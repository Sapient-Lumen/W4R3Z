## A fresh lesson from current SlopOS secure-transport identity posture

Another especially useful seam for ViewFS while SlopOS is still in design is **transport intent versus reference identity versus presented evidence versus verifier profile versus trust-anchor/pin inputs versus channel binding versus resumption state versus current live secure channel versus durable receipt/history**.

What to steal:
- `network-lease-tls-verifier-boundary-v0.md` keeps TLS/QUIC reachability separate from portable trust-root, hostname-verifier, and certificate-exception semantics;
- `network-lease-client-cert-boundary-v0.md` keeps mTLS/client-cert selection out of ordinary network leases;
- `network-lease-session-resumption-boundary-v0.md` keeps tickets, PSKs, and 0-RTT from becoming portable lease truth;
- `certificate-identity-evidence-boundary-v0.md`, `certificate-path-input-boundary-v0.md`, and `certificate-status-evidence-boundary-v0.md` keep identity interpretation, path inputs, and status inputs explicit;
- `namecert-trust-root-boundary-v0.md` reinforces that anchors are evaluator-local input, not self-installed by presented evidence.

What not to freeze yet:
- one universal ViewFS verifier profile or root store;
- one WebPKI/DANE/SPIFFE/SSH/mTLS comparison grammar;
- one channel-binding object format;
- one session-ticket/PSK/0-RTT persistence model;
- one client-certificate or keychain selection lane;
- any assumption that `secure transport succeeded` means service authority, object import trust, secret release, or durable reconnect authority.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS import/materialize/CapStore posture

Another especially useful seam for ViewFS while SlopOS is still in design is **committed object versus archive tier versus thaw job versus thawed copy versus current live facet versus durable receipt/history**.

What to steal:
- `import-to-docref-boundary-v0.md` already keeps durable local object birth separate from later routine reopen semantics;
- `import-to-docref-fresh-identity-boundary-v0.md` already keeps fresh local object identity separate from same-byte alias folklore;
- `capstore-commit-schema-v0.md` already keeps durable commit meaning explicit instead of ambient;
- `lease-descriptor-state-boundary-v0.md` already keeps issuance evidence weaker than current live/openability truth;
- shell chrome should be able to say `archived`, `thaw requested`, `temporary readable copy`, `expires then`, `live here now`, or `history only` as different truths.

What not to freeze yet:
- one universal archive-tier taxonomy across all ViewFS providers and object families;
- whether thaw means temporary copy, tier mutation, provider-local cache warmth, or all three;
- whether every provider exposes explicit expiry dates or only current state;
- whether thaw jobs are explicit first-class objects or just provider-operation rows;
- any assumption that one thaw receipt or rehydrate-complete row proves a current live facet still exists now.

This pass stays deliberately **idea-rich and decision-light**.
## A fresh lesson from current SlopOS cryptosvc, vault, and wallet posture

Another especially useful seam in the current SlopOS material is **sealed object versus recipient wrap versus rewrap plan versus unwrap handle versus current clear facet versus durable receipt/history**.

What to steal:
- `rfcs/0067-capability-crypto-services-and-key-handles.md` keeps key use bound to explicit keyrefs and routes instead of ambient secret material;
- `docs/30-architecture/cryptosvc-key-material-boundary-v0.md` keeps ordinary key use separate from secret-bearing key import/export and rewrap folklore;
- `docs/30-architecture/vault-posture-v0.md` keeps provider-owned secret objects and recovery/inventory posture explicit instead of ambient;
- `docs/30-architecture/auth-proof-export-boundary-v0.md` keeps local auth ceremonies from silently becoming portable proof-export or challenge-signing folklore;
- shell chrome should be able to say `sealed object`, `wrap roster`, `rewrap planned`, `unwrapable here`, `clear facet bound`, or `history only` as different truths.

What not to freeze yet:
- one universal envelope or recipient-wrap format across all ViewFS providers and object families;
- whether wraps are inline, sidecar, or provider-indexed;
- one universal recipient taxonomy covering users, services, devices, and provider-local key slots;
- whether rewrap is in-place, version-producing, or provider-specific;
- whether clear facets survive restart, escrow, or machine boundaries.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from retention, hold, and purge posture

Another especially useful seam for ViewFS while SlopOS is still in design is **committed object versus retention clock versus hold state versus purge verdict versus current live facet versus durable receipt/history**.

What to steal:
- `rfcs/0065-orthogonal-persistence-and-capstore.md` keeps durable existence explicit instead of ambient;
- `rfcs/0114-verified-blobs-and-merkle-integrity.md` keeps immutable content identity separate from mutable policy state;
- `docs/30-architecture/receipt-replication-boundary-v0.md` keeps evidence/history from reviving present truth;
- shell chrome should be able to say `committed object`, `retained until`, `temporary hold`, `event hold`, `legal hold`, `purge blocked`, `purge pending`, `purged`, or `history only` as different truths.

What not to freeze yet:
- one universal retention/hold taxonomy across all ViewFS providers and object families;
- whether retention is version-scoped, anchor-scoped, or aggregate-scoped;
- whether event-driven, temporary, and legal/investigation holds all deserve first-class universal families;
- whether purge lanes are user-driven, lifecycle-driven, GC-driven, or policy-driven in Phase 1;
- any assumption that a kept object is frozen in every other way or currently usable now.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS ordering and supersession posture

Another especially useful seam in the current SlopOS material is **semantic object core versus designation versus revision token versus order scope versus supersession row versus current live facet versus durable receipt/history**.

What to steal:
- `rfcs/0119-ordering-streams-and-tokens.md` keeps ordering evidence scope-bound and witness-shaped instead of pretending one global sequence number explains everything;
- `conflict-key-schema-v0.md` and `conflict-key-family-registry.md` keep the mutation-order scope nameable instead of flattening every write into one global `version`;
- `capstore-commit-schema-v0.md` keeps commit identity, parentage, and epoch explicit rather than hiding head movement inside one vague mutable name;
- `lease-descriptor-state-boundary-v0.md` keeps current live/openability truth separate from any old descriptor or remembered head token;
- Schell and Ward add healthy cross-pressure here too: one negotiated or resolved outcome can be superseded later without erasing the older row or making it live truth again.
- shell chrome should be able to say `object core`, `name/designation`, `current head`, `ordered with`, `superseded`, `live facet`, or `receipt only` as different truths.

What not to freeze yet:
- one universal revision-token family across all ViewFS providers and object families;
- one global logical clock for the whole object store;
- whether order scopes are object-local, branch-like, published-name-local, or provider-local;
- one final supersession-row schema or tombstone family;
- any assumption that a newer head token proves semantic sameness, exact byte sameness, or current live authority.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS proof and validator posture

Another especially useful seam in the current SlopOS material is **exact strong proof versus weaker stable validator versus explicit comparison profile versus current live facet versus durable receipt/history**.

What to steal:
- `capability-wallet-schema-v0.md` makes `wallet_core_digest` stable by projecting and sorting selected fields, which is a great reminder that some comparison keys are intentionally profile-shaped rather than exact full-envelope proofs;
- `artifact-reference-schema-v0.md` keeps exact artifact identity on digest-bearing CH-AREF rows instead of pretending the stable review digest and the exact artifact digest are interchangeable;
- `capstore-commit-schema-v0.md` keeps commit identity, parentage, and epoch truth explicit rather than implied by one weak summary key;
- `document-handle-schema-v0.md` and `lease-descriptor-state-boundary-v0.md` keep current live/openability truth separate from any old digest or descriptor evidence;
- shell chrome should be able to say `strong proof`, `weak validator`, `compare profile`, `live facet`, or `receipt only` as different truths.

What not to freeze yet:
- one universal strong-proof digest family across all ViewFS object families;
- whether every family even needs a weak validator lane;
- one final comparison-profile schema or registry;
- any assumption that a stable review digest is safe to reuse as an exact write/range gate;
- any assumption that an old proof or validator proves current live authority exists now.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS budget-payer posture

Another especially useful seam in the current SlopOS material is **action authority versus explicit payer root versus bounded budget lease versus actual spend/charge truth**.

What to steal:
- `budget-payer-semantics-v0.md` already says **no ambient current payer**, no hidden session sponsorship, and no portable rule that `current process/container/subtree` equals payer;
- `budget-lease-schema-v0.md` keeps budget leases as explicit bounded sponsorship artifacts instead of magical access side-effects;
- `background-lease-posture-v0.md` keeps `allowed to keep running` separate from any implication that costs are silently covered forever;
- shell chrome should be able to say `authorized`, `requester pays`, `server budget`, `budget present`, `charged`, `charge rejected`, or `receipt only` as different truths.

What not to freeze yet:
- one universal payer-root schema across all ViewFS families;
- one final budget lease or charge-verdict wire format;
- any assumption that current room authority implies current sponsorship;
- any assumption that charge receipts prove a live sponsor still exists now.

This pass stays deliberately **idea-rich and decision-light**.

# Evaluating the SlopOS datacube for ViewFS

## A fresh lesson from current SlopOS import/materialization posture

Another especially useful seam in the current SlopOS material is **transient staging capsule versus seal state versus courier handoff versus committed object versus current live facet versus durable receipt/history**.

What to steal:
- `import-to-docref-boundary-v0.md` already says explicit materialization must happen before routine document workflows, which is exactly the right instinct for `draft first, commit later` honesty;
- `import-to-docref-fresh-identity-boundary-v0.md` keeps fresh local object birth separate from same-byte aliasing, which stops one old local object from laundering a new staging/import event;
- `artifact-reference-schema-v0.md` keeps exact artifact identity separate from locator folklore, which is the same kind of humility a staging capsule needs;
- `capstore-commit-schema-v0.md` keeps durable commit meaning explicit instead of ambient;
- shell chrome should be able to say `draft capsule`, `sealed for review`, `couriered locally`, `committed here`, `published now`, or `history only` as different truths.

What not to freeze yet:
- one universal staging-capsule primitive across all ViewFS providers and shells;
- whether freeze-for-review comes from kernel seals, provider-local posture, or shell-only discipline;
- whether every helper handoff is FD-passing, portal-owned, or runtime-owned;
- whether any capsule survives restart, reboot, or machine boundaries;
- any assumption that a frozen capsule is already a durable object or durable reopen grant.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS request-key discipline

Another especially useful seam in the current SlopOS material is **retry-safe sameness witness versus accepted request versus provider follow-up versus later completion verdict versus local adoption**.

What to steal:
- `network-request-idempotency-boundary-v0.md` already says the same scoped request key replays only the same canonical request and must reject mismatched reuse before effect;
- `background-request-state-posture-v0.md` keeps request identity smaller than current provider-owned state;
- `acp-acceptance-completion-posture-v0.md` reminds us that admission and later settlement are different truths even after one exact request was accepted;
- shell chrome should be able to say `fresh intent`, `same-intent retry`, `payload mismatch`, `accepted`, `ticket`, `settled`, or `receipt only` as different truths.

What not to freeze yet:
- one universal idempotency-key or fingerprint schema across all ViewFS provider families;
- any assumption that the shell or provider must own the sameness witness in every case;
- any assumption that a replay-safe duplicate implies a fresh provider run or fresh room adoption;
- any assumption that an old request key proves current settlement truth after expiry or pruning.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS acceptance/completion posture

Another especially useful seam in the current SlopOS material is **accepted request versus provider-owned follow-up operation versus later completion verdict versus local adoption**.

What to steal:
- `acp-acceptance-completion-posture-v0.md` already says an accepted request or outcome receipt is not downstream completion truth or current provider-owned live state;
- `acp-outcome-receipt-schema-v0.md` keeps admission receipts bounded instead of turning them into a generic completion bus;
- `background-request-state-posture-v0.md` keeps a stable request key separate from current grant state, which is exactly the same kind of humility ViewFS needs for provider-backed mutation tickets;
- shell chrome should be able to say `accepted`, `operation handle`, `pending`, `settled`, `adopted here`, or `receipt only` as different truths.

What not to freeze yet:
- one universal async mutation/result protocol across all providers and object families;
- whether every provider offers a pollable status endpoint or operation object;
- any assumption that provider settlement automatically rewrites current room footing;
- any assumption that an old accepted-request receipt proves current completion truth.

This pass stays deliberately **idea-rich and decision-light**.

The uploaded SlopOS archive is still visibly in design. That is a reason to steal its strongest **separations** and **process habits**, not a reason to inherit every future-facing surface whole.

For this revision, the most useful SlopOS surfaces were:
- `rfcs/0065-orthogonal-persistence-and-capstore.md`
- `docs/30-architecture/attrfs-posture-v0.md`
- `docs/30-architecture/capshell-filesystem-posture-v0.md`
- `docs/30-architecture/capshell-handle-table-posture-v0.md`
- `docs/30-architecture/capstore-commit-schema-v0.md`

A productive reading of the current SlopOS “datacube” is not “one giant subsystem.”
It is also now clearly resisting one especially dangerous collapse: **local draft state, exact witnessed pushback basis, explicit provider verdict, and local post-verdict adoption are different truths**.
That is one of the best lessons ViewFS can steal right now because it strengthens object-store optionality instead of forcing a premature mutable-provider ABI.

It is a **cluster of separations**:
- immutable-ish artifacts and exact identity,
- explicit handles and handle tables,
- creator-populated per-process views,
- view-scoped query and smart-folder surfaces,
- optional durable roots / cap persistence,
- and shell/automation surfaces that are supposed to stay capability-honest.

## A fresh lesson from current SlopOS commit posture

Another especially useful seam in the current SlopOS material is **exact pushback witness versus provider-side verdict versus local adoption**.

What to steal:
- `acp-precondition-witness-posture-v0.md` keeps exact local witness material and validator-local preconditions separate from floating `latest` queries;
- `capstore-commit-schema-v0.md` keeps durable commit/update meaning explicit instead of hiding it inside session folklore;
- `conflict-key-schema-v0.md` and `conflict-key-family-registry.md` keep conflict scope nameable instead of collapsing everything into one generic mismatch;
- shell chrome should be able to say `draft`, `based on`, `provider accepted`, `provider rejected`, `merge needed`, or `receipt only` as different truths.

What not to freeze yet:
- one universal validator shape across all providers and object families;
- one final pushback/update ABI for the whole datacube;
- whether every provider verdict automatically fast-forwards local room state;
- any assumption that a stale-basis conflict must be solved by one universal merge engine.

## What SlopOS is teaching ViewFS right now

### 1. CapStore should remain optional, explicit, and scary in the right way
The strongest thing about SlopOS's CapStore work is not that it promises durable authority graphs.
It is that it keeps saying **durability is explicit authority**.

That is exactly the right instinct for ViewFS.

What to steal:
- persistence should require explicit store/root capabilities rather than piggybacking on ordinary use;
- immutable object storage and durable authority graphs should stay visibly different layers;
- rollback, resurrection, and revocation epochs should be treated as first-class problems, not cleanup notes;
- device-facing or host-bridge-facing capabilities should be assumed awkward for persistence until proven otherwise.

What not to freeze yet:
- the exact durable-root object model;
- whether ViewFS ever wants single-level-store style semantics;
- any broad “resume is boot” commitment;
- any general persistent capability graph beyond narrow reopen/receipt stories.

### 1b. Narrow continuity is worth stealing, but only as its own seam
One especially good idea to steal from the wider ecosystem is **narrow continuity**:
- a request may still be in flight,
- a conversation may have reconnectable endpoints,
- a launcher or framework may escrow just enough state to resume that conversation later,
- and none of that has to mean “the whole authority graph was persisted.”

That is a much smaller, safer, and more product-useful class than full durable-capability persistence.
It is also a better fit for early ViewFS shell ergonomics.

What to steal:
- continuity/escrow should be opt-in, typed, and obviously narrower than durable roots;
- continuity artifacts should say what they can resume, what they cannot, and when they expire;
- queued follow-ups, portal requests in flight, and reconnectable sessions should stay visible in shell chrome instead of dissolving into scrollback;
- resumption should not silently widen authority beyond the exact resumed conversation.

What not to freeze yet:
- the exact escrow object schema;
- whether continuity storage belongs to the shell, a launcher, or another framework service;
- whether continuity ever crosses reboot, machine boundary, or user boundary;
- any assumption that “resume” implies durable success, full replay, or magical session resurrection.

### 1c. Exact-handle restart lockers are worth stealing too
Another especially good middle shape is **restart-stable exact-handle continuity**.
The best precedent here is not a grand persistent object graph.
It is the narrower idea that a supervisor may hold **specific delegated descriptors** and hand them back at the next restart without pretending to restore the whole machine or every past authority edge.

What to steal:
- continuity lockers should hold exact handles or exact resumable request/session artifacts, not a fuzzy “workspace state” blob;
- they should be named, inspectable, and obviously narrower than durable reopen refs or persistent roots;
- stop/discard, preserve-across-restart, and preserve-across-wider-boundaries should remain separate product states;
- shell chrome should be able to show `resumable here`, `restart only`, `stale`, `discarded`, or `durable reopen required` instead of one vague restore promise.

What not to freeze yet:
- whether ViewFS continuity lockers are kernel-adjacent, shell-owned, launcher-owned, or portal-owned;
- whether locker contents are always live handles, sometimes typed resumable receipts, or both;
- whether any locker survives a full stop versus only controlled restart;
- any assumption that a locker implies replay safety, output retention, or resurrected side effects.

### 1d. Exact-byte staging capsules are worth stealing carefully

Another especially useful low-regret seam is **explicit startup delivery with issuer-visible handle copies**.
A launcher, supervisor, or mediator can hand a child exact ready resources at start time, and copied handles can carry local issuer-visible identity or witness tags, without any of that pretending to be the object's immutable identity or a durable reopen story.

What to steal:
- startup should prefer handed-in ready handles, namespace fragments, or activation kits over rediscovery by ambient path, port, or global search;
- activation-slot names should stay separate from the underlying object identity and from any later local bind names;
- copied handles may carry issuer-visible badges, labels, or witness tags, but those should describe the copy/issuer lane rather than the object itself;
- shell chrome should be able to show `activation slot`, `source`, `rights`, `issuer badge`, and `object ref` as different truths;
- if a handle came from a continuity locker, portal request, or reviewed route plan, that source should remain explicit rather than dissolving into a generic open event.

What not to freeze yet:
- the exact badge/label encoding or whether badges are kernel-level, runtime-level, or shell-only descriptors;
- whether activation kits are shell-owned, supervisor-owned, portal-owned, or split across those layers;
- whether issuer-visible badge values ever cross machine or user boundaries;
- any assumption that a startup carrier or badge automatically implies durable reopen, stable naming, or trust.

Another especially useful middle shape is **transient exact-byte staging**.
A system can let a process assemble or receive exact bytes in a temporary capsule, seal that capsule for review or transfer, hand the live capsule explicitly to another process, and only later decide whether those bytes deserve a durable object-store commit.

That is a much smaller commitment than making every import/export/editor round-trip a path reopen or a durable authority story.
It is also a very nice fit for ViewFS's design-phase posture.

What to steal:
- staging capsules should be explicit transient artifacts, distinct from committed object IDs, durable reopen refs, and ordinary history rows;
- sealing / commit-last flows are attractive for preview, external-editor return, drag/drop, and export-review paths;
- local exact transfer should prefer explicit handle courier lanes over path reopen folklore;
- shell chrome should be able to say `draft capsule`, `sealed for review`, `couriered`, `committed`, or `discarded` instead of one vague temporary-file story.

What not to freeze yet:
- the exact implementation primitive (sealed RAM file, temp inode, shared-memory object, or something else);
- whether capsules are shell-owned, portal-owned, or lower-level runtime objects;
- whether any capsule can ever cross reboot or machine boundaries;
- any assumption that a sealed capsule automatically implies durable storage, durable authority, or durable reopen.


### 1f. Transfer ghosts, paste capsules, and local imports are worth keeping apart
Another especially useful seam is **current transfer/source truth versus retained history ghosts versus prompt-local paste capsules versus later local materialization**.

What to steal:
- typed transfer sessions should stay visibly different from durable document handles and from live room binds;
- a helper-retained clipboard/history ghost should remain visibly weaker than a current offer or a fresh import;
- prompt-local paste should be allowed to stay just prompt input unless the user explicitly materializes/imports it;
- shell chrome should be able to say `offer now`, `history ghost`, `prompt bytes only`, `materialized here`, or `receipt only` instead of one vague clipboard/open story.

What not to freeze yet:
- the final clipboard/history substrate;
- whether Phase 1 exposes primary-selection-like and clipboard-like lanes separately;
- whether materializing a transfer always mints a fresh local object versus sometimes adopting one live transferable handle;
- any assumption that one retained clipboard/history row implies durable reopen authority.

### 1e. Courier provenance and structured command packets are worth stealing
Another especially useful seam is **courier provenance plus structured command packets**.

The best lesson here is not “invent a giant messaging substrate.”
It is the smaller observation that a local courier lane can carry exact live handles or capsules **and** a bounded witness about who sent them, while the shell can promote a strongly-known command block into a structured packet for routing/escalation without pretending raw transcript text is now authority.

What to steal:
- a courier witness should describe the sender lane or peer that transferred something, while staying separate from the transferred object's identity and separate from any later durable receipt;
- shell-visible `received from`, `issuer`, `peer witness`, or `route source` labels are useful truth even when the transferred object is the same underlying object/capsule as before;
- strongly-known command blocks should be promotable into explicit packets carrying command line, exit/result state, captured output, and nearby witnesses instead of forcing copy/paste into another helper or route plan;
- explicit packet promotion is a better product move than teaching the terminal to infer too much from arbitrary selected text.

What not to freeze yet:
- the exact peer-witness schema or whether it comes from OS credentials, runtime badges, or shell-local attestations;
- the final command-packet schema or whether packets carry cwd/env/attachment references by default;
- whether packet promotion is shell-owned, route-sheet-owned, or shared with another service;
- any assumption that a command packet automatically implies replay approval, durable audit status, or durable authority.

### 1f. Live process descriptors are worth stealing, but only with narrower right classes

Another especially useful seam is **exact running-process identity without PID folklore**.

The best lesson here is not “give the shell magical omnipotent process objects.”
It is the smaller observation that a shell or supervisor can track one exact running command instance through a process descriptor-like handle, while still keeping lifecycle control, deep inspection, and transcript history visibly separate.

What to steal:
- running commands should be trackable as exact live instances instead of only numeric PIDs or command-line text;
- `wait/poll`, `interrupt/terminate`, and deeper `inspect/debug/duplicate-fd` powers should be different right classes, not one vague process handle promise;
- shell chrome should be able to say `running now`, `history only`, `waitable`, `stoppable`, `deep inspect available`, or `receipt only`;
- transcript-promoted command packets should stay useful after exit without pretending to be current process authority.

What not to freeze yet:
- the exact kernel/runtime primitive (pidfd, procdesc, supervisor-local ref, or something else);
- whether lifecycle control and deep inspection share a primitive or stay on separate lanes;
- whether any process-handle story crosses reboot, machine, or user boundaries;
- any assumption that a visible running-command card implies debugger attach, namespace entry, or fd duplication.

### 1g. Detached namespace fragments are worth stealing, but only as a separate pre-attach class

Another especially useful seam is **a namespace fragment that exists before it is attached anywhere**.

The best lesson here is not “reinvent the Linux mount API.”
It is the smaller observation that a system can:
- open or clone one exact subtree or view fragment,
- adjust some narrow posture on that detached fragment,
- and only later attach it into one concrete process view,
without pretending the fragment was already globally named, durably placed, or ambiently reachable.

What to steal:
- a detached fragment / view fragment should be a first-class object distinct from a live bind into one process namespace;
- pre-attach posture should stay explicit, narrow, and inspectable rather than getting inferred later from the final attach point;
- attaching a fragment should be a separate act that produces a bind/attach receipt instead of silently laundering the fragment into “that path was always there”;
- shell chrome should be able to say `detached fragment`, `prepared`, `attached here`, `not yet attached`, or `discarded before attach`;
- closing or discarding an unattached fragment should remain a smaller and safer act than revoking a committed object or tearing down a durable reopen story.

What not to freeze yet:
- the exact implementation primitive (detached mount-like object, view fragment descriptor, handle-table recipe, or something else);
- which fragment transforms are legal before attach and which must remain impossible in Phase 1;
- whether fragments are shell-owned, launcher-owned, or a lower runtime/service seam;
- any assumption that a detached fragment implies durable storage, durable naming, or cross-process/global visibility.

### 1h. Exact exec objects and activation-time credentials are worth stealing, but only as separate launch-basis classes

Another especially useful seam is **exact launch meaning before the child starts**.

The best lesson here is not “copy Linux execve details” or “copy systemd wholesale.”
It is the smaller observation that a system can:
- bind one exact executable object or exact staged byte object,
- keep script/interpreter entry explicit instead of rediscovering it from shebang or ambient PATH,
- keep argv/env/cwd shaping visible as launch basis rather than hidden folklore,
- and deliver startup credentials as a narrower activation-time lane than either environment or durable authority.

What to steal:
- launch should be able to mean `this exact exec object` rather than `whatever mutable name points there now`;
- startup credentials should remain explicit, inspectable, and narrower than ordinary filesystem or environment inheritance;
- shell chrome should be able to say `exec object`, `script input`, `argv/env basis`, `credential slot`, `launch receipt`, or `history only` as different truths;
- route-plan and launch-rehearsal cards should explain exact exec identity and startup credential presence without dumping secret contents into transcript flow.

What not to freeze yet:
- the exact per-platform primitive for launch-by-handle versus exact-byte staging;
- the exact startup credential carrier shape (private files, slots, descriptors, or another narrow lane);
- whether any activation-time credential can ever be promoted into a durable reopen story;
- any assumption that a reviewed command string or mutable path alias is already enough launch identity.

### 1i. Exact exec objects are still not the same thing as exact startup code closure

Another especially useful seam is **exact executable object versus startup code closure**.

The best lesson here is not “copy one loader” or “freeze a package/runtime model.”
It is the smaller observation that a system can:
- bind one exact executable object,
- still have to decide how startup loader/interpreter/shared-library resolution works,
- and still need a separate story for plugin/module imports that happen after startup.

That is a perfect low-regret lesson for ViewFS because it keeps us from overclaiming what “exact launch” means while SlopOS is still moving.

What to steal:
- exact exec-object identity should stay separate from the exact startup native-code closure;
- loader search/resolution policy should stay explicit debt or explicit posture, not hidden launch folklore;
- later plugin/module imports should stay a distinct runtime lane rather than silently expanding what the original launch meant;
- shell chrome should be able to say `exec exact`, `startup closure exact`, `loader debt`, `late import`, `launch receipt`, or `history only` as different truths.

What not to freeze yet:
- the exact startup-closure representation, if any;
- whether ViewFS ever wants a first-class closure manifest at launch time;
- how much late plugin/module import is allowed, denied, or review-gated in Phase 1;
- any assumption that exact executable-object launch already solves dynamic loader/search-order or plugin-import risk.

### 1j. Exact exec objects and startup closure are still not the same thing as runner/runtime choice or bootstrap posture

Another especially useful seam is **exec object versus hosting runner/runtime versus startup/bootstrap posture**.

The best lesson here is not “become Fuchsia” or “become OCI.”
It is the smaller observation that a system can:
- bind one exact executable or exact staged byte object,
- still need to choose what runner/runtime will actually host it,
- still need a separate answer for whether startup is clean or carrying startup-hook / profile debt,
- and only then produce one live interactive session or detached helper.

That is a perfect low-regret lesson for ViewFS because it keeps us from overclaiming what `exact launch` means while SlopOS is still moving.

What to steal:
- runner/runtime choice should stay explicit, inspectable, and visibly separate from the object being run;
- clean bootstrap versus compat/startup-hook debt should stay a separate truth from runner choice and from live-session identity;
- shell chrome should be able to say `exec exact`, `runner kind`, `bootstrap clean`, `interactive live`, `detached helper`, or `history only` as different truths;
- launch-review cards should be able to explain hosting/runtime posture without pretending those choices are object identity or durable authority.

What not to freeze yet:
- the final runner taxonomy for ViewFS or SlopOS;
- whether runner/runtime selection is fully portable or partly provider-local in Phase 1;
- the exact representation for bootstrap posture, startup customization bundles, or compat debt;
- any assumption that a command row or exact exec object already proves how the resulting session will be hosted.

### 1k. Exact child handle tables still do not tell us whether live handles share one open state

Another especially useful seam is **current slot/local binding versus live handle copy versus shared open-state group versus independent reopen**.

The best lesson here is not “copy UNIX file descriptors” or “standardize one portable cursor/lock model now.”
It is the smaller observation that a system can:
- populate a child handle table exactly and reviewably,
- still bind two slots that alias one live mutable open state,
- still mint a fresh reopen to the same object with independent cursor/state,
- and only later describe those choices in receipts/history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **exact-child-table** instinct in `capshell-handle-table-posture-v0.md` and `CH-FDSET v0`, but those seams do **not** by themselves settle whether one reviewed binding is a fresh reopen or another alias to one live open state.

What to steal:
- keep `slot/local binding`, `live alias`, `shared open state`, `fresh reopen`, and `history only` visibly distinct;
- make duplicate-versus-reopen an explicit reviewed choice instead of one ambiguous “copy handle” act;
- let shell chrome say `same live cursor`, `shared lease`, or `fresh reopen` as different truths;
- keep any future transfer/import receipts explicit about whether they preserved live aliasing or minted a new reopen.

What not to freeze yet:
- a universal portable cursor/lock/lease taxonomy for every future ViewFS handle family;
- whether every object kind in ViewFS even exposes shared mutable open-state semantics in Phase 1;
- whether cross-process handle lending of shared open state is portable or remains provider-local in Phase 1;
- any assumption that exact child-table posture already implies independent current-I/O posture.

### 1m. Current possession of a handle is still not the same thing as crossing a launch boundary

Another especially useful seam to steal is **launch-boundary inheritance**.
A current process may hold exact live handles right now, yet that still should not mean a child automatically receives them merely because the host launch path has inheritance knobs or descriptor folklore.

What to steal:
- default launch posture should be `held here only` unless a reviewed launch kit or activation set explicitly carries the handle across;
- launch-boundary eligibility/shuttering should stay separate from the exact child-local slot/name that receives a reviewed copy;
- receipts should remember one reviewed boundary crossing without reviving it later;
- shell chrome should be able to show `held here`, `launch-shuttered`, `eligible but not selected`, `selected for child`, or `receipt only` instead of one vague inherited-handle story.

What not to freeze yet:
- the exact portable slot vocabulary (`fd`, named activation slot, both, or something else);
- whether host backends implement launch shutters with `FD_CLOEXEC`, explicit spawn actions, supervisor-side reconstruction, or another mechanism;
- whether a future `close-on-fork` / no-fork-inheritance posture ever becomes a first-class ViewFS surface;
- any assumption that a launch receipt or child-slot map implies durability, restart continuity, or broader delegation than that one reviewed launch.

### 2. AttrFS has the right humility
The current AttrFS posture is strong because it refuses to become a global inventory oracle.
It keeps queries:
- **view-scoped**,
- **schema-declared**,
- **snapshot-first**,
- and **handle-returning**.

That is almost exactly the right lesson for ViewFS query/search/smart-folder work.

What to steal:
- query inside a bound view, not across the machine by default;
- return objects/handles already reachable from that view, not raw paths or generic existence probes;
- keep live-query/update streams explicitly bounded and revocable;
- keep saved-query/smart-folder persistence shell-owned until stronger evidence exists.

What not to freeze yet:
- full-text / ranking / semantic extraction as part of the base object story;
- app-owned saved-query CRUD surfaces;
- any “query == standing background daemon” model.

### 3. Capshell is strongest where it rejects ambient folklore
The most useful Capshell notes are the ones that say:
- no ambient host filesystem baseline,
- no reviewed `open(path)` membrane smuggled into launch,
- launch authority arrives through explicit cwd/fd/view/document seams,
- handle inventories and child assembly are explicit.

That is gold for ViewFS.

What to steal:
- treat child namespace assembly as an authored act;
- keep handle tables explicit and inspectable;
- refuse “normal host filesystem” as an invisible fallback contract;
- keep shell/session memory and receipts from silently reviving live authority.

What not to freeze yet:
- final shell syntax;
- final exec-pack schemas;
- a giant universal handle taxonomy before prototypes expose the real cuts.

## Lessons we must learn from the past

### A. Durable authority is where systems get weird
Persistent capability systems are inspiring, but they are also where rollback, resurrection, epoch drift, and device-state mismatches start to dominate the design space.

That means ViewFS should keep repeating this sentence:

**blob persistence is not the same problem as durable authority persistence.**

### B. The child should not rediscover its world from ambient globals
Private per-process namespaces are not an implementation trick.
They are the conceptual center.

That means ViewFS should keep preferring:
- creator-populated launch kits,
- explicit directory/object bindings,
- explicit rebinding,
- and explicit child-visible roots.

### C. Requests, selections, grants, and binds are different truths
Portal history keeps teaching the same lesson over and over:
- there was a request,
- there may have been candidate browsing,
- one thing was selected,
- some grant/ref may have been minted,
- and this pane/process may or may not have bound it locally.

Those are not the same class.
ViewFS should not compress them just because a UI wants to say “opened”.

A related lesson from transfer systems is just as important:
- there may be a current clipboard/selection owner,
- that owner may advertise several representations,
- the sink may accept only one representation,
- those bytes may only become pasted prompt input,
- and only a later explicit act might import or bind anything durable.

Those are not the same class either.
ViewFS should not compress them into one magical “paste/open/import” story.

### D. Query is not inventory
The minute search surfaces become ambient inventory, count probes, or cross-view existence tests, they start acting like a second authority plane.

So ViewFS should keep query/smart-folder work:
- view-scoped,
- handle-returning,
- snapshot-first,
- and visibly advisory where appropriate.

### E. The shell is not just decoration
Past systems keep showing that the interaction model determines whether users can actually reason about authority.

A shell that hides authority differences behind plain text is not neutral.
It is misleading.

## Nifty ideas worth stealing

### Activation kits with named slots
A low-regret thing to steal is the idea that startup can hand in already-open resources through named launch slots rather than making the child rediscover them from ambient globals.
That keeps process startup capability-honest and makes shell explainability much stronger.

### Badged handle copies
Another good steal is the distinction between the **object** and the **copy of the handle** to that object.
If copied handles carry issuer-visible badge/lineage/witness material, the shell can explain where a handle came from without pretending that the badge is the object's immutable identity.

### Capability dictionaries, but only as explicit kits
If ViewFS eventually needs grouped authority, the nicest shape on the table is still “dictionary/bundle/kit” — but only when it is:
- explicit,
- inspectable,
- and clearly not the same thing as a live bind or a historical receipt.

### Action menus driven by exact affordances
A surprisingly powerful idea to steal from document-provider and portal ecosystems is that the selected object should advertise what can actually be done with it.
The shell should not have to guess from path shape or filename folklore.

That suggests a very healthy ViewFS posture:
- object identity stays separate from current placement in a bound view;
- currently held rights stay separate from shell guesses about likely verbs;
- exact advertised operations should shape route sheets, chooser follow-ups, and context menus;
- unsupported verbs should disappear or explain themselves rather than failing late behind generic buttons.

### Snapshot-first smart folders
SlopOS's AttrFS posture suggests a powerful pattern for ViewFS:
- a query manifest,
- a current result snapshot,
- maybe a bounded live feed later,
- and a shell-owned saved-query surface.

That avoids both fake freshness and fake authority.

### Launch rehearsal cards
Before running, show:
- candidate child view,
- exact bindings/handles,
- likely authority delta,
- ambient debt if any,
- and what would be persisted afterward, if anything.

That steals the best part of capability launch systems without overcommitting to final schemas.

### Clipboard offer cards and paste ladders
A very steal-worthy idea is to treat clipboard/selection exchange as a first-class reviewed lane.
The shell should be able to show:
- current source/owner,
- offered MIME/type set,
- accepted representation,
- whether bytes became prompt input only,
- and whether a later import/bind happened at all.

That lets ViewFS copy the good part of transfer-portal design without committing to one clipboard mechanism.

### Request chips, staging trays, and bind-here last
The shell should treat mediated imports like a staged workflow:
- request chip,
- chooser sheet,
- selected object,
- staged action choices,
- bind/reopen/receipt-only split,
- then ledger entry.

### Pane metadata that is not process environment
One especially good shell move is to keep pane/session truth in **terminal-visible pane metadata** rather than laundering it into child env state.
That gives the terminal enough truth for badges, inspectors, and routing without pretending those facts are child authority.

### Inheritance shutters and child-slot maps
Another strong move to steal is a launch-boundary card that shows which currently held handles are shuttered from launch, which ones are explicitly selected, and where the child will actually receive them.
That would make the future ViewFS shell unusually honest without committing to one host mechanism.

## Moves that could make the custom shell + terminal super awesome

### 1. Semantic zones with a human inspector
Prompt/input/output/history-only regions should be first-class and inspectable.
The terminal should be able to show what it thinks the regions are, not keep that protocol state hidden.

### 2. Prompt-local clicks only
Click-to-cursor, edit-in-place, and “send selected command back to prompt” should work only inside the active prompt/input zone.
Old transcript text should stay transcript text.

### 3. Pane HUD with truth labels
Each pane should have tiny visible badges for:
- current view,
- synthetic cwd,
- restricted/trusted posture,
- receipt-only/history-only state,
- ambient debt,
- and whether any live task/request is still active.

### 4. Semantic history with honesty badges
History is useful, but it should tell the truth about what it contains:
- plain text,
- route sheet,
- receipt,
- durable ref,
- stale ref,
- or heuristic file-like guess.

### 5. Result lockers and receipt trays
Do not let mediated imports, route plans, or transfer receipts dissolve into scrollback.
Keep them reusable and obviously typed.

### 6. Route sheets everywhere
Typed links in output should normally land on an inspectable route sheet instead of performing a magical open.

## Repo/process law while SlopOS is still moving
Because both parent and child datacubes are still design-phase, each import should preserve:
- the exact foreign packet that mattered,
- the local seam it pressured,
- the bounded take,
- and the explicit non-takes.

That keeps “good ideas from outside” from laundering themselves into inevitability.
It also means hot moving-head sources should stay on short re-review dates when we lean on them for shell chrome, portal behavior, or continuity vocabulary.

## Things ViewFS should postpone while SlopOS is still moving
- any grand unified durable capability graph;
- any broad rights lattice frozen before real workloads exist;
- any assumption that query/search is part of the object store core rather than a view-scoped adjunct;
- shell syntax commitments beyond the minimum metadata needed for truthful blocks, links, and badges;
- any model where session memory or shell notebooks silently serialize live authority.

## Repo/process implications for ViewFS
Keep copying SlopOS's **archive hygiene**, but in the lightest form that still compounds:
- changelog discipline every revision;
- bibliography + moving-head review queue;
- evidence index and release manifest;
- regenerated context pack every time the archive grows meaningfully;
- one more seam note only when a real anti-collapse pressure appears.

That process discipline is worth stealing immediately even where the design remains unresolved.

## Current recommendation
ViewFS should keep freezing **separations**, not **mechanisms**.

Freeze now:
- immutable identity versus current naming versus mutable head versus durable reopen;
- immutable object storage versus durable authority persistence;
- request versus candidate versus selection versus grant/ref versus bind;
- query snapshot versus live feed versus saved smart-folder manifest;
- pane metadata versus child environment versus live authority;
- browse/open versus trust/automation.

Postpone for evidence:
- rich persistence semantics,
- large query/search ambitions,
- final shell protocol shapes,
- and any unified “one object to rule them all” story.


## Fresh caution from the current SlopOS drafts
SlopOS is already strongest where it keeps **document-portal durable handles** and **typed transfer payload leases** on different seams.
ViewFS should steal that posture, but stay even stricter about one extra split: current clipboard/selection ownership, accepted prompt paste, and imported object identity should not collapse back together just because a shell wants a convenient `paste` story.


## Fresh caution from classic job control and current SlopOS shell drafts
SlopOS is already strongest where Capshell keeps job-control posture, local IPC/control lanes, and peer inspection explicit instead of hiding them in one terminal folklore blob.
ViewFS should steal that posture, and stay stricter about one extra split: the live process handle, its visible stream lanes, any controlling-terminal relationship, and the current foreground-turn / interrupt-target state should not collapse together just because the shell wants a friendly `attached terminal` story.

That split is worth freezing early because it helps both architecture and product:
- architecture gets narrower attach/control contracts,
- the datacube avoids turning transcript cards into fake authority,
- and the future shell gets honest `observe`, `stdin live`, `controlling tty`, `foreground now`, and `history only` chrome.

### Foreground baton pills and TTY lease badges
A very steal-worthy shell move is to make interactive ownership visible:
- who is running,
- which bytes are merely mirrored,
- whether stdin is really live,
- whether a controlling terminal exists,
- and where terminal-generated signals go right now.

That copies the best part of old UNIX job control — honest posture — without committing ViewFS to one specific host mechanism.

### 1l. Exact child handle tables still do not tell us whether a handle is only a locator or live byte I/O

Another especially useful seam is **locator/metadata handle versus live byte-I/O handle versus explicit reopen/escalation act versus durable ref/history**.

The best lesson here is not “copy Linux `O_PATH`” or “standardize one portable metadata-only fd family now.”
It is the smaller observation that a system can:
- populate a child handle table exactly and reviewably,
- bind one current root/object handle that is only good for designation, rooted walk, or metadata operations,
- later mint a live read/write/append handle to the same underlying object,
- and only later describe those choices in receipts/history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **exact-child-table** and **bound-root** instincts in `capshell-handle-table-posture-v0.md`, `capshell-cwd-root-posture-v0.md`, and `CH-FDSET v0`, but those seams do **not** by themselves settle whether one reviewed binding is inspect-only or already live byte I/O.

What to steal:
- keep `locator only`, `root/walk only`, `metadata only`, `read now`, `write now`, `needs reopen`, and `history only` visibly distinct;
- make `open for read` / `reopen for write` an explicit reviewed choice instead of silently upgrading a locator;
- let shell chrome say `inspect-first`, `bound root`, `readable now`, or `receipt only` as different truths;
- keep import/bind receipts explicit about whether they minted live byte-I/O or only a locator/root handle.

What not to freeze yet:
- a universal portable handle-class taxonomy for every future ViewFS object kind;
- whether every object kind in ViewFS even exposes a useful locator-only or metadata-only class in Phase 1;
- whether some backends provide these classes directly while others emulate them behind a more portable contract;
- any assumption that exact child-table posture already implies current byte-I/O authority.

### 1n. Exact roots and handles still do not tell us who may rewrite namespace placement

Another especially useful seam is **object identity versus source parent anchor versus destination parent anchor versus namespace-mutation act versus durable receipt/history**.

The best lesson here is not “standardize rename now” or “choose one portable directory-token trick now.”
It is the smaller observation that a system can:
- keep one object identity stable,
- require one current parent anchor to remove or detach the old name,
- require another parent anchor to create or replace a new name,
- make collision posture explicit (`create new only`, `replace`, `exchange`),
- and only later describe those choices in receipts/history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **exact-root**, **explicit-docref**, and **exact-child-table** instincts in `capshell-cwd-root-posture-v0.md`, `capshell-handle-table-posture-v0.md`, and the document-portal drafts, but those seams do **not** by themselves settle who may rewrite namespace placement around a current object.

What to steal:
- keep `object`, `source parent`, `destination parent`, `rename`, `replace`, `exchange`, and `history only` visibly distinct;
- make cross-parent move/rename review show both anchors explicitly instead of hiding them behind one path string;
- let shell chrome say `same object, new placement` without pretending a byte/data handle changed;
- keep mutation receipts explicit about source anchor, destination anchor, and collision posture.

What not to freeze yet:
- the exact portable set of namespace-mutation verbs for Phase 1;
- whether every backend/provider can support `noreplace`, `replace`, or `exchange` natively;
- whether cross-parent mutation uses one primitive, a token/cookie trick, or a higher-level transaction behind the scenes;
- any assumption that inspect/open authority over an object automatically implies authority to rewrite the namespace around it.


### 1o. Current binds still do not tell us how later namespace changes propagate

Another especially useful seam is **live bind versus propagation posture versus peer/upstream relationship versus durable receipt/history**.

The best lesson here is not “copy Linux shared subtrees” or “freeze one propagation mechanism now.”
It is the smaller observation that a system can:
- create one current bind into one explicit local view,
- separately decide whether later namespace changes stay local, propagate to peers, or only arrive from an upstream/master relationship,
- separately decide whether a bind should be cloneable/bindable again at all,
- and only later describe those choices in receipts/history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **explicit local view** and **non-activating replicated summary** instincts in `view-namespace-posture-v0.md`, `view-replication-boundary-v0.md`, and the Capshell root/handle posture docs, but those seams do **not** by themselves settle the blast radius of later namespace changes under one current bind.

What to steal:
- keep `attached here`, `local only`, `shared to peers`, `receive from upstream only`, `not cloneable`, and `history only` visibly distinct;
- make attach/rebind review show propagation posture explicitly instead of hiding it behind one generic bind row;
- let shell chrome say `blast radius local`, `peer-shared`, or `upstream-fed` as different truths;
- keep bind receipts explicit about whether they recorded a local-only, peer-shared, slave/dependent, or unbindable posture.

What not to freeze yet:
- whether ViewFS Phase 1 should expose the full classic `private/shared/slave/unbindable` vocabulary everywhere;
- whether propagation uses kernel shared-subtree mechanics, owner-routed view fan-out, or another provider-local implementation under the hood;
- whether peer/master relationships get surfaced as stable local identifiers, opaque witnesses, or only qualitative blast-radius language;
- any assumption that one current bind always implies the same propagation posture across every backend/provider.


## 1n. Unnamed objects and namespace publication deserve their own seam
The newest low-regret lesson from outside research is that **object existence before naming** is real and useful. Linux `O_TMPFILE` allows creation of an unnamed object in a target filesystem, and `linkat(..., AT_EMPTY_PATH)` can later publish that object into the namespace. That means ViewFS does not need to decide yet whether “save”, “publish”, “attach”, and “durable reopen” are one mechanism.

What ViewFS should steal while SlopOS is still fluid:
- keep `draft object` separate from `published name`;
- keep the chosen publication anchor separate from the object itself;
- keep collision posture and publication act separate from both object creation and later history;
- keep publication receipts/history from turning back into live authority.

How this reflects back onto SlopOS:
- the CapStore/store ideas are strongest when they remain willing to host objects that are not yet in any visible namespace;
- the view namespace work is strongest when publication into a view is explicit and receiptable rather than an automatic side effect of writing bytes somewhere;
- the document-handle / portal work is strongest when `received exact bytes` and `published in this view` stay different lanes.

Shell consequence:
- a future custom shell should be able to surface a `draft object` card, one `publish here` sheet with parent-anchor + collision posture, and one `publication receipt` row without pretending every staged payload has already become a visible file.


## 1p. Descriptor-first object identity is worth stealing, but only if descriptors stay non-authoritative
The newest low-regret lesson from the current SlopOS drafts is that **digest-authoritative descriptor envelopes** are a very strong middle seam. SlopOS's artifact-reference work already points toward `digest authoritative, locator hint only`, and that is exactly the sort of restraint ViewFS should copy while the object store, handles, portals, and namespace machinery are all still moving.

What ViewFS should steal while SlopOS is still fluid:
- keep `object/content descriptor` separate from `live handle now`;
- keep media type, byte size, and locator hints explicitly non-authoritative;
- keep `descriptor known` separate from `local bytes hydrated`, `bound here`, and `published here`;
- keep transcript/history rows useful by letting them carry descriptor truth without silently reviving authority.

How this reflects back onto SlopOS:
- the CapStore/store ideas are strongest when exact-object description does not overcommit ViewFS to one fetch or publication mechanism;
- the document-handle / portal work is strongest when `descriptor known` and `current access granted` stay different lanes;
- the shell ideas get much better when object cards can exist before a current bind or reopen is minted.

Shell consequence:
- a future custom shell should be able to surface a compact `descriptor card` with digest/object ID, media type, size, and locator hint, then offer a narrow ladder like `hydrate`, `bind here`, `publish here`, or `keep as receipt` instead of pretending every object card is already a live file handle.


## 1q. Imported source refs and local durable docrefs deserve a hard materialization boundary
Another especially useful seam is **imported source ref versus explicit materialization act versus fresh local object versus local docref/reopen designator versus durable receipt/history**.

The best lesson here is not “copy Android SAF” or “standardize one portal docref format now.”
It is the smaller observation that a system can:
- identify one source-side object or offer,
- explicitly materialize a fresh local object only when the user or policy chooses,
- mint a local durable docref only after that localization step,
- later mint one live handle/bind when current authority is needed,
- and only later describe those choices in receipts/history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **manual chooser**, **non-bearer docref**, **reopen clamp**, and especially **import-to-docref materialization boundary** instincts in `document-portal-posture-v0.md`, `powerbox-posture-v0.md`, and `rfcs/0089-document-portal-and-durable-file-handles.md`, but those seams do **not** by themselves settle whether ViewFS imports copy now, hydrate later, publish immediately, or route through one exact object-store substrate.

What to steal:
- keep `source ref only`, `materializing`, `fresh local object`, `local docref`, `live handle now`, and `history only` visibly distinct;
- refuse any disguised “remote bearer docref” shortcut for durable reopen;
- make import review show when local identity is minted versus when namespace publication/bind is reviewed;
- keep receipts explicit about whether they recorded source designation, local-object creation, docref minting, live-handle minting, or publication.

What not to freeze yet:
- whether Phase 1 imports always copy immediately, lazily fetch, or support both;
- whether every localized object gets a durable docref or only user-promoted ones do;
- whether local docrefs are visible shell objects, internal portal records, or both;
- whether local-object localization and namespace publication are usually one transaction or remain separate reviewed steps;
- any assumption that “document reopen” must be the universal durable reference shape for every future ViewFS object kind.


## 1r. Shell integration should expose semantic truth, but never smuggle authority through startup magic
Another especially useful seam is **semantic observation side channel versus shell startup/bootstrap mechanism versus current authority**.

The best lesson here is not “copy one terminal emulator's shell integration exactly.”
It is the smaller observation that a system can:
- emit explicit semantic events about cwd/command/object truth,
- keep those events visibly attributable to one shell/plugin/runtime build,
- use barriers or epochs so the UI knows which observations really belong to which launch,
- and still refuse to let integration bootstrap tricks become invisible authority-bearing behavior.

That is a perfect low-regret lesson for ViewFS because Steward already has the right **semantic side-channel**, **confidence/provisional labels**, and **resync epoch** instincts, while SlopOS already keeps exact launch/handle seams explicit. The shell/terminal should therefore be semantically rich **and** brutally honest about where the semantics came from.

What to steal:
- explicit semantic lanes for cwd, command boundaries, descriptor cards, and import/materialization truth;
- remembered-versus-live labels plus freshness/epoch markers;
- exact-run or exact-launch barriers before trusting late-arriving semantic events;
- shell integration that can be manual and inspectable, not only hidden startup injection.

What not to freeze yet:
- one universal sideband transport or escape-sequence family;
- whether ViewFS ships its own shell, shim layers for existing shells, or both in Phase 1;
- any assumption that semantic shell integration should ever be able to mint new object authority by itself;
- any assumption that “automatic integration” is always better than explicit inspectable setup.


## 1s. Remembered reopen and narrow exact continuity should stay separate from live authority
Another especially useful seam is **remembered designator versus explicit revalidation versus exact continuity locker versus revived live handle versus durable receipt/history**.

The best lesson here is not “copy one bookmark API” or “decide now that CapStore is inevitable.”
It is the smaller observation that a system can:
- remember one designator for later reopen,
- separately revalidate or resolve that remembered thing,
- separately preserve one exact already-live handle across a narrow restart boundary,
- separately revive one current live handle or bind only when authority is needed again,
- and separately keep stale / moved / revoked outcomes visible in receipts/history.

That is a perfect low-regret lesson for ViewFS because the current SlopOS datacube already has the right instincts in three different places:
- `rfcs/0089-document-portal-and-durable-file-handles.md` keeps non-bearer durable reopen separate from current access,
- `rfcs/0081-activation-handoff-and-handle-stores.md` keeps restart continuity narrow and inbound rather than turning it into a general persistence substrate,
- `rfcs/0065-orthogonal-persistence-and-capstore.md` keeps broad durable authority as an optional profile instead of an MVP assumption.

What ViewFS should steal while SlopOS is still fluid:
- keep `remembered`, `revalidating`, `locker available`, `live again`, `stale`, and `history only` visibly distinct;
- let durable reopen be real without pretending it is the same thing as a live handle;
- let exact restart continuity be real without pretending it settles the larger CapStore question;
- make shell and receipts precise about whether continuity came from remembered designation or exact-handle preservation.

What not to freeze yet:
- whether ViewFS Phase 1 even exposes remembered designators beyond local docref-like objects;
- whether exact-handle continuity lockers exist in early phases;
- whether broad persistent capability graphs ever become desirable outside optional profiles;
- any assumption that restart continuity, reopen, and current authority should share one universal object shape.


### 1k. Transfer offers, live copied authority, later revival, and local adoption should stay on different seams

Another especially useful seam is **offer/courier event versus live copied authority versus later revival designator versus receiver-local adoption**.

The best lesson here is not “copy one IPC transport” or “freeze a durable ticket format.”
It is the smaller observation that a system can:
- surface an exact offer or courier event,
- explicitly choose bytes versus live copied authority versus later revival,
- transport one live handle copy with narrowing when policy allows,
- and only later adopt that result into one local slot/view.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right instincts in `capshell-pipeline-posture-v0.md` and `capx-posture-v0.md`: **no hidden peer-stage raw-handle passing**, explicit delegation import, and fresh-local-object-first bridges for routine document workflows.

What to steal:
- cross-boundary exchange should preserve `offer`, `choice`, `receive`, and `adopt` as distinct truths;
- live copied authority should stay visibly different from a stored revival designator for later revalidation;
- issuer/courier witness should remain separate from both object identity and current authority;
- shell chrome should be able to say `offer only`, `accepted as bytes`, `live copy`, `attenuated copy`, `stored for later`, `adopted here`, or `receipt only`.

What not to freeze yet:
- whether ViewFS Phase 1 supports live handle copying across panes/processes at all;
- whether stored revival designators are provider-local only or ever portable;
- whether receiver-local adoption is shell-owned, provider-owned, or launcher-owned;
- any assumption that `shared once` should silently imply `reopen forever`.

Caution from the past:
- the shell and object store should stay skeptical of durable bookmark-like magic. Security-scoped bookmark history is a reminder that persistent re-open semantics become security-critical surprisingly quickly, so ViewFS should bias toward explicit revalidation and policy-killable designators rather than opaque ambient persistence.

## Additional lesson from current SlopOS drafts: keep designation separate from authority

The newest low-regret thing ViewFS can steal from SlopOS is not one concrete durable-handle mechanism.
It is the **shape** of keeping descriptive artifacts apart from authority-bearing ones.

Why this matters:
- `rfcs/0116-capability-wallets.md` explicitly keeps wallets descriptive rather than authoritative;
- `rfcs/0117-plumb-messages-and-cli-intents.md` keeps intent/routing envelopes separate from raw capability transfer;
- `rfcs/0089-document-portal-and-durable-file-handles.md` points toward mediator-shaped durable reopen instead of ambient rediscovery;
- `rfcs/0065-orthogonal-persistence-and-capstore.md` is powerful enough that it should remain optional and explicit rather than becoming the default explanation for every convenience feature.

My current ViewFS reading:
- **designation-only references** should be easy to copy into notes, receipts, route sheets, and palettes;
- **authority-bearing tickets** should be clearly marked, explicitly revalidated, and optionally hidden behind wallet/mediator UX;
- **local aliases/binds** should stay current-view facts rather than durable truth;
- **receipts/history** should stay inspectable without reviving authority by being clicked.

The practical upshot is simple:
do not let ViewFS’s nicest shell affordances accidentally turn every pretty link into a capability URL.


## Additional lesson from current SlopOS drafts: keep declared caveats separate from enforced attenuation

The best new thing to steal from SlopOS is not one final delegation format.
It is the discipline of keeping **declared bounds**, **enforced bounds**, **current live authority**, and **history** apart.

Why this matters:
- `capability-lease-posture-v0.md` is unusually crisp that the **lease proxy is the authority** and the redaction-safe descriptor is evidence only;
- `capability-export-schema-v0.md` is equally crisp that the export envelope can carry caveat display material without forcing the core seam to standardize one caveat VM too early;
- `capability-semantics.md` keeps attenuation, membranes, and revocation strategies explicit instead of pretending all delegation works the same way.

My current ViewFS reading:
- **declared caveat sets** should be easy to inspect in transcripts, route sheets, and receipts;
- **membrane/lease badges** should say where enforcement really lives;
- **live delegated handles** should remain current-authority facts, not just pretty caveat cards;
- **revival designators** should stay explicit and policy-killable;
- **receipts/history** should say which lane was used without reviving authority.

The practical upshot is simple:
do not let ViewFS’s nicest shell chrome turn every “read-only until tomorrow” chip into fake proof that anything is being enforced right now.

## Added in Revision 068: permission outlook versus liveness truth

- **REF-W3C-PERMISSIONS** reinforces that queryable permission state is explicit and can be `granted`, `prompt`, or `denied`, which is useful exactly because it does not pretend the caller already holds the result.
- **REF-WICG-FSACCESS** sharpens the same lesson for file-like handles: `queryPermission()` and `requestPermission()` give explicit state and repair steps, while operations still reject when permission is denied.
- **REF-XDG-DOCUMENTS** reinforces that grant, revoke, delete, and info are separate acts with separate observable consequences.
- **REF-ANDROID-SAF** reinforces that stable document IDs and per-document capability flags are useful, but still separate from whether the app currently has permission and from whether the target still opens cleanly.
- **REF-ZCAP-LD** keeps expiry and revocation first-class instead of invisible folklore.
- **REF-SEL4-MANUAL-LATEST** remains a reminder that revoke is an explicit act and that user-level designs should avoid pretending authority loss is mysterious.
- The combined lesson is that ViewFS should keep **permission outlook**, **revival designators**, **current live handles**, **explicit death-state verdicts**, and **receipt/history** visibly separate instead of one generic `reopenable` object.

## Additional lesson from current SlopOS drafts: keep permission outlook separate from current authority and dead-state truth

The best new thing to steal from SlopOS is not one final revocation object.
It is the discipline of keeping **preflight state**, **current authority**, **death-state reason**, and **history** apart.

Why this matters:
- `document-portal-posture-v0.md` already points toward explicit mediated grants instead of ambient reopen folklore;
- `powerbox-posture-v0.md` already refuses to become a remembered-grant oracle;
- `capability-lease-posture-v0.md` already keeps lifecycle and enforcement explicit;
- `namecert-time-boundary-v0.md` already keeps freshness/admission checks from silently mutating live bindings.

My current ViewFS reading:
- **permission outlook** should be easy to surface in the shell as advisory preflight, not authority;
- **revival designators** should remain explicit things that may help ask again later;
- **live handles** should remain the current-authority truth;
- **death-state verdicts** should preserve reason classes like `revoked`, `expired`, `target changed`, `issuer unavailable`, or `history only` rather than collapsing into `stale`;
- **receipts/history** should preserve what happened without reviving authority.

The practical upshot is simple:
do not let ViewFS’s nicest shell chrome turn `granted` into fake possession or `stale` into the only explanation for authority death.

### 1g. Provenance claims, endorsement bundles, and local admit/deny should stay on different seams

Another especially useful seam is **claim versus endorsement versus local verdict versus live handle**.

The best lesson here is not “make the datacube a software-supply-chain product.”
It is the smaller observation that SlopOS already has the right instinct in its attestation family: exported evidence, endorsement/reference inputs, and verifier-local verdicts should not collapse together.

What to steal:
- keep provenance/import/build/review claims inspectable even when the local verdict is still `preview only` or `deny`;
- keep endorsement bundles, threshold/delegation material, or reference-value packs visible as appraisal inputs rather than universal truth;
- keep local admit/deny/runnable-open verdicts explicit and transcript-visible;
- keep current live handles and binds as a separate truth again;
- let shell chrome answer `why runnable here?` with claim + endorsement + local rule instead of one green trust badge.

A nice companion idea from the uploaded Helm archive is its **trusted chrome lane** and **host-effect witness** posture: stronger review/admit surfaces should live in shell-owned chrome, while weaker-origin content can still explain what request or claim motivated that review lane. That is a very good product move for ViewFS too.

What not to freeze yet:
- whether ViewFS Phase 1 requires provenance or attestation for all local objects;
- whether endorsement stacks are local-only, mirrored, or fetched on demand;
- whether guarded-open, document-open, and runnable-open share one verdict family;
- any assumption that signature presence, transparency logging, or attestation structure alone equals local admission.

## 1w. Request rows, session handles, portal-owned current state, and local adopted binds deserve a hard seam

This is one of the best lessons in the current SlopOS drafts. The background request-state note is crystal clear that one requester-chosen request key is not portal-owned current grant state. That is a beautiful design instinct and ViewFS should steal it.

The matching external lesson is just as strong:
- XDG Request says the request object exists for the duration of one interaction and resolves by `Response`/`Close`.
- XDG Session says long-lived sessions have their own handle and `Closed` signal.
- XDG Inhibit / GlobalShortcuts / ScreenCast show request creation, session handles, later state changes, and current active state on different seams.
- XDG FileTransfer shows a courier object that can remain open, autostop, or close after retrieval.

### Why this matters for ViewFS
ViewFS is heading toward chooser/import flows, durable reopen, transfer offers, and shell-first repair UX.
If it does not preserve this seam, then:
- a request row in history will start masquerading as current portal state,
- a portal-side `active` or `allowed` state will start masquerading as one local live bind,
- and the shell will not be able to explain whether the next action is `retry request`, `rejoin session`, `retrieve transfer`, or `adopt locally`.

### Nifty ideas worth stealing
- **request ledgers** that preserve pending/succeeded/cancelled/expired rows without pretending they are live state;
- **session cards** with explicit `open`, `configured`, `active`, `ending`, `closed`, and `closed by portal` states;
- **adoption shutters** that answer whether this pane actually adopted the result or only witnessed the portal outcome;
- **repair ladders** that can say `retry`, `rejoin`, `retrieve`, `adopt`, or `ask again` instead of one generic reopen button.

### What not to decide yet
Do not decide yet whether ViewFS exposes a generic `list live portal state` API, whether every family shares one lifecycle enum, or whether portal-owned state is shell-only or app-queryable. Freeze the split first.

### 1x. Added in Revision 071: smart queries versus materialized local collections

A particularly strong lesson from older query systems is that saved-query surfaces should not silently become durable local collection objects. Apple Smart Folders are saved criteria, Windows Search Folders are query descriptors that are rerun, and Haiku's query objects can be live virtual objects that notify on changing matches.[REF-APPLE-SMARTFOLDERS][REF-WIN-SEARCH-MS][REF-HAIKU-FSMODULES]

That gives SlopOS's datacube and ViewFS a very clean low-regret seam to preserve while SlopOS is still fluid: query manifest / snapshot of hits / live query feed / materialized local collection / current bind / receipt. We do not need to decide yet whether the eventual collection object is called a basket, set, shelf, pin, or folder; we only need to avoid collapsing it into the query engine.

The custom shell opportunity here is unusually good. A shell-native freeze operation can turn a live or remembered query surface into a local basket-like collection object, then show a drift lens between "what the query says now" and "what was frozen then" without lying that these are the same thing. Portal-mediated indexing and provider access can also surface as explicit index-debt or provider-unavailable badges instead of ordinary path errors.[REF-GNOME-SERVICES]

### 1y. Additional lesson from current SlopOS drafts

The SlopOS drafts are at their best when they preserve seams rather than finalizing mechanisms too early. AttrFS-like query ideas are compelling, but they become much safer if the repo keeps saved queries, frozen hit sets, and local durable collections visibly distinct. That posture keeps the datacube expressive without letting the query subsystem quietly become the whole object store.

### 1z. Added in Revision 072: completion candidates versus accepted insertions versus compiled packets

One of the sharpest lessons in the current SlopOS drafts lives in `mcp-completion-import-boundary-v0.md`: provider-local completion suggestions are not selector/default/workflow truth. That is exactly the kind of boundary ViewFS should steal while the datacube is still fluid.

The stronger ViewFS-specific refinement is: **candidate suggestion / focused detail / accepted insertion / compiled pane-local packet / prepared action / receipt**.

That gives the custom shell a great path to being genuinely awesome without getting spooky:
- completion ghosts can stay advisory,
- detail drawers can load provenance/rights/docs on focus,
- fish-style accept-one-word flows can remain fast and explicit,
- packet gutters can explain what the current pane actually recognized and bound,
- and replay can key off trust grade instead of treating every old line of transcript text as equal.

The historical lesson is good too. LSP keeps list rows, lazy resolve, and insertion semantics distinct; fish keeps autosuggestion acceptance separate from execution; and trusted shell-integration protocols make explicit command packets stronger than heuristically scraped text. ViewFS should steal those separations, not just their widgets.

What not to freeze yet:
- whether ViewFS packet truth is `shell reported`, `nonce verified`, `object composed`, or some other final vocabulary;
- whether accepted insertions are textual only or can carry structured object fragments;
- whether focus-triggered detail loads are shell-local or helper/provider-assisted.

### 1aa. Selected regions, extracted entities, and routed actions should stay on different seams

Another especially useful seam is **selected screen region versus extracted entity versus routed intent envelope**.

The best lesson here is not “copy terminal hyperlinks” or “copy one hints mode.”
It is the smaller observation that a modern shell can:
- expose one visible text/cell region,
- separately propose one typed meaning for that region,
- separately resolve more target detail lazily,
- separately mint one typed plumb/route envelope,
- and only later prepare one action.

That is a very good low-regret seam for ViewFS because the current SlopOS plumb drafts already keep typed message envelopes non-authoritative and request-local instead of turning them into a covert capability lane.

What to steal:
- keep highlighted bytes/cells separate from typed entity candidates;
- keep lazy target/detail resolution separate from route choice;
- keep one route/plumb envelope separate from one prepared action;
- let shell chrome surface `plain text`, `path-ish`, `receipt ref`, `object ref`, `URI`, `explicit link`, `resolved target`, and `route slip` as different truths;
- preserve hostname mismatch / missing target / history-only / bind-exists-here states before action prep.

What not to freeze yet:
- the final entity-candidate taxonomy;
- whether extraction is shell-owned, terminal-assisted, or helper-assisted;
- whether all route slips reuse one final shared packet schema;
- any assumption that OSC 8 or selection hints themselves imply authority or execution.

The shell payoff is excellent. A custom ViewFS terminal could make transcript interaction feel magical by showing an **entity peel** first and a **route slip** second. That is the right kind of awesome: faster than ordinary terminals, but still brutally honest.

## Revision 074: gesture evidence, activation batons, armed state, and active control are different classes

One more low-regret seam is worth freezing now: **fresh user-action proof / transferable activation baton / armed-or-enabled lane / active control / receipt**.

This is a particularly good seam for ViewFS because it improves the shell and portal-mediated imports without forcing any object-store decision.
SlopOS already has the right instincts in its attention, capture, and request-state notes: transient attention is not durable truth, enabled/requested state is not the same thing as active state, and the strongest interaction consequences need explicit, inspectable surfaces.

What the outside world adds is a sharper interaction vocabulary:
- HTML distinguishes sticky activation, transient activation, and activation-consuming calls, which is a good reminder that recent user action is timed/consumable proof rather than standing authority.
- Wayland uses user-event serials and separate activation tokens, which is a good reminder that “I can ask the compositor to activate this” is not the same thing as current foreground control.
- XDG InputCapture explicitly separates `enabled` from `active`, which is exactly the sort of truth-preserving ladder ViewFS should steal.
- Windows foreground transfer APIs remind us that foreground privilege can be passed narrowly and can expire on later input instead of becoming ambient power.

What to steal:
- **activation baton chips** that show `fresh`, `consumable`, `expired`, `passed`, or `refused`;
- **arming rails** that show `prepared`, `waiting for baton`, `enabled`, `active`, `ended`, or `history only`;
- **foreground-transfer cards** that say `may ask to activate` rather than pretending activation already happened;
- **consume-once guards** so one gesture cannot silently power several stronger side effects.

What not to freeze yet:
- a universal baton or activation-token schema;
- whether all portal/import/open/reveal flows require such a baton in Phase 1;
- whether active-control state is shell-owned, terminal-owned, compositor-owned, or mixed;
- whether gesture history is durable by default.


## Revision 075: object identity, placement, rights, and advertised operations deserve a hard seam

One more seam is worth freezing now because it improves both the object model and the future shell without forcing any final storage or portal mechanism: **object identity / current placement in one explicit view / current handle-rights posture / currently advertised operations / receipt**.

The outside precedents are stronger than they first look:
- Android's document model says one opaque `COLUMN_DOCUMENT_ID` is the document identity and explicitly allows the same document to appear as a child of multiple directories, while `COLUMN_FLAGS` separately advertises rename/copy/move/delete/settings/web-link operations.
- Linux `O_PATH` says one descriptor can indicate location and support descriptor-level operations while ordinary read/write-style operations fail.
- Capsicum says one currently held descriptor can be refined so some operations remain possible and others do not.
- Fuchsia says capabilities live in one component namespace with one rights set, and concrete filesystem operations require explicit rights.
- HTTP `Allow` says a target resource can advertise the methods currently supported for it, and that advertised set can change dynamically.

That is a beautiful cluster of lessons for ViewFS and for SlopOS's datacube while SlopOS is still fluid.
The thing to steal is not a single API.
It is the discipline that:
- one object is not one placement,
- one placement is not one current rights set,
- one current rights set is not the same thing as the provider's advertised affordance surface,
- and old receipts are not current affordance truth.

### Why this matters for ViewFS
If ViewFS preserves this seam:
- the shell can render action menus from explicit affordance truth instead of path folklore;
- the same object can appear in several explicit per-process namespaces without faking several identities;
- one locate-only or read-only handle can stay honestly weaker than the full provider object model;
- import/rebind/publish flows can explain whether the missing thing is a wider handle, a different placement, or provider support.

### Nifty ideas worth stealing
- **place cards** for `same object, appears here as …`;
- **verb ledgers** that say `supported by provider`, `not with this handle`, `not here`, `ask policy`, or `history only`;
- **affordance lenses** that separate identity, placement, rights, verbs, and receipts in one inspectable drawer;
- **why-not drawers** instead of generic disabled buttons or late failures.

### What not to decide yet
Do not decide yet whether affordances come from one universal provider ABI, a shell adapter layer, or a mixed model.
Do not decide yet whether placements are parent/name pairs, alias objects, or higher-level bind records.
Freeze the separation first.


## Revision 076: type evidence, handler choice, and live open state

A very good seam to steal from the current SlopOS drafts is the OpenURI/content-type posture around **what generic launch should not decide**.
`openuri-content-type-boundary-v0.md` says generic URI launch should not become a portable MIME/UTI/content-sniffing oracle.
`openuri-handler-selection-boundary-v0.md` says concrete handler choice should stay shell-owned.
`openuri-preview-metadata-boundary-v0.md` says generic launch should not quietly become an unfurl/preview-metadata seam.
`open-untrusted-posture-v0.md` and its companion boundaries reinforce that preview/open/editor choice can and should stay narrower than trust or durable reopen.

That is a beautiful cluster of design instincts for ViewFS.
The thing to steal is not a single type system or a single opener registry.
It is the discipline that:
- one declared type hint is not the same thing as one locally derived classification,
- one type classification is not the same thing as one handler association set,
- one associated/default handler is not the same thing as one chosen opener for this act,
- one chosen opener is not the same thing as one current live preview/editor session,
- and old receipts are not current openability truth.

### Why this matters for ViewFS
If ViewFS preserves this seam:
- the shell can expose type disagreement honestly instead of hiding it behind icons and suffixes;
- preview routes can stay narrower than full editor/open routes;
- open-with UX can become much smarter without silently setting sticky global defaults;
- import/rebind/portal flows can explain whether the next missing step is `pick representation`, `choose opener`, `import locally`, or `stay inert`.

### Nifty ideas worth stealing
- **type lenses** for `declared`, `derived`, `virtual`, and `disagrees`;
- **handler racks** for `associated`, `default`, `chosen now`, `safe preview`, and `unavailable here`;
- **why-this-opener drawers** instead of one opaque `Open With…` result;
- **open-state badges** that can say `previewing`, `editing`, `external`, `portal-owned`, or `history only`.

### What not to decide yet
Do not decide yet whether ViewFS standardizes one universal type schema, one universal handler discovery protocol, or one single owner for opener choice across shell, portal, helper, and provider.
Freeze the separation first.


### 3j. Label-like metadata is worth stealing, but only if we separate note, selector, policy, and chrome
Another especially useful seam is **annotation versus selector label versus policy label versus trusted badge**.

The best lesson here is not “invent one universal metadata system.”
It is the smaller observation that a system can:
- carry rich freeform notes and provenance metadata,
- expose a much smaller selector-safe label set for grouping and smart baskets,
- keep handling/quarantine/review labels in a stronger policy lane,
- and still project all of that into shell-owned badge chrome without pretending the chrome is the substrate.

What to steal:
- freeform annotations should remain useful for explanation, provenance, and imported ecosystem metadata without becoming query truth by accident;
- selector-safe labels should stay compact and visibly queryable so saved filters and materialized baskets do not depend on arbitrary notes;
- policy-bearing labels should live in stronger shell-owned chrome, not in decorative chip clouds;
- a future custom shell should be able to show `annotation`, `selector`, `policy`, `badge`, or `history only` as different classes.

What not to freeze yet:
- the final label schema;
- whether selector labels live on objects, placements, or side indexes;
- whether policy labels are local-only, provider-owned, or imported;
- whether trusted badge chrome is terminal-native, shell-native, or helper-native.

A nice companion idea from the uploaded Steward archive is its **label surface** posture: titles, badges, right-status text, and similar chrome should stay provenance-labeled and clearly separate from transcript or policy truth. That is an excellent product move for ViewFS too.



## Revision 078: continuation cursors, sync watermarks, live subscriptions, and rebuilt state

One more seam is worth freezing now because it improves the shell and datacube-style query surfaces without forcing any final object-store or portal mechanism: **continuation cursor / sync watermark / live subscription / rebuilt snapshot / gap verdict / receipt**.

The outside precedents line up nicely:
- Kubernetes uses `BOOKMARK` events and `resourceVersion` to mark what point a watch has caught up through, allows synthetic initial state followed by a bookmark, and is honest that clients may need repair when older versions fall out of retention.
- Dropbox uses folder cursors both for pagination and later delta polling, but cursors can expire and require a fresh list; longpoll waits for change but still is not the same thing as the updated set.
- Watchman warns that wall-clock time is race-prone and prefers logical clock ids for incremental change tracking, which is a good reminder that better tokens are still just sync state.
- Apple FSEvents is explicit that coalescing, dropped events, and root changes can require recursive or full rescan, and it exposes event ids so clients can judge how far behind they are.

That is a very good low-regret seam for ViewFS because the current SlopOS drafts already keep request identity, portal-owned state, and durable history on separate seams.
The next thing to steal is not a giant global watch/resume API.
It is the discipline that:
- a provider-issued continuation cursor is not a durable object ref,
- a processed-through watermark is not proof that one live follow still exists,
- a live follow is not the same thing as the current materialized result set,
- and a reset/overflow/root-change verdict deserves stronger truth than one vague `stale` light.

### Why this matters for ViewFS
If ViewFS preserves this seam:
- smart baskets and live query panes can show `snapshot through X` versus `following from X` honestly;
- imports and portal-backed result feeds can keep provider sync tokens on the provider side instead of laundering them into durable ViewFS refs;
- the shell can distinguish `waiting for change`, `caught up through`, `needs relist`, and `history only` instead of flattening them;
- receipts and transcripts can explain what happened without silently reviving live follow state.

### Nifty ideas worth stealing
- **waterline cards** for `caught up through`, `following from`, and `rebuilt at`;
- **gap badges** such as `expired cursor`, `resource version too old`, `must rescan`, `provider reset`, or `remote-risk`;
- **resync ladders** that say `continue`, `wait`, `relist`, `rebuild`, `freeze rows`, or `stay receipt only`;
- **snapshot-versus-follow split views** so users can compare a stable set to current live deltas without lists shifting under the cursor.

### What not to decide yet
Do not decide yet whether ViewFS standardizes one universal cursor/watermark schema, whether rebuilt snapshots become first-class stored objects, or whether live follow ownership lives in the shell, terminal, or provider.
Freeze the separation first.

### 23. Exact basis, draft state, and durable winner should stay separate

Another especially useful seam to steal from the wider ecosystem while SlopOS is still fluid is **observed validator / private writable session / live hold / commit predicate / committed durable version**.

What SlopOS is already teaching here:
- `acp-precondition-witness-posture-v0.md` insists that reviewed/observed state must bind through exact local witness material rather than ambient `latest` lookups.
- `capstore-commit-schema-v0.md` keeps durable commit/update meaning explicit instead of letting mutable work state silently define what won.
- the lease family keeps coordination artifacts visibly narrower than final durable authority or final durable history.

What to steal:
- exact basis material should stay inspectable and copyable as honesty artifacts, not current authority;
- local/private writable sessions should stay explicit draft lanes instead of covert shared ownership claims;
- commit acts should say which basis and which hold posture they depended on;
- the durable winning version should remain a visible truth surface distinct from `my draft closed` or `my helper returned`;
- shell editing should bias toward explicit compare/rebase/fork ladders rather than one magical save.

What not to freeze yet:
- one universal validator vocabulary for all ViewFS/SlopOS objects;
- one final transaction ABI for multi-object commits;
- whether write holds are mandatory anywhere in Phase 1;
- whether draft sessions are shell-owned, provider-owned, or runtime-owned across all platforms.

## Revision 080: sparse local bytes, whole-object proof, and lazy fill are different classes

One more seam is worth freezing now because it improves the object-store story and the future shell without forcing a final sparse-storage or portal design: **current local coverage / layout metadata / whole-object completeness / whole-object proof / live range fill / receipt**.

The outside precedents line up nicely:
- HTTP range transfers make it explicit that one response may carry only a portion of the selected representation.
- HTTP caching is explicit that incomplete responses may be stored, but they cannot satisfy a complete request as if incomplete bytes were full truth.
- eStargz is especially valuable because it keeps images OCI-compatible while still allowing lazy fetch of needed files/chunks during execution.
- Amazon S3 is a sharp warning that multipart ETags and part-level checksums are operationally useful but are not automatically one whole-object proof.
- Zarr is a sharp reminder that chunk grids/codecs are extremely useful layout metadata without telling us which chunks are currently local.

That is a very good low-regret seam for ViewFS because SlopOS already has the right instincts around exact blob descriptors, exact staged bytes, and later materialization/commit acts.
The next thing to steal is not one universal sparse-object schema.
It is the discipline that:
- partial local bytes are not the same thing as full local completeness,
- chunk or shard metadata is not the same thing as current local coverage,
- a live lazy-fill path is not the same thing as offline readiness,
- and multipart/composite identifiers are not the same thing as one exact whole-object witness.

### Why this matters for ViewFS
If ViewFS preserves this seam:
- imported/lazy objects can show `descriptor known`, `holes present`, `remote fill reachable`, `whole proof missing`, or `fully local + verified` honestly;
- shell cards can stop flattening huge objects into one fake downloaded state;
- offline/export/publish decisions can depend on stronger truth than `it opened once` or `some bytes were here`;
- and SlopOS's design-phase object store can stay flexible about sparse chunks, range caching, exact proofs, and portal ownership.

### Shell and terminal ideas worth stealing
- **hole maps** so coverage is visible instead of implied;
- **range panels** that keep coverage/layout/proof/fill/history in one trusted drawer;
- **whole-proof ladders** like `fill missing`, `verify whole`, `seal local`, or `stay sparse`;
- **offline honesty lamps** that distinguish `fully local`, `remote-fill only`, `proof missing`, and `history only`.

### What not to freeze yet
- one universal sparse coverage schema;
- whether coverage is tracked by ranges, chunks, files, or provider-specific shards;
- whether every publish/launch/export flow requires one exact whole-object proof;
- whether live range fill is shell-owned, helper-owned, provider-owned, or portal-owned in Phase 1.


## Revision 081: delta recipes, exact bases, and reconstructed targets are different classes

One more seam is worth freezing now because it improves the object-store story and the future shell without forcing a final update/import substrate: **delta recipe / exact basis requirement / current apply session / reconstructed target object / fallback full fetch / receipt**.

The outside precedents line up nicely:
- HTTP `If-Range` is explicit that an exact validator gates whether range/partial recovery is safe; mismatch means send the whole current representation.
- Delta encoding in HTTP is explicit that the delta is against a base instance and that the response still identifies the current instance separately.
- VCDIFF makes the source-segment / target-window distinction explicit instead of pretending the delta is the target object.
- OSTree static deltas target exact commit pairs and even distinguish `from NULL` reconstruction from base-to-target transitions.
- zsync shows that a client can reuse existing local bytes very effectively, but only through explicit checksum/control-file matching rather than magical continuity.

That is a very good low-regret seam for ViewFS because SlopOS already has the right instincts around exact descriptors, explicit materialization acts, and explicit durable commits.
The next thing to steal is not one universal patch format.
It is the discipline that:
- a delta recipe is not the target object,
- an exact basis requirement is not proof the basis is present now,
- an apply session is not durable target truth,
- a reconstructed target is not live-handle continuity,
- and a full-fetch fallback deserves stronger truth than one silent background retry.

### Why this matters for ViewFS
If ViewFS preserves this seam:
- imports, repairs, offline refreshes, and lazy update flows can say `needs base X`, `basis missing`, `apply in scratch`, `rebuilt locally`, or `fetched full target instead` honestly;
- shell cards can stop flattening update/repair flows into one vague `downloaded new version` badge;
- object-store evolution can stay flexible about delta formats, basis vocabularies, and helper ownership;
- and SlopOS can continue deferring a universal delta substrate without losing product clarity.

### Shell and terminal ideas worth stealing
- **basis cards** for `needs X`, `have X`, `mismatched X`, and `history only`;
- **delta peels** that keep recipe/basis/apply/fallback/result/history visible in one trusted drawer;
- **apply ladders** like `apply in scratch`, `verify`, `materialize fresh object`, `fetch full target`, or `discard recipe`;
- **rebuilt-from badges** that say `rebuilt from X + R` without pretending that means same path or same live handle.

### What not to freeze yet
- one universal delta format;
- one canonical basis vocabulary;
- whether apply sessions are shell-owned, helper-owned, provider-owned, or runtime-owned;
- whether every update/import workflow gets a delta lane in Phase 1.

## Revision 082: freeze the seam, not the mechanism

One more seam is worth freezing now because it strengthens the object-store story, capability-handle story, explicit per-process namespace story, and future shell without forcing a final continuity/import substrate: **activation carrier / live handle copy / issuer-visible badge or courier witness / immutable object ref / receiver-local bind / later revival designator / receipt**.

The outside precedents line up nicely:
- Plan 9 says per-process namespace assembly is a real design primitive, but that does not require ViewFS to collapse everything back into path folklore.
- Fuchsia says creator-assembled capability-routed namespaces are practical and can vary by role, identity, and rights.
- systemd says startup-delivered descriptors and narrow restart lockers can be explicit and useful without becoming universal persistent authority.
- UNIX descriptor passing says local cross-process handoff should be an explicit courier act.
- seL4 says badges are attributes of capability copies/sender lanes, not immutable object identity.

That is a very good low-regret seam for ViewFS because the current SlopOS material already leans the right way:
- explicit launch assembly,
- explicit handle-table population,
- explicit namespace/view shaping,
- and explicit portal/document-handle boundaries.

The next thing to steal is **not** one canonical durable-handle scheme.
It is the discipline that:
- startup slot names are not durable paths,
- live copied handles are not immutable object identity,
- issuer/courier witness is not trust verdict,
- local adopted binds are not proof of original delivery shape,
- and receipts/history are not current authority.

Recommended posture:
- keep using SlopOS as evidence that explicit construction beats ambient rediscovery;
- keep durable continuity narrow and optional until SlopOS itself settles more of the surrounding runtime;
- keep portal-mediated imports plural and mediated rather than treating one current sketch as the forever protocol;
- make the shell first-class here with activation sheets, handoff sheets, and copy-lineage drawers so users can actually see the seam.



## 1x. Store membership, synthetic portal/provider views, live handles, and published names deserve a hard seam

This is the next low-regret seam ViewFS should steal from the current SlopOS direction.
The key lesson is not “choose one final object-store and namespace model now.”
It is the smaller observation that a capability-native system can keep these truths separate:
- an object exists locally in the store,
- a portal/provider projects it through a restricted synthetic view,
- one actor holds a live handle now,
- one process view publishes it under one current name,
- and receipts/history describe how those things happened.

The external precedents line up unusually well here:
- Plan 9 keeps per-process namespaces fundamental rather than treating one global path tree as object essence.
- Fuchsia sharpens that further by letting components consume namespaces they are given and separately publish objects through an outgoing directory.
- Fuchsia dictionary capabilities are also a useful reminder that grouped authority can be aggregated, nested, retrieved, and extended without turning grouping into publication.
- XDG Request / FileChooser / Documents sharpen the mediated-view lesson: user interaction lives in request objects, selected files may be surfaced through a restricted synthetic document view, and that still is not the same thing as native publication in every current app view.

What to steal:
- **publish-here last** as a product instinct: a chooser/import result should often land in staging before it becomes one current local bind;
- **synthetic-view badges** so `portal view`, `provider projection`, `published here`, `stored only`, and `history only` are different shell truths;
- **published-name ledgers** so one object can show several current publication/projection sites without pretending one path string is the object;
- **same-object multi-view diffs** so shells can compare object ref, projection site, live-handle state, and current publication honestly.

What not to freeze yet:
- whether early synthetic views are shell-owned, service-owned, launcher-owned, or lower-level runtime objects;
- whether publication ledgers are queryable first-class objects, shell-owned chrome, or both;
- whether later overlay/search semantics ever share the same publication vocabulary.

The practical upshot is simple:
do not let ViewFS’s nicest portal and path affordances quietly collapse **object-store truth**, **projection truth**, **current authority**, and **current publication** into one fake universal file identity.

## Revision 084: explicit-handle truth, rooted compat debt, and ambient escape receipts

One more low-regret seam is worth freezing now while SlopOS is still in design: **direct current-handle opens**, **rooted compat pathwalks inside already-held roots/views**, **portal-mediated grants/projections**, **ambient host escapes**, and **receipts/history** should stay visibly distinct.

Why this lines up with the current SlopOS direction:
- `capshell-filesystem-posture-v0.md` is strongest exactly where it refuses an ambient host-filesystem baseline.
- `capshell-cwd-root-posture-v0.md` and `view-namespace-posture-v0.md` already lean toward creator-populated roots/views rather than rediscovery.
- `document-portal-posture-v0.md` already leans toward explicit mediated document grants rather than fake native reopen folklore.
- `rfcs/0115-capability-safe-shell-and-automation.md` already implies that shell UX must expose the real authority story instead of hiding it.

That means ViewFS does **not** need SlopOS to settle one final object store or portal substrate before it can freeze a useful discipline:
- if a process already holds a live handle, say so;
- if it only walked inside an already-held root/view, say so;
- if a mediator minted or projected access, say so;
- if bring-up still used an ambient host escape, make it loud and receipted.

### Cross-datacube echo worth stealing
Two sibling-cube habits strengthen this conclusion:
- **Helm** keeps settlement, visibility, and durable outcome truth from collapsing into one fake `done` bit.
- **Steward** keeps lifecycle/control truth legible through semantic side channels instead of trusting PTY folklore.

That combination is useful here.
ViewFS should keep `opened successfully` from collapsing direct authority, compat debt, mediation, and history into one fake `it worked` noun.

### Shell and terminal ideas worth stealing
- **safe-open ladders** so the user can see the winning lane: `handle`, `rooted`, `portal`, `ambient`;
- **ambient-debt sirens** so host-global fallbacks are visible, searchable, and replaceable;
- **route provenance drawers** that explain root/view, mediator, publication, and resulting receipt;
- **replace-this-debt buttons** that turn a one-off ambient success into a cleaner keep-handle / bind-root / publish-here / ask-portal flow next time.

### What not to freeze yet
- one universal rooted compat walker API;
- whether early ambient escapes are blocked, developer-only, or policy-gated in every runtime;
- whether portal results usually land as direct handles, synthetic views, publish-later candidates, or some mix;
- whether object-store lookup and rooted compat designation ever share one concrete API surface.


## Revision 085: discoverability, enumeration, exact-name reachability, and fit notes

Another low-regret seam is worth freezing while SlopOS is still in design: **direct current authority**, **exact-name reachability inside a held root/view**, **enumeration/listability**, **mediated suggestion or fit notes**, and **receipts/history** should stay visibly distinct.

Why this lines up with the current SlopOS direction:
- `mcp-completion-import-boundary-v0.md` already says provider-suggested values are only suggestion mechanics, not selector/default/workflow truth.
- `mcp-roots-import-boundary-v0.md` and `mcp-resource-import-boundary-v0.md` already refuse to turn imported hints into filesystem/document grants or current-state oracles.
- `namecert-search-boundary-v0.md` already says search should stay closed-world over explicit bundle sets rather than regrowing ambient discovery.
- `view-namespace-posture-v0.md` and `capmode-posture-v0.md` already lean toward explicit view assembly instead of ambient browse/global lookup.

That means ViewFS does **not** need SlopOS to settle one final object store, explorer, or search substrate before it can freeze a useful discipline:
- if the actor already holds live authority, say so;
- if the actor only succeeded because it knew one exact child name under a held root/view, say so;
- if the container was genuinely browseable/listable, say so;
- if a portal/helper/index merely suggested a candidate or fit class, say so;
- and receipt which truth actually held.

### Cross-datacube echo worth stealing
Two sibling-cube habits strengthen this conclusion:
- **Foundry** keeps discovered sidecars, compatibility proof, overlay gates, and durable outcomes from collapsing into one flattened metadata story.
- **Harbor** keeps discovery, trust, continuation, and aftermath on different rails instead of letting one callback/search hit mean everything.

That combination is useful here.
ViewFS should keep `shown in search`, `listable here`, `known name under root`, and `opened now` from collapsing into one fake `visible therefore usable` noun.

### Shell and terminal ideas worth stealing
- **dark directories** so `exact name works` and `browse is gated` can both be true visibly;
- **known-name chips** so exact-name success is transcript-visible;
- **browse gates** that let users cross a disclosure boundary deliberately instead of silently;
- **fit sheets** that explain `preferred`, `acceptable`, `advanced`, or `history only`;
- **search-result dimmers** so helper/index/history hits never masquerade as current local authority.

### What not to freeze yet
- one universal directory-rights lattice;
- one universal search/index owner;
- whether exact-name reachability is app-visible or mostly a runtime/shell seam;
- whether provider fit-quality vocabularies ever get normalized globally.

## Revision 086: presence adverts, readiness claims, and current authority are different classes

Another low-regret seam is worth freezing while SlopOS is still in design: **provider/catalog presence**, **freshness-scoped readiness**, **grant-needed posture**, **direct current authority**, and **receipts/history** should stay visibly distinct.

Why this lines up with the current SlopOS direction:
- `mcp-roots-import-boundary-v0.md`, `mcp-resource-import-boundary-v0.md`, and `mcp-prompt-import-boundary-v0.md` already refuse to let imported catalogs quietly become filesystem/document/workflow truth.
- `mcp-completion-import-boundary-v0.md` already says suggested values are suggestion mechanics only, not selector/default/current-state truth.
- `connector-tool-policy-boundary-v0.md` already refuses to equate a visible tool catalog with portable admin or enabled-tool truth.
- Steward’s `presence-advertisement`, `freshness decay`, and `chrome lane` pressure is a strong companion reminder that `advertised`, `ready`, `held`, and `history only` are different user-facing truths.

The outside precedents line up well too:
- Fuchsia reminds us that components consume one namespace and separately publish outgoing/exposed capabilities; publication/discoverability is not the same as a client already holding a handle.
- MCP roots/resources/prompts/tools remind us that dynamic helper catalogs and `listChanged` notifications are valuable, but they still do not settle current authority or current local filesystem truth.
- DNS-SD reminds us that discovering a named service instance is a browse/resolve surface, not a proof that we can act through it yet.
- Kubernetes EndpointSlice reminds us that visibility is not one bit: `ready`, `serving`, and `terminating` can differ, which is exactly the kind of freshness-scoped honesty ViewFS should steal.

What to steal:
- **presence halos** around helper/provider rows instead of one fake `available` badge;
- **readiness lamps** that decay visibly to `last known` and `history only`;
- **withdrawn ghosts** so disappeared adverts remain explainable for a short horizon;
- **grant-needed ladders** that make `ask portal`, `rebind`, `reacquire`, or `receipt only` explicit;
- **advert ledgers** that preserve who advertised something, under what freshness window, and whether a later grant was actually minted.

What not to freeze yet:
- one universal advert protocol;
- one universal readiness vocabulary for every provider/object kind;
- whether helper/provider presence is pushed, pulled, or query-only in Phase 1;
- whether every provider even has a meaningful `ready` state distinct from `advertised`.


### 1j. Provider-ready is still not local-realized

Another especially useful seam is **provider-ready truth versus local realization truth**.

The best lesson here is not `copy Nix` or `copy Git partial clone`.
It is the smaller observation that a system can know:
- a provider claims it can supply something later,
- one repair/rebind/reacquire step is still owed,
- and the thing still does not exist locally yet.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `make local`, `still provider-owned`, `substitutable`, `repair owed`, and `local now` as different truths.

What to steal:
- provider-ready should be a first-class state that is stronger than mere advert/discovery but weaker than local realization;
- repair/reacquire obligations should stay visible rather than hiding inside a green `available` badge;
- local realization should stay separate from current live-handle possession;
- shell chrome should be able to say `provider-ready`, `reacquire needed`, `realizing`, `local now`, `held now`, or `history only`;
- imports and resumed work should default to honest ladders rather than pretending provider-backed utility is already local truth.

What not to freeze yet:
- the exact fetch/substitute/reacquire owner (shell, portal, supervisor, or other service);
- whether realization always means exact local byte copy versus some narrower locally backed projection;
- whether provider-ready claims are advisory or audited enough to drive background prefetch by default;
- any assumption that a remembered or provider-ready thing is durable offline truth without explicit realization.

## Revision 088: redeemable claims, holder-bound grants, and spent traces

This pass says ViewFS should distinguish **claim/redeem authority**, **holder-bound live grants**, **freely passable live handles**, and **spent historical traces** instead of flattening them into one `token` or `capability` noun.
That fits SlopOS surprisingly well.

SlopOS is already pushing imported auth-adjacent material such as PKCE and DPoP toward **provider-local binding machinery** instead of portable proof folklore.
Steward is separately exploring compact **consumable-grant** and **holder-bound-grant** posture.
Together, those sibling signals suggest a low-regret direction for ViewFS: standardize the shell vocabulary for redemption, current-holder proof, passability, and spentness now, but leave broader object-store, ticket-wallet, and portable-proof decisions open.

The shell implications are exciting.
Instead of generic `open token` or `resume token` language, a ViewFS transcript could say `claim`, `redeem once`, `holder proof needed`, `live handle passable now`, or `spent ghost`.
That would make portal-mediated imports, one-shot approvals, and replay-sensitive actions much easier to understand.


### 1k. Current possession is still not current invocability

Another especially useful seam is **current possession versus current invocability**.

The best lesson here is not `copy an assurance registry` or `copy one auth framework`.
It is the smaller observation that a system can know:
- one object is local now,
- one handle or holder-bound grant is held now,
- and the action still is **not invokable now** because freshness, stronger authentication, or immediate local presence is still missing.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `held`, `too old for this action`, `step-up needed`, `presence needed`, `invokable now`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `mcp-step-up-auth-import-boundary-v0.md` already refuses to turn imported `insufficient_user_authentication`, `acr_values`, `max_age`, `acr`, `auth_time`, or `amr` into one portable assurance ledger, recent-login oracle, or durable account/session truth.
- `cryptosvc-interactive-auth-boundary-v0.md` already refuses to turn provider-local PIN / biometric / user-presence / unlock mechanics into one generic app-facing portable unlock plane.
- Harbor's new proximity/timebound work is a strong nearby reminder that some real flows are context-gated even when the artifact itself is perfectly real.

What to steal:
- **why-not-now drawers** that distinguish missing authority from stale recency from unsatisfied local presence;
- **step-up ladders** that make `held` and `invokable` visibly different;
- **recency shutters** that decay honestly without pretending the underlying handle vanished;
- **presence pins** for touch/verify/auth-now style gates;
- **satisfaction ghosts** that remember one satisfied or failed challenge without turning it into timeless authority.

What not to freeze yet:
- one universal assurance taxonomy across providers;
- whether any successful step-up opens a reusable short window or only one immediate action;
- whether local presence is shell-owned, provider-owned, authagent-owned, or split;
- any assumption that current possession automatically implies current invocability.


### 1l. Live possession is still not standing-watch good status

Another especially useful seam is **live possession versus later watch/status truth**.

The best lesson here is not `copy OCSP` or `copy token introspection` or `copy TUF`.
It is the smaller observation that a system can know:
- one subject is still local or held now,
- one smaller later status carrier says something new about it,
- one local receiver chooses whether to suspend, quarantine, refresh, or ignore,
- and one successor/replacement may be available without having been adopted yet.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `held`, `watch current`, `watch stale`, `suspended here`, `quarantined here`, `refresh available`, `successor required`, `invokable now`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `attention-durable-status-boundary-v0.md` already refuses to let transient status chrome become durable truth.
- `mcp-step-up-auth-import-boundary-v0.md` already refuses to let provider-local auth/status context silently become one portable generic verdict plane.
- Ward’s new status-carrier / suspension-rail / attenuation-event work is a strong nearby reminder that later status inputs and local spend consequence are different objects.
- Harbor’s route/admission/outcome discipline reinforces that one later signal may narrow local consequence without replacing base route or base object truth.

What to steal:
- **watch braids** that show base truth, status source, local stance, and current hold posture side by side;
- **hold rails** that distinguish reversible suspension from harder quarantine or final withdrawal;
- **successor lanterns** for `replacement exists` versus `replacement adopted`;
- **stale-watch fog** that lets standing-watch confidence decay honestly without pretending possession vanished;
- **history ghosts** that preserve prior good-standing or hold transitions without reviving them as present truth.

What not to freeze yet:
- one universal watch transport or status-carrier schema;
- one universal reversible/terminal hold taxonomy;
- whether successor refresh is shell-owned, portal-owned, provider-owned, or some shared service;
- any assumption that a held object, handle, or grant automatically implies standing-watch good status.


### 1m. Holding something is still not the same thing as being able to lend it live

Another especially useful seam is **current possession versus local duplication versus live lend versus weaker representation export**.

The best lesson here is not `copy one IPC ABI` or `copy one desktop share sheet`.
It is the smaller observation that a system can know:
- one subject is held here now,
- it may be duplicable locally,
- it may or may not be lendable live across one explicit courier lane,
- and even when live lend fails a weaker representation export may still be available.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `held`, `duplicate local`, `lend live`, `lend narrowed`, `bytes only`, `projected doc`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `transfer-portal-posture-v0.md` already keeps clipboard/drag-drop transfer manual, sink-pull, and one-shot rather than ambient.
- `document-portal-posture-v0.md` and nearby document/import seams already resist the temptation to call projected document export the same thing as live capability handoff.
- `seal-posture-v0.md` already reinforces that attenuation and narrowing should be explicit instead of silently reversible.
- Schell and Helm are both converging on stronger `what exactly crossed the boundary?` honesty in their own companion lanes, which is a useful sibling pressure toward the same sender-side distinction.

What to steal:
- **lend ladders** instead of one fake universal share action;
- **lane-fit badges** that say whether the current strongest route is local duplicate, live lend, portal export, or bytes-only;
- **bytes-only fallback chips** when exact live handoff is impossible;
- **same-object versus new-representation drawers** so the shell can explain what the receiver really gets;
- **share receipts** that preserve exact lane truth rather than one flattering `sent` row.

What not to freeze yet:
- one universal live-lend transport;
- one universal representation-export taxonomy;
- whether any live-lend lane is cross-machine in Phase 1;
- whether terminal-native transfer is core ViewFS or a shell/terminal adjunct.

### 1n. Borrowed foreign-backed usability is still not projected locality or true local realization

Another especially useful seam is **foreign-backed borrow versus wrapper/relay attach versus projected local view versus true local realization**.

The best lesson here is not `copy one document provider API` or `copy one desktop portal`.
It is the smaller observation that a system can know:
- one thing is usable now through another provider or mediator,
- one wrapper or relay made it attachable in this pane/process,
- one scoped local projected view exists,
- and none of that yet means the object truly lives here as local object-store truth.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `borrowed`, `wrapped here`, `projected here`, `materialized here`, `local object`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `document-portal-posture-v0.md` already refuses to turn mediated document access into one ambient native path story.
- `import-to-docref-boundary-v0.md` already resists flattening imported references into immediate local durable objecthood.
- `view-namespace-posture-v0.md` and `capshell-cwd-root-posture-v0.md` already make room for explicit local attachment/publication acts instead of one global mount folklore.
- Foundry's foreign-cell / borrowed-handle / restore-reacquire work is strong nearby pressure toward the same humility about foreign-backed utility.

What to steal:
- **borrow rails** that keep provider-backed use first-class instead of second-class;
- **projection badges** for portal/provider-scoped views;
- **provider-owned halos** plus **dataless/materialized lamps** so locality remains inspectable;
- **make-here ladders** that keep `keep borrowing`, `project here`, and `localize here` as visibly different next steps;
- **why-not-adopt drawers** for `provider gone`, `wrapper needed`, `projection only`, or `history only`.

What not to freeze yet:
- one universal wrapper/relay ABI;
- one final projected-import taxonomy;
- whether localization always means exact copy, local mirror, or object-store commit;
- whether provider-backed borrows should survive relaunch/offline by default.



### 1o. Route capsules are still not authority sidecars or sink-held consequences

Another especially useful seam is **typed route capsule versus authority sidecar versus sink-side acceptance/bind/import**.

The best lesson here is not `copy one share sheet` or `copy one portal packet`.
It is the smaller observation that a system can know:
- one typed route or plumb envelope exists,
- one optional sidecar narrows or explains that route,
- one sink actually accepted only a representation, projection, bind, or localization,
- and one receipt later remembers all of that without reviving it as current authority.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `designation only`, `route + sidecar`, `accepted representation`, `projected here`, `bound here`, `localized here`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `rfcs/0117-plumb-messages-and-cli-intents.md` already keeps CH-PLUMBMSG non-authoritative and refuses to turn route envelopes into covert capability lanes.
- `rfcs/0116-capability-wallets.md` already keeps wallet artifacts descriptive and non-resolving.
- `rfcs/0089-document-portal-and-durable-file-handles.md` and `rfcs/0094-transfer-portal-and-typed-payload-leases.md` already keep request-local routing/transfer state separate from final grants or accepted payload consequence.
- Foundry’s newer sidecar and adoption discipline is a strong sibling reminder that attached explanatory material and final local adoption are different objects.

What to steal:
- **route slips** that remain cheap to inspect and safe to copy because they are `designation only`;
- **authority sidecar chips** for wallet digests, URI-grant candidates, representation offers, fit notes, or proof-needed posture;
- **sink trays** that show the exact consequence per receiving pane/process;
- **dry-run route diffs** so the shell can compare route-only versus route-plus-sidecar before commit;
- **post-route bind cards** so receipts explain what the sink really accepted instead of one flattering `opened/shared` story.

What not to freeze yet:
- one universal route-envelope schema;
- one universal sidecar taxonomy;
- whether any sidecar may carry narrowly live authority in Phase 1;
- one final sink-binding vocabulary shared by representation transfer, projection, bind, and localization.

### 1p. Borrowed authority is still not caller context or deny-only provenance

Another especially useful seam is **privilege bracket versus borrowed authority versus call-chain context versus deny-only provenance**.

The best lesson here is not `copy one async-local API` or `copy one tracing context carrier`.
It is the smaller observation that a system can know:
- one helper is inside one bounded privileged block,
- one exact handle or authority class is being borrowed inside that block,
- one bounded caller chain explains who asked,
- and one provenance-derived veto may narrow or block one route without becoming authority.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `inside borrowed-authority bracket`, `borrowed handles active`, `caller context only`, `vetoed by helper chain`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `rfcs/0118-privilege-bracketing-and-call-chain-contexts.md` already argues that internal helper/library authority should be bracketed instead of quietly ambient, and that call-chain metadata should stay bounded and non-authoritative.
- `rfcs/0115-capability-safe-shell-and-automation.md` already pushes shell/automation design toward explicit capability passing instead of helper folklore.
- Harbor’s issuer/origin-card pressure and Foundry’s explicit helper residue both reinforce the same product lesson: provenance is useful truth, but it is not the same thing as live authority.

What to steal:
- **bracket rails** instead of one vague helper mode;
- **caller badges** and **who-asked drawers** that preserve provenance without laundering it into capability;
- **borrowed-authority drawers** so helper action can name real current handles or capability classes;
- **deny-only shutters** for `untrusted plugin in chain` or `preview-pane origin` vetoes;
- **deputy-fog warnings** when one helper tries to fall back to ambient global/task-local state.

What not to freeze yet:
- one final call-chain schema;
- one final privilege-bracket API or carrier;
- whether any caller-chain material crosses machine/user boundaries;
- one final deny-only rule vocabulary.

### 1q. Direct native fit is still not adapter-backed use or translated representation

Another especially useful seam is **native attach versus adapted attach versus coerced representation versus local realization**.

The best lesson here is not `copy one wrapper ABI` or `copy one file-provider API`.
It is the smaller observation that a system can know:
- one receiver lane is directly native for the current pane/process/tool,
- one wrapper or relay is making the thing usable here,
- one alternate representation is available even when same-object attach is not,
- and one stronger local/native state could be made explicitly if needed.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `native`, `adapter`, `relay`, `coerced`, `make local for native`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `view-namespace-posture-v0.md` already leaves room for explicit receiver-local attachment/publication acts instead of one global path truth.
- `document-portal-posture-v0.md` already refuses to equate mediated/projection access with ambient native filehood.
- `import-to-docref-boundary-v0.md` already resists flattening imported references into immediate durable local objecthood.
- Foundry’s foreign-cell / borrowed-handle posture and Harbor’s consequence/adoption discipline both add sibling pressure toward explicit receiver-side fit/fidelity truth instead of one fake `opened` story.

What to steal:
- **attach-mode badges** that distinguish `native`, `adapter`, `relay`, `coerced`, `localized`, and `history only`;
- **adapter veils** so the shell can explain what glue is actually in the path;
- **virtuality lamps** when the current best lane is one alternate representation rather than same-object attach;
- **same-object versus translated drawers** before edit/send/import decisions;
- **make-local-for-native ladders** when stronger local/native semantics are desired.

What not to freeze yet:
- one universal wrapper/relay ABI;
- one final translated-representation taxonomy;
- whether some translated lanes become durable caches by default;
- whether native attach is required for any Phase 1 workflows.



### 1m. Clean shell delight is still not the same thing as ambient startup files or project-local hooks

One more especially useful seam from current SlopOS material is **built-in shell baseline versus explicit customization bundle versus startup/profile code versus project-local activation hook**.

The best lesson here is not “never customize shells.”
It is the smaller observation that a system can:
- ship a rich built-in shell baseline,
- still allow explicit reviewed user-owned customization bundles,
- still refuse to treat host/user startup files as reviewed baseline truth,
- still keep project-local activation hooks behind a separate review/trust gate,
- and only then produce one live interactive session.

That is a perfect low-regret lesson for ViewFS because SlopOS already refuses implicit rc/profile loading and prompt/cwd code-loading in the reviewed baseline, while outside precedents like direnv and VS Code show that project-local activation really does deserve a separate allow/re-allow/trust posture.

What to steal:
- built-in shell affordances should stay product-native and explainable without ambient dotfile folklore;
- useful ambient snippets should be promotable into explicit reviewed customization bundles;
- project-local activation hooks should get explicit pending/allowed/denied/stale states;
- prompt provenance should be inspectable so users can see whether behavior came from built-in code, a reviewed bundle, a startup file, or one project hook.

What not to freeze yet:
- the exact customization-bundle schema,
- whether any legacy rc/profile import path exists in Phase 1,
- the final scope lattice for project-hook approval,
- or how portable bundle execution is across host shells/runtimes.


### 1r. Command-surface honesty is still not the same thing as startup honesty

Another especially useful seam from current SlopOS material is **built-in verb versus lexical expansion versus semantic command layer versus key action versus external launch**.

The best lesson here is not “copy one shell” or “freeze one shell language.”
It is the smaller observation that a system can:
- ship product-native verbs,
- still allow typed lexical expansions,
- still allow explicit overlay/module/custom-command layers,
- still offer keybound widgets and command-palette actions,
- still launch exact external executables or script entries,
- and only then produce one transcript/history row.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `built-in`, `expanded`, `overlay`, `widget`, `external`, and `history only` as different truths if it wants to stay capability-honest and awesome.

Why this lines up with current SlopOS direction:
- SlopOS capshell material already refuses ambient shell folklore and keeps launch meaning structured instead of hiding it behind one string.
- Foundry's config-layer and overlay-gate work is strong sibling pressure toward explicit layer activation instead of one hidden active command soup.
- The new shell-startup work in ViewFS already separated baseline/bundle/profile/hook truth, which makes command-surface truth the natural next shell seam.

What to steal:
- **verb provenance cards** so the shell can explain which layer won;
- **abbr gutters** so lexical expansion stays visible before semantic resolution;
- **overlay racks** for active semantic command layers;
- **key-table lamps** for modal interaction layers;
- **which ladders** that compare built-in, overlay, custom, and external winners without folklore.

What not to freeze yet:
- the exact alias/abbreviation/snippet object model;
- one universal overlay/module schema;
- whether every key action can promote into one typed verb;
- or one final command-palette wire format.



### 1s. Smart shell editing is still not the same thing as current packet truth

Another especially useful seam for current SlopOS-adjacent work is **editable buffer versus parsed structure versus advisory diagnostics versus compiled packet versus prepared action**.

The best lesson here is not `pick one parser now`.
It is the smaller observation that a system can:
- keep current typed text mutable,
- still expose rich parse/highlight structure,
- still surface shell-specific diagnostics and hints,
- still compile one stronger pane-local packet,
- still require one later review/launch step,
- and only then produce one history row.

That is a perfect low-regret lesson for ViewFS because SlopOS is still in design and therefore still has time to freeze UX honesty without freezing one parser or diagnostic substrate.

What to steal:
- **parse lenses** instead of fake green-ready chrome;
- **diagnostic rails** instead of one generic red underline;
- **packet gutters** that only appear after current pane-local bind/compile;
- **compile diff cards** when identical text means different packets in different panes.

What not to freeze yet:
- one final grammar/parser,
- one final lint engine,
- one final token taxonomy,
- or one final packet representation.

### 1g. Room identity versus current view versus child spawn truth should stay separate
Another especially useful seam to steal from the current SlopOS direction is **room honesty above namespace honesty**.

SlopOS already has enough ingredients for this without settling the final shell:
- explicit views / namespaces rather than one ambient filesystem (`view-namespace-posture-v0.md`),
- capability-safe shell posture (`rfcs/0115-capability-safe-shell-and-automation.md`),
- descriptive wallets (`rfcs/0116-capability-wallets.md`),
- typed plumb messages (`rfcs/0117-plumb-messages-and-cli-intents.md`),
- and portal/document-handle import lanes (`rfcs/0089-document-portal-and-durable-file-handles.md`).

What to steal:
- the room a human is sitting in should be a first-class thing distinct from the exact view bound there now;
- child/split/helper inheritance posture should stay a separate question from both current view and current receipts;
- a prepared child spawn/import recipe should be inspectable and saveable without pretending a child already exists;
- child-received imports should be reported as current child truth instead of getting laundered through the parent room name or through recipe chrome;
- room restore should restore explanation and layout first, and only then rebind fresh authority if asked.

What not to freeze yet:
- the exact room model (tab/pane/notebook/helper/service) or whether those all share one type;
- the exact spawn-recipe schema or whether it is wallet-shaped, plumb-shaped, or something thinner;
- whether room identity is shell-owned, terminal-owned, supervisor-owned, or split;
- any assumption that a saved room or recipe automatically implies durable authority, durable reopen, or child clonability.

### 1t. Namespace plans, live room bindings, portal sessions, and local overlays should stay separate
Another especially useful seam for current SlopOS-adjacent work is **namespace planning versus live room binding versus portal/session truth versus local-only overlay residue**.

Why this is high value now:
- SlopOS already has explicit view/namespace posture and capability-safe shell posture, so ViewFS does not need to flatten room state into one ambient cwd myth.
- SlopOS already has document-portal and durable-handle posture, so request/session lifetime can stay different from current binds.
- Helm provides strong sibling pressure for a **local overlay** contract: useful, derivative, scoped, cheap to discard, and forbidden from traveling by surprise.
- Schell provides strong sibling pressure for **anchor death** honesty: if an old continuity point died, say what killed it instead of flattering the user with fake resume.

What to steal:
- **namespace switchboards** that separate `planned`, `live now`, `pending session`, `local overlay`, and `receipt only`;
- **overlay racks** that make local-only residue visible and clearable;
- **import session strips** that keep request/session truth different from live bind truth;
- **anchor death cards** and **reset-scope chips** when old switch/import anchors stop being exact.

What not to freeze yet:
- whether namespace plans are shell-owned, terminal-owned, or portable store objects;
- one universal overlay object model;
- whether a durable access list item becomes a first-class ViewFS object;
- one final session/state wire format.

### 1k. Exact wake kits, restart lockers, and namespace pins are worth stealing, but only as a narrow middle seam

Another especially useful middle shape is **startup-delivered exact kits plus manager-held restart lockers plus explicit namespace pins**.

The best lesson here is not "make persistence universal" and not "make every room magically restorable."
It is the smaller observation that a system can:
- hand one child or room exact ready resources at start time,
- let a supervisor/manager preserve some exact live resources across a controlled restart,
- keep some namespace/view basis alive through a narrower pin,
- and still keep all of that visibly weaker than durable reopen anchors or universal persistent graphs.

What to steal:
- startup should prefer handed-in exact kits over rediscovery by ambient paths, names, or latest-state folklore;
- restart lockers should stay explicit, typed, inspectable, and narrower than durable reopen or persistent roots;
- namespace pins should remain honest liveness facts rather than silently laundering into `live room` truth;
- shell chrome should be able to say `warm exact`, `warm partial`, `cold repair`, `cold fresh`, `pin present`, or `receipt only` instead of one vague `restored` promise;
- partial/degraded warm starts should confess what was missing instead of flattering the operator.

What not to freeze yet:
- whether restart lockers are shell-owned, supervisor-owned, service-manager-owned, or split;
- whether namespace pins are OS handles, provider-held tickets, or another local keepalive primitive;
- whether any locker survives reboot or only controlled restart;
- any assumption that a namespace pin or restart locker implies durable authority, durable naming, or durable store membership.


### 1u. Live room bindings, provider currentness, shell semantic epochs, and repair offers should stay on different seams

Another especially useful seam is **current live bind versus currentness witness versus shell semantic footing versus bounded repair offer versus durable receipt**.

The best lesson here is not `add more persistence`.
It is the smaller observation that a system can:
- hold one exact current binding in a room now,
- keep a separate provider-side witness about whether that binding is still current/revoked/replaced/expired,
- admit that the shell has moved into a newer semantic epoch or hop path so old anchors are no longer exact enough,
- and surface one bounded repair offer without pretending the old truth silently fixed itself.

What to steal:
- provider-side currentness and expiry should stay explicit instead of dissolving into generic I/O failure;
- shell semantic epochs and hop lineage should stay explicit instead of preserving stale certainty after restart/resync/remote change;
- repair should usually appear as one visible offer card or ladder rung rather than a hidden magic fix;
- receipts should remember witness refresh, stale refusal, reconsent, rebind, or make-local moves without reviving current authority.

What not to freeze yet:
- the final witness schema for provider currentness;
- whether semantic epochs are pane-local, room-local, or hop-local;
- whether repair offers are provider-authored, shell-authored, or assembled from several seams;
- any assumption that one `available` or `stale` bit can honestly represent all of this.


### 1v. Renewal windows, retry advice, and repair gates should stay separate from live binds and durable anchors

Another especially useful seam is **current live bind versus currentness witness versus renewal window versus retry advice versus repair gate versus durable receipt**.

The best lesson here is not `add more persistence`.
It is the smaller observation that a system can:
- hold one exact current binding in a room now,
- keep a separate provider-side witness about whether that binding is still current/revoked/replaced/expired,
- allow one compact renew-or-expire budget for that same live claim,
- surface one exact earliest sensible follow-up time when a retry is premature,
- and stop automatic help after repeated misses without pretending the room forgot why.

What to steal:
- explicit renewal/lease windows rather than sticky `probably still alive` folklore;
- tiny retry clocks rather than giant retry-policy mythology;
- explicit repair gates after repeated misses or repeated stale follow-up;
- shell chrome that can say `renewed through`, `retry after`, `cooling down`, `manual clear required`, or `receipt only`.

What not to freeze yet:
- one final renewal protocol,
- one final retry-budget grammar,
- whether repair gates are room-owned, issuer-owned, or supervisor-owned,
- or any assumption that timing hints and quieting state share one object with durable anchors.


### 1w. Keep-warm presence, restore intent, and deferred repair should stay separate
This is another excellent design instinct in current SlopOS.

`background-lease-posture-v0.md` already keeps `background` and `autostart` as different grant bits, prefers jobs for deferred maintenance/retry loops, and refuses silent widening on renewal. `background-request-state-posture-v0.md` then sharpens the seam again by saying requester-chosen request identity is not current portal-owned grant state.

That suggests a very healthy ViewFS posture:
- keep **live room binding now** separate from **room visibility state**;
- keep **background keep-warm authority** separate from **restore-at-login intent**;
- keep both separate again from **deferred repair jobs**;
- and keep receipts/history explanatory rather than authority-bearing.

The shell move is excellent too:
- warmth rails for `foreground`, `warming`, `background serving`, `draining`, or `history only`;
- login lanterns for `restore allowed`, `restore proposed`, `restore denied`, or `reconsent needed`;
- defer drawers whenever the honest next move is a queued repair job rather than pretending the room/import is still live.

What not to freeze yet:
- one final keep-warm lease carrier;
- one final restore/autostart substrate;
- whether deferred repair jobs are shell-local, portal-local, or supervisor-local;
- or one final lifecycle-status enum for room chrome.

## Revision 106 synthesis: attention is not liveness, and transient attention is not durable truth
SlopOS looks especially right on one subtle seam that ViewFS should steal now rather than later:
- `attention-lease-posture-v0.md` refuses to let `urgent` quietly become a broad authority lane;
- `attention-durable-status-boundary-v0.md` refuses to let transient status chrome become durable consequence truth;
- `background-lease-posture-v0.md` and `background-request-state-posture-v0.md` separately keep `live/warm`, `request identity`, and `current portal state` from collapsing into one flattering continuity story.

That strongly suggests the next ViewFS shell/object-store seam should keep:
- **live room binding** separate from **attention cue**;
- **attention cue** separate from **interrupt grade**;
- **interrupt grade** separate from **quiet/suppression posture**;
- **transient cue/suppression posture** separate from **durable ack/follow-up row**;
- and all of those separate from **receipt/history**.

What to steal now:
- attention pips for `activity`, `bell`, `silence`, `follow-up unread`, or `receipt only`;
- interrupt ladders for `badge only`, `banner candidate`, `urgent request`, `urgent but clamped`, or `critical requires separate grant`;
- quiet shutters for focus/presentation/workspace hush posture;
- durable ack ledgers for unresolved follow-up after the transient cue is gone.

What not to freeze yet:
- one final inbox/history object model;
- one final urgent/critical entitlement path;
- whether quiet posture is shell-local, terminal-local, or policy-local;
- whether ack rows and receipts share storage or only share chrome.

### 1x. Summon cues, activation batons, actual foreground turns, and secure-entry truth should stay separate
Use:
- `attention-lease-posture-v0.md`
- `tool-ui-display-surface-boundary-v0.md`
- `uicap-scope-posture-v0.md`
- `capshell-job-control-posture-v0.md`
- `openuri-activation-control-boundary-v0.md`

Implication:
- SlopOS already gives ViewFS enough explicit attention/display/trusted-UI posture that ViewFS can keep `live room binding`, `summon cue`, `activation baton`, `foreground turn`, `secure-entry gate`, and `receipt only` on different seams without inventing a fake general focus object;
- host-owned display changes should stay presentation choreography rather than a hidden portable foreground plane;
- trusted-entry should stay a narrower, separately visible mode rather than inheriting from `frontmost` or `fullscreen`;
- shell chrome should be able to say `surface me`, `raise allowed`, `front now`, `trusted path active`, or `history only` instead of one vague `focused` glow.


### 1z. Observe mirrors, automation leases, synthetic input lanes, and secure-entry exclusions should stay separate
Use:
- `rfcs/0080-capability-mediated-ui-compositor-and-secure-attention.md`
- `rfcs/0099-accessibility-and-automation-leases.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `uicap-scope-posture-v0.md`
- `tool-ui-display-surface-boundary-v0.md`

Implication:
- SlopOS already gives ViewFS enough explicit accessibility/automation/trusted-UI posture that ViewFS can keep `live room binding`, `observe mirror`, `automation lease`, `synthetic input lane`, `secure-entry exclusion`, and `receipt only` on different seams without inventing a fake universal automation object;
- observe-only posture should remain the expected default shape for assistive review and shell-visible inspection, while injection stays a stronger explicitly separated lane;
- secure-entry / secure-input posture should be allowed to redact mirrors and clamp synthetic input without rewriting room identity, foreground truth, or durable history;
- shell chrome should be able to say `semantic mirror`, `screen mirror`, `observe only`, `inject allowed`, `mirror redacted`, `input blocked`, or `history only` instead of one vague `automation active` glow.

What to steal now:
- mirror strips for `semantic`, `screen`, `redacted`, `delayed`, or `history only`;
- rehearsal rails for `would target here` before real injection exists;
- lease chips for `observe only`, `rehearse only`, `inject allowed`, `revoked`, or `expired`;
- secure-entry curtains that explain redaction/clamp truth instead of leaving the user to infer it from failure.

What not to freeze yet:
- one final automation substrate or policy language;
- one final mirror-store schema;
- whether assistive and test automation share a taxonomy;
- whether secure-entry exclusions and secure-entry gates share storage or only share chrome.

### 1u. Projected sites, room publication, and local realization should stay separate
Another especially useful seam for current SlopOS-adjacent work is **provider-backed projection site versus room-local publication alias versus true local realization**.

The best lesson here is not `copy one document-provider API` or `copy one placeholder filesystem`.
It is the smaller observation that a system can know:
- something is reachable here through a scoped provider/portal projection,
- something is separately published in this room under one chosen alias,
- something is later localized or hydrated here,
- and none of those truths automatically imply the others.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `provider projection`, `published here`, `placeholder only`, `hydrated provider-owned`, `local replica`, `local object`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `document-portal-posture-v0.md` already refuses to turn mediated document access into one ambient native path story.
- `import-to-docref-boundary-v0.md` already resists flattening imported references into immediate local durable objecthood.
- `view-namespace-posture-v0.md` and `capshell-cwd-root-posture-v0.md` already leave room for explicit local publication acts instead of one global mount folklore.
- sibling pressure from Harbor label honesty and Foundry adoption residue keeps pushing toward explicit `what crossed`, `what is published`, and `what now lives here` truth.

What to steal:
- **site ledgers** instead of one flattering path chip;
- **provider halos** plus **placeholder/hydrated lamps** so locality stays inspectable;
- **bind-here ladders** that keep `keep projected`, `publish alias`, and `localize here` visibly different;
- **same-object multi-site diffs** for projection/publication/localization comparisons;
- **receipt rows** that remember projection or publication without reviving them as current authority.

What not to freeze yet:
- one universal projection-site substrate;
- one final room-publication ledger schema;
- whether localization means byte copy, replica registration, or object-store commit in Phase 1;
- whether provider-owned placeholder posture survives relaunch/offline by default.

### L76. Cheap clone/overlay posture is permission to separate base, upper, merge, and commit
- SlopOS's roadmap explicitly wants per-component namespaces that are cheap to clone and overlay. That is a strong signal to keep layered-room truth explicit while the datacube is still design-stage.
- REF-OVERLAYFS and REF-PLAN9-UNIONDIRS point to the same lesson: lower/base ordering, writable upper shadow, merged traversal, and hide/create rules are different truths.
- REF-K8S-PROJECTED-VOLUMES points to the same lesson from another angle: a merged directory may be composed from several sources without those sources becoming one local object family.
- REF-APPLE-FILEPROVIDER-PLACEHOLDER, REF-APPLE-FILEPROVIDER-STARTPROVIDING, REF-APPLE-FILEPROVIDER-EVICT, and REF-NIX-REALISE point to the same lesson: placeholder/base posture, later realization/materialization, and later dehydrate/evict/commit acts deserve distinct lanes.
- Therefore: ViewFS should keep live room bind, projected base stack, local upper overlay, merged presentation, publish/commit result, and receipt/history visibly separate.

## More ideas worth stealing
- **stack badges** that tell the truth about `base`, `upper`, `merged`, `whiteout`, `published`, or `receipt only`.
- **whiteout ghosts** so `hidden below` is inspectable instead of silently flattened into delete.
- **creation-target pips** inspired by Plan 9 union creation order.
- **commit ladders** that keep `keep shadow`, `seal upper`, `publish merged`, `make local`, and `push back` as different acts.

### 1w. Caller request context, detached continuation root, deadline, and cancellation should stay separate
Another especially useful seam for current SlopOS-adjacent work is **caller-bound request context versus detached continuation root versus deadline intent versus live cancellation state**.

The best lesson here is not `copy Go context` or `copy one workflow engine`.
It is the smaller observation that a system can know:
- this work is still governed by the original caller,
- this work has a narrowed or inherited patience budget,
- the caller has cancelled or timed out,
- cleanup still runs under a fresh root,
- the provider has detached the work for longer follow-up,
- a status ticket still exists,
- and none of those truths automatically imply the others.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `caller child`, `cleanup root`, `provider continuation`, `deadline fired`, `cancel requested`, `cancel acknowledged`, `watch only`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `rfcs/0105-request-contexts-deadlines-and-cancellation.md` explicitly treats cancellation/deadlines as coordination rather than authority and calls for a fresh root context when work intentionally outlives its caller.
- background/job/automation RFCs already separate permission to continue from current live operation state.
- ACP and receipt posture already resist treating one old status row as a portable current-state oracle.

What to steal now:
- **cutoff lamps** instead of one vague timeout badge;
- **detach-root cards** for `caller child`, `cleanup root`, `provider continuation`, or `watch only`;
- **continue-without-me ladders** that separate `cancel with me`, `let cleanup finish`, `let provider continue`, and `stop watching`;
- **cause drawers** so deadline, parent cancel, and provider-side continuation can all be inspected honestly.

What not to freeze yet:
- one universal request-context schema;
- one universal detach token;
- whether detached cleanup roots and detached long-running roots share storage or only chrome;
- whether cutoff/deadline intent is ever first-class store state beyond witness/receipt surfaces.

### 1y. Creator-seeded rooms, exact child handle tables, and portal imports should stay stronger than path rediscovery
Another especially useful seam in the current SlopOS material is **creator-populated namespace truth versus exact launch-time handle-table truth versus later portal-mediated imports versus any weaker compat pathwalk story**.

The best lesson here is not `copy one host sandbox` or `standardize one path ABI`.
It is the smaller observation that a system can know:
- a room was seeded with one explicit namespace kit,
- a child began with one exact reviewed handle table,
- a later chooser/portal/import act widened the room in one explicit place,
- a compat pathwalk happened under debt-marked constraints,
- and none of those truths automatically imply the others.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `seeded at launch`, `imported later`, `exact child table`, `compat walker used`, `ambient debt`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `capshell-filesystem-posture-v0.md` already refuses to treat a normal host filesystem as the portable launch baseline.
- `capshell-handle-table-posture-v0.md` already refuses to let child authority depend on ambient inheritable-FD folklore.
- `document-portal-posture-v0.md` and `import-to-docref-boundary-v0.md` already resist flattening mediated imports into one invisible native-open story.
- `view-namespace-posture-v0.md` and `capshell-cwd-root-posture-v0.md` already leave room for creator-seeded namespaces and later explicit rebinding instead of one global mount tale.

What to steal now:
- **room seed kits** that describe the namespace fragments, activation slots, and exact handle-table posture a child starts with;
- **ambient-debt sirens** whenever compat pathwalk is used instead of exact-handle routing;
- **import ladders** that keep `import for now`, `bind here`, `keep durable anchor`, and `receipt only` visibly different;
- **exact child-table receipts** so launch review can say what was present at start rather than what the child later discovered.

What not to freeze yet:
- one final namespace-plan wire format;
- one universal slot-addressing scheme for handles;
- whether every portal import defaults to a live room bind, a durable anchor, or only a local receipt;
- any promise that compat pathwalk debt is portable semantic core instead of temporary membrane behavior.

### 1aa. Object blobs, mutable anchors, retention roots, and current live authority should stay separate
Another especially useful seam in the current SlopOS material is **immutable stored object identity versus mutable named anchor/root updates versus retention truth versus current live authority**.

The best lesson here is not `copy Git` or `copy Nix` or `copy one persistent capability machine`.
It is the smaller observation that a system can know:
- these bytes/objects exist in the store,
- this mutable root or anchor now names one current cut,
- this retention root keeps the cut collectible or non-collectible,
- this process still holds a live authority edge now,
- and none of those truths automatically imply the others.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `store object`, `current anchor`, `kept alive`, `collectible if unpinned`, `live handle now`, `stale durable anchor`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `rfcs/0065-orthogonal-persistence-and-capstore.md` already treats CapStore persistence as an explicit power rather than ambient session residue.
- `capstore-commit-schema-v0.md` already models named root updates and rollback/epoch posture separately from ordinary live use.
- sibling pressure from `document-handle-schema-v0.md`, `document-portal-posture-v0.md`, and `capability-lease-schema-v0.md` keeps pushing toward exact distinctions between durable designation, current live reachability, and lease/currentness truth.
- the design-phase state of SlopOS is itself a lesson: the archive is strongest exactly where it refuses to collapse persistence, liveness, and naming into one flattering object model.

What to steal now:
- **root ledgers** that show mutable anchor updates separately from underlying object identity;
- **retention racks** that make `kept alive`, `restart locker`, `durable root`, and `receipt only` visibly different;
- **compare-and-swap anchor updates** instead of silent mutable-head replacement;
- **live-versus-durable honesty lamps** so a shell can confess when it only has a durable anchor or only has current possession.

What not to freeze yet:
- one universal mutable-head family for every ViewFS object kind;
- one final GC/root-retention model for all future stores;
- any promise that a durable anchor implies current invocability now;
- any assumption that retention roots, continuity lockers, and published names should share one storage family before repeated pressure proves it.

## 1ab. Object-home rooms, attached tools, imported binds, published names, and retention roots deserve a hard split
Another especially useful seam is **object home / room seed versus attached tool session versus imported capability bind versus published/local name versus retention root/history**.

The best lesson here is not `copy Sandstorm grains` or `decide every object gets its own room now`.
It is the smaller observation that a system can:
- keep one object-centered room/home/context that organizes current work,
- attach one editor/tool/service session into that room later,
- import or offer one more capability/object through a mediated flow,
- publish one convenient local name inside one namespace,
- separately retain the underlying objects via explicit roots,
- and record the whole story in receipts/history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **capshell namespace**, **view/object split**, **capstore commit**, and **portal-mediated import** instincts, but those seams do **not** by themselves settle whether ViewFS is app-centric, path-centric, or object-centric.

What to steal:
- let the shell bias toward object-home rooms and late tool attachment instead of letting `open with X` become the only mental model;
- let room seeds say what object set and capability kit starts the room, separately from which tool gets attached first;
- keep imported capability binds visibly different from the room's original home set;
- keep published local names visibly different from store membership or retention status;
- keep retention roots/ledgers visibly different from live room occupancy or tool attachment;
- let shell chrome say `object home`, `tool attached`, `imported`, `published here`, `rooted`, or `history only` as different truths.

What not to freeze yet:
- whether every important object deserves a dedicated room/home;
- one universal mapping from object families to room layouts;
- one final `open with` versus `attach tool` protocol;
- any assumption that retention roots, recent-item rows, or old route receipts imply an active object-home room still exists now.


## 1ac. Object identity, capability facets, grouped kits, live room binds, and published names deserve a hard split

Another especially useful seam from current SlopOS material is **underlying object identity versus chosen capability facet versus grouped authority kit versus live room bind versus current published name**.

What to steal:
- `capability-semantics.md` and `capability-rights-registry.md` already keep rights, attenuation, membranes, and revocation explicit instead of pretending every handle is the same noun with invisible extra powers;
- `capshell-handle-table-posture-v0.md` and `capshell-filesystem-posture-v0.md` keep child startup authority explicit enough that a room or child can receive one chosen facet or one explicit kit rather than `the whole object somehow`;
- `document-handle-schema-v0.md` and `document-portal-posture-v0.md` already leave room for one mediated shaped handle/view without claiming that future publication, automation, or durable retention all reuse the same class.

The broader ecosystem sharpens the lesson:
- Sandstorm Powerbox requests ask for a type/API, not one pre-named resource, and the platform can export multiple APIs or permission levels from the same grain;
- Fuchsia says a capability is resource-plus-rights and lets dictionaries group capabilities without pretending grouping is publication;
- Capsicum says rights can only be reduced, never expanded, which is a strong reminder that a narrower facet should be treated as its own live truth;
- CHERIoT sealing is a good reminder that some handles should stay opaque typed tokens rather than stringly designators.

What not to freeze yet:
- one universal facet taxonomy across all ViewFS object families;
- whether facets are always separate minted handles, wrappers over one base handle, or mixed;
- one final grouped-kit schema;
- whether published names normally expose inspect facets, edit facets, publish facets, or tool-shaped projections.

What the shell should be able to say:
- `inspect facet`, `edit facet`, `publish facet`, `automation facet`, `kit only`, `bound here`, `name only`, or `receipt only`.


## 1ad. Descriptor/proof-only rows, verify-only facets, live read facets, and live publish facets should stay separate
Another especially useful seam in the current SlopOS material is **non-authoritative descriptor/proof posture versus verify-only checking posture versus live read/use posture versus live edit/publish posture versus current room bind/history**.

The best lesson here is not `copy Tahoe-LAFS`, `copy Linux O_PATH`, or `standardize one seal/unseal ABI now`.
It is the smaller observation that a system can know:
- one descriptor/proof row exists and is safe for wallets/history/receipts,
- one verify-only facet can validate or check an object without implying ordinary use,
- one live read facet exists right now,
- one stronger edit/publish facet exists right now,
- one room currently binds one of those live facets,
- and none of those truths automatically imply the others.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `descriptor only`, `verify only`, `read now`, `publish now`, `bound here`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `capability-wallet-schema-v0.md` and `wallet-posture-v0.md` already keep wallets descriptive and non-authoritative.
- `document-handle-schema-v0.md` already keeps CH-DOCREF as a non-bearer durable descriptor rather than the authority itself.
- `capability-lease-posture-v0.md` already leans hard on the idea that the enforced proxy/lease is the authority while the descriptor is evidence only.
- `import-to-docref-boundary-v0.md` already refuses to let imported bearer material quietly become one hidden always-live reopen object.

The broader ecosystem sharpens the lesson:
- Tahoe-LAFS capability URIs explicitly distinguish read, write, and verify capability flavors and let stronger forms derive weaker ones.
- Linux `O_PATH` shows that designation and descriptor-level operations can be useful while ordinary byte I/O still fails closed.
- CHERIoT sealing is a reminder that some tokens should stay opaque and tamper-evident when handed back later.

What to steal now:
- **proof cards** that are safe to keep in transcripts, receipts, and wallets without reviving live authority;
- **verify chips** that keep `can check` smaller than `can read/use`;
- **read rails** and **publish rails** so stronger live facets feel intentionally stronger instead of silently widening from inspection;
- **opaque return tokens** for lanes that need hand-back validation rather than stringly rediscovery.

What not to freeze yet:
- whether every ViewFS object family needs a first-class verify-only facet;
- whether proof-only rows are always derived from object descriptors, from live handles, or from separately minted tickets;
- one universal opaque token or seal/unseal ABI;
- whether read and publish facets are sibling handle classes, wrappers, membranes, or mixed depending on backend.


## 1ae. Grant outlooks, issued-bounds cards, restore tokens, live binds, and death verdicts should stay separate
Another especially useful seam in the current SlopOS material is **preflight grant outlook versus issuance-bounded descriptor/evidence versus restore or reactivation material versus current live bind versus explicit death-state verdict/history**.

The best lesson here is not `invent one universal status API now` or `standardize one restore token family now`.
It is the smaller observation that a system can honestly know:
- one preflight outlook says `prompt`, `granted`, `denied`, or `unknown`,
- one descriptor/evidence row says what exact bounds were reviewed or issued,
- one restore/reactivation token or repair route may exist,
- one current room or session may hold live authority right now,
- one explicit death verdict may later say `revoked`, `expired`, `session closed`, `token spent`, or `target changed`,
- and history can remember all of that without silently reviving live power.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `granted`, `issued bounds known`, `restore token present`, `bound here now`, `revoked`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `lease-descriptor-state-boundary-v0.md` is admirably blunt that historical lease/grant descriptors prove exact issuance bounds only and are **not** a hidden current-state oracle.
- `capability-lease-posture-v0.md` already keeps the enforced proxy as the authority while the descriptor is evidence only.
- `capability-wallet-schema-v0.md` and `wallet-posture-v0.md` already keep wallets descriptive rather than resolving or reopening anything.
- `temporal-capability-schema-v0.md` explicitly says CH-TCAP is a redaction-safe descriptor while the live temporal capability remains a kernel capability.
- `document-portal-posture-v0.md`, `import-to-docref-boundary-v0.md`, and portal/session posture keep request objects, durable docrefs, and current live use on distinct seams.

The broader ecosystem sharpens the lesson:
- W3C Permissions and File System Access distinguish querying permission state from requesting permission on a handle.
- Android SAF and `UriPermission` keep user-selected scope and persisted-permission bookkeeping explicit instead of pretending persistence is current successful use.
- XDG Request and Session keep one request object separate from one longer-lived session object.
- XDG RemoteDesktop keeps persistence mode and a single-use restore token separate from the current session.

What to steal now:
- **grant gauges** for `prompt`, `granted`, `denied`, `reconsent needed`, or `unknown`;
- **issued-bounds cards** that are safe for notebooks/history and clearly marked as evidence, not live power;
- **restore beads** for `single-use`, `renewable`, `repair needed`, or `none`;
- **death cards** that preserve `revoked`, `expired`, `session closed`, `token spent`, `target changed`, or `history only` instead of one vague `stale` bucket;
- **repair ladders** that keep `ask again`, `reconsent`, `rebind here`, and `keep receipt only` visibly distinct.

What not to freeze yet:
- one universal grant-status API across all ViewFS object families;
- one universal restore/reactivation token family;
- whether death verdicts are always authoritative provider statements, locally inferred, or mixed;
- whether every family gets a queryable grant outlook or only some do.

## 1af. Semantic object cores, exact byte proofs, structured addresses, and live facets deserve a hard split
Another especially useful seam in the current SlopOS material is **semantic object core versus exact byte proof versus structured/chunked/store address versus designation/published name versus current live facet versus history**.

The best lesson here is not `pick one perfect hash now` or `decide every object family shares one ID scheme`.
It is the smaller observation that a system can honestly know:
- one semantic object is what the user or workflow keeps referring to,
- one exact byte proof exists for one raw or canonicalized representation,
- one structured address exists for one chunked/codec/reference-sensitive layout,
- one designation or published name exists in one namespace or receipt trail,
- one current live facet is bound here now,
- and none of those truths automatically imply the others.

Why this lines up with current SlopOS direction:
- `artifact-reference-schema-v0.md` already says the digest is authoritative while the locator is a hint.
- `artifact-resolution-posture-v0.md` already refuses ambient locator dereference and keeps resolution explicit.
- `verified-blob-descriptor-schema-v0.md` already treats verification posture as descriptive rather than live authority.
- `release-identity-boundary-v0.md` already warns that release names/labels are not exact digest truth.
- `capstore-commit-schema-v0.md` already keeps named-root commits separate from referenced artifacts.
- `document-handle-schema-v0.md` and `wallet-posture-v0.md` already keep descriptive handles/wallet rows non-authoritative.

The broader ecosystem sharpens the lesson:
- OCI descriptors describe one exact raw payload with digest, media type, and size;
- RFC 6920 `ni:` names standardize hash-based naming for digital objects;
- IPFS CIDs include codec and may name a root block after chunking/encoding rather than one plain file checksum;
- Nix content-addressed store paths can include file graph, references, name, and store-directory context.

What to steal now:
- **object-core badges** for `same object core`, `related derivative`, `core unknown`, or `history only`;
- **byte-proof lamps** that separate exact raw-byte proof from other proof families;
- **shape-hash drawers** that explain when chunking/codec/reference context is in play;
- **facet rails** so old proofs and names never impersonate current inspect/read/edit/publish authority.

What not to freeze yet:
- one universal semantic-object-core family across all ViewFS object kinds;
- whether every family needs a semantic core distinct from exact bytes;
- one universal canonicalization rule for proof generation;
- one universal shape-address family or chunking substrate;
- whether designators are mostly local aliases, object cards, docrefs, or publication rows.

## Revision 122 pressure: semantic object cores versus exact byte proofs versus shape hashes
SlopOS now gives ViewFS another honesty warning adjacent to artifact references, verified blobs, release identity, and capstore commits: one semantic object, one exact byte proof, one chunk/codec/reference-sensitive structured address, one published designation, and one current live facet are different truths even when the user experiences them as `the object ID`.

That strongly suggests ViewFS should keep **semantic object cores**, **exact byte proofs**, **shape hashes / structured addresses**, **designations / published names**, **live facets**, and **receipts** on different seams.

That means ViewFS can be ambitious about object-core badges, byte-proof lamps, shape-hash drawers, and facet rails **without** freezing one universal object-id family, one universal proof/canonicalization family, or one final chunk-address substrate.

## 1ag. Stable authority-core stamps, descriptive envelopes, explain sidecars, and live binds should stay separate
Another especially useful seam in the current SlopOS material is **stable review/gate digest versus richer descriptive review envelope versus explainability sidecars versus current live bind versus durable receipt/history**.

The best lesson here is not `standardize one universal wallet now` or `pick one final digest family now`.
It is the smaller observation that a system can honestly know:
- one stable authority-core stamp is the comparison key for drift/reconsent,
- one richer descriptive envelope exists for human review and receipts,
- one graph/diff/basis/provenance sidecar exists to explain rather than authorize,
- one current room or session holds live authority right now,
- and history can remember all of that without reviving live power.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `same reviewed core`, `envelope changed`, `diff attached`, `bound here now`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `wallet-posture-v0.md` is admirably blunt that `wallet_core_digest` is the only stable binding key while the full wallet digest is correlation only.
- `capability-wallet-schema-v0.md` keeps wallets descriptive/review-oriented rather than live authority.
- `capability-graph-schema-v0.md` and `capability-diff-schema-v0.md` already treat graph/diff digests as explainability surfaces.
- `lease-descriptor-state-boundary-v0.md` already refuses to let historical descriptive records impersonate current live state.

The broader ecosystem sharpens the lesson:
- Git patch-id is useful precisely because one reasonably stable digest can key metadata without claiming to be the whole commit object or its descriptive history.
- OCI descriptors keep exact content truth in a compact required core while annotations and URLs remain descriptive/optional.
- in-toto statements keep subject digest truth separate from contextual names and the broader predicate envelope.
- SLSA provenance is valuable explanatory/verifiable metadata without being the artifact or the current authority.

What to steal now:
- **core stamps** for `same reviewed core`, `core changed`, `correlation only`, or `unknown`;
- **envelope drawers** that expose volatile labels/issuance/source context without churning the stable review key;
- **sidecar lamps** for `graph attached`, `diff attached`, `basis attached`, `provenance attached`, or `none`;
- **live rails** that keep `bound here`, `bound elsewhere`, `not bound`, and `history only` visibly different.

What not to freeze yet:
- one universal authority-core digest family across all ViewFS object families;
- one universal wallet/review-envelope schema;
- one universal explain-sidecar taxonomy;
- whether sidecars are shell-owned, provider-owned, portal-owned, or mixed.

## Revision 123 pressure: stable review stamps versus descriptive envelopes
SlopOS now gives ViewFS another honesty warning adjacent to wallets, graph/diff explainability, and lease-state boundaries: one stable review/gate digest, one richer descriptive envelope, one explain sidecar bundle, and one current live bind are different truths even when the user experiences them as `the capability card`.

That strongly suggests ViewFS should keep **authority-core stamps**, **descriptive review envelopes**, **explain sidecars**, **live binds**, and **receipts** on different seams.

That means ViewFS can be ambitious about stamp badges, envelope drawers, sidecar lamps, and live rails **without** freezing one universal wallet schema, one universal digest family, or one final explain-sidecar ABI.

## 1ah. Semantic records, canonical payloads, signed wrappers, wire copies, and live binds should stay separate
Another especially useful seam in the current SlopOS material is **semantic record meaning versus canonical payload bytes versus signed/authenticated wrapper versus concrete wire/storage copy versus current live bind versus durable receipt/history**.

The best lesson here is not `pick one universal signature envelope now` or `pick one universal canonicalization law now`.
It is the smaller observation that a system can honestly know:
- one semantic record is what the user is reviewing,
- one canonical payload is what a particular digest/signature profile cares about,
- one signed wrapper authenticates payload type and signer context,
- one concrete wire/storage copy is what moved through one channel,
- one current room or session holds live authority right now,
- and history can remember all of that without reviving live power.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `same record`, `same payload`, `wrapper changed`, `wire copy only`, `detached payload`, `bound here now`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `encoding-policy.md` is admirably blunt that authoring JSON may be canonicalized and transcoded, while signed/wire forms are a separate decision surface.
- `wallet-posture-v0.md` already says `wallet_core_digest` is a stable binding key while the full wallet digest is only correlation.
- `capability-wallet-schema-v0.md` makes the normalized projection explicit and therefore keeps `same authority summary` distinct from `same full descriptor bytes`.
- `artifact-reference-schema-v0.md` already keeps digest-authoritative identity separate from locator hints.

The broader ecosystem sharpens the lesson:
- RFC 8785 JCS explicitly says canonicalization lets cryptographic operations happen on a canonicalized counterpart while the original JSON may remain on the wire.
- RFC 8949 explicitly says protocols must be clear about deterministic encoding when multiple representations could express the same semantics.
- RFC 9052 COSE explicitly allows detached payloads and makes the application responsible for ensuring the detached content is transported unchanged.
- in-toto separates Statement and Envelope, requires signed payload type, and refuses to let media type or filename alone stand in for authenticated meaning.

What to steal now:
- **record cards** for `same meaning`, `changed meaning`, `review only`, or `unknown`;
- **payload chips** for `same canonical payload`, `payload changed`, `profile mismatch`, or `not computed`;
- **wrapper seals** for `signed`, `payload type authenticated`, `detached payload`, `wrapper changed`, or `wrapper only`;
- **wire ghosts** for `transport copy`, `logged copy`, `export copy`, or `history only`;
- **live rails** that keep `bound here now` stronger than every payload, wrapper, or wire card.

What not to freeze yet:
- one universal canonicalization profile family across all ViewFS objects;
- one universal signature wrapper or media-type family;
- one universal detached-payload rule;
- whether wrappers are shell-owned, portal-owned, provider-owned, or mixed.

## Revision 126 pressure: semantic records versus payloads versus wrappers versus wire copies
SlopOS now gives ViewFS another honesty warning adjacent to wallets, artifact references, canonical encoding policy, and future signed descriptors: one **semantic record**, one **canonical payload**, one **signed wrapper**, one **wire/storage copy**, one **current live bind**, and one **receipt/history row** are different truths even when the user experiences them as `the signed card I imported`.

That strongly suggests ViewFS should keep **semantic records**, **canonical payloads**, **signed wrappers**, **wire copies**, **live facets/binds**, and **receipts** on different seams.

That means ViewFS can be ambitious about record cards, payload chips, wrapper seals, wire ghosts, and live rails **without** freezing one universal canonicalization family, one universal signature envelope, or one final export/import blob format.


## 1ai. Fresh object identities, shared backing, copy lineage, and live binds should stay separate
Another especially useful seam in the current SlopOS material is **fresh local object identity versus shared-backing optimization versus explicit copy lineage versus current live bind versus durable receipt/history**.

The best lesson here is not `standardize one universal clone ABI now` or `pick one deep-copy policy now`.
It is the smaller observation that a system can honestly know:
- one fresh logical object was minted for this import/materialization event,
- one shared-backing optimization may exist below the object layer,
- one explicit parent/origin lineage row explains where it came from,
- one current room or session holds live authority right now,
- and history can remember all of that without reviving live power.

That is a perfect low-regret lesson for ViewFS because the future shell will absolutely need to say `fresh object`, `shares backing`, `backing diverged`, `explicit parent`, `bound here now`, and `history only` as different truths.

Why this lines up with current SlopOS direction:
- `import-to-docref-fresh-identity-boundary-v0.md` is admirably blunt that import/materialize must mint a fresh local object identity even when the bytes match an existing local object.
- That same boundary is also admirably blunt that storage-level dedupe is allowed only below the object boundary.
- `open-untrusted-export-lineage-boundary-v0.md` insists on one explicit immediate parent digest rather than filename/path folklore.
- `wallet-posture-v0.md` keeps review artifacts descriptive so lineage/history can stay visible without becoming authority.

The broader ecosystem sharpens the lesson:
- Linux reflink explicitly shares underlying storage while writes remain private to the file being written.
- Btrfs reflink explicitly says shared blocks do not stop the files from being independent.
- OpenZFS clone concepts keep snapshot origin dependency and clone promotion explicit.
- APFS clones make cheap local copies first-class without pretending they are hard links.

What to steal now:
- **birth badges** for `fresh object`, `derived object`, `rebuilt object`, or `history only`;
- **backing ghosts** for `shares backing`, `backing diverged`, `deep copy`, or `unknown`;
- **lineage ladders** for `reflinked from`, `snapshot origin`, `explicit parent`, `rebuilt from`, or `history only`;
- **unshare/adopt ladders** so `deep copy now`, `keep shared`, `promote derived copy`, and `receipt only` stay visibly distinct.

What not to freeze yet:
- one universal clone/reflink ABI across all ViewFS providers;
- whether every provider even exposes backing-sharing visibility;
- one universal lineage graph schema;
- whether `unshare now` or `adopt as primary` are universal verbs.

## Revision 127 pressure: fresh objects versus shared backing versus lineage
SlopOS now gives ViewFS another honesty warning adjacent to import-to-docref fresh identity, explicit safe-open export lineage, and provider-local object posture: one **fresh object**, one **shared-backing optimization**, one **copy lineage row**, one **current live bind**, and one **receipt/history row** are different truths even when the user experiences them as `the copy I imported`.

That strongly suggests ViewFS should keep **fresh object identities**, **shared backing**, **copy lineage**, **live facets/binds**, and **receipts** on different seams.

That means ViewFS can be ambitious about birth badges, backing ghosts, lineage ladders, and live rails **without** freezing one universal clone ABI, one universal lineage graph, or one final deep-copy/unshare policy.

## A fresh lesson from current SlopOS persistence, import, and jobs posture

Another especially useful seam in the current SlopOS material is **upload session versus part coverage versus completion manifest versus committed object versus abort verdict versus current live facet versus durable receipt/history**.

What to steal:
- `rfcs/0038-persistent-object-store-and-snapshots.md` keeps durable store membership and snapshot lineage explicit instead of laundering `bytes are moving` into `object exists now`.
- `rfcs/0065-orthogonal-persistence-and-capstore.md` keeps durable commits and named roots explicit instead of letting one in-flight continuity token impersonate durable object birth.
- `artifact-reference-schema-v0.md` keeps exact artifact identity separate from storage/retrieval plumbing, which is the right posture for completion manifests and import residue.
- `import-to-docref-fresh-identity-boundary-v0.md` already pressures fresh local object birth to remain explicit instead of cache-hit folklore.
- `background-lease-posture-v0.md` explicitly says deferrable sync/uploads should prefer jobs rather than ambient keep-running myths, which is a great reminder that upload continuity and live authority should stay separate.
- shell chrome should be able to say `session open`, `partial`, `assembly ready`, `committed`, `aborted`, `live facet`, or `receipt only` as different truths.

What not to freeze yet:
- one universal resumable-upload or multipart ABI across all ViewFS providers;
- one universal part/chunk numbering scheme;
- whether completion manifests are explicit first-class objects on every backend;
- whether abort cleanup is synchronous, lazy, or provider-owned;
- any assumption that one session carrier or offset row proves a durable committed object or current live authority already exists.

This pass stays deliberately **idea-rich and decision-light**.

## A fresh lesson from current SlopOS composition, persistence, and activation posture

Another especially useful seam in the current SlopOS material is **assembly recipe versus member descriptor versus aggregate object versus realized work surface versus current live facet versus durable receipt/history**.

What to steal:
- `rfcs/0009-component-manifests-and-capability-routing.md` keeps composition/routing as explicit data, which is the right instinct for recipe-like assembly intent.
- `docs/30-architecture/activation-posture-v0.md` is admirably blunt that CH-ACTSET is descriptive and bounded rather than authority by itself; that is exactly the honesty we want from recipe/member rows.
- `rfcs/0038-persistent-object-store-and-snapshots.md` keeps snapshot/clone/store membership explicit rather than laundering one assembled result into one mounted workspace myth.
- `rfcs/0065-orthogonal-persistence-and-capstore.md` keeps durable commits and named roots explicit instead of ambient.
- `docs/30-architecture/artifact-reference-schema-v0.md` keeps exact artifact identity separate from retrieval folklore, which is the right posture for member descriptors.
- `docs/30-architecture/attestation-pack-schema-v0.md` keeps normalized summary bytes and provider-native evidence distinct inside one pack; that is strong pressure not to flatten recipe/payload/aggregate/work-surface layers.
- shell chrome should be able to say `recipe only`, `member set known`, `aggregate committed`, `realized here`, `evicted but rebuildable`, `live now`, or `history only` as different truths.

What not to freeze yet:
- one universal recipe schema across all ViewFS object families;
- one universal member-descriptor vocabulary;
- whether every aggregate object must be reproducible from recipe plus descriptors alone;
- whether realization is provider-owned, portal-owned, helper-owned, or shell-owned;
- any assumption that unpack/materialize/hydrate is the same thing as durable aggregate-object birth.

This pass stays deliberately **idea-rich and decision-light**.

## Revision 129 pressure: assembly recipes versus member descriptors versus aggregate objects versus realized work surfaces
SlopOS now gives ViewFS another honesty warning adjacent to component manifests, activation manifests, persistent object-store posture, CapStore roots, and artifact references: one **assembly recipe**, one **member descriptor set**, one **aggregate durable object**, one **realized work surface**, one **current live facet**, and one **receipt/history row** are different truths even when the user experiences them as `one assembled thing`.

That strongly suggests ViewFS should keep **assembly recipes**, **member descriptors**, **aggregate objects**, **realized work surfaces**, **live facets**, and **receipts** on different seams.

That means ViewFS can be ambitious about recipe cards, member rails, aggregate seals, unpack lamps, and live rails **without** freezing one universal bundle ABI, one universal recipe language, or one final unpack/materialize contract.


## A fresh lesson from current SlopOS artifact and CapStore posture

Another especially useful seam in the current SlopOS material is **committed object versus durability profile versus redundancy layout versus repair verdict versus availability state versus current live facet versus durable receipt/history**.

What to steal:
- `artifact-reference-schema-v0.md` already keeps digest identity authoritative while locators stay non-authoritative hints, which is exactly the right instinct for not letting placement rows become object identity;
- `capstore-commit-schema-v0.md` already keeps durable commit meaning explicit instead of ambient, which is the right anchor for saying `the object exists` without pretending the current storage layout is part of the same noun;
- shell chrome should be able to say `replica target`, `k-of-n target`, `layout hidden`, `scrubbing`, `repairing`, `retrievable with degradation`, `unrecoverable`, or `history only` as different truths.

What not to freeze yet:
- one universal durability-profile registry across all ViewFS providers and object families;
- whether every provider exposes share, replica, stripe, or placement rows at all;
- whether repair verdicts are provider-native, locally audited, or mixed;
- whether availability is room-local, machine-local, provider-local, or all three;
- any assumption that current readability proves current redundancy health or vice versa.

This pass stays deliberately **idea-rich and decision-light**.


## Revision 135 pressure: committed objects versus residency profiles versus placement realms versus route endpoints versus egress gates

Another especially useful seam in the current SlopOS material is **committed object versus residency profile versus placement realm versus route endpoint versus egress gate versus current live facet versus durable receipt/history**.

What to steal:
- `cluster-map-schema-v0.md` already keeps locality/partition description explicit, deterministic, and non-authoritative, which is exactly the right instinct for realm truth;
- ADR-0006 replication contracts already keeps cross-cluster ownership and replication class explicit instead of ambient, which is the right instinct for placement truth;
- `artifact-reference-schema-v0.md` keeps exact artifact identity separate from locator folklore, which is the same kind of humility route surfaces need;
- `capstore-commit-schema-v0.md` keeps durable object birth explicit instead of ambient;
- shell chrome should be able to say `policy says EU pair`, `copies in A+B`, `nearest route`, `secondary read`, `cross-boundary export denied`, `live here now`, or `history only` as different truths.

What not to freeze yet:
- one universal region/jurisdiction taxonomy across all ViewFS providers;
- whether placement realms are exact, summarized, or provider-hidden;
- whether route endpoints are always inspectable to users;
- one final cross-boundary egress policy language;
- any assumption that a nearest/global endpoint proves object presence or policy compliance there.

This pass stays deliberately **idea-rich and decision-light**.

## Revision 136 pressure: committed objects versus access propagation versus public cache copies versus cache trails

Another especially useful seam in the current SlopOS material is **committed object versus access-propagation state versus public-cache copy versus cache trail versus current live facet versus durable receipt/history**.

What to steal:
- `artifact-reference-schema-v0.md` already keeps exact artifact identity separate from retrieval/runtime folklore, which is exactly the right instinct for origin truth.
- `approval-basis-posture-v0.md` is admirably blunt that one reviewed approval is not a portable permission cache, which is the right instinct for propagation truth.
- `auth-result-export-boundary-v0.md` and nearby auth boundaries keep provider-local login / proof / result state from silently becoming durable universal authority.
- `cache-topology-authority-boundary-v0.md` is already blunt that cache-topology facts are placement hints only, which is the right instinct for not letting cache rows become authority.
- many current SlopOS boundary notes explicitly warn against hidden cached provider state becoming portable truth.
- shell chrome should be able to say `origin current`, `revoke settling`, `public cache may still serve stale`, `cache trail says hit`, `live read facet`, or `history only` as different truths.

What not to freeze yet:
- one universal public-cache or invalidation API across all ViewFS providers;
- whether cache trails are always exposed to users or only to debug/receipt views;
- one final revocation-propagation state machine;
- whether public cache copies are modeled as first-class objects or only summarized state;
- any assumption that one cache hit/miss row proves durable object or permission truth.

This pass stays deliberately **idea-rich and decision-light**.


## 1aa. Prefix projections, provider folder resources, listing snapshots, and current room binds should stay separate
Another especially useful seam is **committed object versus prefix projection versus provider folder resource versus listing snapshot versus published name / room bind versus live facet versus receipt/history**.

The best lesson here is not `object stores are fake filesystems` or `every folder should be first-class now`. The stronger lesson is that older systems get expensive when they force one folder-looking row to mean object identity, provider-native directory truth, current listing completeness, and current authority all at once. Amazon S3 stays flat and says prefixes are not directories; Google Cloud Storage stays flat by default, yet separately adds managed folders and hierarchical namespace when stronger folder resources are wanted; Azure Blob Storage uses virtual directories in flat naming but can also expose real directories in hierarchical-namespace accounts.

That is a perfect low-regret lesson for ViewFS because the current SlopOS datacube already has the right instincts in several places:
- `capshell-cwd-root-posture-v0.md` already treats process-local roots as explicit setup rather than inherited browse folklore.
- `capshell-handle-table-posture-v0.md` already treats live authority tables as runtime truth rather than list-result truth.
- `attrfs-posture-v0.md` already keeps shell/view-owned grouping and query ideas distinct from raw stored objects.
- `document-portal-posture-v0.md` and `import-to-docref-boundary-v0.md` already keep mediated localization and later reopen distinct from provider naming.

So ViewFS should preserve a few simple truths while both parent and child datacubes are still fluid:
- one row may be a **flat prefix projection** and not a folder resource,
- one row may be a **provider folder resource** and not the semantic object itself,
- one browse result may be a **listing snapshot** rather than a room bind,
- one **published name** may exist without any current room binding,
- and one **live facet** may exist without any current complete listing.

That gives the future shell some brilliant ideas to steal without overcommitting early:
- prefix badges and folder ghosts,
- list lanterns for `snapshot`, `partial`, `cached`, or `live`,
- and room-bind rails that stay visibly separate from storage-prefix folklore.

Do not decide yet whether every provider folder resource becomes a first-class ViewFS object, whether flat object stores get one canonical delimiter, or whether published names and current room binds share storage. Freeze the split first.

## Revision 138 evaluation addendum: launch plans, bound roots, handle slots, portal tickets, live binds, and receipts

The best new lesson from reviewing the included SlopOS design material is that the datacube should treat launch/import assembly as an authority boundary, not as file-manager chrome.

### What SlopOS already gets right

- It keeps child handle tables exact through CH-STDIO / CH-FDSET rather than inheriting ambient parent descriptors.
- It treats cwd/root binding as authority instead of a host path hint.
- It refuses to treat ordinary absolute paths as reviewed portable authority inside capshell.
- It frames portals as handle-returning mediation surfaces with receipts, leases, and cap-diffs, not as magical ambient access brokers.

### Datacube consequence

ViewFS should let the user and the system separately inspect:

1. what was planned for a launch/import;
2. what root was actually bound;
3. which exact live slots/handles were delivered;
4. which portal ticket/request/session is still only mediator control state;
5. what live bind/facet exists here now;
6. which receipts explain history but do not confer power.

### Must-learn lessons

- Fuchsia: namespaces are assembled per component/process; do not assume global `/`.
- Capsicum/WASI: live descriptors/preopens/resources are authority; ambient path lookup is the thing to shrink.
- XDG Documents: document-store entries, permissions, host paths, revocation, and deletion are separate enough to reason about.
- Tahoe-LAFS / Cap'n Proto: capability flavors and capability tables are useful, but stringly universal handles are not mandatory.
- EROS: persistent capabilities can be elegant, but persisting live authority graphs is a whole-system commitment.
- GCS/Azure/etcd: compare-before-write witnesses belong near mutation/adoption, not hidden behind names or old receipts.

### Nifty ideas to steal

- **launch rehearsal cards** before authority is installed;
- **root badges** for synthetic, sealed-empty, provider-backed, object-store-backed, compat, and history-only roots;
- **slot maps** with rights/lease/provenance chips;
- **import ticket trays** that distinguish `granted-not-bound` from `live here now`;
- **adoption ladders** from external result to staging capsule to committed object to published bind;
- **live-bind rails** that visibly outrank plans, tickets, list rows, and receipts;
- **ambient-debt sirens** for host absolute paths, inherited descriptors, stale reopen receipts, and hidden compatibility fallbacks.

### Decisions still intentionally avoided

This addendum does not choose the datacube hash, object manifest, pack layout, GC policy, handle ABI, rights taxonomy, portal-ticket persistence model, or final namespace serialization. It only preserves the split so those later choices can be made deliberately.

## A fresh lesson from SlopOS capability-graph and capability-diff posture

Another especially useful seam for ViewFS while SlopOS is still in design is **current handle inventory versus custody chain versus outflow gate versus redacted flow snapshot/diff versus leak verdict versus live export/proxy/borrow versus durable receipt/history**.

What to steal:

- SlopOS's capability graph posture keeps snapshots bounded and redacted, which is exactly the right shape for ViewFS debugging and consent surfaces;
- SlopOS's capability diff posture gives ViewFS a vocabulary for before/after authority changes without treating the diff as the operation;
- SlopOS's capability export posture keeps cross-boundary authority explicit and proxy-first;
- SlopOS's wallet posture reminds ViewFS that summaries and descriptors must not become bearer authority;
- SlopOS's portal playbook keeps imports transcriptable, default-deny, and handle-shaped rather than path-shaped;
- capshell posture keeps shell execution authority visible enough for users and test harnesses.

What not to freeze yet:

- one final capability graph schema;
- one final export-token format;
- one final passability taxonomy;
- one universal currentness witness;
- one UI gesture that means every kind of share/export/borrow/materialize;
- any idea that a receipt, graph snapshot, custody badge, or wallet row grants current power.

This pass stays deliberately **idea-rich and decision-light**. The new design object is the separation itself, not a final ViewFS capability ABI.


## Revision 140: a fresh lesson from SlopOS CapStore and durable-root posture

Another especially useful seam for ViewFS while SlopOS is still in design is **durable root commit versus epoch fence versus restore intent versus resurrection gate versus activation target versus current live bind versus durable receipt/history**.

What to steal:
- `capstore-commit-schema-v0.md` already makes durable commits explicit through parentage, root updates, artifact refs, epochs, signatures, and durable capability entries;
- `rfcs/0065-orthogonal-persistence-and-capstore.md` already says persistent authority is explicit and optional, not ordinary ambient memory by default;
- `view-namespace-posture-v0.md` and `capshell-cwd-root-posture-v0.md` already push toward explicit view/cwd roots rather than privileged global `open(path)`;
- `capability-wallet-schema-v0.md` already keeps authority summaries non-authoritative;
- `keyref-schema-v0.md` and `secretref-schema-v0.md` already keep key/secret persistence reference-shaped rather than raw secret-shaped;
- shell chrome should be able to say `recorded root`, `accepted tip`, `stale candidate`, `needs reconsent`, `read-only preview`, `activated`, `live slots installed`, or `receipt only` as different truths.

What not to freeze yet:
- one final durable-root schema;
- whether CapStore is the ViewFS store, a SlopOS substrate, or one provider behind ViewFS;
- one universal epoch/currentness witness;
- one final portal/sturdyref/keyref resurrection ceremony;
- whether rollback is a normal user feature, a recovery feature, or mostly a developer/test lane;
- any assumption that an old root commit, wallet row, cap graph, receipt, or durable descriptor proves current live authority now.

This pass stays deliberately **idea-rich and decision-light**.

## Revision 141 pressure: reachability roots versus live-handle roots versus pins/holds/leases versus sweep candidates

Another especially useful seam for ViewFS while SlopOS is still in design is **reachability root versus live-handle root versus pin/hold/lease record versus sweep candidate versus deletion finalizer versus collected ash/tombstone versus current live facet versus durable receipt/history**.

What to steal:

- `rfcs/0065-orthogonal-persistence-and-capstore.md` says durable roots and persistence are explicit authority, while GC-root representation remains a real open question rather than folklore;
- `capstore-commit-schema-v0.md` keeps root commits, parents, epochs, artifacts, and durable capability refs explicit;
- `capability-lease-posture-v0.md` and `lease-descriptor-state-boundary-v0.md` keep temporary proxy/grant evidence bounded and weaker than current live state;
- `background-lease-posture-v0.md` keeps future work/jobs separate from ambient keep-running assumptions;
- `receipt-replication-boundary-v0.md` and nearby receipt boundaries keep history from reviving present truth;
- shell chrome should be able to say `durable root`, `live handle root`, `direct pin`, `recursive pin`, `lease`, `hold`, `cache only`, `sweep candidate`, `finalizing`, `collected`, `live now`, or `receipt only` as different truths.

What not to freeze yet:

- one universal GC algorithm or graph schema;
- one universal CapStore/ViewFS root table;
- one final pin/hold/lease vocabulary across every provider and object family;
- whether tombstones are mandatory or family-specific;
- whether finalizers are stored beside roots, receipts, providers, or a separate deletion queue;
- any assumption that cache presence, search visibility, list membership, receipt retention, or stale namespace rows are roots by default.

This pass stays deliberately **idea-rich and decision-light**.

## Revision 142: a fresh lesson from SlopOS D-QUAR and safe-open anti-laundering

Another especially useful seam for ViewFS while SlopOS is still in design is **origin evidence versus quarantine mark versus safe-open capsule versus viewer residue versus derived artifact versus trust clearance versus live open versus receipt/history**.

What to steal:

- SlopOS D-QUAR treats quarantine as monotonic by default, object-local, and manual-only to clear;
- import-to-docref boundaries say explicit bearer/import handoffs should first become fresh local objects and remain quarantined by default;
- safe-open materialization is request-local and stable, not a live alias or write-through mount;
- safe-open viewers stay inert by default for active content;
- viewer residue should stay disposable-local unless explicitly exported;
- content-derived indexes, OCR, embeddings, summaries, and smart-folder matches should not launder quarantined bytes into ordinary discovery surfaces;
- ordinary kept output is a new artifact with parent evidence and still quarantined by default unless a distinct sanitize/clear workflow says otherwise.

What not to freeze yet:

- one final quarantine metadata schema;
- one final risk taxonomy;
- one final scanner/reputation/notarization pipeline;
- one final content-disarm or sanitizer ABI;
- one final embedding/summary storage model;
- one universal rule for when equal bytes may reuse trust;
- one UI gesture that means preview, edit, active-content enablement, and execution trust.

This pass stays deliberately **idea-rich and decision-light**. The important object is the split itself: `selected`, `imported`, `previewed`, `indexed`, `derived`, `sanitized`, `cleared`, `live-open`, and `receipted` are separate classes.

## Revision 143 pressure: archive/container extraction must not become ambient namespace authority

Another especially useful seam for ViewFS while SlopOS is still in design is **container envelope versus member claim versus extraction plan versus sterile materialization root versus extracted member capsule versus namespace commit versus current live open versus receipt/history**.

Current SlopOS pressure:

- D-QUAR keeps quarantine monotonic and object-local;
- open-untrusted materialization is request-local and stable, not a live alias;
- viewer residue and content-derived indexing are kept out of durable host state unless explicitly exported;
- capshell cwd/root posture rejects `..`, absolute paths, and symlink escapes against an ambient root;
- artifact references and CapStore-style commits already distinguish digest evidence from runtime authority.

External pressure:

- Zip Slip showed how widespread arbitrary overwrite can follow from trusting archive member paths;
- Python's tarfile moved to a safer default extraction filter while still warning that untrusted archives require inspection;
- Go's tar/zip insecure-path checks are compatibility-gated, showing why ViewFS cannot depend on one runtime default;
- bsdtar refuses traversal and symlink target-directory alteration by default unless the user opts into absolute/insecure behavior;
- OCI image structure separates descriptors/manifests/indexes/layers/configs/runtime bundles instead of pretending the aggregate is already a live root.

ViewFS import:

- raw member names are claims, not names in a ViewFS namespace;
- extraction should have a visible rehearsal/plan step;
- materialization should land first in a sterile root or projection;
- admitted members should receive fresh object/projection identities and quarantine lineage;
- publication into a view should be a separate currentness-checked namespace commit;
- receipts should record denied hazards without becoming reopen authority.

Non-import:

- do not adopt any one tar/zip/OCI library's defaults as the ViewFS security model;
- do not treat archive signatures as trust clearances for member publication;
- do not make `extract here` the semantic center of the object store;
- do not let whiteouts or link targets mutate current views without an explicit plan.

## Revision 144 pressure: SBOM/VEX/attestation seams must not become trusted-package folklore

The SlopOS datacube is especially valuable for ViewFS here because it has already resisted several common supply-chain collapses. The embedded SBOM posture says digest-bound inventory evidence must not authorize install, boot, import, network fetch, package selection, or policy widening. Its VEX posture says exploitability evidence must not become vulnerability suppression, feed authority, or boot/update/import authorization. Its artifact-reference and artifact-resolution notes say locators are hints and privileged code must not dereference them ambiently. Its verification-material/policy/verdict boundaries preserve the difference between evidence discovery, policy selection, and local result.

ViewFS should steal that shape. A future ViewFS object store will have archives, helper bundles, launch kits, extracted member capsules, safe-open documents, and executable objects. Those objects will attract SBOMs, VEX documents, signatures, provenance attestations, transparency-log entries, update metadata, scanner results, and hand-written receipts. The right early posture is to keep all of those as evidence until a local admission cut names a subject, action, target, policy, epoch, and resulting live facet.

The highest-risk design smell is a UI or API that says **trusted package** without exposing which exact subject, inventory, locator matches, advisories, provenance roots, policy cut, target, and live handle it means.

## Revision 145 evaluation: secret delivery and redaction are separate from live authority

SlopOS already gives ViewFS a strong local warning. D-APPSECRET is intentionally a minimal app-scoped seed seam, not a vault, named-secret inventory, password manager, OAuth-token paste lane, account-linking bridge, or credential-export facility. Capshell environment posture says launch environments are exact, not ambient baselines. Credential baseline posture prevents host/session identity from silently crossing exec. Auth-export boundaries keep login result, proof, authorization context, identity claim, account binding, and teardown separate.

For ViewFS, that means the next object-store/capability/namespace work should preserve these classes:

- secret descriptor;
- acquisition prompt or consent act;
- delivery slot/projection;
- environment shadow;
- redaction lens;
- renewal/rotation lease;
- live-use handle;
- residue marker;
- receipt/history.

The main design warning: **masked is not safe, env is not a secret store, prompt success is not future authority, renewal is not current material, and receipt is not a token**.

This matters for ViewFS imports and admitted helpers because a careful capability namespace can still be defeated by a broad inherited token in env, a provider keyring side channel, a transcript leak, or secret-derived residue in caches/config/databases.

## Revision 146 evaluation: revocation wavefronts are separate from live authority

SlopOS's design-phase material is a strong warning against the naive `revoke` button. D-LEASE makes the lease proxy the authority and CH-CAPLEASE evidence only. RFC-0019 treats epochs/indirection as optional, bounded revocation mechanisms with no-resurrection obligations. D-CAPX and sturdyref posture keep bearer restore/import material sharp and off-by-default. The MCP/OAuth token revocation/import boundaries keep provider-local token teardown from widening into portable connected-account, durable live-login, or generic delegation truth.

For ViewFS, the next split is:

- delegation intent;
- attenuation/caveat envelope;
- membrane lease/proxy;
- delegated handle/imported stub;
- revocation request;
- revocation wavefront/checkpoint;
- stale-handle brake/death verdict;
- renewal/redelegation control;
- current live authority;
- receipt/history.

The main design warning: **revoked is not one bit**. It may mean a local proxy closed, an epoch advanced, a provider accepted a revoke request, a token expired, renewal was denied, a stale use was blocked, a recipient was notified, an offline descendant is unknown, or only a receipt was written.

This matters because ViewFS wants explicit per-process namespaces, capability handles, portal-mediated imports, and object-store receipts. Without this split, the shell will either overpromise revocation or make users distrust the model. With the split, the shell can show wavefront maps, membrane lamps, stale brakes, rotate/reissue ladders, and recall receipts while still leaving SlopOS free to revise its final CapStore/D-LEASE/D-CAPX details.

## Revision 147: a fresh lesson from SlopOS inspect, observation export, trace, and peer-inspection posture

Another especially useful seam for ViewFS while SlopOS is still in design is **inspection intent versus target locator versus namespace/process-view snapshot versus handle/fd peek versus memory/core capture versus trace probe/stream/processor versus debug-control lane versus redaction/export cut versus current live authority versus receipt/history**.

Current SlopOS pressure:

- capshell peer-inspection posture already says reviewed launch should not inherit host-default same-principal dumpability or debugger attachability;
- CH-INSPECT already gives a bounded/canonical/redaction-aware diagnostic snapshot vocabulary;
- observation export policy already says exported observation material needs minimization and policy, not ambient log scraping;
- tracepoint descriptors and trace processors already separate probe schemas, field redaction, bounded predicates, untrusted processors, output discipline, and TTLs;
- microvm debug-introspection posture explicitly declines portable host-side guest-debug and memory-dump contracts in Phase 1.

What to steal:

- diagnostic snapshots should be structured and bounded;
- raw handles, raw addresses, secrets, and stable cross-target identifiers should be redacted by default;
- process inspection is authority, not harmless metadata;
- trace processing can be a sandboxed computation over observations rather than privileged extension code;
- debug/memory-dump surfaces deserve bright non-portability warnings until they are explicitly designed.

What not to freeze yet:

- one final diagnostic export schema;
- one final support bundle format;
- one final trace vocabulary;
- a portable debugger or memory-dump ABI;
- a rule that the shell can always inspect sibling processes, workers, providers, or microVM guests;
- any idea that a slot inventory, trace stream, dump metadata, redaction mask, or inspection receipt is current authority.

This pass stays deliberately **idea-rich and decision-light**. The new design object is the separation itself, not a final diagnostics subsystem.

## Revision 148: a fresh lesson from SlopOS D-NETLEASE and network boundary posture

The SlopOS datacube is extremely strong on outbound networking. RFC-0056 makes network access portal-issued and lease-based rather than ambient. The D-NETLEASE posture keeps socket constructors, DNS, resolver binding, proxy selection, service binding, Happy-Eyeballs/address selection, TLS verifier details, local egress, request identity, and live portal-owned state on separate seams. The boundary-index approach is especially valuable because it prevents a small network request descriptor from quietly growing into a universal browser/network-stack transcript.

For ViewFS, the lesson is not “copy CH-NETREQ.” The lesson is that a future object store and capability namespace will be porous unless network is treated as another explicit authority class. Import workflows, safe-open viewers, package/update helpers, support uploaders, trace exporters, and secret-bearing tools all need to say when they are resolving, connecting, listening, advertising, fetching, sending, or only recording history.

What to steal:

- no ambient sockets/DNS as the clean design target;
- portal-owned resolver/dialer/listener handles rather than process-global `getaddrinfo` and socket constructors;
- exact request bytes are replay/dedupe identity, not current live lease state;
- local network, loopback, public internet, proxy, DNS, service binding, and address selection should stay named;
- request/lease/stream/receipt vocabularies should make omitted facts explicit.

What not to freeze yet:

- one ViewFS network lease descriptor;
- one DNS resolver or URL canonicalization profile;
- one proxy/PAC/WPAD story;
- one TLS/QUIC/ALPN/SNI/ECH/client-cert model;
- whether local discovery belongs under network, devices, portals, or a separate family;
- whether a SlopOS lease handle is the native ViewFS object.

The new guardrail: **a network intent is not a destination, a destination is not a resolution witness, a resolution witness is not a dialer, a lease descriptor is not the live stream, stream telemetry is not a future grant, local exposure is not outbound connect, egress/import is not merely network reach, and receipt/history is not current authority**.
## Revision 149 evaluation: service discovery and binding must not become endpoint folklore

The SlopOS datacube is already sensitive to this problem. Its D-NETLEASE family separates name context, service binding, resolver binding, DNS query shape, address selection, proxy, TLS verifier, and live portal-owned state. Its DID document import boundary keeps service entries and resolver metadata from becoming controller truth, signer inventory, endpoint-discovery authority, or approval-basis objects. Its MCP/resource/tool and artifact-reference boundaries keep catalogs and locators descriptive unless a local policy lane adopts them.

For ViewFS, the new lesson is broader than network. Service discovery can appear through object-store catalogs, project service directories, local IPC, portal resource lists, MCP tools, DNS-SD/mDNS, Kubernetes-like service abstractions, xDS-like control planes, socket activation, DID service entries, package metadata, or shell suggestions.

The split to preserve:

- service intent;
- service designator;
- discovery/catalog authority;
- discovery snapshot / candidate set;
- readiness/health/identity evidence;
- binding cut / admission decision;
- activation target / route warming;
- current live service handle;
- advertisement / publication;
- receipt/history.

What to steal:

- SlopOS's refusal to let resolver/service-binding metadata become portable authority;
- DNS-SD's browse/resolve split;
- mDNS's local-link caution;
- Kubernetes EndpointSlice's multi-state readiness vocabulary;
- xDS's resource subscriptions, sequencing, warming, and TTL humility;
- systemd socket activation's manager-passed handle discipline;
- SPIFFE's workload identity vocabulary, but only as evidence for local binding/admission.

What not to steal yet:

- one global service registry;
- a service URL that is itself authority;
- one health/readiness green bit;
- one service identity / trust-domain model;
- one listener/advertisement/public-endpoint model;
- old receipts as rebind authority.

The guardrail is the same ViewFS keeps discovering in new clothes: **metadata can guide authority, but metadata is not authority**.


## Revision 151 pressure: content-addressed storage must not become a membership oracle

Another especially useful seam in the included SlopOS archive is **fresh local identity versus storage-level sharing versus verification descriptors versus cache/index observations versus current authority**.

Why this matters for ViewFS:
- a digest is excellent proof material, but not read authority;
- a dedup/cache hit can leak that some domain already has material;
- a same-byte import still needs fresh identity, origin, quarantine, lineage, and receipts;
- a verified blob descriptor can bind audit/proof, but it is not a mount/open grant;
- memory/page dedup shows that content equality can become an isolation/timing side channel.

What to steal from SlopOS now:
- keep storage-level dedupe below the object boundary;
- keep CH-VBLOB-like proof descriptors non-authoritative;
- keep import-to-docref fresh identity even when bytes match;
- keep untrusted/quarantined content from automatically joining global indexes or semantic caches;
- keep memory/page-dedup and similar density optimizations implementation-local until a much stronger isolation story exists.

What not to freeze:
- one universal digest family;
- one global dedup domain;
- one portable encrypted-dedup/convergence protocol;
- one proof-of-possession API;
- one shell-visible membership query.

The promising UI vocabulary is digest shades, equality rails, dedup shutters, convergence lamps, cache ghosts, possession challenge cards, leakage meters, unshare ladders, and membership-safe receipts.

## Revision 151 sibling-cube pressure: dedupe/comparison aids need horizons and postures

The other included cubes reinforce the same ViewFS caution without forcing a shared schema.

- Foundry's pending duplicate / dedupe horizon / expiry gate vocabulary says that duplicate-safe treatment has time and settlement posture. A same key, same digest, or same request fingerprint is not eternal proof of replay safety.
- Ward's identity witness / dedupe posture / correction lineage vocabulary says that repeated trust answers need to expose the rule used to collapse rows and the history that later corrected them.
- Helm's surface-core digest vocabulary says a digest may name a stable portable subset while the landing envelope, overlays, residue, fit, and adoption remain separate.
- Schell's change-digest cards say compact glance artifacts should stay weaker than raw streams, currentness, and action authority.
- Harbor's cache-epoch and admission-truth posture says cached discovery or schema detail can help explain an answer, but must not become fresh materialization, admission, or authority.

For ViewFS, this adds four concrete anti-collapse checks to Revision 151:

1. every exposed digest/equality result names its comparison profile;
2. every dedup or duplicate-suppression result names its horizon/currentness posture;
3. every cache hit says whether it is provider-opaque, local-only, cross-principal-hidden, or safe to reveal;
4. every materialization/admission step preserves fresh object identity even when backing bytes or stable cores match.


## Revision 152 evaluation: semantic derivation and retrieval stores must not become ambient memory or authority

The SlopOS archive already contains the exact warning ViewFS needs next. Its quarantined content-index boundary rejects ambient full-text, OCR, embedding, and summary extraction from risky bytes. Its derived-attribute boundary rejects semantic back-write onto quarantined source-object metadata. Its result-preview boundary rejects automatic snippets, thumbnails, and preview panes for quarantined results.

ViewFS should generalize this beyond the quarantined case. The future shell will want semantic spines, smart folders, retrieval-backed answer cards, and agent context packs. Those should stay powerful, but each should carry enough structure to avoid becoming hidden authority.

The split to preserve:

- semantic extraction intent;
- source snapshot / input capsule;
- extractor / OCR / embedding / model / chunker / redaction profile;
- derived artifact;
- index or retrieval-store membership;
- query scope and authority gate;
- result projection and ranking evidence;
- answer / suggestion card;
- current live authority;
- receipts / history.

What to steal from SlopOS:

- risky bytes do not feed ambient semantic pipelines;
- semantic analysis output can be explicit without becoming source-object metadata;
- result rendering is a content-exposure decision, not a harmless list operation;
- derived artifacts need lineage and quarantine/trust posture;
- search and assistant memory should not become portable authority.

What to steal from the wider world:

- desktop search privacy controls and indexer/extractor separation;
- vector-store namespace/shard isolation vocabulary;
- model-profile and redaction-profile chips;
- answer cards that cite projection receipts rather than smuggling source handles;
- forget/unindex ladders that distinguish source deletion from derived-row cleanup.

What not to freeze:

- one embedding model or vector DB;
- one RAG architecture;
- one answer-card schema;
- one agent memory plane;
- one unlearning proof protocol;
- one rule that semantic output is always safe once derived.

The new guardrail: **indexed is not opened; embedded is not safe; summarized is not cleared; matched is not authority; answered is not source truth; old answer receipts are not future memory.**
## Revision 153 evaluation: instruction-like text must not become authority

The SlopOS archive is unusually strong on the next ViewFS seam. `llm-operations-posture-v0.md` says model output, prompt completions, tool annotations, hints, and retrieved text are non-authoritative inputs only. Effectful behavior must still flow through explicit schemas, validators, bindings, and approvals.

That is exactly the guardrail ViewFS needs after semantic retrieval. Search, RAG, answer cards, workspace instructions, MCP servers, prompt files, custom agents, and tool UIs can make the shell wonderful, but they also create a route for ambient prompt authority unless the lanes stay separate.

The split to preserve:

- instruction source record;
- trust/priority label;
- context frame / input capsule;
- model/prompt execution profile;
- proposal text;
- typed action plan;
- tool invocation candidate;
- approval/adoption cut;
- current live authority;
- result/observation lane;
- receipt/history.

What to steal from SlopOS:

- text is proposal-only;
- no second agent runtime execution path;
- MCP prompts/resources/tools/roots/sampling/completions/tasks/logging stay provider-local unless admitted by explicit seams;
- tool UI components are presentation/local-continuation aids, not trusted approval, file authority, browser-session authority, or model-memory authority;
- action validation should bind exact subject, action, target, authority, and preconditions outside the model.

What to steal from the wider world:

- prompt-injection and indirect-prompt-injection threat framing;
- instruction-hierarchy labels as helpful model input, not proof;
- MCP's catalog separation plus its own security warnings;
- workspace instruction/source scopes from modern IDEs;
- UI surfaces for context inclusion, omission, and approval basis.

What not to freeze:

- one prompt format;
- one instruction hierarchy;
- one model profile;
- one MCP ABI;
- one prompt-injection scanner;
- one action-plan language;
- one memory store.

The new guardrail: **data may suggest; text may propose; plans may validate; approvals may authorize; live handles may act; receipts may explain. These are different objects.**

## Revision 154 evaluation: volition and consent must not become a UI bit

The included SlopOS archive is unusually precise on this seam. `rfcs/0039-volition-tokens-and-trusted-ui-path.md` proposes a fresh local one-shot CH-VOL-style witness that binds a concrete gesture to an action digest and a canonical consent-summary digest. `volition-posture-v0.md` keeps that witness non-exportable and non-restorable in Phase 1. `powerbox-posture-v0.md`, `tool-ui-authority-boundary-v0.md`, and `llm-elicitation-boundary-v0.md` reinforce the adjacent point: rendered helper UI, model/tool requests for input, and chooser-like flows are not hidden authority paths.

ViewFS should generalize the split rather than freeze SlopOS's schema.

The split to preserve:

- consent candidate / authority diff;
- canonical consent summary;
- presentation surface record;
- trusted-path posture;
- gesture evidence;
- volition token / ceremony witness;
- approval cut / authorization grant;
- execution arm / current live authority;
- outcome / denial / cleanup;
- receipt / history.

What to steal from SlopOS:

- bind high-risk approval to exact action and summary digests;
- keep volition evidence fresh, local, one-shot, and optional by profile;
- make local mediation explicit for login/OAuth/payment/secret-entry and other sensitive elicitation;
- prevent tool UI widgets from becoming approval, file-selection, browser-session, or model-memory authority;
- use consent receipts to explain, not to reapprove.

What to steal from the wider world:

- trusted-path and user-volition traceability from EROS;
- sticky/transient/consuming activation vocabulary from web APIs;
- compositor-mediated activation-token humility from Wayland;
- Secure Attention Sequence as a classic non-spoofable credential-entry path;
- WebAuthn's separation of user presence, user verification, relying-party scope, and ceremonies;
- clickjacking/UI-redress threat framing.

What not to freeze:

- one UI root;
- one volition token format;
- one secure attention sequence;
- one exact canonical-summary grammar;
- one accessibility or remote-headless issuer model;
- one policy that all actions require local human gestures.

The new guardrail: **a button can request, a summary can inform, a surface can present, a gesture can witness, a token can bind, an approval can authorize, a live handle can act, and a receipt can explain. Do not collapse them.**
