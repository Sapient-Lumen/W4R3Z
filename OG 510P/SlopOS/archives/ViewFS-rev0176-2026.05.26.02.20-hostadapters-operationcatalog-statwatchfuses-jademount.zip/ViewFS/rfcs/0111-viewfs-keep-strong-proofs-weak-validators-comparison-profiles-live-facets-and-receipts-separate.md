# RFC-0111: Keep strong proofs, weak validators, comparison profiles, live facets, and receipts separate

Status: exploratory  
Updated: 2026-03-28

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
That combination gets easier to evolve if ViewFS freezes one more separation early:
**one exact strong proof**, **one weaker sameness validator**, **one declared comparison profile**, **one current live facet**, and **one durable receipt/history row** should not silently collapse into one hash-shaped myth.

## The separation
Keep these classes separate:
- strong proof / exact witness
- weak validator / sameness hint
- comparison profile / declared equivalence rule
- current live facet / current authority
- durable receipt / history row

Do **not** flatten them into one vague noun like `etag`, `object id`, `digest`, or `same as before`.

## Historical lesson
The past keeps rewarding different comparison strengths for different jobs:
- HTTP entity tags explicitly distinguish weak and strong validators, and strong comparison is what later conditional mutation and `If-Range` rely on.
- Amazon S3 explicitly warns that an object `ETag` may or may not be an MD5 digest of the object data, especially for multipart or some encrypted objects, while checksum lanes are separate.
- Git patch-id is intentionally a reasonably stable change-shaped key and not the whole commit object.
- SlopOS now rhymes with the same lesson: `wallet_core_digest` is a profiled/stable review key, while CH-AREF and commit digests are the exact-byte lane.

Those are all useful ideas.
They are just different ideas.

## ViewFS rule
ViewFS should preserve distinct lanes for:
1. a **strong proof** that is suitable for exact integrity, exact basis checks, and other cut-sensitive operations,
2. a **weak validator** that is useful for review, cache-ish sameness, or drift hints without claiming exactness,
3. an explicit **comparison profile** that tells us what kind of sameness we are talking about,
4. a separately bound **current live facet** when power is actually present here now,
5. a separately durable **receipt/history row** after the fact.

## Why this helps ViewFS
- It prevents one weak/stable review key from accidentally becoming an exact write gate.
- It keeps cache-ish or drift-ish sameness usable without lying about byte-perfect or representation-perfect equality.
- It lets different object families choose different comparison profiles later without pretending they all share one universal digest story.
- It gives the future shell a sharp way to say `strong proof`, `weak validator`, `compare profile`, `live facet`, and `history only` as different truths.

## What this does not decide
This RFC intentionally does **not** decide:
- one universal strong-proof digest family for all ViewFS families,
- whether every family even has a weak validator lane,
- one universal comparison-profile schema,
- whether comparison profiles are provider-owned, shell-owned, or jointly declared,
- one final shell or wire ABI for strong-vs-weak comparison metadata.

## Shell consequences
A future ViewFS shell should be able to show:
- `strong proof present`,
- `weak validator only`,
- `comparison profile changed`,
- `cannot compare under current profile`,
- `bound here now`,
- and `history only`

as different truths.

## SlopOS alignment
This matches current SlopOS unusually well because SlopOS already gives us both sides of the lesson:
- `wallet_core_digest` is intentionally smaller and more stable than the full descriptive wallet;
- CH-AREF and commit digests live on the exact-artifact lane;
- docrefs and leases add live-state and origin binding posture that cannot be reconstructed from one old digest alone.

ViewFS can therefore steal the *shape* of strong proof versus weak validator versus compare profile now while leaving exact digest families, validator carriers, and comparison-profile syntax deliberately under-decided.
