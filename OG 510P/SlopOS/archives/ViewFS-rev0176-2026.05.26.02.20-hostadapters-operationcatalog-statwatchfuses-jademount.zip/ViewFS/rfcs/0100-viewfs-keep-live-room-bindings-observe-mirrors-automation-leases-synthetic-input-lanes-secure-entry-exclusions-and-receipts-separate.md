# RFC-0100: Keep live room bindings, observe mirrors, automation leases, synthetic input lanes, secure-entry exclusions, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0107 kept **live room bindings**, **summon beacons**, **activation batons**, **foreground turns**, **secure-entry gates**, and **receipts** separate.
That remains right.

But SlopOS is also now explicit that accessibility / automation must remain leased, that observation is not injection, that high-risk UI capture and remote-control flows are portal-mediated sessions, and that secure attention / secure-input posture can clamp observation and injection without pretending the underlying room stopped existing.

That gives ViewFS one more low-regret seam to protect while the object store, shell, and import story are still moving:

**the live room binding now, the separate mirror of UI/semantic/capture state, the separate automation lease/session posture, the separate synthetic-input lane, the separate secure-entry exclusion that can clamp mirrors or injection, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `observe implies control` story,
- one fake `automation lease means global automation forever` myth,
- one fake `current frontmost room can always be mirrored or injected into` assumption,
- one shell UX that cannot distinguish `I can see`, `I can rehearse`, `I can inject`, and `secure entry blocks this now`,
- and one muddled object-store story where mirror residue starts impersonating live room authority.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, helper, or current handle is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as whether some UI mirror exists or whether automation can inject input.

### 2. Observe mirror / semantic mirror
Question:
- what exact mirror of UI or semantic state is available for inspection right now?

Examples:
- one semantic accessibility tree,
- one highlighted/focused-node mirror,
- one screen/window capture stream,
- one transcript-safe inspect strip,
- one redacted or delayed mirror.

A mirror is not the room binding itself.
It is a separately shaped view of current state.

### 3. Automation lease / session posture
Question:
- what exact leased session says observation or automation is allowed at all, for what scope, and for how long?

Examples:
- observe-only accessibility session,
- remote-support session,
- dev/test automation session,
- shell-visible lease with TTL and policy note,
- expired or revoked session.

An automation lease is not a live room binding and not the injection lane itself.
It is the reviewable, expiring posture that may enable narrower lanes.

### 4. Synthetic input lane / injection right now
Question:
- what exact lane, if any, can currently deliver synthetic input or control gestures?

Examples:
- one pointer/keyboard injection lane,
- one compositor-owned active capture/injection path,
- one rehearse-only lane with injection disabled,
- one expired or policy-clamped input lane.

This is stronger than observation.
It should stay visibly narrower than `automation` as a broad category.

### 5. Secure-entry exclusion / redaction clamp
Question:
- what exact higher-trust posture currently blocks or redacts mirrors and/or injection?

Examples:
- secure chooser active,
- secure review field focused,
- password/PIN entry clamp,
- trusted-input mode suppressing keywatchers,
- policy-only redaction while mirror stays alive.

Secure-entry exclusion is not the same thing as foreground or trusted-entry itself.
It is the narrower fact that certain automation/mirror lanes are clamped here now.

### 6. Receipt / history
Question:
- what durable artifact records that a mirror existed, an automation lease was minted/renewed/revoked, an injection lane was enabled/denied, or a secure-entry clamp was applied?

Receipts should explain prior truth without silently reviving live room bindings, observe mirrors, automation leases, input lanes, or secure-entry exclusions.

## Lessons we must learn from the past

### Observe-only and inject are different classes
XDG InputCapture explicitly distinguishes `enabled` from `active`, and the compositor decides when capture becomes active and which devices are captured.
That is a strong precedent that a request/session state should stay different from actual input delivery.

### Remote-control sessions should not dissolve into generic automation
XDG RemoteDesktop keeps the session and the eventual EIS input path separate enough that once the EIS connection exists, input must flow through that path.
That is a good precedent for a narrower synthetic-input lane instead of one flattering `automation session` blob.

### Screen or semantic mirrors are not the room itself
ScreenCast and MediaProjection both treat capture as an explicit, user-mediated session/token rather than a natural consequence of being able to see the room.
That is exactly the humility ViewFS should keep.

### Secure entry can clamp mirrors and injection without rewriting room truth
Android `FLAG_SECURE`, Windows secure desktop / UIAccess policy, and SlopOS trusted-UI posture all reinforce the same point: some surfaces become non-capturable or non-injectable during sensitive entry, but that does not erase the underlying room binding.

### Accessibility power is still privileged power
Fuchsia's accessibility manager can intercept gestures, inject input, and participate in focus changes; Windows UI Automation / UIAccess material likewise treats protected UI as a separately governed class.
That is a reminder that accessibility/assistive tooling deserves explicit, leased, shell-visible posture instead of ambient helper folklore.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **observe/semantic mirrors**
3. **automation leases / session posture**
4. **synthetic input lanes**
5. **secure-entry exclusions / redaction clamps**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one `automation` or `assistive control` object by default.

## What to steal right now
- from SlopOS: observe-only default posture, leased audited automation, secure-attention/secure-input clamps, and shell-visible indicators;
- from XDG InputCapture: `enabled` versus `active` humility;
- from XDG RemoteDesktop: explicit session-first control paths rather than hidden ambient input;
- from Android MediaProjection and `FLAG_SECURE`: user-mediated mirrors plus secure-surface redaction;
- from Fuchsia accessibility: separate accessibility focus/highlight and trusted-manager-only focus-chain truth.

## Non-decisions preserved
This RFC does **not** freeze:
- one final automation-lease schema,
- one final mirror object model,
- whether semantic mirrors and screencast mirrors share storage,
- whether synthetic input lanes are shell-owned, compositor-owned, or supervisor-owned,
- whether secure-entry exclusions live beside summon/foreground truth or in a parallel UI-policy store,
- or one final test/assistive/remote-support product taxonomy for ViewFS.
