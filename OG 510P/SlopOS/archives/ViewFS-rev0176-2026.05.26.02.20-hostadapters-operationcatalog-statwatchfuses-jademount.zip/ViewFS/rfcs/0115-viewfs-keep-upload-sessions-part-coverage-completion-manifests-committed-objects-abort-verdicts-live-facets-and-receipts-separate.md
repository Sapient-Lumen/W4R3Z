# RFC-0115: Keep upload sessions, part coverage, completion manifests, committed objects, abort verdicts, live facets, and receipts separate

## Why
A brand new object store + capability-handle system will be tempted to let one resumable upload session quietly mean too many things at once.
That is historically where storage systems get slippery.

A single `upload`-looking row may try to stand for:
- the live session or staging lane still accepting bytes,
- the current uploaded part/offset coverage,
- the assembly/completion manifest describing how finalization should happen,
- the durable committed object that only exists after a successful close/commit,
- the abort or expiry verdict,
- the currently live facet over the finished object,
- and one durable receipt/history row.

Those are neighboring truths, not one truth.

## Keep separate
ViewFS should keep these seams separately nameable:
1. **upload session** — the live resumable staging lane or upload ID/session URI.
2. **part coverage** — uploaded chunks, parts, or persisted offset/progress within that session.
3. **completion manifest** — the explicit close/assemble instruction set needed to finalize the durable object.
4. **committed object** — the durable object/store member that only exists after successful finalization.
5. **abort verdict** — explicit `aborted`, `expired`, `replaced`, `unknown`, or `history only` truth for the session.
6. **live facet** — currently usable inspect/read/edit/publish authority over the finished object, if any.
7. **receipt/history** — durable memory of session start, progress, close, abort, and commit events.

## Why this split matters
- one **upload session** can exist without any committed object yet;
- one **part coverage** row can be rich while the final object still does not exist;
- one **completion manifest** can be reviewable without being proof that finalization succeeded;
- one **committed object** can outlive the upload session that created it;
- one **abort verdict** can matter even when old parts still linger or cleanup is delayed;
- one **live facet** over the finished object should stay visibly stronger than every session/progress/abort row.

## Good pressure from the past
- Amazon S3 multipart upload is useful because it separates create-upload-ID, upload-part, complete-with-part-list, and abort, and explicitly warns clients to maintain their own part list.
- tus is useful because the resumable upload URL and current offset are session/progress truths, not the same thing as one finished durable object.
- OCI Distribution is useful because chunked blob upload has three explicit phases: obtain a session URL, upload chunks, then close the session.
- Google Cloud Storage is useful because resumable-upload session URIs are explicit session carriers, may expire, and are not the same thing as the finished object.
- Current SlopOS drafts already rhyme with the same lesson through optional persistent store / CapStore posture, digest-addressed artifact references, fresh-identity imports, and `portal.jobs` preference for deferrable uploads rather than ambient long-lived grants.

## Product shape to steal
- **session beads** that answer `open`, `resuming`, `sealed for commit`, `committing`, `expired`, or `history only`.
- **part gauges** that answer `0 parts`, `partial`, `offset known`, `assembly list ready`, `cannot prove`, or `history only`.
- **seal ladders** that answer `finalize with manifest`, `reopen session`, `abort now`, or `mint object facet`.
- **abort ash** that keeps `aborted`, `expired`, `replaced`, or `cleaned later` visible without laundering it into object truth.
- **live rails** that keep current inspect/read/edit/publish power visibly separate from every session card above.

## Non-decisions to preserve
Do **not** decide yet:
- one universal multipart/resumable upload protocol for every provider;
- one universal part/chunk numbering scheme;
- whether ViewFS exposes explicit completion manifests for every backend or synthesizes them for some;
- whether abort cleanup is synchronous, lazy, or provider-owned for every store;
- whether session ownership is shell-owned, portal-owned, helper-owned, or provider-owned.

The no-regret move is only to keep the nouns honest.
