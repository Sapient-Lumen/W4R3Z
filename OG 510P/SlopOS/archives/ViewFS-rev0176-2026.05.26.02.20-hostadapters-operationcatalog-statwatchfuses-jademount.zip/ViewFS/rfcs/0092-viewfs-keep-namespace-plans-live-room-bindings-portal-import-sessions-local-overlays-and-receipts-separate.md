# RFC-0092: Keep namespace plans, live room bindings, portal import sessions, local overlays, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0091 kept **room identity**, **current view**, **inheritance posture**, **prepared child recipes**, **child-received imports**, and **receipts** separate.
That remains right.

But one equally important seam still needs protection while both ViewFS and SlopOS remain design-stage systems:

**the plan for a namespace, the live room-local binding now, the current portal/request session that may still be mediating imports, the local-only overlay convenience state around that room, and the receipt explaining a switch/import/reset are different truths.**

If we collapse those early, we will accidentally freeze:
- one object-store schema,
- one namespace-switch wire format,
- one shell-owned overlay model,
- and one “session versus receipt” story,

before the evidence is ready.

## Distinct truths

### 1. Namespace plan
Question:
- what explicit namespace recipe, template, or switch target is being proposed or remembered?

Examples:
- one planned room-local namespace card
- one saved `switch here` basis
- one `spawn child with these named binds` plan
- one imported-fragment rehearsal

This is a plan.
It is not current live room authority.

### 2. Live room binding now
Question:
- what explicit namespace/view is this room actually bound to **right now**?

Examples:
- one current room-local root binding
- one current import mount/bind set
- one current provider projection
- one current cwd/root pairing

This is current truth.
It is not the same as the plan that proposed it, nor the same as local-only convenience chrome.

### 3. Portal import/request session
Question:
- what mediated import/open/share workflow is still alive and what stage is it in?

Examples:
- chooser/request still pending
- document/session handle still alive
- import awaiting user response
- granted-but-not-yet-bound import session

This is request/session truth.
It is not yet a live bind, and it is not only history.

### 4. Local-only overlay
Question:
- what local, rebuildable, room/device/activity-specific convenience state is layered around the live binding?

Examples:
- pane-local layout or split preference
- local receiver choice
- local shortcut or palette pin
- room-local trust posture lamp
- local filter/order/inspector choice

This is helpful local residue.
It should stay weaker than portable core namespace truth and cheap to discard/rebuild.

### 5. Anchor/reset death state
Question:
- did an old switch/import/resume anchor die, and if so, what killed it and what weaker residue still survives?

Examples:
- switch target replaced
- old import session expired
- room reset changed the active namespace epoch
- restore brought back layout but not the old exact binding basis

This is a diagnostic/honesty layer.
It is not proof that the source failed, only that one old anchor stopped being exact.

### 6. Receipt / history
Question:
- what durable artifact records that one switch/import/reset/refusal happened before?

Examples:
- switch receipt
- import receipt
- denied import receipt
- overlay-clear receipt
- reset-scope receipt

Receipts should explain prior actions without silently reviving live room binds, portal sessions, or overlays.

## Lessons we must learn from the past

### Explicit namespaces beat ambient guessing
Plan 9 made per-process namespaces a real product primitive rather than an implementation accident.
Fuchsia shows the same lesson in a capability-shaped modern system: processes receive explicit namespaces/handles and capability aggregation can stay explicit rather than ambient.
That is precedent for making namespace switches and room-local bindings inspectable instead of mysterious.

### Request/session state is not grant/bind state
Portal systems split request objects, user interaction, document/session objects, and the resulting accessibility of files or resources.
That is exactly the seam ViewFS needs for portal-mediated imports.
A pending import strip, a current live room bind, and a receipt row are different classes.

### Durable convenience lists need repair ladders and pruning discipline
Browser/file-access systems and desktop durable-access lists are useful precisely because they do **not** promise “all previous access is now ambient forever.”
They require explicit permission queries, repairs, and bounded durable state.
ViewFS should steal the repair-ladder honesty, not the assumption that durable reopen state and current live authority are the same thing.

### Great terminal UX must admit when an old anchor died
Once a shell+terminal supports room restore, review watermarks, import history, and jump-back affordances, it also needs a brutally honest `what killed this old anchor?` answer.
That is why anchor-death cards and reset-scope chips belong in ViewFS inspiration work even before a final protocol exists.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **namespace plans / switch targets**
2. **current live room bindings**
3. **portal/request session state**
4. **local-only overlays**
5. **anchor/reset death state**
6. **receipts/history**

The UI may render them adjacent, but the model should not compress them into one “room object” or one “saved import object” by default.

## What to steal right now
- **Plan 9 namespaces** (REF-PLAN9): explicit per-process assembly and replace/before/after semantics are strong evidence that namespace planning is a first-class act.
- **Fuchsia dictionary capabilities** (REF-FUCHSIA-DICTCAP): grouped authority should stay explicit and inspectable rather than showing up as inheritance soup.
- **XDG Request / Session / Documents** (REF-XDG-REQUEST, REF-XDG-SESSION, REF-XDG-DOCUMENTS): request lifetime, session lifetime, and projected restricted views should remain visibly different.
- **WICG File System Access** (REF-WICG-FSACCESS), **Windows FutureAccessList** (REF-MS-FUTUREACCESSLIST), and **Apple security-scoped bookmarks** (REF-APPLE-SECBOOKMARK-ENABLE): durable access UX only stays safe when repair, bounds, and opt-in remain explicit.
- **Helm local overlay contract**: local convenience state should be derivative, scoped, cheap to discard, and forbidden from traveling by surprise.
- **Schell anchor-death humility**: review/restore comfort must admit when the old anchor no longer survives exactly.

## What not to freeze yet
- the final object-store schema for namespace plans or import sessions;
- whether local overlays are shell-owned, terminal-owned, or supervisor-owned;
- one universal overlay object model;
- whether namespace plans and child-spawn recipes share one exact wire format;
- whether durable access items become first-class ViewFS store objects or stay portal/provider-local artifacts.
