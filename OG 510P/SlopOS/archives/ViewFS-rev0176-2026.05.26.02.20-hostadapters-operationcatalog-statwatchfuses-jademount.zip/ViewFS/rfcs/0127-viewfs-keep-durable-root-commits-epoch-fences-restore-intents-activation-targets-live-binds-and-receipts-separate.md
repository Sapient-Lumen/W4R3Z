# RFC 0127 — Keep durable root commits, epoch fences, restore intents, activation targets, live binds, and receipts separate

Status: design-phase guardrail  
Revision: 140  
Date: 2026-05-13  
Codename: rootledgers-epochfences-restorerails-ironmoss

## Summary

ViewFS should treat SlopOS's CapStore direction as an important source of design pressure, not as a final object-store or capability-persistence ABI.

This RFC keeps seven things separate:

1. **durable root commit** — a content-addressed / signed / ordered durable update to a named root or root family;
2. **epoch fence / root-tip witness** — the anti-rollback, last-seen, monotonic, or provider-currentness evidence used to decide whether a root update is admissible;
3. **restore intent** — a user, manager, portal, or recovery flow saying which old/new/root candidate it wants to inspect, repair, resume, or roll back toward;
4. **resurrection gate** — the revalidation step that decides whether dormant durable refs, sturdyrefs, portal anchors, or stored capability references may become live again;
5. **activation target** — the chosen root/session/room/namespace target that should become current at boot, launch, resume, rollback, or repair;
6. **current live bind / handle set** — the actual authority installed now after activation or restore succeeds;
7. **receipt / history** — durable evidence of the above, weaker than current live authority.

The goal is to make persistence useful without accidentally inventing a magic saved filesystem where old durable rows silently resurrect authority.

## Motivation

Revision 138 split planned launch views, bound roots, live handle slots, portal tickets, live binds, and receipts. Revision 139 split live handle inventories, custody, outflow gates, flow snapshots, leak verdicts, live exports, and receipts.

The next trap is persistence.

SlopOS already has a valuable CapStore posture: durable named roots, content-addressed commits, explicit epochs, rollback guards, sturdy references, key/secret references rather than raw secret bytes, and a strong warning that persistence is authority. ViewFS should preserve that lesson. But because ViewFS is still in design, it should not yet decide that one CapStore commit object is automatically the ViewFS object store, the durable grant database, the namespace root, the boot target, the portal permission store, and the current live handle table.

Those are different promises.

A durable root commit can exist without being safe to activate. A restore intent can be reviewed without changing live authority. An old durable descriptor can survive while its issuer, revocation epoch, portal policy, provider object, or currentness witness no longer admits resurrection. An activation target can point at a candidate state without any process currently holding handles from it. A receipt can prove the old state existed without reopening it.

## The split

### 1. Durable root commit

A durable root commit answers: **what durable root update was recorded?**

Promising shapes include:

- content-addressed commit records;
- parent pointers or ordered update rows;
- per-root or per-family root updates;
- referenced artifacts / manifests / object cores;
- signatures or provenance bindings;
- declared durability profile and GC roots;
- typed durable capability references, not raw live handles.

A durable root commit does not answer:

- whether this commit is the current accepted tip;
- whether it is safe to activate;
- whether any stored capability reference may still be reopened;
- whether a live namespace binding exists now;
- whether a user asked for this root to become current.

### 2. Epoch fence / root-tip witness

An epoch fence answers: **is this root update fresh enough, ordered enough, and not an unsafe rollback?**

Candidate witnesses include:

- monotonic per-root epoch;
- last-seen root-tip digest;
- compare-and-swap basis;
- provider generation / metageneration / ETag / revision;
- anchored monotonic counter;
- transparency-log inclusion or append proof;
- cluster consensus revision;
- issuer revocation epoch.

This is intentionally a family, not a single chosen token. Cloud object stores, consensus stores, and persistent capability systems all teach that currentness and rollback prevention are load-bearing, but each exposes different witnesses.

### 3. Restore intent

A restore intent answers: **what recovery / resume / rollback / inspect action is being asked for?**

Examples:

- `inspect old root`;
- `resume last accepted workspace root`;
- `roll back room to this checkpoint candidate`;
- `repair missing object family from provider copy`;
- `reattach portal-imported anchor if still admissible`;
- `open read-only time capsule`;
- `promote this recovered root as next boot/session target`.

The restore intent should carry caller, purpose, target candidate, basis witness, deadline, and requested live authority. It is not itself a root commit and not itself authority.

### 4. Resurrection gate

A resurrection gate answers: **may dormant stored state become live authority again?**

This is the scary part of persistent capability design.

A gate might check:

- issuer still recognizes the durable reference;
- revocation epoch has not passed;
- provider object still matches expected generation / ETag / revision;
- portal permission remains valid or must ask again;
- subject identity and room/session context still match;
- key/secret references unwrap only through current provider policy;
- object retention / legal hold / quarantine permits the requested lane;
- old descriptors are not being replayed after a rollback.

The gate is not the stored descriptor. It is the current revalidation step between stored history and live power.

### 5. Activation target

An activation target answers: **which candidate should become current for this boot, room, session, view, or process family?**

Activation is a routing/currentness decision, not mere existence of a durable commit.

Examples:

- boot profile points at root commit `R` after checking fence `E`;
- room restart chooses namespace plan `P` and root commit `R`;
- workspace repair chooses recovered head `H` but does not yet install live handles;
- rollback preview chooses old root `O` for a read-only staging room;
- portal repair chooses `ask again` rather than direct resurrection.

### 6. Current live bind / handle set

A live bind answers: **what authority is installed and usable now?**

This may include:

- bound root handles;
- per-process namespace entries;
- object-store read/edit/publish facets;
- portal-projected live handles;
- provider proxies;
- borrowed live handles;
- activation-time handle slots.

A live handle set should be derived from an accepted activation and successful gates, but it should not be confused with any stored commit or old receipt.

### 7. Receipt / history

A receipt answers: **what happened, what was checked, and what did not happen?**

Receipts should say whether a root was merely recorded, whether an epoch fence passed, whether a restore intent was denied, whether a resurrection gate asked for reconsent, whether activation succeeded, and which live slots were installed.

Receipts should not reopen authority unless a separate live restore/import/open mechanism explicitly consumes them under current policy.

## Lessons we must learn from the past

### Persistent capability systems are not a bolt-on

KeyKOS, EROS, and CapROS are inspiring because persistence and capabilities are designed together. The warning is just as important: transparent persistence changes reboot, rollback, revocation, GC, recovery, debugging, and user mental models. ViewFS should not serialize a live handle table and call it persistence.

### SlopOS CapStore is a seam lesson

SlopOS's current CapStore posture already separates durable root commits, named roots, epochs, artifact references, sturdyrefs, key/secret references, and explicit restore validation. ViewFS should steal those separations while still leaving the final storage substrate open.

### Object stores teach currentness witnesses

Amazon S3 conditional writes, Google Cloud Storage generation/metageneration preconditions, Azure Blob ETags/leases, and etcd compare transactions all say the same thing in different dialects: mutating a durable head without an expected-current witness is a footgun.

### Capability tokens teach attenuation and leakage

Macaroons, zcaps, and Tahoe-LAFS capabilities are useful vocabulary for attenuation, capability flavors, and durable designators. They also warn that bearer material and durable capability references must be handled as secrets or revalidation descriptors, not as decorative strings in logs and receipts.

### Per-process namespaces do not solve resurrection alone

Fuchsia, Plan 9, Capsicum, WASI, `openat2`, Landlock, and `unveil` all reinforce explicit roots and scoped path walking. That does not by itself decide which old durable root may be activated after a crash or rollback. Restore remains a separate ceremony.

### Qubes-style cross-domain flows are explicit for a reason

Qubes qrexec and file-copy/move flows are useful negative/positive pressure: cross-boundary transfer should be named, policy-mediated, and user-visible. A restored root should not silently reconnect old cross-domain authority just because the bytes are still present.

## Normative posture for now

Until a later RFC deliberately narrows this, ViewFS design docs and prototypes SHOULD:

- treat durable root commits as stored facts, not live authority;
- store epoch/currentness witnesses separately from object identity and root names;
- require an explicit restore intent before old state becomes a live candidate;
- run resurrection gates before dormant refs, portal anchors, or sturdyrefs become live handles;
- treat activation as a separate choice from storage and from live handle installation;
- emit receipts that say whether the result is `recorded`, `candidate`, `gated`, `activated`, `live`, `read-only`, `denied`, `stale`, or `receipt only`;
- allow read-only inspection and preview roots as safer intermediate states;
- keep rollback / resurrection warnings louder than ordinary open failures;
- avoid storing raw bearer tokens, raw live handle material, or raw secrets in durable root commits;
- preserve room for provider-specific currentness witnesses without making any one provider the universal model.

ViewFS design docs and prototypes SHOULD NOT:

- treat an old root commit as an automatic current root;
- treat a durable descriptor as a live handle;
- treat a restore receipt as a reopen token;
- treat an activation target as proof that live slots were installed;
- let crash recovery silently widen authority beyond the pre-crash live subject;
- let rollback resurrect revoked caps without an epoch/fence failure;
- let a portal permission row or stored document reference bypass current portal revalidation;
- serialize the cap-flow graph as a durable authority graph unless the persistence model explicitly says so;
- conflate backup, checkpoint, root commit, boot target, namespace bind, and live handle table.

## Low-regret tests to add later

1. **Stored root is not live** — copying a root commit into a process gives no handle.
2. **Receipt is not restore** — a receipt of prior authority cannot reopen it.
3. **Rollback needs a fence** — activating an older root without an explicit rollback lane fails closed.
4. **Reconsent survives recovery** — portal anchors that need fresh consent ask again after restore.
5. **Revoked durable ref stays dead** — a stored ref whose issuer revocation epoch advanced does not resurrect.
6. **Activation preview is weaker than activation** — previewing a root installs read-only staging authority or none.
7. **Live slots are explicit after restore** — successful activation produces a fresh slot map, not hidden ambient access.
8. **Provider-currentness mismatch is named** — generation/ETag/revision mismatch yields an explicit stale verdict.
9. **Rollback allowed is loud** — developer/test rollback mode is visible in receipts and shell chrome.
10. **Secret refs stay refs** — key/secret durable rows never contain raw secret bytes.

## Deferred decisions

This RFC deliberately does not decide:

- whether ViewFS durable roots are CapStore commits, content-addressed manifests, database rows, append-log entries, provider-native heads, or a mix;
- whether epoch fences are logical counters, transparency proofs, consensus revisions, provider generations, or hardware counters;
- whether resurrection gates live in portals, providers, ViewFS, SlopOS, or shell-managed restore harnesses;
- whether activation targets are boot-level, room-level, process-level, object-level, or all of them;
- whether live handles are kernel objects, RPC refs, userspace descriptors, provider sessions, or mixed;
- how long receipts are retained;
- whether read-only time capsules become a universal feature or just a demo lane;
- whether persistent capabilities are ever transparent, or always explicit.

## Tiny vocabulary card

Use these words carefully in future docs:

- **root commit**: durable recorded update, not current live authority.
- **epoch fence**: anti-rollback/currentness evidence, not object identity.
- **restore intent**: requested recovery action, not permission.
- **resurrection gate**: current revalidation, not stored state.
- **activation target**: selected candidate to become current, not yet a handle table.
- **live bind**: authority usable now.
- **receipt**: history, not power.
