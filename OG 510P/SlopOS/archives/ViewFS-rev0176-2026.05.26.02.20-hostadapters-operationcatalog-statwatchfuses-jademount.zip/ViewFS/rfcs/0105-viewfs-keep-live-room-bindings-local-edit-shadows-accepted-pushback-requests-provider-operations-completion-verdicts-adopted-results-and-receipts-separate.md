# RFC-0105: Keep live room bindings, local edit shadows, accepted pushback requests, provider operations, completion verdicts, adopted results, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0112 kept **live room bindings**, **local edit shadows**, **exact pushback bases/preconditions**, **provider verdicts**, **locally adopted results**, and **receipts** separate.
That remains right.

But there is one more easy collapse still waiting to happen: once a pushback or provider-backed mutation is *submitted*, systems start flattering the user again.
One request gets **accepted now**, then perhaps **queued**, then maybe one **provider operation** runs for a while, then perhaps a later **completion verdict** exists, and only then does one room choose what to **adopt locally**.
If we skip those distinctions, `accepted`, `running`, `settled`, and `adopted here` blur together.

SlopOS is still design-phase enough that ViewFS should steal the **split**, not a single final async provider protocol.
The low-regret seam is:

**the live room binding now, the separate local edit shadow, the separate accepted pushback request, the separate provider operation or completion ticket, the separate completion verdict, the separate locally adopted result, and the separate receipt/history row are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `accepted means finished` story,
- one fake `operation handle is the new object` myth,
- one fake `queued` and `completed` vocabulary that tries to fit every provider,
- one fake `provider completed it` implies `this room adopted it` shortcut,
- and one shell UX that cannot say `accepted`, `still pending`, `settled`, `expired`, `completion unknown`, `adopted locally`, or `receipt only` as different truths.

## Distinct truths

### 1. Live room binding now
Question:
- what exact thing is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as the submitted request or any later provider operation.

### 2. Local edit shadow
Question:
- what private writable shadow, draft, or upper layer is the user/tool editing locally?

Examples:
- no local shadow,
- one clean local draft,
- one submitted-but-still-editable draft,
- one sealed candidate,
- one conflict-preserved draft,
- or one history-only draft.

Local edit shadow is draft truth.
It is not the same thing as accepted or completed upstream work.

### 3. Accepted pushback request
Question:
- did the provider or gateway merely admit the exact request for later processing?

Examples:
- request rejected immediately,
- request accepted and queued,
- request accepted and delegated,
- request accepted with a poll URL / operation name,
- or request admission unknown because transport died.

Accepted request truth is admission truth.
It is not the same thing as completion truth.

### 4. Provider operation / completion ticket
Question:
- is there one bounded provider-owned operation handle, status monitor, or later-completion reference?

Examples:
- no operation lane,
- one provider-local job ID,
- one poll URL,
- one long-running operation resource,
- one expiring completion reference,
- or one unknown/lost ticket.

Operation/ticket truth is follow-up truth.
It is not the same thing as the final provider result.

### 5. Completion verdict
Question:
- what later provider-side settlement became true, if anything?

Examples:
- completed and applied,
- completed with conflict,
- completed and superseded,
- completed but later unavailable,
- still pending,
- expired/forgotten,
- or completion unknown.

Completion verdict is settled-upstream truth.
It is not the same thing as what this room adopts locally afterward.

### 6. Locally adopted result
Question:
- after request acceptance or later settlement, what local state did this room actually adopt?

Examples:
- keep the draft,
- fast-forward to the settled provider version,
- retain local draft and attach completion receipt,
- fork local state from a settled provider result,
- adopt nothing and keep history only,
- or adopt a provider-returned successor object.

Adopted result is local-consequence truth.
It is not the same thing as request acceptance, operation presence, or provider settlement.

### 7. Receipt / history
Question:
- what durable artifact explains which request was accepted, which operation/ticket existed, what completion truth was later observed, and what local adoption happened?

Receipts should explain prior truth without reviving live room bindings, edit shadows, request acceptance, operation tickets, completion verdicts, or adopted results.

## Lessons we must learn from the past

### Immediate acceptance is not final success
HTTP `202 Accepted` is intentionally noncommittal and explicitly says the request might or might not eventually be acted upon.
That is a direct warning against collapsing acceptance and completion.

### Operation handles are useful but not identity
Google-style long-running operations return an operation resource that can be polled later.
That is valuable follow-up state, but it is not the same thing as the completed object or completed mutation truth.

### Status endpoints are their own seam
Azure's asynchronous request-reply pattern is explicit that the initial endpoint can return `202 Accepted`, a location to poll, and only later does the status endpoint say pending, complete, or redirect to a resulting resource.
That is excellent shell/product guidance.

### Local adoption should stay explicit even after remote settlement
A provider can settle a request later without dictating what a particular room adopts locally.
A shell may keep a draft, fork, or fast-forward after seeing the final provider result.

### Retention/expiry matters
Long-running-operation resources and status references may expire or disappear.
That is another reason not to let an old accepted request or old operation handle masquerade as current completion truth forever.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **local edit shadows**
3. **accepted pushback requests**
4. **provider operations / completion tickets**
5. **completion verdicts**
6. **locally adopted results**
7. **receipts/history**

The UI may render them together, but the model should not compress them into one fake `save`, `sync`, or `job` object by default.

## What to steal right now
- from SlopOS: acceptance/completion posture, outcome receipts, background-request-state humility, and the refusal to let old receipts stand in for current provider-owned state;
- from HTTP: explicit `accepted now, maybe finished later` semantics;
- from Google LRO patterns: operation handles that are useful but not final truth;
- from Azure async request-reply: explicit poll/status endpoints and redirect-to-result posture;
- from existing task/progress shells: status chrome that stays smaller than object identity or durable authority.

## Non-decisions preserved
This RFC does **not** freeze:
- one universal async mutation protocol,
- one universal operation-handle schema,
- whether every provider must expose pollable status,
- whether completion verdicts are embedded in receipts or separate objects,
- whether local adoption always waits for final settlement,
- or one final mapping between operation tickets and shell progress chrome.

