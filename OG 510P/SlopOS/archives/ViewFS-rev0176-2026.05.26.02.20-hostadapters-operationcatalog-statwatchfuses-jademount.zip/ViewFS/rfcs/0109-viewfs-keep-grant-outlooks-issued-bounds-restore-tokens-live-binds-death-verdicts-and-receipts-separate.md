# RFC 0109: Keep grant outlooks, issued bounds, restore tokens, live binds, death verdicts, and receipts separate

Status: exploratory

## Why this exists

ViewFS already separates descriptors from live authority, durable reopen from live binds, request objects from sessions, and receipts from current state.
The next easy mistake is subtler: letting `query says granted`, `descriptor says this was issued`, `restore token exists`, and `something is live right now` collapse into one flattering continuity story.

That flattening will come back as soon as ViewFS has more real portal-mediated imports, more explicit per-process namespace state, more session-like helper flows, and more restart/continuity chrome.
It is worth freezing one more seam now while SlopOS is still visibly in design.

## The separation

Keep these classes separate:
- **grant outlook** — preflight posture such as `prompt`, `granted`, `denied`, `reconsent needed`, or `unknown`;
- **issued-bounds card** — one reviewed descriptor or evidence row describing what exact shape was granted/issued;
- **restore/reactivation material** — a narrower continuity aid such as a restore token, rebind recipe, or reconsent path;
- **current live bind** — authority actually installed in one room/process/session now;
- **death-state verdict** — reason-rich end states such as `revoked`, `expired`, `session closed`, `token spent`, `target changed`, or `provider unavailable`;
- **durable receipt/history row** — a non-live record that any of the above used to be true.

Do **not** flatten them into one vague `still allowed`, `reopenable`, or `live enough` story.

## Historical lesson

Several useful systems already resist this collapse:
- W3C Permissions and File System Access distinguish querying permission state from requesting permission on a handle.
- Android SAF keeps user-selected scope and persisted-permission bookkeeping explicit, and `UriPermission` exposes persisted-time metadata rather than pretending persistence itself is current use.
- XDG Request and Session separate one interaction handle from a longer-lived session handle.
- XDG RemoteDesktop separates persistence mode, a single-use restore token, and the current session.
- SlopOS now says lease/grant descriptors prove issued bounds only, not present live state.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule

ViewFS should preserve a distinct lane for:
1. preflight permission/gate outlook,
2. one reviewed issued-bounds/evidence card,
3. one explicit restore/reactivation aid,
4. one current live bind if current authority really exists,
5. one explicit death-state verdict if continuity ended,
6. one durable receipt/history row about any of those transitions.

A shell or transcript must be able to carry these rows forward without silently upgrading old evidence into current power.

## Why this helps ViewFS

- It stops `query says granted` from impersonating `a process holds a live handle now`.
- It stops `I can probably restore this` from impersonating `this is still live`.
- It makes continuity failure repairable because `revoked`, `expired`, `session closed`, and `target changed` lead to different next steps.
- It gives the future shell a much more honest vocabulary around continuity, reconsent, rebind, and history.
- It lets ViewFS stay ambitious about continuity UX without freezing one universal grant-status protocol or one universal reopen token family too early.

## What this does not decide

This RFC intentionally does **not** decide:
- whether every ViewFS family supports a queryable grant outlook;
- whether restore/reactivation material is shell-held, mediator-held, provider-held, or wallet-held;
- whether issued-bounds cards are always separate descriptors or sometimes embedded in receipts;
- whether death verdicts are authoritative provider statements, locally derived status, or mixed;
- whether there is one universal continuity/restore token family.

## Shell consequences

A future ViewFS shell should be able to show:
- `prompt`,
- `granted`,
- `issued bounds known`,
- `restore token present`,
- `bound here now`,
- `revoked`,
- `expired`,
- `session closed`,
- and `history only`

as different truths.

It should also be able to render one honest ladder that says:
`inspect outlook` → `request/reconsent` → `inspect issued bounds` → `attempt restore/rebind` → `bind here now` → `record death verdict / keep receipt only`
without implying that any earlier step silently grants the later ones.

## SlopOS alignment

This separation fits SlopOS especially well because SlopOS already keeps wallets descriptive, document handles non-bearer, lease descriptors issuance-bounded, and portal/session/request shapes explicit.
ViewFS can therefore borrow the *shape* of continuity honesty now while leaving final wallet shapes, portal restore carriers, session APIs, and object-store bindings open longer.
