# RFC-0101: Keep live room bindings, selection owners, transfer offers, manager retentions, paste capsules, materialized imports, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0108 kept **live room bindings**, **observe mirrors**, **automation leases**, **synthetic input lanes**, **secure-entry exclusions**, and **receipts** separate.
That remains right.

But SlopOS also continues to warn that transfer lanes and document lanes should not collapse together, and terminal UX keeps proving that `copied`, `offered`, `retained by a clipboard manager`, `pasted into the prompt`, and `materialized as a local object` are different truths.

That gives ViewFS one more low-regret seam to protect while the object store, per-process namespace, and portal/import story are still moving:

**the live room binding now, the separate current selection owner/source, the separate transfer offer and representation rack, the separate clipboard-manager or history retention posture, the separate paste capsule that reached this prompt, the separate materialized local import or adopted bind, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `selection owner means durable import` story,
- one fake `clipboard history means I still hold live authority` myth,
- one fake `paste into a prompt means a local object was imported` assumption,
- one shell UX that cannot distinguish `offer only`, `history ghost`, `prompt bytes only`, `materialized locally`, and `receipt only`,
- and one muddled object-store story where transfer residue starts impersonating live room authority or durable reopen state.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, helper, or current handle is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as whether some selection/clipboard offer exists.

### 2. Selection owner / current source
Question:
- who currently owns or sources the active selection/clipboard offer, if that fact is even visible here now?

Examples:
- one current clipboard owner,
- one primary-selection owner,
- one drag source for the current offer,
- one share/route sender,
- or `unknown / none`.

This is current offer-source truth.
It can disappear when focus changes, when a new selection replaces it, or when the sender goes away.

### 3. Transfer offer / representation rack
Question:
- what exact offer exists now, and what representations are being advertised for it?

Examples:
- text/plain plus text/uri-list,
- one portal file-transfer key,
- one prompt-safe text representation,
- one promised file/object offer,
- one receiver-chosen representation among many.

An offer is not yet one pasted prompt capsule and not yet one materialized local object.

### 4. Manager retention / history ghost
Question:
- did some privileged clipboard manager or history helper retain a separate copy or restorable ghost of a past offer?

Examples:
- no retention,
- terminal-local ephemeral history only,
- privileged clipboard-manager retention,
- retained representation summary without live source,
- expired or privacy-clamped retention.

This is not current owner truth and not current live authority.
It is a separate helper/history posture.

### 5. Paste capsule / prompt-local accepted representation
Question:
- what exact representation reached this prompt or pane as pasted/transferred input?

Examples:
- one bracketed-paste text capsule,
- one quoted literal insertion,
- one prompt-safe path token,
- one scratch capsule,
- one receiver-accepted representation recorded for later review.

A paste capsule is prompt-local input truth.
It is not itself one imported object or one live room bind.

### 6. Materialized import / adopted bind
Question:
- did a later explicit act materialize the transferred bytes or ref into one local object or adopted bind?

Examples:
- import created one fresh local object,
- accepted transfer became one adopted bind,
- offered file promise materialized into one staging object,
- or no materialization happened at all.

This is where local object-store consequences begin.
It should stay visibly later than `offer exists` or `prompt got bytes`.

### 7. Receipt / history
Question:
- what durable artifact records that an offer existed, one representation was accepted, a manager retained it, bytes were pasted, or an import/adoption happened?

Receipts should explain prior truth without silently reviving current selection ownership, live transfer offers, history-manager retention, prompt capsules, or materialized imports.

## Lessons we must learn from the past

### Current selection is not a durable object
Wayland data devices and primary selection both model selection as an owner-plus-offer relationship whose current offer is introduced separately and only remains valid while that state still holds.
That is exactly the warning ViewFS should keep: current offer source is not durable local identity.

### Clipboard management is a privileged helper lane
Wayland data-control protocols explicitly let a privileged client manage the selection and act as a clipboard manager.
That is a strong precedent that history retention is a special helper surface, not baseline truth about the selection itself.

### Transfer sessions are not imported objects
XDG FileTransfer makes drag/drop and copy/paste a transfer session with StartTransfer / AddFiles / RetrieveFiles / StopTransfer and an `autostop` default.
That is a very strong precedent that current transfer state, retrieved files, and later local adoption should stay visibly separate.

### Pasted prompt input is not typed input
xterm bracketed paste is valuable precisely because it lets an application distinguish pasted input from ordinary keyboard input.
That is the right shell humility for ViewFS too: `these bytes reached the prompt by paste` is its own truth.

### Rich clipboard access still deserves permission and type visibility
The Clipboard API and kitty clipboard protocol both reinforce that clipboard access is powerful enough to deserve explicit permissions and representation/type inspection.
That is good evidence for offer cards and paste capsules rather than one magical clipboard blob.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **selection owners / current sources**
3. **transfer offers / representation racks**
4. **manager retentions / history ghosts**
5. **paste capsules / accepted prompt-local representations**
6. **materialized imports / adopted binds**
7. **receipts/history**

The UI may render them together, but the model should not compress them into one `clipboard`, `paste`, or `open` object by default.

## What to steal right now
- from SlopOS: typed transfer leases, explicit document handles, and a refusal to let portal/transfer/document seams dissolve together;
- from Wayland: current owner/offer humility and the separate clipboard-manager lane;
- from XDG FileTransfer: session-first transfer with explicit retrieval and close/autostop;
- from xterm: paste-origin signaling so prompt-local safety rails can be honest;
- from kitty and the Clipboard API: type inspection, permission-gated reads, and explicit primary-selection versus clipboard posture.

## Non-decisions preserved
This RFC does **not** freeze:
- one final clipboard protocol,
- whether ViewFS exposes primary-selection-like and clipboard-like lanes separately in Phase 1,
- one final manager-retention schema,
- whether paste capsules live in the shell, terminal, or shared prompt substrate,
- whether materialized imports always create fresh local objects or can also adopt transferred live handles,
- or one final object-store layout for transfer receipts versus import receipts.
