# RFC-0096: Keep live room bindings, currentness witnesses, renewal windows, retry advice, repair gates, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0103 kept **live room bindings**, **currentness witnesses**, **semantic epochs**, **repair offers**, and **receipts** separate.
That remains right.

But one more seam matters now that ViewFS is taking portal-mediated imports, restart continuity, and a custom shell+terminal seriously while SlopOS is still design-stage:

**the live room binding now, the separate witness that says whether it is still current, the renewal window that can keep the same claim alive, the retry advice that says when a follow-up is sensible, the repair gate that says when automatic help should stop, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one keepalive/renewal contract,
- one retry/backoff vocabulary,
- one quieting-versus-repair policy,
- one auto-repair posture,
- and one flattering `it will probably come back` badge,

before the evidence is ready.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, or current handle is this room actually bound to **right now**?

Examples:
- one current projected document in the room namespace,
- one current local object bound under a room-local name,
- one current child helper import inherited from a reviewed recipe,
- one current bind redelivered by a wake kit or portal session.

This is current authority truth.
It is not the same thing as the witness that says whether it is still current, and it is not the same thing as one retry or repair policy.

### 2. Currentness witness / revocation fence
Question:
- what exact evidence says whether the current bind is still current, not revoked, not replaced, not expired, or no longer exact enough for this action?

Examples:
- one provider-side revocation epoch or generation witness,
- one portal/session freshness token,
- one holder-bound proof or step-up result,
- one watch/status carrier that says `good`, `replaced`, `expired`, `unknown`, or `refresh required`.

This is not the binding itself.
A room may still remember or even temporarily hold something while the witness says `revalidate`, `refresh`, `successor available`, or `unknown`.

### 3. Renewal window
Question:
- what exact renew-or-expire budget keeps the *same* live claim or live conversation current if it is refreshed in time?

Examples:
- one watchdog or keepalive budget,
- one portal/session renewal deadline,
- one grace window attached to a current imported capability,
- one `renewed through T` budget for a still-live room-side bind.

A renewal window is not a broader proof of health, and it is not a fresh grant.
It only says how this *same* live thing can continue without silently widening scope.

### 4. Retry advice / not-before hint
Question:
- if the next exact follow-up is not sensible now, what is the earliest useful retry moment or the exact `not before` guidance?

Examples:
- `retry after 12s`,
- `try again at 14:03`,
- `still processing`,
- `issuer has pushback until refresh`,
- `no retry advice available`.

Retry advice is timing guidance.
It is not authority, not a renewal window, and not a promise that the later retry will succeed.

### 5. Repair gate
Question:
- when repeated failure, repeated expiry, or repeated stale follow-up means automatic help should stop, what exact gate says `cool down`, `wait for explicit repair`, or `manual clear required`?

Examples:
- `cooling down`,
- `repair required`,
- `manual clear required`,
- `healthy run reset the recent-failure window`,
- `auto-renew suspended after repeated misses`.

A repair gate is not the same thing as one failed action.
It is a pattern/history judgment about when automatic retries, renewals, or rebind attempts should stop flattering the user.

### 6. Receipt / history
Question:
- what durable artifact records that a witness expired, a renewal was missed, retry advice was issued, a repair gate tripped, or a later clear/rebind succeeded before?

Examples:
- witness-refresh receipt,
- renewal-missed receipt,
- retry-advice receipt,
- repair-gate entry receipt,
- explicit-clear / manual-repair receipt.

Receipts should explain prior truth without silently reviving current authority, currentness witnesses, renewal windows, retry hints, or closed repair gates.

## Lessons we must learn from the past

### Current authority, keepalive continuity, and retry timing are different classes
Systemd keeps these ideas distinct enough to be useful:
- fdstore is an explicit manager-held exact continuity seam,
- `WATCHDOG=1` is a keepalive for the same running service,
- and timeout extension / watchdog triggering are their own messages.

That is good precedent for keeping live binds, renewal windows, and repair gates separate.

### Timing guidance should stay small and honest
HTTP `Retry-After` is a very small idea with a large benefit: it tells the client **when** to try again, not whether the object is current, not whether the client already has authority, and not whether repair is complete.

That is excellent precedent for one narrow `retry advice` seam instead of one giant retry-policy language.

### Durable-ish access and current grants are different truths
Android `UriPermission`, the web File System Access APIs, and the XDG portal stack all keep current grants, permission state, and user-mediated continuation on explicit seams.
That is strong precedent for not flattening `still have a bind`, `can renew it`, `should wait`, and `must repair` into one boolean.

### Great shell UX depends on visible state classes
Nushell overlays, WezTerm semantic zones, VS Code shell-integration quality, fish autosuggestions, and newer Ghostty shell integration features all show the same product lesson:
**helpful shell UX works best when the terminal knows which class of thing it is looking at instead of guessing from bytes.**

That is strong evidence that ViewFS should surface renewal windows, retry clocks, and repair gates as first-class shell chrome instead of hiding them behind silent loops.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **currentness witnesses / revocation fences**
3. **renewal windows**
4. **retry advice / not-before hints**
5. **repair gates / quieting state**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one `still valid / try again later` object by default.

## What to steal right now
- from SlopOS: explicit expiry / revocation posture, descriptive wallets, capability/background leases, and capability-safe shelling;
- from Steward: semantic epochs plus renewal-window, retry-advice, and repair-gate posture;
- from systemd: narrow keepalive and quieting primitives instead of one giant persistence myth;
- from HTTP: tiny retry timing hints;
- from modern terminals: visible quality/state badges instead of transcript folklore.

## Non-decisions preserved
This RFC does **not** freeze:
- one final renewal protocol,
- one final retry-budget grammar,
- whether renewal windows are provider-authored, manager-authored, or mixed,
- whether repair gates are room-local, issuer-local, or supervisor-local,
- whether retry advice can be carried inside witnesses or must stay a sibling object,
- or whether any of these eventually share storage with durable anchors or restart lockers.
