# RFC 0135: Keep network intents, resolution witnesses, connection leases, stream handles, local exposures, egress cuts, live authority, and receipts separate

## Status
Proposed.

## Problem
ViewFS is converging on an object store with capability handles, explicit per-process namespaces, portal-mediated imports, and a shell that should make authority visible. Network access is one of the easiest ways to accidentally smuggle ambient authority back into that model.

A process that cannot see a file root may still exfiltrate selected bytes if it inherits a broad socket constructor, proxy environment, resolver, DNS-over-HTTPS client, browser local-network bridge, background fetch helper, or package-update lane. A quarantined safe-open viewer may be harmless until it can phone home. A package may be admitted locally but still fetch code or telemetry later. A portal import may look read-only while its helper can resolve names, probe local devices, or upload derived artifacts.

The temptation is to add one broad **network allowed** bit. Prior systems show why that is not enough. Static sandbox permissions are useful, but broad network sharing often grants more than one intended destination. DNS and name resolution are not just metadata: search paths, IDNA mapping, SVCB/HTTPS alternate endpoints, DoH, split DNS, mDNS, Happy-Eyeballs address racing, proxies, and local-network reachability can change what **connect to this name** really means. Browser local-network defenses also show that loopback and private-network access deserve user-visible boundaries.

SlopOS already has a strong D-NETLEASE seam. ViewFS should steal the caution, not freeze SlopOS's exact schema or network stack.

## Proposal
For Phase 1 and near-term research, ViewFS should keep at least these lanes separate:

1. **Network intent** — the reviewed purpose, actor, target class, and requested operation: resolve, connect, listen, fetch, import, send, sync, update, webhook, or background refresh.
2. **Destination designator** — the user/app supplied URL, host, canonical ASCII name, service label, IP prefix, loopback class, local-network class, port, scheme, or route capsule. It is not authority by itself.
3. **Resolution witness** — a bounded record of resolver policy, canonicalization, answer family, chosen address set, TTL/epoch, and omitted facts. It explains one resolution, but does not create a dialer.
4. **Network admission cut / lease descriptor** — the local policy verdict and clamp: allowed scope, protocol family, destination predicate, port range, TTL, budget, purpose, and renewal posture.
5. **Current live network authority** — the actual live resolver, dialer, listener, stream, proxy, or portal handle that can create or carry network traffic now.
6. **Connection / stream state** — current attempt, established stream, selected address, TLS/QUIC/ALPN/SNI/client-auth facts, proxy path, byte counters, errors, and close state. This is telemetry, not a future grant.
7. **Local exposure** — listen/bind, loopback callback, local-network advertisement, mDNS/SSDP discovery, port forward, tunnel, NAT/public endpoint, or service publication. This is not the same thing as outbound connect.
8. **Egress / import materialization cut** — the decision that object-store bytes, derived artifacts, logs, diagnostics, or secret-bearing material may cross the network boundary or be materialized from it.
9. **Receipts / history** — durable evidence of requests, grants, denials, resolution witnesses, connects, uploads, downloads, budget exhaustion, revocation, and cleanup. A receipt must not reconnect.

The exact names can change. The separation should not.

## Core guardrails

### 1. Network is authority, not a default affordance
A launch namespace that omits object roots but inherits ambient sockets is not capability-clean. Network constructors, resolvers, proxies, and local-network discovery should be explicit launch inputs, portal grants, or intentionally absent.

### 2. A destination string is not a reviewed endpoint
`https://example.test`, `printer.local`, `localhost:8080`, `10.0.0.0/8`, `*.example.com`, `443`, and `service=updates` are designators. They require canonicalization and policy interpretation. They should not become portable authority without a local admission cut and current live network handle.

### 3. A DNS answer is not a capability
A resolution witness can explain what the portal saw. It does not confer a right to connect, persist as future truth, or authorize an app to use another resolver. Treat DNS, DoH, mDNS, split DNS, `/etc/hosts`, search paths, SVCB/HTTPS, SRV, and Happy-Eyeballs selection as dangerous shape-shifters until explicitly modeled.

### 4. Local network and loopback are separate surfaces
Local devices, developer servers, wallets, admin panels, routers, printers, hypervisors, SSH agents, Docker APIs, and loopback services can be high-value targets. A grant to the public internet should not silently include local-network probing or loopback callback channels.

### 5. Connect, listen, advertise, and publish are different
Outbound connect authority does not imply the ability to listen. Listening does not imply DNS publication, mDNS advertisement, NAT mapping, public tunnel creation, or long-lived service registration. Each has different privacy, reachability, and abuse implications.

### 6. Fetching bytes is not importing trust
A network stream may deliver bytes. ViewFS still needs quarantine, extraction, supply-chain evidence, object-core, currentness, and admission cuts before those bytes become trusted object-store material or executable launch inputs.

### 7. Sending bytes is not just opening a socket
Network egress can move object contents, diagnostics, secrets, traces, SBOMs, user input, or derived artifacts. The egress cut should name what crosses the boundary, not just which host was reachable.

### 8. Proxy and resolver configuration are not ambient environment
`HTTP_PROXY`, PAC, WPAD, system DNS, browser DoH, VPN path choice, and enterprise egress policy can be useful local policy. They should not silently widen the transcript-stable meaning of a ViewFS network request.

### 9. Receipts cannot reconnect
A prior successful fetch, sync, update, webhook, resolver witness, or support upload receipt is history. It should not prove the lease is still live, that the same DNS answer is still valid, or that a retry is authorized.

## Lessons to steal carefully

- Flatpak is useful because a sandbox has no network by default and then `--share=network` is a visible broad grant; the lesson is to keep the no-network baseline and avoid hiding broad grants.
- Apple App Sandbox separates client and server network entitlements; the lesson is that connect and listen are different powers.
- Android's ordinary internet permission shows that mainstream platforms often make internet access install-time/static, while Android's local-network permission work shows local network access deserves a tighter runtime/user-visible lane.
- OpenBSD `pledge` distinguishes reduced promises and separates DNS behaviors from broader internet promises; the lesson is to name resolver power.
- DNS-over-HTTPS shows that resolution can ride ordinary HTTPS-looking channels, so ViewFS should not assume “no UDP/53” means “no resolver.”
- SVCB/HTTPS DNS records and Happy-Eyeballs show that one hostname may lead to alternate endpoints, transport parameters, and raced address choices; a reviewed name is not one stable socket.
- WICG Private Network Access and Chrome Local Network Access show that public-to-private and public-to-loopback requests need explicit treatment because browser code can otherwise reach behind a user's firewall.
- SlopOS D-NETLEASE, CH-NETREQ/CH-NETLEASE, resolver-binding boundaries, proxy boundaries, and local-egress boundaries are strong sibling-cube precedent. ViewFS should reuse the seam vocabulary while leaving final schema ownership open.

## What not to decide yet

Do not freeze yet:

- one final ViewFS network lease schema;
- one network stack, firewall, VPN, microVM gateway, or proxy architecture;
- one canonical URL parser or hostname normalization profile;
- one DNS transport, DoH/DoT policy, split-DNS story, or mDNS/SSDP discovery story;
- one TLS verifier, certificate-exception, client-certificate, ALPN, SNI, ECH, or QUIC profile;
- whether fetch/import is a network subsystem, object-store subsystem, portal subsystem, or a composed workflow;
- whether broad internet access is ever acceptable for compatibility launch rooms;
- whether local-network discovery is a portal, a device lease, a network lease, or a separate discovery object;
- whether SlopOS CH-NETREQ/CH-NETLEASE becomes the ViewFS-native descriptor format.

The low-regret decision is only this: network intent, destination shape, resolution witness, lease/admission cut, live network authority, stream state, local exposure, egress/import materialization, and receipts are different truths.

## Adoption test
A future ViewFS proposal touching network access should answer:

- Is this changing network intent, destination designators, resolution witnesses, admission cuts, live network authority, stream state, local exposure, egress/import materialization, or only receipts?
- Can the actor resolve names, connect, listen, advertise, publish, proxy, tunnel, or only request a portal flow?
- Does a public-internet grant include local-network or loopback reachability?
- What canonicalization is reviewed, and what resolver/proxy/path facts are explicitly omitted?
- What object-store bytes, derived artifacts, logs, traces, secrets, or diagnostics can cross the network boundary?
- What happens after TTL expiry, budget exhaustion, DNS drift, connection close, revocation, portal policy change, or safe-open disposal?
- What remains in history, and can any history item be replayed into current network authority?

If a proposal says **network allowed** while hiding resolver choice, local-network reach, proxy path, background uploads, or listen/publication authority, it is too broad.
