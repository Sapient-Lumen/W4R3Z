# RFC 0130 — Keep container envelopes, member claims, extraction plans, materialization roots, namespace commits, live opens, and receipts separate

Status: design-phase guardrail  
Revision: 143  
Date: 2026-05-14  
Codename: extractplans-membercapsules-pathguards-coralvault

## Summary

Revision 142 made risky-content laundering visible. The next trap is **archive/container extraction laundering**: an archive member name, link target, device entry, whiteout, permission bit, xattr, duplicate entry, or decompressed byte count can quietly become namespace authority if the system treats `extract` as a boring file operation.

This RFC keeps eight things separate:

1. **container envelope** — the ZIP/TAR/package/image/bundle object and its top-level format, digest, origin, compression, signature, and quarantine posture;
2. **member claim** — what the container says each internal entry is named, typed, linked to, sized as, permitted as, timestamped as, extended with, or layered over;
3. **extraction plan** — a reviewed, normalized, policy-filtered plan that decides which claims may materialize, which are denied, which are rewritten, and which conflicts or resource budgets apply;
4. **sterile materialization root** — a private, disposable, uncommitted root where bytes and metadata can be expanded without publishing into any live namespace;
5. **extracted member capsule / fresh object birth** — one newly minted object or capsule for an admitted member, carrying lineage and quarantine rather than inheriting ambient path truth;
6. **namespace commit / adoption** — an explicit act that publishes a selected materialized object, tree, projection, or bundle into one ViewFS view;
7. **current live open / mount / executable surface** — the actual authority to inspect, read, edit, run, mount, or traverse materialized content now;
8. **receipt / history** — durable explanation of inspection, rehearsal, deny, rewrite, materialization, publication, cleanup, and live-open grants, weaker than authority and weaker than retention.

The goal is not to freeze a final archive format, unpack service, package manager, OCI-image story, or virtual-mount ABI. The goal is to prevent the future ViewFS object store and shell from accidentally treating untrusted member names or unpack side effects as capabilities.

## Motivation

Archives are small object stores with worse habits. They carry names, file types, link targets, timestamps, permissions, owner fields, sparse ranges, duplicate entries, compression claims, extended attributes, ACLs, device entries, whiteouts, and sometimes executable startup semantics. Every one of those fields is useful. Every one can be dangerous if it is interpreted directly against the host namespace.

Classic failure modes include:

- `../` or absolute member names escaping the chosen destination;
- symlink or hardlink entries causing later members to write outside the extraction root;
- duplicate names making the previewed member differ from the extracted member;
- device nodes, FIFOs, setuid bits, ACLs, xattrs, or platform metadata reappearing as stronger authority than the user reviewed;
- archive bombs exhausting space, memory, inodes, path depth, or CPU;
- container-layer whiteouts or rename semantics being mistaken for ordinary deletion in a ViewFS namespace;
- same-digest archive reuse laundering a fresh origin or quarantine story;
- extracted members inheriting ambient trust because the parent archive was merely opened or indexed;
- a successful extraction receipt being treated as a future reopen grant.

ViewFS should make unpacking feel first-class and calm, not scary. But it should never make member strings into authority.

## The split

### 1. Container envelope

A container envelope answers: **which aggregate object are we inspecting?**

Candidate envelope fields:

- container object digest and format family;
- origin evidence and quarantine posture;
- container-level signatures, checksums, or manifests;
- compression families and streaming requirements;
- declared member count, compressed size, expected expanded size, and resource-class hints;
- whether the envelope is a simple archive, layered filesystem image, application bundle, package, backup, disk image, or unknown aggregate.

The envelope is not a namespace and not a live mount. A signed archive is still not permission to publish its member names into a process view.

### 2. Member claim

A member claim answers: **what does the container assert about one internal entry?**

Candidate claim fields:

- raw member name as bytes/text and decoded view;
- normalized display path, if any;
- entry kind: regular file, directory, symlink, hardlink, device, FIFO, sparse file, whiteout, metadata-only, manifest-only, or unsupported;
- link target or whiteout target;
- compressed size, uncompressed size, offset/range evidence, and checksum if present;
- mode/permission/owner/time/xattr/ACL/platform metadata;
- duplicate-name/collision group;
- parent/child lineage for nested containers.

A claim is not an object birth and not a publication request. It is evidence to be filtered.

### 3. Extraction plan

An extraction plan answers: **what would happen if we materialized this container under this policy?**

It should include:

- selected members and denied members;
- path normalization and escape verdicts;
- symlink/hardlink/device/FIFO/xattr/ACL/setuid/whiteout policy;
- duplicate/collision treatment;
- quarantine propagation and trust inheritance posture;
- resource budgets for expanded bytes, entries, depth, sparse extents, CPU, temporary storage, and time;
- destination mode: sterile preview, new object tree, overlay projection, import bundle, package install, or read-only mount;
- currentness witness for mutable source envelopes;
- expected result summary and non-goals.

The plan is not yet materialization, namespace mutation, or live authority. It is the moment to review the scary parts before bytes land.

### 4. Sterile materialization root

A sterile materialization root answers: **where can expansion happen without touching the live namespace?**

Properties worth preserving:

- private to one request/session unless explicitly adopted;
- no ambient host path access;
- no follow-through symlink/hardlink escape;
- cleanup/lease/budget visible;
- quarantine default preserved;
- publish/adopt must be a separate act;
- old root after cleanup is receipt-only, not reopen authority.

The root may be backed by a temporary object store, an isolated VM/container, a provider-owned scratch area, or a pure virtual projection. ViewFS need not decide yet.

### 5. Extracted member capsule / fresh object birth

An extracted member capsule answers: **which admitted claim became which fresh local object or capsule?**

Each admitted member should get its own lineage:

- parent envelope digest;
- member claim digest;
- extraction plan digest;
- normalized target name, if any;
- assigned fresh object identity or virtual projection identity;
- inherited quarantine/risk state;
- materialization proof or error;
- whether it is publishable, inspectable only, or denied.

This is where the classic same-bytes trap matters: equal content can still have different origin, quarantine, and member-lineage stories.

### 6. Namespace commit / adoption

A namespace commit answers: **what selected result is now visible through a ViewFS name/bind/view?**

It must stay separate from extraction because publication choices are policy choices:

- publish all admitted members into a fresh object tree;
- publish one selected member;
- bind a read-only archive view;
- import as a package/bundle object;
- mount a layered image as a restricted root;
- keep only a derived sanitized artifact;
- discard the materialization.

A namespace commit should have conflict/currentness witnesses and should not inherit member raw paths by default.

### 7. Current live open / mount / executable surface

A live open answers: **what can be exercised now?**

Important distinctions:

- container inspected but not materialized;
- extraction plan reviewed but not run;
- sterile root live for preview only;
- selected member object live for read;
- extracted tree published but read-only;
- helper has a mounted/projection root now;
- executable entry admitted to safe-open only;
- receipt only, no current live surface.

The shell should render these states without making `unpacked` look like `trusted`, `published`, or `runnable`.

### 8. Receipt / history

A receipt answers: **what happened, with which warnings and which denied powers?**

Good receipts record envelope inspection, member claim digests, rejected entries, path rewrites, budget decisions, materialization roots, cleanup, namespace commits, and live-open grants. They must avoid raw bearer tokens, hidden provider paths, and unredacted risky snippets. They must not become reopen grants, retention roots, or trust clearances by themselves.

## Lessons we must learn from the past

### Zip Slip: member names are attacker input

The Zip Slip class is the canonical warning: archive extraction code that joins a destination path with attacker-controlled member names can write outside the intended directory and even reach code-execution paths. ViewFS should never place raw member names directly into a live namespace.

### TAR/ZIP extraction is many hazards, not just `../`

Modern libraries increasingly expose extraction filters or insecure-path warnings because archives can contain absolute names, traversal, symlinks, hardlinks, devices, sparse files, owner/mode bits, and metadata that do not fit a naive copy loop. That is exactly the evidence for a ViewFS extraction plan rather than a direct `unpack here` verb.

### Safe defaults are good, but ViewFS should not depend on one library default

Python's tarfile default extraction filter moved toward safer behavior in Python 3.14, but the same documentation still warns that untrusted archives require prior inspection. Go added GODEBUG-controlled insecure-path checks for tar/zip while preserving earlier behavior by default for compatibility. The lesson is that ViewFS should make path-guard posture explicit in the object model and shell, not bury it in a runtime toggle.

### OCI images separate manifest, config, layers, and unpack

OCI image format is a good aggregate-object precedent: manifests, indexes, descriptors, layers, configuration, signatures, and runtime bundles are distinct. ViewFS should steal the separation, not assume every container-like object is already a live filesystem root.

## SlopOS pressure to import

The included SlopOS archive already gives ViewFS useful adjacent posture:

- `quarantine-posture-v0.md` keeps risky origin state monotonic and object-local;
- `open-untrusted-materialization-boundary-v0.md` keeps safe-open materialization stable and request-local;
- `open-untrusted-viewer-residue-boundary-v0.md` keeps preview residue disposable-local unless exported;
- `quarantined-content-index-boundary-v0.md` blocks ambient content-derived indexing of risky bytes;
- `capshell-cwd-root-posture-v0.md` rejects `..`, absolute paths, and symlink escapes against an ambient root for compat path resolution;
- `artifact-reference-schema-v0.md` keeps digest/reference truth separate from retrieval and runtime folklore.

ViewFS should extend those instincts to archive members and layered containers: member names are claims, not capabilities.

## Design pressure on future object-store API

A future API should leave room for these questions without answering them too early:

- Are archives exposed as virtual read-only trees, materialized object trees, or both?
- Are path rewrites represented as new names, sidecars, receipts, or plan transforms?
- How are duplicate entries, case-folding collisions, Unicode normalization, and platform-reserved names handled?
- Do xattrs, ACLs, ownership, device nodes, FIFOs, sparse extents, and whiteouts become first-class object facts, denied claims, or provider-local metadata?
- Which extraction plans require a disposable VM or micro-sandbox?
- Can a container image become an executable root without a distinct launch-view plan and handle-slot table?
- Which receipts are safe to export without leaking filenames, origin, member contents, or hidden provider paths?

## Guardrails

- `member name` is not `namespace authority`.
- `archive opened` is not `members trusted`.
- `member listed` is not `member materialized`.
- `plan reviewed` is not `bytes extracted`.
- `sterile root exists` is not `published bind`.
- `same bytes` is not `same origin or trust`.
- `symlink/hardlink claim` is not `permission to follow`.
- `whiteout claim` is not `delete from current view`.
- `extraction receipt` is not `reopen grant`, `retention root`, or `trust clearance`.
