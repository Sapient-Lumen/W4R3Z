# RFC-0095: Keep live room bindings, currentness witnesses, semantic epochs, repair offers, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0101 kept **durable import anchors**, **live room bindings**, **stale shadows**, **repair plans**, and **receipts** separate.
Revision 0102 kept **activation kits**, **restart lockers**, **namespace pins**, **live room bindings**, and **receipts** separate.
That remains right.

But one more seam matters now that ViewFS is taking room-local namespace truth, portal-mediated imports, restart continuity, and custom shell/terminal semantics more seriously while SlopOS is still design-stage:

**the live room binding now, the separate witness that says whether that binding is still current, the shell/terminal semantic epoch that says whether old observations still belong to this semantic world, the bounded repair offer surfaced to the user, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one revocation/currentness model,
- one stale-action fence model,
- one shell semantic epoch contract,
- one repair UX vocabulary,
- and one misleading `still valid` badge,

before the evidence is ready.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, or current handle is this room actually bound to **right now**?

Examples:
- one current projected document in the room namespace
- one current localized object bound under a room-local name
- one current child helper/process import inherited from a reviewed recipe
- one current view binding delivered via a wake kit or portal session

This is current authority truth.
It is not the same thing as the witness that says whether it is still current, and it is not the same thing as one historical receipt.

### 2. Currentness witness / revocation fence
Question:
- what exact evidence says whether a live binding is still current, not revoked, not replaced, not expired, or no longer exact enough for this action?

Examples:
- one provider-side revocation epoch or generation witness
- one portal/session freshness witness
- one holder-bound currentness proof or step-up token
- one watch/status carrier that says `good`, `replaced`, `expired`, `unknown`, or `refresh required`

This is not the binding itself.
A room may still remember or even temporarily hold something while the currentness witness says `revalidate`, `refresh`, `successor available`, or `unknown`.

### 3. Semantic epoch / hop lineage
Question:
- does this observation, anchor, or command block still belong to the same semantic world and same hop path the shell thinks it is acting in?

Examples:
- one pane-local semantic epoch after resync or shell restart
- one hop-lineage token after ssh/tmux/domain changes
- one target anchor that expected the previous epoch
- one precision fence that says old semantic certainty no longer applies

This is observational shell truth.
It is not provider-side revocation truth, and it is not room authority by itself.

### 4. Repair offer
Question:
- what exact bounded next move is being offered to the user now that the live binding, currentness witness, or semantic epoch no longer line up well enough?

Examples:
- `revalidate now`
- `refresh witness only`
- `reconsent via portal`
- `rebind from durable anchor`
- `make local copy instead`
- `rerun clean in a fresh room`

A repair offer is not the same thing as a full repair plan, and it is not a hidden automatic fix.
It is one user-visible, reviewable proposal that may consume or consult other seams.

### 5. Receipt / history
Question:
- what durable artifact records that a witness expired, an epoch shifted, a revalidation ran, a repair offer was accepted, or a rebind failed before?

Examples:
- witness-refresh receipt
- epoch-shift receipt
- reconsent receipt
- rebind-after-successor receipt
- stale-action refusal receipt

Receipts should explain prior truth without silently reviving current authority, currentness witnesses, or old semantic epochs.

## Lessons we must learn from the past

### Current authority and currentness are not the same thing
SlopOS already points in the right direction:
- `CH-DOCREF v0` includes explicit expiry and an optional `rev_epoch`,
- the document-portal posture says revoked, expired, or replaced targets fail closed on reopen,
- and capability wallets are descriptive rather than authority-bearing.

That is strong evidence that ViewFS should keep one live room bind separate from one currentness witness.

### Request/session lifetime and resulting accessibility are different classes
The XDG portal stack keeps request objects, longer-lived session objects, and resulting document accessibility on distinct seams.
That is strong precedent for not flattening `request still alive`, `binding still current`, and `user should repair or reconsent` into one boolean.

### Shell semantic truth must admit epoch shifts instead of flattering stale certainty
Steward is exploring exactly the right shell discipline:
- semantic epochs,
- hop lineage,
- target anchors,
- precision fences,
- and chrome lanes.

That is strong evidence that ViewFS should keep provider currentness truth separate from shell semantic currentness truth.
A binding may still be provider-current while the shell admits that one old anchor belongs to an older semantic world.

### Great shell UX depends on semantic zones, not just bytes
WezTerm shell integration and newer Ghostty shell-integration features show how much terminal UX improves when prompt zones, command blocks, cwd, and status are explicit rather than scraped from bytes.
That is not the same thing as current authority or currentness proof.
It is the observational substrate that lets the shell stay honest.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room binding now**
2. **currentness witness / revocation fence**
3. **semantic epoch / hop lineage**
4. **repair offer**
5. **receipt/history**

The UI may render them together, but the model should not compress them into one `still valid room binding` object by default.

## What to steal right now
- **SlopOS CH-DOCREF + document portal posture**: expiry, optional `rev_epoch`, fail-closed reopen, and explicit persistence are the right currentness instincts.
- **RFC 7662 / RFC 7009 / RFC 6960 precedent**: status/introspection/revocation style material is a different class than the bearer or certificate-like object itself.
- **Steward semantic-epoch / hop-lineage / target-anchor discipline**: stale shell actions need their own fence vocabulary.
- **WezTerm + Ghostty shell integration**: prompt zones, command blocks, cwd reporting, and command-finished chrome are the right substrate for truthful UI.
- **Nushell overlays**: explicit layers are delightful precisely because activation state is visible.
- **Schell anchor-death humility**: when an old exact action point died, say so rather than silently targeting `latest`.

## What not to freeze yet
- the final currentness-witness schema;
- whether provider currentness is epoch-shaped, challenge-shaped, status-object-shaped, or several of them;
- whether semantic epochs are room-local, pane-local, hop-local, or layered;
- whether repair offers are provider-authored, shell-authored, or assembled from both;
- whether some repair offers are safe to pre-stage automatically before the user accepts them;
- whether a future stale-action fence should require one holder-bound fresh-intent step for higher-risk verbs.
