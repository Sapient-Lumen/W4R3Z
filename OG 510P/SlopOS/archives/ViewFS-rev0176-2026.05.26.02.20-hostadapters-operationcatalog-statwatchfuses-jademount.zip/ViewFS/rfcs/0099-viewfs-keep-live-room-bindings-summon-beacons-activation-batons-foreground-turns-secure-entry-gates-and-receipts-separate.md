# RFC-0099: Keep live room bindings, summon beacons, activation batons, foreground turns, secure-entry gates, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0106 kept **live room bindings**, **attention cues**, **interrupt grades**, **quiet windows**, **ack ledgers**, and **receipts** separate.
That remains right.

But SlopOS is also now very explicit that host-owned display changes are not a hidden focus/foreground authority plane, that trusted entry lives on a narrower secure-UI seam, and that activation/bring-to-front requests are not the same thing as current frontmost truth.

That gives ViewFS one more low-regret seam to protect while the object store, shell, and portal story are still design-stage:

**the live room binding now, the narrower beacon that says this room wants to be surfaced, the separate activation baton that says it may try to surface, the separate foreground turn that says it actually has focus/frontmost status now, the separate secure-entry gate that says a higher-trust input path is active, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one flattering `attention means foreground soon` story,
- one hidden `fullscreen/modal means trusted` myth,
- one fake `activation token means the raise definitely happened` assumption,
- one shell UX that cannot distinguish `wants eyes`, `may raise`, `actually frontmost`, and `secure entry`,
- and one muddled object-store story where visibility chrome starts impersonating authority.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, helper, or current handle is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as whether the room wants to be surfaced or whether it is frontmost.

### 2. Summon beacon / surface-me cue
Question:
- what exact signal says this room, helper, or review card wants to be surfaced to the user?

Examples:
- a background room finished a command and wants a glance,
- a helper wants its result card surfaced,
- a reviewed rebind offer wants the room header reopened,
- a terminal domain wants a glance without claiming focus.

A summon beacon is visibility/request truth.
It is not proof of focus, not proof of successful activation, and not trusted-entry state.

### 3. Activation baton / raise eligibility
Question:
- what exact narrow artifact says this room or helper may try to bring something to the foreground?

Examples:
- one freshly minted activation token,
- one transferred foreground privilege,
- one recent-user-action proof tied to a click or prompt action,
- one baton that can expire, be rejected, or be consumed.

An activation baton is not the foreground turn itself.
It is narrower, often expiring, and may fail.

### 4. Foreground turn / frontmost truth
Question:
- what exact state says this room, pane, tab, or helper is actually frontmost and focus-receiving **now**?

Examples:
- room currently selected in the shell,
- terminal pane currently focused,
- window brought to front and receiving keyboard input,
- requested raise that was declined or stolen back.

Foreground turn is current presentation/input truth.
It is not the same thing as a summon beacon or an activation baton.

### 5. Secure-entry gate / trusted-input mode
Question:
- what exact narrower state says the user is in a visually distinct trusted-input path for a high-risk action?

Examples:
- secure entry for consent/login/review,
- trusted chooser/powerbox path,
- shell-controlled high-risk action that intentionally defers to a host-owned secure mode.

Secure-entry state is not just `focused now`.
It is a separate, higher-trust posture.

### 6. Receipt / history
Question:
- what durable artifact records that a summon happened, an activation baton was minted or spent, a foreground request was declined or accepted, or a secure-entry gate was entered and exited?

Receipts should explain prior truth without silently reviving live room bindings, summon beacons, activation batons, foreground turns, or secure-entry state.

## Lessons we must learn from the past

### Activation proof is not foreground truth
Wayland xdg-activation lets one client request a token and forward it to another, but the compositor may still ignore an invalid token or refuse activation when the token is stale or lacks recent-enough user action.
That is an excellent precedent because it keeps `may ask` separate from `frontmost now`.

### Delegated foreground privilege is still only privilege
Windows is equally explicit: `AllowSetForegroundWindow` and `CoAllowSetForegroundWindow` pass the privilege to try foregrounding, and the privilege can expire or still fail to produce the foreground window.
Again, `may try` is not `did happen`.

### Trusted entry is not ordinary focus chrome
SlopOS already refuses to let fullscreen/modal/widget presentation silently become trusted UI or secure-entry truth.
That is exactly the lesson ViewFS should steal.
A pane being large, visible, or frontmost does not mean it is the trusted approval/login path.

### Focus signals are useful, but they are just signals
Terminals like xterm can emit focus-in/focus-out events, which is very useful for shell polish.
But those signals should stay weaker than activation/foreground/secure-entry truth.
The shell should use them for chrome, not for wishful authority claims.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **summon beacons / surface-me cues**
3. **activation batons / raise eligibility**
4. **foreground turns / frontmost truth**
5. **secure-entry gates / trusted-input mode**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one `focus / alert / activation / trusted` object by default.

## What to steal right now
- from SlopOS: no-hidden-foreground discipline, host-owned modal honesty, and secure-entry separation;
- from Wayland xdg-activation: transferable activation proof that can still be declined;
- from Windows foreground APIs: passable foreground privilege that is narrower than actual focus;
- from xterm focus events: lightweight focus-change signals for shell chrome;
- from Ghostty / WezTerm / VS Code shell integration: prompt-aware and focus-aware UI chrome that still admits quality limits.

## Non-decisions preserved
This RFC does **not** freeze:
- one final summon-beacon schema,
- one final activation-baton carrier,
- whether foreground-turn truth is shell-owned, terminal-owned, or host-owned,
- whether secure-entry gates live in the same store as receipts,
- whether room tabs and helper cards share the same summon taxonomy,
- or one final `focus manager` product surface for ViewFS.
