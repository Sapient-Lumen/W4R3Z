# RFC-0108: Keep action authority, payer roots, budget leases, spend reservations, charge verdicts, and receipts separate

Status: Draft  
Updated: 2026-03-24

## Summary
The next low-regret seam for ViewFS is not a richer object-store payment protocol.
It is a narrower honesty story:
**action authority ≠ payer root ≠ budget lease ≠ spend reservation/admission ≠ charge verdict ≠ provider effect/adoption ≠ receipt/history**.

That split matters because SlopOS is now explicit enough about budget leases, payer selection, and no-ambient-sponsorship posture that ViewFS can safely learn the lesson **without** freezing one final meter schema, one final budget-lease carrier, or one final charging pipeline.

## Why this seam matters now
ViewFS already separates:
- action plans from approvals and results;
- provider admission from later completion;
- exact pushback basis from provider verdict and local adoption;
- retry sameness witnesses from request identity and settlement.

But there is still one dangerous collapse left:
- the shell can start treating `may perform this action`, `may spend this sponsor`, `reserved budget exists`, `actual charge landed`, and `history says something expensive once happened` as one vague `allowed / paid` blob.

SlopOS points the other way.
Its budget work insists on **explicit payer linkage**, **no ambient current payer**, **attenuation-only budget delegation**, and transcript-visible sponsorship.
That is exactly the humility ViewFS should steal.

## The distinction to preserve
When a room kicks off a metered action, ask seven different questions:
1. **What current live room bind / object authority made the action legal?**
2. **What payer root or sponsor would be charged if the action proceeds?**
3. **Is there a current budget lease or sponsorship ticket, and what exactly does it bound?**
4. **Was any spend/reservation/admission accepted yet?**
5. **What is the current charge verdict?** pending, partially spent, charged, charge rejected, provider-paid, or unknown?
6. **What provider effect or local adoption actually followed?**
7. **What only survives as receipt/history now?**

Those are not the same truth.

## Lessons we must learn from the past

### 1. Access control and billing are different seams
Requester Pays on Amazon S3 and Google Cloud Storage is unusually crisp:
- access still requires normal permissions;
- the requester must explicitly accept/declare billing posture;
- storage charges and access charges can still land on different parties;
- multi-request flows can have their own billing-project rules.

That is a direct warning against treating `can read this` as proof of `will pay for this` or `already paid for this`.

### 2. Authorization and resource ceilings are different seams
Kubernetes is also blunt:
- RBAC answers whether a subject may ask for an action;
- ResourceQuota answers how much aggregate resource a namespace may consume;
- quota failures reject requests even when authorization would otherwise allow them.

That is excellent evidence that ViewFS should not let authority handles silently impersonate spend/budget truth.

### 3. Execution identity and CPU budget can be separate objects
seL4 MCS keeps scheduling contexts separate from threads and even allows scheduling-context donation across RPC-style calls.
That is a wonderful precedent: the thing that lets work run and the budget that fuels that work can be distinct objects with their own lineage.

### 4. Resource donation can ride its own session/property lane
Genode's session model treats resource donation as a session property that can be successively shaped by the process hierarchy.
That is a good hint that sponsorship/budget posture can stay explicit and reviewable instead of hiding in one thread-local account register.

### 5. Hierarchical resource control is not portable payer identity
Linux cgroup v2 is clear that it organizes processes hierarchically and distributes resources along that hierarchy, with restrictions that only tighten deeper in the tree.
That is useful implementation inspiration, but it is not proof that `current container / current subtree` is the right portable answer to `who pays?`.

## Promising shape
ViewFS probably wants distinct conceptual rows such as:
- **ActionAuthority** — what current bind/handle/policy posture makes the act legal?
- **PayerRoot** — what sponsor account, meter, or explicit payer lineage would cover costs?
- **BudgetLease** — what exact bounded spend ticket is available now?
- **SpendReservation** — what pre-admission or admitted spend/reserve record currently exists?
- **ChargeVerdict** — charged, partially charged, denied, owner-paid, requester-paid, expired, unknown?
- **EffectOrAdoption** — what provider-side effect happened and what did this room adopt locally?
- **ChargeReceipt** — what only survives as explanation/history now?

The names can change.
The split should stay.

## Shell consequences
This seam gives the custom shell some gorgeous honest chrome:
- **payer chips** for `requester pays`, `owner pays`, `server budget`, `unknown sponsor`, or `no spend lane`;
- **budget braids** that show parent budget, narrowed child lease, delegated spend, or detached server sponsorship;
- **spend rails** for `not reserved`, `reserved`, `partially spent`, `spent`, `charge rejected`, `provider absorbed`, or `history only`;
- **charge ghosts** that preserve earlier spend/charge truth without reviving a live sponsor;
- **burn ladders** that keep `preview cost`, `reserve`, `commit spend`, `retry with same sponsor`, and `switch payer` visibly different;
- **sponsored-by drawers** that explain who paid, why, and under what explicit lease.

That is exactly how to make the shell feel magical without turning cost/sponsorship into hidden ambient folklore.

## What not to decide yet
- one universal payer-root schema for all ViewFS families;
- one universal budget-lease format or meter unit family;
- whether spend reservations and final charge verdicts share IDs or only receipts/history links;
- whether payer selection always belongs to the caller, the provider, or a reviewed negotiation lane;
- whether budget/state lives in the ViewFS object store at all versus only on adjacent provider seams.
