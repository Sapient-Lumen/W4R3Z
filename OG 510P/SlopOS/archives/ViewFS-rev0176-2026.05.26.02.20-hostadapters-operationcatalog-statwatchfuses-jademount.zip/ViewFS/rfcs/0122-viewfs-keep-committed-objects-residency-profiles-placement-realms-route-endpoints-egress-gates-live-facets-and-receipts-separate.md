# RFC-0122: Keep committed objects, residency profiles, placement realms, route endpoints, egress gates, live facets, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
Recent revisions already separated durability, archive/thaw posture, and storage-health truth.
One more low-regret seam now looks load-bearing:

- a **committed object** (`this durable thing exists`)
- a **residency profile** (`where this thing is supposed to live or not live`)
- a **placement realm** (`where copies or authoritative backing currently exist`)
- a **route endpoint** (`which site/endpoint/region a read or write path is currently using`)
- an **egress gate** (`whether this action may cross a residency or locality boundary`)
- a **live facet** (`what this process can actually do right now`)
- and a **receipt/history row**

should stay visibly different.

This matters while SlopOS is still in design because the easiest mistake now would be to let one `region`, `nearest endpoint`, or `replicated` badge silently become all of:
object identity, compliance posture, read route, export permission, and current authority.

## The separation

Keep these classes separate:

1. **Committed object** — the durable object or version record.
2. **Residency profile** — intended data-boundary posture such as `same realm only`, `dual realm`, `provider hidden`, or `compliance bounded`.
3. **Placement realm** — current storage or authoritative-placement truth such as `region A only`, `A+B`, `provider hidden`, or `unknown`.
4. **Route endpoint** — current access path truth such as `served from A`, `nearest route`, `secondary read`, `provider hidden`, or `history only`.
5. **Egress gate** — whether copying, exporting, or binding across one boundary is permitted, denied, or needs explicit review.
6. **Live facet** — inspect/read/edit/publish power currently held here.
7. **Receipt/history** — durable evidence that one placement, route, or egress verdict once existed.

Do **not** flatten them into one vague story like `the object is in Europe`, `the endpoint is global`, or `closest copy wins`.

## Historical lesson

The storage ecosystem keeps making the same distinction.

Amazon S3 replication separates the logical object from same-region or cross-region copy spread, and Multi-Region Access Points can route a request to the closest bucket even when that bucket does not hold the object unless replication has already put a copy there.
Google Cloud Storage dual-region buckets separate bucket location, paired-region replication, and bucket replication policy / RPO.
Azure geo-redundant storage separates secondary-region existence from whether secondary reads are enabled, and also warns that asynchronous replication can leave the secondary behind the primary.
Ceph CRUSH goes even deeper by separating logical object IDs from topology-aware placement rules.

ViewFS should steal that honesty.

## ViewFS rule

ViewFS should preserve distinct lanes for:
- durable object truth,
- residency-policy truth,
- current placement-realm truth,
- current routed-endpoint truth,
- cross-boundary egress truth,
- current live authority,
- and history/receipt truth.

The shell should be able to say:
- `committed object exists`,
- `residency policy says EU pair`,
- `copies currently in us-east-1 and eu-west-1`,
- `request currently routed through nearest endpoint`,
- `cross-boundary export denied`,
- `secondary read allowed`,
- `live read facet here now`,
- or `receipt only`.

## Why this helps ViewFS

- It prevents one routing badge from impersonating compliance or placement truth.
- It prevents one residency label from pretending to be current readable route.
- It prevents cross-boundary export/import from being laundered into ordinary open/read affordances.
- It gives the shell a principled way to be luxurious about locality without lying.
- It leaves room for wildly different backends without forcing one final region/site taxonomy now.

## Shell consequences

A future ViewFS shell should be able to render:
- `realm badge`
- `placement ghost`
- `route halo`
- `egress shutter`
- `live rail`
- `receipt only`

as visibly different layers.

The default UX should stay conservative:
- showing where an object is *intended* to live should not imply it is readable from there now,
- showing one current route should not imply all copies are current,
- and showing a nearest/global endpoint should not imply cross-boundary export is approved.

## What this does not decide

This RFC intentionally does **not** decide:
- one universal region / jurisdiction / realm taxonomy,
- whether placement realms are exact, redacted, or policy-hidden,
- whether route endpoints are always inspectable to users,
- one universal egress-policy language,
- whether residency profiles live on objects, containers, stores, or adjacent policy seams.

## SlopOS alignment

This separation fits SlopOS unusually well because SlopOS already has nearby but distinct draft seams for:
- non-authoritative cluster maps,
- explicit replication contracts,
- artifact references that keep exact identity distinct from locator folklore,
- and CapStore commit posture that keeps durable object birth explicit.

ViewFS can therefore borrow the *shape* of residency-versus-placement-versus-route now, while leaving placement APIs, provider exposure, and compliance taxonomy open longer.
