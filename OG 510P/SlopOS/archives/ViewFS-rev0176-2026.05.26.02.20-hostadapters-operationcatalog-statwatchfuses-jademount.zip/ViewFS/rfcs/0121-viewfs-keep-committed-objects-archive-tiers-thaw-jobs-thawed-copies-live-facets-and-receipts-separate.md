# RFC-0121: Keep committed objects, archive tiers, thaw jobs, thawed copies, live facets, and receipts separate

Status: Draft  
Updated: 2026-03-28

## Why
ViewFS is inching toward a brand-new object store, capability handles, explicit per-process namespaces, and portal-mediated imports.
One very likely mistake would be to flatten `the durable object`, `the current cold/archive posture`, `the in-flight thaw or rehydrate request`, `the temporary or rehydrated readable copy`, `the current readable/editable facet`, and `the historical receipt` into one flattering noun like “stored object” or “restored file”.
Past systems keep warning us that:
- a **committed object** can already exist durably while still being offline for ordinary reads;
- an **archive tier** or equivalent cold posture can separately say `archived`, `cold`, or `offline` without saying the object is gone;
- a **thaw job** can separately say `requested`, `pending`, `priority high`, or `failed` without becoming the object itself;
- a **thawed copy** can separately say `temporary readable copy`, `rehydrated online copy`, or `expiry known` without becoming semantic object identity;
- a **live facet** is still stronger than every archive/thaw/history row;
- and a **receipt/history row** should remember restore, expiry, or rehydrate facts without reviving present authority.

## Separation to keep
Keep separate:
- **committed object** — one durable object record that exists now;
- **archive tier** — one current storage-class or offline/online posture row;
- **thaw job** — one requested or in-progress restore / rehydrate action;
- **thawed copy** — one temporary or rehydrated readable realization created by that thaw job;
- **live facet** — currently usable inspect/read/edit/publish authority over that object;
- **receipt/history row** — evidence that one archive move, thaw request, thaw completion, expiry, or rehydrate failure happened.

## Why this is low-regret
This split lets ViewFS stay ambitious without freezing too much too early.
It preserves room for:
- providers whose cold tiers are offline and require explicit thaw;
- providers whose thaw creates a temporary readable copy versus providers whose thaw changes the object's tier;
- providers that expose explicit expiry dates and providers that only expose current status;
- room-local or machine-local hot realization layered on top of provider-local cold storage;
- and richer shell UX around `archived`, `rehydrating`, `temporary copy until …`, `copy thawed`, `tier changed`, and `history only`.

## External pressure
- Amazon S3 shows that archived objects are not accessible in real time, that restore is an explicit operation, and that for Glacier classes the restored readable copy can be temporary with an expiration date.
- Amazon S3 also shows that a restore request and a restore-status row are separate from the object version itself.
- Azure Blob Storage shows that archive-tier blobs are offline and unreadable until rehydrated.
- Azure also shows two different thaw shapes: copy to a new online blob or change the archived blob's tier to hot/cool, which is a strong reminder that `rehydrated` is not one universal object-store action.
- SlopOS already rhymes with this because import/materialize boundaries, CapStore commit meaning, and lease-descriptor posture all keep durable object meaning, current live use, and historical receipts on different seams even though SlopOS does not yet settle a cold-tier / thaw lifecycle family.

## What to steal
- **frost badges** instead of one flattering `available` bit,
- **thaw beads** instead of pretending restore jobs are the object,
- **copy-thaw ladders** instead of hiding whether rehydration made a temporary copy, changed tier, or failed,
- **live rails** that remain visibly stronger than every archive/thaw/history row,
- **expiry lanterns** that keep `temporary readable until …` distinct from durable object identity.

## What not to decide yet
Do not decide yet:
- one universal archive-tier taxonomy across all ViewFS providers and object families;
- whether thawed readability is represented as a temporary copy, tier mutation, or provider-specific virtual view;
- whether thaw jobs are explicit first-class objects or folded into provider operation rows;
- whether thaw expiry is provider-local, room-local, or represented only in receipts;
- one final receipt format for archive moves, thaw requests, or thaw-completion state.
