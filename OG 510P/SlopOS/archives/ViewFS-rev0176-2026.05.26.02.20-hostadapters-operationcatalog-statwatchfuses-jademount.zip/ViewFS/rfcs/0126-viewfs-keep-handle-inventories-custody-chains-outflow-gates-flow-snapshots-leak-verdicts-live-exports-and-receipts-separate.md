# RFC 0126 — Keep handle inventories, custody chains, outflow gates, flow snapshots, leak verdicts, live exports, and receipts separate

Status: design-phase guardrail  
Revision: 139  
Date: 2026-05-13  
Codename: flowmaps-custodybadges-leakalarms-silverloom

## Summary

ViewFS should steal the best part of SlopOS's capability-graph work without accidentally turning a debug graph, audit row, UI badge, or receipt into live authority.

This RFC keeps seven things separate:

1. **handle inventory** — the live authority slots currently held by a subject;
2. **custody chain** — the local explanation of how a handle was minted, imported, attenuated, delegated, borrowed, copied, or restored;
3. **outflow gate** — the policy posture for whether the handle may leave this subject and by which mechanism;
4. **flow snapshot / flow diff** — a bounded, redacted, explanatory graph of authority before, after, or across an operation;
5. **confinement / leak verdict** — a test or analyzer result about whether authority stayed inside the expected boundary;
6. **live exported handle / proxy / borrow** — the actual present authority that another subject can use now;
7. **receipt / history** — durable evidence that something happened, weaker than present power.

The purpose is not to choose the final ViewFS object-store or capability ABI. The purpose is to prevent early design notes, shell chrome, and test artifacts from collapsing these lanes before SlopOS and ViewFS have enough evidence.

## Motivation

Revision 138 separated launch view plans, bound roots, handle slots, portal import tickets, live binds, and receipts. That solves only the first half of the problem: a process can be launched with an explicit namespace and handles.

The next problem is what happens after launch:

- a portal import adds a directory handle;
- a helper process receives a narrowed object-store writer;
- a UI preview is lent a read-only live facet;
- a remote service gets a proxy rather than the raw handle;
- a shell command exits, but some handle remains live;
- a receipt claims a delegation happened, but no current handle exists anymore;
- a cap graph says authority existed in a redacted snapshot, but the graph itself must not become authority.

SlopOS already has unusually useful pressure here: capability graph snapshots, capability diffs, capability export descriptors, capability wallet summaries, capshell handle-table posture, and portal design rules. ViewFS should adopt the posture, not blindly import the exact schemas.

## The split

### 1. Handle inventory

The handle inventory is the current table of live handles held by a subject. It answers: **what can this subject use now?**

It must be runtime-local unless explicitly materialized through a separately defined mechanism. It may contain slot names, class tags, rights summaries, revocation posture, live/dead state, and local debugging labels.

It must not be confused with:

- custody history;
- graph snapshots;
- audit receipts;
- path names;
- durable reopen descriptors;
- provider object identities;
- permission-store rows.

### 2. Custody chain

The custody chain answers: **how did this handle arrive here?**

Examples:

- created by this subject;
- inherited from the launch plan;
- bound from a root badge;
- imported through a portal consent ceremony;
- attenuated from another handle;
- borrowed from a parent process;
- proxied from a provider;
- restored from a durable descriptor after an explicit reopen ceremony.

Custody explanations are crucial for debugging confused-deputy cases, but they are not themselves permission to use an object.

### 3. Outflow gate

Every handle class should eventually have an explicit outflow posture. Candidate gates include:

- `non_passable` — cannot leave this subject;
- `same_authority_room_lend` — can be lent only to explicitly related subjects and must remain borrow-shaped;
- `child_launch_only` — can be passed only through launch-plan construction;
- `portal_mediated_export` — can leave only through a portal ceremony;
- `proxy_only_remote` — remote recipients get a proxy endpoint, not the original handle;
- `bytes_only_materialize` — only content bytes or a derived artifact may leave;
- `receipt_only` — only an audit row or proof may leave.

This list is a vocabulary sketch, not the final ABI.

### 4. Flow snapshot / diff

Flow snapshots and diffs are bounded, redacted, explanatory artifacts. They answer:

- what changed between two launch/import/export states?
- why does this subject still have authority after the operation?
- which handle crossed which trust boundary?
- did a child process receive exactly the intended root and slots?
- did the portal grant widen access compared with the preview?

They must be deterministic enough for tests and receipts, but they must not contain raw secrets, raw kernel pointers, long-lived bearer strings, or stable identifiers that become a tracking layer.

### 5. Confinement / leak verdict

A leak verdict is an assertion produced by a test, analyzer, debugger, or policy engine. It says something like:

- `expected_closed_handle_still_live`;
- `unexpected_outflow_gate_widened`;
- `portal_import_not_bound_to_named_subject`;
- `raw_path_escape_attempt_blocked`;
- `receipt_without_live_power`;
- `live_power_without_receipt`.

A verdict is not the confinement mechanism. It is evidence about whether the mechanism behaved.

### 6. Live exported handle / proxy / borrow

A live export is present power in another subject. It may be a direct handle, a borrowed handle, a revocation-aware proxy, a one-shot send right, a provider-local capability, or another form we have not designed yet.

The live export must be explicit because receipts and diffs can outlive it. A receipt that says `exported at 10:04` must not imply `export remains usable at 10:12`.

### 7. Receipt / history

Receipts are durable evidence. They support accountability, replay-resistant debugging, and review. They are weaker than current live authority and weaker than exact provider state.

A receipt can prove that a portal granted a handle, an export gate was checked, a child launch received a slot set, or a leak analyzer passed. It cannot by itself reopen authority unless a separate reopen/import/restore mechanism says so.

## Lessons we must learn from the past

### Confused-deputy lesson

Never accept a bare path, label, or object name as sufficient authority. Keep caller identity, purpose, authority source, and custody chain visible. This is the old confused-deputy lesson in ViewFS clothing.

### Capability URL lesson

Bearer strings are powerful and leak-prone. ViewFS should avoid rendering raw capability material in logs, terminal output, screenshots, filenames, telemetry, or receipts. Human-visible summaries should be redacted, digest-shaped, or non-authoritative.

### Fuchsia / Plan 9 / Capsicum / WASI lesson

A process namespace can be explicit and per-process; ambient global lookup is not sacred. But explicit namespaces are not enough if live handle flow after launch becomes invisible. ViewFS should combine explicit launch roots with runtime handle-flow accounting.

### seL4 / Cap'n Proto / WIT lesson

Capability tables, live object references, owned handles, and borrowed handles are different ideas. ViewFS should steal the distinctions without assuming one kernel, RPC system, or component model.

### Sandstorm / XDG portal lesson

Imports from outside the sandbox should be mediated, reviewable, and audit-friendly. The mediator should return handles/descriptors, not ambient path strings that silently widen later.

### `openat2`, `unveil`, and Landlock lesson

Compatibility layers and host fallback paths will exist. They must be treated as constrained escape hatches with visible root/resolve/unveil/landlock posture, not as the semantic core of ViewFS.

### Object-store and transaction lesson

Currentness witnesses matter. Mutating, adopting, exporting, or reopening authority should be able to say what revision/generation/etag/token it believed it was acting against, and what happened when that belief was stale.

## Normative posture for now

Until a later RFC deliberately narrows this, ViewFS design docs and prototypes SHOULD:

- name live handle inventories separately from custody history;
- keep graph snapshots and diffs redacted and non-authoritative;
- attach some outflow posture to every handle family under discussion;
- keep portal/session/import tickets separate from the live imported handle;
- distinguish direct export, borrowed export, proxy export, bytes-only materialization, and receipt-only export in diagrams;
- make leak/confinement verdicts evidence artifacts, not ambient permission rules;
- avoid raw path strings as authority in shell examples;
- avoid raw bearer tokens in any durable receipt or visible shell surface;
- store enough currentness witness vocabulary to support compare-before-mutate/import/export later.

ViewFS design docs and prototypes SHOULD NOT:

- treat a cap graph snapshot as a serialized capability set;
- treat a receipt as a reopen token;
- treat a custody explanation as proof of current power;
- treat a policy verdict as enforcement;
- treat a UI badge as ground truth;
- treat a shell path as a durable object identity;
- treat a portal permission-store row as a live handle;
- treat one provider's object generation, ETag, revision, or handle type as the universal ViewFS model.

## Deferred decisions

This RFC deliberately does not decide:

- the final handle-table ABI;
- whether handles are kernel objects, userspace descriptors, RPC references, object-store tokens, or a mix;
- whether custody chains are stored inline, sidecar, or reconstructed from receipts;
- how much of a flow graph is visible to ordinary users versus developers;
- whether outflow gates are enforced by static type, runtime policy, portal ceremony, provider rules, or all of them;
- whether leak verdicts belong in SlopOS assurance, the shell, the object store, a policy engine, or separate test harnesses;
- the final schema for capability snapshots/diffs/exports.

## Shell obligations

The shell should eventually make these distinctions legible:

- a **slot map** for current live handles;
- **custody badges** for how each handle arrived;
- **outflow gates** for whether it can leave and how;
- **flow diff drawers** for launch/import/export changes;
- **leak sirens** when expected authority remains live;
- **audit drawers** for receipts that are no longer live power.

The UI goal is not more chrome. The goal is to make the dangerous states visible before users and developers build habits around invisible authority.

## Local evidence and adjacent docs

- `docs/30-architecture/handle-inventories-custody-chains-outflow-gates-flow-snapshots-leak-verdicts-live-exports-and-receipts.md`
- `docs/70-shell/flow-maps-custody-badges-outflow-gates-leak-sirens-and-audit-drawers.md`
- `rfcs/0125-viewfs-keep-launch-view-plans-bound-roots-handle-slots-portal-import-tickets-live-binds-and-receipts-separate.md`
- `slopos/docs/30-architecture/capability-graph-schema-v0.md`
- `slopos/docs/30-architecture/capability-diff-schema-v0.md`
- `slopos/docs/30-architecture/capability-export-schema-v0.md`
- `slopos/docs/30-architecture/capability-wallet-schema-v0.md`
- `slopos/docs/60-engineering/portal-design-playbook.md`

## References

- `REF-CONFUSED-DEPUTY-HARDY`
- `REF-W3C-CAPURL`
- `REF-FUCHSIA-NAMESPACE`
- `REF-FUCHSIA-CAPS`
- `REF-CAPSICUM`
- `REF-WASI-CAPS`
- `REF-SEL4-CSPACE`
- `REF-CAPNP-RPC`
- `REF-WIT-RESOURCE-HANDLES`
- `REF-SANDSTORM-POWERBOX`
- `REF-XDG-DOCUMENTS`
- `REF-XDG-PERMISSION-STORE`
- `REF-OPENAT2`
- `REF-OPENBSD-UNVEIL`
- `REF-LINUX-LANDLOCK`
- `REF-S3-CONDITIONAL-WRITES`
- `REF-GCS-PRECONDITIONS`
- `REF-AZURE-BLOB-CONCURRENCY`
- `REF-ETCD-TXN`
