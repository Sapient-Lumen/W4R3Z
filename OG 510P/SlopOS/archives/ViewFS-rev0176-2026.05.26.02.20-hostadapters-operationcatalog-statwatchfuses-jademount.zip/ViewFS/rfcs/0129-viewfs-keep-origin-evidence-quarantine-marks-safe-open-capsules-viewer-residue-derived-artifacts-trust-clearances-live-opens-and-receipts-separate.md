# RFC 0129 — Keep origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, live opens, and receipts separate

Status: design-phase guardrail  
Revision: 142  
Date: 2026-05-13  
Codename: quarantinecapsules-residuelamps-trustreceipts-amberreed

## Summary

Revision 141 made object-store liveness explicit. The next trap is **quarantine laundering**: a risky object can slip from portal import to preview, search index, thumbnail cache, assistant summary, sanitized export, trusted derivative, recent item, or executable open unless the datacube keeps the intermediate states visible.

This RFC keeps eight things separate:

1. **origin evidence** — provenance and arrival-route facts, such as download, email, transfer, paste, capture, archive extraction, CH-SREF/CH-CAPX import, or provider-local handoff;
2. **quarantine mark / risk hold** — object-local handling state saying that the object remains risky, review-needed, safe-open-only, code-blocked, content-index-blocked, or unknown;
3. **safe-open capsule** — request-local materialization of one exact source into a disposable or constrained review lane;
4. **viewer residue / data exhaust** — thumbnails, MRU rows, autosave, crash recovery, OCR caches, extracted text, embeddings, summaries, preview bitmaps, and search snippets created while inspecting risky content;
5. **derived or sanitized artifact** — a new object produced by explicit export, sanitize, disarm, transcode, extract, or summarize workflows;
6. **trust clearance / override decision** — a narrow, explicit, receipted change to how one source or derivative may be handled;
7. **current live open / execution authority** — the actual ability to hand an object to a full viewer, interpreter, helper, or runnable surface now;
8. **receipt / history** — durable explanation of import, safe-open, clear, deny, export, sanitize, quarantine propagation, and residue cleanup, weaker than retention and weaker than live authority.

The goal is not to freeze a final malware, notarization, active-content, indexing, or sanitize API. The goal is to prevent the future ViewFS object store, shell, and portal model from accidentally treating `previewed once`, `indexed once`, `deduplicated once`, `exported once`, or `receipt says safe-open succeeded` as `trusted and live forever`.

## Motivation

Portal-mediated imports are a gift and a danger. They make it possible to localize foreign content into a capability-native object store, but they also create many places where a system can launder risk:

- an explicit import token becomes a fresh local object and somebody says `explicit token == trusted bytes`;
- a safe-open viewer writes thumbnails or MRU rows outside the disposable and somebody treats that as durable reopen state;
- an indexer extracts text, OCR, embeddings, summaries, or snippets from quarantined bytes and somebody treats the semantic sidecar as harmless;
- a search result shows the quarantined source through a derived artifact by hidden lineage join;
- a same-digest cache hit aliases new risky bytes onto an older trusted object;
- a sanitized export keeps the source identity or overwrite destination and erases the provenance boundary;
- a clear decision is path-wide, recursive, policy-hidden, or silently triggered by a successful open;
- an old receipt says a viewer opened safely and later code treats that receipt as live open authority.

SlopOS is already unusually disciplined here. Its D-QUAR posture says quarantine is monotonic by default, clearing is manual-only and object-local, safe-open does not mutate trust in place, ordinary kept output remains a new artifact, and viewer/index/derived-result boundaries must not become hidden laundering lanes. ViewFS should steal that discipline directly, while still remaining design-phase and decision-light.

## The split

### 1. Origin evidence

Origin evidence answers: **where did this object or derivative come from, and through which bounded workflow?**

Candidate fields may include:

- source class: `network`, `email`, `portal-import`, `transfer`, `paste`, `capture`, `archive-entry`, `provider-sync`, `local-tool`, `unknown`;
- route: portal family, import ticket, chooser request, transfer offer, extraction run, drag/drop, safe-open export, sanitizer run, or copy/fork lineage;
- parent digest or source receipt digest when known;
- locator hints that are explicitly non-authoritative and redaction-aware;
- source epoch/currentness evidence when the source is mutable.

Origin evidence is not trust, not permission, not possession, and not a durable reopen grant. It is a witness for humans and policies.

### 2. Quarantine mark / risk hold

A quarantine mark answers: **what handling constraints follow this object right now?**

Useful states include:

- `quarantined`;
- `review needed`;
- `safe-open only`;
- `metadata-discoverable only`;
- `active content blocked`;
- `code-bearing input blocked`;
- `clear requested`;
- `cleared for document open`;
- `cleared for this helper`;
- `cleared for execution`;
- `policy denied`;
- `unknown / provider hidden`.

The mark should be object-local and monotonic by default. Copy, extract, derive, repackage, bind into a workspace, add to recents, or launch a safe-open viewer should not silently clear it. Equal bytes should not inherit trust just because a previous local object with the same digest was cleared.

### 3. Safe-open capsule

A safe-open capsule answers: **what exact stable input did the disposable or constrained viewer receive for this request?**

A good capsule records:

- one exact source object/ref at decision time;
- materialization class: staged copy, read-only snapshot, provider export, inert projection, reconstructed object, or sanitized prepass;
- disposable / sandbox / review lane identity;
- active-content posture;
- allowed egress lanes;
- output treatment;
- cleanup obligations;
- basis witnesses and expiry.

The capsule is not a trust clearance and not a live alias back to the source. Source mutation, revocation, or replacement after materialization should affect future opens and explicit publish/replace flows, not silently retarget the already-running capsule.

### 4. Viewer residue / data exhaust

Viewer residue answers: **what side effects did inspection create?**

Examples:

- thumbnails and preview images;
- MRU / recent-doc rows;
- autosave and crash-recovery files;
- extracted text, OCR, embeddings, model summaries, and search snippets;
- per-viewer caches;
- temporary unpacked contents;
- telemetry or diagnostic bundles;
- helper-local scratch state.

Residue is hazardous because it feels harmless. A thumbnail can leak content. A vector embedding can preserve sensitive semantics. An MRU row can become a reopen hint. A crash-recovery file can become a second, less-guarded copy of the document. ViewFS should treat residue as a first-class lane: disposable-local by default, metadata-safe when exposed, and persisted only through explicit export/keep workflows.

### 5. Derived or sanitized artifact

A derived artifact answers: **what new object was produced from risky input?**

Examples:

- safe-open kept output;
- content-disarmed document;
- extracted text file;
- OCR output;
- embedding or summary object;
- image thumbnail intentionally exported;
- unpacked archive member;
- transcoded media;
- schema-normalized data;
- explicitly sanitized report.

Derived artifacts need their own identity, origin, quarantine/default handling, parent evidence, and receipts. Ordinary derived output should remain quarantined by default unless a distinct sanitizer/clear workflow says otherwise. `new object` is safer than `same object, trust bit flipped`.

### 6. Trust clearance / override decision

A trust clearance answers: **which human or policy decision changed handling constraints, and with what scope?**

It should say:

- who/what authorized it;
- source object or derivative identity;
- exact scope: preview, edit, macro, network callback, helper launch, code input, full execution, workspace use, publication, or export;
- basis: signature, notarization, scan, reputation, policy, manual review, or emergency override;
- expiry and revocation posture;
- whether the decision applies only to the source, only to one derivative, or to a bounded class.

The default should be narrow and object-local. Broad trusted folders, recursive archive clears, and invisible policy auto-clear should remain high-burden future choices.

### 7. Current live open / execution authority

A live open answers: **what can be exercised now?**

Important combinations:

- origin known + quarantined + no live open;
- quarantined + safe-open capsule live;
- safe-open capsule ended + receipt only;
- derived artifact live for preview but source still quarantined;
- cleared for document edit but not for macros;
- cleared for one helper but not for shell execution;
- live execution allowed now but no durable future clearance.

The shell should render these differences instead of showing one generic `open` or `trusted` state.

### 8. Receipt / history

A receipt answers: **what happened, under which basis, and what did not follow from it?**

Good receipts record imports, propagation, safe-open materialization, inert-view decisions, blocked active content, residue cleanup, derived artifact creation, trust clearances, denials, and live-open grants. They must not contain raw bearer tokens, private source locators, secret provider IDs, or enough data to reconstruct risky content. They also must not become reopen grants, retention roots, or trust decisions by themselves.

## Lessons we must learn from the past

### macOS: quarantine and Gatekeeper are useful, but not magic

macOS quarantine metadata and Gatekeeper show that origin/risk state should be visible to the platform and checked before risky launch. They also warn that bypasses and inconsistent propagation are real, so ViewFS should not rely on one hidden xattr-like bit as the whole story.

### Windows: Mark-of-the-Web is valuable because applications use it differently

Zone-of-origin metadata, Office macro blocking, Protected View, and Application Guard show why one origin marker must drive different handling lanes: read-only document preview, macro denial, isolated open, full trust, and execution are different decisions. ViewFS should not flatten them.

### Browsers: warnings, reputation, and download danger are advisory layers

Safe Browsing and browser dangerous-download UX show the value of layered warnings and risk categories, but they should inform ViewFS policy rather than become the object store's identity or trust model.

### Portals and SAF: mediated access does not imply trusted content

XDG Documents and Android SAF are strong portal/document-access precedents, but selected/imported is not the same as trusted. A chooser can say `the user chose this object`; quarantine still decides what operations are safe.

### SlopOS D-QUAR: the most stealable idea is anti-laundering discipline

The best SlopOS lesson is not one final schema. It is the posture: fresh local object on import, quarantine-first, safe-open as request-local stable materialization, inert-by-default viewers, no durable viewer residue outside the disposable, no ambient semantic indexing, no hidden derived-match resurfacing, and new-artifact exports with parent evidence.

## Failure modes to test later

- An archive extraction loses quarantine on child entries.
- A same-digest dedupe path maps newly imported risky bytes onto a previously cleared object.
- A safe-open viewer writes a host MRU row that later becomes a reopen handle.
- A thumbnail or OCR sidecar escapes the disposable and leaks content.
- An embedding generated from a quarantined file appears in semantic search as if the source were cleared.
- A derived artifact match causes the quarantined source to appear in smart-folder results by hidden lineage join.
- A sanitized export overwrites the original destination in place and inherits trusted identity.
- A clear decision for preview is reused as execution authority.
- A receipt saying `opened safely` is treated as current live-open authority.

## Minimal prototype posture

A useful prototype can start with:

- one origin receipt shape;
- one object-local quarantine mark;
- one `open safe` capsule shape;
- one residue ledger that defaults to disposable-local;
- one derived-artifact parent link;
- one narrow trust-clear receipt;
- one live-open facet badge;
- one `why quarantined?` shell command.

That is enough to test the seam without deciding the final malware scanner, notarization integration, embedding store, content disarm system, or portable quarantine schema.
