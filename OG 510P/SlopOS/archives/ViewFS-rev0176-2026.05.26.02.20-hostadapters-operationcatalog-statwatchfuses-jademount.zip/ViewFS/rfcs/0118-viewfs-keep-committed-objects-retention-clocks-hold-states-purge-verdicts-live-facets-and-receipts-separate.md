# RFC-0118: Keep committed objects, retention clocks, hold states, purge verdicts, live facets, and receipts separate

Status: Draft  
Updated: 2026-03-28

## Why
ViewFS is inching toward a brand-new object store, capability handles, explicit per-process namespaces, and portal-mediated imports.
One very likely mistake would be to flatten `durably exists`, `cannot be deleted yet`, `is under an investigation/regulatory hold`, `will be purged later`, and `is usable right now` into one flattering noun like “locked object”, “archived object”, or “protected file”.
Past systems keep warning us that:
- a **committed object** can already exist durably;
- a **retention clock** can separately say `may not be deleted or replaced until later`;
- a **hold state** can separately say `keep this regardless of the clock` or `wait for some event before the clock starts to matter`;
- a **purge verdict** can separately say `eligible`, `blocked`, `pending lifecycle`, or `purged`;
- and a **live facet** is still stronger than every retention/hold/history row.

## Separation to keep
Keep separate:
- **committed object** — the durable object or object version that exists now;
- **retention clock** — one retain-until or equivalent deletion/replacement fence over that committed object;
- **hold state** — one temporary, event-driven, legal, or similar keep barrier independent from ordinary object birth;
- **purge verdict** — one later deletion, lifecycle, GC, or `still blocked` outcome;
- **current live facet** — current inspect/read/edit/publish/delete power over the object;
- **receipt/history row** — evidence that one commit, hold change, retention change, purge attempt, or purge completion happened.

## Why this is low-regret
This split lets ViewFS stay ambitious without freezing too much too early.
It preserves room for:
- version-scoped protection rather than only name-scoped protection,
- editable versus locked retention policies,
- temporary versus event-based versus legal/investigation holds,
- lifecycle or policy-driven purge lanes,
- and richer shell UX around `retained until`, `hold present`, `purge blocked`, `purge pending`, `purged`, and `history only`.

## External pressure
- Amazon S3 Object Lock shows that legal holds are independent from retention periods, can remain until explicitly removed, and apply to object versions.
- Google Cloud Storage object holds show that temporary holds and event-based holds are not the same thing, and that event-based holds interact differently with retention timing.
- Google Cloud Storage Object Retention Lock shows that object-level retain-until posture, mode/lock posture, lifecycle deletion, and editable metadata are distinct truths.
- Azure immutable storage shows that legal holds can be scoped separately, can require tags/audit logs at some scopes, and keep WORM posture separate from general object existence.

## SlopOS pressure
Current SlopOS material rhymes with this even though it does not settle a full retention family yet:
- `rfcs/0065-orthogonal-persistence-and-capstore.md` keeps durable existence explicit instead of ambient;
- `rfcs/0114-verified-blobs-and-merkle-integrity.md` keeps immutable content identity explicit rather than smearing it across mutable policy state;
- `docs/30-architecture/receipt-replication-boundary-v0.md` keeps evidence/history from reviving present truth;
- the broader archive keeps policy, evidence, and current live authority on different seams.

## Shell posture worth stealing
The shell should be able to say:
- `committed object`
- `retained until ...`
- `temporary hold`
- `event hold`
- `legal hold`
- `purge blocked`
- `purge pending`
- `purged`
- `history only`

…without pretending these are the same class.

## Do not decide yet
Do not decide yet:
- one universal retention/hold taxonomy across all ViewFS providers and object families;
- whether retention applies only to object versions, also to named anchors, or sometimes to higher-level aggregates;
- whether event-style holds, legal/investigation holds, and temporary user holds all deserve first-class distinct families;
- whether purge lanes are user-driven, lifecycle-driven, GC-driven, or policy-driven in Phase 1;
- whether retention blocks only destructive replacement or also some classes of metadata/head movement;
- one universal retention-policy wire format.
