# RFC-0123: Keep committed objects, access propagation, public cache copies, cache trails, live facets, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
Recent revisions already separated durability, archive/thaw posture, locality/route truth, and live-facet truth.
One more low-regret seam now looks load-bearing:

- a **committed object** (`this durable thing exists`)
- an **access-propagation state** (`one grant/revoke/config change is or is not fully in effect everywhere that matters`)
- a **public cache copy** (`one shared/public cache may still serve this representation`)
- a **cache trail** (`how caches actually handled one response/request path`)
- a **live facet** (`what this process can actually do right now`)
- and a **receipt/history row**

should stay visibly different.

This matters while SlopOS is still in design because one easy mistake now would be to let one flattering `published`, `revoked`, `deleted`, or `latest` badge silently become all of:
object truth, access-policy truth, shared-cache visibility, current cache path, and current live authority.

## The separation

Keep these classes separate:

1. **Committed object** — the durable object or version record.
2. **Access-propagation state** — whether one access-control or bucket/config change has fully taken effect, is pending, or is only known historically.
3. **Public cache copy** — whether one cacheable/public representation might still be served by a shared cache even after origin change or delete.
4. **Cache trail** — standardized evidence of how caches handled one response, such as hit/miss/forward/stored details.
5. **Live facet** — inspect/read/edit/publish power currently held here.
6. **Receipt/history** — durable evidence that one access change, cache state, or trail once existed.

Do **not** flatten them into one vague story like `the object is gone everywhere now`, `revoked means no one can fetch it`, or `published means every reader sees the latest bytes immediately`.

## Historical lesson

Modern object stores and HTTP caching keep making the same distinction.

Amazon S3 now gives strong read-after-write and list consistency for object operations.
Google Cloud Storage likewise documents strong object and listing consistency, but separately warns that granting/revoking access is eventually consistent and that cacheable publicly readable objects might not exhibit strong consistency because cached copies are not updated or deleted until cache lifetime expires.
RFC 9111 defines caches and the controls around cache behavior, and RFC 9211 standardizes `Cache-Status` so the cache path can be inspected rather than guessed.

ViewFS should steal that honesty.

## ViewFS rule

ViewFS should preserve distinct lanes for:
- durable object truth,
- access-propagation truth,
- current public-cache visibility truth,
- cache-trail truth,
- current live authority,
- and history/receipt truth.

The shell should be able to say:
- `committed object exists`,
- `origin read-after-write is strong`,
- `access revoke still propagating`,
- `public cache may still serve stale bytes`,
- `cache trail says hit then validate`,
- `live read facet here now`,
- or `receipt only`.

## Why this helps ViewFS

- It prevents revocation UX from lying about already-cached public copies.
- It prevents one cache-hit row from impersonating object truth or current permission truth.
- It gives portal-mediated publication/import flows a calmer, more inspectable story about staleness and repair.
- It gives the shell a principled way to be luxurious about publication and cache debugging without pretending cache state is authority.
- It leaves room for wildly different backends and cache layers without forcing one universal revocation/cache ABI now.

## Shell consequences

A future ViewFS shell should be able to render:
- `truth badge`
- `propagation echo`
- `cache ghost`
- `trail drawer`
- `live rail`
- `receipt only`

as visibly different layers.

The default UX should stay conservative:
- showing a committed object should not imply every shared/public cache is fresh,
- showing `revoked` should not imply every previously cacheable public copy disappeared,
- and showing one cache hit or miss should not imply object or permission truth by itself.

## What this does not decide

This RFC intentionally does **not** decide:
- one universal cache taxonomy across all ViewFS providers,
- whether cache trails are always exposed to users,
- one final publication/revocation propagation state machine,
- whether public cache copies are modeled as first-class objects or only summarized state,
- one universal purge/invalidation API.

## SlopOS alignment

This separation fits SlopOS unusually well because SlopOS already has nearby but distinct draft seams for:
- exact artifact identity versus retrieval/runtime folklore,
- approval-basis and auth-result material that should not become a portable permission cache,
- cluster-map / locality / replication drafts that already refuse to let operator-state rows become object identity,
- and multiple boundary notes that explicitly warn against hidden cached state becoming authority.

ViewFS can therefore borrow the *shape* of committed-object-versus-propagation-versus-cache-trail now, while leaving publication policy, invalidation APIs, and provider exposure open longer.
