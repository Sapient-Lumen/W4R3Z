# RFC 0124: Keep committed objects, prefix projections, folder resources, listing snapshots, published names, live facets, and receipts separate

Status: exploratory

## Why this exists
ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
One more object-store lesson is worth freezing early:

- a **committed object**,
- a **prefix projection** that groups names for browsing,
- a **provider folder resource** when the backing system really has one,
- a **listing snapshot**,
- a **published name**,
- a **live facet / current room bind**,
- and a **receipt/history row**

should stay visibly different.

This matters because the easiest future mistake would be to let one folder-looking UI row become all of: object identity, provider-native directory truth, current listing completeness, current namespace bind, and current authority.

## Historical lesson
Object stores keep arriving at the same warning from different directions.
Amazon S3 keeps buckets and objects as the primary resources and says there is no hierarchy; prefixes and delimiters only let tools infer one.
Google Cloud Storage says flat-namespace buckets have no directories or folders, yet separately introduces managed folders and hierarchical namespace when true folder resources/operations are wanted.
Azure Blob Storage likewise uses delimiters for virtual directories in flat blob naming, while hierarchical-namespace accounts can also expose real directories.

The lesson is not “folders are fake” or “folders are real.”
The lesson is that **folder-like browse is its own layer**.

## ViewFS rule
ViewFS should preserve distinct lanes for:
1. durable object truth,
2. folder/prefix projection truth,
3. provider-native folder-resource truth,
4. list/feed snapshot truth,
5. current published-name / room-bind truth,
6. live-facet truth,
7. receipt/history truth.

Do **not** flatten them into one vague story like “this folder entry is the object”.

## Why this helps ViewFS
- It keeps the object store free to stay flat or object-centric.
- It keeps the room/namespace layer free to present folder-like views without pretending storage prefixes are directories.
- It lets providers with true folder resources fit naturally later without rewriting the basic object model.
- It lets listings be partial, cached, or historical without corrupting identity or authority semantics.
- It gives the shell a principled way to say `flat prefix`, `provider folder`, `managed folder`, `snapshot only`, `bound here`, `live now`, or `history only`.

## Shell consequences
A future ViewFS shell should be able to render:
- `flat prefix projection`
- `provider folder resource`
- `managed folder / delegated folder`
- `listing snapshot`
- `listing may be partial`
- `published here`
- `bound here`
- `live facet present`
- `receipt/history only`

The default browse/open behavior should stay conservative:
- listing a prefix does not prove a durable folder object exists,
- seeing an object in a list does not prove current authority over every child,
- and binding a room prefix remains an explicit shell act rather than one automatic property of stored keys.

## What this does not decide
This RFC intentionally does **not** decide:
- whether Phase 1 surfaces provider-native folder resources directly,
- whether a folder resource is first-class in the same way as ordinary objects,
- whether one delimiter or many projection modes exist for flat object stores,
- whether every provider gets a live-list feed,
- whether published names and room binds share storage or stay fully separate.

## SlopOS alignment
This separation fits SlopOS well because current SlopOS material already pushes toward:
- exact per-process namespace roots,
- explicit handle tables,
- shell-owned query / view surfaces,
- explicit portal-mediated imports and localizations.

ViewFS can therefore borrow the *shape* of honest folder/prefix separation now while leaving object-store indexing, room-presentation mechanics, and provider folder-resource breadth open longer.
