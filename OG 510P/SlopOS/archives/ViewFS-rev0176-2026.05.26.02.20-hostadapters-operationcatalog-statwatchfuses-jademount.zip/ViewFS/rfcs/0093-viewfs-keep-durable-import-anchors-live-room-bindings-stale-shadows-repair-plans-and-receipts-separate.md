# RFC-0093: Keep durable import anchors, live room bindings, stale shadows, repair plans, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0100 kept **namespace plans**, **live room bindings**, **portal import sessions**, **local overlays**, and **receipts** separate.
That remains right.

But one more seam matters now that ViewFS is studying durable reopen/import precedents more seriously while SlopOS is still design-stage:

**a durable access/import anchor, the live room binding now, the weaker stale-or-repairable shadow left behind when currentness is lost, the plan for how to repair/rebind, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one durable-handle object model,
- one revocation or stale-state story,
- one repair or reconsent carrier,
- and one shell restore model,

before the evidence is ready.

## Distinct truths

### 1. Durable import anchor
Question:
- what persisted, non-bearer, reopen/reimport designator or durable access record exists?

Examples:
- one document-portal document handle
- one security-scoped bookmark-like record
- one FutureAccessList-style durable entry
- one persisted URI permission / provider reference
- one local durable import anchor minted after explicit user mediation

This is a durable anchor.
It is not proof that the room currently has the live object bound.

### 2. Live room binding now
Question:
- what exact object, projection, or import is this room actually bound to **right now**?

Examples:
- one current document bind in the room view
- one current projected import in the pane namespace
- one current localized object bound under a room-local name
- one current helper/process child bind inherited from a reviewed recipe

This is current truth.
It is not the same as the durable anchor that might help reacquire it later.

### 3. Stale shadow / repair-needed shadow
Question:
- what weaker state remains when the durable anchor still exists but current live truth no longer does?

Examples:
- durable anchor resolves stale
- provider still knows the object but the room lost the live bind
- device reboot or session reset dropped current permission/use state
- user consent must be renewed
- object moved/replaced and identity continuity is now uncertain

This is a shadow state.
It is stronger than pure history because repair may still be possible, but weaker than a live bind.

### 4. Repair / rebind plan
Question:
- what exact next workflow could restore current truth, and what would it ask for?

Examples:
- ask the portal to reissue the live grant
- resolve-and-reconfirm a stale bookmark-like anchor
- reopen with fresh provider consent
- localize/import anew while preserving continuity evidence
- discard the stale anchor and keep only the receipt/history

This is a plan.
It is not proof that the repair succeeded.

### 5. Receipt / history
Question:
- what durable artifact records that a bind, rebind, repair, expiry, denial, or discard happened before?

Examples:
- durable import receipt
- stale verdict receipt
- repair-attempt receipt
- rebind receipt
- discard-from-durable-list receipt

Receipts should explain prior actions without silently reviving live room binds or stale shadows.

## Lessons we must learn from the past

### Durable access and live access are routinely split on purpose
Apple security-scoped bookmark APIs require resolving bookmark data and then explicitly starting access to the resource, and that resolution can report staleness. Android's Storage Access Framework distinguishes import-like one-off access from `ACTION_OPEN_DOCUMENT` long-term access, and longer-lived access needs explicit persistence. Windows FutureAccessList and StorageItemAccessList are bounded app-maintained durable lists rather than proof that the resource is currently open in a live process. Web File System Access exposes explicit permission query/request state instead of pretending a remembered handle is automatically live forever.

That is strong evidence that ViewFS should keep durable anchors, live binds, stale shadows, and repair plans visibly distinct.

### Current-handle truth is stronger than remembered-authority folklore
Capsicum capability mode and Linux pidfd/process-fd work both reinforce the same idea: current possession of a live capability-bearing handle is a special truth class. A durable anchor or a historical receipt should not masquerade as that class.

### Portals teach that the middle states matter
Request objects, response objects, document projections, and transfer sessions stay distinct because user mediation is not a one-time boolean. The shell should preserve the same honesty for stale shadows and repair plans.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **durable import anchors / durable access records**
2. **current live room bindings**
3. **stale-or-repairable shadows**
4. **repair / rebind plans**
5. **receipts/history**

The UI may render them together, but the model should not compress them into one “saved import object” or one “recent document entry” by default.

## What to steal right now
- **XDG Documents / Requests / FileTransfer** (REF-XDG-DOCUMENTS, REF-XDG-REQUEST, REF-XDG-FILETRANSFER): durable projection, mediation, and transfer states are not one class.
- **Apple security-scoped bookmark flow** (REF-APPLE-SECBOOKMARK, REF-APPLE-SECSTART, REF-APPLE-SECRESOLVE, REF-APPLE-SECBOOKMARK-ENABLE): durable anchor, resolve, start-accessing, and stale detection stay separate.
- **Android SAF** (REF-ANDROID-SAF): import/copy, durable access, and bounded provider-granted reach should remain distinct.
- **Windows FutureAccessList** (REF-MS-FUTUREACCESSLIST): durable reopen lists need pruning, inspection, and explicit maintenance.
- **WICG File System Access + Permissions** (REF-WICG-FSACCESS, REF-W3C-PERMISSIONS): repair ladders get better when the system can say `granted`, `prompt`, or `denied` instead of collapsing all failures into generic I/O errors.
- **Capsicum + pidfd** (REF-CAPSICUM-HANDBOOK, REF-LINUX-PIDFD, REF-LINUX-PIDFD-GETFD): live-handle truth and stronger inspection rights should remain distinct from durable anchors or history.

## What not to freeze yet
- the final durable-anchor schema;
- whether durable anchors are store objects, portal/provider-local artifacts, or a mixed story;
- whether repair plans are shell-owned, room-owned, or helper-owned;
- whether stale shadows are explicit first-class objects or derived state with receipts;
- whether rebind receipts are enough for continuity, or whether some later continuity locker is still warranted.
