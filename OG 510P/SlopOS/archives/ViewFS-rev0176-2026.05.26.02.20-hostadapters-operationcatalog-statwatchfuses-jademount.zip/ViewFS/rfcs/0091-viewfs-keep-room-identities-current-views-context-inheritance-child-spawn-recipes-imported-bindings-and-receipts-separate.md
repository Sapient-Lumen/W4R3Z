# RFC-0091: Keep room identities, current views, context-inheritance postures, child spawn recipes, imported bindings, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0051 already kept **current handles**, **launch inheritance posture**, **exact child slot delivery**, and **launch receipts** separate.
That remains right.

But the future ViewFS shell + terminal needs one higher-level split as well:

**the room/tab/pane the human thinks they are in, the current view bound to that room, the inheritance posture for new children or splits, the prepared spawn/import recipe, the bindings a child actually received, and the durable receipt/history artifact are different classes.**

That matters even more because both ViewFS and SlopOS are still in design.
If we collapse these too early, we will accidentally freeze one shell model, one namespace-cloning story, and one object-store/import story before the evidence is ready.

## Distinct truths

### 1. Room identity
Question:
- what long-lived interactive locus is this?

Examples:
- one pane identity
- one tab/room identity
- one notebook/runbook lane
- one restored room shell card

This is the thing a human drags, renames, reopens, searches for, or compares.
It is not automatically the same thing as the room's current namespace or its child-launch rules.

### 2. Current view / namespace now
Question:
- what explicit view or current namespace is bound to this room **right now**?

Examples:
- one current view binding
- one synthetic root/cwd posture
- one current imported subtree placement
- one current borrowed provider-backed projection

This tells the truth about what the room can currently resolve/use.
It is not the same thing as the room identity, because a room may switch views without becoming a different room.

### 3. Context-inheritance posture
Question:
- if this room spawns a child/split/helper now, what parts of the current context are even eligible to cross the boundary?

Examples:
- `inherit none`
- `inherit cwd only`
- `inherit named bindings only`
- `inherit receipts/history never`
- `inherit route/source witness but not live handles`

This is a policy/posture class.
It is not yet one concrete spawn or one child-local binding map.

### 4. Prepared child spawn / import recipe
Question:
- what reviewed recipe would assemble the next child room or helper context if committed now?

Examples:
- a spawn recipe
- a child-room launch rehearsal
- a `split here with these two imports` plan
- a `rerun in clean room plus this one borrowed object` plan

This is a prepared action or reviewed diff.
It is not yet proof that any child exists or that any child received the imports.

### 5. Child-received bindings / imports
Question:
- what exact bindings/imports did the child actually receive after the spawn/import completed?

Examples:
- child slot maps
- current child-local view binds
- imported activation handles
- portal/session results adopted into the child room

This is current child truth.
It should remain separate from the recipe that proposed it and separate from the parent room that happened to propose it.

### 6. Receipt / history
Question:
- what durable artifact records that one room switch, child spawn, import, or refusal happened before?

Examples:
- launch receipts
- import receipts
- route receipts
- denied-spawn receipts
- restore receipts

Receipts should explain prior actions without silently reviving room state, current bindings, or current inheritance posture.

## Lessons from the past

### Ambient shells and inherited descriptors taught us that convenience leaks authority
Classic UNIX taught the hard lesson that inheritance defaults are easy to get wrong.
`O_CLOEXEC` exists because setting close-on-exec in a separate step races with `fork()+execve()` in multithreaded programs, which can leak descriptors into children unintentionally.
That is the poster child for why current possession and child inheritance must stay separate.

### Capability systems taught us that good diagnostics are a product requirement
Capsicum adoption work is a reminder that capability discipline spreads only when failure modes are easy to trace and explain.
A future ViewFS shell should treat `why did this child not inherit that?` as a first-class debugging question, not as folklore or strace archaeology.

### Per-process namespaces taught us to prefer explicit assembly over hidden cloning
Fuchsia is one of the clearest modern proofs that a process can receive an explicit client-side namespace rooted in arbitrary directory handles rather than rely on one global filesystem worldview.
That is strong precedent for keeping room identity separate from current namespace and for making child namespace assembly explicit.

### Portal systems taught us that request state and granted state are not the same thing
XDG portals split request handles, chooser interactions, exported document views, and transfer sessions.
That is exactly the kind of discipline ViewFS should preserve for room-local imports.
A room asking for something, a prepared recipe mentioning it, and a child actually holding it are different truths.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **room identity**
2. **current room-local view / namespace**
3. **context-inheritance posture**
4. **prepared child spawn/import recipe**
5. **child-received bindings/imports**
6. **durable receipt/history artifact**

## Consequences
We should be able to say things like:
- `room only`
- `room switched to view receipts/review-queue`
- `inherit none`
- `inherit cwd plus review-only route witness`
- `spawn recipe prepared`
- `child created but import blocked`
- `child received 2 named bindings`
- `receipt only`

without laundering them into one fake `this tab has that authority` bit.

## Good answers might look like
- **room badges** that survive view switches and make layout/search/restoration honest
- **context-diff cards** showing parent room current state versus proposed child room state before commit
- **inherit-none-by-default room cloning** with small explicit additions
- **spawn recipes** that can be saved or compared without being current authority
- **child import trays** that show what actually landed versus what the recipe only requested
- **receipt-only replay** that reconstructs explanation and layout before any fresh authority is rebound

## What this does not decide
This RFC does **not** decide:
- the final object-store schema for the things being imported;
- whether rooms are shell-owned, terminal-owned, supervisor-owned, or split across those layers;
- the exact portable encoding of a spawn recipe or context diff;
- whether child-room creation, helper-process creation, and remote-worker creation share one recipe format or only one higher-level separation;
- whether a room can exist without any current view bound at all;
- whether receipts can promote into reusable recipes automatically or only by explicit user action.

## Shell implications worth stealing
A future custom shell+terminal should expose:
- **room badges** that show room identity separately from current view/cwd;
- **context-diff drawers** that compare `this room now` versus `candidate child room`;
- **spawn-recipe cards** that say `prepared`, `committed`, `partially imported`, `blocked`, or `receipt only`;
- **inheritance shutters** that default to small reviewed context, not ambient clone-all behavior;
- **child import trays** that show `requested`, `granted`, `bound`, `skipped`, or `receipt only` separately;
- **receipt-first room restore** that restores layout/searchability before any fresh authority is rebound.

## Why this is a low-regret move
Even if SlopOS changes its final capshell launch descriptors, wallet descriptors, document-handle shape, or view-clone helpers, this split stays useful.
It keeps custom-shell delight, object-store research, per-process namespaces, and portal-mediated imports honest while the deeper design is still moving.

## Inspirations / pressure sources
- **Fuchsia namespaces** (REF-FUCHSIA-NAMESPACE) and **filesystem architecture** (REF-FUCHSIA-NS, REF-FUCHSIA-DIR-CAPS) keep namespace assembly explicit and client-side.
- **Fuchsia dictionary capabilities** (REF-FUCHSIA-DICTCAP) are a good reminder that grouped authority should be a first-class bundle/recipe concept, not a silent inheritance side effect.
- **XDG Request / Documents / FileTransfer** (REF-XDG-REQUEST, REF-XDG-DOCUMENTS, REF-XDG-FILETRANSFER) show healthy separation between request objects, exported views, transfer sessions, and resulting accessibility.
- **WezTerm shell integration** (REF-WEZTERM-SHELL-INT) shows how room/pane metadata, command blocks, and semantic zones can drive great UX without pretending metadata is authority.
- **fish** (REF-FISH), **Nushell overlays** (REF-NU-OVERLAYS), and **Ghostty command-palette / shell integration** (REF-GHOSTTY-CMDPALETTE, REF-GHOSTTY-SHELLINT) show that delightful command surfaces, overlays, room actions, and command tracking are best when they stay explicit.
- **Linux `open(2)`** (REF-MAN7-OPEN) and **Capsicum adoption notes** (REF-CAPSICUM-ADOPTION) remind us that inheritance mistakes and poor diagnostics kill capability discipline in practice.
