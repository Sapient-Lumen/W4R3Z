# RFC-0104: Keep live room bindings, local edit shadows, pushback bases, provider verdicts, adopted results, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0111 kept **projected bases**, **local upper overlays**, **merged room presentations**, **publish results**, and **receipts** separate.
That remains right.

But the next dangerous collapse happens one step later, when a room has a writable local shadow and the user tries to **push changes back toward some provider-backed or externally governed source**.
At that point systems start flattering the user again:
- one local edit shadow starts looking like the provider's current truth,
- one stale base witness starts looking like optional trivia instead of the commit gate,
- one provider-side accept/reject/conflict verdict starts looking like the same thing as the local draft,
- one later locally adopted result starts looking like it was guaranteed by the push attempt,
- and one old conflict or success row starts looking replayable even after the basis moved.

SlopOS is still design-phase enough that ViewFS should steal the **split**, not freeze one final pushback ABI, one final provider protocol family, or one final mutable-store story.
The low-regret seam is:

**the live room binding now, the separate editable local shadow, the separate exact pushback basis/preconditions, the separate provider-side verdict, the separate locally adopted result, and the separate receipt/history row are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `save just means provider accepted it` story,
- one fake `current local draft is already the provider's next head` myth,
- one fake `provider rejection is just a local editor problem` shortcut,
- one fake `adopted local result` equals `remote durable success` assumption,
- and one shell UX that cannot say `based on X`, `provider moved to Y`, `conflicted`, `accepted but not adopted here`, `adopted locally`, or `receipt only` as different truths.

## Distinct truths

### 1. Live room binding now
Question:
- what exact thing is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as the current local edit state.

### 2. Local edit shadow
Question:
- what private writable shadow, draft, or upper layer is the user/tool editing locally?

Examples:
- no local edit shadow,
- one private draft over a projected base,
- one sealed candidate ready for pushback,
- one stale/diverged shadow,
- or one history-only shadow.

A local edit shadow is draft truth.
It is not the same thing as the provider's accepted state.

### 3. Pushback basis / preconditions
Question:
- what exact observed provider/base state must still be true for this pushback to count as valid?

Examples:
- ETag / digest basis,
- generation / metageneration basis,
- expected old head,
- lease token plus expected old value,
- or `create-if-absent`.

Pushback basis is commit-gate truth.
It is not the same thing as the current draft contents.

### 4. Provider-side verdict
Question:
- what did the provider or upstream mutation gate actually say when the pushback was attempted?

Examples:
- accepted,
- rejected: precondition failed,
- rejected: lease missing,
- rejected: conflict / ownership mismatch,
- accepted with new provider generation,
- or unknown / transport-lost.

Provider verdict is upstream outcome truth.
It is not the same thing as what this room adopts locally afterward.

### 5. Locally adopted result
Question:
- after the verdict, what local state did this room or shell actually adopt?

Examples:
- keep local shadow unchanged,
- fast-forward local room to provider-accepted result,
- record conflict receipt and keep draft,
- fork a new local object instead,
- adopt provider-returned version,
- or receipt only.

Adopted result is local-consequence truth.
It is not the same thing as the provider verdict or the original draft.

### 6. Receipt / history
Question:
- what durable artifact explains which basis, verdict, and local adoption steps happened before?

Receipts should explain prior truth without reviving live room bindings, edit shadows, pushback basis, provider verdicts, or adopted local result.

## Lessons we must learn from the past

### Exact preconditions are not optional niceties
HTTP conditional requests, S3 conditional writes, and Cloud Storage generation/metageneration preconditions all keep mutation gates explicit and return failure when state changed underfoot.
That is a strong warning against a flattering `save latest` story.

### Force-with-lease is a great product verb because it keeps the old value explicit
Git's `--force-with-lease` and `update-ref <new> <old>` are excellent precedents for saying `replace, but only if the current thing is still exactly what I think it is`.
That is much better product language than one generic `force`.

### Leases and locks are still not commit truth
WebDAV locking keeps lock tokens, timeout, and ordinary authorization separate.
A lease may help coordinate a write, but it is still not the same thing as the exact precondition or the winning durable result.

### Conditional transactions stay smaller than global lock managers
etcd's If/Then/Else transaction shape is a good reminder that guarded updates can stay explicit and compact without turning the whole design into a mandatory lock service.

### Private writable sessions deserve their own shell truth
The File System Access API's `createWritable()` keeps the writable session distinct from the file's already-committed durable state and even distinguishes `exclusive` versus `siloed` modes.
That is a good reminder that local draft posture is not the same thing as accepted upstream state.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **local edit shadows**
3. **pushback basis / preconditions**
4. **provider verdicts**
5. **locally adopted results**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one fake `save` or `commit` object by default.

## What to steal right now
- from SlopOS: exact local witness gates, explicit commit schemas, conflict-key families, and the refusal to let a floating `current` query substitute for a witnessed basis;
- from HTTP / S3 / Cloud Storage: guarded mutation using exact old-state predicates;
- from Git: `force-with-lease` ergonomics and expected-old compare-and-swap posture;
- from WebDAV and etcd: leases/transactions as narrower coordination seams than general write truth;
- from File System Access: writable-session honesty.

## Non-decisions preserved
This RFC does **not** freeze:
- one final provider pushback protocol,
- one universal validator/basis vocabulary,
- whether adopted local results always fast-forward the room or sometimes stay draft-first,
- whether provider verdicts are stored as separate objects or embedded in receipts,
- or one final mapping between local edit shadows and later publish/pushback lanes.
