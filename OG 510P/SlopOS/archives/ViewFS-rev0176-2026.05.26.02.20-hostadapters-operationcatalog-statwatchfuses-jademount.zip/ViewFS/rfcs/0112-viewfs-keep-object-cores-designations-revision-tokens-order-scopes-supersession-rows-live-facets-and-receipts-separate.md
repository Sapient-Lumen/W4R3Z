# RFC-0112: Keep object cores, designations, revision tokens, order scopes, supersession rows, live facets, and receipts separate

## Why
A brand new object store will be tempted to let one `version-like` token do too many jobs at once.
That is historically where systems get muddy.

A single row may try to stand for:
- the semantic object we mean,
- the human-facing name or publication path,
- the current mutable head,
- the ordering/conflict scope for concurrent writes,
- the supersession history of older heads,
- the currently live capability facet,
- and one durable receipt/history card.

Those are neighboring truths, not one truth.

## Keep separate
ViewFS should keep these seams separately nameable:
1. **object core** — the semantic object or lineage we mean to talk about.
2. **designation** — a path, published name, local alias, docref-like designation, or other human-facing pointer.
3. **revision token** — one provider-local or store-local version/head/change token.
4. **order scope** — the conflict scope or ordered stream that constrains concurrent writes.
5. **supersession row** — evidence that one head/revision replaced another, or that a delete-marker / tombstone / replaced head now wins.
6. **live facet** — the currently usable inspect/read/edit/publish authority.
7. **receipt/history** — durable memory of how the above changed.

## Why this split matters
- a **designation** can stay the same while the winning head changes;
- a **revision token** can advance without proving semantic sameness or exact byte sameness;
- an **order scope** can be branch-like, published-name-like, or provider-local rather than identical to object identity;
- a **supersession row** can be useful for review/repair without being a live head or live facet;
- a **live facet** can disappear while all the historical rows remain inspectable.

## Good pressure from the past
- Kubernetes keeps `metadata.uid`, `metadata.resourceVersion`, names, watches, and history windows on meaningfully different seams.
- etcd keeps key identity, key-local version counters, create/mod revisions, and the cluster revision distinct.
- S3 keeps key names, opaque version IDs, current delete-marker posture, and noncurrent versions distinct.
- Git keeps refs, commits, and reflogs distinct instead of pretending `the branch` is a timeless object.
- SlopOS already pressures the same split with conflict-key families, ordering-token work, explicit commit schemas, and lease/current-state humility.

## Product shape to steal
- **head badges** that say `current head`, `noncurrent`, `tombstoned`, `superseded`, or `history only`;
- **order pips** that say `ordered with`, `parallel`, `unknown order`, or `scope mismatch`;
- **supersession ladders** that show what replaced what and why;
- **facet rails** that keep live inspect/read/edit/publish power honest even when history looks rich.

## Non-decisions to preserve
Do **not** decide yet:
- one universal revision-token family across all ViewFS providers;
- whether order scopes are always object-local or sometimes published-name-local / branch-local / query-local;
- one final supersession-row schema;
- one global logical clock for the whole object store;
- whether every family exposes durable supersession rows or only some do.

The no-regret move is only to keep the nouns honest.
