# RFC-0098: Keep live room bindings, attention cues, interrupt grades, quiet windows, ack ledgers, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0105 kept **live room bindings**, **visibility states**, **keep-warm leases**, **restore intents**, **deferred repair jobs**, and **receipts** separate.
That remains right.

But SlopOS is also now very explicit that transient attention chrome is not durable truth, that urgent interruption is a policy-gated hint rather than a blanket capability, and that request identity must not be confused with current portal-owned state.

That gives ViewFS one more low-regret seam to protect while the object store, shell, and portal story are still design-stage:

**the live room binding now, the narrower cue that says this room or helper wants attention, the separate interruption grade that says how strongly it may ask, the separate quiet-window or suppression posture that says whether we should hush it, the durable acknowledgement or inbox row, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one flattering `still live so it can interrupt` story,
- one hidden notification-history object model,
- one fake `toast was shown so the user knows` assumption,
- one implicit critical-alert lane,
- and one shell UX that cannot distinguish `activity`, `urgency`, `suppressed`, and `acknowledged`.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, helper, or current handle is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as whether the room wants attention or whether it may interrupt the user strongly.

### 2. Attention cue / advert
Question:
- what exact signal says this room or helper wants the user to notice something?

Examples:
- new output in a hidden room,
- one bell-like event from a helper,
- one silence / stalled-progress cue,
- one `follow me` activity pip on a room tab.

An attention cue is presentation truth.
It is not durable acknowledgement, not proof that the user saw anything, and not permission to break through quiet/focus posture.

### 3. Interrupt grade / escalation class
Question:
- how strongly may the system ask for attention for this event?

Examples:
- passive badge only,
- heads-up / banner candidate,
- urgent but policy-clamped,
- special critical-interrupt class that would need its own explicit entitlement/review.

Interrupt grade is not the same thing as an attention cue.
It is also not the same thing as current room authority.
A room can be live without any interrupt grade, and an interrupt grade request can be denied or downgraded.

### 4. Quiet window / suppression posture
Question:
- what exact local or reviewed posture says this room, tab, or helper should currently be hushed, coalesced, delayed, or shown only as a quiet badge?

Examples:
- focus mode / presentation mode,
- `quiet for this workspace` posture,
- `suppress heads-up but keep badge` mode,
- `coalesce until foreground returns` posture.

Quiet posture is not the same thing as durable acknowledgement.
It only says how the cue may be surfaced now.

### 5. Ack ledger / durable follow-up row
Question:
- what durable row says something consequential still deserves follow-up even after the transient cue is gone?

Examples:
- one unread room-attention row,
- one `helper needs foreground review` entry,
- one `repair finished; rebind ready` follow-up card,
- one durable inbox-style task row.

An ack ledger row is durable follow-up truth.
It is not itself the original live cue and not itself proof that the room is still live.

### 6. Receipt / history
Question:
- what durable artifact records that a cue fired, was suppressed, escalated, acknowledged, or converted into a follow-up row?

Receipts should explain prior truth without silently reviving live room bindings, present attention cues, interrupt grades, suppression posture, or ack rows.

## Lessons we must learn from the past

### Transient notification presentation is not durable truth
XDG Notification explicitly says the application cannot learn whether a notification was actually presented to the user.
That is a wonderful precedent because it refuses to let `we asked for attention` become `the user definitely saw it`.

### Interrupt strength is a separate policy/governance seam
Android notification channels make interruption level depend on the channel importance, and users can change channel behavior after creation.
Apple critical alerts are a special entitlement-backed class rather than a generic `urgent` bit.
That is exactly the lesson ViewFS needs: `may badge`, `may heads-up`, and `may break through quiet` are different policy classes.

### Activity, bell, and silence are different kinds of shell attention
`tmux` keeps activity, bell, and silence as separate monitored conditions with separate status-line markers and actions.
That is excellent shell precedent for ViewFS room chrome.
One vague red dot is not enough.

### Durable follow-up deserves its own seam
SlopOS already refuses to let transient attention cues become durable consequence truth.
That is the right instinct for ViewFS too: if something still matters after the toast or status pip is gone, it should land on an explicit follow-up row or receipt rather than relying on lucky timing.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **attention cues / adverts**
3. **interrupt grades / escalation classes**
4. **quiet windows / suppression posture**
5. **ack ledgers / durable follow-up rows**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one `notification / alert / unread / background problem` object by default.

## What to steal right now
- from SlopOS: attention-durable-status honesty, urgent-as-hint discipline, and request-state hygiene;
- from XDG Notification: request/presentation separation and activation on click without pretending that presentation itself was durable truth;
- from Android channels: explicit interruption grades with strong user control;
- from Apple critical alerts: stronger interruption as a separately governed class, not an ordinary flag;
- from tmux: separate activity/bell/silence status glyphs and actions;
- from sibling pressure (Harbor / Schell / Ward): explicit label honesty, anchor death, and staleness/revalidation signals rather than flattering chrome.

## Non-decisions preserved
This RFC does **not** freeze:
- one final inbox / acknowledgement-ledger schema,
- one final interrupt-entitlement or urgent-review carrier,
- whether quiet windows are shell-owned, terminal-owned, or policy-owned,
- whether ack rows live in the same store as receipts,
- whether a room tab and a helper job use the same attention taxonomy,
- or one final `notification center` product surface for ViewFS.
