# RFC-0110: Keep authority-core stamps, descriptive review envelopes, explain sidecars, live binds, and receipts separate

Status: exploratory  
Updated: 2026-03-28

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
That combination gets easier to evolve if ViewFS freezes one more separation early:
**one stable review/gate digest**, **one richer descriptive envelope**, **one or more explain/diff/provenance sidecars**, **one current live bind**, and **one durable receipt/history row** should not silently collapse into one wallet-like blob.

## The separation
Keep these classes separate:
- authority-core stamp / stable review stamp
- descriptive review envelope
- explain sidecar bundle (graph/diff/basis/provenance)
- current live bind / current live authority
- durable receipt / history row

Do **not** flatten them into one vague noun like `the wallet`, `the import record`, or `the capability card`.

## Historical lesson
The past keeps rewarding stable summary keys that are deliberately smaller than the whole descriptive envelope:
- Git patch IDs are useful exactly because a stable digest over the patch meaning can key metadata without claiming to be the whole commit object or its history envelope.
- OCI descriptors keep the required exact-content core small while annotations and URLs stay optional and descriptive.
- in-toto statements keep subject digest truth distinct from contextual names and the larger predicate envelope.
- SlopOS now makes the same move directly with `wallet_core_digest` versus full wallet correlation digest, plus separate `capgraph_digest` and `capdiff_digest` explainability rows.

Those are all good ideas.
They are just different ideas.

## ViewFS rule
ViewFS should preserve distinct lanes for:
1. the smallest stable authority-core stamp used for review/drift/reconsent decisions,
2. a richer descriptive review envelope that may contain volatile issuance, labels, or context,
3. optional explain sidecars that help humans understand graph/diff/basis/provenance,
4. a separately bound current live authority surface when power is actually present here,
5. a separately durable receipt/history row after the fact.

## Why this helps ViewFS
- It prevents rich descriptive envelopes from becoming accidental authority folklore.
- It lets drift/reconsent stay stable even when volatile descriptive fields churn.
- It lets explainability get rich without silently becoming power.
- It gives the future shell a sharp way to say `same reviewed core`, `descriptive only`, `diff attached`, `graph attached`, `bound here now`, and `history only`.

## What this does not decide
This RFC intentionally does **not** decide:
- one universal authority-core digest scheme for all ViewFS families,
- whether every family uses a wallet-shaped envelope,
- one universal explain sidecar taxonomy,
- whether sidecars are provider-owned, shell-owned, portal-owned, or mixed,
- one final shell or wire ABI for stable review stamps.

## Shell consequences
A future ViewFS shell should be able to show:
- `same authority core`,
- `descriptive envelope changed`,
- `diff sidecar attached`,
- `graph sidecar attached`,
- `bound here now`,
- and `history only`

as different truths.

## SlopOS alignment
This matches current SlopOS unusually well because SlopOS already treats `wallet_core_digest` as the stable binding key, treats the full wallet digest as correlation-only, and keeps graph/diff digests explicitly explainability-only.
ViewFS can therefore steal the *shape* of that separation now while leaving exact digest families, envelope schemas, sidecar carriers, and live-bind carriers deliberately under-decided.
