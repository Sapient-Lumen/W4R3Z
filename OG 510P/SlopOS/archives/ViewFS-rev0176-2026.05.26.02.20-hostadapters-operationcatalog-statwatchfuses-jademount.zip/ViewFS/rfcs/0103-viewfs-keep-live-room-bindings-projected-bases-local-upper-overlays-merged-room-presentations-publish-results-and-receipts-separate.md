# RFC-0103: Keep live room bindings, projected bases, local upper overlays, merged room presentations, publish results, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0110 kept **live room bindings**, **provider-backed projection sites**, **published room aliases**, **localizations**, and **receipts** separate.
That remains right.

But the next dangerous collapse happens when a projected or localized thing becomes **editable through a writable shadow**.
At that point systems start flattering the user again:
- one provider-backed or generated base starts looking like the thing they are editing directly,
- one local writable shadow starts looking like the base itself,
- one merged presentation starts looking like durable object truth,
- one hidden lower entry starts looking like a permanent delete,
- and one later publish/commit/adopt act starts looking like it was already true all along.

SlopOS is still design-phase enough that ViewFS should steal the **split**, not freeze one final overlay/worktree/store substrate.
The low-regret seam is:

**the live room binding now, the separate projected or generated base stack, the separate writable local upper overlay, the separate merged room presentation, the separate publish/commit/adopt result, and the separate receipt/history row are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `what I currently see is the base` myth,
- one fake `upper shadow edits equal permanent commits` story,
- one fake `hidden below means deleted everywhere` shortcut,
- one fake `merged path equals native locality` assumption,
- and one shell UX that cannot say `base`, `upper shadow`, `merged`, `whiteout`, `publish result`, or `receipt only` as different truths.

## Distinct truths

### 1. Live room binding now
Question:
- what exact thing is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as whether this room is seeing a merged presentation.

### 2. Projected base stack
Question:
- what lower/provider/generated base or stack of bases is being presented here?

Examples:
- one provider-backed projected tree,
- one portal-backed synthetic subtree,
- several ordered lower layers,
- one generated config/secret stack,
- or none.

A projected base stack is lower-source truth.
It is not the same thing as current local edits.

### 3. Local upper overlay
Question:
- is there one writable local shadow that records local additions, replacements, hides, or policy-local metadata without mutating the base?

Examples:
- no writable upper,
- one ephemeral local upper,
- one persisted local upper,
- one upper that only records hides/whiteouts,
- or one upper that is already sealed/history-only.

A local upper is mutation-shadow truth.
It is not the same thing as the merged thing the user sees.

### 4. Merged room presentation
Question:
- what presentation does the room currently traverse when base and upper are combined?

Examples:
- base-only,
- base plus upper shadow,
- ordered union presentation,
- filtered/projected presentation,
- or none.

A merged presentation is traversal truth.
It is not the same thing as durable object/store truth.

### 5. Publish / commit / adopt result
Question:
- did a separate act publish, seal, adopt, or commit the current merged/upper state into some other durable room/local/store result?

Examples:
- not yet published,
- published as a room alias only,
- committed as a local object,
- exported back to provider,
- adopted by child room,
- or rejected.

A publish result is outcome truth.
It is not the same thing as the presence of an upper overlay.

### 6. Receipt / history
Question:
- what durable artifact explains which base, upper, merge, and publish steps happened before?

Receipts should explain prior truth without reviving live room bindings, base stacks, upper overlays, or merged presentations.

## Lessons we must learn from the past

### Overlay stacks only merge some truths
OverlayFS keeps `lowerdir`, `upperdir`, and `workdir` separate, forms merged directories only in some cases, reports many attributes from the upper directory only, and records removal via whiteouts and opaque directories instead of mutating the lower tree.
That is a strong warning that `base`, `upper`, `merged`, and `delete/hide` are different classes.

### Ordered unions deserve explicit ordering and creation rules
Plan 9 union directories are ordered lists; new members can be placed at the head or tail or replace the list entirely, lookup follows list order, and creation goes to the first directory in list order that allows it.
That is exactly the kind of honesty ViewFS wants for layered room presentations.

### Multi-source merged views are not one native source
Kubernetes projected volumes map several existing sources into the same directory.
That is another useful reminder that the merged presentation is a convenience surface, not proof that the sources became one object family.

### Placeholder, actual file, and eviction are separate states
Apple File Provider explicitly separates placeholder creation for remote items not stored locally, later providing the actual file on disk for a placeholder, and eviction that removes materialized content.
That is excellent pressure to keep `placeholder/base`, `materialized upper/local shadow`, and `later eviction/dehydrate` separate.

### Explicit realization deserves its own act
Nix `nix-store --realise` either fetches from substituters or builds what is required; if no substitute and no derivation is available, realization fails.
That is a good precedent for treating `publish/commit/adopt` as an explicit act rather than a magical side effect of traversal.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **projected base stacks**
3. **local upper overlays**
4. **merged room presentations**
5. **publish / commit / adopt results**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one fake `file`, `path`, `worktree`, or `imported editable thing` object by default.

## What to steal right now
- from SlopOS: the roadmap permission to make view objects cheap to clone and overlay, while keeping exact persistence and namespace ownership open;
- from OverlayFS: lower/upper/workdir humility, whiteout honesty, and the reminder that merged metadata can still be upper-biased;
- from Plan 9: ordered union membership and explicit head/tail/replace posture;
- from Kubernetes projected volumes: multi-source merged presentation without pretending the sources are one object;
- from File Provider and Nix: placeholder/materialize/evict and explicit realize/publish ladders.

## Non-decisions preserved
This RFC does **not** freeze:
- one final overlay substrate,
- one final whiteout or hide-marker representation,
- whether upper overlays are shell-owned, room-owned, or supervisor-owned,
- whether publish/commit/adopt results target one local object-store, one provider pushback path, or several result families,
- or one final mapping between merged presentations and later durable reopen lanes.
