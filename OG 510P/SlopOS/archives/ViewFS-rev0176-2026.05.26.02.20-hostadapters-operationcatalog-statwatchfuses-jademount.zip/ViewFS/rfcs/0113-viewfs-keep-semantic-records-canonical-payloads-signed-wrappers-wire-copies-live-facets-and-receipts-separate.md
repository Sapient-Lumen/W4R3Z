# RFC-0113: Keep semantic records, canonical payloads, signed wrappers, wire copies, live facets, and receipts separate

## Why
A brand new object store + capability-handle system will be tempted to let one `signed object` or one `descriptor blob` do too many jobs at once.
That is historically where systems get brittle.

A single artifact may try to stand for:
- the semantic record or review meaning we care about,
- the canonical payload bytes one digest/signature profile cares about,
- the signed/authenticated wrapper that adds signatures and payload-type binding,
- the storage or transport copy that happened to move across one wire,
- the currently live facet or bind,
- and one durable receipt/history row.

Those are neighboring truths, not one truth.

## Keep separate
ViewFS should keep these seams separately nameable:
1. **semantic record** — the meaning, review card, or descriptor semantics we intend to talk about.
2. **canonical payload** — the exact bytes defined by one normalization / deterministic-encoding profile for hashing, diffing, or signing.
3. **signed wrapper** — one authenticated/signature-bearing container that names payload type, signers, or detached-payload rules.
4. **wire copy** — one concrete storage / transfer / export / import copy that moved through one channel.
5. **live facet** — the currently usable inspect/read/edit/publish authority.
6. **receipt/history** — durable memory of issuance, comparison, transfer, verification, and rebinding.

## Why this split matters
- one **semantic record** can survive several valid wrapper or wire forms;
- one **canonical payload** can be stable while wrapper bytes change;
- one **signed wrapper** can rotate signers or transport shape without changing semantic meaning;
- one **wire copy** can be detached, re-packed, compressed, or logged without becoming the canonical comparison target;
- one **live facet** can disappear while the review cards, payloads, wrappers, and receipts remain inspectable.

## Good pressure from the past
- JCS explicitly allows cryptographic operations on a canonicalized counterpart while the original JSON may stay on the wire.
- RFC 8949 is clear that deterministic CBOR requires protocols to be explicit when more than one representation could express the same semantics.
- COSE explicitly allows detached payloads and makes the application responsible for ensuring those bytes are transported without changes.
- in-toto separates the Statement layer from the Envelope layer and requires the payload type to be signed with the payload.
- Current SlopOS drafts already rhyme with the same lesson through `wallet_core_digest`, canonical-CBOR encoding policy, and descriptor envelopes that are digest-authoritative but not live authority.

## Product shape to steal
- **record cards** that answer `same meaning`, `same review intent`, `changed meaning`, or `unknown`.
- **payload chips** that answer `same canonical payload`, `different canonical payload`, `profile mismatch`, or `not computed`.
- **wrapper seals** that answer `signed wrapper present`, `payload type authenticated`, `detached payload`, `wrapper changed`, or `wrapper only`.
- **wire ghosts** that answer `transport copy only`, `logged copy`, `export copy`, or `history only`.
- **live rails** that keep current inspect/read/edit/publish power visibly separate from every card above.

## Non-decisions to preserve
Do **not** decide yet:
- one universal canonicalization family for every ViewFS object family;
- one universal signed-wrapper or signature-envelope schema;
- whether every family even needs a signed wrapper;
- one final detached-payload policy;
- whether wrappers are provider-owned, shell-owned, portal-owned, or mixed.

The no-regret move is only to keep the nouns honest.
