# RFC 0132 — Keep secret descriptors, acquisition prompts, delivery slots, environment shadows, redaction lenses, renewal leases, live-use handles, and receipts separate

Status: Draft  
Revision: 145  
Date: 2026-05-15

## Context

Revision 144 kept supply-chain evidence, local admission, activation, live facets, and receipts separate. The next trap is what happens when admitted/imported/launched code needs secrets or short-lived credentials.

The wrong move is to say **secret** and accidentally mean a dozen different things: a vault item, a login result, a seed, a service-account token, a projected file, an environment variable, a masked transcript value, a refreshable credential, a signer/decryptor handle, or a receipt. SlopOS already has a useful warning in its D-APPSECRET, capshell env/credential baseline, auth-export, and vault/cryptosvc posture: app-scoped secret issuance should not become a general password manager, environment baseline, account-linking channel, or portable token-export lane by prose drift.

ViewFS should steal the separation now, without choosing a final vault, keychain, token broker, OAuth/FedCM bridge, platform credential manager, service-account system, or shell-redaction format.

## Decision

ViewFS design notes and early shell affordances must keep at least these classes distinct:

1. **Secret descriptor** — redaction-safe metadata about purpose, scope, provider, account/tenant class, rotation epoch, expected carrier, and non-exportability. It is not the secret bytes or a live use grant.
2. **Acquisition prompt / consent act** — the user-, policy-, or provider-mediated act that may issue or unlock secret-bearing material. A prompt receipt is not the material.
3. **Delivery slot / projection** — a narrow process/local namespace slot, handle, file projection, credential directory entry, IPC session, or compatibility carrier through which material is delivered.
4. **Environment shadow** — a legacy string carrier, `$FOO_FILE` pointer, argv/config interpolation, or visible compatibility variable that may name or contain secret-related material. It is never allowed to hide its leakiness.
5. **Redaction lens / transcript mask** — a rule or derived marker that hides material from logs, UI, history, crash reports, search, screenshots, and terminal metadata. It is not confidentiality by itself.
6. **Renewal / rotation lease** — scoped authority or evidence for refresh, reissue, rotate, revoke, or reacquire. It is not the current token, cleartext, signer, or vault item.
7. **Live-use handle** — the actual current authority: bearer token, signing/decrypting handle, provider-bound credential session, secret-file open, HTTP-auth session, or app-seed use capability.
8. **Residue / sink marker** — memory, config, cache, crash dump, env snapshot, child inheritance, copied config file, database initialization, or external service state that may retain material or effects after the projection is gone.
9. **Receipt/history row** — durable explanation of issuance, delivery, redaction, renewal, rotation, use, revocation, leak detection, or cleanup. It is not current authority.

The shell may braid these together, but the model must not turn them into one green **secret available** bit.

## Non-decisions

Revision 145 explicitly does not decide:

- whether ViewFS uses a platform keychain, SlopOS D-VAULT, D-APPSECRET, TPM-backed service, WebAuthn/passkey broker, OAuth token broker, service-account projection, or multiple lanes;
- whether secret delivery is handle-only, file-projected, IPC/session-based, environment-compatible, or mixed;
- whether app secrets are per-profile, per-device, per-user, per-room, per-workspace, per-bundle, or per-artifact;
- whether renewal is manual, provider-driven, lease-driven, or background-managed;
- whether transcript redaction uses value masks, structured taint, descriptor hashes, provider hints, or terminal escape metadata;
- whether a future vault supports named collections/items, attribute search, cross-app sharing, import/export, or password-manager semantics;
- how much of a remote identity/login result can be represented as a secret, auth proof, subject identity, account binding, or authorization context;
- how a future object store should retain or sweep secret-derived residue without leaking provider/account identity.

## Requirements for the next design round

- A secret descriptor is metadata, not a token, key, seed, password, or signer.
- A successful unlock/prompt is not durable future access.
- A delivery slot says where material arrived; it is not object identity or a later reopen lane.
- A `$FOO`, `argv`, config string, shell history row, or transcript cell containing or pointing at a secret is a hazardous compatibility shadow, not a safe carrier.
- A redaction mask hides displays; it does not prevent use, copying, child inheritance, memory disclosure, crash dumps, `/proc`-style inspection, provider-side replay, or external service effects.
- A renewal lease is weaker than current material and stronger than a receipt; it needs its own scope, expiry, revocation, and currentness witness.
- A live-use handle is present authority only while live and within its caveats.
- Residue must be first-class: copied config files, initialized databases, temporary files, caches, screenshots, embeddings, command output, and child processes may outlive the original slot.
- A receipt must never revive secret material, renew credentials, clear a redaction warning, or prove that a leak was cleaned up.

## Candidate vocabulary

These names are intentionally descriptive rather than final ABI commitments:

```text
SecretDescriptor
AcquisitionPrompt
SecretDeliverySlot
EnvironmentShadow
RedactionLens
RenewalLease
LiveSecretUseHandle
SecretResidueMarker
SecretReceipt
```

Candidate verbs:

```text
request_secret(descriptor, purpose, audience) -> acquisition_prompt
issue_secret_delivery(prompt_result, target_subject) -> delivery_slot
project_secret(slot, carrier_policy) -> environment_shadow | file_projection | handle_projection
attach_redaction_lens(subject, descriptor) -> redaction_lens
use_secret(handle, requested_action) -> live_use_result
renew_secret(renewal_lease, currentness_witness) -> delivery_slot | denial
rotate_secret(descriptor, rotation_plan) -> rotation_receipt
mark_secret_residue(subject, sink, cleanup_plan) -> residue_marker
write_secret_receipt(subject, inputs, result) -> receipt
```

## Shell affordance sketch

- **Secret slot cards**: show provider/purpose/scope/epoch/carrier without showing the material.
- **Env-shadow lamps**: warn when a secret is in argv/env/config text, when only a `$FOO_FILE` pointer is present, and when child inheritance/logging/procfs-style inspection risk applies.
- **Prompt beads**: distinguish `requested`, `unlocked`, `issued`, `denied`, `dismissed`, `timed out`, and `history only`.
- **Redaction lenses**: show where masking applies and, more importantly, where it does not apply.
- **Renewal rails**: show whether a short-lived token can be renewed, must be reacquired, is expired, or is revoked.
- **Residue sweepers**: show copied config, initialized database state, cached credentials, crash reports, transcripts, thumbnails, embeddings, and exported files as cleanup obligations rather than invisible afterthoughts.
- **Use receipts**: say what was used, by whom, for which audience/action, and under what epoch, without storing bearer material.

## Open questions

- Should ViewFS expose one minimal `secret descriptor` vocabulary that can describe SlopOS D-APPSECRET, platform keychain items, service account tokens, and token-broker sessions without pretending they share authority semantics?
- Can the custom shell make env-string compatibility feel usable while loudly showing why it is worse than handle/file projection?
- What is the lowest-regret redaction model that composes with transcripts, terminal metadata, crash reporting, semantic search, notebooks, and screenshots?
- Should renewal/rotation be represented as a lease, a prompt opportunity, a provider session, a policy-admitted action, or several lanes?
- How should GC treat residue that is secret-derived but no longer a live secret?
- What does **safe replay** mean when an old command used a secret that cannot or should not be renewed?

## References

- REF-SYSTEMD-CREDENTIALS
- REF-K8S-SECRETS
- REF-K8S-PROJECTED-VOLUMES
- REF-DOCKER-SECRETS
- REF-SECRET-SERVICE-SPEC
- REF-LINUX-PROC-ENVIRON
- REF-GITHUB-ACTIONS-SECRETS
- REF-AWS-IAM-TEMPORARY-CREDENTIALS
- REF-SLOPOS-APPSECRET-CAPSHELL-SECRETS
