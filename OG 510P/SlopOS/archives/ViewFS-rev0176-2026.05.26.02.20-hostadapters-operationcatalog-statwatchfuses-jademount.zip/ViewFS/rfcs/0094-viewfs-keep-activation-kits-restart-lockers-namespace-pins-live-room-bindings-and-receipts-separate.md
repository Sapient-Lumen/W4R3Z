# RFC-0094: Keep activation kits, restart lockers, namespace pins, live room bindings, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0101 kept **durable import anchors**, **live room bindings**, **stale shadows**, **repair plans**, and **receipts** separate.
That remains right.

But one more seam matters now that ViewFS is studying launch/restart continuity and per-process namespace construction more seriously while SlopOS is still design-stage:

**the startup-delivered kit of exact resources for this process, the manager-held exact resources that may survive a controlled restart, the narrower pin that keeps a namespace or view basis alive, the live room binding now, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one restart/restore object model,
- one namespace-lifetime story,
- one warm-start promise,
- and one shell restore vocabulary,

before the evidence is ready.

This RFC is deliberately narrower than durable persistence.
A **restart locker** is not a **durable import anchor**, and neither is the same thing as one **current live room binding**.

## Distinct truths

### 1. Activation kit / wake kit
Question:
- what exact ready resources were delivered to this process at startup?

Examples:
- one handed-in socket or descriptor set
- one explicit child-room bind set
- one startup import tray for the process
- one ready namespace fragment or activation slot map

This is startup-delivered truth.
It is not proof that the manager still holds a restart locker, and it is not durable reopen state.

### 2. Restart locker
Question:
- what exact live handles, namespace ingredients, or resumable request artifacts is some manager explicitly holding for a controlled restart?

Examples:
- one service-manager-held descriptor set
- one supervisor-held exact room import set
- one restart-only resumable lane
- one locker entry preserved across controlled stop/start

This is restart-survivable exact state.
It is not current room authority until delivered again, and it is not the same as a durable anchor that can outlive the restart story.

### 3. Namespace pin
Question:
- what exact object keeps one namespace/view basis alive even when one particular process is gone?

Examples:
- one namespace file descriptor or bind-mounted namespace token
- one provider-held room/view pin
- one local pin preventing a prepared room basis from evaporating during handoff

This is a liveness/preservation fact.
It is not proof that some process is currently bound into that namespace, and it is not proof of durable reopen across arbitrary future sessions.

### 4. Live room binding now
Question:
- what exact object, projection, or import is this room actually bound to **right now**?

Examples:
- one current document bind in the room view
- one current projected import in the pane namespace
- one current localized object bound under a room-local name
- one current helper/process child bind inherited from a reviewed recipe

This is current truth.
It is not the same as the activation kit that started the room, the locker that may re-deliver it later, or the pin that may keep some basis alive.

### 5. Receipt / history
Question:
- what durable artifact records that a warm start, locker delivery, pin drop, cold fallback, or explicit discard happened before?

Examples:
- activation receipt
- restart-locker receipt
- pin-drop / pin-expiry receipt
- warm-restart receipt
- cold-start-after-miss receipt

Receipts should explain prior actions without silently reviving activation kits, restart lockers, pins, or live room binds.

## Lessons we must learn from the past

### Startup delivery and restart retention are useful precisely because they are narrow
systemd socket activation and the file-descriptor store show a useful middle layer: resources can be delivered at activation time, and selected descriptors can be explicitly preserved by a manager across restarts, without turning that into a general persistence story.
Apple's `launch_activate_socket` points in the same direction for launchd-managed sockets.

That is strong evidence that ViewFS should keep activation kits and restart lockers separate from durable anchors and from current live room binds.

### Namespace lifetime and namespace membership are different truths
Linux `setns(2)` and `namespaces(7)` make the split very explicit:
- a namespace can be joined through a namespace file descriptor,
- and namespace lifetime can be pinned by an open fd or bind mount even when no process currently inhabits it.

That is excellent precedent for keeping `namespace pin` separate from `live room bind now`.

### Warm restart and cold restart should not share one flattering badge
A room that restarts with an exact locker-delivered wake kit is different from a room that had to reacquire via durable anchors, and different again from a room that fell back to a totally fresh cold start.
The shell should preserve those truths.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **activation kits / wake kits**
2. **restart lockers / manager-held exact continuity lanes**
3. **namespace pins / liveness-preservation facts**
4. **current live room bindings**
5. **receipts/history**

The UI may render them together, but the model should not compress them into one `restorable room object` by default.

## What to steal right now
- **systemd socket activation and fd store** (REF-SYSTEMD-SOCKETACT, REF-SYSTEMD-FDSTORE): startup delivery and narrow restart retention are useful precisely because they stay explicit.
- **Linux namespace fd semantics** (REF-LINUX-SETNS, REF-LINUX-NAMESPACES7): a namespace can be joined via a handle and pinned without a currently running member process.
- **launchd socket activation** (REF-APPLE-LAUNCHD-SOCKETS): launch-time retrieval of manager-owned sockets is a strong startup-kit precedent.
- **Schell anchor-death/reset-scope humility**: warm-start UX should admit when an old exact restart point is gone instead of silently mapping to latest.
- **Ward read cuts and revalidation fences**: historical receipts should say what exact start/warm state one answer reflects, and higher-risk actions should cross a stronger revalidation fence.
- **Steward adaptation witnesses**: partial or degraded wake kits should say `cache trimmed`, `partial locker`, `concurrency capped`, or `cold fallback` explicitly instead of one vague `degraded` bit.

## What not to freeze yet
- the final restart-locker object model;
- whether restart lockers are shell-owned, supervisor-owned, service-manager-owned, or split;
- the final representation of namespace pins;
- whether any pin survives reboot, machine boundary, or user boundary;
- whether activation kits and child spawn recipes eventually share one carrier;
- whether restart lockers ever hold only exact live handles, only resumable request/session artifacts, or both.
