# RFC-0125: Keep launch view plans, bound roots, handle slots, portal import tickets, live binds, and receipts separate

Status: Draft / design-phase guardrail  
Revision: rev0138  
Date: 2026-05-13

## Summary

ViewFS should not turn the future SlopOS datacube into one overloaded noun such as `file`, `object`, `handle`, `path`, or `folder` before the design earns it. The next low-regret seam is the launch/import seam around a process: the thing we planned to give it, the namespace root we actually bound, the live handle slots it actually received, the portal-mediated import ticket that may or may not become authority, the live facet/bind it can use now, and the receipt/history row that explains what happened are all different truths.

This RFC keeps those truths visibly separate while deferring the final object-store ABI, capability-handle encoding, namespace description language, portal protocol, and persistence model.

## Motivation

SlopOS is still in design, and the current SlopOS archive already points in the right direction:

- capshell child processes are supposed to receive an exact CH-STDIO / CH-FDSET handle table instead of inheriting ambient parent descriptors;
- CH-CWD is a bound root, not an advisory host path string;
- capshell declines hidden host filesystem authority and keeps file authority on explicit descriptors, view bindings, or chooser/portal outputs;
- portal design guidance says grants return handles, request/session objects are control state, and receipts/cap-diff digests should be explicit.

ViewFS should preserve that negative space. A datacube object store can still be pleasant, folder-like, and shell-friendly, but the core should not accidentally reintroduce ambient paths, magical `/`, hidden descriptor inheritance, durable portal sessions-as-authority, or old receipts that impersonate current power.

## The split

### 1. Launch view plan

A **launch view plan** is a reviewable proposal for what a process or helper will see:

- intended roots;
- intended handles;
- intended imports;
- intended live facets;
- intended policy/lease bounds;
- expected receipts.

It is not authority. It may be rendered, diffed, rehearsed, signed, or rejected before launch.

### 2. Bound root / bound namespace

A **bound root** is the actual root-like capability installed for one process, room, helper, or compatibility membrane. It is local to that subject and need not imply a machine-global `/`.

The binding can be synthetic, sealed-empty, provider-backed, object-store-backed, history-only, or compat-rooted, but it should be inspectable as a binding rather than inferred from path strings.

### 3. Handle slot table

A **handle slot table** is the exact set of live handles or descriptors delivered to the subject. Slot identity is local to the launched subject. Rights, lease bounds, badges, borrow/own posture, provenance, and close/revoke behavior should be visible without making slot numbers a universal object identity.

This is the natural place to steal from Capsicum, WASI preopens/resource handles, Cap'n Proto capability tables, and SlopOS CH-STDIO / CH-FDSET, while still refusing to freeze a final ViewFS handle ABI in this RFC.

### 4. Portal import ticket / request / session

A **portal import ticket** is mediator-owned control state. It can show that a user was asked, that a provider picker is open, that a selected external object is waiting for adoption, or that a request expired/was denied.

It is not the imported object. It is not a durable reopen grant by default. It does not become namespace authority until a separate handle/facet/binding is minted and installed.

### 5. Adopted live bind / live facet

A **live bind** is the current thing a subject can use now. It might be a read facet, edit facet, publish facet, preview-only facet, verify-only facet, provider projection, staged object, committed object, or namespace subtree.

The live bind is stronger than a plan, ticket, receipt, listing row, or history card. Shell UI should make that difference obvious.

### 6. Receipt / history

A **receipt** records what was planned, compared, granted, bound, denied, refreshed, revoked, or failed. It should be durable enough for audit and replay/debugging, but it must not silently revive authority.

Receipts should be able to prove that a launch/import happened without becoming a new path, handle, or object-store name.

## Lessons we must learn from the past

1. **Ambient global roots are a trap.** Fuchsia-style per-component namespaces and Capsicum-style capability mode both teach that a process should operate on capabilities it was intentionally given, not on a global filesystem myth.

2. **Descriptors and rights are authority, not merely metadata.** A path string, object key, doc ID, receipt ID, or old chooser session is weaker than a current live handle with rights.

3. **Portals should mediate imports, not become magic storage.** XDG Documents-style stores are useful because grants, document-store entries, host paths, and app permissions remain separate enough to revoke, inspect, and reason about.

4. **Persistent capabilities are powerful and dangerous.** EROS-style persistence is inspiring, but it also warns that persisting authority graphs can make recovery, checkpointing, revocation, and dependency reasoning a whole-system problem. ViewFS should not accidentally persist the whole live authority graph in Phase 1.

5. **Capability references can be elegant without becoming universal strings.** Tahoe-LAFS cap flavors and Cap'n Proto interface references are excellent precedents, but ViewFS should keep capability class, live rights, verify/proof-only posture, and adoption context explicit rather than declaring one magic cap URI or one global slot table.

6. **Object-store mutation needs witnesses.** Cloud object stores and etcd show the value of generation/metageneration, ETag, revision, and compare-before-commit discipline. ViewFS should keep currentness witnesses separate from namespace names and portal tickets.

7. **Folder-looking rows are often projections.** S3 prefixes, GCS simulated folders/managed folders/HNS folders, and Azure virtual/native directories all warn against treating a list row as object identity, namespace authority, or a durable folder resource by default.

## Normative posture for Revision 138

For design discussions, mock shells, and prototype docs, ViewFS SHOULD use the following terms precisely:

- **plan** for intended launch/import shape before authority is installed;
- **bound root** for actual root-like authority delivered to one subject;
- **slot** for one exact live handle/descriptor/resource entry delivered to that subject;
- **ticket** for mediator-owned portal/request/session state;
- **bind** or **facet** for current usable authority;
- **receipt** for durable explanatory history.

ViewFS SHOULD NOT make any of these equivalent by default:

- portal ticket == object identity;
- document/store ID == host path;
- slot number == stable object identity;
- namespace path == global path;
- receipt == durable authority;
- launch plan == actual child authority;
- list result == current live bind;
- import adoption == committed object;
- committed object == current editable/publishable facet.

## Deferred decisions

This RFC deliberately does not decide:

- the final object ID or manifest format;
- the hash algorithm, pack layout, or GC model;
- the final rights taxonomy;
- whether handle slots are numeric, named, typed, table-indexed, or hybrid;
- whether a portal import ticket is represented as an object-store row, session object, effect log row, or provider-owned request handle;
- how live binds survive process restart;
- whether proof-only / verify-only facets are first-class caps or descriptors plus service methods;
- how much folder-like namespace compatibility the first runtime should expose;
- the final relationship between ViewFS and any SlopOS CapStore / D-NS / D-POWERBOX implementation.

## Shell obligations

The shell should be able to show, at minimum:

- the launch plan that was reviewed;
- the actual root badges installed;
- the exact slot map delivered;
- import ticket status separate from adopted binds;
- live bind rails separate from receipts;
- stale/expired/denied states without pretending they are authority.

## Evidence and adjacent files

- `docs/30-architecture/launch-view-plans-bound-roots-handle-slots-portal-import-tickets-live-binds-and-receipts.md`
- `docs/70-shell/slot-maps-root-badges-import-tickets-and-live-bind-rails.md`
- `docs/30-architecture/viewfs-namespace-posture-v0.md`
- `docs/30-architecture/portal-import-posture-v0.md`
- `docs/30-architecture/object-store-posture-v0.md`
- SlopOS: `capshell-handle-table-posture-v0.md`, `capshell-cwd-root-posture-v0.md`, `capshell-filesystem-posture-v0.md`, and `portal-design-playbook.md`

## References

- REF-FUCHSIA-NAMESPACE
- REF-FUCHSIA-CAPS
- REF-FUCHSIA-FSARCH
- REF-CAPSICUM-HANDBOOK
- REF-WASI-CAPS
- REF-WIT-RESOURCE-HANDLES
- REF-XDG-DOCUMENTS
- REF-XDG-PERMISSION-STORE
- REF-TAHOE-URIS
- REF-CAPNP-RPC
- REF-CAPNWEB
- REF-EROS
- REF-GCS-PRECONDITIONS
- REF-AZURE-BLOB-CONCURRENCY
- REF-ETCD-TXN
- REF-AWS-S3-PREFIXES
- REF-GCS-MANAGED-FOLDERS
