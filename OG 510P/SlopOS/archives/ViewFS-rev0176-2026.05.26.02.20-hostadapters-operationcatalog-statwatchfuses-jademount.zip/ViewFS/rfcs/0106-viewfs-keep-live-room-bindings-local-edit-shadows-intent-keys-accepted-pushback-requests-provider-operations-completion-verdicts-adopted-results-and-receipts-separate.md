# RFC-0106: Keep live room bindings, local edit shadows, intent keys, accepted pushback requests, provider operations, completion verdicts, adopted results, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0113 kept **live room bindings**, **local edit shadows**, **accepted pushback requests**, **provider operations/completion tickets**, **completion verdicts**, **locally adopted results**, and **receipts** separate.
That remains right.

But there is one more easy collapse still waiting to happen: once a provider-backed action can be retried, people start treating **same intent**, **same request**, **same ticket**, and **same outcome** as if they were one truth.
They are not.
One room may have one editable local shadow, one user-chosen retry key or sameness witness, one accepted request, one provider operation, one later completion verdict, and one local adoption choice.
Those are different truths.

SlopOS is still design-phase enough that ViewFS should steal the **split**, not one final mutation or idempotency protocol.
The low-regret seam is:

**the live room binding now, the separate local edit shadow, the separate intent key / sameness witness, the separate accepted pushback request, the separate provider operation or completion ticket, the separate completion verdict, the separate locally adopted result, and the separate receipt/history row are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `retry means same request` story even when the edited basis drifted,
- one fake `same key means mutable upsert` loophole,
- one fake `operation ticket is the dedupe key` myth,
- one fake `same intent always means same eventual result` promise,
- and one shell UX that cannot say `fresh intent`, `same-intent replay`, `payload mismatch`, `pending first attempt`, `pruned`, `settled`, `adopted here`, or `receipt only` as different truths.

## Distinct truths

### 1. Live room binding now
Question:
- what exact thing is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as retries, replay keys, or provider tickets.

### 2. Local edit shadow
Question:
- what local draft, upper, or sealed candidate is the user/tool editing privately?

Examples:
- no local shadow,
- one clean draft,
- one sealed candidate,
- one conflict-preserved fork,
- or one history-only draft.

This is draft truth.
It is not the same thing as retry identity or provider settlement.

### 3. Intent key / sameness witness
Question:
- what exact client-side marker says “this retry is meant to be the **same** action as before”?

Examples:
- no sameness witness,
- one generated idempotency key,
- one requester-chosen stable key,
- one provider-scoped client token,
- one key plus canonical request fingerprint,
- one expired/pruned key,
- or one mismatch verdict saying the current payload is no longer the same request.

This is replay-safe sameness truth.
It is not the same thing as admission, provider ownership, or final result.

### 4. Accepted pushback request
Question:
- did the provider or gateway admit this exact request for later work?

Examples:
- rejected immediately,
- accepted and queued,
- accepted with operation ticket,
- accepted but follow-up unknown,
- or duplicate replayed from prior settled result.

This is admission truth.
It is not the same thing as the intent key or the final completion verdict.

### 5. Provider operation / completion ticket
Question:
- is there one bounded provider-owned handle for later follow-up?

Examples:
- none,
- one poll URL,
- one long-running operation resource,
- one provider-local job ID,
- one expiring completion reference,
- or one lost/unknown ticket.

This is follow-up truth.
It is not the same thing as sameness or the final durable result.

### 6. Completion verdict
Question:
- what later provider-side settlement became true, if anything?

Examples:
- completed and applied,
- completed with conflict,
- duplicate replayed,
- concurrent duplicate rejected/conflicted,
- still pending,
- expired/forgotten,
- or completion unknown.

This is settled-upstream truth.
It is not the same thing as what the room adopts locally afterward.

### 7. Locally adopted result
Question:
- after replay, settlement, or mismatch, what local state did this room actually adopt?

Examples:
- keep draft,
- fast-forward to settled result,
- retain draft and attach duplicate receipt,
- fork local state,
- start fresh with a new intent key,
- or adopt nothing and keep history only.

This is local-consequence truth.
It is not the same thing as intent sameness, request admission, or provider completion.

### 8. Receipt / history
Question:
- what durable artifact explains which intent key was used, whether it matched the same canonical request, what admission/completion truth was later observed, and what local adoption happened?

Receipts should explain prior truth without reviving live room bindings, edit shadows, intent keys, provider tickets, or adopted results.

## Lessons we must learn from the past

### An idempotency key is a sameness claim, not a magic success handle
The current HTTP Idempotency-Key draft keeps saying the same thing in a careful way: the key makes non-idempotent requests fault-tolerant, the server publishes expiry policy, and idempotency enforcement depends on whether the same key/fingerprint pair is first-seen, duplicated after completion, or duplicated while still in flight.
That is a direct warning against collapsing retry identity with final success.

### Same key plus different parameters must fail closed
AWS EC2 client tokens replay the same request, but the same token with different parameters fails with `IdempotentParameterMismatch`.
That is excellent product guidance.
ViewFS should prefer `not the same request anymore` over silent upsert or retargeting semantics.

### Dedupe windows and pruning matter
Stripe stores the first result for a given idempotency key, compares incoming parameters against the original request, and may treat a reused key as new after pruning.
That is another strong reminder that a sameness witness has its own lifecycle.
It should not masquerade as permanent object identity or permanent provider truth.

### Concurrent duplicate is its own state
The HTTP Idempotency-Key draft explicitly calls out concurrent retries before the first request completes and recommends a conflict-style response instead of pretending the duplicate already settled.
That is a useful shell truth in its own right.

### Local adoption should stay explicit even after replayed settlement
Even if a provider replays the original result for the same intent key, a room may still want to keep the draft, fork local state, or simply attach a receipt.
Provider sameness handling should not silently rewrite room footing.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **local edit shadows**
3. **intent keys / sameness witnesses**
4. **accepted pushback requests**
5. **provider operations / completion tickets**
6. **completion verdicts**
7. **locally adopted results**
8. **receipts/history**

The UI may render them together, but the model should not compress them into one fake `retry`, `save`, `sync`, or `job` object by default.

## What to steal right now
- from SlopOS: `network-request-idempotency-boundary-v0.md` and `background-request-state-posture-v0.md` for exact-same-request discipline and humility about request keys;
- from the HTTP Idempotency-Key draft: separate key lifecycle, fingerprinting, duplicate-after-completion, and concurrent-duplicate conflict posture;
- from AWS EC2: fail-closed mismatch semantics when the same client token is reused with different parameters;
- from Stripe: explicit key pruning/expiry and same-parameters comparison;
- from existing async-operation patterns: keep dedupe/sameness separate from provider tickets and later settlement.

## Non-decisions preserved
This RFC does **not** freeze:
- one universal idempotency-key schema,
- one canonical fingerprint algorithm for all ViewFS provider families,
- one mandatory dedupe retention window,
- whether keys are user-chosen, shell-generated, or provider-issued,
- whether every provider supports replay-safe retry,
- or one final mapping between sameness witnesses and shell retry chrome.
