# RFC-0097: Keep live room bindings, visibility states, keep-warm leases, restore intents, deferred repair jobs, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0104 kept **live room bindings**, **currentness witnesses**, **renewal windows**, **retry advice**, **repair gates**, and **receipts** separate.
That remains right.

But one more seam matters now that ViewFS is taking portal-mediated imports, explicit per-process namespaces, warm continuity, and a custom shell+terminal seriously while SlopOS is still design-stage:

**the live room binding now, the room or task visibility state, the narrower grant that allows a thing to stay warm while not foreground-visible, the separate intent that allows restore/autostart later, the deferred repair/job lane, and the receipt explaining what happened are different truths.**

If we collapse those early, we will accidentally freeze:
- one giant “background persistence” story,
- one hidden session-manager model,
- one silent autostart policy,
- one flattering `restored automatically` badge,
- and one under-modeled retry/background loop,

before the evidence is ready.

## Distinct truths

### 1. Live room binding now
Question:
- what exact object, projection, import, or current handle is this room actually bound to **right now**?

Examples:
- one current projected document in the room namespace,
- one current local object bound under a room-local name,
- one current child helper import inherited from a reviewed recipe,
- one current bind redelivered by a wake kit or portal session.

This is current authority truth.
It is not the same thing as whether the thing is visible/foregrounded, and it is not the same thing as any background or restore permission.

### 2. Visibility / serving state
Question:
- is the room or process foreground-visible, backgrounded-but-serving, draining/terminating, or receipt only?

Examples:
- one room is active in a visible pane,
- one helper remains background-visible via a status line,
- one import is terminating and should not accept new work,
- one row is historical only.

Visibility is presentation and lifecycle truth.
It is not by itself a keep-warm grant, and it is not a durable restore promise.

### 3. Keep-warm lease / background presence grant
Question:
- what exact reviewed authority says this room, helper, or imported lane may remain alive or renew in the background after it stops being foreground-visible?

Examples:
- one background-presence grant for a room-scoped helper,
- one narrow keep-warm lane for a current import,
- one portal-backed status-bearing presence grant,
- one lease that may keep the same live claim warm without widening scope.

A keep-warm lease is narrower than live authority and narrower again than restore/autostart.
It says `you may stay warm`, not `you may come back later by yourself`, and not `a deferred job may do equivalent work instead`.

### 4. Restore intent / autostart hint
Question:
- what exact reviewed intent says this room, pane, or helper may be re-created later after logout, restart, or login?

Examples:
- one login-restore choice for a room arrangement,
- one reviewed restart intent for a helper lane,
- one shell-owned remember-and-offer card,
- one portal-backed autostart bit.

Restore intent is not current liveness and not a keep-warm lease.
It is permission or intent to attempt a later comeback.
It may still fail, need repair, or require reconsent.

### 5. Deferred repair job
Question:
- what exact deferred job/task lane may attempt refresh, repair, or rebind work while the room is not foreground-visible?

Examples:
- one queued revalidation job,
- one deferred make-local/import-fresh attempt,
- one periodic repair probe,
- one constrained background task that can report later.

A deferred repair job is not the same thing as a keep-warm lease.
It may exist even when nothing stays live, and it may be forbidden even when background presence is allowed.

### 6. Receipt / history
Question:
- what durable artifact records that something stayed warm, cooled, restored, failed to restore, queued a repair job, or required a fresh foreground review before?

Examples:
- keep-warm granted receipt,
- keep-warm expired receipt,
- restore-at-login receipt,
- restore-failed / restore-repaired receipt,
- deferred-repair queued/completed receipt.

Receipts should explain prior truth without silently reviving current binds, visibility state, keep-warm grants, restore intents, or deferred jobs.

## Lessons we must learn from the past

### Background permission and autostart are not the same thing
XDG Background explicitly lets apps request permission to **run in the background** or to be **started automatically when the user logs in**.
That is a wonderful precedent because it refuses to collapse “stay alive now” and “come back later” into one permission.

### Background status is not live task identity
The Background portal also has a separate status-setting surface.
That is a tiny but very useful lesson: user-visible “still doing something” state should stay separate from the exact live task, the grant that allowed it, and the later receipt/history.

### Mobile platforms punish vague background stories
Android background execution limits and foreground-service requirements, and Apple BGTaskScheduler / BackgroundTasks, all push the same lesson:
continuous presence, user-visible foreground work, and later deferred maintenance are different classes.
Trying to hide them under one “background mode” story leads to poor UX and over-broad authority.

### Lease state is richer than one on/off bit
Kubernetes Leases keep holder identity, renew time, and lease duration on explicit seams, while EndpointSlice keeps `ready`, `serving`, and `terminating` as different conditions.
That is strong precedent for ViewFS room chrome that can say `foreground`, `warming`, `serving in background`, `draining`, or `history only` instead of one fake timeless availability bit.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **visibility / serving state**
3. **keep-warm leases / background-presence grants**
4. **restore intents / autostart hints**
5. **deferred repair jobs**
6. **receipts/history**

The UI may render them together, but the model should not compress them into one `restored / backgrounded / still around` object by default.

## What to steal right now
- from SlopOS: background leases, request-state discipline, jobs-vs-background separation, descriptive wallets, and capability-safe shelling;
- from XDG Background: separate `run in background` from `start automatically when the user logs in`;
- from Android and Apple: visible status, constrained background execution, and honesty about when work is deferred instead of continuously alive;
- from Kubernetes: richer multi-bit lifecycle chrome instead of one binary readiness myth;
- from modern terminals: quality/state badges and semantic shell metadata instead of transcript folklore.

## Non-decisions preserved
This RFC does **not** freeze:
- one final keep-warm lease protocol,
- one final autostart / restore carrier,
- whether restore intents are shell-owned, portal-owned, or supervisor-owned,
- whether deferred repair jobs live in the same store as task wrappers or only share chrome,
- whether keep-warm grants can be attached to rooms, helpers, or imports in the same exact way,
- or one final “background presence” manager for ViewFS.
