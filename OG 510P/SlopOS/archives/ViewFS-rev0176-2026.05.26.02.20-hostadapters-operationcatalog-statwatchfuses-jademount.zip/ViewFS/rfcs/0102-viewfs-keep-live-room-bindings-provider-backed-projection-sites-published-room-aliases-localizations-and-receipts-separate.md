# RFC-0102: Keep live room bindings, provider-backed projection sites, published room aliases, localizations, and receipts separate

## Status
Draft guardrail RFC.

## Why this exists
Revision 0101 kept **live room bindings**, **selection owners**, **transfer offers**, **manager retentions**, **paste capsules**, **materialized imports**, and **receipts** separate.
That remains right.

But the next dangerous collapse happens one step later.
After an open/import/transfer is accepted, systems start flattering the user again:
- one provider-backed projected site starts looking like a native local file,
- one room-local published alias starts looking like durable locality,
- one hydrated placeholder starts looking like a fully local object-store fact,
- and one receipt/history row starts looking like it can reopen the same thing forever.

SlopOS is still design-phase enough that ViewFS should steal the **split**, not freeze one final substrate.
The low-regret seam is:

**the live room binding now, the separate provider-backed or portal-backed projection site, the separate room-local published alias or slot, the separate local localization/materialization fact, and the separate receipt/history row are different truths.**

If we collapse those early, we will accidentally freeze:
- one fake `path means locality` myth,
- one fake `projected here means lives here` story,
- one fake `hydrated placeholder means native object-store truth` shortcut,
- one fake `published alias means durable reopen` assumption,
- and one shell UX that cannot say `provider projection`, `published here`, `localized here`, `placeholder only`, `materialized but provider-owned`, or `receipt only` as different truths.

## Distinct truths

### 1. Live room binding now
Question:
- what exact thing is this room actually bound to **right now**?

This is current authority truth.
It is not the same thing as whether some namespace site currently names it.

### 2. Provider-backed projection site
Question:
- is there one scoped synthetic/provider/portal namespace site that makes this thing reachable here without making it native local truth?

Examples:
- one document-portal path under a restricted synthetic tree,
- one provider-backed document/tree entry,
- one placeholder/projection site that can hydrate on demand,
- one wrapper/relay mount point,
- or none.

A projection site is reachability truth.
It is weaker than local object-store truth.

### 3. Published room alias / slot
Question:
- did this room choose to publish or bind one local alias/slot/name for the thing here now?

Examples:
- published in this room under `/work/report`,
- published to one child room/launch recipe,
- alias only in this pane,
- projection visible but not published in the room namespace,
- or none.

A published alias is room-namespace truth.
It is not the same thing as provider backing, localization, or durable reopen.

### 4. Localization / local realization
Question:
- did a separate act actually create or confirm one local object, local replica, or localized materialization here?

Examples:
- no localization,
- dataless/placeholder only,
- hydrated copy under provider control,
- local replica,
- local object-store commit.

This is local-object truth.
It is not the same thing as projection or publication.

### 5. Receipt / history
Question:
- what durable artifact remembers that a thing was projected here, published here, localized here, hydrated here, or later removed?

Receipts should explain prior truth without reviving current room bindings, projection sites, published aliases, or localizations.

## Lessons we must learn from the past

### A projected path is still a mediated view
XDG Documents makes exported files available through a FUSE filesystem rooted at `/run/user/$UID/doc/`, and the view inside the sandbox is restricted to just the files the app is allowed to access.
That is a strong precedent that a visible path can still be a scoped mediated projection rather than native local publication.

### A provider hierarchy is not the same thing as provider storage
Android SAF says the document-provider schema is based on a traditional file hierarchy, but the provider may physically store the data however it likes.
That is exactly the humility ViewFS wants: path shape and object/storage truth can differ.

### Shared namespace population is not the same thing as object identity
Fuchsia directory capabilities are routed into a component namespace at a chosen path, and components separately publish objects through their outgoing directory.
That is strong evidence that `namespace site`, `published capability`, and `underlying object/capability` should stay separate.

### Placeholder conversion and hydration are still separate from native locality
Windows Cloud Files / CFAPI lets providers register a sync root with hydration and population policies, and lets an existing local file be converted into a placeholder.
That is excellent evidence that placeholder/projection posture, hydration/materialization posture, and fully local truth are not one bit.

## Guardrail
ViewFS should keep these classes visibly separate:
1. **live room bindings**
2. **provider-backed projection sites**
3. **published room aliases / slots**
4. **localizations / local realizations**
5. **receipts/history**

The UI may render them together, but the model should not compress them into one fake `file`, `open`, or `imported here` object by default.

## What to steal right now
- from SlopOS: explicit view/namespace posture, document-portal humility, and import-to-docref caution;
- from XDG Documents: scoped synthetic document views instead of ambient filehood;
- from Android SAF: provider-managed hierarchies whose storage truth can remain elsewhere;
- from Fuchsia: explicit namespace population and separately published outgoing capabilities;
- from Cloud Files / file-provider systems: placeholder versus hydrated versus local-object honesty.

## Non-decisions preserved
This RFC does **not** freeze:
- one final projection-site substrate,
- one final room-publication/alias schema,
- whether localized objects are exact copies, replicas, or object-store commits in Phase 1,
- whether placeholder/dataless posture is shell-owned, provider-owned, or supervisor-owned,
- or one final mapping between projected sites and later durable reopen lanes.
