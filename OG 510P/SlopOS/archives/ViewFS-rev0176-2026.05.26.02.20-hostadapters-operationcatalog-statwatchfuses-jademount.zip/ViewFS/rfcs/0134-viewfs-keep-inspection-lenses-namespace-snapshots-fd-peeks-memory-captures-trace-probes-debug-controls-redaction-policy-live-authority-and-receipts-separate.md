# RFC 0134: Keep inspection lenses, namespace snapshots, fd peeks, memory captures, trace probes, debug controls, redaction policy, live authority, and receipts separate

## Status
Proposed.

## Problem
ViewFS is heading toward explicit per-process namespaces, capability handles, portal-mediated imports, object-store receipts, and a first-class shell. That makes inspection and diagnostics both extremely valuable and extremely dangerous.

The shell will want to answer questions like:

- What roots, handles, and slots did this process launch with?
- What does this process believe its namespace is?
- Why did this import, mount, borrow, secret projection, or revocation fail?
- Can I inspect the child process, follow a trace, capture a crash, or attach a debugger?
- Can I share a bug report without sharing bearer handles, secrets, raw memory, or private object graph structure?

Those are all reasonable needs. The failure mode is to hide them inside one fuzzy **debug**, **observe**, **inspect**, **trace**, or **log** switch. History says that is unsafe. Process inspection surfaces are often authority surfaces: `ptrace` can observe and control a process and read or change memory/register state; `/proc/<pid>/fd` and memory-map surfaces expose sensitive process-local facts; core dumps can preserve secrets and capabilities; tracing systems can reveal private data or mutate state when destructive actions are enabled; and platform privacy settings often treat screen/input/control observation as privileged rather than harmless metadata.

The design-phase opportunity is to keep the seam explicit before ViewFS accidentally bakes host folklore into its object store and shell.

## Proposal
For Phase 1 and near-term research, ViewFS should keep at least these lanes separate:

1. **Inspection intent** — a reviewed request to inspect, trace, debug, snapshot, or export diagnostics for a named target and purpose.
2. **Target identity / process-view locator** — a non-authoritative way to point at a live process, room, task, worker, provider, child namespace, or object-store operation.
3. **Namespace snapshot** — a bounded, point-in-time, redacted description of the target's roots, slot names, imports, live binds, and visibility posture.
4. **Handle / fd / slot peek** — a redacted inventory row saying that a live slot exists and what class of authority it might represent; not a duplicate of the handle and not a reopen grant.
5. **Memory / register / core / crash capture** — sensitive captured state, usually quarantined and export-gated, never ordinary log text.
6. **Trace probe / trace stream / trace processor** — a bounded observation stream plus optional processing/filtering, distinct from the live state it observes and distinct from debugger control.
7. **Debug-control lane** — attach, pause, single-step, inject, mutate registers/memory, dump handles, or enter a namespace; always stronger than inspect/trace/read-only observe.
8. **Redaction / export policy cut** — a local decision about which observations may leave the target boundary, terminal, support bundle, notebook, or repo.
9. **Current live inspection authority** — the actual live handle/proxy/lease that can inspect, trace, capture, or debug now.
10. **Inspection receipt / support bundle history** — durable evidence of what was inspected, captured, redacted, exported, denied, or destroyed, without carrying current authority.

The exact names can change. The separation should not.

## Core guardrails

### 1. Observation is authority
A process's view roots, fd table, handle slots, open object classes, memory maps, trace events, screen contents, input stream, and logs may reveal secrets, relationships, or capabilities. ViewFS should require explicit authority for observation instead of assuming same-principal or same-workspace inspection is safe.

### 2. A namespace snapshot is not the namespace
A snapshot can explain what the target was allowed to see at one moment. It must not be restorable as a live root, used as a launch plan, or treated as proof that the target still has those handles.

### 3. A handle inventory row is not a handle
A slot peek can say `slot 4: document-read facet, issuer redacted, caveat digest X`. It must not duplicate, reopen, transfer, retain, or dereference the handle unless a separate live authority lane says so.

### 4. Trace feeds are not live truth and not debug authority
A trace stream can lose events, be sampled, be filtered, or be redacted. It may be excellent evidence, but it is not complete state, not a right to attach, and not a grant to mutate.

### 5. Core/crash/memory captures are new risky objects
A crash capture is often a frozen bag of secrets, credentials, handles, paths, input, and user data. It should inherit quarantine/risk/residue posture and need its own redaction/export gate. It should not enter search, recents, semantic summaries, or support bundles by default.

### 6. Redaction lenses are not containment
A redaction lens may make one transcript, bundle, or panel safer. It does not prove that a secret did not appear in another log, trace, dump, screenshot, derived artifact, or provider cache.

### 7. Debug control is a separate lane
Pause, step, inject, memory write, register write, fd duplication, namespace entry, and live replay are not variants of `peek`. A design that says `inspect` but can control execution is really a debug-control design and must be reviewed as such.

### 8. Receipts stay descriptive
An inspection receipt can preserve target digest, purpose, time, result class, redaction policy, and export destination. It must avoid raw bearer tokens, raw fd paths, unredacted secrets, stable cross-target linkability by default, and any ability to revive an old inspection session.

## Lessons to steal carefully

- Linux `ptrace` is the canonical warning: inspect and control often live on the same primitive, and per-thread stopped/running state matters.
- Linux `hidepid`, ptrace access checks on `/proc/<pid>/fd`, and `PR_SET_DUMPABLE` are reminders that ordinary process metadata is sensitive enough to need gates.
- Linux `coredump_filter` and dumpability are reminders that crash capture policy is not the same thing as process authority or source code identity.
- Fuchsia Inspect is a good model for structured runtime diagnostics, but ViewFS should still add export minimization and authority boundaries around it.
- ETW's controller/provider/consumer split is useful vocabulary for trace ownership and lost-event accounting.
- DTrace's separate privileges and explicit destructive-action opt-in are good warning labels: observation tools can become effectful.
- Kubernetes RBAC subresources are a useful shape: logs, exec, attach, and port-forward are related but separately authorized API surfaces.
- macOS privacy controls for screen recording, input monitoring, automation, accessibility, and full disk access are a user-facing reminder that observation/control classes should be named rather than buried in one broad permission.
- SlopOS already has capshell peer-inspection posture, CH-INSPECT, observation export policy, trace descriptors/processors, and microvm debug-introspection non-portability. ViewFS should reuse that caution while avoiding a premature final diagnostics ABI.

## What not to decide yet

Do not freeze yet:

- one universal inspection schema;
- one final trace/event vocabulary;
- one final process identity or target locator;
- one final redaction policy language;
- one final core/crash capture representation;
- whether debugger control is provider-owned, shell-owned, supervisor-owned, or never portable;
- whether handle/slot inventories can be exported outside the local user/session;
- how much support-bundle material can be made searchable;
- whether any host `/proc`, ETW, DTrace, eBPF, Fuchsia Inspect, or SlopOS CH-INSPECT substrate becomes a native ViewFS provider.

The low-regret decision is only this: inspection, trace, dump, export, debug-control, live authority, and receipts are different truths.

## Adoption test
A future ViewFS proposal touching diagnostics should answer:

- Is this changing the inspection intent, target locator, namespace snapshot, handle/fd peek, memory/core capture, trace stream, debug-control lane, redaction/export policy, live authority, or only receipts?
- What can the observer learn that it could not learn before?
- Can the observer duplicate, reopen, enter, or mutate anything, or only view redacted state?
- What happens when the target exits, revokes, rotates secrets, changes namespace, or crosses an epoch fence?
- What material is quarantined or excluded from indexing, search, transcripts, crash reports, semantic summaries, and support bundles?
- What survives into history, and can any history item be replayed into current inspection authority?

If a proposal says **read-only diagnostics** while exposing raw fd paths, live handle duplication, memory bytes, register writes, or hidden support-bundle export, it has crossed into a stronger lane.
