# RFC 0133 — Keep delegation intents, attenuation envelopes, membrane leases, revocation wavefronts, stale brakes, live authority, and receipts separate

Status: Draft  
Revision: 146  
Date: 2026-05-15

## Context

Revision 145 separated secret descriptors, acquisition prompts, projections, environment shadows, redaction, renewal, live-use handles, residue, and receipts. The next trap is the adjacent one: once ViewFS can lend handles, import capability-bearing objects, run helpers, or issue short-lived credentials, users will ask to **share**, **revoke**, **expire**, **recall**, **rotate**, and **see who still has access**.

The old-world mistake is to answer all of those with one object called a grant. That collapses too much. A delegation request, a caveat list, a bearer token, a live proxy, a local imported handle, a revocation request, a propagation checkpoint, a stale-handle denial, a renewal opportunity, and a receipt answer different questions. SlopOS already has useful pressure here in D-LEASE, D-CAPX, CH-CAPLEASE, CH-SREF, D-APPSECRET, RFC-0019 revocation epochs/indirection, and the recent auth import boundaries around token exchange and revocation: borrowed or imported authority should not silently turn into portable delegation, durable account truth, ambient token brokerage, or a universal disconnect ledger.

ViewFS should steal the vocabulary and warning signs without choosing one final revocation substrate, derivation-tree model, token format, distributed object runtime, authorization server, or shell action syntax.

## Decision

ViewFS design notes and early shell affordances must keep at least these classes distinct:

1. **Delegation intent / share ask** — a plan or request to delegate, loan, export, share, attenuate, or persist authority. It is not a grant and not live authority.
2. **Attenuation envelope / caveat set** — declared narrowing terms such as action allowlists, expiry hints, audience, locality, use budget, no-redelegate bits, provider constraints, or purpose. It is not proof that enforcement exists.
3. **Membrane lease / revocable proxy** — a current mediator that enforces bounds before forwarding. While live, this proxy may be the authority; its descriptor remains evidence only.
4. **Delegated handle / imported stub** — the recipient's currently usable reference, handle, proxy, broker session, bearer credential, or object-capability stub.
5. **Revocation request / recall act** — an attempt to invalidate, shorten, withdraw, rotate, close, disconnect, or deny future renewal. It is not proof that all recipients have stopped.
6. **Revocation wavefront / checkpoint** — evidence of which brokers, membranes, recipients, stores, offline queues, authorization servers, or provider sessions have observed the revocation epoch. It is not global omniscience.
7. **Stale-handle brake / death verdict** — a use-site denial or degraded state such as `revoked`, `expired`, `epoch mismatch`, `issuer unavailable`, `basis drift`, `offline descendant unknown`, `provider propagation pending`, or `history only`.
8. **Renewal / redelegation control** — a separate ability to extend, refresh, rotate, reissue, delegate onward, or promote to durable reopen. It is not implied by having the delegated handle.
9. **Live authority now** — the actual current ability to perform effects. This may be a raw handle, membrane proxy, lease gate, auth token, opened descriptor, or provider session, and it must be visible as current rather than inferred from old evidence.
10. **Receipt/history row** — durable explanation of request, issuance, attenuation, import, use, revocation, wavefront, denial, expiry, rotation, renewal, or cleanup. It is not authority and not proof of global erasure.

The shell may braid these together in one card, but the model must not turn them into one green **shared** or **revoked** bit.

## Non-decisions

Revision 146 explicitly does not decide:

- whether ViewFS uses derivation trees, epoch counters, revocable forwarders, brokered handles, capability tables, short-lived tokens, macaroons, zcaps, UCAN-like chains, OAuth-like revocation, local-only membranes, or multiple lanes;
- whether revocation is synchronous, eventually observed, use-site checked, broker-enforced, lease-expiry driven, provider-owned, or mostly impossible for a given grant family;
- whether all delegated handles are proxy-shaped, token-shaped, descriptor-shaped, or native-handle-shaped;
- whether re-delegation is allowed by default, denied by default, or modeled per boundary;
- whether wavefront state is centralized, distributed, local-only, provider-owned, or omitted for some substrates;
- how much recipient/offline inventory may be revealed without creating a privacy side channel;
- whether persistent delegation exists at all in Phase 1 beyond explicit revalidation designators;
- how ViewFS should rotate or tombstone existing bearer material after revocation;
- whether revocation failures become policy errors, repair offers, warning badges, or hard denials for each object class.

## Requirements for the next design round

- A share/delegation intent must not create authority by being saved, displayed, approved for review, or embedded in a workflow.
- Attenuation terms must stay monotonic if token-like, and shell-visible if policy-like, but terms are not the enforcement mechanism.
- If enforcement is by membrane, the membrane/proxy is the live authority and the descriptor is only evidence.
- If enforcement is by verifier or provider, ViewFS must preserve the verifier/provider currentness boundary instead of pretending local receipt truth is enough.
- If enforcement is by expiry alone, the UI should say `expires` or `expired`, not `revocable`.
- A revocation request must produce a local result and, when applicable, a wavefront/checkpoint state; it must not claim to undo already committed effects.
- A stale-handle denial must preserve reason classes instead of collapsing everything into `access denied`.
- A renewal or redelegation ability needs its own caveats, currentness witness, and expiry; it is not inherited from ordinary use authority.
- Receipts may explain what happened, but must not contain bearer delegation material, raw capability URLs, raw sturdyrefs, raw tokens, or enough live locator material to reacquire authority.
- The object store must treat revocation state, receipts, and delegation indexes as audit/control metadata, not object liveness roots or trust clearance.

## Candidate vocabulary

These names are intentionally descriptive rather than final ABI commitments:

```text
DelegationIntent
AttenuationEnvelope
CaveatSet
MembraneLease
DelegatedHandle
RevocationRequest
RevocationWavefront
StaleHandleBrake
DeathVerdict
RenewalControl
RedelegationControl
LiveAuthorityNow
DelegationReceipt
```

Candidate verbs:

```text
prepare_delegation(intent, source, bounds) -> delegation_intent
issue_attenuated(intent, currentness_witness) -> delegated_handle | membrane_lease | denial
wrap_with_membrane(source_handle, attenuation_envelope) -> membrane_lease
import_delegation(envelope, adoption_policy) -> delegated_handle | designator | denial
request_revoke(subject, target, reason) -> revocation_request
advance_wavefront(revocation_request, observer_report) -> revocation_wavefront
use_delegated(handle, action, currentness_witness) -> result | stale_handle_brake
renew_delegation(renewal_control, basis) -> delegated_handle | denial
promote_delegation(handle, persistence_intent) -> durable_designator | denial
write_delegation_receipt(event, redaction_policy) -> receipt
```

## Shell affordance sketch

- **Delegation cards**: show who/what is being asked to receive which authority, from whom, through which route, with what attenuation.
- **Caveat chips**: show action, audience, expiry, locality, purpose, use budget, no-redelegate, offline, and provider constraints as claims, not enforcement.
- **Membrane lamps**: distinguish `proxy-enforced now`, `verifier-checked`, `provider-owned`, `descriptor only`, `bearer copy`, and `history only`.
- **Revocation wave maps**: show local closed, broker observed, provider accepted, recipient notified, offline unknown, stale denied, and propagation pending without claiming omniscience.
- **Stale brakes**: make use-site denials readable: `expired`, `recalled`, `epoch mismatch`, `object gone`, `basis drift`, `policy now denies`, `issuer unavailable`, `needs reacquire`.
- **Recall receipts**: explicitly say what was attempted, what is known, what cannot be undone, and what remains unknown.
- **Rotate/reissue ladders**: offer fresh short-lived replacement authority without replaying old bearer material.
- **Who-still-can drawers**: bounded, redacted, privacy-preserving views over known live/proxy/delegation state.

## Open questions

- Should ViewFS's first delegations be membrane-only, short-lived-token-only, handle-copy-only, or intentionally multiple so the shell learns to show the differences?
- What is the smallest wavefront state that helps users without leaking a sensitive recipient graph?
- Can the shell make `revoked for future use` understandable without overclaiming that all prior effects or offline copies disappeared?
- Should revocation wavefronts be stored as object-store metadata, separate control-plane metadata, or receipt-only evidence?
- When should revocation force secret rotation, object re-keying, namespace republishing, or trust-clearance reset?
- How should compatibility with bearer capability URLs be shown without normalizing URL-paste delegation?
- What does safe replay mean for an old workflow whose delegated handle is now stale but whose renewal control may still exist?

## References

- REF-SLOPOS-DLEASE-REVOCATION
- REF-SEL4-MANUAL-LATEST
- REF-MACAROONS-NDSS14
- REF-UCAN-SPEC
- REF-UCAN-REVOCATION
- REF-RFC7009-REVOKE
- REF-AWS-IAM-TEMPORARY-CREDENTIALS
- REF-W3C-CAPURL
- REF-TAHOE-CAPS
- REF-CAPTP-DRAFT
- REF-CLOUDFLARE-WORKERS-RPC
