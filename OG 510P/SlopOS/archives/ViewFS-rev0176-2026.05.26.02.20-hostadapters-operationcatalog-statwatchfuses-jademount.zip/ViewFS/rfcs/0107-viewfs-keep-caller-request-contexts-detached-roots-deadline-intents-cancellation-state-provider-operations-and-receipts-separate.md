# RFC-0107: Keep caller request contexts, detached roots, deadline intents, cancellation state, provider operations, and receipts separate

Status: Draft  
Updated: 2026-03-24

## Summary
The next low-regret seam for ViewFS is not a bigger persistence story.
It is a narrower honesty story:
**caller-bound request context ≠ detached continuation root ≠ deadline intent ≠ current cancellation state ≠ provider operation ticket ≠ completion/adoption ≠ receipt/history**.

That split matters because SlopOS is now explicit enough about request contexts, cancellation, deadlines, and background work that ViewFS can safely learn the lesson **without** freezing one final request-context schema, one final detach token, or one final provider mutation protocol.

## Why this seam matters now
ViewFS already separates:
- accepted request from completion verdict;
- retry-safe sameness witness from request admission;
- graceful cancel from terminate, detach/delete, retry, and reset/fork;
- keep-warm/background presence from restore intent.

But there is still one dangerous collapse left:
- the shell can start treating caller cancellation, detached cleanup/continuation, deadline expiry, provider-side pending work, and durable history as one vague `still running / maybe detached` blob.

SlopOS points the other way.
Its request-context work keeps cancellation/deadline propagation as coordination, not authority.
It explicitly says work that intentionally outlives its caller should mint a **fresh root context** on the owning seam rather than rely on portable detach/shield semantics.
That is exactly the humility ViewFS should steal.

## The distinction to preserve
When a room kicks off provider-backed work, ask seven different questions:
1. **What is the current live room bind?**
2. **What caller request context currently governs this attempt?**
3. **Is there a detached provider-owned continuation root now?**
4. **What deadline or timeout intent currently applies, if any?**
5. **What is the current cancellation state?** requested, propagated, cooperatively acknowledged, ignored, expired, or unknown?
6. **Is there a provider operation ticket to observe?**
7. **What only lives as receipt/history now?**

Those are not the same truth.

## Lessons we must learn from the past

### 1. Derived caller contexts are real parent→child structure, not generic tags
Go's `context` package is unusually crisp:
- a context carries deadlines, cancellation signals, and request-scoped values across API boundaries;
- derived contexts are canceled when their parent is canceled;
- failing to call a returned `CancelFunc` leaks the child until the parent is canceled.

That is a direct warning against letting ViewFS treat caller-bound request context as decorative metadata.
If we model it, we should model it as real structure with cleanup obligations.

### 2. Detaching is a different act from deriving
Go's `WithoutCancel` is a beautiful warning label.
It returns a context that points at the parent but is **not** canceled with the parent, and it returns **no deadline**, **no Err**, and a **nil Done channel**.
That is extremely useful evidence that `continue after caller is gone` is not just an ordinary child context with a cute flag on it.
It is a different class and should look different in ViewFS.

### 3. Deadlines are coordination intent, not final state
gRPC is crisp too:
- the client should set realistic deadlines;
- the client can receive `DEADLINE_EXCEEDED`;
- the server should stop spawned work when the initiating RPC has been cancelled;
- deadline propagation may convert absolute deadline to timeout to avoid clock-skew trouble.

That means ViewFS should keep one operation's current deadline intent separate from whether provider work was admitted, detached, completed, or adopted locally.

### 4. Cancellation is often cooperative, and shielding is dangerous when widened
Kotlin's coroutine docs make the tradeoff painfully explicit:
- cancellation is cooperative;
- a parent job cancels its children;
- `NonCancellable` is for `withContext` cleanup blocks, **not** for launching ordinary child work;
- using `launch(NonCancellable)` severs the parent-child relation so the parent no longer waits for or is cancelled by the child.

That is exactly the kind of footgun we should not flatten into a hidden portable `detach` bit.

### 5. Cleanup-after-cancel is not the same thing as ordinary detached work
Temporal's `workflow.NewDisconnectedContext` is a perfect steal.
It is used so cleanup can still run **after** cancellation, with explicit code and purpose.
That is much better than pretending every detached continuation is just another child operation.

### 6. RPC logistics need their own lane
Cap'n Proto's server call context explicitly owns RPC logistics such as cancellation.
That is a good reminder that call-lifetime control belongs on its own seam instead of being smuggled into object identity, room bind truth, or durable receipts.

## Promising shape
ViewFS probably wants distinct conceptual rows such as:
- **CallerRequestContext** — current parent-bound cancellation/deadline/cause posture for one attempt.
- **DetachedRoot** — fresh provider- or supervisor-owned continuation root that intentionally outlives the caller.
- **DeadlineIntent** — one current cutoff/timeout posture, possibly inherited, narrowed, absent, or detached away.
- **CancellationState** — live status such as `active`, `cancel requested`, `deadline fired`, `cleanup running`, `detached root active`, `confirmed stopped`, `unknown`.
- **ProviderOperation** — the provider's current watch/poll handle if the work remains externally observable.
- **ContinuationReceipt** — durable history saying whether work stayed caller-bound, detached for cleanup, detached for long follow-up, expired by deadline, ignored cancel, or only left history.

The names can change.
The split should stay.

## Shell consequences
This seam gives the custom shell some of the best honest chrome yet:
- **cutoff lamps** for `inherits caller cutoff`, `narrowed cutoff`, `no cutoff`, `deadline fired`, `unknown`;
- **detach-root cards** for `still caller-bound`, `cleanup root only`, `provider detached root`, `local watch detached`, `history only`;
- **continue-without-me ladders** that keep `cancel with me`, `finish cleanup only`, `let provider continue`, and `stop watching` as visibly different acts;
- **cancellation braids** that show `requested`, `propagated`, `cooperatively acknowledged`, `cleanup still running`, `deadline exceeded`, or `provider still settling`;
- **root provenance chips** that say `caller child`, `fresh root`, `shielded cleanup`, or `unknown bridge`.

That is exactly how to make the shell feel magical without lying about what remains governed by the original caller.

## What not to decide yet
- one universal request-context wire format;
- one universal detach-root ticket format;
- whether detached roots are always provider-owned, supervisor-owned, or family-specific;
- whether deadline intent is stored as absolute cutoff, duration, or only witness/cause rows;
- whether cleanup-only detached roots and long-running detached roots share one schema or only one shell chrome family.
