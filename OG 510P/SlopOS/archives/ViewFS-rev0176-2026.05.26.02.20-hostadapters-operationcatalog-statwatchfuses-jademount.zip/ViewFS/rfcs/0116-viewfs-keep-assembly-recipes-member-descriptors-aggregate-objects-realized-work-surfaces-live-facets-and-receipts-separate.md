# RFC-0116: Keep assembly recipes, member descriptors, aggregate objects, realized work surfaces, live facets, and receipts separate

Status: Draft  
Updated: 2026-03-28

## Why
ViewFS is inching toward a brand-new object store, capability handles, explicit per-process namespaces, and portal-mediated imports.
One very likely mistake would be to flatten all of these into one flattering noun like “bundle”, “package”, or “assembled object”.
Past systems keep warning us that:
- an **assembly recipe** can exist before anything durable is born;
- **member descriptors** can remain useful after member names or source locations are gone;
- one **aggregate object** can be committed durably without saying anything about whether it has been unpacked, mounted, hydrated, or rebound into a current room;
- one **realized work surface** can be evicted and rebuilt without changing the underlying aggregate object;
- and a **live facet** is still stronger than every recipe/descriptor/aggregate/history row.

## Separation to keep
Keep separate:
- **assembly recipe** — the declarative statement of which members, order, and assembly rules were intended;
- **member descriptor** — one exact member reference or digest-bearing row used by the recipe;
- **aggregate object** — the resulting durable object identity if assembly commits successfully;
- **realized work surface** — one unpacked / expanded / mounted / projected / hydrated working presentation;
- **current live facet** — current inspect/read/edit/publish power over one object or work surface;
- **receipt/history row** — evidence that one recipe, assembly, unpack, or bind existed.

## Why this is low-regret
This split lets ViewFS be ambitious without freezing too much too early.
It preserves room for:
- OCI-like descriptor sets and indexes,
- Git-like tree construction from an explicit index,
- object-store-side compose/concatenate operations,
- provider-owned or shell-owned unpack/materialize steps,
- and richer shell UX around `recipe only`, `assembled`, `realized here`, `evicted`, and `history only`.

## External pressure
- Google Cloud Storage composite objects show that a new aggregate object can be composed from existing objects while the source objects remain unaffected.
- OCI manifests and indexes show that descriptor graphs and resulting addressable objects are distinct layers.
- `git write-tree` shows that a tree object can be minted from an explicit staged index rather than from ambient directory folklore.
- containerd shows that pulled content in the content store and later unpacked snapshots are different truths, and that containers and live tasks are different again.

## SlopOS pressure
Current SlopOS material rhymes with this strongly:
- `rfcs/0009-component-manifests-and-capability-routing.md` treats composition/routing as explicit data.
- `docs/30-architecture/activation-posture-v0.md` is admirably blunt that CH-ACTSET is descriptive, bounded, and not authority by itself.
- `rfcs/0038-persistent-object-store-and-snapshots.md` keeps snapshots, clones, and durable store membership explicit.
- `rfcs/0065-orthogonal-persistence-and-capstore.md` keeps durable commits, named roots, and persistence explicit instead of ambient.
- `docs/30-architecture/artifact-reference-schema-v0.md` keeps artifact identity separate from storage or retrieval folklore.
- `docs/30-architecture/attestation-pack-schema-v0.md` keeps normalized summary bytes and provider-native evidence distinct inside one pack.

## Shell posture worth stealing
The shell should be able to say:
- `recipe only`
- `member set known`
- `aggregate committed`
- `realized here`
- `realized elsewhere`
- `evicted but rebuildable`
- `history only`

…without pretending these are the same class.

## Do not decide yet
Do not decide yet:
- one universal recipe schema across all object families;
- one universal descriptor vocabulary for every member kind;
- whether every aggregate object must be reproducible from recipe plus descriptors alone;
- whether realization is provider-owned, portal-owned, helper-owned, or shell-owned;
- whether every realized work surface is addressable as a durable object;
- one universal unpack/materialize protocol.
