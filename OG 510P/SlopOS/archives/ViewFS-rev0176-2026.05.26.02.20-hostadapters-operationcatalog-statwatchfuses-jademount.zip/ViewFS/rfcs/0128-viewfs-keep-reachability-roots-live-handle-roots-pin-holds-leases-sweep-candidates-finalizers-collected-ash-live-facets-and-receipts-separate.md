# RFC 0128 — Keep reachability roots, live-handle roots, pin/hold/lease records, sweep candidates, finalizers, collected ash, live facets, and receipts separate

Status: design-phase guardrail  
Revision: 141  
Date: 2026-05-13  
Codename: gchalos-pinleases-sweepguards-moonfern

## Summary

After Revision 140, ViewFS has a sharper story for durable roots and restore activation. The next trap is object-store liveness: deciding what keeps bytes, object cores, namespace roots, imported material, and capability-adjacent state alive.

This RFC keeps eight things separate:

1. **reachability root** — a durable root, accepted namespace root, named store root, retained profile root, or user-visible pin that participates in the object-store live set;
2. **live-handle root** — temporary liveness created because a process, room, portal session, upload, repair job, or provider proxy currently holds usable authority;
3. **pin / hold / lease record** — an explicit keep-alive, no-destroy, not-yet-GC, or future-use promise, possibly recursive, expiring, provider-local, or policy-scoped;
4. **sweep candidate / mark verdict** — a collector's current analysis that something appears unreferenced or reclaimable;
5. **deletion finalizer / cleanup barrier** — an obligation that delays final removal until cleanup, export, revoke, index-drop, or provider settlement has happened;
6. **collected ash / tombstone** — the state after the object or facet has actually been removed, or a minimal negative record kept to prevent accidental resurrection;
7. **current live facet** — present read/edit/publish/inspect authority for an object or view, independent of whether the backing will survive future GC;
8. **receipt / history** — durable evidence of roots, pins, sweeps, finalizers, deletes, and failures, weaker than both retention and authority.

The goal is to make the future ViewFS object store safe to collect without letting stale receipts, indexes, caches, imported folder views, or old namespace rows accidentally become GC roots — and without letting a sweeper delete material that is only protected by current live authority.

## Motivation

Object stores fail in two opposite ways:

- they retain forever because every path, index row, cache entry, receipt, log, preview, or stale ref sounds like a root;
- they collect too aggressively because only durable roots count, while live handles, imports in flight, leases, repair jobs, and finalizers are invisible to the collector.

Both failures would be disastrous for ViewFS.

ViewFS wants capability handles, explicit per-process namespaces, portal-mediated imports, durable roots, time-capsule restore, and rich receipts. Those are powerful, but they create many nearby nouns that sound like `the object is alive`. This RFC says they are not the same noun.

A receipt can say `object X existed and was collected`; it must not keep X alive unless there is an explicit retention root. A cache hit can serve bytes; it must not prove retention. A live handle can read now; it must not imply the object is pinned after the holder dies. A sweep candidate can be a useful preview; it must not be a deletion. A finalizer can block deletion; it must not become a secret forever-pin with no owner, expiry, or reason.

## The split

### 1. Reachability root

A reachability root answers: **which durable root set currently keeps an object graph alive?**

Candidate root families include:

- accepted durable root commits from the ViewFS root ledger;
- named workspace / room / profile roots;
- user pins or favorites explicitly marked as retention roots;
- offline bundles or hydrated closure roots;
- published-name retention roots;
- provider-native retained roots imported into ViewFS as explicit facts;
- policy roots such as legal holds, backup retention, or profile baseline roots.

A reachability root does not answer whether a process can use an object now. It is retention truth, not live authority.

### 2. Live-handle root

A live-handle root answers: **what currently held authority or runtime operation must keep backing material from being swept right now?**

Examples:

- an open object facet held by a process;
- a live room bind or namespace slot;
- a portal import session with an adoption step in progress;
- a provider proxy serving ranges;
- an upload / repair / thaw / materialization job;
- a borrowed live handle with a non-ended lend;
- a read-only time-capsule preview that has materialized local bytes.

The collector may need to honor these as runtime liveness roots, but they should not silently create durable retention after the holder or job ends.

### 3. Pin / hold / lease record

A pin, hold, or lease answers: **who asked the store not to collect or destroy this material, under what bounds?**

Useful fields may include:

- holder / issuer / owner;
- target object core, root, chunk set, aggregate, folder resource, or namespace projection;
- direct versus recursive versus indirect protection;
- expiry, renewal, recall, or release conditions;
- purpose label: `offline`, `restore-preview`, `active-upload`, `legal-hold`, `publication-cache`, `developer-debug`, `provider-maintenance`;
- current status: `active`, `expired`, `releasing`, `blocked`, `orphaned`, `provider-hidden`;
- privacy posture for explaining the reason without leaking names or relationships.

This is where ViewFS should borrow aggressively from Nix GC roots, IPFS pins, containerd leases, Kubernetes finalizers, and ZFS holds — but not freeze one universal root/lease schema yet.

### 4. Sweep candidate / mark verdict

A sweep candidate answers: **what does the current collector believe may be reclaimable?**

It is a snapshot of analysis, not a deletion.

A good sweep candidate should carry:

- basis root set digest;
- live-handle liveness boundary;
- ignored cache/index/receipt classes;
- mark algorithm / provider family;
- uncertainty and provider-hidden regions;
- grace-period and recent-object policy;
- why-retained or why-reclaimable explanations;
- dry-run size and blast-radius estimates.

Sweep candidates must be staleable. They should expire if roots, live handles, pins, finalizers, epochs, provider witnesses, or in-flight jobs change.

### 5. Deletion finalizer / cleanup barrier

A finalizer answers: **what must happen before removal becomes final?**

Examples:

- revoke exported proxy before collecting backing object;
- flush or cancel upload/repair job;
- withdraw a published name;
- settle provider delete marker / versioned delete;
- remove index rows or cache trails;
- preserve a tombstone to prevent rollback resurrection;
- wait for dependent aggregate or child object cleanup;
- request human confirmation because the only remaining root is surprising.

A finalizer is not a root in disguise. It should have a named owner, reason, failure mode, timeout/renewal policy, and inspection surface.

### 6. Collected ash / tombstone

Collected ash answers: **what is no longer present, and what minimal negative record remains?**

Different providers may need different negative records:

- no tombstone at all for pure content-addressed cache eviction;
- local tombstone to prevent stale namespace resurrection;
- delete marker for versioned providers;
- purge receipt for retention/hold compliance;
- unavailable marker for privacy-preserving redaction;
- `unknown, provider hidden` when the local store cannot know.

Collected ash must not be read as a cache miss only. Sometimes it is a security fact: `this old durable ref must not revive`.

### 7. Current live facet

A current live facet answers: **what can be exercised now?**

A live read/edit/publish/inspect facet can coexist with many retention states:

- live but not durable after close;
- durable but not live;
- live from a cache but not retained;
- live through a provider proxy while local copy is sweepable;
- live read-only from a time capsule while edit authority is denied;
- receipt-only after collection.

The shell should render these differences instead of saying only `exists`.

### 8. Receipt / history

A receipt answers: **what was rooted, pinned, leased, swept, blocked, finalized, collected, or denied?**

Receipts should include enough basis to audit a collection decision, but they must not become hidden retention roots unless a separate retention root explicitly names them. A receipt can be retained as history while the object it describes is gone.

## Lessons we must learn from the past

### Nix: roots are explicit, inspectable, and separate from packages

Nix is valuable here because GC roots are concrete roots, and live paths are the closure reachable from those roots. The lesson is not `copy Nix symlinks`; it is that keeping the root set visible prevents accidental retention folklore.

### IPFS: cached content, pinned content, and mutable facades differ

IPFS teaches that content can be present briefly because of cache behavior, retained because it is pinned, retained indirectly through recursive pins, or protected through MFS. ViewFS should similarly separate cache warmth, direct pinning, recursive retention, and user-facing mutable facades.

### Git: history/reflog grace is not eternal retention

Git keeps unreachable objects around for grace periods and through reflog/recent-object mechanisms. That is a great recovery affordance and a warning: users can mistake recoverability windows for durable roots. ViewFS should display grace periods as grace periods.

### containerd: leases protect future-use resources during operations

containerd leases are especially useful because they protect content/snapshots that are not otherwise obviously in use, and they can expire. ViewFS needs that shape for imports, materializers, repairs, thaws, upload sessions, and child launches.

### Kubernetes: finalizers and owner refs are deletion choreography, not object identity

Kubernetes finalizers make deletion two-phase and controller-visible. Owner references support cascading cleanup. ViewFS should steal the idea of visible deletion barriers while avoiding a giant generic object-controller API too early.

### ZFS holds: no-destroy is a named protection, not a vague preference

OpenZFS holds are a simple reminder that a no-destroy protection should be inspectable and releasable. ViewFS should make hold reasons visible and avoid mystery `cannot delete` states.

### SlopOS: CapStore already knows GC roots are a hard question

The SlopOS CapStore RFC explicitly leaves representation of GC roots, privacy, and accountability as an open question. ViewFS should preserve that humility. The right near-term move is to keep the root/lease/finalizer vocabulary separate, not to choose one hidden reachability database.

## Nifty ideas worth stealing

- **GC halos** around object cards showing whether retention comes from durable root, live handle, pin, hold, lease, policy, or unknown provider state.
- **Pin badges** that say `direct`, `recursive`, `indirect`, `offline`, `debug`, `legal`, `provider`, or `expiring`.
- **Why-retained drawers** that answer `what is keeping this alive?` without leaking protected object names.
- **Sweep rehearsals** that dry-run collection against a named root-set digest and show bytes, objects, capabilities, indexes, and caches separately.
- **Finalizer rails** that show cleanup obligations in order, with owners and failure modes.
- **Ash receipts** for collected objects that preserve audit/recovery truth without keeping the object alive.
- **Grace clocks** for Git-like recoverability windows, visibly weaker than pins or roots.
- **Lease alarms** when a long-lived lease looks like an accidental forever-root.
- **Cache-not-pin ghosts** when content is locally present but not protected.
- **Root-diff protectors** before deleting a namespace root or accepted durable root.

## Normative posture for now

Until a later RFC deliberately narrows this, ViewFS design docs and prototypes SHOULD:

- make every retention root explainable without treating explanation as authority;
- treat live handles and in-flight jobs as runtime liveness roots without making them durable pins by default;
- make pins/holds/leases explicit, bounded, inspectable, and releasable;
- keep sweep candidates staleable and weaker than deletion;
- use finalizers as cleanup barriers, not mystery retention;
- let receipts survive collection without retaining the collected object unless explicitly rooted;
- keep caches, indexes, previews, listing snapshots, and search results out of the root set unless a specific root/lease says otherwise;
- show `live now`, `retained`, `cached`, `pinned`, `finalizing`, `collected`, and `receipt only` as different states.

## Non-decisions

Still open:

- the final GC algorithm or graph representation;
- whether roots are stored in CapStore, ViewFS, SlopOS substrate, provider-native databases, or mixed;
- whether live handles are observed by the collector through a kernel table, broker service, portal manager, or explicit lease rows;
- whether tombstones are mandatory, optional, provider-local, or privacy-scoped;
- how much root-cause explanation can be shown without leaking object relationships;
- whether collection is stop-the-world, incremental, transactional, mark/sweep, refcount-ish, generational, or provider-native;
- whether receipts are stored in the same object store or an append-only evidence lane;
- how to reconcile user deletion, retention policy, legal holds, secure erase, backups, and public cache copies.
