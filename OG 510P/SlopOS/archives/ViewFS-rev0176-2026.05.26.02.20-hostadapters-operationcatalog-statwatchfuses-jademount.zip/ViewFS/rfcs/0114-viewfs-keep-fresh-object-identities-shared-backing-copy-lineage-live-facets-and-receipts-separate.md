# RFC-0114: Keep fresh object identities, shared backing, copy lineage, live facets, and receipts separate

## Why
A brand new object store + capability-handle system will be tempted to let one cheap clone, reflink, or snapshot-derived writable copy quietly mean too many things at once.
That is historically where systems get slippery.

A single copied-looking row may try to stand for:
- the fresh logical object or working copy we just minted,
- the shared-backing optimization that happens to save space underneath,
- the copy/clone lineage pointing back to one parent or origin snapshot,
- the currently live facet or bind,
- and one durable receipt/history row.

Those are neighboring truths, not one truth.

## Keep separate
ViewFS should keep these seams separately nameable:
1. **fresh object identity** — the new logical object or working copy that exists for this import/clone/materialization event.
2. **shared backing** — the extent/block/store optimization that happens to be reused underneath.
3. **copy lineage** — the explicit `derived from`, `reflinked from`, `snapshot origin`, or `rebuilt from` relationship.
4. **live facet** — the currently usable inspect/read/edit/publish authority.
5. **receipt/history** — durable memory of how the copy/clone/materialization happened.

## Why this split matters
- one **fresh object identity** can be real even when storage stays shared for a while;
- one **shared backing** optimization should not imply same object, same trust state, or same current authority;
- one **copy lineage** row can remain useful even after blocks are fully unshared;
- one **live facet** can disappear while the lineage and receipts remain inspectable.

## Good pressure from the past
- Linux reflink/FICLONE explicitly shares underlying storage while writes remain private to the file being written.
- Btrfs reflink docs are admirably blunt that shared blocks do not make the files dependent for later edits.
- OpenZFS clone concepts are useful because clones start from snapshots, keep an explicit origin dependency, and even have a separate `promote` operation.
- APFS clones are useful because they make cheap local copies first-class without pretending they are hard links.
- Current SlopOS drafts already rhyme with the same lesson through `import-to-docref-fresh-identity-boundary-v0.md` and `open-untrusted-export-lineage-boundary-v0.md`.

## Product shape to steal
- **birth badges** that answer `fresh object`, `derived object`, `rebuilt object`, or `history only`.
- **backing ghosts** that answer `shares backing`, `backing diverged`, `backing unknown`, or `deep copy`.
- **lineage ladders** that answer `reflinked from`, `snapshot origin`, `rebuilt from`, `explicit parent`, or `history only`.
- **live rails** that keep current inspect/read/edit/publish power visibly separate from every card above.

## Non-decisions to preserve
Do **not** decide yet:
- one universal clone/reflink ABI for every provider;
- whether every family even exposes backing-sharing hints;
- one universal lineage schema beyond the need for explicit parent/origin truth;
- whether `unshare now` or `deep copy now` becomes a universal verb;
- whether backing-sharing visibility is shell-owned, provider-owned, or mixed.

The no-regret move is only to keep the nouns honest.
