# RFC-0120: Keep committed objects, durability profiles, redundancy layouts, repair verdicts, availability states, live facets, and receipts separate

Status: Draft  
Updated: 2026-03-28

## Why
ViewFS is inching toward a brand-new object store, capability handles, explicit per-process namespaces, and portal-mediated imports.
One very likely mistake would be to flatten `the durable object`, `the intended protection target`, `the concrete share or replica layout`, `the current repair truth`, `the current retrievability answer`, and `the live facet someone holds right now` into one flattering noun like “stored object” or “healthy file”.
Past systems keep warning us that:
- a **committed object** can already exist durably without saying anything about whether its intended protection target is fully satisfied right now;
- a **durability profile** can separately say `replica-3`, `k-of-n`, or equivalent survivability posture without being one proof that the current layout really matches it;
- a **redundancy layout** can separately say `these shares / replicas / placements exist now` without becoming object identity;
- a **repair verdict** can separately say `healthy`, `scrubbing`, `degraded`, `repairing`, or `failed` without claiming object birth or death;
- an **availability state** can separately say `retrievable here now`, `retrievable with degradation`, or `currently unavailable` without changing the semantic object;
- and a **live facet** is still stronger than every durability/layout/repair/history row.

## Separation to keep
Keep separate:
- **committed object** — one durable object record that exists now;
- **durability profile** — one declared or inferred protection target such as replica count, k-of-n threshold, or equivalent survivability posture;
- **redundancy layout** — one concrete share / replica / placement / stripe topology row for that object;
- **repair verdict** — one current statement about whether redundancy or integrity is healthy, degraded, under repair, or failed;
- **availability state** — one current answer to whether the object is retrievable here, retrievable with degradation, temporarily unavailable, or unrecoverable;
- **live facet** — currently usable inspect/read/edit/publish authority over that object;
- **receipt/history row** — evidence that one commit, placement change, repair run, availability transition, or operator/provider verdict happened.

## Why this is low-regret
This split lets ViewFS stay ambitious without freezing too much too early.
It preserves room for:
- replication-backed and erasure-coded providers to coexist,
- providers that expose layout details and providers that intentionally hide them,
- repair flows that are provider-native, locally synthesized, or mixed,
- degraded-yet-readable states that do not look like total loss,
- and richer shell UX around `replica target`, `k-of-n`, `layout hidden`, `scrubbing`, `repairing`, `retrievable with degradation`, and `history only`.

## External pressure
- Ceph shows that object IDs are mapped through placement groups to current OSD placement precisely so clients do not confuse logical object identity with storage placement.
- Ceph also shows that scrubbing and peering are ongoing replica/integrity truths, which is a strong reminder that current repair health is not the same thing as object existence.
- Tahoe-LAFS shows that share encoding has explicit `k` and `N` parameters, that recoverability depends on acquiring enough shares, and that share placement / access control are separate concerns.
- Amazon S3 shows that replication is asynchronous and that objects carry replication-status values such as `PENDING`, `COMPLETED`, `FAILED`, and `REPLICA`.
- SlopOS already rhymes with this because CH-AREF keeps digest identity separate from location hints and CH-CAPSTORE keeps durable commit meaning separate from whatever storage topology eventually backs it.

## What to steal
- **durability badges** instead of one flattering `safe` bit,
- **layout ghosts** instead of pretending placement snapshots are object identity,
- **repair ladders** instead of hiding scrub/degrade/heal stories,
- **availability lamps** instead of conflating `can read now` with `perfectly protected`,
- **live rails** that remain visibly stronger than every durability/layout/repair/history row.

## What not to decide yet
Do not decide yet:
- one universal durability-profile registry across all ViewFS object families;
- whether redundancy layout is ever part of portable object metadata;
- whether repair verdicts come from providers, local audits, or both;
- whether availability states are room-local, machine-local, provider-local, or a composition of those;
- one final receipt format for layout, repair, or availability transitions.
