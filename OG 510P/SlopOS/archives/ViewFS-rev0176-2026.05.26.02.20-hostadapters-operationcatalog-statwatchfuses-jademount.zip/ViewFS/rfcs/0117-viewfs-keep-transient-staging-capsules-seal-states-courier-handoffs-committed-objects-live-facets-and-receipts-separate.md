# RFC-0117: Keep transient staging capsules, seal states, courier handoffs, committed objects, live facets, and receipts separate

Status: Draft  
Updated: 2026-03-28

## Why
ViewFS is inching toward a brand-new object store, capability handles, explicit per-process namespaces, and portal-mediated imports.
One very likely mistake would be to flatten all local drafting, preview, helper-edit, and import staging into one flattering noun like “temporary file”, “draft object”, or “open thing”.
Past systems keep warning us that:
- a **transient staging capsule** can exist exactly and privately before any durable object-store member is born;
- a **seal state** can say `freeze this for review` without saying anything about durable identity or future reopen;
- a **courier handoff** can explicitly pass the capsule to another process without publishing it into a namespace;
- a **committed object** is a later explicit birth event;
- and a **live facet** is still stronger than every draft/seal/courier/history row.

## Separation to keep
Keep separate:
- **transient staging capsule** — one private exact-byte draft object or unnamed file-like thing;
- **seal state** — one review/freeze/lock posture over that capsule;
- **courier handoff** — one explicit local send/receive event for the capsule or one handle to it;
- **committed object** — the durable object/store member or published object that exists only after explicit commit/import/publication;
- **current live facet** — current inspect/read/edit/publish power over the capsule or committed object;
- **receipt/history row** — evidence that one capsule, seal change, courier hop, or commit happened.

## Why this is low-regret
This split lets ViewFS stay ambitious without freezing too much too early.
It preserves room for:
- memfd-like anonymous exact-byte capsules,
- `O_TMPFILE`-like unnamed objects that are published later,
- explicit FD-passing or portal-owned local helper handoffs,
- commit-last or review-before-publish flows,
- and richer shell UX around `draft`, `frozen`, `sent locally`, `committed`, `discarded`, and `history only`.

## External pressure
- Linux `memfd_create()` shows that a regular-file-like object can exist anonymously and be passed between processes.
- Linux file seals show that freeze state is about allowed operations now, not about durable identity or publication.
- `O_TMPFILE` shows that an unnamed local object can exist before any public name is attached, and can later be linked into the filesystem.
- Linux memfd preservation docs show that even when some continuity paths preserve contents and size, seals are not automatically preserved, which is a strong warning not to confuse transient exact-byte capsules with durable object semantics.

## SlopOS pressure
Current SlopOS material rhymes with this strongly:
- `docs/30-architecture/import-to-docref-boundary-v0.md` keeps explicit materialization separate from bearer restore/import.
- `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md` keeps fresh local identity separate from same-byte aliasing.
- `docs/30-architecture/artifact-reference-schema-v0.md` keeps exact artifact identity separate from locator folklore.
- `docs/30-architecture/capstore-commit-schema-v0.md` keeps durable commit/update meaning explicit rather than ambient.

## Shell posture worth stealing
The shell should be able to say:
- `draft capsule`
- `sealed for review`
- `sealed against writes`
- `couriered locally`
- `committed here`
- `published now`
- `discarded`
- `history only`

…without pretending these are the same class.

## Do not decide yet
Do not decide yet:
- one universal capsule primitive or kernel/runtime substrate;
- one universal sealing taxonomy across all providers and object families;
- whether every helper handoff is FD-passing, portal-owned, or higher-level;
- whether every committed object can be traced back to one capsule;
- whether any capsule survives restart or machine transfer;
- one universal commit-last protocol.
