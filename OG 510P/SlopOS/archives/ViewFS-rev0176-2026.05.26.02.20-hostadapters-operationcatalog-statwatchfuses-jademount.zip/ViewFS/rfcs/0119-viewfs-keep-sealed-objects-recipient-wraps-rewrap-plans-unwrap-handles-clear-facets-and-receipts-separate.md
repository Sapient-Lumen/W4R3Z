# RFC-0119: Keep sealed objects, recipient wraps, rewrap plans, unwrap handles, clear facets, and receipts separate

Status: Draft  
Updated: 2026-03-28

## Why
ViewFS is inching toward a brand-new object store, capability handles, explicit per-process namespaces, and portal-mediated imports.
One very likely mistake would be to flatten `the sealed thing we store`, `the per-recipient wrapping story`, `the plan to rewrap or rotate keys`, `the provider-bound thing that can actually unwrap`, and `the live clear facet someone holds right now` into one flattering noun like “encrypted object” or “secure handle”.
Past systems keep warning us that:
- a **sealed object** can already exist durably without saying anything about who can currently clear it;
- a **recipient wrap** can separately say `this payload key or equivalent was wrapped for this recipient / key slot / route`;
- a **rewrap plan** can separately say `change the recipient roster or key version` without claiming semantic object birth;
- an **unwrap handle** can separately say `this provider-bound capability may clear one wrap` without saying the plaintext is live in this room now;
- and a **clear facet** is still stronger than every seal/wrap/rewrap/history row.

## Separation to keep
Keep separate:
- **sealed object** — one durable encrypted object or encrypted package that exists now;
- **recipient wrap** — one wrapped DEK, recipient stanza, or equivalent per-recipient / per-key-slot access row over that sealed object;
- **rewrap plan** — one proposed or completed change to recipient wraps, wrapping key versions, or equivalent envelope posture;
- **unwrap handle** — one current provider-bound or holder-bound authority that may unwrap one recipient wrap;
- **clear facet** — currently usable inspect/read/edit/publish authority over decrypted or otherwise cleared content;
- **receipt/history row** — evidence that one seal, wrap, rewrap, unwrap attempt, or clear-bind event happened.

## Why this is low-regret
This split lets ViewFS stay ambitious without freezing too much too early.
It preserves room for:
- inline versus sidecar wrap sets,
- provider-bound opaque key handles versus exportable public recipient rows,
- cheap rewrap or key-rotation flows that do not pretend to be semantic object birth,
- clear-facet lifetimes that can stay shorter or narrower than wrap durability,
- and richer shell UX around `sealed`, `3 recipients`, `rewrap planned`, `unwrapable here`, `clear facet bound`, and `history only`.

## External pressure
- JWE shows that multiple recipients can share one ciphertext / IV / authentication tag while carrying separate per-recipient `encrypted_key` material and headers.
- WebCrypto shows that a `CryptoKey` is an opaque reference managed by the user agent and that `wrapKey` / `unwrapKey` are separate operations.
- Cloud KMS envelope encryption shows that one KEK wraps DEKs which encrypt actual data, and the encrypted data is stored together with the wrapped DEK.
- Cloud KMS re-encryption guidance shows that key rotation does not automatically re-encrypt already encrypted data, which is a strong warning that `new primary key version` and `object is rewrapped now` are different truths.
- Cloud KMS key-state guidance shows that ciphertext remembers which key version encrypted it, and that primary-version choice and current decryptability are different truths.

## SlopOS pressure
Current SlopOS material rhymes with this even though it does not settle a final envelope / vault / key-handle substrate yet:
- `rfcs/0067-capability-crypto-services-and-key-handles.md` keeps key use bound to explicit keyrefs and routes instead of ambient secret material;
- `docs/30-architecture/cryptosvc-key-material-boundary-v0.md` keeps key use separate from secret-bearing import/export and rewrap folklore;
- `docs/30-architecture/vault-posture-v0.md` keeps provider-owned secret objects and inventory/recovery posture explicit instead of ambient;
- `docs/30-architecture/auth-proof-export-boundary-v0.md` keeps local auth ceremonies from quietly turning into portable proof-export or challenge-signing folklore;
- the broader archive keeps wallets, proof bundles, and current live authority on visibly different seams.

## Shell posture worth stealing
The shell should be able to say:
- `sealed object`
- `wrap roster: 3`
- `wrapped under key version ...`
- `rewrap planned`
- `rewrap complete`
- `unwrapable here`
- `clear facet bound`
- `history only`

…without pretending these are the same class.

## Do not decide yet
Do not decide yet:
- one universal envelope or recipient-wrap format across all ViewFS providers and object families;
- whether wraps live inline with the sealed object, in sidecars, or in provider-local indexes;
- one universal recipient taxonomy covering users, groups, devices, services, and provider-local key slots;
- whether rewrap mutates one object in place, creates a new sealed version, or is provider-specific;
- whether clear facets can survive restart, escrow, or cross-machine transfer;
- one universal unwrap-handle ABI or one universal clear-facet cache model.
