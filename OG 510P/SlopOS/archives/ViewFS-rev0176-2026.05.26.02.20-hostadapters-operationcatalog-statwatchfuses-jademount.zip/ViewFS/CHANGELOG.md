# Revision 176 (2026-05-26)

- Added the host-adapter/filesystem-compatibility executable lane: adapter mounts, stat projections, inode aliases, xattr parcels, watcher subscriptions, advisory lock tokens, rename plans, tempfile leases, hydration tickets, and external-app handoffs.
- Expanded the fixture corpus from 528 to 568 checked specimens and proof coverage from 155 to 166 obligations.
- Added 40 host-adapter fixtures covering mount-root laundering, stat/read leakage, inode identity claims, xattr-policy laundering, watcher-as-open claims, lock/write authority claims, rename completion/cross-mount denial, tempfile promotion gates, hydration currentness/source verification, and external-handoff persistence/redaction gates.
- Added `docs/30-architecture/host-adapter-compatibility-v0.md`, `docs/40-verification/host-adapter-trace-reporting-v0.md`, `docs/70-shell/host-adapter-stat-watch-handoff-cards.md`, and `rfcs/0164-viewfs-host-adapter-filesystem-compatibility-and-operation-catalog-audit.md`.
- Added `tools/build_host_adapter_trace_report.py` and generated `out/host_adapter_trace_report.md`.
- Audited/refactored operation growth with `tools/operation_catalog.py`, `tools/check_operation_catalog.py`, `tools/build_operation_catalog_report.py`, `out/operation_catalog_report.md`, and `docs/40-verification/operation-catalog-audit-v0.md`; `tools/check_fixture_operation_balance.py` now uses the shared operation catalog.
- Updated claims, invariants, non-claims, proof obligations, core schema, generated reports, context pack, and release manifest for the new revision.

# Revision 175 (2026-05-26)

- Added the schema/ontology interoperability executable lane: namespace bindings, external references, vocabulary terms, crosswalk mappings, shape constraints, ontology alignments, catalog entries, and interop cards.
- Expanded the fixture corpus from 496 to 528 checked specimens and proof coverage from 146 to 155 obligations.
- Added 32 interoperability fixtures covering namespace digest/prefix discipline, URI/reference freshness, vocabulary namespace binding, crosswalk confidence/review, shape validation, ontology alignment, catalog publication, and interop-card honesty.
- Added `docs/30-architecture/schema-ontology-interoperability-v0.md`, `docs/40-verification/interop-trace-reporting-v0.md`, `docs/70-shell/interop-reference-crosswalk-cards.md`, and `rfcs/0163-viewfs-schema-ontology-reference-crosswalk-and-record-family-audit.md`.
- Added `tools/build_interop_trace_report.py` and generated `out/interop_trace_report.md`.
- Audited/refactored schema growth with `tools/check_record_family_catalog.py`, `tools/build_record_family_report.py`, `out/record_family_report.md`, and `docs/40-verification/record-family-catalog-audit-v0.md`; lint now requires every record family to be sorted, unique, snake_case, and exercised by at least one non-empty fixture row.
- Updated claims, invariants, assumptions, non-claims, proof obligations, core schema, generated reports, context pack, and release manifest for the new revision.

# Revision 174 (2026-05-26)

- Added the personalization/convenience executable lane: user profiles, preference sets, personalization models, recommendation sets, shortcut bindings, autofill proposals, experiment assignments, feedback signals, and personalization cards.
- Expanded the fixture corpus from 460 to 496 checked specimens and proof coverage from 136 to 146 obligations.
- Added 36 personalization fixtures covering profile/session binding, preference scopes, model purpose/minimization, recommendation redaction, shortcut approval/target rights, autofill redaction/write rights, experiment scopes/epochs, feedback purpose/training consent, and personalization-card honesty.
- Added `docs/30-architecture/personalization-preferences-recommendation-v0.md`, `docs/30-architecture/shortcut-autofill-feedback-experiment-v0.md`, `docs/40-verification/personalization-trace-reporting-v0.md`, `docs/70-shell/personalization-preference-shortcut-cards.md`, and `rfcs/0162-viewfs-personalization-recommendation-shortcut-and-lint-manifest-audit.md`.
- Added `tools/build_personalization_trace_report.py` and generated `out/personalization_trace_report.md`.
- Audited/refactored top-level lint by adding `tools/lint_manifest.py`, `tools/check_lint_manifest.py`, and `docs/40-verification/lint-manifest-refactor-v0.md`; `tools/lint_repo.py` now imports manifest state instead of owning a long duplicated list.
- Updated claims, invariants, assumptions, non-claims, proof obligations, core schema, generated reports, context pack, and release manifest for the new revision.

# Revision 173 (2026-05-25)

- Added the workflow/automation custody executable lane: event envelopes, trigger rules, schedule windows, workflow runs, step invocations, idempotency keys, retry policies, compensation plans, human tasks, and workflow cards.
- Expanded the fixture corpus from 420 to 460 checked specimens and proof coverage from 125 to 136 obligations.
- Added 40 automation fixtures covering event-source trust, trigger epochs, schedule windows, workflow lease/basis checks, target-handle step execution, idempotency fingerprint/replay guards, retry attempts/backoff/budget, compensation reversibility, human-task trusted paths, and workflow-card honesty.
- Added `docs/30-architecture/workflow-automation-custody-v0.md`, `docs/30-architecture/workflow-idempotency-compensation-human-tasks-v0.md`, `docs/40-verification/automation-trace-reporting-v0.md`, `docs/70-shell/workflow-automation-cards.md`, and `rfcs/0161-viewfs-workflow-automation-custody-and-trace-report-registry-audit.md`.
- Added `tools/build_automation_trace_report.py` and generated `out/automation_trace_report.md`.
- Audited/refactored trace-report generation with `tools/report_registry.py`, `tools/build_all_trace_reports.py`, `tools/check_report_registry.py`, `docs/40-verification/trace-report-registry-refactor-v0.md`, and a `trace-reports` Make target.
- Updated claims, invariants, assumptions, non-claims, proof obligations, core schema, generated reports, context pack, and release manifest for the new revision.

# Revision 172 (2026-05-25)

- Added the governance/change-management executable lane: change proposals, decision records, approval quorums, rollout plans, feature flags, deprecation notices, compatibility contracts, migration runs, and governance cards.
- Expanded the fixture corpus from 384 to 420 checked specimens and proof coverage from 116 to 125 obligations.
- Added 36 governance fixtures covering proposal admission, stale basis denial, decision digest binding, quorum thresholds, steward requirements, rollout guardrails, feature-flag scope/currentness, deprecation windows, compatibility version binding, migration prechecks, rollback plans, and governance-card honesty.
- Added `docs/30-architecture/governance-change-management-v0.md`, `docs/40-verification/governance-trace-reporting-v0.md`, `docs/70-shell/governance-change-management-cards.md`, and `rfcs/0160-viewfs-governance-change-management-and-fixture-catalog-audit.md`.
- Added `tools/build_governance_trace_report.py` and generated `out/governance_trace_report.md`.
- Audited/refactored fixture-catalog discipline by adding `tools/fixture_catalog.py`, `tools/check_fixture_catalog.py`, `tools/build_fixture_catalog_report.py`, `docs/40-verification/fixture-catalog-audit-v0.md`, and `out/fixture_catalog_report.md`.
- Fixed fixture `008` filename discipline by renaming it from `008-derived-artifact-not-retention-root.json` to `008-derived-artifact-not-retention-root-denied.json`.
- Refactored proof-coverage and operation-balance checks to use the shared fixture catalog loader.
- Updated claims, invariants, proof obligations, generated reports, context pack, and release manifest for the new revision.

# Revision 171 (2026-05-25)

- Added the incident/forensic/remediation executable lane: alert signals, incident cases, triage verdicts, forensic snapshots, evidence chains, containment plans, remediation plans, recovery rollbacks, and postmortem records.
- Expanded the fixture corpus from 344 to 384 checked specimens and proof coverage from 107 to 116 obligations.
- Added 36 incident-response fixtures covering alert admission, stale/authority-claiming alert denial, incident case authority, active-alert dependency, triage confidence, forensic redaction, evidence-chain integrity, containment blast-radius gates, remediation preconditions/receipt replay, rollback epoch freshness, and postmortem honesty.
- Added four positive balance fixtures for `read_handle`, `semantic_open`, `retain_source_via_index`, and `reacquire_from_restore_token`, closing pre-existing negative-only operation coverage.
- Added `docs/30-architecture/incident-forensic-remediation-v0.md`, `docs/40-verification/incident-response-trace-reporting-v0.md`, `docs/70-shell/incident-forensic-remediation-cards.md`, and `rfcs/0159-viewfs-incident-forensic-remediation-and-operation-balance-audit.md`.
- Added `tools/build_incident_response_trace_report.py` and generated `out/incident_response_trace_report.md`.
- Audited/refactored fixture schema ownership by adding `tools/fixture_schema.py` and importing schema metadata from the fixture checker.
- Added `tools/check_fixture_operation_balance.py` and wired it into `make lint`, requiring every checked operation to have at least one positive and one negative specimen.
- Updated claims, invariants, proof obligations, context pack, and release manifest for the new revision.

# Revision 170 (2026-05-25)

- Added the query/evaluation executable lane: query specs, planner traces, result sets, aggregation views, evaluation sets, benchmark runs, scoring rubrics, and model-selection cards.
- Expanded the fixture corpus from 312 to 344 checked specimens and proof coverage from 99 to 107 obligations.
- Added 32 fixtures covering saved-query denial, query scope/field bounds, planner proposal denial, rights-widening denial, result-member backing handles, stale result denial, aggregation thresholding, raw-row/membership-oracle denial, contaminated eval sets, score-as-deploy denial, unreproducible benchmark denial, uncalibrated/gamed rubrics, and dishonest model-selection cards.
- Added `docs/30-architecture/query-planning-result-evaluation-v0.md`, `docs/40-verification/query-eval-trace-reporting-v0.md`, `docs/70-shell/query-eval-cards-and-benchmark-dashboards.md`, and `rfcs/0158-viewfs-query-planning-result-evaluation-and-trace-report-refactor.md`.
- Added `tools/build_query_eval_trace_report.py` and generated `out/query_eval_trace_report.md`.
- Audited/refactored trace reports by adding `tools/trace_report_common.py` and converting specialized trace builders to wrappers over the shared helper.
- Refactored `tools/check_viewfs_core_fixtures.py` from a long operation `if` chain into an auditable `EVALUATORS` dispatch table.
- Updated claims, invariants, proof obligations, context pack, and release manifest for the new revision.

# Revision 169 — classification, license, jurisdiction, purpose, release, and compliance-card gates

- Added 31 checked compliance-label/release fixtures, expanding the corpus from 281 to 312 specimens.
- Added record families for `ClassificationMark`, `LicenseTerm`, `JurisdictionFence`, `ComplianceObligation`, `PublicReleaseReview`, `PurposeBinding`, and `ComplianceCard`.
- Added checked operations for classification-mark accounting, license-use authorization, jurisdiction-fence checks, compliance-obligation enforcement, public-release approval, purpose-use binding, and compliance-card rendering.
- Added `tools/build_compliance_trace_report.py` and generated `out/compliance_trace_report.md`.
- Added architecture, shell, verification, research, claim, invariant, proof-obligation, and RFC notes for compliance-label and release-gate laundering.

# Revision 168 — transform, codec, migration, annotation, lineage, preview, and canonicalization gates

- Added 30 checked transform/lineage fixtures, expanding the corpus from 251 to 281 specimens.
- Added record families for `TransformPlan`, `CodecProfile`, `SchemaMigration`, `PatchSet`, `AnnotationLayer`, `LineageLink`, `PreviewArtifact`, and `CanonicalizationProfile`.
- Added checked operations for transform application, codec decode/preview, schema migration, patch application, annotation attachment, lineage verification, preview rendering, and canonicalization admission.
- Added `tools/build_transform_lineage_trace_report.py` and generated `out/transform_lineage_trace_report.md`.
- Added architecture, shell, verification, research, claim, invariant, proof-obligation, and RFC notes for interpretation/derived-artifact laundering.

# Revision 167 — runtime, device, network, clipboard, drag/drop, peripheral, and sensor boundary gates

- Added 26 checked boundary-reality fixtures, expanding the corpus from 225 to 251 specimens.
- Added record families for `RuntimePosture`, `DeviceAttestation`, `NetworkConnector`, `ClipboardParcel`, `DragDropParcel`, `PeripheralGrant`, and `SensorObservation`.
- Added checked operations for runtime posture verification, network connector admission, clipboard parcel redemption, drag/drop parcel redemption, peripheral binding, and sensor observation redemption.
- Added `tools/build_boundary_reality_trace_report.py` and generated `out/boundary_reality_trace_report.md`.
- Added architecture, shell, verification, research, and RFC notes for local/runtime/device/network/clipboard/sensor boundary laundering.

# Revision 166 — identity, credential, encryption, secret, and escrow gates

- Added 27 checked identity/secret-custody fixtures, expanding the corpus from 198 to 225 specimens.
- Added record families for `IdentityAssertion`, `SessionBinding`, `CredentialToken`, `EncryptionEnvelope`, `KeyVersion`, `KeyRotationPlan`, `SecretLease`, `SecretInjectionPlan`, `EscrowRecoveryWarrant`, and `SecretCard`.
- Added checked operations for identity-session verification, credential-token redemption, encryption-envelope open, key-version rotation, secret lease use, secret injection, escrow recovery, and secret-card rendering.
- Added `tools/build_identity_secret_trace_report.py` and generated `out/identity_secret_trace_report.md`.
- Added architecture, shell, verification, research, and RFC notes for identity/credential/secret laundering.

# Revision 165 — resource budgets, rate limits, background jobs, cache, capacity, and metering gates

- Added 26 checked resource/side-effect fixtures, expanding the corpus from 172 to 198 specimens.
- Added record families for `ResourceBudget`, `SpendReservation`, `RateLimiter`, `BackgroundJob`, `CacheEntry`, `CapacitySignal`, and `MeteringReceipt`.
- Added checked operations for budget reservation, rate admission, background job start, cache hydration, capacity signal emission, and metering settlement.
- Added `tools/build_resource_trace_report.py` and generated `out/resource_trace_report.md`.
- Added architecture, shell, verification, research, and RFC notes for resource and side-effect laundering.

## Revision 164 executable supply-chain / plugin-tool boundary spine

- expanded the executable ViewFS fixture corpus from 146 to 172 specimens, adding package admission, dependency pin, provenance, transparency, verifier-root, extension-manifest, tool-schema, tool-binding, sandbox, and approved tool-invocation checks.
- extended `tools/check_viewfs_core_fixtures.py` with `PackageEnvelope`, `DependencyPin`, `ProvenanceAttestation`, `TransparencyEntry`, `VerifierRoot`, `ExtensionManifest`, `ToolSchema`, `ToolBinding`, `InstallPlan`, and `SandboxProfile` record families plus `verify_package_install`, `resolve_dependency_pin`, `verify_transparency_entry`, `admit_verifier_root`, `bind_extension_tool`, and `invoke_extension_tool` operations.
- added `tools/build_supply_chain_trace_report.py` and generated `out/supply_chain_trace_report.md`; `make lint` now regenerates conformance, policy, freshness, disclosure, collaboration, GC/archive, and supply-chain trace reports.
- added `docs/30-architecture/supply-chain-package-admission-v0.md`, `docs/30-architecture/extension-tool-schema-sandbox-v0.md`, `docs/40-verification/supply-chain-trace-reporting-v0.md`, and `docs/70-shell/supply-chain-extension-cards-and-tool-fuses.md`.
- added `rfcs/0152-viewfs-supply-chain-package-extension-tool-and-sandbox-gates.md`.
- added proof obligations `PO-VIEWFS-PACKAGE-001`, `PO-VIEWFS-DEPENDENCY-001`, `PO-VIEWFS-PROVENANCE-001`, `PO-VIEWFS-TRANSPARENCY-001`, `PO-VIEWFS-VERIFIERROOT-001`, `PO-VIEWFS-EXTENSION-001`, `PO-VIEWFS-TOOLSCHEMA-001`, `PO-VIEWFS-TOOLBINDING-001`, `PO-VIEWFS-SANDBOX-001`, and `PO-VIEWFS-TOOLINVOKE-001`.
- added `docs/00-meta/research-synthesis-2026-05-23-pass-cme.md` and refreshed core schema, proof obligations, reports, context pack, and release manifest for the new revision.

## Revision 163 executable GC/archive/deletion spine

- expanded the executable ViewFS fixture corpus from 121 to 146 specimens, adding GC candidate, snapshot pin, archive/legal hold, backup set, restore plan, deletion claim, and sanitization proof checks.
- extended `tools/check_viewfs_core_fixtures.py` with `GcCandidate`, `SnapshotPin`, `ArchiveHold`, `BackupSet`, `RestorePlan`, `DeletionClaim`, and `SanitizationProof` record families plus `collect_gc_candidate`, `prune_snapshot`, `release_archive_hold`, `restore_from_backup`, and `verify_deletion_claim` operations.
- added `tools/build_gc_archive_trace_report.py` and generated `out/gc_archive_trace_report.md`; `make lint` now regenerates conformance, policy, freshness, disclosure, collaboration, and GC/archive trace reports.
- added `docs/30-architecture/gc-snapshot-hold-backup-lifecycle-v0.md`, `docs/30-architecture/deletion-claims-sanitization-and-restore-v0.md`, `docs/40-verification/gc-archive-trace-reporting-v0.md`, and `docs/70-shell/gone-vs-retained-snapshot-backup-and-deletion-cards.md`.
- added `rfcs/0151-viewfs-gc-snapshot-archive-hold-backup-restore-and-deletion-proof-gates.md`.
- added proof obligations `PO-VIEWFS-SNAPSHOT-001`, `PO-VIEWFS-HOLD-001`, `PO-VIEWFS-BACKUP-001`, `PO-VIEWFS-RESTORE-001`, `PO-VIEWFS-DELETION-001`, and `PO-VIEWFS-SANITIZE-001`.
- added `docs/00-meta/research-synthesis-2026-05-22-pass-cmd.md` and refreshed core schema, proof obligations, reports, context pack, and release manifest for the new revision.

## Revision 162 executable collaboration and namespace-composition spine

- expanded the executable ViewFS fixture corpus from 98 to 121 specimens, adding shared-room composition, non-member denial, mount-edge widening denial, propagation-gate denial, stale room epoch denial, group membership checks, label overlay conflict checks, handoff packet acceptance/replay checks, and collaboration-card honesty checks.
- extended `tools/check_viewfs_core_fixtures.py` with `SharedRoom`, `MountEdge`, `GroupMembership`, `LabelOverlay`, `HandoffPacket`, and `CollaborationCard` record families plus `compose_shared_view`, `group_bound_authority`, `resolve_label_overlay`, `handoff_packet`, and `render_collaboration_card` operations.
- added `tools/build_collaboration_trace_report.py` and generated `out/collaboration_trace_report.md`; `make lint` now regenerates conformance, policy, freshness, disclosure, and collaboration trace reports.
- added `docs/30-architecture/shared-rooms-mount-edges-and-group-gates-v0.md`, `docs/30-architecture/label-overlays-handoff-packets-and-collaboration-cards-v0.md`, `docs/40-verification/collaboration-trace-reporting-v0.md`, and `docs/70-shell/collaboration-room-mount-label-and-handoff-cards.md`.
- added `rfcs/0150-viewfs-shared-rooms-mount-edges-group-labels-and-handoff-gates.md`.
- added proof obligations `PO-VIEWFS-SHAREDROOM-001`, `PO-VIEWFS-MOUNTEDGE-001`, `PO-VIEWFS-GROUP-001`, `PO-VIEWFS-LABEL-001`, `PO-VIEWFS-HANDOFF-001`, and `PO-VIEWFS-COLLAB-001`.
- added `docs/00-meta/research-synthesis-2026-05-22-pass-cmc.md` and refreshed core schema, proof obligations, fixture coverage, reports, context pack, and release manifest for the new revision.

# Revision 161 (2026-05-22)

## What Revision 161 adds
- continued research and synthesis around structured observability, event envelopes, privacy access/erasure pressure, verifiable packaging, redaction/minimization, publication correction, and stewarded disclosure review.
- expanded the executable ViewFS fixture corpus from 76 to 98 specimens.
- added redaction-view fixtures showing allowed field read, blocked field denial, and redaction-view-alone denial.
- added audit-projection fixtures showing redacted audit rendering allowance, raw-audit denial without raw authority, authority-badge lie denial, and audit redaction leak denial.
- added disclosure-package fixtures showing approved redacted egress, old disclosure receipt replay denial, raw disclosure denial without raw-export authority, missing-redaction denial, and source/sink scope mismatch denial.
- added subscription/notification fixtures showing metadata notification allowance, full-payload redaction leak denial, expired cursor denial, notification-as-open denial, and missing observe-authority denial.
- added subject-access fixtures showing approved redacted export, unapproved request denial, third-party redaction leak denial, receipt replay denial, and scope mismatch denial.
- extended `tools/check_viewfs_core_fixtures.py` with `RedactionView`, `AuditProjection`, `DisclosurePackage`, `SubscriptionCursor`, `NotificationEnvelope`, and `SubjectAccessRequest` record families plus `redaction_view_read`, `render_audit_projection`, `disclose_package`, `deliver_notification`, and `subject_access_export` operations.
- added `tools/build_disclosure_trace_report.py`, `out/disclosure_trace_report.md`, and Makefile/lint integration.
- added `docs/30-architecture/disclosure-observation-redaction-v0.md`, `docs/40-verification/disclosure-trace-reporting-v0.md`, and `docs/70-shell/disclosure-lamps-redaction-drawers-and-observation-cards.md`.
- added `rfcs/0149-viewfs-disclosure-observation-redaction-subscription-and-subject-access-gates.md`.
- added proof obligations for redaction, audit, disclosure, subscription, and subject-access gates, all covered by fixtures.
- refreshed assurance registries, context pack, generated reports, and release manifest for the new archive.

## Revision 160 — 2026-05-22
- continued research and synthesis across NFSv4 lease/delegation invalidation, local-first/offline sync, content-addressed identifiers, verifiable-credential status lists, distributed-clock uncertainty, write-ahead-log checkpointing, and merge-conflict systems.
- expanded the executable ViewFS fixture corpus from 54 to 76 specimens.
- added distributed-state fixtures for lease renewal, stale/expired lease denial, offline branch publish/revalidation, merge reconciliation, remote attestation evidence, freshness fences, and journal checkpoints.
- extended `tools/check_viewfs_core_fixtures.py` with `AuthorityLease`, `OfflineBranch`, `MergePlan`, `RemoteAttestation`, `FreshnessFence`, and `JournalCheckpoint` record families plus six checked operations.
- added `tools/build_freshness_trace_report.py`, `out/freshness_trace_report.md`, and Makefile/lint integration.
- added `rfcs/0148-viewfs-freshness-leases-offline-branches-merge-and-attestation-gates.md`.
- added freshness/lease/offline/merge/attestation/checkpoint architecture, verification, shell, proof-obligation, claim, invariant, and assumption entries.
- regenerated `out/context_pack.md`, `out/conformance_report.md`, `out/policy_trace_report.md`, `out/freshness_trace_report.md`, and `RELEASE-MANIFEST.json` for the new archive.

## Revision 159 — 2026-05-22
- continued research and synthesis across OPA-style decision logs, Cedar-style authorization request structure, in-toto/SLSA-style subject/input witness binding, OpenTelemetry-style generated traces, and Ward-style stewardship/override accountability.
- expanded the executable ViewFS fixture corpus from 40 to 54 specimens.
- added policy-decision fixtures showing enforced allow with live authority, decision-without-handle denial, advisory-allow denial, stale-bundle denial, and policy-deny denial.
- added witness-bundle fixtures showing complete evidence allowance, missing-fact denial, digest-mismatch denial, and replay-effect denial.
- added scenario-replay fixtures showing witnessed positive/negative replay allowance, happy-path-only denial, and missing-witness denial.
- added breakglass override fixtures showing verified steward override allowance and missing-steward denial.
- extended `tools/check_viewfs_core_fixtures.py` with policy/witness/replay/override record families and operations.
- added `tools/build_policy_trace_report.py`, `out/policy_trace_report.md`, and Makefile/lint integration.
- added `rfcs/0147-viewfs-policy-witness-bundles-replay-scenarios-and-breakglass-gates.md`.
- added policy/witness/replay/override architecture, verification, shell, proof-obligation, claim, invariant, and assumption entries.
- regenerated `out/context_pack.md`, `out/conformance_report.md`, `out/policy_trace_report.md`, and `RELEASE-MANIFEST.json` for the new archive.

## What Revision 158 adds
- expands the executable ViewFS fixture corpus from 30 to 40 specimens, adding quarantine, trust-transition, authority-diff, export-plan, and receipt-replay pressure.
- extends `tools/check_viewfs_core_fixtures.py` with `OriginEvidence`, `QuarantineCapsule`, `TrustTransition`, `AuthorityDiff`, and `ExportPlan` record families plus `quarantine_open`, `trust_transition_release`, `render_authority_diff`, and `export_plan` operations.
- adds `tools/build_conformance_report.py` and generated `out/conformance_report.md`; `make lint` now regenerates the report so fixture/proof coverage is reviewable as a single markdown artifact.
- adds `docs/30-architecture/quarantine-trust-transition-v0.md`, `docs/30-architecture/authority-diff-and-export-plan-v0.md`, `docs/40-verification/conformance-reporting-v0.md`, and `docs/70-shell/authority-diff-cards-and-conformance-dashboards.md`.
- adds `rfcs/0146-viewfs-quarantine-authority-diff-export-and-conformance-reporting.md`.
- adds proof obligations `PO-VIEWFS-QUARANTINE-001`, `PO-VIEWFS-AUTHDIFF-001`, `PO-VIEWFS-EXPORT-001`, and `PO-VIEWFS-CONFORMANCE-001`.
- adds `docs/00-meta/research-synthesis-2026-05-21-pass-cly.md`, incorporating TUF freshness/rollback pressure, SLSA provenance separation, Sigstore/Rekor transparency-history pressure, OCI sidecar/referrer pressure, WASI descriptor access, and OpenTelemetry generated-report posture.
- refreshes assurance registries, evidence hooks, context pack, conformance report, and release manifest for `ViewFS-rev0158-2026.05.21.14.09-quarantineauthdiff-exportplans-conformancereports-jadebastion.zip`.

## What Revision 157 adds
- expands the executable ViewFS fixture corpus from 20 to 30 specimens, adding adversarial path resolver checks, delegation-chain checks, shell-card honesty checks, and derived-artifact cleanup checks.
- extends `tools/check_viewfs_core_fixtures.py` with `PathNode`, `Delegation`, `ShellCard`, and `CopyInventory` record families plus `delegate_handle`, `render_shell_card`, and `forget_source` operations.
- strengthens `compat_pathwalk` so symlink, magic/synthetic, and mount/provider crossings are distinct checked denial reasons rather than generic path failures.
- adds `docs/30-architecture/resolver-conformance-v0.md`, `docs/30-architecture/delegation-chain-and-shell-card-honesty-v0.md`, and `docs/30-architecture/derived-artifact-cleanup-ledger-v0.md`.
- adds `rfcs/0145-viewfs-resolver-delegation-shell-and-derived-cleanup-fixture-hardening.md`.
- adds proof obligations `PO-VIEWFS-PATHWALK-001`, `PO-VIEWFS-DELEGATION-001`, `PO-VIEWFS-SHELL-001`, and `PO-VIEWFS-DERIVED-001`, all covered by fixtures.
- adds `docs/00-meta/research-synthesis-2026-05-21-pass-clx.md`, incorporating openat2 resolver flags, WASI descriptor-relative paths, File System Access handle/persistence pressure, SLSA provenance analogy, and companion-cube pressure.
- refreshes assurance registries, evidence hooks, context pack, and release manifest for `ViewFS-rev0157-2026.05.21.13.18-resolverdelegation-shellhonesty-copyinventories-jadecairn.zip`.

## What Revision 156 adds
- expands the executable ViewFS spine from 8 to 20 fixtures, covering handle attenuation, mutable commit cuts, stale-base denial, restore-token death verdicts, explicit retention roots, prompt/action-plan toolcall boundaries, portal grant replay, and revoked-handle inertness.
- extends `docs/30-architecture/core-schema-v0.md` with `MutableSession`, `RevocationEvent`, `RetentionRoot`, and `ActionPlan` families plus new checked operations.
- adds `docs/30-architecture/mutable-anchor-commit-cut-v0.md`, `docs/30-architecture/revocation-stale-brakes-and-retention-roots-v0.md`, and `docs/30-architecture/action-plan-toolcall-lane-v0.md`.
- adds `rfcs/0144-viewfs-fixture-coverage-lifecycle-hardening-and-agentic-action-cuts.md`.
- adds `tools/check_proof_fixture_coverage.py`; fixtures now carry `covers` lists and `make lint` fails if proof-obligation coverage drifts.
- updates `docs/40-verification/proof-obligations-v0.md` with mutable, revocation, retention, and fixture-coverage obligations.
- adds `docs/00-meta/research-synthesis-2026-05-21-pass-clw.md`, incorporating ambient-rights, WASI/capability, persistent bookmark/token, MCP/LLM agency, and lifecycle-state pressure.
- refreshes assurance registries, evidence hooks, roadmap, trajectory, companion seam intake, context pack, and release manifest for `ViewFS-rev0156-2026.05.21.12.31-lifecyclefixtures-coveragegates-stalebrakes-opalharbor.zip`.

## Revision 155 — 2026-05-21
- continued research and synthesis across capability namespaces, path-resolution fences, portal/document grants, prompt/agent/vector risks, trusted-path/activation/volition patterns, and the uploaded companion cubes.
- replaced embedded `slopos/` rev0655 with uploaded SlopOS `rev0720`, bringing ViewFS back into alignment with the companion snapshot it claims to include.
- added `rfcs/0143-viewfs-executable-core-schema-proof-obligation-and-fixture-spine.md`.
- added `docs/30-architecture/core-schema-v0.md`, `docs/40-verification/proof-obligations-v0.md`, and `docs/30-architecture/companion-seam-intake.md`.
- added `fixtures/viewfs-core-v0/` with eight positive/negative JSON specimens covering portal import, pathwalk, receipt, digest, semantic-result, consent, approval-cut, and derived-artifact retention seams.
- added `tools/check_viewfs_core_fixtures.py`, `tools/check_rfc_numbers.py`, and `tools/check_registry_ids.py`, then wired them into `make lint`.
- repaired archive hygiene: duplicate registry IDs are renumbered, the accidental duplicate RFC number is resolved by moving the semantic-object-core RFC to `0142`, and `docs/00-meta/rfc-renumbering-ledger.md` records the repair.
- refreshed README, architecture trajectory, design splits, SlopOS seam map, evidence hooks, context pack, and release manifest for the executable-spine revision.

# Revision 154 (2026-05-18)

## What Revision 154 adds
- continued external research on human-consent and trusted-path hygiene: EROS Trusted Window System, WHATWG/HTML user activation, Wayland xdg-activation, Windows Secure Attention Sequence, WebAuthn/CTAP user presence/user verification, OWASP clickjacking guidance, and SlopOS D-VOLITION / D-POWERBOX / consent-receipt seams.
- added `rfcs/0141-viewfs-keep-consent-summaries-presentation-surfaces-gesture-evidence-volition-tokens-approval-cuts-live-authority-and-receipts-separate.md`.
- added `docs/30-architecture/consent-summaries-presentation-surfaces-gesture-evidence-volition-tokens-approval-cuts-live-authority-and-receipts.md` and `docs/70-shell/consent-cards-trusted-path-lamps-volition-tokens-clickjacking-shields-and-approval-receipts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the anti-collapse rule: a click, focus state, prompt reply, presentation surface, gesture witness, volition token, approval cut, live authority slot, and consent receipt are separate objects.
- refreshed architecture overview, design-splits note, SlopOS seam map, shell idea/protocol notes, bibliography, source-head register, review queue, evidence index, claim/invariant/assumption registries, roadmap, trajectory map, and lint coverage.
- regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Revision 153 (2026-05-18)

## What Revision 153 adds
- continued external research on instruction/prompt/agent hygiene: prompt injection and indirect prompt injection, model-context/tool-call boundaries, MCP tools/resources/prompts security notes, VS Code custom instruction and parent-repository discovery behavior, instruction-hierarchy research, and SlopOS D-LLM/MCP/tool-UI seams.
- added `rfcs/0140-viewfs-keep-instruction-sources-context-frames-proposal-text-action-plans-tool-invocations-approvals-live-authority-and-receipts-separate.md`.
- added `docs/30-architecture/instruction-sources-context-frames-proposal-text-action-plans-tool-invocations-approvals-live-authority-and-receipts.md` and `docs/70-shell/instruction-rails-context-shutters-action-plan-cards-toolcall-fuses-and-approval-receipts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the seam: instruction source record, trust/priority label, context frame/input capsule, model/prompt profile, proposal text, typed action plan, tool invocation candidate, approval/adoption cut, current live authority, result/observation, and receipt/history.
- refreshed architecture overview, design-splits note, SlopOS seam map, shell idea/protocol notes, bibliography, source-head register, review queue, evidence index, claim/invariant/assumption registries, roadmap, trajectory map, and lint coverage.
- regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Revision 152 (2026-05-18)

## What Revision 152 adds
- continued external research on semantic derivation and retrieval-store hygiene: Apple Spotlight search privacy exclusions, GNOME LocalSearch indexing/extraction/control/writeback splits, Pinecone and Weaviate multitenancy isolation patterns, embedding inversion leakage research, OWASP LLM08 vector/embedding risk guidance, and SlopOS D-QUAR / D-ATTRFS content-index boundaries.
- added `rfcs/0139-viewfs-keep-semantic-extraction-intents-derived-artifacts-embedding-stores-query-scopes-result-projections-answer-cards-live-authority-and-receipts-separate.md`.
- added `docs/30-architecture/semantic-extraction-intents-derived-artifacts-embedding-stores-query-scopes-result-projections-answer-cards-live-authority-and-receipts.md` and `docs/70-shell/semantic-derivation-cards-embedding-vaults-scope-filters-result-shades-and-answer-receipts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the seam: semantic extraction intent versus source snapshot/input capsule versus extractor/model profile versus derived artifact versus index/store membership versus query scope/access gate versus result projection versus answer/suggestion card versus current live authority versus receipt/history.
- refreshed architecture overview, design-splits note, SlopOS seam map, shell idea/protocol notes, bibliography, source-head register, review queue, evidence index, claim/invariant/assumption registries, roadmap, trajectory map, and lint coverage.
- regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Revision 151 (2026-05-16)

## What Revision 151 adds
- continued external research on content-address / dedup privacy hygiene: Venti/Foundation CAS, IPFS CID profiles, Nix content-addressed store objects, Tahoe-LAFS convergence secrets, proof-of-ownership attacks against client-side dedup, DupLESS/message-locked encryption, ZFS dedup resource costs, KSM page-sharing side channels, and the included SlopOS object/fresh-identity/verified-blob/microVM-dedup posture.
- added `rfcs/0138-viewfs-keep-content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts.md` and `docs/70-shell/digest-shades-equality-rails-dedup-shutters-convergence-lamps-and-cache-ghosts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the seam: content address versus equality/comparison witness versus dedup eligibility hint versus convergence/privacy domain versus cache/membership observation versus proof-of-possession versus materialization decision versus current live facet versus receipt/history.
- refreshed architecture overview, design-splits note, SlopOS seam map, shell idea/protocol notes, bibliography, source-head register, review queue, evidence index, claim/invariant/assumption registries, roadmap, and lint coverage.
- regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Revision 150 (2026-05-16)

## What Revision 150 adds
- continued external research on secure-transport identity hygiene: TLS 1.3, service identity verification, channel bindings, certificate transparency, SSH known-host checking, SPIFFE X.509-SVIDs, DANE/TLSA, and the included SlopOS D-NETLEASE certificate/verifier/resumption boundaries.
- added `rfcs/0137-viewfs-keep-transport-identities-verifier-profiles-trust-anchor-inputs-channel-bindings-session-resumption-live-secure-channels-and-receipts-separate.md`.
- added `docs/30-architecture/transport-identities-verifier-profiles-trust-anchor-inputs-transparency-status-evidence-channel-bindings-session-resumption-live-secure-channels-and-receipts.md` and `docs/70-shell/channel-binder-cards-cert-braids-trust-anchor-chips-resumption-shades-and-secure-channel-receipts.md`.
- expanded the SlopOS datacube evaluation with the lesson that transport intent, reference identity, presented evidence, verifier profile, trust-anchor/pin inputs, verification verdicts, channel bindings, session resumption/0-RTT state, current live secure channels, and receipts must stay separate.
- refreshed architecture, design-split, SlopOS seam, shell, terminal protocol, bibliography/source-head, review queue, evidence, claim, invariant, assumption, and lint hygiene, then regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Revision 149 (2026-05-15)

## What Revision 149 adds
- continued external research on service discovery and binding hygiene: DNS-SD/mDNS browse-vs-resolve, Kubernetes Service/EndpointSlice dynamics, xDS discovery/update/TTL behavior, systemd socket-activation fd delivery, SPIFFE workload identity, and the included SlopOS D-NETLEASE/service-binding/name-context pressure.
- added `rfcs/0136-viewfs-keep-service-designators-discovery-snapshots-readiness-claims-binding-cuts-activation-targets-live-service-handles-advertisements-and-receipts-separate.md`.
- added `docs/30-architecture/service-designators-discovery-snapshots-readiness-claims-binding-cuts-activation-targets-live-handles-advertisements-and-receipts.md` and `docs/70-shell/service-cards-discovery-drawers-readiness-lamps-binding-braids-activation-rails-advert-shutters-and-call-receipts.md`.
- expanded the SlopOS datacube evaluation with the lesson that service intent, designator, catalog/discovery authority, discovery snapshot, readiness evidence, binding cut, activation target, live service handle, advertisement, and receipt must stay separate.
- refreshed architecture, design-split, SlopOS seam, shell, terminal protocol, bibliography/source-head, review queue, evidence, claim, invariant, assumption, and lint hygiene, then regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Revision 148 (2026-05-15)

## What Revision 148 adds
- continued external research on network capability hygiene: sandboxed no-network defaults, static network entitlements, local-network permission prompts, DNS-over-HTTPS, SVCB/HTTPS service binding, Happy-Eyeballs address racing, private/local-network browser protections, and the included SlopOS D-NETLEASE boundary family.
- added `rfcs/0135-viewfs-keep-network-intents-resolution-witnesses-connection-leases-stream-handles-local-exposures-egress-cuts-live-authority-and-receipts-separate.md`.
- added `docs/30-architecture/network-intents-resolution-witnesses-connection-leases-stream-handles-local-exposures-egress-cuts-live-authority-and-receipts.md` and `docs/70-shell/net-lease-cards-resolver-braids-egress-meters-local-exposure-shutters-and-send-receipts.md`.
- expanded the SlopOS datacube evaluation with the lesson that network intents, destination designators, resolution witnesses, admission/lease descriptors, live dialers/resolvers/listeners/streams, local exposures, egress/import cuts, and receipts must stay separate.
- refreshed architecture, design-split, SlopOS seam, shell, terminal protocol, bibliography/source-head, review queue, evidence, claim, invariant, assumption, and lint hygiene, then regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

## Revision 147 — inspection lenses, proc shades, trace fuses, and dump guards

- Continued external research on diagnostics as authority: Linux `ptrace`, procfs `hidepid` / fd and memory peeks, `PR_SET_DUMPABLE`, core dump filtering, Fuchsia Inspect, ETW, DTrace privileges/destructive actions, Kubernetes RBAC subresources, macOS privacy gates, and the included SlopOS CH-INSPECT / observation-export / trace-processing / peer-inspection posture.
- Added `rfcs/0134-viewfs-keep-inspection-lenses-namespace-snapshots-fd-peeks-memory-captures-trace-probes-debug-controls-redaction-policy-live-authority-and-receipts-separate.md` to keep inspection intents, target locators, namespace snapshots, fd/slot peeks, memory/core captures, trace probes, debug-control lanes, redaction/export policy, live authority, and receipts separate.
- Added `docs/30-architecture/process-inspection-lenses-namespace-snapshots-fd-peeks-memory-captures-trace-probes-debug-controls-redaction-policies-live-authority-and-receipts.md` and `docs/70-shell/inspect-lenses-proc-shades-fd-peek-cards-trace-fuses-dump-guards-and-export-receipts.md`.
- Updated the architecture overview, design-splits note, SlopOS seam map, SlopOS datacube evaluation, inspiration map, shell idea/protocol notes, bibliography, source-head register, review queue, evidence index, claim/invariant/assumption registries, and lint coverage.
- Regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for the new archive.

# Changelog

## Revision 146 — 2026-05-15
- Added RFC 0133 and companion architecture/shell docs for delegation/revocation hygiene.
- Pinned the next anti-collapse seam: delegation intents, attenuation/caveat envelopes, membrane leases, delegated handles, revocation requests, revocation wavefronts/checkpoints, stale-handle brakes/death verdicts, renewal/redelegation controls, current live authority, and receipts stay distinct.
- Folded in SlopOS D-LEASE/RFC-0019/auth-revocation pressure plus current seL4, macaroon, UCAN, OAuth, temporary-credential, capability-URL, Tahoe-LAFS, CapTP, and Workers RPC lessons.
- Updated architecture overview, design splits, SlopOS seam map, inspirations, shell ideas, terminal protocol sketch, bibliography/source-head tracking, review queue, evidence/claim/invariant/assumption registries.
- Regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json`.

## Revision 145 — 2026-05-15
- Continued research on secret and credential delivery hygiene: systemd activation credentials, Kubernetes Secrets/projected volumes, Docker Swarm secrets, Secret Service prompt/lock semantics, Linux process environment visibility, GitHub Actions masking, AWS temporary credentials, and SlopOS D-APPSECRET/capshell environment/credential seams.
- Added `rfcs/0132-viewfs-keep-secret-descriptors-acquisition-prompts-delivery-slots-env-shadows-redaction-lenses-renewal-leases-live-use-handles-and-receipts-separate.md`.
- Added `docs/30-architecture/secret-descriptors-acquisition-prompts-delivery-slots-environment-shadows-redaction-lenses-renewal-leases-live-use-handles-and-receipts.md`.
- Added `docs/70-shell/secret-slot-cards-env-shadow-lamps-redaction-lenses-renewal-rails-and-use-receipts.md`.
- Updated the architecture overview, design splits, SlopOS seam map, inspirations, shell ideas, terminal protocol sketch, bibliography/source-head tracking, review queue, evidence index, claim registry, invariant registry, and assumption registry.
- Regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for `ViewFS-rev0145-2026.05.15.15.16-secretslots-envshadows-renewalrails-obsidianwell.zip`.


## Revision 144 — 2026-05-15
- Continued research on supply-chain evidence and admission hygiene: SPDX/CycloneDX inventory claims, PURL/CPE/OSV locator ambiguity, VEX scoped exploitability statements, in-toto/SLSA provenance, Sigstore/Rekor transparency, TUF freshness/delegation, and SlopOS's SBOM/VEX/attestation/verification seams.
- Added `rfcs/0131-viewfs-keep-artifact-envelopes-inventory-claims-locator-aliases-vulnerability-statements-admission-verdicts-activation-targets-live-facets-and-receipts-separate.md`.
- Added `docs/30-architecture/artifact-envelopes-inventory-claims-locator-aliases-vulnerability-statements-admission-verdicts-activation-targets-live-facets-and-receipts.md`.
- Added `docs/70-shell/sbom-drawers-locator-chips-vex-shutters-admission-cuts-and-live-rails.md`.
- Updated the architecture overview, design splits, SlopOS seam map, inspirations, shell ideas, terminal protocol sketch, bibliography/source-head tracking, review queue, evidence index, claim registry, invariant registry, and assumption registry.
- Regenerated `out/context_pack.md` and `RELEASE-MANIFEST.json` for `ViewFS-rev0144-2026.05.15.14.36-sbomdrawers-vexshutters-admissioncuts-goldreed.zip`.



## Revision 143 — 2026-05-14
- continued external research on archive/container extraction hazards, including Zip Slip/path traversal, Python tarfile extraction filters, Go tar/zip insecure-path compatibility toggles, bsdtar default path refusal, OCI manifest/layer/config separation, and SlopOS quarantine/materialization/root-escape posture.
- added `rfcs/0130-viewfs-keep-container-envelopes-member-claims-extraction-plans-materialization-roots-namespace-commits-live-opens-and-receipts-separate.md`.
- added `docs/30-architecture/container-envelopes-member-claims-extraction-plans-materialization-roots-namespace-commits-live-opens-and-receipts.md` and `docs/70-shell/extract-plan-cards-member-capsules-path-guard-badges-and-unpack-receipts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the archive/container extraction seam: container envelope versus member claim versus extraction plan versus sterile materialization root versus extracted member capsule versus namespace commit versus live open versus receipt/history.
- refreshed architecture overview, design splits, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography/source-head/review-queue entries, evidence index, claim registry, invariant registry, and assumption registry.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 142 — 2026-05-13
- continued external research on quarantine/safe-open anti-laundering, including origin markers, guarded document handling, isolated opens, download warnings, portal/document-store access, and content-index residue hazards.
- added `rfcs/0129-viewfs-keep-origin-evidence-quarantine-marks-safe-open-capsules-viewer-residue-derived-artifacts-trust-clearances-live-opens-and-receipts-separate.md`.
- added `docs/30-architecture/origin-evidence-quarantine-marks-safe-open-capsules-viewer-residue-derived-artifacts-trust-clearances-live-opens-and-receipts.md` and `docs/70-shell/quarantine-capsules-safe-open-shutters-residue-lamps-derived-artifact-rails-and-trust-receipts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the new anti-laundering seam, drawing on SlopOS D-QUAR/open-untrusted boundaries plus Apple quarantine/Gatekeeper, Windows Mark-of-the-Web/Protected View/Application Guard, Chrome Safe Browsing download warnings, XDG Documents, and Android SAF.
- refreshed architecture overview, design splits, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography/source-head/review-queue entries, evidence index, claim registry, invariant registry, and assumption registry.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 141 — 2026-05-13
- continued external research on object-store liveness, retention roots, pins/holds/leases, dry-run sweep posture, finalizer/delete choreography, and tombstone/ash receipts.
- added `rfcs/0128-viewfs-keep-reachability-roots-live-handle-roots-pin-holds-leases-sweep-candidates-finalizers-collected-ash-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/reachability-roots-live-handle-roots-pin-holds-leases-sweep-candidates-finalizers-collected-ash-live-facets-and-receipts.md` and `docs/70-shell/gc-halos-pin-badges-sweep-previews-finalizer-rails-and-ash-receipts.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the new liveness/GC seam, drawing on SlopOS CapStore/lease posture plus Git GC, Nix GC roots, IPFS pinning, containerd leases, Kubernetes finalizers/GC, and OpenZFS holds.
- refreshed architecture overview, design splits, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography/source-head/review-queue entries, evidence index, claim registry, invariant registry, and assumption registry.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 140 — 2026-05-13
- Added RFC 0127 to keep durable root commits, epoch fences/root-tip witnesses, restore intents, resurrection gates, activation targets, current live binds/handle sets, and receipts separate.
- Added architecture and shell notes for root ledgers, epoch fences, restore tickets, resurrection-gate drawers, activation previews, live-after-restore slot maps, and receipt-only ghosts.
- Re-evaluated SlopOS rev0695 CapStore, view namespace, capshell cwd/root, wallet, keyref/secretref, portal, and capability-flow materials as strong design pressure for ViewFS while explicitly avoiding a premature persistent-object-store or capability-resurrection ABI.
- Added new registry entries for durable-root/restore/activation hygiene and refreshed source-head hygiene around persistent capability systems, conditional object-store writes, consensus revisions, qrexec-style mediated transfer, and own/borrow resource handles.
- Regenerated the context pack and release manifest for the `rootledgers-epochfences-restorerails-ironmoss` archive.

## Revision 139 — 2026-05-13
- Added RFC 0126 to keep current handle inventories, custody chains, outflow gates, redacted flow snapshots/diffs, leak verdicts, live exports/proxies/borrows, and durable receipts separate.
- Added architecture and shell notes for flow maps, custody badges, outflow gates, leak sirens, audit drawers, and non-authoritative capability-flow artifacts.
- Re-evaluated SlopOS rev0695 capability graph/diff/export/wallet and portal/capshell materials as strong design pressure for ViewFS, while explicitly avoiding an early final object-store or handle ABI.
- Added new registry entries for the cap-flow/custody seam and refreshed source-head hygiene around redacted capability descriptions, ambient filesystem restriction, and currentness-witness precedents.
- Regenerated the context pack and release manifest for the `flowmaps-custodybadges-leakalarms-silverloom` archive.

## Revision 138 — 2026-05-13
- continued external research on explicit per-process namespaces, exact handle-slot tables, portal-mediated imports, capability references, object-store currentness witnesses, and design-phase non-decisions for the future SlopOS datacube.
- added `rfcs/0125-viewfs-keep-launch-view-plans-bound-roots-handle-slots-portal-import-tickets-live-binds-and-receipts-separate.md`.
- added `docs/30-architecture/launch-view-plans-bound-roots-handle-slots-portal-import-tickets-live-binds-and-receipts.md` and `docs/70-shell/slot-maps-root-badges-import-tickets-and-live-bind-rails.md`.
- expanded SlopOS/datacube evaluation with lessons from the included SlopOS capshell exact-handle table, bound cwd, no-ambient-filesystem, and portal-grant posture plus Fuchsia, Capsicum, WASI/WIT resources, XDG Documents, Tahoe-LAFS, Cap'n Proto, EROS, S3/GCS/Azure object-store folder/currentness lessons, and etcd transaction discipline.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging `ViewFS-rev0138-2026.05.13.15.56-slotmaps-rootbadges-importtickets-copperloom.zip`.

## Revision 137 — 2026-03-28
- continued external research on object-store folder folklore, prefix-projection honesty, provider-native folder-resource seams, listing-snapshot truth, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0124-viewfs-keep-committed-objects-prefix-projections-folder-resources-listing-snapshots-published-names-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/committed-objects-prefix-projections-folder-resources-listing-snapshots-published-names-live-facets-and-receipts.md` and `docs/70-shell/prefix-badges-folder-ghosts-list-lanterns-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: committed object versus prefix projection versus provider folder resource versus listing snapshot versus published name versus live facet versus receipt/history, drawing especially on current SlopOS capshell / AttrFS / document-import posture plus Amazon S3 prefixes, Google Cloud Storage flat namespace / managed folders, and Azure Blob virtual-directory / hierarchical-namespace docs.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 136 — 2026-03-28
- continued external research on origin-truth honesty, access-change propagation, public-cache visibility, cache-trail inspection, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0123-viewfs-keep-committed-objects-access-propagation-public-cache-copies-cache-trails-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/committed-objects-access-propagation-public-cache-copies-cache-trails-live-facets-and-receipts.md` and `docs/70-shell/truth-badges-propagation-echoes-cache-ghosts-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: committed object versus access-propagation state versus public-cache copy versus cache trail versus live facet versus receipt/history, drawing especially on current SlopOS boundary posture plus Amazon S3 strong consistency, Google Cloud Storage consistency, RFC 9111 HTTP caching, and RFC 9211 Cache-Status.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 135 — 2026-03-28
- continued external research on residency-profile honesty, current placement realms, routed-access endpoints, egress-gate posture, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0122-viewfs-keep-committed-objects-residency-profiles-placement-realms-route-endpoints-egress-gates-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/committed-objects-residency-profiles-placement-realms-route-endpoints-egress-gates-live-facets-and-receipts.md` and `docs/70-shell/realm-badges-route-halos-egress-shutters-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: committed object versus residency profile versus placement realm versus route endpoint versus egress gate versus live facet versus receipt/history, drawing especially on current SlopOS cluster-map / replication-contract posture plus Amazon S3 replication and Multi-Region Access Point routing, Google Cloud Storage dual-region and bucket RPO docs, Azure geo-redundancy/read-secondary docs, and Ceph CRUSH placement rules.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 134 — 2026-03-28
- continued external research on archive-tier honesty, thaw-job posture, temporary readable copies, expiry visibility, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0121-viewfs-keep-committed-objects-archive-tiers-thaw-jobs-thawed-copies-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/committed-objects-archive-tiers-thaw-jobs-thawed-copies-live-facets-and-receipts.md` and `docs/70-shell/frost-badges-thaw-beads-copy-thaw-ladders-expiry-lanterns-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: committed object versus archive tier versus thaw job versus thawed copy versus live facet versus receipt/history, drawing especially on current SlopOS import/materialize/CapStore posture plus Amazon S3 restore semantics and Azure archive rehydration semantics.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 133 — 2026-03-28
- continued external research on durability-profile honesty, redundancy-layout exposure, repair-state visibility, availability-now truth, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0120-viewfs-keep-committed-objects-durability-profiles-redundancy-layouts-repair-verdicts-availability-states-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/committed-objects-durability-profiles-redundancy-layouts-repair-verdicts-availability-states-live-facets-and-receipts.md` and `docs/70-shell/durability-badges-layout-ghosts-repair-ladders-and-availability-lamps.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: committed object versus durability profile versus redundancy layout versus repair verdict versus availability state versus live facet versus receipt/history, drawing especially on current SlopOS artifact/CapStore posture plus Ceph placement+scrubbing, Tahoe-LAFS share-threshold guidance, and Amazon S3 replication / replication-status docs.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 132 — 2026-03-28
- continued external research on sealed-object honesty, recipient-wrap layering, rewrap/key-rotation posture, provider-bound unwrap handles, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0119-viewfs-keep-sealed-objects-recipient-wraps-rewrap-plans-unwrap-handles-clear-facets-and-receipts-separate.md`.
- added `docs/30-architecture/sealed-objects-recipient-wraps-rewrap-plans-unwrap-handles-clear-facets-and-receipts.md` and `docs/70-shell/seal-badges-wrap-rosters-rewrap-ladders-and-clear-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: sealed object versus recipient wrap versus rewrap plan versus unwrap handle versus clear facet versus receipt/history, drawing especially on current SlopOS cryptosvc/vault posture plus RFC 7516 JWE, WebCrypto, and Google Cloud KMS envelope-encryption / re-encryption guidance.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 131 — 2026-03-28
- continued external research on retention clocks, hold-state honesty, purge eligibility, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0118-viewfs-keep-committed-objects-retention-clocks-hold-states-purge-verdicts-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/committed-objects-retention-clocks-hold-states-purge-verdicts-live-facets-and-receipts.md` and `docs/70-shell/hold-badges-retention-rails-purge-lamps-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: committed object versus retention clock versus hold state versus purge verdict versus live facet versus receipt/history, drawing especially on current SlopOS persistence/verified-blob posture plus Amazon S3 Object Lock, Google Cloud Storage object holds and Object Retention Lock, and Azure immutable storage.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 130 — 2026-03-28
- continued external research on transient exact-byte staging capsules, freeze-for-review semantics, local courier handoffs, explicit commit-last flows, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0117-viewfs-keep-transient-staging-capsules-seal-states-courier-handoffs-committed-objects-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/transient-staging-capsules-seal-states-courier-handoffs-committed-objects-live-facets-and-receipts.md` and `docs/70-shell/capsule-cards-seal-shutters-courier-rails-and-commit-lamps.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: transient staging capsule versus seal state versus courier handoff versus committed object versus live facet versus receipt/history, drawing especially on current SlopOS import/materialization/commit posture plus Linux `memfd_create()`, file sealing, UNIX FD passing, `O_TMPFILE`, and current memfd-preservation caveats.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 129 — 2026-03-28
- continued external research on assembly-by-reference honesty, member-descriptor graphs, aggregate-object birth, realized work-surface posture, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0116-viewfs-keep-assembly-recipes-member-descriptors-aggregate-objects-realized-work-surfaces-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/assembly-recipes-member-descriptors-aggregate-objects-realized-work-surfaces-live-facets-and-receipts.md` and `docs/70-shell/recipe-cards-member-rails-aggregate-seals-unpack-lamps-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: assembly recipe versus member descriptor versus aggregate object versus realized work surface versus live facet versus receipt/history, drawing especially on current SlopOS composition/persistence posture plus Google Cloud Storage composite objects, OCI manifests/indexes, `git write-tree`, and containerd pull/unpack.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 128 — 2026-03-28
- continued external research on resumable upload/session honesty, staged part coverage, explicit finalization, abort/expiry truth, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0115-viewfs-keep-upload-sessions-part-coverage-completion-manifests-committed-objects-abort-verdicts-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/upload-sessions-part-coverage-completion-manifests-committed-objects-abort-verdicts-live-facets-and-receipts.md` and `docs/70-shell/session-beads-part-gauges-seal-ladders-abort-ash-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: upload session versus part coverage versus completion manifest versus committed object versus abort verdict versus live facet versus receipt/history, drawing especially on current SlopOS persistence/import/jobs posture plus Amazon S3 multipart upload, tus resumable uploads, OCI chunked blob upload, and Google Cloud Storage resumable sessions.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 127 — 2026-03-28
- continued external research on cheap clones, shared-backing honesty, copy-lineage receipts, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0114-viewfs-keep-fresh-object-identities-shared-backing-copy-lineage-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/fresh-object-identities-shared-backing-copy-lineage-live-facets-and-receipts.md` and `docs/70-shell/birth-badges-backing-ghosts-lineage-ladders-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: fresh object identity versus shared-backing optimization versus copy lineage versus current live facet versus receipt/history, drawing especially on current SlopOS import-to-docref fresh-identity and explicit-lineage posture plus Linux reflink, Btrfs reflink, OpenZFS clone concepts, and APFS clones.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

# Changelog

## Revision 126 — 2026-03-28
- continued external research on semantic record meaning, canonical payload bytes, signed wrapper honesty, wire/storage copies, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0113-viewfs-keep-semantic-records-canonical-payloads-signed-wrappers-wire-copies-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/semantic-records-canonical-payloads-signed-wrappers-wire-copies-live-facets-and-receipts.md` and `docs/70-shell/record-cards-payload-chips-wrapper-seals-wire-ghosts-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: semantic record versus canonical payload versus signed wrapper versus wire/storage copy versus live facet versus receipt/history, drawing especially on current SlopOS wallet/encoding posture plus RFC 8785 JCS, RFC 8949 deterministic CBOR, RFC 9052 COSE detached payload rules, and in-toto envelope/statement layering.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 125 — 2026-03-28
- continued external research on head/version honesty, order scopes, supersession rows, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0112-viewfs-keep-object-cores-designations-revision-tokens-order-scopes-supersession-rows-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/object-cores-designations-revision-tokens-order-scopes-supersession-rows-live-facets-and-receipts.md` and `docs/70-shell/head-badges-order-pips-supersession-ladders-and-facet-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: object core versus designation versus revision token versus order scope versus supersession row versus live facet versus receipt/history, drawing especially on current SlopOS ordering-token/conflict-key posture plus Kubernetes object identity and `resourceVersion`, etcd revision metadata, S3 versioning, and Git reflogs.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 124 — 2026-03-28
- continued external research on exact proofs, weak validators, explicit comparison profiles, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0111-viewfs-keep-strong-proofs-weak-validators-comparison-profiles-live-facets-and-receipts-separate.md`.
- added `docs/30-architecture/strong-proofs-weak-validators-comparison-profiles-live-facets-and-receipts.md` and `docs/70-shell/strong-locks-weak-lamps-compare-profile-drawers-and-facet-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: exact strong proof versus weak validator versus comparison profile versus current live facet versus receipt/history, drawing especially on current SlopOS wallet/artifact/commit posture plus HTTP validator semantics, Amazon S3 ETag/checksum caveats, and Git patch-id stability.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.


## Revision 123 — 2026-03-28
- continued external research on stable review/gate digests, descriptive envelopes, explain-sidecar posture, and design-phase non-decisions for the future custom shell+terminal.
- added `rfcs/0110-viewfs-keep-authority-core-stamps-descriptive-review-envelopes-explain-sidecars-live-binds-and-receipts-separate.md`.
- added `docs/30-architecture/authority-core-stamps-descriptive-review-envelopes-explain-sidecars-live-binds-and-receipts.md` and `docs/70-shell/core-stamps-envelope-drawers-sidecar-lamps-and-live-rails.md`.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new seam: stable authority-core stamp versus descriptive envelope versus explain sidecar versus current live bind versus receipt/history, drawing especially on current SlopOS wallet posture plus Git patch-id, OCI descriptor/annotations, in-toto statements, and SLSA provenance.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/external-source-head-register.md`, `docs/00-meta/external-source-review-queue.md`, and `docs/00-meta/evidence-index.md`.
- regenerated repo hygiene surfaces with `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 122 - 2026-03-28
- continued external research on semantic object cores, exact byte proofs, structured/chunked addresses, designation honesty, and live-facet truth for the future custom shell+terminal.
- added `rfcs/0142-viewfs-keep-semantic-object-cores-byte-proofs-structured-addresses-live-facets-and-receipts-separate.md` to keep semantic object core, exact byte proof, structured address, designation, live facet, and receipts visibly distinct.
- added `docs/30-architecture/semantic-object-cores-byte-proofs-structured-addresses-live-facets-and-receipts.md` and `docs/70-shell/object-core-badges-byteproof-lamps-shapehash-drawers-and-facet-rails.md` to sharpen object-store identity honesty without freezing one universal object-ID or canonicalization scheme.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new lesson from current SlopOS datacube posture: semantic object core versus exact byte proof versus structured address versus designation versus live facet.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` so the repo records the new seam while SlopOS is still in design.
- re-checked moving-head source heads most relevant to this pass and refreshed repo evidence/index hygiene for the new revision.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 121 - 2026-03-28
- continued external research on grant outlooks, issuance-bounded descriptors, restore/reactivation tokens, explicit death-state verdicts, and continuity honesty for the future custom shell+terminal.
- added `rfcs/0109-viewfs-keep-grant-outlooks-issued-bounds-restore-tokens-live-binds-death-verdicts-and-receipts-separate.md` to keep preflight permission outlook, reviewed issued-bounds evidence, restore/reactivation material, current live binds, death verdicts, and receipts visibly distinct.
- added `docs/30-architecture/grant-outlooks-issued-bounds-restore-tokens-live-binds-and-death-verdicts.md` and `docs/70-shell/grant-gauges-restore-beads-death-cards-and-repair-ladders.md` to sharpen continuity/repair/death honesty without freezing one universal status or restore API.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with a new lesson from current SlopOS datacube posture: issuance-bounded descriptors versus restore tokens versus current live binds versus explicit death verdicts.
- refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` so the repo records the new seam while SlopOS is still in design.
- re-checked moving-head source heads most relevant to this pass and refreshed repo evidence/index hygiene for the new revision.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 120 - 2026-03-28
- continued external research on descriptor-only versus verify-only versus read/write/publish handle classes, safe proof surfaces, and design-phase non-decisions for the future custom shell+terminal.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` with a new lesson from current SlopOS datacube posture: descriptor/proof-only rows versus verify-only facets versus current read/edit/publish facets versus live room binds.
- expanded `docs/90-inspirations/inspirations-mapped.md` with sharper must-learn and steal-worthy ideas from Tahoe-LAFS capability flavors, Linux `O_PATH`, and CHERIoT sealing for proof-safe versus live-authority handle design.
- refreshed `docs/30-architecture/object-store-posture-v0.md`, `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/70-shell/shell-terminal-ideas.md` so the repo records the new seam without freezing one universal verification or facet ABI too early.
- re-checked moving-head source heads most relevant to this pass and refreshed repo evidence/index hygiene for the new revision.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 119 - 2026-03-28
- continued external research on capability facets, opaque handle classes, grouped authority kits, room-bound facet binding, and design-phase non-decisions for the future custom shell+terminal.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` with a new lesson from current SlopOS datacube posture: object identity versus capability facet versus grouped kit versus live room bind versus published name.
- expanded `docs/90-inspirations/inspirations-mapped.md` with sharper must-learn and steal-worthy ideas from Sandstorm Powerbox/grains, Fuchsia capabilities+dictionaries, Capsicum rights attenuation, and CHERIoT sealing for explicit facet design.
- refreshed `docs/30-architecture/object-store-posture-v0.md`, `docs/30-architecture/viewfs-namespace-posture-v0.md`, `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` so the repo records the new seam without freezing one universal handle taxonomy too early.
- re-checked moving-head source heads most relevant to this pass and refreshed repo evidence/index hygiene for the new revision.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 118 - 2026-03-28
- continued external research on object-centered rooms, late tool attachment, mediated capability imports, explicit retention roots, and design-phase non-decisions for the future custom shell+terminal.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` with a new lesson from current SlopOS datacube posture: object-home rooms versus attached tools versus imported binds versus published names versus retention roots/history.
- expanded `docs/90-inspirations/inspirations-mapped.md` with sharper must-learn and steal-worthy ideas from Sandstorm grains/powerbox, Fuchsia namespaces, and Nix GC roots for object-home room design.
- refreshed `docs/30-architecture/object-store-posture-v0.md`, `docs/30-architecture/viewfs-namespace-posture-v0.md`, `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` so the repo records the new seam without freezing an app model too early.
- re-checked moving-head source heads most relevant to this pass and refreshed repo evidence/index hygiene for the new revision.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 117 - 2026-03-28
- continued external research on creator-populated namespaces, exact child handle tables, portal-mediated imports, mutable anchors, retention roots, and design-phase non-decisions for the future custom shell+terminal.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` with new lessons from current SlopOS namespace/portal/capstore posture: creator-seeded rooms versus later imports, and immutable object blobs versus mutable anchors versus retention roots versus live authority.
- expanded `docs/90-inspirations/inspirations-mapped.md` with sharper must-learn and steal-worthy ideas from Plan 9 namespaces, Fuchsia namespaces/sandboxing, Capsicum, Linux `openat2(2)`, XDG Documents/FileTransfer, Apple security-scoped access, Nix GC roots, Git `update-ref`, Amazon S3 conditional writes, CapROS persistence cautions, and OSTree deployment/root posture.
- re-checked moving-head source heads most relevant to this pass and refreshed the external-source head register for repo hygiene.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 116 - 2026-03-24
- continued external research on explicit payer selection, requester-pays posture, budget leases, sponsorship-vs-authorization, separate resource ceilings, and shell-visible spend honesty for the future custom shell+terminal.
- added `rfcs/0108-viewfs-keep-action-authority-payer-roots-budget-leases-spend-reservations-charge-verdicts-and-receipts-separate.md` to keep action authority, payer roots, budget leases, spend reservations, charge verdicts, provider effects, and receipts visibly distinct.
- added `docs/30-architecture/action-authority-payer-roots-budget-leases-spend-reservations-charge-verdicts-and-receipts.md` and `docs/70-shell/payer-chips-spend-rails-charge-ghosts-and-burn-ladders.md` to sharpen sponsorship/cost honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from SlopOS budget-payer posture, Amazon S3 Requester Pays, Google Cloud Storage Requester Pays, Kubernetes ResourceQuota vs RBAC, seL4 MCS scheduling-context donation, Genode session resource donation, and cgroup v2 resource control.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 115 - 2026-03-24
- continued external research on caller-bound request contexts, detached continuation roots, deadline propagation, cooperative cancellation, cleanup-after-cancel posture, and shell-visible continue-without-me honesty for the future custom shell+terminal.
- added `rfcs/0107-viewfs-keep-caller-request-contexts-detached-roots-deadline-intents-cancellation-state-provider-operations-and-receipts-separate.md` to keep caller request context, detached roots, deadline/cancellation posture, provider follow-up tickets, and receipts visibly distinct.
- added `docs/30-architecture/caller-request-contexts-detached-roots-deadline-intents-cancellation-state-and-provider-operations.md` and `docs/70-shell/cutoff-lamps-detach-root-cards-and-continue-without-me-ladders.md` to sharpen cancellation/deadline/detach honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from SlopOS request-context posture, Go `context` / `WithoutCancel`, gRPC deadlines, Kotlin cancellation + `NonCancellable`, Temporal disconnected cleanup, and Cap'n Proto RPC cancellation logistics.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 114 - 2026-03-24
- continued external research on retry-safe sameness witnesses, idempotency keys, canonical-request mismatch handling, key expiry/pruning, and shell-visible duplicate-versus-fresh honesty for the future custom shell+terminal.
- added `rfcs/0106-viewfs-keep-live-room-bindings-local-edit-shadows-intent-keys-accepted-pushback-requests-provider-operations-completion-verdicts-adopted-results-and-receipts-separate.md` to keep current binds, local edit shadows, retry-safe sameness witnesses, request admission, provider operation handles, completion verdicts, local adopted results, and receipts visibly distinct.
- added `docs/30-architecture/live-room-bindings-local-edit-shadows-intent-keys-accepted-pushback-requests-provider-operations-and-adopted-results.md` and `docs/70-shell/intent-lamps-retry-braids-sameness-chips-and-not-the-same-request-shutters.md` to sharpen retry/dedupe/adoption honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from SlopOS request-key discipline, the HTTP Idempotency-Key draft, AWS EC2 client tokens, Stripe idempotent requests, and long-running-operation follow-up posture.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 113 - 2026-03-24
- continued external research on accepted-versus-completed mutation posture, HTTP 202 humility, long-running operation handles, async request-reply status endpoints, and shell-visible settlement honesty for the future custom shell+terminal.
- added `rfcs/0105-viewfs-keep-live-room-bindings-local-edit-shadows-accepted-pushback-requests-provider-operations-completion-verdicts-adopted-results-and-receipts-separate.md` to keep current binds, local edit shadows, request admission, provider operation handles, completion verdicts, local adopted results, and receipts visibly distinct.
- added `docs/30-architecture/live-room-bindings-local-edit-shadows-accepted-pushback-requests-provider-operations-completion-verdicts-and-adopted-results.md` and `docs/70-shell/accept-slips-operation-beads-settle-rails-and-expiry-lanterns.md` to sharpen acceptance/completion/adoption honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from SlopOS acceptance/completion posture, HTTP 202, XDG request handles, Google-style long-running operations, and Azure asynchronous request-reply patterns.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## What Revision 112 adds
- continued external research on exact pushback bases, conditional writes, lease-vs-commit posture, provider verdicts, and shell-visible conflict/adoption honesty for the future custom shell+terminal.
- added `rfcs/0104-viewfs-keep-live-room-bindings-local-edit-shadows-pushback-bases-provider-verdicts-adopted-results-and-receipts-separate.md` to keep current binds, local editable shadows, exact pushback basis/preconditions, provider-side verdicts, local adopted results, and receipts visibly distinct.
- added `docs/30-architecture/live-room-bindings-local-edit-shadows-pushback-bases-provider-verdicts-and-adopted-results.md` and `docs/70-shell/basis-lamps-verdict-cards-adopt-rails-and-lease-ladders.md` to sharpen pushback/conflict/adoption honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from SlopOS precondition witnesses and commit schemas, HTTP conditional requests, S3 and Cloud Storage preconditions, Git force-with-lease/update-ref posture, WebDAV locking, etcd conditional transactions, and writable-session staging.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## What Revision 111 adds
- continued external research on ordered union directories, writable lower/upper merge posture, placeholder/materialize/evict ladders, explicit realization, and shell-visible edit-shadow honesty for the future custom shell+terminal.
- added `rfcs/0103-viewfs-keep-live-room-bindings-projected-bases-local-upper-overlays-merged-room-presentations-publish-results-and-receipts-separate.md` to keep current binds, projected bases, writable uppers, merged views, publish/commit results, and receipts visibly distinct.
- added `docs/30-architecture/live-room-bindings-projected-bases-local-upper-overlays-and-merged-room-presentations.md` and `docs/70-shell/stack-badges-whiteout-ghosts-and-commit-ladders.md` to sharpen overlay/merge/edit-shadow honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from OverlayFS, Plan 9 union directories, Kubernetes projected volumes, Apple File Provider placeholder/materialize/evict posture, and Nix realisation.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## What Revision 110 adds
- continued external research on projected document views, provider-backed hierarchies, namespace publication, placeholder/hydration posture, and shell-visible locality honesty for the future custom shell+terminal.
- added `rfcs/0102-viewfs-keep-live-room-bindings-provider-backed-projection-sites-published-room-aliases-localizations-and-receipts-separate.md` to keep current binds, scoped projection sites, room-local publication, local realization, and receipts visibly distinct.
- added `docs/30-architecture/live-room-bindings-provider-projection-sites-published-room-aliases-and-localizations.md` and `docs/70-shell/site-ledgers-provider-halos-and-bind-here-ladders.md` to sharpen projection/publication/locality honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from XDG Documents, Android SAF and FileProvider, Fuchsia namespaces/directory capabilities, and Windows Cloud Files placeholder/hydration posture.
- refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## What Revision 109 adds
- continued external research on clipboard/selection offers, XDG transfer sessions, clipboard-manager retention, typed clipboard APIs, and paste-origin signaling for the future custom shell+terminal.
- added `rfcs/0101-viewfs-keep-live-room-bindings-selection-owners-transfer-offers-manager-retentions-paste-capsules-materialized-imports-and-receipts-separate.md` to keep current offer source, manager-retained ghosts, prompt-local paste, and later local materialization visibly distinct.
- added `docs/30-architecture/live-room-bindings-selection-owners-transfer-offers-manager-retentions-paste-capsules-and-materialized-imports.md` and `docs/70-shell/offer-cards-paste-capsules-and-history-ghosts.md` to sharpen transfer/history/paste honesty for the future shell.
- expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from Wayland selection/data-control, XDG FileTransfer, the Clipboard API, xterm bracketed paste, and kitty clipboard posture.
- refreshed the architecture overview, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 108 (2026-03-24)
- Continued external research on accessibility/automation leases, observe-versus-inject separation, portal-mediated screen/input control, secure-entry redaction, and shell-visible automation honesty.
- Added `rfcs/0100-viewfs-keep-live-room-bindings-observe-mirrors-automation-leases-synthetic-input-lanes-secure-entry-exclusions-and-receipts-separate.md` to keep live room binds, observe mirrors, automation sessions, current injection lanes, secure-entry clamps, and receipts distinct.
- Added `docs/30-architecture/live-room-bindings-observe-mirrors-automation-leases-synthetic-input-lanes-and-secure-entry-exclusions.md` and `docs/70-shell/mirror-strips-rehearsal-rails-and-secure-entry-curtains.md` to sharpen assistive/automation honesty for the future shell.
- Expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from XDG InputCapture/RemoteDesktop, Android MediaProjection and `FLAG_SECURE`, Fuchsia accessibility/focus-chain posture, and Windows UIAccess / secure-desktop boundaries.
- Refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- Regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revised107 (2026-03-24)
- Continued external research on activation/focus delegation, trusted-entry posture, host-owned display choreography, and focus-aware shell/terminal UX.
- Added `rfcs/0099-viewfs-keep-live-room-bindings-summon-beacons-activation-batons-foreground-turns-secure-entry-gates-and-receipts-separate.md` to keep summon cues, activation batons, actual foreground turns, secure-entry posture, and receipts distinct.
- Added `docs/30-architecture/live-room-bindings-summon-beacons-activation-batons-foreground-turns-and-secure-entry.md` and `docs/70-shell/summon-beacons-front-latches-and-secure-entry-shutters.md` to sharpen summon/focus/trusted-entry honesty for the future shell.
- Expanded `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with new lessons from Wayland xdg-activation, Windows foreground delegation, xterm focus events, and modern shell-integration quality signals.
- Refreshed the architecture overview, design-splits note, SlopOS seam map, shell super-awesome moves, shell-terminal protocol sketch, bibliography, source-head register, evidence index, and repo lint coverage.
- Regenerated repo hygiene surfaces via `make lint`, `make context-pack`, and `make release-manifest` before packaging.

## Revision 106 (2026-03-24)
- Continued online research on SlopOS attention/background seams, XDG Notification request/presentation discipline, Android interruption grades, Apple critical alerts, and terminal attention chrome precedents.
- Added `docs/30-architecture/live-room-bindings-attention-cues-interrupt-grades-quiet-windows-and-ack-ledgers.md` to keep live room binds, attention cues, interrupt grades, quiet windows, durable ack rows, and receipts visibly distinct.
- Added `docs/70-shell/attention-pips-quiet-shutters-and-ack-ledgers.md` to collect shell ideas around activity/bell/silence pips, interrupt ladders, quiet shutters, and durable follow-up ledgers.
- Added `rfcs/0098-viewfs-keep-live-room-bindings-attention-cues-interrupt-grades-quiet-windows-ack-ledgers-and-receipts-separate.md` so future proposals must classify whether they are about current authority, transient attention, interruption strength, suppression posture, durable follow-up, or only historical explanation.
- Updated architecture overview, design-splits/non-decisions, SlopOS seam map/evaluation, inspiration mapping, shell protocol/moves, bibliography/source-tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.
## Revised105 (2026-03-24)
- Continued online research on background-presence grants, autostart/restore posture, deferred repair/job lanes, lifecycle-status chrome, and shell-integration quality precedents.
- Added `docs/30-architecture/live-room-bindings-visibility-states-keep-warm-leases-restore-intents-and-deferred-repair-jobs.md` to keep live room binds, visibility state, keep-warm leases, restore intents, deferred repair jobs, and receipts visibly distinct.
- Added `docs/70-shell/warmth-rails-login-lanterns-and-defer-drawers.md` to collect shell ideas around warmth rails, keep-warm badges, login lanterns, defer drawers, and quality chips.
- Added `rfcs/0097-viewfs-keep-live-room-bindings-visibility-states-keep-warm-leases-restore-intents-deferred-repair-jobs-and-receipts-separate.md` so future proposals must classify whether they are about live authority, visibility, background presence, later restore, deferred repair, or only history.
- Updated architecture overview, design-splits/non-decisions, SlopOS seam map/evaluation, inspiration mapping, bibliography/source-tracking, shell protocol/moves, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revision 104 - 2026-03-24
- Continued online research on SlopOS document/import/session seams, systemd renewal/watchdog and fdstore continuity, retry-timing hints, and shell/terminal state classes for honest auto-help.
- Added `docs/30-architecture/live-room-bindings-currentness-witnesses-renewal-windows-retry-advice-and-repair-gates.md` to keep live room binds, currentness/revocation truth, renewal windows, retry advice, repair gates, and receipts on distinct seams.
- Added `docs/70-shell/renewal-lamps-retry-clocks-and-repair-gates.md` to collect shell ideas around renewal lamps, retry clocks, cooldown shutters, and repair-gate cards.
- Added `rfcs/0096-viewfs-keep-live-room-bindings-currentness-witnesses-renewal-windows-retry-advice-repair-gates-and-receipts-separate.md` so future proposals must classify whether they are changing live authority, currentness proof, renewal timing, retry timing, quieting/repair posture, or only historical explanation.
- Refreshed architecture overview, design-splits, SlopOS seam map/evaluation, inspiration map, shell super-awesome moves, shell terminal protocol sketch, bibliography/source tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised103 (2026-03-24)
- Continued online research on SlopOS document/import/session seams, provider-side expiry/revocation hints, semantic-epoch shell truth, and modern terminal shell-integration chrome.
- Added `docs/30-architecture/live-room-bindings-currentness-witnesses-semantic-epochs-and-repair-offers.md` to keep live room binds, provider currentness/revocation truth, shell semantic epochs, repair offers, and receipts on distinct seams.
- Added `docs/70-shell/epoch-lamps-hop-badges-and-repair-offer-cards.md` to collect shell ideas around semantic epoch lamps, hop badges, currentness drawers, and bounded repair offers.
- Added `rfcs/0095-viewfs-keep-live-room-bindings-currentness-witnesses-semantic-epochs-repair-offers-and-receipts-separate.md` so future proposals must classify whether they are changing live authority, currentness proof, shell footing, repair UX, or historical explanation.
- Refreshed architecture overview, design-splits, SlopOS seam map/evaluation, inspiration map, shell super-awesome moves, bibliography/source tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revision 102 - 2026-03-24
- added `rfcs/0094-viewfs-keep-activation-kits-restart-lockers-namespace-pins-live-room-bindings-and-receipts-separate.md`, `docs/30-architecture/activation-kits-restart-lockers-namespace-pins-and-live-room-bindings.md`, and `docs/70-shell/restart-shelves-wake-kits-pin-badges-and-cold-start-honesty.md`
- extended the ViewFS/SlopOS evaluation with a new reversible seam: startup-delivered activation kits versus manager-held restart lockers versus namespace pins versus current live room bindings versus receipts/history
- folded in stronger lessons from systemd socket activation + fdstore, Linux `setns(2)` + `namespaces(7)` namespace-pin semantics, Apple launchd socket activation, and sibling pressure from Schell anchor-death/reset-scope humility, Ward revalidation fences, and Steward adaptation witnesses
- maintained repo hygiene by wiring the new docs into lint coverage, regenerating the context pack, and restamping the release manifest for the new archive

# Changelog

## Revision 122 - 2026-03-28
- added `docs/30-architecture/semantic-object-cores-byte-proofs-structured-addresses-live-facets-and-receipts.md`, `docs/70-shell/object-core-badges-byteproof-lamps-shapehash-drawers-and-facet-rails.md`, and `rfcs/0142-viewfs-keep-semantic-object-cores-byte-proofs-structured-addresses-live-facets-and-receipts-separate.md`
- extended the ViewFS/SlopOS evaluation with a new reversible seam: semantic object core versus exact byte proof versus structured/chunked/store address versus designation versus current live facet versus receipt/history
- folded in stronger lessons from OCI descriptors, IPFS CIDs, RFC 6920 `ni:` names, and Nix content-addressed store objects so the object-store can stay ambitious without overfreezing one universal ID scheme
- refreshed the architecture overview, design splits, SlopOS seam map, inspiration map, shell notes, bibliography/source tracking, evidence index, context pack, lint coverage, and release manifest for the new revision

## Revision 101 - 2026-03-24
- added `rfcs/0093-viewfs-keep-durable-import-anchors-live-room-bindings-stale-shadows-repair-plans-and-receipts-separate.md`, `docs/30-architecture/durable-import-anchors-live-room-bindings-stale-shadows-and-repair-plans.md`, and `docs/70-shell/stale-shadows-repair-ladders-and-rebind-receipts.md`
- extended the ViewFS/SlopOS evaluation with a new reversible seam: durable import anchors versus live room binds versus stale shadows versus repair plans versus rebind receipts
- folded in stronger lessons from XDG documents/request/transfer, Apple security-scoped bookmark resolve/start-accessing/stale flow, Android SAF persistence, Windows durable-access lists, Web File System Access permission ladders, and Capsicum/pidfd current-handle truth
- maintained repo hygiene by wiring the new docs into lint coverage, regenerating the context pack, and restamping the release manifest for the new archive

## Revision 100 - 2026-03-24
- added `rfcs/0092-viewfs-keep-namespace-plans-live-room-bindings-portal-import-sessions-local-overlays-and-receipts-separate.md`, `docs/30-architecture/namespace-plans-live-room-bindings-import-sessions-and-local-overlays.md`, and `docs/70-shell/switchboards-overlay-racks-and-anchor-death-cards.md`
- extended the ViewFS/SlopOS evaluation with a new reversible seam: namespace plans versus live room bindings versus portal import session state versus local-only overlays versus anchor/reset receipts
- folded in sibling pressure from Helm local overlays and Schell anchor-death/reset-scope humility so the custom shell can be luxurious without lying about what is live, what is local-only, and what died
- repaired context-pack hygiene so the generated pack follows the living repo instead of depending on a manually aging file list

# Changelog

## Revision 099 - room identities, current views, inheritance posture, and spawn recipes
- Continued online research on explicit per-process namespaces, grouped capability bundles, portal request/document/transfer splits, terminal semantic zones, shell overlays, command-palette room UX, descriptor-inheritance hazards, and capability-adoption diagnostics.
- Added `rfcs/0091-viewfs-keep-room-identities-current-views-context-inheritance-child-spawn-recipes-imported-bindings-and-receipts-separate.md` so room identity, current room-local view, inheritance posture, prepared child spawn/import recipe, child-received bindings/imports, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/room-identities-current-views-context-inheritance-and-child-spawns.md` and `docs/70-shell/room-badges-context-diffs-and-spawn-recipes.md` so ViewFS can sharpen custom-shell room honesty without prematurely freezing one clone/inheritance model, one spawn-recipe schema, or one final import contract.
- Refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` with the new room-versus-view-versus-inheritance seam and a sharper evaluation of what current SlopOS view/capshell/wallet/plumb posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` with room badges, context-diff drawers, spawn-recipe cards, child-import trays, and receipt-first room-restore ideas.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with stronger lessons from Fuchsia namespaces and dictionary capabilities, XDG Request/Documents/FileTransfer, WezTerm shell integration, fish, Nushell overlays, Ghostty room/palette affordances, Linux `O_CLOEXEC`, and Capsicum adoption diagnostics.

## Revised098 (2026-03-24)
- Continued online research on incremental parsing, syntax-highlighting honesty, advisory shell diagnostics, and the distinction between parsed structure, compiled packets, and prepared actions.
- Added `rfcs/0090-viewfs-keep-editable-buffers-parsed-structures-advisory-diagnostics-compiled-command-packets-prepared-actions-and-receipts-separate.md` so buffer text, parser/highlight structure, diagnostics, compiled packets, prepared actions, and durable receipts stay on distinct seams.
- Added `docs/30-architecture/editable-buffers-parsed-structures-advisory-diagnostics-and-compiled-packets.md` and `docs/70-shell/parse-lenses-diagnostic-rails-and-packet-gutters.md` to capture the new shell-editing seam and collect shell ideas around parse lenses, recovery veils, diagnostic rails, packet gutters, and compile-diff cards.
- Refreshed the architecture overview, design splits, SlopOS seam map, inspiration docs, SlopOS evaluation, shell super-awesome moves, shell terminal ideas, and shell terminal protocol sketch with the new research.
- Expanded bibliography, moving-head source tracking, review queue, evidence index, context-pack coverage, and lint requirements; regenerated `out/context_pack.md` and restamped the release manifest for the new archive.

## Revised097 (2026-03-24)
- Continued external research on typed abbreviation/alias expansion, overlay/module activation, command-palette and key-table interaction layers, and honest command-surface resolution for a future custom ViewFS shell.
- Added `docs/30-architecture/command-surface-layers-key-actions-and-external-launches.md` so built-in verbs, lexical expansions, semantic command layers, key actions/widgets, external launches, and durable receipts stay class-aware.
- Added `docs/70-shell/verb-provenance-cards-overlay-racks-and-keytable-lamps.md` to collect shell ideas around verb provenance cards, abbr gutters, overlay racks, key-table lamps, and which ladders.
- Added `rfcs/0089-viewfs-keep-built-in-verbs-lexical-expansions-semantic-command-layers-key-actions-external-launches-and-receipts-separate.md` to freeze the new command-surface seam while leaving alias models, overlay formats, and palette protocols intentionally undecided.
- Refreshed the architecture overview, design splits, SlopOS seam map, inspiration map, SlopOS evaluation, shell super-awesome moves, and shell-terminal protocol sketch with the new research.
- Expanded bibliography, moving-head source tracking, review queue, evidence index, context-pack coverage, and lint requirements; regenerated `out/context_pack.md` and restamped the release manifest for the new archive.

## Revised096 (2026-03-23)
- Continued online research on shell startup honesty, explicit customization bundles, ambient startup/profile scripts, project-local activation hooks, and terminal integration provenance.
- Added `rfcs/0088-viewfs-keep-built-in-shell-affordances-explicit-customization-bundles-startup-files-project-hooks-and-receipts-separate.md` to keep custom-shell delight separate from ambient startup lore.
- Added `docs/30-architecture/built-in-shell-affordances-customization-bundles-startup-files-and-project-hooks.md` and `docs/70-shell/clean-start-lamps-bundle-ledgers-and-hook-quarantine.md` to capture the new shell/startup seam and collect shell/terminal product ideas around clean-start lamps, bundle ledgers, prompt provenance, and hook quarantine.
- Refreshed architecture overview, design splits, SlopOS seam map, inspiration docs, shell notes, bibliography/review tracking, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revision 0095 — 2026-03-23
- add `rfcs/0087-viewfs-keep-native-attaches-adapted-attaches-coerced-representations-local-realizations-and-receipts-separate.md`, freezing the rule that native attaches, adapted attaches, coerced representations, local realizations, and receipts/history remain separate truths instead of collapsing into one flattering `opened natively` story
- add `docs/30-architecture/native-attaches-adapted-attaches-coerced-representations-and-local-realizations.md`, sharpening the architecture split between direct receiver-native fit, wrapper/relay-backed usability, alternate typed representations, explicit make-local transitions, and durable aftermath while SlopOS is still deciding deeper object-store and portal machinery
- add `docs/70-shell/attach-mode-badges-adapter-veils-and-virtuality-lamps.md`, capturing shell/terminal moves like attach-mode badges, adapter veils, virtuality lamps, same-object-versus-translated drawers, and make-local-for-native ladders for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new native/adapted/coerced/localized seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for Android SAF virtual files and WIT resource handles; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revision 0094 — 2026-03-23
- add `rfcs/0086-viewfs-keep-privilege-brackets-borrowed-authority-call-chain-contexts-deny-only-hints-and-receipts-separate.md`, freezing the rule that privilege brackets, borrowed authority, call-chain context, deny-only routing hints, and receipts/history remain separate truths instead of collapsing into one flattering `helper did it` story
- add `docs/30-architecture/privilege-brackets-borrowed-authority-call-chain-contexts-and-deny-only-hints.md`, sharpening the architecture split between bounded helper execution, real borrowed handles, non-authoritative caller provenance, deny-only veto posture, and durable aftermath while SlopOS is still deciding deeper helper/runtime carriers
- add `docs/70-shell/bracket-rails-caller-badges-and-who-asked-drawers.md`, capturing shell/terminal moves like bracket rails, caller badges, who-asked drawers, deputy-fog warnings, deny-only shutters, and borrowed-authority drawers for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new bracket/borrowed-authority/call-context seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for Hardy’s confused deputy paper, Java Scoped Values, Python `contextvars`, Node `AsyncLocalStorage`, and ASP.NET’s ambient-state caution; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revised093 (2026-03-23)
- Continued online research on Plan 9 plumbing, Android Intent URI-grant behavior, XDG request lifetimes, Wayland representation offers, and shell-side route/authority honesty.
- Added `docs/30-architecture/route-envelopes-authority-sidecars-sink-bindings-and-receipts.md` to keep typed route capsules, optional authority sidecars, sink-side acceptance/bind/import, and durable receipts on distinct seams.
- Added `docs/70-shell/route-slips-authority-sidecars-and-sink-trays.md` to collect ideas around route slips, designation-only pills, sidecar chips, sink trays, and dry-run route diffs.
- Added `rfcs/0085-viewfs-keep-route-envelopes-authority-sidecars-sink-bindings-and-receipts-separate.md` so future proposals must classify whether they change routing, sidecars, sink consequence, or only history.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography/review tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised092 (2026-03-23)
- Continued online research on receiver-side import/adoption truth, foreign-backed provider usability, projected local views, explicit localization, and shell/terminal semantics that can tell `borrowed here`, `projected here`, and `local here` apart.
- Added `rfcs/0084-viewfs-keep-foreign-backed-borrows-compat-attaches-projected-imports-local-realizations-and-receipts-separate.md` so foreign-backed borrows, compat attaches, projected imports, local realizations, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/foreign-backed-borrows-compat-attaches-projected-imports-and-local-realizations.md` and `docs/70-shell/borrow-rails-projection-badges-and-make-here-ladders.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with borrow rails, projection badges, make-here ladders, provider-owned halos, and dataless/materialized lamps.
- Expanded bibliography/source tracking/review queue with Apple File Provider materialization and Fuchsia explicit namespace-entry precedents.
- Updated context-pack/lint coverage so RFC 0084 and the new architecture/shell docs ride along automatically.

## Revised091 (2026-03-23)
- Continued online research on local duplication, live-handle lending, representation-export fallbacks, portal/file-transfer mediation, and shell/terminal semantics that can tell `held here`, `lendable here`, `bytes only`, and `history only` apart.
- Added `rfcs/0083-viewfs-keep-current-possession-local-duplication-live-lends-representation-exports-and-receipts-separate.md` so current possession, local duplication, live lends, representation exports, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/current-possession-local-duplication-live-lends-and-representation-exports.md` and `docs/70-shell/lend-ladders-lane-fit-badges-and-bytes-only-fallbacks.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with lend ladders, lane-fit badges, bytes-only fallbacks, share sheets, and same-object-versus-new-representation drawers.
- Expanded bibliography/source tracking/review queue with Mach port rights, seL4 Grant/GrantReply transfer rules, and kitty TTY file-transfer precedents.
- Updated context-pack/lint coverage so RFC 0083 and the new architecture/shell docs ride along automatically.

## Revision 0090 — 2026-03-23
- add `rfcs/0082-viewfs-keep-live-possession-status-carriers-local-holds-successor-refresh-and-receipts-separate.md`, freezing the rule that live possession, watch/status carriers, local hold/quarantine posture, successor/refresh posture, post-watch invocability, and receipts/history remain separate truths instead of collapsing into one vague `still valid` story
- add `docs/30-architecture/live-possession-status-carriers-local-holds-and-successor-refresh.md`, sharpening the architecture split between what is still held here, what later status material says, how the local receiver reacts, what hold or quarantine is active, what successor/refresh is owed, and what is invokable now after watch processing
- add `docs/70-shell/watch-braids-hold-rails-and-successor-lanterns.md`, capturing shell/terminal moves like watch braids, hold rails, successor lanterns, stale-watch fog, and quarantine shutters for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new live-possession / watch-status / hold / successor seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for RFC 7662 token introspection, RFC 7009 token revocation, W3C Bitstring Status List v1.0, RFC 6960 OCSP, RFC 5280 `certificateHold` / `removeFromCRL`, and TUF freshness / root rotation; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revision 0089 — 2026-03-23
- add `rfcs/0081-viewfs-keep-current-possession-freshness-step-up-current-invocability-and-receipts-separate.md`, freezing the rule that current possession, freshness/recency posture, step-up posture, local presence/user-verification posture, current invocability, and receipts/history remain separate truths instead of collapsing into one vague `authorized now` story
- add `docs/30-architecture/current-possession-freshness-step-up-and-current-invocability.md`, sharpening the architecture split between what is held here, what is fresh enough, what still needs stronger auth or local presence, what is invokable now, and what is merely historical trace while SlopOS is still deciding deeper auth-mediation and capability-store mechanics
- add `docs/70-shell/step-up-ladders-recency-shutters-and-why-not-now-drawers.md`, capturing shell/terminal moves like step-up ladders, recency shutters, presence pins, satisfaction ghosts, and why-not-now drawers for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new possession/freshness/invocability seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for RFC 9470 step-up auth, OIDC `max_age` / `auth_time`, WebAuthn presence/verification, and Android Keystore authentication gating; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revision 0088 — 2026-03-23
- add `rfcs/0080-viewfs-keep-claim-tickets-holder-bound-grants-passable-live-handles-spent-tickets-and-receipts-separate.md`, freezing the rule that redeemable claim tickets, holder-bound grants, passable live handles, spent/expired tickets, and receipts/history remain separate truths instead of collapsing into one vague `token` or `handle`
- add `docs/30-architecture/claim-tickets-holder-bound-grants-and-spent-receipts.md`, sharpening the architecture split between redeemable authority, holder-proof-gated authority, freely passable live handles, and anti-replay historical traces while SlopOS is still deciding deeper object-store and portal machinery
- add `docs/70-shell/redemption-ladders-holder-proof-badges-and-spent-ghosts.md`, capturing shell/terminal moves like redemption ladders, holder-proof badges, burn-after-use chips, proof drawers, and spent ghosts for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new claim/holder-bound/passable/spent seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for OAuth authorization codes, DPoP, and Android PendingIntent replay guidance; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revised087 (2026-03-23)
- Continued online research on provider-ready versus locally realized truth, promisor/substituter models, restore/reacquire obligations, and shell/terminal semantics that can tell `can be supplied later` apart from `exists here now`.
- Added `rfcs/0079-viewfs-keep-provider-ready-claims-reacquire-obligations-local-realizations-live-handles-and-receipts-separate.md` so provider-ready claims, reacquire/repair duties, local realizations, live handles, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/provider-ready-claims-reacquire-obligations-local-realizations-and-live-handles.md` and `docs/70-shell/make-local-ladders-provider-owned-badges-and-repair-rails.md`, and refreshed architecture/shell notes with make-local ladders, provider-owned badges, repair rails, offline fog, and locality lamps.
- Refreshed `docs/90-inspirations/slopos-datacube-evaluation.md`, `docs/90-inspirations/inspirations-mapped.md`, bibliography, external-source head/review registers, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.
## Revised086 (2026-03-23)
- Continued online research on published/discoverable presence, freshness-scoped readiness, mediated grant-needed posture, and semantic shell/terminal metadata while keeping SlopOS design-phase uncertainty front and center.
- Added `rfcs/0078-viewfs-keep-presence-adverts-readiness-current-authority-and-receipts-separate.md` so provider/catalog presence, readiness/serving truth, grant-needed posture, current authority, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/presence-adverts-readiness-current-authority-and-receipts.md` and `docs/70-shell/presence-halos-readiness-lamps-and-withdrawn-ghosts.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with presence halos, readiness lamps, withdrawn ghosts, grant-needed ladders, and advert ledgers.
- Expanded bibliography/source tracking/review queue with Fuchsia outgoing-capability, MCP roots, DNS-SD, and Kubernetes EndpointSlice precedents.
- Updated context-pack/lint coverage so RFC 0078 and the new architecture/shell docs ride along automatically.

## Revised085 (2026-03-23)
- Continued online research on search permission, browse/list disclosure, exact-name opens under held roots, match-quality mediation, and semantic shell/terminal metadata while keeping SlopOS design-phase uncertainty front and center.
- Added `rfcs/0077-viewfs-keep-discoverability-enumeration-exact-opens-fit-notes-and-receipts-separate.md` so direct authority, exact-name reachability, enumeration/listability, advisory fit notes/suggestions, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/discoverability-enumeration-exact-name-reachability-and-fit-notes.md` and `docs/70-shell/dark-directories-known-name-chips-and-browse-gates.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with dark directories, known-name chips, browse gates, fit sheets, and search-result dimmers.
- Expanded bibliography/source tracking/review queue with Linux `access(2)` and WASI rights precedents.
- Updated context-pack/lint coverage so RFC 0077 and the new architecture/shell docs ride along automatically.

## Revised084 (2026-03-23)
- Continued online research on explicit handle authority, rooted compat walkers, portal/powerbox mediation, content-addressed archival stores, imported namespace fragments, and semantic terminal metadata while keeping SlopOS design-phase uncertainty front and center.
- Added `rfcs/0076-viewfs-keep-explicit-handle-opens-rooted-compat-pathwalks-ambient-escapes-and-receipts-separate.md` so direct-handle opens, rooted compat walks, portal-mediated grants/projections, ambient host escapes, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/explicit-handle-opens-rooted-compat-pathwalks-and-ambient-escapes.md` and `docs/70-shell/ambient-debt-sirens-safe-open-ladders-and-escape-hatch-receipts.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with safe-open ladders, ambient-debt sirens, route provenance drawers, and replace-this-debt affordances.
- Expanded bibliography/source tracking/review queue with Sandstorm powerbox, Foundation CAS, and Plan 9 import precedents.
- Updated context-pack/lint coverage so RFC 0076 and the new architecture/shell docs ride along automatically.

## Revised083 (2026-03-23)
- Continued online research on Plan 9 per-process namespaces, Fuchsia namespace publication and dictionary capabilities, XDG request/file/document portal restricted views, and shell/terminal semantics that can tell `in store`, `projected`, `live now`, `published here`, and `history only` apart.
- Added `rfcs/0075-viewfs-keep-store-membership-synthetic-views-live-handles-published-names-and-receipts-separate.md` so store membership, synthetic/mediated view projection, live authority, current publication, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/store-membership-synthetic-views-live-handles-and-published-names.md` and `docs/70-shell/published-name-ledgers-and-synthetic-view-badges.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with published-name ledgers, synthetic-view badges, publish-here ladders, and projection/locality truth.
- Refreshed the source-head register/review queue and cleaned the stale nested prior-archive folder out of the repo before packaging the new archive.
- Updated context-pack/lint coverage so RFC 0075 and the new architecture/shell docs ride along automatically.

## Revised082 (2026-03-23)
- Continued online research on per-process namespaces, startup-delivered handles, narrow continuity lockers, explicit local handle courier lanes, badged handle copies, and semantic terminal protocols while keeping SlopOS design-phase uncertainty front and center.
- Added `docs/30-architecture/activation-carriers-badged-handle-copies-and-object-identity.md` to pin the low-regret seam between activation carriers, live handle copies, issuer badges/witnesses, immutable object refs, local binds, later revival designators, and receipts/history.
- Added `docs/70-shell/activation-slots-issuer-badges-and-handoff-sheets.md` and refreshed shell notes/protocol sketches with activation-sheet cards, child-slot maps, copy-lineage drawers, handoff sheets, issuer chips, paste/import capsules, and truth-grade command blocks.
- Refreshed the architecture overview, design-splits, SlopOS seam map, inspiration map, SlopOS datacube evaluation, README hygiene, source-head tracking, and evidence index for the new startup/handoff seam.
- Updated context-pack/lint coverage so the new architecture/shell docs ride along automatically.

## Revised081 (2026-03-23)
- Continued external research on exact-basis delta application, reconstruction, and honest fallback lanes for ViewFS while keeping SlopOS datacube alignment explicit.
- Added `rfcs/0074-viewfs-keep-delta-recipes-exact-bases-apply-sessions-reconstructed-objects-and-receipts-separate.md`.
- Added architecture and shell notes for delta recipes, basis cards, apply ladders, and rebuilt-from lineage.
- Refreshed the SlopOS seam map, datacube evaluation, inspiration map, bibliography, external-source review tracking, and evidence index.
- Updated context-pack/lint coverage so the new RFC and docs ride along automatically.

## Revised080 (2026-03-23)
- Continued online research on sparse/local byte coverage, range requests, lazy pulling, multipart checksum caveats, and chunked-object layouts.
- Added `rfcs/0073-viewfs-keep-partial-residency-chunk-layouts-whole-object-proofs-live-range-sessions-and-receipts-separate.md` to keep partial residency, layout metadata, whole-object proofs, live range sessions, and receipts intentionally decoupled.
- Added `docs/30-architecture/partial-residency-chunk-layouts-and-whole-object-proofs.md` to capture the design posture around sparse objects, completeness truth, proof strength, and remote-fill reachability without prematurely standardizing one sparse-store schema.
- Added `docs/70-shell/hole-maps-range-panels-and-whole-proof-ladders.md` so the custom shell+terminal ambition is grounded in honest sparse/full/proof semantics rather than one fake download state.
- Refreshed architecture overview, design-splits, SlopOS seam map, inspiration mapping, SlopOS datacube evaluation, bibliography/source tracking, evidence index, context-pack coverage, and release manifest for the new research pass.

## Revised079 (2026-03-23)
- Continued online research on version validators, guarded writes, compare-and-swap mutation, writable staging sessions, coordination holds, and shell/terminal UX that can tell `observed base`, `draft`, `hold`, `commit gate`, and `winning durable version` apart.
- Added `rfcs/0072-viewfs-keep-observed-validators-writable-sessions-write-holds-commit-preconditions-committed-versions-and-receipts-separate.md` so observed validators/bases, private writable sessions, live write holds, exact commit preconditions, winning committed versions, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/observed-validators-writable-sessions-and-commit-cuts.md` and `docs/70-shell/draft-gutters-commit-shutters-and-stale-base-lamps.md`, then refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/inspirations-mapped.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new validator/draft/commit seam and shell payoffs.
- Expanded bibliography/source tracking/review queue/evidence index with HTTP conditional request, Cloud Storage precondition, and File System Access writable-session precedents.
- Fixed repo hygiene so context-pack and lint coverage now carry RFC 0072 and the new architecture/shell docs before packaging the new archive.

## Revised078 (2026-03-23)
- Continued online research on watch bookmarks, continuation cursors, sync watermarks, longpoll/watch resume semantics, explicit rescan/relist flows, and shell/terminal UX that can tell `cursor`, `caught up through`, `following now`, `rebuilt set`, and `gap verdict` apart.
- Added `rfcs/0071-viewfs-keep-continuation-cursors-sync-watermarks-live-subscriptions-rebuilt-snapshots-gap-verdicts-and-receipts-separate.md` so provider continuation tokens, sync watermarks, live follow state, rebuilt snapshots, gap/reset verdicts, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/continuation-cursors-watermarks-and-live-subscriptions.md` and `docs/70-shell/waterline-cards-gap-badges-and-resync-ladders.md`, then refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/inspirations-mapped.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new cursor/watermark/subscription/rebuild seam and shell payoffs.
- Expanded bibliography/source tracking/review queue/evidence index with Kubernetes watch/bookmark, Dropbox change cursor, Watchman clockspec, and Apple FSEvents rescan precedents.
- Fixed repo hygiene so context-pack and lint coverage now carry RFC 0071 before packaging the new archive.

## Revised077 (2026-03-23)
- Continued online research on label taxonomies, selector-safe grouping keys, policy-bearing labels, trusted chrome badges, and shell/terminal semantics that can tell `annotation`, `selector`, `policy`, `trusted badge`, and `history` apart.
- Added `rfcs/0070-viewfs-keep-advisory-annotations-selector-labels-policy-labels-trusted-badges-and-receipts-separate.md` so freeform annotations, selector labels, policy-bearing labels, trusted chrome badges, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/annotations-selector-labels-policy-labels-and-trusted-badges.md` and `docs/70-shell/label-chips-selector-rails-and-trusted-badges.md`, then refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/90-inspirations/inspirations-mapped.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new label/selector/policy/chrome seam and shell payoffs.
- Expanded bibliography/source tracking/review queue/evidence index with Kubernetes, OCI annotations, SELinux, TLP, iTerm2 badge/status, and WezTerm right-status precedents.
- Fixed repo hygiene so context-pack and lint coverage now carry RFC 0069, RFC 0070, and the new architecture/shell docs before packaging the new archive.

## Revised076 (2026-03-23)
- Continued online research on declared-versus-derived type evidence, MIME/type databases, handler/default association layers, preview-versus-open boundaries, and shell/terminal semantics that can tell `claimed type`, `derived type`, `associated handler`, `chosen opener`, and `live editor/viewer state` apart.
- Added `rfcs/0069-viewfs-keep-declared-types-derived-types-handler-associations-chosen-openers-live-open-state-and-receipts-separate.md` so type claims, derived classifications, handler associations, chosen openers, live open state, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/type-evidence-handler-choice-and-live-open-state.md` and refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` with the new type/handler/open-state seam and a sharper evaluation of what SlopOS OpenURI / typed-payload / content-type boundaries do and do not settle.
- Added `docs/70-shell/type-lenses-handler-racks-and-open-state-badges.md` and refreshed `docs/70-shell/shell-super-awesome-moves.md` and `docs/70-shell/shell-terminal-ideas.md` with type lenses, handler racks, disagreement cards, why-this-opener drawers, and open-state badges for the future custom shell+terminal.
- Refreshed `docs/90-inspirations/slopos-datacube-evaluation.md`, `docs/90-inspirations/inspirations-mapped.md`, bibliography, moving-head tracking, review queue, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised075 (2026-03-23)
- Continued online research on stable object identity versus current placement, locate-only versus broader live handle rights, explicit provider-advertised affordances, and shell/terminal semantics that can tell `same object` from `same placement` and `supported in principle` from `permitted with what you hold`.
- Added `rfcs/0068-viewfs-keep-object-identity-view-placement-current-handle-rights-advertised-operations-and-receipts-separate.md` so exact object identity, current placement in one view, current handle-rights posture, advertised operations, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/identity-placement-rights-and-affordances.md` and refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` with the new identity/placement/rights/affordance seam and a sharper evaluation of what SlopOS namespace / powerbox / capability posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/70-shell/shell-terminal-ideas.md` with place cards, verb ledgers, affordance lenses, why-not drawers, and protocol metadata that keeps identity, placement, current rights, and advertised verbs visibly distinct.
- Refreshed `docs/90-inspirations/slopos-datacube-evaluation.md`, `docs/90-inspirations/inspirations-mapped.md`, bibliography, moving-head tracking, review queue, trajectory map, assumptions/claims/non-claims/invariants, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised074 (2026-03-23)
- Continued online research on user-activation gating, activation/focus tokens, enabled-versus-active interaction state, and truthful shell UX for gesture-driven actions.
- Added `rfcs/0067-viewfs-keep-gesture-evidence-activation-tokens-armed-state-active-control-and-receipts-separate.md` so fresh gesture proof, transferable activation batons, armed/enabled lanes, active control, and durable receipts stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new interaction-proof / active-control seam and a sharper evaluation of what SlopOS capture/attention posture does and does not settle.
- Refreshed `docs/70-shell/shell-terminal-protocol-sketch.md` and `docs/70-shell/shell-super-awesome-moves.md` with activation baton chips, arming rails, and foreground-transfer card ideas for the future custom shell+terminal.
- Expanded bibliography and moving-head source tracking with HTML / Wayland / XDG portal / Win32 foreground-transfer precedents, refreshed the external review queue, regenerated the context pack and release manifest, and kept lint clean.

## Revised073 (2026-03-23)
- Continued online research on typed transcript routing, lazy link resolution, explicit hyperlink semantics, and shell selection UX.
- Added `rfcs/0066-viewfs-keep-selected-regions-entity-candidates-route-envelopes-prepared-actions-and-receipts-separate.md` to keep selected regions, extracted typed entities, route envelopes, prepared actions, and receipts separate.
- Refreshed shell and architecture notes with **entity peels**, **route slips**, and **hypertruth badges** ideas for the future custom shell+terminal.
- Expanded bibliography/source tracking with Plan 9 plumber, OSC 8 hyperlink, LSP document-link, and kitty hints precedents.
- Fixed context-pack coverage so it now includes RFCs 0065 and 0066 before packaging the new archive.

## Revised072 (2026-03-23)
- Continued online research on completion systems, lazy detail resolution, insertion semantics, trusted shell command reporting, and shell/terminal UX that can tell `candidate`, `inserted`, `compiled`, and `ready` apart.
- Added `rfcs/0065-viewfs-keep-completion-candidates-accepted-insertions-compiled-command-packets-prepared-actions-and-receipts-separate.md` so advisory completion rows, accepted prompt-buffer state, compiled command packets, prepared actions, and durable receipts/history stay visibly distinct.
- Refreshed completion, shell, and protocol docs with **ghost rows**, **detail drawers**, **accept-word ladders**, **packet gutters**, and **rerun safety badges** that make the terminal smarter without laundering suggestions into authority.
- Updated the SlopOS seam map and datacube evaluation to steal the strongest lesson from the current `mcp-completion-import-boundary-v0.md`: provider-local completion suggestions are not selector/default/workflow truth.
- Refreshed bibliography, moving-head source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised071 (2026-03-23)
- Continued online research on smart folders, live metadata queries, saved-search manifests, portal-gated index services, and shell/terminal semantics that can tell `recipe`, `snapshot`, `live feed`, and `local basket` apart.
- Added `rfcs/0064-viewfs-keep-query-manifests-result-snapshots-live-feeds-materialized-collections-live-binds-and-receipts-separate.md` so saved queries, snapshots, live feeds, materialized local sets, current binds, and durable receipts/history stay visibly distinct.
- Expanded query and shell docs with `freeze to basket`, `query-versus-basket drift`, `materialized set`, and `bound here` truth surfaces.
- Refreshed the SlopOS seam map, datacube evaluation, inspirations map, bibliography/source-tracking, assurance registries, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised070 (2026-03-23)
- Continued online research on request handles versus session handles, portal-owned live state, transfer/session lifecycle precedents, and shell/terminal semantics that can tell `request succeeded once` from `portal still active now` and from `adopted here now`.
- Added `rfcs/0063-viewfs-keep-request-handles-session-handles-portal-owned-live-state-and-receipts-separate.md` so request rows, session/transfer objects, portal-owned live state, local adopted binds/live handles, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/portal-grant-lifecycle-notes.md`, `docs/30-architecture/requests-candidates-selections-and-imports.md`, `docs/30-architecture/imports-exports-transfers-and-promised-files.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new request-versus-session-versus-live-state seam and a sharper evaluation of what SlopOS background/capshell/portal posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with request ledgers, session cards, portal-state lenses, adoption shutters, and transcript metadata that keeps request identity separate from portal-owned live state and from current local authority.
- Refreshed bibliography, source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised069 (2026-03-23)
- Continued online research on provenance attestations, endorsement/reference bundles, local appraisal/admission boundaries, transparency/audit precedents, and shell/terminal semantics that can tell `well-described` from `admitted here now`.
- Added `rfcs/0062-viewfs-keep-provenance-attestations-endorsement-bundles-local-admission-verdicts-live-handles-and-receipts-separate.md` so provenance claims, endorsement bundles/trust-root inputs, local admission verdicts, current live handles, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new provenance-versus-admission seam and a sharper evaluation of what SlopOS attestation / endorsement / document-portal posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with provenance ribbons, endorsement stacks, verdict shutters, and transcript metadata that keeps claims and endorsements separate from local admission and from live authority.
- Refreshed bibliography, source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised068 (2026-03-23)
- Continued online research on permission-state versus current authority, explicit revoke/delete/expiry state, revival/recontact designators, and shell/terminal semantics that can tell `granted` from `live now` and `revoked` from generic `stale`.
- Added `rfcs/0061-viewfs-keep-permission-outlooks-revival-designators-live-handles-death-state-verdicts-and-receipts-separate.md` so permission outlook, revival designators, current live handles, explicit death-state verdicts, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/revocation-and-durable-grants-design-space.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new permission-versus-liveness seam and a sharper evaluation of what SlopOS document/lease/powerbox posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with permission lights, death certificates, preflight gutters, repair ladders, and transcript metadata that keeps permission outlook separate from current authority and from dead-state history.
- Refreshed bibliography, moving-head tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised067 (2026-03-23)
- Continued online research on declared caveats versus enforced attenuation, proxy-first lease/membrane delegation, explicit revocation surfaces, and shell/terminal semantics that can tell `caveat declared` from `enforced now`.
- Added `rfcs/0060-viewfs-keep-caveat-sets-membrane-leases-live-handles-and-receipts-separate.md` so caveat sets, membrane/lease proxies, live handles, revival designators, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/rights-attenuation-and-bundles.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new caveat-versus-enforcement seam and a sharper evaluation of what SlopOS D-LEASE / CH-CAPX / capability-semantics posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with caveat laminates, membrane badges, expiry gutters, renewal ladders, and transcript metadata that keeps declared bounds separate from enforced current authority.
- Refreshed bibliography, source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised066 (2026-03-23)
- Continued online research on designation-versus-authority, capability URLs, sturdyref locators, security-scoped bookmark persistence, document-portal mediation, and terminal metadata that can keep `designation only` visibly different from `authority-bearing ticket`.
- Added `rfcs/0059-viewfs-keep-non-authoritative-designators-authority-bearing-tickets-local-aliases-live-handles-and-receipts-separate.md` so note-friendly designators, authority-bearing tickets, local aliases/binds, live handles, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new designation-versus-authority seam and a sharper evaluation of what SlopOS wallet / plumb / document-handle / CapStore posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with inert-designator-paste, ticket chips, explicit authority-reveal ladders, and transcript metadata that keeps designators separate from tickets.
- Refreshed bibliography, source tracking, review queue, evidence index, lint coverage, context-pack coverage, and release manifest for the new revision.

## Revised065 (2026-03-23)
- Continued online research on mediated transfer/handoff, explicit local adoption, UNIX `SCM_RIGHTS`, Fuchsia handle duplication/transfer, Wayland data offers, security-scoped durable reopen caution, and shell/terminal semantics that keep `offered` visibly different from `adopted here now`.
- Added `rfcs/0058-viewfs-keep-transfer-offers-live-handle-copies-revival-designators-adopted-binds-and-receipts-separate.md` so transfer offers, accepted representations, live copied handles, later revival designators, adopted local binds, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new handoff-versus-adoption seam and a sharper evaluation of what SlopOS capshell pipeline / CAPX / import-to-docref posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with transfer sheets, adoption rails, issuer/courier witness chips, and `offer-only` versus `adopted-here` shell truth ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised064 (2026-03-23)
- Continued online research on durable reopen designators, bookmark-style revalidation, exact-handle restart continuity, per-component persistent state versus running authority, and shell/terminal protocol ideas for making `remembered` visibly different from `live now`.
- Added `rfcs/0057-viewfs-keep-remembered-designators-revalidation-continuity-lockers-live-handles-and-receipts-separate.md` so remembered designators, explicit revalidation acts, narrow continuity lockers, revived live handles/binds, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new remembered-versus-live continuity seam and a sharper evaluation of what SlopOS CapStore / activation-handoff / document-portal posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with reopen-truth ladders, continuity lockers, stale-target repair rails, and semantic transcript ideas that keep remembered designation separate from current authority.
- Refreshed bibliography, external-source tracking/review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised063 (2026-03-23)
- Continued online research on portal-mediated import boundaries, per-process/per-component namespace construction, durable document IDs versus current handles, and shell/terminal integration patterns that make `source ref only` visibly different from `fresh local object`.
- Added `rfcs/0056-viewfs-keep-imported-source-refs-materialized-local-objects-docrefs-and-receipts-separate.md` so imported source refs, explicit materialization, fresh local objects, local durable docrefs, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new import-localization seam and a sharper evaluation of what SlopOS document-portal / import-to-docref posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with localize-first import cards, docref ladders, semantic freshness labels, and truth-honest shell integration ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised062 (2026-03-23)
- Continued online research on content/object descriptors, digest-authoritative versus locator-hint references, creator-populated capability namespaces, portal-scoped document import, and shell UX that can tell `descriptor only` from `live handle now`.
- Added `rfcs/0055-viewfs-keep-content-descriptors-live-handles-and-receipts-separate.md` so descriptor envelopes, live handles/binds, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new descriptor-first seam and a sharper evaluation of what SlopOS artifact/document-handle posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with descriptor cards, hydrate-later ladders, object chips, and descriptor-truth shell ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised061 (2026-03-23)
- Continued online research on unnamed temporary objects, publish-later namespace binding, `O_TMPFILE` / `linkat(..., AT_EMPTY_PATH)` style publication, and shell UX that can tell `draft object` from `published name here`.
- Added `rfcs/0054-viewfs-keep-unnamed-objects-namespace-publication-and-receipts-separate.md` so unpublished objects, publication anchors, publication acts, visible names, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new unnamed-object / namespace-publication seam and a sharper evaluation of what SlopOS CapStore/view/document-handle posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with draft-object cards, publish-later ladders, parent-anchor publish sheets, and publication-receipt ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised060 (2026-03-23)
- Continued online research on attached-namespace propagation posture, peer groups, detached-then-attached propagation timing, and shell UX that can show local-only versus shared blast radius honestly.
- Added `rfcs/0053-viewfs-keep-live-binds-propagation-posture-peer-groups-and-receipts-separate.md` so one current bind, its propagation posture, any peer/upstream relationship, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new bind-versus-propagation seam and a sharper evaluation of what SlopOS view / replication posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with propagation badges, blast-radius previews, peer/upstream drawers, and attach-private-first ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised059 (2026-03-23)
- Continued online research on multi-path namespace mutation, source-versus-destination parent anchors, Fuchsia vnode-token/cookie rename mechanics, Capsicum source/destination directory rights, and Linux `renameat2()` collision/exchange modes.
- Added `rfcs/0052-viewfs-keep-object-identity-parent-anchors-namespace-mutations-and-receipts-separate.md` so object identity, source parent anchor, destination parent anchor, namespace-mutation mode, and durable mutation history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new namespace-mutation seam and a sharper evaluation of what SlopOS handle/root/docref posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with two-anchor rename cards, overwrite/exchange ladders, anchor-gap warnings, and name-diff receipt ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised058 (2026-03-23)
- Continued online research on launch-boundary descriptor inheritance, `O_CLOEXEC` race avoidance, `posix_spawn()` inheritance defaults, bulk close-on-exec shutters, and the newer `FD_CLOFORK` precedent.
- Added `rfcs/0051-viewfs-keep-current-handles-launch-inheritance-child-slots-and-launch-receipts-separate.md` so current handle possession, launch-boundary inheritance posture, exact child-slot delivery, and durable launch history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new launch-inheritance seam and a sharper evaluation of what SlopOS activation / exec-pack / handle-table posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with inheritance shutters, child-slot maps, launch-boundary diff cards, and authority-leak sirens.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, release manifest, and repaired shell-terminal protocol numbering around the handle-class event while touching those hygiene surfaces.

## Revised057 (2026-03-23)
- Continued online research on locator/metadata handles, `O_PATH`-style designation semantics, detached mount/object handles, `AT_EMPTY_PATH` metadata operations, and shell UX that can tell `inspect-only` from `readable now`.
- Added `rfcs/0050-viewfs-keep-locator-handles-byte-io-handles-and-durable-refs-separate.md` so locator handles, live byte-I/O handles, reopen/escalation acts, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new handle-class seam and a sharper evaluation of what SlopOS cwd-root / handle-table posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with handle-class badges, inspect-first cards, open-for-more-power ladders, and locator-versus-byte-I/O truth ideas.
- Refreshed bibliography, moving-head tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised056 (2026-03-22)
- Continued online research on open-file-description aliasing, descriptor duplication, cross-process handle copying, and shell UX that can tell `same object` from `same live cursor/lock state`.
- Added `rfcs/0049-viewfs-keep-handle-slots-live-handle-copies-shared-open-state-and-independent-reopens-separate.md` so slot-local bindings, live handle copies, shared open-state groups, independent reopens, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new handle-topology seam and a sharper evaluation of what SlopOS handle-table posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with twin-handle badges, duplicate-vs-reopen ladders, and shared-open-state drawer ideas.
- Refreshed bibliography, moving-head tracking, review queue, evidence index, context pack, lint/context-pack coverage, and release manifest for the new revision; also repaired the missing Revision 055 evidence-index entries while touching the hygiene surfaces.

## Revised055 (2026-03-22)
- Continued online research on explicit runner/runtime selection, environment-hosted launch choices, structured launch/runtime config, and terminal UX that keeps the live mutable prompt area separate from scrollback history.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exec objects versus runner/runtime choice versus bootstrap posture so ViewFS can steal launch-hosting lessons without freezing a runtime mechanism too early.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md`, and added `rfcs/0048-viewfs-keep-exec-objects-runners-bootstrap-posture-and-live-sessions-separate.md` so exec objects, runner/runtime choice, bootstrap posture, live sessions, and durable history stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with runner badges, bootstrap shutters, and mutable-prompt-dock ideas that make the future custom shell+terminal stronger without pretending terminal history and live draft state are the same thing.
- Expanded bibliography and moving-head source tracking with Fuchsia runner/environment and OCI runtime-config precedents plus iTerm2 command-selection / mutable-area precedents, refreshed the external review queue, and regenerated the context pack and release manifest for the new archive.

## Revised054 (2026-03-22)
- Continued online research on UNIX job control, controlling-terminal posture, foreground process groups, login-time TTY adoption, and shell chrome that tells the truth about where interactive input and terminal-generated signals will actually land.
- Added `rfcs/0047-viewfs-keep-live-process-handles-terminal-streams-controlling-tty-and-foreground-turns-separate.md` so running-command identity, stream lanes, controlling-terminal posture, foreground turns, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/observe-attach-control-and-sideband-lanes.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` so observe/attach shells stop flattening process handles, stdio/PTY streams, controlling TTY state, current foreground ownership, and history into one vague attached bit.
- Expanded `docs/70-shell/follow-tails-attach-rails-and-control-panes.md`, `docs/70-shell/shell-super-awesome-moves.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` with foreground-baton pills, TTY-lease badges, and interrupt-preview rails that make the future custom shell+terminal richer without pretending transcript rows are live control.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the new job-control / controlling-terminal seam, added bibliography + source-review entries for classic UNIX job-control / TTY precedents, and refreshed the context pack, evidence index, and release manifest for the new archive.

## Revised053 (2026-03-22)
- Continued online research on clipboard/selection ownership, offered representations, explicit transfer retrieval, permission-gated typed clipboard reads, and how those lessons should shape ViewFS import/paste honesty while SlopOS remains in design.
- Added `rfcs/0046-viewfs-keep-selection-owners-offers-pasted-input-and-imported-objects-separate.md` so current selection ownership, offered representations, pasted prompt bytes, imported objects, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/imports-exports-transfers-and-promised-files.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` so clipboard/selection owner/source, accepted representation, prompt paste, imported object identity, and durable reopen do not collapse back together.
- Expanded `docs/70-shell/shipping-lanes-boundary-previews-and-promised-outputs.md`, `docs/70-shell/shell-super-awesome-moves.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` with clipboard-offer cards, MIME-aware transfer truth, and paste-versus-import ladders that make the future custom shell+terminal richer without pretending paste is authority.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the new transfer/clipboard seam, added bibliography + source-review entries for Wayland primary selection, ICCCM selections, and kitty clipboard docs, and refreshed the context pack, evidence index, and release manifest for the new archive.

## Revised052 (2026-03-22)
- Continued online research on exact startup code closure, loader search policy, late dynamic imports/plugins, and shell chrome that tells the truth about closure certainty instead of only exec-object identity.
- Added `rfcs/0045-viewfs-keep-exec-objects-startup-code-closure-loader-policy-and-late-imports-separate.md` to keep exact exec objects, startup code closure, loader policy/search posture, late import/plugin lanes, and launch/history artifacts on distinct seams.
- Updated `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exact executable objects versus startup code closure, grounded against SlopOS Capshell code-closure drafts.
- Updated `docs/30-architecture/design-splits-and-non-decisions.md` and `docs/30-architecture/slopos-seam-map.md` so exec objects, startup closure, loader debt, late imports, and receipts stay visibly distinct while SlopOS is still moving.
- Updated `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with closure-certainty badges, loader-debt warnings, and late-import route-sheet ideas.
- Refreshed README, bibliography, external-source tracking, review queue, evidence index, lint/context-pack coverage, context pack, and release manifest for the new revision.

## Revised051 (2026-03-22)
- Continued online research on exact executable-object launch, file-descriptor-based execution, activation-time credential delivery, and prompt-aware terminal chrome for launch inspection.
- Added `rfcs/0044-viewfs-keep-exec-objects-startup-credentials-and-launch-basis-separate.md` to keep exact exec objects, explicit interpreter/script entry, argv/env basis, startup credential slots, and launch/history artifacts on distinct seams.
- Updated `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exact exec objects and activation-time credentials, grounded against SlopOS Capshell posture drafts.
- Updated `docs/30-architecture/design-splits-and-non-decisions.md` and `docs/30-architecture/slopos-seam-map.md` so launch basis, exec objects, startup credentials, and launch receipts stay visibly distinct while SlopOS is still moving.
- Updated `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with launch-basis cards, credential drawers, and exact-exec-object badge ideas.
- Refreshed README, bibliography, external-source tracking, review queue, context pack, and release manifest for the new revision.

## Revised050 (2026-03-22)
- Continued online research on detached namespace fragments, explicit attach acts, pre-attach posture, bracketed-paste input origin, and disambiguated terminal key packets.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around detached namespace fragments so ViewFS can steal explicit pre-attach/attach ideas without collapsing them into global paths, durable naming, or durable reopen.
- Refreshed `docs/30-architecture/slopos-seam-map.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and new `rfcs/0043-viewfs-keep-detached-view-fragments-pre-attach-posture-and-live-binds-separate.md` so prepared fragments, pre-attach posture, live binds, current placement, and receipts stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with paste-capsule, prompt-local input-origin, and disambiguated-key-packet ideas that make the future custom shell+terminal stronger without pretending pasted bytes or ambiguous escape codes are authority.
- Expanded bibliography and moving-head source tracking with Linux `open_tree` / `move_mount` / `mount_setattr`, xterm bracketed paste, and kitty keyboard precedents, refreshed the external review queue, regenerated the context pack, and rebuilt the release manifest for the new archive.

## Revised048 (2026-03-22)
- Continued online research on capability-shaped running-process handles, lifecycle-control versus deep-inspection rights, and shell chrome that tells the truth about live-versus-history command objects.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exact running-process identity so ViewFS can steal process-descriptor ideas without collapsing them into transcript folklore or broad debugger power.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md`, and added `rfcs/0042-viewfs-keep-command-packets-live-process-handles-control-rights-and-deep-inspection-separate.md` so command packets, live process handles, lifecycle-control rights, deeper inspection rights, and history rows stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with live-process-card and right-badging ideas that make the future custom shell+terminal stronger without pretending PIDs or transcript rows are authority.
- Expanded bibliography and moving-head source tracking with Linux pidfd and FreeBSD procdesc precedents, refreshed the external review queue, regenerated the context pack, and rebuilt the release manifest for the new archive.

## Revised047 (2026-03-22)
- Continued online research on courier provenance, peer-credential witness surfaces, structured terminal command packets, and exact-action shell chrome.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around **courier provenance** and **structured command packets** so ViewFS can steal exact local-transfer and escalation patterns without collapsing them into object identity, durable receipt, or transcript folklore.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so peer witnesses, transferred live handles, structured command packets, plain transcript rows, and durable receipts stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with peer-witness courier drawers and explicit command-packet promotion ideas that make the future custom shell+terminal more powerful without pretending copied text is authority.
- Expanded bibliography and moving-head source tracking with Linux peer-credential / SO_PASSCRED and VS Code structured terminal-command attachment precedents, repaired a small hygiene gap by bringing RFC 0041 into lint/context-pack coverage, and regenerated the context pack and release manifest for the new archive.

## Revised046 (2026-03-22)
- Continued online research on startup-delivered handles, activation carriers, badged capability copies, command-block truth ladders, and action-gated terminal chrome.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around activation kits and issuer-visible handle copies so ViewFS can steal explicit startup delivery without collapsing it into durable identity or durable reopen.
- Refreshed `docs/30-architecture/slopos-seam-map.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and new `rfcs/0041-viewfs-keep-activation-carriers-badged-handle-copies-and-object-identity-separate.md` so activation slots, live handle copies, issuer badges, immutable object refs, and receipts stay visibly distinct while SlopOS is still moving.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with activation-kit cards, truth-graded command blocks, selection-packet / primary-target, and badged-handle drawer ideas that make the terminal richer without pretending transcript guesswork is authority.
- Expanded bibliography and moving-head source tracking with seL4 badged-capability, systemd socket-activation, and VS Code shell-integration precedents, refreshed the external review queue, and regenerated the context pack and release manifest for the new archive.

## Revised045 (2026-03-22)
- Continued online research on exact local handle transfer, transient byte staging, freeze-for-review semantics, and shell/terminal UX for commit-last import/export flows.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around transient exact-byte staging capsules so ViewFS can steal useful local-transfer and review patterns without freezing a persistence model.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so staged capsules, couriered live handles, committed objects, durable reopen refs, and ordinary history rows stay visibly distinct.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with sealed-capsule, explicit-handle-courier, and commit-last shell ideas worth stealing.
- Expanded `docs/00-meta/bibliography.md`, the moving-head head register, and the external review queue with Linux memfd/seal and explicit fd-passing precedents, then regenerated the context pack and release manifest for the new archive.

## Revised044 (2026-03-22)
- Continued online research on narrow continuity versus durable persistence, exact object identity versus current placement, provider-declared operation surfaces, and truthful shell/terminal review chrome.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` so the current SlopOS datacube is evaluated through two more low-regret lenses: restart-stable exact-handle continuity is a useful middle seam, and action menus should be driven by exact object/handle affordances instead of path folklore.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so ViewFS keeps resumable lane lockers, durable reopen refs, persistent roots, object identity, current placement, and advertised operations on visibly different seams while SlopOS is still moving.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with handle-locker, resumable-lane, exact-action-menu, and provider-flag shell ideas that make the terminal stronger without pretending transcript guesses are authority.
- Extended bibliography and moving-head review tracking with a systemd file-descriptor-store precedent, refreshed Android/terminal moving-head source dates used again in this pass, and regenerated the context pack and release manifest for the new archive.

## Revised043 (2026-03-22)
- Continued online research on narrow continuity versus durable persistence, creator-populated per-process namespaces, portal request/transfer lifetimes, structured shell output, and trusted-but-restricted terminal UX.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` so the current SlopOS datacube is evaluated not just through CapStore/AttrFS/Capshell, but also through a new low-regret continuity lens: narrow escrow/resume should stay separate from durable reopen and persistent authority.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so ViewFS keeps continuity/escrow, durable reopen, persistent roots, and queued follow-up control on visibly different seams while SlopOS is still moving.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with trusted-review-lane, collapsible-command-section, steering-rail, and structured-object-drawer ideas that make the terminal richer without lying about authority.
- Extended bibliography and moving-head review tracking with current Fuchsia idle-stop/handle-escrow and VS Code terminal-section precedents, then regenerated the context pack and release manifest for the new archive.

## Revised042 (2026-03-22)
- Continued online research on optional capability persistence, durable-root rollback/resurrection problems, view-scoped query/smart-folder posture, portal request lifetimes, and semantic shell/terminal metadata.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a more explicit reading of the SlopOS datacube through CapStore, AttrFS, and Capshell, focusing on low-regret separations rather than mechanism lock-in.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so immutable storage, optional durable roots, durable reopen, snapshot query, live feed, and ambient inventory stay visibly separate while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with pane-var, semantic-zone, truth-labeled-history, and persistence/query lessons worth stealing.
- Repaired bibliography coverage for missing referenced sources, added CapROS/TreeSLS persistence references, updated moving-head review tracking, and regenerated the context pack and release manifest for the new revision.

## Revised041 (2026-03-22)
- Continued online research on capability-native object stores, explicit transfer mediation, creator-populated namespaces, structured shell metadata, and restricted-but-productive terminal UX.
- Added `docs/90-inspirations/slopos-datacube-evaluation.md` to record what ViewFS should copy now from the uploaded SlopOS datacube, what it should only copy lightly, what it should postpone while SlopOS is still moving, and which shell/terminal ideas feel promising without freezing them.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md` with a sharper low-regret freeze line: keep identity, naming, mutable heads, reopen state, request/selection/grant/bind, browse-vs-trust, and compat debt visibly separate.
- Refreshed `docs/70-shell/shell-super-awesome-moves.md` with semantic-inspector, restricted-badge, typed-link, and prompt-local click ideas that keep terminal delight subordinate to authority truth.
- Refreshed `docs/90-inspirations/inspirations-mapped.md` with another explicit lesson that transfer lanes should negotiate offers and representations rather than smuggling ambient reach back in.
- Expanded `docs/00-meta/bibliography.md`, the external-source head register, and the review queue with a Wayland data-offer precedent for typed mediated transfer.
- Tightened repo hygiene by bringing inspiration docs into the context pack and lint requirements, and by adding the Revision 040 live-session seam files that earlier lint rules forgot to enumerate.
- Updated `README.md`, the evidence index, the context pack, and the release manifest for the new archive.

## Revised040 (2026-03-22)
- Continued online research on live-session interaction seams: follow/query versus interactive attach, control messages versus synchronous updates, injected debug exec, sideband tunnels, read-only clients, and active-versus-armed interaction state.
- Added `docs/30-architecture/observe-attach-control-and-sideband-lanes.md` to keep read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts on distinct seams.
- Added `docs/70-shell/follow-tails-attach-rails-and-control-panes.md` so ViewFS can collect shell ideas around follow tails, attach rails, control panes, debug launch drawers, sideband badges, and live-session receipts.
- Added `rfcs/0040-viewfs-keep-observe-attach-control-and-sideband-lanes-separate.md` so future proposals must classify whether they change observe/query, interactive attach, control messages, exec/debug, sideband access, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from kubectl live-session verbs, tmux read-only/control-mode clients, Temporal queries/signals/updates, and XDG InputCapture state transitions.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised039 (2026-03-22)
- Continued online research on deferred-work control seams: request close/abort, best-effort cancellation, detach/delete versus remote stop, force termination, reset/fork from history, retained-result expiry, and shell UX for honest stop ladders.
- Added `docs/30-architecture/cancel-terminate-forget-reset-and-rerun.md` to keep close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts on distinct seams.
- Added `docs/70-shell/stop-ladders-detach-rails-and-rerun-forks.md` so ViewFS can collect shell ideas around stop ladders, detach rails, termination fuses, retry-vs-fork drawers, result-retention lockers, and stop receipts.
- Added `rfcs/0039-viewfs-keep-cancel-terminate-forget-reset-and-rerun-separate.md` so future proposals must classify whether they change close/cancel, termination, detach/delete, retry-fresh, reset/fork/attach, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from XDG Request close semantics, Google long-running operation cancel/delete/expiry guidance, MCP task cancellation/deletion/keepAlive semantics, Temporal interrupt/reset/reuse posture, and current session-fork UX.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised038 (2026-03-22)
- Continued online research on deferred-work seams: portal request handles, task-augmented helper requests, progress lanes, input-required checkpoints, long-running-operation polling, background permission/status, and shell UX for honest queued follow-ups.
- Added `docs/30-architecture/requests-tasks-progress-and-results.md` to keep immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final result retrieval, and durable receipts on distinct seams.
- Added `docs/70-shell/task-badges-progress-lanes-and-result-lockers.md` so ViewFS can collect shell ideas around task badges, progress lanes, input-required drawers, queue rails, result lockers, and task receipts.
- Added `rfcs/0038-viewfs-keep-requests-tasks-progress-and-results-separate.md` so future proposals must classify whether they change immediate request submission, accepted task wrappers, live progress, input-required checkpoints, deferred final result retrieval, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from the MCP tasks/progress drafts, XDG request/background portals, Google long-running operations, and current VS Code task/background-agent UX.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised037 (2026-03-22)
- Continued online research on MCP feature classes, request-scoped helper binding, completion disclosure risks, interactive helper surfaces, and terminal-native helper catalog UX.
- Added `docs/30-architecture/resources-prompts-tools-apps-and-bindings.md` to keep helper-exposed resources, prompts, tools, app surfaces, completion suggestions, request-bound attachments, live invocation/results, and durable receipts on distinct seams.
- Added `docs/70-shell/resource-shelves-prompt-chips-tool-racks-and-app-docks.md` so ViewFS can collect shell ideas around resource shelves, prompt chips, tool racks, app docks, completion popovers, binding trays, and invocation receipts.
- Added `rfcs/0037-viewfs-keep-resources-prompts-tools-apps-and-bindings-separate.md` so future proposals must classify whether they change feature catalogs, completion hints, request bindings, live invocations/results, or only durable history.
- Fixed a repo hygiene gap by adding missing helper-lifecycle assurance entries to the claim and invariant registries before layering the new helper-feature seam on top.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from the MCP specification, MCP completion utility, VS Code MCP catalogs, and prompt/tool binding posture.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

- Continued online research on helper lifecycle seams: publisher trust, install/config source, enablement, start approvals, live brokered sessions, request-scoped tool selection, and lifecycle receipts.
- Added `docs/30-architecture/publisher-trust-helper-installs-and-live-sessions.md` to keep publisher trust, installed helper packages, configured helper definitions, enabled state, start approvals, live sessions, request-scoped selections, and receipts on distinct seams.
- Added `docs/70-shell/publisher-badges-start-gates-and-tool-racks.md` so ViewFS can collect shell ideas around publisher badges, installed cards, start-gate drawers, live-session beacons, tool racks, trust-reset sparks, and lifecycle receipts.
- Added `rfcs/0036-viewfs-keep-publisher-trust-helper-installs-and-live-sessions-separate.md` so future proposals must classify whether they change publisher trust, install/config state, enablement, start gates, live sessions, request-scoped tool selection, or only durable history.

## Revised035 (2026-03-22)
- Continued online research on protected configuration scopes, source-class authorability, manual-invocation versus auto-apply helper material, central permission brokers, and terminal-native authorability UX.
- Added `docs/30-architecture/protected-scopes-authorability-and-invocation-lanes.md` to keep protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts on distinct seams.
- Added `docs/70-shell/protected-badges-authorability-matrices-and-latched-invokes.md` so ViewFS can collect shell ideas around protected chips, authorability matrix drawers, latched invokes, broker badges, and invoke-vs-adopt receipt cards.
- Added `rfcs/0035-viewfs-keep-protected-scopes-authorability-and-invocation-lanes-separate.md` so future proposals must classify whether they change protected-only state classes, invoke-only helper material, trust-gated adoption lanes, effective active state, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from Git protected configuration and `safe.directory`, VS Code prompt files/custom agents, restricted configurations and managed policies, and Deno permission brokers.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised034 (2026-03-22)
- Continued online research on managed policy authorship, trust-state withholding, trusted carriers versus authorable sources, current plugin/server trust posture, and terminal-native source-aware shell UX.
- Added `docs/30-architecture/policy-authors-carriers-and-advisory-sources.md` to keep author classes, carrier/container classes, trust gates, advisory-only sources, effective active state, and durable receipts on distinct seams.
- Added `docs/70-shell/author-badges-carrier-tags-and-advisory-rails.md` so ViewFS can collect shell ideas around author badges, carrier tags, advisory-only rails, trust-tunnel warnings, and authorability fuse drawers.
- Added `rfcs/0034-viewfs-keep-policy-authors-carriers-and-advisory-sources-separate.md` so future proposals must classify whether they change author classes, carrier classes, trust gates, advisory-only rails, effective active state, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from VS Code customization discovery, plugin MCP trust posture, workspace trust/security boundaries, managed-policy overrides, Git origin/scope inspection, Deno deny precedence, and modern terminal shell-integration overlays.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised033 (2026-03-22)
- Continued online research on enterprise policy overrides, trust-gated workspace values, imported/discovered helper configs, source-stack inspection, and source-aware shell/terminal UX.
- Added `docs/30-architecture/policy-sources-trust-gates-and-precedence.md` to keep owner/org policy sources, trust-state gates, user/profile preferences, workspace/imported proposal sources, effective active state, and durable receipts on distinct seams.
- Added `docs/70-shell/origin-stacks-trust-shutters-and-override-ledgers.md` so ViewFS can collect shell ideas around origin stacks, trust shutters, import quarantine trays, winner chips, and override ledgers.
- Added `rfcs/0033-viewfs-keep-policy-sources-trust-gates-and-precedence-separate.md` so future proposals must classify whether they change authoritative policy sources, trust-state gating, lower-precedence preferences, imported helper material, effective active state, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from VS Code enterprise AI policies, workspace trust/restricted configurations, MCP configuration/discovery/reset-trust posture, Git origin/scope inspection, and Deno deny/audit posture.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised032 (2026-03-22)
- Continued online research on explicit deny precedence, scope applicability, restricted-but-useful configuration posture, current session versus broader adoption scopes, and terminal UX for narrowing instead of widening.
- Added `docs/30-architecture/deny-ceilings-narrowing-and-scope-eligibility.md` to keep deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption receipts on distinct seams.
- Added `docs/70-shell/ceiling-pills-narrowing-previews-and-scope-fuses.md` so ViewFS can collect shell ideas around ceiling pills, narrowing previews, scope fuses, and adopt-the-narrowest-safe-rung flows.
- Added `rfcs/0032-viewfs-keep-deny-ceilings-narrowing-and-scope-eligibility-separate.md` so future proposals must classify whether they change authoritative ceilings, scope eligibility, narrowing transforms, escalation interactions, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from Cedar deny semantics, Deno deny precedence and audit logs, VS Code configuration scopes, Workspace Trust restricted configurations, current agent-tool permission levels, and VS Code 1.112 terminal/session ergonomics.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised031 (2026-03-22)
- Continued online research on proposal provenance, explicit scope/adoption ladders, configuration-origin diagnostics, MCP trust prompts, session-vs-workspace approval scopes, and authority-vs-agent role separation.
- Added `docs/30-architecture/proposers-lanes-escalations-and-adoptions.md` to keep proposal origins, proposal scopes, escalation requests, authoritative adoptions, and durable adoption receipts on distinct seams.
- Added `docs/70-shell/proposer-badges-escalation-ladders-and-adoption-gates.md` so ViewFS can collect shell ideas around proposer badges, scope chips, escalation ladders, adoption gates, and quiet decline/adoption history.
- Added `rfcs/0031-viewfs-keep-proposers-lanes-escalations-and-adoptions-separate.md` so future proposals must classify whether they change proposal sources, proposal scopes, escalation interactions, authoritative adoptions, or only durable adoption history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from Git config origin/scope inspection, VS Code chat customization diagnostics, MCP server trust/config scopes, agent permission scopes, and polkit’s authority-versus-authentication-agent split.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised030 (2026-03-22)
- Continued external research on policy-family selection, exact consistency cuts, fallback precedence, and shell-native repair UX.
- Added `docs/30-architecture/policy-families-cuts-fallbacks-and-repair.md` to pin the seam between policy-family choice, exact authoritative cuts, fallback candidates, repair proposals, and durable selection receipts.
- Added `rfcs/0030-viewfs-keep-policy-families-cuts-fallbacks-and-repair-separate.md` to keep policy-aware shell recovery from silently swapping judges.
- Added `docs/70-shell/cut-pickers-fallback-rails-and-repair-prompts.md` and extended shell protocol/idea docs with cut-picker, fallback-rail, and selection-receipt terminal moves.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from OPA discovery/config precedence and SpiceDB consistency/ZedToken handling.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised029 (2026-03-22)
- Continued online research on policy validation versus runtime authorization, policy-engine versus enforcement seams, temporary authorization cautionary cases, decision-log redaction, and terminal-native policy/debug overlays.
- Added `docs/30-architecture/schemas-policies-advice-diagnostics-and-decision-logs.md` to keep schema/validation material, authoritative policy/caveat material, shell advice rails, per-decision diagnostics, and durable logs/receipts on distinct seams.
- Added `docs/70-shell/policy-lenses-advice-rails-and-decision-traces.md` so ViewFS can collect shell ideas around policy lenses, non-authoritative advice rails, diagnostic cards, and audit-trace chips.
- Added `rfcs/0029-viewfs-keep-schemas-policies-advice-diagnostics-and-decision-logs-separate.md` so future proposals must classify whether they change validation material, authoritative policy, shell advice, decision diagnostics, or only durable logs/history.
- Updated README, trajectory map, roadmap, architecture overview, SlopOS seam map, shell protocol/ideas, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised028 (2026-03-22)
- Continued online research on attenuation caveats, authorization consistency/freshness witnesses, denial/audit explainability, and shell/terminal affordances for witness/caveat inspection.
- Added `docs/30-architecture/witness-packs-caveats-freshness-and-why-records.md` to keep admissible witness material, caveat sets, freshness/consistency witnesses, why-records, and durable receipts on distinct seams.
- Added `docs/70-shell/caveat-chips-witness-drawers-and-why-panels.md` so replay/import/run UX can become more explainable without turning history into standing authority.
- Added `rfcs/0028-viewfs-keep-witness-packs-caveats-freshness-and-why-records-separate.md` to force future proposals to classify whether they change witness material, caveats, freshness evidence, why-records, or only durable history.
- Updated README, trajectory map, roadmap, architecture overview, SlopOS seam map, shell protocol/ideas, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised027 (2026-03-22)
- Continued online research on exact-basis approval, stale durable refs, reauthorization-on-input-change, bounded durable reopen lists, and semantic terminal metadata for replay/renewal UX.
- Added `docs/30-architecture/basis-records-drift-checks-and-reconsent.md` to keep reuse candidates, exact prior basis records, drift checks, fresh reconsent, renewed artifacts, and history receipts on distinct seams.
- Added `docs/70-shell/basis-diffs-reconsent-ladders-and-renewal-guards.md` so replay, renewal, and receipt-only fallbacks can be ambitious without treating past success as current authority.
- Added `rfcs/0027-viewfs-keep-basis-records-drift-checks-and-reconsent-separate.md` to force future proposals to classify whether they change basis records, drift checks, reconsent checkpoints, renewed artifacts, or only history.
- Updated architecture overview, SlopOS seam map, shell protocol/ideas, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, roadmap, trajectory map, context pack, lint requirements, and release manifest for the new revision.

## Revised026 (2026-03-22)
- Continued online research on temporary authority sharing, revocation/expiry vocabulary, security-scoped reopen flows, explicit permission prompts, and shell/terminal affordances for borrowed authority.
- Added `docs/30-architecture/loans-delegations-recalls-and-expiry.md` to keep lend requests, live borrowed authority, durable delegated refs, issuer-side recall/expiry controls, and loan-end receipts on distinct seams.
- Added `docs/70-shell/lend-once-drawers-borrow-badges-and-recall-rails.md` to collect shell ideas around lend-once drawers, borrowed-authority badges, expiry rails, recall cards, and promote-from-borrow flows.
- Added `rfcs/0026-viewfs-keep-loans-delegations-recalls-and-expiry-separate.md` so future proposals must classify whether they affect borrow requests, live loans, durable delegated refs, issuer-side recall/expiry controls, or only history/receipts.
- Updated architecture overview, SlopOS seam map, shell ideas, inspirations, bibliography/review tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised025 (2026-03-22)
- Continued online research on saved workflows, notebook/runbook UX, workspace-vs-user automation boundaries, explicit promotion flows, and replay safety.
- Added `docs/30-architecture/suggestions-recipes-promotions-and-runs.md` to keep externally suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history/receipts on distinct seams.
- Added `docs/70-shell/suggestion-trays-promotion-lanes-and-replay-guards.md` to collect shell ideas around suggestion trays, explicit promotion, source-drift badges, notebook truth states, and replay guards.
- Added `rfcs/0025-viewfs-keep-suggestions-recipes-promotions-and-runs-separate.md` so future proposals must classify suggestion sources, promotion acts, user-owned workflows, prepared plans, committed runs, and history separately.
- Updated trajectory map, roadmap, architecture overview, design-splits guidance, SlopOS seam map, shell ideas, inspiration map, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised024 (2026-03-22)
- Continued online research on typed route/action preparation, exact approval-basis binding, provider-supported operation flags, runtime permission prompts, restricted-but-productive execution posture, and terminal metadata for plan/result inspection.
- Added `docs/30-architecture/intents-route-plans-approvals-and-results.md` to keep user intent, prepared route plans, approval checkpoints, committed execution, and result receipts on distinct seams.
- Added `docs/70-shell/route-plans-approval-checkpoints-and-result-cards.md` to collect shell ideas around route-plan cards, prepare-versus-commit, approval diffs, restricted productivity, and result cards.
- Added `rfcs/0024-viewfs-keep-intents-plans-approvals-and-results-separate.md` so future proposals must classify whether they are changing intent, plan, approval, execution, or only result/history surfaces.
- Updated README, changelog, trajectory map, roadmap, architecture overview, design-splits note, shell protocol sketch, shell-terminal ideas, shell super-awesome notes, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised023 (2026-03-22)
- Continued online research on portal request objects, chooser-owned candidate sets, restricted synthetic grant views, provider-supported operation surfaces, Capsicum adoption/tooling lessons, and quiet restricted-mode UX for mediated imports.
- Added `docs/30-architecture/requests-candidates-selections-and-imports.md` to keep mediated request objects, candidate/designation surfaces, selections, minted grants/refs, live binds, and receipts on distinct seams.
- Added `docs/70-shell/chooser-sheets-staging-trays-and-grant-ledgers.md` to collect shell ideas around chooser sheets, request chips, staging trays, provider-ops-aware route sheets, grant ledgers, and ephemeral-first import UX.
- Added `rfcs/0023-viewfs-keep-requests-selections-grants-and-binds-separate.md` so future proposals must classify whether they are changing interaction state, candidate/designation surfaces, selected outcomes, minted grants/refs, live binds, or only history surfaces.
- Updated README, changelog, trajectory map, architecture overview, design-splits note, portal-grant lifecycle notes, shell protocol sketch, shell super-awesome notes, shell-terminal ideas, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised022 (2026-03-22)
- Continued online research on creator-populated namespaces, grouped capability dictionaries, restricted synthetic grant views, shell block/mark integration, and structured-shell UX for honest launch rehearsals.
- Added `docs/30-architecture/bundles-view-fragments-and-launch-kits.md` to keep grouped authority objects, view fragments/templates, live binds, child launch kits, and receipts on distinct seams.
- Added `docs/70-shell/launch-rehearsals-kit-cards-and-view-panes.md` to collect shell ideas around launch rehearsals, kit cards, pane view cards, cross-pane handoff sheets, and strip/rebind-friendly replay.
- Added `rfcs/0022-viewfs-keep-bundles-view-fragments-and-launch-kits-separate.md` so future proposals must classify whether they are changing grouped authority, namespace templates, live binds, child launch assembly, or only receipt/history surfaces.
- Updated README, changelog, trajectory map, architecture overview, design-splits note, shell protocol sketch, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised021 (2026-03-22)
- Continued online research on retention-vs-cache semantics, explicit hydration/materialization, mirrors, offline bundles, service-worker-style prefetch hints, and object-store warm-up UX.
- Added `docs/30-architecture/pins-caches-prefetch-and-hydration.md` to keep prefetch hints, caches, hydration acts, pins, mirrors, and offline bundles on distinct seams.
- Added `docs/70-shell/offline-readiness-hydration-and-pin-hygiene.md` to collect shell ideas around hydration plans, offline-readiness badges, warm-up trays, bundle lanes, and pin explain flows.
- Added `rfcs/0021-viewfs-keep-pins-caches-prefetch-and-hydration-separate.md` so future design work must classify whether it is changing prefetch, cache, hydrate, pin, mirror, or offline-bundle semantics.
- Updated architecture overview, design-splits note, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised020 (2026-03-22)
- Continued online research on document-picker lane splits, transfer sessions, save-as/create-only flows, move-versus-copy outcome reporting, delete-on-paste protocols, and promised-file drag/drop materialization.
- Added `docs/30-architecture/imports-exports-transfers-and-promised-files.md` to keep import/open/save/move/transfer/share/promise lanes on distinct seams.
- Added `docs/70-shell/shipping-lanes-boundary-previews-and-promised-outputs.md` to collect shell ideas around boundary previews, shipping lanes, move outcome cards, and promise/materialize UX.
- Added `rfcs/0020-viewfs-keep-import-export-transfer-share-and-promises-separate.md` so future proposals must classify whether they are importing, opening in place, saving/exporting, moving, transferring, delegating, or only promising future materialization.
- Updated README, architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised019 (2026-03-21)
- Continued online research on saved-search/smart-folder semantics, query-manifest file formats, snapshot-versus-live-query behavior, index-policy boundaries, and truthful shell UX for result sets.
- Added `docs/30-architecture/query-manifests-result-snapshots-and-live-feeds.md` to keep query recipes, result snapshots, live feeds, smart-folder surfaces, and authority on distinct seams.
- Added `docs/70-shell/smart-folders-freeze-diffs-and-match-lenses.md` to collect shell ideas around freeze/thaw, snapshot diffs, truthful smart-folder badges, and “why did this match?” lenses.
- Added `rfcs/0019-viewfs-keep-query-manifests-snapshots-and-live-feeds-separate.md` so future proposals must classify whether they are changing a query recipe, a result snapshot, a live feed, or only a shell/journal surface.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised018 (2026-03-22)
- Continued online research on conditional writes/deletes, compare-and-swap ref updates, WebDAV lock tokens/timeouts, lease-backed distributed locks, field ownership/conflicts, and stale-write recovery UX.
- Added `docs/30-architecture/leases-preconditions-and-conflicts.md` to keep optimistic preconditions, short leases/reservations, ownership hints, conflict artifacts, and explicit override acts on distinct seams.
- Added `docs/70-shell/reservations-preconditions-and-merge-lanes.md` to collect shell ideas around guarded save, reservation badges, blocked-write explain panels, merge lanes, and force-with-lease style takeover flows.
- Added `rfcs/0018-viewfs-keep-preconditions-leases-and-conflicts-separate.md` so future proposals must classify whether they are changing expected-old guards, create-if-absent semantics, reservations, ownership hints, conflict artifacts, or override acts.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised017 (2026-03-22)
- Continued online research on snapshots, copy-on-write clones, worktree/fork ergonomics, backup/replication streams, boot-environment style rollback, and atomic deployment/pin workflows.
- Added `docs/30-architecture/checkpoints-clones-and-publication.md` to keep checkpoints, writable forks/worktrees, backup streams, publish candidates, and activation targets on distinct seams.
- Added `docs/70-shell/checkpoints-forks-and-time-travel.md` to collect shell ideas around cheap checkpoints, instant forks, truthful time-travel badges, promotion lanes, rollback previews, and “what would I lose?” inspectors.
- Added `rfcs/0017-viewfs-keep-checkpoints-clones-backups-and-publication-separate.md` so future proposals must classify whether they are changing checkpoint, fork, branch/head, replication, publication, or activation semantics.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised016 (2026-03-22)
- Continued online research on trash/recycle behavior, durable recovery metadata, root-based garbage collection, local history/timeline UX, and reflog-style head recovery.
- Added `docs/30-architecture/trash-retention-and-purge.md` to keep remove/unbind, trash entries, recovery history, retention roots, purge eligibility, and purge acts on distinct seams.
- Added `docs/70-shell/trash-trays-retention-lenses-and-undo.md` to collect shell ideas around trash trays, retention-root inspectors, purge previews, restore-plan cards, and explicit undo timelines.
- Added `rfcs/0016-viewfs-keep-trash-retention-and-purge-separate.md` so future proposals must classify whether they are changing a binding/name, a trash entry, a recovery-history entry, a retention root, purge eligibility, or an actual purge act.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised015 (2026-03-21)
- Continued online research on Gatekeeper/quarantine metadata, Mark-of-the-Web, dangerous-download handling, isolated-open precedents, and the ways risky-object UX quietly collapses into trust when a design is careless.
- Added `docs/30-architecture/origin-quarantine-and-trust-transitions.md` to keep origin evidence, quarantine state, safe-open lanes, explicit trust/clear decisions, derivative exports, and live authority on separate seams.
- Added `docs/70-shell/origin-badges-and-safe-open-ladders.md` to collect shell ideas around origin badges, trust ladders, explain-risk panels, receipt cards, and safe-open-first actions.
- Added `rfcs/0015-viewfs-keep-origin-quarantine-and-trust-separate.md` so future proposals must classify whether they are about origin, quarantine, safe-open, trust-clear, derivative artifacts, or live authority.
- Updated architecture overview, SlopOS seam map, inspiration map, bibliography, external-source tracking, trajectory map, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised014 (2026-03-21)
- Continued online research on rooted path resolution, symlink escape restrictions, bookmark/reopen semantics, Shell Links/shortcut retargeting, and shell UX for explicit link classes.
- Added `docs/30-architecture/links-aliases-and-shortcuts.md` to keep live handles, local names, namespace links, durable reopen refs, route/launch shortcuts, and receipt links on separate seams.
- Added `docs/70-shell/link-lenses-breadcrumbs-and-relink.md` to collect shell ideas around link lenses, breadcrumb provenance, dead-link triage, compare-target views, and explicit relink flows.
- Added `rfcs/0014-viewfs-keep-links-aliases-and-shortcuts-separate.md` so future proposals must classify whether they are changing authority, aliasing, durable reopen, route behavior, or only transcript UX.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, context pack, lint requirements, evidence index, and release manifest for the new revision.

## Revised013 (2026-03-21)
- Continued online research on file-watching APIs, recrawl/overflow behavior, persistent change journals, remote-filesystem caveats, and shell UX for live watch panels.
- Added `docs/30-architecture/watchers-notifications-and-rebuilds.md` to keep watch registrations, event feeds, rebuilt snapshots, and watch receipts separate from live authority.
- Added `docs/70-shell/watch-blocks-and-settle-badges.md` to collect shell ideas around watch blocks, scope cards, pulse summaries, settle badges, rebuild actions, and truthful live panes.
- Added `rfcs/0013-viewfs-keep-watchers-and-event-feeds-advisory.md` so future proposals must classify whether they are changing authority, subscriptions, event feeds, rebuilt snapshots, or only transcript UX.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, context pack, lint requirements, evidence index, and release manifest for the new revision.

## Revised012 (2026-03-22)
- Continued online research on preview panes, read-only inspection, Quick Look-style observation sessions, preview-host isolation, notebook rich-output gating, and derived observation artifacts.
- Added `docs/30-architecture/previews-extractors-and-observation-surfaces.md` to keep live authority, observation sessions, derived preview artifacts, and transcript receipts visibly separate in the ViewFS model.
- Added `docs/70-shell/peek-panes-and-inert-inspectors.md` to collect shell ideas around space-to-peek, compare mode, provider badges, authority ladders, preview receipts, and terminal inspector overlays.
- Added `rfcs/0012-viewfs-keep-previews-and-extractors-separate-from-authority.md` so future proposals must classify whether they affect authority, preview/extraction sessions, derived artifacts, or transcript surfaces.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, README, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised011 (2026-03-22)
- Continued online research on workspace trust/restricted mode, per-directory env-hook gating, project security prompts, notebook trust, and shell onboarding UX.
- Added `docs/30-architecture/workspace-trust-and-automation-gates.md` to keep workspace/tree access, inert metadata reading, workspace-defined automation, and user/global automation on distinct seams.
- Added `docs/70-shell/workspace-onboarding-and-trust-badges.md` to collect shell ideas around browse-first project opening, trust badges, automation manifests, reapproval diffs, and user-vs-workspace workflows.
- Added `rfcs/0011-viewfs-keep-workspace-access-separate-from-workspace-trust.md` so future proposals must classify whether they are granting access to a workspace tree or permission to execute workspace-defined automation.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised010 (2026-03-21)
- Continued online research on background indexing, recent-item registries, selector/palette UX, sandboxed metadata extraction, and provenance-rich command palettes.
- Added `docs/30-architecture/indexes-recents-and-selectors.md` to keep indexes, recent-item stores, and selector rows advisory rather than identity- or authority-bearing.
- Added `docs/70-shell/palette-selectors-and-provenance-lenses.md` to collect shell ideas around one powerful omnibox/palette with explicit class badges, provenance peeks, and truthful action states.
- Added `rfcs/0010-viewfs-keep-indexes-recents-and-palettes-advisory.md` so future proposals must classify registries/search surfaces separately from handles, refs, receipts, and names.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised009 (2026-03-21)
- Continued online research on session-state persistence, portal request lifetimes, block/notebook/workflow UX, semantic shell metadata, and truthful replay/rebind behavior.
- Added `docs/30-architecture/session-state-and-authority.md` to keep shell/session memory, pane/workspace restore, notebooks, workflows, and recent-item caches separate from live authority.
- Added `docs/70-shell/journals-notebooks-and-safe-replay.md` to collect ideas around journal blocks, notebook cells, workflow rows, typed palette badges, and safe replay modes.
- Added `rfcs/0009-viewfs-keep-session-state-and-authority-separate.md` so future proposals must classify session state separately from live handles, durable refs, and receipts.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised008 (2026-03-21)
- Continued online research on handle-vs-ref semantics, portal request/response lifecycles, durable reopen failure modes, and shell/terminal UX for authority summaries and receipt cards.
- Added `docs/30-architecture/handles-refs-and-receipts.md` to keep live handles, durable refs, and transcript receipts visibly separate in the ViewFS model.
- Added `docs/70-shell/authority-hud-and-receipt-cards.md` to collect ideas around visible authority HUDs, compact receipt cards, safe transcript sharing, and honest replay/rebind UX.
- Added `rfcs/0008-viewfs-keep-handles-refs-and-receipts-separate.md` so future proposals must classify whether they affect live authority, durable reopen, or audit/transcript artifacts.
- Updated architecture overview, SlopOS seam map, portal lifecycle notes, shell protocol sketch, semantic marks note, inspiration map, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised007 (2026-03-21)
- Continued external research on immutable identity versus mutable heads, durable reopen versus recent-item UX, typed reveal/launch routing, and semantic terminal marks/hyperlink overlays.
- Added `docs/30-architecture/object-identity-recents-and-reveal.md` to keep immutable object refs, local names, durable reopen handles, workspace binds, and reveal/launch routes on distinct seams.
- Added `docs/70-shell/semantic-marks-links-and-overlays.md` to collect protocol-driven shell/terminal ideas around marks, typed object links, inspect overlays, and honest recent-item states.
- Added `rfcs/0007-viewfs-keep-identity-recents-and-reveal-separate.md` so future proposals must classify whether they are about identity, naming, durable reopen, workspace binding, or routing.
- Refreshed architecture overview, SlopOS seam map, shell protocol notes, inspirations, bibliography/review surfaces, assumptions/claims/non-claims, context pack, lint gate, and release manifest for the new revision.

## Revised006 (2026-03-21)
- Continued online research on workspace/tree grants, chooser-versus-transfer durability, URI launch boundaries, typed routing, semantic zones, and shell completion ergonomics.
- Added `docs/30-architecture/workspace-grants-and-rebinding.md` to keep workspace/tree binds separate from single-object open, transfer, durable reopen, and OpenURI launch/reveal.
- Added `docs/70-shell/truthful-completions-and-routing.md` to collect shell ideas around authority-aware completions, stale-grant handling, typed routes, and palette results that preserve object kind and seam.
- Added `rfcs/0006-viewfs-separate-workspace-grants-from-recents-and-openuri.md` so future proposals must classify whether they are opening, rebinding, reopening, transferring, or routing.
- Updated architecture overview, SlopOS seam map, portal grant notes, shell protocol sketch, inspirations, claims/assumptions/non-claims, bibliography, review tracking, context pack, lint requirements, and release manifest for the new revision.

## Revised005 (2026-03-21)
- Continued online research on rooted compat walkers, ambient-authority markers, Linux backstop sandboxing, OpenURI/reveal flows, and shell product ideas that can stay capability-honest.
- Added `docs/30-architecture/host-bridge-and-backstop-posture.md` to separate bring-up tactics such as preopens, `openat2`-style rooted walking, ambient-debt markers, and Landlock from the actual ViewFS semantic core.
- Expanded `docs/30-architecture/portal-grant-lifecycle-notes.md` with grant classes and receipt states so import/open, transfer, save/export, durable reopen, and bound-workspace semantics remain visibly distinct.
- Added `docs/70-shell/shell-super-awesome-moves.md` to collect higher-ambition terminal ideas such as object palettes, authority diffs, receipt trays, route sheets, and safe replay with stripped authority.
- Extended the shell protocol sketch, inspiration map, SlopOS seam map, and architecture overview with the new research.
- Refreshed bibliography, external-source tracking, evidence index, assumptions/claims/invariants/non-claims, trajectory map, roadmap, context pack, lint requirements, and release manifest for the new revision.

## Revised004 (2026-03-21)
- Continued online research on namespace composition, grant durability, revocation costs, explicit rights attenuation, terminal metadata, and workflow UX.
- Added `docs/30-architecture/design-splits-and-non-decisions.md` to keep identity, naming, mutable state, and durable grants intentionally decoupled until evidence justifies otherwise.
- Added `docs/30-architecture/revocation-and-durable-grants-design-space.md` to clarify ephemeral grants, durable reopen, and strong live revocation as separate commitments.
- Added `docs/70-shell/shell-terminal-protocol-sketch.md` so shell/terminal ambition is grounded in explicit metadata rather than screen scraping or hidden ambient state.
- Added `rfcs/0004-viewfs-separate-questions-before-freezing.md` to make future semantic coupling earn its way into the design.
- Updated architecture overview, seam map, inspiration map, claims/assumptions/invariants/non-claims, bibliography, review tracking, evidence index, roadmap, and trajectory map for the new research pass.

## Revised003 (2026-03-21)
- Continued external research on rights attenuation, capability bundles, mutable-over-immutable work state, persistent grant failure modes, and terminal UX patterns.
- Added `docs/30-architecture/mutable-work-state-design-space.md` to capture the main non-POSIX options for editable state without prematurely standardizing one.
- Added `docs/30-architecture/rights-attenuation-and-bundles.md` to pin the idea that rights reduction and bundle grouping must stay explicit and inspectable.
- Added `docs/30-architecture/portal-grant-lifecycle-notes.md` to map open/save/reopen/transfer flows, durable versus ephemeral grants, and the failure lessons from prior ecosystems.
- Added `rfcs/0003-viewfs-open-research-spikes.md` to keep the next experiments narrow, testable, and deliberately non-final.
- Expanded `docs/70-shell/shell-terminal-ideas.md` with visible view badges, authority previews, receipt-aware blocks, terminal domains, and local-first notebooks/workflows.
- Expanded `docs/90-inspirations/inspirations-mapped.md` and the bibliography with new lessons from Capsicum rights, cap-std, Android SAF, Tahoe-LAFS mutable slots, and recent bookmark/persistent-grant cautionary evidence.
- Updated repo hygiene surfaces: release manifest tooling now accepts packaging metadata via environment variables, the context pack includes the new must-read docs, and the REF review register/queue were extended.

## Revised002 (2026-03-21)
- Continued external research on namespace composition, capability grouping, mediated transfer, mutable-over-immutable models, and shell/terminal interaction.
- Added `docs/30-architecture/slopos-seam-map.md` to keep ViewFS aligned with SlopOS datacube surfaces instead of inventing parallel semantics.
- Added `rfcs/0002-viewfs-decision-freeze-and-spike-plan.md` to record which major decisions remain intentionally deferred and which prototypes should answer them.
- Expanded `docs/70-shell/shell-terminal-ideas.md` with ideas around semantic zones, plumb-style routing, command palettes, notebooks, and mediated drag/drop transfer.
- Expanded `docs/90-inspirations/inspirations-mapped.md` with new lessons, especially around grouped capability bundles, transfer portals, mutable overlays over immutable stores, and stable mutable anchors.
- Added a compact `RELEASE-MANIFEST.json` and updated repo tooling/context-pack generation for better datacube hygiene.
- Updated bibliography, external-source head tracking, review queue, claims, assumptions, non-claims, evidence index, roadmap, and trajectory map.

## Revised001 (2026-03-21)
- Seeded the first ViewFS datacube archive with repo hygiene, charter, trajectory map, claim/invariant skeletons, and a first RFC.
- Added architecture notes for:
  - immutable-first object store posture,
  - explicit per-process namespace posture,
  - portal-mediated import posture,
  - path compatibility membrane posture.
- Added a curated inspiration map covering capability systems, namespaces, portals, content-addressed stores, and terminal UX patterns.
- Added a shell/terminal idea file focused on structured pipelines, capability-aware completions, block transcripts, clickable receipts, and multiplexed view domains.
- Added external-source head tracking surfaces for moving-head docs used during design review.
