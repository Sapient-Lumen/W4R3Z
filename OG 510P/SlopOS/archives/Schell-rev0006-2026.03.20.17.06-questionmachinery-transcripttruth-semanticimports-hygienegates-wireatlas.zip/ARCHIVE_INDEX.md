# Archive index

| Bundle | Date | Summary |
| Schell-rev0006-2026.03.20.17.06-questionmachinery-transcripttruth-semanticimports-hygienegates-wireatlas.zip | 2026-03-20 | Research ratchet: sharpened question advancement machinery, added transcript-truth and denial/background prototype surfaces, deepened SlopOS/current-terminal imports, and tightened repo hygiene around head-bundle truth and question-state discipline. |
| --- | --- | --- |
| Schell-rev0005-2026.03.20.16.38-questionratchet-portablecore-protocolsketch-reviewprototype-signalquartz.zip | 2026-03-20 | Research ratchet: advanced key questions into bounded prototype territory, defined the portable text-only core, sketched a minimal shell↔terminal protocol, and tightened repo hygiene around those new surfaces. |
| --- | --- | --- |
| Schell-rev0004-2026.03.20.16.12-rustquestionkernel-hygienepass-semanticterminal-openquestionmachinery-copperglass.zip | 2026-03-20 | Research ratchet: bound Rust as implementation language without freezing the stack, added a question machine and repo-hygiene checks, deepened the SlopOS evaluation, and recorded Rust-side terminal and tooling pressure. |
| Schell-rev0003-2026.03.20.15.58-interactionproof-importlineage-backgroundshelf-reviewcards-signalforge.zip | 2026-03-20 | Research ratchet: deepened SlopOS evaluation, imported more outside shell/terminal/portal lessons, recorded reversible vs expensive commitments, expanded custom-terminal moves, and sharpened the smallest obvious win interaction. |
| Schell-rev0002-2026.03.20.15.44-reviewedactions-decisiondeferral-semanticzones-portalrationale-lampglass.zip | 2026-03-20 | Research ratchet: re-opened SlopOS and DelayBasin, imported a compact move registry, added terminal-semantic candidate moves, preserved decision deferral, and defined the smallest reviewed action Schell should beat bash on. |
| Schell-rev0001-2026.03.20.15.18-commandcontracts-controlledeffects-sessionlineage-evidencebudget-switchyard.zip | 2026-03-20 | Founding Schell revision: command-contract / controlled-effect / session-lineage charter, initial shell RFC spine, archive-control ledgers, bounded SlopOS+DelayBasin assimilation, and release lint. |
