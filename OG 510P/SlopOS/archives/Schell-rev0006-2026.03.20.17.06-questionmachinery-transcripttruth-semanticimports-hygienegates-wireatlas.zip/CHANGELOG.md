# Changelog

## rev0006 — 2026-03-20 17:06 EDT

- re-opened SlopOS and outside shell/terminal/portal/Rust pressure with a bias toward transcript truth and question advancement instead of premature language freeze;
- advanced the question machine by promoting Q-0002 to prototyping, narrowing Q-0006 and Q-0007, and giving Q-0008 a more concrete Rust prototype slice;
- added transcript-truth, denial-card, and background-shelf prototype surfaces so semantic terminal ideas now have portable proof targets;
- deepened the SlopOS evaluation with a third pass focused on what to import as discipline versus what to refuse as premature schema mirroring;
- added a third research synthesis pass and a new ADR requiring question-state movement to correspond to sharper proof artifacts;
- tightened repo hygiene by strengthening archive-index head checks and question-registry validation;
- refreshed receipts, ledgers, context pack, and release bundle.

## rev0005 — 2026-03-20 16:38 EDT

- re-opened SlopOS and the outside shell/terminal/portal landscape with a bias toward reversible imports rather than early lock-in;
- advanced the question machine by promoting Q-0001 and Q-0008 into prototyping, moving Q-0002 into narrowed, and giving Q-0005 a concrete prototype storyboard surface;
- added a first `minimal-portable-core.md` so plain terminals, SSH, transcripts, and headless automation have an explicit Schell truth surface;
- added a first `minimal-semantic-protocol.md` so richer terminals can grow around explicit semantic boundaries without pretending the final protocol is settled;
- deepened the SlopOS evaluation with a second pass focused on why SlopOS wants a new shell and why Schell still needs to stay decision-light;
- tightened repo hygiene by checking context-pack sync, registry surface references, and followthrough/receipt alignment;
- refreshed receipts, ledgers, context pack, and release bundle.

## rev0004 — 2026-03-20 16:12 EDT

- bound Rust as the implementation language while explicitly keeping the implementation stack open;
- added a first-class question machine with durable question states, next proof surfaces, and discharge rules;
- deepened the SlopOS evaluation with a Rust/readiness pass aimed at design-phase discipline rather than premature copying;
- added repo-hygiene and Rust-process guidance so the datacube's release surfaces stay synchronized before code starts growing;
- added Rust-stack research notes for the custom terminal and interaction layer without adopting crates prematurely;
- hardened linting with question-registry and surface-status checks, including a guard against stale release-head surfaces;
- refreshed receipts, ledgers, context pack, and release bundle.

## rev0003 — 2026-03-20 15:58 EDT

- reopened SlopOS and DelayBasin and added a dedicated SlopOS datacube evaluation surface;
- imported more current outside pressure on shells, terminals, portals, and permission UX;
- added an irreversible-decision ledger so reversibility becomes explicit archive law;
- expanded terminal candidate moves with review cards, shelves, marks, and explicit shell↔terminal signaling;
- promoted a clearer statement of the smallest obvious win interaction: exact-artifact open/send with approval and receipt;
- refreshed the revision receipt, followthrough queue, assumption ledger, and foreign-pressure ledger.

## rev0002 — 2026-03-20 15:44 EDT

- re-opened SlopOS and DelayBasin and ratcheted the archive into stronger research mode;
- imported a compact move registry inspired by DelayBasin;
- added a research synthesis and a terminal-semantic candidate-moves surface;
- defined the smallest reviewed action Schell should beat bash on before freezing more syntax.

## rev0001 — 2026-03-20 15:18 EDT

- founded the Schell archive and initial command-contract / controlled-effect / session-lineage spine;
- imported a compact archive-control discipline from SlopOS and DelayBasin;
- emitted the first revision receipt, ledgers, RFC spine, and release bundle.
