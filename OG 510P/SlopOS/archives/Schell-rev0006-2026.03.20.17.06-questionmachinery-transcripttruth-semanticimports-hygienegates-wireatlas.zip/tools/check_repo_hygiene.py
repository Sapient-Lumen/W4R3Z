#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
needed = [
    "QUESTION-REGISTRY.json",
    "docs/00-meta/question-machine.md",
    "docs/00-meta/repo-hygiene-and-rust-process.md",
]
missing = [p for p in needed if not (root / p).exists()]
if missing:
    raise SystemExit(f"repo hygiene surfaces missing: {missing}")

receipt = json.loads((root / "REVISION-RECEIPT.json").read_text())
text = (root / "CHANGELOG.md").read_text()
if receipt.get("revision") not in text:
    raise SystemExit("changelog missing current revision")

print("check_repo_hygiene: ok")
