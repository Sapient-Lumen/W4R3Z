#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
status = json.loads((root / "SURFACE-STATUS.json").read_text())

if status.get("operational_head", {}).get("revision") != manifest.get("revision"):
    raise SystemExit("surface-status operational_head revision mismatch")
if status.get("citation_head", {}).get("revision") != manifest.get("revision"):
    raise SystemExit("surface-status citation_head revision mismatch")
if status.get("status_lanes", {}).get("frozen_public_surface") != manifest.get("bundle"):
    raise SystemExit("surface-status frozen_public_surface mismatch")

print("check_surface_status_sync: ok")
