#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
receipt = json.loads((root / "REVISION-RECEIPT.json").read_text())

for key in ["project", "revision", "timestamp"]:
    if receipt.get(key) != manifest.get(key):
        raise SystemExit(f"receipt {key} mismatch: {receipt.get(key)!r} != {manifest.get(key)!r}")

if not receipt.get("request"):
    raise SystemExit("receipt request missing")

print("check_revision_receipt: ok")
