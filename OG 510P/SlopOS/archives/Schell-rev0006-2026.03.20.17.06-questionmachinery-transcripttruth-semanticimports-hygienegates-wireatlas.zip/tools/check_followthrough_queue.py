#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
queue = json.loads((root / "FOLLOWTHROUGH-QUEUE.json").read_text())
receipt = json.loads((root / "REVISION-RECEIPT.json").read_text())

if queue.get("project") != manifest.get("project"):
    raise SystemExit("followthrough project mismatch")
if queue.get("revision") != manifest.get("revision"):
    raise SystemExit("followthrough revision mismatch")

ids = set()
for item in queue.get("items", []):
    missing = [k for k in ["id", "title", "state", "next_proof_surface", "owner_surface", "origin_revision", "discharge"] if k not in item]
    if missing:
        raise SystemExit(f"followthrough entry {item.get('id')} missing keys: {missing}")
    if item["id"] in ids:
        raise SystemExit(f"duplicate followthrough id: {item['id']}")
    ids.add(item["id"])

for ref in receipt.get("followthrough_refs", []):
    if not ref.startswith("FOLLOWTHROUGH-QUEUE.json#"):
        raise SystemExit(f"unexpected followthrough ref format: {ref}")
    ref_id = ref.split('#', 1)[1]
    if ref_id not in ids:
        raise SystemExit(f"revision receipt references missing followthrough item: {ref}")

print("check_followthrough_queue: ok")
