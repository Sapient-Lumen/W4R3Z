#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
scripts = [
    root / "tools/check_release_manifest.py",
    root / "tools/check_revision_receipt.py",
    root / "tools/check_archive_index.py",
    root / "tools/check_question_registry.py",
    root / "tools/check_followthrough_queue.py",
    root / "tools/check_surface_status_sync.py",
    root / "tools/check_context_pack_sync.py",
    root / "tools/check_registry_surface_paths.py",
    root / "tools/check_repo_hygiene.py",
]
for script in scripts:
    subprocess.run([sys.executable, str(script)], check=True)
print("run_lint_suite: ok")
