#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
pack = json.loads((root / "context-pack.json").read_text())

if pack.get("revision") != manifest.get("revision"):
    raise SystemExit("context-pack revision mismatch")
if pack.get("head_bundle") != manifest.get("bundle"):
    raise SystemExit("context-pack head_bundle mismatch")
for rel in pack.get("read_first", []):
    if not (root / rel).exists():
        raise SystemExit(f"context-pack read_first surface missing: {rel}")

print("check_context_pack_sync: ok")
