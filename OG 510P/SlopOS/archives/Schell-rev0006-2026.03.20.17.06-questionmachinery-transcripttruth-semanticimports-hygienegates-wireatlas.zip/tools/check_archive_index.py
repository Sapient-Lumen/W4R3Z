#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
lines = (root / "ARCHIVE_INDEX.md").read_text().splitlines()
text = "\n".join(lines)

if manifest["bundle"] not in text:
    raise SystemExit("archive index missing bundle row")

first_bundle_row = next((line for line in lines if line.startswith("| Schell-")), None)
if first_bundle_row is None:
    raise SystemExit("archive index has no bundle rows")
if manifest["bundle"] not in first_bundle_row:
    raise SystemExit("archive index head row does not match current bundle")

print("check_archive_index: ok")
