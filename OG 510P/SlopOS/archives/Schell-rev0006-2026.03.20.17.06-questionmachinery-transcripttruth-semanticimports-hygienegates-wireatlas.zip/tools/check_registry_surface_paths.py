#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
registry = json.loads((root / "QUESTION-REGISTRY.json").read_text())
followthrough = json.loads((root / "FOLLOWTHROUGH-QUEUE.json").read_text())

for item in registry.get("items", []):
    for key in ("next_proof_surface", "owner_surface"):
        rel = item.get(key)
        if rel and not (root / rel).exists():
            raise SystemExit(f"question {item.get('id')} missing surface for {key}: {rel}")

for item in followthrough.get("items", []):
    for key in ("next_proof_surface", "owner_surface"):
        rel = item.get(key)
        if rel and not (root / rel).exists() and not rel.startswith(("QUESTION-REGISTRY.json#", "FOLLOWTHROUGH-QUEUE.json#", "IRREVERSIBLE-DECISION-LEDGER.json")):
            raise SystemExit(f"followthrough {item.get('id')} missing surface for {key}: {rel}")

print("check_registry_surface_paths: ok")
