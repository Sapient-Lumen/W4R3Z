#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
registry = json.loads((root / "QUESTION-REGISTRY.json").read_text())

if registry.get("project") != manifest.get("project"):
    raise SystemExit("question registry project mismatch")
if registry.get("revision") != manifest.get("revision"):
    raise SystemExit("question registry revision mismatch")

required = {"id", "title", "state", "question", "why_it_matters", "next_proof_surface", "owner_surface", "boundary", "discharge", "origin_revision", "current_pressure", "accepted_nearby_non_answer"}
allowed_states = {"open", "narrowed", "prototyping", "deferred", "answered", "retired"}
ids = set()
advanced = 0
for item in registry.get("items", []):
    missing = sorted(required - item.keys())
    if missing:
        raise SystemExit(f"question entry {item.get('id')} missing keys: {missing}")
    if item["id"] in ids:
        raise SystemExit(f"duplicate question id: {item['id']}")
    ids.add(item["id"])
    if item["state"] not in allowed_states:
        raise SystemExit(f"question entry {item['id']} has invalid state: {item['state']}")
    if not isinstance(item.get("current_pressure"), list) or not item["current_pressure"]:
        raise SystemExit(f"question entry {item['id']} needs non-empty current_pressure")
    if item["state"] in {"narrowed", "prototyping"}:
        advanced += 1
if not ids:
    raise SystemExit("question registry has no items")
if advanced == 0:
    raise SystemExit("question registry has no narrowed/prototyping questions")

print("check_question_registry: ok")
