#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "RELEASE-MANIFEST.json").read_text())
required = ["project", "revision", "timestamp", "slug", "bundle"]
missing = [k for k in required if k not in manifest]
if missing:
    raise SystemExit(f"missing manifest keys: {missing}")
expected = f'{manifest["project"]}-{manifest["revision"]}-{manifest["timestamp"]}-{manifest["slug"]}.zip'
if manifest["bundle"] != expected:
    raise SystemExit(f'bundle mismatch: expected {expected}, got {manifest["bundle"]}')
print("check_release_manifest: ok")
