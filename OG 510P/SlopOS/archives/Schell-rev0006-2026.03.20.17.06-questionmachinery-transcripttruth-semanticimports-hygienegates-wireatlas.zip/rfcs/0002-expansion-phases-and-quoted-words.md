# RFC 0002: expansion phases and quoted words

## Problem

Shell folklore often depends on half-remembered ordering rules and shell-specific exceptions.

## Proposal

Freeze an explicit phase order for tokenization, quote handling, substitution, splitting, globbing, redirection binding, and envelope finalization. Preserve an expansion trace.

## Consequences

- Better teachability.
- Better fixture design for compatibility tests.
- Early confrontation with heredoc and command-substitution edge cases.

## Open questions

- Which compatibility modes must preserve historical oddities?
- How much trace detail is too expensive for interactive use?
