# RFC 0001: command envelope

## Problem

Traditional shells make it hard to inspect what one command *means* between raw text and launch-time side effects.

## Proposal

Adopt a command envelope as the primary pre-execution shell object. The envelope should preserve raw input, parse structure, expansion trace, argv, redirections, environment delta, builtin intent, effect hints, authority hints, and lineage pointers.

## Consequences

- Better preview and replay surfaces.
- Clearer boundary for assistant annotations.
- Pressure to define redirection and expansion ordering precisely.

## Open questions

- Should the envelope be serialized durably from day one?
- How stable must field names be across revisions?
