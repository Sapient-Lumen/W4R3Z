# RFC 0003: pipeline data and effect lanes

## Problem

Text pipelines hide status, authority, and effect structure that operators increasingly need.

## Proposal

Keep a payload lane for ordinary shell composition while introducing diagnostic, effect, and status lanes as explicit conceptual surfaces. The implementation may begin as sidecar metadata rather than a fully typed transport.

## Consequences

- Better postmortems and safer automation.
- Pressure to model builtins and environment mutation honestly.
- Possible tension with classic shell simplicity.

## Open questions

- Are lanes visible only in receipts, or also interactively?
- Does the payload lane ever become typed?
