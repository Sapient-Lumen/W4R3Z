# RFCs

RFCs are candidate mechanics. Promote them to ADRs only when the project is willing to bind itself.
The archive currently prefers RFCs that either clarify the execution object or define one concrete reviewed interaction to test before more syntax is frozen.
