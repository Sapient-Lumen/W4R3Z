# RFC 0004: Smallest reviewed action

## Status

Research target.

## Summary

Before Schell freezes more language, it should prove at least one reviewed interaction that is:

- easier to understand than a comparable bash flow,
- more honest about authority,
- durable enough to leave a useful receipt,
- and small enough to prototype quickly.

The current best candidate is now specified more concretely in `rfcs/0005-smallest-obvious-win-open-send.md`.

## Why this exists

A shell can become intellectually elegant while still failing real operators.
This RFC keeps the archive focused on proving one humane interaction before expanding syntax, compatibility, or terminal protocol surface.
