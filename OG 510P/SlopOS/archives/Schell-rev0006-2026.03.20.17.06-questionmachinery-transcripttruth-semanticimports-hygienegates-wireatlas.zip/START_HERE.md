# Schell: start here (for maintainers, including LLMs)

Schell is a **shell-design datacube**.

Non-negotiables:

- **Do not collapse syntax into execution.** Parsing, expansion, authority requests, planning, and process launch are distinct stages.
- **Do not let convenience outrun auditability.** History is not enough; preserve command lineage, effect summaries, and revision receipts.
- **Do not treat side effects as text.** Filesystem mutation, environment mutation, network use, terminal control, background presence, and secret access deserve first-class representation.
- **Do not confuse interactivity with ambient authority.** The shell is a control plane, not a blank cheque.
- **Do not freeze the language before proving the interaction.** A custom shell can still fail if its smallest reviewed action feels worse than bash.
- **Do not let archive mass explode.** Ratchet the charter, RFCs, ADRs, ledgers, and question states; quarantine the rest.
- **Do not overpromise typed payloads.** Typed lanes are a live option, not a bootstrap dogma.
- **Do not sever the agent boundary.** Automation may propose, but Schell must preserve who asked, what was approved, and what actually ran.
- **Do not let open questions float as prose.** Every load-bearing uncertainty should have a registry entry, next proof surface, and discharge rule.
- **Do not confuse “Rust chosen” with “stack settled.”** Language choice is fixed; line editor, PTY, terminal rendering, async runtime, and serialization remain open until earned.

## Read first

1. `docs/00-meta/charter.md`
2. `docs/00-meta/trajectory-map.md`
3. `docs/00-meta/move-registry.md`
4. `docs/00-meta/question-machine.md`
5. `docs/00-meta/question-advancement-pass-2026-03-20.md`
6. `docs/00-meta/question-advancement-pass-iii-2026-03-20.md`
7. `QUESTION-REGISTRY.json`
8. `docs/00-meta/repo-hygiene-and-rust-process.md`
9. `docs/00-meta/slopos-datacube-evaluation-pass-iii.md`
10. `docs/00-meta/research-synthesis-2026-03-20-pass-iii.md`
11. `docs/60-platform/minimal-portable-core.md`
12. `docs/80-terminal/transcript-truth-and-zone-persistence.md`
13. `docs/80-terminal/review-flow-prototype.md`
14. `docs/80-terminal/denial-cards-and-rationale.md`
15. `docs/80-terminal/background-shelf-prototype.md`
16. `rfcs/0004-smallest-reviewed-action.md`
17. `rfcs/0005-smallest-obvious-win-open-send.md`
18. `docs/70-automation/agent-boundaries.md`
19. `docs/90-quarantine/open-questions.md`
20. `docs/90-quarantine/questions-we-still-owe-ourselves.md`

## One command

```bash
make lint
```

## What a good revision looks like

A good Schell revision does at least one of these:

- clarifies the command model,
- hardens an authority boundary,
- makes an effect surface more legible,
- converts shell folklore into an explicit contract,
- improves replay and failure diagnosis,
- records a live assumption or deferred obligation honestly,
- advances one question from `open` to `narrowed` or from `narrowed` to `prototyping` with a concrete proof surface,
- preserves a nearby rejected move so syntax does not fossilize too early,
- improves release hygiene or lints so the archive tells the truth about its current head,
- or makes one candidate interaction obviously more humane than bash without widening ambient authority.
- or sharpens transcript truth so semantic terminal features remain portable and auditable.
