# Docs map

- `00-meta/` — charter, trajectory, policy, move registry, question machine, hygiene, and research synthesis
- `10-command-model/` — the command envelope and execution journey
- `20-language/` — syntax, quoting, expansion, and word formation
- `30-runtime/` — pipelines, processes, effects, and control surfaces
- `40-assurance/` — claims, invariants, and failure classes
- `50-session/` — command lineage, receipts, replay, and postmortems
- `60-platform/` — portability profile, compatibility stance, and Rust implementation posture
- `70-automation/` — agent boundary, consent, and automation posture
- `80-terminal/` — semantic terminal moves, transcript truth, review blocks, denial teaching, background shelves, operator affordances, and Rust terminal-stack notes
- `90-quarantine/` — attractive but unearned ideas
