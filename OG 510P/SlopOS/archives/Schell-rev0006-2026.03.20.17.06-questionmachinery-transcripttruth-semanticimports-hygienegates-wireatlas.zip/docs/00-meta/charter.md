# Charter

## Purpose

Schell is a shell-design archive for building a command environment that is:

- **interactive enough** for ordinary terminal work,
- **structured enough** to support inspection and automation,
- **strict enough** to make authority and side effects visible,
- and **portable enough** to grow on conventional Unix-like systems before any exotic runtime ambitions.

## Non-negotiables

1. **Command intent must become a first-class artifact.**
   A command should not leap from raw text straight into process launch without an inspectable intermediate representation.

2. **Expansion is staged, not magical.**
   Quoting, variable expansion, globbing, command substitution, and redirection binding should have an explicit order and failure story.

3. **Side effects deserve lanes, not footnotes.**
   Environment mutation, filesystem writes, network use, secret reads, terminal control, and job control should be representable as effects.

4. **History should grow into lineage.**
   The archive aims beyond “what text did I type?” toward “what was intended, approved, executed, and observed?”

5. **Compatibility is a profile, not a religion.**
   Schell should learn from POSIX and existing shells without inheriting every historical ambiguity as destiny.

6. **Automation must not erase the human.**
   Agent help may draft or suggest, but Schell must preserve who requested, who approved, and what actually ran.

## Initial north-star object

A **command envelope** plus **effect lanes** plus **session lineage** is the founding compression. That is not yet proof that it is the final one.
