# Repo hygiene and Rust process

This archive is still design-heavy, but repo hygiene is already part of the product.
If the datacube lies about its current head, questions, or assumptions, then the future Rust codebase will inherit that confusion.

## Archive hygiene now

Every revision must keep these aligned:

- `CHANGELOG.md`
- `ARCHIVE_INDEX.md`
- `RELEASE-MANIFEST.json`
- `REVISION-RECEIPT.json`
- `SURFACE-STATUS.json`
- `context-pack.json`
- `QUESTION-REGISTRY.json`
- `FOLLOWTHROUGH-QUEUE.json`
- `ASSUMPTION-LEDGER.json`
- `FOREIGN-PRESSURE-LEDGER.json`

`make lint` should fail if those surfaces drift.
The archive index should also name the current bundle as its first live row, not merely mention it somewhere lower in the file.

## Question hygiene

A load-bearing question is not allowed to live only in prose.
If a revision claims a question advanced, it should update at least one of:

- `QUESTION-REGISTRY.json`,
- the question's `next_proof_surface`,
- a followthrough item,
- or an ADR / RFC that explains why the advancement is real.

## Rust hygiene later

When the workspace begins, the minimum expected hygiene is:

- `cargo fmt` for formatting,
- `cargo clippy` for linting,
- dependency-policy checks via `cargo-deny`,
- structured execution/event instrumentation via `tracing`,
- and tests that exercise the reviewed interaction path before chasing breadth.

## Things we should not settle too early

Rust is fixed. The following are not:

- async runtime choice,
- line editor crate choice,
- TUI/rendering stack,
- PTY abstraction,
- serialization format for receipts or execution IR,
- cross-platform support floor,
- whether the terminal is embedded, standalone, or both.

## Process law

A new crate, subsystem, or build-time dependency should usually correspond to one of these:

- a question entering `prototyping`,
- an RFC that now needs an executable probe,
- or a hygiene gain that cannot live purely in the archive.

That keeps the Rust repo from getting ahead of the evidence.


## Transcript hygiene

Once semantic zones and review blocks exist, the archive should preserve a plain-text truth path for them.
A revision that improves rich terminal affordances without improving or at least preserving transcript truth is probably advancing the wrong layer.
