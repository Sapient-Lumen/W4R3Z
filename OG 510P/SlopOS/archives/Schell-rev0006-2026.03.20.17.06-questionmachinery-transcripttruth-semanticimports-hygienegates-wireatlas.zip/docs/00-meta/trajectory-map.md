# Trajectory map

## Phase 0 — archive bootstrap

- Freeze the charter.
- Define the first shell-specific canonical objects.
- Establish release-control surfaces.
- Import a compact move-registry discipline from DelayBasin.
- Make open questions first-class archive objects rather than footnotes.

## Phase 1 — command model and reviewed microinteractions

- Freeze the command envelope.
- Specify parsing and expansion stages.
- Separate payload, diagnostic, and effect lanes.
- Prove at least one reviewed action that feels obviously better than bash.
- Advance the question kernel through narrow proof surfaces rather than broad syntax claims.

## Phase 2 — execution and replay

- Define builtin classes.
- Define process-launch semantics.
- Establish session receipts and replay/postmortem surfaces.
- Separate execution IR from terminal presentation protocol.

## Phase 3 — authority and policy

- Make authority requests explicit.
- Separate inherited ambient power from requested power.
- Add portal- and receipt-shaped review hooks where shell ergonomics can bear them.
- Distinguish background presence from generic job control.

## Phase 4 — terminal semantics and operator tooling

- Define semantic prompt/input/output/review/receipt zones.
- Prototype denial teaching, receipt cards, and background shelves.
- Keep the terminal enhancement layer additive over a portable text baseline.
- Learn which rich affordances are sugar and which are load-bearing for humane review.

## Phase 5 — portability and implementation

- Build the Rust workspace only as fast as the questions earn it.
- Choose compatibility profiles.
- Build a reference interpreter.
- Add test corpora, replay traces, and failure probes.
- Ratchet repo hygiene from archive-only linting into archive + Rust workspace linting.

## Live open questions

- How typed should pipelines become?
- Should capabilities be modeled as shell-native handles or only as annotations over POSIX processes?
- What is the minimum semantic protocol between Schell and its custom terminal?
- What is the smallest authority review that users will tolerate on the hot path?
- Which Rust crates deserve adoption, and which should remain research pressure only?
