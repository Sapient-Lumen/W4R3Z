# Questions we still owe ourselves

These questions are load-bearing because answering them too early would harden the wrong layer.

## Core boundary questions

1. Is Schell the shell language, the review environment, the custom terminal, or the whole operator stack?
2. What is the smallest portable text-only subset that must remain usable over SSH and in transcripts?
3. Which parts of the rich terminal experience are optional sugar, and which are core to humane reviewed execution?
4. How should semantic zones survive remote hops, transcripts, and replay?

## Command-model questions

5. What are Schell's true first-class nouns?
6. Is the minimal command artifact an intent, an envelope, a request, or a stage graph?
7. Do pipelines primarily move bytes, descriptors, tiny records, or multiple lanes at once?
8. Which builtins deserve first-class status, and which should remain external tools?

## Authority questions

9. Which grants should be one-shot by default?
10. What should expiry look like in practice?
11. How much rationale is helpful before it becomes review fatigue?
12. How should denials teach without synthesizing broader authority?

## Compatibility questions

13. Is legacy interop a quarantine lane, a first-class compatibility profile, or a membrane that compiles into reviewed actions?
14. Which legacy shell habits are worth preserving, and which should stay outside the trust core entirely?

## Replay questions

15. What does it mean to replay an action honestly?
16. Can a replay refresh leases while staying semantically “the same” action?
17. Which parts of a receipt are stable identity and which are merely observation?

## Evaluation questions

18. What are the first three operator tasks Schell must beat bash on?
19. How do we measure review burden, mis-execution rate, denial clarity, transcript truth, and recovery quality?
20. What is the first prototype that can falsify the design quickly?
