# Open questions

These are live questions that should remain visible until a revision earns the right to narrow them.

- What is Schell’s minimal execution artifact and how small can it stay?
- Should pipelines have distinct data lanes and effect lanes, or is that an explanatory tool rather than runtime law?
- How much typed structure is enough before the shell becomes an object bureaucracy?
- Which builtins deserve authority-aware treatment in the first prototype?
- Is the custom terminal optional sugar, a power-user path, or part of Schell’s core humane proof?
- How much POSIX compatibility is worth preserving once reviewability becomes the priority?
- What is the clean membrane for legacy command strings and shell scripts?
- How should receipt/replay semantics relate to caching, idempotence, and background execution?
- What is the best first denial-teaching interaction?
- How should semantic zones and receipt/denial boundaries survive into transcripts?
- What is the smallest interaction proof that ordinary users actually prefer?
