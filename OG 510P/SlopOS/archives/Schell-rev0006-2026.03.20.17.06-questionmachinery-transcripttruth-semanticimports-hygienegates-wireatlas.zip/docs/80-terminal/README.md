# Terminal surfaces

These docs keep the custom terminal in research mode.
They name candidate operator moves and protocol pressures without freezing the final shell↔terminal contract.

Read next:

- `minimal-semantic-protocol.md`
- `semantic-terminal-moves.md`
- `review-flow-prototype.md`
- `superawesome-terminal-moves.md`
- `rust-terminal-stack-notes.md`

- `transcript-truth-and-zone-persistence.md`
- `denial-cards-and-rationale.md`
- `background-shelf-prototype.md`
