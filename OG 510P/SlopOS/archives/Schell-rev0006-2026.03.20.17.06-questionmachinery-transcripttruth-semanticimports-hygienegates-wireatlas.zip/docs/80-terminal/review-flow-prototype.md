# Review-flow prototype

This surface upgrades the current “smallest obvious win” candidate from prose into a bounded prototype target.

## Prototype target

**One exact artifact. One exact open/send action. One review card. One approve/deny decision. One durable receipt or denial block.**

## Why this remains the right first proof

- It is small.
- It is authority-bearing.
- It is understandable without knowing the whole shell.
- It can fail in a legible way.
- It is visibly better than ambient pathname launch if done well.

## Minimal operator storyboard

### Step 1 — select exact artifact

The shell identifies one exact artifact.
At bootstrap this may be a stable path plus digest.
Later it may become a stronger object reference.

### Step 2 — assemble review card

The review card should show only the information needed to make a narrow decision:

- artifact identity,
- requested action (`open`, `send`, `handoff`, etc.),
- destination or mediator,
- requested grant scope,
- expected expiry,
- expected receipt handle.

### Step 3 — operator chooses

Allowed choices at bootstrap:

- approve once,
- deny,
- revise scope,
- cancel.

### Step 4 — emit stable outcome block

Success leaves a receipt block.
Failure leaves a denial block.
Both should be replayable / explainable later.

## Text-only success condition

This prototype should already be understandable in a plain terminal transcript.
A richer terminal may add block navigation, previews, and click affordances, but the core proof should survive as text.

## What would falsify this candidate

- users still cannot tell what authority is being asked for,
- the review card is longer or more confusing than the original task,
- denials do not teach anything actionable,
- or the flow feels slower than a bash equivalent without paying back clarity.
