# Superawesome terminal moves

This surface records ambitious terminal ideas that still look compatible with Schell's explicit-review posture.
These are candidates, not commitments.

## 1) Review cards, not just prompts

Effectful actions should render as cards with:

- exact artifact or descriptor identity,
- intended action,
- narrow authority request,
- expiry / one-shot / durable grant posture,
- expected receipt shape,
- and one obvious approve / deny / narrow-further path.

## 2) Receipt shelf and denial shelf

The terminal should make recent receipts and denials navigable objects, not dead scrollback.
A user should be able to jump to:

- last reviewed action,
- last denial,
- last receipt,
- last exported artifact,
- and last background-state change.

## 3) Background shelf instead of `jobs`

Background state should look like a shelf of live grants with:

- request id,
- live-grant truth,
- TTL,
- renew / revoke,
- autostart posture,
- and what changed since the last review.

## 4) Prompt-aware cursor and selection affordances

When the terminal knows where the prompt and editable input are, it can:

- move the cursor by click only where safe,
- select exact command blocks,
- keep complex prompts visually stable,
- and avoid confusing previous output for current input.

## 5) Exact artifact previews

Artifact refs, receipts, digests, and small structured outputs should support inline preview without confusing the preview for authority.
Preview is observational, not a hidden reopen.

## 6) Split transport from luxury UX

The semantic protocol should stay small enough to survive plain terminals and logs.
Richer local affordances like cards, panes, images, and graph views should layer on top without becoming correctness dependencies.

## 7) Make non-effectful work feel fast

The review ceremony must be concentrated where effects or authority matter.
Observational commands, search, history, navigation, and preview should feel very fast.

## 8) Operator memory aids

A strong custom terminal can make continuity much better by keeping visible:

- current focus artifact,
- current lease set,
- current replay target,
- current open review,
- and the currently active question or experiment when working in design/debug mode.

That would make the terminal feel like an operator cockpit rather than just a byte pump.

## 9) Design/debug mode for the shell itself

Because Schell is still being invented, the custom terminal should probably support a design/debug lane that can show:

- which question entry the current prototype is meant to pressure,
- what proof surface is being exercised,
- what receipts/denials were just generated,
- and whether the prototype is still operating inside the intended reversible scope.
