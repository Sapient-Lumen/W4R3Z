# Rust terminal stack notes

This surface records promising Rust-side ingredients for Schell's future terminal and interactive shell work without treating them as committed dependencies.

## Candidate pressure sources

- `reedline` for interactive line editing, completion, hints, multiline input, validation, and external-print support.
- `ratatui` for local receipt shelves, review cards, denial panes, and background shelves.
- `crossterm` for cross-platform terminal control and richer input handling.
- `portable-pty` for PTY experiments when a subprocess-backed compatibility lane becomes necessary.
- `tracing` for structured execution, review, denial, and replay instrumentation.
- `cargo-deny` for dependency-policy hygiene as soon as a Rust workspace appears.

## Current posture

These are **research candidates**, not architectural commitments.
The stack should remain separable:

- editor/input layer,
- semantic shell protocol,
- local rendering layer,
- compatibility/PTY lane,
- and durable receipt/trace layer.

## Current best first slice

The archive now has a stronger bounded guess for the first executable slice:

1. `tracing` for durable lineage,
2. `reedline` for humane text interaction,
3. transcript-preserving plain-text review/receipt rendering first,
4. only then test whether `ratatui` meaningfully improves the first reviewed action.

This keeps the first prototype lighter than a full TUI or terminal-emulator effort.

## What would justify later additions

- adopt `ratatui` when side panes or shelves materially improve the first reviewed interaction,
- adopt `portable-pty` when a compatibility lane becomes necessary,
- adopt `crossterm` more centrally if richer input/event handling becomes load-bearing.
