# Semantic terminal moves

The custom terminal should make Schell feel **more explicit and more humane at the same time**.
This surface records candidate moves that appear promising without yet freezing the protocol.

## 1) Receipt-native output blocks

Every reviewed action should leave behind a stable block with:

- request id,
- intent summary,
- authority summary,
- approval marker,
- receipt or denial id,
- exported artifact refs,
- replay / explain / diff actions.

## 2) Semantic zones

The terminal should distinguish at least these zones:

- prompt,
- user input,
- assistant proposal,
- review card,
- command output,
- denial,
- receipt,
- exported artifact,
- background-grant state.

The exact encoding is deferred, but the direction is clear: no brittle prompt scraping.

## 3) Background shelf instead of `jobs`

For SlopOS-style work, the terminal should show:

- live background grants,
- expiry / TTL,
- autostart bit,
- revoke / renew,
- what was requested vs what is currently granted.

That is more honest than a shell-owned process list.

## 4) Denial teaching

A denial should explain:

- what action was attempted,
- what lease / portal / handle was missing,
- whether the action was observational or effectful,
- whether retry is safe,
- and which narrower next request would likely succeed.

No auto-approval and no hidden widening.

## 5) Exact artifact previews

The terminal should be able to preview:

- exact doc refs,
- digests,
- output receipts,
- structured diffs,
- and small rendered artifacts.

Rich rendering is a bonus layer, not a correctness dependency.

## 6) Fast navigation

Useful default jumps:

- previous / next prompt,
- previous / next reviewed action,
- previous / next denial,
- previous / next receipt,
- jump to last exported artifact,
- jump to last background grant state change.

## 7) High-confidence suggestion UX

Suggestions should be rich but bounded:

- autosuggest text,
- suggest narrower authority,
- suggest replay of last safe action,
- suggest portal-specific next steps,
- never silently widen or execute.

## 8) Portable split

The terminal may be much richer than a plain PTY, but Schell still needs a portable text baseline.
The design rule is:

> richer terminal semantics may improve legibility and speed, but must not be required for correctness.
