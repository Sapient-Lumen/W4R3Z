# MicroVM interrupt-topology posture v0 (no portable ambient guest-visible interrupt topology / irqchip contract)

Purpose: pin the **Phase 1** meaning of guest-visible interrupt topology under `ext.microvm` so APIC/IOAPIC/PIC/GIC controller flavor, irqchip mode, IRQ/GSI/vector numbering, MSI/MSI-X routing, and interrupt-remapping folklore do not quietly become a reviewed lifecycle, portability, or policy surface.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible interrupt topology / irqchip contract under `ext.microvm`; there is no portable APIC-PIC-IOAPIC-GIC controller-model plane, no portable IRQ-GSI-vector-or-MSI-routing plane, owner-local irqchip mode / controller placement / vector allocation / interrupt-remapping policy stay implementation-local, and policy-significant interrupt-topology changes require new admission rather than a live guest-visible rewire plane.**

Entropy cost justification: the archive already pins guest-visible CPU, bus, passthrough, vIOMMU, and lifecycle surfaces, but it still left a quiet gap where real VMMs choose kernel-vs-userspace irqchip placement, controller versions, vector allocation, and remapping modes that guest software can discover and then treat as portable product meaning. One narrow posture closes that gap without inventing a new interrupt-admin API, debugger sideband, or schema family.

## Posture (v0)

1) **No portable ambient guest-visible interrupt topology / irqchip contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible interrupt topology / irqchip contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard interrupt-controller family, one standard irqchip placement mode, or one standard vector-routing inventory that guest software may treat as authoritative platform shape.”
   - In plain terms: the reviewed contract is not “probe APIC/PIC/IOAPIC/GIC details, IRQ numbering, or remapping behavior and learn the authoritative interrupt architecture of this reviewed leaf.”

2) **No portable APIC-PIC-IOAPIC-GIC controller-model plane**
   - Phase 1 standardizes **no portable APIC-PIC-IOAPIC-GIC controller-model plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about which interrupt-controller family or version is present, whether legacy PIC compatibility exists, whether x2APIC-or-equivalent modes are enabled, whether a GIC version or ITS-like adjunct is exposed, or how much of the controller stack lives in kernel space versus userspace.
   - Implementations may locally choose one controller family/version and one placement strategy to match their host/hypervisor/runtime constraints, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed SlopOS interrupt identity meaning.

3) **No portable IRQ-GSI-vector-or-MSI-routing plane**
   - Phase 1 standardizes **no portable IRQ-GSI-vector-or-MSI-routing plane** under `ext.microvm`.
   - That means no reviewed portable semantics for stable pin-IRQ numbering, GSI allocation, vector inventory, MSI/MSI-X routing layout, interrupt-remapping enablement/status, or guest-visible completion/diagnostic APIs for those routing choices.
   - Guest drivers may still use whatever routing model one local runtime exposes, but those route numbers, vector allocations, and remapping behaviors remain implementation-local and must not silently become portable review surfaces or lifecycle promises.

4) **Owner-local irqchip mode, controller placement, vector allocation, and interrupt-remapping policy stay implementation-local**
   - Owner-local irqchip mode, controller placement, vector allocation, and interrupt-remapping policy stay implementation-local.
   - Runtimes may locally choose split irqchip, userspace IOAPIC, one kernel-provided controller model, or one local vector-allocation strategy to hit their security/performance goals, but that does **not** create a portable reviewed promise about one standard injection path, one stable vector numbering discipline, or one transport-independent interrupt contract.
   - In particular, host/runtime decisions about kernel-vs-userspace controller placement, APIC/GIC flavor, interrupt-remapping enablement, and vector reuse remain host/runtime-local mechanism, not portable SlopOS interface meaning.

5) **Resume/migration classes may constrain interrupt details locally without making them portable API meaning**
   - Resume/migration classes may constrain interrupt details locally without making them portable API meaning.
   - A runtime may require one exact controller version or irqchip layout for snapshot/restore, migration, or heterogeneous-fleet normalization, but that requirement stays on owner-local admission/runtime-class evidence rather than becoming a guest-visible portable contract under `ext.microvm`.
   - If policy cares about one exact interrupt-controller class, that belongs on reviewed admission/runtime evidence, not on ambient guest inference from controller flavor or vector behavior.

6) **Changing the interrupt-topology stance is owner-local lifecycle or new admission, not a portable live rewire plane**
   - Changing the interrupt-topology stance is owner-local lifecycle or new admission, not a portable live rewire plane.
   - Owners/runtimes may choose different local controller/routing strategies for different reviewed leaves or deployment classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable interrupt-topology admin protocol under the same admitted identity.
   - If policy cares about a different guest-visible interrupt stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable interrupt-rewire plane by convention.

7) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for interrupt-topology state, **no new ACP kind**, and **no new conflict-key family** for irqchip-mode changes, vector rewrites, interrupt-remapping toggles, or guest-visible route-table mutation under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `query_irq_model`, `set_irqchip_mode`, `route_guest_msi`, `inject_virtual_irq`, or `rebuild_interrupt_topology`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable APIC / PIC / IOAPIC / GIC controller-family-or-version contract under `ext.microvm`.
- No portable IRQ / GSI / vector / MSI-X route inventory or interrupt-remapping-status vocabulary as reviewed SlopOS meaning.
- No generic interrupt-controller debugger, control agent, or live route-table rewrite API.
- No claim that guest-observed controller flavor, vector numbers, or remapping behavior are an attestation substitute or portable lifecycle proof artifact.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
- Adjacent notes:
  - `microvm-bus-topology-posture-v0.md`
  - `microvm-device-passthrough-posture-v0.md`
  - `microvm-virtual-iommu-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-28)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-IRQTOPOLOGY)
- Policy posture:
  - interrupt topology adds **no new lane**, **no public guest interrupt-admin plane**, and **no portable in-place irqchip rewire protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_interrupt_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible interrupt topology / irqchip contract / no portable APIC-PIC-IOAPIC-GIC controller-model plane / no portable IRQ-GSI-vector-or-MSI-routing plane / owner-local irqchip mode-controller placement-vector allocation-interrupt-remapping policy stay implementation-local / resume-migration classes may constrain interrupt details locally without making them portable API meaning / changing interrupt-topology stance is owner-local lifecycle or new admission not a portable live rewire plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-KVM-API.
- REF-QEMU-KERNEL-IRQCHIP.
- REF-CHYP-IRQCHIP.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
