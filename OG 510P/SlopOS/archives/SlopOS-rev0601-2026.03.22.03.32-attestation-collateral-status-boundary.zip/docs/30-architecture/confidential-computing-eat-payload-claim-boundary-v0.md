# D-CC embedded-EAT claim boundary v0 (`eat_payload` stays profile-local evidence, not portable SlopOS claim meaning)

Purpose: pin the **Phase 1** meaning of **embedded EAT claims inside `CH-ATTEST.eat_payload`** so optional EAT bytes do not quietly become a portable SlopOS attestation claim registry, approval language, or hidden replacement for explicit boot/provenance/report-data/freshness checks.

Entropy cost justification: the archive already pinned the first D-CC provider target, one exact binder contract, the SNP certificate/signer/report-field seams, and the closed D-CC companion boundary index. What remained ambiguous was one broad import seam: **`CH-ATTEST v0` intentionally allows optional `eat_payload` bytes, RFC 9711 explicitly frames EAT as a framework/profile mechanism rather than one universal claim set, and RFC 9334 keeps evidence appraisal and relying-party decisions policy-local.** One small boundary closes that seam without inventing a portable EAT claim registry, native verifier-policy language, or privileged parser plane.

## Posture (v0)

1) **`eat_payload` remains optional profile-local evidence bytes, not native D-CC claim space**
   - `CH-ATTEST v0` may carry bounded `eat_payload` bytes.
   - RFC 9711 describes EAT as a **framework** with profile mechanisms for selecting which claims and algorithms matter in a specific use case.
   - Phase 1 therefore treats embedded EAT claims as **optional profile-local evidence only**. They do **not** become native `CH-ATTEST` claims, a portable SlopOS attestation-claim registry, or a reviewed cross-provider policy language.

2) **No embedded EAT claim widens `CH-ATTEST` / `CH-ATTESTPACK` into a portable claim registry**
   - Embedded EAT claims may describe hardware, software, submodules, security state, platform configuration, or other attestation-oriented facts.
   - Those bytes may be useful to one verifier profile.
   - They do **not** create a portable SlopOS rule that a specific EAT claim key, submodule layout, nonce form, profile URI, or nested-token pattern is part of the Phase 1 D-CC claim surface unless a future RFC-first mapping explicitly says so.

3) **Embedded EAT claims do not substitute for `boot_digest`, `prov_digest`, exact `cc_report_data_v0` binding, or freshness**
   - The archive already pins `boot_digest == digest(CH-BOOT)` as the primary portable binding and separately pins the exact `ccbind_input_v0` → `cc_report_data_v0` contract for provider-native report-data carriers.
   - Embedded EAT claims therefore do **not** replace `boot_digest`, optional `prov_digest`, exact binder bytes, or explicit freshness checks.
   - In particular, an embedded measurement, profile identifier, nonce, timestamp, or policy-like claim does not silently override `PO-BOOT-VERIFY`, `PO-ATTEST-VERIFY`, or `PO-ATTEST-FRESH`.

4) **Verifier-local appraisal may inspect embedded EAT claims under explicit profile policy**
   - RFC 9334 assigns evidence appraisal, endorsements, reference values, and appraisal policy to the Verifier / Verifier Owner rather than to the attester.
   - Phase 1 therefore allows a verifier profile to parse/appraise exact EAT bytes under **explicit verifier-local policy**.
   - That still does **not** make those claims portable SlopOS-native truth, default acceptance criteria, or a hidden secret-release / rollout selector for every deployment.

5) **Packaging/export does not upgrade `eat_payload` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry `attest_bytes` whose `eat_payload` embeds EAT claims.
   - If tooling wants to preserve decoded EAT claims for audit or profile-specific verification, it SHOULD do so as exact evidence artifacts or verifier-local derived results rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable EAT-derived claim schema.
   - Exporting embedded EAT bytes does not imply that remote consumers may treat those claims as reviewed SlopOS-native identity, machine-class, release-order, or approval meaning.

6) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one existing optional payload field.
   - It introduces no new ACP kind, no EAT-query interface, no native claim registry, and no portable verifier-policy language.

## Phase 1 non-goals (explicitly deferred)

- No automatic promotion of embedded EAT claims into `CH-ATTEST v0` top-level fields.
- No portable SlopOS registry of approved EAT claim keys, profile URIs, or nested-token conventions.
- No privileged parser behavior for `eat_payload`; privileged code continues to treat it as opaque bytes.
- No new workflow / ACP / conflict-key family for EAT claim discovery, selection, or approval in v0.

## Why this boundary exists

The archive already kept provider parsing out of privileged code, but one broad drift seam remained:
- `CH-ATTEST v0` intentionally allows optional embedded EAT bytes,
- RFC 9711 is designed to support many profiles rather than one canonical cross-domain claim set,
- RFC 9334 keeps evidence appraisal and authorization policy local to verifiers and relying parties,
- and the first cloud/agent verifier path would otherwise be tempted to treat “whatever EAT claim is handy” as portable OS truth.

Without one explicit rule, Phase 1 code would likely drift into one of these by convention:
- treating embedded EAT claim keys as reviewed `CH-ATTEST` extensions without an RFC,
- letting provider-specific EAT profile conventions silently choose verifier or relying-party policy,
- using embedded measurement/version/profile claims as shortcuts around `boot_digest`, `prov_digest`, exact binder bytes, or freshness,
- or widening `CH-ATTESTPACK` into a portable EAT claim registry rather than keeping it an evidence bundle.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, exact `cc_report_data_v0` binding, and explicit freshness semantics**,
- **embedded EAT claims remain profile-local evidence unless explicit verifier-local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a portable EAT-derived claim registry**,
- and **automation cannot inherit a hidden approval or rollout language through optional embedded claims**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation attestation exports may carry profile-specific EAT bytes for remote policy, but workstation semantics stay on explicit `CH-ATTEST` bindings rather than on whichever optional EAT claims a vendor chose to include.
- **Cloud micro-VM substrate (B):** cloud verifiers may parse embedded EAT bytes under explicit local policy, but those claims do not become the portable SlopOS claim surface for hosted compute or secret release.
- **Embedded / separation-kernel-ish appliance (C):** appliance deployments can preserve profile-specific EAT evidence without importing one ecosystem’s token vocabulary as the appliance’s native attestation semantics.
- **Agent / automation OS (D):** agents may inspect profile-specific EAT claims, but they do not get a silent claim-registry/approval shortcut; any such appraisal remains explicit, local, and reviewable.

## Family status (Phase 1)

This doc is a **family member of the closed D-CC companion boundary family** indexed by `confidential-computing-boundary-index.md`.
If future work needs to widen one embedded claim into portable SlopOS meaning, do that by **RFC-first explicit mapping** in the **same revision** rather than by treating this boundary as permissionless extension space.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-BOOT**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `CH-ATTEST` (`attestation-token-schema-v0.md`)
  - `CH-ATTESTPACK` (`attestation-pack-schema-v0.md`)
  - `CH-AREF` (`aref-resolution-posture-v0.md`)
  - `attestation-posture-v0.md`
  - `confidential-computing-boundary-index.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-BOOT-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_eat_payload_claim_boundary.py` (**EVID-2026-549**).

## References

- REF-EAT-RFC9711.
- REF-RATS-RFC9334.
