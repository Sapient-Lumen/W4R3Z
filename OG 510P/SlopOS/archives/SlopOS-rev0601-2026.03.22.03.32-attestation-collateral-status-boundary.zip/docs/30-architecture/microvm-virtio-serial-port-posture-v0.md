# MicroVM virtio-serial/named-port posture v0 (console-adjacent helper channels stay non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible `virtio-serial` / `virtconsole` / named guest-port channels under `ext.microvm` so console-adjacent helper stacks do not quietly become a portable reviewed data / control / helper plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-PLUMB**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible `virtio-serial` / `virtconsole` / named-port contract under `ext.microvm`; there is no portable `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane, owner-local channel naming and host-path wiring stay implementation-local, and reviewed transfer / lifecycle / helper meaning still rides on already-pinned explicit seams rather than ambient guest ports.**

Entropy cost justification: the archive already pins console directionality, host↔guest transports, guest agents, clipboard/drag-drop helpers, and USB redirection individually, but the ecosystem still has one reusable substrate underneath several of those conveniences: `virtio-serial` multiport channels and named guest ports. The virtio console device explicitly supports multiple ports plus a control queue, libvirt exposes named guest channels under `/dev/vport*` and `/dev/virtio-ports/$name`, and common helper stacks such as QEMU Guest Agent default to those ports. One narrow posture closes that gap without inventing a guest-port broker, a naming registry, or a new schema family.

## Posture (v0)

1) **No portable ambient guest-visible `virtio-serial` / named-port contract**
   - **Phase 1 exposes no portable ambient guest-visible `virtio-serial` / named-port contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable extra serial helper bus, one stable named guest-port namespace, or one stable “open this guest port to reach the host/runtime/helper” contract.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those channels do **not** become SlopOS portable API meaning.

2) **No portable `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane**
   - There is **no portable `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable port inventory/status API, one stable control-message vocabulary, one stable guest-path convention, one stable port naming registry, one stable host chardev/socket/path convention, or one stable sideband helper-install contract bound to named guest ports.
   - Owner-local multiport console devices, helper channels, port names, chardev backends, socket paths, and guest-path bindings remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **Owner-local channel naming and host-path wiring stay implementation-local**
   - Owner-local channel naming and host-path wiring stay implementation-local.
   - Runtimes may locally expose plain console ports, helper-specific named ports, SPICE/QGA-style service channels, one-off debugging channels, or no extra guest ports at all for one deployment class, but those choices do **not** create a portable reviewed promise about one guest-visible named-port vocabulary, one host-side endpoint layout, or one status/control API.
   - In particular, deployments may not smuggle “this guest always has `org.qemu.guest_agent.0`-style ports” or “this named port is the reviewed host↔guest helper channel” into portable semantics just because one runtime can wire those channels locally.

4) **Existing explicit seams remain authoritative**
   - Reviewed serial/console meaning still rides on `microvm-console-channel-posture-v0.md` rather than a portable “extra virtio console ports are available for interaction” story.
   - Reviewed guest-management/helper meaning still rides on `microvm-guest-agent-posture-v0.md` rather than a portable named-port contract.
   - Reviewed transfer / clipboard / convenience file movement meaning still rides on explicit `D-PLUMB` seams rather than ambient helper ports or host-side chardev tunnels.
   - Reviewed host↔guest channel posture still stays killable and explicit rather than being reintroduced through “just add another named virtio port” folklore.

5) **Changing the virtio-serial/named-port stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the virtio-serial/named-port stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different helper-channel posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `open_guest_named_port`, `set_port_backend`, `query_guest_ports`, or `bind_helper_channel` control plane by convention.
   - This keeps helper-channel meaning on already-pinned explicit seams rather than on ambient console-adjacent port folklore.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `open_guest_named_port`, `set_port_backend`, `bind_guest_helper_channel`, or `query_port_inventory` must say whether it commutes with activation, console policy, transfer policy, guest-helper policy, and host-channel kill policy, and where serialization lives.
   - Until then, `virtio-serial` helper channels remain owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable `virtio-serial` / `virtconsole` / `virtserialport` contract under `ext.microvm`.
- No portable named guest-port registry, inventory, guest-path, or host-endpoint convention.
- No portable helper-channel install/status API bound to guest ports.
- No claim that named guest ports are an acceptable portable substitute for explicit console, transfer, or guest-management seams.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-PLUMB, D-ACTIVATE)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-console-channel-posture-v0.md`
  - `microvm-guest-agent-posture-v0.md`
  - `microvm-clipboard-dragdrop-posture-v0.md`
  - `transfer-portal-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-41)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-VSERPORT)
- Policy posture:
  - console-adjacent helper channels add **no new lane**, **no portable live named-port plane**, and **no portable helper-port inventory truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_virtio_serial_port_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable `virtio-serial`-named-port contract / no portable `virtio-serial`-`virtconsole`-`virtserialport`-guest-named-port plane / owner-local channel naming and host-path wiring stay implementation-local / explicit console-guest-agent-transfer seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-LIBVIRT-DOMAIN-XML.
- REF-QEMU-GA-DOC.
