# D-CRYPTOSVC attestation boundary v0 (no portable quote / evidence / verifier-policy seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable attestation-evidence, quote/report/token selector, nonce/challenge broker, PCR/claim/input selector, endorsement/certificate-chain fetcher, or verifier-policy/result surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable quote / evidence / verifier-policy seam in v0**
   - Phase 1 does **not** export a portable `quote`, `quote_pcrs`, `report`, `report_data`, `attestation_token`, `attestation_document`, `attestation_certificate_chain`, `attestation_challenge`, `nonce`, `qualifying_data`, `claim_set`, `measurement_selector`, `evidence_format`, `endorsement_fetch`, `attestation_result`, `appraisal_policy`, `verifier_policy`, `freshness_window`, or equivalent attestation knob/result on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - Providers may internally bind a key to local measured state, obtain a TPM quote, retrieve a vendor attestation chain, or pass through deployment-specific evidence helpers, but those details remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret provider-local quote/report generation, evidence-chain retrieval, freshness inputs, or verifier outcomes as requester-visible generic crypto-service truth.

2. **`attest` is bounded key use, not generic remote-attestation workflow**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff plus pinned CH-KEYPOL data, not about standardizing how callers ask for one exact quote format, choose PCR/claim selectors, relay nonces/challenges, fetch endorsement material, or borrow a portable verifier verdict from whichever backend happens to be present.
   - The closed op set may still include `attest`, but in Phase 1 that does **not** imply a portable quote/report schema, nonce/challenge protocol, evidence-format registry, or verifier-policy/result contract on IF-CRYPTOSVC.
   - Portable attestation evidence meaning therefore stays on the explicit **D-ATTEST / CH-ATTEST / CH-ATTESTPACK** surfaces (`attestation-posture-v0.md`, `attestation-pack-schema-v0.md`, `attestation-endorsement-boundary-v0.md`, and `verification-policy-selection-boundary-v0.md`) rather than smuggling attestation workflow semantics into the key-use seam.

3. **Attestation is its own ecosystem workflow, not generic crypto use**
   - Existing ecosystems really do split these surfaces. TPM 2.0 exposes `TPM2_Quote` as its own command with explicit PCR selection and qualifying data. Android key attestation retrieves an attestation certificate chain for a named key rather than treating ordinary key use as generic attestation truth. RFC 9334 likewise separates Evidence, Verifier appraisal policy, and Attestation Results into distinct roles and message flows.
   - Those are valuable product workflows, but they also allocate extra freshness, challenge, evidence-shape, endorsement, verification, and replay semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden quote broker, challenge relay, endorsement fetcher, or verifier-policy oracle.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future attestation-evidence / challenge / verifier-policy seam must state its own conflict keys, commutativity, serialization point, freshness/replay model, challenge provenance, endorsement handling, and evidence plan explicitly rather than inheriting folklore from TPM quote helpers, vendor attestation APIs, or verifier libraries.
   - Until then, generic crypto use remains keyref/route-bound only; quote/report/token selection, nonce/challenge relay, attestation evidence export, and verifier-policy/result semantics stay on explicit D-ATTEST / D-TIME / D-AREF surfaces.

## Phase 1 non-goals (explicitly deferred)

- No portable `quote`, `report`, `attestation_token`, `attestation_document`, `attestation_certificate_chain`, `attestation_challenge`, `nonce`, `qualifying_data`, `measurement_selector`, `evidence_format`, `endorsement_fetch`, `attestation_result`, or equivalent attestation knob/result on generic crypto use.
- No transcript-stable statement that generic key use also returned one exact quote/report/token, verifier verdict, or endorsement chain for the caller.
- No importer-visible remote-attestation protocol folklore on the D-CRYPTOSVC seam.
- No shell/helper fallback that quietly promotes key use into a quote-generation, challenge-relay, or verifier-policy workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “ask the key service for a TPM quote”, “have the provider relay the verifier nonce”, “return whatever attestation certificate chain this backend likes”, or “treat successful `attest` setup as proof that the same backend verified the quote too.” Once those assumptions land in transcripts and automation, they become hard to retract and easy to misuse as ambient evidence or verifier authority. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden remote-attestation control plane. That matters for all four product shapes: workstation UX can still host local attestation tooling without standardizing its challenge/verifier semantics as substrate meaning; hosted and embedded profiles avoid inheriting provider-specific quote/report formats or endorsement chase semantics they do not want in the key-use seam; and agent tooling cannot mistake CH-KEYREF/CH-KEYPOL for permission to ask a backend for portable attestation truth.

## Profile effect (A–D)

- **Secure workstation (A):** local device-attestation or enterprise posture tools may still gather evidence, but generic crypto use does not standardize quote/report formats, challenge relays, or verifier outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting provider-specific quote/report selectors, challenge handling, or endorsement-fetch behavior inside the key-use seam; verifier policy remains explicit in admission/release workflows.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose attestation-protocol or quote-selection APIs they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to request portable quote/report/token evidence, verifier results, or attestation challenge handling; reviewed evidence export stays on explicit D-ATTEST workflows.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/30-architecture/attestation-posture-v0.md`
- `docs/30-architecture/attestation-pack-schema-v0.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_attestation_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable quote / evidence / verifier-policy seam / attest is bounded key use, not generic remote-attestation workflow / attestation is its own ecosystem workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-606**).

## References

- REF-TPM2-PART3-QUOTE.
- REF-ANDROID-KEYATTEST.
- REF-RATS-RFC9334.
