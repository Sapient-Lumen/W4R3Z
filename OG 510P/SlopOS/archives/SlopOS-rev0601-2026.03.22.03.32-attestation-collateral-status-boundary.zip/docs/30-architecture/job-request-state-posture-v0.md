# D-JOBS request-state posture v0 (request key ≠ live scheduled state)

Purpose: close one small but expensive ambiguity on the D-JOBS seam: **a bounded CH-JOBREQ request artifact is not the same thing as current scheduler-owned live job state**.

Several ecosystems keep these truths separate in practice: callers present a stable request/unique-work identifier, while the scheduler still owns whether work is currently enqueued, replaced, cancelled, expired, disabled, or already completed. SlopOS should be at least that explicit.

This doc is intentionally narrow. It does **not** add a new queue-inspection API, a job-inventory surface, or a durable scheduler-state schema. It only freezes what CH-JOBREQ `job_id` does and does not mean in Phase 1.

## Posture (v0)

1) **`CH-JOBREQ.job_id` is requester-chosen request identity, not portal-issued live state**
   - `job_id` is a stable caller-chosen request/job key carried in the request descriptor so retries, replacements, and ACP dedupe have one exact schema-pinned key.
   - It is **not** a portal-issued queue-entry id, not a runtime handle, and not proof that a current enqueued job still exists.

2) **Request presence is not current scheduled-state truth**
   - The existence of CH-JOBREQ bytes (or an old `jobreq_digest`) says only that a bounded request was formed/submitted.
   - It does **not** by itself mean the job is currently pending, still eligible, enabled, unsatisfied, accepted by policy, or awaiting the next trigger window.

3) **Current scheduler-owned state remains portal-local unless a future surface pays for it explicitly**
   - Coalescing, replacement, cancellation, disablement, expiry, last-run bookkeeping, and "still pending?" truth stay inside the `portal.jobs` service boundary in Phase 1.
   - If later work needs portable queue-entry state, cancel tokens, or job-status receipts, it must return RFC-first with its own schema, ordering, receipts, and assurance hooks.

4) **Dedupe/retry safety uses the request key only as a veto-only identity hook**
   - At-least-once-safe `portal.jobs.submit` depends on a stable `CH-JOBREQ.job_id` so duplicate submissions can collapse before effect.
   - That dedupe key is still non-authoritative: it may suppress/reuse/replace according to portal policy, but it never grants scheduling authority by itself.

5) **Historical receipts do not reactivate current requests**
   - A prior CH-ACPOUT / CH-LOG / CH-RECEIPT trail may prove that a request was reviewed or accepted at some point.
   - It does **not** imply that the corresponding job remains currently scheduled after later cancellation, replacement, expiry, policy change, or portal-local cleanup.

## Phase 1 non-goals (explicitly deferred)

- A portable queue-inspection / list-jobs / enumerate-pending-work API.
- A portable job-status receipt or watcher surface proving whether a request is currently pending, enabled, replaced, cancelled, or expired.
- Treating CH-JOBREQ `job_id` as a portal-issued queue-entry identifier or runtime handle.
- Letting historical CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts stand in for current scheduler-owned truth.
- Any hidden policy/query language that asks the portal for ambient “current job state” during ACP validation.

## Why this earns its place

Without this split, the archive quietly collapses two different questions:
- **what exact request did we review/dedupe?**
- **what job state exists right now inside the portal?**

That collapse would make retry safety, receipts, and later automation less honest. Phase 1 can stay small and still refuse the ambiguity.

## Wiring

- Decision surface:
  - `decision-map.md` (D-JOBS)
- Request descriptor:
  - `job-request-schema-v0.md` (CH-JOBREQ v0)
- Portal semantics:
  - `job-portal-posture-v0.md`
  - `portal-family-registry.md`
- ACP automation:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
- RFC / trajectory:
  - `rfcs/0096-job-portal-and-constraint-based-background-work.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (I-JOB-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-JOBS-STATE)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`

CI drift gate:
- `tools/check_job_request_state_posture.py`

## References

- REF-ANDROID-WORKMANAGER.
- REF-APPLE-BGTASKS.
- REF-SYSTEMD-TIMER.
