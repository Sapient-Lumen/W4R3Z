# D-CC SNP guest-policy claim boundary v0 (`POLICY` stays exact evidence; not a portable SlopOS security-profile claim)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `POLICY`** so one provider-native launch-policy bitfield does not quietly become a portable SlopOS attestation claim, security-profile taxonomy, or hidden approval channel.

Entropy cost justification: the archive already pins one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, one SNP guest-mode cut, one owner-launch-identity rule, and one SNP TCB-field rule. What remained ambiguous was narrower and worth deciding now: **SNP attestation reports also carry the launch `POLICY` bitfield, and AMD gives that field concrete provider-specific semantics (`DEBUG`, `SMT`, `MIGRATE_MA`, `SINGLE_SOCKET`, `ABI_*`, etc.), but the archive had not yet said whether those bits become portable SlopOS security-profile meaning**. One small boundary closes that gap without inventing a new schema, verifier DSL, or cross-provider policy taxonomy.

## Posture (v0)

1) **`POLICY` is exact provider-native launch evidence, not a portable SlopOS security-profile claim**
   - AMD’s SNP firmware ABI says the **guest owner provides the guest policy during launch**, the firmware **binds that policy to the guest for its lifetime**, and the attestation report carries that `POLICY` value.
   - Phase 1 therefore treats SNP `POLICY` as **exact provider-native evidence only**. It does **not** become a native `CH-ATTEST` field, a portable SlopOS hardening/profile label, or a reviewed cross-provider “security level” claim.

2) **Provider-specific `POLICY` bits do not define a normalized SlopOS capability or approval language**
   - AMD’s ABI assigns provider-native semantics to bits such as `DEBUG`, `SMT`, `MIGRATE_MA`, `SINGLE_SOCKET`, `CXL_ALLOW`, `MEM_AES_256_XTS`, `RAPL_DIS`, `CIPHERTEXT_HIDING_DRAM`, `PAGE_SWAP_DISABLE`, and the minimum `ABI_MAJOR` / `ABI_MINOR` requirements.
   - Phase 1 preserves those bits as **exact SNP evidence with AMD-defined meaning**.
   - SlopOS does **not** normalize them into a portable capability vector, deployment-class label, or hidden “approved confidential-computing posture” schema.

3) **`POLICY` does not substitute for `boot_digest`, `prov_digest`, or exact `cc_report_data_v0` binding**
   - A verifier MUST still check the already-pinned boot/provenance/report-data binding surfaces separately.
   - Matching or desirable SNP `POLICY` bits do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace freshness binding under `PO-ATTEST-FRESH`, and do **not** redefine which `CH-BOOT` / provenance bundle was actually admitted.
   - In particular, `DEBUG=0`, `SMT=0`, or any other apparent hardening bit MUST NOT be treated as a substitute proof that the attestation binder contract was satisfied.

4) **Guest-policy-derived key semantics do not widen attestation meaning into a policy language**
   - AMD’s ABI allows `MSG_KEY_REQ` to mix `GUEST_POLICY` into a derived key when the guest explicitly selects that field.
   - Phase 1 still treats the report’s `POLICY` field as **exact evidence**, not as a portable claim that one verifier policy or secret-release profile is in force.
   - Using `GUEST_POLICY` in derived-key material therefore does **not** create a normalized SlopOS policy-ID, approval token, or cross-provider secret-release taxonomy.

5) **Any appraisal of `POLICY` remains explicit verifier-local policy**
   - A deployment-specific verifier MAY inspect exact `POLICY` bits and MAY require some local rule such as `DEBUG=0`, `SMT=0`, `MIGRATE_MA=0`, or minimum ABI compatibility.
   - That appraisal remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS default.
   - Different deployments may therefore reject, ignore, or review the same exact `POLICY` value differently without changing the portable D-ATTEST seam.

6) **Packaging/export does not upgrade `POLICY` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `POLICY`.
   - If tooling wants to preserve decoded policy bits for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable SNP policy schema.
   - Exporting an SNP report that carries `POLICY` does not imply that remote consumers may treat those bits as reviewed SlopOS-native policy meaning.

7) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing SNP report field and one already-existing derived-key selector.
   - It introduces no new workflow kind, no serialization surface, and no attester-side policy-query or policy-negotiation plane.

## Phase 1 non-goals (explicitly deferred)

- No `snp_policy` field in `CH-ATTEST v0`.
- No portable confidential-computing “security tier” or approval taxonomy derived from SNP `POLICY` bits.
- No default rule that one exact SNP `POLICY` bitmask is the universally authoritative verifier input.
- No attester-side policy query, policy negotiation, or `IF-ATTEST` selector for SNP `POLICY` values.

## Why this boundary exists

The archive had already fixed the binding, certificate-source, host-field, owner-identity, TCB-field, and guest-mode seams, but one implementation fork remained likely:
- SNP reports carry `POLICY` directly,
- AMD binds that policy at launch and enforces it through the guest lifetime,
- some bits look obviously security-relevant (`DEBUG`, `SMT`, `MIGRATE_MA`, `PAGE_SWAP_DISABLE`),
- and derived-key requests can optionally mix `GUEST_POLICY` into key material.

Without one explicit rule, the first verifier, secret-release harness, or hosted rollout controller would predictably do one of these by convention:
- treat one AMD `POLICY` bitmask as the portable SlopOS “secure guest profile,”
- use `DEBUG=0` or `SMT=0` as a hidden allow/deny language without surfacing local policy,
- or let one provider-native launch bitfield become the de facto cross-provider secret-release taxonomy.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **SNP `POLICY` stays exact evidence unless explicit verifier-local policy says more**,
- **provider-native key-derivation options do not silently become a portable approval language**,
- and **automation cannot inherit a hidden hosted-provider security-profile taxonomy through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact SNP `POLICY` evidence for audit without importing one hosted-provider launch bitfield as a portable workstation hardening profile.
- **Cloud micro-VM substrate (B):** hosted verifiers can make hard decisions such as `DEBUG=0` or migration-agent disallowed, but only under explicit local policy rather than by assuming one SNP bitmask is OS-approved truth by default.
- **Embedded / separation-kernel-ish appliance (C):** imported SNP evidence may retain exact `POLICY` bytes for audit, but appliance posture does not widen into a cross-provider policy taxonomy just because one cloud report carried those bits.
- **Agent / automation OS (D):** agents can inspect exact `POLICY` evidence, but they do not get a hidden approval shortcut; any `POLICY` appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP guest-policy meaning seam.

If a second closely related D-CC SNP guest-policy boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-tcb-field-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_policy_claim_boundary.py` (**EVID-2026-541**).

## References

- REF-AMD-SNP-FWABI.
- REF-RATS-RFC9334.
