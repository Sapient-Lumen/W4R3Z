# MicroVM firmware-description posture v0 (no portable ambient guest-visible ACPI / device-tree / firmware-table contract)

Purpose: pin the **Phase 1** meaning of guest-visible firmware description under `ext.microvm` so ACPI table sets, device-tree node/property vocabularies, and EFI/firmware-table folklore do not quietly become a reviewed hardware-description, policy, or bootstrap surface.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible firmware-description contract under `ext.microvm`; there is no portable ACPI-table-set / device-tree-node-property / EFI-configuration-table hardware-description plane, owner-local firmware-description mechanism stays implementation-local, and changing that stance still means owner-local lifecycle handling or a new reviewed admission rather than a live guest-visible retable/update protocol.**

Entropy cost justification: the archive already pins guest-visible bus, interrupt, lifecycle, and platform-identity seams, and it already keeps bootstrap metadata out of the portable contract. What remained underspecified was the deeper firmware-description layer underneath those choices: modern VMMs variously boot guests with ACPI tables, generated DTBs, or firmware-mediated EFI configuration tables, and guest software can start treating whatever it probes there as “the” authoritative reviewed platform contract. One narrow posture closes that gap without inventing a firmware agent, table override API, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible firmware-description contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible firmware-description contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard ACPI table set, device-tree layout, EFI configuration-table inventory, or firmware namespace that guest code may treat as authoritative hardware description.”
   - In plain terms: the reviewed contract is not “probe ACPI / DT / EFI tables and learn one portable SlopOS machine model.”

2) **No portable ACPI-table-set / namespace / AML hardware-description plane**
   - Phase 1 standardizes **no portable ACPI-table-set / namespace / AML hardware-description plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about one exact DSDT/SSDT/FADT/MADT/SPCR vocabulary, ACPI namespace path, `_HID` / `_UID` / `_CRS` / `_DSD` convention, or AML-defined control-method contract beyond the already-pinned lifecycle, bus, interrupt, and identity postures.
   - Implementations may locally generate, omit, or revise ACPI tables to satisfy one runtime, architecture, or firmware path, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed SlopOS hardware-description meaning.

3) **No portable device-tree-node-path / compatible-property / phandle hardware-description plane**
   - Phase 1 standardizes **no portable device-tree-node-path / compatible-property / phandle hardware-description plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about one exact DTB node tree, `compatible` vocabulary, `chosen` / `stdout-path` / bootargs conventions, phandle graph, or fixed node-path/property naming as the authoritative portable hardware contract.
   - Implementations may locally generate or pass DTBs for direct kernel boot or bare-metal style guests, but those choices remain implementation-local and must not silently become the portable SlopOS machine-description vocabulary.

4) **No portable EFI-configuration-table / firmware-table inventory plane**
   - Phase 1 standardizes **no portable EFI-configuration-table / firmware-table inventory plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about one exact EFI configuration-table population, firmware-mediated publication of ACPI/DT hardware-description blobs, or stable firmware-table inventory that guest software may treat as the reviewed microVM ABI.
   - Implementations may locally direct-boot a kernel, boot via firmware, publish ACPI through EFI, or mix those paths for one deployment class, but those choices remain implementation-local and must not silently become portable SlopOS interface meaning.

5) **Owner-local firmware-description mechanism stays implementation-local**
   - Owner-local firmware-description mechanism stays implementation-local.
   - Runtimes may choose ACPI on one architecture, generated DTBs on another, direct kernel boot for one deployment class, or firmware/UEFI boot for another, but that does **not** create a portable reviewed promise about one standard firmware-description mechanism or one guest-visible table vocabulary.
   - In particular, table generation, AML contents, DTB layout, EFI publication path, and firmware choice remain host/runtime-local mechanism, not portable SlopOS interface meaning.

6) **Already-pinned bus / interrupt / lifecycle / identity seams still carry the reviewed meaning**
   - The already-pinned bus, interrupt, lifecycle, bootstrap-metadata, and platform-identity seams still carry the reviewed meaning.
   - If a guest-visible property matters portably, it must already be spelled out on those explicit seams rather than inferred from one ACPI namespace path, one DT node path, one EFI table, or one firmware-specific probe result.
   - Firmware-description bytes may be necessary boot mechanism for one implementation, but they do **not** become the portable authority seam for topology, lifecycle, trust, or policy decisions.

7) **Changing the firmware-description stance is owner-local lifecycle or new admission, not a portable live retable plane**
   - Changing the firmware-description stance is owner-local lifecycle or new admission, not a portable live retable plane.
   - Owners/runtimes may choose different local firmware-description mechanisms for different reviewed leaves or upgrade classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable firmware-table update/override protocol under the same admitted identity.
   - If policy cares about a different firmware-description stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable table override or live re-enumeration plane by convention.

8) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest firmware-description state, **no new ACP kind**, and **no new conflict-key family** for table override, DT patching, firmware-table query, or live firmware-description updates under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `query_firmware_tables`, `override_acpi_table`, `patch_dtb`, or `switch_boot_firmware_mode`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable ACPI table-set / namespace / AML control-method contract under `ext.microvm`.
- No portable DTB node-path / `compatible` / property vocabulary as reviewed SlopOS hardware-description meaning.
- No portable EFI configuration-table / firmware-table inventory or override plane.
- No generic guest firmware broker, table patcher, or live firmware-description update API.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
- Adjacent notes:
  - `microvm-bootstrap-metadata-posture-v0.md`
  - `microvm-bus-topology-posture-v0.md`
  - `microvm-interrupt-topology-posture-v0.md`
  - `microvm-lifecycle-signal-posture-v0.md`
  - `microvm-platform-identity-posture-v0.md`
  - `microvm-firmware-state-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-31)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-FWDESC)
- Policy posture:
  - firmware description adds **no new lane**, **no public guest firmware admin plane**, and **no portable in-place table override/update protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_firmware_description_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible firmware-description contract / no portable ACPI-table-set-device-tree-node-property-EFI-configuration-table hardware-description plane / owner-local firmware-description mechanism stays implementation-local / already-pinned bus-interrupt-lifecycle-identity seams still carry the reviewed meaning / changing firmware-description stance is owner-local lifecycle or new admission not a portable live retable plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-ACPI-X86.
- REF-QEMU-ARM-VIRT-DTB.
- REF-CHYP-BOOT-FIRMWARE.
- REF-CHYP-ARM64-ACPI-UEFI.
- REF-LINUX-ACPI-ARM.
