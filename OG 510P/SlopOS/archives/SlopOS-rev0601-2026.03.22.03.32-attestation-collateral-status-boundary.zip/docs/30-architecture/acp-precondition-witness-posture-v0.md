# ACP precondition-witness posture v0 (exact witness gates; no ambient queries)

Purpose: close one small but load-bearing seam in **CH-ACP v0**.
`preconditions` exists so a proposal can say “apply this only if the reviewed basis still matches,” but that field must not turn into a hidden query language, a mutable "latest" lookup, or a second policy engine.

This doc keeps the seam narrow: ACP preconditions are **veto-only exact witness gates** over explicit local inputs.

## Posture (v0)

1) **Preconditions are veto-only**
   - `preconditions` may only **narrow or deny** acceptance.
   - They MUST NOT grant authority, widen a capability, substitute for CH-AUTHZ, or act as a second approval channel.

2) **The reviewed/observed basis must be exact**
   - If a proposal depends on reviewed or observed state, the dependency MUST be expressed against **exact local witness material** already named on the action surface or available to the validator as explicit local state.
   - Admitted basis material is intentionally narrow: canonical action bytes, exact descriptor digests, typed local identifiers, explicit revision/epoch counters, and validator-owned local state that already has a reviewed semantics surface.
   - Human prose, issue comments, transient UI status, tool chatter, mutable document heads, and vague selectors like **ambient `latest`**, `current`, or `whatever is in the queue now` do **not** count as precondition basis.

3) **Evaluation inputs are local and non-ambient**
   - Validators may evaluate preconditions only from explicit local inputs already in scope for validation.
   - No remote fetch, ambient database lookup, filesystem walk, search query, history scrape, or connector discovery step is allowed merely because a precondition was present.

4) **The precondition language stays closed and bounded**
   - Phase 1 admits only a small, mechanically checkable class of gates such as exact equality / mismatch, bounded closed-enum membership, explicit existence / non-existence, or bounded version / epoch comparisons.
   - Phase 1 does **not** add a general predicate VM, free-form query language, regex/search surface, or policy-language embedding under `preconditions`.

5) **Missing or stale witness material fails closed**
   - If the required witness cannot be resolved from explicit local inputs, or if the witness no longer matches, validation MUST deterministically deny.
   - Recommended denial surface: `CH-DENY` with `deny_code = "precondition-failed"`, binding the rejecting witness digest when one exists.

6) **Witnesses are not a history or approval plane**
   - Exact witness binding prevents folklore about what was reviewed, but it does not create a reusable review cache, a `latest approved basis` registry, or a portable history/query plane.
   - If the archive later needs a reusable reviewed-basis artifact or a richer predicate language, that must return as its own RFC-first surface.

## Phase 1 non-goals (explicitly deferred)

- No new `CH-*` schema family for generic predicate programs or query ASTs.
- No ambient `latest head`, `current review`, `current status`, or remote-source freshness lookup inside IF-ACP.
- No hidden embedding of a full policy engine under CH-ACP `preconditions`.
- No portable review-thread / queue / history surface created indirectly through witness reuse.

## Wiring

- Decision surface: `decision-map.md` (D-LLM / IF-ACP adjacency).
- Proposal posture: `llm-operations-posture-v0.md`.
- Action wire shape: `docs/70-llm-control/acp-action-schema-v0.md`.
- Validator semantics: `docs/70-llm-control/acp-validator-semantics.md`.
- Denial registry: `deny-code-registry.md`.
- Assurance anchors: `docs/20-assurance/invariant-registry.md` (**I-ACP-PRECOND-1**) and `docs/20-assurance/proof-obligation-registry.md` (**PO-ACT-PRECOND**).
- CI drift gate: `tools/check_acp_precondition_wiring.py` (EVID-2026-555).

## References

- REF-MACAROONS-NDSS14
- REF-DTRACE-PREDICATES
- REF-CEDAR
