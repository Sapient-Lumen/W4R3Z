# D-INHIBITLEASE posture v0 (close-to-release; no durable carryover)

Purpose: pin an **implementable Phase 1** meaning for D-INHIBITLEASE so “keep the session awake / delay this transition” stays a small, reviewable workflow rather than drifting into persistence, scheduling, or hidden power-policy authority.
It narrows the inhibit seam for the workstation shape and the sessionful edge of the agent shape without inventing a general power manager.

This doc is intentionally narrow: it does **not** design a full power policy engine, a cron-like wakeup scheduler, or a durable persistence channel.

## Posture (v0)

1) **No ambient inhibit constructors**
   - If D-INHIBITLEASE is enabled, post-init components obtain transition inhibition only via `portal.inhibit`.
   - There is no ambient keep-awake syscall, library API, or hidden per-user power hook after init.

2) **Leases are live, close-to-release, and current-session scoped**
   - Phase 1 inhibition is a **live lease handle**, not a durable registration.
   - Closing the handle releases the inhibition deterministically.
   - Process death, holder disconnect, session end, reboot, or portal-enforced expiry MUST release the inhibition fail closed.
   - Phase 1 does **not** support future-dated, reboot-spanning, or login-carried inhibit records.

3) **Delay-by-default for apps; block remains reserved**
   - `delay` is the default app-facing posture: a bounded grace period to finish/save/flush before idle, suspend, logout, or shutdown proceeds.
   - `block` / `block_weak` remain reserved for privileged or system-owned components under explicit policy.
   - Long-lived app-visible inhibits should therefore be exceptional, attributable, and reviewable.

4) **Inhibit is not persistence and not scheduling**
   - D-INHIBITLEASE is for **active transition protection while work is underway**, not for “please keep running later” or “wake me up at a specific time.”
   - Phase 1 explicitly says **prefer D-JOBS** for deferred work and **D-BGLEASE** for durable background presence.
   - A job MAY borrow a short inhibit only while a run is actively executing; it MUST NOT pre-arm a future inhibit or accumulate keep-awake debt after downtime.

5) **Visibility and transcript are part of the contract**
   - Grants, renewals, and releases are transcript-visible.
   - Long-lived or high-impact inhibits imply a user-visible indicator/status surface in profiles that ship interactive UX.
   - CH-INHIBITLEASE exports SHOULD remain redacted/hash-only in strict profiles unless detailed export is explicitly justified.
   - Historical CH-INHIBITLEASE descriptors remain exact grant-bounds evidence rather than a portable “still inhibiting now” oracle (`lease-descriptor-state-boundary-v0.md`).

6) **Composition stays honest**
   - An inhibition lease does **not** imply network, file, device, capture, notification, background/autostart, or volition-bypass authority.
   - Those remain separately portalized/leased and policy-killable.
   - The seam stays fail-closed behind `cfg.params.lane.portal.inhibit`.

7) **No new ACP automation surface in Phase 1**
   - `portal.inhibit.*` remains **manual-only v0**.
   - This posture introduces **no** CH-ACP kind, conflict-key family, or ordering-token family.
   - Serialization remains inside `svc:portal.inhibit`; any future automation surface requires an RFC first.

8) **Sealed compat remains killable and non-ambient**
   - Foreign-cell or compat runtimes do not get their own ambient keep-awake channel.
   - Any legacy inhibit interop must route through explicit adapters and `portal.inhibit`, and remains policy-killable.

## Phase 1 non-goals (explicitly deferred)

- **Persistent or reboot/session-carried inhibits**.
- **Future-dated “wake/keep-awake later” scheduling**.
- **Background/autostart reacquisition loops** that silently recreate inhibits after user absence or restart.
- **An ACP kind for inhibit automation** or exact-wakeup compat semantics.
- **A general power-policy service** embedded into the privileged core.

## Wiring

- Decision surface: `decision-map.md` (D-INHIBITLEASE).
- Schema:
  - `inhibit-lease-schema-v0.md` (CH-INHIBITLEASE v0)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.inhibit.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.inhibit`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-INHIBIT-1, I-INHIBIT-2, I-INHIBIT-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-INHIBIT-VALIDATE, PO-INHIBIT-ENF)

CI drift gate:
- `tools/check_inhibitlease_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “close-to-release / no durable carryover / manual-only / not persistence-or-scheduling” constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-INHIBIT.
- REF-SYSTEMD-INHIBITOR-LOCKS.
- REF-SYSTEMD-INHIBIT-MAN.
- REF-ANDROID-WAKELOCK.
- REF-ANDROID-SET-WAKELOCK.
