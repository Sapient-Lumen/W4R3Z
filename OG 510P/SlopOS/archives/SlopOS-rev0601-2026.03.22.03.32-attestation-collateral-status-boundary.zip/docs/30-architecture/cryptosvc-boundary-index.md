# D-CRYPTOSVC companion boundary index (v0)

Purpose: keep the **closed set of D-CRYPTOSVC / D-AUTHAGENT companion boundary docs** enumerable.

Why this exists:
- the archive now pins multiple small crypto-authority meaning seams so IF-CRYPTOSVC does not quietly regrow into a second agent API, a hidden key-browser/query plane, a transparent forwarding convention, a provider/slot/token chooser surface, a hidden interactive-auth broker, a hidden mechanism/capability-discovery plane, a hidden secret-bearing key-material interchange plane, a hidden key-lifecycle/admin plane, a hidden attestation/evidence plane, or a hidden verification/trust-evaluation plane,
- those boundary docs are individually crisp but easy to forget piecemeal because they span provider-role shape, inventory/search hygiene, cross-boundary delegation, backend-selection semantics, interactive-auth hygiene, mechanism/capability hygiene, secret-bearing key-material hygiene, lifecycle-admin hygiene, derive-result hygiene, attestation/evidence hygiene, and verification/trust-evaluation hygiene,
- `cryptosvc-posture-v0.md` keeps the overall Phase-1 meaning of D-CRYPTOSVC, while this index is the **discovery surface** that says which companion boundaries currently keep crypto authority explicit-route, keyref-bound, and small.

This doc does **not** add a new schema, provider API, or workflow family.
It is an entropy-reducing companion to `cryptosvc-posture-v0.md`, `secret-authority-adjunct-index.md`, and RFC-0067.

## Posture (v0)

1. **Closed family, not adjacent singleton folklore**
   - The current D-CRYPTOSVC / D-AUTHAGENT companion boundaries are treated as one closed recovery surface, not neighboring facts readers are expected to rediscover manually.
2. **Entropy reduction only**
   - This index does not widen IF-CRYPTOSVC, add a provider-management API, or invent a new schema/ACP/receipt family; it just keeps the already-accepted crypto-authority cuts enumerable together.
3. **Same-revision family maintenance**
   - Future crypto-authority boundary growth must either attach to this family in the same revision or justify a different explicit discovery surface in the same revision.

## Phase 1 non-goals (explicitly deferred)

- No generic provider inventory/search/control plane.
- No portable token/session/reader/backend selection API.
- No portable PIN / biometric / presence / unlock workflow or auth-state API.
- No portable mechanism / algorithm-capability / padding-mode discovery/tuning API.
- No portable secret-bearing key import/export / backup-restore / escrow API.
- No portable key generation / rotation / deletion / lifecycle-admin API.
- No portable derive-bits / wrap-unwrap / derived-material export API.
- No portable quote / report / token / nonce-challenge / attestation-verifier-policy API.
- No portable verify / certificate-path / trust-store API.
- No hidden forwarding, admin, or lifecycle family smuggled through this index.
- No second auth-agent protocol/socket surface beside IF-CRYPTOSVC.


## Inclusion rule

A doc belongs here if it removes exactly one tempting D-CRYPTOSVC / D-AUTHAGENT meaning widening from Phase 1 by constraining one of:
- caller-visible API splitting that would otherwise turn “auth agent” into a second portable socket/protocol/inventory seam beside IF-CRYPTOSVC,
- cross-boundary forwarding/delegation semantics that would otherwise smuggle ambient forwarded-agent behavior into explicit crypto authority,
- provider-global key inventory/search/query semantics that would otherwise let key use depend on portable alias lists, certificate searches, or metadata queries instead of explicit CH-KEYREF / route handoff,
- provider/backend/slot/token/session selection semantics that would otherwise let key use depend on a portable backend chooser or token-management vocabulary instead of explicit CH-KEYREF / route handoff,
- interactive unlock/presence semantics that would otherwise let key use depend on a portable PIN / biometric / presence / auth-state vocabulary instead of explicit approval policy and provider-local trusted UI,
- mechanism/capability discovery or caller-tunable algorithm-profile semantics that would otherwise let key use depend on a portable mechanism list, provider-property query, or padding/mode/hash/curve vocabulary instead of explicit CH-KEYPOL / route handoff,
- secret-bearing key-material import/export or backup/restore semantics that would otherwise let key use depend on a portable PEM/JWK/PKCS#8/blob/escrow vocabulary instead of explicit CH-KEYREF / route handoff,
- key generation/rotation/deletion or lifecycle-admin semantics that would otherwise let key use depend on a portable create/rotate/delete/alias-retarget/default-key vocabulary instead of explicit CH-KEYREF / route handoff,
- derived-material shaping or wrap/unwrap/export semantics that would otherwise let key use depend on a portable raw-secret, deriveBits/deriveKey, wrapped-key, or importable-derived-key vocabulary instead of explicit CH-KEYPOL / route handoff,
- attestation-evidence / challenge / verifier-policy semantics that would otherwise let key use depend on a portable quote/report/token selector, nonce relay, evidence-format vocabulary, endorsement retrieval, or verifier verdict instead of explicit D-ATTEST / CH-ATTEST / CH-ATTESTPACK workflows,
- verification / certificate-path / trust-store semantics that would otherwise let key use depend on a portable verifier verdict, best-chain search, trust-root vocabulary, or revocation policy instead of explicit D-SIGENV / D-KEYLESS workflows.

If future work needs a native provider inventory/search surface, portable backend/reader/token selection surface, token unlock/lifecycle/admin plane, portable biometric/presence workflow, portable mechanism/property discovery surface, portable secret-bearing key import/export or backup/restore surface, portable key generation/rotation/deletion surface, portable derived-secret/wrap-unwrap/export surface, portable attestation/challenge/evidence surface, portable verification/trust-store surface, or richer cross-domain forwarding broker instead, that work must return **RFC-first** as its own decision surface rather than hiding behind IF-CRYPTOSVC convenience semantics.

## Closed companion boundary set (Phase 1)

### 1) Auth agent remains a provider role, not a second caller-visible API

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`authagent-provider-role-boundary-v0.md`](authagent-provider-role-boundary-v0.md) | auth-agent-vs-crypto-service surface split | if a key-holding auth agent exists, it is realized behind IF-CRYPTOSVC / D-CRYPTOSVC rather than as a second portable protocol/socket/inventory seam | future RFC-first provider-management/admin surface if ever needed |

### 2) Cross-boundary use stays explicit and attenuated

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-forwarding-boundary-v0.md`](cryptosvc-forwarding-boundary-v0.md) | forwarding / remote-hop / compat delegation semantics | cross-domain or compat key use may happen only through explicit narrowed routes that preserve-or-tighten CH-KEYPOL constraints; no transparent forwarded-agent seam | future RFC-first delegated crypto workflow if ever needed |

### 3) Key use does not become key inventory / alias-listing / certificate search

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-inventory-boundary-v0.md`](cryptosvc-inventory-boundary-v0.md) | provider-global key/certificate inventory, alias listing, and metadata query semantics | callers hold explicit key refs/routes; they do not list aliases, enumerate provider-held identities, or search certificate/key metadata on the portable seam | future RFC-first provider inventory / chooser surface if ever needed |

### 4) Key use does not become provider / slot / token / backend selection

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-provider-selection-boundary-v0.md`](cryptosvc-provider-selection-boundary-v0.md) | provider/backend/slot/token/reader selection semantics | callers hold explicit key refs/routes; they do not pick KSP/CSP/provider names, PKCS#11 slots/tokens/sessions, smartcard readers, or hardware-backend knobs on the portable seam | future RFC-first provider-selection / token-management surface if ever needed |

### 5) Key use does not become PIN / biometric / presence / unlock workflow

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-interactive-auth-boundary-v0.md`](cryptosvc-interactive-auth-boundary-v0.md) | token unlock / PIN / biometric / presence / auth-state semantics | callers hold explicit key refs/routes and approval policy, but they do not pick prompt modality, query cached unlock state, or drive provider login/presence workflows on the portable seam | future RFC-first interactive-auth / token-unlock workflow if ever needed |

### 6) Key use does not become mechanism discovery / algorithm-profile tuning

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-mechanism-boundary-v0.md`](cryptosvc-mechanism-boundary-v0.md) | mechanism enumeration / provider-property query / padding-mode-hash-curve tuning semantics | callers hold explicit key refs/routes and pinned policy, but they do not list token mechanisms, read provider algorithm properties as portable truth, or negotiate caller-chosen padding/mode/hash/curve profiles on the portable seam | future RFC-first crypto-profile / provider-capability workflow if ever needed |

### 7) Key use does not become secret-bearing key import/export / backup-restore / blob interchange

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-key-material-boundary-v0.md`](cryptosvc-key-material-boundary-v0.md) | secret-bearing key import/export / backup-restore / escrow / migration-blob semantics | callers hold explicit key refs/routes and pinned policy, but they do not load or dump PEM/JWK/PKCS#8/PFX/private-key blobs, request escrow/backup artifacts, or expect provider-bridge migration objects as generic crypto-use seam truth | future RFC-first key-lifecycle / provisioning / recovery workflow if ever needed |

### 8) Key use does not become key generation / rotation / deletion / lifecycle-admin

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-key-lifecycle-boundary-v0.md`](cryptosvc-key-lifecycle-boundary-v0.md) | key generation / alias rollover / default-key replacement / delete-archive-revoke semantics | callers hold explicit key refs/routes and pinned policy, but they do not ask IF-CRYPTOSVC to mint new key objects, rebind durable aliases, replace default keys, or delete/archive/revoke provider-held keys as generic crypto-use seam truth | future RFC-first provisioning / rotation / recovery workflow if ever needed |

### 9) Key use does not become derive-bits / wrap-unwrap / derived-material export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-derived-material-boundary-v0.md`](cryptosvc-derived-material-boundary-v0.md) | raw shared-secret / deriveBits-deriveKey / wrap-unwrap / export-result semantics | callers hold explicit key refs/routes and pinned policy, but they do not receive portable raw shared secrets, wrapped-key blobs, or importable derived key objects as generic crypto-use seam truth | future RFC-first derived-secret / key-wrap / provider-lifecycle workflow if ever needed |

### 10) Key use does not become quote/report/token evidence / challenge relay / attestation policy

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-attestation-boundary-v0.md`](cryptosvc-attestation-boundary-v0.md) | quote/report/token selection / nonce-challenge relay / evidence-format / endorsement-fetch / attestation-verifier-policy semantics | callers hold explicit key refs/routes and pinned policy, but they do not ask IF-CRYPTOSVC for portable quote selectors, challenge relays, endorsement chains, or verifier verdicts as generic crypto-use seam truth | explicit D-ATTEST / CH-ATTEST / CH-ATTESTPACK workflows if ever needed |

### 11) Key use does not become signature verification / certificate-path / trust evaluation

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cryptosvc-verification-boundary-v0.md`](cryptosvc-verification-boundary-v0.md) | signature verification / certificate-path / trust-store / verifier-policy semantics | callers hold explicit key refs/routes and pinned policy, but they do not ask IF-CRYPTOSVC for portable verifier verdicts, best chains, trust anchors, or revocation policy outcomes as generic crypto-use seam truth | explicit D-SIGENV / D-KEYLESS / D-TIME / D-TLOG verification workflows if ever needed |

## Review rule

Before adding another D-CRYPTOSVC / D-AUTHAGENT companion boundary doc, answer these questions in order:
1) Is the change really a **crypto-authority meaning pin** rather than a new schema, workflow, or provider-management family?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported token/agent/provider folklore?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.

## Wiring

This index must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_cryptosvc_boundary_index.py` fails `make lint` if this companion family stops being discoverable, loses its closed member set, or drops its same-revision maintenance contract (**EVID-2026-597**).

## References

- REF-PLAN9-FACTOTUM.
- REF-OPENSSH-AGENTRESTRICT.
- REF-PKCS11-SPEC.
- REF-APPLE-KEYCHAIN-ITEMS.
- REF-APPLE-LOCALAUTH-KEYCHAIN.
- REF-MICROSOFT-CERTFINDCERTIFICATEINSTORE.
- REF-ORACLE-JAVA-KEYSTORE.
- REF-ORACLE-JAVA-KEYPAIRGENERATOR.
- REF-ANDROID-BIOMETRICPROMPT.
- REF-MICROSOFT-NCRYPT-UIPOLICY.
- REF-MICROSOFT-CNG-TYPICAL-PROGRAMMING.
- REF-ORACLE-JAVA-PROVIDER.
- REF-W3C-WEBCRYPTO-2.
- REF-MICROSOFT-NCRYPT-IMPORTKEY.
- REF-MICROSOFT-NCRYPT-CREATEPERSISTEDKEY.
- REF-MICROSOFT-NCRYPT-DELETEKEY.
- REF-MICROSOFT-NCRYPT-DERIVEKEY.
- REF-MICROSOFT-NCRYPT-EXPORTKEY.
- REF-TPM2-PART3-QUOTE.
- REF-ANDROID-KEYATTEST.
- REF-RATS-RFC9334.
- REF-KMIP-SPEC.
- REF-APPLE-SECITEMIMPORT.
- REF-APPLE-SECITEMEXPORT.
- REF-APPLE-SECKEYCREATERANDOMKEY.
- REF-APPLE-SECITEMDELETE.
- REF-APPLE-SECTRUST-EVALUATEWITHERROR.
- REF-MICROSOFT-CERTGETCERTIFICATECHAIN.
- REF-ORACLE-JAVA-PKIXBUILDERPARAMETERS.
