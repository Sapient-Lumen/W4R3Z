# CH-BOOT v0 (boot manifest / measurement record, informal)

Purpose: describe the booted artifact set and policy bindings so C-BOOT-1 can be stated as a predicate over explicit bytes.

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- binds a specific policy/config revision to a set of artifact digests
- optional anti-rollback floor (only meaningful if A-BOOT-2 holds)

## Shape (v0)
A manifest `m` contains:
- `schema`: fixed `CH-BOOT v0`
- `boot_policy_rev`: policy revision identifier
- `cfg_digest`: digest of the applied `CH-CFG v0` artifact
- `artifacts`: closed list of `{ name_tag, digest, role }` (bounded)
  - role examples (non-authoritative): `kernel`, `init`, `policy`, `boot_selector` (CH-BOOTSEL), `upd_manifest` (CH-UPD), `comp_manifest` (CH-COMP), `sbom`, `vex`, `harden_profile` (CH-HARDEN), `hwfacts` (CH-HWFACT), `meas_log` (CH-MEASLOG), `proof_bundle`
  - companion boundary `proof-bundle-role-boundary-v0.md`: `proof_bundle` remains a descriptive adjunct-evidence role only; the authoritative meaning is still the exact artifact digest, not a native proof/verdict schema or recursive fetch plan
- `measurements`: optional digest reference to a measured-boot/integrity log (recommended: digest of CH-MEASLOG v0); may be omitted if the profile is verified-boot-only
- `rollback_floor`: optional `{ counter_id, min_value }`
- `prov_attestation_digest`: optional digest of a signed provenance envelope/container (e.g., CH-SIGENV) that signs a `CH-PROV v0` payload digest (for D-PCP; supports C-PROV-2)
  - companion boundary `provenance-container-selection-boundary-v0.md`: if an imported provenance container packages multiple statements, statement selection/reconciliation stays verifier-local
  - companion boundary `provenance-coverage-policy-boundary-v0.md`: CH-BOOT carries exact provenance evidence digests only; it does not carry or select a portable provenance-coverage profile
  - companion boundary `provenance-evidence-set-boundary-v0.md`: multiple exact provenance-bearing artifacts do not jointly define a native provenance closure, fallback rule, or completeness claim
  - companion boundary `sbom-vex-evidence-set-boundary-v0.md`: multiple exact `sbom` / `vex` evidence artifacts do not jointly define a native applicability closure, fallback rule, or completeness claim
  - companion boundary `vex-component-absence-boundary-v0.md`: `component_not_present` plus one selected inventory does not define a native component-absence oracle or completeness verdict on CH-BOOT
  - companion boundary `vex-remediation-selection-boundary-v0.md`: `fixed` / remediation text do not define a native patch-plan or update-target selector on CH-BOOT
  - companion boundary `vex-investigation-deferral-boundary-v0.md`: `under_investigation` / VEX time fields do not define a native install-hold or defer-boot selector on CH-BOOT
  - companion boundary `vex-priority-signal-boundary-v0.md`: imported vulnerability scores / threat-list signals do not define a native boot-veto, defer-boot, or urgency selector on CH-BOOT
  - companion boundary `vex-cpe-applicability-boundary-v0.md`: imported CPE names / applicability expressions do not define a native boot-eligibility selector, product-identity oracle, or applicability-closure rule on CH-BOOT

Note under `ext.microvm`: if a deployment chooses to export which admitted reusable warm-start leaf or owner-local recovery artifact was resumed, that binding rides on ordinary owner-local `CH-BOOT` / `CH-PROV` / deployment-receipt evidence rather than a new guest-visible leaf-id plane. Phase 1 standardizes no dedicated `CH-BOOT` field or required artifact role for warm-start leaf identity (`microvm-resume-admission-evidence-posture-v0.md`).
If **D-RECOVERY** is enabled, any `artifacts[]` entry with role `recovery_root` names a distinct provenance-bound rescue deployment rather than a hidden fallback flag or generic admin image; the compact meaning pin for that role lives in `recovery-posture-v0.md`.

## Verification obligations
- verify signatures/measurements per deployment profile (PO-BOOT-VERIFY)
- if `measurements` is present: validate the referenced CH-MEASLOG and fail closed on structural/binding mismatches (PO-MEASLOG-VALIDATE)
- bind `cfg_digest` to the applied config and fail closed on mismatch (PO-BOOT-BIND)
- if `rollback_floor` present: enforce at install/boot time (I-BOOT-2)
- if `prov_attestation_digest` present: verify it is present/valid and bound to the booted artifacts (PO-PROV-BIND); local policy may require provenance over exact booted digests chosen from `cfg_digest` and exact `artifacts[]` digests already pinned by CH-BOOT; companion `provenance-required-subject-boundary-v0.md` pins that stricter requirements stay carrier-pinned rather than inheriting every subject from a larger release attestation, and companion `provenance-coverage-policy-boundary-v0.md` pins that CH-BOOT carries exact provenance evidence digests only; it does not carry or select a portable provenance-coverage profile, and companion `provenance-evidence-set-boundary-v0.md` pins that multiple exact provenance-bearing artifacts do not jointly define a native provenance closure or fallback rule
- if a `comp_manifest` artifact is present: record/export its digest for audit and treat mismatches as policy violations (PO-COMP-BIND)
- if `sbom` / `vex` artifacts are present: verify each selected artifact on its own binding seam; companion `sbom-vex-evidence-set-boundary-v0.md` pins that multiple exact `sbom` / `vex` evidence artifacts do not jointly define a native applicability closure or fallback rule, companion `vex-component-absence-boundary-v0.md` pins that `component_not_present` plus one selected inventory does not define a native component-absence oracle, companion `vex-remediation-selection-boundary-v0.md` pins that `fixed` / remediation text do not define a native patch-plan or update-target selector on CH-BOOT, and companion `vex-investigation-deferral-boundary-v0.md` pins that `under_investigation` / VEX time fields do not define a native install-hold or defer-boot selector on CH-BOOT
- if `sbom` / `vex` artifacts are present: verify each selected artifact on its own binding seam; companion `vex-priority-signal-boundary-v0.md` further pins that imported vulnerability scores / threat-list signals do not define a native boot-veto, defer-boot, or urgency selector on CH-BOOT.
- if `sbom` / `vex` artifacts are present: verify each selected artifact on its own binding seam; companion `vex-cpe-applicability-boundary-v0.md` further pins that imported CPE names / applicability expressions do not define a native boot-eligibility selector, product-identity oracle, or applicability-closure rule on CH-BOOT.
