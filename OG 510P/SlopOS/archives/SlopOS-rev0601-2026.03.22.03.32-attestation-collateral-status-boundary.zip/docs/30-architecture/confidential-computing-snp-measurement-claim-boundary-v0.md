# D-CC SNP measurement claim boundary v0 (launch measurement is exact evidence, not portable boot identity)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `MEASUREMENT`** so the report’s launch digest does not quietly become a portable SlopOS boot identity, rollout selector, or hidden approval channel.

Entropy cost justification: the archive already pinned the first D-CC provider target, one exact 64-byte binder contract, the SNP certificate-source rule, the SNP `HOST_DATA` rule, the guest-mode cut, and the main report-field seams around owner identity, TCB state, policy, report identity, platform information, chip identity, and `GUEST_SVN`. What remained ambiguous was the most tempting remaining shortcut: **SNP reports also carry `MEASUREMENT`, and AMD treats it as the guest launch digest/measurement of the guest address space**. One small boundary closes that gap without inventing a portable cross-provider measurement schema, replacing `CH-BOOT`, or standardizing a verifier-side expected-measurement database.

## Posture (v0)

1) **`MEASUREMENT` is the provider-native SNP launch digest, not portable SlopOS boot identity**
   - AMD’s SNP firmware ABI says the launch flow initializes a digest context, extends it during `SNP_LAUNCH_UPDATE`, and stores the finalized digest as the guest measurement at `SNP_LAUNCH_FINISH`.
   - AMD’s attestation material further describes report `MEASUREMENT` as the **measurement of the guest’s address space, including page types as defined in `SNP_LAUNCH_UPDATE`**.
   - Phase 1 therefore treats report `MEASUREMENT` as **exact provider-native evidence bytes only**. It does **not** become a native `CH-ATTEST` field, a portable SlopOS boot identity, or a reviewed cross-provider “what booted” digest.

2) **`MEASUREMENT` does not define one portable equivalence rule with `boot_digest == digest(CH-BOOT)`**
   - The archive already pins portable boot identity to `boot_digest == digest(CH-BOOT)` and separately pins exact `cc_report_data_v0` binding in provider-native report-data fields.
   - AMD’s launch digest covers SNP launch-flow semantics and address-space/page-type handling, while `CH-BOOT` is the SlopOS boot manifest / measured-boot binding surface.
   - Phase 1 therefore declines any built-in rule that report `MEASUREMENT` must equal `digest(CH-BOOT)`, any silent derivation of one from the other, and any claim that a verifier may skip one check because the other matched.

3) **`MEASUREMENT` does not substitute for `boot_digest`, `prov_digest`, exact `cc_report_data_v0` binding, or freshness**
   - A verifier MUST still check `boot_digest == digest(CH-BOOT)`, optional `prov_digest`, exact `cc_report_data_v0`, and explicit freshness on their own terms.
   - Matching, expected, repeated, or locally allowlisted SNP `MEASUREMENT` values do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace freshness binding under `PO-ATTEST-FRESH`, and do **not** redefine which `CH-BOOT` / provenance bundle was actually admitted.
   - In particular, `MEASUREMENT` MUST NOT become a hidden nonce, replay oracle, attestation-session identifier, or substitute proof that the exact D-CC binder contract was satisfied.

4) **Any relationship between `MEASUREMENT` and launch/reference material stays explicit verifier-local policy**
   - AMD’s identity block includes an expected launch digest that firmware checks against the computed launch digest during `SNP_LAUNCH_FINISH`.
   - A deployment-specific verifier MAY therefore compare exact report `MEASUREMENT` bytes against an owner/provider-local expected launch digest or reference corpus.
   - That comparison remains **explicit verifier-local policy** under D-POLICY and D-AREF rather than a portable SlopOS claim, default rollout rule, or native “expected measurement” registry.

5) **Packaging/export does not upgrade `MEASUREMENT` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `MEASUREMENT`.
   - If tooling wants to preserve extracted measurement values for audit or for owner-local policy evaluation, it SHOULD do so as exact supporting evidence (for example via `CH-AREF` or verifier-local reference artifacts) rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable SNP measurement schema.
   - Exporting a report that contains `MEASUREMENT` does not imply that remote consumers may treat that value as reviewed SlopOS-native boot identity.

6) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing provider-native SNP report field.
   - It introduces no new workflow kind, no serialization surface, and no portable expected-measurement query plane.

## Phase 1 non-goals (explicitly deferred)

- No `measurement` field in `CH-ATTEST v0`.
- No portable equation or derivation rule between SNP `MEASUREMENT` and `digest(CH-BOOT)`.
- No portable cross-provider expected-measurement schema, catalog, or “latest good measurement” discovery plane.
- No new workflow / ACP / conflict-key family for launch-measurement approval in v0.

## Why this boundary exists

The archive had already fixed most of the obvious SNP trust seams, but the report still carried one particularly attractive implementation shortcut:
- AMD documents `MEASUREMENT` as the launch digest / measurement of the guest address space,
- Linux/KVM launch docs describe guest data as being measured into the SNP guest context during `KVM_SEV_SNP_LAUNCH_UPDATE`,
- and the first verifier / secret-release / rollout path would predictably want to treat that provider-native field as “the real boot digest.”

Without one explicit rule, Phase 1 code would likely drift into one of these by convention:
- treating SNP `MEASUREMENT` as equal to `digest(CH-BOOT)`,
- replacing `boot_digest` checks with a provider-native measurement allowlist,
- silently turning expected launch digests into a portable rollout/approval plane,
- or leaking one provider’s launch-flow semantics into cross-provider attestation meaning.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **SNP `MEASUREMENT` remains exact evidence unless explicit verifier-local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a portable SNP measurement schema**,
- and **automation cannot inherit a hidden provider-native boot-identity channel through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact SNP launch measurements for audit or hosted-secret release without letting one provider-native digest replace `CH-BOOT` as portable workstation boot identity.
- **Cloud micro-VM substrate (B):** hosted-compute verifiers may compare exact measurement bytes against provider-/owner-local launch references, but only under explicit local policy rather than by widening D-ATTEST into a portable measurement allowlist plane.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling can retain exact SNP report measurements for audit without importing a cloud-provider launch digest as the appliance’s native boot identity contract.
- **Agent / automation OS (D):** agents can inspect exact SNP measurements, but they do not get a silent “measurement matched, therefore approved” shortcut; any such appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP launch-measurement seam.

If a second closely related D-CC provider-field measurement boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-BOOT**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-reference-target-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `boot-manifest-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-BOOT-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_measurement_claim_boundary.py` (**EVID-2026-546**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-SNP-ATTEST-PDF.
- REF-LINUX-AMD-MEMENC.
- REF-RATS-RFC9334.
