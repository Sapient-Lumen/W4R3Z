# D-CC SNP report-signing metadata claim boundary v0 (signing metadata is exact evidence, not portable provider/trust meaning)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP attestation-report signing metadata** so report `SIGNING_KEY`, `MASK_CHIP_KEY`, and `SIGNATURE_ALGO` do not quietly become a portable SlopOS provider-class claim, trust-policy language, or approval shortcut.

Entropy cost justification: the archive already pinned the first D-CC provider target, one exact 64-byte binder contract, the SNP certificate-source rule, the SNP `HOST_DATA` rule, the guest-mode cut, and the main report-field seams around owner identity, TCB state, policy, report identity, chip identity, platform information, `GUEST_SVN`, and `MEASUREMENT`. What remained ambiguous was a narrow but high-leverage seam: **SNP reports also disclose which signing key was used (`VCEK`, `VLEK`, or none when chip-key masking zeroes the signature), the firmware exposes `MASK_CHIP_KEY`, and real hosted deployments such as AWS rely on a provider-issued VLEK chain**. One small boundary closes that gap without inventing a portable provider-class taxonomy, trust-policy language, or cross-provider “sanctioned environment” claim surface.

## Posture (v0)

1) **SNP report-signing metadata is exact provider-native evidence, not portable SlopOS trust or provider identity meaning**
   - AMD’s SNP firmware ABI places `SIGNATURE_ALGO`, `SIGNING_KEY`, and `MASK_CHIP_KEY` in the attestation report.
   - `SIGNING_KEY` encodes whether the report was signed by `VCEK`, `VLEK`, or by no key when signature bytes are absent under chip-key masking.
   - Phase 1 therefore treats those fields as **exact provider-native evidence only**. They do **not** become native `CH-ATTEST` claims, a portable SlopOS provider identity, or a reviewed cross-provider trust-profile label.

2) **`SIGNING_KEY` does not define one portable provider-class or “sanctioned environment” taxonomy**
   - AMD documents `VLEK` as a provider-enrolled alternative to `VCEK`, and AWS publicly documents that its EC2 SNP attestation reports are signed by an AMD-issued VLEK for AWS.
   - That makes `SIGNING_KEY == VLEK` useful exact evidence about one deployment’s endorsement path.
   - It does **not** create a portable SlopOS rule that `VLEK` means “hosted cloud”, “approved provider”, “managed substrate”, or any other reviewed deployment-class verdict.

3) **Report-signing metadata does not override the separately pinned certificate-source and verifier-policy boundaries**
   - The archive already pins GHCB/host-memory certificate tables to transport-only meaning and keeps accepted signer class, trust roots, CRL freshness, and related endorsement policy explicit and verifier-local.
   - Report `SIGNING_KEY`, `MASK_CHIP_KEY`, and `SIGNATURE_ALGO` therefore do **not** replace certificate-chain validation, signer-family allowlists, local endorsement policy, or exact verifier-owned approval logic.
   - In particular, `SIGNING_KEY == VLEK` does not auto-admit a report, `SIGNING_KEY == VCEK` does not auto-deny hosted environments, and `MASK_CHIP_KEY == 1` does not silently widen into a portable unsigned-report mode for `CH-ATTEST`.

4) **Unsigned or masked-chip-key reports do not become a portable fallback attestation mode**
   - AMD’s ABI says that when `MaskChipKey` is 1, the report is not signed and the signature field is filled with zeroes; the report also records `MASK_CHIP_KEY` and `SIGNING_KEY` may encode `None`.
   - Phase 1 therefore treats masked/unsigned reports as exact evidence about one provider-native firmware state only.
   - They do **not** define a portable “offline ok”, “local-only attest”, or “signature optional” mode for D-ATTEST / D-CC, and they do not weaken `PO-ATTEST-VERIFY` into a digest-only approval path.

5) **Packaging/export does not upgrade report-signing metadata into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `SIGNATURE_ALGO`, `SIGNING_KEY`, and `MASK_CHIP_KEY`.
   - If tooling wants to preserve extracted values for audit or verifier-local routing, it SHOULD do so as exact supporting evidence (for example via `CH-AREF` or verifier-local policy artifacts) rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable signing-metadata schema.
   - Exporting a report that carries `VLEK`, `VCEK`, or masked/unsigned signing metadata does not imply that remote consumers may treat those values as reviewed SlopOS-native trust or provider claims.

6) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of existing SNP attestation metadata.
   - It introduces no new workflow kind, no signer-discovery plane, no provider-class registry, and no portable attestation-policy channel.

## Phase 1 non-goals (explicitly deferred)

- No `signing_key`, `signature_algo`, or `mask_chip_key` field in `CH-ATTEST v0`.
- No portable SlopOS provider-class or trust-profile taxonomy derived from SNP `VCEK` / `VLEK` / unsigned report modes.
- No portable unsigned-attestation fallback mode for `CH-ATTEST` / `CH-ATTESTPACK`.
- No new workflow / ACP / conflict-key family for signer-family discovery or approval in v0.

## Why this boundary exists

The archive had already fixed most of the obvious SNP trust seams, but the report still carried one especially folklore-prone implementation shortcut:
- AMD exposes which key signed the report and whether chip-key masking zeroed the signature,
- AMD’s VLEK model is explicitly CSP-oriented,
- AWS publicly presents VLEK-signed reports as proof the instance is running in its sanctioned AMD environment,
- and the first verifier / secret-release / rollout path would predictably want to treat that signer metadata as a portable provider or approval claim.

Without one explicit rule, Phase 1 code would likely drift into one of these by convention:
- treating `SIGNING_KEY == VLEK` as a portable “approved cloud” verdict,
- using report signing metadata as a hidden verifier-policy selector,
- normalizing masked/unsigned reports into a generic local-attestation mode,
- or letting signer metadata outrun the already-pinned certificate-source and endorsement-policy boundaries.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, exact `cc_report_data_v0` binding, and explicit verifier-local policy**,
- **SNP report-signing metadata remains exact evidence unless explicit verifier-local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a portable provider/trust taxonomy**, 
- and **automation cannot inherit a hidden provider-class or signer-mode approval channel through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact report-signing metadata for audit or remote-secret release without letting `VCEK` / `VLEK` / masked reports become a portable workstation trust/profile label.
- **Cloud micro-VM substrate (B):** hosted-compute verifiers may use exact signer metadata under explicit local endorsement policy, but only as local policy inputs rather than by widening D-ATTEST into a portable provider-class or approval plane.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling can retain exact signing metadata without importing cloud-provider signer labels as the appliance’s native attestation semantics.
- **Agent / automation OS (D):** agents can inspect exact signer metadata, but they do not get a silent “VLEK therefore approved” shortcut; any such appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP report-signing-metadata seam.

If a second closely related D-CC provider-signing-metadata boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reference-target-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_signing_metadata_claim_boundary.py` (**EVID-2026-547**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-VLEK-CERT.
- REF-AWS-SNP-ATTEST.
- REF-RATS-RFC9334.
