# SBOM/VEX component-version boundary v0 (`version` stays an imported descriptive label, not a native same-component or version-ordering rule)

Purpose: pin the Phase-1 meaning of **component / subject `version` strings imported through CH-SBOM / CH-VEX evidence** across **D-SBOM**, **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, and **D-POLICY** so one ecosystem’s version grammar does not quietly become a portable component-identity root, update-ordering oracle, remediation selector, or suppression join rule.

Entropy cost justification: the archive already pins release names/version strings to observational distribution identity, already keeps `fixed` / remediation text from selecting updates, and already keeps `purl` / `bom-ref` out of native cross-artifact identity. The remaining cheap-but-dangerous ambiguity is the optional `version` field that still appears inside CH-SBOM / CH-VEX and richer external SBOM/VEX ecosystems. If left loose, one tool will start treating `name + version` as “same component everywhere”, another will compare version strings as if all ecosystems share one ordering relation, and a third will infer remediation or suppression from version-range folklore. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still carry optional `version` per component as imported descriptive metadata.
- **CH-VEX v0** may still carry optional `subject.version` and component-scoped `version` as imported exploitability context.
- **Verifier-local policy/tooling** may still compare, normalize, or otherwise reason over version strings/ranges, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **`version` is an imported descriptive label only.**
   - A `version` in CH-SBOM or CH-VEX records one imported package/advisory label chosen by upstream tooling or an attached external SBOM/VEX ecosystem.
   - Phase 1 therefore treats `version` as descriptive evidence syntax, not as a native SlopOS component-identity root or portable ordering relation.
   - Matching `version` bytes across different SBOMs, VEX artifacts, release bundles, or external documents carries no portable same-component meaning by itself.

2) **Exact component binding still rides on stable identifiers when available.**
   - `content_digest` and `build_id` remain the portable component-binding fields under **I-SBOM-2** and the adjacent CH-VEX component-scoping guidance.
   - Companion `sbom-posture-v0.md` already pins `name`, `version`, `purl`, `supplier`, and `licenses` as observational only.
   - This boundary further pins that imported `version` labels stay on the same non-native side of the line even when ecosystem tooling treats them as familiar package identity.

3) **Phase 1 imports no native version ordering / normalization / range-expansion rule.**
   - CycloneDX can carry both a `version` and, for external components, a separate `versionRange`; SPDX package version info is optional text; OSV explicitly notes that version-range handling is ecosystem-specific and unsupported ecosystems may need enumerated version lists.
   - Phase 1 therefore adds no native “semantic-version compare”, “rpm/deb ordering”, “strip epoch”, “normalize git tag”, “expand ecosystem range”, “same name+version implies same package instance”, or “fixed/newer version supersedes this subject” rule.
   - Any such comparison logic stays verifier-local and explicit under **D-POLICY** rather than leaking into CH-SBOM / CH-VEX / CH-UPD / CH-BOOT meaning.

4) **`version` does not widen remediation, absence, or suppression meaning.**
   - Matching one `version` from one inventory/advisory row to one row elsewhere does not by itself prove global component absence, remediation coverage, vulnerability suppression, or successor-package choice.
   - Companion `vex-component-absence-boundary-v0.md` already pins that `component_not_present` plus one linked inventory does not become a native absence oracle.
   - Companion `vex-remediation-selection-boundary-v0.md` already pins that `fixed` and remediation/action text do not become a native patch-plan or successor-target chooser.
   - Companion `vex-vulnerability-identity-boundary-v0.md` already pins that `vuln_id` is one exact advisory label only; `version` must not become the back door for a hidden wider suppression or remediation graph.

5) **Imported richer version ecosystems stay imported evidence unless another seam admits more.**
   - CycloneDX, SPDX, OpenVEX, OSV, and CSAF can all carry version-shaped data, but they do so with ecosystem-specific syntax, optional range forms, or descriptive text rather than one universal portable ordering model.
   - Phase 1 may ingest those exact bytes as evidence and may carry exact external docs through **CH-AREF**, but it does not elevate their version grammars into privileged-core semantics.
   - Companion `verification-policy-selection-boundary-v0.md` still pins that evidence does not choose which comparison / normalization policy is in force.

6) **Exact artifact binding and update choice still happen on the existing seams.**
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds the exact subject digest the verifier cares about.
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds that same subject digest.
   - **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, and **PO-AREF-VERIFY** still answer carrier/evidence integrity for the already-pinned cohort.
   - No portable “same component”, “same package instance”, “newer than”, or “fixed by successor version” verdict is created merely by reusing, normalizing, or comparing imported `version` strings.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported version labels/ranges fit with existing SBOM/VEX/update/boot seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native component-version canonicalizer, alias graph, or same-component oracle.
- No universal version-ordering engine for package/advisory ecosystems.
- No rule that matching or ordered version strings across SBOM/VEX documents creates suppression, completeness, remediation, or applicability semantics.
- No import of full package-ecosystem version grammar into the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- CycloneDX explicitly says component `version` should ideally comply with semantic versioning **but is not enforced**, and also has a separate `versionRange` form for external components.
- SPDX treats package version as optional package-identification text.
- OSV makes version-range handling ecosystem-specific enough that unsupported ecosystems must enumerate concrete versions.

Once VEX, SBOM, remediation hints, and external-doc attachment are all available, it becomes extremely tempting to treat one familiar version grammar as the hidden rule for “same package”, “newer/fixed”, or “covered by this advisory”. Pinning that split now keeps SlopOS from quietly inheriting that folklore.

## Profile effect (A–D)

- **Secure workstation (A):** local scanners may still ingest rich package metadata, but one familiar package version string cannot silently suppress or widen advisory meaning across apps.
- **Cloud micro-VM substrate (B):** fleet pipelines may attach many third-party SBOM/VEX artifacts, but portable install/applicability semantics stay on exact digests rather than version-comparison folklore.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a full cross-ecosystem version-comparison engine.
- **Agent/automation OS (D):** agents may reason over imported version metadata, but they cannot smuggle “same version means same component” or “higher version means fixed” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/vex-component-absence-boundary-v0.md`
  - `docs/30-architecture/vex-remediation-selection-boundary-v0.md`
  - `docs/30-architecture/vex-vulnerability-identity-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0091-sbom-artifacts-and-closure-binding.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-SBOM-2**, **I-VEX-1**, **I-AREF-1**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_component_version_boundary.py` keeps the split small and discoverable (**EVID-2026-490**).

## References

- **REF-CYCLONEDX-VERSIONREF**
- **REF-SPDX-PACKAGE-INFO**
- **REF-OSV-VERSIONS**
- **REF-OPENVEX-SPEC**
