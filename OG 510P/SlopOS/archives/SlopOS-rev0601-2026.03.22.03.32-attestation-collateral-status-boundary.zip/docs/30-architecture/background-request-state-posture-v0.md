# D-BGLEASE request-state posture v0 (request key ≠ live background grant state)

Purpose: close one small but expensive ambiguity on the D-BGLEASE seam: **a bounded CH-BGREQ request artifact is not the same thing as current portal-owned live background/autostart grant state**.

Several of the comparison archives got this exact split right in adjacent workflow lanes: a stable review/dedupe request key is valuable, but it must not collapse into current live grant truth. SlopOS should be at least that explicit.

This doc is intentionally narrow. It does **not** add a new background-grant inventory API, a lease-status watcher, or a durable portal-state schema. It only freezes what CH-BGREQ `req_id` does and does not mean in Phase 1.

## Posture (v0)

1) **`CH-BGREQ.req_id` is requester-chosen request identity, not portal-issued live grant state**
   - `req_id` is a stable caller-chosen request key carried in the request descriptor so retries, renew/review submissions, and ACP dedupe have one exact schema-pinned key.
   - It is **not** a portal-issued BackgroundLease handle, not an autostart-record identifier, and not proof that a current live background/autostart grant exists.

2) **Request presence is not current grant-state truth**
   - The existence of CH-BGREQ bytes (or an old `bgreq_digest`) says only that a bounded request was formed/submitted.
   - It does **not** by itself mean a background grant is currently active, an autostart registration is still enabled, the request is pending review, or the current portal policy would still allow the same grant now.

3) **Current portal-owned grant state remains portal-local unless a future surface pays for it explicitly**
   - Grant issuance, renewal, revocation, expiry, review cadence, disablement, and "still active?" truth stay inside the `portal.background` service boundary in Phase 1.
   - If later work needs portable grant-status receipts, revocation watches, or current autostart-state projection, it must return RFC-first with its own schema, ordering, receipts, and assurance hooks.

4) **Dedupe/retry safety uses the request key only as a veto-only identity hook**
   - At-least-once-safe `portal.background.request` depends on a stable `CH-BGREQ.req_id` so duplicate submissions can collapse before effect.
   - That dedupe key is still non-authoritative: it may suppress/reuse/renew according to portal policy, but it never grants background/autostart authority by itself.

5) **Historical receipts do not reactivate current background grants**
   - A prior CH-ACPOUT / CH-LOG / CH-RECEIPT trail may prove that a request was reviewed or accepted at some point.
   - It does **not** imply that the corresponding background/autostart grant remains live after later revocation, expiry, policy tightening, manual disablement, or portal-local cleanup.

## Phase 1 non-goals (explicitly deferred)

- A portable inventory / enumerate-background-grants / list-autostart API.
- A portable receipt or watcher surface proving whether a request is currently pending, granted, revoked, expired, or manually disabled.
- Treating CH-BGREQ `req_id` as a portal-issued BackgroundLease handle or current autostart-record identifier.
- Letting historical CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts stand in for current portal-owned grant truth.
- Any hidden policy/query language that asks the portal for ambient “current background state” during ACP validation.

## Why this earns its place

Without this split, the archive quietly collapses two different questions:
- **what exact request did we review/dedupe?**
- **what grant state exists right now inside the portal?**

That collapse would make renewals, receipts, and automation less honest. Phase 1 can stay small and still refuse the ambiguity.

## Wiring

- Decision surface:
  - `decision-map.md` (D-BGLEASE)
- Request / grant descriptors:
  - `background-request-schema-v0.md` (CH-BGREQ v0)
  - `background-lease-schema-v0.md` (CH-BGLEASE v0)
- Portal semantics:
  - `background-lease-posture-v0.md`
  - `portal-family-registry.md`
- ACP automation:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
- RFC / trajectory:
  - `rfcs/0103-background-execution-and-autostart-leases.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (I-BGREQ-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-BGLEASE-STATE)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`

CI drift gate:
- `tools/check_background_request_state_posture.py`

## References

- REF-XDG-PORTAL-BACKGROUND.
- REF-ANDROID-BG-EXEC-LIMITS.
- REF-APPLE-BG-MODES.
