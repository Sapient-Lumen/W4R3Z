# D-CC SNP certificate-source boundary v0 (host-shared cert tables are transport only)

Purpose: pin the **Phase 1** meaning of **where SNP endorsement material comes from** so the first verifier harness does not quietly treat hypervisor-shared certificate blobs as native authority.

Entropy cost justification: `attestation-endorsement-boundary-v0.md` already pins endorsements/reference values to **verifier-local appraisal inputs**, `confidential-computing-reference-target-boundary-v0.md` already pins **AMD SEV-SNP** as the first D-CC target, and `confidential-computing-reportdata-binding-boundary-v0.md` already pins the exact report-data bytes. The remaining ambiguity is narrower: **the SNP guest can obtain certificates/CRLs from hypervisor-shared pages or from explicit AMD KDS/mirror tooling, and those paths must not collapse into one ambient trust story**. One small boundary closes that gap without adding a new schema family, quote broker, or fetch plane.

## Posture (v0)

1) **Hypervisor-shared SNP certificate tables are transport only, not trust roots.**
   - AMD GHCB/SNP Extended Guest Request lets a guest receive certificate data (for example VCEK, ASK, ARK, VLEK, CRL) through guest pages that are explicitly **shared with the hypervisor**.
   - Those bytes may be useful transport or audit evidence, but in Phase 1 they are **not self-authenticating truth** merely because the guest received them through the SNP certificate-table mechanism.
   - A verifier MUST therefore treat host/shared-page certificate material as **untrusted supporting input** until it validates under explicit local trust roots and local policy.

2) **Verifier trust anchors and accepted signer class remain explicit local policy.**
   - The Phase 1 verifier chooses which SNP signer families are admissible for a given deployment profile: for example a hosted cloud profile may require an AMD-issued **VLEK** chain for a specific provider class, while another deployment may admit **VCEK** or **VLEK** only when explicitly configured.
   - The signer class is **not** selected by whichever certificate happened to arrive next to the report.
   - Host-delivered ARK / ASK / ASVK / VCEK / VLEK / CRL bytes therefore do not override local allowlists, signer-class selection, freshness windows, or certificate-status policy.

3) **SNP-first export does not require embedding the host certificate table in CH-ATTESTPACK.**
   - The portable export meaning remains **CH-ATTEST v0** plus optional provider-native evidence in **CH-ATTESTPACK v0**.
   - For SNP-first flows, the report itself is the provider-native evidence object that matters most.
   - If an implementation wants to preserve exact host-exposed cert/CRL bytes for audit or offline verification, it SHOULD package them as exact external artifacts (for example via **CH-AREF** or release-bundle packaging) rather than quietly widening CH-ATTESTPACK into a provider-native certificate inventory.

4) **AWS-style “request certs from host memory” is convenience, not portable authority.**
   - Practical SNP guest workflows sometimes retrieve a report and certificates from the platform, then separately validate the resulting VLEK/VCEK chain against AMD-published roots or a local mirror.
   - Phase 1 imports the convenience but not the authority shortcut: host memory is an allowed **transport source**, not an automatic **trust source**.
   - This keeps SNP-first honest across all four product shapes instead of letting one cloud-provider retrieval habit silently redefine D-CC meaning.

5) **KDS fetch, mirror refresh, and CRL retrieval remain explicit verifier-side tooling.**
   - `snpguest` already exposes both models: host-memory certificate retrieval and explicit KDS-oriented fetch commands for CA/VCEK/CRL material.
   - SlopOS Phase 1 standardizes no attester-side KDS client, no implicit host-memory fallback, no ambient CRL refresh loop, and no native “fetch endorsements for this report” plane.
   - Any online mirror/KDS retrieval remains explicit tooling above the authority substrate and, if networked, must use already-pinned **D-NETLEASE** controls.

6) **No new workflow / ACP / conflict-key family appears in v0.**
   - This boundary only narrows the trust meaning of already-existing SNP evidence transport paths.
   - It introduces no new workflow action kind, no serialization boundary, and no provider-specific admin plane.

## Phase 1 non-goals (explicitly deferred)

- No native SNP certificate inventory or host-certificate enumeration API.
- No attester-side KDS / mirror / CRL fetch client in IF-ATTEST.
- No portable rule that host-delivered ARK / ASK / ASVK / VCEK / VLEK / CRL material outruns verifier-local policy.
- No new workflow / ACP / conflict-key family for certificate transport or refresh in v0.

## Why this boundary exists

The SNP-first path was ready to implement, but one trust ambiguity remained expensive:
- AMD’s GHCB spec explicitly allows the guest to receive a certificate table through **shared** guest pages.
- AWS’s public SNP attestation workflow tells users to retrieve certificates from host memory, then separately validate the returned VLEK against AMD’s published chain.
- `snpguest` supports both host-memory retrieval and explicit KDS/CA/CRL fetch paths.

Leaving that seam fuzzy would predictably create a verifier bug class: “whatever certs the host handed us are the authoritative chain.”

Pinning the rule now keeps the first harness small and honest:
- **host/shared pages are transport**,
- **local verifier policy selects trust roots and signer class**,
- **CH-ATTESTPACK stays a bounded evidence export rather than a certificate inventory**,
- and **any live mirror/KDS behavior remains explicit tooling**.

## Profile effect (A–D)

- **Secure workstation (A):** local review tools may preserve host-exposed SNP cert bytes for audit, but desktops do not silently inherit a cloud-host certificate trust path.
- **Cloud micro-VM substrate (B):** hosted SNP verification can use provider-specific VLEK policy while keeping trust roots and CRL freshness local to the verifier rather than to the guest export path.
- **Embedded / separation-kernel-ish appliance (C):** appliance verifiers can ship exact local trust anchors offline and consume packaged cert artifacts without adding ambient KDS/network dependence.
- **Agent / automation OS (D):** agents may reason over bundled SNP cert evidence, but they cannot smuggle in “the host gave us this chain, therefore proceed” authority through automation workflows.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam.

If a second closely related D-CC certificate-source / endorser-selection boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-AREF**, **D-NETLEASE**.
- Adjacent seams:
  - `confidential-computing-reference-target-boundary-v0.md`
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `attestation-endorsement-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **I-ATTEST-1**, **I-AREF-1**.
  - **PO-ATTEST-VERIFY**, **PO-AREF-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_certificate_source_boundary.py` (**EVID-2026-536**).

## References

- REF-AMD-GHCB.
- REF-AWS-SNP-ATTEST.
- REF-AMD-VLEK-CERT.
- REF-SNPGUEST.
- REF-RATS-RFC9334.
