# Boundary-index contract (v0)

Purpose: keep every closed companion `*-boundary-index.md` doc structurally reliable as a compact discovery surface.

Why this exists:
- the archive now depends on many companion family indexes to reduce amnesia,
- once those indexes exist, **existence alone is not enough**: a future revision can leave an index present but thin, under-enumerated, or missing the same-revision review rule that keeps families closed,
- this contract keeps companion indexes crisp without inventing a new product surface or widening any decision seam.

This doc does **not** add a new schema, workflow, or authority surface.
It is an archive-hygiene contract for companion discovery surfaces only.

## Contract

Every current companion boundary-index doc under `docs/30-architecture/` must:
- state a clear `Purpose:` and `Why this exists:` so the family-level entropy cost is explicit,
- include `## Inclusion rule`, one closed-set section (`## Closed companion boundary set (Phase 1)` or a family-specific equivalent such as the capshell launch variant), and `## Review rule`,
- enumerate the current family members **explicitly** with direct markdown links inside the closed-set section rather than relying on filename wildcards or prose like “and related docs”,
- list at least two current member docs in that closed-set section so the surface really is a family index rather than a singleton,
- state that the index itself does **not** add a new schema or workflow family,
- require same-revision maintenance: if a new family member lands, the companion index must be updated in that same revision.

The member set may be made of `*-boundary-v0.md` docs or another tightly-bounded adjunct class when that is the real Phase-1 family (for example `capshell-*-posture-v0.md` launch adjuncts). The key requirement is that the family stays **closed, explicit, and reviewable**.

## Non-goals

- This contract does **not** decide which families should exist; that cost is paid in the family index itself plus `boundary-family-map.md`.
- This contract does **not** replace family-specific drift gates; it keeps their common structure honest.
- This contract does **not** authorize wildcard discovery, hidden inheritance, or “close enough” family membership by prose implication.

## Review rule

Before adding or heavily rewriting any companion `*-boundary-index.md` doc, answer these questions in order:
1) Is this really a **closed companion discovery surface** rather than a new schema, registry, or workflow family?
2) Does the index enumerate every current family member explicitly in its closed-set section?
3) Does it keep the inclusion/review rules readable enough that future passes can update it in the **same revision** as any member change?

If the answer to (1) is yes, keep the index contract and the family-specific drift gate aligned in that same revision.
