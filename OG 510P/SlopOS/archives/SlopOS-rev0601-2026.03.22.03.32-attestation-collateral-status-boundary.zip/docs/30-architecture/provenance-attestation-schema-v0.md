# CH-PROV v0 (provenance attestation payload)

Purpose: a small, canonical provenance statement that can be signed and bound into CH-BOOT via `prov_attestation_digest`.

Phase-1 meaning is pinned in `provenance-posture-v0.md`: **CH-PROV is digest-bound build provenance evidence only**. It does not become a release-registry statement, a verification summary, or a recursive fetch/query protocol.

This schema is inspired by the SLSA provenance predicate and in-toto attestation model, but kept deliberately minimal. Companion release-name/version semantics are pinned separately in `release-identity-boundary-v0.md`: CH-PROV stays artifact/build-bound evidence even when ecosystems also publish release-name mappings. Verification-verdict semantics are pinned separately in `verification-verdict-boundary-v0.md`: verification results and waivers stay on separate seams even when ecosystems publish delegated review artifacts. Companion `provenance-container-selection-boundary-v0.md` further pins that CH-PROV v0 defines one statement payload only; if an imported envelope/container packages multiple statements, selection remains verifier-local.

Refs: REF-SLSA-PROVENANCE, REF-SLSA-VERIFYING-ARTIFACTS, REF-IN-TOTO, REF-IN-TOTO-STATEMENT, REF-IN-TOTO-RELEASE.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded fields (no unbounded logs)
- expresses *what to verify* without requiring a large verifier

## Shape (v0)
A provenance statement `p` contains:
- `schema`: fixed `CH-PROV v0`

### Subject (what was built)
- `subjects`: bounded list of subjects produced by **one reviewed build/release cohort**:
  - `name`: bounded identifier (operator/debug only; observational)
  - `digest`: digest of the artifact (same digest namespace as CH-BOOT; authoritative binding)
  - `role`: closed enum (e.g., `{ hv_image, kernel_image, init_image, cfg, comp_manifest, proof_bundle }`)
    - companion boundary `proof-bundle-role-boundary-v0.md`: `proof_bundle` names one exact adjunct evidence artifact only, not a native bundle schema or approval state

### Builder + build definition (how it was built)
- `builder`:
  - `id`: bounded builder identity (e.g., CI workflow identity; informational until explicit policy validates it)
  - `version`: optional bounded version tag (informational)
- `build`:
  - `build_type`: closed enum for our pipelines (e.g., `{ release, dev, proof }`)
  - `invocation_id`: bounded nonce/id (operator/debug; not a trust root by itself)
  - `timestamp`: optional time value (only if included by profile; not a security oracle)

### Materials (what it depended on)
- `materials`: bounded list of digest-identified inputs:
  - `name`: bounded identifier
  - `digest`: digest
  - `kind`: closed enum (e.g., `{ source_tree, toolchain, deps_lock, spec_bundle, proof_inputs }`)

### Optional: proof/model-check attachments (for D-PCP slices)
- `evidence`: optional bounded list of digest-identified adjunct evidence:
  - `name`: bounded identifier
  - `digest`: digest
  - `kind`: closed enum (e.g., `{ verus_proof, isabelle_proof, kani_report, loom_report, fuzz_corpus, benchmark }`)

## Validation obligations
- reject unknown enum variants and unknown keys (closed world)
- ensure subject digests use supported digest algorithms
- ensure `subjects`, `materials`, and `evidence` lists are bounded
- treat `subjects[].name`, `builder.*`, `build.invocation_id`, and `build.timestamp` as informational metadata unless higher-level policy explicitly validates them
- treat `materials[]` / `evidence[]` digests as references only; any locator/fetch semantics live outside CH-PROV itself (e.g., via CH-AREF + tooling policy)

## Binding note
- CH-BOOT may include `prov_attestation_digest` which refers to a signature envelope/container over CH-PROV v0 (e.g., CH-SIGENV v0; RFC-0093), whose binding ultimately covers the canonical bytes digest of CH-PROV v0 (details are a D-UPD-SIGN/D-SIGENV decision).

## Security notes
- **Digest-first binding**: subject matching is by digest, not by filename, version string, or media type.
- **No verdict overloading**: CH-PROV describes how outputs were produced; release-version mapping, policy conclusions, and verification summaries stay on separate seams.
- **No ambient recursion**: materials/evidence entries bind exact inputs and adjunct evidence, but do not by themselves instruct the runtime to fetch or recursively verify remote objects.
