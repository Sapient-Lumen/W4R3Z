# D-CC SNP version-metadata claim boundary v0 (report/firmware version metadata is exact evidence, not portable platform maturity or capability meaning)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP attestation report / firmware version metadata** so report `VERSION`, `CURRENT_BUILD` / `CURRENT_MINOR` / `CURRENT_MAJOR`, and `COMMITTED_BUILD` / `COMMITTED_MINOR` / `COMMITTED_MAJOR` do not quietly become a portable SlopOS security tier, capability plane, parser-negotiation channel, or hidden approval shortcut.

Entropy cost justification: the archive already pinned the first D-CC provider target, one exact 64-byte binder contract, the SNP certificate-source rule, the SNP VMPL-mode cut, imported embedded-EAT claims, and the main provider-native report-field seams around host data, launch identity, TCB state, policy, report identity, chip identity, platform information, guest SVN, measurement, and signing metadata. What remained ambiguous was narrower but still high leverage: **SNP reports also disclose report-format and firmware-version metadata (`VERSION`, `CURRENT_*`, `COMMITTED_*`), and those fields are tempting places to smuggle provider-specific “approved platform generation”, “minimum safe version”, or “feature level” folklore into portable D-CC meaning**. One small boundary closes that gap without inventing a portable firmware-capability registry, cross-provider version taxonomy, or attestation-policy negotiation plane.

## Posture (v0)

1) **SNP report / firmware version metadata is exact provider-native evidence, not portable SlopOS platform maturity or capability meaning**
   - AMD’s SNP firmware ABI puts `VERSION` in the attestation report, with the current report structure version set to `5h` for this ABI revision.
   - The same report also carries `CURRENT_BUILD` / `CURRENT_MINOR` / `CURRENT_MAJOR` and `COMMITTED_BUILD` / `COMMITTED_MINOR` / `COMMITTED_MAJOR` as the build/minor/major components of `CurrentVersion` and `CommittedVersion`.
   - Phase 1 therefore treats those fields as **exact provider-native evidence only**. They do **not** become native `CH-ATTEST` claims, a portable SlopOS “generation” label, a normalized capability vector, or a reviewed cross-provider maturity/profile tier.

2) **Version metadata does not define one portable minimum-version, compatibility-tier, or approval taxonomy**
   - Exact firmware-version fields may matter to one verifier owner’s local security policy or operational rollout rules.
   - Phase 1 still declines any built-in rule that `CURRENT_*` or `COMMITTED_*` values map to one portable “safe enough”, “supports feature X”, “approved cloud generation”, or “release channel” meaning.
   - Likewise, report `VERSION` does **not** define one portable attestation-claim-generation ladder beyond explicit parser support for exact report bytes.

3) **Parser support stays explicit verifier/tool behavior, not artifact-selected negotiation**
   - A verifier or evidence tool MAY support only specific exact report versions or provider-version ranges.
   - Unsupported or unexpected `VERSION` / `CURRENT_*` / `COMMITTED_*` values therefore cause an **explicit local parser/policy decision** (for example, reject fail closed, quarantine, or route to an upgraded verifier).
   - Those bytes do **not** create a portable negotiation plane, artifact-selected policy switch, or hidden rule that the report itself gets to choose which semantics are in force.

4) **Version metadata does not substitute for TCB fields, boot/provenance binding, exact report-data binding, or freshness**
   - Matching or allowlisted version numbers do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace explicit threshold appraisal of SNP TCB fields, and do **not** redefine which `CH-BOOT` / provenance bundle was admitted.
   - Exact `boot_digest`, optional `prov_digest`, exact `cc_report_data_v0`, and explicit freshness checks still stand on their own terms.
   - In particular, `CURRENT_* >= floor`, `COMMITTED_* >= floor`, or `VERSION == expected` MUST NOT become a hidden replay/freshness/session shortcut or a substitute proof that the exact D-CC binder contract was satisfied.

5) **Any appraisal of version metadata remains explicit verifier-local policy**
   - A deployment-specific verifier MAY impose exact local rules such as “reject report versions I cannot parse”, “require a committed firmware version floor”, or “route exact firmware versions to a quarantine lane pending review”.
   - That appraisal remains **explicit verifier-local policy** under D-POLICY and D-AREF rather than a portable SlopOS default, capability registry, or hidden approval lane.
   - Exported receipts or transcripts may record those exact values or the policy digest that judged them, but naming them does not force another verifier to adopt the same rule.

6) **Packaging/export does not upgrade version metadata into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `VERSION`, `CURRENT_*`, and `COMMITTED_*`.
   - If tooling wants to preserve decoded version metadata for audit or for verifier-local routing, it SHOULD do so as exact supporting evidence (for example via `CH-AREF` or verifier-local policy artifacts) rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable firmware-version schema.
   - Exporting a report that carries those fields does not imply that remote consumers may treat them as reviewed SlopOS-native platform maturity, capability, or approval meaning.

7) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of already-existing provider-native SNP report metadata.
   - It introduces no new workflow kind, no version-discovery service, no verifier-capability negotiation API, and no portable firmware-version registry.

## Phase 1 non-goals (explicitly deferred)

- No `report_version`, `firmware_version`, or `committed_version` field in `CH-ATTEST v0`.
- No portable SlopOS security-tier, capability-level, or approval taxonomy derived from SNP report/firmware version metadata.
- No portable parser-negotiation or “artifact selects verifier semantics” rule.
- No new workflow / ACP / conflict-key family for firmware-version discovery or approval in v0.

## Why this boundary exists

The archive had already fixed most of the obvious SNP trust seams, but one implementation fork remained likely:
- AMD reports exact report/firmware version metadata,
- hosted verifier / secret-release / rollout systems naturally want minimum-version rules,
- and version numbers are a classic place where local operational policy quietly turns into portable product folklore.

Without one explicit rule, Phase 1 code would predictably drift into one of these by convention:
- treating exact `CURRENT_*` / `COMMITTED_*` values as a portable SlopOS “approved platform generation” claim,
- using report `VERSION` or provider firmware versions as a hidden policy selector,
- silently substituting local firmware-version allowlists for explicit TCB / boot / binder / freshness checks,
- or letting the report’s own version metadata choose which parser or semantics are in force.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, exact `cc_report_data_v0`, and explicit verifier-local policy**, 
- **SNP report / firmware version metadata remains exact evidence unless explicit verifier-local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a portable firmware-version or capability schema**,
- and **automation cannot inherit a hidden provider-version approval lane through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact SNP version metadata for audit or remote-secret release without turning one provider’s firmware versioning scheme into a portable workstation trust/profile label.
- **Cloud micro-VM substrate (B):** hosted-compute verifiers may impose exact parser/floor rules under explicit local policy, but they do not get a portable SlopOS platform-generation or approval taxonomy from one provider’s version fields.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling can retain exact report/firmware version bytes for audit without importing cloud-provider firmware taxonomy as the appliance’s native attestation semantics.
- **Agent / automation OS (D):** agents can inspect exact version metadata, but they do not get a silent “CURRENT_MAJOR high enough, therefore approved” shortcut; any such appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc is a **member of the closed D-CC companion family** indexed by `confidential-computing-boundary-index.md`.
It is therefore **not** an intentional singleton under `boundary-family-map.md`.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-boundary-index.md`
  - `confidential-computing-snp-tcb-field-claim-boundary-v0.md`
  - `confidential-computing-snp-measurement-claim-boundary-v0.md`
  - `confidential-computing-snp-signing-metadata-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_version_metadata_claim_boundary.py` (**EVID-2026-550**).

## References

- REF-AMD-SNP-FWABI.
- REF-RATS-RFC9334.
