# Host↔guest channel posture v0 (no ambient host channels in `ext.microvm`)

Purpose: pin the Phase‑1 meaning of **host↔guest communication channels** under `ext.microvm` so “helpful virtualization devices” do not become an ambient authority surface.

This is a *meaning pin* attached to D-MICROVM’s “no hidden host channels” rule: it makes the exclusions explicit and keeps sealed‑compat killable.

## Posture (v0)

When `cfg.feature_flags` includes `ext.microvm`:

1) **No ambient host↔guest transports**
   - v0 MUST NOT expose a general host↔guest transport as an ambient API surface.
   - In particular, **virtio‑vsock** (AF_VSOCK) MUST be **disabled** as an in‑guest syscall surface in Phase 1.

2) **No host filesystem sharing devices**
   - v0 MUST NOT expose host directory trees in‑guest.
   - In particular, **virtio‑fs** and **9p/virtfs** style “shared folder” devices are **disallowed** in Phase 1.

3) **No implicit host control plane**
   - The microVM profile MUST NOT rely on an implicit “host agent” channel for policy or capability changes.
   - Any mutation of policy/authority MUST route through explicit IF surfaces and produce transcript-visible receipts.

4) **Allowed v0 device classes do not add ambient channels**
   - v0 may use virtio devices for **block** and **network** transport, but these MUST NOT create ambient authority inside the guest:
     - Network effects remain portal-issued leased authority (D-NETLEASE); there is no ambient socket/DNS surface.
     - Block devices are treated as sealed images; they do not imply host path access.

5) **Interop must be explicit + killable (future admission rule)**
   - If we later admit host↔guest transports (vsock-like) or host FS sharing, the interface MUST:
     - be **lane-gated** (killable by policy),
     - be expressed as an explicit portal/lease seam (no ambient constructors), and
     - carry D-COMMUTE metadata (conflict keys + ordering) for any externally visible mutating action.

## Phase 1 non-goals (explicitly deferred)

- No “host agent” protocol design in v0 (vsock control planes, guest management daemons).
- No virtio‑fs / 9p / shared-folder semantics (requires an explicit portal/lease design and sealed-compat review).
- No in‑guest vsock APIs for “fast local calls” (requires a capability/lease model and covert-channel review).

## Wiring

- Decision surface: D-MICROVM in `decision-map.md` (this doc pins part of “no hidden host channels”).
- Primary posture: `microvm-profile-posture-v0.md` (calls out the exclusion set; Phase 1 scope discipline).
- Related postures:
  - `network-lease-posture-v0.md` (D-NETLEASE; “virtio-net exists” does not imply ambient sockets/DNS)
  - `observation-export-posture-v0.md` (D-OBS; export is pull-only and killable; avoid “console as ambient exfil”)
  - `microvm-console-channel-posture-v0.md` (serial/console debug plumbing remains off/null or output-only in Phase 1; no interactive host input or monitor multiplex under `ext.microvm`)
  - `microvm-bootstrap-metadata-posture-v0.md` (no ambient guest-readable metadata/bootstrap channel under `ext.microvm`; no MMDS / IMDS / fw_cfg / config-drive / cloud-init datasource contract in Phase 1)
  - `microvm-backend-offload-posture-v0.md` (host-side `vhost-user` / vDPA / VDUSE backend plumbing remains implementation-local; no portable backend socket/control plane under `ext.microvm`)
  - `microvm-usb-redirection-posture-v0.md` (client-device USB forwarding remains implementation-local; no portable `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane under `ext.microvm`)
  - `microvm-virtio-serial-port-posture-v0.md` (console-adjacent helper channels remain implementation-local; no portable `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane under `ext.microvm`, and reviewed console / transfer / guest-helper meaning stays on already-pinned explicit seams)
  - `microvm-clipboard-dragdrop-posture-v0.md` (desktop clipboard / drag-drop helper integration remains implementation-local; no portable shared-clipboard / drag-drop / guest-tools file-transfer plane under `ext.microvm`, and reviewed transfer meaning stays on explicit D-PLUMB seams)
  - `microvm-display-input-posture-v0.md` (guest-visible display/input devices such as `virtio-gpu` / `virtio-input` remain non-portable and do not become ambient host UI/control channels under `ext.microvm`)
  - `microvm-shared-memory-doorbell-posture-v0.md` (guest-visible ivshmem/shared-memory/doorbell devices remain non-portable and do not become ambient host↔guest or guest↔guest channels under `ext.microvm`; reviewed shared-region meaning stays on explicit D-IOBUF / D-PLUMB seams)
  - `microvm-paravirt-enlightenment-posture-v0.md` (guest-visible KVM / Hyper-V / Xen paravirtual-enlightenment ABIs remain non-portable and do not become ambient timing, interrupt, or coordination channels under `ext.microvm`; reviewed meaning stays on already-pinned explicit seams)
  - `microvm-semihosting-posture-v0.md` (guest-visible semihosting remains non-portable and does not become an ambient host file / debugger-console / command / time channel under `ext.microvm`; reviewed file / console / time / bootstrap meaning stays on already-pinned explicit seams)
  - `microvm-guest-agent-posture-v0.md` (guest-agent helpers such as QEMU Guest Agent / Hyper-V integration services / VMware Tools remain non-portable and do not become an ambient host exec / file-copy / metadata / heartbeat / time-sync / quiesce plane under `ext.microvm`; reviewed lifecycle / file / observation / time meaning stays on already-pinned explicit seams)
  - `seal-posture-v0.md` (D-SEAL; post-seal authority widening requires an explicit reconfiguration action)
- Sealed compat honesty: any future host↔guest interop must remain killable and must not introduce ambient `path/env/net` channels.
- CI drift gate: `tools/check_host_guest_channel_posture.py` (EVID-2026-230).

## References

- REF-FIRECRACKER-VSOCK
- REF-CHYP-VSOCK
- REF-LINUX-VSOCK-MAN7
- REF-VIRTIOFS-DESIGN
- REF-LINUX-VIRTIOFS
