# Lease adjunct index (closed `*-lease-posture-v0.md` posture family)

Purpose: keep the current **leased-authority posture family** recoverable as one closed discovery surface.
Why this exists:
The archive already has `capability-lease-posture-v0.md` as the generic **D-LEASE** meaning pin and several specialized `*-lease-posture-v0.md` docs for portalized/network/device/location/background/inhibit/attention cases, but humans/LLMs should not have to rediscover that family by scanning scattered posture rows and portal notes.

This doc does **not** create a universal lease manager, a new D-LEASE schema, or a broader portal taxonomy. It keeps the current `*-lease-posture-v0.md` family closed, enumerable, and reviewable as one implementation-facing surface for shapes **A/B/D** while leaving request-state honesty and profile **C** free to stay on their own narrower seams.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is a `*-lease-posture-v0.md` doc under `docs/30-architecture/` that pins some bounded **leased-authority** or explicit “lease-like but still non-authoritative” posture;
2) it is a posture doc, not an adjacent schema/result/boundary surface (for example `network-lease-schema-v0.md`, `io-lease-schema-v0.md`, `background-lease-schema-v0.md`, `inhibit-lease-schema-v0.md`, `network-request-state-posture-v0.md`, `background-request-state-posture-v0.md`, `lease-descriptor-state-boundary-v0.md`, and `attention-durable-interrupt-boundary-v0.md` stay adjacent);
3) its meaning is about portable lease semantics or a specialized leased workflow, not merely a neighboring surface that happens to mention TTLs or revocation.

## Closed leased-authority posture set (Phase 1)

### 1) Generic lease semantics and proxy-authority discipline

| Doc | One-line pinned meaning |
|---|---|
| [`capability-lease-posture-v0.md`](capability-lease-posture-v0.md) | leases are proxy authority; no raw capability export, no unbounded renewal, no ambient time authority |
| [`attention-lease-posture-v0.md`](attention-lease-posture-v0.md) | urgent interruption stays a policy-gated CH-NOTIF hint; no dedicated attention-lease descriptor or exportable urgent capability |

### 2) Portalized resource and environment leases

| Doc | One-line pinned meaning |
|---|---|
| [`network-lease-posture-v0.md`](network-lease-posture-v0.md) | no ambient sockets/DNS; networking exists only as portal-issued leased authority |
| [`location-lease-posture-v0.md`](location-lease-posture-v0.md) | location stays manual-only, coarse-first, and non-persistent |
| [`io-lease-posture-v0.md`](io-lease-posture-v0.md) | device access stays manual-only via `portal.device.*`; no ambient device namespace; consent receipts required |

### 3) Presence, session-transition, and persistence-adjacent leases

| Doc | One-line pinned meaning |
|---|---|
| [`background-lease-posture-v0.md`](background-lease-posture-v0.md) | background/autostart stays explicit, review-bound persistence; no silent widening; prefer D-JOBS for deferrable work |
| [`inhibit-lease-posture-v0.md`](inhibit-lease-posture-v0.md) | inhibit leases are live, close-to-release, current-session scoped, and manual-only; not a persistence or scheduling surface |

## Review rule

When a new `*-lease-posture-v0.md` doc appears, either:

- add it here **in the same revision**, or
- rename/re-scope it so it clearly belongs to some other existing discovery surface.

If a future change needs a different family rule than “current `*-lease-posture-v0.md` docs,” that widening must be made explicit in the same revision with matching README / posture-index / runbook / decision-map / evidence wiring.

## Wiring

- Generic lease anchor: `capability-lease-posture-v0.md`.
- Portal taxonomy: `portal-family-registry.md`.
- Adjacent workflow/posture surfaces: `job-portal-posture-v0.md`, `portal-session-posture-v0.md`, `request-state-adjunct-index.md`, `attention-durable-interrupt-boundary-v0.md`, `lease-descriptor-state-boundary-v0.md`.
- Decision surfaces: `decision-map.md` (**D-LEASE**, **D-NETLEASE**, **D-LOCLEASE**, **D-IOLEASE**, **D-BGLEASE**, **D-INHIBITLEASE**, **D-ATTN**).
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_lease_adjunct_index.py` (**EVID-2026-523**).
