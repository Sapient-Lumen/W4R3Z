# D-CAPTURE posture v0 (manual-only; indicator-bound; non-persistent)

Purpose: pin an **implementable Phase 1** meaning for D-CAPTURE so camera/microphone/screencast/remote-desktop capture stays explicit, attributable, and reviewable.
It narrows a high-risk seam into portal-mediated live sessions rather than a remembered/background capture substrate.

This doc is intentionally narrow: it does **not** design a full media stack, a remote-support product, or a background recording service.

## Posture (v0)

1) **No ambient capture constructors**
   - If D-CAPTURE is enabled, post-init components obtain camera/microphone/screencast/remote-desktop capture only via `portal.capture`.
   - There is no ambient audio-server socket, global screen-readback API, raw device shortcut, or compatibility backdoor that yields capture after init.
   - The seam remains fail-closed behind `cfg.params.lane.portal.capture`.

2) **Manual-only v0; every start is interactive**
   - `portal.capture.*` remains **manual-only v0** on the ACP surface.
   - Phase 1 does **not** introduce a `portal.capture.request` automation kind.
   - Starting capture requires an explicit interactive portal workflow; there is no headless/background start path in v0.

3) **Indicator-bound live sessions**
   - Active capture implies a non-spoofable shell/portal indicator; requester-controlled UI is insufficient.
   - Indicator state is part of the contract for camera, microphone, screencast, and remote-desktop sessions.
   - When remote-desktop includes input injection, the injection side still follows D-UIAUT posture; capture descriptors do not weaken that split.

4) **Non-persistent in Phase 1**
   - Phase 1 keeps capture sessions **live and non-persistent**.
   - The archive does **not** claim restore-token / remembered-session semantics, permissions that outlive the active session, or background relaunch/resume after app death, logout, or reboot.
   - If persistence is ever needed, it must return as a separate RFC/evidence pass rather than sneaking in through `CH-CAPTURE` metadata.

5) **Scope escalation and renewal remain explicit**
   - Renewal, duration extension, or scope escalation (for example `window -> monitor`, adding microphone to screencast, or widening remote-desktop rights) requires a fresh portal decision and transcript-visible event.
   - Capture is not a hidden “sticky once approved” grant.

6) **No silent persistence via adjacent seams**
   - D-CAPTURE is not a substitute for D-BGLEASE, D-JOBS, or D-INHIBITLEASE.
   - Capture grants do **not** imply background execution, autostart, scheduling, keep-awake, network egress, or durable storage authority for the requestor.
   - Any needed companion authority must be granted separately and remain killable by policy.

7) **Externally visible actions stay ordered inside the portal**
   - Even without an ACP kind in v0, capture session state is **ordered** within the portal because active-session state, indicators, renewal, and revoke/close semantics live there.
   - Serialization boundary: `svc:portal.capture`.
   - Any future ACP surface must keep conflict keys and retry semantics explicit rather than inheriting hidden state from media-server callbacks.

8) **Descriptors stay descriptive, not resumptive**
   - `CH-CAPTURE` remains a bounded descriptor for attribution, bounds, and receipt/audit surfaces.
   - It is **not** authority, does not carry resume/restore tokens, and must not become a hidden session-resumption substrate.
   - Observation/export paths should treat `CH-CAPTURE` as sensitive metadata and prefer redaction/hash-only views by default.

## Phase 1 non-goals (explicitly deferred)

- **No ACP automation kind** for `portal.capture.*` in Phase 1.
- **No restore-token / remembered-session semantics** in the core archive.
- **No background/headless capture start** or relaunch-after-reboot/logout claim.
- **No clipboard/remote-control widening by implication**; remote-control/input rights still require explicit D-UIAUT posture.

## Wiring

- Decision surface: `decision-map.md` (D-CAPTURE).
- Schema:
  - `capture-session-schema-v0.md` (CH-CAPTURE v0)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.capture.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.capture`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-CAPTURE-1..3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-CAPTURE-VALIDATE, PO-CAPTURE-ENF)
- Adjacent surfaces:
  - `microvm-audio-capture-posture-v0.md`

CI drift gate:
- `tools/check_capture_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “manual-only / indicator-bound / non-persistent” constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-SCREENCAST.
- REF-XDG-PORTAL-REMOTEDESKTOP.
- REF-XDG-PORTAL-CAMERA.
- REF-ANDROID-MEDIAPROJECTION.
- REF-APPLE-SCREENCAPTUREKIT.
- REF-APPLE-CONTROL-CENTER-PRIVACY.
