# D-CRYPTOSVC key-lifecycle boundary v0 (no portable key generate / rotate / delete seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable key generation, rotation, deletion, activation, alias-retargeting, or lifecycle-admin workflow.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable key-lifecycle/admin seam in v0**
   - No portable `generate_key`, `generate_keypair`, `create_key`, `create_keypair`, `provision_key`, `persist_key`, `finalize_key`, `activate_key`, `deactivate_key`, `rotate_key`, `roll_key`, `replace_key`, `retarget_alias`, `set_default_key`, `rename_key`, `delete_key`, `destroy_key`, `archive_key`, `restore_archived_key`, `revoke_key`, `disable_key`, `enable_key`, `reissue_key`, `clone_metadata`, `copy_key_object`, or equivalent lifecycle/admin knob or result on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - Providers may internally create, rotate, rename, activate, revoke, archive, or destroy key objects during provisioning, enrollment, update, or hardware/provider-local maintenance, but those workflows remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret provider-local key-container naming, default-key rollover, alias rebinding, generation handles, or delete/archive helpers as requester-visible result schemas, durable receipt truth, or transcript-stable statements that one exact lifecycle transition crossed the IF-CRYPTOSVC seam.

2. **Key use is about already-held authority, not key lifecycle ownership**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff plus pinned CH-KEYPOL data, not about standardizing how callers mint new key objects, rotate a durable alias to new material, delete provider-held keys, or manage activation/default state until some backend agrees.
   - The closed op set may still include `sign`, `decrypt`, `derive`, and `attest`, but in Phase 1 that does **not** imply a portable key-generation API contract, an alias-rebinding/rotation workflow, or a generic delete/archive/admin plane on IF-CRYPTOSVC.
   - If reviewed lifecycle semantics matter, they must live on an explicit future provisioning/rotation/recovery seam with its own compatibility, downgrade, serialization, rollback, and evidence semantics.

3. **Lifecycle/admin is a second workflow, not generic crypto use**
   - Existing ecosystems really do split these surfaces. PKCS #11 exposes object creation / generation / destruction calls apart from sign/decrypt/derive use. Microsoft CNG exposes `NCryptCreatePersistedKey` and `NCryptDeleteKey` as separate key-storage operations. Apple exposes `SecKeyCreateRandomKey` and `SecItemDelete` as distinct generation/deletion workflows. Java splits key-pair generation from keystore entry management, and KMIP defines create/register/activate/revoke/destroy workflows as its own management protocol vocabulary.
   - Those can be useful product workflows, but they also allocate naming, rollover, ownership, retention, audit, deletion, fallback, and recovery semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden key-generator, alias-rotation broker, delete/archive helper, or provider-admin plane.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future key-lifecycle/admin seam must state its own conflict keys, commutativity, serialization point, rollback/recovery policy, retention semantics, naming/alias rules, and evidence plan explicitly rather than inheriting folklore from PKCS#11 object-management calls, CNG persisted-key APIs, Apple keychain item deletion, Java keystore mutation, or KMIP lifecycle verbs.
   - Until then, generic crypto use remains keyref/route-bound only; lifecycle/admin state changes stay hidden inside provider-local or deployment-local setup workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `generate_key`, `generate_keypair`, `create_key`, `rotate_key`, `replace_key`, `retarget_alias`, `set_default_key`, `delete_key`, `destroy_key`, `archive_key`, or equivalent lifecycle/admin knob/result on generic crypto use.
- No transcript-stable statement that a generic crypto-use call also created, rotated, deleted, archived, or renamed one exact key object for the caller.
- No provider-visible promise that durable alias rollover, default-key replacement, generation counters, or deletion semantics are portable substrate truth across providers.
- No shell/helper fallback that quietly promotes key use into a generate/rotate/delete/admin workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “if the key is missing, generate one on first sign”, “rotate the alias in place when the cert renews”, “delete the old key after attestation succeeds”, or “if the HSM route is unavailable, create a temporary software key and keep going.” Once those assumptions land in transcripts and automation, they become hard to retract and easy to misuse as ownership, rollback, or retention loopholes. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden lifecycle/admin plane. That matters for all four product shapes: workstation UX can still host explicit enrollment/renewal/revocation tooling without standardizing it as substrate meaning; hosted and embedded profiles avoid inheriting rollover/delete semantics they do not want; and agent tooling cannot mistake CH-KEYREF/CH-KEYPOL for permission to create, rotate, or destroy provider-held keys until a future workflow pays for that entropy explicitly.

## Profile effect (A–D)

- **Secure workstation (A):** explicit enrollment, renewal, revocation, or deletion helpers may still exist, but generic crypto use does not standardize generate/rotate/delete semantics as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake portable rollover/delete APIs that would become retention, provenance, and downgrade liabilities.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose key lifecycle/admin semantics they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to generate a new keypair, rebind a durable alias, rotate defaults, or delete provider-held keys; reviewed lifecycle stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_key_lifecycle_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable key-lifecycle/admin seam / key use is about already-held authority, not key lifecycle ownership / lifecycle-admin is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-605**).

## References

- REF-PKCS11-SPEC.
- REF-MICROSOFT-NCRYPT-CREATEPERSISTEDKEY.
- REF-MICROSOFT-NCRYPT-DELETEKEY.
- REF-APPLE-SECKEYCREATERANDOMKEY.
- REF-APPLE-SECITEMDELETE.
- REF-ORACLE-JAVA-KEYPAIRGENERATOR.
- REF-ORACLE-JAVA-KEYSTORE.
- REF-KMIP-SPEC.
