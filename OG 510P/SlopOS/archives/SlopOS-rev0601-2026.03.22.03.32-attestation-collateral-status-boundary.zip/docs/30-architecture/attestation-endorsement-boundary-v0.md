# Attestation endorsement/reference boundary v0 (verifier-local appraisal inputs; no exporter-side fetch/query plane)

Purpose: pin the Phase-1 meaning of **attestation endorsements and reference values** across **D-ATTEST**, **D-AREF**, and **D-NETLEASE** so the archive does not quietly overload attestation export into a portable endorsement-discovery, reference-value lookup, or latest-applicable control plane.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-ATTEST v0** answers *which boot/provenance binding this attester is exporting*.
- **CH-ATTESTPACK v0** answers *how those canonical CH-ATTEST bytes plus optional provider-native evidence are packaged for export*.
- **CH-AREF v0** answers *how large supporting artifacts may be pointed to by digest, with locators staying untrusted hints*.
- **Verifier-local appraisal policy** answers *which endorsements/reference values are trusted, applicable, fresh enough, and sufficient for a relying-party decision*.

## Posture (v0)

1) **Endorsements and reference values are verifier-local appraisal inputs, not attester-export truth.**
   - Phase 1 attestation export carries actual evidence about one attester event plus optional pointers to supporting material.
   - Whether endorsement material is trusted, applicable, current enough, or sufficient remains a verifier-local decision under explicit local policy.
   - An attester-exported pointer therefore does not become ambient truth merely because it appeared next to otherwise valid evidence.

2) **IF-ATTEST and CH-ATTESTPACK do not perform or imply live endorsement/reference retrieval.**
   - Phase 1 standardizes no attester-side fetch, discovery, chase, cache refresh, or background synchronization loop for endorsements/reference values.
   - Exporters may package exact supporting artifacts or exact digest pointers, but they do not become a live client for vendor APIs, CoSERV endpoints, certificate repositories, or cloud metadata services by default.
   - Any online retrieval remains explicit tooling above the authority substrate and must use already-pinned **D-NETLEASE** controls if network access is involved.

3) **`endorsement_aref_digests` are exact artifact hints only; applicability/freshness/latest semantics stay local.**
   - In **CH-ATTESTPACK v0**, `endorsement_aref_digests` may point to exact endorsement/reference artifacts through **CH-AREF v0**.
   - Those digests are packaging hints for bounded transport and audit; they do not mean “the right/latest applicable endorsement set”, “fetch this before verification succeeds”, or “replace local verifier inputs with these”.
   - Verifiers may ignore them, require a local allowlist, or substitute a locally curated set without changing the portable meaning of the attestation evidence.

4) **No native endorsement/reference inventory, query, or latest-applicable plane in v0.**
   - Phase 1 adds no native `lookup endorsements`, `discover reference values`, `show current applicable endorsements`, or `watch for updated endorsements` surface.
   - It also adds no standard aggregator, cache, or trust-distribution object for endorsement/reference material.
   - Any future discovery/query surface must return RFC-first with explicit subject model, trust roots, freshness rules, conflict keys, commutativity rules, serialization boundary, and evidence.

5) **CoRIM / CoSERV / vendor retrieval interop stays tooling-only and policy-killable.**
   - Ecosystem mechanisms for packaging or retrieving endorsements/reference values are useful interoperability inputs.
   - Phase 1 may import or emit those artifacts through tooling, but privileged-core meaning still rides on local verification policy and exact digests rather than on ambient network discovery.
   - Optional query/result APIs, aggregators, or vendor fetch protocols remain external tooling concerns and do not create a native attestation-discovery plane.

6) **No endorsement-driven auto-approval, secret-release shortcut, or install shortcut in v0.**
   - Endorsements/reference values help a verifier appraise evidence; they do not, by themselves, authorize secret release, install, boot, or admission.
   - Relying-party decisions still require explicit local policy over the complete evidence set, including freshness and trust-root context.
   - This keeps attestation endorsement material aligned with the already-pinned verification-verdict boundary rather than regrowing a hidden approval plane.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing attestation/export/evidence seams are interpreted.
   - Any future endorsement publication, mirror acknowledgement, cache invalidation, or synchronization workflow must pay for its own RFC, conflict keys, serialization story, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native endorsement/reference-value schema beyond importing existing external artifacts through **CH-AREF** or equivalent bounded packaging.
- No standard vendor-query or aggregator API.
- No “latest applicable endorsements” or “recommended reference values” semantics.
- No rule that an attester-selected endorsement set outruns verifier-local trust roots or freshness checks.
- No background synchronization, notification, or watch plane for endorsement/reference updates.

## Why this is worth pinning

The surrounding ecosystem is explicitly split:
- RFC 9334 places **Endorsements** and **Appraisal Policy for Evidence** on the verifier side of the attestation flow, distinct from Evidence and Attestation Results.
- the current RATS Endorsements draft makes endorsements/reference values additional verifier inputs rather than a new attester-export truth plane;
- CoRIM models endorsement/reference-value corpora as separate artifacts whose authority is added only when verifier matching succeeds;
- CoSERV is explicitly a query/result format for retrieving those artifacts from providers.

Pinning that split now prevents SlopOS from slowly reinventing a hidden vendor-fetch client, trust-distribution service, or latest-applicable endorsement cache under the names of attestation export or supporting evidence.

## Profile effect (A–D)

- **Secure workstation (A):** local tools may attach endorsement corpora for inspection, but laptops do not silently become vendor-fetch clients during attestation export.
- **Cloud micro-VM substrate (B):** fleets may mirror endorsement/reference corpora externally, yet admission and secret release remain verifier-local rather than attester-selected or metadata-service-driven.
- **Embedded / separation appliance (C):** verifiers stay small and deterministic; bounded bundled endorsements can be shipped offline without implying a network dependency.
- **Agent/automation OS (D):** agents may consume packaged endorsement/reference artifacts as evidence, but they cannot smuggle in “vendor says OK therefore proceed” authority through ambient discovery or latest-wins caches.

This doc is a **family member of the closed D-ATTEST companion boundary family** rooted at `attestation-boundary-index.md`.


## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATTEST**, **D-AREF**, **D-NETLEASE**.
- Adjacent meaning pins:
  - `docs/30-architecture/attestation-posture-v0.md`
  - `docs/30-architecture/attestation-pack-schema-v0.md`
  - `docs/30-architecture/artifact-resolution-posture-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
- Engineering / profile surfaces:
  - `rfcs/0064-confidential-computing-profile.md`
  - `docs/30-architecture/interface-registry.md`
- Assurance anchors:
  - **I-ATTEST-1**, **I-AREF-1**.
  - **PO-ATTEST-VERIFY**, **PO-AREF-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_attestation_endorsement_boundary.py` keeps the split small and discoverable (**EVID-2026-463**).

## References

- **REF-RATS-RFC9334**
- **REF-RATS-ENDORSEMENTS-DRAFT**
- **REF-CORIM-DRAFT**
- **REF-COSERV-DRAFT**
