# D-LOCLEASE posture v0 (manual-only; coarse-first; no persistent tracking)

Purpose: pin an **implementable Phase 1** meaning for D-LOCLEASE so location stays explicit, bounded, and reviewable.
It narrows a privacy-heavy seam into something the workstation and agent profiles can reason about without quietly importing mobile-style “always track me” background behavior.

This doc is intentionally narrow: it does **not** design a full sensor-fusion stack, a geofence scheduler, or a provider-specific geolocation service API.

## Posture (v0)

1) **No ambient location constructors**
   - If D-LOCLEASE is enabled, post-init components obtain location only via `portal.location` (manual workflow).
   - There is no ambient global location API, host service shortcut, or ACP automation kind for location in Phase 1.

2) **Manual-only v0; one-shot and foreground updates first**
   - Phase 1 keeps `portal.location` **manual-only v0**.
   - The portal may issue one-shot samples and bounded foreground update sessions.
   - The portal family remains fail-closed behind `cfg.params.lane.portal.location`.

3) **Coarse-first; precise is explicit and purpose-bound**
   - **Coarse-first** is the expected v0 posture.
   - Requestors must ask for an accuracy class explicitly, and policy may clamp `precise` down to `coarse`.
   - `precise` is justified only for foreground, user-legible workflows that actually need it; it is not the default automation posture.

4) **No persistent tracking seam in Phase 1**
   - Phase 1 does **not** claim durable background location, `background="always"`, or geofence wakeups as an active product surface.
   - The wider CH-LOCLEASE vocabulary remains reserved schema space, but A–D profiles should treat persistent tracking states as policy-denied until a future RFC/evidence pass justifies them.
   - D-LOCLEASE is not a substitute for D-BGLEASE or D-JOBS.

5) **No implicit network authority**
   - Location grants do **not** imply outbound network or resolver authority for the requestor.
   - If provider lookups need networking, that authority stays inside the portal/service boundary and is metered/policy-scoped there.

6) **Indicators and transcript are part of the contract**
   - Continuous foreground updates imply a non-spoofable shell indicator/status surface.
   - Grant/renew/revoke decisions remain transcript-visible and may bind to CH-AUTHZ/CH-RECEIPT (and CH-VOL when policy requires fresh consent).
   - Observation/export paths should treat CH-LOCLEASE as sensitive metadata and prefer redaction/hash-only views by default.
   - Historical CH-LOCLEASE descriptors remain exact grant-bounds evidence rather than a portable “location is still live now” oracle (`lease-descriptor-state-boundary-v0.md`).

7) **Externally visible actions stay ordered inside the portal**
   - Even without an ACP kind in v0, location grant/renew/revoke state is **ordered** within the portal because active lease state, rate clamps, and indicator state live there.
   - Serialization boundary: `svc:portal.location`.
   - Any future ACP surface must keep conflict keys and retry semantics explicit rather than inheriting hidden state from provider callbacks.

8) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell use of location must flow through explicit adapters and `portal.location`; compat runtimes do not gain an ambient geolocation channel.
   - The seam remains policy-killable and review-bound.

## Phase 1 non-goals (explicitly deferred)

- **No ACP automation kind** for `portal.location.*` in Phase 1.
- **No durable background tracking** or `background="always"` posture as a claimed product surface.
- **No geofence wakeup/scheduler semantics** that relaunch code later or wake a dormant domain.
- **No provider-specific API surface** in the core archive; backend/provider details stay out of the authority contract.

## Wiring

- Decision surface: `decision-map.md` (D-LOCLEASE).
- Schema:
  - `location-lease-schema-v0.md` (CH-LOCLEASE v0)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.location.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.location`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-LOCLEASE-1..3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-LOCLEASE-VALIDATE, PO-LOCLEASE-ENF)

CI drift gate:
- `tools/check_loclease_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “manual-only / coarse-first / no persistent tracking” constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-LOCATION.
- REF-ANDROID-LOC-PERMS.
- REF-ANDROID-LOC-BACKGROUND.
- REF-APPLE-LOCATION-PRECISE.
- REF-GEOCLUE-DBUS.
