# D-PLUMB OpenURI content-type boundary v0 (no portable MIME / UTI / sniff/classification seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable content-type, MIME, UTI, sniffing, or handler-by-type surface on `portal.uri.*`.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1. **No portable content-type / MIME / UTI / sniff seam in v0**
   - Phase 1 does **not** export a portable `content_type`, `mime_type`, `declared_mime_type`, `sniffed_mime_type`, `sniff_content`, `probe_head`, `uti`, `uniform_type_identifier`, `preferred_content_type`, `expected_content_type`, `accept_content_types`, `open_as_type`, `resolved_content_type`, `resolved_uti`, or equivalent type-classification field on `portal.uri.*`.
   - A shell, browser, activity resolver, Launch Services database, or chosen handler may still classify bytes, honor a declared MIME type, sniff content, or route by a local content-type registry, but those choices remain provider-local rather than portable portal truth.
   - Phase 1 does **not** reinterpret local classification or type-routing decisions as a requester-visible result, stable receipt, or transcript-stable statement that the launched resource was of a particular MIME/UTI/class.

2. **Type classification stays provider-local rather than portal truth**
   - Generic OpenURI is about *admission of a mediated launch*, not portable byte classification, MIME sniffing, Launch Services type binding, or app-resolution by declared/derived content type.
   - Local UX may still use handler manifests, HTTP metadata, file extensions, local type databases, or sniffing heuristics as part of provider-local routing.
   - Phase 1 therefore does **not** reinterpret generic launch as authority to demand or receive that classification logic on the requester’s behalf.

3. **Why this boundary exists**
   - Existing ecosystems really do expose these knobs. The WHATWG MIME Sniffing Standard defines algorithms for determining resource types from bytes and metadata. Android documents `Intent.setType()` / `setDataAndType()` and resolver behavior keyed by MIME type. Apple exposes application lookup and role-handler binding for content types through NSWorkspace / Launch Services.
   - Those are valuable local platform APIs, but they are also exactly the kind of fetch-shaped, registry-shaped, and handler-resolution semantics that would make `portal.uri.*` drift into a hidden classification oracle or preflight broker if imported casually.
   - Pinning the boundary now keeps workstation UX flexible without forcing cloud, embedded, or agent profiles to inherit fake MIME/UTI/sniff contracts as portable substrate meaning.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future reviewed fetch/classification seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from MIME sniffers, app registries, or resolver databases.
   - Until then, generic `open_uri` remains admission-scoped only; content-type resolution stays hidden inside provider-local launch implementation.

5. **Classification is a second workflow, not generic launch**
   - If SlopOS ever needs reviewed content-type probing, MIME/UTI classification, or type-constrained launch selection, that work should return as a **separate RFC-first workflow/surface** with explicit authority, profile gating, transcript semantics, and policy kill switches.
   - It must not arrive by adding “just one more MIME field” to generic `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `content_type`, `mime_type`, `uti`, `sniff_content`, `probe_head`, `resolved_content_type`, or equivalent type-classification knob/result on generic OpenURI.
- No transcript-stable statement that the launched subject was classified as a particular MIME/UTI/type.
- No importer-visible MIME-sniffing / handler-by-type folklore on the D-PLUMB seam.
- No shell/helper fallback that quietly promotes `open_uri` into a preflight classification or type-resolution workflow and reports that second workflow as generic OpenURI truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, agents and wrappers quickly start depending on guessed type resolution semantics like “open this only if it sniffs as PDF,” “tell me what MIME the handler saw,” or “route this URI as markdown.” Once those assumptions land in transcripts, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning mediated launch into content classification authority. That matters for all four product shapes: workstation UX can still use local type registries and shell integration without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting fetch/sniff/type machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to demand MIME/UTI truth.

## Profile effect (A–D)

- **Secure workstation (A):** shells, browsers, and handler registries may still do rich local type resolution, but generic OpenURI does not standardize MIME/UTI/sniff outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake MIME/UTI/sniff contracts or preflight fetch/classification obligations they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising general-purpose type sniffing or handler-by-type workflows they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with permission to demand `content_type`, `mime_type`, `uti`, or sniff results; reviewed classification control stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/intent-kind-registry.md`
- `docs/30-architecture/effect-contract-schema-v0.md`
- `docs/60-engineering/cli-plumbing-tooling.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_openuri_content_type_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable content-type/MIME/UTI/sniff seam / type classification stays provider-local / classification is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-591**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-WHATWG-MIME-SNIFFING.
- REF-ANDROID-INTENTS-DATA-AND-TYPE.
- REF-APPLE-NSWORKSPACE-URLSFORAPPLICATIONS-TOOPEN-CONTENTTYPE.
- REF-APPLE-LSCOPYALLROLEHANDLERSFORCONTENTTYPE.
