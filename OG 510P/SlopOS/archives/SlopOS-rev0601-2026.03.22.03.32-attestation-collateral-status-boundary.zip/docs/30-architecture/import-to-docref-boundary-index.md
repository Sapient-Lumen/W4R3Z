# Import→docref boundary index (v0)

Purpose: keep the **closed set of D-CAPX / D-PLUMB / D-QUAR import→docref companion boundary docs** enumerable.

Why this exists:
- the archive already pins a small bearer→document bridge family so explicit CH-SREF / CH-CAPX import does not quietly widen CH-DOCREF,
- those `import-to-docref-*-boundary-v0.md` docs are individually crisp but easy to forget piecemeal because they span bridge shape, object identity, and provenance breadcrumbs,
- `capx-posture-v0.md`, `sturdyref-posture-v0.md`, and `document-portal-posture-v0.md` keep the surrounding seams honest, while this index is the **discovery surface** that says which companion boundaries currently keep bearer restore/import explicit, fresh-object-first, quarantine-first, and non-bearer on reopen.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `capx-posture-v0.md`, `sturdyref-posture-v0.md`, `document-portal-posture-v0.md`, and the import bridge docs themselves.

## Inclusion rule

A doc belongs here if it removes exactly one tempting Phase-1 meaning from the CH-SREF / CH-CAPX → CH-DOCREF bridge by constraining one of:
- how explicit bearer restore/import crosses into routine document workflows,
- how local object identity is minted when imported bytes already exist locally,
- how import provenance is retained without leaking raw bearer material or hidden refresh authority.

If future work needs a new native portal/schema/workflow instead, that work must return **RFC-first** as its own decision surface rather than hiding behind bearer→docref convenience semantics.

## Closed companion boundary set (Phase 1)

### 1) The bridge stays explicit, local, and quarantine-first

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`import-to-docref-boundary-v0.md`](import-to-docref-boundary-v0.md) | bearer restore/import → local doc workflow bridge | a workflow that starts from CH-SREF / CH-CAPX must first materialize a **fresh local object**, classify it as outside-world input, and only then mint a provider-local CH-DOCREF; reopen stays local and non-bearer | explicit D-CAPX / gateway action for any later fetch/sync/write-back |

### 2) Equal bytes do not collapse object identity or trust state

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`import-to-docref-fresh-identity-boundary-v0.md`](import-to-docref-fresh-identity-boundary-v0.md) | object identity on import/materialize | the bearer→docref bridge is **fresh-object-identity-first**; equal bytes do not justify `reuse_existing`, cache-hit docref reuse, or inherited quarantine/trust state | storage dedupe only below the object boundary |

### 3) Provenance stays digest-only and non-secret

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`import-to-docref-bearer-provenance-boundary-v0.md`](import-to-docref-bearer-provenance-boundary-v0.md) | import breadcrumb retention | imported fresh local objects may record one exact `origin.import_ref_digest` as digest-only evidence of the accepted bearer handoff; routine metadata never stores raw bearer bytes/capability URLs or hidden refresh instructions | explicit D-CAPX / CH-SREF handling for any bearer-bearing workflow |

## Review rule

Before adding another import→docref companion boundary doc, answer these questions in order:
1) Is the change really an **import→docref meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
