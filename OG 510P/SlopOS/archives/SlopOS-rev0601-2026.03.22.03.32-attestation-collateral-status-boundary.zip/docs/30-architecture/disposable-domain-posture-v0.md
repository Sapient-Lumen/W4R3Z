# D-EPHEM posture v0 (disposable means fresh, explicit, and continuity-free)

Purpose: pin an **implementable Phase 1** meaning for D-EPHEM so “open in disposable” and one-shot sandboxes become a small,
reviewable posture rather than a vague promise of “some temporary VM/process thing.”
It narrows the existing RFC into something worth coding: D-EPHEM remains a **user-space posture** layered on existing domain isolation,
views, portals, leases, D-SEAL, and D-CAPMODE; fast spawn is allowed, but only when template identity is pinned and clone-state hygiene stays explicit.

This doc answers the highest-entropy question in the seam:
**what acceleration is allowed without smuggling persistence, identity, or ambient channels back in?**
Phase 1 answers: **digest-pinned templates are allowed; hidden continuity is not**.

## Posture (v0)

1) **D-EPHEM is a posture, not a new privileged spawn primitive**
   - If D-EPHEM is enabled, the privileged core still exposes only the existing domain/process/isolation primitives for the active profile.
   - Phase 1 adds **no generic kernel/admin/API plane** for “spawn disposable.”
   - Disposable creation remains a supervisor/runtime/user-space composition over pinned templates, views, routes, and teardown.

2) **Fast spawn is allowed only from digest-pinned templates**
   - User-space template spawners, preloaded queues, fork/clone-from-template, and snapshot/restore accelerators are allowed.
   - The source template identity MUST be bound by digest (`digest(CH-INIT v0)` or `digest(CH-CKPT v0)`) in the controlling policy/configuration path.
   - Under `ext.microvm`, reusable warm-start templates are also pinned as **parent-bound, leaf-resumable derived accelerators** rather than public diff/base chains; callers consume one admitted leaf and do not reconstruct layer order themselves (`microvm-template-lineage-posture-v0.md`). Resume scope is pinned separately: each reusable leaf is only admissible on hosts in the same exact reviewed class, so heterogeneous fleets are normalized before the cut instead of via best-effort restore-time similarity (`microvm-template-resume-class-posture-v0.md`). Distribution is pinned separately too: reusable warm-start leaves and owner-local recovery checkpoints stay **owner-local admission accelerators**, so portable distribution ships cold parent lineage and each owner/runtime cuts/adopts warm leaves locally rather than importing shareable warm-state blobs (`microvm-template-distribution-posture-v0.md`). Availability is pinned separately as well: portable correctness must not depend on one specific warm leaf staying cached, because owners may evict or regenerate leaves locally without changing deployment identity and Phase 1 adds no public warm-cache hit/miss or `Pending` / `Active` / `Inactive` lifecycle plane (`microvm-template-availability-posture-v0.md`). After such a leaf is resumed, clone-sensitive repair completes before any externally visible action or readiness claim; old sessions/leases are not probed as a repair oracle (`microvm-restore-repair-barrier-posture-v0.md`).
   - “Warm disposable” must still mean “spawn from this exact reviewed template,” not “whatever helper process happened to be lying around.”
   - Companion target-selection boundary: callers may request disposable routing, but they still do not choose or discover the concrete template/domain target on the portable seam (`disposable-target-selection-boundary-v0.md`).

3) **Fresh-instance semantics beat reuse folklore**
   - A disposable is a **fresh one-shot instance**; once marked used, it MUST NOT be returned to any preload queue or recycled as a future disposable.
   - Preloaded/warmed instances MAY exist before first use, but they remain hidden/inert until bound to one concrete launch.
   - Destroying a disposable closes its lifetime; subsequent disposables are new instances even when they share the same template digest.

4) **Clone-state hygiene is part of the contract**
   - Template acceleration MUST NOT carry forward live durable handles, prior export grants, background/autostart leases, inhibit leases, or equivalent persistence/session state into the disposable.
   - Default network posture remains **no ambient network lease**; clone/snapshot restore MUST NOT imply live socket/vsock continuity or inherited connectivity.
   - Template snapshots/clones MUST refresh entropy/identity material before first user payload runs; “copied RNG state is good enough” is not a valid Phase 1 posture.
   - If the acceleration path uses `ext.microvm` snapshot/clone, guest-side detection of clone/restore is pinned separately in `microvm-generation-witness-posture-v0.md`; runtimes do not infer restore from broken sessions or other incidental fallout.

5) **Post-spawn narrowing remains one-way**
   - Any warmed template is treated as potentially over-privileged relative to the disposable it creates.
   - After spawn, view/routes are narrowed and the child enters D-SEAL and, where enabled, D-CAPMODE as a **one-way** transition.
   - Inheritance cannot widen authority after the disposable is activated.

6) **Persistence is export-only; disposal is deterministic**
   - Disposable writable state is ephemeral and MUST NOT be mounted into persistent shared/global stores.
   - Any state that leaves the disposable does so only through explicit portal/grant/export flows and remains transcript-visible.
   - Viewer-derived risky-open residue such as recent-doc entries, MRU state, thumbnails, autosave drafts, and crash-recovery blobs is treated as disposable writable state unless a separate explicit export/persistence seam says otherwise (`open-untrusted-viewer-residue-boundary-v0.md`).
   - Teardown revokes leases/handles and makes the disposable’s writable state unreachable except for explicitly exported artifacts.

7) **Phase 1 adds no generic automation surface for disposable spawn**
   - D-EPHEM v0 deliberately adds **no new ACP kind**, no generic disposable portal family, and no standalone reviewed admin plane.
   - Existing risky-open / safe-open workflows compose with D-EPHEM through their own portals/intents; D-EPHEM contributes an execution posture, not a second workflow protocol. For `intent.kind=open_untrusted`, callers do not choose template/reuse semantics; those remain policy-owned, and the viewer receives a request-local stable input object rather than a live alias/write-through mount back to the source (`open-untrusted-posture-v0.md`, `open-untrusted-materialization-boundary-v0.md`).
   - Because D-EPHEM v0 adds no new externally visible action family, it introduces **no new conflict-key family** in Phase 1.

8) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat runtimes may implement disposables only through explicit adapters and policy.
   - Compat must not reintroduce ambient path/env/network/session channels under the label “disposable.”
   - If a profile disables D-EPHEM, risky-open flows fail closed to the non-disposable policy path rather than silently widening into ordinary launches.

## Phase 1 non-goals (explicitly deferred)

- **No generic disposable-spawn portal / ACP action kind / inventory API**.
- **No promise of live socket/vsock/session continuity** across snapshot/clone restore.
- **No reuse of a used disposable as a later disposable**, even if the preload mechanism makes it tempting.
- **No privileged template manager** in the kernel/hypervisor core.
- **No hidden persistence fast path** that treats template-local caches, exported handles, or prior grants as “warm state.”

## Wiring

- Decision surface:
  - `decision-map.md` (D-EPHEM, D-QUAR, D-SEAL, D-CAPMODE, D-PLUMB)
- Related workflow / ecosystem notes:
  - `open-untrusted-posture-v0.md`
  - `quarantine-posture-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
- `disposable-target-selection-boundary-v0.md`
  - `system-generation-pipeline.md`
  - `microvm-template-lineage-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `microvm-template-distribution-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-EPHEM-1, I-EPHEM-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-EPHEM-RESET, PO-EPHEM-EXPORT)
- RFC history:
  - `rfcs/0050-disposable-domains-and-one-shot-sandboxes.md`
- Policy / kill-switch posture:
  - D-EPHEM introduces **no dedicated disposable portal lane or admin plane** in Phase 1; profiles and policy decide whether risky-open flows may use disposables, and no compat exception may create an ambient disposable path.

CI drift gate:
- `tools/check_disposable_domain_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **digest-pinned templates / fresh-instance semantics / no hidden continuity / no new generic automation plane** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-QUBES-DISPOSABLE-IMPL.
- REF-CHROMIUM-ZYGOTE.
- REF-ANDROID-ZYGOTE.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-FIRECRACKER-ENTROPY-CLONES.
