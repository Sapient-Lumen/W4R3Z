# D-NONDET entropy-request posture v0 (request key ≠ live entropy-handle state)

Purpose: close one small but expensive ambiguity on the D-NONDET entropy seam: **a bounded CH-ENTREQ request artifact is not the same thing as current portal-owned live entropy-handle state**.

The comparison archives repeatedly separated reviewed request identity from current system-owned mutable state. SlopOS should be at least that explicit here too: retries and review keys are useful, but they must not silently stand in for live entropy authority.

This doc is intentionally narrow. It does **not** add a new entropy-handle inventory API, a lease-status watcher, or a durable nondeterminism-state schema. It only freezes what CH-ENTREQ `req_id` does and does not mean in Phase 1.

## Posture (v0)

1) **`CH-ENTREQ.req_id` is requester-chosen request identity, not portal-issued live entropy-handle state**
   - `req_id` is a stable caller-chosen request key carried in the request descriptor so retries, replay harnesses, and ACP dedupe have one exact schema-pinned key.
   - It is **not** a portal-issued CH-ENTROPY handle, not a current provider session identifier, and not proof that a live entropy handle/lease still exists.

2) **Request presence is not current entropy-state truth**
   - The existence of CH-ENTREQ bytes (or an old `entreq_digest`) says only that a bounded request was formed/submitted.
   - It does **not** by itself mean an entropy handle is currently live, unexpired, unrevoked, unexhausted, or still acceptable under current portal policy.

3) **Current portal-owned entropy-handle state remains portal-local unless a future surface pays for it explicitly**
   - Active handle issuance, renewal, revocation, expiry, byte-budget exhaustion, and any “still live?” truth stay inside the `portal.entropy` service boundary in Phase 1.
   - If later work needs portable handle-status receipts, inventories, or watcher/update semantics, it must return RFC-first with its own schema, ordering, receipts, and assurance hooks.

4) **Dedupe/retry safety uses the request key only as a veto-only identity hook**
   - At-least-once-safe `portal.entropy.request` depends on a stable `CH-ENTREQ.req_id` so duplicate submissions can collapse before effect.
   - That dedupe key is still non-authoritative: it may suppress/reuse/reissue according to portal policy, but it never grants entropy authority by itself.

5) **Historical receipts do not reactivate current entropy authority**
   - A prior CH-ACPOUT / CH-LOG / CH-RECEIPT trail may prove that a request was reviewed or accepted at some point.
   - It does **not** imply that the corresponding entropy handle remains live after later revocation, expiry, exhaustion, policy tightening, or portal-local cleanup.

## Phase 1 non-goals (explicitly deferred)

- A portable inventory / enumerate-entropy-handles API.
- A portable receipt or watcher surface proving whether a request is currently pending, granted, revoked, expired, or exhausted.
- Treating CH-ENTREQ `req_id` as a portal-issued CH-ENTROPY handle or provider-session identifier.
- Letting historical CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts stand in for current portal-owned entropy-handle truth.
- Any hidden policy/query language that asks the portal for ambient “current entropy-handle state” during ACP validation.

## Why this earns its place

Without this split, the archive quietly collapses two different questions:
- **what exact request did we review/dedupe?**
- **what entropy-handle state exists right now inside the portal?**

That collapse would make retry safety, receipts, and replay/automation less honest. Phase 1 can stay small and still refuse the ambiguity.

## Wiring

- Decision surface:
  - `decision-map.md` (D-NONDET)
- Request / handle descriptors:
  - `entropy-request-schema-v0.md` (CH-ENTREQ v0)
  - `entropy-descriptor-schema-v0.md` (CH-ENTROPY v0)
- Portal semantics:
  - `nondet-posture-v0.md`
  - `portal-family-registry.md`
- ACP automation:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
- RFC / trajectory:
  - `rfcs/0063-nondeterminism-capabilities-clock-and-entropy.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (I-ENTREQ-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-ENTROPY-STATE)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`

CI drift gate:
- `tools/check_entropy_request_state_posture.py`

## References

- REF-OPENBSD-GETENTROPY.
- REF-SEL4-TIMEPROTECTION.
