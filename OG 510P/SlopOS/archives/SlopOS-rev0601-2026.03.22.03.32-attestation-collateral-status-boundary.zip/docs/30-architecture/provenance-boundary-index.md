# Provenance boundary index (v0)

Purpose: keep the **closed set of D-PCP / D-ATOMICUPD provenance companion boundary docs** enumerable.

Why this exists:
- the archive now pins several small provenance/update-adjacent companion boundaries so CH-PROV and CH-UPD do not quietly regrow into release-registry, policy-tier, proof-bundle, or closure folklore,
- those docs are individually crisp but easy to lose piecemeal because they span release identity, evidence-subject binding, proof-bundle labeling, and multi-artifact/container semantics,
- `provenance-posture-v0.md` and `update-posture-v0.md` keep the overall meaning of D-PCP / D-ATOMICUPD, while this index is the **discovery surface** that says which companion boundaries currently keep provenance/update meaning fail closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `provenance-posture-v0.md`, `update-posture-v0.md`, and RFC-0051.

## Inclusion rule

A doc belongs here if it removes exactly one tempting provenance/update-adjacent meaning from Phase 1 by constraining one of:
- release / role / label semantics that would otherwise smuggle in a native release-registry, latest-wins, proof-bundle, or approval plane,
- attached-evidence semantics that would otherwise widen the install/boot subject, select coverage policy, or redefine what exact cohort CH-UPD installs,
- multi-statement or multi-artifact packaging semantics that would otherwise smuggle in a native provenance union, fallback, completeness, or supersession rule.

If future work needs a new native publication, approval, query, or rollout surface instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind provenance metadata or update attachments.

## Closed companion boundary set (Phase 1)

### 1) Release and adjunct labels stay observational

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`release-identity-boundary-v0.md`](release-identity-boundary-v0.md) | release names / version strings / purls / slugs | imported release labels stay observational distribution identifiers rather than a native release-discovery, latest-wins, or install-authority plane | exact digest binding on CH-UPD / CH-BOOT plus explicit repository policy |
| [`proof-bundle-role-boundary-v0.md`](proof-bundle-role-boundary-v0.md) | `proof_bundle` role labels | imported `proof_bundle` labels stay descriptive adjunct-evidence roles rather than a native proof/verdict schema or recursive fetch plane | exact artifact digests plus explicit verifier-local policy |

### 2) Attached evidence may appraise the pinned cohort, but must not redefine it

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`update-evidence-subject-boundary-v0.md`](update-evidence-subject-boundary-v0.md) | supporting evidence subject scope | attached evidence may appraise the pinned `(target_root_digest, cfg_digest)` cohort but never widens or redefines what CH-UPD installs | exact CH-UPD install subject first, then local evidence evaluation |
| [`provenance-required-subject-boundary-v0.md`](provenance-required-subject-boundary-v0.md) | required provenance subject subset | stricter provenance requirements may select only exact already-pinned carrier digests rather than every subject in a larger release attestation | explicit local required-subject policy over the already-pinned cohort |
| [`provenance-coverage-policy-boundary-v0.md`](provenance-coverage-policy-boundary-v0.md) | provenance-coverage profile / tier hints | carrier-borne provenance fields pin exact evidence bytes only and do not choose which provenance-coverage policy is in force | explicit verifier-local coverage policy |

### 3) Multi-statement and multi-artifact provenance stays verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`provenance-container-selection-boundary-v0.md`](provenance-container-selection-boundary-v0.md) | multi-statement provenance containers | imported multi-statement provenance packaging stays packaging only; statement selection/reconciliation does not become native carrier meaning | explicit verifier-local statement selection |
| [`provenance-evidence-set-boundary-v0.md`](provenance-evidence-set-boundary-v0.md) | multiple provenance-bearing artifacts | several exact provenance-bearing artifacts stay several exact evidence inputs rather than one native provenance closure, fallback, or completeness rule | explicit verifier-local cross-artifact relation policy |

## Review rule

Before adding another provenance/update companion boundary doc, answer these questions in order:
1) Is the change really a **D-PCP / D-ATOMICUPD meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported provenance/update semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
