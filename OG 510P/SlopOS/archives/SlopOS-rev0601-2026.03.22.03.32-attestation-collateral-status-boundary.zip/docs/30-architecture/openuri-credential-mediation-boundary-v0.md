# D-PLUMB OpenURI credential-mediation boundary v0 (no portable credential / autofill / passkey seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable credential-provider, password-autofill, passkey, account-selection, or equivalent credential-mediation surface on `portal.uri.*`.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1. **No portable credential / autofill / passkey seam in v0**
   - Phase 1 does **not** export a portable `autofill`, `password_autofill`, `otp_autofill`, `passkey`, `passkey_assertion`, `passkey_registration`, `webauthn`, `navigator_credentials_get`, `navigator_credentials_create`, `credential_manager`, `credential_provider`, `federated_sign_in`, `conditional_mediation`, `immediate_mediation`, `prefer_immediately_available_credentials`, `account_selector`, or equivalent credential-mediation field on `portal.uri.*`.
   - A shell, browser, platform credential manager, autofill service, passkey provider, or chosen handler may still offer passwords, passkeys, or federated-login account choice locally, but those choices and outcomes remain request-local or provider-local rather than portable portal truth.
   - Phase 1 does **not** reinterpret local credential-provider/autofill/passkey mechanics as a requester-visible result, durable receipt, or transcript-stable statement that launch also invoked a credential broker, returned an account choice, or completed a passkey ceremony.

2. **Credential mediation stays on explicit auth/credential seams**
   - Generic OpenURI is about *admission of a mediated launch*, not about standardizing password entry, account-selection, passkey assertion/registration, or browser/OS credential-provider invocation.
   - If reviewed credential/autofill/passkey work matters, it must live on an explicit future auth/credential seam with its own authority, UX, privacy, and evidence semantics.
   - Phase 1 therefore does **not** reinterpret generic launch as authority to ask the platform for passwords, passkeys, federated-login choices, or autofill behavior on the requester’s behalf.

3. **Credential mediation is a second workflow, not generic launch**
   - Existing ecosystems really do expose these surfaces. WebAuthn defines user-agent-mediated access to public-key credentials scoped to the relying party. Android Credential Manager centralizes passkeys, passwords, and federated sign-in with provider mediation. Apple’s passkey stack routes sign-in through AutoFill / Authentication Services rather than treating it as a generic browser-launch side effect.
   - Those are valuable product workflows, but they also allocate extra account-selection, credential-provider, user-verification, and result-handling semantics that are not harmless synonyms for “open this URI”.
   - Pinning the boundary now keeps `portal.uri.*` from quietly widening into a hidden credential/autofill/passkey broker.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future credential/autofill/passkey seam must state its own conflict keys, commutativity, redaction, and evidence rules explicitly rather than inheriting folklore from browser login UX or platform credential managers.
   - Until then, generic `open_uri` remains admission-scoped only; credential mediation stays hidden inside provider-local auth/account workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `autofill`, `password_autofill`, `otp_autofill`, `passkey`, `passkey_assertion`, `passkey_registration`, `webauthn`, `credential_manager`, `credential_provider`, `federated_sign_in`, `conditional_mediation`, `immediate_mediation`, or equivalent credential-mediation knob/result on generic OpenURI.
- No transcript-stable statement that launch also invoked a password manager, passkey provider, account chooser, or credential broker.
- No importer-visible browser/OS credential folklore on the D-PLUMB seam.
- No shell/helper fallback that quietly promotes `open_uri` into a credential/autofill/passkey workflow and reports that second workflow as generic OpenURI truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, agents and wrappers quickly start depending on guessed semantics like “open this login page and ask the platform for credentials,” “launch this URI and complete the passkey flow,” or “return the chosen account/autofill result as part of launch.” Once those assumptions land in transcripts, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a hidden credential/autofill/passkey authority. That matters for all four product shapes: workstation UX can still use local password/passkey/account-selection tooling without standardizing it as app-visible substrate meaning; hosted and embedded profiles avoid inheriting fake login/account machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to invoke or depend on hidden credential-provider truth.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still use password managers, AutoFill, Credential Manager, or passkey UX locally, but generic OpenURI does not standardize those outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting ambient account-selection or passkey-provider contracts they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising general-purpose password/passkey/account-broker APIs they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with permission to demand `autofill`, `passkey`, `credential_provider`, or `credential_manager` results; reviewed credential mediation stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/intent-kind-registry.md`
- `docs/30-architecture/effect-contract-schema-v0.md`
- `docs/60-engineering/cli-plumbing-tooling.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_openuri_credential_mediation_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable credential / autofill / passkey seam / credential mediation stays on explicit auth/credential seams / credential mediation is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-594**).

## References

- REF-WEBAUTHN-3.
- REF-ANDROID-CREDENTIAL-MANAGER.
- REF-APPLE-PASSKEYS.
