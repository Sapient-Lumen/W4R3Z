# CH-BOOTSEL v0 (boot selector state, informal)

Purpose: standardize the *minimal* state required to support atomic updates with automatic fallback when a newly activated deployment fails to reach a healthy steady state.
Adjacency note: if **D-RECOVERY** is enabled, this schema may stage an explicit bounded trial boot around a recovery session, but the Phase 1 meaning pin in `recovery-posture-v0.md` still forbids treating hidden repeated-failure counters or undocumented repair-mode latches as portable recovery semantics.

This is the “A/B slot metadata” analogue: a small state machine that picks what to boot next, tracks bounded attempts, and commits a deployment as **last-known-good** (LKG) only after an explicit success mark.

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- bounded fields (no unbounded lists/strings)
- monotonic transitions (pending tries only decrease; commit requires explicit success)
- designed to be validated in IF-BOOT (or a bootloader/firmware layer) without importing a large policy engine

## Shape (v0)
A selector state `s` contains:
- `schema`: fixed `CH-BOOTSEL v0`

- `active_root_digest`: digest of the deployment root currently selected as “active”
- `lkg_root_digest`: digest of the last-known-good deployment root

- `pending`: optional object describing a candidate deployment that is being trial-booted:
  - `upd_digest`: digest of the authorizing `CH-UPD v0`
  - `target_root_digest`: digest of the candidate deployment root
  - `tries_remaining`: small integer (e.g., u8) decremented by the boot selector on each boot attempt
  - `policy`: optional (profile-defined) object controlling commit semantics (closed set)
    - MAY include `health_pred_digest`: digest of the required CH-HEALTH predicate for commit
    - example: `{ commit: "on_health", health_pred_digest: <digest> }` (default if D-HEALTH is enabled)

- `rollback_floor`: optional `{ counter_id, min_value }` (same shape as CH-BOOT)
  - meaning: if present and anti-rollback is claimed (I-BOOT-2), the selector MUST NOT choose any deployment that violates the floor.

Notes:
- `active_root_digest` and `lkg_root_digest` MAY be equal (steady state).
- `pending.target_root_digest` MUST differ from `active_root_digest` when present.
- `pending.upd_digest` is used for audit (linking the chosen deployment to a signed update intent).

## State machine (informal)
Typical transitions:

1) **Stage** (installer): write candidate deployment + install CH-UPD.
2) **Activate (pending)**: set `pending = {upd_digest, target_root_digest, tries_remaining=N}`.
3) **Boot attempt** (selector/IF-BOOT):
   - if `pending` exists: boot `pending.target_root_digest` and decrement `tries_remaining`.
   - if `tries_remaining == 0` and no success mark occurred: clear `pending` and set `active_root_digest := lkg_root_digest`.
4) **Mark success** (user space): if the system reaches the profile’s health milestone (CH-HEALTH), call a privileged “mark boot successful” operation that:
   - verifies `upd_digest` (or `target_root_digest`) matches the currently pending deployment
   - verifies the required `health_pred_digest` (if configured) matches the evaluated predicate
   - SHOULD emit a CH-HEALTHREC v0 record and log/bind its digest in the transcript (CH-LOG)
   - sets `lkg_root_digest := pending.target_root_digest`
   - sets `active_root_digest := pending.target_root_digest`
   - clears `pending`

All transitions SHOULD be transcript-visible (CH-LOG) and the chosen CH-BOOTSEL digest SHOULD be recorded in CH-BOOT `artifacts` under a stable role like `boot_selector`.

## Verification obligations
- decoding/validation is total; unknown variants reject deterministically (PO-BOOTSEL-VALIDATE)
- pending→committed is monotonic and requires an explicit success mark; decrement/rollback cannot be bypassed (PO-ATOMICUPD-COMMIT)
- rollback-floor enforcement (if claimed) is deterministic and fail-closed (PO-ATOMICUPD-ROLLBACK)
