# MicroVM debug/introspection posture v0 (no portable ambient host-side guest-debug or memory-introspection contract)

Purpose: pin the **Phase 1** meaning of host-side guest debugging and memory introspection under `ext.microvm` so gdbstub sockets, guest-memory dumps, and debugger-oriented physical-memory examination do not quietly become a portable reviewed observation/control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-OBS**, and **D-INSPECT** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host-side guest-debug or memory-introspection contract under `ext.microvm`; there is no portable gdbstub / remote-debug plane, no portable guest-memory-dump / vmcore-export plane, no portable physical-memory-exam or debug-attach transport-auth contract, owner-local debug socket / dump file / monitor relay setup stays implementation-local, and reviewed observation / inspection / crash evidence still rides on already-pinned explicit `D-OBS` / `D-INSPECT` / `CH-CRASHCAP` seams rather than ambient VMM debug endpoints.**

Entropy cost justification: the archive already pins guest-visible crash-report surfaces, semihosting, guest agents, and host-side management APIs, but real VMM stacks still offer another tempting shortcut: attach a debugger to the live guest, walk guest or physical memory, or dump a vmcore from the host and then quietly treat that as reviewed product meaning. One narrow posture closes that gap without inventing a SlopOS debugger protocol, crash-analysis schema, or new inspection service family.

## Posture (v0)

1) **No portable ambient host-side guest-debug or memory-introspection contract**
   - **Phase 1 exposes no portable ambient host-side guest-debug or memory-introspection contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this admitted microVM always has one stable debugger socket, one stable remote-debug workflow, or one portable memory-inspection path available to operators or automation.”
   - In plain terms: the reviewed contract is not “boot the leaf and expect one portable debug attach or host-side guest-memory inspection channel to exist.”

2) **No portable gdbstub / remote-debug plane**
   - There is **no portable gdbstub / remote-debug plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable GDB remote-connection endpoint, one stable stop/continue / breakpoint / watchpoint control vocabulary, one stable debug transport path, or one stable “attach to the guest and inspect registers/memory” contract.
   - Implementations may locally expose such facilities, but those choices do **not** become SlopOS portable interface meaning.

3) **No portable guest-memory-dump / vmcore-export plane**
   - There is **no portable guest-memory-dump / vmcore-export plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `dump-guest-memory` / vmcore export contract, one stable host-triggered core-dump workflow, one stable dump format / paging option / address-range filter contract, or one stable “host can always export the guest memory image” promise.
   - Owner-local dump-file generation, compression format choice, and crash-analysis workflow remain implementation-local rather than portable `ext.microvm` meaning.

4) **No portable physical-memory-exam or debug-attach transport/auth contract**
   - There is **no portable physical-memory-exam or debug-attach transport/auth contract** under Phase 1.
   - Portable reviewed meaning does **not** include one stable TCP or Unix-socket exposure story, one stable auth/encryption policy, one stable physical-memory examination mode, or one stable orchestrator relay such as `qemu-monitor-command`-style pass-through for debug/introspection actions.
   - Guest debugging and memory inspection may exist locally, but their transport, authentication, and privilege story remain owner-local mechanism rather than portable SlopOS semantics.

5) **Owner-local debug socket / dump file / monitor relay setup stays implementation-local**
   - Owner-local debugger endpoint placement, monitor relays, dump-file paths, compression/conversion choices, and operator tooling remain implementation-local.
   - Implementations may locally use gdbstub sockets, monitor relays, or domain-dump helpers, but those choices do **not** create a portable reviewed promise about one operator workflow, one evidence format, or one debug authorization story.
   - In particular, debug socket reachability, host file placement, paging/physical-memory mode, and libvirt-orchestration wrappers remain runtime-local mechanism rather than portable SlopOS meaning.

6) **Existing explicit seams remain authoritative**
   - Reviewed observation meaning still rides on explicit `D-OBS` exports rather than ambient debugger attach or memory walk facilities.
   - Reviewed inspection and failure-evidence meaning still rides on explicit `D-INSPECT`, `D-FLIGHTREC`, and `CH-CRASHCAP` artifacts rather than ambient host-triggered vmcore export or debug transport exposure.
   - Reviewed lifecycle meaning still rides on explicit `D-ACTIVATE` supervision and already-pinned lifecycle/snapshot postures rather than ambient debugger stop/continue or pause-for-dump conventions.

7) **Changing the debug/introspection stance is owner-local operations policy or new admission, not a portable live inspection plane**
   - Changing the debug/introspection stance is owner-local operations policy or new admission, not a portable live inspection plane.
   - If policy cares about whether a leaf is debuggable or dumpable from the host, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `attach_debugger`, `read_guest_phys`, `dump_vmcore`, or `pause_for_debug` plane by convention.
   - This keeps reviewed observation and failure-evidence meaning on already-pinned seams rather than on ambient VMM debugger endpoints.

8) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `attach_debugger`, `dump_guest_memory`, `read_guest_physical_memory`, or `set_debug_breakpoint` must say whether it commutes with activation, observation export, snapshot/restore policy, crash evidence capture, and attestation freshness, and where serialization lives.
   - Until then, host-side debug and memory-inspection facilities remain owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable gdbstub / remote-debug / breakpoint-watchpoint contract under `ext.microvm`.
- No portable guest-memory-dump / vmcore-export / host-triggered core-dump contract.
- No portable physical-memory-exam / debug-socket / monitor-relay / auth-transport contract.
- No claim that ambient debugger attach or host vmcore export is an acceptable portable substitute for explicit `D-OBS` / `D-INSPECT` / `CH-CRASHCAP` seams.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-OBS, D-INSPECT)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-crash-report-surface-posture-v0.md`
  - `microvm-management-api-posture-v0.md`
  - `microvm-semihosting-posture-v0.md`
  - `microvm-live-migration-posture-v0.md`
  - `observation-export-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-45)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-DBGINSPECT)
- Policy posture:
  - host-side guest debugging and memory introspection add **no new lane**, **no portable debugger attach or vmcore-export plane**, and **no portable host-side inspection truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_debug_introspection_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable host-side guest-debug-or-memory-introspection contract / no portable gdbstub-or-remote-debug plane / no portable guest-memory-dump-or-vmcore-export plane / no portable physical-memory-exam-or-debug-attach transport-auth contract / owner-local debug-socket-dump-file-monitor-relay setup remains implementation-local / explicit observation-inspection-crash-evidence seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-GDB-USAGE.
- REF-QEMU-DUMP-GUEST-MEMORY.
- REF-LIBVIRT-VIRSH-CMDREF.
- REF-CHYP-GDB-STUB.
