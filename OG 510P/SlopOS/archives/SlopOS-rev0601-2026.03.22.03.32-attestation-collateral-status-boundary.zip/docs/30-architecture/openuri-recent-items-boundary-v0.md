# D-PLUMB OpenURI recent-items boundary v0 (no portable recent-items/history control or receipt)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable recent-items, durable-history, or reopen-enrollment policy surface.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable recent-items / history control or receipt in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `add_to_recent`, `record_history`, `suppress_history`, `dont_add_to_recent`, `recent_item_id`, `open_recent`, `reopen_later`, or equivalent recent-items/history control or receipt on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject only.

2) **Shell-local recents, if any, stay shell-owned and non-authoritative.**
   - A shell/provider may keep bounded local hints that a launch occurred, but those hints stay **shell-owned policy**, not app-visible protocol truth.
   - Such hints must not become a portable app-visible inventory API, a stable reopen grant, a raw-path leak, a raw-URI leak, or a bearer token.
   - Redacted labels, shell-local UX grouping, or profile-local clearing policy are acceptable only so long as authority to reopen still lives on existing explicit seams.

3) **Explicit persistence lives on the document portal seam, not generic URI launch.**
   - If a product shape later wants durable reopen of local objects, that belongs on `portal.file.*` / CH-DOCREF / explicit persistence workflows, not as a side effect of generic launch.
   - Phase 1 therefore keeps recent-doc / reopen authority separate from `portal.uri.*`, even when other platforms blur those concepts together.
   - Generic OpenURI remains a mediated launch workflow, not a back door into remembered document authority.

4) **Why this cut is honest.**
   - Real ecosystems really do track durable recent items here: macOS exposes recent apps/documents/servers, Windows shells and dialogs can add items to Recent/Jump List state, and sandboxed desktop ecosystems solve durable reopen with an explicit document-store seam rather than by overloading generic launch.
   - Those are real convenience patterns, but importing them into generic OpenURI would widen `portal.uri.*` from mediated launch into a durable reopen/history plane with shell-state side effects.
   - SlopOS keeps any local launch history shell-owned and non-authoritative unless and until a future RFC deliberately standardizes something richer.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new history-enrollment action family, conflict-key family, or serialization surface.
   - Any future recent-items/admin surface must state its own conflict keys and commutativity explicitly rather than inheriting folklore from launcher UX.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “recent items” mutation or reopen-grant behavior through host helpers.
   - If compat wants OpenURI, it still goes through `portal.uri.*` and whatever shell-local history policy exists remains provider-owned rather than requester-controlled.

## Phase 1 non-goals (explicitly deferred)

- No portable `add_to_recent`, `record_history`, `suppress_history`, `dont_add_to_recent` control on `portal.uri.*`.
- No `recent_item_id`, reopen token, or durable history receipt on generic URI launch.
- No app-visible inventory/query API over shell recent-items or launch-history state.
- No hidden host-helper fallback that silently mutates durable recent-doc / reopen state behind OpenURI success.
- No generic “open recent” / “reopen last URI target” admin surface piggybacking on `portal.uri.*`.

## Why this is worth pinning

Once OpenURI exists, another tempting convenience import is “should this launch appear in recents?” or “can the caller suppress history for this launch?” Desktop ecosystems answer yes often enough that the seam is real, and sandboxed document ecosystems answer durable reopen by introducing a separate explicit document-store authority surface.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a durable reopen/history plane. That matters for all four product shapes: workstation UX may still keep shell-local hints without making them an app contract; hosted and embedded profiles avoid carrying fake recents semantics they do not want; and agents cannot smuggle persistent reopen authority through what should remain a one-shot launch workflow.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
  - `docs/30-architecture/document-portal-posture-v0.md`
  - `docs/30-architecture/plumb-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_recent_items_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable recent-items/history control or receipt / shell-local recents stay non-authoritative / explicit persistence lives on the document portal seam / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-578**).

## References

- REF-XDG-PORTAL-DOCUMENTS.
- REF-APPLE-RECENT-ITEMS.
- REF-WINDOWS-SHADDTORECENTDOCS.
- REF-WINDOWS-FOS-DONTADDTORECENT.
