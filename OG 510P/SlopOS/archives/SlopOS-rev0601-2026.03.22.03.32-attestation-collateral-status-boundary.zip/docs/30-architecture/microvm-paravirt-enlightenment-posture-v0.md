# MicroVM paravirtual-enlightenment posture v0 (hypervisor-specific assist ABIs stay non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible paravirtual enlightenments and hypervisor-assist ABIs under `ext.microvm` so hypervisor-specific CPUID leaves, MSRs, shared pages, hypercalls, and synthetic coordination channels do not quietly become a portable reviewed control/observation/time plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-NONDET**, **D-OBS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible paravirtual-enlightenment contract under `ext.microvm`; there is no portable KVM-paravirt-feature-MSR-shared-page-hypercall plane, no portable Hyper-V-enlightenment-SynIC-VMBus plane, no portable Xen-hypercall-event-channel-grant-table-XenStore plane, owner-local hypervisor-assist exposure stays implementation-local, and reviewed time/interrupt/profiling/channel meaning still rides on already-pinned explicit seams rather than ambient hypervisor-specific guest ABIs.**

Entropy cost justification: the archive already pins time sources, interrupt topology, crash devices, PMU/profiling, and host↔guest channels individually, but hypervisor-specific "helpful" PV/enlightenment ABIs cut across all of them at once. KVM feature MSRs, Hyper-V enlightenments, Xen event channels/grant tables, and KVM-specific time-sync hypercalls can quietly smuggle scheduling hints, clock helpers, crash paths, and hidden coordination channels into guest-visible folklore. One narrow posture closes that gap without inventing a guest agent, compatibility shim, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible paravirtual-enlightenment contract**
   - **Phase 1 exposes no portable ambient guest-visible paravirtual-enlightenment contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable hypervisor-specific CPUID leaf family, paravirtual MSR bank, shared-page ABI, hypercall set, or synthetic interrupt/message channel.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those mechanisms do **not** become SlopOS portable API meaning.

2) **No portable KVM-paravirt-feature-MSR-shared-page-hypercall plane**
   - There is **no portable KVM-paravirt-feature-MSR-shared-page-hypercall plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable KVM CPUID feature-bit vocabulary, `kvmclock`/steal-time/shared-page ABI, PV-EOI / PV-IPI / async-page-fault / sched-yield MSR contract, or KVM-specific helper hypercall such as `PTP_KVM`.
   - Owner-local KVM assist exposure and CPUID/MSR shaping remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable Hyper-V-enlightenment-SynIC-VMBus plane**
   - There is **no portable Hyper-V-enlightenment-SynIC-VMBus plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `hv_*` enlightenment set, VP-assist / runtime / crash / synthetic-timer MSR contract, SynIC message/event ABI, or VMBus-dependent synthetic coordination plane.
   - Owner-local Hyper-V compatibility exposure, crash hooks, and synthetic timer/interrupt plumbing remain implementation-local and must not silently become portable time, interrupt, crash-report, or device semantics.

4) **No portable Xen-hypercall-event-channel-grant-table-XenStore plane**
   - There is **no portable Xen-hypercall-event-channel-grant-table-XenStore plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable Xen hypercall family, event-channel mailbox ABI, grant-table sharing contract, guest scheduler-op surface, or XenStore discovery/control path.
   - Owner-local Xen PV/PVH compatibility choices remain implementation-local and must not silently become portable host↔guest or guest↔guest coordination semantics.

5) **Existing explicit seams remain authoritative**
   - Reviewed time meaning still rides on explicit `D-NONDET` / `D-TIMEPROOF` seams and the already-pinned microVM time-source/clock-disruption postures, not on hypervisor-specific clocks, steal-time pages, or time-sync hypercalls.
   - Reviewed interrupt meaning still rides on the already-pinned interrupt-topology posture, not on SynIC/event-channel/PV-EOI folklore.
   - Reviewed profiling/observation meaning still rides on explicit `D-OBS` / `D-TRACE` seams, not on hypervisor-specific runtime counters, synthetic crash MSRs, or vendor PV tracing hooks.
   - Reviewed channel meaning still rides on the already-pinned host↔guest and shared-memory postures, not on XenStore, VMBus control messages, or similar ambient coordination paths.

6) **Changing the paravirt stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the paravirt stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different enlightenment set or PV-helper posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `enable_hv_time`, `set_kvm_pv_features`, `map_xen_evtchn`, or `attach_vmbus_channel` control plane by convention.
   - This keeps hypervisor-assist meaning on the already-pinned activation/time/interrupt/channel seams rather than on ambient guest vendor ABIs.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_guest_enlightenments`, `enable_guest_paravirt_clock`, `map_guest_evtchn`, or `export_guest_hypervisor_channel` must say whether it commutes with activation, reset, snapshot capture, observation export, and time/interrupt policy, and where serialization lives.
   - Until then, paravirtual enlightenments remain owner-local runtime/guest convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable KVM feature-leaf / MSR / shared-page / helper-hypercall contract under `ext.microvm`.
- No portable Hyper-V enlightenment / SynIC / VMBus coordination contract under `ext.microvm`.
- No portable Xen hypercall / event-channel / grant-table / XenStore coordination contract under `ext.microvm`.
- No portable guest-visible hypervisor-assist inventory or live enable/disable admin plane.
- No claim that hypervisor-specific paravirt assists are portable attestation, placement, timing, or crash-evidence truth.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-NONDET, D-OBS, D-ACTIVATE)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `microvm-nested-virt-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-time-source-posture-v0.md`
  - `microvm-interrupt-topology-posture-v0.md`
  - `microvm-pmu-profiling-posture-v0.md`
  - `observation-export-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-36)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-PARAVIRT)
- Policy posture:
  - guest-visible paravirt/enlightenment adds **no new lane**, **no portable live enable/disable plane**, and **no portable evidence-by-hypervisor-assist contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_paravirt_enlightenment_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable paravirtual-enlightenment / no portable KVM-paravirt-feature-MSR-shared-page-hypercall plane / no portable Hyper-V-enlightenment-SynIC-VMBus plane / no portable Xen-hypercall-event-channel-grant-table-XenStore plane / owner-local hypervisor-assist exposure remains implementation-local / explicit time/interrupt/profiling/channel seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-HYPERV-ENLIGHTENMENTS.
- REF-KVM-CPUID-BITS.
- REF-LINUX-HYPERV-CLOCKS.
- REF-KVM-PTP-KVM.
- REF-XEN-PUBLIC-HYPERCALL.
