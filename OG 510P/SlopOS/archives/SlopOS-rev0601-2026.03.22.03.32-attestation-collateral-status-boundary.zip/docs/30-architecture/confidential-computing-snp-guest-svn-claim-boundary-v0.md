# D-CC SNP GUEST_SVN claim boundary v0 (`GUEST_SVN` stays exact evidence; not portable release ordering or rollback meaning)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `GUEST_SVN`** so the owner-authored guest security-version field does not quietly become a portable SlopOS release order, anti-rollback floor, secret-release namespace, or hidden approval shortcut.

Entropy cost justification: the archive already pins one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, one SNP guest-mode cut, one owner-launch-identity rule, one SNP TCB-field rule, one SNP `POLICY` rule, one SNP report-identity rule, one SNP `CHIP_ID` rule, and one SNP `PLATFORM_INFO` rule. What remained ambiguous was narrower and worth deciding now: **the SNP attestation report also carries `GUEST_SVN`, AMD stores it in the ID block/report, and the guest may explicitly mix it into derived-key requests**. One small boundary closes that gap without inventing a portable release-version schema, anti-rollback service, or verifier-global ordering language.

## Posture (v0)

1) **`GUEST_SVN` is owner-authored guest-version evidence, not a portable SlopOS release or rollback claim**
   - AMD’s firmware ABI includes `GUEST_SVN` in the ID block as the **SVN of the guest**, and the attestation report carries that `GUEST_SVN` value.
   - AMD’s attestation overview groups `GUEST_SVN` with `FAMILY_ID` / `IMAGE_ID` as guest-image identification information.
   - Phase 1 therefore treats `GUEST_SVN` as **exact provider-native evidence only**. It does **not** become a reviewed `CH-ATTEST` field, a portable SlopOS release number, or a cross-provider anti-rollback claim language.

2) **`GUEST_SVN` does not define one portable anti-rollback or patch-floor language**
   - AMD’s ABI allows the guest to request that `GUEST_SVN` be mixed into a derived key, and it requires the requested value to not exceed the guest SVN provided at launch in the ID block.
   - That makes `GUEST_SVN` important exact evidence and an optional key-derivation input, but it still does **not** create one portable SlopOS-wide ordering rule, one normalized rollback-floor schema, or one mandatory monotonicity discipline across all SNP-first deployments.
   - In particular, `GUEST_SVN` is not interchangeable with `CURRENT_TCB` / `COMMITTED_TCB` / `REPORTED_TCB` / `LAUNCH_TCB`, and it is not the same thing as package/update versioning under D-ATOMICUPD.

3) **`GUEST_SVN` does not substitute for `boot_digest`, `prov_digest`, exact `cc_report_data_v0` binding, or freshness**
   - A verifier MUST still check the already-pinned boot/provenance/report-data binding surfaces separately.
   - Matching, increasing, decreasing, or repeated `GUEST_SVN` values do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace freshness binding under `PO-ATTEST-FRESH`, and do **not** redefine which `CH-BOOT` / provenance bundle was actually admitted.
   - In particular, `GUEST_SVN` MUST NOT become a hidden nonce, replay oracle, attestation-session identifier, or substitute proof that the exact D-CC binder contract was satisfied.

4) **`GUEST_SVN` does not define secret-release, key-derivation, or namespace-selection semantics by itself**
   - The fact that SNP derived-key requests can mix in `GUEST_SVN` does not make the report field itself a portable key namespace, vault namespace, release tier, or lease-renewal selector.
   - Phase 1 does **not** bind `CH-AREF`, D-VAULT, or D-CRYPTOSVC selector semantics to `GUEST_SVN` by default.
   - Any deployment that chooses to compare exact `GUEST_SVN` values or to incorporate them into a local release policy is still exercising **explicit verifier-local policy**, not relying on portable SlopOS claim meaning.

5) **Any appraisal of `GUEST_SVN` remains explicit verifier-local policy**
   - A deployment-specific verifier MAY preserve, compare, or threshold exact `GUEST_SVN` values for local image-policy or release-policy reasons.
   - That appraisal remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS default.
   - Different deployments may therefore ignore, reject, review, or order the same exact `GUEST_SVN` evidence differently without changing the portable D-ATTEST seam.

6) **Packaging/export does not upgrade `GUEST_SVN` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `GUEST_SVN`.
   - If tooling wants to preserve decoded values for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable guest-version schema.
   - Exporting an SNP report that carries `GUEST_SVN` does not imply that remote consumers may treat it as reviewed SlopOS-native release ordering, anti-rollback, or approval meaning.

7) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing SNP report / ID-block field.
   - It introduces no new workflow kind, no serialization surface, and no attester-side guest-version query, rollback-reset, or release-ordering plane.

## Phase 1 non-goals (explicitly deferred)

- No `guest_svn` field in `CH-ATTEST v0`.
- No portable release-order or anti-rollback taxonomy derived from SNP `GUEST_SVN`.
- No default secret-release, vault-namespace, or key-derivation selector keyed to `GUEST_SVN`.
- No `IF-ATTEST` selector/query surface for guest-version predicates.

## Why this boundary exists

The archive had already fixed the binder, certificate-source, host-field, owner-identity, TCB-field, guest-policy, report-identity, chip-identity, platform-info, and guest-mode seams, but one implementation fork remained likely:
- AMD’s ABI puts `GUEST_SVN` into the ID block and attestation report,
- AMD also allows `GUEST_SVN` to be mixed into derived keys,
- “SVN” sounds like exactly the sort of thing secret-release and rollout systems want to turn into a portable rollback floor,
- and the archive already has separate reviewed surfaces for boot lineage, provenance, update intent, and verifier-local policy.

Without one explicit rule, the first verifier, release gate, or hosted automation path would predictably do one of these by convention:
- treat `GUEST_SVN` as the portable SlopOS release number,
- treat higher/lower exact values as the built-in cross-provider anti-rollback rule,
- or key secret-release namespaces and approval state directly to `GUEST_SVN` instead of the already-pinned binder/provenance/freshness surfaces.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **exact `GUEST_SVN` values may be appraised only under explicit verifier-local policy**, and
- **the core attestation seam does not inherit one provider-native guest-version taxonomy as portable OS truth**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers may preserve or inspect exact `GUEST_SVN` evidence, but the workstation shape does not inherit one cloud-provider guest-version taxonomy as portable workstation semantics.
- **Cloud micro-VM substrate (B):** hosted verifiers may use exact `GUEST_SVN` values in deployment-local policy, but they do not get a portable SlopOS release-order, rollback-floor, or secret-release namespace from one AMD field.
- **Embedded / separation-kernel-ish appliance (C):** imported SNP evidence may retain exact `GUEST_SVN` values for audit, but appliance posture does not widen into a cross-provider image-version or rollback taxonomy just because one cloud/provider flow exposed that field.
- **Agent / automation OS (D):** agents may inspect exact `GUEST_SVN` evidence, but they do not gain a hidden approval or release-order shortcut; any guest-version interpretation stays transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP guest-version meaning seam.

If a second closely related D-CC SNP guest-version boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**, **D-ATOMICUPD**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-tcb-field-claim-boundary-v0.md`
  - `confidential-computing-snp-policy-claim-boundary-v0.md`
  - `confidential-computing-snp-report-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-chip-id-claim-boundary-v0.md`
  - `confidential-computing-snp-platform-info-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `update-posture-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_guest_svn_claim_boundary.py` (**EVID-2026-545**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-SNP-ATTEST-PDF.
- REF-RATS-RFC9334.
