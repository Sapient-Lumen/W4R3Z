# Reqctx adjunct index (closed request-context posture family)

Purpose: keep the current **request-context posture family** recoverable as one closed discovery surface.
Why this exists:
The archive already has `reqctx-posture-v0.md` as the generic **D-REQCTX** meaning pin and the two consumer-typed sponsorship-reference adjuncts, but humans/LLMs should not have to rediscover that family piecemeal from schema notes, the decision map, and scattered posture rows.

This doc does **not** create a typed sponsorship control plane, a portable baggage store, or a broader D-REQCTX admin/workflow surface. It keeps the current request-context posture family closed, enumerable, and reviewable as one implementation-facing surface for shapes **A/B/D** while leaving the typed-sponsorship evolution boundary and adjacent payer/call-chain semantics explicitly separate.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is `reqctx-posture-v0.md` or a `reqctx-*-posture-v0.md` doc under `docs/30-architecture/` that pins some bounded portable **request-context** or consumer-typed sponsorship-reference meaning;
2) it is a posture doc, not an adjacent schema/result/boundary surface (for example `request-context-schema-v1.md`, `reqctx-sponsorship-evolution-boundary-v0.md`, and `budget-payer-semantics-v0.md` stay adjacent);
3) its meaning is about portable request-context propagation or explicit consumer-typed sponsorship interpretation, not a neighboring seam that merely carries a `reqctx_digest` or call-chain/budget metadata.

## Closed request-context posture set (Phase 1)

### 1) Core request-context meaning

| Doc | One-line pinned meaning |
|---|---|
| [`reqctx-posture-v0.md`](reqctx-posture-v0.md) | request contexts stay sticky and tree-shaped, bounded/non-authoritative, absolute-deadline-only, and free of baggage/detach/shield drift |

### 2) Consumer-typed sponsorship references

| Doc | One-line pinned meaning |
|---|---|
| [`reqctx-budget-ref-posture-v0.md`](reqctx-budget-ref-posture-v0.md) | `budget_desc_digests` stay bare digests; consumers are type-strict and non-ambient, and only CH-BUDGET counts when sponsorship is required |
| [`reqctx-tcap-ref-posture-v0.md`](reqctx-tcap-ref-posture-v0.md) | `tcap_desc_digests` stay bare digests; consumers are type-strict and non-ambient, and only CH-TCAP counts when temporal sponsorship is required |

## Review rule

When a new `reqctx-*-posture-v0.md` doc appears, or when D-REQCTX grows another posture-level adjunct that is part of the same portable request-context meaning surface, either:

- add it here **in the same revision**, or
- explicitly place it under some other existing closed discovery surface in the same revision.

If a future change wants typed sponsorship objects, a baggage/value store, or some portable request-context admin/workflow plane, that widening must remain explicit on its own seam: keep this index, `reqctx-sponsorship-evolution-boundary-v0.md`, `budget-payer-semantics-v0.md`, and `bracket-posture-v0.md` all honest in the same revision instead of letting “request context” become a blurry control bucket.

## Wiring

- Generic request-context anchor: `reqctx-posture-v0.md`.
- CH-REQCTX schema: `request-context-schema-v1.md`.
- Adjacent explicit boundaries: `reqctx-sponsorship-evolution-boundary-v0.md`, `artifact-resolution-posture-v0.md`.
- Adjacent control/correlation seams: `budget-payer-semantics-v0.md`, `bracket-posture-v0.md`.
- Decision surfaces: `decision-map.md` (**D-REQCTX**, **D-BUDGET**, **D-TCAP**, **D-BRACKET**).
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_reqctx_adjunct_index.py` (**EVID-2026-525**).
