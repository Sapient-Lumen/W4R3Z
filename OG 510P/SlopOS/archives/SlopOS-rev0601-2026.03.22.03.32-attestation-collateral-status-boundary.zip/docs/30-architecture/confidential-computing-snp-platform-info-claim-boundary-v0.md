# D-CC SNP PLATFORM_INFO claim boundary v0 (`PLATFORM_INFO` stays exact evidence; not portable security profile)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `PLATFORM_INFO`** so the provider-native platform-configuration bitfield does not quietly become a portable SlopOS security profile, machine class, capability vector, or approval shortcut.

Entropy cost justification: the archive already pins one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, one SNP guest-mode cut, one owner-launch-identity rule, one SNP TCB-field rule, one SNP `POLICY` rule, one SNP report-identity rule, and one SNP `CHIP_ID` rule. What remained ambiguous was narrower and worth deciding now: **the SNP attestation report also carries `PLATFORM_INFO`, AMD uses it for concrete platform-configuration and mitigation bits, and at least one bit (`ECC_EN`) is feature-gated rather than universally present**. One small boundary closes that gap without inventing a portable security-tier taxonomy, hardware-capability registry, or provider-native approval language.

## Posture (v0)

1) **`PLATFORM_INFO` is exact provider-native platform-configuration evidence, not a portable SlopOS security profile or machine class**
   - AMD’s firmware ABI defines `PLATFORM_INFO` as information about the platform and gives concrete report bits such as `TIO_EN`, `ALIAS_CHECK_COMPLETE`, `CIPHERTEXT_HIDING_DRAM_EN`, `RAPL_DIS`, `ECC_EN`, `TSME_EN`, and `SMT_EN`.
   - AMD’s attestation overview likewise presents `PLATFORM_INFO` as properties of the platform configuration and frames appraisal questions such as whether whole-system memory encryption is enabled or SMT is disabled.
   - Phase 1 therefore treats `PLATFORM_INFO` as **exact provider-native evidence only**. It does **not** become a reviewed `CH-ATTEST` field, a portable SlopOS security-profile/tier, or a cross-provider machine-class taxonomy.

2) **Portable meaning cannot depend on every bit being present, stable, or interpreted uniformly**
   - The firmware ABI says `ECC_EN` is present only when the `EccMemReporting` feature bit is set, and the field mixes platform-state, mitigation-state, and feature-reporting semantics.
   - Phase 1 therefore does **not** define one normalized “security score”, “hardening level”, “memory-integrity class”, or “CC mode quality level” derived from `PLATFORM_INFO`.
   - A verifier MAY preserve and appraise exact bits under explicit local policy, but portable conformance does not require one global interpretation for each bit across all SNP-first deployments.

3) **`PLATFORM_INFO` does not substitute for `POLICY`, TCB fields, `CHIP_ID`, or exact binder/freshness surfaces**
   - `PLATFORM_INFO` is not the guest-owner `POLICY` bitfield, does not replace the distinct meanings of `CURRENT_TCB` / `COMMITTED_TCB` / `REPORTED_TCB` / `LAUNCH_TCB`, and does not substitute for `CHIP_ID`, `REPORT_ID`, `boot_digest`, `prov_digest`, or exact `cc_report_data_v0` binding.
   - Matching or differing `PLATFORM_INFO` bits do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace `PO-ATTEST-FRESH`, and do **not** redefine which boot/provenance line was actually admitted.
   - In particular, `PLATFORM_INFO` MUST NOT become a hidden replay/freshness/session selector or a substitute proof that the exact D-CC binder contract was satisfied.

4) **Exact platform-bit appraisal remains explicit verifier-local policy**
   - A deployment-specific verifier MAY require, reject, ignore, or correlate exact bits such as `SMT_EN=0`, `TSME_EN=1`, `RAPL_DIS=1`, `ECC_EN=1`, or `CIPHERTEXT_HIDING_DRAM_EN=1`.
   - That appraisal remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS default.
   - Different deployments may therefore make different decisions about the same exact `PLATFORM_INFO` bytes without changing the portable D-ATTEST seam.

5) **`PLATFORM_INFO` does not become a portable capability vector or hidden approval language**
   - The fact that `PLATFORM_INFO` contains named bits does not make it a portable capability advertisement or a reviewed “this machine is approved for workload class X” vector.
   - Phase 1 therefore does **not** let `PLATFORM_INFO` choose rollout lanes, secret-release tiers, vault namespaces, or cross-shape admission classes by default.
   - Any automation that reasons about exact `PLATFORM_INFO` bits must do so through transcript-visible verifier-local policy rather than through ambient platform folklore.

6) **Packaging/export does not upgrade `PLATFORM_INFO` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `PLATFORM_INFO`.
   - If tooling wants to preserve decoded bits for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable platform-feature schema.
   - Exporting an SNP report that carries `PLATFORM_INFO` does not imply that remote consumers may treat those bits as reviewed SlopOS-native security-profile or capability meaning.

7) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing SNP report field.
   - It introduces no new workflow kind, no serialization surface, and no attester-side platform-configuration query or fleet-classification plane.

## Phase 1 non-goals (explicitly deferred)

- No `platform_info` field in `CH-ATTEST v0`.
- No portable security-tier or machine-class taxonomy derived from SNP `PLATFORM_INFO`.
- No default approval/routing/secret-release policy keyed to exact `PLATFORM_INFO` bits.
- No `IF-ATTEST` selector/query surface for platform-feature predicates.

## Why this boundary exists

The archive had already fixed the binder, certificate-source, host-field, owner-identity, TCB-field, guest-policy, report-identity, chip-identity, and guest-mode seams, but one implementation fork remained likely:
- AMD’s ABI exposes a concrete provider-native platform bitfield inside the report,
- AMD’s attestation guidance openly invites local questions such as “do you require SMT to be off?” or “do you require whole-system memory encryption to be on?”,
- at least one bit is feature-gated rather than universally present,
- and rollout / secret-release systems naturally want a short security-profile label rather than exact evidence-plus-policy.

Without one explicit rule, the first verifier, release gate, or hosted rollout path would predictably do one of these by convention:
- normalize `PLATFORM_INFO` into a portable “high-security host” / “approved substrate” tier,
- treat one provider-native bit combination as the SlopOS-wide meaning of “secure confidential-computing target”,
- or let exact platform bits silently choose secret-release lanes, workload classes, or approval state without explicit verifier-local policy.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **exact `PLATFORM_INFO` bits may be appraised only under explicit verifier-local policy**, and
- **the core attestation seam does not inherit one provider-native platform-feature taxonomy as portable OS truth**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side policy can preserve or inspect exact platform bits, but the workstation shape does not inherit a cloud-provider platform-feature taxonomy as portable workstation semantics.
- **Cloud micro-VM substrate (B):** hosted verifiers may use exact `PLATFORM_INFO` bits in deployment-local policy, but they do not get a portable SlopOS host-class or secret-release tier from one AMD bitfield.
- **Embedded / separation-kernel-ish appliance (C):** imported SNP evidence may retain exact platform bits for audit, but appliance posture does not widen into a cross-provider machine-feature taxonomy just because one cloud/provider flow exposed `PLATFORM_INFO`.
- **Agent / automation OS (D):** agents may inspect exact `PLATFORM_INFO` evidence, but they do not gain a hidden approval vector; any platform-bit interpretation stays transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP platform-configuration meaning seam.

If a second closely related D-CC SNP platform-configuration boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-tcb-field-claim-boundary-v0.md`
  - `confidential-computing-snp-policy-claim-boundary-v0.md`
  - `confidential-computing-snp-report-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-chip-id-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_platform_info_claim_boundary.py` (**EVID-2026-544**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-SNP-ATTEST-PDF.
- REF-RATS-RFC9334.
