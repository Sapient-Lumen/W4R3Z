# MicroVM virtual-IOMMU posture v0 (no portable ambient guest vIOMMU contract)

Purpose: pin the **Phase 1** meaning of guest-visible virtual IOMMU exposure under `ext.microvm` so `virtio-iommu`, endpoint attachment, map/unmap controls, and vIOMMU fault/status folklore do not quietly become a reviewed host↔guest DMA-management plane.

This doc attaches to **D-MICROVM**, **D-DMA**, **D-IOLEASE**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible vIOMMU contract under `ext.microvm`; there is no portable `virtio-iommu` / domain-endpoint-attach / map-unmap / fault-status / address-width plane, owner-local vIOMMU enablement and endpoint placement stay implementation-local, and DMA meaning still rides on explicit D-DMA / D-IOLEASE seams rather than ambient guest remap control.**

Entropy cost justification: the archive already pins host-side DMA honesty (D-DMA), guest-visible passthrough-device non-portability, and the broad `ext.microvm` exit-surface budget. What remained underspecified was the tempting middle layer where a guest-visible vIOMMU looks “small enough” to sneak in as ambient reviewed meaning: endpoint attachment, domain layout, fault visibility, or address-width tuning. One narrow posture closes that gap without inventing a new schema family, a guest mapping API, or a hidden host control plane.

## Posture (v0)

1) **No portable ambient guest-visible vIOMMU contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible vIOMMU contract.
   - Portable reviewed meaning does **not** include “this guest can always rely on a standard virtual IOMMU device and manage DMA translation because it is virtualized.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one stable guest DMA-remapping control surface exists with known endpoint inventory and fault semantics.”

2) **No portable `virtio-iommu` / domain-endpoint-attach / map-unmap / fault-status / address-width plane**
   - Phase 1 standardizes **no portable `virtio-iommu` / domain-endpoint-attach / map-unmap / fault-status / address-width plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about which endpoints sit behind a vIOMMU, how domains or groups are named, whether mappings are established eagerly or lazily, how faults are surfaced, what the IOVA width is, or whether the runtime offers per-device knobs such as `iommu=on` / address-width tuning.
   - Implementations may internally expose, suppress, or tune such mechanisms locally, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local vIOMMU enablement and endpoint placement stay implementation-local**
   - Owner-local vIOMMU enablement and endpoint placement stay implementation-local.
   - Runtimes may choose to expose `virtio-iommu`, attach some virtio or passthrough devices behind it, set one address width, or avoid the device entirely for one deployment class, but that does **not** create a portable reviewed promise about one guest-visible endpoint set, one domain topology, or one runtime status/control API.
   - In particular, per-hypervisor command-line/config choices such as Cloud Hypervisor `iommu=on` or address-width tuning remain host/runtime-local configuration, not portable SlopOS interface meaning.

4) **D-DMA and D-IOLEASE remain authoritative**
   - D-DMA and D-IOLEASE remain authoritative for actual DMA meaning.
   - A guest-visible vIOMMU does **not** relax the D-DMA requirement that physical DMA isolation, when claimed, depends on correct host IOMMU/SMMU enforcement.
   - Likewise, device/queue authority still rides on explicit D-IOLEASE and related device-guard seams rather than on ambient guest remap control or folklore that “a vIOMMU is present, therefore DMA authority is safe.”

5) **Changing the vIOMMU surface is a new admission, not a live control plane**
   - Changing the vIOMMU surface is a new admission, not a live control plane.
   - Owners/runtimes may choose different local vIOMMU exposure or endpoint placement for different reviewed leaves or deployment classes, but they may **not** reinterpret a running leaf as carrying a portable mutable vIOMMU endpoint/mapping/fault plane under the same admitted identity.
   - If policy cares about a different vIOMMU stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to patch in a hidden mapping-control channel by convention.

6) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest vIOMMU state, **no new ACP kind**, and **no new conflict-key family** for live endpoint attach, map/unmap, fault acknowledgement, or address-width mutation under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `attach_endpoint`, `map`, `unmap`, `ack_fault`, or `set_address_width`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that `virtio-iommu` exists with one stable reviewed meaning under `ext.microvm`.
- No portable endpoint inventory, domain-id, fault-log, or map/unmap completion API.
- No portable `iommu=on`, address-width, or endpoint-placement tuning surface.
- No live “same leaf, different vIOMMU/endpoints now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-DMA, D-IOLEASE, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `dma-posture-v0.md`
  - `microvm-device-passthrough-posture-v0.md`
- Adjacent notes:
  - `virtio-iommu-mechanism-note.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-22)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-VIOMMU)
- Policy posture:
  - guest-visible vIOMMU exposure adds **no new lane**, **no public endpoint/mapping/fault plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_virtual_iommu_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible vIOMMU contract / no portable `virtio-iommu`-domain-endpoint-attach-map-unmap-fault-status-address-width plane / owner-local vIOMMU enablement and endpoint placement stay implementation-local / D-DMA and D-IOLEASE remain authoritative / changing vIOMMU surface means new admission not live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-CHYP-IOMMU.
- REF-LINUX-IOMMUFD.
- REF-CROSVM-COIOMMU.
