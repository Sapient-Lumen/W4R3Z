# Lease-descriptor state boundary v0 (issuance evidence ≠ current live grant state)

Purpose: pin one compact Phase-1 rule across **D-LEASE** and the portal-issued lease/grant descriptor family: a **lease/grant descriptor is exact issuance-bounded evidence of one reviewed grant shape**, not a portable oracle for current provider-owned live state.

This boundary is intentionally small. It introduces **no new schema family**, list/watch plane, or generic status API. It only narrows how existing lease/grant descriptors may be interpreted over time.

## Posture (v0)

1) **Lease/grant descriptors prove exact issued bounds, not open-ended current-state truth.**
   - `CH-CAPLEASE`, `CH-NETLEASE`, `CH-LOCLEASE`, `CH-BGLEASE`, `CH-INHIBITLEASE`, and `CH-UIAUT` may describe the exact bounds of one issued proxy/grant/session at the time that descriptor was minted/reviewed.
   - They do **not** by themselves prove that the corresponding authority is still active, still renewable, still attached to the same holder/session, still visible in UX, or still allowed by current policy *now*.
   - Descriptor bytes therefore stay exact issuance evidence, not a hidden “query current lease state from the artifact” shortcut.

2) **Historical descriptors and receipts do not resurrect live grant truth.**
   - Old descriptor digests, historical `CH-ACPOUT` / `CH-RECEIPT` / `CH-LOG` records, and export bundles may prove that one bounded grant/session once existed.
   - They do **not** by themselves prove that a lease/grant remains active/unexpired/unrevoked, that a background/autostart permission is still enabled, that a location/update session is still live, or that an inhibit is still holding now.
   - Any future portable current-state/status/watch surface must pay for its own RFC-first schema, conflict keys, serialization story, and evidence plan.

3) **Current live state stays provider-local unless an explicit status seam exists.**
   - Current active/revoked/expired/replaced/disabled/session-ended truth remains provider-local runtime state.
   - Provider-local current truth may be surfaced only through an explicit family-local seam; it must not be inferred from descriptor presence, descriptor timestamps, or receipt trails.
   - Phase 1 therefore declines a generic “lease status registry”, “active grants inventory”, or “latest descriptor wins” rule.

4) **Issued-now does not imply future carryover or durable registration.**
   - A descriptor minted for a currently active grant may still be exact about issuance time while remaining non-authoritative about later state.
   - Descriptor presence does not create future-dated registration, reboot/session carryover, restart resurrection, or replayable reacquisition semantics.
   - If a workflow wants durable carryover, renewal, or restart continuity, that portability must be named on its own explicit seam.

5) **This boundary narrows interpretation only; it does not change enforcement ownership.**
   - Portal/service/provider implementations still own enforcement of expiry, revocation, visibility, and session death.
   - This doc does **not** replace specialized request-state splits, acceptance/completion boundaries, or family-local posture docs; it prevents them from drifting apart by leaving output descriptors semantically looser than request artifacts.

## Phase 1 non-goals (explicitly deferred)

- No generic cross-family “current lease/grant status” query/watch protocol.
- No rule that descriptor timestamps or `issued_at_*` fields imply current liveness.
- No replay/resurrection of live authority from historical receipt or export material.
- No generic admin inventory of active leases/grants across portal families.

## Why this is worth pinning

Several of the comparison archives were strongest when they refused to let **reviewed issuance artifacts masquerade as current mutable state**. SlopOS already pinned that split for many *request* surfaces and for ACP acceptance receipts, but the output side of lease/grant families still had a small remaining ambiguity: a minted descriptor often sounds “live” in prose unless the archive explicitly says otherwise.

Pinning the boundary once keeps lease/grant semantics aligned across D-LEASE and the portal families that issue bounded descriptors, without inventing a second status subsystem.

## Profile effect (A–D)

- **Secure workstation (A):** makes portal receipts/export bundles reviewable without turning old location/background/inhibit/capture records into a hidden current-permission oracle.
- **Cloud micro-VM substrate (B):** keeps lease/grant descriptors useful for audit while preventing stale bundle/receipt material from masquerading as live runtime authorization.
- **Embedded / separation appliance (C):** lets profiles ship exact grant evidence without accidentally implying a richer runtime status plane.
- **Agent/automation OS (D):** prevents LLM/workflow tooling from reading historical grant descriptors as “still live now”, which is especially important when receipts and exports are fed back into automation.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-LEASE**, **D-NETLEASE**, **D-LOCLEASE**, **D-BGLEASE**, **D-INHIBITLEASE**, **D-UICAP**.
- Adjacent meaning pins / schemas:
  - `docs/30-architecture/capability-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/location-lease-schema-v0.md`
  - `docs/30-architecture/background-lease-schema-v0.md`
  - `docs/30-architecture/inhibit-lease-schema-v0.md`
  - `docs/30-architecture/ui-automation-lease-schema-v0.md`
  - `docs/30-architecture/acp-acceptance-completion-posture-v0.md`
- Assurance anchors:
  - **I-LEASE-4**.
  - **PO-LEASE-STATE**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_lease_descriptor_state_boundary.py` keeps the split small and discoverable (**EVID-2026-567**).

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on the general “lease/grant descriptor vs current live state” seam.

If a second closely related lease/grant live-state boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## References

- **REF-XDG-PORTAL-BACKGROUND**
- **REF-XDG-PORTAL-LOCATION**
- **REF-XDG-PORTAL-INHIBIT**
- **REF-SYSTEMD-INHIBITOR-LOCKS**
- **REF-ANDROID-ACCESSIBILITYSERVICE**
