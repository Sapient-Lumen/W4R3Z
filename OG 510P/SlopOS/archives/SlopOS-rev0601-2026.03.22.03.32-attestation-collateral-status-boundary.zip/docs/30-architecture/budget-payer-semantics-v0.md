# D-BUDGET / D-METER payer semantics v0 (explicit payer; no ambient current-payer fallback)

Purpose: pin an implementable **Phase 1** meaning for **D-BUDGET** / **D-METER** so “explicit payer” stays a real authority boundary instead of drifting into a hidden thread-local current-payer variable, container/job/cgroup membership, or silent callee sponsorship convention.
It narrows RFC-0012 and RFC-0058 into one compact posture adjacent to **CH-METER v0**, **CH-BUDGET v0**, **CH-REQCTX v1**, **D-COMMUTE**, and the sealed-compat rules so services, validators, and operators can reason about one default meaning of “who pays?”.

## Posture (v0)

1) **Resource principal stays separate from subject / protection domain**
   - Portable payer meaning is carried by explicit **Meter** / **BudgetLease** authority, not by “whichever process / thread / session / component is running right now.”
   - A caller, callee, worker, or supervised child may execute in one protection domain while charging a distinct reviewed payer root.
   - This keeps the resource principal distinct from the execution subject, matching **I-METER-3** and **I-BUDGET-1** instead of collapsing back to “process = payer.”

2) **No portable ambient `current payer` / implicit caller-session sponsorship plane**
   - Phase 1 standardizes **no ambient current-payer register**, no thread-local sponsor slot, no inherited “billing context” variable, and no rule that the kernel or runtime guesses the payer from the current session / caller identity.
   - Metered interfaces therefore cannot say “the current request’s payer applies unless overridden”; they must either consume an explicit caller-provided budget/meter or use an explicit profile exemption / explicit server budget.
   - This keeps D-BUDGET honest for agent automation and mediation chains, where “obvious caller” folklore is exactly what creates confused-deputy billing bugs.

3) **Container / cgroup / job / subtree membership is not portable payer identity**
   - Phase 1 exposes **no portable rule** that payer identity is derived from cgroup path, Job Object membership, supervisor subtree, pod/container name, or “the resource envelope this task currently sits in.”
   - Such structures may remain owner-local implementation mechanisms for local accounting, throttling, or admission, but they do **not** become the portable reviewed answer to “who paid?”
   - This deliberately declines Linux-cgroup / Windows-job / similar membership inheritance as the SlopOS payer contract, even when local implementations borrow those mechanisms underneath.

4) **Callee sponsorship is explicit, narrow, and transcript-visible**
   - A callee spends its **own** resources only when the reviewed interface explicitly says so (or a profile exemption says so) and the resulting payer choice is transcript-visible under **PO-METER-PAYER** / **PO-BUDGET-NOIMPLICIT**.
   - “Server pays by default” is therefore **not** portable API meaning.
   - A service may still mint or attach a narrow server budget on purpose, but that is a first-class reviewed act rather than a hidden fallback.

5) **Delegation / rebinding is explicit and attenuation-only**
   - Any payer handoff that widens beyond “use this exact supplied budget” must happen by explicit mint/split/derive of a new reviewed budget or meter descendant.
   - Callees and mediators MUST NOT silently rebind a request onto another payer root, rotate sponsors mid-operation, or fan one pooled sponsor into per-step hidden subpayers without exposing that as an explicit seam.
   - The only portable delegation rule is still monotonic attenuation plus lineage, per **I-BUDGET-2** and **PO-METER-DELEGATE**.

6) **CH-REQCTX remains correlation / veto context, not payer authority**
   - `budget_desc_digests` in **CH-REQCTX v1** remain non-authoritative references with the already-pinned type-strict consumer posture.
   - Privileged code MUST NOT infer “first digest wins”, “session default sponsor”, or “ambient current payer” from request-context presence alone.
   - Actual spending authority still comes from validating the referenced **CH-BUDGET v0** / **CH-METER v0** object under the receiving interface’s rules, not from CH-REQCTX acting like a wallet or ambient account selector.

7) **No portable payer lookup / catalog / path-selection surface**
   - Phase 1 exposes no reviewed `budget.lookup(name)`, no payer inventory/list/watch plane, no cgroup-path / account-name / container-id selector, and no “charge whatever budget matches this label” convention.
   - Portable payer choice is therefore by explicit capability/handle or by digest-bound reviewed artifacts already carried on the request seam.
   - If future products want payer catalogs, policy routing, or admin dashboards, that work must pay an RFC-first entropy cost rather than smuggling lookup semantics into D-BUDGET itself.

8) **Commutativity posture stays narrow and explicit**
   - Ordinary **spend/charge** under already-issued local credit remains the existing additive case from `hot-action-surface-v0.md`: it commutes with other spends on the same payer **within allocated credit**, provided local charge is atomic and fail-closed.
   - **Mint / split / grant / revoke / rebalance / expiry mutation** remain the non-commutative actions; serialization lives at the budget issuer / owner seam and is evidenced there, not in a hidden “current payer” runtime.
   - This doc adds **no new workflow / ACP / conflict-key family**; it sharpens the meaning of existing budget actions instead of inventing a new sponsorship protocol.

9) **Sealed compat remains killable and non-ambient**
   - Foreign cells may adapt guest/job/container resource controls only through explicit local meter/budget imports or explicit reviewed server budgets.
   - They must not recreate ambient “current billing context” discovery for native components, and disabling metering / budget lanes must fail closed for any compat adapter that depended on those explicit seams.
   - This keeps juicy ecosystem mechanisms importable without letting their ambient membership conventions become part of the SlopOS authority substrate.

## Phase 1 non-goals (explicitly deferred)

- A portable ambient current-payer or per-thread billing-context register.
- A portable payer inventory / lookup / account-name / path-based selection API.
- Automatic cgroup/job/container/subtree inheritance as the reviewed payer contract.
- Hidden sponsor rotation, pooled-sponsor fan-out, or per-step silent rebinding inside mediator services.
- A new workflow / ACP / admin plane for sponsorship catalogs or payer-policy routing.

## Wiring

- Decision surfaces:
  - `decision-map.md` (**D-METER**, **D-BUDGET**)
- Primary schema / request-context surfaces:
  - `meter-descriptor-schema-v0.md`
  - `budget-lease-schema-v0.md`
  - `request-context-schema-v1.md`
  - `reqctx-budget-ref-posture-v0.md`
  - `reqctx-sponsorship-evolution-boundary-v0.md`
- Adjacent runtime / action surfaces:
  - `hot-action-surface-v0.md`
  - `rfcs/0012-resource-meters-space-banks-and-budgets.md`
  - `rfcs/0058-operation-scoped-budget-leases.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-METER-3**, **I-BUDGET-1**, **I-BUDGET-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-METER-PAYER**, **PO-METER-DELEGATE**, **PO-BUDGET-NOIMPLICIT**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-048**, **AC-049**)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- No new workflow / ACP / conflict-key family in v0; any future payer inventory, ambient selection, or sponsor-routing plane must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_budget_payer_posture.py` fails `make lint` if this posture stops being discoverable, loses the **no ambient current payer / no container-membership payer / explicit callee sponsorship only / explicit attenuation-only rebinding / no payer lookup plane / no new workflow-ACP family** boundary, or drops its primary REF wiring.

## References

- REF-BANGA-RESCONTAINERS.
- REF-CGROUPV2.
- REF-WIN-JOBOBJECTS.
- REF-SEL4-MCS-TUTORIAL.
- REF-GENODE-SESSIONS.
