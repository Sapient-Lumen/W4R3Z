# CH-ATTESTPACK v0: attestation bundle (CH-ATTEST + opaque evidence)

Purpose: define a **small, canonical bundle** returned by **IF-ATTEST** so tooling and verifiers can:
- consume a normalized **boot-binding summary** (CH-ATTEST v0),
- carry **provider-native attestation evidence** as opaque bytes (TPM quote / SNP report / TDX quote / CCA token / etc),
- and keep export surfaces **bounded** and **policy-killable**.

This schema is a **packaging artifact**, not a full protocol spec. Transport, endorsement retrieval, and verifier policy language remain out of scope.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected by validators (fail-closed).

## Shape (v0)

```text
CH-ATTESTPACK-v0 {
  schema: "CH-ATTESTPACK";
  version: 0;

  # Normalized summary (canonical bytes)
  attest_bytes: bytesN;         # canonical bytes of CH-ATTEST v0
  attest_digest: bytes32;       # digest(attest_bytes); MUST match

  # Provider-native evidence (opaque bytes; optional but common)
  evidence?: [
    {
      kind: enum {
        tpm2_quote,
        sev_snp_report,
        tdx_quote,
        cca_token,
        dice_attestation,
        other
      };
      bytes: bytesN;            # opaque provider-native bytes
    }
  ];

  # Optional endorsement/reference pointers (content-addressed hints only; verifier-local applicability policy)
  endorsement_aref_digests?: [ bytes32 ];   # each is digest(CH-AREF v0)

  # Optional notes (non-authoritative; bounded)
  notes?: {
    provider_hint?: tstr;       # e.g., "TPM2", "SNP", "TDX", "CCA" (bounded)
    profile_hint?: tstr;        # e.g., "cose_sign1" / "jwt" (bounded)
  };
}
```

## Bounds (v0; keep export surfaces tight)

- `attest_bytes` length MUST be ≤ **4096** bytes.
- `evidence` list length MUST be ≤ **4**.
- Each `evidence[i].bytes` length MUST be ≤ **32768** bytes.
- `endorsement_aref_digests` length MUST be ≤ **8**.
- `notes.*` strings MUST be ≤ **64** bytes each.

Profiles may tighten these bounds further.

## Validation rules (summary)

- `schema` and `version` must match exactly.
- `attest_digest == digest(attest_bytes)` must hold.
- `endorsement_aref_digests` entries must be exactly 32 bytes each.
- `endorsement_aref_digests` are optional exact-artifact hints only; trust/applicability/freshness/latest semantics remain verifier-local under `attestation-endorsement-boundary-v0.md`.
- freshness remains verifier-local policy over exact token/report bytes under `attestation-freshness-boundary-v0.md`; packaging a nonce-bearing token or provider-native report does not by itself create a portable currentness/session verdict.
- verifier-generated attestation results remain imported evidence under `attestation-result-boundary-v0.md`; packaging token/report bytes does not by itself create a native verifier-result, approval, or result-query plane.
- attester identity material remains exact evidence/signing context under `attestation-identity-boundary-v0.md`; packaging `attest_bytes` and provider-native evidence does not by itself create a native machine/asset/workload identity, attester inventory, or enrollment-query plane.
- collateral status/freshness artifacts remain exact imported evidence under `attestation-collateral-status-boundary-v0.md`; packaging provider-native evidence, certificate chains, CRLs, OCSP responses, TCB-info / identity blobs, or cache snapshots does not by itself create a native latest-collateral, approval, or ambient fetch/cache plane.
- Under SNP-first D-CC flows, host/shared-page certificate-table bytes remain transport-only supporting artifacts; packaging them does not make them portable trust roots (`confidential-computing-snp-certificate-source-boundary-v0.md`).

## Verification posture (how verifiers should treat this)

- **CH-ATTESTPACK is not itself a trust root.**
- Verifiers MUST validate **provider-native evidence** (when present) using their chosen appraisal policy, and MUST treat `attest_bytes` as a **normalized summary** that can be checked against derived measurement results.
- `endorsement_aref_digests` are optional exact-artifact hints only; the pack does not imply live retrieval, latest-applicable semantics, or replacement of verifier-local endorsement/reference corpora (`attestation-endorsement-boundary-v0.md`).
- Under SNP-first D-CC flows, the pack likewise does not imply that host-exposed certificate-table material becomes the authoritative SNP signer chain or trust-root set (`confidential-computing-snp-certificate-source-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying an SNP report that contains `HOST_DATA` likewise does not normalize those bytes into a portable `CH-ATTEST` claim, policy selector, or substitute binder field (`confidential-computing-snp-hostdata-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying owner-authored `FAMILY_ID` / `IMAGE_ID` labels or `ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST` signer digests likewise does not normalize those bytes into a portable `CH-ATTEST` image/release identity or signer-identity schema (`confidential-computing-snp-launch-identity-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `CURRENT_TCB`, `COMMITTED_TCB`, `REPORTED_TCB`, or `LAUNCH_TCB` likewise does not normalize those bytes into a portable SNP baseline or patch-level claim; `REPORTED_TCB` remains signer/certificate-linkage evidence and any threshold/baseline appraisal stays verifier-local (`confidential-computing-snp-tcb-field-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying report `POLICY` likewise does not normalize those bits into a portable SlopOS security-profile, capability vector, or hidden approval language; any appraisal of exact launch-policy bits stays verifier-local (`confidential-computing-snp-policy-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `REPORT_ID` / `REPORT_ID_MA` likewise does not normalize those bytes into a portable SlopOS instance/migration identity, replay oracle, or freshness/session-resumption claim; any appraisal of exact report IDs stays verifier-local (`confidential-computing-snp-report-identity-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `CHIP_ID` likewise does not normalize those bytes into a portable SlopOS machine/asset identity, anti-cloning oracle, or release-namespace selector; any appraisal of exact or masked CHIP_ID stays verifier-local (`confidential-computing-snp-chip-id-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `PLATFORM_INFO` likewise does not normalize those bits into a portable SlopOS security-profile, machine-class taxonomy, capability vector, or hidden approval language; any appraisal of exact or feature-gated platform bits stays verifier-local (`confidential-computing-snp-platform-info-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `GUEST_SVN` likewise does not normalize that value into a portable SlopOS release-order, anti-rollback, secret-release, or approval claim; any appraisal of exact guest-version values stays verifier-local (`confidential-computing-snp-guest-svn-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `MEASUREMENT` likewise does not normalize that value into a portable SlopOS boot identity, rollout selector, or approval claim; any comparison to expected launch digests stays verifier-local and does not replace `boot_digest == digest(CH-BOOT)` or exact binder/freshness checks (`confidential-computing-snp-measurement-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying report `VERSION` / `CURRENT_*` / `COMMITTED_*` likewise does not normalize those values into a portable SlopOS platform-maturity, capability, parser-negotiation, or approval claim; any appraisal of exact version metadata stays verifier-local and does not replace TCB / boot / binder / freshness checks (`confidential-computing-snp-version-metadata-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying hypervisor-provided `GOSVW` / `guest-visible-workarounds` likewise does not normalize those bytes into a portable SlopOS feature/profile, compatibility, or approval claim; any appraisal of exact workaround bytes stays verifier-local and does not replace boot / binder / freshness checks (`confidential-computing-snp-gosvw-claim-boundary-v0.md`).
- Under D-CC flows, carrying `attest_bytes` whose `eat_payload` embeds EAT claims likewise does not normalize those claims into a portable SlopOS claim registry, approval language, or shortcut around explicit boot/provenance/report-data/freshness checks; any appraisal of exact embedded EAT claims stays verifier-local profile policy (`confidential-computing-eat-payload-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying `SIGNATURE_ALGO` / `SIGNING_KEY` / `MASK_CHIP_KEY` likewise does not normalize those values into a portable SlopOS provider/trust claim, provider-class label, unsigned-attestation fallback, or approval shortcut; any appraisal of exact signer metadata stays verifier-local and does not replace chain validation or local endorsement policy (`confidential-computing-snp-signing-metadata-claim-boundary-v0.md`).
- Under SNP-first D-CC flows, carrying an exact SNP report generated for a non-zero VMPL likewise does not make that report portable Phase 1 conformance evidence; the first portable target is a fully enlightened VMPL0 guest and Multi-VMPL / SVSM / paravisor layouts remain future annex work (`confidential-computing-snp-vmpl-mode-boundary-v0.md`).
- If a verifier cannot validate any attached provider evidence, it MAY still accept **CH-ATTEST summary-only** flows **only if** its policy explicitly allows a software signing root (deployment choice).

## Wiring

- Schema registry: `schema-registry.md` → **CH-ATTESTPACK v0**.
- Interface registry: `interface-registry.md` → **IF-ATTEST** returns/exports this bundle under the lane gate `cfg.params.lane.attest.export`.
- Related posture: `attestation-posture-v0.md` (D-ATTEST v0 meaning pin; “no privileged provider parsing”).
- Companion boundary: `attestation-endorsement-boundary-v0.md` (`endorsement_aref_digests` are optional exact-artifact hints only; verifier-local policy decides trust/applicability/freshness).
- Companion boundary: `attestation-freshness-boundary-v0.md` (freshness remains verifier-local policy over exact token/report bytes; IF-ATTEST packaging does not create a native currentness/session or challenge-service plane).
- Companion boundary: `attestation-result-boundary-v0.md` (verifier-generated attestation results remain imported evidence about one appraisal event; IF-ATTEST packaging does not create a native verifier-result or approval plane).
- Companion boundary: `attestation-identity-boundary-v0.md` (attester identity material remains exact evidence/signing context only; IF-ATTEST packaging does not create a native machine/asset/workload identity, attester inventory, or enrollment-query plane).
- Companion boundary: `attestation-collateral-status-boundary-v0.md` (certificate chains, CRLs, OCSP responses, TCB-info / identity artifacts, and cache snapshots remain exact imported evidence under verifier-local freshness/cache policy; IF-ATTEST packaging does not create a native latest-collateral or fetch/cache plane).
- Companion boundary: `cryptosvc-attestation-boundary-v0.md` (generic IF-CRYPTOSVC key use does not itself define quote/report/token selectors, challenge relay, or verifier-policy semantics; portable attestation evidence stays here on explicit D-ATTEST surfaces).
- Companion boundary: `confidential-computing-snp-certificate-source-boundary-v0.md` (host/shared-page SNP certificate tables are transport-only supporting artifacts rather than portable trust roots).
- Companion boundary: `confidential-computing-snp-hostdata-claim-boundary-v0.md` (host-supplied SNP `HOST_DATA` remains exact provider-native evidence rather than portable SlopOS attestation meaning).
- Companion boundary: `confidential-computing-snp-launch-identity-claim-boundary-v0.md` (owner-authored SNP `FAMILY_ID` / `IMAGE_ID` labels and `ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST` signer digests remain exact provider-native evidence rather than portable image/release identity meaning).
- Companion boundary: `confidential-computing-snp-tcb-field-claim-boundary-v0.md` (SNP `CURRENT_TCB` / `COMMITTED_TCB` / `REPORTED_TCB` / `LAUNCH_TCB` fields remain exact provider-native evidence with distinct meanings; `REPORTED_TCB` is signer/certificate-linkage evidence rather than a portable baseline claim).
- Companion boundary: `confidential-computing-snp-policy-claim-boundary-v0.md` (SNP `POLICY` remains exact provider-native evidence; provider-native launch bits may be appraised under explicit local policy, but they do not become a portable SlopOS security-profile or approval schema).
- Companion boundary: `confidential-computing-snp-report-identity-claim-boundary-v0.md` (firmware-generated `REPORT_ID` / `REPORT_ID_MA` remain exact provider-native evidence; they do not become a portable SlopOS instance/migration identity or hidden replay/freshness schema).
- Companion boundary: `confidential-computing-snp-chip-id-claim-boundary-v0.md` (report `CHIP_ID` remains exact provider-native evidence; it does not become a portable SlopOS machine/asset identity, anti-cloning oracle, or hidden release selector).
- Companion boundary: `confidential-computing-snp-platform-info-claim-boundary-v0.md` (report `PLATFORM_INFO` remains exact provider-native evidence; it does not become a portable SlopOS security-profile, machine-class taxonomy, capability vector, or hidden approval language).
- Companion boundary: `confidential-computing-snp-guest-svn-claim-boundary-v0.md` (owner-authored `GUEST_SVN` remains exact provider-native evidence; it does not become a portable SlopOS release-order, anti-rollback, secret-release selector, or hidden approval shortcut).
- Companion boundary: `confidential-computing-snp-measurement-claim-boundary-v0.md` (report `MEASUREMENT` remains exact provider-native launch evidence; it does not become a portable SlopOS boot identity, rollout selector, or hidden approval shortcut).
- Companion boundary: `confidential-computing-snp-version-metadata-claim-boundary-v0.md` (report `VERSION` / `CURRENT_*` / `COMMITTED_*` remain exact provider-native evidence; they do not become a portable SlopOS platform maturity, capability vector, parser-negotiation plane, or hidden approval shortcut).
- Companion boundary: `confidential-computing-snp-gosvw-claim-boundary-v0.md` (hypervisor-provided `GOSVW` / `guest-visible-workarounds` remains exact provider-native evidence; it does not become a portable SlopOS feature/profile, compatibility, or hidden approval plane).
- Companion boundary: `confidential-computing-eat-payload-claim-boundary-v0.md` (embedded `eat_payload` EAT claims remain profile-local evidence; they do not widen `CH-ATTEST` / `CH-ATTESTPACK` into a portable claim registry or hidden approval language).
- Companion boundary: `confidential-computing-snp-signing-metadata-claim-boundary-v0.md` (report `SIGNATURE_ALGO` / `SIGNING_KEY` / `MASK_CHIP_KEY` remain exact provider-native evidence; they do not become a portable SlopOS provider/trust claim, provider-class label, unsigned-attestation fallback, or hidden approval shortcut).
- Companion boundary: `confidential-computing-snp-vmpl-mode-boundary-v0.md` (the SNP-first portable Phase 1 target is a fully enlightened VMPL0 guest only; Multi-VMPL / SVSM / paravisor layouts stay future annex work).
- Companion boundary index: `confidential-computing-boundary-index.md` (keeps the current D-CC implementation/binding/trust/launch-context/imported-profile-claim/report-field companion set enumerable and machine-checked as one discovery surface, with the current provider-native SNP field inventory bucketed by authorship so verifier/export tooling can keep host vs owner vs firmware vs mixed-linkage semantics straight).

## References

- REF-RATS-RFC9334
- REF-EAT-RFC9711
- REF-COSE-RFC9052
- REF-COSE-RFC9053
- REF-TPM2-PART1
- REF-AMD-SNP-FWABI
- REF-INTEL-TDX-QUOTEEXT
- REF-CCA-TOKEN-DRAFT
