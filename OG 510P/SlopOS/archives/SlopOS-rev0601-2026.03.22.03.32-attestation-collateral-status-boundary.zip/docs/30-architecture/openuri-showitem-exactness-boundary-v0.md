# D-PLUMB OpenURI show-item exactness boundary v0 (no silent degrade to parent browse)

Purpose: pin one compact Phase-1 rule on the **OpenURI / show-item** seam: a request that means **“reveal/select this exact object in a file manager”** stays that exact intent. If the backend lacks an exact-reveal primitive, the request **fails closed** instead of silently degrading into “just open the containing directory” or a generic URI launch.

This boundary is intentionally small. It introduces **no new schema family**, no new request kind, no new receipt kind, and no new conflict-key family. It only narrows how existing `portal.uri.*` / show-item routing may interpret fallback behavior.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **Show-item means exact reveal/select, not approximate browse.**
   - A mediated “show item” / “open containing directory with this object selected” request expresses an **exact target-selection intent**.
   - Phase 1 therefore treats “select the referenced object in a file-manager context” as the requested outcome, not “do something roughly nearby that feels helpful.”
   - The requester still learns only the explicit request outcome; it does **not** gain host paths, directory handles, sibling enumeration authority, or a callback channel.

2) **No silent fallback from exact reveal/select to parent-directory browse in v0.**
   - If a backend/runtime/file-manager path cannot faithfully perform exact reveal/select for the already-held file/directory handle or CH-DOCREF reopen target, the mediated request **denies / reports unsupported**.
   - Phase 1 does **not** silently rewrite the request into “open the parent directory,” “open this directory instead,” “launch the directory URI,” or “best-effort browse near the target.”
   - A backend may internally choose among equivalent exact-reveal mechanisms, but it may not widen the semantic target class.

3) **Why fail-closed is the honest import.**
   - Ecosystems expose both exact-select primitives and looser directory-opening fallbacks.
   - Those are **not semantically identical**: one requests focus on a particular object; the other requests a broader browse surface whose visible contents and user affordances are larger.
   - Keeping the boundary explicit prevents policy/UX/test drift where one profile/runtime “reveals item” while another merely opens a folder and calls that success.

4) **No hidden widening into browse authority or existence side channels.**
   - The requester may already know the target object identity via an already-held handle / CH-DOCREF; this boundary does **not** promise hidden “prove it exists right now in a parent listing” semantics.
   - Success does **not** certify stable parent layout, sibling names, parent-path identity, or that the backend surfaced one exact visual selection primitive visible to automation.
   - Failure does **not** authorize a second probing path, parent-directory reopen fallback, path reconstruction helper, file-manager inventory API, or shell-script escape hatch.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary introduces **no new ACP kind**, **no new conflict key**, and **no new serialization lane**.
   - Existing `open_uri` / show-item request ordering remains at `svc:portal.uri`; shell-visible launch/focus order continues to serialize there.
   - The new rule only constrains what counts as an acceptable implementation of that request.

6) **Sealed compat stays honest.**
   - Foreign Cell / compat runtimes do not regain path-based “reveal in host file manager” helpers that silently widen exact-selection requests into generic folder browsing.
   - If compat wants show-item semantics, it still routes through `portal.uri.*` / CH-DOCREF mediation or fails closed.

## Phase 1 non-goals (explicitly deferred)

- No generic “best effort reveal” portability contract.
- No automatic downgrade from exact item reveal to parent-directory open.
- No new receipt field that claims whether selection vs plain browse happened.
- No app-visible file-manager capability/probing surface for “can you select this item exactly?”
- No host-path reconstruction helper to make reveal work.

## Why this cut is worth making now

Current xdg-desktop-portal documentation for `OpenDirectory` explicitly says it uses `org.freedesktop.FileManager1.ShowItems()` and, **if that service doesn’t exist**, falls back to the `OpenURI` method on the directory of the file or directory. Windows and macOS also expose exact “show this item selected in the file viewer / Explorer” primitives.

That combination makes the temptation obvious: once SlopOS supports “show item,” a runtime/backend may quietly collapse exact-reveal semantics into an approximate folder-open fallback and still report success. Pinning the boundary now keeps D-PLUMB path-free, non-amplifying, and transcript-honest across workstation and agent surfaces.

## Wiring

- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Primary posture:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
- Decision surface:
  - `docs/30-architecture/decision-map.md` (D-PLUMB)
- Control surfaces:
  - `docs/30-architecture/portal-family-registry.md` (`portal.uri.*`)
  - `docs/30-architecture/effect-contract-schema-v0.md` (`portal.uri`)
  - `docs/30-architecture/intent-kind-registry.md` (`open_uri`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-OPENURI-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-OPENURI-ENF)
- Adjacent boundary:
  - `docs/30-architecture/openuri-scheme-support-boundary-v0.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_showitem_exactness_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **exact reveal/select means exact reveal/select / no silent parent-browse fallback / no new ACP-or-conflict-key surface** posture, or drops its primary REF wiring (**EVID-2026-571**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-FDO-FILEMANAGER-SHOWITEMS.
- REF-WINDOWS-SHOPENFOLDERANDSELECTITEMS.
- REF-APPLE-ACTIVATEFILEVIEWERSELECTING.
