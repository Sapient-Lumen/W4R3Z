# SBOM external-reference locator boundary v0 (imported URLs/locators stay evidence, not native fetch/resolver authority)

Purpose: pin the Phase-1 meaning of **URL/locator fields imported through external SBOM documents** across **D-SBOM**, **D-AREF**, **D-NETLEASE**, and **D-POLICY** so one SPDX/CycloneDX link field does not quietly become a portable fetch instruction, resolver plane, same-origin hint, or evidence-closure rule.

Entropy cost justification: the archive already keeps CH-SBOM digest-bound, already keeps CH-AREF locator hints non-authoritative, and already keeps external SBOM identity/graph/package labels verifier-local. What remains cheap-but-dangerous is the locator-rich part of real SPDX/CycloneDX documents: SPDX has `PackageDownloadLocation`, `PackageHomePage`, `ExternalRef` locators, and free-form source/origin commentary; CycloneDX `externalReferences` intentionally carries many URL-like link types including BOM, advisory, distribution, documentation, and support links, sometimes with hashes. Leaving that relationship unstated invites expensive drift later: imported links start acting like a native fetch plan, a hidden mirror-selection rule, or a cross-document evidence-discovery channel. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still point at one exact external SPDX/CycloneDX document via `external_doc_aref`.
- **CH-AREF v0** may still bind exact imported artifacts by digest, with locators staying hints only.
- **Verifier-local policy/tooling** may still parse or display imported URLs/locators, but dereferencing them stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **Imported SBOM URL/locator fields stay descriptive references only.**
   - SPDX `PackageDownloadLocation`, `PackageHomePage`, `ExternalRef` locators, and similar imported fields record where upstream tooling says more package information, source material, or related identifiers may exist.
   - CycloneDX `externalReferences` likewise records contextual links such as advisories, BOMs, documentation, support, distribution, and other related resources.
   - Phase 1 therefore treats these values as imported descriptive references, not as native SlopOS fetch instructions, trust roots, or same-component proofs.

2) **No native auto-follow / fetch plane rides on imported links.**
   - An imported download URL, VCS location, homepage, advisory link, BOM link, or documentation URI does not imply “fetch this now,” “follow this to complete verification,” or “consult the network to finish interpretation.”
   - Any dereference remains explicit local tooling above the authority substrate and, if networked, must use already-pinned **D-NETLEASE** controls.
   - Companion `artifact-resolution-posture-v0.md` already pins that locators are hints only; this boundary further pins that imported SBOM links stay on the same non-authoritative side of the line.

3) **Exact evidence binding still rides on digests, not imported URLs.**
   - Exact imported SBOM bytes are still bound by **CH-AREF** digests or by locally supplied artifact bytes.
   - An imported URL, VCS locator, homepage, or advisory/documentation link therefore carries no portable authority to replace the current document, widen the evidence set, or outrun a digest mismatch.
   - Companion `sbom-document-supersession-boundary-v0.md` already pins that external SBOM document identity/version fields do not create a native latest-wins rule; link fields do not become a back door around that split.

4) **No native mirror / fallback / latest-by-link rule exists in Phase 1.**
   - If an imported SBOM carries several references (for example, source archive, VCS URL, documentation, support page, external BOM, or advisory feed), Phase 1 imports no rule for which one is preferred, freshest, authoritative, or complete.
   - Matching hostnames, similar paths, or repeated links across documents do not create a native “same upstream therefore trust/follow/merge” rule.
   - Any prioritization, retry, or fallback behavior remains verifier-local tooling/policy rather than carrier-visible semantics.

5) **Imported reference types do not create native closure or resolver semantics.**
   - A CycloneDX external reference of type `bom`, `advisories`, `distribution`, `documentation`, `support`, or similar may help local tooling, but it does not by itself widen CH-SBOM into a recursive evidence-closure language.
   - An SPDX `ExternalRef` locator may name additional metadata, downloadable content, or identifiers, but it does not become a native component resolver, relationship crawler, or policy-import channel.
   - Companion `sbom-spdx-reference-boundary-v0.md`, `sbom-spdx-relationship-boundary-v0.md`, and `verification-material-discovery-boundary-v0.md` already pin the adjacent seams; this boundary keeps imported URL/locator fields from silently reopening them.

6) **Human-facing convenience fields do not become trust or support authority.**
   - SPDX `PackageHomePage`, CycloneDX `support` / `documentation` / `website` external references, and similar convenience links may help operators inspect or route work.
   - They do not become a native support-owner oracle, vendor-trust hint, remediation-owner selector, or escalation path in Phase 1.
   - Companion `sbom-supplier-origin-boundary-v0.md` already pins adjacent supplier/origin labels to provenance evidence only; imported convenience links stay on that same evidence side of the line.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported SPDX/CycloneDX link fields fit with existing SBOM/reference/network seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `downloadLocation` / `homepage` / `externalReferences` fetch contract.
- No portable mirror selection, retry, or latest-by-link rule for imported SBOM documents.
- No automatic chase from imported BOM/advisory/documentation/support links into a wider evidence set.
- No imported-link-based trust, support-routing, or remediation authority.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is intentionally richer than our authority substrate:
- SPDX 2.3 explicitly defines `PackageDownloadLocation` as a URL or VCS location, says user credentials in hostnames are not supported, and says user access control to URLs or VCS repositories must be handled outside the SPDX document.
- SPDX 2.3 defines `PackageHomePage` as a URL for more information and `ExternalRef` as a locator to outside information, metadata, identifiers, or downloadable content relevant to a package.
- CycloneDX external references are designed to link components/BOMs to outside resources, accept many URI schemes, and include types such as BOM, advisories, distribution, documentation, support, and exploitability statements.

Pinning that split now prevents SlopOS from quietly reinventing an ambient SBOM link crawler, mirror selector, or “just follow the advisory/BOM URL” authority plane under the names of SBOM convenience or interoperability.

## Profile effect (A–D)

- **Secure workstation (A):** local tools may still display or optionally open imported package/vendor links, but the workstation does not inherit a hidden trust/fetch plane from SBOM metadata.
- **Cloud micro-VM substrate (B):** fleet tooling may mirror or enrich SBOMs externally, yet verifier meaning stays local and digest-bound rather than “whatever the linked registry or feed currently serves.”
- **Embedded / separation appliance (C):** offline verifiers stay small because imported links never require a URL/VCS fetch engine to preserve SBOM meaning.
- **Agent/automation OS (D):** agents may reason over imported reference graphs, but they cannot smuggle ambient network/discovery authority through one helpful-looking SBOM link.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-AREF**, **D-NETLEASE**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/artifact-resolution-posture-v0.md`
  - `docs/30-architecture/sbom-document-supersession-boundary-v0.md`
  - `docs/30-architecture/sbom-spdx-reference-boundary-v0.md`
  - `docs/30-architecture/sbom-spdx-relationship-boundary-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_external_reference_locator_boundary.py` keeps the split small and discoverable (**EVID-2026-496**).

## References

- **REF-SPDX-PACKAGE-DOWNLOAD**
- **REF-SPDX-PACKAGE-HOMEPAGE**
- **REF-SPDX-EXTERNAL-REF-LOCATOR**
- **REF-CYCLONEDX-EXTERNAL-REFERENCES**
