# SBOM/VEX evidence-set boundary v0 (multiple exact supply-chain evidence artifacts stay verifier-local)

Purpose: pin the Phase-1 meaning of **multiple exact SBOM/VEX evidence artifacts** across **D-SBOM**, **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, and **D-AREF** so one carrier plus adjacent inventory/exploitability artifacts do not quietly imply a native vulnerability/applicability closure, completeness claim, or preference rule.

Entropy cost justification: the archive already pins one-subject CH-SBOM and one-subject CH-VEX semantics, plus update/boot carriers that may attach exact SBOM/VEX digests. Real ecosystems often ship several inventories, several exploitability statements, and richer external documents side by side for the same release. Leaving that relationship unstated invites expensive drift later: tools start treating “all nearby SBOM/VEX material” as one authoritative applicability set, or a carrier starts implying a portable completeness/union rule. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** still says what one exact subject inventory snapshot names.
- **CH-VEX v0** still says what one exact subject exploitability statement set claims.
- **CH-UPD v0** and **CH-BOOT v0** may pin several exact `sbom` / `vex` / related evidence artifacts in `artifacts[]`.
- **Verifier-local policy** still answers whether any selected artifacts are required, how they are related, and whether coverage/completeness is sufficient for one already-pinned cohort.

## Posture (v0)

1) **Multiple exact CH-SBOM / CH-VEX artifacts do not become one native vulnerability/applicability closure.**
   - A deployment may carry several exact inventory/exploitability artifacts, including multiple `sbom` or `vex` role entries plus imported external docs reachable through **CH-AREF v0**.
   - Phase 1 imports each artifact as **exact bytes only** under its own seam.
   - It does **not** import a native rule that “all attached SBOM/VEX material is jointly authoritative”, “the set is complete”, or “the carrier defines the full applicability closure for this release”.

2) **Cross-artifact union/reconciliation remains verifier-local, not carrier-visible semantics.**
   - If several exact artifacts each contain inventory or exploitability statements about the same already-pinned subject, the carrier does not thereby choose how they compose.
   - There is no native “union all matching component entries”, “prefer the VEX whose `inventory_digest` matches one attached SBOM”, “latest advisory wins”, “vendor SBOM overrides scanner SBOM”, or “multiple attached VEX documents jointly close all findings” rule.
   - Any such relation remains explicit verifier-local tooling or future RFC work.

3) **Inventory links and adjacency do not auto-prove completeness or applicability.**
   - `inventory_digest`, neighboring bundle placement, and shared subject digests are **references**, not portable completeness proofs.
   - A verifier may use those references to select candidate artifacts, but the presence of linked or adjacent artifacts does not by itself prove that every relevant component is inventoried or every relevant vulnerability statement has been supplied.
   - Extra artifacts therefore remain extra evidence context only unless verifier-local policy says otherwise.
   - Companion `vex-component-absence-boundary-v0.md` further pins that one `component_not_present` statement plus one linked inventory does not become a native absence oracle either.

4) **Each selected artifact still verifies on its own seam.**
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds the exact subject digest the verifier cares about.
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds the exact subject digest the verifier cares about.
   - **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, and **PO-AREF-VERIFY** still answer carrier/evidence integrity for the exact already-pinned cohort.
   - Cross-artifact co-presence does not fuse those checks into a portable “supply-chain evidence set passed” verdict.

5) **Ordering, attachment count, and packaging location are non-authoritative.**
   - File order inside a release zip, `artifacts[]` order, sidecar naming, bundle adjacency, or “put VEX next to SBOM” packaging conventions stay non-authoritative.
   - The portable meaning remains the exact digest of each artifact plus whichever already-pinned schema interprets those bytes.
   - Companion `verification-material-discovery-boundary-v0.md` still pins that discovery stays explicit and killable rather than inferred from sidecar habit.

6) **No portable fallback/preference/completeness/supersession rule in v0.**
   - Phase 1 adds no native “if one VEX is missing, fall back to another”, “prefer the richer SBOM”, “take the intersection of all advisories”, “the union of all attached SBOMs defines closure”, or “this exact evidence set supersedes earlier ones” meaning.
   - Any fallback, tie-breaking, completeness notion, or history/supersession logic remains verifier-local tooling and must not be inferred from artifact count or packaging style.

7) **Imported external docs remain imported evidence, not native closure semantics.**
   - Full SPDX / CycloneDX SBOM documents and OpenVEX / CSAF / CycloneDX VEX documents may be attached through **CH-AREF v0**.
   - Their richer internal graph/advisory semantics stay imported evidence only unless another seam explicitly imports them.
   - Attaching those documents next to CH-SBOM / CH-VEX does not create a second native component-resolution or applicability language in Phase 1.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing inventory/exploitability/update/boot/evidence seams interpret several exact evidence artifacts.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native SBOM/VEX evidence-set schema or applicability-closure grammar.
- No portable union/preference/fallback/completeness rule across several exact SBOM/VEX artifacts.
- No rule that shared subject digests or `inventory_digest` links choose one another’s meaning.
- No cross-artifact supersession/history semantics for inventory/advisory artifacts.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem stays deliberately layered:
- NTIA’s SBOM minimum-elements framing treats the SBOM as the visibility/identification substrate and notes that external data may still be needed for vulnerability analysis;
- OpenVEX is intentionally **SBOM-format agnostic**, which is useful interoperability-wise but means a VEX document does not by itself define one universal native inventory-binding or closure rule;
- CycloneDX’s VEX material focuses on exploitability in context, but richer intra-BOM / cross-BOM references remain format semantics rather than one small portable OS-level authority substrate.

Pinning that split now keeps SlopOS from quietly inheriting “all nearby SBOM/VEX material forms one authoritative applicability set” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** release bundles may carry vendor + local inventory/advisory evidence without making install meaning depend on bundle adjacency or attachment count.
- **Cloud micro-VM substrate (B):** fleet update tooling may inspect richer supply-chain evidence packs, but verifier behavior stays explicit about which exact artifacts matter for one cohort.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject or select exact SBOM/VEX artifacts without importing a general applicability-closure algorithm.
- **Agent/automation OS (D):** agents may analyze richer inventory/advisory packs, but they cannot smuggle “all attached supply-chain evidence jointly closes the finding set” into portable meaning.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-AREF**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/30-architecture/vex-component-absence-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-VEX-1**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-AREF-1**.
  - **PO-SBOM-BIND**, **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_vex_evidence_set_boundary.py` keeps the split small and discoverable (**EVID-2026-482**).

## References

- **REF-NTIA-SBOM-MIN2021**
- **REF-CISA-VEX-MINREQ**
- **REF-OPENVEX-SPEC**
- **REF-CYCLONEDX-OVERVIEW**
