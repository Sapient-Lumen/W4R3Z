# Signature / verification boundary index (v0)

Purpose: keep the **closed set of D-SIGENV / D-KEYLESS / D-TLOG companion boundary docs** enumerable.

Why this exists:
- the archive now pins many small signature / certificate / keyless / transparency companion boundaries so signed-artifact ecosystems do not quietly become native authority,
- those docs are individually crisp but easy to forget piecemeal because they span certificate/path handling, verifier policy, transparency proof transport, and verdict shortcuts,
- `signature-envelope-posture-v0.md` and `transparency-log-posture-v0.md` keep the overall meaning of D-SIGENV / D-KEYLESS / D-TLOG, while this index is the **discovery surface** that says which companion boundaries currently make signed-artifact verification fail closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `signature-envelope-posture-v0.md`, `transparency-log-posture-v0.md`, and RFC-0093.

## Inclusion rule

A doc belongs here if it removes exactly one tempting signed-artifact / verification meaning from Phase 1 by constraining one of:
- certificate / signer / trust-root inputs that would otherwise smuggle in a native path-discovery, identity-selection, signer-quorum, duplicate-counting, trust-enrollment, or algorithm-negotiation plane,
- verifier-material / proof / policy / verdict semantics that would otherwise smuggle in a native sidecar-discovery, bundle-completeness, policy-selection, or approval plane,
- transparency / timestamp adjunct semantics that would otherwise smuggle in a native witness-discovery, proof-refresh, freshness, or time-admin plane.

If future work needs a new native control surface instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind imported signing or transparency metadata.

## Closed companion boundary set (Phase 1)

### 1) Certificate and signer inputs stay explicit verifier-local evidence

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`certificate-path-input-boundary-v0.md`](certificate-path-input-boundary-v0.md) | AIA / `caIssuers` / presented chains | imported chain/path hints do not become a native path-discovery or alternate-chain synthesis plane | explicit verifier-local chain/path inputs |
| [`certificate-status-evidence-boundary-v0.md`](certificate-status-evidence-boundary-v0.md) | CRL / delta-CRL / OCSP status artifacts | imported revocation/status artifacts remain exact local evidence rather than a native status-cache or approval plane | explicit local freshness / soft-fail policy |
| [`certificate-identity-evidence-boundary-v0.md`](certificate-identity-evidence-boundary-v0.md) | SAN / subject / issuer / custom OID identity fields | imported certificate identity claims stay exact signed evidence rather than a native best-identity, wildcard, or repo-owner lookup plane | explicit verifier-local identity interpretation |
| [`signature-trust-root-boundary-v0.md`](signature-trust-root-boundary-v0.md) | trusted roots / log keys / TSA roots | imported trust-root carriers do not become a native self-anchoring, service-discovery, or trust-enrollment plane | explicit local roots or explicit D-TUF/provisioning artifacts |
| [`signature-algorithm-acceptance-boundary-v0.md`](signature-algorithm-acceptance-boundary-v0.md) | signature/message algorithm identifiers | imported algorithm labels stay exact signed evidence rather than a native negotiation or strongest-wins plane | explicit verifier-local algorithm policy |
| [`signature-signer-acceptance-boundary-v0.md`](signature-signer-acceptance-boundary-v0.md) | signer-set / threshold / role-group mapping semantics | imported signature arrays and signer hints do not choose any-one-of/all-of/threshold acceptance, duplicate counting, or maintainer-role meaning | explicit verifier-local signer/quorum policy |
| [`keyless-issuer-discovery-boundary-v0.md`](keyless-issuer-discovery-boundary-v0.md) | OIDC/OAuth issuer metadata / SigningConfig descriptors | imported keyless issuer metadata stays signer/client online config rather than a native issuer-discovery or login plane | explicit local issuer allowlists and identity policy |

### 2) Verification semantics stay verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`verification-material-discovery-boundary-v0.md`](verification-material-discovery-boundary-v0.md) | sibling sidecars / OCI referrers / registry attachments | imported discovery conventions do not become a native sidecar/referrer/registry-discovery plane | explicit artifact bytes plus explicit verification-material artifacts |
| [`verification-policy-selection-boundary-v0.md`](verification-policy-selection-boundary-v0.md) | policy IDs / bundle-selected policy hints | imported evidence fields do not choose which verifier policy is in force | explicit verifier-owner policy selection |
| [`verification-verdict-boundary-v0.md`](verification-verdict-boundary-v0.md) | verification results / summaries / third-party passes | imported verification outcomes stay evidence rather than a native verified-good, waiver, or latest-verified plane | explicit local evaluation under local policy |
| [`proof-bundle-role-boundary-v0.md`](proof-bundle-role-boundary-v0.md) | loose `proof_bundle` role/kind labels | imported bundle labels do not become a native proof-package protocol, completeness rule, or approval shortcut | explicit exact artifact digests plus explicit local policy |
| [`signature-countersignature-boundary-v0.md`](signature-countersignature-boundary-v0.md) | countersignatures / nested signed wrappers / timestamp tokens | imported second-order signatures do not become payload approval, transitive subject closure, quorum policy, or verdict shortcuts | explicit local policy over exact second-order subject bytes |

### 3) Transparency and timing adjuncts stay evidence-only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`signing-time-evidence-boundary-v0.md`](signing-time-evidence-boundary-v0.md) | timestamps / signing-time evidence | imported timing evidence must cover the signing event, and never becomes a native freshness, approval, or time-admin plane | explicit local time policy and exact signing-event evidence |
| [`transparency-witness-acceptance-boundary-v0.md`](transparency-witness-acceptance-boundary-v0.md) | witness identities / quorums / checkpoint signatures | imported witness statements do not auto-enroll trust, define quorum, or imply audit-complete | explicit local witness set and threshold policy |
| [`transparency-proof-import-boundary-v0.md`](transparency-proof-import-boundary-v0.md) | offline inclusion / witness proof artifacts | imported proof packaging does not become a native tile-fetch, witness-query, or proof-refresh plane | explicit external proof artifacts referenced by digest |

## Review rule

Before adding another signature/keyless/verification companion boundary doc, answer these questions in order:
1) Is the change really a **D-SIGENV / D-KEYLESS / D-TLOG meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
