# D-CRYPTOSVC interactive-auth boundary v0 (no portable PIN / biometric / presence / unlock seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable token-unlock, PIN-entry, biometric/presence-prompt, or authentication-state surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable interactive-auth seam in v0**
   - Phase 1 does **not** export a portable `pin`, `pin_prompt`, `secure_pin`, `pin_cache_ttl_s`, `unlock_provider`, `unlock_token`, `login_required`, `login_state`, `session_unlocked`, `biometric`, `face_id`, `touch_id`, `user_presence`, `device_credential`, `protected_auth_path`, `auth_timeout_s`, `reuse_auth_window_s`, `prompt_if_needed`, `ui_policy`, `prompt_reason`, or equivalent unlock/presence field on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - A provider may internally require token login, secure PIN entry, user presence, device credential, or biometric approval before a concrete key use, but those mechanics remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret local prompt modality, cached-auth windows, token-login state, or protected-auth-path behavior as a requester-visible result, durable receipt, or transcript-stable statement that one exact unlock/auth ceremony happened in one exact way.

2. **`confirm` stays an explicit approval requirement, not a prompt-type selector or auth-state query**
   - `CH-KEYPOL confirm=true` keeps one small portable meaning: the provider must require an explicit approval decision before completing the op.
   - It does **not** standardize *how* that approval is obtained, whether it is satisfied by a shell-owned secure prompt, smartcard PIN pad, biometric factor, device passcode, hardware button, cached presence window, or another provider-local mechanism.
   - Phase 1 therefore adds no portable “is the key already unlocked?”, “prompt now for biometrics”, “use the cached auth window”, or “require Face ID instead of passcode” control plane on generic crypto use.

3. **Interactive unlock/auth is a second workflow, not generic crypto use**
   - Existing ecosystems really do expose these surfaces. PKCS #11 standardizes token login and protected authentication path behavior. Apple binds keychain/key access to LocalAuthentication and user-presence access-control flags. Android exposes auth-per-use keys through BiometricPrompt. Microsoft CNG carries strong-key UI and smartcard PIN properties on key/provider handles.
   - Those are valuable product workflows, but they also allocate extra UI-hosting, prompt-modality, caching, privacy, accessibility, and state-query semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden unlock broker, biometric prompt router, token-login API, or auth-state query plane.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future interactive-auth / token-unlock workflow must state its own conflict keys, commutativity, serialization point, trusted-UI path, accessibility story, redaction rules, and evidence plan explicitly rather than inheriting folklore from PKCS#11 login, LocalAuthentication, Android biometric prompts, or CNG strong-key UI.
   - Until then, generic crypto use remains keyref/route-bound only; interactive unlock/auth stays hidden inside provider-local or deployment-local setup/approval workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `pin`, `pin_prompt`, `secure_pin`, `biometric`, `user_presence`, `device_credential`, `auth_timeout_s`, `prompt_if_needed`, or equivalent unlock/auth knob/result on generic crypto use.
- No transcript-stable statement that crypto use also performed a specific biometric, passcode, PIN, secure-element, or protected-auth-path ceremony on behalf of the caller.
- No portable query for current token-login state, cached-auth freshness, or “already unlocked” status on IF-CRYPTOSVC.
- No helper/wrapper fallback that quietly promotes key use into an interactive-auth workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “sign this and prompt for Face ID”, “tell me whether the token is already unlocked”, “reuse the last biometric approval for 30 seconds”, or “open the smartcard PIN dialog if needed and report which prompt ran.” Once those assumptions land in transcripts and automation, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden unlock/presence broker. That matters for all four product shapes: workstation UX can still use local secure prompts or hardware-presence factors without standardizing them as portable substrate meaning; hosted and embedded profiles avoid inheriting UI/presence/token-login contracts they do not actually want; and agent tooling cannot mistake CH-KEYREF/IF-CRYPTOSVC for permission to query or steer human-verification state.

## Profile effect (A–D)

- **Secure workstation (A):** local secure prompts, biometric/presence gates, or smartcard PIN paths may still exist, but generic crypto use does not standardize those ceremonies or cache-state outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake biometric/presence or token-login semantics they cannot honestly provide.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose PIN/prompt/auth-state APIs they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to trigger/query hidden presence prompts, biometric state, or cached unlock state; reviewed interactive approval stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_interactive_auth_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable PIN / biometric / presence / unlock seam / `confirm` stays approval-only / interactive auth is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-599**).

## References

- REF-PKCS11-SPEC.
- REF-APPLE-LOCALAUTH-KEYCHAIN.
- REF-ANDROID-BIOMETRICPROMPT.
- REF-MICROSOFT-NCRYPT-UIPOLICY.
