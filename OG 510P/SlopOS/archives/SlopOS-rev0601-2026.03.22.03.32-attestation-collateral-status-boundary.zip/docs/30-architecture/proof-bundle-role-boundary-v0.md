# Proof-bundle role boundary v0 (descriptive adjunct-evidence label only; no native proof-bundle or verdict plane)

Purpose: pin the Phase-1 meaning of the loose `proof_bundle` role/kind label across **D-PCP**, **D-ATOMICUPD**, **D-TLOG**, and **D-AREF** so one convenient word does not quietly expand into a native schema family, a fetch protocol, or a portable approval shortcut.

Entropy cost justification: the archive already uses `proof_bundle` as an example role in **CH-BOOT v0**, **CH-UPD v0**, **CH-PROV v0**, and `proof_bundle_digest` in **CH-TLOG v0**. Leaving that label informal invites exactly the kind of drift we are trying to prevent: different tools start treating “bundle” as “the right verification package”, “the object that proves installability”, or “the thing to fetch recursively”. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-BOOT v0** and **CH-UPD v0** may list a `proof_bundle` role as one exact adjunct artifact digest.
- **CH-PROV v0** may describe proof-related outputs or evidence digests, but it stays build provenance rather than a bundle protocol.
- **CH-TLOG v0** may anchor the digest of one exact external proof artifact, but it does not reinterpret what that artifact means.
- **CH-AREF v0** may carry exact digest-bound references to those artifacts, with locators staying untrusted hints.

## Posture (v0)

1) **`proof_bundle` is a descriptive role/kind for one exact adjunct evidence artifact digest.**
   - When `proof_bundle` appears in `artifacts[].role`, `subjects[].role`, or a related leaf kind, the authoritative meaning is still the **exact artifact digest** and the already-pinned schema carrying that digest.
   - The role label helps humans classify “this digest names some packaged supporting evidence”, but it does **not** define a universal bundle format, verifier profile, or approval state.
   - Phase 1 therefore refuses the shortcut “it says `proof_bundle`, therefore the verifier knows what is inside and what policy it satisfies”.

2) **No native proof-bundle schema family or required interior layout in Phase 1.**
   - The archive does **not** standardize any native proof-bundle / verification-package schema family for “all proofs needed for verification”.
   - A `proof_bundle` digest may point to many different exact external artifacts: a Sigstore bundle, a C2SP `tlog-proof@v1` file, an attestation set, a zipped model-check report collection, or another owner-local packaging of exact evidence bytes.
   - Any claims about the bundle’s interior members, completeness, or semantics remain external-format-specific and local-policy-specific.

3) **Imported ecosystem bundles remain imported evidence, not portable verdicts or install shortcuts.**
   - Sigstore bundles, C2SP `tlog-proof@v1`, and similar packaged verification materials are useful because they can carry exact verification material offline.
   - They still do **not** by themselves mean “verified-good”, “approved for install”, “fresh enough”, “policy-complete”, or “safe to boot”.
   - This keeps `proof_bundle` aligned with `verification-verdict-boundary-v0.md`, `verification-material-discovery-boundary-v0.md`, and `transparency-proof-import-boundary-v0.md`.

4) **Bundle presence does not choose verifier policy or required evidence profile.**
   - Whether a verifier requires a particular bundle, ignores it, or checks some exact members inside it remains explicit local policy.
   - A deployment may pin exact required bundle digests or exact expected imported formats, but Phase 1 adds no rule that “if `proof_bundle` is present, use it”, “if multiple bundles exist, pick the best one”, or “this bundle chooses the matching policy”.
   - A generic role label therefore never outruns explicit verifier configuration.

5) **`proof_bundle` does not create recursive fetch, discovery, or query authority.**
   - A bundle digest may be shipped directly, referenced through **CH-AREF**, or carried in a release package.
   - The role label does **not** imply sibling-file discovery, OCI referrer lookup, registry crawling, recursive member fetch, or “ask the log/registry for the rest of the proof”.
   - Any such retrieval remains tooling-only, killable by policy, and subordinate to the already-pinned verification-material and transparency import seams.

6) **If `CH-TLOG v0` anchors `proof_bundle_digest`, it anchors exact bytes only.**
   - `leaf_kind = proof_bundle_digest` means the transparency log anchored the digest of **one exact external proof artifact**.
   - It does **not** mean the log/operator/witnesses semantically approved every statement inside the bundle, nor that the bundle is complete for install/update/boot policy.
   - Anchoring a bundle digest is therefore evidence about exact bytes plus append-only log state, not a compressed approval verdict.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no publication queue, no bundle-inventory portal, and no approval workflow.
   - Any future desire for native bundle publication, member enumeration, or portable bundle-completeness semantics must return RFC-first with explicit subject model, conflict keys, commutativity rules, serialization boundary, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native proof-bundle / “verification package” schema family.
- No universal interior-member list or completeness semantics for `proof_bundle`.
- No rule that bundle presence implies approval, installability, or freshness.
- No bundle-selected verifier policy or evidence profile.
- No ambient sibling-file / registry / log / witness discovery or recursive fetch plane.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is intentionally mixed:
- Sigstore bundles package signature content plus verification material for offline verification.
- C2SP `tlog-proof@v1` packages offline-verifiable transparency proof material.
- SLSA verification guidance still says verification depends on comparing evidence against explicit expectations.

Pinning this split now keeps SlopOS from turning one loose example role into a hidden bundle protocol, a universal “verification package” abstraction, or a verdict-bearing install shortcut.

## Profile effect (A–D)

- **Secure workstation (A):** operators can carry explicit proof packages for offline review without turning “bundle present” into an approval badge.
- **Cloud micro-VM substrate (B):** promotion tooling may package evidence aggressively, but cluster install/admission still depends on explicit local policy rather than generic bundle roles.
- **Embedded / separation appliance (C):** image releases may ship compact offline proof packages while keeping verifier behavior deterministic and air-gap friendly.
- **Agent/automation OS (D):** agents can reason over packaged evidence, but they cannot smuggle “proof bundle therefore do it” authority through a loose role label.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-ATOMICUPD**, **D-TLOG**, **D-AREF**.
- Adjacent seams:
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/provenance-attestation-schema-v0.md`
  - `docs/30-architecture/transparency-log-anchor-schema-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/30-architecture/transparency-proof-import-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-AREF-1**, **I-PROV-CHAIN-1**, **I-TLOG-1**.
  - **PO-AREF-VERIFY**, **PO-PROV-BIND**, **PO-TLOG-VERIFY**, **PO-UPD-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_proof_bundle_role_boundary.py` keeps the split small and discoverable (**EVID-2026-476**).

## References

- **REF-SIGSTORE-BUNDLE**
- **REF-TLOG-PROOF**
- **REF-SLSA-VERIFYING-ARTIFACTS**
