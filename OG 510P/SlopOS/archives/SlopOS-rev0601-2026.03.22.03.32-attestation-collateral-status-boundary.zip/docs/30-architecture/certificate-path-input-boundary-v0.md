# Certificate-path input boundary v0 (no ambient AIA chase or alternate-chain synthesis)

Purpose: pin the **Phase 1** meaning of certificate/path inputs for **D-SIGENV** and **D-KEYLESS** so cert-based verification does not silently inherit browser / PKI path-builder folklore.

Entropy cost justification: `signature-envelope-posture-v0.md` already pins signed meaning, offline-first verification, and keyless identity policy, but the **certificate/path input seam** is still partly implicit. One narrow boundary closes that gap without introducing a new schema family, trust-distribution plane, or signing workflow surface.

## Posture (v0)

1) **Path validation consumes explicit verifier-local inputs only.**
   - Trust anchors, accepted intermediate certificates, any presented certificate-chain bytes, and any transparency / timestamp artifacts remain **explicit local policy inputs** or explicit packaged artifacts.
   - **CH-SIGENV v0** does not imply a privileged-core certificate fetcher, ambient system trust-store scan, browser-style AIA chase, or hidden intermediate-cache lookup.
   - Accepted meaning still lands under **I-SIGENV-1**, **I-KEYLESS-1**, **PO-SIGENV-VERIFY**, and **PO-KEYLESS-VERIFY**.

2) **AIA / `caIssuers` / subject-information locator fields are hints only, not authority.**
   - `authorityInfoAccess`, `id-ad-caIssuers`, `id-ad-ocsp`, subject-information access, and similar embedded locators may exist inside presented certificates, but in Phase 1 they are **non-authoritative hints only**.
   - A verifier may ignore them entirely.
   - Their presence MUST NOT create a portable “discover the rest of the chain / trust roots / online status from the network” meaning.

3) **Presented chain bytes are evidence inputs, not automatic trust-set expansion.**
   - A leaf certificate, intermediate certificate, or cross-sign included with a signed artifact is an **evidence input** to local verification, not a command to expand the trusted root or accepted-intermediate set.
   - Encountering a new issuer certificate, alternate cross-sign, or longer chain inside a bundle MUST NOT auto-promote that chain into the accepted verifier baseline.
   - If policy requires an explicit out-of-band intermediate allowlist, certificates outside that allowlist are ignored or rejected rather than silently counted as a valid alternate path.

4) **Certification path building stays verifier-local policy, not portable substrate meaning.**
   - RFC 4158 describes many possible certification-path-building strategies rather than one canonical algorithm; SlopOS therefore standardizes **verified result meaning**, not a portable “best chain” search procedure.
   - The same leaf may have more than one locally acceptable path depending on explicit trust roots, explicit intermediates, and explicit time/status policy.
   - Phase 1 adds no “latest chain wins”, “preferred cross-sign”, “best path”, or “system-default path builder” authority plane.

5) **No ambient AIA chase / alternate-chain synthesis / trust-store search plane in v0.**
   - Phase 1 standardizes no privileged certificate-fetch service, no AIA/`caIssuers` callback, no hidden OS trust-store bridge, no certificate-chain inventory service, and no alternate-chain discovery protocol.
   - If a deployment wants richer certificate/path discovery or federation, it must arrive as an explicit RFC-first seam with its own kill switches, evidence, and policy boundaries.

6) **Interop chain material stays out-of-band and digest-bound.**
   - Certificate / intermediate / bundle bytes may be carried as explicit artifacts (for example through **CH-AREF**, handoff packaging, or explicit local verifier configuration), but they remain adjunct evidence rather than embedded native authority.
   - Out-of-band intermediate allowlists remain explicit local policy inputs or explicit package artifacts; they do not become ambient machine-global discovery state.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no new **CH-*** schema family, no ACP action kind, and no conflict-key namespace.
   - It only narrows what existing cert-bearing verification artifacts are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native AIA/`caIssuers` fetch client or privileged certificate-discovery plane.
- No portable certificate-chain inventory/query service or ambient OS trust-store bridge.
- No portable "best chain" / alternate-chain ranking or latest-chain authority.
- No automatic promotion of bundled intermediates or cross-signs into verifier trust baselines.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, cert-based verification will almost always drift in one of three expensive directions:

- **AIA chasing becomes hidden network authority.** A verifier that “just fetches what the cert says” silently reintroduces ambient network and mutable remote state into a seam the archive already intended to keep offline-first.
- **Cross-signs become trust growth by accident.** Presented intermediates or alternate paths start behaving like “whatever validated on this machine today” rather than “what local policy explicitly accepts”.
- **PKI library choice becomes archive meaning.** RFC 4158 is deliberately not one algorithm; if SlopOS leaves path building implicit, whichever path builder happens to be linked on the host quietly becomes the platform contract.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** reviewable offline verification stays possible without browser-style AIA fetch or trust-store magic.
- **Cloud micro-VM / hosted substrate (B):** release/admission workers can consume exact verifier inputs and produce reproducible evidence instead of machine-specific path-builder outcomes.
- **Embedded / separation-kernel-ish appliance (C):** high-assurance profiles keep trust roots and intermediates small, explicit, and packageable.
- **Agent / automation OS (D):** LLM-mediated tooling cannot hide “it verified on my laptop” chain discovery behind a proposal surface; exact verifier inputs stay inspectable.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-TIME**, **D-TUF**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/signing-time-evidence-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_certificate_path_input_boundary.py` keeps the boundary small and discoverable (**EVID-2026-466**).

## References

- REF-RFC5280-PKIX
- REF-RFC4158-PATHBUILD
- REF-SIGSTORE-BUNDLE
- REF-SIGSTORE-CLIENT-SPEC
