# D-PLUMB OpenURI scheme-support boundary v0 (no requester-visible handler oracle)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: exact knowledge about whether some backend/desktop/platform *could* open a URI scheme is **shell/policy-local routing knowledge**, not a portable requester-visible API or future-success promise.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request type, no new receipt kind, and no new `can-open?` / `scheme-supported?` surface. It only narrows how existing OpenURI routing knowledge may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **Exact scheme-support knowledge stays shell/policy-owned.**
   - A shell/portal/backend may internally know default-handler memory, current desktop capabilities, or platform-specific scheme-support facts.
   - That knowledge remains routing-local implementation state owned by `svc:portal.uri`, not a portable requester capability.
   - Phase 1 therefore imports the **mediated launch** lesson from ecosystem OpenURI surfaces without importing a generic installed-handler oracle.

2) **No requester-visible `SchemeSupported` / `canOpenURL` / `queryIntentActivities` equivalent in v0.**
   - Applications do **not** get a portable `scheme_supported(scheme)`, `can_open(uri)`, `list_supported_schemes()`, or handler-probing call on `portal.uri.*`.
   - The portable requester action remains the ordinary `open_uri` mediation request itself.
   - If a platform/backend internally offers exact scheme-support queries, SlopOS treats them as implementation detail rather than native portable semantics.

3) **Shell UX hints may exist, but they remain coarse and non-authoritative.**
   - A shell may gray out a local affordance, prefill chooser UI, or suppress obviously disallowed schemes using its own local policy.
   - Such UX state is shell-local convenience only: it is not transcript-stable evidence, not a portable receipt, and not a promise that a later launch will succeed or fail the same way.
   - The only portable truth for requesters is the outcome of the actual mediated `open_uri` request.

4) **Support knowledge does not become installed-app inventory or future-success proof.**
   - “A scheme appears supported” does **not** prove which handler is installed, whether one or many handlers exist, which app will be chosen, whether the user will approve/redirect, or whether downstream launch/network work will complete.
   - “A scheme appears unsupported” does **not** justify a second hidden probing path, package query, callback registration, or helper fallback.
   - Default-handler changes, package installs/removals, policy toggles, and desktop-session state remain portal-owned mutable context rather than requester-visible authority.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` request ordering remains at `svc:portal.uri`; shell-visible launch order, default-handler memory, and chooser state keep their existing serialization story.
   - Phase 1 adds **no new ACP kind** and **no new conflict-key family** for support checks because the portable seam deliberately exports none.

6) **Sealed compat remains killable and non-ambient.**
   - Foreign Cell / compat runtimes do not regain `can-open?` probing through ambient host helpers, package-manager APIs, URL-scheme registries, or desktop-service calls.
   - If compat wants link launching, it still goes through `portal.uri.*` or fails closed.

## Phase 1 non-goals (explicitly deferred)

- No portable `SchemeSupported` / `canOpenURL` / `queryIntentActivities` style requester API.
- No app-visible list of supported schemes, handlers, packages, or defaults.
- No transcript-visible support-check receipt or cache artifact.
- No ACP/admin/query surface for OpenURI preflight probing.
- No helper fallback path that bypasses the mediated `open_uri` request.

## Why this is worth pinning

The ecosystem keeps rediscovering that “can something open this link?” is not harmless trivia. Apple moved `canOpenURL:` behind declared schemes and explicitly framed installed-app discovery as privacy-sensitive, while Android 11+ filters package visibility by default because the installed-app graph is sensitive user data. Current xdg-desktop-portal docs also expose a `SchemeSupported` method on OpenURI.

That combination makes the design temptation obvious: once an OpenURI layer exists, exact support probing quickly looks like a harmless convenience API. Pinning the boundary now keeps SlopOS from quietly inheriting a handler-inventory side channel or a future-success oracle under the same mediated-launch seam.

## Profile effect (A–D)

- **Secure workstation (A):** link opening stays convenient without turning launcher state into an app-visible installed-app fingerprinting surface.
- **Cloud micro-VM substrate (B):** guest/tenant tooling can request mediated launch where allowed, but exact host desktop/package support never becomes portable guest-visible authority.
- **Embedded / separation appliance (C):** deployments that do not even ship rich URI handlers avoid carrying a fake support-query API just because some desktops expose one.
- **Agent/automation OS (D):** LLM/tooling cannot branch on a hidden “which handlers are installed?” oracle; they must propose the actual mediated action and receive an explicit outcome.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/openuri-handler-selection-boundary-v0.md`
  - `docs/30-architecture/plumb-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_scheme_support_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no requester-visible support-oracle / shell-local-only exact knowledge / no new ACP-or-conflict-key surface** posture, or drops its primary REF wiring (**EVID-2026-570**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-PACKAGE-VISIBILITY.
- REF-APPLE-CANOPENURL.
- REF-APPLE-LSAPPLICATIONQUERIESSCHEMES.
