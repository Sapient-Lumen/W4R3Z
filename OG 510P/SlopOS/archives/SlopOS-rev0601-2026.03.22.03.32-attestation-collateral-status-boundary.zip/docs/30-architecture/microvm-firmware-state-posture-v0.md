# MicroVM firmware-state posture v0 (UEFI variable store and boot policy stay non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible firmware state under `ext.microvm` so UEFI variable storage, boot-option NVRAM, and Secure Boot key-enrollment folklore do not quietly become portable reviewed meaning.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-ATTEST** and makes one hard decision explicit:
**guest-visible firmware state such as UEFI variable storage, boot-option NVRAM, and Secure Boot key databases remains implementation-local rather than portable `ext.microvm` contract meaning.**

Entropy cost justification: the archive already pins firmware *description* as non-portable, but modern firmware stacks also expose a second, stateful seam: variable storage that can persist boot policy, one-shot boot overrides, key databases, and mode bits across resets. That is a materially different decision surface from “what tables describe the machine,” and it is exactly where guest-visible firmware state can quietly turn into a portable lifecycle/admin/provenance plane. One narrow posture closes that gap without inventing a firmware broker, variable-service API, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible firmware-state contract**
   - **Phase 1 exposes no portable ambient guest-visible firmware-state contract.**
   - There is no portable reviewed guarantee for one guest-visible UEFI variable-store / NVRAM / `efivarfs` plane under `ext.microvm`.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those variables, names, and persistence properties do **not** become SlopOS portable API meaning.

2) **No portable boot-option-maintenance plane**
   - There is **no portable `Boot####` / `BootOrder` / `BootNext` / `BootCurrent` / `DriverOrder` plane** under Phase 1.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one writable firmware boot-order database, one one-shot next-boot override path, or one stable firmware-managed boot-option inventory.”
   - Owners/runtimes may locally support firmware boot variables, direct kernel boot, or no boot-option store at all, but those choices remain implementation-local and must not silently become portable lifecycle or deployment semantics.

3) **No portable Secure Boot key-enrollment or signature-database plane**
   - There is **no portable PK / KEK / db / dbx / SetupMode / AuditMode / DeployedMode variable plane** under Phase 1.
   - Portable reviewed meaning does **not** include one guest-visible key-enrollment workflow, one firmware-signature-database update contract, or one standard secure-boot mode-transition story under `ext.microvm`.
   - Attestation/provenance meaning still rides on explicit `D-ATTEST` evidence and deployment receipts rather than ambient guest reads of firmware-mode bits or key databases.

4) **Owner-local firmware-state storage and protection remain implementation-local**
   - owner-local firmware-state storage and protection remain implementation-local.
   - A runtime may back variables with pflash, a host-managed variable service, a JSON-backed helper, or no guest-visible variable store at all for one deployment class, but that does **not** create a portable reviewed promise about one storage format, one write path, one reset-to-apply rule, or one host/firmware privilege split.
   - In particular, local choices about SMM-backed protection, host-side variable-service emulation, persistence across resets, and variable-capacity limits remain implementation-local rather than portable `ext.microvm` semantics.

5) **Changing the firmware-state stance is owner-local lifecycle or new admission, not a portable live admin plane**
   - Changing the firmware-state stance is owner-local lifecycle or new admission, not a portable live admin plane.
   - If policy cares about a different firmware-state posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `SetVariable()` / boot-order / key-enrollment control plane by convention.
   - This keeps lifecycle and provenance meaning on the already-pinned activation/attestation seams rather than on firmware-variable folklore.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed firmware-state action such as `set_boot_next`, `rewrite_boot_order`, or `enroll_secure_boot_keys` must say whether it commutes with activation, reboot, attestation export, and deployment rollback, and where serialization lives.
   - Until then, firmware state remains owner-local runtime/firmware policy rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable UEFI variable-store / `efivarfs` contract under `ext.microvm`.
- No portable firmware boot-option inventory or writable `BootOrder` / `BootNext` plane.
- No portable Secure Boot key-database enrollment/update API.
- No portable guest-triggerable `SetVariable()` lifecycle/admin plane.
- No claim that firmware-mode bits or key databases are portable attestation truth.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-ATTEST)
- Adjacent postures:
  - `microvm-profile-posture-v0.md`
  - `microvm-firmware-description-posture-v0.md`
  - `microvm-platform-identity-posture-v0.md`
  - `attestation-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-33)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-FWSTATE)
- Policy posture:
  - guest-visible firmware state adds **no new lane**, **no portable lifecycle/admin plane**, and **no portable provenance-by-firmware-variable contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_firmware_state_posture.py` fails `make lint` if this posture stops being discoverable, loses the **non-portable firmware-state / no portable boot-order plane / no portable Secure-Boot-key-enrollment plane / owner-local storage-protection remain implementation-local / no `SetVariable()` admin contract** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-UEFI-VARS.
- REF-UEFI-BOOT-MANAGER.
- REF-UEFI-RUNTIME-VARS.
- REF-UEFI-SECURE-BOOT.
