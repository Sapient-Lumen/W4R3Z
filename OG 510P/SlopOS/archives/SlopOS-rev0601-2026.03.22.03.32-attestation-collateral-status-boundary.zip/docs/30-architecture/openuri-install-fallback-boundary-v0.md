# D-PLUMB OpenURI install-fallback boundary v0 (no portable browser/store/install fallback seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable browser-fallback, app-store redirect, inline-install, instant-app, or install-if-missing workflow on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable fallback / install seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `fallback_url`, `browser_fallback_url`, `install_if_missing`, `store_url`, `market_url`, `app_store_id`, `inline_install`, `instant_app`, or equivalent browser/store/install fallback field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Resolution failure stays request-local rather than triggering a second workflow.**
   - Missing-handler, denied-scheme, blocked-policy, or failed-admission cases stay on the normal request-local outcome path.
   - Phase 1 does **not** reinterpret generic launch failure as permission to open a browser fallback page, jump to an app-market listing, attempt inline installation, or retry with a more permissive secondary route.
   - A launch request therefore either admits on the current seam or fails closed on the current seam; it does not silently become software-acquisition authority.

3) **Store / install / promotion workflows stay on explicit future seams, not generic launch.**
   - If a product shape later needs reviewed software discovery, app-market redirection, optional install prompts, or explicit “open web fallback when native app missing” behavior, that belongs on a future RFC-first software-acquisition / admin seam rather than as a side effect of generic launch.
   - Generic OpenURI therefore stays a mediated launch workflow, not a portable app-promotion, app-store, or install-broker envelope for the chosen handler.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. Chrome Android intent URLs explicitly support a browser fallback URL when the requested app is missing and allow package-targeted launch hints; Google Play exposes explicit listing / inline-install flows; Apple universal links fall back to the website in Safari when the app is not installed.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate additional routing, promotion, or software-acquisition authority that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new software-acquisition action family, conflict-key family, or serialization surface.
   - Any future browser-fallback / install / app-market seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from launcher UX.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this in a browser fallback”, “send user to the store”, or “install if missing” behavior through helper fallbacks.
   - If compat needs reviewed acquisition or fallback flows, it still pays for an explicit future seam rather than smuggling software-discovery/promotion through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `fallback_url`, `browser_fallback_url`, `install_if_missing`, `store_url`, `market_url`, `app_store_id`, `inline_install`, or `instant_app` knob on generic OpenURI.
- No browser or shell fallback that quietly turns a missing native handler into website launch success.
- No portable app-store redirect, inline-install, or app-promotion contract on generic URI launch.
- No host-helper fallback that quietly retries generic launch through a browser/store/install path and reports that second workflow as OpenURI truth.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, and non-materializing, but another tempting convenience import still lingers in mainstream ecosystems: “if the native app is missing, can we fall back to the website, the store listing, or an inline install?” That sounds pragmatic, but it quietly turns a launch seam into a software-discovery / acquisition / promotion broker, which is much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into app-market or browser-fallback authority. That matters for all four product shapes: workstation UX can still launch links without standardizing app-promotion rules; hosted and embedded profiles avoid carrying fake store/install machinery they do not want; and agent tooling cannot mistake `open_uri` failure for permission to start software acquisition.

## Profile effect (A–D)

- **Secure workstation (A):** desktop shells may still choose local UX for missing handlers, but generic OpenURI does not standardize browser/store/install fallback as app-visible substrate truth.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting browser/store/install broker behavior from desktop launcher folklore.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising app-store, browser-fallback, or install semantics they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “if unavailable, acquire software or reroute through the web”; reviewed software-acquisition stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_install_fallback_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable fallback / install seam / resolution failure stays request-local / store-install-promotion stays on explicit future seams / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-583**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-CHROME-ANDROID-INTENTS.
- REF-GOOGLE-PLAY-LINKING.
- REF-GOOGLE-PLAY-INLINE-INSTALL.
- REF-APPLE-UNIVERSAL-LINKS.
