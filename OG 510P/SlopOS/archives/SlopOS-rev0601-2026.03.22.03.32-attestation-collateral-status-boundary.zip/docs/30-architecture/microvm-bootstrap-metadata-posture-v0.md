# MicroVM bootstrap-metadata posture v0 (no ambient guest metadata/bootstrap channel)

Purpose: pin the **Phase 1** meaning of guest-visible bootstrap/config injection under `ext.microvm` so metadata endpoints, firmware-config sidebands, and config-drive/cloud-init conveniences do not quietly become an ambient host↔guest authority plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-NETLEASE** and makes one hard decision explicit:
**Phase 1 exposes no ambient guest-readable metadata/bootstrap channel under `ext.microvm`; there is no portable MMDS / IMDS / metadata-endpoint plane, no fw_cfg key/value bootstrap namespace, no config-drive / cloud-init datasource contract, and bootstrap authority/configuration must ride on reviewed boot artifacts or explicit post-boot seams rather than a hidden host control plane.**

Entropy cost justification: the archive already forbids ambient host channels, fixes guest-visible CPU/RAM/NIC/block/console shape at admission, keeps network authority on explicit `portal.net` / `CH-NETLEASE` seams, and keeps secrets/attestation on explicit post-boot seams. What remains underspecified is the tempting “first boot convenience” layer: metadata endpoints, firmware blobs, and config disks that look operationally cheap but silently recreate an ambient provisioning/control surface. One narrow posture closes that gap without inventing a new schema family, metadata API, or guest agent.

## Posture (v0)

1) **No ambient guest-readable metadata/bootstrap channel**
   - For Phase 1, `ext.microvm` exposes no ambient guest-readable metadata/bootstrap channel.
   - No portable MMDS / IMDS / metadata-endpoint plane exists under the reviewed contract: no link-local guest fetch path for instance metadata, host-supplied identity blobs, cloud credentials, user-data, or mutable bootstrap policy just because the guest is virtualized.
   - In plain terms: the reviewed contract is not “boot the leaf and ask the host metadata service who you are / what to do next.”

2) **No portable fw_cfg / config-drive / cloud-init datasource contract**
   - No portable fw_cfg / config-drive / cloud-init datasource contract exists under `ext.microvm` in Phase 1.
   - That means no reviewed portable semantics for **firmware key/value blobs**, **config-drive volume labels/layouts**, **NoCloud / ConfigDrive-style `user-data` / `meta-data` / `vendor-data` / `network-config` meaning**, or “this guest may always discover bootstrap config from a magic attached disk / firmware namespace”.
   - Implementations may internally use image-building or launch-time tooling, but those mechanisms are **not** part of the guest-visible reviewed product surface and must not silently become portable API meaning.

3) **Bootstrap authority arrives via reviewed boot artifacts or explicit post-boot seams**
   - Bootstrap authority arrives via reviewed boot artifacts or explicit post-boot seams.
   - Boot selectors, boot manifests, sealed images, declared kernel/initrd/cmdline choices, and other already-reviewed boot artifacts remain the place where pre-execution configuration lives.
   - Secrets, cloud/service identity, and freshness-bound policy or release decisions are obtained after boot through explicit existing seams such as attestation, vault/app-secret, activation, or network-lease workflows — not through a hidden metadata side channel.

4) **Changing bootstrap data is a new admission, not a live metadata update plane**
   - Changing bootstrap data is a new admission, not a live metadata update plane.
   - Owners/runtimes may still build different images, initrds, kernel arguments, or deployment-specific boot artifacts locally, but they may **not** reinterpret a running leaf as carrying a portable mutable metadata store under the same admitted identity.
   - If policy wants different bootstrap data, the correct Phase 1 action is to admit a different reviewed leaf/activation or use an explicit post-boot seam — not to patch a hidden metadata/config channel by convention.

5) **No new metadata/bootstrap control plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest metadata/bootstrap retrieval, **no new ACP kind**, and **no new conflict-key family** for live metadata mutation under `ext.microvm`.
   - If a later design wants portable guest-visible metadata retrieval, config-drive import, or bootstrap-token refresh, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity stance, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable MMDS / IMDS / link-local metadata endpoint semantics for `ext.microvm`.
- No portable fw_cfg key namespace or config-drive/cloud-init datasource contract.
- No ambient cloud credentials, SSH key seeding, user-data, or network configuration channel just because a guest is booting in a microVM.
- No promise that owner-local image composition or launch tooling is forbidden; only that it does **not** become a reviewed guest-visible metadata API in Phase 1.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-NETLEASE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `host-guest-channel-posture-v0.md`
  - `microvm-guest-agent-posture-v0.md`
  - `microvm-semihosting-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `attestation-posture-v0.md`
  - `vault-posture-v0.md`
  - `app-secret-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-18)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-BOOTSTRAPMETADATA)
- Policy posture:
  - guest-visible bootstrap/metadata adds **no new lane**, **no hidden credentials-or-user-data plane**, and **no portable live metadata mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_bootstrap_metadata_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no ambient guest-readable metadata/bootstrap channel / no portable MMDS-IMDS-or-fw_cfg-or-config-drive-cloud-init contract / bootstrap via reviewed boot artifacts or explicit post-boot seams / changing bootstrap data means new admission not live metadata plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-MMDS.
- REF-FIRECRACKER-MMDS-API.
- REF-QEMU-FWCFG.
- REF-CLOUDINIT-NOCLOUD.
- REF-CLOUDINIT-CONFIGDRIVE.
