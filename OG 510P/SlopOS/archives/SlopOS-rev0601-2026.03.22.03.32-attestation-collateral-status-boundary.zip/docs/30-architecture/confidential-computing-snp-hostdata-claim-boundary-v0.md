# D-CC SNP host-data claim boundary v0 (HOST_DATA is exact evidence only; not portable attestation meaning)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `HOST_DATA`** so a host/provider-supplied report field does not quietly become a portable SlopOS attestation claim, policy selector, or hidden control channel.

Entropy cost justification: the archive already pins (1) one exact D-CC binder contract for guest-supplied `REPORT_DATA`, (2) one SNP-first certificate-source rule, and (3) one provider target for first implementation. What remained ambiguous was narrower and worth deciding now: **SNP attestation reports also carry `HOST_DATA`, which the hypervisor supplies at launch and firmware includes in reports, but the archive had not yet said whether that field means anything portable to SlopOS itself**. One small boundary closes that gap without inventing a new schema, claim family, or provider-identity subsystem.

## Posture (v0)

1) **`HOST_DATA` is provider/host-supplied evidence, not a portable SlopOS attestation claim.**
   - AMD’s SNP firmware ABI defines `HOST_DATA` as **opaque host-supplied data to describe the guest** and says the firmware does **not** interpret it.
   - The firmware also stores that value in guest context and includes it in attestation reports for the guest.
   - Phase 1 therefore treats `HOST_DATA` as **exact provider-native evidence bytes only**. It does **not** become a native `CH-ATTEST` field, a portable claim about tenant/account/instance identity, or a portable proof that one deployment label is in force.

2) **`REPORT_DATA` and `HOST_DATA` are distinct and non-substitutable.**
   - The already-pinned D-CC binder contract uses exact `cc_report_data_v0` in the provider-native `REPORT_DATA` / `REPORTDATA` carrier.
   - `HOST_DATA` MUST NOT be used as a substitute freshness binder, boot/provenance binder, policy revision channel, or verifier challenge field.
   - A verifier that accepts SNP evidence MUST therefore check the exact `REPORT_DATA` binding separately and MUST NOT treat matching or non-empty `HOST_DATA` as satisfying `PO-ATTEST-VERIFY` / `PO-ATTEST-FRESH`.

3) **Any interpretation of `HOST_DATA` remains explicit verifier-local policy.**
   - A deployment-specific verifier MAY inspect exact `HOST_DATA` bytes as supporting evidence for local/provider-specific appraisal (for example, a locally reviewed launch class or owner-local admission tag).
   - That interpretation remains **explicit local policy** under D-POLICY rather than a portable SlopOS rule.
   - Different providers/deployments may therefore ignore, preserve, or appraise `HOST_DATA` differently without changing the portable D-ATTEST seam.

4) **Packaging/export does not upgrade `HOST_DATA` into normalized claim space.**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `HOST_DATA`.
   - If tooling wants to preserve extracted `HOST_DATA` or related launch metadata for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable host-identity schema.
   - Exporting a report that contains `HOST_DATA` does not imply that remote consumers may treat those bytes as reviewed SlopOS-native meaning.

5) **Phase 1 secret release and automation policies must name any `HOST_DATA` use explicitly.**
   - If a secret-release verifier, rollout gate, or automation harness wants to require some exact `HOST_DATA` value, that requirement MUST live in explicit verifier-local policy and remain visible in reviewed evidence/config.
   - No default D-CC path, agent workflow, or automation portal may silently inherit `HOST_DATA` as a portable allow/deny signal.
   - This keeps product shape D honest: an agent may inspect exact evidence, but it does not get a hidden provider-authored approval bit through the core attestation seam.

6) **No new workflow / ACP / conflict-key family appears in v0.**
   - This boundary only narrows the meaning of one already-existing provider-native SNP report field.
   - It introduces no new workflow kind, no serialization surface, and no provider-side setter/query plane.

## Phase 1 non-goals (explicitly deferred)

- No `host_data` field in `CH-ATTEST v0`.
- No portable tenant/account/project/instance identity claim derived from SNP `HOST_DATA`.
- No host-data-specific policy language, fetch plane, or query interface in IF-ATTEST.
- No new workflow / ACP / conflict-key family for provider launch tags in v0.

## Why this boundary exists

The reportdata-binding decision fixed the guest-controlled binder bytes, but AMD’s ABI still leaves another tempting seam:
- `REPORT_DATA` is the guest/request binder field.
- `HOST_DATA` is host-supplied opaque data that firmware includes in reports.

Without one explicit rule, the first SNP verifier or secret-release harness would predictably start doing one of these by convention:
- treating `HOST_DATA` as a second portable identity channel,
- using it as a provider-authored allow/deny bit,
- or letting agents rely on cloud/provider folklore about what those bytes “mean.”

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on CH-ATTEST + exact `REPORT_DATA` binding**,
- **provider launch labels remain exact evidence unless local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a host-identity schema**,
- and **automation cannot inherit a hidden provider policy channel**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation verification can ignore `HOST_DATA` entirely or preserve it as opaque evidence without turning hosted/provider conventions into portable workstation claims.
- **Cloud micro-VM substrate (B):** hosted SNP verifiers may still use provider-local launch metadata, but only under explicit local policy rather than by widening D-ATTEST into a cloud-instance identity channel.
- **Embedded / separation-kernel-ish appliance (C):** appliance profiles keep their attestation seam small; if imported SNP evidence contains `HOST_DATA`, offline review can preserve it without admitting a provider-label schema into the appliance core.
- **Agent / automation OS (D):** agents can inspect exact report bytes, but they do not get a silent provider-authored approval path; any `HOST_DATA` interpretation must remain transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on provider-controlled SNP report-field meaning.

If a second closely related D-CC provider-report-field boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_hostdata_claim_boundary.py` (**EVID-2026-537**).

## References

- REF-AMD-SNP-FWABI.
- REF-AWS-SNP-ATTEST.
- REF-RATS-RFC9334.
