# MicroVM memory-backing posture v0 (host-side guest-RAM backing stays non-portable)

Purpose: pin the **Phase 1** meaning of host-side guest-RAM backing under `ext.microvm` so huge pages, THP, memfd/file/shm backing, shared mappings, and prefault/prealloc folklore do not quietly become an ambient performance / sharing / snapshot plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host-side guest-RAM backing contract under `ext.microvm`; there is no portable anonymous-vs-file-vs-memfd-vs-shm backing plane, no portable hugepages / THP / prefault / prealloc / shared-mapping plane, owner-local backing-file path / memfd sealing / page-size / mapping-sharing choice stays implementation-local, and reviewed memory / snapshot / backend-offload / performance meaning still rides on explicit topology / snapshot / offload seams rather than ambient host memory-backing modes.**

Entropy cost justification: the archive already fixes guest-visible RAM topology at admission, keeps guest-visible persistent memory out of scope, refuses ambient host↔guest channels, and pins backend-offload plus host-side page dedup as owner-local choices. What remained loose was the host RAM backing layer where real VMMs expose memory-backend-file/memfd/shm objects, huge pages, shared mappings, file-backed memory zones, and prefault/prealloc knobs. One narrow posture closes that gap without inventing a memory-backing API, a live tuning workflow, or a new schema family.

## Posture (v0)

1) **No portable ambient host-side guest-RAM backing contract**
   - **Phase 1 exposes no portable ambient host-side guest-RAM backing contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable host RAM backing vocabulary, one stable page-size/allocation policy, or one portable memory-backing ABI across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable story exists for how the host allocates, shares, seals, or prefaults the RAM behind it.”

2) **No portable anonymous-vs-file-vs-memfd-vs-shm backing plane**
   - There is **no portable anonymous-vs-file-vs-memfd-vs-shm backing plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable host-backing-object kind, one stable backing-file path or directory contract, one stable memfd-vs-shm-vs-anonymous selection rule, one stable memfd sealing requirement, or one stable “this leaf's RAM is shareable with helper processes by construction” promise.
   - Implementations may locally choose anonymous memory, file-backed zones, memfd-backed regions, POSIX shared memory, or equivalent mechanisms, but those choices do **not** become SlopOS portable interface meaning.

3) **No portable hugepages / THP / prefault / prealloc / shared-mapping plane**
   - There is **no portable hugepages / THP / prefault / prealloc / shared-mapping plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable huge-page requirement, one stable huge-page-size vocabulary, one stable transparent-huge-page policy, one stable prefault/preallocate contract, one stable `MAP_SHARED` / `MAP_PRIVATE` promise, or one stable boot-time page-fault suppression workflow.
   - Owner-local choices such as hugetlbfs backing, THP advice, prefault/prealloc, or shared mappings may exist for one runtime or host class, but they do **not** become a reviewed API for the admitted leaf.

4) **No portable backing-file-path / memfd-seal / snapshot-elision / external-share contract**
   - There is **no portable backing-file-path / memfd-seal / snapshot-elision / external-share contract** under Phase 1.
   - Portable reviewed meaning does **not** include one stable rule that guest RAM is backed by a well-known file, one stable promise that snapshots may omit RAM bytes because the backing file is already available, one stable memfd sealing behavior, or one stable external-helper sharing contract for device-model sidecars.
   - If an implementation locally uses file-backed memory zones, memfd sealing, or shared mappings for helper daemons, that remains owner-local mechanism rather than portable `ext.microvm` semantics.

5) **Owner-local backing-file / page-size / mapping-sharing / sealing choice stays implementation-local**
   - **Owner-local backing-file / page-size / mapping-sharing / sealing choice stays implementation-local**.
   - Owners/runtimes may locally choose anonymous memory, huge pages, memfd, POSIX shared memory, file-backed memory zones, prefault/prealloc, sealing, or helper-process sharing, but those choices do **not** create a portable reviewed promise about one host RAM backing mode, one page-size policy, one boot-latency story, or one helper-sharing ABI.
   - In particular, backing paths, memfd names, seal bits, mapping flags, page-size selection, and eager-fault/allocation policy remain runtime-local mechanism rather than portable SlopOS semantics.

6) **Changing the backing stance is owner-local deployment policy or new admission, not a portable live control plane**
   - Changing the backing stance is owner-local deployment policy or new admission, not a portable live control plane.
   - If policy cares whether a leaf runs with huge pages disabled, with shared mappings forbidden, or with file-backed memory zones disallowed for one reviewed class, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `set_guest_ram_backing`, `toggle_hugepages`, `rebind_memory_file`, or `query_memfd_seal` plane by convention.
   - This keeps reviewed memory / snapshot / backend-offload / performance meaning on explicit topology, snapshot, and offload seams rather than on ambient host backing folklore.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_guest_ram_backing`, `toggle_hugepages`, `toggle_thp`, `set_prefault`, `set_memory_zone_file`, or `query_memory_backing_mode` must say whether it commutes with activation, snapshot/restore, backend-offload policy, memory-topology policy, and locality/performance policy, and where serialization lives.
   - Until then, host-side guest-RAM backing remains owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable anonymous-vs-file-vs-memfd-vs-shm host RAM backing contract under `ext.microvm`.
- No portable hugepages / THP / prefault / prealloc / shared-mapping contract.
- No portable backing-file-path / memfd-seal / snapshot-elision / helper-sharing ABI for guest RAM.
- No portable “same leaf, different host RAM backing mode now” lifecycle/admin plane.
- No claim that host-side RAM backing choices are an acceptable portable substitute for explicit topology / snapshot / backend-offload review.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-persistent-memory-posture-v0.md`
  - `microvm-memory-dedup-posture-v0.md`
  - `microvm-backend-offload-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-50)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-MEMBACK)
- Policy posture:
  - host-side guest-RAM backing adds **no new lane**, **no portable memory-backing/status plane**, and **no portable live tuning contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_memory_backing_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable host-side guest-RAM backing contract / no portable anonymous-file-memfd-shm backing plane / no portable hugepages-THP-prefault-prealloc-shared-mapping plane / owner-local backing-file-page-size-mapping-sharing-sealing choice remains implementation-local / explicit topology-snapshot-offload seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-MEMBACKEND.
- REF-CHYP-MEMORY-ZONES.
- REF-FIRECRACKER-HUGEPAGES.
