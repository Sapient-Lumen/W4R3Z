# D-PRESSURE posture v0 (scoped coarse signals; no ambient PSI/procfs/service-protocol seam)

Purpose: pin an implementable **Phase 1** meaning for **D-PRESSURE** so resource-pressure observation helps load shedding and cache trimming without quietly becoming a global oracle, a writable threshold-registration API, or a path/env/socket convention that reintroduces ambient channels.
It narrows RFC-0057 into one compact posture adjacent to **IF-OBS**, **CH-PRESSURE v0**, **D-METER**, **D-JOBS**, and the sealed-compat rules so runtimes, validators, and operators can reason about one default shape.

## Posture (v0)

1) **Observation-only IF-OBS seam; no authority rides on pressure**
   - If **D-PRESSURE** is enabled, portable pressure meaning appears only as observational **CH-PRESSURE v0** output on explicit **IF-OBS** authority.
   - Pressure signals remain non-authoritative under **I-PRESSURE-1**: they cannot authorize privileged effects, widen leases, or substitute for an admission/approval result.
   - In plain terms: “the system is under pressure” may explain why a component sheds work, but it is not itself permission to mutate privileged state.

2) **Explicit scope only; no ambient global pressure oracle**
   - Portable observation scope is limited to an explicitly authorized meter subtree or explicit resource container/job scope, per **I-PRESSURE-2** and **PO-PRESSURE-SCOPE**.
   - Phase 1 deliberately declines an ambient global `/proc/pressure/*`-style or host-wide “show me current pressure” oracle for arbitrary components.
   - Any broader visibility remains owner/operator-local policy behind existing observation authority, not default application meaning.

3) **Coarse level-first contract; no portable exact PSI totals/averages vocabulary**
   - The portable contract is the bounded **CH-PRESSURE v0** event shape: resource class, explicit scope, coarse `ok|some|full` level, bounded `window_ms`, and optional coarse stall percentages.
   - Phase 1 does **not** standardize one exact exported set of PSI `avg10/avg60/avg300/total` counters, one stable cumulative-stall file format, or one exact threshold-calculus vocabulary as portable reviewed meaning.
   - This keeps D-PRESSURE useful for adaptation while refusing to turn one kernel’s accounting layout into a cross-profile timing oracle.

4) **No portable `/proc` / cgroup file / env-var / AF_UNIX pressure-watch protocol**
   - Phase 1 exposes **no portable `/proc/pressure/*` / `memory.pressure` path contract**, no portable `$MEMORY_PRESSURE_WATCH` / `$MEMORY_PRESSURE_WRITE` environment protocol, and no portable FIFO / `AF_UNIX` pressure-watch socket protocol.
   - Pressure delivery is therefore **not** modeled as “discover a magic path, open it, maybe write threshold bytes into it, then poll it.”
   - This keeps sealed compat honest: pressure observation does not smuggle ambient filesystem/env/socket channels back into native or compat execution.

5) **No portable trigger-registration / writable threshold / `poll()`-able FD plane**
   - Phase 1 standardizes **no portable client-writable pressure-trigger plane** such as “write `<some|full> <stall> <window>` to a kernel file, get a `poll()`-able FD, and treat that as the canonical API.”
   - Portable reviewed meaning therefore includes no threshold-registration string format, no one-trigger-per-FD rule, no eventfd/epoll contract, and no client-selected sampling cadence.
   - If a runtime imports Linux PSI or similar machinery locally, that remains implementation-local beneath **CH-PRESSURE v0** and **PO-PRESSURE-RATELIMIT** rather than a new portable app contract.

6) **Edge-triggered, coalesced, rate-limited delivery; clients keep local state if needed**
   - Pressure delivery remains bounded/coarse per **I-PRESSURE-3** and **PO-PRESSURE-RATELIMIT**: providers may coalesce oscillations, skip intermediate transitions, and repeat severe levels when continued action is required.
   - Portable consumers must therefore tolerate edge-triggered/coalesced delivery and keep whatever local state they need; they must not assume a lossless replay log of every micro-transition.
   - This imports the useful ergonomic lesson from Fuchsia-style memory-pressure watchers without standardizing a richer mailbox or replay surface.

7) **No replay debt, no scheduler promise, no automatic remedial action plane**
   - Phase 1 pressure events are hints about current scoped contention, not debt that must later be replayed one-for-one.
   - D-PRESSURE adds no portable promise about exact sampling interval, scheduler reaction time, OOM policy, reclaim strategy, or automatic cache-trim / kill / migration behavior.
   - Any such reactions remain component-local or owner-local policy layered above the observational seam.

8) **No new workflow / ACP / conflict-key family in v0**
   - Phase 1 introduces no portal.pressure.* family, no **CH-ACP** kind for pressure registration, and no dedicated conflict-key family for pressure observation.
   - Ordinary observation export remains read-only and commutative with itself in the D-COMMUTE sense because it does not mutate the reviewed system state; no new serialization boundary is introduced here.
   - If a future design wants mutable pressure-watch registration, threshold policy objects, or kill/trim actions attached to pressure, it must pay an RFC-first entropy cost and say which actions commute, which do not, where serialization lives, and how that is evidenced/tested.

9) **Sealed compat remains killable and non-ambient**
   - Foreign Cells may adapt guest/host-native pressure facilities only through explicit, policy-killable observation membranes.
   - They must not recreate ambient path/env/global-socket pressure discovery for native components, and disabling observation export via `cfg.params.lane.obs.export=false` must fail closed for any compat adapter that depends on IF-OBS.
   - This keeps “juicy” ecosystem imports usable without letting their ambient transport conventions become part of the SlopOS authority substrate.

## Phase 1 non-goals (explicitly deferred)

- A portable global load/pressure oracle for arbitrary components.
- A portable PSI trigger-registration string format or writable procfs/cgroup file contract.
- A portable env-var / filesystem-path / FIFO / `AF_UNIX` memory-pressure service protocol.
- A workflow / ACP / admin surface for registering, listing, cancelling, or replaying pressure watches.
- Automatic policy actions (kill, reclaim, migrate, resize, or suspend work) encoded into the pressure seam itself.

## Wiring

- Decision surface:
  - `decision-map.md` (D-PRESSURE)
- Primary schema / interface surfaces:
  - `pressure-signal-schema-v0.md`
  - `schema-registry.md` (CH-PRESSURE v0)
  - `interface-registry.md` (IF-OBS)
  - `observation-export-posture-v0.md`
- Adjacent control/runtime surfaces:
  - `rfcs/0057-pressure-signals-and-backpressure.md`
  - `job-portal-posture-v0.md`
  - `reqctx-posture-v0.md`
  - `caprpc-oneway-posture-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-PRESSURE-1**, **I-PRESSURE-2**, **I-PRESSURE-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-PRESSURE-VALIDATE**, **PO-PRESSURE-SCOPE**, **PO-PRESSURE-RATELIMIT**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-050**)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future mutable pressure-watch/control plane must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_pressure_posture.py` fails `make lint` if this posture stops being discoverable, loses the **scoped observation-only / no ambient procfs-cgroup-env-socket protocol / no portable trigger-registration plane / edge-triggered+coalesced delivery / no new workflow-ACP surface** posture, or drops its primary REF wiring.

## References

- REF-LINUX-PSI.
- REF-SYSTEMD-PRESSURE.
- REF-FUCHSIA-MEMORY-PRESSURE.
