# D-CC reference-target boundary v0 (SNP-first binder path)

Purpose: pin the **first concrete implementation target** for **D-CC** so Phase 1 code can start from one documented provider-native attestation path instead of stalling on a premature multi-provider abstraction.

This is a narrow hard decision about **what we code first**, not a claim that one vendor format becomes the portable product surface. The portable seam remains **D-ATTEST** with **CH-ATTEST v0** / **CH-ATTESTPACK v0**. This boundary only says which provider-native evidence path must carry the first end-to-end binder/verifier harness.

## Boundary (v0)

1) **AMD SEV-SNP is the first end-to-end D-CC implementation target**
   - Phase 1 reference implementation work for **D-CC** MUST start with an **AMD SEV-SNP** guest path under the cloud/microVM shape.
   - The binder requests a native SNP attestation report, binds the provider-native report input to the archive’s own boot/provenance state using the exact `cc_report_data_v0` contract pinned in `confidential-computing-reportdata-binding-boundary-v0.md`, and exports only the normalized **CH-ATTEST v0** / **CH-ATTESTPACK v0** seam.
   - The first E2 evidence target therefore proves one concrete report-generation + digest-binding + verifier-local appraisal path instead of an abstract “confidential VM” promise.

2) **TDX and CCA remain admitted future annexes, not co-equal Phase 1 blockers**
   - **Intel TDX** and **Arm CCA** remain valid future D-CC annexes, but Phase 1 does **not** require one generic multi-provider adapter, one common quote broker, or one provider-pluggable verifier stack before code begins.
   - New provider support must fit the already-pinned **D-ATTEST / D-CC** seams; it does not get to delay or widen the first binder/verifier target.
   - If a future provider needs materially different portable semantics, that must land as an explicit new seam rather than by weakening this boundary into “whatever any confidential-computing stack happens to export.”

3) **Verifier meaning stays local, digest-bound, and reviewable**
   - The Phase 1 reference verifier path checks the SNP signature chain / endorsements under explicit local policy, verifies the report-data binding against the exported **CH-ATTEST** nonce and `boot_digest`, and treats endorsement/reference material as verifier-local appraisal input only.
   - Phase 1 does **not** introduce a native “latest-good CC policy”, cloud-vendor attestation API, or provider-selected trust-root discovery plane alongside the verifier.

4) **No provider-native secret-release or quote-service plane becomes portable meaning**
   - Attestation-gated secret release still rides on the existing **D-APPSECRET / D-VAULT / D-CRYPTOSVC** seams plus relying-party policy.
   - Choosing SNP first does **not** create a new native secret broker, quote verification service contract, cloud metadata dependency, or provider-admin workflow in the SlopOS core surface.
   - Any helper tooling remains explicit, local, and policy-killable.

5) **The existing warm-state honesty boundaries still apply unchanged**
   - If the SNP-first target is combined with `ext.microvm` warm-start restore, the archive still requires fresh attestation exchange after generation change and still keeps resumed-leaf identity out of portable attestation meaning.
   - This boundary therefore does **not** reopen snapshot continuity folklore just because the first provider target is concrete.

6) **SNP-first does not widen the claim envelope**
   - This is a **coding-target** decision, not a blanket claim that confidential computing suddenly solves side channels, post-boot compromise, or host-trust questions.
   - `ext.confidential_computing.attest_only` remains the honest default reading for Phase 1 integration work; any stronger isolation claim still requires **A-CC-1**, explicit scope, and side-channel posture.

## Why this boundary exists

- **Cuts real implementation entropy now**: the archive already has D-CC, D-ATTEST, CH-ATTEST, CH-ATTESTPACK, and microVM attestation continuity boundaries. Without one provider target, coding risks stalling on an unnecessary provider-abstraction project.
- **Fits the B/D product shapes best**: cloud hosted compute and agent/automation deployments are the places where attestation-gated secret release and “what actually booted?” proofs matter earliest.
- **Chooses the path with the smallest first harness**: AMD documents a guest-requested SNP report path with a launch measurement and a simple endorsement-chain validation flow, and practical open tooling already exists around that path.
- **Keeps future imports honest**: Intel TDX and Arm CCA remain interesting, but they should arrive later as annexes to the already-pinned attestation seam rather than as reasons to postpone first code.

## Imported ecosystem pattern

- **AMD SEV-SNP** contributes the concrete Phase 1 binder target: a provider-native report with a launch measurement and user/report-data style binding field.
- **VirTEE `snpguest`** is the practical ecosystem hint: use a small explicit guest-side report tool path rather than inventing a SlopOS-specific provider protocol before the first verifier exists.
- **Intel TDX** is the contrast case for sequencing: it stays relevant, but Phase 1 declines to turn its quote-generation / verification ecosystem into the blocker for first D-CC code.

## Consequences

- The first D-CC E2 prototype / harness / evidence pack should target **AMD SEV-SNP**.
- The portable SlopOS surface stays provider-neutral at the **CH-ATTEST / CH-ATTESTPACK** layer even while implementation sequencing is provider-specific.
- Future TDX/CCA support remains welcome, but the burden of proof flips: they must fit the pinned seam rather than forcing the seam to become a provider-abstraction project.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** for confidential-computing provider-target sequencing.

If a second closely related D-CC provider-selection / annex-boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces: `decision-map.md` (**D-CC**, **D-ATTEST**, **D-MICROVM**).
- Deployment/profile knobs: `docs/10-threat-model/deployment-profiles.md`, `config-toggle-registry.md`, `profile-feature-flag-defaults.md`.
- Attestation seam: `attestation-posture-v0.md`, `attestation-token-schema-v0.md`, `attestation-pack-schema-v0.md`, `attestation-endorsement-boundary-v0.md`, `confidential-computing-reportdata-binding-boundary-v0.md`.
- Warm-state honesty companions: `microvm-attestation-reacquire-posture-v0.md`, `microvm-attestation-scope-posture-v0.md`, `microvm-resume-admission-evidence-posture-v0.md`.
- Mechanism / proposal notes: `rfcs/0064-confidential-computing-profile.md`.
- Assurance hooks: `docs/10-threat-model/assumption-registry.md` (**A-CC-1**, **A-ATTEST-2**), `docs/20-assurance/invariant-registry.md` (**I-ATTEST-1**, **I-MICROVM-4**, **I-MICROVM-9**), `docs/20-assurance/proof-obligation-registry.md` (**PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-MICROVM-ATTEST-REACQUIRE**, **PO-MICROVM-ATTEST-SCOPE**).
- CI drift gate: `tools/check_confidential_computing_reference_target_boundary.py` (**EVID-2026-534**).

## References

- REF-AMD-SNP-FWABI.
- REF-AWS-SNP-ATTEST.
- REF-SNPGUEST.
- REF-RATS-RFC9334.
- REF-LINUX-TDX.
- REF-INTEL-TDX-QUOTEEXT.
