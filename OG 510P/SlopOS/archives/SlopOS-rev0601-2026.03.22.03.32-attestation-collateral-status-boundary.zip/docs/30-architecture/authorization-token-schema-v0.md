# CH-AUTHZ v0: Authorization token envelope (schema)

Purpose: represent an approval/authorization that is **bound** to a specific action digest and schema version, so that “approval reuse” and “approval substitution” fail closed.

Posture note: D-POWERBOX v0 is pinned in `powerbox-posture-v0.md`: CH-AUTHZ stays **action-bound approval evidence**, not a generic remembered-grant library, inventory ticket, or ambient-name result.

This schema is intentionally small: it is an *envelope* that can carry a signature, a hardware-backed attestation, or a quorum of signatures.

References: REF-CT-RFC6962, REF-TUF-SPEC.

## Encoding
Candidate baseline: canonical CBOR (D-ENC), with COSE (or equivalent) for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-AUTHZ v0 := {
  v: 0,

  ; what this authorizes
  action_schema: tstr,        ; e.g. "CH-ACP v0" | "CH-KABI v0"
  action_digest: bstr,        ; digest of canonical bytes of the action value

  ; validity window
  exp?: uint,                 ; optional expiry (profile-gated; uses monotonic time when enforced)
  not_before?: uint,          ; optional start time (profile-gated)
  nonce?: bstr,               ; optional uniqueness/challenge binding

  ; who/what issued it
  issuer_kind: tstr,          ; closed enum: "sig" | "hw" | "quorum" | "policy" (profile-gated)
  issuer_id?: bstr,           ; key id / device id (format profile-defined)

  ; proof material (opaque to the kernel; verified by IF-ACP / tooling)
  proof: bstr,                ; signature / token / certificate bytes

  meta?: { * tstr => any }    ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `action_schema` is in a closed allowlist.
3) `action_digest` length matches the hash function used for action digests in the profile.
4) Expiry rules (if enabled): require `not_before <= Now < exp` using a monotonic source (I-TIME-1).
5) `issuer_kind` is in a closed allowlist; unknown kinds reject.
6) `proof` verifies under the issuer’s policy (keys, endorsements, quorum threshold, etc). Any ambiguity rejects.
7) Unknown `meta` keys are ignored unless explicitly allowlisted.

## Notes
- CH-AUTHZ is designed to be referenced in transcripts by digest (e.g., `authz_ref = digest(CH-AUTHZ)`) rather than logging raw `proof` bytes.
- CH-AUTHZ binds one exact `action_digest`; it does not independently carry mutable review/current-head semantics. If mutable basis matters, that dependence must already be encoded into the bound action bytes (for example via exact CH-ACP witness gates); see `approval-basis-posture-v0.md`.
- For a “two-person rule” profile, use `issuer_kind = "quorum"` and encode multiple signatures/certs inside `proof`.
