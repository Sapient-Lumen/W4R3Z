# Device-lease ordering boundary v0 (per-device only)

Purpose: resolve **OQ-0009** by freezing the ACP-visible ordering/serialization scope for future automated device attach/lease/revoke work.

This is intentionally a **boundary** doc, not a new schema. It keeps D-IOLEASE / D-DEVGUARD small while still leaving room for richer queue/endpoint dataplane work *outside* the portal attach policy seam.

Adjunct to:
- `io-lease-posture-v0.md`
- RFC-0085 (`rfcs/0085-device-authorization-and-hotplug-portals.md`)
- RFC-0045 (`rfcs/0045-device-leasing-and-io-bypass.md`)
- D-DEVGUARD / D-IOLEASE / D-COMMUTE (`decision-map.md`)

Research imports (translated into our artifacts, not copied):
- XDG’s USB portal frames generic USB mediation as **device access** and explicitly says apps should prefer specialized portals for specific device types such as cameras (REF-XDG-PORTAL-USB).
- Android USB host permission is granted to a **USB device** first; only after that does the app read/write the appropriate interface endpoints (REF-ANDROID-USB-HOST).
- USBGuard policy authorizes / deauthorizes / rejects a **USB device** by deterministic rule evaluation, keeping matching hints separate from authorization state (REF-USBGUARD-RULELANG).
- Qubes’ generic USB mediation attaches and detaches a **selected USB device** to a target qube, while recommending specialized device-type workflows when possible (REF-QUBES-USB).

## v0 boundary (hard decision)

1) **Attach/lease/revoke automation serializes at `device.id` only**
   - If SlopOS later adds a CH-ACP surface for `portal.device.*`, the ACP-visible serialization scope for attach, grant, revoke, and reattach decisions is exactly the already-pinned typed id family:
     - `CH-CONFLICTKEY family="device.id"`
     - `device_key = ck_id("device.id", device_id)`
   - Same `device_id` means the actions do **not** commute and serialize at the `portal.device` / device-manager boundary (or a later validator named by RFC).
   - Different `device_id` values commute by default unless another already-declared surface says otherwise.

2) **No ACP-visible sub-device ordering family for attach policy**
   - Phase 1 and the next automation step both decline ACP-visible families such as:
     - `device.queue`
     - `device.endpoint`
     - `device.interface`
     - `device.vector`
     - `device.port`
   - `port_path`, bus address, raw serial strings, `/dev` names, interface numbers, queue indices, and UI labels may still appear as policy hints or audit material (for example in CH-DEVGUARD / CH-HWEVENT / CH-IOLEASE), but they are **not** attach-policy ordering identity.

3) **Queue/endpoint sequencing lives below the authorization seam**
   - CH-IOLEASE queue indices, IRQ vectors, DMA windows, and similar dataplane details describe the **bounds of the granted lease**, not a second policy-visible serialization surface.
   - Any queue-local or endpoint-local sequencing needed for performance/correctness lives inside the driver manager / driver host / live lease holder and is evidenced by D-IOLEASE / D-DMA / D-DRVDOM obligations, not by a new `portal.device` conflict-key family.

4) **Specialized device classes should split by portal family, not by sub-device conflict keys**
   - If the system later needs distinct workflows for cameras, microphones, smartcards, scanners, etc., the default move is to use or add a **specialized portal family** with its own explicit authority shape.
   - We do **not** overload generic device attach policy with queue-local or endpoint-local ordering just because one device class has richer internal structure.

5) **Any future exception must pay for a new decision surface**
   - If someone later claims that attach/revoke correctness truly requires sub-device ordering, that proposal must land as **one RFC-backed surface** explaining:
     - why `device.id` is insufficient,
     - where serialization lives,
     - why specialized portals are not the right split, and
     - what evidence/harness demonstrates the non-commutative boundary.
   - Until then, `device.id` remains the only portal attach/lease ordering family.

## Why this boundary exists

- **Keeps D-COMMUTE honest**: authorization ordering is about who may hold the lease, not about every internal queue event.
- **Prevents policy-surface explosion**: queue/endpoint details do not silently become new ACP vocabulary.
- **Preserves specialized mediation**: cameras and other rich device classes can still move to narrower portal families instead of bloating generic USB/device attach.
- **Improves cross-shape coherence**: workstation/cloud/appliance/agent profiles can all reason about one attach-policy key even when their dataplanes differ radically.

## Consequences

- OQ-0009 is resolved: future `portal.device.*` automation uses **per-device** ordering only.
- Concurrent attach vs revoke for the **same** `device_id` is explicitly non-commutative and must serialize at the device-manager boundary.
- Queue-level dataplane concurrency remains a D-IOLEASE / D-DRVDOM / future D-IOQ concern, not a generic device-authorization concern.
- Any richer workflow must add one explicit surface rather than mutating CH-IOLEASE or `device.id` semantics in place.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam.

If a second closely related boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Open-question history: `docs/00-meta/trajectory-map.md` (OQ-0009 resolved here)
- Phase-1 posture: `io-lease-posture-v0.md`
- Device authorization RFC: `rfcs/0085-device-authorization-and-hotplug-portals.md`
- Device dataplane lease RFC: `rfcs/0045-device-leasing-and-io-bypass.md`
- Core commutativity surfaces:
  - `conflict-key-family-registry.md`
  - `conflict-key-schema-v0.md`
  - `conflict-key-derivation-registry.md`
  - `typed-id-contract-v0.md`
- CI drift gate: `tools/check_device_lease_ordering_boundary.py` (EVID-2026-257)

## References

- REF-XDG-PORTAL-USB
- REF-ANDROID-USB-HOST
- REF-USBGUARD-RULELANG
- REF-QUBES-USB
- REF-LINUX-USB-AUTHZ
