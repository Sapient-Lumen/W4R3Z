# D-CC SNP TCB-field claim boundary v0 (TCB report fields stay exact evidence; `REPORTED_TCB` is not a portable security-floor claim)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP TCB version fields** so `CURRENT_TCB`, `COMMITTED_TCB`, `REPORTED_TCB`, and `LAUNCH_TCB` do not quietly collapse into one fuzzy “platform is at version X” claim inside SlopOS verifier, secret-release, or rollout policy.

Entropy cost justification: the archive already pins one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, one SNP guest-mode cut, and one owner-launch-identity rule. What remained ambiguous was narrower and worth deciding now: **SNP attestation reports expose multiple TCB version views with different semantics, and AMD explicitly says `REPORTED_TCB` can be lower than the installed/current platform TCB to preserve continuity during updates**. One small boundary closes that gap without inventing a portable TCB-baseline schema, verifier DSL, or attester-side policy plane.

## Posture (v0)

1) **`REPORTED_TCB` is certificate-linkage evidence, not a portable security-floor claim**
   - AMD’s SNP firmware ABI says the firmware uses the systemwide `ReportedTcb` value to derive the VCEK or VLEK used to sign the report, that the hypervisor sets this value, and that it is never greater than the installed TCB version.
   - AMD’s attestation guidance further says `REPORTED_TCB` may be lower than the current platform TCB to ease continuity during TCB updates and uses it to connect the report to the certificate of the attestation key that signed the report.
   - Phase 1 therefore treats `REPORTED_TCB` as **exact provider-native evidence for signer/certificate linkage only**. It does **not** become a normalized `CH-ATTEST` security-floor claim, “latest patched level,” or a portable proof that the platform currently executes at that exact TCB.

2) **`COMMITTED_TCB` is anti-rollback floor evidence, not current-execution truth**
   - AMD’s attestation guidance describes `COMMITTED_TCB` as the anti-rollback minimum of the platform firmware and microcode.
   - Phase 1 therefore treats `COMMITTED_TCB` as **exact evidence about the committed minimum floor**. It does **not** mean “this is the exact currently executing TCB,” and it does not by itself replace explicit verifier-local vulnerability/baseline policy.

3) **`CURRENT_TCB` is exact current-platform evidence, not a portable normalized claim**
   - AMD’s attestation guidance describes `CURRENT_TCB` as the security-version tuple of the currently executing platform firmware and microcode and labels its usage as informational.
   - Phase 1 therefore preserves `CURRENT_TCB` as **exact provider-native evidence only**. It does not add a new normalized `CH-ATTEST` field, a portable “platform patch level” taxonomy, or a hidden latest-baseline rule.

4) **`LAUNCH_TCB` is historical launch evidence, not a current-state or binder substitute**
   - AMD’s attestation guidance describes `LAUNCH_TCB` as the platform firmware/microcode version at the time this guest launched.
   - Phase 1 therefore treats `LAUNCH_TCB` as **exact historical evidence** about whether the guest once executed under some earlier platform TCB.
   - `LAUNCH_TCB` MUST NOT substitute for current-state appraisal, `boot_digest` / `prov_digest`, or exact `cc_report_data_v0` freshness/binder checks.

5) **Any TCB threshold, baseline, or admission rule remains explicit verifier-local policy**
   - A deployment-specific verifier MAY inspect exact `CURRENT_TCB`, `COMMITTED_TCB`, `REPORTED_TCB`, and `LAUNCH_TCB` bytes and may apply explicit local policy to them (for example, requiring a minimum committed floor, rejecting specific launch-history tuples, or checking current-vs-committed drift).
   - That appraisal remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS rule.
   - Phase 1 adds no native “minimum acceptable SNP TCB,” no portable baseline identifier, and no default rule that one of these four fields is the universally authoritative one.

6) **Packaging/export does not upgrade SNP TCB fields into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `CURRENT_TCB`, `COMMITTED_TCB`, `REPORTED_TCB`, and `LAUNCH_TCB`.
   - If tooling wants to preserve extracted values for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable SNP TCB-baseline schema.
   - Exporting a report that carries those fields does not imply that remote consumers may treat any one of them as reviewed SlopOS-native patch-level truth.

7) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of already-existing SNP report fields.
   - It introduces no new workflow kind, no serialization surface, and no attester-side baseline query or update plane.

## Phase 1 non-goals (explicitly deferred)

- No `current_tcb`, `committed_tcb`, `reported_tcb`, or `launch_tcb` field in `CH-ATTEST v0`.
- No portable SNP baseline identifier, minimum-version schema, or cross-provider TCB taxonomy.
- No default rule that `REPORTED_TCB`, `COMMITTED_TCB`, `CURRENT_TCB`, or `LAUNCH_TCB` alone is the universally authoritative verifier input.
- No attester-side “latest TCB” fetch/query/update plane in IF-ATTEST.

## Why this boundary exists

The archive had already fixed the binding, transport, host-field, owner-identity, and guest-mode seams, but one implementation fork remained likely:
- SNP reports expose multiple TCB version fields,
- AMD says `REPORTED_TCB` can intentionally be lower than the installed/current platform TCB,
- and those fields answer different questions (certificate linkage, anti-rollback floor, current execution, historical launch state).

Without one explicit rule, the first verifier or secret-release harness would predictably do one of these by convention:
- treat `REPORTED_TCB` as “current patch level” because it appears in the report,
- treat `COMMITTED_TCB` as if it were current execution,
- ignore `LAUNCH_TCB` even when launch-history policy matters,
- or widen `CH-ATTEST` into a normalized “platform baseline version” field that quietly hides provider-specific semantics.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **SNP TCB fields remain exact evidence unless explicit local policy says more**,
- **`REPORTED_TCB` stays signer/certificate-linkage evidence rather than a portable vulnerability-floor claim**,
- and **automation cannot inherit a hidden “platform patch level” folklore rule through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact SNP TCB tuples for audit without importing hosted-provider patch-level folklore into portable attestation meaning.
- **Cloud micro-VM substrate (B):** cloud verifiers can make hard minimum-floor or launch-history decisions, but only under explicit local policy rather than by assuming one SNP TCB field is “the OS-approved truth” by default.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling stays small and explicit; imported SNP TCB tuples can be retained for audit without admitting a portable baseline/version taxonomy into the appliance core.
- **Agent / automation OS (D):** agents can inspect exact TCB evidence, but they do not get a hidden provider-specific patch-level shortcut; any TCB appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP TCB-report-field meaning seam.

If a second closely related D-CC SNP TCB-field boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_tcb_field_claim_boundary.py` (**EVID-2026-540**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-SNP-ATTEST-PDF.
- REF-RATS-RFC9334.
