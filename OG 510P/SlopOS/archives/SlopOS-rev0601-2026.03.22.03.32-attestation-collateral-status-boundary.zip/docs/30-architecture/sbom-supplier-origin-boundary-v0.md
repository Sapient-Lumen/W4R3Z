# SBOM supplier/origin boundary v0 (`supplier` / `originator` / `manufacturer` / `authors` stay imported provenance evidence, not native trust or support authority)

Purpose: pin the Phase-1 meaning of **supplier / origin / manufacturer / author labels imported through CH-SBOM and external SBOM documents** across **D-SBOM**, **D-AREF**, and **D-POLICY** so SPDX/CycloneDX provenance richness does not quietly become a portable vendor-trust, support-owner, remediation-owner, or update-selection plane.

Entropy cost justification: the archive already keeps CH-SBOM digest-bound, keeps component identity on exact `content_digest` / `build_id` when available, and already refuses hidden latest-wins, dependency, package-identity, or license-policy semantics from imported SBOM ecosystems. What remains cheap-but-dangerous is the **supplier/origin provenance layer**: SPDX distinguishes `PackageSupplier` from `PackageOriginator` and allows `NOASSERTION`; CycloneDX distinguishes component/BOM `manufacturer`, `supplier`, and `authors`, and explicitly says the supplier may be a distributor or repackager rather than the manufacturer. If left loose, one tool will start treating imported supplier labels as a native trust-root hint, another will infer a portable support/remediation owner from `manufacturer`, and a third will treat one external document's provenance text as selecting whose advisory/update channel should win. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still carry optional `supplier` strings per component as imported descriptive metadata.
- **CH-AREF v0** may still bind one exact external SPDX/CycloneDX SBOM document whose bytes carry richer supplier / originator / manufacturer / author provenance fields.
- **Verifier-local policy/tooling** may still parse, normalize, and reason over those imported provenance fields, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **`supplier` / `originator` / `manufacturer` / `authors` are imported provenance evidence only.**
   - A `supplier` field in CH-SBOM records one imported label chosen by upstream tooling or copied from a richer external SBOM ecosystem.
   - SPDX `PackageSupplier` / `PackageOriginator` and CycloneDX `supplier` / `manufacturer` / `authors` likewise remain imported provenance statements about distribution or creation context.
   - Phase 1 therefore treats those fields as descriptive evidence syntax, not as a native SlopOS vendor identity root, trust anchor, support-owner selector, remediation-owner selector, or update-authority rule.
   - Matching organization/person labels across SBOMs, releases, or external documents carries no portable install, boot, verification, or support verdict by itself.

2) **Exact subject/component binding still rides on digests and build IDs.**
   - `content_digest` and `build_id` remain the portable component-binding fields under **I-SBOM-2**.
   - Companion `sbom-posture-v0.md` already pins `name`, `version`, `purl`, `supplier`, and `licenses` as observational only.
   - This boundary further pins that imported supplier/origin metadata stays on the same non-native side of the line even when outside ecosystems use it for provenance, distribution, support, or compliance workflows.

3) **Phase 1 imports no native vendor graph, canonical organization map, or precedence rule.**
   - SPDX intentionally distinguishes distribution source (`PackageSupplier`) from original source (`PackageOriginator`) and allows `NOASSERTION` for either field.
   - CycloneDX intentionally distinguishes `manufacturer`, `authors`, and `supplier`, and notes that suppliers may be distributors or repackagers rather than the manufacturer.
   - Phase 1 therefore adds no native “manufacturer outranks supplier”, “originator is the trusted upstream”, “same normalized organization string means same vendor everywhere”, “supplier name selects support owner”, “authors imply maintainer authority”, or “`NOASSERTION` means reject / warn / allow” rule.
   - Any such parsing/correlation/evaluation stays verifier-local and explicit under **D-POLICY** rather than leaking into CH-SBOM / CH-AREF meaning.

4) **Provenance labels do not widen install, update, or verification authority.**
   - Imported supplier/origin/manufacturer/author labels may inform local review, triage, routing, or redaction policy, but they do not by themselves authorize install, choose trust roots, pick update channels, choose remediation targets, or widen export rights.
   - Companion `verification-policy-selection-boundary-v0.md` already pins that evidence does not choose which policy is in force.
   - Companion `verification-verdict-boundary-v0.md` already pins that verification/appraisal results stay consumer-local rather than becoming a portable “approved vendor/artifact” plane.
   - Companion `release-identity-boundary-v0.md` already pins that distribution labels stay observational rather than becoming install authority.

5) **Imported richer provenance ecosystems stay imported evidence unless another seam admits more.**
   - SPDX and CycloneDX intentionally carry richer supplier / origin / manufacturer / author metadata because upstream provenance, risk, and compliance workflows need them.
   - Phase 1 may ingest those exact bytes as evidence and may carry exact external docs through **CH-AREF**, but it does not elevate their organization/person vocabulary into privileged-core semantics.
   - Any future native vendor-policy, supplier-routing, or support-owner surface must return RFC-first with explicit conflict keys, commutativity, serialization boundary, and evidence hooks.

6) **Exact artifact binding and policy selection still happen on the existing seams.**
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds the exact subject digest the verifier cares about.
   - **PO-AREF-VERIFY** still answers integrity for one attached external SPDX/CycloneDX document.
   - **PO-POLICY-DETERMINISM** and **PO-POLICY-NONAMP** still answer which local policy, if any, parses imported provenance labels and how that policy avoids ambient widening.
   - No portable “trusted vendor”, “official maintainer”, “support owner”, or “preferred remediation source” verdict is created merely by carrying imported supplier/origin metadata.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported supplier/origin metadata fits with existing SBOM / external-document / policy seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native vendor-identity or organization-canonicalization graph.
- No portable trust-root / support-owner / remediation-owner / official-upstream selector on CH-SBOM itself.
- No rule that SPDX `NOASSERTION` or missing supplier/origin fields create native pass/fail semantics.
- No native precedence rule among supplier / originator / manufacturer / authors.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- SPDX 2.3 says `PackageSupplier` identifies the actual distribution source, while `PackageOriginator` identifies where or from whom the package originally came, and both allow `NOASSERTION`.
- CycloneDX distinguishes `manufacturer`, `authors`, and `supplier`; manufacturers/authors describe who created the component or BOM, while suppliers may be distributors or repackagers.
- CycloneDX’s provenance guidance explicitly treats authorship, supplier, and distribution path as part of provenance tracking rather than a native trust protocol.

Once CH-SBOM, CH-AREF, and verifier-local policy are all present, it becomes extremely tempting to let imported provenance labels choose who should be trusted, who owns support, or which advisory/update source should win. Pinning that split now keeps SlopOS digest-first and keeps vendor/support interpretation explicit and local.

## Profile effect (A–D)

- **Secure workstation (A):** review tooling may still surface supplier/origin hints, but one imported vendor label cannot silently become a global trust or allowlist decision across user software.
- **Cloud micro-VM substrate (B):** fleet tooling may still route by vendor metadata, but portable meaning stays on exact digests rather than imported supplier/manufacturer folklore.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a native vendor graph or support-owner engine inside privileged-core meaning.
- **Agent/automation OS (D):** agents may reason over imported supplier/origin metadata, but they cannot smuggle “this vendor string means trust / update here / escalate there” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-AREF**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/30-architecture/release-identity-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0091-sbom-artifacts-and-closure-binding.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-SBOM-2**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_supplier_origin_boundary.py` keeps the split small and discoverable (**EVID-2026-495**).

## References

- **REF-SPDX-PACKAGE-INFO**
- **REF-CYCLONEDX-PROVENANCE-FIELDS**
- **REF-CYCLONEDX-PROVENANCE-USECASE**
