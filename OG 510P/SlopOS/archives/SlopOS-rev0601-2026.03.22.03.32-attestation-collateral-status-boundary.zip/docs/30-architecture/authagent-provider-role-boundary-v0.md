# D-AUTHAGENT provider-role boundary v0 (no second portable agent API)

Purpose: pin the **Phase 1 relationship** between **D-AUTHAGENT** and **D-CRYPTOSVC** so the archive does not quietly regrow two caller-visible key-holder seams.

This is a small hard decision: if SlopOS enables a key-holding authentication agent in Phase 1, the **portable caller-visible seam is still IF-CRYPTOSVC / D-CRYPTOSVC**. **D-AUTHAGENT** remains a provider role / deployment pattern behind that seam, not a second native API, socket convention, or inventory model.

This doc does **not** remove the usefulness of a factotum-style provider. It removes the entropy of treating “auth agent” and “crypto service” as two different portable surfaces when the archive already wants one small op-only contract.

## Posture (v0)

1) **No second portable auth-agent API in Phase 1**
   - If **D-AUTHAGENT** is enabled, clients still consume crypto authority through **IF-CRYPTOSVC** and the pinned descriptor set (**CH-KEYPOL v0**, **CH-KEYREF v0**, **CH-CRYPTOAUDIT v0**).
   - Phase 1 does **not** standardize a second caller-visible “agent protocol”, file/socket API, or environment-discovered side channel next to D-CRYPTOSVC.
   - The portable meaning lives in `cryptosvc-posture-v0.md`, not in provider-specific wire folklore.

2) **D-AUTHAGENT is a provider role, not a second authority substrate**
   - “Auth agent” means the component that holds long-lived keys and performs non-exportable operations subject to policy.
   - It may be implemented as a user-space service, a hardware-backed provider annex, or another reviewed local provider shape.
   - That choice changes implementation and deployment assumptions, but it does **not** create a second portable authority vocabulary.

3) **Ambient discovery remains forbidden**
   - This boundary does **not** reopen ambient `SSH_AUTH_SOCK` / path / env discovery, provider-global browsing, or smartcard/session auto-discovery by renaming the seam “auth agent”.
   - Compat runtimes / Foreign Cells do not inherit a host auth-agent channel by default.
   - Any interop remains explicit-route, transcript-visible, and policy-killable under the existing D-CRYPTOSVC and D-FCELL rules.

4) **Provider internals do not become caller-visible object models**
   - Phase 1 still declines a PKCS#11-style slot/session/object portability promise on the core seam.
   - Providers may internally wrap HSMs, TPMs, TEEs, smartcards, or software key stores, but those details stay behind the reviewed provider boundary unless a future RFC pays for a new explicit surface.
   - “Supports hardware-backed keys” therefore means a provider annex, not a second app-facing programming model.

5) **Cross-boundary use stays on the existing forwarding boundary**
   - If crypto authority crosses a machine / compat / domain boundary at all, it remains an **explicit narrowed route** governed by `cryptosvc-forwarding-boundary-v0.md`.
   - There is no separate “auth-agent forwarding” exception path, transparent tunnel, or implicit remote inventory/search plane.
   - Delegation may preserve-or-tighten policy only; it may not widen it.

6) **No new admin / lifecycle / inventory control plane in v0**
   - Phase 1 adds no portable list/watch/select/import/export/unlock/configure protocol for auth-agent providers.
   - Starting, unlocking, selecting hardware backing, or routing to a concrete backend remain deployment-local concerns unless a future RFC introduces exactly one explicit new seam and pays for its conflict keys, approvals, receipts, and evidence.

## Phase 1 non-goals (explicitly deferred)

- No second portable auth-agent protocol, socket, or SDK beside IF-CRYPTOSVC.
- No portable auth-agent inventory/search, token/session, PIN/unlock, import/export, or lifecycle-admin surface.
- No ambient host-agent inheritance into compat cells, forwarded sessions, or foreign runtimes by naming accident.
- No provider-object portability promise merely because one implementation happens to wrap an HSM, TPM, smartcard, or software store.

## Why this boundary exists

- **Reduces archive entropy**: one key-holder concept now has one caller-visible seam instead of a D-AUTHAGENT vs D-CRYPTOSVC split that encourages duplicate prose and wrapper folklore.
- **Keeps sealed compat honest**: host agent channels do not leak into compat runtimes by naming accident.
- **Keeps workstation/cloud/appliance/agent shapes aligned**: A/B/C/D may deploy different providers, but they all reason about the same small portable contract.
- **Keeps future research importable**: new key backends or hardware roots can land as provider annexes without forcing every caller-visible doc to fork.

## Imported ecosystem pattern

- **Plan 9 factotum** is the positive pattern here: one small key-holding component that centralizes key use and protocol work.
- **OpenSSH agent restrictions** reinforce the same lesson: the key-holder is sensitive enough that the exposed surface should stay tiny and constraints should be explicit.
- **PKCS#11** is useful as a contrast case: it demonstrates how quickly a token/provider API grows into a rich slot/session/object portability model. SlopOS imports the *non-exportable key-holder* idea, not the full portable token-management object model.

## Consequences

- **IF-CRYPTOSVC** remains the only portable app-facing crypto/key-use interface in Phase 1.
- D-AUTHAGENT remains meaningful as a deployment/provider decision, but not as a second caller-visible API family.
- Future work that truly needs portable provider inventory, hardware-token session semantics, or backend selection must return RFC-first as a **new** explicit seam rather than widening D-AUTHAGENT by convention.

## Family status (Phase 1)

This doc is a **member of the closed D-CRYPTOSVC companion boundary family** in `cryptosvc-boundary-index.md` because the auth-agent-vs-crypto-service split is now one of the explicit meaning cuts that keep IF-CRYPTOSVC small.

Future nearby growth should attach to that family in the **same revision** rather than re-creating auth-agent singleton folklore by inertia.

## Wiring

- Decision surfaces: `decision-map.md` (**D-AUTHAGENT**, **D-CRYPTOSVC**).
- Primary posture / interface seam: `cryptosvc-posture-v0.md`, `interface-registry.md` (**IF-CRYPTOSVC**).
- Adjacent family surface: `secret-authority-adjunct-index.md`.
- Cross-boundary routing boundary: `cryptosvc-forwarding-boundary-v0.md`.
- Mechanism/history notes: `mechanisms.md`, `rfcs/0007-membranes-sealers-and-auth-agents.md`, `rfcs/0067-capability-crypto-services-and-key-handles.md`.
- Assurance hooks: `docs/20-assurance/invariant-registry.md` (**I-AUTHAGENT-1**, **I-CRYPTO-1**, **I-CRYPTO-3**), `docs/20-assurance/proof-obligation-registry.md` (**PO-AUTHAGENT-NONEXPORT**, **PO-CRYPTOSVC-ENF**).
- CI drift gate: `tools/check_authagent_provider_role_boundary.py` (**EVID-2026-533**).

## References

- REF-PLAN9-AUTH.
- REF-PLAN9-FACTOTUM.
- REF-OPENSSH-AGENTRESTRICT.
- REF-PKCS11-SPEC.
