# D-ATTN request-state posture v0 (request id ≠ live notification presentation state)

Purpose: close one small but expensive ambiguity on the D-ATTN seam: **a bounded CH-NOTIF request artifact is not the same thing as current portal-owned live notification presentation state**.

Several of the comparison archives kept this exact split honest in workflow-heavy lanes: a stable review/dedupe request key is useful, but it must not collapse into current live request/presentation truth. SlopOS should be at least that explicit for attention requests.

This doc is intentionally narrow. It does **not** add a notification inbox/history API, a delivery-state watcher, or a durable portal-state schema. It only freezes what CH-NOTIF `id` does and does not mean in Phase 1.

## Posture (v0)

1) **`CH-NOTIF.id` is requester-chosen request identity, not portal-issued live presentation state**
   - `id` is a stable caller-chosen request key scoped to the canonical origin so retries, upserts, withdraws, and ACP dedupe have one exact schema-pinned identity hook.
   - It is **not** a portal-issued presentation instance id, not a delivery receipt id, and not proof that a notification is currently visible, pending, queued, suppressed, or acknowledged.

2) **Request presence is not current presentation-state truth**
   - The existence of CH-NOTIF bytes (or an old `notif_digest`) says only that a bounded request was formed/submitted.
   - It does **not** by itself mean that a notification is currently shown, still coalesced under the same key, awaiting display, still dismissible, or that the user ever saw it.

3) **Current portal-owned presentation state remains portal-local unless a future surface pays for it explicitly**
   - Render, suppress, coalesce, withdraw, dismiss, expire, and any “still visible?” / “was it shown?” truth stay inside the `portal.attn` service boundary in Phase 1.
   - If later work needs portable display-state receipts, durable notification history, acknowledgement state, or watcher/update semantics, it must return RFC-first with its own schema, ordering, privacy, and assurance hooks.

4) **Dedupe/upsert safety uses the request key only as a veto-only identity hook**
   - At-least-once-safe `portal.attn.request` depends on a stable `CH-NOTIF.id` so duplicate `kind="post"` submissions can collapse before effect and `kind="withdraw"` can target one reviewed request identity.
   - That identity hook is still non-authoritative: it may suppress/reuse/withdraw according to portal policy, but it never proves delivery, visibility, or user acknowledgement by itself.

5) **Historical receipts do not reactivate or prove current notification state**
   - A prior CH-ACPOUT / CH-LOG / CH-RECEIPT trail may prove that a request was reviewed or accepted at some point.
   - It does **not** imply that the corresponding notification remains visible, was ever shown, or still has a live dismiss/withdraw target after later coalescing, dismissal, timeout, policy changes, or portal-local cleanup.

## Phase 1 non-goals (explicitly deferred)

- A portable inventory / enumerate-notifications / list-current-attention API.
- A portable receipt or watcher surface proving whether a request is currently queued, shown, suppressed, withdrawn, dismissed, or acknowledged.
- Treating CH-NOTIF `id` as a portal-issued delivery/presentation instance id.
- Letting historical CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts stand in for current portal-owned notification presentation truth.
- Any hidden policy/query language that asks the portal for ambient “current notification state” during ACP validation.

## Why this earns its place

Without this split, the archive quietly collapses two different questions:
- **what exact attention request did we review/dedupe/withdraw?**
- **what presentation state exists right now inside the portal?**

That collapse would make retries, withdrawals, receipts, and later automation less honest. Phase 1 can stay small and still refuse the ambiguity.

## Wiring

- Decision surface:
  - `decision-map.md` (D-ATTN)
- Request descriptor / adjacent posture:
  - `notification-request-schema-v0.md` (CH-NOTIF v0)
  - `attention-lease-posture-v0.md`
  - `attention-durable-interrupt-boundary-v0.md`
  - `attention-durable-status-boundary-v0.md`
- Portal semantics:
  - `portal-family-registry.md`
- ACP automation:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
- RFC / trajectory:
  - `rfcs/0055-attention-authority-and-notifications.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (I-ATTN-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-ATTN-STATE)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`

CI drift gate:
- `tools/check_notification_request_state_posture.py`

## References

- REF-XDG-PORTAL-NOTIFICATION.
- REF-ANDROID-NOTIF-CHANNELS.
- REF-APPLE-CRITICAL-ALERTS.
