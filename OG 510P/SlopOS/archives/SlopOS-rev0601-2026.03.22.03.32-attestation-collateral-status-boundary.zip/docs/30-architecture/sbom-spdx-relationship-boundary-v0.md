# SBOM SPDX relationship boundary v0 (`Relationship` edges stay imported graph evidence, not native closure/causality)

Purpose: pin the Phase-1 meaning of **SPDX relationship edges imported through external SBOM documents** across **D-SBOM**, **D-AREF**, and **D-POLICY** so `DEPENDS_ON`, `CONTAINS`, `GENERATED_FROM`, `DESCRIBES`, and similar SPDX relationship labels do not quietly become a native dependency solver, completeness oracle, causality proof, or fetch/selection language.

Entropy cost justification: the archive already keeps CH-SBOM digest-bound, keeps external SBOM documents on exact CH-AREF digests, and already pins SPDX identifiers and external-document references to document-scoped semantics only. What remains cheap-but-dangerous is the relationship vocabulary itself: SPDX exposes many graph edges, says they are a reasonable estimation from a developer perspective, and explicitly says omitted relationships do not assert absence while `NONE` / `NOASSERTION` carry document-local meaning. Leaving that seam unstated invites expensive drift later: imported dependency edges start acting like native install prerequisites, `CONTAINS` starts widening inventory closure, or one SPDX graph quietly becomes a portable causality story. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still point at one external SPDX/CycloneDX document via `external_doc_aref`.
- **CH-AREF v0** may still bind one exact imported document by digest.
- **Verifier-local policy/tooling** may still parse SPDX relationship edges inside imported documents, but that traversal stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **Imported SPDX relationship edges stay document-graph evidence only.**
   - SPDX relationship types such as `DEPENDS_ON`, `DEPENDENCY_OF`, `CONTAINS`, `GENERATED_FROM`, `DESCRIBES`, and `DESCRIBED_BY` remain imported statements about how one SPDX author related two SPDX elements.
   - Phase 1 therefore treats those edges as document-graph evidence only, not as a native SlopOS dependency language, installation prerequisite set, same-component oracle, or build-causality proof.
   - The same textual relationship label appearing in different imported SPDX documents carries no portable same-meaning authority by itself.

2) **No native dependency / closure / causality rule exists in Phase 1.**
   - One imported `DEPENDS_ON` edge does not mean “this deployment must also contain the target package,” “verification must traverse and import the transitive closure,” or “update/install meaning widens to every reachable node.”
   - One imported `CONTAINS` / `CONTAINED_BY` / `GENERATED_FROM` edge does not mean “these nodes are now part of the native inventory closure,” “this proves complete composition,” or “this derived-from story is authoritative for install/appraisal semantics.”
   - Any such traversal or interpretation remains verifier-local reasoning rather than carrier-visible meaning.

3) **`NONE` and `NOASSERTION` stay imported author claims, not native completeness semantics.**
   - SPDX explicitly allows `NONE` and `NOASSERTION` on relationships and also says omission of a relationship type does not assert whether more relationships exist.
   - Phase 1 therefore does **not** import a native rule such as “`NONE` proves no more related elements exist everywhere,” “`NOASSERTION` means defer install,” or “missing edges imply graph completeness for this subject.”
   - Relationship completeness/sufficiency remains explicit verifier-local policy.

4) **Exact subject/document binding still rides on digests, not relationship traversal.**
   - `external_doc_aref` still binds one exact imported SBOM document through **CH-AREF** digest verification.
   - CH-SBOM subject binding still rides on exact subject digests under D-SBOM rather than on imported SPDX graph shape.
   - Companion `sbom-spdx-reference-boundary-v0.md` already pins that SPDX identifier/reference syntax itself stays non-native; this boundary further pins that traversing the resulting graph does not change that split.

5) **No native fetch / solver / package-manager plane rides on SPDX relationships.**
   - Imported SPDX relationship edges do not imply where to fetch more artifacts, which dependency graph is authoritative, how to solve package constraints, or which optional/build/test dependencies must be materialized.
   - Local tooling may still use those edges for review, analytics, or export.
   - Phase 1 adds no native relationship resolver, closure expander, solver, or graph-query workflow on top of imported SPDX edges.

6) **No native suppression / remediation / vulnerability join rule rides on SPDX relationships.**
   - Imported SPDX relationship edges may help local tooling correlate packages/files/documents, but they do not by themselves suppress vulnerabilities, widen VEX applicability, prove absence, or choose remediation targets.
   - Companion `sbom-vex-evidence-set-boundary-v0.md`, `vex-component-absence-boundary-v0.md`, and `vex-remediation-selection-boundary-v0.md` already pin adjacent seams so relationship traversal cannot back-door those meanings into the archive.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported SPDX relationship vocabulary fits with existing SBOM/evidence seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native SPDX dependency/containment/derivation graph in the privileged core.
- No portable transitive-closure, graph-completeness, or relationship-supersession rule.
- No rule that `NONE` / `NOASSERTION` or omitted edges define native completeness, hold, or waiver semantics.
- No package-manager / solver / fetch behavior derived from imported SPDX relationship edges.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- SPDX 2.3 says relationship edges are a reasonable estimation of the relation between two identified elements from a developer perspective.
- SPDX 2.3 allows `NONE` and `NOASSERTION` on relationship targets and explicitly says omitted relationships of a type do not assert whether more exist.
- SPDX 2.3 supports many relationship labels, including dependency, containment, and description edges, precisely because upstream SBOM tooling wants rich graph semantics.

Pinning that split now keeps SlopOS from quietly inheriting “relationship graph means native dependency / closure / causality truth” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** rich imported SPDX graphs may still help local review, but they cannot silently widen install or vulnerability semantics across user software.
- **Cloud micro-VM substrate (B):** fleet tooling may ingest many third-party SPDX dependency graphs, but portable meaning stays on exact digests rather than transitive graph traversal.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a full imported SPDX dependency solver.
- **Agent/automation OS (D):** agents may reason over imported SPDX relationships, but they cannot smuggle “graph says so” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-AREF**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/sbom-spdx-reference-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_spdx_relationship_boundary.py` keeps the split small and discoverable (**EVID-2026-493**).

## References

- **REF-SPDX-RELATIONSHIPS**
- **REF-SPDX-EXTERNAL-DOC-REF**
- **REF-SPDX-ELEMENT-ID-SCOPE**
- **REF-SPDX-SPEC**
