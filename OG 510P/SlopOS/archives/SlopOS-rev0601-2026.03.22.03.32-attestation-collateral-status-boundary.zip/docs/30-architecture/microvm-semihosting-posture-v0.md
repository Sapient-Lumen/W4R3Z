# MicroVM semihosting posture v0 (debug-host escape stays non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible semihosting under `ext.microvm` so trap-driven debug-host facilities do not quietly become a portable reviewed file/console/time/bootstrap/control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-NONDET**, **D-OBS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible semihosting contract under `ext.microvm`; there is no portable Arm-semihosting-trap-operation plane, no portable semihosting-target-userspace-arg plane, no portable host-file-console-command-time plane, owner-local semihosting enablement/routing stays implementation-local, and reviewed file/console/time/bootstrap meaning still rides on already-pinned explicit seams rather than ambient debug-host trap calls.**

Entropy cost justification: the archive already pins serial consoles, bootstrap metadata, host↔guest transports, time sources, and paravirtual enlightenments individually, but semihosting cuts across those seams at once. Real semihosting ABIs let guest code trigger host file I/O, host console output, host command execution, host command-line injection, and real-world time reads via trap instructions that are easy to treat as “just a debug convenience.” One narrow posture closes that gap without inventing a guest agent, debugger protocol, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible semihosting contract**
   - **Phase 1 exposes no portable ambient guest-visible semihosting contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable semihosting ABI, one stable trap instruction, one stable operation-number vocabulary, or one stable host-debug-agent service surface.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those mechanisms do **not** become SlopOS portable API meaning.

2) **No portable Arm-semihosting-trap-operation plane**
   - There is **no portable Arm-semihosting-trap-operation plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `SVC` / `HLT` / `BKPT` trap contract, one stable `SYS_OPEN` / `SYS_CLOSE` / `SYS_READ` / `SYS_WRITE0` / `SYS_SYSTEM` / `SYS_TIME` / `SYS_CLOCK` operation inventory, or one stable guest-visible register/block ABI for semihosting calls.
   - Owner-local semihosting ABI choice and call handling remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable semihosting-target-userspace-arg plane**
   - There is **no portable semihosting-target-userspace-arg plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `target=native|gdb|auto` routing contract, one stable `userspace=on|off` enablement contract, one stable semihosting chardev/backend selection plane, or one stable guest command-line injection mechanism via semihosting arguments.
   - Owner-local routing to QEMU/native helpers, GDB, files, pipes, sockets, or privileged-vs-userspace callers remains implementation-local and must not silently become portable control or bootstrap meaning.

4) **No portable host-file-console-command-time plane**
   - There is **no portable host-file-console-command-time plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable host path/current-working-directory view, host file-open/read/write/remove/rename contract, host debugger-console output/input contract, host command-execution contract, or guest-visible real-world time / elapsed-clock truth sourced from semihosting operations.
   - Owner-local host file access, host console/debug output, host shell command execution, and host-time servicing remain implementation-local and must not silently become portable file, observation, bootstrap, or time meaning.

5) **Existing explicit seams remain authoritative**
   - Reviewed file/bootstrap meaning still rides on explicit boot artifacts, document/file seams, and the already-pinned bootstrap-metadata posture rather than semihosting arguments, host cwd views, or trap-mediated host file access.
   - Reviewed console/observation meaning still rides on explicit `D-OBS` and the already-pinned microVM console posture rather than ambient semihosting debug-console writes or reads.
   - Reviewed time meaning still rides on explicit `D-NONDET` / `D-TIMEPROOF` seams and the already-pinned microVM time-source posture rather than `SYS_TIME` / `SYS_CLOCK` style debug-host time calls.
   - Reviewed host↔guest channel meaning still rides on the already-pinned host↔guest and paravirt postures rather than semihosting traps that reach host files, commands, or debugger consoles.

6) **Changing the semihosting stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the semihosting stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different debug-host posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `enable_semihosting`, `route_semihosting_to_gdb`, `allow_guest_userspace_semihosting`, or `inject_semihosting_args` control plane by convention.
   - This keeps semihosting meaning on already-pinned activation/file/console/time seams rather than on ambient trap-based debug-host facilities.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_guest_semihosting_policy`, `route_guest_semihosting_console`, `allow_guest_semihosting_fs`, or `inject_guest_semihosting_args` must say whether it commutes with activation, reset, observation export, file/bootstrap policy, and time policy, and where serialization lives.
   - Until then, semihosting remains owner-local runtime/debug convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable Arm semihosting trap/operation contract under `ext.microvm`.
- No portable guest-visible semihosting target-routing / backend / userspace-enable admin plane.
- No portable host filesystem / debugger console / host command execution / host-time truth via semihosting.
- No portable semihosting argument or command-line injection contract.
- No claim that semihosting is an acceptable portable bootstrap, observation, file-I/O, or timeproof mechanism.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-NONDET, D-OBS, D-ACTIVATE)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-console-channel-posture-v0.md`
  - `microvm-bootstrap-metadata-posture-v0.md`
  - `microvm-time-source-posture-v0.md`
  - `microvm-paravirt-enlightenment-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-37)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-SEMIHOST)
- Policy posture:
  - guest-visible semihosting adds **no new lane**, **no portable live enable/disable plane**, and **no portable debug-host truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_semihosting_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable semihosting / no portable Arm-semihosting-trap-operation plane / no portable semihosting-target-userspace-arg plane / no portable host-file-console-command-time plane / owner-local semihosting enablement/routing remains implementation-local / explicit file-console-time seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-SEMIHOSTING.
- REF-QEMU-SEMIHOSTING-MANPAGE.
- REF-ARM-SEMIHOSTING.
- REF-QEMU-XTENSA-SEMIHOSTING.
