# Request-state adjunct index (closed `*-request-state-posture-v0.md` posture family)

Purpose: keep the current **request-identity vs live-state posture family** recoverable as one closed discovery surface.
Why this exists:
The archive now has multiple `*-request-state-posture-v0.md` docs that all pin the same deeper honesty rule in different workflow lanes: a **reviewed requester-chosen request key is not the same thing as current provider-owned mutable state**. Those docs are individually crisp, but without one explicit family surface they are still too easy to rediscover piecemeal from scattered portal/lease/time rows.

This doc does **not** create a universal request-status API, a generic live-state watcher, or a wider portal taxonomy. It keeps the current `*-request-state-posture-v0.md` family closed, enumerable, and reviewable as one implementation-facing surface while leaving lease descriptors, ACP acceptance receipts, and any future portable status/watch schemas as explicitly separate seams.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is a `*-request-state-posture-v0.md` doc under `docs/30-architecture/` that pins the rule that a requester-chosen request/dedupe key does **not** become current provider-owned mutable state;
2) it is a posture doc, not an adjacent schema/result/boundary surface (for example `job-request-schema-v0.md`, `background-lease-schema-v0.md`, `lease-descriptor-state-boundary-v0.md`, and `acp-acceptance-completion-posture-v0.md` stay adjacent);
3) its meaning is about request identity vs live state, not merely a neighboring workflow or lease seam that happens to mention retries, receipts, or current status.

## Closed request-state posture set (Phase 1)

### 1) Scheduler and persistence-adjacent request identity

| Doc | One-line pinned meaning |
|---|---|
| [`job-request-state-posture-v0.md`](job-request-state-posture-v0.md) | CH-JOBREQ `job_id` is a stable request/dedupe key, not current scheduler-owned queue state |
| [`background-request-state-posture-v0.md`](background-request-state-posture-v0.md) | CH-BGREQ `req_id` is a stable request/dedupe key, not current portal-owned background/autostart grant state |

### 2) Lease- and resource-adjacent request identity

| Doc | One-line pinned meaning |
|---|---|
| [`network-request-state-posture-v0.md`](network-request-state-posture-v0.md) | CH-NETREQ `req_id` is a stable request/dedupe key, not current portal-owned network-lease state |
| [`entropy-request-state-posture-v0.md`](entropy-request-state-posture-v0.md) | CH-ENTREQ `req_id` is a stable request/dedupe key, not current portal-owned entropy-handle state |

### 3) Presentation and evidence-adjacent request identity

| Doc | One-line pinned meaning |
|---|---|
| [`notification-request-state-posture-v0.md`](notification-request-state-posture-v0.md) | CH-NOTIF `id` is a stable request/upsert/withdraw key, not current portal-owned notification presentation state |
| [`timeproof-request-state-posture-v0.md`](timeproof-request-state-posture-v0.md) | CH-TIMEREQ `req_id` is a stable request/dedupe key, not current portal-owned timeproof sample/cache state |

## Review rule

When a new `*-request-state-posture-v0.md` doc appears, either:

- add it here **in the same revision**, or
- rename/re-scope it so it clearly belongs to some other existing discovery surface.

If a future change needs a true portable request-status inventory, watcher, queue browser, or current-state receipt family, that widening must be paid for under its own RFC/schema/assurance surface rather than hiding behind this request-identity honesty family.

## Wiring

- Adjacent workflow families: `portal-adjunct-index.md`, `lease-adjunct-index.md`.
- Adjacent honesty boundaries: `lease-descriptor-state-boundary-v0.md`, `acp-acceptance-completion-posture-v0.md`.
- Decision surfaces: `decision-map.md` (**D-JOBS**, **D-BGLEASE**, **D-NETLEASE**, **D-NONDET**, **D-ATTN**, **D-TIMEPROOF**).
- Posture registry / family map: `posture-index.md`, `adjunct-family-map.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_request_state_adjunct_index.py` (**EVID-2026-568**).
