# MicroVM persistent-memory posture v0 (no portable ambient guest-visible persistent-memory contract)

Purpose: pin the **Phase 1** meaning of guest-visible persistent memory under `ext.microvm` so `virtio-pmem`, emulated NVDIMMs, and boot-from-pmem / DAX-rootfs shortcuts do not quietly become an ambient host↔guest storage/persistence plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-VERITY** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible persistent-memory contract under `ext.microvm`; there is no portable `virtio-pmem` / NVDIMM / persistent-memory-flush-or-durability plane, no portable boot-from-pmem or DAX-rootfs contract, owner-local backing-file / DAX / flush discipline stays implementation-local, and reviewed storage/provenance/boot meaning still rides on already-pinned explicit block / verity / activation seams rather than ambient guest pmem devices.**

Entropy cost justification: the archive already fixes guest-visible RAM, CPU, NIC, and block topology at admission, and it already refuses ambient host channels and hidden management helpers. What remained loose was a modern but awkward seam that blurs memory and storage: `virtio-pmem` and NVDIMM-style devices can bypass the guest page cache, carry durability semantics, and even become a boot/rootfs path in production microVM stacks. One narrow posture closes that gap without inventing a new schema family, storage control API, or warm-state distribution format.

## Posture (v0)

1) **No portable ambient guest-visible persistent-memory contract**
   - **Phase 1 exposes no portable ambient guest-visible persistent-memory contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable pmem device class, one stable durable-memory region vocabulary, or one portable byte-addressable persistent-storage ABI across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable persistent-memory device exists with durable writes and memory-mapped storage semantics.”

2) **No portable `virtio-pmem` / NVDIMM / persistent-memory region plane**
   - There is **no portable `virtio-pmem` / NVDIMM / persistent-memory region plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `virtio-pmem` device contract, one stable emulated NVDIMM contract, one stable pmem region inventory, one stable label/namespace vocabulary, or one stable guest-visible persistent-memory topology promise.
   - Implementations may locally expose such devices, but those choices do **not** become SlopOS portable interface meaning.

3) **No portable boot-from-pmem / DAX-rootfs contract**
   - There is **no portable boot-from-pmem / DAX-rootfs contract** under Phase 1.
   - Portable reviewed meaning does **not** include one stable rule that a root filesystem, init image, or deployment payload may be memory-mapped through pmem, bypass the guest page cache, or rely on one guest-visible persistent-memory boot story.
   - Reviewed deployment and boot meaning still rides on explicit boot artifacts, block-topology choices, and D-VERITY style integrity posture rather than ambient guest-visible pmem folklore.

4) **No portable persistence-flush / durability-status plane**
   - There is **no portable persistence-flush / durability-status plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest-visible flush command family, one stable durability-complete or persistence-status signal, one stable host-backed DAX guarantee, or one stable crash-consistency contract derived from a pmem device being present.
   - Guest applications may observe one implementation's pmem/flush behavior locally, but those observations remain implementation-local facts rather than portable reviewed API meaning.

5) **Owner-local backing-file / DAX / flush discipline stays implementation-local**
   - Owner-local backing-file choice, filesystem/DAX setup, host page-cache behavior, crash-persistence discipline, and flush policy stay implementation-local.
   - Implementations may locally use pmem-capable storage, ordinary files, DAX mappings, or boot-from-pmem shortcuts, but those choices do **not** create a portable reviewed promise about one persistence domain, one flush discipline, or one rootfs-mapping story.
   - In particular, backing-file safety, DAX availability, fsync/msync discipline, and host-crash durability remain runtime-local mechanism rather than portable SlopOS semantics.

6) **Changing the persistent-memory stance is owner-local deployment policy or new admission, not a portable live control plane**
   - Changing the persistent-memory stance is owner-local deployment policy or new admission, not a portable live control plane.
   - If policy cares about whether a leaf boots from block storage, pmem, or another owner-local mechanism, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `attach_pmem`, `query_pmem_regions`, `flush_pmem`, or `boot_from_pmem` plane by convention.
   - This keeps reviewed storage and provenance meaning on already-pinned block / verity / activation seams rather than on ambient guest-visible persistent-memory devices.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `attach_pmem`, `replace_pmem_root`, `flush_pmem_range`, or `query_pmem_durability` must say whether it commutes with activation, block-topology policy, snapshot/restore policy, and verity/integrity policy, and where serialization lives.
   - Until then, persistent-memory exposure remains owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable `virtio-pmem` / NVDIMM / persistent-memory region contract under `ext.microvm`.
- No portable boot-from-pmem / DAX-rootfs / pmem-backed root-image contract.
- No portable guest-visible persistence-flush / durability-status / label-namespace contract.
- No portable host-backed DAX or crash-persistence guarantee derived from guest pmem presence.
- No claim that pmem exposure is an acceptable portable substitute for explicit block / verity / activation seams.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-VERITY)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-block-topology-posture-v0.md`
  - `microvm-bus-topology-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `verity-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-44)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-PMEM)
- Policy posture:
  - guest-visible persistent-memory exposure adds **no new lane**, **no portable durable-memory or rootfs-mapping plane**, and **no portable in-place persistence-control contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_persistent_memory_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable guest-visible persistent-memory contract / no portable `virtio-pmem`-or-NVDIMM plane / no portable boot-from-pmem-or-DAX-rootfs contract / no portable persistence-flush-or-durability-status plane / owner-local backing-file-DAX-flush discipline remains implementation-local / explicit block-verity-activation seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-QEMU-VIRTIO-PMEM.
- REF-QEMU-NVDIMM-PMEM-SAFETY.
- REF-CHYP-DEVICE-MODEL.
