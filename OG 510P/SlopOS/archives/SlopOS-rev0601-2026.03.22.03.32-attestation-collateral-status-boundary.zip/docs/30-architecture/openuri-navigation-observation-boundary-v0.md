# D-PLUMB OpenURI navigation-observation boundary v0 (no portable navigation-observation seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable browser/web navigation-observation, page-state, or redirect/final-URL telemetry surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable navigation-observation seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - No portable `navigation_event`, `navigation_id`, `is_redirect`, `redirect_count`, `source_changed`, `content_loading`, `dom_content_loaded`, `navigation_completed`, `final_uri`, `final_url`, `current_url`, `page_title`, `history_changed`, `is_loading`, `loading_progress`, `can_go_back`, `can_go_forward`, `tab_hidden`, or equivalent navigation-observation knob/result on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Handler-local navigation and page state stay handler-local and non-authoritative.**
   - A chosen handler may still track page-load start/finish, redirects, final landing URLs, history changes, DOM readiness, load progress, or tab visibility locally.
   - That does **not** make navigation timing, redirect chains, final landing URL/title, history/back-forward state, or page-loading progress portable portal meaning.
   - Phase 1 therefore declines treating OpenURI as a browser-automation, live navigation telemetry, or cross-context page-state observation seam just because real browsers and embedded-web surfaces may expose those signals internally.

3) **Navigation observation stays on explicit web/navigation seams.**
   - If a product shape later needs reviewed page-load state, redirect/final-URL observation, DOM-ready notifications, or embedded-web navigation delegates, that belongs on a future RFC-first web/session/embedded surface rather than as a side effect of generic launch.
   - Existing explicit seams already show the pattern: Custom Tabs, WebView2, and WKNavigationDelegate expose navigation event streams on dedicated APIs rather than overloading generic “open this URI”.
   - Generic OpenURI therefore stays a mediated launch workflow, not a page-state subscription or navigation-telemetry envelope for the chosen handler.

4) **Navigation observation is a second workflow, not generic launch.**
   - Real ecosystems tempt this widening. XDG OpenURI keeps the portable request shape deliberately small: the request is about mediated launch, not downstream page-load callbacks, final URL reports, or redirect telemetry.
   - Chrome documents `CustomTabsCallback` for tracking `NAVIGATION_STARTED`, `NAVIGATION_FINISHED`, and related events, and separately documents engagement/navigation callbacks as part of a live Custom Tabs session rather than plain URI launch.
   - Microsoft WebView2 documents a navigation event sequence including `NavigationStarting`, `SourceChanged`, `ContentLoading`, `HistoryChanged`, `DOMContentLoaded`, and `NavigationCompleted`, with stable `NavigationId` correlation and redirect handling.
   - Apple documents `WKNavigationDelegate` as the object used to accept/reject navigation changes and track the progress of navigation requests.
   - The 2024 IEEE S&P paper *Subverting the Android Custom Tab Security Model* shows why importing those callbacks into generic launch would be dangerous: the combination of shared browser state and navigation callbacks can leak sensitive user state via event sequence, redirect behavior, and timing.
   - SlopOS imports the narrow lesson: `open_uri` can ask the shell to launch a URI, but it does not become a generic final-URL, redirect, progress, or page-state observation plane.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new navigation-subscribe, page-state-poll, or redirect-observation action family, conflict-key family, or serialization surface.
   - Any future explicit web/navigation seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser callback APIs.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “wait for page load / tell me the final URL / report redirects” behavior through helper fallbacks.
   - If compat needs reviewed navigation observation, it still pays for an explicit future seam rather than smuggling browser telemetry through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `navigation_event`, `navigation_id`, `is_redirect`, `redirect_count`, or equivalent callback/result surface on generic OpenURI.
- No portable `final_uri`, `final_url`, `current_url`, `page_title`, or equivalent landing-state receipt on generic OpenURI.
- No portable `content_loading`, `dom_content_loaded`, `navigation_completed`, `is_loading`, `loading_progress`, or equivalent page-progress surface on generic OpenURI.
- No portable `history_changed`, `can_go_back`, `can_go_forward`, `tab_hidden`, or equivalent live browsing-state callback on generic OpenURI.
- No host-helper fallback that quietly turns generic URI launch into a browser-automation, final-URL, or live navigation telemetry API.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, and non-materializing, but one tempting convenience import still lingers in browser and embedded-web ecosystems: “can I open this URL and also learn when it started loading, whether it redirected, what final URL it landed on, or when the page finished?” That sounds small, but it quietly turns a launch seam into a post-launch observation surface.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a browser-state oracle. That matters for all four product shapes: workstation UX can still launch links without standardizing page-state callbacks; hosted and embedded profiles avoid carrying a fake browser-automation plane they do not want; and agent tooling cannot mistake `open_uri` for a reviewed web-observation API. The security case is not hypothetical: the SP24 Custom Tabs paper shows that callback/timing differences can leak authentication and visited-state information.

## Profile effect (A–D)

- **Secure workstation (A):** browsers/viewers may still have rich local navigation state, but generic OpenURI does not standardize page-load, redirect, or final-URL telemetry as app-visible substrate truth.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting a fake browser/web observation plane from desktop and embedded-web folklore.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising a live page-state or redirect-observation API they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “observe a page session”; reviewed web navigation/state telemetry must return on an explicit future seam.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_navigation_observation_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable navigation-observation seam / handler-local navigation state stays handler-local / navigation observation stays on explicit web/navigation seams / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-596**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-CHROME-CUSTOM-TABS-ENGAGEMENT.
- REF-WEBVIEW2-NAVIGATION-EVENTS.
- REF-WEBKIT-WKNAVIGATIONDELEGATE.
- REF-SP24-TABBED-OUT.
