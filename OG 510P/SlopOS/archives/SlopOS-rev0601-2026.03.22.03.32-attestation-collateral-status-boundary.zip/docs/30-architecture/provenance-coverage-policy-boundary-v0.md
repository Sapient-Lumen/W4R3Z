# Provenance-coverage policy boundary v0 (coverage selection stays verifier-local; no carrier-visible coverage-profile plane)

Purpose: pin the Phase-1 **provenance-coverage policy boundary** across **D-PCP**, **D-ATOMICUPD**, **D-BOOT**, and **D-POLICY** so boot/update carriers may pin exact evidence artifacts without quietly naming the verifier policy profile that decides which carrier-pinned digests must have provenance.

Entropy cost justification: `provenance-required-subject-boundary-v0.md` already says local policy may require provenance only for exact already-pinned carrier digests, but one expensive ambiguity remains: whether **CH-UPD**, **CH-BOOT**, or **CH-PROV** should grow a portable `coverage_profile` / `required_provenance_profile`-style field so artifacts can request stronger or weaker provenance coverage. One narrow boundary buys that down without inventing a new schema family, verifier API, or policy-discovery plane.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how already-pinned seams fit together:
- **CH-UPD v0** and **CH-BOOT v0** may pin exact provenance evidence digests.
- **CH-PROV v0** still describes how exact subject digests were produced.
- **Verification/appraisal policy** still decides which exact carrier-pinned digests must be covered before a local verdict passes.

## Posture (v0)

1) **Carriers may name exact provenance evidence artifacts, not provenance-coverage profiles.**
   - `prov_attestation_digest` in **CH-UPD v0** or **CH-BOOT v0** may pin one exact signed provenance-envelope/container artifact.
   - That field says which exact evidence bytes are attached to the carrier, not which local provenance-coverage policy the verifier must apply.
   - Phase 1 therefore rejects the shortcut “this manifest asks for strict provenance mode” or “this boot record selected the verifier coverage profile”.

2) **Which exact digests require provenance remains explicit verifier-local policy.**
   - Whether the verifier requires provenance over only `target_root_digest`, over `target_root_digest` plus `cfg_digest`, or over selected exact adjunct digests already pinned in `artifacts[]` remains local policy.
   - The authoritative requirement is still the resulting exact digest subset, per `provenance-required-subject-boundary-v0.md`, not any artifact-borne profile name, release tier, or bundle hint.
   - This keeps provenance coverage selection aligned with `verification-policy-selection-boundary-v0.md` and **PO-POLICY-DETERMINISM** / **PO-POLICY-NONAMP**.

3) **Owner-local convenience labels for provenance coverage stay off-carrier and non-portable.**
   - A deployment may certainly maintain local labels such as “boot-minimum”, “release-strict”, or “appliance-factory” for policy authoring convenience.
   - Those labels remain owner-local configuration under **D-POLICY**; they are not exported as portable meaning on **CH-UPD v0**, **CH-BOOT v0**, or **CH-PROV v0**.
   - Phase 1 adds no rule that a verifier must resolve, fetch, or agree on a shared provenance-coverage label vocabulary.

4) **Presence or absence of `prov_attestation_digest` does not choose stronger or weaker verifier policy.**
   - If local policy requires provenance for an exact carrier-pinned digest and the required provenance artifact is absent or invalid, verification fails closed under **PO-PROV-BIND**, **PO-UPD-VERIFY**, or **PO-BOOT-VERIFY**.
   - If local policy does not require provenance for a given digest, merely attaching a provenance artifact does not force stricter portable semantics.
   - Success therefore still means “the active local policy accepted the attached exact evidence”, not “the carrier selected the policy tier”.

5) **No portable policy-ID / profile-name / bundle-membership plane for provenance coverage.**
   - Phase 1 adds no native `provenance_profile`, `required_provenance_profile`, `coverage_level`, `prov_requirements_digest`, or “use the profile embedded in this bundle” field on **CH-UPD v0**, **CH-BOOT v0**, or **CH-PROV v0**.
   - It also adds no rule that `proof_bundle` presence, provenance predicate type, builder identity, or release tier chooses which provenance coverage expectations are in force.
   - Any richer policy packaging remains explicit deployment tooling and must stay killable by local policy.

6) **No hidden policy fetch or ambient negotiation.**
   - A verifier may load policy from local provisioning, explicit trusted policy artifacts, or explicit deployment tooling.
   - Phase 1 adds no ambient lookup like “download the named provenance profile”, “ask the repository which coverage tier applies”, “follow a builder URL for expected subjects”, or “choose policy from the attached bundle manifest”.
   - Provenance coverage therefore remains deterministic, non-ambient, and reviewable.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows what provenance-related carrier fields are allowed to mean around existing boot/update/policy seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `provenance_profile` / `coverage_profile` / `required_provenance_profile` field on CH-UPD, CH-BOOT, or CH-PROV.
- No portable label vocabulary for “minimum / strict / release / appliance” provenance coverage.
- No policy selection by `proof_bundle`, provenance predicate type, builder identity, or release tier.
- No hidden network/discovery plane for provenance-coverage policy lookup.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The adjacent ecosystems keep subject identity and verifier expectations separate:
- in-toto Statements bind attestations to exact subject artifacts by digest, while policy about what must match lives with the verifier;
- SLSA verification guidance tells consumers to compare provenance against explicit expectations rather than artifact-selected policy tiers;
- TUF target metadata tells clients which files are trusted, but attached evidence does not itself carry the verifier policy that decides how those files must be appraised.

Pinning that split now keeps SlopOS from drifting into “manifests ask for strict provenance mode”, “bundles choose the policy tier”, or “release class implies a portable required-subject profile” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** product SKUs may tune local policy without baking policy-tier names into portable artifacts.
- **Cloud micro-VM substrate (B):** promotion pipelines can tighten provenance expectations per fleet or tenant without changing the update-carrier schema.
- **Embedded / separation appliance (C):** sealed offline verifiers stay deterministic because artifacts carry exact evidence digests, not policy-resolution instructions.
- **Agent/automation OS (D):** agents can move evidence around without accidentally negotiating verification policy by manifest field or bundle label.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/provenance-required-subject-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-PROV-CHAIN-1**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-PROV-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_provenance_coverage_policy_boundary.py` keeps the split small and discoverable (**EVID-2026-479**).

## References

- **REF-IN-TOTO-STATEMENT**
- **REF-SLSA-PROVENANCE**
- **REF-SLSA-VERIFYING-ARTIFACTS**
- **REF-TUF-SPEC**
