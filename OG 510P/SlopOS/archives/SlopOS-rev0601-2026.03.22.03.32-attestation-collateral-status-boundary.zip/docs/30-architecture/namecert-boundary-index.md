# Namecert boundary index (v0)

Purpose: keep the **closed set of D-NAMECERT companion boundary docs** enumerable.

Why this exists:
- the archive now pins many small `namecert-*-boundary-v0.md` companions so local naming does not quietly regrow into a resolver, PKI, or ambient authority plane,
- those docs are individually crisp but easy to forget piecemeal because they span evaluator closure, trust anchoring, projection, lifecycle, replication, and bundle-shape semantics,
- `namecert-posture-v0.md` keeps the overall meaning of D-NAMECERT, while this index is the **discovery surface** that says which boundary docs currently make imported/local naming semantics fail closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `namecert-posture-v0.md` and RFC-0023.

## Inclusion rule

A doc belongs here if it removes exactly one tempting local-naming meaning from Phase 1 by constraining one of:
- evaluator closure / trust / propagation semantics that would otherwise regrow a hidden resolver or PKI policy plane,
- projection / lifecycle semantics that would otherwise smuggle automatic namespace mutation into D-NAMECERT,
- bundle representation / replication / target semantics that would otherwise smuggle hidden weighting, hierarchy, freshness, or capability transport into CH-NAMECERT itself.

Adjacent **profile** docs such as `namecert-string-profile-v0.md`, `namecert-principal-profile-v0.md`, and `namecert-signature-profile-v0.md` remain important, but they pin the admitted bundle/profile itself rather than the `namecert-*-boundary-v0.md` companion cluster tracked here.

If future work needs a new native resolver, trust-policy, or capability-transport surface instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind CH-NAMECERT evidence.

## Closed companion boundary set (Phase 1)

### 1) Evaluator closure and trust stay explicit

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`namecert-search-boundary-v0.md`](namecert-search-boundary-v0.md) | bundle-set search / chase | evaluation is closed-world and bounded over one explicit bundle set; no ambient fetch, distributed discovery, or hidden retry daemon | explicit artifact supply plus evaluator-local bounded search |
| [`namecert-selection-boundary-v0.md`](namecert-selection-boundary-v0.md) | candidate choice | multiple admissible candidates stay set-valued; D-NAMECERT adds no hidden ranking or winner-selection rule | explicit local chooser policy plus exact chosen-candidate evidence |
| [`namecert-redelegation-boundary-v0.md`](namecert-redelegation-boundary-v0.md) | onward delegation | delegated subjects do not implicitly gain propagation authority; multi-hop chains require explicit independent authorization | future explicit delegation-propagation seam |
| [`namecert-trust-root-boundary-v0.md`](namecert-trust-root-boundary-v0.md) | trust anchors / issuer admission | trust roots stay evaluator-local input; bundles cannot self-anchor or auto-install trusted issuers | explicit local trust-anchor / key-registry policy |

### 2) Projection and lifecycle stay on the target seam

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`namecert-projection-boundary-v0.md`](namecert-projection-boundary-v0.md) | authority-bearing materialization | accepted results become live authority only through explicit `view.attach` / `view.detach` on concrete `view.slot` keys with retained source digest evidence | D-NS `view.*` actions and target-seam audit receipts |
| [`namecert-time-boundary-v0.md`](namecert-time-boundary-v0.md) | validity / freshness lifecycle | time checks gate future admissions only; live bindings do not auto-expire or auto-detach | explicit target-seam removal plus explicit D-TIME / D-TIMEPROOF policy |
| [`namecert-revocation-boundary-v0.md`](namecert-revocation-boundary-v0.md) | later negative evidence | revocation/withdrawal stays evaluator-local admission input; learning it later does not silently rewrite live namespace state | explicit target-seam review and detach policy |

### 3) Bundle representation stays canonical and non-magical

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`namecert-normal-form-boundary-v0.md`](namecert-normal-form-boundary-v0.md) | statement order / duplication | admitted `bindings` / `delegations` use one duplicate-free strict normal form; no first-match, last-match, or duplicate-weight semantics | canonical validation plus explicit local policy |
| [`namecert-label-atom-boundary-v0.md`](namecert-label-atom-boundary-v0.md) | label structure | admitted labels are single opaque atoms after validation; punctuation does not become hierarchy, wildcard, prefix/suffix, or path grammar | future explicit structured-name seam |
| [`namecert-metadata-boundary-v0.md`](namecert-metadata-boundary-v0.md) | `bundle_id` / `created_ms` | signed bundle metadata stays provenance only; no latest-bundle-wins, replacement lineage, or metadata-driven freshness rule | explicit local bundle-management policy |

### 4) Replication and target material stay evidence-only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`namecert-replication-boundary-v0.md`](namecert-replication-boundary-v0.md) | replicated `object_family = namecert` arrivals | replication moves signed bundle-set evidence only; arrivals do not auto-install bindings, trust roots, or hidden resolver state | explicit local import/admission plus D-REPL evidence transport |
| [`namecert-bearer-boundary-v0.md`](namecert-bearer-boundary-v0.md) | capability-bearing targets | CH-NAMECERT bundles never carry raw CH-SREF / CH-CAPX / sturdyrefs / raw capability material | explicit D-CAPX / CH-SREF import and restore seams |

## Review rule

Before adding another `namecert-*-boundary-v0.md` doc, answer these questions in order:
1) Is the change really a **D-NAMECERT meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported naming semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
