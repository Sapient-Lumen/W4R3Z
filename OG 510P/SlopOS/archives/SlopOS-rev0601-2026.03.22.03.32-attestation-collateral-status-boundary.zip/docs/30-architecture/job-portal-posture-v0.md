# D-JOBS posture v0 (best-effort windows; no replay debt)

Purpose: pin an **implementable Phase 1** meaning for D-JOBS so deferred work stays portalized, bounded, and power-safe.
It narrows the job seam into something validators and harnesses can test without turning SlopOS into a cron clone or a hidden persistence substrate.

This doc is intentionally narrow: it does **not** design a full service manager, a general-purpose calendar engine, or durable recurring automation beyond the bounded job portal surface.

## Posture (v0)

1) **No ambient cron / alarms / exact-at constructors**
   - If D-JOBS is enabled, post-init components obtain deferred background execution only via `portal.jobs` (manual workflow) or ACP kind `portal.jobs.submit` (automation).
   - There is no ambient cron, alarm registration, or exact-wakeup constructor after init.

2) **Trigger semantics are best-effort windows, not exact schedules**
   - CH-JOBREQ `trigger.earliest` means **not before**; it is not a promise to run at that timestamp.
   - `trigger.latest` is an advisory window end for coalescing and pressure-aware scheduling, not a hard deadline guarantee.
   - Periodic requests are declarative maintenance intents, not a per-app wall-clock.

3) **Missed windows are not debt**
   - Phase 1 explicitly forbids replaying each missed periodic interval as backlog after sleep, downtime, or pressure deferral.
   - A stale periodic request MAY yield **at most one catch-up run** before cadence resumes; portals MAY also skip straight to the next eligible window.
   - This keeps downtime from turning into wakeup storms or hidden server-thundering-herd behavior.

4) **Coalesced periodic work, not self-owned clocks**
   - `periodic.interval_sec` + optional `flex_sec` define a coarse eligibility envelope that the portal can coalesce across origin/domain pressure.
   - Tight loops, minute-by-minute polling, and user-invisible “run forever every N seconds” patterns are out of scope for Phase 1.
   - If a workflow truly needs continuous presence, it must come back through D-BGLEASE rather than smuggling persistence into D-JOBS.

5) **Runs are bounded and non-amplifying**
   - Every run stays bounded by declared runtime limits and, where enabled, explicit `digest(CH-TCAP v0)` / `digest(CH-BUDGET v0)` sponsorship.
   - Job execution does **not** imply ambient network, file, device, location, notification, or background/autostart authority.
   - Any such authority remains separately portalized/leased and policy-killable.

6) **Externally visible automation is ordered within a domain**
   - `portal.jobs.submit` is an externally visible action:
     - conflict key family: `domain.id`,
     - ordering: **ordered** within a domain because queue/coalescing/cancel state lives there,
     - serialization boundary: `svc:portal.jobs`,
     - retry stance: at-least-once-safe only when the portal dedupes by stable CH-JOBREQ `job_id` request keys and duplicate suppression is transcript-visible.

7) **Request identity stays distinct from live scheduled state**
   - CH-JOBREQ `job_id` is a requester-chosen stable request/job key for dedupe and review, not a portal-issued queue-entry identifier.
   - The existence of CH-JOBREQ bytes or an old accepted submission does **not** by itself mean a current pending/enabled job still exists; replacement/cancellation/expiry/current queue truth remains portal-local Phase 1 state.
   - If we later need portable queue-entry state, cancel handles, or job-status receipts, that must return RFC-first instead of being inferred from CH-JOBREQ.

8) **Persistence and background presence stay separate**
   - D-JOBS is the preferred surface for deferrable sync, uploads, maintenance, indexing, and retries.
   - D-JOBS does **not** grant continuous background presence, login autostart, or a daemon-like exemption from normal lifecycle clamps.
   - Any durable “keep running / relaunch later forever” posture remains D-BGLEASE territory and is reviewed separately.

9) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell use of deferred background work must flow through explicit adapters and `portal.jobs`; compat runtimes do not gain an ambient host scheduler channel.
   - The seam remains fail-closed behind `cfg.params.lane.portal.jobs`.

## Phase 1 non-goals (explicitly deferred)

- **Exact user-invisible wakeup scheduling** or a compatibility cron surface.
- **Replaying every missed periodic tick** after suspend, reboot, or prolonged pressure.
- **Implicit persistence** by self-resubmitting short jobs to emulate a daemon.
- **Authority widening on trigger** (for example, jobs automatically gaining network or autostart because the request was periodic).

## Wiring

- Decision surface: `decision-map.md` (D-JOBS).
- Schema:
  - `job-request-schema-v0.md` (CH-JOBREQ v0)
  - `job-request-state-posture-v0.md`
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.jobs.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.jobs`)
  - `docs/70-llm-control/acp-action-kind-registry.md` (`portal.jobs.submit`)
  - `docs/70-llm-control/acp-validator-semantics.md` (PO-ACP-JOBS-SUBMIT)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-JOB-1, I-JOB-2, I-JOB-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-JOBREQ-VALIDATE, PO-JOBS-ENF, PO-JOBS-STATE, PO-ACP-JOBS-SUBMIT)

CI drift gate:
- `tools/check_job_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “best-effort / no replay debt / no ambient cron” constraints, or drops its primary REF wiring.

## References

- REF-ANDROID-JOBINFO.
- REF-ANDROID-WORKMANAGER.
- REF-ANDROID-ALARMS.
- REF-APPLE-BGTASKS.
- REF-APPLE-BGTASK-EARLIEST.
- REF-SYSTEMD-TIMER.
