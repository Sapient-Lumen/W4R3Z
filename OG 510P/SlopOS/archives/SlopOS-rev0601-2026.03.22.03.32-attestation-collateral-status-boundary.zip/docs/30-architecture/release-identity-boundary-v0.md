# Release identity boundary v0 (labels/purls/slugs are observational; exact authority stays on digests)

Purpose: pin the Phase-1 meaning of **release identity** across **D-PCP**, **D-ATOMICUPD**, **D-TUF**, and **D-SIGENV** so the archive does not quietly overload one word—“release”—into package-registry mapping, install authority, repository freshness, approval verdicts, and handoff naming folklore all at once.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-PROV v0** answers *how these digests were produced*.
- **CH-UPD v0** answers *which exact digest-bound deployment/config binding we intend to install*.
- **D-TUF** answers *which repository metadata view is fresh and consistent enough to trust for fetching*.
- **CH-SIGENV v0** answers *which payload digest was signed under local policy*.
- `RELEASE-MANIFEST.json` answers *which files are inside one archive handoff bundle*.

## Posture (v0)

1) **Release names, version strings, purls, and handoff slugs are observational distribution identifiers; exact authority stays on digests.**
   - Human-friendly release labels are useful for operators, repositories, package registries, dashboards, and handoff filenames.
   - They MUST NOT become native install authority, boot authority, capability selectors, policy verdicts, or compatibility selectors by themselves.
   - Whenever an artifact matters to the authority substrate, the portable binding is still its exact digest.

2) **Registry/package release attestations describe which digests belonged to one published release; they do not authorize install, boot, or policy verdicts.**
   - External release-attestation formats (for example the in-toto Release predicate) are allowed as evidence imports and publication formats.
   - They answer *which artifacts made up release X in registry Y*, not *should SlopOS install or trust this*.
   - Install/boot authority stays on **CH-UPD v0**, local verification policy, and explicit signature/transparency checks.

3) **Build provenance stays artifact/build-bound; release mapping stays separate.**
   - **CH-PROV v0** remains artifact/build evidence under `provenance-posture-v0.md`.
   - A build may produce one or many artifacts, and ecosystems may add more artifacts to an existing release label later.
   - Therefore Phase 1 keeps “which build produced these digests?” separate from “which registry release name/version currently points at which digests?”.

4) **Repository freshness / rollback / mix-and-match semantics stay on D-TUF metadata, not on release labels.**
   - Version counters, expiry times, threshold signatures, consistent snapshots, rollback checks, and freeze-attack handling stay on **D-TUF**.
   - Release labels or package versions MUST NOT silently inherit those repository-security semantics.
   - Likewise, `latest`, channel labels, or UI sort order do not create any native “latest-wins” install rule.

5) **For handoff bundles, `files[].sha256` is authoritative for integrity; `archive_name`, `revision`, and `slug` are descriptive packaging metadata.**
   - The archive handoff seam is intentionally analogous to the supply-chain seam: the bundle name helps humans, but the embedded file digests are what make payload integrity reviewable.
   - `RELEASE-MANIFEST.json` therefore remains a self-description artifact for one produced zip, not a policy object or release-discovery service.
   - Repacking, renaming, or sorting by slug/revision must not silently change the meaning of the archived file set.

6) **No portable release-discovery / query / inventory / latest-wins plane in v0.**
   - Phase 1 adds no native “list releases”, “resolve latest”, “search by version”, “watch a package name”, or “follow this release channel” authority seam.
   - Tooling may maintain owner-local indexes, package-registry mirrors, or dashboards, but those remain outside the privileged native substrate.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing evidence and distribution seams are interpreted.
   - Any future release publication, promotion, or acknowledgement workflow must return RFC-first with explicit conflict keys, commutativity rules, serialization boundary, and evidence.

## Phase 1 non-goals (explicitly deferred)

- No native package-registry or release-catalog API.
- No portable `latest` / channel-following / release-watch contract.
- No rule that a release name/version/purl by itself authorizes install, boot, or trust.
- No overloading of release attestations into approval, waiver, or verification-summary objects.
- No migration of TUF freshness / rollback / mix-and-match semantics onto release labels.
- No bundle-integrity shortcut where archive name / revision / slug outweigh embedded file digests.

## Why this is worth pinning

The surrounding ecosystem is useful but split on purpose:
- the in-toto Release predicate is specifically about the final distribution stage and release identity in a registry;
- SLSA distribution guidance recommends binding attestations to artifacts rather than to releases;
- TUF defines freshness, rollback, freeze, and consistent-view checks on repository metadata rather than on package-version folklore.

Pinning that split now prevents SlopOS from slowly reinventing an ambient release-management protocol under the names of provenance, update, or packaging.

## Profile effect (A–D)

- **Secure workstation (A):** UI-visible versions/slugs remain convenient for humans, while exact install/rollback authority stays reviewable and digest-bound.
- **Cloud micro-VM substrate (B):** fleet promotion can still speak in image/release names, but admission and rollback remain exact-digest decisions.
- **Embedded / separation appliance (C):** distribution labels stay descriptive while anti-rollback and repository trust stay on explicit TUF/update policy.
- **Agent/automation OS (D):** agents can talk about versions or release names without turning those strings into hidden authority or “latest” oracles.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-ATOMICUPD**, **D-TUF**, **D-SIGENV**.
- Adjacent meaning pins:
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/signature-envelope-posture-v0.md`
- Engineering/application surfaces:
  - `docs/60-engineering/supply-chain-repro.md`
  - `docs/60-engineering/update-repository-metadata-and-key-rotation.md`
  - `docs/60-engineering/release-packaging-contract.md`
  - `docs/60-engineering/release-bundle-manifest-contract.md`
- Assurance anchors:
  - **I-PROV-CHAIN-1**, **I-ATOMICUPD-1**.
  - **PO-PROV-BIND**, **PO-UPD-VERIFY**, **PO-SIGENV-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_release_identity_boundary.py` keeps the split small and discoverable (**EVID-2026-461**).

## References

- **REF-IN-TOTO-RELEASE**
- **REF-SLSA-DISTRIBUTING-PROVENANCE**
- **REF-TUF-SPEC**
- **REF-PEP-427**
