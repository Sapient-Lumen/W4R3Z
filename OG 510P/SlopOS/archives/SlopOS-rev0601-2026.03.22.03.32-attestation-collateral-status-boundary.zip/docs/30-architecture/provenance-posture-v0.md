# Provenance posture v0 (digest-bound build evidence; no release-registry/verdict/query semantics)

Purpose: pin the Phase-1 meaning of **D-PCP** / **CH-PROV v0** so provenance work does not quietly regrow into package-registry folklore, policy-verdict objects, or an ambient transparency/query plane.

This posture is intentionally narrower than the wider in-toto / SLSA / SCITT ecosystem. It fixes the portable meaning of **CH-PROV admission and use** while keeping registry-facing release attestations, verification summaries, rich predicate families, and transparency-service APIs outside the native authority substrate unless another seam admits them explicitly.

## Posture (v0)

1) **CH-PROV is digest-bound build provenance evidence only.**
   - Accepted provenance meaning is the bounded statement that ties one reviewed build/release cohort to a set of exact subject digests under **I-PROV-CHAIN-1** and **PO-PROV-BIND**.
   - CH-PROV MUST NOT by itself authorize install, boot, import, release publication, policy widening, or artifact trust.

2) **One statement set, one build/release cohort; no portable aggregation or supersession semantics.**
   - A CH-PROV artifact describes one bounded build/release cohort: the listed `subjects[]` are the exact outputs for one reviewed invocation/cohort.
   - Phase 1 adds no native “merge these attestations”, “latest build wins”, “supersedes prior provenance”, “derive release history”, or “recursive graph closure” meaning. Any such composition remains explicit local tooling outside D-PCP itself.

3) **Subject matching is by digest; names are observational.**
   - The portable binding is the digest of each subject, not filenames, package names, version strings, or media types.
   - `subjects[].name` and similar human-facing identifiers remain operator/debug aids only and MUST NOT become ambient authority or compatibility selectors.
   - Companion `provenance-required-subject-boundary-v0.md` further pins that local policy may require exact subject subsets only from already-pinned boot/update carrier digests; extra subjects remain extra evidence context only.
   - Companion `provenance-coverage-policy-boundary-v0.md` further pins that carrier-borne provenance fields pin exact evidence bytes only and do not choose which provenance-coverage policy is in force.
  - Companion `provenance-container-selection-boundary-v0.md` further pins that imported multi-statement provenance containers remain packaging only; statement selection/reconciliation stays verifier-local.
  - Companion `provenance-evidence-set-boundary-v0.md` further pins that multiple exact provenance-bearing artifacts do not become one native provenance closure; any cross-artifact union/fallback/completeness rule stays verifier-local.

4) **Builder identity, invocation IDs, and timestamps are informational until explicit policy validates them.**
   - `builder.id`, `builder.version`, `build.invocation_id`, and `build.timestamp` may be useful inputs to local verification policy, but they are not trusted merely because they appear in CH-PROV.
   - Any trust in those fields must ride on explicit **D-SIGENV**, **D-TIME**, **D-TLOG**, or deployment policy rather than on unsigned or unchecked metadata.

5) **Materials and evidence digests are dependency pointers, not fetch instructions.**
   - `materials[]` and `evidence[]` bind exact digests for source trees, toolchains, specs, proofs, and reports.
   - Companion boundary `proof-bundle-role-boundary-v0.md` pins that any `proof_bundle`-labeled output or attachment remains a descriptive exact-artifact role rather than a native bundle/verdict schema.
   - Phase 1 adds no native locator/discovery/fetch semantics, no recursive remote expansion, and no ambient “go retrieve and verify the world” contract from CH-PROV by itself. If heavyweight blobs must be located, they travel through explicit **CH-AREF** and local tooling policy.

6) **CH-PROV is not a release registry statement, verification summary, or policy verdict.**
   - Build provenance answers *how these digests were produced*.
   - Mapping release/version names to artifact sets remains on explicit release/update seams such as **CH-UPD** and packaging policy.
   - Verification results, waivers, and policy conclusions remain separate receipts/evidence; Phase 1 does not overload CH-PROV into a “verified-good”, VSA, or admission-verdict object.

7) **SCITT / registry / transparency interop stays tooling-only.**
   - SCITT-style submission, query, or key-discovery APIs may be useful for release publication and audit, but they remain release-tooling interop layered on **CH-SIGENV** + **CH-TLOG**.
   - Phase 1 does not standardize a privileged-core SCITT client, transparency query service, or ambient key-discovery protocol.

8) **No portable live discovery / query / recursive verification plane in v0.**
   - D-PCP adds no list/watch/search/feed/query protocol for provenance objects.
   - Consumers already holding a CH-PROV artifact may verify it under local policy; discovering or fetching more artifacts is a separate explicit tooling concern.

9) **No new workflow / ACP / conflict-key family in v0.**
   - D-PCP reuses existing update/signature/transparency/evidence seams.
   - Any future provenance publication/acknowledgement/verification workflow must return RFC-first with explicit conflict keys, commutativity rules, serialization boundary, and evidence.

## Phase 1 non-goals (explicitly deferred)

- No native merge/supersession/history semantics for multiple provenance artifacts.
- No package-registry release-name/version binding inside CH-PROV.
- No verification-summary / VSA / waiver / admission-verdict semantics inside CH-PROV.
- No ambient fetch, query, key discovery, or recursive expansion from `materials[]` / `evidence[]`.
- No unsigned metadata shortcut where builder/timestamp/invocation fields become trusted by presence alone.
- No new workflow / ACP family for provenance publication or approval.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-SIGENV**, **D-TLOG**, **D-TIME**.
- Core schema / supply-chain seams:
  - `docs/30-architecture/provenance-attestation-schema-v0.md` (CH-PROV v0).
  - `docs/30-architecture/signature-envelope-schema-v0.md` (CH-SIGENV v0).
  - `docs/30-architecture/transparency-log-anchor-schema-v0.md` (CH-TLOG v0).
  - `docs/30-architecture/artifact-reference-schema-v0.md` (CH-AREF v0).
  - `docs/60-engineering/pcp-posture-v0.md`.
  - `docs/60-engineering/supply-chain-repro.md`.
  - `docs/60-engineering/update-repository-metadata-and-key-rotation.md`.
- Assurance anchors:
  - Claims: **C-PROV-1**, **C-PROV-2**.
  - Invariant: **I-PROV-CHAIN-1**.
  - Proof obligations: **PO-PROV-BIND**, **PO-SIGENV-VERIFY**, **PO-TLOG-VERIFY**, **PO-AREF-VERIFY**.
  - Adjacent seams: **D-SIGENV** for signature/admission policy, **D-TLOG** for optional transparency anchoring, **D-TIME** for freshness policy.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - The closed companion boundary set for these provenance/update-adjacent seams is indexed in `docs/30-architecture/provenance-boundary-index.md`.
  - `tools/check_provenance_posture.py` keeps the posture small and discoverable (EVID-2026-459).

## References

- REF-IN-TOTO
- REF-IN-TOTO-STATEMENT
- REF-SLSA-PROVENANCE
- REF-SLSA-VERIFYING-ARTIFACTS
- REF-DSSE
- REF-SCITT-ARCH
- REF-SCITT-SCRAPI
- REF-IN-TOTO-RELEASE
