# D-PLUMB OpenURI speculative-loading boundary v0 (no portable warmup / preconnect / prefetch / prerender seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable browser warmup, DNS-prefetch, preconnect, speculative prefetch, prerender, or equivalent speculation-control workflow on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable speculative-loading seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `warmup`, `prewarm`, `preconnect`, `dns_prefetch`, `prefetch`, `may_launch`, `may_launch_url`, `prerender`, `speculate`, `speculation_rules`, `preresolve`, or equivalent speculative-loading field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Speculative network work stays request-local or provider-local rather than transcript truth.**
   - A shell, browser, agent, or other handler may choose local UX/performance behavior such as warming a browser process, initiating DNS/TCP/TLS setup, prefetching likely next navigations, or prerendering likely next pages.
   - Phase 1 does **not** reinterpret that provider-local behavior as a portable requester-visible result, stable receipt, or transcript-stable statement that a browser process was warmed, an origin was preconnected, a target was prefetched, or a page was prerendered.
   - Generic OpenURI therefore stays launch-oriented rather than becoming a reusable speculative-network-work oracle for arbitrary URIs.

3) **Speculative loading is a second workflow, not generic launch.**
   - Warming a browser process or speculatively resolving/fetching/rendering a likely next navigation can allocate process startup, DNS resolution, TCP/TLS handshakes, HTTP cache state, connection-pool state, partitioned-cache effects, or hidden provider-local render work before the launched handler commits to final presentation.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to preconnect origins, prefetch bytes, prerender pages, or otherwise speculate on the requester’s behalf.
   - If a future product shape needs reviewed speculative navigation or warmup control, that belongs on a future RFC-first fetch/session/perf seam rather than as a side effect of generic launch.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. The HTML Standard defines `dns-prefetch`, `preconnect`, and `prefetch` link types that preemptively resolve origins, initiate connections, and fetch/cache likely future resources. Chrome Custom Tabs documents `warmup()` and `mayLaunchUrl()` for background browser startup and page prefetch. Chrome’s Speculation Rules / prerender docs describe prefetching and prerendering future navigations for near-instant page loads.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate extra network/process/cache/render semantics that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new warmup/prefetch/prerender action family, conflict-key family, or serialization surface.
   - Any future speculative-loading seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser/performance APIs.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this URL and also warm the browser / preconnect the origin / prefetch or prerender the target” behavior through helper fallbacks.
   - If compat needs reviewed speculative-loading workflows, it still pays for an explicit future seam rather than smuggling warmup or prefetch authority through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `warmup`, `prewarm`, `preconnect`, `dns_prefetch`, `prefetch`, `may_launch`, `may_launch_url`, `prerender`, `speculate`, `speculation_rules`, or `preresolve` knob/result on generic OpenURI.
- No portable warmed-browser, preconnected-origin, prefetched-resource, prerendered-page, or speculation-cache receipt on generic URI launch.
- No shell/helper fallback that quietly resolves DNS, opens a TCP/TLS connection, fills HTTP cache, or renders a hidden future page and reports that second workflow as OpenURI truth.
- No portable cache-warmup, speculative-loading, or pre-navigation performance-control plane on generic URI launch.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, non-materializing, and free of metadata/extraction folklore, but one more convenience import still lingers in mainstream browsers and embedded-browser APIs: “while you’re opening this URI, can you also warm the browser, preconnect, prefetch, or prerender the likely target?” That sounds performance-only, but it quietly turns a launch seam into a network/process/cache/render broker, which is much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into speculative-loading authority. That matters for all four product shapes: workstation UX can still do local warmup or prerender optimizations without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting hidden browser/network work they do not want; and agent tooling cannot mistake `open_uri` for permission to prefetch or prerender arbitrary links.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still perform local warmup or speculative loading, but generic OpenURI does not standardize those behaviors as app-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting hidden browser warmup, preconnect, or prerender behavior and the associated cache/network-state side effects.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising speculative browser/network machinery they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “warm/prefetch/prerender this URI”; reviewed speculative loading stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_speculative_loading_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable speculative-loading seam / speculative network work stays request-local-or-provider-local / speculative loading stays a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-586**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-WHATWG-LINK-TYPE-DNS-PREFETCH.
- REF-WHATWG-LINK-TYPE-PRECONNECT.
- REF-WHATWG-LINK-TYPE-PREFETCH.
- REF-CHROME-CUSTOM-TABS-WARMUP-PREFETCH.
- REF-CHROME-SPECULATION-RULES-PRERENDER.
