# D-PLUMB OpenURI launch-completion boundary v0 (admission is not target-completion truth)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: the portable outcome of `open_uri` / show-item mediation proves **portal admission / launch handoff only**, not downstream target completion, current handler-owned live state, or a durable “the user definitely saw/finished this” truth.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, and no new ACP or conflict-key family. It only narrows how existing mediated launch outcomes may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **The portable OpenURI outcome is admission-scoped, not target-completion truth.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 portable truth is whether the mediated launch request was accepted/carried out at the portal seam.
   - That outcome does **not** by itself prove the chosen handler rendered content, fetched network data, brought a window frontmost, stayed alive, or finished any downstream task.

2) **No portable launched-handler lifecycle / completion / exit receipt in v0.**
   - Phase 1 exports **no** `wait=true`, `until_closed`, `await_loaded`, `await_rendered`, `await_network_done`, `exit_status`, `handler_pid`, or equivalent launched-target lifecycle/result surface on `portal.uri.*`.
   - Requesters do **not** receive a portable receipt for “the target app definitely opened this,” “the user saw it,” or “the target later completed successfully.”
   - If a future product shape needs target-completion or liveness truth, it must pay for an explicit RFC-first workflow or family-local session/result seam rather than widening OpenURI in place.

3) **Provider-local mechanics do not become portable truth.**
   - A backend may internally wait for some launcher primitive, broker reply, window-manager acknowledgement, or host API completion callback before deciding whether the mediated launch request itself succeeded.
   - Such mechanics remain provider-local implementation detail: they do **not** standardize a portable statement about current handler-owned live state or downstream work completion.
   - Compatibility/runtime-specific process handles, completion callbacks, or shell bookkeeping therefore remain local and non-authoritative unless a future explicit seam standardizes them.

4) **Why this cut is honest.**
   - xdg-desktop-portal Request objects say the `Response` signal fires when the **user interaction** for a portal request is over, and `response=0` means “Success, the request is carried out.”
   - Apple’s `open(_:options:completionHandler:)` reports whether the system successfully opened the URL.
   - Windows `ShellExecute` / `ShellExecuteEx` likewise return launch success/failure, while process-handle details are incomplete and backend-dependent.
   - Those are real platform precedents, but they still stop short of a portable “the target completed / the user consumed the content” contract.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; shell-visible launch/focus order still serializes there.
   - Phase 1 adds **no new ACP kind** and **no new conflict-key family** for launch completion because portable requesters do not control or observe that state directly.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient “wait for the target app to finish/open/report back” behavior through helper shims, callback URLs, or host-specific process handles.
   - If compat wants richer completion semantics, that need must come back as an explicit reviewed surface rather than piggybacking on `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable launched-handler completion / exit / liveness surface on `portal.uri.*`.
- No requester-visible receipt proving the target definitely opened, rendered, displayed, or finished processing the subject.
- No `wait=true` / `until_closed` / `await_loaded` / `await_network_done` control on OpenURI.
- No hidden helper/callback/process-handle fallback that reintroduces target-completion truth out of band.
- No ACP/admin/query surface for OpenURI target lifecycle or completion state.

## Why this is worth pinning

Once OpenURI exists, a natural follow-up question is “did it really open?” Ecosystems answer that question inconsistently: xdg portals complete when the request interaction is over and the request is carried out; Apple exposes a completion handler that reports whether the system successfully opened the URL; Windows launcher APIs report success/failure and sometimes a process handle, but not a portable statement that the content was rendered or later consumed. Meanwhile `x-callback-url` shows how quickly launcher seams can regrow into explicit return channels.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a fake completion oracle. That matters for the workstation and agent shapes in particular: automation should not branch on launcher folklore or treat launch success as proof of downstream completion, user attention, or current target-owned live state.

## Profile effect (A–D)

- **Secure workstation (A):** link opening stays useful without letting apps infer that the user definitely viewed or finished something just because a handler launch was admitted.
- **Cloud micro-VM substrate (B):** guest/tenant tooling can request mediated launch where allowed without gaining a host-side launched-app lifecycle or completion oracle.
- **Embedded / separation appliance (C):** deployments with narrow viewers/launchers avoid inventing fake “completion” semantics when the true backend behavior is only launch handoff.
- **Agent/automation OS (D):** agents/tools must treat OpenURI outcomes as admission-scoped and use explicit receipts/workflows for durable completion truth instead of reading target success into a launch acknowledgement.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/openuri-scheme-support-boundary-v0.md`
  - `docs/30-architecture/openuri-handler-selection-boundary-v0.md`
  - `docs/30-architecture/openuri-opener-attribution-boundary-v0.md`
  - `docs/30-architecture/plumb-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/acp-acceptance-completion-posture-v0.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_launch_completion_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **admission-scoped-only / no launched-handler completion-or-liveness receipt / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-575**).

## References

- REF-XDG-PORTAL-REQUEST.
- REF-APPLE-OPENURL-COMPLETION.
- REF-WINDOWS-SHELLEXECUTEEX.
- REF-XCALLBACK-URL.
