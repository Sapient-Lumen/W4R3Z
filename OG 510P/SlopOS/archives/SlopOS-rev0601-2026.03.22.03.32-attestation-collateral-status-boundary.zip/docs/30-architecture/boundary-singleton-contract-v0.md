# Boundary-singleton contract (v0)

Purpose: keep every intentional singleton `*-boundary-v0.md` doc explicit, reviewable, and hard to confuse with a forgotten family.

Why this exists:
- `boundary-family-map.md` already classifies some boundary meaning pins as intentional singletons rather than members of a closed family index,
- once singleton status exists, the next subtle drift risk is **singleton-quality drift**: a doc can stay listed while no longer saying why it is still a singleton or when it should be promoted into a family,
- this contract keeps singleton meaning pins crisp without inventing a new schema, workflow, or product surface.

This doc does **not** add a new schema, workflow, or authority surface.
It is an archive-hygiene contract for intentional singleton discovery surfaces only.

## Contract

Every current intentional singleton boundary doc listed in `boundary-family-map.md` must:
- keep a clear `Purpose:` plus a narrow boundary decision on an existing seam,
- include `## Singleton status (Phase 1)`,
- say explicitly that it remains an **intentional singleton** in `boundary-family-map.md`,
- say why **no broader multi-doc boundary family exists yet** on that seam,
- say that if a second closely related boundary doc appears, the archive must introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia,
- avoid pretending to be a family index, schema, workflow, or new control plane.

The point is not to freeze singletons forever. The point is to keep singleton status an explicit temporary choice rather than an accidental resting place for orphan meaning pins.

## Non-goals

- This contract does **not** decide which singletons should be promoted today; that remains a case-by-case archive decision.
- This contract does **not** replace `boundary-family-map.md`; the map remains the closed coverage surface.
- This contract does **not** authorize hidden family growth by prose like “and related docs”. If a real family exists, pay for one explicit `*-boundary-index.md`.

## Review rule

Before adding or retaining an intentional singleton boundary doc, answer these questions in order:
1) Is this truly one narrow seam on an existing decision surface rather than the start of a real multi-doc family?
2) Does the doc itself say why it is still an **intentional singleton** in `boundary-family-map.md`?
3) If a second closely related meaning pin now exists, have you promoted the seam into one companion `*-boundary-index.md` in the **same revision**?

If the answer to (1) and (2) is yes, keep the singleton contract, the singleton doc, and `boundary-family-map.md` aligned in that same revision.
