# Intent kind registry (workflow `intent.kind` taxonomy)

Purpose: provide a **single canonical** closed-world set of `intent.kind` values used by workflow plumbing (D-PLUMB), including:
- CH-PLUMBMSG v0 (`plumb-message-schema-v0.md`) intent messages
- CH-ROUTE v0 (`route-rules-schema-v0.md`) routing rules
- any portal/validator layer that compiles a higher-level UI/CLI workflow into plumbing messages

Non-negotiable: `intent.kind` is **non-authoritative**. It is a routing/UX hint only. Any authority transfer must occur only via explicit portal sessions/intents/receipts, and must remain policy-killable.

Stability: treat this file as a **stable diff surface**. Adding a new kind changes interoperability and must be justified via an RFC (and, if it materially affects isolation/authority, a decision-map update).

## Canonical kind set (v0; alphabetical)

Each kind is a *verb-like* intent. The actual effect (if any) is performed only by a mediator (router/portal) under explicit policy.

- `background`: request background work scheduling (non-authoritative; any actual background capability is mediated by `portal.background` / CH-BGREQ/CH-BGLEASE when enabled).
- `capture`: request a capture workflow (e.g., screenshot/audio/video) mediated by `portal.capture` under explicit leases/policy.
- `drag`: request drag-and-drop style transfer (typically mediated via an explicit transfer descriptor such as CH-XFER when enabled).
- `export`: request an explicit export workflow (typically mediated by a transfer portal; never raw path/FS access).
- `notify`: request an attention workflow (notification), mediated by `portal.attn` with CH-NOTIF (D-ATTN) when enabled.
- `open`: request opening an object in an appropriate handler; subject resolution must occur via explicit portals/handles (no ambient PATH/FS).
- `open_untrusted`: object-only, **`docref`-only** safe-open request by default (composes with D-EPHEM/D-QUAR); not a URI/URL variant and not a CH-SREF restore/import path, policy chooses the disposable/template posture, and export/clear remain separate explicit workflows.
- `open_uri`: request opening a bounded URI (subject.kind=`uri`); any network access is mediated by `portal.net` leases (no ambient net); Phase 1 OpenURI is manual-only, scheme-gated, and launch-only (no app-visible handler inventory/probing, no requester-visible handler-choice / chooser-control / selected-handler-result surface, no portable opener attribution / referrer channel, no foreground/activation control or receipt, no callback / reentry channel, no launched-handler completion / liveness receipt, no recent-items/history control or receipt, no portable full-URI echo/receipt, no portable download/staging/docref-minting seam, no portable resource-grant / URI-permission / security-scope seam, no portable request-header / method / body customization seam, no portable content-type / MIME / UTI classification seam, no portable URL-safety / phishing / malware / reputation-verdict seam (warning/interstitial and policy verdicts stay provider-local or policy-local rather than portable portal truth), no portable warmup / preconnect / prefetch / prerender seam, no portable link-preview / unfurl metadata seam, no portable reader / article-distillation / extracted-content seam, no portable browser-auth / SSO / OAuth login seam, no portable navigation-observation / final-URL / page-state seam, no portable credential / autofill / passkey seam, no portable web-permission / powerful-feature prompt seam, no portable verified-app-link / associated-domain trust seam, no portable browser/store/install fallback seam, no portable browser-session / profile selection seam, no portable placement / reuse seam, and no portable embedded-web-surface seam), and show-item requests keep exact reveal/select meaning rather than silently degrading into parent-directory browse (`openuri-boundary-index.md`, `openuri-callback-reentry-boundary-v0.md`, `openuri-recent-items-boundary-v0.md`, `openuri-subject-echo-boundary-v0.md`, `openuri-materialization-boundary-v0.md`, `openuri-resource-grant-boundary-v0.md`, `openuri-request-shaping-boundary-v0.md`, `openuri-content-type-boundary-v0.md`, `openuri-url-safety-boundary-v0.md`, `openuri-speculative-loading-boundary-v0.md`, `openuri-preview-metadata-boundary-v0.md`, `openuri-content-extraction-boundary-v0.md`, `openuri-session-selection-boundary-v0.md`, `openuri-launch-disposition-boundary-v0.md`, `openuri-embedded-web-surface-boundary-v0.md`, `openuri-auth-session-boundary-v0.md`, `openuri-navigation-observation-boundary-v0.md`, `openuri-credential-mediation-boundary-v0.md`, `openuri-web-permission-boundary-v0.md`, `openuri-verified-association-boundary-v0.md`, `openuri-install-fallback-boundary-v0.md`, `openuri-showitem-exactness-boundary-v0.md`).
- `paste`: request paste/import from clipboard-like sources; mediated by a clipboard/transfer portal and explicit receipts.
- `pick_device`: request selecting a device/resource; mediated by device portals/leasing (D-DEVGUARD/D-IOLEASE when enabled).
- `print`: request print/render output; mediated by `portal.print` (no ambient printer access); Phase 1 print remains manual-only, render-first, and shell-spooled (no app-visible printer inventory or durable queue authority).
- `save`: request saving to a destination handle; mediated by document/file portals with explicit handle selection.
- `share`: request share/export to another component/user; mediated via transfer/consent portals.

## Validation hooks
- **PO-ENC-DECODE**: unknown `intent.kind` values reject deterministically (no permissive fallback).
- **PO-INTENTKIND-CLOSE**: the canonical kind list is defined **only here** and is kept mechanically closed by CI (no shadow enums elsewhere).

## Notes
- Do not treat `intent.kind` as an authorization check. Policy/authorization must be based on explicit capabilities/leases and explicit portal/validator outcomes.
- If a new kind is proposed, prefer expressing it as a composition of existing kinds + a pinned CH-* descriptor digest rather than expanding the vocabulary.
