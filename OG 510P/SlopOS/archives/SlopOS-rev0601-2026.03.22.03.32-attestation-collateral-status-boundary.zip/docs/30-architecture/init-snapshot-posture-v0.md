# D-INITSNAP posture v0 (boot-bound time-0 authority snapshot; no runtime CH-INIT plane)

Purpose: pin an **implementable Phase 1** meaning for **D-INITSNAP** so `CH-INIT` stays a
small **boot-bound description of time-0 authority** instead of drifting into a runtime snapshot
API, a mutable patch/overlay language, a checkpoint/continuity format, or a constructor/template
catalog.

This posture narrows RFC-0024 into one compact baseline the four SlopOS product shapes can actually
share: `CH-INIT` binds one bounded initial authority graph to boot/deployment artifacts by digest,
construction may consume that digest-pinned input, and any faster continuity or warm-state story
still returns on the already-pinned **D-CHKPT** / **D-EPHEM** / microVM template seams rather than
quietly reusing `CH-INIT` as a second runtime control plane.

## Posture (v0)

1) **CH-INIT is a boot-bound description of time-0 authority only**
   - If **D-INITSNAP** is enabled, `CH-INIT` describes the bounded object graph, capability
     distribution, and optional initial mapping state that matter at **time 0** for authority and
     isolation.
   - The authoritative use is boot/admission-time validation and installation against
     **CH-BOOT** plus any referenced **D-PART** / **D-COMP** / address-decoding artifacts.
   - `CH-INIT` therefore does **not** mean “live system snapshot”, “current inventory dump”,
     “mutable desired state”, or “general save image” in Phase 1 (**I-INIT-1**, **I-INIT-2**).

2) **Digest-bound and bounded, not a general meta-language**
   - `CH-INIT` stays a bounded artifact with closed enums, bounded lists, and predictable
     validation cost under **PO-INIT-VALIDATE**.
   - Referenced artifacts stay digest-bound through `bindings` and **CH-BOOT**; changing the
     intended initial authority graph means emitting a **new artifact digest**, not applying an
     in-place patch.
   - Phase 1 declines an ambient capDL import/export compatibility promise, a macro/overlay
     language, or free-form scripting inside `CH-INIT`.

3) **No portable runtime create/apply/patch/list/watch/export plane for CH-INIT**
   - Phase 1 adds **no** generic `CreateFromInit`, `ApplyInit`, `PatchInit`, `DiffInit`,
     `ListInits`, `WatchInits`, or “export the current machine as CH-INIT” surface.
   - User-space tooling may compile authoring sources into `CH-INIT`, and local debugging tools may
     exist, but no portable runtime workflow/admin plane is standardized around `CH-INIT` itself.
   - Any future live snapshot/import/export/admin surface must return RFC-first and pay for its own
     schema, conflict-key, serialization, and evidence vocabulary.

4) **Warm start, checkpoint, and continuity stay on D-CHKPT / D-EPHEM seams**
   - `CH-INIT` is not the portable meaning of warm restore, checkpoint resume, zygote leaves,
     migration state, or post-boot continuity.
   - Reusable warm-state accelerators, recovery checkpoints, and microVM template leaves remain on
     the already-pinned **D-CHKPT** / **D-EPHEM** / `ext.microvm` seams.
   - A product may derive those accelerators from an initial lineage that includes `digest(CH-INIT)`,
     but the warm-state meaning does not retroactively widen `CH-INIT` into a resume format.

5) **Construction may consume CH-INIT digests, but CH-INIT is not a constructor control plane**
   - **D-CONSTR** components may consume pinned `CH-INIT` digests or fragments as template inputs,
     exactly as they may consume pinned **D-COMP** digests.
   - That does **not** make `CH-INIT` a generic constructor request language, constructor catalog,
     live reseeding surface, or template-selection API.
   - Construction still lives on the constructor-owned invocation/export seams; `CH-INIT` remains the
     reviewed description of the resulting subsystem''s initial authority graph, not the runtime
     management interface for that subsystem.

6) **Fresh install may commute; mutation of an existing target does not**
   - Installing a `CH-INIT` artifact into a **fresh** target domain/subgraph commutes when:
     - the target identity/slot is fresh,
     - only explicit request-local authority/budgets are consumed,
     - and the caller-visible result is a fresh explicit export surface.
   - It does **not** commute when a request mutates/replaces an existing owner-visible slot, target,
     publication point, or deployment lineage. In those cases serialization lives on the owning
     admission/deployment/activation seam, not on a new D-INITSNAP control plane.
   - Any future generic live install surface must declare its own conflict key(s), whether it
     commutes, where serialization lives, and how evidence proves it.

7) **No new workflow / ACP / conflict-key family in v0**
   - D-INITSNAP v0 introduces **no** generic portal family, no generic ACP kind, and no new
     conflict-key family of its own.
   - Reviewable automation may still reference `digest(CH-INIT)` inside already-existing deployment
     or construction surfaces, but `CH-INIT` itself does not become a workflow/control-plane verb.

## Phase 1 non-goals (explicitly deferred)

- No portable runtime create/apply/patch/list/watch/export plane for `CH-INIT`.
- No general macro/overlay language or scriptable cap-distribution meta-language in `CH-INIT`.
- No portable “dump the running system to CH-INIT and re-apply it elsewhere” promise.
- No checkpoint/resume/migration/warm-leaf meaning on `CH-INIT`; that stays on **D-CHKPT** /
  **D-EPHEM** and their already-pinned adjuncts.
- No generic constructor/request/admin plane built out of `CH-INIT`.

## Wiring

- Decision surface: `decision-map.md` (**D-INITSNAP**).
- Core artifact surfaces:
  - `init-state-snapshot-schema-v0.md`.
  - `rfcs/0024-initial-state-snapshots-and-cap-distribution-language.md`.
  - `component-manifest-schema-v0.md`.
  - `partition-policy-schema-v0.md`.
- Adjacent seams that remain authoritative:
  - `constructor-posture-v0.md` (**D-CONSTR**).
  - `disposable-domain-posture-v0.md` (**D-EPHEM**).
  - `microvm-template-lineage-posture-v0.md` / `microvm-template-distribution-posture-v0.md` /
    `microvm-template-availability-posture-v0.md` (**D-MICROVM**, **D-INITSNAP**, **D-CHKPT**).
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-INIT-1**, **I-INIT-2**).
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-INIT-VALIDATE**, **PO-INIT-MATCH**).
- Discovery / amnesia-resistor surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/evidence-index.md`.
  - `tools/README.md`.
- CI drift gate: `tools/check_initsnap_posture.py` (**EVID-2026-455**).

## References

- REF-CAPDL-KUZ10
- REF-MICROKIT-MANUAL
- REF-MICROKIT-VERIFY24
- REF-SEL4-COMPREHENSIVE
