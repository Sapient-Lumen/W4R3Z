# Capshell adjunct index (closed `capshell` posture family)

Purpose: keep the current **D-CAPSHELL adjunct posture set** recoverable as one closed discovery surface.
Why this exists:
The archive already has `capshell-launch-boundary-index.md`, but that doc intentionally covers only the narrower front-end + launch-boundary subset that shapes `capshell.exec` admission and launch normalization. The full `capshell-*-posture-v0.md` family is now large enough that humans/LLMs should not have to reconstruct it by scanning many scattered posture docs plus that narrower subset index.

This doc does **not** create a new D-CAPSHELL schema or widen `capshell.exec` meaning. It keeps the current `capshell-*-posture-v0.md` adjunct family closed, enumerable, and reviewable as one implementation-facing product surface for shapes **A/D** (and optional wrapper-first/cloud automation uses in **B**) while leaving profile **C** free to omit the family entirely.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is a `capshell-*-posture-v0.md` adjunct that constrains `capshell.exec`, integrated capshell behavior, or wrapper-first automation behavior under **D-CAPSHELL**;
2) it is a posture doc, not an adjacent schema/result/boundary surface (for example `capshell-exec-pack-schema-v2.md`, `capshell-output-normal-form-v0.md`, `capshell-result-sidecar-boundary-v0.md`, and `capshell-launch-boundary-index.md` stay adjacent but are not members of this closed filename family);
3) its meaning is capshell-specific rather than a generic neighboring seam that merely happens to be used by capshell (for example `network-lease-posture-v0.md` remains the explicit D-NETLEASE seam, not a member of this family).

## Closed adjunct posture set (Phase 1)

### 1) Exact launch intent and front-end interpretation

These members are also part of the narrower closed subfamily in `capshell-launch-boundary-index.md`.

| Doc | One-line pinned meaning |
|---|---|
| [`capshell-exec-selector-posture-v0.md`](capshell-exec-selector-posture-v0.md) | exactly one reviewed `role="exec"` selector; no ambient PATH |
| [`capshell-exec-object-posture-v0.md`](capshell-exec-object-posture-v0.md) | launch one exact bound executable object; no late reopen/retarget |
| [`capshell-argv0-posture-v0.md`](capshell-argv0-posture-v0.md) | child `argv[0]` derives from the exec selector; no caller/wrapper spoofing |
| [`capshell-code-closure-posture-v0.md`](capshell-code-closure-posture-v0.md) | startup loader/interpreter/shared-library closure stays exact; no ambient search |
| [`capshell-script-entry-posture-v0.md`](capshell-script-entry-posture-v0.md) | script entry requires an explicit interpreter; no shebang/env fallback authority |
| [`capshell-command-string-posture-v0.md`](capshell-command-string-posture-v0.md) | runner input stays structured CH-ARGV only |
| [`capshell-startup-profile-posture-v0.md`](capshell-startup-profile-posture-v0.md) | no implicit rc/profile/per-directory startup hooks |
| [`capshell-word-expansion-posture-v0.md`](capshell-word-expansion-posture-v0.md) | no shell-like pre-exec word/pathname expansion before reviewed argv exists |

### 2) Launch-state normalization and inherited-baseline closure

These members are also part of the narrower closed subfamily in `capshell-launch-boundary-index.md`.

| Doc | One-line pinned meaning |
|---|---|
| [`capshell-env-startup-posture-v0.md`](capshell-env-startup-posture-v0.md) | no inherited startup/import/search env hooks (`PATH`, `LD_*`, `PYTHON*`, etc.) |
| [`capshell-env-baseline-posture-v0.md`](capshell-env-baseline-posture-v0.md) | child env is exact CH-ENV only; no convenience baseline injection |
| [`capshell-cwd-root-posture-v0.md`](capshell-cwd-root-posture-v0.md) | CH-CWD binds an exact cwd root; no host-root fallback or escape |
| [`capshell-handle-table-posture-v0.md`](capshell-handle-table-posture-v0.md) | child handle table is exact CH-STDIO + CH-FDSET only |
| [`capshell-umask-posture-v0.md`](capshell-umask-posture-v0.md) | no inherited file-creation mask; restrictive default only |
| [`capshell-rlimit-posture-v0.md`](capshell-rlimit-posture-v0.md) | no inherited `ulimit` / `getrlimit()` baseline |
| [`capshell-signalstate-posture-v0.md`](capshell-signalstate-posture-v0.md) | no inherited blocked/ignored signal state |
| [`capshell-scheduling-posture-v0.md`](capshell-scheduling-posture-v0.md) | no inherited `nice` / scheduler-policy baseline |
| [`capshell-affinity-posture-v0.md`](capshell-affinity-posture-v0.md) | no inherited CPU-affinity / placement baseline |
| [`capshell-resource-envelope-posture-v0.md`](capshell-resource-envelope-posture-v0.md) | no inherited cgroup / job-object resource envelope |
| [`capshell-personality-posture-v0.md`](capshell-personality-posture-v0.md) | no inherited execution-domain / personality flags |
| [`capshell-mac-profile-posture-v0.md`](capshell-mac-profile-posture-v0.md) | no inherited SELinux/AppArmor/Smack/profile wrapper baseline |
| [`capshell-peer-inspection-posture-v0.md`](capshell-peer-inspection-posture-v0.md) | no inherited dumpable / same-principal ptrace baseline |
| [`capshell-launcher-lifetime-posture-v0.md`](capshell-launcher-lifetime-posture-v0.md) | no launcher-death coupling or wrapper lifetime trap |
| [`capshell-syscall-filter-posture-v0.md`](capshell-syscall-filter-posture-v0.md) | no inherited `seccomp()` / `SystemCallFilter=` baseline |
| [`capshell-privgain-posture-v0.md`](capshell-privgain-posture-v0.md) | no setuid/setgid/file-capability/ambient-capability gain across exec |
| [`capshell-credential-baseline-posture-v0.md`](capshell-credential-baseline-posture-v0.md) | no ambient caller credential baseline; fixed least-privilege executor identity |

### 3) Ambient namespace, runtime, and interactive-control closure

These members are also part of the narrower closed subfamily in `capshell-launch-boundary-index.md`.

| Doc | One-line pinned meaning |
|---|---|
| [`capshell-network-posture-v0.md`](capshell-network-posture-v0.md) | no ambient sockets or host-global resolver baseline |
| [`capshell-local-ipc-posture-v0.md`](capshell-local-ipc-posture-v0.md) | no ambient AF_UNIX/session-bus/autolaunch baseline |
| [`capshell-filesystem-posture-v0.md`](capshell-filesystem-posture-v0.md) | no ambient absolute-path / host-global filesystem baseline |
| [`capshell-nondet-posture-v0.md`](capshell-nondet-posture-v0.md) | no ambient time/entropy baseline when D-NONDET is enabled |
| [`capshell-job-control-posture-v0.md`](capshell-job-control-posture-v0.md) | no portable PTY / controlling-terminal / `fg`/`bg`/`jobs` plane |
| [`capshell-interrupt-cancel-posture-v0.md`](capshell-interrupt-cancel-posture-v0.md) | no portable signal-send / jobspec / SIGHUP interrupt plane |

### 4) Explicit workflow composition and operator-assistance adjuncts

These members stay in the full family even though they are **not** part of the narrower launch-boundary subfamily.

| Doc | One-line pinned meaning |
|---|---|
| [`capshell-pipeline-posture-v0.md`](capshell-pipeline-posture-v0.md) | pipelines are stage-local `capshell.exec` actions; no peer FD/handle passing |
| [`capshell-learnmode-posture-v0.md`](capshell-learnmode-posture-v0.md) | learn mode is observational only; no auto-widen / auto-approve / auto-rerun |

## Review rule

When a new `capshell-*-posture-v0.md` adjunct appears, either:

- add it here **in the same revision**, or
- rename/re-scope it so it clearly belongs to some other existing discovery surface.

If the new doc also shapes front-end interpretation or launch normalization, update `capshell-launch-boundary-index.md` **in the same revision** instead of letting the full family and the narrower subfamily drift apart.

If future work needs a different family rule than “current `capshell-*-posture-v0.md` adjuncts,” that widening must be made explicit in the same revision with matching README / posture-index / runbook / decision-map / evidence wiring.

## Wiring

- Decision surface: `decision-map.md` (**D-CAPSHELL**).
- Narrower subfamily: `capshell-launch-boundary-index.md`.
- Adjacent schema/result seams: `capshell-exec-pack-schema-v2.md`, `capshell-output-normal-form-v0.md`, `capshell-result-sidecar-boundary-v0.md`.
- Adjacent posture: `llm-operations-posture-v0.md`.
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_capshell_adjunct_index.py` (**EVID-2026-522**).
