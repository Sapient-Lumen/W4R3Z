# Signature countersignature boundary v0 (exact second-order signature evidence only; no transitive payload approval or nested-verdict plane)

Purpose: pin the **Phase 1** meaning of countersignatures, nested signed wrappers, and timestamp-token style second-order signatures around **D-SIGENV**, **D-KEYLESS**, and **D-TLOG** so a signature over an envelope/checkpoint/token does not quietly become payload approval, signer-quorum authority, or transitive subject truth.

Entropy cost justification: `signature-envelope-posture-v0.md`, `signing-time-evidence-boundary-v0.md`, `signature-signer-acceptance-boundary-v0.md`, `verification-verdict-boundary-v0.md`, and `transparency-proof-import-boundary-v0.md` already pin *what one exact signature means*, *what signing-time evidence means*, *how multiple same-subject signatures are accepted*, and *why external verdict/proof packaging stays evidence*. The remaining ambiguity is narrower and still expensive: **what a signature over another signed object / checkpoint / timestamp token means**. One small boundary closes that gap without adding a new schema family, nested-verification protocol, or approval workflow.

## Posture (v0)

1) **Countersignatures and nested signatures are exact second-order evidence, not transitive payload truth by themselves.**
   - A signature over a `CH-SIGENV`, a signed statement, a checkpoint, a time-stamp token, or another exact envelope binds those exact bytes (or the exact protocol-defined digest of those bytes).
   - It does **not** by itself retarget to the underlying payload digest, every statement inside a bundle, or every artifact transitively referenced from that signed object.
   - Phase 1 therefore refuses the shortcut “someone countersigned the envelope, therefore they approved the payload / release / bundle contents”.

2) **Second-order signatures do not auto-upgrade verification verdict, quorum, or signer-role policy.**
   - A nested signature may be useful evidence from a reviewer, witness, TSA, or log, but its acceptance still depends on explicit local policy about which exact subjects, signer classes, trust roots, and timing rules matter.
   - Presence of a countersignature therefore does **not** by itself satisfy required signer sets, thresholds, review roles, waivers, install approval, or “audit-complete” semantics.
   - Same-subject multi-signature meaning remains pinned separately by `signature-signer-acceptance-boundary-v0.md`; second-order signatures do not reopen that seam under a different wrapper shape.

3) **Exact subject binding stays explicit at each layer.**
   - DSSE makes the signed subject an exact `(payloadType, payload)` pair, RFC 3161 says a TSA attests that a datum existed before a time, and RFC 9338 defines countersignatures over exact COSE body structures / ToBeSigned inputs.
   - SlopOS therefore keeps each signing layer exact: payload signatures bind the payload subject; countersignatures bind the enclosing signed object; transparency and timestamp artifacts bind their own exact protocol subjects.
   - Any application-level claim that two layers should be treated as equivalent or jointly sufficient remains explicit local verifier policy.

4) **Imported timestamp / countersignature material remains evidence, not native approval or freshness authority.**
   - RFC 3161 tokens, COSE countersignatures, Rekor signed entry timestamps, and similar artifacts may strengthen auditability or prove that one exact signed object existed at/before some point.
   - They still do **not** by themselves authorize install, waive local verification, define global freshness, or select which policy bundle is in force.
   - This keeps second-order signatures aligned with `signing-time-evidence-boundary-v0.md`, `verification-policy-selection-boundary-v0.md`, and `verification-verdict-boundary-v0.md`.

5) **Packaging nested signatures does not create a native nested-envelope format or recursive verification plane.**
   - A release bundle MAY carry countersignatures, TSA tokens, witness signatures, SETs, or other second-order evidence as exact external artifacts.
   - That packaging does **not** create a portable rule for recursive verification order, subject expansion, “verify everything inside until something passes”, or automatic adoption of embedded trust roots / signer classes.
   - Any future portable nested-verification workflow must return RFC-first with explicit subjects, trust roots, conflict keys, serialization boundaries, and evidence hooks.

6) **Sealed compat remains honest.**
   - Compat/import paths that infer payload approval, signer quorum, or policy selection from nested CMS/JWS/COSE/DSSE wrappers must remain killable by policy and must not create hidden authority via environment, implicit network, or host-global trust stores.
   - A compat path that cannot explain exactly which bytes were countersigned and why that matters under explicit local policy must fail closed for portable Phase 1 semantics.

7) **No native countersignature inventory / watch / approval plane in v0.**
   - Phase 1 adds no “show all countersigners”, “latest reviewer signature”, “auto-accept if timestamped”, “recursive verify nested wrappers”, or “watch for new endorsements” service.
   - Any future endorsement/review/publisher workflow must pay for its own schema, subject model, conflict keys, commutativity story, and evidence plan.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no new ACP kind, and no conflict-key namespace.
   - It only narrows what nested signatures / countersignatures / timestamp-token signatures are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native countersignature / nested-envelope schema family in Phase 1.
- No transitive rule that a signature over an envelope/checkpoint/token also signs the underlying payload/release/bundle members.
- No portable recursive-verification order or “verify nested until one passes” semantics.
- No countersignature-selected signer quorum, approval role, or verifier policy.
- No native inventory/watch API for countersignatures / reviewer signatures / latest timestamp.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, second-order signature semantics almost always drift in four expensive directions:

- **Nested signatures start implying payload approval.** A reviewer/witness/TSA signature over one envelope gets misread as approval of everything transitively underneath.
- **Quorum logic leaks across wrapper layers.** Teams count countersignatures / reviewer signatures as if they were the same thing as same-subject signer sets.
- **Timestamp evidence becomes verdict or freshness authority.** “It was countersigned / timestamped” gets mistaken for install approval, not-before satisfaction, or evergreen trust.
- **Recursive verification becomes folklore.** Tools quietly adopt ad hoc wrapper-walking behavior that is neither explicit nor portable.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** downloaded signature/timestamp bundles stay reviewable without silently promoting reviewer/TSA wrappers into install authority.
- **Cloud micro-VM / hosted substrate (B):** fleet policy can require exact second-order evidence while keeping signer roles, quorums, and verdict meaning explicit and reviewable.
- **Embedded / separation-kernel-ish appliance (C):** verifiers can stay tiny and exact, rejecting recursive wrapper folklore and ambient approval badges.
- **Agent / automation OS (D):** agents may transport nested signature evidence, but they cannot smuggle “countersigned therefore approved” authority inside the evidence they want admitted.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-TLOG**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/signing-time-evidence-boundary-v0.md`
  - `docs/30-architecture/signature-signer-acceptance-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_signature_countersignature_boundary.py` keeps the boundary small and discoverable (**EVID-2026-608**).

## References

- REF-DSSE
- REF-RFC3161-TSP
- REF-RFC9338
- REF-SIGSTORE-TIMESTAMPS
