# Runtime-coordination adjunct index (closed low-level runtime wait/queue posture family)

Purpose: keep the current **low-level runtime coordination posture family** recoverable as one closed discovery surface.
Why this exists:
The archive already pins each constituent seam individually, but humans/LLMs should not have to rediscover the current `WaitSet` / `uwait` / `robustlock` / `IoQueue` cluster by opening several low-level posture docs in sequence when they are trying to understand the first worth-coding event-loop / blocking substrate.

This doc does **not** create a general scheduler API, a global async runtime, a cross-process signaling plane, or a broader workflow/admin surface.
It keeps the current **D-WAITSET / D-UWAIT / D-ROBUSTLOCK / D-IOQ** posture set closed, enumerable, and reviewable as one implementation-facing surface for shapes **A/B/D** (and minimal runtime kernels in **C**) while leaving quiesce/orchestration, read-mostly reclamation, CPU-local fast paths, scheduling policy, and higher-level workflow seams explicitly separate.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is `waitset-posture-v0.md`, `uwait-posture-v0.md`, `robustlock-posture-v0.md`, `ioq-posture-v0.md`, or a future posture doc under `docs/30-architecture/` that pins the caller-visible meaning of low-level wait/completion batching, process-local wait/wake synchronization, owner-death recovery for local user-space mutexes, or explicit handle-only async submission/completion;
2) it is a posture doc, not an adjacent schema / RFC / maintenance-control / scheduling / replay / workflow surface (for example `io-buffer-schema-v0.md`, `quiesce-posture-v0.md`, `rcu-posture-v0.md`, `rseq-posture-v0.md`, and `scheduling-posture-v0.md` stay adjacent);
3) its meaning is about portable low-level runtime coordination primitives, not a neighboring seam whose Phase 1 posture intentionally lives elsewhere (for example `quiesce-posture-v0.md`, `ordering-token-posture-v0.md`, `turns-posture-v0.md`, and `capshell-job-control-posture-v0.md` remain distinct).

## Closed low-level runtime coordination posture set (Phase 1)

### 1) Observational waiting and explicit completion batching

| Doc | One-line pinned meaning |
|---|---|
| [`waitset-posture-v0.md`](waitset-posture-v0.md) | waits stay observational and level-triggered by default, with explicit bindings, bounded `{tag, observed_mask}` batches, and no packet/control-plane drift |
| [`ioq-posture-v0.md`](ioq-posture-v0.md) | async submission stays provider-owned and explicit-handle-only, with one SQE → one op and no path constructors, chain semantics, or message-ring drift |

### 2) Process-local synchronization and owner-death recovery

| Doc | One-line pinned meaning |
|---|---|
| [`uwait-posture-v0.md`](uwait-posture-v0.md) | wait-on-address stays process-local, 32-bit, wait+wake only, and free of cross-domain signaling, requeue, PI, or workflow drift |
| [`robustlock-posture-v0.md`](robustlock-posture-v0.md) | owner-death recovery stays mutex-only, component-local, explicit `OWNER_DIED` / `NOT_RECOVERABLE`, and free of kernel lock-manager or cross-process recovery drift |

## Review rule

When a new posture doc appears that primarily pins low-level runtime waiting, explicit completion batching, process-local wait/wake synchronization, or owner-death recovery semantics, either:

- add it here **in the same revision**, or
- explicitly place it under some other existing closed discovery surface in the same revision.

If a future change wants quiesce/orchestration policy, scheduler controls, cross-process wait contracts, packet queues, or richer queue-admin/workflow semantics, that widening must remain explicit on its own seam: keep this index, `quiesce-posture-v0.md`, `rcu-posture-v0.md`, `rseq-posture-v0.md`, `scheduling-posture-v0.md`, and `turns-posture-v0.md` all honest in the same revision instead of letting “runtime coordination” become a blurry control bucket.

## Wiring

- Decision surfaces: `decision-map.md` (**D-WAITSET**, **D-UWAIT**, **D-ROBUSTLOCK**, **D-IOQ**).
- Adjacent runtime-control/concurrency seams: `quiesce-posture-v0.md`, `rcu-posture-v0.md`, `rseq-posture-v0.md`, `scheduling-posture-v0.md`, `turns-posture-v0.md`.
- Adjacent explicit data/control carriers: `io-buffer-schema-v0.md`, `request-context-schema-v1.md`, `ordering-token-schema-v0.md`.
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_runtime_coordination_adjunct_index.py` (**EVID-2026-527**).
