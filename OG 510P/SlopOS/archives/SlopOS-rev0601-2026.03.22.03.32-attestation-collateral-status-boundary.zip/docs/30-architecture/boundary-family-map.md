# Boundary family map (v0)

Purpose: keep **all current `*-boundary-v0.md` docs** mechanically classed as either:
- members of a closed companion `*-boundary-index.md` family, or
- explicit standalone meaning pins whose entropy cost is accepted as a singleton for now.

Why this exists:
- the archive now has many closed companion boundary families, which is good for anti-amnesia,
- but once those families exist, the next real drift risk is **coverage**: a new `*-boundary-v0.md` can land outside both a family index and the tiny intentional-singleton set,
- this map keeps boundary coverage reviewable without inventing a new schema, decision surface, or workflow family.

This doc does **not** create new authority semantics.
It is a documentation/control-surface map for archive hygiene only.

## Closed boundary families

These companion discovery surfaces already own the current multi-doc boundary families:

- [`capshell-launch-boundary-index.md`](capshell-launch-boundary-index.md): closed D-CAPSHELL front-end + launch-boundary adjunct family
- [`sbom-boundary-index.md`](sbom-boundary-index.md): closed D-SBOM import-boundary family
- [`vex-boundary-index.md`](vex-boundary-index.md): closed D-VEX import-boundary family
- [`namecert-boundary-index.md`](namecert-boundary-index.md): closed D-NAMECERT boundary family
- [`quarantined-boundary-index.md`](quarantined-boundary-index.md): closed D-QUAR laundering-prevention family
- [`open-untrusted-boundary-index.md`](open-untrusted-boundary-index.md): closed D-PLUMB / D-QUAR / D-EPHEM safe-open family
- [`openuri-boundary-index.md`](openuri-boundary-index.md): closed D-PLUMB OpenURI companion boundary family
  - current family members: `openuri-scheme-support-boundary-v0.md`, `openuri-handler-selection-boundary-v0.md`, `openuri-opener-attribution-boundary-v0.md`, `openuri-activation-control-boundary-v0.md`, `openuri-callback-reentry-boundary-v0.md`, `openuri-launch-completion-boundary-v0.md`, `openuri-recent-items-boundary-v0.md`, `openuri-subject-echo-boundary-v0.md`, `openuri-materialization-boundary-v0.md`, `openuri-resource-grant-boundary-v0.md`, `openuri-request-shaping-boundary-v0.md`, `openuri-content-type-boundary-v0.md`, `openuri-url-safety-boundary-v0.md`, `openuri-preview-metadata-boundary-v0.md`, `openuri-content-extraction-boundary-v0.md`, `openuri-speculative-loading-boundary-v0.md`, `openuri-session-selection-boundary-v0.md`, `openuri-launch-disposition-boundary-v0.md`, `openuri-embedded-web-surface-boundary-v0.md`, `openuri-auth-session-boundary-v0.md`, `openuri-navigation-observation-boundary-v0.md`, `openuri-credential-mediation-boundary-v0.md`, `openuri-web-permission-boundary-v0.md`, `openuri-install-fallback-boundary-v0.md`, `openuri-verified-association-boundary-v0.md`, `openuri-showitem-exactness-boundary-v0.md`
- [`import-to-docref-boundary-index.md`](import-to-docref-boundary-index.md): closed D-CAPX / D-PLUMB / D-QUAR bearer→document bridge family
- [`signature-boundary-index.md`](signature-boundary-index.md): closed D-SIGENV / D-KEYLESS / D-TLOG verification-adjunct family
- [`attention-boundary-index.md`](attention-boundary-index.md): closed D-ATTN companion boundary family
  - current family members: `attention-durable-interrupt-boundary-v0.md`, `attention-durable-status-boundary-v0.md`
- [`confidential-computing-boundary-index.md`](confidential-computing-boundary-index.md): closed D-CC implementation/binding/trust/launch-context/report-field companion family
  - current family members: `confidential-computing-reference-target-boundary-v0.md`, `confidential-computing-reportdata-binding-boundary-v0.md`, `confidential-computing-snp-certificate-source-boundary-v0.md`, `confidential-computing-snp-vmpl-mode-boundary-v0.md`
  - current family members: `confidential-computing-snp-hostdata-claim-boundary-v0.md`, `confidential-computing-snp-launch-identity-claim-boundary-v0.md`, `confidential-computing-snp-tcb-field-claim-boundary-v0.md`, `confidential-computing-snp-policy-claim-boundary-v0.md`, `confidential-computing-snp-report-identity-claim-boundary-v0.md`
  - current family members: `confidential-computing-snp-chip-id-claim-boundary-v0.md`, `confidential-computing-snp-platform-info-claim-boundary-v0.md`, `confidential-computing-snp-guest-svn-claim-boundary-v0.md`, `confidential-computing-snp-measurement-claim-boundary-v0.md`, `confidential-computing-snp-version-metadata-claim-boundary-v0.md`, `confidential-computing-snp-gosvw-claim-boundary-v0.md`, `confidential-computing-snp-signing-metadata-claim-boundary-v0.md`
  - current family members: `confidential-computing-eat-payload-claim-boundary-v0.md`
- [`provenance-boundary-index.md`](provenance-boundary-index.md): closed D-PCP / D-ATOMICUPD provenance/update-adjunct family
- [`hybrid-topology-boundary-index.md`](hybrid-topology-boundary-index.md): closed D-MK / D-CLUSTERMAP / D-SKB topology-authority family
- [`replication-boundary-index.md`](replication-boundary-index.md): closed D-REPL / Hybrid object-family replication family
- [`cryptosvc-boundary-index.md`](cryptosvc-boundary-index.md): closed D-CRYPTOSVC / D-AUTHAGENT crypto-authority companion boundary family
  - current family members: `authagent-provider-role-boundary-v0.md`, `cryptosvc-inventory-boundary-v0.md`, `cryptosvc-forwarding-boundary-v0.md`, `cryptosvc-provider-selection-boundary-v0.md`, `cryptosvc-interactive-auth-boundary-v0.md`, `cryptosvc-mechanism-boundary-v0.md`, `cryptosvc-key-material-boundary-v0.md`, `cryptosvc-key-lifecycle-boundary-v0.md`, `cryptosvc-derived-material-boundary-v0.md`, `cryptosvc-attestation-boundary-v0.md`, `cryptosvc-verification-boundary-v0.md`
- [`attestation-boundary-index.md`](attestation-boundary-index.md): closed D-ATTEST companion boundary family
  - current family members: `attestation-endorsement-boundary-v0.md`, `attestation-freshness-boundary-v0.md`, `attestation-result-boundary-v0.md`, `attestation-identity-boundary-v0.md`, `attestation-collateral-status-boundary-v0.md`

## Standalone boundary docs (Phase 1)

The following boundary docs are **intentional singletons** today. They stay here until one of two things happens: either a real multi-doc family emerges and gets its own `*-boundary-index.md`, or the doc is retired/absorbed. The singleton side must also stay structurally honest under `boundary-singleton-contract-v0.md`.

- [`capshell-result-sidecar-boundary-v0.md`](capshell-result-sidecar-boundary-v0.md): pins the one narrow seam where command results might try to smuggle durable sidecar authority; broader D-CAPSHELL launch-side family already lives elsewhere.
- [`device-lease-ordering-boundary-v0.md`](device-lease-ordering-boundary-v0.md): pins the one narrow seam between D-IOLEASE ordering tokens and device-lease lifecycle semantics; no broader device-ordering family exists yet.
- [`lease-descriptor-state-boundary-v0.md`](lease-descriptor-state-boundary-v0.md): pins the one narrow seam between exact issued lease/grant descriptor bounds and current provider-owned live state; no broader lease-state boundary family exists yet.
- [`disposable-target-selection-boundary-v0.md`](disposable-target-selection-boundary-v0.md): pins the one narrow seam between asking for disposable routing and naming a concrete destination; no broader disposable-routing boundary family exists yet.
- [`profile-default-artifact-boundary-v0.md`](profile-default-artifact-boundary-v0.md): pins the one narrow seam between markdown profile matrices and generated CH-CFG / CH-POLICY artifacts; no broader profile-artifact boundary family exists yet.
- [`reqctx-sponsorship-evolution-boundary-v0.md`](reqctx-sponsorship-evolution-boundary-v0.md): pins the one narrow seam between sticky request-context sponsorship references and any future typed sponsorship/control plane; no broader D-REQCTX evolution family exists yet.

## Review rule

Before adding a new `*-boundary-v0.md` doc, answer these questions in order:
1) Does an existing `*-boundary-index.md` family already own this meaning pin?
2) If not, is this truly a **singleton seam** rather than the start of a new multi-doc family?
3) If it is a singleton, add it here **in the same revision**.
4) If it is the start of a family, introduce exactly one new `*-boundary-index.md` and justify the entropy cost in that same revision.

The guardrail for this map intentionally fails closed: every current `*-boundary-v0.md` file must be covered by one of the family indexes above or be explicitly named in the singleton list here. Companion family indexes themselves must stay structurally honest under `boundary-index-contract-v0.md`; intentional singleton docs themselves must stay structurally honest under `boundary-singleton-contract-v0.md`; neither route is allowed to survive as a stale placeholder.
