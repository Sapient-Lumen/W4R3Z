# SBOM posture v0 (digest-bound inventory evidence; no merge/fetch/authority semantics)

Purpose: pin the Phase-1 meaning of **D-SBOM** so SBOM work does not quietly regrow into package-manager folklore, ambient disclosure, or a second authority path.

This posture is intentionally narrower than a full supply-chain platform. It fixes the portable meaning of **CH-SBOM admission and use** while keeping generator choice, SPDX/CycloneDX richness, vulnerability correlation, and fleet-specific publication workflows outside the native authority substrate unless another seam admits them explicitly.

## Posture (v0)

1) **CH-SBOM is digest-bound inventory evidence only.**
   - Accepted SBOM meaning is the bounded inventory statement bound to one exact `subject.digest` under **I-SBOM-1**, **I-SBOM-2**, **PO-SBOM-VALIDATE**, and **PO-SBOM-BIND**.
   - CH-SBOM MUST NOT by itself authorize install, boot, import, network fetch, package selection, or policy widening.

2) **One subject, one inventory snapshot; no portable merge/union/delta semantics.**
   - Companion `vex-component-absence-boundary-v0.md` further pins that absence from one selected CH-SBOM does not become a native component-absence oracle; whether one inventory is completeness-sufficient remains verifier-local.
   - A CH-SBOM artifact names one subject digest and one bounded component set.
   - Phase 1 adds no native “merge these SBOMs”, “overlay vendor + scanner inventories”, “delta from previous release”, or “latest inventory wins” meaning. Any such composition remains explicit local tooling outside D-SBOM itself.

3) **Stable component identity carries the portable binding; human-facing identifiers are observational.**
   - When available, `content_digest` and `build_id` are the stable component identity under **I-SBOM-2**.
   - `name`, `version`, `purl`, `supplier`, and `licenses` are helpful but non-authoritative and may be redacted on export.
   - Companion `sbom-bomref-identity-boundary-v0.md` further pins that imported CycloneDX `bom-ref` labels remain document-local adjunct evidence rather than a native cross-artifact component identity or join key.
   - Companion `sbom-purl-identity-boundary-v0.md` further pins that imported `purl` stays a package label rather than a native cross-artifact component identity or join key; matching/normalizing package URLs stays verifier-local rather than riding on one external package ecosystem convention.
   - Companion `sbom-component-version-boundary-v0.md` further pins that component/version labels stay observational imported evidence rather than a native same-component or version-ordering rule; matching or ordered version strings stays verifier-local rather than riding on one external package-version convention.
   - Companion `sbom-supplier-origin-boundary-v0.md` further pins that supplier/origin labels stay observational imported evidence rather than a native trust, support-owner, or remediation-owner rule; normalizing vendor/person labels stays verifier-local rather than riding on one external provenance convention.
   - Companion `sbom-license-metadata-boundary-v0.md` further pins that component license metadata stays observational imported evidence rather than a native allow/deny or obligation rule; parsing SPDX expressions, `LicenseRef-*`, `NONE`, `NOASSERTION`, or CycloneDX license names stays verifier-local rather than riding on one external compliance convention.
  - Companion `sbom-external-reference-locator-boundary-v0.md` further pins that imported SPDX/CycloneDX URL/locator fields stay descriptive imported evidence rather than a native fetch, discovery, or resolver rule; dereferencing `PackageDownloadLocation`, `PackageHomePage`, `ExternalRef`, or `externalReferences` links stays verifier-local rather than riding on one external document-link convention.
   - Companion `sbom-document-supersession-boundary-v0.md` further pins that external SBOM document identity/version fields stay imported evidence rather than a native latest-wins or freshness rule; exact document binding stays on CH-AREF digests rather than on CycloneDX/SPDX document-version folklore.
   - Companion `sbom-spdx-reference-boundary-v0.md` further pins that imported SPDX `SPDXID` / `ExternalDocumentRef` syntax stays document-scoped imported evidence rather than a native cross-artifact join or resolver rule; matching prefixed SPDX references stays verifier-local rather than riding on one external document-graph convention.
   - Companion `sbom-spdx-relationship-boundary-v0.md` further pins that imported SPDX relationship edges stay document-graph evidence rather than a native dependency, closure, or causality rule; traversing `DEPENDS_ON` / `CONTAINS` / `GENERATED_FROM` edges stays verifier-local rather than riding on one external SPDX graph convention.

4) **External SPDX/CycloneDX documents are adjunct evidence, not a second native schema.**
   - Richer SBOM material may be attached through **CH-AREF** and verified separately.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` further pins that multiple exact SBOM/VEX artifacts do not become one native vulnerability/applicability closure merely because they are attached together or linked by subject digest.
   - Phase 1 does not import full SPDX/CycloneDX graph semantics, package-manager dependency solving, or external-document fetch/discovery into privileged-core meaning.

5) **Export and disclosure stay policy-scoped.**
   - Publishing or exporting SBOM material remains governed by **D-OBSPOL** and adjacent release policy.
   - Phase 1 adds no ambient “any observer may list/download all SBOMs” inventory service and no hidden export of supplier, purl, or license metadata outside explicit policy.

6) **Freshness and trust are local packaging policy, not SBOM field folklore.**
   - `generated_at_s`, `generator.*`, and similar metadata are informational only.
   - If a product/profile wants signed or attestable SBOM publication, that trust rides on explicit **D-SIGENV**, **D-TLOG**, **D-TIME**, or packaging policy rather than on unsigned SBOM metadata.

7) **No portable live fetch / discovery / watcher plane in v0.**
   - D-SBOM adds no native feed discovery, polling, subscription, or online resolution contract.
   - Tooling may carry SBOM artifacts in release bundles, provenance sets, or owner-local repositories, but Phase 1 does not standardize a runtime “find me the SBOM” service.

8) **No new workflow / ACP / conflict-key family in v0.**
   - D-SBOM reuses existing update/provenance/observation/admission seams.
   - Any future SBOM publication, ack, waiver, or synchronization workflow must return RFC-first with explicit conflict keys, commutativity rules, serialization boundary, and evidence.

## Phase 1 non-goals (explicitly deferred)

- No package-manager or solver semantics on CH-SBOM.
- No portable union/overlay/delta/supersession model for multiple SBOMs.
- No ambient feed discovery, list/watch API, or repository protocol.
- No unsigned metadata shortcut where `generator` / `supplier` / `name` fields become trusted identity.
- No mandatory import of full SPDX/CycloneDX semantics into the privileged core.
- No new workflow / ACP family for SBOM publication or approval.

## Wiring

- Companion boundary index:
  - `docs/30-architecture/sbom-boundary-index.md` (closed companion set of `sbom-*-boundary-v0.md` docs that keeps imported inventory semantics enumerable and machine-checked).
- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-OBSPOL**, **D-SIGENV**, **D-TLOG**, **D-TIME**.
- Core schema / supply-chain seams:
  - `docs/30-architecture/sbom-schema-v0.md` (CH-SBOM v0).
  - `docs/30-architecture/artifact-reference-schema-v0.md` (CH-AREF v0).
  - `docs/60-engineering/supply-chain-repro.md`.
  - `rfcs/0091-sbom-artifacts-and-closure-binding.md`.
- Assurance anchors:
  - Invariants: **I-SBOM-1**, **I-SBOM-2**.
  - Proof obligations: **PO-SBOM-VALIDATE**, **PO-SBOM-BIND**, **PO-AREF-VERIFY**.
  - Adjacent seams: **D-OBSPOL** for export control, **D-SIGENV** for signature/admission policy, **D-TLOG** for transparency anchoring, **D-TIME** for freshness policy.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - `tools/check_supply_chain_evidence_posture.py` keeps the posture small and discoverable together with D-VEX (EVID-2026-458).

## References

- REF-NTIA-SBOM-MIN2021
- REF-CISA-SBOM-MIN2025
- REF-SPDX-SPEC
- REF-CYCLONEDX-OVERVIEW
