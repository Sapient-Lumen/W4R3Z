# D-PLUMB OpenURI resource-grant boundary v0 (no portable URI-permission / security-scope / attachment-grant seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable local-resource grant, URI-permission, security-scope, share-attachment, or docref-handoff surface on `portal.uri.*`.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1. **No portable resource-grant / URI-permission / security-scope seam in v0**
   - Phase 1 does **not** export a portable `grant_read`, `grant_write`, `grant_uri_permission`, `persist_uri_permission`, `grant_target_app`, `content_uri`, `clipdata_uri`, `security_scope`, `security_scoped_bookmark`, `share_docref`, `attachment_docref`, `xfer_token`, or equivalent local-resource grant / handoff field on `portal.uri.*`.
   - A shell, browser, activity resolver, document provider, share sheet, or chosen handler may still attach a content URI, pass a temporary/persistable URI permission, or resolve a sandbox bookmark locally, but those grant mechanics remain provider-local rather than portable portal truth.
   - Phase 1 does **not** reinterpret local grant/handoff mechanics as a requester-visible result, durable receipt, or transcript-stable statement that launch also conveyed target-side local-object authority.

2. **Local-object authority transfer stays on explicit file/document/transfer seams**
   - Generic OpenURI is about *admission of a mediated launch*, not about minting reusable local-resource access for another component.
   - If reviewed local-object authority transfer matters, it must live on explicit `portal.file.*`, CH-DOCREF, or `portal.xfer.*` workflows with their own policy, receipts, lifetimes, and revocation semantics.
   - Phase 1 therefore does **not** reinterpret generic launch as authority to issue local-resource grants on the requester’s behalf.

3. **Why this boundary exists**
   - Existing ecosystems really do expose these knobs. XDG Documents grants sandboxed apps explicit document access. Android FileProvider and the Storage Access Framework use `content://` URIs plus temporary or persistable URI permission grants. Apple exposes security-scoped bookmark access for sandboxed file reopen.
   - Those are valuable local platform APIs, but they are also exactly the kind of durable/shareable local-object authority that would make `portal.uri.*` drift into a hidden attachment/share/docref handoff plane if imported casually.
   - Pinning the boundary now keeps workstation UX flexible without forcing cloud, embedded, or agent profiles to inherit fake attachment/share/grant semantics as portable substrate meaning.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future reviewed local-resource grant or attachment/share surface must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from URI permission systems, bookmark APIs, or share sheets.
   - Until then, generic `open_uri` remains admission-scoped only; local-object authority transfer stays hidden inside explicit file/document/transfer workflows.

5. **Grant/handoff is a second workflow, not generic launch**
   - If SlopOS ever needs reviewed URI-permission, attachment-handoff, or security-scope semantics, that work should return as a **separate RFC-first workflow/surface** with explicit authority, profile gating, transcript semantics, and policy kill switches.
   - It must not arrive by adding “just one more attachment/grant field” to generic `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `grant_uri_permission`, `persist_uri_permission`, `content_uri`, `security_scope`, `security_scoped_bookmark`, `share_docref`, `attachment_docref`, `xfer_token`, or equivalent local-resource grant/handoff knob/result on generic OpenURI.
- No transcript-stable statement that launch also granted read/write/document authority to some target.
- No importer-visible attachment/share/security-scope folklore on the D-PLUMB seam.
- No shell/helper fallback that quietly promotes `open_uri` into a local-resource grant or attachment-handoff workflow and reports that second workflow as generic OpenURI truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, agents and wrappers quickly start depending on guessed semantics like “open this and give the target a readable local object,” “tell me the granted content URI,” or “persist the same authority for reuse later.” Once those assumptions land in transcripts, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning mediated launch into local-resource grant authority. That matters for all four product shapes: workstation UX can still use local sharing/bookmark/document-grant mechanics without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting attachment/share state they do not want; and agent tooling cannot mistake `open_uri` for permission to mint or persist local-object access.

## Profile effect (A–D)

- **Secure workstation (A):** shells, browsers, document providers, and share surfaces may still do rich local handoff/grant work, but generic OpenURI does not standardize URI-permission or security-scope outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake attachment/share/grant contracts or cross-component local-object handoff obligations they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising general-purpose attachment/share or security-scope workflows they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with permission to demand `content_uri`, `grant_uri_permission`, `security_scope`, or `share_docref` results; reviewed local-object transfer stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/transfer-portal-posture-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/intent-kind-registry.md`
- `docs/30-architecture/effect-contract-schema-v0.md`
- `docs/60-engineering/cli-plumbing-tooling.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_openuri_resource_grant_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable resource-grant/URI-permission/security-scope seam / local-object authority transfer stays on explicit file-document-transfer seams / grant-handoff is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-592**).

## References

- REF-XDG-PORTAL-DOCUMENTS.
- REF-ANDROID-FILEPROVIDER-SHARE-FILE.
- REF-ANDROID-PERSISTABLE-URI-PERMISSIONS.
- REF-APPLE-SECBOOKMARK.
