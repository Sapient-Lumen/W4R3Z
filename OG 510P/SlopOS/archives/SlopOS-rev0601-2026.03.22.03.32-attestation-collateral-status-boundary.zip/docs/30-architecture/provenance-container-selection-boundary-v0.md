# Provenance-container selection boundary v0 (imported multi-statement packaging stays verifier-local)

Purpose: pin the Phase-1 meaning of **imported provenance-envelope/container multiplicity** across **D-PCP**, **D-ATOMICUPD**, **D-BOOT**, and **D-SIGENV** so one exact `prov_attestation_digest` does not quietly imply a native union, preference, or completeness rule when the imported artifact happens to package multiple attestations or statements.

Entropy cost justification: the archive already pins `prov_attestation_digest` as one exact provenance evidence artifact digest, but ecosystem packaging can still group multiple attestations together. Leaving that unstated invites expensive drift later: tools start treating “the container” as “the full provenance closure”, “pick the latest statement”, or “all statements inside must be unioned”. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-UPD v0** and **CH-BOOT v0** may pin one exact `prov_attestation_digest`.
- **CH-SIGENV v0** still verifies exact envelope/payload binding for any signed statement it carries.
- **CH-PROV v0** still gives the portable meaning of one provenance statement payload.
- **Verifier-local policy** still answers which exact verified statement or statement subset, if any, is admissible for the already-pinned cohort.

## Posture (v0)

1) **One exact `prov_attestation_digest` may package many attestations; Phase 1 still imports no portable union/reconciliation rule.**
   - A carrier may pin one exact signed provenance envelope/container artifact by digest.
   - That imported artifact might hold one DSSE envelope over one **CH-PROV v0** statement, or it might package multiple attestations/statements in one bundle/container.
   - Phase 1 imports the exact bytes of that artifact, but it does **not** import a native “union all provenance statements”, “intersect all statements”, “dedupe by subject”, or “container defines complete provenance closure” rule.

2) **A multi-statement container does not define which statement is “the provenance” for CH-UPD or CH-BOOT.**
   - **CH-UPD v0** and **CH-BOOT v0** keep their already-pinned cohort meaning first.
   - If the imported artifact contains multiple provenance-relevant statements, the carrier does not thereby nominate a preferred statement, a priority order, or a completeness claim.
   - Bundle position, attachment order, statement count, or packaging convention therefore remain non-authoritative.

3) **Verifier-local policy may reject, select, or require multiple statements, but that choice stays off-carrier and non-portable.**
   - Local policy MAY reject multi-statement provenance containers entirely.
   - Local policy MAY select one verified statement, or require several verified statements, if the deployment has explicit verifier-local rules for doing so.
   - Those rules remain outside the portable meaning of `prov_attestation_digest`; carriers do not choose them, and imported packaging does not negotiate them.

4) **Extra statements in the same imported container remain extra evidence context only.**
   - Statements that do not bind the exact already-pinned staged/booted cohort remain extra evidence context, even if they ship in the same imported container.
   - Extra statements do not widen install/boot subject meaning, do not auto-satisfy stricter provenance requirements, and do not create a release-history or supersession rule.
   - Companion `update-evidence-subject-boundary-v0.md`, `provenance-required-subject-boundary-v0.md`, and `provenance-coverage-policy-boundary-v0.md` still control applicability, required subject subsets, and verifier-policy selection.

5) **DSSE envelope validity and statement subject matching stay separate checks.**
   - **PO-SIGENV-VERIFY** still answers whether a given envelope/signature binding verified under local policy.
   - **PO-PROV-BIND** still answers whether a selected **CH-PROV v0** statement actually binds the exact already-pinned carrier digests the verifier cares about.
   - Passing one check does not collapse the other, and container packaging does not fuse them into a single portable “good provenance bundle” verdict.

6) **No portable latest/preferred/completeness/supersession rule in v0.**
   - Phase 1 adds no native “latest statement wins”, “first matching statement wins”, “all statements in this container are jointly authoritative”, or “this container supersedes earlier provenance” meaning.
   - Any such reconciliation remains explicit local tooling or future RFC work.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing provenance/signature/update/boot seams interpret imported multi-statement packaging.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native provenance-container schema or portable statement-selection grammar.
- No portable union/intersection/dedup/completeness rule for multi-statement containers.
- No statement-order or bundle-membership priority semantics.
- No native supersession/history semantics derived from one container carrying many statements.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is explicitly layered but deliberately leaves policy composition to consumers:
- the in-toto attestation framework separates statement, envelope, and bundle layers, and the bundle layer is for grouping multiple attestations together;
- Sigstore bundles carrying DSSE attestations still embed one in-toto statement per DSSE envelope, yet multiple attestations may be attached to one subject artifact;
- SLSA verification guidance still tells consumers to compare the artifact and its provenance against **expectations**, not against one universal bundle-selection rule.

Pinning that split now keeps SlopOS from quietly inheriting bundle folklore where “all provenance in the container” becomes a hidden install, boot, or policy-selection language.

## Profile effect (A–D)

- **Secure workstation (A):** review bundles may carry multiple attestations without making local install/boot semantics depend on bundle ordering or attachment count.
- **Cloud micro-VM substrate (B):** fleet tooling may package several provenance statements together, but deployment verifiers stay exact and deterministic about which statements matter for one cohort.
- **Embedded / separation appliance (C):** offline verification stays small because a verifier may fail closed or select one bounded statement without importing a general bundle-reconciliation algorithm.
- **Agent/automation OS (D):** agents can reason over rich attestation packs, but they cannot smuggle “all statements in the container apply” into broader portable meaning.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-ATOMICUPD**, **D-BOOT**, **D-SIGENV**.
- Adjacent meaning pins:
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/provenance-attestation-schema-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`
  - `docs/30-architecture/provenance-required-subject-boundary-v0.md`
  - `docs/30-architecture/provenance-coverage-policy-boundary-v0.md`
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-PROV-CHAIN-1**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-SIGENV-1**.
  - **PO-PROV-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-SIGENV-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_provenance_container_selection_boundary.py` keeps the split small and discoverable (**EVID-2026-480**).

## References

- **REF-IN-TOTO-STATEMENT**
- **REF-SIGSTORE-BUNDLE**
- **REF-SLSA-VERIFYING-ARTIFACTS**
- **REF-DSSE**
