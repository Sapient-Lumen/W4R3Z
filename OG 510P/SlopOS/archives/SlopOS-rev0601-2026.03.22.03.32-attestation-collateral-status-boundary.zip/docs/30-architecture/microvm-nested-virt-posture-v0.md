# MicroVM nested-virtualization posture v0 (guest hypervisor capability stays non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible nested-virtualization exposure under `ext.microvm` so VMX/SVM-style hardware-virtualization bits, guest-hypervisor acceleration, and nested-specific assist folklore do not quietly become a reviewed compatibility or control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-FCELL** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible nested-virtualization contract under `ext.microvm`; there is no portable VMX / SVM / guest-hypervisor-acceleration plane, no portable nested-specific enlightenment-or-assist plane, owner-local nested enablement and CPU-feature passthrough stay implementation-local, and reviewed compatibility / isolation meaning stays on explicit D-FCELL and activation seams rather than ambient guest hypervisor capability.**

Entropy cost justification: the archive already pins guest-visible CPU topology, platform identity, paravirtual enlightenments, live migration, and the sealed-compat boundary separately. What remained underspecified was the tempting middle ground where a cloud-oriented microVM runtime exposes hardware virtualization bits to the guest and that somehow turns into a portable promise that “this leaf can be a hypervisor too.” Real ecosystems treat nested virtualization as explicit host-kernel and VMM configuration, frequently with nested-specific enlightenments and version-sensitive behavior. One narrow posture closes that gap without inventing a guest `/dev/kvm` API, a nested-VM workflow surface, or a new schema family.

## Posture (v0)

1) **No portable ambient guest-visible nested-virtualization contract**
   - **Phase 1 exposes no portable ambient guest-visible nested-virtualization contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable hardware-virtualization feature plane, may reliably run as a guest hypervisor, or may expect one stable accelerated L2 contract because it is virtualized.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those mechanisms do **not** become SlopOS portable API meaning.

2) **No portable VMX / SVM / guest-hypervisor-acceleration plane**
   - There is **no portable VMX / SVM / guest-hypervisor-acceleration plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest-visible promise for VMX/SVM enablement, host-passthrough CPU models, nested acceleration, nested VMCS/VMCB behavior, L1→L2 performance characteristics, or nested-live-migration viability.
   - Owner-local host-kernel `nested` settings, VMM CPU-model choices, and hardware-virtualization feature passthrough remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable nested-specific enlightenment-or-assist plane**
   - There is **no portable nested-specific enlightenment-or-assist plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `hv-evmcs` / `hv-emsr-bitmap` / nested-TLB-flush assist vocabulary, one standard nested-hypervisor optimization set, or one portable requirement that the guest receives nested-specific vendor assists when it tries to act as an L1 hypervisor.
   - Nested-specific hypervisor assists remain owner-local runtime choices and must not silently become portable SlopOS time, interrupt, migration, or performance semantics.

4) **D-FCELL and activation remain authoritative for compatibility and lifecycle meaning**
   - D-FCELL and activation remain authoritative for compatibility and lifecycle meaning.
   - A guest-visible nested-virtualization capability does **not** relax the Phase 1 rule that foreign/legacy compatibility is explicit, membrane-bound, and killable by policy rather than ambient because the guest can itself start more VMs.
   - Likewise, portable lifecycle meaning still rides on explicit admission / activation / snapshot seams rather than on folklore such as “the L1 can always boot or migrate its own L2 fleet under the same reviewed identity.”

5) **Changing the nested-virt stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the nested-virt stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares whether a reviewed leaf may act as a guest hypervisor, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `enable_nested`, `set_cpu_vmx`, or `grant_guest_hypervisor_mode` control plane by convention.
   - This keeps nested-virt meaning on explicit activation / compatibility seams rather than on ambient CPU-feature folklore.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_nested_virtualization`, `pass_guest_vmx_svm`, or `export_nested_hypervisor_assists` must say whether it commutes with activation, snapshot capture, migration, attestation, and sealed-compat policy, and where serialization lives.
   - Until then, nested virtualization remains owner-local runtime/guest convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable VMX / SVM / guest-hypervisor-acceleration contract under `ext.microvm`.
- No portable nested-specific enlightenment / assist / performance-tuning contract under `ext.microvm`.
- No portable promise that a reviewed leaf can host its own KVM / Hyper-V / other L2 stack.
- No portable guest-visible nested-migration / nested-snapshot / nested-debug capability contract.
- No claim that nested virtualization is the Phase 1 compatibility story; sealed compat remains explicit and killable by policy.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-FCELL)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-paravirt-enlightenment-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Compatibility posture:
  - `foreign-cell-contract.md`
  - `rumpk-selection-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-47)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-NESTEDVIRT)
- Policy posture:
  - guest-visible nested virtualization adds **no new lane**, **no portable live enable/disable plane**, and **no portable compatibility-by-nesting contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_nested_virt_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable nested-virtualization / no portable VMX-SVM-guest-hypervisor-acceleration plane / no portable nested-specific enlightenment-or-assist plane / owner-local nested enablement and CPU-feature passthrough stay implementation-local / D-FCELL and activation remain authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-KVM-NESTED-GUESTS.
- REF-KVM-NESTED-VMX.
- REF-CHYP-CPU.
- REF-QEMU-HYPERV-ENLIGHTENMENTS.
