# Deny code registry (v0)

Purpose: keep validator denial codes **closed, stable, and reviewable**.

Rationale:
- Denials are a frequent drift seam: “why did it deny?” becomes ad-hoc strings.
- Our stable product surface is **schemas + validators + receipts**. Denials must be receipt-shaped.
- A closed, central registry makes deny semantics composable across profiles (A–D) without forks.

This registry is the source of truth for CH-DENY `deny_code` values.

Where other bounded receipt artifacts need stable denial tokens (e.g., **CH-FADAPT** `result.reason`), they MUST reuse this same closed set (one token vocabulary, no forks).
Validators MUST reject unknown deny codes (fail closed). See `denial-receipt-schema-v0.md`.

## Deny codes

| `deny_code` | Class | Deterministic source | Recommended `reason.kind` | Required binding (if applicable) | Notes |
|---|---|---|---|---|---|
| `invalid-schema` | schema | schema/canonicalization | `schema` | `reason.ref_schema` MAY be set | action failed schema or canonicalization checks (reject-by-default)
| `unknown-kind` | schema | registry closure | `schema` | `reason.ref_schema` SHOULD be set to `CH-ACP v0` | action kind not in the closed kind registry (`acp-action-kind-registry.md`)
| `missing-approval` | authority | cap binding policy | `policy` | `reason.ref_digest` MUST be present = `digest(CH-POLICY v0)` or `digest(CH-POLICYHANDLE v0)` | missing required CH-AUTHZ/cap binding
| `expired-approval` | authority | time/TTL policy | `policy` | `reason.ref_digest` MUST be present = `digest(CH-POLICY v0)` or `digest(CH-POLICYHANDLE v0)` | approval/cap binding expired (when enabled)
| `policy-deny` | policy | veto-only policy | `policy` | `reason.ref_digest` MUST be present = `digest(CH-POLICY v0)` or `digest(CH-POLICYHANDLE v0)` | policy veto denied the action (D-POLICY)
| `lane-disabled` | policy | lane gate | `lane` | `reason.ref_key = <cfg.params.* key>` | config lane gate disabled the kind/effect family (CH-CFG)
| `cfg-deny` | policy | cfg param gate | `lane` | `reason.ref_key = <cfg.params.* key>` | config parameter veto denied the action (non-authoritative narrowing; used for workflow hardening knobs like `cfg.params.capshell.minimal_context`)
| `effcon-violation` | workflow | effect-contract gate | `effcon` | `reason.ref_digest = digest(CH-EFFCON v0)` | workflow runner attempted an undeclared/forbidden effect family
| `execpack-missing` | workflow | exec-pack completeness gate | `schema` | `reason.ref_schema` SHOULD be set to `"CH-EXECPACK v2"` | `capshell.exec` missing required `exec_pack_digest` (prevents ambient context by omission; D-CAPSHELL)
| `plumbmsg-missing` | workflow | intent-envelope gate | `schema` | `reason.ref_schema` SHOULD be set to "CH-PLUMBMSG v0" | required workflow intent envelope missing when `cfg.params.capshell.require_plumbmsg=true` (prevents ambient/prose-only intent channels; D-CAPSHELL/D-PLUMB)
| `reqctx-mismatch` | workflow | request-context binding | `reqctx` | `reason.ref_schema = "CH-REQCTX v1"` and `reason.ref_digest = meta.reqctx_digest` | request context digests disagree across a required binding (e.g., CH-ACP `meta.reqctx_digest` vs CH-EXECPACK v2 `reqctx_digest`); fail closed (veto-only)
| `precondition-failed` | workflow | exact precondition witness gate | `schema` | `reason.ref_digest` SHOULD be present when a rejecting witness digest exists | CH-ACP `preconditions` could not be satisfied from explicit local witness material, or the witness no longer matched; no ambient `latest`/query fallback. For the current ACP overlap with live authority gates, this code is lower precedence than `lane-disabled` / `cfg-deny` / `missing-approval` / `expired-approval` / `policy-deny` (`acp-denial-precedence-posture-v0.md`). |
| `argv-bind-failed` | workflow | argv/binding gate | `schema` | `reason.ref_schema = "CH-ARGV v0"` and `reason.ref_digest = digest(CH-ARGV v0)` | typed argv token list invalid/unavailable/unbindable in the execution context (D-CAPSHELL)
| `env-bind-failed` | workflow | env/binding gate | `schema` | `reason.ref_schema = "CH-ENV v0"` and `reason.ref_digest = digest(CH-ENV v0)` | typed environment token list invalid/unavailable/unbindable in the execution context (D-CAPSHELL)
| `env-name-forbidden` | workflow | env startup/resolution gate | `schema` | `reason.ref_schema = "CH-ENV v0"` and `reason.ref_digest = digest(CH-ENV v0)` | CH-ENV contains a Phase 1 forbidden startup/resolution hook name or prefix (`PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, `BASH_FUNC_*`) and validation fails closed rather than silently scrubbing (D-CAPSHELL)
| `cwd-bind-failed` | workflow | cwd/binding gate | `schema` | `reason.ref_schema = "CH-CWD v0"` and `reason.ref_digest = digest(CH-CWD v0)` | typed working-directory selector invalid/unavailable/unbindable in the execution context (D-CAPSHELL)
| `stdio-bind-failed` | workflow | stdio/binding gate | `schema` | `reason.ref_schema = "CH-STDIO v0"` and `reason.ref_digest = digest(CH-STDIO v0)` | typed stdio bindings invalid/unavailable/unbindable in the execution context (D-CAPSHELL) |
| `fd-bind-failed` | workflow | fdset/binding gate | `schema` | `reason.ref_schema = "CH-FDSET v0"` and `reason.ref_digest = digest(CH-FDSET v0)` | typed extra descriptor bindings invalid/unavailable/unbindable in the execution context or ambient extra handles detected (D-CAPSHELL) |
| `conflict-key-invalid` | ordering | conflict-key derivation | `ordering` | `conflict_key_digest` MUST be present (rejecting digest; for CH-ACP, set to `meta.conflict_key_digest`) | derivation failed or mismatched the validator’s canonical derivation
| `order-witness-missing` | ordering | kind stance | `ordering` | `conflict_key_digest` MUST be present; `reason.ref_schema` SHOULD be set to `CH-ACP v0` | ordered kind missing required ordering witness
| `order-witness-invalid` | ordering | witness verification | `ordering` | `order_digest` MUST be present; `conflict_key_digest` SHOULD be present | witness invalid/mismatched/expired
| `budget-missing` | resource | meter/budget | `reqctx` | `reason.ref_schema = "CH-REQCTX v1"` and `reason.ref_digest = meta.reqctx_digest` | required budget lease missing (when D-BUDGET is enabled and the interface requires explicit payer/budget) |
| `budget-exhausted` | resource | meter/budget | `budget` | `reason.ref_digest = digest(CH-BUDGET v0)` (or profile handle) | budget/fuel exhausted (when enabled)
| `internal-error` | safety | deterministic catch-all | `none` | none | deterministic “catch-all” (should be rare; treated as deny)

## Notes

- The registry is intentionally minimal. If you want a new deny code:
  1) add it here with a crisp deterministic source, and
  2) wire it into invariants/POs/evidence hooks.
- Deny codes do **not** grant authority; they only explain why an effect was rejected.
- For the current ACP overlap between lane/policy/approval gates and exact witness drift, producer precedence is pinned in `acp-denial-precedence-posture-v0.md` so the winning `deny_code` is not an implementation-order accident.

CI drift gates:
- `tools/check_deny_code_refs.py` enforces that any explicitly named `deny_code` token in repo markdown resolves to this registry (prevents denial vocabulary drift).
