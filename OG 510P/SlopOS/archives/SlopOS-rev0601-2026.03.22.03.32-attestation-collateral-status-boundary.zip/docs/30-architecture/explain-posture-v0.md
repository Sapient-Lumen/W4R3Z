# D-EXPLAIN posture v0 (canonical shell-owned diffs; non-authoritative receipts; no generic receipt ledger)

Purpose: pin an **implementable Phase 1** meaning for **D-EXPLAIN** so authority diffs and
consent receipts stay a small **canonical explanation seam** instead of drifting into a
requester-authored prompt surface, a reusable permission store, or a generic receipt-history/admin
plane.

This posture deliberately narrows the seam: **CH-CAPDIFF v0** is the canonical shell/provider-owned
summary object for “what authority changes,” **CH-RECEIPT v0** is durable **non-authoritative**
evidence of what was asked/shown/approved/executed, and any richer history/export/notarization UX
must stay on explicit observation/tooling adjuncts rather than becoming portable approval state.

## Posture (v0)

1) **Canonical shell-owned summaries/diffs, not requester-authored prompts**
   - If **D-EXPLAIN** is enabled, the bound consent summary/diff is a deterministic function of canonical action bytes plus the relevant policy/state.
   - **CH-CAPDIFF v0** is the preferred typed summary object for authority-widening prompts and receipts.
   - Requester prose, locale hints, and UI decoration may help humans, but they do **not** define the bound summary and may not affect `summary_digest`.
   - This is the operational meaning of **I-EXPLAIN-1** and **I-CONSENT-1**, evidenced via **PO-EXPLAIN-SUMMARY**.

2) **Receipts are durable evidence, not approvals or reusable grants**
   - **CH-RECEIPT v0** records what action was requested, what canonical summary was shown, which approval evidence existed (for example **CH-AUTHZ v0** and optional **CH-VOL v0**), and what result occurred.
   - Receipts remain **non-authoritative**: they do not replay as approvals, do not resurrect handles/leases, and do not substitute for fresh consent.
- If a consequential action is initiated or summarized from a transient attention surface, the durable truth still lives on the explicit receipt/state surfaces rather than on whether a toast/banner/notification happened to render (see `attention-durable-status-boundary-v0.md`).
   - This is the operational meaning of **I-EXPLAIN-2** and **I-EXPLAIN-3**, evidenced via **PO-EXPLAIN-RECEIPT-BIND** and **PO-EXPLAIN-NONAUTH**.

3) **Diffs and receipts stay bounded, redacted, and digest-first**
   - **CH-CAPDIFF v0** and **CH-RECEIPT v0** must remain small enough for routine UI/log/export use and must follow the same redaction discipline as other observation artifacts.
   - Phase 1 declines raw capability material, raw pointers, stable kernel object ids, or app-controlled arbitrary blobs in either structure.
   - Optional fields such as `resource_hint`, `locale_hint`, `rationale.hint`, `conflict_key_digest`, and `order_digest` are observability metadata only; they must never become a second authority channel.
   - This is the operational meaning of **I-EXPLAIN-4** and **I-OBS-1**, evidenced via **PO-CAPDIFF-REDACT**.

4) **Approvals stay action-bound; widening or re-rendering requires a fresh explanation path**
   - A receipt/diff binds **one exact action digest** and **one exact summary digest**.
   - If the action widens, the rendered summary changes, or the provider/validator rewrites the actual effect set, the old explanation no longer applies and fresh approval/volition must be obtained where policy requires it.
   - Phase 1 therefore declines wildcard/batch approval reuse, “approve this class of future requests,” and silent summary substitution under the D-EXPLAIN seam.

5) **No generic receipt ledger, list/watch API, or permission-store/admin plane in v0**
   - Shells/providers MAY keep local history or present local viewers, but **D-EXPLAIN itself** does **not** standardize a portable receipt ledger, receipt list/watch API, approval inventory, or grant-management control plane.
   - Family-specific continuity (for example document reopen) stays on its own descriptor seam; D-EXPLAIN does not become the generic place where durable approvals live.
   - Phase 1 therefore declines “always allow” caches, app-queryable permission history, and generic receipt sync semantics on the core explainability seam.

6) **Conflict/order/deny metadata stays adjunct evidence only**
   - When **D-COMMUTE** metadata is in scope, `conflict_key_digest` and `order_digest` in **CH-RECEIPT v0** stay **non-authoritative** observability fields.
   - If validator-facing rejection evidence is emitted as **CH-DENY v0**, it remains a deterministic denial artifact bound from **CH-LOG**; it is not an approval token, retry token, or receipt-admin surface.
   - Phase 1 adds no new portable conflict-key family, ordering stream, or denial-inbox control plane for D-EXPLAIN itself.

7) **Export/interop is explicit and policy-killable**
   - Exporting diffs/receipts is an observation/tooling workflow subject to existing observation/export policy and replication boundaries.
   - Portable semantics stop at canonical bounded artifacts plus digests; any signatures, notarization, transparency logging, or external compliance packaging are optional adjunct tooling layers rather than core approval semantics.
   - Cross-host receipt arrival may support audit/explanation, but it must not satisfy local consent or skip a fresh portal/consent path.

8) **Sealed compat stays honest**
   - Foreign Cells and legacy shims may participate in consent flows only through explicit **IF-CONSENT** / portal mediation.
   - They gain no hidden prompt surface, approval-cache query API, or receipt replay loophole by virtue of compatibility.
   - Policy must be able to kill the interop path without breaking the honesty of D-EXPLAIN itself.

## Phase 1 non-goals (explicitly deferred)

- No requester-authored free-form summary text as the bound consent object.
- No replay/import of **CH-RECEIPT v0** or **CH-CAPDIFF v0** as approval or capability material.
- No generic receipt ledger / list / watch / sync / admin plane on D-EXPLAIN itself.
- No wildcard or batch approval-cache semantics on the D-EXPLAIN seam.
- No mandatory remote notarization, signature, or transparency-log protocol in the portable Phase 1 posture.

## Wiring

- Decision surface:
  - `decision-map.md` → **D-EXPLAIN**.
- Core schemas / interfaces:
  - `capability-diff-schema-v0.md` (**CH-CAPDIFF v0**).
  - `consent-receipt-schema-v0.md` (**CH-RECEIPT v0**).
  - `authorization-token-schema-v0.md` (**CH-AUTHZ v0**).
  - `volition-token-schema-v0.md` (**CH-VOL v0**).
  - `denial-receipt-schema-v0.md` (**CH-DENY v0**).
  - `interface-registry.md` (**IF-CONSENT**).
- Adjacent postures / boundaries:
  - `powerbox-posture-v0.md`.
  - `volition-posture-v0.md`.
  - `observation-export-posture-v0.md`.
  - `receipt-replication-boundary-v0.md`.
- Assurance hooks:
  - Invariants: **I-EXPLAIN-1**, **I-EXPLAIN-2**, **I-EXPLAIN-3**, **I-EXPLAIN-4**, **I-CONSENT-1**, **I-OBS-1**.
  - Proof obligations: **PO-EXPLAIN-SUMMARY**, **PO-EXPLAIN-RECEIPT-BIND**, **PO-EXPLAIN-NONAUTH**, **PO-CAPDIFF-REDACT**.
- Discovery / amnesia-resistor surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/resolved-history.md`.
- CI drift gate: `tools/check_explain_posture.py` (**EVID-2026-354**).

## References

- REF-UDAC-SP12
- REF-YEE-UIDSS-2002
- REF-KANTARA-CONSENT-RECEIPT
- REF-ISO27560-DPV-GUIDE
- REF-SANDSTORM-POWERBOX
- REF-PLASH-POWERBOX
- REF-XDG-PORTAL
