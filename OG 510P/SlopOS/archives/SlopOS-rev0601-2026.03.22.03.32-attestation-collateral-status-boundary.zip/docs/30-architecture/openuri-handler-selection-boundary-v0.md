# D-PLUMB OpenURI handler-selection boundary v0 (no requester-visible chooser or target control)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: concrete handler choice, chooser/default behavior, and disclosure of which handler was selected stay **shell/policy-owned routing state**, not a portable requester-visible control or receipt surface.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, and no new ACP or conflict-key family. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **Requesters express the action + subject, not an exact handler identity.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - The requester does **not** name the exact app/package/bundle/desktop file/handler identity that must run.
   - Concrete handler choice remains local portal/shell policy under `svc:portal.uri`.

2) **No requester-visible chooser forcing or suppression in v0.**
   - Phase 1 does **not** export a portable `ask=true`, `force_chooser`, `skip_chooser`, `use_default`, or `open_with(app)` control surface.
   - A backend may internally remember defaults or present disambiguation UI, but that stays shell-owned behavior rather than requester-owned authority.
   - Any profile-specific chooser UX remains local policy, not transcript-stable requester semantics.

3) **No selected-handler identity, chooser transcript, or default-state receipt in v0.**
   - Requesters do **not** learn which concrete handler was chosen, whether chooser UI appeared, or which default-rule/path caused the final routing decision.
   - Phase 1 therefore declines chooser transcripts, selected-handler receipts, handler IDs, and default-state inspection APIs.
   - The portable requester truth remains the explicit mediated request outcome only.

4) **Why this cut is honest.**
   - Current xdg-desktop-portal OpenURI docs expose an `ask` option and allow a default or last choice to be reused.
   - Android also exposes chooser forcing (`Intent.createChooser`) and default/disambiguation behavior.
   - Those are real platform features, but importing them directly would widen `portal.uri.*` from mediated launch into a handler-selection/admin surface and a stable installed-app side channel.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; shell-visible chooser/default state and launch order serialize there.
   - Phase 1 adds **no new ACP kind** and **no new conflict-key family** for handler selection because portable requesters do not control or observe that state directly.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient `open with app X`, package-manager app selection, or chooser-control knobs through host helpers.
   - If compat wants link/item opening, it still goes through `portal.uri.*` or fails closed.

## Phase 1 non-goals (explicitly deferred)

- No portable `open_with(app)` / app-targeted launch control.
- No requester-visible `ask` / chooser/default forcing or suppression surface.
- No selected-handler identity / chooser transcript / default-state receipt.
- No ACP/admin/query surface for handler-choice policy.
- No hidden helper fallback that lets apps pick a host handler out-of-band.

## Why this is worth pinning

Once OpenURI exists, the next obvious convenience import is not just “can something open this?” but “which app should open this, and can I force the chooser?” Current xdg-desktop-portal docs already expose an `ask` option, while Android explicitly documents chooser forcing and default/disambiguation behavior. Those features are useful on their home platforms, but in SlopOS they would widen a small mediated-launch seam into portable handler-selection authority and a transcript-stable disclosure surface. Pinning the boundary now keeps concrete routing shell-owned while preserving the archive’s no-inventory / no-ambient-discovery posture.

## Profile effect (A–D)

- **Secure workstation (A):** workstation UX may still present chooser/default behavior, but apps and agents do not gain a stable installed-handler or chosen-handler oracle.
- **Cloud micro-VM substrate (B):** guest/tenant tooling can request mediated launch where allowed without learning host-side handler topology or steering concrete target choice.
- **Embedded / separation appliance (C):** deployments that ship exactly one narrow viewer/launcher avoid carrying fake chooser semantics just because richer desktops expose them.
- **Agent/automation OS (D):** LLM/tooling can propose the actual mediated action, but cannot branch on a hidden “open with this app” control plane or record chooser transcripts as durable truth.

## Wiring

- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Primary posture:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
- Decision surface:
  - `docs/30-architecture/decision-map.md` (D-PLUMB)
- Control surfaces:
  - `docs/30-architecture/portal-family-registry.md` (`portal.uri.*`)
  - `docs/30-architecture/effect-contract-schema-v0.md` (`portal.uri`)
  - `docs/30-architecture/intent-kind-registry.md` (`open_uri`)
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-OPENURI-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-OPENURI-ENF)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_handler_selection_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **action+subject-only / no requester-visible chooser control / no selected-handler receipt / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-573**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-PACKAGE-VISIBILITY.
- REF-ANDROID-CREATECHOOSER.
