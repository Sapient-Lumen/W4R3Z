# MicroVM platform-identity posture v0 (no portable ambient guest-visible platform identity / fingerprinting contract)

Purpose: pin the **Phase 1** meaning of guest-visible platform identity and fingerprinting under `ext.microvm` so CPUID branding/hypervisor signatures, SMBIOS/DMI serials and UUIDs, and OEM-string folklore do not quietly become a reviewed provenance, policy, or bootstrap surface.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ATTEST**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible platform identity / fingerprinting contract under `ext.microvm`; there is no portable CPUID-vendor-brand-hypervisor-signature plane, no portable SMBIOS-DMI-manufacturer-product-serial-uuid-OEM-string identity plane, owner-local branding and feature-masking stay implementation-local, and provenance/attestation meaning still rides on explicit D-ATTEST plus deployment evidence rather than ambient guest probes.**

Entropy cost justification: the archive already pins guest-visible CPU/RAM/NIC/block/bus shape, keeps bootstrap metadata out of the portable microVM contract, and keeps attestation meaning on explicit evidence seams. What remained underspecified was the platform-branding convenience layer where VMMs can rewrite CPUID leaves, set SMBIOS serial numbers and UUIDs, or inject OEM strings that guest software then treats as authoritative identity. One narrow posture closes that gap without inventing a new identity agent, provisioning protocol, or schema family.

## Posture (v0)

1) **No portable ambient guest-visible platform identity / fingerprinting contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible platform identity / fingerprinting contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard vendor string, product name, serial number, UUID, or hypervisor fingerprint that guest code may treat as authoritative identity.”
   - In plain terms: the reviewed contract is not “probe CPUID, SMBIOS, or DMI and learn the authoritative platform/provider identity of this reviewed leaf.”

2) **No portable CPUID-vendor-brand-hypervisor-signature plane**
   - Phase 1 standardizes **no portable CPUID-vendor-brand-hypervisor-signature plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about vendor IDs, brand strings, hypervisor-present signaling, hypervisor signature leaves, or other fingerprint-style CPUID/MSR shaping beyond the already-pinned guest CPU topology and resume-class postures.
   - Implementations may locally pass through, normalize, or mask CPUID leaves and related registers to support heterogeneous fleets, migration classes, or guest compatibility, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed SlopOS identity meaning.

3) **No portable SMBIOS-DMI-manufacturer-product-serial-uuid-OEM-string identity plane**
   - Phase 1 standardizes **no portable SMBIOS-DMI-manufacturer-product-serial-uuid-OEM-string identity plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about system manufacturer/product/family strings, board or chassis serial numbers, system UUIDs, SKU strings, or OEM-string payloads discovered through DMI/SMBIOS.
   - Implementations may locally set or omit SMBIOS tables, UUIDs, serial numbers, and OEM strings for one deployment class, but those choices remain implementation-local and must not silently become portable product identity, provenance, or bootstrap meaning.

4) **Owner-local branding, feature masking, and fleet normalization stay implementation-local**
   - Owner-local branding, feature masking, and fleet normalization stay implementation-local.
   - Runtimes may choose CPU templates, CPUID normalization, DMI serial/UUID fields, OEM strings, and other branding/fingerprint controls to keep one fleet operationally coherent, but that does **not** create a portable reviewed promise about one stable provider identity, one exact CPU fingerprint, or one guest-visible instance-identity vocabulary.
   - In particular, host vendor/model strings, hypervisor signatures, SMBIOS manufacturer/product naming, serial numbers, UUIDs, and OEM-string conventions remain host/runtime-local mechanism, not portable SlopOS interface meaning.

5) **Provenance and attestation meaning stay on explicit evidence seams**
   - Provenance and attestation meaning stay on explicit evidence seams.
   - Freshness, boot lineage, deployment identity, measured-boot claims, and key-release policy continue to ride on already-pinned `CH-ATTEST`, `CH-ATTESTPACK`, `CH-BOOT`, deployment receipts, and related evidence rather than ambient guest CPUID / DMI / SMBIOS probes.
   - Guest-observed platform strings may help one implementation with compatibility or telemetry, but they do **not** become the portable authority seam for identity, attestation, trust decisions, or policy routing.

6) **Changing the platform-identity stance is owner-local lifecycle or new admission, not a portable live retag plane**
   - Changing the platform-identity stance is owner-local lifecycle or new admission, not a portable live retag plane.
   - Owners/runtimes may choose different local branding/fingerprint configurations for different reviewed leaves or deployment classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable guest identity/branding protocol under the same admitted identity.
   - If policy cares about a different guest-visible identity stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable identity plane by convention.

7) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest identity/fingerprint state, **no new ACP kind**, and **no new conflict-key family** for CPUID retagging, UUID/serial mutation, SMBIOS field injection, or OEM-string updates under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `query_guest_identity`, `set_guest_uuid`, `set_oem_string`, `set_cpuid_profile`, or `rotate_instance_serial`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable provider-instance-id, guest serial-number, or guest UUID contract under `ext.microvm`.
- No portable CPUID vendor/brand/hypervisor-signature or DMI manufacturer/product/OEM-string vocabulary as reviewed SlopOS identity meaning.
- No generic guest-branding agent, metadata bridge, or provisioning API for changing platform identity in place.
- No claim that guest-observed platform strings are an attestation substitute or policy-proof artifact.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ATTEST, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `attestation-posture-v0.md`
- Adjacent notes:
  - `microvm-bootstrap-metadata-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-bus-topology-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-27)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-IDENTITYSURFACE)
- Policy posture:
  - platform identity/fingerprinting adds **no new lane**, **no public guest identity control plane**, and **no portable in-place retag protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_platform_identity_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible platform identity / fingerprinting contract / no portable CPUID-vendor-brand-hypervisor-signature plane / no portable SMBIOS-DMI-manufacturer-product-serial-uuid-OEM-string identity plane / owner-local branding and feature-masking stay implementation-local / provenance and attestation meaning stay on explicit evidence seams / changing platform-identity stance is owner-local lifecycle or new admission not a portable live retag plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-KVM-CPUID-API.
- REF-FIRECRACKER-CPUID-NORMALIZATION.
- REF-QEMU-SMBIOS-UUID.
- REF-CHYP-PLATFORM.
