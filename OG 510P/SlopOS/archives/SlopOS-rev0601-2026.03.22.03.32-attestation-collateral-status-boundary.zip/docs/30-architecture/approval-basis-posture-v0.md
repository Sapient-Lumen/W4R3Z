# Approval-basis posture v0 (exact mutable basis; no sticky head-following approvals)

Purpose: pin one compact Phase 1 rule that sits **between** CH-ACP `preconditions`, CH-VOL, CH-AUTHZ, and CH-RECEIPT: when a human-facing approval or validator acceptance depends on a **mutable local basis** (current head, current queue entry, current revision/epoch, current designated descriptor, or similar), that basis must already be encoded into the exact action bytes rather than being left ambient.

This doc is intentionally narrow. It does **not** create a reusable review-cache object, a generic `latest approved basis` registry, a PR/work-queue subsystem, or a second policy language under IF-CONSENT / IF-ACP.

## Posture (v0)

1) **Approval evidence binds one exact action, not a floating mutable target**
   - CH-AUTHZ and CH-VOL bind one exact `action_digest`; CH-RECEIPT records the resulting allow/deny path for that same exact action.
   - None of those surfaces quietly mean “approve whatever the current head/revision/queue item is when execution finally happens.”
   - If the mutable basis matters, it must already be reflected in the action bytes that were reviewed.

2) **Mutable basis must be encoded as exact witness material**
   - The admitted Phase 1 pattern is to bind the mutable basis through explicit, local, mechanically-checkable witness material already allowed by `acp-precondition-witness-posture-v0.md`: exact digests, typed local ids, or explicit revision/epoch counters.
   - In practice, a consent/ACP flow that depends on “the reviewed basis still matches” should place that dependence in CH-ACP `preconditions` (or an equivalent exact typed field on the action surface), so the `action_digest` changes if the reviewed basis changes.
   - Ambient `latest`, `current`, `head now`, `whatever is in the queue`, remote lookups, and mutable document/forum status do **not** count as approval basis.

3) **No sticky approval across mutable-basis drift**
   - If the bound mutable basis no longer matches at validation/execution time, the old approval does not silently follow the newer basis.
   - The validator fails closed (recommended CH-DENY: `precondition-failed`), and any subsequent attempt on the newer basis requires a freshly reviewed action and, when policy requires it, a fresh CH-VOL / CH-AUTHZ pair.
   - Phase 1 explicitly rejects silent inheritance such as “the earlier reviewed basis was close enough, so keep the approval live.”

4) **Consent UI and receipts stay basis-honest**
   - Consent UI may summarize the mutable basis the user reviewed, but that summary stays honest only if the same exact basis is reflected in the action bytes that the UI/validator bind.
   - CH-RECEIPT may record that a stale-basis attempt denied, but the receipt does not preserve or resurrect approval on a newer basis.
   - “The user approved this target once” is not a portable permission cache.

5) **No separate head-tracking approval plane in Phase 1**
   - The archive does not add a generic approval-side `reviewed_head`, `approved_basis`, `latest_approved_revision`, or similar mutable follow-the-head register.
   - If future products need a richer compare-and-set or reusable reviewed-basis object, that returns as its own RFC-first seam rather than widening CH-VOL / CH-AUTHZ in place.

## Phase 1 non-goals (explicitly deferred)

- A reusable reviewed-basis artifact or approval-cache object.
- Approval semantics that silently survive mutable local-basis drift.
- A hidden compare-and-set query language inside IF-CONSENT or IF-ACP.
- Any generic “latest approved head/current approved revision” registry.

## Wiring

- Action-side exact basis guard: `acp-precondition-witness-posture-v0.md`, `../70-llm-control/acp-action-schema-v0.md`, `../70-llm-control/acp-validator-semantics.md`.
- Approval / consent artifacts: `authorization-token-schema-v0.md`, `volition-token-schema-v0.md`, `consent-receipt-schema-v0.md`.
- Adjacent trusted-UI family discovery: `trusted-ui-adjunct-index.md`, `volition-posture-v0.md`, `powerbox-posture-v0.md`.
- Decision wiring: `decision-map.md` (`D-VOLITION`, `D-POWERBOX`).
- Assurance surfaces: `docs/20-assurance/invariant-registry.md` (I-AUTHZ-1, I-AUTHZ-2, I-CONSENT-1, I-VOLITION-1, I-VOLITION-2), `docs/20-assurance/proof-obligation-registry.md` (PO-ACT-BIND, PO-ACT-BASIS, PO-CONSENT-VALIDATE, PO-VOL-VALIDATE).

CI drift gate:
- `tools/check_approval_basis_posture.py` (EVID-2026-556).

## References

- REF-CEDAR.
- REF-WEBAUTHN-3.
- `acp-precondition-witness-posture-v0.md`
- `../70-llm-control/acp-action-schema-v0.md`
- `../70-llm-control/acp-validator-semantics.md`
- `authorization-token-schema-v0.md`
- `volition-token-schema-v0.md`
- `consent-receipt-schema-v0.md`
- `volition-posture-v0.md`
- `powerbox-posture-v0.md`
