# CH-CLOCK v0: clock handle/lease descriptor (schema)

Purpose: describe a *time source* capability in a redaction-safe, audit-friendly way.
Rule: the schema is closed and canonically encoded (I-ENC-1).

This schema describes a **handle** (or lease) issued by a time portal/host.
The handle itself is a capability; the descriptor is what gets logged/exported.

## Canonical encoding
- Canonical CBOR with sorted keys and deterministic number/string forms (see `encoding-policy.md`).

## Schema (v0)
Top-level object:
- `v`: integer, must be `0`
- `kind`: string enum
  - `monotonic_coarse`
  - `monotonic_fine`
  - `realtime`
- `resolution_ns`: u64 (nominal granularity)
- `rate_limit_hz`: u32 (optional; 0 means “unspecified/no limit”)
- `adjustable`: bool (true only for clocks that may jump; typically `realtime`)
- `replayable`: bool (true when this handle is intended to be fed from CH-RR `time_tick` events in replay mode)
- `notes`: string (optional; bounded; must not include secrets)

## Validation rules (informal)
- Reject unknown keys and unknown enum variants.
- `resolution_ns > 0`.
- `monotonic_*` implies `adjustable=false`.
- Policies may require `monotonic_coarse` as the default handle for untrusted components.
- `kind="realtime"` is observational/application-facing; `security-time-posture-v0.md` defines the separate D-TIME meaning used for expiry/anti-rollback.

## Example
```json
{
  "v": 0,
  "kind": "monotonic_coarse",
  "resolution_ns": 1000000,
  "rate_limit_hz": 1000,
  "adjustable": false,
  "replayable": true,
  "notes": "default coarse clock for sandboxed components"
}
```
