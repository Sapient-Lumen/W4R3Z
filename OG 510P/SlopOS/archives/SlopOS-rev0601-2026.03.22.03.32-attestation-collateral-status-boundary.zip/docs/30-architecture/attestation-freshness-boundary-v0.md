# Attestation freshness boundary v0 (verifier-local challenge semantics only; no portable currentness/session plane)

Purpose: pin the Phase-1 meaning of **attestation freshness, nonce, and challenge binding** across **D-ATTEST**, **D-NETLEASE**, and **D-TIMEPROOF** so the archive does not quietly overload exported evidence into a portable currentness oracle, nonce-service plane, or session-continuity shortcut.

Entropy cost justification: `attestation-posture-v0.md` already says freshness is explicit/optional and `attestation-endorsement-boundary-v0.md` already keeps endorsements/reference values verifier-local. The remaining ambiguity is narrower and still expensive: **what nonce/challenge/freshness fields are allowed to mean once a token or provider-native report is exported**. One small boundary closes that gap without adding a new schema family, verifier protocol, or nonce-issuance service.

This doc is a **family member of the closed D-ATTEST companion boundary family** rooted at `attestation-boundary-index.md`.

## Posture (v0)

1) **Freshness is verifier-local policy over exact evidence, not an ambient currentness claim.**
   - Exported tokens may carry nonce/challenge/freshness bindings, but those bytes only become meaningful under explicit verifier-local policy over the exact token/report bytes presented.
   - No field in `CH-ATTEST` or `CH-ATTESTPACK` by itself means “this attestation is current now” or “this session is still fresh”.

2) **the challenge/nonce stays an explicit verifier-provided input bound exactly into the attestation evidence.**
   - If freshness is claimed, the challenge/nonce is an explicit verifier input whose exact bytes must be bound into the attestation evidence.
   - Exported evidence does not create a native challenge broker, nonce-issuance helper, or challenge-replay convenience API.

3) **Provider-native freshness fields are evidence inputs, not portable session continuity or replay shortcuts.**
   - Ecosystem carriers such as qualifying data, nonces, epoch handles, or other provider-native freshness fields remain exact evidence inputs.
   - They do not become a portable “resume this attestation session”, “prove liveness without a new challenge”, or “current token” shortcut.

4) **No native nonce-issuance, freshness-query, or online challenge plane in v0.**
   - Phase 1 standardizes no `issue_challenge`, `check_freshness`, `renew_attestation`, `current_attestation`, or similar service surface.
   - Any online freshness protocol remains an explicit higher-layer workflow that must pay for its own RFC, policy, and network story.

5) **Challenge reuse or omission does not silently widen meaning.**
   - Reusing a challenge, omitting freshness, or carrying provider-native fields without a verifier challenge does not silently widen the portable meaning of the evidence.
   - Verifiers may reject, accept under narrow local policy, or require stricter freshness rules without changing the substrate contract.

6) **Freshness does not import ambient wall-clock or timestamp authority.**
   - Freshness binding does not smuggle in trusted wall-clock, time synchronization, or timestamp-authority semantics.
   - Any separate timeproof or timestamp evidence remains explicit and independently appraised.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing attestation/export/evidence seams are interpreted.
   - Any future freshness service, challenge protocol, or session-maintenance workflow must pay for its own RFC, conflict keys, serialization story, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native challenge issuance API.
- No `current attestation` or `revalidate this token` service.
- No built-in online freshness protocol.
- No portable replay-window, epoch-sync, or session-continuity plane.
- No timestamp-authority or trusted-wall-clock import hidden behind attestation freshness.

## Why this is worth pinning

The surrounding ecosystem is explicitly split:
- RFC 9334 treats freshness as verifier/appraiser-side procedure, not as ambient truth carried by Evidence.
- PSA attestation tokens carry verifier-supplied nonce material without assuming a specific protocol or turning the token into a generic session/currentness object.
- TPM quote flows bind qualifying data exactly into the signed evidence to defend against replay, but they still require explicit verifier challenge discipline.

Pinning that split now prevents SlopOS from slowly reinventing a hidden challenge service, “current token” plane, or session-resumption shortcut under the names of attestation export or evidence packaging.

## Profile effect (A–D)

- **Secure workstation (A):** enterprise attestation tools may use nonce-bound exports without turning attestation into a generic “current device trust” oracle.
- **Cloud micro-VM substrate (B):** admission and secret-release flows can require fresh verifier challenges while keeping any online freshness protocol explicit and killable.
- **Embedded / separation appliance (C):** offline verifiers stay deterministic; challenge semantics stay exact and local rather than depending on background services.
- **Agent/automation OS (D):** agents may pass nonce-bound evidence around, but they cannot quietly treat stale tokens as portable live-session truth.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATTEST**, **D-NETLEASE**, **D-TIMEPROOF**.
- Adjacent meaning pins:
  - `docs/30-architecture/attestation-posture-v0.md`
  - `docs/30-architecture/attestation-token-schema-v0.md`
  - `docs/30-architecture/attestation-pack-schema-v0.md`
  - `docs/30-architecture/cryptosvc-attestation-boundary-v0.md`
- Engineering / profile surfaces:
  - `rfcs/0064-confidential-computing-profile.md`
  - `docs/30-architecture/interface-registry.md`
- Assurance anchors:
  - **I-ATTEST-1**.
  - **PO-ATTEST-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_attestation_freshness_boundary.py` keeps the split small and discoverable (**EVID-2026-609**).

## References

- **REF-RATS-RFC9334**
- **REF-EAT-RFC9711**
- **REF-RFC9783-PSA-TOKEN**
- **REF-TPM2-PART3-QUOTE**
