# MicroVM guest-agent posture v0 (management helpers stay non-portable)

Purpose: pin the **Phase 1** meaning of in-guest host-management helpers under `ext.microvm` so convenience daemons do not quietly become a portable reviewed lifecycle/file/metadata/time/snapshot/control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-OBS**, **D-ACTIVATE**, and **D-NONDET** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-agent contract under `ext.microvm`; there is no portable guest-agent lifecycle-file-admin plane, no portable metadata-heartbeat-observation plane, no portable quiesce-time-sync-snapshot-assist plane, owner-local guest-agent installation/enabling stays implementation-local, and reviewed lifecycle/file/observation/time/bootstrap meaning still rides on already-pinned explicit seams rather than ambient host↔guest management daemons.**

Entropy cost justification: the archive already pins host↔guest transports, console channels, bootstrap metadata, lifecycle signaling, time sources, and crash/snapshot semantics individually, but the mainstream guest-agent ecosystem cuts across all of them at once. QEMU Guest Agent, Hyper-V integration services, and VMware open-vm-tools offer host-triggered shutdown/reboot, guest exec/file operations, metadata exchange, heartbeat/state reporting, time synchronization, and quiesced snapshot helpers. One narrow posture closes that gap without inventing a guest-agent protocol, management bus, or new schema family.

## Posture (v0)

1) **No portable ambient guest-agent contract**
   - **Phase 1 exposes no portable ambient guest-agent contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable in-guest management daemon, one stable host-command vocabulary, or one stable “host can always ask the guest” helper surface.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those helper mechanisms do **not** become SlopOS portable API meaning.

2) **No portable lifecycle-file-admin plane**
   - There is **no portable lifecycle-file-admin plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest-agent shutdown/reboot contract, one stable host-triggered guest-exec contract, one stable host-triggered guest file open/read/write/copy contract, one stable password-reset or in-guest account-management contract, or one stable post-boot guest-customization plane.
   - Owner-local guest-agent helpers for power actions, in-guest command execution, file staging, credential mutation, or first-boot customization remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable metadata-heartbeat-observation plane**
   - There is **no portable metadata-heartbeat-observation plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable heartbeat/health report contract, one stable key-value metadata exchange plane, one stable guest network-interface/IP inventory plane, one stable guest application/service/container inventory plane, or one stable guest-usage/statistics publication contract.
   - Owner-local heartbeat, KVP/data-exchange, guest-info, and telemetry helpers remain implementation-local and must not silently become portable readiness, routing, or policy truth.

4) **No portable quiesce-time-sync-snapshot-assist plane**
   - There is **no portable quiesce-time-sync-snapshot-assist plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable filesystem-freeze/thaw or VSS-style quiesce contract, one stable host-triggered guest time-set/time-sync plane, or one stable “snapshot safe because the agent said so” coordination contract.
   - Owner-local snapshot quiescing, guest clock repair, and backup-helper behavior remain implementation-local and must not silently become portable crash-consistency, timeproof, or lifecycle meaning.

5) **Existing explicit seams remain authoritative**
   - Reviewed lifecycle meaning still rides on explicit `D-ACTIVATE` supervision and the already-pinned lifecycle-signal posture rather than ambient guest-agent power or reboot helpers.
   - Reviewed file/bootstrap meaning still rides on explicit boot artifacts, document/file seams, and the already-pinned bootstrap-metadata posture rather than host-triggered guest file copy, guest customization, or metadata exchange daemons.
   - Reviewed observation/health meaning still rides on explicit `D-OBS` exports and already-pinned microVM observation surfaces rather than guest heartbeats, KVP stores, or helper-owned telemetry summaries.
   - Reviewed time meaning still rides on explicit `D-NONDET` / `D-TIMEPROOF` seams and the already-pinned microVM time-source posture rather than guest-agent clock synchronization or host-set-time helpers.
   - Reviewed snapshot/repair meaning still rides on already-pinned warm-start, restore-repair, and crash-evidence seams rather than an ambient “guest agent approved the snapshot” story.

6) **Changing the guest-agent stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the guest-agent stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different in-guest management-helper posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `enable_guest_agent`, `exec_in_guest`, `copy_file_into_guest`, `set_guest_time_via_agent`, or `quiesce_guest_for_snapshot` control plane by convention.
   - This keeps guest-agent meaning on already-pinned activation/file/observation/time seams rather than on ambient host-management daemons.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_guest_agent_policy`, `exec_in_guest`, `copy_file_to_guest`, `read_guest_metadata`, or `quiesce_guest_for_snapshot` must say whether it commutes with activation, reset, observation export, bootstrap policy, time policy, and snapshot/restore policy, and where serialization lives.
   - Until then, guest-agent helpers remain owner-local runtime conventions rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable QEMU Guest Agent / Hyper-V integration-services / VMware Tools contract under `ext.microvm`.
- No portable host-triggered guest exec / file copy / password reset / post-boot customization plane.
- No portable heartbeat / KVP / guest inventory / guest telemetry truth contract.
- No portable freeze-thaw / VSS / time-sync / snapshot-assist contract.
- No claim that guest-agent daemons are an acceptable portable lifecycle, bootstrap, observation, file, or timeproof mechanism.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-OBS, D-ACTIVATE, D-NONDET)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-lifecycle-signal-posture-v0.md`
  - `microvm-bootstrap-metadata-posture-v0.md`
  - `microvm-time-source-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-38)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-GUESTAGENT)
- Policy posture:
  - guest-agent helpers add **no new lane**, **no portable live enable/disable plane**, and **no portable host-command truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_guest_agent_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable guest-agent / no portable lifecycle-file-admin plane / no portable metadata-heartbeat-observation plane / no portable quiesce-time-sync-snapshot-assist plane / owner-local guest-agent installation/enabling remains implementation-local / explicit lifecycle-file-observation-time seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-GUEST-AGENT.
- REF-HYPERV-INTEGRATION-SERVICES.
- REF-OPEN-VM-TOOLS.
