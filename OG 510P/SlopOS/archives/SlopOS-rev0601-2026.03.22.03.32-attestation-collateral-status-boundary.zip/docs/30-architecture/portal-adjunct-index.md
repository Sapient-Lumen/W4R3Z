# Portal adjunct index (closed portal workflow posture family)

Purpose: keep the current **portal workflow posture family** recoverable as one closed discovery surface.
Why this exists:
The archive already has `portal-family-registry.md` as the closed `portal.*` taxonomy and `lease-adjunct-index.md` as the closed family for lease-backed portalized authority, but the generic D-PLUMB portal core plus the direct `*-portal-posture-v0.md` workflow docs are still recovered piecemeal from registry rows and scattered posture entries.

This doc does **not** create a universal portal broker, a backend-selection API, or a wider portal taxonomy. It keeps the current direct workflow portal family closed, enumerable, and reviewable as one implementation-facing surface for shapes **A/D** (and optional mediated-workflow uses in **B**) while leaving lease-backed, request-state-honesty, and other adjacent portalized seams explicitly separate.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is either `plumb-posture-v0.md`, `portal-session-posture-v0.md`, or a `*-portal-posture-v0.md` doc under `docs/30-architecture/` that pins the caller-visible meaning of a direct portal workflow family;
2) it is a posture doc, not an adjacent registry/schema/boundary surface (for example `portal-family-registry.md`, `job-request-schema-v0.md`, `background-request-schema-v0.md`, `open-untrusted-boundary-index.md`, and `import-to-docref-boundary-index.md` stay adjacent);
3) its meaning is about the generic workflow-router/session core or a direct portal-named workflow family, not a neighboring seam whose Phase 1 posture intentionally lives elsewhere (for example `network-lease-posture-v0.md`, `location-lease-posture-v0.md`, `background-lease-posture-v0.md`, `inhibit-lease-posture-v0.md`, `job-request-state-posture-v0.md`, `network-request-state-posture-v0.md`, `notification-request-state-posture-v0.md`, `app-secret-posture-v0.md`, `ui-automation-posture-v0.md`, and `powerbox-posture-v0.md` stay outside this family).

## Closed portal workflow posture set (Phase 1)

### 1) Generic workflow-router and portal-session core

| Doc | One-line pinned meaning |
|---|---|
| [`plumb-posture-v0.md`](plumb-posture-v0.md) | workflow routing stays explicit-invocation and request-local; no durable inbox/outbox, callback registry, or handler inventory |
| [`portal-session-posture-v0.md`](portal-session-posture-v0.md) | portal request/session objects stay provider-owned, single-outcome, and family-local; no generic resume/list/watch/callback layer |

### 2) Direct document, launch, transfer, and print workflows

| Doc | One-line pinned meaning |
|---|---|
| [`document-portal-posture-v0.md`](document-portal-posture-v0.md) | document workflows stay manual-only; persistence is explicit; reopen is non-bearer and non-widening |
| [`openuri-portal-posture-v0.md`](openuri-portal-posture-v0.md) | URI opening stays manual-only, scheme-gated, and launch-only; no handler inventory/probing or callback channel |
| [`transfer-portal-posture-v0.md`](transfer-portal-posture-v0.md) | transfer stays manual-only, sink-pull, one-shot/auto-clear across boundaries, and non-history |
| [`print-portal-posture-v0.md`](print-portal-posture-v0.md) | print stays manual-only, render-first, and shell-spooled; no printer inventory, queue authority, or print-to-file loophole |

### 3) Direct capture and deferred-work workflows

| Doc | One-line pinned meaning |
|---|---|
| [`capture-portal-posture-v0.md`](capture-portal-posture-v0.md) | capture stays manual-only, indicator-bound, and non-persistent; no restore-token / remembered-session seam |
| [`job-portal-posture-v0.md`](job-portal-posture-v0.md) | deferred jobs stay portalized and best-effort/coalesced; no exact-alarm replay debt or ambient scheduler plane |

## Review rule

When a new `*-portal-posture-v0.md` doc appears, or when the generic portal core splits beyond `plumb-posture-v0.md` / `portal-session-posture-v0.md`, either:

- add it here **in the same revision**, or
- explicitly place it under some other existing closed discovery surface in the same revision.

If a future portal family’s main posture intentionally lives outside `*-portal-posture-v0.md`, the split must stay explicit: keep this index, the lease-backed family in `lease-adjunct-index.md`, the request-identity honesty family in `request-state-adjunct-index.md`, and the adjacent consent/accessibility seams (`powerbox-posture-v0.md`, `ui-automation-posture-v0.md`) all honest in the same revision instead of letting “portal” become one blurry bucket.

## Wiring

- Portal taxonomy: `portal-family-registry.md`.
- Adjacent portalized families: `lease-adjunct-index.md`, `request-state-adjunct-index.md`, `powerbox-posture-v0.md`, `ui-automation-posture-v0.md`.
- Adjacent safe-open/document bridge surfaces: `open-untrusted-boundary-index.md`, `import-to-docref-boundary-index.md`.
- Decision surfaces: `decision-map.md` (**D-PLUMB**, **D-CAPTURE**, **D-JOBS**, **D-POWERBOX**).
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_portal_adjunct_index.py` (**EVID-2026-524**).
