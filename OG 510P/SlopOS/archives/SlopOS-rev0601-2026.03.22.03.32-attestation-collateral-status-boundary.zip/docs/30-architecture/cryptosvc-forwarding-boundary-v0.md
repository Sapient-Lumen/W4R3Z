# D-CRYPTOSVC forwarding boundary v0 (no transparent agent forwarding; delegation only via explicit narrowed routes)

Purpose: narrow the **cross-domain / cross-compat delegation** meaning of **D-CRYPTOSVC** so SlopOS does not quietly inherit
SSH-agent-style forwarding as an ambient bearer channel.

This is intentionally a **boundary** doc, not a new schema. It attaches to the existing **D-CRYPTOSVC / D-LEASE / D-FCELL /
D-VOLITION** seams and resolves one practical Phase 1 question: **when key-use authority crosses a machine/domain/compat
boundary, is that a transparent forwarding convention, or an explicit delegated route with reviewable narrowing?**

## Posture (v0)

1) **No transparent forwarded-agent seam in Phase 1**
   - SlopOS does **not** standardize a forwarded agent socket, inherited `SSH_AUTH_SOCK`-style channel, or a “same agent,
     different hop” compatibility fiction on D-CRYPTOSVC.
   - Cross-domain crypto use therefore does **not** happen by ambient path/env/socket inheritance, remote shell startup,
     or hidden broker side effects.
   - Sealed compat stays honest: Foreign Cells do not inherit host auth-agent channels by default.

2) **Cross-boundary use, if allowed at all, is an explicit routed delegation**
   - Any remote/compat/peer use of a key-capability MUST arrive through an **explicit provider-issued route** such as a
     narrowed proxy/lease or a provider-owned request object, not by exporting the whole provider namespace.
   - The delegated route MUST bind one concrete authority target (`kid` / `digest(CH-KEYREF v0)` or an equivalent local
     handle binding) plus one effective policy pin.
   - Phase 1 introduces **no generic “forward my whole agent” surface** and no app-visible transport-neutral forwarding API.

3) **Delegation may narrow policy only; it may not widen it**
   - When authority crosses a boundary, the effective policy MAY stay the same or become a strict subset of the source
     **CH-KEYPOL v0** semantics, but it MUST NOT widen `ops`, `contexts`, `confirm`, `rate`, `time_bounds`, or other
     provider-enforced restrictions.
   - In particular, a forwarded/delegated route MUST NOT turn `confirm=true` into background approval, erase context tags,
     or relax a time/rate bound because the caller is remote.
   - This keeps cross-boundary use aligned with D-LEASE: delegation is attenuation-first, not an excuse to reopen ambient authority.

4) **Confirmation and session integrity stay explicit and fail closed**
   - If provider policy requires confirmation, approval remains an **explicit provider-local decision path** (or another already-reviewed
     approval artifact), not a hidden remote prompt or best-effort forwarding convention.
   - If a deployment uses hop/session-binding or destination-constrained routing, inability to validate the binding MUST fail closed.
   - Phase 1 therefore declines any “fallback to unconstrained forwarding” semantics when session integrity cannot be established.

5) **No remote inventory, search, or provider browsing**
   - A boundary crossing may yield a concrete narrowed route for one already-chosen key capability, but it does **not** grant
     remote enumeration of keys, labels, smartcards, tokens, or provider-global policy state.
   - The receiver gets a concrete delegated authority path, not an inventory oracle.

6) **Compat adapters must stay transcript-visible and policy-killable**
   - If Foreign Cell compatibility needs crypto-provider interop, it MUST go through explicit adapters and remain killable by policy.
   - The adapter path SHOULD emit **CH-FADAPT** receipts and preserve the same no-inventory / no-ambient-forwarding posture.
   - Phase 1 rejects compat shims that silently bridge host agent sockets into the reviewed SlopOS seam.

7) **No new ACP/admin/background forwarding surface in Phase 1**
   - Phase 1 adds **no ACP kind**, no background forwarding broker, no remote key-export daemon, and no durable resume/list/watch
     surface for forwarded crypto authority.
   - If SlopOS ever needs first-class cross-domain crypto delegation, that work must pay for its own RFC-first action surface,
     commutativity analysis, receipts, and policy hooks rather than widening D-CRYPTOSVC by convention.

## Phase 1 non-goals (explicitly deferred)

- no ambient `SSH_AUTH_SOCK` inheritance across machine, compat, shell, or session boundaries.
- no transparent forwarded-agent seam or generic “forward my whole provider” API.
- policy may preserve-or-narrow but never widen across delegation.
- **No remote inventory/search surface** for keys, labels, smartcards, or provider-global state.
- **No durable resume/list/watch surface** for forwarded crypto authority.

## Why this boundary exists

- **Keeps secure workstations (A) honest**: remote shells and compat tools do not smuggle in ambient signing power via socket lore.
- **Keeps cloud/hosted substrates (B) reviewable**: micro-VM and remote build agents get explicit attenuated routes, not inherited bearer channels.
- **Keeps embedded / separation systems (C) small**: crypto authority remains a concrete provider edge, not a hidden forwarding subsystem.
- **Keeps agent/automation systems (D) transcriptable**: LLM-authored workflows can reason about one concrete delegated route and one pinned policy, not a magical global agent namespace.

## Imported ecosystem pattern

- **Plan 9 factotum** shows the value of a small key-holding agent rather than app-managed secret sprawl.
- **OpenSSH agent restrictions** and **destination-constrained keys** show the right direction for cross-hop use: if forwarding exists,
  it should be constrained, explicit, and fail closed rather than being a transparent ambient bearer channel.

We import the pattern, not the whole ecosystem: **cross-boundary crypto use is allowed only through explicit narrowed routes;
transparent forwarding is not part of the core seam**.

## Consequences

- `IF-CRYPTOSVC` can stay a small privileged surface instead of becoming a general remote broker.
- D-LEASE remains the right attenuation vocabulary for delegated key use.
- Any future remote/forwarded crypto action must introduce its own explicit action surface rather than widening CH-KEYREF or CH-KEYPOL in place.

## Family status (Phase 1)

This doc is a **member of the closed D-CRYPTOSVC companion boundary family** in `cryptosvc-boundary-index.md` because forwarding/delegation is one of the explicit meaning cuts that keeps IF-CRYPTOSVC small.

Future nearby growth should attach to that family in the **same revision** rather than re-creating forwarding singleton folklore by inertia.

## Wiring

- Core posture: `cryptosvc-posture-v0.md`
- Interface registry: `interface-registry.md` (IF-CRYPTOSVC)
- Decision surface: `decision-map.md` (D-CRYPTOSVC)
- Related schemas: `key-policy-schema-v0.md`, `keyref-schema-v0.md`, `crypto-audit-schema-v0.md`
- Delegation posture: `capability-lease-posture-v0.md`
- Sealed compat boundary: `foreign-cell-contract.md`, `fcell-adapter-receipt-schema-v1.md`
- History: `rfcs/0067-capability-crypto-services-and-key-handles.md`
- Assurance hooks: `docs/20-assurance/invariant-registry.md` (**I-CRYPTO-3**), `docs/20-assurance/proof-obligation-registry.md` (**PO-CRYPTOPOL-ENF**, **PO-CRYPTOSVC-ENF**)
- CI drift gate: `tools/check_cryptosvc_forwarding_boundary.py` (EVID-2026-339)

## References

- REF-PLAN9-FACTOTUM.
- REF-OPENSSH-AGENTRESTRICT.
- REF-OPENBSD-SSHADD.
