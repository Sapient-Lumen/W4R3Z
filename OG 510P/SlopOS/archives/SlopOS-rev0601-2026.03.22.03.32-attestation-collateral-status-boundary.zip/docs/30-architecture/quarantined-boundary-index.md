# Quarantined boundary index (v0)

Purpose: keep the **closed set of D-QUAR companion boundary docs** enumerable.

Why this exists:
- the archive now pins several small `quarantined-*-boundary-v0.md` companions so quarantine cannot quietly degrade into an advisory tag,
- those docs are individually crisp but easy to lose piecemeal because they span execution gating, content derivation, and result rendering,
- `quarantine-posture-v0.md` keeps the overall meaning of D-QUAR, while this index is the **discovery surface** that says which boundary docs currently make quarantine fail closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `quarantine-posture-v0.md` and RFC-0053.

## Inclusion rule

A doc belongs here if it removes exactly one tempting quarantine-laundering meaning from Phase 1 by constraining one of:
- execution or code-bearing ingress paths that would otherwise turn quarantine into a soft warning,
- content derivation, query, or result-rendering behavior that would otherwise let risky bytes quietly regrow trust through OCR, embeddings, summaries, or previews.

If future work needs a new native review, analysis, or execution workflow instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind quarantine metadata.

## Closed companion boundary set (Phase 1)

### 1) Exact execution must stay explicitly cleared

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`quarantined-execution-boundary-v0.md`](quarantined-execution-boundary-v0.md) | exact executable/script launch | quarantined exact executables/scripts stay deny-by-default on normal exec seams; `open_untrusted` does not widen into a portable `run_untrusted` lane | explicit object-local clear/override plus ordinary execution seam |
| [`quarantined-code-input-boundary-v0.md`](quarantined-code-input-boundary-v0.md) | interpreter/eval-style code ingress | a cleared interpreter/runtime must not launder a quarantined bound code object by feeding it through `stdin`, `-c`, `--eval`, module/archive entry, or similar code-bearing inputs | explicit object-local clear/override plus ordinary reviewed interpreter invocation |

### 2) Discovery, derivation, and rendering must not launder source bytes

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`quarantined-content-index-boundary-v0.md`](quarantined-content-index-boundary-v0.md) | ambient content-derived indexing | quarantined bytes stay out of ambient full-text / OCR / embedding / summary extraction; authorized discovery remains metadata-safe only | explicit derived-output workflow yielding a new quarantined artifact |
| [`quarantined-derived-attribute-boundary-v0.md`](quarantined-derived-attribute-boundary-v0.md) | source-object semantic back-write | even explicit OCR / summarize / classify / embed workflows must not write semantic text/tags/classifier outputs back onto the risky source object's metadata | separate derived artifact carrying the durable semantics |
| [`quarantined-derived-match-boundary-v0.md`](quarantined-derived-match-boundary-v0.md) | source resurfacing by derived matches | query/search/smart-folder surfaces must not resurface the risky source object by hidden lineage joins, representative substitution, or dedup-style collapse when a sibling derived artifact matched | exact hit stays on the derived artifact unless the relation is followed explicitly |
| [`quarantined-result-preview-boundary-v0.md`](quarantined-result-preview-boundary-v0.md) | result rendering | even when the exact quarantined or derived artifact is the right hit, result rendering stays metadata-safe only; no ambient snippets, thumbnails, preview panes, or hover previews from quarantined bytes | separate explicit review/open step on the exact handle |

## Review rule

Before adding another `quarantined-*-boundary-v0.md` doc, answer these questions in order:
1) Is the change really a **D-QUAR laundering-prevention meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening quarantine semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
