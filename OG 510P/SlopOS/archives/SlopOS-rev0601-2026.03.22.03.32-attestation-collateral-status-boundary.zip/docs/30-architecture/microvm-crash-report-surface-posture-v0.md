# MicroVM crash-report surface posture v0 (panic and crash-record surfaces stay non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible panic/crash-reporting surfaces under `ext.microvm` so `pvpanic`, `vmcoreinfo`, and `pstore`/ERST/ramoops folklore do not quietly become a portable reviewed evidence/admin plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-OBS**, **D-INSPECT**, and **D-FLIGHTREC** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible crash-reporting contract under `ext.microvm`; there is no portable `pvpanic` / `vmcoreinfo` / `pstore`-ERST-ramoops plane, owner-local panic notification and crash-record storage stay implementation-local, and exported failure evidence rides on explicit `D-OBS` / `D-INSPECT` / `D-FLIGHTREC` / `CH-CRASHCAP` seams rather than ambient guest devices, firmware tables, or filesystems.**

Entropy cost justification: the archive already has explicit failure-evidence artifacts (`CH-CRASHCAP`, `CH-SNAPSHOT`) and bounded retention posture (`D-FLIGHTREC`), but modern VMMs also expose a separate guest-visible crash path: devices that notify the host of panic, `fw_cfg` notes that shape dumps, and persistent crash-record stores such as ACPI ERST-backed `pstore`. That is a distinct decision surface from lifecycle signaling or firmware state because it can quietly smuggle host reaction policy and evidence collection semantics into guest-visible devices/filesystems. One narrow posture closes that gap without inventing a panic broker, dump API, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible crash-reporting contract**
   - **Phase 1 exposes no portable ambient guest-visible crash-reporting contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable guest-visible panic-notification device, dump-annotation channel, or persistent crash-record store.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those mechanisms do **not** become SlopOS portable API meaning.

2) **No portable `pvpanic` / panic-notification plane**
   - There is **no portable `pvpanic` / guest-panicked notification plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest-triggered panic signal, one host notification event, or one reviewed promise that host automation observes panic through a guest device rather than through explicit observation/evidence seams.
   - Owners/runtimes may locally expose `pvpanic`, a similar panic device, or no guest panic-notification device at all, but those choices remain implementation-local and must not silently become portable lifecycle, evidence, or orchestration semantics.

3) **No portable `vmcoreinfo` dump-annotation plane**
   - There is **no portable `vmcoreinfo` / dump-note plane** under Phase 1.
   - Portable reviewed meaning does **not** include one guest-visible `fw_cfg` entry, one standard dump-note format, or one promise that guest-written dump metadata will be consumed with portable reviewed semantics by the runtime.
   - Owner-local dump-generation details, debug-note consumption, and crash-dump shaping remain implementation-local rather than portable `ext.microvm` contract meaning.

4) **No portable `pstore`-ERST-ramoops crash-record plane**
   - There is **no portable `pstore`-ERST-ramoops plane** under Phase 1.
   - Portable reviewed meaning does **not** include one persistent crash-record filesystem, one ACPI ERST backing contract, one ramoops-style surviving buffer, or one guest-visible crash-record clear/query workflow under `ext.microvm`.
   - Owners/runtimes may locally use ERST-backed `pstore`, host files, persistent RAM, or no guest-visible crash-record store at all, but those storage choices remain implementation-local and must not silently become portable failure-evidence semantics.

5) **Failure evidence export stays on explicit observation seams**
   - Exported/shareable failure evidence still rides on explicit `D-OBS` / `D-INSPECT` / `D-FLIGHTREC` seams and their artifacts such as `CH-CRASHCAP` and `CH-SNAPSHOT`.
   - In plain terms: “how operators receive crash evidence” is a reviewed observation/export question, not a promise that every microVM exposes one guest-visible panic device or one persistent crash-record store with portable semantics.
   - This keeps crash evidence killable, redaction-scoped, and transcript-visible rather than ambient in firmware tables, guest filesystems, or hidden host reactions.

6) **Changing the crash-report stance is owner-local lifecycle/evidence policy or new admission, not a portable live admin plane**
   - Changing the crash-report stance is owner-local lifecycle/evidence policy or new admission, not a portable live admin plane.
   - If policy cares about a different panic-notification or crash-record posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `query_guest_panic_state`, `fetch_vmcoreinfo_note`, or `clear_pstore_records` control plane by convention.
   - This keeps host reaction and evidence-routing meaning on the already-pinned activation/observation seams rather than on guest crash folklore.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed crash-report action such as `watch_guest_panic`, `fetch_guest_crash_record`, or `clear_guest_crash_store` must say whether it commutes with activation, reset, observation export, snapshot capture, and quarantine/redaction policy, and where serialization lives.
   - Until then, crash reporting remains owner-local runtime/guest convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable `pvpanic` / guest-panicked notification contract under `ext.microvm`.
- No portable `vmcoreinfo` / dump-note contract under `ext.microvm`.
- No portable `pstore` / ACPI ERST / ramoops crash-record store or clear/query workflow.
- No portable guest-visible crash-evidence inventory or host-reaction API.
- No claim that guest panic devices or persistent crash-record stores are portable provenance/evidence truth.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-OBS, D-INSPECT, D-FLIGHTREC)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `observation-export-posture-v0.md`
  - `crash-capsule-schema-v0.md`
  - `flight-recorder-policy-schema-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-34)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-CRASHSURFACE)
- Policy posture:
  - guest-visible panic/crash-reporting adds **no new lane**, **no portable host-reaction or crash-record admin plane**, and **no portable evidence-by-device/filesystem contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_crash_report_surface_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable crash-reporting / no portable `pvpanic` / no portable `vmcoreinfo` / no portable `pstore`-ERST-ramoops plane / owner-local crash storage and panic notification remain implementation-local / explicit `CH-CRASHCAP` and observation seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-PVPANIC.
- REF-QEMU-VMCOREINFO.
- REF-QEMU-ACPI-ERST.
- REF-LINUX-RAMOOPS.
- REF-LINUX-PSTORE.
