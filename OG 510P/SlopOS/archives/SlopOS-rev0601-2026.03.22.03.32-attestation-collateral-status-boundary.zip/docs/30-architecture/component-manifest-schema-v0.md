# CH-COMP v0 (component manifest / composition graph, informal)

Purpose: pin the **system composition graph** (components + declared capability routes) as an explicit, signed, canonical artifact that can be:
- reviewed and linted (human + CI),
- bound into boot measurements (CH-BOOT `artifacts`),
- consumed by a user-space init/component manager that refuses any undeclared route.

Constraint: this must *not* require a large privileged “component framework.” The kernel/hypervisor stays mechanistic; composition policy is data + user space.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- closed set of keys (no free-form extension blobs)
- IDs are stable + bounded (no unbounded strings used as authority)
- no ambient discovery: all usable cross-component authority must be reachable via a declared route (I-COMP-1)

## Shape (v0)
A manifest `cm` contains:
- `schema`: fixed `CH-COMP v0`
- `graph_rev`: monotonically increasing identifier (for ops/debug; not authority)
- `components`: bounded list of component declarations
- `routes`: bounded list of capability-route declarations

### Component declaration
Each component `c` contains:
- `cid`: component identifier (opaque; bounded)
- `kind`: one of `{ service, vm, driver }`
- `image_digest`: digest of the component image/artifact (bound by CH-BOOT)
- `entry`: bounded entrypoint selector (e.g., `{ svc_main, vmm_main, drv_main }`)
- `seal_after_init`: bool (if true, component must perform an init→seal step; see D-SEAL)
- `critical`: bool (if true, supervisor treats failure as fail-closed per profile; default false)
- `restart`: optional restart policy object (enforced by user space; see RFC-0017):
  - `policy`: one of `{ never, on_failure, always }`
  - `window_ms`: bounded window for rate limiting
  - `max_restarts`: bounded count within window
  - `backoff_ms`: bounded delay before restart
- `ready`: optional readiness barrier metadata (enforced by user space; see RFC-0074):
  - `required`: bool (default false)
  - `timeout_ms`: bounded time budget to reach ready (e.g., u32)
- `activation`: optional activation/handoff posture (enforced by user space; see RFC-0081 and `activation-posture-v0.md`):
  - `stable_exports`: bounded list of exported `cap_kind` values that are supervisor-owned stable handles (socket-activation style)
  - `handle_store`: optional handle-store policy object:
    - `enabled`: bool (default false)
    - `key_allowlist`: bounded list of bounded labels (not authority; used only as keys)
    - `max_items`: bounded count
    - `phase`: one of `{ steady_only, init_ok }` (default `steady_only`)
- `imports`: bounded list of declared required capability *kinds* (typed; no strings-as-authority)
- `exports`: bounded list of declared provided capability *kinds* (typed; no strings-as-authority)
- `limits`: optional bounded resource constraints (e.g., meter binding IDs, static partition tags)

### Route declaration
Each route `r` contains:
- `from`: source `cid`
- `to`: destination `cid`
- `cap_kind`: one of a closed set (must align with `imports`/`exports`)
- `mode`: one of `{ grant, derive, proxy }` (mechanism is still capability-mediated; this is declarative intent)
- `rights`: bounded rights set (subset of cap_kind’s maximum rights)
- `notes_tag`: optional bounded tag for operator readability (ignored by validators)

## Validation obligations (PO-COMP-VALIDATE)
- reject unknown keys/enum variants (closed world)
- if `restart` present: validate bounds (window/backoff) and reject unknown policy variants
- if `critical` present: must be boolean
- if `activation` present: validate closed-world enums and bounds; unknown keys/variants reject
- `activation.stable_exports[*]` must be a subset of the component’s declared `exports`
- if `activation.handle_store.enabled`: validate `key_allowlist` bounds, `max_items` bounds, and closed-world `phase` enum
- all referenced `cid` exist and are unique
- every `route` matches: `cap_kind` is exported by `from` and imported by `to`
- `rights` are a subset of the declared cap_kind rights; unknown rights reject
- if `seal_after_init` is true, the component must be launched with only init-time authority and then demonstrably attenuate before being considered “ready” (I-SEAL-1 integration; enforced in user space initially)

## Binding obligations (PO-COMP-BIND)
- if CH-COMP is used, its digest must appear in CH-BOOT `artifacts` (role = `comp_manifest`) and must be verified/recorded by IF-BOOT per policy
- a running system must be able to export the active CH-COMP digest via IF-OBS/CH-LOG to support incident response and reproducibility

## Notes
- v0 deliberately does **not** attempt to replicate Fuchsia/Genode feature sets (realms, dynamic resolution, etc.).
- This is a *seam*: enough structure to make composition reviewable and checkable, while keeping the privileged core small.
- Phase 1 activation posture is **manifest-closed + continuity-only**: `activation` is for supervisor-delivered stable handles and bounded per-component continuity, not a generic inherited-descriptor or cross-component export mechanism (`activation-posture-v0.md`).
- Phase 1 supervision posture is **component-rooted + non-process-tree**: `restart` / `critical` metadata bind reviewable user-space supervision to explicit component identities rather than to raw PIDs, shell jobs, `pidfd`, or Job Object ancestry (`supervision-posture-v0.md`).
