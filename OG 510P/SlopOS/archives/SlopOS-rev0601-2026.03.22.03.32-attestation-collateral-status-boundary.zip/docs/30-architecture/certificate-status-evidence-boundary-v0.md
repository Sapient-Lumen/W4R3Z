# Certificate-status evidence boundary v0 (explicit local status inputs; no ambient status chase or latest-status authority)

Purpose: pin the **Phase 1** meaning of certificate status / revocation evidence across **D-SIGENV**, **D-KEYLESS**, and **D-TIME** so cert-bearing verification does not quietly inherit browser / PKI liveness folklore.

Entropy cost justification: `signature-envelope-posture-v0.md`, `signing-time-evidence-boundary-v0.md`, and `certificate-path-input-boundary-v0.md` already pin signed meaning, timing evidence, and certificate/path inputs. The remaining ambiguity is **status** itself: whether CRLs, OCSP, responder hints, cache behavior, or account-compromise notices are native substrate meaning versus explicit local evaluation inputs. One narrow boundary closes that gap without adding a new schema family, fetch client, or approval plane.

## Posture (v0)

1) **Certificate status evaluation consumes explicit local evidence and explicit local policy only.**
   - RFC 5280 requires that path validation establish that a certificate "is not revoked", but it explicitly allows that determination to come from CRLs, status information, or out-of-band mechanisms.
   - RFC 6960 defines OCSP as a protocol for obtaining the **current** status of a certificate; it does not make live responder access a mandatory meaning of every cert-bearing signature.
   - Phase 1 therefore standardizes **verified result meaning**, not a privileged-core status-retrieval algorithm.

2) **CRL / delta-CRL / OCSP locator fields are hints only, not authority.**
   - `cRLDistributionPoints`, `freshestCRL`, `authorityInfoAccess`, `id-ad-ocsp`, and similar embedded locators may appear in certificates, but in Phase 1 they are **non-authoritative hints only**.
   - A verifier may ignore them entirely.
   - Their presence MUST NOT create a portable "fetch current status now" meaning on D-SIGENV / D-KEYLESS.

3) **CRLs, delta CRLs, and OCSP responses are exact evidence inputs, not portable approval or install authority.**
   - A CRL, delta CRL, OCSP response, stapled status object, or other certificate-status artifact may be consumed as **exact local evidence** about a certificate serial / issuer / time window.
   - Those artifacts do **not** by themselves mean "verified-good", "approved", "fresh enough to install", or "latest truth".
   - Successful status checking therefore stays evidence under local policy rather than a portable verdict object.

4) **Freshness, staleness, and soft-fail versus hard-fail remain local policy, not substrate meaning.**
   - RFC 6960 answers certificate status; it does not settle one universal policy for responder availability, network failure, cache reuse, or stale-but-signed status objects.
   - RFC 5280 likewise permits out-of-band mechanisms and CRL constructions without mandating one portable operational profile.
   - Phase 1 therefore adds no portable "network unavailable means soft-pass", "missing CRL means hard-fail", "most recent cached status wins", or "delta CRL required" rule.

5) **No ambient OCSP / CRL / status-cache / watch plane in v0.**
   - Phase 1 standardizes no privileged OCSP client, no background CRL fetch/refresh daemon, no certificate-status inventory API, no revocation watch channel, and no machine-global status cache semantics.
   - If a deployment wants richer status retrieval or fleet-wide cache discipline, that must arrive as an explicit RFC-first seam with kill switches, conflict rules, and evidence hooks.

6) **Keyless account / issuer compromise remains outside the certificate-status seam.**
   - Sigstore’s public model explicitly prefers short-lived certificates over traditional revocation and separately notes that OIDC account compromise is not handled by Sigstore itself.
   - Phase 1 therefore declines any native repo-owner / account-status / forge-ban lookup plane on D-KEYLESS.
   - If an operator wants extra account-compromise deny data, it remains explicit local policy or explicit evidence on another already-reviewed seam.

7) **Interop status artifacts stay out-of-band and digest-bound; no new native status schema family in Phase 1.**
   - OCSP responses, CRLs, delta CRLs, stapled status blobs, cache snapshots, and related interop objects may be packaged or referenced as exact artifacts (for example through **CH-AREF** or release bundles), but they remain adjunct evidence rather than embedded native authority.
   - Phase 1 introduces no new native certificate-status schema family by example.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no ACP action kind, and no conflict-key namespace.
   - It only narrows what existing certificate-status artifacts are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native OCSP / CRL / delta-CRL fetch client or privileged status-discovery plane.
- No portable responder-availability / cache-reuse / soft-fail profile baked into D-SIGENV.
- No app-visible certificate-status inventory, watch, or subscription API.
- No repo-owner / account-compromise / forge-status lookup plane on D-KEYLESS.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, certificate status almost always drifts in one of four expensive directions:

- **Hidden liveness dependence.** A verifier that silently chases OCSP / CRL locators reintroduces ambient network and mutable remote state into a seam the archive already intended to keep offline-first.
- **Status objects turn into verdict folklore.** A cached OCSP response or CRL gets treated as "therefore approved" or "therefore installable" instead of one bounded evidence input under local policy.
- **Library defaults become platform meaning.** PKI stacks disagree on soft-fail, cache reuse, stale-response handling, and delta-CRL policy; leaving this implicit means whichever library happened to verify on one machine quietly becomes archive contract.
- **Identity-provider compromise gets smuggled through the wrong seam.** Keyless account or forge compromise is not solved by pretending cert-status artifacts are a universal account-status oracle.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** offline artifact verification stays reviewable; status evidence may be carried explicitly without making laptops ambient OCSP/CRL clients.
- **Cloud micro-VM / hosted substrate (B):** promotion workers can use exact local status policy without machine-specific library defaults leaking into release meaning.
- **Embedded / separation-kernel-ish appliance (C):** high-assurance profiles can ship explicit status evidence or simply avoid revocation dependence via short-lived cert policy, without adding a live network dependency.
- **Agent / automation OS (D):** agents may reason over status evidence, but they cannot smuggle "latest OCSP says okay" authority through proposal or workflow surfaces.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-TIME**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/signing-time-evidence-boundary-v0.md`
  - `docs/30-architecture/certificate-path-input-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**, **I-TIME-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**, **PO-EXPIRY-ENF**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_certificate_status_evidence_boundary.py` keeps the boundary small and discoverable (**EVID-2026-467**).

## References

- REF-RFC5280-PKIX
- REF-RFC6960-OCSP
- REF-SIGSTORE-SECURITY-MODEL
- REF-SIGSTORE-THREAT-MODEL
