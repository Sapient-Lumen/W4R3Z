# MicroVM memory-dedup posture v0 (mergeable memory stays non-portable)

Purpose: pin the **Phase 1** meaning of host-side guest-memory deduplication under `ext.microvm` so `mem-merge`, KSM, mergeable-memory toggles, and content-based page sharing do not quietly become an ambient density / isolation / tenancy plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host-side guest-memory-dedup contract under `ext.microvm`; there is no portable `mem-merge` / mergeable-memory / KSM plane, no portable merged-page / page-sharing-status plane, owner-local `MADV_MERGEABLE` / KSM scan policy stays implementation-local, and reviewed memory-isolation / tenancy meaning still rides on explicit admission / topology seams rather than ambient content-based page sharing.**

Entropy cost justification: the archive already fixes guest-visible RAM topology at admission, refuses ambient host↔guest channels, and keeps snapshot/migration/debug surfaces narrow. What remained loose was a host-side optimization seam that real VMMs expose directly: QEMU has `mem-merge=on|off`, Cloud Hypervisor has `mergeable=on|off`, and Linux KSM can merge identical anonymous pages across co-resident workloads. One narrow posture closes that gap without inventing a scheduler, tenancy API, or new schema family.

## Posture (v0)

1) **No portable ambient host-side guest-memory-dedup contract**
   - **Phase 1 exposes no portable ambient host-side guest-memory-dedup contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable page-dedup engine, one stable merged-page behavior, or one portable density optimization ABI across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume identical guest-RAM pages may be merged by the host under one portable policy.”

2) **No portable `mem-merge` / mergeable-memory / KSM plane**
   - There is **no portable `mem-merge` / mergeable-memory / KSM plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `mem-merge=on|off` control, one stable `mergeable=on|off` control, one stable KSM enable/disable contract, one stable page-eligibility vocabulary, or one stable content-based page-sharing promise across admitted leaves.
   - Implementations may locally expose or consume such controls, but those choices do **not** become SlopOS portable interface meaning.

3) **No portable merged-page / page-sharing-status plane**
   - There is **no portable merged-page / page-sharing-status plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable merged-pages counter, one stable dedup-hit/miss or scan-progress API, one stable “these leaves may share identical anonymous pages” guarantee, or one stable page-sharing telemetry contract tied to admission identity.
   - Owner-local counters, scan heuristics, and density telemetry remain implementation-local and must not silently become portable isolation, readiness, or scheduling truth.

4) **No portable cross-leaf density or co-residency-sharing promise**
   - There is **no portable cross-leaf density or co-residency-sharing promise** under Phase 1.
   - Portable reviewed meaning does **not** include one stable rule that identical anonymous pages from multiple admitted leaves, helper processes, or same-host tenants may be merged, nor one portable promise about merging across NUMA nodes, overcommit policy, or dedup eligibility windows.
   - If an implementation locally uses page sharing to increase density, that remains owner-local mechanism rather than portable `ext.microvm` semantics.

5) **Owner-local `MADV_MERGEABLE` / KSM scan policy stays implementation-local**
   - Owner-local `madvise(MADV_MERGEABLE)` marking, KSM enablement, scan cadence, page-eligibility policy, merge-across-nodes policy, and any equivalent dedup engine tuning stay implementation-local.
   - Implementations may locally revise those choices across upgrades, hardware classes, or deployment tiers, but those choices do **not** create a portable reviewed promise about page sharing, merge latency, merged-page lifetime, or side-channel posture.
   - In particular, density tuning, dedup eligibility, and merge/copy-on-write timing side effects remain runtime-local mechanism rather than portable SlopOS semantics.

6) **Changing the dedup stance is owner-local deployment policy or new admission, not a portable live control plane**
   - Changing the dedup stance is owner-local deployment policy or new admission, not a portable live control plane.
   - If policy cares whether a leaf runs with mergeable memory disabled, constrained to one owner-local host class, or under a different density posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `set_mem_merge`, `query_merged_pages`, `mark_guest_memory_mergeable`, or `share_identical_pages` plane by convention.
   - This keeps reviewed memory-isolation / tenancy meaning on explicit admission and topology seams rather than on ambient page-sharing folklore.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_mem_merge`, `query_merged_pages`, `set_ksm_policy`, or `share_identical_pages` must say whether it commutes with activation, memory-topology policy, placement/locality policy, snapshot/restore policy, and attestation or tenancy policy, and where serialization lives.
   - Until then, host-side guest-memory deduplication remains owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable `mem-merge` / mergeable-memory / KSM contract under `ext.microvm`.
- No portable merged-page / page-sharing-status / scan-progress telemetry contract.
- No portable cross-leaf identical-page sharing or co-residency density promise.
- No portable `MADV_MERGEABLE` / ksmd tuning / merge-across-nodes policy contract.
- No claim that host-side page dedup is an acceptable portable substitute for explicit admission / topology / tenancy review.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `microvm-live-migration-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-46)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-MEMDEDUP)
- Policy posture:
  - host-side guest-memory dedup adds **no new lane**, **no portable page-sharing or merge-status plane**, and **no portable density-control contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_memory_dedup_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable host-side guest-memory-dedup contract / no portable `mem-merge`-or-KSM plane / no portable merged-page-or-page-sharing-status plane / owner-local `MADV_MERGEABLE`-and-KSM policy remains implementation-local / explicit admission-topology seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-MEM-MERGE.
- REF-LINUX-KSM.
- REF-CHYP-MEMORY.
- REF-SUZAKI-MEMDEDUP-THREAT.
- REF-XIAO-MEMDEDUP-SECURITY.
