# MicroVM lifecycle-signal posture v0 (no portable ambient guest-visible power/reset/suspend/watchdog contract)

Purpose: pin the **Phase 1** meaning of guest-visible lifecycle and power-control signaling under `ext.microvm` so ACPI/i8042 shutdown-reboot keys, suspend-wakeup hooks, reset-cause folklore, and watchdog-trigger semantics do not quietly become a reviewed host↔guest control plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible lifecycle-signal contract under `ext.microvm`; there is no portable ACPI power-button / i8042-or-PL061 shutdown-reboot key / suspend-wakeup / reset-cause / watchdog-action plane, owner-local lifecycle-signal injection and reaction policy stays implementation-local, and microVM start-stop-reset authority still rides on explicit D-ACTIVATE supervision rather than ambient in-band guest device signals.**

Entropy cost justification: the archive already fixes guest-visible CPU/RAM/NIC/block/console shape at admission, keeps host↔guest channels killable, and keeps restart/resume meaning on explicit D-ACTIVATE / D-EPHEM seams. What remained underspecified was the lifecycle-control convenience layer where modern VMMs expose powerdown/reset/wakeup/watchdog behavior through ACPI devices, legacy keyboard controllers, GPIO keys, or host monitor APIs, and operators start to treat those signals as “the” portable management contract. One narrow posture closes that gap without inventing a lifecycle daemon, guest agent, or new control schema family.

## Posture (v0)

1) **No portable ambient guest-visible lifecycle-signal contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible lifecycle-signal contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard guest-visible way to receive host lifecycle requests or report reset/power causes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one stable power-button / reset / suspend / wakeup / watchdog device vocabulary exists inside the guest.”

2) **No portable ACPI power-button / i8042-or-PL061 shutdown-reboot key / suspend-wakeup / reset-cause / watchdog-action plane**
   - Phase 1 standardizes **no portable ACPI power-button / i8042-or-PL061 shutdown-reboot key / suspend-wakeup / reset-cause / watchdog-action plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-observed power-button events, Ctrl-Alt-Del or equivalent reboot/shutdown keys, guest sleep-state entry/wakeup hooks, reset-reason reporting, watchdog expiry consequences, or “guest graceful shutdown” signaling by device convention.
   - Implementations may internally expose some of these mechanisms locally, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local lifecycle-signal injection and reaction policy stays implementation-local**
   - Owner-local lifecycle-signal injection and reaction policy stays implementation-local.
   - Runtimes may choose ACPI-driven reboot/shutdown, a legacy i8042 path, an ARM GPIO shutdown key, a monitor/QMP command, an API action that halts the VM, or no graceful in-band signal path at all for one deployment class, but that does **not** create a portable reviewed promise about one guest-visible lifecycle device, one reset-cause vocabulary, or one watchdog action model.
   - In particular, per-runtime choices such as “powerdown requests become guest ACPI events”, “reboot exits the VMM”, or “watchdog expiry pauses/resets/kills the VM” remain host/runtime-local policy, not portable SlopOS interface meaning.

4) **D-ACTIVATE remains authoritative for lifecycle authority**
   - D-ACTIVATE remains authoritative for lifecycle authority.
   - Starting, stopping, killing, or replacing a microVM leaf is still an explicit supervisor/deployment action governed by the already-pinned activation and restore postures, not something delegated to an ambient guest-visible power-management side channel.
   - Guest cooperation may matter to one implementation’s local shutdown ergonomics, but it does **not** become the portable control seam that defines lifecycle authority for `ext.microvm`.

5) **Changing the lifecycle-signal stance is owner-local lifecycle or new admission, not a portable live control plane**
   - Changing the lifecycle-signal stance is owner-local lifecycle or new admission, not a portable live control plane.
   - Owners/runtimes may choose different local lifecycle-signal mechanisms for different reviewed leaves or deployment classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable power/reset/watchdog protocol under the same admitted identity.
   - If policy cares about a different lifecycle-signal stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden host↔guest lifecycle contract by convention.

6) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for power-state or reset/watchdog signaling, **no new ACP kind**, and **no new conflict-key family** for power-button injection, graceful-shutdown requests, wakeup, reset-cause mutation, or watchdog-action changes under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `request_guest_shutdown`, `inject_power_button`, `wake_guest`, `set_watchdog_action`, or `query_reset_cause`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that microVM guests always see one standard graceful-shutdown/reboot device or event source.
- No portable suspend/wakeup or reset-cause reporting contract under `ext.microvm`.
- No portable watchdog expiry/action semantics for guest-visible lifecycle control.
- No generic lifecycle-signal broker, guest agent, or public power-state inventory API.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `microvm-guest-agent-posture-v0.md`
  - `activation-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
- Adjacent notes:
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-24)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-LIFECYCLESIGNAL)
- Policy posture:
  - lifecycle signaling adds **no new lane**, **no public guest power/reset/watchdog control plane**, and **no portable in-place lifecycle protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_lifecycle_signal_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible lifecycle-signal contract / no portable ACPI-power-button-i8042-or-PL061-shutdown-reboot-key-suspend-wakeup-reset-cause-watchdog-action plane / owner-local lifecycle-signal injection and reaction policy stays implementation-local / D-ACTIVATE remains authoritative / changing lifecycle-signal stance is owner-local lifecycle or new admission not a portable live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-KERNEL-POLICY.
- REF-CHYP-DEVICE-MODEL.
- REF-QEMU-QMP-LIFECYCLE.
