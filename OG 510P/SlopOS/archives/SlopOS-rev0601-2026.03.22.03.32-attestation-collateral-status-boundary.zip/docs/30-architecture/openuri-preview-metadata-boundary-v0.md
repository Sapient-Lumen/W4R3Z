# D-PLUMB OpenURI preview-metadata boundary v0 (no portable link-preview / unfurl seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable link-preview, unfurl, title/icon/image extraction, metadata-fetch, or preview-card workflow on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable preview / unfurl seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `preview`, `fetch_metadata`, `unfurl`, `preview_card`, `preview_title`, `preview_description`, `preview_image`, `preview_icon`, `favicon`, `open_graph`, `oembed`, or equivalent link-preview / unfurl field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Preview metadata stays request-local or provider-local rather than transcript truth.**
   - A shell, browser, chat surface, or other handler may choose local UX for showing previews, cards, or metadata hints.
   - Phase 1 does **not** reinterpret that provider-local behavior as a portable requester-visible result, stable receipt, or transcript-stable statement that a particular title/image/description was fetched.
   - Generic OpenURI therefore stays launch-oriented rather than becoming a metadata oracle for arbitrary URIs.

3) **Dereferencing for preview is a second workflow, not generic launch.**
   - Fetching preview metadata may imply network access, local thumbnailing, media fetches, caching, or parser behavior that differs from the eventual launched handler.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to crawl the target, extract Open Graph/oEmbed metadata, fetch preview media, or emit a reusable preview object.
   - If a future product shape needs reviewed link-preview generation, classification, or preview-card export, that belongs on a future RFC-first fetch/preview seam rather than as a side effect of generic launch.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. Apple Link Presentation explicitly retrieves metadata from a URL and presents rich link content; Slack unfurling crawls posted links and builds previews; the Open Graph protocol standardizes the metadata many preview systems consume.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate extra fetch, parse, cache, and representation semantics that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new preview/unfurl action family, conflict-key family, or serialization surface.
   - Any future preview/metadata seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser/chat UX.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “peek this URL”, “unfurl this link”, or “fetch me a title/icon/card first” behavior through helper fallbacks.
   - If compat needs reviewed preview or metadata-fetch workflows, it still pays for an explicit future seam rather than smuggling metadata fetch through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `preview`, `fetch_metadata`, `unfurl`, `preview_card`, `preview_title`, `preview_description`, `preview_image`, `preview_icon`, `favicon`, `open_graph`, or `oembed` knob/result on generic OpenURI.
- No portable title/icon/description/image receipt or transcript-stable preview object on generic URI launch.
- No shell/helper fallback that quietly crawls the target, parses metadata tags, fetches preview media, or caches preview output and reports that second workflow as OpenURI truth.
- No portable preview-card export or reusable unfurl object on generic URI launch.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, and non-materializing, but another tempting convenience import still lingers in mainstream ecosystems: “while you’re opening this URI, can you also fetch the title, icon, card, or other rich preview?” That sounds harmless, but it quietly turns a launch seam into a fetch/parse/cache/representation broker, which is much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a link-preview or unfurl substrate. That matters for all four product shapes: workstation UX can still render local previews without standardizing crawler semantics; hosted and embedded profiles avoid carrying preview-fetch machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to crawl arbitrary links for metadata.

## Profile effect (A–D)

- **Secure workstation (A):** shells and apps may still show local preview UI, but generic OpenURI does not standardize preview-fetch or preview-card truth as app-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting browser/chat crawler behavior or preview-cache semantics from desktop/app folklore.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising preview-metadata fetch or rich-card behavior they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “crawl this URI for metadata”; reviewed preview/classification work stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_preview_metadata_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable preview / unfurl seam / preview metadata stays request-local-or-provider-local / dereferencing-for-preview stays a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-584**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-APPLE-LINKPRESENTATION.
- REF-SLACK-UNFURLING-LINKS.
- REF-SLACK-ROBOTS.
- REF-OPEN-GRAPH-PROTOCOL.
