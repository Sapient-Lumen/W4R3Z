# D-CC SNP launch-identity claim boundary v0 (owner-authored launch identity fields are exact evidence only)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP owner-authored launch identity fields** so `FAMILY_ID`, `IMAGE_ID`, `ID_KEY_DIGEST`, and `AUTHOR_KEY_DIGEST` do not quietly become portable SlopOS attestation claims, rollout identities, or hidden policy channels.

Entropy cost justification: the archive already pinned one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, and one SNP guest-mode cut. What remained ambiguous was narrower and worth deciding now: **SNP attestation reports also expose owner-authored launch labels and owner-signer digests, but the archive had not yet said whether those fields become portable SlopOS image/release identity meaning**. One small boundary closes that gap without inventing a new schema, identity registry, or verifier language.

## Posture (v0)

1) **`FAMILY_ID` / `IMAGE_ID` are owner-authored launch labels, not portable SlopOS attestation claims**
   - AMD’s SNP firmware ABI defines `FAMILY_ID` and `IMAGE_ID` in the ID block as values **provided by the guest owner and uninterpreted by the firmware**.
   - The attestation report then carries the `FAMILY_ID` and `IMAGE_ID` that were provided at launch.
   - Phase 1 therefore treats those fields as **exact provider-native evidence bytes only**. They do **not** become native `CH-ATTEST` claims, portable workload/image names, or a reviewed SlopOS release identity.

2) **`ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST` are owner-signer evidence, not portable release-identity claims**
   - AMD’s SNP firmware ABI defines `ID_KEY_DIGEST` as the SHA-384 digest of the ID public key that signed the ID block and `AUTHOR_KEY_DIGEST` as the SHA-384 digest of the Author public key that certified that ID key when present.
   - Those digests therefore describe the owner-authored signing material used for `SNP_LAUNCH_FINISH`; they are not themselves a portable SlopOS signer role, image lineage schema, or release-channel identity.
   - Phase 1 keeps them as **exact provider-native evidence only** unless explicit verifier-local policy says more.

3) **These launch-identity fields do not substitute for `boot_digest`, `prov_digest`, or exact `cc_report_data_v0` binding**
   - The already-pinned D-CC binder contract uses exact `cc_report_data_v0` in the provider-native `REPORT_DATA` / `REPORTDATA` carrier, and `CH-ATTEST` binds portable meaning through `boot_digest` (and optional `prov_digest` / freshness fields).
   - `FAMILY_ID`, `IMAGE_ID`, `ID_KEY_DIGEST`, and `AUTHOR_KEY_DIGEST` MUST NOT be used as substitutes for boot/provenance binding, freshness binding, or the exact verifier challenge contract.
   - A verifier that accepts SNP evidence MUST therefore check `boot_digest` / `prov_digest` / `cc_report_data_v0` on their own terms and MUST NOT treat matching owner-authored launch labels or key digests as satisfying those portable proof obligations.

4) **Packaging/export does not upgrade launch-identity fields into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `FAMILY_ID`, `IMAGE_ID`, `ID_KEY_DIGEST`, and `AUTHOR_KEY_DIGEST`.
   - If tooling wants to preserve extracted values for audit or forensic review, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable SNP image/release identity schema.
   - Exporting a report that contains those fields does not imply that remote consumers may treat them as reviewed SlopOS-native naming or signer meaning.

5) **Secret release, rollout, and automation policy must name any SNP launch-identity appraisal explicitly**
   - A deployment-specific verifier MAY inspect exact `FAMILY_ID`, `IMAGE_ID`, `ID_KEY_DIGEST`, or `AUTHOR_KEY_DIGEST` bytes as supporting evidence for local/provider-specific appraisal (for example, an owner-local ring, launch class, or signer allowlist).
   - That interpretation remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS rule.
   - No default D-CC path, agent workflow, or rollout gate may silently inherit those fields as a portable allow/deny signal or as a globally meaningful release taxonomy.

6) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of a small set of already-existing provider-native SNP report fields.
   - It introduces no new workflow kind, no serialization surface, and no portable owner-identity query plane.

## Phase 1 non-goals (explicitly deferred)

- No `family_id`, `image_id`, `id_key_digest`, or `author_key_digest` field in `CH-ATTEST v0`.
- No portable SNP image-family registry, release-channel schema, or signer-identity taxonomy.
- No default verifier rule that owner-authored launch labels or signer digests imply SlopOS release identity.
- No new workflow / ACP / conflict-key family for owner-authored SNP launch identity in v0.

## Why this boundary exists

The archive had already fixed the portable binding and trust seams, but AMD’s ABI still left another tempting implementation shortcut:
- `FAMILY_ID` / `IMAGE_ID` are owner-authored launch labels,
- `ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST` are owner-signer digests,
- and all four ride in the attestation report.

Without one explicit rule, the first SNP verifier, rollout gate, or secret-release harness would predictably start doing one of these by convention:
- treating `IMAGE_ID` as the portable release name,
- treating `FAMILY_ID` as a cross-provider workload taxonomy,
- treating `ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST` as a built-in signer identity schema,
- or letting agents rely on provider/owner folklore about what those fields “mean.”

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **owner-authored launch labels and key digests remain exact evidence unless local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a portable SNP image/release identity schema**,
- and **automation cannot inherit a hidden owner/provider naming channel through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve owner-authored SNP launch labels for audit without importing hosted-image folklore into portable workstation attestation meaning.
- **Cloud micro-VM substrate (B):** hosted-compute verifiers may still use owner-local image rings or signer allowlists, but only under explicit local policy rather than by widening D-ATTEST into a portable cloud image taxonomy.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling can retain exact SNP report values for audit without admitting a provider-native image-family or signer-identity schema into the appliance core.
- **Agent / automation OS (D):** agents can inspect exact launch labels and signer digests, but they do not get a silent owner-authored approval shortcut; any such appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP owner-authored launch-identity seam.

If a second closely related D-CC provider-field identity boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_launch_identity_claim_boundary.py` (**EVID-2026-539**).

## References

- REF-AMD-SNP-FWABI.
- REF-RATS-RFC9334.
