# Attestation result boundary v0 (verifier-generated results stay imported evidence; no native verdict/result plane)

Purpose: pin the Phase-1 meaning of **verifier-generated attestation results** across **D-ATTEST** and **D-POLICY** so the archive does not quietly overload imported EAR / AR4SI-style result artifacts into a portable approval, session-currentness, or “currently trusted” control plane.

Entropy cost justification: `attestation-posture-v0.md` already keeps attestation export observational and killable, `attestation-endorsement-boundary-v0.md` already keeps endorsements/reference values verifier-local, and `attestation-freshness-boundary-v0.md` already keeps nonce/challenge semantics verifier-local. The remaining ambiguity is narrower and still expensive: **what verifier-generated attestation results are allowed to mean once they travel as artifacts or attachments**. One small boundary closes that gap without inventing a new schema family, result cache, or verifier RPC.

This doc is a **family member of the closed D-ATTEST companion boundary family** rooted at `attestation-boundary-index.md`.

## Posture (v0)

1) **Verifier-generated attestation results are imported evidence about one appraisal event, not ambient truth.**
   - A verifier may emit a result artifact about exact evidence under one trust-root set, one appraisal policy revision, and one freshness context.
   - That artifact is evidence about that appraisal event; it is not a portable evergreen truth that the attester or platform is “good”, “current”, or “approved” in general.

2) **No native attestation-result / verifier-verdict schema in v0.**
   - Phase 1 standardizes no native attestation-result carrier, verifier-verdict object, EAR-normalized core schema, or equivalent privileged-core result format.
   - IF-ATTEST exports evidence only; it does not mint a native verifier verdict or relying-party authorization object.

3) **Imported result vocabularies stay evidence, not portable approval or admission authority.**
   - Imported EAR / AR4SI-style trustworthiness vectors, verdict labels, policy hints, and result claims may be preserved as exact evidence attachments.
   - They do not by themselves authorize install, boot, network admission, secret release, or workflow progress.
   - Any such decision remains explicit relying-party / owner-local policy over the exact evidence presented.

4) **Result meaning is scoped to verifier identity, roots, policy, and freshness context.**
   - A result only has meaning together with the verifier identity, trust roots, appraisal policy revision, endorsement/reference corpus, and freshness assumptions that produced it.
   - Replaying the same result in a different deployment, under different roots, or after policy/freshness drift does not silently preserve the same meaning.

5) **No native attestation-result query, latest-result, or watch plane in v0.**
   - Phase 1 standardizes no `get_attestation_result`, `latest_attestation_result`, `watch_attestation_status`, `result_feed`, or similar surface.
   - Any publication, caching, or retrieval of verifier-generated results remains explicit tooling and killable policy, not a portable substrate service.

6) **Forwarded or re-signed results do not outrun local policy or replace exact evidence.**
   - A forwarded, mirrored, wrapped, or re-signed verifier result remains second-order evidence about a prior appraisal event.
   - It does not replace exact attestation evidence, endorsement/reference policy, or local authorization logic.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing attestation and evidence seams are interpreted.
   - Any future portable attestation-result publication, acknowledgement, or relying-party workflow must pay for its own RFC, conflict keys, serialization story, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native attestation-result or verifier-verdict schema.
- No portable “currently trusted” / “currently healthy” / “approved for relying parties” plane.
- No verifier-result cache/query/watch API.
- No rule that an imported result artifact overrides local attestation, endorsement, or freshness policy.
- No ambient translation of result vocabularies into SlopOS approval or waiver authority.

## Why this is worth pinning

The surrounding ecosystem is explicitly split:
- RFC 9334 keeps **Evidence**, **Appraisal Policy for Evidence**, **Attestation Results**, and **Relying Party** decisions as distinct roles and message classes.
- the current EAR draft defines a verifier-produced result format that encodes appraisal output, not a universal authorization object;
- the current AR4SI draft defines reusable result information elements precisely so relying parties can apply **their own** subsequent policies instead of inheriting one ambient approval rule.

Pinning that split now prevents SlopOS from slowly reinventing a hidden trust-distribution, “current platform trust”, or approval badge plane under the names of attestation export, cached verifier results, or imported relying-party hints.

## Profile effect (A–D)

- **Secure workstation (A):** workstation security tools may cache verifier-produced results for operator review, but local trust/admission policy stays explicit and inspectable.
- **Cloud micro-VM substrate (B):** fleet verifiers may emit signed results, yet admission and secret release remain relying-party/local policy rather than “result says trusted therefore allow”.
- **Embedded / separation appliance (C):** constrained verifiers can forward imported result artifacts as evidence, but the appliance does not inherit a native online status or watch plane.
- **Agent/automation OS (D):** agents may consume verifier-produced result artifacts as evidence, but they cannot smuggle in “trusted now” authority through ambient result feeds or cached status labels.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATTEST**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/attestation-posture-v0.md`
  - `docs/30-architecture/attestation-token-schema-v0.md`
  - `docs/30-architecture/attestation-pack-schema-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
- Engineering / profile surfaces:
  - `rfcs/0064-confidential-computing-profile.md`
  - `docs/30-architecture/interface-registry.md`
- Assurance anchors:
  - **I-ATTEST-1**.
  - **PO-ATTEST-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_attestation_result_boundary.py` keeps the split small and discoverable (**EVID-2026-611**).

## References

- **REF-RATS-RFC9334**
- **REF-RATS-EAR-DRAFT**
- **REF-RATS-AR4SI-DRAFT**
