# SBOM external-document supersession boundary v0 (`serialNumber` / BOM `version` / SPDX document namespace stay imported document identity, not native latest-wins authority)

Purpose: pin the Phase-1 meaning of **external SBOM document identity/version fields imported through CH-AREF** across **D-SBOM**, **D-AREF**, **D-TIME**, and **D-POLICY** so CycloneDX `serialNumber` + BOM `version`, SPDX document namespace, and similar document-versioning hints do not quietly become a native latest-wins, freshness, or replacement plane.

Entropy cost justification: the archive already keeps CH-SBOM digest-bound, keeps evidence discovery explicit, keeps policy selection verifier-local, and keeps component labels (`bom-ref`, `purl`, `version`) out of native identity semantics. What remains cheap-but-dangerous is the **document-level** identity layer that rich SPDX/CycloneDX ecosystems already carry: CycloneDX says later BOM versions supersede earlier ones for one serial number, SPDX says an updated document gets a new namespace, and tools naturally start treating those document identifiers as a portable “newest inventory wins” rule. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still point at rich external SPDX/CycloneDX documents via `external_doc_aref`.
- **CH-AREF v0** may still bind one exact imported SBOM document by digest.
- **Verifier-local policy/tooling** may still compare external document identity/version fields, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **External SBOM document identity/version fields stay imported document metadata only.**
   - CycloneDX `serialNumber`, BOM `version`, SPDX document namespace, and similar external-document identifiers remain imported evidence about one external document instance.
   - Phase 1 therefore treats those fields as document-identity metadata, not as a native SlopOS freshness oracle, replacement selector, or latest-wins rule.
   - Seeing the same serial number, a higher BOM version, or a “newer-looking” SPDX namespace carries no portable supersession meaning by itself.

2) **Exact document binding still rides on CH-AREF digest, not document-version folklore.**
   - When `external_doc_aref` is present on CH-SBOM, the portable binding is still the exact digest of the selected CH-AREF object and the exact external document bytes it resolves to.
   - Companion `release-identity-boundary-v0.md` already pins release names/version strings/slugs to observational meaning only.
   - This boundary further pins that external SBOM document identifiers stay on the same non-native side of the line even when upstream tooling encourages versioned document supersession.

3) **Phase 1 imports no native “latest SBOM document wins” rule.**
   - CycloneDX may recommend using the most recent BOM version when serial numbers match, and SPDX may require a new namespace for updated document versions.
   - Phase 1 does **not** import a native rule such as “same serial + higher BOM version supersedes,” “later-created SPDX namespace wins,” “newest document for one product replaces older evidence,” or “document identity selects the verification target.”
   - Any such comparison logic stays explicit verifier-local policy under **D-POLICY** rather than leaking into CH-SBOM / CH-AREF / CH-UPD / CH-BOOT meaning.

4) **Document identity/version fields do not widen freshness or trust meaning.**
   - CycloneDX BOM `version`, SPDX document namespace, creator timestamps, and similar metadata may inform local review.
   - They do **not** by themselves prove freshness, trusted publication time, approved replacement, or compatibility with the already-bound install subject.
   - Freshness and replay policy still ride on explicit **D-TIME**, **D-SIGENV**, **D-TLOG**, and verifier-local policy rather than unsigned or externally-versioned document metadata.

5) **Multiple external SBOM documents stay multiple exact evidence inputs unless another seam admits more.**
   - A verifier may explicitly choose between multiple external SPDX/CycloneDX documents, compare them, or prefer one.
   - That choice remains local policy/tooling; Phase 1 does **not** promote document-versioning folklore into a native cross-document merge, supersession, or completeness rule.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that several exact inventory/exploitability artifacts do not become one native applicability closure merely because they are attached together.

6) **No native fetch/discovery/replacement plane rides on document identifiers.**
   - `serialNumber`, BOM `version`, document namespace, or related metadata do not imply where to fetch the next document, which mirror is authoritative, or whether a replacement exists.
   - Companion `verification-material-discovery-boundary-v0.md` already pins that finding more verification/evidence material is explicit and killable rather than ambient.
   - Phase 1 adds no native SBOM document catalog, latest-by-namespace resolver, or update-by-document-identity workflow.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported document-level SBOM identity/version fields fit with existing SBOM/evidence/time/policy seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native external-SBOM latest-wins / supersession / replacement rule.
- No portable rule that CycloneDX `serialNumber` + BOM `version` or SPDX document namespace chooses the preferred document.
- No ambient fetch/discovery plane keyed by external document identifiers.
- No migration of freshness / trust / replay / approval semantics onto SBOM document metadata.
- No cross-document merge / delta / completeness rule inferred from document-version fields.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but richer than the small digest-first authority substrate we want:
- CycloneDX says the BOM `version` should be incremented when a BOM changes and that when multiple BOMs with identical serial numbers are presented, systems should use the most recent version.
- SPDX says the document namespace must be unique for a specific version of an SPDX document and that an updated document must use a new namespace.

Those are sensible document-management rules inside their ecosystems. But if we import them naively, one external inventory format starts smuggling a native “newer inventory replaces older evidence” rule into SlopOS. Pinning the split now keeps exact evidence binding on digests while leaving richer document-management behavior explicit and local.

## Profile effect (A–D)

- **Secure workstation (A):** rich third-party SBOM feeds may carry revised inventories without silently replacing the exact evidence already reviewed for one install subject.
- **Cloud micro-VM substrate (B):** fleet tooling may compare multiple vendor SBOM revisions, but portable install/evidence meaning stays exact and digest-bound rather than doc-version-driven.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can ignore external latest-wins document folklore and require exact CH-AREF/CH-SBOM bindings only.
- **Agent/automation OS (D):** agents may reason over rich SPDX/CycloneDX document identity/version fields, but they cannot smuggle “newer SBOM document wins” into portable authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-AREF**, **D-TIME**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/release-identity-boundary-v0.md`
  - `docs/30-architecture/decision-map.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0091-sbom-artifacts-and-closure-binding.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-AREF-1**, **I-TIME-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_document_supersession_boundary.py` keeps the split small and discoverable (**EVID-2026-491**).

## References

- **REF-CYCLONEDX-BOM-IDENTITY**
- **REF-SPDX-DOC-NAMESPACE**
