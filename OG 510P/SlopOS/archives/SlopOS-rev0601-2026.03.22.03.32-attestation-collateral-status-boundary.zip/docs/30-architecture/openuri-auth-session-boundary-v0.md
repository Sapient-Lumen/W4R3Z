# D-PLUMB OpenURI auth-session boundary v0 (no portable browser-auth / SSO / OAuth login seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable browser-auth session, SSO/login handoff, redirect-capture workflow, or equivalent auth-specific browser control surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable browser-auth/session seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `auth_session`, `authenticate`, `web_auth`, `oauth`, `oidc`, `sso`, `callback_scheme`, `redirect_uri`, `redirect_host`, `redirect_path`, `prefer_ephemeral_session`, `prefer_ephemeral_browser_session`, `account_chooser`, `credential_broker`, or equivalent auth-session field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Browser-auth session state and outcomes stay request-local or handler-local rather than transcript truth.**
   - A shell, browser, or other handler may choose local UX/security behavior such as presenting a specialized authentication tab, suppressing general browser chrome, enforcing same-publisher redirect checks, or isolating browser state for a one-off login flow.
   - Phase 1 does **not** reinterpret that provider-local behavior as a portable requester-visible result, stable receipt, or transcript-stable statement that a login session was created, an account chooser ran, a redirect URI was captured, or an authentication result was returned.
   - Generic OpenURI therefore stays launch-oriented rather than becoming a reusable browser-auth broker for arbitrary URIs.

3) **Browser-auth is a second workflow, not generic launch.**
   - Dedicated browser-auth APIs allocate additional semantics: explicit redirect interception, browser-owned login/session UX, same-origin or same-publisher checks, ephemeral/private browsing controls, and app-visible auth-result handling.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to start an auth session, capture a redirect result, or negotiate browser-owned login state on the requester’s behalf.
   - If a future product shape needs reviewed browser-auth or federated-login workflows, that belongs on a future RFC-first auth/web-session seam rather than as a side effect of generic launch.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. RFC 8252 recommends native-app OAuth flows use an external user-agent, primarily the user’s browser. Apple exposes `ASWebAuthenticationSession` for authenticating a user through a web service. Chrome’s Auth Tab is a specialized Custom Tab for end-to-end authentication and returns results to the client app through redirect callbacks, with optional fallback and privacy/session controls on adjacent auth-tab APIs.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate extra redirect, session, identity, and callback semantics that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new browser-auth / login action family, conflict-key family, or serialization surface.
   - Any future browser-auth seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from platform login APIs.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this URL and also run a browser-mediated login / redirect capture / SSO handshake” behavior through helper fallbacks.
   - If compat needs reviewed browser-auth workflows, it still pays for an explicit future seam rather than smuggling login/session authority through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `auth_session`, `authenticate`, `web_auth`, `oauth`, `oidc`, `sso`, `callback_scheme`, `redirect_uri`, `redirect_host`, `redirect_path`, `prefer_ephemeral_session`, `prefer_ephemeral_browser_session`, `account_chooser`, or `credential_broker` knob/result on generic OpenURI.
- No portable login-session-created, redirect-captured, account-selected, or auth-result receipt on generic URI launch.
- No shell/helper fallback that quietly promotes `open_uri` into a browser-auth or federated-login workflow and reports that second workflow as OpenURI truth.
- No portable browser-auth, SSO, or redirect-capture control plane on generic URI launch.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, free of callback folklore, and free of session-selection semantics, but one more convenience import still lingers in mainstream mobile/browser APIs: “while you’re opening this URI, can you also treat it as an authentication flow and hand me back the result?” That sounds app-friendly, but it quietly turns a launcher seam into a browser-auth broker with session/privacy/callback semantics that are much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into browser-auth authority. That matters for all four product shapes: workstation UX can still use local browser-auth tooling without standardizing it as app-visible substrate meaning; hosted and embedded profiles avoid inheriting fake login/session machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to initiate or complete OAuth/SSO flows.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still offer local browser-auth UX, but generic OpenURI does not standardize auth-session/result semantics as app-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting ambient browser-login/session state, redirect interception, or fake SSO machinery they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising browser-auth/session workflows they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “initiate or complete an auth session for this URI”; reviewed login/session control stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_auth_session_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable browser-auth/session seam / browser-auth session state and outcomes stay request-local-or-handler-local / browser-auth is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-587**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-RFC8252-NATIVE-APPS.
- REF-APPLE-ASWEBAUTHSESSION.
- REF-CHROME-AUTH-TAB.
- REF-CHROME-EPHEMERAL-CUSTOM-TABS.
- REF-APPLE-ASWEBAUTH-EPHEMERAL.
