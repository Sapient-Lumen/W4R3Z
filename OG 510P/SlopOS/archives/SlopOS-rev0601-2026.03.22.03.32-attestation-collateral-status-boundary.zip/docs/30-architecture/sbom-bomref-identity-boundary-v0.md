# SBOM `bom-ref` identity boundary v0 (`bom-ref` stays document-local join syntax, not a native cross-artifact component identity)

Purpose: pin the Phase-1 meaning of **CycloneDX `bom-ref` labels imported through SBOM/VEX adjunct evidence** across **D-SBOM**, **D-VEX**, **D-AREF**, **D-ATOMICUPD**, and **D-BOOT** so one local identifier from one external BOM document cannot quietly become a portable component-identity root, cross-artifact join key, suppression handle, or applicability oracle.

Entropy cost justification: the archive already pins CH-SBOM / CH-VEX as digest-bound evidence and already keeps stable component identity on exact `content_digest` / `build_id` when available, but real CycloneDX ecosystems encourage rich graph-local joins via `bom-ref`. Leaving that relationship unstated invites expensive drift later: one external SBOM label starts acting like a native component identity across imported BOMs, linked VEX statements, and release bundles. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** still carries a bounded normalized component list and may point at one external SPDX/CycloneDX document via `external_doc_aref`.
- **CH-VEX v0** still carries one already-bound subject plus one bounded statement set, and any finer component-scoping remains exact encoded statement content or verifier-local imported reasoning.
- **Verifier-local policy/tooling** may still parse external CycloneDX documents and correlate local `bom-ref` values inside those documents, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **`bom-ref` is a document-local imported label only.**
   - When an external CycloneDX document is attached through `external_doc_aref`, each `bom-ref` is an identifier that is only guaranteed to be unique within that BOM document.
   - Phase 1 therefore treats `bom-ref` as imported evidence syntax for local joins inside that one document, not as a native SlopOS component identity root.
   - Reusing the same `bom-ref` bytes in a different BOM, VEX document, or release bundle carries no portable same-component meaning by itself.

2) **CH-SBOM native component identity still rides on stable identifiers when available.**
   - `content_digest` and `build_id` remain the portable component-binding fields under **I-SBOM-2**.
   - Companion `sbom-posture-v0.md` already pins `name`, `version`, `purl`, `supplier`, and `licenses` as observational only.
   - This boundary further pins that imported CycloneDX `bom-ref` labels stay on the same non-native side of the line.

3) **No native cross-artifact `bom-ref` join rule exists in Phase 1.**
   - A CH-VEX statement, CH-SBOM external document, CH-UPD `artifacts[]` set, or CH-BOOT `artifacts[]` set does not gain a portable rule such as “join by matching `bom-ref` strings.”
   - Any correlation between a VEX component claim and an external CycloneDX component via `bom-ref` remains verifier-local imported reasoning, not carrier-visible semantics.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that multiple exact SBOM/VEX artifacts do not become one native applicability closure merely because they travel together.

4) **`bom-ref` does not widen absence, remediation, or suppression meaning.**
   - Matching one `bom-ref` from one external BOM to one advisory row does not by itself prove global component absence, global remediation coverage, or cross-artifact vulnerability suppression.
   - Companion `vex-component-absence-boundary-v0.md` already pins that `component_not_present` plus one linked inventory does not become a native absence oracle.
   - Companion `vex-vulnerability-identity-boundary-v0.md` already pins that `vuln_id` is one exact advisory label only; `bom-ref` must not become the back door for a hidden wider suppression graph.

5) **Document-local graph semantics stay imported evidence unless another seam admits more.**
   - CycloneDX dependency graphs, compositions, services, formulations, annotations, and other object references may use `bom-ref` extensively.
   - Those may help local tooling reason about one imported document, but Phase 1 does **not** promote those graph-local joins into a native privileged-core component graph or cross-document identity language.
   - Companion `verification-material-discovery-boundary-v0.md` still pins that discovering more such material stays explicit and killable rather than ambient.

6) **Exact artifact binding still happens on the existing seams.**
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds the exact subject digest the verifier cares about.
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds that same subject digest.
   - **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, and **PO-AREF-VERIFY** still answer carrier/evidence integrity for the already-pinned cohort.
   - No portable “same component”, “same dependency node”, or “same advisory scope” verdict is created merely by co-packaging CycloneDX documents that reuse or cross-reference `bom-ref` labels.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported CycloneDX local identifiers fit with existing SBOM/VEX/update/boot seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `bom-ref` field on CH-SBOM or CH-VEX.
- No portable cross-document `bom-ref` resolver, canonicalizer, alias graph, or same-component oracle.
- No rule that matching `bom-ref` strings across SBOM/VEX documents creates suppression, completeness, remediation, or applicability semantics.
- No import of full CycloneDX object-graph semantics into the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- CycloneDX says `bom-ref` identifies an object **elsewhere in the BOM** and must be unique **within the BOM**.
- The CycloneDX guide even recommends human-friendly choices like PURL or UUID because `bom-ref` is an internal document reference, not a globally standardized component-identity root.
- Once VEX, SBOM, and external-doc attachment are all available, it becomes extremely tempting to treat one convenient local label as the hidden join key for broader policy behavior.

Pinning that split now keeps SlopOS from quietly inheriting “matching `bom-ref` means same component everywhere” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** local scanners may still ingest rich CycloneDX documents, but one imported document label cannot silently suppress or widen advisory meaning across apps.
- **Cloud micro-VM substrate (B):** fleet pipelines may attach many third-party BOMs, but portable install/applicability semantics stay on exact digests rather than graph-local labels.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a full cross-document `bom-ref` graph engine.
- **Agent/automation OS (D):** agents may reason over imported BOM graphs, but they cannot smuggle “matching local label means same component” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-component-absence-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-SBOM-2**, **I-VEX-1**, **I-AREF-1**, **I-ATOMICUPD-1**, **I-BOOT-1**.
  - **PO-SBOM-BIND**, **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_bomref_identity_boundary.py` keeps the split small and discoverable (**EVID-2026-488**).

## References

- **REF-CYCLONEDX-BOMREF**
- **REF-CYCLONEDX-DEPENDENCIES**
- **REF-OPENVEX-SPEC**
