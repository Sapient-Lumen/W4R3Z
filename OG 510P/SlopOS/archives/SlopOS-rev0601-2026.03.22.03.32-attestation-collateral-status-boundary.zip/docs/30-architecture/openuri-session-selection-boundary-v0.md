# D-PLUMB OpenURI session-selection boundary v0 (no portable browser-session/profile selection seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable browser-session, profile, cookie-jar, or private/incognito/ephemeral-mode selection surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable browser-session / profile selection seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `private`, `incognito`, `ephemeral_session`, `ephemeral_browsing`, `profile_id`, `browser_profile`, `cookie_jar`, `share_cookies`, or equivalent browser-session/profile selection field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Handler-local browsing state stays handler-local and non-authoritative.**
   - A chosen handler may open using its default shared browser state, an ephemeral/private state, a browser-specific auth session, or some other local profile/session mode.
   - That does **not** make cookie-jar choice, account/profile selection, history retention mode, credential sharing, or session isolation portable portal meaning.
   - Phase 1 therefore declines treating OpenURI as a browser-session-control, cookie-jar-selection, or auth-session-mode seam just because real handlers may implement those choices internally.

3) **Explicit auth/web-session workflows stay on explicit seams, not generic launch.**
   - If a product shape later needs reviewed ephemeral-web-auth, browser-profile selection, shared-vs-private session choice, or explicit cookie/state isolation guarantees, that belongs on a future RFC-first auth/web/session seam rather than as a side effect of generic launch.
   - Existing explicit seams already show the pattern: `portal.net` leases govern network authority, while richer web/auth ecosystems expose session-mode controls on dedicated APIs rather than overloading generic URI launch.
   - Generic OpenURI therefore stays a mediated launch workflow, not a browser-session or cookie-jar control envelope for the chosen handler.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. XDG OpenURI keeps the portable request shape deliberately small: the `OpenURI` options are limited to mediation metadata such as `handle_token`, `writable`, `ask`, and `activation_token`, not browser-session or profile selectors.
   - Android documentation explicitly says Custom Tabs normally share cookies with the user’s default browser, while Chrome now documents Ephemeral Custom Tabs as a distinct opt-in isolated browser session where cookies, history, credentials, and cached files exist only for that session.
   - Apple AuthenticationServices likewise exposes `prefersEphemeralWebBrowserSession` to request a private authentication session.
   - SlopOS imports the narrow lesson: `open_uri` can ask the shell to launch a URI, but it does not become a generic browser-profile / cookie-jar / ephemeral-session selection plane.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new browser-session-control action family, conflict-key family, or serialization surface.
   - Any future auth/web/admin seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser-launch UX.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this URL in incognito / private / profile X” behavior through helper fallbacks.
   - If compat needs reviewed session/profile choice, it still pays for an explicit future seam rather than smuggling browser-state control through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `private`, `incognito`, `ephemeral_session`, `ephemeral_browsing`, or equivalent OpenURI knob.
- No portable `profile_id`, `browser_profile`, `cookie_jar`, `share_cookies`, or equivalent browser-state selection field on generic URI launch.
- No browser-session/auth-session contract that treats handler-local cookie/profile choices as portable portal truth.
- No host-helper fallback that quietly turns generic URI launch into a browser-profile or private-browsing selection API.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, and non-materializing, but one tempting convenience import still lingers in mainstream ecosystems: “can I open this URL in a private/ephemeral session, or in a chosen browser profile with a chosen cookie jar?” That sounds small, but it quietly turns a launch seam into a browser-session-control surface, which is much harder to reason about for authority, transcript truth, and cross-profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a browser-specific session/profile plane. That matters for all four product shapes: workstation UX can still launch links without standardizing cookie-jar/profile knobs; hosted and embedded profiles avoid carrying a fake browser-session API they do not want; and agent tooling cannot mistake `open_uri` for a reviewed web-auth/session-control seam.

## Profile effect (A–D)

- **Secure workstation (A):** browsers/viewers may still have rich local session behavior, but generic OpenURI does not standardize private/incognito/profile selection as app-visible substrate truth.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting a fake browser-session/profile control plane from desktop launcher folklore.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising browser-profile/cookie-jar controls they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “launch this URI in a chosen auth/profile state”; reviewed web-auth/session control stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_session_selection_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable browser-session/profile selection seam / handler-local browsing state stays handler-local / explicit auth/web-session control stays on explicit seams / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-582**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-INAPP-BROWSING-CUSTOM-TABS.
- REF-CHROME-EPHEMERAL-CUSTOM-TABS.
- REF-APPLE-ASWEBAUTH-EPHEMERAL.
