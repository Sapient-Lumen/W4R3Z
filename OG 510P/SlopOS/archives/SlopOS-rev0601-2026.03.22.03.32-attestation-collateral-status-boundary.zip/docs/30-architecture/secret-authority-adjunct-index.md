# Secret-authority adjunct index (closed secret-bearing authority posture family)

Purpose: keep the current **secret-bearing authority posture family** recoverable as one closed discovery surface.
Why this exists:
The archive already pins minimal app-scoped seeds, ref-bound secret storage, and explicit-route crypto/key use individually, but humans/LLMs should not have to rediscover the current **D-APPSECRET / D-VAULT / D-CRYPTOSVC** runtime story by opening three separate posture docs in sequence when they are trying to understand one worth-coding secret-handling substrate slice.

This doc does **not** create a universal secret broker, a named secret inventory/search API, an ambient agent socket, an implicit sync/recovery plane, or a second portable auth-agent API beside IF-CRYPTOSVC.
It keeps the current **D-APPSECRET / D-VAULT / D-CRYPTOSVC** posture set closed, enumerable, and reviewable as one implementation-facing surface for shapes **A/B/D** (and tightly bounded secret-bearing appliances in **C**) while leaving direct portal workflows, delegation/forwarding boundaries, and generic init-time sealing explicitly separate.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is one of `app-secret-posture-v0.md`, `vault-posture-v0.md`, `cryptosvc-posture-v0.md`, or a future posture doc under `docs/30-architecture/` that pins the caller-visible meaning of minimal app-scoped secret seeds, provider-owned secret object references, or explicit-route crypto/key-use authority;
2) it is a posture doc, not an adjacent schema / portal workflow / forwarding-boundary / inventory-boundary / provider-selection-boundary / recovery surface (for example `portal-adjunct-index.md`, `cryptosvc-forwarding-boundary-v0.md`, `cryptosvc-inventory-boundary-v0.md`, `cryptosvc-provider-selection-boundary-v0.md`, `key-policy-schema-v0.md`, `keyref-schema-v0.md`, `secretref-schema-v0.md`, and `secret-policy-schema-v0.md` stay adjacent);
3) its meaning is about portable secret-bearing authority and provider semantics, not neighboring but separate seams whose Phase 1 posture intentionally lives elsewhere (for example `seal-posture-v0.md`, `capmode-posture-v0.md`, `timeproof-posture-v0.md`, and `attestation-posture-v0.md` remain distinct).

## Closed secret-bearing authority posture set (Phase 1)

### 1) Minimal app-scoped seed authority

| Doc | One-line pinned meaning |
|---|---|
| [`app-secret-posture-v0.md`](app-secret-posture-v0.md) | app secrets stay a minimal app-scoped seed seam reached only through `portal.secret`; no named inventory, no silent auto-rotation, and no ACP automation kind |

### 2) Ref-bound provider-owned secret storage

| Doc | One-line pinned meaning |
|---|---|
| [`vault-posture-v0.md`](vault-posture-v0.md) | vault authority stays reference-bound, provider-owned, and non-inventory; no collection/search broker and no implicit recovery/sync surface |

### 3) Explicit-route crypto/key-use authority

| Doc | One-line pinned meaning |
|---|---|
| [`cryptosvc-posture-v0.md`](cryptosvc-posture-v0.md) | crypto services stay op-only, context-bound, and explicit-route only; no ambient agent socket/path/env discovery and no provider-global key inventory |

## Review rule

When a new posture doc appears that primarily pins app-scoped secret-seed meaning, provider-owned secret-reference meaning, or explicit-route crypto/key-use authority, either:

- add it here **in the same revision**, or
- explicitly place it under some other existing closed discovery surface in the same revision.

If a future doc primarily belongs to direct portal workflow routing, auth-agent-vs-crypto-surface splitting, forwarded/delegated key use across boundaries, inventory/search hygiene, provider/backend selection, interactive-auth/presence hygiene, mechanism/capability hygiene, secret-bearing key-material hygiene, derive-result/materialization hygiene, attestation/evidence hygiene, verification/trust-evaluation hygiene, generic init-time attenuation, or attestation/timeproof evidence, keep the split explicit instead of letting “secret authority” become one blurry bucket: `portal-adjunct-index.md`, `authagent-provider-role-boundary-v0.md`, `cryptosvc-boundary-index.md`, `cryptosvc-forwarding-boundary-v0.md`, `cryptosvc-inventory-boundary-v0.md`, `cryptosvc-provider-selection-boundary-v0.md`, `cryptosvc-interactive-auth-boundary-v0.md`, `cryptosvc-mechanism-boundary-v0.md`, `cryptosvc-key-material-boundary-v0.md`, `cryptosvc-key-lifecycle-boundary-v0.md`, `cryptosvc-derived-material-boundary-v0.md`, `cryptosvc-attestation-boundary-v0.md`, `cryptosvc-verification-boundary-v0.md`, `seal-posture-v0.md`, `attestation-posture-v0.md`, and `timeproof-posture-v0.md` should remain separate unless a later RFC deliberately widens the family.

## Wiring

- Decision surfaces: `decision-map.md` (**D-APPSECRET**, **D-VAULT**, **D-CRYPTOSVC**).
- Adjacent workflow and hardening seams: `portal-adjunct-index.md`, `cryptosvc-boundary-index.md`, `authagent-provider-role-boundary-v0.md`, `cryptosvc-forwarding-boundary-v0.md`, `cryptosvc-inventory-boundary-v0.md`, `cryptosvc-provider-selection-boundary-v0.md`, `cryptosvc-interactive-auth-boundary-v0.md`, `cryptosvc-mechanism-boundary-v0.md`, `cryptosvc-key-material-boundary-v0.md`, `cryptosvc-key-lifecycle-boundary-v0.md`, `cryptosvc-derived-material-boundary-v0.md`, `cryptosvc-attestation-boundary-v0.md`, `cryptosvc-verification-boundary-v0.md`, `seal-posture-v0.md`, `capmode-posture-v0.md`.
- Adjacent schema/mechanism surfaces: `app-secret-descriptor-schema-v0.md`, `secret-policy-schema-v0.md`, `secretref-schema-v0.md`, `key-policy-schema-v0.md`, `keyref-schema-v0.md`, `mechanisms.md`.
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_secret_authority_adjunct_index.py` (**EVID-2026-532**).
