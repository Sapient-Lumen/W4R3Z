# D-CRYPTOSVC verification boundary v0 (no portable verify / trust-evaluation seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable signature-verification, certificate-path-validation, trust-store, trust-root, revocation-status, hostname/EKU/policy, or generic trust-evaluation surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable verify / trust-evaluation seam in v0**
   - Phase 1 does **not** export a portable `verify`, `verify_sig`, `verify_cert`, `verify_chain`, `cert_path`, `build_chain`, `validate_chain`, `trust_eval`, `trust_store`, `trust_anchor`, `anchor_set`, `eku_check`, `hostname_check`, `policy_oid_check`, `ocsp_check`, `crl_check`, `revocation_check`, `best_chain`, `verification_policy`, `verification_verdict`, or equivalent verification/trust knob or result on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - Providers may internally verify signatures, certificate chains, attestation endorsements, or local helper protocol transcripts as part of provider-local setup or request handling, but those details remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret provider-local verification helpers, certificate stores, trust anchors, status caches, or chain-building outcomes as requester-visible generic crypto-service truth.

2. **Verification and trust evaluation are a second workflow, not generic crypto use**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff plus pinned CH-KEYPOL data, not about standardizing how callers verify arbitrary signatures, ask “does this chain validate?”, discover acceptable trust roots, or borrow a portable verifier verdict from whichever backend happens to be present.
   - The closed op set may still include `sign`, `decrypt`, `derive`, and `attest`, but in Phase 1 that does **not** imply a portable `verify` / `verify_chain` / trust-store / verifier-policy API contract on IF-CRYPTOSVC.
   - Signature and certificate verification meaning therefore stays on the explicit **D-SIGENV / D-KEYLESS** surfaces (`signature-envelope-posture-v0.md`, `certificate-path-input-boundary-v0.md`, `certificate-status-evidence-boundary-v0.md`, `certificate-identity-evidence-boundary-v0.md`, `signature-trust-root-boundary-v0.md`, `verification-verdict-boundary-v0.md`) rather than smuggling verifier policy into the key-use seam.

3. **Verification/trust evaluation is its own ecosystem workflow**
   - Existing ecosystems really do split these surfaces. PKCS #11 standardizes `C_Verify*` separately from token object/session mechanics. Apple’s `SecTrust` APIs evaluate certificates together with explicit policies and anchors. Windows `CertGetCertificateChain` builds a certificate chain context back to a trusted root. Java PKIX path building uses explicit `PKIXBuilderParameters` / trust anchors rather than key-use handles.
   - Those are valuable product workflows, but they also allocate extra trust-root, path-building, identity-policy, revocation, freshness, and verdict semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden signature-verification broker, trust-store service, or certificate-policy oracle.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future verification / trust-evaluation seam must state its own conflict keys, commutativity, serialization point, cache/freshness semantics, identity-policy rules, revocation/status policy, and evidence plan explicitly rather than inheriting folklore from PKCS#11 verify calls, SecTrust, CertGetCertificateChain, or PKIX builder defaults.
   - Until then, generic crypto use remains keyref/route-bound only; verification, certificate-path building, trust-root selection, and verifier verdict semantics stay on explicit D-SIGENV / D-KEYLESS / D-TIME / D-TLOG surfaces.

## Phase 1 non-goals (explicitly deferred)

- No portable `verify`, `verify_cert`, `verify_chain`, `build_chain`, `trust_eval`, `trust_store`, `anchor_set`, `eku_check`, `hostname_check`, `policy_oid_check`, `ocsp_check`, `crl_check`, or equivalent verification/trust knob/result on generic crypto use.
- No transcript-stable statement that generic key use also returned a verifier verdict, best chain, accepted root, or revocation result for the caller.
- No importer-visible certificate-path or trust-store folklore on the D-CRYPTOSVC seam.
- No shell/helper fallback that quietly promotes key use into a verifier/trust-evaluation workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “ask the key service whether this signature is valid”, “have the token backend decide whether this chain is trusted”, “reuse the provider’s system trust store and OCSP policy”, or “treat successful `attest` / `sign` setup as proof that the same backend would verify the peer.” Once those assumptions land in transcripts and automation, they become hard to retract and easy to misuse as ambient verifier authority. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden trust-evaluation plane. That matters for all four product shapes: workstation UX can still host local verifier tools without standardizing their trust stores as substrate meaning; hosted and embedded profiles avoid inheriting mutable certificate-chain and revocation policy they do not want in the key-use seam; and agent tooling cannot mistake CH-KEYREF/CH-KEYPOL for permission to query portable verifier truth.

## Profile effect (A–D)

- **Secure workstation (A):** local browsers, package verifiers, or enterprise trust tools may still validate signatures/certificates, but generic crypto use does not standardize those trust-store or revocation outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting mutable machine-specific trust stores or chain-build heuristics inside the key-use seam; verifier policy remains explicit in release/admission workflows.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose certificate-path, revocation, or hostname-policy services they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to ask a backend for portable signature-verification or trust-evaluation truth; reviewed verification stays on explicit D-SIGENV / D-KEYLESS workflows.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/30-architecture/signature-envelope-posture-v0.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_verification_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable verify / trust-evaluation seam / verification is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-603**).

## References

- REF-PKCS11-SPEC.
- REF-APPLE-SECTRUST-EVALUATEWITHERROR.
- REF-MICROSOFT-CERTGETCERTIFICATECHAIN.
- REF-ORACLE-JAVA-PKIXBUILDERPARAMETERS.
