# CH-NETREQ v0: network lease request (optional; D-NETLEASE)

Purpose: a **bounded, normalized request descriptor** for obtaining a scoped outbound-network lease from the network portal.

CH-NETREQ is a stable, digestable input for **LLM-proposed / validator-executed** network lease issuance:
- ACP proposals bind `netreq_digest = digest(CH-NETREQ v0)`.
- Validators verify the request shape (fail closed) and invoke the portal using explicit capabilities.
- The portal returns a **CH-NETLEASE v0** descriptor (bounds receipt) plus an opaque network authority handle.

This schema is **not** authority and MUST NOT contain bearer capability material.

Related:
- `network-lease-schema-v0.md` (CH-NETLEASE v0)
- D-NETLEASE: `docs/30-architecture/decision-map.md`
- Portal family: `docs/30-architecture/portal-family-registry.md` (`portal.net`)

References: REF-LITTLESNITCH, REF-MACOS-NETWORKEXT, REF-XDG-PORTAL-NETWORKMONITOR.

Posture: `network-lease-posture-v0.md` (Phase 1 meaning; no ambient sockets/DNS when D-NETLEASE enabled).

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-NETREQ-v0 {
  schema: "CH-NETREQ";
  version: 0;

  # Request identity (for dedupe/replay correlation).
  # Validators/portals MAY treat stable req_id as an upsert key.
  req_id: bytes16;             # random (>=128 bits)

  # Lease class requested (v0 seed).
  kind: enum { connect, listen, dns };

  # Scope requested (portal may clamp or deny by policy).
  scope: enum { internet, local, loopback, explicit };

  # Transport class requested (portal may clamp).
  proto: enum { tcp, udp, tls, quic };

  # Destination predicate (required for connect/listen; optional for dns).
  # NOTE: this is a *policy request*, not a permission grant.
  dest?: {
    kind: enum { dns_name, dns_suffix, ip_prefix, service };

    dns_name?: string;         # bounded; e.g., "api.example.com"
    dns_suffix?: string;       # bounded; e.g., ".example.com"

    ip_prefix?: {
      family: enum { v4, v6 };
      addr: bytes;             # 4 or 16 bytes
      prefix_len: u16;         # 0..32 or 0..128
    };

    service?: string;          # bounded, policy-resolved stable label (e.g., "updates")

    port?: u16;                # 1..65535
    port_range?: { lo: u16; hi: u16 };
  };

  # Optional bounds (veto-only hints; the portal may clamp or deny).
  bounds?: {
    ttl_s?: u32;               # requested TTL cap; portal clamps
    max_conns?: u32;
    max_bytes?: u64;
    max_seconds?: u32;
    deadline_mono?: u64;       # optional local monotonic deadline (units profile-defined)
  };

  # Optional non-authoritative purpose label (bounded).
  purpose?: string;            # ≤ 96 bytes (e.g., "fetch_updates", "telemetry")

  # Optional export posture hint.
  sensitive?: bool;            # if true, exports are redacted/blocked by CH-OBSPOL profiles
}
```

## Validation rules (summary)
A CH-NETREQ validator MUST be total and fail closed:
1) `schema == "CH-NETREQ"` and `version == 0`.
2) `req_id` is exactly 16 bytes.
3) `kind`, `scope`, and `proto` are allowlisted closed enums.
4) `dest` is required iff `kind` is `connect` or `listen`.
5) If `dest` is present:
   - `dest.kind` selects exactly one predicate form (dns_name | dns_suffix | ip_prefix | service).
   - `dns_name`/`dns_suffix`/`service` are bounded strings.
   - `ip_prefix.addr` length matches `family`, and `prefix_len` is in range.
   - `port` is 1..65535; `port_range.lo <= port_range.hi` and each bound is 1..65535.
6) If `bounds` is present, each numeric field is bounded/clamped by profile; `deadline_mono` is interpreted as a **veto-only** hint.
7) `purpose` length ≤ 96 bytes.

## Security posture
- CH-NETREQ is **non-authoritative**. It records a request shape for mediation and audit; it never grants network authority.
- The portal selects resolvers/providers and may clamp destinations by policy.
- Requests can reveal sensitive intent (destination predicates). Export via IF-OBS should respect CH-OBSPOL and consider hashing/redaction.

ACP integration (optional):
- Network lease requests SHOULD be mediated via ACP kind `portal.net.request`, binding `netreq_digest = digest(CH-NETREQ v0)` and enforcing lane gate `cfg.params.lane.portal.net` fail-closed (PO-ACP-NET-REQUEST; PO-LANE-KILL).
- For retry safety, portals SHOULD dedupe by `req_id` when the kind claims **at-least-once-safe** and SHOULD make duplicate suppression transcript-visible (D-RETRYSAFE).
- `req_id` is a requester-chosen stable request/dedupe key only; it is NOT a portal-issued CH-NETLEASE handle, connection/session identifier, or proof that a current lease still exists (`network-request-state-posture-v0.md`; I-NETREQ-2).
