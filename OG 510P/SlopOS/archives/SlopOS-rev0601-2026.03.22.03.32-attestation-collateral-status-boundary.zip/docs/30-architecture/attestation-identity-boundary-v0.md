# Attestation identity boundary v0 (attester identity stays exact evidence/signing context; no native asset/enrollment plane)

Purpose: pin the Phase-1 meaning of **attester identity material** across **D-ATTEST** and **D-POLICY** so the archive does not quietly overload `CH-ATTEST.device_id`, embedded EAT identity claims, or provider-native device identifiers into a portable machine/asset/workload identity, attester inventory, or enrollment-query control plane.

Entropy cost justification: `attestation-posture-v0.md` already keeps attestation export observational and killable, `attestation-endorsement-boundary-v0.md` already keeps endorsements/reference values verifier-local, `attestation-freshness-boundary-v0.md` already keeps nonce/challenge semantics verifier-local, and `attestation-result-boundary-v0.md` already keeps verifier outputs as imported evidence only. The remaining ambiguity is narrower and still expensive: **what attester identity fields are allowed to mean once they travel in normalized tokens, embedded EAT claims, or provider-native evidence**. One small boundary closes that gap without inventing a new enrollment service, asset registry, or identity-query workflow.

This doc is a **family member of the closed D-ATTEST companion boundary family** rooted at `attestation-boundary-index.md`.

## Posture (v0)

1) **Attester identity material is exact evidence/signing context, not ambient identity truth.**
   - Exported attestation evidence may carry a normalized `device_id`, embedded UEID/implementation-id/instance-id style claims, or provider-native key/device identifiers.
   - Those fields are evidence about one signer/device context under one verifier-local interpretation; no field by itself means “this is the portable machine identity”, “this is the approved asset”, or “this is the current workload owner”.

2) **No native attester-identity / enrollment schema in v0.**
   - Phase 1 standardizes no native attester-identity object, enrollment record, fleet directory entry, stable asset identifier, or equivalent privileged-core identity schema.
   - IF-ATTEST exports evidence only; it does not mint a reviewed substrate identity record.

3) **`device_id`, UEID, implementation-id, instance-id, and key identifiers stay evidence, not portable asset/account/workload identity.**
   - `CH-ATTEST.device_id`, embedded EAT identity-oriented claims, and provider-native key/device identifiers may be preserved as exact evidence/signing-context fields.
   - They do not by themselves authorize network admission, secret release, tenancy/account routing, asset ownership, or workload continuity.
   - Any such decision remains explicit verifier-local enrollment and policy over the exact evidence presented.

4) **Identity meaning is scoped to verifier-local roots, enrollment, and appraisal context.**
   - An identity-bearing field only has meaning together with the verifier identity, accepted roots, enrollment database, endorsement/reference corpus, freshness assumptions, and boot/provenance bindings that interpret it.
   - Replaying the same identifier under different roots, in a different deployment, or after policy/enrollment drift does not silently preserve the same meaning.

5) **No native attester inventory, lookup, latest-seen, or enrollment-query plane in v0.**
   - Phase 1 standardizes no `lookup_attester`, `resolve_device_identity`, `list_attesters`, `latest_seen_attestation`, `enrollment_status`, or similar service surface.
   - Any inventory, enrollment, or directory behavior remains explicit tooling and local policy, not a portable substrate service.

6) **Forwarded or re-labeled identity artifacts do not replace exact evidence or local enrollment.**
   - A forwarded, mirrored, wrapped, or human-labeled identity artifact remains second-order evidence about a prior appraisal/enrollment context.
   - It does not replace exact attestation evidence, local enrollment state, or local authorization logic.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing attestation/export/evidence seams are interpreted.
   - Any future portable attester enrollment, attester inventory, or identity-resolution workflow must pay for its own RFC, conflict keys, serialization story, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native attester identity or enrollment schema.
- No portable machine / asset / workload / account identity plane derived from attestation export.
- No attester inventory, lookup, or latest-seen query/watch API.
- No rule that an imported identifier overrides local roots, enrollment, or freshness/boot policy.
- No ambient translation of EAT identity claims or provider-native identifiers into SlopOS approval or ownership authority.

## Why this is worth pinning

The surrounding ecosystem is explicitly split:
- RFC 9334 keeps Evidence separate from verifier appraisal and relying-party decision; identity-bearing claims are still evidence inputs interpreted under local policy.
- RFC 9711 defines attestation-oriented claims such as UEID in an attested claims set, but the relying party still decides what trust to place in the entity and how to interpret those claims.
- RFC 9783 profiles EAT for PSA with identity-bearing fields such as implementation and instance identifiers without turning the token into a universal enrollment or asset-directory object.
- DICE hardware requirements derive compound identifiers from a device secret plus measured code specifically to bind identity to measured execution, not to create a portable ambient fleet-identity plane.

Pinning that split now prevents SlopOS from slowly reinventing a hidden asset registry, “current device identity” oracle, or enrollment-query plane under the names of attestation export, cached identity labels, or embedded identity claims.

## Profile effect (A–D)

- **Secure workstation (A):** workstation attestation can preserve device identifiers for enterprise policy without turning attestation export into a native fleet/asset directory or account-routing oracle.
- **Cloud micro-VM substrate (B):** attestation evidence may carry tenant- or workload-adjacent identity hints, yet admission and secret release still depend on explicit verifier-local enrollment and policy rather than ambient exported identity truth.
- **Embedded / separation appliance (C):** device fleets may preserve DICE/PSA-style identifiers as evidence, but the appliance does not inherit a native asset registry or online enrollment plane.
- **Agent/automation OS (D):** agents may consume identity-bearing evidence fields, but they cannot quietly smuggle in asset ownership, tenancy, or “same trusted worker” authority through cached attester labels.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATTEST**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/attestation-posture-v0.md`
  - `docs/30-architecture/attestation-token-schema-v0.md`
  - `docs/30-architecture/attestation-pack-schema-v0.md`
  - `docs/30-architecture/confidential-computing-eat-payload-claim-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
- Engineering / profile surfaces:
  - `rfcs/0064-confidential-computing-profile.md`
  - `docs/30-architecture/interface-registry.md`
- Assurance anchors:
  - **I-ATTEST-1**.
  - **PO-ATTEST-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_attestation_identity_boundary.py` keeps the split small and discoverable (**EVID-2026-612**).

## References

- **REF-RATS-RFC9334**
- **REF-EAT-RFC9711**
- **REF-RFC9783-PSA-TOKEN**
- **REF-DICE-HW-REQ**
