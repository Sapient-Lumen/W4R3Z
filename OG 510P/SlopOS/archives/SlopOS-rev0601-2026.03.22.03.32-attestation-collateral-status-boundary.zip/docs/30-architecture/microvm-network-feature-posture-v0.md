# MicroVM network-feature posture v0 (no portable guest-visible NIC acceleration / tuning contract)

Purpose: pin the **Phase 1** meaning of guest-visible network-performance and acceleration features under `ext.microvm` so virtio-net multiqueue, RSS/hash-report, offload toggles, queue sizing, and link-speed folklore do not quietly become a portable ambient performance/control/status plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, **D-NETLEASE**, and **D-OBS** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible NIC acceleration/tuning contract under `ext.microvm`; there is no portable virtio-net multiqueue / RSS / hash-report / offload / queue-size / speed-duplex plane, owner-local queue-count, ring-size, offload-toggle, RSS-steering, and backend-coupling policy stays implementation-local, and reviewed network authority / performance / observation meaning stays on explicit D-NETLEASE, topology, and observation seams rather than ambient virtio-net tuning knobs.**

Entropy cost justification: the archive already fixes guest-visible NIC inventory at admission, keeps host↔guest channels killable, and keeps backend-offload topology implementation-local. What remained underspecified was the large virtio-net feature/config surface that real VMM stacks expose for throughput steering and packet-shape handling: queue counts, ring sizes, RSS/hash reporting, mergeable receive buffers, guest/host checksum-segmentation offloads, and speed/duplex fields. One narrow posture closes that gap without inventing a NIC tuning schema, performance governor, or hidden queue-management plane.

## Posture (v0)

1) **No portable ambient guest-visible NIC acceleration/tuning contract**
   - For Phase 1, `ext.microvm` exposes **no portable ambient guest-visible NIC acceleration/tuning contract**.
   - Portable semantics do **not** include one reviewed meaning for virtio-net **multiqueue queue-pair counts**, **queue-ring sizes**, **RSS steering**, **RSS hash reporting**, **mergeable-RX-buffer behavior**, **guest/host checksum-segmentation-offload feature exposure**, or **reported link speed/duplex**.
   - In plain terms: the reviewed contract is “this leaf has this guest-visible NIC inventory and explicit network leases”, not “this profile promises one exact virtio-net tuning surface for throughput, steering, packet hashing, or offload behavior”.

2) **No portable multiqueue / RSS / offload / speed-duplex plane**
   - Phase 1 standardizes **no portable `VIRTIO_NET_F_MQ` / `VIRTIO_NET_F_RSS` / `VIRTIO_NET_F_HASH_REPORT` / host-or-guest offload / queue-size / speed-duplex control-status plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible fields or APIs such as **`max_virtqueue_pairs`**, **RSS key / indirection-table sizing**, **supported hash-type bitmasks**, **per-queue interrupt-vector budgeting**, **`csum` / `gso` / `tso4` / `tso6` / `ecn` / `ufo` / `mrg_rxbuf` toggles**, or **reported link speed / duplex values**.
   - Implementations may internally expose or negotiate such mechanisms, but they are **not** part of the Phase 1 product contract and must not silently become guest-visible reviewed meaning.

3) **Owner-local NIC tuning policy stays owner-local and must not masquerade as a portable API**
   - Owners/runtimes may still choose one queue count, ring size, offload policy, RSS setup, host backend, MSI-X vector budgeting, or in-QEMU/eBPF steering strategy locally.
   - What they may **not** do in Phase 1 is turn that owner-local tuning into a portable reviewed guest-visible NIC acceleration contract for an already admitted leaf.
   - If a deployment cannot honor one local virtio-net tuning choice, the correct Phase 1 outcomes are to admit a different reviewed leaf/activation, keep the difference owner-local, or fail closed — not to grow a new portable in-place network-acceleration meaning by convention.

4) **Changing guest-visible NIC acceleration stance is owner-local lifecycle or new admission, not a portable live control plane**
   - Owners/runtimes may vary queue counts, offload exposure, or RSS setup across reviewed leaves, deployment classes, or owner-local lifecycle operations.
   - They may **not** reinterpret a running leaf as carrying a portable NIC tuning/status protocol under the same admitted identity.
- changing guest-visible NIC acceleration stance is owner-local lifecycle or new admission, not a portable live control plane.
   - If policy cares about a different guest-visible NIC acceleration stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden queue-management or offload-admin channel by convention.

5) **No new NIC tuning plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for NIC acceleration/tuning state, **no new ACP kind**, and **no new conflict-key family** for queue-count changes, RSS-key updates, offload-toggle mutation, or speed/duplex-status administration under `ext.microvm`.
   - If a later design wants portable NIC queue management, RSS configuration, packet-hash export, or offload/state reporting, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable guest-visible multiqueue / RSS / hash-report contract for `ext.microvm`.
- No portable guest-visible checksum / segmentation / mergeable-buffer offload control-status API.
- No portable link speed / duplex or queue-ring-size tuning API.
- No promise that owner-local NIC tuning is forbidden; only that it does **not** become a reviewed guest-visible control/status plane in Phase 1.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-NETLEASE, D-OBS)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-network-topology-posture-v0.md`
  - `microvm-backend-offload-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-51)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-NETFEATURE)
- Policy posture:
  - guest-visible NIC acceleration/tuning adds **no new lane**, **no public queue-or-offload-status plane**, and **no portable in-place tuning contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_network_feature_posture.py` fails `make lint` if this posture stops being discoverable, loses its no-portable-contract / no-portable-plane / owner-local-policy / explicit-network-authority-seams / no-live-control-plane / no-new-schema-or-ACP constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-LIBVIRT-DOMAIN-XML.
- REF-QEMU-NETDEV-QUEUES.
- REF-KVM-VIRTIO-NET-MQ.
