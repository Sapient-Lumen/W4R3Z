# MicroVM backend-offload posture v0 (no portable ambient `vhost-user` / vDPA backend contract)

Purpose: pin the **Phase 1** meaning of host-side device-backend offload under `ext.microvm` so `vhost-user`, `vhost-vdpa`, `VDUSE`, backend sockets, queue handoff, and backend-rebind folklore do not quietly become a reviewed host-side control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, **D-IOLEASE**, and **D-NETLEASE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host-side backend-offload contract under `ext.microvm`; there is no portable `vhost-user` / `vhost-vdpa` / `VDUSE` / backend-socket / queue-handoff / backend-rebind-status plane, owner-local backend process/device selection stays implementation-local, and device/network authority still rides on explicit D-IOLEASE / D-NETLEASE seams plus already-pinned guest-visible topology postures rather than ambient host backend channels.**

Entropy cost justification: the archive already pins guest-visible microVM topology, excludes ambient host↔guest channels, and keeps device/network authority on explicit lease seams. What remained underspecified was the newer host-side offload layer where modern VMMs push virtio backends into separate processes or vDPA-style datapaths over Unix sockets, file-descriptor passing, shared memory, and queue handoff. One narrow posture closes that gap without inventing a plugin registry, backend-admin API, or hidden host control channel.

## Posture (v0)

1) **No portable ambient host-side backend-offload contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient host-side backend-offload contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard external backend protocol/process model behind virtio devices.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one stable host-side backend socket/process/device topology exists with known queue handoff semantics.”

2) **No portable `vhost-user` / `vhost-vdpa` / `VDUSE` / backend-socket / queue-handoff / backend-rebind-status plane**
   - Phase 1 standardizes **no portable `vhost-user` / `vhost-vdpa` / `VDUSE` / backend-socket / queue-handoff / backend-rebind-status plane** under `ext.microvm`.
   - That means no reviewed portable semantics for backend Unix-socket paths, reconnection policy, ancillary file-descriptor exchange, vring or IOTLB handoff, inflight/log FD handling, backend process identity, backend health/status reporting, or live backend rebind/takeover APIs.
   - Implementations may internally use such mechanisms locally, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local backend process/device selection stays implementation-local**
   - Owner-local backend process/device selection stays implementation-local.
   - Runtimes may choose in-process virtio emulation, a separate `vhost-user` backend process, a kernel/user hybrid such as vDPA/VDUSE, or no backend offload at all for one deployment class, but that does **not** create a portable reviewed promise about one backend topology, one queue-control protocol, or one runtime status/control API.
   - In particular, per-runtime flags such as `vhost_user=true`, `socket=...`, or vDPA/VDUSE attachment choices remain host/runtime-local configuration, not portable SlopOS interface meaning.

4) **Existing guest-visible topology postures and lease seams remain authoritative**
   - Existing guest-visible topology postures and lease seams remain authoritative.
   - Guest-visible NIC/block meaning still rides on `microvm-network-topology-posture-v0.md`, `microvm-block-topology-posture-v0.md`, and explicit D-NETLEASE / D-IOLEASE seams rather than host backend plumbing.
   - Host↔guest filesystem sharing remains separately disallowed by `host-guest-channel-posture-v0.md`; a host `virtiofsd` or similar daemon does **not** create a portable exception.

5) **Changing the backend-offload stance is owner-local lifecycle or new admission, not a portable live control plane**
   - Changing the backend-offload stance is owner-local lifecycle or new admission, not a portable live control plane.
   - Owners/runtimes may choose different local backend implementations for different reviewed leaves or deployment classes, and they may perform owner-local backend failover internally, but they may **not** reinterpret a running leaf as carrying a portable backend rebind/status protocol under the same admitted identity.
   - If policy cares about a different backend-offload stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden backend-management channel by convention.

6) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for backend-offload state, **no new ACP kind**, and **no new conflict-key family** for backend attach, reconnect, takeover, queue handoff, or backend-status mutation under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `attach_backend`, `handoff_queue`, `rebind_backend`, or `query_backend_status`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that `vhost-user`, `vhost-vdpa`, or `VDUSE` exists with one stable reviewed meaning under `ext.microvm`.
- No portable backend socket path, reconnection, queue-state transfer, or backend health/status API.
- No portable “generic external device-backend plugin” contract for microVM devices.
- No host-filesystem-sharing exception via `virtiofsd` or other backend daemons.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-IOLEASE, D-NETLEASE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `microvm-block-topology-posture-v0.md`
- Adjacent notes:
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-23)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-BACKENDOFFLOAD)
- Policy posture:
  - host-side backend offload adds **no new lane**, **no public backend socket/control plane**, and **no portable in-place backend-rebind contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_backend_offload_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient host-side backend-offload contract / no portable `vhost-user`-`vhost-vdpa`-`VDUSE`-backend-socket-queue-handoff-backend-rebind-status plane / owner-local backend process-device selection stays implementation-local / D-IOLEASE and D-NETLEASE remain authoritative / changing backend-offload stance is owner-local lifecycle or new admission not a portable live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-CHYP-DEVICE-MODEL.
- REF-QEMU-VHOST-USER.
- REF-QEMU-VHOST-VDPA.
- REF-LINUX-VDUSE.
