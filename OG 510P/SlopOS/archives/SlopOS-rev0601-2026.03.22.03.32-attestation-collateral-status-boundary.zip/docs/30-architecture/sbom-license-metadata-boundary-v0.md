# SBOM license-metadata boundary v0 (`licenses` stay imported evidence, not native allow/deny or obligation authority)

Purpose: pin the Phase-1 meaning of **license labels / expressions imported through CH-SBOM and external SBOM documents** across **D-SBOM**, **D-AREF**, and **D-POLICY** so SPDX/CycloneDX license richness does not quietly become a portable install-allowlist, denylist, waiver, obligation, or exception plane.

Entropy cost justification: the archive already keeps CH-SBOM digest-bound, keeps component identity on exact `content_digest` / `build_id` when available, and already refuses hidden latest-wins, dependency, or package-identity semantics from imported SBOM ecosystems. What remains cheap-but-dangerous is the **license metadata** layer: SPDX carries license expressions, `LicenseRef-*`, `NONE`, and `NOASSERTION`; CycloneDX supports SPDX license IDs, SPDX expressions, and license names; NTIA explicitly calls out licenses as one use of SBOM data. If left loose, one tool will start treating imported license strings as a native install deny rule, another will infer a portable compliance waiver from `NOASSERTION`, and a third will treat one rich external document as selecting the legal policy in force. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still carry optional `licenses[]` strings per component as imported descriptive metadata.
- **CH-AREF v0** may still bind one exact external SPDX/CycloneDX SBOM document whose bytes carry richer license identifiers, expressions, names, comments, or custom license references.
- **Verifier-local policy/tooling** may still parse, normalize, and reason over those imported license fields, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **`licenses` are imported evidence only.**
   - A `licenses[]` entry in CH-SBOM records one imported label chosen by upstream tooling or copied from a richer external SBOM ecosystem.
   - Phase 1 therefore treats `licenses[]`, SPDX license expressions, `LicenseRef-*`, CycloneDX license names, and similar imported fields as descriptive evidence syntax, not as a native SlopOS allow/deny, waiver, obligation, or exception rule.
   - Matching license strings across SBOMs, releases, or external documents carries no portable install, boot, export, or compliance verdict by itself.

2) **Exact subject/component binding still rides on digests and build IDs.**
   - `content_digest` and `build_id` remain the portable component-binding fields under **I-SBOM-2**.
   - Companion `sbom-posture-v0.md` already pins `name`, `version`, `purl`, `supplier`, and `licenses` as observational only.
   - This boundary further pins that imported license metadata stays on the same non-native side of the line even when outside ecosystems use it for powerful compliance workflows.

3) **Phase 1 imports no native SPDX-expression parser, obligation engine, or waiver vocabulary.**
   - SPDX license expressions intentionally support `AND`, `OR`, `WITH`, `+`, and locally defined `LicenseRef-*` identifiers.
   - SPDX package license fields also permit `NONE` and `NOASSERTION`, while CycloneDX accepts SPDX IDs, SPDX expressions, and license names.
   - Phase 1 therefore adds no native “allowed expression”, “forbidden reciprocal license”, “commercial exception present”, “`NOASSERTION` means warn/allow/deny”, “map equivalent expressions”, “canonicalize custom license refs”, or “infer obligations from this imported text” rule.
   - Any such parsing/evaluation stays verifier-local and explicit under **D-POLICY** rather than leaking into CH-SBOM / CH-AREF meaning.

4) **License metadata does not widen install, update, or export authority.**
   - A component’s imported license metadata may inform local review, gating, or redaction policy, but it does not by itself authorize or block install, select a successor package, widen export rights, or create a native waiver token.
   - Companion `verification-policy-selection-boundary-v0.md` already pins that evidence does not choose which policy is in force.
   - Companion `verification-verdict-boundary-v0.md` already pins that verification/appraisal results stay consumer-local rather than becoming a portable “approved artifact” plane.

5) **Imported richer license ecosystems stay imported evidence unless another seam admits more.**
   - SPDX and CycloneDX intentionally carry richer licensing structures because upstream compliance workflows need them.
   - Phase 1 may ingest those exact bytes as evidence and may carry exact external docs through **CH-AREF**, but it does not elevate their licensing vocabulary into privileged-core semantics.
   - Any future native license-policy or waiver surface must return RFC-first with explicit conflict keys, commutativity, serialization boundary, and evidence hooks.

6) **Exact artifact binding and policy selection still happen on the existing seams.**
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds the exact subject digest the verifier cares about.
   - **PO-AREF-VERIFY** still answers integrity for one attached external SPDX/CycloneDX document.
   - **PO-POLICY-DETERMINISM** and **PO-POLICY-NONAMP** still answer which local policy, if any, parses imported license metadata and how that policy avoids ambient widening.
   - No portable “approved for use”, “must reject”, “allowed exception”, or “obligations satisfied” verdict is created merely by carrying imported license metadata.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported license metadata fits with existing SBOM / external-document / policy seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native license-compatibility engine or legal-obligation calculus.
- No portable allowlist / denylist / exception / waiver schema on CH-SBOM itself.
- No rule that SPDX `NONE` / `NOASSERTION` or CycloneDX license names create native pass/fail semantics.
- No canonicalization of custom license references into a native same-license graph.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- SPDX Annex D defines a compact expression language with Boolean operators and locally defined license references.
- SPDX package-license fields distinguish concluded, discovered, and declared license information and allow `NONE` / `NOASSERTION`.
- CycloneDX explicitly supports SPDX license IDs, SPDX expressions, and license names, and markets that richness for compliance and asset-management use cases.
- NTIA includes licenses among the management use cases and data expectations people attach to SBOMs.

Once CH-SBOM, CH-AREF, and verifier-local policy are all present, it becomes extremely tempting to let imported license syntax select the compliance policy in force or silently create a portable “approved / forbidden / waived” result. Pinning that split now keeps SlopOS digest-first and keeps legal/compliance interpretation explicit and local.

## Profile effect (A–D)

- **Secure workstation (A):** review tooling may still surface license concerns, but one imported SPDX expression cannot silently become a global install deny or waiver token across user software.
- **Cloud micro-VM substrate (B):** fleet tooling may enforce strict local compliance policy, but portable meaning stays on exact digests rather than imported license-expression folklore.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a full legal-obligation engine inside privileged-core meaning.
- **Agent/automation OS (D):** agents may reason over imported license metadata, but they cannot smuggle “this SPDX expression means auto-approve / auto-deny” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-AREF**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0091-sbom-artifacts-and-closure-binding.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-SBOM-2**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_license_metadata_boundary.py` keeps the split small and discoverable (**EVID-2026-494**).

## References

- **REF-SPDX-LICENSE-EXPRESSIONS**
- **REF-SPDX-PACKAGE-LICENSES**
- **REF-CYCLONEDX-LICENSES**
- **REF-NTIA-SBOM-MIN2021**
