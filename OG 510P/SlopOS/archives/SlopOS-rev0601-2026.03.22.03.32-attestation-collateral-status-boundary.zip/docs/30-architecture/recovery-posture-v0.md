# D-RECOVERY posture v0 (sealed dedicated recovery target; no hidden failover/admin shell)

Purpose: pin an implementable **Phase 1** meaning for **D-RECOVERY** so recovery stops being a vague “there is probably some rescue mode” assumption and becomes one small, explicit, auditable boundary.

This posture narrows RFC-0098 into a compact rule set adjacent to **D-ATOMICUPD**, **D-HEALTH**, **D-SUPV**, **D-SEAL**, **CH-BOOT v0**, and **CH-BOOTSEL v0**.

## Posture (v0)

1) **Recovery is a dedicated provenance-bound deployment root**
   - If **D-RECOVERY** is enabled, the portable meaning is one dedicated recovery deployment root bound into the same signed/provenance universe as ordinary trusted deployments.
   - The normal convention is an `artifacts[]` entry with role `recovery_root` in **CH-UPD v0** and/or **CH-BOOT v0**.
   - Recovery is therefore a reviewed boot target, not an ad hoc script pile, mutable rescue partition, or undocumented OEM side path.

2) **Entry is local, explicit, and fail-closed**
   - Phase 1 requires at least one **declared physical-presence/manual entry path** such as firmware or boot-menu selection, a dedicated recovery button, or a secure-attention-mediated pre-UI selector.
   - Software-triggered entry is allowed only if it is explicit, non-spoofable, and policy-reviewed; it must not be a hidden “any privileged process may drop into recovery” escape hatch.

3) **No hidden repeated-failure auto-entry state in v0**
   - Phase 1 standardizes **no portable automatic “after N failed boots enter recovery” state machine** on **D-RECOVERY** itself.
   - Recovery entry may be manual, or a recovery session may explicitly stage a bounded trial boot through **CH-BOOTSEL v0 `pending`**, but hidden failure counters, undocumented boot heuristics, or firmware-specific “repair mode” latches remain implementation-local rather than portable meaning.
   - This keeps boot-selection proof scope small and prevents recovery semantics from depending on folklore around crash counters or boot-status bits.

4) **Recovery boot does not implicitly commit or replace the main deployment**
   - Booting recovery is never itself “boot success” for the normal deployment and does not silently update **CH-BOOTSEL v0 `lkg_root_digest`**, clear rollback evidence, or replace the active deployment.
   - Recovery may offer explicit, transcript-visible actions to choose LKG, stage a bounded trial boot, or reset selected config facets, but those remain ordinary privileged actions rather than ambient consequences of having entered recovery.

5) **Recovery seals quickly and stays minimal**
   - Recovery should enter a **D-SEAL** posture quickly: no ambient networking, no ambient storage traversal, no ambient device attach, and no hidden host-management backchannel.
   - If a profile permits networking in recovery, it remains explicit **D-NETLEASE** authority and must not become a default “rescue shell with the whole network up.”

6) **Workflows are bounded and transcript-visible; no generic admin shell**
   - Phase 1 recovery is for a **small bounded workflow set**: select a known deployment/LKG, stage a bounded trial boot, perform a scoped config reset, export bounded diagnostics, and optionally run explicit wipe/factory-reset flows if the profile allows them.
   - Recovery must not silently widen into a generic package manager, interactive root shell, SSH service, unrestricted filesystem browser, or ambient privileged scripting plane.
   - High-risk actions remain explicit, capability-gated, and transcript-visible under the existing privileged-action / logging seams.

7) **No portable remote recovery / fleet-admin plane in v0**
   - Phase 1 adds no portable remote rescue, remote KVM-like recovery workflow, unattended recovery API, or fleet-directed recovery control plane.
   - Hosted/operator products may implement owner-local remote rescue mechanisms beneath the membrane, but those do not become native portable meaning under the same profile.

8) **This doc adds no new workflow / ACP / conflict-key family in v0**
   - D-RECOVERY reuses already-pinned boot/update/config/diagnostic seams.
   - Any future explicit recovery-admin workflow family must return RFC-first, declare conflict keys, say whether actions commute, name the serialization boundary, and explain how ordering is evidenced/tested.

## Phase 1 non-goals (explicitly deferred)

- A portable repeated-failure auto-entry state machine.
- A generic interactive admin shell or package-management plane inside recovery.
- A portable remote recovery / unattended repair API.
- Treating recovery boot as implicit success, commit, or rollback authorization for the main deployment.
- A second hidden policy language in firmware/bootloader for rescue decisions.

## Wiring

- Decision surface:
  - `decision-map.md` (D-RECOVERY)
- Primary schema / adjacent posture surfaces:
  - `boot-manifest-schema-v0.md`
  - `boot-selector-state-schema-v0.md`
  - `health-predicate-schema-v0.md`
  - `health-record-schema-v0.md`
  - `security-time-posture-v0.md`
  - `supervision-posture-v0.md`
- Engineering notes:
  - `docs/60-engineering/system-generation-pipeline.md`
- RFC history:
  - `rfcs/0098-recovery-mode-and-rescue-environment.md`
  - `rfcs/0051-atomic-system-updates-and-supply-chain-gates.md`
  - `rfcs/0074-health-predicates-and-boot-success.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-RECOVERY-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-RECOVERY-ENTRY**, **PO-RECOVERY-NOAMP**, **PO-ATOMICUPD-COMMIT**)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- This doc adds **no new workflow / ACP / conflict-key family** in v0; any future external recovery-admin surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_recovery_posture.py` fails `make lint` if this posture stops being discoverable,
  loses the **dedicated provenance-bound recovery_root / explicit physical-presence-first entry /
  no hidden repeated-failure auto-entry state / non-committing recovery boot / no generic admin shell /
  no portable remote recovery plane / no new workflow-ACP surface** posture, or drops its primary REF wiring.

## References

- REF-ANDROID-PARTITIONS.
- REF-ANDROID-AB.
- REF-SYSTEMD-SPECIAL.
- REF-WINRE.
