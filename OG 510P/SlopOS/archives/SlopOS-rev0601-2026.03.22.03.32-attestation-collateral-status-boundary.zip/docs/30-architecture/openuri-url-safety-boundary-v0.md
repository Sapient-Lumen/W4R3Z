# D-PLUMB OpenURI URL-safety boundary v0 (no portable phishing / malware / reputation-verdict seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable URL-safety, phishing, malware, deceptive-site, or reputation-verdict surface on `portal.uri.*`.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1. **No portable URL-safety / phishing / malware / reputation-verdict seam in v0**
   - Phase 1 does **not** export a portable `safe_browsing`, `url_reputation`, `threat_verdict`, `threat_type`, `phishing`, `malware`, `deceptive_site`, `unsafe_reason`, `block_reason`, `reputation_score`, `safe_to_open`, `enterprise_verdict`, `allow_if_clean`, or equivalent URL-safety / threat-verdict field on `portal.uri.*`.
   - A shell, browser, enterprise policy engine, or chosen handler may still consult local Safe Browsing / SmartScreen / fraudulent-website-warning style checks, reputation feeds, or policy verdicts internally, but those checks and outcomes remain provider-local or policy-local rather than portable portal truth.
   - Phase 1 does **not** reinterpret local warning/block/interstitial behavior as a requester-visible result, durable receipt, or transcript-stable statement that launch also classified the target as safe, unsafe, phishy, malicious, or policy-allowed.

2. **Threat/reputation checks stay on explicit review/policy seams**
   - Generic OpenURI is about *admission of a mediated launch*, not about returning or standardizing URL threat classification.
   - If reviewed URL-safety or reputation work matters, it must live on an explicit future review/classification/policy seam with its own evidence, freshness, privacy, and override semantics.
   - Phase 1 therefore does **not** reinterpret generic launch as authority to query or depend on browser/OS reputation systems on the requester’s behalf.

3. **Why this boundary exists**
   - Existing ecosystems really do expose these surfaces. Google Safe Browsing lets clients check URLs against lists of unsafe resources. Microsoft Defender SmartScreen applies phishing/malware/reputation checks to sites and downloads. Safari surfaces fraudulent/deceptive website warnings.
   - Those are valuable protections, but they are also exactly the kind of mutable, provider-fed, policy-shaped truth that would make `portal.uri.*` drift into a hidden URL-classification, reputation, or security-policy broker if imported casually.
   - Pinning the boundary now keeps workstation UX flexible without forcing cloud, embedded, or agent profiles to inherit fake portable threat-verdict semantics as substrate meaning.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future reviewed URL-safety / threat-verdict surface must state its own conflict keys, commutativity, freshness rules, and evidence strategy explicitly rather than inheriting folklore from browser warnings, reputation services, or enterprise blocklists.
   - Until then, generic `open_uri` remains admission-scoped only; URL-safety classification stays hidden inside provider-local warning and policy systems.

5. **Safety/reputation is a second workflow, not generic launch**
   - If SlopOS ever needs reviewed phishing/malware/reputation semantics, that work should return as a **separate RFC-first workflow/surface** with explicit authority, profile gating, transcript semantics, and privacy-aware evidence hooks.
   - It must not arrive by adding “just one more safety verdict field” to generic `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `safe_browsing`, `url_reputation`, `threat_verdict`, `threat_type`, `phishing`, `malware`, `deceptive_site`, `unsafe_reason`, `block_reason`, `reputation_score`, `safe_to_open`, `enterprise_verdict`, or equivalent URL-safety/threat-verdict knob/result on generic OpenURI.
- No transcript-stable statement that launch also cleared or blocked the target under a phishing/malware/reputation policy.
- No importer-visible browser-warning / enterprise-verdict / URL-reputation folklore on the D-PLUMB seam.
- No shell/helper fallback that quietly promotes `open_uri` into a URL-classification or reputation-check workflow and reports that second workflow as generic OpenURI truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, agents and wrappers quickly start depending on guessed semantics like “open this if it is safe,” “tell me whether this URL is phishing,” or “return the reputation verdict before launch.” Once those assumptions land in transcripts, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a hidden URL-safety or reputation-query authority. That matters for all four product shapes: workstation UX can still use local warning/interstitial systems without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting mutable external reputation contracts they do not want; and agent tooling cannot mistake `open_uri` for permission to query or depend on hidden URL-classification truth.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still use Safe Browsing / SmartScreen / fraudulent-website-warning style checks locally, but generic OpenURI does not standardize threat verdicts as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake browser-reputation or enterprise-policy contracts they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising general-purpose URL-reputation or phishing-verdict APIs they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with permission to demand `threat_verdict`, `safe_to_open`, `phishing`, or `malware` results; reviewed URL-classification work stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/intent-kind-registry.md`
- `docs/30-architecture/effect-contract-schema-v0.md`
- `docs/60-engineering/cli-plumbing-tooling.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_openuri_url_safety_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable URL-safety/phishing/malware/reputation-verdict seam / threat-reputation checks stay on explicit review-policy seams / safety-reputation is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-593**).

## References

- REF-GOOGLE-SAFE-BROWSING.
- REF-MICROSOFT-DEFENDER-SMARTSCREEN.
- REF-APPLE-SAFARI-FRAUDULENT-WEBSITE-WARNING.
