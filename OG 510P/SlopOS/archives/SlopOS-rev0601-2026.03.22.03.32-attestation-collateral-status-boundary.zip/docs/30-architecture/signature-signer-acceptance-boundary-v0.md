# Signature signer-acceptance boundary v0 (required signer sets stay explicit local policy; no envelope-selected quorum/role plane)

Purpose: pin the **Phase 1** meaning of signer-set, quorum, and signer-role acceptance around **D-SIGENV** and **D-KEYLESS** so multiple signatures, signer hints, and imported ecosystem conventions do not quietly turn into artifact-selected threshold policy, maintainer lookup, or duplicate-counting folklore.

Entropy cost justification: `signature-envelope-posture-v0.md`, `signature-trust-root-boundary-v0.md`, `signature-algorithm-acceptance-boundary-v0.md`, `keyless-issuer-discovery-boundary-v0.md`, and `verification-policy-selection-boundary-v0.md` already pin *what is signed*, *which roots are trusted*, *which algorithms are acceptable*, *how issuer discovery is handled*, and *who chooses verifier policy*. The remaining ambiguity is narrower and still expensive: **once several signature records are present, who counts as an accepted signer and how many accepted signers are required**. One narrow boundary closes that gap without adding a new schema family, signer-directory service, or quorum-policy object.

## Posture (v0)

1) **Signature records are exact signer evidence, not acceptance policy by themselves.**
   - `CH-SIGENV v0` may carry one or more signature records over the same `(payload.schema, payload.digest)` binding.
   - Each signature record is exact evidence that one key or certificate chain produced one signature over those bytes.
   - The mere presence of several signature records does **not** by itself say whether admission requires any-one-of, all-of, threshold-of, per-role, or per-step acceptance.

2) **Required signer sets, thresholds, and role/group mappings remain explicit verifier-local / profile-local policy.**
   - TUF roles explicitly bind trusted keys and signature thresholds to one role, and in-toto layouts explicitly bind authorized `pubkeys` plus a per-step `threshold`.
   - In SlopOS Phase 1, accepted signer sets, signer roles, and quorum requirements therefore remain explicit local/profile policy under **D-SIGENV**, **D-KEYLESS**, **I-SIGENV-1**, **I-KEYLESS-1**, **PO-SIGENV-VERIFY**, and **PO-KEYLESS-VERIFY**.
   - A signed object does **not** get to choose “trust any one signer in this array”, “treat these as two-person review”, or “this signer set satisfies release-owner policy” by envelope shape alone.

3) **Signer hints do not choose quorum membership or signer identity classes.**
   - `key_id` in `direct_key` signatures remains an unauthenticated hint only.
   - `issuer`, `identity.subject`, `identity.repo`, `identity.workflow`, and `identity.commit` in `keyless_cert` signatures remain non-authoritative hints unless explicit local policy re-derives and accepts them.
   - Those hints do **not** by themselves assign a signer to a durable role such as “maintainer”, “release owner”, “security approver”, or “builder quorum member”.

4) **No artifact-selected duplicate-counting / strongest-identity / fallback plane in v0.**
   - Multiple signatures that happen to chain to the same trust root, map to the same account, reuse related subkeys, or share a certificate identity do **not** gain a portable “counts as N distinct approvers” rule.
   - Conversely, a verifier is not forced to collapse signatures by any one built-in deduplication rule; exact duplicate-counting and signer-equivalence rules stay explicit local policy.
   - Phase 1 therefore adds no native “highest signature count wins”, “prefer keyless over direct”, “first valid signer is enough”, or “count every record independently” rule.

5) **Signer-role and delegation semantics stay outside CH-SIGENV.**
   - TUF delegated-role trust, in-toto functionary authorization, enterprise release-owner rosters, forge-maintainer groups, and code-review quorum rules remain explicit local policy inputs or explicit external artifacts.
   - `CH-SIGENV` does **not** create a native signer-directory, maintainer-lookup, team-membership, or role-resolution plane.

6) **Changing accepted signer policy affects future verification only.**
   - Tightening or widening accepted signer sets, quorum counts, signer-role mappings, or duplicate-counting rules MAY change how future verification is performed.
   - It MUST NOT rewrite old signed bytes, mutate existing evidence artifacts, or silently transform past verification outcomes into a portable “still approved because signer policy changed” object.

7) **Sealed compat remains honest.**
   - Compat/import paths that infer accepted signers from host package-manager trust DBs, forge-owner APIs, SCM branch protections, GPG keyrings, or language-runtime signer caches must remain killable by policy and must not create hidden authority via paths, env vars, or implicit network fetch.
   - A compat path that cannot verify signer-set or quorum requirements without ambient discovery must fail closed for portable Phase 1 semantics.

8) **No native signer-set inventory / watch / lookup plane in v0.**
   - Phase 1 adds no “list accepted signers for this artifact”, “discover the required review quorum”, “fetch the current maintainer set”, or “ask the envelope which signer roles matter” service.
   - Any future signer-policy object or quorum-discovery workflow must land as separate RFC-first work with explicit discovery, recording, and evidence hooks.

9) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no new ACP kind, and no new conflict-key namespace.
   - It only narrows what multi-signature presence and signer hints are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native signer-quorum / signer-role policy object/schema in Phase 1.
- No artifact-selected any-one-of / all-of / threshold-of signer semantics.
- No portable duplicate-counting rule for related subkeys, cert identities, or account-linked signers.
- No signer-directory / maintainer-lookup / team-membership discovery plane.
- No native watch/query API for “currently accepted signers” or “required quorum”.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, multi-signature verification almost always drifts in four expensive directions:

- **Envelope shape starts choosing trust.** A signature array gets treated as if it carries its own any-one-of or threshold acceptance rule.
- **Signer hints become identity authority.** Repo names, workflow names, certificate subjects, or `key_id` strings start behaving like native signer-role selectors.
- **Duplicate counting becomes folklore.** Related subkeys, repeated cert identities, or service-linked accounts quietly count as distinct approvals because a wrapper happened to emit several records.
- **Forge/update ecosystem roles bleed into the core seam.** TUF roles, in-toto functionaries, or hosting-site maintainer groups get imported as if `CH-SIGENV` itself knows what a “release approver” is.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** local package or document verification can require one explicit signer set without inheriting repository-owner or desktop keyring folklore.
- **Cloud micro-VM / hosted substrate (B):** admission control can require exact signer quorums for artifacts while keeping signer-role policy reviewable and machine-local.
- **Embedded / separation-kernel-ish appliance (C):** appliances can ship tiny fixed signer sets and reject all ambient signer-directory or threshold-discovery behavior.
- **Agent / automation OS (D):** agents may inspect who signed, but they cannot smuggle “this counts as two approvals” or “treat this repo owner as trusted” semantics inside the evidence they want admitted.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/signature-algorithm-acceptance-boundary-v0.md`
  - `docs/30-architecture/signature-trust-root-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_signature_signer_acceptance_boundary.py` keeps the boundary small and discoverable (**EVID-2026-607**).

## References

- REF-TUF-SPEC
- REF-TUF-SURVIVABLE-KEY-COMPROMISE
- REF-IN-TOTO-SPEC
- REF-IN-TOTO-AUDIT-2023
