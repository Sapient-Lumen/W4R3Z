# D-CRYPTOSVC inventory boundary v0 (no portable key inventory / search / query seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable key-inventory, alias-listing, certificate-search, or metadata-query surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable key inventory / search / query seam in v0**
   - Phase 1 does **not** export a portable `list_keys`, `find_key`, `search_keys`, `query_keys`, `enum_aliases`, `contains_alias`, `match_cert`, `find_certificate`, `find_by_label`, `find_by_subject`, `find_by_issuer`, `find_by_hash`, `list_identities`, `list_certs`, `list_tokens`, `list_slots`, `object_search`, `query_template`, `item_query`, `return_all_matches`, `search_next`, or equivalent inventory/query field on IF-CRYPTOSVC, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - A provider may internally keep aliases, labels, certificates, token objects, handles, or metadata indexes, but that inventory remains provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret local key/certificate query results as a requester-visible result, durable receipt, or transcript-stable statement that one exact alias, certificate row, or search result set was enumerated on behalf of the caller.

2. **Key use stays bound to already-held authority, not discovery of more authority**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff, not about standardizing how callers browse providers, search by alias/label/subject, or enumerate candidate keys/certificates.
   - If reviewed inventory/search work matters, it must live on an explicit future provider-management or chooser seam with its own privacy, redaction, pagination, availability, and evidence semantics.
   - Phase 1 therefore does **not** reinterpret CH-KEYREF `provider` metadata as an invitation to search the provider’s whole keyspace; durable refs stay handoff/audit hooks, not a query capability.

3. **Inventory/search is a second workflow, not generic crypto use**
   - Existing ecosystems really do expose these surfaces. PKCS #11 standardizes object search over token and session objects. Apple keychain services return matching items for search queries. Windows certificate stores expose first/next search and store enumeration APIs. Java `KeyStore` explicitly lists aliases and queries entries by alias.
   - Those are valuable product workflows, but they also allocate extra metadata, privacy, pagination, chooser, and result-shaping semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden key browser, certificate-search broker, or alias-query plane.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future inventory/search/chooser seam must state its own conflict keys, commutativity, serialization point, privacy/redaction policy, result-stability guarantees, and evidence plan explicitly rather than inheriting folklore from PKCS#11 object search, keychain item queries, certificate-store search, or keystore alias APIs.
   - Until then, generic crypto use remains keyref/route-bound only; key inventory/search/query stays hidden inside provider-local or deployment-local setup/chooser workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `list_keys`, `find_key`, `search_keys`, `enum_aliases`, `match_cert`, `find_by_label`, `find_by_subject`, `list_certs`, or equivalent inventory/query knob/result on generic crypto use.
- No transcript-stable statement that crypto use also enumerated provider-held aliases, certificates, labels, or token objects on behalf of the caller.
- No importer-visible provider-global key/certificate inventory/search folklore on the D-CRYPTOSVC seam.
- No shell/helper fallback that quietly promotes key use into a query/chooser workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “find the signing key whose label contains release”, “return all matching certificates”, “list the aliases and let the tool choose”, or “look up the key by subject hash and then sign.” Once those assumptions land in transcripts and automation, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden inventory/search plane. That matters for all four product shapes: workstation UX can still use local choosers or certificate pickers without standardizing them as portable substrate meaning; hosted and embedded profiles avoid inheriting key-browser/cert-store contracts they do not want; and agent tooling cannot mistake CH-KEYREF/IF-CRYPTOSVC for permission to probe provider-held metadata until something interesting turns up.

## Profile effect (A–D)

- **Secure workstation (A):** local certificate/key pickers may still exist, but generic crypto use does not standardize alias lists, store searches, or chooser result sets as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake certificate-store or key-inventory semantics they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose key-browser/search APIs they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to enumerate provider-held identities, search by label, or mine certificate metadata; reviewed discovery stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_inventory_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable key inventory / search / query seam / key use stays bound to already-held authority / inventory-search is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-600**).

## References

- REF-PKCS11-SPEC.
- REF-APPLE-KEYCHAIN-ITEMS.
- REF-MICROSOFT-CERTFINDCERTIFICATEINSTORE.
- REF-ORACLE-JAVA-KEYSTORE.
