# Keyless issuer-discovery boundary v0 (OIDC/OAuth metadata stays signer/client config; no ambient well-known/JWKS plane)

Purpose: pin the **Phase 1** meaning of OIDC/OAuth issuer discovery around **D-SIGENV** and **D-KEYLESS** so cert-bearing verification does not quietly inherit `.well-known` fetches, JWKS refresh, browser login loops, or issuer-metadata folklore as portable authority.

Entropy cost justification: `signature-envelope-posture-v0.md`, `certificate-identity-evidence-boundary-v0.md`, and `signature-trust-root-boundary-v0.md` already pin signed meaning, certificate-claim interpretation, and explicit verifier trust roots. The remaining ambiguity is **whether issuer metadata discovery or signer-side online service configuration is part of keyless verifier meaning**. One narrow boundary closes that gap without adding a new schema family, login portal, or issuer-query plane.

## Posture (v0)

1) **OIDC/OAuth issuer metadata are client interaction metadata, not portable verifier authority.**
   - OpenID Connect Discovery and OAuth Authorization Server Metadata define how clients discover issuer metadata, endpoint locations, and related capabilities for online interaction.
   - In SlopOS Phase 1, those discovery documents remain **client/signer-side online configuration**, not portable verifier authority for **D-KEYLESS** admission.
   - A verifier therefore does not treat discovery metadata as an ambient approval object or substrate-native policy plane.

2) **Keyless verification does not require `.well-known`, OAuth metadata, JWKS, UserInfo, or introspection fetch.**
   - Accepted **CH-SIGENV** meaning remains the verified binding of `(payload.schema, payload.digest)` plus explicit local issuer/identity policy and explicit local trusted roots.
   - If a deployment accepts `keyless_cert`, it does so using the presented certificate/evidence plus explicit local policy under **I-SIGENV-1**, **I-KEYLESS-1**, **PO-SIGENV-VERIFY**, and **PO-KEYLESS-VERIFY**.
   - Phase 1 therefore adds no portable rule that verification must reach out to issuer metadata, JWKS endpoints, UserInfo, token introspection, or similar online issuer services.

3) **Signer-side service configuration remains signer-local online config, not verifier policy.**
   - Sigstore `SigningConfig` and similar descriptors primarily carry service URLs and selection hints for the online aspects of signing.
   - CA URLs, OIDC provider choices, API-version preferences, timestamp-service URLs, and similar signer-side knobs do **not** define verifier policy or portable admission meaning in SlopOS.
   - A bundle, release note, or signer config therefore cannot say “verify by contacting these issuer services”.

4) **Issuer metadata rotation does not retroactively rewrite verification or approval.**
   - Changing discovery metadata, `jwks_uri`, endpoint sets, or issuer-side service topology MAY change how a signer or login client talks to an issuer in the future.
   - It MUST NOT retroactively rewrite prior verification evidence, mutate old receipts, or turn a past verification result into a portable “still approved because the issuer metadata now says so” verdict.
   - Verification remains about exact presented evidence plus explicit local policy, not latest issuer metadata.

5) **No ambient browser login / WebFinger / repo-membership lookup plane in v0.**
   - Phase 1 adds no portable browser login loop, no native WebFinger / `.well-known` issuer discovery client, no UserInfo / introspection / SCIM / repo-membership lookup plane, and no hidden “ask the forge/IdP whether this identity is still good” protocol.
   - Owner-local tooling may choose to use those services outside the portable verifier contract, but that behavior must remain explicit, policy-killable, and non-authoritative as substrate meaning.

6) **Interop discovery documents stay out-of-band and digest-bound; no new native issuer-discovery schema family in Phase 1.**
   - Discovery metadata JSON, OAuth metadata, issuer policy notes, or cached JWKS documents may be packaged or referenced as exact adjunct artifacts (for example through **CH-AREF** or release bundles).
   - They remain adjunct evidence or signer tooling inputs rather than a native issuer-discovery CH-* schema family.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of host browser caches, SDK discovery helpers, or ambient OIDC metadata caches must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot verify without ambient issuer discovery must fail closed for portable **D-SIGENV / D-KEYLESS** semantics.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no ACP kind, and no conflict-key namespace.
   - It only narrows what issuer discovery and signer-side service metadata are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native OIDC/OAuth issuer-discovery CH-* schema family in Phase 1.
- No portable `.well-known` / WebFinger / JWKS / UserInfo / introspection client protocol in privileged code.
- No portable browser login loop or ambient IdP session reuse semantics.
- No repo-membership / forge-owner / SCIM lookup plane for keyless verification.
- No retroactive approval semantics when issuer metadata or JWKS changes later.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, keyless verification almost always drifts in four expensive directions:

- **Signer login plumbing becomes verifier truth.** Online issuer metadata and service URLs leak from signer tooling into portable admission meaning.
- **Ambient issuer discovery outruns explicit policy.** A local SDK or browser silently fetches `.well-known` metadata or JWKS and whatever it found becomes “what verification means on this box”.
- **Current account/forge state rewrites past evidence.** Repo membership, issuer account status, or SCIM/userinfo answers get treated as if they can retroactively approve or revoke old signed evidence.
- **Hidden network dependencies erode sealed compat.** A nominally offline verifier quietly depends on issuer metadata endpoints, browser state, or live identity-provider availability.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** reviewable verification can stay offline-first and explain which certificate claims plus local policy were accepted, instead of inheriting hidden browser/SDK discovery behavior.
- **Cloud micro-VM / hosted substrate (B):** admission workers can verify keyless signatures without ambient `.well-known` or JWKS fetch paths leaking across tenants or node images.
- **Embedded / separation-kernel-ish appliance (C):** high-assurance profiles can ship tiny explicit verifier policy and reject any dependence on issuer metadata/network availability.
- **Agent / automation OS (D):** agents can carry issuer metadata as adjunct artifacts for review, but they cannot smuggle live OIDC discovery, repo-membership checks, or browser login state into portable approval authority.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/certificate-identity-evidence-boundary-v0.md`
  - `docs/30-architecture/signature-trust-root-boundary-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_keyless_issuer_discovery_boundary.py` keeps the boundary small and discoverable (**EVID-2026-470**).

## References

- REF-SIGSTORE-TRUSTROOT-PROTO
- REF-SIGSTORE-FULCIO-OIDC
- REF-OPENID-DISCOVERY
- REF-RFC8414-AS-METADATA
