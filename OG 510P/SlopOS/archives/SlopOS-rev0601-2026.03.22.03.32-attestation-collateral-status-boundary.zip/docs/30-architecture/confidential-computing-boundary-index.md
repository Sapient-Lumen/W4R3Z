# Confidential-computing boundary index (v0)

Purpose: keep the **closed set of D-CC companion boundary docs** enumerable.

Why this exists:
- the archive now pins many small confidential-computing companion boundaries so provider-native attestation/report fields and endorsement paths do not quietly become native SlopOS authority,
- those docs are individually crisp but easy to lose piecemeal because they span implementation sequencing, binder bytes, certificate/signer trust inputs, imported profile-claim seams, and multiple provider-native SNP report fields,
- `attestation-posture-v0.md` and RFC-0064 keep the overall meaning of D-CC / D-ATTEST, while this index is the **discovery surface** that says which companion boundaries currently keep the SNP-first Phase 1 path fail closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `attestation-posture-v0.md`, `attestation-pack-schema-v0.md`, and RFC-0064.

## Inclusion rule

A doc belongs here if it removes exactly one tempting confidential-computing meaning from Phase 1 by constraining one of:
- implementation-target or guest-mode ambiguity that would otherwise smuggle a second provider target or guest architecture into the first coding target,
- provider-native binder / endorsement / signer semantics that would otherwise smuggle in a native certificate-discovery, trust-enrollment, signer-class, or hidden approval plane,
- imported profile-claim semantics that would otherwise smuggle an optional embedded claim vocabulary into native D-CC meaning,
- provider-native report-field semantics that would otherwise smuggle in a native machine identity, release identity, security-profile, rollback, or portable approval plane.

If future work needs a new native attestation, trust-distribution, migration, or provider-admin surface instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind imported provider evidence.

## Closed companion boundary set (Phase 1)

### 1) Coding target and exact binder contract stay explicit

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-reference-target-boundary-v0.md`](confidential-computing-reference-target-boundary-v0.md) | first provider target | the first end-to-end D-CC binder/verifier harness targets AMD SEV-SNP; TDX/CCA stay annexes rather than co-equal blockers | explicit RFC-first future annexes |
| [`confidential-computing-reportdata-binding-boundary-v0.md`](confidential-computing-reportdata-binding-boundary-v0.md) | 64-byte report-data bytes | provider-native report-data carriers use one exact `ccbind_input_v0` → `cc_report_data_v0` contract rather than “canonical equivalent” folklore | exact `cc_report_data_v0` binding |
| [`confidential-computing-snp-vmpl-mode-boundary-v0.md`](confidential-computing-snp-vmpl-mode-boundary-v0.md) | SNP guest-mode cut | the portable SNP-first target is a fully enlightened VMPL0 guest only; Multi-VMPL / SVSM / paravisor layouts stay future annex work | explicit future annex / new guest-architecture work |

### 2) Endorsement transport and signer semantics stay verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-snp-certificate-source-boundary-v0.md`](confidential-computing-snp-certificate-source-boundary-v0.md) | GHCB / host-memory certificate tables | host-delivered cert material is transport only rather than trust-root authority or hidden KDS policy | explicit local roots / signer policy / tooling |
| [`confidential-computing-snp-signing-metadata-claim-boundary-v0.md`](confidential-computing-snp-signing-metadata-claim-boundary-v0.md) | `SIGNATURE_ALGO` / `SIGNING_KEY` / `MASK_CHIP_KEY` | signer metadata stays exact provider-native evidence rather than a portable provider-class, trust-profile, or unsigned-attestation fallback | explicit verifier-local signer/certificate policy |

### 3) Imported profile claims stay profile-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-eat-payload-claim-boundary-v0.md`](confidential-computing-eat-payload-claim-boundary-v0.md) | embedded `eat_payload` EAT claims | optional embedded EAT claims stay profile-local evidence rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable claim registry or approval language | explicit verifier-local profile policy or future RFC-first mapping |

### 4) Provider-native guest-context and report fields stay exact evidence under local policy

Why bucket by authorship:
- **who authored the bytes** is the practical trust-plane discriminator for the current SNP-first D-CC family,
- it is the fastest way to see which tempting meanings must stay verifier-local rather than silently becoming portable `CH-ATTEST` truth,
- and it keeps future verifier/secret-release work from relearning the same “host vs owner vs firmware vs mixed linkage” lesson piecemeal.

#### 4a) Host / hypervisor-authored inputs stay exact provider-native evidence

| Boundary doc | Pins | Why authorship matters | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-snp-hostdata-claim-boundary-v0.md`](confidential-computing-snp-hostdata-claim-boundary-v0.md) | `HOST_DATA` | host-authored launch bytes must not become a portable attestation/policy channel | exact provider evidence plus local policy |
| [`confidential-computing-snp-gosvw-claim-boundary-v0.md`](confidential-computing-snp-gosvw-claim-boundary-v0.md) | `GOSVW` / `guest-visible-workarounds` | hypervisor-defined workaround bytes must not become a portable feature vector, machine class, compatibility tier, or approval plane | exact provider evidence plus local policy |

#### 4b) Owner-authored launch metadata and policy inputs stay exact provider-native evidence

| Boundary doc | Pins | Why authorship matters | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-snp-launch-identity-claim-boundary-v0.md`](confidential-computing-snp-launch-identity-claim-boundary-v0.md) | `FAMILY_ID` / `IMAGE_ID` / `ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST` | owner-authored launch labels/signer digests must not become portable image/release identity or signer-role meaning | exact provider evidence plus local policy |
| [`confidential-computing-snp-policy-claim-boundary-v0.md`](confidential-computing-snp-policy-claim-boundary-v0.md) | `POLICY` | owner-authored launch-policy bits must not become a portable security-profile or approval language | exact provider evidence plus local policy |
| [`confidential-computing-snp-guest-svn-claim-boundary-v0.md`](confidential-computing-snp-guest-svn-claim-boundary-v0.md) | `GUEST_SVN` | owner-authored guest-version data must not become portable release-order, rollback, or approval meaning | exact provider evidence plus local policy |

#### 4c) Firmware / hardware-generated outputs stay exact provider-native evidence

| Boundary doc | Pins | Why authorship matters | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-snp-report-identity-claim-boundary-v0.md`](confidential-computing-snp-report-identity-claim-boundary-v0.md) | `REPORT_ID` / `REPORT_ID_MA` | firmware-generated report identifiers must not become portable instance/migration identity or replay/freshness meaning | exact provider evidence plus local policy |
| [`confidential-computing-snp-chip-id-claim-boundary-v0.md`](confidential-computing-snp-chip-id-claim-boundary-v0.md) | `CHIP_ID` | chip linkage must not become portable machine/asset identity or anti-cloning truth | exact provider evidence plus local policy |
| [`confidential-computing-snp-measurement-claim-boundary-v0.md`](confidential-computing-snp-measurement-claim-boundary-v0.md) | `MEASUREMENT` | provider-native launch digest must not replace portable `boot_digest` meaning or rollout identity | exact provider evidence plus `boot_digest == digest(CH-BOOT)` |
| [`confidential-computing-snp-platform-info-claim-boundary-v0.md`](confidential-computing-snp-platform-info-claim-boundary-v0.md) | `PLATFORM_INFO` | platform-configuration bits must not become a portable security-profile, machine-class, or capability plane | exact provider evidence plus local policy |
| [`confidential-computing-snp-version-metadata-claim-boundary-v0.md`](confidential-computing-snp-version-metadata-claim-boundary-v0.md) | `VERSION` / `CURRENT_*` / `COMMITTED_*` | provider-native report/firmware version metadata must not become portable platform maturity, capability, or approval meaning | exact provider evidence plus local parser/version policy |
| [`confidential-computing-snp-signing-metadata-claim-boundary-v0.md`](confidential-computing-snp-signing-metadata-claim-boundary-v0.md) | `SIGNATURE_ALGO` / `SIGNING_KEY` / `MASK_CHIP_KEY` | signer metadata must not become a portable provider-class, trust-profile, or unsigned-attestation fallback | explicit verifier-local signer/certificate policy |

#### 4d) Mixed signer / endorsement linkage fields stay exact provider-native evidence

| Boundary doc | Pins | Why authorship matters | Explicit seam instead |
|---|---|---|---|
| [`confidential-computing-snp-tcb-field-claim-boundary-v0.md`](confidential-computing-snp-tcb-field-claim-boundary-v0.md) | `CURRENT_TCB` / `COMMITTED_TCB` / `REPORTED_TCB` / `LAUNCH_TCB` | distinct TCB fields have mixed linkage/endorsement meaning and must not collapse into one portable baseline or patch-level claim | exact provider evidence plus local threshold policy |

## Review rule

Before adding another `confidential-computing-*-boundary-v0.md` doc, answer these questions in order:
1) Is the change really a **D-CC meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing explicit seam already in the table above?
3) If not, is the entropy cost worth paying for **one new companion boundary doc** rather than widening imported provider semantics?
4) If yes, which **authorship bucket** owns the bytes: host/hypervisor-authored, owner-authored, firmware/hardware-generated, or mixed signer/endorsement linkage?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision**, place it in exactly one authorship bucket (or justify why it belongs outside section 4), and keep the drift gate aligned so confidential-computing discovery cannot silently rot.
