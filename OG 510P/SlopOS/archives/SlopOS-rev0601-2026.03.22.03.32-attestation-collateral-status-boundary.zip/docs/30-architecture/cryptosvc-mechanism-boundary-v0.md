# D-CRYPTOSVC mechanism boundary v0 (no portable mechanism / algorithm-capability / padding-mode seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable mechanism-selection, algorithm-capability discovery, padding/mode/hash/curve tuning, or provider-property-query surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable mechanism / algorithm-capability / padding-mode seam in v0**
   - Phase 1 does **not** export a portable `list_mechanisms`, `get_mechanism_info`, `list_algorithms`, `get_algorithm_properties`, `get_capabilities`, `supports_pss`, `supports_oaep`, `supports_curve`, `hash_alg`, `padding`, `mode`, `curve`, `salt_len`, `mgf`, `oaep_label`, `chaining_mode`, `algorithm_provider`, `provider_service`, or equivalent mechanism/capability knob or result on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - Providers may internally map one key reference to specific mechanisms, curves, paddings, hardware capabilities, or provider properties, but those details remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret local provider capability discovery or per-algorithm property reads as a requester-visible result, durable receipt, or transcript-stable statement that one exact mechanism/profile/property set was negotiated on behalf of the caller.

2. **Key use stays policy-pinned, not caller-negotiated**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff plus pinned CH-KEYPOL data, not about standardizing how callers enumerate mechanisms, negotiate algorithm profiles, or tune provider properties until some backend agrees.
   - `CH-KEYPOL.alg` remains a local policy pin/hint for provider enforcement and audit; it is **not** a portable mechanism-discovery API, capability-advertisement vocabulary, or caller-directed negotiation transcript.
   - If reviewed mechanism/property discovery or caller-tunable crypto profiles matter, they must live on an explicit future provider-management or crypto-profile seam with their own compatibility, privacy, downgrade, and evidence semantics.

3. **Mechanism discovery/tuning is a second workflow, not generic crypto use**
   - Existing ecosystems really do expose these surfaces. PKCS #11 standardizes mechanism enumeration and mechanism-info queries per token. Microsoft CNG opens algorithm providers and exposes provider properties such as key size or chaining mode. Java security providers enumerate services/algorithms. WebCrypto takes explicit algorithm dictionaries while also warning that extra capability reflection can increase fingerprinting risk.
   - Those are valuable product workflows, but they also allocate extra downgrade, compatibility, capability-fingerprinting, and parameter-negotiation semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden mechanism browser, algorithm-property broker, or retry-until-supported negotiation plane.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future mechanism-discovery / crypto-profile / provider-property seam must state its own conflict keys, commutativity, serialization point, downgrade/fallback policy, privacy/redaction rules, and evidence plan explicitly rather than inheriting folklore from PKCS#11 mechanism lists, CNG provider properties, JCA provider services, or WebCrypto algorithm dictionaries.
   - Until then, generic crypto use remains keyref/route-bound only; mechanism/property discovery and caller-tunable algorithm negotiation stay hidden inside provider-local or deployment-local setup workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `list_mechanisms`, `get_mechanism_info`, `list_algorithms`, `get_algorithm_properties`, `supports_pss`, `supports_curve`, `padding`, `mode`, `hash_alg`, `curve`, `salt_len`, or equivalent mechanism/capability knob/result on generic crypto use.
- No transcript-stable statement that crypto use also negotiated one exact padding/mode/hash/curve/provider-property profile on behalf of the caller.
- No importer-visible provider capability-fingerprinting folklore on the D-CRYPTOSVC seam.
- No shell/helper fallback that quietly promotes key use into a mechanism-discovery or retry-until-supported negotiation workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “try RSA-PSS, then PKCS#1 v1.5 if unsupported”, “ask the token which curves it supports and pick one”, “set the provider’s chaining mode first”, or “return the algorithm/profile that actually worked so automation can remember it.” Once those assumptions land in transcripts and automation, they become hard to retract and easy to misuse as downgrade or fingerprinting channels. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden capability-discovery or profile-negotiation plane. That matters for all four product shapes: workstation UX can still host local pickers or profile adapters without standardizing them as substrate meaning; hosted and embedded profiles avoid inheriting fake per-backend mechanism/property contracts they do not want; and agent tooling cannot mistake CH-KEYREF/CH-KEYPOL for permission to probe provider capabilities until something usable appears.

## Profile effect (A–D)

- **Secure workstation (A):** local compatibility shims or certificate/profile pickers may still exist, but generic crypto use does not standardize provider-mechanism discovery or caller-chosen padding/mode results as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake token-capability/property APIs that would become downgrade and compatibility commitments.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose mechanism-discovery or caller-tunable crypto-profile APIs they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to enumerate provider algorithm support, iterate on padding/mode knobs, or mine provider properties; reviewed profile negotiation stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_mechanism_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable mechanism / algorithm-capability / padding-mode seam / key use stays policy-pinned, not caller-negotiated / mechanism discovery-tuning is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-601**).

## References

- REF-PKCS11-SPEC.
- REF-MICROSOFT-CNG-TYPICAL-PROGRAMMING.
- REF-ORACLE-JAVA-PROVIDER.
- REF-W3C-WEBCRYPTO-2.
