# D-PLUMB OpenURI materialization boundary v0 (no portable download / staging / docref-minting seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable download, staged-copy, local-import, or docref-minting workflow.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable download / staging / docref-minting seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `download=true`, `stage_local_copy`, `import_to_file`, `save_as_docref`, `materialize_uri`, `download_id`, `staged_path`, `docref`, or equivalent download/materialization/import result on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Handler-local caching or downloads stay handler-local and non-authoritative.**
   - A chosen handler may fetch, cache, stream, or locally materialize content as part of its own implementation.
   - That does **not** make the fetched bytes, cache entry, local path, or stored copy a portable portal result or a reviewed substrate contract.
   - Phase 1 therefore declines requesters learning a durable local filename, FUSE-export path, CH-DOCREF, transfer key, or reusable import handle merely because a handler opened a URI.

3) **Explicit persistence/import lives on explicit file/document seams, not generic launch.**
   - If a product shape later needs a durable local object, reviewed export/import lineage, or user-approved reopen grant, that belongs on `portal.file.*`, CH-DOCREF, or a future RFC-first fetch/import workflow rather than as a side effect of generic launch.
   - Phase 1 therefore keeps `portal.uri.*` separate from document-store entry creation, durable file grants, and local-object materialization semantics even when other ecosystems blur “open this URL” with “download this thing”.
   - Generic OpenURI remains a mediated launch workflow, not a back door into file persistence, staging, or import authority.

4) **Why this cut is honest.**
   - Real ecosystems already separate these seams: XDG OpenURI opens URIs, while the Documents portal adds files to a controlled document store and returns document IDs / persistent FUSE exposure; Android likewise gives durable user-approved document access through SAF and separate download/materialization APIs rather than by overloading generic launch.
   - Those imports are useful on their home platforms, but importing them into generic OpenURI would widen `portal.uri.*` from a one-shot mediated launch into a hidden fetch/import/persistence plane with file-authority side effects.
   - SlopOS keeps launch meaning small and pushes durable bytes/object identity onto explicit file/document workflows unless and until a future RFC deliberately standardizes something richer.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new materialize/download action family, conflict-key family, or serialization surface.
   - Any future fetch/import/persistence seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from launcher UX.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “download this URI to a local file for me” behavior through helper fallbacks.
   - If compat wants durable bytes, it still pays for explicit `portal.file.*` / transfer / future fetch-import seams rather than smuggling local-object minting through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `download=true`, `stage_local_copy`, `materialize_uri`, `import_to_file`, `save_as_docref`, or equivalent OpenURI knob.
- No `download_id`, `staged_path`, `docref`, transfer key, or durable local-object receipt on generic URI launch.
- No hidden handler-side cache/download path treated as portable substrate truth.
- No automatic document-portal enrollment, CH-DOCREF minting, or persistence side effect behind OpenURI success.
- No host-helper fallback that quietly turns generic URI launch into a fetch/import pipeline.

## Why this is worth pinning

Once OpenURI exists, another tempting convenience import is “should this URI just download into a local object for me?” or “can the launcher give me a durable handle to whatever was opened?” Desktop and mobile ecosystems do have APIs for reviewed file/document access and for explicit download/materialization, but they are distinct surfaces because they carry very different authority and persistence consequences.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a hidden fetch/import seam. That matters for all four product shapes: workstation UX can still open links without auto-minting durable file authority; hosted and embedded profiles avoid carrying a fake download/local-path plane they do not want; and agents cannot mistake “opened this URI” for “now I own a stable local object”.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/document-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_materialization_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable download/materialization/docref-minting seam / handler-local downloads stay non-authoritative / explicit persistence-import lives on file/document seams / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-580**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-ANDROID-SAF-DOCUMENTS.
- REF-ANDROID-DOWNLOADMANAGER-REQUEST.
