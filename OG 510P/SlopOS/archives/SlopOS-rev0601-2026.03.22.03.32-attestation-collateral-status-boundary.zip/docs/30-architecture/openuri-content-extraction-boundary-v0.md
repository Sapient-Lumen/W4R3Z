# D-PLUMB OpenURI content-extraction boundary v0 (no portable reader / article-distillation seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable reader-mode, article-distillation, readability, text/markdown extraction, or extracted-content workflow on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable reader / content-extraction seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `reader_mode`, `reader_view`, `distill`, `extract_article`, `extract_content`, `readability`, `article_text`, `article_html`, `article_markdown`, `text_content`, `summary`, or equivalent reader-mode / article-distillation / extracted-content field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Extracted content stays request-local or provider-local rather than transcript truth.**
   - A shell, browser, agent, or other handler may choose local UX for reader view, readability cleanup, “simplified page” rendering, or provider-local summaries.
   - Phase 1 does **not** reinterpret that provider-local behavior as a portable requester-visible result, stable receipt, or transcript-stable statement that a particular article body, cleaned HTML, markdown rendering, or summary was extracted.
   - Generic OpenURI therefore stays launch-oriented rather than becoming a reusable content-extraction oracle for arbitrary URIs.

3) **Reader-mode extraction is a second workflow, not generic launch.**
   - Extracting article text or simplified HTML may imply dereferencing the target, DOM parsing, readability classification, sanitization, cache/state policy, relative-URL rewriting, or summary generation that differs from the eventual launched handler.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to distill the target into clean text/HTML/markdown, emit an extracted article object, or produce a reusable summary/result artifact.
   - If a future product shape needs reviewed reader-mode export, page distillation, text extraction, or summarization, that belongs on a future RFC-first fetch/extract seam rather than as a side effect of generic launch.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. Firefox’s Readability library is a standalone component used for Reader View and returns extracted title/content/text/excerpt/byline fields; Chromium Reader Mode uses DOM Distiller to classify distillable pages and extract core page content; Safari Reader presents a simplified article view and now even shows summaries for longer articles.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate extra fetch, parse, classify, sanitize, and representation semantics that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new reader/distillation action family, conflict-key family, or serialization surface.
   - Any future reader/extraction seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser UX or agent tooling.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this URL and also give me the article text/markdown/summary” behavior through helper fallbacks.
   - If compat needs reviewed reader-mode or extraction workflows, it still pays for an explicit future seam rather than smuggling content extraction through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `reader_mode`, `reader_view`, `distill`, `extract_article`, `extract_content`, `readability`, `article_text`, `article_html`, `article_markdown`, `text_content`, or `summary` knob/result on generic OpenURI.
- No portable title/body/byline/excerpt/content receipt or transcript-stable extracted-article object on generic URI launch.
- No shell/helper fallback that quietly dereferences the target, classifies it as distillable/readerable, rewrites relative links, sanitizes extracted HTML, or reports that second workflow as OpenURI truth.
- No portable summary export, article-markdown export, or reusable readability object on generic URI launch.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, non-materializing, and free of link-preview metadata folklore, but one more convenience import still lingers in modern browsers and agent tooling: “while you’re opening this URI, can you also give me the article text / cleaned HTML / markdown / summary?” That sounds harmless, but it quietly turns a launch seam into a fetch/parse/classify/sanitize/representation broker, which is much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a reader-mode or article-extraction substrate. That matters for all four product shapes: workstation UX can still render local reader views without standardizing extraction semantics; hosted and embedded profiles avoid carrying fetch/distillation machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to crawl arbitrary links for extracted text or summaries.

## Profile effect (A–D)

- **Secure workstation (A):** shells and apps may still show local reader-mode UI, but generic OpenURI does not standardize extracted-text, cleaned-HTML, or summary truth as app-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting browser/article-distiller behavior or extracted-content cache semantics from desktop/browser folklore.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising reader-mode extraction or simplified-content behavior they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “fetch and distill this URI”; reviewed extraction/summarization work stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_content_extraction_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable reader/content-extraction seam / extracted content stays request-local-or-provider-local / reader-mode extraction stays a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-585**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-MOZILLA-READABILITY.
- REF-CHROMIUM-READER-MODE.
- REF-POSTLIGHT-PARSER.
- REF-APPLE-SAFARI-READER.
