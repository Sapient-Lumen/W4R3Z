# Profile replication defaults matrix (A–D; no forks)

Purpose: pin **non-authoritative** default guidance for cross-cluster replication contracts (CH-REPLCONTRACT v0) across the four product shapes:

- (A) secure workstation,
- (B) cloud micro-VM / hosted compute substrate,
- (C) embedded / separation-kernel-ish appliance,
- (D) agent/automation OS.

This matrix is a **composition aid**, not a fork mechanism:
- For the artifact boundary between these recommendations and generated CH-CFG / CH-POLICY outputs, see `profile-default-artifact-boundary-v0.md`.
- Profiles may override these defaults in signed policy bundles / config compilers.
- Replication contracts are **non-authoritative** (PO-REPL-NOAMP): they cannot grant authority.
- For the `quota` family specifically, replicated RC3 state is observational/additive only; authorization still comes from local explicit payer authority (see `quota-replication-boundary-v0.md`).
- Unknown `object_family` tokens are rejected in strict profiles (see `replication-object-family-registry.md`).

Stability rule: treat this file as a **stable diff surface**. Any changes must keep A–D viable and keep D-REPL honest: global ordering is rare and explicit.

## Defaults (v0 seed; conservative)

Values are the CH-REPLCONTRACT v0 `replication_class` tokens:
- `rc0_local`
- `rc1_owner`
- `rc2_epoch_snapshot`
- `rc3_comm_merge`
- `rc4_ordered_log`

| object_family | A (workstation) | B (cloud substrate) | C (embedded/separation) | D (agent/automation) | Notes |
|---|---|---|---|---|---|
| `view` | `rc1_owner` | `rc1_owner` | `rc0_local` | `rc1_owner` | C defaults to local-only views (no cross-cluster UX surface); others route authoritative mutations to owner, while any replicated summaries remain read-only/non-activating (see `view-replication-boundary-v0.md`) |
| `transcript` | `rc3_comm_merge` | `rc3_comm_merge` | `rc2_epoch_snapshot` | `rc3_comm_merge` | C prefers epoch snapshots to bound storage/export; others use commutative CH-LOG event-set merge, but replicated transcripts remain evidence only and cannot drive replay/admission/runtime ordering (see `transcript-replication-boundary-v0.md`) |
| `receipt` | `rc3_comm_merge` | `rc3_comm_merge` | `rc2_epoch_snapshot` | `rc3_comm_merge` | same rationale as transcripts; receipts remain immutable digest-addressed evidence only and cannot drive replay/import/admission (see `receipt-replication-boundary-v0.md`) |
| `quota` | `rc3_comm_merge` | `rc3_comm_merge` | `rc0_local` | `rc3_comm_merge` | additive spend summaries only under already-issued local credit; no remote admission/borrowing from replicas (see `quota-replication-boundary-v0.md`) |
| `budget` | `rc1_owner` | `rc1_owner` | `rc0_local` | `rc1_owner` | authoritative issuer / lease-lineage metadata only; non-owner replicas may aid routing/audit/staleness checks but never create spendable local credit or widen a lease (see `budget-replication-boundary-v0.md`) |
| `caprpc_proxy` | `rc1_owner` | `rc1_owner` | `rc0_local` | `rc1_owner` | cross-cluster access is via owned proxies, not copied handles; replicated metadata may aid routing but does not create callable authority (see `caprpc-proxy-replication-boundary-v0.md`) |
| `namecert` | `rc3_comm_merge` | `rc3_comm_merge` | `rc3_comm_merge` | `rc3_comm_merge` | signed bundles merge as a digest-set; replication never auto-installs active bindings; local policy resolves trust/visibility/activation (see `namecert-replication-boundary-v0.md`) |
| `tlog` | `rc0_local` | `rc4_ordered_log` | `rc0_local` | `rc2_epoch_snapshot` | RC4 is reserved to `tlog` in v0; append-only evidence only; local explicit policy pins trusted logs/witnesses and whether anchors are advisory or required (see `tlog-replication-boundary-v0.md`) |

## RC4 admission rule (v0)

`rc4_ordered_log` is **reserved to `object_family = tlog`** in v0.
If any other family needs RC4 semantics, the archive must:
- update D-REPL posture (why order is required and where serialization lives), and
- add an evidence hook showing why RC3/RC2 is insufficient.

## Guardrail

CI enforces:
- `object_family` values are registry-closed (see `replication-object-family-registry.md`),
- `replication_class` values are from the closed enum above, and
- RC4 appears only in the `tlog` row.

Evidence: EVID-2026-214.

Tool: `tools/check_profile_repl_defaults.py`.

Companion discovery surface: `replication-boundary-index.md` (closed set of the current per-object-family replication meaning pins).
