# ACP denial-precedence posture v0 (policy/authority first; preconditions only after live authority)

Purpose: close one small but expensive ambiguity in **IF-ACP** now that SlopOS has both exact mutable-basis witness gates and explicit approval/policy denials.
When more than one reject condition is true at once, the archive should not leave `deny_code` selection up to incidental implementation order.

This doc keeps the rule narrow: for CH-ACP, **policy/authority denials win before exact precondition denials**.

## Posture (v0)

1) **Deterministic denial precedence is part of the stable receipt surface**
   - If IF-ACP emits `CH-DENY v0`, the chosen `deny_code` is not an implementation-private detail.
   - When multiple reject conditions are simultaneously true, producers MUST follow one reviewable precedence rule rather than whichever branch happened to run first.

2) **Live authority/policy gates win before `precondition-failed`**
   - For the current Phase 1 ACP seam, the relevant precedence ladder is:
     1. `lane-disabled` / `cfg-deny`
     2. `missing-approval` / `expired-approval`
     3. `policy-deny`
     4. `precondition-failed`
   - If more than one of those conditions is true, emit the first matching `deny_code` in that order.

3) **`precondition-failed` is reserved for actions that otherwise still had live authority to proceed**
   - Exact witness drift is meaningful only after the action still had a live lane/policy/approval path.
   - A stale reviewed basis therefore does **not** mask that the action had already lost authority, and a dead lane/policy window does **not** decay into a mere stale-basis story.

4) **This is intentionally narrow and ACP-focused**
   - The rule above does **not** attempt to define a total ordering across every possible schema/binding/ordering/resource/internal-error rejection in the archive.
   - It only closes the repeated Phase 1 ambiguity between **authority/policy windows** and **exact mutable-basis witness gates**.
   - Other deny families keep their existing producer rules unless a later RFC-first seam needs a wider precedence ladder.

5) **Non-winning reject facts are optional diagnostics, not second receipt truth**
   - Local implementations MAY log secondary losing conditions for debugging.
   - The stable CH-DENY surface, however, carries one winning `deny_code` only; Phase 1 adds no auxiliary `also_failed[]` list, denial lattice, or multi-reason bundle.

## Phase 1 non-goals (explicitly deferred)

- No total precedence ladder over every CH-DENY code in the archive.
- No new denial sidecar that records all simultaneously true failure conditions.
- No policy-consumption / single-apply authorization family under IF-ACP.
- No hidden retry oracle that infers recoverability from non-winning denial facts.

## Wiring

- Decision/control surface: `decision-map.md` (D-LLM / IF-ACP adjacency).
- Validator semantics: `docs/70-llm-control/acp-validator-semantics.md`.
- Denial vocabulary: `deny-code-registry.md`, `denial-receipt-schema-v0.md`.
- Related exact-basis seams: `acp-precondition-witness-posture-v0.md`, `approval-basis-posture-v0.md`.
- Assurance anchors: `docs/20-assurance/invariant-registry.md` (**I-DENY-6**) and `docs/20-assurance/proof-obligation-registry.md` (**PO-DENY-PRECEDENCE**).
- CI drift gate: `tools/check_acp_deny_precedence.py` (EVID-2026-557).

## References

- REF-CEDAR
- REF-RFC7807
