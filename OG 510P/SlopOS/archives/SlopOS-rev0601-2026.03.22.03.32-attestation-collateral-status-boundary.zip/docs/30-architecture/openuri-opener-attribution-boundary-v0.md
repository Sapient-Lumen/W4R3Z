# D-PLUMB OpenURI opener-attribution boundary v0 (no portable source-app / referrer channel)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: opener identity, referrer-like metadata, and caller-attribution context stay **portal/shell-owned local routing state**, not a portable requester-controlled payload or target-visible cross-app channel.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, and no new ACP or conflict-key family. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable opener identity or referrer propagation in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** let the requester attach stable portable opener metadata such as a source app id, bundle id, package name, referrer URI, caller window id, callback origin, or equivalent cross-app attribution payload.
   - The portable requester truth remains the mediated action + subject only.

2) **Portal/shell may know caller context internally, but it stays local.**
   - The portal/shell may internally know which requester, route, or parent window initiated the launch so it can apply UX, focus, abuse-control, or audit policy.
   - That local knowledge does **not** become portable target-visible semantics, a transcript-stable exported field, or a stable cross-profile contract that handlers may rely on.
   - If a backend/runtime needs local activation/focus tokens, those remain provider-owned mechanics rather than requester-visible authority.

3) **No target-visible source-app / referrer receipt in v0.**
   - Phase 1 exports **no** `source_application`, `source_app_id`, `referrer`, `caller_package`, `opener_window`, or similar target-visible OpenURI metadata contract.
   - The chosen handler must not treat OpenURI as a portable authenticated statement about which app asked for launch.
   - Requesters likewise receive no receipt showing which source-attribution metadata was conveyed, because Phase 1 conveys none as portable meaning.

4) **Why this cut is honest.**
   - Existing ecosystems do carry caller context in various ways: xdg portal backends receive `app_id` / `parent_window`; Apple exposes `UIApplication.OpenURLOptionsKey.sourceApplication`; Android activities can observe referrer-like metadata.
   - Those are real platform features, but importing them directly would widen `portal.uri.*` from mediated launch into a cross-app attribution channel.
   - SlopOS keeps opener identity policy-local unless and until there is a deliberate RFC-first reason to standardize that surface.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; shell-visible launch/focus order still serializes there.
   - Phase 1 adds **no new ACP kind** and **no new conflict-key family** for opener attribution because portable requesters do not control or observe that state directly.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient “tell the host target who launched this” behavior through helper shims, package metadata, or injected referrer fields.
   - If compat wants OpenURI, it still goes through `portal.uri.*` or fails closed.

## Phase 1 non-goals (explicitly deferred)

- No portable source-app / referrer / opener-window payload on `portal.uri.*`.
- No target-visible authenticated opener-identity contract for URI launches.
- No requester-visible receipt proving which opener metadata was conveyed.
- No ACP/admin/query surface for OpenURI attribution policy.
- No hidden compat/helper fallback that reintroduces source-app attribution out-of-band.

## Why this is worth pinning

Once OpenURI exists, another tempting convenience import is “let the target know who opened this.” Real platforms do expose pieces of that: XDG portal backends see `app_id` and `parent_window` during chooser mediation, Apple has a `sourceApplication` URL-open option, and Android activities can observe referrer metadata.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a portable cross-app attribution or referrer side channel. That matters most for the secure workstation and agent shapes, where helper/tooling ecosystems would otherwise start depending on hidden opener identity rather than explicit receipts and policy-reviewed routes.

## Profile effect (A–D)

- **Secure workstation (A):** opening a link stays a shell-owned workflow instead of leaking stable source-app identity into whichever handler wins.
- **Cloud micro-VM substrate (B):** guest/tenant tooling can request mediated launch where allowed without learning or projecting host-side opener attribution contracts.
- **Embedded / separation appliance (C):** deployments without rich desktop UX avoid carrying fake caller-attribution semantics just because some consumer OSes expose them.
- **Agent/automation OS (D):** agents/tools cannot smuggle hidden provenance about “who launched this” through OpenURI; durable meaning stays on explicit route/receipt surfaces.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/openuri-handler-selection-boundary-v0.md`
  - `docs/30-architecture/openuri-scheme-support-boundary-v0.md`
  - `docs/30-architecture/plumb-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_opener_attribution_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable source-app/referrer channel / portal-local-only caller context / no new ACP-or-conflict-key surface** posture, or drops its primary REF wiring (**EVID-2026-574**).

## References

- REF-XDG-PORTAL-APPCHOOSER.
- REF-ANDROID-ACTIVITY-REFERRER.
- REF-APPLE-OPENURL-SOURCEAPPLICATION.
