# D-ATTN companion boundary index (v0)

Purpose: keep the **closed set of D-ATTN companion boundary docs** enumerable.

Why this exists:
- the archive now pins multiple small attention-adjacent meaning seams so `portal.attn.*` does not quietly regrow into a durable interrupt/history/status control plane,
- those `attention-*-boundary-v0.md` docs are individually crisp but easy to forget piecemeal because they span interruption semantics and durable consequence truth,
- `attention-lease-posture-v0.md` keeps the overall Phase-1 meaning of D-ATTN, while this index is the **discovery surface** that says which companion boundaries currently keep CH-NOTIF ephemeral, request-local, and non-durable.

This doc does **not** add a new schema, lease, or workflow family.
It is an entropy-reducing companion to `attention-lease-posture-v0.md`, `notification-request-state-posture-v0.md`, and RFC-0055.

## Inclusion rule

A doc belongs here if it removes exactly one tempting D-ATTN meaning widening from Phase 1 by constraining one of:
- interruption semantics that would otherwise smuggle TTL / renewal / revocation / bypass-Focus / relaunch authority into CH-NOTIF urgency or delivery behavior,
- durable-outcome semantics that would otherwise let transient notifications, toasts, banners, or status cues masquerade as the sole durable carrier of approval, outcome, or next-step truth.

If future work needs a new native inbox, history, durable interrupt lease, acknowledgement ledger, or stronger delivery-status surface instead, that work must return **RFC-first** as its own decision surface rather than hiding behind CH-NOTIF convenience semantics.

## Closed companion boundary set (Phase 1)

### 1) Urgent notification hints do not become durable interrupt authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attention-durable-interrupt-boundary-v0.md`](attention-durable-interrupt-boundary-v0.md) | urgent / high-attention interrupt semantics | CH-NOTIF `importance="urgent"` stays a policy-gated hint only; delivery prominence does not become TTL / renewal / wake / bypass authority | separate RFC-first durable interrupt / lease surface if ever needed |

### 2) Transient presentation does not become durable consequence truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attention-durable-status-boundary-v0.md`](attention-durable-status-boundary-v0.md) | transient notification / toast / status presentation | transient cues may request attention, but durable consequence truth stays on explicit receipt/state surfaces rather than on presentation happenstance | explicit durable receipt / state / history surface under its own RFC if ever needed |

## Review rule

Before adding another D-ATTN companion boundary doc, answer these questions in order:
1) Is the change really an **attention meaning pin** rather than a new schema, lease, or workflow family?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported notification semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
