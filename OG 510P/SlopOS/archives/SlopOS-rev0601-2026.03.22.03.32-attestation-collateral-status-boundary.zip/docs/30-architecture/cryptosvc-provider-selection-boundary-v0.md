# D-CRYPTOSVC provider-selection boundary v0 (no portable provider / slot / token / backend-selection seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: key use does **not** become a portable provider-selection, slot/token/session selection, smartcard-reader selection, or backend-choice surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable provider / slot / token / backend-selection seam in v0**
   - Phase 1 does **not** export a portable `provider_name`, `provider_id`, `provider_class`, `backend`, `backend_id`, `ksp_name`, `csp_name`, `slot_id`, `slot_label`, `token_id`, `token_label`, `session_id`, `reader_id`, `smartcard_reader`, `key_container`, `key_store`, `alias_selector`, `choose_alias`, `prefer_secure_element`, `require_hardware_backing`, or equivalent backend-selection field on IF-CRYPTOSVC, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - A provider may internally choose software keys, smartcards, TPM-backed objects, secure elements, HSMs, or other hardware-backed implementations, but that choice remains provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret local provider/backend selection mechanics as a requester-visible result, durable receipt, or transcript-stable statement that one specific token, reader, slot, or backend was chosen by the caller.

2. **Key use stays bound to explicit key refs/routes, not backend browsing**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff, not about standardizing how callers browse providers, open storage backends, select tokens/readers, or run alias choosers.
   - If reviewed provider selection or token-management work matters, it must live on an explicit future provider-management seam with its own lifecycle, availability, UI, privacy, and evidence semantics.
   - Phase 1 therefore does **not** reinterpret CH-KEYREF `provider` metadata as a portable chooser vocabulary; it remains an authority reference / audit hook, not a backend-picking API.

3. **Provider selection is a second workflow, not generic crypto use**
   - Existing ecosystems really do expose these surfaces. PKCS #11 standardizes slot/session/object portability semantics. Microsoft CNG opens a named key storage provider before opening a key. Android KeyChain exposes alias-selection prompts for client certificates.
   - Those are valuable product workflows, but they also allocate extra token-inventory, reader-selection, backend-availability, and UI/result semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden provider chooser, token browser, or hardware-selection broker.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future provider-management / token-selection seam must state its own conflict keys, commutativity, serialization point, redaction, and evidence rules explicitly rather than inheriting folklore from PKCS#11, CNG KSP selection, or platform certificate pickers.
   - Until then, generic crypto use remains keyref/route-bound only; provider/backend/token selection stays hidden inside provider-local or deployment-local setup workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `provider_name`, `ksp_name`, `csp_name`, `slot_id`, `token_label`, `reader_id`, `alias_selector`, `prefer_secure_element`, or equivalent backend-selection knob/result on generic crypto use.
- No transcript-stable statement that crypto use also chose a specific provider backend, token slot, reader, or alias picker outcome on behalf of the caller.
- No importer-visible token/reader/provider folklore on the D-CRYPTOSVC seam.
- No shell/helper fallback that quietly promotes key use into a provider-selection workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “use the hardware token”, “pick provider X”, “open the smartcard-backed backend”, or “return the chosen certificate alias as part of signing.” Once those assumptions land in transcripts and automation, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden provider-selection or token-management plane. That matters for all four product shapes: workstation UX can still use local token/alias pickers without standardizing them as portable substrate meaning; hosted and embedded profiles avoid inheriting smartcard/backend UI or inventory contracts they do not want; and agent tooling cannot mistake CH-KEYREF/IF-CRYPTOSVC for permission to browse or steer hidden provider state.

## Profile effect (A–D)

- **Secure workstation (A):** local smartcard, platform-keystore, or certificate-picker UX may still exist, but generic crypto use does not standardize those backend-selection outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake token-reader/provider-selection contracts they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose token-management or backend-selection APIs they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to demand provider-selection, alias-picking, or backend-choice results; reviewed provider management stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_provider_selection_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable provider / slot / token / backend-selection seam / key use stays bound to explicit key refs/routes / provider selection is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-598**).

## References

- REF-PKCS11-SPEC.
- REF-MICROSOFT-NCRYPT-OPENSTORAGEPROVIDER.
- REF-ANDROID-KEYCHAIN-CHOOSEPRIVATEKEYALIAS.
