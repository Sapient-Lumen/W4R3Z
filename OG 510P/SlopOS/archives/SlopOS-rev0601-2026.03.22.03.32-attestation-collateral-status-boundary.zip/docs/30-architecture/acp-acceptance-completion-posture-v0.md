# IF-ACP acceptance/completion posture v0 (acceptance receipt ≠ downstream completion/live state)

Purpose: close one small but expensive ambiguity on the ACP outcome seam: **an accepted ACP request or CH-ACPOUT receipt is not the same thing as downstream completion truth or current provider-owned live state**.

Several of the comparison archives kept this exact split honest in review/workflow-heavy lanes: a stable accepted request record is valuable, but it must not collapse into “the task finished”, “the queue item is still current”, or “the provider still holds the same live state right now”. SlopOS should be at least that explicit on CH-ACPOUT.

This doc is intentionally narrow. It does **not** add a generic async task API, a queue/watch surface, a job-completion schema, or a reusable execution-status registry. It only freezes what CH-ACPOUT `outcome="accept"` and optional `effect` do and do not mean in Phase 1.

## Posture (v0)

1) **CH-ACPOUT `outcome="accept"` records admission of one exact request, not downstream completion truth**
   - An accept outcome means the validator/provider admitted the exact reviewed request and took the bounded accept-path action defined by that kind.
   - It is **not** by itself proof that downstream work finished, a launched target exited successfully, a queued item is still pending/current, a grant is still active, or a provider-local live state still exists now.

2) **`effect` is bounded audit metadata, not a portable execution-status plane**
   - `effect="applied"`, `"no_op"`, and `"duplicate_suppressed"` classify the bounded accept-path observation recorded at receipt time.
   - They do **not** become a portable running/completed/failed/progress vocabulary, a queue-state API, or a generic “what happened later?” monitor.

3) **Current live state and later completion stay family-local or absent unless another explicit seam pays for them**
   - For jobs, background grants, notification presentation, timeproof freshness, network/entropy handles, and similar portal-owned state, current truth remains on the provider boundary and may be completely absent from the portable Phase 1 surface.
   - For request-local workflows such as D-PLUMB / `portal.uri.*`, success still means the mediated request/launch was accepted; downstream target completion, reciprocal authority, or later external effects remain separate.
   - If a future product needs portable queued/running/completed/failed/live-state truth, it must return RFC-first with its own schema, ordering, privacy, and assurance hooks.

4) **Historical CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts do not resurrect current truth**
   - A prior receipt trail may prove that an exact request was reviewed, accepted, rejected, or duplicate-suppressed at some point.
   - It does **not** by itself prove that the same provider-owned state is still current now, that a downstream asynchronous task eventually completed, or that a launch/request remained live after later revocation, dismissal, timeout, replacement, or cleanup.

5) **Receipt references stay evidence-only**
   - When CH-ACPOUT `receipt_refs` points at CH-NETLEASE, CH-ENTROPY, CH-RECEIPT, CH-SPROJ, or other digest-referenced adjunct receipts, those digests remain immutable evidence of what was emitted on the accept/reject path.
   - They do **not** silently widen CH-ACPOUT into a generic completion bus, live-object inventory, or current-state oracle.

## Phase 1 non-goals (explicitly deferred)

- A generic ACP task/execution object, status watcher, or completion callback channel.
- A portable `running|completed|failed|cancelled|revoked` state vocabulary attached to CH-ACPOUT.
- Treating `outcome="accept"` or `effect="applied"` as proof that downstream work finished successfully.
- Treating old CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts as current provider-owned live-state truth.
- Any hidden queue/query/history API under IF-ACP that asks “did that accepted request finish later?” without a separate explicit surface.

## Why this earns its place

Without this split, the archive quietly collapses two different questions:
- **what exact request did the validator/provider admit?**
- **what current or eventual execution/live-state truth exists after that admission?**

That collapse would make receipts, retries, support tooling, and later automation less honest. Phase 1 can stay small and still refuse the ambiguity.

## Wiring

- Decision surface:
  - `decision-map.md` (IF-ACP / CH-ACPOUT)
- Receipt / validator semantics:
  - `acp-outcome-receipt-schema-v0.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/README.md`
- Adjacent workflow/request-state seams:
  - `openuri-portal-posture-v0.md`
  - `openuri-launch-completion-boundary-v0.md`
  - `job-request-state-posture-v0.md`
  - `background-request-state-posture-v0.md`
  - `notification-request-state-posture-v0.md`
  - `timeproof-request-state-posture-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (I-ACPOUT-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-ACPOUT-BOUNDARY)
- Discovery/history surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`

CI drift gate:
- `tools/check_acp_acceptance_completion_posture.py`

## References

- REF-HTTP-SEM-202.
- REF-XDG-PORTAL-OPENURI.
- REF-APPLE-OPENURL-COMPLETION.
