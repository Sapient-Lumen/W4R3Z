# D-CRYPTOSVC key-material boundary v0 (no portable secret-bearing key import/export seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable secret-bearing key import/export, blob interchange, backup/restore, or escrow workflow.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable secret-bearing key import/export seam in v0**
   - No portable `import_key`, `export_key`, `load_key`, `dump_key`, `import_pem`, `export_pem`, `import_pkcs8`, `export_pkcs8`, `import_jwk`, `export_jwk`, `import_p12`, `export_p12`, `import_blob`, `export_blob`, `backup_key`, `restore_key`, `escrow_key`, `recover_key`, `rewrap_key`, `clone_key`, `reencrypt_key_blob`, `migrate_key_blob`, `plaintext_private_key`, `private_key_blob`, `seed_blob`, `key_archive_blob`, or equivalent secret-bearing key-material knob or result on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - Providers may internally create, import, export, escrow, or migrate key objects during provisioning, enrollment, backup, or hardware/provider-local setup, but those workflows remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret provider-local key-blob handling, PEM/PKCS#8/JWK/PFX parsing, or backup/restore helpers as requester-visible result schemas, durable receipt truth, or transcript-stable statements that secret-bearing key material crossed the IF-CRYPTOSVC seam.

2. **Key use is about already-held authority, not materialization of more authority**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff plus pinned CH-KEYPOL data, not about standardizing how callers load private keys from blobs, export provider-held private keys, or shuttle reusable secret-bearing key blobs between runtimes until one backend accepts them.
   - The closed op set may still include `sign`, `decrypt`, `derive`, and `attest`, but in Phase 1 that does **not** imply a portable secret-bearing key import/export contract, a backup/restore workflow, or a generic migration/escrow plane on IF-CRYPTOSVC.
   - Public metadata already allowed by explicit schemas (for example `CH-KEYREF.pub`) stays separate from this boundary; what is pinned here is the absence of a portable **secret-bearing key material** interchange plane.

3. **Secret-bearing key-material interchange is a second workflow, not generic crypto use**
   - Existing ecosystems really do split these surfaces. WebCrypto has explicit `importKey` and `exportKey` operations. Microsoft CNG exposes `NCryptImportKey` and `NCryptExportKey` as separate blob-handling calls. Apple keychain APIs expose `SecItemImport` and `SecItemExport` as distinct item-interchange workflows. KMIP exists as a separate client/server protocol for creating, registering, getting, and destroying managed key objects.
   - Those can be useful product workflows, but they also allocate format, secrecy, provenance, backup, migration, downgrade, and escrow semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden PEM/JWK/PKCS#8 loader, a private-key export helper, or a provider-bridge blob migration broker.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future secret-bearing key import/export or lifecycle/interchange seam must state its own conflict keys, commutativity, serialization point, downgrade/fallback policy, secret-handling/redaction rules, and evidence plan explicitly rather than inheriting folklore from WebCrypto import/export, CNG key-blob handling, Apple keychain import/export, or KMIP object-management semantics.
   - Until then, generic crypto use remains keyref/route-bound only; secret-bearing key import/export, backup/restore, escrow, and provider-to-provider blob interchange stay hidden inside provider-local or deployment-local setup workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `import_key`, `export_key`, `import_pem`, `export_pkcs8`, `import_jwk`, `export_blob`, `backup_key`, `restore_key`, `escrow_key`, or equivalent secret-bearing key-material knob/result on generic crypto use.
- No transcript-stable statement that a generic crypto-use call also loaded, dumped, migrated, or escrowed one exact secret-bearing key blob for the caller.
- No provider-visible promise that one provider's private-key blob, wrapped backup object, or opaque transport blob is portable substrate truth on another provider.
- No shell/helper fallback that quietly promotes key use into a secret-bearing key import/export or backup/restore workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “just load this PEM into the signer handle”, “export the private key blob so the enclave can re-import it”, “if the HSM route is missing, fall back to PKCS#8 in userspace”, or “treat backup/restore as part of ordinary sign/decrypt authority.” Once those assumptions land in transcripts and automation, they become hard to retract and easy to misuse as secrecy, provenance, or migration loopholes. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden key-material interchange plane. That matters for all four product shapes: workstation UX can still host explicit provisioning/recovery tooling without standardizing it as substrate meaning; hosted and embedded profiles avoid inheriting blob-migration or escrow semantics they do not want; and agent tooling cannot mistake CH-KEYREF/CH-KEYPOL for permission to import or export secret-bearing keys until a future workflow pays for that entropy explicitly.

## Profile effect (A–D)

- **Secure workstation (A):** explicit provisioning, enrollment, backup, or migration helpers may still exist, but generic crypto use does not standardize private-key blob import/export as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake portable key-blob migration or escrow APIs that would become containment, provenance, and downgrade liabilities.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose private-key import/export or recovery semantics they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “use this key” with permission to load PEM/JWK/PKCS#8 material, dump provider-held private keys, or automate backup/restore across providers.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_key_material_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable secret-bearing key import/export seam / key use is about already-held authority / secret-bearing key-material interchange is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-604**).

## References

- REF-PKCS11-SPEC.
- REF-W3C-WEBCRYPTO-2.
- REF-MICROSOFT-NCRYPT-IMPORTKEY.
- REF-MICROSOFT-NCRYPT-EXPORTKEY.
- REF-APPLE-SECITEMIMPORT.
- REF-APPLE-SECITEMEXPORT.
- REF-KMIP-SPEC.
