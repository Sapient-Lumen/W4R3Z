# D-CAPX posture v0 (gateway-owned, proxy-first import; no portable caveat VM)

Purpose: pin an **implementable Phase 1** meaning for **D-CAPX** so delegated remote authority stays a
small, explicit import seam rather than drifting into direct raw-cap reconstruction, an ambient endpoint/
name resolver, or a portable caveat/policy virtual machine hidden inside the authority substrate.
It narrows RFC-0004 into one thing: **CH-CAPX is a gateway-owned import envelope that binds delegated
remote authority to a local proxy/service object under explicit policy; token semantics remain user-space
and profile-scoped rather than becoming privileged-core semantics**.
This posture is deliberately adjacent to **D-CAPRPC**, **CH-SREF**, and **D-COMMUTE**: imports may create callable remote proxies, but they do not create ambient endpoints, new sequencing semantics, or a second policy VM.

This doc is intentionally narrow: it does **not** standardize distributed GC, a global endpoint namespace,
a portable authorization-logic evaluator for bearer tokens, or a generic app-visible delegation inventory.

## Posture (v0)

1) **CH-CAPX is an explicit import envelope, not an ambient naming hint**
   - Authority appears only when a caller explicitly presents **CH-CAPX v0** bytes to an import path (gateway / introducer / restore service).
   - Parsing, copying, syncing, or displaying CH-CAPX bytes does **not** auto-import authority.
   - Phase 1 therefore treats CH-CAPX as a sharp handoff event, not as a path/env/service-name shorthand for “find the remote thing”.
   - If imported authority later needs routine document workflows, the bridge is pinned separately: the system must first materialize a **fresh local object** and mint a provider-local CH-DOCREF rather than handing apps a hidden bearer-backed docref shim (`import-to-docref-boundary-v0.md`).
   - Companion fresh-identity boundary: that bridge remains **fresh-object-identity-first** even when the same bytes already exist locally; no `reuse_existing` / content-equality alias return of an old docref (`import-to-docref-fresh-identity-boundary-v0.md`).
   - Companion bearer-provenance boundary: the imported fresh local object may record one exact **`origin.import_ref_digest`** for the accepted CH-CAPX handoff, but routine object metadata never carries raw capability URLs or hidden refresh semantics (`import-to-docref-bearer-provenance-boundary-v0.md`).
   - Companion boundary index: `import-to-docref-boundary-index.md` keeps the current `import-to-docref-*-boundary-v0.md` bridge family enumerable so bearer→document semantics do not silently widen by omission.

2) **Gateway-owned, proxy-first binding only**
   - An accepted CH-CAPX object binds delegated authority to a locally minted **`proxy`** or **`service`** object, not to a raw kernel/user capability identifier.
   - Remote use always traverses an explicit gateway/runtime mediation point that can enforce local policy, logging, and teardown.
   - This keeps imported authority on the user-space membrane side of the substrate instead of pretending networked delegation is the same thing as resurrecting a local kernel cap.

3) **No portable caveat VM or token-policy calculus in the core seam**
   - The privileged/core seam validates canonical bytes, a closed `token_kind` allowlist, and the explicit local binding; it does **not** standardize a portable macaroon/biscuit/captp caveat evaluator.
   - `caveats`, `issuer`, `exp`, `nonce`, and `meta` remain profile- or gateway-specific unless a separate reviewed seam explicitly narrows them further.
   - Phase 1 therefore keeps token semantics user-space and profile-scoped rather than importing a hidden authorization DSL into D-CAPX itself.

4) **Explicit route only; no ambient network or service-name fallback**
   - Import requires an explicit gateway / introducer / restore route plus any separately granted network authority under **D-NETLEASE**.
   - CH-CAPX bytes do **not** imply ambient DNS, socket, service-name, or background rendezvous authority.
   - This is the concrete routing-level reading of **I-CAPX-1** and keeps sealed compat honest.

5) **Off-by-default and profile-gated in Phase 1**
   - `ext.capx_remote_delegation` remains **off by default** unless a profile explicitly enables it.
   - Enabling D-CAPX is a deployment/product claim, not a convenience toggle implied by a library parser or RPC runtime.
   - This keeps remote delegation reviewable alongside the rest of the archive’s sharp seams.

6) **Routine workflow/observation surfaces carry digests, not raw CH-CAPX bytes**
   - Ordinary receipts/logs/wallet/plumbing/observation artifacts carry **`digest(CH-CAPX v0)`** for correlation when needed, not raw imported bearer material.
   - If a workflow needs to move raw CH-CAPX bytes, that transfer must be explicit, higher-risk, and separately justified.
   - Admitted **CH-NAMECERT v0** bundles are not such a workflow: they must not embed raw CH-CAPX bytes or become a hidden capability-import side channel (`namecert-bearer-boundary-v0.md`).
   - Phase 1 therefore keeps routine UX and observation surfaces from quietly becoming a delegation side channel.

7) **No app-visible token inventory, probing, or generic share bus**
   - Phase 1 exposes **no app-visible list/search/watch API** over imported CH-CAPX tokens or live delegated-authority rows.
   - There is no portable “show me all imported remote caps”, “probe whether this token resolves”, or generic background sync/share substrate for CH-CAPX.
   - If we later need inventory, federation, or rich delegation UX, that is evidence for a different reviewed seam rather than a silent widening of D-CAPX.

8) **External action semantics stay on the imported provider/proxy, not on CH-CAPX itself**
   - Import is an explicit handoff event; later externally visible actions keep the conflict keys, commutativity stance, serialization boundary, and ordering evidence of the imported provider/proxy surface.
   - CH-CAPX does **not** mint a new global sequencing service, queue-order authority, or workflow control plane.
   - This keeps Hybrid + commutativity honest: delegated authority changes *who may call*, not the semantics of what the target action means.

9) **No new workflow / ACP / admin surface on D-CAPX tokens**
   - Phase 1 introduces no portal family, no **CH-ACP** kind, and no generic admin protocol for listing, migrating, force-refreshing, or mass-revoking imported CH-CAPX tokens.
   - Any future delegation-management surface must pay its own schema, commutativity, and evidence cost explicitly.
   - This keeps D-CAPX from quietly becoming a hidden connection manager, token wallet, or authorization workbench.

10) **Sealed compat remains killable and non-ambient**
   - Foreign Cells may adapt guest delegation/token formats only through explicit, policy-killable membrane surfaces.
   - They must not recreate ambient endpoint lookup, background token refresh daemons, or path/env-based authority import that bypasses declared CH-CAPX handling.
   - Any compat enablement remains subordinate to sealed-compat policy and must fail closed when disabled.

## Phase 1 non-goals (explicitly deferred)

- **No direct binding from CH-CAPX to a raw local kernel/user capability id**.
- **No portable macaroon/biscuit/captp caveat evaluator in the privileged/core seam**.
- **No ambient resolver via env/path/global service names**.
- **No app-visible token inventory/search/watch/probing API**.
- **No new workflow / ACP / admin surface for delegation lifecycle management**.

## Wiring

- Decision surface:
  - `decision-map.md` (D-CAPX)
- Schemas / registries:
  - `capability-export-schema-v0.md` (CH-CAPX v0)
  - `schema-registry.md`
  - `sturdyref-schema-v0.md` (contrast: explicit restore-only bearer refs)
- Adjacent runtime surfaces:
  - `mechanisms.md`
  - `rfcs/0004-networked-capabilities-and-delegation-tokens.md`
  - `rfcs/0026-object-capability-rpc-profile.md`
  - `caprpc-session-posture-v0.md`
  - `caprpc-proxy-replication-boundary-v0.md`
  - `sturdyref-posture-v0.md`
  - `namecert-bearer-boundary-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-CAPX-1**, **I-CAPX-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-CAPX-BIND**, **PO-CAPX-ATTEN**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-012**)
- Related posture/history surfaces:
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/llm-runbook.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future external delegation-management surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_capx_posture.py` fails `make lint` if this posture stops being discoverable, loses its **proxy-first / explicit import / off-by-default / no portable caveat-VM / digest-only routine surfaces** constraints, or drops its primary REF wiring.

## References

- REF-CAPTP.
- REF-OCAPN.
- REF-MACAROONS-NDSS14.
- REF-BISCUIT-SPEC.
