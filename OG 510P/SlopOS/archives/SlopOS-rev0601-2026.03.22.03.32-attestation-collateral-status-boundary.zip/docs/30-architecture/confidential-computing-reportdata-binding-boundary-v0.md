# D-CC reportdata-binding boundary v0 (one exact binder contract; no “canonical equivalent” drift)

Purpose: pin the **exact Phase 1 bytes** that a confidential-computing attestation binder places into a provider-native `REPORT_DATA` / `REPORTDATA` / challenge/user-data field, so implementation can start without the archive drifting between near-equivalent hashes, field subsets, or provider-by-provider ad hoc framing.

This boundary is intentionally narrow:
- it introduces **no new CH-* schema**,
- it keeps the portable surface at **CH-ATTEST v0** / **CH-ATTESTPACK v0**,
- and it only fixes the **binder/verifier-local byte contract** that connects those artifacts to provider-native CC evidence.

## Boundary (v0)

1) **One exact preimage is used for the CC binder digest**
   - The Phase 1 binder MUST build the exact byte string `ccbind_input_v0` as:

```text
ccbind_input_v0 :=
  "slopos.cc.bind.v0\0"                       # ASCII domain tag including trailing NUL
  || boot_digest_raw_32                         # exact CH-ATTEST.boot_digest bytes
  || prov_digest_or_zero_32                     # CH-ATTEST.prov_digest if present, else 32 zero bytes
  || policy_revision_u64be                      # exact CH-ATTEST.policy_revision as unsigned 64-bit big-endian
  || freshness_kind_u8                          # 0 = none, 1 = nonce, 2 = challenge
  || nonce_len_u8                               # 0..64 inclusive
  || nonce_bytes                                # exact CH-ATTEST.freshness.nonce bytes; empty iff nonce_len_u8 == 0
```

   - If `freshness_kind_u8 == 0`, then `nonce_len_u8` MUST be `0` and `nonce_bytes` MUST be empty.
   - `boot_digest_raw_32`, `prov_digest_or_zero_32`, and `policy_revision_u64be` are **raw canonical field bytes**, not hex/base64/text renderings.
   - The binder/verifier digest is then:

```text
ccbind_digest_v0 := digest(ccbind_input_v0)
```

   - Under the current pinned **D-HASH** profile, `digest(..)` means **SHA-256** over the exact bytes above.

2) **One exact 64-byte provider input is used for SNP-first and TDX annexes**
   - When the provider-native field is exactly **64 bytes** wide, the binder MUST pass:

```text
cc_report_data_v0 := ccbind_digest_v0 || zero32
```

   where `zero32` is exactly 32 zero bytes.

   - Phase 1 therefore reserves the high half of the 64-byte provider input and keeps the effective binding meaning in the low 32 bytes only.
   - Verifiers MUST recompute the exact 64 bytes and reject if either:
     - the low 32 bytes do not equal `digest(ccbind_input_v0)`, or
     - the high 32 bytes are not all zero.

3) **SNP-first uses this exact 64-byte contract, not an implementation-local variant**
   - For the first concrete **AMD SEV-SNP** binder/verifier target, the guest-provided `REPORT_DATA` field receives exactly `cc_report_data_v0`.
   - The verifier checks the provider-native report’s `REPORT_DATA` field against the same exact 64-byte value.
   - Phase 1 therefore declines alternate SNP-specific encodings such as `digest(boot_digest || nonce)` one place and `digest(boot_digest || policy_revision || nonce)` elsewhere.

4) **Future TDX uses the same 64-byte contract unless and until an explicit annex says otherwise**
   - Any future **Intel TDX** annex MUST treat `TDREPORT.REPORTDATA` the same way in Phase 1-compatible flows: exact `cc_report_data_v0`, same low-half digest, same zero-filled high half.
   - This keeps the first two 64-byte provider families aligned behind one verifier recomputation rule instead of creating per-provider “almost the same” binder code.

5) **Providers with a non-64-byte challenge/user-data field do not get a silent “canonical equivalent” escape hatch**
   - If a future provider (for example a CCA deployment profile) offers a field that is not exactly 64 bytes, that provider MUST land an explicit annex that says how it carries `ccbind_digest_v0`.
   - Phase 1 does **not** admit prose like “or canonical equivalent” as a substitute for exact bytes.
   - The burden is on the annex to map from the already-pinned `ccbind_digest_v0`, not to invent a second binder-preimage contract.

6) **No new portable schema or provider-native control plane appears**
   - `ccbind_input_v0`, `ccbind_digest_v0`, and `cc_report_data_v0` are **local binder/verifier computations**, not new CH-* artifacts.
   - This boundary adds no provider-native quote broker, challenge service, secret broker, or metadata fetch plane.
   - All export meaning still rides on **CH-ATTEST v0** / **CH-ATTESTPACK v0** and the already-pinned verifier-local appraisal rules.

## Why this boundary exists

The archive had already made the right strategic decision — **bind provider-native CC evidence to our own boot/provenance state** — but the wording still allowed drift in the one place implementation cannot afford it:
- `H(boot_digest || nonce)` in one paragraph,
- `H(boot_digest || policy_rev || nonce)` in another,
- and “or canonical equivalent” as an accidental invitation to fork the binder.

That is expensive because it creates mismatched verifier harnesses, replay bugs, and cross-provider folklore right where the first D-CC code path needs the smallest possible contract.

This boundary spends one small entropy token to collapse that ambiguity:
- **one preimage**,
- **one digest**,
- **one 64-byte report-data contract**,
- **zero provider-specific wiggle room unless a later annex pays for it explicitly**.

## Imported ecosystem pattern

- **AMD SEV-SNP firmware ABI** contributes the first concrete 64-byte guest-provided `REPORT_DATA` carrier and confirms that the firmware does not interpret those bytes.
- **Intel TDX guest attestation** contributes the matching 64-byte `REPORTDATA` carrier, which makes one shared binder contract practical across the first two major CC families.
- The archive deliberately **does not** import provider-native policy services or quote-broker semantics from either ecosystem; only the exact carrier-size fact is imported here.

## Consequences

- The first SNP binder/verifier harness can be implemented against one exact recomputation rule.
- Future TDX work can reuse that rule instead of redesigning the binder.
- Any future provider with a different carrier width must pay an explicit annex cost instead of weakening Phase 1 into “close enough.”
- `CH-ATTEST` remains the portable summary artifact; this boundary only fixes how provider-native CC evidence binds to it.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** for confidential-computing binding semantics.

If a second closely related D-CC binding-boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces: `decision-map.md` (**D-CC**, **D-ATTEST**, **D-HASH**).
- Adjacent posture/spec docs:
  - `confidential-computing-reference-target-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-token-schema-v0.md`
  - `attestation-pack-schema-v0.md`
  - `profile-hash-suite-v0.md`
  - `typed-id-contract-v0.md`
- Threat / assurance anchors:
  - `docs/10-threat-model/abuse-cases.md` (**AC-053**)
  - `docs/20-assurance/invariant-registry.md` (**I-ATTEST-1**, **I-ENC-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**)
- Mechanism / proposal notes:
  - `rfcs/0064-confidential-computing-profile.md`
- CI drift gate:
  - `tools/check_confidential_computing_reportdata_binding_boundary.py` (**EVID-2026-535**)

## References

- REF-AMD-SNP-FWABI.
- REF-LINUX-TDX.
- REF-RATS-RFC9334.
