# CH-ENTREQ v0: entropy handle/lease request (optional; D-NONDET)

Purpose: a **bounded, normalized request descriptor** for obtaining an explicit entropy handle/lease from the entropy portal.

CH-ENTREQ is a stable, digestable input for **LLM-proposed / validator-executed** entropy issuance:
- ACP proposals bind `entreq_digest = digest(CH-ENTREQ v0)`.
- Validators verify the request shape (fail closed) and invoke the portal using explicit capabilities.
- The portal returns a **CH-ENTROPY v0** descriptor (bounds receipt) plus an opaque entropy authority handle.

This schema is **not** authority and MUST NOT contain bearer capability material or secret entropy bytes.

Related:
- `entropy-descriptor-schema-v0.md` (CH-ENTROPY v0)
- D-NONDET: `docs/30-architecture/decision-map.md`
- Portal family: `docs/30-architecture/portal-family-registry.md` (`portal.entropy`)

References: REF-OPENBSD-GETENTROPY, REF-LINUX-GETRANDOM.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-ENTREQ-v0 {
  schema: "CH-ENTREQ";
  version: 0;

  # Request identity (for dedupe/replay correlation).
  # Validators/portals MAY treat stable req_id as an upsert key.
  req_id: bytes16;             # random (>=128 bits)

  # Request class (v0 seed).
  kind: enum { seed, stream, deterministic };

  # Quality requested (portal may clamp or deny by policy).
  # IMPORTANT: "deterministic" quality MUST NOT satisfy any cryptographic-randomness precondition.
  quality: enum { csprng_seed, csprng_stream, deterministic };

  # Optional bounds (veto-only hints; the portal may clamp or deny).
  bounds?: {
    ttl_s?: u32;               # requested TTL cap for the handle/lease; portal clamps
    max_bytes_per_call?: u32;  # requested cap; portal clamps
    max_total_bytes?: u64;     # requested cap; portal clamps
    deadline_mono?: u64;       # optional monotonic deadline (units profile-defined; veto-only)
  };

  # Optional non-authoritative purpose label (bounded).
  purpose?: string;            # ≤ 96 bytes (e.g., "seed_domain_rng", "test_replay")

  # Optional export posture hint.
  sensitive?: bool;            # if true, exports are redacted/blocked by CH-OBSPOL profiles
}
```

## Validation rules (summary)
A CH-ENTREQ validator MUST be total and fail closed:
1) `schema == "CH-ENTREQ"` and `version == 0`.
2) `req_id` is exactly 16 bytes.
3) `kind` and `quality` are allowlisted closed enums.
4) If `kind == deterministic`, then `quality == deterministic`.
5) If `quality == deterministic`, policies MUST forbid treating the resulting handle as satisfying any “cryptographic randomness required” precondition (I-NONDET-3).
6) If `bounds` is present, each numeric field is bounded/clamped by profile; `deadline_mono` is interpreted as a **veto-only** hint.
7) `purpose` length ≤ 96 bytes.

## Security posture
- CH-ENTREQ is **non-authoritative**. It records a request shape for mediation and audit; it never grants entropy authority.
- Entropy bytes are never carried in CH-ENTREQ or CH-ENTROPY descriptors; the handle is the capability.
- Deterministic entropy is explicit and must remain mechanically distinguishable from crypto-quality entropy (I-NONDET-3).

ACP integration (optional):
- Entropy requests SHOULD be mediated via ACP kind `portal.entropy.request`, binding `entreq_digest = digest(CH-ENTREQ v0)` and enforcing lane gate `cfg.params.lane.portal.entropy` fail-closed (PO-ACP-ENTROPY-REQUEST; PO-LANE-KILL).
- For retry safety, portals SHOULD dedupe by `req_id` when the kind claims **at-least-once-safe** and SHOULD make duplicate suppression transcript-visible (D-RETRYSAFE).
- `req_id` is a requester-chosen stable request/dedupe key only; it is NOT a portal-issued CH-ENTROPY handle, provider-session identifier, or proof that a current entropy handle still exists (`entropy-request-state-posture-v0.md`; I-ENTREQ-1).
