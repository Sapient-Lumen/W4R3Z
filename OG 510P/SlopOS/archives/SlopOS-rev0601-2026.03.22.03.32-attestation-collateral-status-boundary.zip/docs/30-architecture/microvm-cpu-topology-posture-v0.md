# MicroVM CPU-topology posture v0 (static guest-visible vCPU shape; no portable resize plane)

Purpose: pin the **Phase 1** meaning of guest-visible CPU topology under `ext.microvm` so vCPU hotplug, CPU online/offline control, and max-vCPU slot semantics do not quietly become an ambient host↔guest control/status plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-NONDET** and makes one hard decision explicit:
**Phase 1 fixes guest-visible vCPU count/topology at admission; `ext.microvm` adds no portable vCPU hotplug / CPU online-offline / hotpluggable-slot / resize-status plane, and changing guest-visible CPU count/topology or SMT means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity.**

Entropy cost justification: the archive already pins `ext.microvm` to a declared device set, forbids ambient host channels, fixes guest-visible RAM at admission, and sharply bounds warm-start lineage/admission semantics. What remains underspecified is whether dynamic guest CPU sizing/topology is part of the reviewed product surface. One narrow posture closes that gap without inventing a new schema family, CPU-slot inventory, or hidden host control plane.

## Posture (v0)

1) **Guest-visible CPU topology is fixed at admission**
   - For Phase 1, each admitted `ext.microvm` leaf runs with **one exact guest-visible vCPU count/topology** fixed at admission.
   - Portable semantics do **not** include post-admission guest-visible CPU resizing, hot-add/hot-remove, or topology mutation under the same reviewed portable identity.
   - In plain terms: the reviewed contract is “this leaf boots with this guest-visible CPU shape”, not “the host may later negotiate a new target vCPU count while the same leaf keeps running”.

2) **No portable vCPU hotplug / online-offline / resize-status plane**
   - Phase 1 standardizes **no portable vCPU hotplug / CPU online-offline / hotpluggable-slot control/status plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible fields or APIs such as **maximum potential vCPU count**, **boot-vCPU vs max-vCPU split**, **hotpluggable CPU slots**, **present/possible/online/offline CPU state**, **host-driven resize commands**, or **guest-visible CPU-resize completion status**.
   - Implementations may internally support such mechanisms, but they are **not** part of the Phase 1 product contract and must not silently become guest-visible reviewed meaning.

3) **Host scheduler placement/affinity policy stays owner-local and must not masquerade as a portable API**
   - Owners/runtimes may still use ordinary host-side placement, pCPU affinity, overcommit, or scheduling policy locally.
   - What they may **not** do in Phase 1 is turn that owner-local policy into a portable guest-visible CPU resize/topology contract for an already admitted leaf.
   - If a deployment cannot honor the fixed guest-visible CPU topology it admitted, the correct Phase 1 outcomes are to admit a different reviewed leaf/activation or fail closed — not to grow a new portable in-place vCPU-resize meaning by convention.

4) **Changing guest-visible CPU topology is a new admission, not an in-place mutation**
   - If policy wants a different guest-visible vCPU count/topology or SMT stance, that change is modeled as a **new reviewed admission / activation choice**.
   - It is **not** modeled as mutating a running guest under the same admitted leaf identity.
   - This keeps CPU sizing/topology aligned with the already-pinned lineage/resume-class story instead of creating a second hidden lifecycle/control surface inside `ext.microvm`.

5) **No new CPU-resize plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for CPU-resize state, **no new ACP kind**, and **no new conflict-key family** for hotplug/online-offline operations.
   - If a later design wants portable CPU hot-add/hot-remove semantics, guest-visible CPU-slot inventory, or explicit online/offline workflows, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable vCPU hotplug or CPU online/offline semantics for `ext.microvm`.
- No portable guest-visible max-vCPU / hotpluggable-slot inventory API.
- No promise that host-side placement or scheduler policy is forbidden; only that it does **not** become a reviewed guest-visible CPU-resize/control plane in Phase 1.
- No in-place “same leaf, different vCPU count/topology now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-NONDET)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `rseq-posture-v0.md`
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-nested-virt-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-14)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-CPUTOPOLOGY)
- Policy posture:
  - guest-visible CPU resizing adds **no new lane**, **no public resize/status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_cpu_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fixed-at-admission guest-visible CPU topology / no portable vCPU-hotplug-or-online-offline control plane / no max-vCPU-or-slot semantics / change CPU topology by new admission not in-place mutation / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-MACHINE-CONFIG.
- REF-CHYP-HOTPLUG.
- REF-QEMU-CPU-HOTPLUG.
