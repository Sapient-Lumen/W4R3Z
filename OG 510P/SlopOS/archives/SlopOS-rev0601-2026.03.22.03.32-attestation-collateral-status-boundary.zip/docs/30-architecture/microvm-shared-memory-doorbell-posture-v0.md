# MicroVM shared-memory / doorbell posture v0 (no portable ambient guest-visible shared-memory peer-channel contract)

Purpose: pin the **Phase 1** meaning of guest-visible shared-memory and peer-notify virtualization under `ext.microvm` so ivshmem-style BARs, peer doorbells, and host-distributed shared-memory file descriptors do not quietly become a reviewed host↔guest or guest↔guest channel plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-IOBUF**, **D-PLUMB**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible shared-memory / doorbell device contract under `ext.microvm`; there is no portable `ivshmem-plain` / `ivshmem-doorbell` / `ivshmem-flat` / peer-id / shared-memory-region / interrupt-doorbell plane, owner-local shared-memory server/file-descriptor/eventfd distribution stays implementation-local, and cross-domain shared-memory meaning still rides on explicit D-IOBUF / D-PLUMB seams rather than ambient guest BARs or peer-notify devices.**

Entropy cost justification: the archive already forbids ambient vsock and shared-folder channels, keeps backend offload implementation-local, and pins explicit shared-region semantics under D-IOBUF. What remained underspecified was the guest-visible shared-memory fast path where real VMMs can map one shared region straight into the guest and let peers/hosts ring doorbells across that mapping. One narrow posture closes that gap without inventing a shared-memory broker, peer-discovery service, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible shared-memory / doorbell device contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible shared-memory / doorbell device contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard shared-memory BAR, one stable peer-id vocabulary, or one blessed interrupt-doorbell protocol for talking to the host or sibling guests.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable guest-visible shared-memory channel exists for fast host/peer coordination.”

2) **No portable `ivshmem-plain` / `ivshmem-doorbell` / `ivshmem-flat` / peer-id / shared-memory-region / interrupt-doorbell plane**
   - Phase 1 standardizes **no portable `ivshmem-plain` / `ivshmem-doorbell` / `ivshmem-flat` / peer-id / shared-memory-region / interrupt-doorbell plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about one mapped shared-memory region, peer enumeration, peer-id assignment, doorbell register layout, interrupt-vector ownership, or “this memory window is the reviewed way to exchange bytes with the host or another guest.”
   - Implementations may locally expose an inter-VM shared-memory device, one or more shared regions, peer interrupts, or no such device at all for one deployment class, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local shared-memory server / FD / eventfd distribution stays implementation-local**
   - Owner-local shared-memory server / FD / eventfd distribution stays implementation-local.
   - Runtimes may choose host memfd-backed regions, ivshmem servers, direct file-descriptor passing, eventfd-based peer notification, or deployment-local peer coordination services, but that does **not** create a portable reviewed promise about one server protocol, one peer-discovery API, one file-descriptor distribution path, or one interrupt-delivery contract.
   - In particular, host socket paths, memfd names, eventfd routing, peer ordering, and recovery/rebind details remain host/runtime-local mechanism, not portable SlopOS interface meaning.

4) **Cross-domain shared-memory meaning stays on explicit D-IOBUF / D-PLUMB seams**
   - Cross-domain shared-memory meaning stays on explicit D-IOBUF / D-PLUMB seams.
   - If two parties need reviewed shared bytes, those bytes still ride on explicit shared-region / transfer / portal workflows where participants, rights, and lifecycle are named.
   - A guest-visible shared-memory device may help one implementation move bytes quickly, but it does **not** become the portable authority seam for shared-region identity, peer discovery, or cross-domain signaling meaning.

5) **Changing the shared-memory / doorbell stance is owner-local lifecycle or new admission, not a portable live control plane**
   - Changing the shared-memory / doorbell stance is owner-local lifecycle or new admission, not a portable live control plane.
   - Owners/runtimes may choose different local shared-memory topologies for different reviewed leaves or deployment classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable shared-memory attach, peer-enumeration, or doorbell-admin protocol under the same admitted identity.
   - If policy cares about a different guest-visible shared-memory stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden host↔guest or guest↔guest channel contract by convention.

6) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for shared-memory/doorbell state, **no new ACP kind**, and **no new conflict-key family** for peer attach, doorbell ring, shared-region export, or interrupt-route mutation under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `attach_peer_shm`, `enumerate_peers`, `ring_peer_doorbell`, `map_shared_region`, or `rebind_interrupt_route`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that microVM guests always see one standard shared-memory BAR or peer-notify device.
- No portable `ivshmem-plain` / `ivshmem-doorbell` / `ivshmem-flat` / peer-id / interrupt-doorbell contract under `ext.microvm`.
- No ambient host↔guest or guest↔guest communication authority through guest-visible shared-memory devices.
- No generic shared-memory broker, peer-discovery daemon, or guest doorbell-control agent API.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-IOBUF, D-PLUMB, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
- Adjacent notes:
  - `rfcs/0084-copyless-buffer-objects-and-shared-regions.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-30)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-SHMCHANNEL)
- Policy posture:
  - shared-memory virtualization adds **no new lane**, **no public peer-discovery/admin plane**, and **no portable in-place shared-memory attach or doorbell protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_shared_memory_doorbell_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible shared-memory-doorbell contract / no portable `ivshmem-plain`-`ivshmem-doorbell`-`ivshmem-flat`-peer-id-shared-memory-region-interrupt-doorbell plane / owner-local shared-memory server-FD-eventfd distribution stays implementation-local / cross-domain shared-memory meaning stays on explicit D-IOBUF and D-PLUMB seams / changing shared-memory-doorbell stance is owner-local lifecycle or new admission not a portable live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-IVSHMEM-SPEC.
- REF-QEMU-IVSHMEM-FLAT.
- REF-XEN-GRANTTABLE.
