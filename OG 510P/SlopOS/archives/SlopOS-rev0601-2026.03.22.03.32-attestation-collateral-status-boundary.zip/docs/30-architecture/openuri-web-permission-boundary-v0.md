# D-PLUMB OpenURI web-permission boundary v0 (no portable web-permission / powerful-feature prompt seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable browser/web permission broker, powerful-feature prompt surface, or equivalent downstream site-permission control plane on `portal.uri.*`.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1. **No portable web-permission / powerful-feature prompt seam in v0**
   - Phase 1 does **not** export a portable `permission_name`, `permission_state`, `permission_query`, `request_permission`, `permission_prompt`, `permission_lifetime`, `remember_permission`, `grant_geolocation`, `grant_camera`, `grant_microphone`, `grant_notifications`, `geolocation_permission`, `camera_permission`, `microphone_permission`, `notification_permission`, `clipboard_permission`, `midi_permission`, or equivalent downstream site-permission field on `portal.uri.*`.
   - A shell, browser, user agent, or chosen handler may still prompt for geolocation, camera, microphone, notifications, clipboard, or other powerful-feature permissions locally, but those prompts, remembered grants, and resulting states remain request-local or provider-local rather than portable portal truth.
   - Phase 1 does **not** reinterpret local browser permission mechanics as a requester-visible result, durable receipt, or transcript-stable statement that launch also queried permission state, granted a powerful feature, or completed a permission prompt workflow.

2. **Powerful-feature permissions stay on explicit authority seams**
   - Generic OpenURI is about *admission of a mediated launch*, not about standardizing downstream browser permission state, prompt outcomes, or remembered grants for location, media capture, notifications, clipboard, or other powerful features.
   - SlopOS already keeps high-risk local authorities explicit elsewhere: device/location access remains on reviewed seams such as D-LOCLEASE and D-CAPTURE, while any future browser/web permission broker must return on an explicit future seam with its own authority, UX, privacy, commutativity, and evidence semantics.
   - Phase 1 therefore does **not** reinterpret generic launch as authority to auto-allow, deny, preflight-query, or depend on browser permission state on the requester’s behalf.

3. **Permission prompting is a second workflow, not generic launch**
   - Existing ecosystems really do expose these surfaces. The W3C Permissions specification defines common infrastructure for querying and tracking permission state for powerful features. The Geolocation specification normatively relies on permission checks before sharing location. Media Capture and Streams defines APIs for requesting access to camera and microphone devices. Notifications integrates explicit permission handling for showing notifications outside the browsing context.
   - Those are valuable product workflows, but they allocate extra consent state, prompt timing, remembered-grant policy, origin scoping, and result-handling semantics that are not harmless synonyms for “open this URI”.
   - Pinning the boundary now keeps `portal.uri.*` from quietly widening into a hidden browser permission broker.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future reviewed browser/web permission seam must state its own conflict keys, commutativity, prompt-serialization rules, privacy redaction, and evidence hooks explicitly rather than inheriting folklore from browser permission UX.
   - Until then, generic `open_uri` remains admission-scoped only; permission prompting and permission-state truth stay hidden inside provider-local browser/runtime workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `permission_name`, `permission_state`, `permission_query`, `request_permission`, `permission_prompt`, `permission_lifetime`, `remember_permission`, `grant_geolocation`, `grant_camera`, `grant_microphone`, `grant_notifications`, `geolocation_permission`, `camera_permission`, `microphone_permission`, `notification_permission`, `clipboard_permission`, or equivalent web-permission knob/result on generic OpenURI.
- No transcript-stable statement that launch also queried, granted, denied, or remembered browser permission state for a downstream site/origin.
- No importer-visible browser permission folklore on the D-PLUMB seam.
- No shell/helper fallback that quietly promotes `open_uri` into a browser permission workflow and reports that second workflow as generic OpenURI truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, agents and wrappers quickly start depending on guessed semantics like “open this site and pre-grant geolocation,” “launch this page and tell me whether notifications are already allowed,” or “open the URI and return the camera/mic permission outcome as part of launch.” Once those assumptions land in transcripts, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning mediated launch into hidden browser permission authority. That matters for all four product shapes: workstation UX can still use local browser permission prompts without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting a fake browser-permission contract they do not want; and agent tooling cannot mistake `open_uri` for permission to auto-grant or depend on hidden browser permission truth.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still prompt for geolocation, camera, microphone, notifications, and similar powerful features locally, but generic OpenURI does not standardize those outcomes as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting ambient browser-permission or remembered-origin-grant contracts they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising general-purpose browser permission brokers they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with permission to demand `permission_state`, `grant_geolocation`, `grant_camera`, or `grant_notifications` results; reviewed permission mediation stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/intent-kind-registry.md`
- `docs/30-architecture/effect-contract-schema-v0.md`
- `docs/60-engineering/cli-plumbing-tooling.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_openuri_web_permission_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable web-permission / powerful-feature prompt seam / permissions stay on explicit authority seams / permission prompting is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-595**).

## References

- REF-W3C-PERMISSIONS.
- REF-W3C-GEOLOCATION.
- REF-W3C-MEDIACAPTURE-STREAMS.
- REF-W3C-NOTIFICATIONS.
