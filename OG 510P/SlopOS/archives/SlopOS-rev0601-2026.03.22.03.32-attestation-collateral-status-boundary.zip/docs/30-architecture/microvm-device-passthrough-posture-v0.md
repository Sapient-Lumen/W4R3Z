# MicroVM device-passthrough posture v0 (no portable ambient guest VFIO/passthrough contract)

Purpose: pin the **Phase 1** meaning of guest-visible device passthrough under `ext.microvm` so VFIO, mediated devices, SR-IOV, and host-specific PCI attachment folklore do not quietly become an ambient DMA-class authority plane.

This doc attaches to **D-MICROVM**, **D-DMA**, **D-IOLEASE**, **D-DEVGUARD**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible device-passthrough contract under `ext.microvm`; there is no portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane, owner-local host binding and attachment details stay implementation-local, and DMA-class device authority still rides on explicit D-DMA / D-IOLEASE / `portal.device.*` seams rather than ambient guest passthrough devices.**

Entropy cost justification: the archive already keeps DMA-class devices manual, policy-visible, and deny-by-default through D-IOLEASE / D-DMA, and the microVM profile already refuses broad PCI compatibility drift. What remains underspecified is the tempting virtualization shortcut where a guest-visible VFIO-assigned GPU/NIC/NVMe/crypto device quietly becomes “real” reviewed meaning because a host/runtime can wire one up. One narrow posture closes that gap without inventing a new schema family, passthrough-manager API, or hidden guest agent.

## Posture (v0)

1) **No portable ambient guest-visible device-passthrough contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible device-passthrough contract.
   - Portable reviewed meaning therefore does **not** include “this guest can rely on one directly assigned physical or mediated device because the runtime supports passthrough.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one stable passthrough-device ABI exists with known DMA, reset, interrupt, or topology semantics.”

2) **No portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane**
   - Phase 1 standardizes **no portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about exact PCI identities, host sysfs paths, IOMMU-group composition, SR-IOV virtual-function numbering, mediated-device type selection, BAR aperture layout, FLR/reset behavior, MSI/MSI-X wiring, or guest-observable attach-status APIs.
   - Implementations may internally expose, mask, or avoid such mechanisms locally, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local host binding and attachment details stay implementation-local**
   - Owner-local host binding and attachment details stay implementation-local.
   - Runtimes may locally bind devices to VFIO/iommufd, select host sysfs paths, require whole IOMMU groups, choose mediated-device profiles, or avoid passthrough entirely for one deployment class, but that does **not** create a portable reviewed promise about one guest-visible PCI topology, one reset model, one interrupt model, or one runtime status/control API.
   - The already-pinned resume-class and admission-local provenance rules remain authoritative if such owner-local choices exist; host-specific passthrough plumbing does not become a portable leaf identity or restore contract by itself.

4) **D-DMA and D-IOLEASE remain authoritative for DMA-class device authority meaning**
   - D-DMA and D-IOLEASE remain authoritative for DMA-class device authority meaning.
   - If DMA-class device access is admitted at all, the policy meaning still rides on explicit `portal.device.*` / `CH-IOLEASE` / D-DMA seams rather than ambient guest device enumeration or in-guest driver success.
   - Guest-visible passthrough devices must not displace the already-pinned deny-by-default posture for DMA-class attachment, consent visibility, receipt logging, and manual Phase 1 issuance.

5) **Changing the passthrough-device surface is a new admission, not a live control plane**
   - Changing the passthrough-device surface is a new admission, not a live control plane.
   - Owners/runtimes may choose different local passthrough stances for different reviewed leaves or deployment classes, but they may **not** reinterpret a running leaf as carrying a portable mutable passthrough-device presence / topology / reset / interrupt plane under the same admitted identity.
   - If policy cares about a different passthrough-device stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to patch a hidden passthrough control plane by convention.

6) **No new passthrough-device control plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest passthrough-device state, **no new ACP kind**, and **no new conflict-key family** for live attach-detach / bind-rebind / mediated-profile / reset mutation under `ext.microvm`.
   - If a later design wants a portable passthrough-device contract, guest-visible DMA/IOMMU semantics, or live device reassignment controls, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity stance, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that a guest-visible VFIO-assigned, mediated, or SR-IOV-backed device exists with one stable reviewed meaning under `ext.microvm`.
- No portable guest-visible PCI/BDF identity, IOMMU-group, reset, BAR, interrupt, or attach-status API.
- No prohibition on owner-local passthrough decisions; only a refusal to turn them into a portable ambient authority contract.
- No live “same leaf, different passthrough-device presence/topology now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-DMA, D-IOLEASE, D-DEVGUARD, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `dma-posture-v0.md`
  - `io-lease-posture-v0.md`
- Adjacent postures:
  - `host-guest-channel-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `microvm-block-topology-posture-v0.md`
  - `microvm-tpm-surface-posture-v0.md`
  - `microvm-virtual-iommu-posture-v0.md`
  - `microvm-bus-topology-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-21)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-DEVICEPASSTHRU)
- Policy posture:
  - guest-visible passthrough-device exposure adds **no new lane**, **no public bind-attach-reset-status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_device_passthrough_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible device-passthrough contract / no portable VFIO-PCI-BDF-IOMMU-group-SR-IOV-VF-mediated-device-BAR-reset-interrupt plane / owner-local host binding and attachment details stay implementation-local / D-DMA and D-IOLEASE remain authoritative / changing the passthrough-device surface means new admission not live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-KERNEL-POLICY.
- REF-CHYP-VFIO.
- REF-CHYP-DEVICE-MODEL.
- REF-LINUX-VFIO.
- REF-LINUX-VFIO-MDEV.
- REF-QEMU-VFIO.
