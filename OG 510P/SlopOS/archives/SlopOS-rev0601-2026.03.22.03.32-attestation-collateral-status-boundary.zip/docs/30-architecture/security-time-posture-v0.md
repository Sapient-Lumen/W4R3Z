# Security-time posture v0 (policy-local monotonic lower bound)

Purpose: pin the Phase-1 meaning of **D-TIME** so “time for security policies” does not drift back into ambient host wall-clock/admin folklore.

This posture is intentionally narrower than general timekeeping. It defines the **portable meaning used for expiry, anti-rollback, and freshness-sensitive admission**, while leaving UI clocks, calendaring, timezone handling, and host-specific realtime plumbing outside the native authority substrate.

## Posture (v0)

1) **Security time is policy-local and monotonic.**
   - When a profile claims time-based security enforcement (**C-TIME-1**), the system evaluates expiry / anti-rollback using a policy-local monotonic security-time model that satisfies **I-TIME-1** under **A-BOOT-2**.
   - Phase 1 treats security time as a monotonic lower bound (`secure_time_lb`) plus monotonic anchor progression; comparisons are total and fail closed.

2) **App-visible realtime remains observational.**
   - App-visible `kind="realtime"` clocks under **CH-CLOCK v0** are observational/application-facing time sources, not the portable definition of security time.
   - Advancing or disciplining app-visible realtime MUST NOT silently bypass expiry, anti-rollback, or proof-verification policy.

3) **No portable wall-clock setting or timezone/calendar admin plane in v0.**
   - D-TIME adds no portable `settimeofday`, RTC-write, timezone, DST, locale-calendar, leap-second-admin, or “mark clock trusted” control plane.
   - Host or product-specific wall-clock UI/admin mechanisms remain implementation-local or belong to future RFCs.

4) **RTC / timeproof / rollback counters are provider-local inputs to one model.**
   - Secure RTC readings, TPM/boot rollback floors, authenticated timeproof samples, and other trusted provider evidence may feed the policy-local security-time model.
   - Signature / transparency timestamp evidence may support local artifact-verification timing decisions, but it does **not** automatically advance `secure_time_lb`, set app-visible clocks, or create a second portable time domain (`signing-time-evidence-boundary-v0.md`).
   - These inputs do not create separate portable time domains, and they MUST NOT compete through hidden precedence folklore.

5) **Lower-bound advancement is explicit and fail-closed.**
   - Any advancement of security time from external evidence obeys existing proof obligations such as **PO-TIMEPROOF-APPLY** and **PO-EXPIRY-ENF**.
   - Backward movement is not a normal operation in v0; any exceptional override must be explicit, transcript-visible, and policy-reviewed.

6) **No new workflow / ACP / conflict-key family in v0.**
   - D-TIME does not introduce a new workflow surface, effect family, or conflict-key namespace.
   - Reviewed automation continues to use existing time-adjacent seams (for example **D-TIMEPROOF** over `portal.clock.timeproof.sample`) rather than a new generic time-admin workflow.

## Phase 1 non-goals (explicitly deferred)

- No generic wall-clock synchronization daemon as privileged-core meaning.
- No portable timezone/calendar-management surface.
- No portable RTC/CMOS/NVRAM write API.
- No portable “current time authority inventory” or provider ranking protocol.
- No claim that every profile must expose app-visible realtime or authenticated timeproofs.

## Wiring

- Decision surface: `decision-map.md` → **D-TIME**.
- Related time seams:
  - **D-NONDET** via `nondet-posture-v0.md` (explicit clock/entropy authority; no ambient time/RNG).
  - **D-TIMEPROOF** via `timeproof-posture-v0.md` (evidence-first, lower-bound-only authenticated bootstrap).
  - `microvm-time-source-posture-v0.md` (guest-visible clocks stay observational under `ext.microvm`).
  - `microvm-clock-disruption-posture-v0.md` (guest-visible precision-clock trust repair stays separate from proof-bearing security time).
- Schema notes:
  - `clock-descriptor-schema-v0.md` (CH-CLOCK v0; `kind="realtime"` remains observational/app-facing rather than the definition of security time).
  - `time-proof-schema-v0.md` / `timeproof-request-schema-v0.md` (CH-TIMEPROOF / CH-TIMEREQ feed verified evidence into the lower-bound model).
- Assurance hooks:
  - Claim: **C-TIME-1**.
  - Invariant: **I-TIME-1**.
  - Boot assumption: **A-BOOT-2**.
  - Proof obligations: **PO-EXPIRY-ENF**, **PO-TIMEPROOF-APPLY**.
- History / rationale:
  - `rfcs/0090-secure-time-sync-and-timeproofs.md`.
- CI drift gate:
  - `tools/check_security_time_posture.py` (EVID-2026-452).

## References

- REF-TUF-SPEC
- REF-TPM2-PART1
- REF-ANDROID-VERIFIEDBOOT-FLOW
- REF-ROUGHTIME-PROTOCOL
- REF-RFC-8915
