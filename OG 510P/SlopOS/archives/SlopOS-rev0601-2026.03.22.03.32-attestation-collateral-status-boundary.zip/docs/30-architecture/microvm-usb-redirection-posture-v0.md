# MicroVM USB-redirection posture v0 (remote USB forwarding stays non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible USB redirection / remote USB forwarding under `ext.microvm` so convenience device-forwarding stacks do not quietly become a portable reviewed device/control/data plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-IOLEASE**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible USB-redirection contract under `ext.microvm`; there is no portable `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane, owner-local client-device forwarding setup stays implementation-local, and reviewed device / capture / credential meaning still rides on already-pinned explicit seams rather than ambient redirected USB buses.**

Entropy cost justification: the archive already pins host↔guest transports, display/input, audio/capture, guest agents, and direct device passthrough individually, but workstation-oriented virtualization stacks still have one tempting shortcut left: just forward the user's USB devices into the guest. `usbredir`, SPICE USB redirection, smartcard redirection, and related host USB proxy paths can quietly turn client-plugged HID/storage/token devices into a broad ambient control/data plane. One narrow posture closes that gap without inventing a USB portal, guest redirection broker, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible USB-redirection contract**
   - **Phase 1 exposes no portable ambient guest-visible USB-redirection contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable remote USB-forwarding stack, one stable “plug a client USB device and it appears in the guest” contract, or one stable sideband policy surface for redirected peripheral classes.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those forwarding mechanisms do **not** become SlopOS portable API meaning.

2) **No portable `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane**
   - There is **no portable `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable redirected-device attach/detach contract, one stable auto-redirect or manual-redirect policy, one stable redirected-device filter vocabulary, one stable “client smartcard/token appears in the guest” contract, or one stable redirected-device inventory/status API.
   - Owner-local redirected HID / storage / serial / smartcard / security-token / other client-device forwarding helpers remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **Owner-local forwarding setup remains implementation-local**
   - Owner-local forwarding setup remains implementation-local.
   - USB controller model choices, redirection-channel counts, client helper daemons, proxy services, filter strings, and per-device routing choices may still exist locally, but they do **not** create a portable reviewed promise about one guest-visible redirection bus, one attachment workflow, or one host/device status API.
   - In particular, deployments may not smuggle “the user had a YubiKey / smartcard / webcam / headset attached on the client” into reviewed portable semantics just because a runtime can forward USB traffic locally.

4) **Existing explicit seams remain authoritative**
   - Reviewed device authority still rides on explicit `D-IOLEASE` seams rather than ambient redirected USB attach/detach channels.
   - Reviewed camera / microphone / media-capture meaning still rides on explicit `D-CAPTURE` / `D-UICAP` seams rather than “forward the user's USB camera/mic into the guest” folklore.
   - Reviewed token / smartcard / signing meaning still rides on explicit `D-CRYPTOSVC` seams rather than a portable “redirect the client token into the guest” story.
   - Reviewed transfer / file / clipboard / print meaning still rides on explicit `D-PLUMB` portal seams rather than redirected removable-media or helper-device conventions.

5) **Changing the USB-redirection stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the USB-redirection stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different remote-device-forwarding posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `attach_redirected_usb`, `set_usbredir_policy`, `redirect_smartcard`, or `list_redirectable_client_devices` control plane by convention.
   - This keeps redirected-device meaning on already-pinned device / capture / credential seams rather than on ambient virtualization convenience channels.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `attach_redirected_usb`, `detach_redirected_usb`, `set_usb_redirect_filter`, or `redirect_guest_smartcard` must say whether it commutes with activation, reset, capture policy, device-lease policy, and credential policy, and where serialization lives.
   - Until then, USB redirection remains owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable `usbredir` / SPICE USB-redirection contract under `ext.microvm`.
- No portable smartcard / security-token / webcam / headset redirection contract under `ext.microvm`.
- No portable redirected-device inventory, filter, auto-redirect, or status API.
- No claim that remote USB forwarding is an acceptable portable substitute for explicit device leases, capture portals, or cryptographic-token services.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-IOLEASE, D-ACTIVATE)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-display-input-posture-v0.md`
  - `microvm-audio-capture-posture-v0.md`
  - `microvm-device-passthrough-posture-v0.md`
  - `io-lease-posture-v0.md`
  - `capture-portal-posture-v0.md`
  - `cryptosvc-posture-v0.md`
  - `transfer-portal-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-39)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-USBREDIR)
- Policy posture:
  - redirected USB/device forwarding adds **no new lane**, **no portable live attach/detach plane**, and **no portable client-device inventory truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_usb_redirection_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable USB-redirection / no portable `usbredir`-SPICE-USB-redirection-smartcard-redirection-host-USB-forwarding plane / owner-local forwarding setup remains implementation-local / explicit device-capture-credential seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-USBREDIR.
- REF-SPICE-USER-MANUAL.
- REF-QEMU-USB-EMULATION.
