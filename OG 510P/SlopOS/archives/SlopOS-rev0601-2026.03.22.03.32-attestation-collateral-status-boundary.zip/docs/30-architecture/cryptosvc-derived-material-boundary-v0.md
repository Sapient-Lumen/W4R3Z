# D-CRYPTOSVC derived-material boundary v0 (no portable derive-bits / wrap-unwrap / export seam)

Purpose: pin one compact Phase-1 rule on the **D-CRYPTOSVC / IF-CRYPTOSVC** seam: generic key use does **not** become a portable derived-secret materialization, `deriveBits`/`deriveKey`, key wrap/unwrap, or export/import-result surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new crypto op, **no new ACP**, and **no new conflict-key family**. It only narrows how existing crypto-provider semantics may be interpreted.

This doc is a **family member of the closed D-CRYPTOSVC companion boundary family** rooted at `cryptosvc-boundary-index.md`.

## Posture (v0)

1. **No portable derive-bits / wrap-unwrap / export seam in v0**
   - Phase 1 does **not** export a portable `derive_bits`, `derive_bytes`, `derive_key`, `shared_secret`, `raw_secret`, `hkdf`, `kdf`, `kdf_params`, `salt`, `info`, `label`, `wrap_key`, `unwrap_key`, `export_derived_key`, `import_derived_key`, `derived_blob`, `secret_handle`, `wrapped_key_blob`, `derive_into`, `derive_to_keyref`, `return_key_material`, or equivalent derived-material knob or result on IF-CRYPTOSVC, CH-KEYPOL, CH-KEYREF, or adjacent caller-visible workflow surfaces.
   - Providers may internally turn one key reference plus peer/input material into a local shared secret, a wrapped blob, another provider-owned key object, or a provider-local KDF pipeline, but those details remain provider-local or deployment-local rather than portable app-facing seam meaning.
   - Phase 1 therefore does **not** reinterpret provider-local derivation pipelines, derived-key issuance, wrapped-key blobs, or raw secret material as requester-visible result schemas, durable receipt truth, or transcript-stable statements about what exact derived material became available to the caller.

2. **`derive` is bounded key use, not generic secret materialization**
   - Generic crypto use is about *already-held authority* expressed through explicit CH-KEYREF / route handoff plus pinned CH-KEYPOL data, not about standardizing how callers pull raw shared secrets, request one exact KDF transcript, wrap/unwrap arbitrary key blobs, or export newly derived key material until some backend agrees.
   - The closed op set may still include `derive`, but in Phase 1 that does **not** imply a portable `deriveBits`/`deriveKey` API contract, a reusable raw-secret result format, or a generic key-lifecycle/wrap-import workflow on IF-CRYPTOSVC.
   - If reviewed derived-material export, wrapped-key interchange, or portable KDF/result shaping matters, it must live on an explicit future derived-secret / key-wrapping / provider-lifecycle seam with its own compatibility, downgrade, redaction, and evidence semantics.

3. **Derived-material handling is a second workflow, not generic crypto use**
   - Existing ecosystems really do split these surfaces. PKCS #11 separates `C_DeriveKey` from wrap/unwrap and import/export object workflows. Microsoft CNG separates secret agreement, key derivation, and key export/import functions. WebCrypto distinguishes `deriveBits`, `deriveKey`, `wrapKey`, and `unwrapKey` as separate operations/usages.
   - Those are valuable product workflows, but they also allocate extra result-shape, lifecycle, interchange, downgrade, and plaintext-secret-handling semantics that are not harmless synonyms for “use this key handle to sign/decrypt/derive/attest”.
   - Pinning the boundary now keeps IF-CRYPTOSVC from quietly widening into a hidden shared-secret export channel, wrapped-key interchange plane, or provider-lifecycle/result-shaping broker.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future derived-secret / wrap-unwrap / key-export seam must state its own conflict keys, commutativity, serialization point, downgrade/fallback policy, plaintext-handling/redaction rules, and evidence plan explicitly rather than inheriting folklore from PKCS#11 derive/wrap workflows, CNG secret-agreement/export flows, or WebCrypto `deriveBits`/`deriveKey`/`wrapKey`/`unwrapKey` semantics.
   - Until then, generic crypto use remains keyref/route-bound only; derived-material shaping, raw-secret materialization, and key wrap/unwrap/import/export stay hidden inside provider-local or deployment-local setup workflows.

## Phase 1 non-goals (explicitly deferred)

- No portable `derive_bits`, `derive_key`, `shared_secret`, `raw_secret`, `hkdf`, `kdf_params`, `wrap_key`, `unwrap_key`, `export_derived_key`, `import_derived_key`, or equivalent derived-material knob/result on generic crypto use.
- No transcript-stable statement that `derive` also yielded one exact reusable raw secret, wrapped blob, or importable derived key object for the caller.
- No importer-visible provider-lifecycle or key-blob interchange folklore on the D-CRYPTOSVC seam.
- No shell/helper fallback that quietly promotes key use into a derive-bits, wrap/unwrap, or export/import workflow and reports that second workflow as generic crypto-service truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, wrappers and agents quickly start depending on guessed semantics like “do ECDH and return the raw shared secret bytes”, “derive me an HKDF-expanded AES key and hand me the blob”, “wrap this provider key so the other runtime can import it”, or “if derive-to-key fails, export the secret and do the KDF in userspace.” Once those assumptions land in transcripts and automation, they become hard to retract and easy to misuse as secret-spill or lifecycle-widening channels. Pinning the boundary now keeps SlopOS from quietly turning explicit key-use authority into a hidden derived-material export plane. That matters for all four product shapes: workstation UX can still host local secure-channel/setup helpers without standardizing them as substrate meaning; hosted and embedded profiles avoid inheriting raw-secret and key-blob interchange contracts they do not want; and agent tooling cannot mistake CH-KEYREF/CH-KEYPOL for permission to extract shared secrets or provider-owned derived key objects until something seems convenient.

## Profile effect (A–D)

- **Secure workstation (A):** local setup/adaptor tooling may still derive transport/session keys or wrap keys for legacy interop, but generic crypto use does not standardize raw shared-secret bytes or wrapped-key blobs as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake portable secret-export or key-blob interchange APIs that would become containment and downgrade liabilities.
- **Embedded / separation appliance (C):** appliance builds can expose bounded key-use authority without promising general-purpose key-wrap/import or raw-secret derivation APIs they do not implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “derive with this key” with permission to extract raw shared secrets, request one exact HKDF transcript, or shuttle wrapped key blobs between providers; reviewed setup/lifecycle stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/key-policy-schema-v0.md`
- `docs/30-architecture/keyref-schema-v0.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/mechanisms.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `rfcs/0067-capability-crypto-services-and-key-handles.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_cryptosvc_derived_material_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable derive-bits / wrap-unwrap / export seam / derive is bounded key use, not generic secret materialization / derived-material handling is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-602**).

## References

- REF-PKCS11-SPEC.
- REF-MICROSOFT-NCRYPT-DERIVEKEY.
- REF-MICROSOFT-NCRYPT-EXPORTKEY.
- REF-W3C-WEBCRYPTO-2.
