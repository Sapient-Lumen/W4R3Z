# D-NAMECERT posture v0 (issuer-local names; evaluator-local; no ambient resolver)

Purpose: pin an **implementable Phase 1** meaning for **D-NAMECERT** so local naming/delegation stays a
small **user-space evidence seam** rather than drifting into a privileged chain evaluator, a global
name service, or a hidden authorization language.
It narrows RFC-0023 into one thing: **CH-NAMECERT is a bounded, signed bundle that a local naming
service may evaluate under explicit policy to materialize view/proxy state; names remain issuer-local,
and authority-bearing effects stay on the target seam rather than on CH-NAMECERT itself**.
This posture is deliberately adjacent to **D-NS**, **D-CAPX**, and **D-COMMUTE**: bundles may help label
or project authorities, but they do not create ambient resolution, new sequencing semantics, or a second
policy VM.

This doc is intentionally narrow: it does **not** standardize a global PKI, background certificate chase,
a privileged-core chain evaluator, or a generic app-visible name-directory/admin surface.

Companion discovery surface: `namecert-boundary-index.md` keeps the current `namecert-*-boundary-v0.md` cluster enumerable so later D-NAMECERT boundary work cannot land as orphan prose.

## Posture (v0)

1) **CH-NAMECERT is explicit naming evidence, not ambient resolution authority**
   - Authority-bearing resolution appears only when a caller explicitly presents **CH-NAMECERT v0** bytes to a local naming service or policy path.
   - Parsing, copying, syncing, replicating, or displaying CH-NAMECERT bytes does **not** auto-install bindings, widen a view, or resolve a name.
   - Phase 1 therefore treats CH-NAMECERT as a sharp evidence/artifact seam, not as a shorthand for “look this up somewhere”.

2) **User-space evaluator only; no privileged-core chain discovery**
   - The privileged/core seam does **not** implement certificate parsing, chain discovery, or authorization reasoning for D-NAMECERT.
   - If a privileged action depends on a resolved name, the resulting authority must still be traceable to an explicit **view** and/or pinned CH-NAMECERT bundle digest recorded in the usual audit surfaces.
   - This is the concrete implementation stance behind **I-NAME-1** and keeps the substrate small.

3) **Issuer-local namespaces, not a global PKI or directory**
   - `Binding.name` and `Delegation.role` are interpreted only inside the issuer/policy context that imported the bundle.
   - Phase 1 further pins those authority-bearing labels to a tiny exact-byte lowercase ASCII profile (`namecert-string-profile-v0.md`): no Unicode normalization, case-folding, PRECIS/Stringprep, or confusable-policy machinery is imported onto D-NAMECERT itself.
   - Label structure is then pinned by `namecert-label-atom-boundary-v0.md`: admitted `Binding.name` / `Delegation.role` values are single opaque atoms after validation, so `.` / `_` / `-` remain ordinary bytes and D-NAMECERT imports no hierarchy, wildcard, prefix/suffix, or path grammar onto the naming seam.
   - Phase 1 declines any global-root, global-uniqueness, DNS-like search, or "latest cert wins" semantics.
   - CH-NAMECERT therefore helps organize and delegate **local** authority; it is not a second ambient naming plane.

4) **Projection is explicit: views/proxies are materialized only by local policy**
   - A naming service MAY project accepted bundles into **view fragments**, labels, or local **proxy/service** metadata, but only through explicit local policy that chooses trust roots, visibility, freshness, and any materialization target.
   - Evaluating a bundle must not mint raw kernel/user capability ids or bypass the normal D-NS / D-CAPX attachment/import surfaces.
   - Phase 1 authority-bearing materialization is further narrowed by `namecert-projection-boundary-v0.md`: accepted results land only through explicit D-NS `view.attach` / `view.detach` on concrete `view.slot` keys with retained source **`digest(CH-NAMECERT v0)`** evidence, while proxy/service labels remain observational metadata only.
   - Time/freshness is further pinned by `namecert-time-boundary-v0.md`: validity checks may deny future admissions, but live `view.slot` bindings do **not** self-expire or auto-detach just because time advances or fresher timeproof evidence arrives.
   - Later negative evidence / issuer withdrawal is further pinned by `namecert-revocation-boundary-v0.md`: revocation remains evaluator-local and admission-scoped, with no ambient CRL/OCSP, no latest-wins resolver semantics, and no automatic detach of live bindings when the evaluator learns new negative evidence.
  - Candidate selection is further pinned by `namecert-selection-boundary-v0.md`: when multiple admissible bindings/delegation paths survive local policy, evaluation stays **set-valued** and Phase 1 adds no hidden ranking/default-winner rule on D-NAMECERT itself; any live binding must identify the exact chosen candidate with retained source digests.
  - Search/evaluation is further pinned by `namecert-search-boundary-v0.md`: Phase 1 stays **closed-world and bounded** over one explicit bundle set, may use local goal-directed search only inside that set, and declines suspend/resume distributed credential discovery, hidden retry/fetch, or unbounded cycle expansion.
  - Redelegation is further pinned by `namecert-redelegation-boundary-v0.md`: onward delegation is explicit absent in Phase 1, because CH-NAMECERT v0 carries no propagation-bit/depth field; a delegated subject may exercise a grant but may not use that grant as proof that it can issue further CH-NAMECERT delegations unless it is independently authorized under explicit local policy.
  - Trust anchoring is further pinned by `namecert-trust-root-boundary-v0.md`: trust roots / issuer allowlists remain **explicit evaluator-local trust-anchor input**, CH-NAMECERT is not itself a trust root or trust-policy container, and bundles cannot self-anchor or auto-install new trusted issuers.
  - Bundle layout is further pinned by `namecert-normal-form-boundary-v0.md`: admitted Phase 1 `bindings` / `delegations` arrays are **duplicate-free canonical statement sets** — strictly sorted by canonical element bytes, with no first-match/last-match semantics and no duplicate weighting by repetition.
  - Label structure is further pinned by `namecert-label-atom-boundary-v0.md`: admitted Phase 1 `Binding.name` / `Delegation.role` values are single opaque atoms after validation, so punctuation does not become hidden hierarchy, wildcard, prefix/suffix, or path grammar.
  - Principal identity is further pinned by `namecert-principal-profile-v0.md`: admitted Phase 1 `issuer` / `subject` refs are hash-only and canonical (`PrincipalRef.kind="key_hash"`, `alg="cose_key_thumbprint_sha256"`, exact 32-byte thumbprints), while raw `PrincipalRef.kind="pubkey"` admissions reject and verifier-key distribution stays on explicit local trust-anchor / key-registry policy rather than in CH-NAMECERT itself.
  - Signature semantics are further pinned by `namecert-signature-profile-v0.md`: admitted Phase 1 bundles use **one inline direct signature profile** (`sig.alg="ed25519"` over canonical unsigned bundle bytes), and wrapper-only, keyless/X.509, or multisignature semantics stay off the D-NAMECERT admission seam.
  - Bundle metadata semantics are further pinned by `namecert-metadata-boundary-v0.md`: `bundle_id` and `created_ms` are **signed provenance only** in Phase 1 and do not create latest-wins, implicit replacement-lineage, or metadata-driven freshness/obsolescence semantics on D-NAMECERT itself.
  - Capability-bearing target material is further pinned by `namecert-bearer-boundary-v0.md`: admitted Phase 1 bundles MUST NOT embed raw CH-SREF / CH-CAPX / raw capability material, `TargetRef.kind="sturdyref"` is reserved+rejected, and any restore/import path stays on explicit D-CAPX / CH-SREF seams instead of piggybacking on naming evidence.
   - This keeps the authority-bearing result on the already-reviewed seam rather than on CH-NAMECERT itself.

5) **Delegation stays monotonic and fail-closed**
   - Evaluation must be **bounded**, **monotonic**, and **non-amplifying**: bundle processing cannot yield authority beyond the explicit bindings/delegations presented.
   - Phase 1 also declines implied redelegation: a delegated subject may exercise a received grant, but may not use that grant as proof that it can issue further CH-NAMECERT delegations unless a future reviewed seam adds explicit propagation semantics.
   - Unknown/unsupported constraint semantics must **fail closed** rather than degrade into “ignore and continue”.
   - Phase 1 therefore declines any portable Datalog/caveat/policy VM on D-NAMECERT itself; `Constraint` remains an evaluator-local, profile-scoped hook rather than a standard ambient language.

6) **No ambient fetch, chase, or background certificate discovery**
   - The evaluator consumes an **explicit bundle set** supplied by policy, configuration, or an already-authorized artifact flow.
   - Phase 1 search is **closed-world** over that presented set: implementations may do bounded local search, but D-NAMECERT standardizes no suspend/resume distributed credential discovery, issuer-directed retrieval, or hidden background retry (`namecert-search-boundary-v0.md`).
   - CH-NAMECERT does **not** imply ambient network fetch, filesystem chase, directory walk, or background gossip beyond separately authorized replication/artifact transfer seams.
   - This keeps sealed compat and offline/embedded profiles honest.

7) **Replication remains bundle evidence only**
   - Under Hybrid, replicated `object_family = namecert` remains a **signed bundle-set evidence** surface only, exactly as pinned by `namecert-replication-boundary-v0.md`.
   - Replicated arrivals may widen the observed set of candidate bundles, but they do not auto-install active bindings, pick winners, become a global resolver, or rewrite the local trust-anchor set; when multiple admissible candidates exist, Phase 1 evaluation stays set-valued rather than applying a hidden winner rule (`namecert-selection-boundary-v0.md`, `namecert-trust-root-boundary-v0.md`).
   - Replication therefore helps audit/distribution without changing who decides trust/visibility/activation.

8) **Routine workflow/observation surfaces carry digests, not resolver side effects**
   - Ordinary receipts/logs/workflow descriptors should carry **`digest(CH-NAMECERT v0)`** or other explicit bundle-set evidence when naming context matters, not hidden resolver state.
   - If a workflow needs the resolved result, that result must travel on the destination seam (for example, an explicit view binding or explicit D-CAPX import), not as an implicit “name was resolved earlier” side effect.
   - This keeps review surfaces stable and avoids hidden authority channels.

9) **No app-visible global name inventory, watch, or admin seam**
   - Phase 1 exposes **no generic list/search/watch API** over all imported bundles, all local names, or all resolution results.
   - There is no portable background sync agent, cross-issuer name browser, or generic “rename the world” admin protocol on D-NAMECERT itself.
   - Any future management plane must pay its own schema, commutativity, and evidence cost explicitly.

10) **External action semantics stay on the materialized seam, not on CH-NAMECERT itself**
   - Accepting or evaluating a bundle is an explicit local policy event; later externally visible actions keep the conflict keys, commutativity stance, serialization boundary, and ordering evidence of the target seam they actually touch (usually **D-NS** or **D-CAPX**).
   - D-NAMECERT therefore adds **no new CH-ACP kind**, **no portal family**, and **no standalone conflict-key vocabulary** in Phase 1.
   - This keeps Hybrid + commutativity honest: CH-NAMECERT changes how local policy may *label/project* authority, not the ordering semantics of downstream operations.

11) **Sealed compat remains killable and non-ambient**
   - Foreign Cells may import guest naming material only through explicit, policy-killable membrane surfaces.
   - Compat enablement must not recreate ambient host path lookup, global certificate stores, or hidden name-resolution daemons that bypass declared CH-NAMECERT handling.
   - Any compat mapping remains subordinate to sealed-compat policy and fails closed when disabled.

## Phase 1 non-goals (explicitly deferred)

- **No privileged-core chain evaluator or global resolver**.
- **No automatic network/filesystem chase for missing bundles**.
- **No ambient revocation/discovery service or latest-wins resolver semantics**.
- **No self-anchoring bundle semantics or replicated trust-root distribution**.
- **No portable caveat/policy language on CH-NAMECERT itself**.
- **No raw issuer/subject public keys admitted as `PrincipalRef.kind="pubkey"`**.
- **No implied onward delegation or hidden propagation-depth policy on `Delegation`**.
- **No order-sensitive or duplicate-weighted statement semantics inside admitted bundles**.
- **No raw bearer/import material embedded inside admitted CH-NAMECERT bundles**.
- **No app-visible global bundle/name inventory or watch surface**.
- **No new workflow / ACP / conflict-key / admin surface for naming lifecycle management**.

## Wiring

- Decision surface:
  - `decision-map.md` (D-NAMECERT)
- Schemas / registries:
  - `namecert-schema-v0.md` (CH-NAMECERT v0)
  - `schema-registry.md`
  - `replication-object-family-registry.md` (contrast: replication is evidence only)
- Adjacent runtime surfaces:
  - `view-namespace-posture-v0.md`
  - `capx-posture-v0.md`
  - `namecert-replication-boundary-v0.md`
  - `namecert-projection-boundary-v0.md`
  - `namecert-time-boundary-v0.md`
  - `namecert-revocation-boundary-v0.md`
  - `namecert-selection-boundary-v0.md`
  - `namecert-search-boundary-v0.md`
  - `namecert-redelegation-boundary-v0.md`
  - `namecert-trust-root-boundary-v0.md`
  - `namecert-normal-form-boundary-v0.md`
  - `namecert-string-profile-v0.md`
  - `namecert-label-atom-boundary-v0.md`
  - `namecert-principal-profile-v0.md`
  - `namecert-bearer-boundary-v0.md`
  - `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**, **I-NAME-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**, **PO-NAMECERT-CHAIN**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-029**, **AC-030**)
- Related posture/history surfaces:
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/llm-runbook.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future naming-management or distributed-resolution surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_namecert_posture.py` fails `make lint` if this posture stops being discoverable, loses its **issuer-local / user-space / no ambient fetch or resolver / fail-closed constraint / digest-first** stance, or drops its primary REF wiring.

## References

- REF-SDSI-RL96.
- REF-SPKI-RFC2692.
- REF-SPKI-RFC2693.
- REF-UCAN-SPEC.
- REF-KEYNOTE-RFC2704.
- REF-BISCUIT-SPEC.
- REF-PRECIS-RFC8264.
- REF-UNICODE-UTS39.
- REF-COSEKEYTHUMBPRINT-RFC9679.
