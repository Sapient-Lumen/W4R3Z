# MicroVM audio/capture posture v0 (no portable ambient guest-visible sound/capture device contract)

Purpose: pin the **Phase 1** meaning of guest-visible audio and capture-class sound virtualization under `ext.microvm` so paravirtual sound cards, host audio backends, and mixer/control folklore do not quietly become a reviewed microphone/system-audio authority plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-CAPTURE**, **D-UICAP**, **D-PLUMB**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible audio/capture device contract under `ext.microvm`; there is no portable `virtio-snd` / playback-capture-stream-mixer-jack-chmap plane, owner-local audio-backend and media-graph choice stays implementation-local, and microphone/system-audio capture meaning still rides on explicit D-CAPTURE / D-UICAP / D-PLUMB seams rather than ambient guest devices.**

Entropy cost justification: the archive already keeps host↔guest transports killable, trusted UI and capture portal-mediated, and display/input plumbing implementation-local, but audio is the adjacent place where modern VMMs can quietly regrow ambient host channels: paravirtual sound cards, backend-specific playback/capture routing, mixer controls, and guest-visible “just record from the host microphone” expectations. One narrow posture closes that gap without inventing an audio protocol, guest agent, or media-session schema family.

## Posture (v0)

1) **No portable ambient guest-visible audio/capture device contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible audio/capture device contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard sound card, one stable playback/capture stream vocabulary, or one blessed host-backed audio-routing stack.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable guest audio/capture device plane exists with stable host playback or microphone semantics.”

2) **No portable `virtio-snd` / playback-capture-stream-mixer-jack-chmap plane**
   - Phase 1 standardizes **no portable `virtio-snd` / playback-capture-stream-mixer-jack-chmap plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about playback vs capture stream inventory, mixer/control element semantics, jack presence, channel-map exposure, host audio-device selection, or “this capture stream corresponds to the host microphone/system-audio source.”
   - Implementations may locally expose a virtio sound device, one or more playback/capture streams, mixer controls, or no guest-visible sound device at all for one deployment class, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local audio backend and media-graph choice stay implementation-local**
   - Owner-local audio backend and media-graph choice stay implementation-local.
   - Runtimes may choose host audio backends, per-device helper processes, media servers, CRAS/AAudio/PipeWire-like routing, or no host audio plumbing at all, but that does **not** create a portable reviewed promise about one backend stack, one host device-selection API, one mixer/control surface, or one latency/capture policy model.
   - In particular, backend socket paths, media-graph object names, per-stream routing policy, and host-device selection remain host/runtime-local mechanism, not portable SlopOS interface meaning.

4) **Capture authority stays on explicit D-CAPTURE / D-UICAP / D-PLUMB seams**
   - Capture authority stays on explicit D-CAPTURE / D-UICAP / D-PLUMB seams.
   - Microphone capture, system-audio capture, screencast-with-audio, remote-desktop audio, and related high-risk media ingress continue to ride on already-pinned capture/UI portal workflows rather than ambient guest sound devices.
   - A guest-visible sound device may help one implementation render playback or ingest local test audio, but it does **not** become the portable authority seam for microphone/system-audio capture meaning.

5) **Changing the audio/capture stance is owner-local lifecycle or new admission, not a portable live control plane**
   - Changing the audio/capture stance is owner-local lifecycle or new admission, not a portable live control plane.
   - Owners/runtimes may choose different local sound/capture configurations for different reviewed leaves or deployment classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable stream-hotplug, mixer-admin, jack-status, source-select, or capture-enable protocol under the same admitted identity.
   - If policy cares about a different guest-visible audio/capture stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden host↔guest media-control contract by convention.

6) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for audio/capture state, **no new ACP kind**, and **no new conflict-key family** for stream attach, mixer mutation, jack reporting, source selection, or host capture enablement under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `attach_sound`, `set_volume`, `set_mute`, `query_streams`, `query_jacks`, `select_capture_source`, or `start_microphone_capture`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that microVM guests always see one standard sound card or playback/capture stream inventory.
- No portable `virtio-snd` / mixer / jack / channel-map / host-audio-device-selection contract under `ext.microvm`.
- No ambient microphone or system-audio capture authority through guest sound devices.
- No generic audio broker, media-session daemon, or guest audio-control agent API.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-CAPTURE, D-UICAP, D-PLUMB, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `capture-portal-posture-v0.md`
- Adjacent notes:
  - `host-guest-channel-posture-v0.md`
  - `microvm-display-input-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-29)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-AUDIOCAPTURE)
- Policy posture:
  - audio/capture virtualization adds **no new lane**, **no public guest audio-control plane**, and **no portable in-place capture-source or mixer-mutation protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_audio_capture_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible audio/capture contract / no portable `virtio-snd`-playback-capture-stream-mixer-jack-chmap plane / owner-local audio-backend and media-graph choice stay implementation-local / capture authority stays on explicit D-CAPTURE D-UICAP and D-PLUMB seams / changing audio-capture stance is owner-local lifecycle or new admission not a portable live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-QEMU-VIRTIO-SND.
- REF-CROSVM-DEVICES.
- REF-PIPEWIRE-ACCESS.
- REF-PIPEWIRE-SESSMGR.
