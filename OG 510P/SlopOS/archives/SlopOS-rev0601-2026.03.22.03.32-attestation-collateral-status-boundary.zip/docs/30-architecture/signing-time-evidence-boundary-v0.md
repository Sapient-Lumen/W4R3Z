# Signing-time evidence boundary v0 (exact signing-event evidence; no freshness/approval/time-admin drift)

Purpose: pin the Phase-1 meaning of **signing-time evidence** across **D-SIGENV**, **D-KEYLESS**, **D-TLOG**, **D-TIME**, and optional out-of-band timestamp artifacts so the archive does not quietly overload “there is a timestamp” into freshness, approval, online CA/TSA dependencies, or wall-clock authority.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SIGENV v0** answers *which typed payload digest was signed*.
- **CH-TLOG v0** answers *which exact artifact digest was anchored at which exact append-only log state*.
- **D-TIME** answers *how local policy evaluates expiry / anti-rollback using one monotonic lower-bound model*.
- **Out-of-band timestamp artifacts** (for example RFC 3161 tokens or ecosystem bundle material) answer *what exact bytes a TSA or log timestamp covered*.

## Posture (v0)

1) **Signing-time evidence binds exact signing-event bytes, not unsigned subject bytes.**
   - If a deployment wants evidence that a signature existed before certificate expiry or revocation, the timestamp/log evidence MUST cover the **signature / envelope / signed statement / signed bundle bytes** whose creation time matters.
   - A raw payload-only timestamp may still prove earlier data existence, but it does **not** by itself prove when a signature was created.
   - Phase 1 therefore refuses the folklore shortcut “the artifact digest was timestamped, therefore the later signature counts as timely”.

2) **Timestamp and log evidence may support certificate-validity proofs, but they do not replace signature or identity verification.**
   - A verifier may use exact signing-time evidence to show that an already-verified signature existed during the signer certificate’s validity window.
   - That evidence does **not** replace **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**, issuer/identity allowlists, or local trust-root policy.
   - Successful timestamp validation is therefore evidence about timing, not a portable approval verdict or install shortcut.

3) **`tlog_anchor_digest` and any RFC 3161 / COSE timestamp records remain exact evidence artifacts, not freshness/latest/install authority.**
   - `tlog_anchor_digest` may point to a **CH-TLOG v0** artifact relevant to the signing event, but it does not mean “latest trusted timestamp”, “fresh enough to install”, or “skip local verification because the log saw it”.
   - Any RFC 3161 token, COSE timestamp header, bundle entry, or similar timestamp material remains an exact evidence artifact whose meaning depends on the bytes it covers and the local policy that checks it.
   - Phase 1 adds no “newest timestamp wins”, “timestamped therefore approved”, or “signed before X therefore still runnable forever” rule.

4) **No ambient TSA / timestamp-chain / OCSP / CRL / account-status fetch plane in v0.**
   - Accepted TSAs, logs, chains, and any revocation/account-status inputs remain explicit local policy inputs or explicit tooling artifacts.
   - Phase 1 standardizes no privileged-core TSA query client, timestamp-chain discovery API, OCSP/CRL callback, repo-owner/account-status lookup, or browser login loop around signing-time evidence.
   - Any online refresh/retrieval remains tooling-only, policy-killable, and must use already-reviewed network/file seams.

5) **Interop timestamp formats remain out-of-band / digest-referenced; no new native timestamp schema family in Phase 1.**
   - RFC 3161 tokens, COSE timestamp headers, Sigstore bundle timestamp material, and similar ecosystem objects may be packaged or referenced as exact artifacts.
   - They do not become a new native timestamp/TSA schema family, and Phase 1 does not widen **CH-SIGENV v0** into an embedded proof-and-bundle kitchen sink.
   - Any future native timestamp artifact must return RFC-first with explicit subject model, proof obligations, trust roots, conflict keys, serialization boundary, and evidence plan.

6) **No automatic security-time advancement or wall-clock update from signing-time evidence.**
   - Timestamp or transparency material used to evaluate one artifact/signature does not automatically advance **D-TIME** lower bounds, set app-visible realtime clocks, or discipline wall-clock UI/admin state.
   - If a deployment wants to feed such evidence into broader time policy, that transformation remains explicit local policy and must preserve the already-pinned **D-TIME** posture.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing signing/time/log seams are interpreted.
   - Any future timestamp publication, notarization queue, freshness arbitration, or replay-window workflow must pay for its own RFC, conflict keys, serialization story, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native timestamp-schema family or TSA admin plane.
- No default rule that logging or timestamping a raw payload digest proves when a signature was created.
- No portable “best timestamp source” / “latest timestamp” / “current certificate status” service.
- No automatic promotion of signing-time evidence into install, approval, or runtime freshness authority.
- No automatic advancement of D-TIME lower bounds or app-visible clocks from signature timestamp evidence.

## Why this is worth pinning

The surrounding ecosystem is explicit that timestamp semantics split in ways that are easy to confuse:
- RFC 3161 defines time-stamp tokens as proof that a datum existed before a time and even uses the “signature existed during certificate validity” case as an example.
- Sigstore’s timestamp guidance says short-lived certificate verification relies on Rekor inclusion time or an RFC 3161 timestamp, and recommends **countersigning the signature rather than the artifact** when using a TSA.
- RFC 9921 makes the distinction fully explicit for COSE: **payload timestamps** and **signature timestamps** have different semantics, and validators must not treat payload-only timestamps as proof of signature creation time.

Pinning that split now prevents SlopOS from slowly accepting older payload timestamps as signature-validity evidence, from letting timestamp records outrun local trust/freshness policy, or from regrowing an ambient TSA/OCSP/account-status client under the names of keyless verification or transparency support.

## Profile effect (A–D)

- **Secure workstation (A):** offline artifact verification stays reviewable; timestamp material can help long-term verification without turning laptops into ambient TSA/OCSP clients.
- **Cloud micro-VM substrate (B):** promotion policy can require exact signing-event evidence for short-lived cert workflows without confusing timestamp presence with approval/freshness.
- **Embedded / separation appliance (C):** exact offline timestamp artifacts remain shippable in release bundles without introducing a second mutable time-control plane.
- **Agent/automation OS (D):** agents may reason over signing-time evidence, but they cannot smuggle “timestamped therefore allowed” authority through policy or tooling shortcuts.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-TLOG**, **D-TIME**.
- Adjacent meaning pins:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/transparency-log-posture-v0.md`
  - `docs/30-architecture/security-time-posture-v0.md`
  - `docs/30-architecture/transparency-log-anchor-schema-v0.md`
- Engineering / profile surfaces:
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
  - `rfcs/0029-transparency-log-anchors-for-evidence.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**, **I-TIME-1**.
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**, **PO-TLOG-VERIFY**, **PO-EXPIRY-ENF**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_signing_time_evidence_boundary.py` keeps the split small and discoverable (**EVID-2026-465**).

## References

- **REF-RFC3161-TSP**
- **REF-RFC9921-TST-HEADER**
- **REF-SIGSTORE-TIMESTAMPS**
- **REF-SIGSTORE-BUNDLE**
