# Provenance-evidence set boundary v0 (multiple exact provenance artifacts stay verifier-local)

Purpose: pin the Phase-1 meaning of **multiple exact provenance-bearing evidence artifacts** across **D-PCP**, **D-ATOMICUPD**, **D-BOOT**, **D-SIGENV**, and **D-AREF** so one carrier plus adjacent proof/evidence artifacts do not quietly imply a native provenance closure, union rule, or completeness claim.

Entropy cost justification: the archive already pins one exact `prov_attestation_digest`, exact adjunct `proof_bundle` artifacts, and exact transparency/proof imports, but real ecosystems often ship several provenance-relevant artifacts side by side for the same subject. Leaving that relationship unstated invites expensive drift later: tools start treating “all attached provenance-like things” as one authoritative set, or carriers start implying a preferred cross-artifact merge/completeness rule. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-UPD v0** and **CH-BOOT v0** may pin one exact `prov_attestation_digest` and may also carry exact adjunct evidence digests in `artifacts[]`.
- **`proof_bundle`** remains one descriptive role label for one exact adjunct evidence artifact digest.
- **CH-TLOG v0** and imported `tlog-proof@v1`-style artifacts remain exact audit evidence about exact bytes.
- **Verifier-local policy** still answers whether one exact artifact, several exact artifacts, or none are required and how their verified contents are related for one already-pinned cohort.

## Posture (v0)

1) **Multiple exact provenance-bearing artifacts do not become one native provenance closure.**
   - A deployment may carry one exact `prov_attestation_digest` and may also pin other exact evidence artifacts such as `proof_bundle`, `CH-TLOG` anchors, or `CH-AREF`-reachable provenance-related bytes.
   - Phase 1 imports each artifact as **exact bytes only**.
   - It does **not** import a native rule that “all provenance-bearing artifacts attached to this cohort are jointly authoritative”, “the set is complete”, or “the carrier defines the full provenance closure”.

2) **Cross-artifact union/reconciliation remains verifier-local, not carrier-visible semantics.**
   - If several exact artifacts each contain provenance-relevant statements, envelopes, receipts, or auxiliary verification material, the carrier does not thereby choose how they compose.
   - There is no native “union all matching statements across artifacts”, “prefer the direct `prov_attestation_digest` over side bundles”, “proof bundle fills in missing provenance subjects”, or “transparency evidence selects the winning provenance statement” rule.
   - Any such relation remains explicit verifier-local policy or future RFC work.

3) **Presence of several exact artifacts does not auto-satisfy coverage/completeness expectations.**
   - Extra provenance-bearing artifacts do not automatically satisfy stricter provenance requirements, dependency completeness goals, or build-history expectations.
   - Companion `provenance-required-subject-boundary-v0.md`, `provenance-coverage-policy-boundary-v0.md`, and `provenance-container-selection-boundary-v0.md` still govern required subject subsets, verifier-local coverage policy, and per-container statement selection.
   - A verifier may still fail closed even when many exact artifacts are present.

4) **Each selected artifact still verifies on its own seam.**
   - **PO-SIGENV-VERIFY** still answers whether one selected envelope/signature binding verified under local policy.
   - **PO-PROV-BIND** still answers whether one selected provenance statement binds the exact already-pinned cohort digests the verifier cares about.
   - **PO-TLOG-VERIFY** still answers whether one selected transparency artifact anchors exact bytes under the accepted local log/witness policy.
   - Cross-artifact co-presence does not fuse those checks into a portable “evidence set passed” verdict.

5) **Ordering, adjacency, and packaging location are non-authoritative.**
   - File order inside a release zip, `artifacts[]` order, neighboring filenames, sidecar naming, or “bundle next to attestation” packaging conventions stay non-authoritative.
   - The portable meaning remains the exact digest of each artifact plus whichever already-pinned schema interprets those bytes.
   - Companion `verification-material-discovery-boundary-v0.md` and `proof-bundle-role-boundary-v0.md` still pin that discovery and generic bundle labels do not choose authority.

6) **No portable fallback/preference/completeness/supersession rule in v0.**
   - Phase 1 adds no native “if direct provenance fails, try proof bundle”, “prefer the most recent artifact”, “the richer set wins”, or “this exact evidence set supersedes earlier ones” meaning.
   - Any fallback, tie-breaking, or completeness notion remains verifier-local tooling and must not be inferred from artifact count or packaging style.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing provenance/signature/update/boot/evidence seams interpret multiple exact evidence artifacts.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native provenance-evidence-set schema or closure grammar.
- No portable union/preference/fallback/completeness rule across several exact provenance-bearing artifacts.
- No rule that `prov_attestation_digest`, `proof_bundle`, or transparency evidence choose one another’s meaning.
- No cross-artifact supersession/history semantics.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem stays deliberately layered:
- the in-toto attestation framework separates statement, envelope, and bundle layers, and the bundle layer is for grouping attestations rather than defining a universal appraisal rule;
- Sigstore bundles describe the verification material and content required to verify one signature object, while attestations on an artifact can still be verified as separate attestation objects;
- SLSA verification guidance still tells consumers to compare provenance to expectations and notes that dependency verification/completeness may be best-effort unless additional verifier-local mechanisms are used.

Pinning that split now keeps SlopOS from quietly inheriting “all nearby provenance-ish artifacts form one authoritative evidence set” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** human-facing release bundles may carry several provenance-related artifacts without making local install/boot semantics depend on bundle adjacency or attachment count.
- **Cloud micro-VM substrate (B):** fleet releases may ship richer side evidence, but deployment verifiers stay explicit about which exact artifacts matter for one cohort.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject or select exact artifacts without importing a general evidence-closure algorithm.
- **Agent/automation OS (D):** agents may inspect richer evidence packs, but they cannot smuggle “all attached evidence jointly authorizes this install” into portable meaning.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-ATOMICUPD**, **D-BOOT**, **D-SIGENV**, **D-AREF**.
- Adjacent meaning pins:
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/proof-bundle-role-boundary-v0.md`
  - `docs/30-architecture/provenance-container-selection-boundary-v0.md`
  - `docs/30-architecture/provenance-required-subject-boundary-v0.md`
  - `docs/30-architecture/provenance-coverage-policy-boundary-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-PROV-CHAIN-1**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-SIGENV-1**, **I-AREF-1**.
  - **PO-PROV-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-SIGENV-VERIFY**, **PO-TLOG-VERIFY**, **PO-AREF-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_provenance_evidence_set_boundary.py` keeps the split small and discoverable (**EVID-2026-481**).

## References

- **REF-IN-TOTO-STATEMENT**
- **REF-SIGSTORE-BUNDLE**
- **REF-SLSA-VERIFYING-ARTIFACTS**
- **REF-DSSE**
