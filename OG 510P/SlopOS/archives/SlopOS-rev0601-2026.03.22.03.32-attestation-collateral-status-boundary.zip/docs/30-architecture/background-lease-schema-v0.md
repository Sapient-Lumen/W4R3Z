# CH-BGLEASE v0: Background/autostart lease descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **background execution** and **login autostart** grants issued by a background portal (D-BGLEASE).
This schema is **not** the authority itself; it describes the bounds of a BackgroundLease handle and any associated autostart grant.

References: REF-XDG-PORTAL-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-ANDROID-FGS-RESTRICTIONS, REF-APPLE-BG-MODES.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-BGLEASE v0 := {
  v: 0,

  ; what is being granted
  background: bool,            ; permission to continue running while backgrounded
  autostart: bool,             ; permission to start automatically at user login

  ; lifetime / review posture
  issued_at_s: uint,           ; monotonic time or policy-defined epoch seconds
  ttl_s: uint,                 ; portal-clamped review window; expiry revokes the lease

  ; stable identifiers for attribution (no secrets)
  origin: {
    comp_id: tstr,             ; canonical component name/id (e.g., CH-COMP name), bounded
    instance?: tstr,
  },

  reason: tstr,                ; bounded, user-visible rationale

  ; short status suitable for a system “background apps” surface
  status_message?: tstr,       ; single line, bounded length

  ; policy posture hints (non-authoritative)
  indicators?: {
    required: bool,            ; whether a non-spoofable indicator must be shown
  },

  redaction?: {
    mode: tstr,                ; closed enum: "none" | "hash_only"
  }
}

Notes:
- This descriptor does not contain capability material. The live BackgroundLease is a handle/capability.
- `ttl_s` is a **review window**: long-lived background/autostart should be periodically re-confirmed in strict profiles.

## Validation rules (minimum)
A CH-BGLEASE validator MUST be total and fail closed:
1) `v == 0`.
2) At least one of `background` or `autostart` is true.
3) `issued_at_s` and `ttl_s` are present and bounded; portal clamps ttl.
4) `origin.comp_id` is present and bounded.
5) `reason` is bounded.
6) If present, `status_message` is bounded (single line; policy clamp on max length).
7) `redaction.mode` is allowlisted when present.
8) Unknown fields reject (or are rejected by canonical CBOR decode).

## Security posture
- CH-BGLEASE is **observational** and contains **no authority**; the live BackgroundLease is a handle/capability issued by `portal.background` under policy. The pinned Phase 1 meaning of that policy surface lives in `background-lease-posture-v0.md` (prefer D-JOBS for deferrable work; no silent widening from background-only to autostart).
- In LLM-first stacks, background/autostart requests SHOULD be mediated via ACP kind `portal.background.request`, binding `bgreq_digest = digest(CH-BGREQ v0)` and emitting transcript-visible outcomes (CH-ACPOUT/CH-DENY). CH-BGLEASE is the portal-issued receipt-like descriptor for the resulting grant bounds.
- Historical CH-BGLEASE bytes remain exact issued-bounds evidence only; they do **not** by themselves prove that a corresponding background/autostart grant is still active/enabled/current now (`lease-descriptor-state-boundary-v0.md`).

## Privacy notes
Background/autostart grants leak behavioral metadata (“this app runs continuously”). Exports SHOULD:
- treat CH-BGLEASE as **sensitive metadata** in strict profiles,
- prefer `redaction.mode="hash_only"` for routine telemetry.
