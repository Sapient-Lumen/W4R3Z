# Signature-algorithm acceptance boundary v0 (algorithm identifiers are signed evidence; acceptance stays explicit local policy)

Purpose: pin the **Phase 1** meaning of signature/message algorithm identifiers around **D-SIGENV** and **D-KEYLESS** so `alg` labels, certificate signature OIDs, and profile capability sets do not quietly turn into artifact-selected crypto policy, ambient library defaults, or hidden negotiation.

Entropy cost justification: `signature-envelope-posture-v0.md`, `signature-trust-root-boundary-v0.md`, `keyless-issuer-discovery-boundary-v0.md`, `verification-material-discovery-boundary-v0.md`, and `verification-policy-selection-boundary-v0.md` already pin *who is trusted*, *where verification material comes from*, and *who chooses policy*. The remaining ambiguity is **which signature algorithms count as acceptable once a signed object is present**. One narrow boundary closes that gap without adding a new schema family, negotiation protocol, or algorithm-inventory service.

## Posture (v0)

1) **Algorithm identifiers are exact signed evidence of how a signature was produced, not verifier policy by themselves.**
   - `CH-SIGENV v0` carries an `alg` field naming the signature algorithm used for that signature record.
   - Certificate signatures similarly carry exact algorithm identifiers / parameters in X.509 structures.
   - Those fields are part of the evidence set; they do **not** by themselves say the verifier must accept that algorithm in this deployment.

2) **Acceptable algorithms remain explicit verifier-local / profile-local policy.**
   - RFC 7515 says a JWS is invalid unless the `alg` value represents a supported algorithm, and it further says that even a successfully validated JWS should be considered invalid unless the algorithms used are acceptable to the application.
   - RFC 9052 likewise defers the required algorithm set to each application profile, and RFC 9711 says an EAT profile should list the allowed algorithm sets when it permits COSE/JOSE protection.
   - In SlopOS Phase 1, accepted signature/message algorithms therefore remain explicit local/profile policy under **D-SIGENV**, **D-KEYLESS**, **I-SIGENV-1**, **I-KEYLESS-1**, **PO-SIGENV-VERIFY**, and **PO-KEYLESS-VERIFY**.

3) **No artifact-selected downgrade/upgrade/negotiation plane in v0.**
   - A signed object does not get to say “pick the strongest algorithm you support”, “fallback to this weaker algorithm if the first one fails”, or “negotiate an equivalent algorithm class”.
   - If multiple signatures are present, each is checked as an exact independent signature record under explicit local allowed-algorithm policy; there is no hidden best-of, strongest-wins, or negotiate-until-one-works rule in Phase 1.
   - Phase 1 adds no native algorithm-negotiation, algorithm-discovery, or algorithm-capability advertisement plane for signature verification.

4) **Library defaults and machine crypto policy are not native substrate meaning.**
   - A deployment may choose to implement its local allowlist/denylist using operating-system crypto policy, FIPS mode, library configuration, or a deployment-local policy bundle.
   - That remains **verifier-local implementation policy**, not portable meaning of `CH-SIGENV` / `CH-ATTEST` / `CH-SBOM` / `CH-VEX` bytes.
   - Two verifiers may therefore see the same signed artifact and reach different admission outcomes if they intentionally adopt different algorithm allowlists.

5) **Certificate algorithm acceptance also stays local and explicit.**
   - For `keyless_cert` signatures, acceptance of the leaf certificate public-key algorithm, certificate-signature algorithm, and chain-signature algorithms remains verifier-local policy alongside trust roots, path inputs, status evidence, and identity checks.
   - A certificate chain carrying a recognized algorithm OID does **not** by itself authorize that algorithm in this deployment.
   - This keeps certificate algorithm acceptance aligned with `certificate-path-input-boundary-v0.md`, `certificate-status-evidence-boundary-v0.md`, `certificate-identity-evidence-boundary-v0.md`, and `signature-trust-root-boundary-v0.md`.

6) **Changing allowed algorithms affects future verification only.**
   - Tightening or widening an algorithm allowlist MAY change how future verification is performed.
   - It MUST NOT rewrite old signed bytes, mutate existing evidence artifacts, or silently turn past verification results into a portable “still approved because policy changed” object.
   - Prior verification outcomes remain tied to the explicit policy/context recorded at the time, or remain intentionally unbound if a profile chose not to record that context.

7) **Sealed compat remains honest.**
   - Compat/import paths that infer algorithm acceptance from ambient host crypto defaults, browser state, JVM security properties, or language-runtime fallback behavior must remain killable by policy and must not create hidden authority via environment variables, host-global config, or implicit network negotiation.
   - A compat path that cannot verify under an explicit algorithm allowlist must fail closed for portable Phase 1 semantics.

8) **No native algorithm inventory / watch / migration plane in v0.**
   - Phase 1 adds no “which algorithms are available?”, “discover stronger algorithm”, “auto-migrate signatures to current best algorithm”, or “watch for allowed-algorithm changes” service.
   - Any future algorithm-agility rollout surface must land as separate RFC-first work with explicit discovery, recording, and evidence hooks.

9) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no new ACP kind, and no conflict-key namespace.
   - It only narrows what algorithm identifiers and algorithm acceptance are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native algorithm-negotiation / capability-advertisement plane for signature verification.
- No artifact-selected fallback / strongest-wins / equivalent-algorithm semantics.
- No portable promise that OS/library/FIPS defaults are the substrate’s algorithm policy.
- No native inventory/watch API for “currently allowed signature algorithms”.
- No automatic signature rewrapping / migration to a newer algorithm class in Phase 1.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, algorithm semantics almost always drift in four expensive directions:

- **Signed metadata starts choosing verifier crypto policy.** `alg` labels, cert OIDs, or bundle hints get treated as if they select the acceptable algorithm set.
- **Library folklore becomes the platform contract.** Whatever OpenSSL / NSS / JCA / language-runtime defaults happen to accept today quietly become native archive meaning.
- **Fallback behavior becomes invisible authority.** Multi-signature records or parser retries start behaving like a hidden negotiation plane.
- **Future agility rewrites history.** Tightening or loosening local algorithm policy gets misread as if it retroactively changed old evidence semantics.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** review tooling can pin a small accepted algorithm set instead of inheriting browser or OS crypto-policy drift.
- **Cloud micro-VM / hosted substrate (B):** admission stacks can align on explicit verifier policy without letting bundles negotiate crypto behavior.
- **Embedded / separation-kernel-ish appliance (C):** appliances can ship tiny fixed allowlists and reject all fallback/negotiation behavior.
- **Agent / automation OS (D):** agents may inspect algorithm identifiers, but they cannot smuggle “use this algorithm policy” selectors inside the signed evidence they want admitted.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/certificate-path-input-boundary-v0.md`
  - `docs/30-architecture/signature-trust-root-boundary-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_signature_algorithm_acceptance_boundary.py` keeps the boundary small and discoverable (**EVID-2026-473**).

## References

- REF-JWS-RFC7515
- REF-JWT-BCP-RFC8725
- REF-COSE-RFC9052
- REF-EAT-RFC9711
