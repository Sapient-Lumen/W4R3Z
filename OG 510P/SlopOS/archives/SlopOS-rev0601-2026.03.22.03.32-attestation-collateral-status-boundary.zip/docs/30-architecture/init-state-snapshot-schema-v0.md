# CH-INIT v0 (initial state snapshot schema, informal)

Purpose: a bounded, canonical description of **time-0** system state relevant to authority and isolation.

Inspired by capDL (seL4) and verified Microkit-to-capDL pipelines.

Phase-1 posture note: `CH-INIT` is a **boot-bound description of time-0 authority only**; it is not the portable meaning of runtime diff/export, warm restore, or mutable desired-state management. See `init-snapshot-posture-v0.md`.

## Constraints
- canonical encoding (I-ENC-1)
- closed enums; no free-form effects
- bounded lists; validation cost is predictable

## Shape (v0)
A snapshot `init` contains:
- `schema`: fixed `CH-INIT v0`
- `profile`: declared profile tag (e.g., `P-PART`, `P-MKERN`, `P-HV`)
- `policy_rev`: monotonically increasing policy revision
- `bindings`:
  - `boot_digest` (optional): digest of CH-BOOT that listed this snapshot
  - `part_digest` (optional): digest of CH-PART (if used)
  - `comp_digest` (optional): digest of CH-COMP (if used)
  - `addrnet_digest` (optional): digest of CH-ADDRNET (if used)
  - `hwfact_digest` (optional): digest of CH-HWFACT (if used)
- `objects`: list of object descriptors (bounded)
  - fields: `{ oid, kind, params }`
  - `kind` is a closed enum: `{ CNode, Endpoint, ASpace, Frame, IRQ, Device, Meter, TCap, Other }`
- `caps`: list of capability edges/grants (bounded)
  - fields: `{ src, dst, cap_kind, rights, derive_from? }`
  - `cap_kind` is a closed enum aligned with `kind`
  - `rights` is a closed bitset aligned with cap semantics
- `maps` (optional, profile-scoped): initial mapping entries, if the profile pins them here rather than via CH-ADDRNET

## Validation obligations (PO-INIT-VALIDATE)
- reject unknown enums/rights
- enforce bounds: max objects/caps/maps per profile
- require all referenced digests (bindings) to match CH-BOOT `artifacts` when present
- check referential integrity: every `src/dst/oid` exists; no dangling edges
- enforce monotonicity rules for `derive_from` (no amplification; aligns with I-CAP-1)

## Installation/match obligations (PO-INIT-MATCH)
- if IF-BOOT uses CH-INIT: the installed initial state must match the snapshot within the declared equivalence (structural or digest-based)
- mismatches fail closed (profile-dependent), and are transcript-logged (CH-LOG)
- runtime create/apply/patch/list/watch/export semantics are intentionally out of scope for CH-INIT v0; any future live snapshot/admin plane must return as a separate RFC-first seam (`init-snapshot-posture-v0.md`)
