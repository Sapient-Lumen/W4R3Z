# SBOM SPDX reference boundary v0 (`SPDXID` / `ExternalDocumentRef` stay document-scoped references, not native cross-artifact identity)

Purpose: pin the Phase-1 meaning of **SPDX element references imported through external SBOM documents** across **D-SBOM**, **D-AREF**, and **D-POLICY** so one SPDX document-local identifier or one `DocumentRef-*` prefix cannot quietly become a portable component-identity root, cross-artifact join key, suppression handle, or fetch/discovery selector.

Entropy cost justification: the archive already keeps CH-SBOM digest-bound, keeps external SBOM documents on exact CH-AREF digests, and already pins component labels like `bom-ref`, `purl`, and `version` to non-native semantics. What remains cheap-but-dangerous is SPDX's own cross-document reference machinery: `SPDXID` values are unique only within one document namespace, and `ExternalDocumentRef` intentionally prefixes references into other SPDX documents. Leaving that relationship unstated invites expensive drift later: imported SPDX references start acting like a native same-component graph, cross-document completeness oracle, or hidden resolver plane. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still point at one external SPDX/CycloneDX document via `external_doc_aref`.
- **CH-AREF v0** may still bind one exact imported document by digest.
- **Verifier-local policy/tooling** may still parse SPDX relationships, `SPDXID` values, and `ExternalDocumentRef` prefixes inside imported documents, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **`SPDXID` stays a document-scoped imported reference only.**
   - SPDX 2.x gives each element an `SPDXID` that is unique within one SPDX document namespace, and external references prepend the external document identifier.
   - Phase 1 therefore treats imported `SPDXID` values as document-scoped reference syntax inside one imported SPDX document context, not as a native SlopOS component identity root.
   - Reusing the same `SPDXRef-*` suffix in a different SPDX document, BOM attachment, or release bundle carries no portable same-component meaning by itself.

2) **`ExternalDocumentRef` stays imported namespace wiring, not a native resolver plane.**
   - An imported `ExternalDocumentRef` may describe a prefix, referenced SPDX document URI, and checksum for another SPDX document.
   - Phase 1 does **not** import a native rule such as “follow this reference automatically,” “resolve this namespace to more evidence,” or “treat one referenced SPDX element as part of the current native evidence closure.”
   - Companion `verification-material-discovery-boundary-v0.md` already pins that finding more evidence must remain explicit and killable rather than ambient.

3) **Exact SBOM/document binding still rides on digests, not SPDX reference syntax.**
   - `external_doc_aref` still binds one exact imported document through **CH-AREF** digest verification.
   - Companion `sbom-document-supersession-boundary-v0.md` already pins that SPDX document namespace and similar document-level identity/version fields do not become a native latest-wins rule.
   - This boundary further pins that element-level SPDX references stay on the same non-native side of the line even when upstream tooling uses them heavily.

4) **No native cross-document SPDX join rule exists in Phase 1.**
   - One imported SPDX relationship, `SPDXID`, or `DocumentRef-*` prefix does not create a native rule such as “same external SPDX element means same component across carriers,” “reference traversal widens applicability coverage,” or “referenced elements join automatically into one inventory.”
   - Any correlation between multiple imported SPDX documents remains verifier-local reasoning rather than carrier-visible semantics.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that several exact evidence artifacts do not become one native closure merely because they travel together.

5) **SPDX reference syntax does not widen suppression, completeness, or remediation meaning.**
   - Matching one imported SPDX element reference to another may help local tooling, but it does not by itself prove global component identity, absence, remediation coverage, or vulnerability suppression.
   - Companion `sbom-bomref-identity-boundary-v0.md`, `sbom-purl-identity-boundary-v0.md`, and `sbom-component-version-boundary-v0.md` already pin adjacent imported-label seams to verifier-local meaning.
   - Phase 1 therefore refuses to let SPDX reference syntax become the back door for a hidden cross-document same-component oracle.

6) **No native fetch/discovery/replacement plane rides on SPDX references.**
   - Imported `ExternalDocumentRef` values, SPDX document URIs, and prefixed SPDX element references do not imply where to fetch more SBOM material, which mirror is authoritative, or whether the current evidence should be replaced.
   - Any such follow-on behavior stays explicit local tooling/policy.
   - Phase 1 adds no native SPDX namespace resolver, document graph crawler, or latest-by-reference workflow.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported SPDX reference syntax fits with existing SBOM/evidence seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `SPDXID` field on CH-SBOM.
- No portable `ExternalDocumentRef` resolver, namespace catalog, or cross-document graph crawler.
- No rule that matching prefixed SPDX element references across imported documents creates native same-component, suppression, completeness, or remediation semantics.
- No import of full SPDX relationship-graph semantics into the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- SPDX 2.3 says the SPDX document namespace must be unique for the specific version of the document and that updated documents get a new namespace.
- SPDX 2.3 says `ExternalDocumentRef` prefixes name another SPDX document URI plus a checksum so current-document elements may reference external elements.
- SPDX 2.3 package/file identifiers are unique within a document and become externally referenceable only by adding the document identifier.
- SPDX 3.x explicitly reworks this area because SPDX 2.3 `ExternalDocumentRef` assumed a particular document/namespace model.

Pinning that split now keeps SlopOS from quietly inheriting “prefixed SPDX reference means native same thing everywhere” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** local scanners may still ingest rich SPDX documents, but one imported element reference cannot silently suppress or widen advisory meaning across apps.
- **Cloud micro-VM substrate (B):** fleet pipelines may attach many third-party SPDX documents, but portable install/applicability semantics stay on exact digests rather than document-graph traversal.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a full external-document SPDX resolver.
- **Agent/automation OS (D):** agents may reason over imported SPDX graphs, but they cannot smuggle “matching prefixed reference means same component” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-AREF**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/sbom-document-supersession-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_spdx_reference_boundary.py` keeps the split small and discoverable (**EVID-2026-492**).

## References

- **REF-SPDX-DOC-NAMESPACE**
- **REF-SPDX-EXTERNAL-DOC-REF**
- **REF-SPDX-ELEMENT-ID-SCOPE**
- **REF-SPDX3-EXTERNALMAP-DIFF**
