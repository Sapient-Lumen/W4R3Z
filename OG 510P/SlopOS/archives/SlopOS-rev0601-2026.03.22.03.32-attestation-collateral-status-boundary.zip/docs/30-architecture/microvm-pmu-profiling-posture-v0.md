# MicroVM PMU/profiling posture v0 (guest-visible perf counters stay non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible PMU and profiling surfaces under `ext.microvm` so virtual PMUs, overflow interrupts, and hardware-tracing folklore do not quietly become a portable reviewed observation/admin plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-OBS**, **D-TRACE**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible PMU/profiling contract under `ext.microvm`; there is no portable PMU-version-counter-width-event-inventory plane, no portable PMI-delivery or guest-programmable PMU-filter/admin plane, no portable `LBR` / `Intel PT` / `PEBS` / `IBS` / `SPE` profiling plane, owner-local vPMU/profiler virtualization stays implementation-local, and reviewed profiling/observation meaning rides on explicit `D-OBS` / `D-TRACE` seams rather than ambient guest counters, interrupts, or trace buffers.**

Entropy cost justification: the archive already keeps observation/export and trace processing explicit, bounded, and killable, but modern VMMs also expose a second profiling path: architectural PMUs, overflow interrupts, event filters, and hardware branch/sample tracing. That is a distinct decision surface from time-source, interrupt-topology, and platform-identity posture because it can quietly smuggle host perf plumbing, profiling policy, and side-channel budget into guest-visible counters and interrupts. One narrow posture closes that gap without inventing a profiler service, guest agent, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible PMU/profiling contract**
   - **Phase 1 exposes no portable ambient guest-visible PMU/profiling contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable architectural PMU version, counter set, overflow-interrupt path, or hardware-tracing facility.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those mechanisms do **not** become SlopOS portable API meaning.

2) **No portable PMU-version / counter-inventory / event-vocabulary plane**
   - There is **no portable PMU-version-counter-width-event-inventory plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable architectural PMU version, number of general-purpose or fixed counters, counter widths, event vocabulary, or capability bitmap that guest code may rely on across runtimes.
   - Owner-local CPU-model shaping, vPMU enablement, and counter virtualization remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable PMI-delivery or guest-programmable PMU-filter/admin plane**
   - There is **no portable PMI-delivery or guest-programmable PMU-filter/admin plane** under Phase 1.
   - Portable reviewed meaning does **not** include one standard overflow-interrupt delivery path, one promise that PMIs are available/accurate, or one guest-visible allow/deny/filter-management contract for programmable PMU events or fixed counters.
   - Owner-local perf-based versus mediated-vPMU choices, PMU disablement, event filters, and interrupt-delivery dependencies remain implementation-local and must not silently become portable lifecycle, scheduling, or profiling semantics.

4) **No portable hardware branch-trace / advanced sampling plane**
   - There is **no portable `LBR` / `Intel PT` / `PEBS` / `IBS` / `SPE` profiling plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest-visible branch-record buffer, packet trace stream, precise-sampling facility, or architecture-specific profiling extension.
   - Owners/runtimes may locally expose one subset, a differently virtualized subset, or no advanced profiling facility at all, but those choices remain implementation-local and must not silently become portable observation or debug semantics.

5) **Reviewed profiling/observation meaning stays on explicit `D-OBS` / `D-TRACE` seams**
   - Reviewed/shareable profiling and observation meaning still rides on explicit `D-OBS` and `D-TRACE` seams and their artifacts rather than ambient guest counters or trace hardware.
   - In plain terms: “how operators collect performance evidence” is a reviewed observation/export question, not a promise that every microVM exposes one stable PMU or branch-trace facility.
   - This keeps profiling killable, redaction-scoped, transcript-visible, and side-channel-budgeted rather than ambient in guest CPU feature probes.

6) **Changing the profiling stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the profiling stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different vPMU or hardware-tracing posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `enable_vpmu`, `set_pmu_filter`, or `attach_branch_trace_sink` control plane by convention.
   - This keeps perf-plumbing and side-channel-budget meaning on the already-pinned activation/observation seams rather than on ambient guest profiling folklore.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed profiling action such as `enable_guest_pmu`, `set_guest_pmu_filter`, or `export_guest_profile_stream` must say whether it commutes with activation, reset, observation export, snapshot capture, and side-channel policy, and where serialization lives.
   - Until then, PMU/profiling remains owner-local runtime/guest convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable PMU version/counter/event inventory contract under `ext.microvm`.
- No portable PMI delivery, PMU enable-disable, or PMU event-filter admin contract under `ext.microvm`.
- No portable `LBR` / `Intel PT` / `PEBS` / `IBS` / `SPE` profiling facility.
- No portable guest-visible profiling inventory or host-side perf-plumbing API.
- No claim that guest PMU counters or hardware-trace buffers are portable attestation, placement, or policy truth.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-OBS, D-TRACE, D-ACTIVATE)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `observation-export-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-35)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-PMUPROF)
- Policy posture:
  - guest-visible PMU/profiling adds **no new lane**, **no portable profiling admin plane**, and **no portable evidence-by-counter/trace-buffer contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_pmu_profiling_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable PMU/profiling / no portable PMU-version-counter-width-event-inventory plane / no portable PMI-delivery or PMU-filter-admin plane / no portable `LBR`-`Intel PT`-`PEBS`-`IBS`-`SPE` profiling plane / owner-local vPMU/profiler virtualization remains implementation-local / explicit `D-OBS` and `D-TRACE` seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-KVM-VPMU-KPARAMS.
- REF-KVM-PMU-CAPABILITY.
- REF-QEMU-ARM-CPU-FEATURES.
- REF-FIRECRACKER-PMU-DISABLED.
- REF-QEMU-CPU-MODELS.
