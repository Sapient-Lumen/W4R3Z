# Adjunct family map (v0)

Purpose: keep **all current `*-adjunct-index.md` docs** visibly classed as closed implementation-facing family surfaces.

Why this exists:
- the archive now depends on multiple companion adjunct indexes to keep build-facing posture clusters rediscoverable,
- once those family surfaces exist, the next subtle drift risk is **coverage at the family layer**: a new `*-adjunct-index.md` can land and even stay individually wired, yet still drop outside one stable human-readable map,
- this map keeps the adjunct-family layer reviewable without inventing a new product surface, schema, or workflow family.

This doc does **not** create new authority semantics.
It is a documentation/control-surface map for archive hygiene only.

## Closed adjunct families

These companion discovery surfaces already own the current implementation-facing posture families:

- [`capshell-adjunct-index.md`](capshell-adjunct-index.md): closed D-CAPSHELL shell/automation posture family
- [`caprpc-adjunct-index.md`](caprpc-adjunct-index.md): closed live D-CAPRPC posture family
- [`lease-adjunct-index.md`](lease-adjunct-index.md): closed leased-authority posture family
- [`microvm-adjunct-index.md`](microvm-adjunct-index.md): closed `ext.microvm` adjunct posture family
- [`portal-adjunct-index.md`](portal-adjunct-index.md): closed direct portal workflow posture family
- [`request-state-adjunct-index.md`](request-state-adjunct-index.md): closed request-identity vs live-state posture family
- [`reqctx-adjunct-index.md`](reqctx-adjunct-index.md): closed request-context posture family
- [`runtime-coordination-adjunct-index.md`](runtime-coordination-adjunct-index.md): closed low-level runtime coordination posture family
- [`secret-authority-adjunct-index.md`](secret-authority-adjunct-index.md): closed secret-bearing authority posture family
- [`trusted-ui-adjunct-index.md`](trusted-ui-adjunct-index.md): closed trusted UI / human-mediation posture family

## Review rule

Before adding a new `*-adjunct-index.md` doc, answer these questions in order:
1) Is this really a **closed implementation-facing posture family** rather than a new schema, registry, or umbrella subsystem?
2) If yes, add the new family index here **in the same revision**.
3) Keep the family-specific checker, `adjunct-index-contract-v0.md`, and the handoff surface aligned in that same revision.

The guardrail for this map intentionally fails closed: every current `*-adjunct-index.md` file under `docs/30-architecture/` must be named here. The adjunct-family map does not classify singleton posture docs; those remain ordinary posture surfaces until they justify paying the entropy cost of one explicit companion family index.
