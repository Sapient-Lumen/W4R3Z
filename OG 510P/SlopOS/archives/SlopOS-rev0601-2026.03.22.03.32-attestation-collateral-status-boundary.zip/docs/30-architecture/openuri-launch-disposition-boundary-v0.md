# D-PLUMB OpenURI launch-disposition boundary v0 (no portable placement / reuse / new-context seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable tab/window/task placement, browsing-context target, named-window reuse, or app-instance reuse/new-instance surface on `portal.uri.*`.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1. **No portable placement / reuse / new-context seam in v0**
   - Phase 1 does **not** export a portable `disposition`, `target`, `window_name`, `current_tab`, `current_window`, `new_tab`, `new_window`, `new_browsing_context`, `reuse_window`, `reuse_tab`, `new_task`, `new_document`, `new_instance`, `launch_bounds`, `split_side`, or equivalent launch-placement/reuse field on `portal.uri.*`.
   - A shell, browser, activity manager, or chosen handler may still place the launch into an existing window, open a new tab, create a new task/document, or prefer a new app instance locally, but those choices remain provider-local rather than portable portal truth.
   - Phase 1 does **not** reinterpret those provider-local choices as a portable requester-visible result, stable receipt, or transcript-stable statement that a specific placement/reuse policy was honored.

2. **Placement and reuse stay provider-local rather than portal truth**
   - Generic OpenURI is about *admission of a mediated launch*, not portable control over browser tabs, named windows, task stacks, split panes, or application-instance reuse.
   - Local UX may still decide placement and reuse according to shell/browser policy, user defaults, window-manager state, or handler internals.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to request or control those placement/reuse decisions on the requester’s behalf.

3. **Why this boundary exists**
   - Existing ecosystems really do expose these knobs. The HTML Standard specifies that `window.open(url, target)` may create a new window and reuse an existing named one. Android documents that intent flags can instruct the system which task an activity should belong to, and that new-document/task flags affect reopen behavior in Recents. AppKit `NSWorkspace.OpenConfiguration` exposes whether to launch a new application instance and whether to use a running instance.
   - Those are valuable local platform APIs, but they are also exactly the kind of product-shaped/browser-shaped/window-manager-shaped semantics that would make `portal.uri.*` drift into an ambient placement broker if imported casually.
   - Pinning the boundary now keeps workstation/browser UX flexible without forcing cloud, embedded, or agent profiles to inherit fake tab/window/task machinery as portable substrate meaning.

4. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Any future placement/reuse seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser tabs, named windows, task stacks, or app-instance launch APIs.
   - Until then, generic `open_uri` remains admission-scoped only; placement and reuse stay hidden inside the provider-local launch implementation.

5. **Launch placement is a second workflow, not generic launch**
   - If SlopOS ever needs reviewed tab/window/task placement or new-instance control, that work should return as a **separate RFC-first workflow/surface** with explicit authority, profile gating, transcript semantics, and policy kill switches.
   - It must not arrive by adding “just one more flag” to generic `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `disposition`, `target`, `window_name`, `new_tab`, `new_window`, `reuse_window`, `new_task`, `new_document`, `new_instance`, or equivalent placement/reuse knob/result on generic OpenURI.
- No transcript-stable statement that a specific tab/window/task/app-instance placement policy was honored.
- No importer-visible browser/window-manager/task-stack folklore on the D-PLUMB seam.
- No shell/helper fallback that quietly promotes `open_uri` into a tab/window/task/app-instance placement workflow and reports that second workflow as generic OpenURI truth.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, agent tooling and CLI wrappers quickly start depending on guessed browser/window-manager semantics like “open this in a new tab,” “reuse the named window,” or “spawn a new instance.” Once those appear in transcripts or shell conventions, they become hard to retract. Pinning the boundary now keeps SlopOS from quietly turning mediated launch into placement/reuse authority. That matters for all four product shapes: workstation UX can still make local placement decisions without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting fake tab/window/task machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to demand browser/window-manager folklore.

## Profile effect (A–D)

- **Secure workstation (A):** shells, browsers, and window managers may still make rich local placement/reuse decisions, but generic OpenURI does not standardize those decisions as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake tab/window/task/app-instance machinery they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising browser-window or task-placement workflows they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with permission to demand new-tab/new-window/reuse-window/new-instance semantics; reviewed placement control stays on explicit future seams.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/llm-runbook.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/intent-kind-registry.md`
- `docs/30-architecture/effect-contract-schema-v0.md`
- `docs/60-engineering/cli-plumbing-tooling.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_openuri_launch_disposition_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable placement/reuse seam / placement and reuse stay provider-local / launch placement is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-590**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-WHATWG-WINDOW-OPEN.
- REF-ANDROID-INTENTS-FLAGS.
- REF-ANDROID-RECENTS.
- REF-APPLE-NSWORKSPACE-CREATESNEWAPPLICATIONINSTANCE.
- REF-APPLE-NSWORKSPACE-RUNNING-APPLICATION-SUBSTITUTION.
