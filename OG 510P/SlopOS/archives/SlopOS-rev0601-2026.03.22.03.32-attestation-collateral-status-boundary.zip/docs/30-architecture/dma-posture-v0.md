# DMA posture (v0)

Purpose: pin the Phase 1 meaning of **DMA-aware isolation** so we do not drift into
hand-wavy “IOMMU optional” claims.

This doc attaches to existing decision+assurance surfaces:
- Decision: **D-DMA** (DMA model)
- Claims: **C-ISO-2** (DMA-aware isolation), **C-DRV-1** (device logic outside core, conditional)
- Invariant: **I-DMA-1** (DMA containment, conditional)
- Proof obligations: **PO-IOLEASE-CONFINE**, **PO-PART-DMA**, **PO-DEVGUARD-ATTACH**
- Assumption: **A-DMA-1** (hardware can enforce DMA translations / isolation as configured)

This is a posture doc (v0): it is intentionally small and it does **not** define an API.

## Posture (v0)

Phase 1 adopts a **fail-closed DMA containment posture**:

1) **If we claim C-ISO-2, the active system MUST be in the `iommu_required` posture.**
   - If the platform lacks a usable IOMMU/SMMU or it is not enabled/configured correctly,
     then **C-ISO-2 is not claimed** (and any “device leasing / hotplug” workflows that
     would rely on DMA containment MUST fail closed).

2) **External DMA-capable peripherals are treated as untrustworthy by default.**
   - DMA-class hotplug/attach flows (see D-DEVGUARD / D-IOLEASE via `portal.device.*`) must
     deny-by-default unless the active DMA posture’s preconditions are satisfied.

   - `portal.device` is the workflow authority seam: device access should not exist as an
     ambient `/dev`-like namespace.

3) **Profiles may explicitly choose weaker postures, but the archive must say so.**
   - We do not silently “kind-of” enforce DMA isolation.
   - Any weaker stance must scope isolation claims accordingly (C-ISO-2 drops to C-ISO-1).

## Phase 1 non-goals (explicitly deferred)

- No v0 wire contract for DMA posture selection (this doc is decision vocabulary only).
- No standardized IOMMU/SMMU programming API yet (that is an implementation plan, not a posture pin).
- No hotplug policy language: attach/lease policy remains a portal/policy bundle detail.


## Posture vocabulary (conceptual; not a CH-* enum)

These names are *decision vocabulary* for D-DMA. They are not yet a wire contract.

### `iommu_required` (Phase 1 default for A/B/D)

Meaning:
- DMA windows are enforced via IOMMU (x86 VT-d / AMD IOMMU) or SMMU (Arm).
- Any action that creates or changes DMA reachability is mediated through explicit
  objects/leases (D-DRVDOM/D-IOLEASE) and must be evidenceable under PO-IOLEASE-CONFINE.

Fail-closed rule:
- If the system cannot establish the required translation/deny state, the workflow must
  deterministically deny (emit a receipt/deny record) rather than “best effort”.

### `devices_in_tcb` (explicitly weaker)

Meaning:
- DMA is not confined by hardware translation for the relevant device set.
- Isolation claims treat those devices as part of the *effective* TCB.

Allowed only when:
- the product shape explicitly scopes claims to C-ISO-1 and treats peripheral inputs as
  trusted (or the system is physically sealed and peripherals are non-hotpluggable).

### `no_dma` (constrained I/O appliances)

Meaning:
- Devices that require arbitrary DMA are not supported.
- Only constrained I/O paths that cannot DMA into privileged memory are permitted.

This posture exists primarily for (C) separation-kernel-ish appliances that can choose
hardware without general-purpose DMA peripherals.

## Composition rules

### With D-DEVGUARD / D-IOLEASE

- `portal.device.*` remains **manual-only in Phase 1** (see `io-lease-posture-v0.md`).
- Under `ext.microvm`, guest-visible VFIO / mediated-device / SR-IOV passthrough meaning is pinned separately as non-portable and non-ambient; owner-local passthrough choices do not bypass D-DMA review or turn guest device presence into the real authority seam (`microvm-device-passthrough-posture-v0.md`).
- Under `ext.microvm`, guest-visible vIOMMU meaning is pinned separately as non-portable and non-ambient; owner-local `virtio-iommu` enablement, endpoint placement, and address-width tuning do not bypass D-DMA review or turn guest remap controls into the real authority seam (`microvm-virtual-iommu-posture-v0.md`).
- Any attach/lease outcome that would allow DMA reachability must be conditioned on
  the active D-DMA posture.
- If `iommu_required` preconditions are not met, the portal must deny-by-default and
  emit a transcript-visible denial/receipt so operators can tell *why* attach failed.

### With D-DRVDOM

Driver domains remain the recommended shape for keeping device logic outside the core.
The DMA posture constrains what “outside the core” can safely mean:
- Under `iommu_required`, driver domains can be granted bounded DMA windows.
- Under `devices_in_tcb`, driver domains do not reduce *DMA* risk; the claim must be scoped.

### Related mechanism: virtio-iommu (optional)

In virtio-first microVM profiles, a guest-visible `virtio-iommu` device can provide an explicit
DMA translation/control seam *inside the guest*. This can reduce device-model complexity for
nested virt and makes guest DMA intent more explicit, but it does **not** replace the host-side
IOMMU/SMMU requirements for physical DMA (see `virtio-iommu-mechanism-note.md`).
The portable meaning of that guest-visible seam is pinned separately: Phase 1 adds no portable ambient guest-visible vIOMMU contract, no portable `virtio-iommu` / domain-endpoint-attach / map-unmap / fault-status / address-width plane, and no live same-leaf mutation surface (`microvm-virtual-iommu-posture-v0.md`).

### With D-PART / static partitioning

If D-PART is enabled and C-ISO-2 is claimed, DMA windows must be partition-scoped
per PO-PART-DMA.

## Evidence hooks (Phase 1 seed)

Phase 1 does not implement IOMMU code yet, but it does pin what must be evidenced:

- **Negative tests**: attempts to attach/lease a DMA-capable device when the active
  posture is not satisfied must deny deterministically (no fallback to “trusted device”).
- **Receipt binding**: denials should carry a stable deny code and bind to the
  relevant portal token / device selection receipt (so “why denied?” is audit-visible).

EVID wiring is tracked under EVID-2026-221.

## Wiring

- Decision surface: `decision-map.md` (D-DMA).
- Claim surfaces: `docs/20-assurance/claim-registry.md` (C-ISO-2, C-DRV-1).
- Related posture: `io-lease-posture-v0.md` (D-IOLEASE; deny-by-default attach/lease workflows).
- Mechanism note: `virtio-iommu-mechanism-note.md` (guest-visible seam; does not replace host IOMMU/SMMU).
- Evidence: EVID-2026-221.
- CI drift gate: `tools/check_dma_posture.py`.

## References

- Intel VT-d (DMA remapping architecture). (REF-INTEL-VTD)
- AMD IOMMU (AMD-Vi) specification. (REF-AMD-IOMMU)
- Arm SMMUv3 architecture specification. (REF-ARM-SMMUV3)
- Thunderclap paper (DMA from untrustworthy peripherals; IOMMU pitfalls). (REF-THUNDERCLAP)
