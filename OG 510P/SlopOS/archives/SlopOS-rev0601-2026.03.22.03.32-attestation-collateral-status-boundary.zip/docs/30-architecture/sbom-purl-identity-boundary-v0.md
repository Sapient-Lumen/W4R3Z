# SBOM/VEX `purl` identity boundary v0 (`purl` stays an imported package label, not a native cross-artifact component identity)

Purpose: pin the Phase-1 meaning of **package URLs (`purl`) imported through CH-SBOM / CH-VEX component evidence** across **D-SBOM**, **D-VEX**, **D-AREF**, **D-ATOMICUPD**, and **D-BOOT** so one package-ecosystem identifier from one toolchain or advisory does not quietly become a portable component-identity root, cross-artifact join key, suppression handle, or applicability oracle.

Entropy cost justification: the archive already pins CH-SBOM / CH-VEX as digest-bound evidence and already prefers exact `content_digest` / `build_id` for portable component binding, but `purl` is attractive because it appears in real SBOM/VEX ecosystems and OpenVEX even recommends it as a product identifier. Leaving that relationship unstated invites expensive drift later: one `purl` string starts acting like “same package therefore same component everywhere”, or tooling silently invents qualifier-dropping / alias / canonicalization rules. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SBOM v0** may still carry optional `purl` per component as imported package-reference evidence.
- **CH-VEX v0** may still carry optional component-scoped `purl` as imported exploitability-scoping evidence.
- **Verifier-local policy/tooling** may still compare, normalize, or otherwise reason over `purl` values, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **`purl` is an imported package label only.**
   - A `purl` in CH-SBOM or CH-VEX records one imported package-style identifier chosen by upstream tooling or an attached external advisory/document ecosystem.
   - Phase 1 therefore treats `purl` as imported evidence syntax for package labeling, not as a native SlopOS component-identity root.
   - Matching `purl` bytes across different SBOMs, VEX artifacts, release bundles, or external documents carries no portable same-component meaning by itself.

2) **Portable component binding still rides on stable exact identifiers when available.**
   - `content_digest` and `build_id` remain the portable component-binding fields under **I-SBOM-2** and the adjacent CH-VEX component-scoping guidance.
   - Companion `sbom-posture-v0.md` already pins `name`, `version`, `purl`, `supplier`, and `licenses` as observational only.
   - This boundary further pins that imported `purl` labels stay on the same non-native side of the line even when ecosystem tooling treats them as preferred package references.

3) **No native cross-artifact `purl` join rule exists in Phase 1.**
   - A CH-VEX statement, CH-SBOM external document, CH-UPD `artifacts[]` set, or CH-BOOT `artifacts[]` set does not gain a portable rule such as “join by matching `purl` strings.”
   - Any correlation between an advisory component claim and an SBOM component via `purl` remains verifier-local imported reasoning, not carrier-visible semantics.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that multiple exact SBOM/VEX artifacts do not become one native applicability closure merely because they travel together.

4) **Phase 1 imports no native `purl` canonicalization / alias / qualifier-elision rule.**
   - Package URL syntax is standardized and type-specific, but real ecosystems still leave room for tool choices around casing, namespace conventions, qualifiers, subpaths, mirror/repository qualifiers, and how package labels relate to exact built bytes.
   - Phase 1 therefore adds no native “drop qualifiers”, “ignore subpath”, “normalize repository URL”, “same type/name/version implies same component”, or “version range matches this exact package instance” rule.
   - Any such comparison logic stays verifier-local and explicit under **D-POLICY** rather than leaking into CH-SBOM / CH-VEX / CH-UPD / CH-BOOT meaning.

5) **`purl` does not widen absence, remediation, or suppression meaning.**
   - Matching one `purl` from one inventory/advisory row to one row elsewhere does not by itself prove global component absence, remediation coverage, vulnerability suppression, or successor-package choice.
   - Companion `vex-component-absence-boundary-v0.md` already pins that `component_not_present` plus one linked inventory does not become a native absence oracle.
   - Companion `vex-remediation-selection-boundary-v0.md` already pins that `fixed` and remediation/action text do not become a native patch-plan or successor-target chooser.
   - Companion `vex-vulnerability-identity-boundary-v0.md` already pins that `vuln_id` is one exact advisory label only; `purl` must not become the back door for a hidden wider suppression graph.

6) **Imported richer package ecosystems stay imported evidence unless another seam admits more.**
   - ECMA-427 defines a shared Package-URL syntax and the purl project maintains type-specific definitions, but those are still package-ecosystem identifiers rather than a native SlopOS proof of exact component bytes.
   - OpenVEX may prefer purl as a product identifier of choice, and CycloneDX tooling often emits purl, but that popularity does not by itself promote purl into privileged-core authority semantics.
   - Companion `verification-policy-selection-boundary-v0.md` still pins that evidence does not choose which comparison / normalization policy is in force.

7) **Exact artifact binding still happens on the existing seams.**
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds the exact subject digest the verifier cares about.
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds that same subject digest.
   - **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, and **PO-AREF-VERIFY** still answer carrier/evidence integrity for the already-pinned cohort.
   - No portable “same component”, “same package instance”, or “same advisory scope” verdict is created merely by co-packaging evidence artifacts that reuse or normalize to similar `purl` strings.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported package labels fit with existing SBOM/VEX/update/boot seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `purl` resolver, canonicalizer, alias graph, or same-component oracle.
- No rule that matching `purl` strings across SBOM/VEX documents creates suppression, completeness, remediation, or applicability semantics.
- No qualifier-dropping / subpath-elision / repository-normalization rule on native seams.
- No import of full package-ecosystem identity semantics into the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- ECMA-427 standardizes Package-URL syntax for identifying software packages and the purl project maintains type-specific definitions.
- OpenVEX explicitly recommends purl as a product identifier choice to help processors match products.
- Once VEX, SBOM, and external-doc attachment are all available, it becomes extremely tempting to treat one convenient package label as the hidden join key for broader policy behavior.

Pinning that split now keeps SlopOS from quietly inheriting “matching `purl` means same component/package instance everywhere” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** local scanners may still ingest rich package metadata, but one imported package label cannot silently suppress or widen advisory meaning across apps.
- **Cloud micro-VM substrate (B):** fleet pipelines may attach many third-party SBOM/VEX artifacts, but portable install/applicability semantics stay on exact digests rather than package-label folklore.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject policies that require a full cross-ecosystem `purl` correlation engine.
- **Agent/automation OS (D):** agents may reason over imported package metadata, but they cannot smuggle “same purl means same component” into native authority semantics.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SBOM**, **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/vex-component-absence-boundary-v0.md`
  - `docs/30-architecture/vex-remediation-selection-boundary-v0.md`
  - `docs/30-architecture/vex-vulnerability-identity-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0091-sbom-artifacts-and-closure-binding.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-SBOM-1**, **I-SBOM-2**, **I-VEX-1**, **I-AREF-1**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-SBOM-BIND**, **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_sbom_purl_identity_boundary.py` keeps the split small and discoverable (**EVID-2026-489**).

## References

- **REF-PURL-SPEC**
- **REF-PURL-TYPES**
- **REF-OPENVEX-SPEC**
- **REF-CYCLONEDX-OVERVIEW**
