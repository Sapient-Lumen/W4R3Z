# Provenance-required subject boundary v0 (local policy may require provenance only for exact already-pinned cohort digests)

Purpose: pin the Phase-1 **verifier-side required-subject boundary for CH-PROV** across **D-PCP**, **D-ATOMICUPD**, and **D-BOOT** so stricter local policy can require provenance over exact staged/booted digests without turning broader provenance subject sets into a second install/boot language.

Entropy cost justification: the archive already says provenance is digest-bound evidence and that attached evidence appraises an already-pinned cohort, but one expensive ambiguity remains: whether local policy must accept every `subjects[]` entry as equally authoritative, whether a verifier may require only a bounded exact subset, and whether extra provenance subjects can quietly become additional install/boot meaning. One narrow boundary buys that down without inventing a new schema field, new workflow, or new verifier API.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how already-pinned seams fit together:
- **CH-UPD v0** or **CH-BOOT v0** answers *which exact digests are already under consideration for install/boot*.
- **CH-PROV v0** answers *how exact subject digests were produced*.
- **Verification/appraisal policy** still answers *which exact staged/booted digests must have provenance before a local verdict may pass*.

## Posture (v0)

1) **Verifier-local required provenance subjects are chosen from already-pinned carrier digests only.**
   - The candidate universe for required provenance subjects comes from the exact digests already pinned by the carrier artifact under review.
   - For **CH-UPD v0**, that means the exact `target_root_digest`, exact `cfg_digest`, and any exact adjunct digests already pinned in `artifacts[]` that local policy marks provenance-relevant.
   - For **CH-BOOT v0**, that means the exact `cfg_digest` plus any exact booted artifact digests already pinned in `artifacts[]` that local policy marks provenance-relevant.
   - Phase 1 therefore rejects the shortcut “whatever extra subjects appear in provenance are now part of the required install/boot set”.

2) **Exact digest matching is authoritative; names and roles stay selectors only when local policy maps them to already-pinned digests.**
   - A verifier may use role labels like `kernel`, `init`, `recovery_root`, or `cfg` as an owner-local convenience for choosing which already-pinned digests must appear in CH-PROV.
   - The authoritative requirement is still the resulting exact digest set, not the label text, filename, package name, or release slug.
   - `subjects[].name` in CH-PROV remains observational metadata only.

3) **Local policy may require a bounded exact subset, not “all provenance subjects” by default.**
   - A strict profile may require provenance over the staged deployment root and config only, or over those plus exact pinned adjunct digests such as `recovery_root`, `kernel`, or `init`.
   - A lighter profile may require provenance over only the one deployment/root digest under review.
   - Phase 1 adds no rule that every CH-PROV `subjects[]` member must correspond to the install/boot cohort, and no rule that every carrier-pinned digest must always appear in provenance.

4) **Extra provenance subjects remain extra evidence context unless local policy independently pinned those exact digests.**
   - A CH-PROV statement may legitimately describe one reviewed build/release cohort containing more outputs than the verifier currently cares about.
   - Those extra subjects may remain useful evidence context for audit, reproduction, or release review.
   - They do **not** become additional required install/boot members, and they do **not** broaden what CH-UPD or CH-BOOT means.

5) **Missing any required exact digest binding fails closed; extra bindings do not broaden install or boot meaning.**
   - If local policy requires provenance over an exact staged/booted digest and the verified CH-PROV subject set does not include that digest, the provenance check fails under **PO-PROV-BIND**.
   - If CH-PROV includes additional exact subjects beyond the required set, those bindings remain additional evidence only.
   - Success therefore means “all locally required exact carrier-pinned digests were covered”, not “the full provenance statement defines the install/boot cohort”.

6) **No implicit fetch, closure, or recursive subject-discovery semantics.**
   - Required provenance subjects are taken from already available exact carrier digests plus explicit local policy.
   - Phase 1 adds no native “discover all transitive subjects”, “follow bundle membership”, “infer required digests from builder metadata”, or “query a release catalog for the rest of the cohort” behavior.
   - Any richer closure reasoning remains external tooling and must not silently affect privileged admission semantics.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how verifiers choose required provenance subject digests around existing boot/update/provenance seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `required_subjects` field inside CH-UPD, CH-BOOT, or CH-PROV.
- No rule that all `subjects[]` in CH-PROV automatically become required for admission.
- No label-only, filename-only, or release-name-only provenance requirements.
- No recursive release-closure or transitive subject-discovery semantics on the native seam.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The adjacent ecosystems are explicit about digest-scoped subjects and verifier-side matching:
- in-toto Statements bind attestations to a set of immutable subject artifacts identified by digest;
- SLSA verification guidance tells consumers to verify the statement subject matches the artifact in question;
- TUF target metadata tells clients which target files they may trust/fetch, but those target sets do not force unrelated attached evidence to become required by default.

Pinning that split now keeps SlopOS from drifting into “all provenance subjects are install subjects” or “all bundle neighbors are provenance requirements” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** profiles can require provenance over the exact boot/update cohort they care about without turning bigger release attestations into surprise install scope.
- **Cloud micro-VM substrate (B):** fleet policy can demand provenance over exactly the promoted deployment root, config, and selected adjunct digests while ignoring irrelevant sibling outputs in the same release attestation.
- **Embedded / separation appliance (C):** small offline verifiers can stay deterministic because required provenance coverage is chosen from already-pinned digests only.
- **Agent/automation OS (D):** agents can reason over large provenance statements without smuggling broader multi-subject release meaning into local install/boot authority.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-ATOMICUPD**, **D-BOOT**.
- Adjacent meaning pins:
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-PROV-CHAIN-1**, **I-ATOMICUPD-1**, **I-BOOT-1**.
  - **PO-PROV-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_provenance_required_subject_boundary.py` keeps the split small and discoverable (**EVID-2026-478**).

## References

- **REF-IN-TOTO-STATEMENT**
- **REF-SLSA-PROVENANCE**
- **REF-SLSA-VERIFYING-ARTIFACTS**
- **REF-TUF-SPEC**
