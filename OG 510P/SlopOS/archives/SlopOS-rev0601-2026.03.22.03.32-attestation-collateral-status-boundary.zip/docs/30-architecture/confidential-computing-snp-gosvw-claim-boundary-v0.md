# D-CC SNP GOSVW claim boundary v0 (guest-visible-workarounds blob is exact evidence, not portable feature/profile meaning)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `GOSVW` / guest-visible workarounds** so a hypervisor-provided workaround blob does not quietly become a portable SlopOS feature vector, compatibility tier, machine-class label, or hidden approval shortcut.

Entropy cost justification: the archive already pinned the first D-CC provider target, one exact 64-byte binder contract, the SNP certificate-source rule, the SNP VMPL-mode cut, imported embedded-EAT claims, and the main provider-native SNP report-field seams around host data, launch identity, TCB state, policy, report identity, chip identity, platform information, guest SVN, launch measurement, report/firmware version metadata, and signer metadata. What remained ambiguous was a different but equally drift-prone seam: **SNP also carries a guest-visible `GOSVW` blob whose value is supplied by the hypervisor and whose format AMD explicitly leaves hypervisor-defined, while QEMU exposes that same field as a launch property named `guest-visible-workarounds`**. One small boundary closes that gap without inventing a portable workaround registry, feature taxonomy, or compatibility handshake plane.

## Posture (v0)

1) **`GOSVW` is exact provider-native guest-context evidence, not portable SlopOS feature/profile meaning**
   - AMD’s SNP firmware ABI says `GOSVW` is a hypervisor-provided value that indicates guest-OS-visible workarounds, and that **the format is hypervisor defined**.
   - The firmware stores that value in guest context and also exposes it to the guest in the secrets page.
   - Phase 1 therefore treats `GOSVW` as **exact provider-native evidence bytes only**. It does **not** become a native `CH-ATTEST` field, a portable SlopOS capability vector, a normalized runtime feature/profile label, or a reviewed cross-provider workaround taxonomy.

2) **`GOSVW` does not define one portable workaround registry, machine class, or compatibility tier**
   - QEMU exposes `GOSVW` as the `guest-visible-workarounds` launch parameter and describes it as a 16-byte base64-encoded blob corresponding to the SNP firmware ABI parameter.
   - Because AMD leaves the format hypervisor defined, Phase 1 declines any built-in rule that the bytes encode one portable workaround catalog, one cross-provider “guest class”, or one SlopOS compatibility tier.
   - Equal or allowlisted `GOSVW` values therefore do **not** imply that two guests share one portable runtime profile, device contract, or approval lane.

3) **`GOSVW` does not substitute for boot/provenance binding, exact report-data binding, or freshness**
   - `GOSVW` bytes do **not** redefine which `CH-BOOT` / provenance bundle was admitted, do **not** replace exact `cc_report_data_v0` binding, and do **not** prove freshness.
   - A verifier MUST still check `boot_digest == digest(CH-BOOT)`, optional `prov_digest`, exact `cc_report_data_v0`, and explicit freshness on their own terms.
   - In particular, `GOSVW` MUST NOT become a hidden nonce, rollout selector, session key, or substitute proof that the exact D-CC binder contract was satisfied.

4) **Any appraisal of `GOSVW` remains explicit verifier-local or owner-local policy**
   - A deployment-specific verifier, owner-local release controller, or guest policy component MAY preserve or compare exact `GOSVW` bytes when doing provider-specific rollout or compatibility checks.
   - That appraisal remains **explicit local policy** under D-POLICY and D-AREF rather than a portable SlopOS default, a native compatibility taxonomy, or a hidden approval rule.
   - Exported receipts or transcripts may record exact `GOSVW` bytes or the policy digest that judged them, but naming them does not force another verifier or guest to adopt the same interpretation.

5) **Packaging/export does not upgrade `GOSVW` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP bytes or side evidence that preserves `GOSVW`.
   - If tooling wants to retain decoded `GOSVW` values for audit, owner-local compatibility checks, or launch-forensics, it SHOULD do so as exact supporting evidence (for example via `CH-AREF` or verifier-local artifacts) rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable workaround schema.
   - Carrying or exporting exact `GOSVW` bytes does not imply that remote consumers may treat them as reviewed SlopOS-native capability/profile meaning.

6) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing provider-native SNP launch/guest-context field.
   - It introduces no new workflow kind, no workaround-discovery API, no capability-negotiation plane, and no portable workaround registry.

## Phase 1 non-goals (explicitly deferred)

- No `gosvw` field in `CH-ATTEST v0`.
- No portable SlopOS workaround registry, machine-class taxonomy, or compatibility tier derived from SNP `GOSVW`.
- No portable parser/negotiation rule that lets artifacts or guests choose semantics via `GOSVW`.
- No new workflow / ACP / conflict-key family for workaround discovery or approval in v0.

## Why this boundary exists

The archive had already fixed most of the obvious SNP trust seams, but one easy implementation shortcut remained:
- AMD says `GOSVW` is supplied by the hypervisor,
- AMD also says the format is hypervisor defined,
- QEMU exposes the same bytes directly as a launch property named `guest-visible-workarounds`,
- and guest/runtime tooling naturally wants to treat “guest-visible workaround blob” as a compact feature/profile signal.

Without one explicit rule, Phase 1 code would likely drift into one of these by convention:
- treating exact `GOSVW` values as a portable SlopOS feature vector or compatibility tier,
- using the blob as a hidden rollout/approval selector,
- inferring one portable runtime/device profile from a provider-local workaround encoding,
- or silently letting guest-visible workaround bytes choose which parser/policy semantics are in force.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, exact `cc_report_data_v0`, and explicit verifier-local policy**, 
- **SNP `GOSVW` remains exact provider-native evidence unless explicit local policy says more**,
- **`CH-ATTESTPACK` stays an evidence carrier rather than a portable workaround or capability schema**,
- and **automation cannot inherit a hidden provider-specific feature/profile lane through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact `GOSVW` bytes for audit or hosted-secret release without importing one provider’s workaround blob as the workstation’s native capability or compatibility contract.
- **Cloud micro-VM substrate (B):** hosted-compute verifiers and launch tooling may compare exact `GOSVW` bytes under explicit local rollout policy, but they do not get a portable SlopOS machine-class or approval taxonomy from one hypervisor-defined blob.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling can retain exact `GOSVW` bytes for audit without importing cloud-provider workaround encoding as the appliance’s native attestation/profile semantics.
- **Agent / automation OS (D):** agents can inspect exact `GOSVW` bytes, but they do not get a silent “workaround blob matched, therefore approved” shortcut; any such appraisal remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc is a **member of the closed D-CC companion family** indexed by `confidential-computing-boundary-index.md`.
It is therefore **not** an intentional singleton under `boundary-family-map.md`.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-boundary-index.md`
  - `confidential-computing-reference-target-boundary-v0.md`
  - `confidential-computing-snp-platform-info-claim-boundary-v0.md`
  - `confidential-computing-snp-version-metadata-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_gosvw_claim_boundary.py` (**EVID-2026-551**).

## References

- REF-AMD-SNP-FWABI.
- REF-QEMU-AMD-MEMENC.
