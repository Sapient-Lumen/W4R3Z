# Adjunct-index contract (v0)

Purpose: keep every closed companion `*-adjunct-index.md` doc structurally reliable as a compact implementation-facing discovery surface.

Why this exists:
- the archive now depends on multiple adjunct-family indexes to reduce amnesia around build-facing posture clusters,
- once those indexes exist, **existence alone is not enough**: a future revision can leave an adjunct index present but thin, under-enumerated, or missing the same-revision review rule that keeps the cluster closed,
- this contract keeps adjunct-family indexes crisp without inventing a new product surface, schema, or workflow family.

This doc does **not** add a new schema, workflow, or decision surface.
It is an archive-hygiene contract for implementation-facing companion discovery surfaces only.

## Contract

Every current companion adjunct-index doc under `docs/30-architecture/` must:
- state a clear `Purpose:` and `Why this exists:` so the family-level entropy cost is explicit,
- include `## Inclusion rule`, one closed-set section whose heading begins with `## Closed`, `## Review rule`, `## Wiring`, and `## Evidence hook`,
- enumerate the current family members **explicitly** with direct markdown links inside that closed-set section rather than relying on filename wildcards or prose like “and related posture docs”,
- list at least two current member docs in that closed-set section so the surface really is a family index rather than a singleton,
- state that the index itself does **not** add a new schema, workflow, or decision surface,
- require same-revision maintenance: if a new family member lands, the companion index must be updated in the same revision.

The member set must be a tightly bounded adjunct posture family whose value is implementation-facing recovery rather than a new umbrella subsystem. The key requirement is that the family stays **closed, explicit, and reviewable**.

## Non-goals

- This contract does **not** decide which adjunct families should exist; that cost is paid in each adjunct index itself.
- This contract does **not** replace family-specific drift gates; it keeps their common structure honest.
- This contract does **not** authorize wildcard discovery, hidden inheritance, or “close enough” membership by prose implication.

## Review rule

Before adding or heavily rewriting any companion `*-adjunct-index.md` doc, answer these questions in order:
1) Is this really a **closed implementation-facing discovery surface** rather than a new schema, registry, or workflow family?
2) Does the index enumerate every current family member explicitly in its closed-set section?
3) Does it keep the inclusion/review/wiring rules readable enough that future passes can update it in the same revision as any member change?

If the answer to (1) is yes, keep the adjunct-index contract and the family-specific drift gate aligned in that same revision.
