# MicroVM NUMA-topology posture v0 (no portable ambient guest-visible NUMA / proximity-domain contract)

Purpose: pin the **Phase 1** meaning of guest-visible NUMA / proximity-domain topology under `ext.microvm` so NUMA nodes, SLIT/HMAT locality tables, and memory-side cache hints do not quietly become an ambient host↔guest placement or compatibility plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible NUMA / proximity-domain contract under `ext.microvm`; there is no portable guest NUMA-node / CPU-to-node / memory-to-node plane, no portable SLIT-distance or HMAT latency-bandwidth-memory-side-cache plane, owner-local locality shaping stays implementation-local, and reviewed memory / CPU / placement meaning still rides on already-pinned explicit admission / topology seams rather than ambient guest locality tables.**

Entropy cost justification: the archive already fixes guest-visible RAM and CPU topology at admission, keeps firmware-description meaning narrow, and refuses ambient host↔guest control channels. What remained loose was the cross-cutting locality layer where modern VMMs can expose guest NUMA nodes, node distances, memory-side caches, and heterogeneous-memory hints. One narrow posture closes that gap without inventing a scheduler, placement API, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible NUMA / proximity-domain contract**
   - **Phase 1 exposes no portable ambient guest-visible NUMA / proximity-domain contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable guest NUMA vocabulary, one stable proximity-domain inventory, or one portable locality matrix across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable guest NUMA topology exists with stable locality semantics.”

2) **No portable guest NUMA-node / CPU-to-node / memory-to-node plane**
   - There is **no portable guest NUMA-node / CPU-to-node / memory-to-node plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest NUMA-node inventory, one stable CPU-to-node assignment story, one stable memory-zone or memory-range-to-node story, one stable CPU-less-memory-node vocabulary, or one stable guest-visible NUMA hot-add / hot-remove / reshape contract.
   - Implementations may locally expose guest NUMA nodes or related placement hints, but those choices do **not** become SlopOS portable interface meaning.

3) **No portable SLIT-distance or HMAT latency-bandwidth-memory-side-cache plane**
   - There is **no portable SLIT-distance or HMAT latency-bandwidth-memory-side-cache plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guest-visible distance matrix, one stable latency or bandwidth hint matrix, one stable memory-side-cache description, one stable heterogeneous-memory tier vocabulary, or one stable ACPI locality-hint contract derived from SLIT / HMAT style tables.
   - Guest software may observe one implementation's locality tables locally, but those observations remain implementation-local facts rather than portable reviewed API meaning.

4) **Owner-local locality shaping stays implementation-local**
   - **Owner-local locality shaping stays implementation-local**.
   - Owners/runtimes may locally shape locality through NUMA layout, memory-zone placement, host-node affinity, CPU grouping, or firmware-table construction, but those choices do **not** create a portable reviewed promise about one guest-visible locality matrix or one memory-tiering story.
   - In particular, owner-local NUMA fitting, distance tuning, HMAT cache/latency/bandwidth hints, and related placement policy remain implementation-local rather than portable microVM meaning.

5) **Reviewed memory / CPU / placement meaning stays on explicit admission / topology seams**
   - **Reviewed memory / CPU / placement meaning stays on explicit admission / topology seams rather than ambient guest locality tables**.
   - Portable reviewed meaning still rides on the already-pinned RAM and CPU topology postures plus explicit activation/admission evidence, not on guest-visible NUMA tables being present.
   - If a later design wants portable guest NUMA/topology mutation, portable locality matrices, or guest-visible heterogeneous-memory semantics, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

6) **No new NUMA locality control plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest NUMA configuration or locality export, **no new ACP kind**, and **no new conflict-key family** for guest NUMA topology mutation.
   - Changing reviewed guest-visible CPU or memory shape remains a new admission / activation choice rather than a portable in-place NUMA-admin workflow.

## Phase 1 non-goals (explicitly deferred)

- No portable guest NUMA-node / proximity-domain inventory for `ext.microvm`.
- No portable SLIT distance or HMAT latency/bandwidth/cache semantics.
- No portable guest-visible memory-tier / heterogeneous-memory contract.
- No portable guest NUMA reshape / locality-admin / locality-status workflow.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-firmware-description-posture-v0.md`
  - `memory-locality-authority-boundary-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-48)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-NUMA)
- Policy posture:
  - guest-visible NUMA/locality tables add **no new lane**, **no public locality-control/status plane**, and **no portable in-place topology-mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_numa_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable guest NUMA-node-CPU-memory plane / no portable SLIT-HMAT-latency-bandwidth-memory-side-cache plane / owner-local locality shaping stays implementation-local / explicit admission-topology seams remain authoritative / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-NUMA-HMAT.
- REF-LIBVIRT-DOMAIN-XML.
- REF-CHYP-MEMORY.
- REF-ACPI-HMAT.
