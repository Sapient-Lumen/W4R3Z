# MicroVM host-management API posture v0 (control APIs stay non-portable)

Purpose: pin the **Phase 1** meaning of host-side VMM control APIs under `ext.microvm` so monitor sockets, REST endpoints, and orchestration helpers do not quietly become a portable reviewed lifecycle/config/inspection/control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-OBS** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host-side microVM management API contract under `ext.microvm`; there is no portable monitor/QMP/REST/D-Bus control plane, no portable lifecycle-config-mutation plane, no portable VM-info-events-counters plane, owner-local API socket/path/transport/auth setup stays implementation-local, and reviewed lifecycle/observation/topology/snapshot meaning still rides on already-pinned explicit seams rather than ambient VMM control endpoints.**

Entropy cost justification: the archive already pins many guest-visible and host↔guest surfaces individually, but mainstream microVM stacks still centralize enormous authority in their host-side management APIs. QMP, Firecracker’s API socket, and Cloud Hypervisor’s REST/D-Bus frontends all bundle lifecycle operations, topology changes, information queries, and runtime control in one operator-facing surface. One narrow posture closes that gap without inventing a SlopOS orchestration API, scheduler protocol, or new schema family.

## Posture (v0)

1) **No portable ambient host-side microVM management API contract**
   - **Phase 1 exposes no portable ambient host-side microVM management API contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf comes with one stable monitor socket, one stable REST base path, one stable D-Bus service/object path, or one stable external "operator can always call this" API vocabulary.
   - Implementations may expose whatever one owner-local runtime chooses to expose, but those control endpoints do **not** become SlopOS portable API meaning.

2) **No portable lifecycle-config-mutation plane**
   - There is **no portable lifecycle-config-mutation plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable create/boot/pause/resume/shutdown/reboot contract, one stable machine-config update contract, one stable attach/detach or hotplug command family, one stable snapshot/load/migrate command family, or one stable host-triggered rate-limit / resource-tuning API.
   - Owner-local QMP/REST/D-Bus actions for lifecycle handling, configuration mutation, topology changes, or snapshot orchestration remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable VM-info-events-counters plane**
   - There is **no portable VM-info-events-counters plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable VM-info / state / counter / metrics contract, one stable event-stream vocabulary, one stable task/job progress stream, one stable management-side inventory of attached resources, or one stable “operator-read API truth” for readiness, topology, or policy state.
   - Owner-local info, counters, event monitors, and management inventories remain implementation-local and must not silently become portable readiness, audit, scheduling, or policy truth.

4) **No portable API socket/path/transport/auth contract**
   - There is **no portable API socket/path/transport/auth contract** under Phase 1.
   - Portable reviewed meaning does **not** include one stable Unix-socket path, one stable TCP/TLS exposure story, one stable character-device monitor backend, one stable D-Bus service name, or one stable external authentication/authorization wrapper for VMM control.
   - Owner-local control-socket placement, transport choice, process topology, ACL model, and confinement strategy remain implementation-local and must not silently become portable deployment semantics.

5) **Existing explicit seams remain authoritative**
   - Reviewed lifecycle meaning still rides on explicit `D-ACTIVATE` supervision and the already-pinned lifecycle-signal posture rather than ambient host monitor or REST commands.
   - Reviewed observation meaning still rides on explicit `D-OBS` exports, crash/inspect artifacts, and already-pinned observation surfaces rather than management-side `vm.info`, event streams, or counter endpoints.
   - Reviewed topology meaning still rides on already-pinned memory/CPU/network/block/bus/interrupt postures rather than ambient “the host API can resize/attach/rewrite it” stories.
   - Reviewed snapshot/restore meaning still rides on the already-pinned warm-start, lineage, and repair-barrier postures rather than an ambient “the VMM API said resume succeeded so continuity is portable” story.

6) **Changing the management-API stance is owner-local orchestration policy or new admission, not a portable live admin plane**
   - Changing the management-API stance is owner-local orchestration policy or new admission, not a portable live admin plane.
   - If policy cares about a different control surface, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `qmp_command`, `call_vm_api`, `subscribe_vm_events`, `resize_vm`, or `pause_and_snapshot` plane by convention.
   - This keeps microVM control meaning on already-pinned activation/observation/topology seams rather than on ambient VMM control endpoints.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `pause_vm`, `resume_vm`, `resize_vm`, `attach_disk`, `stream_vm_events`, or `fetch_vm_metrics` must say whether it commutes with activation, observation export, topology policy, snapshot/restore policy, and attestation freshness, and where serialization lives.
   - Until then, host-side management APIs remain owner-local runtime conventions rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable QMP / HMP / Firecracker REST / Cloud Hypervisor REST / Cloud Hypervisor D-Bus contract under `ext.microvm`.
- No portable host-triggered lifecycle/configuration mutation plane.
- No portable VM info / event stream / metrics / counters truth contract.
- No portable API-socket path / monitor backend / service-name / external-auth wrapper contract.
- No claim that VMM management APIs are an acceptable portable substitute for explicit D-ACTIVATE / D-OBS / D-XS seams.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-OBS)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `microvm-lifecycle-signal-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `microvm-block-topology-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-42)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-MGMTAPI)
- Policy posture:
  - host-side VMM control adds **no new lane**, **no portable external control endpoint**, and **no portable management-truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_management_api_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable host-side management API / no portable monitor-QMP-REST-D-Bus plane / no portable lifecycle-config-mutation plane / no portable VM-info-events-counters plane / owner-local API socket-path-transport-auth setup remains implementation-local / explicit lifecycle-observation-topology seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QMP-SPEC.
- REF-QEMU-SECURITY.
- REF-FIRECRACKER-ACTIONS.
- REF-CHYP-API.
