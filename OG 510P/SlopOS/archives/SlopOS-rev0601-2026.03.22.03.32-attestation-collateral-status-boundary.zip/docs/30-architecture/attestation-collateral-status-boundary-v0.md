# Attestation collateral-status boundary v0 (explicit local collateral status inputs; no ambient collateral chase or latest-collateral authority)

Purpose: pin the **Phase 1** meaning of attestation **collateral status / freshness artifacts** across **D-ATTEST**, **D-AREF**, and **D-NETLEASE** so attestation verification does not quietly inherit vendor-API liveness, cache-refresh folklore, or “latest collateral wins” semantics.

Entropy cost justification: `attestation-endorsement-boundary-v0.md`, `attestation-freshness-boundary-v0.md`, `attestation-result-boundary-v0.md`, and `attestation-identity-boundary-v0.md` already pin verifier-local endorsement/reference inputs, freshness/challenge binding, verifier-produced result artifacts, and attester identity claims. The remaining ambiguity is narrower but operationally expensive: real attestation deployments also carry **collateral status artifacts** such as certificate chains, CRLs, OCSP responses, TCB info, QE/QVE/QAE identity blobs, `issueDate` / `nextUpdate` metadata, and cache snapshots. One narrow boundary closes that gap without inventing a native fetch client, cache service, or trust plane.

## Posture (v0)

1) **Collateral status evaluation consumes explicit local evidence and explicit local policy only.**
   - Phase 1 verification may consume certificate-status artifacts, TCB-info / identity artifacts, exact collateral snapshots, and similar sidecar material as supporting evidence.
   - Whether those artifacts are trusted, current enough, applicable, or sufficient remains a verifier-local decision under explicit local policy.
   - Attestation export therefore standardizes **evidence meaning**, not a privileged-core collateral-retrieval algorithm.

2) **Locator fields, service URLs, and `nextUpdate`-style metadata are hints, not an ambient fetch obligation.**
   - `cRLDistributionPoints`, AIA / OCSP locators, vendor service URLs, PCCS / PCS endpoints, and similar pointers may appear in certificate or collateral ecosystems.
   - `issueDate`, `nextUpdate`, `thisUpdate`, `producedAt`, `tcbEvaluationDataNumber`, and similar freshness metadata may help compare exact artifacts.
   - In Phase 1, those fields are **non-authoritative hints only**: they do not create a portable “fetch current collateral now”, “use the highest sequence number”, or “replace local policy with vendor freshness cadence” meaning on D-ATTEST.

3) **CRLs, OCSP responses, TCB-info / identity artifacts, and cache snapshots stay exact evidence, not portable approval or current-trust authority.**
   - A CRL, delta-CRL, OCSP response, TCB info blob, QE/QVE/QAE identity artifact, or cached collateral bundle may be consumed as **exact local evidence** about one certificate / signer / collateral set / time window.
   - Those artifacts do **not** by themselves mean “verified-good”, “approved”, “safe to release secrets”, or “latest truth”.
   - Successful collateral checking therefore stays evidence under local policy rather than a native verdict object.

4) **Freshness, staleness, cache reuse, and soft-fail versus hard-fail remain local policy.**
   - Real ecosystems expose issue/update windows and sequence numbers, but they do not settle one universal rule for responder availability, mirror lag, cache reuse, or stale-but-signed collateral.
   - Phase 1 therefore adds no portable “missing collateral means hard-fail”, “network unavailable means soft-pass”, “highest `tcbEvaluationDataNumber` wins”, or “refresh automatically at `nextUpdate`” rule.
   - If a deployment wants stronger freshness discipline, that still arrives through explicit local policy and explicit existing networking controls.

5) **No native collateral query, refresh, cache, or watch plane in v0.**
   - Phase 1 standardizes no privileged PCCS / PCS / KDS client, no background collateral refresh daemon, no attestation-collateral inventory API, no collateral-status watch channel, and no machine-global “current collateral set” semantics.
   - Any richer retrieval/cache/update service must return RFC-first with its own kill switches, conflict rules, serialization story, and evidence hooks.

6) **Imported collateral does not auto-authorize secret release, admission, or policy selection.**
   - Collateral status artifacts help a verifier appraise evidence; they do not by themselves authorize admission, install, attestation-gated secret release, or verifier-policy selection.
   - Relying-party action still requires explicit local policy over the full evidence set, including boot binding, freshness/challenge handling, and trust-root context.
   - This keeps collateral-status material aligned with `verification-policy-selection-boundary-v0.md` and `verification-verdict-boundary-v0.md` instead of regrowing a hidden approval plane.

7) **No native collateral-status / latest-collateral schema in v0.**
   - Phase 1 may package exact collateral artifacts or exact digest pointers through already-reviewed evidence seams such as **CH-AREF**, release bundles, or verifier-local stores.
   - It does **not** introduce a new native collateral-status schema family, cache-object type, or “current collateral” receipt kind by example.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no ACP action kind, and no conflict-key namespace.
   - It only narrows what existing collateral/status artifacts are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native PCCS / PCS / KDS / OCSP / CRL fetch client or privileged collateral-refresh plane.
- No portable cache-reuse / stale-collateral / soft-fail profile baked into D-ATTEST.
- No app-visible collateral inventory, watcher, or subscription API.
- No native “latest collateral” or “current vendor TCB” object/receipt.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, attestation collateral almost always drifts in one of four expensive directions:

- **Hidden liveness dependence.** A verifier silently chases vendor collateral endpoints and reintroduces ambient network and mutable remote state into a seam the archive already intended to keep killable and explicit.
- **Status artifacts turn into verdict folklore.** A cached TCB info blob or stapled OCSP response gets treated as “therefore approved” instead of one bounded evidence input under local policy.
- **Library or service defaults become platform meaning.** Different quote-verification stacks disagree on cache refresh, stale-response handling, and soft-fail policy; leaving this implicit means one library build or cloud mirror quietly becomes archive contract.
- **Vendor freshness cadence becomes hidden policy.** `nextUpdate` or `tcbEvaluationDataNumber` starts acting like a built-in policy engine instead of one artifact property the relying party may interpret.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** offline review can carry exact collateral/status artifacts without making laptops ambient OCSP / PCCS clients.
- **Cloud micro-VM substrate (B):** fleet verifiers can mirror collateral explicitly while keeping freshness windows, cache reuse, and fallback policy local instead of vendor-service-defined.
- **Embedded / separation-kernel-ish appliance (C):** appliances can ship exact collateral snapshots offline without inheriting a live service dependency.
- **Agent / automation OS (D):** agents may reason over collateral evidence, but they cannot smuggle “vendor collateral currently says okay” authority through workflow surfaces.

This doc is a **family member of the closed D-ATTEST companion boundary family** rooted at `attestation-boundary-index.md`.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATTEST**, **D-AREF**, **D-NETLEASE**.
- Adjacent seams:
  - `docs/30-architecture/attestation-posture-v0.md`
  - `docs/30-architecture/attestation-pack-schema-v0.md`
  - `docs/30-architecture/attestation-endorsement-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
  - `rfcs/0064-confidential-computing-profile.md`
- Engineering / profile surfaces:
  - `docs/30-architecture/interface-registry.md`
- Assurance anchors:
  - **I-ATTEST-1**.
  - **PO-ATTEST-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_attestation_collateral_status_boundary.py` keeps the split small and discoverable (**EVID-2026-613**).

## References

- **REF-RATS-RFC9334**
- **REF-RFC5280-PKIX**
- **REF-RFC6960-OCSP**
- **REF-INTEL-TRUSTEDSERVICES-API**
