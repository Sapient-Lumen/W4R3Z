# D-PLUMB OpenURI verified-association boundary v0 (no portable verified-app-link / associated-domain trust seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable verified-app-link, associated-domain, universal-link trust, or equivalent domain-association routing/control surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable verified-association seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `verified_only`, `require_verified_association`, `require_verified_handler`, `verified_handler`, `verified_match`, `verified_domain`, `domain_verification_state`, `associated_domain`, `associated_domains`, `assetlinks_state`, `apple_app_site_association`, `app_link`, `universal_link`, `prefer_verified_handler`, or equivalent verified-link / associated-domain field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Association state, trust, and route choice stay shell-local or policy-local rather than transcript truth.**
   - A shell, browser, or other handler may use provider-local knowledge such as Digital Asset Links state, an `apple-app-site-association` file, associated-domains entitlements, user defaults, or local policy to decide how a URI should route.
   - Phase 1 does **not** reinterpret that provider-local knowledge as a portable requester-visible receipt, stable support oracle, or transcript-stable statement that a domain-app association was verified, a trusted deep-link route was selected, or an associated-domain rule matched.
   - Generic OpenURI therefore stays launch-oriented rather than becoming a reusable domain-association trust broker for arbitrary URIs.

3) **Verified deep-link trust is a second policy workflow, not generic launch.**
   - Verified-link ecosystems allocate additional semantics: domain ownership proofs, certificate/app-identity binding, path or host matching rules, server-hosted association files, and sometimes dynamically refreshed routing policy.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to query verified-association state, require that only a verified handler may open a URI, or learn that a platform trusted one app-domain association over another.
   - If a future product shape needs reviewed association-aware routing or verified deep-link policy, that belongs on a future RFC-first web/link-association seam rather than as a side effect of generic launch.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. Android App Links use Digital Asset Links statements hosted on a website to establish a secure and verified association between a website and an app, and verified links can open directly in the app without a disambiguation dialog. Android also exposes explicit domain-verification state and, on current releases, even dynamic server-refreshed deep-link rules. Apple universal links use an `apple-app-site-association` file plus a `com.apple.developer.associated-domains` entitlement to establish trust between a website and an app, with explicit path matching and ordering rules.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate extra trust, routing, and verification semantics that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new verified-link / associated-domain action family, conflict-key family, or serialization surface.
   - Any future verified-association seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from platform deep-link APIs.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this URL only if the platform trusts one associated app-domain relationship” behavior through helper fallbacks.
   - If compat needs reviewed association-aware deep-link workflows, it still pays for an explicit future seam rather than smuggling trust/routing authority through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `verified_only`, `require_verified_association`, `require_verified_handler`, `verified_handler`, `verified_match`, `verified_domain`, `domain_verification_state`, `associated_domain`, `associated_domains`, `assetlinks_state`, `apple_app_site_association`, `app_link`, or `universal_link` knob/result on generic OpenURI.
- No portable receipt that a domain-app association was verified, refreshed, selected, matched, or trusted on generic URI launch.
- No portable “only open in a verified associated app” or “fall back to browser if not verified” contract on generic URI launch.
- No portable domain-association query/oracle, deep-link trust policy plane, or verified-route control plane on generic URI launch.

## Why this is worth pinning

The archive already keeps OpenURI free of handler-selection and browser-auth folklore, but one more convenience import still lingers in mainstream deep-link ecosystems: “while you’re opening this URI, can you also tell me whether the platform trusts a website↔app association, or require that only a verified associated app may handle it?” That sounds tidy, but it quietly turns a launcher seam into a domain-association trust broker with verification-state, routing, and server-policy semantics that are much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into verified-link authority. That matters for all four product shapes: workstation UX can still use local deep-link routing without standardizing association state as app-visible substrate meaning; hosted and embedded profiles avoid inheriting fake website↔app trust machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to query or rely on domain-verification state.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still use local verified-link routing, but generic OpenURI does not standardize association-state or verified-route semantics as app-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting ambient website↔app trust state, domain-verification queries, or fake app-link policy machinery they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising associated-domain or verified-deep-link workflows they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “query or require a verified app-domain association for this URI”; reviewed trust/routing control stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_verified_association_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable verified-association seam / association state stays shell-local-or-policy-local / verified deep-link trust is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-588**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-APP-LINKS.
- REF-ANDROID-VERIFY-APP-LINKS.
- REF-APPLE-UNIVERSAL-LINKS.
- REF-APPLE-ASSOCIATED-DOMAINS.
