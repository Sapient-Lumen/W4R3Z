# SBOM boundary index (v0)

Purpose: keep the **closed set of D-SBOM companion boundary docs** enumerable.

Why this exists:
- the archive now pins many small `sbom-*-boundary-v0.md` companions so imported inventory ecosystems do not quietly become native authority,
- those docs are individually crisp but easy to forget piecemeal because they span component/package labels, external document graphs, and cross-artifact evidence closure,
- `sbom-posture-v0.md` keeps the overall meaning of D-SBOM, while this index is the **discovery surface** that says which boundary docs currently make imported SBOM semantics fail closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `sbom-posture-v0.md` and RFC-0091.

## Inclusion rule

A doc belongs here if it removes exactly one tempting imported-inventory meaning from Phase 1 by constraining one of:
- component/package labeling semantics that would otherwise smuggle in a native identity, same-component, trust, remediation-owner, or compliance plane,
- external document/link/graph semantics that would otherwise smuggle in a native fetch, resolver, latest-wins, dependency, or closure plane,
- cross-artifact composition semantics that would otherwise smuggle in a native vulnerability/applicability/completeness closure.

If future work needs a new native control surface instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind imported SBOM metadata.

## Closed companion boundary set (Phase 1)

### 1) Component/package labels stay observational

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`sbom-bomref-identity-boundary-v0.md`](sbom-bomref-identity-boundary-v0.md) | CycloneDX `bom-ref` labels | one imported document-local join label does not become a native cross-artifact component identity, suppression handle, or applicability/completeness oracle | explicit verifier-local document parsing and correlation |
| [`sbom-purl-identity-boundary-v0.md`](sbom-purl-identity-boundary-v0.md) | package URLs | one imported package label does not become a native same-component, suppression, applicability, completeness, or remediation oracle | explicit verifier-local package matching/normalization |
| [`sbom-component-version-boundary-v0.md`](sbom-component-version-boundary-v0.md) | component / subject `version` labels | one imported version string does not become a native same-component, version-ordering, remediation, or suppression rule | explicit verifier-local version reasoning |
| [`sbom-supplier-origin-boundary-v0.md`](sbom-supplier-origin-boundary-v0.md) | supplier / origin / manufacturer labels | imported provenance labels do not become native trust-root, support-owner, or remediation-owner authority | explicit signature/admission/provenance policy |
| [`sbom-license-metadata-boundary-v0.md`](sbom-license-metadata-boundary-v0.md) | licenses / SPDX expressions / license names | imported compliance metadata does not become a native allow/deny, waiver, or obligation rule | explicit verifier-local compliance policy |

### 2) External SBOM document graph stays imported evidence

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`sbom-external-reference-locator-boundary-v0.md`](sbom-external-reference-locator-boundary-v0.md) | SPDX/CycloneDX links and locators | imported SBOM links remain descriptive evidence rather than a native fetch, discovery, resolver, or mirror-selection rule | explicit CH-AREF / portal fetch policy |
| [`sbom-document-supersession-boundary-v0.md`](sbom-document-supersession-boundary-v0.md) | CycloneDX / SPDX document identity and version metadata | imported document revision metadata does not become a native latest-wins, freshness, or replacement rule | explicit verifier-local revision comparison |
| [`sbom-spdx-reference-boundary-v0.md`](sbom-spdx-reference-boundary-v0.md) | SPDX `SPDXID` / `ExternalDocumentRef` syntax | imported SPDX references stay document-scoped evidence rather than a native cross-artifact join or resolver rule | explicit verifier-local SPDX graph navigation |
| [`sbom-spdx-relationship-boundary-v0.md`](sbom-spdx-relationship-boundary-v0.md) | SPDX relationship edges | imported SPDX graph edges stay document-graph evidence rather than a native dependency, closure, completeness, or causality rule | explicit verifier-local graph traversal |

### 3) Multi-artifact closure remains verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`sbom-vex-evidence-set-boundary-v0.md`](sbom-vex-evidence-set-boundary-v0.md) | multiple exact SBOM/VEX attachments | one carrier-linked evidence set does not become a native vulnerability/applicability/completeness closure, fallback rule, or preference order | explicit verifier-local evidence selection |

## Review rule

Before adding another `sbom-*-boundary-v0.md` doc, answer these questions in order:
1) Is the change really a **D-SBOM meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
