# Safe-open / `open_untrusted` boundary index (v0)

Purpose: keep the **closed set of D-PLUMB / D-QUAR / D-EPHEM safe-open companion boundary docs** enumerable.

Why this exists:
- the archive now pins several small `open_untrusted` companion boundaries so safe-open does not quietly regrow into a trust-laundering mini launcher,
- those `open-untrusted-*-boundary-v0.md` docs are individually crisp but easy to forget piecemeal because they span object materialization, export semantics, active-content suppression, and viewer residue,
- `open-untrusted-posture-v0.md` keeps the overall meaning of `intent.kind=open_untrusted`, while this index is the **discovery surface** that says which companion boundaries currently keep safe-open request-local, inert-by-default, and non-laundering.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `open-untrusted-posture-v0.md`, `quarantine-posture-v0.md`, and RFC-0053.

## Inclusion rule

A doc belongs here if it removes exactly one tempting safe-open meaning from Phase 1 by constraining one of:
- subject/materialization behavior that would otherwise smuggle in a hidden bearer-backed reopen shim, live alias, or save-through path,
- export/persistence behavior that would otherwise smuggle in overwrite-in-place, hidden trust laundering, or parentless durable output,
- viewer/runtime behavior that would otherwise smuggle in document-authored code, ambient side effects, or durable host residue outside the disposable.

If future work needs a new native portal/schema/workflow instead, that work must return **RFC-first** as its own decision surface rather than hiding behind `open_untrusted` convenience semantics.

## Closed companion boundary set (Phase 1)

### 1) Exact input stays request-local and non-aliasing

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`open-untrusted-materialization-boundary-v0.md`](open-untrusted-materialization-boundary-v0.md) | safe-open input materialization | one exact `docref` resolves once into a request-local stable input object rather than a live alias/write-through mount back to the source | explicit `portal.file.*` / `portal.xfer.*` export for anything persistent |

### 2) Persistence/export must not launder trust or continuity

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`open-untrusted-export-classification-v0.md`](open-untrusted-export-classification-v0.md) | kept output trust classification | ordinary safe-open export creates a new artifact that remains quarantined by default rather than silently clearing trust | separate explicit sanitize / clear workflow |
| [`open-untrusted-export-destination-boundary-v0.md`](open-untrusted-export-destination-boundary-v0.md) | keep/export destination semantics | ordinary keep/export is fresh-destination-first rather than overwrite-in-place or replace-existing | separate explicit publish / replace step on existing destination seam |
| [`open-untrusted-export-lineage-boundary-v0.md`](open-untrusted-export-lineage-boundary-v0.md) | parent/source linkage for kept output | ordinary kept output records one exact `origin.parent_digest` rather than appearing parentless or inheriting source `docref` continuity by folklore | explicit derived-artifact lineage evidence |

### 3) Viewer/runtime behavior stays inert and residue-bounded

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`open-untrusted-active-content-boundary-v0.md`](open-untrusted-active-content-boundary-v0.md) | document-authored active content / side effects | admitted viewers stay inert-by-default; document-embedded code, fetch, submit, helper-launch, or equivalent side effects do not piggyback on the original request | separate explicit portal / workflow crossing for any follow-on effect |
| [`open-untrusted-viewer-residue-boundary-v0.md`](open-untrusted-viewer-residue-boundary-v0.md) | durable recent-doc / MRU / cache / recovery residue | mere preview/open does not populate durable host residue or reopen surfaces outside the disposable | explicit keep/export or later portal choice for anything durable |

## Review rule

Before adding another safe-open companion boundary doc, answer these questions in order:
1) Is the change really an **`open_untrusted` meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
