# Certificate-identity evidence boundary v0 (explicit local claim interpretation; no universal cert-identity grammar)

Purpose: pin the **Phase 1** meaning of certificate-borne identity material across **D-SIGENV** and **D-KEYLESS** so cert-bearing verification does not quietly import browser / forge / CI-specific identity folklore as portable substrate meaning.

Entropy cost justification: `signature-envelope-posture-v0.md`, `signing-time-evidence-boundary-v0.md`, `certificate-path-input-boundary-v0.md`, and `certificate-status-evidence-boundary-v0.md` already pin signed subject meaning, signing-time evidence, certificate/path inputs, and certificate-status handling. The remaining ambiguity is **identity interpretation itself**: whether SAN forms, distinguished names, custom OID extensions, EKUs, certificate policies, or forge-specific claims define one portable “who signed this / what are they allowed to sign” grammar versus remaining explicit verifier-local policy inputs. One narrow boundary closes that gap without adding a new schema family, directory service, or approval plane.

## Posture (v0)

1) **Certificate identity claims are exact signed evidence inputs, not portable role or approval semantics.**
   - A certificate may carry signed identity-bearing fields and extensions, but in Phase 1 they remain **evidence about what the issuer bound to the key**, not a portable claim that the subject is therefore globally approved, repo-owner-authoritative, or install-authoritative.
   - Successful extraction of those fields still requires explicit verifier-local policy to decide what they mean.

2) **SAN / subject / issuer / custom OID fields are candidate claim carriers, not one universal identity grammar.**
   - RFC 5280 defines several GeneralName forms for `subjectAltName`, allows identity to live in either the subject field and/or `subjectAltName`, and explicitly leaves wildcard SAN semantics to applications.
   - Fulcio’s OIDC mapping guidance likewise shows that different issuers map different claims into different SAN forms and custom OID extensions (email SAN, URI SAN, OtherName SAN, issuer OID, workflow/build OIDs, and more).
   - Phase 1 therefore declines any native “best identity field”, “one true signer string”, “always use CN/SAN/email/repo/workflow”, or “convert all cert identities into one canonical principal string” rule.

3) **EKU / certificatePolicies / custom policy OIDs remain verifier-local admission predicates, not portable signer-class authority.**
   - RFC 5280 says certificate-using applications MAY require particular EKUs and MAY reject certificates that do not present the purpose they expect; it does not define one universal application-policy meaning.
   - Likewise, certificate policies and custom OIDs are issued under PKI rules but only gain admission meaning when an application or verifier policy interprets them.
   - Phase 1 therefore declines any native “code-signing cert means trusted release signer”, “CI workflow OID means approved builder”, or “policy OID means safe to install” shortcut.

4) **Pattern matching and claim canonicalization remain explicit local policy, not substrate meaning.**
   - Cosign’s verification UX is explicit about this split: keyless verification requires the verifier to supply an expected `--certificate-identity` (or regexp) and expected `--certificate-oidc-issuer` (or regexp).
   - Phase 1 therefore adds no native wildcard language, hostname normalization rule, regex dialect contract, URI canonicalizer, repo/workflow slug canonicalization, or case-folding grammar for certificate identities.
   - If a deployment wants exact string match, regex, parsed URI components, or richer issuer-specific extraction, that stays explicit local policy and test coverage rather than portable substrate meaning.

5) **No ambient best-identity selection / repo-owner lookup / forge-API confirmation plane in v0.**
   - Phase 1 standardizes no background query to determine the current repo owner, workflow maintainer, organization membership, forge policy, or CI provider state for a certificate-borne identity.
   - It also adds no machine-global certificate-identity cache, no directory lookup surface, and no hidden “confirm identity with remote hosting service” step.

6) **Interop certificate claims stay out-of-band and digest-bound; no new native certificate-identity schema family in Phase 1.**
   - X.509 certificates, Fulcio-specific OID-bearing certs, extracted claim summaries, or issuer-local policy manifests may be packaged or referenced as exact adjunct artifacts (for example through **CH-AREF** or release bundles), but they remain adjunct evidence rather than a native identity schema family.
   - Phase 1 introduces no native certificate-identity object family by example.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no ACP action kind, and no conflict-key namespace.
   - It only narrows what existing certificate identity material is allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native certificate-identity normalization / canonical-principal algorithm.
- No portable wildcard / regex / URI-component matching grammar for cert identities.
- No repo-owner / organization-membership / forge-policy / workflow-approval lookup plane.
- No machine-global certificate-identity cache or directory service.
- No new native certificate-identity schema family in Phase 1.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, certificate identity almost always drifts in one of four expensive directions:

- **Issuer-specific cert folklore becomes platform meaning.** Fulcio and similar systems encode different providers into different SAN and OID shapes; if SlopOS leaves this implicit, whichever verifier/parser happened to be in one tool quietly becomes archive contract.
- **Policy-bearing extensions become approval shortcuts.** EKU, policy OIDs, workflow fields, or repo hints get treated as “therefore trusted to release/install” instead of remaining explicit local predicates.
- **Pattern-matching convenience becomes substrate semantics.** Wildcards, regexes, URI normalization, repo slug comparisons, or case-folding rules drift from one verifier into a hidden platform grammar.
- **Remote ownership truth leaks back in.** Verifiers quietly call out to hosting providers or identity services to decide whether a certificate identity still “counts”, reintroducing ambient network and mutable external authority into an offline-first seam.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** reviewable offline verification can explain exactly which cert claims matched local policy without calling out to forges or identity providers.
- **Cloud micro-VM / hosted substrate (B):** promotion workers and admission controllers can carry exact local identity policy and claim extraction rules rather than inheriting library defaults or cloud-specific identity folklore.
- **Embedded / separation-kernel-ish appliance (C):** high-assurance profiles can keep signer identity rules tiny and explicit instead of importing broad PKI / directory semantics.
- **Agent / automation OS (D):** LLM-mediated tooling cannot smuggle “the repo owner is currently X” or “this workflow URI obviously means Y” into a proposal surface; exact matching policy stays inspectable.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/certificate-path-input-boundary-v0.md`
  - `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_certificate_identity_evidence_boundary.py` keeps the boundary small and discoverable (**EVID-2026-468**).

## References

- REF-RFC5280-PKIX
- REF-SIGSTORE-FULCIO-OIDC
- REF-SIGSTORE-FULCIO-OID-INFO
- REF-SIGSTORE-COSIGN-VERIFY
