# MicroVM clock-disruption posture v0 (guest precision-time repair is explicit and separate)

Purpose: pin the **Phase 1** meaning of guest-visible precision time under `ext.microvm` so clone/restore hygiene does not drift into a fake “trusted clock continuity” story.

This doc attaches to **D-MICROVM**, **D-NONDET**, and **D-TIMEPROOF** and makes one hard decision explicit:
**guest clone identity repair and guest clock-quality repair are separate, and neither becomes ambient time authority.**

## Posture (v0)

1) **Generation change and clock disruption are orthogonal signals**
   - Guest/user-space repair MUST treat the primary generation witness from `microvm-generation-witness-posture-v0.md` and VMClock’s `disruption_marker` / `clock_status` as **orthogonal**.
   - `vm_generation_counter` / VMGenID answer **“is this a non-unique clone/restore state?”**
   - `disruption_marker` / `clock_status` answer **“is this precision clock calibration still trustworthy?”**
   - Either class of signal may change without the other, so Phase 1 rejects any folklore rule that one signal stands in for both identity repair and clock repair.

2) **Clock-quality repair is explicit and local**
   - If VMClock is present, guest kernels/runtimes that keep local clock refinements or derived deadline caches MUST discard that refinement when `disruption_marker` changes or when `clock_status` becomes `UNKNOWN`, `INITIALIZING`, or `UNRELIABLE`.
   - Generation-witness change alone is not the portable clock-quality test, and broken sessions/network/vsock side effects are never the clock-quality test.
   - Guest software may continue best-effort local scheduling under its own policy, but any precision-time claim that matters to security/correctness waits for a valid post-disruption clock state or an explicit external time seam.

3) **Guest-visible precision clocks are observational, not authority**
   - VMClock and similar guest-visible paravirtual clocks are observational inputs for guest operation; they are **not** themselves a substitute for SlopOS `portal.clock` handles or CH-TIMEPROOF evidence.
   - Under this posture, anti-rollback, token/lease expiry, policy freshness checks, and cross-node ordering claims do **not** become valid merely because a guest can read a synchronized clock after restore/disruption.
   - Authority-bearing time remains on explicit existing seams: `portal.clock`, `portal.clock.timeproof.sample`, owner-local lease enforcement, and other already-declared policy surfaces.

4) **No new host↔guest control plane is created**
   - Phase 1 adds **no** host callback, guest agent, or writable device protocol for “clock resync complete”.
   - VMClock fields are observational only and remain part of the existing `ext.microvm` implementation posture rather than a new SlopOS `CH-*` schema family.
   - If a future management plane wants an externally visible “recalibrate/resync clock” action, it must define its own ACP kind, conflict keys, serialization boundary, and evidence hooks explicitly.

5) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new ACP kind** and **no new conflict-key family** in Phase 1.
   - Any later exposed resync/discipline workflow must say whether it commutes with suspend/resume, lease expiry, or activation and where serialization lives.
   - Until then, ordering stays local to the guest time stack and/or the owner VMM implementation rather than a portable workflow seam.

## Phase 1 non-goals (explicitly deferred)

- No guarantee that every `ext.microvm` implementation exposes VMClock.
- No portable guest NTP / chrony / `systemd-timesyncd` management API.
- No claim that a guest-visible synchronized wall clock is itself a portable proof artifact.
- No live-migration or cross-host time continuity promise beyond what an implementation explicitly documents.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-NONDET, D-TIMEPROOF)
- Adjacent postures:
  - `microvm-profile-posture-v0.md`
  - `microvm-time-source-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `nondet-posture-v0.md`
  - `timeproof-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-CLOCK-DISRUPTION)
- Policy posture:
  - guest-visible clock disruption signals add **no new lane** and **no new ambient host↔guest channel**; authority-bearing time remains on explicit existing seams.

CI drift gate:
- `tools/check_microvm_clock_disruption_posture.py` fails `make lint` if this posture stops being discoverable, loses the **orthogonal signals / discard local refinement on disruption / guest clock is observational only / no new host-agent plane** constraints, or drops its assurance/reference wiring.

## References

- REF-UAPI-VMCLOCK.
- REF-UAPI-VMGENID.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
