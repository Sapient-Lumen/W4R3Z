# MicroVM cache-hierarchy posture v0 (no portable ambient cache hierarchy / cache-QoS contract)

Purpose: pin the **Phase 1** meaning of guest-visible cache hierarchy and host cache QoS under `ext.microvm` so cache descriptors, shared-cache topology, and cache allocation / monitoring knobs do not quietly become an ambient placement, performance, or control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-OBS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient cache-hierarchy / cache-QoS contract under `ext.microvm`; there is no portable guest-visible L1/L2/L3 cache inventory or cache-sharing-topology plane, no portable CAT/CDP/CMT cache-allocation-or-monitoring plane, owner-local cache masking / partitioning / monitoring stays implementation-local, and reviewed CPU / placement / performance meaning still rides on already-pinned explicit admission / topology / observation seams rather than ambient cache descriptors or QoS knobs.**

Entropy cost justification: the archive already fixes guest-visible CPU and memory topology at admission, keeps NUMA / HMAT locality hints non-portable, and refuses host↔guest helper channels as ambient meaning. What remained loose was the cache layer where modern VMMs can describe guest cache-sharing topology while host orchestrators can also shape or monitor cache allocations. One narrow posture closes that gap without inventing a scheduler, QoS API, or new schema family.

## Posture (v0)

1) **No portable ambient cache-hierarchy / cache-QoS contract**
   - **Phase 1 exposes no portable ambient cache-hierarchy / cache-QoS contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable guest cache hierarchy vocabulary, one stable cache-sharing graph, or one portable cache partition/monitor plane across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable cache-descriptor truth or one portable cache-QoS workflow exists.”

2) **No portable guest-visible L1/L2/L3 cache inventory or cache-sharing-topology plane**
   - There is **no portable guest-visible L1/L2/L3 cache inventory or cache-sharing-topology plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable cache-level inventory, one stable cache-id vocabulary, one stable cache-sharing scope (thread/core/module/cluster/die/socket/etc.), one stable CPUID-or-firmware cache-descriptor truth, or one portable “this leaf guarantees this L3/shared-cache layout” contract.
   - Implementations may locally expose cache descriptors or cache-sharing hints, but those choices do **not** become SlopOS portable interface meaning.

3) **No portable CAT/CDP/CMT cache-allocation-or-monitoring plane**
   - There is **no portable CAT/CDP/CMT cache-allocation-or-monitoring plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable vCPU-to-cache-way partition contract, one stable code-vs-data prioritization story, one stable cache-occupancy monitoring contract, one stable cache pseudo-locking workflow, or one stable cache-QoS status/admin surface.
   - Owner-local cache allocation and monitoring stacks may exist, but they do **not** become SlopOS portable product meaning for a running admitted leaf.

4) **Owner-local cache masking / partitioning / monitoring stays implementation-local**
   - **Owner-local cache masking / partitioning / monitoring stays implementation-local**.
   - Owners/runtimes may locally choose cache descriptors, shared-cache topology shaping, resctrl/CAT policy, cache occupancy monitoring, or related performance tuning, but those choices do **not** create a portable reviewed promise about one guest-visible cache hierarchy or one host-side cache-QoS API.
   - In particular, owner-local `smp-cache` settings, CPU-model cache exposure, resctrl cache partitions, cache monitor groups, and pseudo-locking flows remain implementation-local rather than portable microVM meaning.

5) **Reviewed CPU / placement / performance meaning stays on explicit admission / topology / observation seams**
   - **Reviewed CPU / placement / performance meaning stays on explicit admission / topology / observation seams rather than ambient cache descriptors or QoS knobs**.
   - Portable reviewed meaning still rides on the already-pinned CPU topology, NUMA/locality, and observation postures plus explicit activation/admission evidence, not on guest cache descriptors or host cache-allocation controls being present.
   - If a later design wants portable cache hierarchy descriptors, portable cache partition/admin workflows, or portable cache-monitor telemetry, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

6) **No new cache-admin plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest cache description or cache-QoS export, **no new ACP kind**, and **no new conflict-key family** for cache hierarchy mutation or cache allocation / monitoring control.
   - Changing reviewed guest-visible CPU shape or locality meaning still stays on already-pinned admission/topology seams rather than a new cache-admin workflow.

## Phase 1 non-goals (explicitly deferred)

- No portable guest-visible cache hierarchy / cache-sharing-topology contract for `ext.microvm`.
- No portable cache allocation / partition / monitor / pseudo-locking workflow.
- No portable cache occupancy / cache-QoS telemetry contract.
- No portable “same leaf, different cache hierarchy or cache partition now” lifecycle/admin plane.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-OBS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-numa-topology-posture-v0.md`
  - `microvm-platform-identity-posture-v0.md`
  - `cache-topology-authority-boundary-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-49)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-CACHEHIER)
- Policy posture:
  - guest-visible cache descriptors and host cache-QoS knobs add **no new lane**, **no public cache-admin/status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_cache_hierarchy_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable guest-visible L1-L2-L3 inventory-or-sharing plane / no portable CAT-CDP-CMT allocation-or-monitoring plane / owner-local cache masking-partitioning-monitoring stays implementation-local / explicit admission-topology-observation seams remain authoritative / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-SMP-CACHE.
- REF-LIBVIRT-CACHETUNE.
- REF-LINUX-RESCTRL.
