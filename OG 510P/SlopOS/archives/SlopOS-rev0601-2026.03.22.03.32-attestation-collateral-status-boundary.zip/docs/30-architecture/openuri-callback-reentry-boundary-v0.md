# D-PLUMB OpenURI callback-reentry boundary v0 (no portable callback / reentry channel)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch stays a **one-way request with request-local completion**, not a portable callback-URL, deep-link reentry, or redirect-back rendezvous channel on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable caller-specified callback / reentry target in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `callback_url`, `reply_to`, `return_to`, `continue_uri`, `resume_uri`, `redirect_uri`, `x-success`, `x-error`, `x-cancel`, loopback-listener, or equivalent caller-supplied reentry target on `portal.uri.*`.
   - The portable requester truth remains the mediated action + subject only.

2) **Request-local completion stays request-local.**
   - OpenURI outcomes return on the portal request/completion path plus receipts, not by launching the caller back through a second URI open.
   - Phase 1 therefore exports **no** callback token, wakeup handle, resume token, or target-to-caller rendezvous side channel hidden behind `open_uri` success.
   - If a future product shape needs a real round-trip workflow, it must introduce an explicit RFC-first session/auth/workflow seam instead of overloading generic URI launch.

3) **Targets do not gain a portable “call me back” contract.**
   - A chosen handler may of course perform its own platform-local work, but it must not treat Phase-1 OpenURI as a portable authenticated promise that the requester exposed a callback URL, can be resumed later, or is listening on a loopback/deep-link return endpoint.
   - Likewise, requesters do not receive a portable receipt that some downstream callback/reentry happened.
   - Generic mediated launch stays intentionally asymmetric in Phase 1.

4) **Why this cut is honest.**
   - Existing ecosystems really do grow callback/reentry patterns here: `x-callback-url` standardizes `x-success` / `x-error` / `x-cancel` so the callee can return control/data to the caller, and RFC 8252 documents native-app authorization flows that return results through private-use URI schemes, claimed `https` redirects, or loopback-interface redirects.
   - Those are real patterns, but importing them into generic OpenURI would widen `portal.uri.*` from mediated launch into a second rendezvous bus with ambient reentry expectations.
   - SlopOS keeps request completion on the existing request-local portal seam unless and until there is a deliberate RFC-first reason to standardize something richer.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new callback/reentry action family, conflict-key family, or serialization surface.
   - Any future round-trip workflow must state its own conflict keys and commutativity explicitly rather than inheriting folklore from launcher callbacks.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient callback URLs, deep-link reentry contracts, or loopback redirect expectations through host helpers.
   - If compat wants OpenURI, it still goes through `portal.uri.*` or fails closed.

## Phase 1 non-goals (explicitly deferred)

- No portable caller-supplied callback URL, reply URI, continue URI, or resume URI on `portal.uri.*`.
- No `x-success` / `x-error` / `x-cancel`-style result return contract on generic URI launch.
- No loopback-listener / redirect-back / deep-link reentry receipt on OpenURI.
- No ACP/admin/query surface for OpenURI callback or reentry policy.
- No hidden compat/helper fallback that reintroduces callback/reentry out-of-band.

## Why this is worth pinning

Once OpenURI exists, the next tempting convenience import is “how does the callee get back to me?” Productivity ecosystems answer that with x-callback URLs; native-auth ecosystems answer it with custom-scheme, claimed-HTTPS, or loopback redirect URIs. Those imports are often useful, but they are not the same thing as “open this URI”.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a second rendezvous protocol with hidden wakeup/reentry semantics. That matters for all four product shapes: workstation helpers and agents stop depending on callback folklore; hosted/embedded profiles avoid dragging in fake deep-link or loopback semantics just because richer ecosystems use them; and any later round-trip workflow has to pay for its own explicit authority story.

## Profile effect (A–D)

- **Secure workstation (A):** opening a link stays useful without quietly granting apps a portable callback/reentry contract or deep-link rendezvous channel.
- **Cloud micro-VM substrate (B):** guest/tenant tooling can request mediated launch where allowed without assuming host-side loopback, redirect-back, or callback-URL machinery exists.
- **Embedded / separation appliance (C):** deployments without general app-linking ecosystems avoid carrying fake callback/reentry semantics just because mobile/desktop stacks expose them.
- **Agent/automation OS (D):** agents/tools cannot smuggle a second workflow protocol through `open_uri`; durable round-trips remain explicit request/session designs instead of launcher folklore.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
  - `docs/30-architecture/plumb-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/portal-session-posture-v0.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_callback_reentry_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no caller-supplied callback/reentry target / request-local-completion-only / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-577**).

## References

- REF-XDG-PORTAL-REQUEST.
- REF-XCALLBACK-URL.
- REF-RFC8252-NATIVE-APPS.
