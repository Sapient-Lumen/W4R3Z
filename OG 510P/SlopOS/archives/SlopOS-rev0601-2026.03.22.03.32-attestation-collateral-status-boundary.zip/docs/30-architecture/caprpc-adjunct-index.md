# CapRPC adjunct index (closed live CapRPC posture family)

Purpose: keep the current **live CapRPC posture family** recoverable as one closed discovery surface.
Why this exists:
The archive already pins the live-session, promise/pipelining, and oneway notification seams individually, but humans/LLMs should not have to rediscover the current **D-CAPRPC** runtime story by opening several posture docs in sequence when they are trying to understand one worth-coding capability-RPC substrate slice.

This doc does **not** create a distributed object broker, a generic promise/combinator library, a durable mailbox, or a transparent reconnect/session-manager control plane.
It keeps the current **D-CAPRPC** live-session + latency/notification adjuncts closed, enumerable, and reviewable as one implementation-facing surface for shapes **A/B/D** while leaving restore/import (`capx-posture-v0.md`, `sturdyref-posture-v0.md`), turn discipline (`turns-posture-v0.md`), and replication/topology boundaries (`caprpc-proxy-replication-boundary-v0.md`) explicitly separate.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is `caprpc-session-posture-v0.md`, `caprpc-promise-posture-v0.md`, `caprpc-oneway-posture-v0.md`, or a future posture doc under `docs/30-architecture/` that pins the caller-visible meaning of live D-CAPRPC session continuity, promise/pipelining behavior, or bounded oneway notification semantics;
2) it is a posture doc, not an adjacent schema / RFC / replication / import / restore surface (for example `capability-rpc-frame-schema-v1.md`, `caprpc-proxy-replication-boundary-v0.md`, `capx-posture-v0.md`, and `sturdyref-posture-v0.md` stay adjacent);
3) its meaning is about portable live capability-RPC runtime semantics, not a neighboring seam whose Phase 1 posture intentionally lives elsewhere (for example `turns-posture-v0.md`, `reqctx-posture-v0.md`, `ordering-token-posture-v0.md`, and `wallet-posture-v0.md` remain distinct).

## Closed live CapRPC posture set (Phase 1)

### 1) Live-session continuity and reference validity

| Doc | One-line pinned meaning |
|---|---|
| [`caprpc-session-posture-v0.md`](caprpc-session-posture-v0.md) | live refs stay explicit, connection-specific, and session-scoped; disconnect is fail-stop; continuity requires an explicit new session plus explicit bootstrap or CH-CAPX/CH-SREF restore |

### 2) Latency-tolerance and bounded notification adjuncts

| Doc | One-line pinned meaning |
|---|---|
| [`caprpc-promise-posture-v0.md`](caprpc-promise-posture-v0.md) | promise handles stay caller-local, session-scoped, and one-shot; pipelining targets only unresolved capability results; no promise inventory/combinator/admin seam |
| [`caprpc-oneway-posture-v0.md`](caprpc-oneway-posture-v0.md) | oneway stays interface-marked, enqueue-or-error, and small; no third frame kind, no capability attachments, and no durable mailbox/admin seam |

## Review rule

When a new posture doc appears that primarily pins live D-CAPRPC session continuity, promise/pipelining behavior, or bounded oneway notification semantics, either:

- add it here **in the same revision**, or
- explicitly place it under some other existing closed discovery surface in the same revision.

If a future change wants durable mailboxes, public promise/session inventories, transparent reconnect/resume, endpoint discovery, or broader distributed-runtime control semantics, that widening must remain explicit on its own seam: keep this index, `capx-posture-v0.md`, `sturdyref-posture-v0.md`, `turns-posture-v0.md`, `reqctx-posture-v0.md`, and `caprpc-proxy-replication-boundary-v0.md` all honest in the same revision instead of letting “CapRPC” become a blurry control bucket.

## Wiring

- Decision surfaces: `decision-map.md` (**D-CAPRPC**, adjacent **D-CAPX** / **CH-SREF** continuity).
- Adjacent runtime/input seams: `turns-posture-v0.md`, `reqctx-posture-v0.md`, `ordering-token-posture-v0.md`.
- Adjacent import/restore/replication boundaries: `capx-posture-v0.md`, `sturdyref-posture-v0.md`, `caprpc-proxy-replication-boundary-v0.md`.
- Adjacent carrier/schema surfaces: `capability-rpc-frame-schema-v1.md`, `capability-rpc-frame-schema-v0.md`.
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_caprpc_adjunct_index.py` (**EVID-2026-531**).
