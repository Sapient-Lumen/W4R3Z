# Replication boundary index (v0)

Purpose: keep the **closed set of D-REPL / Hybrid object-family replication boundary docs** enumerable.

Why this exists:
- the archive now pins several small `*-replication-boundary-v0.md` docs so Hybrid replication cannot quietly regrow into a second authority bus,
- those docs are individually crisp but easy to forget piecemeal because they span owner-routed active state, additive spend summaries, signed bundle evidence, transcript/receipt export evidence, and the dedicated ordered-log evidence lane,
- `replication-contracts-v0.md`, `replication-object-family-registry.md`, and `profile-repl-defaults.md` keep the overall D-REPL contract vocabulary / allowlist / A–D defaults honest, while this index is the **discovery surface** that says which companion boundaries currently pin each admitted `object_family` meaning.

This doc does **not** add a new schema, replication class, or object family.
It is an entropy-reducing companion to `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, and `hybrid-phase1-boundary-v0.md`.

## Inclusion rule

A doc belongs here if it removes exactly one tempting cross-cluster replication meaning from Phase 1 by constraining one of:
- owner-routed active state that would otherwise smuggle in portable spend authority, callable proxy authority, or auto-activating namespace state,
- commutative/additive replicated summaries that would otherwise smuggle in replay, admission, or remote borrowing authority,
- ordered or signed evidence lanes that would otherwise smuggle in global name resolution, runtime order, freshness, or control authority.

If future work needs a new native replication class, object family, or globally ordered control plane instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind replicated metadata.

## Closed companion boundary set (Phase 1)

### 1) Owner-routed active state stays explicit and non-portable

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`view-replication-boundary-v0.md`](view-replication-boundary-v0.md) | replicated `view` summaries | owner-routed slot-binding metadata only; non-owner replicas stay read-only and non-activating | explicit owner-routed `view.attach` / `view.detach` or explicit local view materialization |
| [`budget-replication-boundary-v0.md`](budget-replication-boundary-v0.md) | replicated `budget` metadata | owner-routed issuer / lease-lineage metadata only; replicas do not mint local spend authority or widen leases | explicit owner-routed budget mint/split/revoke/close seam |
| [`caprpc-proxy-replication-boundary-v0.md`](caprpc-proxy-replication-boundary-v0.md) | replicated `caprpc_proxy` route/bootstrap data | owner-routed endpoint/proxy metadata only; replicas do not create callable local handles/proxies | explicit live handoff or explicit CH-CAPX / CH-SREF import/restore |

### 2) Commutative evidence sets stay auditable, not authoritative

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`transcript-replication-boundary-v0.md`](transcript-replication-boundary-v0.md) | replicated `transcript` entries | content-addressed CH-LOG event-set evidence only; arrival order is never runtime sequencing, replay, or approval authority | explicit local validator/policy/capability checks |
| [`receipt-replication-boundary-v0.md`](receipt-replication-boundary-v0.md) | replicated `receipt` sets | immutable digest-addressed evidence only; receipts do not authorize replay, import, or admission | explicit local approval/import seams |
| [`namecert-replication-boundary-v0.md`](namecert-replication-boundary-v0.md) | replicated `namecert` bundle sets | signed CH-NAMECERT bundle evidence only; arrivals do not auto-install trust, visibility, or active bindings | explicit local naming policy and explicit view materialization |

### 3) Additive and ordered evidence lanes stay observational only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`quota-replication-boundary-v0.md`](quota-replication-boundary-v0.md) | replicated `quota` spend summaries | additive spend observations only; replicas do not create remote borrowing or admission authority | explicit local payer/budget authority |
| [`tlog-replication-boundary-v0.md`](tlog-replication-boundary-v0.md) | replicated `tlog` checkpoints/proofs | append-only evidence only; checkpoint order does not become general runtime control, freshness, or time authority | explicit local log/witness policy and exact proof artifacts |

## Review rule

Before adding another replication companion boundary doc, answer these questions in order:
1) Is the change really a **D-REPL / Hybrid `object_family` meaning pin** rather than a new schema, replication class, or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening replicated metadata semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
