# MicroVM live-migration posture v0 (migration stays non-portable)

Purpose: pin the **Phase 1** meaning of host-driven live migration / failover under `ext.microvm` so precopy/postcopy/stop-and-copy machinery does not quietly become a portable continuity, transport, or operations contract.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-EPHEM** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient live-migration contract under `ext.microvm`; there is no portable precopy/postcopy/stop-and-copy/failover plane, no portable migration-channel/URI/auth contract, no portable convergence-downtime-or-device-state-transfer contract, owner-local migration orchestration stays implementation-local, and reviewed continuity / activation / snapshot / topology meaning still rides on already-pinned explicit seams rather than ambient VMM migration machinery.**

Entropy cost justification: the archive already pins snapshot/restore, generation witnesses, management APIs, topology mutability, and warm-start lineage individually, but mainstream virtualization stacks still invite one large ambient shortcut: just migrate the running VM and treat the transport, convergence algorithm, destination admission, and device-state handoff as harmless plumbing. QEMU/libvirt migration surfaces and VFIO migration rules show how much coordination, transport state, and device-specific policy hide inside that shortcut. One narrow posture closes that gap without inventing a SlopOS migration service, drain protocol, or new schema family.

## Posture (v0)

1) **No portable ambient live-migration contract**
   - **Phase 1 exposes no portable ambient live-migration contract under `ext.microvm`.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf can be live-migrated, postcopied, failed over, or resumed on another host under one stable reviewed API or one stable continuity story.
   - Implementations may support owner-local migration machinery for one deployment, but that machinery does **not** become SlopOS portable contract meaning.

2) **No portable precopy/postcopy/stop-and-copy/failover plane**
   - There is **no portable precopy/postcopy/stop-and-copy/failover plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `migrate`, `migrate-start-postcopy`, `migrate-recover`, `failover`, or `handoff-running-vm` command family, one stable dirty-page streaming policy, or one stable switchover/downtime vocabulary.
   - Owner-local migration strategy, memory-transfer mode, dirty-page handling, switchover timing, and failover policy remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **No portable migration-channel/URI/auth contract**
   - There is **no portable migration-channel/URI/auth contract** under Phase 1.
   - Portable reviewed meaning does **not** include one stable destination URI format, one stable migration socket/TCP/TLS/RDMA exposure story, one stable peer-to-peer orchestration contract, or one stable external auth wrapper for migration traffic.
   - Owner-local source/destination coordination, migration transport, addressability, access control, and channel protection remain implementation-local and must not silently become portable deployment semantics.

4) **No portable convergence/downtime/device-state-transfer contract**
   - There is **no portable convergence/downtime/device-state-transfer contract** under Phase 1.
   - Portable reviewed meaning does **not** include one stable guarantee about acceptable dirty-rate convergence, one stable downtime bound, one stable device-state transfer capability, one stable VFIO or passthrough migration contract, or one stable rule that guest-visible device/network/topology state survives migration under the same reviewed meaning.
   - Owner-local device-selection, passthrough exclusion, retry/fallback logic, and failure handling remain implementation-local and must not silently become portable readiness or portability truth.

5) **Existing explicit seams remain authoritative**
   - Reviewed activation meaning still rides on explicit `D-ACTIVATE` supervision and owner-local admission, not on ambient “the migration endpoint accepted it” folklore.
   - Reviewed continuity meaning still rides on the already-pinned `microvm-snapshot-posture-v0.md`, generation-witness, repair-barrier, attestation-scope, and resume-admission-evidence postures rather than an ambient migration success story.
   - Reviewed topology meaning still rides on already-pinned CPU/RAM/NIC/block/bus/interrupt/device postures rather than an ambient promise that a running leaf can move across hosts with equivalent device state under one portable identity.
   - Reviewed compatibility meaning still rides on `microvm-template-resume-class-posture-v0.md` and the sealed-compat stance rather than ambient best-effort host renegotiation during migration.

6) **Changing the migration stance is owner-local orchestration policy or new admission, not a portable continuity plane**
   - Changing the migration stance is owner-local orchestration policy or new admission, not a portable continuity plane.
   - If policy cares about a different migration topology, destination class, or failover behavior, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `migrate_vm`, `postcopy_vm`, `failover_vm`, or `rehome_running_leaf` plane by convention.
   - This keeps cross-host continuity meaning on already-pinned activation, evidence, and topology seams rather than on ambient VMM migration machinery.

7) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `migrate_vm`, `enter_postcopy`, `failover_vm`, or `query_migration_state` must say whether it commutes with activation, topology policy, snapshot/restore policy, attestation freshness, passthrough policy, and observation export, and where serialization lives.
   - Until then, migration serialization and rollback are owner-local runtime concerns rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable live-migration / postcopy / failover semantics under `ext.microvm`.
- No portable migration channel / URI / peer-auth / destination-admission contract.
- No portable downtime / convergence / dirty-page streaming guarantee.
- No portable VFIO / passthrough-device migration promise.
- No claim that migration success is an acceptable portable substitute for explicit D-ACTIVATE / D-EPHEM / D-XS seams.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-EPHEM)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `microvm-management-api-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `microvm-restore-repair-barrier-posture-v0.md`
  - `microvm-resume-admission-evidence-posture-v0.md`
  - `microvm-device-passthrough-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-43)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-MIGRATION)
- Policy posture:
  - live migration adds **no new lane**, **no portable cross-host continuity claim**, and **no portable migration control plane** in Phase 1.

CI drift gate:
- `tools/check_microvm_live_migration_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable live-migration contract / no portable precopy-postcopy-stop-and-copy-failover plane / no portable migration-channel-URI-auth contract / no portable convergence-downtime-device-state-transfer contract / owner-local migration orchestration stays implementation-local / explicit activation-continuity-topology seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-QEMU-MIGRATION.
- REF-LIBVIRT-MIGRATION.
- REF-QEMU-VFIO-MIGRATION.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
