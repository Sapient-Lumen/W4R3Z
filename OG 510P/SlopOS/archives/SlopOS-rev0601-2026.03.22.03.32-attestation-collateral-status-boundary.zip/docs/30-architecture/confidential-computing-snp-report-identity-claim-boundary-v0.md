# D-CC SNP report-identity claim boundary v0 (`REPORT_ID` / `REPORT_ID_MA` stay exact evidence; not portable instance/migration identity)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `REPORT_ID` and `REPORT_ID_MA`** so firmware-generated report identifiers do not quietly become a portable SlopOS instance identity, migration truth, freshness token, or hidden secret-release namespace.

Entropy cost justification: the archive already pins one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, one SNP guest-mode cut, one owner-launch-identity rule, one SNP TCB-field rule, and one SNP `POLICY` rule. What remained ambiguous was narrower and worth deciding now: **the SNP attestation report also carries firmware-generated `REPORT_ID` and optional `REPORT_ID_MA`, and AMD says `REPORT_ID` persists with the guest instance throughout its lifetime**. One small boundary closes that gap without inventing a portable instance-ID schema, migration protocol, or replay-tracker service.

## Posture (v0)

1) **`REPORT_ID` / `REPORT_ID_MA` are exact provider-native report identity evidence, not portable SlopOS instance or migration identity claims**
   - AMD’s SNP firmware ABI says the firmware **generates a report ID for each guest** and that it **persists with the guest instance throughout its lifetime**.
   - The same report structure carries `REPORT_ID_MA` when the guest has an associated migration agent.
   - Phase 1 therefore treats both fields as **exact provider-native evidence only**. They do **not** become native `CH-ATTEST` fields, a portable SlopOS instance identifier, or a reviewed cross-provider migration-identity schema.

2) **Report identity fields do not define a normalized continuity / resume / migration language**
   - A matching `REPORT_ID` across two exact reports may be useful to a deployment-local verifier or operator, and a present/non-zero `REPORT_ID_MA` may be useful to deployment-local audit.
   - Phase 1 still does **not** normalize those observations into a portable “same machine”, “same lease”, “same enclave”, “same workload generation”, or “migration authorized/in-progress” claim.
   - In particular, `REPORT_ID_MA` MUST NOT be treated as a portable live-migration capability bit, failover proof, or hidden transport/control-plane selector.

3) **`REPORT_ID` / `REPORT_ID_MA` do not substitute for `boot_digest`, `prov_digest`, exact `cc_report_data_v0` binding, or freshness**
   - A verifier MUST still check the already-pinned boot/provenance/report-data binding surfaces separately.
   - Matching, differing, reused, or absent report IDs do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace freshness binding under `PO-ATTEST-FRESH`, and do **not** redefine which `CH-BOOT` / provenance bundle was actually admitted.
   - In particular, `REPORT_ID` MUST NOT become a hidden nonce, replay oracle, attestation-session identifier, or substitute proof that the exact D-CC binder contract was satisfied.

4) **Report identity fields do not define secret-release, key-derivation, or namespace selection semantics**
   - Phase 1 does **not** bind secret-release scope, handle namespaces, lease renewal, or any `CH-AREF` / D-VAULT / D-CRYPTOSVC selector semantics to `REPORT_ID` or `REPORT_ID_MA`.
   - Those fields may be preserved as exact evidence for audit, but they do **not** become portable approval tokens, key-namespace selectors, or hidden routing inputs for release policy.
   - Any deployment that chooses to compare exact report IDs is still exercising **explicit verifier-local policy**, not relying on portable SlopOS claim meaning.

5) **Any appraisal of report identity fields remains explicit verifier-local policy**
   - A deployment-specific verifier MAY preserve, compare, or log exact `REPORT_ID` / `REPORT_ID_MA` bytes for local audit or same-flow correlation.
   - That appraisal remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS default.
   - Different deployments may therefore ignore, reject, review, or correlate the same exact report-ID evidence differently without changing the portable D-ATTEST seam.

6) **Packaging/export does not upgrade report identity bytes into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `REPORT_ID` / `REPORT_ID_MA`.
   - If tooling wants to preserve decoded values for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable report-ID schema.
   - Exporting an SNP report that carries these fields does not imply that remote consumers may treat them as reviewed SlopOS-native instance, migration, or continuity meaning.

7) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of two already-existing SNP report fields.
   - It introduces no new workflow kind, no serialization surface, and no attester-side instance-ID query, migration-state query, or report-history plane.

## Phase 1 non-goals (explicitly deferred)

- No `instance_id`, `report_id`, or `migration_agent_id` field in `CH-ATTEST v0`.
- No portable live-migration, failover, or restore-continuity claim derived from `REPORT_ID` / `REPORT_ID_MA`.
- No default anti-replay, freshness, or session-resumption rule keyed by `REPORT_ID`.
- No `IF-ATTEST` selector/query surface for exact report IDs or migration-agent report identity.

## Why this boundary exists

The archive had already fixed the binder, certificate-source, host-field, owner-identity, TCB-field, and guest-policy seams, but one implementation fork remained likely:
- AMD’s ABI says `REPORT_ID` persists with the guest instance throughout its lifetime,
- the report also carries `REPORT_ID_MA` when a migration agent exists,
- cloud operators and secret-release systems often want a stable “instance identity” handle,
- and restore/migration/failover stories are already tempting places to smuggle provider-native continuity assumptions back into the core seam.

Without one explicit rule, the first verifier, secret-release controller, or hosted rollout path would predictably do one of these by convention:
- treat `REPORT_ID` as the portable SlopOS guest/instance identifier,
- treat `REPORT_ID_MA` as a portable migration-authorized or migration-in-progress claim,
- or key freshness/replay logic and secret-release continuity to provider-native report IDs instead of the already-pinned binder/provenance/freshness surfaces.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **`REPORT_ID` / `REPORT_ID_MA` stay exact evidence unless explicit verifier-local policy says more**,
- **live migration / restore continuity do not quietly re-enter through SNP report folklore**,
- and **automation cannot inherit a hidden provider-native instance-ID taxonomy through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers can preserve exact `REPORT_ID` bytes for audit without importing one provider-native instance identifier or migration hint as portable workstation semantics.
- **Cloud micro-VM substrate (B):** hosted verifiers can correlate exact report IDs inside deployment-local policy, but they do not get a portable “same guest”, “same lease”, or “migration-approved” shortcut for secret release, rollout, or failover.
- **Embedded / separation-kernel-ish appliance (C):** imported SNP evidence may retain exact report IDs for audit, but appliance posture does not widen into a cross-provider continuity or migration taxonomy just because one cloud report carried those fields.
- **Agent / automation OS (D):** agents can inspect exact `REPORT_ID` / `REPORT_ID_MA` evidence, but they do not gain a hidden instance-identity shortcut; any correlation or migration interpretation remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP report-identity meaning seam.

If a second closely related D-CC SNP report-identity boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-tcb-field-claim-boundary-v0.md`
  - `confidential-computing-snp-policy-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `microvm-live-migration-posture-v0.md`
  - `microvm-attestation-reacquire-posture-v0.md`
  - `microvm-attestation-scope-posture-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_report_identity_claim_boundary.py` (**EVID-2026-542**).

## References

- REF-AMD-SNP-FWABI.
- REF-RATS-RFC9334.
