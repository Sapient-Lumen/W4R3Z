# MicroVM adjunct index (closed `ext.microvm` posture family)

Purpose: keep the current **D-MICROVM adjunct posture set** recoverable as one closed discovery surface.
Why this exists:
`microvm-profile-posture-v0.md` remains the umbrella posture for `ext.microvm`, but the adjunct family has grown large enough that humans/LLMs should not have to recover it by re-reading one long prose document. This index makes the current adjunct set explicit and machine-checkable without changing **D-MICROVM** or inventing a new schema.

This doc does **not** change `ext.microvm` meaning. It keeps the current `microvm-*-posture-v0.md` adjunct family closed, enumerable, and reviewable as one implementation-facing product surface for shapes **A/B/D** while leaving profile **C** free to ignore the family entirely.

## Inclusion rule

Include a doc here if all of the following are true:

1) it is a `microvm-*-posture-v0.md` adjunct that narrows some guest-visible or host-side `ext.microvm` behavior under **D-MICROVM / D-XS**;
2) it is not the umbrella posture doc `microvm-profile-posture-v0.md`;
3) its meaning is specific to the microVM profile rather than a generic seam that merely happens to be adjacent (for example `host-guest-channel-posture-v0.md` stays adjacent wiring, not a member of this closed filename family).

## Closed adjunct posture set (Phase 1)

### 1) Admission shape, topology, and backing

| Doc | One-line pinned meaning |
|---|---|
| [`microvm-backend-offload-posture-v0.md`](microvm-backend-offload-posture-v0.md) | no portable ambient `vhost-user` / vDPA backend contract |
| [`microvm-block-topology-posture-v0.md`](microvm-block-topology-posture-v0.md) | static guest-visible block set; no portable disk attach/eject plane |
| [`microvm-bootstrap-metadata-posture-v0.md`](microvm-bootstrap-metadata-posture-v0.md) | no ambient guest metadata/bootstrap channel |
| [`microvm-bus-topology-posture-v0.md`](microvm-bus-topology-posture-v0.md) | no portable ambient guest-visible device-bus topology contract |
| [`microvm-cache-hierarchy-posture-v0.md`](microvm-cache-hierarchy-posture-v0.md) | no portable ambient cache hierarchy / cache-QoS contract |
| [`microvm-cpu-topology-posture-v0.md`](microvm-cpu-topology-posture-v0.md) | static guest-visible vCPU shape; no portable resize plane |
| [`microvm-device-passthrough-posture-v0.md`](microvm-device-passthrough-posture-v0.md) | no portable ambient guest VFIO/passthrough contract |
| [`microvm-entropy-surface-posture-v0.md`](microvm-entropy-surface-posture-v0.md) | no portable ambient guest entropy contract |
| [`microvm-firmware-description-posture-v0.md`](microvm-firmware-description-posture-v0.md) | no portable ambient guest-visible ACPI / device-tree / firmware-table contract |
| [`microvm-firmware-state-posture-v0.md`](microvm-firmware-state-posture-v0.md) | UEFI variable store and boot policy stay non-portable |
| [`microvm-interrupt-topology-posture-v0.md`](microvm-interrupt-topology-posture-v0.md) | no portable ambient guest-visible interrupt topology / irqchip contract |
| [`microvm-memory-backing-posture-v0.md`](microvm-memory-backing-posture-v0.md) | host-side guest-RAM backing stays non-portable |
| [`microvm-memory-dedup-posture-v0.md`](microvm-memory-dedup-posture-v0.md) | mergeable memory stays non-portable |
| [`microvm-memory-topology-posture-v0.md`](microvm-memory-topology-posture-v0.md) | static guest-visible RAM; no portable resize plane |
| [`microvm-nested-virt-posture-v0.md`](microvm-nested-virt-posture-v0.md) | guest hypervisor capability stays non-portable |
| [`microvm-network-feature-posture-v0.md`](microvm-network-feature-posture-v0.md) | no portable guest-visible NIC acceleration / tuning contract |
| [`microvm-network-topology-posture-v0.md`](microvm-network-topology-posture-v0.md) | static guest-visible NIC set; no portable attach/detach plane |
| [`microvm-numa-topology-posture-v0.md`](microvm-numa-topology-posture-v0.md) | no portable ambient guest-visible NUMA / proximity-domain contract |
| [`microvm-page-tracking-posture-v0.md`](microvm-page-tracking-posture-v0.md) | host-side guest-memory dirty/access tracking stays non-portable |
| [`microvm-persistent-memory-posture-v0.md`](microvm-persistent-memory-posture-v0.md) | no portable ambient guest-visible persistent-memory contract |
| [`microvm-platform-identity-posture-v0.md`](microvm-platform-identity-posture-v0.md) | no portable ambient guest-visible platform identity / fingerprinting contract |
| [`microvm-time-source-posture-v0.md`](microvm-time-source-posture-v0.md) | guest clocksource and wall-clock policy stay non-portable |
| [`microvm-tpm-surface-posture-v0.md`](microvm-tpm-surface-posture-v0.md) | no portable ambient guest TPM contract |
| [`microvm-virtual-iommu-posture-v0.md`](microvm-virtual-iommu-posture-v0.md) | no portable ambient guest vIOMMU contract |

### 2) Channels, peripherals, and host-side control/observation surfaces

| Doc | One-line pinned meaning |
|---|---|
| [`microvm-audio-capture-posture-v0.md`](microvm-audio-capture-posture-v0.md) | no portable ambient guest-visible sound/capture device contract |
| [`microvm-clipboard-dragdrop-posture-v0.md`](microvm-clipboard-dragdrop-posture-v0.md) | desktop helper transfer stays non-portable |
| [`microvm-console-channel-posture-v0.md`](microvm-console-channel-posture-v0.md) | diagnostic sink only; no interactive host channel |
| [`microvm-crash-report-surface-posture-v0.md`](microvm-crash-report-surface-posture-v0.md) | panic and crash-record surfaces stay non-portable |
| [`microvm-debug-introspection-posture-v0.md`](microvm-debug-introspection-posture-v0.md) | no portable ambient host-side guest-debug or memory-introspection contract |
| [`microvm-display-input-posture-v0.md`](microvm-display-input-posture-v0.md) | no portable ambient guest-visible graphics/input device contract |
| [`microvm-guest-agent-posture-v0.md`](microvm-guest-agent-posture-v0.md) | management helpers stay non-portable |
| [`microvm-lifecycle-signal-posture-v0.md`](microvm-lifecycle-signal-posture-v0.md) | no portable ambient guest-visible power/reset/suspend/watchdog contract |
| [`microvm-live-migration-posture-v0.md`](microvm-live-migration-posture-v0.md) | migration stays non-portable |
| [`microvm-management-api-posture-v0.md`](microvm-management-api-posture-v0.md) | control APIs stay non-portable |
| [`microvm-paravirt-enlightenment-posture-v0.md`](microvm-paravirt-enlightenment-posture-v0.md) | hypervisor-specific assist ABIs stay non-portable |
| [`microvm-pmu-profiling-posture-v0.md`](microvm-pmu-profiling-posture-v0.md) | guest-visible perf counters stay non-portable |
| [`microvm-semihosting-posture-v0.md`](microvm-semihosting-posture-v0.md) | debug-host escape stays non-portable |
| [`microvm-shared-memory-doorbell-posture-v0.md`](microvm-shared-memory-doorbell-posture-v0.md) | no portable ambient guest-visible shared-memory peer-channel contract |
| [`microvm-usb-redirection-posture-v0.md`](microvm-usb-redirection-posture-v0.md) | remote USB forwarding stays non-portable |
| [`microvm-virtio-serial-port-posture-v0.md`](microvm-virtio-serial-port-posture-v0.md) | console-adjacent helper channels stay non-portable |

### 3) Snapshot, warm-state, and attestation-continuity adjuncts

| Doc | One-line pinned meaning |
|---|---|
| [`microvm-attestation-reacquire-posture-v0.md`](microvm-attestation-reacquire-posture-v0.md) | clone/restore invalidates attestation freshness and attestation-gated release sessions |
| [`microvm-attestation-scope-posture-v0.md`](microvm-attestation-scope-posture-v0.md) | fresh attestation stays boot/provenance-bound, not warm-state identity |
| [`microvm-clock-disruption-posture-v0.md`](microvm-clock-disruption-posture-v0.md) | guest precision-time repair is explicit and separate |
| [`microvm-generation-witness-posture-v0.md`](microvm-generation-witness-posture-v0.md) | guest-visible clone/restore detection is explicit |
| [`microvm-restore-repair-barrier-posture-v0.md`](microvm-restore-repair-barrier-posture-v0.md) | repair completes before effectful work |
| [`microvm-resume-admission-evidence-posture-v0.md`](microvm-resume-admission-evidence-posture-v0.md) | exact resumed leaf identity is admission-local provenance only |
| [`microvm-snapshot-posture-v0.md`](microvm-snapshot-posture-v0.md) | warm restore is not ambient continuity |
| [`microvm-template-availability-posture-v0.md`](microvm-template-availability-posture-v0.md) | warm-leaf availability is owner-local and semantically optional |
| [`microvm-template-distribution-posture-v0.md`](microvm-template-distribution-posture-v0.md) | warm-state leaves stay owner-local accelerators |
| [`microvm-template-lineage-posture-v0.md`](microvm-template-lineage-posture-v0.md) | reusable templates are parent-bound leaf artifacts |
| [`microvm-template-resume-class-posture-v0.md`](microvm-template-resume-class-posture-v0.md) | reusable templates admit only under an exact reviewed restore class |
| [`microvm-template-snapshot-cut-posture-v0.md`](microvm-template-snapshot-cut-posture-v0.md) | reusable snapshots are secret-clean and authority-cold |

## Review rule

When a new `microvm-*-posture-v0.md` adjunct appears, either:

- add it here **in the same revision**, or
- rename/re-scope it so it clearly belongs to some other existing discovery surface.

If a future change needs a different family rule than “current `microvm-*-posture-v0.md` adjuncts except the umbrella profile posture,” that widening must be made explicit in the same revision with matching README / posture-index / runbook / evidence wiring.

## Wiring

- Umbrella posture: `microvm-profile-posture-v0.md`.
- Adjacent posture: `host-guest-channel-posture-v0.md`.
- Decision surface: `decision-map.md` (**D-MICROVM**, **D-XS**).
- Posture registry: `posture-index.md`.
- Repo indexes: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`.

## Evidence hook

- CI drift gate: `tools/check_microvm_adjunct_index.py` (**EVID-2026-521**).
