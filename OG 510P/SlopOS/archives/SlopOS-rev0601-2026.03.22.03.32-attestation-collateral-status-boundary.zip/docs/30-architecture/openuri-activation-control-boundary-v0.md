# D-PLUMB OpenURI activation-control boundary v0 (no portable foreground / activation control)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: foregrounding, activation handoff, and focus-steering stay **shell/compositor-owned attention policy**, not a portable requester-visible control or receipt surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, and no new ACP or conflict-key family. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable requester-visible foreground / activation control in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `activate`, `foreground`, `raise`, `bring_to_front`, `prefer_background`, `no_activate`, or equivalent attention-steering control on `portal.uri.*`.
   - The portable requester truth remains the mediated action + subject only.

2) **Provider-local activation mechanics stay provider-local.**
   - The portal/shell/backend may internally carry `parent_window`, compositor activation tokens, or platform-specific launch/open configuration flags so it can integrate with local focus-stealing prevention and UX policy.
   - Those mechanics do **not** become a requester-owned stable cross-profile contract, a transcript-stable result field, or a portable activation API.
   - Phase 1 therefore exports **no** portable input or output `activation_token` field on `portal.uri.*`.

3) **No portable receipt that the target was foregrounded, focused, or activated.**
   - Requesters do **not** receive a portable receipt proving that the chosen handler became frontmost, obtained keyboard focus, entered split-screen/adjacent presentation, or otherwise won user attention.
   - Targets likewise must not treat OpenURI as a portable authenticated statement that the opener had a right to steal focus or that the shell guaranteed foreground activation.
   - If a future product shape needs durable attention or foreground-steering truth, it must pay for an explicit RFC-first surface under D-ATTN / shell policy rather than piggybacking on `portal.uri.*`.

4) **Why this cut is honest.**
   - Existing ecosystems really do surface activation mechanics here: xdg OpenURI methods already carry `activation_token`; the xdg AppChooser backend also accepts and may return `activation_token`; Wayland `xdg_activation_v1` models activation as compositor-mediated token handling that may be ignored; AppKit `NSWorkspace.OpenConfiguration.activates` exposes foregrounding as an explicit launch/open option.
   - Those are real platform features, but importing them directly would widen `portal.uri.*` from mediated launch into an attention/activation control plane.
   - SlopOS keeps attention-steering policy local unless and until there is a deliberate RFC-first reason to standardize that surface.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; shell-visible launch/focus order still serializes there.
   - Phase 1 adds **no new ACP kind** and **no new conflict-key family** for activation control because portable requesters do not control or observe that state directly.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host focus-steering, activation-token plumbing, or “bring this handler frontmost” knobs through helper shims.
   - If compat wants OpenURI, it still goes through `portal.uri.*` or fails closed.

## Phase 1 non-goals (explicitly deferred)

- No portable `activation_token` input/output on `portal.uri.*`.
- No requester-visible `activate` / `foreground` / `raise` / `bring_to_front` / `no_activate` surface.
- No portable receipt proving that the chosen handler became frontmost, focused, or otherwise won user attention.
- No ACP/admin/query surface for OpenURI activation policy.
- No hidden compat/helper fallback that reintroduces foreground/activation control out-of-band.

## Why this is worth pinning

Once OpenURI exists, another tempting convenience import is “can I make the chosen handler come to the front?” Current xdg portal docs already carry `activation_token` fields on OpenURI and chooser mediation. Wayland activation makes those tokens explicitly compositor-owned and ignorable, and AppKit exposes foreground activation as a separate open-configuration option rather than something identical to “open this URI”.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a portable attention-steering or focus-stealing control plane. That matters most for the workstation and agent shapes, where helper/tooling ecosystems would otherwise start depending on foreground folklore instead of explicit attention policy and user mediation.

## Profile effect (A–D)

- **Secure workstation (A):** opening a link stays useful without giving apps a portable way to force or verify focus stealing.
- **Cloud micro-VM substrate (B):** guest/tenant tooling can request mediated launch where allowed without steering host-side activation policy.
- **Embedded / separation appliance (C):** deployments without rich desktop UX avoid carrying fake focus/foreground semantics just because richer desktops expose them.
- **Agent/automation OS (D):** agents/tools cannot smuggle “bring this app frontmost” policy through OpenURI; durable attention semantics remain on explicit shell/attention surfaces.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/openuri-opener-attribution-boundary-v0.md`
  - `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
  - `docs/30-architecture/plumb-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/attention-lease-posture-v0.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_activation_control_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable activation-token / no foreground-control / no frontmost-receipt / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-576**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-XDG-PORTAL-APPCHOOSER.
- REF-WAYLAND-XDG-ACTIVATION.
- REF-APPLE-NSWORKSPACE-ACTIVATES.
