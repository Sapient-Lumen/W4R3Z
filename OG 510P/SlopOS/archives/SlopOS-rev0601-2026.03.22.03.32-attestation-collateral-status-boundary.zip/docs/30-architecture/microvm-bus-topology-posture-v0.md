# MicroVM bus-topology posture v0 (no portable ambient guest-visible device-bus topology contract)

Purpose: pin the **Phase 1** meaning of guest-visible device-bus topology under `ext.microvm` so PCI-vs-MMIO transport choice, PCI/BDF slot folklore, ACPI path naming, and bus-rescan/hotplug habits do not quietly become a reviewed host↔guest control/status plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible device-bus topology contract under `ext.microvm`; there is no portable PCI-vs-MMIO transport promise, no stable PCI-BDF-segment-root-port-slot or ACPI-device-path inventory contract, no bus-rescan-or-address-assignment admin/status plane, and changing bus topology/addressing means owner-local relayout or a new reviewed admission/activation rather than mutating a running guest under the same portable identity.**

Entropy cost justification: the archive already fixes guest-visible CPU/RAM/NIC/block shape at admission, forbids ambient host channels, and keeps passthrough/vIOMMU semantics non-portable. What remained loose was the more primitive layer underneath those device families: whether `ext.microvm` quietly promises one specific guest bus vocabulary or a live bus-management plane. One narrow posture closes that gap without inventing a bus schema family, PCI inventory API, or guest agent.

## Posture (v0)

1) **No portable ambient guest-visible device-bus topology contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible device-bus topology contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable bus vocabulary, one fixed enumeration style, or one guest-visible device-addressing scheme across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable PCI-or-MMIO bus story exists with stable addresses and enumeration semantics.”

2) **No portable PCI-vs-MMIO transport promise**
   - Phase 1 standardizes **no portable PCI-vs-MMIO transport promise** under `ext.microvm`.
   - That means no reviewed portable semantics for “all virtio devices appear through PCI”, “all virtio devices appear through MMIO”, or “one runtime must preserve the transport choice made by another runtime as part of the product contract.”
   - Implementations may locally choose virtio-mmio, virtio-pci, a machine model with predeclared transports, or another owner-reviewed layout, but that choice is **not** part of the portable Phase 1 product contract and must not silently become a new compatibility obligation.

3) **No stable PCI-BDF / segment / root-port / slot / ACPI-device-path inventory contract**
   - Phase 1 standardizes **no stable PCI-BDF / segment / root-port / slot / ACPI-device-path inventory contract** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about PCI segment numbering, BDF identity, root-port layout, hotpluggable slot inventory, ACPI device path naming, or “device X will always appear at this exact bus address on every reviewed implementation.”
   - Guests may locally observe a bus inventory in one implementation, but those observations remain implementation-local facts rather than portable reviewed API meaning.

4) **No portable bus-rescan / hotplug / address-assignment admin-status plane**
   - Phase 1 standardizes **no portable bus-rescan / hotplug / address-assignment admin-status plane** under `ext.microvm`.
   - That means no reviewed portable semantics for rescanning buses, enumerating hotpluggable slots, watching device-add/remove completion, steering devices onto specific buses/ports/addresses, or treating guest-visible bus-management tools as the reviewed lifecycle API.
   - Implementations may internally use owner-local bus managers, firmware tables, or runtime-specific hotplug hooks, but those mechanisms remain implementation-local and must not silently become portable SlopOS interface meaning.

5) **Owner-local bus layout and address assignment stay implementation-local**
   - Owner-local bus layout and address assignment stay implementation-local.
   - Runtimes may choose one machine model, one root-complex layout, one MMIO address map, or one PCI enumeration strategy locally, but that does **not** create a portable reviewed promise about one canonical bus topology, one stable set of slot names, or one cross-runtime address-allocation algorithm.
   - In particular, bus names, BDFs, ACPI paths, bridge layout, and low-level address assignment remain host/runtime-local mechanism, not portable SlopOS interface meaning.

6) **Changing bus topology/addressing is owner-local relayout or new admission, not a portable live control plane**
   - Changing bus topology/addressing is owner-local relayout or new admission, not a portable live control plane.
   - Owners/runtimes may revise local bus layout choices across implementations or releases, and they may choose different bus models for different reviewed leaves or deployment classes, but they may **not** reinterpret a running leaf as carrying a portable guest-visible bus-admin plane under the same admitted identity.
   - If policy cares about a materially different guest-visible bus topology/addressing stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden bus-management contract by convention.

7) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for bus inventory, address assignment, or hotplug state, **no new ACP kind**, and **no new conflict-key family** for bus rescan, device add/remove, slot selection, or guest-visible address mutation under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `rescan_bus`, `add_device`, `remove_device`, `query_slots`, or `pin_address`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that `ext.microvm` guests always see one canonical bus vocabulary or one transport family.
- No portable PCI-BDF / segment / root-port / slot / ACPI-device-path inventory contract under `ext.microvm`.
- No portable bus-rescan / slot-admin / address-assignment / device-add-remove workflow under `ext.microvm`.
- No generic bus broker, slot allocator, or guest agent API for bus management.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-device-passthrough-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `microvm-block-topology-posture-v0.md`
  - `microvm-virtual-iommu-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-26)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-BUSTOPOLOGY)
- Policy posture:
  - guest-visible bus/transport topology adds **no new lane**, **no public bus-admin or address-inventory plane**, and **no portable in-place bus-mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_bus_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible device-bus topology contract / no portable PCI-vs-MMIO transport promise / no stable PCI-BDF-segment-root-port-slot-or-ACPI-device-path inventory contract / no portable bus-rescan-hotplug-address-assignment admin-status plane / owner-local bus layout and address assignment stay implementation-local / changing bus topology-addressing is owner-local relayout or new admission not a portable live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-FIRECRACKER-KERNEL-POLICY.
- REF-CHYP-HOTPLUG.
- REF-QEMU-DEVICE-EMULATION.
- REF-QEMU-QMP-DEVICE.
