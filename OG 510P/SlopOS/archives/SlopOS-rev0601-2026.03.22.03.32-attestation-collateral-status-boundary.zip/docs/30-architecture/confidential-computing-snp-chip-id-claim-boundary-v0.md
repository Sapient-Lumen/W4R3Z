# D-CC SNP CHIP_ID claim boundary v0 (`CHIP_ID` stays exact evidence; not portable machine identity)

Purpose: pin the **Phase 1** meaning of **AMD SEV-SNP `CHIP_ID`** so the chip-unique report field does not quietly become a portable SlopOS machine identity, anti-cloning oracle, trust-root selector, or hidden secret-release namespace.

Entropy cost justification: the archive already pins one first D-CC provider target, one exact 64-byte binder contract, one SNP certificate-source rule, one `HOST_DATA` rule, one SNP guest-mode cut, one owner-launch-identity rule, one SNP TCB-field rule, one SNP `POLICY` rule, and one SNP report-identity rule. What remained ambiguous was narrower and worth deciding now: **the SNP attestation report also carries `CHIP_ID`, AMD describes it as unique to the chip when unmasked, and the same ABI also allows platform policy to force the field to zero**. One small boundary closes that gap without inventing a portable machine-identity schema, asset registry, or chip-bound secret-release protocol.

## Posture (v0)

1) **`CHIP_ID` is exact provider-native key-linkage evidence, not portable SlopOS machine or host identity claim**
   - AMD’s SNP attestation material describes `CHIP_ID` as a **unique chip identifier** and says it connects the report to the certificate of the attestation key that signed the report.
   - The firmware ABI likewise defines `CHIP_ID` as the identifier unique to the chip when `MaskChipId` is 0.
   - Phase 1 therefore treats `CHIP_ID` as **exact provider-native evidence only**. It does **not** become a native `CH-ATTEST` field, a portable SlopOS machine/host identifier, or a reviewed cross-provider asset-identity schema.

2) **`CHIP_ID` may be intentionally masked, so portable meaning cannot depend on it being present/non-zero**
   - AMD’s firmware ABI says that if `MaskChipId` is set, the `CHIP_ID` field in the attestation report is set to zero, and platform configuration can force that behavior.
   - Phase 1 therefore does **not** require a non-zero `CHIP_ID` for portable conformance, freshness, or admission meaning.
   - A verifier MAY preserve the exact bytes and MAY apply explicit local policy to a present/non-zero or zero `CHIP_ID`, but the portable D-ATTEST seam does not assume one stable always-present hardware identifier.

3) **`CHIP_ID` does not substitute for signer-class selection, trust-root validation, or certificate-source policy**
   - A verifier MUST still validate the report signature chain under the already-pinned certificate-source rule and MUST still choose accepted signer classes under explicit local policy.
   - `CHIP_ID` may help local tooling relate a report to chip-rooted certificate workflows when such workflows are explicitly configured.
   - Phase 1 still does **not** let `CHIP_ID` choose trust roots, override accepted signer class, or turn host-delivered endorsement material into authority.

4) **`CHIP_ID` does not define portable fleet/asset identity, same-machine continuity, or anti-cloning truth**
   - Matching exact `CHIP_ID` bytes across two reports may be useful to deployment-local audit or hardware inventory.
   - Phase 1 still does **not** normalize those observations into a portable “same physical host”, “same tenant slot”, “same approved asset”, “non-migrated machine”, or “clone detected” claim.
   - In particular, `CHIP_ID` MUST NOT become a portable admission predicate for the four product shapes unless explicit verifier-local policy says so, and even then that remains deployment-local rather than native SlopOS meaning.

5) **`CHIP_ID` does not substitute for `boot_digest`, `prov_digest`, exact `cc_report_data_v0` binding, freshness, or `REPORT_ID`**
   - A verifier MUST still check the already-pinned boot/provenance/report-data/freshness surfaces separately.
   - Matching, differing, masked, or absent `CHIP_ID` values do **not** satisfy `PO-ATTEST-VERIFY`, do **not** replace freshness binding under `PO-ATTEST-FRESH`, and do **not** redefine which `CH-BOOT` / provenance bundle / guest instance was actually admitted.
   - In particular, `CHIP_ID` MUST NOT become a hidden nonce, replay oracle, durable session selector, or substitute proof that the exact D-CC binder contract was satisfied.

6) **Any appraisal of `CHIP_ID` remains explicit verifier-local policy**
   - A deployment-specific verifier MAY preserve, compare, ignore, or reject exact `CHIP_ID` bytes for local audit or asset policy.
   - That appraisal remains **explicit verifier-local policy** under D-POLICY rather than a portable SlopOS default.
   - Different deployments may therefore ignore, require, mask-tolerate, or correlate the same exact `CHIP_ID` evidence differently without changing the portable D-ATTEST seam.

7) **Packaging/export does not upgrade `CHIP_ID` into normalized claim space**
   - `CH-ATTESTPACK v0` may carry exact SNP report bytes that contain `CHIP_ID`.
   - If tooling wants to preserve decoded values for audit, it SHOULD do so as exact external evidence artifacts (for example via `CH-AREF` or release-bundle packaging) rather than widening `CH-ATTEST` or `CH-ATTESTPACK` into a portable chip-identity schema.
   - Exporting an SNP report that carries `CHIP_ID` does not imply that remote consumers may treat the field as reviewed SlopOS-native machine, asset, or anti-cloning meaning.

8) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing SNP report field.
   - It introduces no new workflow kind, no serialization surface, and no attester-side chip-identity query, asset registry, or fleet-correlation plane.

## Phase 1 non-goals (explicitly deferred)

- No `chip_id` field in `CH-ATTEST v0`.
- No portable same-hardware / same-asset / anti-cloning claim derived from `CHIP_ID`.
- No default secret-release, lease-renewal, or vault namespace rule keyed by `CHIP_ID`.
- No `IF-ATTEST` selector/query surface for exact chip IDs or fleet lookup.

## Why this boundary exists

The archive had already fixed the binder, certificate-source, host-field, owner-identity, TCB-field, guest-policy, report-identity, and guest-mode seams, but one implementation fork remained likely:
- AMD’s materials describe `CHIP_ID` as a unique chip identifier and as linkage material for the attestation signer certificate,
- the firmware ABI also allows `CHIP_ID` to be masked to zero,
- cloud/substrate operators and secret-release systems naturally want a stable hardware identifier,
- and asset/host identity is exactly the sort of tempting provider-native meaning that silently widens a portable attestation seam.

Without one explicit rule, the first verifier, release gate, or hosted rollout path would predictably do one of these by convention:
- treat `CHIP_ID` as the portable SlopOS machine/host identifier,
- require a non-zero `CHIP_ID` for portable conformance even though the ABI allows it to be masked,
- or key asset allowlists / continuity / anti-cloning / release namespaces to provider-native chip identity instead of the already-pinned binder/provenance/freshness surfaces.

Pinning the rule now keeps the first implementation honest:
- **portable claim meaning stays on `CH-ATTEST`, `boot_digest`, optional `prov_digest`, and exact `cc_report_data_v0` binding**,
- **`CHIP_ID` stays exact evidence unless explicit verifier-local policy says more**,
- **masked chip identifiers do not silently fail portable conformance**, and
- **automation cannot inherit a hidden provider-native asset taxonomy through the core attestation seam**.

## Profile effect (A–D)

- **Secure workstation (A):** workstation-side verifiers may preserve exact `CHIP_ID` bytes for audit or managed-fleet checks without importing one cloud/provider-native hardware identifier as portable workstation semantics.
- **Cloud micro-VM substrate (B):** hosted verifiers can correlate exact `CHIP_ID` bytes inside deployment-local policy, but they do not get a portable “same approved host” or anti-cloning shortcut for secret release, rollout, or admission.
- **Embedded / separation-kernel-ish appliance (C):** imported SNP evidence may retain exact `CHIP_ID` bytes for audit, but appliance posture does not widen into a cross-provider hardware-identity taxonomy just because one cloud/provider flow carried a chip identifier.
- **Agent / automation OS (D):** agents can inspect exact `CHIP_ID` evidence, but they do not gain a hidden hardware-identity shortcut; any asset-correlation interpretation remains transcript-visible, reviewable local policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this SNP chip-identity meaning seam.

If a second closely related D-CC SNP chip-identity boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-POLICY**, **D-AREF**.
- Adjacent seams:
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `confidential-computing-snp-launch-identity-claim-boundary-v0.md`
  - `confidential-computing-snp-tcb-field-claim-boundary-v0.md`
  - `confidential-computing-snp-policy-claim-boundary-v0.md`
  - `confidential-computing-snp-report-identity-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `verification-policy-selection-boundary-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**, **A-ATTEST-2**.
  - **I-ATTEST-1**, **I-AREF-1**, **I-POLICY-1**.
  - **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_chip_id_claim_boundary.py` (**EVID-2026-543**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-SNP-ATTEST-PDF.
- REF-RATS-RFC9334.
