# MicroVM display/input posture v0 (no portable ambient guest-visible graphics/input device contract)

Purpose: pin the **Phase 1** meaning of guest-visible display and input virtualization under `ext.microvm` so virtio-gpu scanouts, cursor/mode-setting state, virtio-input events, and renderer/acceleration folklore do not quietly become a reviewed host↔guest UI/control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-UICAP**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible display/input device contract under `ext.microvm`; there is no portable `virtio-gpu` / scanout-EDID-cursor-capset / `virtio-input` / raw-input-event-device-inventory plane, owner-local renderer-backend/input-plumbing choice stays implementation-local, and UI/capture/remote-control meaning still rides on explicit D-UICAP / D-PLUMB seams rather than ambient guest devices.**

Entropy cost justification: the archive already keeps host↔guest transports killable, debug consoles non-interactive, and backend offload implementation-local, but the graphics/input ecosystem is exactly where modern VMMs quietly regrow ambient host channels: paravirtual GPUs, display-scanout protocols, evdev-backed input daemons, and fast-moving renderer stacks such as rutabaga/gfxstream/virgl. One narrow posture closes that gap without inventing a display protocol, guest agent, or new schema family.

## Posture (v0)

1) **No portable ambient guest-visible display/input device contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible display/input device contract.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one standard in-guest display adapter, one stable pointer/keyboard device model, or one blessed host-backed graphics/input stack.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one stable guest UI device vocabulary exists with portable display/input behavior.”

2) **No portable `virtio-gpu` / scanout-EDID-cursor-capset plane**
   - Phase 1 standardizes **no portable `virtio-gpu` / scanout-EDID-cursor-capset plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about display-head inventory, scanout count, display hotplug, EDID contents, cursor update/control behavior, 2D/3D capset inventory, mode-setting, or renderer capability discovery.
   - Implementations may locally expose a virtio GPU, one or more scanouts, VGA-compatibility quirks, virgl/Venus/gfxstream/rutabaga-backed acceleration, or no guest-visible display at all for one deployment class, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **No portable `virtio-input` / raw-input-event-device-inventory plane**
   - Phase 1 standardizes **no portable `virtio-input` / raw-input-event-device-inventory plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about keyboards, mice, tablets, absolute vs relative pointer devices, button/key inventories, evdev-style event transport, input-device hotplug, or “host pointer/keyboard is attached to this guest now” workflows.
   - Implementations may locally wire host input through virtio-input, evdev polling daemons, remote-control bridges, or no input device at all, but those choices remain implementation-local and must not silently become portable interface meaning.

4) **Owner-local renderer, display-forwarding, and input plumbing stay implementation-local**
   - Owner-local renderer, display-forwarding, and input plumbing stay implementation-local.
   - Runtimes may choose internal device emulation, `vhost-user-gpu`, `vhost-user-input`, rutabaga/gfxstream/virgl-style acceleration, shared-memory scanout exchange, or other deployment-local plumbing, but that does **not** create a portable reviewed promise about one renderer stack, one display-forwarding protocol, one cursor/input latency model, or one host-side control/status API.
   - In particular, backend sockets, shared-memory file descriptors, evdev paths, render-node selection, and renderer feature negotiation remain host/runtime-local mechanism, not portable SlopOS interface meaning.

5) **UI authority stays on explicit D-UICAP / D-PLUMB seams**
   - UI authority stays on explicit D-UICAP / D-PLUMB seams.
   - Screen capture, remote display, remote control, automation, clipboard/drag-drop transfer, secure-attention entry, and high-risk input injection continue to ride on already-pinned UI/compositor and portal workflows rather than ambient guest display/input devices.
   - A guest-visible display or input device may help one implementation render pixels or deliver local events, but it does **not** become the portable authority seam for trusted UI, capture, or remote-control meaning.

6) **Changing the display/input stance is owner-local lifecycle or new admission, not a portable live control plane**
   - Changing the display/input stance is owner-local lifecycle or new admission, not a portable live control plane.
   - Owners/runtimes may choose different local graphics/input configurations for different reviewed leaves or deployment classes, and they may revise those choices across upgrades, but they may **not** reinterpret a running leaf as carrying a portable display-hotplug, mode-change, input-attach, or renderer-status protocol under the same admitted identity.
   - If policy cares about a different guest-visible display/input stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden host↔guest UI/control contract by convention.

7) **No new externally visible action surface is admitted in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for display/input state, **no new ACP kind**, and **no new conflict-key family** for scanout creation, mode-setting, EDID mutation, cursor/image updates, input-device attach/detach, or host input injection under `ext.microvm`.
   - No externally visible action is admitted here, so this posture introduces **no new commutativity claim** in Phase 1.
   - If a later design wants portable actions such as `attach_display`, `set_mode`, `inject_pointer`, `inject_keyboard`, `query_scanouts`, or `query_renderer_caps`, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity preconditions, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that microVM guests always see one standard display adapter or input-device inventory.
- No portable multi-head / display hotplug / EDID / cursor / renderer-capset contract under `ext.microvm`.
- No portable pointer/keyboard/tablet attach or raw input injection contract under `ext.microvm`.
- No generic display broker, input daemon, remote display protocol, or guest UI agent API.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-UICAP, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `uicap-scope-posture-v0.md`
- Adjacent notes:
  - `host-guest-channel-posture-v0.md`
  - `capture-portal-posture-v0.md`
  - `ui-automation-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-25)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-DISPLAYINPUT)
- Policy posture:
  - display/input virtualization adds **no new lane**, **no public guest UI device control plane**, and **no portable in-place display/input mutation protocol** in Phase 1.

CI drift gate:
- `tools/check_microvm_display_input_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible display/input contract / no portable `virtio-gpu`-scanout-EDID-cursor-capset plane / no portable `virtio-input`-raw-input-event-device-inventory plane / owner-local renderer-backend and input plumbing stay implementation-local / UI authority stays on explicit D-UICAP and D-PLUMB seams / changing display-input stance is owner-local lifecycle or new admission not a portable live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-VIRTIO-1.3.
- REF-QEMU-VHOST-USER-GPU.
- REF-QEMU-VHOST-USER-INPUT.
- REF-RUTABAGA-GFX.
