# Attention durable-status boundary v0 (transient cues are not durable truth)

Purpose: keep **D-ATTN** semantically small by freezing one adjacent rule that easily drifts in real systems: transient notifications, toasts, banners, and status glows may request or focus attention, but they do **not** become the durable carrier of consequential outcome, approval, or next-step truth.

This is intentionally a **boundary** doc, not a new schema. It narrows how existing surfaces fit together:
- **CH-NOTIF v0** remains an ephemeral request seam for attention.
- **CH-RECEIPT v0** and durable route/state surfaces remain the portable place where consequential outcomes are reconstructed.
- **D-EXPLAIN** keeps approvals, summaries, and results bound to explicit artifacts rather than to whichever transient message happened to flash on-screen.

## Decision (v0)

1) **Transient attention cues stay transient**
   - Notifications, snackbars, banners, inline status glows, and similar short-lived attention surfaces may announce or summarize state, but they remain **presentation cues**, not durable state objects.
   - Presentation, auto-dismissal, dismissal by the user, stacking order, or animation timing MUST NOT become the only portable evidence that something happened.

2) **Durable outcome truth lives on explicit receipt/state surfaces**
   - If an action succeeds, fails, widens authority, creates a reference number, changes durable state, or demands a next step, that truth MUST remain reconstructible from explicit route/state/receipt surfaces after the transient cue disappears.
   - In the current archive that means outcomes bind to stable artifacts such as **CH-RECEIPT v0**, transcript-visible denial/result surfaces, and reviewable route state rather than to a vanishing attention render.

3) **No hidden authority from seen/dismissed/timed-out presentation**
   - The privileged side MUST NOT infer approval, acknowledgement, durable delivery, or safe-to-forget state merely because a transient cue was rendered, timed out, or was dismissed.
   - “The toast appeared” is not an approval token, not a receipt, and not a replayable proof that the user saw or accepted the consequence.

4) **Notification actions may launch workflows, but their durable meaning stays elsewhere**
   - CH-NOTIF actions may bind to exact route or ACP intents, but the resulting consequential state still has to land on explicit durable surfaces.
   - A notification click may be the entry point for a workflow; it is not allowed to be the only durable record of what the workflow concluded.

5) **Any future durable inbox/history/status surface must return as its own RFC-first seam**
   - If SlopOS later needs a portable durable inbox, notification history, acknowledgement ledger, or replayable status center, that must return as a **separate RFC-first surface** with its own schema, retention, privacy, and policy rules.
   - CH-NOTIF v0 does not widen in place into that role.

## Why this boundary exists

- **Keeps D-ATTN honest:** attention request semantics stay separate from durable state semantics.
- **Keeps D-EXPLAIN honest:** approvals and outcomes remain bound to explicit summaries/receipts rather than to UI happenstance.
- **Prevents UI-folklore drift:** transient chrome can vary by policy, platform, focus mode, channel settings, and accessibility presentation; durable truth cannot depend on catching that moment.

## Imported ecosystem pattern

- **XDG Desktop Portal Notification** is a small send/withdraw portal and does not tell the requester whether the user actually saw the alert.
- **Android notification channels** make presentation policy and interruption behavior user/policy controlled rather than payload-authoritative.
- **Apple critical alerts** treat stronger interruption as a separately entitled class, not as proof that transient presentation is itself the durable outcome record.

We import the pattern, not the whole product stack: **transient attention cues may help users notice something, but durable consequence truth must remain on explicit receipt/state surfaces**.

## Consequences

- CH-NOTIF stays small and replay-stable.
- D-EXPLAIN / CH-RECEIPT keep their role as the durable audit surface for consequential outcomes.
- UI shells remain free to render rich transient cues without turning them into a hidden approval or history plane.

## Family membership (Phase 1)

This doc is now part of the closed **D-ATTN companion boundary family** enumerated in `attention-boundary-index.md`.

The promotion cost is paid explicitly: D-ATTN now has more than one closely related boundary seam, so discovery moves through one shared family index instead of leaving adjacent attention boundaries to linger as nominal singletons by inertia.

## Wiring

- Decision surface: `decision-map.md` (D-ATTN).
- Companion family surface: `attention-boundary-index.md`.
- Current posture: `attention-lease-posture-v0.md`.
- Request surface: `notification-request-schema-v0.md` (CH-NOTIF v0).
- Durable consequence surface: `explain-posture-v0.md` and `consent-receipt-schema-v0.md` (CH-RECEIPT v0).
- History: `rfcs/0055-attention-authority-and-notifications.md`.
- CI drift gate: `tools/check_attention_durable_status_boundary.py` (EVID-2026-554).

## References

- REF-XDG-PORTAL-NOTIFICATION
- REF-ANDROID-NOTIF-CHANNELS
- REF-APPLE-CRITICAL-ALERTS
