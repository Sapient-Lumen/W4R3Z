# MicroVM page-tracking posture v0 (host-side guest-memory dirty/access tracking stays non-portable)

Purpose: pin the **Phase 1** meaning of host-side guest-memory dirty/access tracking under `ext.microvm` so dirty logs, dirty rings, page-access bitmaps, and dirty-rate folklore do not quietly become a portable ambient migration / snapshot / observation / throttling plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, **D-EPHEM**, and **D-OBS** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host-side guest-memory page-tracking contract under `ext.microvm`; there is no portable dirty-log / dirty-ring / page-access-bitmap / dirty-rate / working-set-estimation plane, owner-local write-protect / clear-and-reprotect / ring-sizing / throttling / diff-snapshot accounting policy stays implementation-local, and reviewed snapshot / migration / observation / performance meaning still rides on explicit snapshot / migration / admission / observation seams rather than ambient host-side page-tracking machinery.**

Entropy cost justification: the archive already pins guest-visible memory topology, host-side memory backing, host-side memory dedup, live migration, and snapshot/restore separately, but mainstream VMM stacks still invite one large ambient shortcut: treat host dirty-page and access-tracking machinery as neutral plumbing and then quietly let dirty logs, dirty rings, page-access heat maps, or dirty-rate throttles become portable semantics by convention. Real VMMs expose exactly those knobs for diff snapshots, migration convergence, and host-side tuning. One narrow posture closes that gap without inventing a portable page-tracking API, migration governor, or guest-visible memory-observation plane.

## Posture (v0)

1) **No portable ambient host-side guest-memory page-tracking contract**
   - **Phase 1 exposes no portable ambient host-side guest-memory page-tracking contract** under `ext.microvm`.
   - Portable reviewed meaning does **not** include “this microVM profile guarantees one stable host dirty-page tracking vocabulary, one stable access-bit harvesting vocabulary, or one portable page-delta accounting ABI across runtimes.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume one portable story exists for how the host tracks which guest pages were written, touched, or throttled since some prior checkpoint.”

2) **No portable dirty-log / dirty-ring / page-access-bitmap / dirty-rate / working-set-estimation plane**
   - There is **no portable dirty-log / dirty-ring / page-access-bitmap / dirty-rate / working-set-estimation plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable `KVM_GET_DIRTY_LOG` / dirty-log-bitmap contract, one stable dirty-ring enablement or sizing contract, one stable page-access bitmap / accessed-bit harvesting contract, one stable working-set estimation contract, one stable dirty-rate query or throttling contract, or one stable “diff snapshot exactness” story tied to one host-side tracking primitive.
   - Implementations may locally use dirty bitmaps, dirty rings, accessed/young-bit harvesting, `mincore()` approximations, write-protect-and-clear cycles, or equivalent mechanisms, but those choices do **not** become SlopOS portable interface meaning.

3) **Owner-local page-tracking policy stays owner-local and must not masquerade as a portable API**
   - Owners/runtimes may still choose one dirty-log mode, ring size, clear-and-reprotect discipline, huge-page split policy, page-access sampling strategy, dirty-rate limiter, or diff-snapshot accounting method locally.
   - What they may **not** do in Phase 1 is turn that owner-local policy into a portable reviewed host-side guest-memory page-tracking contract for an already admitted leaf.
   - If a deployment cannot honor one local page-tracking strategy, the correct Phase 1 outcomes are to admit a different reviewed leaf/activation, keep the difference owner-local, or fail closed — not to grow a new portable in-place page-tracking meaning by convention.

4) **Existing explicit seams remain authoritative**
   - Reviewed snapshot meaning still rides on `microvm-snapshot-posture-v0.md` and explicit owner-local lineage/admission evidence, not on an ambient promise that one dirty-page tracker yields one portable diff-snapshot truth.
   - Reviewed continuity meaning still rides on `microvm-live-migration-posture-v0.md`, generation witnesses, repair barriers, and attestation freshness seams rather than on ambient dirty-rate, convergence, or page-heat counters.
   - Reviewed memory meaning still rides on already-pinned memory-topology / memory-backing / memory-dedup seams rather than on ambient host-side page-delta or page-access folklore.
   - Reviewed observation meaning still rides on explicit D-OBS artifacts rather than on ambient page-dirty / page-access status surfaces becoming a stealth host inspection plane.

5) **Changing host-side guest-memory page-tracking stance is owner-local lifecycle or new admission, not a portable live control or observation plane**
   - Owners/runtimes may vary dirty tracking, access tracking, or dirty-rate limiting across reviewed leaves, deployment classes, or owner-local lifecycle operations.
   - They may **not** reinterpret a running leaf as carrying a portable page-tracking control/status protocol under the same admitted identity.
   - If policy cares about a different page-tracking stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden `query_dirty_pages`, `set_dirty_ring_size`, `read_page_access_bitmap`, `set_dirty_rate_limit`, or `toggle_track_dirty_pages` plane by convention.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `query_dirty_set`, `set_dirty_limit`, `toggle_page_access_tracking`, or `export_working_set_map` must say whether it commutes with activation, snapshot/restore, migration, crash capture, debug inspection, and admission policy, and where serialization lives.
   - Until then, page-tracking ordering, throttling, and rollback remain owner-local runtime concerns rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable host-side dirty-page log / dirty-ring / page-access tracking semantics under `ext.microvm`.
- No portable diff-snapshot exactness guarantee tied to one tracking primitive.
- No portable dirty-rate query / limit / throttle contract.
- No portable working-set / page-heat / access-bitmap telemetry contract.
- No claim that page-tracking success is an acceptable portable substitute for explicit snapshot / migration / observation seams.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-EPHEM, D-OBS)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `microvm-memory-backing-posture-v0.md`
  - `microvm-memory-dedup-posture-v0.md`
  - `microvm-live-migration-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-52)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-PAGETRACK)
- Policy posture:
  - host-side guest-memory page tracking adds **no new lane**, **no portable page-delta-or-access telemetry plane**, and **no portable dirty-rate control plane** in Phase 1.

CI drift gate:
- `tools/check_microvm_page_tracking_posture.py` fails `make lint` if this posture stops being discoverable, loses its no-portable-contract / no-portable-dirty-log-or-dirty-ring-plane / owner-local-policy / explicit-snapshot-migration-observation-seams / no-live-control-or-observation-plane / no-new-schema-or-ACP constraints, or drops its assurance/reference wiring.

## References

- REF-KVM-API.
- REF-QEMU-DIRTY-RING.
- REF-QEMU-DIRTYLIMIT.
- REF-QEMU-MIGRATION.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
