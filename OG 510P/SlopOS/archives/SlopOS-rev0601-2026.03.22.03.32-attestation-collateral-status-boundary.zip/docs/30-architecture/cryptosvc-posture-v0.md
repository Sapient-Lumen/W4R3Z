# D-CRYPTOSVC posture v0 (op-only handles; explicit-route only; no ambient agent socket)

Purpose: pin an **implementable Phase 1** meaning for D-CRYPTOSVC so “keys as capabilities” stays small,
reviewable, and compatible with the archive’s no-ambient-authority posture.
It is the posture-level refinement of the older **D-AUTHAGENT** seam into a tighter, more reviewable cross-component crypto contract.

This doc deliberately narrows a high-entropy seam. It says what a Phase 1 crypto provider *is* and what it is *not*:
a small op-only service with explicit routes, pinned policy, and redaction-safe audit — **not** a global agent socket,
not a generic crypto broker, and not a slot/session/object inventory API.

## Posture (v0)

1) **No ambient agent discovery or socket convention**
   - If D-CRYPTOSVC is enabled, clients reach a crypto provider only via explicit capability routes / handles.
   - Phase 1 does **not** claim `SSH_AUTH_SOCK`-style path/env discovery, a magic per-user socket, implicit smartcard scans, or an ambient provider namespace.
   - Sealed compat remains honest: Foreign Cells do not inherit a host auth-agent socket by default; any interop must come back through explicit adapters and policy-killable routing.

2) **Op-only, closed external surface**
   - The v0 cross-component surface is a **closed op set**: `sign`, `decrypt`, `derive`, `attest`.
   - Phase 1 does **not** claim a generic mechanism-dispatch API, portable mechanism/algorithm-capability discovery semantics, caller-chosen padding/mode/hash/curve tuning semantics, portable key generation/rotation/deletion semantics, portable deriveBits/deriveKey/raw-secret/wrap-unwrap/export-result semantics, portable attestation quote/report/token, nonce/challenge, evidence-format, or verifier-policy semantics, portable verification / trust-evaluation semantics, `encrypt` as an ambient service, slot/session/object browsing, provider-global key search, portable key inventory/search/query semantics, portable provider/backend/slot/token/reader selection semantics, portable PIN/biometric/presence/unlock semantics, or arbitrary key-management verbs on the core seam.
   - Private key bytes remain non-exportable (I-AUTHAGENT-1, I-CRYPTO-1).

3) **Policy is pinned as data, not inferred from call sites**
   - Every durable/exportable reference is mediated by **CH-KEYPOL v0** and/or **CH-KEYREF v0**.
   - A provider MUST fail closed if a requested op is outside `ops`, if required context/purpose data is missing, or if the effective policy pin does not match.
   - “What key is this allowed to do?” remains reviewable as data rather than hidden in code paths or provider-specific defaults.

4) **Context-bound use is the expected v0 posture**
   - When `contexts` is present in CH-KEYPOL, each operation supplies **exactly one** context string and providers enforce it fail-closed.
   - Empty / omitted context is an explicit narrower posture for strictly local cases, not the default shape for reusable signing authority.
   - This keeps D-CRYPTOSVC from silently becoming a cross-protocol signing/decrypt oracle.

5) **Handles and explicit refs, not inventory APIs**
   - Durable handoff/persistence uses **CH-KEYREF v0**.
   - Phase 1 does **not** claim an app-visible “list all keys”, label search, provider-global enumeration, or smartcard/token inventory surface.
   - Discovery happens by explicit handoff / routing / persistence, not by ambient lookup.

6) **Confirmation and rate limits are explicit policy, not hidden UI behavior**
   - `confirm` and `rate` in CH-KEYPOL are provider-enforced policy choices.
   - If confirmation is required, approval is an explicit decision path; if rate limits apply, rejections are deterministic and audit-visible.
   - Phase 1 does **not** claim silent downgrade, opportunistic bypass, or background policy changes via agent forwarding magic; `cryptosvc-forwarding-boundary-v0.md` freezes cross-boundary use to explicit narrowed routes only, `cryptosvc-interactive-auth-boundary-v0.md` further freezes prompt modality, token-login state, biometric/presence semantics, and cached-auth windows as provider-local rather than generic crypto-service meaning, `cryptosvc-mechanism-boundary-v0.md` further freezes mechanism/property discovery plus caller-tunable padding/mode/hash/curve profiles as provider-local/setup-local rather than generic crypto-service meaning, `cryptosvc-key-material-boundary-v0.md` further freezes secret-bearing key import/export, backup/restore, escrow, and migration-blob semantics as provider-local/setup-local rather than generic crypto-service meaning, `cryptosvc-key-lifecycle-boundary-v0.md` further freezes key generation, rotation, alias-retargeting, deletion, and lifecycle-admin semantics as provider-local/setup-local rather than generic crypto-service meaning, `cryptosvc-derived-material-boundary-v0.md` further freezes raw-shared-secret, wrap/unwrap, and derived-key materialization semantics as provider-local/setup-local rather than generic crypto-service meaning, and `cryptosvc-attestation-boundary-v0.md` further freezes quote/report/token selection, nonce/challenge relay, attestation evidence, endorsement fetch, and verifier-policy semantics onto explicit D-ATTEST / CH-ATTEST / CH-ATTESTPACK surfaces rather than generic crypto-service meaning, and `cryptosvc-verification-boundary-v0.md` further freezes signature-verification, certificate-path, trust-root, and verifier-policy semantics onto explicit D-SIGENV / D-KEYLESS surfaces rather than generic crypto-service meaning.

7) **Audit is digest-first and redaction-safe**
   - Crypto use is represented by **CH-CRYPTOAUDIT v0** embedded/referenced from CH-LOG.
   - Audit surfaces carry digests, lengths, policy pins, and short reason codes — not raw key bytes and not plaintext payloads unless an explicitly declared safe profile says otherwise.
   - Observation/export policy still governs whether any transcript leaves the box.

8) **Hardware backing is a profile annex, not an API fork**
   - TPM/TEE/Secure Enclave style backing may strengthen the provider implementation, but the cross-component seam remains CH-KEYPOL / CH-KEYREF / CH-CRYPTOAUDIT.
   - Phase 1 does **not** widen the API just because some deployments have hardware-backed keys.

## Phase 1 non-goals (explicitly deferred)

- **No ambient `SSH_AUTH_SOCK` / path / env agent discovery**.
- **No provider-global key inventory/search API**.
- **No PKCS#11-style slot/session/object model on the core seam**.
- **No raw private-key export/import on the app-facing seam**.
- **No ambient network agent forwarding or transparent remote broker semantics**.
- **No generic bulk-encryption / “crypto syscall” service** under D-CRYPTOSVC.
- **No portable key inventory/search/query surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-inventory-boundary-v0.md`.
- **No portable provider/backend/slot/token/reader selection surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-provider-selection-boundary-v0.md`.
- **No portable PIN/biometric/presence/unlock surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-interactive-auth-boundary-v0.md`.
- **No portable mechanism/algorithm-capability/padding-mode surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-mechanism-boundary-v0.md`.
- **No portable secret-bearing key import/export / backup-restore / key-blob migration surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-key-material-boundary-v0.md`.
- **No portable key generation / rotation / deletion / lifecycle-admin surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-key-lifecycle-boundary-v0.md`.
- **No portable deriveBits/deriveKey/raw-secret/wrap-unwrap/export-result surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-derived-material-boundary-v0.md`.
- **No portable quote/report/token / nonce-challenge / attestation-verifier-policy surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-attestation-boundary-v0.md`.
- **No portable verify / certificate-path / trust-store surface** on generic crypto use; that boundary is pinned separately in `cryptosvc-verification-boundary-v0.md`.

## Wiring

- Decision surface: `decision-map.md` (D-CRYPTOSVC).
- Interface surface: `interface-registry.md` (IF-CRYPTOSVC).
- Closed companion boundary family: `cryptosvc-boundary-index.md`.
- Cross-boundary delegation boundary: `cryptosvc-forwarding-boundary-v0.md`.
- Inventory/search boundary: `cryptosvc-inventory-boundary-v0.md`.
- Provider/backend selection boundary: `cryptosvc-provider-selection-boundary-v0.md`.
- Interactive-auth boundary: `cryptosvc-interactive-auth-boundary-v0.md`.
- Mechanism/capability boundary: `cryptosvc-mechanism-boundary-v0.md`.
- Key-material boundary: `cryptosvc-key-material-boundary-v0.md`.
- Key-lifecycle/admin boundary: `cryptosvc-key-lifecycle-boundary-v0.md`.
- Derived-material boundary: `cryptosvc-derived-material-boundary-v0.md`.
- Attestation/evidence boundary: `cryptosvc-attestation-boundary-v0.md`.
- Verification/trust-evaluation boundary: `cryptosvc-verification-boundary-v0.md`.
- Schema surfaces:
  - `key-policy-schema-v0.md` (CH-KEYPOL v0)
  - `keyref-schema-v0.md` (CH-KEYREF v0)
  - `crypto-audit-schema-v0.md` (CH-CRYPTOAUDIT v0)
- Related mechanism notes:
  - `mechanisms.md` (keys-as-capabilities / provider posture)
  - `app-secret-posture-v0.md` (minimal app seed; not a vault)
  - `microvm-tpm-surface-posture-v0.md` (under `ext.microvm`, guest-visible TPM/vTPM devices stay non-portable and do not replace explicit `CH-KEYPOL` / `CH-KEYREF` meaning)
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-AUTHAGENT-1, I-CRYPTO-1, I-CRYPTO-2, I-CRYPTO-3, I-CRYPTO-6, I-CRYPTO-8, I-CRYPTO-9)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-AUTHAGENT-NONEXPORT, PO-CRYPTOAUDIT-REDACT, PO-CRYPTOPOL-ENF, PO-CRYPTOSVC-ENF, PO-CRYPTOATTEST-BOUNDARY, PO-CRYPTOLIFECYCLE-BOUNDARY, PO-CRYPTOVERIFY-BOUNDARY)

CI drift gate:
- `tools/check_cryptosvc_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “explicit-route only / no ambient agent socket / no inventory / no portable provider chooser / op-only” constraints, or drops its primary REF wiring.

## References

- REF-PLAN9-FACTOTUM.
- REF-OPENSSH-AGENTRESTRICT.
- REF-ANDROID-KEYSTORE.
- REF-ANDROID-BIOMETRICPROMPT.
- REF-MICROSOFT-CNG-TYPICAL-PROGRAMMING.
- REF-W3C-WEBCRYPTO-2.
