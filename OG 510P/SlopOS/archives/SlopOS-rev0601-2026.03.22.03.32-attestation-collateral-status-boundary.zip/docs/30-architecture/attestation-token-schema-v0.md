# CH-ATTEST v0: attestation token payload-to-sign (optional)

Purpose: define a **small, stable payload** that a device can sign to allow a verifier to check **(a)** which boot state is running and **(b)** whether the signer is an accepted device identity.

This is intentionally **not** the full protocol: transport, signature container, endorsement retrieval, and verifier policy are out of scope.

Packaging note: **IF-ATTEST** typically exports a **CH-ATTESTPACK v0** bundle that carries the canonical CH-ATTEST bytes plus optional provider-native evidence blobs and endorsement pointers (see `attestation-pack-schema-v0.md`).

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Payload hashing is over the canonical bytes.
- Unknown fields/variants **MUST** be rejected by validators (fail-closed).

## Top-level fields

```text
CH-ATTEST-v0 {
  schema: "CH-ATTEST";
  version: 0;

  # Binding to local boot/provenance
  boot_digest: bytes32;          # digest(CH-BOOT canonical bytes)
  policy_revision: u64;          # monotonically increasing policy/config revision (if used)
  prov_digest?: bytes32;         # optional digest of CH-PROV payload/proof bundle

  # Device identity / signing context
  device_id: {
    kind: enum { dice_key, tpm_ek, tee_report_key, other };
    pubkey_hash: bytes32;        # hash of the public key used to verify the signature
    endorsement_digest?: bytes32;# optional digest of endorsement set; informational only
  };

  # Freshness (optional)
  freshness?: {
    kind: enum { none, nonce, challenge };
    nonce?: bytesN;              # verifier-provided nonce (bounded length)
    issued_at?: u64;             # optional monotonic counter/time, if claimed
  };

  # Claims payload (optional)
  eat_payload?: bytesN;          # optional EAT payload bytes (CBOR), bounded length
}
```

### Notes
- `boot_digest` is the **primary binding**: it ties the attestation to the measured boot record.
- `policy_revision` is included only if the deployment uses a monotonic policy counter (otherwise set 0 and treat as non-claim).
- `eat_payload` allows embedding an EAT claims set; verifiers may ignore it if the binding fields are sufficient.
- Under D-CC, embedded `eat_payload` claims remain profile-local evidence rather than widening `CH-ATTEST` into a portable claim registry or approval language (`confidential-computing-eat-payload-claim-boundary-v0.md`).
- `endorsement_digest` remains informational: it may name an exact supporting artifact, but it does not imply live retrieval, latest-applicable semantics, or verifier-policy replacement (`attestation-endorsement-boundary-v0.md`).
- `device_id` is a bounded signing-context summary only: mapping it to an accepted machine/asset/workload identity remains explicit verifier-local enrollment and policy rather than portable token meaning (`attestation-identity-boundary-v0.md`).
- Companion boundary `attestation-freshness-boundary-v0.md` further pins that `freshness` is an optional verifier-local binding input: nonce/challenge fields do not become a portable currentness/session claim or hidden nonce-service contract.
- Companion boundary `attestation-result-boundary-v0.md` further pins that token fields and supporting evidence do not by themselves create a native verifier-result or approval object; any imported verifier-generated result remains separate evidence.
- Companion boundary `attestation-collateral-status-boundary-v0.md` further pins that certificate chains, CRLs, OCSP responses, TCB-info / identity artifacts, and collateral cache snapshots remain exact supporting evidence under verifier-local freshness/cache policy; token fields do not by themselves mint a native latest-collateral or current-trust object.

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `boot_digest` must be exactly 32 bytes.
- `device_id.pubkey_hash` must be exactly 32 bytes.
- `nonce` length must be ≤ 64 bytes (bounded).
- `eat_payload` length must be ≤ 2048 bytes (bounded; can be reduced per profile).

## Binding rules
- Verifier computes `digest(CH-BOOT)` and checks equality to `boot_digest`.
- If `prov_digest` is present, verifier checks it matches the active provenance artifact referenced by CH-BOOT.
- Under `ext.microvm`, this provenance binding can support owner-local evidence about which admitted boot/provenance lineage is running, but it does **not** by itself identify one exact resumed warm-start leaf/checkpoint; Phase 1 adds no guest-visible leaf-id claim to `CH-ATTEST` (`microvm-attestation-scope-posture-v0.md`, `microvm-resume-admission-evidence-posture-v0.md`).
- If freshness is enabled, verifier must check the nonce/challenge binding according to the protocol profile.
- Verifier maps `device_id` to any accepted attester identity only under explicit local roots/enrollment/policy; token fields do not by themselves mint a portable machine/asset/workload identity (`attestation-identity-boundary-v0.md`).
Freshness/challenge inputs remain explicit verifier-local policy under `attestation-freshness-boundary-v0.md`; replay/currentness meaning does not arise from token fields alone.
Verifier-generated attestation results remain imported evidence under `attestation-result-boundary-v0.md`; token fields do not by themselves mint a native verifier-result or approval object.
Collateral status/freshness artifacts remain exact imported evidence under `attestation-collateral-status-boundary-v0.md`; token fields do not by themselves mint a native latest-collateral or current-trust object.

## Security posture
- CH-ATTEST is **observational**: producing it must not change privileged state.
- Secret material must not appear in CH-ATTEST; keys live behind D-AUTHAGENT / hardware RoT.
