# MicroVM time-source posture v0 (guest clocksource and wall-clock policy stay non-portable)

Purpose: pin the **Phase 1** meaning of guest-visible time-source and wall-clock policy under `ext.microvm` so runtime-specific clocksource selection, RTC basing, and clock-repair/admin folklore do not quietly become portable reviewed meaning.

This doc attaches to **D-MICROVM**, **D-NONDET**, **D-TIMEPROOF**, and **D-ACTIVATE** and makes one hard decision explicit:
**guest-visible clocksource identity, wall-clock base/progression policy, and any clock-admin path remain implementation-local rather than portable `ext.microvm` contract meaning.**

## Posture (v0)

1) **Clocksource identity is implementation-local**
   - **Phase 1 exposes no portable ambient guest-visible time-source contract.**
   - There is no portable reviewed guarantee for `kvm-clock`, emulated RTC, PIT-based wall-clock behavior, architecture timer naming, or any other guest-visible clocksource inventory/name plane under `ext.microvm`.
   - Guests may probe whatever the owner-local VMM/runtime exposes, but those source names and probe results do **not** become SlopOS portable API meaning.

2) **Wall-clock base and progression policy are implementation-local**
   - There is **no portable RTC-base / timezone / progression policy plane** under Phase 1.
   - UTC-vs-localtime-vs-fixed-datetime basing, host-clock-vs-monotonic-vs-virtual-clock progression, suspend-time progression policy, drift-fix heuristics, and similar runtime knobs remain owner-local implementation choices.
   - Restore/clone hygiene for clock trust stays governed by `microvm-clock-disruption-posture-v0.md`; this doc does **not** turn any local wall-clock policy into proof-bearing time.

3) **Guest clocks remain observational, not authority-bearing**
   - A guest-visible clocksource or wall clock may be useful for ordinary guest scheduling, logging, and best-effort coordination, but it is still **observational**.
   - It does **not** replace explicit SlopOS time authority on `portal.clock`, `portal.clock.timeproof.sample`, or `CH-TIMEPROOF`.
   - Token expiry, anti-rollback, freshness checks, and cross-node ordering claims remain on explicit existing time seams rather than ambient guest time reads.

4) **No portable clock-admin or source-switch plane is introduced**
   - Phase 1 adds **no portable guest-visible or guest-triggerable set-clock / rebase / source-select / timesync-complete / attach-PTP-like-device admin plane** under the same admitted leaf identity.
   - Owner-local VMM/runtime machinery may implement migration monotonicity repair, RTC initialization, or clocksource shaping, but that remains outside the reviewed portable guest contract.
   - If a future design wants an externally visible time-admin workflow, it must define its own ACP kind, conflict keys, serialization boundary, and evidence hooks explicitly.

5) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed clock-admin / resync / time-discipline surface must say whether it commutes with resume, activation, lease expiry, and timeproof sampling, and where serialization lives.
   - Until then, guest clocksource selection and wall-clock discipline remain owner-local runtime policy rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No guarantee that every `ext.microvm` implementation exposes `kvm-clock`.
- No portable guest clocksource list / selection / preference API.
- No portable RTC base/timezone configuration contract.
- No portable wall-clock set/repair/status callback plane.
- No claim that a guest-visible synchronized wall clock is itself a portable proof artifact.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-NONDET, D-TIMEPROOF, D-ACTIVATE)
- Adjacent postures:
  - `microvm-profile-posture-v0.md`
  - `microvm-clock-disruption-posture-v0.md`
  - `nondet-posture-v0.md`
  - `timeproof-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-32)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-TIMESOURCE)
- Policy posture:
  - guest-visible clocksource and wall-clock semantics add **no new lane**, **no new ambient host↔guest channel**, and **no new reviewed lifecycle-mutation plane**; authority-bearing time remains on explicit existing seams.

CI drift gate:
- `tools/check_microvm_time_source_posture.py` fails `make lint` if this posture stops being discoverable, loses the **non-portable clocksource / no portable RTC-base-or-progression policy / guest clocks observational only / no clock-admin plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-DESIGN.
- REF-KVM-API.
- REF-QEMU-RTC-CLOCK.
