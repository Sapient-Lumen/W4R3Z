# D-CC SNP VMPL-mode boundary v0 (Phase 1 reference target is fully enlightened VMPL0 only)

Purpose: pin the **Phase 1** meaning of the SNP-first D-CC implementation target so “AMD SEV-SNP support” does not silently stretch from one simple guest mode into the much larger **Multi-VMPL / SVSM / paravisor** design space.

Entropy cost justification: the archive already pinned one first provider target, one exact 64-byte binder contract, one certificate-source rule, and one `HOST_DATA` rule. What remained ambiguous was the next implementation fork inside that same provider target: **fully enlightened VMPL0 guests versus Multi-VMPL guests with an in-guest privileged service layer**. AMD’s own specs make that a real additional substrate, not a cosmetic flag. One small boundary closes that gap without inventing a new schema, service plane, or verifier language.

## Posture (v0)

1) **Phase 1 SNP-first reference target is a fully enlightened guest at VMPL0**
   - The first portable SNP-first D-CC binder/verifier path MUST target a guest operating system running **directly at VMPL0**.
   - The guest requests the attestation report using the already-pinned exact `cc_report_data_v0` contract and the verifier/appraisal path treats that as the Phase 1 reference target.
   - Portable conformance to the SNP-first Phase 1 target therefore means **fully enlightened VMPL0 guest mode**, not merely “some SNP report exists.”

2) **Multi-VMPL / SVSM / paravisor layouts are deferred to a future annex, not treated as co-equal Phase 1 targets**
   - AMD’s SNP ABI and GHCB specs expose real Multi-VMPL machinery: attestation requests carry a VMPL value, GHCB registration can become per-VMPL, and running vCPUs at another VMPL level is a distinct feature surface.
   - AMD’s SVSM spec then layers a guest-internal privileged-module environment, service discovery, calling conventions, and optional services such as attestation helpers and vTPM over that capability.
   - Phase 1 therefore does **not** claim one portable Multi-VMPL / SVSM / paravisor contract, and it does **not** block first implementation on solving that broader design space.

3) **Phase 1 verifier/appraisal policy for the SNP-first target must reject non-zero VMPL as portable conformance**
   - If a verifier claims conformance to the archive’s Phase 1 SNP-first D-CC target, it MUST require **VMPL = 0** in the provider-native SNP attestation evidence it appraises.
   - Exact SNP reports generated for higher VMPL values may still be preserved as exact evidence bytes for owner-local tools or future experiments, but they are **out of profile** for the Phase 1 portable target.
   - This keeps the first verifier small and fail-closed instead of quietly accepting both “direct guest” and “guest behind privileged in-guest mediator” under one label.

4) **SVSM/paravisor services do not become portable SlopOS attestation or control-plane meaning**
   - Phase 1 adds **no portable service-discovery / service-manifest / calling-area / vTPM / paravisor mediation plane** under D-CC.
   - If a deployment uses SVSM- or paravisor-style services locally, those services remain implementation-local and do not become reviewed SlopOS API meaning merely because the underlying hardware is SNP.
   - `CH-ATTEST` / `CH-ATTESTPACK` remain the portable export seam; they do not widen into “which SVSM services are present?” or “which paravisor mediated this guest?” claim space.

5) **Measurement and trust meaning stay on the already-pinned seams, not on a new VMPL-union rule**
   - The archive already pins one exact `REPORT_DATA` binding contract, one certificate-source rule, and one `HOST_DATA` rule.
   - Phase 1 now also declines any portable “union of VMPL0 service measurements plus VMPL1+ guest measurements” rule, any portable service-manifest appraisal rule, and any portable assumption that paravisor presence is equivalent to the fully enlightened VMPL0 target.
   - Any future non-VMPL0 acceptance or SVSM-aware appraisal must arrive as one explicit annex/RFC with its own evidence burden.

6) **No new workflow / ACP / conflict-key family appears in v0**
   - This boundary only narrows the meaning of one already-existing SNP-first implementation target.
   - It introduces **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.

## Phase 1 non-goals (explicitly deferred)

- No portable Multi-VMPL / SVSM / paravisor conformance profile.
- No portable SVSM service-discovery, calling-area, or vTPM semantics.
- No portable service-manifest appraisal or VMPL-union measurement rule.
- No Phase 1 SNP-first verifier profile that treats non-zero VMPL as equivalent to the fully enlightened VMPL0 target.

## Why this boundary exists

The archive had already chosen **AMD SEV-SNP first**, but “SNP-first” still hid another design fork:
- a **fully enlightened** guest OS running directly at VMPL0, or
- a **Multi-VMPL** guest with an SVSM/paravisor-like privileged module layer that mediates parts of the guest environment.

AMD’s own documents make that second branch materially larger: VMPL is an explicit report parameter, GHCB grows Multi-VMPL control surfaces, and the SVSM spec defines a separate in-guest privileged-service substrate with its own discovery and protocol semantics. Linux’s own CoCo documentation likewise shows that paravisor mode changes the guest architecture in practice: VMPL placement changes, some exceptions and hypercalls route differently, and device emulation / memory-transition behavior can move through the paravisor.

Pinning the rule now keeps the first implementation honest:
- **the first D-CC coding target is one direct VMPL0 guest path**,
- **the first verifier rejects non-zero VMPL for portable Phase 1 conformance**,
- **CH-ATTEST / CH-ATTESTPACK stay the portable seam instead of silently inheriting SVSM service meaning**,
- and **future SVSM/paravisor support, if it is worth doing, must pay for its own annex and evidence.**

## Profile effect (A–D)

- **Secure workstation (A):** workstation-hosted SNP experiments can preserve non-zero-VMPL reports as exact evidence, but the portable D-CC story remains the simpler direct VMPL0 guest target.
- **Cloud micro-VM substrate (B):** the first worth-coding hosted-compute target stays one direct SNP guest path instead of immediately taking on paravisor/SVSM service compatibility and verifier branching.
- **Embedded / separation-kernel-ish appliance (C):** appliance evidence handling can consume exact SNP report bytes without importing a second in-guest privileged-services substrate into the portable appliance core.
- **Agent / automation OS (D):** agents can inspect exact evidence from non-zero-VMPL deployments, but they do not get a hidden “paravisor present means acceptable” shortcut; any broader acceptance stays explicit local policy or a future annex.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this confidential-computing guest-mode seam.

If a second closely related D-CC SNP guest-mode / SVSM / paravisor boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-CC**, **D-ATTEST**, **D-MICROVM**, **D-XS**.
- Adjacent seams:
  - `confidential-computing-reference-target-boundary-v0.md`
  - `confidential-computing-reportdata-binding-boundary-v0.md`
  - `confidential-computing-snp-certificate-source-boundary-v0.md`
  - `confidential-computing-snp-hostdata-claim-boundary-v0.md`
  - `attestation-posture-v0.md`
  - `attestation-pack-schema-v0.md`
  - `microvm-paravirt-enlightenment-posture-v0.md`
- Threat / assurance anchors:
  - **A-CC-1**.
  - **I-ATTEST-1**, **I-MICROVM-36**.
  - **PO-ATTEST-VERIFY**, **PO-MICROVM-PARAVIRT**, **PO-XS-CLOSESET**.
- Discovery / CI:
  - `tools/check_confidential_computing_snp_vmpl_mode_boundary.py` (**EVID-2026-538**).

## References

- REF-AMD-SNP-FWABI.
- REF-AMD-GHCB.
- REF-AMD-SVSM.
- REF-LINUX-HYPERV-COCO.
