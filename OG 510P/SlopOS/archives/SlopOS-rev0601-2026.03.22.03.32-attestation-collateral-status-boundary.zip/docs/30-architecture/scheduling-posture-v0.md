# D-SCHED posture v0 (TCap-first portable scheduling; no ambient priority/class plane)

Purpose: pin an implementable **Phase 1** meaning for **D-SCHED** so CPU scheduling stays an explicit authority/accounting seam rather than quietly becoming a bag of inherited host thread attributes, ambient priority/class folklore, or a generic QoS/admin API.
It narrows the decision-map stub and RFC-0049 into one compact posture adjacent to **D-TCAP**, **CH-TCAP v0**, **D-METER**, **D-RSEQ**, **D-TURNS**, and the existing capshell launch-normalization boundary.

## Posture (v0)

1) **TCap-first portable scheduling authority**
   - If **D-TCAP** is enabled, portable reviewed CPU-time authority flows only through explicitly bound or donated temporal capabilities described by **CH-TCAP v0**.
   - Scheduler enforcement/charging therefore rides on **I-TCAP-1** and **PO-TCAP-ENF** rather than on an ambient per-thread scheduler state plane.
   - In plain terms: runnable time is something you explicitly hold or are explicitly donated; **D-SCHED** does **not** add a second hidden authority path alongside D-TCAP.

2) **Closed urgency vocabulary; no host-native numeric priority/class contract**
   - Portable reviewed scheduling intent is the bounded **CH-TCAP v0** envelope: `budget_us`, optional `period_us`, closed `priority = low|normal|high|critical`, optional `overrun_policy`, and optional donation flags.
   - Phase 1 does **not** standardize raw POSIX `nice` values, host-specific real-time/deadline numeric priorities, process priority classes, utilization clamps, CPU-share weights, or timeslice/quantum tuning as portable application meaning.
   - If a provider/runtime imports those host knobs locally, that remains implementation-local beneath explicit TCap admission or compat adaptation, not a new native contract.

3) **Passive servers run on donated time, not scheduler magic**
   - When donation is enabled, the portable way for a server to run “on the caller’s time” is **passive service + synchronous TCap donation** under **I-TCAP-2**, **I-TCAP-3**, and **PO-TCAP-DONATE**.
   - Phase 1 deliberately declines a portable priority-inheritance / boost / deboost protocol, lock-coupled scheduler side channel, or “blocked caller implies free server time” folklore.
   - Borrowed time must be returned on reply/abort; no TCap duplication or retained borrowed runtime is portable meaning.

4) **No portable self/peer scheduling mutation plane in v0**
   - Phase 1 exposes **no portable self/peer scheduler-tuning API** equivalent to “raise/lower this thread’s priority”, “switch this thread into a special scheduler class”, or “retune this process group’s CPU policy”.
   - This is the system-level counterpart to `capshell-scheduling-posture-v0.md`: reviewed launch meaning is normalized and the generic native surface also declines a post-launch ambient scheduler-control plane.
   - If a deployment needs local scheduler knobs for operators or compat runtimes, they remain owner-local and killable, not portable SlopOS semantics.

5) **No portable fairness / share / latency promise in the generic seam**
   - Phase 1 does **not** claim one portable fairness algorithm, one exact wakeup-latency bound, one exact quantum length, one exact runqueue discipline, or one cgroup/job-tree share model.
   - Stronger guarantees belong either to explicit profile extensions (for example static partitioning) or to explicit temporal-capability budgets, not to ambient scheduler folklore.
   - This keeps the proof surface small: D-SCHED exports explicit authority/accounting hooks, not a full scheduler policy language.

6) **No portable global scheduler inventory or oracle**
   - Phase 1 adds no portable API for “list runnable threads”, “show current scheduler class/priority of arbitrary peers”, “dump runqueue topology”, “query exact per-thread quanta”, or “who preempted whom”.
   - Adjacent seams already own the bounded observable pieces: CPU-local fast-path invalidation and cached CPU ids stay on **D-RSEQ** / **D-NONDET**; coarse contention stays on **D-PRESSURE**; explicit waits stay on **D-WAITSET** / **D-UWAIT**.
   - This prevents D-SCHED from becoming a hidden timing/topology oracle.

7) **No new workflow / ACP / conflict-key family in v0**
   - Phase 1 introduces no dedicated scheduler portal family, no **CH-ACP** kind for scheduler tuning, and no scheduler-specific conflict-key family.
   - Scheduling policy remains below the existing kernel/runtime/control seams; this doc only pins what the portable contract refuses to become.
   - If future work wants reviewed scheduler mutation/admin actions, it must return RFC-first and specify conflict keys, commutativity, serialization boundary, and evidence hooks explicitly.

8) **Sealed compat remains killable and non-ambient**
   - Foreign/compat runtimes may map their own scheduler knobs locally, but they MUST NOT recreate ambient inherited priority/class channels as native meaning for reviewed SlopOS components.
   - Disabling the relevant lane/profile must fail closed for compat adapters that depend on host scheduler mutation semantics.
   - This keeps “juicy” ecosystem scheduler features importable as local implementation tactics without letting them outrun the authority substrate.

## Phase 1 non-goals (explicitly deferred)

- A portable API for `nice` / real-time / deadline / priority-class / CPU-share tuning.
- A portable fairness / CPU-share / latency / quantum guarantee beyond explicit TCap budget/period semantics.
- A portable scheduler-admin or runnable-thread inventory surface.
- A portable lock-coupled priority-inheritance / priority-ceiling protocol.
- A workflow / ACP family for “boost priority”, “pin CPU policy”, or “inspect runqueue”.

## Wiring

- Decision surface:
  - `decision-map.md` (D-SCHED)
- Primary schema / runtime surfaces:
  - `temporal-capability-schema-v0.md`
  - `schema-registry.md` (CH-TCAP v0)
  - `rfcs/0049-temporal-capabilities-and-scheduling-contexts.md`
- Adjacent posture/runtime surfaces:
  - `upcall-posture-v0.md`
  - `reqctx-tcap-ref-posture-v0.md`
  - `capshell-scheduling-posture-v0.md`
  - `rseq-posture-v0.md`
  - `turns-posture-v0.md`
  - `pressure-posture-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-TCAP-1**, **I-TCAP-2**, **I-TCAP-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-TCAP-VALIDATE**, **PO-TCAP-DONATE**, **PO-TCAP-ENF**)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- No new portal family / ACP kind / conflict-key family addition in v0; any future scheduler-control plane must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_scheduling_posture.py` fails `make lint` if this posture stops being discoverable, loses the **TCap-first / closed urgency vocabulary / no ambient scheduler mutation or global inventory / no fairness-share-latency promise / no new workflow-ACP surface** posture, or drops its primary REF wiring.

## References

- REF-SEL4-SCHEDCTX-EUROSYS18.
- REF-SEL4-MCS-TUTORIAL.
- REF-SEL4-API-SC-UNBIND.
- REF-TCAPS-RTSS17.
- REF-MAN7-SCHED.
- REF-MAN7-SCHED-SETSCHEDULER.
