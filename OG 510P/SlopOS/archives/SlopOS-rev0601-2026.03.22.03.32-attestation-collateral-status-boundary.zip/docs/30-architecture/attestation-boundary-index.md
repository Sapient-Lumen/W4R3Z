# Attestation boundary index (v0)

Purpose: keep the **closed set of D-ATTEST companion boundary docs** enumerable.

Why this exists:
- the archive now pins more than one small attestation-adjacent meaning cut, which is good for precision,
- but once those cuts exist, the next drift risk is **amnesia**: freshness/challenge rules, endorsement/reference rules, verifier-result folklore, attester-identity/enrollment folklore, and collateral-status/currentness folklore get rediscovered piecemeal and quietly widened by tooling,
- `attestation-posture-v0.md` keeps the overall meaning of D-ATTEST, while this index is the **discovery surface** that says which companion boundaries currently keep attestation export fail-closed.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `attestation-posture-v0.md` and RFC-0064.

## Posture (v0)

- D-ATTEST keeps a **small closed companion boundary family** for attestation-adjacent meaning cuts that would otherwise regrow endorsement/reference discovery, freshness/currentness folklore, attester-identity/enrollment folklore, collateral-status/currentness folklore, or hidden attestation service semantics behind exported evidence bytes.
- This index is a **discovery and maintenance surface**, not a new protocol: it enumerates the current attestation companion boundaries and forces same-revision maintenance when that family changes.
- Phase 1 meaning remains in `attestation-posture-v0.md`; this index only keeps the current companion-boundary set recoverable by humans, CI, and LLM handoff surfaces.

## Phase 1 non-goals (explicitly deferred)

- This doc does **not** define a new attestation token schema, appraisal policy API, verifier RPC, nonce-issuance service, endorsement lookup protocol, freshness-query service, collateral-status query/cache service, attestation-result schema, or verifier-verdict receipt kind.
- This doc does **not** create a new ACP kind, conflict-key family, portal family, or evidence format.
- If future work needs a broader attestation protocol/admin surface, it must return RFC-first rather than being smuggled in as an index edit.

## Wiring

- Discovery surfaces: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, and `docs/30-architecture/boundary-family-map.md`.
- Decision surfaces: `docs/30-architecture/decision-map.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, and `rfcs/0064-confidential-computing-profile.md`.
- Drift enforcement: `tools/check_attestation_boundary_index.py`, `tools/check_attestation_endorsement_boundary.py`, `tools/check_attestation_freshness_boundary.py`, `tools/check_attestation_result_boundary.py`, `tools/check_attestation_identity_boundary.py`, and `tools/check_attestation_collateral_status_boundary.py`.
- Evidence hook: `docs/00-meta/evidence-index.md` entries `EVID-2026-463`, `EVID-2026-609`, `EVID-2026-610`, `EVID-2026-611`, `EVID-2026-612`, and `EVID-2026-613`.

## References

- `REF-RATS-RFC9334` — keeps attester, verifier, endorsements, attestation results, and relying-party decisions distinct rather than collapsing exported evidence into a native online service plane.
- `REF-RATS-EAR-DRAFT` / `REF-RATS-AR4SI-DRAFT` — verifier-generated attestation results are their own evidence vocabulary; result claims are consumed under relying-party policy rather than becoming ambient approval truth.
- `REF-EAT-RFC9711` / `REF-RFC9783-PSA-TOKEN` — freshness/nonces are explicit evidence bindings, not a generic currentness/session oracle.
- `REF-EAT-RFC9711` / `REF-RFC9783-PSA-TOKEN` / `REF-DICE-HW-REQ` — attester identity terms such as `device_id`, UEID, implementation-id, instance-id, and DICE-derived identifiers are evidence/signing-context inputs interpreted under local enrollment and policy, not a portable asset or enrollment truth plane.
- `REF-RFC5280-PKIX` / `REF-RFC6960-OCSP` / `REF-INTEL-TRUSTEDSERVICES-API` — collateral status/freshness artifacts such as CRLs, OCSP responses, TCB info, QE/QVE identity blobs, `issueDate` / `nextUpdate`, and `tcbEvaluationDataNumber` are supporting evidence inputs interpreted under local freshness/cache policy rather than a portable latest-collateral or approval truth plane.
- `REF-TPM2-PART3-QUOTE` — provider-native qualifying/challenge data exists in real attestation ecosystems, so SlopOS keeps challenge freshness explicit and verifier-local rather than silently portable.

## Inclusion rule

A doc belongs here if it removes exactly one tempting attestation/export meaning from Phase 1 by constraining one of:
- verifier-local appraisal inputs that would otherwise smuggle in a native endorsement-discovery, reference-value lookup, latest-applicable, or approval plane,
- freshness/challenge/session semantics that would otherwise smuggle in a native currentness oracle, nonce-issuance service, session-continuity shortcut, or online freshness client plane,
- attester-identity/enrollment semantics that would otherwise smuggle in a native machine/asset/workload identity, attester inventory, or enrollment-query plane,
- verifier-generated attestation-result semantics that would otherwise smuggle in a native verdict/approval/latest-result plane,
- collateral-status/currentness semantics that would otherwise smuggle in a native latest-collateral, refresh, or current-trust plane.

If future work needs a new native attestation workflow instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind exported attestation bytes.

## Closed companion boundary set (Phase 1)

### 1) Verifier-local appraisal inputs stay explicit

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attestation-endorsement-boundary-v0.md`](attestation-endorsement-boundary-v0.md) | endorsements / reference values / CoRIM-style corpora | imported endorsement material does not become a native endorsement-discovery, reference-value lookup, or latest-applicable plane | explicit verifier-local endorsement/reference corpora and policy |

### 2) Freshness and challenge semantics stay verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attestation-freshness-boundary-v0.md`](attestation-freshness-boundary-v0.md) | nonce / challenge / freshness claims / provider-native qualifying data | exported freshness fields do not become a native currentness oracle, session-continuity shortcut, or online freshness client plane | explicit verifier-local challenge issuance and freshness policy |

### 3) Attester identity and enrollment meaning stay verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attestation-identity-boundary-v0.md`](attestation-identity-boundary-v0.md) | `device_id` / UEID / implementation-id / instance-id / provider-native attester identifiers | attester identity material remains exact evidence/signing context only; it does not become a native machine/asset/workload identity, attester inventory, or enrollment-query plane | explicit verifier-local identity / enrollment policy over exact evidence |

### 4) Verifier-generated attestation results stay imported evidence

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attestation-result-boundary-v0.md`](attestation-result-boundary-v0.md) | EAR / AR4SI-style result artifacts / verifier verdict labels / trustworthiness vectors | verifier-generated attestation results do not become a native approval, current-trust, or latest-result plane | explicit relying-party / owner-local policy over exact evidence + imported result artifacts |

### 5) Collateral status and freshness stay verifier-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`attestation-collateral-status-boundary-v0.md`](attestation-collateral-status-boundary-v0.md) | certificate chains / CRLs / OCSP responses / TCB info / QE-QVE-QAE identity blobs / collateral cache snapshots | imported collateral status/freshness artifacts do not become a native latest-collateral, approval, or ambient fetch/cache plane | explicit verifier-local collateral/status freshness and cache policy over exact evidence |

## Review rule

Before adding another attestation companion boundary doc, answer these questions in order:
1) Is the change really a **D-ATTEST meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
