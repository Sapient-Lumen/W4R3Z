# D-PLUMB OpenURI embedded-web-surface boundary v0 (no portable in-app browser / custom-tab / Safari-view-controller seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable embedded-web surface, in-app browser, custom-tab, Safari-view-controller, or browser-chrome customization surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable embedded-web-surface seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `in_app_browser`, `embedded_web`, `custom_tab`, `partial_custom_tab`, `safari_view_controller`, `trusted_web_activity`, `browser_chrome`, `toolbar_color`, `close_button_style`, `action_button`, `secondary_toolbar`, `menu_items`, `share_state`, `presentation_style`, or equivalent embedded-browser surface field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Embedded browser presentation and chrome stay provider-local rather than portal truth.**
   - A shell, browser, or other handler may still choose local UX such as opening in an external browser app, presenting an in-app browser surface, using partial-sheet or side-sheet presentation, exposing browser chrome, or attaching provider-local toolbar/menu actions.
   - Phase 1 does **not** reinterpret those provider-local presentation choices as a portable requester-visible result, stable receipt, or transcript-stable statement that a particular browser surface, toolbar/action set, or in-app browsing mode was used.
   - Generic OpenURI therefore stays launch-oriented rather than becoming a reusable embedded-browser presentation broker for arbitrary URIs.

3) **Embedded web presentation is a second workflow, not generic launch.**
   - Dedicated embedded-browser APIs allocate additional semantics: app-retained presentation, browser-chrome customization, partial-sheet/side-sheet layout, toolbar/menu action plumbing, and sometimes app-visible engagement callbacks.
   - Phase 1 therefore does **not** reinterpret generic launch as permission to request or control a specific embedded-browser surface on the requester’s behalf.
   - If a future product shape needs reviewed embedded browsing, trusted web surfaces, or browser-chrome customization, that belongs on a future RFC-first web-surface seam rather than as a side effect of generic launch.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. Android documents Custom Tabs as a way to add a customized browser experience directly within an app. Chrome documents UI customization and custom interactivity for Custom Tabs. Apple documents `SFSafariViewController` as a standard visible interface for web content with Safari features.
   - SlopOS imports the narrow lesson: these are real product workflows, but they are not harmless synonyms for “open this URI”. They allocate additional presentation, UI-control, and in-app surface semantics that Phase 1 should not smuggle through `portal.uri.*`.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new embedded-browser action family, conflict-key family, or serialization surface.
   - Any future embedded-web or browser-surface seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from in-app browsing APIs.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this in a custom tab / embedded browser / in-app web sheet” behavior through helper fallbacks.
   - If compat needs reviewed embedded-web presentation, it still pays for an explicit future seam rather than smuggling browser-surface control through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `in_app_browser`, `embedded_web`, `custom_tab`, `partial_custom_tab`, `safari_view_controller`, `trusted_web_activity`, `browser_chrome`, `toolbar_color`, `action_button`, or equivalent browser-surface knob/result on generic OpenURI.
- No portable receipt that a URI was opened in a specific embedded browser, partial sheet, side sheet, or app-retained browser surface.
- No shell/helper fallback that quietly promotes `open_uri` into a browser-surface-selection or browser-chrome-customization workflow and reports that second workflow as OpenURI truth.
- No portable embedded-browser, custom-tab, or in-app web-surface control plane on generic URI launch.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, free of callback folklore, and free of browser-session/auth/install semantics, but one more convenience import still lingers in mainstream mobile/browser APIs: “while you’re opening this URI, can you also keep the user inside my app and give me a tuned browser UI?” That sounds product-friendly, but it quietly turns a launcher seam into a browser-surface broker with presentation, chrome, and interaction semantics that are much harder to reason about for authority, transcript truth, and profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into embedded-browser presentation authority. That matters for all four product shapes: workstation UX can still use local browser surfaces without standardizing them as app-visible substrate meaning; hosted and embedded profiles avoid inheriting fake in-app browsing machinery they do not want; and agent tooling cannot mistake `open_uri` for permission to demand a particular browser UI/control surface.

## Profile effect (A–D)

- **Secure workstation (A):** shells and browsers may still offer local in-app or embedded browsing UX, but generic OpenURI does not standardize embedded-browser surface selection or browser-chrome customization as app-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting ambient embedded-browser or partial-tab machinery they do not actually want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising custom-tab or embedded-web presentation workflows they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “launch this URI in a specific embedded browser surface”; reviewed browser-surface control stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_embedded_web_surface_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable embedded-web-surface seam / embedded browser presentation stays provider-local / embedded web presentation is a second workflow / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-589**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-CUSTOM-TABS-OVERVIEW.
- REF-CHROME-CUSTOM-TABS-UI-CUSTOMIZATION.
- REF-CHROME-CUSTOM-TABS-INTERACTIVITY.
- REF-APPLE-SFSAFARIVIEWCONTROLLER.
