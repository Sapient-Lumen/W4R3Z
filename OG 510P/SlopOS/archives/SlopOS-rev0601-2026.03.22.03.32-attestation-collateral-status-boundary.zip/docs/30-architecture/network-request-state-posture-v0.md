# D-NETLEASE request-state posture v0 (request key ≠ live network lease state)

Purpose: close one small but expensive ambiguity on the D-NETLEASE seam: **a bounded CH-NETREQ request artifact is not the same thing as current portal-owned live network-lease state**.

Several of the comparison archives kept this exact split honest in workflow-heavy lanes: a stable review/dedupe request key is useful, but it must not collapse into current live grant truth. SlopOS should be at least that explicit for leased networking.

This doc is intentionally narrow. It does **not** add a new lease-inventory API, a current-connection watcher, or a durable portal-state schema. It only freezes what CH-NETREQ `req_id` does and does not mean in Phase 1.

## Posture (v0)

1) **`CH-NETREQ.req_id` is requester-chosen request identity, not portal-issued live lease state**
   - `req_id` is a stable caller-chosen request key carried in the request descriptor so retries, renew/review submissions, and ACP dedupe have one exact schema-pinned key.
   - It is **not** a portal-issued CH-NETLEASE handle, not a current connection/session identifier, and not proof that a current live network lease still exists.

2) **Request presence is not current lease-state truth**
   - The existence of CH-NETREQ bytes (or an old `netreq_digest`) says only that a bounded request was formed/submitted.
   - It does **not** by itself mean that a lease is currently active, the same destination scope is still granted, an old lease has not expired/revoked, or the current portal policy would still issue the same bounds now.

3) **Current portal-owned lease state remains portal-local unless a future surface pays for it explicitly**
   - Active lease issuance, renewal, revocation, expiry, budget exhaustion, and any “still live?” truth stay inside the `portal.net` service boundary in Phase 1.
   - If later work needs portable lease-status receipts, live-lease inventories, or watcher/update semantics, it must return RFC-first with its own schema, ordering, receipts, and assurance hooks.

4) **Dedupe/retry safety uses the request key only as a veto-only identity hook**
   - At-least-once-safe `portal.net.request` depends on a stable `CH-NETREQ.req_id` so duplicate submissions can collapse before effect.
   - That dedupe key is still non-authoritative: it may suppress/reuse/renew according to portal policy, but it never grants network authority by itself.

5) **Historical receipts do not reactivate current network authority**
   - A prior CH-ACPOUT / CH-LOG / CH-RECEIPT trail may prove that a request was reviewed or accepted at some point.
   - It does **not** imply that the corresponding network lease remains live after later revocation, expiry, budget exhaustion, policy tightening, or portal-local cleanup.

## Phase 1 non-goals (explicitly deferred)

- A portable lease inventory / enumerate-network-leases API.
- A portable receipt or watcher surface proving whether a request is currently pending, granted, revoked, expired, or exhausted.
- Treating CH-NETREQ `req_id` as a portal-issued CH-NETLEASE handle or a current connection/session identifier.
- Letting historical CH-ACPOUT / CH-LOG / CH-RECEIPT artifacts stand in for current portal-owned network-lease truth.
- Any hidden policy/query language that asks the portal for ambient “current network lease state” during ACP validation.

## Why this earns its place

Without this split, the archive quietly collapses two different questions:
- **what exact request did we review/dedupe?**
- **what network lease state exists right now inside the portal?**

That collapse would make retry safety, receipts, and later automation less honest. Phase 1 can stay small and still refuse the ambiguity.

## Wiring

- Decision surface:
  - `decision-map.md` (D-NETLEASE)
- Request / grant descriptors:
  - `network-request-schema-v0.md` (CH-NETREQ v0)
  - `network-lease-schema-v0.md` (CH-NETLEASE v0)
- Portal semantics:
  - `network-lease-posture-v0.md`
  - `portal-family-registry.md`
- ACP automation:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
- RFC / trajectory:
  - `rfcs/0056-outbound-network-leases-and-portals.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (I-NETREQ-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-NETLEASE-STATE)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`

CI drift gate:
- `tools/check_network_request_state_posture.py`

## References

- REF-ANDROID-CONNECTIVITYMANAGER.
- REF-MACOS-NETWORKEXT.
- REF-LITTLESNITCH.
