# D-PLUMB OpenURI request-shaping boundary v0 (no portable network-request customization seam)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable HTTP/web-request customization surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable network-request customization seam in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `headers`, `extra_headers`, `request_headers`, `http_method`, `method=POST`, `request_body`, `body_bytes`, `user_agent`, `referer_header`, or equivalent request-customization field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus the normal request-local OpenURI outcome.

2) **Any downstream dereference semantics stay handler-local and non-authoritative.**
   - A chosen handler may dereference the URI using its own network stack, browser session, renderer, or helper pipeline.
   - That does **not** make the concrete HTTP method, request headers, cookies, browser profile, redirect policy, or fetch-time network knobs portable portal meaning.
   - Phase 1 therefore declines treating OpenURI as a browser-session-control, web-request-shaping, or hidden fetch-policy seam just because a handler may implement those choices internally.

3) **Explicit fetch/download workflows stay on explicit seams, not generic launch.**
   - If a product shape later needs reviewed network-request shaping, browser-session selection, authenticated fetch, or explicit request-header/body control, that belongs on a future RFC-first fetch/web/auth seam rather than as a side effect of generic launch.
   - Existing explicit seams already show the pattern: `portal.net` leases govern network authority, and explicit download/materialization APIs in other ecosystems carry their own headers/network/destination knobs rather than overloading generic URI launch.
   - Generic OpenURI therefore stays a mediated launch workflow, not a request-customization envelope for the chosen handler.

4) **Why this cut is honest.**
   - Real ecosystems tempt this widening. XDG OpenURI keeps the portable request shape deliberately small: the `OpenURI` options are limited to mediation metadata such as `handle_token`, `writable`, `ask`, and `activation_token`, not arbitrary downstream HTTP controls.
   - Android historically allowed browser-launch flows to attach HTTP headers via `Browser.EXTRA_HEADERS`, and modern Chrome custom tabs still discuss extra-request-header behavior plus cross-origin filtering because those headers are security-sensitive.
   - Android also keeps richer fetch/download control on explicit download APIs that carry their own headers, network constraints, and destination knobs.
   - SlopOS imports the narrow lesson: `open_uri` can ask the shell to launch a URI, but it does not become a generic network-request customization plane.

5) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new request-customization action family, conflict-key family, or serialization surface.
   - Any future fetch/web/admin seam must state its own conflict keys, commutativity, and evidence rules explicitly rather than inheriting folklore from browser-launch UX.

6) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host “open this URL with these hidden HTTP headers/method/body hints” behavior through helper fallbacks.
   - If compat needs reviewed request customization, it still pays for an explicit future seam rather than smuggling network-request shaping through `portal.uri.*`.

## Phase 1 non-goals (explicitly deferred)

- No portable `headers`, `extra_headers`, `request_headers`, or equivalent OpenURI knob.
- No portable `http_method`, `method=POST`, `request_body`, `body_bytes`, or equivalent launch-time request-shaping field.
- No portable `user_agent`, `referer_header`, or equivalent downstream-request override on generic URI launch.
- No browser-session/request-policy contract that treats handler-local network behavior as portable portal truth.
- No host-helper fallback that quietly turns generic URI launch into a request-customized fetch pipeline.

## Why this is worth pinning

The archive already keeps OpenURI launch-only, request-local, and non-materializing, but one tempting convenience import still lingers in mainstream ecosystems: “can I open this URL with a few headers / a different method / a hidden browser hint?” That sounds small, but it quietly turns a launch seam into a delegated network-client surface, which is much harder to reason about for authority, transcript truth, and cross-profile parity.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a browser-specific request-customization plane. That matters for all four product shapes: workstation UX can still launch links without standardizing header/body hacks; hosted and embedded profiles avoid carrying a fake browser-control plane they do not want; and agent tooling cannot mistake `open_uri` for a reviewed fetch API.

## Profile effect (A–D)

- **Secure workstation (A):** browsers/viewers may still have rich local behavior, but generic OpenURI does not standardize browser-specific header/method tricks as app-visible substrate truth.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting a fake per-launch HTTP-control plane from desktop launcher folklore.
- **Embedded / separation appliance (C):** appliance builds can allow bounded link launch where useful without promising a web-request API they do not actually want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “launch this URI” with “perform a customizable fetch”; reviewed network shaping stays on explicit future seams.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/30-architecture/effect-contract-schema-v0.md`
  - `docs/30-architecture/intent-kind-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_request_shaping_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable request-header/method/body customization seam / downstream dereference stays handler-local / explicit fetch stays on explicit seams / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-581**).

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-BROWSER-EXTRA-HEADERS.
- REF-CHROME-CUSTOM-TABS-REQUEST-HEADERS.
- REF-ANDROID-DOWNLOADMANAGER-REQUEST.
