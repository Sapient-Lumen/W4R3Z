# D-PLUMB OpenURI boundary index (v0)

Purpose: keep the **closed set of D-PLUMB OpenURI companion boundary docs** enumerable.

Why this exists:
- the archive now pins multiple small OpenURI-adjacent meaning seams so `portal.uri.*` does not quietly regrow into a handler-discovery oracle, chooser-control surface, opener-attribution channel, activation-control surface, callback/reentry channel, fake completion oracle, raw-subject echo side channel, content-type / MIME / UTI classification broker, URL-safety / phishing / malware / reputation-verdict broker, link-preview / unfurl metadata broker, reader-mode / article-distillation broker, speculative-loading broker, browser-auth/session broker, navigation-observation/page-state/final-URL broker, verified-app-link / associated-domain trust broker, browser/store/install fallback broker, or approximate file-manager convenience API,
- those `openuri-*-boundary-v0.md` docs are individually crisp but easy to forget piecemeal because they span scheme probing, handler selection authority, opener attribution, activation control, callback/reentry control, launch-completion truth, recent-items/history enrollment, subject-echo hygiene, download/materialization boundaries, request-shaping boundaries, content-type/MIME/UTI classification boundaries, URL-safety boundaries, preview/unfurl metadata boundaries, reader-mode/article-distillation boundaries, speculative-loading boundaries, browser-session/profile selection boundaries, launch-disposition boundaries, embedded-web-surface boundaries, browser-auth/session boundaries, navigation-observation boundaries, credential/autofill/passkey boundaries, web-permission boundaries, verified-association boundaries, browser/store/install fallback boundaries, and reveal fidelity,
- `openuri-portal-posture-v0.md` keeps the overall Phase-1 meaning of OpenURI, while this index is the **discovery surface** that says which companion boundaries currently keep mediated URI launch shell-owned, non-ambient, and transcript-honest.

This doc does **not** add a new schema, workflow family, or receipt kind.
It is an entropy-reducing companion to `openuri-portal-posture-v0.md`, `plumb-posture-v0.md`, and RFC-0046 / RFC-0117.

## Posture (v0)

- D-PLUMB OpenURI keeps a **small closed companion boundary family** for seams that would otherwise regrow handler-discovery, chooser-control, opener attribution, activation control, callback/reentry, fake completion truth, recent-items/history control, subject echo, download/materialization semantics, resource-grant/URI-permission/security-scope semantics, request customization semantics, content-type/MIME/UTI classification semantics, URL-safety/phishing/malware/reputation-verdict semantics, preview/unfurl metadata semantics, reader-mode/article-distillation semantics, speculative-loading semantics, browser-session/profile selection semantics, placement/reuse semantics, embedded-web-surface semantics, browser-auth/session semantics, navigation-observation/page-state/final-URL semantics, credential/autofill/passkey semantics, web-permission / powerful-feature prompt semantics, verified-association trust semantics, browser/store/install fallback semantics, or approximate-reveal semantics behind `portal.uri.*`.
- This index is a **discovery and maintenance surface**, not a new protocol: it enumerates the current OpenURI companion boundaries and forces same-revision maintenance when that family changes.
- Phase 1 meaning remains in `openuri-portal-posture-v0.md`; this index only keeps the current companion-boundary set recoverable by humans, CI, and LLM handoff surfaces.

## Phase 1 non-goals (explicitly deferred)

- This doc does **not** define a new chooser policy API, app-targeted `open_with` seam, selected-handler receipt, target-visible opener-attribution seam, foreground/activation-control seam, callback/reentry seam, launch-completion/liveness receipt, recent-items/history policy surface, full-URI echo/history/reporting surface, download/materialization seam, resource-grant/URI-permission/security-scope seam, request-customization seam, content-type/MIME/UTI classification seam, URL-safety/phishing/malware/reputation-verdict seam, link-preview/unfurl metadata seam, reader/article-extraction seam, speculative-loading seam, browser-session/profile selection seam, placement/reuse seam, embedded-web-surface seam, browser-auth/session seam, navigation-observation/page-state/final-URL seam, credential/autofill/passkey seam, web-permission / powerful-feature prompt seam, verified-association trust seam, browser/store/install fallback seam, or file-manager fidelity schema.
- This doc does **not** create a new ACP kind, conflict-key family, portal family, or evidence format.
- If future work needs a broader launcher/admin surface, it must return RFC-first rather than being smuggled in as an index edit.

## Wiring

- Discovery surfaces: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, and `docs/30-architecture/boundary-family-map.md`.
- Decision surfaces: `docs/30-architecture/decision-map.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md`.
- Drift enforcement: `tools/check_openuri_boundary_index.py`, `tools/check_openuri_scheme_support_boundary.py`, `tools/check_openuri_handler_selection_boundary.py`, `tools/check_openuri_opener_attribution_boundary.py`, `tools/check_openuri_activation_control_boundary.py`, `tools/check_openuri_callback_reentry_boundary.py`, `tools/check_openuri_launch_completion_boundary.py`, `tools/check_openuri_recent_items_boundary.py`, `tools/check_openuri_subject_echo_boundary.py`, `tools/check_openuri_materialization_boundary.py`, `tools/check_openuri_resource_grant_boundary.py`, `tools/check_openuri_request_shaping_boundary.py`, `tools/check_openuri_content_type_boundary.py`, `tools/check_openuri_url_safety_boundary.py`, `tools/check_openuri_preview_metadata_boundary.py`, `tools/check_openuri_content_extraction_boundary.py`, `tools/check_openuri_speculative_loading_boundary.py`, `tools/check_openuri_session_selection_boundary.py`, `tools/check_openuri_launch_disposition_boundary.py`, `tools/check_openuri_embedded_web_surface_boundary.py`, `tools/check_openuri_auth_session_boundary.py`, `tools/check_openuri_navigation_observation_boundary.py`, `tools/check_openuri_credential_mediation_boundary.py`, `tools/check_openuri_web_permission_boundary.py`, `tools/check_openuri_install_fallback_boundary.py`, `tools/check_openuri_verified_association_boundary.py`, and `tools/check_openuri_showitem_exactness_boundary.py`.
- Evidence hook: `docs/00-meta/evidence-index.md` entry `EVID-2026-572`.

## References

- `REF-XDG-PORTAL-OPENURI` — portal semantics imported narrowly; tempting `SchemeSupported`, `ask`, and `OpenDirectory` fallback semantics are kept outside portable requester meaning.
- `REF-ANDROID-PACKAGE-VISIBILITY` — installed-handler visibility is privacy-sensitive and should not become an easy requester oracle.
- `REF-ANDROID-CREATECHOOSER` — chooser forcing/default behavior is a separate policy seam, not part of minimal mediated launch meaning.
- `REF-XDG-PORTAL-APPCHOOSER` / `REF-ANDROID-ACTIVITY-REFERRER` / `REF-APPLE-OPENURL-SOURCEAPPLICATION` — caller/window/referrer context exists in real ecosystems, so SlopOS keeps that context portal-local unless a future RFC deliberately standardizes a target-visible attribution surface.
- `REF-XDG-PORTAL-OPENURI` / `REF-XDG-PORTAL-APPCHOOSER` / `REF-WAYLAND-XDG-ACTIVATION` / `REF-APPLE-NSWORKSPACE-ACTIVATES` — launcher ecosystems also expose activation tokens and foregrounding controls, so SlopOS keeps attention-steering policy shell/compositor-owned rather than turning OpenURI into a portable focus/foreground control plane.
- `REF-XDG-PORTAL-REQUEST` / `REF-XCALLBACK-URL` / `REF-RFC8252-NATIVE-APPS` — launcher and native-app ecosystems expose callback URLs, deep-link reentry, and redirect-back patterns, so SlopOS keeps generic OpenURI outcomes on request-local completion paths rather than turning URI launch into a second rendezvous protocol.
- `REF-XDG-PORTAL-REQUEST` / `REF-APPLE-OPENURL-COMPLETION` / `REF-WINDOWS-SHELLEXECUTEEX` / `REF-XCALLBACK-URL` — launcher ecosystems expose request completion, launch success booleans, and sometimes callback conventions, so SlopOS explicitly keeps OpenURI outcomes admission-scoped rather than a portable target-completion or current-live-state oracle.
- `REF-XDG-PORTAL-DOCUMENTS` / `REF-APPLE-RECENT-ITEMS` / `REF-WINDOWS-SHADDTORECENTDOCS` / `REF-WINDOWS-FOS-DONTADDTORECENT` — desktop ecosystems often keep durable recent-items state and even expose “don’t add to recent” knobs, while sandboxed document workflows solve durable reopen on an explicit document-store seam, so SlopOS keeps any launch-history hints shell-owned and separate from generic OpenURI meaning.
- `REF-RFC3986-URI-GENERIC-SYNTAX` / `REF-RFC6819-OAUTH-SECURITY` — URIs may carry userinfo, query, or fragment material that ecosystems frequently display, bookmark, log, or remember in history, so SlopOS keeps full launched URIs request-local and declines a portable raw-subject echo/history/reporting seam on generic OpenURI.
- `REF-XDG-PORTAL-OPENURI` / `REF-XDG-PORTAL-DOCUMENTS` / `REF-ANDROID-SAF-DOCUMENTS` / `REF-ANDROID-DOWNLOADMANAGER-REQUEST` — launcher ecosystems keep generic URI opening separate from document-store entry creation and explicit download/materialization APIs, so SlopOS declines a portable local-object/docref/download receipt seam on generic OpenURI.
- `REF-XDG-PORTAL-DOCUMENTS` / `REF-ANDROID-FILEPROVIDER-SHARE-FILE` / `REF-ANDROID-PERSISTABLE-URI-PERMISSIONS` / `REF-APPLE-SECBOOKMARK` — ecosystems also expose explicit per-app document permissions, URI permission grants, and persistent security-scoped bookmarks, so SlopOS keeps generic OpenURI free of a portable local-resource grant/attachment-handoff plane and reserves reviewed local-object transfer for explicit file/document/transfer seams.
- `REF-XDG-PORTAL-OPENURI` / `REF-ANDROID-BROWSER-EXTRA-HEADERS` / `REF-CHROME-CUSTOM-TABS-REQUEST-HEADERS` / `REF-ANDROID-DOWNLOADMANAGER-REQUEST` — ecosystems do expose request-header/body/network customization on richer browser/download APIs, so SlopOS keeps generic OpenURI free of a portable request-customization plane and reserves reviewed fetch shaping for an explicit future seam.
- `REF-WHATWG-MIME-SNIFFING` / `REF-ANDROID-INTENTS-DATA-AND-TYPE` / `REF-APPLE-NSWORKSPACE-URLSFORAPPLICATIONS-TOOPEN-CONTENTTYPE` / `REF-APPLE-LSCOPYALLROLEHANDLERSFORCONTENTTYPE` — ecosystems expose byte sniffing, MIME/UTI classification, and handler resolution by declared content type, so SlopOS keeps generic OpenURI free of a portable type-classification plane and reserves reviewed fetch/classification control for an explicit future seam.
- `REF-GOOGLE-SAFE-BROWSING` / `REF-MICROSOFT-DEFENDER-SMARTSCREEN` / `REF-APPLE-SAFARI-FRAUDULENT-WEBSITE-WARNING` — ecosystems also expose phishing/malware/reputation checks, browser warning interstitials, and provider-fed URL safety policy, so SlopOS keeps generic OpenURI free of a portable URL-safety/reputation plane and reserves reviewed classification/policy work for an explicit future seam.
- `REF-APPLE-LINKPRESENTATION` / `REF-SLACK-UNFURLING-LINKS` / `REF-SLACK-ROBOTS` / `REF-OPEN-GRAPH-PROTOCOL` — ecosystems also expose rich-link metadata fetch, unfurl crawling, and Open Graph/oEmbed-style preview extraction, so SlopOS keeps generic OpenURI free of a portable preview/unfurl metadata plane and reserves reviewed preview generation for an explicit future seam.
- `REF-MOZILLA-READABILITY` / `REF-CHROMIUM-READER-MODE` / `REF-POSTLIGHT-PARSER` / `REF-APPLE-SAFARI-READER` — ecosystems also expose reader mode, DOM distillation, readability cleanup, article extraction, and even provider-local summaries, so SlopOS keeps generic OpenURI free of a portable reader/article-extraction plane and reserves reviewed distillation/extraction work for an explicit future seam.
- `REF-WHATWG-LINK-TYPE-DNS-PREFETCH` / `REF-WHATWG-LINK-TYPE-PRECONNECT` / `REF-WHATWG-LINK-TYPE-PREFETCH` / `REF-CHROME-CUSTOM-TABS-WARMUP-PREFETCH` / `REF-CHROME-SPECULATION-RULES-PRERENDER` — ecosystems also expose speculative DNS resolution, connection warmup, prefetch, browser-process warmup, and prerender controls on richer browser/performance APIs, so SlopOS keeps generic OpenURI free of a portable speculative-loading plane and reserves reviewed warmup/prefetch/prerender control for an explicit future seam.
- `REF-WHATWG-WINDOW-OPEN` / `REF-ANDROID-INTENTS-FLAGS` / `REF-ANDROID-RECENTS` / `REF-APPLE-NSWORKSPACE-CREATESNEWAPPLICATIONINSTANCE` / `REF-APPLE-NSWORKSPACE-RUNNING-APPLICATION-SUBSTITUTION` — ecosystems also expose explicit tab/window targets, named-window reuse, task/document placement, and app-instance reuse/new-instance controls, so SlopOS keeps generic OpenURI free of a portable placement/reuse plane and reserves reviewed tab/window/task routing control for an explicit future seam.
- `REF-ANDROID-CUSTOM-TABS-OVERVIEW` / `REF-CHROME-CUSTOM-TABS-UI-CUSTOMIZATION` / `REF-CHROME-CUSTOM-TABS-INTERACTIVITY` / `REF-APPLE-SFSAFARIVIEWCONTROLLER` — ecosystems also expose explicit in-app browser surfaces, app-branded browser chrome, toolbar/menu interactions, and Safari-view-controller style presentation, so SlopOS keeps generic OpenURI free of a portable embedded-web-surface plane and reserves reviewed in-app browsing or browser-surface control for an explicit future seam.
- `REF-XDG-PORTAL-OPENURI` / `REF-ANDROID-INAPP-BROWSING-CUSTOM-TABS` / `REF-CHROME-EPHEMERAL-CUSTOM-TABS` / `REF-APPLE-ASWEBAUTH-EPHEMERAL` — ecosystems also expose shared-vs-private browser-state choices, ephemeral sessions, and profile/cookie-jar control on richer web/auth APIs, so SlopOS keeps generic OpenURI free of a portable browser-session/profile-selection plane and reserves reviewed session/privacy control for an explicit future seam.
- `REF-RFC8252-NATIVE-APPS` / `REF-APPLE-ASWEBAUTHSESSION` / `REF-CHROME-AUTH-TAB` / `REF-CHROME-EPHEMERAL-CUSTOM-TABS` / `REF-APPLE-ASWEBAUTH-EPHEMERAL` — ecosystems also expose dedicated browser-auth session APIs with redirect capture, auth-result callbacks, and optional privacy/session controls, so SlopOS keeps generic OpenURI free of a portable browser-auth/session plane and reserves reviewed auth/web-session workflows for an explicit future seam.
- `REF-ANDROID-APP-LINKS` / `REF-ANDROID-VERIFY-APP-LINKS` / `REF-APPLE-UNIVERSAL-LINKS` / `REF-APPLE-ASSOCIATED-DOMAINS` — ecosystems also expose explicit domain-association verification, trusted deep-link routing, and website↔app binding state, so SlopOS keeps generic OpenURI free of a portable verified-app-link / associated-domain trust plane and reserves reviewed association-aware routing for an explicit future seam.
- `REF-CHROME-ANDROID-INTENTS` / `REF-GOOGLE-PLAY-LINKING` / `REF-GOOGLE-PLAY-INLINE-INSTALL` / `REF-APPLE-UNIVERSAL-LINKS` — ecosystems also expose browser fallback URLs, app-market redirection, inline install, and web fallback when a native app is missing, so SlopOS keeps generic OpenURI free of a portable browser/store/install fallback plane and reserves reviewed software-acquisition or promotion control for an explicit future seam.

## Inclusion rule

A doc belongs here if it removes exactly one tempting OpenURI meaning widening from Phase 1 by constraining one of:
- requester-visible probing of scheme support / handler availability / installed-app state,
- requester-visible influence over chooser/default/handler selection or disclosure of which handler was chosen,
- propagation of source-app / referrer-like opener identity into a target-visible or requester-visible cross-app attribution channel,
- requester-visible control over activation/foreground/focus semantics or receipts claiming the chosen handler became frontmost,
- portable callback/reentry/wakeup/redirect-back semantics beyond the request-local mediated completion path,
- portable success/completion/current-live-state claims beyond the admission-scoped mediated request outcome,
- portable recent-items/history enrollment, suppression, reopen-token, or durable-history receipt semantics on generic launch,
- portable echoing/history/reporting of the literal launched URI beyond digests or bounded redacted summaries,
- portable download/staging/import/local-object/docref-minting semantics hidden behind generic URI launch,
- portable request-header/method/body customization semantics hidden behind generic URI launch,
- portable link-preview/unfurl/title-icon-image metadata semantics hidden behind generic URI launch,
- portable reader-mode/article-text/summary extraction semantics hidden behind generic URI launch,
- portable navigation-observation/page-state/final-URL semantics hidden behind generic URI launch,
- portable verified-app-link / associated-domain trust semantics hidden behind generic URI launch,
- portable browser/store/install fallback semantics hidden behind generic URI launch,
- portable browser-session/profile/cookie-jar/private-mode selection hidden behind generic URI launch,
- fallback behavior that would collapse an exact “show/reveal this item” request into a broader browse/open-nearby action.

If future work needs a native chooser policy surface, app-targeted `open_with`, selected-handler receipt, target-visible opener attribution, portable activation/foreground control, callback/reentry/redirect-back semantics, launched-handler completion/live-state truth, recent-items/history control or durable reopen semantics, full-URI echo/history/reporting semantics, download/materialization/docref-minting semantics, URI-permission/security-scope/share-attachment semantics, request-header/method/body customization semantics, URL-safety/phishing/malware/reputation-verdict semantics, link-preview/unfurl metadata semantics, reader/article-extraction semantics, browser-session/profile-selection semantics, placement/reuse semantics, browser-auth/session semantics, navigation-observation/page-state/final-URL semantics, credential/autofill/passkey semantics, web-permission / powerful-feature prompt semantics, verified-association trust semantics, browser/store/install fallback semantics, or richer file-manager fidelity contract instead, that work must return **RFC-first** as its own decision surface rather than hiding behind `portal.uri.*` convenience semantics.

## Closed companion boundary set (Phase 1)

### 1) Scheme-support knowledge does not become a requester-visible oracle

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-scheme-support-boundary-v0.md`](openuri-scheme-support-boundary-v0.md) | support probing | exact scheme-support knowledge stays shell/policy-owned; no portable requester-visible `SchemeSupported` / `canOpenURL` / `queryIntentActivities` seam | actual mediated `open_uri` request plus explicit outcome |

### 2) Handler selection remains shell-owned

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-handler-selection-boundary-v0.md`](openuri-handler-selection-boundary-v0.md) | chooser / target selection / selected-handler disclosure | requesters may ask to open a URI, but they cannot choose the concrete handler, force or suppress chooser/default behavior, or learn which handler was selected | future RFC-first OpenURI policy/admin surface if truly needed |

### 3) Opener attribution stays portal-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-opener-attribution-boundary-v0.md`](openuri-opener-attribution-boundary-v0.md) | source-app / referrer propagation | opener identity and referrer-like metadata stay portal-local; no portable target-visible opener-identity channel or requester-visible attribution receipt | future RFC-first attribution/admin surface if truly needed |

### 4) Activation / foreground stays shell-owned

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-activation-control-boundary-v0.md`](openuri-activation-control-boundary-v0.md) | activation / foreground / focus-steering | foregrounding, activation handoff, and focus-steering stay shell/compositor-owned; no portable `activation_token`, foreground-control knob, or frontmost receipt | future RFC-first attention / shell-control surface if truly needed |

### 5) Callback / reentry stays request-local

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-callback-reentry-boundary-v0.md`](openuri-callback-reentry-boundary-v0.md) | callback URLs / deep-link reentry / redirect-back | request-local completion stays on the portal request/receipt path; no portable `x-success` / `x-error` / `x-cancel` / `callback_url` / `return_to` / redirect-back rendezvous seam on generic URI launch | future RFC-first auth/session/workflow return surface if truly needed |

### 6) Launch admission does not become target-completion truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-launch-completion-boundary-v0.md`](openuri-launch-completion-boundary-v0.md) | launch outcome / target lifecycle truth | mediated OpenURI outcomes stay admission-scoped; no portable launched-handler completion, liveness, exit, or “the user definitely saw this” receipt | future RFC-first result/session surface if truly needed |

### 7) Recent-items history stays shell-owned

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-recent-items-boundary-v0.md`](openuri-recent-items-boundary-v0.md) | recent-items / durable history / reopen-enrollment control | generic OpenURI exports no portable add-to-recents, suppress-history, reopen-token, or durable-history receipt seam; any shell-local launch history stays non-authoritative and separate from explicit document persistence | future RFC-first recent-items/admin surface or explicit `portal.file.*` / CH-DOCREF persistence workflow if truly needed |

### 8) Full URI subjects stay request-local and redaction-first

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-subject-echo-boundary-v0.md`](openuri-subject-echo-boundary-v0.md) | full-subject echo / normalized-URI reporting / raw-URI history truth | full launched URIs stay request-local; Phase 1 exports no portable `opened_uri` / normalized-URI receipt/history/logging seam, and durable audit prefers digests or bounded redacted summaries over verbatim URI text | future RFC-first history/export/admin surface if truly needed |

### 9) Generic launch does not become download/materialization authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-materialization-boundary-v0.md`](openuri-materialization-boundary-v0.md) | download / staging / local import / docref minting | generic OpenURI exports no portable `download=true`, staged-copy, import, local-path, or CH-DOCREF receipt seam; durable bytes and local-object identity stay on explicit file/document workflows | future RFC-first fetch/import workflow or explicit `portal.file.*` / CH-DOCREF persistence flow if truly needed |

### 10) Generic launch does not become resource-grant authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-resource-grant-boundary-v0.md`](openuri-resource-grant-boundary-v0.md) | URI-permission / security-scope / share-attachment / local-object handoff | generic OpenURI exports no portable `grant_uri_permission`, `persist_uri_permission`, `security_scope`, `security_scoped_bookmark`, `share_docref`, `attachment_docref`, or equivalent local-resource grant seam; local-object authority transfer stays on explicit file/document/transfer workflows rather than generic OpenURI truth | explicit `portal.file.*`, CH-DOCREF, or `portal.xfer.*` workflow; future RFC-first grant/handoff surface if truly needed |

### 11) Generic launch does not become request-customization authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-request-shaping-boundary-v0.md`](openuri-request-shaping-boundary-v0.md) | request headers / method / body / downstream dereference shaping | generic OpenURI exports no portable `headers`, `http_method`, `request_body`, `user_agent`, or equivalent request-customization seam; downstream dereference semantics stay handler-local | future RFC-first fetch/web/auth surface if truly needed |

### 12) Generic launch does not become content-type / MIME / UTI classification authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-content-type-boundary-v0.md`](openuri-content-type-boundary-v0.md) | MIME / UTI / content-type / sniffing / handler-by-type routing | generic OpenURI exports no portable `content_type`, `mime_type`, `declared_mime_type`, `sniffed_mime_type`, `sniff_content`, `probe_head`, `uti`, `uniform_type_identifier`, `open_as_type`, `resolved_content_type`, or equivalent type-classification seam; content classification and type-based routing stay provider-local rather than generic OpenURI truth | future RFC-first fetch/classify/type-routing surface if truly needed |

### 13) Generic launch does not become URL-safety/reputation authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-url-safety-boundary-v0.md`](openuri-url-safety-boundary-v0.md) | phishing / malware / deceptive-site / URL-reputation verdicts | generic OpenURI exports no portable `safe_browsing`, `url_reputation`, `threat_verdict`, `phishing`, `malware`, `safe_to_open`, or equivalent URL-safety/reputation seam; browser/OS warning and policy verdicts stay provider-local or policy-local rather than generic OpenURI truth | future RFC-first review/classification/policy surface if truly needed |

### 14) Generic launch does not become link-preview/unfurl authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-preview-metadata-boundary-v0.md`](openuri-preview-metadata-boundary-v0.md) | link preview / unfurl / title-icon-image metadata fetch | generic OpenURI exports no portable `preview`, `fetch_metadata`, `unfurl`, `preview_card`, `preview_title`, `preview_image`, or equivalent metadata-fetch seam; preview generation stays request-local or provider-local rather than generic OpenURI truth | future RFC-first fetch/preview/classification surface if truly needed |

### 15) Generic launch does not become reader/article-extraction authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-content-extraction-boundary-v0.md`](openuri-content-extraction-boundary-v0.md) | reader mode / article distillation / extracted text-html-markdown-summary | generic OpenURI exports no portable `reader_mode`, `extract_article`, `article_text`, `article_markdown`, `summary`, or equivalent extracted-content seam; reader/distillation work stays request-local or provider-local rather than generic OpenURI truth | future RFC-first fetch/extract/summarize surface if truly needed |

### 16) Generic launch does not become speculative-loading authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-speculative-loading-boundary-v0.md`](openuri-speculative-loading-boundary-v0.md) | browser warmup / dns-prefetch / preconnect / prefetch / prerender | generic OpenURI exports no portable `warmup`, `prewarm`, `dns_prefetch`, `preconnect`, `prefetch`, `may_launch`, `may_launch_url`, `prerender`, `speculate`, or equivalent speculative-loading seam; speculative network/process/cache work stays request-local or provider-local rather than generic OpenURI truth | future RFC-first speculative-fetch / performance-control surface if truly needed |

### 17) Generic launch does not become browser-session/profile-selection authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-session-selection-boundary-v0.md`](openuri-session-selection-boundary-v0.md) | browser-session/profile selection | exact cookie-jar/profile/private-mode choice stays handler/shell-owned; no portable requester-visible `incognito` / `ephemeral_session` / `profile_id` seam | actual mediated `open_uri` request plus explicit outcome; future RFC-first auth/web-session seam if needed |

### 18) Generic launch does not become placement/reuse authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-launch-disposition-boundary-v0.md`](openuri-launch-disposition-boundary-v0.md) | tab/window/task placement / browsing-context target / named-window reuse / app-instance reuse | generic OpenURI exports no portable `disposition`, `target`, `window_name`, `new_tab`, `new_window`, `reuse_window`, `new_task`, `new_document`, `new_instance`, or equivalent placement/reuse seam; tab/window/task/app-instance placement stays provider-local rather than generic OpenURI truth | future RFC-first shell / web-surface placement-control surface if truly needed |

### 19) Generic launch does not become embedded-web-surface authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-embedded-web-surface-boundary-v0.md`](openuri-embedded-web-surface-boundary-v0.md) | in-app browser / custom tab / Safari view controller / browser chrome customization | generic OpenURI exports no portable `in_app_browser`, `custom_tab`, `safari_view_controller`, `toolbar_color`, `action_button`, or equivalent embedded-browser surface seam; browser-surface choice and browser chrome stay provider-local rather than generic OpenURI truth | future RFC-first web-surface / embedded-browser control surface if truly needed |

### 20) Generic launch does not become browser-auth/session authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-auth-session-boundary-v0.md`](openuri-auth-session-boundary-v0.md) | browser-auth session / redirect capture / auth result handling | generic OpenURI exports no portable `auth_session`, `oauth`, `sso`, `redirect_uri`, `callback_scheme`, or equivalent browser-auth seam; auth-session UX and outcomes stay request-local or handler-local rather than generic OpenURI truth | future RFC-first auth / web-session surface if truly needed |

### 21) Generic launch does not become navigation-observation authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-navigation-observation-boundary-v0.md`](openuri-navigation-observation-boundary-v0.md) | page-load callbacks / redirect telemetry / final-URL observation / live page-state | generic OpenURI exports no portable `navigation_event`, `navigation_id`, `is_redirect`, `final_url`, `current_url`, `page_title`, `history_changed`, `loading_progress`, or equivalent navigation-observation seam; post-launch page-state stays handler-local rather than generic OpenURI truth | future RFC-first web/navigation/session surface if truly needed |

### 22) Generic launch does not become credential/autofill/passkey authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-credential-mediation-boundary-v0.md`](openuri-credential-mediation-boundary-v0.md) | password autofill / passkeys / credential-provider mediation / account selection | generic OpenURI exports no portable `autofill`, `password_autofill`, `otp_autofill`, `passkey`, `webauthn`, `credential_manager`, `credential_provider`, `federated_sign_in`, `conditional_mediation`, or equivalent credential-mediation seam; password/passkey/account mediation stays request-local or provider-local rather than generic OpenURI truth | future RFC-first auth / credential / autofill surface if truly needed |

### 23) Generic launch does not become browser/web permission authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-web-permission-boundary-v0.md`](openuri-web-permission-boundary-v0.md) | browser/web permission queries, prompts, remembered grants, and powerful-feature consent state | generic OpenURI exports no portable `permission_state`, `permission_query`, `request_permission`, `permission_prompt`, `permission_lifetime`, `grant_geolocation`, `grant_camera`, `grant_microphone`, `grant_notifications`, or equivalent browser/web-permission seam; downstream site-permission prompting and remembered-grant state stay request-local or provider-local rather than generic OpenURI truth | explicit `portal.location.*` / `portal.capture.*` / future RFC-first permission-mediation surface if truly needed |

### 24) Generic launch does not become verified-association trust authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-verified-association-boundary-v0.md`](openuri-verified-association-boundary-v0.md) | verified-app-link / associated-domain trust / domain-verification state | generic OpenURI exports no portable `verified_only`, `require_verified_association`, `require_verified_handler`, `verified_handler`, `verified_match`, `verified_domain`, `domain_verification_state`, `associated_domain`, `associated_domains`, `assetlinks_state`, `apple_app_site_association`, `app_link`, or `universal_link` seam; domain-association state and trusted-route outcomes stay shell-local or policy-local rather than generic OpenURI truth | future RFC-first association-aware routing / deep-link trust surface if truly needed |

### 25) Generic launch does not become browser/store/install fallback authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-install-fallback-boundary-v0.md`](openuri-install-fallback-boundary-v0.md) | browser fallback / app-store / inline install / install-if-missing | missing-handler or denied-scheme outcomes stay request-local; generic OpenURI exports no portable `browser_fallback_url`, `install_if_missing`, `store_url`, or equivalent software-acquisition/promotion seam | future RFC-first software-acquisition / app-market / promotion surface if truly needed |

### 26) Exact reveal does not become approximate browse

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`openuri-showitem-exactness-boundary-v0.md`](openuri-showitem-exactness-boundary-v0.md) | show-item fidelity | “show this item” keeps exact reveal/select meaning; no silent downgrade to parent-directory browse | explicit future RFC-first browse/fidelity surface if truly needed |

## Review rule

Before adding another D-PLUMB OpenURI companion boundary doc, answer these questions in order:
1) Is the change really an **OpenURI meaning pin** rather than a new workflow/schema/admin surface?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported launcher semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
