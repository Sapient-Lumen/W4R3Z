# MicroVM clipboard/drag-drop posture v0 (desktop helper transfer stays non-portable)

Purpose: pin the **Phase 1** meaning of host↔guest clipboard / drag-drop / convenience file-transfer integration under `ext.microvm` so desktop helper stacks do not quietly become a portable reviewed data / transfer / UI plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-PLUMB**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient host↔guest clipboard/drag-drop integration contract under `ext.microvm`; there is no portable shared-clipboard / drag-drop / guest-tools file-transfer plane, owner-local desktop-helper integration setup stays implementation-local, and reviewed transfer / file / clipboard meaning still rides on explicit D-PLUMB seams rather than ambient desktop-helper channels.**

Entropy cost justification: the archive already pins host↔guest transports, display/input devices, guest agents, and USB redirection individually, but workstation-oriented virtualization stacks still have one tempting shortcut left: just share clipboard and drag files between host and guest. SPICE vdagent, VMware open-vm-tools, and VirtualBox Guest Additions all treat clipboard sharing, drag/drop, and similar convenience transfer paths as normal guest-integration features. One narrow posture closes that gap without inventing a new transfer broker, guest integration protocol, or schema family.

## Posture (v0)

1) **No portable ambient host↔guest clipboard/drag-drop integration contract**
   - **Phase 1 exposes no portable ambient host↔guest clipboard/drag-drop integration contract.**
   - There is no portable reviewed guarantee that an admitted `ext.microvm` leaf exposes one stable shared clipboard, one stable drag/drop workflow, or one stable “copy text/files across the VM boundary” helper surface.
   - Guests may observe whatever one owner-local runtime chooses to expose, but those helper mechanisms do **not** become SlopOS portable API meaning.

2) **No portable shared-clipboard / drag-drop / guest-tools file-transfer plane**
   - There is **no portable shared-clipboard / drag-drop / guest-tools file-transfer plane** under Phase 1.
   - Portable reviewed meaning does **not** include one stable host↔guest text/image clipboard contract, one stable guest↔host file drag/drop contract, one stable directionality or auto-share policy, one stable desktop-helper status/inventory API, or one stable guest-side staging/location convention for transferred payloads.
   - Owner-local clipboard watchers, drag/drop helpers, per-session desktop daemons, host UI integrations, and convenience file-transfer helpers remain implementation-local rather than portable `ext.microvm` contract meaning.

3) **Owner-local desktop-helper integration setup stays implementation-local**
   - Owner-local desktop-helper integration setup stays implementation-local.
   - Guest packages, desktop services, helper daemons, `virtio-serial` / `spicevmc` channels, host UI toggles, and per-direction policy switches may still exist locally, but they do **not** create a portable reviewed promise about one standard clipboard/drag/drop transport, one stable helper-install contract, or one host-side status API.
   - In particular, deployments may not smuggle “this guest can always paste from the host” or “this drag/drop path is the reviewed file-transfer workflow” into portable semantics just because one runtime can wire those conveniences locally.

4) **Existing explicit seams remain authoritative**
   - Reviewed clipboard / share / drag-drop meaning still rides on explicit `D-PLUMB` seams such as `portal.xfer.*` and `CH-XFER` rather than ambient desktop-helper channels.
   - Reviewed document/file import-export meaning still rides on explicit document/transfer portal seams rather than a portable “drop a host file into the guest” convention.
   - Reviewed host↔guest channel posture still stays killable and explicit rather than being reintroduced through “UI integration” folklore.
   - Reviewed guest-management/helper meaning still stays on the already-pinned guest-agent posture rather than a portable “install tools for clipboard and drag/drop” story.

5) **Changing the clipboard/drag-drop stance is owner-local lifecycle policy or new admission, not a portable live admin plane**
   - Changing the clipboard/drag-drop stance is owner-local lifecycle policy or new admission, not a portable live admin plane.
   - If policy cares about a different host↔guest convenience-transfer posture, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to smuggle in a hidden portable `set_shared_clipboard_policy`, `push_clipboard_into_guest`, `begin_dragdrop_transfer`, or `list_transfer_capabilities` control plane by convention.
   - This keeps transfer meaning on already-pinned D-PLUMB seams rather than on ambient desktop-integration helpers.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new `CH-*` schema**, **no new ACP kind**, and **no new conflict-key family** in Phase 1.
   - Any later exposed action such as `set_shared_clipboard_policy`, `push_clipboard_into_guest`, `begin_dragdrop_transfer`, or `query_guest_transfer_capabilities` must say whether it commutes with activation, transfer policy, document policy, and guest-helper policy, and where serialization lives.
   - Until then, clipboard/drag/drop integration remains owner-local runtime convention rather than portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable shared clipboard contract under `ext.microvm`.
- No portable drag/drop or helper-driven file-transfer contract under `ext.microvm`.
- No portable directionality toggle, auto-share policy, helper inventory, or transfer-status API for host↔guest convenience transfer.
- No claim that desktop-helper clipboard or drag/drop integration is an acceptable portable substitute for explicit transfer/document portal workflows.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-XS, D-PLUMB, D-ACTIVATE)
- Adjacent postures/artifacts:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `microvm-display-input-posture-v0.md`
  - `microvm-guest-agent-posture-v0.md`
  - `transfer-portal-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-40)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-CLIPXFER)
- Policy posture:
  - clipboard/drag-drop guest integration adds **no new lane**, **no portable live push/pull plane**, and **no portable desktop-helper inventory truth contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_clipboard_dragdrop_posture.py` fails `make lint` if this posture stops being discoverable, loses its **non-portable clipboard-dragdrop integration / no portable shared-clipboard-drag-drop-guest-tools-file-transfer plane / owner-local desktop-helper integration setup stays implementation-local / explicit D-PLUMB transfer seams stay authoritative** constraints, or drops its assurance/reference wiring.

## References

- REF-SPICE-USER-MANUAL.
- REF-OPEN-VM-TOOLS.
- REF-VIRTUALBOX-GUESTADD-CLIPBOARD.
