# Signature trust-root boundary v0 (explicit verifier roots; no bundle self-anchoring or ambient root-store drift)

Purpose: pin the **Phase 1** meaning of signature/keyless trust roots across **D-SIGENV**, **D-KEYLESS**, and **D-TUF** so cert-bearing verification does not quietly inherit browser PKI, machine-global root stores, or artifact-bundled self-anchoring semantics.

Entropy cost justification: `signature-envelope-posture-v0.md`, `signing-time-evidence-boundary-v0.md`, `certificate-path-input-boundary-v0.md`, `certificate-status-evidence-boundary-v0.md`, and `certificate-identity-evidence-boundary-v0.md` already pin signed meaning, signing-time evidence, path inputs, status evidence, and certificate identity interpretation. The remaining ambiguity is **which roots/log keys/CA chains count, how they arrive, and whether signer-side service discovery is part of verifier meaning**. One narrow boundary closes that gap without adding a new schema family, root-management portal, or approval plane.

## Posture (v0)

1) **Trust roots remain explicit verifier-local input or explicit D-TUF/provisioning artifacts.**
   - Acceptance of certificate-bearing or keyless signatures requires an **explicit local set of trusted root material**: for example trusted CA roots, accepted transparency-log keys, accepted CT-log keys, accepted TSA roots, or exact already-authorized trusted-root artifacts.
   - That input may arrive through out-of-band provisioning, pinned local configuration, or explicit **D-TUF** repository metadata / trusted-root artifacts chosen by deployment policy, but it is **not inferred from the signed artifact itself**.
   - In other words: verifier trust roots remain **explicit local input**, not ambient machine state.

2) **Trusted-root carriers are adjunct artifacts, not native substrate meaning.**
   - TUF `root.json`, Sigstore `TrustedRoot` JSON, PEM root bundles, and similar carriers may package trusted verification material, but in Phase 1 they remain **adjunct artifacts or provisioning inputs**, not a new native CH-* schema family.
   - They may be shipped or referenced through existing packaging / `CH-AREF` / release-bundle paths, but the portable meaning still lands on existing **D-SIGENV / D-KEYLESS / D-TUF** seams and local policy.
   - Phase 1 therefore declines any silent widening where “trusted-root file exists” becomes its own portable authority object or approval verdict.

3) **Signing-service discovery is not verifier authority.**
   - Sigstore’s `SigningConfig` and similar service-descriptor formats primarily carry **service URLs and online signing configuration** for signers.
   - Those URLs, API-version preferences, and service-selection rules do **not** define verifier authority in SlopOS.
   - Phase 1 therefore adds no native Fulcio/Rekor/TSA discovery protocol, no “contact the service named in the trusted-root object” rule, and no signing-service URL inheritance on verification surfaces.

4) **Artifact bundles do not self-anchor or rotate trust.**
   - A bundle may carry certificates, intermediates, log proofs, timestamp responses, or a trusted-root artifact reference, but it MUST NOT thereby say “trust this root because this bundle contains it.”
   - Encountering a new root certificate, Rekor key, CT-log key, TSA root, or cross-signed trust anchor inside an artifact bundle MUST NOT auto-install or auto-prefer that material.
   - Root rotation remains explicit deployment policy, not bundle side effect.

5) **Trust-root distribution and rotation stay on D-TUF / provisioning, and only affect future verification.**
   - When deployments choose TUF-style distribution, root rotation and trusted-key changes remain repository/provisioning mechanics under **D-TUF** rather than semantics of **CH-SIGENV** itself.
   - Changing the local trusted-root set MAY change the outcome of **future** admissions and verifications.
   - It MUST NOT silently rewrite old evidence, retroactively mutate prior receipts, or turn a past verification record into a portable “still approved” verdict.

6) **No ambient browser / OS trust store / machine-global cache plane in v0.**
   - Phase 1 adds no rule that verification implicitly consults the host browser trust store, OS CA store, NSS/Keychain/WinCrypt roots, machine-global Sigstore cache, or whatever root bundle a local library happens to preload.
   - Compat layers may map local policy into those mechanisms for implementation convenience, but that mapping must remain explicit, policy-killable, and non-authoritative as substrate meaning.

7) **Sealed compat remains honest.**
   - Any interop with host trust stores, certificate managers, or Sigstore client caches must be killable by policy and must not create ambient authority via host paths, env vars, or hidden background refresh.
   - A compat runtime that cannot guarantee explicit root selection must fail closed for portable verification semantics.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no ACP kind, and no conflict-key namespace.
   - It only narrows what existing trusted-root material is allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native trusted-root / trust-store CH-* schema family in Phase 1.
- No portable Fulcio/Rekor/TSA service-discovery client protocol.
- No bundle-embedded self-anchoring or trust-on-first-bundle semantics.
- No ambient OS/browser/machine-global root-store lookup semantics.
- No retroactive approval semantics when trust roots rotate later.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, signature verification almost always drifts in four expensive directions:

- **Bundle bytes quietly become roots.** Presented trusted-root files or root certs get treated as “obviously what the signer intended,” reintroducing self-anchoring and hidden trust expansion.
- **Signer config becomes verifier truth.** Service URLs and online component selection rules leak from signer tooling into portable verification meaning.
- **Machine-local defaults outrun policy.** Browser/OS root stores, cached TUF state, or SDK defaults quietly become archive contract because “that is what verified on this box today.”
- **Rotation semantics turn into approval semantics.** A current root set or current trusted-root artifact gets read as “therefore previously verified things are still approved,” collapsing evidence, freshness, and local policy into one mutable object.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** reviewable offline verification can say exactly which trusted-root set was used instead of inheriting browser or machine-global trust defaults.
- **Cloud micro-VM / hosted substrate (B):** admission workers can pin explicit roots/log keys per deployment without ambient cache or node-image drift.
- **Embedded / separation-kernel-ish appliance (C):** high-assurance profiles can provision tiny explicit root sets and avoid any hidden online trust-refresh dependency.
- **Agent / automation OS (D):** agents can package or reason over trusted-root artifacts, but they cannot smuggle signer service URLs or bundle-contained roots into portable approval authority.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-TUF**.
- Adjacent seams:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/certificate-path-input-boundary-v0.md`
  - `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/60-engineering/update-repository-metadata-and-key-rotation.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
  - `rfcs/0079-tuf-style-update-repository-metadata.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_signature_trust_root_boundary.py` keeps the boundary small and discoverable (**EVID-2026-469**).

## References

- REF-RFC5280-PKIX
- REF-TUF-SPEC
- REF-SIGSTORE-CLIENT-SPEC
- REF-SIGSTORE-TRUSTROOT-PROTO
- REF-SIGSTORE-CUSTOM-COMPONENTS
