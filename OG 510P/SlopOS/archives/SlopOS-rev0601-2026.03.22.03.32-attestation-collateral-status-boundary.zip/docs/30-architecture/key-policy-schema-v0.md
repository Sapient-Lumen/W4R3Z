# CH-KEYPOL v0: Key usage policy descriptor

Purpose: a redaction-safe description of **how a key may be used** (D-CRYPTOSVC).  
This schema carries **no private key material**; it exists to make key usage reviewable, lintable, and enforceable.

V0 posture note: `cryptosvc-posture-v0.md` pins D-CRYPTOSVC as an **op-only, context-bound, explicit-route-only** seam; CH-KEYPOL is the reviewable policy pin that prevents call-site defaults or ambient agent behavior from deciding key use. `cryptosvc-interactive-auth-boundary-v0.md` further pins `confirm` as an approval requirement only, not a portable PIN / biometric / presence / unlock selector or auth-state query. `cryptosvc-mechanism-boundary-v0.md` likewise pins `alg` as policy pin/hint only, not a portable mechanism-discovery, provider-capability, or caller-negotiated padding/mode/hash/curve vocabulary. `cryptosvc-key-material-boundary-v0.md` further pins the closed op set as already-held key authority only, not a portable secret-bearing key import/export, backup/restore, or escrow vocabulary. `cryptosvc-key-lifecycle-boundary-v0.md` further pins the closed op set as use-only authority, not a portable generate/rotate/delete/alias-retargeting or provider-admin vocabulary. `cryptosvc-derived-material-boundary-v0.md` further pins `ops=["derive"]` as bounded-use authority only, not a portable deriveBits/deriveKey/raw-secret/wrap-unwrap/export contract. `cryptosvc-attestation-boundary-v0.md` further pins `ops=["attest"]` as bounded-use authority only, not a portable quote/report/token, nonce/challenge, evidence-format, or attestation-verifier-policy vocabulary. `cryptosvc-verification-boundary-v0.md` further pins the closed op set as key-use authority only, not a portable `verify` / certificate-path / trust-store / verifier-policy vocabulary.

Refs: REF-PLAN9-FACTOTUM, REF-OPENSSH-AGENTRESTRICT.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-KEYPOL v0 := {
  v: 0,

  ; allowed operation kinds (closed enum)
  ops: [ tstr ],                ; e.g., ["sign", "decrypt", "derive", "attest"]

  ; purpose/context tags to prevent “signing-oracle” cross-protocol misuse
  ; (clients must supply exactly one context string on each operation)
  contexts?: [ tstr ],          ; e.g., ["ssh", "update-signing", "tlog-anchor", "oauth-dpop"]

  ; optional hints/policies enforced by the provider (user space)
  confirm?: bool,               ; if true, require explicit approval/UI for each op (like ssh-agent -c); not a prompt-type or auth-modality selector
  rate?: {
    max_per_min?: uint,         ; bounded
    burst?: uint,               ; bounded
  },

  ; optional time/epoch binding (explicit clock kind; see D-NONDET)
  ; used for “only valid after T” / “expires at deadline”
  time_bounds?: {
    mode: tstr,                 ; "none" | "not_before" | "not_after" | "window"
    clock_kind?: tstr,          ; "monotonic_coarse" | "realtime_coarse" | "logical"
    not_before?: uint,
    not_after?: uint,
  },

  ; algorithm family hints (non-authoritative unless enforced)
  ; policy pin/hint only: not a portable mechanism-discovery or caller-negotiated profile surface
  alg?: tstr,                   ; e.g., "ed25519" | "p256" | "rsa3072" | "x25519" | "aes-gcm-256"

  ; optional audit classification
  class?: tstr,                 ; e.g., "user_auth", "device_attest", "release_signing"

  ; free-form policy notes (non-authoritative)
  note?: tstr,
}

## Validation notes
- `ops` MUST be non-empty and use the closed enum.
- If `contexts` is present, it MUST be non-empty and bounded length.
- Providers MUST fail closed if a requested op/context is not permitted (I-CRYPTO-2).
