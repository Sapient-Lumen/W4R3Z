# Disposable target-selection boundary v0 (request may ask for disposable; policy owns the destination)

Purpose: pin the Phase-1 meaning of **disposable destination selection** across **D-EPHEM**, **D-PLUMB**, **D-QUAR**, and future cross-domain routing so “open in disposable” stays a small, policy-owned execution posture instead of drifting into an ambient domain-selector, template inventory, or cross-domain service-name plane.

This is intentionally a **boundary** doc, not a new schema. It freezes one narrow import from the Qubes/qrexec ecosystem: **a caller may ask for a fresh disposable destination, but it does not get to choose or discover the concrete target by ambient name**.

Adjunct to:
- `disposable-domain-posture-v0.md`
- `open-untrusted-posture-v0.md`
- `plumb-posture-v0.md`
- RFC-0050 (`rfcs/0050-disposable-domains-and-one-shot-sandboxes.md`)

Research imports (translated into our artifacts, not copied):
- Qubes qrexec keeps cross-domain service calls behind explicit policy and uses `@dispvm` to mean **create a fresh disposable for this request**, not “reuse some ambient session” (REF-QUBES-QREXEC, REF-QUBES-RPC-POLICY).
- Qubes’ policy daemon normalizes a requested target and treats `@dispvm:<template>` as policy-engine input, showing that disposable routing is a **mediation-time** decision rather than a property of the caller’s ambient namespace (REF-QUBES-POLICY-DAEMON).
- Qubes’ disposable implementation keeps the destination side fresh and request-scoped, which is the part we import; we do **not** import caller-visible VM/template naming or admin surfaces (REF-QUBES-DISPOSABLE-IMPL).

## Posture (v0)

This boundary freezes one narrow hard decision: **requesters may ask for disposable routing, but policy/supervisor owns the concrete destination**. The numbered rules below are the Phase-1 posture for that seam.

## v0 boundary (hard decision)

1) **A caller may request “disposable”, not name a concrete destination**
   - Phase 1 portable workflows may ask for a **fresh disposable destination** as part of an already-declared action (`open_untrusted`, a future policy-owned cross-domain helper, or another RFC-first seam).
   - They do **not** name an existing running domain, a warm-template instance, a VM/template label, or a provider-internal pool member on the portable seam.
   - “Use a disposable” is therefore a bounded routing posture request, not a generic target selector.

2) **Policy/supervisor owns the exact destination choice**
   - The exact template digest, isolation backend, host placement, warm-leaf selection, and any implementation-local disposable class remain **policy/supervisor-owned** decisions under D-EPHEM.
   - A requester cannot force a particular template, force reuse of a previous disposable, or discover which concrete destination was picked beyond the bounded receipt/evidence already emitted by the owning workflow.
   - If policy forbids disposable routing or no admissible disposable target exists, the request fails closed; it does **not** silently widen into an ordinary non-disposable launch.

3) **Fresh-per-request stays real; no ambient reuse or source identity drift**
   - A disposable destination is always a **fresh one-shot destination for that request**.
   - Phase 1 therefore declines caller-visible knobs such as `same_disposable`, `reuse_last`, `route_to_existing`, or “pick this warm instance by id”.
   - A disposable target never becomes a stable source identity, inventory member, or callback endpoint visible to later unrelated requests.

4) **No caller-visible inventory, probing, or ambient naming side channel**
   - The portable seam adds no list/watch/search API for disposable templates, running disposables, target classes, or route-table entries.
   - Requesters cannot probe which domains/viewers/templates exist by varying a target string and reading policy/parser outcomes.
   - Compat adapters must not smuggle host domain names, environment variables, filesystem paths, or implicit bus names back in as a pseudo-disposable selector.

5) **Ordering and commutativity stay on the owning workflow, not on a new target-selector surface**
   - Phase 1 adds **no new ACP kind** and **no new conflict-key family** for disposable target selection itself.
   - If an existing or future workflow can route to a disposable, it keeps that workflow’s already-declared conflict key(s), commutativity stance, and serialization boundary.
   - Where actions do **not** commute, serialization lives where it already lives today: for example the owning workflow router/provider for one request-local safe-open or service invocation. Evidence remains the owning workflow’s existing receipts/tokens/tests, not a new disposable-selector order stream.

6) **Cross-domain service ideas stay RFC-first and narrower than qrexec naming**
   - This boundary deliberately does **not** introduce a generic qrexec-like named-service substrate in Phase 1.
   - If future work wants a reviewed cross-domain service surface, it must arrive RFC-first with its own service-id vocabulary, policy evaluation story, conflict keys, and evidence plan.
   - Until then, the only imported rule is the narrow one: **disposable destination selection stays explicit, policy-owned, fresh-per-request, and non-inventory**.

7) **All four product shapes benefit from the same honesty rule**
   - **Secure workstation (A):** “open in disposable” remains safe-open UX, not a hidden VM picker.
   - **Cloud micro-VM / hosted compute substrate (B):** warm microVM leaves may accelerate routing, but tenant/workload APIs still do not gain ambient host-side target selection or pool inventory.
   - **Embedded / separation-kernel-ish appliance (C):** profiles that disable D-EPHEM simply fail closed rather than growing a surprising alternate route selector.
   - **Agent/automation OS (D):** LLMs can propose “use disposable” as a bounded posture, but they cannot exfiltrate topology by probing template/domain names or force reuse of a previously warmed target.

## Phase 1 non-goals (explicitly deferred)

- **No generic qrexec-like named-service substrate** in Phase 1.
- **No caller-visible disposable template/domain inventory, watch, or search API**.
- **No `same_disposable`, `reuse_last`, or route-to-existing selector** on the portable seam.
- **No new ACP kind or conflict-key family** dedicated to disposable target selection itself.
- **No ambient compat escape hatch** that reintroduces host paths/env/domain names as pseudo-target selectors.

## Why this boundary exists

- **Keeps D-EPHEM honest:** a disposable is a destination posture, not a new ambient namespace.
- **Keeps sealed compat honest:** compat cannot reintroduce host/VM naming channels under the banner of “disposable”.
- **Keeps D-COMMUTE honest:** no new target-selector ordering plane appears without paying for it explicitly.
- **Reduces future entropy:** the archive already references disposables in safe-open, routing, and ecosystem notes; this boundary stops each future doc from re-deciding who owns the concrete destination choice.

## Consequences

- Future safe-open and disposable-aware workflows may say **“route via disposable posture”**, but they may not let callers choose concrete template/domain identities on the portable seam.
- Any future richer cross-domain service substrate must pay for its own RFC + vocabulary + policy + commutativity/evidence story rather than hiding inside D-EPHEM.
- Warm-template and routing accelerators remain implementation-local and killable by policy.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam.

If a second closely related disposable-routing boundary appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-EPHEM, D-PLUMB, D-QUAR)
- Adjacent posture/boundary surfaces:
  - `disposable-domain-posture-v0.md`
  - `open-untrusted-posture-v0.md`
  - `plumb-posture-v0.md`
  - `boundary-family-map.md`
- RFC / ecosystem history:
  - `rfcs/0050-disposable-domains-and-one-shot-sandboxes.md`
  - `rfcs/0003-ecosystem-features-to-bake-in.md`
  - `docs/90-inspirations/os-lessons.md`
- CI drift gate:
  - `tools/check_disposable_target_selection_boundary.py` (EVID-2026-569)

## References

- REF-QUBES-QREXEC
- REF-QUBES-RPC-POLICY
- REF-QUBES-POLICY-DAEMON
- REF-QUBES-DISPOSABLE-IMPL
