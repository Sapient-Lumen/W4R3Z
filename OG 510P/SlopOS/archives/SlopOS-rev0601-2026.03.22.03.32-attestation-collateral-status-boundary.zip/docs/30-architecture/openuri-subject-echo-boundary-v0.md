# D-PLUMB OpenURI subject-echo boundary v0 (no portable full-URI echo / receipt surface)

Purpose: pin one compact Phase-1 rule on the **OpenURI** seam: mediated URI launch does **not** become a portable full-subject echo, normalized-URI receipt, or durable raw-URI history/log/export surface on `portal.uri.*`.

This boundary is intentionally small. It introduces **no new schema family**, no new OpenURI request kind, no new receipt kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing mediated launch semantics may be interpreted.

This doc is a **family member of the closed D-PLUMB OpenURI companion boundary family** rooted at `openuri-boundary-index.md`.

## Posture (v0)

1) **No portable full-URI echo or receipt in v0.**
   - A requester may ask to open a bounded URI or show an already-authorized item.
   - Phase 1 does **not** export a portable `opened_uri`, `normalized_uri`, `resolved_uri`, `display_uri`, `echo_subject`, `history_uri`, or equivalent full-subject echo / receipt field on `portal.uri.*`.
   - Portable requester truth remains the mediated action + subject at request time, plus digest-first/redacted audit material where policy allows it.

2) **Request-local subject bytes stay request-local.**
   - Portals/shells may parse or display the full URI locally when mediating a request, choosing policy, or presenting immediate UX.
   - That does **not** make the literal URI text durable reviewed truth for receipts, denials, transcript export, shell history, or CLI success contracts.
   - Durable transcript/export uses digests or bounded redacted summaries rather than verbatim URI text, especially for query / fragment / userinfo-bearing subjects.

3) **Why this cut is honest.**
   - Real URI ecosystems make this necessary: RFC 3986 warns that `user:password` userinfo is deprecated, that applications should not render the password part as clear text, and that secret-bearing URIs are frequently displayed, stored in clear-text bookmarks, and logged by history/intermediaries.
   - RFC 6819 likewise notes that referrer headers are commonly logged, request logs commonly include query parameters, and browser history commonly records visited URLs.
   - SlopOS therefore keeps Phase-1 OpenURI truth on the request-local subject plus digest-first receipts/transcripts rather than turning generic launch into a durable raw-URI echo plane.

4) **Ordering and commutativity stay on the existing OpenURI seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `open_uri` ordering remains at `svc:portal.uri`; Phase 1 still does **not** create a new transcript-echo action family, conflict-key family, or serialization surface.
   - Any future export/admin/history surface that truly needs stable subject material must state its own conflict keys, redaction policy, and evidence rules explicitly rather than inheriting folklore from launcher UX.

5) **Sealed compat remains killable and non-ambient.**
   - Compat runtimes do not regain ambient host history/logging of literal launched URIs through helper fallbacks.
   - If compat wants OpenURI, it still goes through `portal.uri.*`, and any durable transcript/export remains bound by existing digest-first / redaction-first observation policy.

## Phase 1 non-goals (explicitly deferred)

- No portable `opened_uri`, `normalized_uri`, `resolved_uri`, `display_uri`, or equivalent echo/result field on `portal.uri.*`.
- No transcript-stable promise that receipts/denials/log exports preserve the literal launched URI string.
- No shell-history/admin/query surface that treats generic OpenURI as a durable raw-URI catalog.
- No new ACP/admin surface for OpenURI subject echo, URI-history disclosure, or normalized-URI reporting.
- No hidden compat/helper fallback that reintroduces full-subject logging as portable truth.

## Why this is worth pinning

The archive already prefers digest-first receipts and redaction-aware transcript export, but `open_uri` still carries a literal `subject.uri` in CH-PLUMBMSG. That makes OpenURI especially vulnerable to convenience drift: shell helpers, agent tools, or audit viewers are tempted to echo the exact URI back out as “helpful” status, normalize it into a receipt field, or let raw URI text harden into shell history semantics.

Pinning the boundary now keeps SlopOS from quietly turning mediated launch into a durable raw-URI side channel. That matters for all four product shapes: workstation links and helper launches often carry query tokens or sensitive paths; hosted and embedded profiles should not invent fake URL-history planes just because richer desktops have them; and agent tooling should not depend on literal-URI transcript echoes when the architecture already prefers digest-first, redaction-aware evidence.

## Profile effect (A–D)

- **Secure workstation (A):** mediated link opening remains useful without hardening query-bearing URLs into receipt/history folklore.
- **Cloud micro-VM substrate (B):** tenant/guest tooling can request mediated launch where allowed without assuming durable raw-URI transcript or shell-history semantics exist.
- **Embedded / separation appliance (C):** profiles without general desktop history UIs avoid carrying fake raw-URI receipt/history semantics just because larger ecosystems leak them.
- **Agent/automation OS (D):** agents/tools cannot rely on exact URI echo as portable state; durable evidence stays digest-first and redaction-aware.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PLUMB**.
- Family discovery surface:
  - `docs/30-architecture/openuri-boundary-index.md`
- Adjacent meaning pins:
  - `docs/30-architecture/openuri-portal-posture-v0.md`
  - `docs/30-architecture/plumb-message-schema-v0.md`
  - `docs/30-architecture/transcript-contract.md`
  - `docs/30-architecture/portal-family-registry.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-OPENURI-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-OPENURI-ENF**)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_subject_echo_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable full-URI echo-or-receipt / request-local-subject-only / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-579**).

## References

- REF-XDG-PORTAL-REQUEST.
- REF-RFC3986-URI-GENERIC-SYNTAX.
- REF-RFC6819-OAUTH-SECURITY.
