# Hybrid topology authority boundary index (v0)

Purpose: keep the **closed set of D-MK / D-CLUSTERMAP / D-SKB Hybrid topology-authority companion boundary docs** enumerable.

Why this exists:
- the archive now pins several small boundaries so richer topology facts do not quietly widen Hybrid ownership or authority semantics,
- those docs are individually crisp but easy to forget piecemeal because they span auto clustering, cache sharing, heterogeneous CPU capacity, memory locality matrices, and the final closed Hybrid Phase 1 posture,
- `hybrid-phase1-boundary-v0.md`, `cluster-derivation.md`, and `cluster-phase1-envelope-v0.md` keep the overall Hybrid meaning, while this index is the **discovery surface** that says which companion boundaries currently keep Phase 1 topology facts coarse, hint-only, and RFC-first to widen.

This doc does **not** add a new schema, action kind, or workflow family.
It is an entropy-reducing companion to `hybrid-phase1-boundary-v0.md`, `cluster-derivation.md`, and ADR-0005.

## Inclusion rule

A doc belongs here if it removes exactly one tempting topology/heterogeneity meaning from Phase 1 by constraining one of:
- which discovered hardware facts may define **owner clusters** versus remaining placement hints only,
- which richer topology hints may influence optimization without becoming budget / routing / replay / admission authority,
- or how the closed Hybrid Phase 1 posture resists re-opening through richer host topology exports or replication folklore.

If future work needs a new native authority-bearing topology or placement policy instead, that work must return **RFC-first** as its own decision surface rather than hiding behind richer CH-HWFACT / CH-CLUSTERMAP interpretation.

## Closed companion boundary set (Phase 1)

### 1) Cluster ownership stays coarse and explicit

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cluster-auto-boundary-v0.md`](cluster-auto-boundary-v0.md) | `preferred_boundary = auto` | default Hybrid cluster derivation stays **NUMA → socket → core_group** only; `die` remains explicit-policy-only rather than silently becoming the new default ownership unit | explicit reviewed policy for any finer boundary |

### 2) Richer topology facts stay placement hints only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`cache-topology-authority-boundary-v0.md`](cache-topology-authority-boundary-v0.md) | cache/LLC sharing facts | cache ids and future cache-sharing hints may improve locality inside a chosen cluster, but they do not create new ownership or replication boundaries | explicit future cache-aware ownership policy |
| [`cpu-capacity-authority-boundary-v0.md`](cpu-capacity-authority-boundary-v0.md) | asymmetric CPU-capacity / performance-class facts | heterogeneous-core metadata may guide in-cluster placement or ranking, but it does not become cluster / budget / replay / authority semantics | explicit future perf-aware authority policy |
| [`memory-locality-authority-boundary-v0.md`](memory-locality-authority-boundary-v0.md) | NUMA-distance / HMAT / memory-tier facts | richer locality matrices may guide placement and audit, but they do not become distance-adaptive ownership, replication, or admission authority | explicit future locality-aware authority policy |

### 3) Hybrid Phase 1 closure stays explicit and reviewable

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`hybrid-phase1-boundary-v0.md`](hybrid-phase1-boundary-v0.md) | closed OQ-0001 posture | the combined Phase 1 Hybrid authority surface is closed: coarse auto clustering, hint-only richer topology facts, registry-closed replication family meanings, and the bounded flagship claim envelope remain one reviewable posture rather than open-ended prose | explicit RFC/ADR + schema/evidence updates for any widening |

## Review rule

Before adding another Hybrid topology companion boundary doc, answer these questions in order:
1) Is the change really a **D-MK / D-CLUSTERMAP / D-SKB Hybrid meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported topology semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.
