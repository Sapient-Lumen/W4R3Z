# D-PLUMB OpenURI posture v0 (manual-only; scheme-gated; launch-only)

Purpose: pin an **implementable Phase 1** meaning for `portal.uri.*` so “open a link / show this item” stays a mediated launch workflow rather than regressing into ambient helper exec, installed-app probing, hidden callback channels, or a fake completion oracle.
It narrows an already-present portal family into something UX, policy, and receipts can test without turning SlopOS into a handler-inventory oracle.

## Posture (v0)

1) **No ambient OpenURI constructors**
   - If D-PLUMB is enabled, opening external URIs / showing local items happens only via `portal.uri`.
   - There is no ambient `xdg-open` / `open` / `start` / `ShellExecute`-style helper path after init, and sealed compat adapters do not get a host shortcut.
   - The seam remains fail-closed behind `cfg.params.lane.portal.uri`.

2) **Manual-only v0; no ACP automation kind**
   - `portal.uri.*` remains **manual-only v0** on the ACP surface.
   - Phase 1 does **not** introduce a `portal.uri.request` or similar automation kind.
   - Any future automation surface must come back with explicit conflict-key / commutativity / retry semantics rather than inheriting toolkit behavior.

3) **Scheme-gated and bounded**
   - URI inputs are bounded, parsed, and canonicalized before routing.
   - Scheme allowlists are shell/policy-owned; unknown, private, or custom schemes deny by default in strict profiles unless explicitly allowed.
   - `file://` URIs and raw host paths are **not** OpenURI authority in v0; opening local files/directories remains a `portal.file.*` / CH-DOCREF or already-held-handle workflow.

4) **Launch-only, not a return channel**
   - OpenURI may launch or foreground a chosen handler, but it does **not** return a capability to the requester, a callback token, or a wakeup/reentry channel.
   - Success means the mediation/launch request was accepted, not that the target finished, granted reciprocal authority, or completed some downstream network action.
   - Asking another component to open `https:` or `mailto:` does not grant the requester ambient network authority; `portal.net` remains separate.
   - Companion callback-reentry boundary: request-local completion stays on the portal request/receipt path, so Phase 1 exports no portable callback URL, redirect-back, deep-link reentry, or `x-success` / `x-error` / `x-cancel` rendezvous seam (`openuri-callback-reentry-boundary-v0.md`).

5) **No app-visible handler inventory or preflight probing in v0**
   - Phase 1 does **not** expose a generic `list_handlers()`, package/app inventory, or `canOpenURL` / `queryIntentActivities`-style probing surface to applications via `portal.uri`.
   - Any “ask every time” UI, default-handler memory, or launcher heuristics remain shell/portal-owned.
   - Companion scheme-support boundary: exact support knowledge stays shell/policy-owned and does not become a requester-visible `SchemeSupported` / `canOpenURL` oracle in Phase 1 (`openuri-scheme-support-boundary-v0.md`).

6) **No requester-visible handler-choice or chooser-control surface in v0**
   - Phase 1 does **not** export a portable `open_with(app)`, `ask`, `force_chooser`, `skip_chooser`, or `use_default` control on `portal.uri.*`.
   - Concrete handler choice, chooser/default policy, and any selected-handler identity remain shell-owned routing state.
   - Companion handler-selection boundary: chooser/default policy and concrete handler choice stay shell-owned rather than becoming portable requester knobs or receipts (`openuri-handler-selection-boundary-v0.md`).

7) **No portable opener-attribution surface in v0**
   - Phase 1 does **not** export a portable source-app / referrer / opener-window payload on `portal.uri.*`.
   - Portal/shell may know requester/window context internally for focus, routing, or audit policy, but that knowledge remains local rather than a target-visible cross-app contract.
   - Companion opener-attribution boundary: opener identity and referrer-like metadata stay portal/shell-owned rather than becoming a portable source-app / referrer channel (`openuri-opener-attribution-boundary-v0.md`).

8) **No portable foreground / activation control or receipt in v0**
   - Phase 1 does **not** export a portable `activation_token`, `activate`, `foreground`, `raise`, `bring_to_front`, or equivalent attention-steering surface on `portal.uri.*`.
   - Portal/shell may use local activation mechanics internally, but those stay provider-owned policy rather than a requester-visible control plane or frontmost receipt.
   - Companion activation-control boundary: foregrounding and activation handoff stay shell/compositor-owned rather than becoming a portable requester-visible control or receipt seam (`openuri-activation-control-boundary-v0.md`).

9) **OpenURI outcomes stay admission-scoped in v0**
   - Phase 1 portable truth is whether the mediated launch request was accepted/carried out at the portal seam.
   - OpenURI exports **no** portable launched-handler completion, liveness, exit-status, or “the user definitely saw this” receipt.
   - Companion launch-completion boundary: mediated outcome remains admission-scoped rather than a portable target-completion or current-live-state oracle (`openuri-launch-completion-boundary-v0.md`).

10) **No portable recent-items / durable history control or receipt in v0**
   - Phase 1 does **not** export a portable `add_to_recent`, `record_history`, `suppress_history`, `dont_add_to_recent`, `recent_item_id`, or equivalent durable-history knob/receipt on `portal.uri.*`.
   - A shell/provider may keep bounded local hints that a launch occurred, but those hints remain shell-owned, non-authoritative, path-free, and non-reopen-capable unless another explicit seam says otherwise.
   - Companion recent-items boundary: launch-history and reopen-enrollment semantics stay shell-owned, while durable reopen of local objects belongs on `portal.file.*` / CH-DOCREF rather than generic OpenURI (`openuri-recent-items-boundary-v0.md`).

11) **No portable full-URI echo or receipt in v0**
   - Phase 1 does **not** export a portable `opened_uri`, `normalized_uri`, `resolved_uri`, `display_uri`, `echo_subject`, `history_uri`, or equivalent raw-subject echo/receipt field on `portal.uri.*`.
   - Portal/shell may still inspect or display the full URI locally when mediating a request, but durable receipts/logs/history/export prefer digests or bounded redacted summaries rather than verbatim URI text.
   - Companion subject-echo boundary: full launched URIs stay request-local rather than becoming a portable receipt/history/logging seam (`openuri-subject-echo-boundary-v0.md`).

12) **No portable download / staging / docref-minting seam in v0**
   - Phase 1 does **not** export a portable `download=true`, `stage_local_copy`, `materialize_uri`, `import_to_file`, `save_as_docref`, `download_id`, `staged_path`, `docref`, or equivalent download/materialization/import result on `portal.uri.*`.
   - A chosen handler may fetch or cache bytes internally, but that stays handler-local implementation detail rather than a portable portal result, durable local-object receipt, or file-authority side effect.
   - Companion materialization boundary: generic URI launch does not become a portable download/staging/docref-minting seam; durable bytes and local-object identity stay on explicit file/document workflows (`openuri-materialization-boundary-v0.md`).

13) **No portable resource-grant / URI-permission / security-scope seam in v0**
   - Phase 1 does **not** export a portable `grant_read`, `grant_write`, `grant_uri_permission`, `persist_uri_permission`, `grant_target_app`, `content_uri`, `clipdata_uri`, `security_scope`, `security_scoped_bookmark`, `share_docref`, `attachment_docref`, `xfer_token`, or equivalent local-resource grant / handoff field on `portal.uri.*`.
   - A shell, browser, activity resolver, document provider, share sheet, or chosen handler may still attach a content URI, pass a temporary/persistable URI permission, or resolve a sandbox bookmark locally, but those grant mechanics remain provider-local rather than portable portal truth.
   - Companion resource-grant boundary: generic URI launch does not become a portable URI-permission / security-scope / attachment-grant seam; local-object authority transfer stays on explicit file/document/transfer workflows instead (`openuri-resource-grant-boundary-v0.md`).

14) **No portable network-request customization seam in v0**
   - Phase 1 does **not** export a portable `headers`, `extra_headers`, `request_headers`, `http_method`, `method=POST`, `request_body`, `body_bytes`, `user_agent`, or equivalent request-customization field on `portal.uri.*`.
   - A chosen handler may still dereference the URI using its own browser/network stack, but those request details remain handler-local implementation semantics rather than portable portal truth.
   - Companion request-shaping boundary: generic URI launch does not become a portable request-header / method / body customization seam; richer fetch/web control must return on an explicit future seam (`openuri-request-shaping-boundary-v0.md`).

15) **No portable content-type / MIME / UTI classification seam in v0**
   - Phase 1 does **not** export a portable `content_type`, `mime_type`, `declared_mime_type`, `sniffed_mime_type`, `sniff_content`, `probe_head`, `uti`, `uniform_type_identifier`, `open_as_type`, `resolved_content_type`, or equivalent content-type / classification field on `portal.uri.*`.
   - A chosen handler, shell, or launcher may still classify content, sniff bytes, or route by type locally, but those classification semantics remain provider-local rather than portable portal truth.
   - Companion content-type boundary: generic URI launch does not become a portable content-type / MIME / UTI / sniff/classification seam; richer fetch/classify/type-routing control must return on an explicit future seam (`openuri-content-type-boundary-v0.md`).

16) **No portable speculative-loading seam in v0**
   - Phase 1 does **not** export a portable `warmup`, `prewarm`, `preconnect`, `dns_prefetch`, `prefetch`, `may_launch`, `may_launch_url`, `prerender`, `speculate`, `speculation_rules`, `preresolve`, or equivalent speculative-loading field on `portal.uri.*`.
   - A shell, browser, agent, or other handler may still warm a browser process, pre-resolve origins, preconnect, prefetch, or prerender locally, but that behavior remains provider-local rather than portable portal truth or a transcript-stable receipt.
   - Companion speculative-loading boundary: generic URI launch does not become a portable warmup / preconnect / prefetch / prerender seam; reviewed speculative-loading control must return on an explicit future seam (`openuri-speculative-loading-boundary-v0.md`).

17) **No portable link-preview / unfurl metadata seam in v0**
   - Phase 1 does **not** export a portable `preview`, `fetch_metadata`, `unfurl`, `preview_card`, `preview_title`, `preview_description`, `preview_image`, `preview_icon`, `favicon`, `open_graph`, `oembed`, or equivalent link-preview / unfurl metadata field on `portal.uri.*`.
   - A shell, browser, chat surface, or other handler may still fetch metadata, crawl the target, or render preview UI locally, but that behavior remains provider-local rather than portable portal truth or a transcript-stable receipt.
   - Companion preview-metadata boundary: generic URI launch does not become a portable link-preview / unfurl / metadata-fetch seam; reviewed preview generation must return on an explicit future seam (`openuri-preview-metadata-boundary-v0.md`).

18) **No portable reader / content-extraction seam in v0**
   - Phase 1 does **not** export a portable `reader_mode`, `reader_view`, `distill`, `extract_article`, `extract_content`, `readability`, `article_text`, `article_html`, `article_markdown`, `text_content`, `summary`, or equivalent reader/distillation/extracted-content field on `portal.uri.*`.
   - A shell, browser, reader surface, or other handler may still distill pages, classify them as readerable, extract core text, or show local summaries, but that behavior remains provider-local rather than portable portal truth or a transcript-stable receipt.
   - Companion content-extraction boundary: generic URI launch does not become a portable reader-mode / article-distillation / extracted-content seam; reviewed extraction/summarization must return on an explicit future seam (`openuri-content-extraction-boundary-v0.md`).

19) **No portable URL-safety / phishing / malware / reputation-verdict seam in v0**
   - Phase 1 does **not** export a portable `safe_browsing`, `url_reputation`, `threat_verdict`, `threat_type`, `phishing`, `malware`, `deceptive_site`, `unsafe_reason`, `block_reason`, `reputation_score`, `safe_to_open`, `enterprise_verdict`, `allow_if_clean`, or equivalent URL-safety / threat-verdict field on `portal.uri.*`.
   - A shell, browser, enterprise policy engine, or chosen handler may still consult local Safe Browsing / SmartScreen / fraudulent-website-warning style checks, reputation feeds, or policy verdicts internally, but those checks and outcomes remain provider-local or policy-local rather than portable portal truth.
   - Companion URL-safety boundary: generic URI launch does not become a portable URL-safety / phishing / malware / reputation-verdict seam; warning/interstitial and provider-fed policy verdicts stay provider-local or policy-local rather than transcript-stable OpenURI truth (`openuri-url-safety-boundary-v0.md`).

20) **No portable browser-session / profile selection seam in v0**
   - Phase 1 does **not** export a portable `private`, `incognito`, `ephemeral_session`, `ephemeral_browsing`, `profile_id`, `browser_profile`, `cookie_jar`, `share_cookies`, or equivalent browser-session/profile selection field on `portal.uri.*`.
   - A chosen handler may still use its default shared browser state, an ephemeral/private mode, or another local profile/session mode, but those choices remain handler-local rather than portable portal truth.
   - Companion session-selection boundary: generic URI launch does not become a portable browser-session / profile / cookie-jar / private-mode selection seam; richer auth/web-session control must return on an explicit future seam (`openuri-session-selection-boundary-v0.md`).

21) **No portable launch-disposition / placement / reuse seam in v0**
   - Phase 1 does **not** export a portable `disposition`, `target`, `window_name`, `current_tab`, `current_window`, `new_tab`, `new_window`, `reuse_window`, `reuse_tab`, `new_task`, `new_document`, `new_instance`, `launch_bounds`, or equivalent placement/reuse field on `portal.uri.*`.
   - A shell, browser, activity/task manager, or chosen handler may still place the URI into an existing window, open a new tab/window, create a new task/document, or prefer a new app instance locally, but those choices remain provider-local rather than portable portal truth.
   - Companion launch-disposition boundary: generic URI launch does not become a portable tab/window/task placement, browsing-context target, named-window reuse, or app-instance reuse/new-instance seam; reviewed placement control must return on an explicit future seam (`openuri-launch-disposition-boundary-v0.md`).

22) **No portable embedded-web-surface seam in v0**
   - Phase 1 does **not** export a portable `in_app_browser`, `embedded_web`, `custom_tab`, `safari_view_controller`, `trusted_web_activity`, `toolbar_color`, `action_button`, `secondary_toolbar`, `browser_chrome`, or equivalent embedded-browser surface field on `portal.uri.*`.
   - A shell, browser, or chosen handler may still present the URI in an in-app browser, custom tab, Safari-view-controller-style surface, partial sheet, or app-branded browser chrome locally, but those presentation choices remain provider-local rather than portable portal truth.
   - Companion embedded-web-surface boundary: generic URI launch does not become a portable in-app-browser / custom-tab / Safari-view-controller / browser-chrome customization seam; browser-surface choice and browser chrome stay provider-local rather than transcript-stable OpenURI truth (`openuri-embedded-web-surface-boundary-v0.md`).

23) **No portable navigation-observation seam in v0**
   - Phase 1 does **not** export a portable `navigation_event`, `navigation_id`, `is_redirect`, `redirect_count`, `source_changed`, `content_loading`, `dom_content_loaded`, `navigation_completed`, `final_uri`, `final_url`, `current_url`, `page_title`, `history_changed`, `is_loading`, `loading_progress`, `can_go_back`, `can_go_forward`, `tab_hidden`, or equivalent browser/web navigation-observation field on `portal.uri.*`.
   - A shell, browser, embedded-web surface, or chosen handler may still track page-load, redirect, final-URL, history, or progress state locally, but those observations remain handler-local rather than portable portal truth.
   - Companion navigation-observation boundary: generic URI launch does not become a portable page-load / redirect / final-URL / browser-state callback seam; post-launch navigation observation stays handler-local or on an explicit future web/navigation surface (`openuri-navigation-observation-boundary-v0.md`).

24) **No portable browser-auth / SSO / OAuth login seam in v0**
   - Phase 1 does **not** export a portable `auth_session`, `authenticate`, `web_auth`, `oauth`, `oidc`, `sso`, `redirect_uri`, `callback_scheme`, `redirect_host`, `redirect_path`, `prefer_ephemeral_session`, `prefer_ephemeral_browser_session`, `account_chooser`, `credential_broker`, or equivalent browser-auth/session field on `portal.uri.*`.
   - A chosen handler may still run an auth flow, capture a redirect, choose an account, or prefer an ephemeral browser session locally, but those choices and outcomes remain request-local or provider-local rather than portable portal truth.
   - Companion auth-session boundary: generic URI launch does not become a portable browser-auth / SSO / OAuth login seam; redirect capture, auth-session UX, and auth-result handling stay request-local or handler-local rather than transcript-stable OpenURI truth (`openuri-auth-session-boundary-v0.md`).

25) **No portable credential / autofill / passkey seam in v0**
   - Phase 1 does **not** export a portable `autofill`, `password_autofill`, `otp_autofill`, `passkey`, `passkey_assertion`, `passkey_registration`, `webauthn`, `navigator_credentials_get`, `navigator_credentials_create`, `credential_manager`, `credential_provider`, `federated_sign_in`, `conditional_mediation`, `immediate_mediation`, `prefer_immediately_available_credentials`, `account_selector`, or equivalent credential-mediation field on `portal.uri.*`.
   - A shell, browser, platform credential manager, autofill service, passkey provider, or chosen handler may still offer passwords, passkeys, or account selection locally, but those choices and outcomes remain request-local or provider-local rather than portable portal truth.
   - Companion credential-mediation boundary: generic URI launch does not become a portable credential-provider / password-autofill / passkey seam; credential mediation stays request-local or provider-local rather than transcript-stable OpenURI truth (`openuri-credential-mediation-boundary-v0.md`).

26) **No portable web-permission / powerful-feature prompt seam in v0**
   - Phase 1 does **not** export a portable `permission_name`, `permission_state`, `permission_query`, `request_permission`, `permission_prompt`, `permission_lifetime`, `remember_permission`, `grant_geolocation`, `grant_camera`, `grant_microphone`, `grant_notifications`, `geolocation_permission`, `camera_permission`, `microphone_permission`, `notification_permission`, `clipboard_permission`, or equivalent browser/web-permission field on `portal.uri.*`.
   - A shell, browser, or chosen handler may still prompt for geolocation, camera, microphone, notifications, clipboard, or other powerful-feature permissions locally, but those prompts, remembered grants, and resulting states remain request-local or provider-local rather than portable portal truth.
   - Companion web-permission boundary: generic URI launch does not become a portable browser/web permission broker or powerful-feature prompt seam; downstream site-permission prompting and permission-state truth stay request-local or provider-local rather than transcript-stable OpenURI truth (`openuri-web-permission-boundary-v0.md`).

27) **No portable verified-app-link / associated-domain trust seam in v0**
   - Phase 1 does **not** export a portable `verified_only`, `require_verified_association`, `require_verified_handler`, `verified_handler`, `verified_match`, `verified_domain`, `domain_verification_state`, `associated_domain`, `associated_domains`, `assetlinks_state`, `apple_app_site_association`, `app_link`, `universal_link`, or equivalent verified-association field on `portal.uri.*`.
   - A shell, browser, or chosen handler may still consult local domain-association evidence, Digital Asset Links / apple-app-site-association state, or trusted-route policy internally, but those choices and outcomes remain shell-local or policy-local rather than portable portal truth.
   - Companion verified-association boundary: generic URI launch does not become a portable verified-app-link / associated-domain trust seam; domain-association state and trusted-route outcomes stay shell-local or policy-local rather than transcript-stable OpenURI truth (`openuri-verified-association-boundary-v0.md`).

28) **No portable browser/store/install fallback seam in v0**
   - Phase 1 does **not** export a portable `fallback_url`, `browser_fallback_url`, `install_if_missing`, `store_url`, `market_url`, `app_store_id`, `inline_install`, `instant_app`, or equivalent browser/store/install fallback field on `portal.uri.*`.
   - Missing-handler, denied-scheme, blocked-policy, or failed-admission cases stay request-local rather than silently triggering a browser fallback page, store listing, inline install, or software-acquisition retry path.
   - Companion install-fallback boundary: generic URI launch does not become a portable browser/store/install broker; reviewed software-acquisition or promotion control must return on an explicit future seam (`openuri-install-fallback-boundary-v0.md`).

29) **OpenDirectory / show-item stays path-free, non-amplifying, and exact**
   - “Show in file manager” / “open containing directory” requires an already-held file/directory handle or a CH-DOCREF reopen path.
   - `portal.uri` does not mint new file authority, leak host paths, or widen a file selection into ambient directory enumeration.
   - Companion show-item exactness boundary: if a backend cannot faithfully reveal/select the target object, Phase 1 fails closed rather than silently degrading into opening the parent directory or a generic browse surface (`openuri-showitem-exactness-boundary-v0.md`).

30) **Ordering lives in the portal**
   - Externally visible OpenURI state (default-handler memory, focus/foreground decisions, “ask” state) is ordered inside `svc:portal.uri`.
   - Two `open_uri` requests may commute with respect to the requester’s authority (they mint none) but do **not** necessarily commute with respect to shell-visible launch order or default-handler state.
   - Any future ACP surface must keep its conflict keys and serialization boundary explicit rather than burying them in toolkit callbacks.

31) **Sealed compat remains killable and non-ambient**
   - Foreign Cell “open link / show item” flows must route through `portal.uri` or an explicit adapter that remains policy-killable.
   - Compat runtimes do not gain ambient host helper execution, package-manager query authority, or fake target-completion truth.

## Phase 1 non-goals (explicitly deferred)

- **No ACP automation kind** for `portal.uri.*` in Phase 1.
- **No generic handler inventory / installed-app query API** visible to applications.
- **No requester-visible `SchemeSupported` / `canOpenURL` / `queryIntentActivities` API** in Phase 1.
- **No callback / return / reentry channel / launched-app telemetry** hidden behind OpenURI success.
- **No portable resource-grant / URI-permission / security-scope seam** hidden behind OpenURI success.
- **No requester-visible `open_with(app)` / chooser/default control** in Phase 1.
- **No selected-handler identity / chooser transcript / default-state receipt** in Phase 1.
- **No portable source-app / referrer / opener-window channel** in Phase 1.
- **No portable foreground / activation control or receipt** in Phase 1.
- **No portable launched-handler completion / liveness / exit-status / current-live-state receipt** in Phase 1.
- **No portable recent-items / durable history control, reopen token, or receipt** in Phase 1.
- **No portable full-URI echo / normalized-subject receipt / durable raw-URI history seam** in Phase 1.
- **No portable download / staging / import / docref-minting seam** on generic URI launch.
- **No `file://` / host-path loophole** that bypasses `portal.file.*` / CH-DOCREF.
- **No portable request-header / method / body customization seam** on generic URI launch.
- **No portable content-type / MIME / UTI classification seam** on generic URI launch.
- **No portable URL-safety / phishing / malware / reputation-verdict seam** on generic URI launch.
- **No portable speculative-loading seam** on generic URI launch.
- **No portable link-preview / unfurl metadata seam** on generic URI launch.
- **No portable reader / article-distillation / extracted-content seam** on generic URI launch.
- **No portable browser-session / profile / cookie-jar / private-mode selection seam** on generic URI launch.
- **No portable launch-disposition / placement / reuse seam** on generic URI launch.
- **No portable embedded-web-surface seam** on generic URI launch.
- **No portable browser-auth / SSO / OAuth login seam** on generic URI launch.
- **No portable navigation-observation / final-URL / page-state seam** on generic URI launch.
- **No portable credential / autofill / passkey seam** on generic URI launch.
- **No portable web-permission / powerful-feature prompt seam** on generic URI launch.
- **No portable verified-app-link / associated-domain trust seam** on generic URI launch.
- **No portable browser/store/install fallback seam** on generic URI launch.
- **No silent widening** from OpenURI into net/file/device authority.
- **No silent downgrade** from exact show-item/reveal intent into approximate parent-directory browse.

## Wiring

- Decision surface:
  - `decision-map.md` (D-PLUMB)
- Control surfaces:
  - `portal-family-registry.md` (`portal.uri.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.uri`)
  - `effect-contract-schema-v0.md` (`portal.uri` effect family)
  - `intent-kind-registry.md` (`open_uri`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-OPENURI-1, I-OPENURI-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-OPENURI-ENF)
- Companion boundary family:
  - `openuri-boundary-index.md`
  - `openuri-scheme-support-boundary-v0.md`
  - `openuri-handler-selection-boundary-v0.md`
  - `openuri-opener-attribution-boundary-v0.md`
  - `openuri-activation-control-boundary-v0.md`
  - `openuri-callback-reentry-boundary-v0.md`
  - `openuri-launch-completion-boundary-v0.md`
  - `openuri-recent-items-boundary-v0.md`
  - `openuri-subject-echo-boundary-v0.md`
  - `openuri-materialization-boundary-v0.md`
  - `openuri-request-shaping-boundary-v0.md`
  - `openuri-content-type-boundary-v0.md`
  - `openuri-url-safety-boundary-v0.md`
  - `openuri-speculative-loading-boundary-v0.md`
  - `openuri-preview-metadata-boundary-v0.md`
  - `openuri-content-extraction-boundary-v0.md`
  - `openuri-session-selection-boundary-v0.md`
  - `openuri-launch-disposition-boundary-v0.md`
  - `openuri-embedded-web-surface-boundary-v0.md`
  - `openuri-auth-session-boundary-v0.md`
  - `openuri-navigation-observation-boundary-v0.md`
  - `openuri-credential-mediation-boundary-v0.md`
  - `openuri-web-permission-boundary-v0.md`
  - `openuri-verified-association-boundary-v0.md`
  - `openuri-install-fallback-boundary-v0.md`
  - `openuri-showitem-exactness-boundary-v0.md`
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / scheme-gated / launch-only / no handler inventory / no requester-visible support oracle / no requester-visible chooser/default control / no portable opener-attribution surface / no foreground/activation-control-or-receipt surface / no target-completion-or-live-state receipt / no recent-items-or-history-control surface / no full-URI-echo-or-receipt surface / no download-staging-docref-minting seam / no content-type-MIME-UTI-classification seam / no URL-safety-phishing-malware-reputation-verdict seam / no link-preview-unfurl metadata seam / no reader/article-extraction seam / no browser-session-profile-selection seam / no launch-disposition-placement-reuse seam / no embedded-web-surface seam / no browser-auth-session seam / no navigation-observation-final-URL-page-state seam / no credential-autofill-passkey seam / no web-permission-powerful-feature-prompt seam / no verified-app-link-associated-domain-trust seam / no browser-store-install-fallback seam / no silent show-item downgrade** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-PACKAGE-VISIBILITY.
- REF-ANDROID-CREATECHOOSER.
- REF-APPLE-CANOPENURL.
- REF-APPLE-LSAPPLICATIONQUERIESSCHEMES.
- REF-XDG-PORTAL-APPCHOOSER.
- REF-ANDROID-ACTIVITY-REFERRER.
- REF-APPLE-OPENURL-SOURCEAPPLICATION.
- REF-WAYLAND-XDG-ACTIVATION.
- REF-APPLE-NSWORKSPACE-ACTIVATES.
- REF-XDG-PORTAL-REQUEST.
- REF-RFC8252-NATIVE-APPS.
- REF-APPLE-OPENURL-COMPLETION.
- REF-WINDOWS-SHELLEXECUTEEX.
- REF-XCALLBACK-URL.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-ANDROID-FILEPROVIDER-SHARE-FILE.
- REF-ANDROID-PERSISTABLE-URI-PERMISSIONS.
- REF-ANDROID-SAF-DOCUMENTS.
- REF-APPLE-SECBOOKMARK.
- REF-APPLE-RECENT-ITEMS.
- REF-WINDOWS-SHADDTORECENTDOCS.
- REF-WINDOWS-FOS-DONTADDTORECENT.
- REF-RFC3986-URI-GENERIC-SYNTAX.
- REF-RFC6819-OAUTH-SECURITY.
- REF-ANDROID-DOWNLOADMANAGER-REQUEST.
- REF-WHATWG-MIME-SNIFFING.
- REF-GOOGLE-SAFE-BROWSING.
- REF-MICROSOFT-DEFENDER-SMARTSCREEN.
- REF-APPLE-SAFARI-FRAUDULENT-WEBSITE-WARNING.
- REF-ANDROID-INTENTS-DATA-AND-TYPE.
- REF-APPLE-NSWORKSPACE-URLSFORAPPLICATIONS-TOOPEN-CONTENTTYPE.
- REF-APPLE-LSCOPYALLROLEHANDLERSFORCONTENTTYPE.
- REF-WHATWG-LINK-TYPE-DNS-PREFETCH.
- REF-WHATWG-LINK-TYPE-PRECONNECT.
- REF-WHATWG-LINK-TYPE-PREFETCH.
- REF-CHROME-CUSTOM-TABS-WARMUP-PREFETCH.
- REF-CHROME-SPECULATION-RULES-PRERENDER.
- REF-APPLE-LINKPRESENTATION.
- REF-SLACK-UNFURLING-LINKS.
- REF-SLACK-ROBOTS.
- REF-OPEN-GRAPH-PROTOCOL.
- REF-MOZILLA-READABILITY.
- REF-CHROMIUM-READER-MODE.
- REF-POSTLIGHT-PARSER.
- REF-APPLE-SAFARI-READER.
- REF-ANDROID-CUSTOM-TABS-OVERVIEW.
- REF-CHROME-CUSTOM-TABS-UI-CUSTOMIZATION.
- REF-CHROME-CUSTOM-TABS-INTERACTIVITY.
- REF-APPLE-SFSAFARIVIEWCONTROLLER.
- REF-ANDROID-BROWSER-EXTRA-HEADERS.
- REF-CHROME-CUSTOM-TABS-REQUEST-HEADERS.
- REF-CHROME-ANDROID-INTENTS.
- REF-GOOGLE-PLAY-LINKING.
- REF-GOOGLE-PLAY-INLINE-INSTALL.
- REF-ANDROID-APP-LINKS.
- REF-ANDROID-VERIFY-APP-LINKS.
- REF-APPLE-UNIVERSAL-LINKS.
- REF-APPLE-ASSOCIATED-DOMAINS.
- REF-ANDROID-INAPP-BROWSING-CUSTOM-TABS.
- REF-CHROME-AUTH-TAB.
- REF-CHROME-CUSTOM-TABS-ENGAGEMENT.
- REF-WEBVIEW2-NAVIGATION-EVENTS.
- REF-WEBKIT-WKNAVIGATIONDELEGATE.
- REF-SP24-TABBED-OUT.
- REF-APPLE-ASWEBAUTHSESSION.
- REF-CHROME-EPHEMERAL-CUSTOM-TABS.
- REF-APPLE-ASWEBAUTH-EPHEMERAL.
- REF-WEBAUTHN-3.
- REF-W3C-PERMISSIONS.
- REF-W3C-GEOLOCATION.
- REF-W3C-MEDIACAPTURE-STREAMS.
- REF-W3C-NOTIFICATIONS.
- REF-ANDROID-CREDENTIAL-MANAGER.
- REF-APPLE-PASSKEYS.
- REF-FDO-FILEMANAGER-SHOWITEMS.
- REF-WINDOWS-SHOPENFOLDERANDSELECTITEMS.
- REF-APPLE-ACTIVATEFILEVIEWERSELECTING.
