# Trajectory map (4 profile stacks + non-negotiables)

This doc records a *mile-high* synthesis of what we are building and the constraints we are choosing.
It is intentionally short: it exists to reduce “local optimum” design drift.

## Non-negotiables (current intent)

1) **One core substrate, four profile stacks** (no forked OSes):
- **Workstation/developer OS** (human-usable daily driver)
- **Cloud substrate / microVM host** (fleet-managed isolation boundary)
- **Embedded / separation-kernel-ish deployments** (small TCB, narrow surface)
- **Agent/automation OS** (LLM-first workflows; auditable actions)

2) **Compatibility is always sealed**: POSIX/legacy environments are treated as **foreign cells** behind an explicit, fail-closed membrane. We may host them for bootstrap and compatibility, but we do not accept their ambient authority model as a system design constraint.

3) **Multicore verification is required**: we do not plan a “single-core-only proof” as our flagship outcome. UP-only prototypes may exist for bring-up, but they are not the verification end state.

4) **Interface-first scalability discipline**: prefer action surfaces whose common-case operations **commute** (D-COMMUTE), so we can scale by sharding/replication and keep global serialization explicit and rare.
   - Composes with Hybrid multicore (D-MK) and keeps the four profile stacks aligned.

5) **LLMs are first-class developers and users** (humans still matter): the stable product surface must be machine-consumable (schemas + validators + receipts), and all high-risk actions must remain deterministic and reviewable.

## What we are (one sentence)

A capability OS whose core product is **explicit, auditable, and enforceable authority** across humans *and* agents, with legacy runtimes hosted only as sealed foreign cells.

## One substrate, four profile stacks

We preserve all four trajectories by keeping the privileged core stable and treating “the rest” as composable stacks.

### Shared substrate (always)
- Capability-mediated resources + IPC + mapping discipline (D-CAP/D-KABI).
- **Portals + receipts** for high-risk authority changes (D-PLUMB/D-VOLITION/D-EXPLAIN), with fresh local-only volition evidence when policy requires a human gesture.
- A closed, schema-pinned **intent envelope** for workflow glue (CH-PLUMBMSG) and capability-safe automation (D-CAPSHELL/D-WALLET).
- Stable typed-id canonicalization for conflict keys and ordering scopes (D-TYPEDID; `docs/30-architecture/typed-id-contract-v0.md`).
- A pinned v0 profile digest function/length for `digest(CH-*)` seams and receipt correlation hooks (D-HASH; `docs/30-architecture/profile-hash-suite-v0.md`).
- Deterministic validator semantics (“propose → validate → authorize → execute → log”) for both humans and LLMs (docs/70-llm-control).
- A sealed-compat membrane for foreign cells (D-FCELL + I-COMPAT-1, I-COMPAT-2, I-FCELL-1).

### Workstation profile
Goal: make least-privilege usable.
- Rich portals (open/share/print/screenshot/input/capture/net) with usage-control framing.
- First-class CLI plumbing so terminal workflows do not reintroduce ambient authority (D-PLUMB).

### Cloud substrate profile
Goal: measurable isolation + operability.
- MicroVM profile (D-MICROVM), fleet-friendly provenance/boot binding (CH-BOOT/CH-PROV), optional CC annex (D-CC).
- Ops surfaces are capability-mediated services, not ambient daemons.

### Embedded / separation profile
Goal: narrow surface + static composition.
- Static CH-INIT/CH-COMP instantiation, small exit surface budget.
- Profile gates to disable dynamic code, broad I/O, rich portals (D-SEAL/D-DYNCODE/D-DRVDOM).

### Agent/automation profile
Goal: action safety at scale.
- Capshell + wallets + drift gates as first-class workflow tooling (D-CAPSHELL/D-WALLET).
- Receipts/transcripts are default outputs; replay/diff is expected (D-RR).

## Profile compatibility contract (design constraints)

These constraints exist to prevent “silent divergence” between profiles:

- **Core primitives must serve ≥2 profiles** or be explicitly profile-scoped.
- **No ambient “escape hatches”**: if humans can do it, agents can propose it, and validators must enforce it.
- **Legacy/POSIX is never policy-authoritative**: it is always a foreign cell.
- **Authority must be legible**: every grant or widening has a diff/receipt path (D-EXPLAIN) and can be gated in CI (authority drift gates).
- **Multicore is not an afterthought**: concurrency choices must be compatible with the verification strategy from day 0.

## Proof-bearing slice (candidate)

We should pursue a small end-to-end slice that exercises the non-negotiables:

- Multicore kernel core (at least an SMP profile) + explicit memory model scope (D-CONC/D-MEMMODEL).
- One portal workflow (e.g., `portal.uri.*` or `portal.net.*`) with receipts (CH-RECEIPT) and authority diffs (CH-CAPDIFF).
- One capshell flow (learn → tighten → drift-gate) that uses a wallet core digest.
- One foreign POSIX cell demonstrating “attempted escape” failing closed.

See: `docs/40-verification/minimum-viable-proof-slice.md` and `docs/30-architecture/multicore-architecture-options.md`.

## Recently resolved (keep short)

Keep stable `OQ-####` ids here after closure; this section is an **OQ-only short window** (max 8 bullets). Each bullet should link the closing boundary/posture doc and name at least one attached surface or evidence hook so future passes can see *why* the question is closed without re-opening it by prose drift.

For non-OQ posture/boundary closure notes and any older overflow once this window fills, use `docs/00-meta/resolved-history.md` rather than expanding this mile-high map.

- **OQ-0002 D-FCELL membrane contract**: v0 membrane is pinned in `docs/30-architecture/foreign-cell-contract.md`, and adapter receipt commutativity/ordering posture is pinned in `docs/30-architecture/fcell-commutativity-contract-v0.md` (D-FCELL, I-COMPAT-1/I-COMPAT-2, I-FCELL-1, D-COMMUTE). Remaining work is evidence/harnessing, not a design decision.
- **OQ-0003 D-RUMPK selection**: v0 internal compat runtime posture is pinned as **rump kernels, filesystem-image handling only** in `docs/30-architecture/rumpk-selection-posture-v0.md`, and **Phase 1 explicitly forbids introducing a second compat runtime family** (LKL/userspace-kernel/libOS/POSIX facades are Phase 2+ via RFC + new negative tests).
- **OQ-0006 profile-default artifact boundary**: A–D profile defaults remain markdown **stable diff surfaces**, not CH-CFG / CH-POLICY templates. Phase 1 declines any standardized template DSL or authoritative generated default bundles; concrete CH-CFG / CH-POLICY outputs remain derived tooling artifacts only (`docs/30-architecture/profile-default-artifact-boundary-v0.md`).
- **OQ-0008 CH-REQCTX sponsorship typing**: CH-REQCTX `budget_desc_digests` / `tcap_desc_digests` stay bare digest lists; Phase 1 declines any in-place upgrade to typed `{schema,digest}` sponsorship entries. If future multi-schema sponsorship becomes necessary, it must live outside CH-REQCTX as its own explicit descriptor/sidecar surface (RFC-first), preserving old transcript meaning and keeping request context non-authoritative (`docs/30-architecture/reqctx-sponsorship-evolution-boundary-v0.md`).
- **OQ-0009 Device leasing automation sub-scope**: generic `portal.device.*` automation is now pinned to **per-device ordering only**. Future attach/grant/revoke ACP work uses `CH-CONFLICTKEY family="device.id"` / explicit typed `device_id`; queue/endpoint/ring/vector details remain internal to the granted lease / driver host rather than becoming a second portal-policy conflict-key vocabulary (`docs/30-architecture/device-lease-ordering-boundary-v0.md`).
- **OQ-0007 capshell result evolution boundary**: the replay-stable `capshell.exec` result remains the CH-AREF digest set returned under CH-EFFCON `contract_id`; Phase 1 declines any in-place upgrade of CH-EXECPACK / CH-ACPOUT into named-output or telemetry schemas. If richer result structure becomes necessary, it must live in one separate digest-referenced sidecar descriptor family, preserving old receipt meaning and keeping replay safety small (`docs/30-architecture/capshell-result-sidecar-boundary-v0.md`).
- **OQ-0005 D-ATTN durable-interrupt boundary**: CH-NOTIF `importance="urgent"` is frozen as an **ephemeral policy-gated hint** only; Phase 1 declines any in-place widening into TTL/renew/revoke or durable interruption authority. If stronger interrupt semantics are ever needed, they must live in a separate RFC-first surface outside CH-NOTIF (`docs/30-architecture/attention-boundary-index.md`; currently `docs/30-architecture/attention-durable-interrupt-boundary-v0.md`; guarded by `tools/check_attention_posture.py` + `tools/check_attention_durable_interrupt_boundary.py`).
- **OQ-0001 Hybrid follow-ups (ADR-0005)**: Phase 1 Hybrid authority/claim posture is now **closed** in `docs/30-architecture/hybrid-phase1-boundary-v0.md`. Default cluster authority is frozen at **NUMA → socket → core_group** (`cluster-auto-boundary-v0.md`), richer cache/perf/locality facts remain **placement hints only** (`cache-topology-authority-boundary-v0.md`, `cpu-capacity-authority-boundary-v0.md`, `memory-locality-authority-boundary-v0.md`), CH-REPLCONTRACT object-family meanings remain registry-closed with per-family boundaries (`quota-replication-boundary-v0.md`, `budget-replication-boundary-v0.md`, `transcript-replication-boundary-v0.md`, `receipt-replication-boundary-v0.md`, `namecert-replication-boundary-v0.md`, `caprpc-proxy-replication-boundary-v0.md`, `view-replication-boundary-v0.md`, `tlog-replication-boundary-v0.md`), and the flagship claim envelope stays **<=64 logical CPUs / <=8 clusters / <=16 logical CPUs per cluster** (`cluster-phase1-envelope-v0.md`). Remaining work is evidence/harnessing or explicit RFC-first expansion, not an unresolved v0 design question.
## Open questions (tracked as decision surfaces)

None currently. If a new open question is introduced, it must get a stable `OQ-####` id and attach to an existing decision/schema/invariant/proof/evidence surface rather than re-opening resolved v0 boundaries by prose drift.
