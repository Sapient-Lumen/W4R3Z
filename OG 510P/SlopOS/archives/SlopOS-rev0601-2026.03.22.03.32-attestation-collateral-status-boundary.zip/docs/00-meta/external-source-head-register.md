# External source head register

Generated from `docs/00-meta/external-source-locks.json` to keep one compact distinction explicit: the reviewer-facing **operational/discovery head** is the bibliography pointer, while the **citation head** is the exact reviewed artifact identity (`lock_url` + `sha256`).

This file intentionally avoids copying raw external URLs into ordinary archive prose. Use the bibliography for human discovery and the lock JSON for exact URL material; this register is only the semantics map between those two roles.

## Snapshot

- lock rows: **6**
- same-url rows: **4**
- split-url rows: **2**
- moving-head rows: **2**
- landing-page-to-artifact rows: **4**
- stable-artifact rows: **0**

## Current rows

| ref_id | title | operational/discovery head | citation head | relation | stability | warning posture |
|---|---|---|---|---|---|---|
| `REF-AMD-SNP-FWABI` | AMD SEV-SNP Firmware ABI Specification | `bibliography_url` | `lock_url` + `sha256:771b330961d8aa95…` | `same-url` | `moving-head` | same URL; digest distinguishes reviewed bytes from mutable head |
| `REF-AMD-GHCB` | AMD SEV-ES / SEV-SNP GHCB Standardization | `bibliography_url` | `lock_url` + `sha256:f4b9038dba38e36b…` | `same-url` | `landing-page-to-artifact` | same URL; digest distinguishes reviewed bytes from mutable head |
| `REF-AMD-VLEK-CERT` | AMD VLEK Certificate Definition | `bibliography_url` | `lock_url` + `sha256:a0f7a523066503b0…` | `same-url` | `landing-page-to-artifact` | same URL; digest distinguishes reviewed bytes from mutable head |
| `REF-AMD-SNP-ATTEST-PDF` | AMD SEV-SNP Attestation note | `bibliography_url` | `lock_url` + `sha256:62b921fd1bf6f05d…` | `same-url` | `moving-head` | same URL; digest distinguishes reviewed bytes from mutable head |
| `REF-RATS-RFC9334` | RFC 9334 text artifact | `bibliography_url` | `lock_url` + `sha256:b80d035fb64a00a6…` | `split-url` | `landing-page-to-artifact` | bibliography head differs from exact artifact |
| `REF-EAT-RFC9711` | RFC 9711 text artifact | `bibliography_url` | `lock_url` + `sha256:20d43b5a03151e50…` | `split-url` | `landing-page-to-artifact` | bibliography head differs from exact artifact |

## Load-bearing notes

- **REF-AMD-SNP-FWABI** — Current confidential-computing boundary work depends on exact SNP report/firmware/interface semantics rather than folklore summaries.
  - Citation-head warning: AMD may publish newer revisions at the same artifact path; review must treat the digest, not the URL alone, as the exact locked byte identity.
- **REF-AMD-GHCB** — Guest-hypervisor boundary reasoning should pin exact GHCB bytes when current D-CC work leans on provider-native field/interface meaning.
  - Citation-head warning: The docs.amd.com content endpoint is a convenience publication surface; keep the exact byte digest explicit because artifact metadata and revision wrappers can change independently of prose references.
- **REF-AMD-VLEK-CERT** — Current endorsement-linkage work should pin exact certificate-field semantics instead of letting endpoint convenience pages stand in for reviewed bytes.
  - Citation-head warning: The AMD docs endpoint is treated as mutable publication plumbing; preserve the digest so endorsement semantics do not inherit silent upstream revisions by URL reuse.
- **REF-AMD-SNP-ATTEST-PDF** — Attestation explainer material is often reused in design discussion; locking the reviewed bytes helps separate exact upstream exposition from remembered summaries.
  - Citation-head warning: This AMD artifact path may be refreshed or replaced over time; treat the digest as the reviewed identity rather than the URL alone.
- **REF-RATS-RFC9334** — RATS architecture language is used as an external vocabulary boundary, so the exact RFC text artifact is the right thing to lock rather than the informational landing page alone.
  - Citation-head warning: The bibliography URL is a discovery page, not the exact locked artifact; review should distinguish the human landing page from the byte-locked RFC text.
- **REF-EAT-RFC9711** — Entity Attestation Token vocabulary is currently load-bearing enough that the archive should pin the exact RFC text bytes instead of relying on a datatracker landing page alone.
  - Citation-head warning: The bibliography URL is a document landing page; the lock uses the RFC Editor text artifact so exact reviewed bytes remain explicit even when portal metadata or rendering changes.
