# External source review queue

Generated from `docs/00-meta/external-source-locks.json` to keep mutable-head lock rows reviewable without copying raw upstream URLs into ordinary archive prose.

Purpose: exact reviewed bytes already stay pinned in the lock register, but entries with mutable publication heads or discovery-vs-artifact splits still need bounded maintainer refresh. This queue keeps that next-review work visible instead of leaving it to memory.

Notes:
- Sorted by `review_by` (earliest first), then by publication-surface risk (`moving-head` before `landing-page-to-artifact` before `stable-artifact`), then by in-repo reference count.
- `refs` counts `REF-*` mentions across `README.md`, markdown docs under `docs/`, and markdown RFCs under `rfcs/`, excluding generated lock-review surfaces and the bibliography.
- `docs` shows up to 3 highest-signal referencing files for the locked ref id.

## Snapshot

- lock rows: **6**
- mutable-head / split-head rows: **6**
- earliest `review_by`: **2026-04-20**

| review_by | ref_id | stability | retrieved_on | refs | docs (top) |
|---|---|---|---|---:|---|
| `2026-04-20` | `REF-AMD-SNP-FWABI` | `moving-head` | `2026-03-20` | 17 | `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/30-architecture/confidential-computing-reference-target-boundary-v0.md`, `docs/30-architecture/confidential-computing-reportdata-binding-boundary-v0.md` |
| `2026-05-20` | `REF-AMD-SNP-ATTEST-PDF` | `moving-head` | `2026-03-20` | 6 | `docs/30-architecture/confidential-computing-snp-chip-id-claim-boundary-v0.md`, `docs/30-architecture/confidential-computing-snp-guest-svn-claim-boundary-v0.md`, `docs/30-architecture/confidential-computing-snp-measurement-claim-boundary-v0.md` |
| `2026-05-20` | `REF-AMD-GHCB` | `landing-page-to-artifact` | `2026-03-20` | 2 | `docs/30-architecture/confidential-computing-snp-certificate-source-boundary-v0.md`, `docs/30-architecture/confidential-computing-snp-vmpl-mode-boundary-v0.md` |
| `2026-05-20` | `REF-AMD-VLEK-CERT` | `landing-page-to-artifact` | `2026-03-20` | 2 | `docs/30-architecture/confidential-computing-snp-certificate-source-boundary-v0.md`, `docs/30-architecture/confidential-computing-snp-signing-metadata-claim-boundary-v0.md` |
| `2026-06-20` | `REF-RATS-RFC9334` | `landing-page-to-artifact` | `2026-03-20` | 27 | `docs/30-architecture/attestation-boundary-index.md`, `docs/30-architecture/attestation-collateral-status-boundary-v0.md`, `docs/30-architecture/attestation-endorsement-boundary-v0.md` |
| `2026-06-20` | `REF-EAT-RFC9711` | `landing-page-to-artifact` | `2026-03-20` | 9 | `docs/30-architecture/attestation-boundary-index.md`, `docs/30-architecture/attestation-freshness-boundary-v0.md`, `docs/30-architecture/attestation-identity-boundary-v0.md` |

## Review posture

- Refreshing a row is a same-revision review action: update the locked digest, `retrieved_on`, `review_by`, and the changelog together.
- This queue does not authorize ambient fetching or automatic bibliography churn; it is only a maintainer reminder surface on top of the explicit lock register.
