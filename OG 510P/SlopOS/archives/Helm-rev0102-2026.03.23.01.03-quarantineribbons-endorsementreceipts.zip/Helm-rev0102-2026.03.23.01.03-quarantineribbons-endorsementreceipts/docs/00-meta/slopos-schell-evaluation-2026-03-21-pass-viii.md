# SlopOS + Schell evaluation — 2026-03-21 — pass VIII

Purpose: keep using SlopOS and Schell as design teachers while Helm decides what deserves a freeze, what deserves a specimen, and what should stay pressure only.

This pass focuses on the next trap after binding-witness posture:
**even a good witness can still lie if it silently widens the activity's scope.**

That pressure now looks strong enough to justify one narrow new Helm freeze:
- **ambient adjacency does not widen activity scope**,
- and one new candidate move:
- **activity scope witnesses**.

DelayBasin matters most here because it names the missing shape directly:
active request,
in-scope object,
ambient roster kept out,
scope state,
and fail-closed repair.

## What SlopOS pressures most strongly now

### 1. Session-selection humility generalizes beyond app launch

SlopOS keeps saying that request admission is not the same thing as choosing arbitrary profile or session state.
That principle matters well beyond OpenURI.
For Helm it means a current browser profile,
account,
remote peer,
or provider lane should not quietly count as part of “the same activity” unless Helm can say that this axis was actually in scope.

### 2. Request-local metadata keeps refusing to become portable identity

SlopOS's preview-metadata, subject-echo, and request-state posture keeps teaching the same lesson:
useful nearby context is still not automatically durable portable truth.

For Helm that means:
- a recent route hint,
- a nearby tab set,
- a remembered account,
- or a last-used provider
can all be helpful,
but they should not silently promote themselves into same-activity proof.

### 3. Exact reveal still refuses nearby substitutes

SlopOS remains stubborn about exact reveal.
If the exact item cannot be shown honestly,
it should fail closed rather than silently opening something nearby.

Helm should steal the same instinct for activity continuity.
A nearby workspace,
sibling window,
similar project,
or likely profile can be a strong hint without silently counting as the same activity scope.

### 4. The SlopOS datacube rewards scope law, not just better matching

By this point the deeper datacube lesson is clear:
Helm does not only need better saved-to-live matching.
It also needs to say **what dimensions were allowed to count**.

Binding witnesses explain the join.
This pass says Helm also needs a small law for the activity scope behind that join.

## What Schell adds to the picture

### 1. Launch kits and cockpits now need included-versus-excluded context

Schell already keeps live sessions,
restored sessions,
launch kits,
quick summon,
and cockpit surfaces visibly distinct.

The next refinement is that these surfaces will increasingly need to say:
- which scope axes were part of the proposed continuity story,
- and which nearby hints stayed outside it.

### 2. Preflight honesty suggests scope honesty

Schell's completion-card and preflight work teaches a reusable rule:
strong help is fine,
so long as candidate state does not impersonate execution truth.

Helm can reuse that here.
A scope witness can be to activity continuity what a preflight card is to command entry:
compact,
useful,
and explicit about what counted versus what stayed nearby.

### 3. Origin badges pressure Helm toward small visible basis cues

Schell's origin-badge direction suggests that tiny visible source cues can do a lot of honesty work.
That points away from a giant scope dashboard and toward a small witness strip or chip row that can open into detail only when needed.

## What DelayBasin usefully pressures here

DelayBasin's scope-witness / active-request / ambient-roster work is almost a direct import lesson for Helm.
It suggests four healthy moves:
- say what exact activity or activity subject is in play,
- say which axes counted,
- say which nearby ambient surfaces did not count,
- and fail closed to hold / inspect / repair when adjacency is doing too much work.

That is unusually good design pressure for Helm right now.

## What now looks worth doing in Helm

### Worth freezing now

- **ambient adjacency does not widen activity scope**

Why now:
- Helm now has enough saved/planned continuity luxuries that hidden scope widening would spread quickly,
- SlopOS keeps refusing silent widening across multiple seams,
- Schell has enough launch-kit/cockpit pressure that scope cannot stay an unnamed implementation detail,
- and the freeze can stay small: it still does not require a final scope ontology.

### Worth adding as candidate pressure now

- **activity scope witnesses**

Why this now looks strong:
- binding witnesses explain whether a join happened,
- but activity scope witnesses can explain which axes made that join count,
- and the first useful version can stay tiny enough to ride on entry kits, cockpit cards, binding witnesses, capsule diffs, and Recall cues.

A first activity scope witness should likely name:
- the activity subject,
- the in-scope axes,
- the nearby ambient exclusions,
- the current scope state,
- and the honest action ladder that remains.

## What Helm should explicitly not take

- a giant final activity identity algebra before one compact witness exists
- hidden profile/account/browser/remote inheritance by “best nearby” convenience
- a belief that better binding cards excuse weaker scope law
- a project-management worldview that turns activity scope into bureaucratic metadata

## Current bounded take

A useful new Helm rule is:

**when Helm suggests or claims continuity for an activity, nearby ambient context should not silently widen what counts as that activity.**

And a useful new candidate move is:

**activity scope witnesses as small shell-owned scope strips or cards that say which axes counted, which nearby context stayed out, and whether the current continuity claim remained exact-scoped, widened, operator-switched, or unknown.**
