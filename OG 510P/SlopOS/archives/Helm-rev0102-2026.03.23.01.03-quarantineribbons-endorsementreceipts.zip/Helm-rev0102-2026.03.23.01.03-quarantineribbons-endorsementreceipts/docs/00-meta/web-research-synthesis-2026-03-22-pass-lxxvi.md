# Web research synthesis — 2026-03-22 — pass LXXVI

This pass focused on one question:

**what should Helm steal from current products once it already has exact cohorts and least-reach ladders,
but still needs one honest answer to “what would this stronger move actually touch?”**

## Strongest outside pressure

### 1. Good systems preview reach before apply
Datadog downtimes let operators preview affected monitors before muting,
and the docs explicitly note that later-created or edited monitors are also included if they match the scope.
That is exactly the kind of honesty Helm needs:
preview the current set,
then name the dynamic rule that can widen the live result later.

Terraform teaches the same law from infrastructure instead of alerting.
`terraform plan` creates an execution plan,
previews proposed change actions,
and does not carry out the changes by itself.
The plan can also be saved for later automation or team review.

### 2. Good systems carry impacted-resource witness
Datadog change events support an explicit list of impacted resources.
This is a small but powerful move:
changes should be able to carry a compact “who was touched” witness instead of relying on prose or memory.

Helm should steal that idea for warrants,
receipts,
reversal ladders,
reveal moves,
and quiet windows.

### 3. Good systems review downstream adoption at instance level
Figma's library-update flow lets people review updates before applying them,
compare side-by-side or overlay,
and move through multiple instances before updating one or all.
That pressure says Helm should keep previews concrete whenever it can:
per-instance,
per-target,
or counted-with-drilldown.

### 4. Good systems keep scope descriptions human-visible
Google's OAuth consent screen includes a summary of the project,
policies,
and requested scopes,
and Google advises using the most narrowly focused scope possible.
Slack's optional-scope approval model is similar:
admins define a superset of optional scopes users may later choose from.

This says Helm should keep scope / reach language legible to humans,
not just encode it inside machine policy.

### 5. Good systems offer smaller alternatives to ambient whole-world reach
Chrome's `activeTab` permission is a direct teacher here.
It grants temporary access to the current tab after a user gesture,
as an alternative to full persistent `"<all_urls>"` style reach.
Android's Selected Photos Access likewise lets users grant access to specific photos and videos rather than all media,
and Android warns that URI access in this mode is temporary.

This reinforces Helm's current direction:
start with exact cohorts,
then show exact reach preview before any broader or stronger act.

## Synthesis for Helm

The shell move that now looks worth warming is:

- **reach previews** — operator-facing pre-act previews that show what a stronger act would currently touch,
  include,
  reveal,
  mute,
  or rerun
- **affected-set witnesses** — compact exact-or-counted witnesses that can attach to warrants,
  windows,
  receipts,
  and repair surfaces

## Best first homes

- action warrants and drift gates
- reveal windows and audience moves
- attention windows and quiet scopes
- Exchange export / publish / attach / handoff
- Operations Center mute / rerun / repair / apply
- Omnibox quick actions that jump from inspect to strong act
- Recall reopen / rerun / reverse / quote / handoff

## Anti-goals

- no giant plan engine
- no full policy simulator
- no promise that every preview is perfectly exact
- no flattening of predicted reach and observed aftermath into one badge
- no silent widening from current set to future-matching rule members
