# Web research synthesis — 2026-03-22 — pass LXXXVIII

Purpose: continue the outside scan and pressure Helm with durable patterns rather than novelty theater.

## Main idea

The next shell law worth stealing is not just **how review begins**.
It is **how active borrowed power stays visible while it is actually in use**.

The strongest outside systems keep powerful use visibly **on air**,
show where the use is coming from,
and keep a nearby stop or narrow control.
Helm should steal that.

## 1. Media-capture standards already distinguish granted access from "on air" use

The W3C Media Capture and Streams spec says two things should be readily apparent once permission exists:
- that the page has access to the devices for which permission is given
- whether any of those devices are presently recording through an **"on air" indicator**

It also says granted permissions should be easy to find and revoke.
That is a strong teacher for Helm:
**a live-use indicator is not the same thing as the original grant surface.**

The Screen Capture spec sharpens the same point.
For display capture,
only the **live** indicators are significant,
and user agents are advised to show a prominent indicator while content is being captured and give the user a means to stop active capture.

## 2. Android shows the value of tiny live beacons plus coarse emergency brakes

Android 12 makes microphone and camera access visible with status-bar indicators.
It also gives users device-wide microphone and camera toggles,
and Android explicitly says turning those toggles off changes app behavior immediately:
apps get a blank camera feed or silent audio.

That is a strong product lesson even though the brake is coarse.
Helm should prefer exact brakes when it can,
but it should still support a truthful coarse emergency brake when exact per-subject control is not available.

## 3. Apple keeps live-use truth compact and nearby

Apple's privacy indicators on Mac and iPhone are a good model for compact honesty.
On the Mac,
Control Center shows dots or arrows when microphone,
camera,
system audio,
or location are in use,
and can show which apps are using them.
On iPhone,
apps must ask for permission first,
users can review or change access in Privacy & Security,
and Control Center can tell the user when an app has recently used camera or microphone.

That is a useful split for Helm:
- current **on-air now** truth
- nearby review/change-access route
- and separate **recently used** historical truth

## 4. Windows is a reminder that live visibility and exact control sometimes arrive at different granularities

Windows says desktop apps cannot always be individually toggled,
yet it still exposes live-use honesty through camera notifications,
a microphone taskbar icon,
and system-tray privacy indicators for location,
microphone,
and camera.

That matters because Helm should not bluff exact kill power where the substrate only offers coarse control.
It should still say something useful:
- what family is hot now
- what exactness grade the shell has for that signal
- and whether the available brake is exact,
  narrow,
  or coarse

## 5. Chrome's shared-tab controls show the value of exact active-cohort brakes

Chrome's Gemini-in-Chrome help is a good modern example of exact active-sharing control.
It lets the user remove one shared tab,
pause sharing the current tab,
or stop sharing all tabs,
and it keeps visual feedback when a tab is shared.

That is exactly the kind of interaction Helm should steal for Exchange,
Overview,
and any shell-owned live reveal or borrowed-context lane:
**a live beacon should have an adjacent brake that can stop this exact shared thing,
not just open a giant settings page.**

## 6. What Helm should steal

### Steal now
- **active-borrow beacons** that say what exact borrowed power is currently hot / on air
- **brake rails** next to those beacons for stop,
pause,
mute,
narrow,
or escalate-to-full-manage moves
- a clear split between **issued lease**,
**borrowed now**,
and **actively consuming now**
- an explicit **control exactness grade** when the substrate only offers coarse stop control
- a compact **recently-used** relation that stays weaker than current on-air truth

### Refuse for now
- no giant privacy center before one tiny beacon works
- no stale history impersonating a live kill switch
- no provider-owned indicator becoming shell truth by default
- no fake exact stop control when the shell only has family-wide brakes

## 7. Best first proofs for Helm

- one trusted shell strip or menu-bar chip that says a camera,
microphone,
screen share,
automation lane,
or background-presence grant is **hot now**
- one exact brake route where available,
with an honest coarse brake when exact control is impossible
- one Operations Center row that keeps **issued lease**,
**borrowed now**,
and **on-air now** visibly different
- one Exchange or Browser share path that can stop this exact tab,
this exact reveal,
or this exact borrowed cohort without collapsing into a giant settings surface

## Judgment

The next strong import is not a bigger permission model.
It is a smaller live-use law:

**if borrowed power is actively hot now,
Helm should show a compact shell-owned beacon for it and keep a nearby truthful brake rail.**
