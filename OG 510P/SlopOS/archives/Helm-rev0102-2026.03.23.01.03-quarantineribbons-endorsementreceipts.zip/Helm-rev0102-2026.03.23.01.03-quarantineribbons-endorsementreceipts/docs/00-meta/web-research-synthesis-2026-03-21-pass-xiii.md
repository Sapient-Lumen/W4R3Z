# Web research synthesis — 2026-03-21 — pass XIII

Purpose: keep harvesting brilliant ideas for Helm while staying disciplined about what counts as a pillar, a cross-pillar move, or a local acceleration.

This pass focuses on three questions:

1. which small UX moves make elite desktop tools feel magical,
2. which ones stay honest enough to import into Helm,
3. and which pillar each move should pressure instead of replace.

## Cluster 1 — tiny preflight surfaces beat giant review screens

### What current tools teach

PowerToys' current Command Palette is now a fast root-search surface with an extension model.
Warp keeps turning saved workflows and launch configurations into command-palette-reachable launch ladders.
Raycast keeps proving that quicklinks and note-specific quicklinks can make saved intent feel instant instead of bureaucratic.

The best lesson is not “build a bigger launcher.”
The lesson is:

**small, reusable, immediately-legible preflight surfaces are often more valuable than giant modal review screens.**

### What Helm should steal

- tiny **review strips** that can appear in Omnibox,
  Object Browser,
  Exchange,
  Recall,
  Operations Center,
  and terminal/capshell
- action ladders that keep:
  subject,
  route,
  basis,
  and readiness visible
- saved launch intent as compact shell objects,
  not just command strings

### What Helm should refuse

- giant launch/review UIs as the only way to stay safe
- saving raw command lines as if they were already shared desktop truth
- “launch config = live session” folklore

## Cluster 2 — recency becomes much better when source and authority stay visible

### What current tools teach

Alfred's clipboard history and snippets show why searchable recency is beloved.
VS Code's terminal shell integration and sticky scroll show the value of command boundaries and visible command anchors.
Warp now explicitly separates terminal blocks from agent-conversation blocks,
which is a useful reminder that not all recent activity has the same authorship or recall authority.

The shared lesson is:

**history gets dramatically more useful when entries preserve source and authority grades.**

### What Helm should steal

- **exact-object recency** rather than only app/file/path recency
- source labels such as:
  live,
  restored,
  historical,
  request-only,
  delegated,
  imported
- sticky context strips that say which action/output region a long-lived result belongs to
- recent reviewed actions and recent route receipts as Recall material

### What Helm should refuse

- one undifferentiated “history” bucket
- terminal-local history pretending to be global desktop truth
- agent/delegated history silently wearing the operator's badge

## Cluster 3 — live derivative surfaces can be amazing when provenance stays obvious

### What current tools teach

PowerToys Crop And Lock proves that cropped or thumbnail live views can be genuinely useful.
GNOME's Activities overview proves the value of live thumbnails and direct manipulation.
Raycast's recent Windows changelog and floating-window ecosystem show that quick preview and quick floating utility surfaces remain desirable.

The lesson is:

**derived live views are powerful,
but only when the user can still tell what they derive from and how live they really are.**

### What Helm should steal

- live lenses with explicit provenance
- searchable overview with live thumbnails
- tiny floating utility surfaces when they remain shell-owned and source-labeled
- thumbnail or crop modes that can stay inspectable rather than magical

### What Helm should refuse

- hidden capture backdoors
- derived surfaces pretending to be independent sources
- floating utility chaos without source witness or lifecycle truth

## Cluster 4 — reusable automation wins on status, packaging, and inspectability

### What current tools teach

Node-RED keeps teaching that subflows,
link nodes,
config nodes,
and status-bearing nodes reduce spaghetti only when the editor supports them explicitly.
PowerToys' Command Palette extension toolkit exposes list pages,
status messages,
progress state,
and settings surfaces,
which is a useful reminder that reusable extension pieces benefit from visible host-owned status.
Warp workflows likewise show that named reusable command objects are easier to keep than repeated freeform commands.

The lesson is:

**reusable fragments matter most when instances carry status and can still be opened up.**

### What Helm should steal

- reusable **Flow fragments** with typed inputs/outputs
- status-bearing fragment instances
- compact progress / hold / failure surfaces on reusable graph pieces
- fragment palettes that make reuse cheap but not opaque

### What Helm should refuse

- opaque prefab black boxes
- reusable fragments that hide raw automation or hidden ambient hooks
- “canvas now, support machinery later”

## Cluster 5 — launcher menus and launch kits are useful, but they are not continuity truth

### What current tools teach

WezTerm's launcher menu and domains are a good example of rich local launch affordances.
Warp's launch configurations show the same thing from a more workflow-oriented angle.
These are clearly useful,
but they are still launch structures rather than proof of current live continuity.

### What Helm should steal

- launch ladders
- entry objects that can name likely environment or domain choices
- fast summon surfaces for known good starting points

### What Helm should refuse

- treating launch kits as continuity proof
- hiding the difference between:
  fresh launch,
  attach,
  reuse,
  repaired return,
  and historical replay
- letting terminal-local launcher structure dictate the whole desktop model

## Brilliant ideas worth carrying forward right now

These currently look especially worth keeping warm:

- **review strips** for tiny preflight truth
- **exact-object recency** with source labels and stronger recent-action / recent-receipt cues
- **sticky context strips** for long-lived output or complex activity surfaces
- **searchable overview with live thumbnails**
- **live lenses with provenance**
- **reusable flow fragments** with visible status
- **launch ladders / entry objects** that stay honest about fresh-vs-restored-vs-historical posture

## Pass-XIII bounded take

The strongest outside ideas in this pass do **not** argue for more pillars.
They argue for better cross-pillar shell moves:

- flesh out the pillars with stronger exactness and source-grading rules,
- add explicit candidate pressure for **review strips**,
  **exact-object recency**,
  and **reusable flow fragments**,
- keep **launch ladders** and **live lenses** warm as shell luxuries,
- and continue refusing ambient command-string culture,
  fake continuity,
  hidden authorship,
  and extension sprawl
