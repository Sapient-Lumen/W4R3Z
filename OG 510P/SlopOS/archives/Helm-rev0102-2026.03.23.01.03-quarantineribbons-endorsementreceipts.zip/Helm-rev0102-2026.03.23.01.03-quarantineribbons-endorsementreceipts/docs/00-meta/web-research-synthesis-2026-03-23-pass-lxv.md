# Web research synthesis — 2026-03-23 — pass LXV

Question: after handoff packets and receiver-fit cards, what small durable cross-cutting move still looks missing for Helm's datacube?

Answer from this pass: **basis witness**.
The strongest next compact move is now **basis stamps**.

## What current tools keep teaching

### 1. Strong compare and restore flows keep an explicit revision identity nearby

GitHub still centers commit SHA as the compact exact identifier for a commit,
and GitHub compare surfaces let operators compare branches,
tags,
commits,
forks,
and dates.
Grafana dashboard version history likewise keeps explicit versions,
lets operators compare two versions,
inspect a JSON diff,
and restore a previous version without destroying history.
Figma version history also keeps checkpoints,
lets operators name versions,
share a specific version link,
duplicate a specific version for handoff,
and restore earlier versions non-destructively.

The pattern is not merely “have history.”
It is:
**carry a compact exact basis witness whenever stronger claims depend on a particular reviewed state.**

### 2. Good systems separate exact machine basis from friendlier human labels

Figma named versions show the useful split directly:
there is a timeline/checkpoint substrate,
and humans may add names and descriptions.
Google Docs named versions makes the same move:
a document can have a friendly named version so a team can track milestones,
while still preserving the underlying version history.

Helm should steal that exact split.
A basis witness should be compact and exact,
while any milestone label or human summary remains descriptive rather than authoritative.

### 3. Some basis witnesses are intentionally short-lived

Notion's view-query flow is especially instructive.
A query against a saved view returns a `query_id` and an `expires_at`,
and the cached results expire after 15 minutes.
That is a strong reminder that not every basis witness should overclaim permanence.
Some basis witnesses are valid only for a bounded freshness window,
and the system should say so plainly.

### 4. Stronger acts often require an expected basis instead of “latest” folklore

GitHub's pull-request update endpoint accepts an `expected_head_sha`.
If that SHA no longer matches the pull request head,
the request fails instead of silently rebinding the old intent onto a newer head.
HTTP conditional requests make the same point at a more general protocol layer:
`If-Match` / `If-Unmodified-Since` give an optimistic-locking posture where the act should fail if the resource changed,
so the user can restart on a newer version or review a diff.

That is exactly the missing cross-cutting law for Helm's stronger moves:
**when a claim,
comparison,
handoff,
or action depends on one exact reviewed basis,
the shell should be able to name that basis compactly and reject silent drift.**

### 5. Basis witnesses reduce fake continuity during travel

Handoff packets and receiver-fit cards already tell Helm how to travel and land honestly.
What they still need is a reusable atom for:

- what exact source or revision this packet reflects,
- what exact reviewed basis a response kit or brief was drafted from,
- what exact checkpoint a patrol route or watchpoint digest is comparing against,
- and whether that basis is current,
unknown,
stale,
or unverifiable on the receiver.

That reusable atom now looks like a **basis stamp**.

## What Helm should steal

- compact exact revision witnesses next to stronger compare/share/handoff acts
- optional human labels layered on top of exact machine basis
- expiry/freshness posture when the basis witness is short-lived or receiver-unverifiable
- stronger actions that require an expected basis instead of silently following moving heads
- compare/diff/review surfaces that open directly from basis mismatch or stale-basis cases

## What Helm should not steal

- latest-wins folklore
- basisless “same as before” language
- silent rebasing of imported or saved shell luxuries onto a newer local head
- descriptive labels that pretend to be exact revision identity
- giant version-control ambition just to get one honest basis witness

## Why this matters to the pillars

This is not a new pillar.
It is a cross-cutting support move that helps almost every existing one:

- **Object Browser** can show what exact saved view,
  deck,
  or derived card a thing reflects
- **Operations Center** can keep glances,
  watch outputs,
  and effect aftermath honest about their reviewed basis
- **Recall** can say what exact checkpoint,
  version,
  or packet basis a reopened thing came from
- **Exchange** can let travel carry basis truth without pretending that carried basis is current-live truth on the receiver
- **Desktop Flow / Omnibox** can put stronger actions behind expected-basis guards instead of ambient latest-following

## Judgment

The next small durable proof worth warming is **basis stamps**.
Helm does not need a giant version-control subsystem.
It needs one compact,
reusable,
copyable way to say:

**this is the exact basis I am talking about,
and here is how strongly that basis still binds.**
