# SlopOS / Schell evaluation — 2026-03-22 pass XXVII

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on a narrower travel truth question:

**what exact reusable witness should travel for basis truth,
and what exact reusable witness should say what local residue stayed behind?**

## 1) SlopOS still teaches explicit view objects and explicit compare surfaces,
not ambient equivalence

The more I re-read SlopOS,
the more consistent the message becomes:
views are explicit objects,
mutations happen through explicit seams,
and receipts/descriptors are preferred over flattering ambient claims.
RFC-0032 still matters because view mutation is explicit,
auditable,
and capability-authorized,
not an invisible global convenience.
That keeps pushing Helm away from giant continuity folklore and toward smaller shell-owned witnesses.

A **basis stamp** fits that posture well.
It is not a giant manifest and not a second truth domain.
It is a small explicit answer to:
"what exact basis is this surface talking about?"

## 2) SlopOS's portal and safe-open boundaries keep teaching that omitted residue is real truth,
not an implementation footnote

RFC-0046 and the OpenURI boundary family keep refusing to let launch quietly become materialization,
recent-items enrollment,
permission reuse,
URI echo,
or durable local-object identity.
RFC-0053 does the same around safe-open:
preview input is a request-local stable object,
residue stays disposable by default,
and export/clear are separate workflows.

That is exactly the kind of teacher pressure Helm needs for a **residue ledger**.
When something travels,
Helm should be allowed — and sometimes required — to say that some residue did not travel:

- trust posture
- recent/history residue
- device-local caches
- session/profile/account choice
- browser/session state
- credentials
- local placements
- or other mutable local leftovers

Those are not bugs in portability.
They are part of truthful portability.

## 3) SlopOS consent-receipt thinking still supports tiny witness objects instead of giant constitutions

The authority-diff / consent-receipt lineage in SlopOS is another useful reminder.
When a system needs trust,
consent,
or explanatory power,
it does not always need a giant new product layer.
Sometimes it needs one compact witness that binds the important reality.

That is the right scale for both new warm moves here:

- a **basis stamp** binds which basis was actually meant
- a **residue ledger** binds what did not travel and therefore must not be misread as carried truth

Both of those feel SlopOS-shaped in the right way:
small,
explicit,
and anti-smuggling.

## 4) Schell pressure still helps at the shell seam,
but does not rewrite the product map

The older shell inspirations still keep paying rent in the same places:
exact handles,
review/apply posture,
receipts,
source grading,
and shell-local acceleration.
But they still do not argue for more pillars.
They argue for sharper cross-pillar shell-owned witness objects.

Basis stamps and residue ledgers fit that role cleanly.

## 5) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- projection surfaces stay bounded and non-authoritative
- landing manifests,
  companion resource bundles,
  receiver fit cards,
  and rebind ladders still look right
- add **basis stamps** as the smallest reusable carried-basis witness
- add **residue ledgers** as the smallest reusable omitted-local witness

## 6) What still does not seem worth taking

- not a giant universal datacube UI
- not a universal sync constitution
- not ambient equivalence between carried structure and local live state
- not hiding omitted residue because it looks less magical
- not new pillars

## 7) Current judgment

The most important lesson from this pass is:

**a truthful shell should say both what exact basis a surface reflects and what exact residue stayed behind.**

That feels strong enough for new candidate contracts,
and still not strong enough for a new pillar or a giant freeze.
