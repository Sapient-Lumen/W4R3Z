# Web research synthesis — 2026-03-21 — pass XII

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on a sharper question than earlier passes:

**which outside ideas should Helm steal as powers,
and which ones should stay carefully bounded so the shell does not become a museum of productivity folklore?**

The outside tools keep converging on the same answer:
- great systems turn tiny luxuries into fast,
  reusable,
  visible powers,
- but the best ones either keep those powers near shared truth,
  or clearly admit when they are only local acceleration.

That makes this pass much more about **peeling ideas apart** than about product imitation.

## Cluster 1 — Preview should be shell-wide, fast, and action-adjacent

### What current tools teach

Apple's Quick Look provides full-size preview of many file types without opening the file,
and Finder's Preview pane and Quick Actions let the user inspect metadata and perform bounded actions directly from the browse surface.
Microsoft now pushes similar ideas through PowerToys Peek,
File Explorer add-ons,
and previewable file surfaces.

The common lesson is not “copy Finder” or “copy Peek.”
The lesson is:
- preview belongs close to browsing,
  search,
  and action,
- and preview becomes more valuable when it can stay lightweight while still exposing the next honest ladder.

### What Helm should steal

- a **shell-wide Preview surface** instead of app-local preview islands
- a **preview metadata strip** with provider/source witness
- **preview-adjacent quick actions** that stay bounded (`inspect`, `open`, `reveal`, `safe-open`, `attach`, `route`, `hold`)
- folder/object summary preview, not just file-body preview

### What Helm should refuse

- silent open/import/run from preview
- plugin clutter that only the host app understands
- local preview caches pretending to be current object truth

## Cluster 2 — Overview works when it is spatial, live, and searchable

### What current tools teach

GNOME's Activities overview combines live window thumbnails,
workspace switching,
a dash,
and type-to-search in one fast transitional surface.
KDE Activities shows the appeal of activity-specific desktop containments,
but it also demonstrates how quickly the idea can drift toward a parallel worldview if it is not carefully bounded.

The best lesson is:
**Overview should be the spatial companion to summon/search,
not a separate mode with its own logic.**

### What Helm should steal

- **live thumbnails** of shell-owned surfaces
- **type-to-search from overview**
- **quick workspace and window moves** from the same surface
- obvious continuity cues while staying keyboard-friendly

### What Helm should refuse

- overview as mouse-only theater
- a second object model separate from Omnibox / Operations Center / Recall
- giant activity-container bureaucracy just because activities exist

## Cluster 3 — modern command palettes win by becoming typed root search

### What current tools teach

PowerToys now treats Command Palette as a quick launcher for apps,
commands,
and development tools,
and it exposes an extension model.
Raycast frames itself as an extendable launcher with Quicklinks,
Notes,
Snippets,
and window management.
Alfred's newer workflow editor adds a Palette,
Prefabs,
and growing script-free Automation Tasks.
KRunner keeps blurring run dialog,
calculator,
launcher,
and document access.

The shared lesson is not “make a bigger launcher.”
The lesson is:
**root search becomes central when it can dispatch across many typed subject families while keeping the host in charge of the rules.**

### What Helm should steal

- **typed providers** instead of flat plugin strings
- **quicklinks / typed seeds / placeholders** that can start from selected text,
  clipboard,
  or known objects
- **prefabbed entry objects** and reusable patterns for Flow or Omnibox providers
- provider-visible identity and action families

### What Helm should refuse

- opaque plugin folklore where the shell cannot explain what just happened
- placeholder systems that silently scrape ambient context to stay magical
- root search becoming a second automation substrate with weaker law than the shell itself

## Cluster 4 — terminal luxuries should stay local accelerators unless they earn broader truth

### What current tools teach

VS Code's shell integration makes command boundaries visible,
enables sticky scroll,
quick fixes,
and source-labeled “run recent command” recall.
WezTerm shows how much local luxury a terminal can grow — panes,
command palette,
launch menu,
and introspectable pane objects — without pretending every terminal-local object is universal system truth.
fish remains a great example of cheap delight through autosuggestions and completions that do not execute until accepted.

The strongest shared lesson is:
**luxury belongs in named local lanes first,
not in hidden ambient authority.**

### What Helm should steal

- **command-boundary witnesses** in terminal/capshell
- **sticky command headers** for long output regions
- **source-labeled recent-command recall** that distinguishes live,
  previous-session,
  and imported history
- **cheap-delight acceptance rules** like autosuggestions that stay inert until accepted
- **pane-local affordances** that do not silently become global authority

### What Helm should refuse

- quick-fix rails that silently perform strong actions
- pane/mux structure becoming a hidden new authority plane
- prompt-time or idle-time helpers becoming correctness dependencies

## Cluster 5 — flow systems win on reuse, status, and support machinery

### What current tools teach

Node-RED's subflows,
status outputs,
and link nodes show how reusable graph fragments and state-bearing nodes reduce spaghetti when the editor supports them explicitly.
Alfred's Prefabs and Automation Tasks show how reusable building blocks and script-free tasks can widen automation without demanding code first.
Blueprints keeps teaching the same old lesson:
a node editor is only as good as its packaging,
status,
search,
and inspectability.

### What Helm should steal

- **reusable fragments / prefab flow packs**
- **status-bearing nodes** and compact debug rails
- **link-like graph jumps** that stay inspectable rather than mystical
- a palette that makes fragment reuse cheap

### What Helm should refuse

- “canvas now,
  tooling later”
- reusable fragments that become opaque black boxes
- graph sprawl without status,
  search,
  or inspect paths

## Cluster 6 — older niche systems still teach useful moves

### What older tools teach

acme still offers one striking lesson:
text can be an action surface without becoming ambient mush,
provided that visible targets,
selection,
and the available ladders stay explicit enough.
That still matters for Helm because terminal/capshell,
object cards,
and exact reveal/open ladders will keep meeting text and selection surfaces.

### What Helm should steal

- visible text or selection as a **candidate action subject**
- action ladders that stay explicit rather than magical
- local composability between visible artifacts and outside helpers

### What Helm should refuse

- ambient click-to-do-whatever smartness
- text selection automatically inheriting broader authority than it visibly carries

## Brilliant ideas worth carrying forward right now

These look especially worth keeping warm:

- **preview strips with inline quick actions**
- **live lenses / cropped derivative surfaces with provenance badges**
- **typed quicklinks / placeholders / snippet seeds**
- **command-boundary witnesses plus sticky command headers**
- **source-labeled run-recent surfaces**
- **searchable overview with live thumbnails**
- **prefab/subflow flow fragments with visible status outputs**
- **cheap-delight timing lanes** where warm state accelerates but does not define truth

## Pass-XII bounded take

The current outside idea harvest most strongly supports this Helm posture:

- keep **Preview**,
  **Overview**,
  **Capsules**,
  **quicklinks/seeds**,
  **command-boundary witnesses**,
  and **flow prefabs/subflows** as strategic pressure,
- normalize Helm around **seven pillars plus one native terminal/capshell front-end family**,
- and prove the architecture first through **exact object → reviewed action → route → receipt → recall** rather than through a giant dashboard,
  launcher,
  or session-restore spectacle.
