# Web research synthesis — 2026-03-21 — pass VIII

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on one sharper question:
**what do current tools teach about the scope of a saved or resumed task?**

The answer is becoming clearer:
current tools keep turning scope axes into explicit surfaces — profiles, session types, private browser contexts, page sharing, layout bundles, reusable accelerators —
but they rarely give one elegant shell-owned way to say which of those axes actually counted for same-task continuity.

That points Helm toward two outcomes:
- freeze **activity-scope truth** narrowly,
- and add **activity scope witnesses** as a candidate move.

## Cluster 1 — modern tools increasingly make scope explicit instead of purely ambient

### What current systems teach

PowerToys Workspaces is revealing here.
It lets users capture desktop state,
add per-app CLI arguments,
and explicitly shape launch behavior.
Its docs even use examples like launching Terminal to a named profile or launching browsers with specific URLs.
At the same time,
existing-window reuse is app-dependent,
and some apps are single-instance only.
That means saved workspaces already rely on explicit scope axes,
but still do not fully explain which axes counted as same-task truth.

VS Code is pushing the same direction in a different domain.
Profiles are named bundles of customizations that you can quickly switch between or share.
Agent sessions are explicit about local,
background,
cloud,
and third-party modes.
The integrated browser tools default to private in-memory sessions,
and pages must be explicitly shared to grant an agent temporary access to saved data.

### What Helm should steal

Helm should keep stealing:
- explicit scope axes instead of ambient assumption,
- visible private-versus-shared posture,
- and small operator-controlled switches for which context can travel with a saved task-entry object.

### What Helm should refuse

- profile/session/account/remote context that silently rides along because it was last used
- saved task-entry surfaces that hide which axes were explicit and which were ambient
- a flat “same activity” badge when the real story involved a scope switch

## Cluster 2 — layout and overview tools remain useful because they stay smaller than full task identity

### What current systems teach

FancyZones stays a very good custom layout engine.
GNOME's Activities overview remains powerful because windows,
search,
and workspace moves stay unified in one shell space.
Obsidian Workspaces also shows the appetite clearly:
users want named layouts and quick switching,
and the saved object mainly captures open files,
tabs,
and sidebar state.

These tools are strongest when they do not pretend geometry or panel state is the whole task.

### What Helm should steal

Helm should keep stealing:
- overview-style unification,
- custom spatial layouts,
- named saved setups,
- and fast switching.

But it should make the activity scope behind those moves explicit when promises become stronger than “show me my layout again.”

### What Helm should refuse

- geometry as a substitute for activity identity
- overview or layout surfaces that quietly inherit provider/profile/account truth
- saved layout objects that silently count as whole-task continuity

## Cluster 3 — tiny accelerators are increasingly dynamic, which makes scope law more important

### What current systems teach

Raycast Quicklinks,
Snippets,
and Dynamic Placeholders keep demonstrating the appetite for tiny reusable accelerators.
They can pull in clipboard text,
other snippets,
arguments,
dates,
and more.
That is powerful precisely because the expansion context is dynamic.

### What Helm should steal

Helm should keep the typed-seed direction alive.
Tiny accelerators are clearly worth having.
But the better lesson is that once placeholders and reusable entry objects get more dynamic,
the shell needs a cleaner story for what context is in scope versus merely nearby.

### What Helm should refuse

- ambient placeholder expansion as same-task proof
- hidden widening of what the shell knows or can act on
- quick accelerators that outrun scope truth

## Cluster 4 — cheap debug panes still do a lot of honesty work

### What current systems teach

Node-RED's sidebar model still shows how much honesty you can buy with nearby filtered evidence panes.
VS Code's Timeline,
Agent Debug panel,
and chart/log views push the same point:
small revealable support surfaces make richer behavior much safer to trust.

### What Helm should steal

Activity scope witnesses will likely be strongest if they can expand into a filtered evidence pane rather than trying to carry the whole scope proof story inside one tiny chip row.

### What Helm should refuse

- giant audit prose where one small filtered evidence pane would do
- scope or continuity claims that cannot reveal their basis

## What now looks worth doing in Helm

### Worth freezing now

- **activity-scope truth**

Why now:
- current tools already expose explicit profiles, session types, private contexts, and reusable setup bundles,
- Helm now has enough saved/planned continuity surfaces that hidden scope widening would spread quickly,
- and the freeze can stay narrow: it only says nearby ambient context should not silently widen what counts as the same activity.

### Worth adding as candidate pressure now

- **activity scope witnesses**

Why this now looks strong:
- PowerToys/VS Code make scope axes explicit,
- GNOME/FancyZones/Obsidian show that layout and overview remain smaller than whole-task truth,
- Raycast shows how dynamic personal accelerators can get,
- and Node-RED/VS Code show that small revealable evidence panes scale better than giant prose.

## Current bounded take

Helm should likely become better than current workspace and command tools in one specific way:

**when it says “this is the same activity,” it should also be able to say which axes made that statement true and which nearby context did not count.**
