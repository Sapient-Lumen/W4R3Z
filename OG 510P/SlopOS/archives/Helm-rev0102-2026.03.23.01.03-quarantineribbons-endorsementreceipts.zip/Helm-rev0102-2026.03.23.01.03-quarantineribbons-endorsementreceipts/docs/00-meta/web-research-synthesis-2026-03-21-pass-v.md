# Web research synthesis — 2026-03-21 — pass V

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on two questions:
1. what ideas are now good enough to freeze narrowly,
2. and what combination move could make Helm feel unusually coherent and delightful.

## What this pass says at a glance

The most useful outside lesson is no longer “add more feature families.”
It is:
- rich desktop surfaces need more structure than flat rows,
- return-to-task tooling needs better honesty than ordinary session folklore,
- and long-running or strong actions feel dramatically better when status, diffs, and next moves live on one shell-owned card.

That combination points toward two strong outcomes for Helm:
- freeze **request-vs-live truth** as a narrow posture,
- and explore **activity cockpit cards** as a candidate cross-cutting move.

## Cluster 1 — structured cards beat flat launcher rows

### What current systems teach

PowerToys Command Palette now supports multiple extension page types, including list pages, detail pages, form pages, markdown pages, and grid pages.
Raycast likewise keeps proving that compact action surfaces become much more useful when they can show structured metadata, arguments, and context rather than only flat rows.

### What Helm should steal

Helm should keep moving toward **typed cards**, not merely richer rows:
- route cards,
- rehearsal cards,
- result cards,
- progress cards,
- and activity cockpit cards.

The key is not visual richness alone.
The key is that cards can carry:
- exact subject identity,
- provider / route identity,
- input fields,
- progress,
- uncertainty,
- and receipt / next-step links.

### What Helm should refuse

- card platforms that become a hidden app model
- provider-owned local state machines the shell cannot inspect
- rich cards that hide whether the truth shown is requested, admitted, or live

## Cluster 2 — saved layouts are popular, but launch truth is usually too flattering

### What current systems teach

PowerToys Workspaces shows strong appetite for one-shot return to a known desktop arrangement and even surfaces per-app launch status while the workspace is coming up.
FancyZones shows continued appetite for editable spatial layouts.
Obsidian Workspaces shows that named task-shaped arrangements remain genuinely useful even in very different products.

### What Helm should steal

Helm should keep pushing **layout templates with rebinding** and **capsules**, but now tie them together through a stronger front door:
- an activity cockpit card can show the current live state,
- the selected capsule,
- the chosen layout template,
- the current mismatches,
- and the pending / failed / completed launches or repairs.

That looks better than treating workspaces, restore, and layout as three separate helper tools.

### What Helm should refuse

- template systems that rely primarily on title folklore
- restore systems that say “done” when they only requested launches
- saved-layout helpers that are more authoritative than the shell graph itself

## Cluster 3 — overview works best when it stays keyboardable and shell-owned

### What current systems teach

GNOME continues to demonstrate the value of an overview that combines windows, workspaces, search, and keyboard navigation rather than forcing a mouse-only mode switch.

### What Helm should steal

Helm should preserve the idea that **Overview is the spatial companion to Omnibox**, not a separate worldview.
The new pressure here is that overview cards and activity cockpit cards should share the same request-vs-live honesty:
- what is currently live,
- what is just proposed,
- what is launching,
- and what is historical.

## Cluster 4 — timelines, session lists, and multi-diff views are quietly gold

### What current systems teach

VS Code's Timeline remains a strong proof that unified event history becomes much more useful once it can mix multiple event sources.
Recent VS Code agent-session work also shows the value of a list that exposes session status, progress, and file-change statistics at a glance.
And multi-file diff views remain a strong review pattern when a change spans more than one surface.

### What Helm should steal

Helm should likely reuse those lessons in shell form:
- capsule diff should be comfortable with small multi-object diffs,
- Operations Center should expose status / progress / changed-surface summaries for flows and long actions,
- and activity cockpit cards should show recent receipts, current mismatches, and “what changed” summaries instead of acting like dead bookmarks.

This is one of the clearest ways Helm can make Recall and Operations feel much smarter without inventing a giant history product.

## Cluster 5 — visual automation only scales with debug and packaging

### What current systems teach

Node-RED continues to show that the debug sidebar and structured message inspection are not luxury add-ons.
Its subflows likewise keep proving that reusable packaged fragments matter once graphs stop being toy-sized.

### What Helm should steal

This reinforces the earlier Flow freeze:
- debug/event lanes,
- reusable inspectable fragments,
- and one obvious path from a Flow node into a rehearsal / route / activity card.

A genuinely great Helm move would be letting a Flow produce an activity cockpit or route card rather than only a toast or a detached log line.

## Cluster 6 — tiny accelerators still matter enormously

### What current systems teach

Raycast Quicklinks, snippets, and dynamic placeholders keep proving that users love tiny personal accelerators that stay close to context.
PowerToys Peek also shows how much value there is in fast preview with optional pinning rather than a giant modal jump.

### What Helm should steal

- typed seeds that can prefill one or two fields on a card,
- preview windows that can stay pinned as a deliberate shell-owned local luxury,
- and explicit “act on current exact selection” routes that do not depend on ambient scraping as a default substrate.

### What Helm should refuse

- macro culture as the default contract
- silent frontmost-app scraping as the main way to satisfy placeholders
- preview that quietly becomes open, import, or execution

## What now looks strongest

Highest-value moves to keep live after this pass:
1. **request-vs-live truth** as a narrow cross-cutting freeze
2. **activity cockpit cards** as a shell-owned candidate move
3. **capsule diffs with multi-object summaries**
4. **layout templates with visible rebinding and launch-state honesty**
5. **typed seeds and pinned preview luxuries** that remain shell-owned and explicit

## What still does not need a hard freeze yet

- final cockpit-card taxonomy
- final overview shape
- final capsule schema
- exact layout-anchor language
- final relationship between cockpit cards and Operations Center tables

## Working stance

Helm should keep stealing ideas that make users feel **oriented, powerful, and truthfully informed**.
The best current recipe looks like:
- shell-owned cards,
- shell-owned diffs,
- shell-owned layout memory,
- and one activity-shaped front door where status, routes, and receipts can actually meet.
