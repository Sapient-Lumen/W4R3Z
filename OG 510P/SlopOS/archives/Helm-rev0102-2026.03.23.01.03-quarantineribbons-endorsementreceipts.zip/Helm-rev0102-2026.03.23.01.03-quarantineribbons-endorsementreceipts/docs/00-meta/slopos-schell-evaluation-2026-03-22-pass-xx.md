# SlopOS / Schell evaluation — 2026-03-22 pass XX

Purpose: continue evaluating what SlopOS's datacube is actually teaching Helm now that projection surfaces, view decks, and materialization bays are already in play.

This pass focused on a narrower question:

**what kinds of shell luxuries should stay personal or local, and what kinds can safely become portable or shared without bluffing about live truth?**

## 1) CH-SPROJ still teaches the right kind of ambition

`state-projection-schema-v0.md` remains one of the most useful SlopOS teachers.
It keeps projection:

- bounded,
- keyed,
- deterministic,
- digest-friendly,
- and explicitly non-authoritative.

That continues to argue against one giant Helm datacube dashboard.
The right steal is still many small honest faces over stronger truth.

But this pass sharpens one more implication:

**small projected faces are not all meant to travel the same way.**

Some are ideal as local shell luxuries.
Some can become portable entry objects.
Some should never quietly become shared truth.

## 2) View objects and AttrFS teach locality discipline as well as projection discipline

`view-objects.md`, `view-namespace-posture-v0.md`, and `attrfs-posture-v0.md` together keep saying:

- views are explicit,
- queries are view-scoped,
- results are handles rather than ambient paths,
- and saved query behavior stays shell-owned rather than turning into an app-visible global watch service.

For Helm, that matters beyond search.
It suggests that:

- a live lens should be visibly derived from one exact source,
- a deck should be visibly gathered around one stronger truth,
- a dock pin should be visibly pointing at one typed subject or action,
- and local shell convenience should not automatically turn into portable team truth.

The datacube lesson is not merely “be explicit.”
It is:

**keep projection, handle scope, and locality explicit together.**

## 3) View replication boundary is the best teacher for shared-vs-local honesty

`view-replication-boundary-v0.md` is especially valuable in this pass because it refuses one of the easiest lies in modern tool design:

a replicated summary is not the same thing as an active local binding.

That one refusal maps almost directly to Helm.
It says:

- a synced dock is not the same thing as a currently valid local target,
- a shareable deck is not the same thing as a live activity,
- a copied exact trail is not the same thing as a locally open object,
- a portable entry kit is not the same thing as local continuity already reacquired.

Helm should steal that discipline aggressively.

## 4) OpenURI materialization boundary keeps the anti-smuggling lesson sharp

`openuri-materialization-boundary-v0.md` keeps reinforcing a lesson Helm keeps needing:

successful open does not mean durable import, exact local object identity, or persistent truth about what now exists locally.

This is exactly why Helm's materialization-bay idea still matters.
And it now combines with locality pressure:

- some things stay ephemeral and local,
- some things become local durable objects,
- some things become portable artifacts,
- some things can be shared,
- but those are different rungs, not one flattering surface.

## 5) The strongest Helm payoff now is renewed live-lens pressure

This pass makes live lenses feel more important again.
A live lens is one of the best ways Helm can make projection-surface law feel delightful instead of bureaucratic.

Why it fits the datacube lessons:

- it is clearly derivative,
- it can stay source-witnessed,
- it can degrade honestly,
- it does not need to pretend to be the canonical object,
- and it can stay a small exact face over stronger truth.

The most promising first-cut lens still looks modest:

- one exact source witness,
- one live badge,
- inspect / follow / expand,
- maybe pin-to-dock or add-to-deck,
- no silent input forwarding by default.

## 6) The second new payoff is surface locality tiers

The outside world increasingly separates:

- personal local setup,
- workspace or activity local setup,
- portable/exportable artifacts,
- and shared/team objects.

SlopOS gives Helm a better reason to do that than ordinary preferences hygiene.
Without locality discipline, compact shell luxuries drift into false continuity or false team truth.

So Helm should likely name a candidate move around **surface locality tiers**:

- what stays personal and local by default,
- what can travel as a portable artifact,
- what can become shared truth,
- and what needs an explicit promotion step between those modes.

## 7) One more lesson we must learn from the past

The past did not only fail by creating ambient authority.
It also failed by creating **ambient portability**:

a useful local setup silently became treated as a thing that should sync, share, restore, or count everywhere.

That is one reason modern tools end up with confusing workspace/profile/device/team overlap.
Helm should resist that early.

## What this pass changes

- it makes **live lenses** feel more urgent as a delightful proof of projection-surface law
- it adds **surface locality tiers** as a new warm Helm move
- it strengthens the reading of SlopOS's datacube as a teacher of **projection + handle scope + locality discipline together**
- it keeps view decks and materialization bays warm, but now with stronger pressure to distinguish local, portable, and shared forms

## What this pass still does not justify

- a giant sync constitution
- a universal shared workspace truth model
- automatic sharing of docks, keys, trust decisions, or live-lens state
- turning every local setup object into a team artifact
- adding more pillars

## Current bounded take

**Helm should keep reading SlopOS's datacube as a teacher of bounded projections, explicit views, explicit materialization, and now explicit locality. That pushes Helm toward live lenses and surface locality tiers without justifying a giant sync or dashboard system.**
