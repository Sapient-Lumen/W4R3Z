# Web research synthesis — 2026-03-21 pass XV

Purpose: continue harvesting strong ideas from current tools **without** importing their whole product worldview.

This pass focused on:

- typed pivots in search/summon surfaces
- preview-adjacent action
- persistent compact launch/search surfaces
- source/mode separation
- reusable flow structure

## 1) Spotlight's typed facet row is more important than it looks

Current Apple Spotlight now exposes explicit category pivots such as **Applications**, **Files**, **Actions**, and **Clipboard**, and Apple documents Clipboard-history search directly inside Spotlight.

The stealable idea is not “copy Spotlight.”
The stealable idea is:

**one fast summon surface gets better when it can pivot explicitly between typed result families instead of pretending one flat list always tells the truth.**

For Helm this suggests a compact **facet strip** that could surface pivots like:

- objects
- actions
- routes
- receipts
- transfers / clipboard / exchange
- maybe windows / workspaces when the shell graph is the active scope

Why this matters:

- Omnibox stays fast without becoming mushy
- Recall stays precise without becoming one giant recent-items soup
- Exchange can expose transfer/clipboard history as one explicit facet rather than leaking it into every result family

## 2) Preview with bounded action keeps winning

Apple Quick Look, Finder Preview pane + Quick Actions, and Raycast Windows Quick Look all keep proving the same thing:
users love seeing something **before** they commit, and they also love having one or two bounded next actions sitting nearby.

Helm should steal that as a **preview rail**, not as silent open.

The important split is:

- preview = inspect
- preview rail = bounded typed next moves
- open / attach / import / run = still stronger actions with their own route/review law

That is cleaner than treating preview as a thin version of full open.

## 3) PowerToys is increasingly a host-surface teacher

Current PowerToys docs make Command Palette a fast host-owned surface for apps, commands, and tools, and the new Dock keeps a persistent edge toolbar of most-used commands and extensions.

The direct steal for Helm is **host-owned compact surfaces**:

- host-owned status/progress
- host-owned typed providers
- maybe later host-owned pinned bands or compact action shelves

The non-take is extension-bazaar drift.
Helm should steal host ownership, not just endless plugin surface area.

## 4) Warp and WezTerm keep validating honest launch objects

Warp's Launch Configurations and URI scheme, plus WezTerm's launcher menu over tabs/windows/domains, continue to validate one thing:
users want durable entry objects.

But these surfaces are best when they are honest about what they are:

- a saved setup,
- a launchable entry,
- an attach candidate,
- a scoped launcher,
- not proof of currently live continuity.

That keeps **launch ladders** warm and supports keeping entry artifacts weaker than live truth.

## 5) VS Code keeps proving anchored context

VS Code terminal shell integration and sticky scroll keep demonstrating that command boundary context is high-value.

The stealable idea is broader than terminal scroll position:

- keep the producing action visible,
- keep the receipt or route anchor visible,
- keep downstream panes tied to their source.

That continues to justify **sticky context strips** as a Helm move.

## 6) Node-RED still teaches reuse better than most desktop tooling

Node-RED subflows remain a good precedent for reusable fragments that can be instantiated in multiple places.

The take for Helm is still:

- reusable typed flow fragments,
- inspectable internals,
- visible status,
- no giant opaque prefab culture.

## 7) Warp's agent modality remains a warning and an opportunity

Warp now documents a clean terminal plus a dedicated conversation view as distinct ways of working.
That continues to validate a Helm/Schell direction:

**source/mode separation improves trust.**

The take is not “copy Warp's agent UX.”
The take is that Helm should keep direct command, delegated/conversation work, historical receipt, and imported material visibly distinct where possible.

## Strongest current takes

- **facet strips** for typed pivots in Omnibox / Recall / Exchange
- **preview rails** for bounded next actions next to shell-owned preview
- **launch ladders** as honest entry objects
- **sticky context strips** for anchored source/action context
- **reusable flow fragments** with visible status and inspectable internals

## Strongest current non-takes

- do not flatten everything into one launcher list
- do not let preview silently count as open
- do not let pinned/docked commands become a hidden second shell law
- do not let terminal-local convenience become shared desktop truth
- do not let reusable flow fragments turn into opaque prefab marketplaces
