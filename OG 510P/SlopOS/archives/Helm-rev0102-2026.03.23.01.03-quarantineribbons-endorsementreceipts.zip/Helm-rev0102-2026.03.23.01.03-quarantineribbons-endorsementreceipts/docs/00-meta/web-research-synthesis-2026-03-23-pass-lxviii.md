# Web research synthesis — 2026-03-23 — pass LXVIII

Question: after basis stamps, action warrants, drift gates, effect receipts, and slot verdict ledgers, what small durable cross-cutting move still looks missing for Helm's datacube?

Answer from this pass: **delegated non-authoritative side work**.
The strongest next compact move is now **shadow work lanes + adoption harbors**.

## What current tools keep teaching

### 1. Good systems separate exploratory or delegated work from the authoritative lane

Figma branches are explicit controlled environments.
They let teams explore changes without editing the original file,
then submit the branch for review and merge only after approval.

GitHub draft pull requests teach the same law in a more review-shaped form.
A draft pull request is a proposal-shaped lane for work in progress.
It cannot be merged,
and code owners are not automatically requested until the author marks it ready for review.

The key pattern is not “copy Git.”
It is:
**parallel candidate work should stay visibly weaker than the authoritative lane until explicit promotion.**

### 2. Suggestions are powerful precisely because they are deferred edits

Google Docs suggestions are effectively deferred edits waiting for approval.
They can be previewed with suggestions accepted or rejected,
but they do not quietly become the official document on creation.

That is a surprisingly strong Helm lesson.
A helper or delegated assistant can do useful work,
but the shell should still keep the live lane honest by holding those edits in a weaker posture until adoption.

### 3. Parallel working copies are useful when identity and relation stay exact

`git worktree` reinforces a narrower structural point.
A repository can support multiple working trees at once,
with each linked worktree tracked as its own working copy attached to the same repository.

That makes the shape of the missing Helm object feel smaller and clearer.
The right move is not a giant new workspace constitution.
It is one compact side lane with exact relation to one live subject and one exact starting basis.

### 4. Agentic delegation becomes trustworthy when the agent works in a weaker lane

GitHub Copilot coding agent is the strongest current pressure here.
It works autonomously in an Actions-powered environment,
creates pull requests with the results,
and GitHub keeps it fenced:
- draft pull requests created by the coding agent must be reviewed and merged by a human,
- the agent cannot mark them ready for review,
- the agent cannot approve or merge them,
- the work is tracked through explicit sessions and logs,
- and by default workflows do not run until a human chooses to approve and run them.

That is almost a direct product lesson for Helm.
Delegated power becomes much more acceptable when it is:
- isolated,
- inspectable,
- clearly authored,
- and unable to silently self-promote into the live lane.

## What Helm should steal

- explicit non-authoritative side lanes for delegated, helper, background, or repair work
- one honest adoption harbor where candidate work can be inspected and selectively applied
- a clear split between lane identity, starting basis, current drift posture, and live adoption state
- preview/diff surfaces that stay adjacent to adoption instead of buried in agent logs
- visible authorship and chooser posture for candidate work
- explicit human-reviewed promotion rungs for stronger lane outputs
- session/log visibility for longer-running delegated work without mistaking logs for adoption

## What Helm should not steal

- giant branch-manager ambition
- giant collaboration-court ambition
- helper edits appearing directly in the authoritative live lane
- draft/suggestion/branch surfaces that silently auto-promote when they "look safe"
- multiple side lanes that lose their exact relation to one live subject or one reviewed basis
- hidden background agents with no obvious review or adoption surface

## Why this matters to the pillars

This is not a new pillar.
It is one cross-cutting delegated-work honesty move that helps almost every existing one:

- **Operations Center** can show delegated/background lanes and adoption-ready items without pretending they are live results already
- **Desktop Flow** can stage repair or helper-generated fragments in side lanes instead of flattening everything into fire-and-forget mutation
- **Exchange** can keep imported or receiver-local candidate landing explicit before adoption
- **Recall** can reopen abandoned or rejected candidate lanes without mistaking them for the authoritative live lane now
- **Omnibox** can summon candidate work honestly instead of pretending a helper suggestion is already the answer

## Judgment

The next small durable proof worth reheating is **shadow work lanes + adoption harbors**.
Helm does not need a giant agent product.
It needs one compact reusable way to say:

**this candidate work exists next to the task,
this is who or what produced it,
this exact basis it started from,
and this is the honest place where adoption can happen — or be refused — without silently mutating the live lane.**
