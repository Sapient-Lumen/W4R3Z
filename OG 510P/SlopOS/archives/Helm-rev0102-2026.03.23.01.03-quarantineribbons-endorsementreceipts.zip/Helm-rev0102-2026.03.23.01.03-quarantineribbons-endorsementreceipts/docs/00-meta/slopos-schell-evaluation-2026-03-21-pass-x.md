# SlopOS + Schell evaluation — 2026-03-21 — pass X

Purpose: keep using SlopOS and Schell as design teachers while Helm decides what deserves a freeze, what deserves a specimen, and what should stay pressure only.

This pass focuses on the next trap after request-vs-live truth,
entry-artifact truth,
binding witnesses,
activity scope truth,
and continuity-choice/authorship truth:

**even an honest continuity surface can still cheat if it lets a past review or strong-action affordance silently follow a newer mutable basis.**

That now looks strong enough to justify one narrow new Helm freeze:
- **reviewed basis drift requires fresh review**,
- and one new candidate move:
- **basis packets**.

DelayBasin matters here because it already keeps asking for basis witnesses,
stale-path honesty,
and exact active-request scope instead of flattering ambient carry.

## What SlopOS pressures most strongly now

### 1. Approval binds exact action bytes, not a floating head

SlopOS already has the sharpest local teacher for this:
`approval-basis-posture-v0.md`.

Its core move is simple and very strong:
- approval binds one exact action,
- mutable local basis must already be encoded as exact witness material,
- and old approval does not silently follow a newer head,
revision,
descriptor,
queue item,
or target.

That is a superb lesson for Helm.
The shell does not need the whole SlopOS approval stack,
but it absolutely should steal the anti-sticky-head law.

### 2. Request-state humility naturally extends into review-basis humility

SlopOS keeps refusing the lie that a request key or admitted request proves current mutable state.
The next refinement is:
a remembered review or saved strong-action affordance also does not prove current mutable state.

That means Helm should not let:
- a cockpit card,
- an entry kit,
- a capsule-derived strong action,
- a saved route,
- a historical receipt,
- or a proposal card

quietly keep its strong-action posture after the basis has drifted.

### 3. Exact reveal and fail-closed posture still matter here

SlopOS's exact-reveal instinct remains the right anti-folklore teacher.

If Helm can no longer show that a strong action still rests on the same reviewed basis,
then the shell should not flatten that into a soft green success path.
The shell can still be helpful,
but the right next move becomes:
- inspect,
- review again,
- fresh bind,
- or hold.

### 4. The SlopOS datacube now pressures a basis layer above choice/authorship

The deeper datacube lesson is now:

- binding witnesses explain **how** a join happened,
- scope witnesses explain **which axes counted**,
- continuity choice witnesses explain **who proposed / chose / executed a substitute**,
- and basis packets can explain **what exact reviewed state the strong action still depends on**.

That feels like the next honest refinement rather than feature sprawl.

## What Schell adds to the picture

### 1. Schell already names the missing move directly

Schell's current pressure is unusually aligned with this pass:
- authorship badges,
- basis packets,
- compare-and-set review,
- restore honesty,
- workflow seeds with provenance,
- and stale-basis refusal.

That is already almost the right Helm move in miniature.

### 2. Entry kits, cockpits, and recall cues increasingly need a basis story

Schell's launch-kit and cockpit direction now implies a stronger shell lesson:
saved task-entry luxuries become much more trustworthy if they can say not only:
- what they point at,
- how they rejoined,
- what scope counted,
- and who chose the substitute,

but also:
- what exact basis the next strong action still depends on,
- and whether that basis still matches.

### 3. Compare-and-set review is the humane version of “try again”

Schell is a useful teacher here because it does not need a giant workflow bureaucracy to say something helpful.
A tiny stale-basis refusal can be more humane than a flatter “go ahead” button,
because it tells the operator:
- this is no longer the exact thing you reviewed,
- here is what drifted,
- here is the next honest ladder.

## What DelayBasin usefully pressures here

DelayBasin is the archive-method teacher that keeps this bounded.

The useful take is:
- preserve the basis witness,
- preserve the stale-path witness,
- preserve the exact active request / subject,
- and fail closed rather than flattering approximate carry.

The non-take is:
- importing a giant constitutional review machine before one tiny shell witness exists.

## What now looks worth doing in Helm

### Worth freezing now

- **reviewed basis drift requires fresh review**

Why now:
- Helm has enough continuity and saved-task structure now that basis drift would quickly become hidden product debt,
- SlopOS already has a first-rate exact-basis teacher,
- Schell already points directly at basis packets and compare-and-set review,
- DelayBasin supplies the “bounded witness, not giant constitution” discipline,
- and the freeze can stay narrow.

### Worth adding as candidate pressure now

- **basis packets**

Why this now looks strong:
- entry kits,
cockpits,
Recall,
binding witnesses,
scope witnesses,
and continuity choice witnesses all get more truthful if a strong action can name its exact reviewed basis,
- basis packets can stay small and shell-owned,
- and the first useful version can be earned without freezing a general workflow algebra.

A first basis packet should likely name:
- the action or continuity subject,
- the source object or receipt,
- the exact revision / digest / live-target witness that mattered,
- any relevant authority or destination digest when it matters,
- the current compare result (`match`, `drifted`, `partial`, `unknown`),
- and the honest next ladder (`inspect`, `review again`, `fresh bind`, `hold`).

## What Helm should explicitly not take

- a giant reusable approval cache
- a hidden `latest approved` register
- a full workflow bureaucracy before one tiny basis packet exists
- the belief that authorship witnesses alone solve stale-basis risk
- a soft “close enough” basis story for strong actions

## Current bounded take

A useful new Helm rule is:

**when a strong shell-facing action or continuity-affecting action depends on reviewed mutable basis, that basis should not silently follow a newer state. Basis drift should require fresh review or downgrade the action.**

And a useful new candidate move is:

**basis packets as small shell-owned witness strips or cards that say what exact reviewed basis a strong action still depends on, whether it still matches, and what honest action ladder remains.**

