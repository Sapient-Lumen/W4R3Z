# Web research synthesis — 2026-03-21 pass XXXI

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on one tighter landing question:

**if Helm already has portable cores, local overlays, inherit masks, arrival overlays, and adoption slices, what stable identity should survive travel, and how should Helm witness the receiver defaults that actually filled omitted gaps?**

## 1) Current tools keep separating a stable carried structure from mutable local residue

VS Code Profiles keep validating this split.
Profiles are explicit sets of customizations that can be created, switched, exported, and imported.
The Default Profile remains the live accumulating local baseline, and partial profiles can include only customized configurations or also include configurations inherited from that Default Profile.
Settings Sync adds the second half of the lesson: some configuration travels across machines, but VS Code explicitly does **not** synchronize extensions to or from remote windows.
User and workspace settings reinforce the same scope split again: some settings are personal/global and some are workspace-scoped.

Raycast teaches a similar distinction from a launcher-first angle.
Personal Quicklinks are stored locally and not synced, while team-shared quicklinks live in a separate shared lane.
That is a strong reminder that “useful structure that can travel” and “my current local residue” should stay distinct even when both feel convenient.

That combination strongly supports one Helm move:
**surface core digests**.
Helm should be able to compute one stable digest over the portable carried core of a shell surface — excluding timestamps,
receipts,
receiver-local overlays,
placement,
secrets,
and similar mutable residue — so comparison,
dedup,
rehearsal,
and follow-on landings can say “same carried core,
different local landing” honestly.

## 2) Explicit inheritance is not enough; actual default use also needs witness

VS Code's profile model again matters here.
A profile may use configurations from the Default Profile,
and partial export can either include only customized configuration or include what was inherited from the Default Profile.
That means there is a real difference between:

- what a packet explicitly carried,
- what the receiver was allowed to inherit,
- and what the receiver actually filled from local defaults.

Figma's Code Connect and slot/property tooling reinforce the same lesson in a more structured way.
Code Connect bridges code components to design components with property mappings and dynamic code examples,
and slots make structured flexible areas explicit instead of relying on fuzzy child-content guesswork.
That is a strong hint that Helm should name both the **stable carried structure** and the **actual receiver-side fills** slotwise rather than flattening them into “it worked.”

That combination strongly supports a second Helm move:
**default-fill receipts**.
If a landing uses an inherit mask to fill one class from receiver defaults,
Helm should leave a compact witness naming exactly which default source filled which admitted slot or class,
and which stronger classes were refused from default fill altogether.

## 3) These moves fit Helm's existing truthful-landing stack

These moves should not replace the current landing family.
They compose with it:

- portable cores
- local overlays
- landing manifests
- anchor maps
- inherit masks
- basis stamps
- residue ledgers
- landing rehearsals
- arrival overlays
- adoption slices
- receiver fit cards
- rebind ladders

A better truthful landing story now looks like this:

1. carry one portable core
2. compute one **surface core digest** over the carried core
3. compare or rehearse the landing on the receiver
4. allow only approved classes to inherit receiver defaults
5. emit one **default-fill receipt** naming what actually filled from local defaults
6. adopt or reject with the remainder still explicit

## 4) Strongest new warm moves from this pass

- **surface core digests** — compact stable digests over the portable carried core of a Helm surface,
  excluding local overlays,
  volatile receipts,
  timestamps,
  and receiver-specific residue
- **default-fill receipts** — compact shell-owned witnesses for which admitted classes actually used receiver defaults during rehearsal,
  landing,
  or bounded adoption

## 5) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep portable structure separate from local residue
- keep explicit inheritance weaker than actual carried structure
- keep actual default fills visible rather than ambient
- keep compare,
  rehearse,
  inherit,
  and adopt as separate truthful steps

## Strongest non-takes from this pass

- do not add a pillar
- do not flatten carried-core identity into full landed equivalence
- do not let receiver defaults quietly impersonate carried sameness
- do not turn inheritance into ambient auto-heal folklore
- do not build a giant sync or merge constitution
