# Web research synthesis — 2026-03-22 — pass LV

Question for this pass:
**what do current tools teach Helm about linked views, profile-scoped front doors, tiny summonable entry handles, hierarchy-preserving view overlays, and triage suggestions — and which of those moves should Helm adopt now versus keep warm?**

## Main takeaway

The strongest new outside pattern is:

**one truth, many linked views, tiny front doors, explicit scope, and suggestions that stay weaker than operator choice.**

This pushes Helm a little further than rev0060 without changing its core direction.
The datacube still should not become one giant cube.
But Helm should now get more serious about four practical moves:
- **linked views by reference**,
- **profile-scoped front doors**,
- **exact front-door handles**,
- and **triage suggestions that begin as explainable proposals rather than silent routing law**.

## What the current tools are teaching

### 1. Notion and GitHub both reinforce linked views over one stronger substrate

Notion keeps teaching that the same database can support many different views,
and that linked databases let those views appear in multiple pages without turning each appearance into a separate source of truth.
GitHub Projects keeps pushing the same basic idea from another angle:
one project can have multiple explicit views,
and the new hierarchy view preserves nesting inside a view rather than forcing teams to switch to a separate hierarchy product.

The Helm lesson is strong:
**a view should be reusable by reference.**
A front door,
a deck,
a cockpit card,
or a triage page should be able to borrow one saved view object without copying its law,
hiding its provenance,
or pretending the borrowed surface is now a fresh authority domain.

### 2. Arc and VS Code keep proving that setup bundles need explicit scope and identity posture

Arc Spaces and Profiles separate *context grouping* from *identity/cookie/login scope*.
VS Code Profiles similarly package tools, settings, and layout as an explicit carried setup that can be switched, exported, imported, and shared.

The Helm lesson is not “copy browser profiles” or “copy editor profiles”.
It is:
**saved front doors should be able to carry explicit scope affinity without silently choosing identity, account, or remote posture for the user.**
A front door can say:
- this usually belongs with work profile,
- this prefers this provider/account/space,
- this was last good in that lane,
without bluffing that those axes are already live now.

### 3. Raycast and PowerToys keep validating tiny exact entry handles

Raycast Quicklinks show the value of tiny named handles for URLs, file paths, and deeplinks.
PowerToys Workspaces shows that one saved arrangement can relaunch a meaningful desktop state and be pinned as a shortcut.

The Helm lesson is that it wants a very small entry object,
smaller than an activity spine and smaller than a full entry kit:
**an exact front-door handle**.
That handle should be summonable,
pinnable,
sharable,
and attachable to other surfaces,
while still staying weaker than current-live truth.

### 4. Linear is now teaching a more precise triage lesson than before

Linear's dedicated Triage inbox still looks right.
But the newer Triage Intelligence docs sharpen the next lesson:
AI can infer likely teams, projects, labels, duplicates, and relationships,
yet the product still keeps explainability and accept/decline posture in the loop.
It even allows auto-apply,
but only as an explicit configurable escalation.

The Helm lesson is:
**triage suggestions are worth stealing, but auto-apply should not be the default constitution.**
Helm should first prove:
- explainable suggestion chips,
- accept / decline / inspect why,
- and optionally saved local guidance.
Only after that should stronger automation rungs exist.

### 5. Figma and GitHub keep reinforcing compare-near-entry

Figma branches remain controlled environments for exploration and review/merge.
GitHub activity and compare views continue to prove that bounded compare should stay near ordinary activity rather than buried in a separate audit religion.

The Helm lesson is unchanged but stronger:
front doors,
linked views,
and triage surfaces should be able to keep one exact compare path nearby.
That compare should stay bounded and source-witnessed,
not turn into general timeline theater.

## What Helm should steal now

### 1. Linked views by reference
A saved view object should be reusable inside:
- activity entry kits,
- view decks,
- cockpit cards,
- Overview,
- and triage surfaces,
while preserving source, basis, trust tier, and local/adopted/imported posture.

### 2. Exact front-door handles
Helm should have a tiny summonable handle that can point at:
- one saved view,
- one entry kit,
- one triage lane,
- one compare path,
- one provider deeplink,
- or one scoped launch path.

### 3. Profile-affinity on front doors
A front door should be able to carry:
- preferred profile/space/account/provider affinities,
- last-good lane relations,
- and visible scope witnesses,
without silently selecting or widening those axes.

### 4. Suggestion-first triage
Suggestion chips for routing,
duplicates,
related work,
and likely next surfaces now look worth prototyping.
But they should remain weaker than explicit operator adoption.

### 5. Hierarchy-preserving overlays inside views
Helm should allow a view to preserve nested relations when useful,
but that should be a property of the view,
not a new giant ontology that every surface must obey.

## What Helm should not import

1. **Do not import dashboard sprawl from database tools.**
2. **Do not let linked views become hidden copied state.**
3. **Do not let profile affinity silently choose the current live account/provider/session.**
4. **Do not let quicklinks/front-door handles impersonate exact current-live return.**
5. **Do not let triage AI silently mutate authoritative state by default.**
6. **Do not let hierarchy overlays become a new universal worldview.**

## Judgment for Helm

The new outside pressure does not change Helm's center.
It sharpens it.

Helm should still keep the seven pillars stable.
It should still treat saved view objects and checkpoint branches as the strongest proof targets.
But the best next supporting moves now look like:
- **linked views**,
- **exact front-door handles**,
- **profile-scoped front doors**,
- and **suggestion-first triage surfaces**.

That is enough new pressure to justify another revision,
but not enough to justify a new pillar or a universal workspace constitution.
