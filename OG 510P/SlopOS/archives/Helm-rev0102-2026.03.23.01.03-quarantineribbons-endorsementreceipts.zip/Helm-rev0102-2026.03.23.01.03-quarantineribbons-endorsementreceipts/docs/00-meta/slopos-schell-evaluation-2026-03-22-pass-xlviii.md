# SlopOS / Schell evaluation — 2026-03-22 — pass XLVIII

Purpose: re-read the latest SlopOS bundle and ask what it teaches Helm about **approval on mutable basis** now that Helm already has context loadouts, contribution witnesses, claim envelopes, and reliance ladders.

## Main takeaway

The latest SlopOS bundle is now pressing a sharper action law into Helm:

**approval should bind one exact proposed effect on one exact reviewed basis,
not a floating latest target and not a transient UI moment.**

That is what Helm still lacks.

## What the latest SlopOS bundle keeps teaching

### 1. Approval should bind exact mutable basis, not “whatever is current now”

`approval-basis-posture-v0.md` is the clearest teacher this pass.
It refuses sticky head-following approval folklore.
A human-facing approval or validator acceptance that depends on mutable local basis should already encode that exact basis into the action,
rather than quietly approving whatever the current head/revision/queue item happens to be later.

For Helm,
that means a strong shell-facing action should not merely remember:
- the intent,
- the subject family,
- or the last place the user looked.

It should be able to say:
- this exact proposed effect,
- against this exact reviewed basis,
- under this exact current context posture.

### 2. Transient UI status is not durable decision truth

`attention-durable-status-boundary-v0.md` keeps insisting that banners,
notifications,
and transient cues are presentation,
not durable consequence truth.

For Helm,
that means:
- a snackbar saying “ready to apply” is not approval,
- a toast saying “done” is not a receipt,
- and a preview card disappearing is not durable decision state.

A reviewed change needs a stronger shell-owned object than transient chrome.

### 3. Status and freshness artifacts are evidence, not authority

`attestation-collateral-status-boundary-v0.md` keeps the same harsh law in another register:
locators,
`nextUpdate`-style metadata,
cache snapshots,
and freshness hints may help,
but they do not create ambient authority,
latest-truth semantics,
or an obligation to auto-chase the newest collateral.

For Helm,
that means a saved preview,
a claim envelope,
a review ticket,
or a historical proposal should not quietly stay action-authoritative merely because it still looks recent.

### 4. Richer result structure belongs in explicit sidecars, not smuggled core semantics

`capshell-result-sidecar-boundary-v0.md` is another strong teacher here.
It keeps richer result structure in an explicit sidecar descriptor instead of overloading the replay-critical core meaning.

For Helm,
that suggests action approval should likewise stay explicit.
Do not smuggle exact proposed-change semantics into:
- generic open,
- generic preview,
- generic recents,
- or generic status badges.

If a surface is carrying a reviewable exact proposed change,
that should be named as such.

## What Helm should keep

### 1. A strong action should have one explicit approval object

Not every tiny action needs ceremony.
But when the action is strong,
mutable,
receiver-affecting,
or privilege-affecting,
Helm should have one compact shell-owned object that carries:
- exact proposed effect,
- exact reviewed basis,
- affected-set or target witness,
- context/loadout witness,
- and the honest next action ladder.

### 2. Drift should downgrade the warrant, not silently follow it

SlopOS keeps forbidding sticky latest-following semantics.
Helm should do the same.
If the mutable thing changed,
old approval posture should degrade to:
- review again,
- refresh bind,
- inspect-only,
- or hold.

### 3. Privileged follow-on steps should often be a stronger rung

A proposed edit,
an adopted edit,
and a privileged follow-on run are not always the same strength.
That is very SlopOS-shaped,
and Helm should keep it.

## What Helm should avoid

1. **Do not let old review cards silently follow new mutable state**
2. **Do not let transient UI cues count as durable approval or durable completion**
3. **Do not let freshness hints or recency posture count as current authority**
4. **Do not let exact change semantics hide inside generic preview/open/status surfaces**
5. **Do not build a giant workflow bureaucracy before one compact action warrant exists**

## Judgment for Helm

SlopOS is again the right teacher.
It keeps saying the same excellent thing in sharper action form:

**exact basis,
explicit proposal,
local review,
and durable consequence are different strengths.**

That makes **action warrants** look like a good next support contract for Helm,
with **drift gates** as the right adjacent move,
provided both stay:
- compact,
- shell-owned,
- basis-witnessed,
- drift-aware,
- and visibly weaker than receipts until the stronger act has really happened.
