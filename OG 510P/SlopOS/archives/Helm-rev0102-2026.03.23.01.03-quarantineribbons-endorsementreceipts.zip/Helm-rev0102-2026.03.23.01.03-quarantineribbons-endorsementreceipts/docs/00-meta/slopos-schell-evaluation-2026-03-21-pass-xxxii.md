# SlopOS / Schell evaluation — 2026-03-21 pass XXXII

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on one sharper seam:

**if Helm already has truthful arrival, explicit compare surfaces, and bounded selective adoption, what should it learn from SlopOS about bounded candidate sets and about durable slotwise outcome witness?**

## 1) SlopOS keeps teaching that selection should stay set-valued until an explicit target is chosen

The strongest teacher in this pass was `namecert-selection-boundary-v0.md`.
That doc makes a hard but healthy move:
evaluation may yield zero,
one,
or many admissible candidates,
and Phase 1 refuses to hide that under a silent winner rule.
There is no “latest bundle wins,”
no “shortest chain wins,”
and no invisible ranking lattice.
Any authority-bearing materialization must name the exact chosen candidate and retain source provenance.

That is an excellent teacher for Helm's landing story.
Near-match fences already say that a similar local target is not automatically the same target.
The next honest step is the positive sibling:
when multiple admissible local candidates exist,
Helm should expose a bounded explicit choice set instead of either failing opaquely or silently picking a winner.

This makes **arrival choice sets** feel increasingly earned.

## 2) SlopOS also keeps teaching that evaluation and materialization are separate,
## and Helm should record the results of selective materialization explicitly

The next strong teacher was `namecert-projection-boundary-v0.md`.
That doc keeps evaluation and materialization as separate events,
lands authority-bearing results only through explicit `view.attach` / `view.detach` actions on concrete slots,
and requires source-digest provenance to travel with the live mutation.

That is a very close cousin of Helm's current adoption story.
A landing or rehearsal may evaluate an imported surface,
show compare overlays,
and offer selective adoption.
But if Helm does not keep one durable per-slot result after those choices,
then the shell has to reconstruct history from receipts,
fit cards,
and memory.
That is exactly the kind of fuzz SlopOS keeps warning against.

This makes **slot verdict ledgers** feel increasingly earned.

## 3) Approval-basis humility still matters here

`approval-basis-posture-v0.md` keeps repeating the same safety discipline:
a reviewed basis must be encoded exactly,
and approval does not silently follow a moving head.
That means an arrival choice set should name exact candidate basis material,
not just display human-friendly labels,
and a slot verdict ledger should preserve which exact candidate or default source actually won for each slot.

`capability-wallet-schema-v0.md` and `view-objects.md` reinforce the remaining posture.
Stable carried structure is useful,
but view resolution stays explicit and authority-bearing change still lands on concrete slots.
That means Helm should keep treating portable shell luxuries as derived structures that only become stronger through explicit slotwise landing.

## 4) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- landing rehearsals,
  arrival overlays,
  adoption slices,
  surface core digests,
  and default-fill receipts still look right
- add **arrival choice sets** so Helm can expose bounded admissible landing candidates without hidden winner-picking
- add **slot verdict ledgers** so selective adoption leaves durable per-slot truth behind

## 5) What still does not seem worth taking

- not a giant global resolver for saved shell surfaces
- not implicit ranking of “best” local rebinding candidates
- not a vague imported state that hides which slots changed
- not a new pillar
- not a universal merge constitution

## 6) Current judgment

The most important lesson from this pass is:

**Helm gets smarter by exposing bounded explicit choice sets when exact rebinding is absent,
and by leaving a durable slotwise outcome witness when selective landing decisions are made.**

That feels strong enough for two new candidate contracts,
and still not strong enough for a new pillar or a new freeze.
