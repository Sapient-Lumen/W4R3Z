# SlopOS + Schell evaluation — 2026-03-21 — pass V

Purpose: keep using SlopOS and Schell as design teachers while Helm is still choosing what to freeze, what to pressure, and what to postpone.

This pass narrows in on one cross-cutting lesson that now looks strong enough to freeze and one new luxury move that looks strong enough to add as a candidate:
- **request-vs-live truth** should become a narrow Helm posture now,
- and **activity cockpit cards** look like a very strong next candidate move.

DelayBasin still matters here, but mainly as archive method: it reminds Helm to keep the import bounded, explicit, and specimen-seeking rather than letting one good insight widen into a whole second constitution.

## What SlopOS pressures most strongly now

### 1. Request state is not live truth

The OpenURI family in SlopOS keeps making the same point from multiple angles:
- exact reveal/select should fail closed rather than degrade into a nearby browse,
- launch completion is not the same thing as observed success,
- recent-items enrollment is not the same thing as durable reopen authority,
- session/profile choice is not the same thing as generic launch,
- and transient attention cues are not durable outcome truth.

That is bigger than OpenURI.
It means Helm should stop letting cards, restores, launchers, and dashboards blur together:
- **requested**,
- **admitted / route-chosen**,
- **live / currently observed**,
- **historical / receipt-backed**,
- and **denied / unavailable**
are distinct truth classes.

This is now strong enough to freeze as a narrow cross-cutting posture instead of leaving it implicit inside Recall or Exchange only.

### 2. Exactness is still one of Helm's main competitive advantages

SlopOS keeps refusing flattering approximations:
- exact reveal/select is exact,
- generic launch is not hidden materialization,
- local history is not portable truth,
- safe-open does not quietly become a broad preview or execution lane,
- and result rendering for risky objects stays metadata-safe until the user explicitly crosses a sharper seam.

Helm should keep stealing that exactness, especially where desktop products usually bluff:
- restore,
- route choice,
- preview,
- open / reveal,
- and “I launched it, therefore it happened” theater.

### 3. Boundaries need families, not just good intentions

The SlopOS datacube is especially good at one thing Helm still needs more of:
when a seam starts spawning adjacent edge cases, SlopOS tends to gather them into an explicit family with a discovery surface instead of letting the archive remember them by mood.

Helm should steal the **family discipline**, not the archive mass.
The point is not to clone SlopOS-sized boundary forests.
The point is to notice when a Helm surface has become important enough that its nearby lies need a compact named family.

Request-vs-live truth is one of those cases.
It now touches:
- Omnibox result cards,
- rehearsal cards,
- Recall restores,
- Operations Center status,
- Exchange route witnesses,
- and notifications / progress cues.

### 4. Authority changes are legible when the shell owns the diff

SlopOS's authority-diff / receipt work keeps pressuring Helm toward the same product move:
strong actions feel much safer when the shell can say not just “run this,” but:
- what subject is involved,
- which route/provider is involved,
- what new authority or effect is expected,
- and what class of uncertainty remains.

Helm should keep translating that into product language:
- route cards,
- rehearsal cards,
- diff cards,
- and compact receipts.

## What Schell adds to the picture

### 1. Packet-and-witness thinking is still the right shape for shell luxuries

Schell keeps usefully pressuring Helm away from decorative helper UIs and toward compact interactive objects:
- ingress packets,
- selection packets,
- hold cards,
- repair cards,
- route witnesses,
- and restore honesty.

That matters because Helm's most attractive new luxuries should still feel like shell truth, not ornament.

### 2. Session lineage pressures Helm toward activity-level front doors

Schell keeps naming lineage, review basis, restored-vs-live truth, and attach/resume posture as first-class concerns.
That pressure now combines well with current outside research.
A promising Helm move is an **activity cockpit card**:
- one shell-owned front door for a named activity,
- live state at the top,
- capsule relation and diff nearby,
- layout template relation nearby,
- outstanding jobs / transfers / grants / denials visible,
- and compact next-action / route cards available.

This looks like a way to make Helm feel remarkably coherent without inventing a new pillar.

### 3. Shell-facing exactness should still stay narrower than full Schell freeze

Schell is still in design phase.
That means Helm should continue to steal:
- packets,
- witnesses,
- lineage,
- restore honesty,
- and reviewed-action posture,
but should still refuse to freeze:
- final shell syntax,
- final remote posture,
- or final attach/resume language.

## What DelayBasin usefully pressures here

DelayBasin's lesson is not product doctrine.
It is continuation discipline.
For this pass it suggests:
- make the imported lesson explicit,
- admit one bounded freeze only when it reduces drift,
- add one candidate move with a sharp question and followthrough,
- and keep the archive honest about what is still provisional.

That is exactly the right scale here.

## What now looks worth doing in Helm

### Worth freezing now

- **request-vs-live truth posture** as a narrow cross-cutting rule

Why now:
- it sharpens multiple pillars at once,
- it is strongly justified by SlopOS,
- and it reduces a real future drift risk: rich cards that accidentally lie.

### Worth adding as candidate pressure now

- **activity cockpit cards**

Why this now looks unusually strong:
- current tools keep proving that users want fast return to a task-shaped arrangement,
- Helm already has capsules, layout templates, route cards, and operations truth nearby,
- and Schell pressure suggests that activities should have a compact shell-owned front door rather than scattering their truth across six places.

## What Helm should explicitly not take

- SlopOS archive mass as a default archive style for every Helm seam
- a giant global request-state ontology before one compact posture and one specimen exist
- helper-suite behavior that hides provider, route, or rebinding truth
- app-dashboard culture that makes “activity cockpit” mean arbitrary embedded app views instead of shell truth
- shell-local attention/progress cues standing in for durable receipts or current-live status

## Current bounded take

A useful new Helm rule is:

**when Helm adds rich cards, restore views, or status surfaces, it should distinguish requested truth, admitted truth, live truth, and historical truth rather than flattering them into one success-shaped story.**

And a useful new candidate move is:

**activity cockpit cards as shell-owned front doors that combine live activity state, capsule relation, layout relation, route affordances, and receipts without becoming a new pillar or a helper-suite dashboard religion.**
