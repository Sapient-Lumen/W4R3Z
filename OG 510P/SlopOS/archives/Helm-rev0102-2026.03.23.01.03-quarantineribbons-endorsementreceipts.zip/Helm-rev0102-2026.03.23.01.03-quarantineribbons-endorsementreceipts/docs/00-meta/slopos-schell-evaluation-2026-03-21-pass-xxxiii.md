# SlopOS / Schell evaluation — 2026-03-21 pass XXXIII

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on one sharper seam:

**if Helm already has bounded landing choice sets and durable slot verdicts,
what should it learn from SlopOS about tiny bounded projection witnesses,
and what should it learn about repeated operator choices that are still explicit rather than hidden policy?**

## 1) SlopOS keeps teaching that projections should be tiny,
## deterministic,
## and non-authoritative

The strongest local teacher in this pass was `state-projection-schema-v0.md`.
CH-SPROJ is a tiny bounded non-authoritative snapshot.
It exists to make post-action state compareable without turning the system into a giant debug dump.
That is exactly the kind of datacube lesson Helm should keep stealing.

Helm now has arrival overlays,
landing rehearsals,
and arrival choice sets.
Those are useful,
but they are still larger surfaces.
The missing small sibling is a compact witness that says:

- which exact slot or candidate this is
- which basis it reflects
- what locality tier it lives in
- what classes are exact,
omitted,
or locally filled
- and what next action is available

That makes **projection cards** feel like a very natural Helm import from SlopOS's projection discipline.

## 2) SlopOS also keeps teaching that set-valued evaluation should not become hidden winner policy

`namecert-selection-boundary-v0.md` still matters here.
It keeps evaluation set-valued and refuses silent winner rules.
That posture should continue to govern Helm.
A projection card may summarize a candidate.
An arrival choice set may group candidates.
But neither should silently choose among them.

This is why a projection card is helpful:
it can make one candidate legible without pretending it has already won.

## 3) Explicit repeated choice is acceptable,
## hidden repeated choice is not

This pass also sharpened a different SlopOS lesson.
Across the archive,
SlopOS repeatedly allows explicit constructor inputs,
explicit per-slot materialization,
and explicit profile-limited defaults,
while refusing hidden follow-the-head or “probably this” behavior.
That does **not** mean every repeated choice must require identical manual work forever.
It means the shell must not hide the rule.

That is why **verdict macros** now seem plausible.
A verdict macro would not be a background resolver.
It would be an explicit,
operator-visible,
bounded repeated-choice helper over an already named slot class or match grade.
The operator is still choosing the macro,
and the macro is still constrained by slot verdict law.

## 4) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- arrival choice sets and slot verdict ledgers still look right
- add **projection cards** so bounded projections become easier to inspect and compare without creating giant landing theater
- add **verdict macros** so repeated low-risk slot verdicts can stay explicit,
  bounded,
  and inspectable

## 5) What still does not seem worth taking

- not a global ranking engine
- not hidden winner rules dressed up as convenience
- not giant import policy automation
- not a universal sync constitution
- not a new pillar

## 6) Current judgment

The most important lesson from this pass is:

**Helm gets better when it makes compare smaller and choice more explicit.
Projection cards make one candidate or slot legible without overgrowing the UI,
and verdict macros let repeated choices stay honest without turning the shell back into hidden policy folklore.**

That feels strong enough for two new candidate contracts,
and still not strong enough for a new pillar or a new freeze.
