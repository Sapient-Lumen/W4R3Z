# SlopOS / Schell evaluation — 2026-03-22 pass XXI

Purpose: continue evaluating what SlopOS's datacube is actually teaching Helm now that projection surfaces,
view decks,
materialization bays,
live lenses,
and surface locality tiers are already in play.

This pass focused on a narrower question:

**what should Helm learn about saved derived views,
change awareness,
and explicit materialization without mistaking any of them for live truth?**

## 1) CH-SPROJ still teaches the right kind of change surface

`state-projection-schema-v0.md` keeps doing something very important for Helm.
It frames projection as:

- bounded,
- deterministic,
- keyed,
- digest-friendly,
- and non-authoritative.

That is already why it has been such a good teacher for Helm's projection-surface law.
But this pass makes one more implication feel stronger:

**change surfaces should be bounded projections too.**

A useful change cue should not require a universal timeline,
a universal event bus,
or a fake omniscient cube.
It can instead be:

- one exact subject,
- one exact compared basis,
- one bounded change summary,
- and one inspect path to stronger evidence.

That is the right pressure behind a Helm **drift beacon**.

## 2) Request-state posture keeps teaching the difference between reviewable history and live mutable truth

SlopOS is full of request-state honesty surfaces:
job requests,
background requests,
notifications,
timeproof requests,
and ACP acceptance/completion posture all keep repeating the same lesson.

A stable request id,
receipt,
or remembered action trail is useful.
But it is not current provider-owned live truth.

That lesson matters even more now that Helm is warming toward change-aware surfaces.
A drift beacon should not become:

- a live authority surface,
- a durable approval cache,
- or a hidden watcher that claims current state just because it remembers a prior basis.

It should remain a bounded shell-owned answer to a narrower question:

**what changed since the exact basis we named?**

## 3) View replication boundary is the best teacher for saved views and recipes

`view-replication-boundary-v0.md` may be the single clearest teacher for this pass.
Its refusal is elegant and brutal:

replicated view information may exist,
but it does not auto-activate local bindings.

That maps almost directly onto Helm's next warm move.
A saved deck or deck recipe may travel.
A shared view object may travel.
A copied trail may travel.
But none of that should silently count as:

- active local binding,
- active local liveness,
- or current local continuity already reacquired.

That is exactly why **deck recipes** feel better than overclaiming decks themselves.
The recipe is the repeatable arrangement intent.
The materialized deck is the current derived local surface.
And neither one is the underlying live authority.

## 4) AttrFS teaches that saved query power should stay shell-owned and explicit

`attrfs-posture-v0.md` remains very valuable because it keeps saved-query persistence shell-owned,
view-bound,
and distinct from ambient application-visible inventory or hidden watch services.

That is almost a direct design lesson for Helm:

- saved derived view recipes should stay shell-owned,
- bound to exact subject family / activity relation / query basis,
- and materialized explicitly,
- rather than turning into ambient app-facing global saved-search folklore.

So if Helm wants a recipe move,
it should probably be a typed shell recipe,
not a vague embedded-app dashboard system.

## 5) OpenURI materialization boundary keeps the second-workflow lesson sharp

`openuri-materialization-boundary-v0.md` still matters here because it refuses a subtle lie:

successful open does not imply durable local object identity.

That refusal is useful far beyond URI launch.
It reinforces the general Helm lesson that:

- recipe is not materialization,
- saved view is not active binding,
- preview is not open,
- candidate work is not adopted truth,
- and change awareness is not current authority.

This is why Helm keeps benefitting from explicit seams:
projection,
materialization,
adoption,
and now drift/change witness.

## 6) The datacube lesson is getting sharper, not larger

This pass makes me even less interested in a giant cube UI.
The valuable datacube lesson is now sharper:

- explicit projections,
- explicit view objects,
- explicit locality,
- explicit materialization,
- and explicit compared-basis change signals.

That is a much more precise teacher than "build a cube."

## 7) Strongest Helm payoffs from this pass

### Drift beacons

A drift beacon looks like one of the cleanest next luxuries for Helm because it could help:

- adoption harbor cards,
- basis packets,
- view decks,
- Recall returns,
- exact trails,
- and activity entry kits

say whether the operator's remembered or reviewed basis still matches.

The most promising first cut still looks modest:

- one exact subject,
- one exact compared basis,
- one bounded change summary,
- inspect / compare / review-again,
- no auto-approval or hidden mutation.

### Deck recipes

A deck recipe now looks like the right way to preserve the best of saved views,
templates,
and reusable view clusters without making decks themselves overclaim.

The recipe is the repeatable starter.
The materialized deck is the current derived cluster.
The stronger truth remains elsewhere.

That is a very SlopOS-compatible shape.

## What this pass changes

- it adds **drift beacons** as a new warm Helm move
- it adds **deck recipes** as a new warm Helm move
- it strengthens the reading of SlopOS's datacube as a teacher of **projection + locality + materialization + change-awareness**
- it keeps live lenses,
  view decks,
  and materialization bays warm,
  but now with sharper support from saved-view and compared-basis discipline

## What this pass still does not justify

- a giant omniscient cube UI
- a universal timeline constitution
- auto-activated shared decks or shared bindings
- templates or recipes that claim live continuity
- adding more pillars

## Current bounded take

**Helm should keep reading SlopOS's datacube as a teacher of bounded projections,
explicit view objects,
explicit locality,
explicit materialization,
and now explicit compared-basis change signals.
That pushes Helm toward drift beacons and deck recipes without justifying a giant cube,
universal sync,
or fake continuity theater.**
