# Web research synthesis — 2026-03-22 — pass XL

Purpose: keep collecting brilliant Helm ideas while testing one newer pressure that keeps recurring across current tools:

**saved structure, stable review slices, and live instances should stay visibly different forms.**

This pass focused on one question:

**what shell law would let Helm make saved views, checkpoints, launch recipes, and compare flows feel powerful without flattening them into one fake continuity story?**

## Main takeaway

Helm increasingly wants a simple cross-cutting law:

1. **recipe / definition**
2. **ticket / snapshot / stable review slice**
3. **live instance / current lane**

Current tools keep separating these three forms even when the UI makes them feel adjacent.

That suggests two practical moves for Helm:

- treat the **three-form law** as a shell-wide design discipline
- warm one compact **review ticket** object for longer compare, paging, handoff, and inspect-before-commit flows

This does **not** mean every result family needs tickets.
It does mean Helm should stop forcing long review flows to hover over live-shifting truth.

## What the outside world is validating now

### 1. Notion is strongly validating “view object” versus “query run”

Notion's current API now makes views first-class resources,
but it also treats a query run as a separate thing:
the view query returns a `query_id`,
backs it with a cached result set,
and gives it an expiration window.

That is one of the clearest current proofs that Helm should distinguish:

- **saved view object**
- **review/result ticket**
- **live subject**

The stealable law is not merely “queries can cache.”
It is that **a durable definition and a bounded review slice are different shell truths**.

### 2. VS Code is validating profiles, checkpoints, restore, and fork as separate forms

VS Code profiles continue to validate saveable setup as an explicit object.
Checkpoint docs make rollback an explicit snapshot-bearing move.
Chat sessions can also be forked from the whole session or from a checkpoint.

That combination keeps reinforcing the same law:

- saved configuration is not a live instance
- a checkpoint is not the current lane
- and a fork is not the same thing as restore

That maps directly to Helm.

### 3. Warp and PowerToys are validating launch recipes rather than fake continuity

Warp separates launch configurations,
session navigation,
and session restoration.
PowerToys Workspaces lets users capture app positions/configurations and relaunch them later with one click.

Both are useful because they stay honest:
they are **recipes** or **saved launch structures**,
not proof that the previous live arrangement still exists.

That is strong pressure for Helm's launch ladders,
deck recipes,
saved view objects,
and future activity-entry objects.

### 4. Chrome Tab Groups and Obsidian show the value of saved grouping without pretending it is still live

Chrome's current help docs distinguish open groups,
closed-but-saved groups that can be reopened,
and deleted groups that disappear across synced devices.
Obsidian distinguishes saved workspaces from the current mutable workspace layout on disk.

Again the same pattern appears:

- saved grouping/layout is useful
- reopen is useful
- sync/share is useful
- but **the saved structure is not the same as the current live instance**

### 5. Figma keeps validating snapshots, branches, compare, and merge as separate things

Figma version history gives explicit historical checkpoints.
Branching creates controlled side paths.
Review/merge flows compare branch changes against the main file,
and reviewers can inspect changes side-by-side or as an overlay before merge.

That is almost a perfect teacher for Helm's checkpoint branches and arrival overlays:
**history, branch, compare, and merge/adopt should stay separate verbs over separate forms.**

## Great ideas worth stealing now

### Tier 1 — steal now

1. **A shell-wide three-form law**
   - recipe/definition
   - ticket/snapshot/stable review slice
   - live instance/current lane

2. **Review tickets**
   - bounded,
     inspectable,
     expiring or clearly historical review slices for compare,
     paging,
     route review,
     batch action review,
     or handoff

3. **Per-form verbs**
   - recipes can be summonable,
     pinnable,
     published,
     and materialized
   - tickets can be paged,
     compared,
     annotated,
     handed off,
     or branched from where that makes sense
   - live instances can be reentered,
     acted on,
     checkpointed,
     or witnessed

4. **Expiration / freshness honesty**
   - a ticket should say when it was cut,
     what basis it reflects,
     and whether it is still safe for the proposed next act

### Tier 2 — steal soon, but keep the contract modest

1. **Ticket-producing saved views**
2. **Checkpoint compare tickets**
3. **Route review tickets in Exchange**
4. **Materialization-bay promotion from ticket to stronger local truth**

### Tier 3 — keep warm only

1. universal ticket law for every object family
2. giant snapshot museums
3. ambient “latest result” folklore
4. treating saved structures as automatically live just because reopen is convenient

## Judgment for Helm

Helm still should not add a pillar.

The higher-leverage move is to make one new shell distinction explicit:

- **recipe / definition**
- **ticket / snapshot / stable review slice**
- **live instance / current lane**

That law sharpens saved views,
checkpoint branches,
Recall,
Omnibox,
Object Browser,
Exchange,
and preview/materialization ladders all at once.

The most promising next support contract is therefore a compact **review ticket** object.
