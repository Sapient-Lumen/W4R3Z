# Web research synthesis — 2026-03-21 pass XXV

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on a narrower landing problem:

**if Helm gets better at portable cores, local overlays, packets, and publication receipts, what should happen on the receiver side so the shell stays fast without lying?**

## 1) VS Code now strongly validates preview-before-import, scoped sharing, and explicit local fit

VS Code's current profile flow is unusually relevant to Helm.
Profiles can be exported, shared, and imported.
The imported contents are displayed before creation,
people can unselect profile elements,
and the same profile ideas now even support drag-and-drop import.
That is important because it keeps travel explicit and inspectable instead of making a shared setup feel ambient.

Its sync and trust story adds the sharper lesson.
Machine settings are not synchronized by default.
Remote windows do not simply inherit every synced extension.
Merge,
replace,
and manual merge remain visible choices.
Workspace Trust and restricted mode still keep execution-heavy behavior behind a boundary.
Background agents get their own worktrees and then an explicit apply step back into the main workspace.

The stealable law is:

**a portable shell surface should land on a receiver as a visible candidate with a fit story, not as already-applied local truth.**

That is the clearest support yet for a Helm **receiver fit card** and **rebind ladder**.

## 2) Obsidian and WezTerm keep proving that saved structure and active local presence should stay separate

Obsidian is now even clearer than before.
Bases give multiple views over one stronger note/property substrate,
while `.obsidian/workspace.json` and `.obsidian/workspaces.json` remain mutable local layout residue that many people may want to ignore in Git.
That is a strong public example of saved view structure versus highly local mutable presence.

WezTerm reinforces the same principle from a shell/workspace angle.
You can spawn windows into differently named workspaces and they do not become visible until that workspace becomes active.
That means a saved or created workspace can exist without silently counting as current visible truth.

The stealable law is:

**landing is not activation,
and saved structure is not current local presence.**

Helm should lean harder into that distinction whenever packets,
recipes,
keys,
decks,
or entry kits move between tiers.

## 3) Figma and Raycast point to a powerful nearby idea: helpful companions should travel, but stay clearly secondary

Figma Dev Mode does two highly relevant things.
It lets developers compare changes against explicit history,
and it lets components carry external dev resources such as GitHub,
Jira,
Storybook,
and VS Code links that propagate to instances.
Raycast deeplinks and fallback text keep showing how exact action handles can carry parameterized starting context without pretending they are the full receiving environment.

That suggests a nearby Helm move worth keeping warm,
but not freezing yet:

**companion resource bundles**.

A deck recipe,
exact action key,
or handoff packet might carry helpful secondary companions such as docs,
runbooks,
code links,
reference queries,
or tickets.
But those companions should remain obviously secondary and non-authoritative.
They are there to help landing,
not to replace receiver-side fit,
rebind,
or trust.

## 4) Notion and Airtable still validate first-class views and explicit share/sync activity, but they are not reasons to copy a giant collaboration constitution

Notion continues to treat views as first-class resources over one data source,
with each view carrying its own filters,
sorts,
and layout configuration.
Airtable continues to make share-and-sync steps and sync activity explicit rather than ambient.
Those remain good teachers for view decks,
deck recipes,
and publication receipts.

But the thing worth stealing is still the bounded part:

- first-class saved view objects
- explicit audience/share activity
- explicit sync or publication setup
- and inspectable activity after the move

The part **not** worth stealing is a giant product-wide collaboration constitution.
Helm should stay shell-first,
not become “Airtable for everything.”

## 5) Strongest new warm moves from this pass

- **receiver fit cards** — compact shell-owned landing reports for portable cores,
  handoff packets,
  and published surfaces,
  naming what matches,
  what was deliberately omitted,
  what is missing locally,
  and what stronger next moves are safe on this receiver
- **rebind ladders** — explicit shell-owned next steps for attaching a portable surface to local paths,
  providers,
  profiles,
  sessions,
  workspaces,
  placements,
  or activity-local overlays without silent retargeting

## 6) Strongest nearby idea worth keeping warm

- **companion resource bundles** — travel-safe secondary resources such as docs,
  runbooks,
  Storybook,
  GitHub,
  Jira,
  and exact query links that help a packet land well without claiming authority or replacing local fit/rebind

## 7) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- make receiver-side landing more explicit instead of building more publication mythology
- require portable things to arrive with a fit story before they can feel “easy”
- keep companion resources warm,
  but secondary

## Strongest non-takes from this pass

- do not build a universal shared workspace constitution
- do not let imported or shared shell luxuries silently become active local bindings
- do not treat helpful companions as authority,
  liveness,
  or trust
- do not blur fit,
  rebind,
  materialize,
  and adopt into one flattering button
- do not add pillars
