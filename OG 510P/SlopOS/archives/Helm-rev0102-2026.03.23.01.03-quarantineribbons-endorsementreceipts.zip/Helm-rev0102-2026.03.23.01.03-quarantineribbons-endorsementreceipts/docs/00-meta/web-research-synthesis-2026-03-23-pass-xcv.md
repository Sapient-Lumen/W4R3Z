# Web research synthesis — pass XCV — 2026-03-23

## Headline

The current outside pressure says Helm should add a small **fresh-intent grammar**.
The main lesson is not merely “ask permission.”
It is:

**tie certain strong acts to a fresh user-intent window,
let some of those acts consume that window,
and keep the most sensitive ones bound to the direct gesture lane itself.**

## Strongest outside patterns

### 1. HTML user activation: not all permission is equal

The HTML Standard distinguishes:
- **sticky activation**,
- **transient activation**,
- and **transient-activation-consuming** APIs.

That is a remarkably good design lesson.
A system can admit that:
- some capabilities only need “the user has interacted here at least once,”
- some need “the user just did something,”
- and some should **spend** that recent intent so it cannot be replayed repeatedly.

### 2. The web platform uses transient activation for many genuinely strong acts

MDN's user-activation guidance now lists a wide spread of powerful or sensitive actions that require transient activation,
including clipboard access,
full screen,
screen capture,
share,
payment,
serial / HID / USB requests,
and file pickers.

That is exactly the kind of durable pattern Helm should steal:
**fresh intent is a real security and anti-spook boundary,
not just browser trivia.**

### 3. File pickers and share are strong precisely because they are chooser-bound and gesture-bound

`showOpenFilePicker()` and the Web Share API both require transient user activation.
That means the chooser surface and the permission to invoke it remain tightly coupled to a direct act.
Helm should want the same thing for strong shell-owned reveals,
exports,
routes,
and wide-scope asks.

### 4. Screen capture shows that some acts should not be reusable at all

`getDisplayMedia()` requires transient activation,
and the Captured Surface Control work goes even further:
it says some follow-on controls should be limited to the moment when the user agent is dispatching the interaction event itself.
That is a very strong hint for Helm.
Some shell acts are sensitive enough that even a short reusable “spark” is too generous;
they should require a **direct-gesture gate**.

### 5. Payment Request says the quiet part out loud

The Payment Request spec explicitly warns that not requiring user activation increases the risk of spam and clickjacking attacks.
That is not just payment advice.
It is a shell law:
if a strong act can be surfaced away from the user's immediate action,
the system becomes easier to spoof,
spam,
and socially route into the wrong outcome.

## What this means for Helm

Helm should probably warm two shell-owned objects:

### Intent sparks
A compact shell-owned fresh-intent witness that can say:
- which trusted shell surface originated the act
- which exact target or cohort the gesture was about
- when the spark began
- whether it is still live
- whether use is single-spend or multi-use within the window
- and whether any later act is running on a still-live spark or on historical residue only

### Direct-gesture gates
A stricter shell-owned gate for especially sensitive acts where even an unexpired spark is not enough.
The act must happen inside the direct host-owned gesture lane,
not after queueing,
relay,
or helper laundering.

## What not to steal

Do not steal:
- giant permission bureaucracy for every tiny click,
- annoying prompt spam,
- fake precise timers exposed as user-facing clutter,
- or a myth that every act needs the same strength of fresh intent.

## Main judgment

This is worth warming now.
It gives Helm a humane answer to one subtle but expensive failure mode:
**old intent should not silently spend as if it were fresh intent,
and fresh intent should sometimes be one-shot or direct-only.**
