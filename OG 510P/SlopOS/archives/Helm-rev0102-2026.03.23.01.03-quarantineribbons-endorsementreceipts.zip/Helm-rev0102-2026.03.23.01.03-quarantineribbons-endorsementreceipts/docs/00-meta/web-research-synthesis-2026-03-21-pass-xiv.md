# Web research synthesis — 2026-03-21 — pass XIV

Purpose: keep harvesting brilliant ideas for Helm while staying disciplined about what belongs in a pillar, what belongs in a cross-pillar move catalog, and what should remain shell-local acceleration until the proof slices earn more.

This pass focuses on four questions:

1. what do current tools teach about preview and launch without overclaiming continuity,
2. how do good tools keep long-running context anchored and legible,
3. what host-owned status/progress surfaces are worth stealing,
4. and which of those ideas pressure Helm's pillars rather than replacing them.

## Cluster 1 — preview becomes much better when it sits next to bounded action

### What current tools teach

Apple's Finder preview pane and Quick Actions keep proving that **preview next to a few bounded actions** is more useful than either a tooltip or a full open-first workflow.
Quick Look still matters for the same reason: inspect first, commit later.
Raycast's new Windows Quick Look support reinforces that instant preview remains a live need rather than a nostalgic Mac-only trick.

### What Helm should steal

- a shell-owned **preview lane** that can appear in Object Browser, Omnibox, Recall, Exchange, and Operations Center
- preview-adjacent bounded actions instead of forcing a full open first
- metadata and source labels near the preview rather than hidden in a side panel

### What Helm should refuse

- preview that silently counts as open/import/run
- app-local preview plugin clutter standing in for shell-wide power
- thumbnail theater that forgets route, subject, or provenance

## Cluster 2 — launch structures are useful when they stay honest about freshness and reuse

### What current tools teach

Warp's Launch Configurations make saved windows/tabs/panes convenient.
WezTerm's launcher menu and domains show the value of quick local spawn/attach choices.
Warp workflows and environment-selection flows show that saved entry artifacts become far more useful when they can still ask one last narrow question instead of pretending they are already live state.

The shared lesson is:

**saved entry objects should present an honest ladder, not a flattering certainty.**

### What Helm should steal

- **launch ladders** with clear steps like inspect, fresh launch, attach, reuse, repaired return, historical replay, or hold
- entry objects that can remember likely destinations or environment choices without overclaiming continuity
- compact selection of profile/domain/environment when that choice really matters

### What Helm should refuse

- treating launch configurations as proof that the old task is still live
- silently inheriting remote/profile/account/window choice from nearby context
- letting generic launch grow one more “new tab / reuse window / new instance” folklore flag at a time

## Cluster 3 — sticky context cues are most useful when they anchor source, not just scroll position

### What current tools teach

VS Code's terminal sticky scroll keeps output visibly tied to the command that produced it.
Warp's agent modality keeps shell commands and agent conversations visually distinct rather than letting them blur into one mode.
The best lesson is not “copy sticky scroll.”
The lesson is:

**long-lived or distant content gets dramatically more trustworthy when a small anchored strip reminds you what produced it, in which source lane, and what kind of action is still valid.**

### What Helm should steal

- **sticky context strips** that can anchor output, receipts, flow status, or long-lived views to their originating subject/action/source
- source-labeled separation between operator command lanes, delegated/proposed lanes, and historical receipts
- expandable anchor strips that stay tiny until the user asks for more detail

### What Helm should refuse

- sticky approval folklore where an old anchor strip keeps stronger action valid by vibes alone
- one undifferentiated history rail where operator, delegated, imported, and historical material all look the same
- terminal-local anchors pretending to be the whole desktop's continuity model

## Cluster 4 — provider-hosted status and progress can make shell surfaces feel much more alive

### What current tools teach

PowerToys' Command Palette toolkit now exposes host-visible status and progress concepts.
That matters because it suggests a launcher/action surface can still show durable host-owned state instead of dumping everything into provider-specific rendering.
Node-RED's reusable fragments and status-bearing nodes point the same way for Flow.

The lesson is:

**status and progress should belong to the host surface whenever the host is the thing making trust claims.**

### What Helm should steal

- host-owned progress / hold / failure / status rows in Omnibox and Operations Center
- status-bearing Flow fragments and provider actions
- compact, inspectable progress surfaces instead of giant bespoke provider UIs

### What Helm should refuse

- providers that become little hidden apps the shell cannot inspect
- progress that exists only inside a provider's private renderer
- host shells claiming readiness or success without a durable status witness

## Cluster 5 — derived live views are great when provenance stays obvious

### What current tools teach

PowerToys Crop And Lock remains one of the clearest current examples of useful live derivative surfaces.
GNOME's Activities Overview still proves the value of live thumbnails plus type-to-search.
The combination suggests that Helm should keep live derivative views warm, but only with strong provenance.

### What Helm should steal

- live lenses / mirrored surfaces with clear provenance
- overview with live thumbnails and quick return/search
- shell-owned derivative views that remain visibly weaker than the source

### What Helm should refuse

- hidden capture-channel backdoors
- mirrored surfaces pretending to be independent sources
- overview becoming decorative theater disconnected from shell truth

## Brilliant ideas worth carrying forward right now

These currently look especially worth keeping warm:

- **launch ladders** for honest saved entry objects
- **sticky context strips** for long-lived source anchors
- **preview-adjacent bounded actions**
- **host-owned status/progress surfaces**
- **live lenses with provenance**
- **exact-object recency** with strong source labels
- **reusable flow fragments** with visible status
- **private scratch / forget-rail pressure** as a shell-facing lesson to keep warm without over-importing it into Helm too early

## Pass-XIV bounded take

The strongest outside ideas in this pass still do **not** argue for more pillars.
They argue for fleshing out the pillars with better cross-pillar shell moves:

- sharpen Object Browser around preview-adjacent actions,
- sharpen Omnibox and Recall around honest launch ladders,
- sharpen Operations Center and Desktop Flow around host-owned status/progress and anchored context,
- keep live lenses and retention humility warm,
- and continue refusing fake continuity, hidden source blending, silent placement folklore, and provider-shaped mini-app sprawl
