# Web research synthesis — 2026-03-21 — pass XI

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on one sharper question:

**what do current systems teach about delegated or background work that should help without silently taking over the live lane?**

The answer is again unusually coherent across different systems:
good systems increasingly isolate delegated work,
keep it reviewable,
and make promotion or apply moments explicit.
They do not treat helpful background work as permission to mutate the current authoritative surface invisibly.

That points Helm toward two outcomes:
- freeze **delegated-adoption truth** narrowly,
- and add **shadow work lanes** as a candidate move.

## Cluster 1 — modern coding agents isolate background work on purpose

### What current systems teach

VS Code now makes this pattern unusually explicit.
Its agent tutorial says background agents can use Git worktrees to isolate file changes from the main workspace and prevent conflicts.
Its security docs say background agents work in a separate Git worktree and have limited tool access.
The November 2025 release notes go further: a background agent can create a new worktree for the session,
isolate its changes there,
and then let the operator review and merge or directly apply those changes back into the main workspace.

That is an excellent direct teacher for Helm:
**powerful delegated work becomes more trustworthy when it happens in a separate lane first and only later crosses an adoption surface.**

### What Helm should steal

Helm should steal:
- isolated mutable side lanes for delegated work,
- explicit apply/adopt moments,
- and the feeling that the live lane remains stable until the operator says otherwise.

### What Helm should refuse

- background help that writes directly into the active lane and only explains afterward
- a belief that good intentions or smooth UX erase the need for isolation
- hidden helper state that becomes authoritative just because it is nearby

## Cluster 2 — branch and pull-request workflows keep promotion explicit

### What current systems teach

Git itself treats multiple working trees as distinct checked-out working states attached to one repository rather than one blended surface.
VS Code's Copilot coding-agent docs say delegated work can create a branch and open a pull request for review.
That is not merely a source-control detail.
It is a product lesson:
when another actor does meaningful mutable work,
there is value in preserving a reviewable candidate lane before it becomes the main story.

### What Helm should steal

Helm should steal:
- candidate-vs-authoritative separation,
- clear promotion/adoption boundaries,
- and lightweight reviewable side lanes for nontrivial delegated work.

### What Helm should refuse

- a shell that flatters delegated work by pretending it was always part of the operator's live lane
- giant PR theater for tiny local moves,
  but also direct mutation for every meaningful delegated repair

## Cluster 3 — explicit conflicts and force paths still matter after isolation

### What current systems teach

Kubernetes Server-Side Apply tracks managed fields and raises conflicts when another manager owns a field.
A force path exists,
but it is explicit and transfers ownership rather than hiding the takeover.
That matters here because isolation alone is not enough.
Eventually a candidate lane wants to land.
At that moment,
conflict and ownership truth still matter.

### What Helm should steal

Helm should steal:
- explicit ownership conflict stories,
- visible force / override posture,
- and a refusal to pretend candidate adoption is conflict-free when another actor already owns part of the basis.

### What Helm should refuse

- isolated helper lanes that still auto-merge into the live lane
- vague “updated for you” wording where real ownership conflict existed
- giant field algebra before one compact adoption surface exists

## Cluster 4 — conditional updates show the right apply posture for adoption

### What current systems teach

HTTP `If-Match` remains a beautiful tiny teacher.
A write only proceeds when the resource still matches the expected ETag;
otherwise the server returns `412 Precondition Failed`.
That is the right shape for shadow-lane adoption too:
review and candidate work can happen,
but adoption should still compare against the expected live basis before it lands.

### What Helm should steal

Helm should steal:
- tiny compare-and-adopt semantics,
- visible mismatch instead of silent overwrite,
- and `match / drifted / hold` language that works on adoption surfaces too.

### What Helm should refuse

- “apply anyway” as the default tone for candidate landing
- candidate lanes that become magic because the user already spent time in them

## Cluster 5 — explicit review after background help is becoming normal

### What current systems teach

VS Code's agent flow,
GitHub-style pull-request review,
and current coding-agent integrations all reinforce one broader lesson:
background help is becoming more powerful,
but mature tools still keep review,
apply,
merge,
or adoption moments visible.
That is not bureaucracy.
It is how the tool stays trustworthy as its automation gets stronger.

### What Helm should steal

Helm should steal:
- delegated work that feels magical because it is contained,
- compact review/apply surfaces,
- and clear adoption language instead of pretending the live lane never changed owners.

### What Helm should refuse

- assistant-rich continuity surfaces that blur proposal,
  execution,
  and adoption into one glossy action path
- smooth helper UX that quietly bypasses shell truth

## Pass-XI bounded take

The current external idea harvest most strongly supports two Helm moves:
- freeze delegated-adoption truth narrowly,
- and explore shadow work lanes as compact shell-owned isolated mutable lanes with adoption cards rather than silent live-lane mutation.
