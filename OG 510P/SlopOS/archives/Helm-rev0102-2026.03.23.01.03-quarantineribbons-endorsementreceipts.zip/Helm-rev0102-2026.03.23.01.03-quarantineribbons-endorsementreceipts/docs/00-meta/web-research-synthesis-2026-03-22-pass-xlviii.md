# Web research synthesis — 2026-03-22 — pass XLVIII

Purpose: look for the next compact Helm move after explicit current context and explicit output claim posture,
and ask what current tools say about **exact proposed change**, **review posture**, and **approval on mutable basis**.

## Main takeaway

The strongest outside pressure now says Helm should not stop at:
- explicit selected context,
- explicit contribution truth,
- and explicit claim posture.

It also needs one honest shell-owned answer to:

**what exact change am I being asked to approve or adopt right now?**

That object should likely be an **action warrant**.

And because proposed changes sit on mutable basis,
Helm likely also needs a small adjacent surface for:

**does this warrant still bind the thing I reviewed, or did the basis drift?**

That second surface should likely be a **drift gate**.

## What current products keep validating

### 1. Proposed changes increasingly travel through explicit review objects, not invisible in-place mutation

GitHub Copilot coding agent does not just “make the change in your repo.”
It opens a pull request,
adds you as a reviewer when it finishes,
and expects review before merge.
GitHub's docs also say a user's approval on a PR created by Copilot does not count toward required review approvals,
which is a very strong public hint that agent-made change and merge-ready approval are different strengths.

This is close to a Helm-shaped law:
**agent proposal is not merge authority.**

### 2. Good action UX now separates proposal, apply, settings, and undo

Gemini in Google Sheets now produces an **Action preview card**,
then requires **Apply**,
and keeps nearby **Settings** and **Undo** when the action completes.
That is much better than pretending natural-language action is already done merely because the request sounded plausible.

It suggests a Helm pattern:
- exact proposed effect,
- reviewable card,
- explicit apply,
- nearby configure/undo,
- and no flattening of proposal into fact.

### 3. Stable review slices are useful, but they should not be timeless

Notion's view-query model executes a saved view's filters and sorts,
caches the full result set,
and returns a `query_id` with an expiration time.
The result slice is stable enough to page and inspect,
but the system still refuses to pretend it stays evergreen.

That is a strong reminder for Helm:
reviewable slices are real,
but they should carry time and basis posture.

### 4. Exact rollback and exact batch revert are becoming first-class review powers

VS Code checkpoints let users restore a workspace to a specific point in a chat conversation,
and the docs explicitly say edits to a previous request revert changes made by that request and subsequent requests before resending the edited prompt.
The same docs also let users inspect which files changed at a checkpoint.

That reinforces a Helm law:
**a reviewed change should be tied to one exact batch and one inspectable affected-set story.**

### 5. Loaded context and loaded customizations are increasingly expected to be visible

VS Code's Agent Debug panel shows which prompt files,
skills,
hooks,
and other customizations are loaded for a session.
OpenAI Projects now lets users add explicit project sources from Slack and Google Drive links.
These are strong signals that current tools are moving away from ambient mystery context.

That matters for action warrants too:
if Helm asks for approval,
it should be able to say not only the proposed effect,
but also the exact context and customizations the warrant rested on.

### 6. Running privileged follow-on automation often requires an extra stronger approval

GitHub's coding-agent docs warn that Actions workflows can be privileged and may have access to secrets,
and provide an explicit **Approve and run workflows** path.
That is exactly the kind of separate strength Helm should steal.

A proposed change may be acceptable for inspection,
acceptable for adoption,
or acceptable for privileged follow-on execution —
and those do not need to be the same rung.

## What to steal now

1. **Review object over vague suggestion blob**
   - Copilot PRs and Sheets action preview cards both validate this.

2. **Separate effect preview from privileged follow-on approval**
   - “approve change” and “approve workflow/secret-bearing execution” should often be different strengths.

3. **Exact batch / exact affected-set visibility**
   - checkpoint file lists and PR diffs both point here.

4. **Expiry / drift posture on stable review slices**
   - Notion's query expiry is a useful model.

5. **Context and customization witness near approval**
   - loaded prompt files, hooks, skills, and explicit project sources make ambient context less acceptable.

## What not to steal

- do not make every action go through giant PR theater
- do not let one green badge collapse inspect/adopt/run into one rung
- do not let old preview cards stay silently valid after mutable basis drift
- do not hide privileged follow-on automation behind an ordinary-looking Apply button
- do not build a giant workflow product before one tiny warrant works

## Judgment for Helm

The next compact support move worth defining is:
- **action warrants** — exact proposed changes with exact effect and basis posture
- **drift gates** — compact gates that say whether the warrant still matches the mutable thing reviewed,
  or has downgraded to review-again / hold / inspect-only

This looks more valuable now than adding another pillar,
because it strengthens Omnibox,
Object Browser,
Recall,
Exchange,
Desktop Flow,
and AI-assisted shell actions all at once.
