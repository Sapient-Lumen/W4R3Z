# Web research synthesis — 2026-03-22 — pass LII

Question for this pass:
**what do current tools teach Helm about revocation, narrowing, self-surrender, and post-grant control once authority windows already exist — and what should Helm steal without drifting into giant permission-center religion?**

## Main takeaway

The strongest outside pattern is not just “grant with better rungs.”
It is:

**make de-escalation and revocation first-class.**

The best products increasingly distinguish between:
- a temporary grant,
- a narrower grant,
- a persistent grant,
- a per-item revoke,
- a global revoke,
- and a session or command allowlist that can still explicitly block specific dangerous moves.

For Helm, that points toward two compact shell moves:
- **revoke handles**
- **attenuation ladders**

## What the current tools are teaching

### 1. Good systems do not treat revocation as a hidden settings chore

Chrome’s extension site-access UX keeps three visibly different rungs: **when you select the extension**, **on the current site**, and **on all sites**.
That is already an attenuation ladder.
Chrome’s `activeTab` permission is even cleaner: access is tied to explicit invocation and is revoked when the user navigates away or closes the tab.
Chrome’s persistent File System Access work also shows that revocation should happen at more than one grain: users can revoke access for one exact file or folder, or revoke broader access for the site more generally.

The lesson for Helm is strong:
**a live grant should keep nearby narrower and revoke paths, not just an audit trail.**

### 2. Modern agent tools are admitting that auto-approval needs counterweights

VS Code’s Copilot CLI sessions now make the isolation split explicit: worktree isolation gets auto-approved tool calls, while workspace isolation exposes permission levels like **Default Approvals**, **Bypass Approvals**, and **Autopilot**.
VS Code also lets operators explicitly auto-approve some terminal commands while always requiring approval for others, and it warns that auto-approval rules are best-effort and weaker than sandboxing.
The security docs add one more critical detail: even automatically approved actions still surface notifications and warning banners, and sandboxing is treated as the stronger protection.

The lesson for Helm is not “more auto-approve.”
It is:
**grant broad room only where isolation earns it, and keep explicit ways to narrow or refuse specific dangerous subfamilies even inside a broader approval posture.**

### 3. Some of the best current systems let software surrender power, not just ask for more

Android keeps teaching this unusually well.
Android 11 introduced **Only this time** permissions and auto-reset for unused apps.
The current runtime-permissions docs go further: on Android 13 and higher, apps can proactively remove their own access using `revokeSelfPermissionOnKill()` or `revokeSelfPermissionsOnKill()`.

That is a very Helm-shaped lesson:
**software should be able to narrow or surrender stale authority on purpose, not only wait for the operator to find the right settings page later.**

### 4. Real revocation often has partial edges, and Helm should tell the truth about them

GitHub’s PAT docs are a good warning here.
Organization owners can review and revoke fine-grained personal access tokens, but revocation does not imply universal erasure of every adjacent power: SSH keys created by the token keep working, and revoked tokens can still read public resources in the organization.
Enterprise PAT policies also show that maximum lifetimes are part of the control surface, not an implementation footnote.

The lesson for Helm is subtle but important:
**revoke must say what actually went away and what did not.**
A revoke handle should not flatter the operator with “all gone” if the truth is “this family is gone, public read remains, and an adjacent side credential still exists.”

### 5. Source and project systems keep validating explicit access moments, but they are still weak on nearby de-escalation

ChatGPT Projects now makes source addition from Slack and Google Drive very lightweight, but it still includes an explicit connect-and-approve step.
That validates the front side of Helm’s authority ladder.
What is still mostly missing in current tools is a shell-like nearby way to narrow, suspend, or revoke those source grants from the same working context.
That gap is exactly where Helm can be better.

## What Helm should steal now

### Steal directly

1. **Per-item revoke versus general revoke**
   - Chrome’s File System Access work validates both grains.

2. **Auto-expiry and auto-reset as normal, not exotic**
   - `activeTab` and Android unused-app reset both validate this.

3. **Explicit allowlists and blocklists inside broader approval posture**
   - VS Code’s terminal auto-approval settings validate that a broad mode can still keep sharp local no-go rules.

4. **Isolation earns room**
   - VS Code’s worktree isolation remains one of the best current proofs.

5. **Software may surrender stale authority**
   - Android’s self-revoke APIs are a quietly brilliant precedent.

### Do not steal whole

1. **giant permission-center religion**
2. **sticky auto-approve that users can’t see from the work surface**
3. **revocation that overclaims total erasure**
4. **broad persistent grants as the default optimistic answer**
5. **best-effort allowlists presented as stronger than isolation**

## Why this matters for Helm specifically

Helm now has:
- action warrants,
- drift gates,
- effect receipts,
- reversal warrants,
- repair ladders,
- authority windows,
- and grant-rung ladders.

That stack is good enough that the next gap is obvious:
**once a grant is live, where is the exact handle to narrow or revoke it, and how do we keep the safer nearby alternatives visible?**

That is what revoke handles and attenuation ladders are for.

## Why this is super-awesome material

This is the kind of move that could make Helm feel unusually humane.
A user should be able to:
- drop a live-lane grant down to isolated-lane only,
- turn “persistent” into “this activity only,”
- keep one command family blocked even when broader helper autonomy is active,
- revoke one source or one exact file without blowing away unrelated work,
- or ask the helper itself to surrender authority it no longer needs.

That is a much better power story than “approve forever and hope.”

## Judgment for Helm

The seven pillars should still stay stable.
Saved view objects and checkpoint branches remain the strongest proof targets.
But the next compact support layer that now looks worth defining is:

- **revoke handles**
- **attenuation ladders**
