# Web research synthesis — 2026-03-22 — pass LXXXIX

Purpose: continue the outside scan and pressure Helm with durable patterns rather than novelty theater.

## Main idea

The next shell law worth stealing is:

**live-looking status should carry an expiry horizon and decay honestly when renewal stops.**

Mature systems keep rediscovering the same discipline:
- heartbeats and leases expire,
- watchdog-backed state needs periodic renewal,
- stale content gets labeled and bounded,
- and privacy surfaces distinguish current use from recent or historical residue.

Helm should steal that law directly.

## 1. Kubernetes leases are a clean model for “current until renewal stops”

Kubernetes uses Lease objects for node heartbeats and leader election.
The key lesson is not “use Kubernetes objects everywhere.”
It is simpler:
- one holder keeps a claim current by renewing it,
- the claim remains valid only for a bounded duration,
- and once `renewTime + leaseDurationSeconds` is passed,
  other actors are allowed to treat the old live claim as expired.

That is excellent pressure for Helm.
A shell-owned beacon or status strip should not say **still current** forever just because it once was.

## 2. systemd watchdogs and timeout extensions make renewal explicit

systemd's `WATCHDOG=1` model says a service must send keep-alive pings regularly when `WatchdogSec=` is enabled.
`EXTEND_TIMEOUT_USEC=` makes the same principle explicit for long-running startup,
runtime,
or shutdown states:
if the new renewal message does not arrive,
the timeout occurs.

That is a very strong product lesson for Helm:
- long-running or live-looking states should not get infinite flattering grace,
- and extending a horizon should be an explicit renewed act,
  not a quiet assumption.

## 3. HTTP caching is a mature grammar for fresh, stale, and revalidate

HTTP caching is not a shell UI,
but it offers an unusually disciplined vocabulary that Helm can steal.
RFC 9111 says a response becomes stale after its freshness lifetime,
and a cache generally must not serve a stale response unless that is explicitly permitted.
`must-revalidate` says once stale,
it must be validated before reuse.
RFC 5861 adds a useful weaker mode:
`stale-while-revalidate` lets a cache show a stale result briefly while revalidating it in the background.

That maps beautifully to Helm surfaces:
- **fresh**
- **stale but usable while revalidating**
- **must revalidate before stronger use**
- **expired / hold**

Helm should steal the grammar,
not the network stack.

## 4. Privacy platforms keep current use separate from recent residue

Android's Privacy Dashboard shows a timeline of when apps accessed sensitive data,
while its status-bar indicators let users inspect which apps are **currently** using microphone or camera.
Apple makes a similar split:
privacy indicators in the menu bar show what is in use now,
and Control Center / support docs also talk about microphone access being **in use or used recently**.
Windows likewise shows current camera or microphone use via lights,
notifications,
or taskbar indicators,
while keeping app-permission review elsewhere.

That is exactly the distinction Helm should preserve:
- current live / on-air
- recent residue
- remembered history
- unknown now

## 5. What Helm should steal

### Steal now
- **freshness-horizon chips** on live-looking shell objects,
  carrying at least last-confirmed time plus a visible horizon
- **decay rails** that say what happens after the horizon:
  revalidate,
  reopen source,
  downgrade to last-confirmed,
  hold stronger action,
  or clear the stale claim
- a stronger split among **current**,
  **last confirmed**,
  **served stale while revalidating**,
  and **historical only**
- `must-revalidate` posture for stronger acts like promotion,
  replay,
  or approval when the basis has gone stale

### Refuse for now
- no infinite green dots
- no giant shell-wide TTL control panel
- no hidden background refresh that silently changes the meaning of a saved or reviewed object
- no current-looking badge without a visible last-confirmed witness
- no pretending recent residue is still on-air now

## 6. Best first proofs for Helm

- one active-borrow beacon with `last_confirmed_at` plus `fresh_until`,
  degrading to **last confirmed** when renewal evidence stops
- one condition strip that can say **progressing but stale** or **restricted and stale** instead of just glowing forever
- one Recall card that reopens as **remembered / historical** after freshness expires
- one Object Browser glance card that can honestly be **stale while revalidating** without pretending to be current-live truth

## Judgment

The next strong import is not a bigger datacube.
It is one small shared rule:

**if Helm shows something as live,
hot,
ready,
or current,
it should also show when that claim was last confirmed,
how long that confidence lasts,
and how the shell will degrade it when renewal stops.**
