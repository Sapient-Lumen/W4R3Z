# Web research synthesis — 2026-03-22 — pass LX

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

## What changed this pass

The outside pattern is no longer only about views, glances, watches, and rounds.
It is also about **bounded curation**.

Current tools keep building some form of:
- investigations,
- notebooks,
- cases,
- incident detail pages,
- structured AI reports,
- or “collect interesting signals here” surfaces.

That means Helm probably needs one shell-owned object for:
**the exact things I want to gather, annotate, inspect, and hand off about one question.**

## 1. Grafana is now strong evidence for curated signal lists plus AI-produced structured reports

Grafana Investigations explicitly says the app lets you collect interesting signals from around the drilldown apps into easy-to-manage lists.
It also supports annotations,
compare-time-range views,
and moving between signals without opening many tabs.

Grafana Assistant Investigations then sharpens the AI side:
- prompt-driven multi-agent analysis,
- background evidence gathering,
- structured report,
- timeline,
- and activity log.

The key Helm lesson:
AI investigation should land in a bounded inspectable object,
not dissolve into chat scroll or silently mutate shell truth.

## 2. Datadog validates rich investigation objects — but also warns Helm not to become a giant notebook platform

Datadog Notebooks validate that teams really do want live-data-backed investigation writeups,
reusable templates,
and mixed text-plus-graph surfaces.

Datadog Incident Details validates a complementary shape:
a centralized incident surface with properties,
signals,
documents,
notifications,
and recent timeline summaries,
all grouped into tabs.

The key Helm lesson:
curation matters,
but Helm should steal the bounded cross-object investigation grammar,
not import a whole collaborative doc suite as core shell constitution.

## 3. Elastic Cases validates evidence gathering plus external handoff

Elastic Cases explicitly frames itself as one place to track incidents,
document findings,
and coordinate response,
with alerts,
evidence,
files,
comments,
and push/update paths to systems like Jira or ServiceNow.

The key Helm lesson:
a curated evidence object becomes much more valuable when it travels honestly.
That fits Helm's existing handoff-packet,
publication-ladder,
and imported-surface posture better than it fits a giant live-sync case engine.

## 4. Linear is the reminder that the stronger source object should stay underneath the curation layer

Linear keeps validating first-class saved views,
favoriteable views,
default views,
and view subscriptions.
This is important because many products let the curation or notebook layer swallow the underlying query/view identity.

Helm should not do that.
The stronger thing should still be:
- the saved view,
- the watchpoint,
- the compare ticket,
- the receipt,
- or the exact handle.

The brief should be the bounded curated wrapper over those exact sources.

## 5. What Helm should steal now

Steal:
- curated signal lists with annotations
- structured AI investigation reports with timeline and activity log
- easy jump-back-to-source from every curated member
- one explicit object for bounded evidence handoff
- templates or seeds for repeated investigation shapes
- clear split between the stronger source object and the weaker curated wrapper

Do not steal:
- giant notebook/editor platforms as shell constitution
- giant case/workflow engines as default shell law
- AI reports that outrank the collected evidence
- silent external push/update behavior without explicit receiver posture

## Judgment

The strongest next compact move is not another view,
another watch,
or another home screen tile.
It is one shell-owned **evidence brief** object that can gather exact signals,
carry weak explanation,
keep authorship visible,
and remain weaker than live truth.
