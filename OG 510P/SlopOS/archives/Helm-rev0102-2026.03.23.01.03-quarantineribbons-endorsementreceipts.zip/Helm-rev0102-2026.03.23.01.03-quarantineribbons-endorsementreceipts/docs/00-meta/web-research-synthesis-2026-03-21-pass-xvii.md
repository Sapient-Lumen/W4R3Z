# Web research synthesis — 2026-03-21 pass XVII

Purpose: keep harvesting strong current ideas for Helm while resisting the urge to import whole products or freeze too much too early.

This pass focused on one question:

**what current tools are really teaching Helm about compact, high-leverage shell surfaces — and what should Helm freeze as shared law versus keep warm as design pressure?**

## 1) The biggest outside pattern is not “launcher mania” — it is projection surfaces

PowerToys Dock, Spotlight action search, Quick Look, Raycast root-search accelerators, VS Code breadcrumbs/timeline, and a bunch of saved-context tools are all converging on one deeper pattern:

**small, high-leverage surfaces get better when they are explicit projections over stronger truth rather than hidden second truth-domains.**

That is the clearest current product pattern Helm should steal.

For Helm this means several warm luxuries increasingly look like members of one family:

- command docks
- preview rails
- facet strips
- review strips
- sticky context strips
- exact trail / breadcrumb cues
- live lenses
- cockpit cards

Their value is real, but their safety comes from staying:

- bounded,
- typed,
- source-witnessed,
- and non-authoritative by default.

That now feels strong enough to freeze as a shared Helm posture.

## 2) PowerToys Dock and Spotlight both validate promotable shell action surfaces

PowerToys now documents a persistent Dock at the edge of the screen, while Spotlight lets search narrow to actions and lets users assign quick keys to actions.

The stealable idea is not “copy these products.”
The stealable idea is:

**a shell can let operators promote a few exact actions or objects into faster surfaces without pretending those faster surfaces are new authority domains.**

That keeps strengthening:

- command docks,
- snippet / quicklink / placeholder seeds,
- and possibly future shell-owned quick-key assignment for exact actions.

That last move still feels warm rather than freeze-worthy, but it is increasingly attractive.

## 3) Quick Look keeps proving preview can stay preview while still being useful

Apple's Quick Look still teaches the right lesson:
preview can be full-size, useful, and action-adjacent without becoming full open-first culture.

That continues to justify Helm's preview rails and preview posture.

The stealable idea is not the exact Apple action set.
It is that preview gets much more lovable when it can carry:

- exact source,
- obvious metadata,
- a few bounded next steps,
- and a clean jump to stronger lanes.

## 4) VS Code keeps validating exact trails, timelines, and admission ladders

VS Code's breadcrumbs and timeline view remain excellent teachers for exact orientation and file history.
Its agent docs also keep normalizing side-by-side agent sessions, while Workspace Trust shows a powerful admission lesson: keep untrusted content browseable and editable, but do not grant full execution by default.

For Helm this sharpens three pressures:

- exact trail / breadcrumb cues should stay warm,
- adoption harbors remain the right answer for mutable delegated work,
- and Helm should keep a future **trust ladder / restricted-mode** idea warm for strong actions over untrusted or imported material.

That trust-ladder idea is not ready for a contract yet, but it feels increasingly worth carrying.

## 5) Saved-context tools keep validating honest return objects, not live-proof folklore

Arc Spaces and Split View, Obsidian Workspaces, Warp Launch Configurations, WezTerm workspaces, and VS Code Profiles all keep teaching the same thing:

users love saved context objects,
but those objects remain lovable only when they stay visibly saved context objects.

Obsidian's own storage docs are especially telling here: workspace files update as you open files and are reasonable `.gitignore` candidates.
That is a strong hint that saved layout/context is often mutable, local, and setup-shaped rather than durable shared truth.

This keeps strengthening:

- workspace/activity capsules,
- launch ladders,
- layout templates,
- and entry objects.

It keeps weakening any temptation to let them impersonate live continuity proof.

## 6) Raycast keeps validating tiny accelerators — and their sync boundaries

Raycast continues to validate quicklinks, clipboard history, snippets, and dynamic placeholders.
But its sync docs are just as informative as its feature docs:
clipboard history is excluded from sync because it may contain sensitive data, and some settings remain local because setups differ.

That matters for Helm.
It suggests that not every useful shell accelerator should automatically become:

- durable shared memory,
- team-wide truth,
- or synced continuity.

Some accelerators should remain:

- local,
- setup-shaped,
- or deliberately lower-authority.

That is an excellent design warning for Recall, Exchange, and future snippet/seed surfaces.

## Strongest takes from this pass

- **freeze projection surfaces as a shared Helm posture**
- keep **command docks**, **preview rails**, **facet strips**, **review strips**, **sticky context strips**, and **live lenses** inside that projection-surface law
- keep **exact trail / breadcrumb cues** warm
- keep a future **trust ladder / restricted-mode** move warm
- keep **assignable quick keys for exact actions** warm
- keep saved-context objects powerful but visibly weaker than live proof

## Strongest non-takes from this pass

- do not copy PowerToys, Spotlight, Quick Look, Raycast, VS Code, Warp, Arc, Obsidian, or WezTerm whole
- do not let promoted quick keys or dock slots silently carry more authority than their owning lane
- do not let projection surfaces turn into shell-level widget folklore or dashboard religion
- do not let saved context objects impersonate live continuity just because they are summonable
- do not freeze trust-ladder or exact-trail law beyond what one compelling specimen can justify
