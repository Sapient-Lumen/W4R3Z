# Web research synthesis — 2026-03-22 — pass LIX

Question for this pass:
**what do current tools teach Helm about bounded repeated revisits — the small circuits people make through important views, links, dashboards, and shortcuts — without turning that need into a giant dashboard religion?**

## Main takeaway

The strongest outside pattern is now:

**users repeatedly need a bounded “make the rounds” object, and current tools keep approximating it with favorites, quicklinks, overview pages, dashboard lists, and playlists.**

That points Helm toward one more compact support object:
- **patrol routes**

A patrol route would be smaller than a dashboard,
more structured than a pile of favorites,
and more inspectable than relying on recents plus memory.

## What current tools are teaching

### 1. Linear validates that frequent saved views deserve first-class return paths

Linear custom views can be saved, shared, favorited, and used as a default opening page.
Its Favorites surface then lets people organize favorites into folders.
That is excellent Helm pressure.

A repeated return path is not just one search result.
It often deserves:
- a durable saved definition,
- a sidebar-visible home,
- grouping,
- and a “start here by default” option.

Helm should steal the return-path dignity,
not just the star icon.

### 2. Raycast validates tiny exact handles plus shared organizational handles

Raycast Quicklinks store URLs, file paths, and deeplinks as small reusable access objects.
Shared Quicklinks make organizational handles distinct from personal ones.
That is useful Helm pressure for patrol routes.

A patrol stop can be tiny.
A route does not need every stop to be a full view object.
Sometimes a compact exact handle is the right stop type.

### 3. Airtable validates Overview as a landing page for key pages and resources

Airtable's Overview layout is explicitly about highlighting key pages and other resources on a single landing page.
That supports Helm's weak Overview direction.
But it also teaches a sharper lesson:
landing pages are often launch surfaces for a bounded round,
not places where all truth should live.

### 4. Grafana validates both dynamic lists and ordered rounds

Grafana's dashboard list panel can surface dynamic links based on starred dashboards,
recent dashboards,
a search query,
or tags,
and it refreshes that list on dashboard load.
That is a very strong idea for Helm.
A patrol route may need one small dynamic lane that stays current without requiring manual curation of every member.

Grafana playlists are also useful,
but only in bounded form.
A playlist is a list of dashboards shown in sequence and is used for situational awareness.
Helm should steal the sequence idea,
not the wallboard worldview.

### 5. Grafana validates context-carrying links between related surfaces

Grafana has explicit dashboard links,
panel links,
and data links,
and its data links/actions keep the context of the source panel.
That is a good Helm lesson.
A patrol hop should preferably preserve useful context such as:
- time range,
- selected object,
- chosen scope,
- or exact compare basis.

### 6. Atlassian Analytics validates the home/catalog surface as weaker than the dashboard itself

Atlassian Analytics opens to a workspace home page where you can view the dashboards you have access to.
That is weaker than the dashboards themselves,
and that weakness is good.
It reinforces the Helm lesson that a top-level landing/catalog surface can be valuable without becoming the one authority plane.

## What Helm should steal now

### 1. Patrol routes as explicit shell objects
A patrol route should be able to bind a small ordered circuit of:
- linked views
- watchpoints
- glance derivations
- compare tickets
- exact front-door handles
- and maybe one bounded dynamic lane

### 2. Personal favorites and shared patrols should stay distinct
Helm should let people favorite patrols,
folder them,
or make one a default return surface.
But shared patrol definitions should remain distinct from personal route state.

### 3. One bounded dynamic lane is healthier than giant static curation
Grafana's dashboard list teaches that one search/tag/current lane can stay useful and current.
Helm should consider allowing one bounded dynamic section inside a patrol route,
with explicit source witness,
instead of requiring everything to be manually frozen.

### 4. Stepwise traversal matters
A patrol route should support:
- next / previous stop
- resume last stop
- jump to source
- skip or snooze one stop
- maybe a weak cycle/presentation mode later

### 5. Overview should launch patrols, not replace them
Overview can be the landing place where a patrol begins,
just as Airtable Overview or a workspace home page helps users choose where to go next.
But the patrol route should remain the explicit revisit object.

## What Helm should avoid

1. **Do not let patrol routes become a universal dashboard constitution.**
2. **Do not let autoplay / rotation become the default patrol experience.**
3. **Do not let a dynamic lane hide its source witness.**
4. **Do not let patrol state silently choose profile, identity, or provider truth.**
5. **Do not let Overview absorb every revisit use case.**

## Judgment for Helm

The seven pillars still do not need to move.
But the support stack sharpens again.

Helm should now keep warming:
- **patrol routes** as shell-owned bounded revisit circuits
- **personal-versus-shared patrol posture**
- **one bounded dynamic lane** inside some patrols
- **Overview as a patrol launcher rather than a fake command center**
- **favorites/default-route posture** for the rounds people actually make repeatedly

That makes Helm feel more lived-in without sacrificing its hard-won truth discipline.
