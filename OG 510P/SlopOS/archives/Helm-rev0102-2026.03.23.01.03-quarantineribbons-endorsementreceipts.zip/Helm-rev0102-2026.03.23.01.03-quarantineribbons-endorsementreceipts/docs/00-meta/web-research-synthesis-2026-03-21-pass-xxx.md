# Web research synthesis — 2026-03-21 pass XXX

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on one tighter arrival question:

**if Helm already has landing rehearsals and near-match fences, what should the operator compare before adoption, and how should Helm support bounded partial acceptance without hiding what was accepted, omitted, inherited, or left local?**

## 1) Current tools keep rewarding compare-to-basis overlays before acceptance

Figma now makes compare surfaces unusually concrete.
Branch review lets reviewers preview branch changes alongside the main file,
side-by-side or as an overlay,
before approval or merge.
Dev Mode compare changes also lets people compare versions over time,
inspect edited layers,
and keep the selected comparison basis visible.
Library updates reinforce the same posture again:
reviewers can visually compare updates and then update one instance at a time or update all.

VS Code Profiles make the same point for shell-like environment structure.
Profiles can be opened in a new window,
imported explicitly,
and drag-and-drop `.code-profile` import opens the Profiles editor so the arriving profile can be previewed before import.
Partial profiles can also include only the customized configurations or include settings inherited from the Default Profile.

That combination strongly supports one new Helm compare surface:
**arrival overlays**.
A receiver should be able to compare an arriving surface against one exact carried basis or one local candidate before adoption,
rather than jumping straight from arrival to trust.

## 2) The best systems also reward bounded partial acceptance,
not only all-or-nothing landing

VS Code Profiles already carry a bounded partiality lesson.
Profiles can inherit some configuration from the Default Profile,
and export/import can be partial rather than total.
That means “use some of this here” can be explicit instead of ambient.

Figma library updates add the second half of the lesson.
Operators may update one instance individually or update all,
rather than pretending every change always deserves one giant indivisible accept step.

Obsidian Bases is a quieter teacher of the same shape.
A `.base` file stores view syntax,
while the underlying notes and properties remain stronger substrate.
Multiple views can exist over the same files,
and a base can be embedded without pretending the whole workspace residue traveled with it.

That combination strongly supports one new Helm arrival move:
**adoption slices**.
A receiver should be able to adopt one bounded slice of an arriving surface — one view,
one dock band,
one key family,
one admitted slot class — while leaving the rest omitted,
inherited,
local,
or still pending rebinding.

## 3) Arrival overlays and adoption slices fit Helm's existing pressure stack

These moves should not replace the current truthful-landing family.
They should compose with it:

- landing manifests
- anchor maps
- inherit masks
- basis stamps
- residue ledgers
- receiver fit cards
- rebind ladders
- landing rehearsals
- near-match fences

A good shell arrival posture now looks increasingly like this:

1. arrival with carried witness
2. overlay compare against one exact basis or one local candidate
3. optional landing rehearsal on the receiver
4. explicit adoption slice or explicit rebind
5. durable receipt naming what really changed

## 4) Strongest new warm moves from this pass

- **arrival overlays** — compact shell-owned side-by-side or overlay compare surfaces for one arriving shell object versus one exact basis or one explicit local candidate before adoption
- **adoption slices** — bounded shell-owned partial-adoption acts that let the receiver accept one admitted slice of a landing while keeping the unaccepted remainder explicit

## 5) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep compare separate from adoption
- keep partial acceptance explicit and receipted
- let one strong compare surface and one strong bounded-accept surface mature before inventing a giant import constitution

## Strongest non-takes from this pass

- do not add a pillar
- do not build a giant universal diff engine
- do not turn partial adoption into hidden field-level patch magic
- do not let side-by-side or overlay compare wear the badge of adoption
- do not let “accepted enough” become silent exact success
