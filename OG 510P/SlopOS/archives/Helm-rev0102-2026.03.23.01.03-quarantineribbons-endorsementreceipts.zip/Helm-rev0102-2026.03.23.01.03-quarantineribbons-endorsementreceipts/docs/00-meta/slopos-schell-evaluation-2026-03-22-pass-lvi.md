# SlopOS/Schell evaluation — 2026-03-22 — pass LVI

Question for this pass:
**what does SlopOS's datacube teach Helm about live saved views, subscriptions, and overview/landing surfaces if we reread it through RFC-0100 smart folders, bounded live queries, explicit view mutation, and no hidden activation/materialization law?**

## Main takeaway

This pass sharpens one lesson that was already latent:

**Helm may absolutely have saved views that can stay warm, notify, and sit near daily work — but those views and their subscriptions must remain shell-owned, view-scoped, bounded, revocable, and weaker than live authority.**

At the same time, **Overview should stay a weak landing/entry surface built from linked views, front-door handles, and current-live beacons rather than becoming a new authority plane.**

## What SlopOS keeps teaching

### 1. Saved queries belong to the shell, not to ambient background folklore

RFC-0100 and `attrfs-posture-v0.md` are now the clearest teachers for Helm's datacube.
They explicitly allow:
- attribute queries bound to an explicit view,
- saved query / smart-folder manifests,
- and optional live query mode.

But they put hard limits on all three:
- query remains **view-scoped**,
- live mode is **optional, revocable, and bounded**,
- result identity stays **handle-returning** rather than ambient path/global inventory,
- and saved-query persistence must not silently widen into autostart, background resubscription, or an app-owned indexing daemon.

That is almost a direct design instruction for Helm.
If Helm wants a saved view that can also notify,
it should do so as a **shell-owned view subscription** attached to one exact saved view object or query digest.
It should not be an app-owned invisible watcher,
a silent background worker,
or a global timeline service.

### 2. Evaluation and materialization stay separate

SlopOS's view and namecert seams keep making the same point:
**evaluation is not materialization**.
A bundle evaluation or query result does not quietly become live local truth.
Actual authority-bearing change still lands on a reviewed target seam such as explicit `view.attach` / `view.detach`.

That matters for Helm in two ways:
- a linked view embedded in Overview is still a borrowed projection,
- and a view subscription is still a bounded attention relation,
  not a right to mutate or auto-adopt what it notices.

### 3. View mutation is explicit, slotwise, and auditable

SlopOS's namespace/view posture keeps refusing “global namespace magic.”
Views are objects.
Mutations happen explicitly.
Attachment and detachment are ordered target-seam acts.
That strongly suggests Helm should resist the temptation to make Overview or subscriptions into hidden orchestration engines.

The Helm analogue is:
- Overview may compose linked views,
  handles,
  current-live beacons,
  and bounded ops slices,
  but it should not become the hidden place where silent rebinding,
  silent profile choice,
  or silent route rewrites happen.
- A view subscription may emit attention,
  but stronger effect still belongs to explicit adoption,
  route,
  action-warrant,
  or publication seams.

### 4. Live queries are useful precisely because they are not giant cubes

The SlopOS smart-folder posture is not “all facts everywhere at all times.”
It is a bounded query over an admitted view.
That is a brilliant teacher for Helm.

Helm can therefore get more alive without getting more grandiose.
Instead of inventing a universal datacube with ambient latest truth,
it can let operators create:
- one saved view,
- one linked appearance of that view in Overview,
- one subscription to entries/exits/threshold changes,
- and one exact compare path nearby.

That is already rich.
And it stays honest.

### 5. Schell still reinforces the shell-facing side of the lesson

Schell keeps pushing Helm away from fake continuity and toward truthful shell-facing seams.
That supports the same conclusion:
front doors,
Overview tiles,
subscriptions,
and compare cues should improve **returnability** and **orientation**,
not bluff that they are current-live state,
current authority,
or current exact attachment.

## Lessons Helm should now lock in harder

1. **Saved views may notify, but the subscription belongs to the shell.**
2. **A live-ish view is still a bounded projection, not a second source of truth.**
3. **Overview is a landing surface, not an authority plane.**
4. **Subscriptions must be revocable, inspectable, and locality-aware.**
5. **No hidden daemon folklore: persistence does not imply ambient background watch law.**

## What this changes for Helm

This pass makes two moves look strong enough to advance:

- **view subscriptions** as a candidate shell object tied to one exact saved view
- **overview landing posture** sharpened around linked views, front-door handles, and current-live beacons

And it sharpens one refusal:

- **do not let Overview become a master dashboard that quietly owns work truth**

## Judgment

SlopOS's datacube is not teaching Helm to become bigger.
It is teaching Helm to become more exact.

The right new move is not a giant home screen or a universal watch service.
It is:
- one explicit saved view,
- optionally one bounded subscription to that view,
- one or two linked appearances,
- and one weak landing surface that helps the operator get back in honestly.
