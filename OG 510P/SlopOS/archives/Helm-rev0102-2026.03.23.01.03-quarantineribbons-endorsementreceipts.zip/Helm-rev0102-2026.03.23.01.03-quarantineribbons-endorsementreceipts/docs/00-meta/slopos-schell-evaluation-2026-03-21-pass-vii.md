
# SlopOS + Schell evaluation — 2026-03-21 — pass VII

Purpose: keep using SlopOS and Schell as design teachers while Helm is still deciding what deserves a freeze, what deserves a specimen, and what should stay pressure only.

This pass focuses on the next trap after entry-artifact truth:
**saved-to-live binding can still lie even when the archive already admits that saved artifacts are not live.**

That pressure now looks strong enough to justify one narrow new Helm freeze:
- **non-exact bindings require witnesses**,
- and one new candidate move:
- **binding witness cards**.

DelayBasin remains most useful here as archive method.
It keeps pushing the same healthy rhythm:
take one bounded step, name the non-takes, and demand one proof-bearing specimen instead of widening the doctrine by enthusiasm.

## What SlopOS pressures most strongly now

### 1. Exact reveal keeps refusing nearby substitutes

SlopOS's exact show-item and reveal posture keeps teaching a very specific shell lesson:
if the system cannot reveal the exact subject honestly, it should fail closed rather than opening a nearby folder, a neighboring object, or a merely plausible substitute.

Helm should steal that principle beyond file reveal.
Once Helm has:
- capsules,
- layout templates,
- activity entry kits,
- cockpit cards,
- and exact/live/historical continuity cues,

it will also need to say whether a saved subject:
- matched exactly,
- rebound with repair,
- stayed ambiguous,
- or failed to bind at all.

### 2. OpenURI keeps separating request, provider-local reuse, and current destination truth

SlopOS's OpenURI family now says the same thing from several seams at once:
- launch request is not session/profile selection,
- recent-items hints are not durable reopen authority,
- launch admission is not target completion,
- preview metadata stays request-local or provider-local,
- and exact show-item requests do not silently degrade into nearby reveal.

The important Helm lesson is broader than URI launch.
A shell can remember useful task-entry shape and still refuse to pretend that provider-local reuse or silent retargeting counted as exact truth.

### 3. Lease and request descriptors keep refusing to become current state

SlopOS's lease-descriptor and background-request-state posture adds the same lesson from another direction:
request identifiers and issued descriptors are durable evidence of prior admission, not a free oracle for current active state.

For Helm this means:
a saved slot, recent live handle, or last-good route hint can be valuable without certifying that the same concrete live target still exists now.

### 4. The SlopOS datacube rewards witnessed joins, not flattering joins

By this point the deeper datacube lesson is clear:
once a system starts joining saved/requested/history objects to current live objects, the dangerous move is not only overclaiming liveness.
It is overclaiming the **join** itself.

Helm already froze request-vs-live truth and entry-artifact truth.
This pass says the next narrow refinement is now earned:
**when the join from saved/planned shape to current live target is not exact, Helm should witness it rather than silently doing it.**

## What Schell adds to the picture

### 1. Launch kits and cockpits now need a matching story

Schell's launch-kit, quick-summon, and cockpit honesty work already keeps:
- live session,
- restored session,
- launch kit,
- quick summon,
- and project cockpit
visibly separate.

That separation was the right first move.
But it now creates a second need:
once a launch kit or cockpit points toward a likely live target, Schell and Helm both need a compact way to explain **why this target counts, how exact the match was, and what action family remains honest**.

### 2. Preflight honesty is a strong clue for continuity honesty

Schell's completion-card, parameter-help, and preflight work teaches a reusable rule:
candidates and previews should help strongly without being mistaken for execution authority.

Helm can reuse that rule directly.
A binding witness card can be to continuity what a preflight card is to command entry:
useful, compact, strong enough to act on, but explicit about evidence, gaps, and downgrades.

### 3. Local view trees reinforce that visible structure is not self-certifying

Schell's local view-tree work keeps reminding us that rich local structure can be useful while still remaining derivative.
The same should hold for Helm's saved-to-live joins.
A beautiful card or cockpit should not certify its own rebind merely because it looks shell-owned.

## What DelayBasin usefully pressures here

DelayBasin's basis-witness and foreign-pressure work is especially useful in this pass.
It suggests three healthy moves:
- say what prior basis or expected target the system thought it was extending,
- say what current evidence was actually observed,
- and fail closed to hold / repair / reread rather than letting stale proximity inherit authority.

That is almost exactly the discipline Helm needs for saved-to-live binding.

## What now looks worth doing in Helm

### Worth freezing now

- **non-exact bindings require witnesses**

Why now:
- Helm now has enough saved and continuity-shaped artifacts that silent rebinding would rot multiple surfaces at once,
- SlopOS keeps refusing silent nearby substitutes across reveal, launch, recents, and request-state seams,
- Schell now has enough launch-kit/cockpit pressure that a matching story is no longer optional,
- and the freeze can stay small: it does not force one universal matching engine or giant ontology.

### Worth adding as candidate pressure now

- **binding witness cards**

Why this now looks strong:
- Helm already has route cards, rehearsal cards, capsule diffs, layout-template rebinding, cockpit cards, and entry kits,
- outside tools already prove users want explicit status and reusable task-entry surfaces,
- and Helm can now combine those instincts into one shell-owned card for exact / repaired / ambiguous / unavailable joins.

A binding witness card should likely name:
- the saved or planned subject,
- the observed live candidate,
- the match basis,
- the match grade,
- the strong actions that remain honest,
- and the repair or hold path when exactness is missing.

## What Helm should explicitly not take

- a global fuzzy matching engine that silently decides identity everywhere
- title-only or icon-only rebinding as the default continuity story
- hidden remote/profile/account/browser/session reuse that the shell cannot explain
- a giant final slot algebra before one compact witness card exists
- a belief that better cards excuse weaker exactness law

## Current bounded take

A useful new Helm rule is:

**when Helm binds saved/planned task-entry structure to current live targets non-exactly, it should show a witness rather than silently claiming continuity.**

And a useful new candidate move is:

**binding witness cards as shell-owned continuity cards that explain exact match, repaired match, ambiguous candidate, or unavailable target across capsules, templates, cockpits, and entry kits without creating a giant workspace bureaucracy.**
