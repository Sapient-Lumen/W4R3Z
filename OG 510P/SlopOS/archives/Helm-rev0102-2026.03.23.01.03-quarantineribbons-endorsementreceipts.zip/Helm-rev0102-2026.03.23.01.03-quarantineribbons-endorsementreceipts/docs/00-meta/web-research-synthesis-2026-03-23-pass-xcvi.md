# Web research synthesis — pass XCVI — 2026-03-23

## Headline

The current outside pressure says Helm should add a small **arrival-risk grammar**.
The main lesson is not merely “warn more.”
It is:

**keep origin evidence, quarantine/risk state, safe-open posture, explicit endorsement, sanitized derivative, and live authority on separate seams.**

## Strongest outside patterns

### 1. Apple Gatekeeper keeps provenance and first-open approval separate from ordinary launching

Gatekeeper's current posture is a strong teacher for Helm:
software downloaded outside the App Store is verified for developer identity,
notarization,
and integrity before first open,
with explicit user approval at first launch.
Apple also treats provenance tracking as part of the story for files written by downloaded software.

The important lesson is not “copy Gatekeeper wholesale.”
It is:
**arrival provenance,
review,
and actual launch authority are different questions.**

### 2. Windows Attachment Manager and Mark-of-the-Web keep zone-of-origin separate from later policy

Windows preserves zone information because otherwise it cannot make proper risk assessments.
Office then uses Mark-of-the-Web as a separate signal that pushes downloaded files into a guarded posture,
including macro blocking by default.

That is exactly the kind of durable law Helm should steal:
**origin evidence should survive long enough to inform later stronger actions,
not disappear just because a file moved or reopened successfully.**

### 3. Chrome Safe Browsing and dangerous-download warnings keep risk posture visible without pretending all warnings are the same

Chrome differentiates dangerous,
suspicious,
unverified,
and insecure download states,
and blocks or warns accordingly.
That is a good reminder that blocked,
restricted,
safe-open-only,
and endorsed should remain visibly different classes.

### 4. VS Code Workspace Trust proves browse-first / trust-later can feel mainstream rather than paranoid

VS Code keeps opening untrusted material in Restricted Mode,
prevents automatic code execution there,
and makes the restricted posture visible in editor chrome.
That is very close to the Helm move:
**safe-open and inspect-first should feel like the normal humane path,
not like a punishment mode.**

## What this means for Helm

Helm should probably warm two shell-owned objects:

### Quarantine ribbons
A compact shell-owned arrival-risk witness that can say:
- where the thing came from
- whether the route is still foreign / risky / unknown
- whether the subject is previewable only,
safe-open only,
blocked,
or already endorsed
- whether the ribbon attaches to the original object or only to one exact derivative

### Endorsement receipts
A compact shell-owned historical receipt that can say:
- which exact object was endorsed or cleared
- by what trusted shell lane
- under what basis or reason
- whether the endorsement applied to the source object,
a derivative,
or a bounded class only
- and what later reopen or exec paths are now allowed

## What not to steal

Do not steal:
- giant path-wide trusted-location folklore
- giant provenance theater before one compact ribbon works
- preview-success-equals-clear shortcuts
- or reputation magic that hides why something is blocked

## Main judgment

This is worth warming now.
It gives Helm a humane answer to one subtle but expensive failure mode:
**foreign material should not quietly graduate from arrived to trusted merely because it became visible,
reopened,
or copied into a friendlier-looking place.**
