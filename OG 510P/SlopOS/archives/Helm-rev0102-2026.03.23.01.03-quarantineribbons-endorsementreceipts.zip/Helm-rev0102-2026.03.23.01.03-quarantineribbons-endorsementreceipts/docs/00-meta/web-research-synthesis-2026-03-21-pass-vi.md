
# Web research synthesis — 2026-03-21 — pass VI

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on one specific question:
**what should a truly good task-entry object look like in 2026?**

The answer from current tools is surprisingly consistent:
users love saved entry artifacts, but the best systems either expose launch status honestly or stop short of pretending saved setup equals current truth.

That points toward two outcomes for Helm:
- freeze **entry-artifact truth** narrowly,
- and explore **activity entry kits** as a candidate move.

## Cluster 1 — structured summon surfaces are now real product substrate

### What current systems teach

PowerToys Command Palette is no longer just a launcher story.
It explicitly supports rich extension content such as list pages, detail pages, form pages, markdown pages, and grid pages.
That matters because current summon surfaces are increasingly expected to carry structure, not only flat rows.

### What Helm should steal

Helm should keep investing in typed summon surfaces that can carry:
- exact subject identity,
- input fields,
- badges,
- route choices,
- and next actions.

That strengthens Omnibox, rehearsal cards, cockpit cards, and future entry-kit cards.

### What Helm should refuse

- a hidden app-within-app card platform
- provider-local state machines the shell cannot inspect
- rich cards that blur saved shape, launch request, and live observation

## Cluster 2 — saved layouts remain valuable, but honesty decides whether they age well

### What current systems teach

PowerToys Workspaces lets users capture a desktop arrangement, launch applications into custom positions and configurations, add per-app arguments, and then shows a launch dialog with per-app statuses such as launched, launching, or failed.
Obsidian Workspaces likewise preserves task-shaped layouts, open tabs, and sidebar visibility for named modes of work.
VS Code Profiles goes even further by letting users preview a profile before creation, switch quickly, associate profiles with folders/workspaces, and export or import them.

### What Helm should steal

Helm should absolutely keep stealing the appetite for:
- task-shaped saved entry artifacts,
- named configurations,
- quick switching,
- preview-before-commit,
- and explicit export/import when useful.

But the real thing to steal is the **honesty model**.
PowerToys Workspaces is especially revealing here: it does not pretend the saved workspace is already live; it shows per-app launch state while the arrangement is being rebuilt.
That is exactly the direction Helm should favor.

### What Helm should refuse

- any saved object that silently counts as a live task merely because it was selected
- title-matching folklore as the main rebinding model
- hidden target reuse that the shell cannot explain

## Cluster 3 — overview works best when search, space, and entry cooperate

### What current systems teach

GNOME still demonstrates the value of an overview that combines windows, applications, workspaces, and instant typing-to-search from one shell-owned space.
It also keeps workspaces manipulable from the same overview, including dragging application or window entries onto a workspace.

### What Helm should steal

Helm should keep Overview as the spatial companion to Omnibox.
But this pass adds a sharper idea:
entry kits should probably appear in both places.
The user should be able to:
- search for an activity entry kit,
- inspect what it would do,
- and place or launch it from the same shell-owned spatial surface.

## Cluster 4 — unified status lists make multi-thing work feel calmer

### What current systems teach

VS Code's Chat/Agent Sessions experience now keeps many kinds of sessions visible in one list, with status, type, file-change hints, grouping, and easy jumping between them.
That is not a desktop shell, but it is a strong example of a unified control surface for parallel ongoing work.

### What Helm should steal

Helm should likely let activity cockpit cards and Operations Center share a similar idea:
- one place to see nearby live work,
- obvious status badges,
- and the ability to jump between related active and historical objects.

This is not an argument to copy agent UI.
It is an argument that **one truthful list of nearby sessions/activities matters a lot** once users juggle parallel work.

## Cluster 5 — timelines and multi-diff views are stronger than generic "history"

### What current systems teach

VS Code's Timeline view remains a unified history surface over multiple event sources, and its multi diff editor shows that people value one scrollable review surface when changes span multiple files.

### What Helm should steal

Helm should keep making capsule diffs and cockpit summaries comfortable with:
- multiple related objects,
- mixed live and historical evidence,
- and compact "what changed" summaries.

This is one of the cleanest ways to make Recall feel much smarter than generic recent-items folklore.

## Cluster 6 — visual automation only stays humane with inspectable debug surfaces

### What current systems teach

Node-RED still shows the importance of a sidebar that exposes information, debug messages, configuration nodes, and context data, and its Debug sidebar keeps message structure explorable instead of hiding everything in logs.

### What Helm should steal

Helm should keep the Desktop Flow observability freeze intact.
More specifically, activity entry kits should be allowed to connect to Flow entrypoints,
but only when the Flow side can still explain:
- what was triggered,
- what is running,
- and what failed or held.

## Cluster 7 — tiny accelerators remain one of the most lovable powers

### What current systems teach

Raycast continues to make Quicklinks, Snippets, and Dynamic Placeholders feel small and immediate.
Quicklinks live in root search, snippets can auto-expand in place, and placeholders can prefill values such as clipboard text or other snippets.

### What Helm should steal

Helm should keep typed seeds alive.
For this pass the new twist is:
entry kits should probably be able to carry a few shell-owned seed refs,
so opening a task can prefill the right routes or forms without falling back to raw macro culture.

### What Helm should refuse

- text-macro folklore as the default substrate
- hidden scraping as the main way to satisfy placeholders
- entry artifacts that silently run strong actions just because a seed was present

## What now looks strongest

Highest-value moves to keep live after this pass:
1. **entry-artifact truth** as a narrow cross-cutting freeze
2. **activity entry kits** as a shell-owned candidate move
3. **activity cockpit cards** as the nearby truthful front door
4. **capsule diffs with multi-object summaries**
5. **typed seeds** that can help task entry without regressing to macro folklore

## What still does not need a hard freeze yet

- final activity-entry-kit schema
- final relationship among entry kits, capsules, and cockpit cards
- final destination-target language for remote/profile/account-like cases
- exact export/share posture for entry kits
- exact visual treatment inside Overview

## Working stance

Helm should keep stealing ideas that make task entry feel:
- fast,
- legible,
- reviewable,
- and honest.

The best current recipe looks like:
- shell-owned entry artifacts,
- shell-owned cockpit cards,
- shell-owned diffs,
- and visible ladders that distinguish attach, restore, relaunch, and fresh launch.
