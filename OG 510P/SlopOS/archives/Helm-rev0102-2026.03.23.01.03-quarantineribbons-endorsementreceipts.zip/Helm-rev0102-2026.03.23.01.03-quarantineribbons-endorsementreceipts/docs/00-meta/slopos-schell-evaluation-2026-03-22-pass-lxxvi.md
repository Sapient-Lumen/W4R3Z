# SlopOS + Schell evaluation — 2026-03-22 — pass LXXVI

This pass re-read the latest SlopOS and Schell bundles after Helm warmed reveal windows,
authority windows,
cohort windows,
and minimization ladders.
The next pressure question was narrower:

**once Helm can say what exact cohort is in play,
how does it say what that cohort or scope will actually touch,
change,
reveal,
or mute before the stronger act lands?**

## What SlopOS is still teaching

### 1. Family members should stay intentionally small
The latest SlopOS auth-mediation tightening keeps repeating a useful product law:
family members remain recoverable when each boundary stays intentionally narrow,
keeps the same-revision attachment to the closed family,
and preserves explicit recovery sections instead of growing into singleton lore.

Helm should keep learning from that.
A new move is justified when it is:
- smaller than a pillar,
- reusable across several shell acts,
- and strict enough to resist widening into one giant governance or planning plane.

### 2. Local success must not widen into portable grant folklore
The current SlopOS auth-mediation work keeps freezing the same boundary from several angles:
explicit local login or credential mediation does **not** create a portable granted-scope,
resource-indicator,
authorization-details,
or entitlement export seam.

For Helm the analogue is:
- a selected cohort is not the same as whole-family reach,
- a chosen rung is not the same as current effective reach,
- and a share / mute / apply / rerun step should not hide what it would actually include.

### 3. Projection and preview stay weaker than authority
SlopOS's view and projection posture still reads healthiest when saved queries,
state projections,
and view replication remain bounded,
non-authoritative,
and explicit about their source.

Helm should keep that law,
but add one more answer next to it:
**preview should not only show the source,
it should also show the expected reach.**

### 4. Dynamic inclusion must be named
One thing the external tools made easier to notice is that scope often keeps moving after selection:
a downtime can later include newly matching monitors,
a saved rule can keep evaluating new items,
a library update may touch many downstream instances,
and a broader scope request may admit more than one current object.

Helm therefore benefits from a compact object that can say:
- what exact set is known now,
- what dynamic rule may add future members,
- and what confidence class the preview belongs to.

## What this means for Helm

Helm now looks ready for one more shell-wide law,
but not for a new pillar:

- **cohort windows** answer: what exact subset is this about?
- **minimization ladders** answer: how much wider are we asking to go?
- **reach previews** should answer: what would this stronger step actually include right now?
- **affected-set witnesses** should answer: what exact or counted set did the shell predict or observe as in scope?

That move fits SlopOS well because it keeps the object family small,
bounded,
source-witnessed,
and explicitly weaker than live truth.

## Keep / reject

### Keep
- exact cohort truth
- explicit widen-by-choice posture
- dynamic-scope caveats
- compact changed/impacted-set witness next to stronger acts
- side-by-side or per-instance review when a preview can show concrete downstream effects

### Reject
- giant blast-radius simulator ambitions
- hidden dynamic inclusion after a scope was chosen
- one vague “this affects multiple things” badge
- letting old share or approval receipts impersonate current affected reach
- pretending preview is always exact when some targets are only rule-derived or future-matching
