# Web research synthesis — 2026-03-22 — pass XC

Purpose: pressure-test whether Helm should add a stronger law for **visible caveats, conditional verdicts, and derived-subtree revoke**.

## Short answer

Yes.
Several mature systems line up on a remarkably useful pattern:
- delegated power should be able to become **narrower**,
- conditions should be **attached and inspectable**,
- evaluation may honestly return **conditional / missing context** instead of only allow/deny,
- and revoking a parent should have a truthful story for **derived descendants**.

## 1. Macaroons are still one of the best teachers for delegated narrowing

Google's macaroons paper remains highly relevant.
The core lesson is not just “token with limits.”
It is that bearer credentials can carry **caveats that attenuate and contextually confine when, where, by who, and for what purpose** requests should be authorized.

For Helm this strongly supports:
- caveat sheets on exchange objects,
- explicit inherited-versus-local caveats,
- and a design where narrowing is normal but widening requires a fresh stronger act.

## 2. Biscuit shows that offline attenuation is a real product possibility

Biscuit's docs say a token can generate a new token with **narrower rights**,
and its revocation guide makes a crucial point:
with offline attenuation,
revoking a token should also revoke **all derived tokens**.

That is a powerful shell lesson.
Helm should not show only “this share exists.”
It should be able to show:
- what it was derived from,
- whether it is narrower than the parent,
- and whether revoke applies to one node or the whole subtree.

## 3. SpiceDB caveats contribute the strongest UI steal in this pass

SpiceDB's caveats are attached to relationships,
can be partially bound at write time,
and are evaluated with runtime context.
Most importantly for Helm,
permission checks can return three states:
- no permission,
- has permission,
- **conditional permission**.

When permission is conditional,
SpiceDB can also return the **missing context fields**.

This is exactly the sort of UX honesty Helm should steal.
Instead of bluffing or denying vaguely,
Helm can say:
- this would be allowed if current network / cohort / freshness / holder context were supplied,
- here is the missing context,
- and here is the narrowest next way to satisfy it.

## 4. AWS STS session policies reinforce intersection-only narrowing

AWS STS temporary sessions remain a useful teacher because session policies only **limit** the permissions of the assumed role or federated session.
The resulting permissions are the **intersection** of the base identity policy and the session policy;
they cannot grant more.

This supports a healthy Helm rule:
child or narrowed objects should not be able to overclaim more than the parent already allowed.

## 5. Why this matters for Helm specifically

Helm already has:
- attenuated reveal links,
- capability budgets,
- lease windows,
- renewal rails,
- access verdict cards,
- least-widening previews,
- trusted chrome,
- freshness horizons,
- and current-live beacons.

What this pass adds is the glue:

### A. Caveat sheet
A reusable shell-owned projection surface over one exact object,
showing the conditions that currently shape its validity.

### B. Delegation subtree
A reusable shell-owned ancestry surface over one exact delegated object,
showing derivation and revoke blast radius.

### C. Conditional verdict
A distinct answer class between yes and no.

That makes Helm's datacube feel smarter **without** requiring a smarter giant cube.

## 6. Steal this, not that

Steal:
- Macaroons-style visible contextual caveats
- Biscuit-style narrower derived tokens plus subtree revoke truth
- SpiceDB-style conditional permission plus missing-context fields
- AWS STS-style intersection-only narrowing

Do not steal:
- giant policy editors as the everyday UI,
- conditionality that only exists in logs,
- delegated children that lose parentage in the shell,
- or a fake binary yes/no story when the real answer is “yes, if this exact context is supplied.”

## 7. Pull-the-trigger judgment

This is worth warming immediately as a cross-cutting law:
- **caveat sheets**
- **delegation subtrees**
- and **conditional / missing-context verdicts**

Do not yet turn it into one enormous policy pillar.
