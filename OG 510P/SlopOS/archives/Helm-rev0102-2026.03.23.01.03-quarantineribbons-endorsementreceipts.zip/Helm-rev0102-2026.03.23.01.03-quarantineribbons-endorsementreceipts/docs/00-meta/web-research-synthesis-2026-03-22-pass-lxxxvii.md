# Web research synthesis — 2026-03-22 — pass LXXXVII

Purpose: continue the outside scan and pressure Helm with durable patterns rather than novelty theater.

## Main idea

The best outside systems keep permissions,
restricted posture,
and temporary grants in **system-owned review surfaces** rather than in ordinary content flow.
Helm should steal that discipline.

## 1. The web permissions model treats powerful-feature permission as browser UI,
not page UI

The W3C Permissions spec is unusually direct here:
express permission to use a powerful feature is generally given and controlled through **browser UI**.
That is the cleanest possible teacher for Helm.

A page may motivate a request.
It should not be the final trustworthy place where the permission truth lives.

## 2. Chrome's newer permission UX shows the value of a tiny trusted review surface

Chrome's one-time permission work is a strong product example because it keeps permission decisions in site controls and browser prompts,
not in page chrome.
It also makes a crucial distinction visible:
- **Allow this time**
- versus **Allow on every visit**

That is exactly the kind of narrow truth Helm should steal.
A shell review lane can make temporary versus persistent posture explicit without needing a giant permission center.

## 3. VS Code Restricted Mode proves blocked-but-browseable can be visible and humane

Workspace Trust is still one of the strongest examples of “restricted first,
trust later.”
VS Code uses a banner,
a status badge,
and a Workspace Trust editor overlay while keeping ordinary browsing possible and execution-rich features restricted.

That matters for Helm because it says:
- imported or unfamiliar material can still be useful,
- stronger execution/review surfaces can move into host-owned chrome,
- and restricted is a first-class product state,
  not a hidden failure.

## 4. Android keeps permission requests tied to concrete actions and encourages narrower scope

Android's runtime permission guidance explicitly says apps should associate specific actions with specific permissions.
That is a product law worth stealing.
A shell should avoid ambient permission asks and instead let the stronger review surface appear at the exact moment of need.

Android 14's Selected Photos Access tightens the same law further.
It lets users grant access to selected media rather than whole libraries,
and it treats selected-media access as temporary.
That is a good reminder that narrow scope and temporary posture should be normal,
not special.

## 5. What Helm should steal

### Steal now
- one **trusted chrome lane** for authority-bearing review,
  grant,
  deny,
  and protected follow-up surfaces
- explicit **temporary versus persistent** review choices when both are available
- **restricted but browseable** arrival posture for imported or unfamiliar surfaces
- exact **request-triggered** review rather than ambient pre-grants
- visible **host-effect witnesses** when weaker-origin content asked for shell-side effects

### Refuse for now
- no giant all-shell security framework
- no pretending app content can faithfully render the shell's strongest review truth
- no silent widening from temporary to persistent
- no design that makes restricted posture feel like generic brokenness

## 6. Best first proofs for Helm

- one imported-surface card that opens in restricted posture but routes stronger adoption into trusted chrome
- one Omnibox stronger action that jumps into a small shell-owned review lane instead of finishing inline
- one Exchange publish / reveal / guarded-link confirmation that lands in trusted chrome rather than in app content
- one Terminal/Capshell prompt where title changes,
  clipboard writes,
  or link-open requests produce host-effect witnesses with visible allow / held / denied posture

## Judgment

The next strong import is not another pillar,
and not a giant policy language.
It is a small shell law:

**authority-bearing review belongs to trusted chrome,
while weaker-origin content can only request shell-side effects through visible witnessed seams.**
