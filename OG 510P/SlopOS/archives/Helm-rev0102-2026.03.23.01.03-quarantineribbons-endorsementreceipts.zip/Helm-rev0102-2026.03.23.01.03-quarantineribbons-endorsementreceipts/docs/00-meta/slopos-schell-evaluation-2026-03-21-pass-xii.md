# SlopOS + Schell evaluation — 2026-03-21 — pass XII

Purpose: keep using SlopOS and Schell as design teachers while Helm decides what deserves a freeze, what deserves a specimen, and what should stay pressure only.

This pass focuses on three linked questions:

1. should terminal/capshell count as an eighth pillar,
2. what first proof slice will best test Helm's shared truth model,
3. and which shell luxuries should stay strategic pressure rather than architecture-leading commitments.

The current answer now looks clearer than it did in earlier passes:

- **Helm should keep seven pillars**,
- **terminal/capshell should be treated as Helm's native shell-facing front-end family rather than as an eighth truth-domain pillar**,
- and the first proof-bearing slice should be a compact cross-pillar path:
- **exact object → reviewed action → route → receipt → recall**.

## What SlopOS pressures most strongly now

### 1. SlopOS keeps insisting that the shell/compositor owns the truth domains

The SlopOS datacube keeps narrowing portable seams so that mediated launch,
activation,
reveal,
request state,
and consent remain shell- or portal-owned rather than requester-owned folklore.

That pressure matters here because it separates:
- a **truth domain** the shell must own,
from
- a **front-end family** that can enter,
inspect,
and act over that truth.

Tiling,
objects,
operations,
continuity,
exchange,
and automation all describe desktop truth domains.
Terminal/capshell mostly does not.
It is a privileged entry and inspection family over those domains.

### 2. Exactness pressure says the first proof slice should cross surfaces, not just words

SlopOS keeps teaching that exact reveal/select,
request-vs-live truth,
and fail-closed semantics beat flattering approximation.
That makes a giant vague Phase-1 wish list less useful than one compact slice where exactness either survives or fails visibly.

The cleanest such slice is:
- one exact object,
- one exact action,
- one visible route,
- one receipt or denial,
- and one truthful later return path.

That slice naturally touches Omnibox,
Object Browser,
Exchange,
Operations Center,
Recall,
and terminal/capshell without forcing a full grand theory of everything first.

### 3. Preview, Overview, and Capsules are strategic pressure, but not good architecture leaders yet

SlopOS's discipline says these luxuries should exist only once they sit on shared truth instead of compensating for missing truth.
That means:
- **Preview** is strategic because inspect-before-commit is shell-wide power,
- **Overview** is strategic because spatial state should be glanceable,
- **Capsules** are strategic because continuity needs honest artifacts,
- but none of them should become the first thing that decides architecture or pillar boundaries.

## What Schell adds to the picture now

### 1. Schell makes terminal work more central without turning it into a separate product truth domain

The latest Schell revision keeps expanding terminal-local luxuries:
- trusted command blocks,
- prompt budgets and cheap-delight timing lanes,
- object cards,
- transcript cards,
- exact open bridges,
- command decks,
- launch kits,
- detector witnesses,
- hyperlink/media witnesses,
- and handoff ladders.

That is exactly why terminal/capshell matters so much.
But the same archive keeps repeating a restraint:
- the shell owns reviewed action truth,
- packets/witnesses stay explicit,
- rich terminal UX stays local luxury unless it earns a broader shell contract,
- and local caches/warm state do not become a new authority plane.

That is much closer to **front-end family over shared shell truth** than to **eighth pillar with its own separate desktop ontology**.

### 2. Schell now gives Helm a sharper first proof slice

The newest Schell directions repeatedly converge on one family of actions:
- exact object cards,
- inspect/reveal/open/safe-open ladders,
- reviewed actions,
- route witnesses,
- exact handoff bundles,
- repair cards,
- source-labeled recall,
- and history that stays weaker than current live authority.

That is the same cross-pillar slice Helm most needs.
It also peels the old inspirations apart correctly:
- i3 contributes spatial discipline,
- Rofi contributes summon-and-dispatch,
- Dolphin contributes exact browse/reveal/preview,
- the “god-tier task manager” contributes receipt/failure/live-state honesty,
- AHK contributes a visible raw lane,
- while Schell contributes the shell-facing review/receipt/witness shape.

### 3. Schell strengthens a useful timing lesson for Helm

One of the strongest young Schell ideas is that luxury should live in named timing lanes:
- keystroke lane,
- prompt-render lane,
- explicit summon lane,
- idle repair lane,
- historical lane.

The lesson for Helm is broader than the terminal:
**warm state, repaired previews, and rich summon help should act as accelerators, not as the truth plane.**
That helps Preview,
Overview,
Recall,
and Omnibox avoid haunted-smartness failure modes.

## What now looks earned in Helm

### Worth freezing now

- **Helm has seven pillars**
- **terminal/capshell is Helm's native shell-facing front-end family**

Why this now looks earned:
- it matches the current SlopOS lesson about shell-owned truth domains,
- it matches the current Schell lesson about terminal-local luxury over shared truth,
- it reduces archive vocabulary drift,
- and it avoids letting terminal convenience silently choose all of Helm's architecture.

### Worth naming as the current preferred proof slice

- **exact object → reviewed action → route → receipt → recall**

Why this now looks right:
- it proves shared truth across multiple pillars,
- it forces exactness,
- it survives both terminal and non-terminal surfaces,
- and it peels the old inspirations into powers instead of look-and-feel clones.

## What Helm should explicitly not freeze yet

- Preview,
  Overview,
  and Capsules as promoted pillars
- a final terminal language or final attach/restore doctrine
- a giant workspace/dashboard/cockpit front door before the proof slice exists
- a full branch/merge/collaboration constitution for shadow work lanes
- a claim that DelayBasin is still a core product teacher rather than mostly an archive-method teacher

## Current bounded take

The strongest pass-XII take is:

**Helm should normalize its product vocabulary around seven pillars plus one native terminal/capshell front-end family, and it should concentrate early proof work on one compact cross-pillar slice: exact object → reviewed action → route → receipt → recall.**

Everything else in this pass — Preview,
Overview,
Capsules,
quicklinks,
prompt luxuries,
command-boundary witnesses,
subflows,
prefabs,
and cheap-delight lanes — should keep pressuring the architecture without claiming pillar status yet.
