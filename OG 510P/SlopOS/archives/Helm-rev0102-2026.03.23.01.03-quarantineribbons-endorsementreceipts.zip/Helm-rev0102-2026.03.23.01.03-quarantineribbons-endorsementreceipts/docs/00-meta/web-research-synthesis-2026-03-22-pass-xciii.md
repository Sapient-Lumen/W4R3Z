# Web research synthesis — pass XCIII — 2026-03-22

## Headline

The current outside pressure says Helm should add a small **quiesce / drain grammar**.
The main lesson is not “pause everything.”
It is:

**separate stop-taking-new-work from force-stop,
and keep drain truth visible while the in-flight work settles.**

## Strongest outside patterns

### 1. Kubernetes: cordon / drain / uncordon is a real state machine

Kubernetes keeps maintenance honest by splitting:
- scheduling disabled,
- graceful eviction/drain,
- disruption-budget respect,
- and later resumption via uncordon.

That is a strong proof that “temporarily not admitting new work” deserves its own visible shell object.
It is not the same as dead,
failed,
or forgotten.

### 2. HAProxy: ready / drain / maint are different administrative truths

HAProxy is especially crisp:
- `ready` is ordinary service,
- `drain` removes the server from load balancing but still allows health checks and persistent connections,
- `maint` disables traffic and health checks.

That distinction is gold for Helm.
It suggests one shell should be able to say:
- **serve normally**,
- **do not take new entrants but let existing affinity/live ties settle**,
- or **full maintenance / hard isolation**.

### 3. XDG Desktop Portal Inhibit: narrow, handle-based inhibition with a user-visible reason

The portal model is not a giant ambient scheduler.
It is a small request handle with explicit inhibited classes and a user-visible reason.
That is the right flavor for Helm too:
maintenance should be attributable,
closeable,
and reason-carrying.

### 4. Temporal: cancellation versus termination remains explicit

Temporal keeps graceful interruption and forceful termination separate.
That maps directly onto Helm's need to keep `drain/cancel cooperatively` distinct from `cut through now`.

### 5. Spotlight live queries: pause updates while inspecting a moving result set

Apple's old but still-clever `NSMetadataQuery` guidance shows one more subtle lesson:
live update streams should sometimes be **temporarily paused while results are being processed**,
then resumed.
That is a nice pattern for Helm Browser/Recall surfaces where live-derived views would otherwise wriggle while the operator is trying to inspect them.

## What this means for Helm

Helm should probably warm two shell-owned objects:

### Quiesce rails
A compact control surface that can:
- begin `drain` or `cancel` mode,
- name the subject or cohort,
- show reason and budget,
- block new work honestly,
- and expose resume / escalate separately.

### Drain witnesses
A compact status/evidence surface that can say:
- how many exact items are still in flight,
- what is blocking quiescence,
- whether the current state is historical-only or live-confirmed,
- whether cut-through happened,
- and what receipt records the end of the story.

## What not to steal

Do not steal:
- global maintenance religion,
- hidden backlog semantics,
- fake guarantees that quiescent means exportable or share-safe,
- or one giant stop button that conflates drain, cancel, terminate, detach, forget, and revoke.

## Main judgment

This is worth warming now.
It sharpens Operations Center,
helps trusted chrome stay honest during stronger maintenance acts,
and gives Helm a humane answer to one of the oldest shell failures:
pretending “paused” means the same thing as “quiet,” “done,” “safe,” or “gone.”
