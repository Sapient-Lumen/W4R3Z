# Web research synthesis — 2026-03-22 — pass LXII

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

## What changed this pass

The outside pattern is now strongly about **time-and-change witnesses**.

Current tools keep inventing:
- annotations,
- markers,
- change events,
- incident timelines,
- and historical-similarity lanes.

The healthy shared lesson is not “build a giant timeline.”
It is:
**people need small exact markers that help correlate what changed with what they are now seeing.**

## 1. Grafana validates query- or panel-bound event markers

Grafana's annotation model is very strong evidence for a small marker object:
- you can create annotations directly in panels,
- fetch them from data sources,
- show them as event markers across a dashboard,
- scope them to a dashboard/panel or use broader organization annotations,
- and filter them by tags.

The strongest lesson is that the marker is:
- small,
- query/display-adjacent,
- and useful precisely because it does **not** try to become the whole dashboard or the whole incident record.

Grafana also supports range/region annotations,
which is important.
Some things are points.
Some things are spans.
Helm should keep both.

## 2. Datadog reinforces the value of manual, portable “this mattered here” notes

Datadog annotations are very plain and very telling:
- manual vertical markers,
- descriptions,
- precise time adjustment,
- and persistence when a widget moves from dashboard to notebook.

That portability lesson is especially good for Helm.
A useful marker should be able to stay attached to the nearby derivative surface or investigation surface without pretending it is the same thing as either one.

## 3. Honeycomb adds the scope lesson: local versus wider markers

Honeycomb's marker model adds two strong ideas:
- markers can be point or range based,
- and markers can be dataset-local or environment-wide.

That maps very cleanly onto Helm.
Helm likely needs:
- view-local markers,
- activity-local markers,
- and perhaps wider environment/service markers.

But the scope should stay visible.
A local marker and a cross-activity marker should not look identical.

Honeycomb's marker settings also suggest a useful secondary move:
marker type / grouping and stable display cues.

## 4. PagerDuty sharpens the “recent changes” and “past incidents” lessons

PagerDuty's Recent Changes model is especially helpful because it keeps **change events** separate from incidents while still correlating them.
It shows:
- recent change events,
- explicit detail pages with timestamp/source/links,
- time-based change correlation,
- related-service change correlation,
- and intelligent correlation based on time, metadata relation, and prior frequency.

That is exactly the kind of thing Helm should steal carefully.
Not the giant AIOps ambition.
The smaller move:
- keep recent exact changes nearby,
- show why they are being surfaced,
- and never let “near in time” quietly become “proven cause.”

PagerDuty's Past Incidents feature adds another valuable lesson:
- historical similarity is useful,
- same-service scoping is healthy,
- and recent vs relevant are meaningfully different sorts.

That suggests Helm should eventually support small historical-neighbor lanes near markers,
watchpoints,
or briefs.

## 5. Atlassian reinforces that manual timeline entries still matter

Atlassian's incident timeline posture reinforces that timelines are most useful when they combine:
- automatically gathered updates,
- linked alert changes,
- edits,
- and manual entries from people doing the work.

That argues for a mixed-authorship marker grammar in Helm.
A marker should be able to say:
- receipt-derived,
- imported,
- machine-suggested,
- or human-authored.

Flattening those into one anonymous event stream would be a mistake.

## 6. What Helm should steal now

Steal:
- point-or-range markers
- exact source witness where possible
- marker tags/types
- local-versus-wider scope posture
- recent-change correlation cues with explicit reasons
- recent-versus-relevant sorting when historical neighbors are shown
- manual and imported markers in the same grammar with visible authorship/provenance
- strong jump-back-to-source from every marker

Do not steal:
- giant universal timeline ambition
- hidden ingestion/event-bus folklore
- wording that confuses temporal proximity with proof of causality
- giant annotation sprawl everywhere
- timeline surfaces that silently outrank the source view, watchpoint, or receipt

## Judgment

The strongest next compact move is one shell-owned **timeline marker** object.
It should support:
- point or range,
- exact source witness,
- scope posture,
- authored/imported provenance,
- type/tag cues,
- and nearby correlation hints,
while staying weaker than current-live truth and weaker than the stronger source objects it references.
