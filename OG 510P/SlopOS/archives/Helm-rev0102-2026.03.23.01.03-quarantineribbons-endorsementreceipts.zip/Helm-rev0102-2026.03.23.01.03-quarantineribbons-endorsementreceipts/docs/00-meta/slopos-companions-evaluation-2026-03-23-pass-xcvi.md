# SlopOS + companions evaluation — 2026-03-23 — pass XCVI

Purpose: re-read the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one tighter question:
**what should Helm learn now about foreign arrivals, risky imports, safe-open posture, and explicit endorsement while those companion cubes are still in design phase?**

## 1. SlopOS keeps teaching that arrival is not clearance

The SlopOS quarantine and preview family still presses a simple but expensive truth:
**visibility is not endorsement.**
A result can be listed,
previewed,
opened in a weaker lane,
or carried through a route witness
without becoming trusted enough to execute,
adopt,
or reopen as if nothing risky ever happened.

Helm should steal that law everywhere foreign material appears:
- recents should not erase the arrival story
- previews should not clear the source object
- copied or re-exported things should not quietly impersonate the old object
- a helper success should not silently clear shell risk posture

## 2. ViewFS is the clearest direct teacher here

`origin-quarantine-and-trust-transitions.md` and RFC 0015 are unusually crisp.
They separate:
- origin evidence,
- quarantine / risk state,
- preview or safe-open session,
- explicit clear / trust decision,
- sanitized derivative,
- and live open / exec authority.

That is exactly the seam cut Helm needs.
Not a giant provenance graph.
Not a giant trust console.
Just one humane shell grammar that refuses to flatten these meanings.

## 3. Schell keeps the interaction law honest

Schell's object-card and safe-open work says the ladder itself matters:
- inspect
- reveal exact item
- open containing place
- insert into active input
- open normally
- safe-open instead
- request stronger action

That is a very Helm-shaped lesson.
When foreign material arrives,
**staging is often better than launch**,
and safe-open should be a separately named downgrade path,
not a hidden variant of open.

## 4. Steward keeps teaching shell-owned posture and label humility

Steward keeps being useful because it refuses decorative confidence.
A shell should say:
- blocked,
- restricted,
- safe-open only,
- endorsement requested,
- or endorsed exact object,

rather than blur everything into one flattering badge.
That matters even more when arrival risk is part of the story.

## 5. The design-phase lesson is now very clear

Because these cubes are still in design phase,
Helm should mostly steal:
- seam cuts,
- arrival honesty,
- preview-vs-open-vs-endorse discipline,
- derivative-versus-source distinction,
- exact-route and exact-reveal posture,
- and shell-owned anti-spoof mediation.

Helm should mostly avoid stealing:
- giant provenance graphs,
- giant trust dashboards,
- broad trusted-location folklore,
- or any theory that one successful preview should clear future stronger acts automatically.

## 6. Best next Helm moves after this re-read

### Pull warmer now
- **quarantine ribbons**
- **endorsement receipts**
- safe-open ladders as one first-class review lane story
- derivative-vs-source truth surviving recents and reopen

### Keep warm only
- giant reputation consoles
- broad publisher-trust registries
- universal sanitization pipelines
- any path-wide bypass mythology

## Judgment

The companion cubes are still strongest when they teach **laws, not lavish machinery**.

Helm should take the next step by making foreign-arrival truth much more legible:
- where the thing came from,
- whether it is still quarantined,
- whether the operator is only safe-opening it,
- whether one exact object was explicitly endorsed,
- and whether a later derivative is a fresh artifact instead of the same object with a cleaner vibe.
