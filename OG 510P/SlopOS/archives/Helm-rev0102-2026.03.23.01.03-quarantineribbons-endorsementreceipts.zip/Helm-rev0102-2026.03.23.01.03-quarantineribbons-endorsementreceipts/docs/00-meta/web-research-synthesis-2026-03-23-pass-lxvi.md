# Web research synthesis — 2026-03-23 — pass LXVI

Question: after basis stamps, what small durable cross-cutting move still looks missing for Helm's datacube?

Answer from this pass: **exact proposed-change objects plus fail-closed-on-drift gates**.
The strongest next compact move is now **action warrants + drift gates**.

## What current tools keep teaching

### 1. Good systems separate proposal from live truth

GitHub is still the clearest mainstream proof.
A pull request is not the live branch.
It is an explicit proposal object for reviewed change.
GitHub's review flow keeps the diff,
per-file comments,
viewed progress,
and an explicit approve/request-changes boundary nearby.
Figma branching keeps the same shape in design form:
a branch is a controlled environment,
reviewers can preview what changed,
and merge is the explicit act that applies those changes to the main file.

The pattern is not “copy Git literally.”
It is:
**strong change deserves a bounded proposal object before it becomes live truth.**

### 2. The best systems reject silent rebinding when mutable basis moved

GitHub's REST endpoint for updating a pull-request branch accepts `expected_head_sha` and returns a 422 if that SHA no longer matches.
Its GraphQL inputs also expose `expectedHeadOid` on auto-merge,
merge,
and enqueue operations.
That is exactly the law Helm wants:
if a strong act depended on one reviewed head,
fail instead of quietly retargeting the act onto a newer one.

HTTP conditional requests teach the same thing at protocol scale.
`If-Match` is explicitly about preventing the lost-update problem,
and the server must not perform the method when the condition fails.
This is not just web trivia;
it is a durable actuation law.

### 3. Drift gates are better when they explain *why* the act downgraded

Kubernetes gives a second strong lesson.
The platform uses `resourceVersion` for optimistic concurrency control,
and server-side apply surfaces explicit conflicts when one manager would overwrite another manager's fields.
That is much closer to what Helm needs than a vague stale badge.

A useful Helm drift gate therefore should not only say `drifted`.
It should be able to say:
- target revision changed
- affected-set changed
- field ownership/conflict widened
- source query expired
- provider/route changed
- privilege posture widened

### 4. Reviewable change does not require giant workflow ambition

The good part to steal from GitHub and Figma is not giant team ritual.
It is the compact grammar:
proposal,
review,
explicit merge/apply,
and conflict or refresh when basis moved.

Helm can keep this shell-sized.
An action warrant can stay smaller than a PR,
smaller than a case,
and smaller than a workflow run.
A drift gate can stay smaller than a policy engine.

### 5. Basis stamps now have an obvious next home

Basis stamps answered:
**what exact basis is this thing speaking from?**

This pass says they are most powerful when carried inside stronger proposal objects.
The warrant can carry the basis stamp,
affected-set witness,
context witness,
and next-step ladder.
The drift gate can compare that basis stamp against current mutable truth.
The result is a safer shell-wide action grammar.

## What Helm should steal

- explicit proposal objects for stronger mutable acts
- exact reviewed-basis guards on stronger rungs
- fail-closed or downgrade-on-drift posture instead of silent latest-following
- visible affected-set or conflict summary before apply
- compact review flows that stay smaller than giant ticket systems
- explicit post-act siblings such as effect receipts after success or refusal

## What Helm should not steal

- turning every small interaction into PR theater
- giant workflow or ticket-engine ambition
- silent rebinding to the newest mutable head
- green confidence badges that hide basis drift
- forcing the operator to leave the shell to learn what exact thing would change

## Why this matters to the pillars

This is not a new pillar.
It is one cross-cutting action honesty move that helps almost every existing one:

- **Omnibox** can graduate from vague quick action into exact proposed change
- **Object Browser** can promote preview into warrant instead of generic apply
- **Desktop Flow** can hand strong effects off to reviewable warrants instead of fire-and-forget scripts
- **Recall** can reopen older acts behind drift gates instead of fake sameness
- **Exchange** can make attach/import/publish acts exact instead of route folklore
- **Operations Center** can show pending strong acts,
drifted acts,
and effect aftermath as honest separate states

## Judgment

The next small durable proof worth warming is **action warrants + drift gates**.
Helm does not need a giant workflow religion.
It needs one compact reusable way to say:

**this exact strong change is being proposed,
and this is whether the reviewed basis still binds strongly enough to proceed.**
