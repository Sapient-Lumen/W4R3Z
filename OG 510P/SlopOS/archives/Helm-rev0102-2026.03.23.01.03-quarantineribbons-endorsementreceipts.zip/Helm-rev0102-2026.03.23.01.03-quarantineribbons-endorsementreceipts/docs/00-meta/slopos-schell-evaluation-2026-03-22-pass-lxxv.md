# SlopOS / Schell evaluation — 2026-03-22 — pass LXXV

Purpose: keep evaluating the uploaded teacher archives while testing whether Helm now needs one more cross-cutting law around **least reach, exact selected cohorts, and no silent widening**.

## Main takeaway

This reread keeps pointing at the same discipline from a new angle:

**travel, reveal, grant, and continuity are all still too flattering if they silently widen the subject set.**

SlopOS keeps teaching that exact reviewed local success does not magically become:
- account-selection truth,
- whole-provider truth,
- portable current authority,
- or wider reveal truth.

That is not just an auth lesson.
It is also a datacube lesson.

## What feels worth keeping from SlopOS

### 1. Exact bounded subject posture

SlopOS repeatedly prefers exact reviewed objects and explicit bounded adjuncts over broad ambient planes.
That keeps pushing Helm away from “this action works over the whole workspace/account by default” and toward “this action names one admitted cohort.”

### 2. No hidden widening from nearby folklore

The auth-mediation family remains harsh about login not implying account selection, password-manager behavior, autofill, portable auth results, or broad provider truth.
For Helm that generalizes into:
- selected item is not selected family,
- selected family is not provider/account/workspace truth,
- and retry is not permission to widen.

### 3. Family maps beat giant grand theory

SlopOS keeps winning when it adds one more explicit family surface rather than one more universal abstraction.
That argues for a small Helm pair:
- cohort windows
- minimization ladders

not a giant governance suite.

## What feels worth keeping from Schell

Schell still helps most around shell-facing seams where explicit target/selection packets keep attach, forward, restore, and route posture honest.
That pressure is compatible with cohort windows:
selected targets should stay exact, and the shell should resist quietly broadening them into “the likely full set.”

## What Helm should now learn

1. **Loadout is not cohort.**
   A context loadout may carry many ingredients; a strong reveal/export/action may still need a smaller exact cohort.

2. **Authority is not cohort.**
   An authority window can say power exists, but cohort windows should still say what exact slice that power is being exercised over.

3. **Audience is not cohort.**
   Reveal windows say who can see; cohort windows should still say what exact slice is visible.

4. **Saved exactness is worth preserving.**
   Reopening, handoff, and helper work should preserve the original exact cohort witness instead of quietly broadening to current whole-family truth.

## Judgment

The next wise move is still not a new pillar.
It is a small shell-wide law:

**Helm should keep exact selected cohorts first-class, and broadening should be a fresh stronger step with a visible why.**
