# SlopOS / Schell evaluation — 2026-03-22 — pass LV

Purpose: re-read the latest SlopOS and Schell bundles after the newest outside pass,
and ask what their design-phase pressure says about **linked views, profile-scoped front doors, exact front-door handles, and suggestion-first triage**.

## Main takeaway

The latest SlopOS bundle keeps agreeing with the fresh outside research:

**composition is good,
but composition must not smuggle authority.**

That means Helm can safely get more ambitious about linked views and front-door handles,
so long as it keeps four SlopOS laws intact:
- explicit view ownership,
- explicit slot/materialization steps,
- bounded non-authoritative projections,
- and no hidden import/adopt/live promotion.

## What the latest SlopOS bundle keeps teaching here

### 1. Linked views are fine if they stay derivative and source-witnessed

`state-projection-schema-v0.md` still teaches the clearest general rule:
small projections are useful precisely because they are bounded,
deterministic,
and non-authoritative.

That transfers cleanly to Helm linked views.
A linked view inside a deck,
entry kit,
or cockpit card should stay:
- explicitly borrowed,
- source-witnessed,
- basis-aware,
- and weaker than the stronger truth it points to.

### 2. Explicit view objects and explicit slot mutation matter even more now

`view-namespace-posture-v0.md` and `view-replication-boundary-v0.md` keep pressing the same exactness law:
a view is explicit,
slot mutation is explicit,
and replicated/read-only view state must not auto-activate locally.

This is an excellent teacher for Helm.
If a linked or imported view arrives from somewhere else,
Helm should allow inspection,
borrowing,
and restricted use,
but any stronger receiver-local activation still needs an explicit step.

### 3. View-scoped query supports triage lanes and borrowed work views

`attrfs-posture-v0.md` remains one of the most directly reusable datacube docs in SlopOS.
No ambient global index,
no cross-view oracle,
and queries run against an explicit authorized view.

That means Helm can safely make triage lanes,
linked work views,
and smart front doors feel rich,
without ever claiming there is one secret system-wide cube behind everything.

### 4. Generic open still should not smuggle import or durable local truth

`openuri-materialization-boundary-v0.md` continues to teach the humility Helm needs for front-door handles.
A tiny handle can be powerful.
But selecting it should not by itself mint durable local objects,
adopt imported structure,
or silently escalate to the strongest possible launch path.

That is the right law for Helm's tiny front-door handles too.
They should point,
route,
open,
compare,
attach,
or propose stronger acts.
They should not bluff that those acts already happened.

### 5. Read-only replicated view state is a direct warning against fake shared liveness

`view-replication-boundary-v0.md` is especially relevant now.
Replicated view information may exist,
but it stays read-only,
cache-shaped,
and non-activating until an explicit local step occurs.

Helm should import that law almost whole.
Shared or imported front doors,
linked views,
and deck members should be allowed to travel.
But receiver-local live posture must remain earned,
not ambiently inherited.

## What Schell pressure still says

Schell is still too design-phase to justify freezing a large universal shell-facing worldview.
But it still reinforces several truths that matter to this pass:
- entry posture matters,
- reviewed basis matters,
- profile/account/session scope matters,
- and saved shell objects should not impersonate current authority.

That supports **profile-scoped front doors**.
It does not support silent profile choice,
ambient session inheritance,
or fake exact return.

## What Helm should import from this evaluation

### 1. Linked views by reference, not copy
A linked view should remain a borrowed derivative surface with source and basis witness.

### 2. Front-door handles smaller than entry kits
A small exact handle now looks safe and useful,
provided it stays clearly weaker than live truth.

### 3. Explicit profile-affinity instead of silent profile choice
Helm can and should remember preferred scope axes.
It should not quietly claim those axes are already valid now.

### 4. Suggestion-first triage over view-scoped data
Helm should prefer explainable suggestions and view-scoped routing surfaces,
not global invisible intelligence.

## What Helm should avoid

1. **Do not let linked views become copied state with hidden drift.**
2. **Do not let imported/shared front doors auto-activate receiver-local truth.**
3. **Do not let quick handles count as durable adoption or current-live proof.**
4. **Do not let profile affinity become silent scope widening.**
5. **Do not let triage intelligence become an ambient background law before suggestion posture is proven.**

## Judgment for Helm

SlopOS and Schell are still in design phase,
which makes this exactly the right moment to steal the correct moves while refusing premature constitutions.

So Helm should now:
- keep the seven pillars stable,
- keep saved view objects and checkpoint branches as the strongest proof targets,
- warm **linked views** and **exact front-door handles** as the best next support contracts,
- sharpen **profile-scoped front doors** in existing entry-kit law,
- and keep **triage intelligence** in suggestion posture until stronger review/warrant machinery proves itself.
