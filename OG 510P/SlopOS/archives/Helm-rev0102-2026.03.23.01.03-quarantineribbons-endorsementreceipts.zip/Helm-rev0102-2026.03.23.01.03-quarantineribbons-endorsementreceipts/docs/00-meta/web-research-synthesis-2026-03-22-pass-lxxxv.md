# Web research synthesis — 2026-03-22 — pass LXXXV

Question for this pass:
**what should Helm add next if budgets, leases, renewal rails, change cursors, retry keys, and teardown rails all look right, but blocked stronger acts still feel too mysterious and too widening-prone?**

Answer:
add two compact support moves:
- **access verdict cards** for exact blocked/allowed posture with determining reasons,
- and **least-widening previews** for counterfactual “what is the smallest stronger delta that would make this work?” honesty.

## 1. AWS IAM policy simulation keeps proving that counterfactual checks are useful — but weaker than live truth

AWS's IAM policy simulator can test identity policies, permissions boundaries, selected resources, and context keys.
It is great for learning why something should or should not work.
But AWS is equally blunt that simulator results can differ from the live environment.

That is a superb Helm lesson.
A shell should absolutely help the operator ask:
- would this exact act be allowed,
- what boundary blocked it,
- and what smaller policy or scope delta would likely admit it?

But Helm should never let a simulation masquerade as current-live authority.
A **least-widening preview** should stay clearly weaker than an active authority window,
a current-live beacon,
or a finished effect receipt.

## 2. Google Cloud Policy Troubleshooter keeps proving that denied access should come with relevant policy reasons

Google's Policy Troubleshooter examines allow,
deny,
and principal access boundary policies for one principal,
one resource,
and one permission.
Then it tells you whether the action is allowed and lists the relevant policies with explanation.

That is almost exactly the product law Helm needs.
Blocked stronger acts should not flatten into one red disabled button.
An **access verdict card** should be able to say:
- exact subject,
- exact requested act,
- allowed / denied / restricted / stale / hidden-policy / unsupported posture,
- determining blockers when known,
- and whether the shell lacks enough visibility to explain the answer fully.

## 3. `kubectl auth can-i` keeps proving that exact authorization questions are better than vague role folklore

`kubectl auth can-i` asks a tiny question:
can this actor perform this exact verb on this exact resource or object?
It also pairs with impersonation.

That suggests Helm should prefer tiny exact verdict queries over giant role summaries.
Before widening a grant,
Helm should be able to ask:
- can the current lane do this exact thing now,
- could the isolated lane do it,
- could a current-only or exact-subject grant do it,
- or is a stronger rung genuinely required?

## 4. VS Code Restricted Mode keeps proving that blocked features can still be productively inspectable

VS Code's Restricted Mode disables or limits AI agents,
tasks,
debugging,
workspace settings,
and extensions.
It also exposes the full list of disabled features in the Workspace Trust editor.

That is a very strong teacher for Helm.
A blocked act should still have a useful inspect surface.
The shell should be able to say:
- blocked because this lane is restricted,
- here is the class of disabled features,
- inspect is still safe,
- and here is the narrowest promotion or trust step that would change the answer.

## 5. Cedar keeps proving that authorization answers should include diagnostics,
not just yes/no

Cedar's authorizer returns a decision plus diagnostics,
including determining policies and errors.
That means the system does not treat explanation as an afterthought.
It treats it as part of the decision output.

Helm should steal that.
An access verdict card should separate:
- the verdict,
- the determining blocker or permit source,
- hidden/unknown visibility gaps,
- and candidate next deltas.

But it should not let diagnostics become standing authority.
The verdict card is explanation,
not permission itself.

## 6. Access previews and runtime optional permissions point toward least-widening as a first-class shell move

AWS Access Analyzer can preview proposed external access before deployment.
Chrome's `chrome.permissions` API requests declared optional permissions at runtime so users understand why they are needed and can grant only what is necessary.

Together they suggest a great Helm move:
**before widening,
show the smallest plausible widening candidate and the weaker alternatives.**

A least-widening preview should be able to compare:
- inspect-only,
- current-only,
- exact-subject,
- isolated-lane,
- activity-scoped,
- guarded-link instead of public,
- or broader persistent scope.

## 7. OPA dry-run and decision logs reinforce one more useful law

OPA's Envoy plugin can run in `dry-run` mode,
allow requests,
and use decision logs to show what would have happened.
This is a strong reminder that “what would be denied” and “what is denied live” should stay visibly different truths.

Helm can borrow that as a weaker rung:
- preview the likely policy result,
- but keep the live verdict,
- the simulated verdict,
- and the eventual effect receipt separate.

## 8. What Helm should steal now

- **Access verdict cards** beside blocked or gated stronger acts
- **Least-widening previews** that compare narrow alternative rungs before broad grants
- **Visibility-gap posture** such as hidden-policy,
  hidden-source,
  or insufficient-explanation rights
- **Restricted-but-inspectable posture** rather than all-or-nothing blocked UI
- **Exact subject + exact act framing** instead of giant permission folklore
- **Counterfactual previews** that stay visibly weaker than live authority

## 9. What Helm should resist

- letting simulated or previewed access masquerade as live truth
- auto-widening authority just because explanation is missing
- flattening blocked,
  stale,
  hidden,
  unsupported,
  and denied into one generic failure state
- turning the shell into a giant IAM console
- teaching people to ask for broad persistent grants first

## Synthesis for Helm

Helm already has:
- capability budgets,
- lease windows,
- renewal rails,
- change cursors,
- retry keys,
- teardown rails,
- claim envelopes,
- and reliance ladders.

The next honesty layer is:
- **access verdict card** = what exact act is blocked or allowed,
  by what known blocker,
  with what visibility gaps
- **least-widening preview** = what smaller stronger delta could admit it,
  if any,
  without pretending that preview is already a grant

That pair would make Helm unusually good at one painful everyday problem:
**not just saying no,
but saying no truthfully,
inspectably,
and with the smallest honest next move.**
