# Web research synthesis — 2026-03-22 — pass XLV

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move is to sharpen **explicit scoped memory** instead of letting context creep back in through ambient magic.

This pass focused on one question:

**once Helm has saved views, checkpoints, activity spines, resource shelves, entry kits, current-live beacons, and scope witnesses, what tiny shell-owned thing should say what is intentionally remembered for this activity?**

## Main takeaway

The outside world is validating a pressure that is easy to miss:

**Helm likely wants explicit activity memory seeds, and perhaps later tiny context recipes built from them.**

Not a giant memory brain.
Not ambient history mining as the default truth plane.
Not a hidden AI profile that quietly widens scope.

A good Helm answer would likely be:

- **activity memory seeds** — explicit shell-owned remembered facts, snippets, instructions, or pointers with source witness and scope posture
- **context recipes** — small ordered bundles of seeds/instructions that can help Omnibox, Recall, entry kits, and planning surfaces without pretending they are live truth

## What the outside world is validating now

### 1. Scoped memory is getting tighter, not looser

ChatGPT Projects is one of the clearest current proofs.
Projects can gather chats and files under one objective.
Project-only memory keeps the context bounded to the project.
For Business users, shared projects are forced into project-only memory.

That is a very Helm-shaped lesson:
**sharing should often tighten memory boundaries rather than widen them.**

### 2. Explicit remembered context is more believable than ambient context

ChatGPT Atlas makes browser memories explicit.
The operator can turn them on,
see them,
archive them,
clear them,
and prevent memory creation on specific sites.
Atlas also exposes a concrete “remember this” move from page text.

This is important because it validates a better shell magic:
not “the system secretly learns everything,”
but “the system lets me intentionally keep a few useful remembered things.”

### 3. Scope-local instructions and repeatable prompts are becoming first-class artifacts

VS Code now treats prompt files,
instructions,
custom agents,
skills,
and hooks as explicit customization families.
Prompt files can live in the workspace or user profile.
Parent-repository discovery is off by default,
only works under an actual repository boundary,
and still depends on trust.

That combination is excellent pressure for Helm.
It says remembered context should be:
- explicit,
- typed,
- scope-aware,
- and trust-aware.

### 4. Small shared memory-like artifacts are already working in practice

Raycast Teams lets people share quicklinks and snippets.
Those are not giant knowledge bases.
They are compact reusable remembered actions and fragments.

This matters because Helm does not need to jump from “no memory” to “full agent memory.”
There is a rich middle zone of:
- saved snippets,
- saved prompts,
- saved quicklinks,
- saved instructions,
- saved object pointers,
- and saved review/playbook fragments.

### 5. Saveable project starters are useful, but they still want remembered context nearby

Warp Launch Configurations,
PowerToys Workspaces,
Chrome saved tab groups,
Linear attached project views,
and Google Docs tabs all show that saveable structure helps users get back into work.
But structure alone is not enough.
Users also need a few remembered local truths like:
- what this activity is for,
- which subview matters most,
- which account/profile is correct,
- and what should be checked before acting.

That is where memory seeds look promising.
They are richer than a label,
smaller than a giant workspace ontology,
and safer than ambient “smart” memory.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Explicit remember-this capture**
   - remember the selected text,
     URL,
     object,
     view,
     route,
     or instruction
   - attach it to the current activity or personal scope
   - do not treat mere open/recent/preview as memory capture

2. **Scope-local memory posture**
   - personal
   - activity-local
   - project/shared
   - imported restricted
   - published starter

3. **Source-witnessed memory seeds**
   - each seed should know where it came from
   - page/object/view/receipt provenance should stay revealable
   - old seeds should be able to go stale without pretending live truth

4. **Memory influence should stay visible**
   - when Omnibox,
     Recall,
     entry kits,
     or planning uses memory seeds,
     a small witness chip should say so

### Tier 2 — steal soon, but keep modest

1. seed aging / last-verified time
2. one “remembered for this activity” chip in entry kits and spines
3. one inspect / archive / forget flow that is easier than hidden settings spelunking
4. tiny context recipes built from a handful of seeds instead of giant prompt files

### Tier 3 — keep warm only

1. ambient scraping of everything you opened
2. hidden cross-scope memory inheritance by convenience
3. treating remembered instructions as live policy authority
4. treating remembered facts as current-live beacons

## Judgment for Helm

Helm should still avoid adding pillars.

But one support move now looks ready to define:

- **activity memory seeds** — shell-owned explicit remembered context with scope, source witness, and stale posture

And one nearby move looks worth warming:

- **context recipes** — tiny ordered bundles of memory seeds, instructions, and starter hints that can help launch/reentry/planning surfaces without becoming a second hidden control plane

The main law is simple:

**what the shell remembers should be explicit, inspectable, scoped, and weaker than live truth.**
