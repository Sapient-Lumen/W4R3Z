# Web research synthesis — 2026-03-23 — pass LXX

Question: after candidate-work honesty, ordered/staged promotion, and post-act receipts, what still feels missing in Helm's small-object grammar?

Answer from this pass: **recovery-side proposal truth**.
The strongest next compact move is now **reversal warrants + repair ladders**.

## What current tools keep teaching

### 1. Good systems do not pretend reversal is history erasure

GitHub's pull-request revert flow is a very clean teacher.
Reverting a merged pull request creates **a new pull request** that contains one revert of the merge commit from the original pull request.
That means reversal is an explicit new proposal,
not a magical deletion of history.

Helm should steal this law directly:
**reversal deserves its own proposal object.**
That object should point back to one exact historical effect,
not blur into “just undo it somehow.”

### 2. Good systems keep rerun scope explicit

GitHub Actions does not give one vague retry button.
It keeps visibly different:
- rerun all jobs
- rerun failed jobs
- rerun one specific job
- optional debug logging on the rerun

That is exactly the shape Helm should import for repair posture.
A user often needs:
- redo the whole exact act,
- rerun only the failed subset,
- rerun one exact item,
- or replay on a fresh basis.

The shell should stop collapsing those into one folklore word like “retry.”

### 3. Good systems distinguish rollback target and rollback speed

Kubernetes `kubectl rollout undo` keeps rollback exact enough to name:
- previous rollout,
- specific revision,
- or server dry-run before applying.

Argo Rollouts adds two more useful lessons.
First,
it has an explicit abort command that stops progression and reverts rollout steps,
but the template still represents the new version until it is changed back.
Second,
its rollback-window feature exists because sometimes the right recovery move is to **skip re-running all the steps** and return quickly to a recent known-good revision.

Helm should steal both ideas:
- reversal can be exact without pretending all history or all authored basis changed,
- and repair can sometimes be a fast recent rollback rather than a full ceremonial re-run.

### 4. Good systems often recover live service first and repair authored history second

Vercel's rollback guide says the sequence is:
roll back to restore service,
investigate the root cause,
and then deploy a fix.
Argo Rollouts teaches something similar from the GitOps side:
a rollback changes the cluster back to the stable version,
marks the application degraded,
and does **not** write back to Git for you.
The expected next step is to fix the issue and roll forward.

This is a hugely important Helm lesson.
The shell should not confuse:
- restoring live usefulness,
- repairing authored basis,
- and publishing a new corrected result.

Those are related,
but they are not the same act.

### 5. Recovery wants a ladder,
not one giant Undo myth

LaunchDarkly guarded rollouts reinforce this too.
A release may be rolled back,
monitoring may be stopped early,
and dependent flags may still need separate rollback work.
Recovery is real,
but it is not universal and it is not always one button.

That maps extremely well to Helm.
A good shell recovery grammar should keep visibly different:
- revert exact effect
- restore to earlier checkpoint
- rerun failed subset
- redo exact act
- replay on fresh basis
- compensate shared/public effect
- hold and inspect
- roll forward with a fix

## What Helm should steal

- one explicit **reversal warrant** as the recovery-side sibling of an action warrant
- one explicit **repair ladder** that keeps rerun / redo / revert / compensate / roll-forward visibly different
- exact tie-back from any recovery move to the historical effect receipt or slot verdict ledger it responds to
- rollback or restore that may help the live lane immediately without silently rewriting authored basis or publication history
- recent-known-good fast paths where replaying every prior step is unnecessary or even undesirable
- dry-run / rehearse / compare-to-current posture before a stronger reversal

## What Helm should not steal

- universal Undo mythology
- retry buttons that do not say whether they rerun everything,
  rerun failed subset,
  or replay on fresh basis
- rollback that quietly rewrites every related authored or shared lane
- compensating repair disguised as true exact undo
- giant incident-management or deployment-control ambition

## Pull-the-trigger judgment

This now looks warm enough to admit as the next compact support proof.
Do **not** make it a new pillar.
Do **not** turn it into a giant recovery court.
But do start proving:
- one reversal warrant tied to one exact prior effect receipt
- one repair ladder that can choose rerun-failed-subset vs reverse-all vs replay-on-fresh-basis
- one shared/public case where live rollback stays separate from authored-history repair
- one drifted case where exact reversal downgrades into compare / branch-and-fix / hold
