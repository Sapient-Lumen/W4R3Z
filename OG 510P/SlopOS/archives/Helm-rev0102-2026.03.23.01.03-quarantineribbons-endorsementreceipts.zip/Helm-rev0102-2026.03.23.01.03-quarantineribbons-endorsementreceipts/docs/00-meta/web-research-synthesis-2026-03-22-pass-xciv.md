# Web research synthesis — pass XCIV — 2026-03-22

## Headline

The current outside pressure says Helm should add a small **grace-budget / cut-through grammar**.
The main lesson is not just “drain.”
It is:

**make the graceful window visible,
name what happens when it expires,
and keep graceful endings separate from forced endings.**

## Strongest outside patterns

### 1. Kubernetes: graceful maintenance is bounded, not mystical

Kubernetes keeps maintenance honest by combining:
- cordon / drain posture,
- PodDisruptionBudget respect,
- eviction that honors `terminationGracePeriodSeconds`,
- and a later `uncordon` step.

That is already a better shell story than “stopping.”
It says:
- no new work admitted,
- current work gets a grace window,
- and resumption is an explicit later act.

### 2. AWS load balancers: draining has a timeout and a post-timeout state

Application Load Balancer target deregistration is refreshingly explicit:
- the target enters `draining`,
- the deregistration delay is a named timeout,
- and then the target becomes `unused`.

That strongly suggests Helm should not show infinite graceful limbo.
A shell should be able to say:
- draining until a deadline,
- immediate finish if nothing remains,
- and a different post-deadline state afterwards.

### 3. Envoy: graceful drain still has a timer and an eventual harder edge

Envoy's graceful listener drain is also crisp:
- there is a graceful drain period,
- the duration is configurable,
- request discouragement changes during that period,
- and listeners are later closed.

That is exactly the kind of bounded honesty Helm should steal.

### 4. systemd: bounded stop with explicit extension messages

systemd sharpens one subtle but very good rule:
shutdown time is bounded,
but a service can explicitly ask to extend that timeout.
The extension is not ambient.
It is a specific message tied to the current state.

That is a strong model for Helm too:
if grace extends,
show the extension as a witnessed act,
not a magical forever-spinner.

### 5. Temporal and nginx: graceful and forceful endings stay visibly different

Temporal keeps cancellation separate from termination.
nginx keeps graceful `quit` separate from fast `stop`.
Those systems are telling Helm the same thing:
**the ending class matters.**
A calm receipt should not hide that the actual ending was forceful.

## What this means for Helm

Helm should probably warm two shell-owned objects:

### Grace-budget chips
A compact shell-owned live chip that can say:
- when graceful maintenance started,
- how much budget remains,
- whether extension is possible,
- and what exact stronger action will happen if time runs out.

### Cut-through receipts
A compact shell-owned historical receipt that can say:
- the graceful story existed,
- the budget expired or an operator escalated,
- the stronger ending that happened,
- and what residual state still requires cleanup or explanation.

## What not to steal

Do not steal:
- giant lifecycle orchestration religion,
- hidden auto-extension,
- infinite stopping spinners,
- or fake post-hoc calm that hides whether a stronger ending took over.

## Main judgment

This is worth warming now.
It makes Helm's maintenance posture more humane,
more bounded,
and more exact about the moment grace stops being grace.
