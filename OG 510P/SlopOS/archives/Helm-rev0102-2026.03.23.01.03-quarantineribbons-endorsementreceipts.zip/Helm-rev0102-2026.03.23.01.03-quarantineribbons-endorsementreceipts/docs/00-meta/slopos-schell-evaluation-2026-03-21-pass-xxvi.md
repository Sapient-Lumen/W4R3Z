# SlopOS / Schell evaluation — 2026-03-21 pass XXVI

Purpose: keep re-reading SlopOS's datacube and the old shell inspirations as teachers,
not dictators,
while Helm keeps adding brilliant ideas without freezing too much too early.

This pass focused on a narrower question:

**what should a traveling Helm surface carry as witness,
and what nearby helpful context can travel with it without becoming fake local truth?**

## 1) SlopOS keeps teaching explicit view objects, not giant ambient state

The more I read SlopOS,
the less “datacube” looks like a mandate for one giant inspectable state warehouse.
RFC-0032 is still the clearest teacher:
views are explicit objects,
name resolution has no fallback,
per-process namespaces are handed off explicitly,
and “mounting” is a mutation of an explicit view object rather than ambient global policy.

That keeps pushing Helm the same direction:
small shell luxuries should be explicit objects,
recipes,
handles,
or manifests over stronger shell truth,
not shadow constitutions.

## 2) The real transferable seam is carried witness plus receiver-local recomputation

SlopOS repeatedly chooses descriptors,
receipts,
and transcript-bound witnesses over portable live claims.
RFC-0046 keeps returning handles instead of raw paths,
models clipboard/drag/drop as bounded transfer descriptors,
and treats high-risk workflows as leases.
OpenURI boundaries keep refusing to let launch imply completion,
materialization,
export,
permission reuse,
or local object identity.

That keeps landing the same Helm lesson:

**travel should carry enough witness to be honest,
but the stronger local truth should still be recomputed or re-earned on the receiver.**

This is exactly why a Helm **landing manifest** now feels earned.
It is the carried-side witness that complements portable cores,
fit cards,
and rebind ladders.

## 3) SlopOS also explains why companion resources should stay secondary

The SlopOS posture around routes,
descriptors,
receipts,
quarantine,
and export boundaries is basically one long anti-smuggling argument.
A launch request should not quietly become a local file,
a durable history record,
a permission grant,
or a hidden browser state choice.

That anti-smuggling law applies cleanly to a Helm-side move around docs,
runbooks,
code links,
queries,
and tickets.
Those are useful travel companions,
but they should remain plainly secondary.
They help the operator understand or land a surface.
They do not become the surface's authority.

That is why **companion resource bundles** now look safe enough to warm into a real candidate contract,
so long as they stay non-authoritative and explicitly subordinate to the primary shell surface.

## 4) Schell pressure still matters,
but not enough to rewrite the product

The older shell inspirations still keep paying rent in the same places:
command-boundary witness,
exact handles,
review/apply posture,
receipts,
source grading,
and fast shell-owned accelerators.
But none of that argues for a new pillar.
It argues for sharper cross-pillar shell moves.

Schell remains more useful as a seam teacher than as a product map.
That is still the right relationship.

## 5) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- projection surfaces still stay bounded and non-authoritative
- portable cores,
  local overlays,
  handoff packets,
  promotion receipts,
  receiver fit cards,
  and rebind ladders still look right
- add **landing manifests** as the source-side travel witness
- add **companion resource bundles** as explicitly secondary travel context

## 6) What still does not seem worth taking

- not a giant universal datacube UI
- not a universal sync constitution
- not ambient receiver-side auto-fit or auto-activation
- not companion resources that silently become authority,
  liveness,
  or trust
- not new pillars

## 7) Current judgment

The most important lesson from this pass is:

**Helm's traveling surfaces should carry explicit witness and optionally useful companions,
but they should still land through honest receiver-local fit,
rebind,
materialization,
or adoption.**

That feels like the right “pull the trigger” level now:
strong enough for new candidate contracts,
still not strong enough for a new pillar or a giant constitutional freeze.
