# Web research synthesis — 2026-03-22 — pass XLVII

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move is to sharpen **output truth posture** instead of only making context/input selection more explicit.

This pass focused on one question:

**once Helm can say what context was selected and what actually influenced the run, what tiny shell-owned thing should say what the output is claiming, how strong that claim is, and what the operator should do next?**

## Main takeaway

The outside world is now validating another pressure that is too strong to ignore:

**Helm likely wants claim envelopes, and probably nearby reliance ladders.**

Not giant provenance theater.
Not one magical confidence score.
Not a flat answer box where sourced facts, model inference, remembered guidance, and proposed actions all wear the same mask.

A good Helm answer would likely be:

- **claim envelopes** — compact shell-owned result objects that separate observed, sourced, derived, remembered, and proposed-action claims
- **reliance ladders** — compact next-step ladders that keep inspect, double-check, save, cite, share, adopt, and apply visibly different strengths

## What the outside world is validating now

### 1. Sources are useful, but products are getting more explicit that sources are not the whole truth story

Gemini Apps can show sources or related links below a response and can also run a double-check pass that highlights statements as likely similar, likely different, or not evaluable against Google Search.
That is a very Helm-shaped lesson:
**a result should separate the claim from the evidence from the follow-up checking move.**

### 2. Current products are admitting that cited outputs can still be wrong

Google Workspace's own guidance now says Gemini can miss a source it used, can cite a document that was not directly used for a specific point, and in some cases can even make up a source.
That is not a reason to abandon source chips.
It is a reason to make Helm outputs more honest about claim class and reliance posture.

### 3. Proposed actions are strongest when they travel through a preview/apply ladder, not a flat answer box

Google Sheets with Gemini now shows analysis steps for data work and uses an action preview card before Apply for spreadsheet mutations.
That validates a shell move where proposed changes are not merely text inside a response;
they should appear as a bounded output object with a stronger next-step ladder.

### 4. Tooling is getting much better at showing loaded context, but not always at showing output claim strata

VS Code's Agent Debug panel shows loaded prompt files, skills, hooks, tool calls, and chat events in real time.
That is excellent input-side truth.
Helm can steal the next step:
make the output also say which parts are:
- directly observed,
- source-backed,
- inferred,
- remembered preference,
- or proposed action.

### 5. Saved outputs are becoming reusable work artifacts

ChatGPT Projects can save a response as a reusable project source.
Notion view queries return stable cached result sets with query IDs and TTLs.
That combination validates a very Helm-shaped idea:
results should be saveable,
but saved outputs should carry explicit freshness and strength posture instead of quietly becoming timeless truth.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Claim classes inside the result**
   - observed from exact current object or live beacon
   - sourced / cited from explicit files or links
   - derived / inferred from multiple inputs
   - remembered / preference guidance
   - proposed action
   - unknown / hold / unresolved

2. **Compact evidence posture near each stronger claim**
   - source chips
   - basis/freshness hints
   - “double-check” or “inspect sources” affordance
   - explicit hold when basis is weak or stale

3. **Reliance ladders instead of one flat answer box**
   - inspect
   - double-check
   - save as source / review ticket
   - cite / share
   - adopt / apply when the claim is really a proposal

4. **Saveable outputs with freshness posture**
   - saved result
   - saved review slice
   - saved claim packet
   - but never “this is just true forever now”

### Tier 2 — steal soon, but keep modest

1. allow one response to show mixed claim classes in one compact envelope
2. let contribution witnesses link directly into claim envelopes
3. let Omnibox, Recall, and Exchange show tiny claim chips like:
   - sourced from 3 files
   - inferred from selected loadout
   - proposal only; not applied
4. let saved outputs degrade honestly when their evidence basis drifts

### Tier 3 — keep warm only

1. one giant confidence meter pretending to summarize everything
2. giant provenance graphs before one tiny claim envelope works
3. saving every response as a durable object by default
4. flattening proposed actions and factual claims into the same visual posture

## Judgment for Helm

Helm should still avoid adding pillars.

But one support move now looks worth defining:

- **claim envelopes** — shell-owned output objects that keep claim strata, evidence posture, and freshness explicit

And one adjacent move looks worth defining too:

- **reliance ladders** — compact next-step ladders that keep inspect, double-check, save, cite, share, adopt, and apply visibly separate

The main law is simple:

**once Helm becomes explicit about current inputs, it should be equally explicit about output claim strength.**
