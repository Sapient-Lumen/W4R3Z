
# SlopOS + Schell evaluation — 2026-03-21 — pass VI

Purpose: keep using SlopOS and Schell as design teachers while Helm is still choosing what to freeze, what to pressure, and what to postpone.

This pass focuses on a subtler but now repeated lesson:
**saved entry artifacts are useful precisely when they stop pretending to be live truth.**

That pressure now looks strong enough to justify one narrow new Helm freeze:
- **entry artifacts are not live state**,
- and one new candidate move:
- **activity entry kits**.

DelayBasin remains useful mainly as archive method.
It keeps suggesting the same healthy move:
record one bounded take, one explicit non-take set, and one specimen-seeking next step instead of turning a good observation into a premature second doctrine.

## What SlopOS pressures most strongly now

### 1. Request identity and issued descriptors keep refusing to become current truth

SlopOS is now unusually clear about a family Helm should study more directly:
- request keys are not current provider-owned state,
- issued descriptors are not open-ended live-state oracles,
- and historical receipts do not reactivate current truth.

That lesson appears repeatedly:
- request-state posture docs keep splitting requester identity from current mutable state,
- lease-descriptor state keeps splitting issued bounds from current grant state,
- OpenURI keeps splitting launch admission from target completion,
- recent-items boundaries keep splitting launch history from durable reopen authority,
- and attention boundaries keep splitting transient cues from durable outcome truth.

For Helm, the pressure is now obvious:
- a selected capsule,
- a saved layout template,
- a launch-oriented artifact,
- a pinned seed,
- or a restored entry card
should not silently count as **the live desktop**.

### 2. SlopOS's datacube keeps rewarding truth classes over flattering convenience

The deepest lesson in the SlopOS datacube is not purity theater.
It is that systems get more trustworthy when they keep nearby truths separate:
- request,
- admission,
- issued artifact,
- live observation,
- and historical receipt.

Helm already froze request-vs-live truth.
This pass says the next narrow refinement is worth freezing too:
**entry artifacts belong to request/history/guidance classes unless Helm has reacquired live evidence.**

### 3. Exact reopen authority and generic launch should stay different families

SlopOS keeps refusing the desktop habit of making every successful launch feel like durable continuity.
OpenURI recent-items and materialization boundaries, document-handle posture, and exact show-item rules all keep saying the same thing:
**durable reopen authority is an explicit thing, not whatever launch helper happened to run last time.**

Helm should steal that aggressively.
A future entry artifact can be powerful, but it should still distinguish:
- fresh launch,
- attach to live thing,
- restore historical continuity,
- and open the cockpit or hold card instead.

## What Schell adds to the picture

### 1. Launch kits already name the missing shell-shaped object

Schell's recent launch-kit and cockpit work is a very direct teacher for Helm.
It keeps distinguishing:
- live session,
- restored session,
- launch kit,
- quick summon,
- and project cockpit.

That is exactly the kind of separation Helm needs.
It gives a better answer than "workspace restore" folklore because it treats entry as its own object class rather than as a fake live-state claim.

### 2. View trees and restored panes reinforce the same humility

Schell's view-tree work keeps a second rule visible:
rich local structure is useful, but panes, layouts, and restored wrappers stay derivative until the shell explicitly reifies something stronger.

That is a strong warning for Helm's current candidate set.
Layout templates, capsules, cockpit cards, and future entry artifacts should cooperate,
not collapse into a single saved-workspace myth.

### 3. Attach / restore / relaunch / fresh launch should stay different action families

This may be the biggest immediate Schell gift to Helm from this pass.
A great shell can make all four flows feel smooth:
- attach,
- restore,
- relaunch from kit,
- fresh launch.

But it should not flatten them into one button that merely *feels* convenient.

## What DelayBasin usefully pressures here

DelayBasin's lesson is not to widen the product.
It is to keep imports small, explicit, and specimen-bearing.

For this pass that means:
- freeze one narrow truth rule,
- add one candidate move,
- update the ledgers,
- and resist inventing a new grand continuity bureaucracy before the first concrete specimen exists.

## What now looks worth doing in Helm

### Worth freezing now

- **entry artifacts are not live state**

Why now:
- SlopOS now presses this distinction from many seams at once,
- Schell now gives a concrete shell-facing object shape that depends on the distinction,
- and Helm is accumulating enough continuity artifacts that drift is now a real risk.

### Worth adding as candidate pressure now

- **activity entry kits**

Why this now looks strong:
- Helm already has capsules, layout templates, typed seeds, route cards, and cockpit pressure,
- outside tools keep proving users want quick return to a task-shaped arrangement,
- and Schell provides a very good honesty model for entry objects that are useful without pretending to be live authority.

An activity entry kit should likely be a shell-owned artifact that links:
- one activity handle,
- optional capsule and layout template hints,
- seed refs,
- preferred route or destination posture,
- and the allowed action ladder.

## What Helm should explicitly not take

- a giant universal workspace/session ontology before one entry-kit specimen exists
- silent target selection for remote/profile/browser/account-like destinations
- saved-layout folklore that outranks live shell truth
- any suggestion that opening a saved entry artifact proves a live task already exists
- arbitrary embedded app dashboards as the meaning of "entry"

## Current bounded take

A useful new Helm rule is:

**saved entry artifacts — such as capsules, layout templates, and future activity entry kits — are guidance, history, or planned shape, not current live truth by default.**

And a useful new candidate move is:

**activity entry kits as shell-owned task-entry artifacts that can open a cockpit, rehearse a relaunch, offer attach/restore/fresh-launch ladders, and carry the right seeds and templates without impersonating a live session.**
