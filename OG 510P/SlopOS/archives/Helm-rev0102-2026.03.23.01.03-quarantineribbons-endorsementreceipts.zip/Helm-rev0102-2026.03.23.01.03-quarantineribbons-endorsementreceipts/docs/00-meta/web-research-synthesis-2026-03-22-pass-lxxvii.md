# Web research synthesis — 2026-03-22 — pass LXXVII

This pass focused on one narrower question:

**which current product moves would make Helm feel premium and unusually honest,
without turning it into a giant workspace suite,
IAM console,
or agent platform?**

## Strongest outside pressure

### 1. Parameterized front doors are now clearly worth stealing
Warp's Launch Configurations and Workflows,
and Raycast Quicklinks,
all converge on the same useful shape:
a saved starting point with explicit arguments,
searchability,
and one fast summon path.

Helm should absolutely steal that,
but under shell law.
A front door should not impersonate live continuity.
It should behave like a truthful starter with inspectable parameters,
profile posture,
and current-live relation.

### 2. Peek is strongest when it stays inert until promoted
Arc Peek remains the clearest mainstream example of this move.
You can inspect a nearby thing,
perform a quick bounded action,
and close it without losing your place.
Figma's review-updates flow adds the next pressure:
review concrete downstream instances before applying the stronger change.

That combination says Helm should keep **peek** and **promote** separate verbs.

### 3. Exact-scope and current-only reach are now a major design gift
Several ecosystems now teach the same law in different language:
- Chrome `activeTab`
- Android Selected Photos Access
- Google Workspace add-on `currentonly` scopes
- Google Workspace app access levels such as Trusted,
  Specific Google data,
  Limited,
  and Blocked

The common lesson is beautiful:
start from the exact current subject,
or from a named smaller rung,
instead of from whole-world ambient reach.

### 4. Good systems bind review to an exact basis
Terraform plan/apply keeps review and execution legible.
The plan previews a proposed act without carrying it out,
and a saved plan can be inspected before later apply.
GitHub's rulesets and required-reviewer features add the next crucial law:
a review can be specific to a diff,
can go stale when the diff changes,
and can require particular owners or reviewers on sensitive paths.

Helm should steal that for warrants,
review tickets,
adoption,
and stronger flow actions.

### 5. Suggestion-first triage is worth stealing
Linear's triage lane and Triage Intelligence are unusually instructive together.
The first gives the team a named inbox.
The second gives suggestions with accept,
decline,
and view-why posture before commitment.

That is exactly the right AI stance for Helm's Operations Center.

### 6. Reuse is strongest when it stays obviously weaker than authority
A nice cluster of tools says the same thing from different angles:
- Datadog Notebooks and templates
- Notion synced blocks
- Figma variable modes
- Apple Handoff

All of them are useful because they carry shape,
not because they collapse every reuse or continuation into one universal live object.
Helm should steal the reuse grammar,
not the ambient mythology.

## Steal now

- parameterized front doors
- inert peek surfaces with explicit promote steps
- current-only / exact-scope grant ladders
- stale-on-diff reviewed-basis posture
- designated-review or visibility-only audience lanes
- triage lane plus explainable suggestions
- local/private continuity controls for Recall

## Steal carefully

- synced weak mirrors of shell objects
- context modes that switch one structure across several environments
- collaborative notebook-like evidence briefs
- partial ownership / managed-facet ideas inspired by Kubernetes Server-Side Apply

The last cluster looks promising,
but it still belongs in the warm bucket until Helm proves smaller specimens first.

## Resist

- giant command-center dashboards
- ambient shared state that launders basis or authority
- AI-first automatic action as shell default
- one total workspace object that tries to explain everything
- preview surfaces that silently execute,
  escalate,
  or claim trust they do not have

## Synthesis for Helm

The next great Helm move is not “add another pillar.”
It is this:

- make starters more explicit,
- make previews more inert,
- make grants smaller,
- make review more exact,
- and make suggestions more humble.
