# Web research synthesis — 2026-03-21 — pass XXXIV

## Main takeaway

The outside pattern has finally sharpened one missing distinction for Helm:
**when a saved or portable shell surface crosses a boundary, the shell should make the operator choose whether that move preserves lineage or creates a new copy/fork/template-instantiation.**

SlopOS keeps teaching the underlying law from the stricter side:
- exact basis matters
- activation/materialization must stay explicit
- ambient inheritance is a lie waiting to happen
- receipts/descriptors are not live truth
- and move-like continuity should not be faked through loose approximation

Current tools reinforce the user-facing version of the same lesson.

## Fresh outside pressure

### 1. VS Code keeps copy/template/preview modes explicit

VS Code Profiles now makes creation modes unusually legible:
- create a profile by copying from a template
- create from an existing profile
- or create an empty profile
- preview the result in a new window before committing
- browse the source contents section-by-section
- optionally inherit some settings from the Default Profile rather than pretending the copied profile carried everything

This is a strong signal that Helm should not treat every cross-boundary save/import/share flow as one thing.
There are at least several distinct user intents:
- continue or preserve something
- fork/copy it
- or instantiate a fresh local starter from it

### 2. Figma now makes lineage-preserving move versus publish-as-copy unusually explicit

Figma's published-component move flow is especially valuable.
After moving components between files, the publish step asks per component whether to:
- **Move to this file** — preserving connections to existing instances
- or **Publish as copy** — creating a new main component and breaking future updates

This is the cleanest public example I found of a product refusing to blur:
- same lineage in a new location
- versus new object with similar content

Helm should steal that honesty aggressively.

### 3. Notion highlights the difference between moved structure, linked views, duplicated templates, and fresh setup

Notion's current docs sharpen the same family of distinctions:
- moving a data source to a new database keeps old views as linked views and creates a new standard table view in the destination
- duplicating a template page during auth creates a new page in the target workspace
- and Notion's own developer guidance now says static template duplication is limited because it is a snapshot that cannot adapt to user context the way programmatic setup can

This is useful Helm pressure because it says:
- structure may preserve relation without preserving the same local presentation
- duplication may be intentionally snapshot-like
- and fresh local instantiation should stay visibly fresh rather than pretending to be live continuity

### 4. Figma slots are still a strong teacher for typed admissible content

Figma slots let a component declare which instances a slot accepts.
That keeps flexibility while refusing uncontrolled replacement.
The Helm translation is not “copy Figma UI”.
It is:
- shell surfaces should expose typed admissible slots,
- and lineage/copy choices should happen on top of those slot classes rather than through fuzzy “best match” folklore.

## What Helm should steal

### Steal this directly

- explicit **lineage mode** choice at share/import/publish/move time
- explicit **copy/fork witness** when a new object is created from an existing source
- explicit “template instantiation” posture that says “new local object from a starter” rather than “same thing, moved here somehow”
- section-by-section browse/preview before import or creation
- per-slot/per-class inheritance only where it is admitted and weak enough

### Keep warm but do not freeze yet

- richer linked-view behavior after a move
- slot-class-aware override preservation during swaps
- shell-wide template-instantiation flows that adapt to receiver context

### Do not steal

- giant sync mythology
- silent copy-on-write that looks like exact continuity
- hidden relinking after a move or share
- “snapshot but somehow still the same thing” language

## Current Helm judgment

Do **not** add a pillar.
Do **not** freeze another law yet.
But Helm now looks ready for two new warm moves:
- **lineage modes**
- **fork receipts**

Those moves feel more earned than another generic witness because they explain a real user-visible choice:
**did this move preserve lineage, or did it make a new thing?**
