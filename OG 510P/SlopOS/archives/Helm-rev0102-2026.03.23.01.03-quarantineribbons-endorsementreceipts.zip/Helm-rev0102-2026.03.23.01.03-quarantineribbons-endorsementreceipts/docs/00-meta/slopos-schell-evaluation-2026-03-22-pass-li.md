# SlopOS / Schell evaluation — 2026-03-22 — pass LI

Purpose: re-read the latest SlopOS bundle and ask what it teaches Helm about **temporary authority, expiring grants, renewal discipline, and current-live grant truth** now that Helm already has action warrants, drift gates, effect receipts, slot verdict ledgers, reversal warrants, and repair ladders.

## Main takeaway

The latest SlopOS bundle keeps pressing a very specific law into Helm:

**urgency is not a grant,
issuance is not current live authority,
renewal must not silently widen,
and mutable-basis approval should not float forward to whatever is current now.**

That now makes Helm's next likely gap feel much clearer:
Helm needs one shell-owned answer to **what authority exists for this act right now and how long does it last?**
And it likely needs one humane chooser for **which duration/scope rung the operator is actually granting.**

That pair currently looks like:
- **authority windows**
- **grant-rung ladders**

## What the latest SlopOS bundle keeps teaching

### 1. Hint surfaces must not smuggle authority

`attention-lease-posture-v0.md` is the clearest teacher for this pass.
It says urgency is a hint, never a grant.
There is no hidden urgent capability and no silent widening from a stronger-looking presentation hint.

For Helm,
that means shell urgency,
foreground prominence,
entry-kit priority,
or “this looks important” chrome must not silently widen permission.
A louder request is still just a request.

### 2. Background or continuing authority must stay explicit, revocable, and non-widening

`background-lease-posture-v0.md` is even more useful.
It says no ambient background/autostart constructors,
background and autostart are different grant bits,
renew/retry flows must not silently widen,
and expiry/revocation fail closed.

For Helm,
that means temporary shell authority should stay bounded.
A helper that got permission for this ask should not silently graduate to this activity,
and a helper that got this activity should not silently graduate to always-on background control.
Widening should pay for a fresh grant.

### 3. Approval binds one exact reviewed basis, not a floating mutable target

`approval-basis-posture-v0.md` is one of the best teachers in the entire bundle.
It says approval evidence binds one exact action,
not whatever the current head/revision/queue item is later.
If the mutable basis matters,
it must already be encoded into the action bytes.
If the basis drifted,
the old approval does not silently follow.

For Helm,
that means an authority window should stay basis-honest.
If the requested file,
view,
route,
provider,
or target changed in a meaningful way,
the old window should often demote or require fresh review instead of quietly staying strong.

### 4. Historical descriptors do not prove a current live grant

`lease-descriptor-state-boundary-v0.md` is the hardest and most valuable teacher here.
It says a lease/grant descriptor proves exact issuance bounds,
not that the grant is still active now.
Historical descriptors and receipts do not resurrect live grant truth.
Current live state stays provider-local unless an explicit status seam exists.

For Helm,
that means historical grant evidence,
old project-source grants,
prior agent permission posture,
and archived “allowed” surfaces must not impersonate a current-live beacon.
If Helm wants the stronger claim that authority is live now,
it should earn that through a current-live surface.

### 5. Durable status should not hide on transient cues

`attention-durable-status-boundary-v0.md` keeps the same anti-laundering law alive on the UI side.
A transient cue is not a durable carrier of consequential truth.

For Helm,
that means one flashed allow badge,
one vanished prompt,
or one toast saying “access granted” should remain weaker than a durable authority window or current grant beacon.

## What Helm should keep

### 1. Temporary authority should be first-class and shell-owned

Not just hidden in provider dialogs.
The shell should be able to show:
- what grant exists
- who it is for
- where it can spend itself
- what reviewed basis it depends on
- when it expires
- and how to revoke or narrow it

### 2. Widening should require a fresh explicit step

The SlopOS posture is excellent here.
No silent widening on renewal.
Helm should import that almost directly.

### 3. Current-live authority should stay stronger than historical grant evidence

A historical grant or old approval should still help Recall,
audit,
and explanation.
But it should not wear the badge of “currently live” without a current-live witness.

### 4. Isolation should matter

SlopOS keeps separating different kinds of authority surfaces instead of laundering them together.
For Helm,
that suggests one especially nice move:
**broader temporary authority can be safer inside an isolated side lane than in the live lane.**

## What Helm should avoid

1. **Do not let urgency or convenience smuggle a wider grant.**
2. **Do not let renew/retry silently widen duration or scope.**
3. **Do not let historical descriptors impersonate current live authority.**
4. **Do not let mutable-basis approval float forward to a new target.**
5. **Do not let one transient success cue carry the only durable grant meaning.**

## Judgment for Helm

SlopOS is still the right teacher.
This pass says Helm should likely add one more support layer above action/recovery truth:

- **authority windows** as bounded shell-owned current-or-historical grant objects
- **grant-rung ladders** as humane shell-owned choice surfaces for exact once / this time / this activity / isolated lane / persistent scope

That looks more valuable right now than a new pillar,
and more mature than many other warm ideas,
because it sharpens Omnibox,
Operations Center,
Recall,
Desktop Flow,
Exchange,
and delegated or AI-assisted helper work all at once.
