# Web research synthesis — 2026-03-22 pass XXI

Purpose: continue harvesting brilliant ideas for Helm while staying disciplined about what should remain warm.

This pass focused on three questions:

- what current tools teach about **durable saved views that are still visibly derived**,
- what they teach about **change-aware surfaces that help people notice drift instead of guessing**,
- and what they teach about **forkable exploratory work that stays near truth without replacing it**.

## 1) Airtable and Linear validate durable saved views without pretending a view is the data

Airtable keeps teaching the basic multi-view lesson very clearly:
multiple views can sit over one underlying table,
and current docs now also keep distinguishing personal vs collaborative/shared views,
plus explicit view-sharing and sync-activity surfaces.

Linear reinforces the same posture from another angle:
custom views are durable filtered views that can be saved,
shared,
and favorited,
while favorites remain personal shortcuts rather than universal workspace truth.
Project-attached views go one step further by letting a team keep a small cluster of useful filtered perspectives close to one stronger object.

For Helm,
this strongly supports two ideas:

- **view decks** should stay explicit derived collections over stronger shell truth,
- and Helm likely wants **deck recipes** — saved typed recipes that can materialize a deck around one exact object family,
  activity relation,
  or query basis without claiming that the recipe itself is live state.

## 2) Notion separates views, layouts, and templates in a way Helm should steal

Notion's current database docs are a useful teacher because they do not flatten everything into one monolithic "database magic" surface.
The docs distinguish:

- views,
- page layouts,
- and templates,

which means the system can say:

- this is one way to look at the underlying collection,
- this is how pages from that collection are presented,
- and this is a repeatable starting shape for new materialization.

That separation is unusually helpful for Helm.
It suggests that Helm should probably keep distinguishing:

- decks and lenses as derived views,
- layout or presentation posture as separate shell truth,
- and **recipes** as reusable starters rather than as proof of live continuity.

Helm should steal the separation,
not the vague database mystique.

## 3) Figma and VS Code both validate change-aware surfaces over fake continuity

Figma Dev Mode is a particularly good teacher here.
Its compare-changes surfaces and design-status cues are not trying to replace the design with a second truth domain.
They are helping a developer answer:

- did this change,
- when,
- and should I re-check my implementation basis?

VS Code is converging on a similar lesson from a different direction.
Timeline,
checkpoints,
restores,
and now session forks all make it easier to inspect,
compare,
recover,
and branch exploratory work without pretending every branch or past state is the current source of truth.

For Helm,
this creates strong pressure for one more warm move:

- **drift beacons** — compact shell-owned change-aware surfaces that can say what changed since a reviewed basis,
  adopted basis,
  last-seen basis,
  or entry-kit basis,
  without turning into giant timeline theater.

## 4) Session forks are a better teacher than fake continuity

VS Code's current chat/session tooling is especially useful because it now supports history,
checkpoints,
and session forks.
That is a public validation of a subtle idea:

**branching exploration can be first-class without rewriting the meaning of the original line.**

That lines up beautifully with Helm's existing shadow-work and adoption-harbor direction.
The shell should get more comfortable with:

- branchable candidate work,
- inspectable lineage,
- and explicit adoption,

rather than flattering every branch into the same authoritative live lane.

## 5) Small shell luxuries still matter most when they stay truthful

PowerToys Dock still validates a tiny persistent command edge.
Quick Look still validates rich preview without full open.
Airtable's view-sharing and sync-activity surfaces validate explicit sharing rather than silent propagation.
Linear's favorites keep proving the value of personal shortcuts that remain personal.

The unifying lesson is not just "add more mini-surfaces."
It is:

**the best mini-surfaces keep their type,
keep their source,
and keep their promotion story legible.**

## 6) Strongest new warm moves from this pass

- **drift beacons** — compact shell-owned change-aware cards/strips/badges over exact reviewed or remembered basis
- **deck recipes** — typed saved recipes that can materialize a deck or deck-like cluster around one subject family,
  activity relation,
  or query basis

These moves fit the current pillar shape without adding a pillar.
They also cash out the datacube lesson in a Helm-native way:

- explicit views,
- explicit locality,
- explicit materialization,
- and now explicit **change-awareness**.

## Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep reading the best saved-view systems as teachers of **derived durable view objects** rather than dashboard constitutions
- add **drift beacons** and **deck recipes** as new warm candidate moves
- keep branchable exploratory work near truth through harbors,
  forks,
  and adoption rather than through fake continuity

## Strongest non-takes from this pass

- do not build a giant universal timeline product
- do not let recipes or templates claim live continuity
- do not let shared views imply active local binding or current authority
- do not let changed-since badges become a second truth domain
- do not add pillars
