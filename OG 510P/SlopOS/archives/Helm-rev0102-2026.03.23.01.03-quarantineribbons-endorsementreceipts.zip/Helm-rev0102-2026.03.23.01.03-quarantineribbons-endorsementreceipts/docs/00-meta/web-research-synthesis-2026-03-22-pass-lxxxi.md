# Web research synthesis — 2026-03-22 — pass LXXXI

Question for this pass:
**what outside ideas would make Helm feel genuinely super awesome now, without forcing a larger constitution?**

Answer:
make previews and side lanes more promotable,
make handles honest about whether they float or pin,
and make conflicts on composite objects explicit instead of folkloric.

## 1. Vercel is a great proof that previews become more valuable when they are real addresses

Vercel treats each deployment as a concrete deployment object with a unique URL.
That already feels closer to Helm's ideal than a vague preview pane.
A preview can be visited,
shared,
and inspected as a real thing before it becomes production.

More importantly,
Vercel also supports **promoting** a preview deployment to production.
That is a beautiful product law for Helm:

**rehearsal should not be throwaway;
it should be promotable when the reviewed basis and gates still hold.**

This makes preview much more interesting than passive inspection.
It becomes a weaker but real addressable lane.

## 2. Vercel's branch links versus commit links point to an excellent Helm distinction

Vercel explicitly distinguishes:
- **branch links**, which reflect the latest commit on a branch
- **commit links**, which reflect one specific commit

Helm should steal that distinction almost verbatim.
Many shell handles really want to be one of two kinds:
- **floating handles** — intentionally latest-following entry points
- **pinned handles** — exact reviewed or exact historical basis

Today many systems blur those together.
That creates confusion about whether reopen,
share,
review,
or act-now means "the thing I saw before" or "whatever is current now."

Helm could make that visible and delightful.
A handle chip or card could say:
- `pinned · exact reviewed basis`
- `floating · follows current branch/activity/service`

That is a small product move with a lot of trust upside.

## 3. VS Code worktrees keep proving the value of compare-before-migrate

VS Code's worktree flow lets people compare worktree changes with the main workspace and then bring those changes back.
Git's own `worktree` model similarly normalizes multiple working trees attached to one repository.

That maps neatly onto Helm's shadow lanes and landing rehearsals.
The right shell move is not to copy Git literally.
It is to copy the grammar:
- isolate side work
- keep relation to one live subject exact
- compare against the authoritative lane
- migrate or promote explicitly

Helm should keep leaning into **rehearsal → compare → promote** instead of leaving promotion as a loose bag of apply/rebind/adopt verbs.

## 4. Figma and Google Docs reinforce that candidate edits should stay candidate edits until acceptance

Figma branch review lets reviewers compare changes side-by-side or as an overlay and then approve,
suggest changes,
or merge.
Google Docs suggestions similarly stay as suggestions until someone accepts or rejects them.

The lesson for Helm is not collaboration ritual.
It is smaller:
**candidate work should remain visibly candidate work,
even when it is very good,
until the user promotes it.**

That strengthens:
- helper lanes
- repair cards
- imported landing rehearsals
- cockpit proposals
- route fixes
- saved-plan posture

## 5. Kubernetes server-side apply is still the best teacher for composite-surface conflict honesty

Kubernetes server-side apply tracks managed fields,
and conflicting writes against fields owned by another manager result in explicit conflicts unless the caller forces the change and takes over ownership.

That is an unusually rich idea for Helm.
As saved views,
entry kits,
decks,
response kits,
and cockpit surfaces become more composite,
Helm should not fall back to quiet last-write-wins.

A shell-sized version of this idea would be:
- track **facet ownership** or **slot authorship** where it matters
- show conflict when a helper,
  imported recipe,
  user pin,
  local override,
  or live derivation want the same facet
- require an explicit takeover step when one actor is displacing another

Helm does not need Kubernetes-scale field machinery.
But it probably does need the conflict law.

## 6. Android keeps reminding us that narrow and time-bounded permission is normal

Android's one-time permissions and Selected Photos Access continue to support the same lesson:
users understand and like permissions more when they are exact,
temporary,
and purpose-shaped.

That remains a powerful pressure on Helm's grant-rung ladders,
authority windows,
and helper lanes.
This pass does not add a new grant theory,
but it reinforces the idea that **temporary exact access should feel first-class,
not like an edge case.**

## Steal now

- **pinned versus floating handles**
- **rehearsal lanes that have real addresses and can promote**
- **compare-before-promote rails**
- **candidate edit posture that stays candidate until accepted**
- **facet ownership / conflict posture** for composite shell objects
- **temporary exact grants** as a normal happy path

## Steal carefully

- production-promotion theater that is too heavy for normal shell work
- full Git or CI ritual pasted onto every shell interaction
- universal field-ownership bookkeeping on every tiny surface
- previews that become permanent just because they are convenient

## Resist

- one generic reopen/share/apply verb hiding pinning or floating semantics
- side lanes with no exact relation to the live subject
- quiet last-write-wins on composite saved views or cockpit surfaces
- preview surfaces that quietly become live adoption

## Synthesis for Helm

Helm can get much more magical without getting much bigger.

The practical recipe now looks like this:
- **give rehearsal lanes stable addresses**
- **make promotion explicit and inspectable**
- **label handles as pinned or floating**
- **show facet conflicts instead of overwriting politely**

That is the kind of shell magic that stays truthful under pressure.
