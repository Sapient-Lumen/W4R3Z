# Web research synthesis — 2026-03-21 pass XXIV

Purpose: continue harvesting brilliant ideas for Helm while staying disciplined about what should remain warm.

This pass focused on three questions:

- what current tools teach about **what part of a saved/derived surface is actually portable**,
- what they teach about **what should stay local, device-specific, or activity-local**,
- and what extra ideas Helm could steal without drifting into fake continuity.

## 1) VS Code and Obsidian both validate a split between shareable structure and local mutable state

VS Code's current docs now form a very useful cluster.
Profiles are explicit exportable/importable customization bundles.
Workspace settings live in `.vscode` at the project root so they can be shared with others.
Settings Sync shares many personal settings across machines,
but it still declines to synchronize extensions to or from remote windows such as SSH,
containers,
or WSL.
Workspace Trust then adds another explicit local layer:
a folder may remain in Restricted Mode until the operator grants trust.

Obsidian reinforces the same pattern in a less developer-shaped product.
Vault content is just local files.
The `.obsidian/workspace.json` and `.obsidian/workspaces.json` files update whenever you open a new file and may be worth adding to `.gitignore`.
Its sync docs explicitly treat one device as the primary source of truth for selected configuration,
while secondary devices receive updates selectively.

The stealable law is:

**keep one portable/shareable core,
but let local mutable overlays stay local unless a stronger explicit promotion happens.**

That is why Helm now looks ready for **portable cores** and **local overlays**.

## 2) Raycast, Warp, and WezTerm validate exact portable entry handles while keeping live session state local

Raycast's current docs remain very useful.
Quicklinks can be shared with members of an organization,
and Cloud Sync can sync Quicklinks,
Snippets,
and more across Macs.
But the broader Raycast model still clearly distinguishes portable accelerators from everything else.

Warp and WezTerm teach the same lesson from the terminal side.
Warp Launch Configurations let users save a configuration of windows,
tabs,
and panes so the same setup can be reopened quickly.
Warp's URI scheme can open a launch configuration directly.
WezTerm workspaces are also explicit named contexts,
but windows spawned into differently named workspaces do not become visible until that workspace is activated.

The stealable law is:

**exact entry handles travel well;
live visible session state should remain local until explicitly activated or rebuilt.**

That strengthens Helm's existing work on:

- exact action keys,
- deck recipes,
- entry kits,
- publication ladders,
- handoff packets,
- and now portable cores/local overlays.

## 3) Figma and Notion validate shared bases with local or downstream divergence

Figma is still one of the nicest teachers for Helm's honesty story.
Dev resources can be attached to components and propagate to all instances of that component.
At the same time,
instances remain copies that can be customized in their new context.

Notion's newer docs point the same way from another angle.
Views are first-class resources over the same underlying data,
and templates are blueprints for creating pages rather than proof that the resulting pages remain the template itself.

The stealable laws here are:

- **shared base + local downstream overlay** is often the right shape,
- and **companion resources** can travel with a surface without becoming the surface's live authority.

That second lesson is a nifty extra idea for Helm.
It suggests a future warm move around small **companion resource bundles**:
GitHub links,
docs,
dashboards,
runbooks,
VS Code links,
or external context attached to a deck,
key,
object,
or flow fragment that can travel as a companion without impersonating local binding.

## 4) Quick Look, PowerToys Dock, and checkpoints still validate small honest powers

Quick Look is still important because it gives a rich preview without opening the file.
PowerToys' Dock proves that a persistent edge command surface can work well when it stays an explicit shell surface.
VS Code checkpoints remind us that reversible experiments work best when they stay anchored to explicit snapshots rather than vague "latest" folklore.

That means Helm still looks strongest when it adds **small honest powers** rather than giant constitutions:

- preview rails,
- command docks,
- drift beacons,
- derivation strips,
- handoff packets,
- promotion receipts,
- portable cores,
- and local overlays.

## 5) Strongest new warm moves from this pass

- **portable cores** — the travel-safe subset of a shell surface that may be exported,
  shared,
  handed off,
  or stored as a portable object without claiming live receiver-side state
- **local overlays** — the personal,
  device-specific,
  workspace-specific,
  or activity-local delta layered on top of a portable core after materialization,
  rebinding,
  or trust/adoption

These feel more mature than a new pillar because they strengthen many existing moves at once.

## Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- split travel-safe shell structure from local mutable overlay state
- let exact portable handles travel,
  but keep live activation,
  trust,
  and local residue explicit
- keep preview,
  compare,
  and checkpoint-style experimentation weaker than adoption

## Strongest non-takes from this pass

- do not sync local overlays by accident
- do not hide secrets,
  trust posture,
  or session/profile selection inside portable packets
- do not let shared templates,
  profiles,
  or views impersonate active receiver-side state
- do not turn companion resources into live authority
- do not add pillars
