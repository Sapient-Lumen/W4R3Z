# Web research synthesis — 2026-03-22 pass LXXIV

Question for this pass:
what current tools most strongly validate a **shell-owned reveal / audience grammar** once Helm already has publication ladders,
promotion receipts,
authority windows,
claim envelopes,
and handoff packets,
but still lacks one honest answer to **who can currently see what shape of truth,
by what route,
for how long,
and under what guard**?

## Strong pattern: share acts, current audience truth, and reveal shape should not blur together

The best current teachers keep separating:
- **who may access**
- **how they get there**
  - invite,
    org-only,
    bearer link,
    passworded link,
    public link,
    or signed URL
- **what shape is visible**
  - full,
    comment,
    edit,
    preview,
    summary,
    or redacted form
- **how long it stays open**
- **what policy can narrow or shut it off later**

That is exactly the shape Helm still lacked.

## Best steals

### Notion: reveal duration and general access are separate choices
Notion separates general-access audience from access level,
and lets “Anyone on the web with link” expire at a chosen time or date.
Enterprise admins can disable public links entirely.
That is a strong signal that **current visibility is its own product truth surface**,
not just a historical share event.

### Google Drive: named audience and expiry belong together
Google Drive keeps Viewer / Commenter / Editor distinct,
and eligible accounts can add an expiry date while sharing.
That reinforces a second law:
**named audience** and **time-bounded reveal** should compose directly rather than being treated as unrelated advanced settings.

### Dropbox and S3: bearer routes need stronger expiry posture
Dropbox shared links can require a password and can expire on a chosen date.
Amazon S3 presigned URLs are explicit bearer tokens,
can expire,
and also die when the underlying credential is revoked or expires.
That is a clean teacher for Helm:
**bearer reveal routes are real,
useful,
and weaker/shorter-lived than named collaborator truth**.

### Figma and Atlassian: org policy should be able to narrow exposure classes
Figma can require passwords,
require expirations,
set workspace-specific public-link rules,
disable public links,
and its FigJam open sessions auto-end after 24 hours.
Atlassian admins can block public links,
and when blocked,
existing public links are turned off rather than silently grandfathered.
That strongly suggests Helm wants **live reveal windows** plus **policy-aware audience ladders**,
not just a one-time share sheet.

## Combined product judgment for Helm

Helm should not answer visibility with one mushy Share state.
It should instead grow one small shell-owned family:

- **reveal windows** — what exact audience relation exists or recently existed,
  by what route,
  with what reveal shape,
  with what start/expiry/revoked posture,
  and with what current-live witness relation
- **audience ladders** — the humane chooser for local-only,
  named collaborators,
  org/workspace,
  guarded link,
  and public/time-boxed reveal where a family should ever allow those rungs
- nearby **narrow / rotate / disable / republish** next moves,
  often reusing publication ladders,
  promotion receipts,
  and revoke-style controls instead of inventing a second giant sharing console

## What not to steal

- giant universal ACL religion before one shell proof exists
- public-link folklore where historical receipts impersonate live current audience truth
- one undifferentiated “shared” badge for named,
  org-only,
  bearer,
  and public routes
- silent widening from summary/preview to full reveal
- password/expiry/policy controls hidden only in provider-specific admin caves

## Pull-the-trigger judgment

This looks like a wise warming move.
Not a new pillar.
Not a giant permission or collaboration suite.
A compact shell-owned **reveal / audience grammar** that can sit next to publication,
travel,
claim,
and authority truth and keep visibility honest.
