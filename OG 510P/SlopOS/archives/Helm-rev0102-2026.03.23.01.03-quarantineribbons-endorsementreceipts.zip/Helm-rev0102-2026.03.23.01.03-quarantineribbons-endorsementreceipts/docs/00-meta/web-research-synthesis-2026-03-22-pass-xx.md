# Web research synthesis — 2026-03-22 pass XX

Purpose: continue harvesting brilliant ideas for Helm while staying disciplined about what should remain warm.

This pass focused on two questions:

- what current tools teach about **small live micro-surfaces**,
- and what they teach about **local vs workspace vs portable vs shared setup**.

## 1) VS Code is now one of the clearest teachers of locality tiers

VS Code keeps separating configuration by scope instead of pretending all customization belongs to one universal bucket.
The docs distinguish user settings, workspace settings, profiles, synced settings, and newer workspace-vs-user placement for AI instruction files and MCP server configuration.

That is more than ordinary configuration hygiene.
It is a public proof that powerful environments stay saner when they can say:

- this is personal,
- this is workspace-scoped,
- this is portable,
- this is shared with the project,
- and this is what sync is actually allowed to carry.

Helm should likely steal that posture for docks, exact action keys, seeds, decks, and other shell luxuries.

## 2) Raycast gives Helm the best public example of “great accelerators, selective sharing”

Raycast still validates Quicklinks, deeplinks, snippets, hotkeys, and a strong keyboard-first command surface.
But its docs are just as useful for what they refuse to flatten:

- Quicklinks and snippets can be shared with teams,
- hotkeys and some setup can sync,
- but Clipboard History is handled as a local, sensitive surface rather than casual shared memory.

That is a very important Helm lesson.

The best accelerators should not automatically become:

- synced continuity,
- shared team truth,
- or portable authority.

Some should remain obviously personal.

## 3) Obsidian separates shareable view definitions from local mutable workspace state

Obsidian Bases is a particularly useful teacher because Bases are explicit data views that can live in `.base` YAML, while Workspaces and workspace JSON track mutable UI state and can be reasonable `.gitignore` candidates.

That is a nearly perfect public example of the distinction Helm now needs:

- some view objects are worth saving and sharing,
- some layout/workspace state is local mutable setup,
- and confusing the two creates noise, drift, and false continuity.

That directly strengthens Helm's view decks, materialization bays, and the new warmth around surface locality tiers.

## 4) Warp and WezTerm keep validating exact entry and session navigation without magical global continuity

Warp's Launch Configurations, Session Navigation, and URI scheme all reinforce the value of:

- named reentry,
- exact session lookup,
- and explicit launch handles.

WezTerm keeps showing the value of explicit workspaces and launcher entries rather than a vague “restore everything everywhere” promise.

That combination suggests Helm should keep favoring:

- exact entry handles,
- named local or activity-scoped surfaces,
- and explicit promotion from local setup into portable artifacts.

## 5) PowerToys Dock, Arc Split View, Little Arc, and Quick Look still validate live micro-surfaces

PowerToys' Dock continues to validate a persistent edge surface for exact pinned commands.
Arc Split View and Little Arc continue to validate quick comparative or triage surfaces that can later be kept or discarded.
Quick Look continues to validate fast preview that remains clearly distinct from full open.

Taken together, these sources keep supporting Helm's projection-surface family:

- command docks,
- preview rails,
- exact trails,
- live lenses,
- and view decks.

But the best fresh takeaway is that these surfaces stay lovable when they remain:

- small,
- legible,
- and clear about whether they are personal convenience, local setup, or stronger shared truth.

## 6) The strongest new warm move is surface locality tiers

The current tool landscape is converging on a practical lesson:

**not every good surface should travel the same way.**

For Helm, that likely means a compact candidate move that can distinguish:

- personal/local shell surfaces,
- activity or workspace-local surfaces,
- portable/exportable artifacts,
- and shared/team surfaces.

That would apply especially to:

- command docks,
- exact action keys,
- snippet/seed surfaces,
- view decks,
- workspace/activity capsules,
- and perhaps some future lens arrangements.

## 7) The strongest renewed move is still live lenses

Live lenses now feel like one of the best ways to make Helm feel super awesome without breaking its honesty.
They cash out many current lessons at once:

- bounded projection,
- exact source witness,
- small live surface,
- honest degradation,
- and optional promotion into a deck or dock without pretending the derivative is the source.

They are still warm rather than frozen, but this pass increases their priority.

## Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- renew **live lenses** as one of the highest-value proof specimens
- add **surface locality tiers** as a new warm candidate move
- keep pushing Helm toward local-first luxuries that can be promoted explicitly instead of silently turning into shared truth

## Strongest non-takes from this pass

- do not build a universal sync constitution
- do not let team sharing become the default for every shell luxury
- do not let local workspace state impersonate durable portable truth
- do not let live lenses become generic remote-control or capture folklore
- do not add pillars
