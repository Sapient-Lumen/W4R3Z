# Web research synthesis — 2026-03-22 — pass LXXXIII

Question for this pass:
**what is the next small rule Helm should steal if authority windows and grant rungs already look right, but we still want stronger portability and less surprise?**

Answer:
separate **capability budgets** from **current borrowed leases**,
then make reacquisition travel through explicit **renewal rails**.

## 1. Google OAuth and Drive keep proving that “may ever ask” is not the same as “asking now”

Google's Drive docs make one unusually useful split explicit.
In the Cloud console,
you declare the highest level of permissions the app may ever request.
In the app,
you still have to request the specific scopes needed for the current session.

That is a beautiful shell lesson.
A front door,
recipe,
flow fragment,
or helper lane can say:
- what it may ever ask for,
- and what it is asking to borrow **right now**.

Those should not be the same object.
A declared max budget is not a live lease.
A live lease is not permission to widen up to the whole budget silently.

## 2. Incremental authorization proves that scope growth should happen in context, not up front

Google's OAuth guidance explicitly recommends incremental authorization:
request scopes when they are needed,
in context,
rather than asking for everything at sign-in.
The same docs also show time-based access and token revocation.

That is exactly the right posture for Helm.
Do not front-load every scary ask.
Do not hide future asks either.
Instead:
- show the upper-bound budget,
- borrow the narrowest current lease,
- and widen only through a fresh,
  legible step.

## 3. AWS STS keeps teaching that borrowed power can be both temporary and intersection-bounded

AWS STS temporary credentials already fit the lease idea,
but the sharper lesson is the session-policy rule:
the session's permissions are the **intersection** of the underlying identity policy and the session policy.

That is more interesting than a generic temporary grant.
It suggests that Helm should often define borrowed power as:
- one exact holder,
- one exact subject family,
- one exact duration,
- one exact lane,
- and one exact budget intersection.

This would keep helper lanes,
recipes,
and imported starter objects much more honest.
A thing may know how to ask for a family of access without automatically holding all of it.

## 4. XDG portals prove that exact chosen objects can persist without becoming ambient filesystem authority

The FileChooser portal lets sandboxed apps ask the user for files outside the sandbox.
Selected files may be added to the Documents portal,
and files added there can stay accessible across sessions.
But the Documents portal also keeps the permissions model explicit:
per-app permissions can be granted,
revoked,
and deleted without deleting the underlying file.

That is a very strong prototype for Helm's handle story.
A remembered exact handle can survive.
A current lease can survive.
But the shell should still be able to say:
- who has access,
- to which exact subject,
- under what permissions,
- and how to revoke or delete the lease without lying about the file itself.

## 5. Chrome's File System Access evolution proves that exact-handle memory and permission persistence should stay distinct

Chrome's File System Access API already centered work on stored file handles.
Its newer persistent-permission behavior makes the split even clearer:
users can allow access this time,
allow on every visit,
or deny;
and later revoke access per item.

That gives Helm a very practical ladder:
- remember the exact handle,
- borrow the narrowest current lease,
- optionally let that lease persist,
- and keep per-item revoke nearby.

Helm should steal the **user-visible three-way choice** and the **per-item revoke**,
not only the underlying handle mechanics.

## 6. What Helm should steal now

- **Capability budgets** on front doors,
  recipes,
  flow fragments,
  and helper lanes:
  the explicit upper bound of what they may ask to borrow later
- **Lease windows** as the live truth surface for what is actually borrowed now
- **Renewal rails** that distinguish:
  - reacquire same subject on same rung,
  - reacquire narrower,
  - migrate to isolated lane,
  - broaden through a fresh ask,
  - or let expire
- **Per-item revoke and residual-truth posture**
- **Imported budget without imported lease** as the default for traveled recipes and packets

## 7. What Helm should resist

- one generic persistent-access myth that fuses handle memory and live power
- one generic "Allow later" promise that hides what the future maximum ask actually is
- renewal that silently widens subject,
  duration,
  or lane
- recipe import that launders yesterday's authority into today's current-live truth
- a giant permission-center constitution just to prove one calmer rule

## Synthesis for Helm

Helm already has authority windows,
grant-rung ladders,
revoke handles,
exact remembered handles,
and recipes.
The next refinement is upstream of all of them:

- **capability budget** = what this thing may ever ask for
- **lease window** = what it is actually borrowing now
- **renewal rail** = the exact honest path from an old or expiring borrow to the next one

That split looks like one of the cleanest remaining ways to make Helm both safer and more delightful without adding another pillar.
