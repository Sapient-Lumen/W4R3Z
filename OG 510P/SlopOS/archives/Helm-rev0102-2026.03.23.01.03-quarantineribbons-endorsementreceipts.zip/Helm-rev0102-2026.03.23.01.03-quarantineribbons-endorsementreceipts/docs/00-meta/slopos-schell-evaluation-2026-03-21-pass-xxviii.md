# SlopOS / Schell evaluation — 2026-03-21 pass XXVIII

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on one sharper seam:

**if a carried Helm surface lands honestly only through explicit fit and rebind,
what exact carried binding structure should it expose,
and when is explicit receiver-default inheritance actually safe?**

## 1) SlopOS still keeps teaching explicit view objects and no ambient resolution

The strongest transferable SlopOS lesson in this pass came from `view-objects.md` and `capability-semantics.md`.
Views are explicit objects.
Name resolution is a pure operation over explicit view state.
There is no fallback to ambient resolution.
That posture is exactly the opposite of “the receiver can probably figure out what I meant.”

That makes a Helm **anchor map** feel increasingly earned.
A portable or derived shell surface should be able to say:

- these are my named slots,
- these are the admitted handle classes,
- these are my carried arguments or companion bindings,
- and these are the places where the receiver still owes an explicit choice.

That is much more SlopOS-shaped than hidden fuzzy retargeting.

## 2) SlopOS also teaches that not every omission should force a giant rebind ritual

Other SlopOS docs keep adding nuance.
The capshell scheduling and affinity postures explicitly refuse to carry launcher/session state across the reviewed boundary.
Approval-basis posture refuses sticky head-following approval.
Capability export posture keeps import explicit and rejects ambient revival.

But those same postures do **not** imply that every omitted detail must become giant visible drama.
Sometimes the honest answer is:

- this class was not carried,
- it remains local,
- and the receiver may use its own default for this bounded class.

That is the right scale for a Helm **inherit mask**.
It is not ambient fallback.
It is explicit permission for a narrow class of receiver-default behavior.

## 3) The good SlopOS import is explicit slot law,
not total carry

This pass sharpened one important distinction.
The SlopOS lesson is not “carry more context.”
It is “carry the right exact context.”

For Helm,
that means the right imported ideas are:

- explicit view objects
- explicit binding slots
- explicit admitted handle classes
- explicit omitted residue
- explicit materialization/adoption
- and explicit denial/refusal when no honest bind exists

That leaves room for inherit masks,
but only as a narrow shell-owned escape hatch for harmless receiver-default classes.

## 4) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- landing manifests,
  fit cards,
  residue ledgers,
  and rebind ladders still look right
- add **anchor maps** as the compact carried binding structure for saved/derived/traveling shell surfaces
- add **inherit masks** as the compact declaration of which bounded classes may use receiver defaults without lying

## 5) What still does not seem worth taking

- not a universal datacube UI
- not ambient receiver inference
- not giant import wizards
- not “use receiver defaults” for trust,
  identity,
  credentials,
  or other strong local truth
- not new pillars

## 6) Current judgment

The most important lesson from this pass is:

**Helm gets smarter by carrying explicit slot law and explicit default law,
not by carrying more fuzzy state.**

That feels strong enough for new candidate contracts,
and still not strong enough for a new pillar or a new freeze.
