# SlopOS + Schell evaluation — 2026-03-21 pass XV

Purpose: continue tightening Helm against the current SlopOS and Schell datacubes **without** pretending either teacher is fully settled.

This pass was driven by three pressures:

- SlopOS keeps sharpening request-state humility and exactness at the mediated shell boundary.
- Schell keeps sharpening shell-facing lineage, source grading, and mode separation, but is still young enough that Helm should import only narrow earned lessons.
- Current public tools keep proving that typed pivots and preview-adjacent action are valuable when they stay host-owned and honest.

## What SlopOS keeps teaching Helm

### 1) Exact reveal/select should fail closed

`openuri-showitem-exactness-boundary-v0.md` is still one of the cleanest imports for Helm.
A request that means **show this exact object selected** should not quietly degrade into “open something nearby.”

For Helm this continues to pressure:

- **Object Browser** toward exact reveal/select instead of nearby browse folklore
- **Recall** toward exact reopen/reveal or explicit repaired/unavailable posture
- **Omnibox** toward exact object actions rather than vague location opening

Helm should keep stealing this law.

### 2) Generic launch is not placement authority

`openuri-launch-disposition-boundary-v0.md` remains a decisive warning.
Generic mediated launch should not silently grow portable placement, named-window reuse, split-side, new-tab, or new-instance mythology.

For Helm this means:

- **Omnibox** may offer stronger placement or reuse choices,
- **Tiling Shell** may own placement policy,
- but generic `open` / generic launch should not quietly inherit every placement knob just because other platforms expose them locally.

This keeps launch ladders honest.

### 3) Activation and focus stay shell/compositor-owned

`openuri-activation-control-boundary-v0.md` and adjacent OpenURI posture continue to validate one of Helm's clearest instincts: requesters do not get to choose foreground truth.

That continues to harden:

- **Tiling Shell** as owner of activation/focus truth
- **Operations Center** as the place that can explain what actually became live
- **Recall** as a continuity surface that should not confuse requested foregrounding with actual liveness

### 4) Preview is real power, but it must stay weaker than open

SlopOS's preview-related boundaries keep repeating a subtle lesson:
preview is not trivial.
Preview is already an execution-adjacent parser/render path, so the shell must keep preview observational by default and avoid letting mere selection imply stronger authority.

For Helm this means:

- **Preview** should stay shell-owned,
- **preview rails** should remain bounded and typed,
- and **Object Browser / Omnibox / Recall** should not let preview quietly count as open, import, or attach.

### 5) Request artifacts are not live state

The request-state adjunct family in SlopOS keeps teaching the same discipline across jobs, background grants, network leases, notifications, and timeproof:
request identity is useful, but it is **not** current live state.

That pressure keeps paying rent in Helm:

- **Operations Center** should continue separating request, admission, launch, live result, and receipt
- **Recall** should continue separating historical receipt from live reentry
- **entry kits / launch ladders / exact-object recency** should not impersonate current liveness

## What Schell keeps teaching Helm

### 1) Shell-facing richness matters, but it is still a seam

Recent Schell continues to get richer around lineage, retention, residue, and history pressure.
That makes terminal/capshell more important, not less.
But it still reads as a **front-end family over shared truth**, not a new standalone pillar.

Helm should continue importing:

- command-boundary witnesses
- receipt-bearing actions
- source grading
- session lineage pressure
- mode separation when direct command and delegated/conversation work coexist

Helm should still avoid importing:

- full terminal-local ontology as desktop master truth
- final retention law before Schell earns it
- pane/session identity as a substitute for receipt and route truth

### 2) One giant history is still the wrong shape

Schell's newer retention/history pressure keeps validating a Helm concern:
block history becomes dishonest when direct commands, delegated proposals, historical receipts, and background residue all look like one thing.

That strengthens:

- **exact-object recency**
- **sticky context strips**
- **facet strips** over typed recency/search buckets
- and source-labeled Recall surfaces

### 3) Mode/source separation is increasingly stealable

The strongest currently stealable Schell lesson is not a final shell syntax rule.
It is that source/mode separation materially improves trust.
Direct command, delegated helper, historical receipt, and imported artifact should not share one visual voice.

That should continue to shape:

- **terminal/capshell**
- **Recall**
- **Operations Center**
- and any future shell-facing quick action surfaces

## What this pass changes in Helm's posture

This pass increases confidence in four directions:

1. **keep the pillar count stable**
2. **keep terminal/capshell as a native front-end family**
3. **flesh out cross-pillar shell powers instead of adding pillars**
4. **treat typed pivots and preview-adjacent action as especially promising**

## Warm candidate ideas this pass strengthens

- **preview rails** — bounded action-adjacent rails next to shell-owned preview
- **facet strips** — small typed pivots for objects / actions / routes / receipts / transfers instead of one mushy omnibox or recency list
- **launch ladders** — still warm, now better constrained by SlopOS launch humility
- **sticky context strips** — still warm, now better justified by Schell history/source pressure
- **exact-object recency** — still warm, now better supported by anti-history-mush pressure

## Explicit non-takes in this pass

- Do not turn every helpful preview affordance into open/attach authority.
- Do not let generic launch absorb placement/reuse folklore.
- Do not let terminal-local history become Helm's Recall model.
- Do not import Schell's still-moving retention constitution as Helm law.
- Do not add more pillars merely because cross-pillar moves are getting more vivid.
