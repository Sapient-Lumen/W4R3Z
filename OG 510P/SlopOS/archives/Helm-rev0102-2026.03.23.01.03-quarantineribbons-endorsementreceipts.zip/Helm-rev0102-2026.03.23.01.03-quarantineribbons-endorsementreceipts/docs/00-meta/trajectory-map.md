
# Trajectory map (Helm v0 + archive-control import)

This doc is intentionally short. It exists to stop Helm from drifting into “nice utilities around an unstated desktop model” or into “good ideas remembered from chat”.

## Non-negotiables

1. **Helm is from scratch**
   - no POSIX desktop inheritance by accident
   - no porting nostalgia as product truth

2. **The exemplar list translates to powers, not clones**
   - i3 is discipline, not historical WM shape
   - AHK is programmable desktop control, not ambient hook culture
   - Rofi is unified summon-and-dispatch, not merely app launch
   - Dolphin is strong object/document browsing, not path worship
   - “god-tier task manager” is operational honesty, not process theater

3. **Shell/compositor owns desktop truth**
   - focus, activation, visibility, placement, reveal/select, continuity posture, transfer routing, and shell-object identity stay shell-owned

4. **Helm is one product with seven visible pillars**
   - Tiling Shell
   - Omnibox
   - Object Browser
   - Operations Center
   - Desktop Flow
   - Recall
   - Exchange
   - plus terminal/capshell as the native shell-facing front-end family

5. **Tiling-first, hybrid-capable**
   - keyboard-first by default
   - floating/special surfaces exist by shell decision, not by accidental legacy convention

6. **Desktop Flow is core**
   - visual desktop programming is part of base Helm, not a plugin story

7. **Automation is tiered**
   - Tier 1: shell graph
   - Tier 2: structural UI graph
   - Tier 3: raw automation lane

8. **The Object Browser is core**
   - query views, reveal exactness, durable object references, preview, bulk operations, and object-local continuity are shell concepts

9. **The Operations Center is core**
   - windows, jobs, background presence, failures, resource use, grants, automation sessions, transfers, and receipts must be visible

10. **Recall is core**
    - reentry, exact reopen/reveal, activity trail, receipts, and restored-vs-live honesty must not collapse into generic recents/history folklore

11. **Exchange is core**
    - paste, drop, clipboard, share, attach, forward, import, export, and action routing must not collapse into path paste, helper magic, or ambient execution

12. **Terminal/capshell is native, not POSIX cosplay**
    - no ambient command-string authority as default desktop glue

13. **Helm does not wait for Schell, but it does respect Schell pressure**
    - lineage over history-only
    - reviewed actions over naked side-effect launch
    - receipts over prompt-return folklore
    - explicit ingress over ambient pasted authority
    - execution grounds over prompt magic
    - restored/attached/resumed posture over fake continuity
    - route witnesses over “smart click” folklore

14. **Helm's archive needs its own control surfaces**
    - startup, status, questions, assumptions, imported pressure, followthrough, and revision receipts are part of durable archive truth, not process garnish

15. **Cross-cutting shell moves matter as much as pillars**
    - Preview should become shell-wide, not app-local
    - workspace/activity capsules should be continuity truth, not folklore session restore
    - Overview should be the spatial companion to Omnibox
    - Desktop Flow needs debug/packaging surfaces, not just a canvas
    - query views and typed routes should keep pressuring multiple pillars at once

16. **Eight narrow freezes are now in**
    - Omnibox extensibility is typed-provider-first, not ambient plugin folklore
    - Desktop Flow observability and reusable fragments are required, not optional polish
    - request-vs-live truth is a cross-cutting posture, not an optional wording detail
    - entry-artifact truth is a cross-cutting posture, not a saved-workspace wording detail
    - binding witness posture is a cross-cutting posture, not a quiet reuse convenience
    - activity-scope truth is a cross-cutting posture, not a nearby-context convenience
    - continuity-switch authorship truth is a cross-cutting posture, not a flattering substitute convenience
    - reviewed-basis truth is a cross-cutting posture, not a sticky-head strong-action convenience
    - delegated-adoption truth is a cross-cutting posture, not a flattering helper-convenience

## Current external idea harvest (not all frozen)

Promising non-pillar moves worth carrying forward:

- Preview as a shell-wide power
- workspace/activity capsules
- Overview as spatial companion to Omnibox
- typed providers for Omnibox
- Flow debug sidebar / outline / reusable fragments
- plumbing-grade route inspection
- visual layout/template editing
- breadcrumb / outline / timeline cues where they strengthen Recall or Object Browser
- live lenses / derivative surfaces as a shell luxury
- drift beacons as compact compared-basis change surfaces over stronger shell truth
- typed snippet / quicklink / placeholder seeds
- activity cockpit cards as shell-owned task front doors
- activity entry kits as shell-owned task-entry artifacts
- binding witness cards as shell-owned saved-to-live continuity cards
- activity scope witnesses as shell-owned strips/cards for included axes and excluded ambient context
- continuity choice witnesses as shell-owned strips/cards for proposer / chooser / executor posture during substitutions or handoffs
- basis packets as shell-owned strips/cards for exact reviewed basis, compare result, and honest next ladders on stronger actions
- review strips as tiny shell-owned preflight strips/cards for subject, route, basis, and readiness truth
- exact-object recency as Recall cues over exact objects, actions, receipts, holds, and source labels
- reusable flow fragments as status-bearing typed graph units
- shadow work lanes as shell-owned isolated mutable side lanes with compact adoption cards
- preview rails as compact bounded next-step edges next to shell-owned preview
- facet strips as compact typed pivots over objects/actions/routes/receipts/transfers
- command docks as tiny persistent shell-owned command/status edges
- adoption harbors as shell-owned review/apply surfaces for delegated or background candidate work
- breadcrumb / exact-trail cues as warmer orientation pressure that still should not be overfrozen
- view decks as compact named sets of explicit views over one stronger truth
- deck recipes as reusable starters for deck materialization without fake continuity
- derivation strips as compact shell-owned witness headers for lenses, decks, recipes, and beacons
- publication ladders as explicit shell-owned tier-promotion ladders instead of ambient sync folklore
- materialization bays as explicit shell-owned promote/adopt/import seams for turning weaker surfaces into stronger local or live things
- receiver fit cards as compact shell-owned landing reports for portable arrivals on one receiver
- rebind ladders as explicit shell-owned next steps for binding portable arrivals to local paths, providers, profiles, sessions, placements, or activities
- basis stamps as compact shell-owned carried-basis witnesses reusable across manifests, beacons, receipts, and arrival cards
- residue ledgers as compact shell-owned omitted-local witnesses that name what stayed behind instead of hiding it inside sync folklore

## What Helm is

A shell/compositor product where layout, launch, browsing, operations, automation, continuity, exchange, and task entry are all part of one visible control plane.

## Pillars and front-end family

### Seven pillars

- tiling-first shell
- omnibox
- object browser
- operations center
- desktop flow
- recall
- exchange

### Native front-end family

- terminal/capshell

## Candidate proof-bearing slice

The preferred early slice is:

**exact object → reviewed action → route → receipt → recall**

A good specimen should demonstrate:

- one exact object that can be found from at least two surfaces
- exact reveal/select plus preview/inspect truth
- one reviewed action over that same object
- one visible route/provider/path witness
- Operations Center truth for live result, denial, or hold
- one Recall return path that distinguishes live, restored, and historical posture
- one terminal/capshell path through the same slice
- and at least one honest failure or drift case


## New pressure added in rev0017

- delegated-adoption truth as a cross-cutting posture for delegated, background, or repair-produced mutable candidate work
- shadow work lanes as shell-owned isolated mutable side lanes with compact adoption ladders
- continued pressure to make entry kits, cockpits, repair flows, basis packets, and continuity witnesses cooperate without hidden live-lane mutation folklore

## New pressure added in rev0016

- reviewed-basis truth as a cross-cutting posture for strong actions over mutable saved/historical/delegated basis
- basis packets as shell-owned strips/cards for exact reviewed basis, compare result, and honest next ladders
- continued pressure to make entry kits, cockpits, binding witnesses, scope witnesses, and continuity choice witnesses cooperate without sticky-head approval folklore

## New pressure added in rev0015

- continuity-switch authorship posture as a cross-cutting posture for repaired, widened, switched, reused, or delegated continuity
- continuity choice witnesses as shell-owned strips/cards for proposer / chooser / executor posture during substitutions or handoffs
- continued pressure to make entry kits, cockpits, binding witnesses, and scope witnesses cooperate without laundering operator authorship

## New pressure added in rev0014

- binding-witness posture as a cross-cutting posture for non-exact saved-to-live joins
- binding witness cards as shell-owned saved-to-live continuity cards
- activity scope witnesses as shell-owned strips/cards for included axes and excluded ambient context
- continued pressure to make capsules, layout templates, cockpit cards, entry kits, and reuse flows cooperate without hidden retargeting folklore

## New pressure added in rev0019

- SlopOS now sharpens the pillar contracts more aggressively around exact reveal/select, generic-launch humility, activation/focus ownership, and request-vs-live separation
- review strips as tiny shell-owned preflight surfaces
- exact-object recency as a stronger Recall direction
- reusable flow fragments as a Desktop Flow requirement rather than a vague future nicety

## New pressure added in rev0021

- preview rails as compact bounded next-step edges next to shell-owned preview rather than silent open-by-selection folklore
- facet strips as compact typed pivots so Omnibox, Recall, and Exchange can avoid one giant mixed-result story
- continued pressure to keep launch ladders, sticky context strips, exact-object recency, and preview/provider law cooperating without adding more pillars

## New pressure added in rev0022

- command docks as tiny persistent shell-owned command/status edges rather than a hidden second launcher constitution
- adoption harbors as shell-owned review/apply surfaces for delegated, background, or repair-produced candidate work
- continued pressure to keep saved context, exact trails, launch ladders, shadow work lanes, and provider-local choice honest without adding more pillars

## New pressure added in rev0023

- projection surfaces as a shared shell law for docks, rails, strips, lenses, cockpit cards, and exact trail cues
- continued pressure to keep exact trails and trust ladders warm without promoting either to a full contract too early


## New pressure added in rev0024

- exact trails as copyable exact shell paths rather than decorative breadcrumbs
- trust ladders as compact shell-owned posture ladders for preview/import/delegated-work cases
- exact action keys as fast promoted bindings for already-earned exact shell powers
- continued pressure to keep datacube/view ideas bounded to explicit views and projections rather than turning Helm into one giant shell-state cube


## New pressure added in rev0025

- view decks as shell-owned named sets of explicit views over one stronger truth rather than one more dashboard or workspace clone
- materialization bays as shell-owned explicit promote/adopt/import seams rather than hidden side effects of preview/query/import surfaces
- renewed live-lens pressure as one of the most promising ways to make projection-surface law feel delightful instead of merely defensive
- continued pressure to keep saved decks, exact trails, docks, and exact keys honest about liveness, provenance, and authority without adding more pillars


## New pressure added in rev0026

- one proof that Helm can distinguish personal/local, activity-local, portable, and shared shell luxuries without building a giant sync constitution
- one proof that live lenses can join decks, docks, or Recall surfaces as bounded projections without smuggling hidden interactivity or false independence
- one proof that drift beacons and deck recipes can make Helm more change-aware and reusable without inflating into a giant cube or workspace constitution

## New pressure added in rev0028

- derivation strips as tiny shell-owned provenance headers for derived surfaces such as lenses, decks, recipes, and beacons
- publication ladders as compact shell-owned local/activity-local/portable/shared promotion ladders rather than ambient sync assumptions
- continued pressure to keep locality tiers, materialization bays, drift beacons, deck recipes, and exact action keys cooperating without turning Helm into a shared-workspace constitution


## Pass XXIII addendum

- handoff packets as portable shell-owned travel forms for deck recipes, exact action keys, dock items, and other saved/derived luxuries that should travel without pretending to be live receiver-side state
- promotion receipts as compact durable witnesses for export/share/publish tier changes, audience/permission deltas, and receiver-side activation expectations
- stronger pressure to keep publication ladders, derivation strips, materialization bays, and exact action keys cooperating around one explicit packet-and-receipt story rather than ambient sync mythology


## New pressure added in rev0031

- receiver fit cards as shell-owned landing witnesses for portable cores, handoff packets, and published shell luxuries that need honest receiver-side fit
- rebind ladders as shell-owned local binding ladders for path/provider/profile/session/activity/placement choices that should not disappear inside import convenience
- continued pressure to keep portable cores, local overlays, materialization bays, publication ladders, and exact action keys cooperating without adding more pillars


## New pressure added in rev0034

- anchor maps as shell-owned typed slot maps for carried references, companion bindings, parameterized inputs, and receiver binding expectations
- inherit masks as shell-owned bounded receiver-default declarations rather than ambient fallback or hidden local carry
- continued pressure to keep landing manifests, residue ledgers, fit cards, rebind ladders, local overlays, exact action keys, command docks, and deck recipes cooperating without turning Helm into a giant sync or import constitution


## New pressure added in rev0036

- landing rehearsals as shell-owned try-before-adopt receiver-local surfaces for portable, saved, or derived shell luxuries
- near-match fences as shell-owned exactness guards that allow inspection of similar local candidates without silently rebinding them as exact truth
- continued pressure to keep landing manifests, anchor maps, basis stamps, residue ledgers, fit cards, and rebind ladders cooperating without turning Helm into a giant import simulator or self-healing matcher


## New pressure added in rev0046

- three-form law as a shell-wide distinction between recipe/definition, ticket/snapshot/stable review slice, and live instance/current lane
- review tickets as compact shell-owned stable review objects for compare, paging, checkpoint review, route review, and handoff
- continued pressure to keep saved view objects, checkpoint branches, launch ladders, materialization bays, and current-live reentry honest without adding a pillar or a giant timeline constitution

## New pressure added in rev0047

- activity spines as shell-owned scoped work frames that can gather saved views, checkpoints, command bands, launch/layout starters, review tickets, and one current-live beacon without becoming a new pillar or a giant workspace religion
- shared-scope tightening as a stronger law: sharing a spine may clamp memory and local carry rather than inheriting ambient personal context
- continued pressure to keep saved view objects, checkpoint branches, review tickets, publication ladders, and current-live reentry honest under explicit scoped work rather than ambient recent/open/share folklore


## New pressure added in rev0048

- resource shelves as shell-owned curated grouped-resource surfaces that can sit inside activity spines without becoming current-live truth, permission engines, or hidden collaboration blobs
- current-versus-all export/share as a stronger grouped-surface law for shelves, tabs, decks, and related shell collections
- continued pressure to keep activity spines, saved view objects, checkpoint branches, view decks, command docks, and publication ladders cooperating without turning Helm into a giant workspace or browser-collection constitution

## New pressure added in rev0049

- activity entry kits / front doors as shell-owned saved starters that can sit on top of activity spines and resource shelves without becoming live truth or a giant workspace religion
- one preferred front door plus explicit inspect / attach / restore / relaunch / fresh-start ladders as a stronger return-to-work law
- continued pressure to keep activity spines, resource shelves, saved views, checkpoint branches, and current-live beacons cooperating without collapsing saved starters into flattering resume folklore
