# SlopOS + Schell evaluation — 2026-03-21 pass XVI

Purpose: continue tightening Helm against the current SlopOS and Schell datacubes **without** pretending either teacher is fully settled.

This pass was driven by four pressures:

- SlopOS keeps getting better at refusing to smuggle a **second workflow** through a convenient first workflow.
- SlopOS keeps defending the split between **exact reviewed descriptors** and **current provider-owned live truth**.
- Schell keeps validating source/mode separation, lineage, and receipt-bearing shell-facing work, but is still too young to import wholesale.
- Current public tools keep proving that persistent host-owned launch surfaces and review/apply harbors can be great **if** they remain explicit projections over shell truth.

## What SlopOS keeps teaching Helm

### 1) The second workflow must not be smuggled through the first workflow

Recent OpenURI boundary work keeps making the same move from several angles:

generic launch is **not** automatically also:

- tab/window/task placement authority,
- embedded browser presentation authority,
- remembered browser-permission authority,
- install fallback authority,
- or durable materialization authority.

That is one of SlopOS's strongest product lessons.

For Helm this means:

- generic **open** should stay weaker than reviewed placement or reuse,
- generic **preview** should stay weaker than open / attach / import / run,
- generic **recall** should stay weaker than continuity proof,
- and generic **background help** should stay weaker than adoption into the live lane.

Helm should steal this law aggressively.

### 2) Descriptor truth and live truth should remain visibly different

SlopOS keeps repeating that receipts, descriptors, grants, and accepted requests may be exact and valuable while still **not** proving current live state.
That pressure is especially visible in lease/grant boundaries and acceptance/completion posture.

For Helm this continues to harden:

- **Operations Center** as the place that names request, admission, launch, live observation, and historical receipt separately
- **Recall** as a continuity surface that can name exact, restored, historical, held, and unavailable without bluffing
- **entry kits / launch ladders / workspace capsules** as powerful saved artifacts that still do not impersonate live truth

### 3) Provider-local choice can be good without becoming portable shared law

SlopOS's OpenURI work is strongest when it says:

- local platforms may absolutely do useful things,
- but those useful things should not automatically become transcript-stable shared substrate meaning.

That matters directly to Helm.
The shell can absolutely own rich local behavior — placement policy, preview renderers, compact docks, adoption harbors, local quick actions — while still refusing to pretend those are generic cross-product truths until Helm earns them.

This is a useful pattern for Helm's current design phase:

**host-owned projection first, portable law later if ever.**

### 4) Exact reveal/select remains one of the cleanest imports

SlopOS still keeps teaching that “show this exact thing selected” should fail closed instead of quietly degrading into nearby browse.
That remains one of Helm's best imports.

It keeps paying rent in:

- **Object Browser**
- **Recall**
- **Omnibox**
- and any future breadcrumb / exact-trail cues

### 5) Shell-facing richness matters, but Helm should still import it narrowly

Schell continues to justify:

- command-boundary witnesses
- receipts
- source grading
- mode separation between direct command and delegated/conversation work
- lineage pressure stronger than raw shell history

But Helm should still avoid importing:

- final retention law
- terminal-local ontology as shared desktop truth
- pane/session folklore as a substitute for route, receipt, and reveal truth

## What this pass changes in Helm's posture

This pass increases confidence in five directions:

1. **keep the pillar set stable**
2. **keep terminal/capshell as a native front-end family rather than an eighth pillar**
3. **treat command docks as candidate projections over existing truth, not new shell law**
4. **treat delegated/background output as candidate work that should land in a review/apply harbor before it can count as live truth**
5. **keep exact trails, breadcrumb-like cues, and recent exact-object pressure warm without overfreezing them yet**

## Warm candidate ideas this pass strengthens

- **command docks** — small persistent host-owned command/status bands over already-legible shell truth
- **adoption harbors** — small shell-owned review/apply surfaces where shadow lanes, delegated work, repair output, or background sessions can land before touching the authoritative live lane
- **workspace capsules** — still warm, now more sharply separated from live continuity
- **launch ladders** — still warm, now better constrained by SlopOS's anti-smuggling law
- **sticky context strips** — still warm, now better justified by background-session tracking and apply/review pressure
- **exact breadcrumb / trail cues** — warmer than before, but not yet worthy of a frozen candidate contract

## Explicit non-takes in this pass

- Do not turn a command dock into a hidden second launcher constitution or extension bazaar.
- Do not let a dock or pinned shortcut silently carry review/receipt authority it has not earned.
- Do not let delegated/background work mutate the live lane just because the helper looked competent.
- Do not import VS Code / Copilot / Cursor / Warp background-agent worldview whole.
- Do not let workspace capsules or launch configurations impersonate current live continuity.
- Do not let exact breadcrumb/trail cues pretend to be more than exact location/orientation evidence.
