# SlopOS / Schell evaluation — 2026-03-21 pass XXIV

Purpose: keep evaluating what SlopOS's datacube is actually teaching Helm now that handoff packets and promotion receipts are already warm.

This pass focused on a narrower question:

**what should Helm learn about the split between a surface's portable core and its local overlay without mistaking either for universal live truth?**

## 1) View replication boundary teaches that portable summaries are not active local bindings

`view-replication-boundary-v0.md` remains a very strong teacher.
Its refusal is now especially relevant for Helm:

- a view can have replicated summaries,
- non-owner replicas may keep read-only cache-shaped state,
- but those artifacts do not auto-attach,
  auto-detach,
  or silently become the receiver's active local view.

That is now pushing Helm toward a sharper portable/local split.
If a Helm surface travels well,
it probably needs a **portable core** that can survive travel honestly,
while leaving **local overlays** behind.
The traveling core might include:

- recipe,
- structure,
- derivation witness,
- subject handle,
- affordance class,
- or other travel-safe shell truth.

But the receiver's local overlay remains separate:

- placement,
- provider/account selection,
- workspace/session choice,
- personal shortcut,
- visible dock arrangement,
- or other local convenience state.

## 2) Namecert projection/time/revocation/trust-root boundaries teach that local policy and later local state stay local

The namecert cluster sharpens the same lesson in a more exact way.

`namecert-projection-boundary-v0.md` keeps evaluation separate from materialization.
A bundle evaluation does not silently mutate active local state;
a live effect lands only through explicit `view.attach` / `view.detach` on concrete local slots.

`namecert-time-boundary-v0.md`,
`namecert-revocation-boundary-v0.md`,
and `namecert-trust-root-boundary-v0.md` sharpen the after-story:

- later freshness or revocation evidence changes **future admission**,
  not old live bindings by magic,
- trust anchors remain **evaluator-local input**,
- and replicated bundle evidence does not auto-install trust roots or trigger hidden detach.

That maps cleanly to Helm.
A portable deck,
key,
recipe,
or dock item should not smuggle:

- local trust posture,
- local account choice,
- local secrets,
- local session/profile choice,
- or other evaluator-local overlay state.

Those things belong in a **local overlay**,
not in the portable core.

## 3) OpenURI and safe-open keep teaching that travel-safe handles and local materialization are different workflows

The OpenURI family still matters here too.
`openuri-materialization-boundary-v0.md` and `open-untrusted-materialization-boundary-v0.md` both keep drawing the line:
open/preview is not portable download,
local import,
docref minting,
or save-through truth.

That same anti-smuggling law now wants a stronger Helm form.
A portable surface should therefore split cleanly into:

- the **portable core** that can be exported/shared/handed off,
- and the **local overlay** that appears only after receiver-side materialization,
  adoption,
  or rebinding.

## 4) The datacube lesson is now less "what travels?" and more "what portion travels?"

Earlier passes got Helm to handoff packets and promotion receipts.
This pass says the next pressure is more specific.
The important question is no longer only:

- should a surface travel,
- and what witness should the promotion leave behind?

It is now also:

- **what exact subset is safe to travel at all?**
- **what must remain a local overlay?**

That is the more precise SlopOS datacube reading:

- bounded projections,
- explicit view objects,
- explicit materialization,
- explicit basis witness,
- explicit locality,
- and now a sharper split between **portable core** and **local overlay**.

## 5) Strongest Helm payoffs from this pass

### Portable cores

Portable cores now look like the smallest honest answer to:
"what exactly goes inside a handoff packet?"

A portable core should carry only the part of a shell surface that:

- survives travel,
- stays inspectable,
- does not depend on local secret or trust state,
- and does not bluff about active receiver-side bindings.

That could become a very strong cross-cutting move for:

- deck recipes,
- exact action keys,
- dock items,
- entry kits,
- flow fragments,
- and some view decks.

### Local overlays

Local overlays now look like the honest home for the rest:

- dock placement,
- device-specific layout,
- local shortcuts,
- account/profile/session choices,
- trust posture,
- local residue,
- and other personal/activity-local adjustments.

Helm probably wants those overlays badly.
But it should want them as **rebuildable, inspectable, local-only deltas**,
not as silent shared-state baggage.

## 6) What this pass changes

- it adds **portable cores** as a new warm Helm move
- it adds **local overlays** as a new warm Helm move
- it sharpens the reading of SlopOS's datacube as a teacher of **what exact subset may travel** rather than just whether a surface travels at all
- it strengthens handoff packets,
  promotion receipts,
  publication ladders,
  and surface locality tiers by giving them a crisper internal split

## 7) What this pass still does not justify

- a giant shared-state shell constitution
- automatic cross-device or cross-user replay of local overlays
- portable credentials,
  trust anchors,
  or session/profile choices hidden inside handoff packets
- ambient sync as a substitute for receiver-side rebinding/materialization
- adding more pillars

## Current bounded take

**Helm should keep reading SlopOS's datacube as a teacher of bounded projections,
explicit materialization,
explicit locality,
explicit basis witness,
and now a sharper split between a surface's portable core and its local overlay.
That pushes Helm toward portable cores and local overlays without justifying ambient sync,
portable secrets,
or any universal live shared-state bluff.**
