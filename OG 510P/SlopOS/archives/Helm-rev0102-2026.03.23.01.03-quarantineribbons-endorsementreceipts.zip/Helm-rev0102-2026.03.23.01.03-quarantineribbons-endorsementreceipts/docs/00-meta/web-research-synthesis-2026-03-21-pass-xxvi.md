# Web research synthesis — 2026-03-21 pass XXVI

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on a narrower travel problem:

**if Helm already has portable cores, local overlays, fit cards, and rebind ladders, what exact witness should travel with a surface, and what helpful side context should be allowed to travel without impersonating authority?**

## 1) Notion now strongly validates first-class views, composite dashboards, and explicit view objects

Notion's current API posture is more relevant to Helm than earlier “database app” takes.
Views are now first-class resources.
A single data source can have many view presets with different filters,
sorts,
and layouts.
Dashboard views can arrange multiple widget views in a grid.

That matters because it keeps composite surfaces legible as **named view objects** rather than as one giant live blob.
The stealable law is:

**a composed shell surface should travel as an explicit recipe/object with a compact manifest, not as implied ambient state.**

This is strong support for a Helm **landing manifest**:
a compact carried witness that names the portable core,
view/deck family,
basis,
carried companions,
and deliberate omissions before the receiver even starts fit evaluation.

## 2) Figma finally makes companion resources feel earned rather than merely cute

Figma Dev Mode now gives two unusually relevant public patterns at once:
compare against explicit prior or main-component basis,
and attach external dev resources like GitHub,
Jira,
Storybook,
and VS Code links that propagate to component instances.

That is almost exactly the shape Helm needs for a warmer move that now looks ready for a real contract:
**companion resource bundles**.

A good Helm surface should be able to carry a few travel-safe secondary resources that help a receiver land the thing well:
runbooks,
docs,
dashboards,
code links,
queries,
or tickets.
But those companions must stay visibly secondary.
They are not the live object,
not proof of fit,
and not a trust decision.

## 3) Raycast keeps proving the value of exact launch handles plus explicit non-traveling residue

Raycast Deeplinks can run enabled commands through exact `raycast://...` handles and pass initial data through `fallbackText`.
That is a strong model for exact action handles that carry *some* starting context.
Raycast Cloud Sync is just as important in the opposite direction:
it synchronizes aliases,
hotkeys,
quicklinks,
snippets,
notes,
and extension settings,
but does not synchronize Clipboard History,
credentials/passwords,
script commands,
or general/advanced settings.

That strengthens two Helm takes at once:

- exact handles should be able to carry a small explicit start context,
- and the portable side should say what it **did not** carry,
  because local residue is part of honest landing.

That is more support for **landing manifests** than for any ambient sync story.

## 4) VS Code and Warp keep rewarding explicit saveable structure that still lands through review or activation

VS Code Profiles remain a strong model because profiles are explicit sets of customizations that can be exported,
imported,
and associated with a current folder or workspace.
Background/CLI agent work is isolated in Git worktrees,
then reviewed and applied or migrated back into the main workspace.
Warp does something similar at a shell/session level:
Launch Configurations save windows,
tabs,
and panes,
and the URI scheme can open a new window,
a new tab,
or a launch configuration.

The stealable law is:

**saved and portable structure should be easy to invoke,
but it should still land through explicit review,
activation,
or apply steps rather than by quiet ambient takeover.**

## 5) WezTerm, Obsidian, and PowerToys still keep the honest-shell constraints visible

WezTerm workspaces can exist without becoming visible until activated.
Obsidian's workspace layout files are mutable local residue that update as you open files and may belong in `.gitignore`.
PowerToys' Dock is a persistent edge-resident command surface rather than a hidden background constitution.

Together they keep validating the same shell law:

**small persistent surfaces and saveable context can be delightful,
but they only stay lovable when the shell is honest about activation,
local residue,
and what kind of object the user is actually touching.**

## 6) Strongest new warm moves from this pass

- **landing manifests** — compact carried witnesses attached to portable cores,
  handoff packets,
  deck recipes,
  exact action keys,
  or other travel-ready shell surfaces,
  naming family,
  basis,
  carried structure,
  companions,
  omissions,
  and intended landing posture before the receiver computes fit
- **companion resource bundles** — travel-safe secondary resources such as docs,
  runbooks,
  dashboards,
  Storybook,
  code links,
  tickets,
  and exact query links that can ride with a shell surface without becoming the surface's authority,
  liveness,
  or trust story

## 7) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- companion resources are now strong enough to formalize as a warm candidate contract
- portable shell surfaces should arrive with a visible carried-basis story,
  not only a receiver-side fit story
- composite views are worth stealing only as explicit view objects,
  not as a collaboration constitution

## Strongest non-takes from this pass

- do not let companion bundles impersonate live authority,
  fit,
  or trust
- do not turn landing manifests into a giant sync schema
- do not treat dashboard-like composite views as a reason to add a collaboration pillar
- do not let saved/view objects or launch configs silently count as active local presence
- do not add pillars
