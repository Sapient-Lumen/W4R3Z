# Web research synthesis — 2026-03-22 — pass LXXXVI

Purpose: continue the outside scan and pressure Helm with durable patterns rather than novelty theater.

## Main idea

The best outside systems keep separating:
- what was requested,
- what has been observed,
- whether work is still progressing,
- whether the current state is restricted,
- and whether the observation still matches the latest mutable basis.

Helm should steal that discipline.

## 1. Kubernetes keeps status honest by standardizing conditions and binding them to observed generations

Kubernetes' conditions work is a strong teacher because it treats conditions as common enough to deserve a shared schema,
not a thousand one-off badge stories.
The conditions standardization effort explicitly says `.status.conditions` should have a common type and common utility methods instead of drifting by accident.

Even more useful for Helm,
current Pod docs now make `status.observedGeneration` explicit.
That is a very strong design clue:
status is not just “what is true,”
it is also **what generation of the mutable basis that truth belongs to**.

That is almost exactly Helm's missing chip.

## 2. Argo CD shows that compact health classes can be useful without becoming one giant source of truth

Argo CD is helpful because it exposes a small health grammar:
- `Healthy`
- `Progressing`
- `Degraded`
- `Suspended`
- `Missing`
- `Unknown`

It also checks observed generation against desired generation for core workload kinds.
And it explicitly declines naive health inheritance from child resources.
That last choice matters.
Parent state should not silently inherit child trouble unless the contract says so.

Helm should steal:
- small named status classes,
- worst-of rules only where a surface contract explicitly wants them,
- and “not inherited by default” posture.

## 3. GitHub checks show why progressing state and conclusion state must stay separate

GitHub check runs and check suites keep `status` separate from `conclusion`.
That is a better model than one badge that tries to mean both.
A run can be:
- `queued`,
- `in_progress`,
- `requested`,
- `waiting`,
- `pending`,
- or `completed`.

Only once completed does conclusion apply,
with values like:
- `success`,
- `failure`,
- `cancelled`,
- `timed_out`,
- `neutral`,
- `skipped`,
- and even `stale` after a long incomplete period.

That is an excellent pattern for Helm.
Do not collapse:
- still running,
- ended well,
- ended badly,
- stale,
- and waiting-on-external-thing
into one flat color.

## 4. Google Cloud long-running operations show a tiny but powerful status split

Google's long-running operations are simple in exactly the right way.
There is operation metadata,
a `done` bit,
and then either a response or an error once complete.

That is a strong reminder that a shell row often does **not** need a giant status universe.
It may only need:
- exact operation id,
- basis or metadata,
- still running vs done,
- and final response-or-error truth.

Helm should borrow that compactness for many strong-act rows.

## 5. VS Code Restricted Mode proves blocked-but-browseable posture can be explicit and humane

Workspace Trust is still one of the best product examples of “restricted first, trust later.”
Restricted Mode shows a visible banner and status badge,
and it keeps browsing possible while disabling or limiting execution-rich features such as agents,
tasks,
debugging,
and extensions.

This matters for Helm's status grammar because it keeps **restricted** separate from:
- broken,
- unknown,
- and ready.

That distinction is worth stealing everywhere.

## 6. systemd still teaches that one state is often too few

systemd's older docs and release notes remain a useful teacher even if Helm should not copy the product.
The project explicitly distinguishes active state and substate,
and `systemctl status` also surfaces the results of unit condition checks from the last start attempt.

The principle is the valuable part:
- one coarse state,
- one finer-grained state,
- and explicit condition-check results
is often better than pretending one word explains everything.

## 7. What Helm should steal

### Steal now
- a compact **condition strip** grammar with named condition rows
- a compact **observed-basis chip** grammar with explicit match / behind / unknown posture
- a split between **progress / running state** and **final conclusion state**
- a split between **restricted** and **failed**
- a split between **historical as-of** and **current live now**
- no child-status inheritance by default
- explicit stale posture when old status is all we still have

### Refuse for now
- no giant generic event/status service
- no universal transitive health propagation
- no one-badge summary that hides basis age
- no pretending simulation / preview / old observation is present-live truth

## 8. Best first proofs for Helm

- one Object Browser row with a condition strip over an exact saved view
- one Operations row with condition strip plus observed-basis chip over a long-running stronger act
- one Recall card that says **historical status observed on basis X** rather than wearing a live badge
- one blocked-but-browseable imported surface with `restricted` status that is neither failure nor success
- one watchpoint card where `muted` stays visibly different from `healthy`

## Judgment

The next strong import is not a new pillar,
and not a bigger cube.
It is a small shared status grammar:
- **condition strips**
- **observed-basis chips**.

Those two moves let Helm say much more truth with much less machinery.
