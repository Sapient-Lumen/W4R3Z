# Web research synthesis — 2026-03-23 — pass LXXII

Question: after claim/reliance honesty, what cross-cutting rule still looks under-modeled for Helm's datacube?

Answer from this pass: **freshness windows + revalidation rails**.
The best current systems do not just say whether something is cached or updated.
They name how long it stays fresh,
what happens when it goes stale,
what fallback is still allowed,
and why revalidation happened.

## What current tools keep teaching

### 1. Useful cached slices should carry explicit expiry

Notion's view-query flow executes a saved view,
returns a `query_id`,
and gives the cached result an `expires_at` field.
The cached results expire after 15 minutes.

The lesson is simple:
**a saved slice can be real and useful without pretending to be timeless.**

### 2. Freshness and re-fetch are different knobs

TanStack Query makes this split unusually explicit.
`staleTime` defines how long cached data stays fresh.
Once stale,
it may refetch automatically in the background on mount,
window refocus,
network reconnect,
or a configured interval.

The lesson for Helm is:
**freshness posture is one question; revalidation triggers are another.**
Those should not collapse into one vague “auto refresh” checkbox.

### 3. Stale can still be usable if the fallback class is explicit

RFC 5861 distinguishes `stale-while-revalidate` from `stale-if-error`.
One allows immediate stale delivery while revalidation happens in the background.
The other allows stale delivery only when the origin errors,
improving availability without pretending the stale response is fully fresh.

Workbox teaches the same idea in product language:
a stale-while-revalidate strategy can serve cached content immediately,
then update the cache from the network in the background.

Helm should steal the law,
not the literal transport cache behavior:
**stale may still be usable,
but only under a named fallback posture.**

### 4. Revalidation benefits from exact reasons and exact scopes

Vercel's current cache docs distinguish time-based revalidation,
on-demand revalidation,
and tag-based revalidation.
Vercel's runtime logs also surface the revalidation reason,
including time-based,
tag-based,
or deployment-based.

That is a very strong precedent for Helm.
An object should not just say “updated.”
It should be able to say **why** it was revalidated and at what scope.

### 5. Freshness budgets often depend on the surface, not just the source

Grafana's query caching shows that a panel's interval affects whether cached data is used or fresh data is fetched.
Wider panels and shorter ranges fetch new data more often;
narrower panels and longer ranges can serve cached data for longer.
Power BI similarly keeps dashboard tile refresh distinct from live query/report behavior;
dashboard tiles refresh on a schedule,
while other surfaces can behave more like live queries.

Helm should steal that distinction.
**surface form changes freshness budget.**
A glance card,
watch summary,
Overview tile,
and exact saved view do not need identical freshness windows.

### 6. Freshness decay should gate stronger reliance

GitHub's stale-approval posture is the cleanest adjacent lesson.
When the diff changes after approval,
GitHub can dismiss stale approvals,
and the work must be approved again.

This is not a cache example,
but it teaches the right design instinct:
**when the basis drifts,
stronger reliance should downgrade rather than glide forward on convenience.**

## What Helm should steal

- one explicit freshness window on saved or derived shell objects when recency matters
- visible decay stages such as fresh,
  stale-but-usable,
  stale-if-error / fallback-only,
  expired,
  and unknown / receiver-cannot-verify
- exact revalidation rails:
  background,
  on-demand,
  tag/family-driven,
  reopen-source,
  compare-against-current,
  or hold
- revalidation reason witness
- different freshness budgets for different surface forms
- stronger actions that downgrade when their freshness window has decayed beyond the allowed rung

## What Helm should not steal

- a universal always-live promise
- hidden background refresh that silently changes what a saved card means
- one timestamp badge pretending to solve freshness,
  drift,
  and authority together
- provider-owned TTL folklore hidden off to the side
- giant cache-administration UI just to get one honest freshness law

## Why this matters to the pillars

This is not a new pillar.
It helps the existing ones stay honest:

- **Object Browser** can keep saved views,
  linked views,
  and query slices explicit about freshness and revalidation posture
- **Operations Center** can separate evaluation currentness,
  summary currentness,
  and quiet/background revalidation work
- **Recall** can show when remembered or reopened artifacts are exact-but-stale instead of pretending they are live
- **Exchange** can let packets and receiver-fit cards carry freshness posture without turning travel into current truth
- **Omnibox / Overview** can tell the operator whether a card is fresh,
  stale-but-usable,
  or needs a stronger reopen/revalidate/compare step

## Judgment

Helm does not need another pillar.
It does not even need a giant new object family.

It now needs one cross-cutting answer to:
**how long is this shell object meaningfully fresh,
what happens when it decays,
and what is the exact responsible way to revalidate it?**

The answer now looks like:
**freshness windows + revalidation rails**.
