# Web research synthesis — 2026-03-21 — pass X

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on one sharper question:

**what do current systems teach about strong actions that must not silently follow a changed basis?**

The answer is unusually coherent across very different systems:
good systems increasingly refuse sticky approval and sticky update semantics.
They bind review to one exact version,
one exact diff,
one exact resource version,
or one exact ownership boundary,
and they reject stale updates instead of pretending nothing changed.

That points Helm toward two outcomes:
- freeze **reviewed-basis truth** narrowly,
- and add **basis packets** as a candidate move.

## Cluster 1 — code review systems increasingly refuse sticky approvals

### What current systems teach

GitHub's protected-branch rules are extremely clear here.
If stale review dismissal is enabled,
GitHub records the state of the diff at the point when a pull request is approved.
If the diff later changes,
the approval is dismissed as stale and the pull request cannot be merged until someone approves again.

That is one of the cleanest mainstream examples of the exact lesson Helm needs:
**approval should bind to the reviewed basis, not to a floating “latest version of this thing.”**

### What Helm should steal

Helm should steal:
- stale-basis dismissal as a first-class truth,
- review-again instead of silent carry,
- and exact basis identity rather than success-shaped continuity glow.

### What Helm should refuse

- “you approved this earlier, so the newest nearby state probably counts”
- continuity cards that remember the review but lose the basis
- strong actions that inherit approval from a past state by vibe alone

## Cluster 2 — conditional web requests show a tiny, elegant compare-and-set pattern

### What current systems teach

HTTP conditional requests are a beautiful compact teacher.
MDN's `If-Match` docs say the header can be used with `PUT` to prevent the lost update problem:
the server can check that the modification will not overwrite another change made since the original resource was fetched.

That is basically a tiny universal law for Helm:
- compare current truth against the reviewed basis,
- proceed only on match,
- otherwise refuse and explain.

### What Helm should steal

Helm should steal:
- tiny compare-and-set semantics,
- visible mismatch rather than optimistic overwrite,
- and reusable `match / drifted / unknown` language for strong actions.

### What Helm should refuse

- sticky strong-action buttons on mutable objects with no current compare
- a belief that basis drift is only a backend concern instead of a shell-truth concern
- hidden fallback from exact match to near-enough

## Cluster 3 — Kubernetes makes stale writes and field ownership explicit

### What current systems teach

Kubernetes says a client updating an object with `PUT` must specify the object's `resourceVersion`,
and the API server uses that to detect lost updates and reject stale requests.
Its Server-Side Apply docs go further:
the control plane tracks managed fields,
conflicts when another manager owns a field,
and forces an override only as an explicit action.

That gives Helm two very strong steals:
- version-bound updates,
- and explicit ownership conflicts rather than silent merge folklore.

### What Helm should steal

Helm should steal:
- exact version witnesses for strong actions,
- conflict-visible ownership stories,
- and explicit force / override steps instead of hidden takeover.

### What Helm should refuse

- shell surfaces that imply one actor still “owns” a decision after the basis changed
- a flattening of review and force-override into one action path
- giant ownership algebra before one compact basis packet exists

## Cluster 4 — task-return tools already expose drift and reuse, but basis is still scattered

### What current systems teach

PowerToys Workspaces remains a good warning sign.
It documents app-specific launch arguments,
explicitly distinguishes opening new windows from repositioning existing windows,
notes that some apps are single-instance,
and even shows per-app launch status during reconstruction.

That is honest and useful.
But the evidence is still scattered across launch notes,
reposition behavior,
single-instance quirks,
and status dialogs.
Helm can do better by making basis and drift one first-class witness.

### What Helm should steal

Helm should steal:
- explicit launch/reuse status,
- app-specific behavior notes,
- and visible drift during reconstruction.

### What Helm should refuse

- continuity or launch cards that know reuse happened but do not say whether the current basis still matches the reviewed one
- shell-owned saved-task luxuries that overclaim certainty because the reconstruction mostly worked

## Cluster 5 — agent systems still rely on explicit session boundaries and review/application steps

### What current systems teach

VS Code's agent sessions stay separate by default,
archive the original session after handoff,
and let the operator review and apply file changes from session details.
That is not the whole Helm answer,
but it reinforces the direction:
powerful delegation still keeps versioned review and apply moments explicit.

### What Helm should steal

Helm should steal:
- archive-vs-active distinction,
- review/apply as visible stages,
- and continuity that keeps its basis legible across handoff.

### What Helm should refuse

- assistant-rich continuity surfaces that pretend the current result still carries the same reviewed basis with no current compare
- magical-seeming handoff that hides stale basis under smooth copy

## Cluster 6 — tiny dynamic accelerators are still worth stealing, but they need source and basis honesty

### What current systems teach

Raycast Quicklinks and Dynamic Placeholders keep proving that users want tiny reusable accelerators with arguments,
clipboard carry,
selected text,
browser-tab content,
and snippets.

That is worth stealing for Helm.
But the more dynamic the seed becomes,
the more important it is to say:
- what came from the saved seed,
- what came from current ambient context,
- and what exact current basis a strong action now depends on.

### What Helm should steal

Helm should keep tiny accelerators alive,
but make source and basis honesty first-class as they grow more powerful.

### What Helm should refuse

- raw macro folklore as the default substrate
- seed expansion that silently acquires strong-action legitimacy from current ambient context
- saved accelerators that look reviewed forever

## Pass-X bounded take

The current external idea harvest most strongly supports two Helm moves:
- freeze reviewed-basis truth narrowly,
- and explore basis packets as compact shell-owned witness strips/cards that complement binding witnesses, scope witnesses, and continuity choice witnesses.

