# Web research synthesis — 2026-03-22 — pass XLIV

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move is to sharpen **current-live beacons** and **activity scope witnesses** on top of activity spines, resource shelves, and entry kits.

This pass focused on one question:

**once Helm has saved front doors and grouped work frames, what tiny shell-owned object tells the truth about what is actually current, live, local, and in-scope right now?**

## Main takeaway

The outside world is validating a very specific pressure:

**Helm likely wants one stronger current-live beacon and one refreshed scope witness.**

Not a new pillar.
Not a giant workspace blob.
Not an ambient profile/session myth.

A good Helm answer would likely be:

- **current-live beacon** — the shell-owned exact cue for the real live lane right now
- **activity scope witness** — the compact explanation of which axes counted and which nearby context stayed out

Those two moves now look more important because Helm already has:
- saved view objects
- checkpoint branches
- review tickets
- activity spines
- resource shelves
- activity entry kits / front doors

Without a beacon and a witness,
those objects risk flattering the user about currentness or scope.

## What the outside world is validating now

### 1. Scoped work keeps getting stronger boundaries, not weaker ones

ChatGPT Projects is one of the clearest current proofs.
Projects can gather chats, files, and instructions under one shared objective.
Project-only memory keeps context inside the project boundary, and shared projects force that tighter posture.

Arc is validating a related idea from the browser side:
Spaces are distinct contexts,
and Profiles scope cookies, history, and settings across one or more Spaces.

VS Code is validating the security/trust side:
a workspace can be opened in Restricted Mode,
and trust state is explicitly visible rather than ambient.

The steal-worthy lesson is not “copy any one product.”
It is:

**the shell should stop pretending nearby context is automatically in scope.**

That makes activity-scope witnesses much more timely again.

### 2. Saveable grouped work is useful, but it is still weaker than current live truth

Dropbox Dash Stacks,
Chrome saved tab groups,
Google Docs tabs,
Linear favorites,
Linear attached project views,
and VS Code Profiles all validate durable grouped work objects.

But none of that grouped structure is the same as the exact current lane.
It is:
- saved structure
- grouped context
- attached perspectives
- or shared starters

That is excellent pressure for Helm.

It suggests the shell should keep:
- resource shelves,
- activity entry kits,
- and activity spines

but also add one stronger shell-owned cue for:

**this is the actual live thing now.**

### 3. “Current” versus “all grouped things” is becoming a common interaction truth

Google Docs tabs is especially useful here.
It supports deep links to the active tab,
and when downloading or printing it asks for **current tab** versus **all tabs**.

That is a very Helm-shaped lesson:
grouped work is helpful,
but users still need a clear way to point at the current subthing.

That argues for:
- one current-live beacon within an activity spine
- one honest current-subthing export/share choice
- and weaker grouped objects that do not overclaim live status

### 4. Shared views are strongest when they stay inspectable and scoped

Linear now makes custom views both saved and favorite-able,
and lets teams attach project-specific issue views directly as tabs inside a project.
That is strong validation for saved view objects living near scoped work.
But the project tab still is not the same thing as the current live task lane.

Helm should steal:
- attached saved views near scoped work
- one obvious front door
- one obvious current-live beacon
- one scope witness explaining whether same-activity claims remained exact

### 5. Preview and quick action work best when they stay near stronger truth

Arc Peek,
Quick Look,
Finder Preview/Quick Actions,
and PowerToys Command Palette all keep fast inspection and nearby action close to the user.
But they do not have to pretend that a preview,
launcher,
or grouped set is already the live durable thing.

That keeps validating Helm's middle-state stack:
preview,
compare/rehearse,
adopt/materialize,
live truth.

The new twist is that the live stage now wants a stronger visible witness.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Current-live beacons**
   - one shell-owned cue per meaningful activity/work frame
   - visibly stronger than recents, entry kits, checkpoints, or grouped resources
   - exact where the shell really has a live hook
   - historical/unknown when it does not

2. **Refreshed activity scope witnesses**
   - compact included/excluded-axis disclosure
   - explicit exact / widened / switched / imported / unknown posture
   - attached to stronger continuity claims rather than shown everywhere

3. **Current-subthing versus all-grouped-things choice**
   - export/share/print/send current one
   - or all grouped members
   - without hiding which happened

4. **One compare step between saved front door and current live lane**
   - not a giant diff theater
   - just enough to answer:
     are we returning to the same thing,
     a widened thing,
     or a merely similar thing?

### Tier 2 — steal soon, but keep the contract modest

1. beacon age / last-witness time
2. one explicit “scope changed” chip
3. personal/shared/imported trust posture next to the beacon
4. compact current-live hooks inside Recall and Omnibox results

### Tier 3 — keep warm only

1. giant workspace dashboards as the only way to know currentness
2. ambient profile/session inference
3. auto-promotion from recent/opened to current-live authority
4. pretending saved groups are equivalent to current live state

## Judgment for Helm

Helm should still avoid adding pillars.

But one support object now looks ready to define,
and one older one looks ready to refresh:

- **current-live beacons** — shell-owned exact current-lane cues
- **activity scope witnesses** — compact axis/inclusion/exclusion witnesses for same-activity claims

The main law is simple:

**saved starters, grouped resources, and historical receipts can point toward currentness, but they should not wear the badge of current live truth themselves.**
