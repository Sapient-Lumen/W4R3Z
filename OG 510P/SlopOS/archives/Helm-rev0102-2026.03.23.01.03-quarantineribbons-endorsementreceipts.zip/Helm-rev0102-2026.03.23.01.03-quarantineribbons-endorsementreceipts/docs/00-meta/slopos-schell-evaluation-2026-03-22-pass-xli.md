# SlopOS / Schell evaluation — 2026-03-22 — pass XLI

Purpose: keep using SlopOS's datacube as Helm's harshest truth teacher while testing whether Helm's next support object should be a **scoped activity spine**.

## Main takeaway

SlopOS is teaching that scope is only useful when it stays **exact, explicit, and non-ambient**.

That sounds obvious,
but it is exactly where shell products usually lie.

The strongest new lesson is:

**an activity object must not widen by adjacency, sharing, recent use, or launch side effects.**

If Helm adds activity spines,
then SlopOS says they must remain disciplined about:
- scope
- locality
- sharing
- recency
- and the difference between a remembered recipe and a current live lane

## What SlopOS is teaching especially well right now

### 1. Ambient adjacency is not valid scope

Helm already absorbed some of this lesson in activity-scope witness pressure,
but the newest SlopOS boundary clusters keep reinforcing it.
Recent-items,
subject-echo,
materialization,
and session-selection boundaries all refuse a common lie:

because two things were nearby in one workflow,
they now count as the same durable activity truth.

For Helm that means:
- nearby windows do not automatically belong to the same activity spine
- nearby browser/account/profile context does not silently become in-scope memory
- recently opened material does not auto-enroll into the spine
- imported or shared material does not become live just because it landed here

### 2. Explicit scope widening is healthier than friendly ambiguity

SlopOS keeps pinning wide surfaces to explicit scope choices.
Even profile-scoped secrets are explicit about when scope widens to user or device.
That is a strong design attitude for Helm.

An activity spine should not quietly grow from:
- personal
to shared
to published
to ambiently remembered

Instead the shell should expose stronger scope rungs explicitly.
That fits Helm's publication ladders,
trust posture,
and lineaged cross-boundary moves.

### 3. Open and share should not backdoor activity enrollment

The OpenURI family remains one of the best anti-laundering teachers in the archive.
It keeps refusing portable recents control,
portable materialization,
portable subject echo,
and portable activation control.

For Helm this becomes a strong activity-spine law:
- open does not auto-add to an activity spine
- preview does not auto-add to an activity spine
- share does not auto-activate receiver-side activity membership
- current-live reentry must stay stronger than “touched once in this project”

### 4. Exact basis still matters inside a scoped activity

It would be easy to think that once Helm has a project-like object,
it can get looser about basis.
SlopOS says the opposite.

A scoped activity object is exactly where you most need to know:
- which saved view definition you are using
- which review ticket was cut when
- which checkpoint branch is current
- which quick action is personal versus shared
- which remembered resource is still actually local/live

In other words,
activity scope does not replace exactness.
It makes exactness more valuable.

### 5. Sharing should often tighten boundaries, not loosen them

This is one of the best external-to-internal resonances right now.
ChatGPT shared projects are pushed into project-only memory.
That is a move SlopOS would like.

Helm should steal the spirit:
**a shared spine may need a stricter boundary than a personal one.**

For example,
when an activity spine becomes shared,
Helm may want to:
- clamp which memories or recent items remain visible
- clamp personal quick actions out of the shared surface
- demote certain local overlays to residue rather than pretending they travel
- force fresh receiver-side adoption for strong actions or local bindings

## What this means for Helm

If Helm introduces activity spines,
then they should be governed by these laws:

1. **A spine is scoped, not ambient.**
2. **A spine is not the live lane.**
3. **A spine does not auto-enroll by open/recent/share side effects.**
4. **Sharing a spine may tighten context boundaries rather than widen them.**
5. **Spine memory must remain inspectable about what is in scope and what is out of scope.**
6. **Personal overlays and receiver-local residue should not be silently laundered into shared spine truth.**

## Judgment

SlopOS is still not telling Helm to build a giant project/workspace constitution.

It is telling Helm something more valuable:

**if Helm wants an activity object, make it exact about scope, explicit about widenings, humble about open/recent/share side effects, and honest that a scoped remembered object is still weaker than current live truth.**
