# SlopOS / Schell evaluation — 2026-03-22 — pass LIV

Purpose: re-read the latest SlopOS bundle and ask what it teaches Helm about a real **datacube shape** now that Helm already has saved views,
checkpoint branches,
publication ladders,
trust posture,
and stronger compare/change law.

## Main takeaway

The latest SlopOS bundle keeps pushing one very reusable answer:

**the datacube is not one giant live cube.
It is a discipline of bounded non-authoritative projections,
view-scoped queries,
and explicit materialization into stronger local slots.**

That pressure lands on Helm very cleanly.
Helm should keep building its datacube as:
- saved view objects,
- bounded derivative view decks,
- activity front doors,
- current-live beacons,
- restricted imported arrivals,
- and explicit promote/adopt/materialize steps.

Not as a universal live dashboard.

## What the latest SlopOS bundle keeps teaching

### 1. Bounded deterministic projection beats giant inspection theater

`state-projection-schema-v0.md` remains the clearest core teacher.
A projection is bounded,
deterministic,
and non-authoritative.
It exists to expose just enough post-state for one purpose,
not to become a general debug dump or ambient observation plane.

That is a strong Helm datacube lesson.
A view,
beacon,
strip,
lens,
or compare card should usually be a **small typed projection** over stronger truth,
not a rival object model.

### 2. Queries should stay view-scoped and snapshot-first

`attrfs-posture-v0.md` is even more relevant than many earlier passes.
It says Phase 1 should have no ambient global index or query authority.
Queries execute against an explicit view,
results are handles rather than raw paths,
and saved queries are shell-owned manifests rather than app-owned background daemons.

This is exactly the anti-folklore law Helm needs.
Its datacube should not become a secret global “search everything forever” religion.
It should be built from explicit saved views,
query objects,
and shell-owned saved slices over visible scope.

### 3. Materialization should be explicit per slot

`namecert-projection-boundary-v0.md` is still one of the best deep teachers in the bundle.
Bindings are materialized by explicit `view.attach` / `view.detach` on explicit slots.
Source digests stay visible.
Phase 1 refuses background reconcile loops,
bulk bundle-to-namespace import,
and automatic watch-sync semantics.

That should harden Helm's product instincts.
A saved view or imported front door can be useful immediately,
but **receiver-local activation must still be an explicit shell move**.
That is why imported-surface trust posture and materialization bays belong in Helm's datacube story.

### 4. Generic open should not smuggle durable object creation

`openuri-materialization-boundary-v0.md` keeps pressing the same humility law:
generic open is not portable download,
staged copy,
docref minting,
or durable object import.

Helm should keep learning from that.
A front door,
preview,
view,
or compared surface should not quietly count as adopted local truth,
published state,
or new current live authority.
Promotion should stay named.

### 5. Weak cues and strong materializations should stay separate

Across the bundle,
SlopOS keeps separating:
- bounded evidence,
- explicit target seams,
- explicit admission,
- and current live truth.

For Helm,
that means:
- a drift beacon is weaker than a basis contrast card,
- a saved view is weaker than the live subject,
- a front door is weaker than a current-live beacon,
- and an imported deck is weaker than a locally adopted deck.

That hierarchy is healthy.
It is the difference between a datacube and a lie.

## What Schell pressure still says

Schell is still in design phase,
so Helm should not freeze a giant shell-facing view or compare language around it.
But Schell continues to reinforce a few product truths that matter here:
- reviewed basis matters,
- exact current context matters,
- visible entry and reentry posture matters,
- and saved shells / launch kits / command decks should not impersonate live authority.

That is enough to support activity front doors and restricted arrivals.
It is not a reason to freeze a larger universal workspace constitution yet.

## What Helm should import

### 1. Treat the datacube as explicit saved views over stronger shell truth

Saved view objects now look even more central.
They match SlopOS's bounded view/query/materialization discipline far better than a giant dashboard idea does.

### 2. Keep view decks derivative

A deck can gather several explicit views.
It should still point back to stronger truth and degrade honestly when one member is stale,
missing,
untrusted,
or unavailable.

### 3. Make activity front doors the humane user-facing datacube object

A front door should be able to point toward:
- one preferred saved view,
- one triage lane,
- one compare/change path,
- one current-live beacon relation,
- and one relaunch/restore/fresh-start ladder.

That is much more Helm-shaped than a universal workspace blob.

### 4. Keep imported datacube surfaces restricted until fit is earned

Imported views,
decks,
front doors,
and starters should land in inspect-only / restricted / fit-required posture before adoption.
The shell should name what is blocked and what stronger step would unblock it.

### 5. Keep share / sync / publish explicit

If a view or front door crosses locality tiers,
Helm should rely on publication ladders,
promotion receipts,
and later receiver-side fit/adoption.
It should not promise shared sameness by ambient sync mythology.

## What Helm should avoid

1. **Do not build one universal always-live cube.**
2. **Do not let saved views or front doors impersonate current-live truth.**
3. **Do not turn saved queries into an ambient background index constitution.**
4. **Do not let import or open silently count as materialization/adoption.**
5. **Do not let shared publication imply receiver-local activation.**

## Judgment for Helm

SlopOS is still teaching the right lesson.
The Helm datacube should remain a **bounded-view companion** to shell truth,
not a replacement for it.

That means:
- keep **saved view objects** and **checkpoint branches** as the clearest proof targets,
- keep **imported-surface trust posture** hot,
- make **activity entry kits / front doors** more explicit,
- keep **view decks** derivative,
- and keep every stronger adopt/materialize/share step named and witnessed.
