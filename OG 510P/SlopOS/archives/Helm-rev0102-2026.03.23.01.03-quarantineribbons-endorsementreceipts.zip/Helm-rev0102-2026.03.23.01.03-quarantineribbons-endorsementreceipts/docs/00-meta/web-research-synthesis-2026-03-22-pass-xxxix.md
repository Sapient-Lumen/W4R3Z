# Web research synthesis — 2026-03-22 — pass XXXIX

Purpose: keep collecting brilliant Helm ideas while getting stricter about one older shell lie:
**generic open often smuggles stronger acts that should stay separate.**

This pass focused on one question:

**what should Helm's shell-wide “open / peek / recall / save / publish” ladder look like if we keep the truth-bearing strengths distinct?**

## Main takeaway

The outside world is still validating Helm's two strongest proof bets:

1. **saved view objects**
2. **checkpoint branches**

But this pass adds a sharper supporting claim:

**Helm should make generic open deliberately weak.**

That means ordinary summon/open should stay closer to:

- preview
- reveal
- current-live reentry when it is real
- or handoff into a stronger explicit workflow

It should not quietly become:

- save / pin
- materialize / import
- publish / share
- restore / fork
- or profile/session/account selection

## What the outside world is validating now

### 1. View objects are becoming more real, not less

Notion's current developer docs now go beyond “views exist in the UI.”
Views are exposed as first-class resources, can be created directly, and can also be added as widget views to dashboards.
That is strong pressure toward Helm's saved view object direction.

The useful lesson is not just “views matter.”
It is also that a **view object** is distinct from:

- the underlying truth it looks at
- a transient result slice
- and a dashboard composition that happens to gather several views

Airtable keeps validating the complementary strength ladder.
A view can be shared,
synced,
and inspected for sync activity.
That is a strong precedent for Helm's eventual view publication ladders and receiver-side honesty.

### 2. Trust and restriction are excellent middle states

VS Code's Workspace Trust continues to be one of the clearest proofs that imported or unfamiliar material should often begin in a weaker posture.
Restricted Mode is not a dead end;
it is a humane middle state that limits stronger actions until the operator grants more trust.

That maps very cleanly to Helm's imported-surface trust posture,
and it becomes even more important once saved view objects,
checkpoint branches,
and portable shell luxuries start traveling across devices or people.

### 3. Saved setup, restore, and branch should remain visibly different

VS Code profiles keep validating saveable configuration that can open a new window under a chosen profile.
VS Code checkpoints and chat sessions keep validating that restore and fork are related but not identical acts.
Warp validates the same separation from another angle:
launch configurations,
session restoration,
and URI launch surfaces are distinct tools rather than one mushy “workspace magic.”

That is exactly the shape Helm wants:

- saved structure is useful
- restoration is useful
- branching is useful
- but these should not be collapsed into one flattering “resume/open” act

### 4. Compact accelerators become much better when scope and confirmation stay explicit

Raycast keeps validating three separate ideas at once:

- quicklinks as light durable launch objects
- snippets as durable reusable text objects
- and team sharing as an explicit stronger scope for those objects

Its deeplink confirmation behavior is especially important.
The product is effectively saying:
**fast launch is good, but hidden activation should still be guarded.**
That is a very useful precedent for Helm's exact action keys,
launch ladders,
and command docks.

### 5. Great shells give you a humane preview layer with nearby actions

Arc Peek,
Apple Quick Look,
and related shell surfaces keep proving that preview is much better when it is:

- fast
- bounded
- close to the source
- and close to a tiny action edge

But this pass sharpens the non-take:
preview should still remain weaker than save,
pin,
publish,
restore,
or adopt.

### 6. Saveable structure is powerful when it stays honest about locality

PowerToys Workspaces validates one-click saved desktop state for launch.
Warp validates saved launch configurations and separate session restoration.
Obsidian validates separate layers for bases/views,
workspace layouts,
and selective sync.

The key lesson is not merely “save more things.”
It is:
**saveable structure should stay explicit about whether it is local residue, portable recipe, or shared/published object.**

### 7. Preserve lineage and publish-as-copy should remain different verbs

Figma remains unusually useful here.
Its move-published-components flow explicitly distinguishes preserving connections from publishing as a copy.
That is one of the best modern precedents for Helm's lineage modes,
fork receipts,
and publication ladders.

## Ideas now worth stealing

### Tier 1 — steal now

1. **A weak generic open**
   - open should usually mean preview,
     reveal,
     current-live reentry,
     or explicit handoff into a stronger ladder
   - not silent materialization or silent publication

2. **A current-live reentry cue**
   - Recall needs one obvious “this is the real current lane” return path
   - that should stay different from “you touched this once” history

3. **A stronger open / save / publish distinction**
   - one thing is inspect/open
   - another is save as a durable view or recipe
   - another is publish/share/promote

4. **Confirmable exact action keys**
   - powerful launchers should stay typed and inspectable
   - dangerous or strong deeplink-style actions should be confirmable rather than ambient

5. **Move-versus-copy on shell luxuries**
   - when a saved view,
     deck,
     recipe,
     or dock band crosses a boundary,
     Helm should be able to say whether lineage was preserved,
     forked,
     or freshly materialized

### Tier 2 — steal soon, but keep the contract modest

1. **device-local overlay classes**
2. **shell-owned recency with source labels instead of app recents folklore**
3. **URI/deeplink-grade exact action keys that still compose with review or hold**
4. **launchable saved structures that remain recipes until stronger local truth is earned**

### Tier 3 — keep warm only

1. universal session magic
2. browser-like history pretending to be durable object truth
3. auto-publication or auto-pin side effects from ordinary open
4. generic “resume” buttons that flatten preview,
   restore,
   rebind,
   and branch

## Judgment for Helm

Helm should still avoid adding pillars.

The higher-leverage move now is to make the shell's strength ladder clearer:

- **saved view objects** and **checkpoint branches** remain the leading proof targets
- **imported-surface trust posture**,
  **preview-promotion ladders**,
  **landing rehearsal**,
  **arrival overlay**,
  and **materialization bay** remain the best humane middle-state support stack
- and now Helm should get much stricter that **generic open is weak while Recall, save, publish, materialize, and branch are stronger separate acts**

That looks like one of the best ways to make Helm feel super awesome without falling back into recent-items folklore,
sync mythology,
or flattering fake continuity.
