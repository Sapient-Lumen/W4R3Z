# Web research synthesis — 2026-03-22 — pass LVIII

Question for this pass:
**what do current tools teach Helm about watch objects, visible evaluated state, muted-versus-disabled honesty, and small query-linked status cards that do not turn into a hidden dashboard daemon?**

## Main takeaway

The strongest outside pattern is now:

**keep the source view/query explicit, keep the evaluation object explicit, keep delivery suppression distinct from evaluation, and keep the visible status surface small but source-witnessed.**

That points Helm toward one more compact support object:
- **watchpoints**

A watchpoint would be smaller than a workflow engine,
stronger than a raw glance card,
and more truthful than using notification history as the only durable evidence that something is being watched.

## What current tools are teaching

### 1. Grafana validates source-linked watch objects rather than free-floating alert folklore

Grafana lets an alert rule be linked to a dashboard panel,
and it can also be created directly from the panel with the panel query pre-filled.
But Grafana explicitly warns that panel queries and alert-rule queries are **not synchronized** after that.

That is a superb Helm lesson.
A watch object should keep an exact source witness,
but it should also admit that the watch law may drift from the source view if one changes and the other does not.
Helm should not hide that desynchronization behind pretty status chrome.

### 2. Grafana and Kibana both validate “mute delivery, keep evaluating” honesty

Grafana says mute timings and silences suppress notifications,
but do not stop alert rules from being evaluated or alert instances from appearing in the UI.
Kibana says snoozing a rule suppresses actions while checks continue to run on a schedule,
whereas disabling a rule stops checks.

Helm should steal this exact law.
A watchpoint needs at least three distinct truths:
- evaluation posture
- current evaluated state
- delivery posture

Muted is not the same thing as healthy.
Disabled is not the same thing as recovered.

### 3. Kibana validates rule health and flapping as first-class state

Kibana exposes rule health (`failed`, `succeeded`, `warning`) and lets rules carry flapping detection settings.
That reinforces a key Helm idea:
a durable watch object should be able to say more than green/red.
It should admit:
- degraded evaluation
- stale/unknown state
- noisy/flapping posture
- and last successful evaluation versus last state transition

### 4. Datadog validates narrow, unambiguous status cards

Datadog's query value widget is valuable because it provides a narrow but unambiguous window into one query and can use conditional formatting to show whether the value is in the expected range.

Helm should steal the narrowness,
not the dashboard sprawl.
A watchpoint card should be tiny,
clear,
and visibly derived from one stronger source lane.

### 5. Sentry validates source-query witness at configuration time

Sentry's metric-alert configuration shows how filters translate into the Discover query displayed in the chart at the top of the configuration page.
That supports the same principle:
if Helm watches something,
it should be easy to inspect **what exact query/view law is being watched**.

### 6. Grafana library panels validate “where is this reused?” visibility

Grafana's library panels can be reused across dashboards,
and Grafana lets you see where a library panel is being used.
That is a strong secondary lesson for Helm:
if one watchpoint or glance card is embedded in Overview,
Operations,
or a digest surface,
the shell should be able to show where it is reused before edits propagate or interpretations diverge.

## What Helm should steal now

### 1. Watchpoints as explicit shell objects
A watchpoint should bind:
- one exact source saved view
- one declared evaluation law
- one current evaluation state
- one delivery posture
- and one inspect/open-source path

### 2. Delivery suppression separate from evaluation
Helm should be able to represent:
- evaluating + notifying
- evaluating + muted
- evaluating + snoozed
- disabled / not evaluating
- degraded / failed evaluation
without flattening those into one generic badge.

### 3. Visible source drift
If the source view changes after the watchpoint was cut,
Helm should surface a drift / needs-refresh posture instead of quietly pretending the watch definition is still current.

### 4. Small status cards backed by stronger truth
Overview and Operations should be able to show a tiny watchpoint card,
but stronger inspection should still route through the exact source view and the watchpoint's evaluation details.

### 5. Usage witnesses for reused derivative surfaces
This should stay a warm support move rather than a pillar,
but the principle is good:
reused watchpoints and glance cards should know where they are embedded.

## What Helm should avoid

1. **Do not let notification history impersonate watch state.**
2. **Do not let muted delivery impersonate recovery or health.**
3. **Do not let a watchpoint silently diverge from its source view.**
4. **Do not let watch cards become a giant dashboard constitution.**
5. **Do not let watchpoints become a hidden workflow engine or provider-owned daemon.**

## Judgment for Helm

The seven pillars still do not need to move.
But the support stack sharpens again.

Helm should now keep warming:
- **watchpoints** as shell-owned evaluated-state objects over exact saved views
- **visible source drift** when a watchpoint and its source view diverge
- **muted-versus-disabled honesty** in Operations and Overview
- **usage witnesses** for reused watch cards and other derivative surfaces

That makes Helm more alive and more honest at the same time.
