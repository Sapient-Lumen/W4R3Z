# Web research synthesis — 2026-03-21 — pass IX

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on one sharper question:
**what do current tools teach about who chooses a switch, substitute, handoff, or reuse path?**

The answer is becoming clearer:
current tools are slowly getting better at making transitions explicit — handoffs,
shared-vs-private state,
launch status,
review gates,
and per-step control —
but they still rarely give one elegant shell-owned witness for who chose the continuity story.

That points Helm toward two outcomes:
- freeze **continuity-choice/authorship truth** narrowly,
- and add **continuity choice witnesses** as a candidate move.

## Cluster 1 — current agent systems increasingly expose handoffs instead of hiding them

### What current systems teach

VS Code is especially revealing here.
Custom agent handoffs are explicitly described as guided sequential workflows with suggested next steps,
relevant context,
and a pre-filled prompt.
The docs also say handoffs are useful because they give developers control for reviewing and approving each step before moving to the next one.

The general agent-session documentation pushes the same lesson.
A session can be handed from one agent type to another,
full context can carry over,
the original session is archived after handoff,
and the resulting file changes can then be reviewed and applied.
That is a much healthier posture than pretending one agent lane simply was the other all along.

### What Helm should steal

Helm should steal:
- explicit handoff surfaces,
- visible archived-vs-active lane distinction,
- review-before-apply posture,
- and strong session/status views.

### What Helm should refuse

- delegated continuity that quietly inherits operator authorship,
- hidden handoffs that flatten local / background / cloud / remote distinctions,
- and substitute paths that only show “success” rather than “who carried this forward.”

## Cluster 2 — the best current systems default to private or isolated context until the operator shares more

### What current systems teach

VS Code's browser agent tools are very strong here.
Pages opened by the agent run in private,
in-memory sessions by default.
The operator must explicitly enable browser tools,
and when they want the agent to use a page from their real browsing session,
they explicitly share that page.
The docs even note that shared pages use the user's existing cookies and login state,
while agent-opened pages remain isolated ephemeral sessions.

### What Helm should steal

Helm should steal:
- private-by-default adjunct context,
- explicit share/open-up verbs,
- revocable share indicators,
- and a refusal to let “same visible page/app/profile” silently imply transferable authority.

### What Helm should refuse

- hidden inheritance of profile/account/browser state,
- continuity surfaces that imply the shell itself chose a privileged session when it only had a hint,
- and AI convenience that silently crosses from proposal to shared live authority.

## Cluster 3 — workspace tools reveal reuse honesty, but not yet chooser honesty

### What current systems teach

PowerToys Workspaces is still a very good warning sign.
It captures layouts,
lets users add per-app CLI arguments,
shows per-app launch status,
lets the user cancel a launch,
and documents that existing-window behavior depends on the app.
The docs also explain that the “Move existing windows” option changes behavior,
that VS Code can be tuned with `--reuse-window`,
and that some single-instance apps will be repositioned by default because new instances cannot be launched.

That is already much better than fake restore glamour.
But the result is still scattered:
launch status is visible,
reuse can be configured,
single-instance limits are acknowledged,
yet there is still not one shell-owned witness saying who chose reuse,
who merely observed it,
and what sort of substitution it was.

### What Helm should steal

Helm should steal:
- explicit per-app launch status,
- cancellation during reconstruction,
- reuse as an opt-in or named behavior,
- and small per-app behavior notes.

### What Helm should refuse

- silent same-activity claims after forced reuse,
- shell-owned continuity cards that flatten operator choice and app-imposed single-instance behavior,
- and “good enough relaunch” stories that erase the chooser.

## Cluster 4 — tiny accelerators remain worth stealing, but dynamic context heightens authorship needs

### What current systems teach

Raycast Quicklinks and Dynamic Placeholders keep proving that users want tiny,
reusable,
dynamic accelerators.
Quicklinks can accept arguments and Quick Search can pass selected text into the first argument.
Dynamic placeholders can pull in clipboard data,
snippets,
arguments,
and the focused browser tab.

That is delightful.
But it also means the expansion path has real authorship questions:
what came from the user now,
what came from stored seed state,
what came from ambient selection,
and what was synthesized or proposed by the shell.

### What Helm should steal

Helm should keep typed seeds alive.
Tiny accelerators are obviously worth having.
But they should gain more explicit preview and source labeling as they become more dynamic and more continuity-bearing.

### What Helm should refuse

- raw macro folklore as the default substrate,
- hidden expansion sources,
- and seed-driven continuity moves that inherit operator authorship without a revealable basis path.

## Cluster 5 — structured shell panels are getting richer, which makes tiny witness panels more plausible

### What current systems teach

PowerToys Command Palette now has explicit list,
detail,
form,
markdown,
and grid page types.
Node-RED keeps showing the value of tiny always-there information/debug sidebars.
GNOME still demonstrates the power of one shell-owned overview where windows,
apps,
search,
and workspaces meet.

Together these suggest that Helm could support one more tiny panel family without turning into widget sprawl,
provided the panel earns its keep by preserving a fragile distinction.

### What Helm should steal

Helm should steal:
- tiny structured witness panels,
- drill-in-from-strip-to-detail,
- and always-nearby inspectability.

### What Helm should refuse

- giant dashboard religion,
- continuity/authorship state buried in a distant operations tool,
- or decorative chips that still hide the real choice path.

## Pass-IX bounded take

The current external idea harvest most strongly supports two Helm moves:
- freeze continuity-choice/authorship truth narrowly,
- and explore continuity choice witnesses as compact shell-owned strips/cards that complement binding witnesses and scope witnesses.
