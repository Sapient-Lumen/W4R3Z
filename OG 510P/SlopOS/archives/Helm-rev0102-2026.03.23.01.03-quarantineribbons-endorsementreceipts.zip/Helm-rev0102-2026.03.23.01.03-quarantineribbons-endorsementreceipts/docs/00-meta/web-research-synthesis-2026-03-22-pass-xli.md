# Web research synthesis — 2026-03-22 — pass XLI

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell object is **not** a new pillar, but a compact **scoped activity spine** that gathers the right saved objects, current-live cues, and memory boundaries for one piece of work.

This pass focused on one question:

**what is the smallest shell-owned activity object that can make views, checkpoints, launch structures, quick actions, and reentry feel coherent without pretending to be the live lane itself?**

## Main takeaway

The outside world is validating a new support move:

**Helm probably wants a shell-owned activity spine.**

Not a giant workspace religion.
Not a hidden project database.
Not a portable blob that flatters itself into live continuity.

A good activity spine would be:
- scoped
- saveable
- inspectable
- shareable by explicit rung
- able to point at current-live work without pretending to contain it
- able to hold a few named shell luxuries without turning them into ambient authority

The strongest shell ingredients now look like:
- saved view objects
- checkpoint branches
- command bands / docks
- launch or layout recipes
- current-live reentry cues
- review tickets
- explicit scope/memory fences

## What the outside world is validating now

### 1. Scoped project memory is a real product move

ChatGPT Projects is now one of the clearest current proofs that long-running work benefits from an explicit scope boundary.
Projects can keep their own memory, and project-only memory limits context to resources within the project instead of reaching outward into the user's broader memory pool.
Shared projects are even forced into project-only memory.

The important steal is not “copy chat projects.”
It is:
**a scoped work object becomes dramatically more trustworthy when its memory boundary is explicit.**

That maps very well onto Helm activity-spine pressure.
A shell-owned activity object should be able to say:
- these are the remembered resources in scope
- these are the linked views/checkpoints/actions
- these are the things deliberately out of scope

### 2. Saveable views belong near activity scope

Linear custom views are a strong validation of the saved-view-object direction.
They can be saved, shared, and favorited.
Linear projects also let teams attach custom issue views directly to a project.

That is useful pressure for Helm.
A saved view object is strong on its own,
but it gets much more practical when a higher-level shell object can say:
- these views belong to this activity
- this one is the default front door
- this one is the triage view
- this one is the compare or backlog view

In other words,
activity spines are a good home for saved views without turning the spine itself into the truth source.

### 3. Spaces, tab groups, and tabs all validate bounded nested working sets

Arc Spaces validates distinct contexts with their own pinned sections and themes.
Chrome saved tab groups validate that a bounded group can live in the bookmarks bar or menu and sync across devices.
Google Docs tabs validate nested tab groups, per-tab links, duplication, and all-tabs versus current-tab export.

These products are not the same thing,
but together they validate several Helm-friendly ideas:
- work is often grouped into a bounded named set
- the bounded set often wants one deep-linkable sub-entry
- nested subcontexts are useful when they stay shallow and explicit
- export/share sometimes needs “current thing” versus “all grouped things” choice

Helm should steal these interaction truths,
not their app-specific ontologies.

### 4. Workspaces and launch structures are useful, but weaker than live continuity

Obsidian Workspaces saves open files/tabs and layout.
Warp launch configurations save windows, tabs, and panes per project.
PowerToys Workspaces captures desktop state and can pin the captured workspace as a shortcut.

This reinforces a key Helm lesson:
**saveable structure is very useful, but it should remain visibly weaker than current live truth.**

That means an activity spine should probably include or point at:
- workspace/layout starters
- launch recipes
- favorite entry views
- possibly a current-live return hook

But the spine itself should still not pretend to *be* the live lane.

### 5. Shared quick actions want an explicit scope too

Raycast for Teams validates that quicklinks, snippets, and extensions become much more valuable when they can be shared deliberately with a team.
Apple Spotlight and PowerToys Command Palette validate that one summon surface can hold files, actions, clipboard/history, and commands without losing type entirely.

The steal-worthy pattern is:
- keep quick actions compact
- keep them typed
- keep their scope explicit
- let an activity object provide a relevant local command band without making every action globally ambient

### 6. Branching remains the cleanest precedent for parallel truth without fake continuity

Figma branching still validates controlled experimentation against a main object.
A branch is an exact replica at creation time, can be shared and reviewed, and supports side-by-side or overlay review before merge.

That matters because an activity spine should probably be able to point at:
- the current live lane
- one or more checkpoints
- one or more branches or review tickets

without collapsing them into one “session” myth.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Scoped activity spines**
   - shell-owned named work objects with explicit memory/scope fences
   - may gather views, checkpoints, quick actions, tickets, and launch/layout starters
   - do not impersonate current live truth

2. **Project-only memory as a shell law, not an AI-only trick**
   - a shared activity should be able to narrow its usable context instead of widening it
   - sharing should often tighten boundaries rather than blur them

3. **Attached views on the activity front door**
   - one activity can have several named views
   - one may be favorited or promoted as the default entry view
   - but each view remains a separate object

4. **Nested shallow subcontexts**
   - docs tabs, tab groups, or sub-spaces validate small nested grouping
   - Helm can steal this as small subtracks or subspines without building infinite hierarchy religion

5. **Current versus all export/share choice**
   - current subview / current tab / current slice versus all grouped members is a great cross-pillar move
   - it helps Exchange and publication ladders stay honest

### Tier 2 — steal soon, but keep the contract modest

1. **Activity-local command bands**
2. **Activity-local current-live beacon**
3. **Pinned subentries with deep links**
4. **Shallow subspine nesting**
5. **One explicit “bring this into this activity” act** rather than ambient capture

### Tier 3 — keep warm only

1. giant portable project blobs
2. ambient shared memory across activities
3. automatic capture of every recent/opened thing into an activity
4. treating an activity spine as the new master ontology for every shell object

## Judgment for Helm

Helm should still avoid adding pillars.

But a new support object now looks worth defining:

**activity spines** — shell-owned scoped work objects that tie together saved view objects, checkpoints, launch/layout starters, quick actions, review tickets, and current-live cues under explicit scope and share boundaries.

The guardrail is just as important as the idea:

**an activity spine is not the live lane, not a giant portable workspace blob, and not a license for ambient memory or ambient authority.**
