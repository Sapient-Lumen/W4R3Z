# Web research synthesis — 2026-03-21 pass XXXIII

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on one narrower question:

**if Helm already has arrival choice sets and slot verdict ledgers, what tiny compare surface should the shell use to make those choices legible, and what is the smallest honest way to accelerate repeated choices without reintroducing hidden winner-picking?**

## 1) Current tools reward tiny compare surfaces more than giant global inspectors

VS Code has become a strong teacher here.
Profiles can be previewed and imported from the Profiles editor,
drag-and-drop profile import opens that editor for preview/import,
and Git worktrees can now be compared directly against the current workspace before migration.
That is not a giant state browser.
It is a compact compare surface tied to one exact landing or migration problem.

Figma is teaching the same lesson from a different angle.
Developers can compare changes in Dev Mode,
including side-by-side history or comparison against a main component,
and library updates can be reviewed before acceptance.
The useful pattern is not “open the whole design system as a dashboard.”
It is “show me the bounded thing that changed,
what basis it relates to,
and what action is available next.”

That makes a Helm **projection card** feel earned.
A projection card would be a tiny shell-owned compare witness for one arriving slot,
one candidate,
or one exact local target.
It would be much lighter than an arrival overlay,
but much stronger than a pretty label.

## 2) Current tools also reward explicit batch acceptance,
## but only when the batch boundaries are honest

The strongest public pressure here came from Figma and VS Code.
Figma library updates let people update an individual asset or choose **Update all**.
VS Code lets users apply a setting to all profiles or apply an extension to all profiles,
while still keeping profile contents inspectable and explicit.
These are not hidden auto-heal systems.
They are bounded repeated choices over a clearly named class.

That suggests Helm may want a **verdict macro**.
A verdict macro would not silently resolve missing exact bindings.
Instead,
it would let an operator say things like:

- accept all exact chrome/layout slots in this landing
- leave all non-exact target bindings pending
- default-fill only admitted low-risk presentation classes
- refuse companion-resource rebinding until explicitly reviewed

The point is not giant rule automation.
The point is to let repeated slotwise choice stay explicit without making the operator click the same obvious decision twenty times.

## 3) Projection cards and verdict macros are complements,
## not substitutes

A projection card answers:
**what is this candidate or slot actually showing me right now?**

A verdict macro answers:
**given already-visible candidates and slot classes,
which repeated verdicts am I intentionally applying across this bounded set?**

This is a healthy separation.
Projection cards stay on the inspect/compare side.
Verdict macros stay on the operator-choice side.
Neither should impersonate adoption,
and neither should become a hidden resolver.

## 4) The best “steal this” move is parameterized shell choice,
## not just more saved views

The outside world still validates saved views,
shared quicklinks,
persistent command surfaces,
and portable profiles.
But the more interesting pattern now is **parameterized shell choice**:
small typed surfaces,
small typed compare,
and bounded repeated acceptance.

That is where Helm can become unusually good.
Instead of making one giant clever landing assistant,
Helm could make landing feel powerful through:

- projection cards
- arrival choice sets
- landing rehearsals
- near-match fences
- slot verdict ledgers
- and verdict macros

## 5) Strongest new warm moves from this pass

- **projection cards** — compact bounded compare witnesses for one slot,
  candidate,
  or target basis
- **verdict macros** — explicit bounded repeated-choice helpers that apply already-legible verdict classes without hidden winner selection

## 6) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep compare weaker than selection,
  and selection weaker than adoption
- add projection cards so arrival choice sets can stay compact without becoming vague
- add verdict macros so repeated slotwise adoption can stay explicit without degenerating into click-torture

## Strongest non-takes from this pass

- do not add a pillar
- do not turn projection cards into a giant universal inspector
- do not let verdict macros choose winners among near matches
- do not let batch acceptance cross strong trust/binding classes by default
- do not let macros hide which exact slots were affected
