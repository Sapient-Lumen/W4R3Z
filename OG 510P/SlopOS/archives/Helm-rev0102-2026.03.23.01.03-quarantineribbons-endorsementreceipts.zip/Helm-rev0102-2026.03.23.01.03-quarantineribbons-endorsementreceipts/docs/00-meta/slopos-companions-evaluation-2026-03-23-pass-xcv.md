# SlopOS + companions evaluation — pass XCV — 2026-03-23

## Headline

This round says Helm should borrow one more **small shell law** from the companion cubes:

**fresh user intent should be a real shell-owned witness,
not a vibe,
not a stale remembered permission,
and not something background machinery can launder into a later stronger act.**

## What SlopOS is teaching now

SlopOS keeps teaching the same discipline from several angles:

- activation is **activation-delivered, not ambiently inherited**
- approval is tied to an **exact mutable basis**
- transient cues are not durable truth
- exact selection and exact mediation matter more than nearby guesses

That combination pushes Helm toward a useful shell rule:
when a stronger act depends on the user meaning **this now**,
that meaning should ride one explicit fresh witness.
It should not be inferred later from:
- old focus,
- a nearby object,
- an old grant,
- helper memory,
- or vague “the user interacted a moment ago” folklore.

## What Schell contributes

Schell keeps reinforcing that stronger transitions should cross a host-owned seam.
That makes a good companion to fresh-intent posture:
- the shell owns the review lane,
- the shell owns the gesture boundary,
- and app content should not be able to impersonate a fresh stronger approval after the moment has passed.

## What Steward contributes

Steward keeps pushing trusted chrome,
current-versus-historical honesty,
and compact witness surfaces.
That is exactly the right style for Helm here.
A fresh-intent witness should be:
- tiny,
- nearby,
- short-lived,
- and visibly weaker once the window has expired.

## What ViewFS contributes

ViewFS keeps the lane cuts honest:
observe is not control,
attach is not operate,
and history is not current power.
For Helm,
that means a remembered selection or historical receipt is not enough to justify a later strong act that really wanted a fresh direct signal from the user.

## What to keep

Keep:
- exact-now mediation
- shell-owned stronger-act seams
- no ambient inheritance
- exact selection rather than nearby inference
- current truth staying visibly different from historical residue

Peel away:
- “the user probably still means it” folklore
- background helpers spending old intent later
- prompts that appear far from the triggering gesture
- fake continuity where delayed automation impersonates direct user choice

## Main judgment

Helm is ready to warm one more compact law:

> some stronger acts should require one shell-owned **intent spark**,
> and a smaller set should require an even stricter **direct-gesture gate**
> that cannot survive queueing,
> relay,
> or delayed execution.

That feels like a real product gain,
not archive decoration.
