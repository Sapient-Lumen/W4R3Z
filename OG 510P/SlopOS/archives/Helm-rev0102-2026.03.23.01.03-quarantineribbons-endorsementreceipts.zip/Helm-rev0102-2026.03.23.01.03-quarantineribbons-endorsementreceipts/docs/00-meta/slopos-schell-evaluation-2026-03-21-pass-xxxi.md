# SlopOS / Schell evaluation — 2026-03-21 pass XXXI

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on one sharper seam:

**if Helm already has truthful arrival,
explicit comparison,
and bounded partial adoption,
what should it learn from SlopOS about stable carried identity and about the receiver-local defaults that were actually used?**

## 1) SlopOS keeps teaching that stable cores matter more than volatile envelopes

The strongest local teacher in this pass was `capability-wallet-schema-v0.md`.
That doc deliberately distinguishes the full wallet descriptor from `wallet_core_digest`.
The core digest is computed from the stable authority-bearing subset,
while volatile fields like issuance metadata,
instance id,
and attached diff evidence stay out of the stable binding key.

That is a very good teacher for Helm.
Portable shell luxuries are starting to accumulate more witness:
landing manifests,
basis stamps,
residue ledgers,
fit cards,
and adoption receipts.
Those are useful,
but they are not all the same kind of thing.
Helm now looks ready for one stable digest over the portable carried core,
so the shell can say “same core,
different envelope or landing” without bluffing that every receipt or local overlay is part of the portable sameness claim.

This makes a Helm **surface core digest** feel increasingly earned.

## 2) SlopOS also keeps teaching that authorization to project is not the same as the live projection that happened

The next strong teacher was the pair of `namecert-projection-boundary-v0.md` and `namecert-selection-boundary-v0.md`.
Those docs keep evaluation separate from materialization,
keep selection explicit,
and require the exact chosen candidate to be retained with source-digest provenance.
They refuse bulk import,
hidden winner rules,
and ambient “the resolver probably meant this one” comfort.

That matters for Helm's inherit masks too.
An inherit mask is permission.
It says a bounded class **may** use receiver defaults.
It does not by itself say that a default was actually used,
which default source won,
or whether that class stayed local,
pending,
or refused.

Helm therefore seems ready for one tiny receiver-side witness that says:

- this class was filled from receiver default X
- this class remained local residue
- this class still required explicit rebind
- this class was not allowed to inherit at all

This makes a Helm **default-fill receipt** feel increasingly earned.

## 3) SlopOS keeps refusing ambient follow-the-head behavior

`approval-basis-posture-v0.md` and `lease-descriptor-state-boundary-v0.md` keep repeating the same discipline from a different angle:
receipts,
descriptors,
and reviewed basis are not live-oracle surfaces.
You do not get to treat an old reviewed thing as “whatever the head is now,” and you do not get to treat a descriptor as current live state.

That matters here too.
A surface core digest should not become a magical equivalence oracle for current landed state,
and a default-fill receipt should not imply that two receivers are now the same just because they both landed the same packet.
The shell still has to distinguish:

- same carried core
- different receiver defaults
- different local overlays
- different current live binding

## 4) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- portable cores,
  local overlays,
  landing manifests,
  arrival overlays,
  and adoption slices still look right
- add **surface core digests** so portable structure has one stable identity independent of volatile landing envelope
- add **default-fill receipts** so receiver-default use stays explicit rather than ambient

## 5) What still does not seem worth taking

- not a universal sync constitution
- not a live-state oracle built from portable digests
- not automatic inheritance that disappears into “close enough” comfort
- not a hidden ranking system for receiver defaults
- not new pillars

## 6) Current judgment

The most important lesson from this pass is:

**Helm gets smarter by separating stable carried core from volatile landing witness,
and by distinguishing permission to inherit from the actual receiver-default fills that occurred.**

That feels strong enough for new candidate contracts,
and still not strong enough for a new pillar or a new freeze.
