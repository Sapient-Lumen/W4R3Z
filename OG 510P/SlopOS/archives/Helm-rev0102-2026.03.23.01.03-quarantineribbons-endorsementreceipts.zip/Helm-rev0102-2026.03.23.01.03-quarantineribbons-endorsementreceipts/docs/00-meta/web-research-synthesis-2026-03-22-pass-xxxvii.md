# Web research synthesis — 2026-03-22 — pass XXXVII

Purpose: keep collecting brilliant Helm ideas while getting even stricter about which moves deserve contract pressure now, and which should remain inspirations rather than commitments.

This pass focused on one practical question:

**what supporting moves make saved view objects and checkpoint branches actually excellent, rather than merely well-named?**

## Main takeaway

The answer is increasingly clear:

Helm's two strongest proof bets are still:

1. **saved view objects**
2. **checkpoint branches**

But the outside world now makes two additional supporting contracts look especially important:

1. **imported-surface trust posture**
2. **preview-promotion ladder**

These should not become new pillars.
They should become reusable shell laws that sharpen several pillars at once.

## What the outside world is validating now

### 1. Notion and Airtable both validate views as real objects, not throwaway filters

Notion's current docs now make views explicit first-class API resources with per-view filters, sorts, quick filters, and layout-specific configuration, and they also support dashboard views that compose widget views on a grid.
That is powerful evidence that Helm should continue treating a saved view as a real shell object rather than a transient query preset.

Airtable continues to validate the same deeper law from another angle:
one view can remain local,
be shared,
be sync-enabled,
or become part of a more governed verified-data path,
without pretending those strengths are the same move.
That is exactly the sort of publication-strength discipline Helm wants for views, decks, and other shell luxuries.

### 2. VS Code is now unusually strong evidence for explicit trust posture plus checkpoint / fork discipline

VS Code's current docs make profiles a real scope surface,
Workspace Trust / Restricted Mode a real weakened execution posture,
and chat/workspace checkpoints a real restore surface.
The February 2026 release notes also make “fork from a checkpoint” explicit.

That matters because Helm needs exactly this grammar:

- imported or uncertain things can begin weaker than local truth
- checkpoint restore is not the same move as branch creation
- and branch creation can inherit basis without pretending continuity was preserved

### 3. Raycast and PowerToys validate compact shell accelerators with explicit locality and share strength

Raycast continues to separate local/personal synced material from organization-shared quicklinks and snippets.
That is a strong sign that Helm should distinguish personal accelerators,
shared accelerators,
and published accelerators instead of treating every pinned command as one generic object.

PowerToys adds complementary pressure in two directions:
its Command Palette Dock shows that persistent compact command bands can be useful without replacing the main shell,
and its Workspaces utility shows that saved desktop setups are valuable precisely because they are openly launch recipes rather than fake live continuity.

### 4. Warp, Obsidian, Chrome, and Apple keep validating “saveable structure that does not overclaim”

Warp now explicitly separates launch configurations,
session navigation,
and session restoration.
That is a clean example of how saved structure,
live navigation,
and restoration should not blur together.

Obsidian is valuable for Helm because it preserves a sharp line between local files,
multiple bases/views over those files,
saved workspaces,
and selectively synced configuration.
That combination suggests Helm should be comfortable with saveable shell structure that remains clearly weaker than live truth.

Chrome saved tab groups reinforce the same lesson in a lighter-weight form:
activity groupings can be saved,
pinned,
and carried across devices,
without those groups becoming a full continuity or live-session claim.

Apple's Quick Look and Spotlight continue to validate the small but crucial grammar of Helm preview:
a lightweight inspect surface can still expose meaningful actions and then promote into a stronger open path without forcing the user to leave the keyboard.

### 5. Arc and Figma validate promotable preview and honest branching

Arc's Peek continues to be one of the clearest validations of preview-that-can-promote.
Preview is not dead-end ornament;
it can become split view,
a full tab,
or be dismissed with almost no ceremony.

Figma contributes two more laws worth stealing.
First, branching is treated as a controlled environment for change rather than hidden temporary state.
Second, Figma can move published components between files without breaking instance links,
which is a very strong proof that a system can preserve lineage in some moves while still keeping publish/move/copy distinctions honest.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Imported-surface trust posture**
   - imported or shared shell objects should often land in restricted posture first
   - stronger powers should require explicit promotion or adoption
   - this supports Omnibox, Object Browser, Exchange, Recall, and Desktop Flow at once

2. **Preview-promotion ladders**
   - preview should be a genuine shell-wide move with bounded actions and clear promotion into open, pin, split, branch-from-here, or adopt
   - this supports Omnibox, Object Browser, Recall, Exchange, and Operations Center at once

### Tier 2 — steal soon, but keep the contract smaller than the mythology

1. **Personal/shared/published accelerator bands**
2. **view decks that stay visibly derivative**
3. **stable compare tickets for long review flows**
4. **saved launch/session/layout recipes with residue shown rather than hidden**

### Tier 3 — keep warm only

1. giant sync constitutions
2. giant dashboard constitutions
3. universal workspace portability promises
4. broad “everything is a branch” mythology

## Judgment for Helm

Helm should still avoid adding pillars.

The better move is:

- keep the seven pillars stable
- keep saved view objects and checkpoint branches as the two main proof targets
- and give them stronger shell support through two cross-cutting contracts:
  - **imported-surface trust posture**
  - **preview-promotion ladder**

That is the highest-leverage way to make Helm feel magical without lying about activity,
trust,
continuity,
or publication.
