# SlopOS + Schell evaluation — 2026-03-23 — pass LXVIII

Purpose: re-read the uploaded SlopOS and Schell bundles with a tighter question:
what should Helm learn about **delegated/background side work** now that action warrants, drift gates, effect receipts, and slot verdict ledgers are already warm?

## 1. SlopOS is extremely strict that request identity is not live-state truth

The most important SlopOS reading in this pass is `background-request-state-posture-v0.md`.
It draws exactly the line Helm still needs:
a request key or prior request artifact is not the same thing as current portal-owned live grant state.

That is a strong warning for Helm.
If a helper lane exists,
or a background candidate lane exists,
that fact alone must not mean:
- the work is already live,
- the authority is already active,
- or the result already counts as the authoritative lane.

A side lane should therefore stay explicitly weaker than current-live truth.

## 2. SlopOS keeps preview separate from open and open separate from trust

`openuri-preview-metadata-boundary-v0.md` and `quarantined-result-preview-boundary-v0.md` keep teaching the same discipline:
preview is not open,
selection is not open,
and ambient result rendering must not quietly become a richer capability seam.

That maps cleanly onto Helm's missing product move.
A shadow lane or adoption harbor can absolutely preview candidate work,
but preview must not quietly equal adoption.
The shell should be able to say:
- this is candidate work,
- this is how it differs,
- and this is the stronger adoption step if you want it.

## 3. SlopOS remains unusually strict about exact mutable basis

`approval-basis-posture-v0.md` still reads like the right constitutional law here.
Approval binds one exact action on one exact mutable basis.
It does not silently follow a newer head.

That matters for side lanes because a delegated or repair lane is most dangerous when it looks adoption-ready after the live task has drifted.
Helm should therefore not let a lane's earlier readiness survive silently when the live basis moved.
A shadow lane should surface drift.
An adoption harbor should downgrade or hold.

## 4. SlopOS also keeps background presence explicit and bounded

`background-lease-posture-v0.md` and related request-state docs keep repeating a product truth Helm should steal:
background presence is real,
but it stays bounded,
explicit,
killable,
and non-ambient.

That is exactly the right posture for delegated helper work too.
Helm does not need invisible side mutation.
It needs visible bounded side work.

## 5. Schell keeps reinforcing that side work is not the main lane

Schell's shell-facing lessons continue to reinforce footing,
restore-vs-live honesty,
and explicit chooser/proposer posture.
That makes the missing pair feel even clearer:
- a **shadow work lane** for candidate side work,
- and an **adoption harbor** for the stronger inspect/apply moment.

Those are much better product answers than:
- silent background mutation,
- giant agent courts,
- or helper folklore that flatters every suggestion into current truth.

## 6. Best first proof slice now looks concrete

A good first Helm proof slice probably is:
- one delegated repair lane tied to one exact live subject,
- one adoption-ready lane item with preview/diff,
- one lane that downgrades because live basis drifted,
- one rejected lane that leaves the live lane untouched,
- and one visible historical record showing that candidate work existed but never became authoritative.

That would prove a lot without broadening Helm into a giant branch manager,
giant incident suite,
or giant agent platform.

## Judgment

The next compact support proof worth reheating is **shadow work lanes + adoption harbors**.
SlopOS and Schell keep saying the same thing in different seam families:

- **candidate/request/history truth is useful**
- **but it must not silently become current-live authority**

Helm now has a good chance to turn that law into a small shell-owned delegated-work grammar.
