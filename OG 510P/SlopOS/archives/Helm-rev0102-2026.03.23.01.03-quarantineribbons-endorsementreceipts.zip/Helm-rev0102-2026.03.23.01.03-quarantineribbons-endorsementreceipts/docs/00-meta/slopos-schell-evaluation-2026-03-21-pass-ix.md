# SlopOS + Schell evaluation — 2026-03-21 — pass IX

Purpose: keep using SlopOS and Schell as design teachers while Helm decides what deserves a freeze, what deserves a specimen, and what should stay pressure only.

This pass focuses on the next trap after request-vs-live truth,
entry-artifact truth,
binding witnesses,
and activity scope truth:
**even an honest continuity surface can still cheat if it hides who chose the substitute.**

That now looks strong enough to justify one narrow new Helm freeze:
- **continuity substitutions require explicit choice/authorship witness**,
- and one new candidate move:
- **continuity choice witnesses**.

DelayBasin matters most here because it names the missing shape directly:
initiator,
proposer,
chooser,
executor,
autonomy posture,
and fail-closed repair.

## What SlopOS pressures most strongly now

### 1. Policy-owned choice keeps refusing requester folklore

SlopOS keeps drawing sharp lines around who actually gets to choose a concrete target.
The OpenURI handler-selection seam,
session-selection seam,
disposable target-selection seam,
and launch-completion humility all point in the same direction:
a request may ask for a posture,
but that is not the same thing as portable authority to say what concrete browser/profile/handler/session or target will count.

For Helm that means continuity repair cannot stop at saying:
- “a repaired join happened”,
or
- “scope widened”.

Helm also needs a way to say:
- who proposed that substitute,
- who actually chose it,
- whether the shell merely surfaced it,
- whether policy forced it,
- or whether an external single-instance / reuse behavior collapsed the choice.

### 2. Request-state humility generalizes into continuity-choice humility

SlopOS repeatedly refuses the lie that an admitted request or stable request key proves current mutable state.
That same discipline now pressures Helm at the continuity layer.
A saved entry artifact,
a remembered profile,
a recent receipt,
or a nearby existing window may be part of the evidence path,
but those surfaces still do not tell us who chose the live substitute.

### 3. Exact reveal keeps teaching anti-laundering instinct

SlopOS's exact reveal posture remains a strong teacher.
If the system cannot show the exact thing honestly,
it should fail closed rather than silently presenting something nearby.

For Helm that implies a more specific rule:
if the shell cannot preserve the original continuity target exactly,
it should not launder a substitute behind a flat same-activity or repaired badge.
The substitute may still be useful,
but its chooser/authorship posture matters.

### 4. The SlopOS datacube now pressures an authorship layer above binding and scope

The deeper datacube lesson is now:
- binding witnesses explain **how** a join happened,
- scope witnesses explain **which axes counted**,
- and a continuity choice witness would explain **who chose the substitute or switch**.

That feels like the next honest refinement rather than feature sprawl.

## What Schell adds to the picture

### 1. Schell already has the right local instincts

Schell keeps pressing:
- authorship badges,
- basis packets,
- reviewed action truth,
- restore honesty,
- launch-kit honesty,
- failure packets and repair cards,
- execution grounds,
- and exact handoff bundles.

Those are already basically saying:
**do not let collaborative or multi-step work blur into one flattering revision story.**

That pressure now transfers neatly into Helm continuity surfaces.

### 2. Launch kits and cockpits increasingly need “who chose this path?”

Schell's launch kits,
quick summon,
reentry cues,
and cockpit direction all get better if they can distinguish:
- exact return,
- operator-switched continuation,
- shell-proposed substitute awaiting review,
- policy-forced fallback,
- and external reuse behavior that the shell only observed.

Without that,
Helm could still look honest while quietly laundering authorship.

### 3. Preflight honesty naturally becomes continuity-choice honesty

Schell's preflight work already teaches that proposal and execution are different truths.
The next generalization is:
a proposed substitute and a chosen substitute are also different truths.
That is a small but very important refinement for an AI-rich shell.

## What DelayBasin usefully pressures here

DelayBasin's authorship-witness / autonomy-posture / maker-checker-trace family is the clearest teacher in this pass.
It suggests five healthy moves for Helm:
- say who initiated the activity or request,
- say what surface proposed the substitute,
- say who actually chose the substitute or axis switch,
- say who executed it,
- and fail closed when those lanes collapse or become unknown.

That is unusually good pressure for Helm because the product is heading toward:
- richer activity entry kits,
- richer cockpits,
- stronger Recall,
- richer shell-owned accelerators,
- and eventually more agent-shaped help.

The archive needs this law before those luxuries get more powerful.

## What now looks worth doing in Helm

### Worth freezing now

- **continuity substitutions require explicit choice/authorship witness**

Why now:
- Helm now has enough continuity luxuries that hidden chooser laundering would spread quickly,
- SlopOS keeps insisting that concrete choice and current mutable state stay explicit,
- Schell already has the right authorship / review / handoff instincts,
- DelayBasin gives a compact witness shape,
- and the freeze can stay narrow: it still does not require a full general autonomy constitution.

### Worth adding as candidate pressure now

- **continuity choice witnesses**

Why this now looks strong:
- binding witnesses explain the join,
- scope witnesses explain which axes counted,
- continuity choice witnesses can explain who proposed / chose / executed the substitute,
- and the first useful version can stay tiny enough to ride on entry kits,
cockpit cards,
binding witnesses,
scope witnesses,
and Recall cues.

A first continuity choice witness should likely name:
- the continuity subject,
- the proposed substitute or switch,
- the proposer,
- the chooser,
- the executor,
- the autonomy posture,
- and the honest action ladder that remains.

## What Helm should explicitly not take

- a giant autonomy constitution before one continuity-choice witness exists
- a belief that scope and binding witnesses already explain enough by themselves
- silent laundering where “the shell found something nearby” magically counts as “the operator chose this”
- agent prestige that lets generated or delegated moves inherit operator authorship by fluency alone

## Current bounded take

A useful new Helm rule is:

**when Helm repairs, widens, switches, reuses, or delegates continuity, it should not hide who proposed, chose, or executed that move.**

And a useful new candidate move is:

**continuity choice witnesses as small shell-owned strips or cards that say who proposed the substitute, who chose it, who executed it, whether the move was exact / operator-switched / shell-proposed / policy-forced / externally-forced / unknown, and what honest action ladder remains.**
