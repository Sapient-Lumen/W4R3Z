# Web research synthesis — 2026-03-22 pass XXII

Purpose: continue harvesting brilliant ideas for Helm while staying disciplined about what should remain warm.

This pass focused on three questions:

- what current tools teach about **derived surfaces that stay visibly derived**,
- what they teach about **promotion from personal/local to portable or shared surfaces**,
- and what they teach about **compact command and compare surfaces that stay honest about strength**.

## 1) Notion, Airtable, and Obsidian all validate saved views — but only when derivation stays legible

Notion's current docs are unusually useful because views are first-class resources and templates are presented as blueprints rather than as the data itself.
Airtable keeps distinguishing views,
view sections,
share links,
form views,
and published views.
Obsidian makes a similarly healthy split between Bases and Workspaces:
Bases are stored view definitions over underlying Markdown/properties,
while workspace JSON tracks mutable local layout state that can be worth `.gitignore`-ing.

The stealable law is not "copy their data model."
It is:

**derived surfaces need a tiny visible derivation story.**

That is why Helm now looks ready for **derivation strips**.
A derivation strip would let a deck,
lens,
recipe materialization,
or drift beacon say:

- what exact subject or basis it comes from,
- whether it came from a recipe,
- what locality tier it lives in,
- and whether it is still just a projection.

## 2) Airtable, Raycast, and VS Code all validate explicit promotion instead of ambient sync folklore

Airtable's current view docs are especially helpful because sharing and publication live behind explicit "Share and sync" flows,
with link settings,
permissions,
and even publish-to-data-library steps.
Raycast's current Cloud Sync docs are equally instructive from the other side:
Quicklinks,
hotkeys,
snippets,
and notes can sync,
but Clipboard History,
credentials,
and some settings do not.
VS Code keeps making strong locality splits too:
user settings are global/personal,
workspace settings are project-local,
and Workspace Trust keeps execution-sensitive state behind explicit approval.

That strongly suggests Helm should stop hand-waving about portability and sharing.
It should likely grow **publication ladders** as the UX move that sits on top of locality tiers.
The ladder is not a giant collaboration constitution.
It is a compact explicit answer to:

- keep local,
- keep activity-local,
- export/portable,
- share with team,
- publish with restricted permissions,
- or refuse because this surface should never travel.

## 3) VS Code and Figma both validate compare/branch/recover surfaces that do not replace source truth

VS Code's current checkpoint docs are very strong here.
A request can be edited,
a checkpoint can be restored,
file deltas can be inspected,
and a conversation can be forked from a checkpoint.
Figma Dev Mode similarly lets developers compare changes and see when a component or frame was last edited.

The shared law is not "everything needs a timeline."
It is:

**people love branch/compare/recover powers when the basis stays explicit.**

That keeps strengthening drift beacons,
materialization bays,
and adoption harbors.
But it also increases the value of a derivation strip,
because a strip can show what exact basis the mini-surface is comparing against.

## 4) PowerToys, Spotlight, Quick Look, Arc, and Warp keep validating tiny honest shell luxuries

PowerToys now supports a persistent Dock at the screen edge and even extension-level Dock support.
Spotlight keeps widening action-first behavior and can narrow to actions,
assign quick keys,
and expose exact path/location cues.
Quick Look still proves the long-term value of rich preview without full open.
Arc's Peek and Split View keep showing how a transient inspection surface can become a more durable adjacent view.
Warp's Launch Configurations and Session Navigation keep validating explicit saved session shapes and exact re-entry.

The strongest steal is not any one UI.
It is the pattern:

- tiny command surfaces can stay useful if they remain shell-owned,
- previews feel magical when they stay clearly weaker than open/adopt/publish,
- and saved arrangements become much safer when their derivation and promotion story is always legible.

## 5) Strongest new warm moves from this pass

- **derivation strips** — tiny shell-owned witness strips/headers for derived surfaces such as lenses,
decks,
recipes,
beacons,
and preview-adjacent cards
- **publication ladders** — compact shell-owned ladders for promoting a surface across locality tiers without ambient sync or fake shared liveness

These feel more mature than another pillar because they strengthen many existing warm moves at once.

## Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- treat saved views,
  compare surfaces,
  and quick accelerators as **derived shell luxuries that should wear provenance openly**
- treat sharing/export/publication as an **explicit promotion ladder** rather than as background magic
- keep the command/preview magic,
  but make the source,
  basis,
  and tier story legible

## Strongest non-takes from this pass

- do not build a giant universal workspace or sync constitution
- do not let a published surface imply active local binding or current live authority
- do not let derivation badges become decorative provenance cosplay
- do not let Quick Look / Peek style surfaces smuggle stronger workflows by convenience
- do not add pillars
