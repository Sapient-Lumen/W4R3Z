# Web research synthesis — 2026-03-22 — pass LXXV

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move is to sharpen **least-reach / exact-cohort posture** across asks, reveals, routes, and stronger actions.

This pass focused on one question:

**after authority windows, reveal windows, and audience ladders, what tiny shell-owned move still keeps Helm from quietly widening from one selected thing into one whole account, workspace, library, or provider?**

## Main takeaway

The outside world is validating a pressure that is now strong enough to name explicitly:

**Helm likely wants cohort windows plus minimization ladders.**

Not a giant data-governance suite.
Not a giant ACL editor.
Not another permission-center religion.

A good Helm answer would likely be:

- **cohort windows** — shell-owned bounded objects that say which exact selected subset is in play for one ask, reveal, export, route, or strong act
- **minimization ladders** — humane chooser rails that start from one item or one selected cohort and only widen to a bigger family when the operator clearly means to

## What the outside world is validating now

### 1. Good systems increasingly start from picked subsets

Android's photo picker and Selected Photos Access let apps work over selected photos/videos instead of the whole media library.
Chrome's `activeTab` gives temporary access only to the current tab after an explicit user gesture.
The File System Access API starts from a chooser that returns exact file or directory handles.
Google Drive Picker likewise starts from files the user explicitly selects.

That is a very Helm-shaped lesson:
**exact selected cohorts are a product surface, not implementation trivia.**

### 2. Broader access is increasingly something you earn later

Google's OAuth guidance says to request only the smallest, most limited scopes possible and to use incremental authorization when functionality actually needs it.
Slack now teaches admins to inspect what an app can view, post, or perform, and notes that newer apps request a narrower set of scopes.

That matters because Helm should likely stop treating wider reach as the natural default.
A reveal, action, or export should usually begin from:
- this item
- these selected items
- this saved view's exact result slice
- this activity-local cohort

Only later should it widen toward:
- whole project/activity family
- whole provider/account/workspace family

### 3. Persistence does not erase exactness

The File System Access explainer explicitly allows persisted handles, but still centers the chooser and leaves room for re-prompting or revocation later.
That is a strong signal for Helm that persistence should not erase the original exact cohort.
A carried or reopened handle should still be able to say:
- what exact cohort was admitted,
- whether that admission is still live,
- and what broader family it does **not** imply.

### 4. Good minimization posture is legible to ordinary users

The best examples are not written like compliance checklists.
They are ordinary humane affordances:
- current tab
- selected photos
- chosen file
- this feature needs one more scope
- this app can view / post / perform these classes of acts

Helm should steal that clarity.
Least reach should feel like a normal shell affordance, not a privacy-ops sidecar.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Exact cohort chips near stronger acts**
   - this file
   - these 3 objects
   - 7 rows from this view
   - current selected watchpoints
   - summary over selected results only

2. **Minimization ladders before broad reveal or broad authority**
   - exact item
   - current selected cohort
   - saved cohort / view result
   - activity-local family
   - wider provider / account / workspace family only when justified

3. **Broaden-for-this-act posture**
   - widen once for this ask
   - widen once for this export
   - widen once for this reveal
   - then fall back to the narrower remembered cohort

4. **Nearby witness for why widening happened**
   - feature required it
   - operator explicitly broadened
   - provider could not honor narrower subset
   - result slice drifted and needed reselection

### Tier 2 — steal soon, but keep modest

1. save exact cohorts as weak reusable starters
2. attach saved cohorts to activity spines, briefs, and patrol routes
3. let AI/helper actions declare the cohort before producing a plan or warrant
4. keep selected-field / selected-row / selected-view slices visibly weaker than whole-family truth

### Tier 3 — keep warm only

1. defaulting every action to whole-provider scope
2. auto-widening because a retry failed
3. flattening selected cohort and current audience into the same concept
4. treating loadouts as identical to cohorts

## Judgment for Helm

Helm should still avoid adding pillars.

But one support move now looks ready to define:

- **cohort windows** — shell-owned exact admitted-subject-set objects for asks, reveals, exports, routes, and stronger acts

And one adjacent move now looks worth defining too:

- **minimization ladders** — humane chooser rails that keep exact item, selected cohort, saved cohort, activity cohort, and wider family visibly different strengths

The main law is simple:

**start from the smallest honest cohort, and widen only by explicit stronger choice.**
