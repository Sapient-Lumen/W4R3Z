# Web research synthesis — 2026-03-21 pass XXIII

Purpose: continue harvesting brilliant ideas for Helm while staying disciplined about what should remain warm.

This pass focused on three questions:

- what current tools teach about **portable shell luxuries that travel as explicit packets rather than fake live state**,
- what they teach about **durable witnesses for publication/share/export moves**,
- and what they teach about **receiver-side materialization, trust, and preview boundaries**.

## 1) VS Code, Raycast, and Airtable all validate explicit portable objects rather than fuzzy continuity

VS Code's Profiles docs are unusually relevant because profiles are not treated as magic ambient state.
They can be exported,
saved,
shared,
and imported again from a gist or local file.
Raycast's current docs are equally useful:
Quicklinks can be shared with an organization,
commands can be invoked by deeplink,
and deeplink execution asks for confirmation before it becomes a habitual fast path.
Airtable keeps similar boundaries in its view share menu:
a view can be linked,
synced to another base,
or published to a data library,
but those are explicit separate moves with different follow-on semantics.

The stealable law is not "copy their product model."
It is:

**use packet-like portable objects instead of pretending that a link or export already is live shared state.**

That is why Helm now looks ready for **handoff packets**.
A handoff packet would let Helm carry a deck recipe,
exact action key,
dock pin,
entry kit,
or other shell luxury across locality tiers without pretending the receiver already has live bindings.

## 2) Airtable sync activity and Obsidian device/config splits both validate publication witnesses

Airtable's current docs are especially strong on the after-story of sharing.
Its view share flow exposes sync activity,
destination bases,
sync creators,
and link settings.
Obsidian's Sync docs reinforce a different but equally healthy lesson:
some sync settings are device specific,
selective sync is explicit,
and profile/config folders can differ by device.
Raycast's Cloud Sync docs add another important restraint:
some objects sync,
but Clipboard History,
credentials,
and some settings do not.

The stealable law is:

**when a shell surface crosses a tier, the shell should leave behind a durable witness of what crossed, to where, under what restrictions, and what still has to happen on the receiving side.**

That is why Helm now looks ready for **promotion receipts**.
A promotion receipt would make export,
share,
sync,
publish,
and revoke stories legible instead of folklore.

## 3) Figma, Notion, Quick Look, Arc, and Obsidian all keep teaching that preview and templates must stay weaker than adoption

Figma Dev Mode does two especially useful things.
It lets developers compare changes against explicit version history,
and it lets components carry resource links such as GitHub,
Jira,
Storybook,
and VS Code links that propagate to component instances.
Notion templates keep a similarly honest distinction:
a template is a starter inside a database,
and the created page is still a new page that can then diverge.
Quick Look,
Arc Peek,
and Obsidian Web viewer keep proving the preview lesson too:
fast nearby inspection is wonderful,
but it should remain preview or lightweight context rather than silently becoming full open,
trusted run,
or durable materialization.

That reinforces Helm's older warm moves — preview rails,
materialization bays,
drift beacons,
view decks,
and derivation strips — while sharpening the new pair:
packets should travel with enough witness material,
and publication should leave a receipt,
but the receiver should still materialize,
adopt,
or trust explicitly.

## 4) Strongest new warm moves from this pass

- **handoff packets** — portable shell-owned packets for deck recipes,
  exact keys,
  dock items,
  entry kits,
  and other shell luxuries that need to travel without pretending to be current live state
- **promotion receipts** — durable shell-owned receipts that record cross-tier publication/share/export moves,
  including scope,
  permission,
  redaction,
  and receiver-side activation expectations

These feel more mature than a new pillar because they strengthen many existing moves at once.

## Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- let portable shell luxuries travel as **inspectable packets** rather than as fake continuity objects
- let cross-tier promotion leave **receipts and activity traces** instead of silent sync mythology
- keep receiver-side adoption,
  materialization,
  and trust explicit

## Strongest non-takes from this pass

- do not build a universal shared workspace constitution
- do not let a link,
  gist,
  deeplink,
  or export artifact imply current live attachment on the receiver side
- do not let publication receipts turn into a giant global audit warehouse
- do not let packet travel bypass trust,
  review,
  or materialization
- do not add pillars
