# Web research synthesis — 2026-03-21 pass XVIII

Purpose: continue harvesting fresh ideas for Helm while resisting premature constitutional freezes.

This pass focused on three questions:

- what current tools validate **exact trail cues**,
- what current tools validate **promotable exact action keys**,
- and what current tools validate **trust/admission ladders** and **preview-first triage**.

## 1) Exact trail cues are getting more valuable, not less

VS Code keeps giving the clearest public evidence here.
Breadcrumbs are no longer just local orientation candy; release notes now also expose **Copy Breadcrumbs Path**, which makes exact location sharable and reusable instead of merely glanceable.
Checkpoints strengthen the same lesson from a second angle: users trust agentic systems more when there is an explicit restorable trail of what changed and when.

That strongly suggests Helm should keep warming toward shell-wide exact trails for:

- objects
- views
- receipts
- routes/providers
- flow fragments
- and perhaps activity entry artifacts

The important steal is not “show breadcrumbs everywhere.”
It is:

**make exact path/trail information promotable, copyable, and useful across surfaces.**

## 2) Quick keys are increasingly a shell power, not just an app trick

Apple's current Spotlight documentation now explicitly frames Spotlight as an action surface with **quick keys**.
Raycast adds the complementary pattern: hotkeys, Quicklinks, dynamic placeholders, and deeplinks that run commands with an explicit confirmation flow.

That combination points to one very promising Helm move:

**promotable exact action keys**.

Helm should likely let operators promote a few exact actions, objects, entry kits, routes, or views into faster hotkey-grade access.
But the current tools also teach the guardrails:

- the key should still point to an exact typed subject or action,
- the shell should still show what kind of thing it is,
- and a stronger action should still preserve review/apply law.

The right steal is speed without hidden widening.

## 3) Preview-first triage is maturing into a real product pattern

Arc's Peek and Little Arc are very strong signals.
Peek previews links from pinned/favorited tabs without leaving the current pinned context, and Little Arc opens quick lookup windows from other apps so users can triage whether to keep or discard them.
Apple's Quick Look and Finder Preview pane still teach the same lesson from another ecosystem: preview gets stronger when it includes a few bounded actions nearby while still clearly not being full open-first culture.

That keeps reinforcing Helm's preview rails, launch ladders, and trust-ladder warmth.

The stealable law is:

**preview becomes lovable when it can help you decide what to do next without pretending you already did it.**

## 4) Trust ladders now have stronger public validation

VS Code's Workspace Trust and newer agent/session docs keep validating the same posture:

- untrusted things can still be opened and explored,
- stronger execution or mutation rights should remain behind an explicit step,
- and multiple session types should remain legible rather than blurring into one blessed lane.

This now makes Helm's trust-ladder warmth feel more important, not less.

The likely value for Helm is not just security branding.
It is better product honesty around:

- imported material,
- provider-local rich actions,
- delegated/background work,
- preview versus stronger open,
- and whether a quick key or dock slot is allowed to do the stronger thing directly.

## 5) Obsidian Bases strengthens Helm's view story

Obsidian Bases is an unexpectedly good teacher for Helm because it shows multiple table/list/cards-style views over the same underlying note/property corpus.
That is a very useful public reminder that many “datacube” wins are really **multiple explicit views over one underlying truth**, not a need to invent a second truth machine.

For Helm this strengthens:

- facet strips,
- live lenses,
- exact trails,
- query-first Object Browser views,
- and the idea that cockpit cards or Recall surfaces should be view-shaped rather than folklore-shaped.

## 6) Sync boundaries are as informative as features

Raycast's sync docs remain one of the cleanest public lessons in restraint.
Quicklinks, snippets, aliases, and hotkeys can sync, but clipboard history does not, and some settings remain local.
Obsidian likewise documents local mutable workspace state and device-local recovery snapshots.

That is a powerful reminder for Helm:

not every acceleration surface should automatically become shared continuity, team truth, or synced state.

This is especially relevant for:

- exact action keys,
- trust-ladder decisions,
- personal docks,
- snippet/seed surfaces,
- and saved local view state.

## Strongest takes from this pass

- add candidate contracts for **exact trails**, **trust ladders**, and **promotable exact action keys**
- keep the seven pillars stable
- keep projection-surface law frozen, but keep these new moves at candidate level
- continue pushing Object Browser / Recall / Operations Center toward explicit shell-owned views over objects rather than dashboard folklore
- continue pushing preview rails and launch ladders with better triage, not blurrier authority

## Strongest non-takes from this pass

- do not freeze trust ladders into a giant constitutional stack yet
- do not freeze exact trails into universal law before one cross-pillar specimen exists
- do not let quick keys become a second macro or ambient shell-string substrate
- do not build a universal datacube dashboard product
- do not let preview triage windows quietly become hidden durable continuity or authority lanes
