# Web research synthesis — 2026-03-22 — pass LXXX

This pass focused on one practical question:

**what durable outside patterns strengthen Helm's pillars now,
without forcing Helm into a giant new constitution?**

## 1. Exact remembered handles are one of the best ideas available anywhere

Several ecosystems converge on the same lesson.

Apple's sandbox guidance and security-scoped bookmark flow are about **persistent access to specific file-system resources** rather than broad file-system reach.
Chrome's File System Access API centers **file and directory handles**,
not guessed paths,
and now supports **persistent permissions**.
Google Drive keeps pressing the same family of ideas through Picker,
`drive.file`,
and newer picker features that can start near the exact file IDs an app is seeking.

Helm should steal the law,
not the host API details:

**remember access as an exact handle whenever possible,
query whether it is still valid,
and make re-request or repair explicit when it is not.**

That is much healthier than pretending:
- a path string is still enough,
- a title match is identity,
- or a nice thumbnail means the shell still has authority.

## 2. Requested-target pickers are better than giant generic choosers

Google's picker work now explicitly supports pre-navigating the picker to specified file IDs.
That is a subtle but important refinement.
It says the app should ask for **this thing if you agree**,
not dump the user into a giant whole-world browser and hope intent survives.

Helm should copy that move widely.
If a route,
repair,
rebind,
or import is probably about one exact subject,
start there.
Offer nearby alternatives only as a visible second step.

## 3. Constrained helper lanes beat permission-prompt fatigue

Anthropic's Claude Code docs and engineering notes now make a persuasive case for **filesystem and network isolation together**.
They also separate allow,
ask,
and deny rules instead of flattening all helper authority into one yes/no switch.

The lesson for Helm is bigger than AI coding.
Any helper lane,
shadow lane,
repair lane,
or delegated lane should be able to say:
- which directories / objects it can reach
- which hosts / domains it can reach
- which verbs are auto-allowed
- which verbs still require approval
- what happens when it hits the boundary

That gives Helm a path to stronger autonomy **inside explicit bounds**,
which is much better than either constant prompt spam or one terrifying all-powerful mode.

## 4. Strong acts deserve named gates,
not just a better confirm dialog

Terraform already taught the value of a real plan object.
This pass found two strong adjacent teachers.

AWS CloudFormation change sets keep create,
inspect,
and execute as explicit separate steps,
including before/after comparison.
GitHub deployments and rules now reinforce that stronger acts may need visible protection gates such as manual approval,
delay,
branch restrictions,
custom app-powered checks,
and required reviewer rules with precise file/branch targeting.

Helm should steal the principle:

**a strong publish / apply / expose act may be correct,
well-formed,
and still not yet admitted.**

That argues for shell-owned **protection gates** as a sibling to saved plans and action warrants.
Gate state should remain distinct from:
- the proposal itself
- the current live object
- the final aftermath receipt

## 5. Repo- or object-scoped installs are a better model than ambient integration reach

GitHub Apps are a useful reminder that integrations can ask for a set of permissions **and** be installed on selected repositories rather than inheriting every repository by default.
That maps cleanly onto Helm's authority windows,
cohort windows,
and exact-handle posture.

Helm should keep learning the same lesson from many domains:
**scope should name both the kind of action and the exact subject family it applies to.**

## Steal now

- **exact remembered handles** over path nostalgia
- **requested-target pickers** over giant generic browse starts
- **constrained helper lanes** with visible file/object + network bounds
- **allow / ask / deny grammar** for helper power
- **named protection gates** over strong publish/apply/expose acts
- **object- or repo-scoped installs/grants** over ambient integration reach

## Steal carefully

- persistent permission memory that outlives the user's expectations
- cloud-sandbox metaphors that accidentally become background-agent mythology
- gate stacks so heavy that ordinary shell use feels like CI/CD theater

## Resist

- title/path similarity masquerading as remembered authority
- helper modes that hide their sandbox or permission posture
- “looks ready” UI that hides pending admission gates
- integration installs that quietly inherit whole-workspace reach

## Synthesis for Helm

The next strong Helm move is not another pillar.
It is a tighter cross-pillar grammar:

- **remember exactly**
- **query current access**
- **repair or re-request honestly**
- **run helpers inside visible bounds**
- **treat strong acts as plan → gates → execution → aftermath**

That grammar would make Helm feel unusually trustworthy,
not merely unusually advanced.
