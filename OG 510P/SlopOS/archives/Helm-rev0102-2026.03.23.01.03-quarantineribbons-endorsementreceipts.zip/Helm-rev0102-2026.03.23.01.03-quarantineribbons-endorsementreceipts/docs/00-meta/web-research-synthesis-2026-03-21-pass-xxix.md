# Web research synthesis — 2026-03-21 pass XXIX

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on a narrower arrival question:

**if Helm already has landing manifests, anchor maps, residue ledgers, and rebind ladders, how should a receiver inspect a landing before adoption, and how should Helm treat merely similar local candidates when the exact target did not arrive?**

## 1) Current tools keep rewarding preview-before-adopt, not straight-through import

VS Code Profiles now make this unusually explicit.
When you create a profile, you can browse its contents section by section.
You can preview the would-be profile in a **new VS Code window** before creating it.
Imported profiles also open into the creation form rather than silently becoming live.
Drag-and-drop profile import now opens the Profiles editor and lets you **preview and import** the profile.

Figma branching reinforces the same arrival posture from a different angle.
Reviewers can preview branch changes against the main file side-by-side or as an overlay,
then approve,
suggest changes,
or merge only after review.
The review modal keeps review and merge coupled without pretending the branch is already the main file.

VS Code background agents add a third parallel signal.
Copilot CLI worktree isolation runs changes in a separate worktree,
then asks the operator to review and merge or apply those isolated changes back into the main workspace.

That combination strongly supports a Helm **landing rehearsal**.
A portable core,
entry kit,
exact action key,
deck recipe,
or dock band should often be able to land in a weaker receiver-local rehearsal mode before adoption.

## 2) The best systems do not treat near matches as exact truth

SlopOS already teaches this locally through show-item exactness and approval-basis truth:
exact reveal must fail closed rather than degrade into “something nearby,”
and approval must not follow a mutable target just because it looks close enough.

The outside tools keep validating the same shape.
Figma branch review treats the branch as a distinct review subject and does not offer partial silent acceptance of “roughly most of it.”
VS Code worktree isolation keeps isolated changes as isolated changes until explicit apply.
Profiles preview in a new window instead of quietly replacing the current environment.
Warp launch configurations and URI launches are also strongest when the launch target is explicit.

That is a strong argument for a Helm **near-match fence**.
If the exact repo,
profile,
provider,
subject root,
or dock command target is missing,
Helm may show candidates,
ranked similarities,
or suggested substitutes.
But it should not silently bind one of those candidates and then report ordinary exact success.

## 3) A receiver-local rehearsal is different from a strong action rehearsal

Helm already has action rehearsal pressure.
This pass suggests a distinct but compatible family:

- **action rehearsal** previews a strong local action before commit
- **landing rehearsal** previews what an arriving portable/saved/derived surface would look like on this receiver before adoption

That difference matters.
A landing rehearsal is more like:

- a temporary window/profile/view arrangement
- a non-adopted dock band or deck specimen
- a split-view compare of imported-vs-current structure
- or a receiver-local specimen materialized under explicit weaker claims

The point is not giant simulation.
The point is:
**try here before calling it here.**

## 4) The receiver should be allowed to inspect near matches without granting them truth

The best version of this move is not a harsh “exact or nothing” religion.
It is a stricter truth discipline:

- exact arrivals may bind exactly
- missing exact arrivals may surface near matches
- near matches may be inspected,
  rehearsed,
  or explicitly adopted
- near matches must not quietly count as exact success

That suggests a good pairing:

- landing rehearsals
- near-match fences
- receiver fit cards
- rebind ladders
- anchor maps
- basis stamps
- residue ledgers

## 5) Strongest new warm moves from this pass

- **landing rehearsals** — shell-owned receiver-local try-before-adopt surfaces for imported,
  saved,
  or derived shell luxuries
- **near-match fences** — shell-owned exactness guards that allow inspection of similar candidates without silently rebinding them as exact truth

## 6) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep travel and landing explicit,
  inspectable,
  and weaker than adoption
- let receivers preview landed structure in a weaker local mode before adoption
- refuse to let similar local targets silently count as exact rebinding

## Strongest non-takes from this pass

- do not add a pillar
- do not turn landing rehearsal into a giant virtualized second desktop before one compact specimen exists
- do not let near-match fences become fuzzy auto-healing with better marketing
- do not flatten rehearsal,
  fit,
  rebind,
  and adoption into one flattering “ready” badge
- do not let receiver-local preview impersonate shared or carried truth
