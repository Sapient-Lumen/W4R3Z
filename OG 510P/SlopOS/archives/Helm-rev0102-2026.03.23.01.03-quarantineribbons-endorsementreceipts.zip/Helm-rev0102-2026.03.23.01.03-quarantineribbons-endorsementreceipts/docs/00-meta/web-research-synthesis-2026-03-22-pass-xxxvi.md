# Web research synthesis — 2026-03-22 — pass XXXVI

Purpose: keep collecting great Helm ideas while getting stricter about which ones sharpen truth versus merely increase shell spectacle.

This pass focused on one practical question:

**which current product moves most strongly justify pulling the trigger on saved view objects and checkpoint branches as explicit Helm moves?**

## Main takeaway

The outside pressure is now strong enough to stop treating two families as vague inspiration only:

1. **saved view objects**
2. **checkpoint branches**

That does **not** mean Helm should freeze a giant datacube constitution around them.
It means Helm now has enough evidence to define small shell-owned contracts that prove these moves in one or two narrow specimens.

The broader pattern is even more helpful:

- first-class views keep becoming legitimate products rather than app-local clutter
- preview keeps becoming a promotable state instead of a dead-end tooltip
- launch/session/layout structures keep becoming saveable recipes rather than fake continuity
- trust/restricted posture keeps becoming an ordinary user-facing mode
- compare/fork/restore keeps becoming a normal everyday move rather than a niche expert escape hatch

## What the outside world is really validating

### 1. Notion is validating saved view objects, composed decks, and cached query tickets

Notion's current data APIs make views real resources with their own filters,
sorts,
and layout configuration,
and dashboard views can arrange multiple widget views on a grid.
Notion also gives a query result a stable query id backed by a cached result set with an expiration window.

The stealable law is not “be a database product.”
The stealable law is:

- a view definition can be a first-class object
- a deck can be a composition of views without becoming the truth-bearing subject itself
- and a frozen-enough query result can support review,
paging,
and handoff better than a constantly shifting list

That strongly supports a Helm distinction between:
- **saved view object**
- **query result slice / ticket**
- **live subject**

### 2. Airtable is validating one surface that can travel by several strengths

Airtable's view-share surface and data-library flow continue to show that one underlying view or dataset can move through multiple explicit strengths:
share,
sync,
publish,
and verified-source reuse.

The stealable law is:

**travel mode should be explicit before the stronger act happens.**

That reinforces Helm's publication ladder work,
but it also sharpens a view-object lesson:
a saved view should be able to stay local,
travel as a recipe,
be shared,
or become a stronger published artifact without any of those modes impersonating live receiver-side activation.

### 3. VS Code is validating restricted posture plus checkpoint / restore / fork as ordinary moves

VS Code now makes three things unusually legible together:
profiles,
Workspace Trust / Restricted Mode,
and checkpoint-based restore / fork in chat and workspace flows.

This combination is one of the clearest available proofs that Helm should normalize:

- imported or not-yet-adopted surfaces beginning in a weaker trust posture
- explicit basis-bearing checkpoints
- restore and fork as separate moves
- and branch creation without pretending the branched path is still the same live lane

### 4. Raycast and PowerToys are validating durable shell accelerators with explicit scope

Raycast keeps separating synced personal accelerators from shared team quicklinks,
while PowerToys keeps validating persistent dock-like command edges and saved workspace launches.

The stealable law is:

- accelerators deserve identity and scope
- shell edges can stay tiny and durable
- launch recipes should say they are recipes,
not current live state
- and pinned command surfaces can remain truthful if they are projections over stronger shell truth

### 5. Warp, Obsidian, Arc, Quick Look, Spotlight, Figma, and Chrome Tab Groups keep converging on the same “promote but do not lie” pattern

Across these tools the same humane grammar keeps appearing:

- preview can promote into a stronger surface
- saved layout/session structure can be reopened later without claiming it is still live
- closed activity groups can be restored without pretending nothing changed
- branch review can compare side-by-side or overlay without flattening lineage differences
- layout/workspace residue can stay local and mutable without contaminating the stronger object story

That is exactly the grammar Helm wants.
The shell opportunity is to make promotion,
restore,
compare,
fork,
and reopen feel powerful **because the shell tells the truth about the move**.

## Great ideas worth stealing now

### Bucket A — truth sharpeners

These are the ideas most worth taking now because they make Helm more honest and more powerful at the same time.

1. **Saved view objects**
   - saveable,
     summonable,
     inspectable,
     pinnable,
     shareable by explicit rung,
     and distinct from their transient result slices

2. **Checkpoint branches**
   - an exact checkpoint can later be restored,
     compared,
     or branched from,
     but the shell should always distinguish live lane versus restored lane versus new branch

3. **Restricted/trust posture on imported or uncertain surfaces**
   - new arrivals should often begin weaker than ordinary local truth

4. **Publication/share ladders on shell luxuries**
   - especially for views,
     decks,
     dock items,
     exact action keys,
     and launch recipes

5. **Stable-enough compare tickets**
   - not everything needs a ticket,
     but long review / paging / compare flows benefit from a short-lived stable slice

### Bucket B — launch and preview sharpeners

These make Helm feel excellent if they remain visibly weaker than truth-bearing objects.

1. **Peek → split / open / pin promotion ladders**
2. **Persistent command docks / bands**
3. **Saveable launch configurations / workspace recipes**
4. **Action-first quick keys**
5. **Session navigation across live and historical-but-not-live structures**

### Bucket C — ideas to keep warm, not freeze yet

1. giant dashboard/deck layout constitutions
2. broad query-ticket law for every result family
3. high-ceremony publication governance before one narrow family proves it
4. universal workspace portability stories that outgrow the specimens

## Judgment for Helm

Two ideas now look mature enough to start proving with real shell contracts:

1. **saved view objects**
2. **checkpoint branches**

The right next move is not to constitutionalize every surrounding rule.
It is to define small shell-owned candidate contracts and make the first specimen do real work across multiple pillars.

That is the path to Helm becoming more magical **without** inheriting the old sins of ambient continuity,
ambient sync,
or dashboard religion.
