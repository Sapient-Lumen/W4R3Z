# SlopOS / Schell evaluation — 2026-03-21 pass XIX

Purpose: continue evaluating what SlopOS's datacube is actually teaching Helm now that projection-surface law is frozen and exact-trail / trust-ladder / exact-key pressure is already warm.

This pass sharpened one reading above all others:

**the datacube lesson is not "one giant cube." It is explicit multi-view discipline plus explicit materialization discipline.**

## 1) CH-SPROJ keeps teaching the right kind of compactness

`state-projection-schema-v0.md` is still one of the clearest SlopOS teachers for Helm.
A state projection is:

- bounded,
- deterministic,
- keyed,
- digest-friendly,
- and explicitly non-authoritative.

That makes it a very good model for Helm's compact shell luxuries.
The shell should keep producing small powerful surfaces by projecting stronger truth, not by minting second truth-domains.

## 2) View objects matter more than cube rhetoric

`view-namespace-posture-v0.md` and `view-replication-boundary-v0.md` keep reinforcing the deeper law:

- views are explicit objects,
- resolution is pure,
- active bindings stay local and explicit,
- and replicated view summaries do not auto-activate local bindings.

That is a very important lesson for Helm.
It argues for stronger shell-owned query views, exact trails, lens views, and cross-pillar view decks.
It argues against ambient “the system probably knows what you meant” browse folklore.

## 3) Replication should inform, not activate

`view-replication-boundary-v0.md` is especially valuable because it refuses an easy lie: a replicated summary is not the same thing as an active local binding.

For Helm this becomes a major anti-folklore rule:

- a saved view is not live activation proof,
- a recent item is not live continuity,
- a dock pin is not current availability,
- and a copied trail is not current authority.

Compact surfaces can still be excellent, but they stay excellent by degrading honestly instead of auto-activating stale or remote state.

## 4) Materialization is the seam that keeps honesty intact

The strongest new lesson in this pass came from the materialization boundaries:

- `openuri-materialization-boundary-v0.md`
- `open-untrusted-materialization-boundary-v0.md`
- `import-to-docref-boundary-v0.md`
- `import-to-docref-fresh-identity-boundary-v0.md`

Across all of them, the pattern is clear:

- preview/open does not silently become durable import,
- durable import does not silently become back-write continuity,
- and when something does become a local durable object, fresh explicit identity matters.

That is exactly the seam Helm still needs to keep warming:
not just adoption for delegated work, but a broader **materialization bay** posture for when a view, preview, import, trail, or candidate becomes a durable local thing or a live shell effect.

## 5) Fresh identity beats hidden alias laundering

The fresh-identity import boundary in SlopOS is a major lesson from the past.
Two byte-equal things should not quietly collapse into one live identity when quarantine, trust, or provenance meaning differs.

For Helm this means a future materialization step should prefer:

- fresh local object,
- explicit provenance,
- explicit reattach/adopt if that is really desired,
- and visible witness when equality tempts the shell to cheat.

This is how Helm avoids charming-but-rotten “we found the same thing for you” folklore.

## 6) What Helm should keep from SlopOS's datacube

Strong imports:

- bounded keyed projections
- explicit view objects
- non-activating replicated summaries
- explicit materialization/adoption seams
- fresh-identity-first import posture where authority or provenance would otherwise blur

Non-imports:

- a giant shell-state cube UI
- a second dashboard constitution
- boundary proliferation for its own sake
- assuming every useful shell affordance needs SlopOS-grade formalism before a specimen exists

## 7) The best new warm moves for Helm

### A. View decks

Helm increasingly wants not just one good query view, but small **named decks of explicit views** over one activity, object family, or exact subject relation.

A good deck might let an operator pivot among:

- objects
- jobs
- receipts
- transfers
- holds
- recall trails
- or one live lens

without pretending the deck itself is live continuity.

### B. Materialization bays

Helm already has adoption harbors for delegated mutable work.
The new pressure is broader:
Helm likely wants a shell-owned place or step where a projection, import, preview, or trail can become:

- a fresh local object,
- a saved entry artifact,
- a live attachment,
- an adopted mutation,
- or another stronger shell effect.

The important point is that this becomes a **second explicit workflow**, not a hidden side effect of the first one.

### C. Renewed live-lens pressure

This pass also makes live lenses feel more relevant again.
A lens is one of the best ways to cash out “bounded projection discipline” into something delightfully Helm-shaped.
But it only stays good when provenance, liveness, and interaction strength remain explicit.

## 8) What this pass changes

- it sharpens the SlopOS datacube reading into **explicit multi-view discipline plus explicit materialization discipline**
- it strengthens **view decks** and **materialization bays** as warm Helm moves worth carrying forward
- it renews **live lenses** as a likely shell luxury that can prove the projection law in a more compelling way
- it still does **not** justify new pillars or a giant universal Helm cube

## Current bounded take

**Helm should keep the seven pillars stable, continue treating compact shell luxuries as bounded projections, and now warm two new moves in earnest: view decks and materialization bays. SlopOS is teaching Helm that great shells win by making views explicit and stronger materialization steps explicit — not by hiding both inside one magical surface.**
