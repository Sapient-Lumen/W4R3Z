# Web research synthesis — 2026-03-22 — pass LIV

Question for this pass:
**what do current tools teach Helm about a real datacube shape — multiple explicit views over one truth, restricted trust on imported surfaces, launchable activity front doors, and keyboard-first triage — and what should Helm steal without becoming a giant shared-workspace dashboard?**

## Main takeaway

The strongest outside pattern is not a giant cube.
It is:

**bounded views + explicit trust posture + honest front doors.**

The best current systems increasingly do four things well:
- they let one underlying truth support several explicit views,
- they keep save/share/sync/publish as named acts rather than ambient sameness,
- they treat imported or unfamiliar things as weaker until trust or fit is earned,
- and they let a saved setup relaunch work quickly without pretending the setup is already live.

That is exactly where Helm's datacube should keep going.

## What the current tools are teaching

### 1. Obsidian keeps proving that a useful datacube can stay local, explicit, and plural

Obsidian Bases is a core plugin over local Markdown files and properties.
A base can have several views,
and each view can keep its own configuration.
The newer developer docs make the important host-law point even stronger:
plugins can register custom Bases views,
but those views still hang off the host's one Bases model rather than replacing it.

The lesson for Helm is excellent:
**saved view objects should be first-class,
but the host still owns the law.**
Helm should absolutely steal multiple explicit views over one truth,
and it should also steal custom view extensibility under shell law instead of ambient plugin folklore.

### 2. Airtable keeps validating view objects, view-specific publication, and visible sync activity

Airtable still treats a view as a real thing:
a particular way to look at the underlying table,
with several view types over the same records.
Its current share flow keeps stronger moves explicit:
create link,
sync this view,
publish to data library,
manage link settings,
and inspect sync activity.
Its Interface Designer adds another useful pressure:
teams often need smaller role-shaped pages over larger truth,
with granular permissions,
rather than one giant base UI for everyone.

The lesson for Helm is:
**saved views, publication ladders, promotion receipts, and role-shaped front doors are more promising than one universal cube screen.**

### 3. GitHub keeps validating view tabs plus compare-from-activity

GitHub Projects keeps project views as explicit tabs,
not hidden filters.
GitHub's repository activity view also makes one great move ordinary:
from an activity feed,
you can ask for **Compare changes** on one exact activity.

The lesson for Helm is:
**activity surfaces should make compare a nearby honest move,
not a trip into a separate history religion.**
A view deck,
entry kit,
or operations surface should be able to say:
this changed,
and here is the exact bounded compare that explains it.

### 4. VS Code is validating restricted arrival and explicit carried setup

Workspace Trust remains one of the best current examples of honest arrival posture.
An unfamiliar folder can open in Restricted Mode,
show a banner and status-bar badge,
and block or limit powerful features until trust is explicitly granted.
The January 2026 release even made terminal opening in restricted workspaces an explicit opt-in,
which reinforces the same rule.
Profiles remain the complementary move:
a profile is an explicit set of customizations that can be switched,
shared,
exported,
and imported.

The lesson for Helm is strong:
**an imported view,
deck,
front door,
or workflow starter should land in a weaker restricted posture first,
with the blocked stronger actions named plainly.**
At the same time,
carried setup should be a real object,
not hidden session residue.

### 5. PowerToys Workspaces validates launchable front doors rather than fake live sessions

PowerToys Workspaces captures a desktop arrangement,
lets people edit it,
add CLI arguments,
and pin it as a desktop shortcut for quick launch.
That is valuable precisely because it is a fast return path,
not because it overclaims current liveness.

The lesson for Helm is:
**activity entry kits / front doors should feel strong,
but they should keep relaunch,
restore,
attach,
and fresh-start posture visibly distinct.**

### 6. Figma keeps validating branches, checkpoints, and compare-before-adopt

Figma branches remain explicit,
restorable,
and visible in version history.
The current docs still say Figma creates checkpoints when you create or merge a branch,
and adds an extra checkpoint before merge.
Dev Mode compare changes also keeps changed-since-last-view plus exact compare close at hand.

The lesson for Helm is unchanged but still important:
**checkpoint branches remain one of Helm's best proof targets,
and compare should stay bounded and adjacent to adoption.**

### 7. Linear keeps proving that triage deserves its own lane

Linear's Triage surface is a separate team-visible lane with direct keyboard entry.
That matters because one of the missing shell luxuries in many desktop systems is not just search,
but **an obvious operational inbox**.

The lesson for Helm is:
**front doors and view decks should often have a named triage member,
not just a generic all-items view.**
A datacube becomes more humane when one saved view is clearly “what needs attention now?”

## What Helm should steal now

### Steal directly

1. **saved view objects as real shell objects**
   - Obsidian,
     Airtable,
     and GitHub all keep multiple explicit views over one truth.

2. **restricted arrival posture for imported surfaces**
   - VS Code Workspace Trust is the cleanest model.

3. **activity front doors that relaunch without bluffing liveness**
   - PowerToys Workspaces is a strong precedent.

4. **one obvious triage lane near richer activity structure**
   - Linear keeps validating this.

5. **compare-from-activity rather than compare-in-a-separate-religion**
   - GitHub and Figma both support this.

6. **explicit share / sync / publish ladders with visible activity**
   - Airtable is especially strong here.

7. **custom views under host law**
   - Obsidian's Bases API is the right shape:
     extensible,
     but still host-owned.

### Do not steal whole

1. **one giant dashboard as the constitution**
2. **ambient sync mythology**
3. **saved workspace equals live session mythology**
4. **plugin systems that outrun host review / receipts / trust law**
5. **one global search/index worldview that quietly becomes authority**

## Why this matters for Helm specifically

Helm already has:
- saved view objects,
- checkpoint branches,
- publication ladders,
- promotion receipts,
- imported-surface trust posture,
- activity spines,
- activity entry kits,
- current-live beacons,
- drift beacons,
- and basis contrast cards.

This pass says the next move is not another pillar.
It is tightening the datacube shape those moves already imply:

- **one truth can support several explicit views**
- **imported views/front doors should start weaker**
- **saved activity entry should point to a preferred door plus a triage lane plus compare/change awareness**
- **publication should stay explicit and inspectable**

## Judgment for Helm

Keep the seven pillars stable.
Keep **saved view objects** and **checkpoint branches** as the two strongest proof targets.
Also start treating these as the most mature support moves for the datacube story:

- **imported-surface trust posture**
- **activity entry kits / front doors**
- **view decks** as derivative activity/object clusters,
  not as dashboards-with-delusions
- **publication ladders + promotion receipts** for view/share/sync/publish truth
- **one named triage lane** near saved entry and compare surfaces
