# Web research synthesis — 2026-03-22 — pass L

Purpose: look for the next compact Helm move after effect receipts and slot verdict ledgers,
and ask what current tools say about **exact reversal**, **bounded repair**, **redo/replay**, and **partial recovery honesty**.

## Main takeaway

The strongest outside pressure now says Helm should not stop at:
- exact selected context,
- explicit contribution truth,
- explicit claim posture,
- exact proposed-change review,
- and durable post-change receipts.

It also needs one honest shell-owned answer to:

**what exact change am I being asked to reverse or repair now, and on what basis?**

That object should likely be a **reversal warrant**.

And because many real recoveries are not all-or-nothing,
Helm likely also needs one compact durable answer to:

**what is the smallest safe next recovery rung: undo, redo, rerun failed subset, reopen unresolved slots, replay on a fresh basis, or hold?**

That second surface should likely be a **repair ladder**.

## What current products keep validating

### 1. Reversal is increasingly treated as a first-class new proposal, not a magic erase button

GitHub's docs say reverting a merged pull request creates a **new pull request** that contains one revert of the merge commit.
GitHub Desktop likewise says a revert is itself a new commit,
and the original commit remains in history.

That is strong validation for Helm's next move:
**reversal should be explicit,
reviewable,
and history-bearing,
not hidden under an ambient undo myth.**

### 2. Good repair UX distinguishes full rollback,
selective rerun,
and redo

VS Code keeps three different recovery moves explicit:
- edit a previous request,
  which reverts the original request and all later changes before resending;
- restore a checkpoint,
  which rolls the workspace back to an earlier point;
- redo after restoring,
  which can reapply the undone changes.

GitHub Actions similarly allows rerunning all jobs,
rerunning failed jobs,
or rerunning a specific job.
The docs also say the rerun uses the **privileges of the actor who originally triggered the workflow** and the same `GITHUB_SHA` and `GITHUB_REF` as the original run.

That is unusually strong validation for a Helm repair ladder:
**repair is not one button.
It is a bounded choice among exact recovery paths that keep basis and authority visible.**

### 3. Humane action systems keep a nearby local undo,
but that undo is still scoped and fragile

Gemini in Google Sheets shows an **Action preview card**,
then **Apply**,
and after completion keeps **Settings** and **Undo** nearby.
But the docs say **Undo** is only available until further changes are made.

That is a very useful product lesson:
nearby reversal is great,
but Helm should avoid pretending every effect is indefinitely or globally undoable.
A reversal path should say what it still binds to,
what drifted,
and when it downgraded.

### 4. Recovery after partial or failed merges still needs exact checkpoints and explicit scope warnings

Figma's version-history restore is non-destructive and adds two autosave checkpoints: one for the current version and one for the restored version.
Its troubleshooting docs for incomplete merges/updates tell users to restore the branch to the **Before update** checkpoint,
or restore the main file to a version before the failed merge.
Those same docs warn that restoring the main file applies to everyone with access,
and that undoing a merge will not restore an archived branch.

That is excellent validation for Helm:
**recovery should carry explicit blast-radius and dependency truth,
not just a comforting “restore” verb.**

## What to steal now

1. **Reversal as a new exact proposal object**
   - not magic,
     not ambient,
     not history-erasing.

2. **Bounded repair ladders instead of one generic retry**
   - undo,
     redo,
     rerun failed subset,
     rerun exact item,
     replay on fresh basis,
     reopen unresolved slots,
     or hold.

3. **Basis- and authority-bearing repair**
   - the system should say which effect receipt,
     which actor privilege posture,
     and which current mutable basis the repair still depends on.

4. **Scope warnings on reversal**
   - some recovery acts are local,
     some are shared,
     some are partial,
     and some cannot faithfully restore side branches or later derived effects.

## What not to steal

- do not promise universal undo for every shell action
- do not let reversal quietly bypass fresh review when basis drifted
- do not let “retry” hide whether Helm is redoing,
  rerunning failed subset,
  replaying on fresh basis,
  or proposing a compensating change
- do not let recovery cards impersonate current-live truth
- do not build a giant incident/workflow system before one compact recovery slice exists

## Judgment for Helm

The next compact support moves worth defining are:
- **reversal warrants** — exact shell-owned proposal objects for undo / revert / compensating change on one reviewed historical effect
- **repair ladders** — compact shell-owned ladders that choose among redo,
  subset rerun,
  replay,
  reopen-unresolved,
  hold,
  or fresh-branch-and-fix

This still looks stronger than adding another pillar,
because it completes the aftermath loop:
- selected context
- contribution truth
- output claim posture
- exact proposal review
- exact aftermath truth
- **exact recovery truth**
