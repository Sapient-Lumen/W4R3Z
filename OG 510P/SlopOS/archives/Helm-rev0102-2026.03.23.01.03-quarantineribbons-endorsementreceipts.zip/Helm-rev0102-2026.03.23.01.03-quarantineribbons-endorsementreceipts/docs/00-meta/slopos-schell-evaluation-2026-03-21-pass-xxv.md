# SlopOS / Schell evaluation — 2026-03-21 pass XXV

Purpose: keep evaluating what SlopOS's datacube is actually teaching Helm now that portable cores,
local overlays,
handoff packets,
and promotion receipts are already warm.

This pass focused on the next narrower question:

**what should happen when a portable shell surface lands on a receiver so Helm stays honest about fit,
materialization,
and local rebinding?**

## 1) View replication boundary keeps teaching that arrival is not activation

`view-replication-boundary-v0.md` remains one of the clearest teachers in the whole SlopOS bundle.
Its refusal is simple:

- non-owner replicas may hold bounded read-only summaries or cache-shaped snapshots,
- but those artifacts do **not** auto-attach,
  auto-detach,
  or quietly become the receiver's active local view,
- and a receiver must either ask the owner for the authoritative mutation or explicitly import/materialize a separate local view.

That is almost a direct teacher for Helm's next landing move.
A handoff packet,
portable core,
or published deck should not arrive as active local binding.
It should arrive as something the shell can inspect for **receiver fit** and then explicitly **rebind** or materialize.

## 2) OpenURI boundaries keep warning that handoff does not prove completion,
persistence,
or local object creation

`openuri-launch-completion-boundary-v0.md` keeps launch outcomes admission-scoped rather than target-completion truth.
`openuri-materialization-boundary-v0.md` keeps mediated launch from quietly turning into download,
staging,
import,
or docref minting.
`openuri-portal-posture-v0.md` keeps OpenURI manual,
scheme-gated,
and launch-only rather than a general return channel.

The combined lesson for Helm is powerful:

**portable arrival should remain weaker than local attachment or current live truth until the receiver performs an explicit stronger step.**

That means Helm should not let a packet landing imply:

- current local binding,
- durable local installation,
- successful completion,
- or trust inheritance.

A receiver fit card can answer “what could happen here?” while a rebind ladder answers “what stronger local step do you want to take?”

## 3) Observation/export posture keeps teaching that receiver-side inspection should be bounded,
pull-like,
and non-ambient

`observation-export-posture-v0.md` is also a strong teacher here.
Exports are pull-only,
killable,
bounded,
and not the basis for an ambient global indexing service.
That is exactly the right temperament for Helm's landing surfaces.

A receiver fit card should feel like bounded inspection,
not like an always-on ambient scanner that silently crawls all local possibilities and auto-solves the landing problem.
If Helm offers suggestions,
those suggestions should remain compact,
killable,
and visibly weaker than actual rebinding or adoption.

## 4) Activation posture reinforces that continuity helpers are not generic import/export channels

`activation-posture-v0.md` draws another important line:
handle-store state is continuity-only,
not a generic persistence/export channel.
That is a useful pressure against a common temptation for Helm.
Once portable cores and overlays exist,
it becomes easy to imagine a giant invisible cache of old local bindings that auto-heals every packet on arrival.

SlopOS is a strong argument against that move.
Continuity helpers may exist,
but they should not silently expand into a second hidden import/export authority plane.
Receiver-side rebinding should stay a visible shell workflow,
not background folklore.

## 5) The datacube lesson is getting sharper: Helm needs landing discipline more than more transport ambition

This pass makes the imported SlopOS lesson sharper again.
The next big gain is not another kind of packet.
It is better landing discipline:

- explicit receiver fit
- explicit missing-local facts
- explicit omitted-local facts
- explicit local rebinding
- explicit materialization / hold / reject
- and explicit refusal when no honest receiver-side landing exists

That is a better datacube lesson than “make imports smarter.”

## 6) Strongest Helm payoffs from this pass

### Receiver fit cards

Receiver fit cards now look like the natural landing sibling to portable cores and handoff packets.
They should stay compact and probably show only:

- exact incoming surface/core witness
- locality tier and portability class
- what matched locally
- what was intentionally not carried because it was local-only
- what required local choice or trust
- and which next stronger actions are available here

### Rebind ladders

Rebind ladders now look like the natural action sibling to fit cards.
They would make local rebinding explicit for things like:

- paths or roots
- accounts or providers
- profiles or sessions
- workspaces or activities
- local placements and shortcuts
- and activity-local overlays

The first cut should stay small and visibly authored.
The shell should not hide who or what proposed the rebind.

## What this pass changes

- it adds **receiver fit cards** as a new warm Helm move
- it adds **rebind ladders** as a new warm Helm move
- it sharpens the SlopOS reading toward **arrival-is-not-activation** and **landing-is-a-second workflow**
- it keeps companion resources warm only as a nearby idea,
  not yet as a contract

## What this pass still does not justify

- a giant self-healing import/rebind engine
- automatic receiver-side activation from packets or exports
- ambient completion claims after portable arrival
- universal global indexing of possible rebind targets
- adding more pillars

## Current bounded take

**Helm should keep reading SlopOS's datacube as a teacher of non-activating arrival,
explicit fit,
explicit local rebinding,
and explicit stronger landing steps.
That pushes Helm toward receiver fit cards and rebind ladders without justifying a giant sync/import constitution,
auto-healing continuity folklore,
or ambient activation lies.**
