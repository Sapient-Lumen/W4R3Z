# SlopOS / Schell evaluation — 2026-03-22 — pass XXXVII

Purpose: keep using SlopOS as Helm's main teacher without importing its archive habits more broadly than the shell product can currently justify.

## Main takeaway

The latest SlopOS datacube is still an excellent teacher for **truth discipline** and a mixed teacher for **product-shaping tempo**.

That split matters.
Helm should keep stealing SlopOS's refusal laws,
but it should be careful not to inherit SlopOS's tendency to let boundary machinery outrun the nearest shell specimen.

Schell remains useful as a seam teacher for shell-facing work,
but it still should not choose Helm's whole constitution too early.

## What SlopOS is teaching especially well right now

### 1. Replication is not activation

The current SlopOS view-replication boundary is one of the most important lessons for Helm.
Replicated view summaries may help inspection or caching,
but they stay read-only,
non-activating,
and weaker than authoritative attach/detach.

For Helm this is gold:

- shared view objects are not live receiver bindings
- published decks are not local activation
- copied shell luxuries are not continuity
- imported structure should require a visible local fit or adoption step

### 2. Materialization and import deserve explicit seams

SlopOS's OpenURI materialization boundary and import-to-docref boundaries keep refusing a very common lie:
that opening,
fetching,
importing,
and minting a durable local object are “basically the same move.”

For Helm this means:

- preview is not open
- open is not import
- import is not adoption
- and imported local identity should often be fresh even when the bytes were already nearby

### 3. Evidence is not verdict

SlopOS keeps drawing a hard line between evidence surfaces and stronger claims.
Approval basis is exact and cannot silently float to a newer mutable head.
Acceptance receipts do not prove downstream completion.
Attestation results and certificate-status evidence remain appraisal/evidence artifacts rather than portable current-trust or approval truth.

For Helm this is a major lesson for Recall and Operations Center:

- receipts are not live success
- changed-since cues are not source truth
- trust badges are not adoption
- review basis drift should weaken affordances until refreshed

### 4. Family maps and boundary indexes are effective anti-amnesia tools

The boundary-family map is a strong organizational move.
It forces the archive to say whether a rule belongs to a closed family or is an intentional singleton.
That sharply reduces semantic drift.

Helm should steal the **discipline**, not the exact machinery:
small candidate-contract clusters,
closed families when a theme is clearly real,
and explicit singleton justification when it is not.

## What Helm should not import too eagerly

### 1. Archive-law sprawl

SlopOS can afford a lot of boundary work because it is building a broad substrate and has chosen that style.
Helm is a shell product.
If Helm copies the full archival density too early,
it risks explaining everything except the daily shell moves.

### 2. Premature closure on shell-level luxuries

SlopOS is right to pin many substrate seams early.
Helm should be slower to freeze shell luxuries like decks,
docks,
portable workspaces,
and publication governance until one or two specimens prove their shape.

### 3. Over-teaching through prohibition alone

SlopOS's best work prevents laundering.
But Helm still needs positive delight:
preview,
restore,
branch,
pin,
share,
reveal,
route,
and adopt should feel terrific,
not merely safe.

## Pillar-level implications for Helm

### Tiling Shell
Steal locality discipline and shell-owned activation truth.
Do not steal substrate-scale closure before a shell specimen demands it.

### Omnibox
Steal exact review basis and typed action honesty.
Use preview-promotion ladders rather than pretending search results are already adopted/opened.

### Object Browser
Steal view non-activation law,
explicit materialization,
and fresh-local-identity humility.
This pillar benefits directly from saved view objects and imported-surface trust posture.

### Operations Center
Steal request/acceptance/live/receipt separation and evidence-versus-verdict discipline.
Make review drift and background adoption visible.

### Desktop Flow
Steal explicit adoption for helper-produced work.
Keep imported fragments or generated candidates weaker than live graph truth until adopted.

### Recall
Steal restore humility and exact-basis law.
Checkpoints,
reentry,
and repaired continuity should remain visibly different.

### Exchange
Steal explicit import/publication/materialization ladders.
Shared packets,
published surfaces,
and receiver-local adoption must not blur.

## Judgment

SlopOS is still the right main teacher for Helm,
but the lesson is now very specific:

**steal SlopOS's anti-laundering laws, not its full archive tempo.**

For the next Helm revisions,
that means:

- keep saved view objects and checkpoint branches as the leading shell proofs
- strengthen them with imported-surface trust posture and preview-promotion ladders
- and resist the temptation to constitutionalize every nice shell luxury before the specimens teach back
