# SlopOS / Schell evaluation — 2026-03-22 — pass XLIV

Purpose: re-read the latest SlopOS bundle and ask what it teaches Helm about **currentness, recency, weak open, and explicit activity scope** now that Helm has activity spines, resource shelves, and entry kits.

## Main takeaway

The harsh SlopOS lesson is not changing.

**issuance evidence, request evidence, history hints, and grouped structure are not current live truth.**

That matters even more now,
because Helm has enough saved and grouped objects that it could easily start flattering the operator again.

## What the latest SlopOS bundle keeps teaching

### 1. Generic open still has to stay weak

The OpenURI boundaries are still excellent teachers.

- launch completion stays admission-scoped rather than portable proof of what actually happened after launch
- recent-items/history semantics stay shell-local and non-authoritative
- materialization/import/persistence stay on explicit other seams rather than becoming side effects of generic open

This is exactly the discipline Helm needs around:
- ordinary open
- recent/opened folklore
- saved entry kits
- grouped resource shelves
- and current-live reentry

A saved thing can absolutely be useful.
But a weak action should not quietly mint a stronger claim.

### 2. Import and safe-open still teach fresh identity and weaker arrival posture

The safe-open and import→docref boundaries stay especially valuable.

SlopOS keeps insisting that:
- imported material should mint **fresh local identity**
- risky/opened material should remain **quarantined by default**
- export/copy-back is not a hidden clearance or endorsement act

For Helm,
that strengthens a shell law that is now central:

**an imported/shared starter or grouped work object should often begin weaker than ordinary local truth.**

That reinforces:
- imported-surface trust posture
- landing rehearsal
- arrival overlay
- materialization bays
- and now a scope witness that can say when the activity basis came from imported or narrowed context

### 3. Descriptor truth is not current-state truth

The lease-descriptor state boundary is an unusually good direct teacher for Helm.

A descriptor can be exact issuance evidence without being a portable oracle of current live state.
Old receipts can prove what once happened without proving what is live now.

Helm needs to steal that exact humility.

Because otherwise:
- a last restore receipt,
- a checkpoint,
- a route receipt,
- an old front door,
- or an imported activity spine

will all start to flatter themselves into “still current” just because they are crisp artifacts.

### 4. Boundary families beat folklore

SlopOS keeps doing something worth stealing at the product level:
it refuses to let meaning hide in vibe.
If a seam matters,
it gets pinned.

For Helm,
the equivalent is likely not “write 60 boundary docs for the shell UI.”
It is smaller and more product-shaped:

- define one **current-live beacon** contract
- refresh one **activity scope witness** contract
- keep them attached to saved views,
  spines,
  entry kits,
  Recall,
  and stronger open/restore/attach flows

That is how Helm learns the right lesson from the datacube without importing archive bulk for its own sake.

## What Helm should keep

### 1. Currentness must be shell-owned
The shell should own the best answer to:
- what is live now
- how recent that proof is
- whether the live hook is exact,
  historical,
  widened,
  or unknown

### 2. Scope should be inspectable
Same-activity claims should be able to name:
- which axes counted
- which nearby context did not count
- whether the scope is personal,
  shared,
  imported,
  or widened

### 3. Recents stay weak unless they can point to stronger truth
Recent/opened history can be useful.
But without a current-live beacon,
it should stay visibly weaker than the shell's live truth.

### 4. Saved grouped objects stay weaker than current live truth
Activity spines,
resource shelves,
saved views,
entry kits,
and checkpoints should all remain useful without impersonating the live lane.

## What Helm should not keep

### 1. Do not let crisp receipts impersonate currentness
### 2. Do not let grouped structure impersonate activation
### 3. Do not let imported starters inherit ordinary local trust automatically
### 4. Do not let ambient profile/session/account glow fill in missing scope

## Judgment

The next wise move is not a new pillar.

It is to make Helm's saved/grouped shell objects answer one harder question honestly:

**what is actually current and in what scope?**

That is why the next compact support move now looks like:
- **current-live beacons**
- plus a refreshed **activity scope witness**
