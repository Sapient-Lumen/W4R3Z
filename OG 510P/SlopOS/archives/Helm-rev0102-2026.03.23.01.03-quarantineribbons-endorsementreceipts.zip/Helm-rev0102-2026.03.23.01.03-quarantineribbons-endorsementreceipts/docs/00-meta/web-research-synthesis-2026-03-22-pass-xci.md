# Web research synthesis — pass XCI

This pass focused on one question:

**what do mature systems teach about temporary stronger power that Helm can reuse without becoming an admin product?**

## Cluster 1 — just-in-time power works when it stays time-bound and inspectable

Google Cloud Privileged Access Manager is a strong current teacher.
Its entitlements can define:
- who may request,
- whether justification is required,
- what roles are temporarily granted,
- maximum grant duration,
- optional approvers,
- and optional approver justification.
It also supports multi-level and multi-party approvals,
and active grants are revoked when the duration ends.

That strongly suggests a Helm object weaker than a live grant but stronger than a loose recipe:
**an elevation ticket**.
It should be able to say:
- who may request,
- what stronger power is being asked for,
- what reason/ticket text was supplied,
- what duration was requested,
- whether approval is pending,
- and what exact live borrowed window would exist if activated.

## Cluster 2 — eligible is not active

Microsoft Entra PIM is even clearer on the state split.
Users can hold **eligible** role assignments,
then activate them later,
optionally with reduced scope,
reason text,
MFA or Conditional Access requirements,
ticket information,
approval,
and bounded assignment duration.
It also supports deactivation,
and its own docs warn that activation-time conditions alone do not govern what happens after activation unless separate policies also apply.

That is an excellent Helm warning.
The shell should not compress these into one truth.
At minimum it should keep:
- eligible,
- requested,
- pending approval,
- active borrowed,
- hot now when in actual use,
- and ended/historical.

## Cluster 3 — short-lived privilege is often session-scoped

`sudo` remains a surprisingly good shell-scale teacher.
The default sudoers policy caches credentials only for a short period,
and by default keeps separate records per terminal.
That means even old-school local privilege systems recognize that temporary stronger power should be:
- time-bounded,
- session- or terminal-sensitive,
- and not treated as one permanent global mode.

Helm should steal that spirit without copying the UX.
Temporary stronger shell power should prefer one activity,
one lane,
one exact subject family,
or one current review basis over a global remembered admin glow.

## Cluster 4 — approval and issuance are not completion

Kubernetes CertificateSigningRequests add another precise cut.
A request may exist,
may require approval,
may be denied,
and only later receive an issued certificate.
The request can also ask for a particular lifetime.
This is a strong reminder that request,
approval,
and issued live authority are different stages.

For Helm that argues against one green badge.
It argues for a small stateful ticket object whose stages remain inspectable.

## Design moves worth stealing

1. **Elevation tickets**
   Small trusted-chrome objects for temporary stronger acts.

2. **Reduced-scope activation**
   Allow the requester to activate a narrower scope than the maximum.

3. **Reason/ticket-bearing activation**
   Let stronger temporary power carry operator intent and incident context.

4. **Early end / de-elevation**
   Make end-now or narrow-now easy instead of relying only on expiry.

5. **Different truths for eligibility, activation, and hot use**
   Do not flatten them.

## What Helm should refuse

- permanent ambient “admin mode” that piggybacks on one old success
- auto-renew by default
- review/approval surfaces buried only in provider settings
- silent carry-forward from one device/session/lane into another
- vague allowed/forbidden labels when the real truth is pending approval or active-until-time-X

## Main judgment

A shell can feel **super awesome** here by making temporary stronger power humane,
compact,
and nearby:
not with a giant IAM center,
but with one clean shell-owned ticket object,
one live borrowed-window witness,
and one nearby de-elevation rail.
