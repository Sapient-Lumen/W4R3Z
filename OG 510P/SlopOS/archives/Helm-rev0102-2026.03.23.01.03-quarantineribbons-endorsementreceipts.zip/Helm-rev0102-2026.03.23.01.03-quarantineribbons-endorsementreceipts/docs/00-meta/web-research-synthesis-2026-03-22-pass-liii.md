# Web research synthesis — 2026-03-22 — pass LIII

Question for this pass:
**what do current tools teach Helm about exact change awareness, stale reviewed bases, saved slices that expire, and humane “changed since you last looked” cues — and what should Helm steal without becoming giant diff bureaucracy?**

## Main takeaway

The strongest outside pattern is not “show more history.”
It is:

**show small exact drift against one explicit basis.**

The best current systems increasingly distinguish between:
- the exact thing that was reviewed,
- the exact thing that is current now,
- the bounded compare surface between them,
- and the next honest ladder when they no longer match.

For Helm, that points toward two compact shell moves:
- **drift beacons**
- **basis contrast cards**

## What the current tools are teaching

### 1. GitHub keeps reminding us that approval belongs to an exact diff state, not to a branch name forever

GitHub’s protected-branch rules say stale approvals can be dismissed when new commits change the pull-request diff.
GitHub also records the diff state at the point when the pull request was approved.
And its compare docs keep the compared basis explicit: compare branches, tags, or exact commits, while pull requests show a three-dot diff against the merge base.

The lesson for Helm is strong:
**review should bind one exact basis, and “changed since review” should be a first-class shell fact.**

### 2. VS Code is making isolated change comparison very ordinary

VS Code checkpoints restore the workspace to the state at a specific earlier point and undo changes after that checkpoint.
Its worktree docs also make a separate compare surface explicit: you can compare a changed file in a worktree with the current workspace side-by-side before bringing changes back.

The lesson for Helm is not “be a Git UI.”
It is:
**a shell can own a tiny compare-against-basis surface without becoming a full history religion.**

### 3. Notion’s view-query model is a clean warning against timeless saved slices

Notion’s view query endpoints create cached result sets with a `query_id`, and those cached results expire after about 15 minutes.
If the cache has expired, retrieving results returns a 404.

That is a very Helm-shaped lesson:
**a saved or reviewable slice can be real and useful while still carrying explicit expiry and drift posture.**

### 4. Google Docs validates humane “changed since last viewed” cues plus named bases

Google Docs surfaces a blue dot on the Last edit icon when someone updated the file since you last viewed it.
It also lets people browse version history, restore an earlier version, copy an earlier version, and create named versions so versions are not merged away.
At the same time, the help docs warn that revisions may occasionally be merged to save storage space.

The lesson for Helm is subtle but important:
**“changed since you last saw it” is valuable, but it is weaker than a named exact basis.**
A humane beacon and an exact basis can coexist.

### 5. Figma shows that compare-before-adopt can stay visual and bounded

Figma’s branch review lets reviewers preview changes before merging.
The merge review supports side-by-side and overlay comparison, and version restore is non-destructive: restoring creates autosave checkpoints for both the previous current version and the restored version.

The lesson for Helm is:
**when drift matters, the right next move is often a compact compare surface with an obvious adopt/hold/review-again ladder nearby.**

## What Helm should steal now

### Steal directly

1. **Stale-review invalidation tied to exact changed basis**
   - GitHub’s stale-approval rule is the clearest precedent.

2. **Compare current against one explicit basis**
   - VS Code worktree compare and GitHub compare views both validate this.

3. **“Changed since you last viewed” as a weak but humane cue**
   - Google Docs’ blue-dot pattern is excellent.

4. **Named bases**
   - Google Docs named versions and Figma named versions both validate that users need memorable exact comparison anchors.

5. **Expiry on saved review slices**
   - Notion’s expiring cached queries are a direct proof.

6. **Visual compare before stronger adoption**
   - Figma’s side-by-side and overlay review modes are especially strong here.

### Do not steal whole

1. **giant universal diff engines for every shell object**
2. **history theater that hides which basis actually mattered**
3. **“changed” badges with no exact basis witness**
4. **auto-refresh that quietly replaces the reviewed basis under the user**
5. **notification spam for every tiny mutation**

## Why this matters for Helm specifically

Helm now has:
- basis packets,
- drift gates,
- claim envelopes,
- action warrants,
- effect receipts,
- and review/recovery ladders.

That stack is good enough that the next gap is easy to name:
**when something changed, where is the tiny shell-owned cue and where is the compact compare surface that explains the change against one exact basis?**

That is what drift beacons and basis contrast cards are for.

## Why this is super-awesome material

This could make Helm feel delightfully strong without getting huge.
A user should be able to:
- glance at an entry kit, view deck, or recall return and see **unchanged / changed / materially drifted / expired / basis missing**,
- click once into a bounded **current vs reviewed basis** compare,
- choose **inspect / review again / update basis / branch from old / keep old but hold stronger action**,
- and then leave with a durable witness of what exact basis now counts.

That is a much better power story than vague recency badges or giant timelines.

## Judgment for Helm

The seven pillars should still stay stable.
Saved view objects and checkpoint branches remain the strongest proof targets.
But the next compact support layer that now looks worth promoting again is:

- **drift beacons**
- **basis contrast cards**
