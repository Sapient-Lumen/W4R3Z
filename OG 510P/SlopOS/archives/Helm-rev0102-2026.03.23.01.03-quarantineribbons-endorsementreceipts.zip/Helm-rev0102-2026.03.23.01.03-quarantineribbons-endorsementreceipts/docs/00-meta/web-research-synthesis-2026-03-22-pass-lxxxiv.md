# Web research synthesis — 2026-03-22 — pass LXXXIV

Question for this pass:
**what small shell laws should Helm steal next if budgets, leases, and renewal already look right, but stronger acts can still feel stale, duplicated, or cliff-like on teardown?**

Answer:
add three compact support moves:
- **change cursors** for changed-since / resume-watch honesty,
- **retry keys** for safe deduplicated stronger acts,
- and **teardown rails** for requested-but-not-finished removal/revoke truth.

## 1. HTTP ETags and `If-Match` keep proving that “the thing I last saw” deserves its own witness

ETags are not the resource itself.
They are a compact version witness.
`If-Match` then turns that witness into an honest precondition for mutation.

That is a superb shell lesson.
Helm already has basis stamps for “what exact thing this surface reflects.”
But mutable exact objects also need a smaller current-facing witness for:
- what version was last seen,
- whether a write still binds that version,
- and whether a caller should refresh before promoting.

A **change cursor** is the right object for that.
It stays smaller than a watchpoint,
smaller than a whole receipt,
and much smaller than pretending every mutable thing needs a giant sync subsystem.

## 2. Kubernetes shows the next rung: change cursors can also be resume points, not just compare tokens

Kubernetes makes `resourceVersion` useful for both optimistic concurrency and watch resumption.
The API concepts docs also describe bookmark events that tell a client the stream is caught up at least to a given resource version.

That suggests Helm should let a change cursor say not only:
- “this is what I last saw,”

but also:
- “resume from here,”
- “tell me if this source is newer than this cursor,”
- and “this surface is caught up through at least this point.”

That is much better than vague latestness,
especially for linked views,
watchpoints,
subscriptions,
and exact remembered handles.

## 3. Google Drive reinforces the same idea from another angle: explicit page tokens for future change retrieval

Drive's change APIs keep a `startPageToken`,
use that token to list later changes,
and can watch that stream.
The lesson is not “copy Drive.”
The lesson is that a shell can keep a tiny carried witness for future deltas without pretending it has current-live truth forever.

Helm should steal:
- explicit start cursor,
- resume from exact cursor,
- explicit expired/unusable cursor posture,
- and one visible refresh/rebind path when the cursor can no longer continue honestly.

## 4. Stripe keeps proving that retry safety deserves its own object too

Stripe's idempotency docs are blunt:
use an idempotency key so retries do not accidentally create a second effect.
This is exactly the sort of law Helm should import for stronger shell acts.

If a warrant-backed action is retried because of transport uncertainty,
helper timeout,
or provider ambiguity,
Helm should be able to say:
- this is the **same intended act**,
- it is still in flight / already landed / conflicted,
- and here is the same or related effect receipt.

A **retry key** is smaller than a warrant,
smaller than a receipt,
and more humane than telling the operator to guess whether pressing Apply again is safe.

## 5. Kubernetes finalizers keep proving that “delete requested” and “gone” are not the same state

Finalizers make deletion explicit and visible.
A deletion request sets `deletionTimestamp`,
but the object remains until the finalizers clear.
That is precisely the kind of honesty Helm should steal for stronger removal,
revoke,
retire,
or teardown acts.

A **teardown rail** should let Helm say:
- removal requested,
- cleanup blocked by these dependents,
- draining in progress,
- force path exists or does not,
- and final disappearance has not happened yet.

That is much better than a cliff-edge delete button,
and much better than a vague spinner that hides which cleanup conditions are still real.

## 6. What Helm should steal now

- **Change cursors** over mutable saved views,
  linked views,
  watched sources,
  and exact handles
- **Retry keys** beside warrants,
  effect receipts,
  and provider-facing stronger acts
- **Teardown rails** for remove / revoke / retire / detach / unpublish flows where completion can lag request time
- **Cursor expiry / unusable posture** rather than fake latestness
- **Duplicate-suppressed retry rows** in Operations instead of second-apply folklore
- **Pending-teardown rows with blocker lists** instead of silent limbo

## 7. What Helm should resist

- pretending a basis stamp is enough to resume change-watching forever
- retrying stronger acts without a visible same-act witness
- treating deletion request as proof of deletion completion
- stuffing all three problems into one giant workflow engine
- letting provider-specific transport weirdness leak straight into shell truth without shell-owned normalization

## Synthesis for Helm

Helm already has basis stamps,
watchpoints,
action warrants,
drift gates,
and effect receipts.
The next small honesty layer is:
- **change cursor** = what exact mutable point I last saw or can resume from
- **retry key** = this stronger act is the same intended effect,
  not a second unrelated attempt
- **teardown rail** = removal/revoke/retire requested,
  but not yet finished

That trio would make Helm's datacube calmer under real-world uncertainty:
stale mutable state,
transport retries,
and cleanup-before-disappearance.
