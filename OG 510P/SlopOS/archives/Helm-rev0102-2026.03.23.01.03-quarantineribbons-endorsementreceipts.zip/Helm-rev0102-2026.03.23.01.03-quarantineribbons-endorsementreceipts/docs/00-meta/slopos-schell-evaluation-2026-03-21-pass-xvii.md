# SlopOS + Schell evaluation — 2026-03-21 pass XVII

Purpose: continue evaluating SlopOS's datacube for Helm while staying disciplined about what is actually ready to freeze.

This pass focused on one question:

**what is the deepest product lesson in SlopOS's datacube right now, and can Helm import it without turning itself into a second SlopOS?**

## 1) The biggest datacube lesson is not “build a cube”

The strongest current SlopOS lesson is subtler than that.

The datacube keeps teaching that useful extra faces should be:

- bounded,
- typed,
- source-bound,
- explicit about materialization,
- and visibly weaker than the authoritative seam they project from.

That is what shows up in several places:

- **CH-SPROJ** is a bounded, deterministic, non-authoritative projection instead of a general dump surface.
- **D-NAMECERT projection** makes authority-bearing materialization explicit on the target seam and keeps source digest evidence visible.
- **OpenURI materialization** keeps launch from silently becoming durable local-object minting.

The shared law is clear:

**helpful derived views are good; silent second workflows and ambient second truth-domains are not.**

## 2) Helm now has enough pressure to freeze one shared law: projection surfaces

Helm already has a growing family of warm shell luxuries:

- command docks
- preview rails
- facet strips
- review strips
- sticky context strips
- live lenses
- cockpit cards
- exact trail cues

Until now those ideas mostly lived as separate temptations.
This pass says they actually belong under one shared discipline:

**projection surfaces are compact shell-owned projections over existing shell truth. They are not new authority domains.**

That feels mature enough to freeze.

## 3) Why freezing this now is useful instead of premature

This is one of the rare places where an early freeze reduces drift rather than adding doctrine.

Without a projection-surface law, Helm risks re-learning the same mistake in many places:

- docks that become second launchers,
- preview rails that become hidden open/import law,
- sticky strips that become dashboard substitutes,
- live lenses that start pretending independence,
- and cockpit cards that quietly become second truth surfaces.

A projection-surface posture does not decide all those products.
It just says what they are **not allowed** to become by accident.

That is a good kind of early freeze.

## 4) What this changes in Helm's pillar read

This pass does **not** change the pillar count.
It does **not** promote a new product family.
It does **not** make exact trails or trust ladders final.

It does change one thing:

Helm should now treat many of its best shell luxuries as members of a single cross-cutting family:

- bounded
- typed
- source-witnessed
- non-authoritative by default
- honest about degradation when source or basis goes away

That makes the pillars sharper without widening them.

## 5) Schell still matters — but mainly as a shell-facing caution and amplifier

Schell remains useful because it keeps pressuring:

- source grading,
- mode separation,
- command-boundary witnesses,
- and explicit shell-facing receipts.

But this pass still does **not** justify importing:

- a final shell ontology,
- a final retention constitution,
- or terminal-local worldview as shared desktop truth.

Schell helps Helm sharpen its shell-facing seams.
It still should not overrule Helm's desktop product spine.

## What this pass freezes

- a new cross-cutting posture doc: **projection surfaces are bounded and non-authoritative by default**
- an ADR capturing that freeze as a shared Helm law

## Warm ideas this pass strengthens without freezing

- exact trail / breadcrumb cues
- trust ladders / restricted-mode entry for untrusted imported material
- promotable quick keys for exact actions
- local-only versus synced acceleration boundaries for Recall/Exchange/seed surfaces

## Explicit non-takes in this pass

- do not turn projection surfaces into a general widget platform
- do not let projection surfaces carry hidden app-owned state machines the shell cannot inspect
- do not let projection surfaces silently materialize second workflows or stronger authority
- do not turn exact-trail warmth into a final continuity constitution before one compelling specimen exists
- do not copy SlopOS's architecture whole instead of translating its law into Helm's product shape

## Current bounded take

**Helm should keep seven pillars plus terminal/capshell as a native front-end family, and it should now explicitly freeze one cross-cutting law learned from SlopOS's datacube: compact shell luxuries should be projection surfaces over stronger shell truth, not new authority domains.**
