# Web research synthesis — 2026-03-22 pass XXVII

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on a narrower travel question:

**if Helm already has landing manifests, companion bundles, fit cards, and rebind ladders, what tiny reusable witness should say which exact basis a surface reflects, and what tiny witness should say what residue stayed behind?**

## 1) Figma and VS Code both keep rewarding explicit compare bases rather than vague sameness

Figma Dev Mode now makes compare-against-basis unusually legible.
Developers can compare a frame or component against prior versions,
compare instances with design overrides against the base component,
and inspect changes over version history.
VS Code checkpoints do something similar for AI-edited workspaces:
checkpoints create snapshots before chat requests,
and restoring a checkpoint returns the workspace to that earlier state.

That matters because it validates a smaller,
more reusable Helm witness than a full landing manifest:

**a basis stamp**.

A landing manifest can stay broad,
but many surfaces want one tiny answer to:
"what exact source/basis/revision does this thing reflect?"

That would help:

- deck recipes
- drift beacons
- derivation strips
- exact action keys
- promotion receipts
- receiver fit cards
- and future exported shell luxuries

## 2) VS Code Profiles and Workspace Trust keep proving that arrival should show contents, not bluff equivalence

VS Code Profiles are still especially relevant.
Exported profiles can be opened with the imported profile contents displayed,
and users can unselect profile elements before import.
Profiles can also be associated with a current folder or workspace.
At the same time,
Restricted Mode explicitly disables or limits AI agents,
tasks,
debugging,
workspace settings,
and extensions in untrusted workspaces.
Copilot CLI adds an adjacent lesson:
background sessions can use worktree isolation,
and those sessions can inherit the full conversation history and context from a local handoff.

The stealable law is:

**arrival should show carried structure and carried basis,
but stronger local meaning still depends on receiver trust,
receiver fit,
and explicit apply/rebind steps.**

This supports a basis-stamp move,
but it also sharpens the case for a separate residue witness:
users should be able to see not just what arrived,
but what stayed behind because it belonged to local trust,
local settings,
local extensions,
or local workspace state.

## 3) Raycast keeps validating explicit sync classes,
exact invocation handles,
and local leftovers that remain local on purpose

Raycast still gives Helm one of the clearest public honesty models.
Deeplinks can run enabled commands through exact `raycast://...` handles,
and `fallbackText` can pass initial data into a command.
But Cloud Sync is sharply selective:
it syncs aliases,
hotkeys,
quicklinks,
snippets,
notes,
extension settings,
and AI chats/presets/commands,
while intentionally leaving Clipboard History,
Script Commands,
Credentials and Passwords,
and General and Advanced Settings unsynced.
Shared Quicklinks reinforce the split again:
organization quicklinks are shared,
while personal quicklinks remain stored locally and not synced.

That is very strong support for a Helm **residue ledger**.
Not because Helm needs a giant diff,
but because a truthful shell should be able to say:

- this traveled,
- this was omitted,
- this remains local-only,
- and this must be re-earned or re-created on the receiver.

## 4) Obsidian,
Warp,
WezTerm,
and PowerToys keep proving that saveable structure and local residue are different classes

Obsidian's `.obsidian/workspace.json` and `.obsidian/workspaces.json` files store the current workspace layout,
update whenever you open a new file,
and may belong in `.gitignore`.
Warp Launch Configurations save windows,
tabs,
and panes,
and Warp's URI scheme can open new windows,
tabs,
or launch configurations directly.
WezTerm workspaces can exist without becoming visible until you switch to them.
PowerToys Dock bands are explicit pinned strips provided by extensions;
users can pin or unpin bands,
and nested commands can be pinned only if the extension exposes a resolver for those command ids.

These are all variants of one broader lesson:

**portable structure is real,
but so is mutable local residue.
The shell should tell the truth about both classes instead of pretending one silently implies the other.**

## 5) Strongest new warm moves from this pass

- **basis stamps** — compact shell-owned witnesses that say what exact source,
  revision,
  checkpoint,
  base component,
  or reviewed basis a portable or derived surface reflects
- **residue ledgers** — compact shell-owned witnesses that say what local-only,
  omitted,
  dropped,
  or re-earned residue did not travel with a surface and therefore cannot be mistaken for carried truth

## 6) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep landing manifests broad,
  but factor basis truth into a smaller reusable witness
- treat omitted local residue as first-class truth,
  not as embarrassing implementation leakage
- make travel and landing more truthful by naming both the carried basis and the non-carried residue

## Strongest non-takes from this pass

- do not add a pillar
- do not turn residue ledgers into giant sync diffs or machine inventories
- do not let a basis stamp impersonate current live continuity or receiver fit
- do not let shared quicklinks,
  profiles,
  launch configs,
  or decks count as active local presence by default
- do not turn current-tool export/import conveniences into a universal shell constitution
