# Web research synthesis — 2026-03-22 — pass XLII

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move under **activity spines** is a compact shell-owned **resource shelf** rather than another pillar or another workspace blob.

This pass focused on one question:

**what is the smallest truthful curation object Helm can ship for grouped resources, deep links, saved references, and shared entry structure without pretending that the group itself is live truth, portable authority, or ambient collaboration?**

## Main takeaway

The outside world is validating a very specific move:

**Helm likely wants shell-owned resource shelves.**

A resource shelf would be:
- a compact curated set
- explicit about member type
- deep-linkable by member
- preview-friendly
- shareable by rung
- weaker than live truth
- able to live inside an activity spine without becoming the activity spine

This is not the same thing as:
- a view deck
- a command dock
- a review ticket
- or the activity spine itself

It is a curated resource surface.
Not the lane.
Not the truth.
Not the sync myth.
