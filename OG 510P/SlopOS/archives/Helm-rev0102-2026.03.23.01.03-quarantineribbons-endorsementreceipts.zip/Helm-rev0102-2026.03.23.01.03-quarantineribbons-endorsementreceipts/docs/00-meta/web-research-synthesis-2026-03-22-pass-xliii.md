# Web research synthesis — 2026-03-22 — pass XLIII

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move is to sharpen **activity entry kits / front doors** on top of activity spines and resource shelves.

This pass focused on one question:

**what is the smallest truthful saved front door Helm can ship for scoped work so people can get back to the right activity quickly without pretending the saved starter is already the live lane?**

## Main takeaway

The outside world keeps converging on a familiar but still under-shaped Helm move:

**Helm likely wants a stronger activity entry kit / front-door object.**

Not a new pillar.
Not a giant workspace manager.
Not a flattering restore myth.

A good Helm entry kit would likely be:
- shell-owned
- scoped to one activity spine or equivalent work frame
- able to point at one preferred front door
- able to gather a few saved views, shelves, launch/layout starters, and checkpoint/restore relations
- explicit about whether it is only a starter, an imported recipe, a current-live reentry hint, or a historical return path
- weaker than live truth

## What the outside world is validating now

### 1. Scoped project bundles want one obvious front door

ChatGPT Projects, Linear Projects, Slack conversation tabs, and Dropbox Dash Stacks all validate the same humane move:
a bounded scope becomes much more usable when it has one obvious place to enter,
see the key resources,
and stay inside the right context fence.

### 2. Saved setup is valuable when it stays visibly weaker than live continuity

VS Code Profiles,
Warp Launch Configurations,
PowerToys Workspaces,
and Chrome saved tab groups all validate saveable starters.
But they are strongest when the user can still tell the difference between:
- a saved setup
- a reopen/relaunch
- and the actually current live thing

### 3. Attached views are more useful when they live near the project front door

Linear's project-attached views are especially interesting.
They act like tabs under the project,
can be reordered,
linked,
favorited,
and shared with others who already have access to the project.
That is a very strong precedent for Helm:
a front door should be able to point at one preferred view,
while still carrying nearby alternate views without becoming a dashboard blob.

### 4. Grouped resources and grouped starters should cooperate without collapsing into one object

Dropbox Dash Stacks,
Slack tabs/folders,
Google Docs tabs,
and Chrome saved tab groups all validate grouped resources or grouped entries.
That suggests Helm should keep a cleaner split:
- activity spine for the scoped work frame
- resource shelf for curated grouped resources
- activity entry kit for the saved front door / starter
- current-live beacon for the actual live reentry cue

## Judgment for Helm

Helm should still not add a pillar.

But one older candidate now looks worth sharpening again:

**activity entry kits / front doors** — shell-owned saved starters that can point into one scoped activity,
carry one preferred front door plus nearby saved views/resources/starters,
and make attach/restore/relaunch/fresh-start choices explicit without pretending the starter itself is already live truth.
