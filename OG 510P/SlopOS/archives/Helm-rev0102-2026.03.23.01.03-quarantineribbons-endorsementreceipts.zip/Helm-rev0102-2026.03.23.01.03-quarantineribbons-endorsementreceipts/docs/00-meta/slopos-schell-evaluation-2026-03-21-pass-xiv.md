# SlopOS + Schell evaluation — 2026-03-21 — pass XIV

Purpose: keep using SlopOS and Schell as design teachers while Helm keeps collecting ideas without prematurely freezing them into constitutional law.

This pass focuses on a narrower question than pass XIII:

**which newer SlopOS seams most strongly shape Helm's pillar wording, and which newer Schell pressures are best imported as warm cross-pillar moves rather than hard freezes?**

## What SlopOS is teaching especially clearly right now

### 1. Request artifacts and live state are different truths

The newer SlopOS request-state posture docs for jobs and background work keep making the same point in different domains:
- a stable request key is valuable,
- a historical reviewed request is valuable,
- but neither one is the same thing as current scheduler-owned or portal-owned live state.

That matters for Helm everywhere:
- **Operations Center** should explicitly separate request, admitted, live, completed, denied, expired, disabled, and historical states
- **Recall** should not mistake a remembered request or old receipt for current live continuity
- **Omnibox** should not present saved entry objects as though they already prove current live attachment

### 2. Approval basis exactness should keep shaping stronger actions

SlopOS's approval-basis posture is still one of the strongest imports available.
It keeps saying that one exact reviewed basis matters more than nearby freshness glow.
That continues to justify Helm's reviewed-basis truth and basis-packet pressure.
It also strengthens the case for tiny preflight surfaces such as review strips and launch ladders.

### 3. Generic launch still should not become placement or reuse authority

The OpenURI launch-disposition boundary remains a very strong teacher.
Generic launch is admission of launch, not portable truth about new tab, reuse window, new instance, task placement, or equivalent folklore.

That should continue to sharpen Helm like this:
- **Tiling Shell** owns spatial placement truth
- **Omnibox** can route and present ladders but should keep generic launch humble
- **Recall** should distinguish attach, reuse, repaired return, historical replay, and fresh launch instead of blurring them together

### 4. Exact reveal should fail closed, not flatter the user

The OpenURI show-item exactness boundary remains one of the best imports into Helm.
If the exact reveal/select promise cannot be met, the honest answer is denial or unsupported — not “something nearby happened.”

That pressure still lands hardest on:
- **Object Browser**
- **Recall**
- **Exchange**
- and secondarily **Operations Center**, because the failure should remain visible later

### 5. Activation/focus law belongs to the shell/compositor

The OpenURI activation-control boundary keeps reinforcing that requesters do not own foregrounding truth.
That is important because Helm's Tiling Shell can otherwise collapse into mere geometry.
The lesson remains:
- focus and activation are shell/compositor law,
- not a side effect the requester gets to narrate as success.

## What Schell is teaching without forcing Helm to freeze too much

### 1. Distinct lanes and source grades matter more than giant universal history

Schell's newer work on authorship badges, basis packets, agent modality, and retention/forget rails keeps pointing toward the same lesson:
source grades matter.
Helm should keep borrowing that lesson for **Recall**, **Operations Center**, and terminal/capshell without turning every shell-local distinction into a global desktop constitution too early.

### 2. Execution ground and context anchors are worth importing as shell moves

Schell's execution-ground and witness work keeps suggesting that operators need tiny answer surfaces for:
- what ground this action would run on,
- what source lane produced this object,
- and what long-lived output/result this visible region belongs to.

Helm does not need Schell's full final rendering to benefit from that pressure.
This is where **sticky context strips** and stronger source labels start to look worthwhile.

### 3. Forget rails are a warning, not yet a Helm pillar driver

Schell's retention and forgetting work is excellent, but for Helm it currently reads more like a design warning than a pillar-shaping law.
The warning is simple:
- shell memory has multiple planes,
- clear-screen is not clear-memory,
- private future suppression is not retroactive deletion,
- and historical residue should not masquerade as live continuity.

Helm should absorb the warning, especially for Recall and Operations Center, without yet importing a giant retention constitution.

## What this changes in Helm's pillar read

### Tiling Shell
Needs to stay explicitly responsible for placement, focus, activation, and shell-owned visibility truth — not just layout transforms.

### Omnibox
Needs to get better at:
- honest launch ladders,
- review strips,
- typed provider status/progress,
- and exact object/action routing
without drifting into generic placement folklore.

### Object Browser
Needs to get stronger around:
- preview-adjacent bounded actions,
- exact reveal/select,
- query-first browsing,
- and source-visible previews.

### Operations Center
Needs to be the main daily surface for:
- request truth versus live truth,
- host-owned progress and hold state,
- background/delegated presence,
- and anchored context for long-running operations.

### Desktop Flow
Needs reusable fragments, visible status, and anchored context so flow execution is inspectable instead of merely drawable.

### Recall
Needs stronger exact-object recency, source labels, and honest launch ladders rather than a flattering recent-items bucket.

### Exchange
Still looks stronger every time SlopOS sharpens route and exactness law.
Exchange should keep typed ingress, typed route witnesses, and exact subject posture visible.

## New cross-pillar moves this pass thinks are worth recording

### 1. Launch ladders
Small shell-owned ladders that keep fresh launch, attach, reuse, repaired return, historical replay, and hold visibly distinct.

### 2. Sticky context strips
Small shell-owned anchor strips/cards that say what long-lived output, receipt, status lane, or view belongs to which subject/action/source.

### 3. Host-owned status/progress rows
A shell-owned way for Omnibox, Operations Center, and Desktop Flow to show provider or fragment progress without letting providers become hidden mini-apps.

These moves look worth carrying forward, but only **launch ladders** and **sticky context strips** feel concrete enough to record as explicit candidate contracts in Helm right now.

## Pass-XIV bounded take

The best take in this pass is:

- keep learning from SlopOS's request-state humility, exact reveal, activation/focus law, launch humility, and reviewed-basis discipline,
- keep learning from Schell's source grading, execution-ground witnesses, and retention humility,
- flesh out Helm's pillars rather than adding more,
- record **launch ladders** and **sticky context strips** as new candidate shell moves,
- and keep refusing giant continuity theater, generic placement folklore, provider mini-app sprawl, and terminal-local history pretending to be universal desktop truth
