# Web research synthesis — 2026-03-21 pass XXXII

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on the next truthful-landing question:

**if Helm already has landing rehearsals, arrival overlays, adoption slices, surface core digests, and default-fill receipts, how should it expose bounded rebinding choices and how should it remember the per-slot outcomes of selective acceptance?**

## 1) Current tools keep rewarding explicit compare surfaces before any durable accept step

VS Code Profiles keeps reinforcing that imported or switched structure should be previewed before it becomes your live working posture.
You can open a new window with a specific profile,
and the drag-and-drop import flow opens the Profiles editor so you can preview and import the incoming `.code-profile` rather than silently absorbing it.
That is a strong public signal that arrival deserves a weaker compareable mode before adoption.

Figma reinforces the same lesson from the design-review side.
Branch review exposes a summary of the branch,
a list of changed objects grouped by page,
and then lets reviewers inspect each change side by side or as an overlay before approval/merge.
Library updates teach an even more selective version of the same pattern:
review one changed instance at a time,
then either update that instance or update all.

That combination suggests Helm should get more explicit about two different compare/accept surfaces:
- one surface for the **bounded candidate set** when exact rebinding is not yet resolved
- one durable surface for the **slotwise verdicts** that selective acceptance produced

## 2) Explicit selection surfaces beat hidden winner-picking

WezTerm's `InputSelector` is tiny but instructive:
it activates an overlay that displays a list of choices for the user to select from,
and the action happens only when one line is explicitly accepted.
PowerToys' new Command Palette Dock tells a similar story from a persistent shell surface:
commands are pinned explicitly into Start,
Center,
and End regions rather than inferred from ambient “most likely” state.

SlopOS has been teaching this more rigorously than most public tools.
The namecert selection boundary is set-valued and refuses hidden winner rules.
The projection boundary insists that evaluation and materialization are separate,
and that any live result must land as an explicit slot mutation with exact provenance.
That is a very strong teacher for Helm.
When a carried surface lands on a receiver and more than one plausible local target exists,
Helm should prefer a bounded explicit choice set over “closest match” folklore.

That makes one new Helm move feel earned:
**arrival choice sets**.
A fit card should be able to say not only “this did not exact-bind,”
but also “here are the bounded admissible candidates,
what basis each candidate corresponds to,
and what extra work or loss each choice would imply.”

## 3) Selective acceptance needs a durable per-slot memory

The other outside lesson is that partial acceptance quickly becomes muddy if the system cannot say which parts were actually accepted.
Figma's library-update flow makes this visible by letting you update one instance or update all.
VS Code's profile model keeps separate the imported profile,
the Default Profile,
user/workspace scope,
and the specific resulting environment.
Obsidian Bases also reinforces a useful split:
views are first-class saved structures,
but mutable local workspace layout remains separate local residue.

That implies Helm should stop treating selective adoption as a one-off gesture and start leaving a compact durable truth table behind.
If you accept some slots,
rebind some,
default-fill some,
and refuse some,
that result should remain inspectable later without re-reading the whole landing scene.

That makes a second Helm move feel earned:
**slot verdict ledgers**.
These would record,
for each carried slot or class,
whether the receiver accepted it,
rebound it,
default-filled it,
left it pending,
or refused it.
They would be the durable sibling of adoption slices.

## 4) Strongest new warm moves from this pass

- **arrival choice sets** — bounded explicit candidate sets for landing/rebinding when exact local targets are not already known,
  with exact-basis witness per candidate and no hidden winner rule
- **slot verdict ledgers** — compact durable per-slot outcome surfaces for selective acceptance,
  rebound targets,
  default fills,
  pending gaps,
  and refusals

## 5) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- keep compare weaker than accept,
  and accept weaker than full adoption
- keep choice sets explicit when exact rebinding is absent
- keep partial outcomes durable and inspectable after the landing moment has passed
- keep hidden winner-picking out of Helm

## Strongest non-takes from this pass

- do not add a pillar
- do not let a near match silently become the winner
- do not let selective adoption collapse into one vague “mostly imported” state
- do not build a giant merge constitution before one narrow specimen exists
- do not turn compare surfaces into ambient live-state truth
