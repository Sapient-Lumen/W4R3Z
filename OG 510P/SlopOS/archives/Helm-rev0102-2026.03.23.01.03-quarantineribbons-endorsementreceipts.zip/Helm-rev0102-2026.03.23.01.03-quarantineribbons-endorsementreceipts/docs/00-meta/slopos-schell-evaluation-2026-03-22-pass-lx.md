# SlopOS + Schell evaluation — 2026-03-22 — pass LX

Purpose: keep translating the current SlopOS and Schell archive pressure into bounded Helm moves rather than ambient import pressure.

## Main reading this pass

SlopOS keeps teaching the same datacube lesson in sharper form:
- saved query / smart-folder persistence should stay **shell-owned**,
- query execution should stay **view-scoped**,
- results should stay **handle-returning**,
- live behavior should stay **optional and bounded**,
- and replicated summaries should stay **read-only and non-activating** until an explicit local step happens.

That means Helm should treat any curated investigation object as:
- a **derived shell object**,
- bound to exact source refs,
- clearly weaker than the stronger source views / receipts / watchpoints it gathers,
- and never an ambient new authority plane.

## 1. The key SlopOS lesson: persistence belongs to the shell, not the query client

SlopOS's attr/query posture keeps saved-query persistence shell-owned and refuses an app-visible ambient saved-query inventory.
That matters for Helm because an evidence brief should be:
- shell-owned,
- inspectable,
- publication-rung aware,
- and composable with Recall/Exchange/Operations,
not just hidden notebook state inside one app.

## 2. The key SlopOS lesson: derivative summaries must not replace source truth

SlopOS keeps separating:
- source object,
- derived artifact,
- and the surface that renders or routes them.

That is exactly the right discipline for Helm evidence briefs.
A brief may gather:
- a saved view,
- a watchpoint,
- a receipt,
- and a compare ticket,

but it should still point back to those stronger source objects instead of swallowing them into one flattering blob.

## 3. The key SlopOS lesson: replicated or imported summaries should not auto-activate locally

SlopOS's view replication boundary keeps read-only summaries from auto-attaching or becoming active local view truth.
That matters because shared/imported evidence briefs should also arrive weaker:
- inspectable,
- maybe materializable,
- maybe adoptable,
- but not silently live.

## 4. Schell pressure still says “keep shell-facing curation exact and inspectable”

Schell is still immature enough that Helm should not let shell-facing curation turn into a huge execution or restore constitution.
But it already reinforces one useful thing:
when a shell-facing object mixes action,
explanation,
and history,
it should still preserve exact witnesses and honest authorship.

That fits evidence briefs well,
especially if Helm later allows machine-assisted summary,
recommended next steps,
or structured follow-up paths.

## Judgment

The next durable Helm lesson from SlopOS's datacube is:
**curation should become a first-class derived shell object, but it must stay shell-owned, exact-ref-based, weaker than source truth, and non-activating until an explicit local step says otherwise.**

That is why evidence briefs now look worth warming.
