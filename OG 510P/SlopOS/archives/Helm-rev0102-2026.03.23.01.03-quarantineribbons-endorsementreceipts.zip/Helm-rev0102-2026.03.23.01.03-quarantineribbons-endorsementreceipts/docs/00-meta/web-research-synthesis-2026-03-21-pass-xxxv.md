# Web research synthesis — 2026-03-21 — pass XXXV

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on one practical question:

**what current products are proving that saved views, saved layouts, previews, forks, and publication need to be first-class objects rather than folklore?**

## Main takeaway

The outside world is converging on a surprisingly consistent pattern:

1. **views are becoming first-class objects**
2. **branch / restore / fork is becoming a normal user move**
3. **shared and personal accelerators are being split explicitly**
4. **preview is becoming promotion-adjacent instead of tooltip-only**
5. **saved layouts are becoming portable structure, not live continuity**

That is extremely good news for Helm.
It suggests the next “super awesome” gains are not extra pillars.
They are better shell-owned objects and better truth around those objects.

## Strongest outside pressure

### 1. Notion now validates first-class views and multi-view dashboards as real objects

Notion's current API treats views as first-class resources with their own types,
filters,
sorts,
and layout configuration,
and it now supports dashboard views that arrange multiple widget views in a grid.
It also lets integrations query a view directly and paginate against a stable cached result set.

The stealable law is not “copy Notion databases.”
It is:

- a saved view should be a real shell object,
- one subject can legitimately have many views,
- dashboard/deck layouts can be truthful if their view provenance stays visible,
- and query results should sometimes be frozen long enough for stable review / paging instead of shifting under the operator.

That strongly pressures Helm toward:
- stronger **view decks**,
- stronger **deck recipes**,
- and probably a clearer distinction between **view object**, **query result slice**, and **live subject**.

### 2. Airtable keeps validating explicit share / sync / publish ladders over one underlying view

Airtable's view-share menu is unusually revealing because one view can be:
- link-shared,
- sync-enabled,
- published to a data library,
- or turned into a form,
all from one explicit “Share and sync” surface.

That is very close to what Helm wants.
The shell lesson is:

**the same underlying shell surface may cross locality tiers in several different strengths,
and those strengths should be chosen explicitly rather than hidden behind background sync.**

That reinforces:
- publication ladders,
- promotion receipts,
- lineage modes,
- and residue-aware cross-tier truth.

### 3. VS Code keeps proving that fork / checkpoint / profile / trust should be normal user-facing moves

VS Code is now unusually strong across several seams at once:
- profiles can be created with chosen included contents,
- user settings and workspace settings stay distinct,
- Workspace Trust keeps untrusted code in Restricted Mode until explicit approval,
- chat sessions can be forked while inheriting prior conversation history,
- and checkpoints can restore a workspace to an earlier state.

Taken together,
that is one of the clearest public validations for Helm's developing grammar:
- same lineage versus fork,
- exact reviewed basis,
- explicit trust posture,
- and saved setup that is neither fake continuity nor ambient global state.

Helm should steal this aggressively for:
- Recall,
- Desktop Flow,
- saved view / deck materialization,
- and task-return slices.

### 4. Obsidian keeps proving that local-first data and view-layer composition are different planes

Obsidian now has Bases for database-like views,
Workspaces for task-specific layouts,
and still keeps notes as local Markdown files in a vault.
That combination is unusually healthy.

The stealable law is:
- substrate,
- saved views,
- and saved layout
should not collapse into one thing.

For Helm this suggests:
- the shell should preserve durable object truth below the view layer,
- query/view objects should remain inspectable objects in their own right,
- and layout/workspace residue should remain obviously more local and more disposable than the underlying objects and view definitions.

### 5. Raycast keeps proving that personal versus shared accelerators should split cleanly

Raycast Cloud Sync syncs many classes across a user's Macs,
and Shared Quicklinks propagate across organization members.
That is a powerful pair of lessons:
- some accelerators are personal,
- some are shared,
- and the system gets more legible when it says which is which.

Helm should steal that for:
- exact action keys,
- command docks,
- deck recipes,
- and other shell accelerators.

This is likely more important than it first appears,
because it gives Exchange and Recall a cleaner story about which handles are:
- local,
- personal-cross-device,
- team-shared,
- portable,
- or published.

### 6. PowerToys proves that tiny persistent edge surfaces can stay extension-grade and still feel native

PowerToys Command Palette Dock is now a persistent edge toolbar,
and the extension model explicitly supports dock bands and pinning nested commands.

That is a near-perfect validation for Helm's command-dock direction.
The stealable law is not “copy this toolbar.”
It is:

- shell-owned tiny persistent surfaces can be first-class,
- extensions/providers can contribute to them without owning the shell,
- and nested command ids can still be pinnable if the host keeps identity and law.

Helm should keep pushing command docks,
but with stronger witness around source,
authority grade,
and locality tier.

### 7. Warp and WezTerm keep validating saveable session structures plus searchable live session navigation

Warp now has launch configurations,
session navigation,
and session restoration.
WezTerm's launch menu continues to validate inspectable spawn entries.

That strongly supports the idea that Helm should distinguish:
- launchable structure,
- live current state,
- and searchable active session/task presence.

That pressure lands directly on:
- Tiling Shell,
- Recall,
- Operations Center,
- and Desktop Flow.

### 8. Spotlight, Quick Look, and Arc Peek validate preview that can promote into stronger surfaces

Apple's Spotlight now supports action-focused search with assignable quick keys,
Quick Look remains a strong preview surface,
and Arc Peek can promote into a new tab or Split View.

The combined lesson is excellent:
- preview can be lightweight,
- action-adjacent,
- and promotable,
without pretending preview already equals open/adopt/live.

Helm should keep stealing this for:
- Omnibox,
- Object Browser,
- Recall,
- and command-dock-adjacent shells.

## Best ideas to steal now

### Pull the trigger soon

1. **First-class view objects with inspectable layout/configuration**
   - The market is validating this hard.
   - Helm should make saved view objects and deck-like layouts feel native,
     not accidental.

2. **Checkpoint / fork / restore as ordinary Recall and Flow powers**
   - This now looks mature enough to start proving with one narrow specimen.
   - The key is to keep basis and lineage explicit.

3. **Explicit personal / shared / published ladders for shell accelerators**
   - This is a big legibility gain for exact action keys,
     dock items,
     deck recipes,
     and exchange objects.

4. **Command docks as persistent native shell edges**
   - The outside evidence is now strong enough that this feels more like a product move than a curiosity.

### Keep warm but do not freeze yet

- stable query-result slices or query tickets for long compare/review flows
- richer dashboard/deck widget placement law
- adaptive workspace/setup generation from higher-level starters
- stronger per-slot carry/reset stories for deck or view duplication

### Resist

- one giant universal workspace mythology
- ambient sync that hides scope changes
- silent “same thing” language for copied or imported shells
- preview surfaces that quietly do strong acts
- dashboards that pretend to be authoritative rather than derived

## Pillar pressure from this pass

- **Tiling Shell** wants command docks,
  saveable layouts,
  and Peek-to-split style promotion.
- **Omnibox** wants action-first quick keys,
  provider pivots,
  and stable result identities.
- **Object Browser** wants first-class views,
  dashboard/deck composition,
  and Quick Look-grade preview.
- **Operations Center** wants searchable live sessions,
  trust posture,
  and checkpoint/restore/fork explanation.
- **Desktop Flow** wants branchable history,
  reusable saved structures,
  and inspectable materialization.
- **Recall** wants basis-aware checkpoints,
  forks,
  exact recency,
  and route/source grade.
- **Exchange** wants publication ladders,
  personal/shared/public tiers,
  and clear lineage-versus-copy truth.

## Judgment for this pass

Do not add a pillar.
Do start treating **saved views, checkpoint forks, publication ladders, and personal-vs-shared accelerators** as the most promising next wave of Helm magic.

Those moves make Helm feel richer **because they clarify truth**,
not because they hide it.
