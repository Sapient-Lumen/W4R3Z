
# Web research synthesis — 2026-03-21 — pass VII

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass focuses on one sharper question:
**once a modern tool saves task shape, how does it stay honest about reuse, rebinding, and current live state?**

The answer from current tools is consistent:
great systems increasingly admit that reconstructed state is not the same thing as current live state,
but most of them still stop short of giving a beautiful explicit witness for the join.

That points Helm toward two outcomes:
- freeze **non-exact binding / reuse witness posture** narrowly,
- and add **binding witness cards** as a candidate move.

## Cluster 1 — saved workspace tools are useful precisely because they admit reconstruction

### What current systems teach

PowerToys Workspaces is unusually revealing.
It lets users capture desktop state, add per-app CLI arguments, launch a saved workspace, and shows per-app launch statuses such as launched, in-progress, and failed.
It also exposes that existing-window reuse is app-dependent: some apps reposition an existing instance, some open a new one, and some are single-instance only.
It even documents that it cannot launch an app directly into its final position; it launches first and then moves/resizes the window.

FancyZones remains useful as a custom layout engine, but it preserves layout shape rather than task identity.
Obsidian Workspaces also keeps the core appetite visible: users want named task-shaped layouts and quick switching among them.

### What Helm should steal

Helm should absolutely keep stealing:
- named task-entry artifacts,
- explicit per-target launch/bind status,
- quick switching,
- editable saved setup,
- and visible reuse-versus-fresh-launch posture.

But the most important thing to steal is the honesty.
The best cue in current workspace tools is that they admit reconstruction is happening.

### What Helm should refuse

- CLI-arg folklore as the main continuity substrate
- geometry-first layout stories that quietly stand in for activity truth
- hidden existing-window reuse
- post-launch “window jumps” as acceptable shell truth rather than a repair path the shell should witness clearly

## Cluster 2 — summon surfaces are now rich enough to host continuity witnesses

### What current systems teach

PowerToys Command Palette now explicitly supports list pages, detail pages, form pages, markdown pages, and grid pages.
That matters because structured summon surfaces can now carry more than rows.
They can carry context, badges, next actions, and typed fields.

### What Helm should steal

Helm should keep investing in typed cards that can live inside Omnibox and nearby shell surfaces.
Binding witness cards fit naturally into this trend.
The shell no longer needs to choose between a tiny launcher row and a giant dedicated app.

### What Helm should refuse

- an app-within-app card platform with provider-local law
- rich cards that hide where their evidence came from
- pretty witness cards that collapse exact, repaired, ambiguous, and unavailable states into one flattering visual bucket

## Cluster 3 — unified session/status views are becoming table stakes

### What current systems teach

VS Code's current agent/session work keeps moving toward one unified place to see sessions, their status, type, and file changes.
Cloud agents can be handed off from local or background conversations, and the session can then be tracked from the same chat surface.
Recent releases also added session logs and an Agent Debug panel showing events, tool calls, and loaded customizations.

### What Helm should steal

Helm should keep stealing:
- one shell-owned place to see live task/session status,
- recent receipts and file-change-like summaries,
- explicit handoff / continue / delegate pathways,
- and drill-down logs when a continuation or repair story becomes important.

This strengthens both Operations Center and future cockpit/witness surfaces.

### What Helm should refuse

- a separate “AI/session mission control” worldview disconnected from the shell graph
- background magic without surfaced status
- handoff or delegation that becomes a new ambient authority plane

## Cluster 4 — overview remains powerful when search, space, and action stay unified

### What current systems teach

GNOME still shows why overview is hard to beat when it is simple:
the Activities overview exposes live window thumbnails, lets users start typing to search immediately, and supports dragging apps or windows to workspaces.

### What Helm should steal

Helm should keep Overview on the candidate list as Omnibox's spatial companion.
The winning ingredients remain:
- live window glanceability,
- instant typing-to-search,
- workspace manipulation,
- and direct drag or keyboard action from the same shell-owned space.

### What Helm should refuse

- overview as mouse-only theater
- overview as a parallel command model unrelated to Omnibox
- overview that treats saved artifacts and live activities as visually interchangeable

## Cluster 5 — tiny accelerators matter most when they are composable and inspectable

### What current systems teach

Raycast keeps demonstrating the appetite for tiny accelerators:
Quicklinks can open URLs, project folders, IDEs, or search targets directly from root search.
Snippets can auto-expand with a keyword.
Dynamic placeholders can inject clipboard content, referenced snippets, cursor position, date/time, arguments, and browser-tab data, with modifiers and context-specific formatting.

### What Helm should steal

Helm should keep its typed-seed direction alive.
Small personal accelerators are clearly valuable.
But the better lesson is to keep them typed, source-labeled, and composable with stronger shell routes instead of making raw macro text the primary desktop substrate.

### What Helm should refuse

- ambient text expansion as the default desktop control plane
- placeholders that silently widen what the shell knows or can act on
- quicklink convenience that outruns route truth

## Cluster 6 — inspect/debug sidebars are still one of the cheapest honesty multipliers

### What current systems teach

Node-RED's sidebar stack is still a good reminder that graph power needs support machinery.
The Information sidebar gives an outline view, current-selection details, and reveal actions.
The Debug sidebar filters messages, scopes them by node or current flow, and keeps the debugging surface close to the working graph.

### What Helm should steal

Helm should keep favoring:
- sidebars or sidepanes for explainability,
- reveal/backlink actions,
- filtered recent evidence views,
- and debug or witness surfaces that are close to the operator's current locus of work.

Binding witness cards will likely be stronger if they can expand into a filtered evidence pane rather than trying to contain the entire proof story inside one tiny chip row.

### What Helm should refuse

- graph luxury without inspection tools
- witness surfaces that cannot reveal the underlying evidence path
- giant audit prose when one small filtered pane would do

## What now looks worth doing in Helm

### Worth freezing now

- **non-exact binding / reuse witness posture**

Why now:
- current tools prove that saved setup and reuse are already mainstream expectations,
- Helm now has enough saved-entry and continuity surfaces that silent rebinding would spread quickly,
- and the freeze can stay narrow: it only says non-exact joins must stay witnessable.

### Worth adding as candidate pressure now

- **binding witness cards**

Why this now looks strong:
- Command Palette-style rich cards can host them,
- Workspaces-style launch status makes their value concrete,
- VS Code-style session/status/log surfaces show the right neighboring machinery,
- and GNOME / Raycast / Node-RED all reinforce that quick action gets much better when it stays inspectable.

## Current bounded take

Helm should likely become better than current workspace and launcher tools in one specific way:

**when it reuses, repairs, or rebinds saved task-entry structure against live shell truth, it should show the join beautifully instead of hiding it.**
