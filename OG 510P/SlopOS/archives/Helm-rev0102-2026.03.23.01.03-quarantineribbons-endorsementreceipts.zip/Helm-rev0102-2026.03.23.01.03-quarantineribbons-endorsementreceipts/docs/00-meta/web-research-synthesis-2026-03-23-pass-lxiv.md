# Web research synthesis — 2026-03-23 — pass LXIV

Question: after attention windows, what small durable object or cross-cutting move still looks missing for Helm's datacube?

Answer from this pass: **portable travel with honest landing**.
The strongest pair is now **handoff packets** plus **receiver-fit cards**.

## What current tools keep teaching

### 1. Travel usually has a dedicated seam

Modern products keep refusing the fantasy that portability is just accidental residue.
They use explicit export/import,
explicit shared objects,
or explicit continuation features.
That matters because Helm has started to accumulate shell luxuries worth carrying:
front-door handles,
entry kits,
view decks,
response kits,
briefs,
and related saved/derived shell objects.

### 2. Export is not identical to import

VS Code Profiles is especially clear here.
Profiles can be exported to a GitHub gist or local file,
then imported through a dedicated import flow that opens the profile creation form,
lets the operator continue to modify contents,
and only then creates the imported profile.
Even the web-opened gist path can require manual extension installation.
That is a strong pattern for Helm:
**packet travel should preserve inspectability and partial adoption instead of pretending arrival equals activation.**

### 3. Shared objects can stay explicit about locality

Raycast Quicklinks also splits local and shared well.
Personal quicklinks are stored locally and not synced,
while organization shared quicklinks are synced for org members.
That is a useful Helm lesson:
**travel tier and sync scope belong in the object posture, not in hidden lore.**

### 4. Context can travel without universal truth traveling

Grafana dashboard and panel links can include the current time range and current template-variable values so the receiver lands in relevant context.
But that still depends on the target side having matching templates and expected context.
This is exactly the right shape for Helm packets:
carry context when useful,
but do not pretend the receiver automatically has every matching binding.

### 5. Continuation features are often narrower than they first appear

Apple Handoff is very useful,
but it works only for nearby devices with Bluetooth and Wi-Fi on and signed in to the same Apple Account.
That means even a polished continuity feature is still a **bounded continuity lane** with explicit eligibility assumptions,
not a universal portability model.
Helm should steal the usefulness,
not the universal-seamless illusion.

### 6. Credential portability proves that sensitive travel deserves its own object family

FIDO's credential-exchange specs define dedicated formats/protocols for securely moving credentials,
and Apple now exposes dedicated credential export/import managers for exchanging passwords and passkeys with other apps.
That is powerful evidence for a Helm principle:
**if travel matters, give it a first-class seam.**
Do not smuggle it through unrelated objects and hope the user infers the rest.

## What Helm should steal

- explicit packetization for travel-worthy shell luxuries
- clear local vs shared vs published posture
- inspect-before-import / inspect-before-create landing flows
- packet-carried context such as exact source witness, basis witness, time range, or narrow variable state
- explicit receiver-fit surfaces naming what matched, what was omitted, and what still needs a choice
- explicit refusal / inspect-only posture when a good landing is unavailable

## What Helm should not steal

- ambient sync mythology
- receiver-side auto-activation
- “same as before” wording when local bindings are still unresolved
- silent account/provider/profile choice on landing
- travel formats that quietly become permissions or current-live truth

## Why this matters to the pillars

This is not a new pillar.
It is a cross-cutting support proof that helps multiple pillars:

- **Tiling Shell / Desktop Flow** can carry layout or starter luxuries honestly
- **Omnibox / Object Browser** can hand off saved views and exact handles honestly
- **Operations Center** can share briefs, kits, and watch-adjacent entry surfaces honestly
- **Recall** can reopen packet travel as packet travel rather than as fake current-live continuity
- **Exchange** becomes materially stronger because typed travel now has a bounded landing witness

## Judgment

The next small durable proof worth warming is **handoff packets plus receiver-fit cards**.
That is a better next move than another giant dashboard, giant sync story, or giant workspace layer.
