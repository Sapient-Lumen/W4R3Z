# SlopOS / Schell evaluation — 2026-03-21 pass XXIX

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on one sharper seam:

**if Helm already has carried witness,
fit,
rebind,
and omission law,
what protects receiver truth between arrival and adoption,
and what prevents “close enough” rebinding from laundering itself into exact success?**

## 1) SlopOS keeps rewarding exactness over helpful approximation

The clearest local teacher in this pass was `openuri-showitem-exactness-boundary-v0.md`.
That doc freezes the rule that “show this exact item” must stay exact reveal/select.
If a backend cannot do that faithfully,
it fails closed rather than opening the parent directory and pretending that was the same thing.

That is an excellent Helm lesson.
When a landed shell surface expects one exact repo,
subject,
provider,
profile,
or route target,
Helm should not silently bind a merely similar local target and then call that ordinary success.
It should surface the candidate as **nearby**,
not as **the same**.

This is exactly the right local teacher for a Helm **near-match fence**.

## 2) SlopOS also keeps separating reviewed basis from mutable head-following

The approval-basis posture in SlopOS keeps teaching the same anti-laundering lesson on a different seam.
Approval binds one exact action and one exact mutable basis witness.
It does not silently follow whatever the current head or current queue item became later.

Helm should import that posture into travel and landing too.
A portable/saved/derived shell surface may arrive with carried basis,
carried slots,
and omissions.
But that does not entitle it to silently snap onto the receiver's newest vaguely-compatible target.
If the receiver wants to adopt a nearby substitute,
that choice deserves inspection and authorship.

## 3) The missing middle is rehearsal on the receiver,
not immediate adoption

SlopOS repeatedly rejects ambient activation.
Descriptors are not current live state.
OpenURI is not materialization.
Request acceptance is not completion.
Historical artifacts do not become live truth just because they are convenient.

The Helm import here is not “more import steps.”
It is one more honest weaker state:
**landing rehearsal**.

A landing rehearsal would let a receiver:

- render or stage a portable surface locally,
- inspect anchor-map satisfaction and omissions,
- view near matches without adopting them,
- and only then adopt,
  rebind,
  or refuse.

That feels much closer to the SlopOS spirit than instant activation,
but much friendlier than a giant bureaucracy.

## 4) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- landing manifests,
  anchor maps,
  residue ledgers,
  fit cards,
  and rebind ladders still look right
- add **landing rehearsals** so receivers can try here before calling it here
- add **near-match fences** so similar local candidates stay visible but weaker than exact success

## 5) What still does not seem worth taking

- not a universal datacube UI
- not giant auto-healing rebinding
- not straight-through import that bypasses review,
  fit,
  or authorship
- not “best effort” success language for exact targets
- not new pillars

## 6) Current judgment

The most important lesson from this pass is:

**Helm gets smarter by adding one more honest weaker state before adoption,
and by refusing to let approximation masquerade as exactness.**

That feels strong enough for new candidate contracts,
and still not strong enough for a new pillar or a new freeze.
