# Web research synthesis — 2026-03-22 — pass LXIII

Question for this pass:
what cross-cutting shell object is still missing after view subscriptions, watchpoints, timeline markers, evidence briefs, and response kits?

## Main answer

The strongest new pressure is **attention windows**.

The best external systems keep separating:
- source query/view,
- evaluated alert/watch state,
- notification delivery,
- and scheduled quieting / maintenance posture.

Helm still had source objects, state objects, revisit objects, evidence objects, guided-response objects, and time/change witness objects.
What it lacked was a clean shell-owned object for:
**when interruption is allowed, when it is quiet, when it is digest-only, and when a narrow critical rung applies — without implying recovery.**

## 1. Grafana teaches the strongest base split

Grafana now has one of the clearest official separations:
- **mute timings** for recurring quiet periods,
- **active time intervals** for “only deliver during these periods,”
- and **silences** for label-matched temporary suppression.

Most importantly,
Grafana says these mechanisms:
- do not prevent alert evaluation,
- do not stop alert instances from appearing in the UI,
- and only prevent notifications from being created.

That maps almost perfectly onto Helm's honesty goals.
Helm should steal the split,
not the whole alertmanager worldview.

## 2. Datadog teaches scoping and preview

Datadog downtimes are useful not because “mute” is novel,
but because the product lets users:
- choose what to silence,
- scope by monitor name, monitor tags, and group scope,
- and preview affected monitors before committing broad silence.

That is exactly the kind of witness Helm needs.
A quiet rule should show what it will touch.

## 3. PagerDuty teaches explicit maintenance state

PagerDuty's maintenance windows reinforce a second distinction:
maintenance is not the same thing as “healthy,”
and it is not the same thing as disabling a service forever.

PagerDuty keeps:
- maintenance windows time-bounded,
- current/future/past visibility explicit,
- end-now/update actions visible,
- and indefinite disable as a different stronger state.

Helm should steal the distinction.
A maintenance-range quieting rule should not silently rewrite watchpoint truth.

## 4. Android teaches channels and user control

Android notification channels continue to validate a strong product law:
notification behavior belongs to a named channel,
and users control how intrusive or visible channels are.

This suggests Helm should keep:
- per-family channels,
- user-visible interruption rungs,
- and user-owned final control.

It also warns against letting providers silently redefine a channel after the fact.

## 5. XDG Portal teaches delivery humility

XDG Desktop Portal's notification interface is small but important.
Sandboxed apps can send and withdraw notifications,
but cannot learn whether the notification was actually presented.

This is a great anti-folklore law for Helm.
The requester should not get a magical “the user definitely saw it” oracle.
Any durable consequence still belongs on explicit receipt/state surfaces.

## 6. Apple teaches narrow critical-rung law

Apple's critical-alert posture validates one more narrow move:
stronger interruption can exist,
but it should require a narrower entitlement and a more reviewed posture.

The important thing to import is not “break through everything.”
It is:
if Helm ever has a critical-only rung,
it should be visibly rarer,
policy-gated,
and separate from ordinary attention windows.

## 7. What to steal for Helm

Steal:
- recurring quiet windows
- fixed one-off silences
- active-only delivery windows
- maintenance windows as explicit time-bounded posture
- per-family channels / interruption rungs
- preview of affected targets before broad quiet rules land
- explicit difference between quiet, active, maintenance, disabled, and healthy
- end-now / disable / inspect actions on the quieting object itself
- no seen-state oracle for the requester

Do not steal:
- giant notification-center ambition
- letting quieting imply recovery
- letting maintenance imply healthy
- letting “critical” become ordinary product law
- provider-owned hidden delivery policy that the shell cannot inspect

## Judgment

The next strong move for Helm is not another alert type,
not another dashboard,
and not a giant inbox.

It is:
**attention windows** as small shell-owned bounded objects,
plus **quiet-budget** posture that keeps evaluation,
state,
delivery,
and quieting visibly separate.
