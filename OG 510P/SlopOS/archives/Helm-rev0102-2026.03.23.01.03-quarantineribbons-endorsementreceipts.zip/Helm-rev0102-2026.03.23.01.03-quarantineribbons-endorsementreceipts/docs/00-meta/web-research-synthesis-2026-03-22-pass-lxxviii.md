# Web research synthesis — 2026-03-22 — pass LXXVIII

This pass focused on a narrower product question:

**which current product moves most directly strengthen Helm's pillars,
while still respecting Helm's anti-giant-cube stance?**

## 1. Front doors should become typed,
parameterized,
and scriptable

Warp keeps strengthening the “starter as object” pattern.
Launch Configurations save windows,
tabs,
and panes,
and Warp's URI scheme can reopen a launch configuration directly.
Raycast keeps the other half of the lesson alive:
Quicklinks,
Commands,
and typed arguments make small reusable entrypoints feel native instead of like hidden automation.

Helm should steal the product law,
not the exact UI.
A Helm front door should be:
- fast to summon,
- visibly typed,
- optionally parameterized,
- inspectable before launch,
- and explicit about whether it is a starter,
a current-live reentry,
or a merely historical convenience.

## 2. Peek is best when it is deliberately weak until promotion

Arc's Peek still nails a crucial desktop move:
you can preview a nearby thing without leaving your place.
Figma strengthens the next step by putting preview,
review,
status,
and merge/change-request posture in one explicit review flow.
Its branching model also keeps checkpoints around branch creation and merge.

That suggests a very clean Helm law:
- **peek** is not **open**,
- **open** is not **adopt**,
- **adopt** is not **apply**,
- and stronger acts should keep basis/review posture visible.

Helm should therefore keep “peek → promote” as one of its signature cross-pillar moves.

## 3. Narrow grants are one of the best modern design gifts

A beautiful cluster of current systems converges on the same idea:

- Chrome `activeTab` grants temporary access to the current tab when the user invokes the extension,
and revokes it on navigation or close.
- Android's Selected Photos Access lets users grant access to specific images and videos instead of the whole library.
- Google Drive's `drive.file` scope lets users choose which files to share with an app.
- Google Workspace add-ons expose `currentonly` scopes for the open document or current event.

The design lesson is bigger than permissions.
It says:
**make the exact subject,
the current surface,
and the smaller rung the default starting point.**

That is a perfect Helm law for Exchange,
Operations Center,
Recall,
and Omnibox strong actions.

## 4. Review should bind to an exact basis,
not a warm feeling

GitHub's protected-branch rules are still one of the clearest product statements of reviewed-basis truth.
Repositories can dismiss stale approvals when code-modifying commits are pushed,
and can require approval of the most recent reviewable push.

Helm should steal that law aggressively.
If an action warrant,
review ticket,
checkpoint adoption,
or flow apply step was reviewed on one basis,
Helm should be willing to say that the review is now stale,
or that a fresher reviewer pass is needed.

This is not bureaucracy.
It is one of the best ways to make a shell feel premium and honest.

## 5. Triage plus explain-why suggestions is the right AI stance

Linear's Triage gives teams a special inbox that sits before ordinary workflow.
Triage Intelligence then suggests properties and relationships,
and explicitly lets operators accept,
decline,
or view more information about why a suggestion was made.

That is very close to the right AI posture for Helm.
Helm should let AI be powerful in:
- triage,
- routing,
- duplicate hints,
- next-step proposals,
- and review preparation,

but the shell should still preserve an explicit operator decision point before stronger adoption or action.

## 6. The shared lesson across these tools

The current best products keep converging on one pattern:

- starters become reusable objects,
- previews become weak and fast,
- grants become smaller,
- review binds to exact basis,
- suggestions arrive with reasons,
- and history remains visibly weaker than live truth.

That is almost exactly what Helm wants.

## Steal now

- parameterized front doors
- typed launch arguments / placeholders
- peek → promote grammar
- exact-scope and current-only grants
- stale-on-diff reviewed-basis posture
- triage lane plus explain-why suggestions
- branch/checkpoint style continuity truth

## Steal carefully

- shared quicklinks and team-shared starters
- review-state badges and reviewer lanes
- checkpoint branches for non-document objects
- embedded pickers and provider-local chooser surfaces

These all look strong,
but Helm should only keep them where they remain obviously weaker than live authority.

## Resist

- one mixed result row that hides inspect,
preview,
execute,
and current-live completion in one state
- broad provider reach as the default starting point
- saved or preview surfaces pretending to be live truth
- auto-applied AI actions as ordinary shell behavior
- giant workflow or workspace objects that absorb too many meanings at once

## Synthesis for Helm

The next big win for Helm is not another pillar.
It is a cross-pillar grammar that keeps the same moves legible everywhere:

- **peek**
- **inspect scope**
- **inspect basis**
- **promote**
- **review**
- **grant once / this activity / persistent**
- **adopt**
- **repair**

If Helm gets that grammar right,
it will feel more magical than a bigger architecture would.
