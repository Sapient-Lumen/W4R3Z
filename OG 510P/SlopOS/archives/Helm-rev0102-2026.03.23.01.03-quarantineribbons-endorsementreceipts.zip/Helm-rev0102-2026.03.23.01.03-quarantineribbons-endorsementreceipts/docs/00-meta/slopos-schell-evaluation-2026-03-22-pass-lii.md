# SlopOS / Schell evaluation — 2026-03-22 — pass LII

Purpose: re-read the latest SlopOS bundle and ask what it teaches Helm about **revocation, narrowing, attenuation, and post-grant control** now that Helm already has authority windows and grant-rung ladders.

## Main takeaway

The latest SlopOS bundle keeps pressing a very specific follow-on law into Helm:

**granting is not enough.
Revocation and attenuation must also be explicit,
fail closed,
and honest about what remains live.**

That makes Helm's next likely gap feel much clearer:
Helm needs one shell-owned answer to **where the operator goes to narrow or revoke a live grant without guessing through provider folklore.**
And it likely needs one humane chooser for **which weaker rung or smaller scope the grant should fall to instead of only all-or-nothing revoke.**

That pair currently looks like:
- **revoke handles**
- **attenuation ladders**

## What the latest SlopOS bundle keeps teaching

### 1. Temporary authority should be mediated by attenuating proxies, not raw export

`capability-lease-posture-v0.md` is the clearest teacher for this pass.
It says the delegate gets a **lease proxy**, not the raw capability.
The proxy enforces bounds, renewal is not ambient, time is not ambient authority, and issuance must be non-amplifying.

For Helm,
that means a broad helper/session/source grant should not be thought of as “we opened the raw thing.”
It should behave more like a bounded live proxy relation that can be narrowed, expired, or revoked without pretending the underlying live object was ever casually exported whole.

### 2. Historical descriptors prove issuance bounds, not current live state

`lease-descriptor-state-boundary-v0.md` remains one of the hardest teachers in the whole bundle.
A descriptor proves exact issuance bounds only.
It does not prove that the provider-owned grant/session/lease is still active now.

For Helm,
that means a revoke handle needs to stay tied to current-live posture.
An old historical window can explain,
but a current revoke surface should not float free of whether there is still a live grant to narrow or kill.

### 3. Revocation evidence should change future admissions before it mutates live state

`namecert-revocation-boundary-v0.md` is unusually useful for Helm even though Helm is not a naming system.
It says revocation evidence is **explicit evaluator input**, not an ambient service.
It changes **future admissions**,
not live bindings,
until some explicit later target-side removal happens.

That is a wonderful anti-magic law for Helm.
A remembered “don’t trust this now” signal,
source denylist,
or revoked grant descriptor should inform what can be reacquired next.
But live state mutation should still remain an explicit shell act with an explicit durable witness.

### 4. Background or continuing authority must stay revocable and non-widening

`background-lease-posture-v0.md` continues to teach exactly the right thing.
No ambient persistence.
No silent widening on renewal.
Expiry and revocation fail closed.
Autostart is distinct from background presence.

For Helm,
that means long-lived assistant/help/helper grants should never be one blob.
A revoke handle should be able to say:
- background stays but autostart dies,
- live-lane dies but isolated lane remains,
- this source dies but the activity remains,
- or this exact command family is now blocked.

### 5. Generic launch or open should not smuggle resource grants

`openuri-resource-grant-boundary-v0.md` keeps teaching one of Helm’s best anti-laundering lessons:
launch is not grant.
A second workflow should stay a second workflow.

For Helm,
that means revoke surfaces should likewise stay exact.
Revoking a file-grant family,
a source grant,
or a helper grant must not quietly overclaim that launch/open state was undone or that unrelated adjacent powers disappeared too.

## What Helm should keep

### 1. Live grants should have shell-owned revoke handles

Not buried inside each provider.
The shell should be able to show:
- what exact family is live,
- who holds it,
- what weaker rungs are available,
- and what exact revoke/narrow act is about to happen.

### 2. Narrowing should often beat full revoke

The SlopOS posture is excellent here even when it does not say the phrase directly.
Attenuation is often the right answer.
Helm should import that almost directly.

### 3. Revocation should be exact about what remains

A narrowed or revoked live relation should say what still exists:
- historical evidence only,
- public read only,
- isolated-lane only,
- this activity only,
- or nothing current-live remains.

### 4. Reacquire should stay separate from remembered state

Old grants,
old windows,
and old handles should help Recall and explanation.
They should not make reacquire feel automatic.

## What Helm should avoid

1. **Do not treat old grant history as a still-live kill switch.**
2. **Do not let revoke mythology imply universal erasure when only one family narrowed.**
3. **Do not let renewal or retry silently re-grow a narrowed grant.**
4. **Do not hide post-grant control inside provider-specific settings folklore.**
5. **Do not flatten exact narrow, suspend, and revoke acts into one friendly “manage access” blur.**

## Judgment for Helm

SlopOS is still the right teacher.
This pass says Helm should likely add one more compact support layer above authority windows:

- **revoke handles** as shell-owned exact current-live grant controls
- **attenuation ladders** as humane shell-owned de-escalation choosers

That looks more valuable right now than a new pillar,
and more mature than many warm luxuries,
because it sharpens Omnibox,
Operations Center,
Recall,
Desktop Flow,
Exchange,
and helper/agent work all at once.
