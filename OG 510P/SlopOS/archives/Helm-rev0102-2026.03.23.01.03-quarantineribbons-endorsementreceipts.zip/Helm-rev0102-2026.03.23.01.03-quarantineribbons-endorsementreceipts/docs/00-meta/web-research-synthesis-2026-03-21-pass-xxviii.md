# Web research synthesis — 2026-03-21 pass XXVIII

Purpose: continue collecting brilliant ideas for Helm without freezing more constitution than the evidence earns.

This pass focused on a narrower landing question:

**if Helm already has landing manifests, residue ledgers, fit cards, and rebind ladders, what exact carried structure should say what must bind here, and what exact omission class should be allowed to inherit receiver defaults instead of pretending it traveled?**

## 1) Figma, Raycast, Warp, and PowerToys all keep rewarding explicit slot maps rather than ambient magic

Figma Code Connect now makes explicit mapping unusually legible.
Design components can be linked to code components through repository paths, component names, property mappings, dynamic code examples, and optional notes.
Raycast Quicklinks and Dynamic Placeholders do something similar at a smaller scale:
exact links may expose named arguments, selected text, browser-tab content, or clipboard input without pretending the target can guess the rest.
Warp Launch Configurations and URI actions also reinforce the same point:
saved structures work better when the launchable inputs are explicit rather than ambient.
PowerToys Dock bands push in the same direction again because pinned nested commands must be resolvable by explicit command ids.

That combination strongly supports a Helm **anchor map**.
A landing manifest already says what arrived.
An anchor map would say the sharper thing:

**which exact slots does this surface expect to bind, and by what admitted handle classes may those slots be satisfied?**

That would help:

- deck recipes
- exact action keys
- command dock bands/items
- companion resource bundles
- activity entry kits
- landing manifests
- receiver fit cards
- and future parameterized deeplink-style shell surfaces

## 2) VS Code Profiles keep validating bounded inheritance from receiver defaults when it is explicit

VS Code Profiles remain especially instructive here.
A profile can include only a subset of configurations and use the rest from the Default Profile.
The profile editor lets users browse contents,
preview the profile in a new window,
and export or import it explicitly.
Workspace settings and user settings are also sharply scoped.
That means VS Code is not forcing a false binary between “carried everything” and “carried nothing.”
It allows a third honest posture:

**this class was not carried,
but it is explicitly allowed to inherit the receiver’s default.**

That is a strong argument for a Helm **inherit mask**.
A residue ledger can explain what stayed behind.
An inherit mask would explain the narrower,
more graceful case where omission is intentional and receiver-default inheritance is allowed.

Good early candidates look like:

- local keyboard shortcut choice
- layout chrome or dock placement defaults
- display/theme style
- some non-sensitive launcher chrome
- maybe some low-risk interaction preferences

Bad candidates still look bad:

- trust posture
- credentials
- account/session identity
- strong-route authority
- history residue
- or anything that would launder omitted local truth into ambient fallback

## 3) Obsidian and Notion keep validating explicit view objects over stronger local substrate

Obsidian Bases now make it even harder to ignore the value of explicit view objects.
Bases are database-like views over local Markdown and properties,
can contain several views,
and may be stored as `.base` files or embedded in notes.
Notion’s Views API now exposes views as first-class resources,
with filters,
sorts,
layout configuration,
and dashboard composition all remaining explicit view structure over one stronger data source.

That continues to argue against a universal Helm datacube UI.
The better steal is:

- explicit view objects
- explicit slot/anchor maps
- explicit receiver-default inheritance where admitted
- and explicit materialization when something needs stronger local reality

## 4) The strongest shell magic here is not more sync — it is more truthful carried structure

The best move for Helm from this pass is not “share more.”
It is:

- carry the right slot map,
- let the receiver compute fit honestly,
- allow bounded receiver-default inheritance when explicitly masked,
- and leave the rest as residue,
  rebind,
  or refusal.

That combination looks like a much stronger long-term story than either:

- giant ambient sync,
- or a brittle everything-must-rebind bureaucracy.

## 5) Strongest new warm moves from this pass

- **anchor maps** — compact shell-owned typed slot maps for the carried references,
  arguments,
  companion links,
  and receiver bindings a surface expects
- **inherit masks** — compact shell-owned declarations of which bounded classes may inherit receiver defaults instead of being carried,
  rebound,
  or faked

## 6) Strongest takes from this pass

- keep the seven pillars stable
- keep terminal/capshell as a native front-end family
- treat SlopOS’s “datacube” lesson as explicit view objects plus explicit binding law,
  not as one giant cube UI
- make travel and landing more truthful through carried slot structure,
  not more hidden sync
- allow explicit receiver-default inheritance only for bounded,
  low-risk classes

## Strongest non-takes from this pass

- do not add a pillar
- do not let inherit masks become ambient fallback folklore
- do not let anchor maps become giant app/plugin schema sprawl
- do not allow trust,
  identity,
  credentials,
  or strong-route authority to slip through “use receiver defaults” convenience
- do not turn view objects into one monolithic datacube religion
