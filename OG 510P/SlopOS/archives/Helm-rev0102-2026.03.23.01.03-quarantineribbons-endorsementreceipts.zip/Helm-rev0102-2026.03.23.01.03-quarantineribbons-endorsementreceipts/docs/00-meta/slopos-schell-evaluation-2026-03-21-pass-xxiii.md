# SlopOS / Schell evaluation — 2026-03-21 pass XXIII

Purpose: keep evaluating what SlopOS's datacube is actually teaching Helm now that derivation strips and publication ladders are already warm.

This pass focused on a narrower question:

**what should Helm learn about portable derived surfaces and publication witnesses without mistaking either for live truth?**

## 1) View replication boundary teaches that replicated summaries are not activation

`view-replication-boundary-v0.md` may now be the clearest direct teacher.
Its refusal is simple:

- replicated view state may exist,
- non-owner replicas may hold read-only summaries or cache snapshots,
- but those artifacts do not auto-attach,
  auto-detach,
  or quietly become the receiver's active local view.

That maps almost directly onto Helm's next portability move.
If Helm wants users to move around:

- a deck recipe,
- a view deck starter,
- an exact action key,
- a dock item,
- an entry kit,
- or another compact shell luxury,

then the thing that travels should be a **handoff packet**,
not a lie that the receiver already has live local state.
A handoff packet is the shell-facing equivalent of the good part of replicated view summaries:
useful,
exact enough to inspect,
non-activating by default,
and materialized only by an explicit local step.

## 2) OpenURI and materialization boundaries teach that travel and local object creation are different workflows

`openuri-materialization-boundary-v0.md` keeps teaching a vital anti-smuggling rule:
open/launch is not portable download,
staged copy,
local import,
or docref minting.
`open-untrusted-materialization-boundary-v0.md` sharpens the same lesson for riskier lanes:
preview or safe-open should not quietly produce a stronger local artifact.

That pressure transfers cleanly to Helm.
A quicklink,
exported deck,
promoted dock item,
or shareable exact key should not quietly count as:

- local installation,
- live attachment,
- trusted receiver state,
- or current continuity.

The traveling artifact should stay a **handoff packet** until the receiving side explicitly materializes or adopts it.

## 3) Observation-export posture teaches that publication should leave a bounded witness

`observation-export-posture-v0.md` is another strong teacher here.
It keeps export:

- pull-only,
- explicit,
- bounded,
- policy-killable,
- and digest-pinned.

The big transferable lesson for Helm is not "copy IF-OBS."
It is:

**when something crosses a tier, the shell should be able to name the export/publication step as its own event.**

That is what a **promotion receipt** answers.
A promotion receipt would not be a giant audit constitution.
It would be the small shell-owned witness that says:

- what surface moved,
- from which locality tier,
- to which tier,
- with what audience or permission delta,
- with what redaction/materialization posture,
- and whether the receiver still needs adopt/materialize/trust.

## 4) Approval-basis posture keeps warning against "close enough" portability

`approval-basis-posture-v0.md` keeps hammering the same truth:
review does not silently follow a newer mutable basis.
That matters for portability too.
A shell surface should not travel with vague folklore such as:

- latest now,
- current head,
- whatever the sender meant,
- or probably the same thing as before.

A handoff packet should therefore carry exact enough witness material to avoid that lie:
source,
basis,
recipe,
revision,
derivation strip,
intended affordance,
or other admitted witnesses.
If the receiver no longer has a matching basis,
that should show up as inspect/hold/re-materialize pressure,
not as fake continuity.

## 5) The datacube lesson is now more about packetized travel and witnessed publication than about giant shared state

This pass makes the SlopOS reading sharper again.
The real imported lessons are now:

- explicit projections,
- explicit view objects,
- explicit locality,
- explicit materialization,
- explicit basis witness,
- explicit publication/export events,
- and explicit receiver-side activation.

That is still a much better teacher than "build one giant cube."

## 6) Strongest Helm payoffs from this pass

### Handoff packets

Handoff packets now look like the smallest strong move for making portable shell luxuries honest.
They should pair especially well with:

- view decks,
- deck recipes,
- exact action keys,
- command dock pins,
- activity entry kits,
- flow fragments,
- and future receiver-side materialization/adoption surfaces.

The first cut should stay small:

- exact source or recipe witness,
- derivation-strip-compatible metadata,
- locality tier of origin,
- intended affordance,
- receiver-side next actions,
- and explicit refusal when a family should not travel.

### Promotion receipts

Promotion receipts now look like the natural witness sibling to publication ladders.
They make locality-tier changes,
share/export/publish activity,
and receiver expectations legible after the fact.

The first cut should stay small too:

- source surface + basis witness,
- tier transition,
- audience/permission delta,
- produced artifact or packet id,
- redaction/materialization notes,
- and revoke/inspect affordances when relevant.

## What this pass changes

- it adds **handoff packets** as a new warm Helm move
- it adds **promotion receipts** as a new warm Helm move
- it strengthens the reading of SlopOS's datacube as a teacher of **non-activating replicated summaries,
  explicit materialization,
  and explicit export/publication witness**
- it keeps derivation strips,
  publication ladders,
  deck recipes,
  view decks,
  and materialization bays warm,
  but now with a sharper portability story

## What this pass still does not justify

- a giant live shared-state shell constitution
- automatic receiver-side activation from exported or shared shell luxuries
- ambient sync as a substitute for publication/activity witness
- portable packets that bypass trust,
  review,
  or materialization
- adding more pillars

## Current bounded take

**Helm should keep reading SlopOS's datacube as a teacher of bounded projections,
exact basis witness,
explicit locality,
explicit materialization,
non-activating replicated summaries,
and explicit export/publication witness.
That pushes Helm toward handoff packets and promotion receipts without justifying a giant cube,
ambient sync mythology,
or shared live-state bluffing.**
