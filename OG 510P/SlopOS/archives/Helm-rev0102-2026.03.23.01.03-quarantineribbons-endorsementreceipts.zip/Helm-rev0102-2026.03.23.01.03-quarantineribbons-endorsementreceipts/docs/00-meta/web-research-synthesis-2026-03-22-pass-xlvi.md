# Web research synthesis — 2026-03-22 — pass XLVI

Purpose: keep collecting brilliant Helm ideas while testing whether the next high-leverage shell move is to sharpen **explicit current context selection** instead of letting AI/session context seep in through ambient tabs, recents, and nearby state.

This pass focused on one question:

**once Helm has memory seeds, activity spines, resource shelves, entry kits, and current-live beacons, what tiny shell-owned thing should say what is intentionally in play for this one ask, compare, route, or action?**

## Main takeaway

The outside world is validating a pressure that is now too strong to ignore:

**Helm likely wants explicit context loadouts, and probably nearby contribution witnesses.**

Not a giant workspace religion.
Not one invisible context sponge.
Not ambient tab or repo scraping by convenience.

A good Helm answer would likely be:

- **context loadouts** — explicit shell-owned current bundles of selected tabs/files/views/seeds/tools/instructions for one ask, compare, route, or action
- **contribution witnesses** — compact post-run witnesses that say what was actually loaded, used, skipped, or merely nearby

## What the outside world is validating now

### 1. Selected context is getting more explicit

Gemini in Chrome uses the current tab by default and, on computer, can also use up to 10 shared open tabs.
Google’s Workspace privacy docs make the selection posture even clearer: users can stop sharing the current tab or any selected tabs at any time.

That is a very Helm-shaped lesson:
**selected context should be explicit, removable, and weaker than ambient browser/session mythology.**

### 2. Scoped sources are becoming first-class work inputs

ChatGPT Projects now keeps project context bounded, prioritizes project chats and files, and can add sources from apps, conversations, or quick text inputs.
That validates a shell move where current context is not merely “what happens to be open,” but a deliberately gathered set of sources tied to the current activity or request.

### 3. Tools and instructions are part of context, not just hidden backend settings

VS Code now lets the operator enable or disable tools for the current request.
Prompt files can specify tools and agents in frontmatter, and the tool list follows an explicit priority order.

That matters because Helm should probably treat **tools, prompts, and instructions as part of a request’s loadout**, not as magical invisible background weather.

### 4. Good systems increasingly reveal what was loaded

VS Code’s Agent Debug panel now shows exactly which prompt files, skills, hooks, and other customizations were loaded for a session.
Google Sheets lets users inspect analysis steps, view sources used, and review an action preview card before applying spreadsheet actions.

That is exactly the missing adjacent move for Helm:
not just “what context did I nominate?” but also “what actually influenced the answer or proposed action?”

### 5. Saved views are strongest when they remain explicit ingredients

Linear keeps validating durable views that can be saved, shared, favorited, subscribed to, and attached as tabs inside projects.
Notion dashboard views validate multi-widget arrangements of explicit views over different data sources.

Helm should steal the lesson, but not the whole product shape.
Saved views look strongest as **explicit current ingredients in a loadout** rather than as a hidden global mode.

## Ideas now worth stealing

### Tier 1 — steal now

1. **Explicit add/remove current context**
   - current tab
   - selected tabs
   - selected files
   - selected objects/views
   - memory seeds
   - tools
   - instructions/prompt fragments

2. **One-off versus saved loadouts**
   - run once with this loadout
   - save as activity-local loadout
   - attach to entry kit or spine
   - share/import in restricted posture

3. **Contribution witness after use**
   - what was loaded
   - what was actually referenced
   - what was skipped, denied, or out of scope
   - what action preview or tool path was taken

4. **Current tab / selected set / whole activity should stay visibly different strengths**
   - current tab only
   - selected tabs/items
   - saved activity loadout
   - project/activity scope
   - web search / external source expansion only when asked or clearly disclosed

### Tier 2 — steal soon, but keep modest

1. save a current loadout as a tiny reusable compare/ask starter
2. let entry kits nominate a preferred default loadout without forcing it
3. let Omnibox and Recall show small “using 3 selected sources” or “using activity loadout” chips
4. let strong actions preview proposed effects before apply

### Tier 3 — keep warm only

1. auto-slurping every nearby file/tab by default
2. silent inheritance of all memory seeds into every current request
3. hidden tool expansion because the model “probably needs it”
4. treating a loadout as the same thing as a spine, shelf, or live lane

## Judgment for Helm

Helm should still avoid adding pillars.

But one support move now looks ready to define:

- **context loadouts** — shell-owned explicit current context bundles for asks, compares, routes, and actions

And one adjacent move now looks worth defining too:

- **contribution witnesses** — compact post-run witnesses for what actually influenced a result or proposal

The main law is simple:

**current context should be selected, inspectable, and dismissible — not ambiently inferred and then laundered into authority.**
