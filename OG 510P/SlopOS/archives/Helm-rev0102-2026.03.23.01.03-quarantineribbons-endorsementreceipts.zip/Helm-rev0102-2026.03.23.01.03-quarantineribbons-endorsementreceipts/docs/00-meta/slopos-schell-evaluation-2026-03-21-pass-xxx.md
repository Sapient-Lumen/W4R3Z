# SlopOS / Schell evaluation — 2026-03-21 pass XXX

Purpose: keep re-reading SlopOS's datacube and the older shell inspirations as teachers,
not dictators,
while Helm keeps collecting brilliant ideas without freezing too much too early.

This pass focused on one sharper seam:

**if Helm already has truthful arrival and exactness guards,
what should it learn from SlopOS about comparison before commitment,
and about selecting only part of a candidate without smuggling hidden winner rules?**

## 1) SlopOS keeps teaching that exact comparison is separate from exact selection

The strongest local teacher in this pass was the `namecert-selection-boundary-v0.md` posture.
That doc keeps evaluation set-valued.
If several candidates are admissible,
SlopOS does not quietly pick a hidden winner.
The candidate set stays visible until an explicit target-seam choice names the exact chosen candidate.

That is a very good teacher for Helm.
A receiver-local compare surface should be allowed to show one incoming subject against one explicit local candidate,
but comparison should still be weaker than selection.
The compare surface explains.
It does not silently choose.

This makes a Helm **arrival overlay** feel increasingly earned.

## 2) SlopOS also keeps refusing to launder second workflows through the first

The OpenURI family keeps repeating the same discipline:
launch is not materialization,
launch is not placement control,
and preview metadata fetch is a second workflow rather than generic launch truth.
That matters here too.

A compare overlay is a second workflow.
It is a useful one,
but it should not be smuggled into adoption.
If the receiver compared two structures,
that does not mean the better-looking one is now bound.
If the receiver inspected a provisional overlay,
that does not mean the shell already adopted that landing.

## 3) Partial acceptance should stay typed and explicit,
not dissolve into ambient merge folklore

The same Namecert selection lesson matters again here.
Selection may be bounded,
explicit,
and target-seam specific.
That is the right scale for Helm too.

If a receiver wants only part of an arriving surface,
Helm should let that happen only across typed admitted slices:

- one dock band
- one view in a deck
- one admitted shortcut/key family
- one resource bundle companion class
- one bounded slot class from an anchor map

What Helm should not do is pretend the rest “probably fit” or silently widen the acceptance scope.
The unaccepted remainder should stay visible as omitted,
inherited,
local,
or still pending.

That makes a Helm **adoption slice** feel increasingly earned.

## 4) What seems worth keeping now

- seven pillars stay stable
- terminal/capshell stays a native shell-facing front-end family,
  not an eighth pillar
- landing manifests,
  anchor maps,
  inherit masks,
  landing rehearsals,
  and near-match fences still look right
- add **arrival overlays** so receivers can compare before they commit
- add **adoption slices** so receivers can accept part of a landing without lying about the rest

## 5) What still does not seem worth taking

- not a universal datacube UI
- not a giant shell-native merge engine
- not field-level patch theology
- not hidden winner selection for similar candidates
- not new pillars

## 6) Current judgment

The most important lesson from this pass is:

**Helm gets smarter by separating compare from select,
and by letting bounded acceptance stay explicit rather than ambient.**

That feels strong enough for new candidate contracts,
and still not strong enough for a new pillar or a new freeze.
