# Web research synthesis — 2026-03-22 — pass LI

Question for this pass:
**what do current tools teach Helm about temporary authority, expiring approval, isolated autonomy, and humane permission duration — and what should Helm steal without collapsing into ambient permission folklore?**

## Main takeaway

The strongest outside pattern is no longer just “review before apply.”
It is:

**make authority duration explicit.**

The best products increasingly distinguish between:
- **one-time / this-time authority**
- **current-session authority**
- **isolated-lane authority**
- **persistent authority**
- and **stronger admin override or policy-level auto-approval**

They also keep warning that the strongest rungs are dangerous.

For Helm, that points toward two compact shell moves:
- **authority windows**
- **grant-rung ladders**

## What the current tools are teaching

### 1. Good systems increasingly offer a weaker, expiring grant before a stronger persistent one

Chrome’s one-time permissions give users **Allow this time**, and those permissions expire when the user stops actively interacting with that origin for some time.
Chrome’s extension `activeTab` permission does something similar in a more shell-shaped way: temporary access begins only after explicit user invocation and is revoked when the user navigates away or closes the tab.
Chrome’s File System Access work also distinguishes session-shaped access from more persistent “allow on every visit” access instead of making persistence the first default. 

The lesson for Helm is very strong:
**do not jump straight from inspect to permanent grant.**
The shell should have a humane in-between rung.

### 2. Modern agent tools are increasingly explicit that autonomy level is a session setting, not a hidden personality trait

VS Code’s current agent UX exposes **Default Approvals**, **Bypass Approvals**, and **Autopilot**, and the permission level applies only to the current session.
That is already close to a shell-owned authority-duration ladder.
The docs also make an especially important nuance explicit: when the agent runs in **worktree isolation**, approval is automatically bypassed because the work happens inside an isolated copy rather than directly in the live workspace.

That means Helm should not only think in terms of **how much** authority is granted.
It should also think in terms of **where** that authority can spend itself.
Isolation can justify a broader window.
Non-isolated live mutation usually should not.

### 3. GitHub keeps proving that approval should be exact, bounded, and sometimes time-limited

GitHub Copilot coding agent pull requests must be reviewed and merged by a human.
By default, workflows do not run until a user with write access clicks **Approve and run workflows**.
GitHub warns that skipping that approval can let unreviewed code access repository write privileges or secrets.
GitHub deployments reinforce the same law from another angle: jobs can wait on required reviewers, reviewers can be configured to prevent self-review, and waiting jobs can automatically fail if not approved within 30 days.

That gives Helm a very strong pattern:
**authority windows should be exact, review-bound, optionally expiring, and visibly stronger when they widen into secret-bearing or live-effectful territory.**

### 4. Project/source systems are getting richer, but access still remains an explicit approval moment

ChatGPT Projects can add Slack channels and Google Drive files/folders as project sources, but the flow still includes connecting the app and approving access.
That matters for Helm because activity spines, shelves, entry kits, and context loadouts are now rich enough that source addition can feel deceptively casual.
The outside signal says: even when source import feels lightweight, the grant step still deserves explicitness.

### 5. Preview/apply tools keep validating nearby settings, undo, and post-grant control

Gemini in Google Sheets still uses an **Action preview card**, then **Apply**, and afterward keeps **Settings** and **Undo** nearby.
That is not a full permission system, but it validates the UX law that stronger acts should keep **nearby adjustment and nearby recovery** visible.
For Helm, that means grant ladders should not end at “allow.”
They should leave a nearby **revoke / narrow / inspect / recover** path.

## What Helm should steal now

### Steal directly

1. **Allow this time / only this time**
   - Chrome and Android both validate a human-understandable temporary grant rung.

2. **Session-scoped approval levels**
   - VS Code validates that approval posture can be an explicit current-session setting rather than hidden preference folklore.

3. **Isolation-sensitive autonomy**
   - VS Code’s worktree-isolation rule is especially valuable.
   - Helm should often allow more autonomy in an explicit isolated lane than in the live lane.

4. **Required reviewer + prevent self-review**
   - GitHub deployments validate that the person who triggered a strong act should not always be sufficient as the approver.

5. **Expiry and wait timers**
   - GitHub deployments validate that some approval windows should expire rather than remain sticky forever.

6. **Persistent access as a stronger, separate rung**
   - Chrome file access validates that persistence should be a named stronger choice, not the casual default.

## What Helm should not steal

1. **Global hidden autopilot**
   - VS Code explicitly warns that broader auto-approval bypasses destructive-action prompts.
   - Helm should not make broad autonomy the cute default.

2. **Descriptor = current permission myth**
   - Outside tools are good reminders, but SlopOS is the harsher teacher here.
   - Historical approval or issuance should not imply current live authority.

3. **Permanent grants as the first rung**
   - The humane path is inspect → temporary → scoped persistent, not inspect → forever.

4. **One giant permissions control panel as the main experience**
   - The best moves are contextual ladders and current-live beacons, not administrative sprawl.

## The promising Helm move

Helm now looks ready for a support layer centered on:

### authority windows
A shell-owned bounded grant object that says:
- what authority was granted
- to whom / to what lane / to what activity
- on what reviewed basis
- for what duration
- under what expiry and revoke path
- and whether the window is still currently live

### grant-rung ladders
A shell-owned humane chooser that keeps these rungs visibly different:
- inspect only / no grant
- exact once
- this focused interaction / this time
- this loadout or ask
- this activity spine
- this isolated side lane / worktree / shadow lane
- until revoked / persistent in named scope

Not every family needs every rung.
But Helm should stop pretending “Allow” is one thing.

## Why this is super-awesome material

This move would make Helm feel unusually good because it gives users **fine-grained courage**.
They can say yes without saying yes forever.
They can give a helper broad room inside an isolated lane without giving the live lane the same privilege.
They can inspect current authority windows from Operations Center and current-live beacons instead of guessing from folklore.

That is a much better kind of power than giant hidden autonomy.

## Judgment for Helm

The seven pillars should still stay stable.
Saved view objects and checkpoint branches remain the strongest proof targets.
But the next compact support layer that now looks worth defining is:

- **authority windows**
- **grant-rung ladders**
