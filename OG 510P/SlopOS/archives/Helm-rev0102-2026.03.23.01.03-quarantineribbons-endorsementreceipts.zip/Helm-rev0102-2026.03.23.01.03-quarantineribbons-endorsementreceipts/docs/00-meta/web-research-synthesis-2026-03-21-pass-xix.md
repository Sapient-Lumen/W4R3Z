# Web research synthesis — 2026-03-21 pass XIX

Purpose: continue harvesting brilliant ideas for Helm while keeping the pillar count stable and resisting overfrozen doctrine.

This pass focused on one new question:

**what do the best current tools teach about multiple explicit views over one truth, and about explicit materialization or exact entry into those views?**

## 1) Obsidian Bases is a very strong public teacher for Helm

Obsidian Bases is one of the cleanest current examples of a useful “mini-datacube” that does not cheat.
The docs describe Bases as database-like views over notes and properties, with several views over the same underlying material, and they make a crucial point: the data remains in local Markdown files and properties while the view definition can live in a `.base` file or be embedded.

That is a direct lesson for Helm.
The shell can support multiple explicit views over stronger local truth without pretending the view is the truth.

Helm should steal:

- multiple named views over one corpus
- local-first view definitions
- typed pivots among different layouts or facets
- formula/filter/sort pressure without inventing a giant separate data religion

## 2) Arc keeps validating preview plus returnable comparative views

Arc's Peek still teaches preview without context loss, and Split View teaches that a comparative multi-surface arrangement can itself become a returnable object.

That combination is great for Helm because it suggests the shell should treat some comparative arrangements not as accidental layout leftovers, but as explicit view-shaped objects that can be reopened honestly later.

This strengthens:

- preview rails
- live lenses
- view decks
- and activity entry objects that preserve view intent without overclaiming live continuity

## 3) Warp and WezTerm keep validating saved context plus explicit scoped entry

Warp's current docs reinforce three important lessons at once:

- Launch Configurations save windows, tabs, and panes for fast reentry
- Session Navigation is explicit and recency-ordered
- Command Palette scopes can filter to sessions or launch configurations, and the URI scheme can open a named launch configuration directly

WezTerm reinforces the same shape from a more minimal angle:

- named workspaces exist explicitly
- switching focus changes which workspace is active
- launcher menus can be explicitly scoped by flags such as workspaces or tabs

The stealable law is not “save everything and hope.”
It is:

**saved context objects and scoped entry surfaces become much better when they are explicit, named, and typed.**

That directly supports Helm's:

- launch ladders
- exact action keys
- view decks
- and future exact entry handles

## 4) PowerToys Dock, Spotlight quick keys, and Raycast still point to fast exact accelerators

PowerToys Dock validates persistent shell-owned command edges.
Spotlight's quick-key docs validate action-first narrowing plus promoted quick triggers.
Raycast validates Quicklinks and deeplinks, while also showing a healthy restraint: Cloud Sync includes hotkeys and Quicklinks, but excludes Clipboard History because it may contain sensitive data.

That is a strong public reminder that Helm's fast accelerators should be:

- exact
- typed
- inspectable
- and sometimes intentionally local-only

This especially sharpens one non-obvious rule for Helm:

**not every great accelerator should become shared continuity or synced team truth.**

## 5) VS Code keeps validating exact location sharing and explicit trust boundaries

VS Code remains the clearest official teacher for exactness and trust.
Breadcrumbs can now be copied as a path, which makes orientation reusable instead of merely decorative.
Workspace Trust still keeps code execution behind an explicit approval boundary and Restricted Mode disables agents and other execution-rich features.

That keeps reinforcing two Helm directions:

- exact trails should be copyable and reusable
- stronger execution/mutation should stay on explicit higher rungs rather than leaking through convenience surfaces

## 6) Strongest new ideas worth stealing

### A. View decks

A view deck is a small shell-owned set of explicit views over one subject family, activity, or exact relation.
It is the move I would most want Helm to keep warming from this pass.

Why it looks strong:

- Obsidian shows multiple views over one truth
- Arc shows comparative arrangements can be first-class enough to return to
- Warp and WezTerm show explicit named entry into saved context works well

A Helm view deck could give one activity or object a few high-value pivots:

- browser/query view
- ops view
- receipt/history view
- transfer view
- one live lens or compare view

without turning into a dashboard religion.

### B. Materialization bays

This pass also makes a broader shell move feel ripe:
explicit **materialization bays**.

This would be the place or workflow where a projection, preview, import, exact trail, or candidate becomes something stronger:

- a fresh local object
- a saved deck
- an entry artifact
- a live attachment
- an adopted mutation

The move matters because it lets Helm keep small views honest while still giving operators a satisfying stronger next step.

### C. Local-first exact accelerators

Helm already has command docks and exact action keys warming.
This pass adds a sharper twist:
keep many of those accelerators **local-first and setup-shaped** by default.
That restraint may be part of what keeps Helm fast without drifting into macro folklore or fake shared continuity.

## Strongest takes from this pass

- keep the seven pillars stable
- keep projection-surface law frozen
- add candidate contracts for **view decks** and **materialization bays**
- renew **live lenses** as one of the best ways to prove the projection law with delight rather than bureaucracy
- keep exact accelerators typed, inspectable, and sometimes intentionally local-only

## Strongest non-takes from this pass

- do not build one giant universal Helm datacube dashboard
- do not let saved decks or comparative views impersonate live continuity
- do not let preview/query surfaces write through by charm
- do not let equality or recency substitute for provenance and fresh identity
- do not add new pillars just because the cross-pillar moves are getting better
