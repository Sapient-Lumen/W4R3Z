# Web research synthesis — 2026-03-22 — pass XLIX

Purpose: look for the next compact Helm move after action warrants and drift gates,
and ask what current tools say about **post-change truth**, **undoable aftermath**, and **partial review / partial outcome honesty**.

## Main takeaway

The strongest outside pressure now says Helm should not stop at:
- exact selected context,
- explicit contribution truth,
- explicit claim posture,
- and exact proposed-change review.

It also needs one honest shell-owned answer to:

**what exact effect actually happened after the stronger act?**

That object should likely be an **effect receipt**.

And because many stronger acts are partial,
selective,
or receiver-local,
Helm likely also needs a compact durable answer to:

**which exact parts landed,
rebounded,
default-filled,
stayed pending,
or were refused?**

That second surface still looks like a **slot verdict ledger**.

## What current products keep validating

### 1. Proposed change and merge authority are increasingly separated on purpose

GitHub Copilot coding agent creates a pull request,
then requests human review when it finishes.
GitHub's docs say draft PRs created by the agent must be reviewed and merged by a human,
that the requesting developer cannot approve the PR for required-review purposes,
and that workflows may require a separate **Approve and run workflows** step.

That is strong validation for Helm's action-warrant thinking:
**proposal,
review,
merge,
and privileged follow-on execution are different strengths.**

### 2. Good action UX now keeps preview,
apply,
settings,
and undo nearby

Gemini in Google Sheets generates an **Action preview card**,
then requires **Apply**,
and after completion keeps **Settings** and **Undo** nearby.

That is one of the clearest current examples of humane strong-action UX:
- show the proposed effect,
- apply explicitly,
- leave behind nearby undo/configure affordances.

Helm should steal that.
But Helm should also go further by leaving a better durable aftermath witness than today's usually-ephemeral action card.

### 3. Exact batch rollback and redo are becoming ordinary powers

VS Code checkpoints restore the workspace to the state it was in at that checkpoint,
undo changes made after that point,
and the 1.103 release notes say the restore can then be redone.

That validates a stronger Helm law:
**a durable effect witness should keep one exact effect boundary plus one honest rollback / redo route nearby.**

### 4. Current branch review still often stays too whole-branch and too coarse

Figma branching is excellent for explicit branch review,
approve,
merge,
and conflict handling.
But its review docs still say branch reviews apply to **all** changes in a branch,
and there is no way to approve some changes and reject others.

That is useful validation and a useful warning at once.
Helm should absolutely steal explicit review-before-merge discipline.
But it should also do better when the shell effect is structurally partial:
slotwise landings,
partial adoption,
receiver-local defaults,
or bounded rebind should remain durably inspectable after the act.

## What to steal now

1. **Exact proposal objects with staged authority**
   - proposal is not merge;
     merge is not privileged follow-on execution.

2. **Nearby undo / redo / configure after stronger acts**
   - not hidden in a distant history page.

3. **Exact changed-set or affected-set visibility**
   - the user should be able to see what changed,
     not just that “something happened.”

4. **Conflict / drift / partiality that stays explicit after the moment of action**
   - especially for imported,
     selective,
     or receiver-local acts.

## What not to steal

- do not turn every Helm action into giant PR theater
- do not let a green success badge stand in for exact durable outcome truth
- do not let whole-surface approval hide slotwise partiality
- do not let historical effect witnesses impersonate current-live truth
- do not build a giant workflow product before one tiny durable aftermath slice works

## Judgment for Helm

The next compact support moves worth defining are:
- **effect receipts** — exact durable after-the-fact witnesses for stronger acts
- **slot verdict ledgers** — durable slotwise aftermath witnesses for selective landing and partial adoption

This looks stronger now than another pillar or another broad shell noun,
because it completes the action loop:
- selected context
- contribution truth
- output claim posture
- exact proposal review
- **exact aftermath truth**
