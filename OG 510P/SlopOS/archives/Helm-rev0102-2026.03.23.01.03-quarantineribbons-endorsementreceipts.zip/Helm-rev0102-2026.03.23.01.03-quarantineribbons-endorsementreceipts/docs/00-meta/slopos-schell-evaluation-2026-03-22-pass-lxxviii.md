# SlopOS + companion-cube evaluation — 2026-03-22 — pass LXXVIII

This pass re-read the latest SlopOS bundle again,
but with a more pointed question:

**what should Helm learn precisely because SlopOS,
Schell,
Steward,
and ViewFS are themselves still design-phase datacubes?**

The answer is not “wait until they are done.”
The answer is:
**steal their laws,
not their unsettled machinery.**

## 1. SlopOS is strongest when it keeps architecture candidate-level until proof pressure earns a cut

The current SlopOS architecture overview still names competing candidate shapes,
keeps the mechanism set minimal,
and points deeper commitments at explicit decision surfaces instead of pretending the whole architecture is settled.
The roadmap does the same thing:
claims,
minimal core,
verified slice,
then broaden.

That is an excellent design-phase lesson for Helm.
Helm should keep copying **proof-slice discipline** rather than imitating every currently warm family in the parent archive.

For Helm that means:
- freeze the shell laws early,
- freeze one or two proof slices early,
- but keep larger family expansion and dashboard-scale machinery explicitly warm rather than prematurely constitutional.

## 2. SlopOS keeps teaching that hidden chooser logic is design rot

`namecert-selection-boundary-v0.md` is still one of the best tiny teachers in the bundle.
Set-valued evaluation is allowed.
Hidden winner selection is not.

That is not only a naming lesson.
It is a Helm lesson for:
- object targeting,
- restore targets,
- reveal targets,
- import/adoption targets,
- and suggested next actions.

Every time Helm is tempted to flatten a candidate set into one flattering row,
it should remember the SlopOS move:
**show the candidate truth,
then make selection explicit.**

## 3. SlopOS keeps teaching that exact success and nearby success are different acts

`openuri-showitem-exactness-boundary-v0.md` keeps the law beautifully small:
if the user asked to reveal the exact item,
opening the containing folder is not the same success.

Helm should keep stealing that everywhere.
Preview,
reveal,
restore,
resume,
apply,
and import all become more trustworthy when close-enough fallback is allowed to fail closed.

That matters even more while Helm is still designing,
because approximate success is how a design-phase shell accidentally teaches itself the wrong law.

## 4. SlopOS keeps teaching that one explicit seam beats one giant constitutional paragraph

The parent archive repeatedly pays rent where it cuts one question into one discoverable seam.
That is true for selection,
exact reveal,
and even the refusal to smuggle IPv4/IPv6 preference and Happy-Eyeballs policy into name-shaped network authority.

Helm should keep the same datacube instinct.
Do not freeze “universal collaboration state,”
“universal workspace state,”
or “universal AI action state.”
Freeze smaller shell-owned objects,
smaller ladders,
and smaller receipts.

## 5. Schell adds a crucial lesson: keep the native meaning floor small

Schell keeps pushing a clean rule:
make the native shell lane smaller and more exact,
then layer comfort above it through explicit membranes,
known signatures,
and review cards.

For Helm that means its own luxury layer should stay visibly weaker than stronger truth.
Titles,
labels,
suggestions,
quick previews,
and imported summaries are all useful,
but they should not silently outrank exact identity,
reviewed basis,
or current-live witness.

## 6. Steward adds a crucial lesson: observational chrome and assist should stay humble

Steward's design-phase posture work keeps reinforcing that:
- chrome is observational,
- assist surfaces suggest before they act,
- and lifecycle/control lanes should stay typed.

That maps directly onto Helm.
A great shell can absolutely have beautiful chrome,
rich quick actions,
and AI help,
but the shell should remain able to say:
- this is only a label,
- this is only a suggestion,
- this is only stale-but-useful history,
- this is only a preview,
- this is a stronger proposed act.

## 7. ViewFS adds a crucial lesson: observe,
attach,
control,
exec,
and sideband are different lanes

ViewFS's live-session seam work is one of the best companion warnings for Helm's Operations Center and Terminal/Capshell family.
Following output,
attaching interactively,
sending a control message,
injecting debug work,
and opening a sideband tunnel are not one vague connected-session state.

Helm should steal that separation early.
It will make Operations Center,
Terminal/Capshell,
and Exchange feel more premium and more honest.

## 8. The design-phase rule for Helm

Because the companion cubes are still moving,
Helm should currently pull the trigger on **verb grammar** and **proof slices**,
not on giant family machinery.

The right things to freeze now are moves like:
- inspect,
- peek,
- promote,
- review,
- grant-once,
- grant-for-this-activity,
- compare,
- adopt,
- repair,
- and revoke.

The wrong things to freeze now are giant meta-objects like:
- one universal workspace object,
- one universal collaboration object,
- one universal assistant action plane,
- or one universal live cube.

## 9. Pull-soon proof stack

The current best proof stack now looks like this:

1. **Parameterized front doors**
   - prove that saved starters can be typed,
     fast,
     exact,
     and clearly weaker than live continuity.
2. **Peek → promote**
   - prove that inert inspection can live beside stronger follow-up verbs without flattening them.
3. **Exact-scope grants**
   - prove that Helm can start from the current subject,
     selected cohort,
     or current activity instead of ambient reach.
4. **Triage + explain-why**
   - prove that suggestions can help without becoming hidden shell law.
5. **Continuity postcards**
   - prove that Recall can be humane without bluffing full restore.

## Closing judgment

The parent and companion cubes are still in design phase,
but they already teach one very stable lesson:

**do not inherit unresolved machinery;
inherit the laws that make strong acts legible.**
