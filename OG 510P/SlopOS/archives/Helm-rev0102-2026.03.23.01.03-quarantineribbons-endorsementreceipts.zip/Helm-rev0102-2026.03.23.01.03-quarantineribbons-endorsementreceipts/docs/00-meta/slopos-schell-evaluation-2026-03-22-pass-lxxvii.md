# SlopOS + Schell evaluation — 2026-03-22 — pass LXXVII

This pass re-read the latest SlopOS bundle again,
but also pulled Steward and ViewFS closer as companion teachers.
The pressure question was:

**what should Helm now actually prove,
what should it keep warm,
and what old shell temptations should it actively refuse?**

## What SlopOS is still teaching

### 1. Never hide the chooser
`namecert-selection-boundary-v0.md` keeps repeating a crucial law:
evaluation can be set-valued,
and the system should admit that instead of laundering the outcome through a hidden single-winner resolver.

That is a first-class Helm lesson.
A shell that hides the chooser will eventually hide the scope,
the basis,
or the reason a stronger act landed on one target instead of another.

### 2. Exact reveal beats flattering nearby fallback
`openuri-showitem-exactness-boundary-v0.md` is one of the cleanest small teachers in the archive.
If a request means **show this exact thing**,
then opening something nearby is not success.
It is a different act.

Helm should keep stealing that.
Preview,
reveal,
reopen,
compare,
and restore all get more trustworthy when “close enough” is allowed to fail closed.

### 3. Narrow family members age better than giant constitutions
The newer SlopOS bundle still looks healthiest where one question gets one small boundary-family member.
It keeps the family recoverable,
lets proofs stay local,
and resists one giant “desktop truth” constitution.

That is exactly the right pressure on Helm's datacube too.
The answer is not more pillars.
The answer is smaller reusable shell objects.

## What Schell, Steward, and ViewFS add

### 4. Display labels are real help, but weak truth
Schell keeps paying rent by refusing to let titles,
session labels,
and badges quietly become identity.
A title is useful,
but it is still a label lane.
That gives Helm a very crisp warning:
chrome must stay orienting unless it cites stronger witnesses.

### 5. Label channels are not interchangeable
Steward sharpens the same seam.
Pinned names,
process-declared names,
shell-reported labels,
and decorative chrome are different evidence classes.
Once Helm flattens them,
it will accidentally let presentation outrank source truth.

### 6. Preview is observation,
not authority
ViewFS is the clearest teacher here.
Preview,
extractors,
and observation surfaces should remain bounded,
non-authoritative,
and explicit about derivation.
A preview receipt is not a live grant.
A thumbnail is not the source.
A rich preview is not permission to execute.

## What Helm should keep

### Keep as durable laws
- exactness over flattering nearby fallback
- review that binds an exact basis
- preview and overview as weaker-than-authority surfaces
- saved setup staying weaker than live setup
- imported things arriving in restricted posture first
- small shell-owned helper objects instead of one giant omniscient cube

### Keep from the older inspirations
- keyboard-first summon speed
- strong overview / peek / split / adjacent inspection
- query-first browsing instead of path worship
- continuity as exact reentry,
  not recent-items folklore
- visual flow leverage,
  but only when debug/status/hold truth is real

## What to peel away

### Peel away aggressively
- ambient workspace mythology
- one giant dashboard religion
- display labels pretending to be durable identity
- AI suggestions silently becoming shell law
- saved layout / starter objects pretending the old live session still exists
- “recent/opened/shared” badges standing in for exact route,
  basis,
  or authority truth

## What now looks wise to prove

The strongest pull-the-trigger set now looks smaller than a new pillar freeze:

### 1. Parameterized front doors
Helm should prove that an activity/front-door object can carry:
- exact target family,
- explicit arguments/placeholders,
- profile or space posture,
- current-live relation,
- and one inspect-first launch ladder.

### 2. Inert peek → promote
Helm should prove a compact peek surface that can:
- preview without leaving context,
- show trust / freshness / derivation,
- and then explicitly promote to split,
  focus,
  open,
  adopt,
  or attach.

### 3. Current-only and exact-scope grants
Helm should prove that stronger access can start from the current thing,
the exact cohort,
or the exact selected slice instead of defaulting to broad ambient reach.

### 4. Review freshness on mutable basis
Helm should prove that an approval or warrant can go stale when the reviewed basis changes,
not because Helm became bureaucratic,
but because reviewed truth must stay exact.

## Closing judgment

The datacube is maturing well when it learns the same lesson from several different teachers:
**the shell becomes magical by making strong acts legible,
not by hiding the chooser,
hiding the scope,
or flattering the user with nearby approximations.**
