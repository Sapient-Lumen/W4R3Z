# SlopOS + Schell evaluation — 2026-03-21 — pass XIII

Purpose: keep using SlopOS and Schell as design teachers while Helm keeps collecting brilliant moves without freezing too much too early.

This pass focuses on a narrower question than pass XII:

**which parts of Helm's pillar contracts should get sharper because SlopOS is so explicit about exactness, launch humility, and shell-owned truth — and which new cross-pillar moves look worth keeping warm rather than promoting too soon?**

## What SlopOS is teaching especially clearly right now

### 1. Generic launch should not secretly become placement authority

The newer SlopOS OpenURI work keeps pinning a strict line:
- generic mediated launch is about **admission of launch**,
- not portable control over tab placement,
  window reuse,
  named-window targeting,
  new-instance guarantees,
  or task-stack policy.

That matters a lot for Helm.
It implies:

- **Tiling Shell** owns placement,
  focus,
  and spatial policy
- **Omnibox** may request and route,
  but it should not quietly pretend to own universal `open in new tab/new window/reuse this window` semantics
- any stronger placement control should return as an explicit second workflow,
  not as one more fuzzy launch flag

### 2. Exact reveal/select should fail closed

SlopOS's show-item boundary keeps the key lesson sharp:
a request meaning **“show this exact object”** should not silently degrade into **“open something nearby.”**

That should harden Helm's posture across multiple pillars:

- **Object Browser** needs exact reveal/select as a first-class promise
- **Recall** should prefer exact-object return over “something near it”
- **Exchange** should preserve exact route and subject witnesses
- **Operations Center** should be able to say that the request was denied or unsupported instead of laundering a near-miss into success

### 3. Activation and focus remain shell/compositor truth

SlopOS keeps warning against requesters quietly choosing activation/focus outcomes.
That reinforces a core Helm lesson:
the compositor is not just plumbing.
It owns:
- focus,
- activation,
- reveal,
- placement,
- and which surface is actually brought forward.

That means Tiling Shell is not only about geometry.
It is also the pillar that keeps activation/focus law visible.

### 4. Launch completion is not durable completion

SlopOS continues to separate:
- request,
- admission,
- launch,
- and downstream completion/live truth.

That reinforces Helm's split between:
- **Omnibox / Exchange** as request-and-route surfaces,
- **Operations Center** as live-truth / receipt / denial / hold surface,
- and **Recall** as historical / restored / live return surface.

The practical lesson:
Operations Center should never collapse “launch requested” into “task succeeded.”

## What Schell still teaches — without forcing a premature freeze

Schell is still young, but its pressure is becoming easier to use.

### 1. Terminal/capshell should stay first-class without becoming the hidden master ontology

The latest Schell posture still pushes:
- command boundaries,
- reviewed actions,
- receipts,
- exact-open bridges,
- local object cards,
- timing lanes,
- and richer shell-facing luxuries.

That keeps terminal/capshell important.
But it still does **not** force Helm to make terminal objects the universal desktop truth model.
The treaty from pass XII still holds:
terminal/capshell is best treated as a **native front-end family over shared truth**.

### 2. Source and authorship grading matter more than raw history volume

Schell keeps sharpening a valuable distinction:
- current live state,
- shell-local warm state,
- prior receipts,
- imported history,
- delegated helper output,
- and proposed next steps

should not collapse into one undifferentiated history rail.

That is especially relevant to Helm's next Recall work.

### 3. Cheap delight should stay acceleration, not authority

Schell's timing-lane pressure still looks right:
warm caches,
fast suggestions,
sticky context cues,
and reviewed shortcuts are great,
but they should act as accelerators over shared truth rather than replacing that truth.

## What this changes in Helm's pillar read

### Tiling Shell
Needs to be read more strongly as the owner of:
- placement truth,
- focus/activation truth,
- and spatial policy —
not only as layout machinery.

### Omnibox
Needs to stay powerful,
but should keep generic launch humble.
It should excel at:
- finding exact objects,
- presenting action ladders,
- showing review strips,
- and routing honestly,
rather than promising universal placement folklore.

### Object Browser
Looks even more central now.
Exact reveal/select,
preview-with-actions,
and query-first browsing feel less like luxuries and more like core shell law.

### Operations Center
Should become the strongest surface for:
- request vs admitted vs launched vs completed vs denied,
- live helper/delegated/background presence,
- and receipt-bearing truth.

### Desktop Flow
Should keep respecting shell law instead of scripting around it.
It needs reusable fragments and visible status so automation stays structured and legible.

### Recall
Should lean harder toward **exact-object recency** and **source-labeled return** rather than generic “recent stuff.”

### Exchange
Should stay the main typed route witness surface.
It looks stronger every time SlopOS narrows launch and reveal honesty.

## New cross-pillar moves this pass thinks are worth keeping warm

### 1. Review strips
Tiny shell-owned preflight strips/cards that can show:
- exact subject,
- action family,
- route/provider,
- basis posture,
- and readiness/hold state
without forcing a giant review UI.

### 2. Exact-object recency
Recall entries centered on:
- exact objects,
- exact reviewed actions,
- route receipts,
- holds/denials,
- and clear source labels such as live / restored / historical / request-only / imported.

### 3. Reusable flow fragments
Desktop Flow needs a first-class reusable-fragment story:
- typed inputs/outputs,
- status-bearing instances,
- expandable body,
- provenance,
- and inspectable raw-lane use.

These moves feel strong enough to record explicitly,
but not strong enough to become new pillars.

## Pass-XIII bounded take

The best current take is:

- let SlopOS further sharpen Helm's pillar contracts around exact reveal,
  launch humility,
  activation/focus ownership,
  and request-vs-live truth
- keep Schell as the main teacher for shell-facing receipts,
  boundaries,
  and source grading
- add explicit pressure for **review strips**,
  **exact-object recency**,
  and **reusable flow fragments**
- and keep proving the architecture through compact cross-pillar slices instead of giant dashboards,
  giant session-restore theater,
  or terminal-first ontology moves
