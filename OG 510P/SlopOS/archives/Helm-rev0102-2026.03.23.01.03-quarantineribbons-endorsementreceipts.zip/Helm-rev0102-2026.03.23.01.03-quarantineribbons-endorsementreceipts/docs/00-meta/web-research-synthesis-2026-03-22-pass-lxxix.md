# Web research synthesis — 2026-03-22 — pass LXXIX

This pass focused on one practical question:

**what outside product moves are strong enough to make Helm better right now,
without forcing Helm to freeze too much too early?**

## 1. Saved starters are strongest when they are typed,
scriptable,
and visibly not live continuity

Warp's Launch Configurations are a crisp reminder that saved starters can be first-class objects.
They preserve windows,
tabs,
and panes,
and Warp's URI scheme can launch them directly.
Raycast keeps the complementary lesson alive:
commands and arguments let users fill in values from root search before opening the command.

Helm should steal the law:
**a front door should be a typed reusable object,
not a fake claim that the underlying work is still live.**

That gives Helm one of its best next delight proofs:
parameterized front doors.

## 2. Weak preview remains one of the cleanest ways to keep power honest

Arc Peek still nails the “look nearby without leaving your place” move.
Figma's branching model adds the next important lesson:
change exploration,
review,
merge,
and checkpoints remain visible and separate.
Figma also creates checkpoints around branch creation and merge,
and version history preserves restore-related checkpoints too.

Helm should steal the full grammar:
- peek
- inspect basis
- inspect scope
- promote
- merge/adopt/apply
- checkpoint / receipt

That gives Helm a premium feeling without hidden chooser magic.

## 3. Narrow grants and picker-scoped access are one of the best current design patterns anywhere

Several current systems converge on the same idea:

- Chrome `activeTab` gives temporary access to the active tab when the user invokes the extension.
- Android 14 Selected Photos Access lets users grant access to specific photos/videos instead of the whole library.
- Google Drive recommends narrow per-file access and points developers toward `drive.file`.
- Google Picker gives an explicit file-open dialog for Drive files instead of ambient whole-Drive browsing.
- Google Workspace `currentonly` scopes grant temporary access to the currently open file in supported Apps Script contexts.

The bigger lesson is not just “permissions.”
It is:

**start from the exact subject,
the current thing,
or the explicitly chosen subset,
and widen only by visible deliberate steps.**

Helm should apply that to:
Exchange,
Operations Center,
Omnibox strong acts,
Recall return acts,
and Terminal/Capshell handoff.

## 4. Restricted-first posture is a huge product gift

VS Code Workspace Trust remains a very strong teacher because it makes restricted mode useful instead of punitive.
Restricted Mode disables or limits execution-sensitive features such as AI agents,
tasks,
debugging,
workspace settings,
and extensions until trust is granted.

That is a direct Helm import:
**imported,
rebound,
or helper-generated structure should still be browseable and inspectable before it is trusted enough to execute,
adopt,
or widen.**

This is a much better shell feel than either:
- all-powerful by default,
  or
- blocked until you accept a giant scary dialog.

## 5. Reviewed basis should be saved,
inspectable,
and willing to go stale

Terraform keeps proving that plan/apply works better when preview is a real object.
`terraform plan` creates an execution plan,
and `terraform apply` can consume a saved plan file.
GitHub protected branches reinforce the same ethic from the review side:
approvals can be dismissed as stale when the merge base changes,
and repositories can require approval of the most recent reviewable push.

Helm should steal the combined law:
**strong acts deserve saved-plan posture plus review freshness posture.**

That is bigger than infrastructure or code review.
It is a premium shell law.

## 6. Triage works best as its own lane,
with explainable suggestions

Linear's Triage is a special inbox before normal team workflow,
and Triage Intelligence automates assessment and routing steps.
The important design lesson is not raw automation.
It is:
**keep intake,
routing,
and suggestion pressure in a dedicated lane that operators can inspect and decide through.**

Helm should import that posture almost directly for Operations Center and Omnibox suggestion lanes.

## 7. Exposure ladders are a brilliant model for shell honesty

Tailscale's split between Serve and Funnel is unusually clean.
Serve routes a local service to other devices in the tailnet.
Funnel routes a local service to the broader internet.

That is a fantastic Helm idea to steal.
Many shells flatten local open,
private share,
org-visible share,
and public exposure into one vague “open/share” concept.
Helm should do the opposite.

A Helm exposure ladder should feel natural,
fast,
and utterly explicit.

## Steal now

- parameterized front doors
- peek → promote
- exact-subject / selected-subset / current-only grants
- restricted-first imported posture
- saved-plan → inspect → apply posture
- stale-on-diff review freshness
- triage lane with explain-why suggestions
- exposure ladders

## Steal carefully

- team-shared starter catalogs
- browser-like preview surfaces
- richer branch/review metaphors for non-document objects
- current-only access stories that depend on host-specific APIs
- service publishing helpers that might tempt Helm into network mythology

## Resist

- ambient whole-world access as a fast path
- “saved starter = current session” bluffing
- preview surfaces that quietly execute or widen
- giant one-state share/open/publish exposure blobs
- AI that auto-applies stronger shell acts
- giant live cube ambitions just because the UI looks neat

## Synthesis for Helm

The next strong Helm move is not another pillar.
It is a slightly tighter cross-pillar grammar:

- **choose exact**
- **peek weakly**
- **inspect scope**
- **inspect basis**
- **adopt narrowest safe rung**
- **promote deliberately**
- **review freshness**
- **receipt the aftermath**
- **keep exposure classes separate**

If Helm gets that grammar right,
it can feel much more powerful than a larger architecture would.
