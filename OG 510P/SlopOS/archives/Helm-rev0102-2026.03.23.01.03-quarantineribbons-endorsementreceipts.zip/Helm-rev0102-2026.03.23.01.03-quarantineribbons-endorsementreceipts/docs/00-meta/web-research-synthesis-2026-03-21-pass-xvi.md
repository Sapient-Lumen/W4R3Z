# Web research synthesis — 2026-03-21 pass XVI

Purpose: continue harvesting strong ideas from current tools **without** importing their whole product worldview.

This pass focused on:

- persistent host-owned compact command surfaces
- background/delegated work review and apply flows
- honest saved workspace/session objects
- keyboard-first operational inboxes and exact recency
- breadcrumb / trail cues that improve exact orientation

## 1) PowerToys Dock makes a good case for a persistent shell edge

Current PowerToys now documents a **Command Palette Dock**: a persistent toolbar that stays visible at the edge of the screen and gives instant access to most-used commands and extensions.

The stealable idea is not “copy PowerToys.”
The stealable idea is:

**the shell can own one tiny persistent command edge that projects already-legible truth without making users re-summon the whole launcher every time.**

For Helm that suggests a **command dock** candidate with a few exact pinned slots such as:

- one exact object or view jump
- one reviewed action entrypoint
- one background/adoption status cue
- one quick entry kit / seed / launch object
- one current-focus return slot

The non-take is important:
Helm should not let the dock become a hidden second product or an extension bazaar that outruns review, receipts, and typed shell law.

## 2) Raycast keeps proving that tiny personal accelerators matter

Raycast continues to make a strong case for:

- **Quicklinks**
- **hotkeys and aliases**
- **clipboard history with pinning**
- **single-hotkey note capture**
- and keyboard-driven window management

The Helm take is not “be Raycast.”
The take is that users genuinely love **small exact accelerators** when they are:

- easy to summon,
- easy to pin,
- typed enough to stay honest,
- and close to the shell rather than hidden in app-local folklore.

That continues to support:

- **snippet / quicklink / placeholder seeds**
- **command docks**
- **exact-object recency**
- and a future one-hotkey scratch surface that feeds Recall or Flow instead of disappearing into app-local notes.

## 3) VS Code / Copilot CLI are excellent teachers for adoption law

Recent VS Code docs around background agent sessions and Copilot CLI are unusually relevant to Helm.
They emphasize:

- background sessions that can run while you continue other work,
- isolation modes such as separate worktrees,
- session tracking,
- review of resulting changes,
- and a deliberate **Apply** step before changes land in the main workspace.

This is one of the cleanest current public precedents for a Helm move that is bigger than AI:

**candidate work should be able to run beside the authoritative live lane, be inspected there, and only become live through an explicit adopt/apply step.**

That strongly supports an **adoption harbor** candidate.

## 4) Arc, Obsidian, Warp, and WezTerm all validate saved context objects — but only as saved context objects

Arc **Spaces** and **Split View**, Obsidian **Workspaces**, Warp **Launch Configurations**, and WezTerm **workspaces / launcher menus** all keep proving that users love:

- reusable contexts,
- saved layout/state shapes,
- fast reentry,
- and scoped launch objects.

The stealable idea is:

**saved context is powerful when it stays visibly saved context.**

That pressure continues to support:

- **workspace/activity capsules**
- **launch ladders**
- **layout templates**
- and shell-owned split/spatial objects that can be returned to honestly later

The non-take is just as important:
Helm should not let saved context objects bluff their way into pretending they are current live continuity.

## 5) Linear and Spotlight keep validating keyboard-first typed operations

Linear's search + triage posture and Apple's Spotlight action/category pivots keep proving that fast keyboard-first surfaces get better when they can:

- narrow to a typed family,
- show recent exact objects,
- jump straight into action,
- and preserve one obvious operational inbox.

That pressure strengthens:

- **facet strips**
- **review strips**
- **exact-object recency**
- **Operations Center** as more than a place for emergencies

## 6) VS Code breadcrumbs are a better idea than just “editor chrome”

VS Code's breadcrumb bar and newer **Copy Breadcrumbs Path** move keep proving that users value one exact readable path they can:

- glance at,
- navigate through,
- and copy/share.

Helm should keep this warm as a shell-wide pressure:

- exact object/location trails in Object Browser,
- exact focus trails in Tiling Shell / Overview,
- exact receipt/object path cues in Recall,
- maybe exact fragment or result trails in Desktop Flow.

This feels increasingly promising, but it still reads as **pressure** rather than a candidate contract worth freezing this revision.

## Strongest current takes

- **command docks** as tiny persistent shell-owned command/status edges
- **adoption harbors** as review/apply surfaces for delegated or background candidate work
- **facet strips** as typed pivots
- **preview rails** as bounded next-action companions to preview
- **launch ladders** and **workspace capsules** as honest saved-context moves
- **exact breadcrumb/trail cues** as warm but still-unfrozen pressure

## Strongest current non-takes

- do not let the dock become a hidden second launcher constitution
- do not let apply/review surfaces collapse into silent auto-merge
- do not let saved workspace/session objects impersonate live truth
- do not let breadcrumb/trail cues overclaim what they know
- do not import agent UX products or browser workspaces wholesale
