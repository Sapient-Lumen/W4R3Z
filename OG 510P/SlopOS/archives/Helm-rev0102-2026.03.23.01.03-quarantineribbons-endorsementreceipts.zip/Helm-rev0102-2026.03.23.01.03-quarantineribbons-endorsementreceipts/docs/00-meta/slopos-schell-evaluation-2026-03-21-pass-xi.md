# SlopOS + Schell evaluation — 2026-03-21 — pass XI

Purpose: keep using SlopOS and Schell as design teachers while Helm decides what deserves a freeze, what deserves a specimen, and what should stay pressure only.

This pass focuses on the next trap after request-vs-live truth,
entry-artifact truth,
binding witnesses,
activity scope truth,
continuity-choice/authorship truth,
and reviewed-basis truth:

**even an honest basis-aware surface can still cheat if delegated or background work writes straight into the operator's live lane and only explains itself afterward.**

That now looks strong enough to justify one narrow new Helm freeze:
- **delegated or background work requires explicit adoption before it becomes authoritative live activity**,
- and one new candidate move:
- **shadow work lanes**.

DelayBasin matters here because it already keeps asking for shadow comparison lanes,
non-authoritative sinks,
and one explicit authoritative output surface instead of flattering candidate bleed-through.

## What SlopOS pressures most strongly now

### 1. Exact basis law naturally points toward isolated candidate work

SlopOS's approval-basis posture already says a reviewed action binds one exact basis and does not silently follow a newer mutable head.
That posture gets much weaker if delegated help is allowed to rewrite the same live surface underneath the operator while still borrowing the earlier basis story.

A natural extension is:
- exact reviewed basis should stay paired with
- exact mutation path,
- exact actor/lane,
- and an explicit adoption moment when delegated work wants to become live.

### 2. Restore-repair barriers are a good model for shell help too

SlopOS's restore-repair barrier for warm-start microVMs is a strong teacher here.
It says repair happens before externally visible effectful work and before readiness is claimed.
Helm should steal the moral rather than the virtualization machinery:
- candidate repair work can exist,
- but it should not count as ready/live/operator-authorized outcome until it crosses a visible adoption barrier.

### 3. Request-state humility already rejects ambient carry

The datacube keeps refusing the lie that requests,
recents,
launches,
or summaries automatically become live truth.
The next refinement is that delegated edits,
background suggestions,
or reconstructed fixes also do not become live truth merely because they are nearby and convenient.

### 4. The SlopOS datacube now pressures an adoption layer above basis packets

The deeper datacube lesson is now:

- binding witnesses explain **how** a join happened,
- scope witnesses explain **which axes counted**,
- continuity choice witnesses explain **who proposed / chose / executed a substitute**,
- basis packets explain **what exact reviewed state still matters**,
- and shadow work lanes can explain **where delegated mutable work lived before the operator adopted it**.

That feels like the next honest refinement rather than feature sprawl.

## What Schell adds to the picture

### 1. Schell already wants proposal-only repair rather than hidden rerun

Schell's repair-card direction is almost the exact shell-facing teacher Helm needs here:
- failures become packets,
- repair remains proposal-only,
- basis drift downgrades stronger moves,
- and exact handoff bundles keep context bounded.

That is already very close to “shadow work first, adoption second.”

### 2. Launch kits and cockpits become more trustworthy if adoption is named

Schell's launch-kit and cockpit direction keeps making the same demand from the opposite side:
- saved entry artifacts are useful,
- restored continuity is useful,
- quick summon is useful,
- but none of those should silently become live authority.

A shadow work lane gives Helm a better answer when delegated help wants to improve or repair one of those surfaces without stealing the lane outright.

### 3. Exact handoff bundles suggest the right seam

Schell's exact handoff bundles are a useful scale hint.
Helm probably does not need a giant branch court first.
It may only need:
- one isolated mutable lane,
- one compact adoption card,
- one exact basis link,
- and one explicit hold / reject / continue-shadow ladder.

## What DelayBasin usefully pressures here

DelayBasin is the archive-method teacher that keeps this bounded.

The useful take is:
- preserve one authoritative output surface,
- preserve candidate-vs-authoritative separation,
- keep shadow work non-returning,
  log-only,
  or adoption-gated until it is cleared,
- and resist scorecard theater before a tiny live specimen exists.

The non-take is:
- importing a giant promotion or mirror-analysis constitution before one shell-owned adoption surface exists.

## What now looks worth doing in Helm

### Worth freezing now

- **delegated or background work requires explicit adoption**

Why now:
- Helm now has enough saved-task,
  review,
  continuity,
  and task-return structure that background help could otherwise become a hidden mutation lane,
- SlopOS already supplies exact-basis and repair-barrier discipline,
- Schell already points toward proposal-only repair and exact handoff,
- DelayBasin supplies the non-authoritative-shadow discipline,
- and the freeze can stay narrow.

### Worth adding as candidate pressure now

- **shadow work lanes**

Why this now looks strong:
- Helm wants richer delegated help,
  background repair,
  and task-return luxury,
- modern tools increasingly isolate that work instead of landing it directly in the active lane,
- and the first useful version can stay small.

A first shadow work lane should likely name:
- the live subject or entry surface it relates to,
- the delegated or background lane id,
- the basis packet it started from,
- the actor/chooser posture,
- whether the lane is read-only,
  proposal-only,
  mutable-but-non-authoritative,
  or adoption-ready,
- and the honest next ladder (`inspect`, `adopt selected`, `adopt all`, `continue shadow`, `reject`, `hold`).

## What Helm should explicitly not take

- a hidden background mutation lane that writes into the live activity and only backfills explanation later
- a giant workspace/branch manager before one compact adoption surface exists
- silent auto-merge or silent retargeting from delegated work into operator-owned live state
- the belief that basis packets alone solve delegated-mutation risk
- an AI-shaped helper religion that bypasses shell law

## Current bounded take

A useful new Helm rule is:

**when delegated, background, or repair work produces mutable candidate state, that work should stay isolated from the operator's authoritative live activity until the operator explicitly adopts it or another clearly named surface does.**

And a useful new candidate move is:

**shadow work lanes as small shell-owned isolated mutable lanes with compact adoption cards that preserve basis, authorship, and exact next steps instead of silently merging helpful work into the live lane.**
