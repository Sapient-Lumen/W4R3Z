# SlopOS / Schell evaluation — 2026-03-21 — pass XXXIV

## Main takeaway

Re-reading the latest SlopOS bundle keeps reinforcing the same core lesson:
**the datacube value is not one giant inspectable cube UI.**
It is the discipline around exact view surfaces,
exact basis,
explicit materialization,
and refusal of ambient inheritance.

This pass sharpens that lesson one step further for Helm:
**cross-boundary shell surfaces need an explicit lineage choice.**

That means Helm should stop treating “move”, “copy”, “duplicate from template”, and “arrived here and rebound locally” as close cousins.
They are different stories.

## What SlopOS keeps teaching

### 1. Activation delivered is not inheritance

The capshell and activation docs continue to reject ambient inherited baselines.
The portable seam is explicit delivery,
not “whatever the parent already had”.

Helm should keep importing the analogous shell lesson:
- a moved or imported shell surface should not silently inherit local identity or continuity,
- and a copied shell surface should not quietly wear the old lineage badge.

### 2. Exact reviewed basis is still stronger than smooth continuity

The approval-basis and ACP precondition docs still point in the same direction:
review binds against exact witness,
not mutable “latest head” folklore.

That matters here because lineage-preserving continuation is the stronger claim.
If Helm ever says a cross-boundary action preserved lineage,
that should be a named exact mode,
not a soft convenience default.

### 3. Receipts are evidence, not live truth

SlopOS continues to be excellent at refusing the flattering collapse:
receipt,
descriptor,
accepted request,
or projected view
are not current live provider truth.

The Helm import is now sharper:
- a fork/copy receipt is valuable because it says a new object was born from a source,
- but the receipt should not imply live linkage unless the lineage mode says so.

### 4. Exactness pressure belongs before selection and after selection

SlopOS also keeps rewarding bounded candidate sets,
deterministic refusal,
and explicit post-choice witness.
That remains the best teacher for Helm's slotwise landing work.

But this pass adds one new emphasis:
Helm should make the lineage choice visible **before** the stronger cross-boundary action,
and the resulting lineage/copy fact visible **after** the action.

## What Helm should keep from old inspirations

Keep:
- exact trails and lineage thinking
- preview before stronger action
- named saved structures
- compact shell accelerators
- slotwise typed flexibility
- visible move/copy/fork distinctions

Peel away:
- any nostalgia for silent “same enough” reuse
- any shared-state fantasy where travel implies live continuity
- any UI that hides whether the operator moved the thing,
  copied it,
  or instantiated a new local starter from it

## Current judgment

The seven pillars still look stable.
The best next import from the SlopOS/Schell teacher line is **not** a new pillar.
It is a sharper cross-boundary identity discipline.

That makes two new warm Helm moves feel earned now:
- **lineage modes**
- **fork receipts**
