# Web research synthesis — pass XCII

This pass focused on one question:

**what do mature systems teach about historical effect truth and partial rerun that Helm can reuse without becoming a giant operations dashboard?**

## Cluster 1 — strong systems preserve a durable run/result object

Google's long-running-operations guidance is a strong current teacher.
It keeps operation identity,
polling,
metadata,
and terminal success-versus-error separate.
A finished operation does not pretend to be the live resource forever;
it remains one bounded historical operation result.

That strongly suggests a Helm object stronger than a toast but weaker than live truth:
**an effect receipt**.
It should be able to say:
- what exact strong act ran,
- whether it is still pending or done,
- whether it finished with response or error,
- and what exact basis relation held when the act landed.

## Cluster 2 — partial outcomes should stay explicit and rerunnable by subset

GitHub Actions is even clearer on the subset-rerun pattern.
Workflow runs keep summary pages,
previous attempts,
check status versus conclusion,
and job summaries.
If only some jobs fail,
GitHub lets the operator rerun just the failed jobs instead of replaying the whole run.

That is an excellent Helm pressure.
The shell should not compress partial aftermath into one badge.
At minimum it should keep:
- exact overall act receipt,
- exact per-part verdicts,
- and exact rerun-failed-subset posture.

## Cluster 3 — stepwise automation benefits from step outputs and status rows

AWS Systems Manager Automation keeps overall execution status distinct from per-step status,
and step execution records can carry start/end time,
failure details,
inputs,
and outputs.
That is a strong reminder that one whole-act historical object often needs a nearby finer-grained companion.

For Helm that argues for a small pair rather than one overloaded receipt:
- one **effect receipt** for the act as a whole,
- one **slot verdict ledger** for the exact subset or stepwise aftermath.

## Cluster 4 — good recovery preserves successful history and retries only the broken subset

AWS Step Functions redrive is one of the best current teachers here.
Redrive restarts unsuccessful Standard Workflow executions,
continues from the unsuccessful step,
preserves the results and execution history of successful steps,
and for Parallel/Map states can rerun only failed or aborted branches/iterations.
Kubernetes indexed Jobs reinforce the same law with `completedIndexes` and `failedIndexes` in status,
while the overall Job can still end in a failed terminal condition.

That is one of the best arguments for Helm's next compact proof.
The shell should be able to say:
- overall act outcome,
- exact completed subset,
- exact failed/pending subset,
- and exact repair/rerun relation,
without rewriting the original history.

## Design moves worth stealing

1. **Effect receipts**
   Small trusted shell objects for exact historical aftermath.

2. **Slot verdict ledgers**
   Slotwise or stepwise durable verdict surfaces for selective outcomes.

3. **Subset rerun / repair**
   Repair should preserve successful prior aftermath and target only unresolved pieces when safe.

4. **Historical-versus-live separation**
   A durable receipt should not masquerade as current-live health.

5. **Retry / redrive relation**
   The shell should preserve ancestry between the first effect and later repair attempts.

## What Helm should refuse

- giant workflow-religion UIs
- one universal status vocabulary for all acts everywhere
- flattening partial outcomes into “mostly worked” prose
- rewriting old history when only a subset is repaired
- current-live badges that quietly inherit trust from a historical receipt

## Main judgment

A shell can feel **super awesome** here by making aftermath unusually honest,
compact,
and recallable:
not with a giant control room,
but with one exact effect receipt,
one exact partial ledger when needed,
and one nearby repair / rerun subset rail.
