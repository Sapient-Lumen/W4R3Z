# Web research synthesis — 2026-03-22 pass LXXIII

Question for this pass:
what current tools most strongly validate a **humane shell-owned authority grammar** once Helm already has basis stamps,
action warrants,
claim envelopes,
reliance ladders,
freshness windows,
and receiver-fit cards?

## Strong pattern: scope, duration, and revoke should not blur together

The best current teachers keep separating:
- **what subject is being granted**
- **how broad the scope is**
- **how long it lasts**
- **what weaker inspect/restricted posture exists instead**
- **how the operator narrows or revokes it later**

That is exactly the shape Helm still lacked.

## Best steals

### Android permissions: grant rungs are real product objects
Android 11 introduced **Only this time** for camera, microphone, and location, and also auto-resets sensitive runtime permissions for unused apps.
That is a strong signal that duration is not decorative wording.
Temporary,
revocable,
and decaying authority is a real product surface.
It also reinforces a second law: previously granted access should not be treated as timeless current truth.

### Chrome extensions: site access should be user-shaped and situational
Chrome lets users choose whether an extension can read/change site data **when selected**,
on the current site,
on specific sites,
or on all sites.
Chrome’s extension privacy guidance also points developers toward **activeTab** and optional permissions instead of broad all-sites access.
That is almost a direct product teacher for Helm’s grant-rung ladder:
exact once / this interaction / bounded subject / broader persistent are meaningfully different rungs.

### GitHub tokens: subject narrowing and expiry are first-class
GitHub fine-grained personal access tokens let people choose an expiration,
limit access to a selected resource owner,
and select repository access / permissions.
GitHub App user access tokens expiring after eight hours by default reinforce the same lesson from the automation side:
persistent power should not be the assumed default.

### VS Code Workspace Trust: inspect-only should remain a live option
VS Code’s Restricted Mode keeps a useful weaker posture available without granting ordinary code execution.
That is a strong teacher for Helm’s lower rung and isolated-lane story:
“inspect / restricted / isolated” is not failure.
It is often the right first authority class.

## Combined product judgment for Helm

Helm should not answer stronger acts with one generic allow prompt.
It should instead grow one small shell-owned family:

- **authority windows** — what exact bounded authority relation exists or recently existed,
  with holder,
  subject,
  rung,
  start/expiry posture,
  and current-live witness relation
- **grant-rung ladders** — the humane chooser for exact once,
  this ask,
  this activity,
  isolated-lane only,
  or persistent scope
- **revoke handles** — nearby controls for revoke,
  suspend,
  narrow subject,
  or move the authority off the live lane

## What not to steal

- giant settings-first admin-console culture
- one universal cross-provider permission ontology before a shell proof exists
- provider-owned hidden revoke surfaces
- fake seamless reuse of historical grants when basis / locality / subject changed

## Pull-the-trigger judgment

This now looks like a wise warming move.
Not a new pillar.
Not a giant IAM system.
A compact shell-owned humane-authority family that can sit next to stronger shell acts and keep travel,
review,
live truth,
and revoke posture honest.
