# SlopOS + Schell evaluation — 2026-03-22 pass LXXIV

This pass re-read the latest SlopOS archive with extra attention on the **auth-mediation family**,
lease-descriptor truth,
and portalized share/open authority.
The important result for Helm is not “become a sharing product.”
It is: **carry current reveal truth as a shell object family rather than hiding it in historical receipts,
provider share sheets,
or fake seamless public-link folklore.**

## What SlopOS is still teaching

### 1. Local mediation is not portable current audience truth
The new authorization-context boundary keeps repeating the same expensive lesson:
local login,
local consent,
and local credential mediation do **not** become a portable granted-scope export seam.
Applied to Helm,
that means a share,
publish,
invite,
or traveling packet should not magically imply the receiver can still see the same shape of truth now.
Historical publication is not the same thing as live reveal.

### 2. Issuance evidence is not live state
The lease-descriptor state boundary is unusually valuable for Helm here.
SlopOS says issued descriptors and receipts are exact bounded evidence of what was granted,
not an oracle for current live state.
That maps almost directly onto reveal posture:
a past publish/share receipt can prove that a reveal route once existed,
but it must not impersonate a still-live audience relation.

### 3. Route families matter
SlopOS’s portal posture keeps rewarding explicit route families instead of one giant ambient helper seam.
That maps cleanly onto Helm’s visibility problem:
- named invite
- org/workspace audience
- guarded link
- public link
- bearer signed route
are not the same route family,
and the shell should stop flattering them into one “shared” badge.

### 4. Redaction / attenuation should stay first-class
The archive keeps rewarding exact bounded weaker forms rather than all-or-nothing access religion.
For Helm,
that means preview-only,
summary-only,
redacted,
or passworded/time-boxed reveal should stay first-class reveal shapes.
A shared brief,
front door,
packet,
claim envelope,
or saved view does not need to expose its strongest full form to every audience rung.

## What Helm should keep

- shell-owned current reveal truth rather than provider-sheet folklore
- named route-class truth when visibility is invite,
  org-only,
  guarded link,
  public link,
  or bearer route
- historical-vs-current honesty for public/shared visibility
- exact weaker reveal shapes like summary,
  preview,
  redacted,
  or inspect-only
- nearby narrow / rotate / disable / republish moves instead of “shared forever” vibes

## What Helm should reject

- one generic shared badge for wildly different audience routes
- historical share receipts impersonating live visibility
- public/bearer routes silently inheriting the same trust posture as named collaborators
- giant ACL or collaboration-suite ambition before a shell proof exists
- silent widening from preview/summary to full reveal merely because a route already exists

## Current judgment

The seven pillars stay stable.
The next compact support family worth warming is **reveal windows + audience ladders**.
That looks like the smallest move that can make Exchange,
Recall,
Operations Center,
Object Browser,
and Overview much more honest about who can currently see what shape of shell truth without broadening Helm into a giant sharing or admin product.
