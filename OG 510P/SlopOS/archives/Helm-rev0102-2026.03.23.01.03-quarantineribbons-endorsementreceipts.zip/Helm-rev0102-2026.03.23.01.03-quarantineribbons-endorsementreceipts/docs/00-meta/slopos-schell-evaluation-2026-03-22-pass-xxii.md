# SlopOS / Schell evaluation — 2026-03-22 pass XXII

Purpose: keep evaluating what SlopOS's datacube is actually teaching Helm now that projection surfaces,
locality tiers,
deck recipes,
and drift beacons are already warm.

This pass focused on a narrower question:

**what should Helm learn about visible derivation and explicit publication/promotion without mistaking either for live truth?**

## 1) CH-SPROJ keeps teaching that derivative surfaces should be bounded and witnessed

`state-projection-schema-v0.md` still provides the cleanest shape for derived truth:

- bounded,
- deterministic,
- keyed,
- digest-friendly,
- and non-authoritative.

That lesson now wants a stronger UI translation inside Helm.
If Helm is going to fill the shell with:

- live lenses,
- view decks,
- deck recipes,
- drift beacons,
- and preview-adjacent compact surfaces,

then those surfaces need a small visible way to say what they are derived from.

That pressure is what a **derivation strip** answers.
A derivation strip is not the stronger source.
It is the compact shell-owned witness that says:

- what the current surface is derived from,
- which exact subject or basis it is anchored to,
- whether the surface came from a recipe or one-off materialization,
- what locality tier it currently inhabits,
- and whether any drift/change cue is already known.

## 2) Approval-basis posture sharpens the case for derivation witness

`approval-basis-posture-v0.md` keeps teaching a brutal but healthy rule:

old review should not silently follow newer mutable basis.

That is not only a consent or validator lesson.
It is a shell-design lesson.
A derived surface that depends on:

- one reviewed basis,
- one remembered subject,
- one saved query,
- one imported object,
- or one materialized deck recipe,

should say so clearly.
Otherwise Helm risks recreating the same old lie in prettier form:
"this surface still feels familiar, so it must still mean the same thing."

A derivation strip is the lightweight answer.
It keeps exact basis and source visible without turning every surface into a giant inspector.

## 3) View replication boundary teaches that travel is not activation

`view-replication-boundary-v0.md` may be the clearest teacher for the second move in this pass.
Its core refusal is simple:

replicated view information may exist,
but it does not auto-activate local bindings.

That maps almost directly onto Helm's next shell luxury.
Helm increasingly wants to let people carry useful things upward:

- a local deck recipe,
- a saved lens arrangement,
- a command dock item,
- an exact action key,
- a shared or exportable view cluster,
- a published investigation surface.

But SlopOS keeps reminding us that movement across scope is not the same thing as local activation.
That is why Helm should treat these moves as an explicit **publication ladder**.
The ladder is not about ambient sync.
It is about deliberate promotion across tiers such as:

- personal/local,
- activity-local,
- portable/exportable,
- shared/team,
- and where appropriate public/published.

## 4) AttrFS and saved-query posture keep pointing toward shell-owned publication rather than app folklore

`rfcs/0100-attribute-query-predicates-and-smart-folders.md` and the surrounding query/view posture keep the good part of saved-search systems:

- queries are explicit,
- scope is view-bound,
- and results do not escape the granted reach just because a query exists.

That is exactly the kind of discipline Helm needs if it starts letting users publish or share derived shell surfaces.
A publication ladder should therefore make publication explicit about:

- the exact subject family,
- the visible filter or recipe basis,
- the locality tier transition,
- and the permissions/visibility that changed.

The point is not just to "share a view."
The point is to keep the publication step itself truthful.

## 5) OpenURI and safe-open materialization boundaries keep the export lesson sharp

`openuri-materialization-boundary-v0.md` and `open-untrusted-materialization-boundary-v0.md` keep teaching a broader anti-smuggling rule:

- preview is not materialization,
- materialization is not live aliasing,
- export-out is a second workflow,
- and a stable local copy should not quietly impersonate the original live object.

That pressure cashes out beautifully for Helm.
A publication ladder should not be:

- secret sync,
- hidden write-through,
- or magical team-shared liveness.

It should be an explicit stronger step with an inspectable before/after story.

## 6) The datacube lesson is now more about witness and promotion than about size

This pass makes the datacube reading sharper again.
The real lessons are now:

- explicit projections,
- explicit view objects,
- explicit locality,
- explicit materialization,
- explicit compared basis,
- and now explicit derivation + publication witness.

That is still a much better teacher than "build a giant cube."

## 7) Strongest Helm payoffs from this pass

### Derivation strips

Derivation strips now look like the smallest high-leverage move for helping Helm's compact luxuries stay honest.
They should pair especially well with:

- live lenses,
- view decks,
- deck recipes,
- drift beacons,
- preview rails,
- basis packets,
- and materialization bays.

The first cut should stay tiny:

- exact source or subject witness,
- basis or recipe witness when relevant,
- locality badge,
- drift/change cue when relevant,
- and jump/inspect/compare/materialize actions.

### Publication ladders

Publication ladders now look like the right way to cash out locality tiers.
They turn vague share/sync/export behavior into one explicit shell-owned next-step ladder.

The first cut should stay small too:

- local → activity-local → portable/exportable → shared,
- visible scope/visibility delta,
- one receipt or witness of what changed,
- and explicit refusal for surfaces that must remain local-only.

## What this pass changes

- it adds **derivation strips** as a new warm Helm move
- it adds **publication ladders** as a new warm Helm move
- it strengthens the reading of SlopOS's datacube as a teacher of **projection + basis witness + locality + publication/materialization discipline**
- it keeps drift beacons,
  deck recipes,
  view decks,
  and materialization bays warm,
  but now with sharper support from view-replication and approval-basis discipline

## What this pass still does not justify

- a giant omniscient cube UI
- ambient sync as a shell default
- a universal shared-workspace constitution
- auto-activation of published or replicated views
- adding more pillars

## Current bounded take

**Helm should keep reading SlopOS's datacube as a teacher of bounded projections,
exact basis witness,
explicit locality,
explicit materialization,
and explicit publication/promotion seams.
That pushes Helm toward derivation strips and publication ladders without justifying a giant cube,
ambient sync,
or shared live-state mythology.**
