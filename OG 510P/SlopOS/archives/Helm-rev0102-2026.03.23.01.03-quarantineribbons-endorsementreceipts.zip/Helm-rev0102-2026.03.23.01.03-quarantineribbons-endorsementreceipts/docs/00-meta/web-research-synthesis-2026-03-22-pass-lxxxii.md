# Web research synthesis — 2026-03-22 — pass LXXXII

Question for this pass:
**what outside ideas strengthen Helm's datacube if we want more power and more delight without a bigger constitution?**

Answer:
make rollback normal with generation cards,
make sharing narrower with attenuated links,
and make portability travel as recipes rather than live grants.

## 1. Nix keeps proving that generations make rollback feel normal instead of scary

Nix profiles exist to support different configurations,
**atomic upgrades and rollbacks**,
and explicit generations.
The rollback command simply switches to the previous generation,
and old generations can later be garbage-collected by policy.

That is a great shell lesson.
Helm should not reserve rollback dignity for OS images or package systems.
If a strong shell object changes materially,
it should be possible to:
- see the current generation,
- compare it to the previous one,
- select an older one,
- and prune history by policy rather than by panic.

This is especially attractive for:
- saved views,
- front doors,
- deck recipes,
- promoted landing artifacts,
- and portable capability recipes.

## 2. Docker keeps sharpening pinned versus floating truth

Docker image digests are immutable content identifiers,
while tags are optional identifiers that can be reused or changed,
and default to `latest` when omitted.

That is basically a perfect reinforcement of Helm's handle stance.
A shell subject often wants one of two postures:
- **exact generation / exact reviewed basis**
- **floating alias that intentionally follows current truth**

Helm should stop making those look interchangeable.
A generation card can work like a digest.
A front-door alias can work like a tag.
Both are useful,
but only one is exact.

## 3. AWS S3 presigned URLs are a strong model for attenuated reveal links

An S3 presigned URL remains valid only for a specified period,
and it expires early if the underlying credential is revoked,
deleted,
or deactivated.

That is a brilliant pattern for Helm Exchange.
A shell share link should often be:
- exact-subject
- narrowly scoped
- time-bounded
- revocable
- obviously weaker than granting broad durable access

This is a much healthier default than pretending every share needs to be either private forever or public forever.

## 4. Tailscale keeps clarifying that sharing one resource is not the same as sharing the whole machine

Tailscale Serve shares a local service with the rest of the tailnet.
Funnel exposes a local service to the public internet.
And device sharing is a different thing again,
meant for sharing a specific device with a specific person in a quarantined way.

That exposure ladder is exactly the kind of honesty Helm needs.
Exchange should clearly separate:
- local-only
- named/private cohort
- org/tailnet
- guarded link
- public
- whole-device / whole-workspace style sharing

A link to one saved view or one exact generation should not masquerade as broad workspace access.

## 5. VS Code Profiles are a good model for portable recipes rather than live state mythology

VS Code Profiles collect customizations,
can be created,
managed,
switched,
shared,
and imported,
but they are still profile objects rather than claims about the current runtime contents of every window.

That is a good inspiration for Helm capability recipes.
A recipe can say:
- which starter or front door this is,
- which saved views or tools it prefers,
- which handles it hopes to reacquire,
- which grants may need to be requested again,
- which generation it came from,

without pretending it already *is* current live truth.

## 6. What to steal now

- **generation cards and rollback rails**
- **digest-vs-tag honesty** as a stronger version of pinned-vs-floating handles
- **attenuated reveal links** with expiry and revocation posture
- **exposure ladders** that keep one-resource sharing separate from broader sharing
- **capability recipes** that are portable and helpful without impersonating live grants

## 7. What to steal carefully

- aggressive retention policies that make rollback disappear too quickly
- share links that outlive the operator's understanding of them
- public-link convenience that quietly bypasses narrower reveal classes
- profile/recipe import that smuggles hidden live state or durable broad access

## 8. What to resist

- one generic “share” state that hides audience,
  duration,
  and subject exactness
- one generic “reopen” state that hides generation versus floating alias posture
- recipe objects pretending to be current live authority
- rollback only appearing after disaster instead of as a first-class everyday tool

## Synthesis for Helm

The next delightful shell law is not harder AI or a bigger cube.
It is a calmer,
cleaner grammar:
- **current live**
- **exact generation**
- **floating alias**
- **attenuated link**
- **capability recipe**

If Helm makes those five things obvious,
a lot of the datacube suddenly becomes much more trustworthy and much more fun.
