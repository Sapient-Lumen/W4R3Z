# Web research synthesis — 2026-03-22 — pass XXXVIII

Purpose: keep collecting brilliant Helm ideas while getting stricter about **where the shell should insert a humane middle state** between weak inspection and strong adoption.

This pass focused on one question:

**what is the missing shell grammar between preview and live truth?**

## Main takeaway

The answer is now clearer than before:

Helm's strongest proof bets are still:

1. **saved view objects**
2. **checkpoint branches**

But the outside world is now strongly suggesting a reusable **middle-state stack** that makes those objects actually excellent:

1. **preview-promotion ladders**
2. **landing rehearsals and arrival overlays**
3. **materialization bays**
4. **imported-surface trust posture**

These should not become new pillars.
They should become a reusable shell grammar for moving from weak contact to stronger local truth.

## What the outside world is validating now

### 1. Views are real objects, not filter residue

Notion's current docs now make views explicit first-class API resources and let integrations programmatically manage the same view presets users create in the UI.
That is strong validation that Helm should keep treating a saved view as a real shell object rather than as ambient filter state.

Airtable validates the complementary publication story:
a view can be shared,
sync-enabled,
or fed into a more governed verified-data path,
without pretending those are the same move.
That is exactly the kind of publication-strength ladder Helm wants for views,
decks,
and other shell luxuries.

### 2. Trust posture should be explicit and reversible

VS Code's Workspace Trust docs remain one of the best current proofs that imported or uncertain material should often begin in a weaker posture.
Restricted Mode is not failure;
it is a useful intermediate state before stronger trust is granted.
That is very close to what Helm wants for imported view objects,
checkpoint-derived branches,
shared dock items,
and other landed shell structure.

### 3. Checkpoints and branches work best when restore and fork are visibly different

VS Code's checkpoint docs explicitly treat restore as a separate act that reverts the workspace to an earlier state.
Figma's branch review/merge flow adds a second useful lesson:
branches are compared,
reviewed,
and approved against a basis instead of quietly drifting back into the main line.
Together these keep reinforcing the same Helm law:
checkpoint,
compare,
restore,
and fork should stay distinct.

### 4. Compact accelerators are great when their locality and share strength stay honest

Raycast continues to separate imported/shared quicklinks and snippets from private/local ones.
PowerToys Workspaces continues to validate that saved launch structure is useful precisely because it is openly a launch recipe rather than fake live continuity.
Warp is teaching the same thing from a terminal angle by separating launch configurations,
session navigation,
and session restoration.

### 5. Great shells offer a humane middle state between preview and adoption

Arc Peek,
Apple Quick Look,
and Spotlight validate a lightweight inspect surface with meaningful nearby actions.
But the stronger signal in this pass is that preview alone is not enough.

Figma shows compare-before-merge and overlay comparison.
VS Code profiles show preview/import rather than instant takeover.
Obsidian shows database-like bases/views,
saved workspaces,
and local workspace residue kept separate on disk.

Taken together,
these products keep pointing to the same missing Helm move:

**after preview, but before adoption, there should often be a compact compare/rehearse/materialize step.**

## Ideas now worth stealing

### Tier 1 — steal now

1. **An honest arrival stack**
   - preview
   - compare/overlay or rehearse locally
   - materialize/adopt explicitly
   - then claim ordinary local or live truth

2. **Landing rehearsals**
   - imported or portable shell structure should often be able to render provisionally on the receiver before adoption

3. **Arrival overlays**
   - one incoming subject against one exact basis or one explicit local candidate
   - typed difference classes matter more than giant visual theater

4. **Materialization bays**
   - weak or derived surfaces need an explicit place to become stronger without laundering that stronger act through preview or query results

### Tier 2 — steal soon, but keep the contract modest

1. **view decks composed from saved view objects**
2. **deck recipes as reusable starters rather than live continuity claims**
3. **personal/shared/published accelerator bands**
4. **compact compare tickets and basis witnesses for longer review flows**

### Tier 3 — keep warm only

1. universal workspace portability mythology
2. giant dashboard constitutions
3. giant sync constitutions
4. “everything is a branch” or “everything is a workspace” religion

## Judgment for Helm

Helm should still avoid adding pillars.

The better move now is to make the shell's strength ladder explicit:

- **saved view objects** and **checkpoint branches** remain the leading proof targets
- **preview-promotion ladders** and **imported-surface trust posture** remain the first support laws
- and **materialization bays** plus **landing rehearsal / arrival overlay** now look like the next humane support stack worth warming in earnest

That is probably the highest-leverage way to make Helm feel super awesome without lying about adoption,
continuity,
trust,
or liveness.
