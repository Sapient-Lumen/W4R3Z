# Basis packet candidate contract v0

Purpose: explore one compact shell-owned move for saying what exact reviewed basis a strong action or continuity-affecting action still depends on,
and whether that basis still matches.

A **basis packet** is a tiny shell-owned witness strip,
chip cluster,
or small card.
It does not replace a binding witness,
scope witness,
or continuity choice witness.
It complements them by answering a narrower question:

**what exact reviewed basis still authorizes this stronger action,
and does that basis still match?**

This is a candidate move, not a freeze.

## Candidate shape

A first useful basis packet would likely include:

1. **Action or continuity subject**
   - one exact shell-owned reference to the thing the user is about to do

2. **Basis source**
   - one source object,
   receipt,
   proposal,
   entry kit,
   or cockpit relation

3. **Exact basis witness**
   - one or more of:
     - object id / digest,
     - revision / epoch,
     - live-target ref,
     - route witness id,
     - destination digest,
     - authority digest

4. **Compare result**
   - `match`
   - `drifted`
   - `partial`
   - `unknown`

5. **Freshness / observation note**
   - when the basis was last observed,
   if that matters for the action story

6. **Allowed action ladder**
   - inspect basis
   - review again
   - fresh bind
   - hold
   - inspect historical receipt
   - only explicit override paths if a future surface earns them

## Guardrails

1. **Not a giant permission dashboard**
   - a first basis packet should stay tiny.

2. **Not a reusable approval cache**
   - the packet describes the current basis posture;
   it does not mint evergreen approval.

3. **Not a universal version algebra first**
   - the first packet can stay narrow and shell-local.

4. **Not mandatory on every tiny action**
   - exact low-risk moves can stay light.
   - this matters when actions are strong,
   continuity-bearing,
   or mutate important state.

5. **No hidden override laundering**
   - if a future surface admits a force path,
   that should remain visibly stronger than ordinary proceed.

## Why this looks promising

Helm is accumulating several saved/planned/task-return luxuries:
- activity entry kits,
- activity cockpits,
- binding witnesses,
- activity scope witnesses,
- continuity choice witnesses,
- route/rehearsal cards,
- and stronger Recall cues.

A tiny basis packet looks like the cheapest way to stop those luxuries from turning past review into a floating latest-state permission story.

It also gives Helm another unusually good kind of magic:

**a task-return surface that can tell you not only what it found,
how it rejoined,
what scope counted,
and who chose the substitute,
but also whether the next strong action still rests on the exact thing you reviewed.**

## First proof-bearing specimen

A narrow specimen would be enough:

- one exact-match basis packet that allows proceed,
- one stale-basis packet that requires review again,
- one historical packet that downgrades to inspect-only,
- and one partial/unknown packet that opens a hold or fresh-bind ladder.

## Failure modes to avoid

- basis chips that still hide the real compared object
- saved or historical objects that look permanently approved
- a giant compare-and-set bureaucracy before one tiny witness exists
- basis packets that duplicate receipts or binding witnesses without adding fresh truth

