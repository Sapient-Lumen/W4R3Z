# Authority window candidate contract v0

Purpose: give Helm one compact shell-owned object for **bounded temporary or scoped authority** so stronger shell acts stop hiding permission duration inside provider dialogs, session folklore, or remembered status chrome.

This is intentionally narrow.
It does **not** design a full IAM system, policy engine, or universal admin console.
It only gives Helm one truthful object for “what authority exists here right now or recently existed here, under what bounds?”

## Contract

An **authority window** is a shell-owned bounded grant object that records one explicit authority relation with visible scope and lifetime.

At minimum it should be able to say:
- **authority family**
  - file write
  - browser action
  - connector/source access
  - tool execution
  - route/apply
  - background/helper continuation
- **holder**
  - operator direct act
  - one ask/loadout
  - one activity spine
  - one isolated side lane / shadow lane / worktree-like lane
  - one named persistent scope
- **subject / target class**
  - exact object,
  - exact provider,
  - exact route family,
  - exact activity,
  - or explicit bounded family
- **grant rung**
  - once,
  - this-time,
  - current session,
  - activity-scoped,
  - isolated-lane scoped,
  - persistent-until-revoked,
  - or another shell-defined bounded rung
- **reviewed basis relation**
  - what exact reviewed basis or action family this window depends on,
  - if any
- **issuer / authorship posture**
  - granted by operator,
  - delegated through reviewed policy,
  - imported and weakened,
  - renewed,
  - or re-acquired fresh
- **start posture and expiry posture**
  - active now,
  - expiring soon,
  - expired,
  - revoked,
  - basis drifted,
  - or historical-only
- **current-live relation**
  - whether a current-live beacon confirms the window is live now,
  - or whether this object is only historical evidence
- **revoke / narrow / reacquire next moves**

## Truth posture

### 1. Issuance is not current live authority

A historical authority window may remain useful for Recall,
inspection,
audit,
and explanation.
But it must not impersonate a current-live grant unless a stronger live witness confirms that status.

### 2. Widening requires a fresh stronger step

Renewal or retry must not silently widen:
- once → activity,
- activity → persistent,
- isolated lane → live lane,
- or narrow subject → broad family.

### 3. Basis drift can demote or expire the window

If the reviewed basis changed materially,
Helm may:
- expire the window,
- downgrade it to inspect-only,
- or require a fresh grant.

It should not silently let the old window float forward.

### 4. Isolation can justify broader temporary scope

A broader window may be acceptable inside an explicit isolated side lane where the live lane would not accept the same rung.
This must stay visible.

### 5. One object, not giant policy religion

The first proof only needs enough structure to make stronger shell acts honest.
It does not need a universal permission subsystem.

## Likely surfaces

- **Omnibox** for run/apply/open-with-stronger-authority asks
- **Operations Center** for current grants, expiry, revoke, and unusual posture
- **Desktop Flow** for helper/tool/controller power inside a flow or activity
- **Recall** for historical-vs-current authority honesty on reentry
- **Exchange** for app-link / source / import / handoff permission posture

## First proof target

A good first specimen would probably be:
- one source/tool/browser/file authority family,
- one live-lane ask,
- one isolated-lane alternative,
- three or four rungs,
- and one obvious current-live beacon plus revoke path.

That is enough to learn whether Helm can make temporary authority feel **awesome, brave, and honest** without ambient permission creep.

## This revision

This revision keeps the contract warm because current teachers increasingly separate subject scope, duration, inspect-only posture, isolation, and revoke. Helm should prove one small family rather than a giant permission center.
