# Condition strip candidate contract v0

Purpose: give Helm one compact shell-owned way to express **several small state classes over one exact subject** without building a giant status center or collapsing everything into one flattering badge.

A **condition strip** is not a receipt.
It is not a policy engine.
It is not a full event log.
It is the shell-owned answer to:

**what compact status classes are currently known for this exact subject?**

## Candidate posture

### 1. Condition strips belong to one exact subject
A condition strip belongs to one exact thing such as:
- this exact saved view
- this exact watched route
- this exact stronger act row
- this exact reveal window
- this exact imported surface
- this exact recall card

It does not mean “everything about this provider” or “overall health everywhere.”

### 2. Several small truths should stay visibly different
A first useful strip should be able to keep classes such as these visibly separate:
- ready
- progressing
- waiting
- restricted
- degraded
- suspended
- stale
- muted
- teardown-requested
- unknown

Not every strip needs every class.
The point is that the shell should stop compressing unrelated truths into one vague icon.

### 3. Condition rows should remain typed
A row should name what it is about,
for example:
- readiness
- progression
- restriction
- freshness
- delivery/mute posture
- teardown posture
- visibility/exposure posture

This keeps “muted” from impersonating “healthy,”
and “restricted” from impersonating “broken.”

### 4. Strips should stay projection surfaces
A strip summarizes bounded shell truth.
It does not replace:
- effect receipts
- action warrants
- access verdict cards
- change cursors
- current-live leases
- or full diagnostic records

### 5. Parent-child inheritance must be explicit
A strip should not silently absorb the health or failure of children unless a surface contract says it should.
“Worst child wins” is a special rule,
not a default law.

## Candidate minimal shape

A first useful condition strip likely needs:
- exact id
- owner surface id
- exact subject refs
- condition rows
- optional compact summary class
- visibility_gap posture when the shell cannot inspect enough to claim more
- optional observed-basis relation
- observed_at

## Best first homes

- one Operations row for a long-running stronger act
- one Browser row for a saved view or watchpoint
- one Recall card showing historical or stale status without pretending live truth
- one Exchange row for reveal / route / publish posture
- one imported-surface card showing restricted-first posture

## Guardrails

1. **No one green dot as the whole story**
2. **No giant event feed hiding behind a strip**
3. **No silent inheritance from child surfaces**
4. **No treating muted as healthy or historical as live**
5. **No replacing receipts and verdicts with pretty chrome**

## Working stance

Condition strips now look like the missing compact status grammar for many already-warm Helm moves.
They let the shell say something much more honest:

**this exact thing is restricted,
progressing,
stale,
muted,
or pending teardown in these exact small ways,
without pretending that all those meanings are the same.**
