# Local overlay candidate contract v0

Purpose: define the smallest shell-owned local/activity/device-specific overlay that can layer on top of a portable core so Helm can stay personal,
fast,
and ergonomic **without** smuggling that local state into packets,
exports,
or shared surfaces by surprise.

A **local overlay** is the rebuildable local delta attached to a portable core after inspection,
materialization,
rebind,
or adoption.
It should compose with portable cores,
handoff packets,
publication ladders,
command docks,
view decks,
and exact action keys.

## Why this move now

Helm increasingly wants portable surfaces,
but the best parts of a shell are often stubbornly local:

- dock placement,
- local keyboard shortcuts,
- account/profile/session selection,
- device-specific layout,
- trust posture,
- per-activity pinning,
- and other convenience state.

Current tools keep validating this split.
Helm now needs an honest home for those local deltas.

## Candidate shape

A first useful local overlay would likely include:

1. **Target core witness**
   - portable core id
   - packet id
   - recipe id
   - exact action key id
   - or another admitted source handle

2. **Overlay scope**
   - personal/device-local
   - workspace-local
   - activity-local
   - machine profile local
   - or another explicit admitted tier

3. **Local binding choices**
   - placement / dock edge / tile preference
   - local shortcut
   - provider/account/profile/session choice
   - preferred receiver object
   - local layout tweaks

4. **Local-only policy or trust posture when relevant**
   - restricted / trusted / hold
   - inspect-only default
   - machine-specific permission posture
   - local refusal notes

5. **Residue / drift notes when relevant**
   - stale local binding
   - missing local provider
   - local override diverged from base/core
   - local residue can be rebuilt or cleared

6. **Tiny next actions**
   - inspect core
   - compare overlay against core
   - rebind
   - clear local residue
   - copy into a new activity-local overlay
   - explicitly promote some portion onward if ever allowed

## Rules that matter

### 1. A local overlay is not the portable core
The overlay should be visibly derivative and scoped.
It should not replace the core's portable identity.

### 2. Local overlays must not travel by accident
Exporting,
sharing,
or packetizing a surface should not silently drag along:

- secrets,
- trust posture,
- local session choices,
- device-private placements,
- or other overlay-only state.

### 3. Receivers should be able to rebuild overlays independently
Two receivers may share the same portable core and still create very different local overlays.
That is not drift in the bad sense.
It is a healthy local-first property.

### 4. Overlays should be cheap to discard and recreate
A good local overlay should feel like rebuildable local convenience,
not like irreplaceable hidden truth.
If it breaks,
the shell should still retain the stronger portable core.

### 5. Some overlays may remain activity-local only
An activity-local overlay can be extremely useful without ever becoming personal-global,
portable,
or shared.
Refusal to travel is part of the contract.

## Best first homes

- command dock arrangement per device
- exact action key local shortcut/profile bindings
- deck or lens placement tweaks per workspace/activity
- activity-local pins derived from a portable entry kit
- launch-configuration overlays that choose local paths,
  shells,
  or profiles

## What this is not

- not a secret sync layer
- not a hidden per-device fork of the portable core
- not an excuse for fragile ambient state
- not a replacement for publication ladders when something really should travel
- not proof that old local residue is still current or healthy

## A good first proof slice would show

- one portable deck recipe with two different local overlays on two receivers,
- one exact action key whose shortcut and profile remain overlay-only,
- one activity-local overlay that refuses broader publication,
- and one compare/clear/rebind path when the local overlay goes stale.

## Why this seems worth keeping warm

Local overlays now look like the honest place for the shell's most delightful local conveniences.
They let Helm stay personal and ergonomic,
while keeping portable cores,
packets,
and published surfaces much more truthful.
