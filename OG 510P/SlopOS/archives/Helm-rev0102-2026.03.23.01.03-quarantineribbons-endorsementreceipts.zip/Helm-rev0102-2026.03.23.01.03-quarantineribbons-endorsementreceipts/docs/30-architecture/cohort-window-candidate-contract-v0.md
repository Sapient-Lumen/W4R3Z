# Cohort window candidate contract v0

Purpose: give Helm one compact shell-owned object for **exact admitted subject cohorts** so asks, reveals, exports, routes, and stronger acts stop quietly widening from one selected subset into one whole account, workspace, view family, or provider.

This is intentionally narrow.
It does **not** design a giant governance suite, query planner, or ACL studio.
It only gives Helm one truthful object for:

**what exact subset is this bounded act actually about right now?**

## Contract

A **cohort window** is a shell-owned bounded subject-set object that records one explicit admitted cohort with visible source, strength, and lifetime.

At minimum it should be able to say:
- **cohort family**
  - exact object
  - selected object set
  - saved-view result slice
  - selected rows/cards/items from a view
  - selected watchpoints/glances/brief inputs
  - imported packet slice
  - explicit bounded provider subset
- **source posture**
  - selected manually now
  - inherited from loadout
  - inherited from saved view result
  - imported and weakened
  - broadened explicitly
  - provider-limited / chooser-limited
- **subject witness**
  - exact ids or stable refs where possible
  - exact view / filter / basis ref where cohort is derived
  - explicit count when individual refs are too many for the primary strip
- **cohort strength**
  - one item
  - small explicit selected set
  - saved exact result slice
  - activity-local cohort
  - wider family
- **relation to other shell truth**
  - authority window if power exists
  - reveal window if visibility exists
  - basis stamp if exact reviewed basis matters
  - loadout if a broader ingredient bundle exists
- **freshness / decay posture**
  - current selection
  - saved exact cohort
  - stale until reselect/revalidate
  - provider can no longer honor exact subset
  - historical-only
- **current-live relation**
  - whether a stronger current-live witness confirms that this exact cohort is still admitted now
- **broaden / narrow / reselect next moves**

## Truth posture

### 1. Exact cohort is not whole-family truth
A selected file,
selected result slice,
or selected watchpoint set does not imply the whole project,
provider,
workspace,
or account family.

### 2. Loadout is broader than cohort
A loadout says what ingredients are in play for a bounded act.
A cohort window says what exact subject subset the act is actually bound to.
The two are related but not identical.

### 3. Authority and reveal do not erase cohort
A broad authority or broad audience relation may exist,
but Helm should still be able to say that this exact act is operating on a smaller exact cohort.

### 4. Retry should not silently widen
If the exact cohort fails,
drifts,
or becomes unavailable,
Helm should prefer:
- reselect,
- revalidate,
- or explicit broaden

rather than quietly switching to a wider family.

### 5. Persistence should preserve exactness where possible
Saved or carried cohorts should keep their exact witness when possible,
even if current-live admission later expires.

## Best first homes

- Exchange export / handoff over selected objects
- Omnibox ask / compare over selected current items
- Recall compare over one exact saved-view slice
- claim envelopes where a result only covers a bounded selected cohort
- reveal windows where only one redacted or selected slice is exposed
- action warrants where the act should preview exact blast radius

## What this is not

- not a giant governance product
- not a full query language
- not a universal row-level security engine
- not a substitute for authority windows or reveal windows
