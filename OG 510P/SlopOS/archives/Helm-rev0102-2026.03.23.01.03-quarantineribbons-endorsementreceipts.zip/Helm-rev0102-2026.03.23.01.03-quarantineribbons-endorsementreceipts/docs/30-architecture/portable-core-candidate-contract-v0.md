# Portable core candidate contract v0

Purpose: define the smallest travel-safe shell-owned core for a saved or derived surface so Helm can export,
share,
hand off,
and restore useful shell luxuries **without** bundling local secrets,
local trust,
or fake live state.

A **portable core** is the subset of a surface that may travel honestly.
It should compose with handoff packets,
promotion receipts,
publication ladders,
view decks,
exact action keys,
and deck recipes.

## Why this move now

Helm now has several warm moves that look portable:

- deck recipes,
- exact action keys,
- command dock items,
- activity entry kits,
- flow fragments,
- and some view-deck starters.

Handoff packets answered **how** a surface can travel.
Portable cores answer the sharper question:

**what exact portion is allowed to travel at all?**

## Candidate shape

A first useful portable core would likely include:

1. **Exact surface/subject witness**
   - surface family
   - subject id / recipe id / key id / deck id
   - or another admitted shell-owned handle

2. **Travel-safe structure**
   - layout/view recipe
   - query/filter/sort structure
   - command/action target class
   - route family
   - or other structure that survives travel without claiming live local binding

3. **Derivation / basis witness when relevant**
   - derivation strip fields
   - recipe witness
   - compared-from id
   - revision / digest / epoch witness
   - or another compact basis story

4. **Allowed affordance class**
   - inspect only
   - materialize locally
   - install as local shortcut/pin
   - adopt into one activity
   - compare against local basis
   - or another bounded next move

5. **Portability / redaction class**
   - portable as-is
   - portable with redaction
   - recipe-only
   - inspect-only
   - export refused

6. **Compatibility witness when relevant**
   - version
   - provider family requirement
   - missing-local-overlay expectation
   - or other compact compatibility cues

## Rules that matter

### 1. A portable core excludes local overlays
A portable core should not silently include:

- local secrets,
- trust decisions,
- account/profile/session choice,
- device-specific placement,
- local window reuse state,
- recent-item residue,
- or other local mutable baggage.

### 2. The same core may materialize differently on different receivers
That is healthy.
Travel-safe sameness should not require identical local overlays.
Different receivers may create different pins,
placements,
profiles,
or trust posture from the same portable core.

### 3. A portable core is weaker than live local state
It may be enough to inspect,
compare,
or start materialization.
It is not proof that the receiver already has current live bindings.

### 4. Some families should refuse portable cores entirely
Examples that often should stay local-only or heavily constrained:

- clipboard history,
- raw lane convenience state,
- credentials,
- trust caches,
- device-private presence,
- some delegated/background candidate work.

### 5. Portable cores should compose cleanly with packets and receipts
A handoff packet can carry a portable core.
A promotion receipt can name which portable core crossed tiers.
Receiver-side overlays should still remain explicit.

## Best first homes

- deck recipes
- exact action keys
- command dock items/bands
- activity entry kits
- flow fragments that travel as recipes
- view-deck starters

## What this is not

- not a live-state snapshot format
- not a portable secret bag
- not a universal sync schema
- not a guarantee of identical receiver-side behavior
- not a substitute for trust,
  review,
  or materialization

## A good first proof slice would show

- one deck recipe reduced to a portable core,
- one exact action key whose local shortcut/profile/session choices stay out of the core,
- one refusal case for a family with no honest portable core,
- and one receiver-side materialization path that creates a fresh local overlay.

## Why this seems worth keeping warm

Portable cores now look like the missing internal discipline behind handoff packets.
They let Helm move useful shell structure around,
while keeping local residue,
local trust,
and local convenience from masquerading as universal shared truth.
