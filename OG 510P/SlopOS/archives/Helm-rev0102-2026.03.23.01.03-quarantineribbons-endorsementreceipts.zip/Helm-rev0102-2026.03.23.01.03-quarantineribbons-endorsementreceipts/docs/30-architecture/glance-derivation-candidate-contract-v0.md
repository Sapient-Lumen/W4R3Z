# Glance derivation candidate contract v0

Purpose: give Helm one compact shell-owned **derived summary object** so saved views, review tickets, subscriptions, watchpoints, Recall, and Overview can show tiny useful state without pretending a summary card is the same thing as the exact source view or current-live truth.

A **glance derivation** is a bounded derivative object computed from:
- one exact saved view object,
- or one exact review ticket.

It is deliberately smaller than the source.

## Candidate shape

A first useful glance derivation would likely include:
- exact id
- source kind and exact source ref
- source basis or cut witness
- derivation recipe kind
- freshness / expiry posture
- cut time
- locality / trust posture
- current summarized payload
- open-source / refresh / inspect actions
- last-delivery or last-refresh receipt when relevant

## Candidate recipe kinds

Keep the first version small.
For example:
- count
- count-by-state bucket
- threshold state
- top-N summary
- delta since basis or prior fire
- degraded / unavailable / unauthorized / expired status
- tiny trend over one bounded recent window

## Candidate posture

### 1. A glance derivation is not the source view
The source saved view remains the durable recipe-like object.
The glance derivation is the smaller derived summary.

### 2. A glance derivation is not current-live proof
It may summarize something current-enough.
But it does **not** prove:
- current focus
- current completion
- current authority
- or universal live truth

### 3. Source witness must stay nearby
A useful glance should always answer:
- what exact source produced this?
- when was it cut?
- on what basis?
- and how do I open the stronger source lane?

### 4. Freshness and expiry are first-class
A glance may be:
- fresh-enough
- stale
- expired
- basis-missing
- source-unavailable
- degraded by permission/trust posture

The shell should not hide those states behind decorative polish.

### 5. Good glances stay summary-bounded
A glance should not quietly become a raw result dump.
Its payload should stay intentionally small.
Stronger inspection belongs to the source view or a review ticket.

### 6. Watchpoints may render through glances

A watchpoint may use one glance derivation as its tiny card or digest face.
But the watchpoint still owns evaluated state, and the glance still remains a smaller derivative summary.

### 7. Subscriptions may deliver glances
A view subscription may send:
- one glance derivation,
- one digest built from a glance derivation,
- or a last-fired receipt that points at one.

That is healthier than flooding raw results by default.

### 8. Overview may compose glances
Overview can show a few glance derivations next to:
- linked views
- exact front-door handles
- current-live beacons
- one bounded ops slice

But Overview must still keep them visibly derivative from stronger shell truth.

### 9. Imported/shared glances start weaker
If a glance derivation arrives from elsewhere,
it should carry source witness and freshness/trust posture.
It should not silently become receiver-local truth.

## Guardrails

1. **Do not let glance derivations overwrite source-view identity.**
2. **Do not let glance cards masquerade as live truth.**
3. **Do not let glances become giant dashboard tile empires.**
4. **Do not let summary derivation hide freshness or expiry.**
5. **Do not let subscriptions use glances as cover for hidden workflow engines.**
6. **Do not let glance cards hide the distinct state owned by a watchpoint.**

## Good first specimens

- one triage saved view emitting a count-plus-top-three glance
- one at-risk projects saved view emitting a threshold-state glance
- one Recall return showing a stale or expired glance next to the stronger source view path
- one Overview tile built from a glance derivation plus an open-source-view action
- one view subscription that delivers a bounded digest derived from a glance instead of an unbounded result list

## Working stance

Glance derivations now look like one of the most promising support moves for Helm.
They give the datacube a humane glance layer without collapsing saved views, review tickets, subscriptions, and current-live truth into one flattering dashboard story.
