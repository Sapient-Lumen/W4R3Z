# Least-widening preview candidate contract v0

Purpose: give Helm one compact shell-owned way to compare **the smallest plausible stronger deltas** before widening authority,
trust,
route,
or audience.

A **least-widening preview** is not a grant,
not a policy editor,
and not a guarantee of later success.
It is a bounded comparison object for one exact blocked or gated act.

## Candidate posture

### 1. The preview belongs to one exact blocked or gated act
A least-widening preview should always attach to:
- one exact subject
- one exact requested stronger act
- one exact current lane or holder posture

It should not become a generic recommendation engine.

### 2. Candidate deltas stay explicit and ordered
A good first candidate family now looks like:
- inspect only
- current-only grant
- exact-subject grant
- guarded-link instead of public
- isolated-lane execution
- activity-scoped widening
- persistent widening
- no honest candidate / unsupported

### 3. Results should separate likely-admit,
likely-still-block,
and cannot-simulate-honestly
A preview should be allowed to say:
- likely admits
- likely still blocked
- blocked by a different stronger gate
- cannot evaluate without hidden policy or provider truth

That is much better than a fake precise answer.

### 4. The narrowest viable candidate should be visible
The operator should not have to inspect every option to discover the smallest rung that likely changes the answer.
But Helm should still show the broader rungs nearby so the operator can see what is being avoided.

### 5. Live and simulated truth must remain separate
A positive least-widening preview is not a live lease window,
not a passed gate,
and not an effect receipt.
The shell must keep that distinction visible.

## Candidate minimal shape

A first useful least-widening preview likely needs:
- exact id
- linked verdict card or blocked act id
- exact subject refs
- current lane / holder posture
- candidate delta rows
- per-row result class
- narrowest_viable_row when one exists
- visibility_gap posture
- simulation_scope posture
- observed_at

## Best first homes

- one blocked publish act comparing guarded-link,
  cohort,
  and public rungs
- one blocked helper-backed mutation comparing inspect-only,
  isolated lane,
  and live-lane widening
- one blocked exact-handle reopen comparing current-only,
  exact-subject,
  and persistent renewal
- one blocked adoption act comparing restricted inspect,
  rehearsal lane,
  and live adopt

## Guardrails

1. **No auto-apply of the chosen delta**
2. **No hiding broader alternatives**
3. **No pretending policy-side success implies runtime success**
4. **No turning least-widening into a giant optimizer or policy language**
5. **No skipping stale-basis,
   trust,
   or route blockers just because grant widening looks promising**

## Working stance

Least-widening previews now look like the humane sibling of budgets,
lease windows,
and renewal rails.
They let Helm say:

**here are the smaller ways this exact act could become possible,
this is the narrowest honest one,
and this preview is still weaker than the live grant itself.**
