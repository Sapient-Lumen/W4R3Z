# Linked view candidate contract v0

Purpose: let Helm reuse one saved view object inside other shell surfaces **by reference** without copying its law, hiding its provenance, or pretending the borrowed appearance is a new authority domain.

A **linked view** is a shell-owned borrowed presentation of one exact saved view object.
It may appear inside:
- an activity entry kit
- a view deck
- Overview
- a cockpit card
- a triage lane
- or another bounded shell surface

This is a candidate move, not a freeze.

## Candidate posture

### 1. Linked means by reference, not by copy
- the source saved view object remains the primary view law
- the linked appearance points back to that exact source
- duplication should be an explicit stronger act,
  not the default meaning of embed/borrow/link

### 2. Source and basis stay visible
A linked view should be able to reveal:
- source saved view id
- source subject family or explicit query basis
- source locality/trust posture
- source revision/basis relation where relevant
- local wrapper surface that is borrowing it

### 3. Local framing may exist, but it stays wrapper-level
A borrowing surface may add bounded framing such as:
- preferred placement
- compact vs expanded layout
- nearby compare action
- nearby triage action
- nearby front-door handle
- wrapper-local notes or warnings

Those wrapper additions must not silently rewrite the meaning of the source view itself.

### 4. Linked views degrade honestly
If the source becomes:
- missing
- stale
- unauthorized
- imported-restricted
- or basis-drifted

then the linked appearance should degrade honestly rather than pretending it is still ordinary local truth.

### 5. Linked views do not auto-materialize stronger local truth
Borrowing a view into a new surface must not by itself:
- adopt it as local default truth
- publish it
- sync it
- import it as a new local object
- or activate stronger receiver-local bindings

Those remain separate explicit acts.

### 6. Hierarchy may be preserved inside the linked view
If the source view carries a useful nested or hierarchy-preserving presentation,
that is a property of the linked view.
It should not force the borrowing surface into a new universal hierarchy ontology.

### 7. Linked views compose with existing Helm moves
Especially with:
- saved view objects
- activity entry kits
- view decks
- current-live beacons
- compare surfaces
- triage lanes
- preview rails
- publication ladders

## Good first specimens

- a front door that borrows one saved triage view
- a deck that borrows one compare view and one work view
- Overview borrowing one live-ish object view plus one ops slice

## Guardrails

1. **Do not treat linked view as copied data.**
2. **Do not hide source and wrapper identity.**
3. **Do not let embed/borrow silently publish, import, or adopt.**
4. **Do not let linked-view breakage silently fall back to a different view.**
5. **Do not let wrapper-local chrome rewrite source view law.**

## Working stance

Linked views now look like one of the cleanest ways to make Helm's datacube feel more powerful without making it more grandiose.
They extend the life of saved view objects,
which is exactly the kind of composition Helm should prefer.
