# Continuity switch authorship posture v0

Purpose: pin one compact Helm rule on the next continuity problem that remains dangerous even after request-vs-live truth,
entry-artifact truth,
binding-witness posture,
and activity-scope truth are already in place.

The problem is simple:
**a continuity surface can still lie if it hides who proposed,
chose,
or executed a repaired join,
scope switch,
reuse path,
or delegated continuation.**

This posture is intentionally narrow.
It does **not** define a full autonomy constitution,
a giant agent-law stack,
or one universal collaboration taxonomy.
It only says Helm should keep **choice/authorship posture** explicit whenever continuity becomes stronger than exact carry.

## Posture (v0)

1. **Exact carry and authored substitution are different truths**
   - if Helm preserves continuity exactly,
   - that can remain compact,
   - but when Helm repairs,
     widens,
     switches,
     reuses,
     delegates,
     or rebinds non-exactly,
     it should not flatten that move into the same ordinary continuation story.

2. **Proposer, chooser, and executor should stay distinguishable when they matter**
   - the shell,
   - the operator,
   - a policy surface,
   - an app's single-instance behavior,
   - a provider,
   - or another helper/agent lane
   may each play different roles.
   Those roles do not need to be shown everywhere,
   but continuity surfaces should be able to reveal them when a substitute path matters.

3. **A shell proposal is not operator authorship**
   - a helpful suggested substitute,
   - likely reuse candidate,
   - nearby session,
   - remembered profile,
   - or generated repair plan
   does not silently become “what the operator chose” just because it was surfaced elegantly.

4. **Externally forced reuse should stay visible as externally forced**
   - single-instance apps,
   provider-owned reuse,
   platform-imposed focus behavior,
   or other external constraints may collapse options.
   Helm should not launder those outcomes as if the shell or operator freely chose them.

5. **Delegated continuity should preserve handoff posture**
   - if a continuity path crosses lanes,
   sessions,
   agents,
   peers,
   or background helpers,
   that handoff should stay visible rather than collapsing into one blended continuity story.

6. **Unknown authorship should stay unknown**
   - when Helm cannot honestly explain who chose the substitute,
   it should say so rather than infer a flattering authorship story.

7. **This posture stays smaller than a general autonomy constitution**
   - Phase 1 does not need one total theory of every collaborative or delegated action.
   - It only needs enough shell law that continuity substitutions stop laundering authorship.

## Why this is worth pinning now

Helm now has enough saved/planned continuity surfaces that binding and scope witnesses alone are no longer quite enough.
A card can explain:
- that a join was repaired,
- and that the scope widened on one axis,

while still hiding the more dangerous question:
**who actually chose that repaired or widened continuation story?**

SlopOS keeps refusing silent target choice across handler-selection,
session-selection,
request-state,
and exact-reveal seams.
Schell keeps pressuring authorship badges,
review lanes,
restore honesty,
launch kits,
and exact handoff bundles.
DelayBasin's authorship-witness / autonomy-posture discipline makes the missing refinement unusually clear.

So the narrow new Helm rule is:

**when Helm repairs,
widens,
switches,
reuses,
or delegates continuity,
it should not hide who proposed,
chose,
or executed that move.**
