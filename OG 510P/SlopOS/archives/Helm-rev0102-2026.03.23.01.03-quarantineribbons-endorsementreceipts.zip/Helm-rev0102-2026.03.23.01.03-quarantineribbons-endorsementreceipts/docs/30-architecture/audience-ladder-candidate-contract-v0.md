# Audience ladder candidate contract v0

Purpose: define one compact shell-owned chooser for **reveal audience rungs** so Helm can move between local-only,
named,
org-only,
guarded-link,
and public/time-boxed visibility without collapsing them into one mushy Share state.

An **audience ladder** sits beside publication ladders,
reveal windows,
and promotion receipts.
It is the operator-facing move that makes audience strength,
route class,
and reveal shape legible before a stronger reveal step happens.

## Why this move now

Helm increasingly wants shell luxuries that may travel or be shown beyond the live local lane:
- saved views
- linked views
- front-door handles
- evidence briefs
- response kits
- claim envelopes
- handoff packets
- selected glance / watch / summary surfaces

Publication ladders already say **that a stronger reveal/share/publish step is happening**.
What they do not yet say clearly enough is:
- who the audience is,
- whether the route is named or bearer-like,
- what shape will be revealed,
- and how temporary or guarded the reveal should be.

An audience ladder is the UX move that makes that law legible.

## Candidate shape

A first useful audience ladder would likely include these rungs:

1. **Keep local**
   - no reveal beyond current local shell posture

2. **Named people only**
   - invite specific collaborators / recipients
   - visible full / comment / edit / summary choice where the family supports it

3. **Org / workspace / team only**
   - visible bounded audience class
   - optional hide-from-search or similar discoverability limits where relevant

4. **Guarded link**
   - passworded,
     email-auth,
     signed,
     or equivalent guard
   - usually time-boxed
   - route class should stay visible

5. **Public / time-boxed public**
   - only where the family should ever support broad reveal
   - explicit expiry,
     guard,
     indexing,
     and disable path

Not every family needs every rung.
Many should stop early.

## Rules that matter

### 1. Audience choice is not activation
A reveal rung does not imply local live adoption,
receiver fit,
or authority to act.
It only changes who can see what shape of the surface.

### 2. Named and bearer routes should stay visibly different
A guarded/signed/public link is not the same thing as a named collaborator relation.
The shell should preserve that distinction.

### 3. Reveal shape belongs on the ladder
The ladder should be able to say whether the chosen audience gets:
- full
- comment
- edit
- preview
- summary
- or redacted form

### 4. Some families should refuse broad reveal
Examples that often should stop early:
- raw activity residue
- trust decisions
- strong authority surfaces
- some watchpoint internals
- some repair or adoption candidate work
- some shadow-lane work

Refusal is part of the ladder,
not a bug.

### 5. Audience ladders should compose with reveal windows and receipts
A stronger reveal act should be able to leave behind:
- one historical promotion receipt
- one current reveal window where applicable
- one nearby disable / rotate / narrow path

## Best first homes

- saved views
- evidence briefs
- claim envelopes
- response kits
- front-door handles where any travel beyond local should stay very weak and exact

## What this is not

- not a universal ACL editor
- not a hidden collaboration substrate
- not a live-state replication promise
- not a giant admin console
- not a replacement for authority windows when actual power,
  not just visibility,
  is being granted

## A good first proof slice would show

- one local-only family that refuses broad reveal,
- one named-collaborator rung,
- one org-only rung,
- one guarded-link rung with password or signature plus expiry,
- and one policy-blocked public rung.

## Why this seems worth keeping warm

Audience ladders now look like the clearest way for Helm to make visibility strength real.
They preserve the magic of share/export/publish,
while keeping audience,
route,
shape,
policy,
and expiry honest.
