# Basis stamp candidate contract v0

Purpose: define one compact shell-owned **basis witness** that says what exact source,
revision,
checkpoint,
query id,
packet basis,
or reviewed state a portable or derived Helm surface reflects.

A **basis stamp** is smaller than a manifest,
smaller than a handoff packet,
and more reusable than one family-specific receipt.
It should compose with:

- handoff packets
- receiver-fit cards
- landing manifests
- drift beacons
- basis contrast cards
- derivation strips
- evidence briefs
- response kits
- watchpoints
- glance derivations
- deck recipes
- exact action keys
- effect receipts
- and future exported or published shell luxuries

## Why this move now

Helm now has basis truth scattered across many warm moves.
Packets can carry origin or basis.
Glance cards can go stale.
Receiver-fit cards need to tell the truth about what exact basis arrived.
Response kits and briefs increasingly need to say what exact reviewed state they were written against.

What Helm still lacks is one **small reusable witness** that answers:

**what exact basis is this surface talking about?**

Without one,
Helm keeps risking two flattering lies:

- “this is obviously the latest or the same thing,”
- and “basis is too small to deserve its own witness.”

## Candidate shape

A first useful basis stamp would likely include:

1. **Owner surface**
   - manifest id
   - packet id
   - exact key id
   - deck recipe id
   - glance id
   - watchpoint id
   - brief id
   - response-kit id
   - receipt id
   - or another admitted owner

2. **Basis family**
   - source object
   - prior reviewed basis
   - checkpoint / snapshot basis
   - packet-carried basis
   - query/result basis
   - compare target
   - published-from basis
   - or another exact basis class

3. **Exact basis witness**
   - digest
   - revision / epoch
   - checkpoint id
   - version id
   - query id
   - commit id
   - component id
   - or other compact exact identifier

4. **Comparison posture**
   - reflects exactly this basis
   - derived from this basis
   - compared against this basis
   - carried from this basis
   - published from this basis
   - expected to still match this basis

5. **Freshness / verification posture when relevant**
   - current at creation
   - unknown freshness
   - stale relative to source
   - expires at
   - basis unavailable
   - receiver cannot verify

6. **Optional human-facing label**
   - milestone name
   - version title
   - release label
   - operator note

7. **Copyable display form**
   - short inspectable stamp
   - compact card line
   - breadcrumb / trail form
   - receipt field
   - packet field

## Rules that matter

### 1. A basis stamp is not continuity

It says what basis a surface reflects.
It does **not** claim the current live source still matches.

### 2. A basis stamp is not receiver fit

Knowing the basis is different from proving local compatibility,
trust,
or activation.

### 3. A basis stamp should stay smaller than a manifest

If the witness becomes a full packet schema,
full diff,
or full version-control subsystem,
Helm has probably collapsed two layers that should stay separate.

### 4. Basis absence can be honest

Some surfaces may only be able to say `basis unavailable`,
`freshness unknown`,
or `receiver cannot verify`.
That is better than bluffing latestness.

### 5. Some stronger claims should require one

If a surface wants to compare,
publish,
hand off,
restore,
or apply on a reviewed basis,
Helm may require a basis stamp or refuse the stronger claim.

### 6. Human labels stay descriptive

A milestone title,
release name,
or friendly version label is useful,
but it must not replace the exact machine witness when exactness matters.

## Best first homes

- handoff packets that carry one exact basis across tiers
- receiver-fit cards that show what exact basis arrived and whether it is verifiable here
- deck recipes that materialize from a known reviewed basis
- drift beacons that compare current state against one exact basis
- response kits and evidence briefs that need to show what exact reviewed state they were written from
- stronger actions that should reject silent drift unless the expected basis still matches

## What this is not

- not a universal snapshot format
- not proof that the current live object is unchanged
- not a substitute for fit,
  trust,
  review,
  or adoption
- not a promise that every surface can always carry an exact basis
- not a giant version-control subsystem

## A good first proof slice would show

- one handoff packet or exact key with a compact basis stamp,
- one receiver-fit card that embeds or consumes the stamp,
- one stale / unknown / unverifiable case,
- and one stronger act that refuses silent drift unless the expected basis still matches.

## Why this seems worth keeping warm

Basis stamps now look like the missing reusable atom for Helm's carried-basis story.
They make travel,
comparison,
publication,
and reviewed stronger acts more honest without adding a new pillar or a giant constitution.
