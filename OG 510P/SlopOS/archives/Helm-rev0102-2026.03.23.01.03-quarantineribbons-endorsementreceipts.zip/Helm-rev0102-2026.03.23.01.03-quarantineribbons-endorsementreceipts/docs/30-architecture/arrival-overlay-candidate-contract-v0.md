# Arrival overlay candidate contract v0

Purpose: define one compact shell-owned **compare-before-adopt** surface so an arriving,
saved,
or derived Helm object can be compared against one exact basis or one explicit local candidate before the receiver adopts anything.

An **arrival overlay** is the compare sibling of landing rehearsal.
It should compose with:

- landing rehearsals
- landing manifests
- basis stamps
- near-match fences
- receiver fit cards
- rebind ladders
- drift beacons
- capsule diffs
- and anchor maps

## Why this move now

Helm now has a fairly rich truthful-landing story.
It can say what arrived,
what stayed behind,
and what still needs local rebinding.
What it still lacks is one explicit compare surface between **arrival** and **adoption**.

Current tools keep validating that missing middle:

- Figma branch review can show changes side-by-side or as an overlay before merge
- Figma compare changes keeps one selected basis visible while differences are inspected
- VS Code Profiles can be previewed and imported explicitly rather than instantly becoming live
- partial profile workflows and landing rehearsals both suggest that comparison deserves its own smaller surface

That combination strongly suggests that some Helm arrivals should be able to say:

**show me this against here before we call any of it adopted.**

## Candidate shape

A first useful arrival overlay would likely include:

1. **Incoming subject witness**
   - landing manifest id
   - portable core id
   - deck recipe id
   - exact action key id
   - dock item/band id
   - or another admitted shell-owned owner

2. **Compared-against witness**
   - exact carried basis
   - exact current local target
   - explicit near-match candidate
   - or explicit no-local-candidate posture

3. **Visible compare modes**
   - side-by-side
   - overlay
   - changed-only summary
   - slot list summary

4. **Typed difference summary**
   - exact slot satisfied
   - missing slot
   - mismatched root/profile/provider/session/activity
   - inherited class
   - omitted local residue
   - stale or unknown basis

5. **Tiny next actions**
   - inspect carried structure
   - open near-match fence
   - open fit card
   - rehearse candidate locally
   - adopt one slice
   - reject landing

## Rules that matter

### 1. Arrival overlay is comparison,
not adoption
Seeing an overlaid or side-by-side compare should not count as adoption.
The receiver still needs an explicit stronger step.

### 2. Compare should stay one-subject-versus-one-subject at first
The first version should not become a giant multi-branch diff theatre.
One arriving subject against one exact basis or one explicit candidate is enough.

### 3. Difference classes should stay typed
The shell should say **why** a difference exists,
not only that a visual diff exists.
Typed mismatch reasons are more important than giant pixel theater.

### 4. Arrival overlay should compose with rehearsal and rebind
Compare should be able to lead into landing rehearsal,
fit inspection,
near-match handling,
or one bounded adoption slice.
It should not replace those steps.

### 5. The first version should stay compact
One overlay card,
one split compare,
or one compare strip is enough.
Do not build a universal merge studio.

## Best first homes

- one deck recipe arriving on a second receiver and compared to one local deck candidate
- one exact action key compared against one local target candidate before rebinding
- one dock band compared against a local dock specimen before adoption
- one entry kit compared against the current local activity arrangement before taking any strong step

## What this is not

- not giant continuity theater
- not a generic version-control system
- not proof that a compared candidate is already chosen
- not a substitute for landing rehearsal,
  fit,
  or rebind
- not permission to flatten compare into merge

## A good first proof slice would show

- one incoming surface,
- one explicit basis or one explicit local candidate,
- one exact slot,
- one typed mismatch,
- one open-near-match path,
- and one explicit adopt-slice or reject path.

## Why this seems worth keeping warm

Arrival overlays now look like the smallest humane compare surface missing from Helm's truthful landing story.
They let the shell be more legible without letting comparison masquerade as adoption.
