# Continuity choice witness candidate contract v0

Purpose: explore one small reusable shell-owned move for showing who proposed,
chose,
or executed a continuity substitute or switch.

A **continuity choice witness** is a compact shell-owned strip,
chip row,
or small card.
It does not replace a binding witness,
scope witness,
cockpit,
or entry kit.
It complements them by answering a narrower question:
**who carried this continuity story forward once it stopped being exact carry?**

This is a candidate move, not a freeze.

## Candidate shape

A first useful continuity choice witness would likely include:

1. **Continuity subject**
   - one activity / capsule / cockpit / entry kit / binding subject
   - one exact shell-owned reference

2. **Choice object**
   - the substitute,
   switch,
   reused target,
   delegated lane,
   or widened axis currently being proposed or used

3. **Role lanes**
   - **proposer** — who suggested the move
   - **chooser** — who actually selected it
   - **executor** — who carried it out

4. **Autonomy / choice posture**
   - exact-carry
   - operator-switched
   - shell-proposed-awaiting-review
   - policy-forced
   - externally-forced-reuse
   - delegated
   - unknown

5. **Basis links**
   - link to the nearby binding witness when the choice occurred during a repaired join
   - link to the nearby scope witness when the choice changed or widened the counted axes
   - link to the receipt,
   entry kit,
   cockpit,
   or restore card that supplied the basis

6. **Allowed action ladder**
   - inspect basis
   - accept the proposed substitute
   - keep exact-only / refuse substitute
   - open cockpit
   - fresh launch / fresh attach
   - hold / repair

## Guardrails

1. **Not a giant maker-checker bureaucracy**
   - the first useful version should stay compact and continuity-focused.

2. **Not a flattering badge row**
   - the point is to reveal authorship posture,
   not decorate hidden substitution with nicer chips.

3. **Not mandatory everywhere**
   - exact carry can stay light.
   - this witness matters when continuity is being repaired,
   widened,
   switched,
   reused,
   or delegated.

4. **No fake operator authorship**
   - proposals,
   policy decisions,
   and external single-instance reuse should not silently wear the operator's badge.

5. **Evidence should stay revealable**
   - a tiny strip is fine,
   but it should open the nearby basis path when the operator wants detail.

## Why this looks promising

Helm is accumulating several saved/planned continuity luxuries:
- capsules,
- layout templates,
- activity cockpits,
- activity entry kits,
- binding witness cards,
- activity scope witnesses,
- and stronger Recall cues.

A tiny continuity choice witness looks like the cheapest way to stop those luxuries from laundering authorship once continuity stops being exact carry.

It also gives Helm another unusually good kind of magic:
**return-to-task surfaces that can tell you not only what they found and in what scope,
but who actually chose the substitute path.**

## First proof-bearing specimen

A narrow specimen would be enough:
- one operator-switched continuity path,
- one shell-proposed substitute awaiting approval,
- one externally-forced single-instance reuse case,
- one delegated lane handoff,
- and one hold path for unknown choice/authorship instead of silent flattening.

## Failure modes to avoid

- a chip row that still hides the real chooser
- agent or helper proposals silently inheriting operator authorship
- a giant review workflow before one tiny witness exists
- duplicating Operations Center tables without improving continuity truth
- forcing every surface to show choice lanes even when no substitute or switch happened
