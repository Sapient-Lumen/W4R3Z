
# Layout template candidate contract v0

Purpose: capture the best part of zone managers and workspace launchers without letting them become a separate shell worldview.

A **layout template** is a shell-owned spatial template with named slots, anchors, and rebinding rules.
It is not the same thing as a capsule.
A capsule says “this is the remembered continuity object.”
A layout template says “this is the spatial structure I want to apply or reuse.”

## Candidate posture

1. **Templates are shell-owned spatial objects**
   - named slots
   - explicit split / stack / tab / shelf relationships
   - explicit scope (one workspace, one capsule family, one monitor topology, etc.)

2. **Templates bind by anchors, not only by titles**
   - object kind
   - flow role
   - provider role
   - current selection lineage
   - explicit user-picked binding

3. **Templates support rebinding**
   - when the exact target is absent, Helm should show possible substitutes or leave the slot visibly open
   - rebinding should be inspectable, not magical

4. **Templates compose with capsules**
   - a capsule may reference a template
   - a restore may choose to apply a template first, then bind capsule targets
   - templates should not become a separate save/restore religion outside Recall

5. **Templates remain Tiling Shell truth**
   - this is not a bolt-on helper suite
   - template editing should feel like a shell luxury, not a foreign manager bolted on beside the shell

## Candidate uses

- save one preferred project arrangement as reusable spatial structure
- reapply a structure to new windows or flows for a task
- repair a capsule restore by rebinding missing slots into an existing template
- edit a layout visually and keep the resulting template as a reusable object

## Candidate v0 specimen

A narrow specimen could be:
- one template with named slots,
- one rebinding card for a missing slot,
- one visible binding witness for a repaired slot-to-live join,
- one template applied inside Tiling Shell,
- and one capsule that reuses the template rather than encoding all spatial truth itself.

## Guardrails

- do not split templates into a separate zone-manager worldview
- do not rely on fragile title-matching folklore as the primary binding method
- do not promise exact restore when the system is really doing rebinding

## Working stance

Layout templates now look like a very plausible shell luxury.
Helm should keep them as a candidate contract until one compact specimen proves they improve Tiling Shell and Recall together rather than fragmenting them.
