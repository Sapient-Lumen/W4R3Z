# Activity memory seed candidate contract v0

Purpose: give Helm one shell-owned explicit remembered-context object that can help activity return, planning, and acting without turning ambient history or AI folklore into a second hidden truth plane.

An **activity memory seed** is a small remembered thing.
It is weaker than live truth.
It is stronger than vague recents folklore.
It is not a pillar.

## Candidate posture

### 1. Capture is explicit
A memory seed should come from an authored remember move such as:
- remember this selection
- remember this page/object/view
- remember this instruction
- remember this warning for this activity

Ordinary open,
preview,
recent use,
or visibility should not silently create seeds by default.

### 2. Seeds are typed
Useful early seed kinds may be:
- fact seed
- instruction seed
- warning/check seed
- object-pointer seed
- view-pointer seed
- route/account/provider hint seed
- source excerpt seed
- question-to-ask-on-return seed

### 3. Scope is first-class
A seed should carry one explicit scope posture such as:
- personal
- activity-local
- shared activity
- imported restricted
- published starter

A seed should not silently widen across nearby profile,
workspace,
account,
browser,
or provider context.

### 4. Source witness stays revealable
A seed should be able to show:
- source family
- source ref
- capture time
- capture author
- optional basis or quote excerpt

This should make the seed inspectable without pretending the source is still current.

### 5. Freshness and staleness are different from source exactness
A seed may be exact about what was remembered and still be stale now.
Useful posture classes may include:
- fresh enough
- historical
- stale / review
- imported
- unknown

Seeds should not impersonate current-live beacons.

### 6. Influence should stay visible
If a seed influences:
- Omnibox ranking,
- Recall suggestions,
- entry-kit front doors,
- activity-spine summaries,
- planning surfaces,
- or agent context,

a small witness should say so.

### 7. Share/adopt ladders stay explicit
Sharing a seed should not make it ordinary local truth for the receiver.
Useful ladders may be:
- keep personal
- share with activity
- include in starter/entry kit
- import in restricted posture
- adopt locally
- publish as starter guidance

### 8. Forgetting is a first-class act
Seeds should support:
- archive
- forget/delete
- retire as stale
- verify/refresh
- move between scopes when explicitly allowed

## Candidate minimal shape

A first useful seed likely needs:
- exact id
- seed kind
- body/value
- source witness
- scope posture
- author
- captured_at
- stale/freshness posture
- optional activity spine ref
- optional entry-kit/front-door refs

## Best first homes

- one activity spine with three memory seeds
- one entry kit showing a remembered warning and a remembered preferred view
- one Omnibox result visibly lifted by a memory seed
- one imported/shared seed that begins in weaker posture
- one stale seed that remains visible but does not pretend to be current truth

## Guardrails

1. **No ambient scrape-by-default memory**
2. **No hidden cross-scope inheritance**
3. **No remembered fact outranking current-live evidence**
4. **No imported seed silently becoming trusted local memory**
5. **No giant memory ontology before one tiny specimen works**
6. **No burying management in one settings cave**

## Working stance

Activity memory seeds now look like one of the best next support objects for Helm.
They can make saved structure,
reentry,
and AI-assisted shell surfaces feel substantially smarter while still learning the right lesson from SlopOS:

**remembered context is guidance and evidence, not ambient authority.**
