# Launch ladder candidate contract v0

Purpose: give Helm one compact shell-owned way to treat saved entry objects, recent exact objects, and routeable actions **honestly** when the right next move is not always the same thing.

This move exists because modern tools keep proving that saved launch configurations, quicklinks, launcher menus, and entry objects are useful — but they become misleading when they quietly pretend to be current live continuity.

## What a launch ladder is

A launch ladder is a **small explicit next-step ladder** that can appear next to a saved entry object, exact object, recent object, or reviewed action.

It does **not** claim that one of the options is already true.
It merely keeps the honest choices nearby.

A first useful family could include:

- inspect / preview
- fresh launch
- attach to live target
- reuse existing surface
- repaired return
- historical replay
- hold

Not every subject gets every rung.
The point is that Helm should not flatten these into one flattering “open” action.

## Where it can appear

Launch ladders should be reusable across:

- **Omnibox**
- **Recall**
- **Object Browser**
- **activity entry kits**
- **activity cockpit cards**
- **terminal/capshell** for shell-facing launch or attach surfaces

## Minimum visible facts

A useful v0 ladder should keep a few facts obvious:

- the exact subject or saved entry object being acted on
- whether the rung is:
  - fresh,
  - live attach/reuse,
  - repaired,
  - historical,
  - or blocked/hold-only
- destination posture when known
- source / authorship grade when that changes the safe next move
- whether review or rebinding is required first

## Guardrails

### 1. A launch ladder is not continuity proof
A ladder may be attached to a recent object, saved entry kit, capsule, or receipt.
That still does not prove the old live state is available now.

### 2. A ladder is not placement authority
Generic launch should not quietly inherit new-window/new-tab/reuse-window placement folklore.
If stronger placement control exists later, it should come from a separate explicit shell workflow.

### 3. A ladder must not hide target choice
If the shell, provider, or policy chose a repaired or reused target, that should stay witnessable.

### 4. A ladder must not bypass review or receipt law
If the chosen rung is a stronger action, it should still compose with review strips, basis truth, route witnesses, and receipts.

### 5. Historical replay should stay visibly weaker than exact live attach
The ladder should not make historical material look equal to current live continuity when the evidence is weaker.

### 6. Generic open should remain weak
A launch ladder is useful partly because it prevents one ordinary open verb from quietly impersonating:

- current-live reentry
- durable save
- materialization / adoption
- publication / promotion
- branch / fork
- or session/profile/account selection

If one of those stronger acts is wanted, the ladder should expose it as a different rung or hand off into a different explicit workflow.

## First specimen worth proving

One good first specimen would be:

- one exact recent object,
- one saved entry object,
- one currently live attach/reuse target,
- one unavailable or repaired case,
- and one hold/review-again case.

That is enough to show the value without freezing a giant session-restore or workspace bureaucracy.
