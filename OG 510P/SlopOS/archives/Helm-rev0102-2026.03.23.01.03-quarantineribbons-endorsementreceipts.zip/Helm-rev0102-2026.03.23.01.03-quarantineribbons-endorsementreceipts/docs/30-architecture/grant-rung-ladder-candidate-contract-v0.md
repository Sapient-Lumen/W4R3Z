# Grant-rung ladder candidate contract v0

Purpose: give Helm one shell-owned humane chooser for **which authority duration/scope rung** the operator is actually granting.

The goal is not a giant permissions menu.
The goal is to stop pretending every approval means the same thing.

## Contract

A **grant-rung ladder** is a bounded shell-owned chooser that offers a small number of distinct authority rungs for one authority family and one current situation.

At minimum it should be able to represent:

### R0 — inspect / no grant
- show the subject
- allow preview, compare, or explanation
- do not grant stronger authority

### R1 — exact once
- one exact action on one exact reviewed basis
- does not remain ambient afterward

### R2 — this time / focused interaction
- temporary during the current focused interaction
- should expire naturally when the interaction ends

### R3 — this ask / loadout / request
- bounded to one current ask or context loadout
- broader than one exact click,
  weaker than activity-wide continuity

### R4 — this activity spine
- bounded to one named activity/work frame
- visible to Recall and Operations Center
- expires when the activity ends or is explicitly revoked/demoted

### R5 — this isolated side lane
- broader temporary room inside one explicit shadow lane / worktree-like lane / isolated helper session
- does not imply the same authority in the live lane

### R6 — named persistent scope / until revoked
- strongest ordinary rung
- requires clearer warning,
  clearer receipt,
  and a strong revoke path

Not every family needs every rung.
Some families may stop at R3.
Some may allow R5 but never R6.
That is fine.

## Truth posture

### 1. The ladder should expose real differences, not cosmetic wording

Each rung must differ in at least one meaningful axis:
- duration,
- blast radius,
- holder,
- isolation,
- or current-live carryover.

### 2. The strongest rung should not be the cheerful default

Persistent or broad-scoped authority should usually require a clearer extra step than temporary or isolated-lane authority.

### 3. Revoke and narrow should stay nearby

A ladder is incomplete if it ends at grant.
After grant,
Helm should keep nearby:
- inspect,
- revoke,
- narrow,
- reacquire on a weaker rung,
- or move to isolated lane.

### 4. Historical rung choice is not current live truth

A prior “allowed for this activity” or “allowed this time” should help explanation,
not masquerade as a still-live grant.

### 5. Drift can change the best available rung

If basis,
subject,
provider,
or locality changed,
Helm may honestly demote the next suggestion:
- from R4 to R3,
- from R3 to R1,
- or from live-lane rungs to isolated-lane-only.

## Why Helm wants this

Without a rung ladder,
Helm risks one mushy “Allow” button for wildly different acts.
That would quietly reintroduce the same folklore the archive has been trying to kill.

With a rung ladder,
Helm can make powerful moves feel safe and legible:
- **allow this helper once**
- **allow this browser tool this time**
- **allow this source for this activity**
- **allow this agent more room, but only in an isolated lane**

## First proof target

A good first specimen would be one shell-owned chooser that appears during a stronger helper action and offers:
- inspect only,
- exact once,
- this ask,
- isolated side lane,
- and persistent named scope.

That is enough to learn whether Helm can turn permission choice into a humane power surface instead of a scary settings chore.

## This revision

This revision keeps the ladder warm because one-time, this ask, activity-wide, isolated-lane, and persistent scope are now strongly validated as meaningfully different user-facing product choices.
