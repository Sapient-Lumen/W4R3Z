# Adoption slice candidate contract v0

Purpose: define one compact shell-owned **bounded partial-adoption** act so a receiver can accept one admitted slice of an arriving Helm surface without pretending the whole surface was adopted.

An **adoption slice** is the bounded-accept sibling of landing rehearsal and receiver fit.
It should compose with:

- landing manifests
- anchor maps
- inherit masks
- residue ledgers
- basis stamps
- receiver fit cards
- rebind ladders
- promotion receipts
- and publication ladders

## Why this move now

Helm already knows that arrivals may be weaker than adoption.
It also knows that some classes should stay local,
some can inherit receiver defaults,
and some require explicit rebinding.
What it still lacks is one explicit way to say:

**accept this part,
leave the rest visible.**

Current tools keep validating that bounded partiality matters:

- VS Code Profiles can include only bounded configuration classes and can inherit the rest from the Default Profile
- partial profile export and import keeps subset choice explicit
- Figma library updates let an operator update one instance individually or update all
- saved views in tools like Obsidian travel more cleanly than mutable local residue or whole-workspace posture

That combination strongly suggests that some Helm arrivals should support a bounded partial-accept move rather than only reject-all or adopt-all.

## Candidate shape

A first useful adoption slice would likely include:

1. **Owner surface witness**
   - landing manifest id
   - portable core id
   - deck recipe id
   - dock item/band id
   - exact action key id
   - or another admitted shell-owned owner

2. **Slice selector**
   - one explicit slot
   - one slot class
   - one view in a deck
   - one dock band
   - one shortcut family
   - one companion bundle class
   - or another bounded admitted class

3. **Visible remainder summary**
   - not adopted yet
   - inherited here
   - still requires rebind
   - intentionally omitted
   - kept local only

4. **Typed gate posture**
   - exact adopt allowed
   - inspect only
   - explicit rebind required first
   - refused

5. **Tiny next actions**
   - adopt selected slice
   - inspect skipped remainder
   - convert remainder to local overlay
   - open fit card
   - open rebind ladder
   - reject full landing

## Rules that matter

### 1. Partial adoption must stay explicit and receipted
If one slice is adopted,
Helm should name exactly what was accepted and what was not.
The receipt matters as much as the act.

### 2. Slice boundaries should stay typed,
not arbitrary patch soup
The shell should adopt by admitted slot,
view,
band,
class,
or another bounded surface unit.
Do not start with hidden field-level merge magic.

### 3. The unaccepted remainder stays visible
A partial adoption should leave clear evidence of what remains omitted,
inherited,
local,
or pending.
It should not flatter the whole landing into success.

### 4. Exactness still matters inside a slice
A slice may be small,
but it should still obey near-match fences,
fit cards,
and rebind rules where relevant.
Partiality is not permission to weaken exactness.

### 5. The first version should stay small
One or two slice classes are enough.
Do not answer this by building a universal merge language.

## Best first homes

- one deck recipe where a receiver adopts one view and leaves the rest pending
- one dock landing where a receiver adopts one band but not the entire arriving set
- one exact action key family where shortcuts inherit locally but target bindings remain pending
- one companion bundle where docs travel but provider/session binding remains receiver-local

## What this is not

- not a general-purpose patch system
- not silent best-effort merge
- not permission to hide omitted or still-local remainder
- not a substitute for rebind ladders or fit cards
- not proof that the whole landing now lives here

## A good first proof slice would show

- one arriving surface with three bounded parts,
- one adopted slice,
- one inherited slice,
- one slice still pending explicit rebind,
- and one receipt that names all three honestly.

## Why this seems worth keeping warm

Adoption slices now look like the smallest honest answer to “I want some of this here,
but not all of it yet.”
They let Helm stay flexible without turning flexibility into ambient merge folklore.
