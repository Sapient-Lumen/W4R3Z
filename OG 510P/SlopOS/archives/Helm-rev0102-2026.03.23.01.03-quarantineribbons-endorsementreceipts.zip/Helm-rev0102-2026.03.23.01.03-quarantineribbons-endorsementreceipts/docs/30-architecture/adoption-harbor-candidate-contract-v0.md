# Adoption harbor candidate contract v0

Purpose: give Helm one compact shell-owned place where **delegated, background, helper, repair, or shadow-lane candidate work** can land for inspection and explicit apply/adopt steps before it counts as authoritative live truth.

This move exists because modern tools keep rediscovering the same thing:
background work feels magical when it is isolated,
trackable,
and easy to review.
It feels dangerous when it silently lands in the live lane.

An adoption harbor is Helm's candidate answer.

## What an adoption harbor is

An adoption harbor is a **small review/apply surface** for candidate work that is related to a live subject but is not yet the authoritative live result.

A useful v0 harbor item may include:

- exact related live subject
- source/authorship posture
- lane or session identity
- exact starting basis packet or drift note
- preview or diff of candidate result
- current posture: proposal-only / adoption-ready / held / drifted / rejected
- next ladders: inspect / adopt selected / adopt all / review again / keep separate / reject / hold
- exact tie-back to any action warrant, effect receipt, or slot verdict ledger that already exists nearby

The harbor is not the live lane.
The harbor is where candidate work becomes inspectable enough to earn adoption.

## Where it can appear

Adoption harbors are most promising across:

- **Operations Center** for delegated sessions, repair jobs, and background runs
- **Desktop Flow** for fragment outputs or side-lane proposals
- **terminal/capshell** for shell-facing delegated sessions or reviewed apply steps
- **Recall** for historical candidate work that never became authoritative
- **Exchange** for receiver-local landings or imported candidate work that should stay weaker than adoption
- and later perhaps **Omnibox** as an entrypoint into harbor items, not as the whole harbor itself

## Why this is different from ordinary notifications

A notification says something happened.
An adoption harbor says:

- what exact candidate work exists,
- what it was based on,
- whether it drifted,
- who authored it,
- what preview or diff is under review,
- and what the honest next moves are.

That is substantially better than “done,” “failed,” or “view changes.”

## Guardrails

### 1. The harbor is not AI-only
This pattern should work for background repairs,
delegated helpers,
Flow side lanes,
or future agent systems.
It is broader than one assistant product shape.

### 2. No silent auto-merge mythology
Candidate work does not become live truth just because the helper looked competent.
If adoption happened,
Helm should be able to say so.
If it did not,
Helm should be able to say that too.

### 3. Drift should stay visible
If the live basis moved,
the harbor item should downgrade or hold rather than wearing the same strong apply affordance.

### 4. Keep it compact
The first cut is not a giant collaboration court.
It is one compact shell-owned review/apply harbor.

### 5. Harbor state is not continuity proof
A harbor item may be recent,
important,
or still useful.
It is still not the authoritative live lane until an explicit adoption step says otherwise.

### 6. Session logs are adjacent, not sovereign
Long-running delegated sessions may emit logs,
progress,
and outputs.
Those are useful.
But the harbor remains the place where candidate work becomes adoption truth or remains non-authoritative.

### 8. Some harbor items should hand off into landing trains
Not every adoption-ready candidate needs direct one-step apply.
If several candidates aim at one authoritative lane,
or if stronger promotion should happen in guarded rungs,
a harbor item should be able to enter one explicit landing train instead of pretending that immediate apply is the only honest next move.

## First specimen worth proving

One good first specimen would be:

- one background shadow-lane repair item,
- one adoption-ready item with preview/diff,
- one drifted item that requires review again,
- and one rejected item that leaves the live lane untouched.

That is enough to learn whether Helm can make delegated power feel awesome without laundering authorship or mutating the live lane by surprise.
