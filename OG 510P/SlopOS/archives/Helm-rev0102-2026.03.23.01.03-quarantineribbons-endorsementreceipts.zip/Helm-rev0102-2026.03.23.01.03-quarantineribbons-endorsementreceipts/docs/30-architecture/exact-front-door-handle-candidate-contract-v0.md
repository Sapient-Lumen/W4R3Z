# Exact front-door handle candidate contract v0

Purpose: give Helm one tiny shell-owned entry object that can be summoned, pinned, attached, or shared without forcing users to carry a full activity spine or entry kit for every recurring way back into work.

An **exact front-door handle** is a very small shell-owned pointer to one preferred entry path.

It is smaller than an activity spine.
It is smaller than a resource shelf.
It is smaller than an activity entry kit.
And it is much weaker than a current-live beacon.

This is a candidate move, not a freeze.

## Candidate shape

A first useful handle would likely include:
- title
- icon
- exact target relation
- target kind
- optional profile/provider affinity hints
- optional compare path relation
- optional triage path relation
- locality/trust posture
- import/share posture
- one obvious primary act
- one honest stronger-act ladder nearby

## Candidate target families

A handle may point at one exact:
- saved view object
- activity entry kit
- triage lane
- compare surface
- exchange route
- command/flow entry
- provider deeplink
- launch/layout starter

## Candidate posture

### 1. Tiny and summonable
A handle should work well in:
- Omnibox
- Overview
- docks/rails
- keyboard shortcuts
- command palettes
- Recall
- pinned launch surfaces

### 2. Exact target identity
The operator should be able to inspect what exact thing the handle points at.
No vague “open probably-related thing” folklore.

### 3. Primary act is explicit but not overclaiming
A handle may prefer one main act such as:
- inspect
- open linked view
- open triage lane
- start compare
- attach
- relaunch

But the handle must not pretend the strongest act already happened.

### 4. Scope affinity may be carried,
###    but not silently chosen
A handle may say:
- prefers work profile
- last good in provider X
- usually opens in browser space Y

Those remain hints,
witnesses,
or explicit stronger choices.
They do not silently count as current live truth.

### 5. Shared/imported handles start weaker
Imported or shared handles should be useful,
but restricted until receiver-local fit or trust is earned.

### 6. External trigger may require confirmation
A handle reached through an external deeplink, shared route, or imported launcher path may begin in inspect/confirm posture when the act is stronger than ordinary inspect/open.

### 7. Handles should compose upward
A handle can sit inside or next to:
- activity entry kits
- linked views
- view decks
- cockpit cards
- triage cards
- compare cards

## Guardrails

1. **Do not let handles impersonate current-live beacons.**
2. **Do not let handles silently choose remote/profile/account/session truth.**
3. **Do not let handles become copied object state.**
4. **Do not let imported handles auto-adopt stronger receiver-local truth.**
5. **Do not make handles a new giant bookmarking bureaucracy.**

## Good first specimens

- one pinned triage handle
- one pinned compare handle
- one pinned saved-view handle
- one imported handle that opens in restricted posture until locally adopted

## Working stance

Exact front-door handles now look like one of the most product-feel-rich additions Helm could make with very little constitutional cost.
They give the shell a smaller reusable noun for “the exact way back in” without asking every path to become a giant project object.


## New pressure from rev0065

Exact front-door handles now look even more useful when they can act as tiny stops inside a **patrol route**.
That is the right scale: the handle stays a compact jump object, while the patrol route owns the bounded repeated round over several such stops.
