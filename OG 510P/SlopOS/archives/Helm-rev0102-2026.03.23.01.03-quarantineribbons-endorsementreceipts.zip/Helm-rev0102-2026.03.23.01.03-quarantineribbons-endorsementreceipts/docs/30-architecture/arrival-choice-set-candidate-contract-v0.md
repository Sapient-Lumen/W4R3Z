# Arrival choice set candidate contract v0

Purpose: define one compact shell-owned **bounded candidate-set surface** for a landing,
rebind,
or selective-adoption moment where Helm does not already have one exact local target.

An **arrival choice set** is the positive sibling of a near-match fence.
A near-match fence says “do not silently pick this.”
An arrival choice set says “here are the bounded admissible candidates,
what exact basis each one corresponds to,
and what adopting each choice would imply.”

It should compose with:

- receiver fit cards
- rebind ladders
- landing rehearsals
- arrival overlays
- near-match fences
- anchor maps
- basis stamps
- surface core digests
- and slot verdict ledgers

## Why this move now

Helm already knows how to refuse a merely similar target.
It already has landing rehearsals,
fit cards,
and compare surfaces.
What it still lacks is one small honest surface for the moment after “not exact” but before “chosen.”

SlopOS keeps teaching this clearly through the namecert selection boundary:
if evaluation yields many admissible candidates,
the system should expose that fact rather than hiding it under a winner rule.
Current tools keep validating the softer version of the same lesson:
compare before accept,
show the list of changed things,
and only act when the operator picks one path.

That makes Helm ready for one bounded explicit choice surface.

## Candidate shape

A first useful arrival choice set would likely include:

1. **Owner surface witness**
   - landing manifest id
   - deck recipe id
   - exact action key family id
   - dock band id
   - or another admitted shell-owned owner

2. **Candidate table**
   - candidate id
   - target kind / slot class
   - exact target ref when one exists
   - basis stamp or compared-basis ref
   - match grade
     - exact
     - admissible-but-not-exact
     - local-default-backed
     - pending proof
   - risk / consequence note
     - adopt as-is
     - requires rebind
     - would create local overlay
     - would drop carried detail

3. **Selection guardrails**
   - no hidden default winner
   - no automatic promotion from near match to exact
   - explicit refusal path
   - explicit “keep pending” path

4. **Tiny next actions**
   - inspect candidate
   - compare candidate side by side / overlay
   - choose candidate for one slot
   - leave unresolved
   - reopen rebind ladder

## Rules that matter

### 1. A choice set is bounded,
not a fuzzy search page
The first version should stay small and tied to one landing problem.
It should not become a giant “search everything nearby” surface.

### 2. The shell must not hide a winner rule
If multiple admissible candidates exist,
Helm must not quietly pick by recency,
name similarity,
window proximity,
or any other hidden heuristic.

### 3. Candidate basis must stay explicit
The operator should be able to see what exact basis or witness each candidate corresponds to.
Human-friendly labels are welcome,
but labels are not enough.

### 4. Choice is weaker than adoption
Selecting a candidate does not by itself mean the whole incoming surface has been adopted.
The actual outcome still belongs on stronger landing or adoption seams.

### 5. The first version should stay narrow
Start with one or two homes,
such as deck-recipe landing or exact-action-key rebinding,
instead of universalizing the pattern immediately.

## Best first homes

- one deck recipe landing where a carried slot has two admissible local targets
- one exact action key family where the target handle must be rebound from a bounded candidate set
- one companion bundle landing where a carried resource ref can map to one of several local resources
- one dock item or deck card whose carried destination is unavailable but a few admissible local replacements exist

## What this is not

- not a global resolver
- not a search engine
- not permission for hidden ranking
- not proof that any candidate is exact unless it says so
- not full adoption

## A good first proof slice would show

- one landing with no exact target,
- one arrival choice set exposing two or three bounded candidates,
- one candidate selected explicitly,
- one candidate refused,
- and one slot verdict showing what happened next.

## Why this seems worth keeping warm

Arrival choice sets look like the smallest honest answer to the question,
“what should Helm do when there is not one exact binding but there are a few admissible possibilities?”
They keep Helm fast,
inspectable,
and resistant to hidden winner folklore.
