# Attention window candidate contract v0

Purpose: give Helm one shell-owned object for **bounded attention governance** so the shell can keep quieting, active-only delivery periods, maintenance posture, and narrow critical-only interruption rungs separate from source truth, watch state, notification history, and live authority.

An **attention window** is a shell-owned bounded attention object bound to:
- one or more exact attention subjects,
- one declared time shape,
- and one declared quiet / active / maintenance posture.

It is a candidate move, not a freeze.

## Candidate shape

A first useful attention window would likely include:
- attention-window id
- exact target refs (subscription / watchpoint / patrol route / digest lane)
- target-preview witness for broader scoped rules
- fixed or recurring time shape
- mode (quiet / active-only / digest-only / maintenance / critical-only)
- channel or interruption rung
- optional rate / burst budget
- optional authored reason / note
- current state
- start / end / next occurrence posture
- inspect / end-now / disable / adopt actions
- source witness for imported/shared attention windows
- optional linked timeline-marker ref for maintenance/change context

## Candidate posture

### 1. Bound to exact shell-owned targets
An attention window should name exact shell-owned subjects.
A broad rule should still preserve a preview of what it will touch.

### 2. Quieting is not healthy state
If a window suppresses delivery,
that does not mean the underlying watchpoint or watched condition is healthy,
recovered,
or gone.

### 3. Evaluation and delivery stay separate
An attention window may suppress or reshape delivery,
but it should not silently rewrite evaluation state.
If Helm is still evaluating,
that posture stays visible.

### 4. Recurring windows and one-off silences are different
A recurring quiet schedule,
a one-off silence,
and an active-only delivery period should not collapse into one fuzzy mute flag.
The time shape matters.

### 5. Maintenance and disable are different
A maintenance-range attention window may explain why attention is quiet right now.
That should stay different from disabling the underlying watch or service entirely.

### 6. Critical-only is a narrower rung
If Helm ever lets some delivery break through quiet posture,
that rung should be visibly narrower and more reviewed than ordinary attention.
It should not become ambient urgent-law.

### 7. Imported/shared windows start weaker
Imported or shared attention windows should not silently arm local interruption law.
Inspect / adopt / fork / hold should remain visible.

### 8. Requesting attention is not durable truth
A delivered notification,
dismissal,
or timeout should not become the only durable proof that something was seen,
acknowledged,
or approved.
Durable truth stays elsewhere.

## Good first proof slices

- one recurring weekend quiet window over an exact watchpoint
- one one-off silence over a triage saved-view subscription
- one maintenance-range attention window linked to a timeline marker and still showing the underlying watchpoint in warning
- one digest-only quiet rule over a patrol route or view-subscription family
- one imported team quiet schedule that arrives paused until adopted locally

## What to avoid

1. **Do not let quiet windows masquerade as recovery.**
2. **Do not let critical-only become ordinary product law.**
3. **Do not let imported windows silently arm local attention.**
4. **Do not let quieting hide the stronger source or watch state.**
5. **Do not turn attention windows into a hidden generic scheduler or workflow engine.**
6. **Do not let notification presentation stand in for durable acknowledgement.**

## Working stance

Attention windows now look like the missing attention-governance object in Helm's support stack.
They let Helm say:
- this is still warning,
- delivery is quiet until Monday,
- this maintenance range ends at 03:00,
- this one route is digest-only,
without pretending that silence equals health or that interruption equals durable truth.

## New pressure from rev0082

Attention windows now want a nearby **reach preview** before a mute, quiet, or maintenance act lands over more than one watchpoint or monitor-like subject.
An **affected-set witness** should later keep predicted muted set and observed muted set inspectable instead of relying on memory.
