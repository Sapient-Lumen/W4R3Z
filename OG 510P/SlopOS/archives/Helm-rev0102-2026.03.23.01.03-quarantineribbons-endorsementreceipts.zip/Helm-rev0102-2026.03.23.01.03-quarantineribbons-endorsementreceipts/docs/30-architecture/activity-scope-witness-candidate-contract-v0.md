# Activity scope witness candidate contract v0

Purpose: explore one small reusable shell-owned move for showing which dimensions of an activity continuity claim are actually in play.

An **activity scope witness** is a compact shell-owned witness strip, chip row, or small card.
It does not replace a cockpit, entry kit, current-live beacon, or binding witness.
It complements them by answering a narrower question:
**what counted as “the same activity,” and what nearby context was kept out?**

This is a candidate move, not a freeze.

## Candidate shape

A first useful activity scope witness would likely include:

1. **Activity subject**
   - one named activity / capsule / cockpit / entry kit / binding subject
   - one exact shell-owned reference

2. **In-scope axes**
   - the dimensions that currently matter for the continuity claim
   - for example: object/project, provider, workspace lane, working tree, peer/remote, account/profile/session, imported/shared posture, or another reviewed axis

3. **Ambient exclusions**
   - nearby visible context that was present but did **not** count as same-activity proof
   - for example: current frontmost workspace, sibling window family, remembered profile, adjacent browser session, nearby peer, or generic same-app glow

4. **Scope state**
   - exact-scoped
   - widened
   - operator-switched
   - unknown

5. **Allowed action ladder**
   - inspect basis
   - inspect nearby current-live beacon
   - open cockpit or entry kit
   - attach exact
   - proceed with widened scope knowingly
   - fresh launch / fresh attach
   - hold / repair

6. **Relation to nearby witnesses**
   - link to the nearby binding witness when scope participated in a saved-to-live join
   - link to the nearby continuity choice witness when the same-activity story depended on an authored switch or substitute
   - link to the nearby receipt, capsule diff, or entry kit when the scope basis came from those surfaces

## Guardrails

1. **Not a giant ontology panel**
   - the first useful version should stay compact and reusable.

2. **Not a hidden matcher with better badges**
   - the point is to reveal scope basis, not decorate silent widening.

3. **Not mandatory everywhere**
   - only surfaces making meaningful continuity claims need it.

4. **No fake exactness**
   - widened, operator-switched, and unknown must stay visibly distinct from exact-scoped.

5. **Evidence should stay revealable**
   - a small witness is fine,
   - but it should be able to open the nearby basis path when the operator wants detail.

## Why this looks promising

Helm is accumulating several saved/planned continuity luxuries:
- capsules,
- layout templates,
- activity cockpits,
- activity entry kits,
- binding witness cards,
- stronger Recall cues,
- and current-live beacons.

A tiny scope witness looks like the cheapest way to stop those luxuries from inheriting ambient profile/account/browser/remote/workspace glow by convenience.
It now also looks like the right companion for current-live beacons, because a beacon without a counted-scope explanation can still overclaim.

It also gives Helm another unusually good kind of magic:
**return-to-task surfaces that can tell you not only whether they found something, but whether they found it in the right scope.**

## First proof-bearing specimen

A narrow specimen would be enough:
- one activity entry kit with an exact-scoped return path,
- one binding witness that widens one axis visibly,
- one operator-switched case,
- and one hold / inspect path instead of silent same-activity bluffing.

## Failure modes to avoid

- a giant scope editor before one tiny witness exists
- a chip row that still hides what counted and what did not
- remote/profile/account/browser scope claims that the shell cannot actually explain
- duplicating Operations Center tables without improving activity truth
- forcing every surface to display a scope witness even when no continuity claim is being made
