# Fork receipt candidate contract v0

Purpose: define one compact shell-owned **durable ancestry witness** for the moment a saved,
portable,
shared,
or published surface becomes a **new copy/fork** rather than a preserved-lineage continuation.

A **fork receipt** is the durable sibling of lineage modes.
Lineage modes expose the choice.
A fork receipt keeps the resulting truth inspectable later.

It should compose with:

- lineage modes
- promotion receipts
- landing manifests
- surface core digests
- residue ledgers
- slot verdict ledgers
- publication ladders
- materialization bays
- and default-fill receipts

## Why this move now

Helm already has good machinery for receipts,
landing,
and slotwise truth.
What it still lacks is one small durable answer to:

**when a new shell surface was born from another one,
what exactly carried over,
what lineage claim was severed,
and what started fresh?**

Current tools keep validating that this distinction matters.
Figma lets people publish as copy instead of preserving component connections.
VS Code lets people create profiles by copying from templates or existing profiles rather than claiming same active identity.
Notion template duplication is explicitly snapshot-like and results in a new page in the receiver workspace.

That makes Helm ready for a compact ancestry witness.

## Candidate shape

A first useful fork receipt would likely include:

1. **Origin witness**
   - origin surface id
   - origin surface core digest
   - origin owner family
   - source revision or basis stamp when relevant

2. **New surface witness**
   - new surface id
   - new owner family
   - creation mode
     - fork-copy
     - starter-instantiation
     - forced-copy-on-publish

3. **Carry summary**
   - carried slot classes
   - reset slot classes
   - omitted residue classes
   - receiver-local default fills when they happened
   - whether future update linkage was intentionally severed

4. **Tiny next actions**
   - inspect ancestry
   - compare origin and fork
   - publish the fork
   - keep diverging locally
   - export a new portable core from the fork

## Rules that matter

### 1. A fork receipt should never impersonate preserved lineage
The entire point is to witness that a new thing exists now.
The receipt may preserve ancestry.
It must not imply same-object continuity.

### 2. Carry and reset must stay explicit
If some weak classes carried while others were reset,
that should remain visible.
A fork is not a black box.

### 3. Receiver-local fills belong in the story
If the new fork became viable partly through local defaults or local overlays,
that fact should not disappear.

### 4. The first version should stay narrow
Start with one cross-boundary family.
Do not design a global ancestry ledger for every shell object before one good specimen exists.

### 5. The receipt should help later explanation
The value is not only immediate debugging.
It is also later recall:
why do these two similar surfaces no longer update or behave as one?

## Best first homes

- a deck recipe published as copy instead of preserved lineage
- a dock band imported as a local fork from a shared parent
- a copied exact-action-key family that preserves ancestry but resets some local target bindings
- a starter-instantiated activity entry kit that records recipe ancestry but no same-lineage claim

## What this is not

- not a universal VCS for Helm
- not a sync diff
- not proof of current live fit
- not a substitute for promotion receipts or slot verdict ledgers
- not a retroactive guess about user intent

## A good first proof slice would show

- one source surface,
- one new fork created from it,
- one receipt naming origin,
  new identity,
  carried classes,
  reset classes,
  and severed update-lineage,
- and one later compare that uses the receipt to explain divergence honestly.

## Why this seems worth keeping warm

Fork receipts look like the smallest honest way to keep “publish as copy” or “duplicate from starter” from dissolving into folklore.
They make ancestry visible without lying about sameness.
