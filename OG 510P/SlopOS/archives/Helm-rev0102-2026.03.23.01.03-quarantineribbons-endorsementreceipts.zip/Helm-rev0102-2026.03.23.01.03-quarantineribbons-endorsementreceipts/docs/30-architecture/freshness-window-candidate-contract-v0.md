# Freshness window candidate contract v0

Purpose: give Helm one compact shell-owned way to express **how long one exact object remains meaningfully fresh,
how it decays,
and what exact revalidation rails are allowed**.

A **freshness window** is not a universal live oracle.
It is not a cache-admin console.
It is not authority by timestamp.
It is the shell-owned answer to:

**how fresh is this bounded object right now,
what weaker stale posture still applies,
and how should the shell help me re-check it?**

## Candidate posture

### 1. Freshness is local policy over exact object + exact basis
A freshness window belongs to one exact shell object such as:
- one saved-view query slice
- one glance derivation
- one watch summary/output
- one claim envelope
- one review ticket
- one handoff packet or receiver-fit card

The window must point at exact basis/source witness.
It does not mean “latest in general.”

### 2. Decay happens in visible stages
A good first ladder now looks like:
- fresh
- stale but usable while revalidating
- stale only as explicit fallback / if-error posture
- expired / hold
- unknown / unverifiable

### 3. Revalidation rails stay explicit
A useful first rail family may include:
- background revalidate
- revalidate now
- reopen exact source
- compare current against stamped basis
- invalidate by tag/family/provider reason
- hold / rereview

### 4. Served-stale posture stays visibly weaker
If an object is being shown while stale,
the shell should say which weaker class applies:
- stale while revalidating
- stale if upstream/source failed
- stale because receiver cannot verify
- stale because review is old and stronger act is blocked

### 5. Revalidation reason should be revealable
Good reasons include:
- time-based
- tag/family/source change
- reopen/focus/mount
- explicit operator request
- deployment/rollout/import event
- failure fallback

### 6. Surface form can change the budget
A glance card,
Overview tile,
watch output,
claim envelope,
and exact saved view may share source basis,
but they do not need the same freshness budget.

## Candidate minimal shape

A first useful freshness window likely needs:
- exact id
- owner object id
- exact basis/source refs
- observed_or_cut_at
- fresh_until
- stale_usable_until when relevant
- fallback_only_until when relevant
- expiry_or_hold_after when relevant
- receiver_can_verify boolean or posture
- current freshness class
- revalidation rails
- last_revalidated_at / reason / result when relevant

## Best first homes

- one glance derivation over a saved view
- one watchpoint summary card distinct from evaluation cadence
- one claim envelope that mixes sourced and derived content
- one Overview card composed from linked views and handles
- one handoff packet / receiver-fit card where freshness cannot be proven locally

## Guardrails

1. **No universal latest-following promise**
2. **No timestamp badge masquerading as authority**
3. **No hidden background refresh that silently changes saved meaning**
4. **No endless stale reuse without named weaker posture**
5. **No forcing live-query posture on every surface**
6. **No provider-owned hidden TTL folklore**
7. **No apply/adopt rung that ignores freshness decay when stronger review is required**

## Working stance

Freshness windows now look like the missing shared law under several already-warm Helm objects.
They let the shell say something unusually useful:

**this is the exact object you are looking at,
this is how fresh it still is,
this is the weaker stale class if any,
and this is the exact responsible way to revalidate it.**
