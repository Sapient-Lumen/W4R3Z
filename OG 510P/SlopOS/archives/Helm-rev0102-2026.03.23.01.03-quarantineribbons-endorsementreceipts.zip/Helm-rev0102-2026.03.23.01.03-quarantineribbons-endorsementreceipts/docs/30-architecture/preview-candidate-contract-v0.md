# Preview candidate contract v0

Purpose: turn Preview from a vague “nice desktop feature” into a narrow candidate contract.

Preview is **not** a pillar.
It is a cross-cutting shell power that now looks important enough to deserve a candidate contract note.

## Candidate posture

1. **Preview is shell-owned and reusable**
   - Object Browser
   - Omnibox
   - Recall
   - Exchange
   - Operations Center evidence panes

2. **Preview is inspect-before-commit, not side-effect execution**
   - preview should not silently become open/launch/import/run

3. **Provider model is explicit**
   - preview providers may exist for object kinds
   - provider identity and failure should be inspectable
   - Preview should not degrade into hidden per-app plugin chaos

4. **Truth posture matters**
   - previewed object kind
   - provider used
   - freshness or staleness where relevant
   - limitations / unsupported facets where relevant

5. **Preview should be action-adjacent, not action-confused**
   - preview panes may offer typed quick actions or route proposals
   - a compact preview rail now looks like the best candidate shape for that adjacency
   - but preview itself should still remain inspect-before-commit

6. **Folders, views, and transfer subjects may also need preview**
   - not just documents or media
   - folder or collection summaries may matter as much as file previews

## Candidate v0 specimen

A narrow proof-bearing slice could be:
- one document/object preview in Object Browser,
- one Omnibox result preview,
- one Exchange preflight preview,
- one Recall preview,
- and one Operations Center preview-failure surface.

## Related candidate

- `preview-rail-candidate-contract-v0.md` now carries the more specific “bounded next-step edge next to preview” pressure.

## Guardrails

- do not let Preview become a hidden execution path
- do not let preview-adjacent quick actions hide review or provider identity
- do not force Preview into app-local ownership
- do not promote Preview to pillar status before the provider/trust story is earned

## Working stance

Preview is increasingly likely to become a real shell service family, but the provider contract, exact trust posture, and execution barriers are still open enough that Helm should keep this as a candidate contract rather than a frozen pillar-family posture.
