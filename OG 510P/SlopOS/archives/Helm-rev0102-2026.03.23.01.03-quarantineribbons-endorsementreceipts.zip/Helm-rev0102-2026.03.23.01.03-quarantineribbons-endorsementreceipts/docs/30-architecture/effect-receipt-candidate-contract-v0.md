# Effect receipt candidate contract v0

Purpose: define one compact shell-owned **durable post-change witness** for a stronger act,
so Helm can say what exact effect actually happened after review / apply / adopt / restore / import / branch / publish rather than leaving aftermath truth to toasts,
spinners,
or memory.

An **effect receipt** is the post-act sibling of an action warrant.
It should compose with:

- action warrants
- drift gates
- claim envelopes
- reliance ladders
- current-live beacons
- contribution witnesses
- slot verdict ledgers
- checkpoint branches
- and Operations Center / Recall surfaces

## Why this move now

Helm now has a much better answer to:

- what was selected
- what influenced the result
- what the result is claiming
- what exact stronger change is being proposed
- and whether the reviewed basis drifted before the user took the stronger rung

What Helm still lacks is one compact durable answer to:

**what exact effect actually happened after the stronger act?**

Without that,
Helm risks letting:
- an action warrant impersonate the aftermath,
- a transient success badge carry too much truth,
- historical action rows blur into current-live truth,
- or partial shell effects collapse into “mostly worked.”

Current tools keep validating the missing need.
Jira playbook outputs, PagerDuty action logs/output reports, AWS Automation step-execution records, and GitHub workflow summaries all keep separate bounded aftermath surfaces for one run or one step rather than pretending a stronger act simply became live truth.
Preview/apply/undo is better than ever,
and review-before-merge is common,
but durable exact aftermath truth is still often weaker than it should be.

## Candidate shape

A first useful effect receipt would likely include:

1. **Source act witness**
   - action warrant id when present
   - optional landing-train id and rung id when the act was ordered or staged
   - source surface id
   - action family id
   - exact operator / delegated actor witness when relevant

2. **Outcome class**
   - applied-exact
   - applied-partial
   - no-op
   - refused
   - duplicate-suppressed
   - superseded
   - rolled-back
   - or another admitted small vocabulary

3. **Affected-set witness**
   - exact object / slot / file / route count
   - compact diff or changed-set ref when relevant
   - skipped or unresolved count when relevant

4. **Basis relation**
   - reviewed basis stamp or packet
   - whether the effect matched that basis exactly,
     required repair,
     or landed under partial/fallback posture

5. **Currentness relation**
   - link to any current-live beacon,
     checkpoint,
     or later superseding receipt
   - one explicit signal that this receipt is durable historical effect truth,
     not a permanent current-state oracle

6. **Nearby next actions**
   - inspect changed set
   - compare against current
   - undo / redo / restore
   - reopen unresolved slots
   - export or cite this effect receipt

## Rules that matter

### 1. An effect receipt is stronger than a toast,

### 1b. A receipt should preserve ordered or staged promotion witness when relevant
If an effect happened through a landing train or guarded promotion rung,
the receipt should say so.
The shell should not flatten:
- direct one-step landing,
- queued ordered landing,
- and partial staged promotion
into the same historical aftermath story.

but weaker than current-live truth
The receipt should prove one exact historical aftermath.
It should not silently become a standing live-state badge.

### 2. Partial effects must stay named
If only part of the stronger act landed,
that partiality should remain explicit.
Do not hide it behind a cheerful whole-surface status word.

### 3. Receipt vocabulary should stay small
Start with a small exact outcome vocabulary.
Do not invent a giant universal workflow-state machine before one specimen exists.

### 4. Undo / redo should stay attached to durable effect truth
Undo is much safer when the shell can point at one exact prior effect.
Redo is much safer when the same prior effect remains inspectable.

### 5. The first version should stay modest
Start with one or two effect families,
not all shell actions at once.

### 6. Effects and completion must stay visibly different
A receipt may witness the bounded aftermath of one exact act,
but it should not silently become proof that every downstream target finished successfully or still remains live now.

## Best first homes

- one AI-assisted apply/adopt action that yields a durable effect receipt
- one checkpoint restore that leaves behind an exact restore-effect receipt plus redo relation
- one imported selective landing that leaves one whole-surface effect receipt plus one slot verdict ledger
- one publish/share/import path where effect history and current-live truth stay visibly different

## What this is not

- not a giant audit warehouse
- not a universal task-status API
- not a permanent current-state oracle
- not permission to flatten partial effects into whole success
- not a substitute for current-live beacons

## A good first proof slice would show

- one warrant-approved action,
- one durable effect receipt,
- one exact changed-set or affected-set summary,
- one nearby reversal warrant or repair ladder path,
- one later compare-to-current path,
- and one case where the receipt is visibly historical rather than current-live.

## Why this seems worth keeping warm

Effect receipts now look like the smallest honest answer to the question Helm still cannot answer cleanly enough after a strong act:

**what exact effect happened here,
and what should I trust about it now?**


## Adjacent recovery truth

An effect receipt should often be the parent witness for:
- one reversal warrant when exact reverse / restore / revoke is still plausible
- one repair ladder when the smaller honest next move is redo, rerun-failed-subset, replay-on-fresh-basis, compensate, or hold

The receipt should not try to impersonate those recovery choices by itself.
## Current warming note

This contract is now explicitly reheated by `docs/00-meta/helm-aftermathreceipts-slotledgers-2026-03-22.md`.
The strongest current outside pressures are GitHub Actions previous-attempt + rerun-failed-jobs posture, Google long-running operations done/response/error posture, AWS Systems Manager step execution records, AWS Step Functions redrive preserving successful-step history, and Kubernetes indexed-Job terminal-versus-per-index truth.
