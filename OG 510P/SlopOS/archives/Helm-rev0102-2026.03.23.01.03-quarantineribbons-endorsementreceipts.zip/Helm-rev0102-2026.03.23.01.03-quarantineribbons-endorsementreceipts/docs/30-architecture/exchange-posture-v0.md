# D-EXCHANGE Exchange posture v0 (typed movement, exact routes)

Purpose: define Helm's transfer surface so paste, drop, clipboard, share, attach, forward, import, and export become explicit shell-owned packet and route truth rather than helper magic.

## Posture (v0)

1. **Exchange is one typed movement family**
   - paste, drop, clipboard, share, attach, forward, import, export, and object handoff should compose through typed packets and routes instead of flattening into raw text or raw paths

2. **Ingress is inert until routed**
   - packets may be inserted, inspected, quoted, imported, staged, attached, or sent
   - they should not silently inherit execution or strong-action authority just because they arrived from clipboard, drop, or a visible selection

3. **Selection, intent, route, and basis witness stay explicit**
   - open, reveal, insert, import, send, attach, and forward are different actions
   - Exchange should preserve exact subject identity and record whether the route was exact, mediated, held, downgraded, or denied
   - when a packet, import, publish, or stronger follow-on act depends on one reviewed mutable basis, Exchange should preserve or surface that basis witness instead of silently following a newer head
   - when a routed import/attach/publish action becomes strong enough to deserve review, Exchange should prefer action warrants plus drift gates over vague helper magic

4. **Transfer truth belongs across the shell**
   - Object Browser, Omnibox, Desktop Flow, terminal/capshell, Recall, and Operations Center should all be able to originate, inspect, or receive transfer receipts
   - when a landing stays candidate-only, those same surfaces should be able to see its shadow-lane or adoption-harbor posture instead of flattering it into “imported” truth

5. **Approximate convenience must not hide widening**
   - helper-like behaviors may exist, but they must not erase exactness, subject identity, or mediation posture

## v0 must exist

- typed ingress for clipboard, paste, drop, and file-like payloads with inspect / insert / import choices
- explicit candidate-landing posture when imported or receiver-local work should first land in a shadow lane or adoption harbor
- explicit landing-train posture when several reviewed candidates aim at one receiver-local or shared target lane
- typed selection/intent routes that keep open / reveal / send / attach / forward distinct
- visible transfer, attach, and forward receipts plus hold/deny reasons
- visible reversal or compensating-repair posture when undoing a shared/public exchange effect should stay distinct from rewriting authored packets or receiver-local live state
- basis stamps or equivalent exact-basis witness when travel or follow-on acts depend on one carried or reviewed basis
- shell-visible subject identity and exactness posture for strong routes
- claim envelopes and reliance ladders when route recommendations or import proposals mix observed packet facts, sourced route evidence, helper analysis, and unapplied next actions

## Temptations to ban early

- path paste as the universal file-transfer UX
- silent promotion from selected thing to execution target
- “smart click” behavior that hides the real route or exactness class
- flattening typed payloads into lossy strings too early

## Phase 1 non-goals

- freezing one universal clipboard backend
- freezing one final packet schema for every transfer kind
- importing ambient host helper behavior as invisible fallback

## Wiring

- decision surface: `decision-map.md` (D-EXCHANGE)
- related docs: `ingress-packets-posture-v0.md`, `object-browser-posture-v0.md`, `omnibox-posture-v0.md`, `desktop-flow-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`, `operations-center-posture-v0.md`
- design pressures carried forward from SlopOS/Schell: typed transfer, import-vs-open separation, selection packets, intent packets, route witnesses, attach/forward honesty
- assurance anchors: CH-HELM-0014, I-HELM-0013

11. **Transfer aftermath stays exact**
   - when a stronger attach/import/publish/adopt step lands, Exchange should prefer effect receipts and slot verdict ledgers over vague “sent/imported/shared” folklore
   - selective landing, rebound, default-fill, pending, and refusal should stay recallable later rather than only visible during one landing session

12. **Exchange recovery should stay exact**
   - when a shared, published, attached, or imported effect later needs correction, Exchange should be able to open a reversal warrant or repair ladder rather than flattening every recovery into delete / resend / retry folklore

- travel, import, and share must disclose what authority did not travel and what fresh receiver-local grant would still be needed


- when a share/publish/import route changes who can currently see a surface, Exchange should prefer reveal windows plus audience ladders over one flattering shared badge
- when a historical publish/share receipt is reopened, Exchange should keep that receipt weaker than any current-live reveal window for the same subject


- cohort windows and minimization ladders should keep exact selected-slice truth visible where this surface would otherwise tempt Helm to widen from one chosen subset into one whole-family default.

## New pressure from rev0082

Exchange now benefits from one compact reach-preview strip beside stronger export, reveal, attach, publish, and handoff moves so exact selected cohort and exact included target set stay visibly different truths.
