# Lineage mode candidate contract v0

Purpose: define one compact shell-owned **cross-boundary identity choice** for a saved,
portable,
shared,
published,
or moved surface.

A **lineage mode** answers:
**is this operation preserving lineage,
creating a fork/copy,
or instantiating a fresh local starter from a recipe/template?**

It should compose with:

- materialization bays
- publication ladders
- handoff packets
- promotion receipts
- portable cores
- local overlays
- landing manifests
- surface core digests
- arrival choice sets
- and fork receipts

## Why this move now

Helm's landing story has become much more truthful.
It now knows about portable cores,
local overlays,
landing manifests,
fit cards,
rebind ladders,
choice sets,
and slot verdicts.

But one important ambiguity remains.
Too many cross-boundary moments still risk collapsing into one flattering story:
- “it moved”
- “it imported”
- “it landed”
- “it is the same thing here now”

Current tools are finally teaching the opposite discipline clearly.
Figma distinguishes preserving component connections from publishing a copy.
VS Code distinguishes copy-from-template,
copy-from-existing,
and empty profile creation.
Notion distinguishes moved structure,
linked views,
duplicated templates,
and fresh programmatic setup.

Helm is ready for one small explicit identity-choice surface.

## Candidate shape

A first useful lineage mode surface would likely offer a bounded choice among:

1. **Preserve lineage**
   - same surface family id
   - same durable relation family
   - stronger continuity claim
   - may require exact fit / rebind / trust steps

2. **Fork as copy**
   - new local or shared surface id
   - origin relation preserved only as ancestry witness
   - no silent future update or same-object claim
   - safe local divergence expected

3. **Instantiate from starter**
   - clearly fresh local object from a recipe/template/packet
   - not a claim of same lineage
   - starter basis and template source remain visible
   - receiver-local defaults may fill admitted weak classes

## Rules that matter

### 1. Preserve-lineage is the strongest claim
If Helm says a move preserves lineage,
that should be a named stronger mode,
not the flattering default of any successful arrival.

### 2. Fork and instantiate are not the same
A fork/copy carries ancestry from a concrete prior surface.
A starter instantiation may come from a recipe or template and should remain visibly “new from starter,” not “same thing elsewhere.”

### 3. Mode choice belongs before the stronger act
The shell should not decide after the fact whether the operator “must have meant” move versus copy.
The choice should be exposed before the stronger publication/import/materialization step.

### 4. Mode choice should compose with slot law
The lineage mode explains the identity claim of the whole surface.
It does not erase slotwise fit,
rebind,
default-fill,
or refusal rules.

### 5. The first version should stay narrow
Start with one or two cross-boundary homes,
such as deck publication,
dock-band sharing,
or exact-action-key family export/import.
Do not universalize the pattern prematurely.

## Best first homes

- publish a deck recipe while choosing preserve-lineage versus fork-copy
- import a dock band and decide whether the receiver is continuing an existing shared lineage or creating a local copy
- create a new exact-action-key family by copying from an existing family versus starting fresh from a template
- materialize a handoff packet as either same-lineage continuation or fresh local fork

## What this is not

- not a giant sync constitution
- not permission for hidden relinking
- not proof of receiver-local fit
- not a substitute for landing manifests or fork receipts
- not a whole version-control system for shell surfaces

## A good first proof slice would show

- one cross-boundary surface,
- one explicit preserve-lineage choice,
- one explicit fork-as-copy choice,
- one explicit instantiate-from-starter choice,
- and durable witnesses showing how those three outcomes differ afterward.

## Why this seems worth keeping warm

Lineage modes look like the smallest honest answer to one increasingly important user question:
**did this move keep the same thing alive,
or did it make a new thing?**

Helm gets more magical when it answers that question clearly,
not when it flatters the operator into thinking every successful landing was a preserved continuity miracle.
