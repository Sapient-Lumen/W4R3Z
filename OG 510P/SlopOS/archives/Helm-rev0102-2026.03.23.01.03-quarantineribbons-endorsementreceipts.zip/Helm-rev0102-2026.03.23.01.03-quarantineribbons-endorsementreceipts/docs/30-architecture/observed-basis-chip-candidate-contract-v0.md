# Observed-basis chip candidate contract v0

Purpose: give Helm one compact shell-owned way to show **what exact mutable basis a visible status or verdict was observed against**.

An **observed-basis chip** is not a current-live grant,
not a current-live beacon,
and not a complete compare view.
It is the shell-owned answer to:

**this visible state was observed against which exact basis,
and how does that basis relate to the current one?**

## Candidate posture

### 1. The chip belongs next to a stronger primary surface
An observed-basis chip usually attaches to:
- a condition strip
- an access verdict card
- a claim envelope
- a glance derivation
- a watchpoint card
- a current-live-or-historical reentry card
- or a stronger act row

It is a witness chip,
not the main object.

### 2. Basis relation should stay explicit
A first useful vocabulary now looks like:
- observed on current basis
- observed on older basis
- observed on exact basis N
- historical-only basis
- cannot compare to current
- current changed since observed
- hidden-current / incomplete comparison rights

### 3. Exact basis is better than vague recency when possible
When the shell has an exact witness,
it should prefer that over vague wording like:
- recent
- up to date
- latest known
- maybe current

The point is to stop stale or historical status from wearing the badge of now.

### 4. The chip stays weaker than current-live truth
Even a matching observed-basis chip is still a witness about observation,
not a substitute for live authority,
live leases,
or fresh act admission.

### 5. Chips should open compare or revalidate rails nearby
A chip is most useful when it can lead to:
- compare current vs observed basis
- refresh / revalidate
- inspect change cursor
- inspect warrant / receipt / verdict context

## Candidate minimal shape

A first useful observed-basis chip likely needs:
- exact id
- linked primary surface id
- exact basis ref or basis witness
- relation_to_current class
- visibility_gap posture when current comparison is incomplete
- compare / revalidate rails when available
- observed_at

## Best first homes

- next to a condition strip in Operations
- next to a watchpoint or saved-view strip in Browser
- next to a Recall result that is historical rather than live
- next to an access verdict that depended on older reviewed basis
- next to a glance derivation or summary card whose source may have moved

## Guardrails

1. **No fake “latest” language when exact basis is known**
2. **No pretending chip == current-live authority**
3. **No hiding the basis relation behind a generic stale icon**
4. **No giant version-tracking constitution for v0**
5. **No silently repairing old basis into new truth**

## Working stance

Observed-basis chips now look like one of Helm's most useful tiny honesty objects.
They let the shell say:

**this visible state was observed against that exact basis,
this is whether it still matches current,
and this is the nearby compare or revalidate path.**
