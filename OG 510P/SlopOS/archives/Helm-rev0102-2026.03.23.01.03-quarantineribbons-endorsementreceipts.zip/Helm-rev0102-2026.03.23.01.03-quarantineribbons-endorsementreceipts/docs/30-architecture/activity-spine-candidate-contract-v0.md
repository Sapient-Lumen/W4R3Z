# Activity spine candidate contract v0

Purpose: give Helm one compact shell-owned **scoped work object** that can gather views, checkpoints, quick actions, launch/layout starters, and current-live cues for one piece of work without turning that bundle into fake live continuity.

An **activity spine** is not a new pillar.
It is a cross-cutting support object.

## Why this move now

Helm now has strong candidate pieces that clearly want to cooperate:
- saved view objects
- checkpoint branches
- review tickets
- command docks / command bands
- launch configurations and layout starters
- current-live reentry cues
- publication ladders
- imported-surface trust posture

What is missing is one shell-owned object that can say:

**these things belong to the same work frame.**

Without that,
Helm risks two bad outcomes:
- everything remains scattered and the shell feels weaker than it should
- or one giant workspace/blob object overclaims liveness, memory, and portability

Activity spines are the middle path.

## Candidate posture

### 1. A spine is scoped, not ambient
A spine must carry an explicit scope/memory posture.
It should be able to answer:
- what resources are in scope
- what resources are out of scope
- whether the spine is personal,
  shared,
  or published
- whether sharing tightened memory/context boundaries

### 2. A spine is not the live lane
A spine may point to:
- one current-live lane
- one current preferred view
- one active checkpoint branch

But the spine itself does not become current live truth.

### 3. A spine gathers objects; it does not replace them
A spine may gather:
- saved view objects
- checkpoints / branches
- review tickets
- evidence briefs
- response kits
- command bands / dock items
- launch/layout starters
- activity memory seeds
- exchange routes or pinned packets

Those members remain their own object families.

### 4. Spine membership should be explicit
Ordinary open,
preview,
recent use,
or share should not silently add a thing to a spine.
Membership should be authored.

### 5. A spine should support one current-live beacon
A useful spine should be able to say:
- this is the current live lane
- this is current but widened
- this is historical but relevant
- this is a saved starter
- this is a review slice

without flattening those into one story.
That beacon should usually be paired with a nearby scope witness when same-activity truth depends on explicit axes.

### 6. Shallow subspines may be useful
A spine may later support small nested subtracks.
This should stay shallow,
named,
and visible rather than becoming giant hierarchy religion.

### 7. Share ladders should stay explicit
Useful early share/posture rungs may be:
- personal only
- shared activity spine
- published starter spine
- imported spine in restricted posture

Cross-boundary arrival should compose with trust posture,
landing rehearsal,
and materialization/adoption.

### 8. Spine memory should be inspectable
A spine should make it possible to inspect:
- attached views
- pinned receipts/tickets/checkpoints/briefs
- current live hook
- optional activity memory seed refs
- current command band
- scope fence
- omitted local residue when shared or exported

## Candidate minimal shape

A useful v0 activity spine likely needs:
- exact id
- title
- scope class / memory posture
- share rung / locality rung
- attached member refs
- optional default/front-door refs
- current-live hook ref
- optional subspine refs
- compact residue / local-only witness when exported or shared

## Best first homes

- one activity with two saved views and one preferred front-door view
- one checkpoint branch linked from the same spine
- one current-live beacon back into Recall
- one small command band/dock slice
- one launch/layout starter
- one honest shared/imported posture where memory/context narrows instead of widens

## Guardrails

- do not let activity spines become the hidden universal object model
- do not let spines impersonate live continuity
- do not let ordinary open/recent/share auto-enroll membership
- do not let shared spines inherit personal context by default
- do not promise giant perfect workspace portability
- do not let subspines become unbounded hierarchy theater

## A good first proof slice would show

- one named activity spine
- two attached saved views
- one linked checkpoint or branch
- one current-live beacon
- one activity-local command band
- one shared/imported restricted posture
- and one honest local-residue witness for what did not travel

## Working stance

Activity spines now look like one of the most promising support objects for Helm.
They can make saved views,
checkpoints,
Omnibox,
Recall,
Object Browser,
Exchange,
and Tiling Shell feel more coherent without adding a pillar or pretending a saved work frame is the same thing as the live lane.
