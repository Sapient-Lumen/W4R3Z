# Basis contrast card candidate contract v0

Purpose: define one compact shell-owned **current-vs-basis compare surface** that can appear when a drift beacon,
drift gate,
review ticket,
action warrant,
entry kit,
or Recall return needs something stronger than a badge but weaker than giant diff religion.

A **basis contrast card** compares **one exact current subject witness** against **one exact basis witness** and shows a bounded digest plus honest next ladders.

It is not the underlying object.
It is not the full history of the object.
It is not a universal diff engine.

## Candidate posture

1. **The pair must stay exact**
   - one current subject witness
   - one exact basis witness
   - one named compare relation
     - reviewed basis
     - last trusted basis
     - adopted basis
     - named version
     - checkpoint basis
     - saved view query basis

2. **The card stays bounded**
   - changed / unchanged / materially drifted / expired / unavailable
   - maybe family or slot counts
   - maybe a small list of changed families/sections/slots/pages/files
   - not a giant raw diff browser first

3. **The basis story stays visible**
   - basis identity or label
   - basis time / review time / restore time / expiry when relevant
   - freshness or availability posture when relevant
   - no decorative “updated” wording with hidden basis

4. **Default actions stay inspect-first**
   - inspect change
   - inspect basis
   - review again
   - update basis
   - branch from old basis
   - hold stronger action
   - reopen exact source

5. **The card should compose with existing Helm moves**
   - drift beacons
   - basis packets
   - drift gates
   - saved view objects
   - checkpoint branches
   - review tickets
   - action warrants
   - effect receipts
   - resource shelves
   - activity entry kits

6. **Unknown and unavailable are allowed answers**
   - basis missing
   - current witness unavailable
   - expiry reached
   - freshness unknown
   - compare unavailable

7. **Locality should stay visible**
   - many contrast cards will be personal,
     activity-local,
     or receiver-local
   - exporting or sharing a contrast card should not make its basis globally authoritative

## Candidate uses

- a saved view object whose cached result basis expired and needs a fresh query before stronger reliance
- an action warrant whose reviewed basis no longer matches the current subject
- an activity entry kit whose preferred front door changed since the named basis was saved
- a resource shelf member that changed since it was curated into the shelf
- a Recall return that says “this changed since the exact version you last trusted”
- a shadow work lane that drifted from the adopted live basis before merge/adoption

## Guardrails

- do not turn basis contrast cards into a giant timeline theater product
- do not auto-refresh the compared basis behind the operator
- do not let the card silently bless stronger actions
- do not force every tiny object into heavyweight compare mode
- do not blur weak changed-since-you-looked cues with exact named-basis comparison

## Candidate v0 specimen

A small proof-bearing slice could be:
- one exact subject,
- one exact basis,
- one contrast card showing unchanged / changed / materially drifted / expired,
- inspect / review-again / update-basis actions,
- and one hold path when a strong act would otherwise overclaim.

## Working stance

Basis contrast cards look like the humane stronger sibling of drift beacons.
They can make Helm feel more truthful and more luxurious at once,
but they should stay compact until one specimen proves they improve return,
review,
adoption,
and change-aware trust without growing into a full diff bureaucracy.
