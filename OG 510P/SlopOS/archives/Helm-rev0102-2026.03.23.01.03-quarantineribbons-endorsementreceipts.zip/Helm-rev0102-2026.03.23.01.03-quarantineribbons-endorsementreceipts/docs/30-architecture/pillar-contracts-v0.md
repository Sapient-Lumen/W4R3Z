# D-PILLARS pillar contracts v0 (must exist, ban early)

Purpose: record the minimum visible shape of Helm's seven pillars plus its native terminal/capshell front-end family before details scatter across later docs.

Design-phase accent: keep the pillars stable, but keep proving them through small cross-pillar specimens. The current best proof stack is parameterized front doors, peek → promote, exact-scope grants, exact remembered handles, constrained helper lanes, named protection gates, pinned-versus-floating handles, rehearsal → compare → promote rails, facet-conflict cards, generation cards, attenuated reveal links, capability budgets, lease windows, renewal rails, effect receipts, slot verdict ledgers, claim envelopes, reliance ladders, access verdict cards, least-widening previews, condition strips, observed-basis chips, trusted chrome lanes, host-effect witnesses, freshness-horizon chips, decay rails, intent sparks, direct-gesture gates, quarantine ribbons, endorsement receipts, caveat sheets, delegation subtrees, triage lanes, and continuity postcards.

Cross-cutting law: compact shell luxuries such as docks, rails, strips, lenses, cockpit cards, and exact trails should be treated as **projection surfaces** over stronger shell truth. They stay bounded, typed, source-witnessed, and non-authoritative by default.

Datacube law: no pillar gets to assume one universal live cube. Multiple explicit saved views are good; ambient global index, ambient sync, and dashboard-overclaim are not.

Authority law: stronger shell acts should expose bounded authority family, subject scope, duration/isolation rung, historical-vs-current grant truth, nearby narrow/revoke posture, and any shell-readable caveats or missing-context requirements rather than collapsing all power into one generic Allow button or buried provider settings.

Reveal law: stronger share/publish/reveal acts should expose audience class, route class, reveal shape, expiry/policy posture, and historical-vs-current reveal truth rather than collapsing all visibility into one generic Shared badge or provider-sheet mystery.

Restricted-first law: imported, rebound, borrowed, or helper-generated structures should be browseable and inspectable before they are trusted enough to execute, adopt, or widen.

Arrival law: foreign or risky arrivals should keep origin evidence, quarantine or risk posture, safe-open posture, explicit endorsement, derivative-versus-source distinction, and live authority visibly separate rather than collapsing into one flattering open/import state.

Plan law: materially stronger shell acts should be able to hold a compact saved-plan / reviewed-basis posture so exact subject, exact scope, exact mutable basis, drift status, and inspect-before-apply review remain visible.

Exposure law: local open, private cohort, org/tailnet, guarded-link, and public should remain visibly different exposure classes rather than collapsing into one vague open/share state.

Handle law: remembered reopen/rebind access should prefer exact handles/bookmarks with visible current, stale, repairable, or re-requestable posture rather than path/title nostalgia.

Sandbox law: helper or delegated lanes should surface file/object scope, network scope, and allow/ask/deny posture instead of inheriting ambient shell reach.

Gate law: materially stronger publish/apply/expose acts may wait on visible protection gates whose pending/passed/rejected results remain distinct from both the proposal and the final aftermath receipt.

Generation law: materially changing saved shell objects should be able to preserve exact generations, compare one generation against another, and roll back explicitly without pretending generation history is current-live truth.

Recipe law: portable starter objects may preserve preferred setup and likely reacquisition paths, but must stay visibly weaker than current-live grants and current-live state.

Budget law: a front door, recipe, flow fragment, or helper lane may declare what authority it may later ask for, but that declared upper bound is not itself a current-live grant.

Renewal law: reacquiring old or expiring power must keep renew-same, renew-narrower, isolated-lane migration, widening, and expiry visibly different; renewal must not silently widen.

Verdict law: blocked stronger acts should keep denied, restricted, stale-basis, missing-live-lease, hidden-policy, unsupported, and unknown posture visibly different; explanation stays weaker than authority.

Least-widening law: when a blocked act might become possible through a narrower delta, Helm should show current-only, exact-subject, isolated-lane, guarded-link, or similarly smaller alternatives before broad persistent widening.

Status law: compact shell status should keep progression, conclusion, restriction, mute posture, teardown posture, and historical-vs-current basis posture visibly different; a small status strip is good, one flattering badge is not.

## Tiling Shell

### Must exist in v0
- directional focus and workspace movement
- predictable split / stack / tab / layout transforms
- shell-owned workspaces and placement policies
- shell-owned activation and focus truth rather than requester-chosen foregrounding

### Ban early in v0
- title/class regex culture as the main customization model
- app-owned global workspace policy
- generic launch surfaces quietly becoming portable placement authority
- “config file is the product” thinking

## Omnibox

### Must exist in v0
- instant summon
- search and act over windows, workspaces, exact objects, views, timeline markers, evidence briefs, response kits, shadow work lanes, adoption-harbor items, activity spines, recall items, exchange routes, and actions
- structured shell actions rather than command-string primacy
- typed provider extensibility with provider-visible actions and results
- exact front-door handles / quicklink-like entry objects as typed summonable subjects
- exact remembered handles / bookmark-grade reopen subjects with visible current / stale / re-request posture
- pinned versus floating handle posture so summon, reopen, share, and act-now subjects can admit whether they bind one exact basis or intentionally follow current truth
- exact generation cards and floating-alias results as visibly different summon/reopen/share subjects
- capability recipes as typed summonable portable starters that remain weaker than live grants or live sessions
- capability-budget chips on front doors and recipes so the operator can see what a starter may later ask for without confusing that upper bound with current borrowed power
- lease-window posture on summonable remembered handles, entry kits, or recipes when a result is about reacquiring old authority rather than simply opening something inert
- parameterized front doors with typed placeholders/arguments and explicit starter-versus-live posture
- weak landing / Overview composition from linked views, front-door handles, patrol starts, glance derivations, watchpoints, nearby markers, nearby briefs, nearby kits, attention-state chips, current-live beacons, and reveal-window chips rather than one giant dashboard plane
- patrol routes as first-class revisit subjects so bounded rounds can be summoned, resumed, inspected, and shared without becoming giant dashboards
- tiny review-strip style preflight surfaces for stronger actions
- action warrants and adjacent drift gates when a quick action graduates into one exact mutable proposed change instead of ordinary open/run folklore
- rehearsal → compare → promote rails when a preview, helper result, or imported candidate becomes strong enough to inspect against live truth and then land explicitly
- landing trains when several adoption-ready or warrant-backed candidates target one exact busy lane and ordered promotion truth matters
- effect receipts when a stronger quick action actually lands so the historical aftermath does not collapse into transient status chrome
- facet ownership / conflict posture on composite saved views, decks, entry kits, and cockpit surfaces when helper proposals, imported recipes, local overrides, or derived defaults would otherwise silently stomp each other
- reversal warrants or repair ladders when the quickest honest next move after a strong action is recovery rather than more forward motion
- preview-promotion ladders that clearly separate inspect, bounded quick action, and stronger promotion exits
- suggestion-first triage proposals that can explain why a route/duplicate/next-step was suggested before any stronger act is taken
- requested-target chooser starts when a strong act is probably about one exact missing or previously granted subject
- visible helper-lane bounds and gate posture when a quick action is actually preparing a stronger publish/apply/expose step
- honest launch ladders for saved entry objects and recent exact objects
- explicit distinction between ordinary open, current-live reentry, durable save/materialize, and stronger publish/branch acts
- current-live beacons and scope witnesses near saved entry objects when same-activity claims would otherwise blur current, historical, or widened posture
- explicit activity memory seeds or tiny context recipes when remembered guidance materially shapes search, launch, planning, or result ordering
- typed review tickets or stable review slices when longer compare/paging/route-review flows should not hover over live-shifting truth
- bounded shell-owned evidence briefs when cross-signal/manual-or-AI curated findings need a shell object stronger than a note pile and weaker than live truth
- bounded shell-owned response kits when exact next steps, exact action affordances, and visible outputs need a shell object stronger than a runbook link pile and weaker than live truth
- bounded shell-owned timeline markers when exact time/range anchors, recent-change context, or causal breadcrumbs need a shell object stronger than generic recents and weaker than live truth
- facet-strip style typed pivots when mixed families would otherwise blur objects, actions, routes, or receipts
- host-owned status/progress visibility for longer-running provider work
- claim envelopes and reliance ladders for AI-assisted results so observed, sourced, derived, remembered, helper-produced, and proposed outputs do not flatten into one answer posture
- freshness windows and revalidation rails so saved/derived/result cards can admit decay and offer exact re-check paths instead of bluffing live truth
- authority windows, lease windows, and grant-rung ladders when a quick action needs stronger shell power so inspect, once, this ask, this activity, isolated-lane only, and persistent authority stay visibly different
- active-borrow beacons and brake rails when the operator needs to see what is not only borrowed now but actually hot now, and what exact or coarse brake is nearest
- freshness-horizon chips and decay rails when the operator needs to know whether a live-looking claim is still current, merely last-confirmed, stale-while-revalidating, or no longer strong enough for a stronger act
- renewal rails when a quick action is really reacquiring or widening old power and the shell should distinguish same-subject renewal from a fresh broader ask
- reveal windows and audience ladders when a quick share/publish/reveal action needs stronger visibility posture so named, org-only, guarded-link, and public/time-boxed reveal stay visibly different
- cohort windows and minimization ladders when a quick ask, reveal, export, rerun, or action should stay bound to one exact selected cohort instead of widening to whole-provider or whole-workspace reach
- reach previews and affected-set witnesses when the shell needs to say what a stronger quick action would currently touch before promotion into a warrant or stronger reveal/mute/apply rung
- action warrants and drift gates for stronger apply/adopt/run moves so exact proposed effect, mutable basis, and downgraded-on-drift posture stay visible
- effect receipts and slot verdict ledgers when the resulting act is partial, selective, or later needs recallable repair truth
- repair ladders when partiality means the operator should choose rerun-failed-subset, replay-on-fresh-basis, reverse-all, or hold instead of a vague retry

### Ban early in v0
- app-launcher-only scope
- PATH-plus-argv as the main UX contract
- hidden side effects that bypass shell receipts for strong actions
- ambient plugin folklore where provider identity or action family is opaque
- universal `open in new tab/new window/reuse this window` folklore on generic launch
- generic open silently creating durable save, recent-authority, publication, or branch side effects

## Object Browser

### Must exist in v0
- split views with strong keyboard navigation
- saved view objects as first-class browser subjects rather than hidden filters
- exact generation rows/cards for materially changing saved shell objects, with compare and rollback posture kept distinct from current live truth
- attenuated reveal-link inspection and recipe inspection as ordinary browser acts when exchange portability matters
- bounded shell-owned subscriptions attached to exact saved views when durable attention improves orientation without becoming app-owned background folklore
- watchpoints over exact saved views when durable evaluated state matters and delivery posture must stay distinct from current state
- linked attention windows when recurring quiet periods, one-off silences, maintenance ranges, active-only delivery, or digest-only posture must stay explicit and weaker than watched truth
- glance derivations over exact saved views or review tickets when tiny freshness-honest summary helps without replacing the stronger source lane
- freshness windows over saved views, glances, briefs, and handoff objects when exact freshness/decay posture should stay visible across Browser and Recall surfaces
- change cursors over mutable saved views, linked views, or watched sources when Browser should show changed-since / resume-from honesty without pretending watchpoint or current-live truth
- condition strips over exact saved views, watchpoints, imported surfaces, and reveal cards when Browser should show restricted / progressing / degraded / stale / muted posture without one vague badge
- observed-basis chips near strips, watchpoints, glances, and previews when Browser is showing status as-of one exact mutable basis rather than current-live truth
- freshness-horizon chips near watchpoints, glances, and current-live headers when Browser should say last-confirmed plus horizon rather than bluff currentness
- temporary quiesce rails and drain witnesses when Browser or Recall needs to freeze live-derived wriggle, stop admitting new arrivals, or explain that a calm-looking surface is only last-confirmed rather than currently quiescent
- grace-budget chips and cut-through receipts when graceful stop needs remaining-time honesty, visible expiry action, or historical truth about whether the ending stayed cooperative
- intent sparks and direct-gesture gates when Ops should explain that a stronger action is blocked not by policy but because fresh intent expired or a direct host-owned gesture is required
- bounded derivative view decks, linked views, activity front doors, evidence briefs, response kits, and timeline markers when they improve orientation without hiding stronger truth
- query views and saved smart views
- attached activity-spine front doors and spine-local view clusters where that strengthens work orientation without hiding the underlying objects
- bulk operations, preview, and exact reveal/select
- exact reopen/reentry to supported shell-owned objects
- continuity postcards that can say current-live, exact saved front door, historical only, repaired return, or adoption needed
- preview-adjacent bounded actions
- imported-surface trust posture for shared or rebound shell objects that have not yet earned ordinary local truth
- borrowed linked views that preserve source and basis posture rather than copying hidden local state
- landing rehearsal and arrival-overlay paths for imported/shared shell structures before adoption
- compact preview rails that keep inspect and stronger action adjacent but distinct
- metadata/source posture near previews rather than hidden in separate folklore panels
- claim envelopes when previews or summaries mix observed state, sourced detail, inference, remembered guidance, and proposed next moves
- reveal windows when a previewed surface is already visible somewhere else so Browser can show who can currently see which shape without flattening historical and live reveal posture
- cohort windows when preview or strong action is only about one selected slice and should not quietly widen to the whole view family
- reach previews when preview should show exact-or-counted expected touched set rather than one vague “multiple items” badge
- action warrants when preview graduates into exact reviewable change rather than ordinary inspect-only posture
- clear distinction between saved view object, emitted review ticket, evidence brief, and current live result set when one family supports all four

### Ban early in v0
- path-only product identity
- fuzzy “best effort” reveal
- treating search/query as a later accessory
- silently degrading exact reveal into nearby browse

## Operations Center

### Must exist in v0
- windows, jobs, background presence, automation sessions, and transfer sessions
- publication / promotion / sync activity for derivative surfaces such as views, linked views, front-door handles, front doors, and shared starters
- generation-promotion / rollback rows for materially changing saved shell objects when compare and restore posture matters
- attenuated-link expiry / revoke / historical rows when one-resource sharing is active or recently active
- recipe materialization / repair rows when portable starters are imported or resumed
- current reveal-window rows for visible named / org / guarded-link / public surfaces when audience truth materially matters
- current cohort-window rows when selected-slice truth, broadened-once posture, or failed-subset repair posture materially matters
- grants / leases / special authority visibility
- explicit observe / attach / control / debug / sideband / exposure lane separation for live and background work
- explicit exposure rows that keep local-only, private cohort, org/tailnet, guarded-link, and public states visibly different
- helper-lane rows that show mode, file/object bounds, network bounds, allow/ask/deny posture, and last boundary hit
- protection-gate rows that show reviewer, delay, policy, custom-check, or freshness gates separately from proposal and execution rows
- decay rails on long-running or live-looking rows when Ops should revalidate, downgrade to last-confirmed, or hold stronger action instead of preserving flattering green state
- receipts, denials, failures, resource use, and continuity posture
- clear separation between request, admission, launch, live result, and historical receipt
- host-owned progress/hold/status rows plus anchored context for long-running work
- visible state for view subscriptions, watchpoints, attention windows, snoozes, mutes, last-fired receipts, bounded digest deliveries, evidence-brief generation jobs, response-kit execution/output jobs, timeline-marker import/suggestion lanes, and external route deliveries when those subscriptions exist
- evaluation health / drift / flapping posture for watchpoints when Overview or ops cards lean on durable watch state
- freshness/expiry posture for glance derivations when Overview, Recall, or ops cards lean on derived summary rather than exact live source
- visible revalidation reasons and rails when ops cards show stale-but-usable or expired shell summaries
- visible duplicate-suppressed / same-act retry rows when stronger acts are retried under one retry key rather than silently becoming second attempts
- trusted chrome handoff or companion rows when grant, deny, hold, publish, reveal, or adopt review must stay shell-owned rather than inline in provider content
- condition strips on long-running, gated, partial, imported, or teardown-pending rows when Ops should show progressing / waiting / restricted / degraded / suspended / stale / muted posture without log-diving first
- observed-basis chips on status-heavy rows when the operator needs to see what exact mutable basis or generation a visible status was actually observed against
- visible pending teardown / blocked cleanup / force-path rows when remove, revoke, detach, retire, or unpublish has been requested but not finished
- visible pending / drifted / held / applied strong-act rows when warrants or drift gates exist so proposal truth, gated truth, and aftermath stay distinct
- visible shadow work lanes and adoption-harbor items when delegated/background/repair work exists so candidate work, adoption-ready work, and authoritative live state do not collapse into one row
- one obvious path from applied rows into effect receipts and slot verdict ledgers when the operator needs durable aftermath truth rather than generic success theater
- one obvious path from regretted or partial rows into reversal warrants and repair ladders when the next move is recovery rather than new forward action
- authority windows, lease windows, and revoke handles when the operator needs to inspect current grants, historical-only grant evidence, expiry posture, or narrow/revoke without leaving shell truth
- budget-versus-borrowed-now posture when the operator needs to see what a front door, helper, or recipe may ask for versus what is actually live right now
- hot-now posture when the operator needs to see whether a currently borrowed capability is actively consuming / exposing something right now rather than merely being available
- explicit no-new-work / draining / quiescent / resumed / cut-through posture when maintenance or graceful stop is in play so “paused” never has to carry the whole story
- visible grace budget / extension / expiry-action posture when humane shutdown or maintenance should stay bounded instead of turning into infinite limbo

### Ban early in v0
- shallow process-list theater
- hiding background presence, automation, or transfer state outside the main ops surface
- making the tool “for emergencies only” instead of daily honesty
- collapsing launch-requested into success

## Desktop Flow

### Must exist in v0
- hotkeys and visible entrypoints over shell objects and routes
- structural graph control over shell-owned actions
- debug/event surfaces and graph secondary views
- reusable inspectable fragments with typed inputs/outputs and visible status
- anchored context strips for long-lived results or downstream panes
- action-warrant handoff for stronger mutable effects so flow can propose exact shell change without flattening everything into fire-and-forget scripts
- saved-plan → inspect → apply posture for materially stronger flow effects
- shadow work lanes or adoption-harbor handoff when helper-generated or repair-generated candidate work should stay powerful without directly mutating the authoritative live lane
- capability budgets when a fragment or helper should declare the strongest families it may later ask for without pre-granting them
- grant-rung ladders when helper or tool power should be allowed once, this ask, this activity, isolated-lane only, or persistent scope without provider-dialog folklore
- renewal rails when a fragment is reacquiring old power and widening should require a fresh stronger turn
- retry keys when provider-backed or helper-backed stronger acts may need transport-safe same-act retries without duplicate side effects

### Ban early in v0
- “pretty canvas now, tooling later”
- opaque prefab black boxes
- raw script boxes as the main flow model
- invisible raw automation hidden inside reusable fragments

## Recall

### Must exist in v0
- one obvious current-live reentry cue
- front doors, exact front-door handles, and saved entry objects kept visibly weaker than current-live beacons
- one compact current-live beacon family that can stay stronger than recents, saved starters, checkpoints, grouped resource sets, watchpoints, or glance derivations
- exact reopen/reveal where supported
- visible distinction between live, restored, historical, exact-handle-backed, repaired, and unknown
- recent exact objects, timeline markers, evidence briefs, response kits, reviewed actions, route receipts, holds, denials, or last-fired view-subscription receipts with source labels
- activity-spine reentry cues that stay visibly weaker than current-live return unless the shell really has a live hook
- source-labeled activity memory seeds near reentry when remembered warnings, instructions, or preferred-view hints materially shape the return path
- scope witnesses near stronger same-activity claims when profile/account/provider/session/workspace axes matter
- honest launch ladders that keep fresh, attach, reuse, repaired, historical, and hold posture distinct
- checkpoint and view previews that can promote into stronger acts without flattening the posture change
- one obvious current-live reentry cue that stays stronger than generic recent/opened history
- explicit compare/rehearse steps before restore, branch, or adopt when imported or historical structure still needs fit
- basis stamps or equivalent exact-basis witness near stronger restored/reopened/reviewed claims when mutable basis still matters
- change cursors when Recall should be able to say changed-since-last-open, caught-up-through, or cursor-expired without bluffing live continuity
- condition strips when Recall needs to show historical success, stale readiness, restricted reopen, or muted watch posture without impersonating current-live truth
- observed-basis chips when a reopened surface is saying “this was observed on basis X” rather than “this is true right now”
- freshness-horizon chips and decay rails when a reopened surface should degrade from live-looking to remembered without one flattering silent drift
- authority-window honesty so a past grant can help explanation without impersonating current-live authority
- reveal-window honesty so a past share or publish event can help explanation without impersonating current-live audience truth
- typed review tickets for longer checkpoint/history comparisons where exact basis and freshness posture matter
- claim envelopes for historical/compare outputs so observed current state, sourced history, remembered guidance, and inferred guidance stay visibly distinct
- drift gates near restored or reopened strong actions when old review may no longer bind the current mutable target
- effect receipts when historical strong acts are reopened from Recall so the operator can see what actually happened then before comparing against now
- reversal warrants and repair ladders when Recall is reopening a regretted, partial, or drifted historical effect and recovery options must stay exact
- typed facet pivots when recency families like live/restored/historical/receipts/holds would otherwise flatten into one list

### Ban early in v0
- recent-files-only thinking
- shell-history-only thinking
- vague task nostalgia without exactness or source posture
- pretending imported or delegated history is ordinary operator-lived continuity
- letting handler-side launch history or provider recents silently become Recall's authority plane

## Exchange

### Must exist in v0
- typed ingress and selection packets
- attenuated reveal links and capability recipes as typed exchange subjects when narrow sharing or portable setup honesty improves
- imported capability budgets without imported live leases so traveled starters can stay helpful without laundering remote or historical authority into current local truth
- exact front-door handles and linked views as typed exchange subjects when route/share/import honesty improves
- saved views, decks, front doors, watchpoints, glance derivations, timeline markers, evidence briefs, and response kits as typed exchange subjects when route/share/import honesty improves
- explicit current-subthing versus all-members export/share choices for grouped activity objects when that improves honesty
- inspect-before-import/share/attach preview surfaces
- restricted-first arrival posture plus receiver-fit/adoption-harbor surfaces before stronger local adoption
- requested-target pickers and remembered-handle repair flows when a route/import/share step is probably about one exact prior subject
- explicit audience/exposure ladders so local, private, org/tailnet, guarded-link, and public remain visibly different
- handoff packets when saved or derived shell luxuries need to travel across tiers
- receiver-fit cards that name matched local facts, omitted local-only facts, and unresolved landing choices before stronger receiver-local adoption
- basis stamps when travel, compare, publish, or stronger acts depend on one exact carried or reviewed basis
- landing rehearsal and arrival-overlay surfaces before stronger receiver-local adoption
- visible route/provider/handler witnesses
- attach/share/forward/import ladders with receipts
- trusted chrome handoff when publish / guarded-link / public reveal or stronger import adoption should not finish inside ordinary content previews
- open/send/share/import/attach routes kept visibly different rather than blurred into generic open-with folklore
- typed facet pivots for transfers, clipboard-like material, route options, and receipts when that improves honesty
- exact subject and route posture where supported
- claim envelopes and reliance ladders when a transfer, attach, import, or route recommendation mixes packet facts, sourced route evidence, helper analysis, and unapplied proposals
- reach previews and affected-set witnesses when a transfer/import/attach/publish step should say what exact targets would currently be included before the stronger act lands
- action warrants and drift gates when a transfer/import/attach/publish step becomes one exact reviewable change rather than generic open/send folklore and when carried reviewed basis may have drifted before execution
- effect receipts and slot verdict ledgers when import/adopt/publish aftermath is selective or receiver-local instead of globally whole-surface
- receiver-local authority posture plus nearby revoke/narrow paths when travel, import, or share would otherwise flatter a portable arrival into local live power
- reveal-window and audience-ladder posture when share/publish/import would otherwise flatten named, guarded-link, org-only, and public visibility into one generic shared result
- reversal warrants and repair ladders when undoing or compensating a shared/public exchange effect should stay distinct from rewriting authored packets or local live state

### Ban early in v0
- clipboard folklore as the whole product
- silent helper magic
- untyped “share/send/open” ambiguity
- route success badges without route identity

## Terminal/Capshell (native front-end family)

### Must exist in v0
- explicit shell-facing entry over shared shell truth
- command-boundary witnesses and receipt-bearing actions
- source-labeled recent-command or recent-action recall
- title/source/exposure witness chips so chrome can admit shell, restored, imported, override, local-open, private, org/tailnet, or public posture
- local luxury that can accelerate without becoming shared authority by default
- clear source or mode separation when command and delegated/conversation lanes coexist
- visible helper permission mode and sandbox-bound chips when delegated or assistant-style command lanes exist
- trusted chrome lane for approval / denial / protected follow-up surfaces that PTY or app content must not impersonate
- host-effect witnesses for title, clipboard, link-open, reveal, or stronger-review requests originating from weaker terminal or app surfaces
- remembered-handle posture for reopened files, folders, sockets, or routes when terminal comfort would otherwise rely on stale cwd/path folklore

### Ban early in v0
- ambient cwd/env/session mythology as the master ontology
- hidden quick fixes that bypass review or receipt paths
- terminal-local history pretending to be the whole desktop's truth
- treating terminal/capshell as an eighth pillar without a separate truth domain
