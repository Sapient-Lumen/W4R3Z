# Derivation strip candidate contract v0

Purpose: define one compact shell-owned witness strip/header for derived surfaces so Helm can make lenses,
decks,
recipes,
beacons,
and preview-adjacent cards feel fast **without** letting them impersonate stronger truth.

A **derivation strip** is a tiny shell-owned strip,
chip row,
or header band attached to a derived surface.
It does not replace the stronger source.
It keeps the derived surface honest about where it came from.

## Why this move now

Helm increasingly wants compact derivative luxuries:

- live lenses,
- view decks,
- deck recipes,
- drift beacons,
- preview rails,
- sticky context strips,
- and materialization bays.

Those moves get much safer if the shell can answer a tiny question clearly:

**what is this surface derived from right now?**

## Candidate shape

A first useful derivation strip would likely include:

1. **Exact source / subject witness**
   - one exact subject family,
   - object id,
   - query basis,
   - activity relation,
   - receipt basis,
   - or comparable shell-owned reference

2. **Basis or recipe witness when relevant**
   - reviewed basis id
   - remembered basis id
   - recipe id
   - materialized-from id
   - imported-from id
   - or last-compared basis

3. **Locality tier badge**
   - local
   - activity-local
   - portable
   - shared
   - or another explicit admitted tier

4. **Posture badge when relevant**
   - derived
   - materialized
   - compared
   - historical
   - imported
   - delegated
   - or preview-only

5. **Tiny next actions**
   - inspect source
   - inspect basis
   - compare
   - materialize
   - publish/promote
   - review again

## Rules that matter

### 1. A derivation strip is itself derivative
It is a shell-owned witness surface.
It does not become the canonical object,
canonical query,
or canonical approval state.

### 2. The strip should name the strongest nearby truth it depends on
If a lens is derived from one exact object,
show that.
If a deck came from one recipe,
show that.
If a drift beacon compares against one receipt or reviewed basis,
show that.

### 3. Recipe/materialization distinction should stay visible
A recipe id is not the same thing as the currently materialized deck.
A saved starter should not look like current live continuity proof.

### 4. Drift should not be implied by familiarity
If the shell knows that the compared basis drifted,
the strip should be able to say so.
If it does not know,
it should not fake certainty.

### 5. The strip should stay compact
The first useful strip is not a giant inspector.
One good line or chip row is enough if it can expand into stronger inspection on demand.

## Best first homes

- live lenses
- view decks
- deck recipes after materialization
- drift beacons
- preview rails for stronger preview contexts
- adoption harbor compare cards
- basis-packet-adjacent stronger actions

## What this is not

- not a universal breadcrumb replacement
- not a giant provenance panel on every surface
- not a second authority badge system
- not a free pass for vague derived surfaces
- not a hidden materialization or publish step

## A good first proof slice would show

- one lens with an exact source witness,
- one deck materialized from a recipe,
- one drift cue on that same strip family,
- and one jump into stronger inspect/compare/materialize surfaces.

## Why this seems worth keeping warm

Derivation strips now look like one of the cheapest ways Helm can become more truthful and more magical at the same time.
They would let small shell luxuries stay small,
while making provenance,
basis,
and tier story much harder to lose.