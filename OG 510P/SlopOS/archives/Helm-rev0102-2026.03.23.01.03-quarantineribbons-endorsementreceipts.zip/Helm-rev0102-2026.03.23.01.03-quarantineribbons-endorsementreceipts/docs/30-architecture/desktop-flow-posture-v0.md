# D-FLOW Desktop Flow posture v0 (visible programmable desktop control)

Purpose: make programmable desktop control a first-class Helm surface.

## Posture (v0)

1. **Desktop Flow is base product**
   - hotkeys, rules, timers, snippets, object actions, layout policies, recall jumps, and exchange routes are all candidates for graph entrypoints

2. **The primary target is the shell graph**
   - windows
   - workspaces
   - selections
   - object references
   - query views
   - notifications
   - jobs
   - recall targets
   - exchange packets/routes
   - shell actions

3. **Typed nodes and edges**
   - Desktop Flow is not just “run arbitrary script”
   - nodes operate on typed desktop objects and actions

4. **Live inspectability**
   - active flows, last-triggered entrypoints, failures, suspension/disablement state, and authority tier crossings should be inspectable

5. **Flow support machinery is required**
   - debug/event lanes, graph outline/search, node status, and reusable inspectable fragments are not optional garnish

6. **Deterministic scheduling where possible**
   - the graph should avoid “sleep and pray” as baseline structure

7. **Scratchpad speed matters**
   - quick local flows must be easy enough to preserve one-minute-hack energy

8. **Shell-facing flow actions should be reviewable where side effects matter**
   - flow should be able to hand off to reviewed shell actions rather than flattening everything into fire-and-forget scripts
   - when mutable basis matters, flow should prefer action warrants plus adjacent drift gates over ambient “just run it again” folklore
   - when delegated or repair-generated candidate work should stay powerful but non-authoritative, flow should be able to emit shadow work lanes and hand off into adoption harbors

## v0 must exist

- hotkeys, rules, timers, recall jumps, exchange routes, and object actions as first-class entrypoints
- typed shell-graph nodes with low-latency execution
- visible failure, disablement, last-trigger inspection, any shadow-lane/adoption-harbor handoff the flow emitted, any landing-train / guarded-promotion posture the flow created, and any reversal-warrant / repair-ladder posture the flow later emits
- debug/event lane, graph outline/search, and reusable inspectable fragments

## Temptations to ban early

- treating “arbitrary script box” as the whole product
- making safe local flows so ceremonial that one-minute hacks die
- letting raw UI injection become the default target even for shell-owned tasks
- shipping only a canvas and deferring observability/reuse indefinitely

## Phase 1 non-goals

- replacing all text scripting
- requiring ceremony so heavy that local power-user tweaks become painful

## Wiring

- decision surface: `decision-map.md` (D-FLOW)
- related docs: `flow-observability-posture-v0.md`, `shell-graph-posture-v0.md`, `flow-entrypoint-posture-v0.md`, `flow-failure-inspection-posture-v0.md`, `control-tier-boundary-v0.md`, `reviewed-action-receipt-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0003, I-HELM-0005

9. **Flow aftermath should not evaporate**
   - node/run completion should be able to yield effect receipts when a stronger graph act actually lands
   - when only part of a run landed or later repair should target a failed subset, Desktop Flow should expose slot verdict ledgers or another bounded per-step sibling instead of pretending the whole run had one simple fate

10. **Flow recovery should not evaporate into rerun folklore**
   - when a flow-created strong act later needs recovery, Desktop Flow should be able to emit a reversal warrant or repair ladder so redo, rerun-failed-subset, reverse-all, replay-on-fresh-basis, and hold stay visibly different
