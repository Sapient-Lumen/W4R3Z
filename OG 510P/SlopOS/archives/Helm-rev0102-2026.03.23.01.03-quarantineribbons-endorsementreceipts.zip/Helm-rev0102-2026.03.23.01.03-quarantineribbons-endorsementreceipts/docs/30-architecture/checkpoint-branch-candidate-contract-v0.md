# Checkpoint branch candidate contract v0

Purpose: give Helm one shell-owned checkpoint move that can later support restore,
compare,
and branching **without** pretending a checkpoint is current live truth or that every restore means total resurrection.

A **checkpoint branch** begins from one exact checkpoint: a compact shell-owned capture of a basis-bearing state,
structure,
or relation at a particular moment.
From that checkpoint the shell may later:

- inspect
- compare
- restore toward it
- or fork a new branch from it

The crucial law is that these are **different moves**.

## Why this move now

Helm increasingly wants a better story for:

- exact return versus repaired return
- saved launch/layout structure versus current live cluster
- Desktop Flow experimentation without losing the earlier path
- Recall that is stronger than recent-items folklore
- compare surfaces that can explain later divergence

A checkpoint branch gives Helm one narrow way to do that honestly.

## Candidate posture

### 1. A checkpoint is an exact basis-bearing witness

A checkpoint should name what exactly it captures:

- object/view/deck/flow/layout family
- exact ids or admitted carried structure
- relevant basis / revision witness when available
- source locality tier
- trust posture where relevant

### 2. A checkpoint is not current live truth

The checkpoint says “this is what this family looked like then.”
It does **not** say:

- this is still live now
- every dependency still exists
- receiver/local bindings still hold
- or a later restore will be exact and total

### 3. Restore and fork are separate acts

A restore attempts to make the current shell resemble the checkpoint again.
A fork creates a new continuity path that begins from that checkpoint.

Helm should not flatten those into one flattering “go back” move.

### 4. Later comparison should explain divergence compactly

A useful v0 compare should be able to say at least:

- carried as-is
- reset / re-created
- rebound locally
- omitted
- unavailable
- drifted since checkpoint

It does not need a giant universal diff system on day one.

### 5. Branches should keep ancestry without impersonating sameness

A new branch may carry ancestry from the checkpoint,
but it should remain visibly different from the original live lane.
This is especially important when:

- layouts were re-materialized
- imported/shared items rebound locally
- one view or dock pin changed scope
- or one flow fragment was swapped / repaired

### 6. Checkpoints should compose with existing Helm law

A checkpoint branch should work with:

- basis stamps
- residue ledgers
- exact trails
- view decks
- launch ladders
- publication ladders
- lineage modes
- fork receipts
- Recall launch/return posture

## Candidate minimal shape

A useful v0 checkpoint likely needs:

- exact checkpoint id
- owner family
- captured basis witness
- capture timestamp
- locality / trust posture
- admitted carried classes
- optional divergence note when later compared or restored
- explicit restore / fork / inspect entrypoints

## Best first homes

- one Recall specimen for exact return and branch-from-here
- one Desktop Flow specimen for experiment-from-checkpoint
- one layout / launch specimen where restore is weaker than full same-state claims

## Guardrails

- do not promise full environment resurrection before one family proves it
- do not collapse restore,
  inspect,
  and fork into one button
- do not treat checkpoint presence as proof of current liveness
- do not build universal version control for every shell surface
- do not hide local rebinding,
  repair,
  or omission after restore

## First specimen worth proving

One good first specimen would be:

- one saved view or layout-backed activity with a checkpoint,
- one later compare against current state,
- one restore attempt that shows carried / reset / unavailable outcomes,
- and one explicit branch-from-checkpoint path that preserves ancestry without pretending same live continuity.

## Working stance

Checkpoint branches now look mature enough to prove soon.
If Helm keeps the basis law strict,
this move can make Recall,
Desktop Flow,
and Operations Center substantially better without dragging the product into giant timeline theater.
