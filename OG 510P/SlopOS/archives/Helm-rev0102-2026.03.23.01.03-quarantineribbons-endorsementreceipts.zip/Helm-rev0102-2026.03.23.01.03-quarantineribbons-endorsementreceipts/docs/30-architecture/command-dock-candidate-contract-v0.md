# Command dock candidate contract v0

Purpose: give Helm one **tiny persistent shell-owned command edge** for exact pinned jumps, launch objects, and status cues without turning the dock into a hidden second shell constitution.

This move exists because current tools keep converging on the same humane pattern:
users often want one or two things **always nearby**.
But the shell should not pay for that convenience by letting a dock outrun review, receipts, or typed truth.

## What a command dock is

A command dock is a **small persistent band** owned by the shell.
It may live on an edge, rail, strip, or compact shelf.

A useful v0 dock could hold a few exact slots such as:

- return to current live focus / activity
- jump to one exact object or view
- launch one entry kit or launch object
- open one review/apply harbor item
- show one host-owned status or hold cue
- summon Omnibox on a typed scope

The dock is not a second launcher.
The dock is a **persistent projection over already-legible shell truth**.

## Where it can appear

Command docks are most promising across:

- **Omnibox** as a compact persistent companion for a few exact launches or scopes
- **Operations Center** as a place for host-owned status / hold / apply cues
- **Recall** as a place for one or two high-value exact return slots
- **Desktop Flow** as a quick path into one exact fragment, result, or harbor item
- and later perhaps **Tiling Shell** as a shell-owned edge surface rather than app chrome

## Minimum visible facts

A useful v0 dock should keep a few facts obvious:

- exact subject or slot identity
- slot kind: jump / launch / harbor / status / hold / summon
- source grade when the slot is delegated, historical, or imported
- whether selection is observational, ordinary, review-first, or blocked
- whether the slot is pointing at live truth, saved entry, or historical material

## Guardrails

### 1. The dock is projection, not new law
A command dock should expose already-earned shell powers.
It should not invent a second hidden control plane with weaker review or receipt law.

### 2. Pins should be exact and typed
Pinned items should be exact shell-owned objects, routes, entry artifacts, or actions where possible.
The dock should not regress into ambient macro strings or fuzzy helper folklore.

### 3. Status is not approval
A badge, glow, or counter in the dock should not count as action success, adopted mutation, or current live continuity proof.
It is merely a compact signal.

### 4. Keep it tiny
The first cut should be narrow.
A dock that tries to hold everything becomes a second desktop mode instead of a humane persistent edge.

### 5. Do not let provider sprawl eat it
The dock should not become a provider-bucket bazaar.
The shell must keep the visible law.

## First specimen worth proving

One good first specimen would be:

- one exact live-return slot,
- one exact object jump,
- one entry artifact / launch object slot,
- one adoption-harbor or hold indicator,
- and one typed Omnibox summon slot.

That is enough to learn whether persistence improves speed without corrupting shell truth.
