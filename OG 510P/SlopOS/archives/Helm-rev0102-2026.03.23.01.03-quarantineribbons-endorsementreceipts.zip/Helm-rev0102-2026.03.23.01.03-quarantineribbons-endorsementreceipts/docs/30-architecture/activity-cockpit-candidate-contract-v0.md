# Activity cockpit candidate contract v0

Purpose: explore one shell-owned front door for a named activity without creating a new pillar or helper-suite dashboard culture.

An **activity cockpit** is a compact shell-owned card or surface that pulls together the truth a user actually wants when returning to a task:
- what is live now,
- what capsule / layout / routes are nearby,
- what is still launching or broken,
- what changed recently,
- and what the next obvious actions are.

This is a candidate move, not a freeze.

## Candidate shape

A first useful cockpit should likely include:

1. **Activity identity**
   - name
   - icon / color / compact summary
   - one exact activity handle in the shell graph

2. **Current live state block**
   - live windows / surfaces
   - live jobs / flows / transfers
   - live grants or unusual authority posture
   - obvious stale / missing / unavailable signals
   - compact scope witness or scope-state cue when same-activity continuity depends on specific axes

3. **Continuity block**
   - related capsule
   - compact capsule diff summary
   - last restore receipt or denial, if relevant

4. **Spatial block**
   - current layout or template relation
   - rebinding proposals if the expected arrangement is not currently satisfied

5. **Recent change / receipt block**
   - recent actions that mattered
   - recent failures, denials, or repairs
   - compact “what changed” summary rather than giant log theater

6. **Next action block**
   - route cards
   - rehearse / restore / reveal / attach / send / continue actions
   - typed seeds or quick actions where they remain shell-owned and inspectable

## Guardrails

1. **Not a new pillar**
   - a cockpit is a cross-cutting shell luxury built from existing pillars, not a ninth pillar.

2. **Not an app dashboard host**
   - it should summarize shell truth, not embed arbitrary app dashboards as the product core.

3. **Request-vs-live truth stays visible**
   - a cockpit must not blur selected capsule, requested restore, launching state, and current live state into one success-shaped blob.

4. **No second parallel desktop model**
   - the cockpit should be derived from the same shell graph, Recall, Exchange, Tiling Shell, and Operations Center truths Helm already owns.

5. **No giant project-management ontology**
   - an activity is a shell object with nearby shell truth, not an attempt to become a universal semantic project tracker.

## Why this looks promising

This move combines several already-attractive strands:
- workspace/activity capsules,
- layout templates,
- route cards,
- receipt visibility,
- and operations truth.

Current tools keep showing that users want:
- fast return to a task-shaped setup,
- confidence about what resumed and what did not,
- and one obvious place to continue.

A cockpit could give Helm that feeling while still staying honest.

## First proof-bearing specimen

A narrow specimen would be enough:
- one named activity,
- one cockpit card,
- one linked capsule,
- one linked layout template,
- one outstanding launch / transfer / flow item,
- one compact diff summary,
- and one route card for the next obvious action.

## Failure modes to avoid

- a dead bookmark page with no live status
- a mini-dashboard that duplicates Operations Center tables without adding orientation
- a restore launcher that pretends launch requests are current truth
- an embedded-app scrapbook that weakens shell ownership
- a giant semantic workspace system before one shell-shaped specimen exists
