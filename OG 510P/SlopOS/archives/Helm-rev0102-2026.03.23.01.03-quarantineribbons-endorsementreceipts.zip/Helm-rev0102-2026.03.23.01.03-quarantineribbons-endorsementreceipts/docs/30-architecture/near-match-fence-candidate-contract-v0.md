# Near-match fence candidate contract v0

Purpose: define one compact shell-owned exactness guard so Helm can surface **similar local candidates** when an expected binding is missing,
without silently treating those candidates as exact success.

A **near-match fence** is the anti-laundering side of rebinding.
It should compose with:

- anchor maps
- basis stamps
- residue ledgers
- receiver fit cards
- rebind ladders
- landing rehearsals
- reviewed-basis truth
- and binding-witness posture

## Why this move now

Helm already knows that hidden reuse,
repaired joins,
and nearby substitutes should not silently count as exact return.
But travel and landing now need a sharper version of that lesson.

Current teachers keep rewarding exactness honesty:

- SlopOS show-item exactness fails closed instead of degrading to opening the parent directory
- SlopOS approval-basis posture refuses sticky approval across mutable-basis drift
- VS Code worktree isolation keeps isolated changes separate until explicit apply
- Figma branch review keeps branches reviewable as distinct candidates until explicit merge

That combination strongly suggests one narrower shell law:

**similarity may be inspectable,
but it must not silently wear the badge of exactness.**

## Candidate shape

A first useful near-match fence would likely include:

1. **Expected binding witness**
   - slot id from an anchor map
   - expected handle class
   - expected exact id or digest
   - expected basis or version witness if relevant

2. **Candidate list**
   - exact match if found
   - near matches with visible similarity reason
   - incompatible candidates
   - intentionally omitted class
   - no-match result

3. **Visible difference summary**
   - same name,
     different root
   - same project,
     different profile
   - same provider family,
     different account/session
   - same route label,
     different basis
   - or another admitted explicit mismatch reason

4. **Fence posture**
   - exact bind allowed
   - inspect only
   - rehearse candidate locally
   - explicit choose-and-rebind required
   - refused

5. **Tiny next actions**
   - inspect candidate
   - compare to expected basis
   - rehearse candidate
   - choose candidate and record rebinding authorship
   - hold or reject landing

## Rules that matter

### 1. Similarity is not exactness
A near match may be useful.
It is still not the same as the expected target.
The UI and receipts should keep that distinction obvious.

### 2. Helm may help,
but not auto-launder
Helm may rank candidates,
show why they are similar,
and offer a faster rebind path.
It should not silently pick one and report ordinary success.

### 3. Difference reasons should stay typed
“close enough” is not a useful witness.
Mismatch classes should stay inspectable:
root,
profile,
provider,
session,
version,
basis,
activity,
or another admitted slot class.

### 4. Near-match fences should compose with rehearsals
A candidate may be worth seeing in context before rebinding.
That makes landing rehearsal a natural partner surface.

### 5. The first version should stay small
One or two mismatch families are enough for a first proof slice.
This should not become a giant universal diff engine.

## Best first homes

- exact action keys whose target root or profile is missing on the receiver
- deck recipes whose subject root exists only approximately
- dock items whose pinned command target has a renamed or moved local home
- entry kits that expect one provider/profile/session and find several similar local candidates instead

## What this is not

- not fuzzy search with a fancier badge
- not hidden self-healing import
- not a substitute for rebind ladders
- not permission to auto-select the top-ranked candidate
- not proof that a similar candidate is safe to adopt

## A good first proof slice would show

- one missing exact target,
- two surfaced near matches with typed mismatch reasons,
- one rehearsal path for the better candidate,
- and one explicit choose-and-rebind action that records authorship instead of pretending exact continuity.

## Why this seems worth keeping warm

Near-match fences now look like the missing guardrail for Helm's truthful landing story.
They let the shell stay helpful and fast without turning helpfulness into a lie.
