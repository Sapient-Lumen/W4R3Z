# Anchor map candidate contract v0

Purpose: define one compact shell-owned carried binding structure so a portable,
derived,
or saved Helm surface can say exactly **what it expects to bind to** without relying on ambient search,
hidden fuzzy repair,
or receiver magic.

An **anchor map** is the typed slot map for a shell surface.
It should compose with:

- landing manifests
- receiver fit cards
- rebind ladders
- residue ledgers
- companion resource bundles
- exact action keys
- deck recipes
- command dock items/bands
- and activity entry kits

## Why this move now

Helm now has enough travel and derived-surface ideas that a vague “this should probably bind somewhere useful” story is no longer good enough.

Current tools keep validating explicit mapping:

- Figma Code Connect maps design components to code components and properties
- Raycast Quicklinks and placeholders make callable inputs explicit
- Warp launch configs and URIs expose launchable structure directly
- PowerToys dock items resolve by explicit command ids
- SlopOS view objects reject ambient resolution fallback

Anchor maps answer the sharper question that landing manifests and fit cards do not fully answer:

**what named slots does this surface carry,
and what handle classes are admitted for satisfying them?**

## Candidate shape

A first useful anchor map would likely include:

1. **Owner surface witness**
   - portable core id
   - packet id
   - deck recipe id
   - exact action key id
   - dock item id
   - or another admitted shell-owned owner

2. **Named slots**
   - subject root
   - object handle
   - route/provider
   - profile/session
   - workspace/activity
   - companion resource
   - argument/input slot
   - compare basis
   - or another admitted slot class

3. **Admitted handle classes per slot**
   - exact shell ref
   - path/root handle
   - provider-local id
   - typed query basis
   - receipt or reviewed-basis witness
   - companion link family
   - receiver-local rebind target class

4. **Binding posture per slot**
   - carried and exact
   - carried but receiver-must-confirm
   - receiver-must-rebind
   - receiver-may-inherit-by-mask
   - intentionally empty
   - refused / unavailable

5. **Optional parameter or placeholder rules**
   - named arguments
   - selected-text or clipboard-style inputs when admitted
   - percent-encoding / formatting constraints
   - bounded transforms
   - no hidden ambient expansion beyond the declared rules

6. **Tiny next actions**
   - inspect slot
   - compare candidate bindings
   - open rebind ladder
   - materialize local specimen
   - clear stale binding
   - reject landing

## Rules that matter

### 1. Anchor maps are explicit slot law,
not fuzzy intent
If a surface needs a repo root,
a provider,
a subject,
or a compare basis,
that dependency should be visible as a slot rather than guessed from ambient context.

### 2. Slots stay typed
A subject slot,
route slot,
companion slot,
and argument slot should not all collapse into one generic string bag.
Typing is what keeps the map inspectable.

### 3. Anchor maps must not silently widen authority
A slot map may help the receiver bind something honestly.
It must not become a hidden permission escalation,
secret-carrier,
or trust bypass.

### 4. Explicit emptiness is allowed
Some slots should remain empty until the receiver chooses.
An empty slot is often more honest than a guessed match.

### 5. Anchor maps should compose with residue ledgers and inherit masks
The map explains **what slots exist**.
The residue ledger explains **what local truth stayed behind**.
An inherit mask may explain **which bounded classes may use receiver defaults**.
Those are different jobs.

## Best first homes

- deck recipes with subject-root and compare-basis slots
- exact action keys with target and argument slots
- companion resource bundles with typed doc/code/ticket/dashboard slots
- command dock bands with explicit per-button command ids or shell refs
- entry kits that need workspace/activity/provider bindings on landing

## What this is not

- not a universal app-plugin schema
- not a giant object graph export format
- not a hidden matching engine
- not a substitute for fit,
  rebind,
  or adoption
- not permission to scrape ambient machine state until something matches

## A good first proof slice would show

- one deck recipe or exact action key carrying three typed slots,
- one slot already satisfied exactly,
- one slot requiring rebind,
- one slot left intentionally empty,
- and one fit-card / rebind-ladder path that consumes the map honestly.

## Why this seems worth keeping warm

Anchor maps now look like the missing carried binding structure in Helm's travel story.
They let the shell be fast and clever,
while keeping binding truth explicit enough that the cleverness does not become a lie.
