
# Binding witness card candidate contract v0

Purpose: explore one reusable shell-owned card for explaining how saved/planned task-entry structure joins to current live targets.

A **binding witness card** is a compact shell-owned continuity card.
It is not a giant restore dashboard and not a universal matching engine.
It is the card Helm can use when a saved/planned subject is:
- matched exactly,
- rebound with repair,
- left ambiguous,
- or found unavailable.

This is a candidate move, not a freeze.

## Candidate shape

A first useful binding witness card would likely include:

1. **Planned subject**
   - activity / capsule / template / slot / seed / route subject
   - one exact saved or planned reference
   - compact "what this card is trying to bind" summary

2. **Observed candidate**
   - current live candidate identity when found
   - live lane / workspace / provider / session relation when relevant
   - current-live / historical / missing distinction

3. **Match basis**
   - what evidence participated in the join
   - for example: exact object id, exact shell ref, recent receipt relation, slot anchor, provider witness, peer witness, explicit operator choice, or nearby scope witness

4. **Match grade**
   - exact
   - repaired
   - ambiguous
   - unavailable

5. **Allowed action ladder**
   - attach to exact live target
   - inspect repaired match
   - restore historical continuity instead
   - relaunch from entry artifact / template / seed path
   - fresh launch
   - hold / repair

6. **Repair notes**
   - compact reason for downgrade or hold
   - what was missing, widened, or operator-chosen

7. **Choice/authorship relation**
   - when the interesting truth is not only the join basis but also who proposed, chose, or executed the substitute path,
   - the card should be able to open the nearby continuity choice witness

## Guardrails

1. **Not a silent auto-rebind engine**
   - the card explains or stages the join; it should not merely disguise a hidden matching decision.

2. **Not a giant workspace bureaucracy**
   - the first version should stay small and reusable across multiple surfaces.

3. **No fake exactness**
   - repaired, ambiguous, and unavailable should stay visibly distinct from exact.

4. **No hidden strong action on display**
   - showing a witness card should not itself perform the strongest available action family.

5. **Evidence should stay revealable**
   - a compact card is fine, but it should be able to open the nearby evidence path when the operator wants detail.

## Why this looks promising

This move combines several already-strong Helm threads:
- rehearsal cards,
- capsule diffs,
- layout-template rebinding,
- activity cockpit cards,
- activity entry kits,
- and request-vs-live / entry-artifact truth.

It also creates one unusually Helm-shaped luxury:
**return-to-task magic that is more inspectable, not less inspectable, than legacy workspace tools.**

## First proof-bearing specimen

A narrow specimen would be enough:
- one binding witness for a capsule-to-live activity match,
- one binding witness for a layout-template slot repair,
- one exact case,
- one repaired case,
- one ambiguous or unavailable case,
- and one hold / inspect path rather than silent retargeting.

## Failure modes to avoid

- a tiny card that still hides the real join basis
- a giant repair wizard before one compact reusable witness exists
- title-matching folklore dressed up with better badges
- remote/profile/account retargeting that the card cannot actually explain
- witness cards that duplicate Operations Center tables without improving the continuity story
