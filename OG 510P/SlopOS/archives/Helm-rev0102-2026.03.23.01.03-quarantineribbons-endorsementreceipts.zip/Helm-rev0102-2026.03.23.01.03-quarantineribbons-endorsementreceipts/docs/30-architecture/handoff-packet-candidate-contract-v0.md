# Handoff packet candidate contract v0

Purpose: define one portable shell-owned packet for moving a derived or saved shell luxury across locality tiers so Helm can support export,
share,
import,
and cross-device/team handoff **without** pretending the receiver already has live local state.

A **handoff packet** is a compact portable packet that represents one admitted shell surface in travel form.
It should compose with derivation strips,
receiver-fit cards,
publication ladders,
materialization bays,
exact action keys,
and adoption harbors.

## Why this move now

Helm increasingly wants shell luxuries that may need to travel:

- deck recipes,
- view decks,
- exact action keys,
- command dock items,
- entry kits,
- flow fragments,
- and other saved/derived shell accelerators.

SlopOS keeps teaching that replicated summaries and portable exports should not auto-activate receiver-side local state.
Current tools keep teaching the same lesson in friendlier form:
export/import profiles,
shared quicklinks,
deeplinks,
share/sync menus,
and templates all work best when the traveling object is explicit.

## Candidate shape

A first useful handoff packet would likely include:

1. **Packet subject witness**
   - exact source surface family
   - exact subject id / recipe id / key id / deck id
   - or another admitted shell-owned handle

2. **Derivation / basis witness when relevant**
   - basis id
   - recipe id
   - compared-from id
   - materialized-from id
   - revision / epoch / digest witness

3. **Intended affordance**
   - inspect only
   - materialize locally
   - adopt into activity
   - install pin/key/dock item
   - compare against local basis
   - or another bounded next move

4. **Origin tier and portability posture**
   - local
   - activity-local
   - portable/exportable
   - shared
   - published
   - and whether receiver-side activation is allowed,
     refused,
     or requires review/trust

5. **Optional carried context when relevant**
   - time range witness
   - variable/filter witness
   - route/slot witness
   - preferred-but-not-binding profile/provider affinity
   - or another compact context witness

6. **Permission / redaction notes when relevant**
   - shared audience hint
   - redaction class
   - trust warning
   - expiry / revoke hint
   - local-only refusal reason

7. **Receiver-side next actions**
   - inspect packet
   - inspect source/basis
   - open receiver-fit card
   - materialize
   - adopt
   - import as recipe only
   - hold
   - reject

## Rules that matter

### 1. A handoff packet is not live shared state
A packet may travel.
It does not by itself prove that the receiver has current live bindings,
current grants,
or current continuity.

### 2. The packet should carry enough witness material to stay honest
A packet should not rely on vibes like:
"latest now",
"same as before",
or "probably still current".
If basis matters,
carry basis witness.
If derivation matters,
carry derivation witness.

### 3. Receiver-side activation should stay explicit
The receiver should usually inspect,
open a fit card,
materialize,
adopt,
or trust explicitly.
Travel is not activation.

### 4. Some families should refuse packetization
Examples that often should stay local-only or heavily constrained:

- clipboard history,
- trust decisions,
- credentials,
- some delegated/background candidate work,
- some raw lane or execution-local convenience state.

### 5. Packets should compose with publication ladders and promotion receipts
A publication step may produce a packet.
A promotion receipt should be able to name that packet.
The receiver should still have its own explicit next move.

## Best first homes

- deck recipes
- view deck starters
- exact action keys
- command dock items or bands
- activity entry kits
- evidence briefs
- response kits
- flow fragments that are safe to travel as recipes

## What this is not

- not a universal live-state replication format
- not a background sync constitution
- not a permission bypass
- not a hidden installation workflow
- not a promise that the receiver can run or open everything immediately

## A good first proof slice would show

- one deck recipe exported as a handoff packet,
- one exact action key packet that still requires receiver-side review/materialization,
- one refusal case for a surface that must stay local-only,
- and one inspect → materialize/adopt ladder on the receiver side.

## Why this seems worth keeping warm

Handoff packets now look like the cleanest way for Helm to support portable shell luxuries without lying about continuity,
trust,
or receiver-side activation.
