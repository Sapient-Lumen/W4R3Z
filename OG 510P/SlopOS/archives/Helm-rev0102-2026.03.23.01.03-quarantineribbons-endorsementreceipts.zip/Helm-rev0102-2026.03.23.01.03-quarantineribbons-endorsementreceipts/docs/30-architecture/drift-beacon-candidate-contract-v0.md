# Drift beacon candidate contract v0

Purpose: name one compact Helm move for **change-aware shell truth** without turning Helm into a giant timeline,
notification,
or approval-cache system.

A **drift beacon** is a shell-owned derivative card,
strip,
badge cluster,
or tiny compare cue that says what changed since one exact reviewed,
remembered,
adopted,
or entry-artifact basis.

It is not the underlying object.
It is not live authority.
It is not a general event log.

## Candidate posture

1. **A drift beacon is derivative and shell-owned**
   - it sits over one stronger shell subject plus one exact compared basis
   - it should carry clear source and basis witnesses
   - it should be visible as derivative shell truth rather than app-local folklore

2. **A beacon answers a narrow question**
   - unchanged
   - changed
   - drifted materially
   - unavailable / basis missing
   - maybe bounded class counts or field/slot families,
     not a giant diff engine first

3. **The compared basis must stay explicit**
   - reviewed action basis
   - adoption basis
   - last-seen object basis
   - entry-kit basis
   - deck member basis
   - receipt or restore basis

4. **Default actions stay inspect-first**
   - inspect change
   - inspect basis
   - compare in stronger surface
   - review again
   - reopen exact source
   - hold when stronger action would otherwise overclaim

5. **A beacon should compose with existing Helm moves**
   - basis packets
   - adoption harbors
   - live lenses
   - view decks
   - exact trails
   - Recall returns
   - activity entry kits

6. **Drift beacons may escalate into a stronger compare sibling**
   - when the cue matters for adoption, rereview, or stronger action, the next move may be a basis contrast card
   - the beacon itself should still stay smaller and weaker than that compare surface

7. **Locality should stay visible**
   - many beacons will be personal or activity-local by default
   - sharing or exporting a beacon should not make its compared basis globally authoritative

## Candidate uses

- a harbor card showing candidate work drifted from the adopted live basis
- a Recall return showing an object changed since last reviewed
- a deck member showing one view has drifted since the deck recipe last materialized
- an exact trail or dock pin showing the target changed since the last confident witness
- an entry kit showing the preferred destination or route is now materially different

## Guardrails
- do not collapse beacons and basis contrast cards into one overgrown surface

- do not turn drift beacons into a giant timeline theater product
- do not let a changed-since badge impersonate current authority
- do not auto-bless or auto-revoke stronger actions without an inspectable basis story
- do not hide the compared basis behind decorative wording
- do not require every tiny object to carry drift machinery by default

## Candidate v0 specimen

A small proof-bearing slice could be:
- one exact subject,
- one exact compared basis,
- one bounded beacon state,
- inspect / compare / review-again actions,
- and one hold path when a strong action would otherwise rely on stale basis.

## Working stance

Drift beacons now look like one of the cleanest ways Helm can become more truthful and more magical at the same time,
but they should stay a candidate contract until one compact specimen proves they improve task return,
adoption,
and reentry without turning into giant diff bureaucracy.
