# D-EXEMPLARS exemplar translations v0 (powers over clones)

Purpose: preserve the insight in the exemplar list without turning Helm into a compatibility shrine.

## i3 → deterministic tiling discipline

### Keep
- directional focus
- predictable layout transforms
- workspaces as explicit units
- keyboard-first operation

### Reject
- text-config primacy as the main product surface
- shelling out as the default integration story
- title/class regex empires as the long-term rule model

### Helm translation
- a shell-owned Tiling Shell over first-class workspaces, layouts, focus chain, and graphable rules

## AHK → programmable desktop control

### Keep
- low-latency key control
- one-minute hacks
- text snippets and transforms
- the ability to act outside a pre-approved happy path

### Reject
- invisible ambient hooks as the primary control model
- raw injection as the first resort for shell-owned tasks
- haunted startup persistence

### Helm translation
- Desktop Flow as base product, plus a real explicit raw automation lane when the model is insufficient

## Rofi → unified summon and dispatch

### Keep
- fast summon
- sparse keyboard-first UI
- switch / search / launch / act from one surface

### Reject
- app-launcher-only identity
- PATH-plus-argv as the main semantic model

### Helm translation
- Omnibox over windows, workspaces, documents, views, jobs, notifications, flows, recall objects, exchange routes, and shell actions

## Dolphin → strong object/document browsing

### Keep
- split views
- bulk operations
- previews
- preview-adjacent bounded actions
- practical keyboard competence
- serious navigation ergonomics

### Reject
- path worship as the sole object model
- fuzzy reveal semantics
- treating search as bolt-on garnish

### Helm translation
- Object Browser over object references, query views, exact reveal/select, previews, and durable references

## “God-tier task manager” → operational honesty

### Keep
- a place that tells the truth about what is running and why
- live resource visibility
- strong failure inspection
- visible status and progress that belongs to the host surface

### Reject
- process-list theater as the main model
- hiding automation, grants, and background state in side tools

### Helm translation
- Operations Center over windows, jobs, background presence, grants, receipts, denials, failures, automation sessions, transfers, and resources

## Promoted pressures from SlopOS and Schell

The exemplar list did not name two product powers loudly enough, but the archives force them into the open.

### Recall → continuity with honesty
- keep: exact reopen/reveal, durable trail, current-live reentry, restored-vs-live truth
- reject: generic recent-items folklore, fake continuity, history-only truth
- Helm translation: Recall as a first-class continuity surface over shell-owned objects, receipts, lanes, and activity

### Exchange → typed movement with exact routing
- keep: typed payload handling, import/send/attach distinctions, packet-local inspection, route witnesses
- reject: path paste as universal transfer, smart-click helper magic, silent widening from selected thing to strong action
- Helm translation: Exchange as a first-class transfer surface over ingress packets, selection packets, intent routes, and transfer receipts

## Summary rule

Helm should inherit the **powers** that made the exemplars beloved, while aggressively refusing the ambient authority folklore that made those tools necessary in older systems.

## Wiring

- decision surface: `decision-map.md` (D-EXEMPLARS)
- related docs: `base-product-surface-v0.md`, `pillar-contracts-v0.md`, `desktop-flow-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`
- assurance anchors: CH-HELM-0011, CH-HELM-0012
