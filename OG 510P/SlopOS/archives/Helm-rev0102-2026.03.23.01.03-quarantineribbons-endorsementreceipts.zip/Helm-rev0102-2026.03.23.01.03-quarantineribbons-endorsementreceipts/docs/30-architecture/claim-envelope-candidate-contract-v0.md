# Claim envelope candidate contract v0

Purpose: give Helm one shell-owned explicit output object for a bounded ask,
compare,
proposal,
summary,
route recommendation,
diagnosis,
or plan.

A **claim envelope** is not a giant provenance graph.
It is not a receipt.
It is not a correctness proof.
It is the shell-owned answer to:

**what exactly is this output claiming,
what grounded it,
and what kind of claim is each part?**

## Candidate posture

### 1. Claim class is explicit
A first useful envelope should let the shell distinguish between at least:
- observed
- sourced
- derived
- remembered
- proposed
- unresolved / hold

### 2. One envelope belongs to one bounded act
Good owners include:
- one ask
- one compare
- one route proposal
- one generated summary
- one pre-apply action card
- one plan or recommendation set
- one watch explanation or recovery explanation

### 3. Grounding witness stays revealable
A stronger envelope should be able to reveal,
when relevant:
- source refs / citations
- exact current-live basis
- exact saved-view / review-ticket / receipt basis
- freshness or expiry hint, ideally through one nearby freshness window when the envelope is saved or revisited
- whether the claim came from selected context,
  remembered guidance,
  helper-session work,
  or derived synthesis
- redacted-support posture when some values are intentionally withheld

### 4. Proposed actions stay visibly different from factual claims
If a result includes:
- a suggested edit,
- a route choice,
- a launch plan,
- a repair proposal,
- or a shell mutation,
that part of the envelope should stay in **proposal** posture until preview / apply / adopt and receipt happen.

### 5. Envelope truth is different from influence truth
A claim envelope explains what the output is saying.
It does not replace:
- context loadouts,
- contribution witnesses,
- receipts,
- route witnesses,
- helper-session logs,
- or current-live beacons.

### 6. Weak summaries may stay weak and even ephemeral
Not every generated summary deserves durable team truth.
A useful first envelope may be:
- private,
- ephemeral,
- or saveable only by deliberate promotion.
Saving should preserve weakness rather than laundering it.

### 7. Saveability does not erase freshness or locality
An envelope may be saved,
shared,
or attached to an activity,
but saveability must not strip away freshness,
expiry,
locality,
or weaker claim posture.

## Candidate minimal shape

A first useful claim envelope likely needs:
- exact id
- owner act id
- claim items or claim groups
- claim class per item/group
- grounding / source / basis refs
- freshness / expiry / redaction posture
- reveal-shape posture when the current audience only gets summary, preview, or redacted form
- optional helper-session witness pointer
- next-step affordances
- saved / shared posture when relevant
- created_at

## Best first homes

- one Omnibox ask over a selected context loadout
- one Recall compare or historical summary
- one Exchange proposal that mixes facts and a recommended route
- one watch / repair explanation that separates observation,
  interpretation,
  and proposed next move
- one spreadsheet-like action preview where analysis and proposed mutation live together without flattening

## Guardrails

1. **No giant provenance graph by default**
2. **No one-number confidence theater**
3. **No flattening sourced,
   derived,
   remembered,
   and proposed claims into one posture**
4. **No treating citation chips as correctness proof**
5. **No treating a saved envelope as timeless truth or hiding stale fallback posture behind smoother wording**
6. **No replacing receipts for stronger completed actions**
7. **No forcing full-session disclosure when a bounded redacted explanation is enough**

## Working stance

Claim envelopes now look less like a nice-to-have and more like the right shell-wide legibility surface for Helm.
They let the shell say something unusually valuable:

**this is what the output claims,
this is what grounded it,
and this is still weaker than authority.**
