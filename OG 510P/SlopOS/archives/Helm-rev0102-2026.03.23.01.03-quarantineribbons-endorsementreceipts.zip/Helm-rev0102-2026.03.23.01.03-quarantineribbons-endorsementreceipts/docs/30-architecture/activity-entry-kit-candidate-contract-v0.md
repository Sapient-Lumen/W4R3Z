# Activity entry kit candidate contract v0

Purpose: explore one shell-owned saved **front-door starter** for a named activity so users can get back to meaningful work quickly without pretending a saved setup is already live truth.

An **activity entry kit** is a compact shell-owned saved starter for entering one scoped piece of work.
It is not the live activity.
It is not the activity spine.
It is not the resource shelf.
It is not the current-live beacon.

It is the object Helm can use to:
- point toward one preferred front door,
- link the nearby scoped work frame,
- carry a few attached views/resources/starters,
- and make the honest next-entry ladder visible.

This is a candidate move, not a freeze.

## Candidate shape

A first useful entry kit would likely include:

1. **Activity identity and scope relation**
   - title
   - icon / color / summary
   - one exact activity handle or one exact linked activity spine
   - visible scope/trust posture where relevant

2. **Preferred front door**
   - one nominated exact entry surface such as:
     - saved view object
     - exact front-door handle
     - cockpit/front card
     - resource shelf
     - current-live beacon relation
     - or another reviewed exact surface
   - importantly: a preferred door,
     not proof the door is live now

3. **Nearby attached surfaces**
   - optional attached saved views
   - optional attached derivative view deck or one named triage lane within it
   - optional attached resource shelf
   - optional attached checkpoint branch relation
   - optional attached review ticket or compare surface
   - optional attached command band/dock relation

4. **Starter relations**
   - optional linked launch/layout starter
   - optional typed seeds
   - optional route or provider hints where already exact and useful
   - optional preferred profile/account/provider/space affinity hints that stay visible and weaker than live proof

5. **Continuity hints**
   - optional current-live beacon relation
   - optional last-good restore receipt or checkpoint relation
   - optional nearby scope witness relation when same-activity truth depends on explicit axes
   - optional remembered warnings or preferred-view hints when the activity meaningfully depends on explicit remembered context
   - compact historical relation instead of a fake live claim

6. **Entry ladder**
   - inspect the kit
   - open the preferred front door
   - open the named triage lane if one exists
   - open attached shelf/views nearby
   - compare current vs remembered/reviewed basis if drift matters
   - attach if a current live target exists
   - restore if a historical continuity path exists
   - relaunch from starter
   - instantiate fresh local starter instead
   - hold / repair / rehearse when needed

7. **Import/share posture**
   - personal / shared / published / imported ladder where relevant
   - imported/shared kits should stay visibly weaker until receiver-local fit and adoption are earned
   - a restricted-mode cue should be able to name which stronger actions are blocked pending trust or fit

8. **Witness relations**
   - binding witness relation when joins repair or widen
   - scope witness relation when same-activity claims depend on explicit axes
   - continuity choice witness relation when attach/restore/reuse/fresh-start authorship matters
   - receiver-fit / landing / trust posture relation when the kit arrived from elsewhere

## Guardrails

1. **Not a live session object**
   - the entry kit points toward work;
     it is not proof the work is live now.

2. **Not the activity spine**
   - a spine frames the work.
     the entry kit is the saved way in.

3. **Not the resource shelf**
   - a shelf curates grouped resources.
     the entry kit may point to one shelf,
     but should not flatten into it.

4. **No hidden target choice**
   - remote/profile/account/browser/session-like target selection should remain inspectable and reviewable when it matters.
   - preferred scope affinity is allowed; silent scope choice is not.

5. **No silent strong action on open**
   - selecting/opening an entry kit should not automatically run the strongest possible action family.
   - inspect,
     open front door,
     attach,
     restore,
     relaunch,
     and fresh start should remain distinguishable.

6. **No auto-generation from recents folklore**
   - ordinary open/recent/share history should not silently become durable entry-kit truth.

7. **Do not become a giant workspace bureaucracy**
   - this should stay one compact shell-owned starter object,
     not a sprawling project-management platform.

8. **Derived from existing shell truths**
   - entry kits should compose with Recall,
     Tiling Shell,
     Omnibox,
     Exchange,
     activity spines,
     and resource shelves rather than forming a parallel worldview.

## Why this looks promising

This move now combines several already-strong Helm threads:
- saved view objects
- activity spines
- resource shelves
- checkpoint branches
- launch ladders
- imported-surface trust posture
- and request-vs-live honesty

It also gives Helm a better answer to a real user question:
**"take me back to the thing I was doing"**
without forcing Helm to lie about whether that thing is already live.
