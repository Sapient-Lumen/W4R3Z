# Default-fill receipt candidate contract v0

Purpose: define one compact shell-owned **receiver-default witness** for the classes or slots that were actually filled from local defaults during rehearsal,
landing,
or bounded adoption,
so inherit masks stay honest and carried omission does not masquerade as carried sameness.

A **default-fill receipt** is the actual-fill sibling of inherit masks.
It should compose with:

- inherit masks
- landing manifests
- receiver fit cards
- rebind ladders
- arrival overlays
- adoption slices
- local overlays
- residue ledgers
- promotion receipts
- and surface core digests

## Why this move now

Helm already has a permission surface for inheritance.
An inherit mask can say which bounded classes may honestly use receiver defaults.
But Helm still lacks the matching witness for what *actually happened* on one receiver.

That gap matters because permission and outcome are different things.
A landing may allow receiver defaults for one class,
but then:

- use a default,
- refuse the default,
- leave the class pending,
- convert it into a local overlay,
- or discover that the class was stronger than defaults were allowed to fill.

Current tools keep validating that distinction.
VS Code Profiles can include settings inherited from the Default Profile,
partial export can choose whether those inherited settings are included,
and scoped settings split user/global from workspace-local behavior.
Raycast likewise separates local personal quick structure from shared quicklinks.
Figma's slot/property mapping pressure suggests that flexible structured gaps are most truthful when the shell names how each gap was filled.

That combination strongly suggests Helm should stop saying only “defaults are allowed here” and start saying “these defaults actually filled these slots here.”

## Candidate shape

A first useful default-fill receipt would likely include:

1. **Owner surface witness**
   - landing manifest id
   - deck recipe id
   - dock band id
   - exact action key family id
   - or another admitted shell-owned owner

2. **Fill table**
   - slot or class id
   - carried / omitted / inheritable status
   - actual fill source
     - receiver Default Profile
     - receiver workspace default
     - receiver shell preference set
     - local overlay
     - none / pending
   - gate result
     - used
     - refused
     - still pending
     - explicit rebind required

3. **Witness links**
   - inherit mask ref
   - anchor-map slot/class ref
   - fit-card or rebind-ladder ref when relevant
   - optional local-overlay ref if the fill turned into a stronger local delta

4. **Tiny next actions**
   - inspect used default
   - freeze this fill into a local overlay
   - convert this class into carried structure next export
   - refuse default fill and rebind explicitly

## Rules that matter

### 1. Permission to inherit is not proof of actual fill
The receipt exists because “may use receiver defaults” is weaker than “did use receiver defaults here.”
Do not collapse those two steps.

### 2. Default-fill receipt should name the source class,
not just say “auto”
The shell should tell the operator whether the fill came from user/profile defaults,
workspace defaults,
local overlay,
or another admitted local source.
“Auto” is not enough.

### 3. Strong classes should still refuse default fill
Trust posture,
identity,
credentials,
strong route authority,
and similar classes should not quietly appear in a default-fill receipt as if ordinary inheritance were acceptable.
Those classes stay on stronger seams.

### 4. Default fill does not equal carried sameness
Two receivers may use different defaults to fill the same omitted class.
That should stay visible.
A receipt of default use should never be mistaken for proof that the landing is now identical everywhere.

### 5. The first version should stay compact
Start with one or two low-risk fill classes such as chrome,
placement hints,
or shortcut presentation.
Do not build a giant fallback engine before one clean specimen exists.

## Best first homes

- one dock band where edge/chrome defaults are allowed and actually filled locally
- one deck recipe where view chrome or pane sizing defaults are allowed and receipted
- one exact action key family where presentation or shortcut defaults are allowed while target binding still requires explicit rebind
- one landing manifest where one class inherits locally,
one remains pending,
and one is refused from default fill entirely

## What this is not

- not a sync diff
- not a hidden auto-heal matcher
- not proof that the landing fully succeeded
- not permission to default-fill strong authority classes
- not a substitute for rebind ladders or fit cards

## A good first proof slice would show

- one incoming surface with three admitted classes,
- one class filled from a named receiver default,
- one class still pending explicit rebind,
- one class refused from default fill,
- and one receipt that names all three honestly.

## Why this seems worth keeping warm

Default-fill receipts now look like the smallest honest answer to “the packet did not carry this,
but the receiver filled it anyway.”
They let Helm stay flexible without letting flexibility turn into ambient sameness folklore.
