# Facet strip candidate contract v0

Purpose: give Helm one compact shell-owned way to pivot a summon/search/recency surface between **typed result families** without pretending one flat list always tells the truth.

This move exists because modern tools keep rediscovering the same thing:
fast search feels better when the user can pivot between explicit families such as apps, files, actions, or clipboard history.
Helm can generalize that into typed shell truth.

## What a facet strip is

A facet strip is a **small typed pivot row** attached to a shell-owned search, summon, or recency surface.

A first Helm-flavored family might include:

- objects
- actions
- routes
- receipts
- transfers / clipboard / exchange
- windows / workspaces when the active scope is spatial

Not every surface needs every facet.
The point is to keep the result family explicit when that improves honesty and speed.

## Where it can appear

Facet strips are most promising across:

- **Omnibox** for typed summon/search pivots
- **Recall** for recency families like exact objects, reviewed actions, receipts, and holds
- **Exchange** for transfer history, clipboard-like material, route options, and receipts
- later perhaps **Overview** when type-to-search spans windows, workspaces, and objects

## Why this is better than one giant list

One giant list is flattering.
It can be fast, but it also hides:

- what kind of thing you are seeing,
- what kinds of next moves are valid,
- why one family is missing,
- and when history, objects, actions, or transfers are being mixed too aggressively.

A facet strip gives Helm one compact typed honesty move without forcing giant separate products.

## Guardrails

### 1. Facets are pivots, not new pillars
A facet strip should not create separate mini-products with separate ontologies.
It is a compact typed lens over shared shell truth.

### 2. Facets must not erase shared keyboard flow
The strip should stay compatible with type-to-search, keyboard pivots, and a single fast summon path.

### 3. Empty or unavailable facets should stay honest
If a facet has no live hits or is disabled, the shell should say so instead of silently blending in nearby families.

### 4. Facets should not become provider spam
The first cut should use stable shell-level families, not every provider inventing a new visible bucket.

## First specimen worth proving

One good first specimen would be:

- an Omnibox strip with objects / actions / routes,
- a Recall strip with live / restored / historical / receipts,
- and an Exchange strip with transfers / clipboard-like items / route receipts.

That is enough to prove typed pivots without building a giant universal search constitution.
