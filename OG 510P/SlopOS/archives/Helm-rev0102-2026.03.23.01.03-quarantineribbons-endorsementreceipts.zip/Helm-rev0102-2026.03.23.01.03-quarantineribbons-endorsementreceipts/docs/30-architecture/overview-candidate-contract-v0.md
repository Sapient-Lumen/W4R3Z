# Overview candidate contract v0

Purpose: name the spatial companion to Omnibox without prematurely freezing a whole worldview.

Overview is **not** a new pillar.
It is a candidate shell surface that may become essential because Helm otherwise risks becoming powerful but too non-spatial.

This revision sharpens one thing:
**Overview should be a weak landing surface built from exact smaller shell objects, not a giant dashboard or second authority plane.**

It can now also borrow tiny **watch cards** backed by explicit watchpoints when that helps orientation without hiding stronger truth,
and it should increasingly act as a launcher for **patrol routes** rather than a substitute for them.

## Candidate posture

1. **Overview is the spatial companion to Omnibox**
   - Omnibox is sparse, typed, and direct
   - Overview is glanceable, spatial, and immediate

2. **Overview should render shell truth, not parallel folklore**
   - windows
   - workspaces
   - focus state
   - continuity cues
   - layout state
   - current-live beacons
   - linked views
   - exact front-door handles
   - patrol starts / resume cards
   - maybe one bounded ops slice

3. **Overview is a landing surface, not a master dashboard**
   - it helps the operator get back in
   - it does not become the hidden place where live authority, profile choice, or route mutation are silently decided

4. **Type-to-search should still be present**
   - Overview should complement Omnibox, not trap users in pointer-only navigation

5. **Subscriptions, glances, watchpoints, and patrols may appear, but as bounded derivatives or launchers**
   - Overview can show a saved view next to its subscription state, one watchpoint state card, last-fired receipt, one glance derivation, or one patrol start/resume card
   - but those smaller surfaces remain derivative from stronger shell truth and weaker than live authority

6. **Fast move / quick act / quick jump matter**
   - jump to workspace
   - move window
   - reopen/reenter from Recall cues
   - open linked view
   - follow one compare path
   - jump through one front-door handle
   - start or resume one patrol route

7. **Muted is not healthy**
   - if a watchpoint card is muted or snoozed, Overview should not paint it as recovered
   - delivery posture and evaluated state should stay visibly distinct

8. **Operations truth must stay consistent**
   - Overview should not invent a second hidden state model separate from Operations Center or the shell graph

## Candidate v0 specimen

A narrow slice could be:
- show all workspaces,
- show focused and visible windows,
- show one current-live beacon per relevant lane,
- show a few linked views or handles,
- show one or two glance derivations with freshness posture,
- show one watchpoint card,
- show one patrol start or resume card,
- permit quick keyboard jump and one window move,
- and allow typing to narrow or jump.

## Guardrails

- do not copy GNOME or KDE whole
- do not let Overview become a decorative mode disconnected from shell truth
- do not let it compete with Omnibox for semantic dispatch
- do not let it become giant dashboard religion
- do not let it silently choose profile/provider/account/session truth

## Working stance

Overview is increasingly plausible as a real Helm surface, but Helm should earn it through a compact specimen first.
The best first proof is not a universal home screen.
It is a weak landing surface assembled from linked views, exact handles, patrol starts, glance derivations, watchpoints, beacons, and one bounded ops slice.
