# Contribution witness candidate contract v0

Purpose: give Helm one compact post-run witness for what actually influenced a result, proposal, or bounded action.

A **contribution witness** is not a full provenance graph.
It is a small honest after-surface.
It answers:

**what was loaded, what was actually used, and what remained merely nearby or available?**

## Candidate posture

### 1. Selection truth and influence truth stay separate
A witness should distinguish between:
- selected members
- loaded members
- actually used / referenced members
- skipped / denied / unavailable members

### 2. The witness belongs to a bounded act
Good owners include:
- one ask
- one compare
- one route proposal
- one pre-apply action preview
- one generated summary / explanation / plan

### 3. Tools and customization matter too
If tools,
instructions,
prompt files,
or saved loadout members influenced the result,
the witness should be able to say so compactly.

### 4. The witness is not a correctness proof
It explains contribution posture.
It does not prove the result is correct,
current,
or safe to apply.

### 5. Durable consequence still needs stronger surfaces
If the act widened authority,
changed state,
or produced durable consequence,
a contribution witness should complement receipts/review strips rather than replace them.

## Candidate minimal shape

A first useful witness likely needs:
- owner act id
- selected member count / refs
- used member count / refs
- skipped/denied/unavailable notes
- tools used
- optional analysis-steps or source-details link
- preview/applied posture when relevant
- timestamp

## Best first homes

- one Ask/compare result with visible used sources
- one spreadsheet-like proposed action with preview then apply
- one Omnibox / terminal result that shows the exact tools and prompt fragments that participated

## Guardrails

1. **No giant forensic theater**
2. **No hiding all detail behind “trust us” badges**
3. **No pretending selected means used**
4. **No pretending used means correct or current**
5. **No replacing receipts, route witnesses, or current-live beacons**

## Working stance

Contribution witnesses now look like the right neighbor for context loadouts.
They let Helm be unusually powerful in a rare way:

**the shell can feel smarter while becoming more inspectable after the fact, not less.**
