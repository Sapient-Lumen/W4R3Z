# Patrol route candidate contract v0

Purpose: give Helm one shell-owned object for **bounded repeated revisits** so the shell can keep “the rounds I make,” “the sources I trust,” and “the order/context I carry” separate from giant dashboards, piles of favorites, and current-live authority.

A **patrol route** is a shell-owned revisit circuit bound to:
- a small ordered set of exact shell-object stops
- zero or one bounded dynamic lane
- optional carried context
- and optional personal progress state

It is a candidate move, not a freeze.

## Candidate shape

A first useful patrol route would likely include:
- patrol-route id
- title
- publication posture (personal / shared / published)
- default start stop
- ordered stop list
- optional bounded dynamic lane descriptor
- carried context descriptor
- route summary / purpose
- personal progress state (last visited stop, collapsed sections, skipped/snoozed stops)
- route actions (start / next / previous / resume / jump to source / inspect route)
- optional route-level glance or digest face

## Candidate stop kinds

Keep the first version small.
For example:
- exact linked view
- exact saved view
- exact front-door handle
- exact watchpoint
- exact glance derivation
- exact evidence brief
- exact response kit
- exact review ticket or compare card
- exact current-live beacon

## Candidate posture

### 1. Bound to stronger exact source objects
A patrol route should mostly point at exact existing shell objects.
Those source objects remain stronger truth than the patrol route itself.

### 2. The patrol route is not the current live lane
A patrol route can describe where to go and what to inspect.
It does **not** prove:
- that those objects are current-live,
- that the operator completed the round,
- that the underlying state stayed stable since the last round,
- or that profile/account/provider truth has already been resolved.

### 3. Shared definition and personal residue stay separate
A shared patrol route may define:
- the stop order,
- the purpose,
- one dynamic lane,
- and suggested carried context.

But personal state such as:
- last visited stop,
- collapsed groups,
- personal snoozes,
- or “resume here”
should remain personal unless explicitly published.

### 4. Dynamic lanes stay bounded and witnessed
A patrol may include one bounded dynamic lane.
If so,
Helm should show:
- what exact source view/query/tag produced it,
- how membership is determined,
- and when it was last refreshed.

Dynamic lanes should not silently widen into a giant dashboard engine.

### 5. Patrol traversal may carry context
Useful carried context might include:
- time range
- selected object or scope
- compare basis
- active activity spine

But carrying context is still weaker than silently choosing live identity or authority.

### 6. Overview may launch patrol routes
Overview can show patrol starts,
resume cards,
or a compact patrol summary.
But Overview remains the landing surface;
the patrol route remains the explicit revisit object.

### 7. Cycle or presentation mode must stay weaker and explicit
A patrol route may later support a weak cycle / wall-display mode.
If it does,
that mode should remain explicit and bounded.
It must not silently become the normal patrol posture.

### 8. Imported/shared patrol routes start weaker
Imported or shared patrol routes should not silently adopt local authority,
re-arm watchpoints,
or choose local profiles/accounts/providers.
The receiver should be able to inspect and adopt them explicitly.

## Guardrails

1. **Do not let patrol routes become giant dashboards in disguise.**
2. **Do not let “resume” impersonate current-live proof.**
3. **Do not let dynamic patrol members hide their source witness.**
4. **Do not let patrol traversal silently choose profile, account, or provider truth.**
5. **Do not let patrol routes become hidden workflow engines.**
6. **Do not let a route-level summary replace stronger source inspection.**

## Good first specimens

- one morning triage patrol over a watchpoint, a linked view, and one compare ticket
- one operations patrol with two watchpoints and one exact front-door handle
- one personal patrol that resumes at the last stop without pretending the route itself is live proof
- one shared patrol where the route definition is shared but the resume state remains personal
- one patrol with a bounded dynamic lane sourced from one exact saved view or tag-backed list

## Working stance

Patrol routes now look like the missing revisit object in Helm's support stack.
They let Helm admit that people make meaningful rounds,
without confusing those rounds with a giant home screen,
a hidden automation engine,
or the live truth itself.
