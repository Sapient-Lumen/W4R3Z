# Attenuation ladder candidate contract v0

Purpose: give Helm one shell-owned humane chooser for **how a live grant should become weaker** when full revoke is unnecessary or too blunt.

The goal is not a giant policy editor.
The goal is to stop pretending the only choices are “leave it broad” or “kill it completely.”

## Contract

An **attenuation ladder** is a bounded shell-owned chooser that offers a small number of distinct weaker postures for one live authority family in one current situation.

At minimum it should be able to represent:

### A0 — keep current rung
- no weakening yet
- inspect current-live posture only

### A1 — inspect only
- retain explanation/history surfaces
- remove stronger live authority

### A2 — exact next act only
- allow one exact reviewed next action
- remove broader carryover afterward

### A3 — this ask / loadout only
- weaker than activity-wide continuity
- good when the operator wants the current task to finish but not linger

### A4 — this activity only
- keep the grant within one named activity frame
- revoke it when the activity ends or is explicitly narrowed again

### A5 — isolated lane only
- the strongest live weakening move
- remove authority from the live lane while preserving room inside an explicit side lane/worktree/shadow lane

### A6 — subject/subfamily narrowing
- keep the grant but only for:
  - one source,
  - one route family,
  - one file/folder,
  - or one command allowlist

Not every family needs every rung.
Some families may only support A1, A3, and A6.
That is fine.

## Truth posture

### 1. Each weaker rung must change something real

An attenuation ladder is only honest if each rung differs in a meaningful axis:
- duration,
- holder,
- lane,
- subject family,
- command family,
- or current-live carryover.

### 2. The ladder should prefer weakening over folklore

If the operator wants “less power, still useful,”
Helm should offer a truthful weaker rung instead of forcing them to remember that hidden settings exist elsewhere.

### 3. Isolation is a real attenuation shape

“Live lane no, isolated lane yes” should count as a first-class weakening move,
not as a weird workaround.

### 4. Narrowing one subfamily must not overclaim broader safety

Blocking `rm` or one source family does not prove the rest is harmless.
The ladder should name what changed,
not flatter the operator with a general-safe aura.

### 5. Reacquire remains a stronger separate act

Once attenuated,
a later desire to broaden again should pay for a fresh stronger step.
The ladder must not quietly remember the old broader rung as ambient entitlement.

## Why Helm wants this

Without an attenuation ladder,
Helm risks making live grants feel sticky and awkward to tame.
That would quietly reintroduce the same authority folklore the archive has been trying to kill.

With an attenuation ladder,
Helm can make safer control feel powerful:
- **finish this ask, then stop**
- **keep this helper only in the side lane**
- **keep read, drop write**
- **block destructive commands, leave the rest review-bound**
- **keep this activity, not this account or source family**

## First proof target

A good first specimen would be one shell-owned chooser that appears on a current-live beacon and offers:
- inspect only,
- this ask only,
- isolated lane only,
- block one dangerous command family,
- and full revoke.

That is enough to learn whether Helm can make de-escalation feel like a luxury instead of a panic button.
