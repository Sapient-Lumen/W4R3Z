# Preview-promotion ladder candidate contract v0

Purpose: define one shell-wide grammar for preview that is useful,
keyboard-first,
and promotable without pretending preview is already the stronger act.

This is **not** a new pillar.
It is a reusable shell move intended to support Omnibox,
Object Browser,
Recall,
Exchange,
and Operations Center.

## Why this exists

Helm repeatedly wants the same humane interaction:

- find something quickly
- inspect it without committing too hard
- take a small bounded action if needed
- and then promote into a stronger surface only if the user chooses that move

Many products now validate pieces of this grammar.
Helm should make it one shell law instead of re-inventing it five times.

## Contract

### A preview surface must provide
- a compact but meaningful representation of the subject
- source / route / provenance posture close to the preview itself
- exactness or locality caveats when relevant
- a small bounded action set
- one or more explicit promotion exits

### Promotion exits may include
- open
- reveal
- split
- pin
- compare
- branch-from-here
- restore-from-here
- import
- adopt
- share

Not every family needs every exit.
But each family should use the same grammar:
**preview stays weaker until the stronger exit is chosen.**

## Required laws

### 1. Preview is not open
A preview may inspect,
peek,
or rehearse.
It does not silently become a full open/adopt/launch path.

### 2. Preview may carry bounded actions
For example:
copy a field,
quick-reveal,
route inspection,
add a note,
pin to a dock,
request review,
or queue a compare.
But these actions must stay clearly weaker than full adoption or launch when that distinction matters.

### 3. Promotion should preserve context
When promoting from preview,
the shell should preserve useful context such as the chosen comparison target,
query basis,
checkpoint,
route,
or slot selection where possible.

### 4. Promotion should say what changed in strength
Going from preview to split,
branch,
import,
or adopted local object is a real posture change and should be explainable.

## Suggested UI grammar
- one consistent preview key / gesture from major shell surfaces
- tiny action rail or strip inside preview
- explicit badges for live,
historical,
imported,
restricted,
repaired,
or partial posture when relevant
- promotion commands with names that describe the stronger act

## Cross-pillar effects
- **Omnibox** gets richer than search-plus-open
- **Object Browser** gets faster triage without losing reveal/adopt honesty
- **Recall** gets better compare and reentry choices without overclaiming continuity
- **Exchange** gets inspect-before-import/share/attach
- **Operations Center** gets humane inspection of jobs,
receipts,
and routes before stronger intervention

## Early specimen ideas
- previewing a saved view object before opening or pinning it
- previewing a checkpoint before restore or branch-from-here
- previewing a route receipt before replay or inspect route
- previewing a shared/imported deck before local adoption

## Judgment

This contract is worth proving soon because it can make Helm feel dramatically better with very little new ontology,
while also protecting against one of the oldest shell lies:
that peeking and committing are basically the same move.
