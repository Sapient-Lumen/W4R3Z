
# Binding witness posture v0

Purpose: freeze one narrow cross-cutting rule before Helm's saved-to-live joins drift into hidden rebinding folklore.

Helm increasingly has surfaces that connect saved or planned structure to current live structure:
- capsules,
- layout templates,
- activity cockpit cards,
- activity entry kits,
- typed seeds with preferred targets,
- and future restore / attach / relaunch flows.

These joins can be valuable.
But when the join is **not exact**, Helm should not silently flatten it into ordinary success.

This is intentionally a small posture.
It does **not** define one universal matching engine, slot algebra, or remote/account taxonomy.
It only names the minimum honesty Helm should keep once saved/planned artifacts start meeting current live targets.

## Posture

1. **Non-exact joins should stay witnessable**
   - if Helm reuses, repairs, or rebinds a saved/planned subject against a current live target non-exactly,
   - that should remain inspectable as a witnessed join rather than a silent success.

2. **Exact joins may stay compact; repaired joins must stay legible**
   - exact identity matches can remain lightweight,
   - but repaired / substituted / ambiguous / downgraded matches should expose what happened and why.

3. **Saved hints do not certify current concrete targets**
   - a saved slot,
   - recent live handle,
   - last-good receipt,
   - preferred peer,
   - or remembered profile/account/browser target
   does not by itself prove that the same concrete target is current and admissible now.

4. **Witnesses should separate planned subject, observed candidate, and action family**
   Helm should keep these nearby truths separate when they matter:
   - what the saved/planned artifact expected,
   - what live candidate was actually observed,
   - how strong the match was,
   - and what action family remains honest now.

5. **Silent target substitution is not an acceptable continuity story**
   - if the system cannot justify an exact or repaired join clearly,
   - it should prefer hold / repair / inspect / fresh launch instead of hidden retargeting.

6. **Remote/profile/account/browser/session-like joins deserve extra caution**
   - destination posture may be remembered,
   - but strong reuse across remote/profile/account/browser/session-like boundaries should remain inspectable and reviewable when exact current truth is missing.

7. **The witness can be compact without becoming weak**
   - this posture does not require an essay every time,
   - only that non-exact joins remain visible enough to inspect, rehearse, hold, or downgrade honestly.

## Where this should visibly pressure Helm

### Recall
- capsules, restore receipts, and live reentry cues should not silently claim repaired matches as exact continuity

### Tiling Shell
- layout-template rebinding should stay visible when saved slots attach to nearby-but-not-identical live windows

### Omnibox
- selecting an entry object should not hide whether the next move is exact attach, repaired reuse, relaunch, or hold

### Operations Center
- current live sessions/activities and saved/planned joins should remain distinguishable, with repair state visible where needed

### Overview / cockpit / entry surfaces
- spatial glanceability is welcome, but the saved-to-live join should not disappear behind a single flattering badge

## Non-goals

- no universal slot algebra yet
- no final remote/profile/account destination taxonomy yet
- no promise that every exact join needs a card
- no fuzzy global identity engine
- no giant workspace/session manager

## Why this freeze is worth doing now

Helm already froze:
- request-vs-live truth,
- and entry-artifact truth.

But that still leaves one common continuity lie available:
**a system can admit the saved thing is not live, then quietly pretend its repaired match is close enough to count as obvious.**

SlopOS keeps refusing silent nearby substitutes across reveal, launch, recents, and request-state seams.
Schell now has enough launch-kit/cockpit pressure that matching honesty matters.
Helm now has enough saved/planned surfaces that hidden rebinding would spread quickly if left implicit.

This posture keeps the next layer of continuity law explicit:
**non-exact binding is allowed to be useful, but it is not allowed to be invisible.**
