# Companion resource bundle candidate contract v0

Purpose: define one compact shell-owned way for a primary Helm surface to carry **helpful secondary resources** without letting those resources impersonate live authority,
local fit,
or trust.

A **companion resource bundle** is a typed set of travel-safe secondary references attached to a primary shell surface.
It should compose with:

- exact action keys
- deck recipes
- handoff packets
- landing manifests
- receiver fit cards
- publication ladders
- promotion receipts
- and future view decks / entry kits

## Why this move now

Several current tools now validate the same useful pattern:

- Figma Dev Mode lets components carry GitHub,
  Jira,
  Storybook,
  and VS Code links that propagate to instances
- Raycast Deeplinks and shared quicklinks show how exact handles can carry helpful starting context
- Notion dashboards and first-class views validate explicit compositional surfaces rather than one monolithic dashboard truth

Helm keeps circling the same nearby idea:
portable shell surfaces often need a few good helpers to land well,
but those helpers should remain clearly secondary.

## Candidate shape

A first useful companion resource bundle would likely include:

1. **Primary owner surface**
   - exact action key
   - packet
   - deck recipe
   - entry kit
   - view deck
   - or another admitted primary surface

2. **Companion entries**
   - documentation link
   - runbook
   - dashboard
   - code or repo link
   - ticket / issue
   - Storybook / design link
   - saved query or search handle
   - other exact,
     typed,
     explicitly secondary entries

3. **Role labels**
   - explain
   - implement
   - validate
   - observe
   - recover
   - escalate

4. **Strength / trust labels**
   - authoritative-primary remains elsewhere
   - companion is secondary
   - local-only companion
   - portable companion
   - inspect-only companion

5. **Open posture**
   - preview companion
   - open locally
   - offer rebind if needed
   - hold if trust / fit not satisfied

6. **Propagation policy**
   - stays with the primary surface when published/exported
   - stays local only
   - drops on travel
   - or requires explicit promote/share

## Rules that matter

### 1. The primary surface stays primary
A companion never becomes the main object by familiarity alone.

### 2. Companions do not satisfy fit or trust
They may help the operator,
but they do not count as local binding,
receiver fit,
or approval.

### 3. Companions may be more portable than overlays,
but less strong than the primary
The bundle can travel,
but only as subordinate context.

### 4. Companions should be typed and inspectable
A vague pile of links is not enough.
A first bundle should stay legible.

### 5. Companions may be dropped honestly
If a companion cannot travel safely or fit the receiver,
Helm should be allowed to leave it behind and say so.

### 6. No hidden credential laundering
Companions should not secretly carry secrets,
auth sessions,
or device-local privilege residue.

## Best first homes

- a deck recipe with docs,
  dashboards,
  and a ticket link
- an exact action key with one runbook and one saved query
- a command-dock item with a linked troubleshooting note
- an entry kit with design,
  implementation,
  and recovery companions

## What this is not

- not a browser bookmark dump
- not a collaboration layer by itself
- not a replacement for receipts,
  fit,
  rebinding,
  or trust ladders
- not a way to smuggle local state across locality tiers
- not proof that a linked resource is current or compatible

## A good first proof slice would show

- one exact action key or deck recipe,
- one small companion bundle with typed roles,
- one portable companion and one deliberately local-only companion,
- and one landing manifest / fit card pair that keeps the companions visibly secondary.

## Why this seems worth keeping warm

Companion resource bundles now look like one of the best “steal this” moves for Helm.
They add landing intelligence and operator help without forcing Helm to become a giant collaboration product.
