# Landing manifest candidate contract v0

Purpose: define one compact shell-owned **carried witness** that travels with a portable surface so Helm can tell the truth about what is actually being handed over before the receiver computes fit,
rebind,
materialization,
or adoption.

A **landing manifest** is the portable side of Helm's travel story.
It complements,
but does not replace:

- portable cores
- local overlays
- handoff packets
- promotion receipts
- receiver fit cards
- rebind ladders
- derivation strips
- and basis packets

If a receiver fit card answers **"what fits here right now?"**,
a landing manifest answers **"what exactly arrived here,
what basis does it carry,
and what did it deliberately not try to carry?"**

## Why this move now

Helm has accumulated enough travel-ready ideas that the receiver side is no longer the only missing witness.
The source side now needs a compact,
inspectable carried story for:

- exact action keys
- handoff packets
- deck recipes
- command-dock items
- entry kits
- view-deck starters
- and future publication/share surfaces

Without one,
Helm risks two flattering lies:

- “this arrived,
  so the receiver should already know what it is,”
- and “this portable surface is self-explanatory,
  so the operator does not need a compact carried-basis witness.”

## Candidate shape

A first useful landing manifest would likely include:

1. **Primary family and id**
   - packet id
   - portable core id
   - exact action key id
   - deck recipe id
   - or another admitted portable family id

2. **Carried basis witness**
   - source object or surface family
   - basis digest / revision / epoch / recipe id
   - creation or publication receipt id if present
   - freshness note if the basis matters

3. **Portable payload summary**
   - carried structure classes
   - admitted exact handles
   - view/deck family
   - route or launch family
   - declared locality tier

4. **Companions carried with it**
   - docs
   - runbooks
   - dashboards
   - code links
   - tickets
   - exact query links
   - other explicitly secondary companions

5. **Deliberate omissions**
   - local overlay state
   - profile/session/account choice
   - trust posture
   - receiver-local placement
   - secrets / credentials
   - device-local residue

6. **Intended landing posture**
   - inspect-only
   - fit-card first
   - rebind-first
   - materialize-first
   - adopt-only-after-review

7. **Integrity / witness hooks**
   - publication receipt ref
   - promotion receipt ref
   - packet digest
   - source witness id

## Rules that matter

### 1. A landing manifest is not receiver fit
It explains what was carried.
It does not claim that the receiver already matches.

### 2. A landing manifest is not activation
Arrival should still be weaker than current live local truth.

### 3. Omissions are first-class truth
What did **not** travel should be explicit,
not treated as embarrassing implementation residue.

### 4. The manifest should stay compact
It should be inspectable at a glance.
If it becomes a giant sync schema,
Helm is probably lying or overreaching.

### 5. Companion resources stay subordinate
The manifest may name carried companions,
but the primary shell surface remains primary.

### 6. Some surfaces may refuse to travel without one
If a portable family cannot be honestly described yet,
Helm should be allowed to refuse export/share/travel for now.

## Best first homes

- handoff packets for exact action keys
- deck recipes or view-deck starters
- shared command-dock items
- activity entry kits
- publication/export of saved shell view objects

## What this is not

- not a universal sync format
- not a hidden local setup script
- not proof that the receiver can satisfy the manifest
- not a substitute for fit cards,
  rebinding,
  trust,
  or adoption
- not a promise that every useful shell luxury is portable

## A good first proof slice would show

- one packet or exact action key with a compact manifest,
- one carried companion bundle,
- one explicit omitted local overlay,
- and one receiver fit card that consumes the manifest without auto-activating anything.

## Why this seems worth keeping warm

Landing manifests now look like the missing portable-side witness for Helm's travel story.
They make travel more honest **before** the receiver starts solving local fit.
