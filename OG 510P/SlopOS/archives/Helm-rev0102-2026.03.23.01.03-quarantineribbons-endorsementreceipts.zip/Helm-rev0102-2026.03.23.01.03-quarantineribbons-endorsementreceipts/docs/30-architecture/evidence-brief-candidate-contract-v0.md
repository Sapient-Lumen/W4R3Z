# Evidence brief candidate contract v0

Purpose: give Helm one shell-owned object for **bounded curated investigation** so the shell can keep exact source refs, weak explanation, and handoff posture separate from giant notebooks, giant case systems, and live authority.

An **evidence brief** is a shell-owned curated bundle bound to:
- a small set of exact shell-object refs
- optional weak authored or machine-assisted notes
- optional question / hypothesis / finding summary
- and optional share/handoff posture

It is a candidate move, not a freeze.

## Candidate shape

A first useful evidence brief would likely include:
- evidence-brief id
- title
- publication posture (personal / shared / published)
- optional owning activity spine ref
- optional originating watchpoint / patrol route / review ticket ref
- optional question / hypothesis
- ordered evidence member list
- member annotations / significance notes
- authorship witness (human / machine-assisted / mixed)
- optional freshness or frozen-snapshot posture
- brief actions (open source / inspect evidence / jump to member / share / export packet / fork brief)
- optional short next-step list

## Candidate member kinds

Keep the first version small.
For example:
- exact saved view
- exact linked view
- exact watchpoint
- exact glance derivation
- exact review ticket or compare card
- exact timeline marker
- exact effect receipt or route witness
- exact front-door handle
- exact current-live beacon

## Candidate posture

### 1. Bound to stronger exact source objects
An evidence brief should mostly point at exact existing shell objects.
Those source objects remain stronger truth than the brief itself.

### 2. The brief is not the current live lane
An evidence brief can explain why something matters.
It does **not** prove:
- that the gathered objects are current-live,
- that the annotations are correct,
- that the summary is the verdict,
- or that a shared/imported brief already matches local authority.

### 3. Weak explanation stays visibly weaker than evidence
A brief may carry:
- operator notes,
- machine-assisted summary,
- likely cause,
- or recommended next steps.

But those should stay visibly weaker than the exact gathered evidence.

### 4. Authorship should stay inspectable
Useful authorship posture might include:
- human-authored
- machine-assisted draft
- machine-gathered plus human-edited
- imported/shared external brief

Helm should not flatten these into one neutral prose surface.

### 5. Freshness posture should stay explicit
Some briefs may be:
- frozen snapshots,
- freshness-tracking collections,
- or mixed collections with stale members.

That posture should stay visible rather than hidden behind a neat title.

### 6. Briefs should compose with activity spines and patrol routes
A brief may belong to an activity spine.
A patrol route may stop at a brief or launch from one.
But the brief remains a bounded curated object,
not the whole work frame or the whole revisit circuit.

### 7. Briefs should compose with handoff packets and publication ladders
A brief may travel.
Travel should remain explicit.
Receiver-side adoption should remain explicit too.

### 8. Imported/shared briefs start weaker
Imported or shared briefs should not silently adopt local authority,
re-arm watchpoints,
or choose local profiles/accounts/providers.
The receiver should be able to inspect and adopt them explicitly.

## Guardrails

1. **Do not let evidence briefs become giant notebooks in disguise.**
2. **Do not let evidence briefs become workflow/case engines in disguise.**
3. **Do not let a brief summary outrank the gathered evidence.**
4. **Do not let imported/shared briefs auto-activate local truth.**
5. **Do not let weak annotations impersonate verdict or live proof.**
6. **Do not let a brief replace easy jump-back-to-source.**

## Good first specimens

- one watchpoint firing promoted into a brief with one saved view, one glance, one timeline marker, and one compare card
- one manually curated brief with three exact evidence members and one human hypothesis note
- one machine-assisted brief with explicit authorship witness and editable summary
- one shared brief that remains inspectable and adoptable without silently becoming local live truth
- one brief exported as a handoff packet and re-opened in restricted posture on another machine

## Working stance

Evidence briefs now look like the missing curation object in Helm's support stack.
They let Helm admit that people need to gather,
annotate,
and hand off exact signals,
without confusing that work with a giant notebook suite,
a giant dashboard,
or the live truth itself.
