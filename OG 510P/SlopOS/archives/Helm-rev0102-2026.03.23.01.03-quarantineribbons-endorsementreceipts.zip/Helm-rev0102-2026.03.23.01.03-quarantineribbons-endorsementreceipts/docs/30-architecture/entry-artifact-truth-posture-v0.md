
# Entry-artifact truth posture v0

Purpose: freeze one narrow cross-cutting rule before Helm's saved task-entry objects drift into flattering live-state folklore.

Helm will increasingly have **entry artifacts**:
- selected capsules,
- layout templates,
- activity cockpit shortcuts,
- typed seed bundles,
- and future activity entry kits.

These artifacts are valuable.
But unless Helm says otherwise, they are **not current live desktop truth**.

This is intentionally a small posture.
It does **not** define a giant universal entry schema.
It only names the minimum split Helm should keep as saved guidance objects accumulate.

## Posture

1. **A selected entry artifact is not the live thing itself**
   - choosing a capsule,
   - choosing a layout template,
   - opening an entry kit,
   - or selecting a saved route/seed bundle
   does not by itself prove a live window set, live session, current grant posture, or current remote/account/profile target.

2. **Entry artifacts are guidance, history, or planned shape first**
   - an entry artifact may preserve:
     - a desired arrangement,
     - a preferred route,
     - a last-known relation,
     - a seed set,
     - or a restore hint
   - but that still belongs to guidance/history/planned-shape truth until Helm reacquires live evidence.

3. **Historical entry artifacts do not reactivate authority by memory alone**
   - a saved task artifact should not silently resurrect:
     - prior attachability,
     - prior remote identity,
     - prior browser/profile/account posture,
     - or prior grant state
   merely because the artifact was opened again.

4. **Strong task-entry actions should stay visibly distinct**
   Helm does not need one giant taxonomy everywhere.
   But rich task-entry surfaces should preserve the difference among at least these action classes when they matter:
   - attach to live thing,
   - restore historical continuity,
   - relaunch from saved entry artifact,
   - fresh launch,
   - hold / repair / inspect instead.

5. **Entry artifacts can point to live truth without claiming it**
   - a cockpit may show a nearby entry kit,
   - an entry kit may point to a likely live activity,
   - a capsule may point to a recent restore receipt,
   - and a template may point to a current mismatch summary
   without collapsing those references into one success-shaped blob.

6. **Exactness still matters inside saved guidance**
   - if an entry artifact names an exact object, that refers to the artifact's saved subject or plan,
   - not a claim that the subject is currently live,
   - and not permission to silently choose a different target when the saved one is missing.

## Where this should visibly pressure Helm

### Recall
- capsule selection, live reentry, restore receipts, and entry kits should remain visibly distinct

### Tiling Shell
- layout templates and saved task-entry surfaces should not claim current spatial truth until bindings are reacquired

### Omnibox
- selecting an entry artifact should not flatten inspect, rehearse, relaunch, attach, and fresh launch into one action label

### Operations Center
- current live sessions/activities and saved entry artifacts should remain different lists or clearly different badge families

### Overview and cockpit surfaces
- spatial glanceability is welcome, but saved entry artifacts must not masquerade as live current activities

## Non-goals

- no promise of a single universal entry-artifact schema yet
- no claim that every capsule or template must become an entry kit
- no final remote/profile/account destination taxonomy yet
- no giant workspace or project-management ontology

## Why this freeze is worth doing now

Helm already has enough continuity pressure that drift is now predictable:
- capsules,
- layout templates,
- cockpit cards,
- typed seeds,
- and shell-facing restore flows.

Outside tools keep proving that users want saved task-entry objects.
SlopOS keeps proving that saved/requested/issued artifacts should not silently become current live state.
Schell now offers a concrete honesty model for launch kits and cockpit entry.

This posture lets Helm keep the delight while avoiding one of the oldest desktop lies:
**"because I picked the saved setup, the real thing must already exist now."**
