# Preview rail candidate contract v0

Purpose: give Helm one compact shell-owned way to keep **bounded next moves next to preview** without letting preview silently count as open, attach, import, or run.

This move exists because current tools keep converging on the same humane pattern:
preview gets much better when one or two typed next actions stay nearby.
But Helm should not pay for that by blurring inspect and execute.

## What a preview rail is

A preview rail is a **small adjacent action rail** attached to a shell-owned preview surface.

A useful v0 rail may include:

- inspect more
- exact reveal
- open
- route / send / attach
- review-first strong action
- hold / unavailable reason

The rail is not the preview itself.
The rail is the typed next-step edge next to preview.

## Where it can appear

Preview rails are most useful across:

- **Object Browser** preview panes
- **Omnibox** preview cards
- **Recall** preview cards for exact objects or receipts
- **Exchange** preflight views
- **Operations Center** evidence panes or failure/result previews

## Minimum visible facts

A useful v0 preview rail should keep a few facts obvious:

- exact subject or object kind
- provider or renderer used for the preview when that matters
- whether the preview is metadata-only, richer render, live-derived, or historical
- whether the next action is inspect-only, ordinary open, routed, review-first, or blocked
- why a stronger action is unavailable or held

## Guardrails

### 1. Preview must remain weaker than open
A preview rail should make next steps easier, but preview itself still remains observational by default.

### 2. The rail must not hide review or route law
If the next move is strong, it should still compose with review strips, basis truth, route witnesses, and receipts.

### 3. The rail must not flatten source grades
Live, historical, receipt-derived, imported, delegated, or metadata-only preview should not all look equivalent.

### 4. The rail should stay compact
The first cut is not a giant side panel of every imaginable action.
The point is one compact next-step edge, not a new action dashboard.

## First specimen worth proving

One good first specimen would be:

- one Object Browser file/object preview with exact reveal and open,
- one Recall preview with historical or receipt-derived grading,
- one Exchange preview with one review-first route,
- and one held/unavailable action that names why it is blocked.

That is enough to prove the distinction between preview and stronger action.
