# Action warrant candidate contract v0

Purpose: explore one compact shell-owned object for carrying one exact proposed strong change,
its exact reviewed basis,
and the honest ladder from inspection to apply.

An **action warrant** is not a receipt,
not a generic preview,
and not a giant workflow ticket.
It is a bounded shell-owned proposal object for one stronger act.

## Candidate shape

A first useful action warrant would likely include:

1. **Action subject**
   - one exact shell-owned reference to the object,
     route,
     lane,
     packet,
     or surface to be changed

2. **Proposed effect**
   - one explicit effect summary such as:
     - apply edit
     - restore checkpoint
     - attach selected packet
     - import and adopt
     - publish by rung
     - delete / revoke / forward / branch / replace

3. **Exact reviewed basis witness**
   - one carried basis stamp or equivalent exact witness such as:
     - object id / digest
     - revision / epoch
     - checkpoint id
     - source query / view / ticket id
     - current-live beacon id when relevant
     - expiry or observation witness when relevant

4. **Affected-set witness**
   - one compact diff-like,
     membership-like,
     or conflict-like summary that says what the warrant expects to touch

5. **Conflict / ownership witness when needed**
   - one compact note when the proposed effect may overwrite,
     transfer,
     or contend with another manager / owner / route / grant

6. **Context witness when relevant**
   - optional pointer to the context loadout,
     memory seed,
     skill/customization witness,
     or project/activity scope that materially shaped the proposal

7. **Privilege / follow-on posture**
   - optional indicator that the proposed change is distinct from any stronger follow-on run,
     secret-bearing workflow,
     or widened authority path

8. **Next-step ladder**
   - inspect
   - compare
   - adjust settings
   - apply / adopt
   - approve stronger follow-on
   - hold
   - review again

9. **Receipt handoff**
   - if applied,
     one obvious path to the resulting receipt,
     route witness,
     or effect receipt

## Guardrails

1. **Not every tiny action needs a warrant**
   - use warrants for stronger,
     mutable,
     authority-bearing,
     or multi-object acts.

2. **Not a receipt**
   - the warrant is pre-act posture,
     not durable proof of completion.

3. **Not a universal workflow engine**
   - keep the first warrant compact and shell-owned.

4. **No hidden basis drift**
   - if mutable basis moved,
     the warrant should downgrade through an adjacent drift gate rather than silently follow.

5. **No hidden privilege promotion**

### 6. Some warrants should target landing trains rather than direct one-step apply
A warrant may still describe one exact proposed strong change,
but the execution posture can be:
- direct apply,
- queued into one landing train,
- or promoted through guarded rungs.

That distinction should stay visible.

   - privileged follow-on execution should stay visibly stronger than ordinary apply/adopt.

6. **Keep the affected set honest**
   - if the shell cannot explain what would be touched,
     it should not bluff that the act is exact.

## Why this looks promising

Helm is already rich on:
- selected inputs,
- output claim posture,
- stable review slices,
- carried basis witnesses,
- and exact reentry cues.

A small action warrant looks like the cheapest way to keep strong shell actions honest without regressing into giant workflow products or invisible direct mutation.

It also unlocks a very Helm kind of magic:

**AI-assisted action that is still exact about what it is asking you to approve.**

## First proof-bearing specimen

A narrow specimen would likely be enough:

- one edit/apply warrant with exact affected-set summary
- one route/import warrant with inspect-before-adopt posture
- one drifted warrant that downgrades to review-again
- one privileged follow-on warrant that splits apply from approve-and-run

## Failure modes to avoid

- warrants that still hide the actual affected set
- old warrants that look permanently valid
- warrants that duplicate receipts without adding proposal truth
- warrants that quietly sit inside ordinary open/preview cards

## New pressure from rev0082

Action warrants increasingly want a **reach preview** nearby so the shell can show what the proposed stronger act would currently touch before review/approval.
They also want an **affected-set witness** that can later compare predicted touched set against observed aftermath.
