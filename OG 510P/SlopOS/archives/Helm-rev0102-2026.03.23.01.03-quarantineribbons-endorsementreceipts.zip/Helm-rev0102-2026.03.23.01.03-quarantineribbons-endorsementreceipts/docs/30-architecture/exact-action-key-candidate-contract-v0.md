# Exact action key candidate contract v0

Purpose: give Helm one fast path for **promoting exact shell actions** into hotkey-grade access without regressing into ambient shell-string macros.

An **exact action key** is a shell-owned promoted key binding that points at an exact typed subject, action, route, view, or entry artifact.

## Why this looks promising

Current tools keep validating the same idea:

- users love being able to promote a few common actions,
- but the good versions keep the action legible,
- and the bad versions decay into macro folklore or hidden power.

Helm can likely do better by making the promoted thing exact and typed from the start.

## Candidate posture

1. **The key points to an exact typed thing**
   - exact object jump
   - exact view summon
   - exact entry-kit launch ladder
   - exact review/apply harbor item
   - exact Omnibox/provider scope
   - exact route or action where that action already has a shell identity

2. **Promotion does not widen authority**
   - the key should do the same class of thing the owning lane already allows
   - if the action normally requires review, the key still lands in review
   - if the action is blocked or trust-ladder-limited, the key should show that honestly

3. **Keys should remain inspectable**
   - the shell should be able to show what a promoted key is bound to
   - promoted keys should not collapse into opaque macro strings or forgotten scripts

4. **The bound thing may be local-only**
   - some exact action keys may be device-local, setup-shaped, or intentionally unsynced
   - promotion should not imply shared continuity or team-wide truth

5. **Keys should compose with projection surfaces**
   - docks, sticky strips, and preview rails may advertise or mirror promoted exact keys
   - those surfaces still remain projection surfaces, not a second macro system

## Candidate uses

- summon one exact Omnibox scope
- jump to one exact object or saved view
- open one exact review strip or harbor item
- invoke one exact launch ladder for an activity entry kit
- run one exact Flow fragment or route card where the owning lane already allows it

## Guardrails

- no raw shell-string default substrate
- no invisible parameter filling from ambient state unless explicitly witnessed
- no authority widening just because the action now has a key
- no treating promoted local keys as global shared workflow truth by default

## First specimen worth proving

One good first specimen would be:

- promote one exact object jump,
- one exact Omnibox scope,
- and one review-first action,
- then show that the review-first action still lands in review instead of bypassing it.

## Working stance

Promotable exact action keys feel like one of the most exciting “super awesome” Helm moves because they combine speed with honesty. They should stay candidate-level until one specimen proves Helm can keep the power without importing macro folklore.
