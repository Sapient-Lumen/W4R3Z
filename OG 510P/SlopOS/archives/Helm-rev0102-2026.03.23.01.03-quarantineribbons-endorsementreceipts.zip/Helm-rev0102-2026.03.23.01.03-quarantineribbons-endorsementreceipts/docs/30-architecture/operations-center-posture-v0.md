# D-OPS Operations Center posture v0

Purpose: define Helm's operations surface as more than a classic process/task manager.

## Posture (v0)

1. **Operational truth over process theater**
   - windows, jobs, background presence, failures, resource use, grants, transfers, and automation sessions matter

2. **The Operations Center is shell-owned**
   - it reflects shell/compositor truth and explicit service state, not merely app self-reporting

3. **Authority must be legible**
   - if something can observe, inject, keep running, transfer authority-bearing payloads, or hold special access, users should be able to see that

4. **The Operations Center is part of daily use, not only emergencies**
   - it is how Helm stays honest under power-user workflows

5. **Continuity and exchange truth belong here too**
   - receipts, reentry posture, transfer sessions, holds, denials, and stale-vs-live state should be visible

7. **Delegated side work belongs here too when it exists**
   - shadow work lanes, adoption-ready harbor items, held candidate work, and rejected candidate work should stay visibly distinct rather than collapsing into one “assistant activity” row

## v0 must exist

- windows, jobs, background presence, flows/automation sessions, transfer sessions, and resource use
- visibility into grants / leases / special authority holdings
- visibility into delegated/background shadow work lanes and adoption-harbor items when they exist
- visibility into landing trains when ordered promotion or guarded-rung posture exists
- visibility into reversal warrants and repair ladders when a strong act later needs recovery-side truth
- receipts, denials, failures, continuity posture, and kill / suspend surfaces users can actually trust
- claim envelopes when operational summaries or recommendations need to keep observation, sourced evidence, helper-session output, and proposal posture separate

## Temptations to ban early

- a shallow process list standing in for system truth
- hiding automation, transfer, or grant state in separate debugging tools
- designing the Operations Center only for failure day instead of everyday operation

## Phase 1 non-goals

- being only a process list
- hiding automation or grant state in secondary tools

## Wiring

- decision surface: `decision-map.md` (D-OPS)
- related docs: `background-presence-posture-v0.md`, `desktop-flow-posture-v0.md`, `raw-automation-lane-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0005, I-HELM-0004

8. **Aftermath truth stays inspectable**
   - when a stronger shell act lands, Operations Center should be able to open an effect receipt rather than flattening the result into one transient success badge
   - when the act was partial, selective, or subset-repairable, Operations Center should be able to open the adjacent slot verdict ledger instead of hiding partiality in logs

9. **Recovery truth should stay adjacent to aftermath truth**
   - when an operator reopens a regretted or partial strong act, Operations Center should be able to open the nearby reversal warrant or repair ladder instead of hiding recovery under one vague Retry or Undo button

- current authority windows, grant rung, expiry posture, and nearby revoke handles should be inspectable without leaving the shell


- visibility into current reveal windows, expiring links, disabled public routes, and historical-only publication receipts when audience truth materially shapes risk or handoff


- cohort windows and minimization ladders should keep exact selected-slice truth visible where this surface would otherwise tempt Helm to widen from one chosen subset into one whole-family default.

## New pressure from rev0082

Operations Center now benefits from reach previews and affected-set witnesses beside mute, rerun, repair, apply, and reversal paths so operators can inspect current expected impact before promotion into stronger acts.
