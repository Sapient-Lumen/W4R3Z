# Landing train candidate contract v0

Purpose: give Helm one shell-owned object for **ordered or staged promotion into one exact authoritative lane** so multiple adoption-ready candidates do not flatten into isolated green-check folklore or hidden auto-merge behavior.

A **landing train** is a shell-owned ordered landing object bound to:
- one exact target lane or target subject
- one ordered set of promotion candidates
- one declared check / rebuild posture
- and optionally one guarded-promotion ladder

It is a candidate move, not a freeze.

## Candidate shape

A first useful landing train would likely include:
- landing-train id
- exact target-lane ref
- target basis stamp
- current queue order
- candidate entries, each with:
  - source ref (adoption-harbor item / receiver-fit landing / action-warrant-backed candidate)
  - candidate basis stamp
  - queue state (queued / checking / ready / paused / invalidated / removed / landed / aborted)
  - exact reason when blocked, invalidated, removed, or rebuilt
  - linked action warrant when strong promotion is being asked for
  - linked drift gate when reviewed basis may have moved
- declared check posture
- optional guarded-promotion ladder for one candidate or for the train's target class
- train actions (inspect / move to top when allowed / remove / pause / continue / abort / inspect receipts)
- resulting effect-receipt refs and slot-verdict-ledger refs when landings actually occur

## Candidate posture

### 1. Bound to one exact authoritative lane
A landing train should name one exact target lane.
Not a fuzzy area.
Not "production-ish."
Not "somewhere this probably belongs."

### 2. Queue truth stays visible
A candidate in a landing train should visibly admit:
- its current position,
- whether it has been rechecked,
- whether earlier queue changes forced a rebuild,
- whether it was invalidated,
- and whether it is paused or blocked.

The shell should not hide those facts behind one decorative ready badge.

### 3. A landing train is weaker than landed truth
Queued is not landed.
Checking is not landed.
Paused after rung one is not fully landed.
A landing train is promotion posture,
not aftermath truth.

### 4. Earlier queue changes matter to later candidates
If earlier queued candidates change the exact target basis,
later candidates should be rebuilt,
rechecked,
or downgraded visibly.
That is one of the main reasons the train exists.

### 5. Guarded promotion stays explicit
A landing train may optionally carry guarded promotion rungs.
For example:
- stage candidate in a weaker audience tier
- pause for review
- check watchpoint or analysis gate
- continue to stronger exposure
- abort and roll back

These rungs should remain explicit.
A partial guarded landing should not impersonate full authoritative landing.

### 6. The train is not a giant workflow engine
The train should stay small.
It is for:
- ordered promotion,
- revalidation truth,
- and optional guarded steps.

It should not turn into a universal automation platform.

### 7. The train should compose with existing Helm objects
A landing train should work naturally with:
- adoption harbors
- action warrants
- drift gates
- effect receipts
- slot verdict ledgers
- watchpoints
- attention windows when interruption posture matters
- and timeline markers when important queue changes deserve durable time witness

### 8. Imported or shared trains start weaker
Imported/shared train definitions should not silently bind receiver-local authority.
The receiver should inspect,
adopt,
and fit them explicitly.

## Guardrails

1. **Do not let landing trains become a giant CI/CD product inside Helm.**
2. **Do not let queued or staged posture impersonate landed truth.**
3. **Do not let reordering or invalidation stay hidden.**
4. **Do not let old review silently survive target-basis drift.**
5. **Do not let train membership become a hidden permission slip for stronger acts.**
6. **Do not let guarded promotion turn into vague progress theater without explicit pause/abort truth.**

## Good first specimens

- one adoption-harbor item queued to land on one exact shared workspace or live target lane
- one second queued item that is rebuilt because the first landing changed the basis
- one guarded landing with two rungs and a pause between them
- one aborted landing that leaves a durable effect receipt and explicit train history
- one Operations Center card that shows queue position,
  paused state,
  and the exact source/target refs without pretending the queue is the authority plane

## Working stance

Landing trains now look like the smallest honest answer to the question Helm still cannot answer cleanly enough after shadow lanes and adoption harbors:

**when several candidates aim at one live lane,
how does Helm keep order,
revalidation,
staged promotion,
and pause/abort truth visible without becoming a giant workflow religion?**
