# Projection card candidate contract v0

Purpose: define one compact shell-owned **bounded projection witness** for a single landing slot,
candidate,
or compared local target.

A **projection card** is the small sibling of an arrival overlay.
An arrival overlay is a richer compare surface.
A projection card is the tiny deterministic witness that makes one compared thing legible enough to choose,
rebind,
leave pending,
or refuse.

It should compose with:

- projection-surface posture
- arrival choice sets
- landing rehearsals
- arrival overlays
- basis stamps
- derivation strips
- surface core digests
- residue ledgers
- and slot verdict ledgers

## Why this move now

Helm now has enough landing machinery to expose a new problem.
There are many moments where the shell does not need a full compare view,
but it still needs more than a label and a fuzzy confidence badge.

SlopOS keeps teaching the right answer through CH-SPROJ:
make bounded deterministic non-authoritative projection a first-class witness.
Current tools reinforce the same posture with compare-with-workspace,
compare-changes,
and inspectable preview/import surfaces.

That makes Helm ready for one tiny compare witness.

## Candidate shape

A first useful projection card would likely include:

1. **Identity and owner witness**
   - owner surface id
   - slot id or candidate id
   - subject class
   - target class

2. **Basis witness**
   - basis stamp ref
   - surface core digest ref when relevant
   - compared-local target ref when relevant

3. **Tiny projection rows**
   - exact fields carried
   - omitted fields
   - inherited-eligible fields
   - current local fills when known
   - drift or mismatch flags when known

4. **Exactness posture**
   - exact
   - admissible-but-not-exact
   - pending-rebind
   - default-fill-possible
   - refused

5. **Tiny next actions**
   - inspect richer compare
   - choose candidate
   - open rebind ladder
   - leave pending
   - refuse

## Rules that matter

### 1. A projection card is bounded,
not a mini dashboard
It should stay small enough to help selection rather than becoming a second universal inspector.

### 2. A projection card is non-authoritative
It can help compare and choose.
It must not silently count as adoption,
fit,
or live truth.

### 3. Basis must stay inspectable
The card should always answer:
**what exact basis or compared target is this card about?**
Labels alone are not enough.

### 4. One card should represent one thing
One slot,
one candidate,
one exact target,
or one compared basis.
Do not make the first version summarize an entire landing.

### 5. The card should be cheap to carry and cheap to discard
Projection cards should be easy for the shell to generate on demand and easy to throw away when richer compare is opened.

## Best first homes

- one slot inside an arrival choice set
- one candidate inside a receiver fit card
- one dock-band landing target that needs exactness inspection
- one deck recipe slot where exact carried structure meets receiver-local fill or drift

## What this is not

- not a full arrival overlay
- not a hidden resolver
- not a proof of adoption
- not a durable live-state oracle
- not a dashboard tile empire

## A good first proof slice would show

- one incoming surface with two candidate targets,
- one projection card for each candidate,
- one projection card showing exact basis,
- and one resulting slot verdict after explicit choice.

## Why this seems worth keeping warm

Projection cards look like the smallest honest way to make bounded compare usable at shell speed.
They let Helm stay compact without regressing to vague winner-picking or giant import theater.
