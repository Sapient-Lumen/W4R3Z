# Minimization ladder candidate contract v0

Purpose: define one compact shell-owned chooser for **least-reach rungs** so Helm can start from an exact item or exact selected cohort and only widen to broader families by an explicit stronger step.

A **minimization ladder** sits beside cohort windows, authority windows, reveal windows, and action warrants.
It is the operator-facing move that keeps exact blast radius legible before the shell widens reach.

## Why this move now

Helm increasingly wants shell luxuries that could quietly sprawl if left implicit:
- ask over sources
- reveal/share/export
- route/apply actions
- helper proposals
- response-kit execution
- handoff packet creation
- evidence-brief generation

Authority windows already say **what power exists**.
Reveal windows already say **who can see what shape**.
What they do not yet say clearly enough is:
- whether the shell is using one item,
- one selected slice,
- one saved cohort,
- one activity cohort,
- or a whole provider/workspace family.

A minimization ladder is the UX move that makes that law legible.

## Candidate shape

A first useful minimization ladder would likely include these rungs:

1. **Exact item only**
   - one file
   - one object
   - one route
   - one card / row / result

2. **Current selected cohort**
   - current selected tabs/items/results/watchpoints
   - exact count visible

3. **Saved exact cohort / view slice**
   - one saved-view result slice
   - one saved cohort ref
   - one bounded patrol or brief input set

4. **Activity-local family**
   - one spine-local family
   - one project-local bounded family
   - still weaker than provider/account-wide reach

5. **Wider provider / account / workspace family**
   - only where the family should ever support it
   - explicit why / consequence / fallback posture

Not every family needs every rung.
Many should stop early.

## Rules that matter

### 1. Start narrow by default
If the shell already has one exact selected cohort,
that should usually be the default rung.

### 2. Broader reach needs a visible why
Useful reasons include:
- the feature genuinely needs the broader family
- provider cannot honor the narrow subset
- the operator explicitly chose broader reach
- the narrow cohort drifted and was reselected more broadly

### 3. Widening is not sticky by accident
A broaden-for-this-act step should not silently become the new durable default unless the operator promotes it deliberately.

### 4. Refusal is part of the ladder
Some families should simply refuse broader rungs.
That is a healthy product constraint,
not a missing feature.

### 5. Compose with receipts and windows
A stronger broaden step should be able to leave behind:
- one cohort window,
- nearby authority/reveal relation where relevant,
- and an explanation of why broader reach was used.

## Best first homes

- Exchange export / reveal / attach
- Omnibox ask / compare / strong quick action
- Recall compare / reopen / quote / handoff
- Operations Center repair or rerun flows where the failed subset should remain the default cohort
- helper or AI-driven plans that need to declare their exact working set before proposal or apply

## What this is not

- not a giant privacy console
- not a universal data-governance suite
- not a replacement for audience or grant choosers
