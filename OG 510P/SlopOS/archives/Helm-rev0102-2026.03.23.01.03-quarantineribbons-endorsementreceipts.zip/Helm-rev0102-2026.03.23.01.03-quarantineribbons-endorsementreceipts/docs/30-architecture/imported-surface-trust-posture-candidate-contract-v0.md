# Imported-surface trust posture candidate contract v0

Purpose: give Helm one small cross-cutting law for shell objects that arrive from somewhere else or whose local fit has not yet been earned.

This is **not** a new pillar.
It is a reusable shell contract intended to support Omnibox,
Object Browser,
Recall,
Exchange,
Operations Center,
and Desktop Flow.

## Why this exists

Helm increasingly wants portable or shared shell luxuries:
view objects,
decks,
flow fragments,
quicklinks,
launch recipes,
checkpoint-derived branches,
and other compact shell objects.

Those are valuable.
But many of them should not land wearing the full badge of ordinary local truth.

Helm therefore needs a standard weaker starting posture for imported,
shared,
rebased,
or otherwise not-yet-adopted shell surfaces.

## Contract

### Object kinds that may use this posture
- imported view objects
- shared view decks
- inbound flow fragments
- portable launch/session/layout recipes
- shared or published accelerators
- branched or checkpoint-derived surfaces whose live fit is not yet earned
- future shell luxuries with the same arrival problem

### Minimum visible states
1. **inspect-only**
   - the object can be viewed,
     previewed,
     and compared,
     but not yet exercise stronger local powers
2. **restricted**
   - the object may run only a bounded weaker action set
3. **fit-required**
   - the object needs local rebinding,
     provider choice,
     path selection,
     session selection,
     or another landing step
4. **adoptable**
   - the object has enough fit/provenance for a stronger user-controlled adoption step
5. **adopted**
   - the object has completed the stronger local step and can now participate as ordinary local shell truth within its allowed scope

## Required user-visible witnesses
- origin / route / sender / source posture
- a restricted / fit-required / adoptable badge or equivalent shell-owned cue near the imported surface
- carried core versus omitted local overlays where relevant
- what stronger powers are currently withheld
- what exact step would strengthen the posture
- whether adoption would preserve lineage,
fork,
or materialize a fresh local object

## Things this posture must not allow
- silent promotion to adopted/local truth
- silent widening from preview to execution/adoption
- imported share/publication counting as local activation
- hidden rebinding of path,
provider,
profile,
session,
or account context
- trust badges or “safe” icons that hide basis drift or missing fit work

## Cross-pillar effects
- **Omnibox**: imported results can still be found and previewed without overclaiming readiness
- **Object Browser**: shared/imported views and front doors can land honestly before activation
- **Recall**: historical or imported continuity objects do not pretend to be lived local continuity
- **Exchange**: received packets and routes stay weaker than local truth until adopted
- **Desktop Flow**: helper-produced or imported fragments stay inspectable before becoming live graph truth
- **Operations Center**: posture changes, publication/import activity, and blocked stronger actions become inspectable events rather than mysteries

## Early specimen ideas
- opening a shared view object from a teammate
- importing a deck recipe from another device
- branching from a checkpoint into a restricted exploratory lane
- receiving a shared dock item or action key that still needs local rebinding

## Judgment

This contract now looks worth proving soon because it prevents the exact class of lies that saved view objects and checkpoint branches would otherwise be tempted to tell.
