# Materialization bay candidate contract v0

Purpose: give Helm one explicit shell-owned place or workflow where a **view, preview, import, trail, or candidate** can become something stronger without smuggling the stronger workflow through the weaker one.

A **materialization bay** is where Helm turns a weaker or more derived thing into a stronger local or live thing by an explicit step.

It generalizes pressure that already exists across:

- preview rails
- launch ladders
- adoption harbors
- exact trails
- import/open-untrusted lessons from SlopOS
- and the fresh-identity / explicit-adoption discipline that keeps convenience from laundering authority

## Candidate posture

1. **A bay is a second workflow, not hidden side effect**
   - preview is not materialize
   - query view is not live attach
   - copied trail is not durable import
   - candidate work is not adopted truth

2. **Materialization should be typed and inspectable**
   - show the source witness
   - show the target form being proposed
   - show whether the result will be a fresh local object, a saved entry artifact, a live attachment, an adopted mutation, or another explicit shell effect

3. **Fresh identity should be the default when identity would otherwise blur**
   - equal bytes or nearby recency should not silently collapse provenance, quarantine, trust, or activity meaning
   - exact reattach/reuse/adopt can still exist, but it should be a named stronger rung

4. **Materialization should preserve lineage**
   - the shell should keep a visible relation from the new thing back to the source basis, preview, view, trail, or candidate item that produced it

5. **Bays should compose with existing Helm moves**
   - trust ladders
   - review strips
   - adoption harbors
   - launch ladders
   - exact action keys
   - view decks

## Candidate uses

- keep/export from a preview into a fresh local object
- promote one query result into a saved entry artifact or deck
- adopt a shadow-lane or harbor candidate into the live lane
- turn a copied exact trail into a pinned dock item or exact action key
- promote a compare/split/lens arrangement into a durable view deck

## Guardrails

- no hidden write-through from preview/query surfaces
- no equality-based alias laundering by default
- no silent path/docref/import authority minting merely because something opened successfully
- no silent live-lane mutation when the source was only candidate or preview truth
- no treating the bay as a generic dumping ground for every unresolved workflow

## First specimen worth proving

One good first specimen would be:

- a preview or harbor item,
- a visible “materialize” rung,
- a choice between fresh local object and stronger exact adopt/attach when applicable,
- clear provenance after materialization,
- and honest refusal when the stronger step is blocked.

## Working stance

Materialization bays look increasingly necessary because Helm already has many good weak or derived surfaces. The shell now needs an equally honest way to make something stronger without letting the weak surface bluff that it already did so.
