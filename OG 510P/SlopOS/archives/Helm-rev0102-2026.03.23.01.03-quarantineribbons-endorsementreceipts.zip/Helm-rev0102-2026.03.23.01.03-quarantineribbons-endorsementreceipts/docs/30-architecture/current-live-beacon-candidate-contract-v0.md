# Current-live beacon candidate contract v0

Purpose: define one compact shell-owned object that answers a narrow but important question:

**what is the actual live lane for this work right now?**

A **current-live beacon** is not:
- a recent item
- a saved starter
- a checkpoint
- a review ticket
- a grouped resource set
- or an activity spine

It is the shell's strongest compact cue for current live truth.

This is a candidate move, not a freeze.

## Candidate shape

A first useful beacon would likely include:

1. **Exact subject**
   - one exact shell-owned subject or lane reference
   - optionally one exact linked activity spine

2. **Currentness posture**
   - exact live
   - live but widened
   - historical relation only
   - imported/shared weaker relation
   - unknown / unavailable

3. **Scope and trust posture**
   - relevant scope axes that currently count
   - trust or restricted posture when important
   - explicit relation to a nearby activity scope witness if one exists

4. **Freshness witness**
   - last confirmed live time
   - last shell witness path
   - whether the shell still has a direct live hook or only remembered historical relation

5. **Reentry / inspect ladder**
   - bring forward / focus / reveal when supported
   - inspect current live basis
   - compare against saved starter or checkpoint
   - attach / continue
   - hold / repair when the beacon no longer supports strong reentry

6. **Nearby relation block**
   - preferred entry kit or front door
   - related saved view
   - related checkpoint/branch
   - recent receipt relation where helpful
   - but none of those become the beacon itself

## Guardrails

1. **Not generic recents with better badges**
   - a beacon must be stronger than launch history.

2. **No fake exactness**
   - if the shell only knows a historical relation,
     the beacon must admit that.

3. **No ambient scope inheritance**
   - nearby account/profile/session/provider glow should not silently count.
   - scope witness should carry that work when needed.

4. **No portability myth**
   - a beacon may point to imported/shared work,
     but that is not proof of identical local liveness.

5. **No second operations dashboard**
   - the beacon stays compact.
   - broad live inventory remains Operations Center territory.

## Why this looks promising

Helm now has many saved and grouped shell objects:
- saved view objects
- checkpoints
- review tickets
- activity spines
- resource shelves
- activity entry kits

That is excellent for reentry and organization.
But it increases one risk:
the shell can start sounding live even when it is only saved,
historical,
or imported.

A current-live beacon is the cheapest way to restore that honesty.

## First proof-bearing specimen

A narrow specimen would likely show:
- one activity spine
- one entry kit
- one current-live beacon
- one saved view nearby
- one checkpoint nearby
- one scope witness on an exact case
- one widened or unknown case that holds instead of bluffing

## Failure modes to avoid

- a stale beacon that still claims exact liveness
- provider-local recents quietly promoted into beacon status
- too much detail in the compact surface
- forcing every saved object to own a beacon
- treating imported/shared grouped work as identical to local current truth
