# Flow fragment candidate contract v0

Purpose: define one reusable inspectable fragment shape for Desktop Flow so Helm can steal the best of subflows/prefabs without turning reusable automation into opaque black boxes.

## What a fragment should be

A flow fragment is a named reusable graph unit with:

- typed inputs
- typed outputs
- an expandable internal body
- one compact status summary for each live instance
- provenance / version identity
- visible raw-lane usage when present

## Why this move matters

Desktop Flow only becomes first-class if reuse stays manageable.
Without fragments,
users either:
- copy graph chunks endlessly,
- hide logic inside opaque helpers,
- or retreat to raw scripts.

A shell-owned fragment move offers a middle path.

## Guardrails

- Fragments must stay inspectable;
  no opaque prefab black boxes.
- Fragment instances should surface status,
  hold,
  and failure without opening the whole graph first.
- Fragment reuse must not hide raw automation or ambient hook use.
- Fragment packaging must not outrun search,
  outline,
  and debug support.
- Do not invent a giant package manager before one small fragment family is useful.

## Good early specimen

A good first specimen would show:

- one fragment with typed input and output
- one visible status-bearing instance
- one expansion path into the body
- one hold or disable path
- and one proof that the fragment can be reused without copy-paste drift

## Nearby surfaces

- `desktop-flow-posture-v0.md`
- `flow-observability-posture-v0.md`
- `raw-automation-lane-posture-v0.md`
- `proof-slice-exact-object-reviewed-route-receipt-recall-v0.md`
