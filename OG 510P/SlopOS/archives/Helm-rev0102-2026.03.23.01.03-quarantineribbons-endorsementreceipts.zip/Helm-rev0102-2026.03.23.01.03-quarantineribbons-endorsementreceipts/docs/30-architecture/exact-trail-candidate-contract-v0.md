# Exact trail candidate contract v0

Purpose: give Helm one shell-wide way to expose **copyable exact orientation** across more than one pillar without pretending local convenience trails are universal truth.

An **exact trail** is a shell-owned typed trail to a subject, view, receipt, route, or reusable fragment.
It is stronger than a decorative breadcrumb.
It is weaker than live authority or live continuity proof.

## Why Helm likely wants this

Helm now has many surfaces where “where am I exactly?” matters:

- Omnibox results and provider scopes
- Object Browser queries and views
- Recall returns and receipts
- Exchange routes and transfer witnesses
- Operations Center job/harbor items
- Desktop Flow fragments and lineage

Without one compact trail move, the shell risks giving users lots of useful surfaces but weak exact orientation.

## Candidate posture

1. **Exact trails are typed and shell-owned**
   - they should identify what kind of trail this is: object, view, receipt, route, flow fragment, entry artifact, or similar
   - they should not fall back to vague titles or app-local hierarchy folklore when stronger shell truth exists

2. **Exact trails are promotable and copyable**
   - glanceable trail cues are nice
   - but the real win is being able to copy, pin, jump, or hand off the exact trail

3. **A trail is not automatically continuity proof**
   - a trail can show where a thing lives in shell truth
   - it does not by itself prove the thing is still live, trusted, adopted, or currently authoritative

4. **Trails should compose with projection surfaces**
   - preview rails, sticky strips, command docks, cockpit cards, and lenses may show compact trail cues
   - those cues remain projection surfaces over stronger shell truth

5. **Degradation must stay honest**
   - if an object disappears, a provider is disabled, or a receipt becomes historical-only, the trail should degrade visibly instead of bluffing a current live jump

## Candidate uses

- copy exact object trail from Recall or Object Browser
- show exact route/provider trail on a review strip or receipt card
- show exact flow-fragment trail in Desktop Flow and Operations Center
- pin one exact trail to a command dock or sticky strip
- export one exact trail into an entry kit, capsule, or harbor card

## Guardrails

- do not turn exact trails into a giant universal namespace constitution yet
- do not let decorative hierarchy impersonate shell-owned exactness
- do not let a trail quietly confer stronger authority than its owning lane
- do not flatten live, restored, historical, and unavailable postures into one cheerful jump

## First specimen worth proving

One good first specimen would be:

- an exact object trail visible in Object Browser,
- the same trail visible on a Recall card,
- copy trail / jump trail actions,
- and visible degradation when the object is no longer live.

## Working stance

Exact trails look increasingly like a high-value Helm move, but they should stay candidate-level until one cross-pillar specimen proves they improve exactness rather than merely adding chrome.
