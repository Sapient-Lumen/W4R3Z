# Exact-object recency candidate contract v0

Purpose: make Recall stronger than vague recent-files or shell-history folklore by centering recency on exact objects, exact reviewed actions, and route/receipt truth.

## What should count as a recent entry

Early candidate classes:

- exact objects recently viewed,
  revealed,
  selected,
  or reopened
- recent reviewed actions over exact objects
- recent route receipts and transfer receipts
- recent holds,
  denials,
  or drift notices worth returning to
- recent restored or repaired continuity paths,
  but only with visible posture labels

## Minimum entry payload

Each entry should be able to say:

- what the subject was
- whether the subject is still exact and currently live
- whether this entry is only a recent/opened hint or a real current-live reentry cue
- whether the entry is:
  - live,
  - restored,
  - historical,
  - request-only,
  - imported,
  - or delegated
- which action or route last made it relevant
- what honest next ladder remains now

## Why this move matters

Helm's Recall pillar will stay thin if it relies on:
- app recents,
- flat shell history,
- clipboard-like stacks,
- or generic activity nostalgia.

Exact-object recency gives Recall a better center of gravity:
recent things are not just “items I touched,”
but typed shell subjects with posture and next ladders.

## Guardrails

- Do not flatten historical and live entries together.
- Do not let provider-side or handler-side launch history silently become Recall authority.
- Do not let imported or delegated entries wear the operator's badge without a source label.
- Do not let a recent entry silently claim current exactness if the binding drifted.
- Strong next actions should still compose with review strips,
  basis packets,
  and witness cards where needed.

## Good early specimen

A good first specimen would include:

- one currently live exact object
- one historical receipt-backed object
- one repaired return
- one denied or hold-worthy recent action
- and one quick filter that groups by source / posture rather than only by app or file type

## Nearby surfaces

- `recall-posture-v0.md`
- `binding-witness-card-candidate-contract-v0.md`
- `continuity-choice-witness-candidate-contract-v0.md`
- `basis-packet-candidate-contract-v0.md`
- `proof-slice-exact-object-reviewed-route-receipt-recall-v0.md`
