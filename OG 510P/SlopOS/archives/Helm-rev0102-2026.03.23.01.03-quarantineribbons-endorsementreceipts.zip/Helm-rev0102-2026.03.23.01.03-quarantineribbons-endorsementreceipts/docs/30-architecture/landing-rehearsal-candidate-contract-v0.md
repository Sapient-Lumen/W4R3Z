# Landing rehearsal candidate contract v0

Purpose: define one compact shell-owned **try-before-adopt** surface so an imported,
saved,
or derived Helm object can be rendered on a receiver in a weaker local mode before it becomes adopted local truth.

A **landing rehearsal** is the receiver-local sibling of action rehearsal.
It should compose with:

- landing manifests
- anchor maps
- residue ledgers
- receiver fit cards
- rebind ladders
- portable cores
- local overlays
- deck recipes
- exact action keys
- and command dock items/bands

## Why this move now

Helm now has a fairly rich travel story.
It can talk about what traveled,
what stayed behind,
what must bind here,
and what may inherit local defaults.
What it still lacks is one explicit weaker state between **arrival** and **adoption**.

Current tools keep validating that missing middle:

- VS Code Profiles can be browsed,
  previewed in a new window,
  and imported explicitly
- drag-and-drop `.code-profile` import opens a preview/import editor rather than silently switching the active environment
- VS Code background agents can work in isolated worktrees and only later apply changes back into the main workspace
- Figma branch review lets reviewers compare branch changes against main before approval or merge

That combination strongly suggests that some Helm arrivals should be able to say:

**show me how this would live here before we call it live here.**

## Candidate shape

A first useful landing rehearsal would likely include:

1. **Owner surface witness**
   - handoff packet id
   - portable core id
   - exact action key id
   - deck recipe id
   - dock item/band id
   - or another admitted shell-owned owner

2. **Receiver-local rehearsal posture**
   - preview only
   - preview with inspect actions
   - preview with explicit adopt button
   - preview with explicit rebind actions
   - preview with refusal / hold path

3. **Visible carried truth**
   - landing manifest summary
   - basis stamp
   - anchor map
   - residue ledger summary
   - inherit mask summary when admitted

4. **Visible receiver-local provisionality**
   - this is not yet adopted
   - this may rely on provisional bindings
   - this may use temporary local specimen materialization
   - this may differ from the eventual adopted local shape

5. **Tiny next actions**
   - inspect carried structure
   - inspect near matches
   - open fit card
   - open rebind ladder
   - adopt as local specimen
   - reject landing

## Rules that matter

### 1. Landing rehearsal is weaker than adoption
Seeing a deck,
key,
dock band,
or entry kit rehearsed on the receiver should not count as adopting it.
The adoption step must remain explicit.

### 2. Landing rehearsal is receiver-local,
not shared truth
A rehearsal may use receiver-local layout,
windowing,
preview panes,
or specimen materialization.
That does not mean those local details traveled.

### 3. Rehearsal may reveal near matches without endorsing them
A rehearsal should be allowed to show similar candidates,
missing slots,
and likely substitutes.
But those remain weaker than adopted bindings.

### 4. Rehearsal should stay compact
The first version should not become a giant simulated desktop,
virtual machine,
or branch manager.
One compact specimen is enough.

### 5. Rehearsal should compose cleanly with fit and rebind
Landing rehearsal is not a substitute for fit cards or rebind ladders.
It is the surface that lets those stronger steps happen before adoption.

## Best first homes

- a deck recipe that can render a temporary view arrangement before adoption
- an exact action key that can show its target and arguments in a receiver-local specimen before pinning
- a dock band that can appear in a provisional dock strip before being added for real
- an entry kit that can stage its views and unresolved slots before local materialization

## What this is not

- not a second hidden desktop
- not a generic simulator
- not silent import
- not a substitute for adoption,
  fit,
  or rebind
- not proof that the rehearsed surface now exists as local durable truth

## A good first proof slice would show

- one portable surface landing into a provisional rehearsal window or strip,
- one exactly satisfied slot,
- one unresolved slot,
- one near-match candidate surfaced but not adopted,
- and one explicit adopt or reject path.

## Why this seems worth keeping warm

Landing rehearsal now looks like the missing humane step in Helm's truthful arrival story.
It makes travel and landing friendlier,
without flattening arrival into adoption.
