# Cross-cutting move catalog v0

Purpose: track strong non-pillar moves that should keep pressuring Helm without automatically becoming pillars.

## 0. Projection surfaces as a shared shell law

What they are:
- compact shell-owned derivative surfaces over already-legible shell truth
- a family that includes docks, rails, strips, lenses, cockpit cards, and exact trail cues

Guardrails:
- bounded and typed
- source-witnessed where that matters
- non-authoritative by default
- do not smuggle a second workflow or second truth-domain

Current state:
- frozen in `projection-surface-posture-v0.md`
- now acts as a cross-cutting law for several other warm moves

## 1. Preview as a shell power

What it is:
- shell-wide inspect-before-commit
- reusable across Object Browser, Omnibox, Recall, Exchange, and Operations Center

Guardrails:
- Preview is not silent open/launch/import/run
- provider identity and failures should remain visible
- Preview should not regress into app-local plugin clutter

Current state:
- candidate contract exists in `preview-candidate-contract-v0.md`
- still not promoted to pillar or full service family posture

## 2. Workspace/activity capsules

What they are:
- continuity objects that capture meaningful project/task state across the shell graph
- primarily a Recall/Tiling/Operations concern

Guardrails:
- exact / repaired / partial / unavailable honesty
- no false promise of carrying identity/account/cookie truth
- visible repair reasons when restore is imperfect

Current state:
- candidate contract exists in `workspace-capsule-candidate-contract-v0.md`


## 2a. Claim envelopes

What they are:
- shell-owned bounded result objects for asks, compares, diagnostics, route recommendations, and helper-produced summaries
- good for keeping observed, sourced, derived, remembered, proposed, and unresolved claims visibly different

Guardrails:
- grounding witness should be revealable without becoming authority
- save/share should preserve weakness, freshness, locality, and redaction posture
- do not become a giant provenance graph
- do not flatten citations into correctness proof

Current state:
- candidate contract exists in `claim-envelope-candidate-contract-v0.md`

## 2b. Reliance ladders

What they are:
- shell-owned bounded next-step rails next to claim envelopes
- good for making inspect basis, inspect sources, inspect helper-session witness, double-check, save weakly, quote/share, preview, adopt, and apply visibly different strengths

Guardrails:
- no single confidence slider standing in for all next moves
- no apply/adopt when only weak proposal posture exists
- no collapsing save/share into verified truth
- do not become a giant workflow wizard

Current state:
- candidate contract exists in `reliance-ladder-candidate-contract-v0.md`

## 2c. Freshness windows

What they are:
- shell-owned bounded freshness/decay objects over exact saved, derived, watched, remembered, or traveling shell surfaces
- good for keeping stale-but-usable, stale-if-error, expired, and unknown/unverifiable posture explicit instead of flattening everything into “updated”

Guardrails:
- freshness is local policy over exact object + exact basis, not a portable latest oracle
- served-stale posture stays visibly weaker
- revalidation rails and reasons stay explicit
- different surface forms can have different budgets without pretending every surface is live
- do not become a giant cache console or hidden background refresh plane

Current state:
- candidate contract exists in `freshness-window-candidate-contract-v0.md`; compact companions now exist in `freshness-horizon-chip-candidate-contract-v0.md` and `decay-rail-candidate-contract-v0.md`


## 2d. Authority windows

What they are:
- shell-owned bounded grant objects over one exact authority family, holder, subject, and rung
- good for keeping current-live grant truth, historical grant evidence, expiry posture, and nearby narrow/revoke controls explicit

Guardrails:
- historical evidence is weaker than current-live authority
- widening requires a fresh stronger step
- imported or traveled surfaces do not inherit local authority by magic
- isolated-lane alternatives can exist without implying the same power on the live lane
- do not become a giant IAM console or universal policy engine

Current state:
- candidate contract exists in `authority-window-candidate-contract-v0.md`

## 2daa. Elevation tickets

What they are:
- shell-owned bounded temporary-power tickets over one exact stronger-power family, holder, subject, and duration posture
- good for keeping eligible, requested, pending approval, active, and historical temporary power visibly different

Guardrails:
- eligibility is weaker than activation
- pending approval is not current grant truth
- reduced-scope activation should stay visible when chosen
- ticket / reason / extra-auth posture should remain inspectable
- do not become a giant enterprise workflow console

Current state:
- warmed in `docs/00-meta/helm-elevationtickets-deelevationrails-2026-03-22.md`
- candidate contract exists in `elevation-ticket-candidate-contract-v0.md`

## 2dab. De-elevation rails

What they are:
- shell-owned nearby rails for ending, narrowing, or dropping temporary stronger power early
- good for keeping end-now, narrow-now, drop-back-to-eligible, and inspect-history visibly different

Guardrails:
- timeout is not the only honest end path
- do not fake exactness when only coarse stop is available
- de-elevation is not identical to revoke or brake
- historical tickets are not live controls
- do not become a settings maze

Current state:
- warmed in `docs/00-meta/helm-elevationtickets-deelevationrails-2026-03-22.md`
- candidate contract exists in `de-elevation-rail-candidate-contract-v0.md`

## 2dac. Active-borrow beacons

What they are:
- shell-owned bounded on-air / hot-state witnesses over one exact active-use family
- good for keeping issued authority, borrowed-now authority, and actively-consuming-now truth visibly different

Guardrails:
- no stale historical receipt pretending to be hot now
- no fake exactness when the substrate only gives family-level signals
- no flattening borrowed-but-idle into on-air-now
- keep recent-use residue weaker than current hot-state truth
- do not become a giant privacy dashboard

Current state:
- warmed in `docs/00-meta/helm-livebeacons-brakerails-2026-03-22.md`
- candidate contract exists in `active-borrow-beacon-candidate-contract-v0.md`

## 2dab. Brake rails

What they are:
- shell-owned bounded nearby stop / pause / mute / narrow rails for exact active-borrow beacons
- good for keeping exact brake, coarse emergency brake, and escalate-to-manage posture visibly different

Guardrails:
- no fake exact stop when only coarse family-wide control exists
- no using historical receipts as live kill switches
- no silent broad side effects behind one tiny control
- keep the fuller revoke handle distinct
- do not become a giant settings center

Current state:
- warmed in `docs/00-meta/helm-livebeacons-brakerails-2026-03-22.md`
- candidate contract exists in `brake-rail-candidate-contract-v0.md`

## 2dacx. Intent sparks

What they are:
- shell-owned bounded fresh-intent witnesses over one exact trusted shell gesture or review lane
- good for keeping live fresh intent, spent intent, expired intent, and historical residue visibly different when stronger acts depend on what the user just meant now

Guardrails:
- spark is weaker than a grant
- expiry must degrade visibly
- consumption must stay honest for single-spend acts
- queueing, helpers, and replay must not silently launder a live spark
- do not become a giant click-history dashboard

Current state:
- warmed in `docs/00-meta/helm-intentsparks-gesturegates-2026-03-23.md`
- candidate contract exists in `intent-spark-candidate-contract-v0.md`

## 2dacy. Direct-gesture gates

What they are:
- shell-owned stricter gates for a narrower class of especially sensitive acts
- good for keeping “fresh spark is enough” visibly different from “this must happen inside the direct trusted gesture lane itself”

Guardrails:
- directness is stronger than freshness
- no helper laundering, queueing, or replay
- do not fake precise timers when the substrate only supports a direct-only rule
- refusal should point to the minimum next move that satisfies the gate
- do not become a giant modal doctrine

Current state:
- warmed in `docs/00-meta/helm-intentsparks-gesturegates-2026-03-23.md`
- candidate contract exists in `direct-gesture-gate-candidate-contract-v0.md`

## 2da. Access verdict cards

What they are:
- shell-owned bounded exact-act explanation objects
- good for keeping allowed, denied, restricted, stale, hidden-policy, unsupported, and unknown posture visibly different while revealing determining blocker class and visibility gaps when known

Guardrails:
- explanation stays weaker than authority
- hidden-policy or incomplete-visibility cases must stay explicit
- safe inspect rails remain nearby
- do not flatten simulated and live verdicts into one state
- do not become a giant policy center

Current state:
- candidate contract exists in `access-verdict-card-candidate-contract-v0.md`

## 2db. Least-widening previews

What they are:
- shell-owned bounded counterfactual comparison objects next to blocked or gated stronger acts
- good for comparing inspect-only, exact-subject, current-only, isolated-lane, guarded-link, activity-scoped, and broader persistent alternatives before widening

Guardrails:
- live and simulated truth stay visibly different
- no auto-apply of the narrowest candidate
- hidden-policy or runtime gaps must stay explicit
- do not bypass stale-basis, trust, or route blockers
- do not become a giant optimizer or policy language

Current state:
- candidate contract exists in `least-widening-preview-candidate-contract-v0.md`

## 2dc. Condition strips

What they are:
- shell-owned bounded typed status strips over one exact subject
- good for keeping ready, progressing, waiting, restricted, degraded, suspended, stale, muted, and teardown-requested posture visibly different without a giant status center

Guardrails:
- strips stay weaker than warrants, receipts, leases, and current-live beacons
- no silent inheritance from child surfaces
- do not let muted mean healthy or historical mean live
- do not hide basis age behind one flattering badge
- do not become a giant event feed

Current state:
- warmed in `docs/00-meta/helm-conditionstrips-observedbasis-2026-03-22.md`
- candidate contract exists in `condition-strip-candidate-contract-v0.md`

## 2dd. Observed-basis chips

What they are:
- shell-owned witness chips next to strips, verdicts, summaries, or recall cards
- good for keeping “observed on current basis,” “observed on older basis,” “historical only,” and “cannot compare to current” visibly different

Guardrails:
- chips are weaker than current-live truth
- do not turn vague recency into fake exactness
- do not hide the exact basis relation when it is known
- no giant version-vector constitution for v0
- do not silently repair old basis into new truth

Current state:
- warmed in `docs/00-meta/helm-conditionstrips-observedbasis-2026-03-22.md`
- candidate contract exists in `observed-basis-chip-candidate-contract-v0.md`

## 2de. Trusted chrome lanes

What they are:
- shell-owned bounded review lanes outside ordinary provider, app, or terminal content flow
- good for keeping grant / deny / protected follow-up / public reveal / stronger adoption surfaces visibly shell-owned

Guardrails:
- lane is not the durable receipt
- no fake app-owned security theater
- no silent widening from inspect to approve
- no giant modal or permission-center religion
- weak-origin requests stay visibly weaker than trusted chrome

Current state:
- warmed in `docs/00-meta/helm-trustedchrome-reviewlanes-2026-03-22.md`
- candidate contract exists in `trusted-chrome-lane-candidate-contract-v0.md`

## 2df. Host-effect witnesses

What they are:
- shell-owned compact witnesses for shell-side effects requested by weaker-origin surfaces
- good for keeping title changes, clipboard writes, link opens, stronger-review requests, and similar host effects visibly separate from already-authorized shell acts

Guardrails:
- witness is not authority
- allow, hold, downgrade, and deny stay visibly different
- decorative labels do not become exact identity
- no giant audit-studio ambition
- witnessed effects stay weaker than current-live truth

Current state:
- warmed in `docs/00-meta/helm-trustedchrome-reviewlanes-2026-03-22.md`
- candidate contract exists in `host-effect-witness-candidate-contract-v0.md`

## 2e. Grant-rung ladders

What they are:
- shell-owned humane choosers for authority duration / scope / isolation rungs
- good for keeping inspect, exact once, this ask, this activity, isolated-lane only, and persistent scope visibly different

Guardrails:
- the broadest rung should not be the cheerful default
- each rung must differ in a meaningful axis
- narrow/revoke stays nearby after grant
- drift or locality change can demote the best available rung
- do not become a scary settings wizard

Current state:
- candidate contract exists in `grant-rung-ladder-candidate-contract-v0.md`

## 2f. Revoke handles

What they are:
- shell-owned nearby live controls bound to one authority window or live grant family
- good for keeping revoke, suspend, narrow, and move-to-isolated-lane visibly different after issuance

Guardrails:
- current control requires current-live witness
- blast radius and residue must stay explicit
- suspend, narrow, and revoke are not one button
- revoked or narrowed grants should not silently regrow on retry
- do not become a giant permission center

Current state:
- candidate contract exists in `revoke-handle-candidate-contract-v0.md`


## 2g. Cohort windows

What they are:
- shell-owned bounded admitted-subject-set objects over one exact ask, reveal, export, route, or strong act
- good for keeping selected-slice truth visibly different from whole-provider or whole-workspace truth

Guardrails:
- exact cohort is weaker than whole-family truth
- loadout, authority, audience, and cohort remain distinct surfaces
- retry should not silently widen the cohort
- saved exactness should persist where possible even when live admission later expires
- do not become a giant governance suite or row-level-security religion

Current state:
- candidate contract exists in `cohort-window-candidate-contract-v0.md`

## 2h. Minimization ladders

What they are:
- shell-owned humane choosers for least-reach rungs
- good for keeping exact item, current selected cohort, saved cohort, activity-local family, and wider provider/workspace family visibly different strengths

Guardrails:
- start narrow by default
- broader reach needs a visible why
- broaden-for-this-act should not silently become the new durable default
- refusal is part of the ladder
- do not become a giant privacy console or governance studio

Current state:
- candidate contract exists in `minimization-ladder-candidate-contract-v0.md`

## 2i. Reach previews

What they are:
- shell-owned bounded pre-act expected-reach surfaces over one stronger reveal, export, mute, apply, rerun, or repair act
- good for keeping “what would this touch right now?” inspectable before the stronger rung lands

Guardrails:
- previewed reach is weaker than the act itself
- static exact sets and dynamic rule-derived sets must stay visibly different
- count-plus-drilldown is acceptable when full list would be noisy
- predicted reach and observed aftermath should remain comparable siblings
- do not become a giant blast-radius simulator

Current state:
- candidate contract exists in `reach-preview-candidate-contract-v0.md`

## 2j. Affected-set witnesses

What they are:
- shell-owned exact-or-counted touched-set witnesses that can attach to previews, warrants, windows, receipts, and repair surfaces
- good for keeping “who was in scope” from collapsing into vague prose or memory

Guardrails:
- predicted and observed sets should stay separable
- exact ids or grouped drilldown should remain nearby when practical
- historical touched-set truth is weaker than current-live truth
- do not grow into a universal lineage graph

Current state:
- candidate contract exists in `affected-set-witness-candidate-contract-v0.md`


## 2k. Exact remembered handles

What they are:
- shell-owned remembered access objects over one exact file,
  folder,
  service,
  route,
  or other reopenable subject where the host supports exact-handle memory
- good for keeping exact reopen/rebind posture visibly different from title/path nostalgia,
  nearby guesses,
  or historical-only memory

Guardrails:
- labels,
  paths,
  and thumbnails stay explicitly secondary
- current access,
  stale memory,
  repairability,
  and re-request posture stay visible
- exact remembered handles should not imply current-live activity or current authority on adjacent subjects
- do not become a giant universal object registry

Current state:
- warmed in `docs/00-meta/helm-exacthandles-sandboxgates-2026-03-22.md`
- not yet promoted to a candidate contract

## 2l. Constrained helper lanes

What they are:
- shell-owned bounded work lanes for helper,
  delegated,
  repair,
  or preparation work
- good for making stronger shell assistance possible without ambient tool or network reach

Guardrails:
- file/object bounds,
  network bounds,
  and allow/ask/deny posture stay visible
- outputs remain clearly proposal,
  preview,
  adoption-ready,
  or applied
- crossing the boundary should create an explicit escalation or denial,
  not silent reach growth
- do not become one magical agent mode for the whole shell

Current state:
- warmed in `docs/00-meta/helm-exacthandles-sandboxgates-2026-03-22.md`
- pressure also reinforced by shadow-work-lane and adoption-harbor work

## 2m. Protection gates

What they are:
- shell-owned named admission gates for materially stronger publish,
  apply,
  expose,
  or route-commit acts
- good for keeping proposal truth,
  gate truth,
  and final execution truth visibly separate

Guardrails:
- pending,
  passed,
  rejected,
  delayed,
  and expired gate posture should remain explicit
- reviewers,
  quiet windows,
  freshness checks,
  policy checks,
  and custom external checks should stay distinguishable
- gate success should not impersonate execution success
- do not become a giant CI/CD console for ordinary shell use

Current state:
- warmed in `docs/00-meta/helm-exacthandles-sandboxgates-2026-03-22.md`
- still not promoted to a candidate contract

## 2n. Pinned and floating handles

What they are:
- shell-owned handle posture objects that say whether one summon/reopen/share/act-now handle binds an exact reviewed or historical basis, or intentionally follows a mutable current target
- good for making current-following entry points and exact reviewed reentry visibly different instead of collapsing both into generic recents or generic links

Guardrails:
- pinned and floating must stay visibly different
- floating does not get to impersonate exact reviewed basis
- pinned does not get to bluff current-live freshness
- handle posture should remain smaller than a universal object registry
- do not collapse handle class, freshness, and authority into one badge

Current state:
- warmed in `docs/00-meta/helm-pinnedhandles-promotionrails-2026-03-22.md`
- not yet promoted to a candidate contract

## 2o. Promotion rails

What they are:
- shell-owned compact rails that keep rehearsal, compare, gate posture, promotion, refusal, and aftermath visibly different
- good for turning side work, imported candidates, preview objects, and helper proposals into real promotable shell surfaces without laundering them into live truth early

Guardrails:
- rehearsal remains weaker than promotion
- compare-before-promote should be nearby for materially stronger acts
- drift or failed gates must stay explicit
- refusal should leave the authoritative lane untouched
- do not turn ordinary shell use into giant deployment theater

Current state:
- warmed in `docs/00-meta/helm-pinnedhandles-promotionrails-2026-03-22.md`
- pressure also reinforced by landing rehearsals, shadow work lanes, adoption harbors, action warrants, and effect receipts

## 2p. Facet ownership cards

What they are:
- shell-owned compact conflict surfaces over one composite shell object and one contested facet or slot
- good for keeping user pins, imported recipes, helper proposals, receiver-local defaults, and derived weak fills from silently overwriting each other

Guardrails:
- only pay for this where conflicts actually matter
- keep owner, incoming actor, and takeover choice visible
- derived/default actors should remain weaker than authored explicit override unless the user transfers ownership deliberately
- historical ownership evidence is weaker than current authored state
- do not become a giant universal merge engine

Current state:
- warmed in `docs/00-meta/helm-pinnedhandles-promotionrails-2026-03-22.md`
- not yet promoted to a candidate contract

## 3. Overview

What it is:
- the spatial companion to Omnibox
- a quick glanceable shell-owned surface over workspaces/windows/focus/continuity cues

Guardrails:
- should render the same shell graph Omnibox and Operations Center rely on
- should not become a decorative mode disconnected from shell truth
- should retain strong keyboard/type-to-search paths

Current state:
- candidate contract exists in `overview-candidate-contract-v0.md`

## 3a. Glance derivations

What they are:
- tiny shell-owned derived summary objects over one exact saved view or review ticket
- good for Overview, Recall side cues, and bounded digest delivery

Guardrails:
- source witness stays visible
- freshness/expiry posture stays visible
- summary remains weaker than source view and current-live truth
- do not become a dashboard tile empire or hidden summary daemon

Current state:
- candidate contract exists in `glance-derivation-candidate-contract-v0.md`

## 3b. Watchpoints

What they are:
- shell-owned evaluated-state objects over one exact saved view
- good for Overview, Operations, and bounded alert/watch posture without using notification history as the durable record

Guardrails:
- evaluation posture and delivery posture stay separate
- source drift stays visible
- muted does not mean healthy
- disabled does not mean recovered
- do not become a hidden workflow engine or giant dashboard empire

Current state:
- candidate contract exists in `watchpoint-candidate-contract-v0.md`

## 3c. Patrol routes

What they are:
- shell-owned bounded revisit circuits over linked views, watchpoints, compare tickets, glance derivations, and exact front-door handles
- good for the repeated rounds people actually make without depending on memory, recents, or one giant Overview

Guardrails:
- the route is weaker than the stronger source objects it traverses
- shared route definition stays separate from personal resume/progress residue
- dynamic lanes stay bounded and source-witnessed
- do not silently choose profile/account/provider truth
- do not become a hidden workflow engine or giant dashboard empire

Current state:
- candidate contract exists in `patrol-route-candidate-contract-v0.md`

## 3d. Evidence briefs

What they are:
- shell-owned bounded curated-investigation objects over exact saved views, watchpoints, glances, review tickets, receipts, and handles
- good for manual or AI-assisted investigation, handoff, and post-incident curation without building a giant notebook or case engine

Guardrails:
- the brief stays weaker than the stronger source objects it gathers
- weak notes and summaries do not outrank the evidence lane
- authorship posture stays visible
- import/share posture stays weaker until explicit local adoption
- do not become a giant notebook empire or hidden workflow engine

Current state:
- candidate contract exists in `evidence-brief-candidate-contract-v0.md`

## 3e. Response kits

What they are:
- shell-owned bounded guided-response objects over exact source refs, instructional and automated steps, action affordances, preconditions, and visible outputs
- good for turning a watchpoint or evidence brief into exact next-step guidance without building a giant workflow engine or vague runbook lore

Guardrails:
- the kit stays weaker than the stronger source objects it leans on
- instructional steps and automated steps stay visibly different
- outputs and aftermath stay visible
- recommendation does not mean execution
- import/share posture stays weaker until explicit local adoption
- do not become a giant workflow-engine empire or silent automation law

Current state:
- candidate contract exists in `response-kit-candidate-contract-v0.md`

## 3f. Timeline markers

What they are:
- shell-owned bounded point-or-range time/change witness objects over exact saved views, watchpoints, receipts, imported change events, or authored notes
- good for recent-change context, causal breadcrumbs, brief evidence anchors, Recall cues, and weak Overview/ops time hints without building a giant timeline or event-bus authority plane

Guardrails:
- the marker stays weaker than the stronger source object it points at
- time proximity does not mean causal proof
- point and range posture both stay explicit
- scope posture stays explicit (local / activity / wider / imported)
- import/share posture stays weaker until explicit local adoption
- do not become giant timeline theater or annotation graffiti

Current state:
- candidate contract exists in `timeline-marker-candidate-contract-v0.md`


## 3g. Attention windows

What they are:
- shell-owned bounded quiet / active / maintenance / critical-only delivery posture objects over exact view subscriptions, watchpoints, patrol routes, or digest lanes
- good for keeping interruption governance explicit without turning quieting into fake recovery or provider-owned hidden settings

Guardrails:
- quiet does not mean healthy
- evaluation and delivery stay separate
- recurring windows and one-off silences stay visibly different
- critical-only remains a narrower reviewed rung
- import/share posture stays weaker until explicit local adoption
- do not become a giant inbox, scheduler, or hidden workflow engine

Current state:
- candidate contract exists in `attention-window-candidate-contract-v0.md`


## 2i. Quarantine ribbons

What they are:
- shell-owned compact arrival-risk witnesses over one exact source object, one exact derivative, or one bounded imported subject
- good for keeping origin evidence, quarantine/risk posture, safe-open-only posture, and endorsement-needed posture visibly different from ordinary trusted open/import folklore

Guardrails:
- arrival evidence is weaker than endorsement
- preview or safe-open must not silently clear the source object
- derivatives stay visibly different from sources
- recents and reopen should preserve the arrival story long enough to matter
- do not become a giant reputation console or path-trust religion

Current state:
- candidate contract exists in `quarantine-ribbon-candidate-contract-v0.md`

## 2j. Endorsement receipts

What they are:
- shell-owned durable historical admit/clear witnesses for one exact risky object, one exact derivative, or one bounded class
- good for keeping the stronger admit act visibly different from earlier preview, safe-open, or blocked posture

Guardrails:
- endorsement is exact unless it explicitly says otherwise
- source versus derivative endorsement must stay visible
- historical receipt is weaker than current-live authority
- later narrow / revoke / stale posture should not erase the original receipt
- do not become a giant trust registry or global allowlist studio

Current state:
- candidate contract exists in `endorsement-receipt-candidate-contract-v0.md`

## 3h. Effect receipts

What they are:
- shell-owned durable historical aftermath witnesses for one exact stronger act
- good for Operations, Recall, Exchange, and Desktop Flow once Helm has action warrants and drift gates on the pre-act side

Guardrails:
- historical effect truth stays separate from current-live truth
- bounded outcome vocabulary stays small
- changed-set or affected-set witness stays nearby
- receipt does not silently become universal completion proof
- do not become a giant job console or audit-warehouse religion

Current state:
- reheated in `docs/00-meta/helm-aftermathreceipts-slotledgers-2026-03-22.md`
- candidate contract exists in `effect-receipt-candidate-contract-v0.md`

## 3i. Slot verdict ledgers

What they are:
- shell-owned durable partial-outcome ledgers for selective landing, rebound, default fill, pending, refusal, and failed-subset posture
- good for keeping partial aftermath explicit when a whole-surface effect receipt would be too coarse

Guardrails:
- whole-surface success does not erase slotwise truth
- rebound and default-fill stay visibly different
- original verdict rows remain visible when later repair or rerun happens
- do not become a hidden merge engine or generic sync diff mythology

Current state:
- reheated in `docs/00-meta/helm-aftermathreceipts-slotledgers-2026-03-22.md`
- candidate contract exists in `slot-verdict-ledger-candidate-contract-v0.md`

## 3j. Landing trains

What they are:
- shell-owned ordered promotion objects for one exact authoritative lane
- good for keeping queue order, rebuild, invalidation, pause, and guarded-promotion truth visible when several candidates aim at one target

Guardrails:
- queued or staged posture does not impersonate landed truth
- earlier queue changes may force visible rebuild or invalidation for later candidates
- optional guarded promotion rungs stay explicit and abortable
- do not become a giant CI/CD platform or hidden workflow engine

Current state:
- candidate contract exists in `landing-train-candidate-contract-v0.md`

## 3k. Reversal warrants

What they are:
- shell-owned exact recovery-side proposal objects for one historical effect, checkpoint, or reviewed change
- good for keeping revert, restore-before, revoke, compensate, and reopen acts visibly distinct from vague Undo folklore

Guardrails:
- the reversal is a new reviewed act, not history erasure
- drifted targets must downgrade instead of silently widening
- blast radius stays explicit
- do not become a giant rollback religion

Current state:
- candidate contract exists in `reversal-warrant-candidate-contract-v0.md`

## 3l. Repair ladders

What they are:
- shell-owned bounded next-step ladders for aftermaths where reverse-all is not the only or best answer
- good for keeping redo, rerun-failed-subset, replay-on-fresh-basis, compensate, branch-and-fix, and hold visibly different

Guardrails:
- retry is too vague
- repair options should point back to exact historical effect truth
- do not promise universal reversibility
- do not become a giant incident manager or hidden self-healing plane

Current state:
- candidate contract exists in `repair-ladder-candidate-contract-v0.md`

## 4. Typed providers for Omnibox

What it is:
- provider-contributed matches, previews, snippets, quicklinks, routes, and actions over typed shell subjects

Guardrails:
- typed providers, not unrestricted shell-outs by default
- provider identity stays visible
- strong actions keep review/receipt pathways

Current state:
- this move is now narrow enough to be frozen in `omnibox-provider-posture-v0.md`

## 5. Flow observability and reusable fragments

What it is:
- event/debug lane
- graph outline/search
- node status
- reusable inspectable fragments

Guardrails:
- no “pretty canvas now, tooling later” trap
- packaged fragments remain inspectable locally
- review gates stay visible

Current state:
- this move is now narrow enough to be frozen in `flow-observability-posture-v0.md`

## 6. Plumbing-grade route inspection

What it is:
- typed, inspectable action routing across Exchange, Omnibox, and shell-visible object actions

Guardrails:
- no silent helper magic
- exact subject and route witness remain visible

Current state:
- still pressure spread across Exchange, handler routing, and shell-facing route surfaces

## 7. Visual layout/template editing

What it is:
- a shell-owned spatial template editor inside Tiling Shell

Guardrails:
- do not regress into a separate zone-manager worldview
- layout templates should compose with Recall and capsules rather than sit beside them

Current state:
- still research pressure only

## 8. Breadcrumb / outline / timeline cues

What they are:
- multiple scales of continuity and orientation across Object Browser, Recall, Overview, and maybe Flow

Guardrails:
- do not trap these as app-local editor tricks
- do not confuse helpful local trails with universal truth

Current state:
- still research pressure only, but stronger than before


## 9. Live lenses / derivative surfaces

What they are:
- shell-owned cropped or mirrored live surfaces derived from another exact surface

Guardrails:
- derivative provenance stays visible
- no silent input forwarding by default
- no hidden capture-channel backdoor

Current state:
- candidate contract exists in `live-lens-candidate-contract-v0.md`

## 10. Snippet / quicklink / placeholder seeds

What they are:
- small reusable personal accelerators that expand into typed inserts, routes, review cards, or Flow entrypoints

Guardrails:
- no raw shell-string default substrate
- no hidden scraping to satisfy placeholders
- strong actions still compose with review/receipt pathways

Current state:
- candidate contract exists in `snippet-seed-candidate-contract-v0.md`

## 11. Provider visibility grades and richer result payloads

What they are:
- typed provider payloads richer than flat list items
- root-visible vs scoped-only vs disabled-until-enabled provider surfaces

Guardrails:
- no hidden provider state machines the shell cannot inspect
- do not flood root search with every provider capability by default

Current state:
- still pressure on Omnibox provider design; partially reflected in `omnibox-provider-posture-v0.md`


## 12. Action rehearsal / route cards

What they are:
- shell-owned preflight cards for strong actions, routes, restores, or Flow entrypoints

Guardrails:
- no fake determinism
- no bypass of review/receipt pathways
- uncertainty class stays visible

Current state:
- candidate contract exists in `action-rehearsal-candidate-contract-v0.md`

## 13. Capsule diffs

What they are:
- shell-owned comparisons between live state, selected capsules, and restore receipts

Guardrails:
- do not flatten repaired / partial / unavailable into generic success
- do not pretend app-local memory is shell truth

Current state:
- candidate contract exists in `capsule-diff-candidate-contract-v0.md`

## 14. Layout templates with rebinding

What they are:
- shell-owned spatial templates with named slots, anchors, and rebinding rules

Guardrails:
- do not split into a separate zone-manager worldview
- do not rely primarily on title-matching folklore
- do not hide rebinding decisions

Current state:
- candidate contract exists in `layout-template-candidate-contract-v0.md`

## 15. Activity cockpit cards

What they are:
- shell-owned front doors for named activities
- compact cards that combine live status, continuity relation, layout relation, recent receipts, and next actions

Guardrails:
- do not become a new pillar
- do not turn into arbitrary embedded app dashboards
- keep request-vs-live truth explicit

Current state:
- candidate contract exists in `activity-cockpit-candidate-contract-v0.md`


## 16. Activity entry kits

What they are:
- shell-owned saved front-door starters for one scoped activity
- compact objects that can link an activity spine, one preferred front door, nearby shelves/views/starters, continuity hints, and an honest entry ladder

Guardrails:
- not live-state claims
- not the activity spine itself
- not the resource shelf itself
- no hidden target choice for remote/profile/account-like destinations
- no silent strong action on select/open
- no auto-generation from recents/open folklore
- do not become a giant workspace bureaucracy

Current state:
- candidate contract exists in `activity-entry-kit-candidate-contract-v0.md`

## 17. Continuity choice witnesses

What they are:
- shell-owned tiny witness strips/cards for proposer / chooser / executor posture during repaired, widened, switched, reused, or delegated continuity

Guardrails:
- do not become a giant autonomy bureaucracy
- do not launder shell/agent/app policy behavior into operator authorship
- only show up where a substitute path or handoff really matters

Current state:
- candidate contract exists in `continuity-choice-witness-candidate-contract-v0.md`


## 17. Binding witness cards

### What they are

Shell-owned continuity cards that explain how a saved or planned subject joins to a current live target.
They should make exact, repaired, ambiguous, and unavailable outcomes legible without creating a giant restore bureaucracy.

### Guardrails

- do not hide the join basis behind a flattering badge
- do not turn repaired and ambiguous matches into exact by wording only
- do not let witness cards become a universal matching engine or giant workspace manager
- do not let remote/profile/account/session-like rebinding disappear just because it feels convenient

### Current state

Candidate contract exists in `binding-witness-card-candidate-contract-v0.md`.


## 18. Activity scope witnesses

### What they are

Small shell-owned witness strips/cards that say which axes counted for a same-activity claim and which nearby ambient context stayed out.
They should pair well with entry kits, cockpit cards, binding witnesses, capsule diffs, and Recall cues.

### Guardrails

- do not become a giant scope ontology or project-management dashboard
- do not hide the actual included/excluded axes behind generic badges
- do not let widened or operator-switched scope collapse into exact-scoped wording
- do not force every surface to show scope machinery when no continuity claim is being made

### Current state

Candidate contract exists in `activity-scope-witness-candidate-contract-v0.md`.


## 19. Basis packets

### What they are

Small shell-owned witness strips/cards that say what exact reviewed basis a stronger action still depends on,
whether that basis still matches,
and which honest next ladder remains.

### Guardrails

- do not become a giant approval cache or permission dashboard
- do not pretend saved or historical objects stay forever review-valid
- do not hide stale-basis drift behind smoother wording
- do not force every low-risk action to carry full basis machinery

### Current state

Candidate contract exists in `basis-packet-candidate-contract-v0.md`.

## 20. Shadow work lanes

### What they are

Small shell-owned isolated mutable side lanes for delegated, background, helper, or repair work.
They keep candidate work powerful and inspectable while preserving one authoritative live lane until adoption.

### Guardrails

- do not become a giant branch manager or hidden second workspace religion
- do not auto-merge candidate work into the live lane
- do not pretend isolation removes the need for basis, conflict, or authorship truth
- do not force trivial harmless suggestions into heavyweight ceremony

### Current state

Candidate contract exists in `shadow-work-lane-candidate-contract-v0.md`.


## 19. Review strips

### What they are

Tiny shell-owned preflight strips/cards that can show subject, action family, route/provider, basis posture, and readiness without expanding into a giant review product by default.

### Guardrails

- do not hide provider or route identity
- do not execute on appearance
- do not flatten request, basis, route, and live result into one success-shaped badge
- compose with witness cards and basis packets instead of replacing them

### Current state

Candidate contract exists in `review-strip-candidate-contract-v0.md`.

## 20. Exact-object recency

### What it is

A Recall direction centered on exact objects, reviewed actions, route receipts, holds, and denials with explicit source labels such as live, restored, historical, request-only, imported, or delegated.

### Guardrails

- do not flatten historical and live entries together
- do not let delegated/imported entries wear the operator badge without source labels
- do not silently claim current exactness when bindings drifted

### Current state

Candidate contract exists in `exact-object-recency-candidate-contract-v0.md`.

## 21. Reusable flow fragments

### What they are

Reusable status-bearing graph units with typed inputs/outputs, expandable bodies, provenance, and visible raw-lane usage.

### Guardrails

- no opaque prefab black boxes
- no hidden raw automation or ambient hook use
- no package-manager sprawl before one compact fragment family is useful
- status, hold, and failure must stay visible on instances

### Current state

Candidate contract exists in `flow-fragment-candidate-contract-v0.md`.


## 17. Launch ladders

What they are:
- shell-owned next-step ladders for saved entry objects, recent objects, and reviewed actions
- compact distinction between inspect, fresh launch, attach, reuse, repaired return, historical replay, and hold

Guardrails:
- do not treat launch ladders as proof of live continuity
- do not smuggle generic placement or reuse folklore into one more launch flag
- stronger rungs still compose with review, basis, route, and receipt law

Current state:
- candidate contract exists in `launch-ladder-candidate-contract-v0.md`

## 18. Sticky context strips

What they are:
- shell-owned tiny anchor strips/cards for long-lived output, result panes, route status, receipts, or historical context
- reusable source/action/subject anchors rather than raw scroll-position aids

Guardrails:
- descriptive, not approving
- source grades remain visible
- expand into evidence rather than vibes

Current state:
- candidate contract exists in `sticky-context-strip-candidate-contract-v0.md`

## 24. Preview rails

What they are:
- compact bounded next-step rails next to shell-owned preview
- a way to keep inspect and stronger action adjacent but distinct

Guardrails:
- preview stays weaker than open/attach/import/run
- stronger actions still compose with review, route witness, and receipts
- source grade and preview strength stay visible

Current state:
- candidate contract exists in `preview-rail-candidate-contract-v0.md`

## 25. Facet strips

What they are:
- compact typed pivot rows for search, summon, recency, or transfer surfaces
- a way to pivot between objects, actions, routes, receipts, transfers, or spatial families without building separate products

Guardrails:
- do not promote facets into new pillars
- keep keyboard/type-to-search flow strong
- use stable shell-level families rather than provider spam

Current state:
- candidate contract exists in `facet-strip-candidate-contract-v0.md`

## 17. Command docks

What they are:
- tiny persistent shell-owned command/status edges
- a compact place for exact pins, launch objects, harbor cues, or live-return slots

Guardrails:
- do not become a second launcher constitution
- do not outrun review, receipts, or typed shell law
- keep the visible law shell-owned rather than provider-sprawled

Current state:
- candidate contract exists in `command-dock-candidate-contract-v0.md`

## 18. Adoption harbors

What they are:
- compact review/apply surfaces for delegated, background, repair, or shadow-lane candidate work
- a shell-owned place where candidate work can be inspected before adoption into live truth

Guardrails:
- not AI-only
- no silent auto-merge mythology
- drift and basis posture must stay visible

Current state:
- candidate contract exists in `adoption-harbor-candidate-contract-v0.md` and is now re-promoted as the next compact adoption proof for delegated/background side work


## 20. Exact trails

What they are:
- shell-owned exact typed trails to objects, views, receipts, routes, or flow fragments
- stronger than decorative breadcrumbs, weaker than live authority or continuity proof

Guardrails:
- copyable and jumpable, not merely glanceable
- do not let decorative hierarchy impersonate exact shell truth
- do not let trail visibility flatten live, restored, historical, and unavailable posture

Current state:
- candidate contract exists in `exact-trail-candidate-contract-v0.md`

## 21. Trust ladders

What they are:
- compact shell-owned posture ladders for inspect-only, preview-safe, review-first, adopt/apply, trusted, or blocked states

Guardrails:
- keep the first cut small
- scope trust narrowly
- do not let fast surfaces outrun the current ladder rung

Current state:
- candidate contract exists in `trust-ladder-candidate-contract-v0.md`

## 22. Exact action keys

What they are:
- promoted hotkey-grade bindings to exact typed shell actions, objects, routes, views, or entry artifacts

Guardrails:
- no raw shell-string macro default
- promotion does not widen authority
- some keys may stay local-only or intentionally unsynced

Current state:
- candidate contract exists in `exact-action-key-candidate-contract-v0.md`


## 23. View decks

What they are:
- shell-owned named sets of explicit views over one stronger subject family, activity relation, or query basis
- a way to pivot among query, ops, receipt, transfer, recency, and lens-like views without dashboard drift

Guardrails:
- do not become a second workspace system
- do not flatten member types into one generic tile wall
- do not auto-activate stale or remote state just because the deck still exists

Current state:
- candidate contract exists in `view-deck-candidate-contract-v0.md`

## 24. Materialization bays

What they are:
- explicit shell-owned places or workflows where weaker or derived surfaces can become stronger local or live things
- a way to keep preview/query/import/candidate surfaces honest while still offering satisfying next steps

Guardrails:
- no hidden write-through from preview/query surfaces
- no equality-based alias laundering by default
- no silent live-lane mutation when the source was only candidate or preview truth

Current state:
- candidate contract exists in `materialization-bay-candidate-contract-v0.md`


## 26. Surface locality tiers

What they are:
- a compact way to say whether a shell luxury is personal/local, activity-local, portable, or shared
- a promotion ladder rather than an ambient sync assumption

Guardrails:
- local-first by default for many accelerators
- explicit promotion between tiers
- do not let local mutable setup impersonate portable truth
- do not auto-share trust decisions, sensitive histories, or profile-shaped conveniences

Current state:
- candidate contract exists in `surface-locality-candidate-contract-v0.md`


## 27. Drift beacons

What they are:
- compact shell-owned change-aware cards, strips, or badges
- a way to compare one exact current subject against one exact reviewed, adopted, or remembered basis

Guardrails:
- do not become a giant timeline or event-log product
- do not let changed-since badges impersonate current authority
- keep the compared basis explicit
- inspect / compare / review-again should outrank decorative reassurance

Current state:
- candidate contract exists in `drift-beacon-candidate-contract-v0.md`

## 28. Deck recipes

What they are:
- shell-owned typed saved starters that can materialize a deck or deck-like cluster around one subject family, activity relation, or query basis
- a reusable arrangement intent, not live continuity proof

Guardrails:
- do not become a second workspace constitution
- do not let recipes auto-reactivate stale or remote state
- keep locality tier visible
- keep materialization explicit

Current state:
- candidate contract exists in `deck-recipe-candidate-contract-v0.md`

## 29. Derivation strips

What they are:
- compact shell-owned witness strips or headers for derived surfaces
- a way to keep source, basis, recipe, and locality visible on lenses, decks, beacons, and other projection surfaces

Guardrails:
- do not become a giant inspector on every surface
- do not let a derivation badge impersonate stronger authority
- keep inspect / compare / materialize stronger than decorative reassurance

Current state:
- candidate contract exists in `derivation-strip-candidate-contract-v0.md`

## 30. Publication ladders

What they are:
- compact shell-owned ladders for moving a surface across locality tiers
- a way to keep export/share/publish behavior explicit instead of ambient sync folklore

Guardrails:
- publication is not activation
- not every surface should be allowed to travel
- the audience / permission delta should stay visible
- receiver-side materialization should remain explicit where needed

Current state:
- candidate contract exists in `publication-ladder-candidate-contract-v0.md`


## 31. Handoff packets

### What they are

Portable shell-owned packets for deck recipes, exact action keys, dock items, entry kits, briefs, kits, and related luxuries that need to travel across tiers without pretending the receiver already has live local state.

### Guardrails

- travel is not activation
- packetization should preserve exact source, basis, and locality witness when those matter
- some families should still refuse packetization
- packet travel should compose with fit cards, rebind ladders, and materialization bays rather than replacing them

### Current state

Candidate contract exists in `handoff-packet-candidate-contract-v0.md`.

## 32. Receiver fit cards

### What they are

Compact receiver-side landing cards that tell the truth about what matched locally, what was intentionally not carried because it belongs to the receiver, and what still needs an explicit choice before rebind, materialize, or adopt.

### Guardrails

- fit is not activation
- do not silently choose provider, profile, account, session, or placement just to make the landing feel magical
- refusal and inspect-only posture are valid outcomes
- fit should stay weaker than rebind, materialize, or adopt

### Current state

Candidate contract exists in `receiver-fit-card-candidate-contract-v0.md`.

## 33. Basis stamps

### What they are

Compact shell-owned exact-basis witnesses that let a derived, traveling, reviewed, or published shell surface say what exact source, revision, checkpoint, query, or prior reviewed state it reflects.

### Guardrails

- a basis stamp is not current-live proof
- a basis stamp is not receiver fit, trust, or activation
- descriptive labels must not replace the exact machine witness when exactness matters
- stronger acts should refuse silent drift rather than silently rebasing onto a newer mutable head

### Current state

Candidate contract exists in `basis-stamp-candidate-contract-v0.md`.

## 34. Promotion receipts

Compact shell-owned durable witnesses for export/share/publish moves that record what crossed tiers, for whom, under what restrictions, and what still needs to happen on the receiver side.


## 35. Landing rehearsals

### What they are

Receiver-local try-before-adopt surfaces for imported, saved, or derived shell luxuries.
They let Helm render what a landing could look like here before that landing becomes adopted local truth.

### Guardrails

- do not let rehearsal count as adoption
- do not turn rehearsal into a giant simulated desktop before one compact specimen exists
- keep carried truth and receiver-local provisionality separately visible
- compose with fit cards and rebind ladders rather than replacing them

### Current state

Candidate contract exists in `landing-rehearsal-candidate-contract-v0.md`.

## 36. Near-match fences

### What they are

Exactness guards that let Helm surface similar local candidates when an expected binding is missing, without quietly laundering those candidates into exact success.

### Guardrails

- do not auto-select the top-ranked candidate and call it exact
- keep mismatch reasons typed and inspectable
- compose with landing rehearsals and rebind ladders
- do not grow into a giant universal diff engine before a compact specimen exists

### Current state

Candidate contract exists in `near-match-fence-candidate-contract-v0.md`.


## 16. Lineage modes

What they are:
- explicit shell-owned cross-boundary identity choices
- preserve-lineage versus fork-as-copy versus fresh starter-instantiation

Guardrails:
- no silent relinking
- no flattering “same thing” claim by default
- should compose with fit, rebind, slot verdict, and portability law rather than erase them

Current state:
- candidate contract exists in `lineage-mode-candidate-contract-v0.md`

## 17. Fork receipts

What they are:
- compact durable witnesses that a new shell surface was created from an older one while severing same-object continuity
- ancestry without fake sameness

Guardrails:
- carry/reset/omitted classes stay explicit
- receiver-local fills remain visible
- not a global version-control system for every shell surface

Current state:
- candidate contract exists in `fork-receipt-candidate-contract-v0.md`


## 41. Review tickets

What they are:
- compact shell-owned stable-enough review slices
- bounded objects for compare, paging, route inspection, checkpoint review, or handoff

Guardrails:
- do not let tickets impersonate live truth
- do not let tickets become the hidden universal object model
- keep basis, cut time, and freshness/expiry posture visible

Current state:
- candidate contract exists in `review-ticket-candidate-contract-v0.md`

## 42. Three-form law

What it is:
- one shell-wide distinction between recipe/definition, ticket/snapshot/stable review slice, and live instance/current lane

Guardrails:
- do not let recipes impersonate live continuity
- do not let tickets impersonate current liveness
- do not let “latest” folklore silently choose the strongest form

Current state:
- currently an explicit design-law synthesis in `docs/00-meta/helm-three-form-law-2026-03-22.md`

## 16. Activity spines

What they are:
- shell-owned scoped work objects that gather saved views, checkpoints, quick actions, launch/layout starters, and one current-live beacon for a named piece of work
- a work frame, not the live lane itself

Guardrails:
- explicit scope and memory fence
- no auto-enrollment from open/recent/share side effects
- no giant workspace-portability mythology
- sharing may tighten boundaries rather than widen them

Current state:
- candidate contract exists in `activity-spine-candidate-contract-v0.md`


## 43. Effect receipts

What they are:
- compact shell-owned durable aftermath witnesses for stronger acts
- exact post-act siblings of action warrants

Guardrails:
- do not let historical effect receipts impersonate current-live truth
- do not flatten partial effects into one green success badge
- keep undo / redo / compare-to-current paths explicit
- do not grow into a universal task-status bureaucracy before one specimen exists

Current state:
- reheated in `docs/00-meta/helm-aftermathreceipts-slotledgers-2026-03-22.md`
- candidate contract exists in `effect-receipt-candidate-contract-v0.md`

## 44. Slot verdict ledgers

What they are:
- durable shell-owned per-slot aftermath ledgers for selective landing,
  rebind,
  default fill,
  pending,
  refusal,
  and drop-by-choice outcomes
- the partial-outcome sibling of effect receipts

Guardrails:
- do not hide partiality under whole-surface success folklore
- keep rebound and default-filled distinct
- do not become a giant sync diff or merge engine
- first proof should stay on one small landing family

Current state:
- reheated in `docs/00-meta/helm-aftermathreceipts-slotledgers-2026-03-22.md`
- candidate contract exists in `slot-verdict-ledger-candidate-contract-v0.md`


## 45. Action warrants

### What they are

Compact shell-owned exact proposed-change objects for one stronger act.
They carry exact subject, exact proposed effect, exact reviewed basis, affected-set witness, and the honest next-step ladder before anything becomes live truth.

### Guardrails

- do not let every tiny click become warrant theater
- keep warrants pre-act rather than receipt-shaped
- do not hide affected-set truth behind confidence badges
- do not silently follow drifted basis onto the newest mutable head

### Current state

Candidate contract exists in `action-warrant-candidate-contract-v0.md`.

## 46. Drift gates

### What they are

Compact shell-owned comparison gates that sit beside action warrants and answer whether the reviewed basis still binds strongly enough to proceed.

### Guardrails

- do not make drift gates a giant policy engine
- explain what changed, not only that something changed
- do not treat a previous successful gate as evergreen approval
- keep override posture visibly stronger than ordinary proceed

### Current state

Candidate contract exists in `drift-gate-candidate-contract-v0.md`.


## 47. Reversal warrants

### What they are

Compact shell-owned recovery-side proposal objects for one historical effect, checkpoint, or reviewed change. They let Helm say exactly what is being reversed, restored, revoked, or compensated before any stronger recovery act happens.

### Guardrails

- do not let reversal masquerade as history erasure
- keep blast radius visible
- if drift blocks exact reversal, downgrade to inspect / compare / repair rather than silently widen
- do not grow into a universal rollback court

### Current state

Candidate contract exists in `reversal-warrant-candidate-contract-v0.md`.

## 48. Repair ladders

### What they are

Compact shell-owned recovery-side next-step ladders for partial, regretted, or drifted aftermaths. They keep redo, rerun-failed-subset, replay-on-fresh-basis, reverse-all, compensate, branch-and-fix, and hold visibly different.

### Guardrails

- do not flatten every recovery move into “retry”
- keep exact source effect witness nearby
- do not promise universal reversibility
- do not become a giant incident-management bureaucracy

### Current state

Candidate contract exists in `repair-ladder-candidate-contract-v0.md`.


## 37. Reveal windows

### What they are

Compact shell-owned bounded visibility objects that say what exact audience relation exists or recently existed, by what route, in what reveal shape, under what expiry/policy posture, and with what current-live versus historical truth.

### Guardrails

- historical publish/share is not current audience truth
- named, org-only, guarded-link, public, and bearer routes should stay visibly different
- preview / summary / redacted reveal should not silently widen into full reveal
- reveal windows should compose with publication ladders and promotion receipts rather than replacing them

### Current state

Candidate contract exists in `reveal-window-candidate-contract-v0.md`.

## 38. Audience ladders

### What they are

Compact shell-owned humane choosers for local-only, named, org/workspace, guarded-link, and public/time-boxed reveal so stronger visibility acts stop collapsing into one generic Share state.

### Guardrails

- audience choice is not activation
- not every family should allow every rung
- route class and reveal shape belong on the ladder
- public/bearer rungs should often be shorter-lived or more guarded than named-collaborator posture

### Current state

Candidate contract exists in `audience-ladder-candidate-contract-v0.md`.

## 2m. Generation cards

What they are:
- shell-owned exact-history objects over one materially changing saved shell surface
- good for keeping current generation, prior generation, compare posture, rollback posture, and retention class visibly different

Guardrails:
- current-live truth is still stronger than generation history
- floating aliases should stay visibly different from exact generations
- rollback is a stronger act than inspect or compare
- pruning policy should stay compact and explicit
- do not become a giant version-control religion for every tiny shell surface

Current state:
- warmed in `docs/00-meta/helm-generationcards-attenuatedlinks-2026-03-22.md`
- not yet promoted to a candidate contract

## 2n. Attenuated reveal links

What they are:
- shell-owned narrow travel/share objects over one exact subject or one exact cohort
- good for keeping time-bounded guarded-link/public/named sharing visibly different from durable broader access

Guardrails:
- expiry, revoke posture, and audience class stay visible
- link travel should stay weaker than whole-workspace or whole-device sharing
- historical link evidence is weaker than current-live reveal truth
- links should not silently widen on reuse
- do not become one giant universal sharing backend

Current state:
- warmed in `docs/00-meta/helm-generationcards-attenuatedlinks-2026-03-22.md`
- not yet promoted to a candidate contract

## 2o. Capability recipes

What they are:
- shell-owned portable starter objects that preserve how to reassemble a good working position
- good for keeping portable setup, preferred front doors, likely handle reacquisition, and likely grant requests useful without impersonating live authority or live state

Guardrails:
- recipes stay weaker than current-live grants and current-live beacons
- imported recipes should start restricted-first
- exact generations referenced by a recipe should remain inspectable
- recipe execution/materialization should stay a distinct stronger act
- do not become a giant hidden capability registry or policy studio

Current state:
- warmed in `docs/00-meta/helm-generationcards-attenuatedlinks-2026-03-22.md`
- not yet promoted to a candidate contract


## 2r. Capability budgets

What they are:
- shell-owned upper-bound ask objects over one front door, recipe, helper lane, flow fragment, or importable starter
- good for keeping “may later ask for this family” visibly different from “is borrowing this now”

Guardrails:
- a budget is not a pre-grant
- widening beyond the declared budget must stay explicit
- imported budgets do not import current-live authority
- keep the budget compact enough to read at summon/import time
- do not become a giant policy studio or universal IAM sheet

Current state:
- warmed in `docs/00-meta/helm-capabilitybudgets-renewalrails-2026-03-22.md`
- not yet promoted to a candidate contract

## 2s. Renewal rails

What they are:
- shell-owned next-step rails for old, expiring, revoked, or historical borrowing
- good for keeping renew-same, renew-narrower, move-to-isolated-lane, widen-with-fresh-ask, and let-expire visibly different

Guardrails:
- renewal must not silently widen subject, duration, lane, or persistence class
- historical descriptor or recipe presence is weaker than current-live lease truth
- same-subject reacquire and broader new ask should not share one cheerful button
- expiry should be a valid honest outcome, not only a UX failure
- do not become a giant wizard for every expiring lease

Current state:
- warmed in `docs/00-meta/helm-capabilitybudgets-renewalrails-2026-03-22.md`
- not yet promoted to a candidate contract

## 2t. Change cursors

What they are:
- shell-owned last-seen / resume-from witnesses over one exact mutable source or stream
- good for keeping changed-since, must-still-match, resume-after, and caught-up-through posture visibly different from current-live truth

Guardrails:
- do not impersonate current-live truth
- do not silently repair expired cursors into latestness
- keep compare posture distinct from watch/evaluation posture
- imported/shared cursors start weaker than local live watching

Current state:
- warmed in `docs/00-meta/helm-changecursors-finalizerrails-2026-03-22.md`
- candidate contract exists in `change-cursor-candidate-contract-v0.md`

## 2u. Retry keys

What they are:
- shell-owned same-act witnesses for stronger mutable or provider-facing work
- good for keeping retry-the-same-act visibly different from duplicate second attempts when transport or helper ambiguity exists

Guardrails:
- do not replace warrants or receipts
- materially changed parameters should conflict rather than silently reuse the same key
- keep duplicate suppression visible in Operations
- do not become a hidden workflow engine

Current state:
- warmed in `docs/00-meta/helm-changecursors-finalizerrails-2026-03-22.md`
- candidate contract exists in `retry-key-candidate-contract-v0.md`

## 2v. Teardown rails

What they are:
- shell-owned pending-removal objects over one exact subject
- good for keeping teardown requested, blockers, cleanup progress, force posture, and teardown complete visibly different

Guardrails:
- request and completion stay separate
- blockers should be explicit when possible
- keep teardown rails distinct from trash/history/recovery surfaces
- do not silently force-remove because smoothness feels nicer

Current state:
- warmed in `docs/00-meta/helm-changecursors-finalizerrails-2026-03-22.md`
- candidate contract exists in `teardown-rail-candidate-contract-v0.md`

## 2w. Caveat sheets

What they are:
- shell-owned compact explanation surfaces over one exact power-bearing object
- good for keeping time, lane, audience, freshness, basis, cohort, and missing-context conditions visibly different from generic “allowed” folklore

Guardrails:
- a caveat sheet explains narrowing but does not widen
- inherited caveats and locally added caveats should stay distinct
- missing context should stay distinct from deny
- keep the sheet compact enough to read during summon/share/review
- do not become one giant policy editor

Current state:
- warmed in `docs/00-meta/helm-elevationtickets-deelevationrails-2026-03-22.md`
- candidate contract exists in `caveat-sheet-candidate-contract-v0.md`

## 2x. Delegation subtrees

What they are:
- shell-owned ancestry surfaces over one exact delegated or attenuated lineage
- good for keeping parentage, attenuation deltas, descendant state, and revoke blast radius visibly different from generic history

Guardrails:
- keep subtree truth exact when the substrate can prove it and humble when it cannot
- node-only revoke and revoke-subtree should stay distinct
- children should not overclaim broader power than the parent allowed
- subtree inspection is weaker than current-live authority
- do not become a universal graph browser

Current state:
- warmed in `docs/00-meta/helm-elevationtickets-deelevationrails-2026-03-22.md`
- candidate contract exists in `delegation-subtree-candidate-contract-v0.md`
## 2y. Quiesce rails

What they are:
- shell-owned cooperative maintenance controls over one exact subject or bounded cohort
- good for keeping no-new-work, drain-versus-cancel mode, resume, blocker inspection, and cut-through posture visibly different

Guardrails:
- quiesce is not revoke, detach, or kill
- queue-behind-boundary should never be implicit
- drain and cancel stay distinct
- cut-through stays visible as a stronger separate ending
- do not become a giant orchestration religion

Current state:
- warmed in `docs/00-meta/helm-quiescerails-draintruth-2026-03-22.md`
- candidate contract exists in `quiesce-rail-candidate-contract-v0.md`

## 2z. Drain witnesses

What they are:
- shell-owned maintenance-phase witnesses over one exact quiesce story or bounded live lane
- good for keeping running, quiescing, quiescent, resumed, cut-through, and completed-historical posture visibly different while carrying blocker and freshness truth

Guardrails:
- observational only; do not widen authority
- historical calm is weaker than live calm
- blocker counts should not impersonate named blockers when exact blocker truth exists
- keep the witness compact enough for chrome and Ops rows
- do not become a generic telemetry warehouse

Current state:
- warmed in `docs/00-meta/helm-quiescerails-draintruth-2026-03-22.md`
- candidate contract exists in `drain-witness-candidate-contract-v0.md`

## 2za. Grace-budget chips

What they are:
- shell-owned compact grace-window witnesses attached to one exact live lane, cohort, or maintenance story
- good for keeping remaining graceful time, extension posture, and post-expiry action visible without building a global timer religion

Guardrails:
- explain grace, not every form of liveness
- extension must be explicit, not ambient
- expiry action must be named
- do not pretend expiry equals cleanup-complete
- do not become a general scheduler

Current state:
- candidate contract exists in `grace-budget-chip-candidate-contract-v0.md`

## 2zb. Cut-through receipts

What they are:
- shell-owned compact historical receipts for the moment a graceful story becomes forceful
- good for keeping grace-expired, operator-escalated, provider-cut-through, and residual-cleanup truth visibly different from graceful completion

Guardrails:
- historical, not control-bearing
- keep the escalation reason exact
- keep residue honest when cleanup still remains
- do not become a giant audit log
- do not flatten graceful and forceful endings into one receipt

Current state:
- candidate contract exists in `cut-through-receipt-candidate-contract-v0.md`
