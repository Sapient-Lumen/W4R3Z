# Change cursor candidate contract v0

Purpose: give Helm one compact shell-owned witness for **last-seen / resume-from / changed-since** truth over one exact mutable source without impersonating current-live state or growing into a giant sync engine.

A **change cursor** is a shell-owned mutable-source witness bound to:
- one exact source object or stream
- one exact cursor family
- and one exact comparison or resume posture

It is a candidate move, not a freeze.

## Candidate shape

A first useful change cursor would likely include:
- cursor id
- exact source object id or stream id
- cursor family (`etag`, `resource-version`, `page-token`, `sequence`, `generation`, or another admitted family)
- exact cursor value
- capture time
- comparison posture (`changed-since`, `must-still-match`, `resume-after`, `caught-up-through`)
- optional bound basis stamp
- freshness / validity posture (`fresh`, `possibly stale`, `expired`, `source unavailable`, `cannot resume`)
- optional linked view / watchpoint / subscription refs
- actions (`compare now`, `resume`, `open source`, `refresh cursor`, `discard`)

## Candidate posture

### 1. Bound to one exact mutable source
A cursor should point at one exact source object or stream.
If the source is replaced,
rebased,
or no longer resumable,
Helm should surface that rather than faking continuity.

### 2. Cursor truth is weaker than current-live truth
A cursor witnesses what was last seen or where watching can resume.
It does **not** prove that the source still matches,
that the source is currently healthy,
or that the holder still has authority to inspect it.

### 3. Compare and resume are related but distinct
Some cursors are mostly for optimistic comparison.
Some are mostly for resuming a stream.
Some can do both.
Helm should keep those postures explicit.

### 4. Expired or unusable is an honest state
A cursor should be able to say:
- this can no longer resume,
- this must be refreshed,
- or this source can no longer be compared honestly.
That is better than bluffing latestness.

### 5. A cursor is smaller than a watchpoint
A watchpoint keeps evaluated state.
A change cursor keeps last-seen / resume / changed-since truth.
Do not fuse them too early.

### 6. Imported/shared cursors start weaker
Imported or shared cursors should not silently grant inspection,
auto-arm watch behavior,
or impersonate local current-live truth.
The receiver should inspect and adopt them explicitly.

## Guardrails

1. **Do not let change cursors impersonate live authority.**
2. **Do not silently repair expired cursors into latestness.**
3. **Do not hide source replacement or rebase events.**
4. **Do not turn every mutable thing into a giant subscription engine.**
5. **Do not let shared/imported cursors auto-arm local background watching.**

## Good first specimens

- one saved view with a changed-since-last-review cursor
- one linked view with a cursor chip that says whether the source moved
- one watchpoint/subscription pair that keeps resume cursor truth separate from evaluated state
- one expired cursor that demands refresh rather than pretending continuity

## Working stance

Change cursors now look like the missing small witness for Helm's mutable-source honesty.
They let the shell say “what I last saw” and “where I can resume” without pretending that old evidence is still current-live truth.
