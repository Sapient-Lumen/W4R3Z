# Access verdict card candidate contract v0

Purpose: give Helm one compact shell-owned way to express **why one exact stronger act is allowed,
blocked,
restricted,
stale,
or unsupported** without turning the shell into a giant policy console.

An **access verdict card** is not a grant.
It is not a standing approval token.
It is not a giant audit pane.
It is the shell-owned answer to:

**what exact act was attempted,
what exact blocker class currently applies,
and how complete is the explanation?**

## Candidate posture

### 1. Verdicts belong to exact act + exact subject + exact lane posture
A verdict card belongs to one exact combination such as:
- reveal this exact saved view to guarded-link audience
- publish this exact bundle publicly
- adopt this exact imported surface into live lane
- run this exact helper action against this exact provider subject
- reopen this exact remembered handle with stronger write posture

It does not mean “what can I generally do?”

### 2. Blocked-state classes stay visibly different
A good first verdict vocabulary now looks like:
- allowed now
- denied by policy or grant ceiling
- restricted by trust or lane posture
- stale basis / rereview required
- missing live lease or current grant
- hidden-policy / incomplete explanation rights
- unsupported in this provider or lane
- unknown / cannot evaluate honestly

### 3. Determining blockers should be revealable when known
A first version should be able to expose:
- determining blocker class
- determining source family or gate class
- stale-basis or stale-cursor witness when relevant
- hidden or incomplete visibility posture when the shell cannot inspect everything

### 4. Safe inspect paths should remain nearby
A blocked stronger act should still be able to show nearby safe moves such as:
- inspect basis
- inspect sources or route
- inspect policy family or trust posture
- inspect helper-session / warrant / receipt witness
- open least-widening preview

### 5. The verdict card must not become authority
The card explains.
It does not itself widen.
It does not satisfy the blocker.
It does not replace current-live authority windows,
warrants,
or effect receipts.

## Candidate minimal shape

A first useful access verdict card likely needs:
- exact id
- owner surface id
- exact requested act id or warrant relation
- exact subject refs
- lane / holder posture
- verdict class
- determining blocker class when known
- determining source refs or gate refs when known
- visibility_gap posture
- safe inspect rails
- least-widening-preview relation when available
- observed_at

## Best first homes

- one Omnibox stronger quick action
- one Object Browser publish or reveal act
- one Exchange route or reveal action
- one Desktop Flow apply or helper-backed mutation
- one Recall reentry that is inspectable but blocked from stronger reopen

## Guardrails

1. **No generic red badge as the whole story**
2. **No silent widening because explanation is inconvenient**
3. **No pretending hidden-policy cases are fully explained**
4. **No collapsing simulated and live verdicts into one state**
5. **No giant IAM or settings suite as the v0 proof**

## Working stance

Access verdict cards now look like the missing shared law under many already-warm Helm moves.
They let the shell say something unusually useful:

**this exact act is blocked or allowed for these exact reasons,
this is how complete the explanation is,
and these are the nearby safe inspect paths.**
