# D-ATTN attention posture v0

Purpose: pin Helm's attention and notification stance.

## Posture (v0)

1. **Attention is a hint, not foreground authority**
   - notification and urgent state do not bypass activation control
   - quieting or unquieting attention does not seize focus or prove user awareness

2. **Durable truth lives elsewhere**
   - transient UI is not the sole carrier of consequential state
   - delivery, dismissal, or timeout do not equal acknowledgement or approval

3. **Evaluation, delivery, and quieting stay separate**
   - a watchpoint may keep evaluating while a linked subscription is quiet
   - an attention window may suppress or reshape delivery without rewriting watch state

4. **Critical-only posture is narrower than ordinary attention**
   - any break-through or critical-only rung should remain rarer, policy-gated, and inspectable

5. **Desktop Flow may react to attention, but does not bypass policy**
   - flows can route, coalesce, or respond, but still respect shell-owned activation and visibility rules

## Phase 1 non-goals

- making urgent equivalent to focus steal
- treating notifications as the durable system of record
- turning attention windows into a generic workflow scheduler

## Wiring

- decision surface: `decision-map.md` (D-ATTN)
- related docs: `activation-control-boundary-v0.md`, `operations-center-posture-v0.md`, `attention-window-candidate-contract-v0.md`, `view-subscription-candidate-contract-v0.md`, `watchpoint-candidate-contract-v0.md`
