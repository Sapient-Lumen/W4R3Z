# Host-effect witness candidate contract v0

Purpose: give Helm one compact shell-owned way to express **what shell-side effect weaker-origin content requested,
what provenance grade it had,
and what the shell actually did** without turning the shell into a giant audit warehouse.

A **host-effect witness** is not a permission itself.
It is not a standing policy rule.
It is the shell-owned answer to:

**what host-side effect was requested here,
by what kind of origin,
and did trusted chrome or local policy allow,
hold,
downgrade,
or deny it?**

## Candidate posture

### 1. Witnesses belong to exact effect requests
A host-effect witness belongs to one exact request such as:
- set this exact title or label
- open this exact link or reveal target
- copy this exact payload to clipboard
- trigger this exact stronger review prompt
- request this exact publish,
  reveal,
  or adoption follow-up

It does not mean “everything the app ever did.”

### 2. Origin grade should stay visible
A first useful witness should be able to distinguish at least:
- raw content
- inferred structure
- shell-attested structure
- trusted chrome

This keeps decorative or weak-origin requests from posing as already-trusted shell actions.

### 3. Policy result should stay explicit
A first useful witness should be able to say:
- allowed as requested
- downgraded to weaker local effect
- held for trusted-chrome review
- denied
- expired / no longer current

That is the compact honesty Helm needs.

### 4. Witnesses stay weaker than current-live truth and durable receipts
A host-effect witness explains one effect request and one shell response.
It does not replace:
- current-live authority windows
- durable receipts for strong effects
- exact object identity
- or long-lived shell state

### 5. Decorative labels and stronger actions are not the same family
A title change,
a badge,
a clipboard write,
a link open,
and a publish confirmation are all shell-side effects,
but they are not equally strong.
A witness should keep effect kind explicit instead of flattening them.

## Candidate minimal shape

A first useful host-effect witness likely needs:
- exact id
- owner surface id
- effect kind
- exact subject or target refs when known
- origin grade
- origin surface refs
- policy result
- trusted-chrome relation when escalated
- optional compact explanation
- observed_at

## Best first homes

- one Terminal/Capshell title / clipboard / link-open request
- one imported Browser card requesting adoption or stronger reveal
- one Exchange surface asking for publish or guarded-link confirmation
- one Omnibox suggestion that can only finish after trusted-chrome review

## Guardrails

1. **No witness becoming authority by itself**
2. **No flattening allow,
   hold,
   downgrade,
   and deny into one hidden bit**
3. **No treating decorative labels as exact identity**
4. **No giant compliance or audit-studio ambitions in v0**
5. **No silent carry from old witnessed effect into current-live truth**

## Working stance

Host-effect witnesses now look like the missing shell confession object under many already-warm Helm moves.
They let the shell say something precise:

**this exact weaker-origin surface asked for this exact host-side effect,
and this is what the shell actually did about it.**
