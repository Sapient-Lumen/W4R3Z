# Drift gate candidate contract v0

Purpose: explore one compact shell-owned gate for deciding whether a previously reviewed action warrant still deserves its stronger next rung.

A **drift gate** does not replace a basis stamp,
a review ticket,
or a claim envelope.
It answers a narrower question:

**does this warrant still bind the exact mutable thing that was reviewed,
or has enough changed that the stronger rung should disappear?**

## Candidate shape

A first useful drift gate would likely include:

1. **Bound warrant reference**
   - one exact pointer to the action warrant being gated

2. **Compared basis**
   - one explicit comparison between:
     - reviewed basis
     - current mutable basis

3. **Gate verdict**
   - `match`
   - `drifted`
   - `partial`
   - `expired`
   - `unknown`

4. **Visibility of changed reason**
   - one compact explanation such as:
     - target revision changed
     - affected set changed
     - source query expired
     - route/provider changed
     - privilege posture widened
     - ownership or field conflict appeared
     - context witness changed materially

5. **Allowed next-step ladder**
   - proceed/apply
   - inspect diff
   - refresh bind
   - review again
   - hold
   - inspect historical only

## Guardrails

1. **Not a giant policy engine**
   - first drift gates should stay compact.

2. **Not a hidden override path**
   - if future override exists,
     it should remain visibly stronger than ordinary proceed.

3. **Not a timeless validity badge**
   - the gate speaks for a comparison at a moment,
     not evergreen approval.

4. **Not mandatory everywhere**
   - low-risk exact actions can stay light.

5. **Explain the downgrade**
   - a drift gate that only says “changed” without saying what compared is too weak.

## Why this looks promising

Helm already wants honest:
- restore,
- reopen,
- import,
- attach,
- branch,
- and apply posture.

A drift gate is the cheap way to stop saved convenience from becoming sticky approval folklore.

## First proof-bearing specimen

A narrow specimen would likely be enough:

- one exact match gate that keeps apply visible
- one drifted gate that removes apply and opens review-again
- one expired gate caused by a stale review slice/query
- one partial gate that allows inspect and refresh-bind only

## Failure modes to avoid

- tiny “changed” badges without saying what compared
- expired/stale surfaces that still show the strongest action
- drift gates that hide the warrant they are gating
- giant compare bureaucracy before one small useful gate exists
