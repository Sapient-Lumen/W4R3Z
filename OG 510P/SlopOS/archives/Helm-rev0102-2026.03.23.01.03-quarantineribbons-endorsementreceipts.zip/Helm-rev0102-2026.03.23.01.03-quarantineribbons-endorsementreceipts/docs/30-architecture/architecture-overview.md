# Architecture overview

Helm is a desktop shell/compositor product built around one idea:

the desktop has a real object model, and that model should be visible and programmable.

The shell/compositor therefore owns desktop truth for:

- surfaces/windows
- focus and activation
- workspaces and placement
- visibility and reveal/select
- continuity posture and reentry
- transfer routing and exactness
- shell-object identity
- base automation entrypoints

Around that truth Helm ships seven first-party shell pillars plus a native terminal/capshell front-end family:

- **Tiling Shell** — keyboard-first, hybrid-capable presentation and layout
- **Omnibox** — launch, search, switch, route, and act over shell-owned objects
- **Object Browser** — query views, reveal, preview, selection, and durable object workflows
- **Operations Center** — windows, jobs, background presence, resource use, grants, failures, automation sessions, transfers, and receipts
- **Desktop Flow** — visible graph control over the desktop
- **Recall** — continuity, reentry, exact reopen/reveal, activity trail, and restored-vs-live honesty
- **Exchange** — typed ingress, selection packets, transfer routing, attach/share/forward workflows, and route witnesses
- **Terminal/Capshell** — a native shell-facing front-end family for explicit shell tooling that does not smuggle ambient authority back in

These are not eight adjacent apps. They are seven pillars plus one native shell-facing front-end family over one control plane.

Helm preserves raw reach through an explicit control-tier model:

1. shell graph
2. structural UI graph
3. raw automation lane

The exemplar lineage now translates like this:

- i3 → deterministic tiling discipline
- AHK → low-latency desktop programmability with a visible raw lane
- Rofi → unified summon/search/switch/dispatch over shell objects
- Dolphin → strong object/document browsing with query views and exact reveal
- “god-tier task manager” → an Operations Center that explains the desktop honestly

SlopOS and Schell now add two promoted product pressures that became pillars rather than hidden subsystems:
- exact continuity, explicit restore/reentry honesty, and durable activity truth
- typed transfer, explicit ingress/selection packets, and exact route witnesses

Schell changed one major thing in recent revisions:
Helm no longer treats terminal work as a generic future placeholder.
Instead it names a provisional shell-facing treaty around:
- session lineage
- reviewed actions and receipts
- ingress packets
- execution-ground witnesses
- restoration honesty
- attach/forward route honesty

The product thesis is not “ban hacks.” It is “make the shell graph strong enough that hacks become the exception rather than the substrate.”

Helm's datacube stance is now much clearer: **do not build one giant cube.**
Build a shell-owned family of saved view objects, basis stamps, change cursors, action warrants, drift gates, retry keys, effect receipts, slot verdict ledgers, quiesce rails, drain witnesses, grace-budget chips, cut-through receipts, intent sparks, direct-gesture gates, quarantine ribbons, endorsement receipts, shadow work lanes, adoption harbors, landing trains, reversal warrants, repair ladders, teardown rails, claim envelopes, reliance ladders, freshness windows, authority windows, elevation tickets, grant-rung ladders, revoke handles, de-elevation rails, active-borrow beacons, brake rails, freshness-horizon chips, decay rails, access verdict cards, least-widening previews, condition strips, observed-basis chips, trusted chrome lanes, host-effect witnesses, reveal windows, audience ladders, cohort windows, minimization ladders, reach previews, affected-set witnesses, glance derivations, watchpoints, patrol routes, evidence briefs, response kits, timeline markers, bounded view subscriptions, derivative view decks, activity front doors, current-live beacons, pinned and floating handles, generation cards, rollback rails, attenuated reveal links, capability recipes, capability budgets, lease windows, renewal rails, promotion rails, humane facet-conflict cards, weak Overview landings, bounded compare surfaces, caveat sheets, delegation subtrees, and explicit publication/adoption/promotion/reveal/materialize/rollback/renew/revalidate/widen/narrow/remove/retire/endorse/safe-open moves over stronger shell truth.

While the companion cubes are still in design phase, Helm should freeze **cross-pillar verbs and proof slices** more confidently than it freezes **cross-pillar mega-objects**. In practice that means pull the trigger on delight proofs like parameterized front doors, peek → promote, exact-scope grants, exact remembered handles, constrained helper lanes, named protection gates, pinned-versus-floating handle badges, rehearsal → compare → promote rails, facet-conflict cards, generation cards, attenuated reveal links, capability budgets, borrowed-now lease windows, renewal rails, elevation tickets, de-elevation rails, effect receipts, slot verdict ledgers, quiesce rails, drain witnesses, grace-budget chips, cut-through receipts, intent sparks, direct-gesture gates, condition strips, observed-basis chips, trusted chrome lanes, host-effect witnesses, active-borrow beacons, brake rails, freshness-horizon chips, decay rails, triage lanes, quarantine ribbons, endorsement receipts, and continuity postcards before expanding family machinery any further.

## Cross-cutting moves currently pressuring the architecture

These are not promoted pillars, but they are increasingly important.
Many of them should now be read through one shared law: **projection surfaces are bounded, typed, source-witnessed, and non-authoritative by default.**
A second shared law is now warming in earnest: **preview, warrant/review, effect/receipt, rehearse/compare, materialize/adopt, reversal/repair, claim/reliance, freshness/revalidation, authority/eligibility/grant/de-elevation/revoke, verdict/least-widening preview, reveal/audience, last-seen/change-cursor, retry/same-act identity, teardown/requested-vs-complete, live truth, and live-truth decay are different strengths, not one mushy convenience state.**
A third shared law now looks worth naming explicitly: **status should be multi-axis and basis-honest — progressing, restricted, degraded, stale, muted, teardown-requested, historical, and current-live are different claims, and visible status should admit what exact mutable basis it was observed against.**
A fourth shared law now looks warm enough to prove: **authority-bearing review should live in shell-owned trusted chrome, while weaker-origin content can only request shell-side effects through witnessed seams.**
A fifth shared law now looks worth warming: **foreign arrival, quarantine/risk state, safe-open posture, explicit endorsement, derivative-vs-source distinction, and live authority are different strengths, not one flattering open/import state.**

- **Three-form law** — recipes/definitions, tickets/snapshots/stable review slices, and live instances/current lanes should stay visibly different forms even when the shell makes them easy to move between
- **Review tickets** — compact shell-owned stable-enough review slices for compare, paging, route inspection, checkpoint review, and handoff without pretending current liveness
- **Activity spines** — shell-owned scoped work frames that can gather saved views, checkpoints, quick actions, launch/layout starters, review tickets, and one current-live beacon without collapsing into a giant workspace religion
- **Current-live beacons** — compact shell-owned exact current-lane cues that stay stronger than recents, entry kits, checkpoints, or grouped resource sets
- **Pinned and floating handles** — compact shell-owned handle posture objects that keep exact reviewed / exact historical / exact commit-like reentry visibly different from intentionally latest-following entry points
- **Generation cards** — compact shell-owned exact-history objects that keep current generation, prior generations, compare posture, rollback posture, and retention class visible for materially changing saved shell surfaces
- **Attenuated reveal links** — compact shell-owned travel/share objects that keep one exact subject or cohort, one reveal shape, one audience class, one expiry posture, and one revoke path visibly different from broad durable access
- **Capability recipes** — compact shell-owned portable starter objects that preserve helpful preferred setup, likely reacquisition paths, generation lineage, and declared future-ask posture without impersonating current-live grants or current-live state
- **Capability budgets** — compact shell-owned upper-bound ask objects that say what a front door, recipe, flow fragment, or helper lane may later request without pretending those asks are already granted
- **Lease windows** — compact shell-owned current-live borrowing objects that say what exact authority is actually held now, by whom, on what subject, on what rung, for how long, and with what nearby revoke/narrow moves
- **Renewal rails** — compact shell-owned next-step rails that keep renew-same, renew-narrower, move-to-isolated-lane, widen-with-fresh-ask, and let-expire visibly different when old borrowing is revisited
- **Promotion rails** — compact shell-owned paths that keep rehearsal, compare, gates, promote, refusal, and aftermath visibly different when side work or preview becomes strong enough to land
- **Retry keys** — compact shell-owned same-act witnesses that keep safe retries visibly different from second attempts or silent duplicate effects when stronger acts cross unreliable boundaries
- **Teardown rails** — compact shell-owned pending-removal objects that keep teardown requested, blockers, cleanup progress, force posture, and teardown complete visibly different
- **Facet ownership cards** — compact shell-owned conflict surfaces that say which authored, imported, derived, helper, or default actor currently owns one facet/slot of a composite shell surface and what explicit takeover or keep-local moves exist
- **Activity memory seeds** — compact shell-owned remembered facts, warnings, instructions, or object/view pointers that stay explicit, scoped, source-witnessed, and weaker than live truth
- **Context loadouts** — compact shell-owned current bundles of selected tabs/files/views/seeds/tools/instructions for one ask, compare, route, or action
- **Contribution witnesses** — compact shell-owned after-surfaces that say what was selected, what was actually used, and what stayed merely nearby or available
- **Claim envelopes** — compact shell-owned output objects that separate observed, sourced, derived, remembered, proposed, and unresolved claim classes; can reveal grounding witness, freshness, locality, and redaction posture; and stop mixed-result surfaces from flattening everything into one answer box
- **Reliance ladders** — compact shell-owned next-step ladders that keep inspect basis, inspect sources, inspect helper-session witness, double-check, save weakly, quote/share, adopt, and apply visibly different strengths next to a claim envelope
- **Freshness windows** — compact shell-owned decay/revalidation posture objects that say how fresh one bounded saved, derived, watched, remembered, or traveling shell object still is; what weaker stale class if any still applies; and what exact revalidation rails remain available
- **Change cursors** — compact shell-owned last-seen / resume-from witnesses that keep “what I last saw,” “where watching can resume,” and “has this changed since then?” visibly different from current-live truth
- **Authority windows** — compact shell-owned bounded grant objects that say what exact authority family exists or recently existed, for whom, on what subject, on what rung, with what live-vs-historical posture, and with what revoke/narrow next moves
- **Elevation tickets** — compact shell-owned temporary-power tickets that keep eligible, requested, pending approval, active, and historical temporary stronger power visibly different while preserving reason, duration, reduced-scope, and extra-check posture
- **De-elevation rails** — compact shell-owned nearby rails that keep end-now, narrow-now, drop-back-to-eligible, and inspect-history visibly different once temporary stronger power exists
- **Grant-rung ladders** — compact shell-owned humane choosers that keep inspect, exact once, this ask, this activity, isolated-lane only, and persistent scope visibly different instead of collapsing everything into one Allow button
- **Revoke handles** — compact shell-owned nearby live controls that keep revoke, suspend, narrow, and move-to-isolated-lane visibly different after a grant exists
- **Reveal windows** — compact shell-owned bounded visibility objects that say what exact audience relation exists or recently existed, by what route, in what reveal shape, under what expiry/policy posture, and with what current-live versus historical truth
- **Audience ladders** — compact shell-owned humane choosers that keep local-only, named, org/workspace, guarded-link, and public/time-boxed reveal visibly different instead of collapsing everything into one Share state
- **Action warrants** — compact shell-owned exact proposed-change objects that say what strong effect is being asked for, on what reviewed basis, with what affected-set and next-step posture
- **Reach previews** — compact shell-owned pre-act expected-reach surfaces that say what a stronger reveal/export/mute/apply/rerun act would currently include, whether that reach is static or dynamically rule-derived, and where the inspect/narrow/broaden path lives
- **Affected-set witnesses** — compact shell-owned exact-or-counted witnesses for predicted or observed touched sets so previews, warrants, windows, receipts, and repair surfaces can carry inspectable “who was in scope” truth
- **Drift gates** — compact shell-owned gates that compare a warrant's reviewed basis against current mutable basis so stronger rungs can downgrade honestly when the target drifted
- **Effect receipts** — compact shell-owned durable aftermath witnesses that say what exact effect actually happened after a stronger act without impersonating current-live truth
- **Slot verdict ledgers** — compact shell-owned slotwise aftermath ledgers that keep partial landing, rebind, default-fill, pending, and refusal outcomes inspectable after the act
- **Quiesce rails** — compact shell-owned cooperative maintenance controls that keep no-new-work, drain-versus-cancel mode, visible blockers, resume, and cut-through posture visibly different without turning the shell into a giant orchestrator
- **Drain witnesses** — compact shell-owned maintenance-phase witnesses that keep running, quiescing, quiescent, resumed, cut-through, and completed-historical posture visibly different while carrying blocker and freshness truth
- **Landing trains** — compact shell-owned ordered promotion objects that keep queue order, exact target lane, rebuild/invalidation truth, and optional guarded-promotion ladders visible when several candidates aim at one authoritative lane
- **Reversal warrants** — compact shell-owned exact reverse/recover proposal objects that bind one historical effect, checkpoint, or reviewed change before a stronger reversal or compensating act happens
- **Repair ladders** — compact shell-owned bounded next-step ladders that keep undo, redo, rerun-failed-subset, replay-on-fresh-basis, reopen-unresolved, branch-and-fix, and hold visibly different after a partial or regretted effect
- **Context recipes** — still-warm tiny ordered bundles of memory seeds, instructions, and starter hints that can steer return/planning surfaces without becoming a second hidden control plane

- **Projection surfaces** — compact shell-owned derivative surfaces such as docks, rails, strips, lenses, cockpit cards, decks, bays, and exact trails that project already-legible shell truth without becoming new authority domains
- **Preview** — a shell-wide inspect-before-commit surface that should appear across Object Browser, Omnibox, Recall, Exchange, and Operations Center
- **Preview-promotion ladders** — a shell-wide grammar where preview may carry bounded actions and then explicitly promote into open, reveal, split, import, adopt, compare, or branch without pretending those stronger moves already happened
- **Open-versus-stronger-act honesty** — generic open/summon should remain weaker than current-live reentry, durable save, materialization/adoption, publication/promotion, and branch/fork acts
- **Workspace/activity capsules** — continuity objects that capture and reenter meaningful project state with exact/repaired/partial/unavailable honesty
- **Scoped activity memory** — a spine or shared activity should be explicit about what memories, views, receipts, and resources are in scope and what remains deliberately out of scope
- **Imported-surface trust posture** — a reusable weaker starting posture for inbound/shared/rebound shell surfaces, ideally with explicit restricted-mode cues and named blocked powers, so imported things can be useful before they are fully adopted as local truth
- **Overview** — a spatial companion to Omnibox that shows windows, workspaces, continuity cues, and quick moves at a glance
- **Visual layout/template editing** — a Tiling Shell surface for spatial templates without regressing into separate zone-manager culture
- **Activity cockpit cards** — shell-owned activity front doors that combine live status, continuity relation, layout relation, and next actions without becoming a new pillar
- **Activity entry kits / front doors** — shell-owned saved starter objects that sit on top of activity spines and resource shelves, point at one preferred way in, can expose one triage lane and one compare/change path nearby, carry explicit profile/provider affinity without silently choosing it, and keep inspect / attach / restore / relaunch / fresh-start choices explicit without pretending to be live state
- **Exact front-door handles** — tiny shell-owned summonable entry objects that point at one preferred way back in without pretending they are current-live proof
- **View subscriptions** — shell-owned bounded attention relations attached to one exact saved view object so a view can notify without becoming a hidden daemon or giant timeline
- **Glance derivations** — tiny shell-owned derived summary objects over one exact saved view or review ticket so Overview and subscriptions can stay glanceable without pretending summary cards are live truth
- **Watchpoints** — shell-owned evaluated-state objects over one exact saved view so Overview and Operations can show durable watch state without confusing notification history for current evaluated truth
- **Attention windows** — shell-owned quiet / active / maintenance / critical-only posture objects over exact subscriptions, watchpoints, patrol routes, or digest lanes so interruption law stays inspectable and weaker than watched truth
- **Basis stamps** — compact shell-owned exact-basis witnesses that let traveling, derived, reviewed, or published shell luxuries say what exact source, revision, checkpoint, query, or prior reviewed state they reflect without bluffing latestness
- **Patrol routes** — shell-owned bounded revisit circuits over linked views, watchpoints, compare tickets, and exact front-door handles so the rounds people actually make stop depending on memory, recents, or giant dashboards
- **Evidence briefs** — shell-owned bounded curated-investigation objects over exact views, watchpoints, glances, tickets, receipts, and handles so people can gather and explain why something matters without turning the shell into a giant notebook or case engine
- **Response kits** — shell-owned bounded guided-response objects over exact source refs, instructional and automated steps, action affordances, preconditions, and visible outputs so people can see what to do next without turning the shell into a giant workflow engine
- **Live lenses** — bounded shell-owned derivative watch/compare surfaces that keep source witness and modest action strength explicit
- **Drift beacons** — compact shell-owned change-aware surfaces that compare one exact current subject against one exact reviewed or remembered basis without becoming giant timeline theater
- **Basis contrast cards** — bounded shell-owned current-vs-basis compare surfaces that sit one rung above drift beacons and one rung below giant history/diff products
- **View decks** — small shell-owned named sets of explicit views over one subject family, activity relation, or query basis, often including triage/compare/work members, without collapsing into dashboard folklore
- **Linked views** — borrowed by-reference appearances of saved view objects inside other shell surfaces, keeping source and basis witness instead of becoming copied authority
- **Deck recipes** — shell-owned typed saved starters that can materialize a view deck or deck-like cluster without letting the recipe itself impersonate live continuity
- **Derivation strips** — tiny shell-owned witness strips/headers that keep a compact derived surface honest about its exact source, basis, recipe, and locality tier
- **Publication ladders** — compact shell-owned ladders for promoting a surface across locality tiers without ambient sync or fake shared liveness
- **Handoff packets** — portable shell-owned travel forms that let a derived or saved surface cross tiers with exact source, basis, and locality witness without pretending the receiver already has live local state
- **Receiver-fit cards** — compact receiver-side landing cards that say what matched locally, what was intentionally omitted because it is receiver-local, and what explicit choices still remain before rebind, materialize, or adopt
- **Promotion receipts** — compact shell-owned durable witnesses for publication/share/export moves, including tier change, audience delta, and receiver-side expectations
- **Materialization bays** — explicit shell-owned places or workflows where a preview, view, import, trail, recipe, or candidate can become a stronger local or live thing without smuggling that stronger workflow through the weaker one
- **Landing rehearsals** — compact receiver-local try-before-adopt surfaces where an imported or derived shell object can be rendered provisionally before it becomes adopted local truth
- **Review strips** — tiny shell-owned preflight strips/cards that can show subject, route, basis, and readiness without forcing giant review UI
- **Launch ladders** — small shell-owned next-step ladders that distinguish inspect, fresh launch, attach, reuse, repaired return, historical replay, and hold instead of flattering everything into “open”
- **Sticky context strips** — tiny shell-owned anchors that keep long-lived output, receipts, status lanes, or result panes attached to their source/action/subject posture
- **Preview rails** — compact bounded next-step rails next to shell-owned preview so inspect and stronger action stay adjacent but distinct
- **Facet strips** — compact typed pivot rows for objects, actions, routes, receipts, and transfers so summon/recency surfaces avoid one mushy mixed list
- **Exact-object recency** — Recall cues centered on exact objects, reviewed actions, route receipts, and clear source labels rather than vague recent-items folklore
- **Current-live reentry cues** — one shell-owned obvious return path for the real active live lane, typically carried by a current-live beacon and kept visibly stronger than generic history or recent/opened hints
- **Authority windows** — shell-owned bounded grant objects that say what authority is live or historical for one act, lane, activity, or source, with expiry/revoke posture and explicit separation between issuance evidence and current-live truth
- **Grant-rung ladders** — small shell-owned choosers that keep inspect / once / this-time / ask-scoped / activity-scoped / isolated-lane / persistent grants visibly different instead of flattening them into one Allow button
- **Revoke handles** — compact shell-owned current-control objects that keep exact revoke, suspend, or narrow acts nearby for live grants instead of burying them in provider folklore
- **Attenuation ladders** — small shell-owned de-escalation choosers that keep drop-to-inspect, this-ask-only, activity-only, isolated-lane-only, subfamily-only, and full revoke visibly different after a grant is already live
- **Reusable flow fragments** — reusable status-bearing graph units so Desktop Flow can absorb subflow/prefab lessons without becoming opaque
- **Binding witness cards** — shell-owned continuity cards that explain exact / repaired / ambiguous / unavailable joins across saved or planned structure and current live targets
- **Activity scope witnesses** — small shell-owned strips/cards that say which axes counted for same-activity continuity and which nearby ambient context stayed out
- **Continuity choice witnesses** — small shell-owned strips/cards that say who proposed, chose, or executed a repaired, widened, switched, reused, or delegated continuity path
- **Basis packets** — small shell-owned strips/cards that say what exact reviewed basis a stronger action still depends on, whether it still matches, and which honest next ladder remains
- **Shadow work lanes** — small shell-owned isolated mutable side lanes with exact live-subject links, authorship posture, basis posture, and drift visibility for delegated or background work
- **Adoption harbors** — compact shell-owned inspect/apply surfaces where candidate side work can be previewed, selectively adopted, held, or rejected without pretending it is already live truth
- **Arrival overlays** — compact shell-owned compare surfaces that show one arriving subject against one exact basis or one explicit local candidate before adoption
- **Adoption slices** — bounded shell-owned partial-adoption acts that let receivers accept one admitted slice of a landing while keeping the remainder explicit
- **Lineage modes** — compact shell-owned cross-boundary identity choices that distinguish preserve-lineage, fork-as-copy, and fresh starter-instantiation before stronger publish/import/materialization acts
- **Fork receipts** — compact shell-owned durable ancestry witnesses that explain when a new surface was born from another one without pretending same-object continuity survived

Twelve narrower moves are now frozen rather than merely implied:

- **typed Omnibox providers** — the action-surface breadth is welcome, but the extensibility model is typed-provider-first rather than ambient shell-string plugin culture
- **Flow observability/reuse** — Desktop Flow now explicitly requires debug/event surfaces, graph secondary views, and reusable inspectable fragments
- **request-vs-live truth** — rich cards, routes, restores, and status surfaces must not flatten proposal, admission, live observation, and historical receipt truth into one flattering success story
- **entry-artifact truth** — saved task-entry objects must not flatten selected plan/history/guidance into current live state merely because they are convenient to summon
- **binding witness posture** — non-exact joins from saved/planned structure to current live targets must stay witnessable rather than silently counting as ordinary success
- **activity-scope truth** — same-activity claims must not silently inherit nearby workspace/profile/account/browser/remote/provider context by convenience or glow
- **continuity-switch authorship truth** — repaired, widened, switched, reused, or delegated continuity must not hide who proposed, chose, or executed the move
- **reviewed-basis truth** — strong shell-facing actions should not silently follow newer mutable basis just because the shell still remembers the task, card, or prior review
- **delegated-adoption truth** — delegated, background, or repair-produced mutable candidate work should not silently mutate the operator's authoritative live lane before explicit adoption
- **ordered-promotion truth** — when several candidates aim at one authoritative lane, queue order, rebuilds, invalidations, pauses, and partial guarded promotion should stay visible instead of collapsing into isolated green-check folklore
- **approval-on-reviewed-basis truth** — strong shell-facing apply/adopt/run acts should bind one exact reviewed basis and downgrade honestly when that basis drifted instead of silently following the newest mutable state
- **recovery truth** — generic undo/retry language should not flatten exact reversal, redo, subset rerun, replay-on-fresh-basis, compensating reverse, and hold into one flattering recovery story
- **authority-duration truth** — temporary approval or grant should not silently widen, float onto a drifted basis, or outlive its explicit rung just because the shell remembers that it was granted once
- **eligibility-versus-activity truth** — being eligible to request stronger power, having a pending request, holding a temporary grant, and being hot now are different claims and should not collapse into one flattering allowed state
- **post-grant control truth** — revocation, suspension, de-elevation, and narrowing should stay exact about what ended and what remains rather than hiding in provider-specific settings or overclaiming total erasure
- **reveal-route truth** — named invite, org-only, guarded link, public link, and bearer/signed route should stay visibly different instead of flattening into one flattering shared badge
- **historical-share truth** — promotion receipts and old publish/share events should not impersonate current audience truth unless a stronger live reveal witness confirms the surface is still open now


Additional narrower moves frozen by this revision:

- **linked-view provenance truth** — borrowed views must keep source, basis, locality tier, and degradation posture inspectable instead of pretending wrapper-local ownership
- **front-door handle truth** — tiny summonable entry handles should stay exact and useful without impersonating current-live beacons or silent strongest-act launch
- **profile-affinity truth** — preferred profile/account/provider/space hints should stay explicit witnesses or choices rather than ambiently selecting live scope
- **suggestion-first triage truth** — AI triage help should begin as explainable suggest/accept/decline posture before any stronger auto-apply rung becomes admissible


New narrower moves frozen by this revision:

- **view-subscription truth** — a saved view may carry bounded attention, but the subscription remains shell-owned, revocable, inspectable, and weaker than current-live or workflow-authority truth
- **overview-landing truth** — Overview should be assembled from linked views, handles, watchpoints, beacons, nearby briefs, nearby kits, and bounded ops slices rather than becoming a second authority plane or giant home dashboard
- **watch-state honesty** — saved view, watchpoint, and delivery event should remain distinct forms, and muted delivery must not impersonate healthy evaluation
- **attention-window honesty** — quiet / maintenance / active-only delivery windows should remain distinct from source truth and watch state, and silence must not impersonate recovery
- **brief-versus-source honesty** — a brief should stay a bounded curated derivative object whose notes, summaries, and imported posture remain weaker than the exact source views, tickets, receipts, and current-live evidence it gathers


Additional narrower move frozen by this revision:

- **marker-time truth** — point/range markers, imported change events, and recent-change breadcrumbs should help correlate time and context without impersonating current-live proof, causal certainty, or giant event-bus authority


## New cross-cutting pressure: least-reach cohorts

Helm now has enough saved, derived, authority, reveal, and recovery objects that one additional law becomes useful across the whole shell:

- a **loadout** says what ingredients are intentionally available
- a **cohort window** says what exact subset a bounded act is actually about
- a **minimization ladder** says how much wider the shell is asking to go
- a **reach preview** says what the stronger move would actually include right now
- an **affected-set witness** keeps predicted and observed touched-set truth inspectable nearby

That distinction keeps Exchange, Recall, Omnibox, and Operations Center from quietly widening from one selected slice into one whole provider or workspace family, and from collapsing predicted blast radius into live aftermath folklore.

## Current ratchets from rev0085

This revision adds three especially strong design-phase ratchets that should now inform most pillar work:

- **restricted-first adoption posture** — imported, rebound, borrowed, or helper-generated structures should begin inspectable and weaker than ordinary local truth until an explicit adopt step upgrades them
- **saved-plan / reviewed-basis posture** — stronger acts should be able to carry exact subject, exact scope, exact basis, drift status, and inspect-before-apply review rather than collapsing immediately into fire-and-forget mutation
- **exposure ladders** — local preview/open, named/private cohort, org/tailnet, guarded-link, and public should remain visibly different reveal/exposure classes rather than one generic open/share state
- **exact remembered handles** — wherever the host allows it, Helm should carry exact reopen/rebind access as remembered handles/bookmarks with visible current / stale / re-requestable posture rather than path/title nostalgia
- **constrained helper lanes** — helper, delegated, or repair work should run inside visible file/object and network bounds with allow / ask / deny posture rather than ambient shell reach
- **named protection gates** — strong publish/apply/expose acts may need visible reviewer / delay / policy / custom-check gates that stay distinct from both the proposal and the final effect receipt

A fourth ergonomic ratchet is warming into likely law:
**adopt the narrowest safe rung** should be an ordinary fast path across pillars.

These are not arguments for a bigger cross-pillar constitution.
They are arguments for a tighter shell-owned verb grammar over the same seven pillars.
