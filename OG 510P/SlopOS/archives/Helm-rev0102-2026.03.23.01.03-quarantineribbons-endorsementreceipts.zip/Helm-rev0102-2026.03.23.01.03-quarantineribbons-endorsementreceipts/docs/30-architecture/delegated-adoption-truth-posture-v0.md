# Delegated-adoption truth posture v0

Purpose: freeze one narrow cross-cutting rule before Helm's delegated help,
background work,
and repair luxuries drift into a hidden mutation lane.

This doc is intentionally narrow.
It does **not** create a giant branch manager,
a full agent constitution,
or a final collaboration algebra.
It only says that when delegated,
background,
or repair work produces mutable candidate state,
that work should not silently become authoritative live activity.

## Posture (v0)

1. **Live activity and delegated candidate work are different truths**
   - A delegated helper,
     background lane,
     repair routine,
     or shadow task may produce valuable candidate state.
   - That state is not the same thing as the operator's authoritative live lane merely because it is useful,
     nearby,
     or likely to be adopted.

2. **Delegated mutable work should land in an isolated non-authoritative lane by default**
   - Candidate work may be visible,
     inspectable,
     and richly contextual.
   - But until adoption,
     it should stay separate from the live lane it relates to.
   - The first implementation can stay small.
   - The rule matters more than the eventual storage model.

3. **Adoption should be explicit when mutable candidate work wants to become live**
   - Helm may offer:
     - inspect,
     - adopt selected,
     - adopt all,
     - fresh bind,
     - continue shadow,
     - reject,
     - or hold.
   - What it should not do is quietly rewrite the authoritative lane and explain later.

4. **Adoption remains basis-aware**
   - Isolation does not remove the need for exact basis and drift checks.
   - Candidate work should still say what basis it started from and whether the current live target still matches.
   - If the live basis drifted,
     Helm should reopen review,
     downgrade,
     or hold rather than silently landing stale work.

5. **Proposal or observation is not mutation**
   - Suggested fixes,
     previews,
     simulations,
     dry runs,
     and side-lane drafts may all be powerful.
   - They should stay visibly proposal-only or observational until adoption crosses a named surface.

6. **External side effects should stay even more constrained than local adoption**
   - If a delegated lane wants to perform externally visible effects,
     that path should remain explicitly stronger than local candidate editing.
   - Silent live-lane mutation is already a problem.
   - Silent external action is worse.

7. **This posture stays smaller than a full branch/workflow system**
   - Phase 1 does not need a universal branch manager,
     generalized merge UI,
     or final collaborative lane constitution.
   - It only needs enough shell law that helpful delegated work stops laundering itself into authoritative live activity.

## Why this is now worth freezing

Helm already froze:
- request-vs-live truth,
- entry-artifact truth,
- binding-witness posture,
- activity-scope truth,
- continuity-switch authorship truth,
- and reviewed-basis truth.

That solved several continuity and strong-action lies,
but one dangerous lie remained easy:

**a surface could stay beautifully honest about basis,
scope,
join,
and authorship,
while still letting delegated work write directly into the live lane and only backfill explanation afterward.**

That risk is now large enough to name.

## Phase 1 non-goals

- a giant workspace / branch / merge manager
- a universal collaboration taxonomy
- forcing every tiny suggestion into a side lane
- hiding ordinary operator-owned edits behind new ceremony

## Wiring

- related docs:
  - `reviewed-basis-truth-posture-v0.md`
  - `continuity-switch-authorship-posture-v0.md`
  - `basis-packet-candidate-contract-v0.md`
  - `shadow-work-lane-candidate-contract-v0.md`
  - `activity-entry-kit-candidate-contract-v0.md`
  - `activity-cockpit-candidate-contract-v0.md`
- likely pressure surfaces:
  - delegated shell help,
  - repair flows,
  - background agents,
  - Recall / cockpit / entry-kit actions that spawn mutable candidate work,
  - and any future exact-handoff or apply surface.
