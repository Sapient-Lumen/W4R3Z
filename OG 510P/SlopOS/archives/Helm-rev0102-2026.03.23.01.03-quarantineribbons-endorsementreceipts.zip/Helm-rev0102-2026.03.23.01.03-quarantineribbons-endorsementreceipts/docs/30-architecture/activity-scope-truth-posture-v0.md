# Activity scope truth posture v0

Purpose: pin one compact Helm rule on a continuity problem that remains dangerous even after request-vs-live truth, entry-artifact truth, and binding-witness posture are already in place.

The problem is simple:
**a saved/planned activity can still lie if nearby visible context silently widens what counts as “the same activity.”**

This posture is intentionally narrow.
It does **not** define a final activity ontology, a giant scope algebra, or one universal matching engine.
It only says Helm should keep explicit **in-scope axes** separate from nearby **ambient adjacency** when return-to-task, rebind, attach, restore, or quick-entry surfaces are making strong continuity suggestions.

## Posture (v0)

1. **Activity identity and activity scope are related, but not interchangeable**
   - a named activity, capsule, cockpit, or entry kit may carry one stable shell-owned activity handle,
   - but any claim that a current live target “belongs to the same activity” may also depend on scope axes such as object/project, provider, working tree, workspace lane, peer/remote, account, browser/profile/session, or other reviewed dimensions.

2. **Nearby visible context does not silently widen activity scope**
   - a nearby window,
   - a similar title,
   - the current workspace,
   - the last-used account/profile/browser session,
   - a plausible remote peer,
   - or another object from the same family
   does **not** silently become part of the same activity just because it is visible, convenient, or recently used.

3. **Included axes and excluded ambient context should be nameable**
   - entry kits,
   - cockpit cards,
   - binding witness cards,
   - capsule diffs,
   - and Recall cues
   should be able to reveal which scope axes participated in the current continuity claim,
   and which nearby ambient surfaces were explicitly kept out.

4. **Widened, unknown, and operator-switched scope stay visible**
   - if Helm cannot maintain the original scope exactly,
   - if the scope basis is missing,
   - or if the operator deliberately switches one axis,
   that should remain visible rather than silently counting as ordinary same-activity continuity.

5. **Remote/profile/account/browser/session-like axes deserve extra caution**
   - these are some of the easiest axes to inherit accidentally from ambient state,
   - and some of the most dangerous axes to overclaim as part of “same activity.”
   Compact witnesses are fine,
   but hidden widening is not.

6. **This posture stays smaller than a giant workspace bureaucracy**
   - Phase 1 does not need one total catalog of every possible scope axis.
   - It only needs enough shell law that saved-to-live continuity can say which axes are in play and which were merely nearby.

## Why this is worth pinning now

Helm now has enough saved/planned continuity surfaces that binding witnesses alone are not quite enough.
A card can explain that a join was exact or repaired,
but still hide the more dangerous question:
**exact with respect to which axes?**

SlopOS keeps refusing silent widening across exact reveal, request-state, session-selection, and request-local metadata seams.
Schell keeps pressuring launch kits, cockpits, origin badges, and preflight honesty.
DelayBasin's scope-witness / active-request / ambient-roster discipline makes the missing refinement unusually clear.

So the narrow new Helm rule is:

**when Helm suggests or claims continuity for an activity, nearby ambient context should not silently widen what counts as that activity.**
