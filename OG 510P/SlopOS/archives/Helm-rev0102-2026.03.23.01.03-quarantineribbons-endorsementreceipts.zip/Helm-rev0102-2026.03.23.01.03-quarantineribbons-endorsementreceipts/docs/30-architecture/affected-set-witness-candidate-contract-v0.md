# Affected-set witness candidate contract v0

Purpose: give Helm one compact exact-or-counted witness for **who was predicted or observed as touched** by one bounded stronger act.

An **affected-set witness** may appear:
- inside a reach preview,
- beside an action warrant,
- beside a reveal window,
- inside an effect receipt,
- or beside a repair / reversal surface.

## Contract

At minimum an affected-set witness should be able to say:
- **witness mode**
  - predicted
  - reviewed
  - observed aftermath
  - mixed predicted/observed with difference visible
- **target family**
  - objects
  - rows / cards / results
  - views / glances / watchpoints
  - packets / routes / receipts
  - reveal targets / audience routes
- **set form**
  - exact ids / refs
  - count plus drilldown
  - grouped by family / page / lane / service
- **difference posture**
  - matched prediction
  - smaller than predicted
  - broader than predicted
  - partially unknown
- **basis relation**
  - exact basis stamp if one exists
  - freshness / stale posture if computed earlier
  - dynamic-rule note if future matching members may exist

## Rules that matter

### 1. Keep the set inspectable
One vague “multiple things affected” badge is not enough.
Even when the strip is compressed,
there should be a nearby drilldown.

### 2. Predicted and observed should stay separable
The shell should be able to say:
- what it thought would be touched,
- what later was actually touched,
- and where they differ.

### 3. Count-only is acceptable when exact list would be noisy
But count-only should not erase the existence of a drilldown or grouped view.

### 4. Historical witnesses stay historical
An affected-set witness can be durable,
but it is still weaker than current-live truth.

## Best first homes

- action warrants
- effect receipts
- slot verdict ledgers
- reveal windows
- attention windows
- repair ladders
- Operations Center strips and tables

## What this is not

- not a giant lineage graph
- not a universal asset inventory
- not a substitute for cohort windows
