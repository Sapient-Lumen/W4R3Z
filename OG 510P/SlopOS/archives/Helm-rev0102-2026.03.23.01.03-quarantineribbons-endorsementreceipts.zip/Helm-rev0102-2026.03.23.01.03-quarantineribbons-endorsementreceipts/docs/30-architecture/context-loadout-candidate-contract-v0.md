# Context loadout candidate contract v0

Purpose: give Helm one shell-owned explicit current-context object for a bounded ask, compare, route, or action.

A **context loadout** is not a giant workspace.
It is not ambient memory.
It is not current-live truth.
It is the shell-owned answer to:

**what exact ingredients are intentionally in play for this one bounded act?**

## Candidate posture

### 1. Assembly is explicit
A loadout should come from authored selection such as:
- use current tab only
- add selected tabs
- add these files / objects / views
- add this memory seed
- enable these tools
- include this instruction or prompt fragment

Ordinary visibility,
recents,
preview,
or adjacency should not silently create or widen a loadout by default.

### 2. Members are typed
Useful early member families may be:
- current surface/tab members
- file/object/view members
- memory seed members
- route/provider hint members
- tool members
- instruction/prompt members
- activity/spine references

### 3. Scope is first-class
A loadout should carry one explicit scope posture such as:
- one-off current request
- current session local
- activity-local saved loadout
- shared/imported restricted
- published starter

A one-off loadout should stay weaker than an activity spine or saved entry kit.

### 4. Source and authorship stay revealable
A loadout should be able to show:
- who assembled it
- when
- from which surface(s)
- which members were added explicitly
- which members were inherited from a saved loadout or starter if inheritance was allowed

### 5. Tools and instructions count as context
If a request depends on:
- enabled tools,
- a prompt fragment,
- an instruction file,
- or a referenced agent/persona,
that should be visible as part of the loadout rather than hidden ambient backend weather.

### 6. Loadout use does not imply memory or adoption
Using a loadout once should not automatically:
- create memory seeds,
- widen activity scope,
- trust imported members,
- or save the bundle as a future default.

### 7. Loadout truth is different from influence truth
A loadout says what was intentionally made available.
It does not by itself prove what the system actually used.
A result/action may therefore open a nearby **contribution witness**.

### 8. A loadout is not automatically the exact cohort
A bounded act may still choose or require a smaller exact subset than the full loadout.
That smaller admitted subject set should stay visible in a nearby **cohort window** instead of being flattened into one generic selected state.

## Candidate minimal shape

A first useful loadout likely needs:
- exact id
- purpose or bounded act type
- member list (typed)
- tool list
- instruction/prompt refs
- scope posture
- trust/import posture
- author
- created_at
- optional saved status
- optional owning activity spine / entry kit ref

## Best first homes

- one Omnibox ask using current tab vs selected tabs vs saved view
- one Recall compare using a checkpoint plus one saved view plus one warning seed
- one Exchange route action with explicit selected objects and route/tool hints
- one Google-Sheets-style pre-apply action rehearsal where the loadout is visible before apply

## Guardrails

1. **No ambient crawl-by-default**
2. **No hidden widening from nearby state**
3. **No treating tools as invisible non-context**
4. **No imported/shared loadout silently becoming local default**
5. **No confusing loadouts with spines, shelves, or live beacons**
6. **No giant context ontology before one tiny specimen works**

## Working stance

Context loadouts now look like one of the best next support objects for Helm.
They can make AI-assisted shell work feel dramatically smarter while still learning the right lesson from SlopOS:

**current context should be selected and inspectable, not ambiently guessed and then laundered into authority.**
