# Deck recipe candidate contract v0

Purpose: give Helm one compact way to preserve the best of saved views,
layouts,
and templates **without** letting a reusable starter impersonate live continuity.

A **deck recipe** is a shell-owned typed recipe that can materialize a **view deck** or deck-like cluster around one exact subject family,
one activity relation,
or one explicit query basis.

It is a recipe,
not the live deck itself.
It is a saved starter,
not current authority.

## Candidate posture

1. **A recipe is saved arrangement intent, not live state**
   - it can describe what kinds of deck members to materialize
   - it does not claim those members are currently live,
     bound,
     trusted,
     or already open

2. **A recipe stays typed and shell-owned**
   - subject family,
     activity relation,
     or query basis should stay explicit
   - member types should stay typed:
     query view,
     preview,
     receipt slice,
     ops slice,
     live lens,
     drift beacon,
     compare member,
     or similar

3. **Materialization is a second explicit step**
   - invoking the recipe materializes a current deck or deck-like cluster
   - the result may still need basis checks,
     live binding,
     or locality-aware promotion
   - the recipe itself should not silently reacquire continuity

4. **Locality tier should be visible**
   - recipes may be personal/local,
     activity-local,
     portable,
     or shared
   - promotion between tiers remains explicit

5. **Recipes should compose with nearby Helm moves**
   - view decks
   - materialization bays
   - surface locality tiers
   - exact action keys
   - snippet seeds
   - live lenses
   - drift beacons
   - activity entry kits

6. **Recipes should help repeated work without becoming a second workspace system**
   - good for repeatable investigations,
     handoff views,
     harbor review clusters,
     or object-centric work packets
   - bad if they start claiming global restore or whole-environment continuity

## Candidate uses

- a local recipe that materializes a three-member exact-object deck: Preview / Relations / Drift
- an activity-local recipe that materializes a harbor deck: Candidate / Compare / Receipt / Adopt
- a portable recipe exported from one operator's local deck arrangement
- a shared team recipe that provides a common starting cluster without claiming a shared live session

## Guardrails

- do not turn recipes into a second workspace or dashboard constitution
- do not let recipes silently auto-open stale remote or local state
- do not let saved starters impersonate current continuity
- do not flatten member types into one generic tile wall
- do not require every useful deck to be shareable just because some are

## Candidate v0 specimen

A first useful specimen could be:
- one personal/local recipe,
- one materialized deck with three typed members,
- one explicit promotion to portable,
- and one refusal where the recipe remains local because the arrangement is too profile- or trust-shaped to travel safely.

## Working stance

Deck recipes now look like the cleanest way for Helm to steal the best parts of saved-view systems,
templates,
and reusable investigation setups without letting any of those surfaces overclaim live truth.
They should stay a candidate contract until one modest specimen proves they make Helm faster and clearer without creating a second workspace religion.
