# Inherit mask candidate contract v0

Purpose: define one compact shell-owned declaration of which bounded classes may honestly use **receiver defaults** when a Helm surface lands,
without pretending those classes traveled and without smuggling sensitive local truth through ambient fallback.

An **inherit mask** is the explicit allowed-defaults side of landing.
It should compose with:

- residue ledgers
- local overlays
- landing manifests
- receiver fit cards
- rebind ladders
- portable cores
- exact action keys
- command dock items/bands
- and deck recipes

## Why this move now

Helm now has a strong omission story:
residue ledgers can explain what stayed behind.
But omission has at least two honest shapes:

1. something stayed behind and must be rebound or recreated
2. something stayed behind and it is fine to use the receiver’s ordinary default

Current tools keep validating the second case when it stays explicit.
VS Code partial profiles can include only some configuration classes and use the rest from the Default Profile.
User and workspace settings are also sharply scoped.
That is not ambient magic.
It is explicit bounded inheritance.

Helm needs the same escape hatch,
or it risks turning every landing into unnecessary rebind theater.

## Candidate shape

A first useful inherit mask would likely include:

1. **Owner surface witness**
   - portable core id
   - packet id
   - landing manifest id
   - deck recipe id
   - exact action key id
   - or another admitted owner

2. **Allowed inherit classes**
   - keyboard shortcut class
   - non-sensitive visual chrome
   - dock edge / panel placement default
   - theme / icon style
   - harmless launcher chrome
   - or another explicitly admitted low-risk class

3. **Denied inherit classes**
   - trust posture
   - credentials / secrets
   - account/profile/session identity
   - strong route/provider authority
   - recent/history residue
   - local reviewed basis
   - or anything else that must not fall back ambiently

4. **Scope**
   - receiver-global default
   - workspace/activity default
   - profile default
   - device-local default
   - or another admitted bounded scope

5. **Fallback posture per class**
   - may inherit automatically
   - may inherit after inspect
   - must prompt
   - never inherit

6. **Tiny next actions**
   - inspect defaults that would be used
   - accept receiver defaults
   - override with local overlay
   - open rebind ladder instead
   - reject landing

## Rules that matter

### 1. Inherit masks are explicit,
not ambient fallback folklore
A class may use receiver defaults only if the mask says it may.
Silence is not permission.

### 2. The allowlist should stay small
The first version should admit only low-risk,
low-authority,
high-ergonomic classes.

### 3. Inheritance is weaker than carriage
If a class is inherited,
Helm should not describe it as carried.
The landing story should remain honest about that difference.

### 4. Sensitive or authority-bearing classes stay out
Trust,
identity,
credentials,
strong routing,
and reviewed-basis truth should not slip into “just use receiver defaults.”

### 5. Inherit masks should compose cleanly with local overlays
A default may be acceptable at first landing,
and later become a receiver-local overlay.
That stronger local choice still remains local truth,
not carried truth.

## Best first homes

- exact action keys whose keyboard shortcut may inherit locally
- dock items whose edge or chrome may inherit receiver defaults
- deck recipes whose visual arrangement may inherit local layout defaults
- entry kits whose harmless chrome may inherit while subject/provider slots still rebind explicitly

## What this is not

- not a secret sync mechanism
- not a permission bypass
- not an excuse for hidden ambient behavior
- not a substitute for residue ledgers,
  fit cards,
  or rebind ladders
- not proof that receiver defaults are identical across machines

## A good first proof slice would show

- one portable surface omitting a shortcut or layout class,
- one inherit mask allowing that class to use receiver defaults,
- one denied class that still requires rebind,
- and one local-overlay promotion path if the operator later wants a stronger receiver-local choice.

## Why this seems worth keeping warm

Inherit masks now look like the missing graceful middle between “carry everything” and “rebind everything.”
They let Helm stay strict about truth while still feeling pleasant on arrival.
