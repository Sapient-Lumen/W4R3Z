# ADR-XXXX: <title>

Decision node(s): D-...

## Context
Problem, constraints, and decision drivers.

## Decision
What we chose, precisely.

## Interfaces / schemas impacted
- IF-...
- CH-...

## Consequences
Positive, negative, follow-ups.

## Evidence
Links to RFC(s), EVID entries, and any proof/model artifacts.

## Affected registries
- Claims: C-...
- Invariants: I-...
- Assumptions: A-...
- Proof obligations: PO-...
