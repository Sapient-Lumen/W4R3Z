# ADR-0001: Archive lint gates (IDs/links/URLs/schemas)

## Context
This archive relies on small registries (C-/I-/PO-/IF-/CH-/EVID-/REF-) to keep claims and evidence mechanically traceable.
Without a guardrail, drift accumulates silently:
- undefined IDs (“ghost claims”)
- broken internal links
- raw URLs scattered in prose (bypassing REF discipline)
- CH-* schema rows without pinned, versioned specs

Constraints:
- keep tooling tiny and auditable
- avoid turning CI into a research project

## Decision
Adopt a minimal lint gate as a required check for repository changes:
- validate that all **concrete** IDs referenced in markdown are defined in their canonical registries/maps (family refs like `<I-FOO-*>` are ignored)
- validate internal links do not break or escape the repo
- forbid raw URLs outside `docs/00-meta/bibliography.md`
- require `schema-registry.md` entries to point to a spec doc that names `CH-* v0`

Implementation: `tools/lint_archive.py` and `make lint`.

## Consequences
Positive:
- prevents silent traceability breakage
- keeps additions tight (forces REF discipline)
- makes schema pinning explicit early (supports proof-shaped ABI work)

Negative:
- adds a small amount of friction for edits that introduce new IDs (must update registries)

Follow-ups:
- extend lint with optional checks only when they prove their value (e.g., "every C-* must have at least one PO-*"), keeping scope bounded.

## Evidence
- EVID-2026-003 (E1): archive lint gates implementation

## Affected claims/invariants
- Claims: none directly (process decision)
- Invariants: I-IF-1, I-ENC-1
- Assumptions: none
