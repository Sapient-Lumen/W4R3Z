# ADR-0004: CH-CFG is compiled output; generations tracked outside the privileged core

Decision node(s): IF-CFG (core interface), D-ATOMICUPD (adjunct), D-EXPLAIN (adjunct)

## Context
Privileged configuration is an unavoidable authority surface: it can widen access, change routing, and alter security posture.

Common failure modes in OS ecosystems:
- ad-hoc mutation (imperative “edit live files” workflows) makes drift hard to audit
- human-authored low-level config formats are error-prone and difficult to review
- rollback is scary because configuration updates are intertwined with mutable state and one-off scripts

We want:
- **deterministic** and reviewable config outcomes
- **small TCB** (kernel only validates/applies; tooling does evaluation)
- **rollback as a normal UX** (generations)
- compatibility with D-EXPLAIN (diff+receipt for authority-widening changes)

Inspiration: Nix/NixOS “declarative config + generations” posture.

## Decision
1) Treat **CH-CFG** as the *compiled output* of deterministic tooling (a “config compiler”).
   - authoring formats and module systems are tooling concerns
   - normative bytes are canonical CH-CFG (D-ENC)
   - profile default matrices remain review surfaces, not CH-CFG template semantics (`docs/30-architecture/profile-default-artifact-boundary-v0.md`)

2) Keep the privileged core limited to **decode → validate → apply** for IF-CFG.
   - no module evaluation, templating, or dynamic fetch in privileged code

3) Adopt a **generations** workflow for config:
   - each application of CH-CFG creates a new generation record
   - prior generations remain selectable for rollback
   - retention/GC remains a user-space policy

4) For any config change that widens authority, require a D-EXPLAIN preview/receipt workflow.

## Interfaces / schemas impacted
- IF-CFG
- CH-CFG v0 (no schema change required)
- CH-CAPDIFF v0 / CH-RECEIPT v0 (adjunct via D-EXPLAIN)
- CH-BOOT/CH-BOOTSEL (binding active cfg digest; optional pending/tries activation)

## Consequences
Positive:
- config becomes auditable (digest + signature + receipts)
- rollback becomes routine (generation selection)
- privileged TCB stays small

Negative / trade-offs:
- “configuration language” debates move into tooling; discipline must prevent it from becoming a hidden policy brain
- data/schema migrations remain an operational hazard; must be made explicit (snapshot before irreversible migrations)

Follow-ups:
- document the pipeline and ops workflow (`docs/60-engineering/configuration-pipeline.md`)
- add CI guardrails for deterministic compilation and authority-widening changes

## Evidence
- RFC-0003 (feature seed: declarative config + generations)
- RFC-0069 (D-EXPLAIN / CH-CAPDIFF)
- RFC-0051 + RFC-0074 (CH-BOOTSEL pending/tries/commit)

## Affected registries
- Proof obligations: PO-CFG-VERIFY (unchanged), plus D-EXPLAIN obligations where used
