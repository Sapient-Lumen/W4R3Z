# ADR-0006: Cross-cluster replication contracts as an explicit artifact seam (CH-REPLCONTRACT v0)

Decision node(s): D-REPL, D-MK, D-COMMUTE

## Context
Hybrid multicore (ADR-0005) requires that cross-cluster shared state be **explicit**, otherwise a “hidden global kernel” reappears via ad-hoc coordination.
The archive already pins:
- a deterministic cluster partition artifact (CH-CLUSTERMAP v0), and
- a commutativity discipline that names unavoidable serialization points (D-COMMUTE + hot action surfaces).

What remained underspecified was: **how do we state and validate cross-cluster replication/consistency for metadata that must be visible across clusters?**
Without an explicit contract, implementations tend to drift into implicit global services, silent caching, and order-dependence that is hard to prove or audit.

## Decision
We adopt a conservative v0 replication-contract vocabulary and make it a first-class artifact seam:

1) **Introduce CH-REPLCONTRACT v0** as a bounded, non-authoritative cross-cluster replication contract.
   - It binds to a concrete CH-CLUSTERMAP digest.
   - It enumerates a small set of object families and assigns each a replication class and (when needed) an owner rule.

2) **Adopt a small set of replication classes (RC0..RC4)**:
   - RC0 local-only
   - RC1 owner-sharded (single-writer)
   - RC2 epoch snapshots (replace-with-epoch)
   - RC3 commutative merge (SEC-style; CRDT-like patterns where appropriate)
   - RC4 ordered log (append-only; explicit global order)

3) **Fail-closed posture**:
   - If CH-REPLCONTRACT is missing/invalid for a profile that requires cross-cluster visibility, cross-cluster operations that depend on it must deny/stop rather than guess.

## Interfaces / schemas impacted
- CH-CLUSTERMAP v0: replication contracts reference stable cluster identifiers via a cluster-map digest.
- D-COMMUTE: RC3/RC4 choices must align with declared commutativity/non-commutativity boundaries.
- Transcripts/receipts: avoid accidental global serialization; ordered log semantics are explicit (RC4) rather than implied.

## Consequences
Positive:
- Makes cross-cluster ownership and replication reviewable and testable.
- Prevents silent ambient “global services” from creeping into Hybrid.
- Creates a stable diff surface for profile review and CI drift gates.

Costs / limitations:
- RC vocabulary is intentionally small; some distributed designs will not fit without future schema extension.
- Requires discipline to keep `object_family` names bounded and meaningful.

## Evidence
- Multikernel motivation: explicit ownership + message structure for scalable multicore (REF-MULTIKERNEL-SOSP09).
- Commutativity discipline: interface properties determine coordination needs (REF-SCR-TOCS15).
- CRDT background for commutative merge patterns (REF-CRDT-INRIA11).
- Transparency-log patterns for explicit ordered replication when required (REF-CT-RFC6962).

## Links
- `docs/30-architecture/replication-contracts-v0.md`
- `docs/30-architecture/replication-contract-schema-v0.md`
- `docs/30-architecture/cluster-derivation.md`
- `docs/30-architecture/hot-action-boundaries-v0.md`
