# ADRs

ADRs are the permanent record of committed decisions. Each ADR must link to evidence and list affected claims/invariants.

Format: Context → Decision → Consequences → Evidence → Links.

## Index
| ADR | Topic | Status | Date |
|---|---|---|---|
| [0001](0001-archive-lint-gates.md) | ADR-0001: Archive lint gates (IDs/links/URLs/schemas) | — | — |
| [0002](0002-phase1-static-partition-profile.md) | ADR-0002: Phase 1 deliverable is the static partition profile (D-PART) | Accepted | — |
| [0003](0003-d-enc-canonical-cbor-and-json-authoring.md) | ADR-0003: D-ENC canonical CBOR bytes; optional JSON authoring | Accepted | 2026-02-25 |
| [0004](0004-config-as-compiled-artifact-and-generations.md) | ADR-0004: CH-CFG as compiled artifact; generations for rollback UX | Accepted | 2026-02-26 |
| [0005](0005-hybrid-multicore-and-commutativity-discipline.md) | ADR-0005: Adopt Hybrid multicore + interface-first commutativity discipline | Accepted | 2026-02-27 |
| [0006](0006-cross-cluster-replication-contracts-v0.md) | ADR-0006: Cross-cluster replication contracts seam (CH-REPLCONTRACT v0) | Accepted | 2026-02-27 |
