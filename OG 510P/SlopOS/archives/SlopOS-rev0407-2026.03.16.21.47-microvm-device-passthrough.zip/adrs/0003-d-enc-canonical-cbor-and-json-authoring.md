# ADR 0003: D-ENC — canonical CBOR bytes; optional JSON authoring

Status: accepted (archive decision)

## Context
Many CH-* artifacts cross trust boundaries and are hashed/signed (boot manifests, policy bundles, receipts, etc.).

If multiple encodings are treated as equivalent, we risk:
- hash/signature ambiguity (same structure, different bytes),
- parser differentials across languages/runtimes,
- tooling drift ("it worked for me" when a decoder silently accepts non-canonical forms).

At the same time, some artifacts benefit from a human-friendly authoring syntax.

## Decision
- **Normative bytes for CH-* are canonical CBOR** per REF-CBOR-RFC8949 (see RFC-0001 + `encoding-policy.md`).
- **Signed containers use COSE** (REF-COSE-RFC9052) over the canonical CBOR bytes.
- Tooling MAY accept JSON for human authoring, but it is **never** a signed/wire format. If JSON is accepted, tooling MUST:
  1) canonicalize it using JCS (REF-JCS-RFC8785) and the archive’s “no floats” restrictions, then
  2) deterministically transcode to canonical CBOR prior to hashing/signing.

## Consequences
- All validators and verifiers can be written against one canonical byte format.
- Reviewable artifacts remain pleasant to edit (JSON), without risking signature ambiguity.
- Schemas can stay closed-world by default (reject unknown keys), improving fail-closed behavior.

## Links
- D-ENC (decision map)
- RFC-0001 (encoding baseline)
- `docs/30-architecture/encoding-policy.md`
