# Contributing

This repository is an archive of *our* specs, invariants, decisions, and evidence pointers.

## Contribution types
- **Research note**: add a REF entry in `docs/00-meta/bibliography.md` (≤3 bullets: key idea / why / implication).
- **RFC**: propose a change with alternatives + evidence plan (`rfcs/`).
- **ADR**: record a decision once evidence exists (`adrs/`).
- **Evidence**: register artifacts in `docs/00-meta/evidence-index.md` with hashes/commits.

## Hard rules
- Every new **security/correctness claim** must map to Claim IDs + Invariant IDs.
- Every new **assumption** must be added to the threat model (with an ID).
- Prefer **citations** over quotes; avoid copying large bodies of external work.

## Review gates
- New `unsafe` requires an updated `unsafe` obligation entry + reviewer signoff.
- Anything that changes isolation/authority requires threat model + invariants update.
