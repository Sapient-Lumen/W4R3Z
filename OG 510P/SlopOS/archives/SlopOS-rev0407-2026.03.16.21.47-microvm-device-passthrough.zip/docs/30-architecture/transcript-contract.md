# Transcript/logging contract (CH-LOG v0)

Purpose: make auditing/replay *mechanically checkable* without silently widening observation/exfil surfaces.

Primary surfaces: IF-ACP emits log entries for accepted/rejected actions; IF-OBS exports log entries subject to redaction policy.

## Minimal entry shape (v0; closed fields)
A log entry `e` contains:
- `schema`: fixed `CH-LOG v0`
- `ts`: optional monotonic timestamp (only if D-TIME enables; otherwise omitted)
- `action_schema`: e.g. `CH-ACP v0`
- `action_digest`: digest of canonical bytes of the action value
- `reqctx_digest`: digest of `CH-REQCTX v1` for the action (non-authoritative correlation + veto-only context; required by CH-ACP)
- `conflict_key_digest?`: optional digest of `CH-CONFLICTKEY v0` when the action kind has a declared conflict key (D-COMMUTE)
- `order_digest?`: optional digest of `CH-ORDERTOK v0` when the action is **ordered** and carries an ordering witness (D-COMMUTE)
- `authz_ref`: opaque reference to the approval/capability used (no secret material)
  - recommended: `authz_ref = digest(CH-AUTHZ)` when CH-AUTHZ v0 is used (do not log raw proofs)
- `result`: deterministic code (accept/reject + reason)
- `deny_digest?`: optional digest of **CH-DENY v0** when `result` is a rejection and a structured denial receipt was emitted
- `effects_digest`: optional digest of the canonical effect request emitted (if separate from action)

## Core invariants
- **I-LOG-1 (Replayable transcript binding):** `e` contains enough information to deterministically replay `validate` on the corresponding action and obtain the recorded `result` (supports PO-LOG-REPLAY).
- **I-OBS-1 (Observation redaction):** exporting log entries must not leak secrets; any secret-bearing content must be excluded or explicitly authorized.

Denial note (CH-DENY):
- `deny_digest` is a **non-authoritative** observability field used to bind structured, redaction-safe denial explanations to transcript entries.
- Validators and replayers MUST NOT treat CH-DENY as authorization evidence.

Outcome receipt note (CH-ACPOUT):
- Some profiles may additionally emit an ACP outcome receipt (**CH-ACPOUT v0**) indexed by `action_digest` (and optionally exported under CH-OBSPOL tiers).
- CH-LOG remains the minimal replay/audit substrate; CH-ACPOUT is an optional digest-only envelope for tooling/UI.
Request-context note (CH-REQCTX):
- `reqctx_digest` is a **non-authoritative** observability field used for correlation, deadline/cancel intent, and veto-only call-chain hooks.
- Validators and replayers MUST NOT treat CH-REQCTX as authorization evidence (I-REQCTX-3).


Commutativity/ordering note (D-COMMUTE):
- `conflict_key_digest` and `order_digest` are **non-authoritative** observability fields used for commutativity evidence, diff stability, and ordered-boundary validation.
- Validators and replayers MUST NOT treat either digest as authorization evidence (I-CONFLICTKEY-1; I-ORDERTOK-1).

## Canonicalization / hashing

Ordering / concurrency note:
- A transcript is treated as a **content-addressed event set**: appending independent entries is commutative.
- Export order is **derived**, not authoritative: exporters sort entries canonically for stable diffs/replay bundles (e.g., by `(ts, action_digest)` when `ts` is present, otherwise by `action_digest`).
- This allows sharded/parallel ingestion in Hybrid profiles without introducing a global “log lock”; any truly ordered sequences must be made explicit at the action level (not by relying on append order).
- Under Hybrid replication, CH-LOG entries remain **evidence only**: replicated arrivals may aid audit/replay/export, but they MUST NOT satisfy local approval/policy/capability checks, authorize replay/resubmission, or become a runtime sequencing oracle (see `transcript-replication-boundary-v0.md`).
- The `action_digest` is computed over **canonical bytes** of CH-ACP (I-ENC-1; PO-ENC-DECODE).
- If `effects_digest` is used, it is computed over canonical bytes of the emitted effect request enum.

## Non-goals (v0)
- “Tamper-proof remote logging” is not claimed unless an ADR adopts it (would require explicit crypto + trust assumptions).
- “Complete provenance of all microarchitectural observations” is out of scope.

## Evidence hooks
- E1: property tests: replay validator against logged actions yields the same `result`.
- E2: bounded model check of validator semantics + log relation (ACP slice).
