# D-RSEQ posture v0 (runtime-owned single-slot rseq; no ambient CPU oracle)

Purpose: pin an implementable v0 meaning for **D-RSEQ** so CPU-local fast paths stay a small runtime optimization rather than widening into a public scheduler oracle, a kernel-managed per-CPU object family, or a hidden workflow seam.
It narrows RFC-0113 into a compact posture validators and harnesses can reason about: one thread-local registration slot, runtime-owned coordination, explicit abort-to-slow-path behavior, and profile-gated nondeterminism.

## Posture (v0)

1) **Optional runtime-internal seam, not a general app API**
   - If D-RSEQ is enabled, it is a **runtime/library fast-path primitive** for a component that already owns the thread context.
   - Phase 1 does **not** standardize a general application-facing `getcpu` / `sched_getcpu` / `current_cluster` API on the core seam.
   - D-RSEQ metadata is performance metadata, not authorization evidence (I-RSEQ-1).

2) **Exactly one thread-local registration slot per thread**
   - v0 assumes **one registered rseq area per thread**.
   - That slot is runtime-owned: multiple libraries inside the same process/component MUST coordinate through the owning runtime rather than independently registering competing areas.
   - v0 does **not** define nested registrations, per-library registration, or kernel multiplexing of multiple rseq areas.

3) **CPU/vCPU cache only; no ambient NUMA/node/cluster oracle**
   - The registered area MAY cache a **cpu_id** or **vcpu_id** sufficient for bounded CPU-local fast paths.
   - Phase 1 declines exposing cached NUMA node ids, cluster ids, socket ids, or other richer topology identifiers through D-RSEQ.
   - Any richer placement/topology facts remain governed by CH-HWFACT / CH-CLUSTERMAP posture docs, not this seam.

4) **Single crisp commit point; abort is the only pre-commit outcome**
   - Every restartable region MUST declare one explicit commit point and one explicit abort target (I-RSEQ-2).
   - If the thread is preempted, migrated, interrupted, or otherwise invalidated before commit, the kernel/runtime MUST redirect control to the abort target with an explicit reason code.
   - User-space MUST treat pre-commit execution as uncommitted; “partial commit counted as success” is forbidden.

5) **Short, non-blocking, no nesting in v0**
   - Restartable regions MUST be short and MUST NOT block, invoke IPC, enter portals, sleep, or loop indefinitely.
   - v0 assumes **nesting depth = 0**.
   - Implementations MUST fail closed if a region would fault or otherwise leave the bounded fast-path contract.

6) **Abort-to-slow-path is explicit; no hidden retry engine**
   - D-RSEQ is a performance fast path, not a correctness crutch.
   - Abort handlers MUST fall back to an explicit slow path (typically atomics/locks plus D-UWAIT where needed), or retry under user-space control.
   - Phase 1 does **not** add a kernel-side automatic retry engine or a public membarrier workflow surface dedicated to D-RSEQ.

7) **Profile-gated nondeterminism and replay discipline**
   - Exposing cpu/vcpu ids and fine-grained abort behavior is part of the **D-NONDET** posture and MUST be profile-gated (PO-RSEQ-NONDET).
   - Profiles that require replay determinism under D-RR MUST disable D-RSEQ, virtualize it, or constrain it to a deterministic static-partition mode with explicit evidence.
   - D-RSEQ v0 therefore remains optional and profile-shaped rather than universal.

8) **CPU-set / hotplug / migration changes fail closed**
   - If the scheduler, CPU set, hotplug state, or virtualization layer invalidates the cached execution context, the region MUST abort to the explicit slow path.
   - D-RSEQ v0 does not promise continuity across migration or topology change.
   - This keeps D-RSEQ from becoming an ambient placement guarantee or a hidden scheduler contract.

9) **Bounded, attributable, and supervision-visible**
   - Registration state, region descriptors, and abort counters MUST be bounded per thread/process and attributable when D-METER is enabled (I-RSEQ-3; PO-RSEQ-BOUND).
   - High abort rates are evidence that the fast path is a bad fit under current scheduling pressure and SHOULD be visible to supervision/diagnostics.
   - Exhaustion or policy denial fails closed and deterministically.

10) **No new workflow / ACP / conflict-key surface in v0**
   - D-RSEQ v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
   - Therefore **no new conflict-key family is introduced in v0**.
   - Any future admin or export surface (for example, explicit rseq registration policy, tracing, or cross-domain coordination) must land RFC-first with its own serialization boundary, commutativity story, receipts, and policy kill switches.

11) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY use an internal host/runtime rseq shim behind the membrane, but Phase 1 does **not** standardize an ambient compat-visible CPU-id API, TLS trick, or hidden env/path bridge for rseq.
   - Any compat enablement remains policy-killable and must not recreate ambient scheduler/topology channels that bypass D-NONDET posture.

## Phase 1 non-goals (explicitly deferred)

- A general public `sched_getcpu` / topology-query API on the core seam.
- Nested or multiplexed rseq registrations.
- NUMA node / cluster / socket caches in the rseq area.
- A kernel-managed per-CPU object family or allocator API.
- A public membarrier / retry-control workflow surface dedicated to D-RSEQ.

## Wiring

- Decision surface: `decision-map.md` (D-RSEQ).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (restartable-sequence seam)
  - `rfcs/0113-restartable-sequences-and-cpu-local-fast-paths.md` (option space / evidence seed)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-RSEQ-1, I-RSEQ-2, I-RSEQ-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-RSEQ-BOUND, PO-RSEQ-NONDET)
  - `docs/30-architecture/nondet-posture-v0.md` (D-NONDET gating)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_rseq_posture.py` fails `make lint` if this posture stops being discoverable, loses the single-slot / no-ambient-CPU-oracle / no-new-workflow posture, or drops its primary REF wiring.

## References

- REF-LINUX-RSEQ-DOC.
- REF-LINUX-RSEQ-MAN.
- REF-REDHAT-RSEQ-GLIBC.
- REF-MAN7-MEMBARRIER.
