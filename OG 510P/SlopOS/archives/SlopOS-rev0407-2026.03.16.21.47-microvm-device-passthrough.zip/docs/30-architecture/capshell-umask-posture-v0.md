# Capshell umask posture v0 (no inherited file-creation mask)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools that create files or directories.
The archive already says execution context is explicit and reviewable, but that promise still drifts
if the child process inherits an ambient host/login/shell **file mode creation mask** (`umask`) that
never appears in the reviewed execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic
credential/profile service, a per-profile compatibility table, or a new workflow knob for tuning
legacy POSIX defaults. It only freezes the minimum Phase 1 posture needed so file-creation behavior
stops depending on hidden launcher/session state across all four product shapes.

## Posture (v0)

1) **No inherited host/session umask in Phase 1**
   - `capshell.exec` MUST NOT inherit the parent process, login shell, wrapper, or host session
     file mode creation mask.
   - A host-specific `umask` is ambient process state and therefore cannot silently participate in
     reviewed workflow behavior.

2) **Phase 1 launch mask is fixed and explicit: `0o077`**
   - Before `exec`, the runner/wrapper MUST set the child file mode creation mask to **`0o077`**.
   - Phase 1 therefore makes newly created filesystem objects **owner-only by default** unless the
     launched program later widens permissions through its own explicit logic.
   - The portable boundary is the fixed launch posture, not “inherit whatever the host shell had.”

3) **Other explicit seams do not secretly mint umask**
   - **CH-ENV v0** does not authorize deriving a file mode creation mask from environment values.
   - **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and **CH-REQCTX v1** do not authorize deriving
     or repairing a creation mask from cwd/tty/request/session state.
   - Any future explicit creation-mode surface must return RFC-first rather than widening
     `capshell.exec` by implication.

4) **No silent compatibility baseline or shell-profile carry-over**
   - The runner MUST NOT preserve a legacy host default such as `0o022`, `0o002`, or “whatever the
     parent shell configured”.
   - Wrapper-first adoption and foreign-cell compatibility layers MUST either apply the same fixed
     `0o077` launch mask or fail closed.
   - Rc/profile files, shell builtins, or per-directory hooks cannot pre-seed the launch mask before
     the reviewed execution boundary.

5) **Programs may still change their own mask after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen interpreter or program after it begins running.
   - If an explicitly selected shell, interpreter, or tool later calls `umask()` / `umask` inside
     reviewed program logic, that is part of the chosen program’s semantics rather than ambient
     runner inheritance.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.umask.*` ACP kind, no profile knob for varying the launch mask, and no
     reviewed umask descriptor surface.
   - If later evidence shows real need for reviewed non-`0o077` creation posture, that work must
     come back as one new explicit decision surface rather than by silently inheriting host state.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that file-creation behavior no longer depends on ambient parent
     process state.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT pass the host file mode creation mask through as hidden state.
   - If a foreign runtime cannot force the fixed launch mask before program start, it MUST fail
     closed instead of quietly inheriting the host/session setting.

## Phase 1 non-goals (explicitly deferred)

- No profile-specific compatibility table of default `umask` values.
- No portable API for reading the launcher’s prior host/session mask.
- No reviewed umask descriptor or per-step creation-mode selector in Phase 1.
- No promise that legacy programs expecting `0o022` or `0o002` will work unchanged without
  explicit in-program adjustment.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `env-schema-v0.md`
  - `cwd-schema-v0.md`
  - `stdio-schema-v0.md`
  - `fdset-schema-v0.md`
  - `capshell-env-baseline-posture-v0.md`
  - `capshell-startup-profile-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-UMASK-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-UMASK-FIXED` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_umask_posture.py` (**EVID-2026-329**).

## References

- REF-OPENGROUP-UMASK
