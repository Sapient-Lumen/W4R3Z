# CH-ATTESTPACK v0: attestation bundle (CH-ATTEST + opaque evidence)

Purpose: define a **small, canonical bundle** returned by **IF-ATTEST** so tooling and verifiers can:
- consume a normalized **boot-binding summary** (CH-ATTEST v0),
- carry **provider-native attestation evidence** as opaque bytes (TPM quote / SNP report / TDX quote / CCA token / etc),
- and keep export surfaces **bounded** and **policy-killable**.

This schema is a **packaging artifact**, not a full protocol spec. Transport, endorsement retrieval, and verifier policy language remain out of scope.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected by validators (fail-closed).

## Shape (v0)

```text
CH-ATTESTPACK-v0 {
  schema: "CH-ATTESTPACK";
  version: 0;

  # Normalized summary (canonical bytes)
  attest_bytes: bytesN;         # canonical bytes of CH-ATTEST v0
  attest_digest: bytes32;       # digest(attest_bytes); MUST match

  # Provider-native evidence (opaque bytes; optional but common)
  evidence?: [
    {
      kind: enum {
        tpm2_quote,
        sev_snp_report,
        tdx_quote,
        cca_token,
        dice_attestation,
        other
      };
      bytes: bytesN;            # opaque provider-native bytes
    }
  ];

  # Optional endorsement/reference pointers (content-addressed)
  endorsement_aref_digests?: [ bytes32 ];   # each is digest(CH-AREF v0)

  # Optional notes (non-authoritative; bounded)
  notes?: {
    provider_hint?: tstr;       # e.g., "TPM2", "SNP", "TDX", "CCA" (bounded)
    profile_hint?: tstr;        # e.g., "cose_sign1" / "jwt" (bounded)
  };
}
```

## Bounds (v0; keep export surfaces tight)

- `attest_bytes` length MUST be ≤ **4096** bytes.
- `evidence` list length MUST be ≤ **4**.
- Each `evidence[i].bytes` length MUST be ≤ **32768** bytes.
- `endorsement_aref_digests` length MUST be ≤ **8**.
- `notes.*` strings MUST be ≤ **64** bytes each.

Profiles may tighten these bounds further.

## Validation rules (summary)

- `schema` and `version` must match exactly.
- `attest_digest == digest(attest_bytes)` must hold.
- `endorsement_aref_digests` entries must be exactly 32 bytes each.

## Verification posture (how verifiers should treat this)

- **CH-ATTESTPACK is not itself a trust root.**
- Verifiers MUST validate **provider-native evidence** (when present) using their chosen appraisal policy, and MUST treat `attest_bytes` as a **normalized summary** that can be checked against derived measurement results.
- If a verifier cannot validate any attached provider evidence, it MAY still accept **CH-ATTEST summary-only** flows **only if** its policy explicitly allows a software signing root (deployment choice).

## Wiring

- Schema registry: `schema-registry.md` → **CH-ATTESTPACK v0**.
- Interface registry: `interface-registry.md` → **IF-ATTEST** returns/exports this bundle under the lane gate `cfg.params.lane.attest.export`.
- Related posture: `attestation-posture-v0.md` (D-ATTEST v0 meaning pin; “no privileged provider parsing”).

## References

- REF-RATS-RFC9334
- REF-EAT-RFC9711
- REF-COSE-RFC9052
- REF-COSE-RFC9053
- REF-TPM2-PART1
- REF-AMD-SNP-FWABI
- REF-INTEL-TDX-QUOTEEXT
- REF-CCA-TOKEN-DRAFT
