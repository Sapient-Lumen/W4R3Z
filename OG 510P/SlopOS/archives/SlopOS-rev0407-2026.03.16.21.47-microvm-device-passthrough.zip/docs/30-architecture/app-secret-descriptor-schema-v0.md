# CH-APPSECRET v0: Application secret descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **per-application secret seeds** issued by a secret portal (D-APPSECRET).
This schema is **not** the authority itself; it describes the bounds and policy posture of an application secret grant/rotation event.

References: REF-XDG-PORTAL-SECRET, REF-ANDROID-KEYSTORE, REF-SECRET-SERVICE-SPEC.
V0 posture note: `app-secret-posture-v0.md` pins D-APPSECRET as a **minimal app-seed seam**, not a named secret inventory or general vault.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-APPSECRET v0 := {
  v: 0,

  ; stable attribution (no secrets)
  origin: {
    comp_id: tstr,             ; canonical component id/name (bounded)
    instance?: tstr,           ; optional instance identifier (bounded)
  },

  ; what kind of secret seed was requested
  scope: tstr,                ; closed enum: "profile" | "user" | "device"
  purpose: tstr,              ; closed enum: "local_encrypt" | "local_integrity" | "kdf_seed"

  ; export posture
  delivery: tstr,             ; closed enum: "bytes" | "handle"

  ; size/bounds
  len: uint,                  ; portal-clamped allowlist (e.g., 32 or 64)

  ; rotation posture
  rotation_epoch: uint,       ; monotonic per (origin, scope); bumps on rotate
  issued_at_s: uint,          ; monotonic time or policy-defined epoch seconds

  ; policy hints (non-authoritative)
  rotate_requested?: bool,    ; whether the request asked to rotate
  rotate_granted?: bool,      ; whether rotation occurred (if requested)

  redaction?: {
    mode: tstr,               ; closed enum: "none" | "hash_only"
  }
}

Notes:
- This descriptor contains **no secret bytes**.
- `delivery="handle"` indicates the platform returned a non-exportable seed handle suitable for derivation-only profiles.
- `scope="profile"` is the expected default v0 posture; wider scopes are policy-controlled widenings, not ambient defaults.

## Validation rules (minimum)
A CH-APPSECRET validator MUST be total and fail closed:
1) `v == 0`.
2) `origin.comp_id` is present and bounded.
3) `scope`, `purpose`, and `delivery` are allowlisted.
4) `len` is allowlisted/bounded.
5) `rotation_epoch` and `issued_at_s` are present and bounded.
6) If `rotate_granted` is true, then `rotate_requested` MUST be true.
7) `redaction.mode` is allowlisted when present.
8) Unknown fields reject (or are rejected by canonical CBOR decode).

## Privacy notes
Application secret events can leak metadata about app behavior (e.g., “this app rotates secrets often”). Exports SHOULD:
- treat CH-APPSECRET as sensitive metadata in strict profiles,
- prefer `redaction.mode="hash_only"` for routine telemetry.
