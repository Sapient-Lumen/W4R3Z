# CH-TRIAGE v0: Triage rules (schema)

Purpose: define a **portable, pinned, bounded** triage-rule artifact that helps answer:
- “what is likely wrong?” (bounded findings/tags), and
- “what is the smallest next diagnostic step?” (bounded snapshot requests),
without turning diagnostics into an ambient exfiltration channel.

This is inspired by Fuchsia’s `fx triage` (selectors + eval + actions + tests), and by declarative alerting/rule systems (e.g., Prometheus rules) that keep evaluation bounded and auditable.

References: REF-FUCHSIA-TRIAGE, REF-PROMETHEUS-ALERT-RULES.

## Encoding
Canonical CBOR (D-ENC). YAML/JSON MAY be used for authoring, but MUST be deterministically transcoded before hashing/signing.

## Design constraints (v0)
- **closed set** of operators and action kinds
- **bounded** strings/lists and bounded evaluation cost
- **deterministic** evaluation (no timestamps, random, or external I/O)
- **non-authoritative**: CH-TRIAGE cannot by itself trigger export; CH-OBSPOL + capability checks still apply

## Shape (v0)
A triage rule set `tr` contains:
- `schema`: fixed string `CH-TRIAGE v0`
- `id`: short identifier (bounded string)
- `rev`: optional monotonically increasing revision number (ops/debug only)
- `inputs`: closed-set list of enabled selector domains
- `selectors`: map from `name -> selector`
- `derived`: optional map from `name -> expr`
- `rules`: ordered list of rule objects
- `tests`: optional list of embedded golden tests

### `inputs` (closed set)
- `inspect` — selectors may read from a provided CH-INSPECT snapshot
- `crashcap` — selectors may read from a provided CH-CRASHCAP manifest

Evaluation is defined only over explicitly supplied input artifacts.

## Selectors
A selector extracts a value into a named slot.

Each selector object has:
- `kind`: one of:
  - `inspect_path`
  - `crash_field`
- `as`: one of: `bool | i64 | u64 | string`

#### `inspect_path`
- `path`: bounded string selector for an inspect hierarchy key path.
  - v0 uses a simple “/”-separated path (no globs); richer selector syntax requires an RFC.

#### `crash_field`
- `field`: enum:
  - `signal` | `exception_kind` | `component_id` | `reason` | `module_count`

Unknown fields reject.

## Expressions (derived values)
`expr` is a bounded AST:
- literals: bool, i64/u64, short strings
- reads: `var(name)` referring to a selector or derived name
- operators (closed set):
  - boolean: `and`, `or`, `not`
  - compare: `eq`, `ne`, `lt`, `le`, `gt`, `ge`
  - numeric: `add`, `sub` (bounded; overflow is deterministic)
  - string: `contains` (bounded; ASCII/UTF-8; no regex)

No loops, no recursion, no external calls.

## Rules
Each rule has:
- `when`: an `expr` returning bool
- `then`: bounded list of actions

Rule evaluation order is deterministic.

## Actions (closed set)
Each action has `kind` and kind-specific parameters.

Allowed action kinds:
- `emit_tag`
  - `tag`: bounded string
- `emit_finding`
  - `code`: bounded string (stable ID)
  - `severity`: enum `info|warn|error`
  - `hint`: bounded string (short human hint)
- `request_snapshot`
  - `tier`: enum `sanitized|full`
  - `entry_kinds`: bounded list from the closed set:
    - `log_window` | `trace_window` | `inspect` | `crashcap` | `receipt_refs`
- `request_escalation`
  - `reason_code`: bounded string

Notes:
- `request_snapshot` is advisory: snapshot tooling MUST still consult CH-OBSPOL allowlists/bounds.
- `full` tier requests MUST be routed through an explicit workflow in hardened profiles.

## Tests (optional)
A test vector provides:
- `name`
- `inputs`: small embedded input fragments (authoring convenience)
- `expect`: expected emitted tags/findings and requested snapshot shape

Tooling MAY strip tests from deployed rule sets (tests are not required at runtime).

## Bounds (recommended)
Implementations SHOULD enforce conservative hard caps, e.g.:
- max selectors: 128
- max derived expressions: 128
- max rules: 256
- max actions per rule: 16
- max string length: 256 bytes (except hints: 512)

Exact caps are profile/tooling choices, but must be deterministic and fail closed.
