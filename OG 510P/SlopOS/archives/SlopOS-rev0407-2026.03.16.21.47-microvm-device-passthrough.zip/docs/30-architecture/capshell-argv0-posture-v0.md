# Capshell `argv[0]` posture v0 (program name derives from the exec selector)

Purpose: keep **D-CAPSHELL** honest after executable selection, exact executable-object binding,
and exact startup code-closure binding are already explicit. Even if `capshell.exec` binds one
exact executable object and one exact startup native code closure, launch meaning still drifts if
the runner lets caller-controlled or wrapper-controlled **`argv[0]`** pick a different startup
mode. Many programs still inspect the invocation name to choose applets, login-shell behavior, or
other mode switches; that makes program-name text a hidden second launch selector.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic alias
registry, a new `exec -a`-style workflow knob, or a package/app-mode catalog. It only pins the
minimum Phase 1 posture needed so reviewed automation launches with **one runner-derived child
program name** that is tied to the explicit `role="exec"` selector rather than to caller-supplied
string tricks.

## Posture (v0)

1) **Child `argv[0]` is derived from the explicit exec selector**
   - After resolving the CH-ARGV `desc` token with `role="exec"` against already-held authority,
     the runner MUST derive the child-visible `argv[0]` from that bound selector by a stable,
     provider-/membrane-owned presentation rule.
   - Phase 1 launch meaning is therefore "this exact executable object / startup closure, presented
     under its stable reviewed selector identity", not "whatever program name the caller asked the
     child to believe".
   - The non-`exec` CH-ARGV tokens preserve their relative order as child `argv[1..]`; the
     `role="exec"` token is a selector, not an arbitrary user-controlled data word.

2) **No caller-controlled or wrapper-controlled `argv[0]` spoofing**
   - The runner MUST NOT let a CH-ARGV `lit` token, wrapper default, symlink alias, launcher
     convenience flag, `exec -a`-style primitive, leading-login-shell hyphen convention, or other
     out-of-band rename rewrite child `argv[0]` independently of the reviewed `role="exec"`
     selector.
   - Review/binding therefore closes over program-name semantics at the same time it closes over
     executable identity and startup code closure.
   - If the active runtime cannot guarantee that the child program name is tied to the reviewed
     selector instead of caller-supplied text, it MUST fail closed.

3) **Multi-call / mode-by-name tools are not a portable capshell promise**
   - Phase 1 does **not** promise portable support for tools whose startup behavior is selected only
     by invocation name (`argv[0]`) rather than by ordinary reviewed arguments, subcommands, or
     separate explicit descriptors.
   - BusyBox-style applet selection, login-shell mode triggered only by `argv[0]`, and similar
     mode-by-name conventions are therefore outside the portable `capshell.exec` promise unless the
     tool also exposes an ordinary reviewed argument or subcommand that reaches the same behavior.
   - This is deliberate: name-sensitive startup is a second hidden selector and would otherwise
     smuggle a mutable compatibility plane back into D-CAPSHELL.

4) **Explicit mode selection stays on ordinary argv or a future seam**
   - If a tool supports the desired mode through ordinary reviewed arguments/subcommands, workflows
     MUST use those existing CH-ARGV tokens.
   - If a product eventually needs a portable alias/app-mode facility, it must return as **one
     explicit new decision surface** rather than widening CH-ARGV or `capshell.exec` by implication.
   - This posture therefore keeps `argv[0]` out of the authority surface while leaving room for a
     future explicit schema if the entropy cost is ever justified.

5) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.exec.argv0`, no alias registry schema, no applet inventory
     query, and no reviewed "pretend to be program X" convenience.
   - Provider-/membrane-local display names may exist for diagnostics, but they are not a portable
     app-mode authority plane.

6) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that child program-name semantics are pinned to the reviewed exec
     selector instead of remaining a caller-controlled side channel.

7) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT recreate mode-by-name startup by letting foreign wrappers rewrite the
     child program name behind the reviewed selector.
   - If a foreign runtime or launcher cannot preserve selector-derived `argv[0]` semantics, it MUST
     fail closed rather than silently importing host `exec -a`, symlink-alias, or login-shell lore.

## Phase 1 non-goals (explicitly deferred)

- No portable `exec -a` / arbitrary `argv[0]` override surface.
- No BusyBox-style applet inventory or alias registry on the capshell seam.
- No login-shell or mode-by-name compatibility contract.
- No package/app-store alias system hidden behind CH-ARGV.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seams:
  - `capshell-exec-object-posture-v0.md`
  - `capshell-code-closure-posture-v0.md`
  - `capshell-script-entry-posture-v0.md`
  - `capshell-exec-pack-schema-v2.md`
  - `argv-schema-v0.md`
- Assurance anchors:
  - `I-CAPSHELL-ARGV0-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-ARGV0-BIND` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_argv0_posture.py` (**EVID-2026-344**).

## References

- REF-OPENGROUP-EXEC
- REF-MAN7-EXECVE
- REF-BUSYBOX-FAQ
