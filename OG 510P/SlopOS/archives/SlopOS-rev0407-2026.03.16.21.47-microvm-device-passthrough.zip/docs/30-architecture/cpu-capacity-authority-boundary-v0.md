# CPU-capacity authority boundary v0 (Phase 1 hardware-fact posture)

Purpose: narrow **OQ-0001** again by freezing what asymmetric CPU-capacity / performance-class facts in CH-HWFACT are allowed to mean in Phase 1, so richer heterogeneous-core data can improve placement without silently becoming a new Hybrid ownership or authority boundary.

## Decision (v0)

In Phase 1, CH-HWFACT asymmetric CPU-capacity facts are **placement hints only**.
That includes any future bounded per-CPU or per-domain heterogeneity facts such as:
- relative CPU-capacity / performance-class hints,
- efficiency-class / highest-performance hints,
- hybrid-core type labels, or
- SKB-derived rank labels built from those facts.

These facts MAY:
- inform placement *within* an already chosen cluster,
- help user-space schedulers or SKB queries rank CPUs for latency / throughput / energy-sensitive work, and
- explain why a task was steered toward one CPU class rather than another.

These facts MUST NOT, by themselves:
- change the default `preferred_boundary = auto` derivation order,
- create a new authoritative cluster `kind` such as `perf_class`, `big_core`, or `little_core`,
- justify cross-NUMA cluster merges or owner migration policies, or
- become an admission/authority boundary for leases, routing, budget, temporal capability, or replay semantics.

Any future design that promotes asymmetric CPU-capacity facts into an ownership or authority boundary must land as a **separate RFC-first policy surface**, not as a reinterpretation of existing CH-HWFACT / CH-CLUSTERMAP bytes.

## Why this boundary exists

Modern systems increasingly expose heterogeneous CPU information: relative capacity numbers, performance-domain hints, efficiency classes, or hybrid-core labels.
That information is useful, but it is still an optimization vocabulary first.

If SlopOS lets those facts silently widen authority in v0, then:
- the same machine class can produce different ownership boundaries as firmware/kernel topology exports evolve,
- scheduler optimization hints become correctness boundaries without explicit review,
- and “run on the big core” starts leaking into budget / priority / replay semantics before the archive has specified any such authority surface.

Phase 1 therefore keeps one hard line:
**CPU-capacity facts may explain where to place work, but not who owns cross-cluster state or which requests gain more authority**.

## Consequences

1) **No automatic performance-class clustering**
   - Discovering capacity asymmetry does **not** create new cluster kinds or rewrite CH-CLUSTERMAP ownership boundaries.
   - `preferred_boundary = auto` remains exactly the Phase 1 rule from `cluster-auto-boundary-v0.md`.

2) **No hidden authority gradient from “big” vs “little” CPUs**
   - A higher-capacity CPU does not imply broader authority, stronger leases, extra budget rights, or a different replay/dedupe meaning.
   - Performance classes may shape placement, not permissions.

3) **Hinting stays optimization-only on current seams**
   - User-space may use heterogeneity facts to rank candidate CPUs or ask for preferred performance points.
   - Such hints remain descriptive/optimization-only unless a later RFC introduces an explicit authority-bearing scheduler or QoS surface.

4) **Future perf-aware authority must be explicit**
   - If a later profile needs cluster ownership or admission rules keyed by CPU capacity / efficiency class, that work must introduce one explicit policy surface and its proof/evidence plan.
   - It must not reuse old CH-HWFACT bytes as if they had always carried authority semantics.

## Wiring

- Hardware fact seam: `hardware-facts-schema-v0.md` (CH-HWFACT v0)
- Hybrid derivation surfaces: `cluster-derivation.md`, `cluster-auto-boundary-v0.md`, `multicore-architecture-options.md`
- Decision surfaces: `decision-map.md` (D-MK, D-CLUSTERMAP, D-SKB)
- History/open-question surface: `docs/00-meta/trajectory-map.md` (OQ-0001 narrowed here)
- Evidence hook: `EVID-2026-270` via `tools/check_cpu_capacity_authority_boundary.py`

## References

- REF-LINUX-SCHED-CAPACITY
- REF-LINUX-UTILCLAMP
- REF-ACPI-CPPC-HETERO
