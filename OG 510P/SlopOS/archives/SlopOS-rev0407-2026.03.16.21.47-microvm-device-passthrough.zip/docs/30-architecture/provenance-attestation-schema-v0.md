# CH-PROV v0 (provenance attestation payload, informal)

Purpose: a small, canonical provenance statement that can be signed and bound into CH-BOOT via `prov_attestation_digest`.

This schema is inspired by the SLSA provenance predicate and in-toto attestation model, but kept deliberately minimal.

Refs: REF-SLSA-PROVENANCE, REF-IN-TOTO.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded fields (no unbounded logs)
- expresses *what to verify* without requiring a large verifier

## Shape (v0)
A provenance statement `p` contains:
- `schema`: fixed `CH-PROV v0`

### Subject (what was built)
- `subjects`: bounded list of subjects:
  - `name`: bounded identifier (operator/debug only)
  - `digest`: digest of the artifact (same digest namespace as CH-BOOT)
  - `role`: closed enum (e.g., `{ hv_image, kernel_image, init_image, cfg, comp_manifest, proof_bundle }`)

### Builder + build definition (how it was built)
- `builder`:
  - `id`: bounded builder identity (e.g., CI workflow identity)
  - `version`: optional bounded version tag
- `build`:
  - `build_type`: closed enum for our pipelines (e.g., `{ release, dev, proof }`)
  - `invocation_id`: bounded nonce/id (operator/debug)
  - `timestamp`: optional time value (only if included by profile; not a security oracle)

### Materials (what it depended on)
- `materials`: bounded list of inputs:
  - `name`: bounded identifier
  - `digest`: digest
  - `kind`: closed enum (e.g., `{ source_tree, toolchain, deps_lock, spec_bundle, proof_inputs }`)

### Optional: proof/model-check attachments (for D-PCP slices)
- `evidence`: optional bounded list:
  - `name`: bounded identifier
  - `digest`: digest
  - `kind`: closed enum (e.g., `{ verus_proof, isabelle_proof, kani_report, loom_report, fuzz_corpus, benchmark }`)

## Validation obligations
- reject unknown enum variants and unknown keys (closed world)
- ensure subject digests use supported digest algorithms
- ensure `materials`/`evidence` lists are bounded

## Binding note
- CH-BOOT may include `prov_attestation_digest` which refers to a signature envelope/container over CH-PROV v0 (e.g., CH-SIGENV v0; RFC-0093), whose binding ultimately covers the canonical bytes digest of CH-PROV v0 (details are a D-UPD-SIGN/D-SIGENV decision).
