# Capshell local IPC posture v0 (no ambient AF_UNIX / session-bus baseline)

Purpose: keep **D-CAPSHELL** honest once workflow launch already has explicit argv/env/cwd/stdio/fdset
and explicit effect contracts. Those seams still drift if the runner quietly preserves **ambient local
IPC authority** from the host/session/runtime: AF_UNIX / AF_LOCAL socket namespace reachability,
filesystem socket-path discovery, Linux abstract-namespace sockets, session/system/user message-bus
conventions, or wrapper behavior that simply “lets the child talk to the normal local bus”.

This adjunct closes that seam. It is intentionally narrow: it does **not** redesign local IPC,
introduce a portable AF_UNIX/socket API, standardize message-bus/launchd/systemd-bus semantics, or add a
reviewed per-step local-bus descriptor surface. It only freezes the minimum Phase 1 posture needed
so `capshell.exec` remains capability-safe instead of inheriting machine-local IPC lore.

## Posture (v0)

1) **No ambient local IPC namespace or session-bus baseline at `capshell.exec`**
   - A reviewed `capshell.exec` launch does **not** imply ambient reachability to filesystem-path
     AF_UNIX sockets, Linux abstract-namespace sockets, host-global session/system/user message-bus
     defaults, or “the normal machine-local IPC fabric” as a portable baseline.
   - In other words: **no ambient AF_UNIX / session-bus baseline** is part of Phase 1 capshell
     launch semantics.
   - If the active runtime or compat membrane cannot prevent ambient local-IPC reachability at the
     launch boundary, it MUST reject/fail closed rather than silently widening child authority.

2) **Phase 1 adds no reviewed per-step AF_UNIX / session-bus surface**
   - Phase 1 adds **no reviewed per-step AF_UNIX / session-bus surface** to CH-EXECPACK, CH-ARGV,
     CH-ENV, CH-CWD, CH-STDIO, or CH-FDSET.
   - Phase 1 adds no reviewed per-step AF_UNIX / session-bus surface.
   - There is therefore no portable `capshell.ipc.*`, no bus-address field, no local-socket path
     selector, no abstract-namespace name surface, and no reviewed service-name lookup plane hidden
     inside `capshell.exec`.

3) **Local IPC stays on explicit handles/routes only**
   - If local IPC is needed, it must arrive through already-reviewed explicit handles/routes: for
     example pre-bound descriptors carried via **CH-STDIO v0** / **CH-FDSET v0**, or through an
     existing explicit service seam such as **D-CRYPTOSVC** where reachability is already
     route-bound and policy-killable.
   - `capshell.exec` itself does **not** grant ambient permission to open or discover host-local
     socket endpoints, message buses, or service-manager control sockets.

4) **No ambient bus discovery or autolaunch**
   - `capshell.exec` does **not** inherit host-global session/system/user bus conventions as a
     portable baseline.
   - Phase 1 declines `DBUS_SESSION_BUS_ADDRESS` / autolaunch fallback / default system-bus socket
     discovery / “current desktop session bus” behavior as part of the reviewed launch contract.
   - Host-local service-name discovery, bus attachment by convention, or abstract-namespace probing
     are out of scope unless a future explicit seam returns through RFC-first work.

5) **Other execution-pack seams do not secretly mint local IPC authority**
   - **CH-ENV v0** may carry literal endpoint strings or bus names, but env bytes alone do **not**
     grant reachability.
   - **CH-CWD v0** / **CH-ARGV v0** do not authorize socket-path scanning, bus-name resolution, or
     local-namespace probing by convention.
   - **CH-STDIO v0** / **CH-FDSET v0** remain explicit descriptor-binding seams only; they are not a
     license to inherit a host socket table, desktop session bus, system bus, or agent/socket
     inventory.

6) **Commutativity and ordering stay on existing seams**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - Ordering for launch remains the existing `capshell.exec` story; any explicit future local-IPC
     broker/bus surface must declare its own conflict keys and serialization boundary.

7) **Sealed compat remains killable and non-ambient**
   - Compat/foreign-cell adapters MUST NOT recreate “normal local sockets”, “the desktop/system
     bus”, or machine-global AF_UNIX namespace reachability as a hidden convenience behind
     D-CAPSHELL.
   - Any legacy local-IPC interop remains explicit, policy-killable, and subordinate to existing
     explicit routes/descriptor seams rather than a side door around them.

8) **No new workflow / ACP / admin surface**
   - Phase 1 adds no `capshell.ipc.*`, no reviewed per-step local-socket/bus descriptor family, no
     service-name inventory API, and no shell-owned local-bus browser/admin surface.
   - Any future explicit local-IPC broker must return as its own RFC-first seam rather than hiding
     inside `capshell.exec`.

## Phase 1 non-goals (explicitly deferred)

- No portable AF_UNIX / abstract-namespace socket API for capshell.
- No reviewed per-step session/system/user message-bus address surface.
- No hidden “inherit the desktop/session/system bus” compatibility promise.
- No local-socket/service-name inventory or autolaunch semantics inside `capshell.exec`.

## Wiring

- Decision surface: `docs/30-architecture/decision-map.md` (**D-CAPSHELL**).
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-network-posture-v0.md`
  - `fdset-schema-v0.md`
  - `stdio-schema-v0.md`
  - `cryptosvc-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-IPC-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-IPC-EXPLICIT` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_local_ipc_posture.py` (**EVID-2026-335**).

## References

- REF-MAN7-UNIX
- REF-DBUS-SPECIFICATION
- REF-DBUS-LAUNCH
