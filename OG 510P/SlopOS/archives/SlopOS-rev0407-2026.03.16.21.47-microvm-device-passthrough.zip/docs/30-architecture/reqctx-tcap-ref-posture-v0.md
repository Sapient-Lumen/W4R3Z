# CH-REQCTX temporal-capability reference posture v0 (untyped digest list; consumer-typed)

Purpose: keep **D-TCAP** (temporal/scheduling-context style capability objects) auditable and non-ambient even though CH-REQCTX carries an *untyped* `tcap_desc_digests` list.

This doc is intentionally narrow: it pins how consumers interpret `tcap_desc_digests` when a workflow or policy wants to **require explicit temporal capability sponsorship**
(e.g., metered timeproof sampling or CPU-time donation).

## Posture (v0)

1) **`tcap_desc_digests` is untyped by design (CH-REQCTX v0/v1)**
   - The list elements are `bytes32` digests only.
   - The list MUST NOT be treated as a polymorphic “resolver hint”.

2) **Consumers are type-strict (veto-only)**
   - When an interface requires a temporal capability descriptor, **only** descriptors that validate as **CH-TCAP v0** satisfy the requirement.
   - Any digest that resolves to a different schema version/kind MUST be treated as **not a temporal capability**.

3) **Resolution is non-ambient**
   - Consumers MUST resolve digests using **only** explicitly provided artifact material (proposal bundle / local artifact store).
   - Consumers MUST NOT dereference locators (`file:`, `https:`, etc.) during validation.

4) **Fail-closed enforcement**
   - If a required temporal capability cannot be validated from the available artifacts, the action MUST deterministically deny (receipt-shaped).

## Phase 1 non-goals (explicitly deferred)

- No CH-REQCTX v1 change to add typed temporal sponsorship references (keep schema bloat gated behind evidence pressure).
- No ambient “borrow time” or implicit scheduling authority (temporal sponsorship remains explicit).
- No v0 standard for “time donation” market/policy mechanics (policy lives in portal/service implementations).

## Evolution boundary

- `tcap_desc_digests` remains a bare digest list; if future typed temporal sponsorship is ever needed, it must be introduced outside CH-REQCTX per `reqctx-sponsorship-evolution-boundary-v0.md`, not by reinterpreting existing entries in place.

## Wiring

- Decision surfaces: `decision-map.md` (D-REQCTX, D-TCAP).
- CH-REQCTX schema: `request-context-schema-v1.md` (field definition + bounds).
- CH-TCAP v0 schema: `temporal-capability-schema-v0.md`.
- Control surfaces: `docs/70-llm-control/acp-validator-semantics.md` and PO-TCAP-VALIDATE (descriptor validation) and PO-TCAP-ENF (where enforcement exists).
- Sealed compat posture: `artifact-resolution-posture-v0.md` (no locator deref in privileged resolution).
- CI drift gate: `tools/check_reqctx_tcap_ref_posture.py` (EVID-2026-208).

## References

- REF-SEL4-SCHEDCTX-EUROSYS18 (temporal capability precedent)
- REF-ROUGHTIME-REPO (timeproof sampling reference; comparison only)
