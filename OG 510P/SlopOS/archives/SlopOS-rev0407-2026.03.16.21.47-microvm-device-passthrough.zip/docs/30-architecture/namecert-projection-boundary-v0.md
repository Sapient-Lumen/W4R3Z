# D-NAMECERT projection boundary v0 (explicit slot materialization; source-digest-bound)

Purpose: narrow the **authority-bearing projection** path from **D-NAMECERT** into live local state so
accepted local naming results cannot quietly turn into ambient namespace changes, hidden resolver cache
state, or a second policy/compliance plane.

This doc attaches to the existing D-NAMECERT / D-NS / D-COMMUTE seams rather than inventing a new one.
It resolves one Phase 1 question: **if CH-NAMECERT bundle evaluation matters for authority, where can the
result land, how is it ordered, and how is the source evidence retained?**

## Boundary (v0)

1) **Evaluation and materialization are separate events**
   - Evaluating an explicit CH-NAMECERT bundle set is a **local policy decision**, not a namespace mutation by itself.
   - Parsing / validating / replicating / caching bundles MUST NOT silently change any active view.
   - Any authority-bearing result must therefore appear on an already-reviewed target seam with its own receipts and ordering rules.

2) **Phase 1 authority-bearing projection target is D-NS view slots only**
   - In Phase 1, accepted D-NAMECERT results may become live authority only through explicit **`view.attach`** / **`view.detach`** actions on a concrete `(view_id, slot_id)`.
   - There is no Phase 1 “install this bundle”, “import all bindings”, “activate this namespace”, or “latest bundle wins” operation.
   - This keeps authority-bearing projection on the existing D-NS seam rather than on CH-NAMECERT itself.

3) **Source-digest provenance is mandatory for materialized bindings**
   - When a `view.attach` / `view.detach` is justified by CH-NAMECERT evaluation, the proposal and its resulting receipts MUST retain the source **`digest(CH-NAMECERT v0)`** bundle-set evidence as digest-only provenance pointers.
   - Acceptable carriers are existing digest-first surfaces on the target seam (for example: CH-ACP metadata provenance pointers, CH-ACPOUT `receipt_refs`, or an allowlisted CH-SPROJ `meta` field).
   - Hidden resolver cache epochs, unnamed “active trust set” state, or implicit “resolved earlier” side effects MUST NOT substitute for explicit source digests.
   - Bundle validity/freshness may gate whether a proposal is accepted, but any live-state lifetime semantics are separately pinned by `namecert-time-boundary-v0.md`; provenance does not imply auto-detach. When multiple admissible candidates exist, the proposal must still identify the exact chosen candidate rather than relying on a hidden winner-selection rule (`namecert-selection-boundary-v0.md`). The supporting candidate set must come from the presented explicit bundle set, not from ambient/distributed follow-on discovery (`namecert-search-boundary-v0.md`). The chosen candidate must also refer only to an already-existing local principal/proxy/service object or other non-bearer descriptor admitted by local policy; CH-NAMECERT must not smuggle raw CH-SREF / CH-CAPX / restore material into the target seam (`namecert-bearer-boundary-v0.md`).

4) **Conflict keys stay on the target seam (`view.slot`)**
   - Namecert-derived namespace mutations inherit the ordinary D-NS / D-COMMUTE stance:
     - conflict key family: **`view.slot`**
     - key payload: `{view_key=digest(view_id), slot_id}`
     - different slots **commute (keyed)**
     - the same slot is **ordered** and requires **CH-ORDERTOK v0**
     - serialization lives at **`svc:view`**
   - D-NAMECERT therefore adds **no new conflict-key family**, **no new ordering stream**, and **no standalone ACP kind**.

5) **No bulk reconciliation, watches, or background auto-materialization**
   - A new replicated bundle arrival, a refreshed trust root, or a changed local policy MAY cause future evaluation results to differ, but any resulting namespace mutation still lands as explicit per-slot `view.attach` / `view.detach`.
   - Phase 1 declines watch loops, background “reconcile my active view”, and bulk namespace rewrites driven by namecert bundle churn.
   - If a bundle affects multiple slots, those are multiple target-seam actions; disjoint slots may commute, same-slot changes still serialize.

6) **Proxy/service labels remain observational in Phase 1**
   - Local proxy/service metadata MAY carry labels derived from **`CH-NAMECERT v0`** for UX or audit, but those labels are **non-authoritative** in Phase 1.
   - D-CAPX / D-CAPRPC authority still comes from explicit local proxy/service objects, imports, and restore paths, not from proxy labels minted out of **`CH-NAMECERT v0`** evaluation.
   - Any future authority-bearing proxy/projection path must land as its own RFC-first seam instead of widening this boundary in place.

7) **Sealed compat remains honest**
   - Compat shims and foreign-cell bridges MUST NOT recreate host-global certificate stores, background name daemons, or automatic path/URI resolution that bypasses the explicit per-slot view materialization path.
   - If compat needs name-derived bindings, they still arrive as explicit view-slot mutations with retained CH-NAMECERT source digests.

## Phase 1 non-goals (explicitly deferred)

- **Bulk bundle→namespace import** or “synchronize this bundle into my live view”.
- **Shared trust-policy distribution** or replicated resolved-name graphs.
- **Authority-bearing proxy relabel / import** driven directly by **`CH-NAMECERT v0`**.
- **A portable compliance checker / policy language** that unifies credentials and local policy on the D-NAMECERT seam.

## Wiring

- Core local naming posture: `namecert-posture-v0.md`
- Time/freshness boundary: `namecert-time-boundary-v0.md`
- Revocation boundary: `namecert-revocation-boundary-v0.md`
- Selection boundary: `namecert-selection-boundary-v0.md`
- Search boundary: `namecert-search-boundary-v0.md`
- Bearer boundary: `namecert-bearer-boundary-v0.md`
- Local naming replication boundary: `namecert-replication-boundary-v0.md`
- Target namespace seam: `view-namespace-posture-v0.md`
- View base semantics: `view-objects.md`
- D-COMMUTE registries:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`view.attach`, `view.detach`)
  - `conflict-key-family-registry.md` (`view.slot`)
  - `serialization-boundary-registry.md` (`svc:view`)
  - `../70-llm-control/acp-commutativity-predicate-registry.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-PROJECT**)

CI drift gate:
- `tools/check_namecert_projection_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **view-slot-only / source-digest-bound / target-seam-ordering / no bulk auto-materialization** stance, or drops its assurance / REF wiring.

## References

- REF-SDSI-RL96.
- REF-SPKI-RFC2693.
- REF-KEYNOTE-RFC2704.
- REF-BISCUIT-SPEC.
- REF-UCAN-SPEC.
