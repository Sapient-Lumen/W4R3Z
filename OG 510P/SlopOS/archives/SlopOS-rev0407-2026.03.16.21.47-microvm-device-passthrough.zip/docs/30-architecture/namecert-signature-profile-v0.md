# D-NAMECERT signature-profile boundary v0 (one inline direct Ed25519 signature; no wrapper-only, keyless, or multisig admissions)

Purpose: narrow the **signature semantics** of **D-NAMECERT** so admitted **CH-NAMECERT** bundles cannot
quietly widen into algorithm-sprawl, wrapper confusion, keyless/X.509 identity rules, or multisignature/quorum
semantics.

This boundary attaches to already-reviewed seams rather than inventing a new one. `namecert-principal-profile-v0.md`
already pins **who** issuer/subject identities are, `namecert-trust-root-boundary-v0.md` already pins **who decides
trust**, and `signature-envelope-schema-v0.md` / RFC-0093 already provide the archive’s generic detached-signature
surface. The specific Phase 1 question closed here is: **what exact signature shape makes a CH-NAMECERT bundle
admissible for local naming, and may external wrappers/keyless material substitute for that inline signature?**

Phase 1 makes a small, hard choice: **one inline direct signature profile only**. Admitted bundles carry exactly one
inline direct **Ed25519** signature over the canonical unsigned bundle bytes; wrapper-only, keyless/X.509, and
multisignature semantics stay out of D-NAMECERT v0 admissions.

## Boundary (v0)

1) **Admitted Phase 1 bundles use one inline direct signature profile only**
   - In admitted **CH-NAMECERT v0** bundles, the inline **`sig`** field is mandatory and authoritative for D-NAMECERT admission.
   - **`sig.alg` MUST be `"ed25519"`** in admitted Phase 1 bundles.
   - Phase 1 admits **one direct signer only**: no signature arrays, no quorum rules, no countersignatures, and no “highest signature count wins” semantics.

2) **The signature verifies over one exact canonical unsigned payload shape**
   - Verification input is the **canonical bytes under I-ENC-1 of the unsigned CH-NAMECERT payload shape**:
     `{schema, bundle_id, issuer, created_ms, bindings, delegations}` with the inline `sig` field omitted.
   - Validators MUST NOT hash a different projection, sign only selected subfields, or let an external wrapper redefine what the signature covers.
   - This keeps bundle review, bundle digest identity, and signature verification aligned to one explicit preimage.

3) **External wrappers do not substitute for the inline admission signature**
   - A bundle wrapped in **CH-SIGENV**, **COSE_Sign1**, DSSE, or another detached-signature container MAY exist as extra audit/supply-chain evidence, but it is **non-authoritative for D-NAMECERT admission** in Phase 1.
   - Validators MUST NOT accept a wrapper-only object when the inline `sig` is missing, malformed, or uses a different algorithm.
   - This avoids dual-signature-channel ambiguity where one layer signs the object while another layer silently decides authority.

4) **No keyless, X.509, or cert-chain identity semantics on the naming seam**
   - Phase 1 D-NAMECERT admission does **not** accept keyless/X.509 certificate identities, OIDC issuer claims, transparency-log inclusion, or CA-chain policy as a substitute for the inline direct signature.
   - If deployments want those richer supply-chain or release-signing semantics, they stay on their own reviewed seams such as **D-SIGENV / D-KEYLESS / D-TLOG**, not inside local naming admission.
   - Local naming therefore keeps one small verifier story instead of importing a second PKI/trust language.

5) **Issuer identity and verifier material stay explicitly local**
   - The inline Ed25519 signature is checked using verifier material selected through the already-pinned **hash-only `PrincipalRef`** profile plus **explicit evaluator-local trust-anchor / key-registry policy**.
   - External wrappers, cert chains, or transparency receipts MUST NOT silently change which verifier key the issuer thumbprint resolves to for D-NAMECERT admission.
   - This keeps signature verification subordinate to the existing principal/trust-root boundaries rather than creating a second identity plane.

6) **This keeps all four product shapes honest**
   - **Secure workstation (A):** one small direct-signature verifier is easier to audit than mixed inline/wrapper/keyless acceptance.
   - **Cloud micro-VM substrate (B):** replicated bundle evidence stays compact and deterministic; admission does not depend on ambient cert-chain or transparency-log fetch.
   - **Embedded / separation-kernel-ish appliance (C):** validators stay tiny: one algorithm, one unsigned-payload shape, one fail-closed path.
   - **Agent/automation OS (D):** LLM tooling gets a crisp rule — emit the canonical unsigned bundle, sign it once with Ed25519, and do not expect wrappers or certs to rescue a bad inline object.

## Phase 1 non-goals (explicitly deferred)

- Wrapper-only admission using **CH-SIGENV**, **COSE_Sign1**, DSSE, or other detached-signature containers.
- Keyless/X.509/OIDC/transparency-log identity policy on D-NAMECERT admission.
- Multisignature, quorum, countersignature, or threshold semantics for local naming bundles.
- Signature-algorithm agility on the D-NAMECERT admission seam.
- Letting external signature wrappers redefine the signed payload shape.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema: `namecert-schema-v0.md`
- Adjacent boundaries:
  - `namecert-principal-profile-v0.md`
  - `namecert-trust-root-boundary-v0.md`
- Adjacent signature/evidence seams:
  - `signature-envelope-schema-v0.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**, **PO-NAMECERT-CHAIN**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-030**)

CI drift gate:
- `tools/check_namecert_signature_profile.py` fails `make lint` if this boundary stops being discoverable, loses its **one inline direct `ed25519` signature / canonical unsigned payload bytes / no wrapper-only or keyless substitution** stance, or drops its assurance / REF wiring.

## References

- REF-EDDSA-RFC8032.
- REF-COSE-RFC9052.
- REF-COSE-RFC9053.
