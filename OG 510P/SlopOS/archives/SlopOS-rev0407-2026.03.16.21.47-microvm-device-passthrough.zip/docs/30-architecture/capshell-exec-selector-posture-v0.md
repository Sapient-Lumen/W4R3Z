# Capshell executable selection posture v0 (no ambient PATH lookup)

Purpose: keep workflow execution free of ambient namespace channels by pinning **how the executable is chosen**.

This posture attaches to D-CAPSHELL and is implemented via **CH-ARGV v0**.

## Posture (v0)

For any `capshell.exec` execution context:

1) **Exactly one exec selector**
   - Validators MUST require **exactly one** CH-ARGV `desc` token with `role="exec"`.
   - Missing selectors reject deterministically.
   - Multiple selectors reject deterministically (prevents ambiguous “pick one” behavior).

2) **No ambient PATH (or other ambient lookup)**
   - Runners MUST select the executable **only** from the bound `role="exec"` descriptor reference.
   - Runners MUST NOT resolve an executable from `lit` argv tokens.
   - Runners MUST NOT consult `PATH` (or any other ambient namespace) for executable discovery.

3) **Receipt-shaped failure**
   - Missing/ambiguous exec selection MUST be transcript-visible and SHOULD use CH-DENY `deny_code = argv-bind-failed` bound to the CH-ARGV digest.

## Phase 1 non-goals (explicitly deferred)

- No “compat PATH” or “search semantics” layer for automation.
- No implicit shebang resolution as an authority channel (if supported, it must be explicit and policy-killable).

## Wiring

- Decision surface: `decision-map.md` (D-CAPSHELL).
- Schema surface: `docs/30-architecture/argv-schema-v0.md` (CH-ARGV v0).
- Control surface: `docs/70-llm-control/acp-validator-semantics.md` and `docs/70-llm-control/acp-action-kind-registry.md`.
- Assurance anchors: I-ARGV-3 and PO-CAPSHELL-ARGV-BIND.
- CI drift gate: `tools/check_capshell_exec_selector.py` (EVID-2026-202).

## References

- REF-OPENGROUP-EXEC
- REF-IBM-AIX-TRUSTEDPATH
