# Cache-topology authority boundary v0 (Phase 1 hardware-fact posture)

Purpose: narrow **OQ-0001** again by freezing what cache-topology facts in CH-HWFACT are allowed to mean in Phase 1, so richer `l3_cache_id` / cache-sharing information can improve placement without silently becoming a new Hybrid ownership boundary.

## Decision (v0)

In Phase 1, CH-HWFACT cache-topology facts are **placement hints only**.
That includes:
- `cpu_topology[].l3_cache_id`, and
- any future bounded cache-sharing / cache-distance / hwloc `Group`-like hints that may be added to CH-HWFACT or derived by D-SKB.

These facts MAY:
- inform placement *within* an already chosen cluster,
- annotate CH-CLUSTERMAP `locality.l3_cache_ids`, and
- help user-space schedulers or SKB queries rank CPUs for locality-sensitive work.

These facts MUST NOT, by themselves:
- change the default `preferred_boundary = auto` derivation order,
- create a new authoritative cluster `kind` such as `cache_group` or `llc`,
- justify cross-NUMA cluster merges, or
- become an admission/authority boundary for leases, routing, or replication.

Any future design that promotes cache-sharing facts into an ownership boundary must land as a **separate RFC-first policy surface**, not as a reinterpretation of existing CH-HWFACT / CH-CLUSTERMAP bytes.

## Why this boundary exists

Cache-sharing data is useful but notoriously presentation-dependent:
firmware tables, kernel topology exports, and topology libraries can expose cache ids, sharing masks, and synthetic grouping helpers in different ways.
That makes them good optimization inputs, but risky default authority boundaries.

If SlopOS lets cache facts silently widen authority in v0, then:
- identical machine classes can produce different ownership boundaries as topology tooling changes,
- placement hints become correctness boundaries without explicit review,
- and Phase 1 Hybrid proof scope expands into cache-/distance-adaptive clustering before the archive has paid for that complexity.

Phase 1 therefore keeps one hard line:
**cache facts may explain where to run work, but not who owns cross-cluster state**.

## Consequences

1) **`l3_cache_id` stays observational / optimization-only**
   - CH-HWFACT may record `l3_cache_id` when available.
   - CH-CLUSTERMAP may echo bounded `locality.l3_cache_ids` for audit.
   - Neither field changes the authoritative cluster partition on its own.

2) **No automatic LLC / cache-group clustering**
   - `preferred_boundary = auto` remains exactly the Phase 1 rule from `cluster-auto-boundary-v0.md`.
   - Discovering cache ids, cache-sharing masks, distance matrices, or hwloc `Group` objects does not auto-promote them into cluster ownership boundaries.

3) **No cache-driven cross-NUMA merging**
   - Cache closeness may inform *intra-cluster* placement.
   - It may not override `allow_cross_numa_clusters = false` or merge NUMA domains by heuristic.

4) **Future cache-aware authority must be explicit**
   - If a later profile needs LLC-scoped ownership or distance-adaptive clustering, that work must introduce one explicit policy surface and its proof/evidence plan.
   - It must not reuse old CH-HWFACT `l3_cache_id` bytes as if they had always carried authority semantics.

## Wiring

- Hardware fact seam: `hardware-facts-schema-v0.md` (CH-HWFACT v0)
- Hybrid derivation surfaces: `cluster-derivation.md`, `cluster-map-schema-v0.md`, `cluster-auto-boundary-v0.md`
- Decision surfaces: `decision-map.md` (D-MK, D-CLUSTERMAP, D-SKB)
- History/open-question surface: `docs/00-meta/trajectory-map.md` (OQ-0001 narrowed here)
- Evidence hook: `EVID-2026-269` via `tools/check_cache_topology_authority_boundary.py`

## References

- REF-HWLOC-OBJTYPES
- REF-LINUX-CACHEINFO
- REF-ACPI-PPTT
