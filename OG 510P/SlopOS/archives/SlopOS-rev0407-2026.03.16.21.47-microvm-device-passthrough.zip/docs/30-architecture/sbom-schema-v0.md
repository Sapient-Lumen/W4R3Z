# CH-SBOM v0: normalized SBOM inventory (digest-bound)

Purpose: represent a Software Bill of Materials (SBOM) as a **bounded, content-addressed artifact** that can be attached to releases/boots and verified for *subject binding*.

This schema is intentionally small and normalized; it is not a full SPDX/CycloneDX replacement.
If richer metadata is needed, link to an external SBOM document via CH-AREF.

References: REF-NTIA-SBOM-MIN2021, REF-CISA-SBOM-MIN2025, REF-SPDX-SPEC, REF-CYCLONEDX-OVERVIEW.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-SBOM v0 := {
  v: 0,

  subject: {
    kind: tstr,            ; closed enum: "deployment_root" | "component" | "bundle"
    digest_alg: tstr,      ; e.g., "sha256"
    digest: bstr,          ; digest bytes
    name?: tstr,           ; optional display name (bounded)
    version?: tstr,        ; optional display version (bounded)
  },

  generated_at_s?: uint,   ; informational only

  generator?: {
    comp_id?: tstr,        ; optional identity of generator component/tooling
    tool?: tstr,           ; optional tool name
    tool_ver?: tstr,       ; optional tool version
  },

  format: tstr,            ; closed enum: "normalized" | "spdx" | "cyclonedx" | "external"

  components: [ + ComponentEntry ],   ; bounded list

  external_doc_aref?: {
    digest_alg: tstr,
    digest: bstr,
  },                         ; optional: digest of a CH-AREF that locates full SBOM doc

  meta?: { * tstr => any }   ; optional; MUST be ignored unless explicitly allowlisted
}

ComponentEntry := {
  name: tstr,               ; bounded
  version?: tstr,           ; bounded

  ; Stable identifiers (prefer at least one)
  content_digest?: { digest_alg: tstr, digest: bstr },   ; digest of the component payload/tree
  build_id?: bstr,          ; e.g., ELF build-id (bounded)

  ; Optional non-authoritative identifiers (may be redacted on export)
  purl?: tstr,              ; package-url string
  supplier?: tstr,          ; bounded

  scope?: tstr,             ; closed enum: "runtime" | "build" | "dev" | "optional"

  licenses?: [* tstr],      ; optional, bounded list of license identifiers
}

Notes:
- CH-SBOM is **evidence**, not authority. It must not be treated as an authorization input.
- `external_doc_aref` is a pointer to a CH-AREF record that can locate a full SPDX/CycloneDX SBOM doc.
- `meta` exists for local-only annotations and MUST NOT affect verification.

## Validation rules (minimum)
A CH-SBOM validator MUST be total and fail closed:
1) `v == 0`.
2) `subject.kind` and `format` are allowlisted closed enums.
3) `subject.digest_alg` is allowlisted; `subject.digest` is present and length-bounded.
4) `components` length is bounded; each entry enforces string/array bounds.
5) Each `ComponentEntry` MUST include at least one stable identifier (`content_digest` or `build_id`), unless the profile explicitly allows “name-only” entries.
6) If `external_doc_aref` is present, it MUST be a digest reference to a CH-AREF object; the CH-AREF validator applies (PO-AREF-VERIFY).
7) Unknown fields reject (or are rejected by canonical CBOR decode); `meta` MUST be ignored unless explicitly allowlisted.

## Binding rules (recommended)
When a CH-SBOM digest is referenced as an artifact:
- If `role == "sbom"` in CH-UPD `artifacts[]`, verifiers SHOULD check:
  `sbom.subject.kind == "deployment_root"` and `sbom.subject.digest == upd.target_root_digest`.
- If `role == "sbom"` in CH-BOOT `artifacts[]`, verifiers SHOULD check:
  `sbom.subject.digest == boot.root_digest` (or the active deployment root digest).

These checks support I-SBOM-1 and PO-SBOM-BIND.

## Security notes
- **Avoid drift**: subject binding prevents “SBOM for A shipped with B.”
- **Export hygiene**: SBOM fields may be sensitive metadata. Exporting CH-SBOM should be governed by CH-OBSPOL tiers, and fields like `supplier`, `purl`, and `licenses` may be redacted.
- **DoS bounds**: keep component list length and string sizes bounded; large SBOMs should be referenced externally via CH-AREF.
