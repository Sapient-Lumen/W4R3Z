# MicroVM entropy-surface posture v0 (no portable ambient guest entropy contract)

Purpose: pin the **Phase 1** meaning of guest-visible entropy sources under `ext.microvm` so `virtio-rng`, CPU HWRNG instructions, and host RNG-backend choices do not quietly become an ambient host↔guest authority/status plane.

This doc attaches to **D-MICROVM**, **D-NONDET**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible entropy device/source contract under `ext.microvm`; there is no portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality-status plane, owner-local boot seeding stays implementation-local, and when D-NONDET is enabled post-init entropy authority still rides on explicit `portal.entropy` / `CH-ENTROPY` seams rather than ambient guest device reads.**

Entropy cost justification: the archive already keeps clone/restore entropy hygiene explicit, keeps bootstrap/metadata off hidden host channels, and keeps time/entropy authority on D-NONDET seams. What remains underspecified is the tempting virtualization convenience layer where host-backed RNG devices, source selectors, and entropy-status folklore quietly become part of the reviewed product contract. One narrow posture closes that gap without inventing a new schema family, a guest RNG API, or a hidden host control/status plane.

## Posture (v0)

1) **No portable ambient guest-visible entropy device/source contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible entropy device/source contract.
   - Portable reviewed meaning does **not** include “this guest can always rely on a host-backed RNG device or entropy instruction path because it is virtualized.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume a standard guest RNG device/source exists with known quality/backing semantics.”

2) **No portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality-status plane**
   - Phase 1 standardizes **no portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality-status plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about `virtio-rng` presence/absence, host source selection such as `/dev/urandom` or external RNG daemons, entropy-health/depletion/throughput status, or a stable “read this device/instruction for blessed host entropy” contract.
   - Implementations may internally expose, mask, or source such mechanisms locally, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local boot seeding stays implementation-local**
   - Owner-local boot seeding stays implementation-local.
   - Runtimes may still seed a guest kernel or early boot environment locally so the system starts reliably, but that does **not** create a portable reviewed promise about one guest-visible entropy device, one source path, or one runtime status/control API.
   - Snapshot/clone hygiene remains governed by the already-pinned restore/generation rules rather than by folklore that a host-backed RNG device makes copied state safe by itself.

4) **D-NONDET remains authoritative for post-init entropy meaning**
   - D-NONDET remains authoritative for post-init entropy meaning.
   - If D-NONDET is enabled, post-init entropy authority still rides on explicit `portal.entropy` / `CH-ENTROPY` seams rather than ambient guest device reads, `/dev/hwrng` expectations, or CPU-HWRNG folklore.
   - `ext.microvm` therefore does not reopen a second ambient entropy path around the already-pinned nondeterminism posture.

5) **Changing the entropy surface is a new admission, not a live control plane**
   - Changing the entropy surface is a new admission, not a live control plane.
   - Owners/runtimes may choose different local entropy-device/source choices for different reviewed leaves or deployment classes, but they may **not** reinterpret a running leaf as carrying a portable mutable entropy source/quality/status plane under the same admitted identity.
   - If policy cares about a different entropy exposure stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to patch a hidden entropy-control channel by convention.

6) **No new entropy-device control plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest entropy-device state, **no new ACP kind**, and **no new conflict-key family** for live entropy-device/source mutation under `ext.microvm`.
   - If a later design wants a portable guest entropy device contract, explicit source-quality/status reporting, or per-leaf entropy-source selection semantics, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity stance, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that `virtio-rng`, `/dev/hwrng`, or CPU-HWRNG instructions exist with one stable reviewed meaning under `ext.microvm`.
- No portable entropy source-selection, health, depletion, throughput, or status API.
- No prohibition on owner-local boot seeding; only a refusal to turn it into a portable ambient authority contract.
- No live “same leaf, different entropy device/source now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-NONDET, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `nondet-posture-v0.md`
- Adjacent postures:
  - `microvm-snapshot-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `microvm-bootstrap-metadata-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-19)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-ENTROPYSURFACE)
- Policy posture:
  - guest-visible entropy exposure adds **no new lane**, **no public source/quality/status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_entropy_surface_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible entropy contract / no portable `virtio-rng`-CPU-HWRNG-RNG-backend-source-entropy-quality-status plane / owner-local boot seeding stays implementation-local / D-NONDET remains authoritative post-init / changing entropy surface means new admission not live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-ENTROPY-DEVICE.
- REF-FIRECRACKER-ENTROPY-CLONES.
- REF-CHYP-DEVICE-MODEL.
- REF-QEMU-RNG-BACKENDS.
