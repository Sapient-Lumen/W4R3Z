# Capshell executable-object posture v0 (exact bound object; no late reopen)

Purpose: keep **D-CAPSHELL** honest after executable selection is already explicit.
The archive already says `capshell.exec` chooses the executable only from one explicit CH-ARGV
`role="exec"` descriptor and never via ambient PATH, but launch still drifts if implementations
quietly turn that reviewed selector back into a host path / portal lookup / mutable file reopen at
the last minute. That reintroduces rename races, retargeting, and "whatever object is there now"
semantics exactly where we most need stable execution meaning.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic
executable catalog, a package-manager policy surface, or a new `capshell.exec` schema. It only
pins the minimum Phase 1 posture needed so reviewed automation executes **one exact bound object**
or fails closed.

## Posture (v0)

1) **`role="exec"` binds one exact executable object in Phase 1**
   - After resolving the CH-ARGV `desc` token with `role="exec"` against already-held authority,
     the runner MUST bind **one exact executable object** before effect.
   - Reviewed launch semantics are the object that was bound, not a later pathname, document label,
     package alias, or portal/provider lookup key.
   - The runner MUST NOT perform a second executable-selection pass after validation.

2) **No late reopen or name-based retargeting at launch**
   - The runner MUST NOT translate the validated exec selector back into an ambient pathname,
     document title, host association, or equivalent name and then reopen "whatever is there now"
     at exec time.
   - Parent directory entries, file replacement, portal/database lookup keys, and other mutable
     naming state are not authoritative launch identity once the reviewed selector has been bound.
  - On path-based launch APIs such as Win32 `CreateProcessW`, merely naming the module is still not the same thing as carrying an exact executable object; such runtimes must preserve equivalent exact-object semantics by explicit staging or fail closed.
   - If the active platform cannot preserve exact-object launch semantics, it MUST fail closed or
     use the explicit staging rule below.

3) **Explicit staging is allowed only as exact-byte materialization**
   - If the host runtime cannot execute the already bound object directly, the runner MAY stage the
     exact executable bytes into a provider-owned execution object and then launch **that** object.
   - Such staging MUST be local, one-shot, and fail closed on any digest/identity mismatch or
     retarget attempt.
   - Staging MUST NOT widen into a generic "look up executable again" compatibility layer.

4) **Mutable document/file grants are not themselves portable exec identity**
   - CH-DOCREF / file-handle style authority may be part of how a local runtime reaches bytes, but
     Phase 1 does **not** treat a reopenable document grant, path-like alias, or mutable host file
     name as the reviewed executable identity.
   - If a local adapter starts from such a grant, it must still end at one exact bound executable
     object (or exact-byte staged equivalent) before launch.
   - This keeps `portal.file` / CH-DOCREF honest as a file-authority seam instead of letting it
     silently become a "latest executable behind this name" channel.
   - Companion quarantined-execution boundary: exact-object launch meaning is downstream of origin/quarantine policy. If the reviewed executable object or explicit script/interpreter input is still quarantined, Phase 1 denies ordinary execution until explicit object-local clear/override; `open_untrusted` is not a fallback run lane (`quarantined-execution-boundary-v0.md`).

5) **Prefer immutable / digest-bound executable sources; sealed profiles require provenance binding**
   - Exact executable-object identity is necessary but not sufficient: startup loader / interpreter /
     shared-library resolution must also stay inside the reviewed closure (`capshell-code-closure-posture-v0.md`).
   - Phase 1 prefers executable objects whose bytes are immutable or digest-bound (for example,
     deployment/store objects, materialization from `CH-AREF v0`, or D-VERITY / `CH-VBLOB v0`-backed
     content) because that keeps launch meaning stable across retries and reviews.
   - In sealed profiles, executable provenance binding remains mandatory via **I-EXEC-SOURCE-1** /
     **PO-EXEC-SOURCE**; this posture narrows the operational meaning even when those stronger
     profile requirements are not enabled.

6) **Script-entry and startup semantics stay on their existing seams**
   - `capshell-script-entry-posture-v0.md` still controls interpreter choice: if a workflow runs a
     script/text artifact, the interpreter itself is the one explicit `role="exec"` selector.
   - This doc only says that whichever executable object is chosen — native binary or explicit
     interpreter — must then remain exact through launch rather than being reopened or retargeted
     by name.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.exec.open`, no executable inventory query, no reviewed
     "execute latest at name X" convenience, and no package/portal callback that rewrites the exec
     selector after review.
   - If a future product wants a portable executable catalog or signed alias system, that work must
     return as **one explicit new decision surface** rather than widening CH-ARGV or CH-EXECPACK by
     implication.

8) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that execution meaning is tied to one exact bound object rather
     than to a later mutable name lookup.

9) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT recreate path-based or host-association-based executable selection by
     reopening a validated selector through ambient namespaces at the last minute.
   - If a foreign runtime cannot preserve exact-object launch or exact-byte staging semantics, it
     MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable executable catalog or package-alias registry.
- No generic "execute latest version at this name" workflow surface.
- No direct CH-DOCREF / path-name reopen semantics as reviewed executable identity.
- No new callback/admin/query plane for executable materialization.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seams:
  - `capshell-exec-selector-posture-v0.md`
  - `capshell-script-entry-posture-v0.md`
  - `quarantined-execution-boundary-v0.md`
  - `capshell-code-closure-posture-v0.md`
  - `capshell-exec-pack-schema-v2.md`
  - `argv-schema-v0.md`
- Adjacent provenance/content seams:
  - `artifact-resolution-posture-v0.md`
  - `verified-blob-descriptor-schema-v0.md`
  - `rfcs/0114-verified-blobs-and-merkle-integrity.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-EXECOBJ-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-EXECOBJ-BIND` in `docs/20-assurance/proof-obligation-registry.md`
  - `I-EXEC-SOURCE-1` / `PO-EXEC-SOURCE` (sealed-profile strengthening)
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_exec_object_posture.py` (**EVID-2026-342**).

## References

- REF-MAN7-FEXECVE
- REF-MAN7-EXECVEAT
- REF-NIX-STORE-OBJECT
- REF-LINUX-FSVERITY
- REF-ANDROID-AVB2-README
- REF-MS-CREATEPROCESS
