# D-PLUMB `open_untrusted` posture v0 (object-only; `docref`-only; policy-chosen disposable; export-only outcomes)

Purpose: pin an **implementable Phase 1** meaning for `intent.kind=open_untrusted` so safe-open stays a small,
request-local workflow boundary instead of drifting into a mini launcher with hidden sandbox/profile knobs, session reuse,
or in-place trust mutation.
It narrows an already-present idea into something worth coding: `open_untrusted` is an **object-only D-PLUMB intent** that
routes one exact object backed by **CH-DOCREF** into a **policy-chosen disposable** (D-EPHEM) with a sealed, continuity-free runtime posture, while
leaving export and quarantine clear on their existing explicit seams.

This doc answers the highest-entropy question in the seam:
**what does “open this untrusted thing safely” actually mean on the portable surface?**
Phase 1 answers: **one exact `docref`, one request-local safe-open launch, policy chooses the disposable, and anything persistent still requires explicit export/clear**.

## Posture (v0)

1) **Object-only safe-open request; exact `docref`; not an OpenURI or restore/import variant**
   - `intent.kind=open_untrusted` is for opening one exact object-like subject, not for generic URI launch, not for exact executable/script launch, and not for CH-SREF restore/import.
   - In **CH-PLUMBMSG v0**, `open_untrusted` uses **`subject.kind = docref` only**. `subject.kind = uri` rejects and remains `open_uri` territory; **`subject.kind = sturdyref` rejects** and remains explicit **D-CAPX / CH-SREF restore/import** territory.
   - `docref` subjects reopen through **CH-DOCREF** / `portal.file.*`, not host paths, and safe-open therefore stays bound to the existing non-bearer document-handle seam instead of selecting from secret-bearing restore material. If a workflow starts from CH-SREF / CH-CAPX, it must first cross the explicit **fresh local object** bridge pinned in `import-to-docref-boundary-v0.md`; safe-open never receives a hidden bearer-backed docref shim. Companion fresh-identity boundary: that bridge is **fresh-object-identity-first**, so same-bytes alias laundering via `reuse_existing` / cache-hit return of an old docref is out of scope (`import-to-docref-fresh-identity-boundary-v0.md`).
   - The portable seam therefore does **not** hide browser launch, URL policy, network mediation, or sturdyref restore behind safe-open.

2) **Policy chooses the disposable profile; callers do not choose templates or reuse**
   - The caller may request safe-open, but does **not** choose the disposable template digest, isolation backend, warm-clone pool, or “reuse the last sandbox” behavior.
   - Those choices remain shell/policy/supervisor-owned under D-EPHEM.
   - Phase 1 adds **no caller-visible template/profile inventory**, no `same_disposable=true` knob, and no second disposable-admin workflow.

3) **Open is view/launch only; export and clear remain separate**
   - `open_untrusted` means “launch a bounded inspection/open workflow,” not “clear quarantine” and not “return a persistent trusted handle.”
   - Success means the request was admitted/launched into the safe-open path; it does **not** mean the object is now trusted, exported, or durably reachable outside the disposable.
   - Any state leaving the safe-open context still crosses explicit `portal.xfer.*` / `portal.file.*` / IF-CONSENT seams and remains transcript-visible; quarantine clear remains its own object-local action.
   - Companion export-classification boundary: ordinary output kept from safe-open becomes a **new artifact** that remains **quarantined by default** unless a separate sanitize/clear workflow says otherwise (`open-untrusted-export-classification-v0.md`).
   - Companion export-destination boundary: ordinary keep/export is **fresh-destination-first**, not overwrite-in-place or replace-existing inside the same workflow (`open-untrusted-export-destination-boundary-v0.md`).
   - Companion export-lineage boundary: ordinary kept output records one exact `origin.parent_digest`, so the fresh artifact keeps explicit parent evidence without inheriting source `docref` identity or durable grants (`open-untrusted-export-lineage-boundary-v0.md`).
   - Companion quarantined-execution boundary: exact executable/script objects do **not** use `open_untrusted`; ordinary exact execution remains deny-by-default until explicit object-local clear/override, and Phase 1 adds no portable `run_untrusted` request (`quarantined-execution-boundary-v0.md`).

4) **Default runtime posture is sealed and continuity-free (with an inert-by-default document viewer/runtime boundary)**
   - The disposable receives only the exact `docref`/view authority needed for the open workflow; no ambient host path, no ambient network lease, and no background/autostart/inhibit continuity come along for the ride.
   - Default safe-open posture is read-only inspection/open plus explicit export, aligned with D-EPHEM and D-QUAR.
   - Companion materialization boundary: the selected `docref` is resolved once into a request-local stable input object (snapshot/staged-copy style) rather than a live alias back to the mutable source; ordinary save stays local until explicit export (`open-untrusted-materialization-boundary-v0.md`).
   - Companion active-content boundary: admitted viewers stay **inert by default**. Embedded active content (macros, document-level scripts, external submit/fetch actions, helper-launch callbacks, or equivalent viewer hooks) does not execute or cause side effects merely because the document was admitted to safe-open; any such effect crosses a new explicit workflow on the existing portal seam (`open-untrusted-active-content-boundary-v0.md`).
   - Companion result-preview boundary: search/smart-folder/launcher UI must not quietly render quarantined document ambient snippet/snippets, thumbnails, preview panes, or hover previews outside this explicit safe-open/review seam; richer preview stays a separate handle-targeted step (`quarantined-result-preview-boundary-v0.md`).
   - The runtime is narrowed, sealed, continuity-free, and inert before user payload runs; safe-open must not smuggle session reuse, hidden persistence, or document-driven side effects back in.

5) **No reuse / no callback / no inventory side channel**
   - `open_untrusted` adds no callback token, no launched-app telemetry channel, no app-visible handler/template inventory, and no “open more objects in the same trusted/untrusted session” portable promise.
   - If the shell later offers convenience UX around recent safe-open choices, that state remains shell-owned and non-authoritative. Companion residue boundary: mere preview/open must not auto-enroll the source object into durable recent-doc / MRU / reopen surfaces or leave thumbnail/autosave/recovery residue outside the disposable; any durable reopen starts only from explicit keep/export or a later portal choice (`open-untrusted-viewer-residue-boundary-v0.md`).
   - Requesters do not learn installed viewers, disposable template names, or route-table details by probing `open_untrusted`.

6) **Ordering stays request-local and export-local**
   - Request lifecycle for one `open_untrusted` interaction is intentionally non-commutative and serializes at the owning workflow/disposable provider (`svc:workflow.router` plus the selected safe-open implementation).
   - Independent `open_untrusted` requests commute **with respect to requester authority** because the intent itself mints none.
   - Any follow-on export/publication uses the existing target-seam conflict keys for `portal.xfer.*` / `portal.file.*`, and any quarantine clear/override uses the existing object-local IF-CONSENT surface; Phase 1 adds **no new conflict-key family** for `open_untrusted` itself.

7) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat runtimes may participate in safe-open only through explicit adapters and policy.
   - Compat must not reinterpret `open_untrusted` as “run this with normal host paths/env/net, but show a warning.”
   - If D-QUAR or D-EPHEM is disabled for a profile, `open_untrusted` fails closed to the non-safe-open policy path rather than silently widening.

## Phase 1 non-goals (explicitly deferred)

- **No URI/URL variant** of `open_untrusted`; URIs remain `open_uri` and keep their own gating.
- **No exact executable/script launch variant** of `open_untrusted`; risky exact execution stays on the explicit quarantine-clear + exec seams.
- **No caller-chosen template/profile/reuse knobs** on the portable seam.
- **No CH-SREF / `sturdyref` subject form** on the portable safe-open seam; explicit restore/import must happen before safe-open if a workflow starts from durable bearer material.
- **No auto-clear, auto-export, or “opened once == trusted” behavior**.
- **No generic safe-open session list/watch/resume/inventory API**.
- **No new ACP kind or conflict-key family** dedicated to `open_untrusted` in Phase 1.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM, D-CAPX)
- Routing / schema surfaces:
  - `intent-kind-registry.md`
  - `plumb-message-schema-v0.md` (CH-PLUMBMSG v0)
  - `quarantine-posture-v0.md`
  - `quarantined-execution-boundary-v0.md`
  - `disposable-domain-posture-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `open-untrusted-active-content-boundary-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
  - `open-untrusted-export-classification-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `open-untrusted-export-lineage-boundary-v0.md`
  - `sturdyref-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-3, I-QUAR-5, I-PLUMB-1, I-PLUMB-3, I-SREF-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-GATE, PO-QUAR-LOCAL, PO-EPHEM-EXPORT, PO-SREF-EXPLICIT)
- RFC / engineering history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **docref-only / policy-chosen disposable / export-and-clear-separate / no callback-or-inventory side channel** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-QUBES-QREXEC.
- REF-XDG-PORTAL-REQUEST.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-CAPTP.
- REF-TAHOE-LAFS.
