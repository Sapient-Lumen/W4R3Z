# CH-QUIESCE v0: quiescence descriptor (optional)

Purpose: a bounded, redaction-safe descriptor capturing **maintenance intent/state** so quiesce/drain behavior is explainable and transcript-friendly.

Non-goal: carrying authority. CH-QUIESCE contains **no capabilities** and must not be treated as authorization evidence.

Used by:
- supervisors / checkpoint managers (portable status reporting)
- CH-LOG entries (bind “why did this stop accepting work?” to a quiesce intent)
- offline triage/debug tooling

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown enum variants and unknown top-level keys reject deterministically.

## Descriptor

```text
CH-QUIESCE-v0 {
  schema: "CH-QUIESCE";
  version: 0;

  qid: u64;                 # quiesce instance id (monotonic per component instance)

  mode: enum {
    DRAIN = 0;
    CANCEL = 1;
  };

  state: enum {
    RUNNING = 0;
    QUIESCING = 1;
    QUIESCENT = 2;
    ENDED = 3;              # used for transcript binding after EndQuiesce
    FAILED = 4;
  };

  # Optional correlation hooks
  reqctx_digest?: bytes32;  # digest of CH-REQCTX (if D-REQCTX is used)

  # Advisory intent for tooling/UX only (not an enforcement oracle)
  monotonic_deadline_ms?: u64;

  # Bounded progress hints (optional)
  progress?: {
    inflight_ops?: u32;
    inflight_jobs?: u32;
    inflight_ioq?: u32;
  };

  # Bounded informational tags (optional; not a general KV store)
  tags?: list<{ k: tstr; v: tstr }>;
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `qid` must be present.
- `reqctx_digest` (if present) must be 32 bytes.
- `monotonic_deadline_ms` (if present) must be non-zero and ≤ 2^63-1.
- `tags` length ≤ 16; each `k`/`v` length ≤ 64; keys must contain only letters, digits, and `._-` (bounded; no spaces).

## Security notes
- CH-QUIESCE is **non-authoritative**: it does not grant rights and must not be used as an authorization input.
- Deadline is **intent**: enforcement uses explicit time/budget authorities (D-NONDET, D-BUDGET, D-TCAP) and/or supervisor policy.
- Progress counters are coarse hints only; do not expose fine-grained timing or secrets.
