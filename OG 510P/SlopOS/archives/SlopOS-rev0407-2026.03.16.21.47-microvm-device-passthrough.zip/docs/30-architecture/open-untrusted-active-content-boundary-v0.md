# D-PLUMB / D-QUAR safe-open active-content boundary v0 (inert viewers; no document-driven code/network side effects)

Purpose: pin the **document-behavior boundary** for `intent.kind=open_untrusted` so document-shaped safe-open does not quietly regrow into “run untrusted” through macros, document-level scripts, external submit/fetch actions, or helper-launch callbacks embedded in the document itself.
It narrows one remaining ambiguity in the seam: once a quarantined object is admitted to a docref-only safe-open workflow, **what is the viewer allowed to do on the document’s behalf?**
Phase 1 answers: safe-open viewers are **inert by default**. They may render, inspect, and support bounded local editing, but they must not execute document-embedded active content or follow document-initiated network / app-launch side effects without crossing a separate explicit portal/consent seam.

This keeps D-QUAR honest without inventing a new subsystem: the archive still does **not** define a universal macro taxonomy or content-disarm engine, but it now fixes the minimum portable rule that keeps “safe-open a risky document” distinct from “run the document’s embedded program.”

## Posture (v0)

1) **Safe-open viewers are inert by default**
   - When `intent.kind=open_untrusted` admits one exact `docref`, the selected viewer/runtime must treat document-embedded **active content** as disabled unless a separate future-reviewed seam explicitly says otherwise.
   - Active content here includes document-level scripts/macros, auto-run actions on open, document-triggered helper/app launch, external template/include fetch, form-submit/network callbacks, or equivalent viewer/plugin extension hooks whose effect would exceed inert local rendering/editing.
   - Baseline safe-open therefore means **render/inspect locally, not execute document-authored behavior**.

2) **Document-driven side effects do not bypass existing portal seams**
   - A document opened via safe-open must not cause ambient network fetch, ambient URI launch, host-app launch, print submission, file export, or similar side effects merely because the format/viewer supports them.
   - If the UI surfaces a hyperlink, attachment, submit action, or equivalent affordance, activating it becomes a **new explicit workflow** on the existing seam (`open_uri`, `portal.file.*`, `portal.print.*`, IF-CONSENT, etc.), not a document-driven callback that piggybacks on the original safe-open grant.
   - This preserves the archive’s existing separation between `open_untrusted` and other portal families instead of letting risky documents script those families indirectly.

3) **Passive editing is allowed; active behaviors are not**
   - Safe-open MAY allow bounded local editing of passive document state (for example text annotations, form field values, or equivalent local edits) when those edits stay inside the disposable until explicit export.
   - That does **not** authorize macro execution, external data refresh, external submit, plugin/module install, or runtime features whose meaning is “run document-authored code” rather than “edit passive document content.”
   - If a format/runtime cannot preserve that distinction clearly enough for the selected mode, it must fail closed or reduce to a more inert rendering path.

4) **Viewer family admission is capability-shaped, not format folklore**
   - Phase 1 adds no portable registry of every macro language, embedded script dialect, or viewer-specific “safe enough” toggle.
   - Instead, each admitted safe-open adapter/viewer family must preserve the v0 inert-view boundary and prove that any still-exposed follow-on effects cross the existing explicit seams.
   - If a legacy or compat viewer cannot disable/contain document-embedded active content, it is not an admissible Phase 1 safe-open implementation for that document family.

5) **Ordering and conflict keys stay on existing seams**
   - This boundary does not mint a new externally visible action family.
   - One `open_untrusted` request remains request-local and serializes at the owning workflow + safe-open provider (`svc:workflow.router` plus the selected viewer/disposable provider).
   - Any later hyperlink/print/export/clear action uses the already-declared conflict keys and evidence paths of `open_uri`, `portal.print.*`, `portal.file.*`, or IF-CONSENT. Phase 1 adds **no new conflict-key family** for active-content suppression itself.

6) **Sealed compat remains non-ambient**
   - Foreign Cell / compat viewers may participate in safe-open only if they preserve the same inert-view posture.
   - Compat must not reinterpret safe-open as “launch the normal full-trust editor/viewer, but inside a disposable” when that viewer still honors macros, document-level scripts, remote template fetch, helper-launch callbacks, or equivalent active-content behavior by default.
   - If a compat path cannot preserve inert-view semantics, it fails closed for `open_untrusted` rather than widening D-QUAR behind the membrane.

## Phase 1 non-goals (explicitly deferred)

- **No universal macro / active-content taxonomy** for every document/runtime family.
- **No hidden “allow active content in this disposable” knob** on `open_untrusted`.
- **No portable promise that every rich document format is fully editable in inert mode**.
- **No content-disarm / rewrite engine** hidden inside safe-open.
- **No document-driven network/helper/print/file side effects** that bypass existing portal seams.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM)
- Related posture / schema surfaces:
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `quarantined-execution-boundary-v0.md`
  - `document-portal-posture-v0.md`
  - `portal-family-registry.md`
  - `intent-kind-registry.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-3, I-PLUMB-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-GATE, PO-PLUMB-NOAMP, PO-OPENURI-ENF, PO-PRINT-ENF)
- RFC / engineering history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_active_content_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **inert-view / no document-driven code or network side effects / explicit follow-on seam** constraints, or drops its primary REF wiring.

## References

- REF-MS-OFFICE-MOTW-MACROS.
- REF-ADOBE-PDF-DOCJS.
- REF-XDG-PORTAL-OPENURI.
- REF-MS-PREVIEW-MOTW.
