# Wallet posture v0 (summary-only; core-digest-bound; no import/merge semantics)

Purpose: pin an **implementable Phase 1** meaning for **D-WALLET** so capability wallets stay a
small review surface for humans and agents rather than drifting into a hidden authority container,
a merge/import substrate, or a second capability-passing mechanism.

This posture deliberately narrows the wallet seam: it keeps CH-WALLET useful for prompts, receipts,
CI drift gates, and effect binding, while refusing any semantics that would let a wallet *carry*,
*resolve*, or *acquire* authority on its own.

## Posture (v0)

1) **Wallets are review artifacts, not authority inputs**
   - **CH-WALLET v0** remains non-authoritative metadata for UX/audit/drift gates.
   - A runner or validator MAY compare wallet contents against already-held authority, but it MUST NOT obtain handles, reopen descriptors, authorize an effect, or resolve a portal workflow solely from wallet contents.
   - `cap_kind`, `rights`, `label`, `desc_schema`, and `desc_digest` are summaries of authority that must already exist elsewhere in the execution context.

2) **`wallet_core_digest` is the only stable binding key**
   - Phase 1 drift gates, prompts, and effect-binding surfaces use **`wallet_core_digest`**, not `digest(CH-WALLET)`.
   - `digest(CH-WALLET)` may be logged as a correlation id, but it MUST NOT be the normative gate key because it includes volatile fields.
   - `wallet_id`, `issued_at`, `subject.instance_id`, `capgraph_digest`, `capdiff_digest`, and `meta` remain outside the stable authority digest.

3) **No wallet import, merge, or handoff semantics in v0**
   - Phase 1 does **not** claim a “load this wallet and acquire authority” path, wallet union/merge operators, or a wallet-to-wallet delegation/import protocol.
   - Pipelines do **not** hand authority to the next stage by “passing the wallet”; cross-stage handoff remains CH-AREF / CH-PLUMBMSG / explicit portal outputs rebound into the next stage’s own context.
   - Any future grouped-handoff object must come back as a separate RFC rather than widening CH-WALLET by implication.

4) **Handle rows are typed summaries, not an inventory API**
   - `handles[*]` entries summarize handle **kinds** and optional rights; they are not a provider-global handle browser or search surface.
   - `desc_digest` may name a typed descriptor already bound in the execution context, but it is not a reopening or lookup oracle.
   - Labels remain human hints only.

5) **Subject and metadata fields are correlation hints only**
   - `subject.component_id`, `subject.instance_id`, `wallet_id`, and `meta` may help operators correlate logs and local state, but they remain non-authoritative.
   - Policy or authorization MUST NOT branch on these fields unless a separate, already-authoritative identity surface independently establishes the same fact.

6) **Wallets may bind explainability, not widen it**
   - `capgraph_digest` and `capdiff_digest` may attach explain/diff evidence to a wallet, but they remain digests only.
   - They MUST NOT be treated as hidden authority import paths or as substitutes for explicit receipts / portal transcripts.

7) **Wallet export is observation-sensitive**
   - Wallets can reveal a component’s authority shape, so sharing/export follows observation policy and redaction hygiene.
   - Phase 1 prefers `wallet_core_digest` and selected descriptor digests in receipts/transcripts over raw full-wallet inventories when practical.

## Phase 1 non-goals (explicitly deferred)

- No wallet import / merge / union API.
- No wallet-as-capability container or transfer format.
- No policy decisions keyed on full `digest(CH-WALLET)` or volatile subject/meta fields.
- No wallet-driven descriptor resolution, reopen, or capability lookup.
- No app-visible/provider-global handle inventory surface derived from CH-WALLET.

## Wiring

- Decision surface: `decision-map.md` → **D-WALLET**.
- Schema surfaces:
  - `capability-wallet-schema-v0.md` → **CH-WALLET v0**.
  - `effect-contract-schema-v0.md` → **CH-EFFCON v0** (`wallet_core_digest` binding only).
  - `plumb-message-schema-v0.md` → **CH-PLUMBMSG v0** (`wallet_core_digest` correlation only).
- Engineering / workflow surfaces:
  - `docs/60-engineering/authority-drift-gates.md`.
  - `docs/60-engineering/cli-plumbing-tooling.md`.
  - `capshell-pipeline-posture-v0.md`.
- Related RFCs:
  - `rfcs/0115-capability-safe-shell-and-automation.md`.
  - `rfcs/0116-capability-wallets.md`.
- Assurance hooks:
  - Invariants: **I-WALLET-1**, **I-WALLET-2**, **I-WALLET-3**, **I-WALLET-4**.
  - Proof obligations: **PO-WALLET-VALIDATE**, **PO-WALLET-BIND**.
- CI drift gate: `tools/check_wallet_posture.py` (**EVID-2026-246**).

## References

- REF-SHILL-OSDI14
- REF-SANDBOX-ADOPTION-ARXIV24
- REF-TAOUP-SECWRAP
