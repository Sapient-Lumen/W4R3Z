# D-TURNS posture v0 (single active turn; far calls async; no hidden pumping)

Purpose: pin an implementable **Phase 1** meaning for **D-TURNS** so turn-based services stay a small **user-space/runtime discipline** rather than widening into a scheduler contract, a portable reentrancy/interleaving API, or a hidden inbox-pumping convenience surface.
It narrows the already-present vat/turn idea into one compact posture adjacent to **D-CAPRPC**, **D-RR**, **D-REQCTX**, and **D-BRACKET** so validators, replay tooling, and reentrancy harnesses can reason about one default shape.

## Posture (v0)

1) **Per-component runtime discipline, not a kernel/global scheduler contract**
   - **D-TURNS** remains a deployable runtime/profile choice for selected components and service sets, not a kernel promise about global scheduling order.
   - The privileged core may expose existing scheduling, wait, and tracing primitives, but turn discipline lives in the owning runtime.
   - This keeps the seam restartable, profile-shaped, and killable by policy rather than baking vat semantics into the platform core.

2) **Exactly one active turn per vat/component instance in v0**
   - A D-TURNS component processes at most one inbound message/turn at a time.
   - While a turn is active, the runtime does not deliver another inbound call/callback into that same vat/component instance.
   - This is the concrete **I-TURNS-1** posture Phase 1 validators should assume unless and until a future schema/RFC explicitly widens it.

3) **Far calls stay asynchronous; no cross-vat synchronous call chains**
   - Cross-vat / cross-component calls return promises, deferred replies, or explicit later-turn outcomes.
   - Synchronous local calls are fine only inside one vat/component instance.
   - The portable posture therefore composes naturally with **D-CAPRPC** promise pipelining and keeps **D-RR** replay/logging closer to turn-level events rather than thread interleavings.

4) **No hidden inbox pumping under blocking/await convenience APIs**
   - A convenience `await` / blocking helper must either block without servicing inbound work, or schedule an explicit continuation/future path.
   - It MUST NOT remain “responsive” by secretly pumping the inbound queue while waiting.
   - This is the concrete runtime reading of **PO-TURNS-NOREENTR** and the main mitigation for **AC-064**.

5) **Reentrancy/interleaving opt-outs are implementation-local, not portable contract**
   - Phase 1 deliberately declines a portable `reentrant`, `always_interleave`, `allow_callback_during_wait`, or equivalent API/manifest knob.
   - If an implementation needs finer-grained interleaving for a particular service, that stays implementation-local, explicitly reviewed, and non-portable.
   - SlopOS v0 therefore does not standardize a general “let another turn in now” escape hatch.

6) **Scale-out should prefer **explicit sharding / more vats** over silently widening one vat into a shared-state threaded service**
   - Higher throughput should come from more vats/shards, narrower services, or explicit partitioning, not from turning one vat into a hidden multi-threaded mutable-state region.
   - This keeps concurrency boundaries reviewable and keeps replay/test harnesses aligned with the declared service decomposition.
   - Embedded profiles can stay with tiny loops; workstation/cloud/agent profiles can scale by adding more vats rather than widening one ambient scheduler surface.

7) **External action semantics stay on existing conflict keys and ordering witnesses**
   - When a turn emits an externally visible action, that action keeps the existing **D-COMMUTE / CH-ORDERTOK** rules, conflict keys, serialization owner, and receipt/evidence story it already had.
   - **D-TURNS** does not mint a new portable conflict-key family, queue order API, or sequencing broker.
   - Turn discipline is therefore a local concurrency posture, not a replacement for explicit commutativity declarations.

8) **No new workflow / ACP / admin surface on D-TURNS.**
   - Phase 1 introduces no new workflow portal, no new **CH-ACP** family, and no general remote/admin protocol for “pause vat”, “force reenter”, “step scheduler”, or “list queued turns”.
   - Any future administrative or debugging surface must pay its own schema, commutativity, and evidence cost explicitly.
   - This keeps D-TURNS from quietly becoming a hidden control plane.

9) **Sealed compat remains killable and non-ambient**
   - Compat runtimes may adapt foreign event loops only through explicit, policy-killable integration points.
   - They must not recreate ambient thread-locals, hidden callback pumps, implicit scheduler joins, or path/env-based activation that would bypass the declared turn boundary.
   - Any interop remains subordinate to sealed compat policy and must fail closed when disabled.

## Phase 1 non-goals (explicitly deferred)

- A portable reentrancy/interleaving annotation or manifest flag beyond the narrow v0 posture.
- A general scheduler or debugger API for enumerating, injecting, or reordering turns.
- Cross-vat synchronous call chains or hidden callback pumping convenience wrappers.
- A new workflow/admin protocol or conflict-key family specific to D-TURNS.
- Any claim that all SlopOS components must use vats; **D-TURNS** remains optional and selective.

## Wiring

- Decision surface:
  - `decision-map.md` (D-TURNS)
- Adjacent runtime surfaces:
  - `mechanisms.md`
  - `rfcs/0078-turn-based-concurrency-and-reentrancy-guards.md`
  - `rfcs/0026-object-capability-rpc-profile.md`
  - `docs/30-architecture/request-context-schema-v1.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-TURNS-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-TURNS-NOREENTR**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-064**)
- Related posture/history surfaces:
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/llm-runbook.md`

CI drift gate:
- `tools/check_turns_posture.py` fails `make lint` if this posture stops being discoverable, loses the Phase 1 **one active turn / far-call async / no hidden pumping / no portable reentrancy knob** constraints, or drops the primary REF wiring.

## References

- REF-ROBUST-COMPOSITION.
- REF-E-LRM.
- REF-SPRITELY-CORE.
- REF-ORLEANS-REQUEST-SCHED.
