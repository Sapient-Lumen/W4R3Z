# CH-KABI v0 (privileged action schema, informal)

Purpose: a closed, canonical "privileged action" format for IF-KABI (syscalls/hypercalls/VM-exits/faults/IRQs) so that decoding/dispatch is total and fail-closed (C-ABI-1; C-HV-1).

Design constraints (v0)
- closed enum of `kind` (budgeted in `exit-surface-budget.md`)
- total parsing + deterministic rejection on unknown fields (I-ENC-1; PO-ENC-DECODE)
- bounded sizes for variable-length fields
- no stringly-typed effects; typed fields only

## Action shape (v0)
An action `a` contains:
- `schema`: fixed `CH-KABI v0`
- `kind`: one of a closed enum
- `source`: `{ syscall | hypercall | vmexit | fault | irq }` (closed enum)
- `subject`: domain/VM identifier (typed handle; may be `none` for boot-time)
- `args`: fixed fields per `kind`
- `meta`: optional `{ seqno, flags, order_digest?, conflict_key_digest? }` (bounded; ignored unless explicitly enabled)
  - `order_digest`: digest(CH-ORDERTOK v0) for ordered kinds
  - `conflict_key_digest`: digest(CH-CONFLICTKEY v0) for the action conflict key (supports D-COMMUTE evidence)

## Seed kind families (keep small)
The *real* kind list is an ADR-level decision once evidence exists; v0 names the families only.
- `cap.derive` / `cap.restrict` (PO-CAP-ATTEN)
- `mem.map` / `mem.unmap` / `mem.share` (I-MAP-1, I-SHARE-1)
- `ipc.send` / `ipc.recv` / `ipc.close` (ordered per `endpoint_id`; ordered actions SHOULD carry `meta.order_digest = digest(CH-ORDERTOK v0)` and `meta.conflict_key_digest = digest(CH-CONFLICTKEY v0)`; PO-HOT-IPCORDER)
- `domain.create` / `domain.enter` / `domain.destroy`
- `fault.handle` (typed fault class; no implicit emulation)
- `irq.route` / `irq.ack` (explicit routing policy)

Conditional families (profile-gated; still closed enums when enabled)
- `budget.mint` / `budget.revoke` (D-BUDGET/D-METER; issuance is the explicit serialization point; ordered actions SHOULD carry `meta.order_digest = digest(CH-ORDERTOK v0)` and `meta.conflict_key_digest = digest(CH-CONFLICTKEY v0)`; PO-HOT-QUOTATOK)

## Decoder/dispatcher obligations
- reject unknown `kind`, `source`, or fields
- reject values outside declared bounds
- no side effects prior to full validation
- stable, bounded error codes (PO-ABI-TOTAL)

Evidence hooks
- E1: property tests for "unknown variant ⇒ reject" and "reject ⇒ no side effects" (PO-XS-CLOSESET)
- E2: bounded model check of decoder totality and closed-set dispatch
