# Capshell interrupt/cancel posture v0 (no portable signal-control plane)

Purpose: keep **D-CAPSHELL** honest once the archive admits an *integrated* shell/session UX.
Even after banning PATH lookup, shell command strings, startup hooks, word expansion, and PTY/job
control, an integrated shell could still quietly recreate a second authority plane if interrupt,
termination, or “kill this job” semantics are standardized as shell-owned **signals** rather than
staying on the archive's explicit workflow seams.

This doc freezes the smaller Phase 1 answer: **`capshell.exec` binds cancellation through explicit
request/workflow seams, not through a portable signal-injection or shell-owned process-control
plane**. Local UX may map gestures such as Ctrl-C into those explicit seams, but raw signal behavior
remains implementation detail rather than portable capshell contract.

## Posture (v0)

1) **No portable signal-injection / kill plane in v0**
   - A `capshell.exec` launch does **not** imply permission to send POSIX/Unix signals, name signal
     numbers, target process groups, or address shell jobspecs as part of the portable workflow
     seam.
   - Phase 1 adds no `capshell.signal`, `capshell.kill`, `capshell.interrupt`, `capshell.hup`,
     `capshell.stop`, or equivalent ACP/admin/query family.

2) **Cancellation stays on explicit request/workflow seams**
   - If D-REQCTX is enabled, the portable cancellation surface for `capshell.exec` is the bound
     `reqctx_digest = digest(CH-REQCTX v1)` carried by CH-EXECPACK v2 and CH-ACP metadata.
   - If an operator or local shell UX interrupts running work, the portable meaning is **cancel the
     bound request/workflow** (or deny a later effect), not “deliver SIGINT/SIGTERM as portable
     authority”.
   - Exported outcomes therefore stay on the existing stable request/workflow result seams
     (`CANCELLED`, `DEADLINE_EXCEEDED`, explicit reject/accept receipts), not on host-specific
     signal names or numeric exit conventions.

3) **Raw signal handling stays local and non-authoritative**
   - Runners MAY use host/runtime-specific signal handling internally to implement cancellation or
     cleanup, but those details are **local implementation technique**, not portable SlopOS
     contract.
   - CH-REQCTX, CH-EXECPACK, CH-ACPOUT, and the transcript surfaces do **not** grow signal-name,
     signal-number, or shell-jobspec fields in Phase 1.
   - Explicit interpreters/shells MAY still implement their own language-level `trap` / signal
     behavior after launch, but that behavior belongs to the chosen interpreter, not to the
     `capshell.exec` seam itself.

4) **Session exit / hangup does not become a portable lifecycle grant**
   - Integrated capshell session exit, terminal disconnect, or local hangup events do **not** become
     a portable “send SIGHUP to descendants” or “keep detached shell jobs alive” contract.
   - Durable/background continuation remains on explicit D-JOBS / D-BGLEASE ownership seams, not on
     shell exit conventions, `disown`, or hidden signal relay.

5) **No hidden signal semantics in effect/wallet review surfaces**
   - CH-EFFCON and CH-WALLET review surfaces remain about explicit effect families / explicit held
     authority; they do **not** acquire signal permissions, shell job identifiers, or a new
     “interrupt rights” family through capshell convenience.
   - Any future stronger stop/terminate control surface must return RFC-first on its owning seam
     rather than widening D-CAPSHELL v0 in place.

6) **Commutativity and ordering stay on existing action seams**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - Ordering for `capshell.exec` remains the existing `domain.id` story; if an owning workflow such
     as D-JOBS or D-QUIESCE later defines explicit cancel/terminate actions, serialization lives on
     those target seams rather than inside hidden shell signal relay.

7) **Sealed compat remains killable and non-ambient**
   - Compat/foreign-cell adapters MAY translate local cancellation into guest/runtime mechanisms, but
     portable interop remains request/workflow-bound and policy-killable.
   - Phase 1 does **not** standardize ambient signal/env/path based cancel propagation across
     membranes, and compat shims MUST NOT treat host signal conventions as a second portable control
     plane.

8) **Interactive UX remains local and non-authoritative**
   - Local keybindings such as Ctrl-C MAY exist, and front-ends MAY show “interrupt requested” UI,
     but those affordances are local UX wrappers around explicit cancellation semantics.
   - They MUST NOT redefine the portable meaning of `capshell.exec`, mint a jobspec namespace, or
     create a hidden shell-owned process inventory/query surface.

## Phase 1 non-goals (explicitly deferred)

- A portable `kill(2)` / signal-send surface in D-CAPSHELL.
- Signal names/numbers or jobspec targets in CH-EXECPACK / CH-REQCTX / CH-ACPOUT.
- Shell-owned `disown` / SIGHUP / stop-continue lifecycle semantics as workflow contract.
- A generic interrupt/terminate admin plane for arbitrary descendants.
- Exporting host-specific signal-exit conventions as portable automation semantics.

## Why this cut is worth making

Real shells and terminals tie interrupt behavior to **signals**, process groups, and shell-owned
policies. POSIX `sh` explicitly specifies behavior when the shell receives `SIGINT`, and terminal
foreground/background rules affect which processes receive keyboard-generated signals. Bash also
layers additional shell policy on top (for example, interactive handling of `SIGINT` / `SIGTERM`
and jobs receiving `SIGHUP` on shell exit).

That is exactly why Phase 1 needs a smaller answer: SlopOS already has an explicit cancellation seam
(**D-REQCTX**) and explicit owner seams for long-lived/deferred work (**D-JOBS**, **D-BGLEASE**,
**D-QUIESCE**). Reusing those is cheaper and more coherent than silently importing a second
signal-control contract into D-CAPSHELL.

This cut keeps the four product shapes honest:
- **secure workstation (A):** local shell UX can still expose interrupt affordances, but portable
  automation review stays on explicit request/workflow seams instead of inherited host signal lore;
- **cloud micro-VM / hosted substrate (B):** headless automation does not need a portable signal or
  terminal process-group story to remain operable;
- **embedded / separation appliance (C):** small deployments avoid importing shell signal/session
  baggage as part of the automation substrate;
- **agent/automation OS (D):** LLM-authored workflows stay transcriptable and replay-friendly,
  because cancellation is described as explicit request/workflow state rather than opaque
  signal-number folklore.

## Wiring

- Decision surface: `decision-map.md` (D-CAPSHELL).
- Existing schema/control seams: `request-context-schema-v1.md`, `capshell-exec-pack-schema-v2.md`,
  `acp-outcome-receipt-schema-v0.md`, `docs/70-llm-control/acp-action-kind-registry.md`,
  `docs/70-llm-control/acp-validator-semantics.md`.
- Adjacent posture docs: `reqctx-posture-v0.md`, `capshell-job-control-posture-v0.md`,
  `background-lease-posture-v0.md`, `job-portal-posture-v0.md`, `quiesce-posture-v0.md`.
- Assurance anchors: **I-CAPSHELL-CANCEL-1**, **PO-CAPSHELL-NOSIGNAL**.
- Policy killability stays the existing `cfg.params.lane.capshell` seam; this posture adds **no new
  lane knob**.
- CI drift gate: `tools/check_capshell_interrupt_cancel_posture.py` (EVID-2026-326).

## References

- REF-OPENGROUP-SH
- REF-OPENGROUP-TERMINAL-IFACE
- REF-BASH-SIGNALS
