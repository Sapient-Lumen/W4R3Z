# Exit/dispatch decode contract (IF-KABI)

Purpose: make "decode ⇒ dispatch" mechanically checkable and resistant to parser differentials.

## Contract
For any input event (syscall/hypercall/VM-exit/fault/IRQ), the IF-KABI boundary must:
1) deterministically select a *single* decode path,
2) either produce a valid `CH-KABI v0` action value or reject,
3) perform **no** privileged side effects prior to full validation.

## Fail-closed rules
- unknown variants reject (PO-XS-CLOSESET)
- unknown fields reject (I-ENC-1)
- invalid bounds reject
- no hidden "slow paths" that interpret raw bytes differently

## Hypervisor-first note
For VM exits, any instruction emulation must be represented as explicit `CH-KABI` actions; no implicit emulation via ad-hoc decode branches (supports C-HV-1).

Evidence hooks
- E1: corpus tests: equivalence classes of inputs map to a unique action or reject
- E2: bounded checks: decoder is total over the declared input space

## Normalization (raw exit → exit-action kind)
Hardware exposes many raw exit reasons. CH-KABI deliberately budgets a smaller set of **exit-action kinds** (see `exit-surface-budget.md`).

Contract:
- Decoder maps each supported raw exit reason into a *normalized* `exit.kind` enum variant.
- Optional `exit.subkind` may carry the raw reason code for telemetry/debugging, but must not widen authority or introduce new behavioral branches.
- Any raw reason outside the supported mapping is rejected or escalated as a controlled `UnsupportedExit` error (fail-closed).

This keeps the proof surface tied to the *normalized* kinds rather than to the full hardware enum.
