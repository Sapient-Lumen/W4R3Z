# CH-BOOT v0 (boot manifest / measurement record, informal)

Purpose: describe the booted artifact set and policy bindings so C-BOOT-1 can be stated as a predicate over explicit bytes.

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- binds a specific policy/config revision to a set of artifact digests
- optional anti-rollback floor (only meaningful if A-BOOT-2 holds)

## Shape (v0)
A manifest `m` contains:
- `schema`: fixed `CH-BOOT v0`
- `boot_policy_rev`: policy revision identifier
- `cfg_digest`: digest of the applied `CH-CFG v0` artifact
- `artifacts`: closed list of `{ name_tag, digest, role }` (bounded)
  - role examples (non-authoritative): `kernel`, `init`, `policy`, `boot_selector` (CH-BOOTSEL), `upd_manifest` (CH-UPD), `comp_manifest` (CH-COMP), `harden_profile` (CH-HARDEN), `hwfacts` (CH-HWFACT), `meas_log` (CH-MEASLOG), `proof_bundle`
- `measurements`: optional digest reference to a measured-boot/integrity log (recommended: digest of CH-MEASLOG v0); may be omitted if the profile is verified-boot-only
- `rollback_floor`: optional `{ counter_id, min_value }`
- `prov_attestation_digest`: optional digest of a signed provenance envelope/container (e.g., CH-SIGENV) that signs a `CH-PROV v0` payload digest (for D-PCP; supports C-PROV-2)

Note under `ext.microvm`: if a deployment chooses to export which admitted reusable warm-start leaf or owner-local recovery artifact was resumed, that binding rides on ordinary owner-local `CH-BOOT` / `CH-PROV` / deployment-receipt evidence rather than a new guest-visible leaf-id plane. Phase 1 standardizes no dedicated `CH-BOOT` field or required artifact role for warm-start leaf identity (`microvm-resume-admission-evidence-posture-v0.md`).

## Verification obligations
- verify signatures/measurements per deployment profile (PO-BOOT-VERIFY)
- if `measurements` is present: validate the referenced CH-MEASLOG and fail closed on structural/binding mismatches (PO-MEASLOG-VALIDATE)
- bind `cfg_digest` to the applied config and fail closed on mismatch (PO-BOOT-BIND)
- if `rollback_floor` present: enforce at install/boot time (I-BOOT-2)
- if `prov_attestation_digest` present: verify it is present/valid and bound to the booted artifacts (PO-PROV-BIND)
- if a `comp_manifest` artifact is present: record/export its digest for audit and treat mismatches as policy violations (PO-COMP-BIND)
