# CH-UPD v0 (update / release manifest, informal)

Purpose: represent “what we intend to install” as explicit, canonical bytes that can be signed, logged, and verified.

Design goal: a **small** manifest that binds update intent to the same digest universe used by CH-BOOT and CH-PROV.

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- binds a target deployment root to the configuration/policy used
- supports optional anti-rollback floor semantics (I-BOOT-2)

## Shape (v0)
A manifest `u` contains:
- `schema`: fixed `CH-UPD v0`
- `target_root_digest`: digest of the deployment root tree (content-addressed)
- `cfg_digest`: digest of the `CH-CFG v0` artifact to apply with this deployment
- `artifacts`: closed list of `{ name_tag, digest, role }` (bounded)
  - role examples: `kernel`, `init`, `policy`, `comp_manifest`, `proof_bundle`
- `rollback_floor`: optional `{ counter_id, min_value }`
- `prov_attestation_digest`: optional digest of a signed provenance envelope/container (e.g., CH-SIGENV) that signs a `CH-PROV v0` payload digest
- `created_at`: optional timestamp (informational; not used for authorization)
- `expires_at`: optional timestamp (informational; policy may require freshness)

## Verification obligations
- verify signatures / threshold policy per deployment profile (D-UPD-SIGN)
- verify `cfg_digest` matches the applied config (PO-CFG-VERIFY)
- verify each listed artifact digest matches fetched/installed content (PO-AREF-VERIFY when CH-AREF is used)
- verify `target_root_digest` matches the staged deployment tree (PO-UPD-VERIFY)
- if `rollback_floor` present: enforce at install/boot time (I-BOOT-2)
- if `prov_attestation_digest` present: verify it is present/valid and bound to the staged artifacts (PO-PROV-BIND)

Notes:
- CH-UPD does not dictate the distribution protocol. It can be transported inside TUF metadata or other channels, but the privileged boot path remains agnostic.
- If D-ATOMICUPD uses A/B-style health-commit semantics, the boot selector state (CH-BOOTSEL) SHOULD store the chosen `upd_digest` so post-boot audit can link selection/rollback decisions to a specific signed intent.
