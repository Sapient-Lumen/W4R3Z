# CH-ORD v0: interface ordinal manifest (optional)

Purpose: make **method identifiers (ordinals)** for CH-CAPRPC explicit, stable, and audit-friendly.

This schema is intentionally small:
- it does **not** define signatures (that lives in the chosen IDL under D-IDL),
- it exists to prevent silent renumbering, collisions, or accidental reuse,
- it enables tooling to diff and gate upgrades for open interfaces.

Constraint: closed-world, canonical encoding (I-ENC-1). Unknown keys/variants reject.

## Shape

```text
CH-ORD-v0 {
  schema: "CH-ORD";
  version: 0;

  # What this ordinal manifest applies to
  iface_digest: bytes32;         # digest of the stable interface pin (CH-IFACE)

  # The interface-definition artifact used to generate this mapping.
  # NOTE: for open interfaces, CH-IFACE.idl_digest is often omitted to keep iface_digest stable;
  # CH-ORD is how we pin a specific IDL revision for build/codegen.
  idl_digest: bytes32;           # digest of the canonical IDL input/IR (D-IDL)

  # Generator identity (drift guard)
  generator: {
    name: tstr;                  # e.g., "mk-idlgen" or "caprpc-witgen"
    version: tstr;               # semantic version or git describe
  };

  # Method ordinal mapping for CH-CAPRPC.method_id
  methods: list<MethodOrd>;

  # Optional reserved ranges.
  # Recommendation: reserve the high bit (bit 31) for framework/runtime internal method_ids.
  reserved?: list<ReservedRange>;

  notes_tag?: tstr;              # bounded; ignored by validators
}

MethodOrd {
  name: tstr;                    # human label; should match the IDL method name
  method_id: u32;                # the on-wire CH-CAPRPC.method_id
}

ReservedRange {
  start: u32;
  end: u32;                      # inclusive; require start<=end
  reason_tag?: tstr;
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `iface_digest` and `idl_digest` are exactly 32 bytes.
- `methods` length ≤ 4096 (default bound; profile may lower).
- Each `MethodOrd.name` is non-empty and ≤ 128 bytes.
- `method_id` values are unique within `methods`.
- If present, `reserved` length ≤ 128; ranges must be non-overlapping.
- If a `method_id` falls within any `reserved` range, the validator MUST reject.

## Ordinal policy guidance (D-IDL / D-APIEVO)
- Prefer **stable hash-derived ordinals** for *open* interfaces so new methods can be added without renumbering.
- Prefer **explicit numeric ordinals** for closed/high-assurance interfaces.
- Never reuse an ordinal for a different semantic operation.

See: `docs/60-engineering/idl-digest-and-ordinal-policy.md`.
