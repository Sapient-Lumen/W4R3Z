# Capshell launch privilege-gain posture v0 (no setuid / file-cap escalation)

Purpose: keep **D-CAPSHELL** honest when a reviewed workflow launch could still gain authority
simply because the selected program or inherited thread state carries **privileged exec** semantics.
The archive already makes argv/env/cwd/stdio/fd bindings explicit, but that promise still drifts if
`capshell.exec` can widen child authority through set-user-ID / set-group-ID bits, file
capabilities, ambient capability state, or similar exec-time privilege transitions that never appear
in the reviewed execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic
credential-management API, a per-step “run as root” surface, or a reviewed descriptor for arbitrary
UID/GID/capability tuning. It only freezes the minimum Phase 1 posture needed so launch behavior no
longer depends on hidden privileged-exec metadata or parent privilege state.

## Posture (v0)

1) **No privilege gain at the launch boundary in Phase 1**
   - `capshell.exec` MUST NOT gain authority merely because the selected executable has set-user-ID
     or set-group-ID bits, attached file capabilities, or equivalent privileged-exec metadata.
   - Ambient launch privilege state also includes inherited ambient/inheritable capability posture or
     similar exec-preserved privilege state that can widen child authority without appearing in the
     reviewed execution pack.

2) **Phase 1 adds no reviewed per-step credential/capability elevation surface**
   - Phase 1 introduces no reviewed `capshell.cred.*` / `capshell.priv.*` ACP/admin family, no
     per-step “run as user/group”, no “preserve privileges” knob, and no reviewed file-capability
     or ambient-capability policy surface.
   - The portable seam is therefore smaller: **reviewed workflow launch must not gain privilege
     across `exec`**.
   - If a deployment needs privileged helpers, that remains local runtime/provider architecture and
     must not be smuggled in as hidden shell/session exec behavior.

3) **Launch guarantees no privilege gain before exec**
   - Before `exec` (or via equivalent spawn attributes / runtime controls), the runner/wrapper MUST
     guarantee that child launch cannot gain privilege relative to the runner's already-reviewed
     authority posture.
   - On platforms that provide a one-way **no-new-privileges** control (for example Linux
     `no_new_privs`), runners SHOULD use it before `exec`.
   - Runners/wrappers MUST NOT rely on setuid/setgid transitions, file capabilities, ambient
     capability carry-over, or similar exec-time privilege lore to widen child authority.
   - Compat/foreign-cell membranes that cannot guarantee that no-privilege-gain posture MUST fail
     closed rather than preserving host defaults.

4) **Programs may still drop privilege further after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen program after it begins running.
   - Programs may still voluntarily narrow their own privilege posture after launch, but Phase 1
     reviewed workflow meaning never depends on launch-time privilege gain.

5) **Other explicit seams do not secretly mint or preserve exec privilege state**
   - **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and
     **CH-REQCTX v1** do not authorize preserving privileged-exec metadata, ambient capability
     state, or caller/session privilege posture.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, startup hooks,
     terminal/job-control UX, or interrupt UX) MUST NOT become hidden carriers for privilege gain.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no reviewed privilege-elevation descriptor family, no policy knob for “allow
     privileged exec for this step”, and no admin/query surface for “what extra privilege was gained
     at launch?”
   - If later evidence shows real need for reviewed launch-time credential/capability control, that
     work must return as **one new explicit decision surface** rather than by silently inheriting
     host privileged-exec behavior.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden privilege-gain
     semantics at `exec` time.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose host setuid/setgid/file-capability behavior or ambient
     capability carry-over as a hidden side channel around the reviewed execution pack.
   - If a foreign runtime cannot bypass privileged-exec metadata or cannot guarantee a no-gain
     launch posture, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable per-step UID/GID / supplementary-group / capability descriptor in Phase 1.
- No portable “run as root/admin”, “preserve privileges”, or setuid/file-capability workflow knob.
- No privileged-exec compatibility table translating host wrapper/service-manager policy into
  D-CAPSHELL semantics.
- No portable query/report surface exposing launch-time gained credentials or capability sets.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-credential-baseline-posture-v0.md`
  - `capshell-umask-posture-v0.md`
  - `capshell-rlimit-posture-v0.md`
  - `capshell-signalstate-posture-v0.md`
  - `capshell-scheduling-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-PRIVGAIN-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-PRIVGAIN-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_privgain_posture.py` (**EVID-2026-333**).

## References

- REF-MAN7-EXECVE
- REF-MAN7-PR-SET-NNP
- REF-MAN7-CAPABILITIES
