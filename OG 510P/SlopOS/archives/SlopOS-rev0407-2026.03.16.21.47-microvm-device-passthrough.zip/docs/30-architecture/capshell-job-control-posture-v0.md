# Capshell terminal/job-control posture v0 (no portable PTY or controlling-terminal plane)

Purpose: keep **D-CAPSHELL** honest once the archive admits an *integrated* shell/session UX.
Explicit argv/env/cwd/stdio/fd bindings still are not enough if the runner quietly grows a second
authority plane through pseudo-terminals, controlling-terminal ownership, process groups, or
shell-managed foreground/background job control. Those semantics are powerful, stateful, and easy to
smuggle in as “just shell convenience”.

This doc freezes the smaller Phase 1 answer: **`capshell.exec` remains an explicit execution-pack
launch seam, not a portable PTY / controlling-terminal / job-control substrate**.
Interactive UX may exist locally, but it does not become a new authority-bearing workflow contract.

## Posture (v0)

1) **No implicit controlling terminal / PTY grant in v0**
   - A `capshell.exec` child launch does **not** imply a controlling terminal, PTY allocation,
     terminal-session leadership, process-group manipulation, or inherited terminal mode state.
   - CH-STDIO / CH-FDSET stay the only portable child-I/O binding surfaces in Phase 1.

2) **CH-STDIO / CH-FDSET stay explicit file/descriptor binding surfaces**
   - Phase 1 does **not** add terminal-device selectors, PTY master/slave descriptors, tty names,
     “inherit current terminal”, or equivalent ambient terminal selectors to CH-STDIO or CH-FDSET.
   - A runner MUST NOT reinterpret existing `docref` bindings as permission to conjure a PTY,
     controlling terminal, or shell job-control domain.

3) **No shell job-control plane**
   - Phase 1 declines a portable `fg` / `bg` / `jobs` / suspend-resume / shell-owned process-list
     surface around `capshell.exec`.
   - The integrated capshell prompt may show local progress/status, but it MUST NOT standardize a
     second authority-bearing foreground/background control plane beside reviewed workflow actions.

4) **Background and deferred work stay on explicit existing seams**
   - Long-lived/deferred execution belongs to **D-JOBS** and **D-BGLEASE**, not to hidden shell job
     control, prompt-time resume logic, or PTY/session ownership conventions.
   - “Run later”, “keep running when I leave”, and “start in background at login/boot” therefore
     stay review-bound portal workflows rather than shell affordances.

5) **Interactive UX remains local and non-authoritative**
   - Line editing, prompts, and local terminal widgets MAY exist as front-end UX, but they do not
     change the reviewed `capshell.exec` contract or widen child authority.
   - Any future portable interactive-terminal broker must return as its own RFC-first seam rather
     than hiding inside D-CAPSHELL v0.

6) **Commutativity and ordering stay on existing action seams**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - If an explicit `capshell.exec` launches a child, ordering remains the existing `domain.id`
     story for `capshell.exec`; if deferred/background presence is needed, serialization lives on
     the already-defined D-JOBS / D-BGLEASE target seams.

7) **Sealed compat remains killable and non-ambient**
   - Compat/foreign-cell adapters MUST NOT recreate host PTY inheritance, controlling-terminal
     capture, shell job lists, or hidden `fg`/`bg` escape hatches behind the membrane.
   - Any interop remains policy-killable and must not create ambient channels through host terminal
     state.

8) **No new workflow / ACP / admin surface**
   - Phase 1 adds no `capshell.pty.*`, `capshell.job.*`, `capshell.fg`, `capshell.bg`, `capshell.jobs`,
     or equivalent admin/query family.
   - Terminal/session lifecycle remains a local implementation detail unless/until a future explicit
     surface is accepted.

## Phase 1 non-goals (explicitly deferred)

- Portable PTY allocation/duplication semantics in CH-STDIO / CH-FDSET.
- Controlling-terminal ownership transfer as part of `capshell.exec`.
- Shell-standardized foreground/background job control (`fg`/`bg`/`jobs`) as a workflow surface.
- Prompt-driven resume/suspend orchestration or shell-owned process inventories.
- A generic terminal broker or interactive session capability family.

## Why this cut is worth making

POSIX terminal/job-control semantics are not mere presentation details. A controlling terminal
interacts with **foreground/background process groups** and signal delivery; shell job control adds a
second state machine for suspend/resume/foregrounding around those groups. Standardizing that inside
D-CAPSHELL would create a large hidden coordination and authority surface right next to our
explicit execution-pack model.

The smaller Phase 1 cut keeps the archive coherent:
- **secure workstation (A):** interactive shells still exist, but ambient PTY/session ownership does
  not silently bypass review-bound workflow seams;
- **cloud micro-VM / hosted substrate (B):** automation stays transcriptable without implying a
  terminal broker in headless environments;
- **embedded / separation appliance (C):** no shell job-control baggage is imported into the small
  deployment profile;
- **agent/automation OS (D):** LLM-authored workflows stay on explicit CH-EXECPACK/CH-REQCTX/
  CH-EFFCON surfaces rather than inheriting an opaque foreground/background state machine.

## Wiring

- Decision surface: `decision-map.md` (D-CAPSHELL).
- Existing schema/control seams: `stdio-schema-v0.md`, `fdset-schema-v0.md`,
  `capshell-exec-pack-schema-v2.md`, `docs/70-llm-control/acp-action-kind-registry.md`,
  `docs/70-llm-control/acp-validator-semantics.md`.
- Adjacent posture docs: `capshell-startup-profile-posture-v0.md`,
  `capshell-word-expansion-posture-v0.md`, `capshell-pipeline-posture-v0.md`.
- Background/deferred work seams: `job-portal-posture-v0.md`, `background-lease-posture-v0.md`.
- Assurance anchors: **I-CAPSHELL-TTY-1**, **PO-CAPSHELL-NOTTY**.
- Policy killability stays the existing `cfg.params.lane.capshell` seam; this posture adds **no new
  lane knob**.
- CI drift gate: `tools/check_capshell_job_control_posture.py` (EVID-2026-325).

## References

- REF-BASH-JOB-CONTROL
- REF-OPENGROUP-TERMINAL-IFACE
