# D-IOLEASE posture v0 (manual-only device leasing; deny-by-default hotplug; consent receipts)

Purpose: pin an **implementable Phase 1** meaning for device access that keeps peripherals non-ambient (D-DEVGUARD), keeps sealed-compat honest (D-FCELL), and prevents drift into “just expose /dev + udev”.

This doc is intentionally narrow: it does **not** design a full automation surface for device leasing. Phase 1 treats device attach as a *human-visible* workflow.

## Posture (v0)

1) **No ambient device namespace**
   - There is no privileged or default user-space API that hands out “device handles by path/name” (no ambient `/dev`, no ambient udev-like discovery surface).
   - Components obtain device access only via explicit mediation workflows (portals) that return capability-bearing handles plus redaction-safe descriptors.

2) **`portal.device.*` is manual-only in Phase 1 (no ACP kind)**
   - Phase 1 explicitly forbids an ACP kind such as `portal.device.request`.
   - Rationale: hotplug is adversarial input; automating it before the trusted UI + DMA posture is nailed down is high entropy.
   - In the Agent/automation profile (D), devices can still be used — but only through a *human-mediated* portal flow that yields transcript-visible receipts.

3) **Every lease grant/revoke is receipted (CH-RECEIPT) and transcript-visible**
   - Any allow/deny decision that results in an active device lease MUST emit a consent receipt `digest(CH-RECEIPT v0)`.
   - The receipt binds the action/request digest and (when applicable) the derived `conflict_key_digest`/`order_digest` fields for observability (D-COMMUTE).
   - The receipt is **non-authoritative**; it is an audit artifact only.

4) **Device I/O bounds are described by CH-IOLEASE; live authority is a separate handle**
   - The portal/driver manager returns a live capability handle for the queue/endpoint/IRQ surface.
   - `CH-IOLEASE v0` is a redaction-safe descriptor of the intended bounds (no secrets), suitable for policy checks and audit (I-IOLEASE-3; PO-IOLEASE-VALIDATE).
   - Revocation must be effective: after revoke, the lessee cannot submit work, DMA, or receive interrupts via that lease (I-IOLEASE-2; PO-IOLEASE-REVOKE).

5) **DMA-class hotplug is fail-closed behind D-DMA**
   - Some “peripherals” are effectively *bus-to-memory* (e.g., Thunderbolt/USB4 PCIe tunneling). Treat them as DMA-class.
   - If the profile cannot meet the D-DMA posture (see `dma-posture-v0.md`), `portal.device.*` MUST deny-by-default and emit a receipt/denial.
   - Phase 1 favors `dma_window.kind="policy_ref"` exports (not raw address ranges) to avoid leaking sensitive topology (I-IOLEASE-3).

6) **Sealed compat does not get devices directly**
   - Foreign cells MUST NOT observe ambient devices.
   - Any device access on behalf of a foreign cell is mediated via an explicit adapter + portal flow, and accompanied by the usual per-op receipts (D-FCELL, I-COMPAT-1/I-COMPAT-2).

7) **Commutativity/ordering stance (v0)**
   - Phase 1 places device-lease serialization inside the `portal.device` service (explicit boundary) and does not yet define a CH-ACP kind surface.
   - Hard decision for future automation: if SlopOS later adds a CH-ACP surface for device attach/lease, per-device serialization MUST use `CH-CONFLICTKEY family="device.id"` (and matching CH-ORDERTOK scope when ordered).
   - `device.id` binds to an explicit typed `device_id` allocated by the device manager / driver authority for one attachable device-presence instance; it MUST NOT be derived from `port_path`, raw serial strings, `/dev` names, or UI labels.
   - OQ-0009 is now resolved by `device-lease-ordering-boundary-v0.md`: `device.id` is the only future ACP-visible ordering family for attach/lease/revoke, while queue/endpoint sequencing remains internal to the live lease / driver host rather than a second portal policy surface.

## Phase 1 non-goals (explicitly deferred)

- **Automated attach/lease issuance** via CH-ACP kinds (ACP support for device attach is Phase 2+ and requires an RFC).
- **Ambient enumeration** (“list all USB devices for any process”). Any enumeration must be portal-scoped and policy-shaped.
- **Persistent auto-attach policies** without an explicit, reviewable policy-as-data artifact (candidate: CH-DEVGUARD; deferred).

## Wiring

- Portal taxonomy + kill switch: `portal-family-registry.md` (`portal.device.*`) and `config-toggle-registry.md` (`cfg.params.lane.portal.device`).
- Under `ext.microvm`, guest-visible VFIO / mediated-device / SR-IOV passthrough meaning is pinned separately as non-portable and non-ambient; guest device presence does not displace explicit `portal.device.*` / CH-IOLEASE issuance as the authority seam (`microvm-device-passthrough-posture-v0.md`).
- Descriptor schema: `io-lease-schema-v0.md` (CH-IOLEASE v0).
- Consent receipts: `consent-receipt-schema-v0.md` (CH-RECEIPT v0).
- Future D-COMMUTE hook (now pinned even though automation is deferred): `conflict-key-family-registry.md`, `conflict-key-schema-v0.md`, `conflict-key-derivation-registry.md`, and `typed-id-contract-v0.md` (`device.id` / `device_id`).
- Ordering boundary resolution: `device-lease-ordering-boundary-v0.md`.
- Decision surfaces: D-DEVGUARD, D-IOLEASE, and D-DMA in `decision-map.md`.

## References

- Desktop portal precedent: REF-XDG-PORTAL-USB.
- Mobile precedent for explicit per-device user permission before communication: REF-ANDROID-USB-HOST.
- Usable “deny-by-default attach” workflow precedent: REF-QUBES-USB.
- Device authorization policy-as-data precedent: REF-USBGUARD-RULELANG.
- DMA-class hotplug risk: REF-THUNDERSPY-REPORT and REF-WIN-KDMA.
- Kernel-level device authorization mechanism reference (for prototyping + threat modeling): REF-LINUX-USB-AUTHZ.

CI drift gate:
- `tools/check_iolease_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “manual-only / no ambient device namespace” constraints, or drops its REF wiring.
