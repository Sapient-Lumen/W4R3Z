# D-NAMECERT time boundary v0 (validity gates admission; no auto-detach or background re-eval)

Purpose: narrow the **time/freshness** meaning of **D-NAMECERT** so certificate validity windows do not
quietly become a hidden lease manager, background sweeper, or ambient time-driven namespace control plane.

This doc attaches to the existing **D-NAMECERT / D-NS / D-NONDET / D-TIMEPROOF** seams rather than inventing a
new one. It resolves one practical Phase 1 question: **when CH-NAMECERT carries validity dates or evaluator-
local freshness constraints, are those self-executing live bindings, or merely admission checks on explicit
materialization?**

## Boundary (v0)

1) **Validity/freshness is an admission check, not a live namespace daemon**
   - `Delegation.not_after_ms`, `not_before`-style constraints, and any accepted evaluator-local freshness rules MAY gate whether a local policy path accepts an explicit CH-NAMECERT bundle set **at the moment it evaluates it**.
   - Those checks are part of the explicit local decision to justify a later target-seam action; they are not a standing request to keep re-evaluating live namespace state in the background.
   - Phase 1 therefore treats time/freshness as **proposal admission** for explicit materialization, not as a self-executing lifecycle for already-materialized bindings.

2) **Time inputs remain explicit and fail closed**
   - If local naming policy uses time to evaluate CH-NAMECERT, it MUST rely on the existing explicit time seams: **D-NONDET** Clock handles and/or **D-TIMEPROOF** lower-bound evidence, under local policy.
   - There is no ambient NTP/DNS lookup, no hidden realtime dependency, and no separate privileged clock path on D-NAMECERT.
   - Missing, stale, or insufficient time evidence for a policy that requires it MUST deny the attempted admission fail closed.

3) **Live bindings do not self-expire or self-detach**
   - Once an accepted result has been materialized through explicit **`view.attach`** on a concrete **`view.slot`**, the resulting live namespace state remains governed by the target seam until an explicit later mutation occurs.
   - Passage of time, arrival of a fresher CH-TIMEPROOF, or later recognition that a supporting CH-NAMECERT bundle is now past `not_after_ms` MUST NOT silently rewrite the active view, auto-run `view.detach`, or mutate earlier receipts.
   - Future changes still land through explicit target-seam actions using the existing **`view.slot`** conflict keys and **`svc:view`** serialization boundary.

4) **No background sweeper, watch loop, or timeproof-triggered reconciliation**
   - Phase 1 declines any daemon that periodically scans live bindings for expired CH-NAMECERT provenance and detaches them automatically.
   - Importing a new bundle, receiving a new timeproof, or advancing a secure-time lower bound MAY change the outcome of **future** evaluations, but it does not create a hidden bulk reconcile path for existing slots.
   - If an operator wants a binding removed, that remains an explicit `view.detach` (or equivalent already-reviewed target-seam action), not a side effect of time passing.

5) **Time-bounded live authority belongs on a different seam**
   - If a deployment needs authority that expires *as live state* rather than at admission time, it should use an explicit authority/lifetime seam such as **D-LEASE** or a future RFC-first time-bounded namespace surface.
   - Phase 1 does **not** overload CH-NAMECERT validity fields into a second lease model for views.
   - This keeps local naming evidence small and keeps ambient time from turning into ambient detach authority.

6) **Receipts remain stable, while future admissions re-check time**
   - Proposal/receipt surfaces that record source **`digest(CH-NAMECERT v0)`** provenance remain historical evidence of why a target-seam mutation was accepted when it happened.
   - They are not retroactively invalidated or rewritten when time advances.
   - However, a fresh future admission decision that again relies on the same bundle set MUST re-check the declared validity/freshness rules under current local time policy.

7) **Sealed compat remains honest**
   - Compat shims and foreign-cell bridges MUST NOT smuggle in host-global certificate-expiry daemons, hidden resolver refresh timers, or automatic detach-on-expiry behavior that bypasses the explicit per-slot mutation path.
   - If compat wants time-bounded authority, that must still ride an explicit lease or explicit later `view.detach` action.

## Phase 1 non-goals (explicitly deferred)

- **Automatic detach on `not_after_ms`**.
- **Background re-evaluation / sweepers / timer jobs** for D-NAMECERT live bindings.
- **Retroactive invalidation or rewriting of prior target-seam receipts** when time advances.
- **Timeproof-driven namespace sync/reconciliation**.
- **A built-in lease/renewal model for view bindings** hidden inside CH-NAMECERT validity fields.

## Wiring

- Core local naming posture: `namecert-posture-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- Revocation boundary: `namecert-revocation-boundary-v0.md`
- Target namespace seam: `view-namespace-posture-v0.md`
- Time seams:
  - `nondet-posture-v0.md`
  - `timeproof-posture-v0.md`
- RFC: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-3**, **I-TIME-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-CHAIN**, **PO-NAMECERT-PROJECT**)

CI drift gate:
- `tools/check_namecert_time_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **admission-only / explicit-time / no auto-detach / no background reconcile** stance, or drops its assurance / REF wiring.

## References

- REF-SPKI-RFC2693.
- REF-UCAN-SPEC.
- REF-MACAROONS-NDSS14.
