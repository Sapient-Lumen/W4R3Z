# CH-MEASLOG v0 (measured boot / integrity event log, informal)

Purpose: provide a **portable, replayable measurement log** that can be bound into CH-BOOT and used by verifiers/operators to interpret “measured boot” evidence.

Key point: **PCRs are not interpretable without a log**. A quote over PCR values is only meaningful if a verifier can replay the ordered event log that produced those PCR values.

Refs: REF-TCG-EFI-PLATFORM, REF-TCG-PC-CLIENT-PFP, REF-TCG-IMELP, REF-SYSTEMD-PCR-MEASURE, REF-LINUX-IMA-TEMPLATES.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded size (avoid “ship the whole world” logs by default)
- safe-by-default metadata (no stable hardware IDs, bearer tokens, or user content)
- allows out-of-band storage for larger logs via CH-AREF (I-AREF-1)

## Shape (v0)
A measured-boot log `l` contains:

- `schema`: fixed `CH-MEASLOG v0`
- `source`: closed enum
  - `tpm2_efi_eventlog` (UEFI/firmware-maintained log)
  - `tpm2_userspace` (measurements appended by OS tooling)
  - `ima` (Linux-style IMA event stream) — **must be bounded or referenced via CH-AREF**
  - `custom`
- `bank`: hash algorithm identifier for event digests (e.g., `sha256`)
- `events`: ordered list of measurement events (bounded count)

Each event `e` contains:
- `idx`: monotonically increasing integer starting at 0
- `pcr`: optional integer PCR index (if the event extends a PCR)
- `etype`: closed enum (v0)
  - `firmware`
  - `bootloader`
  - `kernel`
  - `init`
  - `policy`
  - `config`
  - `component`
  - `runtime`
  - `other`
- `digest`: event digest bytes (length determined by `bank`)
- `ref`: optional binding to a boot-listed artifact digest
  - `role`: bounded tag (should match CH-BOOT `artifacts.role` when used)
  - `digest`: digest bytes (must match the referenced CH-BOOT artifact digest)
- `note`: optional bounded string (hint only; MUST NOT contain secrets)

Optional summary fields:
- `pcrs_final`: optional list of `{ pcr, digest }` entries for the final PCR values (same `bank`)
- `aref`: optional CH-AREF reference to the *full* log, if `events` is truncated/bounded for v0

Canonical ordering rules:
- `events` are ordered by `idx`.
- within `pcrs_final`, entries are ordered by `pcr` ascending.

## Binding rules
If CH-MEASLOG is used for a boot:
- CH-BOOT MUST either:
  - include `measurements = digest(CH-MEASLOG)` (preferred), and/or
  - list the CH-MEASLOG digest in `artifacts` with role `meas_log`.

If `ref` is present on an event:
- verifiers SHOULD confirm `ref.digest` is present in CH-BOOT `artifacts` under the declared role.
- mismatches are treated as a policy violation (fail closed for profiles that claim measured-boot integrity).

## Validation obligations
- reject unknown `source` / `etype` variants
- enforce bounds: max events, max note length, max pcrs_final entries
- enforce monotonic `idx` (no gaps, no duplicates)
- if `aref` is present, apply CH-AREF scheme allowlists and digest checks (PO-AREF-VERIFY)
