# CH-NETLEASE v0: Network lease descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **scoped network authority** granted by a network portal (D-NETLEASE).
This schema is **not** the authority itself; it describes the bounds of a capability (e.g., a `NetDialer`/`NetListener` handle).

References: REF-LITTLESNITCH, REF-MACOS-NETWORKEXT, REF-XDG-PORTAL-NETWORKMONITOR.

Posture: `network-lease-posture-v0.md` (Phase 1 meaning; no ambient sockets/DNS).

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-NETLEASE v0 := {
  v: 0,

  kind: tstr,                ; closed enum: "connect" | "listen" | "dns"

  scope: tstr,               ; closed enum: "internet" | "local" | "loopback" | "explicit"

  proto: tstr,               ; closed enum: "tcp" | "udp" | "tls" | "quic"

  ; destination predicate (required for connect/listen; optional for dns)
  dest?: {
    kind: tstr,              ; closed enum: "dns_name" | "dns_suffix" | "ip_prefix" | "service"

    dns_name?: tstr,         ; e.g., "api.example.com" (bounded)
    dns_suffix?: tstr,       ; e.g., ".example.com" (bounded)

    ip_prefix?: {
      family: tstr,          ; "v4" | "v6"
      addr: bstr,            ; 4 or 16 bytes
      prefix_len: uint,      ; 0..32 or 0..128
    },

    service?: tstr,          ; policy-resolved stable label (e.g., "updates"), bounded

    port?: uint,             ; 1..65535
    port_range?: { lo: uint, hi: uint },
  },

  ; resolver binding (required for any name-resolving lease; v0 only admits portal)
  resolver?: {
    kind: tstr,              ; closed enum: "portal"
    label?: tstr,            ; bounded, non-authoritative (e.g., "default", "corp")
  },

  ; lifetime
  issued_at_s: uint,         ; monotonic time or policy-defined epoch seconds
  ttl_s: uint,               ; lease duration (portal may clamp)

  ; optional budget limits
  budget?: {
    max_conns?: uint,
    max_bytes?: uint,
    max_seconds?: uint,
  },

  ; stable identifiers for attribution (no secrets)
  origin: {
    comp_id: tstr,           ; canonical component name/id (e.g., CH-COMP name), bounded
    instance?: tstr,         ; optional instance label (bounded)
  },

  purpose?: tstr,            ; bounded, non-authoritative note; for UI/audit only

  redaction?: {
    mode: tstr,              ; closed enum: "none" | "dest_hash" | "drop_dest"
    dest_hash?: bstr,        ; if mode==dest_hash: digest of canonical dest predicate
  }
}

Notes:
- `redaction` exists because destinations can be sensitive in some settings; export tools may choose to hash or drop the destination predicate.
- `service` is a *policy label*; the lease descriptor does not embed a mutable endpoint list.
- `resolver` binds the name-resolution strategy for the lease. v0 only admits `resolver.kind="portal"` (no ambient resolvers).

## Validation rules (minimum)
A CH-NETLEASE validator MUST be total and fail closed:
1) `v == 0`.
2) `kind`, `scope`, `proto` are allowlisted closed enums.
3) `issued_at_s` and `ttl_s` are present and bounded; `ttl_s` is clamped by profile.
4) `dest` is required iff `kind` is "connect" or "listen".
5) If `dest` is present, `dest.kind` selects exactly one predicate form (dns_name | dns_suffix | ip_prefix | service), and ports/ranges/prefixes are valid and bounded.
6) `resolver` is required iff the lease can resolve names:
   - `kind == "dns"`, OR
   - `dest.kind in {"dns_name","dns_suffix","service"}`.
7) If `resolver` is present, `resolver.kind` MUST be "portal" (v0 posture) and `label` is bounded.
8) `origin.comp_id` is present and bounded; unknown fields reject (or are rejected by canonical CBOR decode).
9) If `redaction.mode != "none"`, either `dest` is absent (drop_dest) or `dest_hash` present (dest_hash).

## Privacy notes
CH-NETLEASE may reveal user/application intent via destinations. Export via IF-OBS should apply redaction by default (C-OBS-1) and prefer `dest_hash` unless explicit authorization exists.
