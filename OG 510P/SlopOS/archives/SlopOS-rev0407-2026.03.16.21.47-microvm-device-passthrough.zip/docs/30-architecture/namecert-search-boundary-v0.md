# D-NAMECERT search boundary v0 (closed-world; bounded local evaluation only)

Purpose: narrow the **search/evaluation model** of **D-NAMECERT** so an explicit bundle set does not
quietly turn Phase 1 into a distributed credential-discovery protocol, an unbounded graph search,
or a suspend/resume resolver engine.

This boundary deliberately stays on already-reviewed seams: **D-REPL** may move signed CH-NAMECERT
bundle artifacts around, but it remains evidence-only; **D-NS** still carries any authority-bearing
materialization; and **D-COMMUTE** still defines ordering only where a concrete `view.slot` mutation is
attempted.

The archive already says that CH-NAMECERT is explicit user-space evidence, that authority-bearing
projection is explicit per-`view.slot`, that time/freshness is admission-only, that later revocation
evidence is evaluator-local, and that multi-candidate results remain set-valued. This doc closes the
next ambiguity: **how far may the evaluator search, and what happens when the search space is cyclic,
incomplete, or too expensive?**

Phase 1 makes a small, hard choice: **evaluation is closed-world over one explicit bundle set and must
remain bounded**. The evaluator MAY do local goal-directed search inside that presented set, but it does
**not** suspend into distributed discovery, ambient fetch, or iterative credential chasing beyond the
already-authorized artifact bundle it was given.

## Boundary (v0)

1) **Evaluation is closed-world over one explicit bundle set**
   - A Phase 1 query is evaluated only against the explicit **CH-NAMECERT bundle set** already presented by policy, configuration, or another already-authorized artifact flow.
   - The evaluator does **not** consult ambient network services, filesystem walks, remote issuer endpoints, replication peers, or hidden local caches to “complete” a partial chain.
   - Replicated bundle arrivals may change what bundle set a later admission attempt chooses to present, but they do not turn one in-flight query into a distributed discovery session.

2) **Goal-directed local search is allowed; distributed chain discovery is not**
   - Inside that explicit bundle set, an implementation MAY use a local goal-directed search strategy, tuple-reduction engine, or other equivalent bounded evaluator.
   - Phase 1 standardizes **no suspend/resume credential retrieval protocol**, **no suspend/resume distributed credential discovery**, **no issuer-directed lookup hints**, and **no traversable-storage type system** on D-NAMECERT itself.
   - This keeps SlopOS on the SDSI/SPKI side of the line: local names remain local evidence, while richer RT-style distributed credential discovery / chain discovery stays a useful contrast rather than an imported seam.

3) **Cycles and revisits must be handled deterministically**
   - Evaluators MUST treat the effective search state as a bounded graph problem with explicit visited-state suppression or an equivalent deterministic cycle-handling rule.
   - Cyclic name/delegation structures, duplicate certificates, or self-reference must not create an infinite loop, a “keep trying later” background task, or authority amplification.
   - Reaching a previously visited effective state is observational only; it does not produce a new candidate, a stronger proof, or a reason to widen authority.

4) **Resource bounds are explicit and fail closed**
   - Implementations MAY enforce explicit bounds such as candidate count, reduction steps, recursion depth, edge traversals, or evaluator fuel.
   - Exhausting those bounds MUST fail closed for the current admission decision: the evaluator returns denial / inconclusive under local policy rather than falling back to ambient lookup, partial success, or hidden background work.
   - Phase 1 therefore declines any promise of complete distributed discovery; it promises only a bounded, deterministic local decision over the provided bundle set.

5) **Search order is non-authoritative**
   - Internal search order (breadth-first, depth-first, index-guided, memoized, tuple-reduction order, etc.) is an implementation detail so long as the evaluator preserves the archive's declared semantics.
   - Search order does **not** justify hidden winner selection when multiple admissible candidates exist; Phase 1 remains set-valued exactly as pinned by `namecert-selection-boundary-v0.md`.
   - Search order also does **not** create a new conflict-key family, transcript stream, or replication meaning on D-NAMECERT.

6) **Authority-bearing effects still land only on the target seam**
   - A successful local search does not itself mutate namespace state, mint proxies, or update receipts.
   - Any authority-bearing result still lands only through explicit D-NS `view.attach` / `view.detach` on concrete `view.slot` keys with retained `digest(CH-NAMECERT v0)` provenance, exactly as pinned by `namecert-projection-boundary-v0.md`.
   - The search boundary therefore reduces evaluator complexity without adding a second activation or control plane.

7) **The closed-world/bounded stance keeps all four product shapes honest**
   - **Secure workstation (A):** prevents “helpful” background name chasing or resolver retries from silently rebinding user-visible names.
   - **Cloud micro-VM substrate (B):** avoids turning local naming into a distributed credential-discovery service coupled to replication or cluster reachability.
   - **Embedded / separation-kernel-ish appliance (C):** keeps evaluation small, offline-capable, and auditable without hidden fetch agents or daemon state.
   - **Agent/automation OS (D):** gives LLM- and workflow-driven tooling a deterministic, bounded local query surface instead of an open-ended discovery engine.

## Phase 1 non-goals (explicitly deferred)

- Distributed credential-chain discovery, suspend/resume search, or issuer-directed retrieval protocols.
- A portable storage/discovery type system for where credentials must be published.
- Hidden background retry, cache warmers, or daemonized graph expansion for incomplete chains.
- Claims of global completeness once the explicit bundle set is exhausted.
- Any new ACP kind / portal family / conflict-key family for NAMECERT search lifecycle management.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- Time boundary: `namecert-time-boundary-v0.md`
- Revocation boundary: `namecert-revocation-boundary-v0.md`
- Selection boundary: `namecert-selection-boundary-v0.md`
- Replication boundary: `namecert-replication-boundary-v0.md`
- Target namespace seam: `view-namespace-posture-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-CHAIN**)

CI drift gate:
- `tools/check_namecert_search_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **closed-world / no distributed discovery / deterministic cycle handling / fail-closed bounds** stance, or drops its assurance / REF wiring.

## References

- REF-SDSI-RL96.
- REF-SPKI-RFC2693.
- REF-RT0-DISCOVERY.
