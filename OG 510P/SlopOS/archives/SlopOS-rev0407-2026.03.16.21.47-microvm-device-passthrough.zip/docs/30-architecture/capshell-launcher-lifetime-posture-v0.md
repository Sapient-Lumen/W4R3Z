# Capshell launch launcher-lifetime posture v0 (no inherited launcher-death coupling)

Purpose: keep **D-CAPSHELL** honest when reviewed workflow meaning could still depend on
**launcher/session liveness coupling** that never appears in the execution pack: wrapper-imposed
parent-death signals, inherited Job Object membership, kill-on-close scoping, or similar
“die when the launcher/session disappears” behavior. The archive already makes argv/env/cwd/stdio/
fd bindings explicit, but that promise still drifts if a child can quietly die because a short-lived
wrapper thread, shell, or service-side launcher vanished.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic
supervision API, a portable “die with parent” flag, a job-object control surface, or a reviewed
descriptor for arbitrary process-tree ownership policy. It only freezes the minimum Phase 1 posture
needed so launch behavior no longer depends on hidden launcher/session death coupling across all
four product shapes.

## Posture (v0)

1) **No inherited launcher/session death-coupling baseline in Phase 1**
   - `capshell.exec` MUST NOT depend on ambient launcher/session liveness merely because the parent
     shell, wrapper, desktop helper, service-side launcher, or transient runtime shim already had a
     death-coupling policy.
   - Ambient launch state includes wrapper-imposed `PR_SET_PDEATHSIG`, subreaper-mediated
     parent-death delivery, inherited Job Object membership with kill-on-close semantics,
     launcher-owned scope membership, and equivalent “child dies when the launcher/session goes
     away” linkage that never appears in the reviewed execution pack.

2) **Phase 1 adds no reviewed per-step launcher-lifetime coupling surface**
   - Phase 1 introduces no reviewed `capshell.parent_death.*`, `capshell.supervision.*`,
     `capshell.die_with_parent`, `capshell.breakaway_from_job`, `disown`, `nohup`, or equivalent
     ACP/admin family.
   - The portable seam is therefore: **do not carry launcher-/session-death coupling across the
     reviewed boundary as hidden workflow meaning**.
   - If a runtime/provider wants compartment-wide teardown on VM/service/cell shutdown, that remains
     local implementation policy for that compartment and MUST be independent of transient
     shell/wrapper death inside the compartment.

3) **Launch normalizes child lifetime independence at the boundary**
   - Before `exec` (or via equivalent spawn attributes / runtime controls), the runner/wrapper MUST
     ensure the child is **not additionally tied to transient launcher/wrapper death inside the
     active execution compartment**.
   - On Linux-like runtimes, that means reviewed children MUST NOT be launched with wrapper-owned
     `PR_SET_PDEATHSIG` / equivalent parent-death coupling as hidden default behavior.
   - On Job Object / hosted runtimes, the same portable promise applies at the compartment boundary:
     child lifetime may still be bounded by explicit compartment teardown, but MUST NOT acquire
     extra launcher-local kill-on-close/job-membership coupling merely because a short-lived wrapper
     started it.
   - Compat/foreign-cell membranes that cannot guarantee that normalized lifetime posture MUST fail
     closed rather than preserving host defaults.

4) **Durable/background continuation remains explicit**
   - If workflow meaning needs explicit cancellation, continuation, detachment, or owner-mediated
     teardown, that remains on existing **D-REQCTX**, **D-JOBS**, **D-BGLEASE**, and **D-QUIESCE**
     seams rather than on launcher death or shell exit conventions.
   - Programs may still implement their own internal supervision after launch, but Phase 1 reviewed
     automation does not rely on hidden parent/session lifetime linkage at the runner boundary.

5) **Other explicit seams do not secretly mint or repair lifetime coupling**
   - **CH-REQCTX v1** cancellation is not a portable “die when the launching shell exits” promise.
   - **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and terminal/session UX do not
     authorize wrapper-owned parent-death signals, job-object inheritance, shell `disown` lore, or
     service-side launcher lifetime coupling as reviewed workflow meaning.
   - Adjacent conveniences (learn mode, startup hooks, interrupt UX, terminal UX, or compat helper
     wrappers) MUST NOT become hidden carriers for launcher-death policy.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no reviewed process-tree ownership descriptor, no per-step “detach”/
     “survive logout” knob, and no admin query surface for “what launcher death policy applied?”
   - If later evidence shows a real need for reviewed lifetime coupling/detach control, that work
     must return as **one new explicit decision surface** rather than by silently inheriting host
     wrapper/session semantics.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden launcher-/session-
     death linkage.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose host parent-death signals, job-object kill-on-close behavior,
     or wrapper/session lifetime coupling as a hidden side channel around the reviewed execution
     pack.
   - If a foreign runtime cannot clear or bypass launcher-local death coupling while preserving the
     active compartment boundary, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable per-step “die with parent”, “detach”, `nohup`, `disown`, or breakaway-from-job knob.
- No portable process-tree ownership / supervision descriptor in D-CAPSHELL Phase 1.
- No compatibility table translating legacy shell-exit, subreaper, Job Object, or service-manager
  teardown policy into generic capshell semantics.
- No portable query/report surface exposing inherited parent/session death-coupling state.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-interrupt-cancel-posture-v0.md`
  - `capshell-job-control-posture-v0.md`
  - `reqctx-posture-v0.md`
  - `background-lease-posture-v0.md`
  - `job-portal-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-LAUNCHLIFE-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-LAUNCHLIFE-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `docs/30-architecture/capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_launcher_lifetime_posture.py` (**EVID-2026-348**).

## References

- REF-MAN7-PR-SET-PDEATHSIG
- REF-MS-ASSIGNPROCESSTOJOBOBJECT
- REF-MS-JOB-OBJECTS
