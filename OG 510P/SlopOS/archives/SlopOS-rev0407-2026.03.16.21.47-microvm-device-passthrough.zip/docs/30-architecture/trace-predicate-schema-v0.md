# CH-TPRED v0: Trace predicate schema (informal)

Purpose: a **bounded boolean predicate** over a single CH-TRACE event record.
Used for **prefiltering** (drop/keep) without importing an in-kernel scripting engine.

This schema is designed to be:
- total + fail-closed on unknowns (I-ENC-1)
- non-Turing-complete (no loops)
- bounded in size and evaluation cost
- observational (cannot create authority)

Refs: REF-DTRACE-PREDICATES, REF-LINUX-TRACE-FILTER, REF-LTTNG-FILTER.

## Encoding
Canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings.

## Data model (conceptual)

CH-TPRED v0 := {
  v: 0,

  ; optional human label (ignored by enforcement)
  name?: tstr,

  ; which probe/event shape this predicate expects
  probe: tstr,                 ; tracepoint identifier (same namespace as CH-TRACE.probe)

  ; maximum evaluation fuel the author expects; the portal may clamp lower
  fuel?: uint,

  ; expression tree
  expr: TPExpr,

  meta?: { * tstr => any }     ; optional; MUST be ignored unless whitelisted
}

TPExpr :=
  { kind: "and", args: [TPExpr] } |
  { kind: "or",  args: [TPExpr] } |
  { kind: "not", arg:  TPExpr } |

  ; comparisons
  { kind: "cmp", op: TCmpOp, left: TPAtom, right: TPAtom } |

  ; membership test (right is a bounded list literal)
  { kind: "in",  left: TPAtom, set: [TPAtom] } |

  ; existence of an optional field
  { kind: "exists", field: tstr }

TCmpOp := "==" | "!=" | "<" | "<=" | ">" | ">="

TPAtom :=
  ; field reference (to a declared event field)
  { kind: "field", name: tstr } |

  ; literals
  { kind: "u64", value: uint } |
  { kind: "i64", value: int } |
  { kind: "bool", value: bool } |
  { kind: "str", value: tstr } |
  { kind: "bytes", value: bstr }

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0`.
2) `probe` is a known tracepoint ID for the active profile.
3) `expr` node count is bounded (profile-defined cap, e.g. <= 256 nodes).
4) No cycles: `expr` is a tree (validated structurally by decode).
5) Field references:
   - `field.name` MUST be a declared field for `probe` (active CH-TPROBE v0 table (pinned by the profile; see D-TPROBE)).
   - Field types MUST match comparison/membership operators.
6) Literal sizes bounded:
   - `str` length bounded
   - `bytes` length bounded
   - `set` length bounded
7) Evaluation fuel:
   - portal/clamp chooses an enforced fuel budget (may ignore `fuel`)
   - fuel exhaustion MUST fail closed in a deterministic way (drop or keep per profile, but fixed)

## Semantics
- The predicate evaluates against one CH-TRACE record.
- Output is a single boolean: **keep** (true) or **drop** (false).
- Predicates MUST NOT modify any state; implementations MUST NOT allocate per-event.

## Notes
- This schema intentionally does not include actions, projections, aggregation, or stateful variables.
  Rich processing belongs in D-TRACEPROC (user space).
- If the platform later supports a “source-prefilter” mode, the interpreter must be tiny and prove-friendly.
