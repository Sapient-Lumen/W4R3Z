# CH-CAPSTORE v0 (capability store commit schema, informal)

Purpose: represent a **durable commit** for the user-space capability store (CapStore) used by D-PERSIST.  
A commit updates one or more **named roots** to point at durable objects/blobs and durable capabilities (sturdyrefs), with explicit epoch/rollback semantics.

Design constraints (v0)
- Deterministic decode + canonical encoding (I-ENC-1; PO-ENC-DECODE).
- Restore is non-amplifying (I-PERSIST-2; PO-PERSIST-NOAMP).
- Content-addressed artifacts (CH-AREF) and signature verification when used for boot/resume (PO-AREF-VERIFY).
- Rollback is detectable unless the deployment profile opts into “rollback allowed” (I-PERSIST-3; PO-PERSIST-ROLLBACK).
- Unknown fields reject deterministically (fail-closed).

## High-level shape
A CH-CAPSTORE commit is an object with:
- a unique `commit_id` (content digest),
- a `parent` (or `null` for genesis),
- an `epoch` (monotonic per root-set policy),
- a set of `root_updates`,
- a set of referenced `artifacts` (CH-AREF entries),
- and optional `attest_bindings` (when binding to CH-BOOT / D-CC profiles).

## Fields (informal)
- `version`: `"CH-CAPSTORE/v0"`
- `commit_id`: digest string (must equal hash of canonical encoding)
- `parent`: digest string or null
- `timestamp`: optional (if D-NONDET enabled, must be derived from explicit Clock handle; otherwise omit)
- `epoch`:
  - `global`: u64 (monotonic) **or**
  - `per_root`: map `root_name -> u64`
- `root_updates`: list of:
  - `root`: string (e.g., `root/system`, `root/user/alice`)
  - `new_root_ref`: CH-AREF (points at a “root object” that contains durable refs/caps)
  - `policy`: optional policy hint (e.g., `rollback_allowed=false`)
- `artifacts`: list of CH-AREF entries (pages/blobs/objects)
- `caps`: list of durable capability entries:
  - `name`: optional label
  - `sturdyref`: string/URI (see RFC-0014)
  - `revocation_epoch`: u64 or epoch token (see RFC-0019)
- `signatures`: optional list of signature blocks (when used for boot/resume or shared roots)
- `attest_bindings`: optional (bind `H(CH-BOOT.digest || nonce)` in D-CC profiles)

## Example (schematic)
```json
{
  "version": "CH-CAPSTORE/v0",
  "commit_id": "sha256:…",
  "parent": "sha256:…",
  "epoch": { "per_root": { "root/system": 41 } },
  "root_updates": [
    {
      "root": "root/system",
      "new_root_ref": { "kind": "aref", "digest": "sha256:…", "size": 8192 },
      "policy": { "rollback_allowed": false }
    }
  ],
  "artifacts": [
    { "kind": "aref", "digest": "sha256:…", "size": 8192 }
  ],
  "caps": [
    { "name": "net.stack", "sturdyref": "cap://…", "revocation_epoch": 12 }
  ],
  "signatures": [
    { "alg": "ed25519", "key_id": "…", "sig": "…" }
  ]
}
```

## Validation checklist (v0)
- Canonical decode/encode round-trip; reject unknown variants.
- `commit_id == H(canonical(commit))`.
- All CH-AREF entries verify and sizes/bounds are enforced.
- Epoch monotonicity enforced for roots unless `rollback_allowed=true`.
- Restore path cannot create authority beyond what is referenced in the commit (no ambient acquisition).
