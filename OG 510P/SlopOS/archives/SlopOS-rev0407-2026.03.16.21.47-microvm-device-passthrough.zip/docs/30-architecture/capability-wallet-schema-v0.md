# CH-WALLET v0: Capability wallet descriptor (schema)

Purpose: describe (for UX/audit/ops tooling) an **authority bundle** a component is intended to run with:
- which *kinds* of capabilities/handles it has been given,
- which **promise/effect tokens** (CH-PLEDGE) it is allowed to exercise,
- and which **typed descriptors** (CH-*) are associated with high-risk grants (leases, capture sessions, transfers, etc.).

**Important:** CH-WALLET is **non-authoritative**. It does *not* carry bearer secrets, and it cannot be used to obtain capabilities.
Actual capability transfer happens out-of-band (process launch handle passing, CapRPC, portal responses, etc.).
Pinned v0 meaning: see `wallet-posture-v0.md` (summary-only; `wallet_core_digest` is the binding key; no import/merge semantics).

References: REF-SHILL-OSDI14, REF-UDAC-SP12.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-WALLET v0 := {
  v: 0,

  wallet_id: bstr,          ; random id (>=128 bits) for local indexing
  issued_at: uint,          ; profile-defined time base (monotonic or wall-clock)

  ; who this wallet is intended for (non-authoritative identifiers)
  subject: {
    component_id: tstr,     ; CH-COMP identity string or profile-defined id
    instance_id?: bstr,     ; optional runtime instance identifier
  },

  ; declared promises / effect families (pledge tokens)
  pledge: {
    pledge_schema: tstr,    ; typically "CH-PLEDGE v0"
    tokens: [ tstr ],       ; bounded list; closed allowlist per profile
  },

  ; handle inventory (metadata only)
  handles: [
    {
      cap_kind: tstr,       ; closed enum aligned with CH-COMP cap_kind registry
      rights?: [ tstr ],    ; bounded rights subset; unknown rights reject
      label?: tstr,         ; bounded human hint; not authority

      ; optional typed descriptor binding (digest only)
      desc_schema?: tstr,   ; e.g. "CH-NETLEASE v0" | "CH-DOCREF v0" | "CH-IOLEASE v0" | "CH-CAPTURE v0"
      desc_digest?: bstr,   ; digest of canonical bytes of the descriptor
    }
  ],

  ; optional authority-diff hooks (digests only)
  capgraph_digest?: bstr,   ; optional digest(CH-CAPG v0) snapshot used for explain/diff
  capdiff_digest?: bstr,    ; optional digest(CH-CAPDIFF v0) relative to a declared baseline

  meta?: { * tstr => any }  ; optional; MUST be ignored unless whitelisted
}


## Digest normalization (wallet_core_digest)
Rationale: prompts and CI drift gates need a **stable identifier** for "the authority bundle" that does not change when incidental metadata changes.

Tooling SHOULD compute a `wallet_core_digest` over a normalized projection of CH-WALLET:

1) Construct `wallet_core` by copying only these fields:
- `v`
- `subject.component_id`
- `pledge.pledge_schema` and `pledge.tokens`
- `handles[*]` (including `cap_kind`, optional `rights`, optional `label`, optional `desc_schema`/`desc_digest`)

2) Drop volatile/non-core fields:
- `wallet_id`, `issued_at`, `subject.instance_id`, `capgraph_digest`, `capdiff_digest`, and `meta`

3) Deterministically sort lists:
- sort `pledge.tokens` lexicographically
- for each handle, sort `rights` lexicographically
- sort `handles` by the tuple `(cap_kind, label?, desc_schema?, desc_digest?)` with missing fields ordered before present fields

4) Canonical-encode `wallet_core` (I-ENC-1) and hash it with the profile hash function.

The resulting digest is stable across runs unless the effective authority (tokens/handle kinds/rights/descriptor digests) changes.

Notes:
- `digest(CH-WALLET)` (over the full descriptor) may still be useful as a correlation id, but it SHOULD NOT be used for drift gating or as an authority-binding key.
- If a deployment wants to bind explainability evidence, bind `capgraph_digest`/`capdiff_digest` separately in transcripts/receipts; do not mix them into the core authority digest.

## Validation rules (minimum)
Validators MUST be total and fail closed (PO-WALLET-VALIDATE):
1) `v == 0` and required fields present.
2) `subject.component_id` bounded; `instance_id` bounded.
3) `pledge_schema` is allowlisted (typically "CH-PLEDGE v0"); `tokens` are from a closed allowlist; list length bounded.
4) `handles[*].cap_kind` is from a closed allowlist; list length bounded.
5) If `rights` present, each right is allowlisted for the `cap_kind` (closed-world); unknown rights reject.
6) If `desc_schema`/`desc_digest` present:
   - `desc_schema` is in a closed allowlist of CH-* descriptors,
   - `desc_digest` length matches profile hash,
   - **non-authoritative rule:** a wallet MUST NOT contain bearer secrets (e.g., CH-SREF tokens, CH-CAPX export tokens, raw capability IDs).
7) `capgraph_digest`/`capdiff_digest` are digests only; absence is allowed.

## Security notes
- Wallets are intended for prompts, receipts, runbooks, and CI drift gates. Treat them as *sensitive metadata* (they can reveal what a component can do).
- Wallet contents are **descriptive only**: validators/runners must never use CH-WALLET rows to reopen descriptors, look up capabilities, or acquire authority.
- Export/sharing should respect C-OBS-1 redaction policy. Prefer sharing `wallet_core_digest` and typed descriptor digests, not raw inventories.
- Drift gates: if a job/component is “sealed,” widening `pledge.tokens` or adding new `cap_kind` entries should fail CI unless explicitly reviewed.
