# Worker-pool sponsor surface v0 (exact `sponsor` meaning)

Purpose: pin the exact Phase-1 meaning of the required `sponsor` import for the first concrete **D-CONSTR** family so the worker-pool constructor cannot quietly regain ambient payer/session fallback, per-worker sponsor folklore, or a reflected sponsor/admin plane.
`worker-pool-constructor-invocation-v0.md` already says that every worker-pool invocation requires one `sponsor`; this doc closes the remaining folklore gap by fixing what that import authorizes, how broadly it applies, and what it cannot silently turn into.
It does **not** introduce a generic sponsorship schema, a constructor-global budget service, or a new request-context plane.

## Phase-1 choice

1) **`sponsor` is required exactly once and binds the reviewed sponsorship root for construction and routine runtime attribution**
   - Every worker-pool constructor invocation MUST include exactly one `sponsor` import.
   - The portable meaning of that import is the **reviewed sponsorship root** for pool construction and routine runtime attribution of the pool plus its workers.
   - The constructor MUST fail closed if `sponsor` is absent, duplicated, or replaced by ambient caller/session identity.
   - This required sponsor import lives alongside zero or more `worker_seed/<label>` slots and optional `install_target`; it narrows only the sponsorship side of the invocation and does not reinterpret those other imports.

2) **`sponsor` is pool-wide and immutable for one pool instance**
   - One worker-pool instance has one sponsor root for its reviewed lifetime.
   - Phase 1 adds no `sponsor[i]`, no per-worker payer split, no sponsor-override map, and no `RotateSponsor` / `SwapSponsor` / `AdoptCaller` mutator after construction.
   - If future profiles need sponsor rotation or differentiated per-slot charging, that work must pay for a new explicit surface instead of widening this family in place.

3) **`sponsor` is an authority-bearing import, not a parameter field or manifest identity payload**
   - The worker-pool parameter object remains data-only and MUST NOT carry sponsor handles, sponsor locators, or caller-identity fallbacks.
   - `worker-pool-invocation-manifest-v0.md` therefore records only `sponsor_present = true`; sponsor identity itself stays out of the canonical digest-first manifest.
   - `pool.control.Describe()` likewise does not expose sponsor identity, sponsor inventories, or payer metadata beyond the existing bounded summary surface.

4) **`sponsor` may bind charge/attribution lineage, but it is not a mint, rewrite, or workflow plane**
   - The required sponsor import may carry the reviewed authority needed to attribute creation/runtime costs and, where enabled by profile policy, bind explicit budget/time sponsorship that already exists on other seams.
   - It is **not** a budget mint, budget split API, request-context rewrite surface, job-submission endpoint, or generic “run as this principal” switch.
   - Any richer budget/time/request-context evolution must remain on their own explicit surfaces rather than being smuggled through the constructor’s required sponsor slot.

5) **`sponsor` is constructor input only and is never reflected into outputs**
   - The first worker-pool family does not export `sponsor`, rename it into `pool.control`, or expose `GetSponsor`, `DescribeSponsor`, or reflected payer-inventory semantics on `pool.control` or `worker[i]`.
   - Workers may indirectly benefit from the reviewed sponsor root only through the pinned constructor/runtime boundary, not through a constructor-defined sponsor handle in their exported surface.
   - This keeps the first family from regrowing an authority-discovery or accounting-admin plane beside the typed worker interface.

6) **Sealing and confinement obligations apply to sponsor material too**
   - Setup-only sponsor helpers, payer-routing handles, or runtime-only sponsorship state that are needed only during construction MUST be dropped before routine service, following **D-SEAL**.
   - The harness must treat leaked sponsor handles or sponsor-helper routes the same way it treats any other undeclared authority gain: as a confinement failure under **PO-CONSTR-CONFINE**.
   - Sealed compat remains honest: any foreign implementation that cannot keep sponsor authority explicit and policy-killable must fail closed rather than invent ambient sponsor lookup.

7) **Commutativity stays invocation-scoped because sponsorship is explicit and fixed up front**
   - Return-only fresh pool construction still commutes when invocations consume only their explicit imports, including exactly one `sponsor`, and allocate fresh isolated results.
   - The family adds no sponsor-global sequencer, payer-side ordering token, or implicit coupling between otherwise independent pool constructions that merely use equivalent sponsor roots.
   - Install cases remain non-commuting only where the existing `install_target` seam already serializes them.

8) **Evidence binds sponsor presence and reviewed sponsorship digests without turning runtime surfaces into sponsor inventories**
   - The first worker-pool harness/evidence pack MUST bind the presence of exactly one `sponsor` import and any reviewed sponsor/request-context/budget/time digests that materially shape the invocation.
   - Replay and confinement comparison key off those digest-bound evidence slices, not off runtime sponsor browsing APIs or manifest-embedded sponsor identity.
   - The family therefore adds no separate sponsor receipt schema or constructor-global sponsorship inventory.

## Out of scope in v0

- Ambient inference of sponsorship from caller identity, session ancestry, or host login state.
- Per-worker sponsor overrides, split payer maps, or sponsor rotation after construction.
- Using `sponsor` as a budget mint/split, request-context rewrite, or job-submission surface.
- Reflected sponsor inventories or portable payer-identity summaries on `pool.control` or `worker[i]`.
- Host-specific locator strings or ambient principal names as authoritative sponsor identity.

## Wiring

- Decision surface: **D-CONSTR**.
- Reused seams: **D-SEAL**, **D-BUDGET**, **D-CAPAUD**, **D-COMMUTE**.
- Primary family docs: `worker-pool-constructor-family-v0.md`, `worker-pool-constructor-invocation-v0.md`, `worker-pool-invocation-manifest-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-worker-surface-v0.md`.
- Verification/evidence docs: `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-SEL4-SCHEDCTX-EUROSYS18**, **REF-SEL4-MCS-TUTORIAL**, **REF-GENODE-INIT**, **REF-EROS-CONFINEMENT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_sponsor_surface.py` (**EVID-2026-367**).
