# CH-TPROBE v0 (tracepoint descriptor manifest schema)

Purpose: a pinned, machine-readable description of the **probe IDs** used by CH-TRACE streams, including **field names/types** and **redaction classes**.

Why: CH-TRACE v0 is intentionally cheap (probe id + ordered args). Tools and CH-TPRED predicates still need a **stable field mapping** to avoid “index-based” mistakes and to enforce redaction on semantic fields (addresses, IDs, etc).

This is conceptually similar to Linux trace event `format` files and other systems that pair an event stream with an event schema table.
Refs: REF-LINUX-TRACE-EVENTS; REF-LINUX-TRACE-EVENT-FORMAT; REF-LTTNG-FILTER.

## Encoding (v0)
- Normative signed/hashed bytes: **canonical CBOR** per D-ENC / ADR-0003.
- Authoring MAY use JSON, but any digest/signature MUST be computed over the canonical CBOR transcoding.

## Shape (v0)
A tracepoint descriptor manifest `m` contains:

- `v`: fixed `0`
- `namespace`: bounded string tag (e.g., `kernel`, `core`, `user`)
- `build`: optional build identifier (bounded tag) used only for debugging
- `probes`: bounded list of probe descriptors

A probe descriptor `p` contains:

- `id`: bounded string identifier (MUST match `CH-TRACE.probe` for emitted records)
- `name`: human-readable stable name (e.g., `sched.wakeup`)
- `doc`: optional short description (bounded)
- `fields`: bounded list of field descriptors (ordered; order defines `CH-TRACE.args` meaning)
- `fmt`: optional developer-only format hint (bounded; MUST NOT be treated as authoritative)
- `meta`: optional map of bounded keys to bounded values (ignored unless allowlisted by profile)

A field descriptor `f` contains:

- `name`: bounded identifier (unique within the probe)
- `ty`: closed enum: `u64` | `i64` | `bool` | `str` | `bytes`
- `redaction`: closed enum: `public` | `sanitized` | `sensitive`
- `sem`: optional semantic tag (bounded string) such as `addr`, `pid`, `tid`, `irq`, `cap_id`
- `doc`: optional short description (bounded)

Notes:
- `redaction` is the *minimum* classification for the field. Export policy (CH-OBSPOL) may further restrict.
- `sem` is a hint for tooling and policy checks (e.g., `sem=addr` fields must not be exported when `allow_raw_addrs=false`).

Recommended `sem` tags (portable tooling conventions):
- `addr`, `pid`, `tid`, `irq`, `cap_id` (existing)
- `corr_id` (request/activity correlation)
- `trace_id`, `span_id`, `parent_span_id` (distributed tracing correlation)

Rationale: correlation is a debugging multiplier, and these tags let trace processors, snapshot bundlers, and export policy enforce consistent handling without changing CH-TRACE v0.

## Validation rules (minimum)
A CH-TPROBE validator MUST be total and fail closed:

1) `v == 0` and required fields are present.
2) `namespace`/`build`/strings are within profile string-length limits.
3) `probes` length ≤ `MAX_TPROBE_PROBES`; each probe has:
   - unique `id` (within the manifest)
   - unique `name` (recommended; if not unique, tooling MUST key on `id`)
4) For each probe:
   - `fields` length ≤ `MAX_TPROBE_FIELDS_PER_PROBE`
   - each field `name` is unique within the probe
   - `ty` and `redaction` are from the closed enums
5) Unknown `meta` keys are ignored unless allowlisted.
6) The manifest is canonicalized for hashing/signing (I-ENC-1).

## Interaction with CH-TRACE / CH-TPRED
- A CH-TRACE record’s `args[i]` corresponds to `fields[i]` for the probe `id`.
- CH-TPRED predicates name fields; the validator uses the active CH-TPROBE table to:
  - reject unknown fields
  - type-check operators (`eq`/`gt` etc)
  - enforce any semantic restrictions (e.g., address fields)
- If a trace stream is exported, the exporter SHOULD include (or reference) the CH-TPROBE digest used to interpret it.

## Proof obligations (hooks)
- PO-TPROBE-VALIDATE: decoding/validation is total/canonical and bounds are enforced.
- PO-TPROBE-MATCH: emitters/exporters enforce descriptor↔event agreement (mismatches fail closed; no silent reinterpretation).
