# CH-EXECPACK v2: capshell execution pack (schema)

Purpose: eliminate “ambient authority by omission” in workflow execution by bundling the **complete** capshell execution context into a single, hashable descriptor.

CH-EXECPACK is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v2)`.
- deterministic validators/runners **execute** only after validating the pack and then validating/binding each referenced descriptor under already-held authority.

CH-EXECPACK is **non-authoritative**:
- it contains only digests (no bearer secrets, no raw capability material),
- it never grants authority,
- it exists to make required workflow context explicit and reviewable across profiles (A–D) without forks.

Additions vs v1:
- Optional `plumbmsg_digest?: digest(CH-PLUMBMSG v0)` so automation can carry an explicit, non-authoritative **workflow intent envelope** (D-PLUMB) for audit/routing.
  - Profiles may require this via `cfg.params.capshell.require_plumbmsg` (veto-only; denies missing/invalid intent envelopes).

References: REF-SHILL-OSDI14, REF-PLASH.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v2)
- total decoding + fail-closed validation
- bounded sizes and closed fields (no scripting language)
- digests only: **no bearer secrets** and **no raw capability identifiers**
- makes “no ambient workflow context” enforceable:
  - profiles MAY further *narrow* workflow context via `cfg.params.capshell.minimal_context` (veto-only): when true, the referenced CH-ENV/CH-CWD/CH-STDIO/CH-FDSET/CH-ARGV must satisfy the minimal-context constraints (PO-CAPSHELL-MINCTX-ENF).
  - profiles MAY require explicit **workflow intent envelopes** via `cfg.params.capshell.require_plumbmsg` (veto-only): when true, the pack MUST include `plumbmsg_digest = digest(CH-PLUMBMSG v0)` and validators MUST validate the referenced CH-PLUMBMSG descriptor (PO-CAPSHELL-PLUMBMSG-REQ).
  - no ambient PATH resolution (exec chosen via CH-ARGV role="exec" only)
  - no caller-/wrapper-controlled `argv[0]` baseline: child program-name semantics derive from the reviewed exec selector rather than literal tokens, alias tricks, or `exec -a`-style launcher state; see `capshell-argv0-posture-v0.md`
  - no ambient env/cwd inheritance or cwd-root escape
  - bound CH-CWD stays a cwd-root seam, not advisory path text: `kind="empty"` must yield a fresh/sealed empty cwd root and compat/path-based resolution must not escape via `..` or host-root fallback; see `capshell-cwd-root-posture-v0.md`
  - no ambient inherited file mode creation mask: Phase 1 fixes the child launch `umask` at `0o077` rather than inheriting host/login-shell/session state; see `capshell-umask-posture-v0.md`
  - no ambient inherited descriptor / handle-table baseline: child descriptor state is exact CH-STDIO + CH-FDSET only, and Phase 1 rejects `FD_CLOEXEC` / inheritable-handle hygiene as reviewed policy; see `capshell-handle-table-posture-v0.md`
  - no inherited shell/session resource-limit baseline: Phase 1 adds no reviewed per-step `rlimit` surface, does not carry parent `ulimit` / `getrlimit()` state across the boundary, and forces `RLIMIT_CORE = 0` before exec; see `capshell-rlimit-posture-v0.md`
  - no inherited shell/session signal-state baseline: Phase 1 adds no reviewed per-step signal-state surface, does not carry blocked-signal masks or ignored shell trap state across the boundary, and normalizes launch to an empty blocked-signal mask plus default dispositions for catchable signals before exec; see `capshell-signalstate-posture-v0.md`
  - no inherited shell/session scheduling baseline: Phase 1 adds no reviewed per-step scheduling surface, does not carry ambient `nice` / scheduler-policy state across the boundary, and normalizes launch to the default non-real-time time-sharing policy with neutral nice value (`0`) before exec; see `capshell-scheduling-posture-v0.md`
  - no inherited CPU-affinity / placement baseline: Phase 1 adds no reviewed per-step affinity surface, does not carry ambient `taskset` / `sched_setaffinity()` / `CPUAffinity=` / process-affinity masks across the boundary, and normalizes launch to the default eligible CPU set for the active execution compartment before exec; see `capshell-affinity-posture-v0.md`
  - no inherited resource-controller envelope baseline: Phase 1 adds no reviewed per-step resource-envelope surface, does not carry inherited cgroup membership, `CPUQuota=` / `MemoryMax=` / `TasksMax=` / Job Object resource limits, or equivalent wrapper/service-manager resource-controller narrowing across the boundary, and normalizes launch to the default resource-controller envelope for the active execution compartment before exec; see `capshell-resource-envelope-posture-v0.md`
  - no inherited execution-domain / personality baseline: Phase 1 adds no reviewed per-step ABI/personality surface, does not carry wrapper-/session-defined `setarch` / `Personality=` / legacy personality state across the boundary, and normalizes launch to the default native execution-domain / personality baseline before exec; see `capshell-personality-posture-v0.md`
  - no inherited confinement label/profile baseline: Phase 1 adds no reviewed per-step confinement-label/profile surface, does not carry wrapper-/service-manager-selected `setexeccon()` / `SELinuxContext=` / `AppArmorProfile=` / `SmackProcessLabel=` / equivalent execution-label state across the boundary, and normalizes launch to the default confinement label/profile baseline for the active execution compartment before exec; see `capshell-mac-profile-posture-v0.md`
  - no inherited peer-inspection baseline: Phase 1 adds no reviewed per-step debugger / peer-inspection surface, does not carry host-default same-user debugger / tracer / procfs visibility across the boundary, and normalizes launch to a non-dumpable / non-peer-inspectable baseline (`dumpable = 0` on Linux) before exec; see `capshell-peer-inspection-posture-v0.md`
  - no inherited launcher/session death-coupling baseline: Phase 1 adds no reviewed per-step die-with-parent / detach surface, does not carry wrapper-imposed `PR_SET_PDEATHSIG`, inherited Job Object kill-on-close coupling, or equivalent launcher-local death linkage across the boundary, and keeps child lifetime not additionally tied to transient launcher/wrapper death inside the active execution compartment before exec; see `capshell-launcher-lifetime-posture-v0.md`
  - no inherited syscall-filter baseline: Phase 1 adds no reviewed per-step syscall-filter surface, does not carry wrapper-installed `seccomp()` / `PR_SET_SECCOMP` filters, service-manager `SystemCallFilter=` policy, or equivalent launcher/session syscall-admission narrowing across the boundary, and normalizes launch to the default syscall-admission baseline for the active execution compartment before exec; see `capshell-syscall-filter-posture-v0.md`
  - no privilege gain across exec: Phase 1 adds no reviewed per-step credential/capability elevation surface; runners must guarantee that launch cannot gain privilege via setuid/setgid bits, file capabilities, ambient capability carry-over, or similar privileged-exec metadata, using `no_new_privs` / equivalent where available; see `capshell-privgain-posture-v0.md`
  - no ambient caller-identity baseline: Phase 1 adds no reviewed per-step UID/GID/group/access-token surface; runners must not preserve login-session caller identity, supplementary-group widening, or borrowed access-token state as reviewed workflow meaning, and must instead use a provider-/membrane-fixed least-privilege executor identity or fail closed; see `capshell-credential-baseline-posture-v0.md`
  - no ambient socket constructors or ambient DNS / resolver baseline: Phase 1 adds no reviewed per-step raw socket / resolver surface, does not treat host-global network-stack reachability or `/etc/resolv.conf` / NSS / `getaddrinfo()` defaults as reviewed launch context, and requires networking to stay on explicit D-NETLEASE / `portal.net` / `CH-NETLEASE` seams or fail closed; see `capshell-network-posture-v0.md`
  - no ambient AF_UNIX / session-bus baseline: Phase 1 adds no reviewed per-step AF_UNIX / session-bus surface, does not treat filesystem-path sockets, abstract-namespace sockets, session/system/user bus defaults, or autolaunch conventions as reviewed launch context, and requires local IPC to stay on explicit CH-STDIO / CH-FDSET / route-bound service seams or fail closed; see `capshell-local-ipc-posture-v0.md`
  - no ambient absolute-path filesystem baseline: Phase 1 adds no reviewed per-step `open(path)` / namespace-lookup surface, does not treat host-global absolute-path reachability or process-global filesystem visibility as reviewed launch context, and requires file authority to stay on explicit CH-CWD / CH-FDSET / D-NS / D-POWERBOX seams or fail closed; see `capshell-filesystem-posture-v0.md`
  - no ambient time / entropy baseline when D-NONDET is enabled: Phase 1 adds no reviewed per-step clock / entropy surface, does not treat ambient `clock_gettime()` / timer-style time reads, host wall-clock / monotonic defaults, or ambient `getrandom()` / machine-RNG behavior as reviewed launch context, and requires portable time/entropy to stay on explicit `portal.clock` / `portal.entropy` seams or fail closed; see `capshell-nondet-posture-v0.md`
  - companion discovery surface: `capshell-launch-boundary-index.md` enumerates the current closed front-end + launch-boundary adjunct set that shapes `capshell.exec`, so future no-ambient launch promises cannot land as orphan prose
  - no startup/resolution env hooks in CH-ENV (`PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, `BASH_FUNC_*`); see `capshell-env-startup-posture-v0.md`
  - no runner-synthesized convenience baseline env (`HOME`, `PWD`, `TMPDIR`, `TERM`, locale/timezone, `XDG_*`, or similar) beyond the reviewed CH-ENV entries; see `capshell-env-baseline-posture-v0.md`
  - no implicit shell/session startup from rc/profile files or per-directory hooks; integrated startup remains explicit-only (see `capshell-startup-profile-posture-v0.md`)
  - no hidden front-end word expansion before CH-ARGV review/binding; literal tokens stay exact and Phase 1 declines globbing, `~` lookup, `$VAR` / `${...}` expansion, `$(...)`, brace expansion, word splitting, pathname expansion, and process substitution on the capshell side (see `capshell-word-expansion-posture-v0.md`)
  - no ambient stdio/TTY inheritance
  - no ambient inherited handle/FD tables
  - no portable signal-send / jobspec / shell-exit lifecycle control plane; interruption stays on explicit request/workflow seams (see `capshell-interrupt-cancel-posture-v0.md`)
  - no ambient request correlation/deadline/cancel context (bound via CH-REQCTX)

## Data model (conceptual)

CH-EXECPACK v2 := {
  v: 2,

  ; Non-authoritative request context correlation hook.
  ; This is veto-only information: it MUST NOT be used to grant privileged effects.
  reqctx_digest: bstr,      ; digest(CH-REQCTX v1)

  ; Optional non-authoritative workflow intent envelope.
  ; This is routing/audit metadata only; it MUST NOT be treated as authorization evidence.
  plumbmsg_digest?: bstr,   ; digest(CH-PLUMBMSG v0)

  ; The complete execution context is required.
  ; Each field is a digest of canonical bytes of the referenced descriptor.
  effcon_digest: bstr,      ; digest(CH-EFFCON v0)
  argv_digest: bstr,        ; digest(CH-ARGV v0)
  env_digest: bstr,         ; digest(CH-ENV v0)
  cwd_digest: bstr,         ; digest(CH-CWD v0)
  stdio_digest: bstr,       ; digest(CH-STDIO v0)
  fdset_digest: bstr,       ; digest(CH-FDSET v0)

  ; Optional non-authoritative hints.
  note?: tstr
}

## Validation rules (minimum)

An exec-pack validator MUST be total and fail closed (PO-EXECPACK-VALIDATE):
1) `v == 2`.
2) All required digests are present and each digest length matches the profile hash.
3) Unknown keys reject (or are rejected by canonical CBOR decode).
4) `note` (if present) is bounded.

If `plumbmsg_digest` is present:
- it must be 32 bytes,
- and if the profile requires intent envelopes (`cfg.params.capshell.require_plumbmsg=true`), the validator MUST resolve and canonically validate the referenced CH-PLUMBMSG v0 descriptor (PO-PLUMBMSG-VALIDATE).

## Semantics notes (binding to execution)

CH-EXECPACK is a **veto-only completeness seal**:
- It never grants authority (I-EXECPACK-1).
- It exists so `capshell.exec` can be specified as “requires `exec_pack_digest`” rather than
  as a drifting set of optional per-field digests.

Binding points:
- `capshell.exec` proposals MUST carry `exec_pack_digest = digest(CH-EXECPACK v2)`.
- Validators MUST reject `capshell.exec` proposals that omit `exec_pack_digest` (PO-CAPSHELL-EXECPACK-REQUIRE).
- Validators MUST also require **request-context coherence** (PO-CAPSHELL-REQCTX-BIND):
  - let `a.meta.reqctx_digest` be the CH-ACP action request context digest,
  - let `p.reqctx_digest` be the CH-EXECPACK v2 request context digest,
  - acceptance requires `a.meta.reqctx_digest == p.reqctx_digest`.
  Mismatches MUST fail closed.

Intent-envelope posture (optional):
- If `cfg.params.capshell.require_plumbmsg=true`, validators MUST require `plumbmsg_digest` be present in CH-EXECPACK v2 and MUST validate the referenced CH-PLUMBMSG v0 descriptor before any effect (PO-CAPSHELL-PLUMBMSG-REQ).
- CH-PLUMBMSG is **non-authoritative**: it is a routing/UX envelope only and MUST NOT be treated as authorization evidence.

Runners MUST validate and bind each referenced descriptor:
- enforce CH-EFFCON veto-only effect families at every privileged-effect boundary (I-EFFCON-2),
- bind CH-ARGV/CH-ENV/CH-CWD/CH-STDIO/CH-FDSET descriptor references only to already-held handles/leases/portal outputs,
- select the executable only via CH-ARGV `desc` token with `role="exec"` (no ambient PATH),
- keep executable identity exact through launch: after binding the explicit `role="exec"` selector, do not reopen a mutable path/document name/package alias or execute “whatever is there now”; launch the exact executable object that was bound or an exact-byte staged equivalent, or fail closed (`capshell-exec-object-posture-v0.md`),
- keep the startup native code closure exact through launch: do not stage only the main executable and then let the loader/interpreter/shared-library set fall back to ambient `/etc/ld.so.cache`, default `/lib*` / `/usr/lib*`, current-directory, package alias, or DLL-search-order search; launch either from an already bound exact closure root or an exact staged closure, or fail closed (`capshell-code-closure-posture-v0.md`),
- keep child `argv[0]` derived from the explicit exec selector: do not let CH-ARGV `lit` tokens, alias tricks, wrapper defaults, `exec -a`, or login-shell prefix conventions rewrite the child program name independently of the reviewed `role="exec"` selector; the remaining non-`exec` tokens preserve order as child `argv[1..]`, and tools whose startup behavior depends only on invocation name are non-portable on the generic Phase 1 seam unless ordinary reviewed argv already expresses the same mode (`capshell-argv0-posture-v0.md`),
- avoid inheriting any ambient process context (env/cwd/stdio/extra handles).
- keep child env exact: no baseline append step and no synthesis of `HOME`, `PWD`, `TERM`, locale/timezone, or `XDG_*` from host/session/cwd/tty/request-context state before or around binding the reviewed pack (`capshell-env-baseline-posture-v0.md`).
- keep cwd binding as a no-escape root boundary: do not inherit host cwd, do not treat CH-CWD as advisory path text, and do not allow `..` / host-root fallback around the reviewed pack; fail closed if the active runtime cannot guarantee that (`capshell-cwd-root-posture-v0.md`).
- keep file-creation defaults non-ambient: do not inherit the host/login-shell/session file mode creation mask; set the child launch `umask` to `0o077` before exec or fail closed if the active runtime cannot guarantee that (`capshell-umask-posture-v0.md`).
- keep the child handle table exact: do not inherit ambient parent extra descriptors/handles, do not rely on `FD_CLOEXEC` / inheritable-handle hygiene as reviewed policy, and construct the child descriptor table from CH-STDIO + CH-FDSET only or fail closed if the active runtime cannot guarantee that (`capshell-handle-table-posture-v0.md`).
- keep launch resource limits non-ambient: do not inherit parent shell/session `ulimit` / `getrlimit()` state; Phase 1 adds no reviewed per-step `rlimit` surface and requires `RLIMIT_CORE = 0` before exec, with any remaining ceilings coming only from runtime/provider policy independent of parent shell/session state (`capshell-rlimit-posture-v0.md`).
- keep launch signal state non-ambient: do not inherit blocked-signal masks or ignored shell trap state from the parent shell/session; Phase 1 adds no reviewed per-step signal-state surface and requires launch normalization to an empty blocked-signal mask plus default dispositions for catchable signals before exec (`capshell-signalstate-posture-v0.md`).
- keep launch scheduling state non-ambient: do not inherit ambient `nice` / scheduler-policy state from the parent shell/session; Phase 1 adds no reviewed per-step scheduling surface and requires launch normalization to the default non-real-time time-sharing policy with neutral nice value (`0`) before exec (`capshell-scheduling-posture-v0.md`).
- keep launch CPU affinity / placement non-ambient: do not inherit ambient `taskset` / `sched_setaffinity()` / `CPUAffinity=` / process-affinity masks from the parent shell/session or wrapper; Phase 1 adds no reviewed per-step affinity surface and requires launch normalization to the default eligible CPU set for the active execution compartment before exec (`capshell-affinity-posture-v0.md`).
- keep launch resource-controller envelope non-ambient: do not inherit cgroup membership, `CPUQuota=` / `MemoryMax=` / `TasksMax=` / Job Object resource limits, or equivalent wrapper/service-manager resource-controller narrowing from the parent shell/session or wrapper; Phase 1 adds no reviewed per-step resource-envelope surface and requires launch normalization to the default resource-controller envelope for the active execution compartment before exec (`capshell-resource-envelope-posture-v0.md`).
- keep launch execution-domain / personality state non-ambient: do not inherit wrapper-/session-defined `setarch` / `Personality=` / legacy personality state; Phase 1 adds no reviewed per-step ABI/personality surface and requires launch normalization to the default native execution-domain / personality baseline before exec (`capshell-personality-posture-v0.md`).
- keep launch confinement label/profile state non-ambient: do not preserve wrapper-/service-manager-selected `setexeccon()` / `/proc/pid/attr/exec` / `SELinuxContext=` / `AppArmorProfile=` / `SmackProcessLabel=` / equivalent execution-label state; Phase 1 adds no reviewed per-step confinement-label/profile surface and requires launch normalization to the default confinement label/profile baseline for the active execution compartment before exec (`capshell-mac-profile-posture-v0.md`).
- keep launch peer inspection non-ambient: do not preserve host-default same-user debugger / tracer / procfs visibility as reviewed workflow meaning; Phase 1 adds no reviewed per-step debugger / peer-inspection surface and requires launch normalization to a non-dumpable / non-peer-inspectable baseline (`dumpable = 0` on Linux) before exec (`capshell-peer-inspection-posture-v0.md`).
- keep launch launcher lifetime non-ambient: do not preserve wrapper-imposed `PR_SET_PDEATHSIG`, inherited Job Object kill-on-close membership, or equivalent launcher/session death coupling as reviewed workflow meaning; Phase 1 adds no reviewed per-step die-with-parent / detach surface and requires child lifetime to remain not additionally tied to transient launcher/wrapper death inside the active execution compartment before exec (`capshell-launcher-lifetime-posture-v0.md`).
- keep launch syscall admission non-ambient: do not preserve wrapper-installed `seccomp()` / `PR_SET_SECCOMP` filters, service-manager `SystemCallFilter=` policy, or equivalent launcher/session sandbox policy as reviewed workflow meaning; Phase 1 adds no reviewed per-step syscall-filter surface and requires launch normalization to the default syscall-admission baseline for the active execution compartment before exec (`capshell-syscall-filter-posture-v0.md`).
- keep launch privilege posture non-ambient: do not permit privilege gain across exec via setuid/setgid bits, file capabilities, ambient capability carry-over, or similar privileged-exec metadata; Phase 1 adds no reviewed per-step credential/capability elevation surface and runners SHOULD set `no_new_privs` / equivalent where available before exec (`capshell-privgain-posture-v0.md`).
- keep launch caller identity non-ambient: do not preserve login-session caller identity, supplementary-group widening, or borrowed access-token state as reviewed workflow meaning; Phase 1 adds no reviewed per-step UID/GID/group/token surface and runners MUST use a provider-/membrane-fixed least-privilege executor identity or fail closed (`capshell-credential-baseline-posture-v0.md`).
- keep launch networking non-ambient: do not preserve raw socket constructors, host-global DNS / resolver configuration, or an implicit “machine network stack” baseline across the reviewed boundary; Phase 1 adds no reviewed per-step raw socket / resolver surface and requires any portable network behavior to stay on explicit D-NETLEASE / `portal.net` / CH-NETLEASE seams or fail closed (`capshell-network-posture-v0.md`).
- keep launch local IPC non-ambient: do not preserve filesystem-path AF_UNIX sockets, abstract-namespace reachability, session/system/user bus defaults, or autolaunch conventions as a reviewed baseline; Phase 1 adds no reviewed per-step AF_UNIX / session-bus surface and requires local IPC to stay on explicit CH-STDIO / CH-FDSET / route-bound service seams or fail closed (`capshell-local-ipc-posture-v0.md`).
- keep launch filesystem namespace non-ambient: do not preserve host-global absolute-path reachability, process-global root/mount-namespace visibility, or a hidden “normal host filesystem” baseline across the reviewed boundary; Phase 1 adds no reviewed per-step `open(path)` / namespace-lookup surface and requires file authority to stay on explicit CH-CWD / CH-FDSET / D-NS / D-POWERBOX seams or fail closed (`capshell-filesystem-posture-v0.md`).
- keep launch time/entropy non-ambient when D-NONDET is enabled: do not preserve ambient `clock_gettime()` / timer-style time reads, host wall-clock / monotonic defaults, ambient `getrandom()` / machine-RNG behavior, or a hidden “normal machine clock/RNG” baseline across the reviewed boundary; Phase 1 adds no reviewed per-step clock / entropy surface and requires portable time/entropy to stay on explicit `portal.clock` / `portal.entropy` seams or fail closed (`capshell-nondet-posture-v0.md`).
- keep shell/session startup explicit-only: no runner-side rc/profile sourcing or directory-hook execution before or around binding the reviewed pack (`capshell-startup-profile-posture-v0.md`).
- keep argv preparation exact-token only: no runner/front-end globbing, `~` lookup, `$VAR` / `${...}` expansion, `$(...)`, brace expansion, word splitting, pathname expansion, or process substitution before binding the reviewed pack (`capshell-word-expansion-posture-v0.md`).
- keep interruption on explicit request/workflow seams: no signal-name/number fields, jobspec targeting, or shell-exit/SIGHUP lifecycle semantics are implied by the reviewed pack; local host-signal handling remains implementation detail (`capshell-interrupt-cancel-posture-v0.md`).

Request-context note:
- `reqctx_digest` is informational only (I-REQCTX-3): it MUST NOT be used to grant privileged effects.
- It MAY be used to deny/narrow behavior (deadline/cancel intent; profile veto hooks) and to correlate receipts/transcripts.

Denial guidance:
- Missing `exec_pack_digest` SHOULD emit CH-DENY with deny_code `execpack-missing` and `reason.ref_schema = "CH-EXECPACK v2"`.
- Mismatched request contexts SHOULD emit CH-DENY with deny_code `reqctx-mismatch`, binding the relevant `reqctx_digest`.
- If `cfg.params.capshell.require_plumbmsg=true` and `plumbmsg_digest` is missing, validators SHOULD emit CH-DENY with deny_code `plumbmsg-missing` and `reason.ref_schema = "CH-PLUMBMSG v0"`.
- Invalid/unavailable packs SHOULD emit CH-DENY with deny_code `invalid-schema`, binding `reason.ref_schema = "CH-EXECPACK v2"`.

Notes:
- Profiles that disable capshell (`cfg.params.lane.capshell=false`) deterministically deny `capshell.exec` (PO-LANE-KILL).
- This schema is deliberately minimal: it binds *what* context is used, not *how* handles are passed.
- v0 pipeline posture: a CH-EXECPACK is **single-stage only**. Phase 1 forbids peer stage-to-stage raw handle/FD passing; cross-stage handoff uses CH-AREF/CH-PLUMBMSG digests or explicit portal outputs rebound into the next stage's own pack (see `capshell-pipeline-posture-v0.md`).
