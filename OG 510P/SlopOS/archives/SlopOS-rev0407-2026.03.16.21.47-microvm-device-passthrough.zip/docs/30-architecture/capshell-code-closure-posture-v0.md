# Capshell native code-closure posture v0 (exact launch closure; no ambient loader search)

Purpose: keep **D-CAPSHELL** honest after executable selection and exact executable-object binding
are already explicit. Even if `capshell.exec` binds one exact executable object, launch meaning still
quietly drifts when the runtime resolves the ELF interpreter, startup loader, shared libraries, or
platform-equivalent native dependencies from ambient host search state such as `/etc/ld.so.cache`,
trusted system library directories, the current directory, DLL search order, parent `SetDllDirectory`
state, or mutable package aliases.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a package manager,
a portable loader-policy DSL, or a new `capshell.exec` schema. It only pins the minimum Phase 1
posture needed so reviewed automation launches with **one exact native code closure** or fails
closed.

## Posture (v0)

1) **Start-time native code closure is exact and bound in Phase 1**
   - After resolving the CH-ARGV `desc` token with `role="exec"` against already-held authority,
     the reviewed launch meaning includes not only the exact executable object but also any native
     loader / interpreter object and startup shared-library set needed to reach the program's entry
     point.
   - That **native code closure** MUST be bound before effect from already-held provider-owned,
     immutable, or digest-bound objects (for example, a sealed image root, exact deployment/store
     objects, or a provider-owned staged closure whose members are all digest-checked).
   - The runner MUST NOT treat late loader discovery as harmless host plumbing.

2) **No ambient loader / system-library search at launch**
   - Runners/wrappers MUST NOT let launch depend on ambient host search state such as
     `/etc/ld.so.cache`, default `/lib*` / `/usr/lib*` fallbacks, current-directory lookup,
     package-manager alias resolution, standard DLL search order, inherited `SetDllDirectory` /
     process DLL-directory state, or similar host-global native dependency search.
   - On ELF-style runtimes, `DT_RPATH` / `DT_RUNPATH` / interpreter metadata are acceptable only if
     every reachable native dependency stays inside the already bound closure root or digest-bound
     object set; any escape back into host-global search is a validation/launch failure.
   - On Win32-style runtimes, app-local or process-local directory configuration is acceptable only
     when it is derived from the already bound exact closure root; relying on the ordinary DLL
     search order or parent-process search-path mutation is not a reviewed portable meaning.

3) **Staging must preserve the whole reviewed code closure, not just the main executable**
   - If the active runtime cannot execute the already bound object/closure directly, the runner MAY
     materialize a provider-owned staged closure and launch from that staged root.
   - Such staging MUST preserve the reviewed native closure as a set: staging only the main
     executable while letting loader/interpreter/shared-library resolution fall back to ambient host
     search is forbidden.
   - Any digest mismatch, missing dependency, or closure escape MUST fail closed.

4) **Dynamic native modules after entry stay on D-DYNCODE, not on this seam**
   - This posture covers only the native code needed to start the reviewed process and reach its
     main entry point.
   - Any later `dlopen()` / `LoadLibrary*()` / plugin / JIT / execmod behavior stays governed by
     `rfcs/0059-sealed-code-spaces-and-dynamic-loading.md` and MUST NOT be smuggled in as
     “startup closure” convenience.

5) **Prefer immutable / digest-bound closure sources; stricter profiles may require sealed roots**
   - Phase 1 prefers static binaries, sealed app roots, or digest-bound store/image closures because
     they make retry, review, and attestation semantics stable across all four product shapes.
   - Workstation and agent profiles may often reach this posture through provider-owned staged app
     roots; cloud micro-VM and embedded profiles should usually get it from sealed image/store
     composition rather than host-global library state.
   - In stricter sealed profiles, this posture combines with **I-EXEC-SOURCE-1** /
     **PO-EXEC-SOURCE** so executable provenance is not only exact but also admitted from approved
     signed digests.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.loader.*`, no reviewed “search these native library paths”
     knob, no package-manager callback that completes executable closure after approval, and no
     generic app-visible closure inventory API.
   - If future product work wants a portable native-loader policy or signed closure manifest on the
     `capshell.exec` seam, it must return as **one explicit new decision surface**.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that reviewed launch meaning includes the exact startup native code
     closure rather than only a main executable object plus ambient loader behavior.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT preserve “works on this host because the system loader found some
     matching libraries” semantics behind the reviewed boundary.
   - If a foreign runtime cannot preserve the exact startup native code closure — directly or by
     exact staged closure materialization — it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable loader-policy DSL or per-runtime exception language.
- No reviewed host-global library search path knob.
- No package-manager / app-store alias resolution after approval.
- No generic closure inventory or dependency-discovery API on the `capshell.exec` seam.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seams:
  - `capshell-exec-object-posture-v0.md`
  - `capshell-script-entry-posture-v0.md`
  - `capshell-env-startup-posture-v0.md`
  - `capshell-exec-pack-schema-v2.md`
- Adjacent code/provenance seams:
  - `rfcs/0059-sealed-code-spaces-and-dynamic-loading.md`
  - `artifact-resolution-posture-v0.md`
  - `verified-blob-descriptor-schema-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-CLOSURE-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-CLOSURE-BIND` in `docs/20-assurance/proof-obligation-registry.md`
  - `I-EXEC-SOURCE-1` / `PO-EXEC-SOURCE` (sealed-profile strengthening)
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_code_closure_posture.py` (**EVID-2026-343**).

## References

- REF-LDSO-MAN7
- REF-MAN7-DLOPEN
- REF-NIX-STORE-OBJECT
- REF-MS-DLL-SEARCHORDER
- REF-MS-SETDEFAULTDLLDIRECTORIES
