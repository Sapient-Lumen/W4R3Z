# CH-RRBUNDLE v0: record/replay bundle manifest (schema)

Purpose: package the minimum artifacts needed to **replay or audit** a chosen D-RR scope as a portable bundle
(e.g., attach to a bug report, store as incident evidence, or hand to an offline verifier).

This is a *manifest* schema: it names, digests, and constrains the referenced payload files.
Payloads are typically CH-LOG and CH-RR streams, and optionally an input action stream (CH-KABI), denial receipts (CH-DENY), and a checkpoint manifest (CH-CKPT).

## Canonical encoding
- Canonical CBOR with sorted keys and deterministic number/string forms (see `encoding-policy.md`).
- Digest/sign as bytes of canonical encoding.

## Security notes
- Bundles are usually **sensitive**: they may contain secrets (entropy events, device reads, user data).
- Export SHOULD go through a portal path with explicit consent and clear “what’s inside” summary (D-EXPLAIN).
- Bundles MAY be encrypted at rest; the manifest always remains digest-bound to the ciphertext blobs.
- Denial receipts (CH-DENY) are designed to be redaction-safe (digests/keys only), but bundles still need CH-OBSPOL discipline.

## Schema (v0)
Top-level object:
- `v`: integer, must be `0`
- `scope`: string enum matching CH-RR (`kabi_only_quiescent`, `kabi_only_interrupts`, `guest_and_devices`, `full_system`)
- `created_at`: RFC3339 timestamp string
- `label`: short human label (optional; non-authoritative)
- `provenance`: object
  - `boot_digest`: hex digest of CH-BOOT (if present)
  - `system_build_digest`: hex digest of the base deployment / image (if present)
  - `policy_profile_digest`: hex digest of the pinned policy profile (if present)
- `payloads`: array of payload entries (closed set by `kind`, below)

Payload entry object:
- `kind`: enum
  - `rr_stream` — the CH-RR event stream (typically chunked)
  - `log_stream` — CH-LOG transcript stream
  - `deny_stream` — CH-DENY records referenced from included CH-LOG entries via `deny_digest` (optional)
  - `kabi_stream` — CH-KABI action stream (optional; replay harness can derive actions from CH-LOG in some profiles)
  - `rr_index` — optional derived index for random access/search over rr/log streams (non-authoritative)
  - `ckpt_manifest` — CH-CKPT manifest (optional)
  - `ckpt_blobs` — checkpoint blob group (optional; may be omitted for transcript-only replay)
- `path`: relative path within the bundle
- `sha256`: hex digest of the file bytes
- `bytes`: u64 size
- `compression`: enum (`none`, `zstd`, `gzip`) (optional)

Optional encryption wrapper:
- `encryption`: object (optional; if present, payload files are ciphertext)
  - `scheme`: enum (`xchacha20poly1305`, `age`, `other`)
  - `recipients`: array of opaque recipient IDs/fingerprints
  - `note`: string (optional; e.g., “age recipients are org incident-response keys”)

Optional redaction metadata:
- `redaction`: object (optional; informational)
  - `profile`: string (e.g., `minimal_kabi_only`, `no_user_content`, `full`)
  - `notes`: string (optional)

Validation rules (v0):
- `payloads` must include at least `rr_stream` and `log_stream` for any replay-enabled scope.
- `deny_stream` is optional and MUST NOT be required for correctness; it exists to make fail-closed denials mechanically auditable.
  - Bundlers SHOULD include `deny_stream` containing all CH-DENY records referenced by `deny_digest` in the included `log_stream`, unless the chosen redaction profile explicitly omits denials.
- `rr_index` is optional and must not be required for correctness; it is a derived acceleration structure (never evidence on its own).
- Any unknown `kind` MUST reject (closed enum).
- `sha256` and `bytes` MUST match the referenced file.
