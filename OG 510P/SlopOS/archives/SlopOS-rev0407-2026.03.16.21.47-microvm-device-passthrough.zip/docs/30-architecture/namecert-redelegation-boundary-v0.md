# D-NAMECERT redelegation boundary v0 (no implied onward delegation)

Purpose: narrow the **delegation propagation** seam of **D-NAMECERT** so Phase 1 local naming does not
quietly grow a multi-hop authorization language without an explicit propagation bit, depth field, or
reviewed chain policy.

This boundary deliberately stays on already-reviewed seams: **D-NS** still carries any authority-bearing
materialization, **D-COMMUTE** still owns conflict keys/ordering where live state changes, and
**D-REPL** remains signed bundle evidence rather than a delegation-topology control plane.

The archive already says that **CH-NAMECERT** is issuer-local user-space evidence, that evaluation is
closed-world and bounded, that multiple admissible candidates remain set-valued, and that trust anchors
stay explicit evaluator-local input. This doc closes the next ambiguity: **may a delegated subject use a
received grant as proof that it may issue further CH-NAMECERT delegations?**

Phase 1 makes a small, hard choice: **admitted delegations do not imply onward delegation**. A delegated
subject may exercise the delegated authority under local policy, but it may **not** use that received
grant as proof that it may issue further CH-NAMECERT delegations unless a future reviewed seam adds an
explicit propagation control.

## Boundary (v0)

1) **Delegation is terminal for propagation in Phase 1**
   - A Phase 1 `Delegation` statement grants authority from the bundle `issuer` to the named `subject` for the declared `role` / `rights` / validity / constraints.
   - That grant is sufficient only for the delegated subject to be treated as an authorized subject under local evaluation.
   - It is **not** sufficient proof that the delegated subject may further propagate that authority to another subject through CH-NAMECERT.

2) **No implicit propagate bit, `may_delegate`, or delegation-depth semantics**
   - `CH-NAMECERT v0` includes **no** propagation boolean, `may_delegate` flag, hop-count, max-depth, attenuation-depth, or equivalent redelegation control.
   - Because the schema carries no such field, evaluators MUST NOT infer one from bundle order, issuer identity, repetition, stronger rights, or the mere existence of multiple bundles.
   - In other words: **no implicit propagate / may_delegate / delegation-depth semantics** exist on D-NAMECERT v0.

3) **Multi-hop delegation chains therefore reject unless each issuer is independently authorized**
   - If bundle A says issuer `K1` delegates role `r` to subject `K2`, and bundle B says issuer `K2` delegates role `r` (or a subset) to `K3`, Phase 1 evaluation MUST NOT accept the `K1 -> K2 -> K3` chain merely because `K2` received the first grant.
   - Such a second bundle may matter only if `K2` is independently trusted/authorized under explicit evaluator-local policy on its own seam (for example, `K2` is itself a configured issuer / trust anchor for that decision).
   - A delegated subject may exercise the delegated authority, but may not use that grant as proof that it can issue further CH-NAMECERT delegations.

4) **Search/selection remain smaller because redelegation is explicit absent, not heuristically present**
   - Closed-world bounded evaluation therefore does not need a hidden propagation-depth policy, “first non-delegable hop wins” heuristic, or issuer-specific redelegation default.
   - Set-valued candidate semantics remain unchanged: if an independently trusted issuer contributes its own admissible delegation, it is just another explicit candidate, not proof that an earlier delegated issuer could propagate.
   - This keeps PO-NAMECERT-CHAIN honest: chain soundness depends only on declared semantics actually present in the schema, not on guessed intent.

5) **Projection and receipts remain exact-source, not inferred-propagation, events**
   - If a live `view.slot` mutation is justified by a delegation result, the target-seam proposal/receipt still records the exact supporting `digest(CH-NAMECERT v0)` evidence for the chosen candidate.
   - A receipt may not say “`K2` could obviously delegate onward” without pointing to an explicit reviewed seam that grants such power.
   - Projection therefore stays source-digest-bound instead of relying on implied propagation semantics.

6) **The no-redelegation stance keeps all four product shapes honest**
   - **Secure workstation (A):** prevents silently inherited admin-like authority from hopping through convenience bundles.
   - **Cloud micro-VM substrate (B):** avoids cluster-local service bundles accidentally turning into transitive issuer meshes.
   - **Embedded / separation-kernel-ish appliance (C):** keeps the evaluator tiny and offline-capable by declining propagation heuristics or chain-depth policy.
   - **Agent/automation OS (D):** gives LLM- and workflow-driven tooling a crisp rule: delegation is terminal unless a future explicit redelegation seam exists.

## Phase 1 non-goals (explicitly deferred)

- Any portable `may_delegate` / propagation-bit / delegation-depth field on `Delegation`.
- Any future redelegation semantics must land as an explicit reviewed schema/RFC seam.
- Automatic “one hop by default” or issuer-class-based redelegation heuristics.
- Imported SPKI threshold/delegation-composition semantics beyond what CH-NAMECERT v0 explicitly carries.
- A chain-scoped attenuation language for redelegation.
- Any hidden policy that treats “delegated once” as “trusted to issue more”.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema seam: `namecert-schema-v0.md`
- Search boundary: `namecert-search-boundary-v0.md`
- Selection boundary: `namecert-selection-boundary-v0.md`
- Trust-root boundary: `namecert-trust-root-boundary-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Threat model: `docs/10-threat-model/abuse-cases.md` (**AC-030**)
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**, **PO-NAMECERT-CHAIN**, **PO-NAMECERT-PROJECT**)

CI drift gate:
- `tools/check_namecert_redelegation_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **no implied onward delegation / no propagate-bit inference / independently-authorized-issuer-only** stance, or drops its assurance / REF wiring.

## References

- REF-SPKI-RFC2693.
- REF-SPKI-RFC2692.
