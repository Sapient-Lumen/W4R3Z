# Capshell command-string posture v0 (argv stays structured; no hidden shell language plane)

Purpose: keep **D-CAPSHELL** honest when automation authors are tempted to hand the runner a single
“shell command” string.

Phase 1 already pins executable selection to one explicit CH-ARGV `role="exec"` selector, keeps
script entry explicit, and rejects startup/resolution env hooks. This adjunct closes the next drift
seam: **the runner itself must not become a shell parser, command-string tokenizer, or hidden
`sh -c`/`system()` adapter**.

This doc is intentionally narrow. It does **not** invent a shell-language subset, a quoting DSL, or
an argument rewriter. It only freezes the Phase 1 answer for `capshell.exec`: the execution shape is
always a **structured CH-ARGV token list**, and any shell command language semantics live only inside
an explicitly chosen interpreter.

## Posture (v0)

1) **`capshell.exec` accepts structured argv only**
   - The runner input remains the bound **CH-ARGV v0** token list.
   - Phase 1 introduces **no** alternate “command string”, “shell source”, or “one text blob to
     parse” execution form for `capshell.exec`.
   - Validators/runners MUST treat any attempt to smuggle a second parsing form through metadata,
     notes, or convenience wrappers as out of scope for the accepted action shape.

2) **No hidden shell parser / no auto-tokenization**
   - The runner MUST NOT split a free-form string into argv tokens.
   - The runner MUST NOT apply shell quoting rules, field splitting, pathname expansion, variable
     expansion, command substitution, arithmetic expansion, or quote removal as part of `capshell.exec`.
   - The runner MUST NOT normalize structured argv into a shell command string and then re-parse it.

3) **No hidden `sh -c` / `system()` / “run this line” indirection**
   - The runner MUST NOT satisfy `capshell.exec` by internally calling `sh -c`, `system()`, or any
     equivalent “command string to shell” adapter.
   - Literal CH-ARGV tokens remain **data only**; they do not authorize shell-language evaluation or
     an implicit command-interpreter hop.
   - Phase 1 therefore has no runner-side support for “best effort” quoting/escaping of a reviewed
     argv vector back into shell source.

4) **Explicit shells remain allowed, but only as explicit interpreters**
   - A workflow MAY explicitly select a shell as the one CH-ARGV `desc` token with `role="exec"`.
   - That explicit shell MAY receive ordinary argv data such as `-c` and a following command string,
     but those bytes are then part of the chosen tool's own semantics under the already-declared
     execution context.
   - D-CAPSHELL v0 adds no special privilege or safety exemption for that case; profiles/policies MAY
     narrow it further, but the runner itself does not synthesize or hide the indirection.
   - Companion quarantined code-input boundary: a bound quarantined object must not be reserialized
     into that command-string position to bypass explicit object-local clear/override
     (`quarantined-code-input-boundary-v0.md`).

5) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered within
     a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that command-string convenience paths reject deterministically instead
     of widening the accepted execution semantics.

6) **Sealed compat remains killable and non-ambient**
   - Foreign-cell or wrapper-based automation may still choose an explicit shell across the membrane,
     but compat shims MUST NOT silently rewrite structured argv into shell source or accept a free
     command string and auto-tokenize it on the SlopOS side.
   - Any legacy “run this line in a shell” affordance must remain an explicit compat policy choice,
     not an ambient fallback hidden inside `capshell.exec`.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.shell.*` ACP kind, no shell-subset schema, no quoting helper
     registry, and no generic command-string validator API.
   - If a future product wants a typed shell-program artifact or constrained command-language profile,
     it must return as a separate RFC/decision surface rather than widening CH-ARGV or
     `capshell.exec` by implication.

## Phase 1 non-goals (explicitly deferred)

- No shell-language subset or portable quoting profile.
- No runner-side conversion from structured argv to shell source.
- No generic `command_string` field on CH-ARGV / CH-EXECPACK / CH-ACP.
- No special approval path for `sh -c` / `bash -lc` / equivalent interpreters.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Existing assurance anchors (no new invariant/proof family):
  - `I-ARGV-3` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-ARGV-BIND` in `docs/20-assurance/proof-obligation-registry.md`
- Composition seams:
  - `docs/30-architecture/argv-schema-v0.md`
  - `docs/30-architecture/capshell-exec-selector-posture-v0.md`
  - `docs/30-architecture/capshell-script-entry-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_command_string_posture.py` (**EVID-2026-322**).

## References

- REF-OPENGROUP-SHELL-CMDLANG
- REF-OPENGROUP-WORDEXP
- REF-SHILL-OSDI14
- REF-CAPSICUM
