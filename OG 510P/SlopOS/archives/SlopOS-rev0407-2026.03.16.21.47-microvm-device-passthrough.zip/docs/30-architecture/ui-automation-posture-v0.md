# D-UIAUT posture v0 (manual-only; observation-first; no silent persistence)

Purpose: pin an **implementable Phase 1** meaning for D-UIAUT so accessibility and automation stay explicit, attributable, and reviewable.
It narrows a notoriously abuse-prone seam into a portalized session workflow rather than a global hook surface.

This doc is intentionally narrow: it does **not** design a full test harness stack, a remote desktop product, or a background automation framework.

## Posture (v0)

1) **No ambient accessibility/automation constructors**
   - If D-UIAUT is enabled, post-init components obtain UI observation/injection authority only via `portal.a11y`.
   - There is no ambient accessibility API, global event tap, host helper shortcut, or compatibility backdoor that yields global observation or input injection after init.
   - The seam remains fail-closed behind `cfg.params.lane.portal.a11y`.

2) **Manual-only v0; no ACP automation kind**
   - `portal.a11y.*` remains **manual-only v0** on the ACP surface.
   - Phase 1 does **not** introduce a `portal.a11y.request` or similar automation kind.
   - Accessibility/automation grants remain explicit interactive portal workflows until we have a separate RFC/evidence pass for automation, retry, and conflict-key semantics.

3) **Observation-first; injection is separate and higher-risk**
   - Observation and injection are distinct rights, and **observe ≠ inject** remains the core v0 rule.
   - Observation-only sessions are the expected default posture for assistive tooling.
   - Injection (`inject_keyboard`, `inject_pointer`, `global_hotkeys`) is a stronger grant that may require tighter TTLs, stronger indicators, fresh CH-VOL binding, or profile-specific policy clamps.

4) **No silent persistence or relaunch semantics**
   - D-UIAUT is not a persistence surface.
   - Phase 1 does **not** claim login autostart, background relaunch, geofence/job-triggered resurrection, or durable automation sessions that survive holder death, logout, or reboot.
   - If a workflow needs continuous presence, that question belongs to D-BGLEASE/D-JOBS and must still come back through manual review rather than widening `portal.a11y`.

5) **Indicators and transcript are part of the contract**
   - Active observation or injection sessions imply a non-spoofable shell/portal indicator; requester-controlled UI is insufficient.
   - Grant/renew/revoke/deny decisions remain transcript-visible and, when consent is required, bind to CH-AUTHZ/CH-RECEIPT and CH-VOL for high-risk injection paths.
   - Export/diagnostic surfaces should treat CH-UIAUT as sensitive metadata and prefer redaction/hash-only views by default.

6) **Externally visible state remains ordered inside the portal**
   - Even without an ACP kind in v0, accessibility/automation session state is **ordered** within the portal because active rights, indicator state, and renewal/revocation live there.
   - Serialization boundary: `svc:portal.a11y`.
   - Any future ACP surface must keep conflict keys and retry semantics explicit rather than inheriting hidden state from compositor callbacks or toolkit internals.

7) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell use of accessibility/automation must flow through explicit adapters and `portal.a11y`; compat runtimes do not gain an ambient host accessibility or global input-injection channel.
   - The seam remains policy-killable and review-bound.

## Phase 1 non-goals (explicitly deferred)

- **No ACP automation kind** for `portal.a11y.*` in Phase 1.
- **No background/autostart persistence** or hidden relaunch semantics for UI automation sessions.
- **No ambient cross-app UI text/title feed** outside explicit session scope and redaction rules.
- **No test-harness loophole** that bypasses indicators/transcripts just because the caller claims dev/test intent.

## Wiring

- Decision surface: `decision-map.md` (D-UIAUT).
- Schema:
  - `ui-automation-lease-schema-v0.md` (CH-UIAUT v0)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.a11y.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.a11y`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-UIAUT-1..3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-UIAUT-VALIDATE, PO-UIAUT-ENF)

CI drift gate:
- `tools/check_uiaut_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 "manual-only / observation-first / no silent persistence" constraints, or drops its primary REF wiring.

## References

- REF-ANDROID-ACCESSIBILITYSERVICE.
- REF-APPLE-ACCESSIBILITY-TRUST.
- REF-WIN-UIACCESS.
- REF-FUCHSIA-FOCUSCHAIN.
