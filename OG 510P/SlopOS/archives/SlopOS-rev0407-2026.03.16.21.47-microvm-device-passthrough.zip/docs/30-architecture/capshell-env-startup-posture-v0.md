# Capshell environment posture v0 (explicit-only; no startup/resolution hooks)

Purpose: keep **D-CAPSHELL** honest when workflows bind **CH-ENV v0**. Phase 1 already forbids
ambient PATH lookup and ambient env inheritance, but that still leaves a common back door:
**environment variables that change shell startup behavior, dynamic-loader search/injection, or
language-runtime import paths can quietly decide what code runs without changing the explicit exec
selector**.

This adjunct is intentionally narrow. It does **not** create a general env policy language, a
per-runtime compatibility database, or a profile-specific “sanitize whatever seems risky” engine.
It only freezes the minimum Phase 1 posture needed so automation stays reviewable across all four
product shapes.

## Posture (v0)

1) **The child environment is complete and explicit**
   - The child process receives only the variables named in the bound **CH-ENV v0** descriptor.
   - The runner MUST NOT inherit a hidden baseline environment from the host shell, service manager,
     login session, wrapper, or compatibility layer.
   - Learn-mode/adoption tooling MAY *observe* a legacy environment and propose an explicit CH-ENV,
     but accepted execution still injects only the declared CH-ENV entries.

2) **No environment-controlled startup or resolution hooks in v0**
   - Validators/runners MUST reject CH-ENV names whose documented meaning is to change executable
     lookup, startup-file execution, dynamic-loader injection/search, shell-function import, or
     language import-path/bootstrap behavior.
   - The minimum Phase 1 reject set is:
     - exact-name reject: `PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`
     - prefix reject: `LD_`, `BASH_FUNC_`
   - If a workflow needs equivalent behavior, it must come through an explicit argv/runtime flag,
     an explicit descriptor binding, or a future RFC-first posture—not through ambient env hooks.

3) **Explicit interpreters remain allowed, but their hidden startup channels do not**
   - A workflow MAY explicitly choose `sh`, `bash`, `python`, or another interpreter as the one
     CH-ARGV `role="exec"` selector.
   - That choice does **not** authorize `ENV`, `BASH_ENV`, exported shell functions, `LD_*`,
     `PYTHONPATH`, or similar startup/resolution hooks in the child environment.
   - Phase 1 therefore keeps “interpreter selection is explicit” and “startup code selection is
     explicit” aligned on the same seam.

4) **Denials are deterministic and transcript-visible**
   - If the bound CH-ENV contains a forbidden exact name or prefix, validation MUST fail closed
     before execution.
   - Recommended denial: CH-DENY `deny_code = env-name-forbidden`, with
     `reason.kind="schema"`, `reason.ref_schema="CH-ENV v0"`, and
     `reason.ref_digest = env_digest`.
   - The runner MUST NOT silently scrub and continue, because silent scrubbing would hide the real
     execution shape from reviews, transcripts, and retry semantics.

5) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.env.*` ACP kind, no runtime-specific environment policy schema,
     and no app-visible query API for “which variables are dangerous?”
   - Any future per-runtime exception table or profile-specific startup-allowlist must come back as
     a separate RFC/decision surface rather than widening CH-ENV by implication.

6) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered within
     a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that execution contexts with hidden startup/resolution hooks reject
     deterministically instead of being normalized by convenience.

7) **Sealed compat remains killable and non-ambient**
   - Wrapper-based adoption or foreign-cell automation MUST carry the same explicit CH-ENV posture
     across the membrane.
   - Compat layers MUST NOT recreate ambient startup semantics by injecting host login env, shell
     startup files, loader-search variables, or imported shell functions behind the membrane.

## Phase 1 non-goals (explicitly deferred)

- No general env “risk scoring” or policy DSL.
- No per-runtime compatibility matrix for every language/toolchain.
- No silent conversion of startup env hooks into equivalent CLI flags.
- No hidden baseline env allowlist supplied by wrappers or login/session managers.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary schema seam: `env-schema-v0.md` (**CH-ENV v0**).
- Existing adjacent seams:
  - `capshell-exec-selector-posture-v0.md`
  - `capshell-script-entry-posture-v0.md`
  - `capshell-exec-pack-schema-v2.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-ENV-3` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-ENV-SCRUB` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_env_startup_posture.py` (**EVID-2026-321**).

## References

- REF-OPENGROUP-EXEC
- REF-OPENGROUP-SHELL-ENV
- REF-LDSO-MAN7
- REF-BASH-FUNCIMPORT
- REF-PYTHON-CMDLINE
