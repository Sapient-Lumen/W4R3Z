# Capshell pipeline posture v0 (explicit stage handoff; no peer handle passing)

Purpose: keep **D-CAPSHELL** honest when shell-like pipelines show up in real workflows.
The tempting shortcut is to let one stage smuggle authority to the next via inherited FDs,
SCM_RIGHTS, runner-private handle tables, or equivalent hidden channels. That would bypass
CH-EXECPACK/CH-EFFCON/CH-WALLET review surfaces and make agent automation drift-prone. See also `wallet-posture-v0.md`: CH-WALLET remains summary-only and does not become a grouped authority handoff object.

This doc pins a smaller v0 stance: pipelines are **sequences of stage-local `capshell.exec` actions**.
Cross-stage handoff is explicit data or explicit re-binding, not peer authority passing.
This posture is the v0 rule: **no direct peer handle/FD passing**.

## Posture (v0)

1) **Pipelines are stage-local `capshell.exec` actions**
   - Each stage MUST carry its own `exec_pack_digest = digest(CH-EXECPACK v2)`.
   - The runner/validator treats each accepted `capshell.exec` as a **single-stage** action.

2) **CH-STDIO and CH-FDSET are child-local binding surfaces only**
   - They describe how one child receives its stdio and extra handles.
   - They MUST NOT be interpreted as permission to re-export a bound handle/capability from one child directly into another sibling/peer stage.

3) **`stdin`/`stdout`/`stderr` are data channels, not authority carriers**
   - Bytes emitted on stdio MAY contain non-authoritative digests/ids.
   - The runner MUST NOT treat stdio transport itself as authority transfer.

4) **No direct peer handle/FD passing in Phase 1**
   - Runners/orchestrators MUST NOT use SCM_RIGHTS, inherited Unix-domain socket payloads, runner-private handle tables, or equivalent hidden channels to move raw handles/capabilities from one stage to the next.
   - POSIX-style peer FD passing is therefore out of scope for capshell v0.

5) **Cross-stage handoff uses explicit existing artifacts**
   Cross-stage handoff MUST use one of these patterns:
   - content-addressed artifacts via `digest(CH-AREF v0)`,
   - non-authoritative workflow intent envelopes via `digest(CH-PLUMBMSG v0)`, or
   - explicit portal/service outputs that are rebound into the next stage's own CH-ARGV/CH-ENV/CH-CWD/CH-STDIO/CH-FDSET under already-held authority.

6) **Authority for stage N+1 must appear in stage N+1's own execution context**
   - A previous stage producing a digest/reference does not by itself grant use rights.
   - Any authoritative object needed by stage N+1 MUST be validated against stage N+1's own CH-EXECPACK + CH-EFFCON + already-held authority.

7) **No new commutativity surface is introduced**
   - This posture does not add a new ACP kind, conflict-key family, or ordering token family.
   - Pipeline orchestration remains a sequence of ordinary `capshell.exec` actions using the existing `domain.id` conflict key and ordering rules.
   - Any materialized outputs use existing receipt/schema surfaces (for example CH-AREF digests or portal receipts).

8) **Any future authoritative grouped-handoff surface requires an RFC first**
   - If we later need grouped capability handoff, prefer an explicit routed bundle object over peer inheritance.
   - Do not smuggle authoritative grouping through byte streams or hidden runner state.

## Phase 1 non-goals (explicitly deferred)

- A constrained capability-passing primitive for shell pipelines.
- POSIX-style peer FD passing / SCM_RIGHTS interop inside capshell.
- Implicit stage graphs derived solely from shell syntax.
- A new authoritative “bundle” schema for grouped cross-stage handoff.

## Wiring

- Decision surface: `decision-map.md` (D-CAPSHELL).
- Schema/control seams: `capshell-exec-pack-schema-v2.md`, `stdio-schema-v0.md`, `fdset-schema-v0.md`, `artifact-reference-schema-v0.md`, `plumb-message-schema-v0.md`.
- ACP/control semantics: `docs/70-llm-control/acp-validator-semantics.md`.
- Assurance anchors: **I-CAPSHELL-PIPE-1**, **PO-CAPSHELL-PIPELINE-EXPLICIT**.
- Policy killability remains the existing `cfg.params.lane.capshell` seam; this doc adds **no new lane knob**.
- CI drift gate: `tools/check_capshell_pipeline_posture.py` (EVID-2026-231).

## References

- REF-SHILL-OSDI14
- REF-CAPSICUM
- REF-PLAN9-PLUMB
- REF-FUCHSIA-DICTCAP
