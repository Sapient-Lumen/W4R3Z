# D-PLUMB posture v0 (explicit invocation; ephemeral routing; no bus/oracle drift)

Purpose: pin an implementable Phase 1 meaning for **D-PLUMB** itself so workflow routing stays a small mediation seam rather than widening into a durable message bus, callback protocol, installed-app oracle, or hidden authority broker.
It narrows the already-present router + portal stack into one compact posture validators and harnesses can reason about: explicit invocation, request-local completion, shell-owned routing metadata, and no new automation/conflict-key surface.

## Posture (v0)

1) **User-space workflow mediation, not a kernel subsystem**
   - D-PLUMB remains a regular user-space component/service, not a kernel-resident IPC/router facility.
   - The kernel supplies only existing primitives (cap endpoints, routing contracts, handles, receipts, view objects).
   - This keeps workflow semantics restartable, policy-killable, and profile-shapeable rather than baking a launcher/message-bus policy into the privileged core.

2) **Explicit invocation only; no ambient launcher/helper seam after init**
   - Cross-app workflow routing happens only through explicit router/portal invocation (`Workflow.Portal` / `Workflow.Plumb`-style calls) using pinned schemas such as **CH-PLUMBMSG v0** and **CH-ROUTE v0**.
   - There is no ambient `xdg-open`/`open`-style helper shortcut, hidden per-desktop launcher socket, or path/env-triggered auto-dispatch seam after init.
   - Any compat adapter remains policy-killable and must not recreate ambient helper execution under a different name.

3) **Request-local completion, not durable inbox/outbox service**
   - Phase 1 treats workflow requests as **ephemeral request/response interactions** with request-local completion objects, receipts, or direct portal session outcomes.
   - D-PLUMB v0 does **not** standardize a generic application-visible `Subscribe(port)` / durable inbox / held-message retrieval surface.
   - Any buffering for in-flight mediation is router-local, bounded, and non-durable; restart/logout may abort the interaction rather than promising mailbox durability.

4) **Ports and route tables are shell/policy-owned, not app-visible inventory**
   - `dst_port` and CH-ROUTE `deliver(port)` remain router vocabulary for shell-owned dispatch, not a portable app API to enumerate handlers, inspect route tables, or probe installed components.
   - Phase 1 exposes no generic `list_ports()`, `list_handlers()`, `can_handle(intent)`, or equivalent route/handler inventory surface to untrusted requesters.
   - Routing policy/rule sets remain canonicalized deployment artifacts, not mutable caller-provided programs.

5) **No callback/return endpoint registry in v0**
   - CH-PLUMBMSG remains a forward intent envelope, not a callback protocol.
   - Phase 1 declines caller-supplied callback URLs, callback ports, return-mailbox names, or generic “handoff control back to me later” registries on the portable seam.
   - Return data/control comes only from the request-local completion path (portal response object, receipt, explicit already-held capability, or explicit subsequent workflow), not from a second hidden rendezvous channel.

6) **CH-PLUMBMSG stays non-authoritative and path-free**
   - CH-PLUMBMSG carries only bounded intent metadata, stable-handle identifiers, and digest references; it MUST NOT carry raw capabilities, bearer secrets, host paths, ambient env keys, or implicit network endpoints.
   - Any authority transfer happens only through explicit portal/session outcomes and remains transcript-visible (I-PLUMB-1 / I-PLUMB-2 / I-PLUMB-3).
   - Wallet digests, receipts, and capdiff digests stay correlation/review material only.

7) **Router actions stay narrow; no durable delivery semantics in v0**
   - Phase 1 keeps routing actions narrow: deliver to an explicit router-known destination, invoke mediation, rewrite bounded metadata, or deny.
   - D-PLUMB v0 does **not** standardize scheduled delivery, durable retries, broadcast/fanout guarantees, held-message pickup, or queue administration as part of the portable router seam.
   - If a destination is absent or policy denies delivery, failure stays explicit rather than being silently converted into durable background work.

8) **Ordering stays request-local; no new portable conflict-key family**
   - Route evaluation and request lifecycle ordering live inside **`svc:workflow.router`**.
   - Operations on the same request/session object do **not** commute and serialize there; independent requests commute with respect to authority because D-PLUMB itself mints none.
   - Phase 1 introduces **no new CH-ACP kind and no new portable conflict-key family** for D-PLUMB itself; any future automated workflow/admin surface must pay its own commutativity/serialization cost explicitly.

9) **Sealed compat remains killable and non-ambient**
   - Foreign Cell “open/share/print/paste” integration must route through D-PLUMB portals/intents or fail closed.
   - Compat runtimes do not gain ambient host app-inventory queries, callback registries, launcher helpers, or durable clipboard/message-bus shortcuts.

## Phase 1 non-goals (explicitly deferred)

- Generic `Subscribe(port)` / durable inbox / held-message pickup as a public portable API.
- Generic app-visible route-table / handler / port inventory or preflight probing.
- x-callback-url / callback-port / return-mailbox style callback registries.
- Durable retries, scheduled re-delivery, or queue-administration semantics on D-PLUMB itself.
- New CH-ACP automation kinds or conflict-key families for the core workflow router seam.

## Wiring

- Decision surface:
  - `decision-map.md` (D-PLUMB)
- Schema / routing surfaces:
  - `plumb-message-schema-v0.md` (CH-PLUMBMSG v0)
  - `route-rules-schema-v0.md` (CH-ROUTE v0)
  - `intent-kind-registry.md`
  - `portal-family-registry.md`
  - `effect-contract-schema-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-PLUMB-1, I-PLUMB-2, I-PLUMB-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-PLUMB-NOAMP, PO-PLUMB-UI, PO-PLUMBMSG-VALIDATE)
  - `docs/10-threat-model/abuse-cases.md` (AC-090)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`
- Engineering posture:
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_plumb_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **explicit invocation / request-local completion / no durable inbox / no callback registry / no handler inventory** constraints, or drops its primary REF wiring.

## References

- REF-PLAN9-PLUMB.
- REF-XDG-PORTAL.
- REF-XDG-PORTAL-REQUEST.
- REF-ANDROID-PACKAGE-VISIBILITY.
- REF-XCALLBACK-URL.
