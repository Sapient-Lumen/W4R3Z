# Worker-pool worker entry surface v0 (exact `worker[i]` contract)

Purpose: pin an implementable Phase 1 meaning for the exported `worker[i]` handles so the first concrete **D-CONSTR** family does not drift into per-worker admin wrappers, hidden identity lore, or fake continuity guarantees.
This doc narrows one remaining part of the already-chosen worker-pool family / invocation / harness stack into a smaller claim: **`worker[i]` is a slot-stable typed entry handle, not a raw worker identity token or a constructor-specific lifecycle/admin interface**.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-CAPRPC**, **D-COMMUTE**, **D-QUIESCE**, **D-CAPAUD**
- assumes the exact export names are already fixed by `worker-pool-constructor-invocation-v0.md`
- assumes the exact meaning of the required `sponsor` import is already fixed by `worker-pool-sponsor-surface-v0.md`
- assumes the exact meaning of repeated `worker_seed/<label>` imports is already fixed by `worker-pool-seed-surface-v0.md`
- assumes the exact slot-state meanings visible through `pool.control.Describe()` are already fixed by `worker-pool-slot-state-v0.md`
- does **not** introduce a generic worker schema, a scheduler API, or a per-worker inventory/debug plane

## Phase-1 choice

1) **`worker[i]` is a slot-stable entry handle, not a raw worker identity or per-worker admin wrapper**
   - The exported name `worker[i]` denotes slot `i` within one pool instance, not a host PID/TID, debug object, or restart epoch token.
   - The portable meaning is a **slot-stable entry handle** for the worker closure bound to that slot.
   - Implementations MAY replace the concrete occupant behind slot `i` after a crash/restart according to the pinned restart policy, but the constructor family does not expose raw occupant identity as the portable contract.

2) **The exported handle keeps the worker closure’s typed business interface and adds no constructor-specific verbs**
   - Each `worker[i]` handle is typed exactly by the pinned worker closure/template contract.
   - The constructor family adds no extra `Restart`, `Kill`, `Describe`, `Inspect`, `GetPid`, `GetEpoch`, `SwapImports`, or `PublishElsewhere` verb family on that handle.
   - Work authority therefore stays on the worker closure’s own reviewed interface, not on a constructor-defined wrapper API.

3) **Slot continuity is allowed; hidden session continuity is not**
   - If slot `i` is repopulated after failure, future calls/new sessions made through `worker[i]` MAY reach the new occupant for that same slot.
   - The family does **not** promise transparent replay of in-flight requests, hidden success synthesis, or stable live-session continuity across occupant replacement.
   - Where the worker closure uses **D-CAPRPC** session semantics, disconnect/fail-stop behavior remains exactly the one pinned in `caprpc-session-posture-v0.md`: callers must establish a fresh session through the same `worker[i]` entry handle rather than depending on transparent resume.

4) **Per-worker lifecycle/admin control stays off the worker entry handle**
   - Per-worker restart/recycle/kill/debug actions are out of scope on `worker[i]`.
   - Pool-level maintenance stays on `pool.control` (`worker-pool-control-surface-v0.md`), and any material change to closure/imports still requires a new constructor invocation.
   - This keeps the first family from regrowing a hidden per-worker supervisor/admin plane beside the typed work interface.

5) **Commutativity stays with the worker interface, not the constructor family**
   - Calls through different `worker[i]` handles commute only when the underlying worker interface says they do and no active pool quiesce blocks new work.
   - The constructor family adds no cross-slot ordering token, no worker-global sequencer, and no hidden serialization keyed only by slot index.
   - `BeginQuiesce(mode)` / `EndQuiesce(qid)` on `pool.control` remain intentionally non-commutative with new work admission via any `worker[i]`; serialization evidence stays on the pool-control seam rather than on a second per-worker ordering surface.

6) **Observation stays on `pool.control` and explicit evidence seams**
   - `worker[i]` is not a portable inspection or inventory handle.
   - Phase 1 declines per-worker state summaries, metrics streams, crash logs, watch APIs, or diagnostic-tree traversal on `worker[i]` itself.
   - Bounded pool/slot state remains visible through `pool.control.Describe()` and explicit evidence/diagnostics seams, not through widened entry-handle semantics.

7) **Sealed compat remains honest**
   - Compat or hosted implementations MAY realize `worker[i]` using proxying, routing, or service-manager mechanisms behind the membrane.
   - The portable contract stays the same: one slot-stable typed entry handle, no per-worker admin verbs, and no fake live-session continuity across replacement.
   - If a compat layer cannot provide that posture without ambient side channels or hidden admin surfaces, it must fail closed or keep the widening non-portable and policy-killable.

## Out of scope in v0

- Any per-worker lifecycle/admin verb family on `worker[i]`.
- Any raw occupant identity / PID / epoch export as part of the portable worker handle contract.
- Any transparent replay/resume guarantee for in-flight work across worker replacement.
- Any caller-chosen aliasing or relabeling of `worker[i]` exports.
- Any inventory/list/watch/search/debug plane on the worker entry handles.

## Wiring

- Decision surface: **D-CONSTR**.
- Adjacent seams: `worker-pool-constructor-family-v0.md`, `worker-pool-constructor-invocation-v0.md`, `worker-pool-sponsor-surface-v0.md`, `worker-pool-seed-surface-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-slot-state-v0.md`, `caprpc-session-posture-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-REALMS**, **REF-FUCHSIA-RUNNER-STOP**, **REF-GENODE-INIT**, **REF-ERLANG-OTP-PRINCIPLES**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_worker_surface.py` (**EVID-2026-363**).
