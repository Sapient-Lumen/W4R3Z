# Hypervisor-first evaluation (serious candidate)

## What it means here
Root component owns: VM exits/traps, second-stage translation, interrupt routing, minimal scheduling, object/capability enforcement.

## Potential wins
- clean hardware-enforced isolation boundary early
- smaller API surface focused on “resource + isolation”
- naturally matches “guest is adversary” threat model

## Costs/risks
- architecture-specific trap semantics complexity
- subtle interrupt/timer paths
- proof burden may shift into hardware model + exit handling

## External reference models (leverage)
- Recent work provides a machine-checked formal specification of the **NOVA microhypervisor ABI**, including concurrency/architectural behaviors. This can serve as a *reference model* when shaping CH-KABI for a hypervisor-first path (even if we do not reuse NOVA code). (REF-NOVA-ABI-FOSDEM25)
- BlueRock has since **open-sourced and is actively maintaining** the NOVA formal ABI spec (`nova_interface`) and associated proofs (`nova_proof`), including a description of their modular “spike-driven” approach and ongoing coverage tracking. Treat this as a concrete artifact base for CH-KABI design-by-comparison and for sizing the proof scope of a hypervisor-first path. (REF-BLUEROCK-NOVA-OPEN2025, REF-BLUEROCK-NOVA-APPROACH2025, REF-BLUEROCK-NOVA-STATUS2025)
- Earlier work also produced a **formal Nova interface specification** (Robin project era), which is useful as a style template for “ABI as spec” even when not reusing NOVA directly. (REF-NOVA-IFACE-2008)
- The upstream NOVA repo also points to an external branch containing a formal spec/proof effort; treat as a breadcrumb for artifact evaluation/reuse. (REF-NOVA-PROOF-BRANCH)

## DMA/IOMMU
Hypervisor-first forces a DMA story early: either require IOMMU for strong isolation claims or explicitly weaken claim scope.

Adjunct: D-PART (static partition profile) is a natural hypervisor-first slice: fewer exits (no emulation), fewer dynamic decisions, and more policy pushed into a pinned artifact (CH-PART).

Adjunct: D-ADDRNET can make second-stage translation setup auditable by treating translation structure as a pinned artifact (CH-ADDRNET) with a generator/checker pipeline.

## Decision criteria
- privileged TCB size + complexity
- proof tractability (state space, modeling effort)
- early demonstrator feasibility


## Exit surface sketch (budgetable)
| Exit class | Examples | Proof risk | Mitigation |
|---|---|---|---|
| Control regs | CR writes, VMCS/VIRT state | large semantic surface | closed action set + strict decode (PO-XS-CLOSESET) |
| Memory | EPT faults, MMIO traps | aliasing + ordering | explicit mapping objects; minimal emulation |
| Interrupt/timers | APIC/IRQ delivery, timers | subtle reentrancy | model as explicit steps; keep policy small |

Budget policy: see `exit-surface-budget.md`. Decode/dispatch contract: `exit-decode-contract.md` (CH-KABI v0). Claim hook: C-HV-1.


### Deprivileging the I/O data path (inspiration)
To keep the hypervisor-first core small, prefer a control-plane role: configure virtualization + IOMMU and **lease** bounded device queues/resources to user-space driver domains or library dataplanes, rather than embedding a rich device model. This aligns with research that treats the OS as a control plane and pushes I/O fast paths to user space under hardware protection.
Refs: REF-ARRAKIS-OSDI14, REF-DUNE-OSDI12.
