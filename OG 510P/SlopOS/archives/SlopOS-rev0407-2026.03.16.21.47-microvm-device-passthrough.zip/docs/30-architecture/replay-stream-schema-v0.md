# CH-RR v0: record/replay nondeterminism stream (schema)

Purpose: represent *only* the nondeterministic inputs that can affect abstract-machine results under a chosen D-RR profile.
Rule: the event set is closed; any other nondeterminism source is treated as a divergence (I-RR-2).

## Canonical encoding
- Canonical CBOR with sorted keys and deterministic number/string forms (see `encoding-policy.md`).
- Digest/sign as bytes of canonical encoding.

## Schema (v0)
Top-level object:
- `v`: integer, must be `0`
- `scope`: string enum (`kabi_only_quiescent`, `kabi_only_interrupts`, `guest_and_devices`, `full_system`) — a *label* for the intended boundary; profile logic may further restrict accepted event kinds.
- `events`: array of events in strictly increasing `seq`

Event object (common fields):
- `seq`: u64 monotone sequence number
- `kind`: enum (closed set below)

Event kinds (v0 closed set):
- `time_tick`: fields `{ticks: u64}` (abstract time quantum counter)
- `entropy`: fields `{bytes: hex}` (bounded)
- `irq`: fields `{irq_class: string, vector: u32}`
- `fault`: fields `{fault_kind: string, code: u32}`

Notes:
- `kabi_only_quiescent` profiles typically allow only `time_tick` and `entropy`, and replay runs with interrupts disabled.
- `kabi_only_interrupts` profiles allow `irq`/`fault` events and require that interrupt/exception delivery that affects privileged transitions is represented explicitly (else divergence).
- Device/MMIO nondeterminism belongs in broader scopes (`guest_and_devices`/`full_system`) and is intentionally deferred.
