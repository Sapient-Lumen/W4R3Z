# Capshell launch mandatory-access / confinement-profile posture v0 (no ambient inherited execution label/profile baseline)

Purpose: keep **D-CAPSHELL** honest once exact exec selection, exact executable-object binding,
exact startup code-closure binding, fixed caller identity, no privilege gain, and normalized
resource/personality/syscall baselines are already explicit. Those cuts are still insufficient if the
child can quietly inherit wrapper-/service-manager-installed **mandatory-access confinement state**
that never appears in the reviewed execution pack.

On Linux, SELinux exposes an **exec context** (`setexeccon()` / `/proc/pid/attr/exec`) that applies
to the next `execve(2)`, and systemd treats `SELinuxContext=`, `AppArmorProfile=`, and
`SmackProcessLabel=` as first-class execution settings. AppArmor also supports delayed
change-on-exec profile transitions. That makes inherited execution label/profile state a real launch
boundary rather than harmless service-manager trivia.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a reviewed
per-step SELinux/AppArmor/SMACK selector, a generic LSM management API, or a portable label/profile
query surface. It only freezes the minimum Phase 1 posture needed so reviewed automation launches
under **one default confinement label/profile baseline for the active execution compartment** rather
than inheriting wrapper/session/service-manager confinement that happened to exist around the
launcher.

## Posture (v0)

1) **No inherited shell/session/service-manager confinement label/profile baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit wrapper-installed `setexeccon()` / `/proc/pid/attr/exec`
     overrides, service-manager `SELinuxContext=` / `AppArmorProfile=` / `SmackProcessLabel=`
     policy, delayed AppArmor change-on-exec profile state, or equivalent launcher/session
     mandatory-access label/profile narrowing merely because the parent shell, wrapper, login
     profile, service manager, compat membrane, or host session already had it.
   - Ambient launch state includes inherited exec-label/profile overrides, service-manager
     confinement-profile selection, wrapper-local label/profile switching, and equivalent
     parent-selected mandatory-access state that narrows or otherwise changes child authority
     without appearing in the reviewed execution pack.

2) **Phase 1 adds no reviewed per-step mandatory-access / confinement-profile surface**
   - Phase 1 introduces no `capshell.exec.mac`, no label/profile descriptor family, and no
     ACP/admin action family for selecting SELinux contexts, AppArmor profiles, SMACK process
     labels, or equivalent confinement labels/profiles per step.
   - The portable seam is therefore: **do not carry wrapper/session/service-manager confinement
     label/profile state across the reviewed launch boundary**.
   - If a deployment profile needs a fixed compartment-level confinement baseline, that remains
     provider-/membrane-local policy and MUST be independent of parent shell/session state.

3) **Launch normalizes to the default confinement label/profile baseline for the active execution compartment**
   - Before `exec` (or via equivalent spawn attributes), runners/wrappers MUST normalize the child
     to the **default confinement label/profile baseline for the active execution compartment**
     rather than preserving extra wrapper/session/service-manager label/profile narrowing layered on
     top of it.
   - The active execution compartment may already have a provider-defined mandatory-access baseline
     (for example a VM/cell/container/service runtime SELinux type, AppArmor profile, SMACK label,
     or equivalent compartment policy). That baseline may remain in force; the Phase 1 promise is
     only that reviewed launch meaning does not additionally depend on ambient wrapper-/session-
     installed exec-label/profile state.
   - Compat/foreign-cell membranes that cannot guarantee that normalized posture MUST fail closed
     rather than preserving host defaults.

4) **Reviewed launch meaning excludes ambient confinement label/profile switching**
   - Reviewed `capshell.exec` meaning is "this exact exec selector / object / code closure under the
     default confinement label/profile baseline for the active execution compartment", not "whatever
     SELinux/AppArmor/SMACK execution label/profile the launcher already happened to have".
   - Phase 1 therefore declines any portable promise that reviewed automation may rely on ambient
     label/profile transitions, service-manager confinement selection, or wrapper-local exec-label
     lore unless a future explicit seam is introduced.

5) **Programs may still manage their own confinement transitions after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the full semantics of an
     explicitly chosen program after it begins running.
   - Programs may still request or trigger confinement changes after launch according to local
     platform policy, but Phase 1 reviewed workflow meaning never depends on wrapper/session
     label/profile selection that happened before the reviewed `capshell.exec` boundary.

6) **Other explicit seams do not mint or repair confinement label/profile state**
   - **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and
     **CH-REQCTX v1** do not authorize smuggling SELinux contexts, AppArmor profile names,
     `SmackProcessLabel=` values, or generic execution-label/profile hints through unrelated
     fields.
   - Adjacent conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt/job-control UX, or compat adapters) MUST NOT become hidden carriers for ambient
     confinement label/profile policy.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable API for listing, probing, or selecting inherited execution
     labels/profiles, no reviewed report field exposing wrapper-installed SELinux/AppArmor/SMACK
     state, and no admin surface for toggling confinement policy per workflow step.
   - If later evidence shows real need for a reviewed confinement label/profile selector, that work
     must return as **one new explicit decision surface** rather than widening `capshell.exec` by
     implication.

8) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden wrapper/session
     confinement label/profile state.

9) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT recreate host/service-manager exec-label/profile lore behind the
     reviewed seam.
   - If a foreign runtime cannot suppress extra inherited confinement label/profile policy or cannot
     guarantee the default confinement label/profile baseline for the reviewed target runtime, it
     MUST fail closed rather than silently preserving host wrapper/session behavior.

## Phase 1 non-goals (explicitly deferred)

- No portable SELinux/AppArmor/SMACK selector in Phase 1.
- No generic label/profile catalog or per-step confinement policy API.
- No portable query/report surface exposing inherited wrapper/service-manager execution
  labels/profiles.
- No promise that wrapper-local or service-manager mandatory-access policy is available on the
  generic seam.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-personality-posture-v0.md`
  - `capshell-syscall-filter-posture-v0.md`
  - `capshell-privgain-posture-v0.md`
  - `capshell-credential-baseline-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-MAC-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-MAC-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_mac_profile_posture.py` (**EVID-2026-351**).

## References

- REF-MAN7-GETEXECCON
- REF-MAN7-PROC-PID-ATTR
- REF-MAN7-SYSTEMD-EXEC
- REF-UBUNTU-AA-CHANGE-PROFILE
