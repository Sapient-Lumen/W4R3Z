# D-PLUMB / D-QUAR safe-open export destination boundary v0 (fresh destination by default; no overwrite-in-place; explicit replace later)

Purpose: pin the **destination boundary** for output that leaves `intent.kind=open_untrusted` so safe-open export cannot quietly degrade into “save back over the original/trusted file.”
It narrows one remaining ambiguity after **new-artifact + quarantined-by-default** classification was pinned: **where may the kept result land in Phase 1?**
Phase 1 answers: ordinary keep/export from safe-open lands as a **fresh destination artifact by default** on the existing `portal.file.*` / `portal.xfer.*` seams; overwriting/replacing an existing object is **not** part of the same safe-open workflow and must remain a later explicit publish/replace action if policy allows it.

This keeps D-QUAR and CH-DOCREF honest: risky-open export may preserve usefulness, but it must not smuggle identity continuity or trust continuity back in by reusing the source object or silently overwriting an existing trusted destination.

## Posture (v0)

1) **Ordinary safe-open keep/export lands at a fresh destination artifact by default**
   - Output that leaves `open_untrusted` already crosses explicit `portal.file.*` / `portal.xfer.*` / IF-CONSENT seams and becomes a **new artifact**.
   - Phase 1 narrows the destination rule further: the ordinary kept result is created as a **fresh destination artifact** rather than bound to an already-existing object identity.
   - UI may suggest names or folders, but the portable contract is about the outcome: keep/export from safe-open is create-new-first, not overwrite-first.

2) **No overwrite-in-place, no replace-existing, no “save back to source” inside the same workflow**
   - The safe-open flow must not directly overwrite the source object behind the original **CH-DOCREF**.
   - It also must not directly replace some other existing destination object merely because the user picked the same display name, same directory, or a familiar destination.
   - Phase 1 therefore rejects ordinary “save”, “close”, or “export” from safe-open as a hidden copy-back / overwrite-original / replace-trusted-file action.

3) **Later publish/replace is a separate explicit workflow**
   - If the user or policy later wants to publish derived output over an existing destination object, that is a **distinct follow-on action** after the quarantined new artifact already exists.
   - That later action serializes on the normal destination/source mutation seam under existing `portal.file.*` / IF-CONSENT policy, with its own transcript-visible justification.
   - The replace/publish action does not retroactively change what safe-open export meant: safe-open produced a quarantined new artifact first.

4) **Name/path affinity is advisory; identity continuity is not implied**
   - A provider may prefill or suggest a filename derived from the source object.
   - A chooser may also apply collision-avoidance behavior rather than overwriting in place.
   - Same name, same folder, or same apparent project context does **not** imply same object identity, trust carryover, or durable grant continuity.
   - Explicit parent linkage, when present, lives on `origin.parent_digest`; it is not inferred from landing location or name affinity (`open-untrusted-export-lineage-boundary-v0.md`).

5) **Ordering and conflict keys stay on existing seams**
   - The fresh-destination rule itself adds **no new conflict-key family**.
   - Independent safe-open exports commute **with respect to requester authority** except where the existing destination-selection / object-creation seam already serializes on a shared parent/name or equivalent namespace conflict.
   - Any later explicit replace/publish action is the non-commutative step: serialization lives on the existing destination object mutation seam and is evidenced/tested there, not inside `open_untrusted` itself.

6) **Sealed compat remains killable and non-ambient**
   - Compat viewers/importers may participate in safe-open only if their kept-output path preserves the same **fresh-destination-first** rule.
   - Compat must not reinterpret legacy “Save” behavior as permission to overwrite an existing host object directly from the risky-open session.
   - If an interop path cannot preserve this boundary, it fails closed for safe-open export.

## Phase 1 non-goals (explicitly deferred)

- **No automatic copy-back / overwrite-original on save or close**.
- **No safe-open-specific “replace this existing file” shortcut**.
- **No hidden equivalence between same displayed name/path and same object identity**.
- **No trust carryover merely because export landed in a familiar destination**.
- **No portable promise that the kept result inherits the original `docref` identity or durable grant**.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM)
- Related posture / schema surfaces:
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `open-untrusted-export-classification-v0.md`
  - `open-untrusted-export-lineage-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `document-portal-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL, PO-DOCREF-ENF)
- RFC / engineering history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_export_destination_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **fresh-destination-first / no overwrite-in-place / explicit later replace** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-QUBES-QFILECOPY.
- REF-ANDROID-CREATE-DOCUMENT.
- REF-XDG-PORTAL-FILECHOOSER.
