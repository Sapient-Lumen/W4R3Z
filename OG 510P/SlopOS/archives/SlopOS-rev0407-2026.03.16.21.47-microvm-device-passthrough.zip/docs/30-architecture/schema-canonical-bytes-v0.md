# Schema canonical bytes v0 (D-ENC: what `digest(CH-XYZ vN)` hashes)

Purpose: remove ambiguity about the **exact byte string** that is hashed when the archive says:

- `digest(CH-XYZ vN)`

This is a small but high-leverage decision:
- Hybrid + D-COMMUTE evidence relies on stable digests (conflict keys, ordering scopes, receipts).
- “Same value, different encoding” drift is a real source of validator divergence.

Decision surface: **D-ENC** (this doc pins the hashing bytes; signature envelopes remain a separate decision).

Non-goals:
- This does **not** pick a signature/envelope scheme (D-UPD-SIGN / D-SIGENV).
- This does **not** define a network/content distribution system.

## Normative rule (v0)

For any registered CH schema instance `x` of `CH-XYZ vN`:

- `canonical_bytes(CH-XYZ vN, x)` is the **Deterministically Encoded CBOR** representation of `x`.
- `digest(CH-XYZ vN)` means `digest(canonical_bytes(CH-XYZ vN, x))`.

Where:
- Deterministic encoding is as defined in **RFC 8949 §4.2** (REF-CBOR-RFC8949).
- `digest(..)` and `hashlen` are as pinned by **D-HASH** (`profile-hash-suite-v0.md`).

Practical implication:
- Multiple *authoring* encodings MAY exist (e.g., JSON), but only **canonical CBOR bytes** are authoritative for hashing/receipts.

## Decoder/validator requirements (fail closed)

Any privileged decoder/validator that consumes bytes claimed to be `canonical_bytes(CH-XYZ vN, x)` MUST:

- reject **non-deterministic encodings** (indefinite lengths, non-minimal integer/length encodings, non-deterministic map ordering, etc.),
- reject **duplicate map keys**,
- reject **unknown fields** unless the schema explicitly allows an extension map,
- reject **NaN / ±Infinity** float values (v0 posture: avoid float semantics drift),
- and enforce schema bounds (max sizes, max string lengths, etc.).

Rationale: keep the privileged core small and deterministic; avoid “accept-more” behaviors that create covert/interop channels.

## Authoring JSON posture (optional)

Tooling MAY accept JSON for human authoring, but:

- JSON is **not** the canonical bytes.
- Tools MUST canonicalize JSON using JCS (REF-JCS-RFC8785) and deterministically transcode to canonical CBOR **before** hashing/signing.

## Cross-ecosystem evidence (informative)

Hash-stable CBOR profiles are used in adjacent ecosystems where hash drift is expensive:

- IPLD **DAG-CBOR** explicitly requires deterministic CBOR encoding for stable content addressing (REF-IPLD-DAG-CBOR).
- WebAuthn requires CTAP2 canonical CBOR encoding for CBOR messages (REF-WEBAUTHN-3).

## Wiring

- `docs/30-architecture/encoding-policy.md` references this doc.
- `docs/30-architecture/profile-hash-suite-v0.md` references this doc for the meaning of `digest(CH-XYZ vN)`.
- Evidence hook: EVID-2026-211.
- CI drift gate: `tools/check_canonical_bytes_posture.py`.
