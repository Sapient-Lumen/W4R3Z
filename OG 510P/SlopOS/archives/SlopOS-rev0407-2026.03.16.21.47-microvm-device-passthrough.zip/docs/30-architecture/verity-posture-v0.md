# D-VERITY posture v0 (immutable VerifiedBlob handles; deployment-local verity roots)

Purpose: pin an **implementable Phase 1** meaning for **D-VERITY** so verified reads stay a
small, explicit, immutable-content seam instead of drifting into a mutable integrity filesystem,
a generic proof/export API, or a hidden admin/repair plane.

This posture deliberately narrows the surface: the portable consumer-facing unit is an explicit
**VerifiedBlob** handle for immutable content, **CH-VBLOB v0** remains a bounded
**non-authoritative descriptor**, and dm-verity-style volume roots remain a
**boot/deployment-local substrate** rather than a new app-visible mount/inventory authority seam.

## Posture (v0)

1) **Phase 1 centers on explicit immutable VerifiedBlob handles**
   - If **D-VERITY** is enabled, the portable consumer-facing unit is a read-only **VerifiedBlob** handle.
   - Reads either return correct bytes or fail closed with an explicit integrity error.
   - There is no ambient “enable verity on this host path” promise, and no path-based authority is implied by verified-read status.
   - This is the operational meaning of **I-VERITY-2**, evidenced via **PO-VERITY-ENF**.

2) **CH-VBLOB v0 stays descriptor-only and digest-first**
   - **CH-VBLOB v0** records the content identity, Merkle posture, and optional external references for a verified immutable blob.
   - It does **not** carry bytes, mapping authority, mount authority, or approval state.
   - `aref` / `sig_ref` remain references only, and any portable workflow surface should prefer digests over raw proof material.
   - This is the operational meaning of **I-VERITY-1**, evidenced via **PO-VBLOB-VALIDATE**.

3) **File-level blobs are the portable artifact unit; volume verity roots are deployment-local substrate**
   - `kind="file_verity"` is the preferred portable/artifact-facing unit for packages, app bundles, model weights, firmware payloads, and other immutable objects.
   - `kind="volume_verity"` is allowed, but in Phase 1 it means a boot/update/deployment-local immutable root or volume posture rather than a generic app-visible mount/list/manage seam.
   - Consumers should normally receive explicit VerifiedBlob/file objects derived from that substrate, not ambient visibility into a host-global verified volume namespace.

4) **Immutable means immutable: no mutable writeback, online repair, or best-effort downgrade**
   - Phase 1 D-VERITY covers immutable/read-only content only.
   - There is no authenticated writeback, mutable file/object lifecycle, online tree rewrite, or “repair then continue” semantics on the portable seam.
   - Verification mismatch fails closed; the system may quarantine, replace, or redeploy the artifact, but it must not silently fall back to unchecked bytes.

5) **Pager composition is explicit and read-only first**
   - If **D-PAGER** is enabled, VerifiedBlob content may be served by an explicit pager-backed object service that verifies blocks/pages on demand.
   - This composition must preserve the pinned **D-PAGER** posture: object+offset routing, explicit pager endpoints, no per-address-space pager drift, and no hidden writeback lifecycle.
   - Mutable pager-backed writeback semantics remain future work rather than default D-VERITY meaning.

6) **No generic proof-stream, measurement watch, or repair/admin plane in v0**
   - Phase 1 does **not** standardize per-read Merkle proof export, proof-stream APIs, background remeasurement watches, “re-sign/re-root this object,” or a generic verity inventory/list/watch/admin surface.
   - Tooling may inspect descriptor digests and failure receipts, but the core seam remains small: identity + fail-closed reads.

7) **Bounded caches and integrity metadata stay attributable**
   - Hash-tree metadata, verification caches, and any pager/storage-side working sets remain bounded and attributable.
   - If **D-METER** is enabled, those costs must be chargeable to the relevant service/domain so verity does not become a hidden DoS subsidy.
   - This is the operational meaning of **I-VERITY-3**, evidenced via **PO-VERITY-BOUND**.

8) **Sealed compat stays honest**
   - Foreign Cells and compatibility runtimes may consume verified immutable content only through explicit handles, explicit deployment roots, or explicit adapter receipts.
   - They do not gain an ambient host-path “verified file” oracle, a hidden remount/relabel plane, or a bypass around update/boot policy.
   - Policy must be able to kill the interop path without changing what D-VERITY itself means.

## Phase 1 non-goals (explicitly deferred)

- No mutable verified-object / authenticated-writeback profile.
- No generic per-read Merkle proof export API or portable proof-stream surface.
- No ambient “turn this path / mount / existing file into verified storage” control plane.
- No verity inventory / list / watch / repair / re-sign / re-root admin plane on D-VERITY itself.
- No executable-trust policy shortcut where **CH-VBLOB v0** alone authorizes code execution or deployment admission.

## Wiring

- Decision surface:
  - `decision-map.md` → **D-VERITY**.
- Core schemas / mechanisms:
  - `verified-blob-descriptor-schema-v0.md` (**CH-VBLOB v0**).
  - `pager-posture-v0.md` (**D-PAGER**, adjunct).
  - `mechanisms.md`.
  - `schema-registry.md`.
- Adjacent RFCs / surfaces:
  - `rfcs/0114-verified-blobs-and-merkle-integrity.md`.
  - `artifact-resolution-posture-v0.md`.
  - `profile-default-artifact-boundary-v0.md`.
- Assurance hooks:
  - Invariants: **I-VERITY-1**, **I-VERITY-2**, **I-VERITY-3**.
  - Proof obligations: **PO-VBLOB-VALIDATE**, **PO-VERITY-ENF**, **PO-VERITY-BOUND**.
- Discovery / amnesia-resistor surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/resolved-history.md`.
- CI drift gate: `tools/check_verity_posture.py` (**EVID-2026-355**).

## References

- REF-LINUX-FSVERITY
- REF-LINUX-DMVERITY
- REF-ANDROID-AVB2-README
- REF-FUCHSIA-BLOBFS-RAC
- REF-FUCHSIA-PAGER
- REF-FUCHSIA-RFC-0226
