# D-PLUMB / D-QUAR safe-open export classification boundary v0 (export creates a new artifact; quarantined-by-default; sanitize/clear stay separate)

Purpose: pin the **classification boundary** for output that leaves `intent.kind=open_untrusted` so safe-open does not quietly become a trust-laundering path.
It narrows the remaining ambiguity after object-only + snapshot-in decisions: **what status does an exported result get when a user keeps something produced in the disposable?**
Phase 1 answers: exporting from safe-open creates a **new artifact** on the existing `portal.file.*` / `portal.xfer.*` seams, and that artifact is **quarantined by default** unless a separate declared sanitize/clear workflow says otherwise.

This keeps D-QUAR honest: editing/viewing risky content in a disposable may produce useful output, but ordinary export is **not** equivalent to “this is now trusted.”

## Posture (v0)

1) **Safe-open export creates a new artifact; it never launders the source in place**
   - Output that leaves `open_untrusted` crosses explicit `portal.file.*` / `portal.xfer.*` / IF-CONSENT seams.
   - That crossing creates a **new artifact identity** with its own digest/provenance/transcript record; it does not silently mutate the source object behind the original **CH-DOCREF**.
   - The source object remains whatever it already was (typically quarantined) unless a separate explicit clear action is authorized.

2) **Ordinary export from safe-open is quarantined by default**
   - Phase 1 treats ordinary “keep/save/export/share this result” from a safe-open disposable as **derived-from-untrusted** output.
   - The exported artifact therefore lands with quarantine/origin metadata that keeps it on the risky-content lane by default.
   - Companion lineage boundary: ordinary kept output also records one exact `origin.parent_digest`, so “new artifact” does not degrade into “new artifact with no explicit parent evidence” (`open-untrusted-export-lineage-boundary-v0.md`).
   - “Edited in disposable” is evidence of containment, not evidence of trust.

3) **Sanitize and clear are distinct workflows, not side effects of export**
   - If policy offers a sanitizing transform or a deliberate dequarantine path, that remains a **separate explicit workflow** with its own transcript-visible justification.
   - A sanitizing workflow may produce a different new artifact whose quarantine state/policy outcome differs from the default exported result.
   - Ordinary export alone does **not** claim that the bytes are parser-neutralized, policy-approved, or safe for trusted-open.

4) **Destination choice does not change the trust result**
   - Choosing a familiar directory, replacing a same-name file, or exporting back toward the original workflow context does not by itself clear quarantine.
   - Companion destination boundary: ordinary keep/export is **fresh-destination-first**; if a later replace/publish action exists at all, it still serializes on the existing destination/source mutation seam and is evidenced there rather than being folded into the safe-open export itself (`open-untrusted-export-destination-boundary-v0.md`).
   - Phase 1 therefore rejects “copy back to where it came from” as a hidden clear/endorsement signal.

5) **Ordering and conflict keys stay on existing seams**
   - The classification rule itself is deterministic and request-local: `open_untrusted` adds **no new conflict-key family** for “trusted vs quarantined export.”
   - Independent safe-open exports commute **with respect to requester authority** because they mint no extra authority beyond the explicit destination workflow already in use.
   - Non-commutative behavior lives where it already lives: destination object creation/replacement and any explicit clear/sanitize action serialize on their existing `portal.file.*` / `portal.xfer.*` / IF-CONSENT seams and are tested/evidenced there.

6) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat viewers may participate in safe-open only if their kept-output path preserves the same **new-artifact + quarantined-by-default** rule.
   - Compat must not reinterpret “save from sandbox” as “trusted local file now” merely because a legacy app lacks first-class quarantine concepts.
   - If an interop path cannot preserve this boundary, it fails closed for safe-open export.

## Phase 1 non-goals (explicitly deferred)

- **No “edited in disposable == trusted” rule**.
- **No auto-clear based on file extension, MIME guess, parser success, or viewer choice**.
- **No hidden equivalence between export/copy-back and quarantine clear**.
- **No policy-private scanner/notarization verdict that silently reclassifies ordinary exported bytes as trusted**.
- **No new safe-open-specific trust-grade enum, ACP kind, or background promotion workflow**.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM)
- Related posture / schema surfaces:
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `origin-quarantine-attrset.md`
  - `document-portal-posture-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `open-untrusted-export-lineage-boundary-v0.md`
  - `transfer-portal-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-1, I-QUAR-5, I-EPHEM-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL, PO-EPHEM-EXPORT)
- RFC / engineering history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_export_classification.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **new-artifact / quarantined-by-default / sanitize-and-clear-separate** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-QUBES-QFILECOPY.
- REF-MOTW-ZONEID.
- REF-MS-PREVIEW-MOTW.
