# CH-ORDERTOK v0: Ordering token descriptor (schema)

Purpose: describe (for validators, receipts, and audit tooling) an **explicit ordering witness** for actions that are **non-commutative by spec**.

- An ordering token proves that an action belongs to a particular **ordered stream** (scoped to a conflict key).
- Ordering tokens are used to make order dependence **visible and reviewable** without smuggling in implicit global serialization.

**Important:** CH-ORDERTOK is a **descriptor** and is **non-authoritative**.
It MUST NOT carry bearer secrets. Execution authority comes from capabilities/leases/portals; ordering tokens only witness the *order stream identity*.

References: REF-SCR-TOCS15.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-ORDERTOK v0 := {
  v: 0,

  ; correlation id for receipts/debugging (not authority)
  tok_id: bstr,              ; random id (>=128 bits)

  ; what ordered stream this token belongs to
  scope: {
    family: tstr,            ; closed enum; canonical allowlist is pinned in `conflict-key-family-registry.md` (same family vocabulary as CH-CONFLICTKEY)

    ; a stable scope key reference; MUST be a digest, not a raw capability id
    ; v0 norm: key_digest = digest(CH-CONFLICTKEY v0) for the relevant conflict key family
    key_digest: bstr,
  },

  ; where ordering is owned
  owner: {
    cluster_id?: tstr,        ; optional; for Hybrid: the home cluster of the stream
    component_id?: tstr,      ; optional; ordering service identity (non-authoritative)
  },

  ; monotonic position within the ordered stream
  epoch: uint,               ; epoch for revocation/reset; monotonic within a stream
  seqno: uint,               ; monotonic counter within (scope, epoch)

  ; optional bounds (policy-defined time base)
  issued_at?: uint,
  expires_at?: uint,

  meta?: { * tstr => any }    ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed (PO-ORDERTOK-VALIDATE):
1) `v == 0` and required fields present.
2) `tok_id` bounded; `key_digest` length matches profile hash.
3) `scope.family` is a closed allowlist pinned in `conflict-key-family-registry.md` (same family vocabulary as CH-CONFLICTKEY); unknown families reject.
4) `epoch` and `seqno` bounded (implementation-defined max); `seqno` may be zero-based.
5) **Non-authoritative rule:** the descriptor MUST NOT contain bearer secrets or raw capability identifiers.
6) If `expires_at` is present, validators MUST treat expiry as fail-closed for ordered actions.

## Use in action formats and receipts
- CH-ACP and CH-KABI metadata SHOULD carry only a **digest(CH-ORDERTOK)**, not the full descriptor, to keep action envelopes small.
- The ordered stream scope is bound by `scope.key_digest = digest(CH-CONFLICTKEY v0)` (I-ORDERTOK-2).
- Receipts/transcripts MUST make order visible for non-commutative actions by recording:
  - the action digest,
  - the `scope.family` (or a stable family identifier), and
  - the `order_digest` (digest of the CH-ORDERTOK descriptor).

## Security notes
- Ordering tokens do not grant permission; they only make ordering constraints explicit.
- Avoid global streams by default. Prefer stream scopes that match conflict keys:
  - per `ipc.endpoint` (IPC queues),
  - per `view.slot` (name binding),
  - per `budget.issuer` (budget issuance).
- If a profile truly needs a global ordered log (RC4), make that an explicit profile decision and record it as an ordered stream with explicit scope.
