# Worker-pool slot-state model v0 (exact `worker_slots[*].state` meaning)

Purpose: pin an implementable Phase 1 meaning for `worker_slots[*].state` so the first concrete **D-CONSTR** family does not leave `pool.control.Describe()`, per-slot restart budgets, and slot-stable `worker[i]` handles to folklore.
This doc narrows one remaining family-local seam into a smaller claim: **the worker-pool slot state is a closed bounded observation vocabulary, not a hidden worker identity surface, scheduler telemetry stream, or second lifecycle API**.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-QUIESCE**, **D-CAPRPC**, **D-COMMUTE**, **D-CAPAUD**
- assumes the exact exported `pool.control` contract is already fixed by `worker-pool-control-surface-v0.md`
- assumes the exact family-local `Describe()` result shape is already fixed by `worker-pool-describe-summary-v0.md`
- assumes the exact pool-level `quiesce_state` meaning is already fixed by `worker-pool-quiesce-state-v0.md`
- assumes the exact exported `worker[i]` contract is already fixed by `worker-pool-worker-surface-v0.md`
- assumes the exact family-local parameter schema is already fixed by `worker-pool-parameter-schema-v0.md`
- assumes the exact restart-budget semantics are already fixed by `worker-pool-restart-budget-v0.md`
- does **not** introduce a generic worker lifecycle schema, a metrics/inventory stream, or a per-worker admin plane

## Phase-1 choice

1) **`worker_slots[*].state` is a small closed slot-local vocabulary, not a lifecycle telemetry stream**
   - The exact Phase 1 state set is `{starting, running, backoff, failed, quiescing}`.
   - `pool.control.Describe()` reports one member of that closed set for each slot `i`.
   - Phase 1 adds no `idle`, `paused`, `stopped`, `degraded`, `restarting`, `quiescent`, `zombie`, or host-runtime-specific state names on the canonical slot summary.

2) **`starting` means one occupant is being created for the slot, but the slot is not yet ready for new work**
   - `starting` covers the initial bring-up of slot `i` and any later automatic replacement that is actually being launched for that slot.
   - While a slot is `starting`, calls or new sessions through `worker[i]` MUST fail deterministically rather than queue behind the boundary or attach to a half-initialized occupant.
   - If bring-up fails before the slot becomes callable, the next visible state is `backoff` when automatic replacement is still eligible or `failed` when it is not.

3) **`running` means one sealed callable occupant is admitted for that slot**
   - `running` means slot `i` currently has one callable occupant behind the slot-stable `worker[i]` handle and that occupant has reached routine service.
   - `running` does **not** expose host PID/TID, restart epoch, helper identity, or a promise of session continuity beyond the separate `worker[i]` contract.
   - Unexpected occupant loss from `running` transitions to `backoff` when restart budget remains or `failed` when it does not.

4) **`quiescing` is the only slot-local quiesce state in v0**
   - `quiescing` means an active pool `qid` is gating new external work for slot `i` under `BeginQuiesce(mode)`.
   - Phase 1 deliberately uses **no separate per-slot `quiescent` state**: once a slot has drained under an active `qid`, it continues to report `quiescing` until `EndQuiesce(qid)` returns the pool to ordinary admission.
   - When the pool-level `quiesce_state` is `quiescent`, every slot that is neither `backoff` nor `failed` MUST report `quiescing`.
   - Calls or new sessions through `worker[i]` while the slot is `quiescing` MUST reject deterministically with the pool's quiesce outcome rather than silently queueing or slipping through.

5) **`backoff` means no callable occupant is present, but automatic replacement is still eligible**
   - `backoff` means slot `i` currently has no callable occupant and Phase 1 is waiting under the exact per-slot sliding admission budget pinned in `worker-pool-restart-budget-v0.md` before another launch attempt.
   - `backoff` is the only state that represents “temporarily unavailable but not terminal” for a slot.
   - While `backoff`, calls or new sessions through `worker[i]` MUST fail deterministically; there is no hidden request queue or best-effort replay behind the worker handle.
   - If a pool `qid` is active, a slot MAY remain or become `backoff`, but active quiesce suppresses automatic `backoff -> starting` re-entry until `EndQuiesce(qid)` releases the pool back to ordinary admission.

6) **`failed` means the slot is terminal for the lifetime of the current pool instance**
   - `failed` means slot `i` has exhausted its automatic-replacement budget or replacement is otherwise no longer attempted for this pool instance.
   - Once a slot is `failed`, calls or new sessions through `worker[i]` MUST fail deterministically.
   - Returning a failed slot to service requires a fresh constructor invocation that creates a new pool instance; `pool.control` adds no revive/reseed/restart verb for this state.

7) **State transitions are bounded by the existing restart budget and quiesce seam**
   - `worker-pool-parameter-schema-v0.md` already fixes the exact per-slot replacement budget as `restart.max_restarts` plus `restart.window_ms`; the slot-state model consumes that budget but does not widen it.
   - The permitted steady-state paths are intentionally small: `starting -> running`, `starting -> backoff`, `starting -> failed`, `running -> quiescing`, `running -> backoff`, `running -> failed`, `quiescing -> running`, `quiescing -> backoff`, `quiescing -> failed`, and `backoff -> starting` or `backoff -> failed`.
   - Phase 1 adds no per-slot override plane, retry-now verb, or hidden supervisor policy channel beyond those already-declared seams.

8) **Observation stays bounded and separate from worker-handle semantics**
   - `worker_slots[*].state` is observational summary data only; it does not change the typed business interface behind `worker[i]` and does not create new control authority.
   - `pool.control.Describe()` therefore reports only the closed state token per slot, not restart counters, retry timers, stack traces, host identifiers, or import inventories.
   - This keeps the state model comparable across implementations and prevents `Describe()` from quietly regrowing metrics, debug, or scheduler folklore.

## Out of scope in v0

- Any per-slot `quiescent`, `idle`, `paused`, `degraded`, `restarting`, or host-runtime-specific state taxonomy.
- Any per-slot restart counters, retry timers, crash reasons, PID/TID values, or occupant epoch identifiers on the portable summary surface.
- Any `RetryNow`, `Revive`, `RestartWorker`, `ReplaceWorker`, or debug verb family attached to slot state.
- Any hidden queue-behind-boundary or transparent replay semantics when a slot is `starting`, `backoff`, `failed`, or `quiescing`.

## Wiring

- Decision surface: **D-CONSTR**.
- Adjacent seams: `worker-pool-constructor-family-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-describe-summary-v0.md`, `worker-pool-quiesce-state-v0.md`, `worker-pool-worker-surface-v0.md`, `worker-pool-parameter-schema-v0.md`, `worker-pool-restart-budget-v0.md`, `quiesce-posture-v0.md`, `caprpc-session-posture-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-SYSTEMD-SERVICE**, **REF-ERLANG-OTP-PRINCIPLES**, **REF-FUCHSIA-REALMS**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_slot_state.py` (**EVID-2026-373**).
