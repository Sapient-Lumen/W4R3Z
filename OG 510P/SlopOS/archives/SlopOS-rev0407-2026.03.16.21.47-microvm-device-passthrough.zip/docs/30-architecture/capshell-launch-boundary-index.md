# Capshell launch-boundary index (v0)

Purpose: keep the **closed set of D-CAPSHELL front-end + launch-boundary adjuncts** enumerable.

Why this exists:
- the archive now pins many small `capshell.exec` adjuncts that deliberately remove ambient shell/session/host defaults,
- those adjuncts are easy to lose in review because they sit across front-end interpretation, process state,
  namespace reachability, and interactive-control docs,
- CH-EXECPACK v2 stays the reviewed pack, but this index is the **discovery surface** that says which
  no-ambient promises currently shape the meaning of `capshell.exec`.

This doc does **not** add a new schema or action kind.
It is an entropy-reducing companion to `capshell-exec-pack-schema-v2.md`.

## Inclusion rule

A doc belongs here if it changes reviewed `capshell.exec` meaning by constraining **one** of:
- front-end interpretation before CH-ARGV review/binding,
- launch context that would otherwise inherit from the parent shell/session/host (including descriptor / handle tables),
- interactive-control behavior that would otherwise smuggle a second shell/session plane into D-CAPSHELL.

If future work needs a reviewed per-step knob instead, that work must return **RFC-first** as its own schema/
decision surface rather than being hidden behind this index.

## Closed launch-boundary set (Phase 1)

### 1) Front-end interpretation must stay exact

| Posture doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`capshell-exec-selector-posture-v0.md`](capshell-exec-selector-posture-v0.md) | executable choice | exactly one `role="exec"` selector; no ambient PATH | CH-ARGV `desc` token |
| [`capshell-exec-object-posture-v0.md`](capshell-exec-object-posture-v0.md) | executable object identity | validated exec selectors end at one exact bound object; no late path/document-name reopen or retarget-by-rename semantics | exact-object launch or exact-byte staging |
| [`capshell-argv0-posture-v0.md`](capshell-argv0-posture-v0.md) | invocation/program-name semantics | child `argv[0]` is derived from the reviewed `role="exec"` selector; no caller-controlled or wrapper-controlled program-name spoofing, and no portable mode-by-name promise on the generic seam | ordinary reviewed argv/subcommands, or a future explicit alias/app-mode seam |
| [`capshell-code-closure-posture-v0.md`](capshell-code-closure-posture-v0.md) | startup native code closure | reviewed launch includes the exact executable object plus the loader/interpreter/shared-library startup closure; no ambient `/etc/ld.so.cache`, `/lib*` / `/usr/lib*`, current-directory, or DLL-search-order dependency search | static/self-contained image, exact sealed closure root, or exact staged closure |
| [`capshell-script-entry-posture-v0.md`](capshell-script-entry-posture-v0.md) | script/text entry | shebangs stay non-authoritative metadata; no `/usr/bin/env` or ENOEXEC fallback in the runner | explicit interpreter as the `role="exec"` selector |
| [`capshell-command-string-posture-v0.md`](capshell-command-string-posture-v0.md) | command-string input | no free-form command-string parser, auto-tokenization, or hidden `sh -c` / `system()` plane | structured CH-ARGV only |
| [`capshell-startup-profile-posture-v0.md`](capshell-startup-profile-posture-v0.md) | shell startup/session init | no implicit rc/profile files, per-directory hooks, or prompt/cwd code-loading events | explicit future startup/customization seam only |
| [`capshell-word-expansion-posture-v0.md`](capshell-word-expansion-posture-v0.md) | pre-exec token synthesis | no glob/tilde/variable/command-substitution/word-splitting/pathname expansion before reviewed CH-ARGV exists | literal CH-ARGV tokens, or an explicitly chosen interpreter |

### 2) Launch process state must not inherit shell/session defaults

| Posture doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`capshell-env-startup-posture-v0.md`](capshell-env-startup-posture-v0.md) | startup/resolution env hooks | reject `PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, `BASH_FUNC_*` | exact CH-ENV only |
| [`capshell-env-baseline-posture-v0.md`](capshell-env-baseline-posture-v0.md) | convenience env baseline | no runner-synthesized `HOME`/`PWD`/`TMPDIR`/`TERM`/locale/`XDG_*` append step | exact CH-ENV only |
| [`capshell-cwd-root-posture-v0.md`](capshell-cwd-root-posture-v0.md) | cwd/root semantics | CH-CWD binds a cwd root; no `..` escape, host-root fallback, or advisory downgrade | explicit CH-CWD / D-NS |
| [`capshell-handle-table-posture-v0.md`](capshell-handle-table-posture-v0.md) | descriptor / handle table | exact CH-STDIO + CH-FDSET child table only; no ambient inheritance or best-effort `FD_CLOEXEC` / inheritable-handle hygiene | explicit CH-STDIO / CH-FDSET only |
| [`capshell-umask-posture-v0.md`](capshell-umask-posture-v0.md) | file-creation mask | no inherited `umask`; launch fixes `0o077` | future explicit creation-mode seam only |
| [`capshell-rlimit-posture-v0.md`](capshell-rlimit-posture-v0.md) | resource limits | no inherited `ulimit` / `getrlimit()` baseline; `RLIMIT_CORE = 0` | runtime/provider ceilings only |
| [`capshell-signalstate-posture-v0.md`](capshell-signalstate-posture-v0.md) | signal mask/dispositions | no inherited blocked/ignored signal state; empty blocked mask + default dispositions | future explicit signal-state seam only |
| [`capshell-scheduling-posture-v0.md`](capshell-scheduling-posture-v0.md) | CPU scheduling bias | no inherited `nice` / scheduler-policy state; default non-real-time policy + neutral nice `0` | future explicit scheduling seam only |
| [`capshell-affinity-posture-v0.md`](capshell-affinity-posture-v0.md) | CPU affinity / placement | no inherited `taskset` / `sched_setaffinity()` / `CPUAffinity=` / process-affinity mask baseline; default eligible CPU set for the active execution compartment | future explicit affinity/placement seam only |
| [`capshell-resource-envelope-posture-v0.md`](capshell-resource-envelope-posture-v0.md) | resource-controller / cgroup-job envelope | no inherited cgroup / `CPUQuota=` / `MemoryMax=` / `TasksMax=` / Job Object resource-envelope baseline; default resource-controller envelope for the active execution compartment | future explicit cgroup/job resource-envelope seam only |
| [`capshell-personality-posture-v0.md`](capshell-personality-posture-v0.md) | execution-domain / personality flags | no inherited `setarch` / `Personality=` / legacy personality baseline; default native execution-domain / personality only | future explicit ABI/personality seam only |
| [`capshell-mac-profile-posture-v0.md`](capshell-mac-profile-posture-v0.md) | mandatory-access / confinement label-profile state | no inherited `setexeccon()` / `/proc/pid/attr/exec` / `SELinuxContext=` / `AppArmorProfile=` / `SmackProcessLabel=` wrapper baseline; default confinement label/profile baseline for the active execution compartment only | future explicit confinement label/profile seam only |
| [`capshell-peer-inspection-posture-v0.md`](capshell-peer-inspection-posture-v0.md) | peer inspection / dumpability | no inherited dumpable / same-principal ptrace / `/proc` peer-inspection baseline; launch normalizes to non-dumpable / non-peer-inspectable where supported | future explicit debug/diagnostic seam only |
| [`capshell-launcher-lifetime-posture-v0.md`](capshell-launcher-lifetime-posture-v0.md) | launcher/session lifetime coupling | no wrapper-imposed `PR_SET_PDEATHSIG`, inherited Job Object kill-on-close membership, or equivalent launcher-death linkage; child lifetime stays independent of transient launcher/wrapper death inside the active execution compartment | D-REQCTX / D-JOBS / D-BGLEASE / future explicit supervision-lifetime seam |
| [`capshell-syscall-filter-posture-v0.md`](capshell-syscall-filter-posture-v0.md) | syscall-admission / syscall-filter state | no inherited `seccomp()` / `PR_SET_SECCOMP` / `SystemCallFilter=` wrapper baseline; launch stays on the default syscall-admission baseline for the active execution compartment | future explicit syscall-filter / sandbox seam only |
| [`capshell-privgain-posture-v0.md`](capshell-privgain-posture-v0.md) | privilege transitions across exec | no setuid/setgid/file-capability/ambient-capability gain across exec | future explicit credential/elevation seam only |
| [`capshell-credential-baseline-posture-v0.md`](capshell-credential-baseline-posture-v0.md) | caller identity / credential baseline | no ambient caller UID/GID/groups/access-token baseline; fixed least-privilege executor identity only | future explicit identity-selection seam only |

### 3) Ambient namespace + nondeterminism baselines stay out

| Posture doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`capshell-network-posture-v0.md`](capshell-network-posture-v0.md) | sockets / DNS / resolver state | no ambient socket constructors or host-global resolver baseline | D-NETLEASE / `portal.net` / CH-NETLEASE |
| [`capshell-local-ipc-posture-v0.md`](capshell-local-ipc-posture-v0.md) | AF_UNIX / session bus | no ambient AF_UNIX/session-bus/autolaunch baseline | CH-STDIO / CH-FDSET / route-bound service seams |
| [`capshell-filesystem-posture-v0.md`](capshell-filesystem-posture-v0.md) | host filesystem namespace | no ambient absolute-path / host-global filesystem baseline | CH-CWD / CH-FDSET / D-NS / D-POWERBOX |
| [`capshell-nondet-posture-v0.md`](capshell-nondet-posture-v0.md) | time / entropy (when D-NONDET is enabled) | no ambient `clock_gettime()` / timer or `getrandom()` / RNG baseline | `portal.clock` / CH-CLOCK and `portal.entropy` / CH-ENTROPY |

### 4) Interactive control stays local or moves to explicit workflow seams

| Posture doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`capshell-job-control-posture-v0.md`](capshell-job-control-posture-v0.md) | PTY / terminal session plane | no portable PTY, controlling-terminal, process-group, or `fg`/`bg`/`jobs` surface | D-JOBS / D-BGLEASE |
| [`capshell-interrupt-cancel-posture-v0.md`](capshell-interrupt-cancel-posture-v0.md) | interruption semantics | no portable signal-send/jobspec/SIGHUP lifecycle plane | D-REQCTX / D-JOBS / D-BGLEASE / D-QUIESCE |

## Review rule

Before adding another `capshell-*-posture-v0.md` adjunct, answer these questions in order:
1) Is the change really a **launch-boundary/front-end meaning pin** for `capshell.exec`?
2) Can the need be satisfied by an existing explicit seam already in the table above?
3) If not, is the entropy cost worth paying for **one new posture** rather than a new schema/RFC surface?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and
extend the drift gate so discovery cannot silently rot.
