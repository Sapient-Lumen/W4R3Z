# CH-PLEDGE v0: Voluntary promise mask / self-restriction contract

Purpose: let a component/domain **voluntarily narrow** the privileged operations it can invoke after initialization, in a way that is:
- one-way (monotonic narrowing),
- total/fail-closed (unknown tokens reject),
- auditable (loggable/pinnable),
- ergonomic for large/legacy codebases.

This is inspired by OpenBSD’s `pledge(2)` and the broader “self-restrict” pattern seen in Capsicum and Landlock. It is intended as a *wrapper* around D-SEAL/D-CAPMODE (defense in depth), not a replacement for correct capability distribution.

References: REF-OPENBSD-PLEDGE, REF-BECK-PLEDGEUNVEIL-2018, REF-LANDLOCK, REF-CAPSICUM.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-PLEDGE v0 := {
  v: 0,

  ; enforcement policy (how violations are handled)
  violation: tstr,          ; closed enum: "deny" | "kill"
                            ; deny: return stable error (e.g., ENOSYS/EPERM)
                            ; kill: terminate domain deterministically (profile-defined)

  ; closed set of promise tokens (versioned by CH-PLEDGE)
  promises: [ tstr ],       ; non-empty, unique, sorted (canonical order)

  ; optional: promises applied to a freshly spawned child before it runs user code
  ; (useful for supervisors/launchers; monotonic w.r.t. parent)
  child_promises?: [ tstr ],

  ; optional: stable note for audit tools (ignored by validator unless allowlisted)
  note?: tstr
}

### Promise tokens (v0)
Promise tokens are **coarse-grained** to keep the seam small and stable; they map to allowlists of privileged action kinds (CH-KABI) and/or allowlists of portal intents.

v0 token set (closed enum):
- `compute` — no privileged effects beyond exit/yield (pure compute)
- `ipc` — IPC send/recv on already-held endpoints
- `thread` — thread creation/scheduling within existing temporal caps
- `vm` — memory map/unmap within existing address-space caps
- `view.resolve` — resolve names in already-held view objects
- `view.mutate` — bind/mount/unmount within already-held view objects
- `obs` — emit low-risk observability events (trace/log submission), subject to existing caps

- `portal.file` — request file-open/save/export workflows via the workflow router/powerbox (no raw path acquire)
- `portal.uri` — request “OpenURI” workflows (open external links, open directories) via portals
- `portal.print` — request printing workflows via portals (exfiltration surface)
- `portal.device` — request device-selection/device-lease workflows via portals (D-DEVGUARD/D-IOLEASE)
- `portal.location` — request location workflows (one-shot/updates/geofences) via portals (CH-LOCLEASE; D-LOCLEASE)
- `portal.secret` — request per-application secret seed workflows via secret portal (CH-APPSECRET; D-APPSECRET)
- `portal.clock` — request clock handle/lease workflows via a time portal/host shim (CH-CLOCK; D-NONDET)
- `portal.entropy` — request entropy handle/lease workflows via an entropy portal/host shim (CH-ENTROPY; D-NONDET)
- `portal.inhibit` — request session-transition inhibition (idle/suspend/logout/shutdown) via inhibit portal (CH-INHIBITLEASE; D-INHIBITLEASE)

- `portal.net` — request outbound network sessions/leasing via a network portal (if present)
- `portal.capture` — request capture/remote-control sessions (camera/mic/screencast/remote desktop)
- `portal.xfer` — request clipboard/drag-drop/share transfers via transfer portal (CH-XFER)
- `portal.attn` — request notifications/attention prompts via attention portal (CH-NOTIF; D-ATTN)
- `portal.jobs` — request constraint-based background jobs via job portal (CH-JOBREQ)
- `portal.background` — request background execution/autostart grants via background portal (CH-BGREQ/CH-BGLEASE; D-BGLEASE)
- `portal.a11y` — request accessibility/automation sessions (UI observation/injection) via a11y portal (CH-UIAUT)


Notes:
- Tokens may be ignored if the corresponding subsystem is not present; unknown tokens MUST be rejected.
- “Having a token” never grants authority; it only allows *using* already-held authority along certain channels.

## Validation rules (minimum)
A CH-PLEDGE validator MUST be total and fail closed:
1) `v == 0`.
2) `violation` is allowlisted.
3) `promises` is non-empty, each element is allowlisted, no duplicates, length-bounded.
4) `child_promises` (if present) is a subset of `promises`.
5) Unknown keys reject (or are rejected by canonical CBOR decode).

## Semantics notes (binding to runtime)
- Installing a CH-PLEDGE mask is a **one-way** operation (I-PLEDGE-1): future updates may only remove promise tokens.
- Enforcement MUST be applied at every privileged-effect boundary (I-PLEDGE-2): no “fast path” bypass.
- For `violation = "deny"`, implementations SHOULD emit a deterministic, redaction-safe violation record (e.g., via CH-LOG/CH-OBS) that includes the denied effect kind and active pledge digest. This enables “learn mode” workflows without weakening fail-closed behavior.

- Child inheritance MUST be monotonic (I-PLEDGE-3): children cannot start with broader promises than the parent.

The specific mapping from promise tokens → allowed privileged operations is profile-defined but MUST be explicit, reviewed, and covered by tests.

See also: `docs/30-architecture/pledge-token-mapping.md` (seed mapping table to keep token→effect meaning stable and evidence-relevant).
