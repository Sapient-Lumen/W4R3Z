# CH-WPOOLPARAM v0: worker-pool constructor parameter object

Purpose: spend **one small schema** so the first concrete **D-CONSTR** family has an exact, portable target for `param_digest` instead of “equivalent” parameter folklore.
This schema attaches to the already-chosen worker-pool constructor family: it does **not** introduce a generic constructor parameter protocol, an authority bundle, or a pool-admin surface.

## Why this schema is worth the entropy cost
- `worker-pool-invocation-manifest-v0.md` already treats `param_digest` as part of the reviewed invocation contract.
- Without one exact schema, two tools can produce different “same enough” encodings for `pool_size` + restart policy and silently diverge.
- `CH-WPOOLPARAM v0` therefore earns its keep by turning an implied digest target into one exact digest target.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).
- `param_digest` for the first worker-pool family is `digest(CH-WPOOLPARAM v0)` over the canonical bytes of this object.

## Top-level fields

```text
CH-WPOOLPARAM-v0 {
  schema: "CH-WPOOLPARAM";
  version: 0;

  # Number of exported worker slots and worker-set handles.
  pool_size: u8;                # closed range: 1..64

  # Per-slot automatic replacement budget.
  restart: {
    max_restarts: u8;           # closed range: 0..255
    window_ms: u32;             # 0 when max_restarts=0; otherwise 1..3_600_000
  };
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `pool_size` MUST be in `1..64`.
- `restart.max_restarts` MUST be in `0..255`.
- If `restart.max_restarts = 0`, then `restart.window_ms` MUST be `0` and automatic replacement is disabled.
- If `restart.max_restarts > 0`, then `restart.window_ms` MUST be in `1..3_600_000`.
- The object carries **no** capability material, import digests, export-label maps, target identity, prose prompts, or late-bound selectors.

## Semantic meaning
CH-WPOOLPARAM v0 is the exact family-local parameter object for the first worker-pool constructor.
- `CH-WPOOLPARAM v0` is the exact family-local parameter object for the first worker-pool constructor.
- `pool_size` fixes the canonical exported `worker[i]` set and the `worker_slots` table length.
- `pool_size` also fixes the slot count reported through `pool.control` summaries for the same pool instance.
- `worker-pool-slot-state-v0.md` then fixes the exact meaning of each reported `worker_slots[*].state` token without widening this parameter object into runtime state.
- `restart.max_restarts` and `restart.window_ms` form a per-slot automatic-replacement budget.
- `worker-pool-restart-budget-v0.md` fixes the exact operational meaning of that budget: it is a per-slot sliding admission budget over automatic `backoff -> starting` re-entry only, the initial fresh occupant does not consume it, disabled budgets (`0` / `0`) fail closed directly to `failed`, and successful occupancy only ages admissions out of the trailing window.
- The restart budget is tracked per worker slot, not pool-wide.
- When a slot exhausts that budget, the slot transitions to `failed` and no further automatic replacement is attempted for that slot in the current pool instance.
- Changing `pool_size` or restart policy changes `param_digest` and therefore the reviewed invocation contract.

## Security posture
- The parameter object is data-only: it carries no capabilities, no digests for authority-bearing imports, and no caller-chosen export labels.
- `sponsor`, `worker_seed/<label>`, and optional `install_target` stay outside this object on explicit import slots.
- Sealed compat remains honest: hosted runtimes may realize the restart budget however they like internally, but the portable contract remains only the bounded fields above.
- Commutativity stays explicit: parameter changes affect only the reviewed fresh-construction contract; install serialization still lives on the target seam, not inside this schema.

## Wiring
- Decision surface: **D-CONSTR**.
- Family contract: `worker-pool-constructor-family-v0.md`.
- Exact invocation boundary: `worker-pool-constructor-invocation-v0.md`.
- Exact invocation-manifest contract: `worker-pool-invocation-manifest-v0.md`.
- Exact control-handle contract: `worker-pool-control-surface-v0.md`.
- Exact slot-state summary model: `worker-pool-slot-state-v0.md`.
- Primary harness contract: `docs/40-verification/worker-pool-constructor-harness-v0.md`.
- Canonical handoff pack: `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`.
- Reused seams: **D-COMMUTE**, **D-CAPAUD**, **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-ERLANG-OTP-PRINCIPLES**, **REF-EROS-CONFINEMENT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_param_schema.py` (**EVID-2026-368**).
