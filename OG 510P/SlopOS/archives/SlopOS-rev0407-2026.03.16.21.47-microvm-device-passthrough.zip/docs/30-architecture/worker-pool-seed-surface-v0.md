# Worker-pool seed import surface v0 (exact `worker_seed/<label>` meaning)

Purpose: pin the exact Phase-1 meaning of the repeated `worker_seed/<label>` import family for the first concrete **D-CONSTR** target.
`worker-pool-constructor-invocation-v0.md` already says that the worker-pool constructor may consume zero or more `worker_seed/<label>` slots; this doc closes the remaining folklore gap by fixing what those slots bind, how broadly they apply, and what they cannot silently turn into.
It does **not** introduce a generic import schema, a per-worker policy language, or a second control plane.

## Phase-1 choice

1) **`worker_seed/<label>` binds a reviewed worker import label, not a per-slot payload channel**
   - Each `worker_seed/<label>` entry binds one caller-supplied authority input to one declared import label in the pinned worker closure/template contract.
   - The constructor interprets `<label>` only as a reviewed import label name; it is not a free-form job tag, a hidden routing expression, or a per-slot selector language.
   - This repeated seed family lives alongside one required `sponsor` import and optional `install_target`; it narrows only the worker-seed side of the invocation and does not reinterpret those other imports.
   - Labels therefore stay exact, finite, and template-owned.

2) **The seed-label set is pool-wide and uniform across all worker slots**
   - For one constructor invocation, every worker slot is launched against the same reviewed seed-label set.
   - Phase 1 adds no `worker_seed/<label>[i]`, no per-worker override map, and no caller-chosen partitioning of seed imports across `worker[i]` slots.
   - Slot-specific authority differences therefore require a different constructor family or an explicit later RFC; they are not smuggled into the first worker-pool family through naming folklore.

3) **Required/optional labels are determined by the pinned worker closure, and mismatches fail closed**
   - If the reviewed worker closure/template contract requires a label, the matching `worker_seed/<label>` import MUST be present.
   - If an invocation supplies an undeclared extra `worker_seed/<label>`, the constructor MUST fail closed rather than ignore it, widen silently, or reinterpret it as metadata.
   - Replay and confinement evidence therefore key off an exact seed-label set, not “best effort” matching.

4) **Seed imports are constructor inputs only; they are never renamed into outputs**
   - `worker_seed/<label>` entries exist only on the constructor input side.
   - The family does not export seed handles directly, does not republish them under constructor-owned aliases, and does not expose a reflected import inventory on `pool.control` or `worker[i]`.
   - Any worker-visible use of a seed happens only through the pinned worker closure’s own reviewed interface and sealing discipline.

5) **Reseed-after-construction is out of scope in v0**
   - Once a pool is constructed, the seed-label set and its bindings are immutable for that pool instance.
   - `pool.control` adds no `reseed_imports`, `SwapImports`, `InjectSeed`, or equivalent mutator, and `worker[i]` adds no per-slot import-rewrite/admin verb.
   - If future profiles need seed rotation or staged rebinding, that work must pay for a new explicit surface instead of widening this family in place.

6) **Sealing and confinement obligations apply to seed imports too**
   - Setup-only seed authority that is needed only to construct or initialize workers MUST be dropped before routine service, following **D-SEAL**.
   - The constructor/harness must treat leaked seed handles the same way it treats any other undeclared authority gain: as a confinement failure under **PO-CONSTR-CONFINE**.
   - Sealed compat remains honest: any foreign compatibility layer that cannot keep seed authority explicit and killable by policy must fail closed rather than invent ambient seed lookup.

7) **Commutativity stays invocation-scoped because seed labels are fixed up front**
   - Return-only fresh pool construction still commutes when invocations consume only their explicit imports and allocate fresh isolated results.
   - Fixing the seed-label set up front means there is no hidden per-slot import ordering story and no constructor-global seed sequencer.
   - Install cases remain non-commuting only where the existing `install_target` seam already serializes them.

8) **Evidence binds the exact seed-label set and proves non-leakage**
   - The first worker-pool harness/evidence pack MUST bind the exact set of `worker_seed/<label>` imports used by the invocation.
   - The cap-graph delta predicate MUST reject any seed handle, setup helper, or import-inventory surface that becomes caller-reachable outside the declared `pool.control` plus `worker[i]` outputs.
   - The family therefore adds no separate seed receipt schema or constructor-global import inventory.

## Out of scope in v0

- Per-worker seed maps, worker-class partitions, or heterogeneous seed sets inside one pool instance.
- Post-construction seed rotation or import hot-swap.
- A generic schema for constructor seed descriptors.
- Reflected import inventories or debugging APIs that disclose seed contents/identities by default.
- Treating seed labels as ambient service-discovery names.

## Wiring

- Decision surface: **D-CONSTR**.
- Reused seams: **D-SEAL**, **D-CAPAUD**, **D-COMMUTE**.
- Primary family docs: `worker-pool-constructor-family-v0.md`, `worker-pool-constructor-invocation-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-worker-surface-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-CAPABILITIES**, **REF-FUCHSIA-REALMS**, **REF-GENODE-INIT**, **REF-EROS-CONFINEMENT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_seed_surface.py` (**EVID-2026-364**).
