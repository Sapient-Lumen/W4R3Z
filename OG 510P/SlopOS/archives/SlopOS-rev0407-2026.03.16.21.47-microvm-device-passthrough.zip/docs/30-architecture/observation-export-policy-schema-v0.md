# CH-OBSPOL v0: Observation export policy (schema)

Purpose: make “what diagnostics/telemetry can be exported” **explicit, reviewable, and deterministic**.

See also: `observation-export-posture-v0.md` (D-OBS Phase 1 posture: pull-only, bounded/redacted, policy-killable exports).

This schema is a *policy-as-data* companion to IF-OBS and D-INSPECT:
- IF-OBS exports **CH-OBS** payloads (logs/trace summaries/graphs/etc).
- D-INSPECT adds bounded **CH-INSPECT** snapshots and shareable bundles: **CH-CRASHCAP** crash capsules and **CH-SNAPSHOT** support bundles.
- **CH-OBSPOL** pins the allowlist/bounds/redaction tier so tooling can fail closed and auditors can verify “we only exported what we said we would.”

Design constraints (v0)
- deterministic decode + canonical encoding (I-ENC-1; PO-ENC-DECODE)
- closed enums; unknown keys/values reject
- bounded sizes and bounded rule sets (no regex engines, no scripts)
- policy MUST NOT grant authority; it only constrains exports (aligns with I-OBS-2)

References: REF-FUCHSIA-DIAGNOSTICS, REF-FUCHSIA-TRIAGE, REF-ANDROID-BUGREPORT.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1).

## Data model (conceptual)

CH-OBSPOL v0 := {
  v: 0,

  name: tstr,                 ; short policy name (<= 64 bytes)
  description?: tstr,         ; optional (<= 512 bytes)

  ; Export tier: the default should be 'sanitized'.
  tier: tstr,                 ; closed enum: 'sanitized' | 'full'

  ; What high-level payload classes may be exported via IF-OBS.
  obs_allow: {
    logs?: bool,              ; allow exporting CH-LOG entries
    trace?: bool,             ; allow exporting CH-TRACE (usually summarized/processed)
    cap_graph?: bool,         ; allow exporting CH-CAPG
    labels?: bool,            ; allow exporting CH-LABEL
    metrics?: bool,           ; allow exporting numeric counters/aggregates (profile-defined)
    other?: bool
  },

  ; Whether shareable support/incident bundles may be created.
  snapshot_allow?: {
    enabled: bool,
    kinds: [ tstr ],           ; closed enum list: 'log'|'trace'|'inspect'|'crash'|'boot'|'comp'|'cfg'|'other'
  },

  ; Redaction class allowlist for exported fields/entries.
  redaction_allow: [ tstr ],   ; closed enum list: 'public' | 'sanitized' | 'sensitive'

  ; Global bounds (hard caps).
  bounds: {
    max_total_bytes: uint,     ; total bytes of an exported payload/bundle (profile cap)
    max_entry_bytes: uint,     ; per-entry cap (e.g., per CH-SNAPSHOT entry)
    max_entries: uint,         ; total entries (e.g., CH-SNAPSHOT entries)
  },

  ; Hard disallow lists.
  forbid: {
    allow_sturdyrefs: bool,    ; MUST be false for sanitized policies
    allow_raw_addrs: bool,     ; MUST be false for sanitized policies
    allow_secret_caps: bool,   ; MUST be false always (no secret-bearing caps)
  },

  meta?: { * tstr => any }     ; ignored unless allowlisted
}

## Validation rules (minimum)
A CH-OBSPOL validator MUST be total and fail closed:
1) `v == 0` and required fields present (`name`, `tier`, `obs_allow`, `redaction_allow`, `bounds`, `forbid`).
2) `tier` is one of the closed enum values.
3) `redaction_allow` contains only closed enum values.
4) `bounds.*` are within profile limits (e.g., `max_total_bytes <= MAX_OBS_EXPORT_BYTES`).
5) `forbid.allow_secret_caps == false` always.
6) If `tier == 'sanitized'`: `forbid.allow_sturdyrefs == false` and `forbid.allow_raw_addrs == false`.
7) If `snapshot_allow.enabled == true`, `snapshot_allow.kinds` elements are from the closed enum list.
8) Unknown `meta` keys are ignored unless allowlisted.

## Intended uses
- **Operator policy pinning**: export tooling records the policy digest so recipients can verify which rules were applied.
- **Bundle profiles**: development builds may permit `tier='full'` with stricter access control, while production defaults to `tier='sanitized'`.
- **Fail-closed enforcement**: if an export request cannot be satisfied under the policy (size/type/redaction), it must produce a bounded error and refuse.

## Proof obligations (hooks)
- PO-OBSPOL-VALIDATE: decoding/validation is total/canonical and bounds are enforced.
- PO-OBSPOL-APPLY: exporters apply policy deterministically and fail closed on violations.
