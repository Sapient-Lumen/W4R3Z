# D-CAPRPC promise posture v0 (session-local one-shot promises; capability-result pipelining only)

Purpose: pin an implementable **Phase 1** meaning for the **promise handle + pipelining adjunct** on **D-CAPRPC** so capability-RPC latency tolerance stays a small runtime seam instead of widening into a general promise broker, queueing subsystem, or hidden scheduler/control surface.
It narrows RFC-0026 into one compact posture adjacent to **D-TURNS**, **D-REQCTX**, **D-COMMUTE**, and **D-CAPX** so runtimes, validators, and replay/logging tools can reason about one default shape.

## Posture (v0)

1) **Promise/result handles stay caller-local, session-scoped, and one-shot**
   - A D-CAPRPC promise/result handle exists only inside the owning caller/runtime session.
   - It names one eventual outcome slot and is consumed by resolve/break/cancel completion, not a reusable mailbox or globally shareable object.
   - Phase 1 therefore treats promise/pipeline state exactly like other session runtime state around `call_id` / reply routing: explicit, bounded, and non-replicated.

2) **Pipelining is allowed only toward unresolved capability results, not arbitrary data promises**
   - The portable v0 seam permits pipelined sends only when the unresolved result is expected to designate a **capability/object reference** once resolved.
   - Pipelining does **not** expose a general “call methods on any unresolved data value” surface, property-path mini-language, or host-language reflection trick.
   - This keeps the latency win where ocap RPC needs it most while declining a wider promise calculus in Phase 1.

3) **Dependent sends preserve sender identity, `iface_digest` checks, and explicit attachment bounds**
   - A pipelined call MUST execute exactly as if the caller had waited for resolution and then sent the call with the same sender identity, the same explicit attachments, and the same `iface_digest` / `method_id` checks.
   - Pipelining MUST NOT bypass rights checks, method/interface pins, or attachment-count / payload bounds from **CH-CAPRPC**.
   - This is the concrete runtime reading of **I-CAPRPC-3** and **PO-CAPRPC-PIPELINE**.

4) **Cancellation and disconnect break dependent promises deterministically; no silent completion**
   - If the caller cancels the owning **D-REQCTX**, the connection aborts, or the upstream promised result is broken, dependent pipelined sends fail with deterministic framework outcomes.
   - The runtime MUST NOT silently drop, silently complete, or “best effort maybe later” any dependent promise work.
   - Broken-promise propagation is therefore explicit and replay/log friendly rather than hidden transport behavior.

5) **No public promise catalog, list/watch, or cross-session restore/export surface**
   - Phase 1 declines any portable API to enumerate live promises, subscribe to their state, hand them to unrelated sessions, persist them, or restore them later.
   - Promise handles are not sturdyrefs, not `CH-CAPX`, and not a new export/import family.
   - This keeps unresolved-result state out of inventories, logs, and workflow routers.

6) **No portable join/race/fork combinator surface on D-CAPRPC**
   - Host runtimes MAY internally implement helpers such as fan-out/fork/join/race, but SlopOS v0 does **not** standardize them on the D-CAPRPC seam.
   - In particular, there is no portable `Promise.all`, `race`, `fork`, or `await_any` contract in the CH-CAPRPC surface itself.
   - This keeps the wire/runtime contract small and avoids turning promise state into a second scheduler API.

7) **No hidden inbox pumping; D-TURNS remains the default composition story**
   - Promise helpers and pipelined sends may improve latency tolerance, but they must not reintroduce hidden inbox pumping or cross-vat synchronous call chains.
   - Blocking/await conveniences remain subordinate to **D-TURNS**: either block without servicing inbound work or schedule an explicit continuation.
   - Promise pipelining is therefore a latency tool, not a reentrancy escape hatch.

8) **External action semantics stay on existing conflict keys and ordering witnesses**
   - A pipelined call that eventually performs an externally visible action keeps the same underlying provider conflict keys, commutativity stance, serialization boundary, and **CH-ORDERTOK** evidence story as the non-pipelined call.
   - D-CAPRPC promises do **not** mint a new queue-order surface, a promise-local sequencing token, or a second ordering broker.
   - The adjunct changes dispatch timing/latency only; it does not create new externally visible action semantics.

9) **No new workflow / ACP / admin surface on D-CAPRPC promises**
   - Phase 1 introduces no new portal family, no new **CH-ACP** kind, and no generic admin protocol for listing, cancelling, migrating, or force-resolving promises across components.
   - Any future promise-administration surface must pay its own schema, commutativity, and evidence cost explicitly.
   - This keeps D-CAPRPC promises from quietly becoming a hidden control plane.

10) **Sealed compat remains killable and non-ambient**
   - Foreign Cells may adapt guest promise/future abstractions only through explicit, policy-killable membrane surfaces.
   - They must not recreate ambient event loops, background resolver registries, or path/env based promise lookup that bypasses declared capability-RPC handles.
   - Any compat enablement remains subordinate to sealed-compat policy and must fail closed when disabled.

## Phase 1 non-goals (explicitly deferred)

- A portable promise inventory, subscription API, or debug/inspection protocol.
- Durable/exportable unresolved-result handles or cross-session promise restoration.
- General data-promise method/property pipelining.
- Portable `join` / `race` / `fork` combinators on D-CAPRPC itself.
- Any new workflow / ACP / admin surface for promise lifecycle management.

## Wiring

- Decision surface:
  - `decision-map.md` (D-CAPRPC)
- Adjacent runtime surfaces:
  - `mechanisms.md`
  - `rfcs/0026-object-capability-rpc-profile.md`
  - `turns-posture-v0.md`
  - `reqctx-posture-v0.md`
  - `capability-rpc-frame-schema-v0.md`
  - `capability-rpc-frame-schema-v1.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-CAPRPC-1**, **I-CAPRPC-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-CAPRPC-FRAME**, **PO-CAPRPC-PIPELINE**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-064**)
- Related posture/history surfaces:
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/llm-runbook.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future external promise-management surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_caprpc_promise_posture.py` fails `make lint` if this posture stops being discoverable, loses the **session-local one-shot / capability-result-only pipelining / deterministic break / no promise inventory** posture, or drops its primary REF wiring.

## References

- REF-CAPNP-RPC.
- REF-CAPNP-CXXRPC.
- REF-E-REFMECH.
- REF-TC39-EVENTUALSEND.
