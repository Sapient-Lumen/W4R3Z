# Origin + quarantine attribute set (for CH-ATTR v0)

Purpose: provide a small, reviewable attribute key space used by D-QUAR so that:
- quarantined objects can be detected consistently,
- propagation rules are testable,
- UI can present provenance without guessing.

This is an **instance** of CH-ATTR v0 (not a new CH-* schema).

## Declared keys

### origin.*
- `origin.source` : enum {`network`, `email`, `removable`, `ipc`, `unknown`}
- `origin.locator_hint` : string (optional; non-authoritative)
- `origin.time` : u64 (unix seconds)
- `origin.parent_digest` : digest (optional; exact immediate parent object digest for derived objects; required for ordinary safe-open kept/exported output when the parent digest is known)
- `origin.import_ref_digest` : digest (optional; exact digest of the accepted CH-SREF / CH-CAPX import object when a fresh local document object was materialized from bearer restore/import)
- `origin.chain_digest` : digest (optional; if CH-PROV is enabled, digest of the provenance chain object)

### quarantine.*
- `quarantine.state` : enum {`none`, `quarantined`, `cleared`}
- `quarantine.reason` : enum {`download`, `attachment`, `extracted`, `unknown`}
- `quarantine.cleared_by` : string (optional; identifier for the clearing workflow/policy)

## Semantics (summary)
- Any create/copy/extract from a quarantined object yields a quarantined object (I-QUAR-1), and ordinary safe-open export from a quarantined object also yields a quarantined new object by default, unless a declared sanitize/clear workflow produces a differently classified artifact with an explicit log record (`open-untrusted-export-classification-v0.md`).
- When ordinary safe-open output is kept/exported, the new artifact records the exact immediate parent object digest as `origin.parent_digest`; richer lineage may additionally be bound through `origin.chain_digest` when CH-PROV is enabled (`open-untrusted-export-lineage-boundary-v0.md`).
- Clearing is **object-local**: clearing one object does not recursively clear enclosing archives, extracted children, siblings, or future derivations (I-QUAR-5).
- Safe-open / preview does not silently rewrite the source object’s quarantine state; sanitized/dequarantined materialization happens by producing a **new artifact** with its own digest and transcript-visible reason rather than laundering trust in place (`quarantine-posture-v0.md`).
- `origin.locator_hint` is informational and must not be used for authorization decisions or as a substitute for explicit parent-digest lineage; it must not carry raw bearer material, capability URLs, or hidden restore/re-fetch instructions.
- Quarantine/origin classification is **object-local rather than content-addressed trust**: equal bytes do not imply shared quarantine state, shared document identity, or permission to reuse an existing docref/object on CH-SREF / CH-CAPX driven import (`import-to-docref-fresh-identity-boundary-v0.md`).
- `origin.import_ref_digest` is the minimum portable breadcrumb for that explicit bearer handoff when policy records it: the value is digest-only evidence, not raw bearer material, not reopen authority, and not a replacement for `origin.parent_digest` or richer CH-PROV lineage (`import-to-docref-bearer-provenance-boundary-v0.md`).
- `origin.parent_digest` / `origin.chain_digest` remain **explicit related-artifact navigation evidence**, not hidden query joins: if a derived artifact carries OCR text, semantic tags, or similar fields, those breadcrumbs do not make the quarantined source object itself match a CH-ATTRQ predicate unless a future explicit relation-query surface says so (`quarantined-derived-match-boundary-v0.md`).
