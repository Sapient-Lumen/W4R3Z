# Capshell env-baseline posture v0 (no injected convenience baseline)

Purpose: keep **D-CAPSHELL** honest when workflows bind **CH-ENV v0**. The archive already says
child environments are **complete and explicit**, but that promise still drifts if runners are
allowed to synthesize “helpful” baseline variables from the host login/session/TTY context or from
other bound descriptors.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a locale policy
engine, a user-identity service, a home-directory portal, or a profile-specific “supply whatever
legacy programs usually expect” compatibility database. It only freezes the minimum Phase 1
posture needed so automation stays reviewable across all four product shapes.

## Posture (v0)

1) **The child environment is exact, not “declared plus baseline”**
   - The environment visible to the launched program is exactly the ordered set of entries named in
     the bound **CH-ENV v0** descriptor.
   - The runner MUST NOT append a profile-defined, host-defined, wrapper-defined, or
     session-manager-defined baseline environment.
   - “Complete and explicit” therefore means *exactly CH-ENV*, not “CH-ENV plus whatever the
     launcher thinks is conventional.”

2) **No synthesized convenience variables in v0**
   - The runner MUST NOT synthesize convenience variables from ambient login/session/TTY/locale/
     timezone state or from other execution-pack fields.
   - Phase 1 forbids hidden injection of common host/session variables such as:
     - `HOME`, `PWD`, `OLDPWD`, `TMPDIR`
     - `USER`, `LOGNAME`, `SHELL`
     - `TERM`
     - `LANG`, `LC_*`, `TZ`
     - `XDG_CONFIG_HOME`, `XDG_DATA_HOME`, `XDG_STATE_HOME`, `XDG_CACHE_HOME`, `XDG_RUNTIME_DIR`,
       `XDG_CONFIG_DIRS`, `XDG_DATA_DIRS`
   - These names remain allowed as **explicit CH-ENV entries**. The boundary is that the runner
     cannot create them implicitly.

3) **Other explicit seams do not secretly mint env**
   - Binding **CH-CWD v0** does **not** authorize the runner to synthesize `PWD` or `OLDPWD`.
   - Terminal/stdio bindings do **not** authorize synthesis of `TERM`.
   - Request/workflow context does **not** authorize synthesis of locale/timezone/user identity
     variables.
   - Any future “derive env from another seam” behavior must return as an explicit RFC-first
     surface rather than widening CH-ENV by implication.

4) **Explicit declaration stays data-only**
   - Workflows MAY still include `HOME`, `TMPDIR`, `TERM`, `LANG`, `LC_*`, `TZ`, or `XDG_*` as
     literal CH-ENV entries when they intentionally want that child-visible configuration.
   - Doing so does **not** grant filesystem, terminal, user-database, or timezone authority by
     itself; authority still comes only from explicit handles, portals, and effect contracts.
   - Phase 1 therefore separates “the child can see a string” from “the runner may discover and
     inject host/session context on its behalf.”

5) **No silent repair or compatibility injection**
   - If a workflow omits convenience variables, the runner MUST launch with them omitted.
   - The runner MUST NOT auto-fill “reasonable defaults,” auto-copy host values, or apply a
     profile-specific legacy compatibility baseline behind the review surface.
   - Learn-mode/adoption tooling MAY *suggest* explicit CH-ENV entries for compatibility, but
     accepted execution still injects only what the reviewed CH-ENV names.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.env.baseline.*` ACP kind, no baseline-env profile blob, and no
     query API for “what would the runner have injected?”
   - Any future compatibility annex for conventional locale/home/runtime variables must come back as
     a separate RFC/decision surface rather than hiding inside runner defaults.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that omitted convenience variables stay omitted instead of being
     silently repaired by launcher policy.

8) **Sealed compat remains killable and non-ambient**
   - Wrapper-based adoption or foreign-cell automation MUST carry the same exact-env posture across
     the membrane.
   - Compat layers MUST NOT recreate ambient host/session state by auto-injecting home, cwd,
     locale, timezone, terminal, user, or XDG directory variables behind the membrane.

## Phase 1 non-goals (explicitly deferred)

- No generic environment-baseline profile matrix for compatibility runtimes.
- No locale/home/runtime-dir portal hidden behind CH-ENV.
- No automatic `PWD`/`TERM` synthesis from CH-CWD or CH-STDIO.
- No profile-specific “legacy shell baseline” append step.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary schema seam: `env-schema-v0.md` (**CH-ENV v0**).
- Existing adjacent seams:
  - `capshell-env-startup-posture-v0.md`
  - `cwd-schema-v0.md`
  - `stdio-schema-v0.md`
  - `capshell-exec-pack-schema-v2.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-ENV-4` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-ENV-EXACT` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_env_baseline_posture.py` (**EVID-2026-327**).

## References

- REF-OPENGROUP-ENVVARS
- REF-XDG-BASEDIR
