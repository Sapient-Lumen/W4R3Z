# CH-LABEL v0: information-flow labels and tag privileges

Purpose: a minimal, canonical representation of DIFC label state that can be used for:
- debugging/observability (redacted)
- checkpoint/restore metadata (optional)
- policy tooling / test fixtures

Non-goal: representing *authority* itself. Actual tag privileges remain capabilities; CH-LABEL records only *identifiers* and inventories for audit/debug.

## Canonical fields (v0)

### `label`
Represents a label as two finite sets of tag identifiers.

- `secrecy: [tag_id...]` — tags that must be preserved (no write-down)
- `integrity: [tag_id...]` — tags describing acceptable influence (no read-down)

Encoding rules:
- Each list is sorted lexicographically.
- Duplicates are forbidden.
- Empty lists are allowed.

### `tag_id`
Opaque identifier, canonical string form.

Rules:
- ASCII alphanumerics plus `._-`.
- 1..64 bytes.
- No embedded secrets; treat as a name/handle.

### `priv_inventory` (optional)
A debug/audit snapshot of which tag-privileges a domain claims to hold.

- `secrecy_add: [tag_id...]` — may add secrecy tag to a label
- `secrecy_remove: [tag_id...]` — may remove secrecy tag (declassify)
- `integrity_add: [tag_id...]` — may add integrity tag (endorse)
- `integrity_remove: [tag_id...]` — may remove integrity tag

Notes:
- This is *observational* and may be incomplete (e.g., if privileges are hidden behind membranes).
- Tooling should treat it as “what the exporter can see,” not as authoritative.

### `scope` (optional)
Optional string describing what this snapshot covers, e.g.:
- `domain:<id>`
- `object:<id>`
- `checkpoint:<digest>`

## Redaction guidance
- IF-OBS exports should default to redacting tag identifiers unless the caller has explicit authority.
- A safe default is to export counts/hashes: `hash(tag_id || salt)` with a pinned salt per transcript.

## Compatibility
- v0 is intentionally narrow; any extension must be additive and versioned.
