# MicroVM generation-witness posture v0 (guest-visible clone/restore detection is explicit)

Purpose: pin the **Phase 1** guest-side detection story for `ext.microvm` snapshot/clone acceleration so runtimes do not infer restore events from broken sessions, copied entropy, or ad-hoc host agents.

This doc attaches to **D-MICROVM**, **D-EPHEM**, and **D-NONDET** and makes one hard decision explicit:
**if guest software must adapt after clone/restore, it gets one explicit generation witness, not folklore.**

## Posture (v0)

1) **Exactly one primary guest-visible generation witness**
   - If a profile uses `ext.microvm` snapshot/clone acceleration and expects guest/user-space software to repair clone-sensitive state after restore, the VMM/runtime MUST expose **one primary guest-visible generation witness**.
   - Phase 1 prefers **VMClock `vm_generation_counter`** when available; otherwise **VMGenID** is the accepted fallback.
   - If both mechanisms are present, runtime policy treats **VMClock `vm_generation_counter` as the primary witness** and uses VMGenID only as a compatibility adjunct. This keeps restore handling deterministic instead of asking guests to reconcile multiple competing signals.

2) **Witness semantics are narrow and explicit**
   - The witness changes when a virtual machine is restored to an earlier or otherwise non-unique state (for example snapshot restore, backup recovery, clone/copy/import, or failover to copied state).
   - Ordinary pause/resume, reboot, host reboot, or lossless live migration are **not** clone/restore events for this posture.
   - The witness is a **read-only observational signal**, not authority: it does not authorize resume, import, network access, secret release, or any host↔guest management action.
   - Clock-quality repair is pinned separately in `microvm-clock-disruption-posture-v0.md`: generation change and VMClock `disruption_marker` / `clock_status` are orthogonal rather than interchangeable.

3) **Observation must happen before resumed payload matters**
   - The guest runtime responsible for entropy/identity/session hygiene MUST be able to observe the new witness value before resumed user payload relies on clone-sensitive state.
   - Snapshot/clone acceleration that cannot deliver the witness in time for the chosen guest/runtime profile is out of scope for Phase 1 and MUST fail closed rather than relying on “connections broke, so maybe we were restored.”
   - In particular, guests must not treat broken network/vsock/session side effects, changed CIDs, or other incidental fallout as the authoritative restore detector.

4) **What the guest/runtime does with witness changes is pre-committed**
   - A changed witness triggers **clone/restore hygiene**, not continuity optimism.
   - At minimum, the guest/runtime reseeds or refreshes entropy-dependent state, regenerates ephemeral instance identifiers and per-instance agent/session tokens, and invalidates cached state that assumes monotonic uniqueness or uninterrupted execution.
   - Any desired continuity still crosses explicit existing seams such as D-ACTIVATE, D-NETLEASE, or D-CAPX; the witness does not replace them.

5) **No new ambient interop plane**
   - Phase 1 does **not** invent a host agent, callback channel, RPC control plane, or snapshot catalog just to tell guests they were restored.
   - VMClock / VMGenID remain implementation-local mechanisms under the D-MICROVM posture, not new SlopOS `CH-*` schemas or portable policy objects.
   - Sealed compat stays honest: a foreign guest may consume the witness for its own hygiene, but that does not create a hidden general interop channel.

6) **Commutativity/ordering remain unchanged by omission**
   - D-MICROVM v0 still defines **no generic ACP kind** for snapshot/restore/clone and therefore adds **no new conflict-key family** in Phase 1.
   - If a later management plane exposes snapshot/restore as an externally visible action, it must specify conflict keys, commutativity stance, retry semantics, and serialization scope explicitly.
   - The witness itself is observational and therefore introduces no new externally visible ordered action family.

## Phase 1 non-goals (explicitly deferred)

- No generic guest-agent protocol for restore callbacks.
- No portable live-migration contract.
- No snapshot catalog / history / inventory API.
- No guarantee that every VMM exposes both VMClock and VMGenID.
- No in-place upgrade of the witness into a new authority-bearing SlopOS schema.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-NONDET)
- Adjacent postures:
  - `microvm-profile-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `disposable-domain-posture-v0.md`
  - `nondet-posture-v0.md`
  - `microvm-clock-disruption-posture-v0.md`
  - `microvm-restore-repair-barrier-posture-v0.md`
  - `microvm-attestation-reacquire-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-GEN-WITNESS)
- Policy posture:
  - the generation witness is observational only; it adds **no lane**, **no host-agent exemption**, and **no new ambient host↔guest channel** in Phase 1.

CI drift gate:
- `tools/check_microvm_generation_witness_posture.py` fails `make lint` if this posture stops being discoverable, loses its **one primary witness / VMClock-preferred / VMGenID-fallback / no side-effect detector / no new interop plane** constraints, or drops its assurance/reference wiring.

## References

- REF-UAPI-VMCLOCK.
- REF-UAPI-VMGENID.
- REF-QEMU-VMGENID.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
