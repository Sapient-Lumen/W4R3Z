# CH-NAMECERT v0: Local naming certificate bundle schema

Purpose: represent a **bounded set of local name bindings + delegation statements** as a canonical artifact (D-NAMECERT).

This schema is meant to be easy to validate and audit. Complex chain discovery/policy reasoning remains in user space.

## Design rules
- closed-world: unknown keys/variants reject
- bounded sizes: cap number of bindings/delegations
- canonical encoding: I-ENC-1

## Canonical shape (informal)

```text
NameCertBundle {
  schema: "CH-NAMECERT-v0",
  bundle_id: String,        // signed provenance label only in v0; not a serial/version/winner key (see namecert-metadata-boundary-v0.md)
  issuer: PrincipalRef,
  created_ms: u64,          // signed provenance timestamp only in v0; not freshness/obsolescence semantics by itself (see namecert-metadata-boundary-v0.md)
  bindings: [Binding],
  delegations: [Delegation],
  sig: Signature,
}

PrincipalRef {
  kind: "key_hash" | "pubkey",
  alg: String,
  data: Bytes,
  // admitted Phase 1 bundles accept only kind="key_hash", alg="cose_key_thumbprint_sha256", data=32-byte thumbprint (see namecert-principal-profile-v0.md)
}

Binding {
  name: String,              // local label: exact-byte lowercase ASCII opaque atom in v0; `.` / `_` / `-` are ordinary bytes, not separators (see namecert-string-profile-v0.md, namecert-label-atom-boundary-v0.md)
  target: TargetRef,
}

TargetRef {
  kind: "principal" | "sturdyref" | "proxy",
  ref: Bytes,                // opaque bytes interpreted by the consumer; `sturdyref` is structurally reserved but rejected in admitted Phase 1 bundles (see namecert-bearer-boundary-v0.md)
}

Delegation {
  role: String,              // local role label; exact-byte lowercase ASCII opaque atom in v0; `.` / `_` / `-` are ordinary bytes, not separators (see namecert-string-profile-v0.md, namecert-label-atom-boundary-v0.md)
  subject: PrincipalRef,
  rights: RightsRef,
  not_after_ms?: u64,
  constraints?: [Constraint],
  // no `may_delegate` / propagation / depth field in v0; admitted Phase 1 delegations do not imply onward delegation (see namecert-redelegation-boundary-v0.md)
}

RightsRef {
  kind: "cap_set" | "tag" | "opaque",
  ref: Bytes,
}

Constraint { kind: "label" | "caveat" | "opaque", ref: Bytes }
Signature { alg: String, sig: Bytes }  // admitted Phase 1 bundles accept only alg="ed25519" and verify over canonical unsigned bundle bytes (see namecert-signature-profile-v0.md)
```

## Validation requirements (must)
- `issuer` matches `sig` verifier key/hash (according to profile)
- `PrincipalRef.kind` must be `"key_hash"` in admitted Phase 1 bundles; `PrincipalRef.kind = "pubkey"` is structurally reserved but MUST reject at admission in v0 (`namecert-principal-profile-v0.md`)
- `PrincipalRef.alg` must be `"cose_key_thumbprint_sha256"` and `PrincipalRef.data` must be exactly 32 bytes in admitted Phase 1 bundles; equality/comparison for principals is exact `(kind, alg, data)` equality after validation (`namecert-principal-profile-v0.md`)
- `sig.alg` must be `"ed25519"` in admitted Phase 1 bundles, and the inline signature verifies over the canonical unsigned CH-NAMECERT payload shape `{schema, bundle_id, issuer, created_ms, bindings, delegations}` under **I-ENC-1**; wrapper-only/keyless/multisignature semantics are rejected for D-NAMECERT admission (`namecert-signature-profile-v0.md`)
- `bundle_id` and `created_ms` are admitted as signed provenance metadata only: validators do not derive latest-wins, implicit replacement-lineage, or metadata-driven freshness/obsolescence semantics from those fields (`namecert-metadata-boundary-v0.md`)
- bounds on `bindings` and `delegations`
- `bindings` and `delegations` must each be duplicate-free and **strictly sorted by the canonical bytes of each element** under **I-ENC-1**; exact duplicate elements reject and array position is non-authoritative (`namecert-normal-form-boundary-v0.md`)
- `name` and `role` must satisfy the Phase 1 D-NAMECERT string profile (`namecert-string-profile-v0.md`): **1..64 bytes**, lowercase ASCII `[a-z0-9._-]`, first/last byte alphanumeric
- comparison for `name` and `role` is exact byte equality after validation; labels are single opaque label atoms (`.` / `_` / `-` are ordinary bytes), with no dot/slash splitting, no wildcard/prefix/suffix/glob semantics, no Unicode normalization (`NFC`/`NFKC`/`NFD`), no PRECIS/Stringprep, no locale-aware comparison, and no case-folding (`namecert-label-atom-boundary-v0.md`)
- expiry / validity fields (if present) are admission checks enforced by the consumer under local time policy; in Phase 1 they do **not** create auto-detach or background re-evaluation semantics for already-materialized live bindings (`namecert-time-boundary-v0.md`)
- `Delegation` has no `may_delegate` / propagation / depth field in v0; unknown variants reject and admitted Phase 1 evaluation treats delegations as non-redelegable unless a future reviewed seam adds explicit propagation semantics (`namecert-redelegation-boundary-v0.md`)
- `TargetRef.kind = "sturdyref"` is structurally reserved but MUST reject in admitted Phase 1 bundles; CH-NAMECERT v0 must not embed raw CH-SREF / CH-CAPX / raw capability-bearing restore/import material (`namecert-bearer-boundary-v0.md`)

## Notes
- The privileged core should *not* parse CH-NAMECERT by default; it is a user-space feature (see `namecert-posture-v0.md`).
- Consumers evaluate an **explicit bundle set** only; CH-NAMECERT does **not** imply ambient network/filesystem chase, background discovery, or global-directory lookup. Phase 1 search is closed-world over the presented set: implementations may use bounded local search, but there is no suspend/resume distributed credential discovery or hidden retry/fetch semantics (`namecert-search-boundary-v0.md`).
- **CH-NAMECERT v0 is not itself a trust root or trust-policy container**; evaluators must use **explicit local trust-anchor / issuer-allowlist input** and must not auto-promote issuers encountered in the presented bundle set (`namecert-trust-root-boundary-v0.md`).
- **CH-NAMECERT v0 uses one canonical principal-id profile in Phase 1**: admitted `issuer` / `subject` refs are hash-only (`kind="key_hash"`, `alg="cose_key_thumbprint_sha256"`, exact 32-byte thumbprints), raw `kind="pubkey"` admissions reject, and verifier-key distribution stays on explicit local trust-anchor / key-registry policy rather than in bundle contents (`namecert-principal-profile-v0.md`).
- **CH-NAMECERT v0 uses one signature profile in Phase 1**: admitted bundles require the inline `sig` field, accept only `sig.alg="ed25519"`, verify over the canonical unsigned bundle bytes, and treat CH-SIGENV / COSE_Sign1 / DSSE / keyless material as extra audit evidence rather than D-NAMECERT admission authority (`namecert-signature-profile-v0.md`).
- **CH-NAMECERT v0 keeps bundle metadata observational in Phase 1**: `bundle_id` and `created_ms` are signed provenance only, do not define replacement/freshness semantics, and cannot justify candidate choice, supersession, or detach by themselves (`namecert-metadata-boundary-v0.md`).
- **CH-NAMECERT v0 declines implied onward delegation in Phase 1**: a delegated subject may exercise an admitted grant, but may not use that grant as proof that it can issue further CH-NAMECERT delegations unless it is independently authorized or a future explicit propagation seam is added (`namecert-redelegation-boundary-v0.md`).
- **CH-NAMECERT v0 uses one duplicate-free statement normal form in Phase 1**: admitted `bindings` / `delegations` arrays are strictly sorted by canonical element bytes, exact duplicates reject, and statement order/repetition never become first-match/last-match or weighted authority semantics (`namecert-normal-form-boundary-v0.md`).
- **CH-NAMECERT v0 is not bearer-capability transport**: admitted Phase 1 bundles must not carry raw CH-SREF / CH-CAPX / restore/import material, `TargetRef.kind = "sturdyref"` is reserved+rejected, and `proxy` targets remain local descriptor-only rather than a hidden import path (`namecert-bearer-boundary-v0.md`).
- `Constraint.kind = "caveat"` remains **evaluator-local and fail-closed** in v0; CH-NAMECERT does not standardize a portable policy/caveat language on the core seam.
- Because authority-bearing labels are ASCII-only in Phase 1, CH-NAMECERT v0 does **not** import confusable skeletons, mixed-script checks, or a versioned Unicode-security dataset into the seam (`namecert-string-profile-v0.md`).
- Those admitted labels are also **single opaque label atoms** after validation: Phase 1 defines no path hierarchy, wildcard, prefix/suffix, or multi-segment query grammar on `Binding.name` / `Delegation.role`; punctuation stays ordinary bytes rather than authority-bearing structure (`namecert-label-atom-boundary-v0.md`).
- CH-NAMECERT v0 does **not** standardize serial numbers, CRL distribution points, OCSP endpoints, or a portable revocation/status artifact; any revocation/replacement input remains evaluator-local under explicit policy rather than ambient discovery (`namecert-revocation-boundary-v0.md`).
- If CH-NAMECERT affects privileged configuration, ensure the relevant digest is recorded in CH-LOG and/or listed in CH-BOOT `artifacts`.
- Any Phase 1 authority-bearing projection into local namespace state must stay on the target seam: accepted results land only through explicit `view.attach` / `view.detach` on concrete `view.slot` keys, and the target-seam proposal/receipts retain source `digest(CH-NAMECERT v0)` evidence rather than hidden resolver cache state (`namecert-projection-boundary-v0.md`).
- When multiple admissible candidates exist for a queried name/role path, Phase 1 evaluation is **set-valued**; CH-NAMECERT v0 standardizes no default ranking or winner-selection rule, and any live binding must identify the exact chosen candidate rather than a resolver guess (`namecert-selection-boundary-v0.md`).
- Cycles, duplicates, or incomplete chains do not authorize ambient chase: evaluators must handle revisits deterministically and may fail closed on explicit search/fuel bounds rather than widening authority or continuing in the background (`namecert-search-boundary-v0.md`).
- Cross-cluster replication of `object_family = namecert` moves **signed bundle evidence**, not active resolver authority: replicated bundles must not auto-install bindings, auto-prefer arrivals, or become a privileged/global resolver (`namecert-replication-boundary-v0.md`).
