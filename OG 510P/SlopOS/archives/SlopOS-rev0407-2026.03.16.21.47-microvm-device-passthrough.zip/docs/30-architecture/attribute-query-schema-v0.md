# CH-ATTRQ v0: Attribute query predicates (optional)

Purpose: standardize a **small, bounded** query format for D-ATTRFS so that multiple shells/index services can interoperate on:
- what a query *means*,
- how it is validated (closed, deterministic), and
- how it is hashed/signed (canonical bytes).

CH-ATTRQ is designed to be:

Phase-1 posture note: query evaluation is **snapshot-first** and **handle-returning** in v0; saved-query persistence stays shell-owned rather than app-visible inventory or background watch state (see `attrfs-posture-v0.md`).

CH-ATTRQ is designed to be:
- **capability-scoped** (queries run against an explicit view),
- **typed** when a CH-ATTR schema is available,
- **non-Turing-complete** and cost-bounded.

## Canonical encoding
CH-ATTRQ follows D-ENC/RFC-0001 rules.

**Normative bytes:** canonical CBOR (RFC 8949) suitable for hashing/signing.
- reject unknown keys (closed world)
- no floats

**Optional authoring form:** tools MAY accept JSON for authoring, but MUST normalize deterministically and transcode to canonical CBOR before hashing/signing.

## Data model (v0)
Top-level object:
- `version`: `"0"`
- `namespace`: string identifying the attribute family (e.g. `"media"`, `"mail"`, `"tags"`).
- `schema_digest` (optional): digest string of a CH-ATTR declaration for this namespace. If present, validators MUST type-check attribute keys and literals strictly.
- `expr`: an expression node.

### Expression nodes
Nodes are CBOR maps with an `op` field and operator-specific fields.

Common constraints (validation):
- max node count (recommended default: 128)
- max `in` list length (recommended default: 32)
- max string length for keys/literals (recommended default: 256 bytes)

#### Operators (closed set)
Boolean composition:
- `op = "and"` with `args: [expr, ...]` (len >= 2)
- `op = "or"` with `args: [expr, ...]` (len >= 2)
- `op = "not"` with `arg: expr`

Presence:
- `op = "has"` with `key: "<attr-key>"`

Comparisons:
- `op = "eq"|"ne"|"lt"|"le"|"gt"|"ge"` with:
  - `key: "<attr-key>"`
  - `lit: <literal>`

Set membership:
- `op = "in"` with:
  - `key: "<attr-key>"`
  - `lits: [<literal>, ...]` (bounded)

### Literals
A literal is one of:
- CBOR text string
- CBOR byte string
- CBOR integer (signed)
- CBOR boolean

Typing notes:
- If `schema_digest` is present, validators MUST enforce that `key` exists in the CH-ATTR declaration and that literals match the declared `type`.
- If `schema_digest` is absent, validators MUST apply a conservative profile:
  - allow only `eq/ne/has/in` (no ordering comparisons)
  - treat type mismatches as reject (no guessing/coercions)

## Minimal validation rules
- reject unknown top-level fields and unknown operator fields
- `version` must be `"0"`
- `namespace` must be non-empty
- `op` must be from the closed set
- enforce bounds (node count, list lengths, string lengths)
- if `schema_digest` is present:
  - `key` must exist in the referenced CH-ATTR schema
  - literal types must match schema types (time_ns treated as integer)

## Notes
- CH-ATTRQ only specifies query bytes and validation. It does not define storage layouts or UI representations.
- Live queries are an execution profile, not part of CH-ATTRQ. See RFC-0100. Phase 1 keeps them optional, bounded, and non-persistent by default (`attrfs-posture-v0.md`).
- Phase 1 exposes no app-visible saved-query inventory; durable smart folders are shell-owned manifests bound to an explicit view (`attrfs-posture-v0.md`).
- For quarantined content, Phase 1 also forbids **hidden lineage joins** or source-preferred result substitution: if content-derived semantics live on a separate derived artifact, CH-ATTRQ evaluation matches that artifact rather than resurfacing the risky source object via `origin.parent_digest` or similar breadcrumbs (`quarantined-derived-match-boundary-v0.md`).
- Companion **result-rendering boundary**: even when CH-ATTRQ returns the exact quarantined or derived artifact that matched, result rendering remains **metadata-safe only**; ambient snippets, thumbnails, preview panes, or hover previews from quarantined bytes stay out of scope unless a separate explicit review/open step is taken (`quarantined-result-preview-boundary-v0.md`).

## Links
- D-ATTRFS (decision)
- RFC-0100
- `attrfs-posture-v0.md`
