# D-MICROVM posture v0 (`ext.microvm`: virtio-first, no legacy, no hidden host channels)

Purpose: pin a **small, implementable** v0 meaning for the `ext.microvm` profile extension.

This is an exit-surface posture (D-XS): it constrains what the system will emulate/expose so the virtualization/device-model TCB stays reviewable.

## Posture (v0)

When `cfg.feature_flags` includes `ext.microvm`, the microVM profile is:

1) **Virtio-first and declared**
   - The guest-visible device model is a **declared, closed set** (no “implicit hardware”).
   - Unknown/unlisted devices MUST fail closed (ties to PO-XS-CLOSESET).
   - Transport choice is allowed to be platform-dependent (virtio-mmio vs virtio-pci), but **the device *types* remain virtio**.

2) **No legacy emulation**
   - v0 explicitly does **not** include legacy chipset/device emulation (ACPI tables, random historical PCI devices, BIOS-era glue).
   - If the platform uses PCI for virtio transport, v0 still treats “PCI support” as *virtio transport only* (no general PCI(e) ecosystem).

3) **No hidden host channels**
   - The microVM profile MUST NOT create ambient channels “because virtualization”: no implicit host filesystem, no implicit host network, no implicit host time.
   - Any host-mediated effects flow through existing portal/receipt seams under lane gates (e.g., `portal.net`, `portal.file`, `portal.clock`).

4) **Not a compatibility escape hatch (sealed-compat remains sealed)**
   - Running foreign OSes/runtimes in a microVM is still “foreign code in a box”.
   - Phase 1’s **no second compat runtime family** posture (D-RUMPK) applies: we do **not** adopt “just run Linux guests” as a hidden POSIX/legacy path in Phase 1.
   - If we later want “foreign guests as a product”, we must do it explicitly as sealed compatibility (D-FCELL + new negative tests), not as an ambient microVM side effect.

## Phase 1 non-goals (explicitly deferred)

- No standardized exhaustive device list in v0 (only posture direction + exclusion set).
- No vCPU hotplug / CPU online-offline / guest CPU-topology mutation / NIC hotplug / attach-detach / guest link-state mutation / disk hotplug / hot-remove / media insert-eject / tray-status plane / interactive serial-or-console host-input / console-monitor multiplex / runtime console-backend rebind / MMDS / IMDS / link-local metadata endpoint / fw_cfg key namespace / config-drive or cloud-init datasource contract / `virtio-rng` / CPU-HWRNG entropy-source-or-quality-status plane / guest TPM-vTPM / PCR-NV / sealing-attestation-document plane / guest VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane / vsock / fs sharing / balloon / virtio-mem / ACPI memory hotplug / PCI hotplug without an RFC + D-XS budget update.
- No “foreign guest as the default compatibility story” (requires explicit sealed-compat design).

## Wiring

- Decision surface: `decision-map.md` (D-MICROVM, D-XS).
- Feature flag surface: `docs/30-architecture/config-toggle-registry.md` (`cfg.feature_flags` includes `ext.microvm`).
- Related postures:
  - `rumpk-selection-posture-v0.md` (D-RUMPK; “no second runtime family” in Phase 1)
  - `host-guest-channel-posture-v0.md` (host↔guest channels; v0 forbids virtio-vsock/virtio-fs/9p as ambient interop)
  - `microvm-memory-topology-posture-v0.md` (guest-visible RAM size/topology is fixed at admission; no portable balloon / virtio-mem / ACPI memory-hotplug control/status plane in Phase 1)
  - `microvm-cpu-topology-posture-v0.md` (guest-visible vCPU count/topology is fixed at admission; no portable vCPU hotplug / CPU online-offline / hotpluggable-slot control/status plane in Phase 1)
  - `microvm-network-topology-posture-v0.md` (guest-visible NIC inventory/topology is fixed at admission; no portable NIC hotplug / attach-detach / link-state / interface-status control plane in Phase 1)
  - `microvm-block-topology-posture-v0.md` (guest-visible block-device inventory/topology is fixed at admission; no portable disk hotplug / hot-remove / media-insert-eject / tray-or-device-status control plane in Phase 1)
  - `microvm-console-channel-posture-v0.md` (guest-visible serial/console presence + directionality are fixed at admission; no portable interactive input, no console/monitor multiplex, and no runtime backend-rebind/status plane in Phase 1)
  - `microvm-bootstrap-metadata-posture-v0.md` (Phase 1 exposes no ambient guest-readable metadata/bootstrap channel; no portable MMDS / IMDS / fw_cfg / config-drive / cloud-init datasource plane, and bootstrap authority rides on reviewed boot artifacts or explicit post-boot seams)
  - `microvm-entropy-surface-posture-v0.md` (Phase 1 exposes no portable ambient guest-visible entropy device/source contract; no portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality-status plane, owner-local boot seeding stays implementation-local, and post-init entropy meaning stays on explicit D-NONDET seams)
  - `microvm-tpm-surface-posture-v0.md` (Phase 1 exposes no portable ambient guest-visible TPM/vTPM contract; no portable TPM2 command-status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane, owner-local TPM enablement/backend choice stays implementation-local, and attestation/key-sealing meaning stays on explicit D-ATTEST and D-CRYPTOSVC seams)
  - `microvm-device-passthrough-posture-v0.md` (Phase 1 exposes no portable ambient guest-visible device-passthrough contract; no portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane, owner-local host binding/attachment details stay implementation-local, and DMA-class device authority stays on explicit D-DMA and D-IOLEASE seams)
  - `microvm-generation-witness-posture-v0.md` (guest-visible clone/restore detection stays explicit and read-only; no host-agent control plane)
  - `microvm-clock-disruption-posture-v0.md` (guest-visible precision-time disruption stays explicit and separate from clone identity repair; no hidden time-authority plane)
  - `microvm-attestation-reacquire-posture-v0.md` (generation change invalidates freshness-bound attestation exports and attestation-gated release sessions; no hidden quote-cache continuity plane)
  - `microvm-attestation-scope-posture-v0.md` (a fresh post-restore attestation export remains boot/provenance-bound; exact warm-start leaf identity stays on separate lineage/admission evidence rather than becoming a hidden resumed-state claim)
  - `microvm-resume-admission-evidence-posture-v0.md` (if exact resumed leaf identity matters, it stays on owner-local admission/provenance evidence rather than a guest-visible leaf-id API or new CH-ATTEST claim)
  - `microvm-template-snapshot-cut-posture-v0.md` (reusable template snapshots stay secret-clean and authority-cold; post-secret/post-session checkpoints are not fan-out bases)
  - `microvm-template-lineage-posture-v0.md` (reusable template identity stays parent-bound and leaf-resumable; internal diff/base layering does not become a portable workflow surface)
  - `microvm-template-resume-class-posture-v0.md` (each reusable template leaf resumes only inside one exact reviewed class; fleet heterogeneity is normalized before the cut instead of negotiated at restore time)
  - `microvm-restore-repair-barrier-posture-v0.md` (resumed reusable leaves complete clone-sensitive repair before any externally visible action or readiness claim; no portable checkpoint-hook/control plane is added)
  - `microvm-template-distribution-posture-v0.md` (reusable warm-start leaves and owner-local recovery checkpoints stay owner-local admission accelerators rather than a portable/public artifact class; distribute cold parent lineage and cut/admit warm leaves locally)
  - `microvm-template-availability-posture-v0.md` (reusable warm-start leaves remain owner-local, semantically optional accelerators; owners may evict/regenerate them locally without changing portable deployment identity, and Phase 1 adds no public warm-cache hit/miss or `Pending` / `Active` / `Inactive` lifecycle plane)
  - `dma-posture-v0.md` (D-DMA; physical DMA containment remains host-enforced)
- Mechanism note: `virtio-iommu-mechanism-note.md` (guest-visible seam; optional; declared/killable).
- CI drift gate: `tools/check_microvm_profile_posture.py` (EVID-2026-215).

## References

- REF-FIRECRACKER-NSDI20
- REF-FIRECRACKER-KERNEL-POLICY
- REF-VIRTIO-1.3
- REF-QEMU-MICROVM
- REF-KVM-API
- REF-CHYP-DEVICE-MODEL
- REF-CHYP-IOMMU
