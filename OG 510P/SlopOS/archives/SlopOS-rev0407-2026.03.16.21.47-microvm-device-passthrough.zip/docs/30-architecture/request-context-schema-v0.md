# CH-REQCTX v0: request context descriptor (optional)

Purpose: a bounded, redaction-safe descriptor capturing **request intent** (deadline/correlation/budget links) so cancellation/timeout behavior is explainable and transcript-friendly.

Non-goal: carrying authority. CH-REQCTX contains **no capabilities** and must not be treated as authorization evidence.
Runtime/interoperability posture: see `reqctx-posture-v0.md` for sticky propagation, absolute-deadline, and no-baggage/no-detach semantics.

Used by:
- CH-LOG entries (correlate “why did this cancel/timeout?”)
- optional CH-CAPRPC v1 `ctx_digest` correlation hook
- offline triage/debug tooling

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown enum variants and unknown top-level keys reject deterministically.

## Descriptor

```text
CH-REQCTX-v0 {
  schema: "CH-REQCTX";
  version: 0;

  # Correlation
  ctx_id: u64;                 # caller-chosen stable id within a session/workflow
  parent_ctx_digest?: bytes32; # optional digest link to the parent CH-REQCTX (if any)

  # Deadline intent (optional)
  monotonic_deadline_ms?: u64; # advisory intent; enforcement uses explicit ClockCap / budgets

  # Trace correlation (optional; identifiers only)
  trace?: {
    trace_id: bytes16;
    span_id: bytes8;
    flags?: u8;                # optional; e.g., sampling flags
  };

  # Optional links to related descriptor digests (audit-only)
  budget_desc_digests?: list<bytes32>;  # digests of CH-BUDGET and/or CH-METER descriptors (if used)
  tcap_desc_digests?: list<bytes32>;    # digests of CH-TCAP descriptors (if used)

  # Bounded informational tags (optional; not a general KV store)
  tags?: list<{ k: tstr; v: tstr }>;
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `ctx_id` must be present.
- `parent_ctx_digest` (if present) must be 32 bytes.
- `monotonic_deadline_ms` (if present) must be non-zero and ≤ 2^63-1.
- `trace.trace_id` is exactly 16 bytes; `trace.span_id` exactly 8 bytes.
- `budget_desc_digests` length ≤ 8; `tcap_desc_digests` length ≤ 8.
- `tags` length ≤ 16; each `k`/`v` length ≤ 64; keys must contain only letters, digits, and `._-` (bounded; no spaces).

## Security notes
- CH-REQCTX is **non-authoritative**: it does not grant rights and must not be used as an authorization input.
- Tags are bounded and intended for diagnostics correlation only; avoid embedding user secrets.
- Deadline is **intent**: enforcement uses explicit time/budget authorities (D-NONDET, D-BUDGET, D-TCAP).

Budget references:
- `budget_desc_digests` is intentionally an **untyped** digest list.
- Any consumer that treats the list as “required sponsorship” MUST be type-strict and non-ambient: only descriptors that resolve and validate as **CH-BUDGET v0** satisfy the requirement; locators are hints only and MUST NOT be dereferenced by privileged code (see `reqctx-budget-ref-posture-v0.md`, `reqctx-sponsorship-evolution-boundary-v0.md`, and `artifact-resolution-posture-v0.md`).

Temporal-capability references:
- `tcap_desc_digests` is intentionally an **untyped** digest list.
- Any consumer that treats the list as “required temporal sponsorship” MUST be type-strict and non-ambient: only descriptors that resolve and validate as **CH-TCAP v0** satisfy the requirement; locators are hints only and MUST NOT be dereferenced by privileged code (see `reqctx-tcap-ref-posture-v0.md`, `reqctx-sponsorship-evolution-boundary-v0.md`, and `artifact-resolution-posture-v0.md`).
