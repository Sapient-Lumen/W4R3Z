# CH-EFFCON v0: Effect contract descriptor (workflows; capability-safe automation)

Purpose: make “workflow glue” (shell scripts, CI jobs, admin runbooks) *least-authority by default* by letting a runner validate and enforce an explicit **effect contract**.

An effect contract is a **non-authoritative** descriptor that:
- binds an automation step to a declared authority bundle (CH-WALLET core; binding only, never authority import),
- optionally binds a voluntary self-restriction mask (CH-PLEDGE),
- pins the intended high-level effect families (closed enum),
- and gives deterministic validators enough structure to reject ambient/implicit effects.

This is an ecosystem seam for D-CAPSHELL: **LLMs propose; validators execute**.

References: REF-SHILL-OSDI14, REF-PLASH, REF-CAPSICUM, REF-UDAC-SP12.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- total decoding + fail-closed validation
- bounded sizes and closed enums (no scripting language)
- **no bearer secrets** and **no raw capabilities** in the descriptor
- no ambient references (paths/env/implicit network) as “permission grants”
- hashable and stable for binding into CH-ACP / transcripts / receipts

## Data model (conceptual)

CH-EFFCON v0 := {
  v: 0,

  contract_id: bstr,            ; random id (>=128 bits) for local indexing / replay de-dup correlation
  issued_at?: uint,             ; optional (profile-defined time base)

  subject: {
    component_id: tstr,         ; non-authoritative CH-COMP identity string
    instance_id?: bstr,
  },

  ; Bind to the intended authority bundle.
  ; NOTE: this is a digest of the *normalized* wallet core (see CH-WALLET).
  wallet_core_digest: bstr,     ; digest(wallet_core) ; correlation/binding only; never authority import

  ; Optional: bind to a voluntary self-restriction mask.
  pledge_digest?: bstr,         ; digest(CH-PLEDGE v0 canonical bytes)

  ; The allowed high-level effect families (closed enum).
  ; These are NOT authority; they are a validator allowlist for which *channels*
  ; the runner may invoke using already-held caps/leases/portals.
  effects: [
    {
      kind: tstr,               ; closed enum (v0) below
      selector?: tstr,          ; bounded, kind-specific hint (non-authoritative)
    }
  ],

  ; Optional: expected output artifact references (digests only).
  ; Used for receipts/transcripts and CI drift gates.
  outputs?: [
    {
      schema: tstr,             ; allowlisted CH-* schema name (e.g., "CH-AREF v0")
      digest: bstr,             ; digest of the referenced descriptor
      note?: tstr,
    }
  ],

  meta?: { * tstr => any }      ; optional; MUST be ignored unless allowlisted
}

### Effect kinds (v0; closed enum)

Effect kinds are intentionally coarse to keep the seam stable. Unknown kinds MUST be rejected.

- `compute` — no privileged effects beyond CPU/memory within the domain
- `caprpc.call` — CapRPC calls to already-held endpoints (no ambient resolve)
- `view.resolve` — resolve names in already-held view objects
- `view.mutate` — bind/mount/unmount in already-held view objects

- `portal.file` — mediated open/save/export/share workflows
- `portal.uri` — mediated OpenURI workflows (manual-only, scheme-gated, launch-only in v0; no app-visible handler inventory/probing)
- `portal.print` — mediated print workflows (manual-only, render-first, shell-spooled in v0; no app-visible printer inventory/queue authority)
- `portal.device` — mediated device pick/lease workflows
- `portal.location` — mediated location workflows
- `portal.secret` — mediated secret-seed workflows
- `portal.clock` — mediated clock handle/lease workflows (D-NONDET; coarse by default); D-TIMEPROOF timeproof sampling is separately killable via `cfg.params.lane.timeproof`
- `portal.entropy` — mediated entropy handle/lease workflows (D-NONDET; seed-by-default)
- `portal.net` — mediated outbound network lease workflows (profile-gated)
- `portal.capture` — mediated capture workflows (profile-gated)
- `portal.xfer` — mediated transfer workflows (profile-gated)
- `portal.attn` — mediated notifications/attention prompts (profile-gated; D-ATTN)
- `portal.jobs` — mediated background job workflows
- `portal.background` — mediated background/autostart workflows (profile-gated)
- `portal.inhibit` — mediated inhibit workflows
- `portal.a11y` — mediated accessibility/automation workflows (profile-gated)

Notes:
- The `portal.*` kinds are aligned with CH-PLEDGE’s portal promise tokens and the portal family registry.
- `selector` is informational only (e.g., a route port hint like `"workstation"`); validators MUST ignore unknown selectors.

Lane gates:
- All `portal.*` effect kinds MUST be **killable** via CH-CFG lane toggles.
- For any `portal.<family>` listed in `effects[*].kind`, the runner MUST require the corresponding portal lane toggle (see mapping below) to be enabled.
  - Missing/unknown toggle values MUST be treated as `false` (fail closed).
  - If disabled, execution deterministically rejects at the privileged-effect boundary and emits a transcript-visible receipt/log event (PO-LANE-KILL).

v0 mapping (complete, closed):
- `portal.file` → `cfg.params.lane.portal.file`
- `portal.uri` → `cfg.params.lane.portal.uri`
- `portal.print` → `cfg.params.lane.portal.print`
- `portal.device` → `cfg.params.lane.portal.device`
- `portal.net` → `cfg.params.lane.portal.net`
- `portal.location` → `cfg.params.lane.portal.location`
- `portal.secret` → `cfg.params.lane.portal.secret`
- `portal.clock` → `cfg.params.lane.portal.clock`
- `portal.entropy` → `cfg.params.lane.portal.entropy`
- `portal.capture` → `cfg.params.lane.portal.capture`
- `portal.xfer` → `cfg.params.lane.portal.xfer`
- `portal.attn` → `cfg.params.lane.portal.attn`
- `portal.jobs` → `cfg.params.lane.portal.jobs`
- `portal.background` → `cfg.params.lane.portal.background`
- `portal.inhibit` → `cfg.params.lane.portal.inhibit`
- `portal.a11y` → `cfg.params.lane.portal.a11y`

Portal lane toggle keys are pinned in `docs/30-architecture/config-toggle-registry.md` and are drift-gated by tooling.

Profile guidance (non-normative): workstation profiles often enable `portal.file`/`portal.uri`/`portal.print`/`portal.xfer`/`portal.jobs`; hardened micro-VM / embedded profiles often default most portal lanes off and require explicit enablement.

## Workflow-bound descriptor allowlist (v0)

CH-ARGV v0 and CH-ENV v0 can carry `desc_schema` + `desc_digest` references so a capshell runner can bind **already-held** handles into a child process without using ambient namespaces.

This is a common drift seam: if “what descriptor schemas are allowed” is left purely profile-defined, LLM edits and wrapper implementations tend to diverge and accidentally reintroduce ambient acquisition paths (e.g., treating an unrecognized schema name as a permission grant).

v0 rule (tight, high-leverage):
- The runner MUST treat the set of workflow-bindable descriptor schemas as **closed-world** and **effect-bound**.
- For a given `capshell.exec`, any descriptor reference appearing in CH-ARGV/CH-ENV MUST be justified by the bound CH-EFFCON `effects[*].kind` list.
- If a descriptor schema implies a portal/effect family not present in the active effect contract, the runner MUST fail closed and emit CH-DENY with `deny_code = effcon-violation` bound to `reason.ref_digest = effcon_digest`.

Seed mapping (v0): effect kind → workflow-bindable descriptor schema(s)

| Effect kind (CH-EFFCON `effects[*].kind`) | Allowed `desc_schema` values for CH-ARGV/CH-ENV | Notes |
|---|---|---|
| `compute` | — | pure compute provides no bindable authority by itself |
| `caprpc.call` | — | endpoints are passed out-of-band; CH-ARGV/CH-ENV must not smuggle endpoint ids |
| `view.resolve` | — | view handles are not bound via argv/env in v0 |
| `view.mutate` | — | view mutation is mediated by already-held view caps, not argv/env tokens |
| `portal.file` | `CH-DOCREF v0` | durable document/file handles (no host paths) |
| `portal.uri` | — | “open a URI” is a portal workflow, not a handle passed to children; Phase 1 keeps OpenURI launch-only and out of the handler-inventory business |
| `portal.print` | — | printing is mediated; no child-handle binding in v0 |
| `portal.device` | `CH-IOLEASE v0` | device/IO leases issued by device portal (D-IOLEASE) |
| `portal.location` | `CH-LOCLEASE v0` | location leases issued by location portal (D-LOCLEASE) |
| `portal.secret` | `CH-APPSECRET v0` | per-app secret seed descriptor (no secret bytes in CH-ENV) |
| `portal.clock` | `CH-CLOCK v0` | clock handle/lease descriptors (no ambient time; prefer coarse by default) |
| `portal.entropy` | `CH-ENTROPY v0` | entropy handle/lease descriptors (seed-by-default; deterministic is explicit) |
| `portal.net` | `CH-NETLEASE v0` | network leases issued by network portal (D-NETLEASE) |
| `portal.capture` | `CH-CAPTURE v0` | capture session descriptor (actual media via caps) |
| `portal.xfer` | `CH-XFER v0` | transfer descriptor (payload via caps) |
| `portal.attn` | — | notifications/actions are mediated; no argv/env descriptor binding in v0 |
| `portal.jobs` | `CH-JOBREQ v0` | job request descriptors (optional; profile-defined binding) |
| `portal.background` | `CH-BGREQ v0` | background/autostart request descriptors (optional); portal returns CH-BGLEASE receipts |
| `portal.inhibit` | `CH-INHIBITLEASE v0` | inhibit lease descriptors (optional) |
| `portal.a11y` | `CH-UIAUT v0` | UI automation lease descriptors (optional) |

Notes:
- This table does **not** grant authority: it only constrains what schema names may appear as descriptor references in argv/env token lists.
- Profiles MAY further restrict (subset) the allowed schemas (never widen beyond the table without a CH-EFFCON update + review).
- v0 keeps argv/env binding focused on portal-issued descriptors (including optional D-NONDET Clock/Entropy handles). Extend this table for any future additions rather than introducing a parallel allowlist.

## Validation rules (minimum)

An effect contract validator MUST be total and fail closed (PO-EFFCON-VALIDATE):
1) `v == 0`.
2) `contract_id` is bounded; `subject.component_id` is bounded.
3) `wallet_core_digest` length matches profile hash.
4) `pledge_digest` (if present) length matches profile hash.
5) `effects` is non-empty, length-bounded, and each `kind` is from the closed enum.
6) `outputs` (if present) length-bounded; each `schema` is allowlisted and each `digest` length matches profile hash.
7) Unknown keys reject (or are rejected by canonical CBOR decode).

## Semantics notes (binding to execution)

The effect contract is a **veto-only** structure:
- It never grants authority (I-EFFCON-1). It only restricts which effect families a runner may invoke.
- Enforcement is at the runner’s privileged-effect boundary (I-EFFCON-2): every portal invocation / view mutation / CapRPC call must be checked against the active contract.

Binding points:
- `capshell.exec` proposals SHOULD carry `exec_pack_digest = digest(CH-EXECPACK v2)`, and the referenced pack binds `reqctx_digest = digest(CH-REQCTX v1)` and `effcon_digest = digest(CH-EFFCON v0)`.
- If the runner models child environments explicitly (D-CAPSHELL strict profiles), the proposal SHOULD also bind `env_digest = digest(CH-ENV v0)` so workflow execution does not inherit ambient host environments.
- Transcripts/receipts SHOULD record `exec_pack_digest` (and/or `effcon_digest`) as non-authoritative correlation hooks, alongside conflict_key/order digests when D-COMMUTE is in scope.

Security notes:
- Contract content may still reveal intent; exports should respect C-OBS-1 redaction policy.
- Prefer digests and allowlists over raw user text.
