# CH-REQCTX v1: request context descriptor (optional)

Purpose: same as CH-REQCTX v0, with an optional hook to reference a bounded **call chain** descriptor.

Used by:
- CapRPC runtimes (via CH-CAPRPC v1 `ctx_digest`, optional).
- IF-ACP / CH-ACP proposals as `meta.reqctx_digest` (required; non-authoritative; veto-only narrowing).

Additions vs v0:
- `call_chain_digest?: bytes32` referencing **CH-CALLCHAIN v0**.

Non-goal: carrying authority. CH-REQCTX contains **no capabilities** and must not be treated as authorization evidence.
Runtime/interoperability posture: see `reqctx-posture-v0.md` for sticky propagation, absolute-deadline, and no-baggage/no-detach semantics; see `bracket-posture-v0.md` for the optional borrowed-mode / deny-only call-chain posture attached to `call_chain_digest`.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown enum variants and unknown top-level keys reject deterministically.

## Descriptor

```text
CH-REQCTX-v1 {
  schema: "CH-REQCTX";
  version: 1;

  # Correlation
  ctx_id: u64;
  parent_ctx_digest?: bytes32;

  # Deadline intent (optional)
  monotonic_deadline_ms?: u64;

  # Trace correlation (optional)
  trace?: {
    trace_id: bytes16;
    span_id: bytes8;
    flags?: u8;
  };

  # Optional links to related descriptor digests (audit-only)
  budget_desc_digests?: list<bytes32>;
  tcap_desc_digests?: list<bytes32>;

  # Optional call-chain reference (audit/deny-only)
  call_chain_digest?: bytes32;   # digest(CH-CALLCHAIN v0)

  # Bounded informational tags (optional)
  tags?: list<{ k: tstr; v: tstr }>;
}
```

## Validation rules (summary)
All CH-REQCTX v0 rules apply, plus:
- `call_chain_digest` (if present) must be 32 bytes.

Bounds:
- `budget_desc_digests` length ≤ 8; `tcap_desc_digests` length ≤ 8.
- `tags` length ≤ 16; each `k`/`v` length ≤ 64; keys must contain only letters, digits, and `._-`.

## Security notes
- CH-REQCTX is **non-authoritative**: it does not grant rights.
- `call_chain_digest` is for audit/correlation and *veto-only* decisions.
  - It must not be used to grant authority.
  - It may be used to deny or narrow behavior.

Budget references:
- `budget_desc_digests` is intentionally an **untyped** digest list.
- Any consumer that treats the list as “required sponsorship” MUST be type-strict and non-ambient: only descriptors that resolve and validate as **CH-BUDGET v0** satisfy the requirement; locators are hints only and MUST NOT be dereferenced by privileged code (see `reqctx-budget-ref-posture-v0.md`, `reqctx-sponsorship-evolution-boundary-v0.md`, and `artifact-resolution-posture-v0.md`).

Temporal-capability references:
- `tcap_desc_digests` is intentionally an **untyped** digest list.
- Any consumer that treats the list as “required temporal sponsorship” MUST be type-strict and non-ambient: only descriptors that resolve and validate as **CH-TCAP v0** satisfy the requirement; locators are hints only and MUST NOT be dereferenced by privileged code (see `reqctx-tcap-ref-posture-v0.md`, `reqctx-sponsorship-evolution-boundary-v0.md`, and `artifact-resolution-posture-v0.md`).
