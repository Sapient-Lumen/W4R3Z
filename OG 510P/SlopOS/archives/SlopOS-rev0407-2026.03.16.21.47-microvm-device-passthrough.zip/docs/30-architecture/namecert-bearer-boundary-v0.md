# D-NAMECERT bearer boundary v0 (no raw bearer refs in bundles; capability import stays explicit)

Purpose: narrow the **capability-bearing target** seam of **D-NAMECERT** so local naming bundles cannot
quietly smuggle raw bearer authority through what is otherwise an evidence-first, replication-safe,
digest-first archive surface.

This boundary attaches to already-reviewed seams rather than inventing a new one. **CH-NAMECERT** may
help label principals or already-authorized local proxy/service objects, but **portable capability-bearing
material stays on D-CAPX / CH-SREF**. The specific Phase 1 question closed here is: **may CH-NAMECERT
itself carry raw sturdyrefs, raw import envelopes, or other bearer restore/import material?**

Phase 1 makes a small, hard choice: **no**. Raw bearer/import material does not belong inside
**CH-NAMECERT v0** admissions. Capability-bearing transfer remains an explicit restore/import event on its
own seam. Capability-bearing transfer remains an explicit restore/import event on its own seam.

## Boundary (v0)

1) **CH-NAMECERT is naming evidence, not bearer-capability transport**
   - Admitted Phase 1 **CH-NAMECERT v0** bundles MUST NOT embed raw **CH-SREF** bytes, raw **CH-CAPX** bytes, raw kernel/user capability identifiers, restore tokens, or any other bearer/import material whose mere possession is enough to attempt authority restoration/import. In plain terms: raw CH-SREF bytes, raw CH-CAPX bytes, raw kernel/user capability identifiers, and similar restore/import secrets are all out of scope here.
   - If a deployment needs to move capability-bearing material, that movement must occur through the explicit **D-CAPX / CH-SREF** handoff seam rather than piggybacking on local naming evidence.
   - This keeps D-NAMECERT aligned with the archive-wide digest-first / no-ambient-authority stance.

2) **`TargetRef.kind = "sturdyref"` is structurally reserved but rejected in Phase 1 admissions**
   - `CH-NAMECERT v0` keeps the `TargetRef.kind` token only so the archive does not accidentally pretend this question was never considered.
   - In Phase 1, however, validators MUST reject any admitted authority-bearing bundle that uses **`TargetRef.kind = "sturdyref"`**.
   - Any future descriptor-only durable-reference form must land as its own reviewed seam or profile, not as an accidental widening of **CH-NAMECERT v0**.

3) **`TargetRef.kind = "proxy"` is local descriptor-only, not an import path**
   - A `proxy` target may identify an already-existing local proxy/service object or local descriptor understood under explicit policy.
   - It MUST NOT be interpreted as permission to restore/import remote authority, fetch a bearer token, or auto-create a new live proxy out of bundle contents.
   - Capability import therefore stays on explicit D-CAPX / CH-SREF restore/import routes, while D-NAMECERT remains a labeling/projection aid.

4) **Replication and routine surfaces stay non-bearer**
   - Because raw bearer/import material is forbidden, `object_family = namecert` replication remains **signed bundle evidence only**, not a side channel for copying portable authority across clusters.
   - Ordinary receipts/logs/workflow artifacts continue to carry **`digest(CH-NAMECERT v0)`** and (where relevant) **`digest(CH-SREF v0)`** / **`digest(CH-CAPX v0)`** pointers rather than raw secrets.
   - This keeps Hybrid RC3 replication honest and prevents audit/discovery surfaces from quietly becoming an authority bus.

5) **Authority-bearing results still land only on explicit target seams**
   - If a local name ultimately points at authority in Phase 1, that authority must already exist as an explicit local principal/proxy/service object or arrive through an explicit **CH-SREF / CH-CAPX** restore/import event.
   - Any live namespace mutation still lands only as explicit D-NS `view.attach` / `view.detach` on a concrete `view.slot`.
   - D-NAMECERT therefore does not become a stealth capability wallet, restore protocol, or secret transport format.

6) **This boundary keeps all four product shapes honest**
   - **Secure workstation (A):** prevents secret-bearing sturdyrefs from leaking into routine name bundles, logs, or sync flows.
   - **Cloud micro-VM substrate (B):** prevents replicated naming evidence from turning into replicated bearer authority.
   - **Embedded / separation-kernel-ish appliance (C):** avoids importing a hidden capability-restore format into a small local naming seam.
   - **Agent/automation OS (D):** gives LLM-driven tooling a simple rule — name bundles are safe-ish evidence objects; bearer/import material always travels on sharper explicit seams.

## Phase 1 non-goals (explicitly deferred)

- Embedding raw **CH-SREF** or **CH-CAPX** bytes inside admitted **CH-NAMECERT v0** bundles.
- Treating `TargetRef.kind = "sturdyref"` as an active restore path in v0.
- A generic “resolve this local name and import whatever secret it points at” workflow.
- Replication of portable bearer authority via `object_family = namecert`.
- Reusing D-NAMECERT as a capability wallet / share bus / export envelope.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema: `namecert-schema-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- Replication boundary: `namecert-replication-boundary-v0.md`
- Adjacent sharp seams:
  - `capx-posture-v0.md`
  - `sturdyref-posture-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-030**)

CI drift gate:
- `tools/check_namecert_bearer_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **no raw bearer/import material / sturdyref-rejected / proxy-descriptor-only** stance, or drops its assurance / REF wiring.

## References

- REF-TAHOE-LAFS.
- REF-W3C-CAPURLS.
- REF-CAPTP.
