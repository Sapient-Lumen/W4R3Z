# Cluster derivation for Hybrid multicore (D-MK adjunct)

ADR-0005 adopts Hybrid multicore: **multikernel across clusters/NUMA/chiplets; SMP within a cluster**.
This document pins a **deterministic v0 derivation** for clusters so that:
- “cluster” is not a hand-wavy term (it becomes a reviewable artifact), and
- cross-cluster replication and ownership contracts can be stated and validated.

Inputs:
- CH-HWFACT `cpu_topology` facts (and optionally `iommu_presence`, platform tags).
- Optional, profile-scoped clustering knobs (digest-binded as `policy_digest` in CH-CLUSTERMAP).

Output:
- CH-CLUSTERMAP v0.

## Design goals
- Deterministic: same inputs ⇒ same CH-CLUSTERMAP bytes (after canonicalization).
- Bounded: avoid importing full firmware topology dumps into the living contracts.
- Conservative: prefer boundaries that reduce shared-state coupling without over-fragmenting Phase 1 ownership (NUMA / socket by default; `die` only by explicit policy; cache/LLC facts, memory-locality matrices, and asymmetric CPU-capacity facts remain placement hints only per `cache-topology-authority-boundary-v0.md`, `memory-locality-authority-boundary-v0.md`, and `cpu-capacity-authority-boundary-v0.md`).
- Profile-aware but killable: clustering knobs may vary by profile, but the mechanism stays the same.

## v0 clustering policy knobs (bounded)
Represented as a small profile fragment (digest-binded via `policy_digest`):
- `preferred_boundary`: `numa | socket | die | auto`
  - `auto` is intentionally narrow in Phase 1: see `cluster-auto-boundary-v0.md`.
- `max_cpus_per_cluster`: small integer cap (optional; Phase 1 flagship claims keep this at `<=16`, see `cluster-phase1-envelope-v0.md`)
- `allow_cross_numa_clusters`: bool (default false)

## v0 derivation algorithm (deterministic)
Given CH-HWFACT and optional policy knobs:

1) **Extract topology sets** from `cpu_topology`:
   - `cpu_ids`
   - `numa_node_id(cpu_id)` if present
   - `socket_id(cpu_id)` if present
   - `die_id(cpu_id)` if present

2) **Choose the initial partition key** `K`:
   - If `preferred_boundary = numa` and `numa_node_id` is present for all CPUs: use `K = numa_node_id`.
   - Else if `preferred_boundary = die` and `die_id` present for all CPUs: use `K = die_id`.
   - Else if `preferred_boundary = socket` and `socket_id` present for all CPUs: use `K = socket_id`.
   - Else (`auto` or missing facts): Phase 1 chooses the first fully-known boundary in this order:
     `numa` > `socket` > `core_group`.
   - `die` is **not** auto-selected in Phase 1; see `cluster-auto-boundary-v0.md`.

3) **Form initial clusters** by grouping CPUs by `K`.

4) **Apply size cap** (`max_cpus_per_cluster`) if present:
   - For any cluster with `N > cap`, split deterministically into `ceil(N/cap)` subclusters by sorting `cpu_id` ascending and chunking.
   - Set `reason_tag = cap_size_split` for the derived subclusters.

5) **Finalize cluster ids** deterministically:
   - Compute `cluster_id = H("cluster" || kind || sorted(cpu_ids) || locality_tags)` (digest truncated to a bounded display form).
   - Sort clusters by `cluster_id` (lexicographic) for canonical order.

6) **Emit CH-CLUSTERMAP v0**:
   - `hwfact_digest = digest(CH-HWFACT bytes)`
   - `policy_digest` if knobs supplied
   - `clusters` with `kind`, `members.cpu_ids` (sorted), optional locality hints

## Validation and proof obligations
This derivation introduces mechanical obligations:
- PO-CLUSTERMAP-VALIDATE: CH-CLUSTERMAP decode is total, bounded, and rejects overlaps.
- PO-CLUSTERMAP-DERIVE: the derivation is deterministic given the declared inputs.
- PO-CLUSTERMAP-AGREE: if a `cpu_index` is present, it agrees with the cluster list.

These POs are intentionally small and “toolable” (property tests + golden fixtures).

## Relationship to commutativity (D-COMMUTE)
Hybrid reduces cross-cluster shared state. D-COMMUTE reduces the remaining coordination.
Cluster boundaries should therefore be chosen to:
- minimize the set of actions that must cross clusters, and
- make any cross-cluster ordering surfaces explicit (and pinned in hot-action boundaries).

## Open follow-ups
- OQ-0001 is now resolved by `hybrid-phase1-boundary-v0.md`: Phase 1 Hybrid authority/claim semantics are closed rather than open-ended.
- Keep the replication contract surface bounded: treat `object_family` as registry-closed (see `replication-object-family-registry.md`) and update A–D defaults in `profile-repl-defaults.md` for any change (keeps D-REPL reviewable).
- Phase 1 flagship claims are now numerically bounded by `cluster-phase1-envelope-v0.md`; larger cluster counts / sizes are explicit follow-on work rather than implicit scope creep.
- Cache / LLC facts are now pinned as placement hints only in v0 (`cache-topology-authority-boundary-v0.md`); any future cache-aware ownership boundary must land as an explicit RFC-first policy surface instead of reinterpreting existing CH-HWFACT bytes.
- Asymmetric CPU-capacity / performance-class facts are likewise pinned as placement hints only in v0 (`cpu-capacity-authority-boundary-v0.md`); any future perf-class authority or cluster-boundary policy must land as an explicit RFC-first surface instead of reinterpreting existing CH-HWFACT bytes.
- NUMA-distance / HMAT latency-bandwidth / memory-tier facts are likewise pinned as placement hints only in v0 (`memory-locality-authority-boundary-v0.md`); any future distance-adaptive ownership or tier-aware authority policy must land as an explicit RFC-first surface instead of reinterpreting existing CH-HWFACT bytes.
- For any correctness-required global ordering, prefer isolating it to `object_family=tlog` (RC4 reserved) rather than upgrading multiple families; otherwise redesign the interface to commute (D-COMMUTE).
