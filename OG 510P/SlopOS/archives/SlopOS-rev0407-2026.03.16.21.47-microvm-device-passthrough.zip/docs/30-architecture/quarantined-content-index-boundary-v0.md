# D-QUAR / D-ATTRFS / D-OBS quarantined content-index boundary v0 (no ambient OCR / full-text / embedding / summary extraction)

Purpose: pin the **content-derivation boundary** for quarantined objects so risky bytes do not quietly re-enter the system through “helpful” search, OCR, semantic indexing, or agent summarization side effects.
It narrows the next ambiguity after **docref-only safe-open**, **inert-by-default viewers**, and **no durable viewer residue**: even if `open_untrusted` itself is fenced, **may the platform still extract and persist text/embeddings/summaries from quarantined content in the background?**
Phase 1 answers: **no ambient content-derived extraction outside an explicit workflow**. View-scoped metadata queries may still expose safe, declared attributes (name/type/size/quarantine state/origin class), but quarantined bytes do **not** automatically feed full-text indexes, OCR pipelines, embedding stores, assistant memory, or summary caches.

This keeps D-QUAR, D-ATTRFS, D-OBS, and the agent/automation shape honest without inventing a new analysis portal: metadata-safe discovery remains available, while content-derived interpretation of risky bytes stays either disposable-local or an explicit follow-on workflow that produces a **new quarantined artifact**.

## Posture (v0)

1) **Metadata-safe query/index surfaces remain allowed**
   - Phase 1 does **not** require quarantined objects to disappear from ordinary metadata discovery.
   - View-scoped CH-ATTR / CH-ATTRQ evaluation may still expose declared safe attributes such as type, size, timestamps, quarantine state, origin class, and shell-owned labels.
   - But those surfaces remain **metadata-safe**: they do not imply full-text extraction, OCR, semantic embedding, or assistant-produced summaries from the quarantined bytes themselves.

2) **No ambient content-derived extraction from quarantined bytes**
   - A host/global indexer, search daemon, OCR service, embedding pipeline, assistant memory cache, or summary service must not ingest quarantined object bytes merely because the object exists, was imported, or was selected for risky-open.
   - Phase 1 therefore forbids automatic generation/persistence of full-text inverted indexes, OCR sidecars, vector embeddings, semantic tags derived from the bytes, or LLM-authored summaries for quarantined content outside an explicit workflow.
   - This remains true even when the same platform supports those features for cleared/local-trust objects.

3) **Safe-open/viewer convenience does not double as a host-side extraction pass**
   - `intent.kind=open_untrusted` may render and inspect document content inside the disposable.
   - Any text extraction, OCR, search-within-document cache, or model-side summarization used to support that request stays **request-local to the disposable** unless explicitly exported through an existing `portal.file.*` / `portal.xfer.*` seam.
   - A safe-open success must not cause the source object’s contents to appear in host/global search results, assistant memory, or a durable semantic index outside the disposable.

4) **Explicit analysis workflows produce new quarantined artifacts**
   - If a user/operator later chooses OCR, summarize, classify, or embed quarantined content, that work is a **separate explicit workflow** rather than a background consequence of import/open/search.
   - Any durable derived output (recognized text, summary note, embedding blob, tags, classifier result, or similar) is represented as a **new artifact** with its own digest/log justification, exact `origin.parent_digest` linkage to the analyzed source when known, and **quarantined-by-default** classification unless a separate clear/sanitize workflow says otherwise. Export/publication happens only on existing `portal.file.*` / `portal.xfer.*` seams.
   - Such derived outputs do not clear the source object, do not become a hidden reopen grant, and do not authorize future refetch/reanalysis.
   - Companion derived-attribute boundary: those workflows also must not write semantic text/tags/classifier outputs back onto the quarantined source object's CH-ATTR surface; if the semantics are meant to persist/query, they live on the new derived artifact instead (`quarantined-derived-attribute-boundary-v0.md`).
   - Companion result-preview boundary: even after explicit analysis yields a quarantined derived artifact, there is still **no ambient result rendering** from quarantined bytes: search/smart-folder/launcher UI keeps results metadata-safe rather than auto-showing snippets, thumbnails, or preview panes merely because the derived artifact matched (`quarantined-result-preview-boundary-v0.md`).

5) **Agent/automation memory and search stay non-authoritative**
   - In the agent/automation profile, quarantined bytes must not silently flow into long-lived planner memory, retrieval stores, or background summarization caches.
   - If an agent workflow is explicitly authorized to analyze quarantined content, the resulting artifacts remain observation/derived-output surfaces, not authority or trust upgrades.
   - Presence/absence in any derived index must not become an app-visible inventory oracle or a substitute for explicit document authority.

6) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - Background indexing/analysis is not introduced as a new ambient service; explicit analysis/export steps serialize only on their existing workflow/provider seams.
   - Metadata-safe view queries continue to use the existing D-ATTRFS snapshot/live-query semantics and do not gain a second content-analysis ordering vocabulary.

7) **Sealed compat remains killable and non-ambient**
   - Compat adapters may support search/OCR/summary features only if quarantined content still respects this no-ambient-extraction boundary.
   - If an interop path cannot keep content-derived extraction disposable-local or behind an explicit workflow that yields a new quarantined artifact, it fails closed for quarantined objects.
   - Legacy “always index everything” behavior is not grandfathered into sealed compat.

## Phase 1 non-goals (explicitly deferred)

- **No automatic full-text indexing of quarantined bytes**.
- **No automatic OCR / semantic embedding / LLM summarization pipeline for quarantined objects**.
- **No promotion of extracted text/embeddings/summaries into a provider-global inventory, reopen, or grant surface**.
- **No new generic content-analysis portal, background daemon, or ACP kind in v0**.
- **No claim that metadata-safe attributes must disappear from view-scoped queries**; the boundary is about **content-derived extraction**, not hiding file existence within already-authorized views.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-QUAR, D-ATTRFS, D-OBS, D-PLUMB)
- Related posture / schema surfaces:
  - `quarantine-posture-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
  - `attrfs-posture-v0.md`
  - `observation-export-posture-v0.md`
  - `origin-quarantine-attrset.md`
  - `attribute-schema-v0.md`
  - `attribute-query-schema-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-5, I-ATTRQ-2, I-OBS-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL, PO-ATTRQ-ENF, PO-OBS-REDACT)
- RFC / engineering history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0100-attribute-query-predicates-and-smart-folders.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_quarantined_content_index_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **metadata-safe only / no ambient content-derived extraction / explicit derived-output artifact** constraints, or drops its primary REF wiring.

## References

- REF-MS-WINDOWS-SEARCH-INDEXING.
- REF-APPLE-CORESPOTLIGHT.
- REF-MS-OFFICE-MOTW-MACROS.
