# Memory-locality authority boundary v0 (Phase 1 hardware-fact posture)

Purpose: narrow **OQ-0001** again by freezing what NUMA-distance / HMAT latency-bandwidth / memory-tier facts are allowed to mean in Phase 1, so richer locality matrices can improve placement without silently becoming a new Hybrid ownership or authority boundary.

## Decision (v0)

In Phase 1, CH-HWFACT memory-locality matrix facts are **placement hints only**.
That includes any future bounded locality datasets such as:
- NUMA distance / locality matrices,
- HMAT latency / bandwidth attributes,
- memory-tier / near-memory / far-memory labels, or
- SKB-derived rank labels built from those facts.

These facts MAY:
- inform CPU↔memory placement *within* an already chosen cluster,
- help user-space schedulers or SKB queries rank candidate nodes for latency / bandwidth / capacity-sensitive work,
- annotate CH-CLUSTERMAP locality summaries for audit, and
- explain why a placement or migration suggestion preferred one memory node or tier over another.

These facts MUST NOT, by themselves:
- change the default `preferred_boundary = auto` derivation order,
- create a new authoritative cluster `kind` such as `distance_group`, `mem_tier`, or `near_mem`,
- justify cross-NUMA cluster merges, owner migration, or implicit replica placement authority, or
- become an admission/authority boundary for leases, routing, budget, temporal capability, replay, or time semantics.

Any future design that promotes memory-locality matrix facts into an ownership or authority boundary must land as a **separate RFC-first policy surface**, not as a reinterpretation of existing CH-HWFACT / CH-CLUSTERMAP bytes.

## Why this boundary exists

Modern platforms increasingly expose richer locality data: firmware can publish relative NUMA distances and latency/bandwidth datasets, topology libraries can derive distance matrices, and kernels can use those facts for page placement or memory tiering.
That information is valuable, but it is still an optimization vocabulary first.

If SlopOS lets those facts silently widen authority in v0, then:
- the same machine class can produce different ownership boundaries as firmware/kernel/topology exports evolve,
- distance and tiering hints become correctness boundaries without explicit review,
- and “prefer nearer/faster memory” starts leaking into ownership, replay, or budget semantics before the archive has specified any such authority surface.

Phase 1 therefore keeps one hard line:
**memory-locality matrices may explain where to place data and work, but not who owns cross-cluster state or which requests gain authority**.

## Consequences

1) **No automatic distance-adaptive clustering**
   - Discovering NUMA-distance matrices, HMAT latency/bandwidth datasets, or memory-tier labels does **not** create new cluster kinds or rewrite CH-CLUSTERMAP ownership boundaries.
   - `preferred_boundary = auto` remains exactly the Phase 1 rule from `cluster-auto-boundary-v0.md`.

2) **No hidden authority gradient from “nearer” or “faster” memory**
   - Lower latency or higher bandwidth does not imply broader authority, stronger leases, extra budget rights, or a different replay/dedupe meaning.
   - Memory tiers may shape placement, not permissions.

3) **Hinting stays optimization-only on current seams**
   - User-space may use locality matrices to rank memory nodes, suggest migration targets, or explain scheduler decisions.
   - Such hints remain descriptive/optimization-only unless a later RFC introduces an explicit authority-bearing placement or ownership surface.

4) **Future memory-tier authority must be explicit**
   - If a later profile needs distance-aware ownership, tier-specific admission rules, or locality-sensitive replication placement, that work must introduce one explicit policy surface and its proof/evidence plan.
   - It must not reuse old CH-HWFACT bytes as if they had always carried authority semantics.

## Wiring

- Hardware fact seam: `hardware-facts-schema-v0.md` (CH-HWFACT v0)
- Hybrid derivation surfaces: `cluster-derivation.md`, `cluster-map-schema-v0.md`, `cluster-auto-boundary-v0.md`, `multicore-architecture-options.md`
- Decision surfaces: `decision-map.md` (D-MK, D-CLUSTERMAP, D-SKB)
- History/open-question surface: `docs/00-meta/trajectory-map.md` (OQ-0001 narrowed here)
- Evidence hook: `EVID-2026-271` via `tools/check_memory_locality_authority_boundary.py`

## References

- REF-HWLOC-DISTANCES
- REF-ACPI-HMAT
- REF-LINUX-NUMA-BALANCING
