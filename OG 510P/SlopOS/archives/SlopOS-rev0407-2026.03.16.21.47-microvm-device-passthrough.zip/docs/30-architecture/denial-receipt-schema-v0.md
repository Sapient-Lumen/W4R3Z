# CH-DENY v0: Deterministic denial receipt (schema)

Purpose: record a **non-authoritative**, redaction-safe receipt for a *deterministic validator denial*.

CH-DENY is distinct from CH-RECEIPT:
- **CH-RECEIPT** binds a user/consent decision (what was shown + approval evidence).
- **CH-DENY** binds a validator’s fail-closed rejection (schema/policy/lane/ordering), even when no UI/consent step exists.

Design constraints:
- MUST NOT contain raw capability material, bearer secrets, or ambient-authority surrogates (paths/env/implicit network names).
- MUST be mechanically checkable and stable for audits and LLM tooling.
- MUST be safe to include (possibly redacted) in transcript/export bundles.

References: REF-RFC7807.

## Encoding
Candidate baseline: canonical CBOR (D-ENC), optionally wrapped with COSE for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-DENY v0 := {
  v: 0,

  deny_id: bstr,              ; random 128-bit (or more) identifier, for local indexing
  issued_at?: uint,           ; optional monotonic or wall-clock (profile-defined)

  ; what was rejected
  action_schema: tstr,        ; e.g. "CH-ACP v0" | "CH-KABI v0"
  action_digest: bstr,        ; digest of canonical bytes of the action value

  ; optional commutativity/ordering observability (non-authoritative)
  conflict_key_digest?: bstr, ; digest(CH-CONFLICTKEY v0) when derivable (D-COMMUTE)
  order_digest?: bstr,        ; digest(CH-ORDERTOK v0) when present/required (D-COMMUTE)

  ; deterministic denial classification
  deny_code: tstr,            ; closed enum (see deny-code-registry.md)

  ; structured, non-secret reason binding (optional)
  reason?: {
    kind: tstr,               ; closed enum: "none" | "policy" | "lane" | "effcon" | "ordering" | "budget" | "schema" | "reqctx"
    ref_schema?: tstr,        ; optional schema name for the referenced object
    ref_digest?: bstr,        ; optional digest of referenced object
    ref_key?: tstr,           ; optional key name (e.g., a cfg.params lane key)
  },

  ; bounded, profile-defined metadata (ignored unless allowlisted)
  meta?: { * tstr => any }
}

### Deny codes (v0; closed)

`deny_code` MUST be one of the values listed in `deny-code-registry.md`.
Validators MUST reject unknown codes (fail closed).

The registry also defines recommended `reason.kind` bindings and any required keys/digests for auditability.

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `action_schema` is allowlisted; `action_digest` length matches the profile hash.
3) If `conflict_key_digest`/`order_digest` are present, they MUST match profile digest length.
4) `deny_code` is in the closed enum.
5) If `reason.kind` is present, it MUST be in the closed enum.
6) **Non-authoritative rule**: no validator may treat CH-DENY as approval evidence; it is only an audit artifact.

Producer rules (normative, ACP-focused):
- For `action_schema == "CH-ACP v0"`, IF-ACP validators SHOULD emit CH-DENY for all `Reject(..)` outcomes and reference it from the corresponding CH-LOG entry (`deny_digest`).
- When `deny_code == lane-disabled`, producers MUST set `reason.kind = "lane"` and MUST set `reason.ref_key = <cfg.params.* key>` naming the **registry-closed** lane gate that was missing/false (see `config-toggle-registry.md`).
- When `deny_code == cfg-deny`, producers MUST set `reason.kind = "lane"` and MUST set `reason.ref_key = <cfg.params.* key>` naming the **registry-closed** cfg-param gate that vetoed the action (see `config-toggle-registry.md`).
- When `deny_code == missing-approval`, producers MUST set `reason.kind = "policy"` and MUST bind `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)`.
- When `deny_code == expired-approval`, producers MUST set `reason.kind = "policy"` and MUST bind `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)`.
- When `deny_code == policy-deny`, producers MUST set `reason.kind = "policy"` and MUST bind `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)`.
- When `deny_code == reqctx-mismatch`, producers SHOULD set `reason.kind = "reqctx"` and bind `reason.ref_schema = "CH-REQCTX v1"` and `reason.ref_digest = meta.reqctx_digest` (or the rejecting digest).
- When `deny_code == conflict-key-invalid`, producers MUST set `reason.kind = "ordering"` and MUST set `conflict_key_digest` to the rejecting digest value; for CH-ACP, this MUST match the action `meta.conflict_key_digest` (keeps D-COMMUTE evidence reviewable on rejects).
- When `deny_code == order-witness-missing`, producers MUST set `reason.kind = "ordering"` and MUST include `conflict_key_digest` (derived by the validator for ordered kinds) so tooling can identify the ordering domain even when `meta.order_digest` is absent.
- When `deny_code == order-witness-invalid`, producers MUST set `reason.kind = "ordering"` and MUST include `order_digest` (the rejecting witness digest) and SHOULD include `conflict_key_digest` (derived key).

## Security notes
- CH-DENY is a **veto-only** observability artifact: it can explain rejections, but can never authorize effects.
- Hybrid note: if CH-DENY artifacts are replicated under `object_family = receipt`, they remain immutable evidence only; replicated denials cannot satisfy local validator checks, act as policy caches, or become a freshness/order oracle (`receipt-replication-boundary-v0.md`).
- Exports must respect observation policy: metadata may be sensitive; prefer digests/keys over values.
- Avoid raw strings that embed secrets. Use closed enums + digests only.
