# Artifact resolution posture v0 (D-AREF; no ambient locator deref)

Purpose: keep **D-AREF** “sealed compat” honest when we reference heavyweight artifacts via **CH-AREF v0**.
CH-AREF is *content identity* (digest is authoritative); **resolution is a workflow** and must not reintroduce ambient paths/env/implicit network.

This doc does **not** introduce a new schema surface. It pins how implementations treat CH-AREF `locator` hints.

## Posture (v0)

1) **`locator` is never authority**
   - The only authoritative identity is `(digest_alg, digest)` (and optional `size`).
   - Verifiers MAY ignore `locator` entirely.

2) **No privileged dereference**
   - Privileged validators/verifiers MUST NOT dereference `locator` (no implicit `file:` reads, no implicit `https:` fetches).
   - Privileged code only verifies bytes that are already provided via an explicit channel.

3) **Resolution uses explicit workflows (killable by policy)**
   When bytes are needed, the system MUST obtain them via *explicit* workflow seams:

   - **Network**: acquire connectivity via `portal.net.*` (lane-gated by `cfg.params.lane.portal.net`).
     - Requests SHOULD use CH-NETREQ v0 with `purpose="aref_fetch"` and a tight destination predicate (prefer `dest.kind=service` where policy can pin the mapping).
     - Any fetched bytes MUST be verified against the CH-AREF digest before use.

   - **Local files / user-supplied artifacts**: obtain a handle via `portal.file.*` (lane-gated by `cfg.params.lane.portal.file`).
     - The handle (e.g., CH-DOCREF) is the access path; raw host paths MUST NOT become an authority channel.
     - Bytes read through the handle MUST be verified against the CH-AREF digest before use.

4) **Scheme guidance (non-normative)**
   - `ni:` is preferred when you want a *digest-first name* that composes across tooling (still a hint, still may be ignored).
   - `cas:`/`https:` are acceptable only when the resolver is explicitly operating under a network lease.
   - `file:` locators are allowed as a *debug hint* for user-space tooling, but MUST NOT be dereferenced by privileged code.

5) **Cache semantics (commutative by construction)**
   If a resolver maintains a local cache, it MUST be idempotent keyed by digest:
   - inserting the same bytes for the same digest is a no-op,
   - mismatched bytes for a digest is a deterministic integrity failure.

## Phase 1 non-goals (explicitly deferred)

- **Compat “ambient resolver”**: no “just fetch URLs” behavior in privileged code.
- **Policy language** for artifact source selection / mirroring: a portal policy detail, not a v0 contract.
- **Cross-host cache federation**: any distribution requires an RFC with explicit channels and kill-switches.

## Wiring

- Decision surface: `decision-map.md` (D-AREF).
- Schema surface: `artifact-reference-schema-v0.md` (CH-AREF v0).
- Portal families: `portal-family-registry.md` (`portal.net`, `portal.file`).
- Network request surface: `network-request-schema-v0.md` (CH-NETREQ v0).
- Assurance anchors: I-AREF-1, PO-AREF-VERIFY, PO-LANE-KILL.
- CI drift gate: `tools/check_aref_resolution_posture.py` (EVID-2026-199).

## References

- REF-RFC6920 (ni: URIs)
- REF-REAPI-PROTO (REAPI digest-addressed blobs)
- REF-NIX-CA-OUTPUTS (digest-first build outputs)
