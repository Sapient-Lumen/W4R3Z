# D-CAPX / CH-SREF posture v0 (explicit restore-only bearer refs; no ambient resolver or inventory)

Purpose: pin an **implementable Phase 1** meaning for D-CAPX sturdyrefs so “offline capabilities” stay a
small, reviewable handoff/persistence seam rather than drifting into an ambient launch string, a global
inventory/search API, or an invisible authority import path.
It narrows a sharp area into one thing: **CH-SREF bytes are secret-bearing restore material, and Phase 1
permits authority only through an explicit restore/import path; only digests travel through routine UX/
observation surfaces by default**.

This doc is intentionally narrow: it does **not** design distributed GC, global revocation, a generic
cross-machine object runtime, or a default “share authority by pasting strings everywhere” UX.

## Posture (v0)

1) **CH-SREF is secret-bearing restore material, not a hint**
   - **CH-SREF v0** remains a capability-bearing object: possession of the raw bytes is enough to attempt restore.
   - Phase 1 therefore treats CH-SREF bytes like a password or bearer secret, not like a non-authoritative descriptor.
   - Routine transcripts/logs/receipts carry **`digest(CH-SREF v0)`**, not raw CH-SREF bytes, unless an explicit higher-risk disclosure path is in force.
   - This same rule now explicitly covers local naming evidence too: admitted **CH-NAMECERT v0** bundles must not embed raw CH-SREF bytes (`namecert-bearer-boundary-v0.md`).

2) **Restore is explicit and restore-only**
   - Authority appears only when a caller explicitly presents CH-SREF bytes to a restore/import path (gateway / introducer / persistence service).
   - Parsing, displaying, syncing, or storing CH-SREF bytes does **not** auto-restore authority.
   - Phase 1 declines any “click/deserialize/open implies restore” behavior as a product claim.

3) **No ambient resolver, inventory, or probing surface**
   - Phase 1 exposes **no app-visible list/search/watch/inventory API** over CH-SREF material.
   - There is no ambient environment/path/process-global resolver that turns a capability URI/string into authority behind the caller’s back.
   - Shell-owned bookmarks / named roots may exist as explicit UX or D-PERSIST structure, but they are not a generic provider-global sturdyref inventory.

4) **Phase 1 keeps D-CAPX off-by-default and profile-gated**
   - `ext.capx_remote_delegation` remains **off by default** across A–D until a profile explicitly enables it.
   - Enabling D-CAPX is a profile claim, not a convenience toggle implied by a parser/library.
   - This keeps “remote delegation exists” reviewable in the same place as other sharp seams.

5) **Only digests belong in routine workflow/observation artifacts**
   - CH-SREF bytes do **not** belong inside CH-WALLET, CH-PLUMBMSG, sanitized observation exports, default diagnostic snapshots, or ordinary receipts.
   - Those surfaces may carry `digest(CH-SREF v0)` for correlation, but not bearer restore material.
   - If a workflow needs durable authority transfer, that transfer must be explicit and separately justified; it does not hide inside summary or UX artifacts.

6) **Restore does not imply ambient network authority**
   - If restore needs a remote introducer/gateway, that communication happens only through an explicit D-CAPX path with any required network authority separately provided under D-NETLEASE.
   - A CH-SREF string does **not** grant ambient DNS/socket authority by itself.
   - This keeps “offline capability” honest under the archive’s no-ambient-network posture.

7) **D-CAPX is not a substitute for every other durable seam**
   - CH-SREF is a sharp export/import/persistence adjunct, not a replacement for CH-DOCREF, CH-SECRETREF, D-WALLET, D-ACTIVATE, or D-PLUMB routing.
   - Phase 1 prefers the narrower seam when one exists: non-bearer doc handles for documents, summary-only wallets for review, explicit named roots for D-PERSIST, and explicit portals for workflows. `intent.kind=open_untrusted` therefore stays on CH-DOCREF rather than selecting from CH-SREF on a routine plumbing surface. If a workflow starts from CH-SREF and genuinely needs document workflows, it must first materialize a **fresh local object** that remains **quarantine-first** and only then mint a provider-local CH-DOCREF (`import-to-docref-boundary-v0.md`). Companion fresh-identity boundary: that bridge stays **fresh-object-identity-first** with no `reuse_existing` / cache-hit collapse onto a previously imported or trusted local object, even when the bytes match (`import-to-docref-fresh-identity-boundary-v0.md`). Companion bearer-provenance boundary: the imported fresh local object may record one exact **`origin.import_ref_digest`** for the accepted CH-SREF handoff, but routine object metadata never carries raw sturdyref bytes, capability URLs, or hidden refresh semantics (`import-to-docref-bearer-provenance-boundary-v0.md`).
   - If users/apps need inventory/search/recovery/federation semantics, that is evidence for a different reviewed seam, not a reason to silently widen CH-SREF.

## Phase 1 non-goals (explicitly deferred)

- **No app-visible sturdyref inventory/search/watch API**.
- **No auto-restore on parse/open/deserialize/click**.
- **No claim that CH-SREF is safe to paste into logs, chats, wallets, or default exports**.
- **No ambient resolver via env/path/global service names**.
- **No claim that D-CAPX replaces D-PERSIST / D-PLUMB / D-WALLET / CH-DOCREF / CH-SECRETREF**.

## Wiring

- Decision surface: `decision-map.md` (D-CAPX).
- Schemas:
  - `sturdyref-schema-v0.md` (CH-SREF v0)
  - `capability-export-schema-v0.md` (CH-CAPX v0)
- Adjacent seams:
  - `wallet-posture-v0.md` (contrast: summary-only, never bearer)
  - `observation-export-posture-v0.md` (default redaction/export posture)
  - `document-portal-posture-v0.md` (contrast: CH-DOCREF is non-bearer)
  - `namecert-bearer-boundary-v0.md` (contrast: CH-NAMECERT stays non-bearer evidence only)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-SREF-1, I-SREF-2, I-SREF-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-SREF-RESTORE, PO-SREF-EXPLICIT)

CI drift gate:
- `tools/check_sturdyref_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **explicit restore-only / off-by-default / no inventory / digest-only routine surfaces** constraints, or drops its primary REF wiring.

## References

- REF-CAPTP.
- REF-ROBUST-COMPOSITION.
- REF-TAHOE-LAFS.
- REF-W3C-CAPURLS.
