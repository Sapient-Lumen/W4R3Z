# D-QUAR / D-ATTRFS quarantined derived-match boundary v0 (no source resurfacing by derived matches)

Purpose: pin the **result-identity boundary** for explicit analysis of quarantined content so “derive something useful on a sibling artifact” does not quietly turn into “the risky source object now shows up as the matching search result anyway.”
It narrows the next laundering seam after the **no source-object semantic back-write** rule: once OCR / summarize / classify / embed yields a **separate derived artifact**, **may query/smart-folder/search surfaces still return the quarantined source object by following `origin.parent_digest` lineage or collapsing the match onto a preferred representative?**
Phase 1 answers: **no**. Content-derived semantics match the **derived artifact that actually carries them**; the risky source object does not inherit discoverability by hidden lineage joins, representative substitution, or dedup-style result collapse.

This keeps D-QUAR and D-ATTRFS honest without inventing a larger provenance query subsystem: the archive already allows explicit parent linkage and related-artifact navigation, but now fixes the minimum portable rule that stops lineage from laundering search/discovery results back onto the quarantined source.

## Posture (v0)

1) **Queries match the object whose attributes satisfied the predicate**
   - If OCR text, summary text, semantic tags, classifier labels, embeddings, or similar content-derived fields are persisted on a **derived artifact**, then a CH-ATTRQ predicate over those fields matches that **derived artifact**.
   - The quarantined source object does **not** become a matching result merely because `origin.parent_digest`, `origin.chain_digest`, or another related-artifact breadcrumb links the two.
   - In other words: “derived semantics exist about the source” is not the same as “the source matches the semantic predicate.”

2) **Lineage is navigational evidence, not a hidden query join**
   - `origin.parent_digest` and richer provenance links remain useful for explicit “show related/source artifact” navigation, audit, or review.
   - But Phase 1 does **not** treat those links as an implicit join condition that lifts a derived-artifact match onto the quarantined source object.
   - View-scoped search/query services therefore stay handle-returning on the matched object, not “best effort lineage expansion” over related objects.

3) **No representative substitution, dedup collapse, or source-preferred presentation**
   - UI/search layers must not replace a matching derived artifact with the quarantined source object as a prettier/preferred/canonical representative.
   - Grouping or dedup presentation may exist only if the group membership itself is explicit and still preserves the exact matching object; the source object must not silently inherit the hit.
   - “Open original/source” is a separate follow-on action, not evidence that the source matched the query.

4) **Saved queries / smart folders remain digest-bound to the actual matching object set**
   - Because CH-ATTRQ results stay tied to the object whose attributes satisfied the predicate, saved queries / smart folders must not start containing the quarantined source object solely because a sibling derived artifact matched.
   - If users/operators want both objects visible, that is a shell-owned related-artifact presentation choice layered on top of the exact result set, not a change in predicate semantics.
   - This keeps D-ATTRFS snapshot/live-query semantics honest: lineage can explain a relation, but it does not widen match membership.

5) **Related-artifact traversal stays explicit and capability-scoped**
   - A UI, shell, or agent may offer an explicit “show source/original” or “show derived artifact” step only where policy already allows traversing the relation.
   - That traversal uses existing handles/views/metadata; it is not an ambient query side effect and it does not mint a provider-global relation inventory.
   - Companion result-preview boundary: even when the **matching derived artifact** is the right result, rows still stay metadata-safe by default; previewing the derived artifact's bytes is a separate explicit step rather than an ambient consequence of the match (`quarantined-result-preview-boundary-v0.md`).
   - The portable boundary is therefore: exact match first, explicit relation-follow second.

6) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - Query execution, smart-folder refresh, and explicit related-artifact traversal continue to serialize only on their existing view/query/provider seams.
   - The risky source object does not gain a second hidden discoverability stream through lineage-driven result synthesis.

7) **Sealed compat remains killable and non-ambient**
   - Compat adapters may support related-result UX only if quarantined source objects still respect this no-source-resurfacing boundary.
   - If a foreign stack can only express OCR/search hits by returning the original file item while hiding the derived record that actually matched, that behavior must be disabled or isolated behind an explicit materialization/review step.
   - Legacy “search the extracted text, then jump straight to the original file as if it matched” behavior is not grandfathered into sealed compat for quarantined content.

## Phase 1 non-goals (explicitly deferred)

- **No implicit lineage join that makes a quarantined source object match because a sibling derived artifact matched**.
- **No result substitution that hides the matching derived artifact behind the source object as a preferred representative**.
- **No automatic smart-folder / saved-query membership of the risky source object based solely on derived-artifact semantics**.
- **No generic provenance query language, relation-join operator, or background correlation service in v0**.
- **No claim that explicit related-artifact navigation is forbidden**; the boundary is about hidden match lifting, not about reviewable follow-on traversal.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-QUAR, D-ATTRFS)
- Related posture / schema surfaces:
  - `quarantined-content-index-boundary-v0.md`
  - `quarantined-derived-attribute-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `attrfs-posture-v0.md`
  - `attribute-query-schema-v0.md`
  - `origin-quarantine-attrset.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-5, I-ATTRQ-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL, PO-ATTRQ-ENF)
- RFC / engineering history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0100-attribute-query-predicates-and-smart-folders.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_quarantined_derived_match_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no source resurfacing / no hidden lineage join / no representative substitution** constraints, or drops its primary REF wiring.

## References

- REF-MS-WINDOWS-SEARCH-INDEXING.
- REF-APPLE-SPOTLIGHT-IMPORTERS.
- REF-APPLE-SPOTLIGHT-QUERYGUIDE.
