# Foreign Cell adapter kind registry (v0)

Purpose: keep `adapter_kind` values **stable, closed, and reviewable** for D-FCELL.

A Foreign Cell may rely on **adapters** that translate a legacy ABI operation into a **portalized** host workflow.
Adapter kinds are a security seam:
- they define which legacy ops can trigger host workflows,
- they bind those workflows to a specific `portal_token`, and
- they determine which descriptor kinds may be issued.

This registry is the canonical closed set for `CH-FCELL.interop.adapters.*` and `CH-FADAPT.adapter_kind`.
Any new adapter kind requires a small RFC note and updates to:
- this registry,
- `foreign-cell-manifest-schema-v0.md` (seed enums),
- negative tests (AC-071), and
- evidence wiring (EVID).

Non-goal: enumerating the entire legacy ABI. The ABI surface remains separately closed (I-COMPAT-2).

## Adapter kinds (seed)

| adapter_kind | Legacy ABI op scope (illustrative) | Portal token | Request artifact (optional) | Issued descriptor kinds | Conflict key family | Notes |
|---|---|---|---|---|---|---|
| `posix.open_via_doc_portal` | `open/openat/creat` resolved via a document chooser; **no raw path traversal** | `portal.file` | `CH-PLUMBMSG` (D-PLUMB) | `docref` | `cell.adapter` | Used for “open a file” as a mediated workflow; may return read-only or read-write docrefs; deny wins.
| `posix.socket_via_net_portal` | `socket/connect` mediated via outbound session/lease; **no ambient DNS/socket by name** | `portal.net` | `CH-PLUMBMSG` or `CH-JOBREQ` (profile-dependent) | `netlease` | `cell.adapter` | Used for outbound connectivity; actual destinations remain governed by the net portal + lease bounds.

### Validation / binding notes (minimum)

- `adapter_kind` is a **closed allowlist**: unknown kinds reject (fail closed).
- Each adapter kind is profile-gated and **policy-killable** at two layers (both MUST be enabled; missing/unknown toggles treated as disabled; PO-LANE-KILL):
  - **Adapter gate** (granular compat): `cfg.params.lane.fcell.adapter.<adapter_kind>` (normalize `.` → `_`)
    - `posix.open_via_doc_portal` ⇒ `cfg.params.lane.fcell.adapter.posix_open_via_doc_portal`
    - `posix.socket_via_net_portal` ⇒ `cfg.params.lane.fcell.adapter.posix_socket_via_net_portal`
  - **Portal gate** (workflow authority): the adapter’s bound portal token lane kill switch
    - `portal.file` ⇒ `cfg.params.lane.portal.file`
    - `portal.net` ⇒ `cfg.params.lane.portal.net`
- Adapters MUST emit CH-FADAPT receipts for any adapter-mediated host effect (ALLOW/DENY), binding `portal_token` and issued descriptor digests (PO-FADAPT-EMIT).
- Time/entropy are **not** “adapter-mediated host workflows” in v0: they are provided via explicit `resources.clocks` / `resources.entropy` handles in CH-FCELL (no ambient sources).
