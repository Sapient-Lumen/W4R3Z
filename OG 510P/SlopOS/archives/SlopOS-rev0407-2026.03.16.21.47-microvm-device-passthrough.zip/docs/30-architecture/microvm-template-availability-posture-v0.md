# MicroVM template-availability posture v0 (warm-leaf availability is owner-local and semantically optional)

Purpose: pin the **Phase 1** lifecycle boundary for reusable `ext.microvm` warm-start leaves so fast-start work does not quietly become a correctness, release-identity, or public readiness contract.

This doc attaches to **D-MICROVM**, **D-EPHEM**, **D-INITSNAP**, **D-CHKPT**, **D-ATOMICUPD**, and **D-ACTIVATE** and makes one hard decision explicit:
**reusable warm-start leaves are owner-local, semantically optional accelerators whose presence may change without changing the cold parent lineage; portable correctness cannot depend on one specific warm leaf remaining available.**

Entropy cost justification: the archive already says reusable leaves are parent-bound, admitted only under one reviewed resume class, and distributed only as owner-local accelerators. What remains underspecified is whether the **continued availability** of one warm leaf is itself part of the product contract. One narrow posture closes that gap without inventing a new schema family, a public warm-cache state machine, or a new activation lane.

## Posture (v0)

1) **Warm-leaf availability is owner-local and semantically optional**
   - Phase 1 treats reusable warm-start leaves as **owner-local, semantically optional accelerators**.
   - The portable reviewed identity stays on the cold parent lineage (`CH-BOOT`, `CH-INIT`, ordinary deployment artifacts), not on the continued residency of one particular warm leaf.
   - Portable correctness therefore MUST NOT depend on a specific reusable warm-start leaf remaining available, resident, or reusable across time.

2) **Evict / regenerate / patch locally without changing portable deployment identity**
   - The owning runtime may hit, miss, evict, deactivate, recycle, or regenerate warm leaves locally for reasons such as idle reclaim, cache pressure, security/runtime patching, or lifecycle maintenance.
   - Such lifecycle changes do **not** by themselves create a new portable deployment identity, a new published release artifact, or a new guest-visible meaning for the workload.
   - Exact admitted leaf identity may still be recorded as owner-local admission evidence when policy cares, but leaf turnover under the same reviewed parent lineage and resume class is expected rather than exceptional.

3) **miss / rehydrate policy stays admission-local, not a guest-visible API**
   - If no admissible warm leaf is currently available, the owner-local runtime may either:
     - admit a cold start from the reviewed parent lineage, or
     - hold activation/admission locally while regenerating or re-admitting a replacement warm leaf.
   - Phase 1 does **not** standardize a guest-visible or portable public warm-cache status API such as **cache hit/miss**, **warm required**, or **`Pending` / `Active` / `Inactive`** for reusable leaves.
   - In plain terms: warm-leaf lifecycle is an owner-local admission concern, not a portable execution identity/control plane.

4) **Regenerated leaves still obey the already-pinned restore chain**
   - Regeneration does not relax any previously pinned restore discipline.
   - Any newly cut or re-admitted warm leaf still obeys the template-cut, lineage, distribution, resume-class, generation-witness, and repair-barrier postures before it can emit externally visible work.
   - “This leaf was rebuilt locally” is therefore not a reason to bypass repair, widen compatibility, or skip provenance/admission evidence.

5) **No new warm-leaf lifecycle plane is created**
   - Phase 1 adds **no new `CH-*` schema** for warm-leaf availability state, **no new ACP kind**, **no new conflict-key family**, and **no new public catalog/state machine** for warm-leaf lifecycle.
   - If a later design wants portable warm-cache reservations, explicit `Pending` / `Active` lifecycle semantics, or a public “warm start required” contract, it must pay a separate RFC-first cost with explicit ordering, admission, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable guarantee that one exact warm leaf will remain cached, active, or restorable across time.
- No public warm-cache hit/miss or pending/active/inactive lifecycle schema for `ext.microvm` leaves.
- No requirement that every deployment fall back cold instead of failing closed while regenerating a local warm leaf.
- No implication that local regeneration/patching of warm leaves creates a new portable release identity.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-INITSNAP, D-CHKPT, D-ATOMICUPD, D-ACTIVATE)
- Adjacent postures:
  - `microvm-template-distribution-posture-v0.md`
  - `microvm-template-lineage-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `microvm-restore-repair-barrier-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-12)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-TEMPLATE-AVAILABILITY)
- Policy posture:
  - warm-leaf lifecycle adds **no new lane**, **no public warm-cache status plane**, and **no portable cache-residency promise** in Phase 1.

CI drift gate:
- `tools/check_microvm_template_availability_posture.py` fails `make lint` if this posture stops being discoverable, loses its **owner-local semantically optional accelerator / evict-regenerate-without-new-release-identity / miss-rehydrate-stays-admission-local / no public Pending-Active-Inactive state machine / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-AWS-SNAPSTART-ACTIVATE.
- REF-AWS-LAMBDA-RUNTIME-ENV.
- REF-AWS-SNAPSTART-RUNTIME-HOOKS.
