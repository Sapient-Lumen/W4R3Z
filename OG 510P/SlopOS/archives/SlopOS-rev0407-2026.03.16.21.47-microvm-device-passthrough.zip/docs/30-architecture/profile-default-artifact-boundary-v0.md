# Profile default artifact boundary (v0)

Purpose: resolve **OQ-0006** by pinning how the A–D profile default matrices relate to
**CH-CFG v0** / **CH-POLICY v0**.

This doc is an entropy-control decision: it keeps the profile defaults mechanically discoverable
without inventing a new template language or a second authoritative config surface.

Adjunct to:
- ADR-0004 (`adrs/0004-config-as-compiled-artifact-and-generations.md`)
- `config-schema-v0.md` (CH-CFG v0)
- `profile-lane-defaults.md`
- `profile-feature-flag-defaults.md`
- `profile-workflow-defaults.md`
- `profile-repl-defaults.md`

Research imports (translated into our artifacts, not copied):
- CUE treats data validation / configuration as a first-class language/tooling problem (REF-CUE-DOCS).
- Dhall is a programmable configuration language with explicit safety claims (REF-DHALL-HOME, REF-DHALL-SAFETY).
- Jsonnet is a hermetic data templating language rather than a privileged config runtime (REF-JSONNET-HOME, REF-JSONNET-DESIGN).

## v0 boundary (hard decision)

1) **The profile matrices are canonical diff surfaces, not policy artifacts**
   - `profile-lane-defaults.md`, `profile-feature-flag-defaults.md`, `profile-workflow-defaults.md`,
     and `profile-repl-defaults.md` are the canonical archive surfaces for **recommended** A–D defaults.
   - They are **not** CH-CFG fragments, **not** CH-POLICY bundles, and **not** validator inputs.

2) **Phase 1 does not standardize a template DSL or machine-readable profile-default schema**
   - Tooling MAY read the profile matrices and emit concrete CH-CFG / CH-POLICY artifacts,
     but the chosen authoring/generation language remains a tooling concern.
   - SlopOS core surfaces stay where ADR-0004 put them: privileged code only **decode → validate → apply**
     canonical artifacts.

3) **Generated defaults are derived artifacts only**
   - If a repo tool later emits example/default CH-CFG or CH-POLICY artifacts, they live as generated outputs
     (for example under `out/` or test fixtures), not as new discovery/index roots.
   - Such generated artifacts must name the exact profile and source revision they were derived from;
     they do not replace the markdown matrices as the archive’s review surface.

4) **No second source of truth**
   - A proposal to make generated profile defaults authoritative must introduce exactly one new RFC-backed
     surface and explain why markdown diff surfaces are no longer sufficient.
   - Until then, the profile matrices remain the single reviewable source for recommended A–D defaults.

## What this forbids in Phase 1

- No “official” CUE/Dhall/Jsonnet/Starlark/etc. commitment in the core archive.
- No privileged evaluation of template logic inside IF-CFG / IF-BOOT / policy validators.
- No docs/index drift where generated CH-CFG examples are presented as the canonical profile defaults.
- No forked per-profile config trees that silently outrank the shared A–D matrices.

## Why this is worth deciding now

- It keeps **LLM discovery** simple: there is one place to compare A/B/C/D defaults.
- It keeps **sealed compat / no ambient authority** honest: template languages do not quietly become privileged semantics.
- It preserves future freedom: teams can prototype generators, but the archive only standardizes the compiled artifacts
  and the review surface.
- It avoids spending schema budget before we know a machine-readable profile-default surface is worth its entropy cost.

## Wiring

- Open-question history: `docs/00-meta/trajectory-map.md` (OQ-0006 resolved here)
- CH-CFG compiled-output posture: `adrs/0004-config-as-compiled-artifact-and-generations.md`
- Canonical default matrices:
  - `profile-lane-defaults.md`
  - `profile-feature-flag-defaults.md`
  - `profile-workflow-defaults.md`
  - `profile-repl-defaults.md`

## References

- REF-CUE-DOCS
- REF-DHALL-HOME
- REF-DHALL-SAFETY
- REF-JSONNET-HOME
- REF-JSONNET-DESIGN
- REF-NIXOS-MANUAL
