# D-REQCTX posture v0 (sticky tree contexts; absolute-deadline intent; no baggage/detach drift)

Purpose: pin an implementable v0 meaning for **D-REQCTX** so request contexts stay a small coordination seam for cancellation, deadline intent, and correlation instead of drifting into a hidden baggage store, detach/suppress-cancel escape hatch, or second authority surface.
It narrows RFC-0105 into one compact posture validators and runtimes can share: sticky parent→child propagation, one absolute monotonic deadline intent, bounded correlation metadata, and no new workflow/ACP surface.

## Posture (v0)

1) **Optional coordination seam, never an authority source**
   - If D-REQCTX is enabled, request contexts are a **runtime/library-owned coordination primitive** for cancellation, deadline intent, and replay-friendly correlation.
   - **CH-REQCTX** remains a descriptor, not a token: it contains no capabilities, grants no authority, and may only narrow/deny behavior where a consumer explicitly says so (I-REQCTX-3).
   - Phase 1 does **not** standardize a policy/grant path, an approval container, or a generic distributed control plane on this seam.

2) **Derived contexts stay in one monotonic parent→child tree; widening is forbidden**
   - A derived context has at most **one explicit parent** and inherits cancellation/deadline state monotonically.
   - Derivation may only narrow: earlier deadline intent, stricter deny-only metadata, and additional explicit sponsorship digests that are themselves interpreted by consumer-typed adjunct surfaces (I-REQCTX-1; PO-REQCTX-ATTEN).
   - Phase 1 does **not** standardize merge/join contexts, sibling fan-in policies, or ambient “combine whichever context is nearby” behavior.

3) **Deadline intent is one absolute monotonic value; relative timeouts stay local sugar**
   - Portable CH-REQCTX deadline intent remains exactly **`monotonic_deadline_ms`** (absolute on the relevant monotonic clock domain) or absent.
   - Helper APIs MAY offer relative timeout convenience locally, but serialization/export/inter-component propagation must collapse to the one absolute deadline-intent field.
   - Effective deadline is therefore the earliest inherited absolute deadline, not a stack of hidden relative timers or wall-clock timestamps (D-NONDET).

4) **Cancellation is sticky, one-way, and exported as stable closed outcomes**
   - Once a context is cancelled or times out, it remains cancelled for the lifetime of that context; there is no reset/un-cancel operation.
   - Exported/runtime-visible terminal outcomes stay the stable closed set **`CANCELLED`** and **`DEADLINE_EXCEEDED`**; operations must not silently continue after surfacing cancellation (I-REQCTX-2).
   - Phase 1 does **not** standardize a portable resume/retry-inside-the-same-context semantic, a “soft cancel” state, or a hidden background-completion mode after cancellation is reported.

5) **Shielding / non-cancellable cleanup is local-only and non-serializable in v0**
   - Runtimes MAY provide local lexical cleanup/cleanup-shield scopes for carefully bounded critical sections, but those scopes are **not** represented in CH-REQCTX and do not cross an interface boundary.
   - Portable request contexts therefore do **not** carry `shield`, `uncancellable`, `must_finish`, or similar bits.
   - This keeps “finish cleanup anyway” as a local runtime discipline rather than a portable excuse to defeat caller cancellation or quiesce semantics.

6) **Detaching work requires a fresh root and explicit rebinding, not hidden suppress-cancel tricks**
   - Work that is intended to outlive its caller must mint a **fresh root request context** (or no request context) under an explicit owning service/workflow, with its own budget/time sponsorship if required.
   - Phase 1 does **not** standardize a portable “detach while keeping some metadata” wrapper, `suppress_cancel`, or context-stripping adaptor that silently severs parent cancellation while preserving ambient authority/correlation.
   - If a subsystem wants durable or background work, that decision must land on the owning seam (for example D-BGLEASE / D-JOBS / D-QUIESCE), not by mutating D-REQCTX inheritance.

7) **CH-REQCTX stays bounded correlation metadata, not a baggage/value store**
   - `tags` remain bounded diagnostic/correlation metadata only; they are not a general KV store, optional-parameter channel, or authorization input.
   - Phase 1 declines arbitrary typed values, ambient locale/user/session blobs, and opaque caller-controlled payloads on CH-REQCTX.
   - Call-chain metadata (when present via CH-REQCTX v1 and CH-CALLCHAIN) remains bounded and veto-only; it must not become a second authority narrative.

8) **Propagation is the default posture; interfaces must be explicit if they decline it**
   - Generated stubs / runtimes / supervisors SHOULD propagate request contexts by default so caller cancellation, deadline intent, and correlation survive routine composition.
   - If a service/interface intentionally declines cancellation for a bounded critical section, that exception must be explicit in the owning interface/runtime contract; “forgot to propagate cancel” is not an acceptable default.
   - CapRPC-style disconnect/caller-cancel behavior therefore composes with D-REQCTX by default rather than relying on per-call ad hoc bookkeeping.

9) **Adjuncts stay explicit; no ambient time or queue-local timeout dialects**
   - D-WAITSET, D-UWAIT, D-IOQ, and D-QUIESCE MAY bind explicit request contexts for cancellation/deadline outcomes, but they do not invent separate portable timeout/cancel dialects on their own seams.
   - Deadline enforcement uses explicit clock/time/budget authority where required (D-NONDET, D-BUDGET, D-TCAP), not ambient wall clock or network time.
   - This keeps cancellation/deadline semantics reviewable across runtimes rather than fragmenting them into queue-local flags and service-local timers.

10) **No portable cancel-cause field in CH-REQCTX v0/v1**
   - Phase 1 keeps CH-REQCTX portable and replay-friendly by declining any portable free-form cancel-reason string / exception payload / rich cause object field.
   - Implementations MAY record richer local causes in transient runtime state or local logs, but exported/interoperable semantics stay the closed stable outcomes above.
   - Any future structured portable cause surface would need its own RFC/evidence path rather than silently widening CH-REQCTX.

11) **No new workflow / ACP / conflict-key family surface in v0**
   - D-REQCTX v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
   - Therefore **no new conflict-key family is introduced in v0**.
   - Any future request-context admin/export/workflow seam must land RFC-first with its own serialization boundary, receipts, and kill switches.

12) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY internally map guest/runtime cancellation onto host-specific mechanisms, but portable interop carries request-context meaning only through explicit adapter surfaces such as digest-bound correlation.
   - Phase 1 does **not** standardize signal/env/path based ambient cancel propagation into compat domains.
   - This keeps sealed compat honest: request-context interop remains policy-killable and cannot bypass D-FCELL membranes.

## Phase 1 non-goals (explicitly deferred)

- A portable baggage/value store in CH-REQCTX.
- Merge/join contexts or hidden context-combining logic.
- Portable `shield` / `suppress_cancel` / detach semantics.
- Portable free-form cancel-cause strings or exception payloads in CH-REQCTX.
- Ambient wall-clock deadlines or network-time-trusting timeout propagation.
- New workflow / ACP / admin surfaces around request contexts.

## Wiring

- Decision surface: `decision-map.md` (D-REQCTX).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (request-context seam)
  - `rfcs/0105-request-contexts-deadlines-and-cancellation.md` (option space / evidence seed)
  - `request-context-schema-v0.md` / `request-context-schema-v1.md` (bounded descriptor shape)
  - `reqctx-budget-ref-posture-v0.md`, `reqctx-tcap-ref-posture-v0.md`, `reqctx-sponsorship-evolution-boundary-v0.md` (adjunct sponsorship boundaries)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-REQCTX-1, I-REQCTX-2, I-REQCTX-3, I-REQCTX-4)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-REQCTX-VALIDATE, PO-REQCTX-ATTEN)
  - `docs/70-llm-control/acp-validator-semantics.md` (veto-only request-context binding)
  - `call-chain-schema-v0.md` / RFC-0118 (bounded optional call-chain adjunct)
- Discovery/profile surfaces:
  - `posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_reqctx_posture.py` fails `make lint` if this posture stops being discoverable, loses the sticky-tree / absolute-deadline / no-baggage / no-detach posture, or drops its primary REF wiring.

## References

- REF-GO-PKG-CONTEXT.
- REF-KOTLIN-CANCEL.
- REF-CAPNP-1.0-CANCEL.
- REF-TRIO-CANCELSCOPE.
