# CH-VOL v0: Volition token (trusted UI gesture evidence)

Purpose: represent **evidence** that a human performed a gesture through a trusted UI path and was shown a canonical summary bound to an action digest. This is **not** authority by itself; it is an input to IF-CONSENT, which may mint CH-AUTHZ.

Posture note: Phase 1 meaning is pinned in `volition-posture-v0.md`: CH-VOL stays **fresh, local-only, and one-shot**. It is not a batch approval, session-restore cache, export/import artifact, or CH-AUTHZ substitute.

Reference: REF-EROS-EWS-SEC04.

## Encoding
Candidate baseline: canonical CBOR (D-ENC), with COSE (or equivalent) for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-VOL v0 := {
  v: 0,

  ; what the user saw / what it binds to
  action_schema: tstr,            ; e.g. "CH-ACP v0" | "CH-KABI v0"
  action_digest: bstr,            ; digest of canonical action bytes
  summary_digest: bstr,           ; digest of the canonical-rendered consent summary
  summary_profile: tstr,          ; closed enum: "default" | "hi_risk" | ... (policy-defined)

  ; gesture evidence (profile-defined)
  gesture_kind: tstr,             ; closed enum: "click" | "hold" | "biometric" | ...
  gesture_nonce: bstr,            ; unique per token (prevents replay)
  ui_session_id?: bstr,           ; optional UI session identifier
  ui_context?: bstr,              ; optional context hash (window/app identity; profile-defined)

  ; validity window
  exp?: uint,
  not_before?: uint,

  ; issuer (trusted UI root)
  ui_issuer_id: bstr,             ; key id / issuer id (profile-defined)
  proof: bstr,                    ; signature / attestation over the canonical token bytes

  meta?: { * tstr => any }        ; optional; MUST be ignored unless allowlisted
}

## Validation rules (minimum)
A volition token validator MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `action_schema` is allowlisted; `action_digest` length matches the configured hash.
3) `summary_digest` matches the digest of the summary actually rendered for the given `action_digest` under `summary_profile`.
4) `gesture_kind` is allowlisted; `gesture_nonce` is fresh within the declared replay window (e.g., tracked per `ui_issuer_id`).
5) time window rules (if enabled): `not_before <= Now < exp` using a monotonic source (I-TIME-1).
6) verify `proof` under `ui_issuer_id` using the pinned UI-root trust policy (key allowlist, endorsements, etc).
7) unknown `meta` keys are ignored unless explicitly allowlisted.

## Notes
- The *consent UI* should display content derived from canonical bytes (or their digest) to uphold I-CONSENT-1.
- CH-VOL is intentionally compatible with both “local UI root signs” and “hardware-backed attest” profiles.
