# CH-CALLCHAIN v0: call-chain descriptor (optional)

Purpose: a bounded, redaction-aware descriptor capturing a **call chain** (who invoked whom) for audit/debug and for **veto-only** routing/policy decisions.

Non-goal: authority. CH-CALLCHAIN contains **no capabilities**, **no tokens**, and **no bearer secrets**.
Runtime/interoperability posture: see `bracket-posture-v0.md` for borrowed-mode default, task/request-local scoped privilege, and deny-only call-chain use.

Used by:
- CH-REQCTX v1 (optional) via `call_chain_digest`
- workflow router / portals for *deny-only* policy decisions
- postmortems (“why did helper X perform privileged effect Y?”)

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown enum variants and unknown top-level keys reject deterministically.

## Descriptor

```text
CH-CALLCHAIN-v0 {
  schema: "CH-CALLCHAIN";
  version: 0;

  chain_id: u64;               # caller-chosen id within a session/workflow

  # Frames are ordered: root -> leaf (the current requester/caller last)
  frames: list<Frame>;

  Frame {
    kind: enum { component, portal, shell, user, external };

    # Optional stable identity digest. For components, this SHOULD be a digest of the component identity
    # (e.g., component manifest digest or a stable component-id digest used elsewhere in the system).
    actor_digest?: bytes32;

    # Optional human hint (non-authoritative): e.g., component moniker, portal family, or tool name.
    hint?: tstr;

    # Optional interface/intent hint (non-authoritative): IF-* name, portal method, or intent kind.
    surface?: tstr;
  };
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `chain_id` must be present.
- `frames` length: 1..32.
- `Frame.kind` is a closed enum; unknown variants reject.
- `actor_digest` (if present) must be exactly 32 bytes.
- `hint` (if present) length ≤ 80.
- `surface` (if present) length ≤ 80.
- Total encoded size of CH-CALLCHAIN ≤ 8 KiB.

## Security notes
- **Non-authoritative**: CH-CALLCHAIN must not be used to grant authority.
- **Veto-only allowed**: it may be used to *deny* or narrow behavior (“if chain includes untrusted origin, refuse export”).
- **Privacy**: hints may be sensitive metadata; export should be governed by CH-OBSPOL (hash-only export is acceptable).
