# Cluster Phase 1 claim envelope v0 (Hybrid scale budget)

Purpose: narrow **OQ-0001** by freezing the **numeric Phase 1 multicore / Hybrid claim envelope**, so the archive does not quietly over-claim “verified many-core” before the proof and measurement plan exists.

## Decision (v0)

The **Phase 1 flagship multicore claim** (D-MK / C-CONC-1) covers only machines/configurations whose derived **CH-CLUSTERMAP v0** satisfies **all** of the following:

1. **Total logical CPUs**: `sum(cluster.members.cpu_ids) <= 64`
2. **Cluster count**: `len(clusters) <= 8`
3. **Per-cluster size**: every cluster has `len(cpu_ids) <= 16`

These numbers are a **claim envelope**, not a schema bound and not a promise that larger machines cannot boot.
They mean only that **Phase 1 assurance, performance, and replay claims stop here**.

## Interpretation

- Systems inside the envelope are the intended **Phase 1 review/evidence target** across all four product shapes.
- Systems outside the envelope may still be brought up, profiled, or experimented with, but they are **explicit non-claims** until the archive adds a broader D-MK/CH-CLUSTERMAP evolution plan with new evidence.
- `max_cpus_per_cluster` may be used to **lower** the per-cluster cap, but Phase 1 does **not** raise the flagship claim above `16` CPUs per cluster.
- `preferred_boundary = die` remains explicit-policy-only per `cluster-auto-boundary-v0.md`; using it does not automatically expand the claim envelope.

## Why this boundary exists

The archive already commits to a staged multicore story:
- a **small in-cluster proof story** is acceptable early (for example, an SMP big-lock baseline), and
- Hybrid / multikernel structure exists so ownership and routing can become explicit when scale requires it.

What was still missing was the **numeric honesty boundary**.
Without one, “verified multicore” can silently drift into “verified many-core/NUMA/chiplet fleet” even though:
- proof cost grows with cluster count and cross-cluster surfaces,
- contention/serialization evidence stops being comparable once cluster size quietly expands,
- and the four product shapes start optimizing for different hardware classes without a shared claim line.

The Phase 1 envelope therefore chooses a **modest but non-toy** target:
- enough total CPUs to cover the intended workstation / agent / cloud-microvm lanes,
- small enough clusters that the early SMP proof/measurement story remains believable,
- and enough clusters to exercise Hybrid routing/replication without pretending we already solved extreme many-core scaling.

## Consequences

1. **Phase 1 claims stay reviewable**
   - “Multicore required” remains true, but the archive no longer implies an unbounded scale target.
   - C-CONC-1 evidence can be written against one concrete envelope rather than vague “many-core” language.

2. **A–D stay aligned**
   - A (secure workstation), B (cloud micro-VM / hosted substrate), and D (agent/automation) still fit a realistic early envelope.
   - C (embedded / separation appliance) remains comfortably inside it.

3. **Larger machines become explicit follow-on work**
   - More than `64` logical CPUs, more than `8` clusters, or more than `16` logical CPUs in any cluster are **Phase 2+ / RFC-first**.
   - Any stronger cache-/distance-aware clustering policy must arrive with an explicit D-MK / CH-CLUSTERMAP evolution note and new evidence; it does not silently inherit the Phase 1 claim.

## Wiring

- Core direction: `multicore-architecture-options.md`
- Deterministic derivation: `cluster-derivation.md`
- Default auto-boundary: `cluster-auto-boundary-v0.md`
- Decision surfaces: `decision-map.md` (D-MK, D-CLUSTERMAP, D-REPL)
- Verification staging: `docs/40-verification/minimum-viable-proof-slice.md`
- Non-claim boundary: `docs/20-assurance/non-claims.md`
- Open-question history: `docs/00-meta/trajectory-map.md` (OQ-0001 narrowed here)
- Evidence hook: `EVID-2026-267` via `tools/check_cluster_phase1_envelope.py`

## References

- REF-MULTIKERNEL-SOSP09
- REF-SEL4-BIGLOCK-APSYS15
