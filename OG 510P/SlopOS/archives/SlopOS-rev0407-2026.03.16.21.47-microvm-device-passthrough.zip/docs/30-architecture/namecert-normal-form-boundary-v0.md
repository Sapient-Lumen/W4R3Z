# D-NAMECERT normal-form boundary v0 (duplicate-free strict statement sets; no order or repetition semantics)

Purpose: narrow the **statement representation** seam of **D-NAMECERT** so admitted **CH-NAMECERT** bundles
cannot quietly widen into order-sensitive resolver behavior, duplicate-weighted delegation semantics, or many-
digests-for-the-same-practical-statement-set drift.

This boundary attaches to seams that are already in play rather than inventing a new one. `namecert-search-boundary-v0.md`
already pins evaluation as **closed-world and bounded** over one explicit bundle set, `namecert-selection-boundary-v0.md`
already keeps multi-candidate results **set-valued**, and `schema-canonical-bytes-v0.md` / **I-ENC-1** already pin
canonical bytes as a first-class archive contract. The practical Phase 1 question closed here is: **may admitted
CH-NAMECERT bundles treat `bindings` / `delegations` as arbitrary arrays whose order or repetition might affect
meaning, preference, or digest identity?**

Phase 1 makes a small, hard choice: **no**. Admitted statement arrays use one duplicate-free strict normal form,
and evaluators do not invent semantics from order or repetition.

## Boundary (v0)

1) **Admitted statement arrays use one duplicate-free strict normal form**
   - In admitted **CH-NAMECERT v0** bundles, both **`bindings`** and **`delegations`** are treated as sets of statements rather than ordered policy programs.
   - Each array MUST be **strictly sorted by the deterministic canonical bytes of each element** under **I-ENC-1**.
   - **Exact duplicate elements reject**; there is no “same statement twice means stronger evidence” rule.

2) **Admission rejects non-normal input instead of silently repairing it**
   - Phase 1 validators MUST reject `bindings` / `delegations` arrays that are unsorted or contain exact duplicates.
   - Evaluators do **not** silently sort, deduplicate, compact, or rewrite the bundle before policy decisions.
   - This keeps bundle bytes, signatures, receipts, and review surfaces aligned: the admitted artifact is already in the only accepted normal form.

3) **Statement order and repetition are non-authoritative**
   - Position within `bindings` / `delegations` MUST NOT create first-match, last-match, priority, shadowing, or “earlier rule wins” semantics on D-NAMECERT.
   - Repeating an already-admitted statement MUST NOT add weight, votes, quorum, freshness, or trust strength.
   - Any evaluation result depends only on the admitted statement set plus explicit local policy inputs already pinned elsewhere (trust anchors, time input, revocation input, search bounds, candidate selection rules).

4) **Selection/search semantics stay exactly where they already live**
   - This boundary does **not** change `namecert-selection-boundary-v0.md`: when multiple admissible candidates exist after evaluation, results remain **set-valued** rather than preference-ordered.
   - It also does **not** change `namecert-search-boundary-v0.md`: evaluators may perform bounded local search over the explicit bundle set, but search order is non-authoritative and cannot recover hidden semantics from array position.
   - The point here is narrower: normalize the input statement set so later evaluation cannot smuggle in resolver behavior through array order or repetition.

5) **Digest/evidence stability improves across all four product shapes**
   - **Secure workstation (A):** reviewing a name bundle is simpler when one practical statement set has one accepted array form.
   - **Cloud micro-VM substrate (B):** replicated bundle evidence avoids “same semantics, different digest because order changed” churn.
   - **Embedded / separation-kernel-ish appliance (C):** validators stay tiny: one sort rule, one duplicate rule, one reject path.
   - **Agent/automation OS (D):** LLM tooling gets a crisp contract: emit statement sets in strict normal form or expect rejection; do not rely on array order to express intent.

6) **Authority-bearing effects still land only on the target seam**
   - Normalizing admitted statement arrays does **not** create a new ACP kind, conflict-key family, or resolver-admin surface on D-NAMECERT.
   - Any authority-bearing materialization still lands only through explicit D-NS **`view.attach`** / **`view.detach`** on concrete **`view.slot`** keys with retained **`digest(CH-NAMECERT v0)`** provenance.
   - This boundary therefore reduces ambiguity in the evidence seam without widening the action seam.

## Phase 1 non-goals (explicitly deferred)

- Silent canonicalization/repair of malformed `bindings` / `delegations` arrays at admission time.
- First-match / last-match / priority-list semantics inside CH-NAMECERT statement arrays.
- Weighted duplicate semantics (“repeat the same statement N times to strengthen it”).
- A richer policy-rule ordering language on D-NAMECERT itself.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema: `namecert-schema-v0.md`
- Adjacent boundaries:
  - `namecert-selection-boundary-v0.md`
  - `namecert-search-boundary-v0.md`
  - `schema-canonical-bytes-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**, **I-NAME-2**, **I-ENC-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**, **PO-NAMECERT-CHAIN**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-030**)

CI drift gate:
- `tools/check_namecert_normal_form_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **duplicate-free strict normal form / reject unsorted-or-duplicate arrays / no order-or-repetition semantics** stance, or drops its assurance / REF wiring.

## References

- REF-SDSI-RL96.
- REF-SPKI-RFC2693.
- REF-CBOR-RFC8949.
