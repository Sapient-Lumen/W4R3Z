# CH-ENTROPY v0: entropy handle/lease descriptor (schema)

Purpose: describe an *entropy source* capability in a redaction-safe, audit-friendly way.
Rule: the schema is closed and canonically encoded (I-ENC-1).

This schema describes a **handle** (or lease) issued by an entropy portal/host.
The handle itself is a capability; the descriptor is what gets logged/exported.

Design intent (hygiene): treat privileged entropy primarily as **seed material** by default (REF-OPENBSD-GETENTROPY).

## Canonical encoding
- Canonical CBOR with sorted keys and deterministic number/string forms (see `encoding-policy.md`).

## Schema (v0)
Top-level object:
- `v`: integer, must be `0`
- `kind`: string enum
  - `seed` (bounded bytes intended for seeding a per-domain CSPRNG)
  - `stream` (longer-lived stream; rare; explicit)
  - `deterministic` (test/replay provider; never for crypto)
- `max_bytes_per_call`: u32 (0 means “unspecified”; recommended to cap seed calls to small buffers, e.g., 256 bytes)
- `quality`: string enum
  - `csprng_seed` (high-quality bytes suitable for seeding)
  - `csprng_stream` (continuous cryptographic stream)
  - `deterministic` (repeatable bytes)
- `replayable`: bool (true when reads are intended to be fed from CH-RR `entropy` events in replay mode)
- `notes`: string (optional; bounded; must not include secrets)

## Validation rules (informal)
- Reject unknown keys and unknown enum variants.
- `kind==deterministic` implies `quality==deterministic`.
- Policies must forbid treating `quality==deterministic` as satisfying any “cryptographic randomness required” precondition.

## Example
```json
{
  "v": 0,
  "kind": "seed",
  "max_bytes_per_call": 256,
  "quality": "csprng_seed",
  "replayable": true,
  "notes": "seed bytes for per-domain CSPRNG"
}
```
