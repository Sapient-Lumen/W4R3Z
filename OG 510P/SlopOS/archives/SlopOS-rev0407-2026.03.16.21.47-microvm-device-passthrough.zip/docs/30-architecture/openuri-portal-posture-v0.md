# D-PLUMB OpenURI posture v0 (manual-only; scheme-gated; launch-only)

Purpose: pin an **implementable Phase 1** meaning for `portal.uri.*` so “open a link / show this item” stays a mediated launch workflow rather than regressing into ambient helper exec, installed-app probing, or a hidden callback channel.
It narrows an already-present portal family into something UX, policy, and receipts can test without turning SlopOS into a handler-inventory oracle.

## Posture (v0)

1) **No ambient OpenURI constructors**
   - If D-PLUMB is enabled, opening external URIs / showing local items happens only via `portal.uri`.
   - There is no ambient `xdg-open` / `open` / `start` / `ShellExecute`-style helper path after init, and sealed compat adapters do not get a host shortcut.
   - The seam remains fail-closed behind `cfg.params.lane.portal.uri`.

2) **Manual-only v0; no ACP automation kind**
   - `portal.uri.*` remains **manual-only v0** on the ACP surface.
   - Phase 1 does **not** introduce a `portal.uri.request` or similar automation kind.
   - Any future automation surface must come back with explicit conflict-key / commutativity / retry semantics rather than inheriting toolkit behavior.

3) **Scheme-gated and bounded**
   - URI inputs are bounded, parsed, and canonicalized before routing.
   - Scheme allowlists are shell/policy-owned; unknown, private, or custom schemes deny by default in strict profiles unless explicitly allowed.
   - `file://` URIs and raw host paths are **not** OpenURI authority in v0; opening local files/directories remains a `portal.file.*` / CH-DOCREF or already-held-handle workflow.

4) **Launch-only, not a return channel**
   - OpenURI may launch or foreground a chosen handler, but it does **not** return a capability to the requester, a callback token, or a wakeup/reentry channel.
   - Success means the mediation/launch request was accepted, not that the target finished, granted reciprocal authority, or completed some downstream network action.
   - Asking another component to open `https:` or `mailto:` does not grant the requester ambient network authority; `portal.net` remains separate.

5) **No app-visible handler inventory or preflight probing in v0**
   - Phase 1 does **not** expose a generic `list_handlers()`, package/app inventory, or `canOpenURL` / `queryIntentActivities`-style probing surface to applications via `portal.uri`.
   - Any “ask every time” UI, default-handler memory, or launcher heuristics remain shell/portal-owned.
   - Optional scheme-support checks, if any, must be shell/policy-coarsened and must not reveal the installed-handler graph to untrusted requesters.

6) **OpenDirectory / show-item stays path-free and non-amplifying**
   - “Show in file manager” / “open containing directory” requires an already-held file/directory handle or a CH-DOCREF reopen path.
   - `portal.uri` does not mint new file authority, leak host paths, or widen a file selection into ambient directory enumeration.

7) **Ordering lives in the portal**
   - Externally visible OpenURI state (default-handler memory, focus/foreground decisions, “ask” state) is ordered inside `svc:portal.uri`.
   - Two `open_uri` requests may commute with respect to the requester’s authority (they mint none) but do **not** necessarily commute with respect to shell-visible launch order or default-handler state.
   - Any future ACP surface must keep its conflict keys and serialization boundary explicit rather than burying them in toolkit callbacks.

8) **Sealed compat remains killable and non-ambient**
   - Foreign Cell “open link / show item” flows must route through `portal.uri` or an explicit adapter that remains policy-killable.
   - Compat runtimes do not gain ambient host helper execution or package-manager query authority.

## Phase 1 non-goals (explicitly deferred)

- **No ACP automation kind** for `portal.uri.*` in Phase 1.
- **No generic handler inventory / installed-app query API** visible to applications.
- **No callback / return channel / launched-app telemetry** hidden behind OpenURI success.
- **No `file://` / host-path loophole** that bypasses `portal.file.*` / CH-DOCREF.
- **No silent widening** from OpenURI into net/file/device authority.

## Wiring

- Decision surface:
  - `decision-map.md` (D-PLUMB)
- Control surfaces:
  - `portal-family-registry.md` (`portal.uri.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.uri`)
  - `effect-contract-schema-v0.md` (`portal.uri` effect family)
  - `intent-kind-registry.md` (`open_uri`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-OPENURI-1, I-OPENURI-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-OPENURI-ENF)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0117-plumb-messages-and-cli-intents.md`

CI drift gate:
- `tools/check_openuri_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / scheme-gated / launch-only / no handler inventory** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-OPENURI.
- REF-ANDROID-PACKAGE-VISIBILITY.
- REF-APPLE-CANOPENURL.
- REF-APPLE-LSAPPLICATIONQUERIESSCHEMES.
