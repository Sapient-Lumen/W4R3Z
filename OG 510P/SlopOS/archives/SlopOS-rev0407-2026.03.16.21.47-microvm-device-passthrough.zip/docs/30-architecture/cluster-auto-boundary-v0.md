# Cluster auto-boundary v0 (Phase 1 default clustering)

Purpose: narrow **OQ-0001** by freezing what `preferred_boundary = auto` is allowed to do in Phase 1, so Hybrid does not silently drift into chiplet/cache-distance micro-partitions just because topology probes expose them.

## Decision (v0)

When `preferred_boundary = auto`, CH-CLUSTERMAP derivation MUST choose the first fully-known boundary in this order:

1. `numa`
2. `socket`
3. `core_group`

`die` is **not** an auto-selected boundary in Phase 1, even if `die_id` facts are available.
`die` remains an **explicit-policy-only** boundary: the archive may emit `kind = die` only when `preferred_boundary = die` is set and complete `die_id` facts are present.

This is a deliberate authority-surface choice, not a claim that dies/chiplets are unimportant.
In v0 they are treated as **placement/optimization facts**, not the default ownership boundary for Hybrid.

## Why this boundary exists

Auto-clustering is part of the authority substrate because it determines where ownership, routing, and replication boundaries are drawn.
If `auto` freely picks smaller or more ad-hoc topology units whenever the host exposes them, then:
- the same machine class can produce different CH-CLUSTERMAP partitions across firmware/kernel/topology libraries,
- Hybrid proof surfaces grow prematurely (more clusters, more cross-cluster messages, more owner ids), and
- die/chiplet or cache-distance hints start mutating correctness boundaries instead of staying local optimization inputs.

Phase 1 therefore keeps the default rule small:
- prefer **NUMA** when full NUMA facts exist because memory locality is the first-order cross-cluster concern,
- otherwise fall back to **socket**, which is the next stable coarse locality boundary,
- otherwise use a bounded **core_group** fallback,
- and require **explicit policy** to opt into `die` clustering.

## Consequences

1) **No automatic die/chiplet clustering**
   - Discovering `die_id`, CCD, chiplet, cache-group, or hwloc `Group` structure does **not** change the default cluster partition by itself.
   - Cache/LLC facts remain placement hints only in v0; see `cache-topology-authority-boundary-v0.md`.
   - NUMA-distance / HMAT latency-bandwidth / memory-tier facts likewise remain placement hints only in v0; see `memory-locality-authority-boundary-v0.md`.
   - Those facts may still inform placement *within* a chosen cluster.

2) **NUMA remains the preferred Phase 1 authority boundary**
   - If all CPUs have NUMA membership, `auto` uses `numa`.
   - `allow_cross_numa_clusters` remains false by default; Phase 1 does not merge NUMA nodes just because they are “close.”

3) **Socket is the coarse fallback**
   - If NUMA facts are incomplete/missing but socket facts are complete, `auto` uses `socket`.
   - This avoids inventing a finer-grained ownership boundary from less-stable optimization hints.

4) **`die` stays available, but only by policy**
   - Appliances or profiled platforms that genuinely want die-granularity ownership may request it explicitly.
   - That choice must be reviewable via policy/config bytes, not inferred opportunistically from host topology enumeration.

## What remains open

This narrows OQ-0001 but does not finish it.
Still-open follow-ups:
- whether later phases should admit an explicit cache-/distance-aware ownership policy beyond the v0 placement-hint-only boundary in `cache-topology-authority-boundary-v0.md`,
- how/when the archive expands beyond the pinned Phase 1 claim envelope in `cluster-phase1-envelope-v0.md`,
- and whether any additional replication families need tighter RC rules.

## Wiring

- Core derivation surface: `cluster-derivation.md`
- Artifact seam: `cluster-map-schema-v0.md` (CH-CLUSTERMAP v0)
- Decision surfaces: `decision-map.md` (D-MK, D-CLUSTERMAP, D-REPL)
- Hybrid direction: `multicore-architecture-options.md`, ADR-0005
- Open-question history: `docs/00-meta/trajectory-map.md` (OQ-0001 narrowed here)
- Evidence hook: `EVID-2026-259` via `tools/check_cluster_auto_boundary.py`

## References

- REF-HWLOC-OBJTYPES
- REF-LINUX-NUMA
- REF-ACPI-PPTT
