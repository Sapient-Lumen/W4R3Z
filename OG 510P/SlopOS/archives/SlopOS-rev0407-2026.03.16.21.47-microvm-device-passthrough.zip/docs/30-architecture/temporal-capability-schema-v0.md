# CH-TCAP v0 (temporal capability descriptor schema, informal)

Purpose: a pinned, redaction-safe descriptor for **temporal capabilities** (D-TCAP) / scheduling contexts.

This does **not** carry capability secrets. The live TCap is a kernel capability; CH-TCAP describes the intended parameters for audit, initial-state pinning (CH-INIT), and transcript references.

## Design constraints (v0)
- Canonical decode/encode (I-ENC-1) for hashing/logging.
- Closed enums; bounded integers.
- Validation cost is predictable.

## Descriptor shape (v0)
A TCap descriptor `T` contains:
- `schema`: fixed `CH-TCAP v0`
- `tcap_id`: small opaque string/id (bounded; correlation only)
- `budget_us`: uint (bounded; max per profile)
- `period_us` (optional): uint (bounded; if absent, treat as “aperiodic” budget)
- `priority`: enum (closed): `low | normal | high | critical`
- `donatable`: bool
- `donation_depth_limit` (optional): uint (bounded; defaults to 1)
- `overrun_policy` (optional): enum (closed): `block | yield | fail` (profile-scoped)
- `meter_ref` (optional): small opaque id referencing a meter object in the same CH-INIT snapshot (ties to D-METER)

## Validation obligations (PO-TCAP-VALIDATE)
- reject unknown enums/fields
- enforce bounds: `budget_us` and `period_us` within profile maxima
- if `period_us` present: require `budget_us <= period_us`
- if `donatable=false`: require `donation_depth_limit` absent or 0
- enforce small-string bounds for `tcap_id` and `meter_ref`

## Intended uses
- CH-INIT entries for objects of `kind: TCap` can set `params := CH-TCAP`.
- CH-LOG entries can reference `digest(CH-TCAP)` when issuing named budget grants.
- Tooling can diff CH-TCAP inventories across releases to detect budget/policy drift.

## Notes
- This schema is intentionally policy-light. Any “who may donate to whom” policy belongs in user space (e.g., CH-COMP routes, CH-POLICY veto checks) rather than in CH-TCAP.

Refs: REF-TCAPS-RTSS17, REF-SEL4-SCHEDCTX-EUROSYS18.
