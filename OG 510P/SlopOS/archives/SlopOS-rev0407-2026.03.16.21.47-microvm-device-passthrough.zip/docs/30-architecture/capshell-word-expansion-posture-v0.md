# Capshell word-expansion posture v0 (no implicit pre-exec expansion stage)

Purpose: keep **D-CAPSHELL** honest for the *interactive/front-end* side of the shell design.
The archive already pins explicit exec selection, explicit script entry, explicit child env,
structured argv, and explicit-only integrated startup. But an integrated capshell can still
quietly reopen ambient authority if it performs a **shell-like word-expansion stage before
binding CH-ARGV**.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a shell DSL,
a typed mini-language, or a new artifact schema for expansions. It only freezes the Phase 1
answer: **capshell front-end tokens are exact unless an explicitly chosen interpreter expands
them itself**.

## Posture (v0)

1) **No shell-style word expansion in integrated capshell front-end**
   - Integrated capshell MUST NOT perform shell-style pre-exec expansion over user/authored input
     before producing the reviewed **CH-ARGV v0** token list.
   - Phase 1 therefore declines a front-end stage for brace expansion, tilde expansion,
     parameter/variable expansion, command substitution, arithmetic expansion, word splitting,
     pathname expansion / filename expansion, quote removal, or process substitution.
   - `capshell.exec` proposals stay reviewable because the runner sees the exact already-bound
     CH-ARGV token list rather than an expansion result synthesized from ambient shell state.

2) **Literal CH-ARGV tokens are exact bytes, not patterns or indirections**
   - CH-ARGV `lit` tokens remain exact string data; the capshell front-end MUST NOT reinterpret
     `*`, `?`, `[ ... ]`, `{a,b}`, `~`, `$VAR`, `${...}`, `` `cmd` ``, `$(...)`, `<(...)`, or
     similar spellings as instructions to synthesize new argv words.
   - Quote characters may help the interactive UI preserve an exact token during editing, but
     Phase 1 capshell does not expose a second hidden expansion/removal pass that changes the
     reviewed token sequence before execution.
   - If a workflow wants those bytes, they remain those bytes unless an explicitly chosen shell or
     runtime later interprets them under its own already-declared semantics.

3) **Descriptor binding comes only from explicit descriptors, not expansion results**
   - Descriptor-bearing argv entries still come only from explicit `desc_schema + desc_digest`
     references bound to already-held authority.
   - The integrated shell/front-end MUST NOT enumerate the filesystem, expand globs into path
     strings, rewrite `~` into home-directory paths, consult `$PWD` / directory-stack state, or
     run command substitution in order to manufacture new descriptor bindings or literal argv
     tokens on behalf of `capshell.exec`.
   - Future convenience features such as explicit query/selection helpers must return through an
     existing explicit surface (for example portal choice, view-scoped search, or a future
     RFC-first artifact), not through a hidden pre-exec expansion stage.

4) **No implicit namespace reads to prepare argv**
   - Preparing a `capshell.exec` proposal MUST NOT require ambient namespace reads such as
     directory enumeration for globbing, passwd/home lookup for `~user`, shell-variable lookup for
     `$VAR`, or subshell execution for command substitution.
   - Phase 1 therefore keeps argv preparation deterministic with respect to the explicit execution
     context rather than host login state, shell memory, or current filesystem contents.

5) **Explicit shells remain allowed, but only as explicit interpreters**
   - A workflow MAY explicitly choose a shell/runtime as the one CH-ARGV `desc` token with
     `role="exec"`.
   - That explicit interpreter MAY then receive ordinary argv data containing shell metacharacters
     or a command string, but those bytes are part of the chosen tool's own semantics under the
     already-declared execution context.
   - D-CAPSHELL v0 adds no special exemption or hidden rewrite for that case; the capshell
     front-end itself stays expansion-free.

6) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that front-end expansion conveniences reject or remain literal
     instead of silently widening the accepted execution semantics.

7) **Sealed compat remains killable and non-ambient**
   - Wrapper-first or foreign-cell adoption may still launch an explicit shell or legacy program,
     but compat shims MUST NOT auto-expand wildcard/path/tilde/variable syntax on the SlopOS side
     before forming the reviewed CH-ARGV.
   - Any future legacy convenience that reintroduces shell-like expansion must remain an explicit,
     policy-killable compat decision rather than ambient behavior hidden inside D-CAPSHELL.

8) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.expand.*` ACP kind, no glob/tilde policy registry, no shell
     variable store, and no generic pre-exec expansion API.
   - If we later want explicit query languages, path-selection helpers, or a reviewable shell
     language profile, that must land as a separate RFC/decision surface rather than widening
     CH-ARGV or `capshell.exec` by implication.

## Phase 1 non-goals (explicitly deferred)

- No integrated globbing / wildcard expansion.
- No integrated tilde / `$HOME` / directory-stack expansion.
- No integrated parameter expansion or command substitution.
- No runner/front-end brace expansion or process substitution.
- No hidden conversion from literal path patterns into CH-DOCREF / view-bound descriptors.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Existing assurance anchors:
  - `I-ARGV-4` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-NOEXPAND` in `docs/20-assurance/proof-obligation-registry.md`
- Composition seams:
  - `docs/30-architecture/argv-schema-v0.md`
  - `docs/30-architecture/capshell-exec-pack-schema-v2.md`
  - `docs/30-architecture/capshell-command-string-posture-v0.md`
  - `docs/30-architecture/capshell-startup-profile-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_word_expansion_posture.py` (**EVID-2026-324**).

## References

- REF-OPENGROUP-SHELL-CMDLANG
- REF-BASH-SHELL-EXPANSIONS
- REF-SHILL-OSDI14
- REF-CAPSICUM
