# D-CAPRPC oneway posture v0 (bounded notifications; no reply, no stealth transport)

Purpose: pin an implementable **Phase 1** meaning for the **oneway / pulse-style notification adjunct** on **D-CAPRPC** so fire-and-forget calls stay a small runtime seam instead of widening into a durable mailbox, callback bus, or hidden scheduler/control surface.
It narrows RFC-0026 into one compact posture adjacent to **D-TURNS**, **D-REQCTX**, **D-COMMUTE**, and **D-CAPX** so runtimes, validators, and replay/logging tools can reason about one default shape.

## Posture (v0)

1) **Interface-marked adjunct only; no ambient "fire-and-forget" toggle**
   - Oneway is enabled only when the interface definition explicitly marks a method as `oneway` under the pinned **D-IDL / CH-IFACE / CH-ORD** surface.
   - Phase 1 deliberately declines a caller-chosen per-send flag like “do not wait”, “best effort”, or “reply optional”.
   - This keeps **D-CAPRPC** method meaning pinned at the interface boundary rather than drifting into transport-local convenience switches.

2) **No third CH-CAPRPC frame kind in Phase 1**
   - **CH-CAPRPC** stays a two-kind outer frame (`call | return`) in v0/v1.
   - A oneway method is encoded as an ordinary `msg_kind=call` frame whose interface/method metadata says “no return is permitted”, and the callee/runtime MUST NOT emit a matching `return`.
   - `call_id` remains transcript/runtime correlation state only; it does not imply a deferred completion or later receipt surface.

3) **Enqueue-or-error only; no reply, receipt, or deferred completion surface**
   - Sending a oneway call yields exactly one local transport/runtime outcome: accepted for enqueue on the current live session, or a deterministic error.
   - There is no protocol-level reply payload, no separate “delivery receipt”, and no later completion promise for the oneway itself.
   - This is the concrete runtime reading of **I-CAPRPC-2** and **PO-CAPRPC-ONEWAY**.

4) **Tightly bounded small payload; no bulk transfer semantics**
   - Phase 1 pins oneway payloads to a stricter bound than ordinary calls: **`payload <= 256 bytes`**.
   - Oneway is therefore a notification seam for wakeups, nudges, bounded counters/codes, and small status hints, not a bulk-data or stream-transfer path.
   - Anything that needs larger payloads, chunking, or reliable completion belongs on normal D-CAPRPC calls or explicit transfer/queueing seams.

5) **Zero capability attachments and no export/import material on oneway**
   - Phase 1 pins `caps.len == 0` for oneway calls.
   - A oneway call therefore cannot smuggle live handles, **CH-CAPX**, or **CH-SREF** material as a side effect of “notification”.
   - This keeps authority transfer explicit and prevents a stealth transport surface from hiding inside pulse-style delivery.

6) **No pipelined/promised-answer oneway in v0**
   - Phase 1 declines pipelined sends of `oneway` methods toward unresolved promised answers or other promise/result placeholders.
   - If a caller wants promise pipelining, it must stay on the ordinary request/reply adjunct pinned in `caprpc-promise-posture-v0.md`.
   - This keeps pulse-style notifications from merging with the promise calculus and becoming a second queue/scheduler seam.

7) **Current-session only; no durable backlog, replay, or transparent resume**
   - A oneway call exists only on the current explicit live session pinned by `caprpc-session-posture-v0.md`.
   - If enqueue fails because the session is gone or resources are exhausted, the sender gets a deterministic error; if the session later disconnects after acceptance, Phase 1 offers no transparent retry, redelivery ledger, offline mailbox, or resume token.
   - Oneway is therefore live transport state, not a durability promise.

8) **Delivery becomes a normal later turn, not an interrupt/reentrancy escape hatch**
   - When a oneway call is accepted, it is delivered only as a normal later inbound turn/notification on the target runtime.
   - It MUST NOT preempt an active turn, secretly pump the inbox, or bypass the **D-TURNS** “one active turn / no hidden pumping” posture.
   - This keeps notification latency separate from reentrancy hazards and preserves **AC-064** mitigations.

9) **External action semantics stay on existing conflict keys and ordering witnesses**
   - If a oneway method eventually performs an externally visible action, that action keeps the same provider conflict keys, commutativity stance, serialization boundary, and **CH-ORDERTOK** evidence story it would have had as a normal call.
   - Oneway does **not** imply commutativity, unordered execution, or a queue-local sequencing broker.
   - The adjunct changes reply coupling only; it does not create new externally visible action semantics.

10) **No new workflow / ACP / admin surface on D-CAPRPC oneway**
   - Phase 1 introduces no portal family, no **CH-ACP** kind, and no generic admin protocol for listing, cancelling, replaying, draining, or inspecting queued oneway calls.
   - Any future durable mailbox / signal-bus / admin surface must pay its own schema, commutativity, and evidence cost explicitly.
   - This keeps D-CAPRPC oneway from quietly becoming a hidden workflow or control plane.

11) **Sealed compat remains killable and non-ambient**
   - Foreign Cells may adapt guest fire-and-forget or signal APIs only through explicit, policy-killable membrane surfaces.
   - They must not recreate ambient callback registries, background event daemons, or path/env-based notification lookup that bypasses declared D-CAPRPC handles.
   - Any compat enablement remains subordinate to sealed-compat policy and must fail closed when disabled.

## Phase 1 non-goals (explicitly deferred)

- A third `msg_kind=oneway` / `pulse` frame in **CH-CAPRPC**.
- Capability attachments, export/import material, or bulk-data semantics on oneway.
- Delivery receipts, completion promises, or replay/resume semantics for oneway.
- Pipelined/promised-answer oneway sends.
- Any durable mailbox, list/watch, or admin surface for queued notifications.

## Wiring

- Decision surface:
  - `decision-map.md` (D-CAPRPC)
- Adjacent runtime surfaces:
  - `mechanisms.md`
  - `rfcs/0026-object-capability-rpc-profile.md`
  - `capability-rpc-frame-schema-v0.md`
  - `capability-rpc-frame-schema-v1.md`
  - `caprpc-session-posture-v0.md`
  - `caprpc-promise-posture-v0.md`
  - `turns-posture-v0.md`
  - `reqctx-posture-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-CAPRPC-1**, **I-CAPRPC-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-CAPRPC-FRAME**, **PO-CAPRPC-ONEWAY**, **PO-CAPRPC-NOAMBIENT**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-064**)
- Related posture/history surfaces:
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/llm-runbook.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future external notification-management surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_caprpc_oneway_posture.py` fails `make lint` if this posture stops being discoverable, loses the **interface-marked / two-kind frame / enqueue-or-error / payload<=256 / zero-cap / no durable mailbox** posture, or drops its primary REF wiring.

## References

- REF-QNX-PULSES.
- REF-QNX-MSGSENDPULSE.
- REF-GENODE-SIGNALS.
