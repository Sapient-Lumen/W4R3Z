# CH-SPROJ v0: state projection receipt (schema)

Purpose: provide a **bounded, deterministic, non-authoritative** snapshot of *just enough* post-action state to make D-COMMUTE swap-order tests operational.

Motivation
- D-COMMUTE claims must be testable without relying on ambient logs, timing, or implementation-specific “dump” endpoints.
- Many action families are naturally keyed (conflict-key scoped): for commutativity evidence we usually need only the **post-state for the affected key**, not a global state snapshot.
- CH-SPROJ is a tiny, digest-friendly receipt that can be referenced from CH-ACPOUT `receipt_refs` and exported under the same redaction posture as other digest-only receipts.

Non-goals
- CH-SPROJ does **not** grant authority.
- CH-SPROJ is not a general “debug dump” format.
- CH-SPROJ is not claimed to be tamper-proof unless an ADR explicitly adopts signatures/attestation.

## Encoding
Canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-SPROJ v0 := {
  v: 0,

  ; projection identity
  family: tstr,             ; projection family token (typically matches a CH-CONFLICTKEY family)
  key_digest: bstr,         ; digest(CH-CONFLICTKEY v0) for the projected key

  ; projection payload (bounded)
  kind: tstr,               ; "absent" | "present" | "digest" | "digestset"

  ; For kind="absent": no value fields present.
  ; For kind="present": the projection exists but is intentionally opaque; use value_digest.
  value_digest?: bstr,      ; profile hash; digest of canonical bytes of the family-specific value

  ; For kind="digestset": canonical sorted list of digests (e.g., issued lease digests keyed by req_id).
  value_digests?: [* bstr],

  ; Optional compact metadata (bounded, profile-defined allowlist).
  meta?: { * tstr => any }
}

### Projection kind semantics (v0; closed)
- `absent`: the projected record does not exist (e.g., revoked/withdrawn).
- `present`: the projected record exists but the exporter chooses not to expose structure; `value_digest` is the only payload.
- `digest`: a single digest-valued summary; use `value_digest`.
- `digestset`: a bounded set of digest values; use `value_digests`.

Decoders MUST reject unknown `kind` values (fail closed).

## Validation rules (minimum)
Decoders and validators MUST be total and fail closed:
1) `v == 0` and required fields are present.
2) `family` is bounded (length <= 64) and matches `[a-z0-9][a-z0-9_.-]*`.
3) `key_digest` length matches `hashlen` (D-HASH).
4) `kind` is one of the closed values above.
5) If `value_digest` is present, its length matches `hashlen`.
6) If `value_digests` is present:
   - every element length matches `hashlen`,
   - the list is strictly sorted ascending (canonical),
   - and the list length is bounded (default cap: 256 entries; profiles may lower).
7) `meta` keys are bounded and allowlisted by the emitting surface (unknown keys reject when used across trust boundaries).

## Producer rules (ACP-focused, normative)

When D-COMMUTE evidence is in scope for CH-ACP kinds:
- For any ACP kind whose commutativity predicate registry entry requires a “final externally visible state” comparison, producers SHOULD emit a CH-SPROJ v0 receipt and include it by digest in CH-ACPOUT `receipt_refs` (schema=`"CH-SPROJ v0"`).
- The emitted CH-SPROJ key MUST be the derived `conflict_key_digest` (digest(CH-CONFLICTKEY v0)) for the action (when the kind has a declared conflict key).
- The CH-SPROJ payload MUST be deterministic for the same final state and MUST NOT contain secrets or bearer capability material.

This keeps commutativity tests compareable without introducing ambient observation channels.

## Security notes
- **Non-authoritative**: consumers MUST NOT treat CH-SPROJ as authorization evidence.
- **No ambient joins**: CH-SPROJ carries only digests and bounded enums; it must not embed filesystem paths, environment, hostnames, or implicit network identifiers.
- **Redaction posture**: prefer `value_digest`/`value_digests` over raw structure. If structure is ever added in a future version, it must be explicitly redaction-aware.

## Related docs
- D-COMMUTE overview: `commutativity-and-interface-scalability.md`
- ACP kind metadata: `../70-llm-control/acp-action-kind-registry.md`
- ACP commutativity predicates + normalization: `../70-llm-control/acp-commutativity-predicate-registry.md`
- CH-ACPOUT receipt surface: `acp-outcome-receipt-schema-v0.md`
- Conflict key artifact: `conflict-key-schema-v0.md` (CH-CONFLICTKEY v0)
