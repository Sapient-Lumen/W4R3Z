# MicroVM restore-repair barrier posture v0 (repair completes before effectful work)

Purpose: pin the **Phase 1** post-restore execution boundary for reusable `ext.microvm` warm-start leaves so clone/restore hygiene does not drift into “let the resumed guest probe the outside world and see what still works.”

This doc attaches to **D-MICROVM**, **D-EPHEM**, **D-NONDET**, **D-ACTIVATE**, **D-CAPRPC**, **D-LEASE**, and **D-NETLEASE** and makes one hard decision explicit:
**after clone/restore, there is a local restore-repair barrier; the guest/runtime completes clone-sensitive repair before any externally visible action or readiness claim.**

Entropy cost justification: the archive already pins that warm restore is not continuity, that one explicit generation witness exists, that clock quality and attestation freshness repair are separate, and that reusable templates are secret-clean. What is still missing is the execution boundary that keeps those decisions operationally honest. One narrow repair-barrier posture closes that gap without introducing a new schema family or management plane.

## Posture (v0)

1) **Restore has a distinct local repair barrier before effectful work**
   - When a reusable `ext.microvm` leaf is resumed from snapshot/clone, the resumed guest/runtime enters a **local restore-repair barrier** before ordinary effectful work.
   - During this barrier, the guest/runtime may run owner-local repair code, but it MUST NOT perform **externally visible actions** that depend on clone-sensitive state, and it MUST NOT present resumed payload as ready until the barrier completes.
   - In practical terms: no “send the first packet / use the old session / publish ready / try the old lease and see” folklore.

2) **Barrier inputs are the already-pinned explicit repair signals**
   - The barrier begins by observing the primary generation witness from `microvm-generation-witness-posture-v0.md`.
   - If VMClock is present, local clock-quality repair follows the separate rules from `microvm-clock-disruption-posture-v0.md`: `disruption_marker` / `clock_status` invalidate local refinements, while `vm_generation_counter` / VMGenID remain the clone/restore witness.
   - At minimum, the runtime repairs entropy-dependent state, regenerates ephemeral instance identifiers/tokens, invalidates clone-sensitive caches, revalidates or re-establishes network/transport state as needed, and reacquires any generation-scoped attestation/release/session/lease state through existing explicit seams.

3) **Readiness and external effects wait for barrier completion**
   - Activation-delivered public endpoints, inbound request handling, outbound session bootstrap, lease use, attestation freshness claims, and similar externally visible effects become valid only **after** the repair barrier completes.
   - If the chosen guest/runtime cannot observe the generation witness in time, complete its repair work, or re-establish the required explicit state, restore MUST fail closed rather than letting resumed payload race ahead in a half-repaired state.
   - This keeps D-ACTIVATE, D-CAPRPC, D-LEASE, and D-NETLEASE honest: continuity and re-entry still happen only on their explicit seams, not by optimistic use of copied memory.

4) **Transport breakage and stale success are never the repair oracle**
   - Broken network/vsock/session side effects are not the restore detector; the primary witness is.
   - Conversely, an old connection or cached handle appearing to survive for a moment is not permission to skip the barrier.
   - The runtime MUST NOT “test” prior imported authority by using it before repair completes; session/lease/attestation reacquisition stays explicit and policy-owned.

5) **The barrier is a lifecycle rule, not a new portable hook/control plane**
   - Implementations may realize the barrier with runtime-specific after-restore hooks, init phases, supervisor handshakes, or equivalent owner-local techniques.
   - Phase 1 does **not** standardize a portable checkpoint-hook API, guest-management callback protocol, or host-agent “repair complete” signal: there is **no new portable checkpoint-hook API** in v0.
   - The portable requirement is only the ordering boundary: repair first, externally visible work second.

6) **Commutativity and ordering remain explicit by omission**
   - This posture introduces **no new ACP kind** and **no new conflict-key family** in Phase 1.
   - If a later management plane exposes actions such as “prepare restore”, “await repair complete”, or “publish readiness after restore”, it must define conflict keys, commutativity stance, retry semantics, serialization scope, and evidence hooks explicitly.
   - Until then, the repair barrier remains local to the owning runtime / guest stack rather than a new workflow surface.

## Phase 1 non-goals (explicitly deferred)

- No portable guest-management callback or restore-orchestration protocol.
- No generic “checkpoint/restore hooks” API for all runtimes.
- No claim that the barrier solves live migration, HA failover, or cross-host orchestration semantics.
- No hidden cold-boot fallback that pretends the same resumed leaf completed repair successfully.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-NONDET, D-ACTIVATE, D-CAPRPC, D-LEASE, D-NETLEASE)
- Adjacent postures:
  - `microvm-snapshot-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `microvm-clock-disruption-posture-v0.md`
  - `microvm-attestation-reacquire-posture-v0.md`
  - `microvm-template-snapshot-cut-posture-v0.md`
  - `activation-posture-v0.md`
  - `caprpc-session-posture-v0.md`
  - `capability-lease-posture-v0.md`
  - `network-lease-posture-v0.md`
  - `disposable-domain-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-8)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-REPAIR-BARRIER)
- Policy posture:
  - restore-repair adds **no new lane**, **no new guest-visible readiness API**, and **no new host↔guest callback exemption** in Phase 1.

CI drift gate:
- `tools/check_microvm_restore_repair_barrier_posture.py` fails `make lint` if this posture stops being discoverable, loses its **repair barrier before any externally visible action / explicit witness first / no side-effect oracle / no new portable checkpoint-hook API** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-UAPI-VMGENID.
- REF-AWS-SNAPSTART-UNIQUENESS.
- REF-AWS-SNAPSTART-RUNTIME-HOOKS.
