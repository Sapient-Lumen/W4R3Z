# D-NAMECERT string profile v0 (exact-byte ASCII labels; no Unicode/confusable seam)

Purpose: narrow the **identifier/string** meaning of **CH-NAMECERT v0** so local naming does not quietly
turn into a Unicode-preparation problem, a locale-aware comparison seam, or a moving confusable-detection
policy surface.

This doc attaches to the existing **D-NAMECERT / I-ENC-1 / AC-029** surfaces rather than inventing a new
naming subsystem. It resolves one practical Phase 1 question: **what exact string class do `Binding.name`
and `Delegation.role` live in, and how are they compared?**

Phase 1 makes a small, hard choice: **`Binding.name` and `Delegation.role` are exact-byte ASCII labels.**
We do not standardize Unicode preparation, case-folding, transliteration, script policies, or confusable
mitigation logic on D-NAMECERT itself.

## Boundary (v0)

1) **One tiny identifier class for authority-bearing labels**
   - `Binding.name` and `Delegation.role` MUST each be **1..64 bytes**.
   - Allowed bytes are lowercase ASCII letters, digits, dot, underscore, and hyphen: **`[a-z0-9._-]`**.
   - The first and last byte MUST be ASCII alphanumeric.
   - Uppercase letters, whitespace, slash, colon, NUL, non-ASCII UTF-8, and empty labels reject.

2) **Comparison is exact byte equality after validation**
   - After the Phase 1 validator accepts a label, equality/duplicate checks use **exact byte comparison**.
   - D-NAMECERT standardizes **no Unicode normalization** (`NFC` / `NFKC` / `NFD`), **no PRECIS/Stringprep profile**, **no locale-aware comparison**, and **no case-folding** on these authority-bearing labels.
   - In other words: `admin`, `Admin`, and visually similar non-ASCII lookalikes are **not** aliases; unsupported forms simply reject.

3) **No hidden confusable-detection or mixed-script policy plane**
   - Because Phase 1 labels are ASCII-only, D-NAMECERT does **not** import script tables, confusable skeletons, bidi checks, or a versioned Unicode-security dataset into the core seam.
   - If a future profile wants richer human-facing aliases or Unicode display names, that must land as a **separate RFC-first seam** with explicit evidence and drift gates rather than widening authority-bearing labels in place.

4) **Shadowing remains explicit, never normalization-driven**
   - Two labels can collide only if their validated byte strings are identical.
   - There is therefore no silent shadowing by case-fold, width fold, compatibility decomposition, mixed-script confusable, or transliteration.
   - Multi-candidate ambiguity still uses the already-pinned **set-valued** selection semantics from `namecert-selection-boundary-v0.md`; this doc only removes normalization-driven aliasing from that surface.

5) **Projection and replication keep carrying digests, not prettified names**
   - Authority-bearing materialization still lands only through explicit `view.attach` / `view.detach` on concrete `view.slot` keys with retained source `digest(CH-NAMECERT v0)` evidence (`namecert-projection-boundary-v0.md`).
   - Replication still distributes signed CH-NAMECERT bundle evidence only (`namecert-replication-boundary-v0.md`).
   - This string-profile closure therefore adds **no new ACP kind**, **no new conflict-key family**, and **no display-name synchronization seam**.

6) **Sealed compat stays honest**
   - Foreign-cell / compat adapters MUST NOT reinterpret Phase 1 CH-NAMECERT labels with host locale rules, Unicode case-folding, filesystem normalization, or environment-dependent collation.
   - If compat software wants user-friendly aliases, those aliases stay non-authoritative until explicitly mapped onto the target seam under reviewed local policy.

## Phase 1 non-goals (explicitly deferred)

- Unicode / PRECIS / Stringprep preparation profiles for authority-bearing D-NAMECERT labels.
- Locale-aware comparison, transliteration, or case-insensitive matching for CH-NAMECERT labels.
- Confusable-detection datasets, mixed-script policies, or bidi rules on D-NAMECERT itself.
- Human-friendly alias/display-name synchronization as part of authority-bearing CH-NAMECERT evaluation.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema notes: `namecert-schema-v0.md`
- Selection boundary: `namecert-selection-boundary-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Threat hook: `docs/10-threat-model/abuse-cases.md` (**AC-029**)
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**)

CI drift gate:
- `tools/check_namecert_string_profile.py` fails `make lint` if this boundary stops being discoverable, loses its **exact-byte ASCII / no Unicode normalization or case-folding / no confusable-policy seam** stance, or drops its assurance / REF wiring.

## References

- REF-PRECIS-RFC8264.
- REF-UNICODE-UTS39.
- REF-SDSI-RL96.
