# Capshell filesystem-namespace posture v0 (no ambient absolute-path baseline)

Purpose: keep **D-CAPSHELL** honest once workflow launch already has explicit argv/env/cwd/stdio/fdset
and explicit effect contracts. Those seams still drift if the runner quietly preserves an **ambient
filesystem namespace baseline** from the host/session/runtime: absolute-path reachability, process-global
root/mount-namespace visibility, or wrapper behavior that simply “lets the child see the normal host
filesystem”.

This adjunct closes that seam. It is intentionally narrow: it does **not** redesign D-NS, add a
portable `open(path)` workflow API, standardize mount layout, or widen `capshell.exec` into a namespace
manager. It only freezes the minimum Phase 1 posture needed so `capshell.exec` remains capability-safe
instead of inheriting host filesystem lore.

## Posture (v0)

1) **No ambient host filesystem namespace baseline at `capshell.exec`**
   - A reviewed `capshell.exec` launch does **not** imply ambient absolute-path reachability,
     process-global root/mount-namespace visibility, or “the normal host filesystem” as a portable
     baseline.
   - In other words: **no ambient absolute-path filesystem baseline** is part of Phase 1 capshell
     launch semantics.
   - If the active runtime or compat membrane cannot prevent ambient host-filesystem reachability at
     the launch boundary, it MUST reject/fail closed rather than silently widening child authority.

2) **Phase 1 adds no reviewed per-step `open(path)` / namespace-lookup surface**
   - Phase 1 adds **no reviewed per-step `open(path)` / namespace-lookup surface** to CH-EXECPACK,
     CH-ARGV, CH-ENV, CH-CWD, CH-STDIO, or CH-FDSET.
   - There is therefore no portable host-path field, no absolute-path allowlist, no shell-owned
     mount/root selector, and no hidden “legacy paths still work” compatibility promise inside
     `capshell.exec`.

3) **File authority stays on explicit seams only**
   - If reviewed automation needs filesystem authority, it must arrive only through existing explicit
     seams: a bound **CH-CWD v0** root, explicit descriptors in **CH-FDSET v0** / **CH-STDIO v0**,
     explicit **D-NS** view bindings, or explicit chooser/portal-mediated object selection such as
     **D-POWERBOX** / document portal flows.
   - `capshell.exec` itself does **not** grant permission to probe host absolute paths, treat `/` as a
     reviewed capability, or depend on process-global namespace reachability by convention.

4) **Absolute paths are not a reviewed portability promise**
   - Phase 1 declines “normal absolute paths still exist” semantics as part of the reviewed launch
     contract.
   - Host conventions such as `/etc/...`, `/var/run/...`, `/tmp/...`, `/usr/bin/...`, per-user home
     trees, or similar pathnames are not portable workflow authority merely because a child process can
     spell them.
   - Compat wrappers MUST NOT translate reviewed execution into host absolute-path reachability via
     hidden re-rooting, best-effort path rebasing, or “legacy path passthrough” conventions.

5) **Other execution-pack seams do not secretly mint filesystem authority**
   - **CH-ENV v0** may carry literal path strings, but env bytes alone do **not** grant filesystem
     reachability.
   - **CH-ARGV v0** literals do not authorize ambient pathname resolution or host namespace probing by
     convention.
   - **CH-CWD v0**, **CH-STDIO v0**, and **CH-FDSET v0** remain the reviewed file/descriptor binding
     seams; they are not a license to inherit the rest of the host namespace on the side.

6) **Commutativity and ordering stay on existing seams**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - Ordering for launch remains the existing `capshell.exec` story; ordering for explicit namespace or
     object-binding actions remains on the already-defined D-NS / D-POWERBOX / portal seams.

7) **Sealed compat remains killable and non-ambient**
   - Compat/foreign-cell adapters MUST NOT recreate “normal host filesystem visibility” as a hidden
     convenience behind D-CAPSHELL.
   - Any legacy filesystem interop remains explicit, policy-killable, and subordinate to D-NS /
     descriptor/portal seams rather than a side door around them.

8) **No new workflow / ACP / admin surface**
   - Phase 1 adds no `capshell.fs.*`, no reviewed per-step path-open selector, no root/mount inventory,
     and no shell-owned namespace browser/admin surface.
   - Any future explicit path-oriented workflow surface must return as its own RFC-first seam rather
     than hiding inside `capshell.exec`.

## Phase 1 non-goals (explicitly deferred)

- No portable `open(path)` / `mkdir(path)` / `rename(path)` workflow API for capshell.
- No reviewed per-step absolute-path allowlist or mount/root selector inside CH-EXECPACK.
- No hidden “inherit the normal host filesystem” compatibility promise.
- No shell-owned filesystem inventory or namespace browser layered onto `capshell.exec`.

## Wiring

- Decision surfaces: `docs/30-architecture/decision-map.md` (**D-CAPSHELL**, **D-NS**, **D-POWERBOX**).
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-cwd-root-posture-v0.md`
  - `fdset-schema-v0.md`
  - `stdio-schema-v0.md`
  - `view-namespace-posture-v0.md`
  - `powerbox-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-FS-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-FS-EXPLICIT` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_filesystem_posture.py` (**EVID-2026-336**).

## References

- REF-CAPSICUM
- REF-FREEBSD-OPEN-CAPMODE
- REF-OPENAT2
