# CH-EXECPACK v0: capshell execution pack (schema)

Status: **superseded** by `capshell-exec-pack-schema-v2.md`.
v0 is retained for legacy references; new capshell wiring SHOULD prefer v1.

Purpose: eliminate “ambient authority by omission” in workflow execution by bundling the **complete** capshell execution context into a single, hashable descriptor.

CH-EXECPACK is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v0)`.
- deterministic validators/runners **execute** only after validating the pack and then validating/binding each referenced descriptor under already-held authority.

CH-EXECPACK is **non-authoritative**:
- it contains only digests (no bearer secrets, no raw capability material),
- it never grants authority,
- it exists to make required workflow context explicit and reviewable across profiles (A–D) without forks.

References: REF-SHILL-OSDI14, REF-PLASH.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- total decoding + fail-closed validation
- bounded sizes and closed fields (no scripting language)
- digests only: **no bearer secrets** and **no raw capability identifiers**
- makes “no ambient workflow context” enforceable:
  - no ambient PATH resolution (exec chosen via CH-ARGV role="exec" only)
  - no ambient env/cwd inheritance
  - no ambient stdio/TTY inheritance
  - no ambient inherited handle/FD tables

## Data model (conceptual)

CH-EXECPACK v0 := {
  v: 0,

  ; The complete execution context is required.
  ; Each field is a digest of canonical bytes of the referenced descriptor.
  effcon_digest: bstr,   ; digest(CH-EFFCON v0)
  argv_digest: bstr,     ; digest(CH-ARGV v0)
  env_digest: bstr,      ; digest(CH-ENV v0)
  cwd_digest: bstr,      ; digest(CH-CWD v0)
  stdio_digest: bstr,    ; digest(CH-STDIO v0)
  fdset_digest: bstr,    ; digest(CH-FDSET v0)

  ; Optional non-authoritative hints.
  note?: tstr,
  meta?: { * tstr => any }
}

## Validation rules (minimum)

An exec-pack validator MUST be total and fail closed (PO-EXECPACK-VALIDATE):
1) `v == 0`.
2) All required digests are present and each digest length matches the profile hash.
3) Unknown keys reject (or are rejected by canonical CBOR decode).
4) `note`/`meta` (if present) are bounded; `meta` MUST be ignored unless allowlisted.

## Semantics notes (binding to execution)

CH-EXECPACK is a **veto-only completeness seal**:
- It never grants authority (I-EXECPACK-1).
- It exists so `capshell.exec` can be specified as “requires `exec_pack_digest`” rather than
  as a drifting set of optional per-field digests.

Binding points:
- `capshell.exec` proposals MUST carry `exec_pack_digest = digest(CH-EXECPACK v0)`.
- Validators MUST reject `capshell.exec` proposals that omit `exec_pack_digest` (PO-CAPSHELL-EXECPACK-REQUIRE).
- Runners MUST validate and bind each referenced descriptor:
  - enforce CH-EFFCON veto-only effect families at every privileged-effect boundary (I-EFFCON-2),
  - bind CH-ARGV/CH-ENV/CH-CWD/CH-STDIO/CH-FDSET descriptor references only to already-held handles/leases/portal outputs,
  - select the executable only via CH-ARGV `desc` token with `role="exec"` (no ambient PATH),
  - avoid inheriting any ambient process context (env/cwd/stdio/extra handles).

Denial guidance:
- Missing `exec_pack_digest` SHOULD emit CH-DENY with deny_code `execpack-missing`.
- Invalid/unavailable packs SHOULD emit CH-DENY with deny_code `invalid-schema`, binding `reason.ref_schema = "CH-EXECPACK v0"`.

Notes:
- Profiles that disable capshell (`cfg.params.lane.capshell=false`) deterministically deny `capshell.exec` (PO-LANE-KILL).
- This schema is deliberately minimal: it binds *what* context is used, not *how* handles are passed.
