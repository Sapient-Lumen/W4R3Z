# CH-SECRETREF v0: Durable secret reference (no secret bytes)

Purpose: a durable, shareable reference to a secret object and its usage policy (D-VAULT).  
This schema is suitable for **CapStore persistence** (D-PERSIST), receipts, and audits. It contains **no secret bytes**.

Refs: REF-PLAN9-SECSTORE, REF-APPLE-KEYCHAIN, REF-ANDROID-KEYSTORE, REF-SECRET-SERVICE-SPEC.

V0 posture note: `vault-posture-v0.md` pins **CH-SECRETREF** as the portable handle for D-VAULT in Phase 1.
The archive deliberately declines collection/item/session/search inventory semantics and implicit recovery/federation behavior on the core seam.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-SECRETREF v0 := {
  v: 0,

  ; stable identifier (provider-defined, collision-resistant)
  sid: bstr,                    ; e.g., 16–32 bytes (opaque)

  ; where the secret “lives”
  provider: {
    uri: tstr,                  ; e.g., "cap://.../vault/..."
    realm?: tstr,               ; optional realm label for human audit
  },

  ; public metadata (avoid low-entropy digests)
  class?: tstr,                 ; "user_cred" | "device_secret" | "recovery" | "token" | ...
  len_hint?: uint,              ; optional upper bound hint (non-authoritative)

  ; policy (and pin)
  policy?: CH-SECRETPOL v0,
  policy_digest?: bstr,         ; digest(CH-SECRETPOL) if policy redacted/not embedded

  ; optional provenance hooks (non-authority)
  created_by?: bstr,            ; digest of CH-PROV / release identity (if applicable)
  created_at?: uint,            ; optional logical/monotonic timestamp (see D-NONDET)

  note?: tstr,
}

## Notes
- If `policy` is present, `policy_digest` SHOULD equal digest(policy) for easy cross-checking.
- CapStore roots SHOULD prefer storing CH-SECRETREF rather than any application-level secret blob.
- Avoid including digests of low-entropy secrets in this schema; store those digests only inside the provider if needed for rotation semantics.

