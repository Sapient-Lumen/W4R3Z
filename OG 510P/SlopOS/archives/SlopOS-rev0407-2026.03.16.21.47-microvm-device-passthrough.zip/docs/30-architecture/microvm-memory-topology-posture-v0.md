# MicroVM memory-topology posture v0 (static guest-visible RAM; no portable resize plane)

Purpose: pin the **Phase 1** meaning of guest-visible memory topology under `ext.microvm` so ballooning, free-page hinting, and memory hotplug do not quietly become an ambient host↔guest control/status plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 fixes guest-visible memory size/topology at admission; `ext.microvm` adds no portable balloon / virtio-mem / ACPI memory-hotplug / resize-status plane, and changing guest-visible RAM means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity.**

Entropy cost justification: the archive already pins `ext.microvm` to a declared device set, forbids ambient host channels, and sharply bounds warm-start lineage/admission semantics. What remains underspecified is whether dynamic guest-memory management is part of the reviewed product surface. One narrow posture closes that gap without inventing a new schema family, a resize workflow, or a hidden host control plane.

## Posture (v0)

1) **Guest-visible memory topology is fixed at admission**
   - For Phase 1, each admitted `ext.microvm` leaf runs with **one exact guest-visible memory size/topology** fixed at admission.
   - Portable semantics do **not** include post-admission guest-visible RAM resizing under the same reviewed portable identity.
   - In plain terms: the reviewed contract is “this leaf boots with this guest-visible RAM topology”, not “the host may later negotiate a new target size while the same leaf keeps running”.

2) **No portable balloon / hotplug / resize-status plane**
   - Phase 1 standardizes **no portable balloon / virtio-mem / ACPI memory-hotplug control/status plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible fields or APIs such as **target/requested size**, **plugged/unplugged size**, **guest memory statistics**, **free-page hinting runs**, or **host-driven resize commands**.
   - Implementations may internally support such mechanisms, but they are **not** part of the Phase 1 product contract and must not silently become guest-visible reviewed meaning.

3) **Host reclaim/overcommit policy stays owner-local and must not masquerade as a portable API**
   - Owners/runtimes may still use ordinary host-level capacity management, reclaim, or admission policy locally.
   - What they may **not** do in Phase 1 is turn that owner-local policy into a portable guest-visible resize/status contract for an already admitted leaf.
   - If a deployment cannot honor the fixed guest-visible memory topology it admitted, the correct Phase 1 outcomes are to admit a different reviewed leaf/activation or fail closed — not to grow a new portable in-place memory-resize meaning by convention.

4) **Changing guest-visible RAM is a new admission, not an in-place mutation**
   - If policy wants a different guest-visible memory size/topology, that change is modeled as a **new reviewed admission / activation choice**.
   - It is **not** modeled as mutating a running guest under the same admitted leaf identity.
   - This keeps memory sizing aligned with the already-pinned lineage/resume-class story instead of creating a second hidden lifecycle/control surface inside `ext.microvm`.

5) **No new resize plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for memory-resize state, **no new ACP kind**, and **no new conflict-key family** for balloon/hotplug operations.
   - If a later design wants portable resize/hot-remove semantics, free-page hinting workflows, or guest-visible memory-pressure/telemetry contracts, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable balloon / virtio-mem / ACPI memory-hotplug semantics for `ext.microvm`.
- No portable guest memory-statistics or free-page-hinting API.
- No promise that host-side capacity policy is forbidden; only that it does **not** become a reviewed guest-visible resize/control plane in Phase 1.
- No in-place “same leaf, different RAM size now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `host-guest-channel-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `microvm-template-availability-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-13)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-MEMTOPOLOGY)
- Policy posture:
  - guest-visible memory resizing adds **no new lane**, **no public resize/status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_memory_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fixed-at-admission guest-visible topology / no portable balloon-virtio-mem-ACPI control plane / no target-size-or-stats semantics / change RAM by new admission not in-place mutation / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-MEMORY-HOTPLUG.
- REF-FIRECRACKER-BALLOONING.
- REF-VIRTIO-1.3.
- REF-CHYP-HOTPLUG.
