# CH-CRASHCAP v0 (crash capsule manifest schema, informal)

Purpose: a bounded manifest that captures **one failure event** (crash/panic/abort/watchdog) and binds the minimal evidence needed for triage and symbolized debugging.

CH-CRASHCAP is a “crash-shaped” companion to CH-SNAPSHOT:
- CH-SNAPSHOT: broad support bundle (many kinds, many domains)
- CH-CRASHCAP: one crash, bounded evidence, stable module identity

Refs: REF-CRASHPAD-OVERVIEW, REF-MS-MINIDUMP-FILES, REF-SYSTEMD-COREDUMP-MAN.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded metadata and bounded payload references
- export/redaction posture is explicit (I-OBS-1)
- avoid stable hardware IDs, bearer tokens, raw pointers in the manifest

## Shape (v0)
A crash capsule manifest `c` contains:

- `schema`: fixed `CH-CRASHCAP v0`
- `crash_id`: random nonce (no stable identity)
- `fault_kind`: closed enum (e.g., `panic`, `segv`, `abort`, `oom_kill`, `watchdog`, `assert_fail`)
- `reason`: bounded string (human hint; non-authoritative)
- `domain`: bounded tag naming the failing component/domain
- `boot_digest`: optional digest of CH-BOOT (or redacted boot summary digest)
- `cfg_digest`: optional digest of the active configuration generation (CH-CFG or derived generation digest)
- `comp_digest`: optional digest of CH-COMP (or a redacted graph digest)
- `ts`: optional timestamp (only if enabled by profile)

### Modules list (symbolization identity)
`modules`: canonical list of loaded modules at failure time (bounded count):
- `name_hint`: bounded string (e.g., `libfoo.so`, `driver_net`) — hint only
- `build_id`: bytes or hex string (preferred) OR `digest` (if build_id is unavailable)
- `module_kind`: closed enum (`exe`, `shared_lib`, `jit`, `driver`, `other`)
- `addr_hint`: optional (range or base) — only if permitted by export policy; otherwise omitted

Canonical ordering:
- modules sorted by (`module_kind`, `name_hint`, `build_id/digest`).

### Payload references
`payloads`: canonical list of payload references, each:
- `kind`: closed enum
- `digest`: content digest of the payload bytes
- `aref`: optional CH-AREF (if stored out-of-band)
- `redaction`: optional enum (`public` | `sanitized` | `sensitive`)
- `note`: optional bounded string

Allowed `kind` values (v0):
- `log_window` (CH-LOG excerpt)
- `trace_window` (CH-TRACE excerpt or processor output)
- `inspect` (CH-INSPECT snapshot)
- `dump` (opaque crash dump payload)
- `replay_bundle` (CH-RRBUNDLE digest reference; only if enabled)
- `snapshot_bundle` (CH-SNAPSHOT digest reference; optional escalation)

Dump payload metadata (optional):
If `kind = dump`, the payload reference MAY include:
- `dump_kind`: closed enum (`minidump`, `core`, `other`)
- `dump_format_hint`: bounded string (e.g., `minidump-v1`, `elf-core`)

Canonical ordering:
- payloads sorted by (`kind`, `digest/aref.digest`).

## Validation obligations
- reject unknown enum values
- enforce bounds: module count, payload count, string lengths
- best-effort lint: forbid obvious secret-bearing fields (bearer tokens) in `note` and `reason`

## Binding obligations
If `boot_digest` / `cfg_digest` / `comp_digest` are present:
- capsule consumers SHOULD fail closed on mismatch with claimed environment
- assemblers SHOULD ensure payloads come from the same boot/session (no cross-boot mixing)

## Policy obligations
Assemblers MUST:
- apply CH-OBSPOL (or equivalent policy) to decide which payload kinds and which metadata are allowed
- default to **sanitized** payload sets
- require explicit authority/workflow for `sensitive` payloads
