# CapRPC proxy replication boundary (v0)

Purpose: narrow **OQ-0001** for `object_family = caprpc_proxy` without turning replicated routing metadata into replicated capability authority.

`CH-CAPRPC v0`, `CH-CAPX v0`, and RFC-0026 already pin the object-capability RPC stance: remote effects require an explicit capability/proxy, calls are framed explicitly, and sturdy/persistent references are restore/import problems rather than ambient naming.
Hybrid needs one additional hard decision so cross-cluster replication cannot quietly smuggle “live proxy state” into a second authority plane:

- replicated `caprpc_proxy` state is **owner-routed endpoint/proxy metadata only**, and
- **callable authority remains the locally held proxy/handle or an explicit restore/import event bound to local policy**.

This keeps RC1 owner-sharded replication honest while preserving the D-CAPRPC / D-CAPX rule that capability use stays explicit, connection-aware, and non-ambient.

## Decision (v0)

For `object_family = caprpc_proxy` under CH-REPLCONTRACT v0:

1. The authoritative instance is **owned by exactly one cluster** and keyed by `endpoint_id`.
2. Non-owner replicas MAY cache only **bounded read-only metadata** needed for routing/bootstrap, such as `{owner_cluster, endpoint_id, iface_digest, epoch, route_hint}`.
3. Replication MAY move that metadata between clusters, but it MUST NOT by itself:
   - create a new callable local handle/proxy,
   - copy connection-scoped capability/object ids, promised-answer paths, or reply routing state into another cluster as usable authority,
   - auto-restore an imported/persistent capability,
   - bypass the explicit CH-CAPX / CH-SREF restore/import seam, or
   - upgrade cached route hints into a globally valid endpoint namespace.
4. Any cluster that wants to *use* remote authority MUST still obtain an explicit local authority object via:
   - a live capability/proxy handoff on an authenticated connection,
   - an explicit CH-CAPX import bound to a local `cap`/`proxy` object, or
   - an explicit CH-SREF restore route when that adjunct is enabled.
5. Ordering/causality for cross-cluster calls lives in the **proxy/RPC contract** (CH-CAPRPC, CH-CONTRACT, session state), not in replication. Replicated `caprpc_proxy` metadata may help locate an owner, but it is not itself a call queue or ordered log.
6. If owner metadata is stale or missing, consumers MUST fail closed (deny/retry/refresh) rather than guessing a replacement owner or silently minting a new proxy.

## Why RC1 fits here

`caprpc_proxy` is RC1-safe in v0 because the dangerous state is **live endpoint/proxy state**, which is inherently owner-scoped and often connection-scoped.
A single authoritative owner keeps:

- endpoint lifecycle explicit,
- failover/migration RFC-first rather than ambient, and
- call ordering where it belongs: in the RPC/proxy session contract.

What does **not** safely commute in v0 is “this replicated row means I may now call the remote object.”
SlopOS therefore declines any rule like “whoever has the latest proxy metadata may instantiate authority locally,” “replica majority selects the active endpoint,” or “replication automatically replays/imports the proxy after reconnect.”

## Explicit non-goals (v0)

Phase 1 does **not** standardize:

- active-active multi-owner proxy replicas,
- replicated queued calls / offline outboxes for CapRPC,
- automatic cross-cluster proxy failover or endpoint migration,
- a global endpoint catalog/discovery service, or
- replication of connection-local promised-answer or handle ids as portable authority.

If we later need endpoint migration, durable proxy journals, or multi-owner failover semantics, that work must land as a new RFC-first protocol/object-family surface rather than by silently widening `caprpc_proxy` replication.

## Source notes

- Cap’n Proto RPC makes capability permissions **connection-specific** and treats persistent capabilities as an explicit **save/restore** feature rather than an ambient namespace (REF-CAPNP-RPC).
- CapTP / Robust Composition emphasize explicit object references, vats/event loops, and explicit introductions rather than global names or hidden authority transfer (REF-CAPTP, REF-ROBUST-COMPOSITION).

## Consequences for the archive

- `replication-object-family-registry.md` should treat `caprpc_proxy` as **owner-routed endpoint/proxy metadata only**.
- `profile-repl-defaults.md` may keep RC1 defaults where cross-cluster CapRPC is plausible, but the note must say that **replication does not create callable proxy authority**.
- `capability-rpc-frame-schema-v0.md`, `capability-export-schema-v0.md`, RFC-0026, and RFC-0004 should point out that live handle/proxy authority still arrives only through explicit handoff/import/restore surfaces.
- Any future stronger semantics (endpoint migration, durable queued calls, multi-owner failover) must pay for a new decision surface.
