# View replication boundary (v0)

Purpose: narrow **OQ-0001** for `object_family = view` without turning replicated namespace metadata into ambient cross-cluster attach authority.

`D-NS` already pins view objects as the explicit namespace substrate: privileged code resolves through a held view, attach/detach mutates named slots, and slot mutation is ordered on `CH-CONFLICTKEY family="view.slot"` at `svc:view`. Hybrid needs one additional hard decision so cross-cluster replication does not quietly turn remote namespace observations into active local bindings:

- replicated `view` state is **owner-routed slot-binding metadata only**, and
- any non-owner replica material stays **read-only, cache-shaped, and non-activating**.

This keeps RC1 honest while preserving I-VIEW-1/I-VIEW-2: names stay local to an explicit view object, and replication never becomes a second attach/import authority plane.

## Decision (v0)

For `object_family = view` under CH-REPLCONTRACT v0:

1. The canonical authoritative state is the owner-routed set of **slot binding mutations scoped by `view_id`**.
2. Authoritative `view.attach` / `view.detach` remains serialized by the owner on `family="view.slot"` at `svc:view`; replication does not move that serialization boundary.
3. Non-owner clusters MAY hold bounded **read-only summaries or epoch-tagged cache snapshots** describing a remote view, but those artifacts MUST NOT by themselves:
   - auto-attach or auto-detach a binding inside a receiver's active local view,
   - create a new local root or default namespace,
   - treat path strings / slot labels / arrival order as portable authority, or
   - bypass the explicit `view.attach` / `view.detach` receipt path.
4. A receiver MAY use replicated view information only through an **explicit local step**: either ask the owner to perform the authoritative mutation, or import/materialize a separate local view under local policy.
5. Concurrent remote slot updates are **not** merged by last-writer-wins, peer majority, or path-string comparison. The owner-routed mutation log remains the only authoritative source for active slot state.

## Why RC1 fits here

`view` is RC1-safe in v0 because the correctness-sensitive object is **the active slot binding state**, not a commutative bundle set.
Within one `(view_id, slot_id)` the meaning of “which binding is active?” is intentionally non-commutative and already has an explicit ordered seam: `family="view.slot"` plus `svc:view`.

Read-only summaries may still exist for inspection, caching, or planning, but they are derivative observations, not the authoritative view itself. SlopOS therefore declines any v0 rule like “replicas auto-apply owner changes locally,” “latest replicated slot wins,” or “remote views merge into one active namespace.”

## Explicit non-goals (v0)

Phase 1 does **not** standardize:

- live cross-cluster namespace mirroring,
- multi-owner consensus on active slot bindings,
- remote path-based authority import,
- auto-promotion of a replicated cache into a local active root view, or
- path/inventory APIs that let applications infer another cluster's active namespace without an explicit exported summary surface.

If we later need durable cross-cluster view snapshots, shared namespace projections, or multi-owner namespace failover, that work must land as a new RFC-first object family or descriptor seam rather than by silently widening `object_family = view`.

## Source notes

- Fuchsia namespaces are **per-component rather than global**, and components only access namespace objects reachable from handles they already possess; there is **no ambient authority** (REF-FUCHSIA-NS).
- Plan 9 treats namespaces as **private/local views**: users build a private environment, and per-window namespace adjustments do not affect other windows or programs (REF-PLAN9-PAPER).

## Consequences for the archive

- `replication-object-family-registry.md` should treat `view` as **owner-routed slot-binding metadata only**.
- `profile-repl-defaults.md` may keep RC1 defaults where cross-cluster views are plausible, but the note must say that replicated summaries are **read-only/non-activating**.
- `view-objects.md`, `view-namespace-posture-v0.md`, RFC-0032, and the hot-action surfaces should point out that replication does not auto-activate bindings in a receiver's local active view.
- Any future stronger semantics (live mirrored namespaces, multi-owner failover, active snapshot import) must pay for a new decision surface.
