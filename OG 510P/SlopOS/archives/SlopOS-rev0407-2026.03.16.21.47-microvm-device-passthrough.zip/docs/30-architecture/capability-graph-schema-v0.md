# CH-CAPG v0 (capability graph snapshot schema, informal)

Purpose: a **bounded, redacted** snapshot of a domain/component's capability graph, exported via IF-OBS for debugging/audit, and used by tooling for *capability leak detection*.

Design constraints (v0)
- Deterministic decode + canonical encoding (I-ENC-1).
- Redaction/minimization is explicit (I-OBS-1; PO-OBS-REDACT).
- No raw pointers/addresses; no kernel object identifiers that would meaningfully help ASLR/side-channel attackers.
- Graph size is bounded by policy (export fails closed if it would exceed the bound).

## Shape (v0)

A cap-graph bundle `g` contains:
- `schema`: fixed `CH-CAPG v0`
- `scope`: tag describing *which* domain/component or “view” is being described (opaque string; may be redacted)
- `epoch`: optional monotonic counter for comparing snapshots (or omitted if not enabled)
- `nodes`: list of node records (bounded)
- `edges`: list of edge records (bounded)

### Node record (v0)
Each node:
- `nid`: small integer stable *within this bundle* (1..N)
- `kind`: enum: `domain | thread | endpoint | memory | irq | view | meter | other`
- `label`: optional redacted label (e.g., `driver_domain`, `netstack`, `init`), policy-controlled
- `attrs`: optional small map for audit (e.g., `rights_summary`, `quota_summary`) with **no** high-entropy IDs

### Edge record (v0)
Each edge:
- `src`: `nid`
- `dst`: `nid`
- `etype`: enum: `holds_cap | derives_from | maps_view | owns | charges_to`
- `rights`: optional reduced rights summary for `holds_cap` edges (e.g., `rwx`, `send/recv`, etc.)
- `meta`: optional small map (policy-controlled)

## Intended uses
- “Why does this component still have authority X?” (audit)
- Leak tests: compare snapshots before/after an operation; diff edges/nodes.
- Runtime debugging: correlate cap graph with CH-LOG/CH-TRACE entries (via time window / epoch, not raw IDs).

## Validation obligations (PO candidates)
- PO-CAPG-BOUNDS: exporter enforces size bounds and fails closed.
- PO-CAPG-REDACT: exporter never emits forbidden fields (addresses, raw kernel IDs).
- PO-CAPG-SCOPE: exporter only emits graphs the caller is authorized to observe.

Refs: REF-GENODE-MANUAL, REF-CAPSICUM, REF-PLAN9.
