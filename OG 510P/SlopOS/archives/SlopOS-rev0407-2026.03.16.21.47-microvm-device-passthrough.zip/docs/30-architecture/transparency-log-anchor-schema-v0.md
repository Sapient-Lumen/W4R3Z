# CH-TLOG v0 (transparency log anchor, informal)

Purpose: provide a compact, verifiable “this digest was logged” record for release/provenance evidence.

Key design rule: the **kernel does not depend on the log**. Log anchoring is an evidence pipeline (D-TLOG).

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- anchors only small digests/metadata; large objects live elsewhere
- supports third-party auditing: checkpoint signatures + consistency progression

## Shape (v0)
An anchor record `t` contains:
- `schema`: fixed `CH-TLOG v0`
- `log_id`: identifier for the target log instance (string)
- `pubkey_id`: identifier for the log’s public key used to verify checkpoints
- `leaf_kind`: closed enum (e.g., `boot_digest`, `prov_digest`, `release_bundle_digest`, `proof_bundle_digest`)
- `leaf_digest`: digest of the anchored artifact
- `checkpoint`:
  - `tree_size`: u64
  - `root_hash`: bytes
  - `signature`: bytes (over `tree_size || root_hash`, exact format profile-specific)
- `inclusion_proof_digest`: optional digest of a stored inclusion proof object (kept out-of-band)
- `prior_checkpoint_digest`: optional digest link to an earlier checkpoint (for consistency verification)

Hybrid / replication note: if CH-TLOG artifacts travel under `object_family = tlog`, replicated checkpoints/proofs remain **evidence only**. They do not by themselves authorize boot/update/runtime actions, rotate trusted log keys/origins/witness sets, or supply global time/order semantics; those choices stay local explicit policy (see `tlog-replication-boundary-v0.md`).

## Verification obligations
- PO-TLOG-VERIFY:
  - checkpoint signature verifies against the pinned public key
  - if `prior_checkpoint_digest` present, the verifier checks consistency between checkpoints (append-only growth)
  - mismatch/verification failure is treated as “anchor invalid” (evidence rejected)

Refs: REF-CT-RFC6962, REF-TLOG-SWTCH, REF-TESSERA, REF-SIGSTORE-REKOR.
