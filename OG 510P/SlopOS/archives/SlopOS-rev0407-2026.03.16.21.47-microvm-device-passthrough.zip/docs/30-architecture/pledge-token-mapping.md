# Pledge token → effect mapping table (v0)

Purpose: make CH-PLEDGE `promises` **reviewable and testable** by keeping an explicit, small table that maps each token to:
- the privileged-effect families it allows (conceptual), and
- the concrete seams it gates (CH-KABI action kinds and portal intents).

This is intentionally coarse-grained and should change rarely.
Any change to this table is evidence-relevant for PO-PLEDGE-ENFORCE and AC-046.

References: REF-OPENBSD-PLEDGE, REF-CAPSICUM, REF-LANDLOCK.

## Conventions
- “Allows” means: *if the domain already holds the needed capability/handle*, it may exercise that effect. Tokens never grant authority.
- KABI action names are illustrative; the actual closed enum is CH-KABI v0.
- Portal intents are D-PLUMB families; portal rules and policy may still deny.

## Mapping table (seed)

| CH-PLEDGE token | Conceptual allowed effects | Concrete gated seams |
|---|---|---|
| `compute` | none beyond yield/exit | KABI: `sched.yield`, `proc.exit` |
| `ipc` | send/recv on held endpoints | KABI: `ipc.send`, `ipc.recv` |
| `thread` | spawn/join threads within held scheduling context | KABI: `thread.spawn`, `thread.join` |
| `vm` | map/unmap within held address-space caps | KABI: `vm.map`, `vm.unmap`, `vm.protect` |
| `view.resolve` | name resolution in held view objects | KABI: `view.resolve` |
| `view.mutate` | mount/bind/unmount in held view objects | KABI: `view.mount`, `view.unmount`, `view.bind` |
| `obs` | trace/log submission (low-risk, bounded) | KABI: `obs.emit`, `trace.emit`; IF-OBS export is NOT gated here |
| `portal.file` | request file-open/save/export workflows | Portal: `portal.file.*` (D-PLUMB; FileChooser/Documents/Export) |
| `portal.uri` | request OpenURI workflows (open links, open directory/show item) | Portal: `portal.uri.*` (D-PLUMB; OpenURI) |
| `portal.print` | request printing workflows | Portal: `portal.print.*` (D-PLUMB; Print) |
| `portal.device` | request device-selection/device-lease workflows | Portal: `portal.device.*` (D-DEVGUARD/D-IOLEASE; PickDevice/USB) |
| `portal.location` | request location workflows (one-shot/updates/geofences) | Portal: `portal.location.*` (D-LOCLEASE; CH-LOCLEASE) |
| `portal.secret` | request per-application secret seed workflows | Portal: `portal.secret.*` (D-APPSECRET; CH-APPSECRET) |
| `portal.clock` | request clock handles/leases (coarse by default; fine by explicit grant) | Portal: `portal.clock.*` (D-NONDET; CH-CLOCK) |
| `portal.entropy` | request entropy handles/leases (seed-by-default; deterministic for tests) | Portal: `portal.entropy.*` (D-NONDET; CH-ENTROPY) |
| `portal.inhibit` | request session-transition inhibition (idle/suspend/logout/shutdown) | Portal: `portal.inhibit.*` (D-INHIBITLEASE; CH-INHIBITLEASE) |
| `portal.net` | request outbound network leases/sessions | Portal: `portal.net.*` (D-NETLEASE) |
| `portal.capture` | request capture/remote-control sessions (camera/mic/screen/remote desktop) | Portal: `portal.capture.*` (D-CAPTURE) |
| `portal.xfer` | request clipboard/drag-drop/share transfer grants | Portal: `portal.xfer.*` (D-PLUMB adjunct; CH-XFER) |
| `portal.attn` | request notifications / attention prompts | Portal: `portal.attn.*` (D-ATTN; CH-NOTIF) |
| `portal.jobs` | request constraint-based background jobs | Portal: `portal.jobs.*` (D-JOBS; CH-JOBREQ) |
| `portal.background` | request background execution + login autostart grants | Portal: `portal.background.*` (D-BGLEASE; CH-BGREQ/CH-BGLEASE) |
| `portal.a11y` | request accessibility/automation sessions (UI observation/injection) | Portal: `portal.a11y.*` (D-UIAUT; CH-UIAUT) |

## Notes and footguns
- In “learn/complain” profiles (`violation = "deny"`), denied effects should emit a stable violation record. Tooling can then map observed denied CH-KABI kinds back to a minimal token set.
- `portal.*` tokens are about requesting *workflows*; they do not imply success. Policy may require D-EXPLAIN approval and/or D-VOLITION.
- `obs` here means “submit observability events”; exporting observations (IF-OBS) remains privileged and separately controlled.

## Change control
- Changes should be accompanied by: (a) a short RFC note, (b) updates to negative tests, and (c) an entry in the evidence index referencing the change.
- CI drift gate: `tools/check_pledge_token_mapping.py` enforces that this table covers the closed CH-PLEDGE v0 token set in `pledge-contract-schema-v0.md` exactly (no missing/extra/duplicate tokens). This keeps the token meaning surface stable for PO-PLEDGE-VALIDATE and PO-PLEDGE-ENFORCE.
