# CH-INHIBITLEASE v0: Inhibit lease descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **session transition inhibition** granted by an inhibit portal (D-INHIBITLEASE).
This schema is **not** the authority itself; it describes the bounds of an inhibition lease handle.
Phase-1 posture is pinned in `inhibit-lease-posture-v0.md`: leases are **close-to-release**, current-session scoped, and non-durable.

References: REF-XDG-PORTAL-INHIBIT, REF-SYSTEMD-INHIBITOR-LOCKS, REF-SYSTEMD-INHIBIT-MAN, REF-ANDROID-WAKELOCK.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-INHIBITLEASE v0 := {
  v: 0,

  ; which transitions are inhibited
  what: [* tstr],              ; non-empty set; closed elements:
                               ; "logout" | "switch_user" | "suspend" | "idle" | "shutdown"

  ; how the inhibition behaves
  mode: tstr,                  ; closed enum: "delay" | "block" | "block_weak"

  ; lifetime
  issued_at_s: uint,           ; monotonic time or policy-defined epoch seconds
  ttl_s: uint,                 ; lease duration (portal clamps)

  ; if mode == "delay", the maximum delay window before transition may proceed
  delay_grace_s?: uint,

  ; stable identifiers for attribution (no secrets)
  origin: {
    comp_id: tstr,             ; canonical component name/id (e.g., CH-COMP name), bounded
    instance?: tstr,
  },

  reason: tstr,                ; bounded, user-visible rationale

  ; policy posture hints (non-authoritative)
  background?: tstr,           ; closed enum: "no" | "while_in_use" | "always"

  redaction?: {
    mode: tstr,                ; closed enum: "none" | "hash_only"
  }
}

Notes:
- `block_weak` mirrors the common “weak block” concept: not enforced against privileged/system-initiated transitions.
- This descriptor does not contain capability material. The live inhibition lease is a handle/capability.

## Validation rules (minimum)
A CH-INHIBITLEASE validator MUST be total and fail closed:
1) `v == 0`.
2) `what` is non-empty, length-bounded, unique, and all entries are allowlisted.
3) `mode` is allowlisted.
4) `issued_at_s` and `ttl_s` are present and bounded; portal clamps ttl. The descriptor models a **currently active** live lease, not a future-dated or reboot/session-carried registration.
5) If `mode == "delay"`, `delay_grace_s` SHOULD be present and bounded; if present for non-delay modes it MUST be ignored or rejected by policy (profile choice).
6) `origin.comp_id` is present and bounded.
7) `reason` is bounded; unknown fields reject (or are rejected by canonical CBOR decode).

## Privacy notes
Inhibition grants leak some behavioral metadata (“this app is preventing suspend”). Exports SHOULD:
- treat CH-INHIBITLEASE as **sensitive metadata** in strict profiles,
- prefer `redaction.mode="hash_only"` for routine telemetry,
- avoid exports that would make long-lived inhibit presence a hidden persistence or behavior-tracking channel.
