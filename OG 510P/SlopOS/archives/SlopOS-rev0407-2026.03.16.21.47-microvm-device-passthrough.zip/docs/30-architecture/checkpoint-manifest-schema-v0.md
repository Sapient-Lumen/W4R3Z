# CH-CKPT v0 (checkpoint manifest schema, informal)

Purpose: represent a **bounded checkpoint bundle** for a set of components/domains, enabling checkpoint/restore and migration in user space (D-CHKPT) while preserving capability discipline (no authority amplification).

Design constraints (v0)
- Deterministic decode + canonical encoding (I-ENC-1; PO-ENC-DECODE).
- Restore is non-amplifying (I-CKPT-1; PO-CKPT-NOAMP).
- Artifacts are content-addressed (CH-AREF) and verified (PO-AREF-VERIFY, PO-CKPT-VALIDATE).
- Partial checkpoints are explicit: consumers must not assume completeness (I-CKPT-2).

## High-level shape (conceptual fields)

`CH-CKPT` is a single record with:
- `schema`: fixed string `"CH-CKPT"` and `version`: integer `0`
- `created_at`: UTC timestamp (string; canonical form per D-ENC)
- `profile`: string (e.g., `"dev"`, `"ops"`, `"migration"`) used only for policy/debug
- `components`: list of component identifiers (digest or name+digest)
- `scope`:
  - `kind`: `"single"` | `"set"` | `"system"`
  - `notes`: optional short string (non-authoritative)
- `view_snapshot`: optional CH-AREF pointer to a serialized view/namespace snapshot (if D-NS is enabled)
- `state_artifacts`: list of entries `{ component_id, kind, aref }` where:
  - `kind` is a closed enum: `"memory" | "cpu" | "ipc" | "files" | "device" | "app"`
  - `aref` is a CH-AREF pointer to the component-provided state bundle
- `cap_summary`:
  - `root_caps_digest`: digest of a redacted capability graph snapshot (CH-CAPG) or empty if not exported
  - `rules`: closed enum describing how caps were captured (e.g., `"cooperative-export"` only in v0)
- `restore_constraints`:
  - `requires_secrets`: bool
  - `requires_devices`: list of device class tags (closed enum list in v0)
  - `requires_monotonic_time`: bool (if replay/timestamps matter)
- `integrity`:
  - `manifest_digest_alg`, `manifest_digest`: binding for transcript/log anchoring
  - optional `signatures`: list (profile-dependent; use D-UPD-SIGN posture)

## Notes
- v0 assumes **cooperative export/import** (components implement a checkpoint RPC) rather than transparent interception.
- Checkpoint manifests are *not* themselves authority-bearing; they reference artifacts that are verified and loaded only under explicit restore authority.

Refs: RFC-0037, REF-CRIU, REF-DMTCP.
