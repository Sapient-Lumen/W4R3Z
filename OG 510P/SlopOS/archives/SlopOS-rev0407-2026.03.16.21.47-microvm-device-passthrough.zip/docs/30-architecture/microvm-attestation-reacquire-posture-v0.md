# MicroVM attestation-reacquire posture v0 (clone/restore invalidates attestation freshness and attestation-gated release sessions)

Purpose: pin the **Phase 1** reuse boundary between `ext.microvm` clone/restore acceleration and remote attestation / attestation-gated secret release so cached evidence does not quietly turn into a continuity substrate.

This doc attaches to **D-MICROVM**, **D-ATTEST**, **D-CC**, **D-APPSECRET**, and **D-VAULT** and makes one hard decision explicit:
**generation-witness change invalidates freshness-bound attestation exports and attestation-gated release sessions; they are reacquired, not resumed.**

## Posture (v0)

1) **Boot evidence stays boot-bound; freshness stays fresh**
   - `CH-ATTEST` / `CH-ATTESTPACK` remain **boot-bound observational exports** as pinned by `attestation-posture-v0.md`.
   - If a guest under `ext.microvm` is cloned or restored to a non-unique state, any later claim of **freshness** or **live current-instance proof** MUST come from a **fresh attestation exchange** with a fresh verifier challenge/nonce.
   - Replaying a pre-restore quote/token/document is never a valid substitute for a fresh post-restore export, even when the measured boot state is unchanged.
   - A fresh post-restore export still proves the current boot/provenance lineage and freshness binding only; exact resumed warm-state leaf identity stays on separate explicit lineage/admission evidence (`microvm-attestation-scope-posture-v0.md`).

2) **Generation witness is the local invalidation trigger**
   - The primary guest-visible generation witness from `microvm-generation-witness-posture-v0.md` is the Phase 1 trigger for invalidating cached attestation exports, verifier sessions, and challenge/response state that assumed unique uninterrupted execution.
   - Guests/runtimes MUST NOT wait for broken transport, expired TLS, changed IP/CID, or other incidental side effects to decide that attestation freshness must be reacquired.
   - VMClock / VMGenID still remain **observational signals**, not a new authority-bearing attestation claim or host↔guest management plane.

3) **Attestation-gated secret release is reacquired, not resumed**
   - Reusable warm-start templates stay **secret-clean**: the reusable snapshot cut happens before attestation-gated secret release or freshness-bound attestation state enters guest memory (`microvm-template-snapshot-cut-posture-v0.md`).
   - Secret-release results that depended on a prior attestation exchange — for example decrypted bootstrap material, data keys, unwrap grants, or provider-specific release sessions — MUST be treated as **generation-scoped**.
   - After generation-witness change, the runtime/provider MUST reacquire them through the existing explicit seam (`portal.secret`, D-VAULT provider flow, remote KMS/verifier exchange, or equivalent) using a **fresh attestation challenge** when freshness is required.
   - Snapshot/clone success MUST NOT turn those releases into ambient continuity handles, resumable secret sessions, or hidden “still valid because the VM came back” folklore.

4) **Local provider-owned secret objects keep their own posture**
   - This posture does **not** say that every local secret object is deleted or rotated on generation change; **blanket deletion** is not the Phase 1 rule here.
   - `D-APPSECRET` app seeds and `D-VAULT` provider-owned persistent secret references keep the semantics already pinned by their own postures.
   - What changes is narrower: any cache, session, or release predicate that depended on a **fresh attestation of this running instance** must be invalidated and re-established explicitly.

5) **No new ambient interop or ordering surface**
   - Phase 1 does **not** add a quote-cache broker, restore callback plane, verifier push channel, or generic ACP kind for “resume attestation/secret session after restore”.
   - Therefore this posture introduces **no new conflict-key family** and no new commutativity claim in Phase 1.
   - If a future externally visible management action exposes attestation/session reuse, it must specify conflict keys, retry semantics, serialization scope, and evidence separately rather than inheriting hidden ordering from snapshot success.

## Phase 1 non-goals (explicitly deferred)

- No portable quote/session cache protocol.
- No claim that remote verifiers must learn VM generation counters directly.
- No automatic deletion or auto-rotation of all local app/vault secrets on clone/restore.
- No new provider-specific parsing logic in the privileged core.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-ATTEST, D-VAULT, D-CC)
- Adjacent postures:
  - `microvm-snapshot-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `attestation-posture-v0.md`
  - `microvm-attestation-scope-posture-v0.md`
  - `app-secret-posture-v0.md`
  - `vault-posture-v0.md`
  - `microvm-template-snapshot-cut-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-4)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-ATTEST-REACQUIRE)
- Policy posture:
  - generation change invalidates freshness-bound attestation/release caches locally, but adds **no new lane**, **no new host↔guest callback exemption**, and **no new portable session-resume surface**.

CI drift gate:
- `tools/check_microvm_attestation_reacquire_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fresh challenge after generation change / attestation-gated release is reacquired not resumed / no blanket local-secret deletion / no new quote-cache plane** constraints, or drops its assurance/reference wiring.

## References

- REF-UAPI-VMGENID.
- REF-UAPI-VMCLOCK.
- REF-LINUX-TDX.
- REF-AWS-SNP-ATTEST.
- REF-AWS-NITROTPM-ATTEST.
