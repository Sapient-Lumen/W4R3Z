# CH-FDSET v0: capability-bound extra descriptor bindings (schema)

Purpose: eliminate ambient authority in workflow automation by making **extra child handles** (beyond stdin/stdout/stderr) explicit, typed, and bindable, rather than inherited from an ambient host handle/FD table.

CH-FDSET is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v2)`; the referenced pack binds `fdset_digest = digest(CH-FDSET v0)`.
- deterministic validators/runners **execute** only after validating the set and binding referenced descriptors to already-held handles.

CH-FDSET is **non-authoritative**:
- it MUST NOT contain bearer secrets or raw capability material,
- it MUST NOT be interpreted as a “permission grant,”
- and any binding to real handles MUST be checked against already-held authority (e.g., a bound CH-WALLET core digest).

Rationale: inherited file descriptor tables / inherited handle tables are a classic “workflow glue” ambient-authority seam.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- total decoding + fail-closed validation
- bounded sizes and closed enums
- **no bearer secrets** and **no raw capabilities**
- no ambient-authority surrogates (host paths, implicit TTY devices, inherited handle tables)
- stable for binding into CH-ACP / transcripts / receipts

## Data model (conceptual)

CH-FDSET v0 := {
  v: 0,

  ; Extra child-handle bindings. stdio (stdin/stdout/stderr) is modeled separately
  ; by CH-STDIO v0; CH-FDSET covers **only** additional slots.
  fds: [ FD ],

  note?: tstr,
  meta?: { * tstr => any }
}

FD := {
  ; A stable slot number for the child handle table.
  ;
  ; v0 seed convention:
  ; - slots 0..2 are reserved for stdin/stdout/stderr (CH-STDIO)
  ; - CH-FDSET entries MUST have slot >= 3
  ;
  ; This does NOT require a POSIX ABI; profiles map slots to whatever the
  ; child launch mechanism uses (FD table, handle table indices, etc.).
  slot: uint,

  ; v0 seed: only bindings backed by CH-DOCREF v0.
  kind: "docref",
  docref_digest: bstr
}

### Notes (v0)
- CH-FDSET uses `CH-DOCREF v0` as the only descriptor reference in v0.
  - `docref_digest` requires a file-like handle suitable for passing to the child.
  - Rights are enforced by the bound handle rights (not by CH-FDSET fields).
- CH-FDSET does **not** model acquiring handles from ambient namespaces (paths/env/implicit net).
- CH-FDSET does **not** permit inheriting an ambient parent handle table: the runner MUST construct the child handle table from CH-STDIO + CH-FDSET only.
- CH-FDSET also does **not** smuggle in PTY master/slave handles, controlling-terminal selectors, or shell job-control/session authority as a side channel; Phase 1 keeps those out of the portable capshell seam (`capshell-job-control-posture-v0.md`).

## Validation rules (minimum)

A fdset validator MUST be total and fail closed (PO-FDSET-VALIDATE):
1) `v == 0`.
2) `fds` is present (may be empty) and bounded.
3) Each FD has `kind` in the closed enum (v0: `docref`).
4) `slot` is bounded, `slot >= 3`, and slots are unique.
   - Strict profiles SHOULD require `fds` entries be sorted by ascending `slot`.
   - If `cfg.params.capshell.minimal_context=true`, validators MUST require `fds` to be empty for `capshell.exec` contexts (PO-CAPSHELL-MINCTX-ENF).
5) For `docref` bindings: `docref_digest` length matches profile hash.
6) Unknown keys reject (or are rejected by canonical CBOR decode).

## Binding semantics (capshell runner)

CH-FDSET is a **veto-only** structure:
- It never grants authority (I-FDSET-1).
- Runners MUST NOT inherit ambient host handle/FD tables.

When `capshell.exec` (via CH-EXECPACK) binds `fdset_digest`:
- The runner MUST start the child with **only**:
  - stdio bindings from CH-STDIO (slots 0..2), and
  - additional bindings from CH-FDSET (slots >= 3).
  Any inherited extra handles MUST be treated as a policy violation and must fail closed.
- The runner MUST check that every `docref_digest` reference corresponds to already-held authority in the execution context (wallet/handle inventory).
- If any reference is unknown/unavailable/unbindable, execution MUST fail closed and be transcript-visible (I-FDSET-2; PO-CAPSHELL-FDSET-BIND).
- Rejects SHOULD emit CH-DENY with deny_code `fd-bind-failed`, binding:
  - `reason.kind="schema"`
  - `reason.ref_schema="CH-FDSET v0"`
  - `reason.ref_digest=fdset_digest`

Notes:
- The mechanism for passing bound handles to children is profile-defined (FD passing, handle tables, view binding, etc.), but the **no ambient inheritance** rule is invariant and the reviewed launch posture is pinned in `capshell-handle-table-posture-v0.md`.
- CH-FDSET bindings are **child-local**: a runner/orchestrator MUST NOT re-export a bound slot from one child into another sibling as implicit pipeline inheritance; any next-stage authority must be rebound in that stage's own CH-EXECPACK v2 (see `capshell-pipeline-posture-v0.md`).
- CH-FDSET composes with CH-ARGV/CH-ENV/CH-CWD/CH-STDIO: argv/env/cwd/stdio/fdset are independent, explicit seams, each validated and bound fail-closed.
