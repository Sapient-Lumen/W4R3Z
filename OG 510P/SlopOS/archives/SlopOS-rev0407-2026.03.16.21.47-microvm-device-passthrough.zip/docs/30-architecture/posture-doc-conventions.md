# Posture doc conventions (v0)

Purpose: keep **v0 posture** docs small, comparable, and lintable so they resist drift and “LLM amnesia”.

A *posture doc* is a Phase‑1 scoped **meaning pin** for a decision surface (D-*).
It is intentionally **not** a full API spec.

## Required shape

Every v0 posture doc under `docs/30-architecture/` (as listed in `posture-index.md`) MUST include the following sections (in order):

1) `## Posture (v0)`
   - Normative rules using MUST/SHOULD/MAY.
   - Keep it tight: prefer ≤ 12 numbered rules.

2) `## Phase 1 non-goals (explicitly deferred)`
   - List the tempting expansions we are *not* doing yet.
   - If there are no meaningful non-goals, write `- None.`

3) `## Wiring`
   - Link the posture to:
     - the decision surface (`decision-map.md`),
     - any CH-* schemas involved,
     - any portal families / ACP kinds touched,
     - relevant invariants / proof obligations / claim surfaces,
     - and the policy knobs (lane gates) that keep sealed-compat killable.

4) `## References`
   - List ≥ 1 `REF-*` entry (no pasted external text).
   - Prefer primary specs/papers/repos.

## Drift gate expectations

- Most posture docs SHOULD have a dedicated drift gate script under `tools/` (typically named `check_<topic>.py`) and an EVID entry.
- If a posture intentionally has **no** dedicated drift gate, say so in `## Wiring` and point at the existing checks that cover it.

## Template (copy/paste)

Use this as a starting point when adding a new v0 posture doc:

- H1: `# <surface> posture v0 (<one-line meaning pin>)`
- Purpose: 2–6 lines.
- `## Posture (v0)` (numbered rules)
- `## Phase 1 non-goals (explicitly deferred)`
- `## Wiring` (links + anchors + CI note)
- `## References` (REF-* list)
