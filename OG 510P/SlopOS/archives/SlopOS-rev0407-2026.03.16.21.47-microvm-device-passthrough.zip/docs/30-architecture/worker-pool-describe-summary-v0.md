# Worker-pool Describe summary v0 (exact `Describe()` result contract)

Purpose: pin one exact family-local meaning for the bounded `Describe()` result on the first concrete **D-CONSTR** worker-pool family so callers, harnesses, and future tooling do not drift into equivalent-but-different summary objects.
This doc narrows an already-chosen surface: it does **not** introduce a generic pool schema, a metrics tree, or a second diagnostics/control plane.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-QUIESCE**, **D-COMMUTE**, **D-CAPRPC**
- assumes the exact `pool.control` handle contract is already fixed by `worker-pool-control-surface-v0.md`
- assumes the exact digest-first invocation object is already fixed by `worker-pool-invocation-manifest-v0.md`
- assumes the exact pool-level `quiesce_state` meaning is already fixed by `worker-pool-quiesce-state-v0.md`
- assumes the exact `worker_slots[*].state` vocabulary is already fixed by `worker-pool-slot-state-v0.md`
- assumes the exact `worker[i]` contract is already fixed by `worker-pool-worker-surface-v0.md`
- does **not** introduce a generic report schema, a watch/list surface, or a richer per-worker diagnostics vocabulary

## Phase-1 choice

1) **`Describe()` returns one closed data-only summary object, not an implementation-defined status tree**
   - The portable `Describe()` result is one bounded family-local object for the current pool instance only.
   - The top-level field set is closed to exactly `v`, `invocation_manifest_digest`, `pool_size`, `quiesce_state`, optional `qid`, and `worker_slots`.
   - Phase 1 declines extra top-level keys for metrics, timestamps, target names, helper identities, counters, host locators, or implementation-defined extension bags on the canonical summary surface.

2) **`v`, `invocation_manifest_digest`, and `pool_size` are exact identity/binding fields**
   - `v` is exactly `0` in Phase 1.
   - `invocation_manifest_digest` MUST equal the canonical digest-first object pinned in `worker-pool-invocation-manifest-v0.md`.
   - `pool_size` MUST be in `1..64` and MUST match the `pool_size` encoded under `digest(CH-WPOOLPARAM v0)` through that same `invocation_manifest_digest`.
   - These fields do not vary with current worker occupancy, quiesce progress, or host/runtime internals.

3) **`quiesce_state` and `qid` follow one exact presence rule**
   - `quiesce_state` is closed to {`running`, `quiescing`, `quiescent`} exactly, with the exact pool-level meaning pinned in `worker-pool-quiesce-state-v0.md`.
   - `qid` is absent when `quiesce_state = running`.
   - `qid` is present exactly once when `quiesce_state` is `quiescing` or `quiescent`, and it MUST be the current active quiesce identifier for that pool instance.
   - Phase 1 adds no nested quiesce objects, no arrays of active maintenance actions, and no free-form mode/result strings on the canonical summary object.

4) **`worker_slots` is one exact ordered slot table**
   - `worker_slots` is an array of length exactly `pool_size`.
   - Entries are ordered strictly by ascending `slot`, starting at `0` and ending at `pool_size - 1`, with no duplicates or gaps.
   - Each entry's field set is closed to exactly `slot` and `state`.
   - `slot` MUST equal the array position and `state` MUST use the exact vocabulary pinned in `worker-pool-slot-state-v0.md`.

5) **The summary stays observational and does not smuggle new authority or identity**
   - `Describe()` is data-only and observational; it does not change the typed business interface behind `worker[i]` and does not grant new control authority.
   - The canonical summary MUST NOT expose host PIDs/TIDs, worker occupant epochs, restart counters, retry timers, stack traces, import inventories, sponsor identity, or raw capability material.
   - Any richer diagnostics stay on explicit evidence/log/inspection seams rather than hitchhiking on `Describe()`.

6) **Comparison semantics are exact and replay-friendly**
   - Normalized comparison keys only off the closed field set above.
   - Two portable `Describe()` results for the same instant are equivalent only if all canonical fields match after ordinary encoding normalization; tool-local pretty printing or host-native status names are non-authoritative.
   - This keeps `Describe()` stable across native, compat, and hosted implementations without turning it into a second evidence pack.

7) **Commutativity and serialization stay unchanged**
   - `Describe()` remains observational-only and therefore **commutes** with all other actions on this family.
   - `BeginQuiesce(mode)` / `EndQuiesce(qid)` stay the only mutators on `pool.control`; pinning the summary object does not introduce a new sequencing surface.
   - Any non-commutativity still lives on the pool-control seam and the existing target seam, not in summary production.

8) **Sealed compat remains honest**
   - Hosted or compat implementations MAY derive this summary from richer runtime state behind the membrane.
   - The portable surface still remains the exact bounded object above, with the same field names and presence rules.
   - If an implementation cannot provide the closed summary without ambient side channels or host-specific extension keys, it must fail closed or keep that widening non-portable and policy-killable.

## Out of scope in v0

- A generic report/status schema shared by future constructor families.
- Any watch/stream/list/search surface for pool summaries.
- Any per-slot restart counters, retry timers, or occupant epoch identifiers on the portable summary object.
- Any host-native extension bag or opaque implementation-defined metadata under `Describe()`.
- Any claim that the summary object itself is a durable evidence artifact.

## Wiring

- Decision surface: **D-CONSTR**.
- Adjacent seams: `worker-pool-constructor-family-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-invocation-manifest-v0.md`, `worker-pool-quiesce-state-v0.md`, `worker-pool-slot-state-v0.md`, `worker-pool-worker-surface-v0.md`, `quiesce-posture-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-DIAGNOSTICS**, **REF-GENODE-INIT**, **REF-SYSTEMD-SERVICE**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_describe_summary.py` (**EVID-2026-374**).
