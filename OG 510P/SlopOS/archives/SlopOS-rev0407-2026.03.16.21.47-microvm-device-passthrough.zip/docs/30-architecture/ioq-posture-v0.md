# D-IOQ posture v0 (provider-owned single-op queues; no path/chain/message drift)

Purpose: pin an implementable v0 meaning for **D-IOQ** so high-throughput batching stays a small provider-owned transport seam rather than drifting into a programmable async syscall kitchen sink, hidden authority broker, or second workflow/control plane.
It narrows RFC-0107 into one compact posture validators and harnesses can reason about: explicit handle targets, bounded single-op submissions, explicit completion rings, and no new workflow/ACP surface.

## Posture (v0)

1) **Optional provider-owned batching seam, not a general async syscall substrate**
   - If D-IOQ is enabled, it is a **low-level runtime / server / driver-host primitive** for batching operations against an explicit provider/service.
   - Phase 1 does **not** standardize a kernel-global “submit arbitrary syscalls asynchronously” substrate, a generic packet router, or an application-facing programmable I/O VM.
   - The queue is a transport/performance seam over already-authorized operations, not a new authority source (I-IOQ-1; I-IOQ-3).

2) **Queue scope is provider-owned and opcode-closed in v0**
   - An IoQueue instance is created by or against one explicit provider / service boundary, and the portable opcode set for that queue is **closed and declared** by that provider.
   - Phase 1 does **not** standardize a kernel-global opcode catalog shared across unrelated subsystems, nor a queue that can silently mix unrelated provider families by ambient lookup.
   - This keeps review, policy, and proof obligations attached to the owning subsystem rather than hidden in the queue runtime.

3) **Targets are explicit handles only; no path/open/create constructors on the core seam**
   - Submission entries may target only **explicit handles/capabilities already held by the caller** plus explicit shared buffers when D-IOBUF is enabled.
   - Phase 1 therefore does **not** standardize `openat`/`openat2`/`mkdirat`/`renameat`/`unlinkat`-style path constructors, ambient namespace lookup, or queue-created descriptors/files on D-IOQ itself.
   - Any future path-oriented or namespace-crossing async surface must land RFC-first on the owning namespace/filesystem seam rather than widening D-IOQ by analogy.

4) **One SQE is one operation; portable v0 declines chains, hard-links, and multishot semantics**
   - The portable submission contract is **one submission entry describes one operation attempt**.
   - Phase 1 does **not** standardize linked chains, hard-linked dependency graphs, multishot receives/accepts, or “one submission yields an unbounded stream of completions” semantics on the portable seam.
   - Sequencing across multiple operations remains explicit in user space or on higher-level workflow surfaces rather than being smuggled into ring flags.

5) **Completions are explicit ring records, not a second packet/control plane**
   - Completion delivery stays on the queue’s own bounded completion ring / dequeue path.
   - Portable completion records are limited to **`user_tag + status + bounded result fields`**; tags are caller-chosen correlation data and are always untrusted (I-IOQ-3).
   - Phase 1 does **not** standardize user-injected completion packets, cross-queue message delivery, or arbitrary opaque payload blobs on D-IOQ itself.

6) **No credential/personality override or hidden authority rebinding in v0**
   - Operations execute with the authority already represented by the caller’s explicit handles/capabilities and the queue/provider contract.
   - Phase 1 does **not** standardize per-SQE credential override, personality switching, or hidden authority rebinding knobs on D-IOQ.
   - This prevents the batching seam from becoming a second authorization surface that is harder to review than the underlying provider API.

7) **No portable preregistered handle/buffer inventory on the core seam**
   - Implementations MAY internally cache validation or pin buffers, but portable v0 does **not** standardize a public preregistered handle table, sparse slot inventory, or queue-local file/buffer registry API.
   - Callers still reason in terms of explicit handles and explicit shared buffers (D-IOBUF) rather than a second mutable index space with hidden lifetime/replace rules.
   - Any future public registration surface must land RFC-first with explicit bounds, replacement semantics, and policy visibility rather than hitchhiking on performance pressure.

8) **D-WAITSET integration is observational only**
   - When D-WAITSET is enabled, an IoQueue MAY expose readiness bits such as `CQ_READABLE`, optional `SQ_AVAILABLE`, and `PEER_CLOSED`.
   - Waiting remains observational: D-WAITSET reports queue state, while completion payloads stay on the explicit completion ring/dequeue path.
   - D-IOQ therefore composes with D-WAITSET without collapsing the two seams into one packet bus.

9) **Cancellation/deadlines stay on explicit adjunct surfaces**
   - If submissions carry `ctx_digest`, cancellation/deadline behavior composes with D-REQCTX rather than inventing a second timeout/cancel system inside D-IOQ.
   - Any cancelled operation must complete explicitly and must not continue silently in the background after the caller is told it was cancelled.
   - Phase 1 does **not** assume ambient clocks, hidden timeout policy, or queue-global scheduler knobs on this seam.

10) **Bounded, attributable, and deterministic under pressure**
   - Queue depth, outstanding operation count, completion backlog, and teardown work MUST be bounded and attributable when D-METER is enabled (I-IOQ-2; PO-IOQ-BOUND).
   - Overflow/backpressure behavior is explicit and deterministic rather than silent drop or hidden allocation.
   - High-pressure cases SHOULD surface as explicit provider/backpressure signals rather than widening the queue into an unbounded broker.

11) **Conflict keys and commutativity come from the owning provider, not the queue transport**
   - D-IOQ v0 does **not** create a new semantic action family for the operations carried inside it.
   - Each queued operation inherits the conflict key(s), commutativity preconditions, and serialization boundary of the underlying provider/service action it invokes; the queue transport itself must not invent contradictory queue-local conflict domains.
   - If an operation family is non-commutative, serialization lives where it already lives for that provider (validator / service boundary), and evidence remains on that surface rather than in hidden ring scheduler behavior.

12) **No new workflow / ACP / conflict-key family surface in v0**
   - D-IOQ v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
   - Therefore **no new conflict-key family is introduced in v0**.
   - Any future queue-admin/export/workflow seam (for example, public registration tables, chain execution, or queue-to-queue messaging) must land RFC-first with its own serialization boundary, receipts, and policy kill switches.

13) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY use an internal host/runtime io_uring / I/O Rings / driver fast path behind the membrane, but Phase 1 does **not** standardize a compat-visible fd/path/env bridge, ambient host queue broker, or hidden queue-sharing substrate.
   - Any compat enablement remains policy-killable and must not recreate ambient namespace or control channels that bypass D-FCELL posture.

## Phase 1 non-goals (explicitly deferred)

- A kernel-global async syscall kitchen sink.
- Path-oriented open/create/rename/unlink constructors on D-IOQ itself.
- Linked / hard-linked submission chains, multishot semantics, or queue-to-queue message injection.
- Per-SQE credential/personality override.
- A public preregistered file/buffer inventory API on the portable seam.
- New workflow / ACP / admin surfaces around queues.

## Wiring

- Decision surface: `decision-map.md` (D-IOQ).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (IoQueue seam)
  - `rfcs/0107-io-submission-queues-and-completions.md` (option space / evidence seed)
  - `docs/30-architecture/waitset-posture-v0.md` (observational wait integration)
  - `docs/30-architecture/io-buffer-schema-v0.md` (explicit shared buffers when D-IOBUF is enabled)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-IOQ-1, I-IOQ-2, I-IOQ-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-IOQ-BOUND, PO-IOQ-NOAMP)
  - `docs/30-architecture/commutativity-and-interface-scalability.md` (underlying-provider serialization boundary discipline)
  - `docs/30-architecture/waitset-posture-v0.md` (completions stay off the wait seam)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_ioq_posture.py` fails `make lint` if this posture stops being discoverable, loses the explicit-handle / no-path-constructors / no-chain-or-message-ring posture, or drops its primary REF wiring.

## References

- REF-LINUX-IOURING-PDF.
- REF-LINUX-IOURING-ENTER.
- REF-LINUX-IOURING-REGISTER.
- REF-WIN-IORING-OVERVIEW.
- REF-WIN-IORING-REGISTERFILEHANDLES.
- REF-WIN-IORING-REGISTERBUFFERS.
