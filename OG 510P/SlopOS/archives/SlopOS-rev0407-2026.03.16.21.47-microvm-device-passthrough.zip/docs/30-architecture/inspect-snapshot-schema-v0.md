# CH-INSPECT v0 (inspect tree snapshot schema, informal)

Purpose: export a **bounded, canonical snapshot** of a component’s structured diagnostics tree (“inspect tree”).

This is conceptually similar to Fuchsia Inspect’s structured diagnostics model, but CH-INSPECT is the **export** shape used for hashing, signing, bundling, and redaction policy.

Refs: REF-FUCHSIA-INSPECT, REF-FUCHSIA-INSPECT-FORMAT.

## Constraints (v0)
- deterministic decode + canonical bytes suitable for hashing/signing (I-ENC-1)
- closed set of value types (no arbitrary JSON)
- bounded size (per-node and total)
- no secrets by default; redaction/minimization is explicit (I-OBS-1)
- avoid stable pointers/addresses and bearer tokens

## Shape (v0)
An inspect snapshot `s` contains:
- `schema`: fixed `CH-INSPECT v0`
- `domain`: optional bounded tag for the emitting domain/component instance (opaque)
- `ts`: optional timestamp (only if enabled by profile)
- `tree`: a canonical list of nodes

### Node record
Each node `n` contains:
- `path`: canonical list of UTF-8 segments (bounded length per segment; bounded segment count)
- `props`: canonical list of properties
- `redaction`: optional enum tag (`public` | `sanitized` | `sensitive`) used by bundle assemblers

Canonical ordering:
- nodes are sorted lexicographically by `path` (segment-wise)
- properties are sorted lexicographically by `name`

### Property record
Each property `p` contains:
- `name`: UTF-8 string (bounded)
- `kind`: closed enum
- `value`: typed value

Allowed `kind` variants (v0):
- `counter_u64` (monotonic counter)
- `gauge_i64`
- `bool`
- `small_str` (bounded UTF-8; MUST be treated as non-secret)
- `small_bytes` (bounded bytes; intended for digests/ids)

Notes:
- arrays/histograms are intentionally excluded from v0; encode as derived counters/gauges.
- `small_bytes` MUST NOT carry bearer material (e.g., CH-SREF secrets) unless explicitly authorized and redaction-marked.

## Validation obligations (PO-INSPECT-VALIDATE)
- reject unknown `kind` values
- enforce bounds on:
  - total nodes
  - total properties
  - segment lengths and counts
  - `small_str` and `small_bytes` lengths
- reject obvious bearer tokens and raw addresses/pointers under the active export policy

## Collector bounds + rate posture (PO-INSPECT-BOUNDS)
Collectors/archivists MUST enforce:
- max inspect-region size per component instance
- max snapshot size per export
- deterministic overflow behavior (drop newest, drop oldest, or reject) as configured by profile

## Redaction guidance
- default exports should include only `public` + `sanitized` nodes
- `sensitive` nodes require explicit authority/scope in the snapshot policy
- secret references should appear only as *digests* (e.g., CH-KEYREF / CH-SECRETREF) unless explicitly authorized
