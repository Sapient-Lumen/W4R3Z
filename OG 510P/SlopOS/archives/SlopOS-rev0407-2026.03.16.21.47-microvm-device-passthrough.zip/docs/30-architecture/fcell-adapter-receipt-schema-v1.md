# CH-FADAPT v1: Foreign-cell adapter receipt (schema)

Purpose: same as CH-FADAPT v0, with an optional request-context hook for correlation and veto-only policy.

CH-FADAPT pins the “portal/intent/receipt” seam for sealed compatibility (D-FCELL):
- the **cell** requests a legacy ABI operation,
- an **adapter** translates it into a portalized host workflow,
- the host returns **handles/leases** (never ambient strings), and
- the adapter emits a receipt describing *what portal family was used* and *what handle(s) were issued*.

**New in v1:** `reqctx_digest?: bstr` = `digest(CH-REQCTX v1)`.
- Non-authoritative.
- Used for correlation/deadline/cancel intent and veto-only narrowing (never grants authority).
- When an adapter operation is initiated within an ACP action or a workflow message that already carries a request-context digest, v1 receipts SHOULD propagate the same digest.

Compatibility:
- CH-FADAPT v0 remains valid and unchanged.
- v1 is an additive evolution for profiles that want tighter end-to-end correlation without ambient context.

**Important:** CH-FADAPT is **non-authoritative**.
It MUST NOT carry bearer secrets, raw capability tokens, or ambient authority surrogates (paths, env, implicit network names).

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-FADAPT v1 := {
  v: 1,

  ; identity / binding
  cell_id: bstr,                 ; must match the launched CH-FCELL.cell_id (digest-sized; D-TYPEDID)
  manifest_digest?: bstr,         ; optional digest(CH-FCELL) to bind the instance to its manifest
  policy_digest?: bstr,           ; optional digest(CH-POLICY v0) or digest(CH-POLICYHANDLE v0) used at decision time

  ; what happened (bounded, deny-only audit)
  abi_op_id: tstr,                ; closed-set op id (from the runtime's ABI surface)
  adapter_kind: tstr,             ; closed allowlist (see fcell-adapter-kind-registry.md)
  portal_token: tstr,             ; CH-PLEDGE `portal.*` token used by the adapter

  ; request/result correlation (never authoritative)
  request_schema?: tstr,          ; e.g. "CH-PLUMBMSG" | "CH-JOBREQ" (if a bounded request artifact exists)
  request_digest?: bstr,          ; digest(request_schema vN) when request_schema is present

  ; request context (optional; veto-only; non-authoritative)
  reqctx_digest?: bstr,           ; digest(CH-REQCTX v1) (I-REQCTX-3)

  ; outcome
  result: {
    code: tstr,                   ; "ALLOW" | "DENY" | "ERROR" (closed set)
    reason?: tstr                 ; deny_code token (see deny-code-registry.md); no raw host paths
  },

  ; handles/leases issued to the cell (identifiers only)
  issued: [
    {
      kind: tstr,                 ; e.g. "docref" | "netlease" | "clock" | "entropy" | "iolease" | "xfer" | "capture" | "uiaut" | "bglease" | "budget"
      digest: bstr                ; digest(CH-*) of the issued bounded descriptor (or digest(handle descriptor))
    }
  ]

  ; optional commutativity observability hooks
  conflict_key_digest?: bstr,     ; digest(CH-CONFLICTKEY v0) for cell-scoped ordering/sharding
  order_digest?: bstr             ; digest(CH-ORDERTOK v0) if adapter ops are serialized within a stream
}

Notes:
- `issued[*].digest` refers to digests of **descriptor artifacts** (CH-DOCREF, CH-NETLEASE, CH-IOLEASE, etc.), not to bearer capabilities.
- `result.reason` (when present) is a **deny_code** token from `deny-code-registry.md` (e.g., `lane-disabled`, `policy-deny`, `internal-error`).
- `reqctx_digest` is for correlation and veto-only decisions. It MUST NOT be used as authorization evidence.
- Hybrid note: if CH-FADAPT artifacts are replicated under `object_family = receipt`, they remain immutable evidence only; replicated receipts cannot resurrect issued handles/leases, skip local adapter policy, or become a remote host-effect admission cache (`receipt-replication-boundary-v0.md`).

## Validation rules (minimum)
Validators MUST be total and fail closed (PO-FADAPT-VALIDATE):

1) `v == 1` and required fields present.
2) `portal_token` MUST be a valid CH-PLEDGE `portal.*` token.
3) `abi_op_id` MUST be a member of the runtime’s closed ABI surface for the launched cell (I-COMPAT-2).
4) `adapter_kind` MUST be in the manifest’s `interop.adapters.enabled` allowlist (deny wins), MUST be a member of the canonical closed set in `fcell-adapter-kind-registry.md`, and must be profile-gated.
5) `issued[*].kind` is a closed allowlist and `issued[*].digest` has bounded length.
6) `result.code` is in the closed enum. If `result.code == "ALLOW"`, `result.reason` MUST be absent. If `result.code` is `"DENY"` or `"ERROR"`, `result.reason` MUST be present and MUST be a `deny_code` from `deny-code-registry.md`.
7) If `reqctx_digest` is present, it MUST have the profile digest length and MUST refer to CH-REQCTX v1 canonical bytes.
8) **Non-authoritative rule:** the record contains no bearer secrets and no ambient authority surrogates.

## Usage / obligations

- **I-COMPAT-1 / PO-COMPAT-NOAMBIENT:** any host effect on behalf of a foreign cell MUST be portalized; the presence of CH-FADAPT receipts is how we make this auditable.
- **D-FCELL lane killability:** when `cfg.params.lane.fcell=false`, adapters MUST NOT emit `ALLOW` receipts; they must deterministically emit `DENY` receipts with `reason=lane-disabled`.
- **Hybrid note:** `conflict_key_digest` SHOULD be `family="cell.adapter" payload={cell_id, portal_token}` for sharding; ordered streams (if any) must be scoped to that key (I-ORDERTOK-2). See `fcell-commutativity-contract-v0.md` for the pinned posture.

Request-context propagation (optional, profile-defined):
- If an adapter operation is initiated by an ACP action that carries `meta.reqctx_digest`, or by a workflow message that carries a CH-REQCTX digest, the adapter SHOULD include the same `reqctx_digest` in the CH-FADAPT v1 receipt.
- Consumers may use `reqctx_digest` only for correlation and veto-only narrowing (I-REQCTX-3). It must not be used to grant authority.

## Evidence hooks (seed)

- Correlation test: when a compat adapter op is initiated by an ACP action, the emitted CH-FADAPT v1 receipt carries the same `reqctx_digest` as the initiating action and CH-LOG/CH-ACPOUT entries.
