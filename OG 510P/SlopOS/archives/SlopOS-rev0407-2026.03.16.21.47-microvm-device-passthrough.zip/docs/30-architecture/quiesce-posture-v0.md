# D-QUIESCE posture v0 (cooperative component-local quiesce; no global freeze/orchestration drift)

Purpose: pin an implementable v0 meaning for **D-QUIESCE** so maintenance operations stay a small cooperative control seam instead of widening into a global freezer, hidden service-manager policy surface, migration/checkpoint promise, or ambient process-tree stop mechanism.
It narrows RFC-0108 into one compact posture validators and harnesses can reason about: one active quiesce epoch per component instance, explicit new-work gating, bounded drain/cancel outcomes, and no new workflow/ACP surface.

## Posture (v0)

1) **Optional cooperative maintenance seam, not a mandatory global stop framework**
   - If D-QUIESCE is enabled, it is a **component-local control contract** that supervisors/checkpoint tooling MAY use when a component explicitly implements it.
   - Phase 1 does **not** require every component to implement D-QUIESCE, and components that do not implement it remain crash-only from the supervisor's point of view.
   - The seam exists to make maintenance behavior explicit where adopted, not to smuggle in a universal lifecycle manager.

2) **Quiesce is explicit control authority; observation remains non-amplifying**
   - `BeginQuiesce` / `EndQuiesce` require an explicit control handle/capability already held by the caller.
   - Observing quiesce state (status polling or optional signal bits / CH-QUIESCE descriptors) does **not** create authority or bypass existing capability checks (I-QUIESCE-1).
   - Phase 1 therefore treats quiesce as control authority, not as a side door into objects or a replacement for ordinary auth checks.

3) **Exactly one active quiesce epoch per component instance in v0**
   - A component instance has at most **one** active `qid` at a time.
   - If `BeginQuiesce(...)` arrives while the instance is already `QUIESCING` or `QUIESCENT`, the call MUST fail deterministically with an equivalent of `QUIESCE_ACTIVE` and the current `qid`; Phase 1 declines nesting, stacking, implicit grace extension, and mode merge rules.
   - This keeps maintenance coordination reviewable and prevents quiesce requests from turning into an implicit queue or policy language.

4) **The portable state machine is small and closed**
   - Phase 1 pins the control state machine to `RUNNING -> QUIESCING(qid, mode) -> QUIESCENT(qid) -> RUNNING`.
   - v0 does **not** standardize extra lifecycle states such as `FREEZING`, `FROZEN`, `PARTIALLY_QUIESCENT`, `DRAINING_SUBTREE`, or `MAINTENANCE_PENDING`.
   - Invalid transitions and stale/non-current `qid` values MUST reject deterministically (PO-QUIESCE-STATE).

5) **Only two modes in v0: `DRAIN` and `CANCEL`**
   - `DRAIN` means: gate new externally triggered work and allow already-started work to finish until the relevant explicit deadline/cancel authority says otherwise (for example via D-REQCTX when enabled).
   - `CANCEL` means: gate new externally triggered work and actively request cancellation of in-flight work, with explicit outcomes tied to request contexts where present.
   - Phase 1 declines `SUSPEND`, `FREEZE`, `PAUSE`, `CHECKPOINT_ONLY`, priority classes, and policy-specific maintenance modes.

6) **New-work gating must be complete; queue-behind-boundary is never implicit**
   - Once `QUIESCING`, externally triggered entrypoints that would start new work MUST reject deterministically with a quiesce-specific outcome unless that interface explicitly declares bounded queue-behind-boundary semantics.
   - There is no hidden “accept now, start later after quiesce” behavior in the base posture.
   - This keeps drain behavior testable and prevents maintenance from becoming a silent backlog/replay mechanism (PO-QUIESCE-GATE).

7) **Canceled work must not continue silently in the background**
   - If an operation is reported canceled because of quiesce or deadline, the component MUST NOT continue that operation silently in the background (I-QUIESCE-2).
   - Cleanup/rollback work MAY continue if it is internal to making the cancellation outcome true, but that internal work must not produce the original external effect later as if cancellation never happened.
   - Phase 1 therefore declines “best-effort cancel” semantics that still allow the original effect to surface after the caller has been told it was canceled.

8) **Waitability is observational adjunct only**
   - When D-WAITSET is enabled, a control handle MAY expose a `QUIESCENT` signal bit so supervisors can wait efficiently without polling.
   - The wait seam remains observational: it reports readiness/state, not maintenance payload packets or hidden control messages.
   - Any portable transcript/state export continues to use explicit status/descriptor surfaces such as CH-QUIESCE rather than piggybacking payloads on waiting.

9) **Escalation is outside D-QUIESCE; force-kill is a supervisor/runner policy, not a quiesce opcode**
   - D-QUIESCE is the cooperative step. Escalation after a bounded grace period lives in D-SUPV / runner policy, not on the core D-QUIESCE seam.
   - Phase 1 therefore does **not** add `ForceQuiesce`, `KillAfter`, or subtree-kill semantics to the portable quiesce contract.
   - This keeps the maintenance handshake small and avoids embedding service-manager policy in the component-local control API.

10) **Checkpoint/restart/migration compose with quiesce but are not promised by it**
   - Reaching `QUIESCENT` means “this component has stopped starting new external work and has drained/canceled in-flight work according to the chosen mode”; it does **not** by itself promise exportability, live migration safety, or transparent checkpoint support.
   - Checkpoint/export/state handoff remain explicit adjunct seams under D-CHKPT / D-ACTIVATE.
   - Phase 1 therefore declines any claim that `BeginQuiesce(DRAIN)` is itself a portable checkpoint or migration primitive.

11) **No tree/global ordering semantics in the core seam**
   - D-QUIESCE v0 is **component-local**: it does not define recursive subtree quiesce, dependency-order traversal, or realm/pod/process-tree freeze semantics.
   - Supervisors MAY orchestrate ordering across multiple components using explicit topology/dependency knowledge, but that orchestration lives outside the core seam and must stay reviewable in D-SUPV / deployment policy.
   - This prevents D-QUIESCE from silently becoming a hidden global orchestrator or kernel freezer surface.

12) **No new workflow / ACP surface in v0; ordering stays local and explicit**
   - D-QUIESCE v0 introduces **no new portal family, CH-ACP automation kind, or CH-CONFLICTKEY family**.
   - Within one component instance, `BeginQuiesce`, `EndQuiesce`, and “start new externally triggered work” are intentionally **non-commutative** on the component-local maintenance state and therefore serialize at the component control handle / supervisor boundary; evidence lives in explicit `qid` / state outcomes and optional CH-QUIESCE descriptors rather than ambient logs.
   - Any future fleet-wide/admin/export seam for quiescing components must land RFC-first with its own receipts, serialization story, policy kill switches, and commutativity boundary.

13) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat runtimes (D-FCELL) MAY translate D-QUIESCE into internal signals, runtime hooks, or guest-specific stop handshakes behind the membrane.
   - Phase 1 does **not** standardize an ambient process-tree signal bridge, compat-visible freezer handle, or hidden host-side quiesce broker.
   - Any compat integration remains policy-killable and must not recreate ambient stop/control channels.

## Phase 1 non-goals (explicitly deferred)

- Nested / stacked / merged quiesce requests.
- Recursive subtree or process-tree freeze semantics.
- A force-kill opcode on D-QUIESCE itself.
- Payload-bearing wait results or packet queues on the wait seam.
- Implicit checkpoint / migration / export promises merely from reaching `QUIESCENT`.
- New workflow / ACP / fleet-admin surfaces for quiesce.

## Wiring

- Decision surface: `decision-map.md` (D-QUIESCE).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (quiesce/drain maintenance handshake)
  - `rfcs/0108-quiescence-and-drain-protocol.md` (option space / evidence seed)
  - `rfcs/0098-recovery-mode-and-rescue-environment.md` (crash-only / rescue fallback remains distinct)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-QUIESCE-1, I-QUIESCE-2, I-QUIESCE-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUIESCE-STATE, PO-QUIESCE-GATE)
  - `docs/30-architecture/waitset-posture-v0.md` (observational wait adjunct)
  - `docs/30-architecture/activation-posture-v0.md` (restart continuity stays separate)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future admin/orchestration surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_quiesce_posture.py` fails `make lint` if this posture stops being discoverable, loses the single-active-qid / component-local / no-force-kill posture, or drops its primary REF wiring.

## References

- REF-SYSTEMD-SERVICE.
- REF-KUBE-LIFECYCLE-HOOKS.
- REF-ERLANG-RELEASE-HANDLING.
- REF-LINUX-CGROUP-FREEZER.
- REF-FUCHSIA-RUNNER-STOP.
