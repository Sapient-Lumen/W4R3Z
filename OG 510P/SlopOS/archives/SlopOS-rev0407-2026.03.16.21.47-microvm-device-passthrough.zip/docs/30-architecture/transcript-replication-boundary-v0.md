# Transcript replication boundary (v0)

Purpose: narrow **OQ-0001** for `object_family = transcript` without turning replicated audit history into portable runtime authority.

SlopOS already treats CH-LOG as a **replay/audit transcript** with canonicalized export order rather than ambient append order.
Hybrid needs one more hard decision so cross-cluster transcript sharing does not quietly become a remote approval cache, replay ticket, or runtime sequencer:

- replicated `transcript` state is a **content-addressed CH-LOG event-set evidence surface**, and
- **local explicit validators/policy/capabilities still decide whether any new effect may happen now**.

This keeps RC3 commutative replication honest while preserving the archive rule that transcript material is for audit, replay bundles, and explanation — not portable effect authority.

## Decision (v0)

For `object_family = transcript` under CH-REPLCONTRACT v0:

1. The replicated value is a **content-addressed set of immutable CH-LOG entries** scoped by `log_id`.
   - Each member is identified by the canonical digest of the CH-LOG entry bytes.
   - Replication may carry accompanying closure artifacts referenced by those entries (for example CH-DENY / CH-ACPOUT bundles) only through their own digest-addressed families; the transcript family itself remains the CH-LOG entry set.
2. Merge is **set union by entry digest**. Duplicates collapse by digest; arrival order is not authoritative.
3. Export order is **derived presentation only**.
   - Replicas MAY canonicalize/sort for stable diffs, replay bundles, or redaction-safe exports.
   - Receivers MUST NOT interpret “latest replicated transcript arrival” as a runtime sequencing bus, freshness clock, lease clock, or approval priority rule.
4. Replication MAY move CH-LOG entries between clusters for audit, replay-bundle closure, deterministic diffing, redaction-checked export, or offline explanation, but it MUST NOT by itself:
   - satisfy a missing local approval, policy, or capability check,
   - authorize replay/resubmission of an old action,
   - instantiate or reissue a handle/lease/capability named by transcript-linked digests,
   - treat transcript arrival order as proof that one hot action must serialize after another, or
   - convert a replicated `result`, `deny_digest`, `order_digest`, or `authz_ref` into bearer authority.
5. Any local system that wants to act on what a transcript names must still cross an **explicit local seam**:
   - validator/executor admission for privileged actions,
   - local restore/import rules for CH-CAPX / CH-SREF / lease-like objects,
   - local policy checks for replay tooling, export tiers, and any transcript-driven diagnostics.
6. If a future design needs **portable replay tickets, remote approval caches, or globally ordered workflow control**, that work must land as a **new RFC-first descriptor/object family** (or use the already-explicit `tlog` evidence lane where appropriate), not as a reinterpretation of `object_family = transcript`.

## Why RC3 fits here

Transcript entries are immutable evidence objects. Adding one more CH-LOG digest to the observed set commutes with adding another. That is the useful part of cross-cluster transcript exchange.

What does **not** commute is using those arrivals to decide whether a new privileged effect may happen, or in what global runtime order hot actions should execute. SlopOS intentionally keeps those decisions outside transcript replication and on local explicit seams.

## Explicit non-goals (v0)

Phase 1 does **not** standardize:

- cross-cluster approval caches driven by CH-LOG arrivals,
- replay authorization based only on replicated transcript presence,
- transcript-arrival order as a distributed runtime sequencer,
- automatic lease/handle resurrection from transcript-linked digests, or
- a global transcript authority service.

If later phases need portable replay/result authority, they must pay for a distinct capability/descriptor seam with its own invariants, ordering rules, and evidence.

## Source notes

- CRDT set-style replication is a good fit for immutable event collections because merge can be modeled as a commutative/idempotent set join rather than a hidden global lock (REF-CRDT-INRIA11).
- SCITT explicitly allows the **same Signed Statement** to be independently registered by multiple transparency services and notes that entry ordering may be non-deterministic but must remain verifiable, which matches the archive's “share evidence, keep authority local” posture (REF-SCITT-ARCH).
- in-toto Statements bind immutable subjects by digest while leaving policy evaluation to consumers, which matches SlopOS's rule that transcript-linked digests help audit/explain but do not themselves authorize a new effect (REF-IN-TOTO-STATEMENT).

## Consequences for the archive

- `replication-object-family-registry.md` should treat `transcript` as **CH-LOG event-set evidence replication only**.
- `profile-repl-defaults.md` may keep RC3 defaults where desired, but the note must say that replicated transcripts are **evidence only** and cannot drive replay/admission/runtime ordering.
- `transcript-contract.md` should say that canonical export order is presentation-only across replicas and that replicated transcript arrivals never become approval/replay authority.
- Any future stronger semantics must pay for a new decision surface.
