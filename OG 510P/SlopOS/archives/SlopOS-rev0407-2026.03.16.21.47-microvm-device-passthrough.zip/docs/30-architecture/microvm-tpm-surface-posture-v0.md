# MicroVM TPM-surface posture v0 (no portable ambient guest TPM contract)

Purpose: pin the **Phase 1** meaning of guest-visible TPM / vTPM surfaces under `ext.microvm` so TPM devices, emulator sockets, PCR folklore, and guest-side sealing do not quietly become an ambient host↔guest authority plane.

This doc attaches to **D-MICROVM**, **D-ATTEST**, **D-CRYPTOSVC**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 exposes no portable ambient guest-visible TPM/vTPM contract under `ext.microvm`; there is no portable TPM2 command-status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane, owner-local TPM enablement and backend selection stay implementation-local, and attestation / key-sealing meaning still rides on explicit D-ATTEST / CH-ATTESTPACK and D-CRYPTOSVC / CH-KEYPOL / CH-KEYREF seams rather than ambient guest TPM device calls.**

Entropy cost justification: the archive already keeps attestation export explicit, keeps secret/key use on D-CRYPTOSVC and D-VAULT seams, and refuses hidden bootstrap/metadata channels. What remains underspecified is the tempting virtualization convenience layer where a guest-visible TPM device, emulator socket, PCR bank, or host-TPM passthrough quietly becomes “the real” portable authority path. One narrow posture closes that gap without inventing a new schema family, a guest agent, or a hidden TPM management plane.

## Posture (v0)

1) **No portable ambient guest-visible TPM/vTPM contract**
   - For Phase 1, `ext.microvm` exposes no portable ambient guest-visible TPM/vTPM contract.
   - Portable reviewed meaning therefore does **not** include “this guest can always rely on a TPM 2.0-compatible device because it is virtualized.”
   - In plain terms: the reviewed contract is not “boot the leaf and assume a stable in-guest TPM ABI exists with known PCR, NV, attestation, or sealing semantics.”

2) **No portable TPM2 command-status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane**
   - Phase 1 standardizes **no portable TPM2 command-status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible guarantees about TPM command availability, PCR bank layout/policy, NV storage/index lifecycle, quote/attestation-document retrieval, or sealing/unsealing behavior through a guest TPM device.
   - Implementations may internally expose, mask, or route such mechanisms locally, but those choices are **not** part of the portable Phase 1 product contract and must not silently become reviewed API meaning.

3) **Owner-local TPM enablement and backend selection stay implementation-local**
   - Owner-local TPM enablement and backend selection stay implementation-local.
   - Runtimes may locally choose NitroTPM-like enablement at launch, `swtpm`-style emulator backends, or host-TPM passthrough/avoidance for one deployment class, but that does **not** create a portable reviewed promise about one guest-visible device, one backend type, or one runtime status/control API.
   - Snapshot/clone semantics remain governed by the already-pinned generation/attestation boundaries rather than by folklore that a guest-visible TPM device makes restored state or sealing continuity portable by itself.

4) **D-ATTEST and D-CRYPTOSVC remain authoritative for attestation and key-sealing meaning**
   - D-ATTEST and D-CRYPTOSVC remain authoritative for attestation and key-sealing meaning.
   - If D-ATTEST is enabled, exported attestation meaning still rides on explicit `IF-ATTEST` / `CH-ATTEST` / `CH-ATTESTPACK` seams rather than ambient guest TPM calls or in-guest quote utilities.
   - If D-CRYPTOSVC is enabled, portable reviewed key/sealing meaning still rides on explicit `CH-KEYPOL` / `CH-KEYREF` policy-bound handles rather than ambient TPM ownership, NV policy, or PCR-binding folklore inside the guest.

5) **Changing the TPM surface is a new admission, not a live control plane**
   - Changing the TPM surface is a new admission, not a live control plane.
   - Owners/runtimes may choose different local TPM exposure stances for different reviewed leaves or deployment classes, but they may **not** reinterpret a running leaf as carrying a portable mutable TPM presence / backend / NV / PCR / attestation plane under the same admitted identity.
   - If policy cares about a different TPM exposure stance, the correct Phase 1 action is to admit a different reviewed leaf/activation or keep the difference owner-local — not to patch a hidden TPM control plane by convention.

6) **No new TPM device control plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for guest TPM device state, **no new ACP kind**, and **no new conflict-key family** for live TPM enable-disable / ownership / NV / PCR mutation under `ext.microvm`.
   - If a later design wants a portable guest TPM contract, PCR-bound storage semantics, or guest-visible TPM lifecycle controls, it must pay a separate RFC-first cost and explicitly state the kill switch, conflict keys, commutativity stance, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable promise that a guest-visible TPM 2.0 / vTPM device exists with one stable reviewed meaning under `ext.microvm`.
- No portable PCR-bank policy, NV index lifecycle, quote/attestation-document retrieval, or sealing/unsealing API.
- No prohibition on owner-local TPM enablement at launch; only a refusal to turn it into a portable ambient authority contract.
- No live “same leaf, different TPM presence/backend now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-ATTEST, D-CRYPTOSVC, D-XS, D-ACTIVATE)
- Primary postures:
  - `microvm-profile-posture-v0.md`
  - `attestation-posture-v0.md`
  - `cryptosvc-posture-v0.md`
- Adjacent postures:
  - `microvm-bootstrap-metadata-posture-v0.md`
  - `microvm-attestation-reacquire-posture-v0.md`
  - `microvm-attestation-scope-posture-v0.md`
  - `microvm-resume-admission-evidence-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-20)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-TPMSURFACE)
- Policy posture:
  - guest-visible TPM exposure adds **no new lane**, **no public TPM-management or quote-retrieval plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_tpm_surface_posture.py` fails `make lint` if this posture stops being discoverable, loses its **no portable ambient guest-visible TPM-vTPM contract / no portable TPM2-command-status-PCR-bank-NV-index-sealing-unsealing-attestation-document plane / owner-local TPM enablement and backend selection stay implementation-local / D-ATTEST and D-CRYPTOSVC remain authoritative / changing the TPM surface means new admission not live control plane / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-AWS-NITROTPM.
- REF-AWS-NITROTPM-ATTEST.
- REF-CHYP-TPM.
- REF-QEMU-TPMDEV.
- REF-TPM2-PART1.
