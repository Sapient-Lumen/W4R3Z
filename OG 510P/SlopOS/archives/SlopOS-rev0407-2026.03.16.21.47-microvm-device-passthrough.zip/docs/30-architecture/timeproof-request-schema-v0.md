# CH-TIMEREQ v0: authenticated time sample request (optional; D-TIMEPROOF)

Purpose: a **bounded, normalized request descriptor** for obtaining an authenticated time sample from the user-space time/clock portal.

CH-TIMEREQ is a stable, digestable input for **LLM-proposed / validator-executed** timeproof sampling:
- ACP proposals bind `timereq_digest = digest(CH-TIMEREQ v0)`.
- Validators verify the request shape (fail closed) and invoke the portal using explicit capabilities.
- The portal returns a **CH-TIMEPROOF v0** evidence artifact bound to the request nonce.

See: RFC-0090 (D-TIMEPROOF) and `time-proof-schema-v0.md` (CH-TIMEPROOF).

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-TIMEREQ-v0 {
  schema: "CH-TIMEREQ";
  version: 0;

  # Request identity (for dedupe/replay correlation).
  # Validators/portals MAY treat stable req_id as an upsert key.
  req_id: bytes16;            # random (>=128 bits)

  # Proof kind requested (v0 supports only Roughtime-shaped bootstrap samples).
  kind: enum { roughtime };

  # Freshness binding: the client nonce used for the proof.
  # NOTE: nonce bytes are not secrets, but they are correlation identifiers.
  nonce: bytes32;

  # Optional bounds (veto-only hints; the portal may clamp or deny).
  bounds?: {
    max_radius_ms?: u32;       # requested maximum uncertainty radius
    deadline_mono?: u64;       # optional local monotonic deadline (units profile-defined)
  };

  # Optional non-authoritative purpose label (bounded).
  purpose?: string;            # ≤ 96 bytes (e.g., "tuf_bootstrap", "audit")
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `req_id` must be exactly 16 bytes.
- `nonce` must be exactly 32 bytes.
- `purpose` length must be ≤ 96 bytes.
- If present:
  - `max_radius_ms` is bounded by policy (suggested default max: 10 minutes).
  - `deadline_mono` is interpreted as a **veto-only** hint (reject/timeout), never as a grant.

## Security posture
- CH-TIMEREQ is **non-authoritative**.
- It MUST NOT contain endpoint addresses, DNS names, or network parameters.
  - Server selection is profile/policy-defined and lives in the portal.
- It is a request for **evidence-first** authenticated time sampling, not a request to set ambient realtime/scheduler state (see `timeproof-posture-v0.md`).
- Treat `nonce` as potentially sensitive correlation metadata; export should be scoped by CH-OBSPOL.

References: REF-ROUGHTIME-PROTOCOL; REF-ROUGHTIME-IETF; REF-RFC-8915.
