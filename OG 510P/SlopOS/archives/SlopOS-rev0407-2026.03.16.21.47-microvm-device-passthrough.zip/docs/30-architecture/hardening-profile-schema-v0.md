# CH-HARDEN v0: Hardening profile declaration (optional)

Purpose: declare (and pin) the **expected hardening posture** for a component/domain so that:
- launchers can enforce “no weaker than declared,”
- audits can answer “what hardening was active?”, and
- boot/provenance can bind hardening intent to the running image.

This schema is deliberately small: it does **not** define security policy. It is a declarative *hint+contract* that can be validated and bound.

Primary driver: D-MEMTAG (hardware memory tagging profiles), but the schema also provides room for a few common control-flow hardening bits.

## Canonical encoding
CH-HARDEN follows D-ENC/RFC-0001 rules.

**Normative bytes:** canonical CBOR (RFC 8949) suitable for hashing/signing.
- no floats (deterministic integers/bytes/text only)
- reject unknown keys (closed world)

**Optional authoring form:** tools MAY accept JSON for human authoring, but MUST normalize it deterministically and transcode to canonical CBOR **before** hashing/signing. See `encoding-policy.md`.

## Data model (v0)
Top-level object:
- `schema`: fixed string `"CH-HARDEN v0"`
- `hid`: bounded identifier/tag (for operator readability; not authority)
- `target`: one of:
  - `{ kind: "component", cid: <bounded> }` (if CH-COMP is in use)
  - `{ kind: "image", image_digest: <digest> }`
- `features`: hardening feature declarations
- `fault_policy`: how faults are handled for *this* profile
- `notes_tag`: optional bounded tag for humans (ignored by validators)

### `features` (v0)
- `memtag`: one of `{ "off", "require_sync", "require_async" }`
  - `require_sync` = synchronous tag checks (debug/triage)
  - `require_async` = asynchronous tag checks (lower overhead; production posture)
- `wx`: one of `{ "default", "require" }`
  - `require` means the launcher must select a W^X-enforcing address-space profile (pairs with D-DYNCODE)
- `cfi`: one of `{ "off", "require" }` (control-flow hardening, platform-specific)

### `fault_policy` (v0)
- `on_memtag_fault`: one of `{ "kill", "trap" }`
  - `kill` = terminate the domain deterministically
  - `trap` = deliver a fault to the component’s pager/handler (dev/test)

## Minimal validation rules
- reject unknown fields at all levels
- `schema` must match exactly
- `hid` must be bounded length (policy) and printable
- `target.kind` must be one of `{ component, image }`
- if `target.kind=component`: `cid` must be present
- if `target.kind=image`: `image_digest` must be present and well-formed
- enums must match exactly; unknown variants reject

## Binding obligations (PO-HARDEN-BIND)
- if CH-HARDEN is used in a deployment, its digest(s) must appear in CH-BOOT `artifacts` (role = `harden_profile`) and must be exportable for audit via IF-OBS/CH-LOG.
- launchers must refuse to start a component that declares `memtag=require_*` if the underlying platform cannot satisfy it (fail closed per profile).

## Notes
- v0 intentionally avoids “free-form flags.” If we need more, add a v1 revision via RFC.
- This schema is an *audit seam*: it makes “hardening drift” visible and reviewable.

Links:
- RFC-0062 (D-MEMTAG)
- RFC-0059 (D-DYNCODE) for W^X posture
