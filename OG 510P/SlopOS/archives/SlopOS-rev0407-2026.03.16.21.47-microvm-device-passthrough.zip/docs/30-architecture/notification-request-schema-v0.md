# CH-NOTIF v0: Notification request (attention portal)

Purpose: let untrusted components request user notifications through a **mediated portal** that can enforce origin branding, budgets, and volition-gated actions.
This schema is a bounded, non-executable request; it does not grant authority.

References: REF-XDG-PORTAL-NOTIFICATION, REF-NOTIF-PHISH-WOOT12.

Portal family: `portal.attn.*` (CH-PLEDGE token `portal.attn`; CH-EFFCON effect kind `portal.attn`).
Lane gate: `cfg.params.lane.portal.attn` (PO-LANE-KILL; I-PORTAL-KILL-1). When disabled (or missing), the portal MUST deterministically reject requests and emit transcript-visible denial/receipt evidence.

When invoked via ACP, proposals SHOULD use the dedicated kind `portal.attn.request` and bind a `notif_digest = digest(CH-NOTIF v0)` (PO-ACP-ATTN-REQUEST).

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-NOTIF v0 := {
  v: 0,

  kind: tstr,                 ; closed enum: "post" | "withdraw"
  id: bstr,                   ; caller-chosen stable id (scoped to origin); used for withdrawal/update

  channel: tstr,              ; caller-chosen channel name (UI maps to user settings); bounded
  importance?: tstr,          ; closed enum: "background" | "default" | "urgent" (optional; policy may ignore)

  title?: tstr,               ; bounded text; no markup
  body?: tstr,                ; bounded text; no markup

  icon?: {
    kind: tstr,               ; closed enum: "aref" | "handle"
    ref: bstr,                ; content digest / handle id (policy-defined)
  },

  actions?: [
    {
      label: tstr,            ; bounded; no markup
      intent: {
        kind: tstr,           ; closed enum: "route" | "acp"
        digest: bstr,         ; digest of CH-ROUTE intent or CH-ACP action bytes
        schema: tstr,         ; "CH-ROUTE v0" | "CH-ACP v0"
      }
    }
  ],

  ttl_s?: uint,               ; optional time-to-live in seconds; portal may clamp

  hints?: { * tstr => any }   ; optional; portal MUST ignore unless allowlisted
}

Notes:
- Origin identity is **not provided** by the request. The portal derives origin branding from canonical component identity (CH-COMP + runtime identity).
- `actions` are *requests*; executing them requires trusted UI volition (D-VOLITION) and may require consent/diffs (D-EXPLAIN).

## Validation rules (minimum)
A CH-NOTIF validator MUST be total and fail closed:
1) `v == 0` and `kind` is allowlisted.
2) `id` is non-empty and length-bounded; portal enforces per-origin uniqueness within a window.
3) `channel` length-bounded (e.g., <= 64 bytes) and UTF-8 valid.
4) `title`/`body` are length-bounded; MUST be treated as plain text.
5) If `icon` is present, `kind` is allowlisted and `ref` length matches the configured identifier size.
6) If `actions` present:
   - list length is bounded (e.g., <= 3)
   - each `label` length-bounded
   - `intent.schema`/`intent.kind` pair is allowlisted
   - `digest` length matches configured hash
7) `ttl_s` clamped to a profile maximum; omitted implies a conservative default.
8) Unknown `hints` keys are ignored unless explicitly allowlisted.

## Obligations (portal semantics)

- **Lane killability:** if `cfg.params.lane.portal.attn` is `false` (or missing), the portal MUST reject requests deterministically and SHOULD emit CH-DENY with `deny_code = lane-disabled` and `reason.ref_key = cfg.params.lane.portal.attn` (PO-LANE-KILL).
- **Origin branding:** the portal derives origin labels/icons from canonical component identity + policy state; requester fields must not override branding (PO-ATTN-BRAND).
- **Urgent is policy-gated (no lease/capability in v0):** if `importance="urgent"` is requested, the portal MUST treat it as an advisory hint that may be denied, downgraded, or coalesced under the active policy and deterministic budgets (I-ATTN-3; PO-ATTN-URGENT). Urgent requests MUST NOT bypass volition requirements for actions (I-ATTN-2), MUST NOT imply background/autostart/runtime persistence, and MUST NOT rely on any `attention.urgent` capability because no such v0 surface exists. CH-NOTIF MUST NOT be reinterpreted in place as TTL/renew/revoke or durable interrupt authority; any future stronger interrupt semantics must live in a separate RFC-first surface (see `docs/30-architecture/attention-lease-posture-v0.md` and `docs/30-architecture/attention-durable-interrupt-boundary-v0.md`; design inspirations: REF-XDG-PORTAL-NOTIFICATION, REF-APPLE-CRITICAL-ALERTS, REF-ANDROID-NOTIF-CHANNELS).
- **Action binding:** if a notification action is rendered, the clicked action MUST bind to the same `{intent.schema, intent.digest}` that was displayed; post-render swaps must reject and be transcript-logged (PO-ATTN-ACTIONBIND).

## Privacy notes
Notification requests and their delivery metadata are PII-adjacent. Export via IF-OBS should be minimized/redacted (C-OBS-1) and should not include raw message bodies by default.
