# Capshell cwd-root posture v0 (no parent escape or host-root fallback)

Purpose: keep **D-CAPSHELL** honest once workflow execution binds **CH-CWD v0**. Making cwd
explicit is necessary, but it is not sufficient if the runner still treats cwd as advisory path text
or quietly lets relative-path resolution escape into ambient parents, host root, or process-global
filesystem state. That would turn “explicit cwd” into a thin wrapper around ambient path lookup.

This adjunct freezes the smaller Phase 1 answer: **CH-CWD selects a bound cwd root, not a stringy
starting hint**. Relative path resolution for compat/path-based launches must stay inside the bound
authority envelope, and any platform/runtime that cannot guarantee that MUST fail closed rather than
quietly downgrade to host cwd semantics.

## Posture (v0)

1) **CH-CWD selects a bound cwd root, not an advisory pathname**
   - `cwd_digest = digest(CH-CWD v0)` names the starting directory authority for `capshell.exec`.
   - The runner MUST NOT reinterpret CH-CWD as a host path string, re-resolve it through ambient
     lookup, or replace it with “whatever cwd the launcher already has.”
   - The bound cwd is therefore part of the reviewed execution shape, not a convenience hint.

2) **`kind="empty"` means fresh or sealed and non-escaping**
   - In Phase 1, `cwd.kind="empty"` must bind a **fresh empty directory** or an equivalently
     **sealed cwd root** with no inherited contents and no ambient parent/root escape.
   - The child MUST NOT gain authority to discover or traverse host/global parents merely because a
     cwd was required by the ABI.
   - If the runtime cannot provide that sealed empty cwd root under the active profile, execution
     MUST fail closed and be transcript-visible.

3) **Relative path resolution must stay beneath the bound root**
   - For compat/path-based launches, relative-path resolution from the bound cwd MUST remain within
     the active bound root / view namespace; `..` traversal, absolute-path re-rooting, or similar
     fallbacks must not escape into ambient namespaces.
   - The implementation mechanism is deliberately left open (for example, a sealed view namespace,
     a compat runtime rooted beneath the bound directory, or per-open beneath/in-root enforcement),
     but the exported safety bar is not optional.
   - “Best effort” is not a valid Phase 1 answer here.

4) **Descriptor-bound cwd stays handle-first**
   - `cwd.kind="desc"` binds only to already-held directory handles / leases / portal outputs
     admitted by the active execution context.
   - The runner MUST NOT convert a descriptor digest back into an ambient host pathname and then
     bind cwd by string lookup.
   - If a compat layer needs pathname APIs internally, it must preserve the same no-escape bound
     root semantics instead of reintroducing ambient path discovery behind the membrane.

5) **No portable cwd path-string oracle**
   - This posture does **not** promise that the child can recover a stable host pathname for its
     cwd, nor that `getcwd()`-style strings identify an ambient global location.
   - Shell/UI conveniences such as prompts or breadcrumbs remain local presentation choices, not a
     portable authority or discovery surface.
   - Phase 1 therefore separates “the child has a starting directory authority” from “the runner
     reveals a host pathname identity for that authority.”

6) **No best-effort downgrade or silent repair**
   - If the launcher cannot prove the required no-escape cwd-root semantics on the active platform
     or compat membrane, it MUST reject/fail closed rather than silently inheriting host cwd,
     tolerating `..` escape, or rebasing to `/`.
   - There is no fallback mode where explicit CH-CWD becomes advisory only.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain those already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, serialized at `svc:IF-CAPSHELL`).

8) **Sealed compat remains killable and non-ambient**
   - Compat / foreign-cell adapters MUST carry the same cwd-root boundary across the membrane.
   - Interop remains policy-killable and MUST NOT recreate ambient path discovery through host cwd,
     host root, or “legacy absolute paths still work from here” conventions.

9) **No new workflow / ACP / admin surface**
   - Phase 1 adds no `capshell.cwd.*` admin/query family, no cwd inventory API, and no portable
     “what host pathname did this cwd resolve to?” surface.
   - Any richer namespace/root-management UX must return as a separate RFC/decision surface rather
     than widening CH-CWD by implication.

## Phase 1 non-goals (explicitly deferred)

- Standardizing a specific kernel primitive such as `openat2()` or a particular namespace layout.
- Promising portable `getcwd()` / prompt-path semantics for bound cwd roots.
- General absolute-path compatibility for external tools beyond the existing D-NS / portal model.
- Turning CH-CWD into a filesystem-namespace management or mount-manipulation surface.

## Why this cut is worth making

Unix/POSIX-style cwd is deceptively powerful: once a process can combine cwd-relative path lookup
with `..`, absolute paths, or symlink escapes against an ambient root, the system has recreated a
hidden namespace-authority plane beside reviewed argv/env/cwd bindings. Linux's `openat2()`
`RESOLVE_BENEATH` / `RESOLVE_IN_ROOT` family exists precisely because “start from this directory”
is not enough when resolution can still race or escape. SlopOS does **not** standardize `openat2()`
itself here; it imports the **correctness bar**: a cwd root that can leak back into ambient path
lookup is not an explicit-authority seam.

The smaller Phase 1 cut keeps the archive coherent:
- **secure workstation (A):** wrapper-first automation can still run legacy tools, but cwd no
  longer silently reopens host-parent traversal beside reviewed handles and portals;
- **cloud micro-VM / hosted substrate (B):** automation remains replayable and namespace-bounded
  instead of depending on mutable instance cwd/root state;
- **embedded / separation appliance (C):** the small profile stays honest about path authority
  rather than importing best-effort shell cwd behavior;
- **agent/automation OS (D):** LLM-authored workflows keep cwd as an explicit bound root, not an
  ambient escape hatch hidden behind relative paths.

## Wiring

- Decision surface: `decision-map.md` (D-CAPSHELL).
- Primary schema seam: `cwd-schema-v0.md` (**CH-CWD v0**).
- Adjacent seams:
  - `capshell-exec-pack-schema-v2.md`
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `view-namespace-posture-v0.md`
- Assurance anchors: **I-CWD-2**, **PO-CAPSHELL-CWD-BIND**.
- Engineering surface: `docs/60-engineering/cli-plumbing-tooling.md`.
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_cwd_root_posture.py` (**EVID-2026-328**).

## References

- REF-OPENAT2
- REF-CAPSICUM
