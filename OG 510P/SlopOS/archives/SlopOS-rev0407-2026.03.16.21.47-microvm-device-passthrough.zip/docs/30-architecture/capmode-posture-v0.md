# Capability-mode posture v0 (no ambient acquire after entry)

Purpose: pin the Phase-1 meaning of **D-CAPMODE** so “no ambient authority” stays an
implementable execution posture rather than drifting into vague rhetoric, a hidden process-global
admin plane, or a second namespace system.

This doc deliberately narrows RFC-0010 into one thing: **after a domain enters capability mode,
it may continue to use authority it already holds or authority it receives explicitly, but it may
not acquire new authority from ambient/global namespaces or fallback mechanisms**.
D-CAPMODE is therefore a **constraint on existing authority-bearing actions**, not a new privileged
interface family, schema, or workflow surface.

This posture composes with **D-SEAL** and **D-NS**:
- **D-SEAL** narrows what a service keeps after init,
- **D-CAPMODE** forbids reacquiring ambient authority later,
- and **D-NS** keeps name resolution explicit via view objects rather than hidden defaults.

## Posture (v0)

1) **D-CAPMODE is a local execution posture on existing authority-bearing actions, not a new interface surface**
   - Phase 1 standardizes no new `IF-*`, no new `CH-*`, and no generic control protocol for D-CAPMODE itself.
   - Entering capability mode changes how existing acquire / resolve / open / connect style actions are validated; it does not add a second namespace or privilege broker.

2) **Entry is one-way**
   - Once a domain enters D-CAPMODE, it MUST NOT return to an ambient-acquire state in the same lifetime (I-CAPMODE-1, PO-CAPMODE-ONEWAY).
   - “Temporarily disable capmode”, “borrow ambient authority for one call”, or “re-enter init mode” are out of scope in Phase 1.

3) **No ambient authority acquisition after entry**
   - After entry, the domain MUST NOT acquire new authority from ambient/global namespaces or fallback channels.
   - This includes path/default-namespace lookup, cwd/env-based fallback, service-name registries, ambient DNS/network discovery, proc-table style global discovery, and similar “find it from the environment” mechanisms.
   - If an action would require such ambient acquisition, it MUST fail closed with a deterministic deny/error.

4) **Already-held explicit authority remains usable**
   - D-CAPMODE does not revoke authority the domain already holds.
   - Existing handles, views, leases, descriptors, proxy/service objects, and other explicitly held capabilities may continue to be used subject to their own target-seam rules.
   - Capability derivation/attenuation from already-held authority remains allowed; D-CAPMODE forbids ambient acquisition, not explicit use of already-held capabilities.

5) **Explicit receipt is allowed; ambient fallback is not**
   - After entry, the domain MAY still receive authority explicitly through request inputs, portals, supervisor-delivered handles, view attachment, CH-CAPX / CH-SREF restore/import seams, or other explicitly authorized handoff paths.
   - If an explicit handoff path fails or is absent, the runtime MUST NOT silently retry via path/env/default-service fallbacks.
   - “Could not resolve explicitly” must not degrade into “look around globally”.

6) **Pre-opened capability services are allowed, but only as explicit handles**
   - Phase 1 allows the Capsicum/Casper-style pattern where a domain opens specific capability services **before** entry and then uses those already-held service handles after entry.
   - Such service handles remain ordinary explicit authority edges; they do not justify later ambient lookup of equivalent facilities.
   - Long-lived services SHOULD close broad introducers before or at entry so “service capability” does not hide a root ambient resolver behind one explicit handle.

7) **D-CAPMODE composes with D-SEAL; capmode alone is not enough**
   - For long-lived services, entering D-CAPMODE SHOULD normally follow init-time narrowing under D-SEAL.
   - A service that enters capmode while still holding broad introducers, namespace mutation power, or oversized init-only handles has not honestly narrowed authority.
   - D-CAPMODE prevents reacquisition; D-SEAL is what should drop excess authority in the first place.

8) **External action semantics stay on the target seam, not on D-CAPMODE itself**
   - D-CAPMODE does not mint new conflict-key families, ordering witnesses, portal kinds, or workflow actions.
   - Any externally visible action keeps the conflict keys, commutativity stance, serialization boundary, and evidence hooks of the target seam it already belongs to.
   - The only capmode-specific effect is that forbidden ambient-acquire attempts reject deterministically at the existing action boundary.

9) **No new workflow / ACP / admin surface on D-CAPMODE itself**
   - Phase 1 introduces no generic capmode portal family, no CH-ACP kind for toggling/querying capability mode, no app-visible inventory of “ambient denials”, and no global “which domains are in capmode?” introspection surface.
   - If future products need operational visibility, that must ride on existing observation/export policy rather than silently widening D-CAPMODE into an admin plane.

10) **Sealed compatibility remains killable and non-ambient**
   - Foreign Cells and compat wrappers may adopt capmode-like postures only through explicit, policy-killable membrane logic.
   - They MUST NOT recreate ambient acquisition through injected PATH/env defaults, hidden host service discovery, or background compatibility daemons.
   - D-CAPMODE therefore tightens sealed compat instead of legitimizing ambient escape hatches.

## Phase 1 non-goals (explicitly deferred)

- A mandatory system-wide capmode bit for every process on every profile.
- A portable transcript/event schema that records “entered capmode” as a first-class wire artifact.
- A generic query API for current capmode state or historical ambient-acquire denials.
- A privileged-core service catalog for DNS / passwd / sysctl / locale; any such facilities remain user-space capability services or explicit portals.

## Wiring

- Decision surface: D-CAPMODE in `docs/30-architecture/decision-map.md`.
- Assurance anchors: I-CAPMODE-1 and PO-CAPMODE-ONEWAY in `docs/20-assurance/invariant-registry.md` and `docs/20-assurance/proof-obligation-registry.md`.
- Pressure test: AC-008 in `docs/10-threat-model/abuse-cases.md`.
- Composition seams:
  - `docs/30-architecture/seal-posture-v0.md`
  - `docs/30-architecture/view-namespace-posture-v0.md`
  - `rfcs/0010-ambient-authority-and-capability-mode.md`
  - `rfcs/0016-voluntary-sandboxing-promises-and-unveil.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
- CI drift gate: `tools/check_capmode_posture.py` (EVID-2026-318).

## References

- REF-CAPSICUM
- REF-FREEBSD-CAPSICUM
- REF-FREEBSD-LIBCASPER
- REF-CLOUDABI
- REF-WASI-DESIGN
