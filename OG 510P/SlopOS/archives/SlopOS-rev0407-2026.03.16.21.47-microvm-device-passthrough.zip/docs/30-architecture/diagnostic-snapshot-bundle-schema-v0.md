# CH-SNAPSHOT v0 (diagnostic snapshot bundle manifest schema, informal)

Purpose: a bounded manifest that describes a **support/incident snapshot bundle**.

A snapshot bundle is a *shareable object* that can be attached to bug reports and incident tickets. It is not a replay bundle (CH-RRBUNDLE), but it may reference replay artifacts if the profile allows.

Refs: REF-FUCHSIA-SNAPSHOT, REF-ANDROID-BUGREPORT, REF-APPLE-SYSDIAGNOSE.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded number of entries and bounded per-entry metadata
- explicit redaction/minimization posture (I-OBS-1)
- avoid stable kernel IDs, raw pointers, and bearer tokens in the manifest

## Shape (v0)
A snapshot manifest `m` contains:
- `schema`: fixed `CH-SNAPSHOT v0`
- `scope`: an enum tag describing intent (e.g., `support`, `incident`, `ci_failure`)
- `redaction_profile`: a bounded tag (or digest reference to an active export policy, typically CH-OBSPOL) describing sanitization rules
- `boot_digest`: optional digest of CH-BOOT (or a redacted boot summary digest)
- `session`: optional bounded identifiers (e.g., boot nonce / session nonce; no stable hardware IDs)
- `created_ts`: optional timestamp (only if enabled)
- `entries`: canonical list of snapshot entries

### Entry record
Each entry `e` contains:
- `kind`: closed enum
- `digest`: content digest of the entry payload (if payload is included)
- `aref`: optional CH-AREF reference (if payload is stored out-of-band)
- `domain`: optional bounded tag naming the relevant component/domain (opaque)
- `redaction`: optional enum (`public` | `sanitized` | `sensitive`) indicating expected handling
- `note`: optional bounded string (human hint; non-authoritative)

Canonical ordering:
- entries are sorted by (`kind`, `domain`, `digest`/`aref.digest`) with a stable ordering.

### Allowed `kind` values (v0)
Core kinds:
- `log_window` (CH-LOG excerpt or digest)
- `trace_window` (CH-TRACE excerpt or processor output)
- `inspect` (CH-INSPECT snapshot)
- `health_record` (CH-HEALTHREC)
- `cap_graph` (CH-CAPG)
- `config` (CH-CFG)
- `component_graph` (CH-COMP)
- `update_manifest` (CH-UPD)

Optional kinds (referenced via digest/CH-AREF):
- `crash_dump` (format unspecified)
- `core_dump` (format unspecified)
- `heap_profile` (format unspecified)
- `perf_profile` (format unspecified)

Notes:
- “format unspecified” kinds are intentionally out of scope for the core schema; they are opaque artifacts referenced by digest.
- if D-RR is enabled and the snapshot policy allows, `replay_bundle` (CH-RRBUNDLE) may appear as an entry kind in a future version.

## Validation obligations
- reject unknown `kind` values
- enforce entry count + metadata length bounds
- enforce “no bearer tokens” in `note` and metadata (best-effort lint)

## Policy obligations (PO-SNAP-REDACT)
Snapshot assemblers MUST:
- apply the declared redaction_profile (policy/tag) to decide which kinds and which domains may be included
- default to excluding `sensitive` content
- require explicit authority/workflow for any inclusion of sensitive entries

## Binding obligations (PO-SNAP-BIND)
If `boot_digest` and/or `session` is present, assemblers SHOULD ensure:
- included entries are consistent with the declared session (no mixing across boots)
- digest mismatches fail closed (don’t silently swap payloads)
