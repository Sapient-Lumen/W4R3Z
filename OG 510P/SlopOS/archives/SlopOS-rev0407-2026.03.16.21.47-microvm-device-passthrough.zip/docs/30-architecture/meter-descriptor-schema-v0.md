# CH-METER v0 (meter descriptor schema, informal)

Purpose: a pinned, redaction-safe descriptor for **resource meters/budgets** (D-METER), suitable for transcript logging, audits, and “who paid?” debugging.

This does **not** carry capability secrets. The `Meter` capability (or equivalent handle) is transferred via normal capability mechanisms. CH-METER describes the intended bounds and lineage.

## Design constraints (v0)
- Canonical decode/encode (I-ENC-1) for hashing/logging.
- Bounded fields and closed enums (avoid stringly policy).
- No ambient identities: any linkage is via opaque IDs and/or digests.

## Descriptor shape (v0)
A meter descriptor `M` contains:
- `schema`: fixed `CH-METER v0`
- `meter_id`: small opaque string/id (bounded) used only for correlation in logs
- `kind`: closed enum (profile may allow only a subset):
  - `mem_bytes` (memory objects/VMOs/pages)
  - `kernel_refs` (cap slots/endpoints/other reference-like kernel objects)  
  - `io_buf_bytes` (buffer objects, if D-IOBUF)
  - `net_bytes` (byte budget for outbound networking, if D-NETLEASE)
  - `cpu_ticks` (if D-TCAP; may be redundant with CH-TCAP)
  - `other` (reserved; must be profile-approved)
- `limit`:
  - `{ unit: bytes|ticks|count, value: u64 }` (unit must match `kind`)
- `lineage` (optional):
  - `parent_digest`: digest of the parent meter descriptor (if minted via `split`)
  - `depth_hint`: small integer (bounded)
- `expiry` (optional):
  - `{ monotonic_deadline_ms }` (requires D-TIME/D-TCAP profile support)
- `notes` (optional):
  - bounded plain text intended for **auditors**, not as policy input

## Intended uses
- CH-LOG entries that allocate/expand resources include a `payer` reference:
  - `payer = digest(CH-METER)` (or a stable handle ID)
- A `split` event logs both parent and child meter descriptor digests.
- Leak/DoS tests can assert:
  - no resource-creating privileged action is observed without an explicit payer (PO-METER-PAYER)
  - split is attenuation-only (PO-METER-DELEGATE)

## PO candidates
- PO-METER-PAYER: any abstract-machine operation that creates/expands a resource must identify an explicit payer meter (or be an explicit profile exemption).
- PO-METER-DELEGATE: `split` is monotonic; child limits are ≤ parent and lineage is logged.

Refs: REF-BANGA-RESCONTAINERS, REF-CGROUPV2, REF-CGROUP-DELEGATION, REF-FUCHSIA-JOBS.
