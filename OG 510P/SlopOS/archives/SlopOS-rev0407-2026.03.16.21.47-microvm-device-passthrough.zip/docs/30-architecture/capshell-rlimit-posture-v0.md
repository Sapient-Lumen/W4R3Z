# Capshell resource-limit posture v0 (no inherited `ulimit` / `getrlimit()` baseline)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools whose behavior depends on inherited
per-process **resource limits** (`getrlimit()` / `setrlimit()` / shell `ulimit`). The archive already
says execution context is explicit and reviewable, but that promise still drifts if the child launch
quietly inherits parent/login-shell/session resource-limit state that never appears in the reviewed
execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic quota
service, a per-step scheduler/tuning API, or a new reviewed descriptor for arbitrary POSIX/BSD/Linux
resource limits. It only freezes the minimum Phase 1 posture needed so launch behavior stops
depending on hidden shell/session `ulimit` state across all four product shapes.

## Posture (v0)

1) **No inherited shell/session resource-limit baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit resource limits merely because the parent shell, wrapper,
     login profile, or host session already had them.
   - Resource limits are process attributes; shell-facing `ulimit` state is therefore ambient launch
     context unless the archive makes an explicit reviewed surface for it.

2) **Phase 1 adds no reviewed per-step `rlimit` surface**
   - Phase 1 introduces no reviewed resource-limit descriptor family, no `capshell.rlimit.*` ACP/admin family, and no per-step
     workflow knobs for `RLIMIT_NOFILE`, `RLIMIT_STACK`, `RLIMIT_AS`, `RLIMIT_CPU`, or similar.
   - The portable seam is therefore: **do not carry launcher/session `ulimit` state across the
     reviewed boundary**.
   - If a runtime/provider wants fixed ceilings for a deployment class, those ceilings remain local
     implementation policy and MUST be independent of the caller shell/session state.

3) **Core dumps are forced closed at launch: `RLIMIT_CORE = 0`**
   - Before `exec`, the runner/wrapper MUST set the child launch core-dump ceiling to **`0`**.
   - Phase 1 therefore prefers explicit crash-capsule / minidump workflows over ambient core-dump
     generation as a by-product of `capshell.exec`.
   - Compat/foreign-cell membranes that cannot guarantee `RLIMIT_CORE = 0` before launch MUST fail
     closed rather than inheriting host defaults.

4) **Other explicit seams do not secretly mint or repair resource limits**
   - **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and **CH-REQCTX v1** do not
     authorize synthesizing or translating parent shell/session `ulimit` state into the child.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, session startup hooks,
     prompt/cwd changes) MUST NOT become hidden carriers for resource-limit inheritance.

5) **Programs may still manage their own limits after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen shell/interpreter/program after it begins running.
   - If an explicitly selected tool later calls `setrlimit()` / `ulimit` inside reviewed program
     logic, that behavior belongs to the chosen program/runtime rather than to ambient launch state.

6) **No silent compatibility carry-over from login shells or wrapper hosts**
   - Runners/wrappers MUST NOT preserve host/session `ulimit` defaults as a convenience baseline.
   - Wrapper-first adoption and foreign-cell compatibility layers MUST either start from a
     runtime/provider baseline that is independent of parent shell/session state **and** enforce
     `RLIMIT_CORE = 0`, or fail closed.
   - Rc/profile files, shell builtins, or per-directory hooks cannot pre-seed the child launch
     limits before the reviewed execution boundary.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable resource-limit descriptor family, no policy knob for varying
     launch ceilings per workflow step, and no admin query surface for “what inherited limits were
     applied?”
   - If later evidence shows real need for reviewed non-core resource-limit control, that work must
     return as **one new explicit decision surface** rather than by silently inheriting shell state.

8) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden parent/session
     `ulimit` state, and crash-dump posture is pinned closed at the boundary.

9) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose inherited host/session resource limits as a hidden side channel
     around the reviewed execution pack.
   - If a foreign runtime cannot bypass login-shell/session `ulimit` carry-over or cannot force
     `RLIMIT_CORE = 0` before launch, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable resource-limit schema or per-step resource-limit descriptor in Phase 1.
- No promise of exact portable values for non-core limits such as `RLIMIT_NOFILE`, `RLIMIT_STACK`,
  `RLIMIT_AS`, or `RLIMIT_CPU`.
- No compatibility table translating legacy shell `ulimit` profiles into D-CAPSHELL policy.
- No portable query/report surface exposing launcher-parent resource limits.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `env-schema-v0.md`
  - `cwd-schema-v0.md`
  - `stdio-schema-v0.md`
  - `fdset-schema-v0.md`
  - `capshell-umask-posture-v0.md`
  - `rfcs/0086-crash-capsules-and-shareable-evidence-bundles.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-RLIMIT-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-RLIMIT-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_rlimit_posture.py` (**EVID-2026-330**).

## References

- REF-OPENGROUP-GETRLIMIT
- REF-OPENGROUP-ULIMIT
- REF-SYSTEMD-COREDUMP-MAN
