# D-CAPX / D-PLUMB import-to-docref bearer-provenance boundary v0 (`origin.import_ref_digest`; no raw bearer bytes in object metadata)

Purpose: pin one **minimal non-secret provenance hook** on top of the bearer→docref bridge so a fresh imported local object does not become a parentless document with no mechanically queryable memory of which explicit import handoff created it.
This boundary adds exactly one breadcrumb rather than a new provenance subsystem:
**when CH-SREF / CH-CAPX restore/import materializes document-like content for routine document workflows, Phase 1 may record one exact `origin.import_ref_digest` on the fresh local object, but routine object metadata must never carry raw bearer material, capability URLs, or hidden re-open/re-fetch semantics.**

This keeps the seams honest:
- D-CAPX / CH-SREF still owns explicit bearer restore/import,
- CH-DOCREF still names a provider-local document object rather than raw bearer material,
- D-QUAR still treats imported document-like content as quarantine-first local input,
- and CH-ATTR gains one digest-only breadcrumb instead of a capability-bearing metadata backchannel.

## Posture (v0)

1) **Materialized local objects record one exact import-object digest**
   - When CH-SREF / CH-CAPX restore/import is bridged into routine document workflows, the fresh local object MAY record `origin.import_ref_digest = digest(exact accepted import object)`.
   - The digest names the exact CH-SREF / CH-CAPX handoff object accepted on the import seam, not a guessed remote locator and not “whatever token later resolves to the same bytes.”
   - `origin.import_ref_digest` is evidence, not bearer reuse.

2) **Routine object metadata never stores raw bearer material or remote locators**
   - Routine document/object metadata MUST NOT store raw CH-SREF / CH-CAPX bytes, capability URLs, secret restore strings, or hidden remote refresh pointers.
   - `origin.locator_hint` remains informational only and cannot be used to smuggle raw bearer material, authority-bearing URLs, or implicit refresh/reopen instructions into CH-ATTR.
   - Digest-only evidence is the portable ceiling on this seam.

3) **`origin.import_ref_digest` does not replace parent/object lineage**
   - `origin.import_ref_digest` is an optional breadcrumb about the explicit import handoff that created the fresh local object.
   - It does **not** replace `origin.parent_digest` for safe-open kept/exported output, does not replace CH-PROV chain semantics, and does not make imported objects their own parent.
   - Imported objects may carry both ordinary object-local lineage and this digest-only import breadcrumb when policy enables both.

4) **No implicit restore/re-fetch/refresh from provenance metadata**
   - The presence of `origin.import_ref_digest` MUST NOT grant reopen authority, trigger remote re-fetch, or imply that a later docref reopen can recover the original bearer material.
   - Any later sync, refresh, or publish against the remote bearer target remains a separate explicit D-CAPX / CH-SREF action.
   - The digest is a receipt hook, not a resumable capability.

5) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - Independent imports commute with respect to requester authority and object creation even when their accepted import objects later resolve to equal bytes.
   - Non-commutative behavior stays where it already lives: explicit destination mutation, explicit later publish/replace, or explicit remote gateway actions.

6) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat runtimes may participate only through explicit, policy-killable import adapters that preserve **fresh local object + digest-only provenance + no hidden restore/re-fetch** semantics.
   - Compat must not surface raw capability strings in routine document metadata or reinterpret `origin.import_ref_digest` as an authority-bearing reopen channel.
   - If an interop path cannot preserve this boundary, it fails closed for document workflows.

## Phase 1 non-goals (explicitly deferred)

- **No raw CH-SREF / CH-CAPX bytes or capability URLs in routine object metadata**.
- **No typed import-object mini-schema inside CH-ATTR**.
- **No implicit restore/re-fetch/refresh** from `origin.import_ref_digest` or `origin.locator_hint`.
- **No replacement of `origin.parent_digest` or CH-PROV chain semantics**.
- **No app-visible import-object inventory/search/watch API**.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-CAPX, D-PLUMB, D-QUAR)
- Related posture / schema surfaces:
  - `import-to-docref-boundary-v0.md`
  - `import-to-docref-fresh-identity-boundary-v0.md`
  - `capx-posture-v0.md`
  - `sturdyref-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `quarantine-posture-v0.md`
  - `document-handle-schema-v0.md`
  - `origin-quarantine-attrset.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-SREF-3a, I-DOCREF-1a, I-QUAR-1a)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-SREF-EXPLICITA, PO-DOCREF-REOPENA, PO-QUAR-PROPA)
- RFC / engineering history:
  - `rfcs/0004-networked-capabilities-and-delegation-tokens.md`
  - `rfcs/0014-sturdyrefs-and-capability-uris.md`
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_import_to_docref_bearer_provenance_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **digest-only provenance / no raw bearer bytes in metadata / no hidden restore-or-refresh / no parent-lineage replacement** constraints, or drops its primary REF wiring.

## References

- REF-TAHOE-LAFS.
- REF-XDG-PORTAL-DOCUMENTS.
