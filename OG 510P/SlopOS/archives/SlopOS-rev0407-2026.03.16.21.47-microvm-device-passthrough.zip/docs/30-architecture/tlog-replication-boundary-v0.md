# Transparency-log replication boundary (v0)

Purpose: narrow **OQ-0001** for `object_family = tlog` without turning replicated append-only evidence into ambient cross-cluster authority.

`D-TLOG`, `CH-TLOG v0`, and RFC-0029 already pin transparency logs as an **optional, out-of-band evidence lane** for release/provenance material.
Hybrid needs one additional hard decision so the one admitted RC4 family does not quietly become a second control plane:

- replicated `tlog` state is **append-only evidence material only**, and
- **local explicit policy still decides which log origins, public keys, witness thresholds, and anchor requirements matter for acceptance of any claim**.

This keeps `rc4_ordered_log` honest: the only thing that is globally ordered is the transparency log's own append-only history, not the operating system's runtime authority graph.

## Decision (v0)

For `object_family = tlog` under CH-REPLCONTRACT v0:

1. The authoritative object is the append-only **log evidence stream scoped by `log_id`**: signed checkpoints, inclusion proofs, consistency proofs, tiles, and optional witness bundles/cosignatures.
2. RC4 ordering is scoped to **that log's Merkle history only**. Replication of `tlog` material MUST NOT be reused as:
   - a global runtime serialization bus,
   - a scheduler/lease freshness clock,
   - a cluster-wide transaction sequence, or
   - proof that a privileged action happened "before" another action unless a separate local policy explicitly binds that claim.
3. Replicas MAY cache, gossip, mirror, or snapshot CH-TLOG v0 evidence artifacts, but those artifacts MUST NOT by themselves:
   - grant boot/update/admission authority,
   - auto-promote a new `log_id`, log origin, public key, shard, or witness quorum into the trusted set,
   - force runtime allow/deny decisions without an explicit local verification policy,
   - become a general ordered workflow queue for CH-ACP / hot actions, or
   - override local retention/export policy for release/provenance evidence.
4. Acceptance of an anchored artifact remains a **local explicit verification step** against pinned policy inputs such as `{log_id, pubkey_id, origin, witness policy, required leaf kinds}`.
5. If replicated `tlog` material is stale, missing, or inconsistent, receivers MUST fail according to the local evidence policy (e.g. reject an "audit-complete" claim, mark evidence advisory-only, or request refresh). They MUST NOT guess trust roots or silently downgrade mandatory verification.
6. Any future desire to use transparency-log material as an online admission oracle, distributed sequencer, or cluster-wide freshness service must land as a **new RFC-first seam** rather than by widening `object_family = tlog` in place.

## Why RC4 fits here

`tlog` is the one v0 family where ordered append-only semantics are the point of the object.
The archive already reserves RC4 to this lane because transparency systems need checkpoints plus consistency proofs over an ordered Merkle history.
What does **not** follow is that the rest of SlopOS should start borrowing that order as ambient substrate truth.

By freezing `tlog` as an evidence lane only, SlopOS keeps:

- global order **rare and explicit**,
- runtime authority in existing local seams (update policy, boot policy, portal/ACP validators), and
- witness/checkpoint machinery available for audit without coupling execution to remote infrastructure.

## Explicit non-goals (v0)

Phase 1 does **not** standardize:

- using `tlog` as a global transaction bus or lock service,
- deriving scheduler time, lease freshness, or request deadlines from checkpoint order/tree size,
- automatic trust-root / shard / witness rotation from replicated checkpoints,
- making runtime hot actions block on online transparency-log reachability, or
- treating mirrored log state as a substitute for local CH-POLICY / IF-BOOT / release verification rules.

## Source notes

- RFC 9162 defines append-only transparency logs around **signed tree heads/checkpoints plus inclusion and consistency proofs** (REF-CT-RFC9162).
- Transparency witnesses reduce split-view risk by **verifying append-only evolution and counter-signing consistent checkpoints** (REF-TRANSPARENCY-WITNESS).
- Tessera keeps witnessing/checkpoint publication as log/evidence infrastructure, which fits SlopOS's out-of-band D-TLOG posture (REF-TESSERA).

## Consequences for the archive

- `replication-object-family-registry.md` should treat `tlog` as **append-only evidence only**, not a generic ordered control plane.
- `profile-repl-defaults.md` may keep B on RC4 and D on RC2 snapshots by default, but the notes must say that trusted log identities/witness policy remain local explicit configuration.
- `replication-contracts-v0.md`, `transparency-log-anchor-schema-v0.md`, RFC-0029, and the decision map should point out that replicated checkpoints/proofs are evidence artifacts, not runtime authority.
- Any future stronger semantics (online admission gating, global ordering service, mandatory runtime sequencer, auto-trusted witness distribution) must pay for a new decision surface.
