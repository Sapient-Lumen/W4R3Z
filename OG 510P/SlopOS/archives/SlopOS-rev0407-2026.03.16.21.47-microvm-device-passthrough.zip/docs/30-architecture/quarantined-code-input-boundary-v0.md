# D-QUAR quarantined code-input boundary v0 (no laundering through `stdin` / `-c` / eval-like interpreter entry)

Purpose: close the seam between **D-QUAR** deny-by-default exact execution and the explicit-interpreter
postures in **D-CAPSHELL**. Phase 1 already says quarantined exact executable/script objects do not gain a
portable `run_untrusted` lane, and that explicit interpreters remain allowed when they are chosen as the
one `role="exec"` selector. Without one more boundary, later implementations can still launder risky code by
reading a quarantined object and restaging its bytes as `stdin`, `-c`, `--eval`, `-m`, or another
interpreter-specific code entry path.

This adjunct keeps the archive small and implementable:
quarantine still does **not** become a general source-code taint subsystem, but when an exact workflow
binds a code-bearing input object for an explicit interpreter/runtime, that object remains upstream of
the same explicit clear/override gate as a quarantined script file.

## Posture (v0)

1) **Quarantine gating covers code-bearing interpreter inputs, not only the main executable object**
   - If the reviewed `role="exec"` selector is an explicit interpreter/runtime, any separately bound
     object whose declared role is to supply **code to be executed** remains upstream of quarantine
     policy.
   - That includes obvious cases such as a reviewed script file argument, and also reviewed object
     bindings that feed code through `stdin`, a descriptor/FD, a module/archive/package entry, or a
     runtime-specific code-evaluation switch.
   - In other words: Phase 1 does not let “trusted interpreter + quarantined code object” bypass the
     quarantined-execution boundary just because the bytes are no longer named `argv[0]`.

2) **No laundering via `-c`, eval-like flags, or interpreter `stdin` when bytes come from a quarantined object**
   - Runners/front-ends MUST NOT read bytes from a quarantined object and then restage those bytes as
     an ordinary CH-ARGV literal, command string, `stdin` stream, or equivalent code-evaluation input
     in order to make the launch look like “the interpreter is trusted.”
   - If a reviewed code-bearing input object remains `quarantine.state = quarantined`, ordinary exact
     execution fails closed before effect even when the main executable is a cleared interpreter.
   - This keeps `capshell-script-entry-posture-v0.md`, `capshell-command-string-posture-v0.md`, and
     `quarantined-execution-boundary-v0.md` aligned instead of letting them cancel each other out.

3) **User-authored literals stay distinct from bound quarantined objects**
   - Phase 1 does **not** claim that every literal string passed to an explicit interpreter is a
     quarantined object.
   - Inline source typed directly by an operator or generated as ordinary workflow text is governed by
     the existing explicit-interpreter / command-string posture, not by hidden provenance inference.
   - This boundary applies when code bytes are sourced from a **reviewed bound object** whose
     quarantine/origin state is already known.

4) **Ambiguous code-bearing positions must be declared or fail closed**
   - Some runtimes expose multiple code-entry forms (`-c`, `--eval`, module/package execution,
     archive/zip execution, `stdin`, loader hooks, etc.).
   - Phase 1 adds no portable per-runtime flag taxonomy, but any adapter/profile that treats a bound
     object as code for such a position must declare that interpretation explicitly enough for the
     quarantine gate to apply.
   - If the active runtime cannot preserve that distinction, it MUST fail closed rather than assuming
     the input is “just data.”

5) **Clear/override remains the only bridge, and it stays object-local**
   - Executing code sourced from a quarantined object still requires the existing explicit,
     object-local IF-CONSENT + CH-LOG clear/override bridge.
   - Clearing the interpreter does not clear the code object, and clearing one code object does not
     recursively bless sibling files, later imports, or future derivations.
   - `open_untrusted`, preview success, static inspection, or successful sandboxed execution do not by
     themselves authorize later exact execution of quarantined code-bearing input objects.

6) **Ordering and conflict keys stay on existing seams**
   - This boundary does not mint a new externally visible action family.
   - Quarantine clear / override serializes where it already serializes: the object-local consent /
     transcript seam keyed to the source object digest.
   - Normal execution ordering stays where it already lives for `capshell.exec` / exact-object launch
     (for example `domain.id` and `svc:IF-CAPSHELL`).

7) **Sealed compat remains killable and non-ambient**
   - Compat layers MUST NOT turn a quarantined code object into “safe” exact execution by piping it to
     a trusted interpreter behind the membrane, by wrapping it in a generated `-c` command string, or
     by hiding it inside a runtime-specific eval/import convenience path.
   - If a foreign runtime cannot preserve both explicit interpreter binding and quarantine gating for
     bound code objects, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No generic source-code taint engine or language-agnostic static classifier.
- No portable registry of every interpreter flag that can execute code.
- No hidden object-to-`stdin` / object-to-`-c` / object-to-`--eval` coercion layer.
- No provenance guessing for user-authored inline literals that were never bound as objects.
- No portable `run_untrusted` lane or interpreter-specific sandbox helper.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-QUAR, D-CAPSHELL)
- Adjacent posture docs:
  - `quarantined-execution-boundary-v0.md`
  - `capshell-script-entry-posture-v0.md`
  - `capshell-command-string-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-6, I-ARGV-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-EXEC, PO-CAPSHELL-ARGV-BIND)
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- RFC history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`

CI drift gate:
- `tools/check_quarantined_code_input_boundary.py` fails `make lint` if the boundary stops being
  discoverable, if quarantined code objects regain a `stdin` / `-c` / eval-like laundering path
  through cleared interpreters, or if explicit interpreters silently bypass the existing quarantine
  clear/override gate for bound code-bearing objects.

## References

- REF-OPENGROUP-SHELL-CMDLANG.
- REF-PYTHON-CMDLINE.
- REF-NODE-CLI.
