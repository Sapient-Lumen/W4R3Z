# Capshell startup-profile posture v0 (no implicit rc/profile files or per-directory hooks)

Purpose: keep **D-CAPSHELL** honest for the *interactive shell/session* side of the design. The
archive already pins explicit exec selection, explicit script entry, explicit child env, and
structured argv for `capshell.exec`. But an integrated shell can still quietly reopen ambient
authority if **session startup or prompt/cwd transitions execute code discovered from the host
filesystem**.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a startup-profile
schema, a dotfile compatibility layer, or a general “safe shell customization” subsystem. It only
freezes the Phase 1 answer: **capshell session startup is explicit-only, and prompt/cwd changes are
not code-loading events**.

## Posture (v0)

1) **No implicit rc / profile / dotfile startup in v0**
   - Integrated capshell session startup MUST NOT consult host/user/project startup files such as
     `/etc/profile`, `~/.profile`, `~/.bashrc`, or equivalent dotfile search paths.
   - Wrapper-first adoption tooling and compat shims MUST NOT pre-source host startup files before
     crossing into the reviewed capshell execution/session boundary.
   - Phase 1 therefore declines the familiar “shell starts by discovering profile code from the
     namespace” model.

2) **No per-directory hooks or prompt-time code loading**
   - Prompt redraw, `cd`, or cwd rebinding MUST NOT trigger filesystem-controlled startup hooks such
     as `.envrc`, `.env`, virtualenv activation scripts, or similar project-local auto-activation.
   - Capshell prompt state may *display* explicit already-held authority state, but it MUST NOT run
     hidden code because the current directory changed or because a prompt hook fired.
   - Directory-local policy remains an explicit review/binding problem, not a hidden ambient shell
     behavior.

3) **Convenience state stays built-in or future-explicit**
   - Phase 1 integrated capshell MAY provide built-in commands, help, completion, prompt rendering,
     and wallet/contract views that are part of the shipped product surface.
   - It MUST NOT treat user/project startup code as part of the trusted baseline by convention.
   - Any future reusable startup/customization surface must return as an explicit RFC-first,
     digest-bound artifact or policy seam rather than by silently widening dotfile discovery.

4) **Commutativity and ordering stay on existing action seams**
   - This posture does not mint a new externally visible action family.
   - `capshell.exec` keeps its existing conflict keys, commutativity stance, ordering witness, and
     serialization boundary (`domain.id`, ordered within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that implicit session-start and cwd/prompt code-loading paths are
     forbidden instead of being treated as harmless convenience.

5) **Sealed compat remains killable and non-ambient**
   - Compat wrappers may still launch legacy tools, but they MUST keep session/bootstrap semantics
     explicit across the membrane.
   - “Works on my shell because my rc files or directory hooks ran first” is not a valid capshell
     compatibility story.
   - Any future compat affordance that reintroduces startup files or per-directory hooks must remain
     an explicit, policy-killable compat decision rather than ambient behavior inside D-CAPSHELL.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.startup.*` ACP kind, no shell-profile registry, no directory-hook
     approval cache, and no generic “load this dotfile” API.
   - If we later want explicit startup manifests, policy-bound shell customizations, or reviewable
     project activation bundles, that must land as a separate RFC/decision surface.

## Phase 1 non-goals (explicitly deferred)

- No portable shell rc/profile compatibility layer.
- No project-local auto-activation protocol (`.envrc`, `.env`, venv activation, etc.).
- No host/user dotfile import into capshell startup.
- No generic startup-profile schema hidden inside CH-ENV, CH-EXECPACK, or wallet metadata.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Existing adjacent seams:
  - `capshell-env-startup-posture-v0.md`
  - `capshell-command-string-posture-v0.md`
  - `capshell-exec-pack-schema-v2.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-STARTUP-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-NORC` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_startup_profile_posture.py` (**EVID-2026-323**).

## References

- REF-BASH-STARTUP
- REF-OPENGROUP-SHELL-ENV
- REF-DIRENV
- REF-SHILL-OSDI14
