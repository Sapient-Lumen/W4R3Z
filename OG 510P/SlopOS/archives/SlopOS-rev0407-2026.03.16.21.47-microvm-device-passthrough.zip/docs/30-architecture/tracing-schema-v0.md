# CH-TRACE v0 (trace event record schema, informal)

Purpose: a minimal, canonical trace event record emitted by tracepoints and exported via IF-OBS.

This is **not** an in-kernel scripting system. It is a stable, typed record format for predeclared tracepoints.

Refs: REF-DTRACE.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- closed set of event kinds and value types (no free-form JSON)
- bounded size (drop/overflow is explicit and deterministic)
- no secrets by default (I-OBS-1); redaction/allowlists are policy-driven

## Shape (v0)
A trace event `t` contains:
- `schema`: fixed `CH-TRACE v0`
- `seq`: monotonically increasing sequence number within a stream
- `probe`: tracepoint identifier (closed enum per build/profile)
  - If D-TPROBE is enabled, `probe` is interpreted using the pinned CH-TPROBE table (field names/types/redaction), and `args[i]` corresponds to `fields[i]`.
- `domain`: optional bounded tag identifying the emitting domain/component (opaque)
- `ts`: optional timestamp field (only if enabled by profile; otherwise absent)
- `args`: bounded list of typed values

### Value types (closed)
Allowed `args` value variants:
- `u64` / `i64`
- `bool`
- `small_bytes` (bounded length; intended for hashes/digests)
- `small_str` (bounded UTF-8; intended for tags, not secrets)
- `cap_ref` (opaque, non-capability-bearing identifier; must not be a bearer token)

## Validation obligations
- reject unknown `probe` IDs for the active profile
- enforce bounds on `args` length and element sizes
- if CH-TPROBE is pinned (D-TPROBE), enforce `args` length/type agreement with the descriptor for this `probe`; mismatches drop/fail closed (PO-TPROBE-MATCH)
- reject any bearer-capability strings (e.g., CH-SREF material) unless explicitly authorized and redaction-marked

## Notes
- This schema is designed to be “cheap to validate” and “hard to misuse.”
- If D-RR is enabled, traces are *observations*; they are not treated as replay inputs.

## Interaction with D-TRACEPROC (optional)
If D-TRACEPROC is enabled, CH-TRACE records may be consumed by user-space trace processors (often Wasm) to produce bounded aggregates without exporting raw traces.
If D-TPRED is enabled, trace portals MAY apply bounded CH-TPRED predicates as prefilters to reduce event volume before buffering/export (portal-only by default; optional source-prefilter per profile).
