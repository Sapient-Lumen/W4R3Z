# Capshell launch scheduling posture v0 (no inherited `nice` / scheduler-policy baseline)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools whose behavior depends on inherited
CPU **scheduling state**: `nice` value, scheduler policy/class, or static scheduler priority carried
across the runner/wrapper boundary. The archive already says execution context is explicit and
reviewable, but that promise still drifts if the child launch quietly inherits parent/login-shell/
session scheduling posture that never appears in the reviewed execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic job
scheduler, a per-step QoS API, or a reviewed descriptor for arbitrary scheduler tuning. It only
freezes the minimum Phase 1 posture needed so launch behavior stops depending on hidden
shell/session `nice` or scheduler-policy state across all four product shapes.

## Posture (v0)

1) **No inherited shell/session scheduling baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit scheduling state merely because the parent shell, wrapper,
     login profile, service manager, or host session already had it.
   - Ambient launch state includes inherited `nice` bias, privileged or special scheduler classes,
     and static scheduler priority that never appears in the reviewed execution pack.

2) **Phase 1 adds no reviewed per-step scheduling surface**
   - Phase 1 introduces no reviewed scheduler-policy descriptor family, no `capshell.sched.*`
     ACP/admin family, and no per-step workflow knobs for `nice`, real-time policy, batch/idle
     policy, or static scheduler priority.
   - The portable seam is therefore: **do not carry launcher/session scheduling state across the
     reviewed boundary**.
   - If a runtime/provider wants fixed scheduling ceilings or placement policy for a deployment
     class, that remains local implementation policy and MUST be independent of parent
     shell/session state.

3) **Launch normalizes CPU scheduling state at the boundary**
   - Before `exec` (or via equivalent spawn attributes), the runner/wrapper MUST start the child in
     the platform's **default non-real-time time-sharing policy** with a **neutral nice value (`0`)
     on POSIX-like hosts**.
   - Launch MUST NOT preserve inherited negative `nice`, inherited real-time/deadline policy,
     inherited batch/idle policy, or inherited static scheduler priority from the parent
     shell/session.
   - Compat/foreign-cell membranes that cannot guarantee that normalized launch posture MUST fail
     closed rather than preserving host defaults.

4) **Programs may still manage their own scheduling after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen shell/interpreter/program after it begins running.
   - If an explicitly selected tool later adjusts its own `nice` or scheduler policy inside
     reviewed program logic, that behavior belongs to the chosen program/runtime rather than to
     ambient launch state.

5) **Other explicit seams do not secretly mint or repair scheduling state**
   - **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and **CH-REQCTX v1** do not
     authorize synthesizing or translating parent shell/session scheduling state into the child.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt UX, or terminal/session UX) MUST NOT become hidden carriers for inherited `nice` or
     scheduler-policy state.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable scheduler-policy descriptor family, no policy knob for varying
     launch priority/class per workflow step, and no admin query surface for “what inherited
     scheduling state was applied?”
   - If later evidence shows real need for reviewed launch-time scheduling control, that work must
     return as **one new explicit decision surface** rather than by silently inheriting shell state.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden parent/session
     `nice` or scheduler-policy state.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose inherited host/session scheduling state as a hidden side
     channel around the reviewed execution pack.
   - If a foreign runtime cannot bypass login-shell/session `nice` / scheduler-policy carry-over or
     cannot normalize the child to a default non-real-time time-sharing policy plus neutral nice
     value, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable scheduler-policy schema or per-step launch-priority descriptor in Phase 1.
- No portable guarantee about exact provider-internal CPU shares, cgroup weights, or placement.
- No compatibility table translating legacy shell/service-manager priority profiles into
  D-CAPSHELL policy.
- No portable query/report surface exposing launcher-parent scheduling state.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-umask-posture-v0.md`
  - `capshell-rlimit-posture-v0.md`
  - `capshell-signalstate-posture-v0.md`
  - `capshell-job-control-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-SCHED-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-SCHED-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_scheduling_posture.py` (**EVID-2026-332**).

## References

- REF-MAN7-SCHED
- REF-MAN7-SETPRIORITY
- REF-MAN7-SCHED-SETSCHEDULER
