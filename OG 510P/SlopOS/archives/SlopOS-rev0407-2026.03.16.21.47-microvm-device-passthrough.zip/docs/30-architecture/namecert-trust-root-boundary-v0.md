# D-NAMECERT trust-root boundary v0 (explicit evaluator anchors; no self-anchoring or ambient root distribution)

Purpose: narrow the **trust-anchor / trust-root** meaning of **D-NAMECERT** so local naming does not quietly
turn into a self-certifying PKI, a replicated root-store distribution plane, or a hidden trust-policy VM.

This doc attaches to the existing **D-NAMECERT / D-REPL / D-NS** seams rather than inventing a new one.
It resolves one practical Phase 1 question: **when CH-NAMECERT bundle bytes are presented, where does trust
actually come from — the bundle itself, or an explicit local evaluator policy that chooses which issuers count
as roots/anchors?**

## Boundary (v0)

1) **Trust anchors are explicit evaluator-local input**
   - Any admission decision over **CH-NAMECERT v0** uses an **explicit local trust-anchor / issuer-allowlist / trust-policy input** chosen by the evaluator or deployment.
   - That input may be compiled configuration, a pinned local policy artifact, or another already-authorized local mechanism, but it is **not inferred from the presented bundle bytes**.
   - In other words: **trust anchors are explicit evaluator-local input**, not ambient resolver state.

2) **CH-NAMECERT is not itself a trust root or trust-policy container**
   - **CH-NAMECERT v0** carries naming/delegation evidence only; it does **not** standardize root-store distribution, trust weights, issuer reputation, or a portable trust-policy language.
   - A verifier that has no explicit local anchor input has no basis to treat a presented bundle as authoritative just because it is signed.
   - If we later need portable trust-policy or trust-anchor distribution, that must land as a separate RFC-first seam rather than by silently widening CH-NAMECERT in place.

3) **No self-anchoring or transitive root installation**
   - A bundle MUST NOT be allowed to say, in effect, “trust this issuer because this bundle says so.”
   - Encountering a new issuer key, delegation subject, or certificate chain inside the presented set MUST NOT auto-promote that key into the trusted anchor set.
   - Phase 1 therefore declines **self-anchoring**, **trust-on-first-bundle**, and any “import this certificate and also trust its root” behavior on D-NAMECERT.

4) **Replication distributes bundles, not anchors**
   - Cross-cluster `object_family = namecert` replication remains **signed bundle-set evidence only** as pinned by `namecert-replication-boundary-v0.md`.
   - Replicated arrivals MAY widen the observed evidence set for a later explicit admission attempt, but they MUST NOT auto-install new trust roots, rewrite the local issuer allowlist, or create “cluster-majority trust” semantics.
   - There is no ambient root-store sync, no hidden trust-anchor gossip plane, and no “latest trust root wins” rule on D-NAMECERT.

5) **Changing anchor policy affects future admissions, not live bindings**
   - Refreshing or editing the local trust-anchor / issuer-allowlist input MAY change the outcome of **future** CH-NAMECERT evaluations.
   - It MUST NOT silently rewrite the active view, auto-run `view.detach`, or mutate earlier source `digest(CH-NAMECERT v0)` receipts merely because the evaluator now trusts (or distrusts) a different issuer set.
   - Explicit later removal still lands on the reviewed target seam, just as with time or revocation boundaries.

6) **Authority-bearing effects still land only on the target seam**
   - D-NAMECERT trust-anchor choice is part of the evaluator’s local admission context, not a new authority surface.
   - If a trusted bundle result becomes live authority in Phase 1, it still materializes only through explicit **`view.attach`** / **`view.detach`** on concrete **`view.slot`** keys, with source **`digest(CH-NAMECERT v0)`** evidence retained on the target seam.
   - D-NAMECERT therefore adds **no new conflict-key family**, **no new ordering stream**, and **no standalone ACP/admin plane** for trust-root lifecycle.

7) **Sealed compat remains honest**
   - Compat shims and foreign-cell bridges MUST NOT smuggle in host-global certificate stores, browser trust decisions, or automatic “accept system roots” behavior that bypasses the explicit local D-NAMECERT evaluator policy.
   - Any compat trust mapping must remain policy-killable and must not create ambient channels through host path lookups, env vars, or implicit network fetch.

## Phase 1 non-goals (explicitly deferred)

- **Bundle-embedded trust-root installation** or trust-on-first-bundle semantics.
- **Replicated trust-anchor distribution** or cluster-majority trust rules on D-NAMECERT.
- **Portable trust-policy / issuer-reputation language** on CH-NAMECERT itself.
- **Automatic detach / receipt rewriting** when local trust-anchor policy changes later.
- **A global CA/root-store model** for local naming.

## Wiring

- Core local naming posture: `namecert-posture-v0.md`
- Schema notes: `namecert-schema-v0.md`
- Replication boundary: `namecert-replication-boundary-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- Target namespace seam: `view-namespace-posture-v0.md`
- RFC: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**, **I-NAME-2**, **I-NAME-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-CHAIN**, **PO-NAMECERT-PROJECT**)

CI drift gate:
- `tools/check_namecert_trust_root_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **explicit evaluator-local anchor / no self-anchoring / no replicated trust-root distribution / no auto-detach** stance, or drops its assurance / REF wiring.

## References

- REF-SDSI-RL96.
- REF-SPKI-RFC2692.
- REF-SPKI-RFC2693.
- REF-KEYNOTE-RFC2704.
