# Capshell handle-table posture v0 (exact child handle table; no ambient inheritance hygiene)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools whose behavior can depend on the
ambient **descriptor table / handle table** inherited from the parent runner, wrapper, login
session, or host runtime. The archive already says **CH-STDIO v0** + **CH-FDSET v0** are the
reviewed binding surfaces, but that promise still drifts if launch semantics are allowed to depend
on best-effort `FD_CLOEXEC` / inheritable-handle hygiene, broad “pass through what is already
marked inheritable” conventions, or platform-specific hidden allowlists that never appear in the
reviewed execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a new descriptor
schema, a generic handle-passing broker, a portable `pass_fds` convenience surface, or a child
handle-table query API. It only freezes the minimum Phase 1 posture needed so child descriptor
state stops depending on ambient parent-process leakage across all four product shapes.

## Posture (v0)

1) **No inherited parent handle/FD-table baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit ambient extra file descriptors / handles merely because the
     parent runner, shell, service manager, or host runtime already had them open and marked for
     inheritance.
   - The reviewed launch boundary therefore treats parent descriptor-table state as **ambient**
     unless it is rebound through explicit capshell seams.

2) **The child handle table is exact, not best-effort hygiene**
   - The child starts with exactly:
     - **CH-STDIO v0** bindings for slots `0..2`, and
     - **CH-FDSET v0** bindings for slots `>=3`.
   - Phase 1 rejects any posture equivalent to “inherit whatever is not `FD_CLOEXEC`” or “inherit
     all handles currently marked inheritable, then hope launcher hygiene was good enough.”
   - Exact child authority must not depend on ambient close-on-exec flags, wrapper defaults,
     library-global spawn policy, or concurrent descriptor activity in the parent process.

3) **Phase 1 adds no reviewed per-step descriptor-inheritance surface**
   - Phase 1 introduces no `capshell.pass_fds`, no reviewed “inherit parent descriptors” knob, no
     `close_fds=false` compatibility mode, and no shell-facing descriptor-table template surface.
   - If future evidence shows a real need for richer launch-time descriptor shaping, that work must
     return as **one new explicit decision surface** rather than widening CH-STDIO / CH-FDSET by
     convention.

4) **Runners must construct an exact child table or fail closed**
   - On POSIX-like runtimes, wrappers/runners MUST ensure the post-`exec` child sees only the
     reviewed stdio/fdset bindings; relying solely on ambient `FD_CLOEXEC` discipline is
     insufficient.
   - On handle-table runtimes, wrappers/runners MUST use an exact inheritance allowlist mechanism
     (or an equivalent exact child-table construction) rather than inheriting the ambient set of
     handles currently marked inheritable.
   - Compat/foreign-cell membranes that cannot guarantee this exact-child-table posture MUST fail
     closed rather than preserving host inheritance lore.

5) **Other explicit seams do not secretly widen child handles**
   - **CH-ENV v0**, **CH-CWD v0**, **CH-REQCTX v1**, **CH-PLUMBMSG v0**, and learn-mode reports do
     not authorize inheriting extra parent descriptors/handles.
   - Phase 1 also declines hidden descriptor transfer via shell/session startup, wrapper policy,
     service-manager conventions, or parent-side “helper” sockets that were never named in
     CH-STDIO / CH-FDSET.

6) **No hidden peer-stage transfer or sibling bleed-through**
   - This posture reinforces `capshell-pipeline-posture-v0.md`: one stage’s bound handles do not
     become another stage’s implicit inherited baseline.
   - Peer stage-to-stage handoff still requires explicit CH-AREF / CH-PLUMBMSG / portal output
     rebinding in the next stage’s own CH-EXECPACK v2.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no public list/watch/query surface for “what handles would this child
     inherit?”, no admin override for ambient descriptor inheritance, and no portable workflow knob
     that re-enables parent-table inheritance.
   - Any future portability surface for descriptor inheritance must pay for its own action family,
     commutativity analysis, and receipts instead of hiding inside runner defaults.

8) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain those already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that child descriptor state no longer depends on ambient parent
     handle/FD-table leakage or best-effort inheritance hygiene.

9) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT preserve host ambient descriptor inheritance behavior as a hidden
     side channel around reviewed CH-STDIO / CH-FDSET bindings.
   - If a foreign runtime cannot suppress inherited extra descriptors/handles or cannot construct an
     exact reviewed child table, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No reviewed `pass_fds` / `inherit_handles` compatibility surface in Phase 1.
- No descriptor-table query/report API for children.
- No launcher mode that depends on ambient `FD_CLOEXEC` / inheritable-handle hygiene.
- No shell/session convenience surface for “inherit this process’s current extra descriptors.”

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `stdio-schema-v0.md`
  - `fdset-schema-v0.md`
  - `capshell-pipeline-posture-v0.md`
  - `capshell-job-control-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-STDIO-2` / `I-FDSET-2` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-STDIO-BIND` / `PO-CAPSHELL-FDSET-BIND` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_handle_table_posture.py` (**EVID-2026-340**).

## References

- REF-OPENGROUP-EXEC
- REF-OPENGROUP-FCNTL
- REF-MAN7-OPEN
- REF-MAN7-POSIX-SPAWN
- REF-MS-CREATEPROCESS
- REF-MS-UPDATETHREADATTR
