# MicroVM serial/console posture v0 (diagnostic sink only; no interactive host channel)

Purpose: pin the **Phase 1** meaning of guest-visible serial / console surfaces under `ext.microvm` so debugging and boot-log plumbing do not quietly become an ambient host↔guest control plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-OBS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 fixes guest-visible serial/console presence + directionality at admission; `ext.microvm` adds no portable interactive serial/console input plane, no runtime backend-rebind/status plane, and no monitor/control multiplexing. If an admitted serial/console surface exists at all, it is off/null or a write-only diagnostic sink rather than a guest↔host capability/control channel.**

Entropy cost justification: the archive already says `ext.microvm` has no hidden host channels, but the mainstream VMM ecosystem exposes exactly the surfaces that turn “just debugging” into ambient authority: serial redirected to stdout/files, console PTYs and sockets, and multiplexed console+monitor backends. One narrow posture closes that gap without inventing a new schema family, guest-agent protocol, lane, or control plane.

## Posture (v0)

1) **Guest-visible serial/console posture is fixed at admission**
   - For Phase 1, each admitted `ext.microvm` leaf has **one exact guest-visible serial/console presence + directionality stance** fixed at admission.
   - Portable semantics do **not** include changing a running guest from `off`/`null` to interactive, rebinding one backend type to another, or switching directionality under the same reviewed portable identity.
   - In plain terms: the reviewed contract is “this leaf has no console, or this leaf has a diagnostic output sink”, not “the host may later turn a debug endpoint into an interactive channel”.

2) **No portable interactive serial/console input plane**
   - Phase 1 standardizes **no portable interactive serial/console input plane** under `ext.microvm`.
   - That means no reviewed portable semantics for host→guest **TTY/PTY/stdin/socket/telnet/websocket input semantics**, login-console interaction, or “connect a terminal now” workflows.
   - Implementations may have local debugging facilities, but they are **not** part of the Phase 1 product contract and must not silently become reviewed meaning.

3) **Diagnostic output is observation-only**
   - If a serial/console surface is enabled at all, serial/console bytes are owner-local diagnostic sinks rather than a guest↔host capability or control plane.
   - Such output may help local diagnosis or owner-local capture, but it does **not** grant host filesystem, shell, policy, capability, or monitor authority, and it does **not** become an ambient remote-export promise.
   - Any later remote forwarding or durable export still rides on explicit existing observation/export seams rather than on ambient console folklore.

4) **No monitor/control multiplexing or shared chardev backends**
   - Phase 1 standardizes **no monitor/control multiplexing or shared chardev backends** for guest-visible serial/console surfaces.
   - That means no reviewed portable semantics where the same backend is shared between guest console traffic and host monitor/control traffic, no escape-sequence control channel, and no “console plus host control plane on one PTY/socket/stdin” contract.
   - If a local VMM supports such features, they remain owner-local implementation details outside the portable product surface.

5) **No runtime rebind / attach / detach / status plane**
   - Phase 1 adds **no portable runtime rebind / attach / detach / status plane** for serial/console backends under `ext.microvm`.
   - That means no reviewed API meaning for concepts such as **currently attached console client**, **backend type/state**, **waiting-for-PTY/socket peer**, **connect/disconnect now**, or **switch this leaf from file/stdout to interactive terminal**.
   - If policy wants a different guest-visible serial/console stance, that change is modeled as a **new reviewed admission / activation choice**, not as mutating a running guest under the same portable identity.

6) **Owner-local capture plumbing stays owner-local and does not become a portable channel contract**
   - Owners/runtimes may still choose local capture/drop plumbing such as stdout redirection, file capture, ring buffers, PTYs, or sockets for their own debugging workflows.
   - What they may **not** do in Phase 1 is let that owner-local plumbing masquerade as a portable interactive host↔guest channel or reviewed serial/console lifecycle API.

7) **No new serial/console control plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for console attach/rebind/control, **no new ACP kind**, and **no new conflict-key family** for guest-visible serial/console mutation operations.
   - If a later design wants portable interactive consoles, console leasing, or host-monitor bridging, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, evidence hooks, and sealed-compat/covert-channel story.

## Phase 1 non-goals (explicitly deferred)

- No portable interactive login console or host terminal attach workflow for `ext.microvm`.
- No portable serial/console backend taxonomy (`pty` / `tty` / `socket` / `stdio` / `telnet` / `websocket`) as reviewed API meaning.
- No console+monitor multiplexing or escape-sequence host-control contract.
- No runtime console rebind / status / attach-detach lifecycle under one admitted leaf identity.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-OBS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `host-guest-channel-posture-v0.md`
  - `observation-export-posture-v0.md`
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `microvm-block-topology-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-17)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-CONSOLE)
- Policy posture:
  - guest-visible serial/console mutation adds **no new lane**, **no portable interactive input plane**, and **no portable monitor/control multiplex** in Phase 1.

CI drift gate:
- `tools/check_microvm_console_channel_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fixed-at-admission serial/console stance / no portable interactive input / output-is-observation-only / no monitor-control multiplex / no runtime rebind-status plane / no new CH-schema-or-ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SERIAL.
- REF-CHYP-COMMANDS.
- REF-QEMU-CHARDEV.
