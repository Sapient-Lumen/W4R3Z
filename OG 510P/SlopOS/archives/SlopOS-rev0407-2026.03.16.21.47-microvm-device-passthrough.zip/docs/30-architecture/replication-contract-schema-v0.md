# CH-REPLCONTRACT v0 (cross-cluster replication contract)

Purpose: pin a **bounded, non-authoritative** description of how selected object families behave across clusters under the Hybrid posture (ADR-0005).
It exists so that:
- cross-cluster ownership/replication is explicit and reviewable (not implicit “it’s global”),
- validators and tooling can fail closed instead of guessing,
- and commutativity/ordering requirements can be checked against the pinned hot-action surfaces.

Primary producer: profile/config compiler (user space) or topology/placement tooling (SKB) that already emits CH-CLUSTERMAP.
Primary consumers: routing/placement logic (user space), validators (IF-CFG/IF-BOOT), audit/replay tooling.

Notes:
- CH-REPLCONTRACT is **non-authoritative**: it cannot grant authority, only constrain/describe.
- This schema is intentionally conservative and bounded; it is not a general distributed-systems policy language.

## Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- bounded lists and bounded strings
- closed enums for replication classes and owner rules
- must reference a concrete cluster partition by digest (CH-CLUSTERMAP)

## Shape (v0)
A replication contract `r` contains:
- `schema`: fixed `CH-REPLCONTRACT v0`
- `cluster_map_digest`: digest of the CH-CLUSTERMAP this contract is written against
- `profile_tag` (optional): short string identifying the profile lane (e.g., `workstation`, `cloud`, `appliance`, `agent`)
- `objects`: bounded list of `ObjectContract` entries

### ObjectContract entries
Each `ObjectContract` contains:
- `object_family`: short enum-like string (bounded) identifying the family this applies to
  - v0 strict posture: treat as **registry-closed** (see `replication-object-family-registry.md`); unknown families reject in strict profiles.
  - examples: `view`, `transcript`, `receipt`, `quota`, `budget`, `caprpc_proxy`, `namecert`, `tlog`
- `replication_class`: one of:
  - `rc0_local`
  - `rc1_owner`
  - `rc2_epoch_snapshot`
  - `rc3_comm_merge`
  - `rc4_ordered_log` (v0 reserved to `object_family=tlog`; see `profile-repl-defaults.md`)
- `owner_rule` (required for rc1/rc2/rc4): one of:
  - `home_cluster` (owner is derived from the object’s home placement)
  - `fixed:<cluster_id>` (explicit owner cluster id)
  - `hash_shard:<key_tag>` (deterministic shard-by-key; key_tag is bounded enum-like)
- `conflict_keys` (optional, bounded): list of conflict key tags used for D-COMMUTE reasoning
  - examples: `view_id`, `endpoint_id`, `addrspace_id`, `quota_pool`, `log_id`
- `non_commutative_boundary` (optional): short tag naming the minimal ordering boundary, if any
  - intended to reference labels in `hot-action-boundaries-v0.md`
- `notes` (optional, bounded): short freeform text (<= N chars)

## Validation obligations
- reject unknown `replication_class` values
- enforce that rc1/rc2/rc4 entries have an `owner_rule`
- enforce bounds: `objects` length, string lengths, list lengths
- enforce that `cluster_map_digest` is present and well-formed
- if `owner_rule` uses `fixed:<cluster_id>`, the `cluster_id` must exist in the referenced CH-CLUSTERMAP
- reject duplicate `object_family` entries

## Interop / evidence
- Intended to be bundled with CH-CFG / CH-BOOT “initial conditions” when Hybrid is enabled.
- Supports D-COMMUTE by making cross-cluster ownership and ordering surfaces explicit.
