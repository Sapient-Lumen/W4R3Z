# Foreign Cell adapter commutativity contract (v0)

This document pins how **sealed-compat adapter operations** participate in **Hybrid + D-COMMUTE** reasoning.
It applies only to **adapter receipts / observability** (CH-FADAPT), not to the underlying portal workflows.

Goal: keep the foreign-cell membrane scalable and reviewable without smuggling in accidental global serialization.

## Scope

- Artifact: CH-FADAPT v0/v1 (adapter receipt) (D-FCELL).
- Surfaces: conflict keys (CH-CONFLICTKEY), ordered streams (CH-ORDERTOK), transcripts/receipts (D-COMMUTE).

## Conflict key binding (cell.adapter)

Adapters SHOULD compute and include `conflict_key_digest = digest(CH-CONFLICTKEY v0)` for the **derived** key:

- `family = "cell.adapter"`
- `key.cell_id = <digest-sized bstr cell_id>` (D-TYPEDID; see `typed-id-contract-v0.md`)
- `key.portal_token = <closed CH-PLEDGE portal.* token>`

Derivation is pinned in:
- `docs/30-architecture/conflict-key-derivation-registry.md` (row `cell.adapter`).

Notes:
- This key is for **sharding/correlation/ordering visibility** only. It does not grant authority.
- Strict profiles MAY require presence of `conflict_key_digest` for adapter receipts; otherwise consumers treat it as unknown (conservative).

## Commutativity stance (receipt emission)

CH-FADAPT receipts are **non-authoritative observations** of adapter-mediated host effects.

- Receipts with **different** `conflict_key_digest` commute (they can be merged/reordered across shards).
- Within the **same** `conflict_key_digest`, receipts are treated as **unordered by default** unless an explicit ordering witness is provided.

Rationale:
- The *host effect* ordering constraints (if any) are owned by the underlying portal workflows and their conflict keys.
- Adapters must not invent hidden ordering guarantees; if they claim ordering, it must be explicit.

## When ordering must be made explicit

If an adapter implementation needs to claim or enforce a stable per-cell/per-portal sequence for auditability
(e.g., it serializes legacy ops internally, or it batches multiple portal calls into one ABI op), it MUST:

1) Serialize at an explicit boundary (validator or a named service component).
2) Emit `order_digest = digest(CH-ORDERTOK v0)` in the CH-FADAPT receipt.
3) Ensure the ordering token scope is:
   - `scope.family = "cell.adapter"`
   - `scope.key_digest = conflict_key_digest` (I-ORDERTOK-2)

If ordering is not claimed, adapters MUST omit `order_digest` (do not imply a sequence).

## Evidence hooks (seed)

- Drift gate: CI checks that `cell.adapter` remains a registered conflict-key family, and that CH-FADAPT v1 retains
  the optional `conflict_key_digest`/`order_digest` observability hooks.
- Harness target (future): verify that when an adapter emits `order_digest`, the referenced CH-ORDERTOK validates and is scoped
  to the same derived `cell.adapter` conflict key.
