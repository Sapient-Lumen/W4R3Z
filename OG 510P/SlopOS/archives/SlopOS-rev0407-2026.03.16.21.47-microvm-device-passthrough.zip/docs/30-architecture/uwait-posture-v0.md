# D-UWAIT posture v0 (process-local 32-bit wait/wake; no cross-domain sleep channels)

Purpose: pin an implementable v0 meaning for **D-UWAIT** so fast blocking for user-space locks stays a tiny kernel-assist seam rather than widening into a cross-process signaling substrate, a scheduler-coupled lock service, or a hidden workflow API.
It narrows RFC-0110 into one compact posture validators and harnesses can reason about: process-local address identity, one aligned 32-bit wait word, explicit re-check-after-wake discipline, and no new workflow/ACP surface.

## Posture (v0)

1) **Optional runtime/compat primitive, not a workflow surface**
   - If D-UWAIT is enabled, it is a **low-level runtime / compatibility primitive** for user-space mutexes, condvars, queues, and similar synchronization objects.
   - Phase 1 does **not** standardize an app-facing sleep broker, a lock object family, or a workflow-visible `wait.on_address` service.
   - Wait/wake state is synchronization metadata, not authorization evidence (I-UWAIT-1).

2) **Process-local only in v0; no cross-component or cross-process wait channels**
   - v0 wait queues are scoped to the caller's **single address space / component**.
   - Phase 1 does **not** standardize cross-process futex semantics, shared-memory wait queues across security domains, or remote wake authority derived from shared physical memory.
   - Any future shared-region wait contract must land RFC-first on its own explicit capability surface rather than widening D-UWAIT by implication.

3) **Exactly one aligned 32-bit wait word in v0**
   - The v0 wait identity is one **aligned 32-bit word**.
   - Phase 1 does **not** standardize 8-bit / 16-bit / 64-bit waits, vector waits, or composite multiword conditions on the core seam.
   - This keeps the ABI small and compatible with the common futex lineage while leaving wider encodings to user-space structure design.

4) **Wait + wake only on the core seam; no requeue / PI / owner semantics in v0**
   - The core v0 seam standardizes **wait** and **wake** only.
   - Phase 1 does **not** standardize `requeue`, priority-inheritance, or owner-tracking variants on D-UWAIT itself.
   - Owner-death and inconsistent-state recovery remain the separate D-ROBUSTLOCK surface; scheduler-coupled PI remains explicit future/profile work.

5) **Atomic compare-and-sleep; mismatch fails closed**
   - `uaddr_wait` MUST atomically verify that the wait word still equals the expected value before sleeping (I-UWAIT-2; PO-UWAIT-ATOMIC).
   - If the word no longer matches, the operation returns **`BAD_STATE`** and does not sleep.
   - There is no best-effort or polling fallback hidden inside the primitive.

6) **Wake is advisory; callers MUST re-check after return**
   - A successful wake means only that the thread was released from sleep on that wait word.
   - Callers MUST re-read the guarded state after return and MUST tolerate spurious or stale wakes under the documented contract.
   - D-UWAIT therefore remains a sleep primitive for user-space protocols, not a promise that the desired condition is already true.

7) **Ephemeral kernel waiter state only; no persistent objects or rights**
   - Kernel waiter state exists only while threads are blocked and is keyed by normalized wait-word identity.
   - D-UWAIT v0 does **not** mint a durable handle, file descriptor, named kernel object, or rights-bearing waiter capability.
   - This keeps the seam bounded, non-inventory, and unsuitable as a hidden signaling namespace (I-UWAIT-3; PO-UWAIT-BOUND).

8) **Address normalization is explicit; tags do not create new wait identities**
   - Where the platform supports tagged pointers or tagged virtual addresses, the kernel/runtime MUST normalize the wait-word address before deriving waiter identity.
   - Architecture-specific tags must not create distinct wait queues for the same underlying memory location.
   - This keeps D-UWAIT aligned with D-MEMTAG posture rather than turning tag bits into synchronization namespaces.

9) **Cancellation/deadlines are explicit adjuncts, not ambient time**
   - If D-REQCTX is enabled, waits MAY bind an explicit request context for timeout/cancel outcomes.
   - Phase 1 does **not** assume ambient wall-clock time, global timers, or hidden scheduler timeouts on the seam.
   - Timeout/cancel outcomes stay explicit and deterministic under the chosen profile.

10) **Bounded, attributable, and supervision-visible**
   - Waiter records and per-word queue depth MUST be bounded and attributable when D-METER is enabled (I-UWAIT-3; PO-UWAIT-BOUND).
   - Exhaustion fails closed with deterministic outcomes rather than silently spinning or allocating unbounded kernel state.
   - Pathological contention or wake storms SHOULD be visible to D-SUPV / diagnostics as a liveness signal, not hidden behind the primitive.

11) **No new workflow / ACP / conflict-key surface in v0**
   - D-UWAIT v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
   - Therefore **no new conflict-key family is introduced in v0**.
   - Any future admin/export surface (for example, shared wait namespaces, PI policy knobs, or requeue contracts) must land RFC-first with its own serialization boundary, commutativity story, receipts, and policy kill switches.

12) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY use an internal host/runtime futex shim behind the membrane, but Phase 1 does **not** standardize a host-exposed futex FD, path, env var, or ambient shared-memory wake broker.
   - Any compat enablement remains policy-killable and must not recreate hidden cross-domain signaling channels that bypass D-PLUMB / D-FCELL posture.

## Phase 1 non-goals (explicitly deferred)

- Cross-process or cross-component wait-on-address semantics.
- 8-bit / 16-bit / 64-bit wait words, vector waits, or multiword wait conditions on the core seam.
- Standardized `requeue` on the core seam.
- Priority inheritance / owner-tracking in D-UWAIT itself.
- A public wait-object / file-descriptor / waitset bridge dedicated to D-UWAIT.

## Wiring

- Decision surface: `decision-map.md` (D-UWAIT).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (wait-on-address seam)
  - `rfcs/0110-wait-on-address-and-futex-primitives.md` (option space / evidence seed)
  - `rfcs/0111-robust-locks-and-owner-death.md` (separate owner-death surface)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-UWAIT-1, I-UWAIT-2, I-UWAIT-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-UWAIT-BOUND, PO-UWAIT-ATOMIC)
  - `docs/30-architecture/nondet-posture-v0.md` (explicit time/timeout posture)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_uwait_posture.py` fails `make lint` if this posture stops being discoverable, loses the process-local / 32-bit / wait+wake-only / no-new-workflow posture, or drops its primary REF wiring.

## References

- REF-MS-WAITONADDRESS.
- REF-MS-WAITFUNCS.
- REF-LINUX-FUTEX2.
- REF-FREEBSD-UMTX-OP.
- REF-FUCHSIA-FUTEX.
