# Quota replication boundary v0

Purpose: narrow **OQ-0001** by pinning what `object_family = quota` is allowed to mean under Hybrid and RC3.

This doc keeps one tempting ambiguity from turning into a second authority surface: **replicated quota data is observational accounting only**. It does not become remote admission authority, remote budget discovery, or a distributed “ask the merged counter if I may spend” seam.

## Decision (v0)

### 1) `quota` means additive spend summaries under already-issued local credit

When CH-REPLCONTRACT uses `object_family = quota`, the replicated object is a bounded, non-authoritative summary of **charges already accepted** against explicit local payer authority.

Allowed examples:
- additive charge/export records tied to `budget_id` / `meter_id`
- bounded spend summaries for audit, pressure, or owner reconciliation
- lag-tolerant usage exports whose merge is commutative/associative/idempotent

Disallowed examples:
- remote mint/grant/revoke authority
- implicit “borrow from another cluster” admission
- a cross-cluster oracle that says a caller may spend without a local explicit payer object
- inferred rights widening from merged replicas alone

### 2) Authorization still comes from explicit local payer authority

A charge is authorized only by a **local explicit payer object** already available at the execution site:
- local meter/budget mechanism state,
- a validated `digest(CH-BUDGET v0)` sponsorship edge, or
- another profile-explicit local payer handle.

Replicated `quota` summaries may inform audit, reconciliation, or owner diagnostics, but they do **not** by themselves authorize new work. Old summaries cannot resurrect exhausted budgets, and fresher summaries cannot widen a caller’s local budget.

### 3) Rights distribution changes stay on the `budget` / owner-routed seam

Anything that changes the amount or placement of spendable credit is **not** `quota` in v0. It stays on the authoritative `budget` family / issuer seam:
- `mint`
- `split` / `grant`
- `revoke`
- any future cross-cluster credit rebalance / escrow-rights transfer

Those operations remain owner-routed / explicitly serialized (RC1) until a future RFC introduces a new, explicit credit-transfer surface with its own invariants, schemas, and evidence.

### 4) Phase 1 declines implicit distributed admission on quota replicas

Phase 1 does **not** standardize:
- distributed “check merged quota then spend” admission,
- automatic quota borrowing across clusters,
- or background quota-rights rebalancing hidden behind `quota` replication.

If later profiles need escrow-style local spend across regions, they must carry it as **explicitly issued local credit** whose authoritative issuance/transfer remains visible on the `budget` seam. Do not reinterpret `quota` summaries into authority.

## Why this is the right boundary

Escrow-style systems only avoid coordination by **pre-allocating rights** and keeping rights transfer explicit; the replicated merge object is not the authority story by itself (`REF-ESCROW-TODS86`, `REF-BOUNDED-COUNTER-SRDS15`, `REF-CRDT-INRIA11`). SlopOS already has the right authority substrate for this: explicit payer objects, CH-BUDGET sponsorship, and owner-visible mint/split/revoke.

This boundary preserves all four product shapes:
- **A secure workstation**: local responsiveness without hidden remote sponsorship.
- **B cloud substrate**: explicit owner routing for issuer state; replicated usage exports remain cheap.
- **C appliance/separation**: local-only defaults stay simple; no surprise distributed budget logic.
- **D agent/automation OS**: LLM/planner flows can reason over receipts/summaries without silently acquiring spending authority.

## Required wiring

- `replication-contracts-v0.md`
- `replication-object-family-registry.md`
- `profile-repl-defaults.md`
- `hot-action-surface-v0.md`
- `hot-action-boundaries-v0.md`
- `budget-lease-schema-v0.md`
- `rfcs/0012-resource-meters-space-banks-and-budgets.md`
- `decision-map.md`
- `trajectory-map.md`

## Guardrail

CI must fail if the archive stops saying that `quota` replication is **observational only**, or if the core replication/metering docs stop linking this boundary.

Evidence: `EVID-2026-258`.

Tool: `tools/check_quota_replication_boundary.py`.
