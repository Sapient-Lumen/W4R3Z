# D-NS posture v0 (view objects as namespaces; single-slot binding; no privileged `open(path)`)

Purpose: pin an **implementable Phase 1** meaning for D-NS that keeps name resolution non-ambient (I-VIEW-1/I-VIEW-2), keeps Hybrid/commutativity honest (D-COMMUTE), and prevents drift into “just add a global filesystem namespace”.

This doc is intentionally narrow: it does **not** design v1 ergonomics (union mounts, per-process clones). Those remain in RFC-0032.

## Posture (v0)

1) **Namespaces are explicit view objects (no global resolver)**
   - A *view* is a capability-mediated object mapping names to capabilities.
   - Privileged and policy-relevant code MUST obtain name→cap bindings via an explicit view object (I-VIEW-1).
   - Name resolution is *pure*: `resolve(view, name) -> cap | none` (no fallback to ambient state).
   - Base spec: `view-objects.md`.

2) **v0 binding model is single-slot (no overlays/union semantics)**
   - The v0 namespace mutation surface is expressed as **slot-scoped attach/detach** operations.
   - Each `view.slot` holds **at most one** bound capability at a time.
   - “Overlay stacks”, “union mounts”, and “ordered search lists” are **out of scope in Phase 1**.
   - Rationale: union semantics are high-entropy and make determinism/commutativity evidence harder; keep them behind an explicit Phase 2+ decision (RFC-0032).

3) **No privileged `open(path)` / no kernel path parsing**
   - The privileged core MUST NOT provide a syscall/hypercall that parses arbitrary path strings against a global namespace.
   - Any “open-like” UX is built by user space walking an explicit namespace/view (or by consuming directory-like capabilities), keeping the authority edges explicit and lintable.
   - Evidence shape: Fuchsia demonstrates a production system where the kernel avoids a privileged `open` syscall and processes receive an explicit namespace of handle mappings. (REF-FUCHSIA-NS, REF-FUCHSIA-LIFEOFOPEN)

4) **Externally visible actions are transcripted and commutativity-scoped**
   - Namespace mutations are externally visible actions with explicit conflict keys:
     - `view.attach` and `view.detach` are CH-ACP kinds in the closed ACP registry.
     - Conflict key family: `view.slot` (scoped by `{view_id, slot_id}`), so mutations across disjoint slots **commute (keyed)**.
     - Within the same `view.slot`, operations are **ordered** and require an explicit ordering witness (CH-ORDERTOK v0).
     - Serialization boundary is explicit (`svc:view`), so “where serialization lives” is transcript-visible.
   - If a slot mutation is justified by D-NAMECERT evaluation, Phase 1 still uses the same `view.slot` conflict keys and `svc:view` ordering boundary, and the target-seam proposal/receipts retain source `digest(CH-NAMECERT v0)` evidence rather than hidden resolver cache state (`namecert-projection-boundary-v0.md`).
   - CH-NAMECERT validity/freshness may gate whether such a proposal is admitted, but live `view.slot` bindings do not auto-detach when time advances; any later removal stays an explicit target-seam mutation (`namecert-time-boundary-v0.md`).
   - Later local negative evidence or issuer withdrawal likewise does not auto-detach a live binding; if removal is desired, it still lands as an explicit target-seam mutation rather than a hidden revocation side effect (`namecert-revocation-boundary-v0.md`).
  - If CH-NAMECERT evaluation yields multiple admissible candidates, Phase 1 still standardizes no hidden winner-selection rule; any live `view.slot` mutation must identify the exact chosen candidate with retained source digests (`namecert-selection-boundary-v0.md`).
  - Changing the local D-NAMECERT trust-anchor / issuer-allowlist input may change future admission outcomes, but it does **not** silently rewrite active `view.slot` bindings or auto-run detach; later removal remains an explicit target-seam mutation (`namecert-trust-root-boundary-v0.md`).
  - The candidate set itself must come from the explicit presented bundle set under bounded local evaluation, not from ambient/distributed follow-on discovery or background retry (`namecert-search-boundary-v0.md`).

5) **Hybrid replication does not auto-activate bindings**
   - Cross-cluster `object_family = view` replication remains owner-routed metadata only.
   - Replicated summaries/caches MUST NOT silently attach/detach bindings in a receiver's active local view; any such change still goes through explicit `view.attach` / `view.detach` authority and receipts.
   - Boundary: `view-replication-boundary-v0.md`.

6) **Sealing is the steady-state guardrail**
   - View mutation authority SHOULD be dropped after init via sealing/self-restriction (D-SEAL): long-lived components run with a sealed or otherwise mutation-disabled view.
   - This makes “post-init namespace narrowing” one-way and keeps late-binding escape hatches honest.

## Phase 1 non-goals (explicitly deferred)

- **Union/overlay semantics** and ordered search lists: RFC-0032 (Plan 9 + BSD union mount background: REF-PLAN9, REF-PLAN9-NSCROSS, REF-UNIONMOUNT-44BSD).
- **Per-process copy-on-write namespace clones** (`view.clone`) and inheritance defaults: RFC-0032.
- **Service trees / remote mount protocols** (9P-like bridges): RFC-0032 (user space only).
- **Global indexing / search**: any “find” surface is an observation/export surface and must remain view-scoped (I-VIEW-1/I-VIEW-2) with export/redaction policy (D-OBSPOL).

## Wiring

- View object base semantics: `view-objects.md`.
- D-NS decision surface: `decision-map.md`.
- Commutativity/ordering metadata and conflict keys:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`view.attach`/`view.detach`)
  - `conflict-key-family-registry.md` (`view.slot`)
  - `serialization-boundary-registry.md` (`svc:view`)

CI drift gate:
- `tools/check_view_namespace_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “single-slot / no privileged open(path)” constraints, or drops its REF wiring.

## References

- REF-FUCHSIA-NS
- REF-FUCHSIA-LIFEOFOPEN
- REF-UNIONMOUNT-44BSD (deferred v1 overlay semantics inspiration)
