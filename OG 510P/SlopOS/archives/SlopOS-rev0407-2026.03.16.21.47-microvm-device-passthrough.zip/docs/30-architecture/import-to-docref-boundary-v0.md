# D-CAPX / D-PLUMB import-to-docref boundary v0 (explicit materialize; fresh local object; quarantine-first)

Purpose: pin the **exact bridge** from explicit bearer restore/import into routine document workflows so CH-SREF / CH-CAPX do not quietly turn **CH-DOCREF** into a disguised remote reopen token, a live bearer-backed shim, or a trust-laundering shortcut.
It narrows one sentence that the archive already relies on — “restore/import first, then obtain a `docref`” — into one implementable rule:
**if a workflow starts from CH-SREF / CH-CAPX and wants `portal.file.*` or `intent.kind=open_untrusted`, Phase 1 must first materialize a fresh local object, classify it as outside-world input, and only then mint a CH-DOCREF for that local object.**

This keeps the seams honest:
- D-CAPX / CH-SREF stays the **explicit bearer import** path,
- CH-DOCREF stays a **non-bearer local reopen** path,
- D-QUAR still sees imported document-like bytes as risky-origin input,
- and `open_untrusted` remains a `docref`-only safe-open lane rather than a second restore/import API.
- Companion fresh-identity boundary: even when imported bytes match an existing local object, the bridge stays **fresh-object-identity-first** with no `reuse_existing` / content-equality alias collapse (`import-to-docref-fresh-identity-boundary-v0.md`).
- Companion bearer-provenance boundary: the imported fresh local object may record one exact **`origin.import_ref_digest`** naming the accepted CH-SREF / CH-CAPX handoff, but provenance stays digest-only evidence rather than raw bearer metadata or hidden restore/re-fetch semantics (`import-to-docref-bearer-provenance-boundary-v0.md`).

## Posture (v0)

1) **Bearer restore/import and CH-DOCREF minting are distinct steps**
   - Raw **CH-SREF** / **CH-CAPX** bytes never directly satisfy a **CH-DOCREF** request and never count as `subject.kind = docref` on D-PLUMB surfaces.
   - If a workflow starts from bearer restore/import material and wants routine document/open flows, it MUST first perform an explicit restore/import step and then an explicit **materialize/import-to-document-store** step.
   - Phase 1 therefore declines any synthetic “docref view of this sturdyref/token” shortcut.

2) **Materialization mints a fresh local object plus a provider-local `docref`, not a live bearer-backed wrapper**
   - The resulting **CH-DOCREF** names a local document-store/import-provider object, not the raw CH-SREF / CH-CAPX bytes and not a hidden remote mutable object.
   - The materialized local object may additionally record one exact **`origin.import_ref_digest`** for the accepted import handoff, but routine object metadata never stores raw bearer material or capability URLs (`import-to-docref-bearer-provenance-boundary-v0.md`).
   - Even if the imported bytes already exist locally, the bridge still mints a **fresh object identity** for the import event rather than reusing an existing document-store entry/docref (`import-to-docref-fresh-identity-boundary-v0.md`).
   - Reopen authenticates the caller and re-applies the normal **CH-DOCREF** policy/binding checks against that local provider-owned object.
   - The portable seam therefore does **not** promise that reopening a docref replays bearer-token resolution, remote fetch, or mutable remote-object identity.

3) **Imported document-like content is classified as outside-world input and quarantined by default**
   - When CH-SREF / CH-CAPX restore/import materializes document-like bytes for `portal.file.*` / safe-open use, the resulting local object records outside-world origin (`origin.source = network | ipc | unknown`, per policy) and is **quarantined by default**.
   - Restore/import success does **not** imply trust, quarantine clear, or “already reviewed because the token was explicit.”
   - `intent.kind=open_untrusted` therefore composes with the resulting **CH-DOCREF** exactly as it does for any other quarantined document handle.

4) **No silent refetch, refresh, or write-back on docref reopen**
   - Reopening an imported **CH-DOCREF** MUST NOT silently re-consult the bearer token, re-fetch fresh remote bytes, or turn local “save” into remote overwrite/write-back semantics.
   - If a caller wants fresh remote state, sync, publish, or mutation against the imported authority, that remains a **separate explicit D-CAPX / gateway action** or a fresh explicit restore/import event.
   - A local docref reopen is therefore a local reopen, not an ambient sync loop.

5) **Ordering and conflict keys stay on existing seams**
   - Import/materialize-to-docref adds **no new conflict-key family**.
   - Independent imports commute **with respect to requester authority** except where the existing destination-creation or explicit later publish/replace seam already serializes.
   - Non-commutative behavior lives where it already lives: explicit destination mutation, explicit remote gateway actions, or explicit later publish/replace workflows.

6) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat runtimes may participate only through explicit, policy-killable import/materialization adapters.
   - Compat must not reinterpret “open this token/capability URL” as a normal trusted local open or mint a hidden bearer-backed docref shim.
   - If an interop path cannot preserve **fresh local object + quarantine-first + no hidden refetch/write-back**, it fails closed for document workflows.

## Phase 1 non-goals (explicitly deferred)

- **No synthetic CH-DOCREF that embeds or reuses raw CH-SREF / CH-CAPX bearer material**.
- **No transparent live sync / background refresh / remote-write-through semantics** on docref reopen.
- **No automatic quarantine clear** just because content arrived via an explicit restore/import path.
- **No portable claim that local save over a reopened imported docref updates the remote bearer-target object**.
- **No new token→file inventory/search/watch API** that widens D-CAPX or CH-DOCREF.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-CAPX, D-PLUMB, D-QUAR)
- Related posture / schema surfaces:
  - `capx-posture-v0.md`
  - `sturdyref-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `open-untrusted-posture-v0.md`
  - `quarantine-posture-v0.md`
  - `document-handle-schema-v0.md`
  - `capability-export-schema-v0.md`
  - `origin-quarantine-attrset.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-CAPX-1, I-SREF-3, I-DOCREF-1, I-QUAR-1, I-QUAR-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-CAPX-BIND, PO-SREF-EXPLICIT, PO-DOCREF-REOPEN, PO-QUAR-PROP, PO-QUAR-GATE)
- RFC / engineering history:
  - `rfcs/0004-networked-capabilities-and-delegation-tokens.md`
  - `rfcs/0014-sturdyrefs-and-capability-uris.md`
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`
  - `import-to-docref-bearer-provenance-boundary-v0.md`

CI drift gate:
- `tools/check_import_to_docref_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **explicit materialize / fresh local object / quarantine-first / no hidden refetch-or-writeback** constraints, or drops its primary REF wiring.

## References

- REF-TAHOE-LAFS.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-XDG-PORTAL-FILECHOOSER.
