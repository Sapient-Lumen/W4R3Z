# D-NAMECERT metadata boundary v0 (bundle metadata is signed provenance only; no replacement or freshness semantics)

Purpose: narrow the **bundle-metadata** seam of **D-NAMECERT** so admitted **CH-NAMECERT** bundles do not
quietly widen into a hidden version-selection, freshness, or replacement protocol.

This boundary attaches to already-reviewed seams instead of inventing a new one. `namecert-selection-boundary-v0.md`
already keeps multi-candidate evaluation **set-valued**, `namecert-time-boundary-v0.md` already pins validity/
freshness as **admission-only**, `namecert-revocation-boundary-v0.md` already keeps later negative evidence
**evaluator-local**, and `namecert-projection-boundary-v0.md` already keeps authority-bearing materialization on
explicit D-NS actions. The practical Phase 1 question closed here is: **may `bundle_id` or `created_ms` become
hidden authority inputs for winner selection, obsolescence, or replacement?**

Phase 1 makes a small, hard choice: **no**. `bundle_id` and `created_ms` are signed provenance fields only.
They may aid audit, correlation, and human review, but they do **not** create implicit authority semantics.

## Boundary (v0)

1) **`bundle_id` and `created_ms` are signed provenance fields only**
   - `bundle_id` is an issuer-chosen provenance label carried inside the signed bundle.
   - `created_ms` is an issuer-supplied creation timestamp carried inside the signed bundle.
   - In Phase 1 both fields are **observational metadata only**: they help correlate artifacts, logs, and review surfaces, but they do **not** define delegation meaning, principal identity, or target authority.

2) **No hidden replacement, freshness, or winner semantics from bundle metadata**
   - D-NAMECERT standardizes no rule such as “latest `created_ms` wins”, “highest `bundle_id` wins”, “newer bundle replaces older bundle”, “older `created_ms` is stale”, or “matching `bundle_id` means same logical certificate lineage”.
   - Candidate selection remains governed by `namecert-selection-boundary-v0.md`: when multiple admissible candidates exist, evaluation stays **set-valued** rather than metadata-ranked.
   - Freshness remains governed by `namecert-time-boundary-v0.md`: admission-time validity checks use explicit local time policy, not the bare existence of a larger `created_ms` value.

3) **Replication and later arrivals do not turn metadata into lifecycle control**
   - Replicating a bundle with a different `bundle_id` or a later `created_ms` may widen the explicit bundle set visible to a receiver, but it does **not** mark earlier bundles as superseded, revoked, detached, or inactive.
   - Later arrivals still require explicit evaluator-local trust/time/revocation inputs and explicit target-seam actions for any authority-bearing change.
   - This keeps Hybrid honest: replicated `object_family = namecert` remains signed bundle evidence only, not a metadata-driven resolution protocol.

4) **Projection and receipts bind the exact source digest, not metadata guesses**
   - Any authority-bearing Phase 1 materialization still lands only through explicit D-NS `view.attach` / `view.detach` on concrete `view.slot` keys.
   - Target-seam proposal/receipt surfaces MUST bind the exact **`digest(CH-NAMECERT v0)`** that justified the action.
   - `bundle_id` and `created_ms` MAY appear as extra audit metadata in human-facing traces, but they do **not** substitute for the bundle digest and cannot justify attach/detach or candidate choice by themselves.

5) **If we ever want repository/update-style metadata semantics, they pay their own seam cost**
   - Update frameworks such as **TUF** define explicit version/timestamp/expiry roles because freshness and rollback resistance are their own protocol surface.
   - D-NAMECERT v0 deliberately does **not** smuggle that larger lifecycle machinery in through `bundle_id` or `created_ms`.
   - Any future “replacement lineage”, “bundle supersedes bundle”, or “monotonic version” semantics must land as a separate reviewed seam/RFC, not as implicit meaning attached to existing metadata fields.

6) **This keeps all four product shapes honest**
   - **Secure workstation (A):** avoids “helpful latest-bundle” rebinding after sync or restore.
   - **Cloud micro-VM substrate (B):** prevents clustered arrivals from turning metadata recency into hidden winner selection.
   - **Embedded / separation-kernel-ish appliance (C):** avoids importing a version/freshness protocol into a tiny evaluator.
   - **Agent/automation OS (D):** gives LLM/tooling a crisp contract: emit bundle metadata for audit, never rely on those fields to carry replacement intent.

## Phase 1 non-goals (explicitly deferred)

- Serial-number or version-counter semantics on CH-NAMECERT itself.
- “Latest bundle wins” or “newer timestamp replaces older bundle” rules.
- Implicit replacement lineage keyed by `bundle_id`.
- Ambient garbage-collection / supersession of earlier bundles when later metadata arrives.
- Turning `created_ms` into a lease, expiry, or freshness policy without an explicit reviewed seam.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema: `namecert-schema-v0.md`
- Adjacent boundaries:
  - `namecert-selection-boundary-v0.md`
  - `namecert-time-boundary-v0.md`
  - `namecert-revocation-boundary-v0.md`
  - `namecert-replication-boundary-v0.md`
  - `namecert-projection-boundary-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**, **I-NAME-2**, **I-NAME-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**, **PO-NAMECERT-CHAIN**, **PO-NAMECERT-PROJECT**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-030**)

CI drift gate:
- `tools/check_namecert_metadata_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **bundle metadata is provenance-only / no latest-wins-or-replacement semantics / digest-not-metadata projection** stance, or drops its assurance / REF wiring.

## References

- REF-SPKI-RFC2693.
- REF-TUF-SPEC.
- REF-TUF-METADATA.
