# D-CONSTR posture v0 (user-space factories; explicit export contracts; no constructor control plane)

Purpose: pin an **implementable Phase 1** meaning for **D-CONSTR** so “build a confined subsystem” stays a
small **user-space factory + evidence** pattern instead of drifting into a kernel constructor framework, a
global constructor catalog, or a second workflow/admin plane.

This posture narrows RFC-0042 into one compact baseline the four SlopOS product shapes can actually share:
constructors are ordinary components, template selection is pinned by digest, parameter objects stay
**data-not-authority**, exported surfaces are declared, and confinement evidence comes from cap-graph diffs
plus transcript wiring rather than from ambient trust in a factory label.

## Posture (v0)

1) **Constructors are ordinary user-space components, never a privileged kernel framework**
   - If **D-CONSTR** is enabled, a constructor is an ordinary user-space component/service that instantiates a subsystem from pinned inputs and returns an explicit exported surface.
   - Phase 1 does **not** add a kernel-resident constructor subsystem, constructor-specific object type in the privileged core, or ambient “factory mode” escape hatch.
   - Any authority a constructor uses must already be held explicitly by that constructor or passed explicitly by the caller; construction never justifies a new privileged shortcut (**I-CONSTR-1**, **I-CAP-1**).

2) **Construction is digest-pinned and parameterized by data, not ambient lookup**
   - A constructor invocation is defined by pinned template/artifact digests (for example CH-COMP / CH-INIT fragments or equivalent compiled templates) plus a bounded **schema-pinned parameter object**.
   - Parameters are configuration data only: names, sizes, counts, policy knobs, placement hints, freshness selectors, and similar values that do **not** themselves resolve ambient capabilities, paths, environment variables, or default services.
   - Phase 1 therefore declines stringly “look this up by host name/path/env label” constructor semantics; any authority-bearing handle must arrive explicitly rather than being re-fetched ambiently.

3) **Outputs are an explicit export contract, not “whatever the constructor happened to leave reachable”**
   - Each constructor must declare its intended **exported surface**: the handles/capabilities returned to the caller and the bounded structure of that surface.
   - D-CONSTR v0 is compatible with **D-SEAL**: constructors should finish wiring, then seal the constructed subsystem into a steady-state posture where init-only authority is dropped.
   - Constructors may internally assemble richer graphs, but the caller-visible authority gain is only the declared export contract; anything else is a leak and fails the posture (**I-CONSTR-1**, **PO-CONSTR-CONFINE**).

4) **Evidence is cap-graph diff + transcript replay material, not a constructor brand**
   - The standard evidence hook for D-CONSTR is a confinement test built from cap-graph export/delta analysis (via **D-CAPAUD**) plus transcript logging of the constructor instantiation.
   - Constructor logs/receipts must bind at least the constructor/template digest set and a digest of the parameter object so replay/testing can reproduce the instantiation boundary (**I-CONSTR-2**, **PO-CONSTR-REPLAY**).
   - Phase 1 does **not** claim that a constructor is safe merely because it is named “factory” or appears in a catalog; safety is evidenced by the declared export contract and the confinement harness.

5) **No generic constructor catalog, inventory, or workflow/admin plane in v0**
   - Phase 1 does **not** standardize a global constructor registry, constructor search/list/watch API, generic constructor portal family, or generic constructor ACP kind.
   - D-CONSTR therefore introduces **no new closed vocabulary** for constructor families, no new policy lane, and no new generic receipt type of its own.
   - Individual subsystems may expose owner-specific instantiation actions, but those remain subordinate to the subsystem that owns them rather than becoming a cross-cutting constructor control plane.

6) **Commutativity stays honest: no generic constructor conflict key in v0**
   - D-CONSTR v0 introduces **no generic conflict-key family** because it does not introduce one generic external control surface.
   - A constructor instantiation **commutes** when it allocates a fresh isolated subgraph, consumes only explicit request-local inputs/budgets, and returns results solely through fresh export handles/slots that were not previously occupied.
   - It does **not** commute when it mutates or replaces an existing owner-visible slot/name/view/export table/budget root. In those cases serialization lives on the **target seam’s existing conflict keys and ordering witnesses**, and the constructor evidence must show which owner-specific surface serialized the mutation.

7) **Accounting, teardown, and lifecycle stay on existing seams**
   - Resource costs for constructed subsystems remain attributable through existing **D-METER** / **D-KOBJQ** / budget seams; D-CONSTR is a consumer of those seams, not a replacement for them.
   - Teardown/restart/continuity remain on existing supervision, activation, revocation, and checkpoint seams (**D-SUPV**, **D-ACTIVATE**, **D-MEMBRANE**, **D-CHKPT** when enabled).
   - Phase 1 declines any separate constructor-owned lifetime manager, garbage-collection oracle, or persistent constructor catalog that outlives the created subsystem.

8) **Sealed compat remains explicit and killable**
   - Constructors may stamp out compat/interop subsystems, but doing so does **not** authorize ambient path/env/network channels or invisible host integration.
   - Any compat constructor must still satisfy the active membrane and no-ambient invariants; policy must be able to kill the underlying compat path or the owner-specific instantiation action.
   - D-CONSTR does not create a second compatibility backdoor beyond the explicit seams already accepted elsewhere in the archive.

## Phase 1 non-goals (explicitly deferred)

- No kernel-resident constructor framework or privileged-core constructor object type.
- No global constructor registry/catalog/search/watch/inventory surface.
- No generic constructor portal family, generic constructor ACP kind, or constructor admin plane.
- No ambient lookup semantics in parameter objects (`PATH`, env vars, host names, global service names, or implicit network fetch).
- No generic constructor conflict-key family; any future generic external constructor plane must return RFC-first and pay for its own ordering/receipt vocabulary.

## Wiring

- Decision surface: `decision-map.md` (**D-CONSTR**).
- Narrative/mechanism surfaces:
  - `mechanisms.md`.
  - `rfcs/0042-constructors-and-confinement-tests.md`.
  - `docs/00-meta/roadmap.md`.
  - `docs/00-meta/glossary.md`.
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-CONSTR-1**, **I-CONSTR-2**).
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**).
  - `rfcs/0035-capability-graph-export-and-leak-tests.md` (**D-CAPAUD** evidence hook).
- Adjacent seams that remain authoritative:
  - `component-manifest-schema-v0.md` / **D-COMP** (template wiring).
  - `capmode-posture-v0.md` / **D-CAPMODE** (no ambient reacquire after entry).
  - `seal-posture-v0.md` / **D-SEAL** (drop init-only authority).
  - `docs/70-llm-control/acp-action-kind-registry.md` (no generic constructor ACP kind in v0).
- Discovery / amnesia-resistor surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/resolved-history.md`.
- CI drift gate: `tools/check_constructor_posture.py` (**EVID-2026-356**).

## References

- REF-KEYKOS-NANOKERNEL
- REF-KEYKOS-ARCH85
- REF-KEYKOS-OSR92
- REF-EROS-CONFINEMENT
- REF-CAPMYTHS
- REF-SHILL-OSDI14
