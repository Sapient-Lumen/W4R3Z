# D-TRANS posture v0 (view-local translators; explicit attach; no global pathspace)

Purpose: pin an **implementable Phase 1** meaning for **D-TRANS** so user-space translators and
service-tree adapters remain an explicit **view-local composition seam** instead of drifting into a
global pathname registry, an ambient service-discovery surface, or a hidden second namespace model.

This posture deliberately narrows the seam: translators are ordinary user-space components reached
through explicit **view slots**, and any externally visible install/remove action stays on the
existing **D-NS** mutation surface rather than inventing a separate translator admin plane.

## Posture (v0)

1) **Translators are ordinary user-space components bound through explicit view slots**
   - A translator is a user-space component/service object that exports filesystem-like or tree-like behavior for a bound node or subtree.
   - Phase 1 does **not** treat translators as a privileged kernel feature, host-global mount table entry, or ambient service-publication mechanism.
   - Any authority a translator exercises comes only from the capabilities explicitly given to it and from the specific **view slot** where it is attached.

2) **Attachment is view-local and single-slot in Phase 1**
   - Translator install/remove/replace is just **D-NS** mutation of a concrete `view.slot`; it does not create a second namespace mutation model.
   - Phase 1 inherits the v0 D-NS rule that each `view.slot` carries **at most one** binding at a time.
   - Translator stacks, ordered translator chains, and “try next translator” fallback semantics are **out of scope** until a future RFC/ADR pays for that entropy explicitly.

3) **Externally visible translator actions reuse existing conflict keys and ordering witnesses**
   - Any externally visible translator attach/detach/replace action uses the existing ACP kinds **`view.attach`** / **`view.detach`**.
   - Conflict key family: **`view.slot`**, derived from `{view_id, slot_id}` exactly as in D-NS.
   - Such actions **commute (keyed)** across disjoint `view.slot` keys and are **ordered** within the same slot, with serialization living at **`svc:view`** and evidenced by **CH-ORDERTOK v0**, **CH-ACPOUT v0**, and **CH-SPROJ v0**.

4) **No ambient pathspace, resolver, or service-tree discovery surface**
   - Phase 1 does **not** expose a host-global pathname registration API, process-external mount table, translator inventory, or “find all services of this type” oracle.
   - Any service-tree UX remains a user-space convention layered on explicit capabilities and views; remote/tree bridges (including 9P-like transports) remain ordinary user-space adapters, not privileged routing magic.
   - Translators must not regain ambient `open(path)`, default-service lookup, or implicit network fetch as a side door around D-NS / D-CAPMODE.

5) **Attach/remove is explicit, transcript-visible, and sealable**
   - Translator install/remove must remain an explicit, reviewable action on the target view, not a package-install side effect, boot-time ambient script, or hidden “auto-mount when touched” behavior.
   - Long-lived components are expected to drop translator-mutation authority after init using **D-SEAL** / **D-CAPMODE** just as they do for other namespace mutation powers.
   - Translator continuity/restart policy lives on existing supervision/activation seams (**D-SUPV**, **D-ACTIVATE**) rather than on D-TRANS itself.

6) **Sealed compat stays honest**
   - Foreign/compat runtimes may export filesystem-like services through explicit translators mounted into views, but they gain **no ambient host path/env/network channel** by virtue of doing so.
   - Policy must be able to kill such interop by denying the underlying view mutation or by disabling the compat pathway; D-TRANS does not create an unkillable compatibility backdoor.
   - Imported translator-facing services must still satisfy **I-VIEW-2** / **PO-VIEW-NOAMP** and, when a compat runtime is involved, **I-COMPAT-1** / **PO-COMPAT-NOAMBIENT**.

## Phase 1 non-goals (explicitly deferred)

- No translator stack/chain semantics within one `view.slot`.
- No host-global pathspace registration or mount-table discovery API.
- No app-visible translator inventory / watch / search / auto-attach surface.
- No privileged remote service-tree transport or hidden broker; any 9P/Styx-like bridge stays user space only.
- No separate `translator.*` ACP family or translator-specific admin/query plane; Phase 1 reuses `view.attach` / `view.detach`.

## Wiring

- Decision surfaces:
  - `decision-map.md` → **D-TRANS**.
  - `view-namespace-posture-v0.md` → **D-NS** single-slot namespace mutation baseline.
- Core semantics / narrative:
  - `view-objects.md`.
  - `mechanisms.md`.
- ACP / commutativity / ordering surfaces:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`view.attach`, `view.detach`).
  - `conflict-key-family-registry.md` (`view.slot`).
  - `serialization-boundary-registry.md` (`svc:view`).
  - `state-projection-schema-v0.md` (**CH-SPROJ v0**).
  - `ordering-token-schema-v0.md` (**CH-ORDERTOK v0**).
- Related RFCs / compat guidance:
  - `rfcs/0032-view-namespace-semantics-v1.md`.
  - `rfcs/0036-rump-kernel-compatibility-domains.md`.
  - `rfcs/0083-driver-hosts-and-compatibility-runtimes.md`.
- Assurance hooks:
  - Invariants: **I-VIEW-1**, **I-VIEW-2**, **I-COMPAT-1**.
  - Proof obligations: **PO-VIEW-RESOLVE**, **PO-VIEW-NOAMP**, **PO-COMPAT-NOAMBIENT**.
- Discovery / amnesia-resistor surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/resolved-history.md`.
- CI drift gate: `tools/check_translator_posture.py` (**EVID-2026-352**).

## References

- REF-HURD-TRANSLATORS
- REF-HURD-SETTRANS
- REF-QNX-RESMGR
- REF-QNX-RESMGR-ATTACH
- REF-PLAN9
- REF-STYX-ARCH
