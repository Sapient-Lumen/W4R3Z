# CH-FADAPT v0: Foreign-cell adapter receipt (schema)

Purpose: provide a bounded, **non-authoritative** receipt record for *each* adapter-mediated host effect performed on behalf of a Foreign Cell.

This is the “portal/intent/receipt” seam for sealed compatibility:
- the **cell** requests a legacy ABI operation,
- an **adapter** translates it into a portalized host workflow,
- the host returns **handles/leases** (never ambient strings), and
- the adapter emits a receipt describing *what portal family was used* and *what handle(s) were issued*.

CH-FADAPT exists to make D-FCELL evidence and auditability mechanical:
- reviewers can confirm that compat interop is **portalized** (not ambient),
- negative tests can assert “no adapter receipt → no host effect,”
- and Hybrid profiles can keep cross-cluster compat supervisors consistent without relying on implicit ordering.

**Important:** CH-FADAPT is **non-authoritative**.
It MUST NOT carry bearer secrets, raw capability tokens, or ambient authority surrogates (paths, env, implicit network names).

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-FADAPT v0 := {
  v: 0,

  ; identity / binding
  cell_id: bstr,                 ; must match the launched CH-FCELL.cell_id (digest-sized; D-TYPEDID)
  manifest_digest?: bstr,         ; optional digest(CH-FCELL) to bind the instance to its manifest
  policy_digest?: bstr,           ; optional digest(CH-POLICY v0) or digest(CH-POLICYHANDLE v0) used at decision time

  ; what happened (bounded, deny-only audit)
  abi_op_id: tstr,                ; closed-set op id (from the runtime's ABI surface)
  adapter_kind: tstr,             ; closed allowlist (see fcell-adapter-kind-registry.md)
  portal_token: tstr,             ; CH-PLEDGE `portal.*` token used by the adapter

  ; request/result correlation (never authoritative)
  request_schema?: tstr,          ; e.g. "CH-PLUMBMSG" | "CH-JOBREQ" (if a bounded request artifact exists)
  request_digest?: bstr,          ; digest(request_schema vN) when request_schema is present

  ; outcome
  result: {
    code: tstr,                   ; "ALLOW" | "DENY" | "ERROR" (closed set)
    reason?: tstr                 ; deny_code token (see deny-code-registry.md); no raw host paths
  },

  ; handles/leases issued to the cell (identifiers only)
  issued: [
    {
      kind: tstr,                 ; e.g. "docref" | "netlease" | "clock" | "entropy" | "iolease" | "xfer" | "capture" | "uiaut" | "bglease" | "budget"
      digest: bstr                ; digest(CH-*) of the issued bounded descriptor (or digest(handle descriptor)
    }
  ]

  ; optional commutativity observability hooks
  conflict_key_digest?: bstr,     ; digest(CH-CONFLICTKEY v0) for cell-scoped ordering/sharding
  order_digest?: bstr             ; digest(CH-ORDERTOK v0) if adapter ops are serialized within a stream
}

Notes:
- `issued[*].digest` refers to digests of **descriptor artifacts** (CH-DOCREF, CH-NETLEASE, CH-IOLEASE, etc.), not to bearer capabilities.
- `result.reason` (when present) is a **deny_code** token from `deny-code-registry.md` (e.g., `lane-disabled`, `policy-deny`, `internal-error`).
- Hybrid note: if CH-FADAPT artifacts are replicated under `object_family = receipt`, they remain immutable evidence only; replicated receipts cannot resurrect issued handles/leases, skip local adapter policy, or become a remote host-effect admission cache (`receipt-replication-boundary-v0.md`).

## Validation rules (minimum)
Validators MUST be total and fail closed (PO-FADAPT-VALIDATE):

1) `v == 0` and required fields present.
2) `portal_token` MUST be a valid CH-PLEDGE `portal.*` token.
3) `abi_op_id` MUST be a member of the runtime’s closed ABI surface for the launched cell (I-COMPAT-2).
4) `adapter_kind` MUST be in the manifest’s `interop.adapters.enabled` allowlist (deny wins), MUST be a member of the canonical closed set in `fcell-adapter-kind-registry.md`, and must be profile-gated.
5) `issued[*].kind` is a closed allowlist and `issued[*].digest` has bounded length.
6) `result.code` is in the closed enum. If `result.code == "ALLOW"`, `result.reason` MUST be absent. If `result.code` is `"DENY"` or `"ERROR"`, `result.reason` MUST be present and MUST be a `deny_code` from `deny-code-registry.md`.
7) **Non-authoritative rule:** the record contains no bearer secrets and no ambient authority surrogates.

## Usage / obligations

- **I-COMPAT-1 / PO-COMPAT-NOAMBIENT:** any host effect on behalf of a foreign cell MUST be paired with a CH-FADAPT receipt (or it is treated as a policy violation).
- **D-FCELL lane killability:** when `cfg.params.lane.fcell=false`, adapters MUST NOT emit `ALLOW` receipts; they must deterministically emit `DENY` receipts with `reason=lane-disabled`.
- **Hybrid note:** `conflict_key_digest` SHOULD be `family="cell.adapter" payload={cell_id, portal_token}` for sharding; ordered streams (if any) must be scoped to that key (I-ORDERTOK-2). See `fcell-commutativity-contract-v0.md` for the pinned posture.

## Evidence hooks (seed)

- Negative tests: attempt an ambient file/network/time acquisition from inside a foreign cell yields no CH-FADAPT `ALLOW` receipts and fails deterministically (AC-071).
- Adapter mapping tests: for each enabled `adapter_kind`, a representative ABI op produces a CH-FADAPT receipt whose `portal_token` matches the intended portal family.
