# CH-CAPX v0: Capability export envelope (schema)

Purpose: represent *delegated authority* crossing a trust boundary (process/VM/machine) as a canonical, signed/hashable payload.

Phase 1 posture is pinned in `capx-posture-v0.md`: CH-CAPX stays a **gateway-owned, proxy-first import seam**. Accepted tokens bind only to local `proxy`/`service` objects, routine workflow/observation surfaces carry digests rather than raw CH-CAPX bytes, and the core seam does not standardize a portable caveat/policy VM.

Non-goal: standardize macaroon/biscuit/CaPTP internals. This schema is an envelope that binds an opaque token to **our** gateway/import graph.

References: REF-CBOR-RFC8949, REF-COSE-RFC9052, REF-MACAROONS-NDSS14, REF-BISCUIT-SPEC, REF-CAPTP.

## Encoding
Candidate baseline: canonical CBOR (D-ENC) with optional COSE wrapper for signatures.
- The canonical bytes of this payload are what get hashed/signed.
- Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)
This is a *schema sketch*; use it to drive parser/validator implementation and bounded model checks.

CH-CAPX v0 := {
  v: 0,
  token_kind: tstr,            ; e.g., "captp-ref" | "macaroon" | "biscuit" | "sturdyref" | "opaque"
  token: bstr,                 ; opaque token bytes (format determined by token_kind)

  bind: {
    local_kind: tstr,          ; "proxy" | "service"
    local_id: bstr,            ; stable identifier for the local proxy/service import object
    rights_hint?: tstr,        ; optional human/debug hint; NOT authoritative
  },

  caveats?: [ tstr ],          ; optional, human/audit display only unless the validator models them
  issuer?: bstr,               ; optional issuer key ID / authority (if signed)
  exp?: uint,                  ; optional expiry (seconds since epoch, or a declared monotonic domain)
  nonce?: bstr,                ; optional replay/uniqueness tag

  meta?: { * tstr => any }     ; optional; MUST be ignored by validators unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) v == 0 and all required fields present.
2) local_id binding: `bind.local_id` must refer to an existing local proxy/service import object and the object type must match `bind.local_kind`.
3) Expiry enforcement (if used): if `exp` is present and the profile claims expiry (C-TIME-1), enforce with a monotonic source (I-TIME-1).
4) Unknown `token_kind` MUST reject (closed set) unless the deployment profile explicitly enables an "opaque" passthrough.
5) `meta` keys are ignored unless explicitly listed in an allowlist for the profile.

## Security notes
- Treat CH-CAPX as a *capability-bearing object*; do not log raw tokens unless a redaction policy allows it (C-OBS-1).
- If bearer tokens are enabled, attenuation must be monotonic (I-CAPX-2; PO-CAPX-ATTEN) and caveats must be non-removable.
- If CapTP-style references are enabled, remote use must go through a local proxy/service object that is itself capability-mediated (I-CAPX-1).
- If `token_kind == "sturdyref"`, `token` SHOULD be the canonical bytes of CH-SREF v0 (`sturdyref-schema-v0.md`) and follows the pinned `sturdyref-posture-v0.md` rule that sturdyrefs are explicit restore-only bearer material rather than an ambient inventory/auto-restore surface.
- Under Hybrid, replicated `object_family = caprpc_proxy` metadata may help a component locate an owner cluster, but it is never sufficient to instantiate `bind.local_id` or create a callable proxy/handle; import/restore remains explicit at this CH-CAPX / CH-SREF seam (`caprpc-proxy-replication-boundary-v0.md`).
