# Namecert replication boundary (v0)

Purpose: narrow **OQ-0001** for `object_family = namecert` without inventing a global naming substrate.

`CH-NAMECERT v0` already gives SlopOS a small user-space seam for **local names + delegation bundles** (D-NAMECERT). Hybrid needs one additional hard decision so replicated naming material does not quietly turn into ambient resolution authority:

- replicated `namecert` state is a **set of signed CH-NAMECERT bundle artifacts**, and
- **authority-bearing name resolution remains local, explicit, and policy-scoped**.

This keeps RC3 commutative replication honest while preserving the D-NAMECERT stance that names are local to principals and evaluated in user space, not inside the privileged core.

## Decision (v0)

For `object_family = namecert` under CH-REPLCONTRACT v0:

1. The replicated value is a **content-addressed set of immutable CH-NAMECERT bundle digests** scoped by `name_domain`.
2. Merge is **set union by digest** (duplicates collapse by canonical digest).
3. Replication MAY move signed bundles between clusters, but it MUST NOT by itself:
   - auto-install a bundle into the active resolver/view,
   - auto-prefer one binding/delegation because it arrived “later” or from “more peers”,
   - create a global namespace,
   - move raw CH-SREF / CH-CAPX / other bearer restore/import material across clusters under the cover of naming evidence, or
   - resolve names on behalf of privileged code.
4. A local naming service MAY evaluate replicated bundles only through **explicit local policy** that chooses trust roots, visibility, freshness rules, and any view materialization.
5. Any privileged action that depends on a resolved name must still be traceable to an explicit view and/or pinned CH-NAMECERT bundle set (I-NAME-1); replication alone is never sufficient authority.

## Why RC3 fits here

`namecert` is RC3-safe in v0 because the replicated object is the **bundle set**, not the evaluated name graph.
Signed CH-NAMECERT artifacts are immutable evidence objects; adding one more bundle to the observed set commutes with adding another. `namecert-bearer-boundary-v0.md` closes the adjacent secret-transport question that would otherwise break this posture: admitted bundles are non-bearer evidence only, so replication of `object_family = namecert` cannot quietly become replication of portable restore/import material.

What does **not** commute is “which bundle wins for a given local name?” That question is intentionally pushed out of replication and kept in the local naming policy/evaluator. SlopOS therefore declines any v0 rule like “latest bundle wins”, “highest signature count wins”, or “cluster-majority resolution wins”. `namecert-selection-boundary-v0.md` further freezes Phase 1 evaluation as **set-valued** when multiple admissible candidates exist, so replication cannot smuggle in an implicit default winner rule. `namecert-search-boundary-v0.md` additionally freezes each admission attempt as **closed-world** over the explicit bundle set it was handed, so replication arrivals do not turn one query into a suspend/resume distributed discovery session. `namecert-trust-root-boundary-v0.md` closes the adjacent trust seam: replication may move bundle evidence, but it does not distribute trust anchors, rewrite issuer allowlists, or auto-install new roots.

## Explicit non-goals (v0)

Phase 1 does **not** standardize:

- cross-cluster auto-subscription or ambient discovery of name bundles,
- automatic trust-root distribution or root-store sync,
- globally coherent name resolution semantics,
- remote clusters deciding which local name binding is active, or
- a privileged-core certificate parser/resolver.

If we later need a replicated **resolved-view snapshot**, **shared trust-policy distribution**, or **globally ordered name update log**, that work must land as a new RFC-first object family or descriptor seam rather than by silently changing `namecert` replication semantics in place.

## Source notes

- SDSI emphasizes **linked local namespaces** rather than a global hierarchy (REF-SDSI-RL96).
- SPKI requirements push certificates toward carrying the **minimum information necessary** for authorization, not identity-PKI sprawl (REF-SPKI-RFC2692).
- SPKI certificate theory keeps meaning in explicit certificates/delegations rather than ambient naming infrastructure (REF-SPKI-RFC2693).

## Consequences for the archive

- `replication-object-family-registry.md` should treat `namecert` as **signed bundle-set replication only**.
- `profile-repl-defaults.md` may keep RC3 defaults for all four product shapes, but the note must say that **local policy resolves trust/visibility/activation**.
- `namecert-schema-v0.md`, `namecert-trust-root-boundary-v0.md`, `namecert-bearer-boundary-v0.md`, and RFC-0023 should point out that replication moves bundle evidence, not active resolver authority, trusted-anchor state, or bearer restore/import secrets.
- Any future stronger semantics (resolved snapshot, shared trust policy, ordered update stream) must pay for a new decision surface.
