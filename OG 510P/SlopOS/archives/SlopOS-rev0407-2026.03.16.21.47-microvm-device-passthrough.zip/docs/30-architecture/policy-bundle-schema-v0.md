# CH-POLICY v0 (policy bundle, informal)

Purpose: pin *operational guardrails* used by user-space validators (e.g., IF-ACP) without turning policy into an authority-granting mechanism.

Key design rule: **policy is veto-only** (D-POLICY). Capabilities/approvals remain the source of authority.

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- references other artifacts by digest to avoid bloating bundles
- records policy engine identity/version for audit

## Shape (v0)
A policy bundle `p` contains:
- `schema`: fixed `CH-POLICY v0`
- `engine`: closed enum identifying evaluator semantics (e.g., `cedar`)
- `engine_rev`: evaluator version string (or digest of the evaluator binary/container)
- `policy_source_digest`: digest of the policy source text (engine-specific)
- `entity_schema_digest`: optional digest of an entity/schema definition (engine-specific)
- `inputs`: closed list of named, pinned input digests allowed to influence decisions (default empty)
  - examples: `cfg_digest` (CH-CFG), `comp_digest` (CH-COMP)
  - non-examples (default forbidden): tool outputs, live observations, network lookups
- `mode`: closed enum
  - `veto_only` (required in v0)

## Evaluation contract (v0)
`policy_allows(p, action, ctx) -> {allow|deny|error}`
- total: must return a result for all inputs; `error` is treated as `deny` (fail-closed)
- deterministic: given the same `p`, canonical `action` bytes, and `ctx` (bounded and pinned), the result is identical (I-POLICY-1)
- non-amplifying: the policy result is not sufficient to authorize an action (I-POLICY-2)

## Verification obligations
- PO-POLICY-DETERMINISM: evaluation is total/deterministic and errors deny
- PO-POLICY-NONAMP: acceptance still requires explicit authorization binding (I-AUTHZ-1)

Profile handle note:
- Some profiles may ship policy as builtin/compiled artifacts rather than as an explicit CH-POLICY bundle.
- In those cases, receipts SHOULD name the effective policy semantics via `digest(CH-POLICYHANDLE v0)`.

Refs: REF-CEDAR, REF-CEDAR-SPEC.
