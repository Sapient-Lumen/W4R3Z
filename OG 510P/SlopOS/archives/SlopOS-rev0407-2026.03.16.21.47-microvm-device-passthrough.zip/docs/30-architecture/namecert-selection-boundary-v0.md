# D-NAMECERT selection boundary v0 (set-valued evaluation; no hidden winner selection)

Purpose: narrow the **selection semantics** of **D-NAMECERT** so multiple valid bindings/delegation
paths do not quietly turn Phase 1 into a hidden resolver-preference engine.

This boundary deliberately stays on already-reviewed seams: **D-NS** carries any authority-bearing materialization, **D-COMMUTE** still defines the conflict keys/ordering, and **D-REPL** remains evidence-only for replicated bundle visibility rather than a winner-selection protocol.

The archive already says that CH-NAMECERT is explicit user-space evidence, that authority-bearing
projection is explicit per-`view.slot`, that time/freshness is admission-only, and that later
revocation evidence is evaluator-local. This doc closes the next ambiguity: **what happens when an
explicit bundle set yields more than one admissible candidate?**

Phase 1 makes a small, hard choice: **evaluation is set-valued**. If multiple candidates survive
validation and local policy, the evaluator exposes that fact as a bounded candidate set. It does **not**
quietly pick a single winner by arrival order, signature count, lexical order, shortest chain, or any
other implicit preference rule.

## Boundary (v0)

1) **Evaluation is set-valued, not single-winner**
   - An explicit CH-NAMECERT bundle set may yield **zero, one, or many** admissible candidates for a queried local name/role path.
   - In Phase 1 the evaluator therefore returns a **bounded candidate set** (or denial), not an ambient “best match”.
   - This matches the local-name posture inherited from SDSI/SPKI: issuer-local names may map through explicit reduction chains, but v0 declines to smuggle global uniqueness or automatic single-winner resolution onto D-NAMECERT.

2) **No hidden preference lattice on D-NAMECERT itself**
   - Phase 1 standardizes **no** default ranking such as “latest bundle wins”, “shortest chain wins”, “highest signature count wins”, “lexicographically first name wins”, “first arrival wins”, or “majority cluster view wins”.
   - If a deployment wants chooser/ranking behavior, that policy must live **outside** D-NAMECERT as an explicit reviewed seam. Phase 1 therefore carries **no hidden winner-selection rule** on the naming seam itself.
   - Routine UX MAY sort or group candidates for display, but those presentation choices are **non-authoritative** until an explicit target-seam action occurs.

3) **Authority-bearing materialization must name the exact chosen candidate**
   - If a candidate from a set becomes live authority in Phase 1, the resulting `view.attach` / `view.detach` proposal MUST identify the exact target it is choosing, not just the queried name.
   - The target-seam proposal/receipt surfaces MUST retain the supporting **`digest(CH-NAMECERT v0)`** provenance for the candidate that justified the action.
   - A receipt that says only “the resolver picked one” is insufficient; the chosen binding/delegation path must stay reconstructible from explicit source digests and ordinary target-seam evidence.

4) **Conflict keys and serialization stay on the target seam**
   - The existence of multiple candidates does **not** introduce a new conflict-key family or ordering stream on D-NAMECERT.
   - Any authority-bearing choice still lands only as explicit D-NS `view.attach` / `view.detach` on concrete `view.slot` keys, using the existing `view.slot` family, `svc:view` serialization boundary, and `CH-ORDERTOK v0` witness rules for same-slot ordering.
   - The selection question is therefore visible only where a concrete live-state mutation is attempted, not as a background resolver state machine.

5) **Replication, freshness, and revocation remain evidence-only inputs to selection**
   - Replicated bundle arrivals may widen the candidate set; time/freshness checks may shrink the admissible set at admission time; later local negative evidence may shrink future admissions.
   - None of those inputs grants permission to silently pick a new winner for already-materialized live state.
   - If local policy wants a different live binding, it still performs an explicit target-seam mutation with fresh provenance.

6) **Explicit candidate-set semantics keep the archive honest for all four product shapes**
   - **Secure workstation (A):** prevents “helpful” resolver heuristics from silently rebinding user-visible names.
   - **Cloud micro-VM substrate (B):** keeps automation from drifting into hidden latest/majority winner rules across clusters.
   - **Embedded / separation-kernel-ish appliance (C):** avoids importing chooser logic or background resolution daemons into small deployments.
   - **Agent/automation OS (D):** gives LLM- and workflow-driven tooling an inspectable candidate set instead of a black-box resolver guess.

## Phase 1 non-goals (explicitly deferred)

- A portable **candidate ranking** or trust-scoring language on D-NAMECERT itself.
- Automatic “best binding” selection by replication arrival order, timestamps, chain length, or peer counts.
- A global uniqueness / alias-resolution protocol for issuer-local names.
- A generic chooser UI/API or global candidate inventory/watch plane.
- An RT-/KeyNote-/Biscuit-style integrated credential graph / policy engine on the D-NAMECERT seam.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- Time boundary: `namecert-time-boundary-v0.md`
- Revocation boundary: `namecert-revocation-boundary-v0.md`
- Replication boundary: `namecert-replication-boundary-v0.md`
- Target namespace seam: `view-namespace-posture-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-2**, **I-NAME-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-CHAIN**, **PO-NAMECERT-PROJECT**)

CI drift gate:
- `tools/check_namecert_selection_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **set-valued / no hidden winner-selection / exact-candidate provenance** stance, or drops its assurance / REF wiring.

## References

- REF-SPKI-RFC2693.
- REF-RT0-DISCOVERY.
- REF-KEYNOTE-RFC2704.
- REF-BISCUIT-SPEC.
- REF-UCAN-SPEC.
