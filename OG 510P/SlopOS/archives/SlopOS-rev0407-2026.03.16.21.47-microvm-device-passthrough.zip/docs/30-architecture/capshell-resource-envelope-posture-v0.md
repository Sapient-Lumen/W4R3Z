# Capshell launch resource-controller envelope posture v0 (no inherited cgroup / Job Object limits baseline)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools whose behavior depends on inherited
resource-controller **envelope state**: cgroup membership, controller enablement, quota/weight
settings, process-count ceilings, memory limits, I/O throttles, or equivalent Job Object resource
limits carried across the runner/wrapper boundary. The archive already says execution context is
explicit and reviewable, but that promise still drifts if the child launch quietly inherits a
parent/login-shell/session/service-manager resource envelope that never appears in the reviewed
execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic
resource-control API, a reviewed descriptor for arbitrary cgroup paths / slices / jobs, or a
portable scheduler/quota planner. It only freezes the minimum Phase 1 posture needed so launch
behavior stops depending on hidden shell/session/wrapper resource-controller state across all four
product shapes.

## Posture (v0)

1) **No inherited shell/session resource-controller envelope baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit a narrowed resource-controller envelope merely because the
     parent shell, wrapper, login profile, service manager, or host session already had it.
   - Ambient launch state includes inherited cgroup membership, inherited controller settings such
     as CPU quota/weight, memory ceilings, I/O throttles, `pids.max` / process-count ceilings,
     service-manager `CPUWeight=` / `CPUQuota=` / `MemoryHigh=` / `MemoryMax=` / `TasksMax=` /
     `IOWeight=` policy, inherited Job Object resource limits, and equivalent wrapper-selected
     resource envelopes that never appear in the reviewed execution pack.

2) **Phase 1 adds no reviewed per-step resource-envelope surface**
   - Phase 1 introduces no reviewed cgroup / slice / Job Object descriptor family, no
     `capshell.resenv.*` ACP/admin family, and no per-step workflow knobs for CPU quota/weight,
     memory ceilings, I/O throttles, process-count limits, or control-group/job placement.
   - The portable seam is therefore: **do not carry launcher/session resource-controller envelope
     state across the reviewed boundary**.
   - If a runtime/provider wants fixed resource ceilings for a deployment class, that remains local
     implementation policy and MUST be independent of parent shell/session/wrapper state.

3) **Launch normalizes to the default resource-controller envelope for the active execution compartment**
   - Before `exec` (or via equivalent spawn attributes), the runner/wrapper MUST start the child in
     the platform's **default resource-controller envelope for the active execution compartment**
     rather than in a parent-inherited nested cgroup / slice / Job Object / wrapper-specific tighter
     envelope.
   - The active execution compartment may already have a provider-defined default envelope (for
     example, a VM/cell/container/service-wide CPU/memory/IO/process-count ceiling). That is fine.
     The Phase 1 promise is that reviewed launch meaning stays on **that one default compartment
     envelope**, not on extra shell/session/wrapper narrowing layered on top.
   - On Linux-like hosts, that means not preserving extra parent-inherited cgroup membership or
     controller narrowing beyond the runtime's default compartment baseline when the runtime can
     spawn or migrate into the correct cgroup before first reviewed execution.
   - On hosted/service-managed runtimes, the portable promise is the same but scoped to the
     runtime's own envelope: the child launches in the default cgroup/job/resource-domain ordinarily
     assigned to that compartment, not in an extra shell/session/wrapper-imposed sub-envelope.
   - Compat/foreign-cell membranes that cannot guarantee that normalized launch posture MUST fail
     closed rather than preserving host defaults.

4) **Programs may still manage their own resource domains after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen shell/interpreter/program after it begins running.
   - If an explicitly selected tool later subdivides its own compartment or adjusts its own
     resource-controller state using already-held local authority, that behavior belongs to the
     chosen program/runtime rather than to ambient launch state.

5) **Other explicit seams do not secretly mint or repair resource-envelope state**
   - **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and **CH-REQCTX v1** do not
     authorize synthesizing or translating parent shell/session cgroup / Job Object state into the
     child.
   - **D-BUDGET**, **D-LEASE**, **D-JOBS**, and **D-BGLEASE** do not authorize
     treating inherited cgroup / slice / Job Object policy as reviewed workflow meaning. Any future
     portable resource-envelope seam must return explicitly rather than piggybacking on budgets,
     jobs, or request context.
   - **CH-HWFACT v0** and placement/cache facts remain observational and MUST NOT silently become
     launch controller selectors.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt UX, or terminal/session UX) MUST NOT become hidden carriers for inherited
     resource-controller envelope state.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable cgroup / Job Object descriptor family, no policy knob for
     varying launch resource envelopes per workflow step, and no admin query surface for “what
     inherited cgroup/job limits were applied?”
   - If later evidence shows real need for reviewed launch-time cgroup/job control, that work must
     return as **one new explicit decision surface** rather than by silently inheriting shell state.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden parent/session
     cgroup / Job Object resource-controller state.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose inherited host/session cgroup paths, service slices, or Job
     Object resource limits as a hidden side channel around the reviewed execution pack.
   - If a foreign runtime cannot bypass login-shell/session/service-manager resource-envelope
     carry-over or cannot normalize the child to the default resource-controller envelope for the
     active execution compartment, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable cgroup / Job Object schema or per-step launch resource-envelope descriptor in Phase 1.
- No portable guarantee about exact controller inventory, quota formulas, or provider-internal slice
  topology.
- No automatic derivation from budget leases, hardware-fact locality, or profile defaults into host
  cgroup / Job Object policy.
- No compatibility table translating legacy cgroup paths, `systemd-run --scope`, service slices, or
  Job Object limits into D-CAPSHELL policy.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-rlimit-posture-v0.md`
  - `capshell-scheduling-posture-v0.md`
  - `capshell-affinity-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-RESENV-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-RESENV-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_resource_envelope_posture.py` (**EVID-2026-350**).

## References

- REF-MAN7-CGROUPS
- REF-CGROUPV2
- REF-MAN7-SYSTEMD-RESOURCE-CONTROL
- REF-MS-JOB-OBJECTS
