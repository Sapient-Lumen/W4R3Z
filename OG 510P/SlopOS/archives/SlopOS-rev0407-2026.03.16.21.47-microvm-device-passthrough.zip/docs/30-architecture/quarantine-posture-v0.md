# D-QUAR posture v0 (monotonic; object-local clear; safe-open does not mutate trust in place)

Purpose: pin an **implementable Phase 1** meaning for D-QUAR so origin/quarantine metadata becomes a small,
reviewable workflow boundary rather than a vague “warning bit” that different tools clear differently.
It narrows the existing RFC into something worth coding: quarantine is **monotonic by default**, clearing is
**manual-only and object-local**, safe-open stays a **disposable/view-first** workflow, and any “this is now safe”
materialization happens by creating a **new artifact** with a fresh digest and transcript record rather than mutating trust in place.

This doc says what Phase 1 quarantine *is* and what it is *not*:
an **explicit provenance + gating posture** bound to object digests and safe-open workflows — **not** an app-private flag,
not a recursive “trust this folder/archive tree” toggle, and not a hidden notarization/AV verdict channel that silently dequarantines content.

## Posture (v0)

1) **Origin/quarantine stay explicit data, not app-private heuristics**
   - If D-QUAR is enabled, origin and quarantine state live in the declared `origin.*` / `quarantine.*` attribute set.
   - Applications and compat runtimes do not get to invent parallel private trust bits that bypass the shared contract.
   - `origin.locator_hint` remains informational only and must not become an authorization input.

2) **Propagation is monotonic and container-aware**
   - Copy, extract, derive, and equivalent container decode flows preserve quarantine by default.
   - Rename, repack, archive nesting, or “open then save elsewhere” must not silently drop quarantine.
   - Container handling is part of the contract, not an implementation detail left to individual apps.

3) **Clearing is manual-only, object-local, and never recursive**
   - Phase 1 quarantine clear remains an IF-CONSENT mediated action with transcript logging.
   - Clearing object `X` does **not** recursively clear siblings, descendants, extracted children, enclosing archives, or future derivations.
   - There is **no ACP automation kind** for quarantine clear / safe-open override in v0.

4) **Safe-open is a view/execute workflow, not a trust mutation**
   - Opening or previewing quarantined document-like content routes through the safe-open workflow (typically `intent.kind=open_untrusted` on one exact `docref` into a disposable domain + explicit export) unless an explicit override is authorized.
   - Companion quarantined-execution boundary: quarantined exact executable/script objects do **not** auto-coerce into `open_untrusted`; ordinary exact execution stays deny-by-default until explicit object-local clear/override, and Phase 1 adds no portable `run_untrusted` lane (`quarantined-execution-boundary-v0.md`).
   - Companion quarantined code-input boundary: a cleared interpreter/runtime still does **not** launder a quarantined bound code object by feeding it through `stdin`, `-c`, `--eval`, module/archive entry, or a similar code-bearing input form (`quarantined-code-input-boundary-v0.md`).
   - Companion safe-open active-content boundary: even document-shaped safe-open viewers stay **inert by default**. Embedded active content (macros, document-level scripts, external submit/fetch actions, helper-launch callbacks, or equivalent viewer hooks) does not execute or cause side effects merely because the object was admitted to `open_untrusted`; any such effect must cross a new explicit workflow on the existing portal seam (`open-untrusted-active-content-boundary-v0.md`).
   - Companion import boundary: if document-like bytes arrive from explicit CH-SREF / CH-CAPX restore/import and are materialized for routine document workflows, that fresh local object is still **quarantined by default**; the “token was explicit” fact does not bypass D-QUAR (`import-to-docref-boundary-v0.md`).
   - Companion fresh-identity boundary: quarantine/origin stay **object-local rather than content-addressed trust**; the import bridge must not collapse equal bytes onto an existing local object/docref via `reuse_existing` or similar cache-hit semantics (`import-to-docref-fresh-identity-boundary-v0.md`).
   - Companion bearer-provenance boundary: imported fresh local objects may keep one exact **`origin.import_ref_digest`** naming the accepted bearer handoff, but that breadcrumb stays digest-only evidence and never becomes raw bearer metadata or hidden refresh authority (`import-to-docref-bearer-provenance-boundary-v0.md`).
   - The preview input is a request-local stable materialization, not a live alias/write-through mount back to the mutable source object (`open-untrusted-materialization-boundary-v0.md`).
   - Companion residue boundary: merely viewing a quarantined document must not populate durable recent-doc / MRU / thumbnail / autosave / crash-recovery surfaces outside the disposable; any such residue stays disposable-local unless a separate explicit export/persistence workflow says otherwise (`open-untrusted-viewer-residue-boundary-v0.md`).
   - Companion content-index boundary: quarantined bytes may still appear in authorized **metadata-safe** discovery surfaces, but they do **not** silently flow into ambient full-text / OCR / embedding / summary indexing, assistant memory, or other content-derived caches outside an explicit derived-output workflow (`quarantined-content-index-boundary-v0.md`).
   - Companion derived-attribute boundary: even explicit derived-output workflows must not write their semantic results back onto the risky source object's queryable metadata; source-object semantic back-write stays disallowed and durable semantics live on a separate derived artifact (`quarantined-derived-attribute-boundary-v0.md`).
   - Companion derived-match boundary: **no source resurfacing by derived matches** — even when those semantics live on a separate derived artifact, query/search/smart-folder surfaces must not make the quarantined source object appear as the hit by hidden lineage joins, representative substitution, or dedup-style result collapse; exact hits stay on the derived artifact unless the relation is followed explicitly (`quarantined-derived-match-boundary-v0.md`).
   - Companion result-preview boundary: even when the exact quarantined or derived artifact is the right hit, result rendering stays **metadata-safe only**: no ambient snippets, thumbnails, preview panes, or hover previews from quarantined bytes; richer preview must be a separate explicit review/open step on the exact handle (`quarantined-result-preview-boundary-v0.md`).
   - Safe-open must not silently rewrite `quarantine.state` on the source object.
   - Preview/open success does not mean “trusted forever”; it means a bounded workflow was allowed to inspect the object.

5) **Safe export creates a new artifact; it does not launder the source in place**
   - Any dequarantined materialization across the trust boundary is a **new artifact** with its own digest, provenance, and transcript-visible justification.
   - ordinary safe-open export remains quarantined by default; only a separate sanitize/clear workflow can produce a differently classified artifact (`open-untrusted-export-classification-v0.md`).
   - ordinary keep/export is also **fresh-destination-first** rather than overwrite-in-place, so risky-open output does not regain trust/identity continuity merely by landing on a familiar name or destination (`open-untrusted-export-destination-boundary-v0.md`).
   - ordinary kept output also records one exact `origin.parent_digest`, so the new artifact stays explicitly tied to its risky source instead of turning provenance into path/filename folklore (`open-untrusted-export-lineage-boundary-v0.md`).
   - The source object remains quarantined unless it is separately and explicitly cleared.
   - “Sanitize then trust” is modeled as *derive a new object*, not *mutate the old object’s trust bit*.

6) **Verification may gate consent, but it does not silently clear**
   - Signature checks, notarization, scanning, or parser validation may inform policy/UI for the clear decision.
   - Those results do **not** auto-clear quarantine in Phase 1.
   - Any future policy-assisted fast path still needs an explicit transcript-visible authorization edge.

7) **Sealed compat and importers remain killable and non-ambient**
   - Foreign Cell import/open flows must respect D-QUAR and route quarantined content through safe-open or explicit clear.
   - Interop must not create a hidden “legacy app saved this without tags” laundering path.
   - If a profile disables D-QUAR, it does so explicitly rather than via compat exceptions.

## Phase 1 non-goals (explicitly deferred)

- **No recursive “trust this archive/folder tree” clear**.
- **No “opened once == permanently trusted” behavior**.
- **No policy-hidden auto-clear after signature, notarization, or AV verdict**.
- **No app-private quarantine bits** that bypass the shared attribute + consent contract.
- **No generic “run in disposable” execution lane** hidden behind quarantine UX.
- **No rename/repack/container loophole** that treats equivalent bytes as newly trusted without a logged workflow.

## Wiring

- Decision surface:
  - `decision-map.md` (D-QUAR, D-EPHEM, D-PLUMB)
- Schema / attribute surfaces:
  - `origin-quarantine-attrset.md`
- Related workflow notes:
  - `open-untrusted-posture-v0.md`
  - `quarantined-execution-boundary-v0.md`
  - `quarantined-code-input-boundary-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `open-untrusted-export-classification-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `open-untrusted-export-lineage-boundary-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
  - `document-portal-posture-v0.md`
  - `transfer-portal-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-1, I-QUAR-2, I-QUAR-3, I-QUAR-6, I-QUAR-4, I-QUAR-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-PROP, PO-QUAR-GATE, PO-QUAR-EXEC, PO-QUAR-CLEAR, PO-QUAR-LOCAL)
  - `docs/10-threat-model/abuse-cases.md` (AC-040)
- RFC history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`

CI drift gate:
- `tools/check_quarantine_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / object-local clear / safe-export-creates-new-artifact / no silent auto-clear** constraints, or drops its primary REF wiring.

## References

- REF-MOTW-ZONEID.
- REF-MACOS-GATEKEEPER.
- REF-GATEKEEPER-BYPASS.
- REF-MS-PREVIEW-MOTW.
