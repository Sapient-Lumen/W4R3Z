# Capshell output normal form (v0: CH-AREF + deterministic replay)

Purpose: make `capshell.exec` (D-CAPSHELL) **practically** at-least-once-safe under D-RETRYSAFE
*without* inventing a new output schema.

This doc pins a minimal “output normal form” so:
- duplicate suppression can return a deterministic “already done” outcome,
- outputs can be compared / diffed / cached by tooling,
- and the system does not drift into ambient, log-only “what happened?” channels.

Adjunct to:
- D-RETRYSAFE (`docs/30-architecture/decision-map.md`)
- D-AREF (`docs/30-architecture/artifact-reference-schema-v0.md`)
- CH-ACPOUT v0 (`docs/30-architecture/acp-outcome-receipt-schema-v0.md`)
- `capshell-result-sidecar-boundary-v0.md`

Research imports (translated to our artifacts, not copied):
- Bazel Remote Execution API (REAPI): action results reference stdout/stderr/output files by digest in a CAS (REF-REAPI-PROTO).
- Nix content-addressed outputs: output identity depends on the output content (not build history) (REF-NIX-CA-OUTPUTS).

## v0 contract (tight)

When `capshell.exec` is used with retry safety **at-least-once-safe** (registry cell),
the runner/owner surface MUST treat the step’s exportable outputs as a closed, digest-addressed set:

1) **All exported outputs are CH-AREF v0**
   - Any output the system wants to treat as stable/replayable MUST be referenced as `digest(CH-AREF v0)`.
   - Outputs MAY point at local storage (workstation), a CAS (cloud substrate), or an appliance-local blob store,
     but the *authoritative identity* is always the digest.

2) **“Already done” is deterministic**
   - Duplicate suppression keyed by CH-EFFCON `contract_id` (D-RETRYSAFE) MUST return:
     - the same output CH-AREF digests as the first accepted execution, and
     - a transcript-visible outcome classification (CH-LOG and/or CH-ACPOUT `effect="duplicate_suppressed"`).

3) **No ambient output channels**
   - The runner MUST NOT treat host paths, implicit working directories, environment variables, or implicit network
     as output “namespaces”. If a produced artifact must be exportable, it must be promoted through an explicit
     portal/descriptor lane and referenced by digest.

4) **Minimal, stable observability hook**
   - On `accept`, producers SHOULD emit CH-ACPOUT v0 with `receipt_refs` entries referencing the produced outputs:
     - `schema="CH-AREF v0"`, `digest=<aref_digest>`.
   - For strict profiles, a runner MAY also bind “expected outputs” via CH-EFFCON `outputs[]` as a veto-only
     completeness check (missing outputs → deterministic deny).
   - If a future profile needs richer result descriptors, those live outside this seam per
     `capshell-result-sidecar-boundary-v0.md`; they do not change what counts as the canonical replay result.

Non-goals (v0):
- pinning a file-tree output schema,
- standardizing resource-usage telemetry fields,
- standardizing streaming output UX.

## Where the bytes live (profile notes, not a fork)

The digest is the stable identity; the locator is an implementation detail that can vary per profile:

- **A (secure workstation):** outputs often land in a user-visible store via portals; any locator that names a host
  path MUST remain policy-killable and must not become ambient authority.
- **B (cloud substrate):** prefer CAS semantics (REAPI-like): outputs are blobs addressed by digest and fetched
  via explicit capability/lease.
- **C (embedded/appliance):** keep the surface small: outputs may be disabled by policy, or exported only via
  tightly bounded diagnostic portals.
- **D (agent/automation):** output normal form is the default: tools diff by digest; retry safety relies on
  deterministic “already done” outcomes.

## Wiring into existing artifacts

- Dedupe key: CH-EFFCON `contract_id` (already pinned by D-RETRYSAFE).
- Output identity: CH-AREF v0 (already pinned by D-AREF).
- Outcome envelope: CH-ACPOUT v0 `receipt_refs` + `effect` (already pinned).

If we later need richer structure (directory trees, named outputs, streaming, or resource telemetry),
follow `capshell-result-sidecar-boundary-v0.md`: introduce **one** explicit sidecar descriptor family via RFC
rather than growing ad-hoc `meta` dictionaries or changing the meaning of CH-AREF digests.
