# D-PLUMB safe-open materialization boundary v0 (snapshot-in; no live alias; explicit export-out)

Purpose: pin the **exact input/output boundary** for `intent.kind=open_untrusted` so safe-open remains a bounded inspection workflow instead of drifting into “document portal reopen, but in a sandbox.”
It narrows one remaining ambiguity in the seam: a request may target one exact `docref`, but **what does the disposable actually receive?**
Phase 1 answers: safe-open resolves the `docref` **once**, then hands the disposable a **request-local stable materialization** (for example, a read-only snapshot, staged exact-byte copy, or equivalent fixed derived object) rather than a live alias back to the mutable source object.

This keeps D-QUAR honest: previewing risky content inspects a bounded input object, and anything that leaves the disposable is a **separate explicit export** rather than hidden write-through to the source.

## Posture (v0)

1) **Resolve once; materialize a request-local stable input**
   - `intent.kind=open_untrusted` begins from one exact **CH-DOCREF** subject.
   - Before user payload runs, the safe-open provider resolves that `docref` to one exact source object identity and materializes a **request-local stable input object** for the disposable.
   - Acceptable Phase 1 implementations include a read-only snapshot, exact-byte staged copy, or an equivalent stable derived object/view.
   - The portable contract is about the boundary, not the mechanism: the disposable must observe a fixed input for the lifetime of that request.

2) **No live alias, no retarget-on-change, no hidden portal reopen loop**
   - The disposable does **not** receive a live alias to the mutable source object, a host path, or a reopen token that can silently fetch “whatever the `docref` points to now.”
   - Source rename/replace/mutation after materialization must not retarget the running safe-open instance.
   - A provider may internally use copy-on-write or snapshot machinery, but Phase 1 must not expose shared mutable backing or save-through semantics to the requester/viewer.

3) **Edits stay local until explicit export**
   - Any save/edit activity inside the safe-open environment lands on disposable-local scratch/output state, not directly on the source object behind the `docref`.
   - “Save” inside the risky-open context therefore means “produce candidate output inside the disposable,” not “overwrite the source object in place.”
   - If the user wants to keep derived output, that crosses explicit `portal.xfer.*` / `portal.file.*` / IF-CONSENT seams and becomes transcript-visible.
   - Companion active-content boundary: the staged/snapshotted viewer input still does **not** authorize document-embedded active content to execute or trigger network/helper side effects; admitted viewers remain inert-by-default and any hyperlink/print/file effect crosses a separate explicit workflow (`open-untrusted-active-content-boundary-v0.md`).
   - Companion residue boundary: mere preview/open must not populate durable recent-doc / MRU / thumbnail / autosave / crash-recovery surfaces outside the disposable; viewer-derived residue stays disposable-local unless explicitly exported (`open-untrusted-viewer-residue-boundary-v0.md`).
   - Companion export-classification boundary: the kept result is a **new artifact** that remains **quarantined by default** unless a separate sanitize/clear workflow says otherwise (`open-untrusted-export-classification-v0.md`).
   - Companion export-destination boundary: ordinary keep/export lands as a **fresh destination artifact** rather than overwriting an existing object in place (`open-untrusted-export-destination-boundary-v0.md`).
   - Companion export-lineage boundary: if output is kept at all, the new artifact records the exact immediate parent digest as `origin.parent_digest` rather than relying on name/path/session folklore (`open-untrusted-export-lineage-boundary-v0.md`).

4) **Source revocation/mutation gates future opens, not in-flight preview identity**
   - Before materialization, normal CH-DOCREF origin-binding, revocation/expiry, stable-target, and quarantine checks apply.
   - After a stable input object has been admitted into the disposable, later source mutation/replacement/revocation does not mutate the in-flight preview into a different object.
   - Future `open_untrusted` requests and any explicit publish/replace-back workflow re-check current policy and source state separately.

5) **Ordering and conflict keys stay on existing seams**
   - For one `open_untrusted` request, snapshot/materialization is intentionally **request-local** and serializes at the owning workflow + safe-open provider (`svc:workflow.router` plus the selected document/snapshot materializer).
   - Independent `open_untrusted` requests commute **with respect to requester authority** because safe-open materialization mints no durable authority over the source object and does not mutate it in place.
   - Any later publish/replace action is the non-commutative part: it serializes on the existing destination/source object-local mutation seam under `portal.file.*` / IF-CONSENT policy and is evidenced there. Phase 1 adds **no new conflict-key family** for safe-open materialization itself.

6) **Sealed compat remains non-ambient**
   - Foreign Cell / compat viewers may participate in safe-open only by receiving the same request-local stable input boundary.
   - Compat must not reinterpret safe-open as “mount the real host file read-write in a sandbox” or “let the legacy app save directly back through the chooser grant.”
   - If a compat path cannot preserve snapshot-in / explicit-export-out semantics, it fails closed for `open_untrusted`.

## Phase 1 non-goals (explicitly deferred)

- **No live shared mount / read-write alias** from the safe-open viewer back to the source object.
- **No automatic copy-back / overwrite-original on close or save**.
- **No auto-refresh-on-source-change** for an already launched safe-open instance.
- **No hidden “same sandbox keeps editing the same document” continuity promise**.
- **No new safe-open-specific publish/replace API** beyond existing `portal.file.*` / `portal.xfer.*` / IF-CONSENT seams.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM, D-POWERBOX)
- Related posture / schema surfaces:
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-active-content-boundary-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
  - `document-portal-posture-v0.md`
  - `quarantine-posture-v0.md`
  - `open-untrusted-export-classification-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `open-untrusted-export-lineage-boundary-v0.md`
  - `document-handle-schema-v0.md` (CH-DOCREF v0)
  - `disposable-domain-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-DOCREF-2, I-QUAR-3, I-QUAR-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-DOCREF-REOPEN, PO-QUAR-GATE, PO-QUAR-LOCAL)
- RFC / engineering history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_materialization_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **resolve-once / stable-materialization / no-live-alias / explicit-export-out** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-QUBES-QFILECOPY.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-XDG-PORTAL-FILECHOOSER.
