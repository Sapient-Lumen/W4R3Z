# MicroVM template lineage posture v0 (reusable templates are parent-bound leaf artifacts)

Purpose: pin the **Phase 1** artifact semantics for reusable `ext.microvm` warm-start templates so fast-start work does not quietly grow a public diff/base snapshot plane or a mutable deployment surface.

This doc attaches to **D-MICROVM**, **D-EPHEM**, **D-INITSNAP**, **D-CHKPT**, and **D-ATOMICUPD** and makes one hard decision explicit:
**a reusable warm-start template is a parent-bound, leaf-resumable derived accelerator; diff/base layering and in-place mutation stay implementation-local.**

## Posture (v0)

1) **Reusable templates are derived accelerators, not standalone deployment roots**
   - A reusable warm-start template is a **derived accelerator** subordinate to one exact reviewed parent lineage.
   - That parent lineage is policy-owned and MUST bind template selection to the exact deployment/template inputs that gave the template meaning — for example the selected deployment/`CH-BOOT` root, optional `CH-INIT` / `CH-CKPT` digest, and the local runtime/VMM profile used to cut it. Restore-admission scope is pinned separately in `microvm-template-resume-class-posture-v0.md`: a reviewed leaf is only fan-out-admissible on hosts in the same exact reviewed class. Distribution scope is pinned separately in `microvm-template-distribution-posture-v0.md`: even a reviewed reusable leaf stays owner-local rather than becoming a portable/public artifact class.
   - A reusable template therefore MUST NOT be treated as an independently selected deployment root, update object, or compatibility artifact with authority separate from its parent lineage.
   - If the parent deployment/template lineage is withdrawn, superseded by policy, or violates the applicable rollback floor, the derived reusable template is likewise ineligible for ordinary fan-out.

2) **The externally selected reusable template is always leaf-resumable**
   - Phase 1 portable fan-out consumes one **leaf-resumable full template artifact**.
   - If an implementation internally uses base snapshots, diff layers, merge chains, copy-on-write caches, or equivalent storage optimizations, those remain internal preparation details.
   - Policy, tooling, and portable workflow surfaces MUST NOT require callers to select a base snapshot, reason about layer order, or reconstruct a resumable template by replaying a public chain.

3) **Template refresh happens by cutting a new leaf, not mutating one in place**
   - When a change alters the parent lineage that gives a reusable template meaning — such as code/config/runtime changes, feature-flag changes, template cut semantics, or VMM/runtime compatibility changes — Phase 1 handles that by cutting and admitting a **new reusable template leaf**.
   - The old leaf may remain as an owner-local cache while its parent lineage stays policy-admissible, but it MUST NOT silently change meaning in place.
   - In plain terms: reusable templates behave more like published-version caches than mutable live system state.

4) **Implementation-local layer management stays non-portable**
   - Implementations MAY compact, merge, rebase, encrypt, deduplicate, or garbage-collect internal template layers locally.
   - Phase 1 does **not** standardize a portable snapshot-manifest schema, diff/base export contract, merge API, or template inventory/search plane for these internals.
   - Any future externally visible management surface for template chains must pay its own RFC/evidence cost rather than inheriting legitimacy from “snapshot support exists”.

5) **Commutativity and ordering remain explicit by omission**
   - This posture introduces **no new ACP kind** and **no new conflict-key family** in Phase 1.
   - If a later management plane exposes actions such as “publish template leaf”, “merge diff layer”, or “rebase template chain”, it must specify conflict keys, retry semantics, serialization scope, and evidence hooks explicitly.
   - Until then, internal template-chain ordering lives inside the owning runtime/VMM implementation, not in portable workflow semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable snapshot-chain manifest or diff-layer schema.
- No public merge/rebase API for reusable templates.
- No claim that internal layer storage is stable across runtime/VMM revisions.
- No in-place mutation semantics for a published reusable template leaf.
- No public inventory/search surface for internal template layers.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-INITSNAP, D-CHKPT, D-ATOMICUPD)
- Adjacent postures:
  - `microvm-template-snapshot-cut-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `microvm-profile-posture-v0.md`
  - `disposable-domain-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-6)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-TEMPLATE-LINEAGE)
- Policy posture:
  - reusable template lineage adds **no new lane**, **no new compat exemption**, and **no new portable snapshot-chain surface** in Phase 1.

CI drift gate:
- `tools/check_microvm_template_lineage_posture.py` fails `make lint` if this posture stops being discoverable, loses its **parent-bound / leaf-resumable / refresh-by-new-leaf / internal diff-chain hidden** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-AWS-SNAPSTART-ACTIVATE.
- REF-AWS-LAMBDA-VERSIONS.
