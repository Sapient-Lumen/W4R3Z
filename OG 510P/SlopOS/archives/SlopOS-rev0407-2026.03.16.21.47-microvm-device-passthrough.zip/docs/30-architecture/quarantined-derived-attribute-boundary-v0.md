# D-QUAR / D-ATTRFS quarantined derived-attribute boundary v0 (no source-object semantic back-write)

Purpose: pin the **source-metadata boundary** for explicit analysis of quarantined content so “derive something useful” does not quietly turn into “rewrite the risky source object’s queryable metadata.”
It narrows the next laundering seam after the **metadata-safe only** content-index rule: once OCR / classify / summarize / embed becomes an explicit workflow that yields a new quarantined artifact, **may that workflow also write semantic tags, extracted text, or classifier labels back onto the source object’s CH-ATTR namespace?**
Phase 1 answers: **no**. Source-object metadata for quarantined content stays metadata-safe; durable content-derived interpretation lives on a **separate derived artifact**, not as semantic back-write onto the risky source.

This keeps D-QUAR and D-ATTRFS honest without inventing a bigger provenance/tagging subsystem: the archive already allows explicit derived-output workflows, but now fixes the minimum portable rule that stops those workflows from laundering risky bytes back into search/query/smart-folder surfaces through source-object labels. Companion derived-match boundary: even when durable semantics live on a separate derived artifact, query/search/smart-folder surfaces still may not resurface the risky source object by hidden lineage joins or representative substitution (`quarantined-derived-match-boundary-v0.md`).

## Posture (v0)

1) **Source-object metadata stays metadata-safe even after explicit analysis**
   - For a quarantined source object, the queryable/source-visible CH-ATTR surface remains limited to declared safe metadata such as type, size, timestamps, quarantine/origin fields, and shell-owned manual labels.
   - An explicit OCR / summarize / classify / embed workflow must not back-write recognized text, semantic tags, classifier labels, extracted entities, topic hints, or similar **content-derived** attributes onto that source object.
   - In other words: explicit analysis may create a sibling artifact, but it does **not** upgrade the risky source into a semantic index entry.

2) **Durable analysis results live on a new derived artifact, not on the source object**
   - If the system persists recognized text, summary notes, embedding blobs, classifier outputs, or semantic tags for quarantined content, those durable results are represented as a **new artifact** with its own digest/log justification.
   - The new artifact remains **quarantined by default** unless a separate clear/sanitize workflow says otherwise.
   - When known, that derived artifact records exact parent linkage through `origin.parent_digest`; richer provenance may additionally use CH-PROV / `origin.chain_digest` if enabled.

3) **Query and smart-folder surfaces do not gain semantic predicates on the risky source**
   - Because content-derived results do not back-write onto the source object, saved queries / smart folders must not start matching the quarantined source by newly attached OCR text, semantic labels, or classifier attributes.
   - If a user/operator wants those derived fields to be queryable, the query targets the **derived artifact’s** attributes, not the source object’s.
   - This keeps D-ATTRFS snapshot/live-query semantics honest: the source object’s discoverability does not widen merely because an explicit analysis workflow once touched it.

4) **Manual shell labels remain manual and non-authoritative**
   - Phase 1 still allows shell-owned/manual labels on the source object where the shell policy otherwise permits them.
   - But an analysis workflow, assistant, or indexer must not silently collapse its own semantic output into those labels on the user’s behalf.
   - Any user-visible “apply these suggested labels” affordance is a **separate explicit edit** to source metadata, not an automatic consequence of running OCR/classify/summarize on quarantined bytes.

5) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - Analysis/export workflows serialize only on their existing provider/workflow seams plus whatever existing destination mutation seam they already use for the **derived artifact**.
   - The source object does not gain a second hidden mutation stream for semantic metadata back-write.

6) **Sealed compat remains killable and non-ambient**
   - Compat adapters may support OCR/search/classification features only if quarantined-source metadata still respects this no-semantic-back-write boundary.
   - If a foreign stack can only express analysis results by mutating the source object’s queryable metadata/property set, that behavior must be disabled or isolated behind a separate explicit materialization step that yields a new artifact.
   - Legacy “write extracted tags/properties back onto the same file item” behavior is not grandfathered into sealed compat for quarantined sources.

## Phase 1 non-goals (explicitly deferred)

- **No write-back of OCR text, summary text, semantic labels, or classifier outputs onto quarantined source-object attributes**.
- **No automatic smart-folder / saved-query enrollment of a quarantined source object based on content-derived analysis results**.
- **No claim that user-authored/manual shell labels disappear**; the boundary is about automatic or analysis-driven semantic back-write.
- **No generic provenance / tagging ACP kind or source-object semantic patch protocol in v0**.
- **No exception that collapses source and derived object identity just because both live under the same provider or share equal bytes**.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-QUAR, D-ATTRFS)
- Related posture / schema surfaces:
  - `quarantined-content-index-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `attrfs-posture-v0.md`
  - `attribute-schema-v0.md`
  - `attribute-query-schema-v0.md`
  - `origin-quarantine-attrset.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-5, I-ATTRQ-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL, PO-ATTRQ-ENF)
- RFC / engineering history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0100-attribute-query-predicates-and-smart-folders.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_quarantined_derived_attribute_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no semantic back-write onto the source object / derived artifact instead / no smart-folder enrollment by source mutation** constraints, or drops its primary REF wiring.

## References

- REF-MS-WINDOWS-PROPERTY-HANDLERS.
- REF-MS-WINDOWS-SEARCH-INDEXING.
- REF-APPLE-SPOTLIGHT-IMPORTERS.
- REF-APPLE-SPOTLIGHT-QUERYGUIDE.
