# D-RUMPK posture v0 (rump kernels, FS-image handling only)

Purpose: resolve **OQ-0003 (D-RUMPK selection)** by pinning a small, implementable v0 choice for what runs *inside* a Foreign Cell when the optional compat lane is enabled.

This doc does **not** change the membrane contract (that is D-FCELL / `foreign-cell-contract.md`). It only constrains the *internal runtime* choice and its initial scope.

## Posture (v0)

If the compat lane is enabled (D-FCELL + D-RUMPK), then:

1) **Default internal runtime: NetBSD rump kernels (rump servers)**
   - “Rump domain” == ordinary user-space component hosted behind the compat membrane.
   - Treat the runtime as **untrusted**; all host effects must remain portalized (I-COMPAT-1).

2) **Scope: filesystem-image handling is the first-class case**
   - The v0 compat runtime may mount/parse **untrusted filesystem images** via a translator/view path (D-TRANS/D-NS).
   - It does **not** become a general “POSIX app” substrate.
   - No v0 expansion to general networking stacks, storage stacks, or “legacy app” ABI facades without a new RFC + explicit evidence plan.

3) **No second compat runtime family in Phase 1**
   - v0 explicitly does **not** adopt:
     - LKL as a donor kernel runtime,
     - a gVisor-style userspace kernel,
     - or Drawbridge-style win32 personality layers,
     as the Phase 1 compat runtime family.
   - Any change here requires an RFC/ADR and a new negative-test suite beyond AC-071 that targets the new family’s escape vectors.

## Phase 1 non-goals (explicitly deferred)

- No “run Linux guests” as an ambient compatibility escape hatch (microVM is not a compat story by default).
- No “compat syscall ABI promise” for general apps.
- No automation bypass: compat remains lane-killable and portalized.

## Wiring

- Decision surfaces: `decision-map.md` (D-RUMPK, D-FCELL) and OQ-0003.
- Membrane contract: `foreign-cell-contract.md` (D-FCELL).
- Related posture: `microvm-profile-posture-v0.md` (D-MICROVM; microVM is not a compat escape hatch).
- RFC context: RFC-0036 (rump kernel cell), RFC-0083 (compat lane considerations).
- CI drift gate: `tools/check_rumpk_selection_posture.py` (EVID-2026-210).

## References

- REF-RUMPKERNEL-WIKI
- REF-RUMPKERNEL-ABC2015
- (comparison-only; non-v0): REF-LKL-GITHUB, REF-GVISOR-GITHUB, REF-DRAWBRIDGE-ASPL11
