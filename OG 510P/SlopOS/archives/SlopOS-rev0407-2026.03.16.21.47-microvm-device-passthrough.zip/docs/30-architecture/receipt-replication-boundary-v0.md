# Receipt replication boundary v0

Purpose: narrow **OQ-0001** for `object_family = receipt` without turning replicated receipts into portable effect authority.

SlopOS already emits several **non-authoritative receipt artifacts** — CH-RECEIPT, CH-DENY, CH-ACPOUT, and CH-FADAPT — so users, tools, and LLMs can explain decisions and reconstruct workflow history. Hybrid needs one more hard decision so cross-cluster receipt sharing does not quietly become a result cache, approval cache, or handle-resurrection seam:

- replicated `receipt` state is an **immutable digest-addressed evidence set**, and
- **effect authority still comes only from explicit local policy/capability/restore seams**, never from replicated receipt arrivals.

This keeps RC3 commutative replication honest while preserving the archive rule that receipts are audit artifacts, not authorization artifacts.

## Decision (v0)

For `object_family = receipt` under CH-REPLCONTRACT v0:

1. The replicated value is a **content-addressed set of immutable receipt artifacts** scoped by `log_id`:
   - CH-RECEIPT v0
   - CH-DENY v0
   - CH-ACPOUT v0
   - CH-FADAPT v0 / v1
   - other future receipt-like artifacts only if they keep the same non-authoritative posture
2. Merge is **set union by canonical digest**. Duplicates collapse by digest; arrival order is not authoritative.
3. Replication MAY move receipt artifacts between clusters for audit, diffing, explanation, bundle closure, or offline correlation, but it MUST NOT by itself:
   - satisfy a missing local approval, policy, or capability check,
   - authorize replay/resubmission of an old action,
   - instantiate or reissue a handle/lease/capability named by a receipt field,
   - treat `result_digest`, `authz_digest`, `vol_digest`, `lease_id`, or `issued[*].digest` as bearer authority, or
   - turn “most recent receipt arrival” into a runtime freshness/order oracle.
4. Any local system that wants to act on what a receipt names must still cross an **explicit local seam**:
   - portal re-consent for CH-RECEIPT,
   - validator/executor admission for CH-ACPOUT / CH-DENY,
   - explicit restore/import for capability-bearing continuations,
   - explicit local adapter/policy checks for CH-FADAPT.
5. If a future design needs portable approvals, remotely consumable result tokens, or receipt-driven restore/import semantics, that work must land as a **new RFC-first descriptor/object family**, not as a reinterpretation of `object_family = receipt`.

## Why RC3 fits here

Receipt artifacts are immutable evidence objects. Adding one more receipt digest to the observed set commutes with adding another.

What does **not** commute is using those receipts to decide whether a new privileged effect may happen now. SlopOS intentionally keeps that decision outside replication and on local explicit seams. There is no v0 rule like “a replicated allow receipt may skip consent,” “a replicated ACP outcome may skip validation,” or “the latest receipt arrival revives the old lease.”

## Explicit non-goals (v0)

Phase 1 does **not** standardize:

- cross-cluster approval caches,
- remote effect/result admission based on old receipts,
- automatic lease/handle resurrection from replicated receipt metadata,
- receipt-arrival order as a distributed freshness clock, or
- a global receipt authority service.

If later phases need portable approval/result tokens, they must pay for a distinct capability/descriptor seam with its own invariants, replay rules, and evidence.

## Source notes

- in-toto Statements separate **subject binding** from the predicate payload, and the framework further separates **statement**, **envelope**, and **bundle** layers (REF-IN-TOTO-STATEMENT).
- DSSE authenticates the **message and its type** specifically to avoid confusion attacks; the envelope is authentication/packaging, not effect authority (REF-DSSE).
- OCI descriptors keep type + digest + size in a reference object used to securely point at content, rather than overloading referenced content into runtime authority (REF-OCI-DESCRIPTOR).

## Consequences for the archive

- `replication-object-family-registry.md` should treat `receipt` as **digest-addressed evidence-set replication only**.
- `profile-repl-defaults.md` may keep RC3 defaults where desired, but the note must say that replicated receipts are **evidence only** and cannot drive replay/import/admission.
- Receipt schema docs should point out that replicated receipt artifacts never become approval, replay, or handle-resurrection authority.
- Any future stronger semantics must pay for a new decision surface.
