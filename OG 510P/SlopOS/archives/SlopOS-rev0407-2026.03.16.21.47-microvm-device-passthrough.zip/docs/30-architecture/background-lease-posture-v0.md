# D-BGLEASE posture v0 (bounded background presence; no silent persistence widening)

Purpose: pin an **implementable Phase 1** meaning for D-BGLEASE that keeps background execution and login autostart explicit, user-legible, and review-bound.
It narrows a high-entropy seam for the workstation and agent/automation shapes without inventing a new scheduler or “blessed daemon” subsystem.

This doc is intentionally narrow: it does **not** design a generic service manager, a universal power manager, or a rich autostart policy language.

## Posture (v0)

1) **No ambient background/autostart constructors**
   - If D-BGLEASE is enabled, post-init components obtain background execution or login autostart only via `portal.background` (manual workflow) or ACP kind `portal.background.request` (automation).
   - There is no ambient “keep running”, per-user daemon registration, or login-autostart registry surface after init.

2) **Background presence is not generic scheduling**
   - D-BGLEASE is for **continuous presence** or user-legible persistence, not for ordinary deferred work.
   - Phase 1 explicitly says **prefer `portal.jobs` / D-JOBS** for deferrable sync, uploads, maintenance, indexing, and retry loops.

3) **Background and autostart are distinct grant bits; widening is explicit**
   - `background` and `autostart` remain separate grant bits in CH-BGREQ/CH-BGLEASE.
   - A background grant MUST NOT imply login autostart.
   - Renew/retry flows MUST NOT silently widen a live grant (for example, background-only → autostart, or a larger TTL than policy already clamped). Any widening requires a **fresh** CH-BGREQ request and a new transcript-visible decision path.

4) **Review-bound, revocable, and attenuation-friendly**
   - The portal clamps TTL/review cadence; expiry and revocation fail closed.
   - Closing the live BackgroundLease drops background permission deterministically.
   - Autostart remains tied to the grant record and is independently revocable.

5) **Visibility is part of the contract**
   - Long-lived background presence implies a user-visible indicator/status surface.
   - CH-BGREQ `status_message` / CH-BGLEASE `status_message` stays single-line and bounded; the portal owns the presentation surface.
   - Routine exports SHOULD prefer redacted/hash-only telemetry in strict profiles.

6) **Composition stays honest**
   - Background/autostart grants do **not** imply network, file, device, capture, location, or notification authority.
   - Those authorities remain separately portalized/leased and policy-killable.
   - In the agent/automation profile, long-lived background work SHOULD compose with explicit sponsorship (`digest(CH-BUDGET v0)` / `digest(CH-TCAP v0)`) where those surfaces are enabled.

7) **Externally visible automation is ordered within a domain**
   - `portal.background.request` is an externally visible action:
     - conflict key family: `domain.id`,
     - ordering: **ordered** within a domain because grant/renew/revoke state lives there,
     - serialization boundary: `svc:portal.background`,
     - retry stance: at-least-once-safe only when the portal dedupes by CH-BGREQ `req_id` and duplicate suppression is transcript-visible.

8) **Sealed compat remains killable and non-ambient**
   - Any foreign-cell use of background/autostart must flow through explicit adapters and `portal.background`; compat runtimes do not gain their own ambient persistence channel.
   - The seam remains fail-closed behind `cfg.params.lane.portal.background`.

## Phase 1 non-goals (explicitly deferred)

- **Ambient launch agents / user daemons / cron-like substitutes** beyond D-JOBS.
- **Silent widening on renewal** (“I already had background, so now grant autostart too”).
- **Publisher-wide blanket exemptions** that bypass transcript/visibility requirements.
- **Implicit network wake loops** or hidden polling allowances tied to background presence.

## Wiring

- Decision surface: `decision-map.md` (D-BGLEASE).
- Schemas:
  - `background-request-schema-v0.md` (CH-BGREQ v0)
  - `background-lease-schema-v0.md` (CH-BGLEASE v0)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.background.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.background`)
  - `docs/70-llm-control/acp-action-kind-registry.md` (`portal.background.request`)
  - `docs/70-llm-control/acp-validator-semantics.md` (PO-ACP-BGLEASE-REQUEST)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-BGREQ-1, I-BGLEASE-1..3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-BGREQ-VALIDATE, PO-BGLEASE-VALIDATE, PO-BGLEASE-ENF, PO-ACP-BGLEASE-REQUEST)

CI drift gate:
- `tools/check_bglease_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “prefer jobs / no ambient persistence / no silent widening” constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-BACKGROUND.
- REF-ANDROID-BG-EXEC-LIMITS.
- REF-ANDROID-FGS-RESTRICTIONS.
- REF-APPLE-BG-MODES.
- REF-APPLE-BGTASKS.
