# CH-IOBUF v0: I/O buffer descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **copyless shared buffer authority** (D-IOBUF).
This schema is **not** the authority itself; it describes the bounds/intent of a buffer handle (e.g., a `SharedRegion`/`Buf` capability) so tooling, transcripts, and portals can be explicit about *what kind of sharing* occurred.

References: REF-IOLITE-OSDI99, REF-IOLITE-IMMUTABLE, REF-FUCHSIA-VMO-CREATE, REF-FUCHSIA-VMO-CHILD, REF-XEN-GRANTTABLE.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-IOBUF v0 := {
  v: 0,

  kind: tstr,                 ; closed enum: "linear" | "ring_spsc" | "ring_mpsc" | "sg_list"

  size_bytes: uint,           ; total buffer size (bounded by profile)
  align_bytes?: uint,         ; optional alignment hint (power of two; bounded)

  immutability: tstr,         ; closed enum: "mutable" | "frozen" | "cow_snapshot"
                              ; "frozen" means payload is immutable under the declared profile
                              ; "cow_snapshot" indicates copy-on-write snapshot semantics were used

  sharing: {
    participants: [
      {
        comp_id: tstr,         ; canonical component id/name (CH-COMP), bounded
        role: tstr,            ; closed enum: "producer" | "consumer" | "peer"
        rights: tstr,          ; closed enum: "r" | "rw"         (map rights; non-authoritative hint)
      }
    ],

    trust: tstr,               ; closed enum: "same_domain" | "same_trust" | "cross_trust"
                               ; "cross_trust" SHOULD imply immutability != "mutable" for safe use
  },

  usage: tstr,                 ; closed enum: "ipc" | "net" | "storage" | "graphics" | "driver_dma" | "other"

  coherence?: {
    model: tstr,               ; closed enum: "coherent" | "noncoherent"
    flush_required?: bool,     ; if true, producer/consumer must use an explicit flush/invalidate step
  },

  lifetime: {
    issued_at_s: uint,         ; monotonic or policy-defined epoch seconds
    ttl_s: uint,               ; lease duration (issuer may clamp)
  },

  origin: {
    comp_id: tstr,
    instance?: tstr,
  },

  purpose?: tstr,              ; bounded, non-authoritative note; for UI/audit only

  redaction?: {
    mode: tstr,                ; closed enum: "none" | "drop_participants" | "hash_participants"
    participants_hash?: bstr,  ; digest of canonical participants list if hashed
  },
}

Notes:
- `immutability` captures the **TOCTTOU posture**: if data is passed by reference across trust boundaries, the receiver should not have to assume the sender can mutate the bytes after "send".
- `trust` is advisory but intended to be **linted** by composition policy: `cross_trust` with `immutability="mutable"` should be treated as a policy violation in hardened profiles.
- `rights` is a *hint* for audit/UX; the authoritative rights live in the capability itself.

## Validation rules (minimum)
A CH-IOBUF validator MUST be total and fail closed:
1) `v == 0`.
2) `kind`, `immutability`, `usage` are allowlisted closed enums.
3) `size_bytes` is present and bounded by profile; `align_bytes` (if present) is a power-of-two ≤ profile bound.
4) `sharing.participants` length is bounded; each `comp_id` is bounded; roles/rights are allowlisted.
5) `sharing.trust` is allowlisted.
6) `lifetime.issued_at_s` and `lifetime.ttl_s` are present and bounded; issuer may clamp `ttl_s`.
7) If `sharing.trust == "cross_trust"`, then `immutability != "mutable"` unless the active profile explicitly permits it.
8) Unknown keys reject (or are rejected by canonical decode).

## Privacy notes
Participant identity can be sensitive (it can reveal workflow topology). Export tooling SHOULD support `redaction` by default (C-OBS-1), preferring `hash_participants` when exporting to third parties.
