# CH-SIGENV v0 (signature envelope over payload digests, informal)

Purpose: provide a small, canonical “this payload digest was signed” envelope for CH-* artifacts.

Design rules:
- the envelope signs a **payload digest + payload type** (domain separation)
- no requirement to embed the payload bytes (keep envelopes small)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded lists and closed enums (no unbounded narratives)

This schema is DSSE-inspired: signatures are computed over a pre-auth encoding of `(payload.schema, payload.digest)` rather than over an ad-hoc concatenation.

Refs: REF-DSSE, REF-DSSE-BACKGROUND.

## Shape (v0)
An envelope `s` contains:
- `schema`: fixed `CH-SIGENV v0`

### Payload binding
- `payload`:
  - `schema`: bounded string (e.g., `CH-UPD v0`, `CH-PROV v0`, `CH-CFG v0`)
  - `digest`: digest of the canonical payload bytes (same digest namespace as CH-BOOT)
  - `size_bytes`: optional u64 (informational)

### Signatures
- `signatures`: bounded list of signature records (at least 1)

Each signature record `sig` contains:
- `kind`: closed enum `{ direct_key, keyless_cert }`
- `alg`: closed enum (v0): `{ ed25519, ecdsa_p256_sha256, rsa_pss_sha256 }`
- `sig_bytes`: bytes

Signer material (depends on `kind`):
- if `kind = direct_key`:
  - `key_id`: bounded string (must match an allowlisted verifier key id)
  - `pubkey_spki`: optional bytes (SPKI DER) (may be omitted if the verifier already knows the key by `key_id`)
- if `kind = keyless_cert`:
  - `cert_digest`: digest of the leaf X.509 certificate (DER)
  - `issuer`: bounded string (OIDC issuer / CA instance identifier)
  - `identity`: bounded identity hints (non-authoritative; policy-checked):
    - `subject`: bounded string
    - `repo`: optional bounded string (e.g., `org/repo`)
    - `workflow`: optional bounded string
    - `commit`: optional bounded string

Optional transparency anchoring:
- `tlog_anchor_digest`: optional digest of `CH-TLOG v0` asserting `leaf_digest == payload.digest`

## Verification obligations
- PO-SIGENV-VALIDATE: deterministic decode, canonical bytes, bounds, closed enums.
- PO-SIGENV-VERIFY: verify signatures over the DSSE-style pre-auth encoding of `(payload.schema, payload.digest)`.
- PO-KEYLESS-VERIFY (if enabled): validate cert chain + issuer allowlist + identity allowlist + validity window.

Notes:
- `identity` fields in `keyless_cert` records are **hints**; verifiers must not trust them unless they re-derive/check against the certificate claims per the profile policy.
- Certificate bytes and inclusion proofs are intentionally out-of-band. If needed, store them as content-addressed blobs and reference via CH-AREF in a higher-level bundle.
