# CH-REQCTX sponsorship evolution boundary v0 (keep request context small)

Purpose: resolve **OQ-0008** by freezing the meaning of CH-REQCTX sponsorship digest lists and pre-committing where any future typed sponsorship may live.

This is intentionally a **boundary** doc, not a new schema. It exists to keep CH-REQCTX small, audit-friendly, and non-authoritative while still leaving room for future multi-schema sponsorship *outside* the request-context core.

## Decision (v0)

1) **CH-REQCTX sponsorship lists stay bare digests**
   - `budget_desc_digests` and `tcap_desc_digests` remain `list<bytes32>` correlation surfaces in CH-REQCTX v0/v1.
   - Their meaning is frozen: they are **not** upgraded in place into `{schema,digest}` objects, tagged unions, or resolver directives.

2) **No polymorphic reinterpretation of existing fields**
   - Privileged code MUST NOT infer schema/type from locator shape, naming conventions, list position, or side-band defaults.
   - Consumers that require sponsorship remain **type-strict and fail-closed**: they validate the referenced artifact bytes and accept only the exact schema(s) their interface names.

3) **If typed sponsorship ever becomes necessary, it lives outside CH-REQCTX**
   - Any future multi-schema / typed sponsorship surface MUST be introduced as a **separate descriptor family or sidecar artifact** via RFC + evidence, not by changing the semantics of `budget_desc_digests` / `tcap_desc_digests`.
   - A future typed surface may be *bound by digest* from workflow artifacts, but it does not get to retroactively redefine what CH-REQCTX v0/v1 meant.

4) **Typed wrappers are still non-authoritative**
   - Even if a future sidecar carries explicit `schema` / `kind` / `locator` metadata, authority still comes from validating the referenced descriptor artifacts under the receiving interface's rules.
   - Typed wrappers may aid discovery, audit, or dispatch; they MUST NOT become ambient sponsorship or a second authorization path.

## Why this boundary exists

- **Keeps CH-REQCTX honest**: request context remains bounded correlation + veto-only narrowing metadata, not a growing bag of semi-authoritative workflow objects.
- **Avoids semantic drift**: existing digest lists do one small job and stay reviewable.
- **Preserves future flexibility without forked meaning**: if we later need typed sponsorship, we can add it explicitly without creating two incompatible readings of old transcripts.

## Imported ecosystem pattern

- **OCI descriptors** carry type and digest in a dedicated object (`mediaType`, `digest`, `size`) instead of asking consumers to reinterpret a bare digest list differently in different places.
- **in-toto statements** keep subject identity digest-based while allowing additional descriptor metadata only where explicitly modeled.
- **DSSE** is a reminder that type confusion is a real attack surface; when type matters, bind it explicitly instead of letting wrappers or conventions guess.

We import the pattern, not the whole ecosystem: **type lives in an explicit wrapper object when needed; bare digest lists stay bare**.

## Consequences

- CH-REQCTX v0/v1 stays stable and easy to lint.
- Existing posture docs for budget and temporal sponsorship remain correct.
- Future typed sponsorship work, if it ever happens, must pay its own entropy cost with one explicit new schema/decision surface.

## Wiring

- Decision surfaces: `decision-map.md` (D-REQCTX, D-BUDGET, D-TCAP).
- CH-REQCTX schemas: `request-context-schema-v0.md`, `request-context-schema-v1.md`.
- Current consumer-typed postures: `reqctx-budget-ref-posture-v0.md`, `reqctx-tcap-ref-posture-v0.md`.
- Trajectory resolution: `docs/00-meta/trajectory-map.md` (retired OQ-0008).
- CI drift gate: `tools/check_reqctx_sponsorship_boundary.py` (EVID-2026-255).

## References

- REF-OCI-DESCRIPTOR
- REF-IN-TOTO-STATEMENT
- REF-DSSE
