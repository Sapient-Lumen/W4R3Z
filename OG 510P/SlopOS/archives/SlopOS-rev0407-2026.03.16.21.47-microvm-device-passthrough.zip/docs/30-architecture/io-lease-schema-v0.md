# CH-IOLEASE v0: device/I/O lease descriptor (schema)

Purpose: a pinned, redaction-safe descriptor for **device leases** (D-IOLEASE), suitable for transcript logging and audit.

Posture: Phase 1 device-leasing workflow posture is pinned in `io-lease-posture-v0.md` (manual-only v0; no ambient device namespace; consent receipts).

CH-IOLEASE is a stable artifact for **LLM-proposed / validator-executed** device leasing:
- ACP proposals and CH-LOG/CH-ACPOUT receipts reference `digest(CH-IOLEASE v0)`.
- A driver/portal returns live capability handles (doorbells, queues, IRQ endpoints) **separately**; CH-IOLEASE describes the intended bounds.

Design constraints:
- **Non-authoritative**: CH-IOLEASE MUST NOT be treated as authorization evidence. It is a descriptor for audit/policy checks only (I-IOLEASE-3).
- **No secrets**: it MUST NOT contain bearer capability material or ambient-authority surrogates.
- **Canonical + fail-closed**: decoding/validation is total; unknown variants/keys reject (I-ENC-1; PO-IOLEASE-VALIDATE).
- **Bounded + closed enums**: lists/strings are bounded; enums are closed.
- **Address sensitivity**: prefer policy-safe references to raw addresses; profiles may forbid raw `iova_range` values on export.

## Encoding
Candidate baseline: canonical CBOR (D-ENC), optionally wrapped with COSE for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-IOLEASE v0 := {
  v: 0,

  schema: "CH-IOLEASE",
  lease_id: tstr,               ; bounded opaque correlation id (non-authoritative)

  device: {
    class: tstr,                ; "net" | "storage" | "gpu" | "other" (closed)
    label?: tstr,               ; optional redacted label (policy-controlled; bounded)
    instance_hint?: uint        ; optional small integer (bounded)
  },

  queues: [ * {
    kind: tstr,                 ; "tx" | "rx" | "submit" | "complete" | "other" (closed)
    index: uint,                ; queue index (bounded)
    depth_hint?: uint           ; bounded advisory only
  } ],

  dma_window: {
    kind: tstr,                 ; "none" | "iova_range" | "policy_ref" (closed)
    base?: uint,                ; required when kind="iova_range" (profile may forbid on export)
    len?: uint,                 ; required when kind="iova_range" (non-zero; bounded)
    ref?: tstr                  ; required when kind="policy_ref" (e.g., "dma.window.3")
  },

  irq?: {
    kind: tstr,                 ; "msix" | "msi" | "intx" | "other" (closed)
    vectors: [ * uint ]         ; bounded list of vectors/lines
  },

  expiry?: {
    kind: tstr,                 ; "monotonic_deadline_ms" (v0; closed)
    deadline_ms: uint           ; monotonic deadline (profile-defined timebase)
  }
}

Notes:
- `lease_id` is for correlation only. It MUST NOT be used to infer authority.
- `queues[*].index` / `irq.vectors` describe dataplane bounds inside one granted lease; they are not separate `portal.device.*` conflict-key families or attach-policy ordering keys (see `device-lease-ordering-boundary-v0.md`).
- `dma_window.kind="policy_ref"` exists to avoid embedding raw addresses; profiles may require `policy_ref`.

## Validation rules (minimum)
Decoders and validators MUST be total and fail closed (PO-IOLEASE-VALIDATE):
1) `v == 0` and required fields are present.
2) `schema == "CH-IOLEASE"`.
3) All closed enums reject unknown values: `device.class`, `queues[*].kind`, `dma_window.kind`, `irq.kind`, `expiry.kind`.
4) Bounds are enforced deterministically:
   - `lease_id` length <= 64; `device.label` length <= 128; `dma_window.ref` length <= 64.
   - `queues` length <= 32.
   - `queues[*].index` <= 1024; `depth_hint` (if present) <= 1_048_576.
   - `irq.vectors` length <= 256; each vector <= 4096.
5) `dma_window` is internally consistent:
   - if `kind == "none"`: `base/len/ref` MUST be absent.
   - if `kind == "policy_ref"`: `ref` MUST be present; `base/len` MUST be absent.
   - if `kind == "iova_range"`: `base` and `len` MUST be present; `len > 0`; `base+len` MUST NOT overflow.
6) Unknown keys/variants MUST reject (fail closed).

## Intended uses
- CH-LOG entries can reference `digest(CH-IOLEASE v0)` when granting/revoking leases.
- Tooling can check “lease within policy bounds” (e.g., against CH-PART or CH-ADDRNET in tighter profiles).
- Leak tests can assert that revocation removes the corresponding authority edges.

## Related assurance hooks
- I-IOLEASE-1 / PO-IOLEASE-CONFINE (DMA confinement)
- I-IOLEASE-2 / PO-IOLEASE-REVOKE (revocation effectiveness)
- I-IOLEASE-3 / PO-IOLEASE-VALIDATE (canonical, bounded schema surface)

Ref: REF-ARRAKIS-OSDI14.
