# D-CAPSHELL learn-mode posture v0 (observational only; no auto-widen)

Purpose: pin an **implementable Phase 1** meaning for the “learn mode” promised by D-CAPSHELL so adoption help does not quietly become an authority-widening side channel.
It keeps wrapper-first and integrated capshell workflows teachable **without** introducing an allow-and-remember plane, an ambient policy database, or a hidden self-healing runner.

This doc is intentionally narrow: it does **not** define a new CH-* schema, a new ACP kind, or a generic policy synthesis service.

## Posture (v0)

1) **No relaxed enforcement path**
   - If D-CAPSHELL learn-mode tooling exists, `capshell.exec` still runs under the normal fail-closed validator/runner path.
   - Missing effects, missing handles, lane denials, and bind failures remain **denials**, not “allow and log”.
   - Learn mode is observational/reporting behavior over existing transcript-visible failures; it is not a second authorization mode.

2) **Reports are non-authoritative suggestions**
   - Any learn-mode output is a local/report artifact only.
   - It MUST NOT be consumed by validators/runners as authority input, MUST NOT carry raw capabilities/leases/secrets, and MUST NOT bypass CH-EFFCON / CH-PLEDGE / CH-EXECPACK validation.
   - Learn-mode reports may summarize suggested effect-family additions or missing descriptor classes, but they never grant authority by being present.

3) **Suggestions are stage-local and binding-aware**
   - Suggestions SHOULD be keyed to the exact stage execution shape, at minimum the active CH-EFFCON `contract_id`, CH-EFFCON `wallet_core_digest`, and the exact CH-ARGV executable selector for that stage.
   - Multi-stage workflows remain **stage-local**: tooling MUST NOT collapse a pipeline into one broad “allow this whole pipeline” recommendation that hides which stage needed which authority.
   - Any suggested widening must preserve the existing explicit stage boundaries pinned in `capshell-pipeline-posture-v0.md`.

4) **No auto-edit / auto-approve / auto-rerun**
   - Learn-mode tooling MUST NOT silently rewrite CH-EFFCON, CH-PLEDGE, CH-ARGV, CH-ENV, CH-CWD, CH-STDIO, CH-FDSET, or CH-EXECPACK artifacts.
   - It MUST NOT auto-request missing handles/leases/portal grants, and MUST NOT auto-rerun a denied action under a widened contract.
   - Applying a suggestion requires an explicit human/CI edit path that produces new descriptor digests and re-enters the normal review/transcript flow.

5) **Missing effects and missing bindings stay distinct**
   - Learn-mode output MUST keep at least these classes separate:
     - effect-family/pledge suggestions (for example, an omitted `portal.net` family),
     - missing descriptor/handle bindings (for example, an absent input capability),
     - and policy/lane denials.
   - Tooling MUST NOT translate a missing descriptor into a broad effect-family grant suggestion, or vice versa.
   - This keeps “what channel is needed” separate from “which concrete authority instance is missing”.

6) **No new ACP/admin surface**
   - D-CAPSHELL learn mode adds **no new externally visible action family**, no `capshell.learn.*` ACP kind, no persistent approval database, and no workflow callback plane.
   - Ordering/commutativity therefore stay on the existing `capshell.exec` and target effect seams; this posture introduces no new conflict key or serialization boundary of its own.

7) **Sealed compat remains explicit and killable**
   - Wrapper-first / Foreign Cell adoption may use learn-mode reports, but compat runtimes do not gain an ambient host-policy memory channel.
   - Any suggested widening still has to materialize as explicit effect-contract / pledge / binding edits under `cfg.params.lane.capshell`, and all ambient PATH/env/network fallback stays forbidden.

## Phase 1 non-goals (explicitly deferred)

- **Auto-generated policy commits** or self-applying contract rewrites.
- **Allow-once / remember-forever behavior** hidden behind “learning”.
- **Pipeline-wide aggregated approvals** that erase stage boundaries.
- **A generic policy synthesis or approval service** separate from the existing validator/runner/transcript surfaces.

## Wiring

- Decision surface: `decision-map.md` (D-CAPSHELL).
- Core workflow surfaces:
  - `effect-contract-schema-v0.md` (CH-EFFCON v0)
  - `pledge-contract-schema-v0.md` (CH-PLEDGE v0)
  - `capability-wallet-schema-v0.md` (CH-WALLET v0)
  - `argv-schema-v0.md` (CH-ARGV v0)
  - `capshell-exec-pack-schema-v2.md` (CH-EXECPACK v2)
- Adjacent D-CAPSHELL posture docs:
  - `capshell-exec-selector-posture-v0.md`
  - `capshell-pipeline-posture-v0.md`
  - `capshell-output-normal-form-v0.md`
- Portal/control surfaces:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`capshell.exec`)
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `config-toggle-registry.md` (`cfg.params.lane.capshell`)
- Engineering workflow:
  - `docs/60-engineering/authority-bracketing-and-promise-learning.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-CAPSHELL-LEARN-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-CAPSHELL-LEARN-REPORT)

CI drift gate:
- `tools/check_capshell_learnmode_posture.py` fails `make lint` if this posture stops being discoverable, loses its “observational only / no auto-widen / stage-local” constraints, or drops its assurance/evidence wiring.

## References

- REF-SHILL-OSDI14.
- REF-PLASH.
- REF-POLARIS-SOUPS05.
- REF-OPENBSD-PLEDGE.
