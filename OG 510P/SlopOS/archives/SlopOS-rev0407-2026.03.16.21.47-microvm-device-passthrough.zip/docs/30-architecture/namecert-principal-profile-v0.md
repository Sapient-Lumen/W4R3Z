# D-NAMECERT principal-profile boundary v0 (hash-only principal refs; no raw pubkeys in admitted bundles)

Purpose: narrow the **principal identity representation** seam of **D-NAMECERT** so issuer/subject identity
inside local naming bundles cannot quietly widen into multiple equivalent encodings, ad-hoc key-distribution
rules, or bundle-carried verifier material.

This boundary attaches to already-reviewed seams rather than inventing a new one. **CH-NAMECERT** already has
explicit local trust-anchor policy (`namecert-trust-root-boundary-v0.md`), exact-byte authority-bearing label
rules (`namecert-string-profile-v0.md`), and non-bearer target rules (`namecert-bearer-boundary-v0.md`). The
specific Phase 1 question closed here is: **may admitted CH-NAMECERT bundles identify principals either by raw
public keys or by key hashes, leaving equality/aliasing to local taste?**

Phase 1 makes a small, hard choice: **no**. Admitted principal references are hash-only and use one canonical
thumbprint profile.

## Boundary (v0)

1) **Admitted Phase 1 `PrincipalRef` values are hash-only**
   - In admitted **CH-NAMECERT v0** bundles, **`PrincipalRef.kind` MUST be `"key_hash"`** for both `issuer` and `subject` positions.
   - **`PrincipalRef.kind = "pubkey"` is structurally reserved but rejected** in Phase 1 admissions.
   - This removes the easy aliasing problem where the same principal could appear once as raw key bytes and again as a digest-derived identifier.

2) **One canonical thumbprint profile only**
   - In admitted Phase 1 bundles, **`PrincipalRef.alg` MUST be `"cose_key_thumbprint_sha256"`**.
   - `PrincipalRef.data` MUST be exactly **32 bytes**: the SHA-256 COSE Key Thumbprint for the referenced public key.
   - Equality for `PrincipalRef` is exact `(kind, alg, data)` equality after validation; there is no alternate hash, no multiple thumbprint families, and no local case/formatting layer.

3) **CH-NAMECERT carries identifiers, not verifier-key distribution**
   - Admitted Phase 1 bundles do **not** carry raw issuer/subject public keys as part of `PrincipalRef`.
   - Local evaluators map `PrincipalRef = {kind="key_hash", alg="cose_key_thumbprint_sha256", data=...}` to verifier material through already-authorized local trust-anchor / issuer-allowlist / key-registry policy.
   - There is no ambient key fetch, no “look up this thumbprint online”, and no replicated key-store mutation implied by CH-NAMECERT itself.

4) **This keeps issuer-local naming deterministic across all four product shapes**
   - **Secure workstation (A):** no shadow identities caused by mixed raw-key vs hash forms in imported bundles.
   - **Cloud micro-VM substrate (B):** replicated bundle evidence stays compact and avoids accidental key-distribution semantics.
   - **Embedded / separation-kernel-ish appliance (C):** validator logic stays tiny: one accepted principal-id form, one hash algorithm, fixed-width bytes.
   - **Agent/automation OS (D):** LLM-facing tooling gets a simple rule: principal identity is one opaque 32-byte thumbprint, never “maybe raw key, maybe digest”.

5) **This boundary complements, rather than replaces, local trust policy**
   - Hash-only principal references do **not** make CH-NAMECERT self-authenticating.
   - Evaluators still require explicit local trust-anchor policy (`namecert-trust-root-boundary-v0.md`), explicit bundle sets (`namecert-search-boundary-v0.md`), and fail-closed admission semantics (`namecert-posture-v0.md`).
   - The point here is only to keep principal identity representation canonical and cheap to validate.

## Phase 1 non-goals (explicitly deferred)

- Admitting raw issuer/subject public keys directly as `PrincipalRef.kind="pubkey"`.
- Supporting multiple principal-id schemes or hash families inside admitted **CH-NAMECERT v0** bundles.
- Turning CH-NAMECERT into a key-distribution, key-fetch, or trust-anchor-install surface.
- Adding key negotiation / alternate canonicalization semantics on D-NAMECERT itself.

## Wiring

- Core posture: `namecert-posture-v0.md`
- Schema: `namecert-schema-v0.md`
- Adjacent boundaries:
  - `namecert-trust-root-boundary-v0.md`
  - `namecert-string-profile-v0.md`
  - `namecert-bearer-boundary-v0.md`
- RFC source seam: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-VALIDATE**, **PO-NAMECERT-CHAIN**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-030**)

CI drift gate:
- `tools/check_namecert_principal_profile.py` fails `make lint` if this boundary stops being discoverable, loses its **hash-only / one-thumbprint-profile / no raw `PrincipalRef.kind="pubkey"` admissions** stance, or drops its assurance / REF wiring.

## References

- REF-SPKI-RFC2693.
- REF-COSEKEYTHUMBPRINT-RFC9679.
