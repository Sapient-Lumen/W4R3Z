# Worker-pool constructor invocation v0 (exact family-local boundary)

Purpose: pin the **exact family-local invocation shape** for the first concrete D-CONSTR implementation target.
`worker-pool-constructor-family-v0.md` chooses the family, and `worker-pool-constructor-harness-v0.md` says what the first harness must prove.
This doc closes the remaining folklore gap by fixing **which imports exist, what the data-only parameter object may say, and how the exported handles are named**.
It does **not** introduce a generic constructor protocol, a constructor-global type system, or a worker/job API.

## Phase-1 choice

1) **One exact invocation profile fixes imports, params, and exported names**
   - The first worker-pool constructor consumes one invocation shape made of:
     - the pinned worker template/artifact digest set,
     - one exact `digest(CH-EXECPACK v2)` for the worker launch closure,
     - one data-only parameter object,
     - one explicit authority-import set,
     - and one bounded export contract.
   - Family-local variation by hidden label maps, prose interpretation, or late-bound name lookup is out of scope.

2) **Required authority imports are `sponsor`, zero or more `worker_seed/<label>` slots, and optional `install_target`**
   - `sponsor` is required exactly once, and its exact meaning is now fixed by `worker-pool-sponsor-surface-v0.md`: one explicit pool-wide sponsorship root, no ambient payer/session fallback, no sponsor rotation, and no sponsor-inventory/admin drift on runtime surfaces.
   - `worker_seed/<label>` is a bounded repeated slot family for any authority intentionally passed into workers. Each `<label>` MUST match a declared import label in the pinned worker closure/template contract; labels are unique within one invocation.
   - `worker-pool-seed-surface-v0.md` narrows the remaining folklore: the seed-label set is pool-wide and uniform across all worker slots, mismatches fail closed, and Phase 1 adds no per-worker seed maps or reseed-after-construction semantics.
   - `install_target` is optional and appears at most once. It is used only when the caller asks the constructor to publish the canonical exported surface onto an owner-visible target seam instead of returning handles directly.
   - `worker-pool-install-target-surface-v0.md` closes the remaining folklore: `install_target` is publication-only, exact/all-or-nothing, and does not add rename/remap/catalog semantics or a duplicate direct-return surface.
   - There are no wildcard imports, no ambient route lookup, no implicit filesystem/service/network fallback, and no hidden per-worker side-channel imports.

3) **The parameter object is data-only, bounded, and schema-pinned**
   - The parameter object is data-only and bounded.
   - The family-local parameter object MUST validate as `CH-WPOOLPARAM v0`, as pinned in `worker-pool-parameter-schema-v0.md`.
   - `CH-WPOOLPARAM v0` carries only `pool_size` plus the per-slot restart budget (`restart.max_restarts`, `restart.window_ms`).
   - If `restart.max_restarts = 0`, then `restart.window_ms` MUST be `0` and automatic replacement is disabled; otherwise `restart.window_ms` MUST be in `1..3_600_000`.
   - Phase 1 intentionally excludes capability material, free-form env/argv payloads, prose prompts, export-label maps, late-bound selectors, and any knob that would change the worker closure digest set.
   - If the family later needs richer policy, that policy must become a new explicit surface or a new schema-pinned data object rather than silently widening this v0 parameter shape.

4) **The exported surface is canonically named `pool.control` plus `worker[i]` for `0 <= i < pool_size`**
   - The caller-visible result is fixed:
     - one pool control handle named `pool.control`, and
     - one worker entry handle per index named `worker[0]` through `worker[pool_size-1]`.
   - Each `worker[i]` handle is typed by the pinned worker closure/template contract; the family does not define a constructor-specific job protocol on top of that handle.
  - `worker-pool-invocation-manifest-v0.md` fixes the exact digest-first object reused by `invocation.manifest` and `pool.control.Describe()` for the reviewed invocation contract.
  - `worker-pool-control-surface-v0.md` narrows `pool.control` itself to one bounded `Describe()` summary plus cooperative quiesce mutators only; Phase 1 declines scale/reseed/job/admin verbs on the family control handle.
  - `worker-pool-worker-surface-v0.md` narrows `worker[i]` itself to a slot-stable typed entry handle with no per-worker lifecycle/admin wrapper verbs and no transparent live-session continuity promises across worker replacement.
   - Phase 1 declines alias maps, caller-chosen export labels, per-worker diagnostic/export side channels, and hidden supervisor/setup handles in the returned surface.

5) **Fresh return-only invocations commute; install cases serialize on the target seam**
   - If `install_target` is absent, the invocation is **return-only** and commutes when it consumes only explicit imports and allocates a fresh isolated pool.
   - If `install_target` is present, the constructor enters install mode as pinned by `worker-pool-install-target-surface-v0.md`: it may publish only `pool.control` plus `worker[i]` onto that target seam, publication is exact/all-or-nothing, and the installed export set is not duplicated as extra direct outputs.
   - Any non-commutativity is therefore evidenced and serialized by the target seam's existing conflict keys and ordering witnesses, not by a constructor-global key or sequencer.

6) **Replay and confinement evidence must bind canonical import labels and export names**
   - The first harness/replay bundle MUST bind:
     - the presence of exactly one `sponsor` import,
     - the exact set of `worker_seed/<label>` imports,
     - whether `install_target` was present,
     - the parameter-object digest,
     - and the canonical exported names `pool.control` plus `worker[i]`.
   - Because those names are fixed, the family does not need label-remapping receipts, export-name negotiation, or an auxiliary constructor inventory surface.
   - `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md` fixes the corresponding evidence-pack member labels and stable case ids so replay bundles do not fork into per-tool naming folklore.

## Out of scope in v0

- Caller-chosen export-label maps or aliasing.
- Heterogeneous worker closures inside one pool instance.
- Per-worker parameter overrides beyond what can be expressed by explicit `worker_seed/<label>` imports and the bounded family-local parameter object.
- Autoscaling, resize/shrink APIs, or constructor-global pool management.
- Constructor-specific worker job/request schemas.

## Wiring

- Decision surface: **D-CONSTR**.
- Primary family choice: `worker-pool-constructor-family-v0.md`.
- Exact family-local parameter schema: `worker-pool-parameter-schema-v0.md`.
- Exact sponsor-import contract: `worker-pool-sponsor-surface-v0.md`.
- Exact invocation-manifest contract: `worker-pool-invocation-manifest-v0.md`.
- Exact control-handle contract: `worker-pool-control-surface-v0.md`.
- Exact install-target contract: `worker-pool-install-target-surface-v0.md`.
- Exact seed-import contract: `worker-pool-seed-surface-v0.md`.
- Exact worker-entry contract: `worker-pool-worker-surface-v0.md`.
- Evidence contract: `docs/40-verification/worker-pool-constructor-harness-v0.md`.
- Reused seams: **CH-EXECPACK v2**, **D-BUDGET**, **D-SEAL**, **D-CAPAUD**, **D-COMMUTE**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-REALMS**, **REF-FUCHSIA-COMPONENTS**, **REF-GENODE-INIT**, **REF-EROS-CONFINEMENT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_invocation.py` (**EVID-2026-360**).
