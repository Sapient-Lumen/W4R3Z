# D-VOLITION posture v0 (fresh, local-only gesture evidence; no batch/cached approvals)

Purpose: pin an **implementable Phase 1** meaning for D-VOLITION so “trusted UI gesture evidence” stays a small, reviewable seam.
It narrows a slippery area into one thing: **fresh evidence that a human approved one exact summary for one exact action on the local trusted UI path**.

This doc is intentionally narrow: it does **not** design a remote signing protocol, a delegated approval cache, a biometric/passkey identity framework, or a general cross-session authorization ticket.

## Posture (v0)

1) **CH-VOL is evidence, not authority**
   - If D-VOLITION is enabled, CH-VOL remains **additional gesture evidence** consumed by IF-CONSENT.
   - CH-VOL never substitutes for CH-AUTHZ, never replays as a grant, and never travels as a bearer token in place of approval.
   - The seam stays fail-closed: invalid/missing CH-VOL can only narrow/deny a flow that requires volition.

2) **One gesture, one action digest, one summary digest**
   - A Phase 1 CH-VOL binds exactly one `action_digest` and one `summary_digest`.
   - There is **no wildcard or batch approval** semantics in v0: one token does not approve “this class of future actions”, “anything from this app for 10 minutes”, or “all actions matching this summary profile”.
   - Freshness is per-token and one-shot within the replay window.

3) **Local trusted-path only; not export/import material**
   - CH-VOL is **local trusted-UI-path evidence**, not a portable cross-host/cross-session artifact.
   - Phase 1 does **not** use CH-VOL as a handoff object for CH-PLUMBMSG, CH-WALLET, CH-SREF, Foreign Cells, or any remote workflow.
   - If a profile is headless or remote-only, it should disable D-VOLITION rather than simulate it with a fake local token.

4) **Current-session bound; no restore/cached approval reuse**
   - `ui_session_id` / `ui_context` exist to keep the evidence tied to the **current UI session** / secure UI session when the profile uses them.
   - Phase 1 does **not** claim session-restore, reboot-restore, or background reuse semantics for CH-VOL.
   - “Approve once, silently reuse later” is out of scope for CH-VOL v0.

5) **Summary is canonical and shell-owned**
   - The bound `summary_digest` comes from the canonical consent summary actually rendered by the trusted UI path.
   - Requester prose/hints may decorate the prompt, but they do **not** determine the bound summary or widen the approval.
   - High-risk prompts stay shell/UI-root owned; apps/agents do not supply their own approval surface and call it volition.

6) **Biometric/passkey style factors remain action-bound inside the prompt**
   - `gesture_kind` may include `click`, `hold`, `biometric`, or other policy-allowlisted factors.
   - In Phase 1, those factors still only prove a gesture for the exact `(action_digest, summary_digest)` pair shown by the trusted UI.
   - Successful biometric/passkey verification does **not** become a general reusable approval cache, capability transport, or ambient “user is present, therefore allow” shortcut.

7) **Fresh volition is required for re-prompts and authority widening**
   - If a workflow changes the action digest, changes the shown summary, or widens authority after the user saw the prompt, the old CH-VOL no longer applies.
   - Notification actions, capture escalation, high-risk automation injection, secret release, and similar flows must obtain a **fresh** CH-VOL whenever policy says they are volition-gated.
   - Post-render swaps and overlay/clickjacking attempts fail closed.

8) **Sealed compat remains non-ambient**
   - Foreign Cells and compat shims may trigger consent workflows only through explicit portals / IF-CONSENT.
   - They do not get ambient access to a UI-root signing service, synthetic CH-VOL constructors, or approval-cache side channels.

## Phase 1 non-goals (explicitly deferred)

- **No wildcard / batch approvals** under CH-VOL.
- **No export/import / remote handoff semantics** for CH-VOL.
- **No session-restore or “approve once, reuse later” cache semantics** in CH-VOL.
- **No claim that biometrics/passkeys replace IF-CONSENT or CH-AUTHZ**.
- **No hidden app-owned consent surface** that can mint CH-VOL outside the trusted UI path.

## Wiring

- Decision surface: `decision-map.md` (D-VOLITION).
- Schemas:
  - `volition-token-schema-v0.md` (CH-VOL v0)
  - `consent-receipt-schema-v0.md` (CH-RECEIPT v0)
  - `capability-diff-schema-v0.md` (CH-CAPDIFF v0)
- Interface/control surfaces:
  - `interface-registry.md` (IF-CONSENT)
  - `uicap-scope-posture-v0.md` (secure UI / SAS posture adjacency)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-CONSENT-1, I-VOLITION-1, I-VOLITION-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-VOL-VALIDATE, PO-VOL-NOREPLAY, PO-VOL-LOCAL)

CI drift gate:
- `tools/check_volition_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **fresh/local-only/no batch-or-cached approvals** constraints, or drops its primary REF wiring.

## References

- REF-EROS-EWS-SEC04.
- REF-MS-WINLOGON-SAS.
- REF-WEBAUTHN-3.
- REF-ANDROID-BIOMETRICPROMPT.
