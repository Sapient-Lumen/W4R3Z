# Architecture overview (candidate shapes)

This document describes competing architecture shapes without committing. Decisions are recorded as ADRs.

## Candidate A: hypervisor-first micro-hypervisor core
Core enforces CPU+memory partitioning (virtualization), exposes minimal resource + capability API; services run outside root.

## Candidate B: microkernel-first
Classic microkernel mechanisms first; virtualization later as extension (risk: TCB growth, proof churn).

## Candidate C: separation-kernel-first
Static partitions for early assurance; add dynamism later only with explicit proof budget.

Concrete seam: D-PART with CH-PART policy artifact (RFC-0021).

## Mechanism set (must stay minimal)
- domains/VMs, threads/vCPUs
- capability/object model
- mapping operations
- IPC primitive(s)
- interrupt routing primitives

## Open questions
See `decision-map.md`.

## Canonical deep-dives (keep small)
- Capability semantics: `capability-semantics.md`
- Privileged surface budget: `exit-surface-budget.md`
- Hypervisor-first analysis: `hypervisor-first-evaluation.md`
