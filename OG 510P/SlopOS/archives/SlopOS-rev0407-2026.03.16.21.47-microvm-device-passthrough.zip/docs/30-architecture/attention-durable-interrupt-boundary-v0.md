# Attention durable-interrupt boundary v0 (keep CH-NOTIF ephemeral)

Purpose: resolve **OQ-0005** by freezing what urgent notifications are allowed to mean in Phase 1 and pre-committing where any future durable interruption semantics may live.

This is intentionally a **boundary** doc, not a new schema. It exists to keep `portal.attn.*` small, killable, and reviewable while still leaving room for a future stronger interrupt surface *outside* CH-NOTIF if we ever truly need one.

## Decision (v0)

1) **CH-NOTIF stays ephemeral**
   - CH-NOTIF `kind="post"` / `kind="withdraw"` remains an upsert-withdraw request seam for notifications.
   - CH-NOTIF `importance="urgent"` remains an **advisory hint only** under local policy. It is not a durable grant, not a lease, and not a capability.

2) **No in-place widening of CH-NOTIF into interruption authority**
   - Privileged code MUST NOT reinterpret CH-NOTIF fields, delivery success, channel defaults, or user-visible prominence as implicit TTL/renew/revoke semantics.
   - CH-NOTIF MUST NOT become an ambient wake, relaunch, bypass-Focus, bypass-mute, or keep-alerting authority surface by policy convention alone.
   - Duplicate suppression keyed by CH-NOTIF `.id` remains a request hygiene rule, not proof of durable interrupt rights.

3) **If stronger interrupt semantics are ever needed, they live outside CH-NOTIF**
   - Any future durable interruption surface (TTL, renewal, revocation, privileged review, or stronger delivery semantics) MUST be introduced as a **separate RFC-first descriptor/lease surface** with its own consent, policy, and revocation rules.
   - That future surface may be *referenced by digest* from workflows, but it does not get to retroactively change what CH-NOTIF v0 meant.

4) **Any future durable surface stays non-ambient and policy-killable**
   - A stronger interrupt surface still MUST be explicit-route only, tied to local policy, and killable by configuration/profile.
   - It MUST NOT imply background execution, durable capability export, or an app-visible inventory/search surface.
   - Notification actions remain under D-VOLITION / D-EXPLAIN regardless of urgency.

## Why this boundary exists

- **Keeps D-ATTN honest**: interruption review remains separate from notification formatting and delivery.
- **Prevents semantic drift**: “urgent” stays a small policy hint instead of becoming a hidden lease.
- **Preserves future flexibility without forked meaning**: if SlopOS ever needs a stronger interrupt product shape, it can pay for one explicit surface instead of mutating old transcripts and receipts.

## Imported ecosystem pattern

- **XDG Desktop Portal Notification** exposes a simple send/withdraw portal rather than a durable interruption lease surface.
- **Android notification channels** make interruption level an explicit policy/user-setting concept, not a portable grant embedded inside each notification payload.
- **Apple critical alerts** require explicit entitlement/review for the stronger interrupt class rather than treating ordinary notification urgency as sufficient.

We import the pattern, not the whole ecosystem: **stronger interruption semantics, if any, must be a separately reviewed surface; CH-NOTIF stays a small request seam**.

## Consequences

- CH-NOTIF v0 stays stable and easy to lint.
- `attention-lease-posture-v0.md` remains the Phase 1 posture doc; this boundary just retires the remaining “maybe lease later” ambiguity.
- Any future durable interrupt work must pay for a distinct RFC, schema/descriptor surface, and evidence rather than widening `importance="urgent"` in place.

## Wiring

- Decision surface: `decision-map.md` (D-ATTN).
- Current posture: `attention-lease-posture-v0.md`.
- Schema surface: `notification-request-schema-v0.md` (CH-NOTIF v0).
- History: `rfcs/0055-attention-authority-and-notifications.md`.
- Trajectory resolution: `docs/00-meta/trajectory-map.md` (retired OQ-0005).
- CI drift gate: `tools/check_attention_durable_interrupt_boundary.py` (EVID-2026-268).

## References

- REF-XDG-PORTAL-NOTIFICATION
- REF-ANDROID-NOTIF-CHANNELS
- REF-APPLE-CRITICAL-ALERTS
