# CH-IFACE v0: interface descriptor (optional)

Purpose: a small, canonical artifact that binds an *interface identity* to the concrete artifacts needed to safely use and evolve it.

This is not an ABI by itself; it is a **pin** that lets the ecosystem talk about “the interface” in a stable way across:
- D-IDL (codegen and dispatch),
- D-CONTRACT (protocol FSM checks, when used),
- D-CAPRPC (wire framing via `iface_digest`),
- D-ATOMICUPD (upgrade gates and adapters).

Constraint: closed-world, canonical encoding (I-ENC-1). Unknown keys/variants reject.

## Shape

```text
CH-IFACE-v0 {
  schema: "CH-IFACE";
  version: 0;

  # Human label (non-authoritative)
  name: tstr;                    # bounded; e.g., "fs.vfs" or "net.dns"

  # Primary identity: the digest that appears on the wire.
  # In D-CAPRPC, this is carried in CH-CAPRPC.iface_digest.
  iface_digest: bytes32;         # MUST equal digest(canonical_bytes_of_this_object)

  # Concrete definition pins
  idl_digest?: bytes32;          # digest of the pinned IDL input for codegen (D-IDL)
  contract_digest?: bytes32;     # digest of CH-CONTRACT spec (D-CONTRACT), if used

  # Evolution policy
  openness: enum { closed, open };      # closed = fail on unknown method/op; open = allow safe extension
  unknown_method: enum { error, close };# for open interfaces: return a framework error vs close channel

  # Compatibility breadcrumbs
  supersedes?: list<bytes32>;    # predecessor iface_digests (for upgrade tooling)
  notes_tag?: tstr;              # bounded; ignored by validators
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `iface_digest` must be exactly 32 bytes and **must match the digest of the canonical bytes** of this CH-IFACE object.
- If present, `idl_digest` and `contract_digest` are exactly 32 bytes.
- `supersedes` length ≤ 16 (default bound).
- `name` and `notes_tag` are bounded strings and are non-authoritative.

## Intended use
- **Bind RPC calls to an interface**: CH-CAPRPC carries `iface_digest` so receivers can deterministically decide whether they support the interface.
- **Upgrade-time checks**: tooling can refuse upgrades where a required interface digest disappears without an explicit adapter.
- **Compatibility policy**: `openness/unknown_method` makes forward-compat posture explicit (see D-APIEVO).

- **Open interface families**: for CH-IFACE.openness=`open`, it is often preferable to **omit** `idl_digest` so that `iface_digest` can remain stable as new methods are added. In this posture, the evolving definition is pinned per release via `idl_digest` in codegen artifacts (e.g., CH-ORD) while the on-wire identity stays constant.

## Non-goals
- Not a full interface registry (method lists/signatures live in IDL artifacts under D-IDL).
- Not a naming system (names are non-authoritative; use D-NAMECERT for delegation/naming).
