# Serialization boundary token registry (v0; closed)

Purpose: pin a **closed, reviewable vocabulary** for where correctness-required serialization lives for **ordered** privileged actions.

This registry is a stable diff surface used by D-COMMUTE/Hybrid evidence:
- the ACP kind registry (`docs/70-llm-control/acp-action-kind-registry.md`) records a per-kind **Serialization boundary** token,
- validators and test harnesses treat that token as a *fact* about where ordering is enforced,
- CI drift gates ensure token usage remains **registry-closed** (no typo’d/implicit boundaries).

Rules:
- Ordered kinds MUST use `validator` or a `svc:<name>` token from this table.
- Non-ordered kinds MUST use `none` (and MUST NOT name any `svc:*` boundary).
- The token set is closed; changes require an RFC + updates to ACP kind metadata and evidence hooks.

## Token registry

| Token | Meaning | Used by (seed) |
|---|---|---|
| `validator` | serialization is enforced inside the deterministic validator | `cfg.set_policy` (and other purely-validator-serialized kinds) |
| `svc:IF-CFG` | configuration service boundary (IF-CFG owner) | `cfg.set_policy` |
| `svc:IF-KABI` | kernel ABI/service boundary (IF-KABI owner) | `domain.quarantine` |
| `svc:IF-CAPSHELL` | capshell runner boundary (IF-CAPSHELL owner) | `capshell.exec` |
| `svc:view` | view/namespace service boundary | `view.attach`, `view.detach` |
| `svc:portal.attn` | attention/notification portal service boundary | `portal.attn.request` |
| `svc:portal.clock` | clock/time portal service boundary | `portal.clock.timeproof.sample` |
| `svc:portal.net` | network portal service boundary | `portal.net.request` |
| `svc:portal.entropy` | entropy portal service boundary | `portal.entropy.request` |
| `svc:portal.jobs` | jobs portal service boundary | `portal.jobs.submit` |
| `svc:portal.background` | background/autostart portal service boundary | `portal.background.request` |
| `svc:budget` | metering/budget service boundary | `budget.mint` |
| `svc:fcell` | Foreign Cell supervisor boundary | `fcell.launch`, `fcell.kill` |
| `none` | no correctness-required serialization boundary (kind is not ordered) | `cap.grant` |

## CI drift gate

`make lint` runs `tools/check_acp_serialization_boundary_registry.py` to enforce that the ACP kind registry uses only the tokens above.
