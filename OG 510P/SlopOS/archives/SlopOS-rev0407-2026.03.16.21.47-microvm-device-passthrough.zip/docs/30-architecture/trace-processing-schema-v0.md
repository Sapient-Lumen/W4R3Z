# CH-TRACEPROC v0: Trace processing request (schema)

> NOTE: This v0 schema remains supported for compatibility. New deployments should prefer **CH-TRACEPROC v1**, which adds an explicit optional CH-TPRED prefilter reference (see RFC-0073).


Purpose: install/remove/configure **user-space** trace processors that consume CH-TRACE records and emit bounded, redaction-safe outputs.
This is a *control-plane* request for a mediated trace portal/supervisor; it does not itself grant authority.

Design stance:
- no in-kernel scripting
- processors run in an untrusted sandbox (typically Wasm; D-WASM)
- strict bounds and deterministic failure behavior

Refs: REF-DTRACE, REF-EBPF-INTRO, REF-WASM-CM-INTRO.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-TRACEPROC v0 := {
  v: 0,

  kind: tstr,                  ; closed enum: "install" | "remove" | "update"
  id: bstr,                    ; caller-chosen stable id (scoped to origin)

  ; which trace events this processor may receive
  probes: [ tstr ],            ; bounded list of tracepoint ids (profile-defined names or numeric tags)

  ; processor payload (required for install/update)
  proc?: {
    kind: tstr,                ; closed enum: "aref" | "handle"
    ref: bstr,                 ; digest(CH-AREF) or opaque handle id (policy-defined)
  },

  ; resource bounds (portal may clamp)
  limits?: {
    cpu_ms_per_s?: uint,       ; optional per-second CPU budget
    mem_bytes?: uint,          ; optional memory cap
    out_bps?: uint,            ; optional output byte rate cap
    max_state_bytes?: uint,    ; optional cap on processor-maintained state
  },

  ; output discipline hints (policy may ignore)
  output?: {
    kind: tstr,                ; closed enum: "counters" | "summaries" | "digests"
    max_items?: uint,          ; bound on distinct keys/items per window
    max_value_bytes?: uint,    ; bound on any emitted value
  },

  ttl_s?: uint,                ; optional time-to-live; portal may clamp or ignore

  meta?: { * tstr => any }     ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `kind` is in the closed set; unknown kinds reject deterministically.
3) bounds enforced:
   - `probes` length bounded
   - `id` length bounded
   - `limits` values clamped/rejected if out of policy range
4) if `kind in {"install","update"}`, `proc` MUST be present.
5) `proc.kind` must be allowlisted by policy; `proc.ref` must be well-formed:
   - if `aref`, portal MUST verify referenced digest matches the loaded artifact (PO-AREF-VERIFY).
6) output settings are hints; portal enforces the actual export/redaction policy (I-OBS-1).

## Notes
- A trace processor is *not* a privileged extension. It is an untrusted computation over observation streams.
- For deterministic testing/replay, record (proc_digest, config_digest) alongside traces when relevant.
