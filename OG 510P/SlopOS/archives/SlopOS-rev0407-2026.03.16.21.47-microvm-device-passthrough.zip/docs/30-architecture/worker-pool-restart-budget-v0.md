# Worker-pool restart-budget semantics v0 (exact `restart.max_restarts` / `restart.window_ms` meaning)

Purpose: pin an implementable Phase 1 meaning for the per-slot automatic replacement budget already carried by **CH-WPOOLPARAM v0** so the first concrete **D-CONSTR** family does not drift into hidden supervision folklore, pool-wide crash scores, or implementation-defined reset rules.
This doc narrows one already-chosen seam: **the restart budget is a slot-local admission rule for automatic replacement, not a portable timer API, admin surface, or second health model**.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-QUIESCE**, **D-COMMUTE**, **D-CAPRPC**, **D-CAPAUD**
- assumes the exact family-local parameter object is already fixed by `worker-pool-parameter-schema-v0.md`
- assumes the exact `worker_slots[*].state` vocabulary is already fixed by `worker-pool-slot-state-v0.md`
- assumes the exact pool-level `quiesce_state` meaning is already fixed by `worker-pool-quiesce-state-v0.md`
- assumes the exact bounded `Describe()` result shape is already fixed by `worker-pool-describe-summary-v0.md`
- does **not** introduce a generic supervision schema, a portable backoff timer API, or any new mutator beyond the existing constructor/control seams

## Phase-1 choice

1) **The restart budget is a per-slot sliding admission budget, not a pool-wide health score**
   - `restart.max_restarts` and `restart.window_ms` are evaluated independently for each slot `i`.
   - The budget counts only automatic replacement admissions for that slot: each automatic `backoff -> starting` re-entry appends one admission timestamp to the slot-local sliding window.
   - The initial constructor-created occupant for a fresh pool slot does **not** consume restart budget.
   - Phase 1 adds no pool-wide burst counter, no cross-slot sharing of restart budget, and no summary-level crash score.

2) **`restart.max_restarts = 0` and `restart.window_ms = 0` disable automatic replacement exactly**
   - This disabled form is already required by `worker-pool-parameter-schema-v0.md`.
   - When automatic replacement is disabled, occupant loss or failed bring-up for a slot transitions directly to `failed` for that pool instance.
   - A disabled slot therefore does **not** enter `backoff`, schedule hidden retry work, or retain a latent restart queue behind `pool.control`.

3) **Positive restart budgets admit replacement only while the sliding window remains within budget**
   - If `restart.max_restarts > 0`, the slot MAY re-enter `starting` automatically only when the count of slot-local automatic restart admissions in the trailing `restart.window_ms` is strictly less than `restart.max_restarts`.
   - If the next automatic admission would exceed that bound, the slot transitions to `failed` for the lifetime of the current pool instance.
   - Successful long-running occupancy does not reset the budget by side channel; prior admissions age out only by leaving the trailing `restart.window_ms` window.

4) **`backoff` is budget-eligible temporary unavailability, not a portable timer surface**
   - A slot may report `backoff` only while automatic replacement is still eligible under the current budget.
   - Phase 1 does **not** standardize exponential delay curves, jitter policy, next-retry timestamps, or portable restart-cause taxonomies.
   - Hosted or native implementations MAY choose internal retry timing however they like, but they must not expose that timing on the canonical `Describe()` surface.

5) **Active quiesce gates readmission but does not refund or reset budget**
   - If a pool `qid` is active, automatic `backoff -> starting` re-entry remains suppressed exactly as pinned in `worker-pool-slot-state-v0.md`.
   - Time may continue to pass while the slot is quiesce-gated, so older admissions may naturally age out of the trailing `restart.window_ms` window.
   - `BeginQuiesce(mode)` and `EndQuiesce(qid)` do **not** clear restart history, refund spent admissions, or mint a new slot-local restart epoch.

6) **Observation stays bounded and non-diagnostic on the portable summary surface**
   - `pool.control.Describe()` continues to expose only the exact `worker_slots[*].state` tokens plus the bounded pool-level fields already fixed elsewhere.
   - The canonical summary does **not** expose restart counters, next retry time, failure reason taxonomies, crash digests, or per-slot retry schedules.
   - Richer crash/retry detail stays on explicit logs/evidence/diagnostic seams rather than hitchhiking on the family-local control handle.

7) **Commutativity and serialization remain where they already live**
   - Restart-budget evaluation is internal to one pool instance and does not introduce a new constructor-global conflict-key family.
   - External non-commutativity remains on the existing pool-control seam (`BeginQuiesce(mode)` / `EndQuiesce(qid)`) and any existing install target seam, not on a new restart-admin interface.
   - Evidence stays on slot-state outcomes, transcripts, and the existing confinement/replay bundle rather than on a new restart ledger surface.

8) **Sealed compat remains honest**
   - Hosted or compat implementations MAY realize restart timing and process supervision differently behind the membrane.
   - The portable contract still stays the same narrow rule set above: per-slot sliding admission budget, no pool-wide crash score, no portable retry timer surface, and no quiesce-driven budget reset.
   - If an implementation cannot provide that posture without ambient host supervisor state leaking onto `Describe()` or `worker[i]`, it must fail closed or keep that widening non-portable and policy-killable.

## Out of scope in v0

- A portable restart-delay / jitter / exponential-backoff schedule.
- Pool-wide restart-intensity semantics or supervisor trees exposed on `pool.control`.
- Manual per-slot restart verbs or any restart counter reset operation.
- Portable failure-reason taxonomies, crash digests, or retry timestamps on the canonical summary surface.
- Any claim that slot restart history is itself a durable evidence artifact.

## Wiring

- Decision surface: **D-CONSTR**.
- Adjacent seams: `worker-pool-constructor-family-v0.md`, `worker-pool-parameter-schema-v0.md`, `worker-pool-slot-state-v0.md`, `worker-pool-quiesce-state-v0.md`, `worker-pool-describe-summary-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-worker-surface-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-ERLANG-OTP-PRINCIPLES**, **REF-SYSTEMD-SERVICE**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_restart_budget.py` (**EVID-2026-376**).
