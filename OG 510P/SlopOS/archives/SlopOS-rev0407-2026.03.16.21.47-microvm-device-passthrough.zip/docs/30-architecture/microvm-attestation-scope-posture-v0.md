# MicroVM attestation-scope posture v0 (fresh attestation stays boot/provenance-bound, not warm-state identity)

Purpose: pin the **Phase 1** claim boundary between `ext.microvm` warm-start restore and **D-ATTEST / D-CC** so a fresh post-restore attestation export does not quietly become a proof of the exact resumed warm-state leaf.

This doc attaches to **D-MICROVM**, **D-ATTEST**, **D-CC**, **D-INITSNAP**, and **D-CHKPT** and makes one hard decision explicit:
**after clone/restore, fresh attestation remains a proof about the current boot/provenance lineage and freshness binding; it is not, by itself, a portable proof of the exact resumed warm-state leaf or snapshot memory image.**

Entropy cost justification: the archive already pins that warm restore is not continuity, that one explicit generation witness exists, that attestation freshness is reacquired after generation change, and that reusable templates are parent-bound leaves. What is still missing is the scope boundary that keeps those decisions from collapsing into “a fresh quote proves the resumed template leaf.” One narrow posture closes that gap without introducing a new schema family, verifier protocol, or compatibility surface.

## Posture (v0)

1) **Fresh post-restore attestation stays boot/provenance-bound**
   - Phase 1 literally pins that **fresh post-restore attestation stays boot/provenance-bound** rather than widening into a portable resumed-memory claim.
   - `CH-ATTEST` / `CH-ATTESTPACK` remain bound to `digest(CH-BOOT)` and optional provenance bindings exactly as pinned by `attestation-posture-v0.md` and RFC-0064.
   - After generation-witness change, a fresh attestation exchange may prove that the currently running guest instance is freshly responding for the admitted **boot/provenance lineage**.
   - That fresh export does **not** by itself prove that the resumed guest memory equals one exact reusable warm-start leaf, diff chain, or owner-local checkpoint image.

2) **Warm-state leaf identity is separate explicit evidence**
   - If policy cares about **which reusable warm-start leaf** or recovery artifact was resumed, that identity/admission must travel on a separate explicit evidence seam — for example the parent-bound template lineage, admitted leaf identifier, deployment/CH-BOOT root, local restore receipt, or equivalent owner-reviewed provenance.
   - Remote verifiers and secret-release policy MUST NOT infer exact resumed leaf identity solely from a fresh `CH-ATTEST` export, even when the measured boot lineage is unchanged.
   - In plain terms: attestation can say “this boot lineage is fresh/current again”; it cannot silently say “this exact post-init warm-state leaf was resumed” unless some separate evidence contract says so.

3) **Vendor/runtime measurement richness stays adjunct, not portable warm-state meaning**
   - Platform-specific measurement registers or event logs may exist and may be carried as opaque/provider-specific evidence in `CH-ATTESTPACK` or related external artifacts.
   - Phase 1 does **not** standardize a cross-provider rule that such adjuncts prove one exact resumed warm-start leaf, diff/base merge result, or restored memory image under `ext.microvm`.
   - Any stronger resumed-state attestation meaning would require its own explicit schema/verification surface and evidence plan rather than being inherited from existing `CH-ATTEST` semantics.

4) **Snapshot/template artifact trust stays on deployment/provenance seams**
   - Reusable template leaves, memory files, and snapshot packaging inputs remain deployment/provenance artifacts whose admission is governed by the owner-local lineage/admission policy already pinned elsewhere in the archive.
   - They MUST NOT be treated as magically covered by remote attestation just because the guest can later export a fresh quote/report/token.
   - This keeps Firecracker-style snapshot artifact trust, template lineage, and restore admission separate from remote attestation semantics.

5) **No new ambient verifier or guest-management plane**
   - Phase 1 adds **no new `CH-*` field** to overload `CH-ATTEST` with leaf identity, **no new ACP kind**, **no new conflict-key family**, and **no new host↔guest callback plane** for “verified warm-state restore”.
   - If a later design wants portable resumed-state attestation or verifier-visible template identity, it must pay an RFC-first cost with explicit schema, conflict/ordering semantics, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable resumed-memory or post-init template-leaf attestation schema.
- No claim that all providers expose equivalent runtime measurement semantics.
- No generic verifier policy language for template-leaf identity.
- No host-side snapshot packaging or signing protocol specified here.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-ATTEST, D-CC, D-INITSNAP, D-CHKPT)
- Adjacent postures:
  - `attestation-posture-v0.md`
  - `microvm-attestation-reacquire-posture-v0.md`
  - `microvm-resume-admission-evidence-posture-v0.md`
  - `microvm-template-lineage-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `microvm-restore-repair-barrier-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
  - `rfcs/0064-confidential-computing-profile.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-9)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-ATTEST-SCOPE)
- Policy posture:
  - fresh attestation after restore adds **no new lane**, **no new portable leaf-identity claim**, and **no new verifier/control plane** in Phase 1.

CI drift gate:
- `tools/check_microvm_attestation_scope_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fresh attestation stays boot/provenance-bound / exact resumed leaf identity is separate explicit evidence / no new CH-ATTEST field or portable resumed-state attestation plane** constraints, or drops its assurance/reference wiring.

## References

- REF-AWS-SNP-ATTEST.
- REF-LINUX-TDX.
- REF-INTEL-TDX-TDVF-MEASUREMENT.
- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
