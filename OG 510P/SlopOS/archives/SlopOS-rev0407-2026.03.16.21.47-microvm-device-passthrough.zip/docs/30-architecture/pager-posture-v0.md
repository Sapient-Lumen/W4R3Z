# D-PAGER posture v0 (object-backed fault routing only; no per-AS vaddr pagers)

Purpose: pin an **implementable Phase 1** meaning for **D-PAGER** so user-mode paging stays a
small, auditable **object-backed fault-routing seam** instead of drifting into a generic
per-address-space exception-upcall model, a hidden writeback subsystem, or an ambient self-paging
story.

This posture deliberately chooses the narrower branch of the RFC: when `ext.user_mode_pager` is
on, Phase 1 means **declared pager-backed memory objects** with explicit pager endpoints and
bounded **CH-FAULT v0** requests that identify an object + offset. Generic per-address-space fault
handlers, virtual-address-bearing fault IPC, and mutable writeback lifecycles stay future work.

## Posture (v0)

1) **Phase 1 D-PAGER is for declared pager-backed memory objects only**
   - `ext.user_mode_pager` means selected memory objects may be backed by an explicit user-space pager service.
   - The portable v0 seam is **object-backed**: fault requests identify the backed object and offset/length rather than a process-global “current fault address”.
   - Phase 1 does **not** define a generic per-address-space pager/exception-handler install surface for arbitrary anonymous memory or language-runtime traps.

2) **Fault routing minimizes address-space disclosure**
   - **CH-FAULT v0** is the bounded kernel→pager request surface.
   - In the pinned v0 posture, emitted fault requests use the **`object.vmo`** form only; the `object.as` / raw-virtual-address shape is reserved for any future per-address-space pager profile and must not be emitted in Phase 1.
   - The kernel may attach only the one-shot out-of-band reply capability for this fault; Phase 1 does not add thread-register snapshots, generic signal payloads, or a pager-visible process-memory inventory.

3) **Pager authority is explicit and non-amplifying**
   - A pager may resolve a fault only by using **existing explicit authority** to map/grant the relevant backing object into the target address space.
   - The fault message itself is not mapping authority; it is a bounded request plus a one-shot completion token.
   - This posture is the operational meaning of **I-PAGER-1** and must satisfy **PO-PAGER-ROUTE** without creating a second hidden memory-management control plane.

4) **Read-mostly backing first; no writeback lifecycle in v0**
   - Phase 1 D-PAGER is optimized for immutable/read-mostly objects such as cacheable file/image content, verified blobs, and decompression-aware backing stores.
   - Dirty-page tracking, writeback scheduling, pager-issued persistence guarantees, and mmap-style mutable file semantics are **out of scope** for the portable v0 seam.
   - If we later need mutable pager-backed objects, that must return as a separate RFC/ADR-backed profile slice rather than quietly widening CH-FAULT or `ext.user_mode_pager` in place.

5) **No pager inventory, install/watch API, or hidden fallback pager**
   - Phase 1 does **not** expose a generic “list installed pagers”, “watch faults”, or “set this task’s pager” API.
   - Pager attachment remains a property of explicit object construction / launch wiring and policy, not an ambient runtime mutation surface.
   - The kernel must not silently fall back to a default pager, hidden kernel filesystem cache, or best-effort page supplier when explicit pager routing is missing or denied.

6) **DoS and side-channel costs stay visible and profile-gated**
   - Because pager services sit on the fault path, bounded queues, fail-closed overflow behavior, and explicit budgeting/metering remain required companions when `ext.user_mode_pager` is enabled.
   - Profiles that need stricter side-channel posture should prefer the default kernel-only paging posture or keep D-PAGER narrowly scoped to object-backed datasets that justify the leakage budget.
   - “Self-paging” by arbitrary applications remains a future/profile experiment only; Phase 1 does not turn every process into its own pager.

## Phase 1 non-goals (explicitly deferred)

- No generic per-address-space pager / exception-handler installation surface.
- No emitted `object.as` / raw-virtual-address **CH-FAULT v0** requests in the portable posture.
- No mutable writeback / dirty-page lifecycle or mmap-style persistence contract.
- No arbitrary app/language-runtime self-paging profile in Phase 1.
- No pager inventory / list / watch / admin plane, and no hidden fallback pager.

## Wiring

- Decision surface:
  - `decision-map.md` → **D-PAGER**.
- Core semantics / narrative:
  - `fault-message-schema-v0.md`.
  - `mechanisms.md`.
  - `schema-registry.md`.
- Profile / deployment surfaces:
  - `config-toggle-registry.md` (`ext.user_mode_pager`).
  - `profile-feature-flag-defaults.md`.
  - `docs/10-threat-model/deployment-profiles.md`.
- Related RFC / adjacent seams:
  - `rfcs/0044-user-mode-paging-and-external-pagers.md`.
  - `rfcs/0114-verified-blobs-and-merkle-integrity.md`.
  - `nondet-posture-v0.md`.
- Assurance hooks:
  - Invariants: **I-PAGER-1**, **I-MAP-1**, **I-CAP-1**.
  - Proof obligations: **PO-PAGER-ROUTE**.
- Discovery / amnesia-resistor surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/resolved-history.md`.
- CI drift gate: `tools/check_pager_posture.py` (**EVID-2026-353**).

## References

- REF-FUCHSIA-PAGER
- REF-FUCHSIA-BLOBFS-RAC
- REF-FUCHSIA-RFC-0226
- REF-L4RE-DS-RM
- REF-MACH-EXTPAGER
- REF-NEMESIS-SELFPAGING
