# CH-FLIGHTPOL v0 (flight recorder retention policy schema, informal)

Purpose: a pinned, bounded policy artifact describing **flight recorder retention**:
- which observation streams are retained,
- ring-buffer bounds (bytes/segments/age),
- whether retention is volatile or persisted locally,
- which triggers produce incident captures (CH-SNAPSHOT).

This schema is intentionally **not** a scripting language and is not a general DLP policy.
Export/sharing remains gated by CH-OBSPOL and explicit workflows (D-EXPLAIN).

Refs: REF-LINUX-RAMOOPS, REF-LINUX-PSTORE, REF-MS-ETW, REF-SYSTEMD-JOURNALD.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded size/cost (validation must be cheap)
- closed sets (stream kinds, trigger kinds, persistence modes)
- no authority-bearing secrets (policy is descriptive, not an authorization token)

## Shape (v0)
A flight recorder policy `p` contains:
- `schema`: fixed `CH-FLIGHTPOL v0`
- `policy_id`: bounded identifier (string)
- `obspol_digest?`: optional digest binding to the active CH-OBSPOL used for redaction/scope decisions
- `streams`: bounded list of retained stream specs
- `triggers`: bounded list of trigger rules
- `bounds`: explicit caps on evaluation cost and on persisted storage usage

### streams[].kind (closed)
- `log`      ; structured logs/observations (CH-LOG/CH-OBS)
- `trace`    ; selected trace streams (CH-TRACE), typically filtered by CH-TPRED
- `inspect`  ; periodic or on-trigger inspect snapshots (CH-INSPECT)
- `rr`       ; optional record/replay stream segment retention (CH-RR), only if enabled

### streams[].retention
- `max_bytes`: uint (required) — ring capacity for this stream
- `max_segments`: uint (required) — cap on segment count
- `max_age_ms?`: uint — best-effort age bound; interpreted relative to a referenced clock kind
- `persist`: mode (closed)
  - `volatile` (default): RAM only
  - `persistent_local`: bounded local store (requires an explicit store quota)
  - `crash_survivor`: reserved region intended to survive reboot (pstore-like), optional and high-risk

### streams[].filters (optional)
- `tpred_digest?`: digest(CH-TPRED) for trace/log field predicates (if used)
- `allow_kinds?`: bounded allowlist of event kinds/categories (closed per stream type)

### triggers[].kind (closed)
- `component_crash`
- `watchdog_trip`
- `operator_request`
- `test_harness`

### triggers[].capture
- `snapshot`: bool (default true) — assemble CH-SNAPSHOT manifest referencing retained segments
- `inspect_now`: bool — take a fresh CH-INSPECT snapshot as part of capture
- `rr_window_ms?`: uint — if `rr` stream exists, include at most this recent window (bounded)
- `quiesce?`: bool — if D-QUIESCE is enabled and kind permits, request cooperative quiesce before `inspect_now`

### bounds
- `max_total_persist_bytes`: uint — global cap for any persistent_local retention across all streams
- `max_capture_artifacts`: uint — cap on the number of artifact refs included in any single capture
- `overflow_policy`: closed enum `drop_oldest` | `drop_newest` | `summarize` (deterministic)

## Notes
- Volatile retention should be the default posture for early profiles.
- Persistent retention must be explicitly justified in the threat model and bound tightly.
- crash_survivor buffers should hold only minimal, redaction-safe records unless an explicit “sensitive capture” workflow is in effect.
