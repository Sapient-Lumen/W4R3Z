# Seal posture v0 (init→seal is one-way attenuation)

Purpose: pin the Phase‑1 meaning of **D-SEAL** so “init-only authority” does not become a permanent, invisible widening channel.

Many systems rely on convention (“we drop privileges after startup”). In SlopOS v0, **init→seal** is a *reviewable* posture:
- authority can only **shrink** after seal,
- any post-seal widening must be an explicit, transcript-visible reconfiguration action,
- and “self-restrict” mechanisms (CH-PLEDGE) compose as defense-in-depth rather than replacing correct capability distribution.

## Posture (v0)

1) A component/service that claims D-SEAL MUST have an explicit **init phase** followed by a **seal transition** into steady state.
2) The seal transition MUST be **one-way attenuation**: after seal, the component MUST NOT regain dropped capabilities or relax dropped restrictions except via an explicitly authorized reconfiguration action (I-SEAL-1, PO-SEAL-ONEWAY).
3) Init-only authority MUST be **dropped** at seal:
   - any capability that is not required for steady state,
   - and any **introducer** / minting authority not required for steady state (no hidden “mint later” backdoors).
4) If the component uses CH-PLEDGE v0, then:
   - the post-seal promise mask MUST be a **subset** of any init-time mask,
   - promise widening MUST be rejected (fail closed),
   - and promise violations MUST produce deterministic deny/kill outcomes at privileged-effect boundaries (CH-PLEDGE v0; D-SEAL).
5) After seal, the component MUST treat any “capability acquisition” as **input-driven only**:
   - accept/consume explicit handles/leasable descriptors from request inputs, portals, or previously declared stores,
   - and MUST NOT consult ambient/global namespaces to obtain new authority (this composes with D-CAPMODE but does not require it).
6) If the component owns or mutates view objects (D-NS), it SHOULD drop or disable view-mutation authority at seal.
   - In Phase 1, long-lived services SHOULD run with mutation disabled by default, and any reconfiguration MUST be explicit and transcript-visible.
7) If the component exports observations (D-OBS), post-seal observation export MUST remain **pull-only** and policy-killable; sealing MUST NOT implicitly enable new export channels.
8) Any action that would *increase* a component’s effective authority post-seal SHOULD be bound to an explicit receipt/diff surface (e.g., CH-CAPDIFF v0 via CH-RECEIPT) so “authority widening” remains reviewable and testable (D-EXPLAIN optional).

## Phase 1 non-goals (explicitly deferred)

- Hardware-backed sealing/attestation requirements (TPM/TEE integration).
- Global, mandatory system-wide capability-mode enforcement (D-CAPMODE may be enabled later as a profile extension).
- A standardized “seal event” schema on the wire; Phase 1 relies on component manifest pins + CH-LOG/receipts for evidence.
- Automatic “unsealing” or privilege re-escalation workflows.

## Wiring

- Decision surface: D-SEAL in `docs/30-architecture/decision-map.md`.
- Assurance anchors: I-SEAL-1 and PO-SEAL-ONEWAY in `docs/20-assurance/invariant-registry.md` and `docs/20-assurance/proof-obligation-registry.md`.
- Composition seams:
  - CH-PLEDGE v0 (`docs/30-architecture/pledge-contract-schema-v0.md`) as one-way self-restriction.
  - View mutation (D-NS) and view posture: `docs/30-architecture/view-namespace-posture-v0.md`.
  - Explainability evidence: CH-CAPDIFF v0 (`docs/30-architecture/capability-diff-schema-v0.md`) and consent receipts (CH-RECEIPT v0).
  - Component manifest pin: `seal_after_init` in `docs/30-architecture/component-manifest-schema-v0.md`.
- Discovery surfaces:
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
- CI drift gate: `tools/check_seal_posture.py` (EVID-2026-227).

## References

- REF-OPENBSD-PLEDGE
- REF-OPENBSD-UNVEIL
- REF-CAPSICUM
