# Capshell peer-inspection / dumpability posture v0 (no ambient same-principal inspectability baseline)

Purpose: keep **D-CAPSHELL** honest once exact exec selection, exact executable-object binding,
exact startup code-closure binding, fixed caller identity, normalized signal/scheduling/personality
state, and no-privilege-gain launch posture are already explicit. Those cuts are still insufficient
if the child remains ambiently inspectable by same-principal peer processes through a host-default
**dumpability / debug-attach** baseline that never appeared in the reviewed execution pack.

On Linux, the `dumpable` attribute is normally `1`; `PR_SET_DUMPABLE` can set it to `0`, which
blocks `ptrace(PTRACE_ATTACH, ...)` from ordinary peers and changes ownership of `/proc/pid`
entries. `ptrace(2)` is not passive metadata: it lets one process observe and control another, and
examine or change its memory and registers. That makes peer inspection a real authority seam rather
than harmless launcher trivia.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a reviewed
per-step debugger selector, a profiling catalog, a generic ptrace API, or a portable process-
introspection service. It only freezes the minimum Phase 1 posture needed so reviewed automation
launches under **one non-ambient peer-inspection baseline** rather than inheriting host/user-session
conventions about which sibling processes may inspect it.

## Posture (v0)

1) **No inherited shell/session peer-inspection baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit an ambient same-principal inspectability baseline merely
     because the parent shell, wrapper, login profile, service manager, compat membrane, or host
     session already runs processes in a dumpable / debugger-attachable mode.
   - Ambient launch state includes Linux `dumpable = 1`, same-user `ptrace` attachability,
     `/proc/pid` ownership/readability that follows dumpability, and equivalent host conventions
     where sibling processes may inspect child memory/register/runtime state by default.

2) **Phase 1 adds no reviewed per-step debugger / peer-inspection surface**
   - Phase 1 introduces no `capshell.exec.debug`, no ptrace/profile descriptor family, and no
     ACP/admin action family for choosing debugger attachability, dumpability, or peer-inspection
     visibility per step.
   - The portable seam is therefore: **do not carry wrapper/session peer-inspection state across the
     reviewed launch boundary**.
   - If a deployment profile needs a fixed diagnostic posture for one runtime, that remains
     provider-/membrane-local policy and MUST be independent of parent shell/session state.

3) **Launch normalizes to a non-dumpable / non-peer-inspectable baseline**
   - Before `exec` (or via equivalent spawn attributes), runners/wrappers MUST normalize the child
     to a **non-dumpable / non-peer-inspectable baseline** for the reviewed target runtime wherever
     the platform exposes such a boundary directly.
   - On Linux, that means `dumpable = 0` (or a boundary with equivalent effect on ordinary peer
     attachability and `/proc/pid` exposure), not the host default dumpable posture.
   - Compat/foreign-cell membranes that cannot guarantee that normalized posture MUST fail closed
     rather than preserving host defaults.

4) **Reviewed launch meaning excludes ambient same-principal inspection channels**
   - Reviewed `capshell.exec` meaning is "this exact exec selector / object / code closure under a
     non-ambient peer-inspection baseline", not "whatever same-user debugger / tracer / procfs
     visibility the wrapper or login session already allowed".
   - Phase 1 therefore declines any portable promise that reviewed automation may rely on ambient
     same-principal ptrace attach, register/memory inspection, or host-default `/proc` exposure
     unless a future explicit seam is introduced.

5) **Other explicit seams do not mint or repair peer inspection**
   - **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and
     **CH-REQCTX v1** do not authorize smuggling debugger attachability, profiler mode, or procfs
     visibility through unrelated fields.
   - Adjacent conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt/job-control UX, or compat adapters) MUST NOT become hidden carriers for ambient peer
     inspection.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable API for listing, probing, or granting debugger attachability,
     no reviewed report field exposing inherited dumpability, and no admin surface for toggling
     process-inspection visibility per workflow step.
   - If later evidence shows real need for a reviewed diagnostic/introspection selector, that work
     must return as **one new explicit decision surface** rather than widening `capshell.exec` by
     implication.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden wrapper/session
     peer-inspection state.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT recreate host same-user debugger lore behind the reviewed seam.
   - If a foreign runtime cannot suppress ambient peer inspection or cannot guarantee the
     non-dumpable / non-peer-inspectable baseline for the reviewed target runtime, it MUST fail
     closed rather than silently preserving host wrapper/session behavior.

## Phase 1 non-goals (explicitly deferred)

- No portable ptrace/debugger/profile selector in Phase 1.
- No generic process-inspection catalog or debugger transport.
- No portable query/report surface exposing inherited dumpability or procfs visibility.
- No promise that host-default same-user tracing / profiling behavior is available on the generic seam.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-rlimit-posture-v0.md`
  - `capshell-signalstate-posture-v0.md`
  - `capshell-personality-posture-v0.md`
  - `capshell-privgain-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-INSPECT-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-INSPECT-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_peer_inspection_posture.py` (**EVID-2026-346**).

## References

- REF-MAN7-PR-SET-DUMPABLE
- REF-MAN7-PTRACE
