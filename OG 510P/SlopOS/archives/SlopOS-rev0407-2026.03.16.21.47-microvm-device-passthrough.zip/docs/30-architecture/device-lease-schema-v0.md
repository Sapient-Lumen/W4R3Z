# DEPRECATED: CH-LEASE v0

This file was superseded to avoid ambiguity with general “lease” mechanisms.

**Use:** [CH-IOLEASE v0](io-lease-schema-v0.md) for the device/I/O lease descriptor schema.

(See `docs/00-meta/deprecations.md`.)
