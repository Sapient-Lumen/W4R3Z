# Capshell nondeterminism posture v0 (no ambient time or entropy baseline)

Purpose: keep **D-CAPSHELL** honest once workflow launch already has explicit argv/env/cwd/stdio/fdset
and explicit effect contracts. Those seams still drift if the runner quietly preserves **ambient time or
entropy authority** from the host/session/runtime: raw `clock_gettime()`-style reads, timer APIs, host wall-
clock / monotonic defaults, `getrandom()` / `/dev/urandom`-style entropy, or wrapper behavior that simply
"lets the child use the normal machine clock/RNG".

This adjunct closes that seam. It is intentionally narrow: it does **not** redesign **D-NONDET**,
standardize a timer ABI, define a portable PRNG library, or add a reviewed per-step clock / entropy policy
surface. It only freezes the minimum Phase 1 posture needed so `capshell.exec` remains capability-safe
instead of inheriting host nondeterminism lore.

## Posture (v0)

1) **No ambient time or entropy baseline at `capshell.exec` when D-NONDET is enabled**
   - A reviewed `capshell.exec` launch does **not** imply raw `clock_gettime()` / `gettimeofday()` /
     timer-style time reads, ambient host wall-clock or monotonic-clock reachability, `getrandom()` /
     `/dev/urandom`-style entropy access, or "normal machine time/RNG" as a portable baseline when
     **D-NONDET** is enabled.
   - In other words: **no ambient time or entropy baseline** is part of Phase 1 capshell launch
     semantics when D-NONDET is enabled.
   - If the active runtime or compat membrane cannot prevent ambient time/RNG access at the launch
     boundary while D-NONDET is enabled, it MUST reject/fail closed rather than silently widening child
     authority.

2) **Time/entropy behavior stays on explicit D-NONDET seams**
   - Phase 1 adds **no reviewed per-step clock / entropy surface** to CH-EXECPACK, CH-ARGV, CH-ENV,
     CH-CWD, CH-STDIO, or CH-FDSET.
   - Any portable time/entropy behavior for `capshell.exec` therefore routes only through the existing
     **D-NONDET** seams: `portal.clock` with reviewed **CH-CLOCK v0** descriptors/receipts and
     `portal.entropy` with reviewed **CH-ENTROPY v0** descriptors/receipts.
   - If a workflow does not carry the reviewed `portal.clock` / `portal.entropy` effect families,
     runners/wrappers MUST NOT conjure time/entropy authority on the child's behalf.

3) **Other execution-pack seams do not secretly mint nondeterminism authority**
   - **CH-ENV v0** may carry literal timestamps, seeds, or config strings, but env bytes alone do **not**
     grant clock or entropy authority.
   - **CH-STDIO v0** and **CH-FDSET v0** stay explicit descriptor-binding seams only; they are not a
     license to inherit host clock devices, timerfds, random devices, or helper services as an ambient
     baseline.
   - **CH-CWD v0** and **CH-ARGV v0** do not authorize host time lookup, wall-clock fallback, RNG
     discovery, or out-of-band entropy service access.

4) **Hosts with D-NONDET disabled do not create reviewed capshell semantics by accident**
   - This posture does **not** require D-NONDET to be universally enabled across all product shapes.
   - But even when D-NONDET is disabled or unavailable, host ambient clock/RNG behavior remains an
     implementation detail rather than a reviewed `capshell.exec` contract.
   - Workflows whose meaning depends on time or entropy MUST still come back through explicit D-NONDET
     seams instead of relying on host defaults that may differ across wrappers, profiles, or replay
     harnesses.

5) **Commutativity and ordering stay on existing seams**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - Ordering for launch remains the existing `capshell.exec` story; ordering for explicit clock/entropy
     issuance remains the already-defined `portal.clock.*` / `portal.entropy.request` seams.

6) **Sealed compat remains killable and non-ambient**
   - Compat/foreign-cell adapters MUST NOT recreate "normal host clocks" or host RNG access as a hidden
     convenience behind D-CAPSHELL.
   - Any legacy time/RNG mediation remains explicit, policy-killable, and subordinate to D-NONDET rather
     than a side door around it.

7) **No new workflow / ACP / admin surface**
   - Phase 1 adds no `capshell.clock.*`, no `capshell.entropy.*`, no reviewed per-step timer surface,
     and no shell-owned time/RNG inventory.
   - Any future explicit timer/runtime broker must return as its own RFC-first seam rather than hiding
     inside `capshell.exec`.

## Phase 1 non-goals (explicitly deferred)

- No reviewed per-step time/timer API for capshell.
- No reviewed per-step entropy/RNG API for capshell.
- No hidden "inherit the machine clock/RNG" compatibility promise.
- No timerfd/random-device escape hatch that bypasses D-NONDET.

## Wiring

- Decision surfaces: `docs/30-architecture/decision-map.md` (**D-CAPSHELL**, **D-NONDET**).
- Existing nondeterminism seam: `nondet-posture-v0.md`, `clock-descriptor-schema-v0.md`,
  `entropy-descriptor-schema-v0.md`, `entropy-request-schema-v0.md`,
  `effect-contract-schema-v0.md`, `portal-family-registry.md`.
- Capshell schema/control seams: `capshell-exec-pack-schema-v2.md`,
  `docs/70-llm-control/acp-action-kind-registry.md`,
  `docs/70-llm-control/acp-validator-semantics.md`, `docs/60-engineering/cli-plumbing-tooling.md`.
- Assurance anchors:
  - `I-CAPSHELL-NONDET-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-NONDET-EXPLICIT` in `docs/20-assurance/proof-obligation-registry.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_nondet_posture.py` (**EVID-2026-337**).

## References

- REF-MAN7-CLOCK_GETTIME
- REF-LINUX-GETRANDOM
- REF-WASI-CLOCKS
