# CH-OBS v0 (observation export schema, informal)

Purpose: a minimal, redacted observation payload exported by IF-OBS for operators/auditors.

See also: `observation-export-posture-v0.md` (D-OBS Phase 1 posture: pull-only, bounded/redacted, policy-killable exports).

Constraints (v0)
- deterministic decode (I-ENC-1)
- redaction/minimization is explicit (I-OBS-1)
- avoid implicit joins of high-entropy identifiers (side-channel posture is scoped elsewhere)

## Shape (v0)
An observation bundle `o` contains:
- `schema`: fixed `CH-OBS v0`
- `scope`: what profile/policy this export is for (typed tag)
- `window`: optional time/seqno bounds (only if enabled)
- `logs`: optional list of `CH-LOG v0` entries (redacted)
- `boot`: optional summary of `CH-BOOT v0` (redacted; digests only)
- `metrics`: optional bounded set of counters (no raw pointers / addresses)
- `cap_graph`: optional `CH-CAPG v0` snapshot (redacted; bounded)
- `trace`: optional bounded list of `CH-TRACE v0` entries (or a `trace_digest` pointer if the profile exports traces out-of-band); when exporting raw traces, ALSO include or reference the active CH-TPROBE digest (`tprobe_digest`) so offline consumers can interpret fields safely

## Validation obligations (PO-OBS-REDACT)
- only include allowed fields for the configured export scope
- secret-bearing content must be absent unless explicitly authorized
- stable ordering/canonicalization if digests are computed over exports
