# D-BRACKET posture v0 (borrowed-mode default; task-local scoped privilege; deny-only call-chain)

Purpose: pin an implementable v0 meaning for **D-BRACKET** so privilege bracketing stays a small user-space/runtime guardrail against in-process confused deputies instead of drifting into a kernel stack-inspection subsystem, an ambient thread-local privilege toggle, or a second workflow/policy plane.
It narrows RFC-0118 into one compact posture runtimes and helper ecosystems can actually share: **borrowed mode by default** at inbound trust boundaries, **task-local lexically scoped privileged blocks**, and **bounded optional CH-CALLCHAIN** metadata that is audit/deny-only.

## Posture (v0)

1) **Optional runtime guardrail, never an authority source**
   - If D-BRACKET is enabled, it is a **runtime/library-owned guardrail** for in-process helpers, plugins, routers, and automation runtimes.
   - It does **not** create capabilities, does **not** widen rights, and does **not** move authority into the kernel or scheduler. It only narrows visibility/behavior around capabilities the runtime already holds (I-BRACKET-3).
   - Phase 1 does **not** standardize a new privileged-core policy engine, global permission lattice, or approval channel on this seam.

2) **Borrowed mode is the default at inbound trust boundaries**
   - When a component/runtime handles an inbound request, effect, portal callback, plugin hook, or helper invocation under D-BRACKET, **privileged capabilities are dark by default** unless code explicitly enters a privileged block.
   - Only capabilities explicitly lent in the inbound request (or safely derived from those lent capabilities) are routinely visible in borrowed mode (I-BRACKET-1).
   - This keeps helper ecosystems aligned with the capability model: “who called?” may influence veto-only routing, but ambient internal authority does not quietly come along for the ride.

3) **Bracketing state is task/request-local dynamic scope, not an ambient global/thread toggle**
   - Phase 1 pins bracketing state to **task/request-local dynamic scope** owned by the runtime, not to a mutable process-global singleton, environment variable, path lookup, or plain unconstrained thread-local flag.
   - Implementations MAY use mechanisms analogous to **scoped values** / **context-local variables** under the hood, but the exported posture is: state is bounded by the lexical/dynamic request scope, and it must not bleed across unrelated concurrent tasks (I-BRACKET-2).
   - Async children created under structured scope MAY inherit borrowed-mode context; detached/background work must start from a fresh owner-controlled root rather than inheriting a stale privileged state by accident.

4) **Privileged blocks are explicit, minimal, and exception-safe**
   - Code must enter an explicit **privileged block** to access privileged capabilities while servicing an inbound request.
   - Privileged blocks are **scoped and exception-safe**: prior bracketing state is restored on every exit path, including panic/exception/cancellation unwind (I-BRACKET-2; PO-BRACKET-SCOPE).
   - Phase 1 requires the privileged region to stay as small as possible; “utility helpers that always call privileged code on behalf of others” are exactly the drift this seam is meant to prevent.

5) **Bracketing remains veto-only: no self-elevation, no hidden capability minting**
   - D-BRACKET may only hide privileged capabilities or narrow behavior; it must never manufacture new capabilities, widen rights, or bypass ordinary explicit handoff rules (I-BRACKET-3).
   - Entering a privileged block means “the runtime may temporarily expose already-held privileged capabilities to this lexical region,” not “the caller gains new authority.”
   - Call-chain presence, frame hints, or routing context must not be treated as capability material or as a substitute for explicit portal/capability grants.

6) **CH-CALLCHAIN stays bounded, optional, and non-authoritative**
   - **CH-CALLCHAIN** remains an optional descriptor for audit/debug and **deny-only** routing. It contains no capabilities, no bearer secrets, and no authority proofs (I-CALLCHAIN-1; PO-CALLCHAIN-VALIDATE).
   - Frame kinds stay closed and bounded; hints/surfaces remain human/debug metadata only.
   - Phase 1 declines “mandatory call-chain everywhere,” portable stack-walking proofs, or any attempt to use call-chain metadata to grant privileged effects.

7) **Cross-task and long-lived work must be explicit, not inherited by accident**
   - Runtime helpers MAY propagate borrowed-mode/call-chain context across structured child tasks that are still part of the same request tree.
   - Long-lived work, queued jobs, or background services must mint a **fresh owner-controlled root** and start in borrowed mode under their own explicit authority surfaces (D-REQCTX, D-JOBS, D-BGLEASE), rather than carrying a privileged block or implicit caller privilege across time.
   - This prevents “spawn and keep my privileges around” from becoming an accidental ambient channel.

8) **Adjunct seams stay explicit: D-REQCTX / D-CAPSHELL / D-PLUMB may carry digests, not privilege**
   - CH-REQCTX v1 may reference `call_chain_digest`, but request context remains **non-authoritative** and veto-only (I-REQCTX-4).
   - D-CAPSHELL / D-PLUMB may log or route based on bounded call-chain metadata, but they do not gain a new authority path from this seam.
   - D-SEAL still governs post-init authority narrowing; D-BRACKET is about request-time visibility of already-held privileged capabilities, not a substitute for sealing.

9) **No portable stack inspection or kernel enforcement in v0**
   - Phase 1 deliberately declines kernel stack inspection, scheduler-mediated privilege tracking, or a privileged-core call-stack proof system.
   - D-BRACKET is a **user-space/runtime convention** with validators, harnesses, and logs/evidence where useful.
   - This keeps the entropy cost small and avoids turning helper hygiene into a new kernel subsystem.

10) **No new workflow / ACP / conflict-key family surface in v0**
   - D-BRACKET v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
   - Therefore **no new conflict-key family is introduced in v0**.
   - Any future portable admin/workflow surface for privilege bracketing or call-chain export must land RFC-first with its own receipts, serialization boundary, and kill switches.

11) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY internally emulate helper/plugin guardrails, but portable interop may only carry D-BRACKET meaning through explicit adapter/runtime surfaces such as CH-REQCTX v1 digest references or local logs.
   - Phase 1 does **not** standardize environment-variable, signal, path, or ambient thread-state tricks to push privileged mode across D-FCELL boundaries.
   - This keeps sealed compat honest: privilege bracketing interop remains policy-killable and cannot bypass membranes.

## Phase 1 non-goals (explicitly deferred)

- Kernel stack inspection or any privileged-core enforcement model for D-BRACKET.
- A global permission lattice, security-manager clone, or implicit privilege-inheritance framework.
- Mandatory CH-CALLCHAIN export on every request or a portable call-chain broker service.
- Portable background/detached privilege inheritance.
- New workflow / ACP / admin surfaces around privilege bracketing or call-chain export.

## Wiring

- Decision surface: `decision-map.md` (D-BRACKET).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (privilege bracketing seam)
  - `rfcs/0118-privilege-bracketing-and-call-chain-contexts.md` (option space / evidence seed)
  - `call-chain-schema-v0.md` (bounded call-chain descriptor)
  - `request-context-schema-v1.md` (optional call-chain digest hook)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-BRACKET-1, I-BRACKET-2, I-BRACKET-3, I-CALLCHAIN-1, I-REQCTX-4)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-CALLCHAIN-VALIDATE, PO-BRACKET-SCOPE)
  - `docs/70-llm-control/acp-validator-semantics.md` (request-context/call-chain remains veto-only)
- Discovery/profile surfaces:
  - `posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_bracket_posture.py` fails `make lint` if this posture stops being discoverable, loses the borrowed-mode / task-local scoped-privilege / deny-only call-chain posture, or drops its primary REF wiring.

## References

- REF-CONFUSED-DEPUTY.
- REF-JAVA-STACKINSPECT.
- REF-JAVA-ACCESSCONTROLLER.
- REF-JAVA-DOPRIVILEGED.
- REF-OPENJDK-SCOPEDVALUES.
- REF-PEP-567.
- REF-PY-CONTEXTVARS.
