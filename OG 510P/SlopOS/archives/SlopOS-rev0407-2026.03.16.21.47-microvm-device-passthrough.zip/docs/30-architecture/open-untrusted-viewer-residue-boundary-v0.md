# D-PLUMB / D-QUAR / D-EPHEM safe-open viewer-residue boundary v0 (no durable recent-doc / MRU / cache residue outside the disposable)

Purpose: pin the **host-residue boundary** for `intent.kind=open_untrusted` so risky-open does not quietly regrow a persistence lane through “helpful” viewer side effects.
It narrows the next ambiguity after **docref-only**, **snapshot-in**, **inert-by-default**, and **fresh-destination-first**: once a quarantined document is admitted to safe-open, **what durable traces may the platform leave behind merely because it was viewed?**
Phase 1 answers: mere preview/open must not create durable recent-doc, reopen, thumbnail, index, autosave, or crash-recovery residue outside the disposable. Any durable state starts from an explicit kept/exported artifact or another explicit follow-on workflow, not from the act of risky-open itself.

This keeps D-EPHEM, D-PLUMB, and D-QUAR honest without inventing a new metadata subsystem: disposables stay continuity-free, recent-doc convenience stays shell-owned and non-authoritative, and document portals keep persistence explicit instead of smuggling it in through viewer caches. Companion content-index boundary: even when viewer residue stays disposable-local, quarantined bytes still do **not** automatically enter host/global full-text / OCR / embedding / summary systems (`quarantined-content-index-boundary-v0.md`).

## Posture (v0)

1) **Preview/open does not auto-enroll the source object into durable reopen surfaces**
   - Admitting one exact `docref` to `open_untrusted` must not by itself mint a persistent CH-DOCREF, add the source object to durable “recent documents” / MRU / reopen menus, or create another durable reopen token outside the disposable.
   - Risky-open success therefore means **a bounded preview workflow launched**, not “the system now remembers this source object for later direct reopen.”
   - If the shell later offers a “recent safe-open choices” convenience surface, that state remains shell-owned, non-authoritative, and separate from document authority.

2) **Viewer-derived residue stays disposable-local unless explicitly exported**
   - Thumbnails, preview bitmaps, search/index sidecars, autosave drafts, crash-recovery blobs, session-restore state, editor temp files, and equivalent viewer-derived residue created while handling `open_untrusted` stay inside the disposable writable state by default.
   - Teardown of the disposable therefore discards that residue along with the rest of the disposable-local writable state.
   - A host/global cache, indexer, or recovery service must not observe or persist such residue outside the disposable merely because risky-open happened.

3) **Shell convenience history stays non-authoritative and redaction-safe**
   - Phase 1 does not forbid a shell from keeping a bounded local history that a safe-open workflow occurred.
   - But that history must not itself be a reopen grant, must not expose an app-visible inventory API, and must not become a hidden path / raw `docref` / raw bearer material leak.
   - Redacted labels, receipt digests, or equivalent shell-owned hints are acceptable; authority to reopen still comes only from the existing explicit document/export seams.

4) **Any later “remember/reopen” flow begins from an explicit kept artifact or explicit portal choice**
   - If the user wants something persistent after risky-open, the first durable object is the explicit kept/exported artifact already pinned as **new-artifact + quarantined-by-default + fresh-destination-first**.
   - Any later “remember this file,” durable CH-DOCREF minting, or recent-doc UX must attach to that explicit post-export object or to a fresh mediated `portal.file.*` choice, not to the original risky-open session as a side effect.
   - Safe-open therefore remains a preview-first lane, not a backdoor into persistent document enrollment.

5) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - One `open_untrusted` request remains request-local and serializes only at the owning workflow + selected safe-open provider.
   - Any later keep/export/remember/reopen step uses the already-declared conflict keys and evidence paths of `portal.file.*`, `portal.xfer.*`, IF-CONSENT, or other existing seams.

6) **Sealed compat remains killable and non-ambient**
   - Compat viewers/adapters may participate in safe-open only if they preserve the same no-residue boundary outside the disposable.
   - Compat must not reinterpret “legacy viewer wrote MRU/thumbnail/recovery state on the host” as harmless convenience.
   - If an interop path cannot keep recent-doc / cache / recovery residue inside the disposable or behind an explicit later export/persistence seam, it fails closed for `open_untrusted`.

## Phase 1 non-goals (explicitly deferred)

- **No app-visible recent-safe-open inventory / MRU API**.
- **No hidden persistent thumbnail, search-index, autosave, or crash-recovery cache** for risky-open merely because a viewer ran.
- **No auto-minting of persistent CH-DOCREFs, remembered grants, or reopen tokens** on preview/open success.
- **No host-side pre-open thumbnailing/indexing pass** over the risky source object outside the safe-open compartment.
- **No search-result preview pane / hover-preview / Quick Look activation** for quarantined objects on mere selection/focus outside the explicit safe-open compartment (`quarantined-result-preview-boundary-v0.md`).
- **No promise that shells cannot keep a local redacted receipt/history hint**; the boundary is that such state is non-authoritative and non-reopen-capable.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM)
- Related posture / schema surfaces:
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `open-untrusted-export-classification-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `disposable-domain-posture-v0.md`
  - `document-handle-schema-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-EPHEM-2, I-DOCREF-3, I-QUAR-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-EPHEM-EXPORT, PO-DOCREF-ENF, PO-QUAR-GATE)
- RFC / engineering history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_viewer_residue_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no durable recent-doc / MRU / cache residue outside the disposable / shell history remains non-authoritative** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-APPLE-RECENT-ITEMS.
- REF-MS-OFFICE-MRU.
