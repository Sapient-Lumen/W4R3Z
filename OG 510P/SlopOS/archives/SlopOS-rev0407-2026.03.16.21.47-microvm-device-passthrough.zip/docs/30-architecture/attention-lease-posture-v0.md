# Attention lease posture v0 (D-ATTN; no new lease descriptor)

Purpose: close the D-ATTN “attention lease” follow-up **without adding a new schema surface**.

Decision (v0 stance): **do not introduce a dedicated attention-lease descriptor** for urgent/critical alerts.
Instead, treat urgency as a *policy-gated hint* on the existing request seam **CH-NOTIF v0**. In Phase 1 there is also **no separate `attention.urgent` capability**: any stronger durable interruption surface would add a new schema/consent/renewal problem and therefore requires a **separate RFC-first surface** rather than silent widening. See `attention-durable-interrupt-boundary-v0.md`.

This document refines **D-ATTN** and applies to the `portal.attn.*` family.

## Posture (v0)

1) **Urgency is a hint, never a grant**
   - CH-NOTIF `importance="urgent"` is **never** a bypass and never a capability.
   - It is a request the portal may ignore, downgrade, coalesce, or deny.

2) **No bypass of volition** (I-ATTN-2)
   - `importance="urgent"` MUST NOT enable background execution or auto-running notification actions.
   - If `actions[*]` are rendered, executing them still requires the normal D-VOLITION posture and digest-binding.

3) **No bypass of budgets/coalescing** (I-ATTN-3; PO-ATTN-BUDGET)
   - Urgent requests are subject to the same deterministic budget/coalescing rules as non-urgent requests.
   - Policy MAY apply stricter limits for urgent (cooldowns, lower ceilings), but never looser.

4) **Explicit policy gating for urgent** (PO-ATTN-URGENT)
   - If a profile/policy does not allow urgent interruption for the origin/channel, the portal MUST deterministically deny or downgrade the request.
   - Denials SHOULD be transcript-visible when mediated via ACP (`portal.attn.request`) using CH-DENY `deny_code="policy-deny"` or `"cfg-deny"`.

5) **Replay stability** (D-RR)
   - Given the same request bytes + the same policy bundle/handle, the portal’s urgent downgrade/deny decision MUST be deterministic.

## Phase 1 non-goals (explicitly deferred)

- **No new attention-lease schema** (TTL/renew/revoke semantics) in Phase 1.
- **No “critical alert” universal promise**: profile defaults may deny urgent entirely (especially B/D).
- **No automation-first device interruption**: urgent remains policy+user gated; it is not a “do this now” control channel.
- **No standalone urgent capability token** in Phase 1: profiles/policy may allow or deny urgent by origin/channel, but there is no exportable `attention.urgent` grant surface.

## Wiring

- Decision surface: `decision-map.md` (D-ATTN).
- Schema surface: `notification-request-schema-v0.md` (CH-NOTIF v0).
- Portal family: `portal-family-registry.md` (`portal.attn`).
- ACP kind: `docs/70-llm-control/acp-action-kind-registry.md` (`portal.attn.request`).
- Lane gate: `cfg.params.lane.portal.attn` (policy-killable).
- Assurance anchors: I-ATTN-2, I-ATTN-3, PO-ATTN-BUDGET, PO-ATTN-URGENT.
- Boundary note: `attention-durable-interrupt-boundary-v0.md` retires OQ-0005 by freezing CH-NOTIF as an ephemeral request seam; any future durable interrupt semantics must live outside CH-NOTIF.
- CI note: dedicated drift gates `tools/check_attention_posture.py` and `tools/check_attention_durable_interrupt_boundary.py` pin the no-lease/no-capability v0 rule and the evolution boundary.

## References

- REF-APPLE-CRITICAL-ALERTS
- REF-ANDROID-NOTIF-CHANNELS
