# MicroVM snapshot posture v0 (warm restore is not ambient continuity)

Purpose: pin the **Phase 1** meaning of snapshot/restore/clone under `ext.microvm` so the cloud/hosted-compute story can use warm starts **without** silently acquiring a hidden continuity plane.

This doc is a posture for existing seams, not a new subsystem. It attaches to **D-MICROVM**, **D-EPHEM**, and **D-NONDET** and makes one hard decision explicit:
**warm restore preserves declared machine bytes, not ambient transport/session/identity authority**.

## Posture (v0)

1) **Snapshot/restore is an implementation-local accelerator, not a portable continuity contract**
   - Phase 1 may use snapshot/restore/clone to reduce startup latency for `ext.microvm` workloads.
   - Snapshot artifacts are treated as **implementation-local and version-pinned** unless a narrower future profile says otherwise.
   - Reusable warm-start templates are pinned separately in `microvm-template-snapshot-cut-posture-v0.md`: the reusable cut stays **secret-clean and authority-cold**.
   - v0 therefore adds **no** generic “resume this VM anywhere and keep everything live” product promise.

2) **Restore resumes declared machine state only**
   - Restoring a microVM may recover guest RAM, CPU/device state, and other declared image/template bytes.
   - It MUST NOT be interpreted as preserving ambient **host↔guest** transport continuity, portal session continuity, or authority continuity.
   - In particular, ordinary live **network** connections, **vsock** connections, inherited transport FDs, and equivalent host-side session state are out of scope as portable continuity claims in Phase 1.

3) **Clone/restore must refresh entropy and instance identity before first payload**
   - A restored/cloned microVM MUST NOT rely on copied RNG state as its operational entropy story.
   - Any clone/restore path that matters for D-NONDET must refresh or reseed instance entropy before first user payload runs.
   - If policy allows guest-visible instance identifiers (for example CID/MAC/IP/hostname-like bindings), those identifiers must be treated as **fresh instance inputs**, not as ambient continuity inherited from an arbitrary source snapshot.
   - Guest-side restore detection is pinned separately in `microvm-generation-witness-posture-v0.md`: snapshot success alone is never the signal.

4) **Any externally visible continuity must cross existing explicit seams**
   - If a product wants continuity after restore, it must use an **existing explicit seam** such as D-ACTIVATE inbound-only handles, fresh D-NETLEASE issuance, explicit D-CAPX/CH-SREF restore/import, or a family-local reopen protocol.
   - Snapshot/restore itself is **not** that seam.
   - There is no implicit host agent, no hidden rebind to `portal.net`, no transparent reanimation of provider-owned portal sessions, and no ambient reattachment to previously granted host resources.

5) **Sealed compat remains honest**
   - Snapshotting a foreign guest or hosted runtime does **not** make `ext.microvm` a compatibility escape hatch.
   - Any future guest-management interop remains subject to the existing host↔guest posture: explicit, killable, and non-ambient.
   - Snapshot convenience must not backdoor path/env/net/session channels that the archive otherwise forbids.

6) **Commutativity/ordering remain explicit by omission**
   - D-MICROVM v0 defines **no generic ACP kind** for snapshot/restore/clone and therefore introduces **no new conflict-key family** in Phase 1.
   - If a later management plane exposes snapshot/restore as an externally visible action, it must specify conflict keys, commutativity stance, retry semantics, and where serialization lives.
   - Until then, serialization is local to the owner VMM / instance-management service rather than a new portable workflow surface.

## Phase 1 non-goals (explicitly deferred)

- No portable live-migration semantics.
- No transparent preservation of open network/vsock sessions.
- No snapshot catalog / inventory / search plane.
- No cross-version snapshot compatibility promise.
- No generic host-agent continuity channel hidden behind restore success.

## Wiring

- Decision surface:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-NONDET)
- Adjacent postures:
  - `microvm-profile-posture-v0.md`
  - `host-guest-channel-posture-v0.md`
  - `disposable-domain-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `microvm-restore-repair-barrier-posture-v0.md`
  - `microvm-template-snapshot-cut-posture-v0.md`
  - `activation-posture-v0.md`
  - `network-lease-posture-v0.md`
  - `nondet-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-SNAPSHOT-BOUNDARY)
- Policy posture:
  - snapshot/restore adds **no new lane** or ambient interop exemption in Phase 1; any future management API must stay explicit and killable.

CI drift gate:
- `tools/check_microvm_snapshot_posture.py` fails `make lint` if this posture stops being discoverable, loses its **implementation-local / no ambient continuity / refresh entropy+identity / explicit continuity seams only** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-FIRECRACKER-ENTROPY-CLONES.
- REF-CHYP-SNAPSHOT-STABILITY.
- REF-FIRECRACKER-VSOCK.
