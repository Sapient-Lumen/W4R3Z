# CH-PART v0: Partition policy schema

Purpose: describe **static partitioning** (“cells”) as explicit data so it can be validated and bound in boot/provenance without embedding policy logic in the privileged core.

This schema is **optional** (D-PART) and should be treated like CH-CFG/CH-BOOT: canonical, hashable, and strictly validated.

## Design rules
- closed-world: unknown keys/variants reject (PO-PART-VALIDATE)
- bounded sizes: reject policies that exceed declared limits (to cap validation cost)
- no embedded large blobs: refer to device tables/firmware by digests (CH-BOOT artifacts)
- overlap checks are mandatory: CPU/mem/dev/IRQ assignments must be disjoint unless a shared object explicitly represents the sharing

## Canonical shape (informal)

```text
PartitionPolicy {
  schema: "CH-PART-v0",
  platform_id: String,
  policy_id: String,          // human label; not trusted for uniqueness
  partitions: [Partition],
  channels: [Channel],        // optional; empty means no cross-partition comm
  digests: {
    hwfacts?: DigestRef,      // optional binding hint
    build?: DigestRef,        // optional (policy generator build)
  }
}

Partition {
  pid: String,
  cpus: [CpuId],
  mem: [PhysRange],
  devices: [DeviceRef],       // opaque IDs that map to platform tables (CH-HWFACT or board DB)
  irqs: [IrqRef],
  entry: {
    kind: "bare" | "pv" | "os",
    image_digest: DigestRef,
    boot_args?: String,
  },
  io: {
    mmio: [PhysRange],
    pio?: [PortRange],
    dma: "none" | { iommu_domain: String },
  },
  comm: {
    inboxes?: [EndpointRef],
    outboxes?: [EndpointRef],
  }
}

Channel {
  cid: String,
  kind: "shared_mem" | "msg",
  participants: [String],     // partition pids
  rights: [ { pid: String, r: Bool, w: Bool, x?: Bool } ],
  backing?: PhysRange,        // for shared_mem
  endpoint?: EndpointRef,     // for msg
}

DigestRef { alg: String, hex: String }
PhysRange { base: u64, size: u64 }
PortRange { base: u16, size: u16 }
```

## Validation requirements (must)
- all arrays are bounded by profile constants (implementation-defined)
- `PhysRange` entries are page-aligned and non-overlapping across partitions, except where a `Channel(kind=shared_mem)` declares the sharing and enumerates participants
- `cpus` are disjoint across partitions (unless a profile explicitly allows time-slicing, which must be modeled as a separate scheduling authority)
- `io.mmio` ranges are disjoint across partitions unless explicitly shared and represented as a shared object
- `entry.image_digest` must appear in CH-BOOT `artifacts` under a declared role
- DMA posture must satisfy D-DMA: either no DMA, or IOMMU domain isolation with explicit windows

## Recommended binding
If used, list the CH-PART digest in CH-BOOT `artifacts` under a role like `partition_policy`, and export it for audit via IF-OBS/CH-LOG.
