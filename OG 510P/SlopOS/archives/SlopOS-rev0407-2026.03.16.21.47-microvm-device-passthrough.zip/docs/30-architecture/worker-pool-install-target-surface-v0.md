# Worker-pool install target surface v0 (exact `install_target` contract)

Purpose: pin an implementable Phase 1 meaning for the optional `install_target` import so the first concrete **D-CONSTR** family does not regain rename/remap folklore, partial publication, duplicate direct-return surfaces, or a hidden constructor catalog/admin plane.
This doc narrows one remaining part of the already-chosen worker-pool family / invocation / harness stack into a smaller claim: **`install_target` is a publication-only target seam for one exact canonical export set, not a rename/remap/catalog capability**.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-COMMUTE**, **D-CAPAUD**, **D-SEAL**, **CH-SPROJ v0**
- assumes the exact family-local invocation boundary is already fixed by `worker-pool-constructor-invocation-v0.md`
- assumes the exact exported handle contracts are already fixed by `worker-pool-control-surface-v0.md` and `worker-pool-worker-surface-v0.md`
- does **not** introduce a new constructor-global install protocol, target inventory API, or publication/admin plane

## Phase-1 choice

1) **`install_target` is a publication-only target seam, not a rename/remap/catalog capability**
   - `install_target` appears at most once in one invocation and denotes one already-existing **owner-visible target seam**.
   - The constructor may use it only to publish the family’s already-pinned canonical export set onto that target seam.
   - It is **not** a target-discovery handle, alias map, export-template editor, inventory/list/watch interface, or a generic “publish this anywhere” capability.
   - Phase 1 therefore declines any `ListTargets`, `RenameExport`, `AttachAlias`, `PublishElsewhere`, `MergeInstall`, or catalog-style interpretation of `install_target`.

2) **Publication is exact, canonical, and all-or-nothing**
   - When `install_target` is present, the install set is fixed to exactly:
     - `pool.control`, and
     - `worker[i]` for `0 <= i < pool_size`.
   - The constructor may not rename those entries, drop a subset, add helper outputs, or synthesize caller-chosen aliases during installation.
   - Installation MUST be **all-or-nothing** at the family boundary: either the whole canonical set is published onto the target seam, or the invocation fails closed.
   - Partial publication, placeholder entries, best-effort continuation, or split success across multiple target seams is out of scope in v0.

3) **Install and return-only are separate modes in v0**
   - If `install_target` is absent, the invocation is **return-only** as pinned in `worker-pool-constructor-invocation-v0.md`.
   - If `install_target` is present, the invocation is **install mode**: the canonical export set becomes reachable through the target seam rather than through a second direct-return surface.
   - The constructor may still return bounded receipts/status, but it does not duplicate the installed export set as extra direct outputs.
   - This keeps replay evidence and caller-visible deltas from forking into “installed and separately returned” folklore.

4) **Conflict keys and serialization stay on the target seam**
   - `install_target` does not mint a constructor-global ordering stream or a family-specific conflict-key vocabulary.
   - Non-commutativity comes only from mutating the already-existing owner-visible target seam.
   - The constructor therefore reuses the target seam’s existing conflict keys, ordering witnesses, and `CH-SPROJ v0`-style projections for install cases.
   - `target.before` / `target.after` in `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md` remain the canonical evidence hooks for those projections.

5) **Observation stays on target-seam projection, not a constructor inventory**
   - The constructor does not expose a reflected “what targets exist?” or “what is installed where?” API on `pool.control`, `worker[i]`, or a sideband constructor object.
   - Install success/failure is observed through ordinary target-seam results plus the bounded evidence/projection artifacts already required by the harness.
   - Phase 1 declines install-history scans, constructor-global watch streams, or target-search conveniences tied to `install_target`.

6) **Sealed compat remains honest**
   - `install_target` cannot be used to smuggle ambient paths, environment defaults, hidden network publication, or foreign-cell compatibility aliases into the first worker-pool family.
   - Any compat-facing publication still has to live on an explicit reviewed target seam with its own kill switch / policy story; the constructor import itself adds no ambient channel.
   - If a candidate target seam cannot host the exact canonical set without aliasing, ambient lookup, or partial success, the invocation MUST fail closed instead of degrading into host-convention install behavior.

## Out of scope in v0

- Caller-chosen export-label maps or aliasing during install.
- Installing the same family instance into multiple targets in one invocation.
- Partial success / retry debt / background completion for publication.
- A target inventory, browse, search, or watch API on the constructor family.
- Constructor-defined uninstall, rename, or migration verbs.

## Wiring

- Decision surface: **D-CONSTR**.
- Reused seams: **D-COMMUTE**, **D-CAPAUD**, **D-SEAL**, **CH-SPROJ v0**.
- Primary family docs: `worker-pool-constructor-family-v0.md`, `worker-pool-constructor-invocation-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-worker-surface-v0.md`.
- Verification/evidence docs: `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-REALMS**, **REF-FUCHSIA-TOPOLOGY**, **REF-GENODE-INIT**, **REF-EROS-CONFINEMENT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_install_target_surface.py` (**EVID-2026-365**).
