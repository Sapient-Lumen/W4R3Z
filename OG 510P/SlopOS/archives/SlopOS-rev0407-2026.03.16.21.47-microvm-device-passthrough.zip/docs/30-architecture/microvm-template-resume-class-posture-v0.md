# MicroVM template resume-class posture v0 (reusable templates admit only under an exact reviewed restore class)

Purpose: pin the **Phase 1** restore-admission meaning for reusable `ext.microvm` warm-start templates so fast-start work does not quietly turn host/kernel/CPU compatibility folklore into an ambient deployment promise.

This doc attaches to **D-MICROVM**, **D-EPHEM**, **D-XS**, and **D-ATOMICUPD** and makes one hard decision explicit:
**a reusable warm-start template leaf is admitted only under one exact reviewed resume class; cross-class restore is out of scope and fails closed.**

Entropy cost justification: the archive already says reusable templates are parent-bound leaf artifacts, but it does not yet pin **where** a reviewed leaf may legally resume. One narrow resume-class posture removes a large amount of future ops folklore without adding a new schema family.

## Posture (v0)

1) **Every fan-out-admitted leaf has one exact reviewed resume class**
   - A reusable warm-start template leaf is not merely bound to a parent lineage; it is also admitted under one exact reviewed **resume class**.
   - In Phase 1, the resume class is policy-owned and implementation-local, but it MUST cover the software and hardware configuration that gives restore its meaning — at minimum the relevant VMM snapshot format/version, declared guest device/transport profile, guest architecture, CPU feature class, and any host kernel / microcode floor the implementation relies on.
   - “Resume this leaf” therefore means “resume this leaf on a host admitted to the same reviewed resume class,” not “best effort on whatever machine looks close enough.”

2) **Cross-class restore fails closed instead of negotiating at resume time**
   - If the target host/runtime is outside the admitted resume class, ordinary fan-out restore MUST fail closed.
   - Phase 1 adds no best-effort compatibility negotiation, no automatic degrade-to-cold-boot fallback hidden behind the same template identity, and no silent widening from one CPU/device/kernel class to another.
   - If a product wants a broader restore set, it must cut/admit a leaf for that broader class explicitly rather than discovering compatibility opportunistically at restore time.

3) **Heterogeneous fleets are normalized before the cut, not during restore**
   - If an owner wants one reusable template to serve a heterogeneous fleet, the heterogeneity is handled **before** the reusable cut by choosing a narrower reviewed guest-visible class — for example by pinning a CPU feature profile/template that all intended hosts can honestly satisfy.
   - Restore does **not** renegotiate guest CPU shape, transport surface, or snapshot format semantics on the fly.
   - In plain terms: cut once for the class you mean to serve; do not promise that host passthrough or ad hoc runtime similarity will rescue an over-specific snapshot later.

4) **Resume class is admission metadata, not a new ambient interop plane**
   - Phase 1 does **not** standardize a new `CH-*` schema, host-agent callback protocol, or guest-visible RPC just to publish resume-class membership: there is **no new `CH-*` schema** for compatibility metadata in v0.
   - The owning service/runtime may maintain its admission table locally, but callers continue to select one admitted reusable leaf under the existing parent-lineage rules.
   - Sealed compat stays honest: a foreign guest may benefit from being launched under a reviewed class, but that does not create a new ambient compatibility channel or a hidden restore-anywhere promise.

5) **Refreshing compatibility means admitting a new leaf or class policy, not mutating restore semantics in place**
   - If the VMM snapshot format version, CPU feature profile, device/transport profile, or required kernel/microcode floor changes in a way that matters for resume safety, Phase 1 handles that by admitting a new leaf and/or updating the owner-local class policy explicitly.
   - A previously admitted leaf MUST NOT silently acquire broader resume rights in place just because operations upgraded hosts or found that “it seems to work.”
   - This keeps D-ATOMICUPD honest: compatibility drift is reviewed release/admission work, not ambient runtime folklore.

6) **Commutativity and ordering remain explicit by omission**
   - This posture introduces **no new ACP kind** and **no new conflict-key family** in Phase 1.
   - If a later management plane exposes actions such as “admit host into resume class”, “publish compatibility class”, or “reclassify template leaf”, it must define conflict keys, commutativity stance, retry semantics, serialization scope, and evidence hooks explicitly.
   - Until then, resume-class membership and serialization live inside the owning deployment/runtime service rather than a portable workflow surface.

## Phase 1 non-goals (explicitly deferred)

- No portable `CH-*` schema for resume-class metadata.
- No best-effort restore onto “similar enough” hosts.
- No automatic restore-time CPU/device/kernel negotiation.
- No promise that host-passthrough CPU exposure is fleet-portable.
- No hidden cold-boot fallback under the same reusable-template identity.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-XS, D-ATOMICUPD)
- Adjacent postures:
  - `microvm-profile-posture-v0.md`
  - `microvm-snapshot-posture-v0.md`
  - `microvm-template-lineage-posture-v0.md`
  - `disposable-domain-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-7)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-RESUME-CLASS)
- Policy posture:
  - resume-class admission adds **no new lane**, **no new guest-visible channel**, and **no new portable compatibility API** in Phase 1.

CI drift gate:
- `tools/check_microvm_template_resume_class_posture.py` fails `make lint` if this posture stops being discoverable, loses its **exact reviewed resume class / same-class-or-fail-closed / heterogeneity normalized before the cut / no new CH-schema or ACP surface** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-FIRECRACKER-CPU-TEMPLATES.
- REF-QEMU-CPU-MODELS.
