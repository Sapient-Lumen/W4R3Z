# Typed ID contract v0 (opaque digest identifiers)

Purpose: pin a **small, deterministic** representation for the typed `*_id` values that appear on
privileged action surfaces and feed conflict-key derivation.

This exists to reduce drift:
- D-COMMUTE relies on stable conflict keys and ordered-stream scopes.
- Several seams refer to ids in prose (`as_id`, `endpoint_id`, `view_id`, …) without a canonical
  encoding, which invites subtle “profile-defined” ambiguity.

Decision surface: **D-TYPEDID**.

Non-goals:
- This does **not** define an allocation API, naming UX, or persistence semantics.
- This does **not** grant authority. IDs are correlation handles; capabilities remain the authority.

## Normative rule (v0)

For v0 pinned surfaces, the following typed ids are **opaque digest bytes**:

- `as_id` (address-space id)
- `endpoint_id` (IPC endpoint id)
- `view_id` (view/namespace id)
- `log_id` (event-set/log id)
- `meter_id` (budget issuer / meter id)
- `budget_id` (budget lease id)
- `domain_id` (domain/VM id when used as an action scope)
- `cell_id` (Foreign Cell identity when used as a scope/correlation handle)
- `device_id` (device-manager / driver-authority identity for one attachable device-presence instance when used as a conflict-key/order scope)

Representation:
- Each value is a **bstr** of length **`hashlen`**, where `hashlen` is the active profile digest length (D-HASH; see `profile-hash-suite-v0.md`).
- Any validator/decoder that consumes one of these ids MUST reject (fail closed) if:
  - the value is not a `bstr`, or
  - the length is not exactly `hashlen`.

Implication:
- For the families that use `ck_id(tag, x)` (see `conflict-key-derivation-registry.md`), `x` is
  digest-sized in v0, so `ck_id(..)` returns `x` (avoid double-hash) and conflict-key derivation is
  fully deterministic without pinning a structured tuple encoding.

## Rationale

- **Determinism:** digest bytes have a single canonical encoding (raw bytes), avoiding “same id,
  different tuple encoding” drift across tools and profiles.
- **Small privileged surface:** validators only need a length check, not a parsing stack.
- **Hash agility stays profile-scoped:** if we ever transition digest algorithms, we do it at the
  profile level via an explicit D-HASH revision, not by letting multiple encodings leak into privileged seams.

This is compatible with content-addressing practice and hash-naming standards, while keeping the
privileged core minimal. It also keeps future device-automation ordering keyed to an explicit typed
identifier (`device_id`) rather than ambient topology strings or serial hints. (REF-RFC6920, REF-GIT-HASH-TRANSITION, REF-MULTIHASH)

## Human-readable names (optional, non-authoritative)

If a profile needs human-friendly identifiers (UI labels, logs, operator tooling):
- carry them as **separate, non-authoritative metadata** (e.g., `display_name`, `alias`),
- never use them as inputs to conflict-key derivation, ordering scopes, or authorization binding,
- and treat them as redaction-scoped observability fields (I-OBS-1).

## Wiring

- `docs/README.md` links this contract.
- `conflict-key-derivation-registry.md` references this contract and treats the listed ids as
  digest-sized inputs.
- CI drift gate: `tools/check_typed_id_contract.py`.
