# CH-HEALTH v0: Health predicate (schema)

Purpose: pin a **profile-defined, reviewable “boot health” milestone** as a signed, canonical artifact.
This allows mechanisms like CH-BOOTSEL (trial boots + bounded tries) to commit a deployment as “last-known-good” (LKG) only after a *specific*, auditable health condition is met.

This is the capability-OS analogue of:
- Android/boot_control `markBootSuccessful()` for A/B slots,
- ChromeOS “setgoodkernel” marking after integrity checks,
- systemd’s “automatic boot assessment” where user space blesses the boot only after reaching `boot-complete.target`.

References: REF-ANDROID-BOOTCTRL, REF-ANDROID-VERIFIEDBOOT-FLOW, REF-CHROMEOS-UPDATEENGINE, REF-SYSTEMD-BOOT-ASSESS.

## Encoding
Canonical CBOR (D-ENC). JSON MAY be used for authoring but MUST be deterministically transcoded before hashing/signing.

## Design constraints (v0)
- deterministic decode; closed set of keys and check types (I-ENC-1)
- bounded sizes (no unbounded lists/strings); suitable for linting + small validators
- **non-authoritative** by itself: CH-HEALTH describes *what* constitutes health, but does not grant the ability to commit (that remains a capability boundary)
- explicit binding points:
  - CH-BOOT `artifacts` SHOULD include `health_pred` digest
  - CH-BOOTSEL `pending.policy.health_pred_digest` MAY reference the required predicate for that pending activation

## Shape (v0)
A health predicate `hp` contains:
- `schema`: fixed `CH-HEALTH v0`
- `profile_rev`: optional monotonically increasing identifier (ops/debug only; not authority)
- `checks`: bounded list of check clauses (AND-semantics)
- `policy`: optional closed-set object for strictness/timing

### Check clauses (closed set)
Each element of `checks` is an object with:
- `kind`: one of:
  - `uptime_ge_ms`
  - `components_ready`
  - `no_restart_storm`

And kind-specific parameters:

#### `uptime_ge_ms`
- `min_ms`: u64 (bounded by validator, e.g., ≤ 1 day)

Meaning: health requires the system to remain up for at least `min_ms` since boot.

#### `components_ready`
- `cids`: bounded list of component IDs (CH-COMP `cid`)
- `mode`: enum:
  - `all` (default): all listed `cids` must be ready
  - `critical`: all components with `critical=true` (RFC-0017) must be ready; `cids` MAY be empty

Meaning: health requires that components have crossed a “ready barrier” (see RFC-0074).

#### `no_restart_storm`
- `window_ms`: u64 (bounded; e.g., ≤ 10 minutes)
- `max_restarts`: u16
- `scope`: enum:
  - `all` (default)
  - `cids`: the listed `cids` only

Meaning: health requires that the supervision/restart layer did not observe a restart storm within the window.

### `policy` (optional)
Closed set:
- `grace_ms`: u64 (bounded) — allow checks to start evaluating after a grace period
- `require_sealed_after_init`: bool — if true, any `seal_after_init=true` components MUST be sealed/attenuated before being considered ready

## Notes
- v0 intentionally avoids “arbitrary scripts” or embedding a VM. If richer health logic is needed, add new check kinds via RFC.
- Check semantics are **profile-defined** but must be mechanically auditable (recorded in CH-LOG and bindable via CH-HEALTHREC).
