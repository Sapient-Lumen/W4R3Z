# MicroVM resume-admission evidence posture v0 (exact resumed leaf identity is admission-local provenance only)

Purpose: pin the **Phase 1** boundary for **where exact resumed warm-start leaf identity may live** under `ext.microvm`, so “which reusable template leaf or owner-local recovery artifact was resumed?” does not quietly become a guest-visible identity API, a new `CH-ATTEST` meaning, or an ambient control plane.

This doc attaches to **D-MICROVM**, **D-INITSNAP**, **D-CHKPT**, and **D-ATOMICUPD** and makes one hard decision explicit:
**if policy distinguishes which reusable warm-start leaf or owner-local checkpoint was resumed, that fact is admission-local provenance/evidence under the deployment owner; it is not a guest-visible identity surface and it is not self-asserted by resumed software.**

Entropy cost justification: the archive already pins that warm restore is not ambient continuity, that reusable templates are parent-bound leaves, that each leaf resumes only inside one reviewed class, that repair completes before visible work, and that fresh post-restore attestation does not itself identify the resumed leaf. What remains underspecified is **where exact leaf identity is allowed to live**. One narrow posture closes that gap without introducing a new schema family, leaf-id API, or verifier/control-plane surface.

## Posture (v0)

1) **Exact resumed leaf identity is admission-local provenance only**
   - Phase 1 literally pins that **exact resumed leaf identity is admission-local provenance only**.
   - Before guest execution, the owner/runtime may admit **one exact reusable warm-start leaf** or **one exact owner-local recovery artifact** under the already-pinned parent lineage + reviewed resume class.
   - If that exact choice is recorded, it lives in owner-reviewed deployment/provenance evidence such as a local restore receipt, deployment record, `CH-BOOT` / `CH-PROV` binding, or equivalent admission artifact.
   - The portable contract is therefore about **which artifact the owner admitted**, not about a self-description the resumed guest can mint after the fact.

2) **Phase 1 adds no guest-visible leaf-id API**
   - Phase 1 literally adds **no guest-visible leaf-id API** for “which reusable template leaf/checkpoint am I?”.
   - `VMClock vm_generation_counter` and `VMGenID` remain clone/restore hygiene signals only: they indicate **non-unique state**, not exact leaf identity.
   - resumed software MUST NOT self-assert its own warm-start leaf identity as authority-bearing truth for remote policy, secret release, or deployment admission.
   - Guest logs or self-reported labels may exist for debugging, but they are observational and cannot override the owner-local admission record.

3) **Any exported leaf digest reuses existing provenance surfaces**
   - If an operator wants remote parties or auditors to know which admitted reusable leaf/recovery artifact was resumed, any exported digest/binding MUST ride on **existing provenance/admission surfaces** such as `CH-BOOT`, `CH-PROV`, or an owner-signed deployment/restore receipt.
   - Phase 1 literally standardizes **no new `CH-*` field or role** for exact warm-start leaf identity, and **no new `CH-ATTEST` claim** for it.
   - In plain terms: if leaf identity is exported at all, the export is a deployment/provenance choice layered on existing artifacts rather than a new guest-visible schema or control plane.

4) **Snapshot/template packaging remains host/deployment trust, not guest self-description**
   - Firecracker-style snapshot files, memory files, and packaging metadata remain trusted deployment inputs whose lifecycle/integrity is governed outside the resumed guest.
   - Exact resumed leaf identity therefore follows the owner’s package/admission chain, not guest self-report after resume.
   - A fresh quote/report/token can re-prove boot/provenance lineage + freshness for the current generation, but it does not let the guest unilaterally redefine which admitted reusable leaf the owner resumed.

5) **No new ambient verifier or restore-management plane**
   - Phase 1 adds **no new `CH-*` schema**, **no new ACP kind**, **no new conflict-key family**, and **no new host↔guest callback plane** for warm-start leaf identity.
   - If a later design wants portable exact leaf manifests, verifier-visible leaf identifiers, or policy language over resumed-leaf identity, it must pay an RFC-first cost with explicit schema, conflict/ordering semantics, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable leaf-manifest or checkpoint-identity schema.
- No in-guest API that reveals one exact admitted reusable leaf/checkpoint identity as authority-bearing truth.
- No generic remote-verifier policy language for warm-start leaf identity.
- No host-side snapshot packaging/signing protocol specified here.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-INITSNAP, D-CHKPT, D-ATOMICUPD)
- Adjacent postures:
  - `microvm-attestation-scope-posture-v0.md`
  - `microvm-template-lineage-posture-v0.md`
  - `microvm-template-resume-class-posture-v0.md`
  - `microvm-restore-repair-barrier-posture-v0.md`
  - `attestation-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
  - `rfcs/0064-confidential-computing-profile.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-10)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-RESUME-ADMISSION-EVIDENCE)
- Policy posture:
  - exact resumed warm-start leaf identity adds **no new lane**, **no new guest-visible identity plane**, and **no new portable verifier/control plane** in Phase 1.

CI drift gate:
- `tools/check_microvm_resume_admission_evidence_posture.py` fails `make lint` if this posture stops being discoverable, loses its **admission-local provenance only / no guest-visible leaf-id API / no new CH-ATTEST field or warm-state identity plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-AWS-SNP-ATTEST.
- REF-LINUX-TDX.
