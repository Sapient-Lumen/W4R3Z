# Cross-cluster replication & consistency contracts (v0)

Hybrid multicore (ADR-0005) assumes **explicit cross-cluster ownership** rather than accidental shared state.
This doc pins the **v0 contract vocabulary** for cross-cluster metadata so that:
- we can state (and later verify) what must be single-owner vs replicated,
- we avoid reintroducing an ambient “global kernel” via hidden coordination,
- and we keep authority non-amplifying when state is copied/merged across clusters.

**Status:** v0 contract vocabulary + CH-REPLCONTRACT v0 seam. This is intentionally conservative.

## Non-negotiable posture

- **Replication is non-authoritative.** Replicated artifacts must not grant authority; at most they can *describe* state (or support deny-only routing/policy).
- **Capabilities are local.** Raw kernel capabilities/handles are not “replicated.” Cross-cluster access is via explicit gateways/proxies/portals (e.g., CapRPC), not by copying bearer handles.
- **Fail closed.** If the replication contract is missing/invalid for a profile, cross-cluster operations that depend on it must deny/stop rather than guess.

## What we need from a replication contract

For each object family that can be observed or used across clusters, we want to write down:
- **owner model**: who is allowed to mutate authoritative state (one cluster? a set?)
- **replication class**: how replicas are updated/merged (if at all)
- **coordination requirement**: whether order is part of the spec (D-COMMUTE + hot-action boundaries)
- **evidence hooks**: what tests/proofs we need to prevent accidental order dependence or authority amplification

We pin this as an explicit artifact seam: **CH-REPLCONTRACT v0**.

## Replication classes (RC-v0)

These are *contract classes*, not implementation mandates. Implementations MAY be stricter than required, but must not be weaker.

- **RC0 Local-only**
  - State is meaningful only within one cluster.
  - Cross-cluster references must be via a proxy object that is itself explicitly routed.

- **RC1 Owner-sharded (single-writer)**
  - Each object instance has exactly one **owner cluster**.
  - Other clusters may cache read-only summaries (bounded, epoch-tagged), but updates are routed to the owner.

- **RC2 Epoch snapshots (replace-with-epoch)**
  - The owner periodically publishes a bounded snapshot with a monotonic **epoch**.
  - Replicas accept only non-decreasing epochs; merges are `max(epoch)` with replace semantics.
  - Suitable for read-mostly metadata where “latest wins” is acceptable.

- **RC3 Commutative merge (SEC-style)**
  - Replicas can accept updates locally and merge without coordination because updates are designed to commute/merge safely.
  - Use only for *bounded* metadata with explicit monotonic/merge semantics (CRDT-like patterns; REF-CRDT-INRIA11).

- **RC4 Ordered log (append-only, consistency-checkable)**
  - Global order is required by the spec (non-commutative by definition).
  - Express this as an **append-only log** with signed checkpoints / consistency proofs when enabled (REF-CT-RFC6962, REF-CT-RFC9162). Optional hardening: cosign checkpoints with independent witnesses (REF-COSI-2015, REF-TRANSPARENCY-WITNESS).
  - Prefer moving “order-required” semantics to an ordered log rather than smearing ordering constraints across many objects.


## RC4 admission posture (v0)

RC4 (ordered-log) semantics are intentionally hard to admit under Hybrid because they smuggle global order back into the substrate.

v0 rule:
- `replication_class = rc4_ordered_log` is **reserved to `object_family = tlog`** (see `replication-object-family-registry.md` and `profile-repl-defaults.md`).
- Any other use of RC4 requires an explicit D-REPL update (why order is correctness-required, where serialization lives, and what evidence will keep it honest).

Motivation: most “timeline order” desires are UI/presentation needs; the substrate should prefer RC3 commutative event sets + canonicalization, or RC2 snapshots, and push any evidence-bearing global order into a dedicated log lane (`tlog`) rather than infecting multiple object families.

## Default stance for the v0 hot action surface

This does **not** expand the hot surface; it states how cross-cluster concerns should be handled for the already-pinned families:

- **mem.map / mem.unmap**
  - Default: **RC0 local-only** per address-space home cluster.
  - If a profile allows cross-cluster shared regions, it must be explicit (D-IOBUF) and use owner-sharded metadata; the mapping primitive itself remains local.

- **ipc.* endpoint operations**
  - Endpoints are **RC0 local-only**.
  - Cross-cluster calls are via capability-RPC/proxies; any ordering requirements live in the proxy protocol contract (CH-CONTRACT) and are transcript-visible.

- **view.attach / view.detach**
  - Default: **RC1 owner-sharded** per `view_id`.
  - Replicated `view` data is **owner-routed slot-binding metadata only**: read-only summaries may be cached with epochs (RC2), but they must not auto-attach, auto-detach, or otherwise activate bindings in a receiver's local active view. Authoritative attach/detach stays routed to the owner cluster (see `view-replication-boundary-v0.md`).

- **transcript/receipt append**
  - Default: **RC3 commutative merge**: transcripts are treated as a content-addressed event set; append is commutative and export order is canonicalized.
  - Replicated `transcript` data is **content-addressed CH-LOG event-set evidence only**: it may help audit/replay bundles/diffing, but it must not satisfy missing approval/policy/capability checks, authorize replay/resubmission, instantiate imported handles or leases, or turn transcript arrival order into a runtime sequencing/freshness oracle (see `transcript-replication-boundary-v0.md`).
  - Replicated `receipt` data is **immutable digest-addressed evidence only**: it may help audit/explain/offline correlation, but it must not satisfy missing approval/policy/capability checks, authorize replay/resubmission, or reissue/import handles or leases named by receipt fields (see `receipt-replication-boundary-v0.md`).
  - If a profile needs strict “timeline order,” treat it as a **presentation** rule by default; if it must be evidence-bearing, route the ordered slice through `object_family=tlog` (RC4 reserved) rather than upgrading transcripts/receipts to RC4.

- **quota/budget charge**
  - Default: **RC3 commutative merge** for additive charge summaries under **already-issued local credit**, but **mint/revoke/split/grant** is **RC1 owner-sharded** (non-commutative boundary lives with the owner).
  - Replicated `quota` data is **observational only**: it supports audit/reconciliation and must not become remote admission authority or implicit quota borrowing (see `quota-replication-boundary-v0.md`).
  - Replicated `budget` data is **owner-routed issuer / lease-lineage metadata only**: non-owner caches may aid routing/audit/staleness checks, but they must not mint local spend authority, widen leases, or infer portable credit from cached lineage state (see `budget-replication-boundary-v0.md`).

- **namecert bundle gossip / sharing**
  - Default: **RC3 commutative merge** for **immutable signed CH-NAMECERT bundle sets** scoped by `name_domain`. Merge is set union by digest.
  - Replicated `namecert` data is **bundle evidence only**: it may make more signed bundles visible, but it must not auto-install active bindings, auto-prefer “latest” arrivals, become a global namespace / privileged resolver, or rewrite the local trust-anchor set. Local explicit naming policy still chooses trust roots, visibility, freshness, and any view materialization (see `namecert-replication-boundary-v0.md`, `namecert-trust-root-boundary-v0.md`).

- **caprpc_proxy route/bootstrap metadata**
  - Default: **RC1 owner-sharded** per `endpoint_id`. Replicas may cache bounded read-only route/bootstrap metadata (owner cluster, endpoint id, interface digest, epoch, route hints) to find the owner.
  - Replicated `caprpc_proxy` data is **metadata only**: it must not create a callable proxy, replay connection-local handle ids, promised-answer paths, or restore/import remote authority implicitly. Actual use still requires an explicit live proxy/handle or explicit CH-CAPX / CH-SREF import/restore event bound locally (see `caprpc-proxy-replication-boundary-v0.md`).

- **tlog checkpoint / proof distribution**
  - Default: `object_family = tlog` is the dedicated **ordered evidence lane**. Replicas may mirror signed checkpoints, inclusion/consistency proofs, tiles, and optional witness bundles scoped by `log_id`.
  - Replicated `tlog` data is **evidence only**: local policy still pins accepted log identities/public keys/witness thresholds and decides whether missing anchors are advisory or rejecting. Checkpoint order/tree size must not become a general runtime ordering bus, lease clock, or admission oracle (see `tlog-replication-boundary-v0.md`).

These defaults are intended to keep global order rare and explicit.

## Evidence hooks (v0)

- **PO-REPLCONTRACT-VALIDATE**: CH-REPLCONTRACT decode is total/bounded/closed-enum; owner cluster ids are valid under CH-CLUSTERMAP.
- **PO-REPL-NOAMP**: replication artifacts cannot grant authority (they may only narrow/deny or describe).
- **PO-REPL-MERGE**: for RC3 objects, merge/apply is commutative/associative/idempotent (bounded domains), and is compatible with D-COMMUTE tests.

- Drift gate: **EVID-2026-214** pins the `object_family` allowlist + A–D defaults + RC4 admission posture (prevents Hybrid drift into ad-hoc RC4 uses).

See also: `commutativity-and-interface-scalability.md`, `hot-action-boundaries-v0.md`, `quota-replication-boundary-v0.md`, and `cluster-derivation.md`.
