# Profile hash suite v0 (D-HASH; SHA-256, fixed length)

Purpose: remove ambiguity around the archive-wide notion of **"profile hash"** / **"profile digest length"**.
Many CH-* artifacts and validator rules rely on a fixed-length digest for:
- `digest(CH-XYZ vN)` references,
- typed ids on pinned seams (D-TYPEDID),
- conflict keys / ordering scopes (D-COMMUTE; CH-CONFLICTKEY / CH-ORDERTOK), and
- receipt correlation hooks (CH-DENY/CH-ACPOUT/CH-FADAPT).

If the hash suite is left implicit, implementations drift (length mismatches, mixed algorithms, human-facing encodings leaking into privileged seams).

Decision surface: **D-HASH**.

Non-goals:
- This does **not** pick a signature scheme (that is D-UPD-SIGN).
- This does **not** define a self-describing digest format (e.g., multihash) for v0.
  If/when we need hash agility across deployments, we introduce it explicitly on *non-privileged* seams first (e.g., CH-AREF locators), with a migration story.

## Normative rule (v0)

For v0 of the archive-wide "profile hash":

- `digest(bytes)` := **SHA-256(bytes)**
- `hashlen` := **32** bytes

Any validator/decoder rule that says "digest length matches the profile hash" means:
- the value is a `bstr`,
- the byte length is exactly `hashlen` (32),
- and the bytes are interpreted as the raw SHA-256 output (no base16/base64 wrappers in privileged seams).

References:
- REF-FIPS180-4 (normative algorithm definition)
- REF-RFC6234 (SHA-2 parameterization + conventions)

Meaning of `digest(CH-XYZ vN)`:
- The digest is taken over the schema's **canonical bytes** (`schema-canonical-bytes-v0.md`).
- `digest(CH-XYZ vN)` is shorthand for `digest(canonical_bytes(CH-XYZ vN, x))`.

## Human display encoding (non-authoritative)

When a digest must be shown to humans (logs, UI, CLI):
- represent it as **lowercase hex** (base16) of the raw bytes,
- never treat the string form as an authority input,
- and never accept both encodings on a privileged seam without an explicit schema revision.

Rationale: hex is ubiquitous, deterministic, and avoids accidental whitespace/locale transformations.

## Upgrade posture (keeps drift contained)

- v0 deployments MUST NOT mix multiple digest algorithms within one validator domain.
- If a future revision changes the profile hash suite, it must:
  1) be a new decision-map entry revision (D-HASH v1+),
  2) explicitly enumerate the affected seams (typed ids, conflict keys, receipts, CH-AREF),
  3) provide a transition plan (dual-writing / dual-verification only where unavoidable), and
  4) introduce any self-describing digest formats only on non-privileged seams first.

Practical lessons: Git's SHA-1 → SHA-256 transition is a cautionary tale about letting multiple encodings leak into core seams (REF-GIT-HASH-TRANSITION).

## Wiring

- This doc is referenced from:
  - `docs/30-architecture/decision-map.md` (D-HASH),
  - `docs/30-architecture/conflict-key-derivation-registry.md` (definition of `digest(..)`/`hashlen`), and
  - `docs/30-architecture/typed-id-contract-v0.md` (definition of `hashlen`).
- CI drift gate: `tools/check_profile_hash_suite.py`.
