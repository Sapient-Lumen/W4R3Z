# D-RCU posture v0 (QSBR-first; no ambient/global grace domain)

Purpose: pin an implementable v0 meaning for **D-RCU** so read-mostly sharing stays cheap for readers without quietly importing a global collector, a new portal family, or a kernel-sized policy surface.
It narrows RFC-0112 into a small posture validators and harnesses can reason about: per-subsystem domains, explicit quiescent progress, bounded retirement, and fail-closed stall handling.

## Posture (v0)

1) **User-space, per-subsystem GraceDomain by default**
   - If D-RCU is enabled, the default seam is a **user-space GraceDomain service/library** scoped to one subsystem/runtime, not a new ambient kernel facility.
   - A kernel object or kernel-managed participant registry is out of scope for v0 unless evidence later shows user-space cannot meet the bounds/latency contract.

2) **QSBR-first in Phase 1; EBR is runtime-local, not ecosystem-global**
   - Phase 1 prefers **QSBR** for turn-based/event-loop/driver-host components: quiescent progress is declared at explicit safe points (turn boundaries, poll iterations, or after processing an inbound message).
   - **EBR** MAY exist inside a runtime-owned implementation where threads cannot honestly provide quiescent points, but it remains local to that runtime/domain rather than a system-wide policy seam.
   - D-RCU v0 does **not** standardize hazard pointers or a mixed global collector contract.

3) **No system-wide or cross-component GraceDomain**
   - There is no ambient, system-global “everyone shares one epoch” facility in v0.
   - Domain membership is explicit, bounded, and local to the subsystem that owns the read-mostly structure.
   - This keeps D-RCU from turning into a cross-component activity oracle or a hidden scheduler dependency (I-RCU-1; PO-RCU-NOORACLE).

4) **Grace-period waiting must block, not poll**
   - `synchronize()` MUST have explicit, deterministic outcomes and MUST NOT silently degrade into busy-wait loops or scheduler-tick polling (I-RCU-2).
   - If D-UWAIT is enabled, implementations SHOULD block on explicit epoch/quiescent counters.
   - If D-WAITSET is enabled, implementations MAY surface grace completion as a waitable signal.

5) **Retirement/backlog is bounded and attributable**
   - Participant registrations, limbo nodes, and deferred-free backlogs MUST be bounded per GraceDomain and attributable to an explicit owner/payer when D-METER is enabled (I-RCU-3; PO-RCU-BOUND).
   - Overflow behavior is explicit and fail-closed: reject new retirements/registrations, shed the caller into a slower safe path, or escalate to supervision; never silently grow unbounded limbo.

6) **Stalls are a liveness failure, not an excuse for infinite limbo**
   - D-RCU does not “solve” stuck readers; a participant that fails to report quiescence within its declared bound is a liveness failure for D-SUPV / D-PRESSURE handling.
   - Production profiles SHOULD restart/kill/recover the offender or fail-close the dependent service rather than letting reclamation debt grow forever.

7) **No new workflow / ACP surface in v0**
   - D-RCU v0 does **not** introduce a new portal family, CH-* request schema, or CH-ACP automation kind.
   - GraceDomain operations are local implementation calls inside a component/runtime, not a cross-domain workflow surface.
   - Therefore **no new conflict-key family is introduced in v0**. Any future explicit admin/automation surface (for example, domain drain/collect controls) must land RFC-first with its own conflict keys, commutativity rules, serialization boundary, and receipts.

8) **Retired objects stay implementation-owned and generation-safe**
   - Deferred reclamation covers implementation-owned nodes/records for read-mostly structures; it must not become a generic capability transport or destructor callback substrate that can run with widened authority.
   - If retired nodes embed identifiers that can be reused, generation/epoch safety must prevent ABA-style confusion on reuse.

9) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY use internal host/runtime reclamation mechanisms behind the membrane, but v0 does not standardize any ambient host RCU/epoch handle or compat-visible “global collector” channel.
   - Any compat bridge that depends on RCU-style progress remains killable by policy and must not recreate hidden path/env/network side channels.

## Phase 1 non-goals (explicitly deferred)

- A general tracing GC / region-GC / language-runtime memory-management spec.
- A system-global GraceDomain or kernel-owned “collect everyone” epoch service.
- A new workflow / portal / ACP admin surface for grace-domain control.
- Standardizing hazard pointers, mixed EBR+HP collector policies, or cross-machine reclamation protocols.

## Wiring

- Decision surface: `decision-map.md` (D-RCU).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (grace-period seam)
  - `rfcs/0112-grace-periods-and-deferred-reclamation.md` (option space / evidence seed)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-RCU-1, I-RCU-2, I-RCU-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-RCU-BOUND, PO-RCU-NOORACLE)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_rcu_posture.py` fails `make lint` if this posture stops being discoverable, loses the QSBR-first / no-global-domain / bounded-stall posture, or drops its primary REF wiring.

## References

- REF-LINUX-RCU-CONCEPTS.
- REF-LINUX-RCU-CHECKLIST.
- REF-HART-MEMRECL-IPDPS06.
- REF-LIBURCU.
- REF-CROSSBEAM-EPOCH.
- REF-CONCURRENCY-KIT.
