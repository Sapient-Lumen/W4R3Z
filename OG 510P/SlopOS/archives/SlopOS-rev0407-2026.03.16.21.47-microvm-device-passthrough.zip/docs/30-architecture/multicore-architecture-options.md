# Multicore architecture options (SMP, multikernel, hybrids)

This doc expands D-CONC and D-MK with a “mile-high but concrete” comparison.
Goal: keep multicore verification and scalability requirements explicit so we do not drift into an architecture that cannot meet our own claims.

## Non-negotiable premise

We intend multicore correctness to be part of our flagship verified slice, not a deferred add-on. UP-only prototypes are acceptable for bring-up, but **UP-only proofs are not our end state**.

## First decision: define “scale”

We need an explicit scale target because it drives architecture.

- **Closely-coupled SMP**: ~8–32 cores, shared LLC, mostly uniform latency.
- **Many-core / NUMA / chiplets**: ~64–256+ logical cores, multiple sockets/NUMA domains, latency variation dominates.

D-MK must record the target class.

## Option A — Shared-kernel SMP with a big kernel lock (BKL)

**Shape**: one kernel instance; a global lock serializes most kernel critical sections.

**Why it exists**: microkernels have short, bounded kernel entries; contention can be low enough that BKL is “good enough” on closely-coupled cores.

- Evidence precedent: *For a Microkernel, a Big Lock is Fine* argues BKL can scale well for microkernels on modest core counts (REF-SEL4-BIGLOCK-APSYS15).

**Verification impact**:
- Kernel functional correctness is close to the sequential abstract machine.
- We still must verify the lock’s correctness and its interaction with interrupts/preemption; a rely/guarantee verification path exists in the literature (REF-SEL4-LOCK-VERIF-ARXIV24).

**Risk**: once we build policies/data structures that implicitly assume a global serialization point, we may accumulate “hidden sharing” that makes later scaling painful.

**When it’s a good default**:
- We target ≤32-ish closely-coupled cores in early phases.
- We want multicore verification early with minimal proof surface.

## Option B — Shared-kernel SMP with sharding/replication (clustered objects)

**Shape**: still one kernel instance, but shared state is aggressively reduced:
- per-core or per-cluster replicas;
- partitioned queues and registries;
- shared state is *explicitly* opted into and paid for.

This is the “middle path”: keep SMP structure, but adopt multikernel lessons inside a single kernel.

Evidence precedents:
- Tornado argues for multiple implementations of OS objects based on sharing degree (REF-TORNADO-OSDI99).
- K42’s clustered object model uses distribution/replication/partitioning to scale shared objects (REF-K42-COMPLETE-06).

**Verification impact**:
- Harder than BKL because invariants become conditional on shard ownership.
- But easier than a full multikernel if we keep the replication protocols simple and local.

**Risk**: complexity creep if we create many bespoke sharding schemes without a uniform contract.

**Mitigation**: standardize “ownership + replica” patterns as part of the abstract machine and schema-pinned registries.

## Option C — Multikernel (per-core kernel instances + explicit messages)

**Shape**: treat the machine as a network of cores.
- Each core runs a kernel instance; most state is per-core.
- Shared/global state is modeled as replicated state with explicit synchronization protocols.

Evidence precedent: the multikernel model and Barrelfish argue for message-passing OS structure to tame sharing and scale on many cores/heterogeneous hardware (REF-MULTIKERNEL-SOSP09; see also REF-BARRELFISH).

**Verification impact**:
- In-kernel shared-memory concurrency shrinks, but we now have distributed-systems proof obligations:
  - message protocol correctness,
  - replication consistency (even if weak/eventual for some metadata),
  - failure handling across cores.

Depending on what we choose to replicate/centralize, this can be **easier** (no complex shared-memory interleavings) or **harder** (protocol reasoning everywhere).

**Performance impact**:
- Potentially best on NUMA/many-core, because the default is locality.
- May cost latency for operations that require cross-core coordination.

**Risk**: “kernel becomes a distributed system” and the ecosystem/tooling must treat it that way.

## Option D — Application-directed sharing (Corey-style)

**Shape**: kernel avoids sharing by default; applications explicitly request shared structures when needed.

Evidence precedent: Corey’s design principle is “applications should control sharing,” pushing the OS to keep data private unless directed otherwise (REF-COREY-OSDI08).

**Why it matters to us**:
- Our world already prefers explicitness (capabilities + manifests + schemas).
- We can expose “share scopes” as explicit configuration artifacts rather than hidden kernel heuristics.

**Verification impact**:
- Attractive if we can make “share scope” a first-class, audited, bounded concept.
- Risk: if apps must micromanage sharing, we may lose usability unless we provide good defaults and tooling.

## Option E — Hybrid: multikernel across NUMA, SMP within a cluster

**Shape**:
- Within a “cluster” (e.g., a socket / CCD / NUMA region), use SMP (possibly BKL or sharded).
- Across clusters, use multikernel-style messaging and replication.

This matches what the multikernel literature itself notes: sharing can be a *local optimization* when it is faster, while the global structure remains message-passing (REF-MULTIKERNEL-SOSP09).

**Why it’s compelling**:
- Lets us keep a simpler in-cluster proof story while still aiming for many-core scale.
- Makes “hardware topology as data” (CH-HWFACT/SKB) genuinely useful for placement.

**Verification impact**:
- Two proof regimes, but each is simpler than the fully-general alternative.

## What we should optimize for

Given the non-negotiables (verified multicore + all four profiles), the safest direction is:

1) **Pick an early baseline we can verify**: BKL SMP is a practical “Phase 1 verified multicore” anchor if our near-term scale target is modest (now pinned in `cluster-phase1-envelope-v0.md` as **<=64 logical CPUs**, **<=8 clusters**, **<=16 logical CPUs per cluster**).
2) **Architect for migration**: treat state ownership and topology as explicit, so we can evolve toward hybrid/multikernel without ABI break.
3) **Standardize the sharding/replication story** early (even if unused): prevent hidden sharing from becoming “how it works.”

## Current direction

We adopt **Hybrid** (multikernel across clusters/NUMA; SMP within a cluster) and treat **commutativity** as a required spec discipline (ADR-0005).
Cross-cluster replication contracts are now pinned as an explicit artifact seam (`replication-contracts-v0.md` 2192 CH-REPLCONTRACT v0, ADR-0006). Phase 1 also narrows `preferred_boundary = auto` so default clustering is **NUMA → socket → core_group** rather than opportunistic die/chiplet partitioning (`cluster-auto-boundary-v0.md`), freezes CH-HWFACT cache/LLC facts as **placement hints only** rather than new authority boundaries (`cache-topology-authority-boundary-v0.md`), freezes asymmetric CPU-capacity / performance-class facts as **placement hints only** rather than ownership or budget/replay selectors (`cpu-capacity-authority-boundary-v0.md`), freezes NUMA-distance / HMAT latency-bandwidth / memory-tier facts as **placement hints only** rather than distance-adaptive ownership or authority selectors (`memory-locality-authority-boundary-v0.md`), and freezes the flagship claim envelope at **<=64 logical CPUs**, **<=8 clusters**, and **<=16 logical CPUs per cluster** (`cluster-phase1-envelope-v0.md`). `hybrid-phase1-boundary-v0.md` records that these decisions now close the Phase 1 Hybrid authority/claim surface; remaining work is later-phase evidence and RFC-first expansion beyond that envelope.

## Decision guidance (D-CONC / D-MK)

Under ADR-0005 we adopt Hybrid as the default direction. D-MK should still record:
- Scale target class (closely-coupled vs NUMA/many-core).
- Baseline architecture (A/B/C/D/E) and what is permitted as a local optimization.
- Verification plan: what is proved in Phase 1/2, and what is an explicit non-claim.
- Operational implications: failure modes, monitoring, and replay/determinism posture.



## Orthogonal — Interface-first scalability (commutativity) (D-COMMUTE)

This is not a kernel topology choice; it is a **spec/interface discipline** that composes with SMP, multikernel, and hybrid.

If the *spec* of operations says they commute, then there exists an implementation that can scale those operations on multicore by avoiding needless coordination (REF-SCR-TOCS15).  
In practice this becomes a design rule: **avoid making order observable unless required**, and make any required ordering explicit and rare.

How it helps Hybrid:
- reduces cross-cluster coordination needs by pushing work into commutative/sharded regions,
- makes serialization points explicit (and therefore optimizable and auditable),
- gives us a testable contract for “this should scale.”

See: `commutativity-and-interface-scalability.md` (D-COMMUTE) and `hot-action-surface-v0.md` (pinned hot surface v0).
