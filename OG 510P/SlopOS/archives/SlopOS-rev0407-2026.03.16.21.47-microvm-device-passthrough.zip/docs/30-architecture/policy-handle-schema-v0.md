# CH-POLICYHANDLE v0: policy handle descriptor (optional; D-POLICY)

Purpose: provide a **digestable, non-authoritative handle** naming the effective veto-only policy semantics in force when a validator makes a decision.

Why this exists:
- In some profiles (notably embedded/separation-kernel-ish deployments), policy may be **built in** or **compiled** and not shipped as a CH-POLICY bundle artifact.
- We still require policy/authority denials to name *which policy handle* was in force on the stable CH-DENY surface (avoid ambient/log-only explanations).

CH-POLICYHANDLE is **not** authority and MUST NOT contain bearer capability material.
It is an **audit/evidence anchor** only.

Related:
- `policy-bundle-schema-v0.md` (CH-POLICY v0, policy bundle)
- `denial-receipt-schema-v0.md` (CH-DENY v0)
- D-POLICY: `docs/30-architecture/decision-map.md`

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-POLICYHANDLE-v0 {
  schema: "CH-POLICYHANDLE";
  version: 0;

  # Policy evaluation posture.
  # v0 is veto-only by design (D-POLICY).
  mode: enum { veto_only };

  # Evaluator identity (names semantics).
  engine: enum { cedar, wasm, builtin };
  engine_rev: string;           # <= 64 bytes (or a digest tag)

  # Digest naming the effective policy artifact.
  # Examples:
  # - digest(CH-POLICY v0) if policy is shipped as a bundle
  # - digest of compiled IR / bytecode / signed image section for builtin policies
  policy_artifact_digest: bstr; # bounded (profile hash length)

  # Optional pinned inputs permitted to influence decisions.
  # This is an audit hook: it is *not* a capability grant.
  inputs?: [
    {
      name: string;             # <= 32 bytes (e.g., "cfg_digest", "comp_digest")
      schema: string;           # <= 32 bytes (e.g., "CH-CFG v0")
      digest: bstr;             # bounded (profile hash length)
    }
  ];

  # Optional profile label (A–D or profile-specific), for audit.
  profile?: string;             # <= 32 bytes
}
```

## Validation rules (summary)
A CH-POLICYHANDLE validator MUST be total and fail closed:
1) `schema == "CH-POLICYHANDLE"` and `version == 0`.
2) `mode == veto_only`.
3) `engine` is in the closed enum; `engine_rev` length <= 64 bytes.
4) `policy_artifact_digest` length matches the profile hash length.
5) If `inputs` is present:
   - list length <= 16.
   - each `name` and `schema` is bounded (<= 32 bytes), and each `digest` length matches the profile hash length.
6) If `profile` is present, it is bounded (<= 32 bytes).

## Security posture
- **Non-authoritative**: CH-POLICYHANDLE does not grant authority; it only names policy semantics.
- **No ambient channels**: it carries digests and bounded labels only (no raw paths, env, network identifiers).
- **Fail closed**: unknown fields/variants reject; invalid encodings reject.

## Receipt usage
When CH-DENY v0 is emitted for policy/authority failures (`missing-approval`, `expired-approval`, `policy-deny`), producers MUST bind `reason.kind="policy"` and MUST bind `reason.ref_digest` to either:
- `digest(CH-POLICY v0)` (when the policy bundle is available), or
- `digest(CH-POLICYHANDLE v0)` (when policy is builtin/compiled and represented by a handle).

This keeps “which policy was in force?” **non-ambient** and transcript-visible.
