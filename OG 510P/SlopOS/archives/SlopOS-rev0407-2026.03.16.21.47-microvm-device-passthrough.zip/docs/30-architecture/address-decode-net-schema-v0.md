# CH-ADDRNET v0: Address decoding net schema

Purpose: pin a **bounded translation graph** used for boot-time table synthesis/validation (D-ADDRNET).

This is not a full SoC description language. It is a compact, audit-friendly artifact that captures the translation structure relevant to isolation claims.

## Design rules
- closed-world: unknown keys/variants reject
- bounded sizes: cap nodes/edges per profile
- canonical encoding: I-ENC-1
- no embedded blobs: refer to large platform descriptions by digest

## Canonical shape (informal)

```text
AddrNet {
  schema: "CH-ADDRNET-v0",
  platform_id: String,
  scope: {
    kind: "cpu_mmu_only" | "cpu+iommu" | "full_interconnect_subset",
  },
  nodes: [Node],
  edges: [Edge],
  digests: {
    hwfacts?: DigestRef,
    platform_model?: DigestRef,
  }
}

Node {
  nid: String,
  kind: "va_space" | "pa_space" | "device" | "decoder" | "iommu",
  accepts: [Range],          // optional; allowed local-address ranges
}

Edge {
  from: String,              // nid
  to: String,                // nid
  kind: "translate" | "alias" | "decode" | "block",
  rule: {
    src: Range,
    dst: Range,
    perms: Perms,
    attrs?: Attrs,
  }
}

Range { base: u64, size: u64 }
Perms { r: Bool, w: Bool, x: Bool }
Attrs { cache?: String, share?: String }
DigestRef { alg: String, hex: String }
```

## Validation requirements (must)
- `nid` uniqueness; edges reference existing nodes
- bounds on `nodes` and `edges`
- `Range` alignment rules per profile (page size / granularity)
- no “implicit allow”: the absence of a path is deny by default
- no “mystery edges”: all translation paths relevant to isolation must be representable by the declared edge kinds in this schema

## Binding
If used, list the CH-ADDRNET digest in CH-BOOT `artifacts` under a role like `addrnet`, and export it via IF-OBS/CH-LOG.
