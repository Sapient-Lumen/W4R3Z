# D-PLUMB portal-session posture v0 (provider-owned; single-outcome; family-local)

Purpose: pin an **implementable Phase 1** meaning for generic portal request/session objects so D-PLUMB does not quietly widen into a durable resumable broker, a live-object inventory API, or a family-agnostic callback/rendezvous protocol.
It narrows the already-present portal/session idea in RFC-0046 into a compact core posture validators and harnesses can reason about: provider-owned control objects, one terminal outcome per request, family-local long-lived sessions only when a specific portal family needs them, and no generic resume/list/watch surface.

This doc is intentionally narrow: it does **not** design any one portal family, a backend-selection policy layer, or a persistence model for documents/capture/background workflows.

## Posture (v0)

1) **Provider-owned request/session objects; callers do not mint rendezvous identities**
   - Portal methods may return opaque request/session handles or object references, but those objects are **provider-owned control objects** for the lifetime of one interaction or one family-specific live session.
   - Requesters do **not** choose callback object paths, port names, request IDs, or session names that other principals can later target.
   - Request/session objects are not portable capability exports, not generic IPC endpoints, and not a second application-facing namespace.

2) **One request → one terminal outcome**
   - A portal request has exactly one terminal outcome in v0: grant/success, deny, cancel, or provider-declared failure.
   - After the terminal outcome, the request object is finished; Phase 1 does **not** promise repeated responses, durable replay, or “pick the result up later from another inbox.”
   - Retries are explicit new requests under the caller’s current D-REQCTX / D-VOLITION / policy state.

3) **Long-lived sessions are family-local, not a generic resumable core seam**
   - Some portal families may need a live session object (for example capture/inhibit/automation style workflows), but the generic D-PLUMB core does **not** standardize a family-agnostic persistence, resume, restore-token, or session migration protocol.
   - Any persistence/restore semantics must be justified and pinned **inside the specific family RFC/posture** (for example explicit CH-DOCREF reopen or an eventual capture persistence RFC) rather than back-propagating into every portal family by default.
   - Phase 1 therefore treats “request/session object still exists” as a live runtime fact, not as a portable durable capability.

4) **Close/abort is explicit and fail-closed**
   - Portal/session providers may explicitly close or abort a request/session object; requester death, portal restart, logout, or policy disable may also terminate it unless a narrower family posture says otherwise.
   - Phase 1 does **not** guarantee background completion after requester death or shell/session teardown.
   - Any family that needs a stronger continuity story must specify it with an explicit descriptor/evidence surface.

5) **Results are typed artifacts/handles; request/session objects themselves are not authority**
   - Completion returns already-declared capability handles, leased endpoints, typed CH-* descriptors, receipts, or denials.
   - The request/session object itself is only lifecycle/control state; copying its identifier must not grant fresh authority, widen existing authority, or act as a durable reopen selector.
   - Descriptor digests remain attribution/audit surfaces, not hidden session-resume tokens.

6) **No generic list/watch/inventory API for live or historical portal objects**
   - Phase 1 exposes no family-agnostic application-visible API to enumerate active requests, historical requests, or other applications’ live sessions.
   - Shell/provider diagnostics may exist, but they are not the portable app-facing seam and must remain policy-owned.
   - If a family later needs list/watch semantics, that cost must be paid **in that family’s own RFC/posture** rather than inferred from the generic existence of sessions.

7) **No caller-supplied callback/return rendezvous on the core seam**
   - Completion flows on the provider-owned response path for the request/session object, not via caller-specified callback URLs, return ports, or app-registered mailbox endpoints.
   - Portal cores therefore stay compatible with the D-PLUMB rule that workflow outcomes are request-local and receipt-bound rather than a second callback protocol.

8) **Ordering stays inside each portal family implementation**
   - Request/session lifecycle transitions for one live family object are intentionally non-commutative: create/start/renew/close/cancel must serialize at the owning portal family implementation.
   - Serialization boundary: `svc:portal.<family>`.
   - D-PLUMB portal-session posture introduces **no new CH-ACP kind, no new conflict-key family, and no cross-family ordering service** in v0.

9) **Sealed compat remains killable and non-ambient**
   - Foreign Cell integrations must flow through the same provider-owned request/session path as native callers.
   - Compat runtimes do not gain a hidden callback broker, a resumable session cache, or an inventory view of portal-owned live objects.

## Phase 1 non-goals (explicitly deferred)

- **No generic portal-session persistence / restore-token / resume-later surface** in the D-PLUMB core.
- **No generic request/session list/watch API** across families or principals.
- **No request/session object export as CH-AREF / CH-SREF / bearer authority**.
- **No caller-specified callback registry or mailbox protocol** on the portable seam.
- **No cross-family “session composition” substrate** that lets one generic core session absorb arbitrary family-specific semantics.

## Wiring

- Decision surface:
  - `decision-map.md` (D-PLUMB)
- Companion posture docs / families:
  - `plumb-posture-v0.md`
  - `capture-portal-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `inhibit-lease-posture-v0.md`
  - `ui-automation-posture-v0.md`
- Portal/control surfaces:
  - `portal-family-registry.md`
  - `docs/60-engineering/portal-design-playbook.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-PLUMB-1, I-PLUMB-2, I-PLUMB-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-PLUMB-NOAMP, PO-PLUMB-UI, PO-PLUMBMSG-VALIDATE)

CI drift gate:
- `tools/check_portal_session_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **provider-owned / single-outcome / family-local / no generic resume-list-watch** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL.
- REF-XDG-PORTAL-REQUEST.
- REF-XDG-PORTAL-SESSION.
- REF-XDG-PORTAL-SCREENCAST.
