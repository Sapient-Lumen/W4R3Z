# Worker-pool invocation manifest v0 (exact `invocation.manifest` / `invocation_manifest_digest` contract)

Purpose: pin one exact, digest-first meaning for the worker-pool family-local **invocation manifest** so the first concrete **D-CONSTR** family does not drift into “equivalent” manifest folklore between `pool.control.Describe()`, replay bundles, and harness outputs.
This doc narrows an already-chosen surface: it does **not** introduce a generic constructor schema, receipt protocol, or constructor-global metadata plane.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-CAPAUD**, **D-AREF**, **CH-EXECPACK v2**, **CH-AREF v0**
- assumes the exact family-local invocation boundary is already fixed by `worker-pool-constructor-invocation-v0.md`
- assumes the exact family-local parameter schema is already fixed by `worker-pool-parameter-schema-v0.md`
- assumes the exact meaning of the required `sponsor` import is already fixed by `worker-pool-sponsor-surface-v0.md`
- assumes the exact evidence-pack member set is already fixed by `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- assumes the exported `pool.control` handle already returns `invocation_manifest_digest` as pinned by `worker-pool-control-surface-v0.md`
- does **not** introduce a generic constructor manifest schema or a manifest inventory/search surface

## Phase-1 choice

1) **One exact invocation manifest binds the reviewed family-local invocation contract**
   - Every successful worker-pool construction produces one exact **invocation manifest** for that pool instance.
   - The same canonical bytes may be embedded as `invocation.manifest` in the harness evidence pack or surfaced indirectly through `invocation_manifest_digest` on `pool.control`.
   - Phase 1 declines per-tool manifest variants, prose-only summaries, or constructor-family-local “close enough” manifest shapes.

2) **The manifest stays digest-first and records only the bounded invocation contract**
   - The portable manifest contains exactly:
     - `v = 0`,
     - `family = "worker_pool"`,
     - `template_set_digest`,
     - `execpack_digest = digest(CH-EXECPACK v2)`,
     - `param_digest` = `digest(CH-WPOOLPARAM v0)`,
     - `pool_size` in `1..64`,
     - `import_contract_digest`,
     - `export_contract_digest`,
     - `sponsor_present = true`,
     - `worker_seed_labels` as a lexicographically sorted unique list,
     - `install_mode` in {`return_only`, `publish_canonical`}.
   - The manifest does **not** inline capabilities, raw seed handles, target-seam locator strings, human prompts, helper-object identities, or fresh object IDs.

3) **`worker_seed_labels` and `install_mode` are exact reviewed projections, not ambient reconstruction hints**
   - `worker_seed_labels` is the exact reviewed label set from `worker_seed/<label>` imports after validation; missing/extra labels fail closed before the manifest is accepted.
   - `install_mode = return_only` means `install_target` was absent.
   - `install_mode = publish_canonical` means `install_target` was present and the reviewed invocation selected the exact canonical publication path pinned in `worker-pool-install-target-surface-v0.md`.
   - The manifest does **not** encode target identity, alias maps, publication history, or ordering witnesses; those remain on the target seam and in the evidence pack’s optional `target.before` / `target.after` members.

4) **The manifest is the stable digest target reused by both runtime summaries and evidence packs**
   - `pool.control.Describe()` returns `invocation_manifest_digest`, and that digest MUST match the canonical bytes of the corresponding `invocation.manifest` pack member when a harness/evidence bundle is emitted for the same pool instance.
   - This gives operators and tooling one stable digest to compare across runtime observation, replay bundles, and confinement evidence.
   - If a profile chooses to reference the manifest indirectly via `CH-AREF v0`, the resolved artifact MUST still hash to the same canonical manifest bytes.

5) **Instance-local fresh state stays out of the manifest**
   - Fresh worker object IDs, active `qid`, slot occupancy epochs, crash counters, target-seam ordering tokens, and transcript sequence numbers are **not** part of the invocation manifest.
   - Two fresh return-only constructions with the same reviewed invocation contract may therefore share the same manifest digest even though they produce different fresh internal identities.
   - Install cases still differ only by target-seam evidence, not by a second manifest vocabulary.

6) **Human notes are optional and non-authoritative**
   - Tools MAY render labels, markdown, or operator notes around the manifest for review convenience.
   - Those notes are outside the canonical manifest bytes and MUST NOT affect replay, confinement, or comparison verdicts.
   - The manifest remains a small digest-first contract object, not an explanation channel.

## Out of scope in v0

- A constructor-generic manifest shared by every future family.
- Embedding raw capabilities, helper handles, or per-worker diagnostics in the manifest.
- Target inventory/history/search semantics.
- Host-specific locator strings as authoritative identity.
- A second receipt/admin plane keyed off manifest digests.

## Wiring

- Decision surface: **D-CONSTR**.
- Family choice: `worker-pool-constructor-family-v0.md`.
- Exact invocation boundary: `worker-pool-constructor-invocation-v0.md`.
- Exact family-local parameter schema: `worker-pool-parameter-schema-v0.md`.
- Exact sponsor-import contract: `worker-pool-sponsor-surface-v0.md`.
- Exact control-handle contract: `worker-pool-control-surface-v0.md`.
- Exact install-target contract: `worker-pool-install-target-surface-v0.md`.
- Primary evidence pack: `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`.
- Primary harness contract: `docs/40-verification/worker-pool-constructor-harness-v0.md`.
- Reused seams: **CH-EXECPACK v2**, **CH-WPOOLPARAM v0**, **CH-AREF v0**, **D-CAPAUD**, **D-AREF**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-IN-TOTO**, **REF-IN-TOTO-STATEMENT**, **REF-SLSA-PROVENANCE**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_invocation_manifest.py` (**EVID-2026-366**).
