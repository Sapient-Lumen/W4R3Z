# CH-HEALTHREC v0: Health record (schema)

Purpose: record a **non-authoritative but digest-bound** account of a health evaluation for a specific boot/session and predicate.
This supports audit/forensics (“why did we commit/rollback?”) and allows deterministic negative tests.

References: REF-SYSTEMD-BOOT-ASSESS, REF-ANDROID-BOOTCTRL.

## Encoding
Canonical CBOR (D-ENC).

## Design constraints (v0)
- bounded fields; no raw secrets
- deterministic decode + closed key set (I-ENC-1)
- non-authoritative: the commit operation is a capability boundary; CH-HEALTHREC is evidence/logging material

## Shape (v0)
A health record `hr` contains:
- `schema`: fixed `CH-HEALTHREC v0`
- `boot_nonce`: opaque bounded bytes copied from CH-BOOT (profile-defined length; e.g., 16 bytes)
- `root_digest`: digest of the booted deployment root (same digest format as CH-BOOT/CH-BOOTSEL)
- `comp_manifest_digest`: optional digest of CH-COMP used for this boot (if applicable)
- `health_pred_digest`: digest of the CH-HEALTH predicate evaluated
- `uptime_ms`: u64 at evaluation time
- `decision`: enum `{ pass, fail }`
- `results`: bounded list of per-check results mirroring CH-HEALTH `checks`
  - each result contains:
    - `kind`: same as predicate check kind
    - `ok`: bool
    - `detail`: optional bounded, closed-set detail (no free-form strings)

## Binding guidance
- If a system claims D-ATOMICUPD with health-commit:
  - the boot-success mark SHOULD emit a CH-HEALTHREC and include its digest in the transcript (CH-LOG)
  - the boot selector (or IF-BOOT) SHOULD require that `health_pred_digest` matches the pending policy’s required predicate (if configured)
  - mismatches fail closed and MUST NOT commit
