# Privileged interface (ABI): syscalls, hypercalls, and VM-exit surface

Goal: define the *smallest* stable interface that must be specified and (eventually) refined/proved.
This document is **not** a full API reference; it records interface *shape* constraints for verifiability.

## Interface shapes (candidates)
### A) Microkernel-style syscall ABI
Unprivileged code invokes syscalls into the core; core provides threads/IPC/mappings/caps.

### B) Hypervisor-first hypercall ABI (+ VM-exit handling)
Guests invoke hypercalls for resource management; core also mediates VM exits (traps, privileged ops, interrupts).

### C) Separation-kernel ABI (static configuration + minimal runtime calls)
Mostly static partitioning with a minimal set of runtime calls (often simplest to verify early).

## Non-negotiable constraints (verifiability)
- **Small and typed:** interface must be expressible as a small action set in the abstract machine (`abstract-machine.md`).
- **Total where possible:** prefer explicit error returns over implicit behavior.
- **Capability-mediated:** every sensitive operation takes explicit authority (C-CAP-1, I-CAP-1).
- **No ambient global state:** make state explicit in object handles/capabilities.
- **Exit-surface minimization:** for hypervisor-first, reduce VM-exit reasons handled in privileged code; push policy to deprivileged services when possible.

## Minimal required operations (slice-aligned)
- capability ops: derive/mint/revoke? (design choice D-CAP)
- mapping ops: map/unmap/declare-share (I-MAP-1, I-SHARE-1)
- IPC: send/recv (bounded message + explicit shared-region object)
- scheduling primitive(s): yield/preempt semantics consistent with D-CONC
- interrupt routing ops: bind/ack with explicit authority

## Proof hooks
Each interface op should map to:
- an abstract action in `abstract-machine.md`
- invariant preservation obligations (I-IDs)
- `unsafe` obligations (U-IDs) if relevant
