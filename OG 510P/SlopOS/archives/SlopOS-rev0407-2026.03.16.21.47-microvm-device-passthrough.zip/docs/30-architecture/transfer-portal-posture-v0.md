# D-PLUMB transfer posture v0 (sink-pull, one-shot/auto-clear, non-history)

Purpose: pin an **implementable Phase 1** meaning for `portal.xfer.*` so clipboard, drag-drop, and share workflows stay explicit, attributable, and non-ambient.
It narrows an already-present RFC/schema seam into something validators, UX, and harnesses can test without turning SlopOS into a global clipboard bus, history service, or background observer channel.

This doc is intentionally narrow: it does **not** design a full desktop selection model, a rich MIME picker UI, or cross-device sync.

## Posture (v0)

1) **No ambient clipboard readers, watchers, or history constructors**
   - If D-PLUMB transfer workflows are enabled, post-init components obtain cross-component clipboard/drag-drop/share delivery only via the manual workflow family `portal.xfer`.
   - There is no ambient global clipboard read API, no background clipboard observation subscription, and no clipboard-history enumeration service after init.

2) **Copy publishes an offer; sink action grants delivery**
   - `copy` / drag-source publication is an inert offer (formats + bounded metadata), not a cross-component grant.
   - Cross-component delivery happens only when a sink performs an explicit paste/drop/share action and portal policy permits it.
   - Keep **copy ≠ grant** and **paste/drop/share == grant** honest in transcripts and UX.

3) **Cross-boundary transfer is one-shot/short-lived and auto-clear by default**
   - For transfers that cross components, domains, or quarantine boundaries, Phase 1 expects **short TTL**, `max_uses=1`, and `clear_on_use=true` unless policy explicitly narrows further.
   - Multi-sink fan-out, durable clipboard replay, and “copy once, paste forever everywhere” semantics are out of scope for Phase 1.

4) **Rich content stays bounded and path-free**
   - CH-XFER contains no payload bytes or host paths.
   - Cross-domain defaults SHOULD clamp to allowlisted safe formats (plain text first).
   - File/document handoff SHOULD use `portal.file.*` / CH-DOCREF rather than path-bearing drag semantics or raw host paths.

5) **Sensitive transfer metadata stays redaction-first**
   - `sensitive=true` keeps transfer descriptors and receipts export-scoped under CH-OBSPOL.
   - Labels/metadata stay bounded; strict profiles MAY refuse to export sensitive CH-XFER descriptors entirely.

6) **Manual-only in v0; no ACP automation kind**
   - Phase 1 keeps `portal.xfer.*` **manual-only**.
   - There is no CH-ACP kind for transfer workflows yet, so there is no hidden automation lane and no unstated conflict-key/ordering claim.
   - If future automation is justified, it must return via RFC with explicit conflict keys, commutativity stance, serialization boundary, and evidence hooks.

7) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell clipboard/share behavior must flow through explicit adapters and `portal.xfer`; compat runtimes do not gain an ambient host clipboard sync channel.
   - The seam remains fail-closed behind `cfg.params.lane.portal.xfer`.

## Phase 1 non-goals (explicitly deferred)

- **Clipboard history services** or enumeration APIs.
- **Background clipboard observation/watchers** or hidden copy notifications to unrelated components.
- **Persistent multi-sink fan-out** semantics for a single copy across trust boundaries.
- **Automation/ACP kinds** for `portal.xfer.*` before conflict keys + transcripts are specified.

## Wiring

- Decision surface: `decision-map.md` (D-PLUMB).
- Schemas:
  - `transfer-descriptor-schema-v0.md` (CH-XFER v0)
  - `document-handle-schema-v0.md` (CH-DOCREF v0; related path-free durable file handoff)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.xfer.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.xfer`)
  - `pledge-token-mapping.md` (`portal.xfer`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-PLUMB-1, I-XFER-1, I-XFER-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-PLUMB-NOAMP, PO-XFER-VALIDATE)
  - `docs/10-threat-model/abuse-cases.md` (AC-081)

CI drift gate:
- `tools/check_transfer_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **sink-pull / one-shot-auto-clear / non-history** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-CLIPBOARD.
- REF-WAYLAND-APA-DATADEVICE.
- REF-XDG-PORTAL-CLIPBOARD.
- REF-ANDROID-SECURE-CLIPBOARD.
- REF-ANDROID-12-CLIPBOARD-TOAST.
