# Worker-pool control surface v0 (exact `pool.control` contract)

Purpose: pin an implementable Phase 1 meaning for the exported `pool.control` handle so the first concrete **D-CONSTR** family does not regrow an ad-hoc scheduler, job-ingress API, reseeding surface, or pool-admin plane.
This doc narrows the already-chosen worker-pool family / invocation / harness stack into one smaller claim: **`pool.control` is a bounded family-local observation + maintenance handle, not a generic runtime-management interface**.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-QUIESCE**, **D-COMMUTE**, **D-SEAL**, **D-CAPAUD**
- assumes the exact export names are already fixed by `worker-pool-constructor-invocation-v0.md`
- assumes the exact meaning of the required `sponsor` import is already fixed by `worker-pool-sponsor-surface-v0.md`
- assumes the exact meaning of repeated `worker_seed/<label>` imports is already fixed by `worker-pool-seed-surface-v0.md`
- assumes the exact `invocation.manifest` / `invocation_manifest_digest` contract is already fixed by `worker-pool-invocation-manifest-v0.md`
- assumes the exact family-local parameter schema is already fixed by `worker-pool-parameter-schema-v0.md`
- assumes the exact family-local `Describe()` result shape is already fixed by `worker-pool-describe-summary-v0.md`
- assumes the exact pool-level `quiesce_state` meaning is already fixed by `worker-pool-quiesce-state-v0.md`
- assumes the exact slot-state meanings inside `worker_slots[*].state` are already fixed by `worker-pool-slot-state-v0.md`
- assumes the exact restart-budget semantics behind `restart.max_restarts` / `restart.window_ms` are already fixed by `worker-pool-restart-budget-v0.md`
- does **not** introduce a generic pool schema, a new portal family, or a constructor-global admin surface

## Phase-1 choice

1) **`pool.control` is a family-local observation + maintenance handle, not a scheduler or job protocol**
   - The exported `pool.control` handle exists so callers can inspect one pool instance and request cooperative maintenance on that same pool instance.
   - It is **not** a job queue, work-submission endpoint, autoscaler, worker-template manager, or generic factory catalog entry.
   - Phase 1 therefore declines any `submit`, `enqueue`, `scale`, `rebalance`, `replace_template`, `reseed_imports`, `publish`, `attach_export`, or inventory/list/watch verb family on `pool.control`.

2) **`Describe()` is required and returns one bounded fixed-slot summary**
   - `Describe()` is the required observational verb on `pool.control`.
   - Its result is data-only and bounded, and its exact family-local shape is pinned in `worker-pool-describe-summary-v0.md`.
   - In Phase 1 the portable summary stays closed to `v`, `invocation_manifest_digest`, `pool_size`, `quiesce_state`, optional `qid`, and ordered `worker_slots`; `pool_size` MUST still match the `pool_size` encoded under `digest(CH-WPOOLPARAM v0)` through `invocation_manifest_digest`; `qid` follows one exact presence rule; `quiesce_state` uses the exact pool-level meaning pinned in `worker-pool-quiesce-state-v0.md`; and `worker_slots[0..pool_size-1]` is one gap-free slot table whose per-slot `state` uses the exact vocabulary pinned in `worker-pool-slot-state-v0.md`.
   - The summary does **not** carry host PIDs/TIDs, queue-depth metrics, logs, raw capability material, sponsor identity, hidden helper handles, or ambient locator hints.

3) **`BeginQuiesce(mode)` and `EndQuiesce(qid)` are the only mutators in v0**
   - The only Phase 1 mutating verbs on `pool.control` are `BeginQuiesce(mode)` and `EndQuiesce(qid)`.
   - They reuse the small cooperative maintenance semantics pinned in `quiesce-posture-v0.md`: `mode` is only `DRAIN` or `CANCEL`, there is at most one active `qid`, and force-kill / subtree-freeze / hidden backlog semantics stay out of scope.
   - If a profile or instance does not implement D-QUIESCE, these mutators MUST fail deterministically as unsupported rather than silently widening into some other control surface.

4) **Pool size, launch closure, and import labels are immutable after construction**
   - `pool.control` cannot change `pool_size`, swap the worker template/artifact set, replace `digest(CH-EXECPACK v2)`, or rewrite the declared `worker_seed/<label>` import contract after construction.
   - Any such change would be a **new constructor invocation** on D-CONSTR, not a mutation performed through the already-exported control handle.
   - This keeps the first family replay-friendly and stops runtime management from becoming a hidden second constructor path.

5) **Worker handles remain the direct work authority; `pool.control` never proxies worker business methods**
   - The caller uses `worker[i]` handles for the worker closure's own typed interface.
   - `pool.control` does **not** proxy that interface, inject work into workers on the caller's behalf, or multiplex hidden per-worker control channels.
   - The control handle is therefore about pool-level observation and cooperative maintenance only, not about turning the family into a scheduler/front-door abstraction.

6) **Commutativity and serialization stay small and explicit**
   - `Describe()` is observational-only and **commutes** with all other actions on this family.
   - `BeginQuiesce(mode)` and `EndQuiesce(qid)` are intentionally **non-commutative** with each other and with new work admission on the same pool instance; serialization lives at the pool instance's existing control boundary rather than on any constructor-global ordering service.
   - Evidence of that serialization stays on explicit qid/state outcomes, transcript entries, and optional wait/signal adjuncts where enabled; v0 adds no pool-global sequencer or worker-slot mutation key family on `pool.control`.

7) **Observation stays bounded and non-inventory-like**
   - `Describe()` reports only the fixed-slot summary above for the current pool instance.
   - Phase 1 declines list-all-pools, watch-stream, search/filter, crash-log, metrics-export, or per-worker diagnostic-tree traversal semantics on `pool.control` itself.
   - Richer observation remains on explicit evidence/log/diagnostics seams rather than hitchhiking on the family control handle.

8) **Sealed compat remains honest**
   - Compat or hosted implementations MAY map `pool.control` to host/runtime facilities behind the membrane.
   - The portable contract still stays the same narrow handle: bounded `Describe()`, cooperative quiesce only, and no hidden host job-control / service-manager / autoscaling plane.
   - If a compat layer cannot provide that posture without ambient side channels, it must fail closed or keep the widening non-portable and policy-killable.

## Out of scope in v0

- Any job-submission or scheduler semantics on `pool.control`.
- Any scale-up / scale-down / add-worker / remove-worker verbs.
- Any explicit restart/recycle verb for individual workers.
- Any template swap, closure rewrite, or import reseeding through the exported control handle.
- Any list/watch/search/inventory/metrics-export admin plane for pools.

## Wiring

- Decision surface: **D-CONSTR**.
- Adjacent seams: `worker-pool-constructor-family-v0.md`, `worker-pool-constructor-invocation-v0.md`, `worker-pool-parameter-schema-v0.md`, `worker-pool-sponsor-surface-v0.md`, `worker-pool-invocation-manifest-v0.md`, `worker-pool-seed-surface-v0.md`, `worker-pool-describe-summary-v0.md`, `worker-pool-quiesce-state-v0.md`, `worker-pool-slot-state-v0.md`, `worker-pool-worker-surface-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `quiesce-posture-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-REALMS**, **REF-GENODE-INIT**, **REF-ERLANG-OTP-PRINCIPLES**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_control_surface.py` (**EVID-2026-362**).
