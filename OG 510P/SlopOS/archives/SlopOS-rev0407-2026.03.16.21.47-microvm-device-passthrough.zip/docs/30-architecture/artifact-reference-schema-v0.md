# CH-AREF v0: Artifact reference envelope (schema)

Purpose: reference *large or external* artifacts (build outputs, proofs, logs, test corpora) without importing them into this archive.
The reference is **content-addressed**: the digest is authoritative; locators are hints.

Non-goal: define a storage system. CH-AREF is an envelope that can point to a local path, a CAS, an object store, or “available on request”, while still being mechanically checkable.

References: REF-VENTI-FAST02, REF-FOUNDATION-CAS, REF-RFC6920, REF-TLOG-SWTCH, REF-CT-RFC6962, REF-REPRODUCIBLE-BUILDS.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-AREF v0 := {
  v: 0,

  ; content identity
  digest_alg: tstr,           ; closed enum: "sha256" | "sha512" | "blake3" (profile-gated)
  digest: bstr,               ; raw digest bytes

  ; sanity bounds
  size: uint,                 ; bytes
  media_type?: tstr,          ; e.g. "application/pdf" | "application/json" | "text/plain"

  ; where to obtain it (non-authoritative)
  locator?: tstr,             ; e.g. "ni:..." | "cas:..." | "file:..." | "https:..." (policy-gated; locator is non-authoritative)

  ; why it exists (audit hint)
  role?: tstr,                ; e.g. "proof" | "replay-trace" | "test-corpus" | "release-binary"
  produced_by?: {
    tool?: tstr,              ; tool name
    tool_digest?: bstr,       ; digest of tool binary/source closure (if available)
    input_digests?: [ bstr ], ; digests of primary inputs (optional)
  },

  meta?: { * tstr => any }    ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `digest_alg` is in a closed allowlist for the active profile.
3) `size` is within declared profile bounds for the given `role`.
4) If the artifact is fetched/loaded, its digest MUST match `digest_alg/digest`; mismatch rejects.
5) `locator` is non-authoritative: validators MAY ignore it entirely, or accept only allowlisted schemes.
6) Unknown `meta` keys are ignored unless explicitly allowlisted.

## Security notes
- CH-AREF is designed to prevent “archive bloat” while keeping evidence checkable: all heavyweight items can be referenced by digest.
- A “valid” CH-AREF does **not** imply the referenced artifact is trustworthy—only that it is *identifiable*.
- If CH-AREF is used for boot/update gating, treat `locator` as untrusted input (policy-gate schemes; avoid SSRF-like surprises).
- Resolution posture: dereferencing locators is a workflow seam (no privileged dereference; portalized net/file); see `artifact-resolution-posture-v0.md`.
