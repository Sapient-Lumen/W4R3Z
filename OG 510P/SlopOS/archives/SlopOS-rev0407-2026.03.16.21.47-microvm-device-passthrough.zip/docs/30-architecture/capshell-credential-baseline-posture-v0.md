# Capshell launch credential-baseline posture v0 (no ambient caller identity)

Purpose: keep **D-CAPSHELL** honest when a reviewed workflow launch could still depend on the
ambient **caller identity** of the parent runner, login session, service manager, or host runtime.
The archive already forbids privilege gain across `exec`, but reviewed launch behavior still drifts
if `capshell.exec` quietly inherits real/effective UID/GID state, supplementary groups, or a host
access token as hidden authority baseline. Those credentials change filesystem reachability,
service access, and policy outcomes even when argv/env/cwd/stdio/fd bindings are explicit.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic
credential-management API, a portable “run as user/group” descriptor, or a reviewed token broker.
It only freezes the minimum Phase 1 posture needed so launch identity stops depending on ambient
caller/session state.

## Posture (v0)

1) **No ambient caller-identity baseline in Phase 1**
   - `capshell.exec` MUST NOT treat the parent runner's current caller identity as reviewed
     workflow input merely because the runner was launched from a particular login session,
     service manager, terminal, or helper process.
   - Ambient launch identity includes at least POSIX real/effective UID/GID state,
     supplementary-group membership, and host access-token / equivalent process-security-context
     state that would otherwise be inherited by default.

2) **Phase 1 adds no reviewed per-step credential-selection surface**
   - Phase 1 introduces no reviewed `capshell.cred.*` / `capshell.identity.*` ACP/admin family, no
     per-step UID/GID/supplementary-group selector, no “preserve caller identity” knob, and no
     reviewed access-token / logon-token chooser surface.
   - The portable seam is therefore smaller: **reviewed workflow launch does not get to select or
     inherit caller identity as workflow meaning**.
   - If a deployment needs explicit cross-identity launching, that work must return as **one new
     explicit decision surface** rather than hiding inside wrappers or service-manager defaults.

3) **Runners launch under a fixed least-privilege executor identity or fail closed**
   - The reviewed boundary may rely only on a **provider-/membrane-fixed executor identity** whose
     credential state is already part of the local runtime architecture, not on whichever user,
     session, or helper happened to invoke the runner.
   - Where the launcher already runs under that fixed executor identity, ordinary `exec` inheritance
     of that fixed identity is acceptable because the identity is no longer ambient relative to the
     reviewed boundary.
   - Compat/foreign-cell membranes that cannot pin or normalize launch identity to such a fixed
     least-privilege executor posture MUST fail closed rather than preserving ambient caller
     identity.

4) **Supplementary groups / token memberships must not silently widen authority**
   - Runners/wrappers MUST NOT preserve ambient supplementary-group membership, host role grants,
     or access-token group/claim state when those memberships would widen reviewed child authority
     beyond the fixed executor posture.
   - Phase 1 adds no reviewed “preserve user groups”, “borrow desktop token”, or “inherit current
     login claims” convenience surface.
   - If the active runtime cannot strip or pin those widening memberships, it MUST fail closed.

5) **This seam is narrower than privilege gain, but adjacent to it**
   - `capshell-privgain-posture-v0.md` forbids **gaining** privilege at `exec` time through setuid,
     file capabilities, ambient capability carry-over, or similar privileged-exec metadata.
   - This doc additionally forbids treating the **ambient caller identity baseline itself** as
     reviewed workflow meaning, even when no gain occurs across `exec`.
   - Together, the two adjuncts keep launch identity both **non-widening** and **non-ambient**.

6) **Other explicit seams do not secretly mint or preserve caller identity**
   - **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and
     **CH-REQCTX v1** do not authorize inheriting login-session identity, supplementary groups,
     access tokens, or similar caller-side credential posture.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, startup hooks,
     terminal/job-control UX, or interrupt UX) MUST NOT become hidden carriers for caller-identity
     selection.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no reviewed query for “which caller identity would launch use?”, no policy
     knob for “preserve invoking user/session identity”, and no admin override that silently swaps
     executor identities for one `capshell.exec` step.
   - Any future reviewed identity-selection surface must pay for its own conflict keys,
     commutativity analysis, receipts, and profile posture rather than hiding inside wrapper
     defaults.

8) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on ambient caller identity
     or widening group/token inheritance.

9) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose host login-session identity, service-manager caller identity,
     supplementary-group drift, or borrowed access tokens as a hidden side channel around the
     reviewed execution pack.
   - If a foreign runtime cannot pin/normalize caller identity to the fixed executor posture, it
     MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable per-step UID/GID / supplementary-group selector in Phase 1.
- No portable access-token / logon-token / integrity-level chooser surface in Phase 1.
- No workflow knob for “preserve invoking user/session identity”.
- No portable query/report surface exposing launch-time caller identity or group/token memberships.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-privgain-posture-v0.md`
  - `capshell-umask-posture-v0.md`
  - `capshell-rlimit-posture-v0.md`
  - `capshell-signalstate-posture-v0.md`
  - `capshell-scheduling-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-CRED-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-CRED-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_credential_baseline_posture.py` (**EVID-2026-341**).

## References

- REF-MAN7-CREDENTIALS
- REF-MAN7-EXECVE
- REF-MAN7-PATH-RESOLUTION
- REF-MS-CREATEPROCESS
- REF-MS-CREATEPROCESSASUSER
