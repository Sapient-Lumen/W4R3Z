# CH-CWD v0: capability-bound working directory selector (schema)

Purpose: eliminate ambient authority in workflow automation by making a child process working
 directory **explicit, typed, and bindable**.

CH-CWD is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v2)`; the referenced pack binds `cwd_digest = digest(CH-CWD v0)`.
- deterministic validators/runners **execute** only after validating the selector and binding
  any referenced directory descriptor to already-held authority.

CH-CWD is **non-authoritative**:
- it MUST NOT contain host paths, bearer secrets, or raw capability material,
- it MUST NOT be interpreted as a “permission grant,”
- and any binding from CH-CWD to a real directory handle MUST be checked against already-held
  authority (e.g., a bound CH-WALLET core digest).

References: REF-PLASH, REF-CAPSICUM, REF-SHILL-OSDI14, REF-OPENAT2.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- total decoding + fail-closed validation
- bounded sizes and closed enums
- **no ambient cwd inheritance**
- hashable and stable for binding into CH-ACP / transcripts / receipts

## Data model (conceptual)

CH-CWD v0 := {
  v: 0,

  cwd: Cwd,

  ; Optional non-authoritative hints.
  note?: tstr,
  meta?: { * tstr => any }
}

Cwd :=
  ; explicit fresh/sealed cwd-root selector. The runner chooses a per-execution empty directory
  ; (or equivalent sealed cwd root) whose parent/root traversal cannot escape into ambient
  ; namespaces. The exported safety bar is fixed even if the implementation mechanism varies.
  { kind: "empty" }

| ; typed directory descriptor reference (digest only). The runner binds the referenced
  ; descriptor to an already-held directory handle and sets it as the child cwd.
  { kind: "desc",
    desc_schema: tstr,   ; allowlisted directory descriptor schema (v0: only "CH-DOCREF v0")
    desc_digest: bstr    ; digest of canonical bytes of the descriptor
  }

## Validation rules (minimum)

A cwd validator MUST be total and fail closed (PO-CWD-VALIDATE):
1) `v == 0`.
2) `cwd.kind` is in the closed enum: `"empty" | "desc"`.
3) For `kind="desc"`:
   - `desc_schema` is allowlisted and directory-capable (v0: only `"CH-DOCREF v0"`),
   - `desc_digest` length matches profile hash.
4) Unknown keys reject (or are rejected by canonical CBOR decode).

## Binding semantics (capshell runner)

CH-CWD is a **veto-only** structure:
- It never grants authority (I-CWD-1).
- Runners MUST NOT inherit or consult an ambient host current working directory as an
  authorization source.

When `capshell.exec` (via CH-EXECPACK) binds `cwd_digest`:
- If `kind="empty"`, the runner MUST set the child cwd to a **fresh empty directory or an equivalent sealed cwd root**. The exported guarantee is fixed: relative-path resolution from that cwd MUST NOT escape via `..`, absolute-path fallback, host-root rebasing, or similar ambient namespace tricks. If the runner cannot provide that no-escape cwd root under the active profile, it MUST fail closed.
- If `kind="desc"`, the runner MUST check that the referenced descriptor corresponds to
  already-held authority in the bound wallet/handle inventory for the execution context.
  For `CH-DOCREF v0`, the descriptor MUST have `target_kind="dir"`. The runner MUST bind the
  descriptor as a handle/root, not by converting it back into an ambient host pathname.
- If any reference is unknown/unavailable/unbindable, or if the active runtime cannot prove the
  required no-escape cwd-root semantics, execution MUST fail closed and be transcript-visible
  (I-CWD-2; PO-CAPSHELL-CWD-BIND).

Rejects SHOULD emit CH-DENY with deny_code `cwd-bind-failed`, binding `reason.kind="schema"`,
`reason.ref_schema="CH-CWD v0"`, and `reason.ref_digest=cwd_digest`.

Notes:
- Environment variables are modeled by **CH-ENV v0** (`env-schema-v0.md`). Command-line
  arguments are modeled by **CH-ARGV v0** (`argv-schema-v0.md`). Keeping cwd separate makes
  ambient-seam reviews sharper.
- The Phase 1 posture for no-parent-escape / no-host-root fallback is pinned in
  `capshell-cwd-root-posture-v0.md`; CH-CWD is a bound cwd-root seam, not a best-effort starting
  directory hint.
- Profiles may narrow cwd further. If `cfg.params.capshell.minimal_context=true`, validators MUST require `cwd.kind="empty"` for `capshell.exec` contexts. All profiles forbid ambient host cwd inheritance regardless of this knob.
