# MicroVM block-topology posture v0 (static guest-visible block set; no portable disk attach/eject plane)

Purpose: pin the **Phase 1** meaning of guest-visible block-device topology under `ext.microvm` so disk hotplug, media insert/eject, and guest-visible block-inventory mutation do not quietly become an ambient host↔guest control/status plane.

This doc attaches to **D-MICROVM**, **D-XS**, and **D-ACTIVATE** and makes one hard decision explicit:
**Phase 1 fixes guest-visible block-device inventory/topology at admission; `ext.microvm` adds no portable disk hotplug / hot-remove / media-insert-eject / tray-or-device-status plane, and changing guest-visible block-device inventory/topology means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity.**

Entropy cost justification: the archive already pins `ext.microvm` to a declared device set, forbids ambient host channels, fixes guest-visible RAM / CPU / NIC shape at admission, and keeps host-side file/storage authority on explicit boot/artifact or portal seams instead of ambient virtualization folklore. What remains underspecified is whether dynamic guest-visible disk management is part of the reviewed product surface. One narrow posture closes that gap without inventing a new schema family, media library, slot inventory API, or hidden host storage control plane.

## Posture (v0)

1) **Guest-visible block topology is fixed at admission**
   - For Phase 1, each admitted `ext.microvm` leaf runs with **one exact guest-visible block-device inventory/topology** fixed at admission.
   - Portable semantics do **not** include post-admission guest-visible disk add/remove, media insert/eject, tray open/close, or other block-topology mutation under the same reviewed portable identity.
   - In plain terms: the reviewed contract is “this leaf boots with this guest-visible block set/topology”, not “the host may later attach another disk or swap backing media while the same leaf keeps running”.

2) **No portable disk hotplug / media-mutation plane**
   - Phase 1 standardizes **no portable disk hotplug / hot-remove / media-insert-eject / tray-or-device-status control plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible fields or APIs such as **maximum potential disk count**, **hotpluggable drive slots**, **present/absent/ejected media state**, **host-driven disk attach/detach commands**, **tray open/close state**, or **guest-visible block-device change completion status**.
   - Implementations may internally support such mechanisms, but they are **not** part of the Phase 1 product contract and must not silently become guest-visible reviewed meaning.

3) **Owner-local block backend policy stays owner-local and must not masquerade as a portable API**
   - Owners/runtimes may still choose local image formats, caching policy, throttling, copy-on-write layering, host path sandboxing, and storage-backend placement.
   - What they may **not** do in Phase 1 is turn that owner-local backend policy into a portable guest-visible disk attach/eject/status contract for an already admitted leaf.
   - If a deployment cannot honor the fixed guest-visible block-device inventory/topology it admitted, the correct Phase 1 outcomes are to admit a different reviewed leaf/activation or fail closed — not to grow a new portable in-place storage-topology mutation meaning by convention.

4) **Changing guest-visible block topology is a new admission, not an in-place mutation**
   - If policy wants a different guest-visible block-device inventory/topology, that change is modeled as a **new reviewed admission / activation choice**.
   - It is **not** modeled as mutating a running guest under the same admitted leaf identity.
   - This keeps guest-visible storage shape aligned with the already-pinned lineage/resume-class story instead of creating a second hidden lifecycle/control surface inside `ext.microvm`.

5) **No new disk-mutation plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for disk attach/detach or media-state control, **no new ACP kind**, and **no new conflict-key family** for guest-visible block-topology mutation operations.
   - If a later design wants portable disk hotplug, removable-media workflows, or guest-visible block inventory/status contracts, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable disk hotplug / hot-remove semantics for `ext.microvm`.
- No portable guest-visible removable-media / tray / insert-eject / block-slot inventory or status API.
- No promise that owner-local backend policy is forbidden; only that it does **not** become a reviewed guest-visible control plane in Phase 1.
- No in-place “same leaf, different block-device inventory now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `host-guest-channel-posture-v0.md`
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `microvm-network-topology-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-16)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-BLOCKTOPOLOGY)
- Policy posture:
  - guest-visible block-device mutation adds **no new lane**, **no public disk-attach-or-media-status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_block_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fixed-at-admission guest-visible block topology / no portable disk-hotplug-or-media-mutation control plane / no max-disk-or-slot semantics / change block topology by new admission not in-place mutation / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-DRIVES.
- REF-CHYP-HOTPLUG.
- REF-QEMU-QMP-BLOCK.
- REF-QEMU-SECURITY.
