# D-PLUMB print portal posture v0 (manual-only; render-first; shell-spooled)

Purpose: pin an **implementable Phase 1** meaning for `portal.print.*` so printing stays a mediated exfiltration workflow rather than regressing into ambient printer sockets, app-visible printer inventory, or durable queue authority.
It narrows an already-present portal family into something UX, policy, and receipts can test without turning SlopOS into a host print-subsystem compatibility layer.

## Posture (v0)

1) **No ambient printer constructors**
   - If D-PLUMB is enabled, printing happens only via `portal.print`.
   - There is no ambient printer socket, spool directory, CUPS/IPP helper shortcut, or raw `/dev/usb/lp*` path available to applications after init.
   - The seam remains fail-closed behind `cfg.params.lane.portal.print`.

2) **Manual-only v0; no ACP automation kind**
   - `portal.print.*` remains **manual-only v0** on the ACP surface.
   - Phase 1 does **not** introduce a `portal.print.submit` or similar automation kind.
   - Any future automation surface must come back with explicit conflict-key / commutativity / retry semantics rather than inheriting toolkit behavior.

3) **Render-first, then submit**
   - The portal may expose a two-step prepare→submit workflow: obtain bounded print settings/page setup, render the final print artifact, then submit it.
   - Print settings are hints/clamps for rendering, not ambient authority to enumerate printers or operate queues.
   - The printable artifact is a bounded document/image stream handed to the shell-owned spool path; printing is not a general remote-procedure surface to printer drivers.

4) **No app-visible printer inventory or queue authority in v0**
   - Phase 1 does **not** expose a generic `list_printers()`, printer capability database, or durable queue/job-management API to applications via `portal.print`.
   - Any remembered default-printer state, “ask every time” behavior, queue UX, or retry/release policy remains shell/portal-owned.
   - A successful print submission means the shell/portal accepted the print job for mediation; it does **not** hand the requester durable authority over the printer, queue, or transport.

5) **Print is an exfiltration workflow, not a file/path loophole**
   - Printing local content still requires already-held document authority (`portal.file.*` / CH-DOCREF or equivalent handles); `portal.print` does not mint ambient file access.
   - “Print to file” / “save as PDF” remains a `portal.file.*` destination-selection problem, not a host-path escape hatch hidden inside printing.
   - Printing does not silently widen into `portal.net`, `portal.device`, or any ambient network/device authority just because many printers are networked or USB-attached.

6) **Spooling/retry stays shell-owned and non-amplifying**
   - The portal or shell may queue/retry the bounded print artifact according to local policy, but applications do not get a durable retry daemon or queue-control channel in Phase 1.
   - Silent background resubmission, queue introspection, and printer-status polling are out of scope unless a later RFC introduces an explicit bounded receipt surface.

7) **Ordering lives in the portal/spooler**
   - Externally visible queue order, destination choice, and duplicate suppression live inside `svc:portal.print`.
   - Two print requests may commute with respect to the requester’s authority (they mint none) but do **not** necessarily commute with respect to spool order, paper/device contention, or quota/budget state.
   - Any future ACP surface must keep its conflict keys and serialization boundary explicit rather than burying them in toolkit callbacks.

8) **Sealed compat remains killable and non-ambient**
   - Foreign Cell print flows must route through `portal.print` or an explicit adapter that remains policy-killable.
   - Compat runtimes do not gain ambient access to host printer stacks, helper binaries, or queue-management sockets.

## Phase 1 non-goals (explicitly deferred)

- **No ACP automation kind** for `portal.print.*` in Phase 1.
- **No app-visible printer inventory / capability query API**.
- **No durable queue/job-management authority** or printer-status polling channel for applications.
- **No raw printer transport/socket/device access** as an interop convenience.
- **No “print to file/path” loophole** that bypasses `portal.file.*` / CH-DOCREF.

## Wiring

- Decision surface:
  - `decision-map.md` (D-PLUMB)
- Control surfaces:
  - `portal-family-registry.md` (`portal.print.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.print`)
  - `effect-contract-schema-v0.md` (`portal.print` effect family)
  - `intent-kind-registry.md` (`print`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-PRINT-1, I-PRINT-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-PRINT-ENF)
- RFC history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_print_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / render-first / no printer inventory or queue authority** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-PRINT.
- REF-ANDROID-PRINT-FRAMEWORK.
- REF-ANDROID-KITKAT-PRINTING.
- REF-APPLE-UIPRINTINTERACTIONCONTROLLER.
