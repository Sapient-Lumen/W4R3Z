# Replication object-family registry (v0)

CH-REPLCONTRACT v0 uses `object_family` strings to describe cross-cluster ownership/replication semantics under Hybrid (ADR-0005).
Left “open”, these strings become an amnesia/drift seam: new families appear in prose, tooling diverges, and reviewers lose the closed-world surface.

This registry closes that seam by pinning a **reviewable allowlist** of v0 `object_family` tokens.

## Rules (v0)

- **Strict posture:** IF-CFG / IF-BOOT validators in strict profiles MUST reject CH-REPLCONTRACT entries whose `object_family` is not listed here.
- **Non-authoritative:** replication artifacts never grant authority (PO-REPL-NOAMP). These families are *descriptions* only.
- **RC4 admission is narrow:** `replication_class = rc4_ordered_log` is reserved to `object_family = tlog` in v0.
  - Any other use of RC4 requires an explicit decision update (D-REPL) + evidence.

## Canonical v0 families

| object_family | What it names | Default RC stance (v0) | Conflict-key tag(s) | Notes |
|---|---|---|---|---|
| `view` | view/namespace binding metadata (attach/detach, slot bindings) | `rc1_owner` | `view_id` | owner-routed slot-binding metadata only; replicas may cache bounded read-only summaries but cannot auto-activate bindings (see `view-replication-boundary-v0.md`) |
| `transcript` | audit transcript/event-set export metadata (CH-LOG) | `rc3_comm_merge` | `log_id` | content-addressed CH-LOG event-set evidence only; canonical order is derived, and replicated arrivals cannot drive replay/admission/runtime ordering (see `transcript-replication-boundary-v0.md`) |
| `receipt` | receipt/event-set export metadata (e.g., CH-ACPOUT, CH-DENY, CH-FADAPT receipts) | `rc3_comm_merge` | `log_id` | immutable digest-addressed evidence set only; replicated arrivals cannot authorize replay/import/admission (see `receipt-replication-boundary-v0.md`) |
| `quota` | spend/charge state summaries for metering/quota | `rc3_comm_merge` | `budget_id` | additive spend summaries under already-issued local credit only; observational/non-authoritative; mint/grant/revoke/rebalance lives elsewhere (see `quota-replication-boundary-v0.md`) |
| `budget` | mint/split/revoke authoritative budget state | `rc1_owner` | `budget_id` | owner-routed issuer / lease-lineage metadata only; replication never creates spendable local credit or widens a lease (see `budget-replication-boundary-v0.md`) |
| `caprpc_proxy` | cross-cluster proxy metadata for capability-RPC endpoints | `rc1_owner` | `endpoint_id` | owner-routed endpoint/proxy metadata only; replication never creates a callable proxy/handle (see `caprpc-proxy-replication-boundary-v0.md`) |
| `namecert` | local naming certificates / delegation bundles (D-NAMECERT) | `rc3_comm_merge` | `name_domain` | signed bundles merge as a digest-set; replication is bundle evidence only, while local policy resolves trust/visibility/activation (see `namecert-replication-boundary-v0.md`) |
| `tlog` | transparency log checkpoints/receipts (non-authoritative evidence lane) | `rc4_ordered_log` (when enabled) | `log_id` | append-only evidence only; local explicit policy still pins accepted log origins/pubkeys/witness policy, and replicas cannot turn checkpoints into runtime admission/control/time authority (see `tlog-replication-boundary-v0.md`) |

## Change control

To add a new `object_family` token:
1) add exactly one new row above (justify why it is cross-cluster relevant),
2) update `profile-repl-defaults.md` so A–D defaults remain coherent (no forks),
3) if the family needs RC4, update the RC4 admission posture (D-REPL) and add evidence,
4) update docs wiring (`docs/README.md`), and
5) add/extend a drift gate + EVID entry if the new family meaning could drift.

## Related docs

- `replication-contract-schema-v0.md` (CH-REPLCONTRACT v0 schema)
- `replication-contracts-v0.md` (RC0..RC4 vocabulary + v0 posture)
- `profile-repl-defaults.md` (A–D default guidance)
- `budget-replication-boundary-v0.md` (pins `budget` replication to owner-routed issuer / lease-lineage metadata only; no portable spend authority from replicas)
- `namecert-replication-boundary-v0.md` (pins `namecert` replication to signed bundle-set evidence; no global/ambient resolution)
- `receipt-replication-boundary-v0.md` (pins `receipt` replication to immutable digest-addressed evidence sets only; no replay/import/admission authority)
- `transcript-replication-boundary-v0.md` (pins `transcript` replication to CH-LOG event-set evidence only; no replay/admission/runtime-order authority)
