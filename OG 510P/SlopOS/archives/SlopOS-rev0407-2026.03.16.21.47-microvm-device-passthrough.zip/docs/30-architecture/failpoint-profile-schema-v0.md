# CH-FAIL v0 (failpoint profile schema, informal)

Purpose: a bounded, deterministic contract for **fault injection** in dev/test profiles.

This is not a chaos scripting language. It is a pinned artifact that describes *which* failpoints exist, *when* they fire, and *what* bounded effect occurs.

Refs: REF-LINUX-FAULTINJECT, REF-JEPSEN.

## Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded size/cost (validation must be cheap)
- closed sets (trigger kinds, effect kinds)
- effects are **failure-only**: they must not create authority (I-FAIL-1)

## Shape (v0)
A failpoint profile `f` contains:
- `schema`: fixed `CH-FAIL v0`
- `profile_id`: bounded identifier (string)
- `seed`: optional 64-bit seed for deterministic PRNG use (only if a `prob` trigger kind is used)
- `rules`: bounded list of failpoint rules
- `bounds`: explicit caps on evaluation cost and damage radius

### Rule
Each rule contains:
- `id`: stable failpoint identifier (string; typically `subsystem:hook`)
- `scope`: where it applies
- `when`: trigger condition
- `effect`: bounded effect

#### scope (closed)
- `global`
- `component { component_id }`
- `domain { domain_tag }`

#### when (closed)
Deterministic triggers:
- `always`
- `once`
- `nth { n }` (fire on the nth encounter)
- `every { k }` (fire every k encounters)
- `range { start, end }` (fire for encounter indices in [start,end])

Optional probabilistic trigger (deterministic under a pinned seed):
- `prob { p, stream }`
  - `p` is a rational probability represented as `p_num/p_den` (avoid float)
  - `stream` is a bounded string selecting a PRNG substream (to keep evaluations stable)

#### effect (closed)
Safe, failure-inducing effects:
- `return_err { code }` (must be a stable, closed error code enum)
- `delay { micros }` (bounded by `bounds.max_delay_micros`)
- `drop` (only for explicitly allowlisted message classes; used cautiously with D-RR)
- `stall { micros }` (like delay, but represents “no progress”; bounded)

Optional “destructive” effects (dev-only, explicit opt-in):
- `panic { reason_tag }`

## Validation obligations (PO-FAIL-VALIDATE)
Validators must:
- reject unknown `when` or `effect` variants
- enforce `rules.len <= bounds.max_rules`
- enforce all numeric bounds (micros, n/k ranges, probability denominator caps)
- require `seed` if any `prob` trigger exists
- forbid `drop` unless the active profile declares a D-RR compatible semantics (either recorded as CH-RR input or excluded from the replay claim)

## Notes on determinism (I-FAIL-2)
- Encounter counting is per-(id, scope) unless explicitly overridden by the profile.
- For `prob`, the PRNG must be deterministic and depend only on (`seed`, `stream`, encounter index).
- If D-RR is enabled, either:
  - treat `prob` draws as part of the replay input stream, or
  - treat “fired” decisions as explicit CH-RR events.

## Intentional omissions (v0)
- message corruption / bit flips (too close to undefined behavior for a first-class seam)
- arbitrary scripting / code injection
- cross-node cluster fault modeling (that belongs to higher-level harnesses)
