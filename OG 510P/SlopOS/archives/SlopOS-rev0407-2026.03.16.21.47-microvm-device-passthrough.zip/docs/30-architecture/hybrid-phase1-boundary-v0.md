# Hybrid Phase 1 boundary v0 (resolved authority/claim posture)

Purpose: resolve **OQ-0001** by freezing the Phase 1 Hybrid multicore surface as a *closed* set of authority and claim rules, so future topology richness or replication debates cannot silently widen D-MK/D-CLUSTERMAP/D-REPL semantics.

## Decision (v0)

For Phase 1, the Hybrid multicore posture is now **closed and resolved**:

1) **Cluster derivation authority is fixed**
   - `preferred_boundary = auto` means **NUMA → socket → core_group** only (`cluster-auto-boundary-v0.md`).
   - `die` remains explicit-policy-only.
   - The flagship claim envelope remains **<=64 logical CPUs**, **<=8 clusters**, and **<=16 logical CPUs per cluster** (`cluster-phase1-envelope-v0.md`).

2) **Richer hardware/topology facts stay hint-only unless a new surface says otherwise**
   - CH-HWFACT cache/LLC facts remain **placement hints only** (`cache-topology-authority-boundary-v0.md`).
   - Asymmetric CPU-capacity / performance-class facts remain **placement hints only** (`cpu-capacity-authority-boundary-v0.md`).
   - NUMA-distance / HMAT latency-bandwidth / memory-tier facts remain **placement hints only** (`memory-locality-authority-boundary-v0.md`).
   - These hints may improve ranking, placement, migration, and audit, but they do **not** become ownership, replay, budget, admission, or replication authority.

3) **Cross-cluster replication meaning is registry-closed in v0**
   - CH-REPLCONTRACT `object_family` remains closed by `replication-object-family-registry.md`.
   - The only admitted v0 family meanings are the already pinned boundary docs for `quota`, `budget`, `transcript`, `receipt`, `namecert`, `caprpc_proxy`, `view`, and `tlog`.
   - RC4 remains reserved to `object_family = tlog`, and only for append-only evidence.

4) **Any widening must be explicit and RFC-first**
   - Future cache-/distance-/tier-/perf-aware ownership or new replicated authority semantics must land as one new explicit surface: a new RFC/ADR update, any required schema/version or registry row changes, updated A–D diff surfaces, and a new evidence/guardrail hook.
   - Existing CH-HWFACT / CH-CLUSTERMAP / CH-REPLCONTRACT bytes must **not** be reinterpreted in place.

## Why this resolves OQ-0001

OQ-0001 existed to prevent Hybrid from drifting in three expensive ways:
- topology probes quietly becoming authority boundaries,
- replicated metadata quietly becoming portable authority, and
- the archive silently over-claiming many-core scope.

Those seams are now closed in v0.
The Phase 1 archive has one stable answer for each of them:
- default ownership boundaries are small and explicit,
- richer facts are optimization-only unless promoted by a new explicit surface,
- replicated object families are closed and individually pinned,
- and the multicore claim envelope is numerically bounded.

Remaining work is therefore **evidence / harnessing / later-phase expansion**, not an unresolved design question.

## Consequences

1) **Phase 1 Hybrid review gets smaller**
   - Reviewers can treat Hybrid as one bounded posture instead of an open-ended topology or replication debate.

2) **Future expansion must pay the entropy cost up front**
   - A later design may add cache-aware ownership, distance-adaptive clustering, new object families, or larger cluster counts, but it must do so with an explicit RFC-first surface and new guardrails.

3) **The four product shapes stay aligned**
   - A/B/C/D may choose different profile knobs or default replication classes, but they do not fork the meaning of Hybrid authority in v0.

## Wiring

- Root decision surfaces: `adrs/0005-hybrid-multicore-and-commutativity-discipline.md`, `decision-map.md`
- Cluster derivation / claim surfaces: `cluster-derivation.md`, `cluster-auto-boundary-v0.md`, `cluster-phase1-envelope-v0.md`
- Hint-only topology boundaries: `cache-topology-authority-boundary-v0.md`, `cpu-capacity-authority-boundary-v0.md`, `memory-locality-authority-boundary-v0.md`
- Replication closure surfaces: `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`
- History/open-question surface: `docs/00-meta/trajectory-map.md` (OQ-0001 resolved here)
- Evidence hook: `EVID-2026-272` via `tools/check_hybrid_phase1_boundary.py`

## References

- REF-MULTIKERNEL-SOSP09
- REF-SCR-TOCS15
