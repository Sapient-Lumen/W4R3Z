# D-QUAR quarantined-execution boundary v0 (no portable `run_untrusted`; clear-before-exec)

Purpose: close the seam between **D-QUAR** safe-open and exact-object execution.
Phase 1 already pins `intent.kind=open_untrusted` as an object-only, **`docref`-only** document-shaped
safe-open workflow, while **D-CAPSHELL** pins normal execution to one exact bound executable object.
Without one more boundary, "open/execute quarantined objects" can drift into an underspecified launcher
that half-means preview and half-means arbitrary execution.

This adjunct keeps the archive small and implementable:
quarantined **document-like** content may go through `open_untrusted`, but quarantined **exact
executable/script objects** do **not** gain a portable run-in-disposable lane in Phase 1.
They remain deny-by-default on normal execution seams until an explicit, object-local clear/override
crosses the existing consent/logging boundary.

## Posture (v0)

1) **Safe-open stays document-shaped; exact execution stays on existing exec seams**
   - `intent.kind=open_untrusted` remains one exact **CH-DOCREF** safe-open request for document-like
     risky parsing/preview/edit flows.
   - Normal exact execution remains on existing launch seams such as `capshell.exec` with one explicit
     CH-ARGV `role="exec"` selector and the exact-object binding pinned in
     `capshell-exec-object-posture-v0.md`.
   - Phase 1 does **not** reinterpret `open_untrusted` as "run this executable/script in a disposable."

2) **Quarantined exact executable/script objects fail closed on normal exec surfaces**
   - If the candidate executable object, explicit interpreter, reviewed script input, or another
     reviewed **code-bearing input object** for that interpreter/runtime remains
     `quarantine.state = quarantined`, the ordinary exact execution path rejects before effect.
   - Companion code-input boundary: a cleared interpreter/runtime does not bypass this rule by
     restaging quarantined object bytes as `stdin`, `-c`, `--eval`, module/archive entry, or a
     similar code-bearing input form (`quarantined-code-input-boundary-v0.md`).
   - There is no portable coercion from a quarantined executable/script object into `open_untrusted`,
     `open_uri`, host file associations, CH-DOCREF reopen, or a document-viewer trick.
   - Exact object binding is necessary for execution correctness, but it is downstream of the
     quarantine/origin gate rather than a substitute for it.

3) **Clear/override is the only Phase 1 bridge from quarantine to exact execution**
   - To execute a quarantined exact executable/script object, policy must first cross the existing
     object-local IF-CONSENT + CH-LOG quarantine-clear / override seam.
   - After that explicit authorization edge, the normal exact execution rules still apply: one exact
     reviewed executable object, explicit interpreter binding for scripts, no ambient PATH/name reopen,
     and no hidden authority widening.
   - `open_untrusted` success, preview success, static inspection, or copy/export outcomes do not by
     themselves authorize later exact execution.

4) **No portable `run_untrusted` lane in Phase 1**
   - Phase 1 adds no `intent.kind=run_untrusted`, no `capshell.exec.untrusted`, and no generic
     arbitrary-command-in-disposable convenience surface.
   - Local/admin product glue may build profile-specific helpers above existing seams, but that is not
     a portable archive promise and must remain killable by policy.
   - If a future product wants a reviewed run-in-disposable surface, it must return as one explicit RFC,
     ideally with a StartApp-like exact target model rather than a VMShell-like arbitrary command string.

5) **Sandboxed run success does not clear quarantine or bless persistence**
   - Any local/profile-specific sandboxed execution helper remains distinct from quarantine clear.
   - Successful execution, process exit status, or generated output must not silently rewrite the source
     object's `quarantine.state` or imply trusted persistence/copy-back.
   - Any kept output still crosses the existing explicit destination/export/clear seams.

6) **Ordering and conflict keys stay on existing seams**
   - This boundary does not mint a new externally visible action family.
   - Quarantine clear / override serializes where it already serializes: the object-local IF-CONSENT /
     transcript seam keyed to the source object digest.
   - Normal execution ordering stays where it already lives for `capshell.exec` / exact-object launch
     (for example `domain.id` and `svc:IF-CAPSHELL`).

7) **Sealed compat remains killable and non-ambient**
   - Compat layers must not turn a quarantine denial into "launch anyway with a warning," an ambient
     host-association reopen, or a hidden disposable-run fallback.
   - If a foreign runtime cannot preserve both quarantine gating and exact-object launch semantics, it
     must fail closed.

## Phase 1 non-goals (explicitly deferred)

- No `intent.kind=run_untrusted` portable request kind.
- No CH-DOCREF/path/file-association coercion into `capshell.exec`.
- No generic “run in disposable” launcher, handler inventory, or template picker.
- No auto-clear or trust upgrade after sandboxed execution, preview, or exit success.
- No hidden copy-back / persistence approval from sandboxed execution.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-QUAR, D-CAPSHELL, D-PLUMB, D-EPHEM)
- Adjacent posture docs:
  - `quarantine-posture-v0.md`
  - `open-untrusted-posture-v0.md`
  - `capshell-exec-object-posture-v0.md`
  - `capshell-script-entry-posture-v0.md`
  - `quarantined-code-input-boundary-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-3, I-QUAR-6, I-CAPSHELL-EXECOBJ-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-GATE, PO-QUAR-EXEC, PO-CAPSHELL-EXECOBJ-BIND)
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- RFC history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`

CI drift gate:
- `tools/check_quarantined_execution_boundary.py` fails `make lint` if the boundary stops being discoverable,
  if `open_untrusted` widens into a portable exec lane, or if quarantined exact executable/script objects stop
  being deny-by-default pending explicit clear/override.

## References

- REF-MACOS-GATEKEEPER.
- REF-QUBES-DISPOSABLES.
- REF-QUBES-QREXEC.
- REF-PYTHON-CMDLINE.
- REF-NODE-CLI.
