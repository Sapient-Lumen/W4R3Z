# Core mechanisms (spec-oriented)

This is the narrative counterpart to the abstract machine spec (to be added in Phase 1). Keep it minimal.

## Objects (v0)
- Domain/VM
- Thread/vCPU
- Endpoint/channel
- Memory objects: frames, page tables, shared regions
- Interrupt objects
- View objects (optional): explicit name→cap mappings (see `view-objects.md`)

## Capabilities (v0)
- Cap = (object_ref, rights, metadata)
- Derivation is explicit; revocation is a design choice (see decision map)

## Translators / service-tree adapters (optional)
If **D-TRANS** is enabled, treat translators as **ordinary user-space components** attached through explicit **D-NS** `view.slot` mutations rather than as a privileged pathspace or mount-table feature.

Phase 1 posture keeps the seam **view-local**, **single-slot**, and **non-ambient**: externally visible attach/remove actions stay on the existing `view.attach` / `view.detach` kinds with `view.slot` conflict keys and `svc:view` ordering, translators gain no ambient `open(path)` / default-service / network-fetch escape hatch, and there is no host-global translator inventory or separate translator admin plane.

Service-tree UX remains a user-space adapter convention. Any 9P/Styx-like bridge is just another capability-bearing component, not privileged routing magic. Translator continuity/restart lives on existing supervision/activation seams rather than on D-TRANS itself.

Pinned v0 posture: `translator-posture-v0.md` (view-local translators; explicit attach; no global pathspace).

## IPC (v0)
- Message IPC: bounded copy for simplicity
- Shared-memory IPC: explicit shared-region objects (no hidden sharing)

## Request contexts + cancellation/deadlines (optional)
If **D-REQCTX** is enabled, standardize a small **request-context** seam so cancellation, deadline intent, and correlation stop fragmenting into ad hoc per-interface flags and timeout knobs.

Phase 1 posture keeps the seam **sticky, tree-shaped, and non-authoritative**: derived contexts only narrow inherited intent, portable deadline intent is the single absolute `monotonic_deadline_ms` field from CH-REQCTX, and exported outcomes stay the stable closed set `CANCELLED` / `DEADLINE_EXCEEDED`.

Portable request contexts deliberately decline a baggage/value-store role. `tags` remain bounded diagnostic metadata, not a general KV channel; portable CH-REQCTX also declines `shield` / `uncancellable` / `detach` bits, so long-lived work that must outlive its caller has to mint a fresh root on the owning seam rather than silently suppress parent cancellation.

This seam composes with D-WAITSET, D-UWAIT, D-IOQ, D-QUIESCE, D-BUDGET, D-TCAP, and D-NONDET without introducing ambient time or queue-local timeout dialects.

Pinned v0 posture: `reqctx-posture-v0.md` (sticky parent→child propagation; absolute monotonic deadline intent only; no portable baggage/detach/shield semantics; no workflow/ACP surface).
See RFC-0105.

## Turn-based concurrency for selected services (optional)
If **D-TURNS** is enabled, standardize a small **user-space/runtime discipline** for selected components/CapRPC services so local reasoning stays tractable and implicit callback reentrancy does not creep back in through convenience APIs.

Phase 1 posture keeps this seam **per-component**, **one-turn-at-a-time**, and **asynchronous across vat boundaries**: exactly one inbound turn runs per vat/component instance, far calls remain promise/event-message based, and blocking/await conveniences must not secretly pump the inbox while waiting.

Portable v0 deliberately declines a general `reentrant` / `always-interleave` / call-chain-reentrancy knob. If an implementation needs finer-grained interleaving, that stays implementation-local and explicit rather than becoming a SlopOS-wide contract. Scale-out should prefer **more vats / explicit sharding** over silently widening one vat into a shared-state threaded service.

D-TURNS composes with D-REQCTX, D-BRACKET, D-RCU, D-WAITSET, and D-CAPRPC, but it does **not** invent a new conflict-key or ordering-witness surface: externally visible actions emitted from a turn keep the same D-COMMUTE/CH-ORDERTOK evidence rules they already had.

Pinned v0 posture: `turns-posture-v0.md` (per-component runtime discipline; one active turn per vat; far calls stay async; no hidden inbox pumping; no portable reentrancy/interleaving knob; no workflow/ACP surface).
See RFC-0078.

## CapRPC live sessions (optional)
If **D-CAPRPC** is enabled, standardize a small **explicit live-session seam** for object references so capability RPC stays connection-bound and non-ambient rather than drifting into transparent reconnect/resume or endpoint discovery.

Phase 1 posture keeps this seam **explicit**, **connection-specific**, and **fail-stop**: live refs exist only inside the current session, disconnect deterministically breaks outstanding work, and continuity requires an explicit new session plus explicit bootstrap / introducer capability or explicit **CH-CAPX / CH-SREF** import/restore. Portable v0 deliberately declines a public session/object inventory, routing-table introspection, and transparent resume surface.

Pinned v0 posture: `caprpc-session-posture-v0.md` (explicit live sessions; fail-stop disconnect; explicit restore-only continuity; no session/object inventory or transparent resume surface).

## CapRPC promises + pipelining (optional)
If **D-CAPRPC** promise handles / pipelining are enabled, standardize a small **runtime-local latency seam** for unresolved capability results so remote object APIs do not degenerate into one-RTT-per-step call chains.

Phase 1 posture keeps this adjunct **caller-local**, **session-scoped**, and **one-shot**: promise/result handles are runtime state, not exportable capability objects; pipelining is allowed only toward unresolved **capability results**; and dependent sends must preserve the same sender identity, `iface_digest` / `method_id` checks, and explicit attachment bounds they would have had after normal resolution.

Portable v0 deliberately declines a public promise catalog, cross-session restore/export semantics, and any `join` / `race` / `fork` combinator API on D-CAPRPC itself. Cancellation/disconnect break dependent promise work deterministically, and **D-TURNS** still forbids hidden inbox pumping. Externally visible actions keep the existing provider conflict keys and ordering witnesses they already had; promise state does **not** create a new sequencing or workflow surface.

Pinned v0 posture: `caprpc-promise-posture-v0.md` (caller-local/session-scoped one-shot promise handles; capability-result-only pipelining; deterministic broken-promise/disconnect outcomes; no promise inventory/combinator/admin surface).
See RFC-0026.

## CapRPC oneway notifications (optional)
If **D-CAPRPC** oneway methods are enabled, standardize a small **bounded-notification adjunct** so fire-and-forget calls can carry wakeups/backpressure/status nudges without widening into a mailbox, callback bus, or hidden scheduler surface.

Phase 1 posture keeps this adjunct **interface-marked**, **enqueue-or-error**, and **small**: CH-CAPRPC stays a two-kind frame (`call | return`), oneway rides an ordinary `call` with no permitted return, payloads stay **`<= 256 bytes`**, and oneway carries **zero capability attachments**.

Portable v0 deliberately declines pipelined/promised-answer oneway, durable backlog/replay/resume semantics, delivery receipts, and any public mailbox/list/watch/admin surface. Accepted oneway delivery becomes a normal later turn and does **not** bypass **D-TURNS** or invent a new conflict-key / ordering-witness seam.

Pinned v0 posture: `caprpc-oneway-posture-v0.md` (interface-marked only; no third CH-CAPRPC frame kind; enqueue-or-error; payload <= 256 bytes; zero capability attachments; no durable mailbox/admin surface).
See RFC-0026.

## Privilege bracketing + call-chain contexts (optional)
If **D-BRACKET** is enabled, standardize a small **user-space/runtime guardrail** so privileged capabilities are **dark by default** while helpers/plugins/routers service inbound work, unless code explicitly enters a scoped privileged block.

Phase 1 posture keeps the seam **borrowed-mode-by-default**, **task/request-local**, and **veto-only**: bracketing state lives in task/request-local dynamic scope rather than ambient globals or plain thread-local toggles, privileged blocks are explicit and exception-safe, and bounded **CH-CALLCHAIN** metadata stays optional audit/deny-only context rather than authority.

This seam composes with D-REQCTX, D-CAPSHELL, D-PLUMB, D-SEAL, and D-FCELL without creating a new policy engine: long-lived/background work must mint a fresh owner-controlled root instead of inheriting privileged state by accident, and sealed-compat interop remains explicit and killable.

Pinned v0 posture: `bracket-posture-v0.md` (borrowed-mode default; task/request-local dynamic scope; explicit exception-safe privileged block; bounded optional deny-only CH-CALLCHAIN; no portable stack inspection or workflow/ACP surface).
See RFC-0118.

## Wait sets + object signals (optional)
If **D-WAITSET** is enabled, standardize a small set of pollable **signal bits** per object type (readable/writable/terminated/etc.) and an efficient **WaitSet** object to wait on many handles without O(n) polling loops.

Phase 1 posture keeps the seam **observational and explicit-binding**: waits are **level-triggered by default**, the portable result is **`tag + observed_mask` only**, and payload-bearing queues remain on explicit dequeue/read surfaces owned by the relevant subsystem rather than on D-WAITSET itself. Phase 1 also declines user-injected packet queues, programmable filters, and other control-plane widening on the core wait seam.

Waiting must be **non-amplifying**: registering and waiting cannot create authority (I-WAITSET-1). Bindings and returned batches are bounded and overflow is explicit and deterministic (I-WAITSET-2; PO-WAITSET-BOUND).

Cancellation/deadlines should compose cleanly with request contexts (D-REQCTX) without introducing ambient time: deadlines use explicit Clock handles when D-NONDET is enabled.

Pinned v0 posture: `waitset-posture-v0.md` (observational signal bits; explicit bindings; level-triggered by default; `tag + observed_mask` only; no packet queue/user injection; no workflow/ACP surface).
See RFC-0106.

## Wait-on-address (futex) primitives (optional)
If **D-UWAIT** is enabled, provide a minimal **wait-on-address** primitive (futex/WaitOnAddress/umtx/Zircon-futex lineage) so user-space can implement mutexes/condvars efficiently: uncontended operations stay in user space; the kernel is entered only under contention to sleep/wake waiters.

The primitive must be **bounded and attributable** (D-METER when enabled): waiter state is charged and hard-capped; exhaustion fails closed and deterministically. Phase 1 posture is **process-local** and keyed by one **aligned 32-bit wait word** so the seam does not quietly become a shared-memory signaling substrate.

Core v0 standardizes **wait + wake only**. Requeue, PI, and owner semantics are deferred to explicit future/profile work; owner-death remains the separate D-ROBUSTLOCK surface. Wait operations should compose with request contexts (D-REQCTX) for cancellation/deadlines without introducing ambient time.

Pinned v0 posture: `uwait-posture-v0.md` (process-local only; aligned 32-bit wait word; wait + wake only; no requeue/PI/workflow surface).
See RFC-0110.

## Robust locks + owner-death semantics (optional)
If **D-ROBUSTLOCK** is enabled, add an opt-in kernel/runtime assist for **user-space mutexes** so that if a thread terminates while holding a robust mutex, other local participants do **not** block forever.

Minimal seam:
- A **runtime-owned per-thread RobustSet** (quota-bounded) registers robust mutex words in the caller's writable address space; Phase 1 does **not** claim cross-process/shared-region robust recovery.
- On abnormal owner exit, the runtime/kernel sets an explicit **OWNER_DIED** state in the mutex word and performs a bounded local wake (typically via D-UWAIT where available).
- The next acquirer receives an explicit **owner-died** result and must either repair the protected state and call `make_consistent()` or, if it unlocks/abandons without doing so, the mutex transitions to **NOT_RECOVERABLE** until reinitialized.

This is an ecosystem reliability primitive (Linux robust futex / POSIX robust mutex / Windows WAIT_ABANDONED lineage), but Phase 1 deliberately chooses the stricter POSIX/FreeBSD-style **explicit poison** path rather than silently returning to normal after a successor release.
Pinned v0 posture: `robustlock-posture-v0.md` (per-thread, mutex-only, component-local, explicit `OWNER_DIED` / `NOT_RECOVERABLE`, no workflow/ACP surface).


## Grace periods + deferred reclamation for read-mostly shared state (optional)
If **D-RCU** is enabled, standardize a small **grace-period** seam (RCU/QSBR/EBR lineage) so components can publish new versions of read-mostly shared state and safely reclaim old nodes after readers have quiesced. This is especially valuable for shared inspect state and routing/handle tables, where coarse locks harm latency and snapshot ergonomics.

Minimal seam:
- a per-subsystem **GraceDomain** handle (user-space service/library preferred) that supports `read_enter/read_exit` (or explicit quiescent points in QSBR profiles) and `synchronize()` (wait for a grace period).
- optional `defer_free` queues that reclaim only after `synchronize()` completes.

Waiting must not devolve into polling: implementations SHOULD block via D-UWAIT when available, or surface completion as a D-WAITSET signal bit. Deferred frees and participant counts must be **bounded and attributable** (D-METER when enabled); overflow is explicit and deterministic.

This seam does **not** eliminate stalls: production profiles treat prolonged non-quiescence as a liveness failure under D-SUPV rather than silently growing limbo state.
Pinned v0 posture: `rcu-posture-v0.md` (QSBR-first, per-subsystem/user-space GraceDomains, no ambient/global collector).
See RFC-0112.


## Restartable sequences + CPU-local fast paths (optional)
If **D-RSEQ** is enabled, provide a small **restartable-sequence** seam (Linux rseq lineage) so user-space runtimes can implement bounded **CPU-local fast paths**: short regions that are intended to run start→commit on a single CPU, and if the thread is preempted/migrated/interrupt-delivered before commit, control is redirected to a user-provided abort handler.

This is a performance primitive, not a correctness crutch: regions must be **short and non-blocking** (no faults/IPC/sleeps), and the contract must have a single crisp commit point (“no partial commit”). Registration and metadata are bounded and attributable (D-METER when enabled); high abort rates are observable to supervision.

D-RSEQ must be **profile-gated**: exposing cpu/vcpu identifiers and fine-grained abort behavior is part of the D-NONDET posture, and deterministic replay profiles (D-RR) must disable or virtualize this seam.
Pinned v0 posture: `rseq-posture-v0.md` (runtime-owned single-slot thread registration; no ambient `getcpu`/topology oracle; explicit abort-to-slow-path; no workflow/ACP surface).
See RFC-0113.


## I/O submission queues + completion events (optional)
If **D-IOQ** is enabled, provide a bounded submission/completion **IoQueue** object (shared rings + doorbell) so I/O-heavy services can batch operations without per-op boundary crossings.

Operations must target only explicit handles (no ambient paths) and, when D-IOBUF is enabled, use explicit shared buffer objects. Phase 1 keeps the queue **provider-owned** and **single-op**: one submission entry describes one operation attempt, completions remain on the queue's own ring, and D-WAITSET only reports readiness rather than becoming a second packet bus.

Queue sizing and outstanding operations must be bounded and charged (D-METER when enabled); overflow and teardown behavior must be explicit and deterministic (I-IOQ-2; PO-IOQ-BOUND). Phase 1 declines linked chains, multishot streams, per-SQE credential/personality override, public preregistered handle/buffer inventories, and path/open/create constructors on D-IOQ itself.

Pinned v0 posture: `ioq-posture-v0.md` (provider-owned batching; explicit handles only; one SQE → one op; no path constructors, chain/message-ring drift, or workflow/ACP surface).

## Quiescence + drain protocol (optional)
If **D-QUIESCE** is enabled, standardize a small cooperative maintenance handshake so supervisors/checkpoint tooling can request “stop accepting new work; drain/cancel in-flight work” with a bounded deadline intent (D-REQCTX).

Prefer a two-step pattern: `BeginQuiesce(DRAIN|CANCEL)` → wait for `QUIESCENT` (via D-WAITSET signal bit where supported, or bounded status polling) → perform maintenance (swap/checkpoint/export) → `EndQuiesce`.

Quiesce is **control authority**: it must be capability-gated and non-amplifying (I-QUIESCE-1). New-work gating must be complete while QUIESCING (PO-QUIESCE-GATE), and cancellation outcomes must be explicit with no silent background continuation (I-QUIESCE-2).

Pinned v0 posture: `quiesce-posture-v0.md` (component-local only; one active qid; `DRAIN|CANCEL` only; no force-kill opcode or global/subtree freeze semantics; escalation remains supervisor/runner policy; no workflow/ACP surface).


## Resource meters + kernel object quotas (optional)
If D-METER is enabled, treat resource consumption (memory objects, CPU time, endpoint objects) as **explicit authority**: allocations present meter/budget caps and are charged deterministically. If D-KOBJQ is enabled, kernel-maintained references (cap slots/endpoints/notifications) are also charged to prevent resource-exhaustion DoS.

Design note: keep charging rules *mechanistic* and fail-closed; leave policy (who gets budget) in user space.
## Contract-based channels (optional)
For selected endpoints/channels, treat the allowed message sequences as a **protocol contract** (finite-state machine) and generate wrappers/monitors that reject illegal transitions (supports D-CONTRACT). This is a cheap way to prevent protocol confusion and makes bounded model checking feasible.

## Scheduling (v0)
Start with an SMP-safe baseline: an explicit sequentialization point (e.g., a per-cluster big lock) is acceptable early, but the privileged core MUST run correctly on multiple cores and the concurrency model MUST be pinned (D-CONC/D-MEMMODEL). Refinements (sharding, per-core queues) are staged; the existence of multicore is not.

## Temporal capabilities (optional)
If D-TCAP is enabled, represent CPU time/budget/scheduling authority as explicit capabilities (“time as authority”), so policy can live in user space while the core enforces mechanistic charging and fail-closed exceed behavior (I-TCAP-1; PO-TCAP-ENF). Start with deterministic profiles before expanding scheduling expressiveness.

## Workflow plumbing + portals (optional)
If D-PLUMB is enabled, keep the workflow router a **small explicit-invocation mediation seam** rather than a durable app-bus: requesters submit CH-PLUMBMSG intents, the router evaluates canonical CH-ROUTE rules, and any authority transfer happens only through explicit portal/session outcomes plus receipts/capdiffs.
Pinned portal-session posture: `portal-session-posture-v0.md` (provider-owned request/session objects; one terminal outcome per request; long-lived sessions stay family-local; no generic resume/list/watch/callback surface).

Pinned powerbox posture: `powerbox-posture-v0.md` (designation-scoped, chooser-owned mediation; concrete capability results only; no generic remembered-grant library or candidate/app inventory oracle).
If D-POWERBOX is enabled, keep consent mediation a **designation-scoped grant seam** rather than a generic permission store: callers ask for a bounded authority shape, the chooser/provider owns the candidate set, summaries/diffs stay shell-owned, and durable continuity lives only on family-specific adjuncts such as CH-DOCREF rather than on D-POWERBOX itself.

Pinned explain posture: `explain-posture-v0.md` (canonical shell-owned CH-CAPDIFF summaries; non-authoritative CH-RECEIPT evidence; no generic receipt ledger/admin plane).
If D-EXPLAIN is enabled, keep explainability a **digest-bound evidence seam** rather than a reusable approval store: canonical CH-CAPDIFF bytes define what was shown, CH-RECEIPT records what actually happened, optional conflict/order metadata stays observability-only, and any history/export/notarization UX stays on explicit observation/tooling adjuncts rather than on D-EXPLAIN itself.

Pinned v0 posture: `plumb-posture-v0.md` (request-local completion only; no generic `Subscribe(port)`/held-message pickup; no callback URL/port registry; no app-visible handler/route inventory; no new workflow/ACP/conflict-key surface).

## Event plumbing (optional)
If D-EVENTBUS is enabled, provide a user-space “plumber”-style event router whose publish/subscribe and routing are capability-mediated (I-EVENT-1) and whose cross-boundary payloads are schema-pinned + canonically encoded (I-EVENT-2; PO-EVENT-NOAMBIENT, PO-EVENT-SCHEMA). This can serve as a composition layer for ops/control workflows without introducing ambient broadcast channels.

## Driver domains (optional)
If D-DRVDOM is enabled, keep device logic outside the privileged core. Mediate MMIO/PIO, IRQ delivery, and DMA/IOMMU mappings via explicit I/O resource objects/capabilities (I-IORES-1) and compose with the chosen DMA posture (D-DMA; I-DMA-1). Phase 1 DMA stance is pinned in `dma-posture-v0.md`.

Mechanism note: for virtio-first microVMs, `virtio-iommu` is an optional paravirtual IOMMU seam; see `virtio-iommu-mechanism-note.md`.


## Init→seal authority narrowing (optional)
Services may start with broader authority during initialization, then **seal** into a steady-state by dropping rights/promises and locking down view objects (supports D-SEAL).

## Capability mode / no ambient authority acquisition after entry (optional)
If D-CAPMODE is enabled, entering capability mode is a **one-way no-ambient-acquire posture**: the domain may keep using explicit handles it already holds and may still receive explicit handoffs, but any path/env/default-service/DNS/global fallback must fail closed after entry. D-CAPMODE adds no new interface or admin plane of its own; it is a constraint on existing authority-bearing actions and composes with D-SEAL so long-lived services both **drop excess authority** and **cannot reacquire it ambiently** later. Pinned v0 posture: `capmode-posture-v0.md` (no ambient authority acquisition after entry; pre-opened capability services remain explicit handles, not a license for hidden fallback).

## Constructors and confinement tests (optional)
If **D-CONSTR** is enabled, the pinned v0 posture keeps the seam **user-space, digest-pinned, and evidence-first**: constructor/factory components instantiate a subsystem from pinned template digests plus **schema-pinned data-only** parameter objects, return an **explicit exported surface**, and rely on cap-graph diff + transcript evidence rather than a constructor brand (see `constructor-posture-v0.md`). The reusable Phase 1 boundary split is documented in `constructor-boundary-pattern-v0.md`: template/artifact digests, a data-only parameter object, explicit authority-import slots, a bounded export contract, and transcript bindings stay separate so constructor families do not need a generic constructor protocol. The first concrete family/harness target is `worker-pool-constructor-family-v0.md`: a **sandboxed worker-pool constructor** reusing one exact `digest(CH-EXECPACK v2)` worker closure plus explicit budget/authority imports and a bounded export contract, so we can exercise D-CONSTR on a real subsystem without reopening translator, namespace, or microVM policy surfaces. `worker-pool-constructor-invocation-v0.md` then makes that family implementable by fixing the exact family-local invocation boundary: required imports are `sponsor`, zero or more `worker_seed/<label>` slots, and optional `install_target`; the parameter object stays data-only and bounded; and the exported surface is canonically `pool.control` plus `worker[i]` instead of a caller-chosen label map. `worker-pool-parameter-schema-v0.md` then pins that parameter object as **CH-WPOOLPARAM v0**: a digest-first data-only schema carrying only `pool_size` plus the per-slot restart budget (`restart.max_restarts`, `restart.window_ms`), with automatic replacement disabled exactly when both are `0` and no capability material, import digests, or caller-chosen export labels. `worker-pool-sponsor-surface-v0.md` narrows the required sponsor import itself: exactly one pool-wide reviewed sponsorship root, no ambient payer/session fallback, no sponsor rotation or per-worker sponsor splits, and no sponsor-inventory/admin drift on runtime surfaces. `worker-pool-install-target-surface-v0.md` narrows the optional install path itself: `install_target` is a publication-only owner-visible target seam, install mode is distinct from return-only mode, publication is exact and all-or-nothing for `pool.control` plus `worker[i]`, and any serialization/evidence stays on the target seam instead of becoming constructor folklore. `worker-pool-seed-surface-v0.md` fixes the exact meaning of those repeated `worker_seed/<label>` imports: reviewed import labels only, one pool-wide uniform seed-label set for every worker slot, fail-closed on missing/extra labels, and no per-worker maps or reseed-after-construction drift. `worker-pool-invocation-manifest-v0.md` fixes the exact digest-first object shared by replay/runtime tooling: `invocation.manifest` / `invocation_manifest_digest` contain one canonical field set (`template_set_digest`, `execpack_digest`, `param_digest`, `pool_size`, import/export contract digests, exact `worker_seed_labels`, and `install_mode`) and explicitly exclude target identity, helper handles, and fresh instance state. `worker-pool-control-surface-v0.md` narrows the remaining exported-handle folklore by pinning `pool.control` to one bounded summary verb plus cooperative quiesce mutators only, explicitly declining scale/reseed/job/admin semantics on the family control handle. `worker-pool-describe-summary-v0.md` then pins the exact bounded shape of that summary object itself: the top-level field set is closed to `v`, `invocation_manifest_digest`, `pool_size`, `quiesce_state`, optional `qid`, and `worker_slots`; `qid` follows one exact presence rule; and `worker_slots` is one ordered gap-free slot table rather than an implementation-defined status tree. `worker-pool-quiesce-state-v0.md` then pins the exact bounded meaning of `quiesce_state` itself inside that summary: the pool-level vocabulary is closed to `running`, `quiescing`, and `quiescent`; `qid` is absent only in `running`; `quiescent` keeps the active `qid` in force until `EndQuiesce(qid)`; and Phase 1 adds no mixed/partial/mode folklore on the canonical summary surface. `worker-pool-slot-state-v0.md` then pins the exact bounded meaning of `worker_slots[*].state` inside that summary: the portable slot vocabulary is closed to `starting`, `running`, `backoff`, `failed`, and `quiescing`; there is no separate per-slot `quiescent` state; `backoff` is the only temporary-unavailable state; and active quiesce suppresses automatic `backoff -> starting` re-entry until `EndQuiesce(qid)` releases admission again. `worker-pool-restart-budget-v0.md` then pins the exact operational meaning behind `restart.max_restarts` / `restart.window_ms`: one per-slot sliding admission budget for automatic replacement only, initial fresh occupancy does not spend budget, disabled budgets fail closed directly to `failed`, and successful occupancy only ages admissions out of the trailing window. `worker-pool-worker-surface-v0.md` does the same for the worker-set exports: each `worker[i]` stays a slot-stable typed entry handle for the pinned worker closure, with no per-worker lifecycle/admin wrapper verbs and no transparent live-session continuity promises across restart. `docs/40-verification/worker-pool-capgraph-snapshots-v0.md` then pins the exact caller-scoped graph pair used by the confinement predicate: `capgraph.before` / `capgraph.after` are same-profile `CH-CAPG v0` receipts over one shared observation scope, comparison keys only off the normalized caller-reachable delta over `pool.control` plus `worker[i]`, and whole-system/helper-visible graph dumps stay out of the canonical pair. `docs/40-verification/worker-pool-target-projection-v0.md` then pins the exact install-only target-seam evidence pair: `target.before` / `target.after` are `CH-SPROJ v0` receipts over the same target-seam `(family, key_digest)` pair, each carrying one canonical digest over exactly `pool.control` plus `worker[i]`, with no target-name folklore or inventory/list/watch drift. `docs/40-verification/worker-pool-transcript-slice-v0.md` then pins the exact bounded replay transcript shape itself: `transcript.slice` is a case-indexed window set over ordered `CH-LOG v0` references, with stable case ids and `primary` / `swapped` order variants instead of whole-log dumps or harness-local folder folklore. `docs/40-verification/worker-pool-verdict-summary-v0.md` pins the compact comparison layer that sits beside that slice: `verdict.summary` is one exact case-indexed verdict table with explicit `delta_predicate_ok` / `replay_predicate_ok` bits, canonical `pool.control` + `worker[i]` export shape, and no prose-only/flaky-warning result drift.

Phase 1 deliberately declines a kernel constructor framework, a global constructor catalog/search/watch surface, and no generic constructor portal family / ACP / workflow plane. D-CONSTR also introduces **no generic conflict-key family in v0**: fresh isolated instantiations commute, but any constructor action that mutates an existing owner-visible slot/name/export table must serialize on that target seam’s existing conflict keys and ordering witnesses rather than inventing a second ordering story.

See RFC-0042, `constructor-posture-v0.md`, and `constructor-boundary-pattern-v0.md`.

## Copyless buffer objects (optional)
If IPC/I/O costs dominate, consider immutable buffer objects as explicit shared regions to avoid redundant copies while preserving I-SHARE-1 (supports D-IOBUF).

## Deterministic replay substrate (optional)
Treat CH-KABI + CH-LOG as a stable “privileged action trace” format suitable for replay/testing profiles (supports D-RR).

## Tracing and tracepoints (optional)
If D-TRACE is enabled, add predeclared tracepoints that emit bounded CH-TRACE records and export them via IF-OBS under redaction policy (I-OBS-1). Keep tracing mechanistic (no in-kernel scripting) and fail-closed on overflow (PO-TRACE-NOSTATE). If D-TPROBE is enabled, ship a pinned tracepoint descriptor table (CH-TPROBE v0) so probe IDs have an authoritative field mapping (names/types/redaction) for predicates and tooling. If D-TPRED is enabled, portals MAY accept bounded CH-TPRED predicates for prefiltering (portal-only by default; optional source-prefilter for selected probes per profile). If D-TRACEPROC is enabled, support user-space **trace processors** configured via CH-TRACEPROC v1 (v0 compatible) (often Wasm components, D-WASM) that consume CH-TRACE streams and emit bounded, redaction-safe aggregates under explicit budgets (D-BUDGET).

## Structured diagnostics trees + snapshot bundles (optional)
If **D-INSPECT** is enabled, components MAY publish a bounded, structured “inspect tree” (hierarchical typed state) in a shared region that a diagnostics collector can snapshot without syscalls.
- Exported snapshots use **CH-INSPECT v0** (canonical, bounded; no secrets by default).
- Operators/tools can assemble **support/incident bundles described by **CH-SNAPSHOT v0** (and smaller crash reports via **CH-CRASHCAP v0**), which references logs/traces/inspect snapshots and other artifacts by digest (optionally via CH-AREF).

Adjunct seam:
- If **D-FLIGHTREC** is enabled, the diagnostics collector MAY retain bounded “last N seconds” rings of selected logs/traces/inspect snapshots and assemble a CH-SNAPSHOT capture on crash/watchdog/operator triggers (no ambient auto-export; still CH-OBSPOL scoped). See: RFC-0109.
Snapshot export is explicit authority (capability-gated) and must enforce redaction/minimization (I-OBS-1); treat bundles as sensitive objects by default.

## Memory mappings (v0)
All mapping ops require authority; must preserve I-MAP-1 and I-SHARE-1.

Executable mappings follow D-DYNCODE posture:
- W^X is the default (no RWX).
- RW→RX flips (“execmod”) are capability-gated effects.
- in sealed profiles, executable pages are provenance-bound to signed artifacts (synergy with D-ATOMICUPD).

## User-mode pager / exception servers (optional)
If D-PAGER is enabled, the pinned v0 posture is **object-backed only**: selected pager-backed memory objects route bounded **CH-FAULT v0** messages to declared pager endpoints using object+offset references rather than raw virtual addresses (see `pager-posture-v0.md`). Any mapping/grant decisions remain capability-mediated and must preserve I-MAP-1/I-CAP-1 (see I-PAGER-1; PO-PAGER-ROUTE). Per-address-space pagers and “self-paging” remain explicit future/profile work rather than default Phase 1 semantics.

## Verified blobs + Merkle integrity (optional)
If **D-VERITY** is enabled, the pinned v0 posture keeps the seam **VerifiedBlob-first and immutable**: explicit read-only **VerifiedBlob** handles are the portable consumer-facing unit, reads are verified against a pinned Merkle tree (or equivalent) and **fail closed** on mismatch, and `kind="volume_verity"` remains a boot/update/deployment-local substrate rather than a generic app-visible mount/admin plane (see `verity-posture-v0.md`).

- Identity/intent can be recorded as **CH-VBLOB v0** (bounded, descriptor-only, non-authoritative) for binding into CH-BOOT/CH-UPD artifacts, transcripts (CH-LOG), and incident bundles under CH-OBSPOL.
- Prefer implementations in user-space storage/pager domains (synergy with D-PAGER) to avoid expanding the privileged core; any pager composition must preserve the pinned read-only/object-backed D-PAGER posture, does **not** import mutable pager writeback semantics, and must not quietly widen into mutable writeback.
- Verification caches and hash-tree metadata MUST be bounded and (when D-METER is enabled) attributable, so verified reads cannot be abused as unbounded CPU/I/O work.
See: RFC-0114 and `verity-posture-v0.md`.

## Networked capability delegation (optional)
If D-CAPX is enabled, delegated authority that crosses a trust boundary is represented as an explicit envelope (CH-CAPX) that binds opaque token/reference bytes to local **proxy/service** IDs rather than raw kernel/user capability ids. Keep token/runtime complexity in user space; the privileged/core seam should validate canonical bytes + bindings, but not grow a portable caveat/policy VM (I-CAPX-1/I-ENC-1).
Pinned v0 posture: `capx-posture-v0.md` (gateway-owned, proxy-first import seam; no raw-cap binding; no ambient resolver/inventory; no portable caveat VM on D-CAPX itself).

## Local naming certificates (optional)
If D-NAMECERT is enabled, keep local naming/delegation as a **user-space evidence seam**: CH-NAMECERT bundles label or delegate authority inside an issuer-local namespace, but they do not become a privileged chain evaluator, a global directory, or a second ambient resolution plane. Naming services consume an **explicit bundle set**, apply explicit local trust/visibility policy, and in Phase 1 may materialize authority-bearing results only through explicit D-NS `view.attach` / `view.detach` actions on concrete `view.slot` keys; any D-CAPX/proxy labels remain observational metadata only.
Pinned v0 posture: `namecert-posture-v0.md` (issuer-local, evaluator-local naming evidence; no ambient fetch/global resolver; no automatic view install; no portable policy VM on D-NAMECERT itself).
Projection boundary: `namecert-projection-boundary-v0.md` (view-slot-only materialization, retained `digest(CH-NAMECERT v0)` provenance, no bulk install/watch-sync path).
Time boundary: `namecert-time-boundary-v0.md` (validity/freshness gates explicit admission only; no self-expiring live bindings, background sweepers, or timeproof-triggered detach).
Revocation boundary: `namecert-revocation-boundary-v0.md` (later negative evidence stays evaluator-local and admission-scoped; no ambient CRL/OCSP or latest-wins semantics, and no automatic detach of live bindings when revocation is learned).
Selection boundary: `namecert-selection-boundary-v0.md` (evaluation is set-valued when multiple candidates survive local policy; D-NAMECERT adds no hidden ranking/default-winner rule, and any live binding must identify the exact chosen candidate with retained source digests).
Search boundary: `namecert-search-boundary-v0.md` (evaluation is closed-world over one explicit bundle set; bounded local goal-directed search is allowed, but there is no suspend/resume distributed credential discovery, ambient fetch/chase, or hidden retry daemon).
Redelegation boundary: `namecert-redelegation-boundary-v0.md` (delegated subjects do not implicitly gain onward delegation power in Phase 1; CH-NAMECERT v0 carries no `may_delegate` / propagation-bit / depth field, so multi-hop delegation chains reject unless each issuer is independently authorized).
Trust-root boundary: `namecert-trust-root-boundary-v0.md` (trust anchors are explicit evaluator-local input; CH-NAMECERT is not itself a trust root or trust-policy container, bundles cannot self-anchor, and replicated arrivals cannot auto-install anchors or rewrite live bindings).
Normal-form boundary: `namecert-normal-form-boundary-v0.md` (admitted `bindings` / `delegations` arrays are duplicate-free and strictly sorted by canonical element bytes; statement order/repetition is non-authoritative, so there is no first-match/last-match or weighted-duplicate semantics).
String-profile boundary: `namecert-string-profile-v0.md` (authority-bearing `Binding.name` / `Delegation.role` labels use a tiny exact-byte lowercase ASCII class only; no Unicode normalization, case-folding, PRECIS, or confusable-policy seam on D-NAMECERT itself).
Label-atom boundary: `namecert-label-atom-boundary-v0.md` (admitted Phase 1 labels are single opaque atoms after validation: `.` / `_` / `-` remain ordinary bytes, and D-NAMECERT imports no hierarchy, wildcard, prefix/suffix, or path grammar onto `Binding.name` / `Delegation.role`).
Principal-profile boundary: `namecert-principal-profile-v0.md` (admitted `PrincipalRef` identities are hash-only and canonical in Phase 1: `kind="key_hash"`, `alg="cose_key_thumbprint_sha256"`, exact 32-byte thumbprints, and no raw `kind="pubkey"` admissions).
Signature-profile boundary: `namecert-signature-profile-v0.md` (admitted bundles use exactly one inline direct `ed25519` signature over the canonical unsigned bundle bytes; wrapper-only, keyless/X.509, and multisignature admission semantics stay out of D-NAMECERT v0).
Metadata boundary: `namecert-metadata-boundary-v0.md` (`bundle_id` / `created_ms` are signed provenance only in Phase 1; no latest-wins, implicit replacement lineage, or metadata-driven freshness/obsolescence semantics on D-NAMECERT itself).
Bearer boundary: `namecert-bearer-boundary-v0.md` (admitted CH-NAMECERT bundles are never bearer-cap transport; raw CH-SREF / CH-CAPX / raw capability material is forbidden, `TargetRef.kind="sturdyref"` is reserved+rejected, and capability-bearing import stays on explicit D-CAPX / CH-SREF seams).

## Membranes + sealers/unsealers (optional)
Across trust boundaries (components, plugins, remote gateways), consider **membranes** (revocable forwarders) and **sealers/unsealers** to keep authority mediated and optionally revocable without leaking raw capabilities (supports D-MEMBRANE).

## Capability leases + limited-use proxies (optional)
If D-LEASE is enabled, prefer **leased proxy capabilities** at boundaries and portal grants: proxy objects enforce **time-limited** and/or **use-limited** bounds before forwarding to an underlying cap, without leaking the raw cap.  
Time-based leases depend on explicit Clock handles (D-NONDET) so “no ambient time” profiles stay honest; expiry must fail closed.  
For audit/UX, emit a redaction-safe **CH-CAPLEASE** descriptor digest in CH-LOG/receipts (D-EXPLAIN), and treat leases as non-durable by default (D-PERSIST).

## Key-holding authentication agent (optional)
Consider a factotum/ssh-agent style user-space **crypto provider** that holds long-lived keys and exports only capability-mediated operations (sign/decrypt/derive/attest), so key material is never handed to clients (supports D-AUTHAGENT).  
Phase 1 posture is pinned in `cryptosvc-posture-v0.md`: access remains **explicit-route only** (no ambient `SSH_AUTH_SOCK`/path/env discovery), the cross-component surface stays op-only, provider-global key inventory is out of scope, and `cryptosvc-forwarding-boundary-v0.md` freezes cross-boundary use to **explicit narrowed routes only** rather than transparent forwarded-agent behavior.

If D-CRYPTOSVC is enabled, pin the key interface as data:
- key usage policy is explicit (**CH-KEYPOL**) and operations are checked against it (purpose/context tags; optional confirm/rate hints)
- durable references use **CH-KEYREF** (CapStore stores references, not secrets)
- crypto usage is audit-visible without leaking payloads via **CH-CRYPTOAUDIT** embedded/referenced in **CH-LOG**

If D-VAULT is enabled, extend the same pattern from keys to **credentials and opaque secrets**.
Phase 1 posture is pinned in `vault-posture-v0.md`: the portable surface remains **ref-bound and non-inventory** (CH-SECRETPOL + CH-SECRETREF + closed ops only), not a collection/search broker; optional recovery/federation remains a profile-explicit annex rather than default behavior.
- secret usage policy is explicit (**CH-SECRETPOL**) and enforced by the vault provider (context + evidence requirements)
- durable references use **CH-SECRETREF** (CapStore stores references, not secret blobs)
- high-risk secret release can be consent/receipt bound (CH-AUTHZ + CH-VOL + CH-RECEIPT/CH-CAPDIFF) or attestation-gated in D-CC profiles, without pushing policy into the privileged core

Bind operations to meters/budgets (optional) and to transcripts (CH-LOG) for auditability, and prefer leased delegation (D-LEASE) when sharing key authority across boundaries.


## Capability store / orthogonal persistence (optional)
If D-PERSIST is enabled, implement a user-space **CapStore** service that persists **named roots** and durable capability graphs (via sturdyrefs).  
Persistence must be **explicit authority**: clients need a CapStoreCap / DurableRootCap to make state durable; otherwise authority dies on reboot.  
Boot/resume can then treat “resume is boot”: CH-BOOT may point at a CapStore root commit (CH-CAPSTORE) and init chooses fresh-boot vs resume. Pair with D-CHKPT (CH-CKPT) for snapshot/migration semantics and with D-RR for auditable recovery traces.

## Sandboxed component runtime (optional)
If D-WASM is enabled, a user-space Wasm runtime can serve as a plugin boundary. Treat the host boundary as “imports are capabilities”: no ambient filesystem/network/time access by default (I-WASM-1), and pair with init→seal for long-lived hosts (D-SEAL).
