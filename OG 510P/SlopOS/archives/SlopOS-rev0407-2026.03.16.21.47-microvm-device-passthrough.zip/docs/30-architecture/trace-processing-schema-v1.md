# CH-TRACEPROC v1: Trace processing request (schema)

Purpose: configure **user-space** trace processors that consume CH-TRACE records and emit bounded, redaction-safe outputs.

This version adds an optional **prefilter** reference (CH-TPRED) so portals can safely reduce event volume before expensive processing.

Design stance:
- no in-kernel scripting
- processors run in an untrusted sandbox (typically Wasm; D-WASM)
- strict bounds and deterministic failure behavior
- optional predicates are boolean and bounded (D-TPRED)

Refs: REF-DTRACE, REF-EBPF-INTRO, REF-WASM-CM-INTRO.

## Encoding
Canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-TRACEPROC v1 := {
  v: 1,

  kind: tstr,                  ; closed enum: "install" | "remove" | "update"
  id: bstr,                    ; caller-chosen stable id (scoped to origin)

  ; which trace events this processor may receive
  probes: [ tstr ],            ; bounded list of tracepoint ids (profile-defined names or numeric tags)

  ; optional prefilter applied by the portal (or at source if D-TPRED profile allows)
  filter?: {
    kind: tstr,                ; closed enum: "tpred"
    ref: bstr,                 ; digest(CH-TPRED)
  },

  ; processor payload (required for install/update)
  proc?: {
    kind: tstr,                ; closed enum: "aref" | "handle"
    ref: bstr,                 ; digest(CH-AREF) or opaque handle id (policy-defined)
  },

  ; resource bounds (portal may clamp)
  limits?: {
    cpu_ms_per_s?: uint,
    mem_bytes?: uint,
    out_bps?: uint,
    max_state_bytes?: uint,
  },

  ; output discipline hints (policy may ignore)
  output?: {
    kind: tstr,                ; closed enum: "counters" | "summaries" | "digests"
    max_items?: uint,
    max_value_bytes?: uint,
  },

  ttl_s?: uint,

  meta?: { * tstr => any }     ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 1` and required fields present.
2) `kind` is in the closed set.
3) bounds enforced:
   - `probes` length bounded
   - `id` length bounded
   - `limits` values clamped/rejected if out of policy range
4) if `kind in {"install","update"}`, `proc` MUST be present.
5) `proc.kind` must be allowlisted by policy; `proc.ref` must be well-formed:
   - if `aref`, portal MUST verify referenced digest matches the loaded artifact (PO-AREF-VERIFY).
6) if `filter` is present:
   - `filter.kind == "tpred"`
   - portal MUST validate the referenced CH-TPRED against the allowed probe set and bounds (PO-TPRED-VALIDATE/BOUNDS)
   - policy may require portal-only evaluation or allow source-prefilter depending on D-TPRED
7) output settings are hints; portal enforces the actual export/redaction policy (I-OBS-1).

## Compatibility notes
- CH-TRACEPROC v0 remains valid. v1 adds an explicit `filter` field rather than overloading `meta`.
- Portals MAY accept v0 and treat it as v1 with `filter` absent.

## Notes
- A trace processor is *not* a privileged extension. It is an untrusted computation over observation streams.
- For deterministic testing/replay, record (proc_digest, config_digest, optional predicate_digest) alongside traces when relevant.
