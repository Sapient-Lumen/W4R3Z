# CH-TIMEPROOF v0: authenticated time sample / proof record (optional)

Purpose: a **bounded, normalized record** of an authenticated time sample that can be exported as evidence.

CH-TIMEPROOF is not the full time-sync protocol. It’s a stable “receipt” that:
- identifies the authority/key used,
- records a `(midpoint, radius)` time statement (uncertainty),
- binds to a request nonce (freshness), and
- optionally binds to a raw proof blob via CH-AREF.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-TIMEPROOF-v0 {
  schema: "CH-TIMEPROOF";
  version: 0;

  kind: enum { roughtime, other };

  # Authority identity (verification policy is profile-defined)
  authority: {
    kind: enum { pubkey_hash, other };
    id: bytes32;            # e.g., hash(pubkey) for roughtime
    label?: string;         # optional human label (bounded)
  };

  # Freshness binding
  nonce_hash: bytes32;      # H(request NONC) or equivalent

  # Time statement
  time: {
    unix_sec: u64;          # midpoint seconds since UNIX epoch
    unix_nsec: u32;         # 0..999,999,999
    radius_ms: u32;         # uncertainty radius in milliseconds
  };

  # Local observation metadata (optional, bounded)
  observed?: {
    rtt_ms?: u32;           # coarse round trip estimate
    recv_mono?: u64;        # local monotonic counter at receipt (units profile-defined)
  };

  # Optional bindings for audit correlation
  boot_digest?: bytes32;    # digest(CH-BOOT) when explicitly bound by tooling
  policy_revision?: u64;    # optional monotonic policy/config rev used in the deployment

  # Optional raw proof reference (recommended for audit)
  raw_ref?: CH-AREF-v0;     # digest-addressed raw response blob (bounds enforced by policy)
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `authority.id` and `nonce_hash` must be exactly 32 bytes.
- `unix_nsec` must be < 1e9.
- `radius_ms` must be bounded by policy (suggested default max: 10 minutes).
- `label` length must be ≤ 96 bytes.
- Phase-1 posture accepts only `kind=roughtime` and `authority.kind=pubkey_hash`; `other` values are reserved and MUST reject fail-closed in v0 (see `timeproof-posture-v0.md`).
- `raw_ref` is optional; if present, it must satisfy CH-AREF validation (I-AREF-1) and any profile allowlists.

## Security posture
- CH-TIMEPROOF is **observational**.
- In v0 it is **lower-bound evidence**, not an ambient clock-setting API: verified samples may advance security time lower bounds only under explicit policy (see `timeproof-posture-v0.md`).
- It must not contain secrets.
- Treat it as potentially sensitive metadata (network + timing hints). Export should be scoped by CH-OBSPOL.

References: REF-ROUGHTIME-PROTOCOL; REF-ROUGHTIME-IETF; REF-RFC-8915.
