# CH-REQCTX budget reference posture v0 (untyped digest list; consumer-typed)

Purpose: make explicit-budget enforcement (D-BUDGET) **mechanically checkable** even though CH-REQCTX v1 carries an *untyped* `budget_desc_digests` list.

This doc is intentionally narrow: it pins how validators interpret `budget_desc_digests` when a workflow **requires** explicit sponsorship
(e.g., `capshell.exec` under `cfg.params.capshell.require_budget_lease=true`).

## Posture (v0)

1) **`budget_desc_digests` is untyped by design (CH-REQCTX v1)**
   - The list elements are `bytes32` digests only.
   - The list MUST NOT be treated as a polymorphic “resolver hint”.

2) **Consumers are type-strict (veto-only)**
   - When an interface requires a budget, **only** descriptors that validate as **CH-BUDGET v0** satisfy the requirement.
   - Any digest that resolves to a different schema version/kind MUST be treated as **not a budget** (do not guess).

3) **Resolution is non-ambient**
   - Validators MUST resolve digests using **only** explicitly provided artifact material (e.g., the proposal bundle / local artifact store) and MUST NOT dereference locators (`file:`, `https:`, etc.).
   - This composes with the CH-AREF posture: CH-AREF `locator` is a hint; privileged code does not fetch.

4) **Fail-closed enforcement**
   - If a required budget cannot be validated from the available artifacts, the action MUST deterministically deny (receipt-shaped).

## Phase 1 non-goals (explicitly deferred)

- No CH-REQCTX field upgrade from bare digests to typed sponsorship objects; OQ-0008 is resolved by `reqctx-sponsorship-evolution-boundary-v0.md`, which requires any future typed sponsorship surface to live outside CH-REQCTX.
- No ambient “find me a budget” fallback (no portal fetch; no implicit store sync).
- No standard budget policy language in v0 (policy lives in portal/service implementations).

## Wiring

- Decision surfaces: `decision-map.md` (D-REQCTX, D-BUDGET).
- CH-REQCTX v1 schema: `request-context-schema-v1.md` (field definition + bounds).
- Evolution boundary: `reqctx-sponsorship-evolution-boundary-v0.md`.
- CH-BUDGET v0 schema: `budget-lease-schema-v0.md`.
- Capshell budget requirement seam: `docs/70-llm-control/acp-validator-semantics.md`, `docs/70-llm-control/acp-action-kind-registry.md`, and PO-CAPSHELL-BUDGET-REQ.
- Sealed compat posture: `artifact-resolution-posture-v0.md` (no locator deref in privileged resolution).
- CI drift gate: `tools/check_reqctx_budget_ref_posture.py` (EVID-2026-205).

## References

- REF-SEL4-SCHEDCTX-EUROSYS18 (capability-shaped time/budget authority precedent)
- REF-CGROUPV2 (resource control as explicit structure; comparison only)
