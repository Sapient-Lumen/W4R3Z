# Capshell network posture v0 (no ambient sockets or resolver baseline)

Purpose: keep **D-CAPSHELL** honest once workflow launch already has explicit argv/env/cwd/stdio/fdset
and explicit effect contracts. Those seams still drift if the runner quietly preserves **ambient network
authority** from the host/session/runtime: raw socket constructors, host-global resolver state,
`/etc/resolv.conf`-style DNS defaults, NSS/service-discovery lookup, proxy autodiscovery, or wrapper
behavior that simply “lets the child use the normal network stack”.

This adjunct closes that seam. It is intentionally narrow: it does **not** redesign D-NETLEASE,
introduce a socket ABI, standardize a portable packet filter, or add a reviewed per-step raw-socket /
resolver policy surface. It only freezes the minimum Phase 1 posture needed so `capshell.exec`
remains capability-safe instead of inheriting host networking lore.

## Posture (v0)

1) **No ambient socket constructors at `capshell.exec`**
   - A reviewed `capshell.exec` launch does **not** imply raw `socket()` / `connect()` / `bind()` /
     `listen()` authority, ambient host-network-stack reachability, or “normal machine networking” as a
     portable baseline. In other words: **no ambient socket constructors** are part of Phase 1
     capshell launch semantics.
   - If the active runtime or compat membrane cannot prevent ambient network access at the launch
     boundary, it MUST reject/fail closed rather than silently widening child authority.

2) **Networked behavior stays on explicit D-NETLEASE seams**
   - Phase 1 adds **no reviewed per-step raw socket / resolver surface** to CH-EXECPACK, CH-ARGV,
     CH-ENV, CH-CWD, CH-STDIO, or CH-FDSET.
   - Phase 1 adds no reviewed per-step raw socket / resolver surface.
   - Any portable networked behavior for `capshell.exec` therefore routes only through the existing
     **D-NETLEASE** seam: `portal.net` in **CH-EFFCON v0** and reviewed **CH-NETLEASE v0**
     descriptors/receipts.
   - If a workflow does not carry the reviewed `portal.net` effect family, runners/wrappers MUST NOT
     conjure network access on the child's behalf.

3) **No ambient DNS / resolver baseline**
   - `capshell.exec` does **not** inherit host-global DNS / resolver configuration as a portable
     baseline.
   - Phase 1 declines `/etc/resolv.conf` / NSS / `getaddrinfo()`-style global resolver discovery,
     proxy autodiscovery, or similar host lookup behavior as part of the reviewed launch contract.
   - When name resolution is authorized, it stays on explicit **CH-NETLEASE v0** bindings whose
     `resolver.kind` is already pinned to `"portal"` by D-NETLEASE.

4) **Other execution-pack seams do not secretly mint network authority**
   - **CH-ENV v0** may carry literal proxy or endpoint strings, but env bytes alone do **not** grant
     networking.
   - **CH-STDIO v0** and **CH-FDSET v0** stay explicit file/descriptor binding surfaces, not a license
     to inherit host socket tables, resolver service handles, or ambient transport sessions.
   - **CH-CWD v0** and **CH-ARGV v0** do not authorize host-network fallback, service-name discovery,
     or out-of-band endpoint lookup.

5) **Commutativity and ordering stay on existing seams**
   - This posture introduces **no new ACP kind**, **no new conflict-key family**, and **no new
     serialization plane**.
   - Ordering for launch remains the existing `capshell.exec` story; ordering for leased networking
     remains the already-defined `portal.net.request` / network-lease seam.

6) **Sealed compat remains killable and non-ambient**
   - Compat/foreign-cell adapters MUST NOT recreate “normal host sockets” or host-global DNS as a
     hidden convenience behind D-CAPSHELL.
   - Any legacy socket mediation remains explicit, policy-killable, and subordinate to D-NETLEASE
     rather than a side door around it.

7) **No new workflow / ACP / admin surface**
   - Phase 1 adds no `capshell.net.*`, no reviewed per-step socket family list, no raw DNS API, and no
     shell-owned connection inventory.
   - Any future explicit socket/runtime broker must return as its own RFC-first seam rather than
     hiding inside `capshell.exec`.

## Phase 1 non-goals (explicitly deferred)

- No reviewed per-step raw socket / bind / listen API for capshell.
- No portable DNS / NSS / service-discovery control surface in CH-EXECPACK.
- No hidden "inherit the machine network stack" compatibility promise.
- No socket-handle-passing escape hatch that bypasses D-NETLEASE.

## Wiring

- Decision surfaces: `docs/30-architecture/decision-map.md` (**D-CAPSHELL**, **D-NETLEASE**).
- Existing network seam: `network-lease-posture-v0.md`, `network-lease-schema-v0.md`,
  `network-request-schema-v0.md`, `effect-contract-schema-v0.md`.
- Capshell schema/control seams: `capshell-exec-pack-schema-v2.md`,
  `docs/70-llm-control/acp-action-kind-registry.md`,
  `docs/70-llm-control/acp-validator-semantics.md`, `docs/60-engineering/cli-plumbing-tooling.md`.
- Assurance anchors:
  - `I-CAPSHELL-NET-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-NET-EXPLICIT` in `docs/20-assurance/proof-obligation-registry.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_network_posture.py` (**EVID-2026-334**).

## References

- REF-MAN7-SOCKET
- REF-MAN7-CONNECT
- REF-MAN7-GETADDRINFO
- REF-MAN7-RESOLV-CONF
