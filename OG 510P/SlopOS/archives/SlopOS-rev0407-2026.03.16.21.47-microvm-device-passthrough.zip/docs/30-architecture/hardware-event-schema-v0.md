# CH-HWEVENT v0 (hardware event record, informal)

Purpose: represent **bounded, auditable** changes to the hardware fact base after boot (hotplug, device removal, link state changes) without embedding device logic in the privileged core.

Primary consumer: user-space SKB (RFC-0018) and device manager/driver manager (RFC-0085/RFC-0083).

Refs: REF-MULTIKERNEL-SOSP09, REF-BARRELFISH-SKB, REF-FUCHSIA-DRIVER-FRAMEWORK.

## Constraints (v0)
- deterministic encoding + canonical bytes (I-ENC-1)
- closed enum of event kinds (no free-form bags)
- bounded payloads; large blobs are represented as digests (CH-AREF)
- monotonic sequencing per epoch

## Shape (v0)
A hardware event record `e` contains:
- `schema`: fixed `CH-HWEVENT v0`
- `epoch`: u64 (fact-epoch identifier; initial epoch is derived from CH-HWFACT)
- `event_seq`: u64 (monotonic counter within an epoch; never decreases)
- `ts`: optional coarse timestamp (if D-NONDET/D-TIMEPROOF is enabled; otherwise omitted)
- `kind`: one of the closed event kinds below
- `payload`: kind-specific, bounded fields
- `digests`: optional bounded list of `{ tag, digest }` for external blobs (e.g., sanitized descriptor bytes)

### Event kinds (closed)
Each `kind` implies a bounded payload:
- `device_added`
  - `bus`: enum { usb, pcie, platform, virt }
  - `loc`: redaction-safe location token (bus-defined; not a path authority)
  - `id`: `{ vendor_id, device_id, class }` (bounded)
  - `hints`: optional bounded tags (e.g., `dma_capable`, `removable`)
- `device_removed`
  - `bus`, `loc`, optional `reason` enum
- `link_state`
  - `bus`, `loc`, `state` enum { up, down, degraded }
- `irq_reroute`
  - `irq_token`, `from`, `to` (bounded identifiers)
- `iommu_state`
  - `present`: bool, `mode` enum (bounded)

## Validation obligations
- reject unknown `kind` values
- enforce bounds on lists and strings
- enforce monotonic `event_seq` per `{epoch}` (reject decreases)
- reject embedded raw descriptor dumps (use digests)

## Notes
- CH-HWEVENT is intended to be **sufficient** for audit/replay and policy determinism, not for driver bring-up.
- Security-relevant attach/detach decisions should reference `{epoch, event_seq}` and the digests of related CH-HWEVENT records.
