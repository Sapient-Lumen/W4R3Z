# D-CONSTR boundary pattern v0 (template digests; data-only params; explicit imports; export contracts)

Purpose: pin the **smallest reusable constructor-family boundary pattern** for Phase 1 so
D-CONSTR becomes easier to implement without inventing a generic constructor portal, a generic
request schema, or a second authority plane. This resolves the “what is the smallest reusable
parameter-object pattern?” question in RFC-0042 by keeping constructor invocations split across
**template digests**, **data-only parameters**, **explicit authority imports**, an **export contract**,
and **transcript/evidence bindings**.

## Phase 1 pattern

1) **Invocation shape is split into template digests, data-only parameters, explicit authority imports, an export contract, and transcript bindings**
   - A constructor-family invocation is defined by:
     - a **digest-pinned template/artifact set** (typically **CH-COMP** plus any pinned init fragments / helper artifacts),
     - a bounded **schema-pinned parameter object**,
     - an **import contract** describing the typed authority slots the constructor expects,
     - an **export contract** describing the bounded caller-visible surface it may return,
     - transcript/evidence bindings that tie the whole instantiation to replay and confinement checks.
   - This is a **pattern**, not a new generic constructor RPC/request schema. Phase 1 deliberately avoids a universal constructor request/receipt protocol surface.

2) **Parameter objects stay data-only and ambient-free**
   - Parameter objects carry only bounded data such as enums, sizes, policy knobs, local symbolic labels, and digests.
   - They MUST NOT carry live capabilities/handles, bearer refs, raw paths, environment-variable names, hostnames, DNS names, global service names, URLs, or “fetch this template by name” instructions.
   - If a constructor family needs bytes/artifacts beyond its pinned template set, those arrive through explicit imports or content-addressed refs already authorized elsewhere; they do not get re-fetched ambiently (**D-CAPMODE**, **I-CAP-1**).

3) **Authority imports are explicit invocation-local slots, not serialized parameters**
   - Any authority-bearing input arrives on explicit, invocation-local import slots with an owner-defined typed contract (for example: budget root, pager endpoint, document handle, network lease, or translator attach point).
   - The import contract may name slot labels, rights expectations, and multiplicity/cardinality, but it does not create global discovery semantics or an ambient “look this up for me” fallback.
   - Missing or mismatched imports fail closed; constructors do not silently synthesize or widen authority.

4) **Export contracts are bounded and replay-friendly**
   - Each constructor family declares the bounded shape of the caller-visible result: which handles are returned, which are fresh, which begin sealed/live/pending, and which caller-visible slots/names (if any) may be written.
   - D-CONSTR v0 therefore keeps “export contract” separate from the internal graph the constructor may build while wiring the subsystem.
   - Constructors should finish setup, then narrow steady-state authority using **D-SEAL** where applicable.

5) **Receipts bind digests, not live authority**
   - Transcript-visible constructor evidence MUST bind at least:
     - the template/artifact digest set,
     - `params_digest`,
     - `import_contract_digest`,
     - `export_contract_digest`, and
     - references to the cap-graph / transcript evidence used for **PO-CONSTR-CONFINE** and **PO-CONSTR-REPLAY**.
   - Receipts may name owner-local slot labels or export names, but they MUST NOT serialize live capabilities or become a bearer restore path.
   - The replay story is therefore “same template digests + same parameter object + same declared contracts,” not “replay hidden ambient lookups.”

6) **Commutativity stays on the target seam**
   - A constructor invocation **commutes** when it allocates a fresh isolated subgraph, consumes only its explicit imports, and returns results only through fresh export handles/slots that were previously unoccupied.
   - It does **not** commute when it mutates/replaces an existing owner-visible slot, name, view binding, export table entry, or budget root. In those cases serialization lives on the **target seam's existing conflict keys and ordering witnesses**, not on D-CONSTR itself.
   - The export contract must say which owner-visible target seam, if any, is mutated so ordering evidence stays honest.

7) **No generic constructor request/receipt schema or constructor-global admin plane in v0**
   - Phase 1 does **not** standardize a universal constructor invocation schema, constructor-global receipt schema, constructor inventory API, constructor watch/list API, or constructor admin surface.
   - Constructor families may document owner-specific schemas/contracts, but those remain subordinate to the owning seam instead of becoming a cross-cutting constructor protocol.

## Phase 1 non-goals (explicitly deferred)

- No generic constructor request/receipt schema family in v0.
- No authority-bearing parameter objects or serialized live-handle arguments.
- No ambient lookup/import semantics (`PATH`, env, hostnames, service registries, implicit network fetch) inside constructor parameters.
- No constructor-global conflict-key family or ordering service.
- No constructor catalog/list/watch/inventory surface layered on top of this boundary pattern.

## Wiring

- Decision surface: `decision-map.md` (**D-CONSTR**).
- Primary posture: `constructor-posture-v0.md`.
- Narrative/mechanism surfaces:
  - `mechanisms.md`.
  - `rfcs/0042-constructors-and-confinement-tests.md`.
  - `docs/00-meta/roadmap.md`.
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-CONSTR-1**, **I-CONSTR-2**).
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**).
- Adjacent authoritative seams:
  - `component-manifest-schema-v0.md` / **CH-COMP**.
  - `capmode-posture-v0.md` / **D-CAPMODE**.
  - `seal-posture-v0.md` / **D-SEAL**.
  - `docs/70-llm-control/acp-action-kind-registry.md` (still no generic constructor ACP kind in v0).
- Discovery / continuity surfaces:
  - `README.md`.
  - `docs/README.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/resolved-history.md`.
- CI drift gate: `tools/check_constructor_boundary_pattern.py` (**EVID-2026-357**).

## References

- REF-KEYKOS-NANOKERNEL
- REF-EROS-CONFINEMENT
- REF-GENODE-INIT
- REF-SHILL-OSDI14
