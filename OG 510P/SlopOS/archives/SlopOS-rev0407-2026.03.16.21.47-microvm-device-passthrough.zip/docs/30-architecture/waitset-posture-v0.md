# D-WAITSET posture v0 (observational level-triggered waits; no packet/control-plane drift)

Purpose: pin an implementable v0 meaning for **D-WAITSET** so scalable event loops stay a small observational seam rather than widening into a packet bus, programmable filter VM, hidden control plane, or ambient timeout/oracle surface.
It narrows RFC-0106 into one compact posture validators and harnesses can reason about: explicit handle bindings, level-triggered signal observations by default, bounded batches, and no new workflow/ACP surface.

## Posture (v0)

1) **Optional observational event-loop seam, not a packet/control plane**
   - If D-WAITSET is enabled, it is a **low-level runtime / server-loop primitive** for waiting on many explicit handles efficiently.
   - Phase 1 does **not** standardize a message queue, a generic packet mailbox, a cross-thread notification bus, or an application-facing event broker on this seam.
   - Wait results are observations over already-authorized object state, not new authority or transport (I-WAITSET-1; I-WAITSET-3).

2) **Object signals are level-triggered observations by default**
   - v0 signals are **current-state bits** derived from object state (for example `READABLE`, `WRITABLE`, `TERMINATED`, `PEER_CLOSED`).
   - Wait completion returns the currently observed mask; callers that care about progress MUST re-check object state after return.
   - Phase 1 therefore treats edge-triggered / one-shot / auto-rearm behavior as deferred profile work rather than the default portable contract.

3) **Explicit handle bindings only; no ambient namespace or remote wait broker**
   - `WaitSet.bind` attaches only to **explicit handles/capabilities already held by the caller**.
   - v0 does **not** standardize path/fd lookup, ambient namespace subscription, cross-process registration by identifier, or a remote wait-broker service that lets one domain observe another by name.
   - Waiting remains capability-mediated and non-amplifying (I-WAITSET-1; PO-WAITSET-NOAMP).

4) **One binding per `(WaitSet, handle)` in v0; modify means re-bind**
   - A given handle appears at most once in a given WaitSet in Phase 1.
   - If a caller wants a different mask or tag, it MUST unbind and re-bind explicitly rather than depending on silent merge or duplicate-registration semantics.
   - This keeps bind churn deterministic and prevents duplicate registrations from becoming an accidental multi-delivery policy surface.

5) **Returned events carry `tag + observed_mask` only; no packet payloads on the core seam**
   - The core v0 wait result is a bounded batch of `{tag, observed_mask}` observations.
   - Phase 1 does **not** standardize payload-bearing event packets, inline user data beyond the caller-supplied tag, or opaque per-event blobs on D-WAITSET itself.
   - Higher-level queues that need payloads must expose them through their own explicit dequeue/read surface (for example D-IOQ completion rings) while using D-WAITSET only for readiness.

6) **No user-injected events or packet queue on the core seam**
   - D-WAITSET v0 does **not** include a `queue_packet`, `post`, or equivalent operation for user code to inject synthetic events into another waiter.
   - Phase 1 therefore declines the IOCP/port-style pattern where the same object doubles as both readiness wait set and general in-process packet queue.
   - External wake/control paths must stay on explicit adjunct surfaces rather than piggybacking on wait infrastructure.

7) **`wait_many` remains the bootstrap/small-set adjunct; WaitSet is the scalable path**
   - Phase 1 may keep a small `wait_many(items[])` primitive for bootstrap code and tiny sets.
   - The scalable portable posture, however, is **explicit WaitSet bind/unbind/wait**, not repeated ad hoc scans or subsystem-specific poll APIs.
   - This keeps server/drivers/event loops on one reviewable pattern while leaving tiny runtimes a minimal fallback.

8) **Deadlines/cancellation are explicit adjuncts, not ambient time**
   - If D-REQCTX is enabled, runtimes MAY wire `ctx.cancelled` into a bound cancel source or equivalent interruptible wait path.
   - If D-NONDET is enabled, any deadline/timeout semantics must come from explicit clock authority rather than ambient wall-clock time.
   - Phase 1 does **not** assume global timers, implicit wall clocks, or hidden scheduler timeout policy on D-WAITSET.

9) **Tags are opaque and untrusted; they never influence authorization**
   - A binding tag is caller-chosen correlation data returned back to that caller.
   - Tags MUST be treated as opaque/untrusted bytes or scalars; authorization derives only from the bound handle, requested mask, and object state.
   - This keeps tags useful for runtimes without turning them into policy selectors or authority tokens (PO-WAITSET-NOAMP).

10) **Bounded, attributable, and deterministic under pressure**
    - Binding counts, ready-state bookkeeping, and returned batch sizes MUST be bounded and attributable when D-METER is enabled (I-WAITSET-2; PO-WAITSET-BOUND).
    - Overflow/backpressure is explicit and deterministic rather than silent drop or unbounded queue growth.
    - Readiness storms SHOULD surface as pressure/diagnostic signals rather than hiding inside an ever-growing kernel event queue.

11) **No programmable filters, side payload interpreters, or hidden scheduler policy in v0**
    - Phase 1 declines kqueue-class rich filter programming, kernel-side payload transforms, and policy knobs that steer scheduling/fairness via WaitSet semantics.
    - D-WAITSET v0 is therefore a small observation and batching seam, not a general event-processing VM.
    - Ordering/fairness beyond the documented bounded batch contract remains implementation-defined and must not be smuggled in as a product guarantee.

12) **No new workflow / ACP / conflict-key surface in v0**
    - D-WAITSET v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
    - Therefore **no new conflict-key family is introduced in v0**.
    - Any future admin/export surface (for example, shared wait brokers, packet injection, or filter policy knobs) must land RFC-first with its own serialization boundary, commutativity story, receipts, and policy kill switches.

13) **Sealed compat remains killable and non-ambient**
    - Foreign Cells MAY use an internal host/runtime epoll/kqueue/IOCP/port shim behind the membrane, but Phase 1 does **not** standardize a compat-visible wait FD/path/env bridge, ambient event broker, or hidden packet queue.
    - Any compat enablement remains policy-killable and must not recreate ambient observation or cross-domain wake channels that bypass D-FCELL posture.

## Phase 1 non-goals (explicitly deferred)

- Edge-triggered / one-shot / auto-rearm semantics on the portable default seam.
- Payload-bearing event packets or user-injected packet queues on D-WAITSET itself.
- Programmable filters / kernel event VMs.
- Ambient namespace/path/fd registration or remote wait-broker semantics.
- New workflow / ACP / admin surfaces around WaitSets.

## Wiring

- Decision surface: `decision-map.md` (D-WAITSET).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (wait-set seam)
  - `rfcs/0106-wait-sets-and-object-signals.md` (option space / evidence seed)
  - `rfcs/0107-io-submission-queues-and-completions.md` (payloads remain on explicit dequeue surfaces)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-WAITSET-1, I-WAITSET-2, I-WAITSET-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-WAITSET-BOUND, PO-WAITSET-NOAMP)
  - `docs/30-architecture/nondet-posture-v0.md` (explicit time/timeout posture)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_waitset_posture.py` fails `make lint` if this posture stops being discoverable, loses the observational / level-triggered / no-packet-queue posture, or drops its primary REF wiring.

## References

- REF-ZIRCON-SIGNALS.
- REF-ZIRCON-OBJECT-WAIT-MANY.
- REF-ZIRCON-OBJECT-WAIT-ASYNC.
- REF-ZIRCON-PORT-WAIT.
- REF-LINUX-EPOLL.
- REF-BSD-KQUEUE.
- REF-WIN-IOCP.
- REF-WIN-POSTQUEUEDCOMPLETIONSTATUS.
