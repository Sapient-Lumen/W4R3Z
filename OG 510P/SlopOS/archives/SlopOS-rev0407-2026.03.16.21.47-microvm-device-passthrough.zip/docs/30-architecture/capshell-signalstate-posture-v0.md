# Capshell launch signal-state posture v0 (no inherited signal mask / trap baseline)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools whose behavior depends on inherited
**signal state**: blocked signals, ignored dispositions, or shell trap state carried across the
runner/wrapper boundary. The archive already says execution context is explicit and reviewable, but
that promise still drifts if the child launch quietly inherits parent/login-shell/session signal
mask and ignored-signal posture that never appears in the reviewed execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic signal
broker, a portable `kill` API, a jobspec surface, or a reviewed per-step descriptor for arbitrary
signal policy. It only freezes the minimum Phase 1 posture needed so launch behavior stops
depending on hidden shell/session signal state across all four product shapes.

## Posture (v0)

1) **No inherited shell/session signal-mask baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit blocked-signal state merely because the parent shell,
     wrapper, login profile, or host session already had signals masked.
   - Signal masks are per-thread/process launch context; carrying them across the reviewed boundary
     would make execution depend on hidden parent state rather than reviewed artifacts.

2) **No inherited shell/session ignored-signal / trap baseline**
   - `capshell.exec` MUST NOT preserve ignored-signal or shell-trap posture merely because the
     launcher/session already installed it.
   - Shell trap/ignore state is ambient launch context unless the archive makes an explicit reviewed
     surface for it.

3) **Phase 1 adds no reviewed per-step signal-state surface**
   - Phase 1 introduces no reviewed signal-mask descriptor, no per-step signal-disposition schema,
     and no `capshell.signal.*` ACP/admin family.
   - The portable seam is therefore: **do not carry launcher/session signal state across the
     reviewed boundary**.
   - If a runtime/provider needs local signal policy for supervision or host integration, that
     remains implementation detail and MUST be independent of parent shell/session state.

4) **Launch normalizes signal state at the boundary**
   - Before `exec` (or via equivalent spawn attributes), the runner/wrapper MUST start the child
     with an **empty blocked-signal mask**.
   - Before `exec` (or via equivalent spawn attributes), the runner/wrapper MUST restore
     **default dispositions for catchable signals** rather than preserving inherited ignored/trap
     state from the parent shell/session.
   - Compat/foreign-cell membranes that cannot guarantee that normalized launch posture MUST fail
     closed rather than preserving host defaults.

5) **Programs may still manage their own signal policy after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen shell/interpreter/program after it begins running.
   - If an explicitly selected tool later installs handlers, blocks signals, or ignores `SIGPIPE`,
     that behavior belongs to the chosen program/runtime rather than to ambient launch state.

6) **Other explicit seams do not secretly mint or repair signal state**
   - **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and **CH-REQCTX v1** do not
     authorize synthesizing or translating parent shell/session signal state into the child.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt UX) MUST NOT become hidden carriers for blocked-signal or trap inheritance.

7) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable signal policy descriptor, no admin query surface for “which
     signals were inherited?”, and no shell-facing workflow knob for step-local mask/disposition
     overrides.
   - If later evidence shows real need for reviewed launch-time signal policy, that work must
     return as **one new explicit decision surface** rather than by silently inheriting shell state.

8) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden parent/session
     blocked-signal or trap state.

9) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose inherited parent shell/session signal mask or ignored-signal
     state as a hidden side channel around the reviewed execution pack.
   - If a foreign runtime cannot bypass launcher/session signal inheritance or cannot normalize the
     child to empty-mask/default-disposition launch posture, it MUST fail closed.

## Phase 1 non-goals (explicitly deferred)

- No portable signal-mask/disposition schema in Phase 1.
- No portable signal-send / jobspec / job-control plane on D-CAPSHELL.
- No attempt to standardize host supervision signal policy or local service-manager conventions.
- No query/report surface exposing inherited parent signal state.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-interrupt-cancel-posture-v0.md`
  - `capshell-job-control-posture-v0.md`
  - `capshell-umask-posture-v0.md`
  - `capshell-rlimit-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-SIGSTATE-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-SIGSTATE-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_signalstate_posture.py` (**EVID-2026-331**).

## References

- REF-OPENGROUP-EXEC
- REF-MAN7-SIGPROCMASK
- REF-MAN7-SIGACTION
- REF-MAN7-POSIX-SPAWN
