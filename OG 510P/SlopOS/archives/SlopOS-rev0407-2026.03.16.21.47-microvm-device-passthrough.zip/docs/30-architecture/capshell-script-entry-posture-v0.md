# Capshell script-entry posture v0 (explicit interpreter binding; no shebang/env lookup)

Purpose: keep **D-CAPSHELL** honest when workflows execute script-like artifacts.
Phase 1 already pins executable selection to one explicit CH-ARGV `role="exec"` selector and
forbids ambient PATH lookup. This adjunct closes the remaining gap: **script headers and
ENOEXEC-style fallbacks must not smuggle interpreter discovery back in through a second path**.

This doc is intentionally narrow. It does **not** invent a new script package format, a new
interpreter registry, or a generic shebang policy engine. It only pins how `capshell.exec` treats
script/text entry so automation stays explicit, reviewable, and fail-closed across all four product
shapes.

## Posture (v0)

1) **Interpreter selection remains the one explicit exec selector**
   - If a workflow runs a script/text artifact, the interpreter itself MUST be the **only** CH-ARGV
     `desc` token with `role="exec"`.
   - The script artifact is a separate explicit input (for example, a CH-ARGV `desc` token with
     `role="arg"` or an explicit CH-FDSET/CH-STDIO binding), bound against already-held authority.
   - The runner MUST NOT infer the interpreter from script bytes, filename suffixes, or host file
     associations.

2) **Shebangs are non-authoritative metadata in capshell**
   - A leading `#!...` line MAY exist inside a script artifact, but `capshell.exec` treats it as
     observational metadata only in Phase 1.
   - The runner MUST NOT select or rewrite the executable based on the shebang line.
   - `#!/usr/bin/env ...` MUST NOT trigger PATH search, utility discovery, or a second interpreter
     selection pass inside the runner.

3) **No ENOEXEC / shell fallback path**
   - If the bound `role="exec"` artifact is not directly executable under the active runner profile,
     execution MUST fail closed and be transcript-visible.
   - The runner MUST NOT silently retry with `sh`, `env`, a profile default shell, or any other
     command interpreter.
   - Literal argv tokens remain data only; they do not authorize a hidden `sh -c` / `env tool`
     fallback path.

4) **Explicit interpreters remain allowed**
   - A workflow MAY explicitly choose a shell or language runtime as the `role="exec"` selector,
     then pass a script descriptor as a separate argument/input.
   - Any PATH/env/loader semantics performed by that explicitly chosen interpreter are then part of
     that component's own behavior under its already-declared execution context; the capshell runner
     itself adds no ambient lookup.
   - Profiles MAY further narrow such interpreters, but D-CAPSHELL v0 does not create a special
     allowlist/denylist surface here.
   - Companion quarantined code-input boundary: if a separately bound object is supplying code to the
     chosen interpreter/runtime, quarantine still gates execution even when the runtime accepts that
     code through `stdin`, `-c`, `--eval`, module/archive entry, or another non-`argv[0]` form
     (`quarantined-code-input-boundary-v0.md`).

5) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no `capshell.script.*` ACP kind, no shebang registry schema, no runner-side
     “trusted interpreter database”, and no generic query API for script-entry policy.
   - If a future product wants portable shebang admission or descriptor-bound interpreter aliases,
     it must return as a separate RFC/decision surface rather than widening CH-ARGV or
     `capshell.exec` by implication.

6) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered within
     a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that ambiguous script-entry paths reject deterministically instead of
     widening executable resolution semantics.

7) **Sealed compat remains killable and non-ambient**
   - Foreign-cell or wrapper-based automation may support script launch only through explicit
     interpreter binding across the membrane.
   - Compat shims MUST NOT recreate ambient script execution by consulting host PATH, host file
     associations, or injected `/usr/bin/env` wrappers behind the membrane.

## Phase 1 non-goals (explicitly deferred)

- No portable shebang registry or interpreter-alias schema.
- No filename-suffix-based interpreter selection.
- No automatic `#!/usr/bin/env` portability layer inside the capshell runner.
- No fallback-to-shell behavior on `ENOEXEC` or equivalent runner errors.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Existing assurance anchors (no new invariant/proof family):
  - `I-ARGV-3` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-ARGV-BIND` in `docs/20-assurance/proof-obligation-registry.md`
- Composition seams:
  - `docs/30-architecture/capshell-exec-selector-posture-v0.md`
  - `docs/30-architecture/argv-schema-v0.md`
  - `docs/30-architecture/capshell-exec-pack-schema-v2.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_script_entry_posture.py` (**EVID-2026-320**).

## References

- REF-OPENGROUP-EXEC
- REF-OPENGROUP-ENV
- REF-LINUX-BINFMT-MISC
- REF-CAPSICUM
