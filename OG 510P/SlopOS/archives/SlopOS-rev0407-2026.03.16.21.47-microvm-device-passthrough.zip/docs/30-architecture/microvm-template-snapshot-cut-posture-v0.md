# MicroVM template snapshot-cut posture v0 (reusable snapshots are secret-clean and authority-cold)

Purpose: pin the **Phase 1** cut discipline for **reusable** `ext.microvm` snapshots so warm-start fan-out does not quietly duplicate secrets or live imported authority.

This doc attaches to **D-MICROVM**, **D-EPHEM**, **D-ATTEST**, **D-APPSECRET**, **D-VAULT**, **D-CAPRPC**, **D-LEASE**, and **D-NETLEASE** and makes one hard decision explicit:
**a reusable template snapshot is cut before secret ingress and live imported authority; post-secret/post-session snapshots are recovery artifacts, not fan-out templates.**

## Posture (v0)

1) **Reusable templates are a distinct snapshot class**
   - A **reusable template snapshot** is any snapshot intended to seed a warm pool, resume more than once, or act as a base artifact for later clone/fan-out.
   - That class is distinct from an owner-local crash/recovery checkpoint for one already-running instance.
   - Phase 1 keeps the portable microVM fast-start story on the reusable-template class only.
   - Artifact semantics for that reusable class are pinned separately in `microvm-template-lineage-posture-v0.md`: the fan-out input is a parent-bound, leaf-resumable template, while any diff/base layering stays implementation-local.

2) **Reusable template cut happens before secret ingress and live imported authority**
   - A reusable template snapshot MUST be taken **before** the guest has admitted any state whose validity or secrecy depends on being a unique current instance.
   - In particular, the reusable template cut MUST happen before:
     - freshness-bound attestation exports/challenges/sessions,
     - attestation-gated secret-release bytes or other unsealed secret material already delivered into guest memory,
     - live **D-CAPRPC** sessions/imports,
     - issued **D-NETLEASE** / **D-LEASE** handles or equivalent current-session remote authority,
     - per-instance unique ids/secrets/nonces/tokens intended for later external use.
   - What *may* be inside a reusable template is narrower: booted runtime state, validated read-only artifacts, JIT/compiler caches, immutable lookup tables, and other non-authority-bearing warm data.

3) **Restore reacquires hot/live state explicitly after generation repair**
   - After restoring a reusable template, guest/user-space first observes the primary generation witness from `microvm-generation-witness-posture-v0.md`, repairs uniqueness, and only then reacquires live external state through existing explicit seams.
   - That reacquisition includes fresh attestation exchange, fresh secret release, fresh network/lease issuance, and fresh live session bootstrap where needed.
   - Copied memory bytes alone are never evidence that previously admitted live authority remains valid.

4) **Post-secret or post-session snapshots are not fan-out templates**
   - If an implementation needs checkpoints after secret ingress or after live sessions/leases exist, those snapshots stay **owner-local, policy-bound recovery artifacts** for that instance lineage.
   - Phase 1 MUST NOT advertise or treat such artifacts as reusable warm-pool templates, scale-out bases, or ordinary clone inputs whose secrecy/uniqueness properties survived intact.
   - Any later export/import/distribution story for such checkpoints must pay its own design/evidence cost rather than inheriting legitimacy from “snapshot support exists”; Phase 1 now fixes the default boundary as **owner-local only** for warm-state artifacts rather than a portable/public artifact class (`microvm-template-distribution-posture-v0.md`).

5) **No new portable checkpoint-hook or wipe plane is created**
   - Implementations may use runtime-specific before-checkpoint/after-restore hooks, wipe-on-suspend hints, or equivalent local techniques internally.
   - Phase 1 does **not** standardize those mechanisms as a new portable SlopOS hook API, callback plane, or guest-management protocol.
   - The portable rule is the **snapshot cut discipline** plus explicit reacquisition on restore, not a generic hook substrate.

6) **Commutativity/ordering remain explicit by omission**
   - This posture adds **no new ACP kind** and **no new conflict-key family** in Phase 1.
   - If a later management plane exposes an externally visible “prepare/freeze/cut reusable snapshot” action, it must specify conflict keys, retry semantics, serialization scope, and evidence hooks explicitly.
   - Until then, cut orchestration remains owner-local to the VMM/runtime rather than a new workflow surface.

## Phase 1 non-goals (explicitly deferred)

- No portable generic checkpoint-hook API.
- No claim that owner-local recovery checkpoints are forbidden.
- No promise that reusable templates may keep live DB/TLS/portal sessions valid across restore.
- No blanket deletion rule for provider-owned D-APPSECRET / D-VAULT references that were never unsealed into guest memory.
- No new snapshot catalog / inventory / export plane.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-ATTEST, D-APPSECRET, D-VAULT, D-CAPRPC, D-LEASE, D-NETLEASE)
- Adjacent postures:
  - `microvm-snapshot-posture-v0.md`
  - `microvm-generation-witness-posture-v0.md`
  - `microvm-attestation-reacquire-posture-v0.md`
  - `microvm-template-lineage-posture-v0.md`
  - `app-secret-posture-v0.md`
  - `vault-posture-v0.md`
  - `caprpc-session-posture-v0.md`
  - `capability-lease-posture-v0.md`
  - `network-lease-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-TEMPLATE-CUT)
- Policy posture:
  - reusable template snapshots add **no new lane**, **no new host↔guest callback exemption**, and **no new portable checkpoint-hook surface** in Phase 1.

CI drift gate:
- `tools/check_microvm_template_snapshot_cut_posture.py` fails `make lint` if this posture stops being discoverable, loses its **reusable templates are secret-clean + authority-cold / reacquire after generation repair / post-secret checkpoints are not fan-out templates / no new hook plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-FIRECRACKER-ENTROPY-CLONES.
- REF-BROOKER-UNIQUENESS.
- REF-AWS-SNAPSTART-UNIQUENESS.
- REF-AWS-SNAPSTART-RUNTIME-HOOKS.
