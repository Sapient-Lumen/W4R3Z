# Capability rights registry (v0, conceptual)

Purpose: make **capability classes + rights bits** explicit and reviewable so that:
- authority can be attenuated mechanically (derive/restrict),
- “dangerous” effects (execmod, device DMA, raw I/O) have a named seam,
- UI/receipts (CH-CAPDIFF) can render stable, non-stringly rights summaries.

Non-goal: freeze a final object model. This is a *living* registry for early bring-up and for keeping RFCs consistent.

## Normative stance
- Rights are **monotone** under derivation: child capabilities can only drop rights (D-CAP).
- Privileged operations MUST check rights at the boundary (IF-KABI) and fail closed.
- Rights are *not* ambient: the only way to act is to present a capability with the required right.

## V0 object classes (seed)

### `MemObj` (frames / VMOs / backing memory objects)
Rights:
- `R` read
- `W` write
- `X` execute (bytes may be mapped executable)

Rule of thumb:
- ordinary anonymous memory is created without `X`.
- memory that backs a sealed artifact’s text segment may carry `X`.

### `VSpace` (address spaces / mapping authority)
Rights:
- `MAP_R`, `MAP_W`, `MAP_X` (permission to request corresponding page permissions)
- `PROTECT` (permission to change page permissions via a protect/mprotect-like operation)

Notes:
- A profile may split `MAP_X` from `PROTECT` so that “map executable once” is distinct from “flip RW→RX later” (D-DYNCODE).

### `VmExec` (exec-authority / vmex-style issuer)
Purpose: a *separate* capability that gates creating or upgrading `MemObj` handles with `X`.
Rights:
- `ISSUE_X` (may mint/upgrade a `MemObj` handle to include `X`)

This follows a “two-key” pattern:
1) to create an executable mapping you need a `VSpace` right to request `X`, and
2) the backing `MemObj` must itself carry `X`.

If a component lacks `VmExec`, it cannot manufacture new `X`-carrying `MemObj`s even if it can allocate/write data memory.

## Exec mapping and execmod gating (D-DYNCODE)
Baseline (recommended):
- W^X holds (I-WX-1): no mapping is both writable and executable.
- Execmod is explicit (I-EXECMOD-1): RW→RX transitions or executable mappings of *non-sealed bytes* require explicit exec-authority.

Concrete check (v0 candidate):
- `mem.map(... perm=X ...)` requires `VSpace.MAP_X` **and** `MemObj.X`.
- `mem.protect(... W→X ...)` requires `VSpace.PROTECT` **and** `VmExec.ISSUE_X` (or a narrower `EXECMOD` right if we split it later).

Sealed-code-space profile:
- Sealed artifacts provide `MemObj.X` for their text pages.
- Components without `VmExec` can map those pages executable, but cannot create new executable pages at runtime.


### `BootSel` / `BootCommit` (boot selection + commit)
Rights:
- `read_state`: read selector state (CH-BOOTSEL)
- `set_pending`: activate a pending deployment with bounded tries
- `commit_success`: mark the current pending deployment successful (requires D-HEALTH binding if enabled)

Notes:
- In a minimal design, the updater holds `set_pending`, while only a small health assessor holds `commit_success`.

### `ReadyToken` (one-shot readiness handshake)
Rights:
- `signal`: signal readiness exactly once (token consumed)

Notes:
- Used to make “components_ready” checks non-ambient and spoof-resistant (RFC-0074).
## Rendering rights in CH-CAPDIFF
When emitting `rights` strings in CH-CAPDIFF, prefer reduced vocab derived from this registry (e.g., `"read"`, `"write"`, `"execute"`, `"execmod"`).

## References
- REF-FUCHSIA-VMAR-MAP (execute mapping requires rights on both region + backing object)
- REF-FUCHSIA-VMO-EXEC (adding execute right requires a distinct exec-authority handle)
- REF-SINGULARITY (sealed code spaces as a no-dynamic-code baseline)
