# Capshell result sidecar boundary v0 (keep replay stable)

Purpose: resolve **OQ-0007** by freezing what counts as the stable replay/result seam for `capshell.exec` and pre-committing where any richer result structure may live.

This is intentionally a **boundary** doc, not a new schema. It keeps retry safety small and machine-checkable while still leaving room for future named-output or telemetry work *outside* the replay-critical core.

Adjunct to:
- `capshell-output-normal-form-v0.md`
- `acp-outcome-receipt-schema-v0.md`
- D-CAPSHELL / D-RETRYSAFE (`decision-map.md`)

Research imports (translated into our artifacts, not copied):
- Bazel Remote Execution API (REAPI) keeps output requests/result material explicit and sorted/deduplicated, with output trees returned by digest-backed typed fields rather than ambient filesystem discovery (REF-REAPI-PROTO).
- OCI descriptors keep type metadata in a separate descriptor object bound to a digest rather than overloading the digest itself (REF-OCI-DESCRIPTOR).
- OpenTelemetry process metrics are a separate telemetry vocabulary, not part of authorization or result identity (REF-OTEL-PROCESS-METRICS).

## v0 boundary (hard decision)

1) **The canonical replay result stays a digest-addressed output set**
   - For `capshell.exec`, the replay-stable output contract remains the one pinned in `capshell-output-normal-form-v0.md`:
     - duplicate suppression is keyed by CH-EFFCON `contract_id`,
     - exportable outputs are referenced as `digest(CH-AREF v0)`, and
     - accepted duplicates return the same CH-AREF digests.
   - This meaning is frozen for v0/v1 replay tooling.

2) **No richer result structure is smuggled into existing core seams**
   - CH-EXECPACK v2, CH-EFFCON v0, and CH-ACPOUT v0 MUST NOT grow ad-hoc fields or `meta` conventions for:
     - named output trees,
     - resource-usage telemetry,
     - streaming-progress summaries, or
     - path-based output inventories.
   - Privileged code MUST NOT reinterpret `receipt_refs`, `outputs[]`, or free-form metadata as if they were an implicit result-tree schema.

3) **If richer result structure is needed, it lives in a separate sidecar descriptor**
   - Any future named-output / output-tree / resource-usage surface MUST be introduced as **one explicit sidecar descriptor family** via RFC + evidence, not by changing the meaning of CH-AREF digests or CH-ACPOUT `receipt_refs`.
   - That sidecar may be referenced by digest from CH-ACPOUT `receipt_refs` or rebound behind a returned CH-AREF, but it does not get to retroactively redefine the core replay contract.

4) **Named outputs stay labels, not ambient reopen selectors**
   - If a future sidecar introduces names, those names are descriptor-local bounded labels bound to CH-AREF digests.
   - They MUST NOT become host paths, cwd-relative reopen selectors, implicit mount points, or capability lookup keys.
   - Any reopen/fetch still goes through the explicit artifact/portal lane bound to the referenced CH-AREF.

5) **Telemetry sidecars are observational only**
   - Any future execution telemetry (CPU time, memory, IO counts, queue delay, etc.) is **non-authoritative**.
   - It MUST NOT affect duplicate suppression identity, authorization, cache hits, or the meaning of “already done.”
   - Telemetry may help scheduling, UX, or diagnosis, but replay correctness remains anchored to CH-EFFCON `contract_id` + CH-AREF output identity.

## Why this boundary exists

- **Keeps replay safety crisp**: dedupe/cache semantics stay small enough to test and explain.
- **Prevents path drift**: named outputs cannot quietly turn back into ambient filesystem semantics.
- **Separates result identity from observability**: output correctness and performance reporting evolve independently.
- **Preserves future freedom without forked meaning**: if we later need richer result descriptions, we can add them explicitly without corrupting old receipts.

## Consequences

- Existing `capshell.exec` replay semantics remain valid and easy to lint.
- CH-ACPOUT `receipt_refs` stays a digest-only envelope, not an implicit result schema.
- Any future richer result work must pay for itself with one new schema/decision surface and its own proof obligations.

## Wiring

- Open-question history: `docs/00-meta/trajectory-map.md` (OQ-0007 resolved here)
- Replay contract: `capshell-output-normal-form-v0.md`
- Outcome envelope: `acp-outcome-receipt-schema-v0.md`
- Core decision surface: `decision-map.md` (D-CAPSHELL / D-RETRYSAFE)
- CI drift gate: `tools/check_capshell_result_sidecar_boundary.py` (EVID-2026-256)

## References

- REF-REAPI-PROTO
- REF-OCI-DESCRIPTOR
- REF-OTEL-PROCESS-METRICS
