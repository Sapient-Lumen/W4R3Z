# D-NAMECERT revocation boundary v0 (explicit evaluator input; no ambient chase or auto-detach)

Purpose: narrow the **revocation / withdrawal** meaning of **D-NAMECERT** so issuer regret, negative evidence,
or replacement bundles do not quietly turn into an ambient CRL/OCSP dependency, a hidden global “latest wins”
resolver, or an automatic live-namespace mutation plane.

This doc attaches to the existing **D-NAMECERT / D-NS / D-COMMUTE / D-REPL** seams rather than inventing a new
one. It resolves one practical Phase 1 question: **when local naming policy learns that a previously acceptable
bundle should no longer be trusted, does that create ambient revocation authority over live bindings, or merely a
new admission outcome for future explicit materialization?**

## Boundary (v0)

1) **Revocation evidence is explicit evaluator input, not an ambient service**
   - If a deployment wants revocation / withdrawal behavior for local names, the evaluator MAY consume **explicit local negative evidence** such as a denylist, explicit replacement map, monotonic epoch side input, or another already-authorized artifact flow.
   - That negative evidence is chosen by **local policy** and evaluated in user space alongside the explicit CH-NAMECERT bundle set.
   - Phase 1 therefore declines any ambient CRL/OCSP lookup, implicit trust-store callback, background “check if still valid” daemon, or privileged-core revocation service on D-NAMECERT. In other words: **no ambient CRL/OCSP**.

2) **Phase 1 standardizes no portable revocation/discovery artifact on D-NAMECERT itself**
   - **CH-NAMECERT v0** does not grow serial numbers, CRL distribution points, OCSP responders, or “latest bundle wins” semantics.
   - Phase 1 also introduces **no new portable revocation/status schema**, no app-visible revocation watch API, and no separate ACP/admin plane for naming withdrawal.
   - If we later need portable revocation artifacts or distributed status proofs, that must land as a separate RFC-first seam rather than by silently widening CH-NAMECERT in place.

3) **Revocation changes future admissions, not live bindings**
   - Learning new local negative evidence MAY cause **future** CH-NAMECERT evaluations to deny an attempted explicit materialization fail closed.
   - It MUST NOT silently rewrite the active view, auto-run `view.detach`, mutate source `digest(CH-NAMECERT v0)` receipts, or invalidate earlier accepted target-seam actions merely because the evaluator now knows more.
   - Revocation therefore behaves like a new local admission result, not like a background command against already-materialized namespace state.

4) **Explicit later removal stays on the target seam**
   - If an operator or service wants a live binding removed because of later revocation evidence, that removal remains an explicit target-seam mutation such as **`view.detach`** on the affected **`view.slot`**.
   - The same `view.slot` conflict keys, `svc:view` serialization boundary, and target-seam receipts apply.
   - D-NAMECERT itself adds no new conflict-key family, no negative-authority ordering stream, and no “issuer withdrawal” side channel that bypasses the reviewed D-NS mutation path.

5) **Arrival order and replacement bundles do not imply winner selection**
   - A newer bundle, a replicated bundle arrival, or a locally maintained deny entry MUST NOT by itself imply “replace the active binding now”.
   - Phase 1 declines “latest bundle wins”, “most recent revocation notice wins”, or “cluster majority revocation” semantics on D-NAMECERT.
   - Which bundle set is admissible remains an explicit local evaluation question; changing live namespace state still requires an explicit target-seam action.

6) **Replication and audit remain evidence-only**
   - Cross-cluster `object_family = namecert` replication remains **signed bundle-set evidence only** as pinned by `namecert-replication-boundary-v0.md`.
   - A deployment MAY distribute local deny/replacement inputs through some other already-authorized artifact channel, but Phase 1 defines no privileged/global revocation replication plane for D-NAMECERT.
   - Audit/receipt surfaces may record that an attempted admission was denied because of local negative evidence, but that does not create portable revoke authority over peers.

7) **Short lifetimes / explicit leases stay separate tools**
   - Deployments that need rapid withdrawal SHOULD prefer explicit short validity windows (`namecert-time-boundary-v0.md`), explicit later `view.detach`, or an already-reviewed lease/revocation seam.
   - Phase 1 does **not** claim that D-NAMECERT alone solves global distributed revocation for already-leaked authority.
   - This keeps local naming evidence small and avoids importing a second revocation subsystem into the core seam.

8) **Sealed compat remains honest**
   - Compat shims and foreign-cell bridges MUST NOT smuggle in host-global certificate stores, OCSP/CRL agents, or automatic detach-on-revocation behavior that bypasses explicit local policy and the reviewed D-NS mutation path.
   - If compat requires revocation, it must still be killable by policy and remain explicit about where evaluation and removal happen.

## Phase 1 non-goals (explicitly deferred)

- **Ambient CRL / OCSP / trust-store lookups** for D-NAMECERT.
- **Automatic detach or receipt rewriting** when revocation evidence is learned later.
- **Portable revocation/status schemas or watch APIs** on CH-NAMECERT itself.
- **Global serial-number / issuer-status infrastructure** for local naming.
- **“Latest bundle wins” or replicated-majority winner semantics** for active local bindings.

## Wiring

- Core local naming posture: `namecert-posture-v0.md`
- Projection boundary: `namecert-projection-boundary-v0.md`
- Time/freshness boundary: `namecert-time-boundary-v0.md`
- Replication boundary: `namecert-replication-boundary-v0.md`
- Target namespace seam: `view-namespace-posture-v0.md`
- RFC: `rfcs/0023-local-naming-certificates-spki-sdsi.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (**I-NAME-2**, **I-NAME-3**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NAMECERT-CHAIN**, **PO-NAMECERT-PROJECT**)

CI drift gate:
- `tools/check_namecert_revocation_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its **explicit local negative evidence / no portable revocation artifact / no auto-detach / no latest-wins semantics** stance, or drops its assurance / REF wiring.

## References

- REF-SPKI-RFC2692.
- REF-SPKI-RFC2693.
- REF-UCAN-SPEC.
- REF-MACAROONS-NDSS14.
