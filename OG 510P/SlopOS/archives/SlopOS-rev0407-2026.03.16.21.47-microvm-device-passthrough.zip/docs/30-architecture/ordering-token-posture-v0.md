# CH-ORDERTOK / D-COMMUTE posture v0 (scope-bound ordering witness; no portable sequencer)

Purpose: pin an implementable v0 meaning for **CH-ORDERTOK** under **D-COMMUTE** so explicit ordering evidence stays a small, reviewable witness seam rather than drifting into a portable sequencing service, client self-mint protocol, hidden global stream, or second workflow/control plane.
It narrows RFC-0119 into one compact posture validators, planners, and receipts can reason about: scope-bound ordering tied to one conflict key, owner-minted witness semantics, digest-only action references, and no portable reserve-next-token API.

## Posture (v0)

1) **Ordering witness seam, not a general sequencing service**
   - If CH-ORDERTOK is used, it is an **evidence / validation seam** for actions that are already non-commutative by spec.
   - Phase 1 does **not** standardize a kernel-global sequencer, a general-purpose ordered log service, a public "reserve the next sequence number" API, or a transport for arbitrary clients to mint or negotiate portable sequence tickets.
   - Ordering authority remains where correctness-required serialization already lives: the validator or owning service boundary for the ordered action (I-ORDERTOK-1; PO-ORDERTOK-VALIDATE).

2) **Scope is exactly one conflict key stream in v0**
   - The portable stream scope is exactly **`(scope.family, scope.key_digest)`**, where `scope.key_digest = digest(CH-CONFLICTKEY v0)` for one conflict key.
   - Phase 1 therefore does **not** standardize cross-key batch streams, wildcard ordering scopes, family-spanning composite scopes, or an implicit system-global stream.
   - If a profile truly needs a global ordered stream, it must say so explicitly as profile work; global order is never inherited by accident from the existence of CH-ORDERTOK.

3) **Ordered streams are owner-routed and conflict-key-local by default**
   - Default posture is **one owner-routed ordered stream per conflict key scope**, matching the serialization owner already declared for that ordered action family.
   - Hybrid/planner/tooling may shard by conflict key family + key digest, but Phase 1 does **not** standardize client-visible leader election, migratable token issuers, or cross-cluster speculative issuance on the portable seam.
   - This keeps Hybrid + commutativity honest: order is scoped to the smallest non-commutative surface instead of collapsing into a shared global bottleneck.

4) **Tokens are owner-minted witnesses; callers do not self-mint semantics**
   - A CH-ORDERTOK descriptor is an **issuer/owner witness** that an action belongs to an ordered stream position; it is not a caller-chosen ordering claim.
   - Clients MAY carry `tok_id`/digest references through proposals and receipts, but portable correctness does **not** rely on planners or untrusted callers selecting their own `epoch` / `seqno` semantics.
   - Phase 1 therefore does **not** define client self-mint, client-side `seqno` reservation, offline range allocation, or “bring your own order witness” semantics on the portable surface.

5) **Sequence fields are evidence, not a portable arithmetic API**
   - `epoch` and `seqno` exist so validators/receipts/tests can establish stream membership and fail closed on stale or mismatched witnesses.
   - Portable consumers may compare them only under issuer-validated scope; they are **not** a general arithmetic API for planners, retry engines, or queue schedulers to synthesize missing order or infer hidden topology.
   - Phase 1 therefore declines “next-seqno prediction”, portable gap-filling promises, client-visible range grants, and cross-stream numeric comparisons.

6) **Digest-first action binding; no bearer semantics**
   - Portable action envelopes and receipts carry **`order_digest = digest(CH-ORDERTOK v0)`** rather than the full descriptor by default.
   - CH-ORDERTOK remains strictly **non-authoritative**: it must not carry bearer secrets, raw capability identifiers, or authority to perform the ordered effect without the separately authorized action.
   - Replaying a descriptor without the ordered action’s normal authorization must have no effect beyond deterministic validation failure.

7) **Expiry/reset is explicit and fail-closed, but v0 declines lease-like renewal surfaces**
   - If `expires_at` is present, ordered actions fail closed after expiry.
   - If an owner resets a stream via `epoch`, that reset is an owner-local serialization decision, not a portable promise that clients may extend or renew.
   - Phase 1 therefore declines renewal, keepalive, batch-lease, or delegated substream semantics on CH-ORDERTOK itself.

8) **No new workflow / ACP / admin surface in v0**
   - CH-ORDERTOK v0 adds **no new portal family, no new CH-ACP kind, and no new standalone admin/export API**.
   - It only tightens how already-ordered actions prove their stream membership and how receipts make that visible.
   - Therefore **no new conflict-key family is introduced in v0**; CH-ORDERTOK reuses the closed CH-CONFLICTKEY family vocabulary and existing serialization owners.

9) **Sealed compat remains killable and non-ambient**
   - Compat runtimes MAY internally use ordered logs, journals, or queue sequence numbers behind the membrane, but Phase 1 does **not** standardize a compat-visible sequence broker, fd/path/env side channel, or hidden global sequencer reachable from foreign cells.
   - Any interop that exports ordering evidence remains policy-killable and must stay digest-only/non-authoritative on the SlopOS side.

## Phase 1 non-goals (explicitly deferred)

- A portable `reserve_next()` / range-allocation / batch-ticket API.
- A kernel-global or cluster-global default ordered stream.
- Cross-key / wildcard / family-spanning stream scopes.
- Client self-minted ordering tokens or caller-defined `seqno` semantics.
- Lease/renew/keepalive semantics on CH-ORDERTOK itself.
- New workflow, ACP, or admin surfaces for ordering.

## Wiring

- Decision surface: `decision-map.md` (D-COMMUTE).
- Narrative/mechanism surfaces:
  - `commutativity-and-interface-scalability.md` (D-COMMUTE discipline)
  - `hot-action-boundaries-v0.md` (ordered hot families must state conflict key + ordering token)
  - `docs/70-llm-control/acp-action-schema-v0.md` (ordered actions bind `order_digest` + `conflict_key_digest`)
  - `rfcs/0119-ordering-streams-and-tokens.md` (option space / evidence seed)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-ORDERTOK-1, I-ORDERTOK-2, I-ORDERTOK-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-ORDERTOK-VALIDATE, PO-ACT-KINDMETA, PO-DENY-ORDER-BIND)
  - `conflict-key-family-registry.md` and `conflict-key-derivation-registry.md` (closed family vocabulary + stable scope derivation)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No new portal family / ACP kind / conflict-key family is introduced in v0; any future portable issuance/admin surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_ordering_token_posture.py` fails `make lint` if this posture stops being discoverable, loses the one-conflict-key / owner-minted / no-portable-sequencer posture, or drops its primary REF wiring.

## References

- REF-SCR-TOCS15.
- REF-KAFKA-PARTITION-ORDER.
- REF-ZK-ZXID.
- REF-FDB-VERSIONSTAMP.
