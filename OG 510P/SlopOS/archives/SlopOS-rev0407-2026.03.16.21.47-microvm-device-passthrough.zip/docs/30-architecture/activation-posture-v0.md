# D-ACTIVATE posture v0 (supervisor-owned, inbound-only continuity; no generic handle persistence)

Purpose: pin an **implementable Phase 1** meaning for D-ACTIVATE so “stable handles + handle store” stays a small,
reviewable restart-continuity seam rather than drifting into a generic descriptor inheritance/persistence subsystem.
It narrows a slippery area into one thing: **supervisor-owned public endpoints are rebound at activation, and any
optional handle-store state is a bounded continuity aid for the same component, not a general export/import or inventory channel; the handle store stays **non-inventory** in v0**.

This doc is intentionally narrow: it does **not** design live migration, checkpoint/restore, arbitrary descriptor escrow,
a generic cross-component handle broker, or a daemon-managed global fd/object store.

## Posture (v0)

1) **Stable handles are supervisor-owned inbound continuity, not service-owned rebinding**
   - If D-ACTIVATE is enabled, Phase 1 stable handles are **supervisor-owned** exported endpoints delivered at start.
   - The service gets the right to **serve on** those handles; it does not recreate or ambiently re-bind public listeners/endpoints on restart.
   - The seam is primarily for **inbound continuity** (socket-activation style), not for general outbound/session resurrection.

2) **CH-ACTSET is descriptive, bounded, and redaction-safe**
   - **CH-ACTSET v0** remains a manifest of what was delivered at activation; it is **not authority by itself**.
   - Phase 1 CH-ACTSET contains bounded labels, cap kinds, rights summaries, and origins only; it does **not** carry bearer handles, raw kernel ids, raw fds, or provider-private object paths.
   - Logging/export binds the `digest(CH-ACTSET v0)`; replay/debug tooling consumes the manifest, not hidden process inheritance.

3) **Handle store is continuity-only, not a generic persistence/export channel**
   - If the optional handle store is enabled, it remains a **private per-`cid` continuity aid** for the same component across restart.
   - Phase 1 declines any app-visible **list/search/watch/inventory API** over stored handles.
   - Retrieval happens only via the next activation path for the same `cid`; the store is **not** a general cross-component mailbox, wallet substitute, or CH-SREF or CH-SECRETREF handoff mechanism.

4) **manifest-closed and bounded by CH-COMP**
   - `activation.stable_exports` and `activation.handle_store.key_allowlist` stay **manifest-declared** and closed-world.
   - Services do not mint new public activation keys at runtime, and they do not upload unbounded arbitrary handles “just in case”.
   - Bounds (`max_items`, key sizes, metadata size) are part of the contract, not tuning folklore.

5) **Seal posture remains honest**
   - Default Phase 1 posture remains `steady_only`: handle-store `Put()` is permitted only **after seal**.
   - `phase=init_ok` is an explicit widening for narrowly declared keys, not a convenience default.
   - Handle store must not become a route around D-SEAL for stashing init-only authority and reviving it later.

6) **Activation is activation-delivered, not ambiently inherited**
   - Services discover activation handles through the explicit activation delivery path, not through ambient environment/path/process-global conventions.
   - A runtime may use host/platform inheritance internally, but the **portable SlopOS seam** is CH-COMP + CH-ACTSET + supervisor delivery.
   - Phase 1 declines a generic “inherit everything from parent process” story as a product claim.

7) **No generic restart cache or state-migration story hides here**
   - D-ACTIVATE is for *small continuity*, not arbitrary process resurrection.
   - Large mutable state belongs to explicit D-CHKPT / D-PERSIST / D-VAULT / app-level persistence seams, each with its own review path.
   - If continuity needs exceed bounded stable handles + bounded handle-store items, that is evidence for a different RFC, not a reason to silently widen D-ACTIVATE.

8) **Stop/Kill and restart ownership stay supervisor-local**
   - Stop→Kill discipline remains a supervisor lifecycle concern; the component does not self-upgrade by passing live handles directly to an untracked successor.
   - Phase 1 prefers pristine restarted instances over old/new side-by-side inheritance tricks that bypass lifecycle/resource/security reset.
   - This keeps restart continuity compatible with D-SUPV and with transcript-visible activation digests.

## Phase 1 non-goals (explicitly deferred)

- **No generic descriptor/object escrow broker** beyond per-`cid`, allowlisted continuity.
- **No app-visible handle-store inventory/search/watch API**.
- **No cross-component export/import semantics** for stored handles.
- **No claim that activation replaces D-CHKPT / D-PERSIST / D-CAPX / D-WALLET**.
- **No ambient parent-process inheritance story** as the portable contract.

## Wiring

- Decision surface: `decision-map.md` (D-ACTIVATE).
- Schemas:
  - `activation-set-schema-v0.md` (CH-ACTSET v0)
  - `component-manifest-schema-v0.md` (CH-COMP activation fields)
- Adjacent seams:
  - `seal-posture-v0.md` (D-SEAL phase honesty)
  - `volition-posture-v0.md` (contrast: local evidence, not reusable activation state)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-ACTIVATE-1, I-ACTIVATE-2, I-ACTIVATE-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-ACTIVATE-HANDOFF, PO-ACTIVATE-CONTINUITY)

CI drift gate:
- `tools/check_activation_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **supervisor-owned / inbound-only / continuity-only / no inventory** constraints, or drops its primary REF wiring.

## References

- REF-SYSTEMD-SOCKET-ACTIVATION.
- REF-SYSTEMD-FDSTORE.
- REF-LAUNCHD-ACTIVATE-SOCKET.
- REF-FUCHSIA-RUNNER-STOP.
