# CH-CONTRACT v0: Channel contract spec (protocol FSM)

Purpose: represent a protocol contract as a small **finite-state machine** over message kinds, enabling:
- generated wrappers to fail closed on illegal transitions, and
- fast model checking over bounded automata.

References: REF-SING-CHANCONTRACTS, REF-SING-MSGCOMM.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-CONTRACT v0 := {
  v: 0,
  name: tstr,                       ; human-readable

  ; message kinds are symbolic; payload schemas are separate CH-* specs
  msg_kinds: [ + tstr ],            ; closed set for this contract

  states: [ + tstr ],
  start_state: tstr,

  ; each transition is a labeled edge: (state, dir, kind) -> state'
  transitions: [
    + {
      from: tstr,
      dir: tstr,                    ; "send" | "recv"
      kind: tstr,                   ; member of msg_kinds
      to: tstr,

      ; optional linearity/ownership transfers (profile-defined)
      transfers?: [
        + {
          what: tstr,               ; "endpoint" | "buffer" | "handle"
          id?: tstr,                ; symbolic name (contract-local)
          mode: tstr,               ; "move" | "borrow" | "share"
        }
      ]
    }
  ],

  terminal_states?: [* tstr],

  meta?: { * tstr => any }          ; optional; ignored unless allowlisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0`, `start_state ∈ states`, and all referenced `from/to ∈ states`.
2) `dir ∈ {"send","recv"}` and `kind ∈ msg_kinds`.
3) determinism: no duplicate edges for the same `(from, dir, kind)` tuple.
4) `terminal_states ⊆ states` if present.
5) `meta` keys ignored unless allowlisted.

## Notes
- Payload schemas (message payload CH schema documents) are orthogonal; contracts constrain **order**, not encoding.
- Wrappers should attach a contract id/digest to endpoints so logs can attribute failures.
