# CH-DERIV v0: Build derivation record (schema)

Purpose: record a **build recipe + full input/output digests** as a compact, canonical object that can be:
- referenced as evidence (EVID artifacts can point at CH-DERIV documents),
- embedded/linked from CH-PROV provenance attestations,
- compared across releases (“what changed?”) without trusting mutable state.

Non-goal: define a complete build language or reproduce Nix/Guix wholesale. CH-DERIV is a *record* and a seam.

References: REF-NIXOS-JFP10, REF-NIX-HOWNIX, REF-GUIX-FPM13, REF-REPRODUCIBLE-BUILDS.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-DERIV v0 := {
  v: 0,

  ; human/audit hints
  name?: tstr,                  ; e.g. "kernel" | "init" | "netstack"
  purpose?: tstr,               ; e.g. "release-binary" | "test-binary" | "doc"

  ; builder identity / environment (best-effort)
  builder: {
    tool: tstr,                 ; e.g. "cargo" | "make" | "bazel"
    tool_digest?: bstr,         ; digest of the builder binary/source closure if available
    platform?: tstr,            ; e.g. "x86_64-linux" | "aarch64-darwin"
    env_digest?: bstr,          ; digest of declared build env (optional)
  },

  ; declared inputs (prefer digests; locators are hints)
  inputs: [ CH-AREF ],

  ; build command (optional but useful for audit)
  cmd?: {
    argv: [ tstr ],             ; argv[0] is the tool or wrapper
    workdir?: tstr,
    env_allowlist?: [ tstr ],   ; names only; values not required
  },

  ; sandbox posture (audit hint; not trusted unless bound by external evidence)
  sandbox?: {
    network: bool,              ; true if network was allowed
    mounts?: [ tstr ],          ; human hints only
  },

  ; declared outputs
  outputs: [ CH-AREF ],

  meta?: { * tstr => any }      ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimal)
- `v` MUST be 0.
- `inputs` and `outputs` MUST be non-empty.
- Each CH-AREF in `inputs/outputs` MUST include a digest and digest_alg.
- `cmd.argv` SHOULD be bounded in length by policy (to avoid log abuse).

## Notes
- CH-DERIV is **not** a trust root. It becomes meaningful when:
  - its `tool_digest` is pinned in CH-PROV or a transparency log, and/or
  - CI records reproducibility checks as evidence artifacts.
