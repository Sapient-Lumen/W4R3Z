# D-CAPX / D-PLUMB import-to-docref fresh-identity boundary v0 (no `reuse_existing`; no same-bytes alias laundering)

Purpose: pin the **next exact rule** on top of the import-to-docref bridge so “materialize a fresh local object” does not quietly collapse into **reuse an existing document object/docref because the bytes look the same**.
That collapse would reintroduce amnesia and trust laundering: quarantine/origin state is object-local, while equal bytes are not proof of equal workflow meaning.
**When CH-SREF / CH-CAPX restore/import materializes document-like content for routine document workflows, Phase 1 must mint a fresh local document object identity for that import event, even when the imported bytes match an existing local object or an existing document-store entry.**

This keeps the seams honest:
- D-CAPX / CH-SREF still owns bearer restore/import,
- CH-DOCREF still names a provider-local document object rather than “whatever local object already has these bytes”,
- D-QUAR still classifies imported document-like content per object/event rather than by content-equality folklore,
- and document-store/storage dedupe can remain an internal optimization only when it does **not** collapse object identity, origin metadata, or trust state.

## Posture (v0)

1) **Import/materialize mints a fresh local document object identity for the import event**
   - When CH-SREF / CH-CAPX restore/import is bridged into routine document workflows, the provider MUST allocate a **fresh local document object identity** for that import event before minting a CH-DOCREF.
   - The bridge MUST NOT satisfy the request by returning an existing CH-DOCREF or by aliasing an already-present local object merely because content bytes, a stable remote locator, or prior import history match.
   - Equal bytes therefore do **not** imply equal document identity, equal quarantine/origin state, or permission to skip the import-to-docref bridge.

2) **No `reuse_existing` / `as-needed` semantics on the bearer→docref bridge**
   - If the underlying document store/import provider offers XDG-style `reuse_existing` / `as-needed` behavior, those options are **disabled on this boundary**.
   - Phase 1 therefore declines “this file is already here, so just hand back the old docref” semantics for CH-SREF / CH-CAPX driven import.
   - The portable bridge is fresh-identity-first, not cache-hit-first.

3) **Origin/quarantine classification stays object-local, not content-addressed trust**
   - The newly materialized object records origin/quarantine attributes for **this import event** and is **quarantined by default** under the existing D-QUAR posture.
   - An existing trusted/cleared object with identical bytes remains a distinct object with its own metadata and history.
   - “We have seen these bytes before” is not a quarantine-clear argument and not a reason to inherit another object’s classification.

4) **Storage-level byte dedupe is allowed only below the object boundary**
   - Implementations MAY deduplicate immutable byte payloads below the document/object metadata layer.
   - If they do, each imported document object must still keep distinct object identity, distinct origin/quarantine metadata, and distinct transcript-visible create/import events.
   - Any implementation that cannot preserve **fresh object identity above shared bytes** fails closed for this seam.

5) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - Independent imports commute with respect to requester authority and imported-object creation, even when their byte payloads are equal.
   - Non-commutative behavior stays where it already lives: explicit destination mutation, explicit later publish/replace, or explicit remote gateway actions.

6) **Sealed compat remains killable and non-ambient**
   - Foreign Cell / compat runtimes may bridge bearer import into routine document workflows only through explicit, policy-killable adapters that preserve **fresh object identity + quarantine-first** semantics.
   - Compat must not reinterpret equal bytes as permission to surface a pre-existing trusted local file/docref.
   - If an interop path cannot preserve this boundary, it fails closed for document workflows.

## Phase 1 non-goals (explicitly deferred)

- **No content-equality collapse** from imported bearer material onto an existing CH-DOCREF or existing local document object.
- **No `reuse_existing` / `as-needed` cache hit** that skips fresh-object minting for CH-SREF / CH-CAPX driven import.
- **No automatic trust inheritance** from an already-cleared local object that happens to have identical bytes.
- **No portable promise that repeated imports of equal bytes yield the same document identity**.
- **No new content-digest inventory/search/watch API** for discovering “matching local files” during import.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-CAPX, D-PLUMB, D-QUAR)
- Related posture / schema surfaces:
  - `import-to-docref-boundary-v0.md`
  - `capx-posture-v0.md`
  - `sturdyref-posture-v0.md`
  - `document-portal-posture-v0.md`
  - `open-untrusted-posture-v0.md`
  - `quarantine-posture-v0.md`
  - `document-handle-schema-v0.md`
  - `origin-quarantine-attrset.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-DOCREF-1, I-QUAR-1, I-QUAR-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-DOCREF-REOPEN, PO-QUAR-PROP, PO-QUAR-LOCAL)
- RFC / engineering history:
  - `rfcs/0004-networked-capabilities-and-delegation-tokens.md`
  - `rfcs/0014-sturdyrefs-and-capability-uris.md`
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_import_to_docref_fresh_identity_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **fresh-object-identity / no `reuse_existing` / quarantine-is-object-local / storage-dedupe-below-object-only** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-DOCUMENTS.
- REF-MOTW-ZONEID.
