# D-PLUMB / D-QUAR safe-open export lineage boundary v0 (explicit parent digest; no hidden identity continuity)

Purpose: pin the **minimum lineage hook** for output that leaves `intent.kind=open_untrusted` so safe-open does not trade one laundering bug for a quieter amnesia bug.
It narrows the next ambiguity after **new-artifact**, **quarantined-by-default**, and **fresh-destination-first**: once safe-open output becomes a distinct artifact, **what exact evidence ties that artifact back to the risky source object it came from?**
Phase 1 answers: ordinary keep/export from safe-open records the immediate parent object explicitly as **`origin.parent_digest`**, and any fuller provenance chain remains evidence layered on top rather than hidden identity continuity.

This keeps D-QUAR and D-PLUMB honest: the kept result is still a **new artifact** with fresh identity and no inherited durable grants, but it is also not allowed to appear as if it came from nowhere.

## Posture (v0)

1) **Ordinary safe-open keep/export records one exact immediate parent digest**
   - When `open_untrusted` keeps/exports output at all, the resulting artifact is still a fresh object with its own digest.
   - That fresh object MUST record the exact digest of the source object that was materialized for the safe-open request as **`origin.parent_digest`**.
   - For the portable seam, this is the **immediate parent** only: one exact source-object digest, not an inferred path, filename, URI, or template identity.

2) **Lineage is explicit evidence, not hidden identity continuity**
   - `origin.parent_digest` is a provenance hook, not a reuse of the original **CH-DOCREF**, not a persistent grant, and not permission to reopen/overwrite the parent object.
   - The kept result remains a **new artifact** on the explicit `portal.file.*` / `portal.xfer.*` seams.
   - Any source reopen, publish, replace, or quarantine-clear action still happens only on its existing explicit seam.

3) **`origin.chain_digest` remains the fuller optional chain when available**
   - If CH-PROV is enabled, implementations SHOULD bind the kept artifact into a provenance chain whose digest is recorded as `origin.chain_digest`.
   - That chain may carry richer evidence such as the child digest, parent digest, workflow receipt digests, sanitizer identity, or policy decisions.
   - Phase 1 does **not** require D-QUAR to standardize a new CH-PROV schema; it only requires that the minimum portable lineage hook stay explicit even when a fuller chain is absent.

4) **No locator/path fallbacks and no source-guessing folklore**
   - `origin.locator_hint` remains informational only and is not a substitute for `origin.parent_digest`.
   - Same displayed filename, same project, same folder suggestion, or same app session must not stand in for explicit parent linkage.
   - If the implementation cannot identify the exact parent digest for an ordinary safe-open export, it MUST fail closed or keep the result on a local-only/non-exported path rather than minting a lineage-less kept artifact.

5) **Ordering and conflict keys stay on existing seams**
   - Recording `origin.parent_digest` adds **no new conflict-key family**.
   - Independent safe-open exports still commute **with respect to requester authority** except where the existing destination-creation or explicit later publish/replace seam already serializes.
   - Non-commutative behavior lives where it already lives: destination mutation, explicit clear, explicit sanitize, or later publish/replace actions.

6) **Sealed compat remains killable and non-ambient**
   - Compat viewers/importers may participate in safe-open only if kept output preserves the same explicit-parent-lineage rule.
   - Compat must not treat “save from sandbox” or “copy modified bytes back” as sufficient lineage, because raw bytes without explicit parent evidence collapse reviewability.
   - If an interop path cannot preserve explicit parent linkage, it fails closed for safe-open export.

## Phase 1 non-goals (explicitly deferred)

- **No recursive ancestry graph or ambient lineage-query service** in D-QUAR itself.
- **No reuse of the source `docref`, durable grant, or object identity** as shorthand for lineage.
- **No path/filename/URI-based parent inference** in place of exact parent digest evidence.
- **No trust upgrade or quarantine clear** merely because a lineage record exists.
- **No new safe-open-specific provenance schema family** beyond one explicit `origin.parent_digest` hook plus optional CH-PROV chaining.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-QUAR, D-EPHEM)
- Related posture / schema surfaces:
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-materialization-boundary-v0.md`
  - `open-untrusted-export-classification-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `quarantine-posture-v0.md`
  - `origin-quarantine-attrset.md`
  - `document-portal-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL)
- RFC / engineering history:
  - `rfcs/0046-workflow-plumbing-and-portals.md`
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0089-document-portal-and-durable-file-handles.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_open_untrusted_export_lineage_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **explicit parent digest / no hidden identity continuity / no locator fallback** constraints, or drops its primary REF wiring.

## References

- REF-QUBES-DISPOSABLES.
- REF-QUBES-QFILECOPY.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-IN-TOTO-STATEMENT.
- REF-SLSA-PROVENANCE.
