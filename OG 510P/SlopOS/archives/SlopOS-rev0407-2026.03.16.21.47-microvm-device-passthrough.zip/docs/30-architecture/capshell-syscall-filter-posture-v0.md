# Capshell syscall-admission / syscall-filter posture v0 (no ambient inherited syscall-filter baseline)

Purpose: keep **D-CAPSHELL** honest once exact exec selection, exact executable-object binding,
exact startup code-closure binding, fixed caller identity, normalized signal/scheduling/personality
state, and no-privilege-gain launch posture are already explicit. Those cuts are still
insufficient if the child can quietly inherit wrapper-/service-manager-installed **syscall
admission policy** that never appeared in the reviewed execution pack.

On Linux, `seccomp(2)` filters are inherited by children when `fork()` / `clone()` are permitted
and are preserved across `execve(2)`; additional filters may also be layered later. systemd treats
`SystemCallFilter=` as a first-class service execution policy surface. That makes inherited
syscall-filter state a real launch boundary rather than harmless launcher trivia.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a reviewed
per-step seccomp selector, a generic sandbox catalog, a portable syscall broker, or an app-visible
system-call policy API. It only freezes the minimum Phase 1 posture needed so reviewed automation
launches under **one default syscall-admission baseline for the active execution compartment**
rather than inheriting wrapper/session/service-manager narrowing that happened to exist around the
launcher.

## Posture (v0)

1) **No inherited wrapper/session syscall-filter baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit wrapper-installed `seccomp()` / `PR_SET_SECCOMP` filters,
     service-manager `SystemCallFilter=` policy, or equivalent launcher/session syscall-admission
     narrowing merely because the parent shell, wrapper, login profile, service manager, compat
     membrane, or host session already had it.
   - Ambient launch state includes inherited seccomp filter trees, wrapper-local sandbox profiles,
     and service-manager/system policy that narrows child syscalls beyond the default baseline for
     the active execution compartment.

2) **Phase 1 adds no reviewed per-step syscall-filter / seccomp surface**
   - Phase 1 introduces no `capshell.exec.seccomp`, no syscall-filter descriptor family, and no
     ACP/admin action family for selecting allowlists, denylists, seccomp return actions, or
     wrapper-installed syscall-admission profiles per step.
   - The portable seam is therefore: **do not carry wrapper/session/service-manager syscall-filter
     state across the reviewed launch boundary**.
   - If a deployment profile needs a fixed compartment-level syscall-admission ceiling, that
     remains provider-/membrane-local policy and MUST be independent of parent shell/session state.

3) **Launch normalizes to the default syscall-admission baseline for the active execution compartment**
   - Before `exec` (or via equivalent spawn attributes), runners/wrappers MUST normalize the child
     to the **default syscall-admission baseline for the active execution compartment** rather than
     preserving extra wrapper/session/service-manager narrowing layered on top of it.
   - The active execution compartment may already have a provider-defined default syscall-admission
     ceiling (for example a micro-VM, container, hosted cell, or service runtime baseline). That
     baseline may remain in force; the Phase 1 promise is only that reviewed launch meaning does
     not additionally depend on ambient wrapper-/session-installed seccomp or `SystemCallFilter=`
     state.
   - Compat/foreign-cell membranes that cannot guarantee that normalized posture MUST fail closed
     rather than preserving host defaults.

4) **Reviewed launch meaning excludes ambient syscall-admission narrowing**
   - Reviewed `capshell.exec` meaning is "this exact exec selector / object / code closure under the
     default syscall-admission baseline for the active execution compartment", not "whatever
     seccomp or service-manager filter the launcher already happened to have".
   - Phase 1 therefore declines any portable promise that reviewed automation may rely on ambient
     syscall denial, allowlisting, trap/log behavior, or wrapper-local sandbox profiles unless a
     future explicit seam is introduced.

5) **Other explicit seams do not mint or repair syscall-filter policy**
   - **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and
     **CH-REQCTX v1** do not authorize smuggling seccomp profiles, sandbox class names,
     `SystemCallFilter=` fragments, or syscall-admission hints through unrelated fields.
   - Adjacent conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt/job-control UX, or compat adapters) MUST NOT become hidden carriers for ambient
     syscall-filter policy.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable API for listing, probing, or selecting inherited seccomp state,
     no reviewed report field exposing wrapper-installed syscall filters, and no admin surface for
     toggling syscall-admission policy per workflow step.
   - If later evidence shows real need for a reviewed syscall-filter / sandbox selector, that work
     must return as **one new explicit decision surface** rather than widening `capshell.exec` by
     implication.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden wrapper/session
     syscall-admission state.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT recreate host seccomp / service-manager sandbox lore behind the
     reviewed seam.
   - If a foreign runtime cannot suppress extra inherited syscall-filter policy or cannot guarantee
     the default syscall-admission baseline for the reviewed target runtime, it MUST fail closed
     rather than silently preserving host wrapper/session behavior.

## Phase 1 non-goals (explicitly deferred)

- No portable seccomp / syscall-filter selector in Phase 1.
- No generic sandbox-profile catalog or per-step syscall policy API.
- No portable query/report surface exposing inherited wrapper/service-manager syscall filters.
- No promise that wrapper-local seccomp or service-manager `SystemCallFilter=` policy is available
  on the generic seam.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-personality-posture-v0.md`
  - `capshell-peer-inspection-posture-v0.md`
  - `capshell-launcher-lifetime-posture-v0.md`
  - `capshell-privgain-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-SYSCALL-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-SYSCALL-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_syscall_filter_posture.py` (**EVID-2026-349**).

## References

- REF-MAN7-SECCOMP
- REF-KERNEL-SECCOMP
- REF-MAN7-SYSTEMD-EXEC
