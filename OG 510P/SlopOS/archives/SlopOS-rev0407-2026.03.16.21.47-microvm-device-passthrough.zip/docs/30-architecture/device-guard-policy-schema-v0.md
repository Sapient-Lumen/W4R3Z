# CH-DEVGUARD v0: device authorization / hotplug policy descriptor

Purpose: a pinned, redaction-safe descriptor for **device authorization rules** (D-DEVGUARD), suitable for transcript logging, audit, and deterministic policy evaluation.
This schema does **not** carry capability secrets; it describes which device identities/topologies are allowed to become *eligible* for assignment or leasing.

Inspiration: USBGuard’s rule-driven authorization model (REF-USBGUARD-RHEL7, REF-USBGUARD-RULELANG) and Qubes’ explicit device attach workflows (REF-QUBES-USB).

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-DEVGUARD v0 := {
  v: 0,

  default: tstr,              ; closed enum: "deny" | "quarantine" | "allow_driver" | "allow_attach" | "allow_autoattach"

  rules: [* rule],            ; bounded list, evaluated in order; first-match-wins
}

rule := {
  id: tstr,                   ; small opaque id for logging/correlation (bounded)
  match: match,
  action: action,
  note?: tstr,                ; optional operator note (bounded; redaction-safe)
}

match := {
  bus?: tstr,                 ; closed enum: "usb" | "pci" | "other"
  port_path?: tstr,           ; stable topology string if available (e.g., "2-4.1"); policy-defined semantics
  vid?: uint,                 ; vendor id (e.g., USB VID), if known
  pid?: uint,                 ; product id, if known
  class?: tstr,               ; closed enum: "hid" | "storage" | "net" | "camera" | "audio" | "other"
  serial_hash?: bstr,         ; optional stable identifier as a hash/digest (no raw serials by default)
}

action := {
  decision: tstr,             ; closed enum: "deny" | "quarantine" | "allow_driver" | "allow_attach" | "allow_autoattach"

  driver_domain?: tstr,       ; optional named driver host/domain label (policy-defined namespace)
  target_domain?: tstr,       ; only for "allow_autoattach": named target domain label
  require_portal?: bool,      ; if true, attach requires explicit portal consent even if allow_attach
  risk_tier?: tstr,           ; closed enum: "low" | "medium" | "high" (display hint; not authority)
}

## Semantics (v0)
- Matching is **deterministic** and order-dependent: evaluate `rules` sequentially; first match wins; else use `default`.
- `allow_driver` means the device may be bound to a driver domain but remains **unattached** to workloads.
- `allow_attach` means the device is eligible for attach to a workload, but should default to **portal-required** unless `require_portal=false` is explicitly set.
- `allow_autoattach` is a footgun and should be disallowed by default profiles unless the platform/role requires it.
- All actions should be **transcript-visible**: CH-LOG records reference digest(CH-DEVGUARD), matched rule id, and the attach/detach result.

## Notes / non-goals
- This is not a universal device identity format. Keep it intentionally small and extensible only via new versions.
- Do not treat `port_path` or `serial_hash` as “secure identity”; they are best-effort hints for policy and UX.
