# D-QUAR / D-ATTRFS quarantined result-preview boundary v0 (metadata-safe result rendering; no ambient snippets / preview panes)

Purpose: pin the **result-rendering boundary** that remains even after quarantined discovery/indexing has already been fenced to **metadata-safe only**, explicit analysis has already been forced onto **separate derived artifacts**, and exact query hits have already been pinned to the **artifact that actually matched**.
It narrows the next laundering seam: **even if the right object matched, may search/smart-folder/launcher surfaces still auto-render snippets, excerpts, thumbnails, preview panes, Quick Look cards, or hover previews from quarantined bytes?**
Phase 1 answers: **no**. For quarantined objects — including quarantined derived artifacts — ambient result rendering stays **metadata-safe only**. Any richer byte/content preview requires a new explicit handle-targeted review/open step on the exact object.

This keeps D-QUAR and D-ATTRFS honest without inventing a larger preview/answer-card subsystem: the archive already permits explicit safe-open and explicit related-artifact traversal, but now fixes the minimum portable rule that stops result UIs from quietly turning search/discovery back into an ambient preview channel.

## Posture (v0)

1) **Result cards/lists stay metadata-safe only for quarantined objects**
   - Query/search/smart-folder/launcher result rows for quarantined objects may show declared safe metadata such as object name, type, size, timestamps, quarantine state, shell-owned labels, and explicit relation presence.
   - They must **not** auto-inline OCR text, extracted excerpts, summary paragraphs, semantic highlights, thumbnails, page/image previews, or other content-derived renderings from quarantined bytes.
   - This applies both to the original quarantined source object and to any quarantined **derived artifact** that matched a predicate; matchability does not itself authorize ambient preview.

2) **Selection, hover, focus, and suggestion UI are not implicit open/review**
   - Merely selecting a result, moving keyboard focus across a result list, hovering, expanding a group, showing a preview pane, or displaying “top match” / suggestion UI must **not** invoke a preview handler, Quick Look, thumbnail renderer, snippet fetcher, or viewer runtime over quarantined bytes outside an explicit review/open request.
   - “Preview while browsing results” is therefore **off by default** for quarantined objects unless the preview itself is mediated as a distinct explicit action on the exact handle.
   - A shell may still provide an explicit preview/open affordance, but the affordance must be reviewable as a new step rather than a consequence of list navigation.

3) **Richer preview routes back through existing explicit seams on the exact object**
   - If the user/operator wants more than metadata, the system crosses an existing explicit seam on the **exact object being previewed**.
   - For document-like quarantined objects bound through **CH-DOCREF**, that richer review step routes through `intent.kind=open_untrusted` and inherits the already-pinned **docref-only**, **snapshot-in**, **inert-by-default**, and **no durable residue** boundaries.
   - Exact executable/script objects remain deny-by-default until explicit object-local clear/override; a search result must not create a second preview/launch path around the quarantined execution boundary.
   - Explicit related-artifact traversal remains separate: previewing a derived artifact does not imply previewing the source object, and previewing the source object does not imply the derived artifact matched.

4) **No ambient snippet/preview caches are created by result rendering**
   - Result rendering for quarantined objects must not create durable host-side snippet caches, preview thumbnails, hover cards, answer-card payloads, or other preview artifacts outside the explicit viewer/review compartment.
   - If a selected explicit preview action needs temporary rendering state, that state stays inside the existing safe-open / explicit review workflow and follows its export/teardown rules.
   - Phase 1 therefore rejects “the query UI already had to render a little preview” as justification for durable preview residue or content leakage.

5) **Ranking/filtering may use the matched attributes, but rendering still stays metadata-safe**
   - A query engine may use declared attributes on the exact matching object for ranking, sorting, or filtering.
   - But ranking a quarantined derived artifact highly does **not** authorize inline display of the OCR text, summary sentence, or thumbnail that caused the match.
   - In other words: **matching and ordering may depend on the attributes; ambient result rendering still may not expose quarantined content bytes or content-derived previews.**

6) **Ordering and conflict keys stay on existing seams**
   - This boundary adds **no new conflict-key family**.
   - Result rendering itself stays a view/query presentation concern; any explicit preview/open step serializes only where it already serializes (`svc:workflow.router`, the selected safe-open implementation, or the existing object-local clear/exec seams).
   - The archive therefore does not add a second preview-token, hover-session, or answer-card ordering vocabulary in Phase 1.

7) **Sealed compat remains killable and non-ambient**
   - Compat adapters may support result previews only if quarantined objects still respect this metadata-safe rendering boundary.
   - If a foreign stack can only express search results by auto-rendering file-content snippets, preview panes, or hover cards as the user navigates the list, that behavior must be disabled for quarantined objects or isolated behind an explicit review/open step.
   - Legacy “select a result and the shell quietly renders part of the file” behavior is not grandfathered into sealed compat for quarantined content.

## Phase 1 non-goals (explicitly deferred)

- **No ambient inline snippet / excerpt / highlight rendering for quarantined search results**.
- **No preview-pane / Quick Look / hover-preview activation on mere selection, focus, or top-match suggestion for quarantined objects**.
- **No source-object preview substitution from a matching derived artifact's content**.
- **No new preview-token/cache/inventory/answer-card API in v0**.
- **No claim that quarantined objects disappear from results entirely**; metadata-safe result rows remain allowed.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-QUAR, D-ATTRFS, D-PLUMB)
- Related posture / schema surfaces:
  - `quarantine-posture-v0.md`
  - `attrfs-posture-v0.md`
  - `attribute-query-schema-v0.md`
  - `quarantined-content-index-boundary-v0.md`
  - `quarantined-derived-match-boundary-v0.md`
  - `open-untrusted-posture-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-5, I-ATTRQ-2)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-LOCAL, PO-ATTRQ-ENF)
- RFC / engineering history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`
  - `rfcs/0100-attribute-query-predicates-and-smart-folders.md`
  - `docs/60-engineering/cli-plumbing-tooling.md`

CI drift gate:
- `tools/check_quarantined_result_preview_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **metadata-safe result rendering / no hover-or-selection preview / explicit open-on-exact-handle** constraints, or drops its primary REF wiring.

## References

- REF-MS-PREVIEW-HANDLERS.
- REF-APPLE-QUICKLOOK.
- REF-APPLE-SPOTLIGHT-MAC.
