# Exit/entry surface budget (minimize privileged variability)

Purpose: bound the “ways into privileged effects.” This is the *primary* lever for proof tractability and exploit-resistance.

Scope: all privileged entrypoints, including syscalls/hypercalls, VM exits, faults, interrupts, and privileged control plane requests.

## Design rules
- **Enumerate** every privileged surface as an IF-ID (see `interface-registry.md`).
- **Close the set**: unknown variants fail closed (PO-ABI-TOTAL; C-ABI-1).
- **Budget** the number of variants (kinds, reasons, message forms) and treat growth as an ADR-level event.
- Prefer **action sets** (closed enums) over open-ended stringly interfaces.

## Surface ledger (v0; keep small)
| Surface class | Canonical interface | Encoding/schema | Budget target | Notes |
|---|---|---|---:|---|
| Syscall/hypercall dispatch | IF-KABI | CH-KABI v0 | ≤ 32 action kinds | model privileged effects as a closed action set |
| VM exits (hypervisor-first) | IF-KABI | CH-KABI v0 | ≤ 20 exit-action kinds | no hidden emulation paths (C-HV-1); see `exit-decode-contract.md` |
| Faults (page fault, GP, etc.) | IF-KABI | CH-KABI v0 | ≤ 12 fault-action kinds | total/fail-closed decode (PO-ABI-TOTAL) |
| Interrupt delivery | IF-KABI | CH-KABI v0 | ≤ 16 IRQ classes | keep routing policy explicit |
| Boot/update verifier | IF-BOOT | CH-CFG v0 / CH-BOOT v0 | fixed | policy-driven and minimal |
| Config load/apply | IF-CFG | CH-CFG v0 | fixed | schema-validated, digest-bound |
| Observation export | IF-OBS | CH-OBS v0, CH-OBSPOL v0, CH-LOG v0 | fixed | redaction + bounded policy-pinned export |
| Agent control plane | IF-ACP | CH-ACP v0, CH-LOG v0 | ≤ 24 action kinds | deterministic validator (C-LLM-1) |
| Tool sandbox | IF-SBX | (opaque bytes) | fixed | tool outputs are untrusted data; privileged effects require IF-ACP or caps |

## Evidence drivers (what justifies budget growth)
- **E1**: instrumentation proves no undisclosed entrypoints exist (supports I-IF-1).
- **E2**: bounded checks show “unknown variant ⇒ reject” for decoders/dispatch.
- **E3**: mechanized refinement of dispatch/decoding for the declared action sets.

## Claims/invariants impacted
- Claims: C-ABI-1, C-HV-1 (if hypervisor-first), C-OBS-1 (audit/export)
- Invariants: I-IF-1, I-ENC-1, I-LOG-1
- Proof obligations: PO-ABI-TOTAL, PO-ENC-DECODE, PO-LOG-REPLAY

## Normalization note
The VMX/SVM architecture exposes many *raw* exit reasons. The budget above is for **normalized, spec-defined exit kinds** in CH-KABI (i.e., the closed action set the privileged core actually reasons about).

Rule: decode maps raw exits into a small, budgetable enum (plus optional `subkind` for telemetry), and any raw reason outside the supported mapping is fail-closed (PO-XS-CLOSESET; PO-ABI-TOTAL).

