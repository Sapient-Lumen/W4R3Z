# Portal family registry (v0)

Purpose: keep portal families **stable and reviewable** as the ecosystem grows.

Portals are user-space mediation services that implement high-risk workflows (open/save/share, open-uri, printing, device selection, capture, etc.) and return **capability-bearing handles** instead of ambient strings/paths.

This registry ties together:
- the **portal family name** (`portal.*`),
- the **primary RFC(s)** that define the seam,
- any **bounded descriptor artifacts** (CH-*), and
- the corresponding **CH-PLEDGE tokens** used for voluntary self-restriction.

See: RFC-0046 (workflow plumbing + portals) and `pledge-token-mapping.md`.

## Portal families

Automation wiring:
- If a portal family has an ACP automation surface, list the CH-ACP kind token(s) here.
- If a portal family is intentionally **manual-only** in v0 (no ACP kind yet), the cell MUST say `none` (no placeholders).

| Portal family | Primary workflow(s) | ACP kind(s) (automation surface) | Descriptor artifact(s) (optional) | Primary decision(s) | CH-PLEDGE token | Notes |
|---|---|---|---|---|---|---|
| `portal.file.*` | open/save/export/share via chooser/powerbox | none (manual-only v0) | CH-DOCREF (durable handles) | D-PLUMB, D-POWERBOX | `portal.file` | manual-only v0; return handles/caps, not host paths; persistence is explicit, reopen is non-bearer + non-widening, and Phase 1 exposes no app-visible grant inventory (`document-portal-posture-v0.md`, RFC-0089) |
| `portal.uri.*` | open external URIs / open directory / show item | none (manual-only v0) | (none required) | D-PLUMB | `portal.uri` | manual-only v0; scheme-gated + launch-only; no app-visible handler inventory/probing or callback channel; `file://` stays a file-portal / CH-DOCREF problem (`openuri-portal-posture-v0.md`, RFC-0046) |
| `portal.print.*` | print workflow (dialog + submit) | none (manual-only v0) | (none required) | D-PLUMB | `portal.print` | manual-only v0; render-first prepare→submit; no app-visible printer inventory or durable queue authority; print-to-file remains a file-portal / CH-DOCREF problem (`print-portal-posture-v0.md`, RFC-0046) |
| `portal.device.*` | pick device / request device lease (e.g., USB) | none (manual-only v0) | CH-HWEVENT (if D-SKB) | D-DEVGUARD, D-IOLEASE | `portal.device` | “device access” is a workflow: user intent + policy + lease bounds; v0 posture pinned in `io-lease-posture-v0.md` |
| `portal.net.*` | outbound connectivity lease/session grants | `portal.net.request` | (session descriptors optional) | D-NETLEASE, D-LEASE | `portal.net` | no ambient `connect-by-name`; scope split (local vs internet) is policy; v0 posture pinned in `network-lease-posture-v0.md` |
| `portal.clock.*` | clock handle/lease issuance (coarse by default; fine by explicit grant) | `portal.clock.timeproof.sample` (timeproof) | CH-CLOCK, CH-TIMEREQ, CH-TIMEPROOF | D-NONDET, D-LEASE, D-TIMEPROOF (optional) | `portal.clock` | time is nondeterminism; prefer coarse timers; fine clocks are explicit authority (RFC-0063); v0 posture pinned in `nondet-posture-v0.md`; authenticated time proofs are evidence-first + lower-bound-only, and portable/exported CH-TIMEPROOF is Roughtime-only in Phase 1 (`timeproof-posture-v0.md`, RFC-0090) |
| `portal.entropy.*` | entropy handle/lease issuance (seed-by-default) | `portal.entropy.request` | CH-ENTROPY | D-NONDET, D-CRYPTOSVC (adjunct) | `portal.entropy` | treat privileged entropy primarily as bounded seed material; v0 posture pinned in `nondet-posture-v0.md`; deterministic entropy is explicit for test/replay; ACP kind portal.entropy.request binds `digest(CH-ENTREQ v0)` (RFC-0063) |
| `portal.location.*` | location (one-shot, updates, geofences) | none (manual-only v0) | CH-LOCLEASE | D-LOCLEASE, D-LEASE | `portal.location` | manual-only v0; coarse-first; treat as sensitive metadata; no persistent tracking in Phase 1; indicators for continuous foreground updates (`location-lease-posture-v0.md`) |
| `portal.secret.*` | per-application secret seed retrieval/rotation | none (manual-only v0) | CH-APPSECRET | D-APPSECRET, D-CRYPTOSVC (adjunct), D-VAULT (optional) | `portal.secret` | minimal app-scoped seed seam only; no ambient "secret by name" APIs, no collection/item model, and no silent auto-rotation in v0 (`app-secret-posture-v0.md`) |
| `portal.capture.*` | camera/mic/screencast/remote desktop | none (manual-only v0) | CH-CAPTURE | D-CAPTURE, D-LEASE | `portal.capture` | manual-only v0; indicator-bound live sessions; no ambient capture; no restore-token / remembered-session semantics in Phase 1 (`capture-portal-posture-v0.md`, RFC-0095) |
| `portal.xfer.*` | clipboard/drag-drop/share transfers | none (manual-only v0) | CH-XFER | D-PLUMB, D-LEASE | `portal.xfer` | manual-only v0; sink-pull (`copy` is offer, paste/drop/share is grant); one-shot/auto-clear across trust boundaries; no background clipboard observers/history service (`transfer-portal-posture-v0.md`, RFC-0094) |
| `portal.attn.*` | notifications / attention prompts | `portal.attn.request` | CH-NOTIF | D-ATTN, D-VOLITION | `portal.attn` | origin branding + budgets; `importance="urgent"` is a policy-gated hint (no lease/capability in v0); actions bind to CH-ROUTE/CH-ACP digests (RFC-0055) |
| `portal.jobs.*` | constraint-based background work | `portal.jobs.submit` | CH-JOBREQ | D-JOBS, D-TCAP | `portal.jobs` | coalesced scheduling; no precise alarms by default; v0 posture pinned in `job-portal-posture-v0.md` (RFC-0096) |
| `portal.background.*` | background execution + login autostart grants | `portal.background.request` | CH-BGREQ, CH-BGLEASE | D-BGLEASE, D-JOBS | `portal.background` | prefer D-JOBS for deferrable work; background presence/autostart are visible, bounded, revocable, and v0 posture-pinned in `background-lease-posture-v0.md` (RFC-0103) |
| `portal.inhibit.*` | inhibit idle/suspend/logout/shutdown transitions | none (manual-only v0) | CH-INHIBITLEASE | D-INHIBITLEASE, D-LEASE | `portal.inhibit` | delay-by-default for apps; block reserved for privileged components; **close-to-release**, current-session scoped, and non-durable in v0; indicators for long-lived inhibits (`inhibit-lease-posture-v0.md`, RFC-0102) |
| `portal.a11y.*` | accessibility / automation sessions | none (manual-only v0) | CH-UIAUT | D-UIAUT, D-UICAP | `portal.a11y` | manual-only v0; observe ≠ inject; leased sessions + non-spoof indicators; no hidden persistence/relaunch seam in Phase 1 (`ui-automation-posture-v0.md`, RFC-0099) |

## Lane kill switches

Every portal family is an explicit workflow authority seam and MUST be policy-killable:
- For each CH-PLEDGE token `portal.<family>` in this registry, there is a corresponding CH-CFG kill switch `cfg.params.lane.portal.<family>` (closed set in `config-toggle-registry.md`).
- Portal invocations MUST treat missing/unknown lane toggle values as disabled (fail closed) and emit transcript-visible denial/receipt evidence when rejected (PO-LANE-KILL; I-LANEGATE-1).

This prevents “ambient portal enablement” drift and keeps sealed-compat and workflows honest across profiles.
CI drift gate: docs must not introduce new backticked `portal.*` tokens without updating this registry; `tools/check_portal_token_refs.py` fails `make lint` if any doc references an unknown portal family (PO-PORTALREF-CLOSE).
CI drift gate: portal families must declare whether they have an ACP automation surface by listing `portal.<family>.*` action kind token(s) (or explicitly `none`), and every `portal.*` ACP kind must be listed under its family row; `tools/check_portal_registry_acp_kinds.py` fails `make lint` on drift (EVID-2026-203).


## Reference precedents
These families intentionally mirror the shape of widely deployed desktop portals:
- OpenURI (open external links) and Print portals. (REF-XDG-PORTAL-OPENURI, REF-XDG-PORTAL-PRINT)
- Notifications as a mediated attention workflow. (REF-XDG-PORTAL-NOTIFICATION)
- USB device access as a mediated workflow. (REF-XDG-PORTAL-USB)
- Inhibit portal for session-transition inhibition. (REF-XDG-PORTAL-INHIBIT)
- Secret portal for per-application secret seeds. (REF-XDG-PORTAL-SECRET)

The goal is not “Linux compatibility”; it is to bake the **mediation pattern** (handles/caps, consent, leases, receipts, bounded descriptors) into the OS ecosystem from day one.
