# Capshell execution-domain / personality posture v0 (no inherited ABI/personality baseline)

Purpose: keep **D-CAPSHELL** honest once exact exec selection, exact executable-object binding,
exact startup code-closure binding, fixed caller identity, and no-privilege-gain launch posture are
already explicit. Those cuts are still insufficient if the child quietly inherits a modified
**execution domain / personality** from the wrapper, login shell, service manager, or compat layer.
On Linux, `personality(2)` can change legacy execution-domain behavior and flags such as
`ADDR_NO_RANDOMIZE`, `ADDR_COMPAT_LAYOUT`, `READ_IMPLIES_EXEC`, `STICKY_TIMEOUTS`, and `UNAME26`;
wrappers such as `setarch(8)` and service-manager knobs such as `Personality=` / `LockPersonality=`
prove this is a real launch boundary rather than trivia.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a reviewed
per-step ABI/personality selector, a `capshell.exec.personality` convenience knob, or a generic
legacy-emulation catalog. It only freezes the minimum Phase 1 posture needed so reviewed automation
launches under **one default native execution-domain / personality baseline** rather than inheriting
wrapper/session quirks that never appeared in the reviewed execution pack.

## Posture (v0)

1) **No inherited shell/session/service-manager personality baseline**
   - `capshell.exec` MUST NOT inherit execution-domain / personality state merely because the parent
     shell, wrapper, login profile, service manager, container entrypoint, or compat membrane
     already had it.
   - Ambient launch state includes alternate execution-domain selection, `setarch`-style arch /
     `uname -m` personality changes, and personality flags such as `ADDR_NO_RANDOMIZE`,
     `ADDR_COMPAT_LAYOUT`, `READ_IMPLIES_EXEC`, `STICKY_TIMEOUTS`, `UNAME26`, and similar
     legacy-emulation bits that never appear in the reviewed execution pack.

2) **Phase 1 adds no reviewed per-step execution-domain / personality surface**
   - Phase 1 introduces no `capshell.exec.personality`, no ABI/emulation descriptor family, and no
     ACP/admin action family for choosing legacy execution domains or personality flags per step.
   - The portable seam is therefore: **do not carry wrapper/session personality state across the
     reviewed launch boundary**.
   - If a deployment profile needs a fixed execution-domain/personality policy for one runtime, that
     remains provider-/membrane-local policy and MUST be independent of parent shell/session state.

3) **Launch normalizes execution-domain / personality to the default native baseline**
   - Before `exec` (or via equivalent spawn attributes), runners/wrappers MUST normalize the child
     to the platform's **default native execution-domain / personality baseline** for the reviewed
     target runtime.
   - Launch MUST NOT preserve inherited `setarch`-style arch personality, `Personality=` service
     manager overrides, `ADDR_NO_RANDOMIZE`, `READ_IMPLIES_EXEC`, `ADDR_COMPAT_LAYOUT`,
     `STICKY_TIMEOUTS`, `UNAME26`, or similar wrapper/session flags as reviewed workflow meaning.
   - Compat/foreign-cell membranes that cannot guarantee that normalized posture MUST fail closed
     rather than preserving host defaults.

4) **Reviewed launch meaning excludes wrapper-driven legacy/emulation quirks**
   - Reviewed `capshell.exec` meaning is "this exact exec selector / object / code closure under
     the default native execution-domain/personality baseline", not "whatever legacy ABI,
     architecture-reporting, ASLR, mmap, or timeout quirks the wrapper happened to enable".
   - Phase 1 therefore declines any portable promise that reviewed automation may rely on altered
     `uname` arch reporting, disabled ASLR, `READ_IMPLIES_EXEC`, legacy mmap layout, sticky timeout
     semantics, or similar execution-domain quirks unless a future explicit seam is introduced.

5) **Other explicit seams do not mint or repair personality state**
   - **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and
     **CH-REQCTX v1** do not authorize smuggling execution-domain / personality state through
     unrelated fields.
   - Adjacent conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt/job-control UX, or compat adapters) MUST NOT become hidden carriers for execution-
     domain / personality policy.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable API for listing, probing, or selecting alternate personality
     modes, no reviewed report field exposing inherited personality state, and no admin surface for
     toggling execution-domain quirks per workflow step.
   - If later evidence shows real need for a reviewed personality/ABI selector, that work must
     return as **one new explicit decision surface** rather than widening `capshell.exec` by
     implication.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain exactly those already declared for `capshell.exec` (`domain.id`, ordered
     within a domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden wrapper/session
     execution-domain / personality state.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT recreate host personality lore behind the reviewed seam.
   - If a foreign runtime cannot clear inherited personality flags or cannot guarantee the default
     native execution-domain/personality baseline for the reviewed target runtime, it MUST fail
     closed rather than silently preserving host wrapper/session behavior.

## Phase 1 non-goals (explicitly deferred)

- No portable `capshell.exec.personality` selector or ABI/emulation descriptor in Phase 1.
- No generic compatibility catalog for legacy personality modes.
- No portable query/report surface exposing inherited wrapper/session personality state.
- No promise that multi-ABI or legacy-emulation launch behavior is available on the generic seam.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-scheduling-posture-v0.md`
  - `capshell-privgain-posture-v0.md`
  - `capshell-credential-baseline-posture-v0.md`
  - `capshell-code-closure-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-PERS-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-PERS-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
  - `capshell-launch-boundary-index.md`
- CI drift gate: `tools/check_capshell_personality_posture.py` (**EVID-2026-345**).

## References

- REF-MAN7-PERSONALITY
- REF-MAN7-SETARCH
- REF-MAN7-SYSTEMD-EXEC
