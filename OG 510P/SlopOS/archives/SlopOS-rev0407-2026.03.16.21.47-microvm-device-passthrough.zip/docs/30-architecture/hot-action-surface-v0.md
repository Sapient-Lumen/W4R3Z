# Hot action surface v0 (commutativity + serialization points)

Purpose: pin a small set of **hot** privileged actions that we treat as first-class **performance** and **proof** targets.

Why now: Hybrid (D-MK) only pays off if the *interface* does not accidentally force global order. D-COMMUTE says “make order-dependence explicit”; this doc makes that concrete.

Scope: this is an *evidence-driving* selection, not a complete action set. The seed set is intentionally small and maps to the likely highest-frequency privileged transitions.

## How to read this table

- **Conflict key**: the smallest resource identity whose concurrent mutation can conflict.
-   - When the key must cross trust boundaries (validators/receipts/tests), represent it as `digest(CH-CONFLICTKEY v0)`.
- **Commutativity**:
  - **commutes (keyed)**: operations on *different conflict keys* commute; same key may serialize.
  - **commutes (conditional)**: commutes only under a predicate (e.g., disjoint ranges).
  - **non-commutative (required)**: order is part of the spec; we must serialize *for correctness*.
- **Serialization point**: where we *intentionally* impose order; must be explicit and reviewable.
- **Replication contract (default)**: how cross-cluster observations/interop of *metadata* for this family is handled under Hybrid (RC0..RC4 in `replication-contracts-v0.md`). This is **not** “copying capabilities.”
- **Ordering witness**: if the family is ordered, receipts MUST record `order_digest` referencing CH-ORDERTOK v0 (or explicitly declare `none`).

## Seed hot actions (v0)

| Action family (candidate) | Where it lives | Conflict key(s) | Commutativity stance | Serialization point (if any) | Replication contract (default) | Proof/perf target |
|---|---|---|---|---|---|---|
| `mem.map` / `mem.unmap` | CH-KABI `mem.*` | `(as_id, vaddr_range)` | **commutes (conditional)** on disjoint ranges; **non-commutative** for overlapping ranges | per-address-space **range ownership/lock** (overlap ⇒ serialize or reject) | **RC0** (address spaces are cluster-local) | PO-HOT-MEMRANGE; commutativity tests on disjoint ranges; overlap stress + W^X regression checks |
| IPC endpoint ops | kernel IPC (CH-KABI or equivalent) | `endpoint_id` | **non-commutative (required)** *within an ordered endpoint*; **commutes (keyed)** across endpoints | per-endpoint queue/owner (ordering is explicit, scoped) | **RC0** (endpoints are cluster-local; cross-cluster via proxy contracts) | PO-HOT-IPCORDER; send/recv/close microbench: many endpoints scale; single endpoint contention is visible |
| `view.attach` / `view.detach` | view service / namespace layer | `(view_id, slot_id)` | **commutes (keyed)** across disjoint slots; **non-commutative** within the same slot | per-(view,slot) serialization (attach/detach is a name-binding surface) | **RC1** (owner-sharded per `view_id`; optional RC2 caches) | PO-HOT-VIEWSLOT; negative tests for name-binding confusion; contention bound; replicated summaries stay read-only/non-activating (`view-replication-boundary-v0.md`) |
| Transcript/receipt append | CH-LOG v0 store | `(log_id, entry_digest)` | **commutes (keyed)** by design: entries are content-addressed events; export order is canonicalized | none for correctness; sharding is allowed; ordering is derived | **RC3** (commutative merge; transcript replication is evidence-only and cannot drive replay/admission/runtime ordering; see `transcript-replication-boundary-v0.md`); RC4 only by explicit profile decision | PO-HOT-LOGCOMMUTE; deterministic export order checks; replay checks |
| Meter/budget charge | metering layer (D-METER/D-BUDGET) | `budget_id` / `meter_id` | charges are **commutative** (additive) *within allocated credit*; enforcement/minting is a separate, explicit step | **mint/split/grant** is the serialization point; spend is local/atomic | Spend: **RC3** for observational additive summaries only; Mint/revoke: **RC1** owner-routed issuer/lineage metadata only | PO-HOT-QUOTATOK; quota spend hot path avoids cross-cluster coordination; cached `budget` replicas never create portable spend authority (see `budget-replication-boundary-v0.md`) |

Notes:
- This table does *not* force implementation choices inside the kernel; it forces **spec clarity**: where order matters, say so.
- The non-commutative rows are *not bad*—they are where we focus proof effort and measure contention.

## Required annotations for each hot action (minimum)

For each hot action family, the spec/RFC/ADR must record:
1) conflict key(s),
2) commutation predicate (if conditional),
3) the explicit serialization owner (if non-commutative),
4) the normalized externally observable outcome digest used by commutativity tests,
5) the **minimal non-commutative sub-action boundary** (or explicit `none`) — see `hot-action-boundaries-v0.md`,
6) the **cross-cluster replication contract class (RC*)** for any cross-cluster observation/interop of relevant metadata — see `replication-contracts-v0.md` (D-REPL; CH-REPLCONTRACT v0).

## Evidence wiring

- Default commutativity test/fuzz target set: **these actions** (EVID-2026-119).
- Default “serialization-point microbench” targets: the non-commutative rows above (EVID-2026-120).

## Related docs

- D-COMMUTE: `commutativity-and-interface-scalability.md`
- Multicore options / Hybrid: `multicore-architecture-options.md` (D-MK)
- Replication contracts: `replication-contracts-v0.md` (D-REPL)
- Quota RC3 boundary: `quota-replication-boundary-v0.md`
- Ordering tokens: `ordering-token-schema-v0.md` (CH-ORDERTOK v0)
- KABI action families: `kabi-action-schema-v0.md` (CH-KABI v0)
- Transcript contract: `transcript-contract.md` (CH-LOG v0)
- Hot boundaries: `hot-action-boundaries-v0.md` (non-commutative sub-actions + default RC*)
