# D-ROBUSTLOCK posture v0 (mutex-only owner-death assist; explicit poison on failed repair)

Purpose: pin an implementable v0 meaning for **D-ROBUSTLOCK** so owner-death recovery stays a small, explicit runtime/kernel assist rather than drifting into a general lock-object family, a cross-process wake substrate, or a hidden scheduler/PI contract.
It narrows RFC-0111 into one compact posture validators and harnesses can reason about: one runtime-owned per-thread registration surface, mutex-only coverage, explicit `OWNER_DIED` / `NOT_RECOVERABLE` recovery states, and no new workflow/ACP surface.

## Posture (v0)

1) **Optional owner-death assist, not a lock-object family**
   - If D-ROBUSTLOCK is enabled, it is a **low-level runtime / compatibility primitive** for user-space mutexes that want explicit owner-death recovery.
   - Phase 1 does **not** standardize kernel-managed mutex objects, a general lock service, or an application-facing "robust lock manager" API.
   - Robust metadata is recovery metadata, not authorization evidence (I-ROBUST-1).

2) **One explicit per-thread RobustSet registration surface**
   - v0 assumes **one runtime-owned RobustSet per thread** for the locks that thread may hold robustly.
   - Registration is explicit and opt-in; Phase 1 does **not** standardize ambient exit scanning, per-process inventories of robust locks, or a global query surface over registered addresses.
   - This keeps exit-time cleanup bounded and auditable (I-ROBUST-2; PO-ROBUST-BOUND).

3) **Mutex-only in v0; no rwlock / condvar / PI variants**
   - D-ROBUSTLOCK v0 covers **mutex words only**.
   - Phase 1 does **not** standardize robust rwlocks, robust condvars, PI mutexes, or ownership-transfer variants on this seam.
   - This keeps the state machine small and avoids silently importing scheduler policy into owner-death recovery.

4) **Component-local coverage in v0; cross-process robust recovery is deferred**
   - Registered lock words MUST lie in the caller's writable address space and are recovered only for the owning **component / address space** in Phase 1.
   - v0 therefore does **not** claim inter-process robust mutex recovery for shared-memory regions, named mutex objects, or cross-domain waiter wakeups.
   - Any future shared-region / cross-process variant must land RFC-first alongside an explicit shared wait contract rather than widening D-ROBUSTLOCK by implication.

5) **OWNER_DIED is explicit and non-authoritative**
   - If a thread exits while holding a registered robust mutex, the runtime/kernel sets an explicit **`OWNER_DIED`** state and performs a bounded wake/release on any local waiters (I-ROBUST-1).
   - The next acquirer receives an explicit `owner_died` result; this means only that the lock was acquired from a dead owner and the protected state may be inconsistent.
   - `OWNER_DIED` does **not** grant repair authority beyond the lock acquisition the caller already performed.

6) **Recovery is explicit: `make_consistent()` or poison permanently**
   - After `owner_died`, the successor MUST either repair the protected state and call **`make_consistent()`**, or fail closed.
   - If the successor unlocks or abandons the mutex **without** `make_consistent()`, the mutex transitions to an explicit **`NOT_RECOVERABLE`** state until reinitialized (I-ROBUST-1).
   - Phase 1 therefore declines the Windows-style "release and silently return to normal" posture in favor of a stricter fail-closed recovery contract aligned with robust-mutex practice.

7) **Generation-safe owner identity only; no hidden handle resurrection**
   - Any owner token stored in a robust mutex word MUST be generation-safe so thread-id reuse cannot spuriously trigger owner-death or cleanup on an unrelated mutex (I-ROBUST-3; PO-ROBUST-NOREUSE).
   - Cleanup logic MUST only act when the stored owner token still names the exiting owner generation.
   - Robust cleanup does not resurrect thread handles, recreate waiters, or mint new authority.

8) **Bounded exit cleanup; no ambient inventory or scavenger**
   - Registration count, exit-time scan work, and wake fan-out MUST be bounded and attributable when D-METER is enabled (I-ROBUST-2; PO-ROBUST-BOUND).
   - Overflow or invalid registration rejects deterministically; Phase 1 does **not** permit silent partial coverage or unbounded scavenging on exit.
   - High owner-death or poison rates SHOULD surface as supervision / diagnostics signals rather than remaining hidden inside the primitive.

9) **No new workflow / ACP / conflict-key surface in v0**
   - D-ROBUSTLOCK v0 introduces **no new portal family, CH-* request schema, or CH-ACP automation kind**.
   - Therefore **no new conflict-key family is introduced in v0**.
   - Any future admin/export surface (for example, shared robust sets, PI controls, or recovery-policy knobs) must land RFC-first with its own serialization boundary, commutativity story, receipts, and policy kill switches.

10) **Sealed compat remains killable and non-ambient**
   - Foreign Cells MAY use an internal host/runtime robust-mutex shim behind the membrane, but Phase 1 does **not** standardize a compat-visible named mutex namespace, env/path bridge, or hidden cross-domain recovery broker.
   - Any compat enablement remains policy-killable and must not recreate ambient synchronization channels that bypass D-UWAIT / D-FCELL posture.

## Phase 1 non-goals (explicitly deferred)

- Cross-process or cross-component robust mutex recovery for shared-memory regions.
- Robust rwlocks, robust condvars, or PI/priority-protected mutex variants.
- A public query/inventory API over robust registrations.
- Kernel-managed lock objects or a general lock manager.
- Automatic recovery policies beyond explicit `make_consistent()` / `NOT_RECOVERABLE`.

## Wiring

- Decision surface: `decision-map.md` (D-ROBUSTLOCK).
- Narrative/mechanism surfaces:
  - `mechanisms.md` (robust-lock seam)
  - `rfcs/0111-robust-locks-and-owner-death.md` (option space / evidence seed)
  - `rfcs/0110-wait-on-address-and-futex-primitives.md` (D-UWAIT boundary this posture refuses to widen)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-ROBUST-1, I-ROBUST-2, I-ROBUST-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-ROBUST-BOUND, PO-ROBUST-NOREUSE)
  - `docs/30-architecture/uwait-posture-v0.md` (process-local wait boundary)
- Discovery/profile surfaces:
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
- No portal family / ACP kind / conflict-key registry addition in v0; any future external control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_robustlock_posture.py` fails `make lint` if this posture stops being discoverable, loses the mutex-only / component-local / explicit-poison posture, or drops its primary REF wiring.

## References

- REF-LINUX-ROBUST-FUTEX-ABI.
- REF-LINUX-GET-ROBUST-LIST.
- REF-PTHREAD-MUTEXATTR-SETROBUST.
- REF-FREEBSD-UMTX-OP.
- REF-WIN-WAITFORSINGLEOBJECT.
