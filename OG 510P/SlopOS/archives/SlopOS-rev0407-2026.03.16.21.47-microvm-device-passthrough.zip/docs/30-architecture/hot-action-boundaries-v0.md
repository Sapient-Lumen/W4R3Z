# Hot action boundaries v0 (non-commutative sub-actions)

Purpose: refine the pinned **hot action surface** into explicit **sub-action boundaries** so we can:
- keep Hybrid (D-MK) honest about *where* serialization lives,
- keep D-COMMUTE honest about *what* must be ordered (and what must not),
- keep D-REPL honest about what cross-cluster coordination is required (and what is forbidden),
- and give verification/perf work a stable target list.

Rule: for every hot action family in `hot-action-surface-v0.md`, we must name the **minimal correctness-required serialization boundary** (or explicitly declare **none**) **and** record the default cross-cluster replication contract class (RC*) for the object family.

This doc is intentionally **mechanism-agnostic**: it constrains the *spec surface* and observable receipts, not the internal implementation.

## Terms

- **Sub-action**: a spec-level step that may be implemented as an internal critical section, an explicit KABI kind, or a user-space service method. The key is that we can talk about commutativity and serialization precisely.
- **Ordering token**: an explicit ordering witness (CH-ORDERTOK v0) proving membership in an ordered stream scoped to a conflict key. If order matters, receipts must make that order visible (order_digest).
- **RC***: replication contract class from `replication-contracts-v0.md` (RC0..RC4). This is about **cross-cluster metadata**, not copying handles/capabilities.

## Boundary table (v0 seed)

Columns:
- **Family**: row in `hot-action-surface-v0.md`.
- **Sub-action**: canonical name used in specs/tests (not a public API promise).
- **Where**: which surface owns it (IF-KABI / IF-ACP / user-space service).
- **Commutativity**: commutes (keyed/conditional) vs ordered.
- **Non-commutative boundary**: the *minimal* step that must serialize for correctness (or `none`).
- **Replication contract (default)**: RC* class for cross-cluster observations/interop of the relevant metadata.

| Family | Sub-action(s) (spec names) | Where | Commutativity | Non-commutative boundary (explicit) | Replication contract (default) |
|---|---|---|---|---|---|
| `mem.map` / `mem.unmap` | `mem.range_claim`, `mem.pte_apply`, `mem.tlb_sync` | IF-KABI | claim/apply **commutes (conditional)** on disjoint `(as_id, vaddr_range)`; overlap is ordered | **`mem.range_claim` on overlapping ranges**: one owner per overlapping range at a time; reject-or-serialize is explicit (PO-HOT-MEMRANGE) | **RC0** (address spaces are cluster-local; any cross-cluster sharing is explicit and separate) |
| IPC endpoint ops | `ipc.enqueue`, `ipc.dequeue`, `ipc.close_epoch` | IF-KABI | **ordered** within `endpoint_id`; commutes across endpoints | **`ipc.enqueue`/`ipc.dequeue` per `endpoint_id`**: endpoint order is part of the spec (PO-HOT-IPCORDER) | **RC0** (endpoints are cluster-local; cross-cluster calls are via explicit proxies/contracts) |
| `view.attach` / `view.detach` | `view.slot_mutate` (bind/unbind), `view.resolve_snapshot` | user-space view service (validated via IF-ACP as needed) | keyed across `(view_id, slot_id)`; **ordered** within a slot | **`view.slot_mutate` for a single `(view,slot)`**: name-binding order is explicit and receipt-visible (PO-HOT-VIEWSLOT) | **RC1** (owner-sharded per `view_id`; optional RC2 caches for read-only summaries) |
| Transcript/receipt append | `log.insert_event`, `log.export_canonicalize` | privileged log store (CH-LOG) | **commutative by design** (event-set insert) | **none for correctness**: ordering is derived by canonicalization; any implementation lock is a performance choice, not a spec requirement (PO-HOT-LOGCOMMUTE) | **RC3** (commutative merge as an event-set; replicated transcript state is evidence-only and cannot become runtime sequencing/admission authority; see `transcript-replication-boundary-v0.md`; RC4 only if a profile explicitly needs strict ordered-log semantics) |
| Meter/budget charge | `budget.spend_atomic`, `budget.mint_split` (grant), `budget.revoke` | IF-KABI (mechanism) + portals/validator (policy) | spend is **commutative** within minted credit; mint/split is ordered | **`budget.mint_split` per payer (`meter_id`/issuer)**: issuance is the correctness-serialization point; spends must avoid cross-cluster coordination on the hot path (PO-HOT-QUOTATOK; PO-BUDGET-CHARGE) | **Spend: RC3** for observational additive summaries only; **Mint/revoke: RC1** (owner-sharded per issuer) |

## Notes per family (normative)

### `mem.map` / `mem.unmap`
Non-commutative boundary: **`mem.range_claim` on overlap**.
Conflict key: `digest(CH-CONFLICTKEY v0)` with `family="mem.range"` and payload `{ as_key, vaddr_lo, vaddr_len }` (range identity).
Ordering token: **none** by default (overlap ⇒ deterministic reject). If a profile chooses serialize-on-overlap, receipts MUST include `order_digest` referencing CH-ORDERTOK v0 scoped to the claimed range.
Replication contract: **RC0 local-only** (per address-space home cluster).
- If two operations touch overlapping `(as_id, vaddr_range)`, the spec must either (a) serialize under a range owner, or (b) reject deterministically.
- Receipts must include enough normalized info to support commutativity tests on disjoint ranges (e.g., mapping digest / address-space digest).

### IPC endpoint ops
Non-commutative boundary: **endpoint queue order** (`ipc.enqueue`/`ipc.dequeue`).
Conflict key: `digest(CH-CONFLICTKEY v0)` with `family="ipc.endpoint"` and payload `{ endpoint_key }`.
Ordering token: CH-ORDERTOK v0 (family `ipc.endpoint`) scoped to `digest(CH-CONFLICTKEY v0)` for the endpoint conflict key (family `ipc.endpoint`; `endpoint_key` derived per `conflict-key-derivation-registry.md`). Receipts MUST record `order_digest` for ordered endpoint actions.
Replication contract: **RC0 local-only** (per endpoint home cluster).
- Ordering is scoped: per `endpoint_id` only.
- Cross-cluster calls are via explicit proxies (CapRPC/channels); any ordering requirement lives in that proxy’s contract and is transcript-visible.

### `view.attach` / `view.detach`
Non-commutative boundary: **slot mutation**.
Conflict key: `digest(CH-CONFLICTKEY v0)` with `family="view.slot"` and payload `{ view_key, slot_id }`.
Ordering token: CH-ORDERTOK v0 (family `view.slot`) scoped to `digest(CH-CONFLICTKEY v0)` for the slot conflict key (family `view.slot`; `view_key` derived per `conflict-key-derivation-registry.md`; `slot_id` raw). Receipts MUST record `order_digest` for slot-ordered attach/detach.
Replication contract: **RC1 owner-sharded** per `view_id` (with optional RC2 caches).
- The ordered surface is *name binding*, not object creation.
- Disjoint slots commute; the same slot is ordered.
- Cross-cluster readers may cache bounded summaries, but those summaries are read-only/non-activating; authoritative attach/detach routes to the owner (see `view-replication-boundary-v0.md`).

### Transcript/receipt append
Non-commutative boundary: **none** (for correctness).
Conflict key: `digest(CH-CONFLICTKEY v0)` with `family="log.eventset"` and payload `{ log_key }` (event-set identity).
Ordering token: **none**. Insert is commutative; canonical export derives order from content-addressed events.
Replication contract: **RC3 commutative merge** (event-set), with **RC4** only by explicit profile decision.
- The log is an event-set; canonical order is derived. Any ordering lock is an implementation choice and should be measured as a perf artifact, not justified as correctness.

### Meter/budget charge
Non-commutative boundary: **issuance (mint/split/grant)**. Replicated `quota` state remains observational only and must not be consulted as remote admission authority, while replicated `budget` state remains owner-routed issuer/lineage metadata only and must not create portable spend authority (see `quota-replication-boundary-v0.md` and `budget-replication-boundary-v0.md`).
Conflict key: spend uses `digest(CH-CONFLICTKEY v0)` with `family="budget.lease"` and payload `{ budget_key }`; mint/revoke uses `family="budget.issuer"` with payload `{ issuer_key }`.
Ordering token: for mint/revoke only: CH-ORDERTOK v0 (family `budget.issuer`) scoped to `digest(CH-CONFLICTKEY v0)` for the issuer conflict key (family `budget.issuer`; `issuer_key` derived per `conflict-key-derivation-registry.md`). Spend uses **no** ordering token and must remain commutative within minted credit.
Replication contract: **Spend: RC3**, **Mint/revoke: RC1**.
- Spending is additive/atomic within minted credit (commutative); issuance must be explicit and transcript-visible.
- Any “free sponsor” path is disallowed unless a profile explicitly declares an exemption (I-METER-3; PO-BUDGET-NOIMPLICIT).

## Wiring + enforcement

- This doc is referenced by `hot-action-surface-v0.md` and D-COMMUTE.
- Replication contract classes are defined in `replication-contracts-v0.md` (D-REPL; CH-REPLCONTRACT v0).
- Lint guardrail: `make lint` runs `tools/check_hot_action_wiring.py` and must fail if this doc is missing or if it omits:
  - a **Non-commutative boundary:** statement for a pinned hot family, and
  - a **Replication contract:** statement for a pinned hot family, and
  - an **Ordering token:** statement for a pinned hot family (CH-ORDERTOK v0 or none), and
  - a **Conflict key:** statement for a pinned hot family (digest(CH-CONFLICTKEY v0)).
