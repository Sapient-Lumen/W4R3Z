# CH-PRESSURE v0 (resource pressure signal schema, informal)

Purpose: a **redaction-safe**, bounded event describing *resource pressure* (D-PRESSURE), suitable for:
- backpressure / adaptive shedding in user space,
- policy hooks (coarse), and
- transcript logging / postmortems (via CH-LOG / IF-OBS).

This schema carries **no authority**. It is observational-only (I-PRESSURE-1).

## Design constraints (v0)
- Canonical decode/encode (I-ENC-1) for hashing/logging.
- Coarse, bounded signal to reduce oracle/side-channel risk (I-PRESSURE-3).
- Scope must be explicit (per-meter subtree or explicit resource container) (I-PRESSURE-2).

## Event shape (v0)

A pressure event `P` contains:
- `schema`: fixed `CH-PRESSURE v0`
- `resource`: closed enum:
  - `mem` (physical memory / reclaim / OOM proximity)
  - `cpu` (runqueue/latency pressure)
  - `io` (block/storage backlog)
  - `net` (egress queue/backlog)
  - `other` (reserved; profile-approved)
- `scope`:
  - `meter_digest` (digest of CH-METER v0 describing the monitored subtree), OR
  - `container_id` (opaque id of a resource container/job; profile-defined)
- `level`: closed enum:
  - `ok` (no meaningful pressure)
  - `some` (partial stalls / reclaim / backlog observed)
  - `full` (near-saturation / severe stalls)
- `window_ms`: u32 (bounded) — observation window for the aggregated signal
- `avg_stall_pct`: u16 (0..10000) — average stall percentage over `window_ms` in **basis points** (optional for some resources)
- `max_stall_pct`: u16 (0..10000) — peak stall percentage over `window_ms` (optional)
- `timestamp` (optional, profile-dependent):
  - `{ monotonic_ms }` (requires D-TIME profile support)

## Delivery notes (non-normative)
- Export should be **per-scope** (not global) and **rate-limited/coalesced**.
- When `level` increases (ok→some→full), emitting an event is favored.
- When pressure decreases, events may be coalesced (avoid spam).

Refs: REF-LINUX-PSI, REF-FUCHSIA-MEMORY-PRESSURE, REF-SYSTEMD-PRESSURE.
