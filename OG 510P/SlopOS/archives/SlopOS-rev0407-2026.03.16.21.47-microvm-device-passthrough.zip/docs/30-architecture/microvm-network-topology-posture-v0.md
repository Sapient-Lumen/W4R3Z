# MicroVM network-topology posture v0 (static guest-visible NIC set; no portable attach/detach plane)

Purpose: pin the **Phase 1** meaning of guest-visible network-interface topology under `ext.microvm` so NIC hotplug, attach/detach, and guest-visible link-state mutation do not quietly become an ambient host↔guest control/status plane.

This doc attaches to **D-MICROVM**, **D-XS**, **D-ACTIVATE**, and **D-NETLEASE** and makes one hard decision explicit:
**Phase 1 fixes guest-visible network-interface inventory/topology at admission; `ext.microvm` adds no portable NIC hotplug / attach-detach / link-state / interface-status plane, and changing guest-visible NIC inventory/topology means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity.**

Entropy cost justification: the archive already pins `ext.microvm` to a declared device set, forbids ambient host channels, fixes guest-visible RAM and CPU shape at admission, and keeps networking authority on explicit `portal.net` / `CH-NETLEASE` seams. What remains underspecified is whether dynamic guest-visible NIC management is part of the reviewed product surface. One narrow posture closes that gap without inventing a new schema family, interface-slot inventory API, or hidden host networking control plane.

## Posture (v0)

1) **Guest-visible network topology is fixed at admission**
   - For Phase 1, each admitted `ext.microvm` leaf runs with **one exact guest-visible network-interface inventory/topology** fixed at admission.
   - Portable semantics do **not** include post-admission guest-visible NIC add/remove, interface attach/detach, or link-state/topology mutation under the same reviewed portable identity.
   - In plain terms: the reviewed contract is “this leaf boots with this guest-visible NIC set/topology”, not “the host may later attach another interface or rewrite link state while the same leaf keeps running”.

2) **No portable NIC hotplug / attach-detach / link-state plane**
   - Phase 1 standardizes **no portable NIC hotplug / attach-detach / link-state / interface-status control plane** under `ext.microvm`.
   - That means no reviewed portable semantics for guest-visible fields or APIs such as **maximum potential interface count**, **hotpluggable network slots**, **present/absent/attached interface state**, **host-driven NIC attach/detach commands**, or **guest-visible link-state / interface-change completion status**.
   - Implementations may internally support such mechanisms, but they are **not** part of the Phase 1 product contract and must not silently become guest-visible reviewed meaning.

3) **Host networking backend policy stays owner-local and must not masquerade as a portable API**
   - Owners/runtimes may still use ordinary host-side backend plumbing, tap placement, NAT/bridge choices, queue steering, or rate-limiter policy locally.
   - What they may **not** do in Phase 1 is turn that owner-local backend policy into a portable guest-visible NIC attach/link-state/status contract for an already admitted leaf.
   - If a deployment cannot honor the fixed guest-visible NIC inventory/topology it admitted, the correct Phase 1 outcomes are to admit a different reviewed leaf/activation or fail closed — not to grow a new portable in-place network-interface mutation meaning by convention.

4) **Changing guest-visible NIC topology is a new admission, not an in-place mutation**
   - If policy wants a different guest-visible NIC inventory/topology, that change is modeled as a **new reviewed admission / activation choice**.
   - It is **not** modeled as mutating a running guest under the same admitted leaf identity.
   - This keeps guest-visible network shape aligned with the already-pinned lineage/resume-class story and with explicit D-NETLEASE authority, instead of creating a second hidden lifecycle/control surface inside `ext.microvm`.

5) **No new network-interface mutation plane is created in Phase 1**
   - Phase 1 adds **no new `CH-*` schema** for NIC attach/detach or link-state state, **no new ACP kind**, and **no new conflict-key family** for guest-visible interface-mutation operations.
   - If a later design wants portable NIC hotplug, admin-link-state workflows, multihoming mutation, or guest-visible interface inventory/status contracts, it must pay a separate RFC-first cost and explicitly state the conflict keys, commutativity rules, serialization boundary, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable NIC hotplug / hot-remove / attach-detach semantics for `ext.microvm`.
- No portable guest-visible interface-slot inventory or link/admin-state API.
- No promise that host-side backend plumbing or rate-limiter policy is forbidden; only that it does **not** become a reviewed guest-visible control plane in Phase 1.
- No in-place “same leaf, different NIC inventory now” lifecycle contract.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-XS, D-ACTIVATE, D-NETLEASE)
- Primary posture:
  - `microvm-profile-posture-v0.md`
- Adjacent postures:
  - `host-guest-channel-posture-v0.md`
  - `microvm-memory-topology-posture-v0.md`
  - `microvm-cpu-topology-posture-v0.md`
  - `network-lease-schema-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-15)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-NETTOPOLOGY)
- Policy posture:
  - guest-visible network-interface mutation adds **no new lane**, **no public attach/detach-or-link-status plane**, and **no portable in-place mutation contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_network_topology_posture.py` fails `make lint` if this posture stops being discoverable, loses its **fixed-at-admission guest-visible NIC topology / no portable NIC-hotplug-or-link-state control plane / no max-interface-or-slot semantics / change NIC topology by new admission not in-place mutation / no new CH-schema or ACP plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-NETIFACE.
- REF-CHYP-HOTPLUG.
- REF-VIRTIO-1.3.
