# View objects (Plan 9-inspired, capability-mediated)

Goal: import the low-hanging fruit from Plan 9 namespaces **without** ambient authority.

## Concept
A **view** is an explicit object that maps *names* to *capabilities*.
- Views are created/modified only via explicit capability-authorized operations.
- Name resolution is a *pure* operation: `resolve(view, name) -> cap | none`.

This replaces implicit global namespaces with explicit, auditable objects.

## Minimal semantics (v0)
- `view.create(parent_view?) -> view_cap`
- `view.bind(view, name, cap)` (requires write authority to the view)
- `view.mount(view, prefix, other_view)` (composition; optional)
- `view.resolve(view, name) -> cap | none` (no fallback to ambient state)

## Invariants
- **I-VIEW-1 (No ambient resolution):** any name→cap mapping used by privileged code must be obtained via an explicit view object.
- **I-VIEW-2 (No implicit amplification):** binding/mounting cannot create authority beyond the capabilities provided (paired with PO-VIEW-NOAMP).

## Why it is worth it
- shrinks "policy toggles" into explicit objects (supports I-IF-1)
- makes observation/export scoping cheaper (IF-OBS can export a redacted view summary)
- treats name-binding as a protection boundary (name resolution mistakes are protection mistakes)

Refs: REF-BISBEY78.

Evidence hooks
- E1: property tests for resolve purity + no fallback
- E2: model-check small view graphs for "no amplification" and "no unintended aliasing" properties


## Phase 1 scope pin

Phase 1 uses view objects as the namespace substrate, but keeps the mutation and interop surfaces deliberately small:
- D-NS v0 posture (single-slot binding; no privileged `open(path)`): `view-namespace-posture-v0.md`.
- D-TRANS v0 posture (view-local translators; explicit attach; no global pathspace): `translator-posture-v0.md`.
- Hybrid replication boundary: owner-routed slot-binding metadata only; replicated summaries do not auto-activate local bindings (`view-replication-boundary-v0.md`).

## v1 ergonomics (deferred)

Per-process namespaces, union/overlay semantics, and service-tree tooling conventions are tracked as v1 work in **RFC-0032**.

Policy: keep any v1 semantics out of the Phase 1 “hot” seams unless accepted via ADR + evidence.
