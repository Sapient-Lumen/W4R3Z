# D-CONSTR sandboxed worker-pool family v0 (first evidence target)

Purpose: resolve RFC-0042's remaining “which real constructor should be the first evidence target?” choice with the **smallest concrete constructor family** that is worth implementing against in Phase 1. This doc does **not** introduce a generic constructor protocol or a new scheduler/control plane. It pins one reusable **family contract** under the existing D-CONSTR / D-CAPSHELL / D-SEAL / D-BUDGET / D-CAPAUD seams.

## Phase-1 choice

1) **First evidence target is the sandboxed worker-pool family**
   - The first concrete D-CONSTR family we standardize for evidence and harnessing is a **sandboxed worker pool**.
   - Reason: it exercises the archive's most reusable authority boundaries without reopening namespace, translator, or microVM-specific policy surfaces.
   - This gives profiles **A/B/D** a common “stamp out bounded workers” story while keeping profile **C** free to stay static.

2) **Each worker instance is launched from one exact CH-EXECPACK v2 digest and one pinned template set**
   - A pool family instance binds one reviewed worker launch closure: a pinned template/artifact set plus one exact `digest(CH-EXECPACK v2)` for the worker process/component image.
   - Phase 1 does **not** define heterogeneous mixed-image pools under one family instance.
   - The constructor may stamp out multiple workers from that one closure, but it does not reinterpret caller prose or late-bound names at instantiation time.

3) **Parameters stay data-only and bounded**
   - The pool parameter object stays **data-only** and replay-friendly.
   - `worker-pool-constructor-invocation-v0.md` now fixes the Phase 1 parameter shape to bounded restart policy plus `pool_size` in `1..64`; the family does **not** accept caller-chosen export-label maps, prose prompts, or capability material in params.
   - `worker-pool-parameter-schema-v0.md` then makes that exact digest target concrete as `CH-WPOOLPARAM v0`: one data-only schema carrying only `pool_size` plus the per-slot restart budget (`restart.max_restarts`, `restart.window_ms`), with automatic replacement disabled exactly when both are `0`.
   - Authority-bearing imports (budgets, routes, lease handles, logging/export sinks, etc.) stay in explicit import slots rather than serialized params.

4) **Authority imports are explicit and pool-local**
   - The family import contract MUST name every authority-bearing input needed to construct the workers.
   - `worker-pool-constructor-invocation-v0.md` fixes the exact slot story: one required `sponsor`, zero or more explicit `worker_seed/<label>` slots, and optional `install_target` when publishing onto an owner-visible seam.
   - `worker-pool-sponsor-surface-v0.md` then fixes what that required sponsor import means: one explicit pool-wide sponsorship root, no ambient payer/session fallback, no sponsor rotation or per-worker sponsor splits, and no sponsor-inventory/admin drift on runtime surfaces.
   - `worker-pool-install-target-surface-v0.md` then fixes what that optional install import means: one publication-only owner-visible target seam, all-or-nothing canonical installation of `pool.control` plus `worker[i]`, and no rename/remap/catalog or duplicate direct-return drift.
   - `worker-pool-seed-surface-v0.md` then fixes what those repeated `worker_seed/<label>` imports actually mean: they bind reviewed worker import labels only, they are uniform across all worker slots, and they do not grow per-worker maps or reseed semantics in Phase 1.
   - Any authority granted to workers (document handles, network leases, local routes, clocks, entropy, device leases) MUST therefore arrive through one of those explicit slots and remain bounded by the worker template contract.
   - No ambient filesystem, PATH/env lookup, service discovery, hostnames, implicit network, or foreign-cell compatibility fallback may enter through the family contract.

5) **The export contract is one pool control handle plus a fixed worker-set surface**
   - The bounded caller-visible result is fixed by `worker-pool-constructor-invocation-v0.md` as:
     - one **pool control handle** named `pool.control`, and
     - one index-stable worker-set surface named `worker[0]` through `worker[pool_size-1]`.
   - `worker-pool-invocation-manifest-v0.md` fixes the exact digest-first object named by that summary's `invocation_manifest_digest`, keeping replay/runtime comparisons on one canonical manifest instead of per-tool prose.
  - `worker-pool-control-surface-v0.md` narrows `pool.control` itself to one bounded `Describe()` summary plus cooperative quiesce mutators only; Phase 1 declines scale/reseed/job/admin verbs on that handle.
  - `worker-pool-describe-summary-v0.md` narrows the exact family-local shape of that `Describe()` result: the top-level field set is closed, `qid` follows one exact presence rule, and `worker_slots` is one ordered gap-free slot table rather than an implementation-defined status tree.
  - `worker-pool-quiesce-state-v0.md` narrows the remaining pool-level quiesce folklore under `Describe()`: `quiesce_state` is closed to `running`, `quiescing`, and `quiescent`; `qid` is absent only in `running`; `quiescent` keeps the active `qid` in force until `EndQuiesce(qid)`; and Phase 1 adds no mixed/partial/mode folklore on the canonical summary surface.
  - `worker-pool-slot-state-v0.md` narrows the remaining summary-state folklore under `Describe()`: `worker_slots[*].state` is closed to `starting`, `running`, `backoff`, `failed`, and `quiescing`; `backoff` is the only temporary-unavailable state; and active quiesce suppresses automatic `backoff -> starting` re-entry until `EndQuiesce(qid)` releases admission again.
  - `worker-pool-restart-budget-v0.md` narrows the remaining operational folklore behind `restart.max_restarts` / `restart.window_ms`: the budget is per-slot, counts only automatic `backoff -> starting` admissions, the initial fresh occupant does not consume budget, disabled budgets fail closed directly to `failed`, and successful occupancy only ages admissions out of the trailing window.
  - `worker-pool-worker-surface-v0.md` narrows each exported `worker[i]` handle to a slot-stable typed entry handle only; Phase 1 declines per-worker admin verbs, raw occupant identity, and transparent live-session continuity promises on that handle.
  - The constructor does **not** export internal helper handles, template fetch authority, bring-up channels, undisclosed supervisor references, or caller-chosen export aliases.
   - Any publication into owner-visible registries, views, names, or portal bindings happens on those target seams explicitly, not as hidden constructor fallout.

6) **Workers are sealed before routine use**
   - The family reuses **D-SEAL**: any init-only imports used to assemble a worker must be dropped before the worker enters routine service.
   - Pool reuse is therefore about repeated construction from a pinned closure, not about retaining ambient bring-up authority inside long-lived workers.

7) **Fresh isolated pool instantiations commute; installs reuse the target seam**
   - A worker-pool constructor invocation **commutes** when it allocates a fresh isolated pool, consumes only its explicit imports, and returns results only through previously unoccupied export slots.
   - Non-commuting cases are explicit: if the caller asks the constructor to install the pool or worker exports into an owner-visible slot/name/export table, serialization lives on that target seam's existing conflict keys and witnesses rather than on a constructor-global key.
   - This family therefore introduces **no pool-global ordering service** and **no new constructor-wide conflict-key family**.

8) **Evidence contract is transcript-bound and cap-graph-checkable**
   - The first implementation/harness target for D-CONSTR MUST emit enough evidence to support **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, and **PO-CONSTR-REPLAY** for this family.
   - The canonical handoff/member-label normal form for that evidence is pinned in `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`; the family does not allow equivalent alternate pack label vocabularies.
   - The exact caller-scoped `capgraph.before` / `capgraph.after` meaning is pinned in `docs/40-verification/worker-pool-capgraph-snapshots-v0.md` as a same-profile `CH-CAPG v0` pair over one shared scope, compared only on the normalized caller-reachable delta over exactly `pool.control` plus `worker[i]`, instead of whole-system or helper-visible graph dumps.
   - The exact install-only `target.before` / `target.after` meaning is pinned in `docs/40-verification/worker-pool-target-projection-v0.md` as a same-key target-seam `CH-SPROJ v0` pair carrying one canonical publication digest over exactly `pool.control` plus `worker[i]`, instead of target-name or inventory folklore.
   - The exact bounded `transcript.slice` layout is pinned in `docs/40-verification/worker-pool-transcript-slice-v0.md` as a case-indexed window set over ordered `CH-LOG v0` references, with stable case ids and `primary` / `swapped` order variants instead of whole-log dumps.
   - The exact compact result layer is pinned in `docs/40-verification/worker-pool-verdict-summary-v0.md`: `verdict.summary` is one stable case-id verdict table over the canonical worker-pool export shape, with explicit `delta_predicate_ok` / `replay_predicate_ok` bits instead of prose-only or flaky/warning result folklore.
   - Minimum transcript/evidence bindings are:
     - worker template/artifact digest set,
     - `digest(CH-EXECPACK v2)` used for the worker closure,
     - parameter-object digest,
     - import-contract digest / export-contract digest,
     - any sponsor/request-context digests used for attribution,
     - cap-graph delta proving that only the declared pool control handle and bounded worker-set exports became caller-reachable.
   - Negative tests should include “no ambient file/network/time/local-IPC acquisition” checks using the existing capshell/compat posture suites where applicable.

## Out of scope in v0

- No autoscaling policy plane, queue-depth feedback controller, or pool-global scheduler API.
- No heterogeneous mixed-image pools under one constructor instance.
- No constructor-specific job/request schema or generic worker-pool receipt schema.
- No hidden publication into registries/views/names/services as part of routine instantiation.
- No ambient worker warm-start state that bypasses the pinned template + exec-pack closure.

## Attachments / wiring

- Decision surface: **D-CONSTR**.
- Reused launch seam: **CH-EXECPACK v2 / D-CAPSHELL**.
- Reused proof hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- Supporting authority boundaries: **D-SEAL**, **D-BUDGET**, **D-CAPMODE**, **D-CAPAUD**.

## References

- `rfcs/0042-constructors-and-confinement-tests.md`.
- `constructor-posture-v0.md`.
- `constructor-boundary-pattern-v0.md`.
- `worker-pool-constructor-invocation-v0.md`.
- `worker-pool-parameter-schema-v0.md`.
- `worker-pool-sponsor-surface-v0.md`.
- `worker-pool-install-target-surface-v0.md`.
- `worker-pool-seed-surface-v0.md`.
- `worker-pool-invocation-manifest-v0.md`.
- `worker-pool-control-surface-v0.md`.
- `worker-pool-slot-state-v0.md`.
- `worker-pool-worker-surface-v0.md`.
- `docs/40-verification/worker-pool-constructor-harness-v0.md`.
- `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`.
- `docs/40-verification/worker-pool-target-projection-v0.md`.
- `docs/40-verification/worker-pool-verdict-summary-v0.md`.
- `capshell-exec-pack-schema-v2.md`.
- `seal-posture-v0.md`.
- `docs/20-assurance/invariant-registry.md` (I-CONSTR-1 / I-CONSTR-2).
- `docs/20-assurance/proof-obligation-registry.md` (PO-CONSTR-CONFINE / PO-CONSTR-REPLAY).
- External inspirations: **REF-KEYKOS-NANOKERNEL**, **REF-EROS-CONFINEMENT**, **REF-FUCHSIA-COMPONENTS**, **REF-FUCHSIA-REALMS**, **REF-GENODE-INIT**, **REF-SHILL-OSDI14**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_family.py` (**EVID-2026-358**).
