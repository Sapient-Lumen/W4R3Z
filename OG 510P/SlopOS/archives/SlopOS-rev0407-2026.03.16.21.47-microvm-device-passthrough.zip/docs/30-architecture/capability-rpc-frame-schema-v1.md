# CH-CAPRPC v1: capability-RPC frame (with optional request-context correlation)

Purpose: v0 frame plus an optional `ctx_digest` hook for correlating calls with **CH-REQCTX** (deadlines/cancellation intent/trace correlation), without changing authority semantics.

This is a **frame**, not an IDL: the `payload` bytes are interpreted according to a pinned interface definition under D-IDL.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown `msg_kind` values reject deterministically.

## Frame

```text
CH-CAPRPC-v1 {
  schema: "CH-CAPRPC";
  version: 1;

  msg_kind: enum { call, return };

  # Correlation
  call_id: u64;                  # chosen by caller; stable within a session

  # Optional correlation hook
  ctx_digest?: bytes32;          # digest of CH-REQCTX v0 canonical bytes (non-authoritative)

  # Target
  target: {
    kind: enum { local_handle, exported_token };
    handle_id?: u64;             # opaque local handle id
    token_digest?: bytes32;      # digest of CH-CAPX/CH-SREF token if used
  };

  method_id: u32;                # method selector (ordinal) within the target interface

  # Payload
  iface_digest: bytes32;         # digest of the pinned interface descriptor (CH-IFACE)
  payload: bytesN;               # bounded; interpreted by IDL

  # Capability attachments
  caps: list<CapRef>;

  # Return fields (for msg_kind=return)
  status?: enum { ok, err };
  err_code?: u32;                # stable error taxonomy for replay/logging
}

CapRef {
  kind: enum { handle, export };
  handle_id?: u64;
  token_digest?: bytes32;
  rights_hint?: u32;             # optional; non-authoritative; for diagnostics only
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `ctx_digest` (if present) must be 32 bytes.
- `iface_digest` is mandatory and must be 32 bytes.
- `payload` length ≤ 4096 bytes (default bound; profile may lower).
- `caps` length ≤ 64 (default bound; profile may lower).
- For `msg_kind=call`, `status/err_code` must be absent.
- For `msg_kind=return`, `status` must be present.

## Notes
- `ctx_digest` is **informational only**: it must not affect authorization, routing, or method dispatch.
- Services and tooling MAY include `ctx_digest` in CH-LOG transcripts and diagnostic bundles to help explain cancellations/timeouts.
- Cancellation mechanics (signals, deadlines, budgets) are outside the frame; they live in request-context conventions and/or interface payloads (see RFC-0105, RFC-0026).
- Live-session posture is pinned in `caprpc-session-posture-v0.md`: live refs remain connection-specific, session-scoped runtime state; disconnect is fail-stop; continuity requires explicit bootstrap/introducer capability or explicit CH-CAPX / CH-SREF import/restore; and there is no public session/object inventory or transparent resume surface.
- Promise/result handles and pipelining posture are pinned in `caprpc-promise-posture-v0.md`: caller-local, session-scoped, one-shot, capability-result-only for pipelining, and never an exportable inventory/admin surface.
- Oneway posture is pinned in `caprpc-oneway-posture-v0.md`: Phase 1 keeps **CH-CAPRPC** at `call | return` only, represents oneway as an interface-marked `call` with no permitted `return`, caps oneway payloads at **`<= 256 bytes`**, requires **zero capability attachments**, and declines any durable mailbox/admin surface.
