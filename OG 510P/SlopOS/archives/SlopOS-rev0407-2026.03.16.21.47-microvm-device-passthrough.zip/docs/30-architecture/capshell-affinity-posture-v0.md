# Capshell launch CPU-affinity / placement posture v0 (no inherited affinity baseline)

Purpose: keep **D-CAPSHELL** honest when workflows launch tools whose behavior depends on inherited
CPU **affinity / placement state**: narrowed affinity masks, wrapper-selected CPU subsets, or
service-manager placement defaults carried across the runner/wrapper boundary. The archive already
says execution context is explicit and reviewable, but that promise still drifts if the child
launch quietly inherits parent/login-shell/session affinity posture that never appears in the
reviewed execution pack.

This adjunct closes that seam. It is intentionally narrow: it does **not** invent a generic CPU
placement API, a reviewed descriptor for arbitrary affinity masks, or a hardware-topology planner.
It only freezes the minimum Phase 1 posture needed so launch behavior stops depending on hidden
shell/session/wrapper CPU-affinity state across all four product shapes.

## Posture (v0)

1) **No inherited shell/session CPU-affinity baseline in Phase 1**
   - `capshell.exec` MUST NOT inherit CPU-affinity / placement state merely because the parent
     shell, wrapper, login profile, service manager, or host session already had it.
   - Ambient launch state includes inherited `taskset` / `sched_setaffinity()` masks, inherited
     service-manager `CPUAffinity=` defaults, inherited Job Object / process-affinity masks, and
     equivalent wrapper-selected CPU subsets that never appear in the reviewed execution pack.

2) **Phase 1 adds no reviewed per-step CPU-affinity / placement surface**
   - Phase 1 introduces no reviewed affinity-mask descriptor family, no `capshell.affinity.*`
     ACP/admin family, and no per-step workflow knobs for CPU masks, processor groups, cpusets,
     preferred NUMA nodes, or cluster/placement hints.
   - The portable seam is therefore: **do not carry launcher/session CPU-affinity state across the
     reviewed boundary**.
   - If a runtime/provider wants fixed placement ceilings for a deployment class, that remains local
     implementation policy and MUST be independent of parent shell/session state.

3) **Launch normalizes CPU eligibility at the boundary**
   - Before `exec` (or via equivalent spawn attributes), the runner/wrapper MUST start the child on
     the platform's **default eligible CPU set for the active execution compartment** rather than on
     a parent-inherited narrowed subset.
   - On POSIX-like hosts, that means undoing inherited `taskset` / `sched_setaffinity()` narrowing
     when the runtime can recover the compartment's default eligible CPU set.
   - On service-managed or hosted runtimes, the portable promise is the same but scoped to the
     runtime's own envelope: the child launches on the default CPU set ordinarily assigned to that
     VM/cell/container/service, not on an extra shell/session/wrapper narrowing layered on top.
   - Launch MUST NOT preserve inherited one-off CPU subset pinning from the parent shell/session,
     wrapper, or desktop/service-manager process.
   - Compat/foreign-cell membranes that cannot guarantee that normalized launch posture MUST fail
     closed rather than preserving host defaults.

4) **Programs may still manage their own affinity after launch**
   - This posture constrains the **runner/front-end launch boundary**, not the semantics of an
     explicitly chosen shell/interpreter/program after it begins running.
   - If an explicitly selected tool later adjusts its own affinity or placement inside reviewed
     program logic, that behavior belongs to the chosen program/runtime rather than to ambient
     launch state.

5) **Other explicit seams do not secretly mint or repair affinity state**
   - **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**, and **CH-REQCTX v1** do not
     authorize synthesizing or translating parent shell/session affinity state into the child.
   - **CH-HWFACT v0**, **CH-CLUSTERMAP v0**, and locality/cache facts remain observational and MUST
     NOT silently become launch placement selectors.
   - Adjacent automation conveniences (learn mode, wrapper-first adoption, session startup hooks,
     interrupt UX, or terminal/session UX) MUST NOT become hidden carriers for inherited CPU masks
     or placement bias.

6) **No new workflow / ACP / admin surface**
   - Phase 1 introduces no portable CPU-affinity descriptor family, no policy knob for varying
     launch placement per workflow step, and no admin query surface for “what inherited CPU mask was
     applied?”
   - If later evidence shows real need for reviewed launch-time affinity control, that work must
     return as **one new explicit decision surface** rather than by silently inheriting shell state.

7) **Commutativity and ordering stay on `capshell.exec`**
   - This posture does not mint a new externally visible action family.
   - Conflict keys, commutativity stance, ordering witnesses, serialization boundary, and retry
     evidence remain the ones already declared for `capshell.exec` (`domain.id`, ordered within a
     domain, `svc:IF-CAPSHELL`).
   - The only Phase 1 change is that launch behavior no longer depends on hidden parent/session CPU
     masks or placement bias.

8) **Sealed compat remains killable and non-ambient**
   - Compat membranes MUST NOT expose inherited host/session CPU-affinity state as a hidden side
     channel around the reviewed execution pack.
   - If a foreign runtime cannot bypass login-shell/session/service-manager affinity carry-over or
     cannot normalize the child to the default eligible CPU set for its compartment, it MUST fail
     closed.

## Phase 1 non-goals (explicitly deferred)

- No portable CPU-affinity schema or per-step placement descriptor in Phase 1.
- No portable guarantee about exact host CPU inventory, processor groups, cpuset composition, or
  NUMA-node/cluster placement.
- No automatic derivation from `CH-HWFACT` / `CH-CLUSTERMAP` locality facts into launch authority.
- No compatibility table translating legacy `taskset`, `CPUAffinity=`, cpuset, or Job Object
  affinity settings into D-CAPSHELL policy.

## Wiring

- Decision surface: D-CAPSHELL in `docs/30-architecture/decision-map.md`.
- Primary launch seam: `capshell-exec-pack-schema-v2.md` (**CH-EXECPACK v2**).
- Existing adjacent seams:
  - `capshell-scheduling-posture-v0.md`
  - `capshell-personality-posture-v0.md`
  - `capshell-peer-inspection-posture-v0.md`
  - `rfcs/0115-capability-safe-shell-and-automation.md`
- Assurance anchors:
  - `I-CAPSHELL-AFFINITY-1` in `docs/20-assurance/invariant-registry.md`
  - `PO-CAPSHELL-AFFINITY-BASELINE` in `docs/20-assurance/proof-obligation-registry.md`
- Engineering surface:
  - `docs/60-engineering/cli-plumbing-tooling.md`
- Discovery surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/llm-runbook.md`
- CI drift gate: `tools/check_capshell_affinity_posture.py` (**EVID-2026-347**).

## References

- REF-MAN7-SCHED-AFFINITY
- REF-MAN7-TASKSET
- REF-MAN7-SYSTEMD-SYSTEM-CONF
- REF-MS-SETPROCESSAFFINITYMASK
