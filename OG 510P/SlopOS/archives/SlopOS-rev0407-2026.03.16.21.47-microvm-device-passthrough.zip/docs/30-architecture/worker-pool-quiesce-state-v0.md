# Worker-pool quiesce-state v0 (exact `quiesce_state` meaning)

Purpose: pin an implementable Phase 1 meaning for the pool-level `quiesce_state` field inside the first concrete **D-CONSTR** worker-pool summary so `pool.control.Describe()`, slot-state reporting, and cooperative maintenance evidence do not drift into equivalent-but-different pool lifecycle folklore.
This doc narrows one already-chosen family-local seam: **`quiesce_state` is a small observational summary token set, not a second lifecycle API, scheduler state machine, or inventory/status tree**.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-QUIESCE**, **D-COMMUTE**, **D-CAPAUD**
- assumes the exact exported `pool.control` contract is already fixed by `worker-pool-control-surface-v0.md`
- assumes the exact `Describe()` result shape is already fixed by `worker-pool-describe-summary-v0.md`
- assumes the exact `worker_slots[*].state` meaning is already fixed by `worker-pool-slot-state-v0.md`
- assumes the portable D-QUIESCE state machine is already fixed by `quiesce-posture-v0.md`
- does **not** introduce a generic quiesce schema, a watch/list API, or any new mutator beyond `BeginQuiesce(mode)` / `EndQuiesce(qid)`

## Phase-1 choice

1) **`quiesce_state` is a small closed pool-level observation vocabulary, not a second lifecycle API**
   - The exact Phase 1 pool-level `quiesce_state` set is `{running, quiescing, quiescent}`.
   - `pool.control.Describe()` reports exactly one member of that closed set for the current pool instance.
   - Phase 1 adds no `idle`, `paused`, `draining`, `partially_quiescent`, `frozen`, `canceling`, `maintenance_pending`, or host-runtime-specific state names on the canonical summary surface.

2) **`running` means there is no active quiesce epoch for this pool instance**
   - `quiesce_state = running` means the pool is in ordinary admission mode and there is no active `qid` for this pool instance.
   - In this state, `qid` MUST be absent from the canonical `Describe()` result.
   - When `quiesce_state = running`, no slot MAY report `quiescing` in `worker_slots[*].state`.

3) **`quiescing` means one active `qid` is gating new work, but the pool has not yet reached full drain/cancel completion**
   - `quiesce_state = quiescing` means one active `qid` exists, `BeginQuiesce(mode)` has already taken effect, and new externally triggered work is being rejected according to `quiesce-posture-v0.md`.
   - In this state, `qid` MUST be present exactly once in the canonical `Describe()` result.
   - `quiescing` does **not** expose queue depth, remaining in-flight request counts, per-slot drain timers, or a hidden mode/result bag on the portable summary surface.

4) **`quiescent` means one active `qid` still exists and externally triggered work remains gated, but the pool has reached the drained/canceled steady point**
   - `quiesce_state = quiescent` means the active `qid` is still in force and the pool has completed the cooperative drain/cancel objective for the chosen mode.
   - In this state, `qid` MUST be present exactly once in the canonical `Describe()` result.
   - Returning from `quiescent` to ordinary admission requires `EndQuiesce(qid)`; Phase 1 adds no implicit timeout expiry, no auto-resume, and no hidden maintenance-complete ack path.

5) **The relation to slot states is exact and intentionally small**
   - If `quiesce_state = running`, every slot state MUST be drawn from `{starting, running, backoff, failed}`.
   - If `quiesce_state = quiescing`, at least one slot MAY report `quiescing`, and any remaining non-terminal slots MAY still report `running` or `starting` while the drain/cancel boundary is in progress.
   - If `quiesce_state = quiescent`, every slot that is neither `backoff` nor `failed` MUST report `quiescing`.
   - Phase 1 therefore adds no pool-level `mixed` / `partial` / `degraded` token and no extra per-slot `quiescent` token just to mirror in-progress drain conditions.

6) **`quiesce_state` is observational and does not smuggle mode or authority**
   - `quiesce_state` is summary data only; it does not replace the explicit control authority required for `BeginQuiesce(mode)` / `EndQuiesce(qid)`.
   - The canonical summary does **not** expose the current quiesce `mode`, control-handle identity, caller identity, sponsor identity, or raw capability material.
   - Any richer maintenance telemetry remains on explicit evidence/log/inspection seams rather than hitchhiking on one summary token.

7) **Commutativity and serialization stay where they already live**
   - Reporting `quiesce_state` remains observational-only and therefore **commutes** with all other actions on this family.
   - `BeginQuiesce(mode)` / `EndQuiesce(qid)` remain intentionally **non-commutative** with each other and with new work admission on the same pool instance; serialization still lives on the pool-control seam, not in a new quiesce-summary sequencing surface.
   - The exact `quiesce_state` token set therefore does not create a new conflict-key family or a second maintenance protocol.

8) **Sealed compat remains honest**
   - Hosted or compat implementations MAY derive `quiesce_state` from richer host/runtime lifecycle state behind the membrane.
   - The portable surface still remains the exact closed token set above with the same `qid` rule and the same relation to `worker_slots[*].state`.
   - If an implementation cannot preserve that narrow contract without ambient side channels or host-specific extension keys, it must fail closed or keep that widening non-portable and policy-killable.

## Out of scope in v0

- Any additional pool-level `quiesce_state` tokens beyond `running`, `quiescing`, and `quiescent`.
- Exposing the active quiesce `mode` or progress counters on the canonical summary surface.
- A watch/list/stream API for quiesce-state changes.
- Per-slot `quiescent` mirroring or pool-level `mixed` / `partial` / `degraded` lifecycle tokens.
- Any claim that `quiescent` itself implies checkpointability, migration safety, or durable export readiness.

## Wiring

- Decision surface: **D-CONSTR**.
- Adjacent seams: `worker-pool-control-surface-v0.md`, `worker-pool-describe-summary-v0.md`, `worker-pool-slot-state-v0.md`, `worker-pool-worker-surface-v0.md`, `quiesce-posture-v0.md`.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-SYSTEMD-SERVICE**, **REF-FUCHSIA-RUNNER-STOP**, **REF-ERLANG-OTP-PRINCIPLES**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_quiesce_state.py` (**EVID-2026-375**).
