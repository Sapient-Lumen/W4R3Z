# Budget replication boundary v0

Purpose: narrow **OQ-0001** by pinning what `object_family = budget` is allowed to mean under Hybrid and RC1.

This doc closes the last remaining replication-family ambiguity around spend authority. SlopOS already split the story in two:

- `quota` is the **observational/additive spend-summary** lane, and
- `budget` is the **authoritative issuer / credit-placement** lane.

Hybrid needs one more hard boundary so replicated `budget` metadata cannot quietly turn into portable spend authority, remote sponsorship, or a distributed mint service.

## Decision (v0)

### 1) `budget` means owner-routed issuer / lease-lineage metadata only

When CH-REPLCONTRACT uses `object_family = budget`, the replicated object is the owner-routed metadata needed to describe authoritative budget issuance state, for example:

- issuer / owner identity for a budget lineage (`meter_id`, issuer cluster)
- lineage metadata that says which local budget lease was minted/split from which parent
- bounded revocation / closure / expiry status summaries
- descriptor digests or epochs needed for routing, audit, or stale-cache rejection

What it is **not** in v0:

- a portable budget capability,
- a replicated pool of spendable credit,
- a "look at the replica and spend" admission oracle, or
- a second path for recreating payer authority without the owner.

### 2) Authoritative mutations stay at the owner/issuer seam

Anything that changes spendable credit placement or validity remains an **owner-routed mutation** on the authoritative issuer seam:

- `mint`
- `split` / `grant`
- `revoke`
- `close`
- any future credit rebalance / transfer across clusters

Those operations are the non-commutative boundary. They remain explicitly serialized per issuer (`budget.issuer`) rather than inferred from replicated state.

### 3) Non-owner replicas may cache metadata, but they cannot create local spend authority

A non-owner cluster MAY cache bounded read-only `budget` metadata to:

- route a request to the correct issuer,
- explain why a lease is stale/revoked/expired,
- correlate receipts/transcripts with budget lineage, or
- support owner-visible audit/reconciliation.

A non-owner replica MUST NOT, by itself:

- mint a new local budget lease,
- widen a lease limit/scope/expiry,
- infer unspent credit from cached lineage metadata,
- accept a CH-BUDGET descriptor digest as spend authority without a corresponding explicit local payer object, or
- resurrect a revoked/exhausted/expired lease because a stale replica still mentions it.

### 4) `budget` remains distinct from `quota`

`quota` remains the RC3 observational summary lane for charges already accepted under local explicit credit (`quota-replication-boundary-v0.md`).

`budget` remains the RC1 authoritative issuance lane for where spendable credit lives and who may mint/split/revoke it.

Do not collapse these back together. If later phases need portable cross-cluster spend rights, they must pay for a **new RFC-first transfer/import surface** with its own invariants and evidence, not reinterpret replicated `budget` metadata into authority.

## Why this is the right boundary

Escrow-style systems only avoid coordination by making rights **explicitly allocated and transferred**; the replicated summary is not enough by itself (`REF-ESCROW-TODS86`, `REF-BOUNDED-COUNTER-SRDS15`, `REF-CRDT-INRIA11`). SlopOS already has the right authority substrate for that discipline:

- explicit payer objects,
- CH-BUDGET as a redaction-safe descriptor rather than a bearer token,
- and explicit owner-visible mint/split/revoke boundaries.

That keeps all four product shapes honest:

- **A secure workstation** avoids hidden remote sponsorship or background budget borrowing.
- **B cloud substrate** keeps issuer state owner-routed while still allowing cheap replicated audit/routing metadata.
- **C appliance/separation** keeps the default local-only/simple posture intact.
- **D agent/automation OS** lets planners reason over budget lineage and receipts without accidentally acquiring spending authority from replicated metadata.

## Required wiring

- `replication-contracts-v0.md`
- `replication-object-family-registry.md`
- `profile-repl-defaults.md`
- `hot-action-surface-v0.md`
- `hot-action-boundaries-v0.md`
- `budget-lease-schema-v0.md`
- `rfcs/0058-operation-scoped-budget-leases.md`
- `decision-map.md`
- `trajectory-map.md`

## Guardrail

CI must fail if the archive stops saying that `budget` replication is **owner-routed issuer / lineage metadata only**, or if the core replication/budget docs stop linking this boundary.

Evidence: `EVID-2026-266`.

Tool: `tools/check_budget_replication_boundary.py`.
