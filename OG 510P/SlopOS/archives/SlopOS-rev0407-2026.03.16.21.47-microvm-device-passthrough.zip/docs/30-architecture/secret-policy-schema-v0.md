# CH-SECRETPOL v0: Secret usage policy descriptor

Purpose: a redaction-safe description of **how a secret may be used** (D-VAULT).  
This schema carries **no secret bytes**; it exists to make secret release/export policies reviewable, lintable, and enforceable.

Refs: REF-PLAN9-SECSTORE, REF-APPLE-KEYCHAIN, REF-ANDROID-KEYSTORE, REF-SECRET-SERVICE-SPEC.

V0 posture note: `vault-posture-v0.md` pins D-VAULT as a **ref-bound, provider-owned, non-inventory** seam.
CH-SECRETPOL describes what one referenced secret may do; it is not an app-visible search / collection / inventory protocol.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-SECRETPOL v0 := {
  v: 0,

  ; allowed operation kinds (closed enum)
  ops: [ tstr ],                ; e.g., ["read", "wrap", "rotate", "delete"]

  ; purpose/context tags to prevent “credential confused deputy” misuse
  ; (clients must supply exactly one context string on each op when contexts is present)
  contexts?: [ tstr ],          ; e.g., ["oauth_refresh", "disk_unlock", "recovery", "update_fetch"]

  ; evidence requirements (all enforced by the provider; user space)
  require?: {
    authz?: bool,               ; require CH-AUTHZ bound to the action digest
    volition?: bool,            ; require CH-VOL (trusted UI gesture) for each op
    explain?: bool,             ; require CH-CAPDIFF/receipt binding (D-EXPLAIN) when volition is used
    attest?: bool,              ; require an attestation gate in D-CC profiles (provider-defined)
    rollback_guard?: tstr,      ; "none" | "capstore_tip" | "monotonic_counter" (profile-defined)
  },

  ; provider-enforced hints/policies
  confirm?: bool,               ; require explicit per-op confirmation (UI/root)
  rate?: {
    max_per_min?: uint,
    burst?: uint,
  },

  ; size and class metadata (public; non-authoritative unless enforced)
  max_len?: uint,               ; maximum plaintext length for `read` (if permitted)
  class?: tstr,                 ; "user_cred" | "device_secret" | "recovery" | "token" | ...

  note?: tstr,                  ; non-authoritative human note
}

## Validation notes
- `ops` MUST be non-empty and use the closed enum.
- If `contexts` is present, it MUST be non-empty; providers MUST fail closed on unknown contexts.
- `require.rollback_guard` MUST use the closed enum; semantics are profile-defined and must be documented where enabled.
- Providers SHOULD treat `confirm` as *enforced*, not advisory, when present.

## Integration hooks
- D-LEASE: secret handles may be wrapped in lease proxies (temporary authority by default).
- D-PERSIST: policies and references are persisted (CH-SECRETREF), not raw secret bytes.
- D-CC: in confidential-computing profiles, `require.attest=true` indicates “do not release unless platform evidence binds to our boot digest” (see RFC-0064).

