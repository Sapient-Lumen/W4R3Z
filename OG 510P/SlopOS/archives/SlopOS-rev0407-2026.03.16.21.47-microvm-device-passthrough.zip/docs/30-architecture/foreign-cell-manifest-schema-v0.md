# CH-FCELL v0 (Foreign Cell manifest, informal)

Purpose: a bounded, non-authoritative manifest describing a foreign compatibility cell to be launched by policy.
It is used for validation, receipts, drift-gates, and auditability.

This schema **does not contain capability material**. It can only reference already-issued handles (by digest or opaque id).

## Non-authoritative by construction

CH-FCELL cannot grant authority. The launcher/validator must ensure:

- referenced handles exist and are authorized for the launcher,
- all requested portal lanes are enabled by CH-CFG lane gates + policy (missing/unknown lane toggles treated as disabled; fail closed),
- unknown/unsupported fields are rejected (fail closed),
- the ABI surface is closed (PO-COMPAT-CLOSESET).

## Shape

```
schema: "CH-FCELL"
version: 0

cell_id: <digest_bstr>      # digest-sized bstr of length hashlen (D-TYPEDID; see typed-id-contract-v0.md)
profile: <closed enum>  # workstation | cloud | embedded | agent | bootstrap

runtime:
  kind: <closed enum>    # rump (v0) | reserved (others rejected; see D-RUMPK posture)
  abi: <closed enum>     # posix | linux | bsd | wasi_like | custom
  abi_surface:
    allow: [<abi_op_id>...]   # closed-set list, optional if profile provides a named preset
    deny:  [<abi_op_id>...]   # deny wins

resources:
  budgets:
    cpu: <meter_or_budget_ref>
    mem: <meter_or_budget_ref>
    io:  <meter_or_budget_ref>
  views: [<view_ref>...]      # pre-attached view handles (no raw paths)
  documents: [<docref_digest>...]
  net: [<netlease_digest>...]
  clocks: [<clock_digest>...]
  entropy: [<entropy_digest>...]
  devices: [<iolease_digest>...]

interop:
  portals_allowed: [<portal_token>...]  # closed enum; unknown tokens rejected (see v0 seeds below)
  adapters:
    enabled: [<adapter_kind>...]        # e.g., posix.open_via_doc_portal
    deny:    [<adapter_kind>...]

observability:
  transcript:
    required: true|false
    redaction_profile: <closed enum>
  receipts:
    required: true|false

meta:
  created_at: <timestamp>
  expires_at: <timestamp>
  policy_digest: <digest>              # binds expected policy lane
  notes: <bounded string>
```

## Closed enums (v0 seeds)

- `profile`: `workstation | cloud | embedded | agent | bootstrap`
- `runtime.kind`: `rump` (v0). Other names remain **reserved** and MUST be rejected by v0 validators unless a later RFC explicitly expands D-RUMPK (see `rumpk-selection-posture-v0.md`).
- `runtime.abi`: `posix | linux | bsd | wasi_like | custom`
- `portal_token` (v0): the closed set of CH-PLEDGE portal tokens (mirrors `portal-family-registry.md`; drift-gated). Example tokens: `portal.file`, `portal.net`, `portal.clock`.
- `adapter_kind` (seed): canonical closed set in `fcell-adapter-kind-registry.md` (v0 seed: `posix.open_via_doc_portal | posix.socket_via_net_portal`)
- `redaction_profile`: `none | minimal | incident_bundle`

## Validation obligations (v0)

- Reject unknown keys/enum variants.
- Enforce D-RUMPK v0 posture: `runtime.kind` MUST be `rump` (fail closed on any other value, even if listed as reserved).
- Enforce typed id posture: `cell_id` MUST be a digest-sized `bstr` of length `hashlen` (D-TYPEDID; see `typed-id-contract-v0.md`).
- Enforce bounded list sizes and bounded strings.
- Enforce `deny` precedence where both allow/deny lists exist.
- If `interop.portals_allowed` is non-empty, require the corresponding portal lane kill switches to be enabled in the active config/policy (e.g., `portal.file` ⇒ `cfg.params.lane.portal.file`; `portal.net` ⇒ `cfg.params.lane.portal.net`); missing toggles are treated as disabled (PO-LANE-KILL; I-PORTAL-KILL-1).
- Enforce that references are identifiers/digests only (no embedded payload bytes).
- If `observability.transcript.required` is true, require CH-LOG support in the profile.
- If `runtime.abi_surface.allow` is present, it is the closed set; otherwise profile presets define it.
- If `interop.adapters.enabled` is non-empty, require each enabled adapter kind to pass **adapter-lane** gating in addition to portal-lane gating: `cfg.params.lane.fcell=true` and `cfg.params.lane.fcell.adapter.<adapter_kind>=true` (normalize `.` → `_`). Missing/unknown toggle values MUST be treated as disabled (fail closed; PO-LANE-KILL).
- If `interop.adapters.enabled` is non-empty, the compat supervisor MUST emit per-op CH-FADAPT receipts (v0 or v1) for adapter-mediated host effects (ALLOW/DENY), binding `portal_token` + issued descriptor digests; absence of receipts is treated as a policy violation (PO-FADAPT-EMIT).

## Notes

- CH-FCELL is intended to be referenced from a policy bundle (CH-POLICY) or a boot/config lane (CH-CFG/CH-BOOT) and validated before launch.
- A future version may add a `repl_contract` field to declare cross-cluster placement expectations for foreign-cell supervisors (but never for ambient effects).
