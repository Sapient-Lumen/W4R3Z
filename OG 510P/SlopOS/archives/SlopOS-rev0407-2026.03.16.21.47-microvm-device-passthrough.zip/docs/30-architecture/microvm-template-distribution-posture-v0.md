# MicroVM template distribution posture v0 (warm-state leaves stay owner-local accelerators)

Purpose: pin the **Phase 1** distribution boundary for `ext.microvm` warm-state artifacts so fast-start work does not quietly create a portable publish/import/share format for resumed memory images.

This doc attaches to **D-MICROVM**, **D-EPHEM**, **D-INITSNAP**, **D-CHKPT**, and **D-ATOMICUPD** and makes one hard decision explicit:
**reusable warm-start template leaves and owner-local recovery checkpoints stay owner-local admission accelerators; portable distribution ships cold parent lineage and cuts warm leaves locally.**

Entropy cost justification: the archive already says reusable templates are parent-bound leaves, exact resumed leaf identity stays on owner-local admission evidence, and post-secret checkpoints are owner-local recovery artifacts rather than fan-out bases. What remains underspecified is whether those warm-state artifacts themselves are allowed to become a **portable/public artifact class**. One narrow posture closes that gap without inventing a new schema family, artifact registry, or warm-state import/export plane.

## Posture (v0)

1) **Warm-state leaves are owner-local admission accelerators**
   - Phase 1 literally pins reusable warm-start template leaves and owner-local recovery checkpoints as **owner-local admission accelerators**.
   - They may exist inside one deployment owner's runtime/control plane as cached, encrypted, or otherwise admission-governed artifacts.
   - The portable contract is therefore about **admitting one locally controlled warm artifact under an already reviewed parent lineage**, not about sharing a universal warm-state blob format.

2) **Portable distribution happens at the cold parent lineage, not at the warm leaf**
   - If a product wants to publish, mirror, replicate, or hand off an execution lineage across owners/environments, Phase 1 distributes the **cold parent lineage** — for example `CH-BOOT`, `CH-INIT`, ordinary code/config digests, or other already-reviewed deployment artifacts.
   - Each owner/runtime then cuts and admits its own reusable warm-start leaf locally under the already-pinned template-cut, lineage, and resume-class rules.
   - `ext.microvm` therefore adds **no portable published warm-leaf bundle** and **no cross-owner warm-state handoff contract** in Phase 1.

3) **Provider-local caching/encryption is compatible, not a public artifact surface**
   - Host/VMM-managed snapshot files may be trusted deployment inputs and may be cached/encrypted by the owning service locally.
   - That local lifecycle does **not** imply that reusable warm-state bytes become a public package format, a cross-owner exchange object, or a generally shareable artifact class.
   - In plain terms: “the platform stores encrypted cached snapshots for its own service” is compatible with this posture; “therefore warm-state leaves are a portable release artifact” is not.

4) **Owner-local recovery checkpoints remain owner-local by default**
   - A checkpoint taken after secret ingress, live imported authority, or ordinary execution may still be valuable for one owner's crash recovery / rollback / debugging path.
   - In Phase 1, that does **not** promote it into a publication-grade deployable artifact, a cross-owner migration primitive, or a portable warm-state import story.
   - Any broader export/import/distribution semantics for such checkpoints must pay an explicit RFC-first cost rather than inheriting legitimacy from “snapshot support exists”.

5) **No new warm-state artifact plane is created**
   - Phase 1 adds **no new `CH-*` schema** for warm-leaf publication/import, **no new ACP kind**, **no new conflict-key family**, and **no generic warm-state artifact registry/catalog**.
   - If a later design wants portable warm-state bundle exchange, replicated warm-leaf catalogs, or cross-owner checkpoint publication semantics, it must define explicit schema, ordering/commutativity stance, admission policy, and evidence hooks.

## Phase 1 non-goals (explicitly deferred)

- No portable published warm-leaf or checkpoint-bundle format under `ext.microvm`.
- No generic warm-state marketplace / registry / shared-cache protocol.
- No cross-owner warm-state import promise.
- No claim that provider-local caching/encryption of warm-state artifacts is forbidden.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-MICROVM, D-EPHEM, D-INITSNAP, D-CHKPT, D-ATOMICUPD)
- Adjacent postures:
  - `microvm-template-snapshot-cut-posture-v0.md`
  - `microvm-template-lineage-posture-v0.md`
  - `microvm-resume-admission-evidence-posture-v0.md`
  - `microvm-template-availability-posture-v0.md`
  - `disposable-domain-posture-v0.md`
  - `docs/60-engineering/system-generation-pipeline.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-MICROVM-11)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-MICROVM-TEMPLATE-DISTRIBUTION)
- Policy posture:
  - warm-state artifact distribution adds **no new lane**, **no new public artifact plane**, and **no cross-owner warm-state import contract** in Phase 1.

CI drift gate:
- `tools/check_microvm_template_distribution_posture.py` fails `make lint` if this posture stops being discoverable, loses its **owner-local admission accelerators / distribute cold parents not warm leaves / provider-local caching is not a public artifact surface / no new CH-schema or registry plane** constraints, or drops its assurance/reference wiring.

## References

- REF-FIRECRACKER-SNAPSHOT-SUPPORT.
- REF-AWS-SNAPSTART-SECURITY.
- REF-AWS-LAMBDA-RUNTIME-ENV.
- REF-AWS-SNAPSTART-UNIQUENESS.
