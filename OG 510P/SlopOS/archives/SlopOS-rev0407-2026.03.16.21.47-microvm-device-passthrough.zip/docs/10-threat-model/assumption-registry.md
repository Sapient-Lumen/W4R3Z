# Assumption registry (A-IDs)

Assumptions are explicit prerequisites for claims. They are *not* “obvious truths”; they are commitments we must validate, constrain, or mitigate.

## Hardware / ISA
- **A-HW-1**: CPU implements documented privilege/virtualization semantics (platform-specific annexes may refine).
- **A-HW-2**: memory model/atomic semantics match the assumptions of our concurrency strategy (if any).
- **A-CHERI-1 (optional)**: if a CHERI-enabled platform profile is used, the hardware enforces capability provenance/permissions per the chosen CHERI ABI and our software model reflects those semantics (no “ambient pointer” fallbacks).

## Boot / update
- **A-BOOT-1**: boot chain provides either verified boot or measured boot (deployment-profile-specific).
- **A-BOOT-2**: secure time/monotonic counters (or equivalent) are available if anti-rollback is claimed.

## DMA / devices
- **A-DMA-1**: DMA is mediated by an IOMMU with enforced policy **or** devices are explicitly treated as trusted/TCB (claim scope changes accordingly).

## Toolchain / proofs
- **A-TOOL-1**: verification toolchain soundness assumptions are documented (e.g., solver trust), with mitigations where possible (replay/certificates/diverse checking).
- **A-TOOL-2 (optional)**: compiler/toolchain used to build trusted artifacts corresponds to its source (no “trusting trust” subversion), *unless mitigated* via D-DDC and/or D-BOOTSTRAP posture (RFC-0061).

## Confidential computing (optional)
- **A-CC-1**: the chosen confidential-computing (CC) technology’s isolation + attestation semantics (firmware/module, keys, measurement chain, and endorsement distribution) match the documented model for the selected deployment profile (D-CC).
  - Includes: correctness of the measurement/root-of-trust chain for the chosen substrate (e.g., SEV-SNP / TDX / CCA) and the verifier's trust anchors for endorsements.
  - Excludes by default: microarchitectural side channels, local physical attacks beyond the stated profile, and post-boot compromise of guest software (unless separately modeled).
  - Operational note: CC evidence must be bound to our own CH-BOOT digest (RFC-0064) to avoid “verified the wrong thing” failures.

## Operational environment
- **A-OPS-1**: physical attacker scope is defined by deployment profile (tamper resistance not assumed by default).

## Device attestation (optional)
- **A-ATTEST-1 (optional)**: the chosen hardware root-of-trust (e.g., DICE/TPM/TEE) protects the attestation signing key(s) from extraction/forgery within the declared physical attacker scope; compromising the key requires compromising immutable ROM/firmware per the platform’s threat model.
- **A-ATTEST-2 (optional)**: if freshness is claimed, the challenge/nonce channel between verifier and device is integrity-protected and the verifier’s replay window/nonce policy is enforced.
