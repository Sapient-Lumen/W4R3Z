# Deployment profiles (scope knobs)

Purpose: constrain claims by explicitly choosing operational assumptions. A claim must name its profile(s) or list the A-IDs it needs.

## Profile P0: Dev/Research (wide scope, weak operational claims)
- Boot: best-effort (A-BOOT-1 not required)
- Updates: no anti-rollback claim
- Devices: may be trusted implicitly for bring-up (but then isolation claims must be scoped)

## Profile P1: High-assurance lab (strong integrity + reproducibility)
- Boot: verified or measured boot (A-BOOT-1)
- Updates: signed metadata (CH-UPD); optional D-TUF repository metadata for freeze/mix-and-match resistance; anti-rollback if A-BOOT-2 satisfied
- Devices/DMA: DMA-aware isolation is **fail-closed** in Phase 1: if claiming C-ISO-2, the active D-DMA posture must be IOMMU/SMMU-required under A-DMA-1; otherwise the claim is not made and DMA-class attach/lease workflows must deny-by-default. See `docs/30-architecture/dma-posture-v0.md`.

## Profile P2: Field/hostile environment (explicitly harder)
- Requires P1 plus explicit physical attacker model (A-OPS-1 tightened)
- Side channels remain non-claims unless separately modeled and mitigated


## Optional profile extensions (must be explicit)
These are *extensions* that further constrain the system and/or introduce additional assumptions. If enabled they must be recorded in CH-CFG `feature_flags` and logged in CH-BOOT/CH-LOG.

The closed set of allowed `feature_flags` values is pinned in:
- `docs/30-architecture/config-toggle-registry.md`

- **`ext.static_partitioning`**: fixed cores + fixed memory partitions; no overcommit; minimal scheduler complexity.
  - Benefit: makes early isolation proofs cheaper.
  - Typical dependencies: D-ARCH (separation-kernel-ish) + D-SCHED deterministic.

- **`ext.microvm`**: minimal, declared device model; no hidden emulation; tight exit/entry budget.
  - Benefit: yields a realistic hypervisor-first A2/A3 slice.
  - Typical dependencies: D-MICROVM + D-XS closed sets; see `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-memory-topology-posture-v0.md`, `docs/30-architecture/microvm-cpu-topology-posture-v0.md`, `docs/30-architecture/microvm-network-topology-posture-v0.md`, `docs/30-architecture/microvm-block-topology-posture-v0.md`, `docs/30-architecture/microvm-console-channel-posture-v0.md`, `docs/30-architecture/microvm-bootstrap-metadata-posture-v0.md`, `docs/30-architecture/microvm-entropy-surface-posture-v0.md`, `docs/30-architecture/microvm-tpm-surface-posture-v0.md`, `docs/30-architecture/microvm-device-passthrough-posture-v0.md`, `docs/30-architecture/microvm-snapshot-posture-v0.md`, `docs/30-architecture/microvm-generation-witness-posture-v0.md`, `docs/30-architecture/microvm-clock-disruption-posture-v0.md`, `docs/30-architecture/microvm-attestation-reacquire-posture-v0.md`, `docs/30-architecture/microvm-attestation-scope-posture-v0.md`, `docs/30-architecture/microvm-resume-admission-evidence-posture-v0.md`, `docs/30-architecture/microvm-template-snapshot-cut-posture-v0.md`, `docs/30-architecture/microvm-template-lineage-posture-v0.md`, `docs/30-architecture/microvm-template-resume-class-posture-v0.md`, `docs/30-architecture/microvm-restore-repair-barrier-posture-v0.md`, `docs/30-architecture/microvm-template-distribution-posture-v0.md`, and `docs/30-architecture/microvm-template-availability-posture-v0.md`.
  - Scope note: not a compatibility escape hatch; Phase 1 does not adopt “run Linux guests” as a hidden POSIX/legacy path.

- **`ext.confidential_computing.attest_only`**: TEE-backed attestation evidence only (integrity evidence only; no isolation claim).
- **`ext.confidential_computing.enforced`**: TEE-backed guest isolation + attestation (claim-scoped isolation per A-CC-1).
  - Benefit: enables attestation-gated secret release and tighter “what ran?” provenance for remote parties, but increases assumption surface.
  - Dependencies: D-CC + A-CC-1 + explicit side-channel posture (D-SIDECH).
  - See: RFC-0064.

- **`ext.cheri`**: capability hardware for pointer provenance/permissions (research/targeted platforms).
  - Benefit: can tighten memory-safety and compartment boundaries for selected components (especially mixed-language driver stacks).
  - Dependencies: A-CHERI-1 + explicit scope (what is CHERI-enforced vs not); side-channel posture unchanged unless separately addressed.
  - Refs: REF-CHERI-INTRO.

- **`ext.capx_remote_delegation`**: optional “remote caps” via CH-CAPX envelope and a user-space gateway.
  - Benefit: least-authority delegation across machines with explicit audit trails.
  - Dependencies: D-CAPX + <I-CAPX-*> + careful observation/redaction posture (C-OBS-1).

- **`ext.wasm_plugins`**: user-space Wasm runtime for extension components with a capability-only host boundary.
  - Benefit: bespoke extensibility without importing large unsafe runtimes into the privileged core.
  - Dependencies: D-WASM + I-WASM-1 + D-SEAL (recommended for long-lived hosts).

- **`ext.ifc_lite`**: decentralized information-flow control for a scoped subset of IPC/buffer/object operations.
  - Benefit: makes privacy/integrity confinement properties expressible and testable without central MAC policy.
  - Dependencies: D-IFC + I-IFC-1/I-IFC-2 + PO-IFC-STEP; explicit label/tag budget limits.

- **`ext.user_mode_pager`**: object-backed fault routing delivered as IPC to declared pager services for pager-backed memory objects.
  - Benefit: shrinks kernel paging policy and makes backing-store policy explicit/auditable without defaulting to per-address-space fault upcalls.
  - Dependencies: D-PAGER + I-PAGER-1 + DoS posture (D-METER recommended); v0 keeps raw-vaddr/per-address-space pager mode out of scope.