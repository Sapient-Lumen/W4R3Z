# Threat model

See Charter for mission; this document is the single source of truth for attackers, assumptions, and scope.

## Assets (v0)
- Integrity of privileged state (root mode / kernel core)
- Isolation (memory/CPU) across domains/VMs
- Authority integrity (capability model)
- Boot + update integrity; provenance of shipped artifacts
- Integrity of durable state and durable authority (CapStore roots/commits) when D-PERSIST is enabled

## Adversaries (v0)
- **ADV-GUEST**: malicious guest/user process attempting escalation or lateral movement
- **ADV-APP**: malicious application attempting to trick users/UX mediators into granting authority (phishing, permission spam, consent laundering), or abusing allowed channels to exfiltrate data
- **ADV-SERVICE**: compromised user-space service/driver (if outside TCB)
- **ADV-SUPPLY**: supply-chain attacker (deps, CI, mirrors, toolchains)
- **ADV-OPS**: operator/admin error or insider misconfiguration (policy mistakes, unsafe rollouts)
- **ADV-NET**: active network attacker (MITM/replay/injection) against any optional remote-capability transport
- **ADV-PHYS**: physical attacker (scope set by deployment profile)

## Assumptions
All assumptions are registered as **A-IDs** in [`assumption-registry.md`](assumption-registry.md). Claims must reference the A-IDs they require.

## Deployment profiles
Profiles (P0–P2) bundle common assumption sets. See [`deployment-profiles.md`](deployment-profiles.md).

## In-scope attack classes (initial)
- memory corruption attempts via syscall/trap paths
- code injection / execution-enabling surfaces (dynamic native loading, RW→RX flips, JIT exec) where permitted by profile; treat “make bytes executable” as explicit authority (D-DYNCODE)
- authority confusion/forgery attempts in capability operations
- cross-domain read/write absent explicit sharing
- rollback/tampered updates (repository compromise scenarios)

## Out-of-scope (until explicitly added)
- microarchitectural side channels (timing/speculation)
- fault injection / malicious hardware
These are not ignored; they are **non-claims** unless modeled and mitigated. See `sidechannels.md` for explicit posture.

## Mapping
Every security goal must map to Claim IDs (C-*) and Invariant IDs (I-*).

## See also
- Non-claims (canonical exclusions): `docs/20-assurance/non-claims.md`
- LLM/control-plane specific threats: `docs/70-llm-control/llm-threats.md`
