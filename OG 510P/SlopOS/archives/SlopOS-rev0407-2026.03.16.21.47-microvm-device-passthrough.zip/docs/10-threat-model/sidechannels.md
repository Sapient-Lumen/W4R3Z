# Side-channel posture (explicit non-claims, staged scopes)

Purpose: prevent “implicit side-channel promises.” We either model a channel and claim something, or we do not claim it.

## Default posture (v0)
- **No general side-channel resistance claims.**
- Side channels are treated as *out of scope* unless a specific scope and model is adopted via ADR.

This is consistent with `assurance-claims.md` (explicit non-claims).

## Candidate scoped models (only if we decide to claim)
1) **Coarse timing-only leakage bounds** (very limited; often unrealistic)
2) **Constant-time within a declared kernel slice** (requires careful API and microarch assumptions)
3) **Partitioned microarchitectural state** (requires hardware support and explicit model)

Note: “time protection” work in seL4 argues that timing isolation needs an explicit OS abstraction (not just careful coding). Treat as a candidate reference point if we ever adopt a timing-channel scope (REF-SEL4-TIMEPROTECTION).

If we adopt D-TCAP with scheduling contexts (RFC-0049), those boundaries can also act as the natural *time protection* domain-switch hook, but this remains an explicit non-claim until we adopt a scoped model.

## Decision hooks
- D-SIDECH: whether we claim anything at all, and which model.
- D-ARCH / D-ISA: microarchitectural reality differs dramatically by platform.

## Evidence that would justify adopting a scope
- E1: measurement harness shows stable bounds under representative adversary scheduling
- E2: model checking (where possible) of the observation model for the declared slice
- E3: mechanized proofs only for a *narrow* channel model (avoid “prove the CPU” fantasies)

## If we do *not* claim
Record “non-claim” explicitly in any release profile asserting other security claims, and avoid relying on secrecy through timing.

## Hygiene knobs (still not a claim)
Even without adopting a scoped side-channel model, we can still reduce ambient “oracle surface” for untrusted code:
- **D-NONDET**: make fine clocks an explicit authority (default coarse clocks) and keep time/entropy reads on the declared nondeterminism boundary for replay/testing.
- **D-METER / D-PRESSURE**: avoid turning resource pressure into a high-bandwidth oracle by design (budgeted, coarsened, and claim-scoped).

These are *hygiene* measures; they do not imply a side-channel claim.
