# Update repository metadata + key rotation (D-TUF playbook)

Purpose: make D-TUF adoptable by defining an **operator reality**:
how keys are stored, rotated, and recovered — not just how metadata is verified.

Scope: update repository tooling + fleet operations.
Non-scope: kernel behavior (kernel remains agnostic; see RFC-0051 / RFC-0079).

## Key hierarchy (recommended baseline)
TUF baseline roles: **root**, **targets**, **snapshot**, **timestamp**.

Recommended posture (P1/P2):
- **root**: offline, threshold signatures (e.g., 2-of-3) stored in separate locations.
- **targets**: offline or semi-offline (connected only during release staging).
- **snapshot**: semi-offline; can be derived from staged targets.
- **timestamp**: online; short-lived; compromise should be survivable.

Rationale:
- online compromise of timestamp alone should not let an attacker publish arbitrary targets.
- root compromise should be rare and treated as an incident requiring out-of-band recovery.

## Expiry windows (starting point)
Expiry is a *freshness alarm*, not a guarantee of update availability.

Suggested initial windows (tune per cadence):
- timestamp: 1–2 days
- snapshot: 1–7 days
- targets: 7–30 days (shorter if you publish frequent security updates)
- root: 180–365 days

Shorter expiry increases security but requires an operational cadence that can reliably refresh metadata.

## Release staging (minimal)
A staged release for a channel SHOULD include:
- a CH-UPD object (signed by D-UPD-SIGN policy, and published as a TUF target)
- optional: CH-SIGENV envelope(s) for CH-UPD / CH-PROV / CH-CFG (D-SIGENV), including keyless cert binding if D-KEYLESS is enabled
- optional: CH-TLOG anchor(s) for the payload digests (D-TLOG) to support independent auditing
- the deployment tree/closure referenced by CH-UPD `target_root_digest`
- optional: CH-PROV attestation container, proof bundle, CH-TLOG anchor(s)

Staging steps (conceptual):
1) build artifacts; compute digests
2) produce CH-UPD (intent) + optional provenance bundle
3) update TUF targets metadata with new target(s)
4) update snapshot + timestamp
5) (optional) publish transparency anchors for CH-UPD + targets metadata digests (D-TLOG)

## Rotation drill (required for credibility)
D-TUF claims are only meaningful if rotation is practiced.

Quarterly or per-release-cycle drill:
- simulate compromise of **timestamp** key:
  - revoke/replace in root metadata
  - verify clients reject old metadata and accept rotated keys
- simulate compromise of **targets** key:
  - issue root update revoking targets key and installing replacement
  - validate that a malicious targets file signed with the old key is rejected
- verify monitors (if D-TLOG) detect any attempted equivocation

Artifact:
- record a signed incident/rotation “exercise log” entry (operator evidence) and bind it into the archive evidence index.

## Root-compromise recovery (out-of-band)
If a threshold of root keys is compromised, normal repository updates cannot safely recover trust.

Required out-of-band strategy (choose one for P1/P2):
- physical install media refresh for affected systems, or
- fleet provisioning channel that can pin a new root digest (TPM/secure storage), or
- enterprise MDM-style distribution of a new root bundle.

Guidance:
- document the recovery method as part of the deployment profile.
- treat “root recovery completed” as a gate before secret release if D-VAULT depends on update trust.

## Fleet extensions (optional: D-UPTANE posture)
Uptane adds a director split for per-device/cohort policy (e.g., staged rollout, VIN-targeted updates).
If used:
- ensure the director keys are managed with at least targets-key hygiene,
- ensure the “image repository” is still verified as a consistent snapshot,
- treat director outages as a denial-of-service, not a safety failure.

## References
See: RFC-0079.  
Refs: REF-TUF-SPEC, REF-TUF-METADATA, REF-UPTANE-STANDARD2, REF-UPTANE-BESTPRACTICES.
