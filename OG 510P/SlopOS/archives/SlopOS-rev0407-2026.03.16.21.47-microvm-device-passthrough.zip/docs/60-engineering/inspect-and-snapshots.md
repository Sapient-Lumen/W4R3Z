# Inspect trees and diagnostic snapshots (engineering notes)

This doc sketches how to operationalize **D-INSPECT** (RFC-0075) without turning diagnostics into an ambient side channel.

## Why an inspect tree?
Logs answer “what happened,” but incident debugging usually starts with:
- what state is the component currently in?
- what are the counters / mode flags / topology?
- what did it *think* it was doing when it logged that line?

Stringly “dump” endpoints proliferate because the platform does not offer a stable, structured alternative.

## Publishing model (recommended)
A component maintains a bounded in-memory diagnostics tree and exposes it as a read-only region:
- writer updates are **local** (no syscalls)
- a diagnostics collector can snapshot by copying the region

This decouples “high-rate updates” from the privileged core.

## What belongs in inspect
Good candidates:
- component mode (init/sealed, recovery state)
- bounded topology (peer counts, queue lengths)
- rate and error counters
- last-success timestamps *only if profiles permit time* (D-NONDET)
- digests of config/build inputs (not raw config secrets)

Anti-patterns:
- bearer tokens, raw credentials, raw sturdyrefs
- raw addresses/pointers
- unbounded strings (log lines, stack traces)

## Redaction and classification
Every node/property can be tagged:
- `public`: safe in normal exports
- `sanitized`: safe after policy scrubbing
- `sensitive`: excluded by default; explicit authority required

Rule of thumb: if it would be inappropriate to paste into a public issue tracker, it’s at least `sensitive`.


Export rule: IF-OBS exports and snapshot assembly SHOULD be constrained by a **pinned observation export policy** (CH-OBSPOL).
- sanitized builds can ship with a single “default sanitized” policy digest
- dev/bringup builds may allow a separate `tier=full` policy behind explicit operator authority
- any exported CH-SNAPSHOT should record which policy/profile was applied (via `redaction_profile` and/or transcript metadata)
## Snapshot bundles (CH-SNAPSHOT)
A snapshot bundle is a *manifest + payloads* packaging flow for incidents.

Recommended profiles:
- **sanitized snapshot (default)**
  - short log window
  - inspect snapshots for critical components
  - health record + component graph
  - optional trace processor aggregates (no raw trace by default)

- **full snapshot (rare)**
  - requires explicit operator/consent workflow
  - may include raw traces, crash dumps, and sensitive inspect nodes

## CI and reproducibility workflows
Snapshots are useful even without replay:
- attach a sanitized snapshot to flaky CI failures
- use the manifest’s digests to pin exactly which artifacts were present
- feed snapshots to minimizers that decide whether replay capture is needed

## Tooling ideas (future)
- `snapshot lint`: checks bundles for obvious secrets and policy violations
- `snapshot diff`: compare two manifests to see “what changed” between runs
- `inspect query`: typed queries over CH-INSPECT snapshots (no runtime access)
