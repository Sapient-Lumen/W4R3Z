# Interface evolution workflow (D-APIEVO)

This is a practical checklist for evolving an interface without breaking upgrades or creating “silent fallback” security hazards.

## 1) Decide the posture: closed vs open
- **Closed** (CH-IFACE.openness=`closed`):
  - default for privileged or high-assurance surfaces,
  - unknown methods are treated as fatal (fail closed),
  - breaking changes require *new interface digest* + explicit adapter.
- **Open** (CH-IFACE.openness=`open`):
  - acceptable for broad ecosystem surfaces,
  - unknown methods return `UNKNOWN_METHOD` with no side effects,
  - allows “additive” evolution to ship without lockstep upgrades.

Rationale: open interfaces need explicit semantics for unknown interactions (compare REF-FUCHSIA-APIEVO / REF-FUCHSIA-RFC0138).

## 2) Prefer additive evolution
If your encoding/IDL supports tagged fields (ordinals), stick to “add-only” changes:
- add new optional fields with new tags/ordinals,
- reserve removed field tags (do not reuse),
- do not change the meaning of an existing tag,
- avoid reordering semantics that change canonical encoding.


## 2a) Method ordinals: never renumber
CapRPC dispatch relies on `method_id`. Treat it like a compatibility contract:
- **Never** renumber or reuse an ordinal for a different semantic method.
- For **open** interfaces, prefer hash-derived ordinals so that adding a method does not require touching existing ids.
- Emit and pin a **CH-ORD v0** ordinal manifest and gate upgrades on “no reuse / no collisions.”

See: `docs/60-engineering/idl-digest-and-ordinal-policy.md`.

Good prior art:
- Cap'n Proto evolution rules (REF-CAPNP-EVOL)
- Protobuf compatibility practices (REF-PROTOBUF-COMPAT)

## 3) When semantics change, ship an adapter
If the change is not monotonic (e.g., tightening preconditions, changing meaning, splitting/merging objects):
- mint a new CH-IFACE (new `iface_digest`),
- ship a **translator/facade** component that speaks the old digest and calls the new provider,
- route legacy clients to the adapter explicitly (do not hide it in a generic runtime).

## 4) Make removal boring: staged deprecation
A staged approach that keeps rollouts safe:
1. **Provider implements both** old and new (or ships adapter).
2. **Consumers migrate** to new digest.
3. **Policy/tooling gate** refuses upgrades that remove the old digest while any consumer still depends on it.
4. Remove the old interface only after the system is demonstrably quiesced.

## 5) Tests that catch the classic failures
Minimum regression suite for any open interface:
- old client ↔ new server: unknown method returns `UNKNOWN_METHOD` and channel stays usable,
- new client ↔ old server: unknown method returns `UNKNOWN_METHOD` (or fails closed if policy says closed),
- method mismatch never triggers fallback to a different interface digest,
- adapter does not increase authority (capgraph diff gate, D-EXPLAIN).

