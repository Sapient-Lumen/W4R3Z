# Release bundle verification contract

Purpose: make the user-facing zip a **checkable handoff artifact**, not just a file that is trusted because our packager created it.

## Canonical verification command

The canonical verifier is:

- `make verify-release BUNDLE=/abs/path/to/SlopOS-rev####-YYYY.MM.DD.HH.MM-<slug>.zip`

`make package-release ...` MUST run this verification logic on the just-built bundle before reporting success, and the standalone command remains the independent re-check path for already-produced artifacts. Verification MUST validate the bundle **itself**, not the unpacked workspace.

## Required checks

`tools/verify_release_bundle.py` MUST reject bundles unless all of the following hold:
- the filename matches `SlopOS-rev####-YYYY.MM.DD.HH.MM-<slug>.zip`;
- the bundle contains exactly one root-level `RELEASE-MANIFEST.json`;
- the manifest `archive_name`, `revision`, `packaging_timestamp`, and `slug` match the filename;
- `files[]` is lexicographically sorted, excludes `RELEASE-MANIFEST.json`, and matches the actual zip member set exactly;
- each listed member's `size` and `sha256` match the bytes inside the bundle;
- every zip member carries canonical archive metadata (timestamp derived from `STAMP`, canonical permissions, Unix creator marker).

## Posture

Verification is **manifest-against-bundle**, not working-tree-against-bundle. This mirrors a useful packaging pattern: Python wheel archives carry a `RECORD` file listing archived files and strong hashes, and verification should inspect the bytes inside the distributed artifact rather than trusting whatever happens to be unpacked nearby (`REF-PEP-427`).

## Why this exists

- Keeps the zip handoff reviewable as a final artifact, not only as packager code.
- Makes payload drift or metadata drift observable before handoff.
- Completes the packaging loop: package must self-verify, and standalone verification remains available to re-check the exact bundle being handed off.
- Stays small and composable; this is bundle verification, not a larger signing or release-management subsystem.

## Wiring

- Packaging contract: `docs/60-engineering/release-packaging-contract.md`
- Embedded manifest contract: `docs/60-engineering/release-bundle-manifest-contract.md`
- Verification tool: `tools/verify_release_bundle.py`
- Drift gate / evidence hooks: `tools/check_release_bundle_verification_contract.py`, `EVID-2026-280`; `tools/check_release_package_self_verify.py`, `EVID-2026-281`

## References

- `REF-PEP-427`
- `REF-REPRO-BUILDS-ARCHIVES`
- `REF-PYTHON-ZIPFILE`
