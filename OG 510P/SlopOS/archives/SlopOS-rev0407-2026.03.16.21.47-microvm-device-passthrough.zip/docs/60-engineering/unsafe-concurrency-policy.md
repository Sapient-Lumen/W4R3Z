# Unsafe & concurrency policy

## Unsafe is an obligation boundary
- `unsafe` only in designated modules (HAL, page tables, low-level traps)
- each `unsafe` block documents (and links to a U-ID entry in `docs/20-assurance/unsafe-obligation-registry.md`):
  - Safety Preconditions
  - Preserved invariants (I-IDs)
  - Postconditions

## Type-capabilities (optional guardrail)
To reduce accidental privilege *inside* the privileged core, sensitive internal APIs may be gated by module-private **type-capability tokens** (RFC-0020).
- only boot/init code can mint the token
- token-gated APIs should have **no equivalent un-gated entrypoints**
- tokens default to `!Send/!Sync` unless explicitly justified

Maps to: I-TYPECAP-1; PO-TYPECAP-NOFORGE/PO-TYPECAP-AUDIT.

## Concurrency constraints (choose explicitly)
Options (D-CONC):
- UP-only bring-up builds (explicitly non-flagship; no verification claims)
- SMP big-lock baseline (a verified sequentialization point on multicore hardware)
- SMP refined locking / sharding
- Hybrid evolutions (D-MK): multikernel across clusters with explicit message-passing; SMP within a cluster

## Gates
- deny new `unsafe` in core without an RFC or explicit policy entry
- CI runs bounded checks for critical state machines where feasible
