# System generation pipeline (CH-COMP → CH-INIT) (Microkit/capDL-inspired)

Goal: keep early system bring-up **simple, static, and auditable** by supporting an optional build-time pipeline that compiles a declared composition (CH-COMP) into a concrete time‑0 snapshot (CH-INIT), minimizing runtime “init logic” and making it easier to test/verify that “boot matches intent”.

This is an *engineering posture* layered on D-COMP + D-INITSNAP:
- CH-COMP remains the **authoring** and review artifact (“what should run + how routing is allowed”).
- CH-INIT is the **realized** time‑0 object/capability graph (“what actually exists at boot”).

Inspiration: seL4’s capDL + Microkit toolchain, which treats architecture as a static description compiled into an initializer/runtime that sets up the system state.

Refs: REF-MICROKIT-MANUAL, REF-MICROKIT-GITHUB, REF-CAPDL-KUZ10, REF-MICROKIT-VERIFY24.


## Inputs
- **CH-COMP v0** (authoring): components, routes, restart/criticality metadata, and optional readiness/health annotations.
- Optional adjuncts (authoring):
  - CH-PART / CH-ADDRNET / CH-HWFACT (if the profile uses them)
  - Profile policy: bounds (max objects/caps), scheduling stance, device exposure posture


## Outputs
- **CH-INIT v0** (snapshot): bounded list of objects + capability edges + optional initial maps (profile-scoped).
- Optional accelerator (ecosystem): a digest-identified **template image** derived from CH-INIT (or a cooperative CH-CKPT) to enable low-latency spawning of disposable domains (zygote-style) without adding privileged-kernel logic; D-EPHEM v0 still requires fresh-instance semantics, no hidden handle/network continuity, and entropy/identity refresh before user payload runs (`disposable-domain-posture-v0.md`). Under `ext.microvm`, the reusable fan-out artifact is a **parent-bound, leaf-resumable** template; any diff/base layering, merge order, or chain maintenance stays implementation-local rather than becoming a public deployment/workflow surface (`docs/30-architecture/microvm-template-lineage-posture-v0.md`). Restore admission is pinned separately: each reusable leaf resumes only on hosts in the same exact reviewed class, so CPU/device/kernel heterogeneity is normalized before the cut instead of negotiated at resume time (`docs/30-architecture/microvm-template-resume-class-posture-v0.md`). Guest-visible memory topology is pinned separately too: Phase 1 `ext.microvm` adds no portable balloon / virtio-mem / ACPI memory-hotplug or resize-status plane, so changing guest-visible RAM means admitting a different reviewed leaf/activation rather than mutating a running guest under the same portable identity (`docs/30-architecture/microvm-memory-topology-posture-v0.md`). Guest-visible CPU topology is pinned separately as well: Phase 1 `ext.microvm` adds no portable vCPU hotplug / CPU online-offline / hotpluggable-slot or resize-status plane, so changing guest-visible vCPU count/topology or SMT means admitting a different reviewed leaf/activation rather than mutating a running guest under the same portable identity (`docs/30-architecture/microvm-cpu-topology-posture-v0.md`). Guest-visible network topology is pinned separately too: Phase 1 `ext.microvm` adds no portable NIC hotplug / attach-detach / link-state or interface-status plane, so changing guest-visible NIC inventory/topology means admitting a different reviewed leaf/activation rather than mutating a running guest under the same portable identity (`docs/30-architecture/microvm-network-topology-posture-v0.md`). Guest-visible block topology is pinned separately as well: Phase 1 `ext.microvm` adds no portable disk hotplug / hot-remove / media-insert-eject or tray/device-status plane, so changing guest-visible block-device inventory/topology means admitting a different reviewed leaf/activation rather than mutating a running guest under the same portable identity (`docs/30-architecture/microvm-block-topology-posture-v0.md`). Guest-visible serial/console posture is pinned separately too: Phase 1 `ext.microvm` adds no portable interactive serial/console input, no console/monitor multiplex, and no runtime backend-rebind/status plane, so any admitted serial/console surface is off/null or a write-only diagnostic sink rather than a host control channel (`docs/30-architecture/microvm-console-channel-posture-v0.md`). Guest-readable bootstrap/metadata is pinned separately as well: Phase 1 `ext.microvm` adds no portable MMDS / IMDS / fw_cfg / config-drive / cloud-init datasource plane, so bootstrap authority rides on reviewed boot artifacts or explicit post-boot seams rather than a hidden host metadata path (`docs/30-architecture/microvm-bootstrap-metadata-posture-v0.md`). Guest-visible entropy exposure is pinned separately too: Phase 1 `ext.microvm` adds no portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality/status plane, so any owner-local boot seeding remains implementation-local and post-init entropy meaning stays on explicit D-NONDET seams rather than ambient guest device reads (`docs/30-architecture/microvm-entropy-surface-posture-v0.md`). Guest-visible TPM exposure is pinned separately as well: Phase 1 `ext.microvm` adds no portable TPM2 command/status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane, so any NitroTPM / `swtpm` / passthrough choice remains owner-local and attestation/key-sealing meaning stays on explicit D-ATTEST and D-CRYPTOSVC seams rather than ambient guest TPM device calls (`docs/30-architecture/microvm-tpm-surface-posture-v0.md`). Guest-visible passthrough-device exposure is pinned separately too: Phase 1 `ext.microvm` adds no portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane, so any owner-local host binding, group selection, or mediated-profile choice remains implementation-local and DMA-class device authority stays on explicit D-DMA and D-IOLEASE seams rather than ambient guest passthrough devices (`docs/30-architecture/microvm-device-passthrough-posture-v0.md`). If policy cares which exact reusable leaf or owner-local recovery artifact was admitted, that identity stays on owner-local provenance/admission evidence rather than a guest-visible API (`docs/30-architecture/microvm-resume-admission-evidence-posture-v0.md`). After resume, clone-sensitive repair completes before the leaf emits externally visible effects or claims readiness; runtime-specific hooks may implement that ordering locally, but Phase 1 does not standardize a portable restore-complete control plane (`docs/30-architecture/microvm-restore-repair-barrier-posture-v0.md`). A fresh post-restore attestation exchange may then re-prove boot/provenance lineage + freshness for the current generation, but it still does not identify one exact resumed warm-start leaf unless separate lineage/admission evidence says so (`docs/30-architecture/microvm-attestation-scope-posture-v0.md`). Distribution is pinned too: reusable warm-start leaves and owner-local recovery checkpoints stay owner-local admission accelerators, so portable handoff ships the cold parent lineage and each owner/runtime cuts warm leaves locally rather than importing shareable warm-state blobs (`docs/30-architecture/microvm-template-distribution-posture-v0.md`). Availability is pinned too: owners may evict or regenerate those leaves locally without changing the reviewed cold parent lineage, and Phase 1 adds no public warm-cache hit/miss or `Pending` / `Active` / `Inactive` lifecycle plane; a miss/regeneration remains admission-local rather than guest-visible semantics (`docs/30-architecture/microvm-template-availability-posture-v0.md`).
- Optional build products (non-authoritative, for tooling/debug):
  - `init.diff` (CH-COMP intent vs realized CH-INIT summary)
  - `cap-graph.svg` or `cap-graph.json` (for visualization)

### Recovery deployment (D-RECOVERY)
If the profile enables D-RECOVERY (RFC-0098), the build pipeline SHOULD also emit a **recovery deployment root**:
- built from a minimal CH-COMP/CH-INIT composition (diagnostics + rollback/config tooling),
- sealed/minimal by default (no ambient network/device attach),
- installed into a reserved slot, and
- referenced from release intent and boot records as an `artifacts[]` entry with role `recovery_root` (CH-UPD/CH-BOOT convention).

This keeps recovery in the same digest/provenance universe as normal deployments without adding privileged logic.


## Pipeline stages
### Stage A: Authoring + lint (CI)
- Validate CH-COMP (closed-world validation; reject unknown variants).
- Lint for authority hazards:
  - no undeclared routes (I-COMP-1 profile),
  - no ambient acquisition edges (D-CAPMODE discipline),
  - seal_after_init coverage on critical components (D-SEAL profiles),
  - restart storm risk heuristics (RFC-0017).

### Stage B: Sysgen (build-time compilation)
- Allocate the initial object graph deterministically (IDs are stable under a chosen ordering).
- Expand declared routes into concrete capability edges:
  - enforce attenuation rules (rights reduction only unless an explicit authority object is present).
- Optional: materialize profile-specific objects (meters, sched contexts, device windows) using CH-PART/CH-ADDRNET.

Output: CH-INIT snapshot + a small “init plan” artifact for humans.

### Stage C: Boot-time installation
Two modes (both are acceptable; chosen by profile):
- **Interpretation mode**: user-space init reads CH-COMP and creates objects/caps at runtime.
- **Snapshot mode**: a tiny initializer installs exactly the CH-INIT snapshot (and can still hand off to a user-space supervisor).

Snapshot mode is preferred for high-assurance profiles because it reduces runtime degrees of freedom.


## Assurance hooks
- **PO-INIT-VALIDATE**: CH-INIT decoding/validation is deterministic and bounded.
- **PO-INIT-MATCH**: installed initial state matches CH-INIT within the declared equivalence.
- **PO-COMP-BIND**: if CH-COMP is used, its digest is bound in CH-BOOT (and ideally tied to the CH-INIT digest if snapshot mode is used).

Evidence targets (early):
1. Golden tests: a tiny CH-COMP produces an expected CH-INIT (stable IDs, stable edges).
2. Negative tests: invalid routes/rights amplification fail closed.
3. Boot check: attempt to boot with tampered CH-INIT must fail closed and be transcript-visible.


## TCB posture
- Sysgen tooling is **not** in the privileged core.
- The trusted part (if snapshot mode is used) is a small initializer + validator that:
  - validates CH-INIT,
  - instantiates objects/caps,
  - records/binds digests into CH-BOOT/CH-LOG for audit.

Rule: keep the initializer’s behavior a straight-line “install snapshot” procedure with total validation. Complex policy stays in authoring tools and validators.
