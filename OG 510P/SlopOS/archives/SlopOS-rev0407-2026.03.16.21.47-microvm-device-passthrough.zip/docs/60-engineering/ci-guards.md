# CI guards (minimal, high-value)

Purpose: keep the archive honest by preventing drift in claims/IDs/interfaces, without turning CI into a research sink.

## Guard list (v0)
1) **Archive lint gates** (EVID-2026-003):
   - undefined concrete IDs (C-/I-/A-/D-/PO-/U-/IF-/CH-/EVID-/REF-/ADR-/RFC-)
   - broken internal links
   - raw URLs outside the bibliography (force REF discipline)
   - schema-registry entries must point to spec docs that name `CH-* v0`

   Command: `make lint` (runs `tools/lint_archive.py`).

2) **No duplicate canonical sources**: if a concept has a canonical registry/doc, forbid parallel “shadow” lists (enforced by review + deprecations).

3) **Unsafe gate**: new `unsafe` in privileged core must add/extend a U-ID entry and reference the preserved invariants.

4) **Release profile gate** (when releases exist): artifacts claiming C-BOOT-1/C-PROV-1 must have reproducibility checks and provenance attestations.

## Decision
- ADR-0001 adopts the v0 archive lint gates as a required check for repo changes.
