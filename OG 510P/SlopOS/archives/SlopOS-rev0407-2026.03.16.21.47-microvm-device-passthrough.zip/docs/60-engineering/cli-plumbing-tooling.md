# CLI plumbing tooling (make terminal workflows capability-safe)

Goal: prevent the terminal ecosystem from reintroducing ambient authority via paths, helper sockets, or ad-hoc IPC.

Baseline rule: **CLI tools talk to the workflow router** (D-PLUMB) using **CH-PLUMBMSG** envelopes (RFC-0117), and any authority acquisition happens via portals (RFC-0046).

## Design principles
- **Handles, not paths:** CLI verbs should accept `docref`/`sturdyref`/cap handles. If a human needs to pick a file, invoke the file chooser portal and receive a handle.
- **No ambient “open”:** avoid `PATH`-style helper discovery or global “default app” sockets. Routing is explicit (CH-ROUTE) and auditable.
- **Dry-run is normal:** every plumb action should support `--explain` to show the resolved route and the predicted authority diff (CH-CAPDIFF) before execution.
- **Wallet-aware:** when a wallet is present (CH-WALLET), attach `wallet_core_digest` so prompts/receipts/CI drift gates can key off stable authority; do not treat wallet artifacts as an authority import or lookup path.
- **Capmode-safe:** tools must operate correctly under D-SEAL/D-CAPMODE (no fallback to ambient namespaces).

## Recommended CLI verbs (v0)
These are the “xdg-open equivalents”, but capability-safe:
- `open <subject>`
  - subject: `docref:<id>` | `sref:<digest>` | `uri:<...>`
  - emits `intent.kind=open` or `open_uri`
- `save-as <subject> --format <fmt>`
  - emits `intent.kind=export` with explicit format bounds
- `share <subject> --to <target>`
  - routes through transfer portal (CH-XFER)
- `paste` / `copy` / `drag`
  - routes through transfer portal; never reads global clipboard state
- `print <subject>`
  - routes through print portal; no raw printer sockets, printer inventory queries, or print-to-file path bypass

Each verb is implemented as:
1) construct CH-PLUMBMSG
2) call `Workflow.Plumb.Send`
3) if mediation is required, the workflow router runs the portal session and emits receipts/transcripts

Phase 1 pinned PLUMB posture: CLI outcomes come back only on the request-local completion path (request handle / portal response / receipt trail). Tools must not depend on a generic `Subscribe(port)` inbox, callback URL, or return-mailbox convention. Imported-bearer document workflows stay pinned separately: CH-SREF / CH-CAPX driven import must first mint a **fresh local object** + CH-DOCREF, and the resulting object may keep only digest-only bearer provenance via **`origin.import_ref_digest`** (`import-to-docref-bearer-provenance-boundary-v0.md`).

## Debugging + safety rails

### `plumb explain`
A non-effectful path that returns:
- matched CH-ROUTE rule (name + digest)
- whether mediation is required
- predicted `capdiff` (as a digest reference), when possible

Use cases:
- packaging checks: confirm a CLI tool does not silently widen authority
- CI gates: reject merges that widen wallet core digests without an explicit approval

### “Safe-open” defaults
For `open` on quarantined/origin-tagged objects (D-QUAR), the CLI should default to:
- `intent.kind=open_untrusted` (disposable) unless explicitly overridden
- object-only safe-open request: one exact `docref`, not a URI/URL variant and not a `sturdyref` restore/import shortcut
- if a workflow starts from durable bearer material, it must first perform an explicit D-CAPX / CH-SREF restore/import step, materialize a **fresh local object**, and obtain a provider-local `docref`; only then may it call `open_untrusted` (`import-to-docref-boundary-v0.md`)
- that bridge is **fresh-object-identity-first**: even if the imported bytes already exist locally, it must not reuse an existing docref/object via `reuse_existing` / cache-hit semantics (`import-to-docref-fresh-identity-boundary-v0.md`)
- do not mint a hidden bearer-backed docref shim: local docref reopen must not silently refetch remote bytes or turn ordinary save into remote write-back semantics
- safe-open resolves that `docref` once into a request-local stable input object (snapshot/staged-copy style), so the viewer gets no live alias or save-through path back to the source
- admitted safe-open viewers preserve the **inert-view boundary**: document-embedded active content must not execute and document-driven network/helper/print/file effects must not happen behind the initial request; any such effect becomes a new explicit workflow on the existing portal seam (`open-untrusted-active-content-boundary-v0.md`)
- admitted safe-open viewers also preserve the **no-residue boundary**: merely previewing/opening a risky document must not populate durable recent-doc / MRU / reopen / thumbnail / autosave / crash-recovery surfaces outside the disposable; any durable persistence starts only from explicit keep/export or a later portal choice (`open-untrusted-viewer-residue-boundary-v0.md`)
- preview/open does not auto-clear or auto-export; any persistence still routes through explicit `portal.xfer.*` / `portal.file.*` / IF-CONSENT seams
- ordinary kept output from safe-open becomes a **new artifact** that remains **quarantined by default**; only a distinct sanitize/clear workflow can produce a differently classified result
- ordinary keep/export is **fresh-destination-first**; “save back over the original/trusted file” is not part of routine safe-open UX and any later replace/publish step stays explicit
- ordinary kept output records one exact `origin.parent_digest`, so the fresh quarantined artifact keeps an explicit parent link instead of turning provenance into filename/path/session folklore
- quarantined exact executable/script objects do **not** auto-route into `open_untrusted`; ordinary `capshell.exec` / exact-object launch must fail closed until explicit object-local clear/override, and Phase 1 adds no portable `run_untrusted` helper (`docs/30-architecture/quarantined-execution-boundary-v0.md`)

## Plan 9 lineage without Plan 9 footguns
Plan 9 plumbing (REF-PLAN9-PLUMB) is the inspiration: send typed messages to a central router; rules decide dispatch.

Key adaptation for a capability OS:
- CH-PLUMBMSG is **non-authoritative** (no raw caps)
- all authority handoff is portalized and transcripted

## Integration with capshell
- Capshell scripts should emit CH-PLUMBMSG intents rather than invoking ambient helpers.
- Learn-mode can record “this script invoked open/share/print” as intents and then tighten contracts.
- When capshell executes external tools, it MUST bind execution context via **CH-EXECPACK v2** (which bundles **CH-REQCTX v1**, **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, and **CH-FDSET v0** plus the bound **CH-EFFCON v0** effect contract).
  - No ambient PATH resolution, no ambient env inheritance, no ambient cwd inheritance, no ambient stdio/TTY inheritance, and no ambient inherited handle/FD tables; child descriptor state is exact CH-STDIO + CH-FDSET only (`docs/30-architecture/capshell-handle-table-posture-v0.md`).
  - Any authority acquisition happens only via portals (RFC-0046) and is receipt/transcript-visible.
- Strict profiles MUST NOT select an executable from a literal argv token or ambient PATH; the executable is chosen only from a CH-ARGV `desc` token with `role="exec"` bound to already-held authority.
- After binding that selector, launch must stay on the **exact executable object** that was reviewed: runners do not turn it back into a mutable path/document name/package alias and reopen "whatever is there now"; they either use exact-object launch or exact-byte stage into a provider-owned execution object, or fail closed (`docs/30-architecture/capshell-exec-object-posture-v0.md`).
- Exact-object launch meaning is still downstream of quarantine/origin policy: if that reviewed executable/script object remains quarantined, CLI tooling must reject until explicit object-local clear/override and must not invent a document-shaped `run_untrusted` fallback (`docs/30-architecture/quarantined-execution-boundary-v0.md`).
- Launch must also stay on the **exact startup native code closure** that was reviewed: the runner does not bind only the main executable and then let loaders/interpreters/shared libraries come from ambient `/etc/ld.so.cache`, default `/lib*` / `/usr/lib*`, current-directory, package aliases, or standard DLL search order. It either launches from an already bound sealed closure root / image or stages the whole reviewed closure into a provider-owned root, or fails closed (`docs/30-architecture/capshell-code-closure-posture-v0.md`).
- Child `argv[0]` must stay tied to that reviewed exec selector: the runner derives the child program name from the explicit `role="exec"` selector, keeps the remaining non-`exec` tokens as child `argv[1..]`, and does not use `exec -a`, alias tricks, or login-shell prefix conventions to spoof startup mode on the generic seam (`docs/30-architecture/capshell-argv0-posture-v0.md`).
- If a workflow runs a script/text artifact, the interpreter itself remains that explicit `role="exec"` selector. The runner does not consult shebangs, `#!/usr/bin/env`, filename suffixes, or ENOEXEC-style fallback to discover an interpreter; the script is a separate explicit input.
- The runner never accepts a free-form shell **command string**, never auto-tokenizes shell source into argv, and never satisfies `capshell.exec` via hidden `sh -c` / `system()` indirection. If a workflow explicitly chooses a shell as `role="exec"`, any following command string is just ordinary argv data under that shell's own semantics (`docs/30-architecture/capshell-command-string-posture-v0.md`).
- A cleared interpreter/runtime still does **not** launder a quarantined bound code object by restaging it as `stdin`, `-c`, `--eval`, module/archive entry, or a similar code-bearing input. CLI tooling/adapters must either preserve the object-local quarantine gate on those positions or fail closed (`docs/30-architecture/quarantined-code-input-boundary-v0.md`).
- Companion no-ambient-extraction boundary: CLI/shell/agent helpers around risky-open, attrfs, or observation export must not silently turn quarantined bytes into host/global full-text indexes, OCR sidecars, embedding stores, or summary caches. Any later OCR/summarize/embed step is explicit and yields a new quarantined artifact rather than background laundering (`docs/30-architecture/quarantined-content-index-boundary-v0.md`).
- Companion no semantic back-write boundary: even those explicit derived-output steps must not write OCR text, semantic tags, classifier outputs, or similar content-derived fields back onto the quarantined source object's attributes; if durable semantics are needed, they stay on a separate derived artifact (`docs/30-architecture/quarantined-derived-attribute-boundary-v0.md`).
- Companion no source-resurfacing boundary: even when durable semantics live on a separate derived artifact, CLI/shell/agent query surfaces must not hide the matching derived artifact behind the risky source object through hidden lineage joins, representative substitution, or dedup-style result collapse; explicit relation-follow stays separate (`docs/30-architecture/quarantined-derived-match-boundary-v0.md`).
- Companion metadata-safe result-rendering boundary: even when the exact quarantined or derived artifact is the right hit, CLI/shell/agent result rows must not auto-render snippets, thumbnails, preview panes, Quick Look cards, or hover previews from quarantined bytes; richer preview is a separate explicit review/open step on the exact handle (`docs/30-architecture/quarantined-result-preview-boundary-v0.md`).
- Strict profiles SHOULD require explicit `cwd.kind="empty"` (CH-CWD) and an empty CH-ENV by default, so legacy tools cannot accidentally pick up host namespaces.
- `cwd.kind="empty"` is a **sealed cwd-root** request, not a convenience hint: runners should map it to a fresh empty directory (or equivalent sealed root) whose relative-path resolution cannot escape via `..` or host-root fallback; if the active runtime cannot guarantee that, reject/fail closed instead of inheriting launcher cwd (`docs/30-architecture/capshell-cwd-root-posture-v0.md`).
- Launch file-creation defaults are also explicit by posture: runners/wrappers do not inherit the parent shell/session `umask`; Phase 1 fixes the child launch `umask` at `0o077`, so new files/directories start owner-only unless the explicitly chosen program later widens permissions itself (`docs/30-architecture/capshell-umask-posture-v0.md`).
- Launch resource limits are also explicit by posture: runners/wrappers do not inherit parent shell/session `ulimit` / `getrlimit()` state; Phase 1 adds no reviewed per-step `rlimit` surface and forces `RLIMIT_CORE = 0` before exec, so crash output and limit ceilings do not depend on hidden login-shell defaults (`docs/30-architecture/capshell-rlimit-posture-v0.md`).
- Launch signal state is also explicit by posture: runners/wrappers do not inherit blocked-signal masks or ignored shell trap state from the parent shell/session; before exec they normalize the child to an empty blocked-signal mask plus default dispositions for catchable signals, so reviewed automation does not depend on hidden shell traps or wrapper signal masks (`docs/30-architecture/capshell-signalstate-posture-v0.md`).
- Launch scheduling state is also explicit by posture: runners/wrappers do not inherit ambient `nice` / scheduler-policy state from the parent shell/session; before exec they normalize the child to the default non-real-time time-sharing policy with neutral nice value (`0`), so reviewed automation does not depend on hidden service-manager, wrapper, or login-shell CPU bias (`docs/30-architecture/capshell-scheduling-posture-v0.md`).
- Launch CPU affinity / placement is also explicit by posture: runners/wrappers do not inherit ambient `taskset` / `sched_setaffinity()` / `CPUAffinity=` / process-affinity masks from the parent shell/session or wrapper; before exec they normalize the child to the default eligible CPU set for the active execution compartment, so reviewed automation does not depend on hidden service-manager, wrapper, or desktop-session core pinning (`docs/30-architecture/capshell-affinity-posture-v0.md`).
- Launch resource-controller envelope posture is also explicit by posture: runners/wrappers do not preserve inherited cgroup membership, service-manager `CPUQuota=` / `MemoryMax=` / `TasksMax=` policy, Job Object resource limits, or equivalent wrapper/session resource-controller narrowing as reviewed workflow meaning; before exec they normalize the child to the default resource-controller envelope for the active execution compartment, so reviewed automation does not depend on hidden shell/service-manager CPU, memory, IO, or process-count ceilings (`docs/30-architecture/capshell-resource-envelope-posture-v0.md`).
- Launch execution-domain / personality state is also explicit by posture: runners/wrappers do not inherit wrapper-/session-defined `setarch` / `Personality=` / legacy personality state; before exec they normalize the child to the default native execution-domain / personality baseline, so reviewed automation does not depend on hidden service-manager, wrapper, or login-shell ABI/emulation quirks (`docs/30-architecture/capshell-personality-posture-v0.md`).
- Launch confinement label/profile state is also explicit by posture: runners/wrappers do not preserve wrapper-/service-manager-selected `setexeccon()` / `/proc/pid/attr/exec` overrides, `SELinuxContext=` / `AppArmorProfile=` / `SmackProcessLabel=` policy, or equivalent execution-label state; before exec they normalize the child to the default confinement label/profile baseline for the active execution compartment, so reviewed automation does not depend on hidden service-manager, wrapper, or login-shell mandatory-access selection (`docs/30-architecture/capshell-mac-profile-posture-v0.md`).
- Launch peer-inspection posture is also explicit by posture: runners/wrappers do not preserve host-default same-user debugger / tracer / procfs visibility as reviewed workflow meaning; before exec they normalize the child to a non-dumpable / non-peer-inspectable baseline, so reviewed automation does not depend on hidden sibling-process inspection channels (`docs/30-architecture/capshell-peer-inspection-posture-v0.md`).
- Launch launcher-lifetime posture is also explicit by posture: runners/wrappers do not preserve wrapper-imposed parent-death signals, inherited Job Object kill-on-close scoping, or equivalent die-with-launcher/session linkage as reviewed workflow meaning; before exec they keep the child not additionally tied to transient launcher/wrapper death inside the active execution compartment, so reviewed automation does not depend on hidden shell/service-launcher liveness (`docs/30-architecture/capshell-launcher-lifetime-posture-v0.md`).
- Launch syscall-admission posture is also explicit by posture: runners/wrappers do not preserve wrapper-installed `seccomp()` / `PR_SET_SECCOMP` filters or service-manager `SystemCallFilter=` policy as reviewed workflow meaning; before exec they normalize the child to the default syscall-admission baseline for the active execution compartment, so reviewed automation does not depend on hidden wrapper/service-manager sandbox profiles (`docs/30-architecture/capshell-syscall-filter-posture-v0.md`).
- Launch privilege posture is also explicit by posture: runners/wrappers guarantee **no privilege gain across exec**; reviewed automation must not widen authority through setuid/setgid bits, file capabilities, or ambient capability carry-over, and platforms with one-way `no_new_privs` / equivalent controls should use them before exec (`docs/30-architecture/capshell-privgain-posture-v0.md`).
- Launch caller identity is also explicit by posture: runners/wrappers do not preserve invoking login-session identity, supplementary-group widening, or borrowed access-token state as reviewed workflow meaning; instead they use a provider-/membrane-fixed least-privilege executor identity or fail closed if the active runtime cannot pin that posture (`docs/30-architecture/capshell-credential-baseline-posture-v0.md`).
- Launch network posture is also explicit by posture: runners/wrappers do not preserve ambient socket constructors, host-global DNS / resolver state, or an implicit “normal machine networking” baseline at `capshell.exec`; Phase 1 adds no reviewed per-step raw socket / resolver surface, so any portable network behavior must stay on explicit `portal.net` / `CH-NETLEASE` seams or fail closed (`docs/30-architecture/capshell-network-posture-v0.md`).
- Launch local-IPC posture is also explicit by posture: runners/wrappers do not preserve filesystem-path AF_UNIX sockets, abstract-namespace reachability, session/system/user bus defaults, or autolaunch conventions at `capshell.exec`; Phase 1 adds no reviewed per-step AF_UNIX / session-bus surface, so any local IPC that matters to workflow meaning must stay on explicit CH-STDIO / CH-FDSET / route-bound service seams or fail closed (`docs/30-architecture/capshell-local-ipc-posture-v0.md`).
- Launch filesystem posture is also explicit by posture: runners/wrappers do not preserve host-global absolute-path reachability, process-global root/mount-namespace visibility, or a hidden “normal host filesystem” baseline at `capshell.exec`; Phase 1 adds no reviewed per-step `open(path)` / namespace-lookup surface, so any filesystem authority that matters to workflow meaning must stay on explicit CH-CWD / CH-FDSET / D-NS / D-POWERBOX seams or fail closed (`docs/30-architecture/capshell-filesystem-posture-v0.md`).
- Launch nondeterminism posture is also explicit by posture when D-NONDET is enabled: runners/wrappers do not preserve ambient `clock_gettime()` / timer-style time reads, host wall-clock / monotonic defaults, ambient `getrandom()` / machine-RNG behavior, or a hidden “normal machine clock/RNG” baseline at `capshell.exec`; Phase 1 adds no reviewed per-step clock / entropy surface, so any portable time/entropy behavior must stay on explicit `portal.clock` / `portal.entropy` seams or fail closed (`docs/30-architecture/capshell-nondet-posture-v0.md`).
- Even when CH-ENV is non-empty, capshell v0 rejects startup/resolution env hooks (`PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, `BASH_FUNC_*`) rather than silently scrubbing them, so the reviewed execution shape matches the executed one (`docs/30-architecture/capshell-env-startup-posture-v0.md`).
- Child env also stays **exact**: runners do not append a convenience baseline or synthesize `HOME`, `PWD`, `TMPDIR`, `TERM`, locale/timezone, or `XDG_*` from host session, cwd, tty, or request context state; if compatibility needs such variables, they must appear explicitly in CH-ENV (`docs/30-architecture/capshell-env-baseline-posture-v0.md`).
- Integrated capshell startup is explicit-only: the shell/runner does not consult host/user/project rc/profile files or per-directory hooks (`/etc/profile`, `~/.profile`, `~/.bashrc`, `.envrc`, `.env`, venv activation) when establishing a session or reacting to prompt/cwd changes (`docs/30-architecture/capshell-startup-profile-posture-v0.md`).
- Integrated/front-end capshell does not run a hidden shell-expansion pass before execution: globbing, `~` lookup, brace expansion, `$VAR` / `${...}`, `$(...)`, process substitution, word splitting, and pathname expansion stay out of Phase 1 on the capshell side, so those spellings remain literal unless an explicitly chosen interpreter later expands them under its own semantics (`docs/30-architecture/capshell-word-expansion-posture-v0.md`).
- Integrated capshell also stays off a portable terminal/job-control plane: `capshell.exec` does not imply PTY allocation, controlling-terminal ownership, process-group/session control, or `fg` / `bg` / `jobs` semantics, and any “keep running in background” story must route through D-JOBS / D-BGLEASE instead (`docs/30-architecture/capshell-job-control-posture-v0.md`).
- Portable interruption also stays off a shell-owned signal plane: front-ends may map local gestures such as Ctrl-C into explicit cancellation of the bound request/workflow, but `capshell.exec` does not imply signal-send rights, jobspec targeting, or shell-exit/SIGHUP lifecycle semantics (`docs/30-architecture/capshell-interrupt-cancel-posture-v0.md`).

References: RFC-0046, RFC-0115, RFC-0117.
