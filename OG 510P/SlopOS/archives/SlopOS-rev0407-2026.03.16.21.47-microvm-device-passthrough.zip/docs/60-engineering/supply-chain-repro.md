# Supply chain security & reproducibility (day 0 posture)

## Threats
- dependency poisoning, compromised CI/build infra, tampered artifacts, rollback installs

## Practices (initial)

### Toolchain trust seam (optional but high leverage)

Classic “trusting trust” attacks remind us that reproducible builds alone don’t guarantee the compiler corresponds to its source. We keep two optional hardening seams:

- **D-BOOTSTRAP**: keep a path toward a reduced, explicit bootstrap seed and eventually a bootstrappable toolchain chain (BP0–BP2), without making it a Phase‑1 dependency.
- **D-DDC**: for release profiles, optionally run **diverse double-compiling** gates for the compiler/toolchain used to build trusted artifacts, and bind the outcome into provenance (CH-PROV `evidence[]`).

See: RFC-0061; refs: REF-THOMPSON-TRUST, REF-WHEELER-DDC, REF-BOOTSTRAPPABLE-BUILDS, REF-GUIX-FULLSOURCE.



Design seam: D-FPM (functional build graphs) is optional, but we design provenance and updates so it can be adopted later without re-architecting.
- pin toolchains and dependencies for trusted artifacts
- signed provenance attestations (layout + steps) (REF-IN-TOTO)
- canonical provenance payload schema: CH-PROV v0 (bound via CH-BOOT `prov_attestation_digest`)
- optional: SBOM inventory as a pinned artifact (CH-SBOM) bound to the same deployment digests; attach full SPDX/CycloneDX SBOM docs via CH-AREF when needed; keep exports policy-scoped (D-SBOM; RFC-0091)
- optional: VEX exploitability statements as a pinned artifact (CH-VEX) bound to the same subject digests; link to OpenVEX/CSAF/CycloneDX docs via CH-AREF when needed; keep exports policy-scoped and treat as non-authoritative evidence (D-VEX; RFC-0092)
- standardized signature envelopes over payload digests (CH-SIGENV) to avoid type/subject confusion; optional keyless signing profiles (D-SIGENV/D-KEYLESS; RFC-0093) (REF-DSSE; REF-SIGSTORE-KEYLESS; REF-SIGSTORE-BUNDLE)
- transparency log consideration/anchoring for signed digests (e.g., Rekor; D-TLOG) (REF-SIGSTORE-REKOR)
- optional: repository metadata with survivable key rotation and freeze/rollback resistance (TUF/Uptane; D-TUF; RFC-0079)
- reproducible build checks in CI (REF-REPRODUCIBLE-BUILDS)
- optional: functional build graphs (Nix/Guix) can emit a closure manifest + **CH-DERIV** records; these can be treated as inputs to CH-PROV (e.g., in `proof_bundle`) without bloating the verifier (REF-NIXOS-JFP10, REF-NIX-HOWNIX, REF-GUIX-FPM13)
- optional: atomic deployments + rollback for the base OS image (rpm-ostree/OSTree pattern) can make “what ran” a digest-addressed artifact and reduce upgrade brick risk (REF-RPM-OSTREE, REF-FEDORA-ROLLBACKS)
- optional: microkernel ecosystems show the same operator need: integrity-protected package feeds with on-target update and routine rollback (Genode depot/Sculpt) can keep compositions modular without turning "update" into mutable filesystem surgery (REF-GENODE-PKG, REF-GENODE-SCULPT, REF-GENODE-UPDATE-ROLLBACK)

## Release profiles (sketch)
- Dev profile: fast iteration (A0/A1 evidence)
- Assurance profile: strict provenance + reproducible artifacts supporting A2/A3 claims

## Proof-carrying provenance (flagship target)

v0 posture is pinned in `docs/60-engineering/pcp-posture-v0.md`:
- **release-only PCP** (produced in CI/release tooling),
- boot-time verification stays small: IF-BOOT verifies *binding* when enabled, but does not validate bulky proofs/models.

Minimal binding hook (still the seam): CH-BOOT `prov_attestation_digest` is optional (payload: CH-PROV v0); if present, IF-BOOT must verify it is valid and corresponds to the booted artifact digests (PO-PROV-BIND). This supports an aspirational claim C-PROV-2 while keeping C-PROV-1 as the baseline.
## Claim linkage
- C-BOOT-1 and C-PROV-1 depend on this doc; other security claims must not quietly assume supply-chain properties.
- C-PROV-2 (if pursued) adds an end-to-end binding requirement and must be explicitly scoped to the chosen deployment profile and verifier.