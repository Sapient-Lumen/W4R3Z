# D-PCP v0 posture: release-only proof-carrying provenance

**Status:** pinned v0 posture (no new schemas; tooling-only interop).  
**Decision surface:** D-PCP (see `docs/30-architecture/decision-map.md`).

## One-sentence
Proof-carrying provenance (PCP) is a **release pipeline artifact**: we bind what boots to signed, digest-addressed provenance (and optional transparency receipts), while keeping boot-time verification small and deterministic.

## v0 posture (hard decision)
**v0 posture: release-only PCP.**

- PCP is produced **at release time** (CI/build farm) and shipped alongside update metadata.
- IF-BOOT may verify *binding* if a profile enables it, but IF-BOOT does **not** validate proofs/models/large evidence corpora.
- Higher-assurance profiles MAY require that a deployment root includes:
  - `digest(CH-PROV v0)` and a validating `CH-SIGENV v0` over that digest (D-SIGENV), and
  - optionally a `CH-TLOG v0` anchor (D-TLOG) and/or witness-backed checkpoint policy (D-WITNESS).

Non-goals for v0:
- “PCP on every boot” (boot should remain offline-capable and non-brittle).
- making the kernel or IF-BOOT speak a specific transparency API.
- embedding bulky proof bytes in the boot path.

## What “proof-carrying” means in SlopOS artifacts
PCP is a *digest-bound bundle* shaped around existing seams:

- **Subject:** the booted deployment is already digest-addressed (CH-BOOT `root_digest`, profile hash suite; D-BOOT/D-HASH).
- **Provenance statement:** CH-PROV v0 points at the subject digests and records build steps / derivations (CH-DERIV) and other typed evidence pointers via CH-AREF (D-AREF).
- **Signature envelope:** CH-SIGENV v0 signs `(payload.schema, payload.digest)` (prevents type confusion; D-SIGENV).
- **Optional transparency receipt:** CH-TLOG v0 anchors the signed digest into an append-only log state (D-TLOG/D-WITNESS).

This supports C-PROV-1 as a baseline (“attest build”) and makes C-PROV-2 (“end-to-end binding”) achievable *without* putting proof validators in the boot path.

## Profile implications (A–D)
We keep one substrate and let profiles dial requirements:

- (A) **Secure workstation:** default dev channels accept “no PCP” during iteration; high-assurance channels MAY require CH-PROV+CH-SIGENV and allow offline verification.
- (B) **Cloud micro-VM substrate:** fleet policy can require PCP for *all* promoted images; transparency anchoring is attractive for multi-operator auditing.
- (C) **Embedded / separation appliance:** strongest fit for “PCP required” (static compositions, tight update channels); prefer fewer roots and smaller verifier footprints.
- (D) **Agent/automation OS:** PCP is a safety primitive for toolchains and policies; agents can reason over receipts and refuse to act when provenance is missing/ambiguous.

## SCITT interop (optional, tooling-only)
If we want to interoperate with external “transparency-backed statements” ecosystems without importing their protocols into privileged code:

- Treat `digest(CH-PROV v0)` (or `digest(CH-UPD v0)`) as the **statement subject**.
- Treat CH-SIGENV as our canonical “statement signature” object (DSSE-like digest+type binding).
- Treat CH-TLOG as our minimal “log receipt anchor” seam.

Release tooling MAY additionally emit a SCITT-compatible statement/receipt bundle for ecosystem interoperability (REF-SCITT-ARCH, REF-SCITT-SCRAPI, REF-SCITT-CCF-RECEIPTS). The archive stays strict: privileged code consumes **our** schemas; SCITT formats remain an *interop layer*.

## Assurance anchors
- **PO-PROV-BIND:** if CH-BOOT includes a provenance digest, IF-BOOT verifies it is valid and bound to the booted root/policy (see `docs/20-assurance/proof-obligation-registry.md`).
- **I-PROV-CHAIN-1:** provenance and subject digests remain coherently bound (no “floating” attestations).
- **I-TLOG-1 (optional):** if transparency anchoring is claimed, anchors must verify as valid receipts.

## Evidence hooks
- **EVID-2026-212:** PCP posture drift gate + wiring checks (prevents “PCP means everything at boot” drift and keeps SCITT/receipt discussion tooling-only).

