# IDL digest + ordinal policy (D-IDL)

Goal: make interface identity, code generation, and on-wire dispatch **deterministic** and **upgrade-safe**, without forcing every ecosystem surface to be “closed forever.”

This document has two parts:
1) how to compute and pin `idl_digest` (CH-IFACE.idl_digest / CH-ORD.idl_digest), and
2) how to assign and evolve `method_id` (CH-CAPRPC.method_id) safely.

## 1) `idl_digest` must be over a canonical representation

Rule: `idl_digest` is a digest of a **canonical IR**, not “whatever text happened to be in a file.”

Why:
- text formats often have multiple equivalent spellings (whitespace, ordering, imports),
- some IDLs do not guarantee stable serialization order,
- we want drift gates that are resilient to harmless formatting changes.

### Recommended canonicalization strategies
Pick one per IDL family and make it part of the build contract.

- **Protobuf**: digest the deterministic serialization of a `FileDescriptorSet` produced by `protoc --descriptor_set_out` (ideally with imports included). Use descriptor sets as the canonical IR rather than `.proto` text. (REF-PROTOBUF-TECHNIQUES)

- **Cap'n Proto**: treat the schema’s **unique IDs** as the canonical identity for files/types/interfaces; pin the IDL digest over the compiled schema (or a stable extracted schema representation) rather than the source text alone. (REF-CAPNP-IDS)

- **FIDL/Wire-oriented IDLs**: prefer a compiler-produced canonical IR; avoid hashing raw source.

- **WIT** (Wasm Component Model): digest the compiler-produced canonical package graph (AST/IR) rather than raw `.wit` text (exact canonicalizer is a tooling choice; the rule is “hash a canonical IR”).

If we support multiple IDLs simultaneously, the canonicalization algorithm must be explicit and versioned as part of the generator identity.

## 2) Method ordinals (`method_id`) must be stable

`CH-CAPRPC.method_id` is the selector used for dispatch. The classic failure modes:
- accidental renumbering when code reorders methods,
- collisions when two bindings compute ids differently,
- reuse of an old ordinal for a different semantic method.

### Two recommended policies

#### A) Open interfaces: hash-derived ordinals
For *open* interfaces (CH-IFACE.openness=`open`), strongly prefer hash-derived ordinals:
- adding a new method does not require renumbering existing methods,
- old servers can safely return `UNKNOWN_METHOD` on a method they don’t implement,
- the ordinal algorithm itself becomes a stability anchor.

Prior art: Fuchsia/FIDL computes ordinals from a SHA-256 hash of a fully-qualified method name and reserves bits to keep the space structured. (REF-FUCHSIA-FIDL-LANG; REF-FUCHSIA-RFC-0020; REF-FUCHSIA-FIDL-BINDINGS)

**Candidate policy for CH-CAPRPC v0 (u32 method_id):**
- Define a canonical string `S = <iface_name> "/" <method_name>` (UTF-8, no trailing NUL).
- Compute `H = SHA256(S)`.
- Let `x = first_4_bytes(H)` interpreted as a big-endian u32.
- Clear the high bit: `method_id = x & 0x7fffffff`.
- Reserve the high-bit space `0x8000_0000..0xffff_ffff` for runtime/framework internal selectors.

Notes:
- `iface_name` must be treated as stable for the interface family; changing it changes every ordinal.
- Collisions are *possible* with 31-bit space; generators MUST detect collisions within the declared method set and fail closed.
- If collision risk becomes a real constraint, evolve to a u64 ordinal in a future CH-CAPRPC revision.

#### B) Closed interfaces: explicit numeric ordinals
For *closed* interfaces (privileged/high-assurance surfaces), prefer explicit numeric ordinals:
- ordinals are assigned intentionally,
- removed ordinals are reserved forever,
- semantic changes generally mint a new interface identity.

This pairs well with “new iface digest + adapter” discipline (D-APIEVO).

## 3) Pinning: CH-ORD as a drift guard

To keep everyone honest, represent the mapping as data:
- Generate a **CH-ORD v0** ordinal manifest from the canonical IDL IR.
- Bind it to:
  - the interface pin (`iface_digest`),
  - the canonical IDL digest (`idl_digest`),
  - the generator identity/version.

Tooling gates should:
- reject any CH-ORD that reuses an ordinal for a different name,
- reject any ordinal collision,
- reject any use of reserved ranges.

## 4) Interaction with CH-IFACE

- For **closed** interfaces, it is usually appropriate for CH-IFACE to carry `idl_digest` (the interface pin changes when the definition changes).
- For **open** interfaces, it is often preferable for CH-IFACE to **omit** `idl_digest` so that `iface_digest` can remain stable as methods are added; the evolving definition is then pinned via per-release IDL digests and CH-ORD artifacts.

This keeps “wire identity” stable while allowing additive evolution, and makes `UNKNOWN_METHOD` meaningful.
