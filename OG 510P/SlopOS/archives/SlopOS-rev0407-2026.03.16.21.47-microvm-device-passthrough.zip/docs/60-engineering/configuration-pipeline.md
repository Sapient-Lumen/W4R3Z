# Configuration pipeline (human config → CH-CFG) and generations

Goal: make **policy/config changes** reviewable, reproducible, and rollback-friendly by treating CH-CFG as a small signed artifact produced by deterministic tooling — not a hand-edited blob and not an in-place mutation.

This is an *engineering posture* layered on:
- **IF-CFG / CH-CFG** (privileged config loader)
- **D-ATOMICUPD / CH-BOOTSEL** (atomic deployments + bounded-tries + health commit)
- **D-EXPLAIN** (authority diffs + receipts) for any change that widens authority

Inspiration: Nix/NixOS “declarative config + generations” model (a new generation per evaluation; bootable rollback by selection).

Refs: REF-NIXOS-MANUAL, REF-NIXOS-JFP10, REF-NIX-MANUAL-ROLLBACK.


## Principle: CH-CFG is compiled output
Treat CH-CFG as the output of a deterministic “config compiler”:

- Human-facing authoring inputs may be:
  - a module system (NixOS-like),
  - a small DSL,
  - or a typed YAML/JSON authoring format.
- **Normative bytes are CH-CFG canonical CBOR** (I-ENC-1).
- The privileged core only does: **decode → validate → apply**, fail-closed.

Rule: the config compiler is *not* privileged; it is a build/admin tool whose outputs are audited via digests, signatures, and receipts.


## Generations model (rollback as UX)
Define a “config generation” as:
- the digest of a validated **CH-CFG** (and optionally its signed envelope),
- plus pointers to the deployment it is paired with (if any).

Recommended behavior:
- Each `apply` produces a new generation record and leaves prior generations available for rollback.
- Boot binds the active `cfg_digest` in CH-BOOT (already) and records the generation number/tag for human ops.
- Rollback is implemented as a deterministic selection of a prior generation:
  - either by selecting a prior deployment (D-ATOMICUPD),
  - or by selecting a prior CH-CFG for the same deployment when policy/config is updated independently.

Garbage collection:
- keep the privileged core out of GC; user space decides retention.
- retention policy SHOULD keep at least `N` last-known-good generations and any “pinned” audit targets.


## Tight integration points
### 1) Pair config changes with authority diffs (D-EXPLAIN)
When a config change **widens authority** (new routes, new portal grants, new device exposure):
- compute a CH-CAPDIFF preview against the currently active configuration,
- require explicit approval and emit a CH-RECEIPT bound to the shown diff.

This turns “config drift” into an auditable workflow rather than an accident.

### 2) Pair high-risk config changes with bounded-tries activation
For changes that can brick the box (boot-critical services, storage layout, device posture):
- stage the change as a **pending** generation with bounded tries (CH-BOOTSEL),
- commit only after the health predicate marks success (RFC-0074).

### 3) Treat migrations as explicit, compatibility-scoped, and snapshot-gated
NixOS has a well-known footgun: rolling back code does not automatically roll back **mutable data schema**.
We should make “rollback safety for state” a first-class *operator-visible* contract:

- declare **data contracts** (per-dataset reader/writer compatibility) in CH-CFG (`data_contracts`) — see RFC-0097,
- prefer **expand/contract** style migrations (forward-compatible reads) where feasible,
- when a migration is **breaking**, require an explicit snapshot barrier (D-PERSIST) and record it so rollback is not “mysteriously unsafe.”

Rule: rollback safety is a product feature; irreversible state transitions must be explicit and testable.


## Suggested artifact hygiene
Optional but recommended conventions (purely tooling-level; no new kernel surface):

- Include a `cfg_source_digest` (git tree hash / flake lock digest / module set digest) in the signed metadata that accompanies CH-CFG.
- Include a `cfg_tool_digest` (compiler version) to make “who produced this” auditable.
- Include the active CH-CFG digest in any support bundles (CH-SNAPSHOT) and in replay bundles (CH-RRBUNDLE) so incidents can be reproduced with the same policy.


## Evidence plan (cheap, high leverage)
E1:
- golden tests: given pinned authoring inputs, the compiler emits identical CH-CFG bytes (canonicalization tests).
- negative tests: reject unknown keys, invalid bounds, and authority-widening changes without receipts.

E2:
- property: “rollback selection is deterministic and non-amplifying” for a bounded set of generations.
- drift tests: diff tool produces stable CH-CAPDIFF across equivalent encodings.
