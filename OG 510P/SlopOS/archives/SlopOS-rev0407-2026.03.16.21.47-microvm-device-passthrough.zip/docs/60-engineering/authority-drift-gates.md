# Authority drift gates (wallet-first review discipline)

Goal: make **authority widening** a boring, deterministic CI failure.

In most ecosystems, least-privilege breaks down in the last mile:
- wrappers drift,
- scripts accumulate “just one more” capability,
- and nobody notices until an incident.

This archive’s posture is to treat “what authority does this thing run with?” as a **reviewable artifact**, not an emergent property.

## Building blocks
- **CH-PLEDGE v0**: closed-world effect/promise tokens for voluntary self-restriction.
- **CH-WALLET v0**: non-authoritative authority summary (kinds/rights/tokens + descriptor digests).
- **wallet_core_digest**: a stable digest over a normalized authority projection (defined in CH-WALLET); the only Phase-1 wallet binding key.
- **CH-CAPDIFF v0** (optional, D-EXPLAIN): bounded authority diffs for explainability.

See: RFC-0115 (D-CAPSHELL) and RFC-0116 (wallets).

## Recommended workflow
### 1) Declare a baseline wallet for each automation unit
For each job/component/runbook you want drift-gated:
- declare a baseline **pledge token** set (CH-PLEDGE tokens), and
- declare a baseline **wallet core** (cap kinds/rights + descriptor digests).

Store the baseline as canonical CH-WALLET bytes (or a normalized textual form that compiles to CH-WALLET). The baseline is a review artifact, not a capability container or import source.

### 2) Compute the stable digest used for gating
CI computes:
- `wallet_core_digest(current)` from the emitted wallet (drop volatile fields; deterministically sort; canonical-encode; hash), and
- compares it to the pinned baseline digest.

Rule: **widening is a failure**.
- new CH-PLEDGE token → fail
- new `cap_kind` → fail
- broader rights set for an existing kind → fail
- new high-risk descriptor digest (e.g., new net lease category) → fail

Narrowing is allowed, but should still be surfaced in review so the operator understands behavioral changes.

### 3) Bind drift decisions into transcripts/receipts
When D-EXPLAIN is enabled, prefer receipts that include:
- `wallet_core_digest`, and
- `capdiff_digest` (CH-CAPDIFF) relative to the approved baseline.

This makes “why did this job have network authority?” answerable from evidence artifacts.
Wallet contents remain summary-only: CI may compare wallet cores, but it must not resolve or acquire authority from a wallet artifact.

### 4) Seal after initialization
The strongest drift gates are paired with one-way tightening:
- enter capmode / close introducers (D-CAPMODE),
- seal view roots where applicable (D-SEAL), and
- ensure portals are the only acquisition surface for high-risk resources.

If a component cannot be sealed, treat it as a **review exception** (the drift gate still helps, but the risk posture is different).

## Practical tips
- **Keep baselines small and grouped**: one wallet per unit of review. If a unit needs “sometimes network,” split it into two units with different wallets.
- **Prefer descriptor digests over enumerating instances**: e.g., describe the *type* of network lease, not a transient session id.
- **Make violations noisy and explainable**: surface a short authority diff in CI logs (cap kind + right + token deltas), and link to the wallet artifact.

## What this avoids
- “ambient glue” regressions (shell scripts quietly getting more authority)
- ad-hoc, narrative permission reviews
- security posture that depends on tribal knowledge
