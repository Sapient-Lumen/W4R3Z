# Release profiles (assurance + supply-chain posture)

Purpose: avoid one-size-fits-all releases by defining a small set of profiles that bind:
- assurance level targets (A0–A3)
- supply-chain posture (SLSA-like)
- boot/update expectations (TUF-like)
- reproducibility requirements

## RP0: Dev snapshots
- Claims: none beyond engineering intent (no C-BOOT-1/C-PROV-1 asserted)

- Evidence: A0/A1 ok
- Provenance: best-effort, pinned deps recommended
- Reproducibility: not required

## RP1: Assurance candidate
- Claims: may assert C-BOOT-1 for a pinned profile; does not assert C-PROV-1 unless reproducibility is demonstrated

- Evidence: includes E2 for critical state machines; begins E3 for MVP slice
- Provenance: signed artifacts + recorded build inputs
- Reproducibility: required for privileged core artifacts

## RP2: Assurance release
- Claims: asserts C-BOOT-1 and C-PROV-1 for the declared artifact set (scoped)

- Evidence: MVP slice reaches A2 (E3) for defined claims; A3 only for explicitly modeled properties
- Provenance: strong attestations (layout + transparency) + TUF-style update metadata
- Reproducibility: required; independent rebuild recommended/targeted

- Optional hardening seam: **toolchain trust gates** (D-BOOTSTRAP / D-DDC) can be enabled for RP2+ to reduce reliance on opaque bootstrap binaries and mitigate “trusting trust” via diverse double-compiling checks (RFC-0061).
