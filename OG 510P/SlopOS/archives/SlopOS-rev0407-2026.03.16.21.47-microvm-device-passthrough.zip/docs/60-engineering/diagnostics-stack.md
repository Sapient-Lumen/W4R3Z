# Diagnostics stack (logs, traces, replay, checkpoints)

Goal: make production incidents *debuggable and shareable* without turning diagnostics into an ambient exfiltration channel or growing the privileged core.

Design stance:
- keep the privileged core as an **action boundary** + **validator**
- standardize *artifacts* (CH-*) so user space can build powerful tooling (reverse execution, bisection, omniscient queries)
- keep exports explicit, redactable, and capability-mediated (I-OBS-1, I-RR-3)


## Artifact layers

### 1) CH-LOG (authoritative transcript)
CH-LOG is the canonical, policy-relevant record of privileged actions and outcomes.
- designed to be deterministic to decode (I-ENC-1)
- can be bound into evidence chains (D-TLOG) or provenance artifacts (CH-PROV)

Rule: CH-LOG is the “what happened” substrate. Everything else is optional acceleration.

### 2) CH-TRACE (optional observational traces)
CH-TRACE is a bounded, typed tracepoint stream (RFC-0015) for diagnostics and performance work.
- observational only (I-TRACE-1)
- exported under redaction policy (I-OBS-1)
- optional bounded prefilter predicates (CH-TPRED; D-TPRED)
- optional tracepoint descriptor manifest (CH-TPROBE; D-TPROBE) to bind probe IDs to field names/types/redaction for tools/predicates
- optional user-space trace processors for safe aggregation (CH-TRACEPROC; D-TRACEPROC)

Correlation convention (recommended):
- use CH-TPROBE `sem` tags (`corr_id`, `trace_id`, `span_id`, `parent_span_id`) to make traces joinable with inspect snapshots and receipts without changing CH-TRACE v0.
- snapshot tooling SHOULD preserve these identifiers (subject to CH-OBSPOL) so operators can pivot across CH-LOG ↔ CH-TRACE ↔ CH-INSPECT when triaging.

Rule: traces must never be treated as replay inputs. If replay needs it, it belongs in CH-RR.

### 2.5) CH-INSPECT (optional structured state snapshots)
CH-INSPECT is an optional **structured diagnostics snapshot** of a component's current state (counters, topology hints, mode flags), intended to reduce reliance on stringly "dump" endpoints.
- exported as canonical, bounded CH-INSPECT snapshots (no arbitrary JSON)
- reads/exports are capability-gated and redaction-aware (I-OBS-1)
- publishing should be cheap (prefer shared-memory regions that collectors snapshot)

Rule: CH-INSPECT answers "what is it like right now?"; it complements CH-LOG and CH-TRACE.


### 3) CH-RR (optional nondeterminism stream)
CH-RR pins the nondeterminism boundary for enabled D-RR profiles (RFC-0013).
- “replay determinism” is a *profile claim* (I-RR-1), not a universal promise
- D-NONDET eliminates ambient time/entropy so recorded inputs are explicit

Rule: CH-RR is the “inputs you must re-supply” stream, not a general log.

### 4) CH-CKPT (optional checkpoints)
CH-CKPT is an optional checkpoint bundle used to accelerate replay and support migration.
- cooperative seams are preferred to “transparent interception” (D-CHKPT)

Rule: checkpoints are optimizations and workflow enablers (fast reverse queries), not required for correctness.

### 5) CH-RRBUNDLE (shareable handoff)
CH-RRBUNDLE is a manifest that digests/binds a set of payloads for replay/audit handoff.
- required payloads: `rr_stream` + `log_stream`
- optional payloads: `kabi_stream`, `ckpt_manifest`, `ckpt_blobs`, and derived accelerators like `rr_index`

Rule: the manifest is the trust anchor; derived payloads (e.g., indices) are never evidence on their own.

### 6) CH-SNAPSHOT (support/incident snapshot bundles)
CH-SNAPSHOT is a bounded manifest for a **support bundle**: a shareable package of logs/traces/inspect snapshots and selected metadata for incident response and bug reports.
- bundles are redaction-scoped (I-OBS-1) and treated as sensitive objects
- entries reference payloads by digest (optionally via CH-AREF) so consumers can verify integrity
- unlike CH-RRBUNDLE, CH-SNAPSHOT does **not** claim replay determinism; it's for triage and correlation

Rule: prefer CH-SNAPSHOT for "help me understand" and CH-RRBUNDLE for "help me reproduce".


### 6.5) CH-CRASHCAP (crash capsules)
CH-CRASHCAP is an optional **crash report** manifest for a single failure event (panic/abort/fault), designed to be the default “useful bug report” artifact.
- binds the failure to environment digests (boot/config/component graph)
- references a bounded set of payloads (log/trace/inspect windows, and an optional dump such as a minidump/core)
- includes module identity (build IDs/digests) so tools can fetch symbols without shipping full images

Rule: CH-CRASHCAP is the small, failure-shaped cousin of CH-SNAPSHOT. Use it by default for crash reports; escalate to CH-SNAPSHOT only when needed.

See: RFC-0086, crash-capsule-schema-v0.


### 6.6) CH-TRIAGE (on-device triage rules)
CH-TRIAGE is an optional, pinned **rule set** that evaluates over CH-INSPECT snapshots and/or CH-CRASHCAP to produce bounded findings and **advisory** next-step requests (e.g., which snapshot entry kinds to assemble under which tier).
- triage is deterministic and bounded (no scripting VM)
- triage is non-authoritative: exporters still enforce CH-OBSPOL + capability gates

Rule: CH-TRIAGE helps make "collect less, explain more" the default. It should reduce the temptation to export raw traces/logs wholesale.

See: RFC-0087, triage-rules-schema-v0.




## Workflow patterns (what we want to make cheap)

### A) “Attach-a-replay” incident handoff
1. capture a bounded window (CH-LOG + CH-RR; optional CH-TRACE)
2. package as CH-RRBUNDLE
3. validate (PO-RR-BUNDLE) before consuming
4. reproduce deterministically in a harness (PO-RR-DETERMINISM)

Why: makes debugging and auditing a *transferable artifact* instead of a “try to reproduce it” ritual.

### B) “Search through time” and time-travel debugging (user space)
Tooling targets:
- reverse execution by replaying forward from checkpoints (rr-style)
- automated bisection to earliest failing point (FReD-style)
- queryable traces/value provenance layers (omniscient UX)

System responsibilities:
- stable schemas and canonical encoding so third-party tooling can flourish
- explicit nondeterminism sources (D-NONDET)
- explicit policy + consent for exports (D-PLUMB/D-EXPLAIN)

### C) “Minimize-and-share” (debugging and responsible disclosure)
Given a failing replay bundle:
- automatically minimize the window (log/replay slicing)
- optionally scrub/redact payloads under policy
- re-validate the minimized bundle and ship it as the bug reproducer

Why: a minimized replay is often the most actionable bug report.

### D) On-device triage → smallest useful snapshot
Given a crash capsule or periodic inspect snapshot:
- run CH-TRIAGE rules locally to emit bounded findings (tags/codes)
- assemble the smallest snapshot that satisfies the recommended entry kinds *under the active CH-OBSPOL*
- if escalation is recommended, route through an explicit operator/portal flow (and keep the resulting tier/policy digest audit-visible)

Why: moves incident workflows from "export everything" to "export the minimum that answers the question".


## Safety / privacy checklist

- **Capability gating:** replay/trace artifacts are sensitive objects; reading/exporting them must be explicit (I-RR-3).
- **Redaction:** exports must enforce I-OBS-1 (no secrets unless explicitly authorized and marked).
- **Boundedness:** buffers are bounded; overflow/drop is deterministic and fail-closed.
- **No hidden inputs:** replay profiles treat any unmodeled nondeterminism as divergence (I-RR-2).


## Mapping
- D-TRACE (RFC-0015), D-TPRED (RFC-0073), D-TRACEPROC (RFC-0068), D-INSPECT (RFC-0075), D-TRIAGE (RFC-0087), D-RR (RFC-0013), D-CHKPT, D-NONDET (RFC-0063)
- I-OBS-1, I-TRACE-1, I-INSPECT-1..2, I-RR-1..3, I-SNAP-1..2, I-TRIAGE-1..2
- PO-RR-DETERMINISM, PO-RR-BOUNDARY, PO-RR-BUNDLE, PO-TRACE-NOSTATE, PO-TPRED-VALIDATE/PO-TPRED-BOUNDS, PO-TRACEPROC-BOUNDS, PO-INSPECT-VALIDATE/PO-INSPECT-BOUNDS, PO-SNAP-REDACT/PO-SNAP-BIND, PO-TRIAGE-VALIDATE/PO-TRIAGE-EVAL
