# LLM/control-plane threats (pressure tests)

Threat model: LLM outputs are untrusted; attackers can influence prompts, context, and tool outputs.

## Primary attacker behaviors
- **prompt injection**: adversarial text causes the model to request unsafe actions
- **tool output spoofing**: untrusted tools return crafted data to steer proposals
- **authority laundering (sequence)**: model smuggles a privileged change via a sequence of individually “reasonable” requests
- **exfil via observations**: model coerces IF-OBS into leaking secrets
- **audit gaps**: actions occur without durable transcript bindings

## Required mitigations (design rules)
- **no direct effects** from text/model outputs (I-LLM-1; C-LLM-1)
- **schema-validated actions**: only CH-ACP actions; reject unknown fields/variants (I-ENC-1)
- **explicit authorization**: effects require explicit capability/approval token, bound to an action digest (I-AUTHZ-1)
- **observations are not authority**: tool outputs/observations may inform proposals but must not be the sole basis for acceptance; acceptance depends on explicit approvals/caps + pinned policy inputs (I-OBS-2; PO-OBS-NOTAUTH)
- **budgeting + expiry**: proposals and approvals expire; rate-limit/lock down on anomaly (I-TIME-1)
- **replayable transcript**: every accepted action is logged with schema version + digest + deterministic result (I-LOG-1)

Related: MiniScope proposes an automated least-privilege confinement framework for tool-calling agents; we treat it as supporting evidence for our approach (explicit, bounded grants + deterministic validators), not as a substitute for capability/approval discipline.
Refs: REF-MINISCOPE-ARXIV25.

## Notes on sequence laundering (explicitly scoped)
The hardest case is *composition*: an adversary need not propose a single obviously-privileged action. They can aim for a path where each step passes local validation but the sequence transfers/creates authority cumulatively.

Archive stance (for now):
- Phase 1 claim remains the narrow **I-LLM-1** seam: “text cannot create authority.”
- Full “no authority laundering via sequences” is **not** claimed absent an explicit, checkable sequence invariant.

Optional mitigation profile (when we choose to claim more):
- Enable a bounded `Ledger/Fuel` discipline in the validator semantics (I-LLM-2; PO-ACT-COMPOSE), so the accepted action space becomes model-checkable under declared bounds and any attempt to exceed them is fail-closed and logged.

## Evidence targets
- **E1** adversarial text/tool corpus (AC-LLM-*) showing rejected unsafe proposals and bad bindings.
- **E2** bounded model check:
  - baseline: “text cannot create authority” under the validator semantics
  - optional profile: bounded-sequence discipline via `Ledger/Fuel`
