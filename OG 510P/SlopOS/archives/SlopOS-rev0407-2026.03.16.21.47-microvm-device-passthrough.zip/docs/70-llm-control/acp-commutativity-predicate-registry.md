# ACP commutativity predicate registry (v0)

Purpose: make D-COMMUTE *operational* for the CH-ACP surface by pinning, per action kind:
- the **commutation predicate** (when A∘B == B∘A), and
- the **normalized observation boundary** used by commutativity tests.

Why this exists:
- `acp-action-kind-registry.md` pins conflict keys + stance + ordering boundaries, but
  commutativity also depends on **what is observable** and on the **exact predicate**.
- LLM planners can only safely reorder/batch actions when the predicate is explicit.
- Multicore/Hybrid scale only stays honest if commutativity claims are testable and drift-resistant.

Non-goals:
- This doc does **not** grant authority and does **not** change authorization semantics.
- This doc does **not** require any particular implementation strategy.

Normative references:
- D-COMMUTE: `docs/30-architecture/commutativity-and-interface-scalability.md` (REF-SCR-TOCS15)
- CH-ACP kinds + conflict keys: `acp-action-kind-registry.md`
- Conflict key encoding: `docs/30-architecture/conflict-key-schema-v0.md` (CH-CONFLICTKEY v0)
- Outcome receipt: `docs/30-architecture/acp-outcome-receipt-schema-v0.md` (CH-ACPOUT v0)
- State projection receipt: `docs/30-architecture/state-projection-schema-v0.md` (CH-SPROJ v0)

CI guardrail:
- `make lint` runs `tools/check_acp_commutativity_predicates.py` (EVID-2026-184).
  The guardrail fails if any ACP kind is missing an entry here or if required predicate/normalization anchors drift.

## Normalized observation boundary (ACP surface)

For swap-order commutativity tests (PO-COMMUTE-TEST), we define the default normalized observation for CH-ACP kinds as:

- **Per-action outcome**: the emitted CH-ACPOUT v0 for each action (or an equivalent stable digest-only outcome),
  normalized by ignoring any non-deterministic/ambient fields (timestamps, transport metadata).
  - Required comparison fields (minimum):
    - `action_digest`
    - `status` (+ `effect` when present)
    - `conflict_key_digest` (when applicable)
    - `order_digest` (when applicable; if the predicate allows commutation only across *different* keys, `order_digest` is compared only within the same key)

- **Final externally visible key-scoped state**: `sproj_digest = digest(CH-SPROJ v0)` for the derived `conflict_key_digest` of the action.
  - For kinds with a declared conflict key family, accept outcomes SHOULD include a CH-SPROJ receipt referenced from CH-ACPOUT `receipt_refs` (schema=`CH-SPROJ v0`) whose `key_digest` equals the derived `conflict_key_digest`.
  - If a kind does not yet emit a CH-SPROJ receipt (or its spec does not yet state what it covers), the commutativity harness MUST treat the kind as *not yet commutativity-tested* and record this as an open evidence gap.

This normalization keeps commutativity claims about **effects** and **stable receipts**, not about incidental timing.

## Per-kind predicates (v0)

Each entry below is keyed by the **kind token** from `acp-action-kind-registry.md`.

### `cfg.set_policy`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `policy.param` keys). Within the same key it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`, `order_digest` when present) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `policy.param` key.

### `cap.grant`
- Predicate: commutes across different `domain.id` keys. Within the same domain, `cap.grant` operations commute under set-union semantics (order-independent insertion); duplicate grants are idempotent.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `domain.quarantine`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `view.attach`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `view.slot` keys). Within the same slot it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `view.slot` key.

### `view.detach`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `view.slot` keys). Within the same slot it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `view.slot` key.

### `capshell.exec`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key + the workflow-visible output digest set for each action (content-addressed outputs when at-least-once-safe is claimed).

### `portal.attn.request`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `portal.clock.timeproof.sample`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `portal.net.request`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `portal.entropy.request`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `portal.jobs.submit`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `portal.background.request`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `domain.id` keys). Within the same domain it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `domain.id` key.

### `budget.mint`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `budget.issuer` keys). Within the same issuer it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `budget.issuer` key.

### `fcell.launch`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `cell.id` keys). Within the same cell it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `effect`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `cell.id` key.

### `fcell.kill`
- Predicate: commutes iff the derived `conflict_key_digest` differs (different `cell.id` keys). Within the same cell it is **ordered** and requires CH-ORDERTOK.
- Normalize: compare CH-ACPOUT (`action_digest`, `status`, `conflict_key_digest`, `order_digest`) + `sproj_digest = digest(CH-SPROJ v0)` for the derived `cell.id` key.
