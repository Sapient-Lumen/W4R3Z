# LLM-assisted control (ground floor; keep small)

We assume LLM-centric design/observation/control is useful, but we **do not** treat the LLM as trusted.
Design rule: **LLM proposes; deterministic validator executes** (or rejects).

## Goals (scoped)
- preserve C-CAP-1/<C-ISO-*> even under adversarial text (prompt injection)
- keep privileged effects behind explicit schemas (CH-*) + explicit auth (caps/approvals)
- make the control loop auditable and replayable

## Canonical docs
- `llm-threats.md`: attacker behaviors and mitigations
- `acp-action-schema-v0.md`: action IR (CH-ACP v0) used for validation
- `acp-action-kind-registry.md`: closed kind set + per-kind conflict keys/commutativity/ordering metadata
- `acp-validator-semantics.md`: small-step semantics for validator slice (model-checkable)
- `../30-architecture/request-context-schema-v1.md`: CH-REQCTX v1 request context (non-authoritative; required meta for CH-ACP proposals; veto-only narrowing)
- `../30-architecture/acp-outcome-receipt-schema-v0.md`: CH-ACPOUT v0 outcome receipt (stable digest-only result envelope; non-authoritative)
