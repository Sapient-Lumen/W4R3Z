# CH-ACP v0 (Action IR schema, informal)

Purpose: a small, deterministic intermediate representation for *proposed* privileged actions.
The validator (IF-ACP) accepts or rejects; **no other action format is executed**.

This file pins the **wire shape**. The *per-kind semantics* (conflict keys, commutativity/ordering stance, retry safety, and profile gates) are pinned in:
- `acp-action-kind-registry.md`.

## Design constraints
- total parsing (fail closed)
- canonical encoding (I-ENC-1)
- explicit effect typing; no “eval” or stringly-typed effects
- hashable (action digest) for authorization binding
- closed-world kinds: unknown kinds/fields reject deterministically

## Action shape (v0)

An action is:
- `kind`: one of a **closed** enum (see kind registry)
- `target`: an object/capability/config handle (typed)
- `params`: fixed fields per kind
- `preconditions`: optional assertions the validator can check
- `meta`: schema version, timestamps/expiry, provenance pointers, and (when required) ordering/conflict metadata

### Conflict keys and commutativity

For Hybrid + D-COMMUTE, each kind has a *declared* conflict key derivation and commutativity stance.
- When a conflict key must cross trust boundaries (validators/receipts/tests), represent it as `digest(CH-CONFLICTKEY v0)`.
- Validators SHOULD compute the derived conflict key digest from `target`/`params` and (when present) check it matches any supplied digest.

### Ordered actions

If a kind is specified as **ordered** (a non-commutative correctness boundary), the proposal MUST include:
- `meta.order_digest`: `digest(CH-ORDERTOK v0)` for the ordered stream scope,
- `meta.conflict_key_digest`: `digest(CH-CONFLICTKEY v0)` for the action conflict key,
- and enough scope identifiers in `target`/`params` for the validator to check the ordering token scope matches the derived conflict key.

Validators MUST fail closed if an ordered action is missing either digest, is expired, or has a mismatched scope (PO-ORDERTOK-VALIDATE; PO-CONFLICTKEY-VALIDATE).

### Request contexts (CH-REQCTX)

To keep workflows and audits **non-ambient** and replayable, every CH-ACP action MUST carry a non-authoritative request context reference:
- `meta.reqctx_digest = digest(CH-REQCTX v1)`

Rules:
- The referenced CH-REQCTX is **informational only** (I-REQCTX-3): it MUST NOT be used to grant privileged effects.
  - It MAY be used to **deny or narrow** behavior (deadline/cancel intent; call-chain veto hooks).
- Validators MUST fail closed if `reqctx_digest` is missing, cannot be resolved to canonical bytes, or fails CH-REQCTX validation (PO-REQCTX-VALIDATE; PO-ACT-REQCTX).
- Transcripts and outcome receipts SHOULD echo `reqctx_digest` as a digest-only observability field (CH-LOG v0; CH-ACPOUT v0).

Minimal profile note: embedded/minimal profiles can satisfy this requirement with a tiny CH-REQCTX v1 containing only `ctx_id` (and optional `parent_ctx_digest`), preserving A–D viability without forks.

### Outcome receipts

For the stable product surface (schemas + validators + receipts), IF-ACP validators SHOULD emit a non-authoritative outcome receipt for each validated action:
- **CH-ACPOUT v0** (ACP outcome receipt): binds `action_digest` and (when applicable) `conflict_key_digest` / `order_digest`, and can reference CH-DENY/CH-RECEIPT/other receipts by digest.
Receipt emission/persistence is policy/profile-controlled, but the receipt format is stable and closed-world (no stringly ad-hoc outcomes).

## Example kinds (seed; keep small)

These are representative members of the closed kind set; the normative list and metadata live in `acp-action-kind-registry.md`.

- `cfg.set_policy` (IF-CFG): set a named policy parameter within allowed bounds (**ordered** per parameter)
- `cap.grant` (IF-KABI): grant a capability along a derivation path (must prove attenuation; set-insertion semantics)
- `domain.quarantine` (IF-KABI): quarantine a domain and revoke its authority per policy (**ordered** within a domain)
- `view.attach` / `view.detach` (view service): mutate a single `(view_id,slot_id)` binding under explicit authorization (**ordered** within a slot)
- `budget.mint` (metering/budget svc, profile-gated): mint/split a short-lived operation budget lease (CH-BUDGET) from a payer meter (**ordered**)
- `fcell.launch` / `fcell.kill` (compat supervisor, profile-gated): launch/terminate a CH-FCELL-described foreign cell (**ordered** within a `cell.id` key; policy-killable)
- `capshell.exec` (capshell runner, profile-gated): execute an automation step under an explicit **CH-EXECPACK v2** execution pack (`exec_pack_digest = digest(CH-EXECPACK v2)`), which bundles **CH-REQCTX v1**, optional **CH-PLUMBMSG v0**, **CH-EFFCON v0**, **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, and **CH-FDSET v0** digests bound to a wallet core digest (**ordered** within a `domain.id` key)
- `portal.attn.request` (attention portal, profile-gated): submit a `notif_digest = digest(CH-NOTIF v0)` request to the mediated attention portal; lane-killable via `cfg.params.lane.portal.attn` (no ambient notification APIs); **ordered** within the action’s `domain.id` conflict key
- `portal.clock.timeproof.sample` (clock portal, optional; D-TIMEPROOF): request an authenticated time sample by binding `timereq_digest = digest(CH-TIMEREQ v0)`; validator invokes the portal (no ambient NTP) and emits CH-TIMEPROOF evidence; killable via `cfg.params.lane.portal.clock` + `cfg.params.lane.timeproof`
- `portal.net.request` (network portal, optional; D-NETLEASE): request a network lease by binding `netreq_digest = digest(CH-NETREQ v0)`; validator invokes the portal (no ambient sockets) and the portal returns a bounded CH-NETLEASE descriptor (plus an opaque network authority handle); killable via `cfg.params.lane.portal.net`
- `portal.entropy.request` (entropy portal, optional; D-NONDET): request an entropy handle/lease by binding `entreq_digest = digest(CH-ENTREQ v0)`; validator invokes the portal (no ambient RNG APIs) and the portal returns a bounded CH-ENTROPY descriptor (plus an opaque entropy authority handle); killable via `cfg.params.lane.portal.entropy`
- `portal.jobs.submit` (job portal, optional; D-JOBS): submit a background job request by binding `jobreq_digest = digest(CH-JOBREQ v0)`; validator invokes the portal (no ambient cron/alarms) and emits an outcome receipt; killable via `cfg.params.lane.portal.jobs`
- `portal.background.request` (background portal, optional; D-BGLEASE): request background execution/autostart grants by binding `bgreq_digest = digest(CH-BGREQ v0)`; validator invokes the portal (no ambient daemons/autostart registries) and emits an outcome receipt; killable via `cfg.params.lane.portal.background`

## Validator obligations (<PO-ACT-*>)

- reject unknown kinds/fields
- ensure kind-specific authorization is present and unexpired
- ensure capability effects are attenuation-only unless an explicit ADR allows otherwise
- compute and record conflict_key digests for receipts/transcripts when applicable
- if a kind is **ordered**, require an explicit ordering token (CH-ORDERTOK v0) referenced by digest and emit an order-visible receipt (`order_digest`)
