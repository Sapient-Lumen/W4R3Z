# Lessons from other systems (compressed, mapped to our specs)

Rule: each lesson must map to a D-*, C-*, I-*, IF-*, PO-*, or AC-* adjustment.
For a longer “feature seeds” list, see RFC-0003.

## Composition + authority (least privilege that survives contact with reality)

### Plan 9: namespaces as an access-control primitive
Lesson: treat namespaces as **composable views**, not global state.
Spec impact: model namespaces as capability-mediated **view objects**; treat union/overlay as an optional ergonomic layer.
Maps to: D-NS, I-VIEW-1/I-VIEW-2, PO-VIEW-RESOLVE/PO-VIEW-NOAMP.
Refs: REF-PLAN9, REF-PLAN9-NSCROSS.

### Bisbey/Hollingworth: name binding errors are protection errors
Lesson: classic security analyses found that many real vulnerabilities are not “crypto failures” but **name-binding failures** (confused paths, races, aliasing, and ambiguous resolution) that cause the system to act on a different object than the user intended.
Spec impact: treat name resolution as a *hazardous operation* that must be (a) capability-mediated (views), (b) deterministic, and (c) non-amplifying. Prefer handle-based flows (document handles, portal grants) and make any remaining path resolution explicitly view-scoped and race-resistant (no hidden re-parse in privileged code).
Maps to: D-NS, I-VIEW-1/I-VIEW-2, PO-VIEW-RESOLVE/PO-VIEW-NOAMP.
Refs: REF-BISBEY78.

### Confused deputy + Java stack inspection: scoped privilege boundaries for shared helpers
Lesson: the classic confused-deputy problem shows up again inside modern processes (plugins, helpers, compatibility layers): untrusted code induces trusted helpers to use the helpers' internal authority. Java's stack-inspection + `doPrivileged` model is a pragmatic lesson in making privilege elevation explicit, scoped, and explainable.
Spec impact: add an optional **D-BRACKET** seam (RFC-0118): privileged capabilities are “dark” by default while servicing inbound requests (borrowed mode), and privileged effects require an explicit, exception-safe privileged block; optionally attach bounded **CH-CALLCHAIN** provenance metadata via CH-REQCTX v1 for audit and deny-only routing.
Maps to: D-BRACKET, D-REQCTX (adjunct), I-BRACKET-1/2/3, I-CALLCHAIN-1, PO-BRACKET-SCOPE, AC-091.
Refs: REF-CONFUSED-DEPUTY, REF-JAVA-STACKINSPECT, REF-JAVA-DOPRIVILEGED.

### Plan 9/Inferno: 9P/Styx “service trees” are a scalable ops/debug interface
Lesson: hierarchical, file-like interfaces stay popular because they are **inspectable** and easy to script; a tiny uniform protocol can bridge local+remote service trees.
Spec impact: standardize an optional “service tree” convention and keep any 9P-like bridge strictly in user space (endpoint is just another capability).
Maps to: D-NS, I-VIEW-1/I-VIEW-2, PO-VIEW-RESOLVE.
Refs: REF-9P, REF-STYX-ARCH.

### Solaris Doors: fast local RPC as a capability you can pass (and optionally publish)
Lesson: local RPC primitives stay usable when the “service handle” is just another transferable object (and can be surfaced for discovery/ops without ambient globals).
Spec impact: keep our local RPC ergonomics sharp:
- service endpoints are first-class capabilities that can be passed, stored, and attached into service trees,
- optimize a local fast path (copyless where possible) without inventing a separate “special IPC.”
Maps to: D-CAPRPC, D-NS, D-ATTRFS, D-IOBUF.
Refs: REF-SOLARIS-DOORS.

### Wayland: compositor-mediated pixels + focus-gated input as a security boundary
Lesson: UI security improves when (a) clients can’t access other clients’ surfaces/pixels and (b) input is routed only to the focused surface; “global” features must move into a mediation layer.
Spec impact: add an optional D-UICAP contract: a user-space compositor/UI root exposes surfaces and input endpoints as object capabilities; high-risk UI authority (screenshot/screencast/remote control) becomes portal-mediated and lease-based.
See also: `docs/30-architecture/uicap-scope-posture-v0.md` (pins D-UICAP v0 scope; profile-shaped).
Maps to: D-UICAP, D-PLUMB, D-LEASE, D-VOLITION.
Refs: REF-WAYLAND-CH04, REF-XDG-PORTAL-SCREENSHOT, REF-XDG-PORTAL-SCREENCAST.

### Windows/AIX/macOS: “trusted path” entry + secure keyboard input
Lesson: credentials and high-risk approvals need a spoof-resistant entry point: a non-interceptable “secure attention” gesture that switches to a trusted UI mode, plus a way to suppress global key taps during sensitive entry.
Spec impact: if D-UICAP is enabled, reserve a secure-attention sequence (SAS) delivered only to the secure UI component; add an optional “secure input session” lease that temporarily disables non-authorized input intercept/inject paths when a surface is marked sensitive.
Maps to: D-UICAP, D-VOLITION, D-LEASE.
Refs: REF-MS-WINLOGON-SAS, REF-IBM-AIX-TRUSTEDPATH, REF-APPLE-TN2150-SECEVENTINPUT, REF-FUCHSIA-FOCUSCHAIN.

### QNX: bounded async notifications (“pulses”) complement message passing
Lesson: synchronous request/reply is great for effects, but awkward for interrupts/timers/backpressure; a tiny, fixed-size async message avoids “fake replies” and reduces coupling.
Spec impact: allow an optional CapRPC oneway/pulse method profile (interface-marked), with crisp “enqueue vs error” semantics and no silent drop.
Maps to: D-CAPRPC, D-EVENTBUS, I-CAPRPC-1.
Refs: REF-QNX-PULSES, REF-QNX-MSGSENDPULSE.

### kqueue/epoll/IOCP/Zircon: wait sets + object signals scale event-driven systems
Lesson: scalable servers and driver loops need a uniform way to wait on **many** event sources without devolving into polling or bespoke notification APIs. Mature OSes converge on (a) small per-object **signal bitmasks** and (b) an aggregating **wait set/port** that returns bounded event packets.
Spec impact: add an optional D-WAITSET seam: object signals + an efficient WaitSet primitive with bounded registrations and deterministic overflow behavior; ensure it composes with D-REQCTX cancellation/deadlines without introducing ambient time.
Maps to: D-WAITSET, D-REQCTX (adjunct), I-WAITSET-1/I-WAITSET-2/I-WAITSET-3, PO-WAITSET-BOUND/PO-WAITSET-NOAMP.
Refs: REF-ZIRCON-SIGNALS, REF-ZIRCON-OBJECT-WAIT-MANY, REF-ZIRCON-PORT-WAIT, REF-LINUX-EPOLL, REF-BSD-KQUEUE, REF-WIN-IOCP.

### io_uring / Windows I/O rings: batched submit+complete cuts boundary-crossing overhead
Lesson: for I/O-heavy workloads, “readiness” primitives aren’t enough—you want to enqueue many operations and reap completions with minimal transitions. Shared submission/completion rings (Linux io_uring; Windows I/O Rings) are a convergent pattern: bounded rings, submit tags, completion packets.
Spec impact: add an optional D-IOQ seam: a bounded IoQueue object whose operations target only explicit handles (no ambient paths) and whose completions integrate with D-WAITSET signals. Keep opcodes closed and the surface minimal; avoid importing a large programmable VM or per-driver bespoke fast paths.
Maps to: D-IOQ, D-WAITSET (adjunct), D-IOBUF (adjunct), I-IOQ-1/I-IOQ-2/I-IOQ-3, PO-IOQ-BOUND/PO-IOQ-NOAMP.
Refs: REF-LINUX-IOURING-PDF, REF-LINUX-IOURING-MAN7, REF-WIN-IORING-OVERVIEW.

### futex / WaitOnAddress / _umtx_op / Zircon futex: wait-on-address is the missing “sleep” primitive for user locks
Lesson: event loops need wait sets, but **threads** need an efficient way to block on contended mutexes/condvars without spinning or allocating heavyweight kernel objects per lock. Mature OSes converge on a futex-like **wait-on-address** primitive: uncontended operations are user-space atomics; only contention uses the kernel for queueing and scheduling.
Spec impact: add an optional D-UWAIT seam (RFC-0110): process-local wait/wake keyed by a normalized userspace address, bounded and chargeable waiter state (D-METER when enabled), deterministic failure modes, and optional integration with D-REQCTX (timeout/cancel) and D-RR (replay).
Maps to: D-UWAIT, D-REQCTX (adjunct), D-METER (adjunct), I-UWAIT-1/I-UWAIT-2/I-UWAIT-3, PO-UWAIT-BOUND/PO-UWAIT-ATOMIC.
Refs: REF-MS-WAITONADDRESS, REF-MS-WAKEBYADDRESSSINGLE, REF-MS-WAITFUNCS, REF-LINUX-FUTEX2, REF-LINUX-FUTEX-PAPER, REF-FREEBSD-UMTX-OP, REF-FUCHSIA-FUTEX.


### Linux robust futexes / Windows abandoned mutex: make “owner died” explicit (avoid permanent deadlock)
Lesson: fast user-space locks in shared memory have a sharp edge: if an owner thread/process terminates while holding the lock, other participants can block forever unless the kernel helps with cleanup. Mature OSes expose an explicit “owner died / abandoned” outcome (Linux sets an OWNER_DIED bit and wakes; Windows returns WAIT_ABANDONED) so the next acquirer can repair state or fail-close.
Spec impact: design an optional D-ROBUSTLOCK seam (RFC-0111) that composes with D-UWAIT: opt-in robust sets (quota-bounded) register lock-word addresses within writable/shared regions; on abnormal owner exit, kernel sets OWNER_DIED + wakes; next acquirer must call `make_consistent()` or abandon/restart.
Maps to: D-ROBUSTLOCK, D-UWAIT (adjunct), D-METER (adjunct), I-ROBUST-1/I-ROBUST-2/I-ROBUST-3, PO-ROBUST-BOUND/PO-ROBUST-NOREUSE.
Refs: REF-LINUX-ROBUST-FUTEX-ABI, REF-KERNEL-ROBUST-FUTEXES-TXT, REF-LINUX-GET-ROBUST-LIST, REF-FREEBSD-UMTX-OP, REF-WIN-WAIT_ABANDONED.


### RCU / QSBR / epoch reclamation: read-mostly sharing without contended locks
Lesson: real systems accumulate read-mostly shared structures (registries, routing tables, diagnostic state). The fastest pattern is “publish a new version, then reclaim old nodes after a grace period” (RCU/QSBR/EBR). Without a standard approach, ecosystems either over-lock (latency) or build bespoke lock-free schemes that eventually ship a use-after-free.
Spec impact: add an optional D-RCU seam (RFC-0112): a bounded GraceDomain for read-side critical sections (or explicit quiescent points) and `synchronize()` to obtain grace periods; pair with D-UWAIT/D-WAITSET for blocking waits and with supervision (D-SUPV) for stall handling.
Maps to: D-RCU, D-UWAIT (adjunct), D-WAITSET (adjunct), D-SUPV (adjunct), D-METER (adjunct).
Refs: REF-LINUX-RCU-WHATIS, REF-LINUX-RCU-CONCEPTS, REF-LINUX-RCU-CHECKLIST, REF-MCKENNEY-PERFBOOK, REF-HAZARD-POINTERS-MICHAEL, REF-FRASER-PRACTICAL-LOCK-FREEDOM, REF-HART-MEMRECL-IPDPS06, REF-LIBURCU.


### restartable sequences (rseq): CPU-local fast paths without atomics everywhere
Lesson: once you have multi-core + shared memory, high-throughput runtimes want per-CPU sharding (allocators/caches/counters). Linux’s rseq provides a disciplined escape hatch: tiny user-space regions intended to run start→commit on one CPU, and if the kernel preempts/migrates the thread before commit, execution is redirected to an abort handler. This enables a class of “atomicless” per-CPU updates (still bounded, still careful) without turning every operation into a syscall.
Spec impact: add an optional D-RSEQ seam (RFC-0113) with strict bounds (short, non-blocking regions; single commit point; bounded registrations), profile gating for D-NONDET posture (cpu/vcpu id exposure), and a clear story for D-RR determinism (disable/virtualize/record).
Maps to: D-RSEQ, D-SCHED (adjunct), D-NONDET (adjunct), D-UWAIT (adjunct), D-RR (adjunct), I-RSEQ-1/I-RSEQ-2/I-RSEQ-3, PO-RSEQ-BOUND/PO-RSEQ-NONDET.
Refs: REF-LINUX-RSEQ-DOC, REF-LINUX-RSEQ-MAN, REF-REDHAT-RSEQ-GLIBC, REF-LWN-RSEQ-GLIBC.


### IO-Lite / Zircon VMOs / Xen grant tables: copyless sharing needs immutability or explicit ownership rules
Lesson: shared memory becomes an ecosystem inevitability, but cross-trust sharing is unsafe unless receivers can rely on **immutable** payloads (or snapshot semantics) rather than “mutable-after-send”. IO-Lite’s immutable buffers, Zircon’s handle+rights VMOs with COW children/clones, and Xen’s grant-table mediated sharing all converge on “explicit sharing + bounded rights + safe mutation story”.
Spec impact: keep bounded-copy the default, but add an optional D-IOBUF seam: explicit shared-region buffer handles plus CH-IOBUF descriptors that allow linting and enforce “cross-trust implies immutable/snapshot” by profile; require contracted ring protocols for mutable streaming cases.
Maps to: D-IOBUF, D-CONTRACT (adjunct), I-SHARE-1, I-IOBUF-1/I-IOBUF-2, PO-IOBUF-VALIDATE, PO-IOBUF-OWNERSHIP, AC-073.
Refs: REF-IOLITE-OSDI99, REF-IOLITE-IMMUTABLE, REF-FUCHSIA-VMO-CREATE, REF-FUCHSIA-VMO-CHILD, REF-XEN-GRANTTABLE.


### Capsicum / CloudABI / WASI: ban ambient authority acquisition
Lesson: capability designs regress when “open-by-path / connect-by-name” sneaks back in.
Spec impact: enforce acquisition only via explicit views or explicit handoff; optional one-way capmode for post-init.
Maps to: D-CAPMODE, I-CAPMODE-1, PO-CAPMODE-ONEWAY.
Refs: REF-CAPSICUM, REF-CLOUDABI, REF-WASI-DESIGN.

### Capsicum Casper: capability services keep capmode usable
Lesson: capability mode adoption improves when “ambient-ish” facilities (DNS, network config, user/group lookup, sysctl reads) are moved behind **explicit, pre-opened service capabilities** so apps can enter capmode without giving up basic functionality.
Spec impact: document a standard user-space “capability services” pattern for compat layers: pre-open required service channels before sealing/capmode; close the root introducer; post-seal calls go through those explicit handles only.
Maps to: D-CAPMODE, D-SEAL, D-TRANS (adjunct), I-CAPMODE-1, I-SEAL-1.
Refs: REF-FREEBSD-LIBCASPER, REF-FREEBSD-CAPSICUM.

### Exokernel + Nemesis: application-level resource management (mechanisms over policy)
Lesson: kernels stay small (and adaptable) when they provide **secure multiplexing** and push most *resource management policy* into unprivileged runtimes (libOS/service managers). Nemesis makes the “isolation/exposure/responsibility” trade explicit for QoS and VM (including self-paging), which pairs naturally with capability-based meters/budgets and pressure signals.
Spec impact: keep D-METER/D-BUDGET/D-PRESSURE as **mechanistic** accounting + coarse signals; let user space implement admission control, caching, QoS, and paging policy. Treat user-mode paging as an optional profile seam (D-PAGER) with explicit fault routing and bounded message shapes.
Maps to: D-METER, D-BUDGET, D-PRESSURE, D-PAGER (optional), D-UPCALL (optional).
Refs: REF-EXOKERNEL-SOSP95, REF-NEMESIS, REF-NEMESIS-SELFPAGING, REF-MACH-EXTPAGER.



### Cap’n Proto / E: promise pipelining makes object-capability RPC usable over latency
Lesson: remote object calls must not pretend to be local; **promises + pipelining** avoid “one RTT per step” and keep ocap interfaces ergonomic across trust boundaries.
Spec impact: extend the optional D-CAPRPC profile to support **pipelined sends to unresolved references** (a “promise handle” in the CapRPC runtime), with deterministic disconnect/error behavior and no authority amplification.
Maps to: D-CAPRPC, D-CAPX, I-CAPRPC-1, I-CAPRPC-3, PO-CAPRPC-PIPELINE.
Refs: REF-CAPNP-RPC, REF-TC39-EVENTUALSEND.

### CapTP / OCapN: networked object capabilities that stay capability-pure
Lesson: distributed capability protocols avoid “ambient network” by making remote authority explicit: references are introduced, messages are queued/delivered under explicit routing, and failure is a first-class result (disconnection is not “just a timeout”). OCapN is a modern interop effort that reuses the CapTP lineage.
Spec impact: treat remote capability use as an **optional user-space gateway profile** over D-CAPX + D-CAPRPC:
- remote references are minted/imported only via explicit CH-CAPX envelopes (no implicit DNS or sockets),
- introduction and revocation semantics are explicit and transcriptable,
- prefer eventual-send / promise semantics for latency tolerance (pairs with D-TURNS).
Maps to: D-CAPX, D-CAPRPC, D-NAMECERT (optional), D-TURNS (optional).
Refs: REF-CAPTP, REF-OCAPN.


### E / Spritely: communicating event loops ("vats") avoid implicit reentrancy
Lesson: capability security and concurrency control interact; a turn-based event-loop model keeps local reasoning tractable and makes "await" safe by avoiding inbox pumping.
Spec impact: add an optional D-TURNS deployment/runtime profile for selected services (especially CapRPC-exposed ones) that enforces turn-atomic delivery and forbids hidden reentrancy; tie to explicit promise-based APIs.
Maps to: D-TURNS, D-CAPRPC, I-TURNS-1, PO-TURNS-NOREENTR.
Refs: REF-ROBUST-COMPOSITION, REF-E-LRM, REF-E-FAQ, REF-SPRITELY-CORE.

### Fuchsia/Genode/Singularity: manifested component graphs + routing
Lesson: “what runs + who can access what” must be explicit, lintable, and fail-closed.
Spec impact: CH-COMP + declared routing; composition validators are a first-class seam.
Maps to: D-COMP, I-COMP-1/I-COMP-2, PO-COMP-VALIDATE.
Refs: REF-FUCHSIA-COMPONENTS, REF-GENODE-INIT, REF-SING-OSR07.

### Singularity: channel contracts make protocols checkable
Lesson: when IPC channels have explicit, analyzable contracts, protocol bugs become a tooling target rather than a latent reliability/security issue.
Spec impact: treat protocol FSMs as first-class artifacts; generate stubs/monitors from pinned contracts; fail-closed on illegal transitions.
Maps to: D-CONTRACT, D-IDL, I-CONTRACT-1/I-CONTRACT-2, PO-CONTRACT-OBEY/PO-CONTRACT-MCHECK.
Refs: REF-SINGULARITY, REF-SING-CHANCONTRACTS.

### seL4 Microkit/capDL: compile the architecture into a time-0 snapshot
Lesson: initialization becomes tractable (and even verifiable) when the system’s architecture is a **static description** consumed by a tool that produces a concrete time‑0 object/capability graph and a tiny initializer/runtime.
Spec impact: treat CH-COMP as authoring input and support an optional build-time **sysgen** pipeline that emits a bounded CH-INIT snapshot; keep runtime composition logic small and validate ‘boot matches snapshot’.
Maps to: D-COMP, D-INITSNAP, PO-INIT-VALIDATE, PO-INIT-MATCH.
Refs: REF-MICROKIT-MANUAL, REF-MICROKIT-GITHUB, REF-CAPDL-KUZ10, REF-MICROKIT-VERIFY24.

### Multicore scalability: avoid accidental sharing (Corey/Tornado/K42/multikernel)
Lesson: on many cores, the OS bottleneck is often **unnecessary shared kernel state**. Research systems converge on variants of ‘private-by-default’ and ‘replicate/partition unless sharing is demanded’.
Spec impact: treat shared state as an explicit design surface:
- prefer per-core/per-cluster ownership and replicas (D-MK),
- make any ‘share scope’ explicit (Corey-style),
- apply commutativity thinking to the KABI so common operations can scale without conflicts.
Maps to: D-CONC, D-MK, D-MEMMODEL, C-CONC-1.
Refs: REF-MULTIKERNEL-SOSP09, REF-COREY-OSDI08, REF-TORNADO-OSDI99, REF-K42-COMPLETE-06, REF-SCALABLE-COMMUTATIVITY-TOCS13.


### KeyKOS/EROS/Hydra: factories/constructors make confinement repeatable
Lesson: capability systems get their strongest safety story when **construction** is disciplined: factories/constructors stamp out protected subsystems, and a confinement test checks that no authority leaks across the boundary except the declared exports. Hydra’s “templates” highlight a related need: controlled **rights amplification** for internal managers without handing raw authority to callers.
Spec impact: keep D-CONSTR as an explicit ecosystem seam:
- represent constructors as normal components (user space) that consume pinned template digests + parameter data and return an exported surface,
- standardize a confinement regression test using cap-graph export + delta checks (leak detection),
- use sealers/unsealers or “brands” to prevent type confusion when wrapping references across the constructor boundary.
Maps to: D-CONSTR, D-CAPAUD, D-SEAL (adjunct), D-MEMBRANE (adjunct).
Refs: REF-KEYKOS-ARCH85, REF-KEYKOS-FACTORY, REF-EROS-CONFINEMENT, REF-HYDRA-CH6, REF-CAPMYTHS.


### OpenBSD pledge/unveil: make post-init narrowing ergonomic
Lesson: least-privilege adoption improves when narrowing is **easy** and **one-way**.
Spec impact: D-SEAL + voluntary sandboxing wrappers that “seal down” after init.
Addendum: bake in a “learn/complain” workflow (deny+log) so teams can converge on minimal promise sets; independent reimplementations (e.g., SerenityOS) and recent sandboxing work highlight that usability/debuggability drives adoption.
Maps to: D-SEAL, D-CAPMODE (optional), I-SEAL-1, PO-SEAL-ONEWAY.
Refs: REF-OPENBSD-PLEDGE, REF-OPENBSD-UNVEIL, REF-SERENITY-PLEDGEUNVEIL, REF-THREADBOX-ARXIV25.

### Qubes qrexec: cross-domain services with policy-as-data
Lesson: cross-domain workflows stay usable when (a) calls are **named services**, (b) authorization is **fail-closed**, and (c) policy is **layered as data** (with disposable targets as first-class).
Spec impact: treat “service call” as a portal/routing problem backed by CapRPC + pinned veto-only policies.
Maps to: D-CAPRPC, D-POLICY, D-PLUMB, D-EPHEM, I-POLICY-1/I-POLICY-2.
Refs: REF-QUBES-QREXEC, REF-QUBES-DISPOSABLES.

### Qubes USB devices: untrusted peripherals live in a dedicated domain
Lesson: treat hotplug peripherals as hostile-by-default; keep raw device access in a dedicated “peripheral domain” and make attachment to workloads explicit and reversible.
Spec impact: deny-by-default hotplug with portalized attach; bind raw devices to driver domains first; lease to workloads only with explicit CH-IOLEASE bounds and transcript visibility.
Maps to: D-DEVGUARD, D-DRVDOM, D-IOLEASE, D-VOLITION, I-DEVGUARD-1/I-DEVGUARD-2.
Refs: REF-QUBES-USB.

### USBGuard: deterministic allow/deny rules are usable ops tooling
Lesson: a simple, deterministic first-match rule set for device authorization is adoptable and scriptable; defaults matter.
Spec impact: pin an optional policy-as-data schema (CH-DEVGUARD) that is transcript-visible and can be used for veto-only automation.
Maps to: D-DEVGUARD, D-POLICY (veto-only), PO-DEVGUARD-DECIDE.
Refs: REF-USBGUARD-RHEL7, REF-USBGUARD-RULELANG.

### Thunderbolt/USB4: DMA-class hotplug requires IOMMU posture and boot assumptions
Lesson: “authorization prompts” are not enough when the bus tunnels PCIe; OS DMA protection relies on IOMMU/firmware integration and does not cover pre-OS boot.
Spec impact: make D-DMA a hard gate for DMA-class hotplug; fail closed without IOMMU; keep the remaining pre-boot window explicit as an assumption (A-BOOT-1/A-BOOT-2/A-HW-1).
Maps to: D-DMA, D-DEVGUARD, I-DMA-1, PO-IOLEASE-CONFINE.
Refs: REF-THUNDERSPY-REPORT, REF-WIN-KDMA.

### Portals / powerbox / UDAC: user intent must be in the loop
Lesson: least-privilege fails when grants are decoupled from user intent; powerbox-style mediators concentrate risky decisions.
Spec impact: route high-risk workflows through portals that return handles (not paths) and bind grants to trusted UI volition + receipts.
Additionally, “boring desktop glue” like **OpenURI**, **printing**, and even **USB device access** benefits from the same portal discipline: mediation + leases + receipts instead of ambient helpers/sockets or raw `/dev`.

Maps to: D-PLUMB, D-POWERBOX, D-VOLITION, D-EXPLAIN, I-CONSENT-1, PO-PLUMB-UI.
Refs: REF-XDG-PORTAL, REF-XDG-PORTAL-OPENURI, REF-XDG-PORTAL-PRINT, REF-XDG-PORTAL-USB, REF-SANDSTORM-POWERBOX, REF-PLASH-POWERBOX, REF-UDAC-SP12.

### Location: coarse vs precise, foreground vs background (portalize location authority)
Lesson: location is a high-value privacy surface; systems that treat location as a normal API tend to grow ambient, global tracking channels. Modern platforms add explicit mediation and **accuracy tiers** (approximate vs precise) and restrict **background** access. Desktop sandboxes even expose a dedicated **Location portal**.
Spec impact: treat location as a portal workflow (`portal.location`) that mints leased location capabilities and emits a redaction-aware lease descriptor (CH-LOCLEASE) for receipts/audit. Continuous tracking implies non-spoofable indicators; policy clamps TTL and update cadence; background/precise posture is profile-gated and may require fresh volition.
Maps to: D-LOCLEASE, D-PLUMB, D-LEASE, D-VOLITION, D-EXPLAIN, I-LOCLEASE-1/I-LOCLEASE-2/I-LOCLEASE-3, PO-LOCLEASE-VALIDATE/PO-LOCLEASE-ENF, AC-086.
Refs: REF-XDG-PORTAL-LOCATION, REF-ANDROID-LOC-PERMS, REF-ANDROID-LOC-BACKGROUND, REF-APPLE-LOCATION-PRECISE, REF-GEOCLUE-DBUS.


### Plash: practical least-privilege wrappers for legacy apps
Lesson: you often get least-privilege by wrapping unmodified binaries (views + explicit handoff).
Spec impact: ship a compat launcher that constructs default-deny views, then seals/capmodes post-init.
Maps to: D-NS, D-SEAL, D-CAPMODE.
Refs: REF-PLASH, REF-POLARIS-SOUPS05.

### SHILL: capability-safe shell scripting with explicit contracts
Lesson: shell scripts and pipelines are “security glue” that quietly accumulate ambient authority. SHILL demonstrates a workable pattern: scripts declare **effect contracts**, and even native executables spawned by the script are wrapped so they cannot exceed the script’s declared authority.
Spec impact: treat automation as first-class **components** (D-COMP) with declared caps, use default-deny views (D-NS), and make post-init narrowing one-way (D-SEAL/D-CAPMODE). For adoption, provide a learn-mode workflow and an ergonomic “capability wallet” concept for bundling handles + pledge tokens.
Maps to: D-CAPSHELL, D-COMP, D-NS, D-SEAL, D-CAPMODE, D-PLUMB, D-EXPLAIN.
Refs: REF-SHILL-OSDI14, REF-PLASH, REF-CAPSICUM.


### Sandboxing adoption reality: mechanisms don’t ship ecosystems
Lesson: empirical studies find that even when sandboxes exist, **few packages invoke sandboxing APIs directly**; developers often simplify toward pledge-like models or rely on wrappers and downstream packaging to apply confinement.
Spec impact: treat adoption as a first-class design constraint: ship wrapper-first tooling, learn-mode workflows, and contract artifacts that can be drift-gated in CI. Make “run it safely” the lowest-ceremony path.
Maps to: D-SEAL, D-CAPMODE, D-CAPSHELL, D-NS, D-PLUMB, D-EXPLAIN.
Refs: REF-SANDBOX-ADOPTION-ARXIV24, REF-LEASH-CAPSICUM-2025.


## Hardware knowledge + scaling (heterogeneity without hidden probes)


### Durable document handles (document portal / security-scoped bookmarks)
Sandboxed desktop apps need “recent documents” and project reopen without being handed ambient paths. The practical pattern is a **document portal**: a mediator that exports selected files into a restricted per-app view and can re-issue scoped handles later.

Key takeaways:
- make persistence **explicit** (don’t silently persist every chooser result)
- treat durable handles as **non-bearer** (a stolen handle must not grant access)
- bind reopening to stable object identity (rename/move OK; replace/swap must fail closed or require re-consent)
- keep “what’s being granted” transcript-visible (receipts/diffs) and make revocation manageable

Maps to: D-PLUMB, D-POWERBOX, D-EXPLAIN, D-PERSIST, I-DOCREF-1/I-DOCREF-2, PO-DOCREF-VALIDATE/PO-DOCREF-REOPEN, AC-076.
Refs: REF-XDG-PORTAL-DOCUMENTS, REF-APPLE-SECBOOKMARK, REF-SSB-CVE-2025.
### Barrelfish: a System Knowledge Base (SKB) for platform facts
Lesson: platform topology, quirks, and routing constraints should be **queryable facts**, and the logic to derive placements/allocations should live in a declarative/constraint layer rather than being smeared through privileged code.
Spec impact: centralize platform facts in CH-HWFACT and a user-space SKB service; model fact evolution via CH-HWEVENT when hotplug is enabled; keep the privileged core agnostic and bind any security-relevant hardware facts into provenance.
Maps to: D-SKB, D-ADDRNET (adjunct), D-DEVGUARD (adjunct), I-HWFACT-1, PO-HWFACT-BIND, PO-SKB-PURITY.
Refs: REF-BARRELFISH, REF-BARRELFISH-SKB, REF-DECLARATIVE-OS, REF-FUCHSIA-DRIVER-NODES.

## Isolation + compartmentalization (security posture as a product feature)

### Multics: protected subsystems via rings (and the cautionary tale)
Lesson: Multics demonstrated that you can structure a large system as nested protected subsystems (rings) with controlled cross-ring calls. It also became a long-running lesson in how **complex privileged surfaces** and “special cases” accumulate into security debt.

Spec impact:
- Keep our privileged core (“ring 0”) ruthlessly small (D-KABI + exit-surface budgeting).
- If we want intra-domain privilege separation for risky plugins, treat it as a **user-space hardening profile** (e.g., CHERI sealing / memory tagging / MPK-like keys), not a kernel policy feature.
- Prefer explicit capability boundaries + contracts over “ambient ring tricks”.

Maps to: D-KABI, D-SEAL, D-CHERI (optional), D-MEMTAG (optional), C-ABI-1, PO-ABI-TOTAL.
Refs: REF-MULTICS-RINGS, REF-MULTICS-PROTMULT, REF-KARGER-2002.

### OpenBSD: W^X as a default platform stance
Lesson: enforcement beats convention — banning writable+executable memory by default removes a large class of injection techniques and forces dynamic code to adopt explicit patterns.
Spec impact: treat executable memory as explicit authority (execmod/JIT gating) with W^X enforced at the privileged boundary; keep exceptions profile-scoped and evidence-tracked.
Maps to: D-DYNCODE, I-WX-1, PO-WX-ENF.
Refs: REF-OPENBSD-33-WX, REF-OPENBSD-WX-KERNEL.

### Qubes: templates + disposables as an ecosystem multiplier
Lesson: “many compartments” only works if creation/update/storage are cheap; templates + disposables make isolation a daily habit.
Spec impact: align atomic deployments + image stores + disposable domains so “open risky thing in disposable” is one click.
Maps to: D-EPHEM, D-ATOMICUPD, D-FPM.
Refs: REF-QUBES-TEMPLATES, REF-QUBES-TEMPLATE-IMPL, REF-QUBES-DISPOSABLES.

### Android/Chromium: “zygote” template spawners make sandboxes cheap
Lesson: isolation becomes a default user habit when spawning is **fast**. Both Android and Chromium use a long-lived “zygote” that performs expensive setup once, then forks/clones children on demand so they share read-only pages.
Spec impact: document a user-space **template spawner** pattern for D-EPHEM: warmed templates identified by digest (CH-INIT or CH-CKPT), then immediate post-spawn narrowing (view install → routing → seal/capmode) to prevent inherited authority from widening.
Maps to: D-EPHEM, D-INITSNAP (adjunct), D-CHKPT (adjunct), D-SEAL, D-CAPMODE.
Refs: REF-ANDROID-ZYGOTE, REF-ANDROID-MEMORY-OVERVIEW, REF-CHROMIUM-ZYGOTE.

### Qubes: clipboard as an explicit grant (not broadcast)
Lesson: secure cross-domain copy/paste requires an explicit transfer step.
Spec impact: model clipboard/drag-drop as portal sessions that mint short-lived payload leases; bind to volition + receipts.
Maps to: D-PLUMB, D-VOLITION, D-LEASE.
Refs: REF-QUBES-CLIPBOARD.

### Wayland/XDG portals/Android: clipboard is a security surface (session grants + user visibility)
Lesson: systems that treat clipboard/drag-drop as ambient global state end up with exfiltration and confused-deputy flows. Modern stacks increasingly model transfer as an explicit offer→accept handshake (negotiated format, bytes delivered on demand) and add user visibility controls.
Spec impact: prefer portal-mediated transfer grants that mint leased payload handles and emit a bounded transfer descriptor (CH-XFER) for audit/receipts; add sensitive marking and export redaction, and default to auto-clear semantics for cross-domain clipboard.
Maps to: D-PLUMB, D-LEASE, D-VOLITION (policy), D-OBSPOL (export).
Refs: REF-WAYLAND-APA-DATADEVICE, REF-XDG-PORTAL-CLIPBOARD, REF-ANDROID-SECURE-CLIPBOARD, REF-ANDROID-12-CLIPBOARD-TOAST.

### PipeWire + portals: media capture becomes permissionable (and mic shouldn’t be a static socket)
Lesson: modern media stacks increasingly treat capture as a mediated graph: a user-space media server enforces per-client permissions on graph objects, and a session/policy manager decides which clients may access which sources. Where systems still grant audio servers as static permissions, microphone capture becomes effectively ambient.
Spec impact: model camera/microphone/screencast/remote-desktop as portal-mediated capture sessions that mint leased capture endpoints and emit a bounded session descriptor (CH-CAPTURE) for audit/receipts; require user-visible indicators and treat capture metadata as sensitive for exports.
Maps to: D-PLUMB, D-UICAP, D-LEASE, D-IOLEASE, D-OBSPOL, I-CAPTURE-1/I-CAPTURE-2, PO-CAPTURE-VALIDATE, AC-082.
Refs: REF-PIPEWIRE-ACCESS, REF-PIPEWIRE-SESSMGR, REF-XDG-PORTAL-SCREENCAST, REF-XDG-PORTAL-REMOTEDESKTOP, REF-XDG-PORTAL-CAMERA, REF-XDG-PORTAL-AUDIO-ISSUE.

### Android/iOS/systemd: background work should be scheduled, coalesced, and bounded
Lesson: exact wakeup alarms and always-on daemons become ambient authority and a power/privacy footgun. Modern platforms push apps toward **constraint-based background jobs**: you declare intent + constraints, and the system chooses execution time for overall device health.
Spec impact: add an optional D-JOBS seam: a user-space **job portal** that accepts bounded requests, can coalesce under pressure signals, and triggers work via activation/message delivery with explicit runtime bounds. Emit a bounded CH-JOBREQ descriptor (no capability material) for audit/receipts.
Maps to: D-JOBS, D-TCAP, D-PRESSURE, D-ACTIVATE (adjunct), D-NETLEASE (no ambient net), D-PERSIST (optional).
Refs: REF-ANDROID-JOBINFO, REF-ANDROID-WORKMANAGER, REF-APPLE-BGTASKS, REF-APPLE-BGTASK-EARLIEST, REF-SYSTEMD-TIMER.

### XDG portals / Android / Apple: background execution + autostart must be explicit grants
Lesson: allowing apps to keep running invisibly (or relaunch automatically) turns into ambient persistence. Modern systems constrain background execution (service limits; reviewed modes) and sandboxed desktops treat background/autostart as a mediated portal workflow with user-visible reasons and status.
Spec impact: add an optional `portal.background` workflow that issues leased background/autostart grants and emits a bounded descriptor (CH-BGLEASE) for receipts/audit. Prefer D-JOBS for deferrable work; reserve background presence for narrow cases under policy with TTL/renewal clamps and non-spoofable indicators.
Maps to: D-BGLEASE, D-LEASE, D-JOBS (adjunct), D-VOLITION (policy), D-OBSPOL (export).
Refs: REF-XDG-PORTAL-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-ANDROID-FGS-RESTRICTIONS, REF-APPLE-BG-MODES.

### systemd/logind + XDG portals + Android: inhibiting suspend/idle is authority (lease it)
Lesson: “keep the device awake” APIs become a battery/availability footgun and a persistence surface. Production systems model this as explicit **inhibitor locks** (desktop) and **wake locks** (mobile), and sandboxes expose it as an explicit portal workflow rather than an ambient call.
Spec impact: add an optional inhibit portal (`portal.inhibit`) that mints **leased** inhibition handles, defaults to `delay` semantics for apps, clamps TTL/renewal, and emits a bounded CH-INHIBITLEASE descriptor for receipts/audit. Long-lived inhibits imply non-spoofable UI indicators; privileged `block` inhibits are policy-gated for system components (e.g., updates).
Maps to: D-INHIBITLEASE, D-LEASE, D-JOBS (adjunct), D-VOLITION (policy).
Refs: REF-XDG-PORTAL-INHIBIT, REF-SYSTEMD-INHIBITOR-LOCKS, REF-SYSTEMD-INHIBIT-MAN, REF-ANDROID-WAKELOCK, REF-ANDROID-SET-WAKELOCK.

### XDG secret portal + Android Keystore: app secrets should be a primitive
Lesson: most apps need a small, stable secret seed for protecting *their own* local state (at-rest encryption, integrity tags). If the platform doesn’t provide a minimal primitive, ecosystems drift into ad hoc files, ambient keyrings, or hardcoded credentials.
Spec impact: add an optional `portal.secret` workflow that returns an app-scoped secret seed under explicit scope and bounded parameters, and emits a redaction-safe CH-APPSECRET descriptor. Keep this distinct from full credential storage/sharing (D-VAULT).
Maps to: D-APPSECRET, D-PLUMB (adjunct), D-CRYPTOSVC (adjunct), D-VAULT (optional), I-APPSECRET-1/I-APPSECRET-2/I-APPSECRET-3, PO-APPSECRET-VALIDATE/PO-APPSECRET-ENF, AC-089.
Refs: REF-XDG-PORTAL-SECRET, REF-ANDROID-KEYSTORE, REF-ANDROID-KEYATTEST, REF-SECRET-SERVICE-SPEC.

### Split-service patterns (Split GPG / “vault” domains)
Lesson: users value “split secrets” workflows that keep key material in a dedicated domain and expose operation-only access.
Spec impact: standardize keys-as-capabilities + vault patterns so split-service use-cases are boring and well-audited.
Maps to: D-CRYPTOSVC, D-VAULT, D-POWERBOX.
Refs: REF-QUBES-SPLITGPG, REF-PLAN9-FACTOTUM.

### Tock: ruthless isolation boundaries inside a small kernel
Lesson: treat in-kernel subsystems as mutually distrustful; encapsulate privileged logic behind narrow interfaces.
Spec impact: keep privileged code modular; push policy to user space; isolate/measure `unsafe`.
Maps to: D-UNSAFE, I-UNSAFE-1/I-UNSAFE-2.
Refs: REF-TOCK-DESIGN, REF-TOCK-OS.

### HiStar / Asbestos / Flume: DIFC labels make “no exfil” a checkable claim (scoped)
Lesson: capabilities control *calls*, but not *copies*; DIFC adds a minimal, explicit information-flow predicate (plus explicit declassify/endorse authority) that can make privacy/integrity confinement claims meaningful for a **scoped subset**.
Spec impact: keep D-IFC optional and start IFC-lite by labeling a few high-leverage sinks (export surfaces, selected channels); treat declassification as an explicit, transcript-visible capability boundary; optionally unify quarantine with a secrecy tag.
Maps to: D-IFC, D-QUAR, D-OBSPOL, I-IFC-1/I-IFC-2/I-IFC-3, PO-IFC-STEP/PO-IFC-DECLASS, AC-072.
Refs: REF-HISTAR-SOSP06, REF-ASBESTOS-SOSP05, REF-FLUME-SOSP07, REF-FLUME-NONINTERFERENCE, REF-DIFC-SOSP97.

### Fuchsia / Windows UMDF: drivers in restartable user-space hosts
Lesson: drivers are high-risk; systems get more stable when drivers run in **user-space host processes** with manager-controlled lifecycles and isolation boundaries.
Spec impact: treat driver hosts as normal supervised components; use explicit IO resource capabilities/leasing; prefer supervisor-owned stable service handles for continuity across restarts.
Maps to: D-DRVDOM, D-SUPV, D-ACTIVATE, D-IOLEASE, I-IORES-1.
Refs: REF-FUCHSIA-DRIVER-FRAMEWORK, REF-FUCHSIA-DRIVER-DEVEL, REF-WINDOWS-UMDF-OVERVIEW.


## Recovery + service management (crash-only discipline that operators can trust)

### Erlang/OTP + MINIX 3: supervision and reincarnation
Lesson: structured supervisors + restart limits prevent “ad-hoc init chaos” and make failure handling testable.
Spec impact: minimal restart metadata in CH-COMP; explicit abuse case for restart storms.
Maps to: D-SUPV, AC-022.
Refs: REF-ERLANG-OTP-PRINCIPLES, REF-MINIX-RELIABLE-OS.

### Solaris SMF: manifests + dependency-driven restarters
Lesson: service managers scale when service definitions are **validated artifacts** and restarters are explicit.
Spec impact: adopt a validate+install loop for CH-COMP / policy bundles; make dependency semantics crisp and lintable.
Maps to: D-COMP, D-POLICY.
Refs: REF-SOLARIS-SMF-BP, REF-SOLARIS-SMF-CREATESVC.

### Windows Job Objects / Linux cgroups / Fuchsia jobs: “who pays” and “who dies” should share a handle
Lesson: operators want a crisp, enforceable answer to “which processes are *in this unit*” (limits/accounting) and “what happens to the unit when the owner goes away” (kill/cleanup). Doing this ad-hoc in every supervisor is fragile.
Spec impact: model a first-class **container/job realm** object in user space:
- it is the default **resource principal** (payer) for spawned children (meter lineage),
- it holds restart/cleanup policy for the subtree,
- its control handle is explicitly *not inherited* by default (prevents “escape by inheriting the leash”).
Maps to: D-METER, D-SUPV, D-ACTIVATE, I-METER-3, I-SUPV-1.
Refs: REF-WIN-JOBOBJECTS, REF-CGROUPV2, REF-CGROUP-DELEGATION, REF-FUCHSIA-JOBS.

### Mach IPC: dead-name notifications make liveness an explicit message (not polling)
Lesson: if “the thing I’m talking to died” is a first-class signal, systems get simpler: supervisors don’t need timers everywhere, and cleanup becomes deterministic.
Spec impact: treat “death watch” as an optional seam in cap-RPC/endpoint objects:
- a watcher registers a one-shot notification target,
- if the endpoint (or its backing object) dies, the watcher receives a bounded notification event,
- supervisors use this as the primary “crash detector” signal for managed components.
Maps to: D-CAPRPC, D-SUPV, D-RECOVERY.
Refs: REF-MACH-REQUEST-NOTIFY.

### Go context / structured concurrency: cancellation + deadlines should be a request-scoped context
Lesson: systems get dramatically simpler when cancellation and deadlines are *not* ad hoc flags. A request-scoped context that propagates down the operation tree prevents orphan work, makes shutdown reliable, and turns timeouts/cancels into explicit, countable error outcomes.
Spec impact: add an optional D-REQCTX seam: standardize request-context conventions (deadline intent + cancellation propagation + trace correlation), represent intent as a bounded CH-REQCTX descriptor (non-authoritative), and optionally carry `ctx_digest` in CapRPC frames (CH-CAPRPC v1) for correlation. Prefer explicit budget/time authority (D-BUDGET/D-TCAP) when “who pays” matters.
Maps to: D-REQCTX, D-CAPRPC, D-TURNS, D-BUDGET (adjunct), D-TCAP (adjunct), I-REQCTX-1/I-REQCTX-2/I-REQCTX-3.
Refs: REF-GO-CONTEXT, REF-KOTLIN-CANCEL, REF-CAPNP-1.0-CANCEL, REF-VORPUS-TIMEOUTS.

### Erlang release handling + Kubernetes/systemd: quiesce/drain beats “send a signal and pray”
Lesson: production orchestrators converge on a multi-step stop: stop accepting new work, drain in-flight work for a bounded grace period, then escalate (force-kill) if needed. Erlang/OTP upgrades even suspend processes to make code change safe; Linux checkpoint tooling can freeze task trees. The common missing piece in many ecosystems is a *standard cooperative quiesce gate* that makes maintenance behavior explicit and testable.
Spec impact: add an optional **D-QUIESCE** seam: a capability-gated `BeginQuiesce(DRAIN|CANCEL)` protocol with bounded outcomes, optional `QUIESCENT` waitability (D-WAITSET adjunct), and an optional bounded **CH-QUIESCE** descriptor for transcript correlation. Compose with D-REQCTX deadlines and D-SUPV escalation; keep quiesce non-amplifying and deny-by-default for uncooperative services (crash-only fallback).
Maps to: D-QUIESCE, D-REQCTX, D-SUPV, D-ACTIVATE (adjunct), D-CHKPT (adjunct), I-QUIESCE-1/I-QUIESCE-2/I-QUIESCE-3.
Refs: REF-ERLANG-RELEASE-HANDLING, REF-KUBE-LIFECYCLE-HOOKS, REF-SYSTEMD-SERVICE, REF-LINUX-CGROUP-FREEZER.

### systemd/launchd/nginx: manager-owned endpoints enable zero-downtime restarts
Lesson: restarts stop being scary when the manager owns inbound endpoints and can restart workers without dropping new connections; preserving a bounded set of handles across restarts avoids full checkpointing for many services.
Spec impact: add an optional D-ACTIVATE seam: supervisor-owned stable handles passed in at start (CH-ACTSET) + optional per-component handle store with strict bounds and seal/phase gating.
Maps to: D-ACTIVATE, D-SUPV, I-ACTIVATE-1/I-ACTIVATE-2, PO-ACTIVATE-HANDOFF.
Refs: REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-FDSTORE, REF-SD-LISTEN-FDS, REF-LAUNCHD-ACTIVATE-SOCKET, REF-NGINX-CONTROL.


### Crashpad/Breakpad + systemd-coredump: crash capsules need stable identity + bounded payloads
Lesson: crash reporting becomes usable when (a) capture is standardized and preferably out-of-process, (b) payloads are bounded (minidump-style) rather than “dump everything”, and (c) crash artifacts carry module identity (build IDs) so symbolization can happen later without shipping full images.
Spec impact: define an optional CH-CRASHCAP crash capsule manifest that binds env digests + module build IDs and references bounded payloads (log/trace/inspect windows, optional dump/replay). Keep export explicit and redaction-scoped; treat symbol fetch as a content-addressed artifact lookup (debuginfod-like, policy gated).
Maps to: D-INSPECT, D-RR (adjunct), D-OBS/D-OBSPOL, D-FPM (adjunct), D-ENC, I-OBS-1.
Refs: REF-CRASHPAD-OVERVIEW, REF-SYSTEMD-COREDUMP-MAN, REF-MS-MINIDUMP-FILES, REF-DEBUGINFOD.

### Fuchsia triage + alert-rule systems: make diagnosis rules portable and bounded
Lesson: operators get better outcomes when "what to collect" is expressed as a **bounded, testable rule set** over structured diagnostics, rather than ad-hoc scripts and tribal knowledge. Fuchsia's triage rules (selectors + eval + actions + tests) show that on-device rule evaluation can be both practical and auditable; alerting-rule systems (Prometheus) show how declarative predicates can drive repeatable ops responses.
Spec impact: add an optional D-TRIAGE seam: CH-TRIAGE v0 rule sets that evaluate over CH-INSPECT and/or CH-CRASHCAP to emit bounded findings and advisory snapshot requests; keep export authority constrained by CH-OBSPOL and portal workflows.
Maps to: D-TRIAGE, D-INSPECT, D-OBS/D-OBSPOL, I-TRIAGE-1/I-TRIAGE-2, PO-TRIAGE-VALIDATE/PO-TRIAGE-EVAL, AC-075.
Refs: REF-FUCHSIA-TRIAGE, REF-PROMETHEUS-ALERT-RULES.

### Solaris FMA: typed error reports → diagnosis engines → response agents (self-healing without reboot)
Lesson: “restart the whole machine” is a crude response to localized faults. Solaris Fault Management Architecture (FMA) treats errors as **typed reports** (ereports/ireports) that feed diagnosis engines, which emit suspect lists and drive response agents (offline a component, restart a service, request operator action).
Spec impact: treat faults as structured, bounded artifacts/events (CH-FAULT / CH-HWEVENT / CH-CRASHCAP) and keep diagnosis engines in user space: triage rules can emit deterministic findings and request bounded actions, while response agents flow through supervised, transcripted control paths (IF-ACP) rather than ad-hoc scripts. Prefer “offline the bad unit” (D-DEVGUARD / leasing) and “restart the affected service” (D-SUPV) over whole-system resets where profiles allow.
Maps to: D-TRIAGE, D-INSPECT, D-SUPV, D-DEVGUARD, D-OBS/D-OBSPOL.
Refs: REF-SOLARIS-FMA-OVERVIEW, REF-SOLARIS-FMA-ADMIN.


## Updates + provenance (what booted should be mechanically answerable)

### rpm-ostree / OSTree: atomic deployments + rollback by default
Lesson: updates are safer when the base OS is an immutable deployment tree and upgrades are pointer flips.
Spec impact: bind boot selection to deployment digests; make rollback first-class. Treat *mutable data* as a separate concern: atomic deployment rollback does not automatically make state rollback-safe, so add explicit migration gates/data contracts (RFC-0097) or snapshot barriers when profiles require it.
Maps to: D-ATOMICUPD, D-BOOT.
Refs: REF-RPM-OSTREE, REF-FEDORA-ROLLBACKS.

### Solaris/FreeBSD ZFS boot environments: “bootable snapshots” + one-shot activation
Lesson: snapshot/clone-backed **boot environments** make rollback routine; importantly, production tooling bakes in “activate once” / bounded tries semantics so a new environment can be tested and auto-reverted if it doesn’t come up healthy.
Spec impact: treat this as practical confirmation of our CH-BOOTSEL state machine: pending activation with bounded tries + explicit health commit; keep base OS immutability and bind state transitions to digests.
Maps to: D-ATOMICUPD, D-BOOT, D-HEALTH, I-ATOMICUPD-3, PO-BOOTSEL-VALIDATE.
Refs: REF-SOLARIS-BOOTENV, REF-FREEBSD-BECTL.

### Windows RE / Android recovery / systemd rescue targets: dedicated recovery environment as a boot target
Lesson: recovery works best when it is a **separate, minimal boot target** with at least one physical-presence entry path (boot menu/button), so it remains usable even when the normal UI/input stack or policy is broken. Android treats recovery as a first-class boot artifact, and systemd formalizes minimal troubleshooting targets (rescue/emergency).
Spec impact: add an optional D-RECOVERY seam: ship a digest-addressed recovery deployment (`recovery_root`) alongside normal updates; keep recovery sealed/minimal; make rollback/config-reset/diagnostics workflows explicit and transcript-visible.
Maps to: D-RECOVERY, D-ATOMICUPD (adjunct), D-HEALTH (adjunct), D-BOOT.
Refs: REF-WINRE, REF-ANDROID-PARTITIONS, REF-SYSTEMD-SPECIAL.

### TCG measured boot (UEFI event log) + IMA: PCRs need replayable event logs
Lesson: PCR values alone are opaque; verifiers need an event log to replay PCR extends, and runtime measurement logs can be enormous unless bounded/streamed.
Spec impact: treat measured boot logs as pinned artifacts (CH-MEASLOG) referenced by CH-BOOT; keep platform-specific extraction/parsing in tooling; use CH-AREF when full logs are required out-of-band.
Maps to: D-BOOT, D-AREF (adjunct), D-ATTEST (adjunct), I-MEASLOG-1, PO-MEASLOG-VALIDATE.
Refs: REF-TCG-EFI-PLATFORM, REF-TCG-PC-CLIENT-PFP, REF-TCG-IMELP, REF-SYSTEMD-PCR-MEASURE, REF-LINUX-IMA-TEMPLATES.

### Roughtime + NTS: authenticated time bootstrap (with evidence) and secure time sync
Lesson: expiry-based security mechanisms (updates, cert validity) fail open or fail unusably on devices without a trustworthy RTC; unauthenticated time sync adds a rollback/freeze attack surface. Roughtime provides signed time samples that can be exported as portable evidence (and can expose server misbehavior); NTS secures NTP at scale for steady-state discipline.
Spec impact: add an optional D-TIMEPROOF seam: keep time sync in user space; maintain a monotonic, non-decreasing “secure wall time” lower bound for expiry decisions; export bounded time receipts (CH-TIMEPROOF) as evidence, and keep export scoped by CH-OBSPOL.
Maps to: D-TIME, D-TIMEPROOF, D-NONDET, D-TUF (adjunct), I-TIME-1, I-TIMEPROOF-1/I-TIMEPROOF-2, PO-TIMEPROOF-VALIDATE/PO-TIMEPROOF-VERIFY/PO-TIMEPROOF-APPLY, AC-077.
Refs: REF-ROUGHTIME-PROTOCOL, REF-ROUGHTIME-IETF, REF-RFC-8915, REF-CHRONY-NTS, REF-CLOUDFLARE-ROUGHTIME.


### Nix/Guix: reproducible closures as identity
Lesson: reproducibility and rollback become natural when outputs are addressed by their inputs.
Spec impact: treat builds as graphs; bind closure manifests into provenance/evidence.

Lesson: SBOMs become actionable only when they are **bound to the exact deployed subject** (deployment root/component), not to filenames or "what we intended". A greenfield OS can standardize a small, digest-bound inventory artifact and attach richer SPDX/CycloneDX documents only when needed; *separate, digest-bound VEX statements* then reduce scanner noise without turning exceptions into tribal knowledge. (REF-NTIA-SBOM-MIN2021; REF-CISA-SBOM-MIN2025; REF-SPDX-SPEC; REF-CYCLONEDX-OVERVIEW; REF-CISA-VEX-MINREQ; REF-OPENVEX-SPEC)
Spec impact: add optional D-SBOM and D-VEX seams with bounded CH-SBOM and CH-VEX artifacts; reference them from CH-UPD/CH-BOOT `artifacts[]` as roles `sbom` and `vex`, and enforce subject binding in tooling (avoid drift; reduce noise).
Maps to: D-FPM, D-PCP.
Refs: REF-NIXOS-JFP10, REF-GUIX-FPM13.

### NixOS: declarative system configuration + “generations” as rollback UX
Lesson: rollback becomes a daily habit when configuration evaluation is **deterministic** and each evaluation produces a bootable “generation” you can select/rollback to (without in-place mutation).
Spec impact: treat CH-CFG as a compiled artifact produced by deterministic tooling; integrate generation tracking with D-ATOMICUPD and keep the privileged core limited to “validate+apply CH-CFG” while tooling owns module evaluation and generation GC.
Maps to: D-ATOMICUPD, D-FPM (adjunct), D-EXPLAIN (diffs for config changes), IF-CFG.
Refs: REF-NIXOS-MANUAL, REF-NIX-MANUAL-ROLLBACK.

### Genode depot: integrity-protected packages + on-target update/rollback
Lesson: package distribution scales when system composition is built from signed packages, updated on-target, and rollback is routine.
Spec impact: align D-FPM + D-ATOMICUPD so "install" is a digest-checked materialization of a declared composition; keep update tools out of the privileged core but bind the active package set into CH-BOOT/CH-PROV.
Maps to: D-FPM, D-ATOMICUPD, D-COMP.
Refs: REF-GENODE-PKG, REF-GENODE-SCULPT, REF-GENODE-UPDATE-ROLLBACK.

### fs-verity / dm-verity / AVB: Merkle-tree verified reads for immutable artifacts
Lesson: supply-chain integrity is not just “verify at install” — immutable bytes should be **verified on read** so offline tampering becomes an explicit, fail-closed error instead of undefined behavior. Merkle trees make on-demand verification practical: verify only the blocks you touch, but bind the whole artifact to a pinned root hash.
Spec impact: add an optional D-VERITY seam (RFC-0114): represent immutable content as VerifiedBlob handles (fail-closed verified reads) and standardize a bounded CH-VBLOB identity descriptor so boot/update manifests and transcripts can name “what was supposed to be read” without embedding bytes. Prefer user-space storage/pager implementations to keep the privileged core small.
Maps to: D-VERITY, D-ATOMICUPD (adjunct), D-DYNCODE (adjunct), D-PAGER (adjunct), D-AREF (adjunct), I-VERITY-1/I-VERITY-2/I-VERITY-3, PO-VERITY-ENF/PO-VBLOB-VALIDATE.
Refs: REF-LINUX-FSVERITY, REF-LINUX-DMVERITY, REF-ANDROID-DMVERITY, REF-ANDROID-AVB2-README.


### TUF / Uptane: update distribution that survives key compromise and detects freeze
Lesson: update systems fail in practice without a **freshness signal**, **consistent views**, and a plan for **key compromise**; role-separated metadata with expiries makes rollback/freeze/mix-and-match attacks detectable and recovery operationally manageable.
Spec impact: model update distribution as an optional D-TUF seam that serves CH-UPD + artifacts via signed metadata; keep boot path agnostic; encourage D-TLOG monitoring for equivocation.
Maps to: D-TUF, D-UPD-SIGN, D-ATOMICUPD, I-TIME-1, PO-TUF-VERIFY.
Refs: REF-TUF-METADATA, REF-TUF-SPEC, REF-UPTANE-STANDARD2, REF-UPTANE-BESTPRACTICES, REF-PEP-480.


### Sigstore/cosign: keyless signing + transparency as the default workflow
Lesson: long-lived signing keys are an adoption cliff. Sigstore shows a practical alternative: sign with short-lived keys, bind the key to an OIDC identity via a CA (Fulcio), and publish verification material + log inclusion evidence as a portable bundle; DSSE-style envelopes reduce type-confusion risks. The trade is that **identity policy becomes the trust boundary** (issuer allowlists + workload/repo/workflow constraints), and high-assurance channels should demand transparency anchoring.
Spec impact: add D-SIGENV/D-KEYLESS seams and standardize a small signature envelope (CH-SIGENV) that signs payload digests with DSSE-style type binding; optionally attach CH-TLOG anchors for “logged” releases; keep this entirely in user space and profile-driven.
Maps to: D-UPD-SIGN, D-SIGENV, D-KEYLESS, D-TLOG, D-TUF (adjunct), D-TIMEPROOF (adjunct for validity windows).
Refs: REF-DSSE, REF-DSSE-BACKGROUND, REF-SIGSTORE-KEYLESS, REF-SIGSTORE-FULCIO-OIDC, REF-SIGSTORE-BUNDLE, REF-SIGSTORE-REKOR.



### Sigsum / Go sumdb: witnessed transparency improves accountability
Lesson: append-only logs improve auditability, but ecosystem accountability gets stronger when checkpoints are **witnessed** (or otherwise cross-validated) so split-view/equivocation is harder; requiring “visibility in a public log” can detect rogue signatures and targeted releases.
Spec impact: treat witnessing as an optional D-WITNESS extension of D-TLOG: high-assurance channels can require threshold witness signatures over log checkpoints as an “audit-complete” predicate, without coupling boot to external infra.
Maps to: D-TLOG, D-WITNESS, I-TLOG-1/I-TLOG-2, PO-TLOG-VERIFY/PO-TLOG-WITNESS, AC-070.
Refs: REF-SIGSUM, REF-GO-SUMDB-DESIGN, REF-TRANSPARENCY-WITNESS, REF-ARMORED-WITNESS.



### KeyKOS/EROS/CapROS + TreeSLS: persistence by checkpointing the authority graph
Lesson: if authority must survive reboot, **persistence must preserve capability relationships**, not just bytes; whole-system or graph-following checkpoints keep the security model consistent across “disk boundaries”. This can drastically simplify recovery, but makes rollback/time/device interaction explicit design problems.
Spec impact: keep D-PERSIST optional but explicit (CapStore/DurableRoot capability, epochs/anti-rollback); treat device state as **non-persistent** unless explicitly virtualized; prefer a user-space checkpoint manager, with minimal in-kernel metadata only where bootstrapping demands it.
Maps to: D-PERSIST, D-CHKPT, I-PERSIST-1/2/3, PO-PERSIST-NOAMP, A-BOOT-2.
Refs: REF-KEYKOS-OSR92, REF-EROS-FASTCAP, REF-CAPROS-OVERVIEW, REF-CAPROS-USERDRIVERS, REF-TREESLS-SOSP23.
### Amoeba: “names are authority” at distributed scale (capabilities + directories + immutable storage)
Lesson: in a distributed setting, “the name” of an object can *be* the authority: capabilities are **location-transparent references**, and directories are just capability sets that attenuate rights. This blocks the slow creep back toward ambient “connect-by-hostname” authority.

Spec impact: treat D-CAPX (sturdyrefs via CH-SREF) as the baseline for cross-machine references; keep naming/lookup explicitly capability-mediated (views). Prefer immutable or snapshot-style storage when sharing across trust boundaries; represent updates as “new object + atomic directory swap” rather than in-place mutation.

Maps to: D-CAPX (sturdyrefs via CH-SREF), D-NS, D-PERSIST (adjunct), D-ATOMICUPD (adjunct), I-SREF-1, I-VIEW-1/I-VIEW-2.
Refs: REF-AMOEBA-INTRO, REF-AMOEBA-CACM90, REF-AMOEBA-1990S.

### Twizzler: object-centric persistence as a first-class programming model (persistent memory pressure)
Lesson: if byte-addressable persistent memory becomes common, file I/O APIs can become a tax. Twizzler argues for a **global object space** with stable object references and object-relative pointers, so data can be shared across processes and across time without “serialize → write → reopen” gymnastics, while still enforcing per-object access control.

Spec impact: keep D-PERSIST (capstore via CH-CAPSTORE) usable for *object graphs* (not just byte blobs). Prefer snapshot/clone semantics (COW children, immutable-by-default sharing) for cross-trust sharing; tie persistent references to explicit revocation epochs so “old pointers” can’t silently become ambient authority.

Maps to: D-PERSIST (capstore via CH-CAPSTORE), D-CAP (revocation/epochs), D-CAPX (sturdyrefs via CH-SREF), D-IOBUF (adjunct), I-PERSIST-1, I-REVOKE-1, I-SREF-1, PO-CAPSTORE-VALIDATE.
Refs: REF-TWIZZLER-ATC20, REF-TWIZZLER-TR17.


### Plan 9 Fossil + Venti: snapshot trees + immutable archival blocks
Lesson: making snapshots a normal, browseable part of the namespace turns rollback and forensic inspection into routine operations; append-only, content-addressed archival storage makes snapshots cheap and deduplicated.
Spec impact: keep persistence in user space (D-PERSIST), but standardize a “snapshot tree” convention in view mounts and inspect tooling; bind snapshot lineage to digests to keep rollback/resurrection explicit.
Maps to: D-PERSIST, D-NS, D-INSPECT, I-PERSIST-1/I-PERSIST-2/I-PERSIST-3, PO-PERSIST-NOAMP/PO-PERSIST-ROLLBACK.
Refs: REF-PLAN9-FOSSIL, REF-PLAN9-FOSSIL-MAN, REF-VENTI-FAST02.



## Extensibility + UX primitives (make powerful things “normal”)

### Project Oberon: ruthless simplicity as a security/perf feature
Lesson: a small, coherent system with explicit module boundaries and minimal “magic” is easier to audit, port, and maintain — especially for greenfield work.
Spec impact: keep privileged mechanisms few and orthogonal; treat interfaces as data (CH-IFACE/CH-ORD) and make dynamic code loading an explicit authority transition (D-DYNCODE), not an implicit linker escape hatch.
Maps to: D-KABI, D-IDL, D-DYNCODE, I-ENC-1, I-WX-1.
Refs: REF-PROJECT-OBERON.

### GNU Hurd: user-space translators
Lesson: attaching user-space servers to individual namespace nodes enables powerful composition without kernel bloat; Hurd makes this explicit with translators and tools like `settrans` to attach/remove them.
Spec impact: treat translators as user-space domains mounted into views/service trees; keep attachment as an explicit, capability-gated **view mutation** that is transcripted and sealable (no hidden global registration). Prefer deterministic enumeration/overlay rules so translator stacking composes with replay and postmortems.
Maps to: D-TRANS, D-NS, I-VIEW-1/I-VIEW-2, PO-VIEW-RESOLVE/PO-VIEW-NOAMP.
Refs: REF-HURD-TRANSLATORS, REF-HURD-SETTRANS.

### QNX Neutrino: resource managers (path-attached user-space servers)
Lesson: “attach a server to a pathname” can be a durable, production pattern when the attach/register operation is explicit and the microkernel IPC is the backbone.
Spec impact: treat translator attachment as a first-class, capability-gated view mutation; make “name registration” auditable and sealable like any other authority change.
Maps to: D-TRANS, D-NS, I-VIEW-1/I-VIEW-2.
Refs: REF-QNX-RESMGR, REF-QNX-RESMGR-ATTACH.

### BeOS/Haiku: indexed attributes + filesystem queries
Lesson: local search becomes a first-class UX primitive when metadata is indexed in the filesystem.
Spec impact: keep index/query engines in user space but design for view-scoped queries.
Maps to: D-ATTRFS, D-NS.
Refs: REF-BFS-ATTR, REF-HAIKU-QUERIES, REF-PFSD-BFS.

### Redox: “schemes” unify OS interfaces as capability-ish endpoints
Lesson: treating OS services as **scheme endpoints** (roughly VFS-like namespaces where `scheme:path` targets a service) is an ergonomic way to make “everything is a service” concrete; it also makes it natural to gate access by passing a handle to a scheme endpoint rather than relying on global names.
Spec impact: keep our view objects as the authority boundary, but adopt the lesson that “service endpoints that look like namespace nodes” are a practical affordance; align D-TRANS/service trees with explicit capability handles and discourage ambient discovery.
Maps to: D-NS, D-TRANS, D-CAPMODE.
Refs: REF-REDOX-SCHEMES.


## Debuggability + observability (make “repro + explain” the default)

### rr / replay: deterministic record/replay boundaries
Lesson: replay changes debugging economics; a pinned nondeterminism boundary turns flaky tests into artifacts.
Spec impact: record privileged action streams + explicit nondeterminism inputs; keep replay as a profile.
Maps to: D-RR, D-NONDET.
Refs: REF-RR-ATC17.

### DTrace / Linux tracing: safe tracing primitives beat ad-hoc logs
Lesson: tracing becomes a superpower when it is safe, fielded, and redaction-aware.
Spec impact: declared tracepoints + bounded predicates; rich programmability lives out of the privileged core.
Maps to: D-TRACE, D-TPROBE, D-TPRED, D-TRACEPROC.
Refs: REF-DTRACE, REF-LINUX-TRACE-FILTER.

### Windows ETW / Apple unified logging: correlation IDs + privacy-by-default logging
Lesson: production logging scales when event schemas are explicit and correlation is first-class (activity/related IDs), and when privacy classes are enforced by default (public vs private fields).
Spec impact: keep CH-TRACE v0 minimal but standardize correlation semantics via CH-TPROBE `sem` tags (`corr_id` / trace+span IDs), and treat privacy classification as a policy input for export/snapshot tooling.
Maps to: D-TRACE, D-TPROBE, D-INSPECT (bundles), D-OBSPOL.
Refs: REF-MS-ETW, REF-MS-ETW-ACTIVITYID, REF-APPLE-OSLOGPRIVACY.

### journald / ETW buffering / pstore: “keep last N seconds” flight recorders beat “please reproduce with debug logs”
Lesson: support workflows succeed when systems retain a bounded window of recent logs/traces/state in circular buffers (optionally crash-survivor) and can assemble an incident bundle on triggers.
Spec impact: add an explicit retention-ring seam (CH-FLIGHTPOL) plus trigger→bundle assembly that stays policy-bound and capability-gated (no ambient auto-export).
Maps to: D-FLIGHTREC, D-INSPECT, D-TRACE, D-OBSPOL, D-ENC.
Refs: REF-SYSTEMD-JOURNALD, REF-MS-ETW, REF-LINUX-RAMOOPS, REF-LINUX-PSTORE, REF-ANDROID-BUGREPORT, REF-APPLE-SYSDIAGNOSE.
