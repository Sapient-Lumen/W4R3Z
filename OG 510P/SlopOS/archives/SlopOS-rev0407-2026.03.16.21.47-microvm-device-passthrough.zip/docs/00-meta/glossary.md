# Glossary

- **TCB:** components that must be correct for a claim to hold.
- **Capability:** unforgeable authority token; rights + object reference; derivation/revocation rules define policy.
- **Microkernel:** minimal mechanisms (address spaces, threads, IPC) with services outside.
- **Micro-hypervisor:** minimal virtualization/isolation root (VM exits, second-stage translation, interrupt routing).
- **Library OS (libOS):** OS personality implemented as a user-space library/runtime linked with an app (or per-app compartment), rather than a shared privileged kernel.
- **Picoprocess:** a minimal, strongly isolated process/container-like compartment intended to host a single app + its libOS with low overhead.
- **Userspace kernel:** an implementation of a kernel API (often Linux/POSIX) in user space used as an isolation boundary (e.g., container sandboxes).
- **Unikernel:** a single-purpose appliance image, specialized at build time and typically sealed against modification at runtime.

- **Vat:** a single-threaded event loop hosting objects; messages from other vats are delivered asynchronously (E-language lineage).
- **Turn:** one unit of message processing within a vat (process one inbound message to completion before starting the next).
- **Reentrancy (message reentrancy):** a callback or inbound message arrives while a service is mid-update (often due to "await"/blocking that pumps the inbox), potentially violating invariants; D-TURNS aims to prevent implicit reentrancy.

- **Refinement:** implementation behaviors are included in (or match) the specification behaviors, under assumptions.
- **Information-flow:** secrets do not influence public outputs within a specified model/scope.
- **Provenance:** cryptographic evidence of how an artifact was produced (inputs, build steps, identities).

- **Transparency log (tlog):** an append-only, verifiable log (typically Merkle-tree-based) that provides inclusion and consistency proofs; used to make releases/keys globally auditable.
- **Witness (tlog witness):** an independent service/operator that cosigns transparency-log checkpoints (tree heads) so equivocation/split-view attacks are harder.
- **Split view (equivocation):** a transparency-log attack where different parties are shown different log histories/checkpoints, undermining global accountability.

- **Confidential computing (CC):** hardware/firmware-backed isolation for virtual machines or enclaves plus remote attestation evidence, under explicit platform assumptions (see D-CC).
- **Attester / Verifier / Relying Party:** standard remote-attestation roles (Attester produces evidence, Verifier appraises it, Relying Party consumes the appraisal to decide whether to release secrets or allow actions).
- **REPORTDATA / user-data field:** a CC “challenge” field carried inside an attestation report/quote/token that can be used to bind evidence to an external digest (e.g., digest(CH-BOOT) + nonce).

- **Cap quota / cap budget:** an explicit accounting limit for creating kernel-maintained object references (capability slots, endpoints, etc.) to prevent resource-exhaustion DoS; typically enforced via D-METER mechanisms.
- **Capability graph:** the directed graph of “who holds what authority,” modeled as nodes (objects/domains) and edges (capabilities/derivations/ownership). Used for audit and leak detection.
- **Constructor / factory:** a user-space component that instantiates a confined subsystem from pinned templates (digests) + parameter data, returning an explicit exported surface (D-CONSTR).
- **Confinement test:** a regression test (often cap-graph export + delta check) that detects authority leaks across a declared boundary; used to keep “construction without ambient authority” honest (RFC-0042).


- **Interface digest:** a content-addressed identifier for an interface pin used on message boundaries (e.g., CH-CAPRPC `iface_digest`).
- **CH-IFACE:** a pinned interface descriptor artifact that binds interface identity to definition digests and an explicit evolution posture (open vs closed).
- **Ordinal / selector (method ordinal):** a numeric method identifier used for on-wire dispatch (e.g., CH-CAPRPC `method_id`). Ordinals must be stable (no reuse/renumbering); open interfaces often use hash-derived ordinals to enable additive method growth.
- **CH-ORD:** a pinned ordinal manifest artifact that records method name↔ordinal mappings for an interface family; used for drift guards and upgrade gates.
- **Open interface (D-APIEVO sense):** an interface that defines explicit behavior for unknown operations (e.g., `UNKNOWN_METHOD`) to allow safe additive evolution without lockstep upgrades.
- **Adapter / translator:** a component that mediates compatibility between old and new interfaces by mapping calls/responses explicitly, rather than relying on silent fallback in generic runtimes.

- **Attention authority:** the ability to interrupt or solicit user attention (e.g., notifications). Treated as a scarce resource: origin-branded, budgeted, and volition-gated for actions (D-ATTN).

- **W^X (write XOR execute):** memory protection policy where pages are either writable or executable, but not both.
- **Execmod:** a permission/effect that allows turning writable bytes into executable code at runtime (e.g., RW→RX flips, JIT codegen). In this archive it is treated as explicit authority under D-DYNCODE.
- **Dynamic code loading:** introducing new native executable code at runtime (e.g., `dlopen`/DSOs, runtime patching). Distinct from updating by replacing signed, sealed artifacts.
- **Sealed code space:** posture where executable code is fixed to a sealed set of signed artifacts (often content-addressed), and widening executability requires explicit, reviewable grants.
- **JIT (just-in-time compilation):** runtime generation of machine code. Useful, but an execution-enabling surface; treated as execmod under D-DYNCODE.

- **MTE (Memory Tagging Extension):** Arm hardware tagged-memory feature that assigns small tags to allocations and checks tag matches on loads/stores, helping catch UAF/overflow classes (often with sync/async modes). Used by D-MEMTAG profiles.

- **Trusting trust:** attack class where a compiler/toolchain injects malicious behavior into outputs (including into future compilers), so the running binary diverges from inspected source.
- **DDC (Diverse Double-Compiling):** mitigation technique that compiles a compiler’s source through an independent, diverse compilation path and checks for bit-for-bit equivalence with the compiler-under-test.
- **Bootstrappable builds:** build posture where the remaining bootstrap seed (initial binaries) is intentionally minimized and/or replaced by a chain that can be rebuilt from source “all the way down,” improving auditability of the toolchain.


- **Nondeterminism authority (D-NONDET):** treating time and randomness as explicit, capability-gated authorities (Clock/Entropy handles) rather than ambient syscalls; supports deterministic replay and makes high-resolution timers an explicit grant.
- **Clock handle:** a capability granting access to a time source (e.g., monotonic coarse/fine, realtime), described by CH-CLOCK.
- **Entropy handle:** a capability granting access to random bytes, with explicit quality/intent labeling (seed/stream/deterministic), described by CH-ENTROPY.
- **CapStore:** user-space capability store service for D-PERSIST that persists named roots and durable capability graphs (CH-CAPSTORE).
- **Capability wallet:** a *non-authoritative* descriptor (CH-WALLET) that summarizes an intended authority bundle (cap kinds/rights + pledge tokens + descriptor digests) for prompts, receipts, and CI drift gates. It does not contain bearer secrets or transfer capabilities.

- **Workflow plumbing (D-PLUMB):** a user-space workflow router that receives typed intent messages (CH-PLUMBMSG) and dispatches them via deterministic routing rules (CH-ROUTE), invoking portals as needed to return capabilities (handles, not paths).
- **Plumb message:** a non-authoritative intent envelope (CH-PLUMBMSG) used for cross-app routing; carries digests/refs/tags but not raw capabilities.
- **Plumb port:** a named subscription stream on the workflow router used for dispatching messages to handlers (Plan 9 plumber lineage).

- **Time-travel debugging (TTD):** debugging workflow that records an execution trace and allows replay forward and backward ("rewind"), enabling root-cause analysis without repeatedly reproducing the bug.
- **Reversible debugging:** umbrella term for stepping backward through execution, typically implemented via checkpoint+replay rather than true state reversal.
- **Omniscient debugging:** tooling style that treats an execution trace as a queryable database (e.g., value provenance/dataflow queries), often layered on record/replay traces.

- **Orthogonal persistence:** persistence property where any object may be made durable and is manipulated uniformly regardless of lifetime; contrasted with “files only” persistence.
- **Durable root:** a named entry point into durable state (e.g., `root/system`), updated only with explicit DurableRoot authority; used for resume/restore.
- **Membrane:** a wrapper/proxy that mediates a set of capabilities so that revocation or policy changes can cut off all authority obtained through it (D-MEMBRANE).

- **Sealer / unsealer:** object-capability pattern that “brands” an opaque token so only holders of the matching unsealer can interpret it; used to prevent type confusion and to safely wrap references across boundaries.
- **Revoker / caretaker:** object-capability patterns where a delegator hands out a mediated capability plus a separate revocation handle; revocation disables future use of the mediated capability.
- **Lease (capability lease):** a proxy capability that is intentionally bounded (time-limited and/or use-limited) so delegated authority is temporary by design (D-LEASE).
- **LeaseGate:** a proxy object that holds a raw capability privately and forwards only while lease bounds hold (RFC-0066).

- **Crypto provider:** a user-space service that holds key material and exposes only declared cryptographic operations via capabilities (often the auth agent).
- **Key handle:** a capability that authorizes operations on a key object; it is not the key bytes.
- **Non-exportable key (interface sense):** a key whose private material is never returned by an API; clients can only request operations like “sign”.
- **Purpose/context tag:** an explicit string included with a crypto operation to prevent cross-protocol “signing oracle” misuse; enforced by CH-KEYPOL when D-CRYPTOSVC is enabled.

- **Vault provider:** a user-space service that stores secrets/credentials as objects and releases/uses them only via capability-mediated operations checked against CH-SECRETPOL (D-VAULT).
- **Secret handle:** a capability that authorizes a bounded operation on a secret object (read/wrap/rotate/delete), not raw storage access.
- **CH-SECRETPOL:** a pinned, reviewable secret usage policy descriptor (contexts + evidence requirements).
- **CH-SECRETREF:** a durable, shareable reference to a secret object and its pinned policy (no secret bytes), suitable for CapStore.

- **Tracepoint / probe:** a predeclared instrumentation site that emits a bounded CH-TRACE event.
- **Trace processor:** an untrusted user-space computation over CH-TRACE streams (often a Wasm component) that emits bounded, redaction-safe aggregates (D-TRACEPROC).
- **Trace predicate:** a bounded boolean expression over declared CH-TRACE event fields used to prefilter trace streams (CH-TPRED; D-TPRED).
- **Tracepoint descriptor manifest:** a pinned mapping from trace `probe` IDs to ordered field descriptors (names/types/redaction) used to interpret CH-TRACE streams and validate predicates (CH-TPROBE; D-TPROBE).
- **Triage rules:** pinned, bounded diagnosis rules (CH-TRIAGE; D-TRIAGE) evaluated over CH-INSPECT and/or CH-CRASHCAP to emit bounded findings and advisory snapshot requests, while export authority remains constrained by CH-OBSPOL and capability gates.
- **Covert channel:** unintended information flow via side effects (timing, ordering, rates) rather than explicit data fields.
- **Health predicate:** a pinned, profile-defined definition of "healthy" for boot success/commit decisions (CH-HEALTH; D-HEALTH).
- **Boot assessment:** a post-boot user-space step that blesses/commits a boot only after a completion barrier is met (e.g., systemd automatic boot assessment, Android `markBootSuccessful`).
- **Ready barrier:** a one-shot readiness handshake for a component, used by supervision and health evaluation to avoid time-only heuristics.

- **Quiescence (service quiesce):** a cooperative service state where new externally-triggered work is gated and in-flight work is drained or explicitly canceled to obtain a consistent cut for maintenance (shutdown, upgrade, checkpoint) (D-QUIESCE).
- **Drain (connection/work drain):** a quiesce mode that stops accepting new work while allowing in-flight work to finish within a bounded grace period; contrasted with cancel/abort modes.

- **Flight recorder:** bounded retention of recent diagnostics (logs/traces/state) in ring buffers so crashes/hangs can capture “what just happened” without unbounded logging.
- **Crash-survivor buffer:** a small reserved region intended to survive reboot (pstore-like) for last-gasp diagnostics; high leverage but sensitive.

- **Robust lock / robust mutex:** a shared-memory synchronization primitive that provides an explicit **owner-death** outcome if the previous owner terminates while holding the lock (prevents permanent deadlock).
- **OWNER_DIED / abandoned:** a flag/result indicating the lock was acquired but the protected state may be inconsistent because the previous owner exited without releasing it.
- **make_consistent():** an explicit post-recovery step that clears OWNER_DIED after the new owner repairs state (or, alternatively, the component fails closed/restarts).

- **CPU-local / per-CPU:** a sharding technique where each CPU (or vCPU) has its own slot/arena/counter to reduce contention; requires care under thread migration and hotplug.
- **Restartable sequence (rseq):** a tiny user-space code region intended to run start→commit on a single CPU; if the thread is preempted/migrated before commit, the kernel redirects control to a user abort handler (D-RSEQ).
- **Commit point (rseq):** the instruction boundary after which a restartable region is considered completed; designs must avoid “partial commit” ambiguity.

