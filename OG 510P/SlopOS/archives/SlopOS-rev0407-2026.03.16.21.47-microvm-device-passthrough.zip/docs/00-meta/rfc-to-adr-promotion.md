# RFC → ADR promotion rubric (evidence-gated)

Purpose: prevent premature decisions; keep the repo small by turning long debates into short, evidence-backed ADRs.

## RFC vs ADR
- **RFC**: explores options; may change freely; records unknowns + experiments.
- **ADR**: commits a choice; pins scope; updates registries; changes only via a superseding ADR.

## Promotion criteria (must all hold)
1) Scope pinned: what is decided and what is explicitly *not* decided.
2) Claim impact enumerated: which **C-*** are affected (or “none”).
3) Invariants/POs exist: references to relevant **I-***/**PO-*** (or added).
4) Interface impact pinned: affected **IF-***/**CH-*** are named (or “none”).
5) Evidence exists: at least one of E0/E1/E2 is present in `evidence-index.md`.
6) TCB delta accounted (if boundary-affecting): update [TCB inventory](../20-assurance/tcb.md) and (if needed) [release profiles](../60-engineering/release-profiles.md).
7) Exit ramp: what evidence would falsify the decision and what we would change.

## Anti-patterns (do not promote)
- preferences without evidence hooks
- silent expansion of privileged surfaces (IF-*)
- decisions that create new IDs without updating registries
