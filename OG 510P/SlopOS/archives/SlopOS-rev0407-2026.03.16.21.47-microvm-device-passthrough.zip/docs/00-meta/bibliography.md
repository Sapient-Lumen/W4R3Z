# Annotated bibliography (REF index)

Rule: each REF entry is ≤3 bullets: **key idea** / **why it matters** / **implication for us**.
No pasted papers; just pointers.

## Verified kernels & microkernels
- **REF-SEL4-SOSP09** — seL4 verification (SOSP 2009) — https://www.sigops.org/s/conferences/sosp/2009/papers/klein-sosp09.pdf  
  - key: end-to-end functional correctness via refinement
  - why: sets the assurance bar
  - us: constrain interfaces + start spec/refinement early
- **REF-SEL4-L4V** — L4.verified proofs repo (Isabelle/HOL) — https://github.com/seL4/l4v  
  - key: proof engineering at scale
  - why: maintenance/traceability patterns
  - us: keep Claim→Invariant→Evidence and release-tied proof drift
- **REF-SEL4-COMPREHENSIVE** — seL4 program writeup — https://sel4.systems/Research/pdfs/comprehensive-formal-verification-os-microkernel.pdf  
  - key: disciplined scope control
  - why: shows what blows up
  - us: MVP slices + hard “non-claims” posture
- **REF-SEL4-INFOFLOW** — seL4 info-flow proof — https://sel4.systems/Research/pdfs/sel4-from-general-purpose-to-proof-information-flow-enforcement.pdf  
  - key: security property layered on functional correctness
  - why: roadmap for A3
  - us: only claim within explicit observation/channel model
- **REF-SEL4-TIMEPROTECTION** — *Time Protection: The Missing OS Abstraction* (EuroSys 2019) — https://tomchothia.gitlab.io/Papers/EuroSys19.pdf  
  - key: timing isolation needs explicit OS abstractions (not just careful coding)
  - why: credible blueprint for a scoped timing-channel model
  - us: keep as optional D-SIDECH scope; do not implicitly assume timing safety
- **REF-SEL4-SCHEDCTX-EUROSYS18** — *Scheduling-context capabilities: A principled, light-weight OS mechanism for managing time* (EuroSys 2018) — https://trustworthy.systems/publications/full_text/Lyons_MAH_18.pdf  
  - key: scheduling context as a capability object representing time, separable from threads
  - why: keeps kernel scheduling policy light while enabling mixed-criticality and strong attribution
  - us: treat time as explicit authority (D-TCAP) and make RPC-friendly time donation a first-class pattern
- **REF-SEL4-MCS-TUTORIAL** — seL4 MCS tutorial (passive servers, SC donation) — https://docs.sel4.systems/Tutorials/mcs.html  
  - key: practical API patterns for configuring scheduling contexts and passive servers
  - why: shows the ergonomics needed for real systems (not just a paper model)
  - us: keep our D-TCAP profile usable: concrete bind/unbind/donate lifecycle + tests
- **REF-SEL4-IRQ-TUTORIAL** — seL4 interrupts tutorial (IRQControl; explicit IRQ caps) — https://docs.sel4.systems/Tutorials/interrupts.html  
  - key: interrupts (including timer IRQs) are obtained via explicit capabilities (IRQControl → handler cap)
  - why: a concrete precedent for treating timing sources as authority, not an ambient channel
  - us: keep high-resolution timing surfaces policy-gated under D-NONDET/D-SIDECH; avoid ambient timer APIs

- **REF-SEL4-API-SC-UNBIND** — seL4 API reference: scheduling context unbind/return semantics — https://docs.sel4.systems/projects/sel4/api-doc.html  
  - key: donated scheduling contexts are returned to the original owner when unbound/replied
  - why: clarifies the conservation/return rule that makes donation safe
  - us: encode this as I-TCAP-2 + PO-TCAP-DONATE (no duplication, deterministic return)
- **REF-CERTIKOS-OSDI16** — CertiKOS (OSDI 2016) — https://www.usenix.org/system/files/conference/osdi16/osdi16-gu.pdf  
  - key: compositional certified kernels, concurrency-aware refinement
  - why: concurrency + refinement tactics
  - us: informs staged multicore + mechanized refinement planning

- **REF-LINUX-SCHED-CAPACITY** — Linux scheduler: Capacity Aware Scheduling — https://docs.kernel.org/scheduler/sched-capacity.html  
  - key: heterogeneous CPUs are modeled with relative capacity values used for scheduler placement/fitness
  - why: strong primary-source precedent for treating CPU-capacity facts as optimization data
  - us: keep perf-class facts useful for placement without silently turning them into authority boundaries
- **REF-LINUX-UTILCLAMP** — Linux scheduler: Utilization Clamping — https://docs.kernel.org/scheduler/sched-util-clamp.html  
  - key: performance-point requests are explicit scheduler hints, not ambient authority
  - why: useful precedent for “performance preference” as a hint surface
  - us: any future SlopOS perf-point interface should stay explicit and non-authoritative unless separately specified
- **REF-ACPI-CPPC-HETERO** — ACPI 6.4 Device Configuration / _OSC diverse CPPC Highest Performance support — https://uefi.org/htmlspecs/ACPI_Spec_6_4_html/06_Device_Configuration/Device_Configuration.html  
  - key: firmware can expose heterogeneous highest-performance information for OS optimization
  - why: shows that performance-class diversity is real platform metadata, not just a Linux-internal invention
  - us: accept heterogeneous-core facts as auditable inputs while keeping authority semantics local and explicit

## IFC / labeled systems
- **REF-DIFC-SOSP97** — A Model for Decentralized Information Flow Control (SOSP 1997) — https://www.cs.cornell.edu/andru/papers/iflow-sosp97/paper.html  
  - key: decentralized authority over declassification/endorsement (not a single global policy)
  - why: the conceptual foundation that makes DIFC usable in multi-principal systems
  - us: keep D-IFC privileges as capabilities and treat “widening flows” as explicit authority (I-IFC-3)

- **REF-HISTAR-SOSP06** — HiStar (SOSP 2006) — https://www.scs.stanford.edu/~nickolai/papers/zeldovich-histar.pdf  
  - key: small kernel + strict information-flow control with labels; “no superuser” posture
  - why: shows DIFC can coexist with Unix-like environments by pushing most policy into untrusted code
  - us: motivates an optional D-IFC substrate with explicit, scoped claims (C-IFC-1) and a small privileged check surface

- **REF-ASBESTOS-SOSP05** — Asbestos: Labels and event processes (SOSP 2005) — https://pdos.csail.mit.edu/papers/asbestos-sosp05.pdf  
  - key: fine-grained labeling within processes (“event processes”) to avoid VM-per-label granularity
  - why: demonstrates that IFC is an ergonomics problem as much as a policy problem
  - us: start IFC-lite on a small subset (sinks + selected channels) and avoid “label everything” by default

- **REF-FLUME-SOSP07** — Flume: Information flow control for standard OS abstractions (SOSP 2007) — https://pdos.csail.mit.edu/papers/flume-sosp07.pdf  
  - key: DIFC model aligned with common OS objects (pipes/files/sockets) and explicit label-change privileges
  - why: practical precedent for “labels + privileges as caps” that map onto real application shapes
  - us: supports our IFC-lite approach: enforce `flow_ok` at a small set of primitives and make declassify/endorse transcript-visible (PO-IFC-DECLASS)
- **REF-FLUME-NONINTERFERENCE** — Noninterference for a Practical DIFC-Based Operating System (follow-up analysis) — https://cs-people.bu.edu/tromer/papers/flumecsp.pdf  
  - key: kernel-enforced information-flow via labels and explicit gates
  - why: clean precedent for staged IFC claims
  - us: start with IFC-lite on a scoped subset (D-IFC), not “label everything”

## Verified hypervisors / separation kernels
- **REF-SEKVM-SP21** — SeKVM (IEEE S&P 2021) — https://www.cs.columbia.edu/~nieh/pubs/ieeesp2021_kvm.pdf  
  - key: verified security argument over commodity virtualization paths
  - why: precedent for hypervisor-first verification slices
  - us: isolate exit handling + make “surface budget” explicit
- **REF-MUEN-SK** — Muen separation kernel repo — https://github.com/codelabs-ch/muen  
  - key: separation-kernel posture + minimal runtime surface

## Assurance cases / argumentation
- **REF-SCSC-GSN** — Goal Structuring Notation (GSN) standardisation hub (SCSC) — https://scsc.uk/gsn  
  - key: standardized structure for claims/arguments/evidence (GSN)
  - why: helps keep assurance intent explicit and reviewable
  - us: supports having stable “claim surfaces” (like profile claim matrices) without turning them into prose
- **REF-OMG-SACM-21** — Structured Assurance Case Metamodel (SACM) v2.1 (OMG) — https://www.omg.org/spec/SACM/2.1/PDF  
  - key: metamodel for structured assurance cases (claims/argumentation/artifacts)
  - why: a common representation for traceability and tooling
  - us: informs future machine-checkable Claim→Invariant→Evidence wiring without changing our Phase 1 scope
  - why: contrast to featureful microkernels
  - us: candidate static-partition profile extension
- **REF-MUEN-SYSTEM-SPEC** — Muen System Specification (PDF) — https://muen.codelabs.ch/doc/muen-system-spec.pdf  
  - key: policy-described system composition with static resource assignment
  - why: a concrete “policy-as-artifact” template for D-PART / CH-PART
  - us: informs what the privileged core validates vs what tooling produces
- **REF-MUEN-KERNEL-SPEC** — Muen Kernel Specification (PDF) — https://muen.codelabs.ch/doc/muen-kernel-spec.pdf  
  - key: minimal kernel responsibilities under a separation-kernel model
  - why: helps scope what must be in the privileged core vs user space
  - us: supports our “validate+install policy” stance for the early slice
- **REF-JAILHOUSE** — Jailhouse partitioning hypervisor — https://github.com/siemens/jailhouse  
  - key: static partitioning into “cells”; simplicity over feature richness
  - why: practical reference for a high-isolation deployment mode
  - us: comparison point for D-MICROVM and static-partition profiles
- **REF-NOVA-EUROSYS10** — NOVA microhypervisor (EuroSys 2010) — https://os.inf.tu-dresden.de/papers_ps/steinberg_eurosys2010.pdf  
- **REF-NOVA-ABI-FOSDEM25** — *A Formal Specification of the NOVA Microhypervisor’s ABI* (FOSDEM 2025) — https://archive.fosdem.org/2025/events/attachments/fosdem-2025-5083-a-formal-specification-of-the-nova-microhypervisor/slides/238242/paper_WDpfx6o.pdf  
  - notes: formal ABI/interface spec (incl. concurrency/arch behaviors) that can inform CH-KABI normalization and proof strategy
  - key: tiny microhypervisor + deprivileged multi-server environment
  - why: management plane should not be privileged by default
  - us: require CH-KABI mediated effects + transcripts for privileged actions
- **REF-NOVA-IFACE-2008** — Formal Nova interface specification (Robin project, 2008) — https://user.it.uu.se/~tjawe125/publications/tews08specification.html  
  - notes: imperative pseudo-code spec + semantics for the ABI-level operations; useful for interface-as-spec framing
- **REF-NOVA-PROOF-BRANCH** — NOVA formal specification/proofs (BluerockSec branch pointer) — https://github.com/udosteinberg/NOVA  
- **REF-BLUEROCK-NOVA-OPEN2025** — BlueRock Formal Methods, *The Formal Specs and Proofs of NOVA are now open-sourced* (Oct 16, 2025) — https://bluerocksec.gitlab.io/formal-methods/blogs/2025-10-16-NOVA-specs-proofs-open/
- **REF-BLUEROCK-NOVA-APPROACH2025** — BlueRock Formal Methods, *The approach of specifying and verifying NOVA* (Nov 18, 2025) — https://bluerocksec.gitlab.io/formal-methods/blogs/2025-11-18-NOVA-proof-spec/
- **REF-BLUEROCK-NOVA-STATUS2025** — BlueRock Formal Methods, *Specs and Proofs are up-to-date with the October release (25.43.0)* (Nov 18, 2025) — https://bluerocksec.gitlab.io/formal-methods/blogs/2025-11-18-NOVA-october-release/
  - notes: points to an external proof/spec branch; useful as a breadcrumb for artifact reuse/evaluation
- **REF-FIRECRACKER-NSDI20** — Firecracker microVM VMM (NSDI 2020) — https://www.usenix.org/system/files/nsdi20-paper-agache.pdf  
  - key: minimal device model + reduced virtualization surface for microVMs
  - why: device model is the silent TCB
  - us: treat D-MICROVM as a primary candidate slice
- **REF-FIRECRACKER-KERNEL-POLICY** — Firecracker guest kernel policy (virtio transport notes; PCI optional) — https://github.com/firecracker-microvm/firecracker/blob/main/docs/kernel-policy.md  
  - key: operationally pins “what the guest needs” for the minimal device model
  - why: keeps microVM support from drifting into implicit firmware/device assumptions
  - us: reference when scoping v0 `ext.microvm` posture and test kernels
- **REF-FIRECRACKER-VSOCK** — Firecracker virtio-vsock design doc — https://github.com/firecracker-microvm/firecracker/blob/main/docs/vsock.md  
  - key: host/guest transport via virtio-vsock for microVM-hosted services
  - why: clarifies the transport surface that snapshot/restore must not silently treat as durable continuity
  - us: background for D-MICROVM / D-EPHEM continuity claims

- **REF-FIRECRACKER-SNAPSHOT-SUPPORT** — Firecracker docs: Snapshot support — https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/snapshot-support.md  
  - key: snapshot/restore support with explicit caveats; restored microVMs do not preserve ordinary live network/vsock session continuity automatically
  - why: production microVM precedent that warm restore is not the same thing as keeping live connectivity/session state
  - us: informs D-EPHEM v0’s ‘no hidden continuity’ rule for clone/snapshot accelerators

- **REF-FIRECRACKER-MEMORY-HOTPLUG** — Firecracker docs: Memory hotplug (`virtio-mem`) — https://github.com/firecracker-microvm/firecracker/blob/main/docs/memory-hotplug.md  
  - key: host sets a requested/target size and the guest plugs or unplugs memory blocks to match; status exposes plugged/requested size
  - why: direct evidence that guest-visible memory resize is a host↔guest control/status surface rather than a neutral implementation detail
  - us: supports fixing guest-visible RAM topology at admission in Phase 1 instead of standardizing a balloon/hotplug control plane under `ext.microvm`

- **REF-FIRECRACKER-MACHINE-CONFIG** — Firecracker Swagger: `/machine-config` (pre-boot only) — https://github.com/firecracker-microvm/firecracker/blob/main/src/firecracker/swagger/firecracker.yaml  
  - key: Firecracker updates machine configuration including `vcpu_count` via `/machine-config`, and both PUT and PATCH are explicitly **Pre-boot only**
  - why: direct evidence that guest-visible CPU count/SMT are treated as admission-time machine configuration rather than a running guest resize/control plane
  - us: supports fixing guest-visible vCPU count/topology at admission in Phase 1 instead of standardizing CPU hotplug under `ext.microvm`
- **REF-FIRECRACKER-NETIFACE** — Firecracker Swagger: `/network-interfaces/{iface_id}` (pre-boot create/update; post-boot rate-limiter patch only) — https://github.com/firecracker-microvm/firecracker/blob/main/src/firecracker/swagger/firecracker.yaml  
- **REF-FIRECRACKER-DRIVES** — Firecracker Swagger: `/drives/{drive_id}` (pre-boot create/update; post-boot property updates only) — https://github.com/firecracker-microvm/firecracker/blob/main/src/firecracker/swagger/firecracker.yaml  
- **REF-FIRECRACKER-SERIAL** — Firecracker changelog: `/serial` endpoint redirects guest serial-console output to a pre-created file, defaults to stdout if unset, and the setting is not persisted across snapshots — https://github.com/firecracker-microvm/firecracker/blob/main/CHANGELOG.md  
- **REF-FIRECRACKER-ENTROPY-DEVICE** — Firecracker Swagger: `/entropy` (pre-boot only entropy device) — https://github.com/firecracker-microvm/firecracker/blob/main/src/firecracker/swagger/firecracker.yaml  
  - key: one optional entropy device can be enabled per VM via a pre-boot `/entropy` endpoint rather than being an inherent always-on part of the guest contract
  - why: direct evidence that guest-visible host-backed entropy is a deliberate configuration surface, not a neutral always-present baseline
  - us: supports keeping guest-visible entropy-device/source semantics out of the portable Phase 1 `ext.microvm` contract
- **REF-FIRECRACKER-MMDS** — Firecracker docs: microVM Metadata Service (MMDS) user guide — https://github.com/firecracker-microvm/firecracker/blob/main/docs/mmds/mmds-user-guide.md  
  - key: mutable host-managed data store that can be shared with guests, activated by allowing requests on configured guest network interfaces
  - why: direct evidence that guest-readable metadata endpoints are a real host↔guest bootstrap/control surface rather than a neutral implementation detail
  - us: supports keeping MMDS / IMDS-style metadata access out of the portable Phase 1 `ext.microvm` contract
- **REF-FIRECRACKER-MMDS-API** — Firecracker Swagger: `/mmds` data store and `/mmds/config` (pre-boot config with network interfaces that allow MMDS requests) — https://github.com/firecracker-microvm/firecracker/blob/main/src/firecracker/swagger/firecracker.yaml  
  - key: mutable MMDS store plus explicit pre-boot configuration of the IPv4 address and guest interfaces that may forward requests to MMDS
  - why: direct evidence that metadata/bootstrap exposure is a designated guest-visible control plane, not ambient networking
  - us: supports Phase 1’s decision to keep guest-readable metadata/bootstrap channels absent unless a later RFC pays for them explicitly
- **REF-QEMU-FWCFG** — QEMU docs: Firmware Configuration (`fw_cfg`) device — https://www.qemu.org/docs/master/specs/fw_cfg.html  
  - key: guest-readable firmware interface for blobs that influence firmware/guest configuration, including boot order, ACPI/SMBIOS tables, UUID, SMP/NUMA info, and direct kernel/initrd images
  - why: direct evidence that firmware-config namespaces are a host→guest bootstrap data plane rather than a neutral implementation detail
  - us: supports keeping `fw_cfg`-style bootstrap/config injection out of the portable Phase 1 `ext.microvm` contract
- **REF-CLOUDINIT-NOCLOUD** — cloud-init docs: NoCloud datasource — https://docs.cloud-init.io/en/latest/reference/datasources/nocloud.html  
  - key: local or remote datasource that supplies `user-data`, `meta-data`, `vendor-data`, and `network-config` to an instance at runtime
  - why: concrete ecosystem precedent for turning first-boot configuration into a guest-visible metadata/bootstrap contract
  - us: supports keeping cloud-init datasource semantics out of the portable Phase 1 `ext.microvm` contract
- **REF-CLOUDINIT-CONFIGDRIVE** — cloud-init docs: ConfigDrive datasource — https://docs.cloud-init.io/en/latest/reference/datasources/configdrive.html  
  - key: config-drive disk can provide networking information and equivalents of instance-metadata-service data such as authorized keys and metadata files
  - why: direct evidence that attached disks can act as an ambient bootstrap/configuration plane instead of ordinary storage
  - us: supports keeping config-drive semantics out of the portable Phase 1 `ext.microvm` contract

- **REF-QEMU-CPU-HOTPLUG** — QEMU docs: Virtual CPU hotplug — https://www.qemu.org/docs/master/system/cpu-hotplug.html  
  - key: hotplug requires `query-hotpluggable-cpus` plus explicit `device_add` with socket/core/thread properties
  - why: shows that guest-visible CPU hot-add is a real runtime control plane with slot/topology/status semantics, not a neutral implementation detail
  - us: supports keeping vCPU hotplug / slot inventory / online-offline meaning out of the portable Phase 1 `ext.microvm` contract

- **REF-FIRECRACKER-BALLOONING** — Firecracker docs: Ballooning and free-page hinting — https://github.com/firecracker-microvm/firecracker/blob/main/docs/ballooning.md  
  - key: Firecracker exposes start/status/stop endpoints for free-page hinting and uses command/status ids to coordinate with the guest driver
  - why: shows that memory reclamation/hinting semantics are also an explicit host↔guest control surface, not just an invisible optimization
  - us: supports keeping guest memory statistics/hinting out of the portable Phase 1 contract

- **REF-FIRECRACKER-CPU-TEMPLATES** — Firecracker docs: CPU templates — https://github.com/firecracker-microvm/firecracker/blob/main/docs/cpu_templates/cpu-templates.md  
  - key: heterogeneous fleets can be normalized by masking guest CPU features into a reviewed common class; host passthrough is not the portability story
  - why: concrete microVM precedent that portability across hosts must be designed into the exposed guest CPU surface before launch/snapshot reuse
  - us: supports the v0 rule that heterogeneous restore sets are handled before the template cut by choosing a narrower reviewed class

- **REF-QEMU-CPU-MODELS** — QEMU docs: QEMU / KVM CPU model configuration — https://www.qemu.org/docs/master/system/i386/cpu.html  
- **REF-QEMU-QMP-BLOCK** — QEMU docs: QMP command surfaces for `device_add` / `device_del`, `blockdev-add`, `blockdev-del`, and related block-device mutation — https://www.qemu.org/docs/master/qapi-qmp-index.html  
- **REF-QEMU-CHARDEV** — QEMU user docs: character-device backends plus `mux=on` multiplexing for serial/monitor frontends (stdio, files, Unix/TCP sockets, and shared control backends) — https://www.qemu.org/docs/master/system/qemu-manpage.html  
- **REF-QEMU-RNG-BACKENDS** — QEMU user docs: `virtio-rng` can be backed by built-in RNG, host device files, or external entropy daemons — https://www.qemu.org/docs/master/system/qemu-manpage.html  
  - key: QEMU treats guest-visible RNG as a configurable device/backend surface (`rng-builtin`, `rng-random`, `rng-egd`) rather than a single intrinsic VM property
  - why: direct evidence that host-backed guest entropy is a real source-selection/control surface in the ecosystem
  - us: supports Phase 1’s refusal to standardize a portable guest-visible entropy-device/source contract under `ext.microvm`
- **REF-QEMU-SECURITY** — QEMU docs: security considerations for monitor/QMP control, including `blockdev-add` exposing arbitrary files as virtual disks — https://www.qemu.org/docs/master/system/security.html  
  - key: host passthrough gives best fidelity/performance when migration is not required, while safer cross-host portability depends on choosing a named/normalized CPU model rather than expecting arbitrary hosts to match later
  - why: primary virtualization guidance that compatibility classes are an explicit admission choice, not a best-effort runtime guess
  - us: supports the v0 microVM resume-class posture: same-class-or-fail-closed, with heterogeneity normalized before the cut

- **REF-FIRECRACKER-ENTROPY-CLONES** — Firecracker docs: Entropy for Clones — https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/handling-entropy.md  
  - key: cloned/snapshotted guests can repeat entropy state unless snapshot logic and guest setup are designed carefully
  - why: direct evidence that warm cloning needs an explicit entropy/identity refresh story
  - us: informs D-EPHEM v0’s clone-state hygiene requirements before first user payload runs

- **REF-UAPI-VMCLOCK** — UAPI.13 VMClock — https://uapi-group.org/specifications/specs/vmclock/  
  - key: guest-visible precision-time structure with disruption markers and `vm_generation_counter` for snapshot/restore detection
  - why: provides a vendor-neutral, guest-visible signal for restore/clone hygiene without inventing a host agent
  - us: preferred v0 generation witness when `ext.microvm` guests must detect restore before resumed payload matters

- **REF-UAPI-VMGENID** — UAPI.14 VMGenID — https://uapi-group.org/specifications/specs/vmgenid/  
  - key: 128-bit cryptographically random generation identifier that changes on snapshot restore, backup recovery, clone/copy/import, or failover to non-unique state
  - why: minimal explicit signal for guest software to detect clone/restore and repair entropy/unique-id state
  - us: accepted v0 fallback witness when VMClock `vm_generation_counter` is unavailable

- **REF-BROOKER-UNIQUENESS** — Brooker et al., *Restoring Uniqueness in MicroVM Snapshots* — https://arxiv.org/abs/2102.12892  
  - key: reusable post-init snapshots duplicate high-value memory contents and require explicit uniqueness/secret handling
  - why: primary research precedent for keeping reusable warm-start snapshots secret-clean and uniqueness-aware
  - us: supports the v0 template-cut rule that fan-out snapshots are taken before secret ingress or live imported authority

- **REF-AWS-SNAPSTART-UNIQUENESS** — AWS Lambda docs: Handling uniqueness with Lambda SnapStart — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-uniqueness.html  
  - key: reusable initialized snapshots must not carry unique ids, unique secrets, or entropy-dependent state intended to stay unique across resumed environments
  - why: concrete production guidance for post-restore uniqueness repair under snapshot fan-out
  - us: supports the v0 rule that reusable templates stay secret-clean and reacquire uniqueness-sensitive state after restore

- **REF-AWS-SNAPSTART-RUNTIME-HOOKS** — AWS Lambda docs: Implement code before or after Lambda function snapshots — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-runtime-hooks.html  
  - key: before-checkpoint/after-restore hooks are useful runtime-specific techniques for cleanup and re-initialization around snapshots
  - why: primary operations doc showing hooks are implementation techniques rather than a universal contract
  - us: supports keeping checkpoint hooks implementation-local instead of standardizing a new SlopOS hook plane

- **REF-AWS-SNAPSTART-ACTIVATE** — AWS Lambda docs: Activating and managing Lambda SnapStart — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-activate.html  
  - key: Lambda creates a snapshot for each published function version, and updating the snapshot means publishing a new version
  - why: strong production precedent for refresh-by-new-version rather than mutating a reusable snapshot in place
  - us: supports treating reusable warm-start templates as admitted leaves under a parent lineage, not mutable live objects

- **REF-AWS-SNAPSTART-SECURITY** — AWS Lambda docs: Security model for Lambda SnapStart — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-security.html  
  - key: SnapStart snapshots are encrypted at rest with AWS KMS keys under the owning function/account policy surface
  - why: production precedent for treating warm-state artifacts as provider-/owner-local managed inputs rather than public release artifacts
  - us: supports the v0 rule that reusable warm-state leaves stay owner-local admission accelerators rather than a portable/public artifact class

- **REF-AWS-LAMBDA-RUNTIME-ENV** — AWS Lambda docs: Understanding the Lambda execution environment lifecycle — https://docs.aws.amazon.com/lambda/latest/dg/lambda-runtime-environment.html  
  - key: Lambda persists an encrypted snapshot of initialized memory/disk state and caches it for low-latency restore when SnapStart is enabled
  - why: concrete provider-local lifecycle example for warm-state storage/caching without implying a public warm-state bundle format
  - us: supports keeping warm-state artifact management provider-local while portable distribution continues to ship cold deployment lineage

- **REF-AWS-LAMBDA-VERSIONS** — AWS Lambda docs: Manage Lambda function versions — https://docs.aws.amazon.com/lambda/latest/dg/configuration-versions.html  
  - key: published function versions are immutable snapshots of code and configuration, and the qualified version ARN is unique
  - why: concrete parent-identity model for reusable execution snapshots
  - us: supports binding reusable templates to one reviewed deployment/template lineage rather than treating them as standalone deployable artifacts

- **REF-QEMU-VMGENID** — QEMU VM Generation ID Device — https://www.qemu.org/docs/master/specs/vmgenid.html  
  - key: concrete implementation notes and interoperability requirements for exposing VMGenID to guests
  - why: shows a real-world VMM path for guest-visible clone/restore detection without a custom control plane
  - us: grounding for D-MICROVM generation-witness posture and future implementation sketches

- **REF-CHYP-SNAPSHOT-STABILITY** — Cloud Hypervisor release stability notes — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/releases.md  
  - key: snapshot/restore and live migration are not guaranteed across major versions
  - why: reinforces that snapshot artifacts are implementation/version scoped rather than a portable continuity ABI
  - us: treat microVM warm-restore as a local accelerator unless a future explicit profile says otherwise
- **REF-CHYP-VSOCK** — Cloud Hypervisor vsock support notes — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/vsock.md  
- **REF-CHYP-HOTPLUG** — Cloud Hypervisor docs: CPU and memory hotplug — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/hotplug.md  
- **REF-CHYP-COMMANDS** — Cloud Hypervisor commands: `--serial` / `--console` support `off|null|pty|tty|file|socket` style console backends — https://www.cloudhypervisor.org/docs/prologue/commands/  
  - key: Cloud Hypervisor exposes HTTP API-driven resize semantics for RAM and CPUs, with guest cooperation and reboot caveats for some reductions
  - why: another modern virtio-first VMM precedent that dynamic guest memory sizing is an explicit runtime control plane
  - us: supports Phase 1’s decision to keep guest-visible memory topology fixed at admission unless a future RFC standardizes resize semantics explicitly
  - key: production virtio-only VMMs commonly expose vsock as a guest↔host comm path
  - why: reinforces that vsock is a tempting default for management planes
  - us: if adopted, require lane-gating + lease/portal shaping; otherwise forbid in Phase 1
- **REF-LINUX-VSOCK-MAN7** — Linux `vsock(7)` man page (AF_VSOCK) — https://man7.org/linux/man-pages/man7/vsock.7.html  
  - key: AF_VSOCK is a socket family (CID, port) with normal socket semantics
  - why: if exposed, it is effectively an ambient socket constructor surface
  - us: v0 forbids vsock; any later admission must be non-ambient and policy-killable
- **REF-VIRTIOFS-DESIGN** — Virtiofs design document — https://virtio-fs.gitlab.io/design.html  
  - key: host directory-tree sharing for VMs with near-local filesystem semantics
  - why: powerful developer ergonomics, but a high-risk ambient path/metadata channel
  - us: v0 forbids host FS sharing devices; any later admission must be explicit + killable
- **REF-LINUX-VIRTIOFS** — Linux kernel virtiofs documentation — https://docs.kernel.org/filesystems/virtiofs.html  
  - key: guest↔host FS sharing driver (virtio-fs device + FUSE userspace daemon)
  - why: clarifies the complexity + attack surface of filesystem sharing
  - us: use for threat modeling if we ever admit virtio-fs; v0 forbids it
- **REF-VIRTIO-1.3** — OASIS Virtual I/O Device (virtio) spec v1.3 (PDF) — https://docs.oasis-open.org/virtio/virtio/v1.3/virtio-v1.3.pdf  
  - key: standard paravirtual device semantics (queues/features/transports)
  - why: a “minimal device model” still needs a precise, shared contract
  - us: treat virtio device types as the default microVM I/O surface; avoid bespoke devices
- **REF-QEMU-MICROVM** — QEMU `microvm` machine type docs — https://www.qemu.org/docs/master/system/i386/microvm.html  
  - key: minimalist VM machine model (explicitly *without* PCI/ACPI)
  - why: concrete precedent for “no legacy glue” microVM posture
  - us: use as a comparison point for D-MICROVM v0 scope and exit-surface budgeting
- **REF-KVM-API** — Linux Kernel-based Virtual Machine API documentation — https://docs.kernel.org/virt/kvm/api.html  
  - key: authoritative ioctl-level VM control surface (host substrate)
  - why: clarifies what the VMM must do vs what is kernel-provided
  - us: reference when budgeting privileged/device-model surface in a hypervisor-first slice
- **REF-CHYP-DEVICE-MODEL** — Cloud Hypervisor device model docs — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/device_model.md  
  - key: modern virtio-only device model for cloud workloads
  - why: demonstrates a “no legacy emulation” direction in a production-oriented VMM
  - us: comparison point for what virtio set and complexity emerges in practice
- **REF-LINUX-VFIO** — Linux kernel docs: VFIO (“Virtual Function I/O”) — https://docs.kernel.org/driver-api/vfio.html
  - key: VFIO is an IOMMU/device-agnostic framework for exposing direct device access to userspace; groups are the ownership unit because DMA isolation is not always per-device
  - why: primary-source grounding that device passthrough is fundamentally a DMA/IOMMU/isolation problem, not just a convenience flag
  - us: informs the microVM passthrough-device posture so guest-visible passthrough does not bypass D-DMA review or become ambient authority
- **REF-LINUX-VFIO-MDEV** — Linux kernel docs: VFIO mediated devices — https://docs.kernel.org/driver-api/vfio-mediated-device.html
  - key: mediated devices reuse VFIO for GPUs, network adapters, and compute accelerators, and explicitly model create/destroy + IOMMU-group membership operations
  - why: primary-source reminder that mdev/SR-IOV-style virtualization still creates a real attach/profile/control surface rather than a neutral compatibility layer
  - us: informs the microVM passthrough-device posture so mediated-device choices stay implementation-local unless a later RFC pays for a portable contract
- **REF-CHYP-IOMMU** — Cloud Hypervisor IOMMU docs (virtio-iommu design notes) — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/iommu.md  
  - key: argues for virtio-iommu as a paravirtual alternative to full physical-IOMMU emulation
  - why: keeps microVM device-model scope small while enabling nested virt / safer device attachment
  - us: mechanism candidate for B-profile hardening; does not relax D-DMA host-side requirements
- **REF-LINUX-VIRTIO-IOMMU-DTB** — Linux virtio-iommu device-tree binding note — https://www.kernel.org/doc/Documentation/devicetree/bindings/virtio/iommu.txt  
  - key: documents how virtio-iommu is plumbed in DT-described topologies
  - why: useful for embedded/Arm platform bring-up and for auditing which endpoints sit behind a vIOMMU
  - us: reference when scoping vIOMMU usage in C-profile or Arm-hosted B-profile settings
- **REF-OASIS-VIRTIO-SPEC-REPO** — virtio spec source repository (authoritative diffs) — https://github.com/oasis-tcs/virtio-spec  
  - key: the source of truth for spec changes beyond PDFs
  - why: helps keep device-model scope pinned as virtio evolves
  - us: prefer linking to exact spec versions and tracking diffs for any adopted device class
- **REF-XEN-ARCH** — Xen architecture docs (conceptual reference) — https://wiki.xenproject.org/wiki/Architecture  
  - key: hypervisor layering choices
  - why: sanity-check exit/entry surfaces
  - us: compare TCB growth pressures

- **REF-RUMPKERNEL-ABC2015** — *The rump kernel: A tool for driver development and a toolkit for applications* (AsiaBSDCon 2015) — https://www.netbsd.org/gallery/presentations/justin/2015_AsiaBSDCon/justincormack-abc2015.pdf  
  - key: running kernel drivers outside the kernel as user-space components
  - why: matches driver-domain deprivileging goals without rewriting every driver first
  - us: possible bridge strategy for early hardware bring-up while keeping the privileged core small
- **REF-RUMPKERNEL-TUT** — NetBSD tutorial on rump kernel servers/clients — https://www.netbsd.org/docs/rump/sptut.html  
  - key: practical patterns for running filesystem/crypto drivers in user space
  - why: concrete operational guidance; shows how “driver as a service” can work
  - us: inform interface design and failure modes for driver domains (D-DRVDOM)

- **REF-RAX-ARXIV2025** — *Safe and usable kernel extensions with Rax* (arXiv 2025) — https://arxiv.org/abs/2502.18832  
  - key: safe extension framework addressing termination/stack safety gaps beyond language safety
  - why: relevant if we later want extension points without pulling large code into the privileged core
  - us: candidate inspiration for a future “safe extension” profile (deferred; avoid Phase 1 scope creep)

## Rust verification / safe systems
- **REF-RUSTBELT** — RustBelt (semantics of Rust safety) — https://plv.mpi-sws.org/rustbelt/  
  - key: what Rust guarantees *and what it doesn’t* (esp. `unsafe`)
  - why: prevents “Rust = proof” confusion
  - us: U-ID obligations must be explicit and discharged
- **REF-VERUS** — Verus verifier for Rust — https://github.com/verus-lang/verus  
  - key: SMT-backed verification with ghost code/specs
  - why: plausible Phase 1–2 path for slices
  - us: embed spec/refinement artifacts near code
- **REF-KANI** — Kani model checker — https://github.com/model-checking/kani  
  - key: bounded checks for Rust code
  - why: fast feedback loop for invariants/decoders
  - us: Phase 0/1 evidence for PO-ABI-TOTAL / PO-ENC-DECODE / PO-ACT-VALIDATE
- **REF-LOOM** — Loom concurrency permutation testing — https://github.com/tokio-rs/loom  
  - key: systematically explores thread interleavings under the C11 memory model
  - why: catches “works on my machine” races early
  - us: use for kernel-internal concurrency libraries to support early multicore (SMP) safety claims without relying on UP-only evidence
- **REF-CREUSOT** — Creusot (deductive verification for Rust) — https://github.com/creusot-rs/creusot  
  - key: Why3-backed contracts for (mostly safe) Rust
  - why: alternative path for function-level specs
  - us: candidate for mechanizing decoder/validator invariants
- **REF-PRUSTI** — Prusti (Rust verification) — https://www.pm.inf.ethz.ch/research/prusti.html  
  - key: contract-style verification
  - why: alternative tooling tradeoffs
  - us: tool landscape comparisons under A-TOOL-1
- **REF-CONVEROS** — Converos (practical model checking for Rust OS sync) — https://www.usenix.org/system/files/atc25-tang.pdf  
  - key: model checks realistic Rust OS synchronization behavior under weak memory assumptions
  - why: our “stage concurrency” plan needs *fast* counterexample finding
  - us: template for Phase-2 evidence on selected primitives (keep scope explicit)
- **REF-TICKTOCK-TOCK-ISO** — TickTock: verified isolation for Tock (paper) — https://patpannuto.com/pubs/rindisbacher2025tickTock.pdf  
  - key: realistic isolation proof slice in a Rust kernel
  - why: precedent for “prove one meaningful thing first”
  - us: informs our MVP proof slice selection
- **REF-TOCK-OS** — *Tock: From Research to Securing 10 Million Computers* (SOSP 2025) — https://tockos.org/assets/papers/2025-sosp-tock-decade.pdf  
  - key: long-lived Rust kernel experience; type-system used to encode OS properties
  - why: shows where Rust helps and where process isolation/hardware still matter
  - us: supports internal “type-capability” guardrails + staged assurance slices
- **REF-SLK** — *SLK: A Capability System Based on Safe Language Technology* — https://www.cs.cornell.edu/hu/SLK.PDF  
  - key: type-capability model to constrain authority in safe-language components
  - why: gives a concrete lens for internal authority discipline
  - us: motivates RFC-0020 type-capabilities as an optional guardrail

## Supply chain / reproducibility / provenance
- **REF-TUF** — The Update Framework — https://theupdateframework.io/  
  - key: compromise-resilient update metadata
  - why: boot/update claims need structure
  - us: informs C-BOOT-1 in a maintainable way
- **REF-TUF-SPEC** — TUF specification (latest) — https://theupdateframework.github.io/specification/latest/  
  - key: precise threat model + role/delegation metadata for updates
  - why: update integrity/rollback defenses need spec-level clarity
  - us: candidate basis for a bounded D-UPD-SIGN design without inventing new protocols
- **REF-IN-TOTO** — in-toto — https://in-toto.io/  
  - key: link build steps to attestations
  - why: provenance claims need evidence objects
  - us: supports C-PROV-1 and the D-PCP target
- **REF-IN-TOTO-STATEMENT** — in-toto Attestation Framework: Statement v1 spec — https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md
  - key: a fixed, lightweight statement layer that binds a predicate to one or more subjects
  - why: stable semantics for attestations across tools
  - us: reference for CH-PROV alignment and DSSE/attestation interop
- **REF-BAZEL-BEP** — Bazel Build Event Protocol — https://bazel.build/remote/bep
  - key: build/test results as structured events with stable identifiers and payload types
  - why: useful precedent for machine-comparable result records rather than prose-only summaries
  - us: supports family-local constructor evidence/result surfaces staying compact and typed
- **REF-BAZEL-BEP-TESTSUMMARY** — Bazel Build Event Protocol glossary: `TestSummary` — https://bazel.build/remote/bep-glossary
  - key: one fixed summary event shape per test target/configuration with machine-readable aggregate outcome data
  - why: stable case/result tables are easier to diff and gate than free-form logs
  - us: informs the exact `verdict.summary` contract for the first worker-pool constructor family
- **REF-OCI-DESCRIPTOR** — OCI Content Descriptor specification — https://github.com/opencontainers/image-spec/blob/main/descriptor.md
  - key: a compact typed reference object: `mediaType` + `digest` + `size` (with optional locator hints)
  - why: shows how to carry type when type matters without overloading bare digest fields
  - us: supports keeping CH-REQCTX sponsorship digest lists frozen and introducing any future typed sponsorship as a separate descriptor surface rather than polymorphic reinterpretation
- **REF-DSSE** — DSSE: Dead Simple Signing Envelope — https://github.com/secure-systems-lab/dsse
  - key: type-bound signature envelope that avoids canonicalization pitfalls
  - why: prevents type confusion and wrapper proliferation
  - us: informs CH-SIGENV v0 design (D-SIGENV)
- **REF-DSSE-BACKGROUND** — DSSE background + PAE rationale — https://github.com/secure-systems-lab/dsse/blob/master/background.md
  - key: pre-auth encoding (PAE) for unambiguous signing of (type,payload)
  - why: avoids ambiguous concatenation formats
  - us: clarifies our deterministic 'to_sign' function for CH-SIGENV
- **REF-SIGSTORE-BUNDLE** — Sigstore bundle format — https://docs.sigstore.dev/about/bundle/
  - key: portable object carrying DSSE envelope + verification material + transparency evidence
  - why: makes keyless signing workflows auditable and tool-friendly
  - us: informs how we can attach CH-TLOG anchors and store cert/proof material out-of-band
- **REF-SIGSTORE-FULCIO-OIDC** — Sigstore Fulcio: OIDC usage — https://docs.sigstore.dev/certificate_authority/oidc-in-fulcio/
  - key: how OIDC claims are mapped into issued certificates
  - why: keyless trust boundary is identity policy
  - us: informs D-KEYLESS issuer/identity allowlists
- **REF-CT-RFC6962** — RFC 6962: Certificate Transparency — https://www.rfc-editor.org/info/rfc6962  
  - key: append-only, verifiable log design pattern (Merkle tree) for auditability
  - why: independent auditing reduces trust in a single publisher
  - us: inspiration for publishing signed CH-BOOT/CH-PROV digests as *evidence objects* (keep kernel out)
- **REF-CT-RFC9162** — RFC 9162: Certificate Transparency Version 2.0 — https://www.rfc-editor.org/info/rfc9162
  - key: updated CT protocol and proof/message formats (v2)
  - why: modern primary spec for log inclusion/consistency proof shapes
  - us: informs D-TLOG/RC4 evidence lanes and interop expectations when we treat ordered logs as optional evidence objects
- **REF-COSI-2015** — Syta et al., *Keeping Authorities “Honest or Bust” with Decentralized Witness Cosigning* (CoSi) — https://arxiv.org/pdf/1503.08768
  - key: witness cosigning to reduce equivocation/split-view risk by requiring diverse cosigners on authoritative statements
  - why: strengthens transparency-log checkpoints beyond single-operator signatures
  - us: informs D-WITNESS posture; candidate technique for cosigning `tlog` checkpoints in RC4 lanes (tooling-only in v0)
- **REF-TRILLIAN** — Trillian (verifiable logs) — https://github.com/google/trillian  
  - key: production-grade transparency log implementation patterns
  - why: shows operational considerations (inclusion proofs, consistency, monitoring)
  - us: optional reference if we later adopt a “transparency log” evidence pipeline
- **REF-SIGSTORE-REKOR** — Sigstore Rekor transparency log — https://docs.sigstore.dev/logging/rekor/  
  - key: ecosystem transparency log used for supply-chain artifacts
  - why: demonstrates practical workflows for public append-only logs
  - us: candidate external log to publish release metadata/digests without running our own infra
- **REF-TLOG-SWTCH** — Russ Cox, *tlog: a transparent log* (design note) — https://research.swtch.com/tlog  
  - key: minimal transparency-log design framing (leaf digests + signed checkpoints)
  - why: simple mental model for “append-only evidence anchoring”
  - us: informs CH-TLOG v0 shape and verifier expectations (keep kernel out)
- **REF-TESSERA** — transparency-dev Tessera (tile-based transparency logs) — https://github.com/transparency-dev/tessera  
  - key: tile-based APIs for efficient serving/auditing of large logs ("tlog-tiles") and a modern path beyond classic CT serving stacks
  - why: practical direction for operating large logs at lower cost
  - us: candidate backend for D-TLOG (keep kernel out); aligns with optional witness stacks (see REF-TRANSPARENCY-WITNESS)
- **REF-TRANSPARENCY-WITNESS** — transparency-dev witness (witnessing for verifiable logs) — https://github.com/transparency-dev/witness  
  - key: witness binaries/libraries for cosigning checkpoints and helping prevent split-view attacks
  - why: reduces reliance on a single log operator by adding independent cosigners
  - us: informs D-WITNESS and PO-TLOG-WITNESS verification expectations
- **REF-ARMORED-WITNESS** — Armored Witness (plug-and-play witness deployment) — https://github.com/transparency-dev/armored-witness  
  - key: operational “witness appliance” patterns intended to bootstrap a cross-ecosystem witness network
  - why: lowers the barrier to deploying independent witnesses
  - us: reference for the ops playbook around D-WITNESS
- **REF-SIGSUM** — Sigsum (witnessed transparency for key/binary usage) — https://www.sigsum.org/  
  - key: witness-threshold design aimed at making a signer’s actions globally visible and harder to hide
  - why: modern framing for witnessed transparency beyond classic CT
  - us: inspiration for “audit-complete” release criteria under D-WITNESS
- **REF-SIGSUM-DOCS** — Sigsum documentation — https://www.sigsum.org/docs/  
- **REF-GO-SUMDB-DESIGN** — Go proposal: checksum database (sumdb) design — https://go.googlesource.com/proposal/+/master/design/25530-sumdb.md  
  - key: transparency-log-based authenticity for a large dependency ecosystem
  - why: demonstrates a practical client+proxy+log trust split at ecosystem scale
  - us: additional precedent for D-TLOG/D-WITNESS as supply-chain hygiene
- **REF-GO-SUMDB-TLOGPKG** — Go sumdb transparency log package docs — https://pkg.go.dev/golang.org/x/mod/sumdb/tlog  
  - key: a small, CT-compatible tamper-evident log implementation used in production
  - why: shows a minimal verification surface and proof shapes
  - us: reference for verifier tooling in EVID-2026-080
- **REF-TESSERA-INTRO** — transparency.dev blog: Introducing Trillian Tessera — https://blog.transparency.dev/introducing-trillian-tessera  

- **REF-SLSA** — SLSA framework — https://slsa.dev/  
- **REF-SLSA-SPEC-V12** — SLSA specification v1.2 (Approved) — https://slsa.dev/spec/v1.2/  
  - key: defines build + source tracks, levels, and attestation formats; current approved spec as of late 2025
  - why: keeps our provenance/update gating aligned with the latest community spec
  - us: update-gating vocabulary for D-PCP/D-UPD-SIGN and provenance expectations
- **REF-SLSA-PROVENANCE** — SLSA provenance predicate (v1) — https://slsa.dev/provenance/v1
  - key: standardized provenance statement model for builds
  - why: gives consumers something concrete to verify and rebuild
  - us: informs CH-PROV v0 (bounded, canonical payload)
  - key: supply-chain maturity levels
  - why: shared vocabulary for posture
  - us: map release profiles to concrete controls

- **REF-NTIA-SBOM-MIN2021** — NTIA: *The Minimum Elements for a Software Bill of Materials (SBOM)* (2021) — https://www.ntia.gov/report/2021/minimum-elements-software-bill-materials-sbom
  - key: minimum element set and use-case framing for interoperable SBOM exchange
  - why: grounds our “bounded inventory” posture in widely used guidance
  - us: informs CH-SBOM v0 field minimalism + export hygiene
- **REF-CISA-SBOM-MIN2025** — CISA: 2025 Minimum Elements for an SBOM (resource page) — https://www.cisa.gov/resources-tools/resources/2025-minimum-elements-software-bill-materials-sbom
  - key: updated SBOM minimum-element guidance reflecting 2024–2025 tooling maturity
  - why: keeps our SBOM posture aligned with current adoption guidance
  - us: informs D-SBOM evidence criteria and export tiers
- **REF-SPDX-SPECS** — SPDX: specifications landing page (current versions + formats) — https://spdx.dev/use/specifications/
  - key: SPDX as a widely deployed SBOM exchange format (ISO/IEC 5962 lineage)
  - why: external interoperability target for “full SBOM doc” attachments
  - us: CH-SBOM can link to SPDX docs via CH-AREF when needed
- **REF-SPDX-SPEC** — SPDX spec repository (current stable + WIP) — https://github.com/spdx/spdx-spec
  - key: normative spec text and versioning for SPDX documents
  - why: durable reference for tooling and validation behavior
  - us: supports “external SBOM doc” attachment workflows
- **REF-CYCLONEDX-OVERVIEW** — CycloneDX: specification overview — https://cyclonedx.org/specification/overview/
  - key: BOM standard with supply-chain risk metadata; supports multiple BOM kinds
  - why: alternative external SBOM document format with strong ecosystem tooling
  - us: CH-SBOM can link to CycloneDX docs via CH-AREF when needed
- **REF-CISA-VEX-MINREQ** — CISA: *Minimum Requirements for Vulnerability Exploitability eXchange (VEX)* (2023) — https://www.cisa.gov/sites/default/files/2023-04/minimum-requirements-for-vex-508c.pdf
  - key: defines minimal fields/semantics for exploitability statements to reduce vulnerability noise
  - why: motivates keeping VEX as a separate, evolvable artifact from inventory
  - us: informs CH-VEX v0 status/justification fields and evidence criteria; complements D-SBOM
- **REF-OPENVEX-SPEC** — OpenVEX specification (community-owned) — https://github.com/openvex/spec
  - key: lightweight VEX-shaped document for exploitability statements
  - why: practical, embeddable complement to SBOMs
  - us: mapping/interoperability target for CH-VEX external-doc attachments

- **REF-OPENVEX-REL** — OpenVEX specification releases/tags (versioned change log) — https://github.com/openvex/spec/releases
  - key: concrete, versioned evolution of the OpenVEX schema (e.g., v0.2.0 breaking changes)
  - why: helps keep our CH-VEX mapping honest about what version we align with
  - us: informs CH-VEX v0 enum choices + external-doc linking guidance
- **REF-CSAF-ISO** — OASIS CSAF v2.0 approved as ISO/IEC 20153:2025 (includes VEX profile) — https://www.oasis-open.org/2025/05/20/csaf-v2-approved-as-iso-iec-international-standard/
  - key: CSAF as a broader advisory framework with a VEX profile
  - why: interoperability anchor for vendors who publish security advisories in CSAF
  - us: CH-VEX may link to CSAF docs via CH-AREF when needed (keep CH-VEX minimal)
- **REF-UBUNTU-VEX** — Ubuntu Security: published VEX feed (OpenVEX-shaped) — https://documentation.ubuntu.com/security/security-updates/vex/
  - key: real-world operational publishing of VEX data for a large distro
  - why: validates that minimal VEX artifacts are practical and useful
  - us: example target for CH-VEX ingestion/export workflows

- **REF-REPRODUCIBLE-BUILDS** — reproducible-builds.org — https://reproducible-builds.org/
- **REF-REPRO-BUILDS-ARCHIVES** — reproducible-builds.org: *Archive metadata* — https://reproducible-builds.org/docs/archives/
  - key: deterministic archives need stable file order and normalized metadata such as timestamps/permissions
  - why: handoff zips are artifacts too, and host-dependent archive metadata causes unnecessary drift
  - us: canonical zip packaging should normalize member metadata and make payload changes observable
- **REF-PEP-427** — Python Packaging PEP 427: *The Wheel Binary Package Format 1.0* — https://peps.python.org/pep-0427/
  - key: wheel archives carry a `RECORD` file listing archived files and strong hashes
  - why: useful precedent for verifying the distributed artifact itself via embedded file inventory + digests
  - us: keep SlopOS handoff verification manifest-against-bundle, not workspace-against-bundle
- **REF-PYTHON-ZIPFILE** — Python standard library: `zipfile` — https://docs.python.org/3/library/zipfile.html
  - key: `ZipInfo` controls member metadata including timestamps and permissions inside ZIP archives
  - why: our canonical handoff packager is implemented with Python stdlib, so the metadata contract must match the tool actually writing archives
  - us: normalize `date_time`/modes explicitly instead of leaking host mtimes and umask into the handoff artifact
- **REF-THOMPSON-TRUST** — Ken Thompson, *Reflections on Trusting Trust* (1984 Turing Award lecture; CACM) — https://www.cs.cmu.edu/~rdriley/487/papers/Thompson_1984_ReflectionsonTrustingTrust.pdf  
  - key: a compiler can subvert outputs (and itself) while leaving source seemingly clean
  - why: toolchain trust is a first-class security boundary
  - us: keep compiler-trust assumptions explicit (A-TOOL-2) and add mitigations (D-DDC / D-BOOTSTRAP)
- **REF-WHEELER-DDC** — David A. Wheeler, *Countering Trusting Trust through Diverse Double-Compiling* — https://dwheeler.com/trusting-trust/  
  - key: DDC detects trusting-trust style compiler subversion via diverse recompilation + bitwise comparison
  - why: provides a practical mitigation beyond “trust the vendor”
  - us: optional RP2+ release gate (D-DDC) bound into provenance
- **REF-BOOTSTRAPPABLE-BUILDS** — Bootstrappable Builds project — https://www.bootstrappable.org/projects.html  
  - key: community effort to reduce opaque bootstrap binaries and make “build from source” real
  - why: bootstrap seeds are a persistent audit blind spot
  - us: keep a reduced-seed/bootstrappable posture as an explicit, optional design track (D-BOOTSTRAP)
- **REF-GUIX-FULLSOURCE** — GNU Guix blog: *The Full-Source Bootstrap: Building from source all the way down* (2023) — https://guix.gnu.org/blog/2023/the-full-source-bootstrap-building-from-source-all-the-way-down/  
  - key: practical reduction of bootstrap binaries via GNU Mes and staged bootstrapping
  - why: concrete blueprint for shrinking the trust seed
  - us: informs BP1/BP2 bootstrap postures for trusted releases
- **REF-STAGE0** — stage0 bootstrap repo (minimal dependency bootstrap chain) — https://github.com/oriansj/stage0  
  - key: “less-than-nothing” style staged bootstrap starting from a tiny monitor/assembler chain
  - why: shows what an aggressively minimized bootstrap seed can look like
  - us: inspiration for an eventual BP2 target (not required for early bring-up)
  
- **REF-NIXOS-JFP10** — *NixOS: A Purely Functional Linux Distribution* (JFP, 2010 draft) — https://edolstra.github.io/pubs/nixos-jfp-final.pdf  
  - us: closure/canonical-store ideas for reproducible artifact sets and rollback semantics
- **REF-NIX-HOWNIX** — How Nix Works (official guide) — https://nixos.org/guides/how-nix-works/  
  - us: succinct explanation of store paths, derivations, purity and immutability
- **REF-CUE-DOCS** — CUE documentation — https://cuelang.org/docs/  
  - key: data validation + configuration + generation in one tooling ecosystem
  - why: concrete example of keeping rich config authoring outside the privileged runtime
  - us: candidate generator/validation toolchain for CH-CFG emitters, without standardizing a core template DSL
- **REF-DHALL-HOME** — The Dhall configuration language — https://dhall-lang.org/  
  - key: programmable configuration language with types/imports/normalization
  - why: shows a config-as-source option that can stay user-space and deterministic
  - us: informs the “tooling concern, not core seam” boundary for profile-default generation
- **REF-DHALL-SAFETY** — Dhall documentation: Safety Guarantees — https://docs.dhall-lang.org/discussions/Safety-guarantees.html  
  - key: explicit safety/totality framing for a programmable configuration language
  - why: useful contrast when deciding what safety properties belong in tooling vs privileged validators
  - us: supports keeping IF-CFG limited to canonical artifact validation, not language evaluation
- **REF-JSONNET-HOME** — Jsonnet configuration language — https://jsonnet.org/  
  - key: data templating language aimed at generating structured configuration
  - why: common precedent for profile/default generation that should remain outside privileged semantics
  - us: another example of a valid emitter choice that does not justify a new SlopOS schema surface
- **REF-JSONNET-DESIGN** — Jsonnet design rationale — https://jsonnet.org/articles/design.html  
  - key: hermetic templating as a design goal
  - why: relevant to our insistence that generators not introduce ambient env/network/path semantics
  - us: reinforces the boundary between generator convenience and authoritative CH-CFG / CH-POLICY artifacts

- **REF-NIXOS-MANUAL** — NixOS Manual (stable) — https://nixos.org/manual/nixos/stable/  
  - key: module-based declarative system configuration and operational workflow
  - why: shows the ergonomic bridge from “declarative intent” to “bootable system state”
  - us: inspiration for treating CH-CFG as compiled output and making config generations/rollback routine
- **REF-NIX-CA-OUTPUTS** — Nix Reference Manual: *Content-addressing derivation outputs* — https://nix.dev/manual/nix/2.28/store/derivation/outputs/content-address.html  
  - key: content-addressed output identity depends on the output content (not build history)
  - why: makes “already built” results comparable/cachable by digest
  - us: informs capshell output normal form (CH-AREF + deterministic replay; D-RETRYSAFE)
- **REF-NIX-MANUAL-ROLLBACK** — Nix Reference Manual: `nix-env --rollback` (profiles/generations) — https://nix.dev/manual/nix/2.24/command-ref/nix-env/rollback  
  - key: “profiles” as a sequence of generations with deterministic rollback semantics
  - why: crisp, ops-friendly model for selecting prior states without in-place mutation
  - us: informs our user-space generations store posture and rollback UX expectations
- **REF-GUIX-FPM13** — *Functional Package Management with Guix* (arXiv 2013) — https://arxiv.org/abs/1305.4584  
  - us: functional build graphs and provenance-friendly closures
  - key: rebuildability discipline and pitfalls
  - why: “provable” builds need mechanics
  - us: acceptance criteria for C-PROV-1
- **REF-RPM-OSTREE** — rpm-ostree (atomic deployments + rollback) — https://coreos.github.io/rpm-ostree/  
  - key: immutable OS deployments with atomic upgrade/rollback (hybrid image/package model)
  - why: reduces upgrade brick risk; makes “what ran” a digest-addressed object
  - us: reference for D-ATOMICUPD; bind deployment digest to CH-BOOT/CH-PROV

- **REF-REAPI-PROTO** — Bazel Remote Execution API: `remote_execution.proto` (v2) — https://github.com/bazelbuild/remote-apis/blob/main/build/bazel/remote/execution/v2/remote_execution.proto  
  - key: remote execution + caching results where stdout/stderr/output files are referenced by digests in a CAS
  - why: proven “digest-first outputs” pattern for retries/caching without ambient channels
  - us: inspiration for `capshell.exec` output normal form and CAS-like storage in the cloud substrate profile
- **REF-FEDORA-ROLLBACKS** — Fedora docs: updates/upgrades/rollbacks (Atomic Desktops) — https://docs.fedoraproject.org/en-US/atomic-desktops/updates-upgrades-rollbacks/  
  - key: real-world operational rollback workflows around atomic deployments
  - why: evidence that rollback UX is usable and valuable at scale
  - us: informs acceptance criteria for D-ATOMICUPD tooling and boot selection semantics
- **REF-ANDROID-AB** — Android A/B (seamless) system updates docs — https://source.android.com/docs/core/ota/ab/  
  - key: A/B slot metadata semantics (`tries_remaining`, `successful_boot`), bootloader interactions, and rollback protection interplay  
  - why: concrete, widely deployed pattern for “trial boot then commit on health”  
  - us: informs CH-BOOTSEL and I-ATOMICUPD-3 / PO-ATOMICUPD-COMMIT profiles
- **REF-ANDROID-PARTITIONS** — Android partitions overview (recovery partition) — https://source.android.com/docs/core/architecture/partitions
  - key: documents the `recovery` partition (or boot-embedded recovery ramdisk for A/B devices) as a first-class boot artifact
  - why: recovery must remain bootable even when the main system is broken
  - us: supports D-RECOVERY as a digest-addressed recovery_root updated alongside normal releases
- **REF-SYSTEMD-SPECIAL** — systemd.special (emergency/rescue targets) — https://www.freedesktop.org/software/systemd/man/systemd.special.html
  - key: defines minimal troubleshooting boot targets (`rescue.target`, `emergency.target`) and their boot-entry semantics
  - why: widely deployed pattern for a minimal recovery posture when normal boot fails
  - us: inspiration for a sealed/minimal rescue environment as a boot target (D-RECOVERY)
- **REF-WINRE** — Windows Recovery Environment (WinRE) technical reference — https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-recovery-environment--windows-re--technical-reference?view=windows-11
  - key: a dedicated recovery environment with multiple entry paths (advanced startup, recovery media, hardware recovery button)
  - why: recovery should be independent and reachable via physical presence when normal boot is broken
  - us: justifies treating recovery as a first-class boot target with explicit entry assumptions (D-RECOVERY)

- **REF-CHROMEOS-UPDATEENGINE** — ChromeOS `update_engine` README (A/B rollback behavior) — https://chromium.googlesource.com/aosp/platform/system/update_engine/+/HEAD/README.md  
  - key: long-lived A/B updater with rollback behavior documented for ChromeOS  
  - why: additional operational evidence for partition-style atomic updates and rollback triggers  
  - us: informs D-ATOMICUPD acceptance criteria and boot selector audit expectations

- **REF-CHROMIUM-ZYGOTE** — Chromium docs: Linux zygote process (prefork spawn server) — https://chromium.googlesource.com/chromium/src/+/HEAD/docs/linux/zygote.md
  - key: a zygote listens for spawn requests and forks after expensive setup to improve startup time and share memory pages
  - why: production precedent that the pattern generalizes beyond managed runtimes (Android) and integrates with sandboxing
  - us: supports a user-space “template spawner” pattern for disposable domains (D-EPHEM) without adding privileged-kernel machinery
- **REF-SYSTEMD-BOOT-ASSESS** — systemd: Automatic boot assessment / boot counting + bless-boot — https://github.com/systemd/systemd/blob/master/docs/AUTOMATIC_BOOT_ASSESSMENT.md  
  - key: post-boot user-space step that marks a boot entry as "good" only after reaching a completion barrier (e.g., `boot-complete.target`)  
  - why: concrete, deployed pattern for separating "booted" from "healthy" and enabling rollback on repeated failures  
  - us: informs D-HEALTH and CH-HEALTH/CH-HEALTHREC wiring into CH-BOOTSEL commit semantics
- **REF-ANDROID-BOOTCTRL** — Android Boot Control HAL (A/B slot state machine, includes `markBootSuccessful`) — https://android.googlesource.com/platform/hardware/interfaces/+/refs/heads/android16-qpr2-release/boot/1.0/IBootControl.hal  
  - key: explicit interface to mark the current slot successful; bootloader state machine expects bounded tries + success marking  
  - why: shows how major platforms prevent silent "success" and make commit a discrete step  
  - us: informs our capability-gated boot commit operation and negative tests
- **REF-ANDROID-VERIFIEDBOOT-FLOW** — Android Verified Boot boot flow (A/B success mark before advancing rollback metadata) — https://source.android.com/docs/security/features/verifiedboot/boot-flow  
- **REF-ANDROID-BUGREPORT** — Android Studio: capture and read bug reports (`adb bugreport`, zip structure) — https://developer.android.com/studio/debug/bug-report
- **REF-ANDROID-READBUGREPORTS** — AOSP: read bug reports (components + tips) — https://source.android.com/docs/core/tests/debug/read-bug-reports
  - key: ties the "boot successful" step to rollback-protection metadata updates in A/B devices  
  - why: evidence that commit and anti-rollback should be coupled carefully  
  - us: informs I-BOOT-2/I-ATOMICUPD-3 and D-HEALTH binding choices

- **REF-ANDROID-ZYGOTE** — AOSP docs: About the Zygote processes — https://source.android.com/docs/core/runtime/zygote
  - key: zygote as the root of app/system processes for a given ABI; preloads runtime state then forks on request
  - why: concrete, widely deployed “preforked template” pattern for fast process start and shared memory
  - us: inspiration for disposable-domain templates (D-EPHEM) and warm-start snapshot templates (D-INITSNAP/D-CHKPT) without expanding privileged core
- **REF-ANDROID-MEMORY-OVERVIEW** — Android Developer: memory management overview (mentions Zygote fork + shared pages) — https://developer.android.com/topic/performance/memory-overview
  - key: explains why forking from a preloaded zygote shares framework pages and improves launch performance
  - why: mainstream documentation connecting the technique to real memory sharing outcomes
  - us: supports the “templates reduce marginal sandbox cost” UX claim (evidence target for D-EPHEM)

- **REF-ANDROID-JOBINFO** — Android API: JobInfo.Builder (JobScheduler constraints) — https://developer.android.com/reference/android/app/job/JobInfo.Builder
  - key: declare background work with closed-set constraints (network/charging/idle/etc.) rather than exact wakeups
  - why: mainstream precedent for constraint-based scheduling replacing alarm-driven daemons
  - us: informs D-JOBS constraint vocabulary + fail-closed validation posture
- **REF-ANDROID-WORKMANAGER** — Android docs: task scheduling with WorkManager (persistent background work) — https://developer.android.com/develop/background-work/background-tasks/persistent
  - key: deferrable background work runs when constraints are met; survives process death/restarts
  - why: production guidance that scheduling is best-effort and system-coalesced
  - us: supports a job-portal design (D-JOBS) that coalesces work and enforces bounded runtime
- **REF-ANDROID-ALARMS** — Android docs: Schedule alarms / exact vs inexact background timing — https://developer.android.com/develop/background-work/services/alarms
  - key: exact wakeups are special and resource-expensive; routine background work should prefer inexact/coalesced scheduling
  - why: sharpens the D-JOBS split between ordinary deferred work and exceptional precise alarms
  - us: supports the v0 no-ambient-cron / best-effort-window posture and keeps exact scheduling out of Phase 1
- **REF-APPLE-BGTASKS** — Apple: Using background tasks to update your app (BGTaskScheduler) — https://developer.apple.com/documentation/uikit/using-background-tasks-to-update-your-app
  - key: schedule background refresh/processing tasks via system scheduler; the system decides actual run time
  - why: confirms a cross-ecosystem convergence toward constraint-based background work
  - us: informs D-JOBS trigger model (earliest, best-effort) and “no exact timestamps” posture
- **REF-APPLE-BGTASK-EARLIEST** — Apple: BGTaskRequest.earliestBeginDate — https://developer.apple.com/documentation/backgroundtasks/bgtaskrequest/earliestbegindate
  - key: earliest start time is advisory; the system does not guarantee launching at that date
  - why: explicit documentation that background scheduling is best-effort
  - us: supports windowed triggers and side-channel minimization
- **REF-SYSTEMD-TIMER** — systemd.timer manual (timers, coalescing, persistence) — https://www.freedesktop.org/software/systemd/man/systemd.timer.html
  - key: declarative timers with coalescing/randomization and optional persistent catch-up semantics
  - why: demonstrates operationally useful background job semantics without per-app daemons
  - us: informs D-JOBS periodic + catch-up semantics and pressure-aware coalescing
- **REF-ANDROID-SECURE-CLIPBOARD** — Android Developers: secure clipboard handling (privacy risk + mitigations) — https://developer.android.com/privacy-and-security/risks/secure-clipboard-handling  
  - key: clipboard access is treated as a privacy/security risk; includes guidance such as marking sensitive clipboard content
  - why: mainstream precedent that clipboard is a security surface, not just UX glue
  - us: motivates CH-XFER `sensitive` marking + export redaction and discourages ambient clipboard reads
- **REF-ANDROID-12-CLIPBOARD-TOAST** — Android 12 behavior changes: clipboard access notifications — https://developer.android.com/about/versions/12/behavior-changes-all#clipboard-access-notifications  
  - key: user-visible notification when an app accesses clipboard data from another app
  - why: visibility reduces stealth clipboard snooping
  - us: supports focus/volition gating and transcript visibility for portal-mediated transfers


- **REF-FUCHSIA-SWUPDATE** — Fuchsia software update system (concepts; TUF-based) — https://fuchsia.dev/fuchsia-src/concepts/packages/software_update_system  
  - key: modern, content-addressed update system that adapts TUF and binds package merkle roots into the update chain  
  - why: shows one way to keep the boot path small while still using TUF-like distribution metadata  
  - us: informs D-ATOMICUPD/D-UPD-SIGN design posture and how to keep IF-BOOT TUF-agnostic
- **REF-FUCHSIA-DIAGNOSTICS** — Diagnostics and observability on Fuchsia (logs/Inspect/tracing/snapshots tooling) — https://fuchsia.dev/fuchsia-src/development/diagnostics
  - key: an opinionated, integrated diagnostics stack (logs + Inspect + tracing + snapshots + tools)
  - why: concrete example of keeping most observability machinery in user space while standardizing artifacts and tools
  - us: informs D-INSPECT, snapshot workflows, and export-policy enforcement posture
- **REF-FUCHSIA-INSPECT** — Fuchsia component inspection overview (structured diagnostics tree) — https://fuchsia.dev/fuchsia-src/development/diagnostics/inspect
- **REF-FUCHSIA-INSPECT-TREE** — Inspect discovery/hosting on Fuchsia (Archivist aggregates Inspect on-demand) — https://fuchsia.dev/fuchsia-src/reference/diagnostics/inspect/tree
  - key: system-level diagnostics service aggregates structured state on demand, using capability discovery
  - why: a concrete pattern for “no ambient global query” while still enabling powerful tooling
  - us: supports D-OBS/D-INSPECT posture: pull-only exports; scoped aggregation; artifacts over APIs
- **REF-FUCHSIA-INSPECT-FORMAT** — Inspect VMO file format (platform spec) — https://fuchsia.dev/fuchsia-src/reference/platform-spec/diagnostics/inspect-vmo-format
- **REF-FUCHSIA-DIAGNOSTICS-SCHEMA** — Fuchsia diagnostics schema (ArchiveAccessor StreamDiagnostics responses) — https://fuchsia.dev/fuchsia-src/reference/platform-spec/diagnostics/schema
  - key: a pinned, typed response schema for diagnostics export streams
  - why: shows how to keep export semantics tool-friendly without smuggling authority
  - us: informs CH-OBS/CH-SNAPSHOT “schema-first export” posture under IF-OBS
- **REF-FUCHSIA-SNAPSHOT** — Fuchsia diagnostics monitoring tutorial (mentions `ffx target snapshot`) — https://fuchsia.dev/fuchsia-src/get-started/learn/fidl/diagnostics-monitoring
- **REF-FUCHSIA-TRIAGE** — Fuchsia triage tooling (analyze snapshots via config rules) — https://fuchsia.dev/fuchsia-src/development/diagnostics/triage/fx_triage
  - key: selectors + eval expressions + actions + embedded tests over snapshot/Inspect data
  - why: shows that bounded rule sets can replace ad-hoc scripts for diagnosis and are testable as artifacts
  - us: primary precedent for D-TRIAGE/CH-TRIAGE
- **REF-FUCHSIA-NS** — Fuchsia Namespaces (process namespace as explicit path→handle table) — https://fuchsia.dev/fuchsia-src/concepts/process/namespaces
  - key: each process gets a private namespace (non-overlapping path prefixes) mapping names to handles; used for file access + service discovery
  - why: concrete mainstream example of sandboxing via explicit namespaces, not privileged global resolvers
  - us: supports D-NS posture that name resolution is capability-mediated and non-ambient
- **REF-FUCHSIA-LIFEOFOPEN** — Fuchsia: Life of an Open (namespace walking; no kernel `open` syscall) — https://fuchsia.dev/fuchsia-src/concepts/filesystems/life_of_an_open
  - key: path resolution happens in user-space VFS code walking a namespace of handles; Zircon avoids a privileged `open` syscall
  - why: demonstrates an explicit alternative to kernel path parsing as an ambient authority surface
  - us: evidence for keeping SlopOS IF-* surfaces handle-based while still supporting file/service UX


- **REF-PROMETHEUS-ALERT-RULES** — Prometheus docs: Alerting rules — https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/
  - key: declarative rules over a bounded metrics model (expressions + labels) that trigger operator actions
  - why: precedent for audit-friendly rule configuration that remains bounded and externally testable
  - us: informs CH-TRIAGE posture (bounded predicates + actions) without importing a full query language

- **REF-OSQUERY-CONFIG** — osquery docs: Configuration + query packs — https://osquery.readthedocs.io/en/stable/deployment/configuration/
  - key: curated "packs" of queries scheduled for specific tasks (compliance/IR)
  - why: shows operational value of purpose-built collection sets that minimize data by default
  - us: informs CH-TRIAGE selectors/tests and the "collect only what you need" stance

## Authorization / policy engines (optional, veto-only posture)
- **REF-CEDAR** — Cedar policy language (docs + engine) — https://www.cedarpolicy.com/  
  - key: policy language with a clear evaluation model and tooling ecosystem
  - why: plausible “guardrails as data” mechanism without embedding policy in the kernel
  - us: candidate D-POLICY engine for ACP/component constraints (veto-only)
- **REF-CEDAR-SPEC** — cedar-spec (formalization + differential tests) — https://github.com/cedar-policy/cedar-spec  
  - key: executable semantics + differential randomized testing against the implementation
  - why: aligns with our D-DRT spec-first evidence loop
  - us: pattern/template for reference models of CH-KABI/CH-ACP validators

## LLM/tool-calling agent confinement (related)
- **REF-MINISCOPE-ARXIV25** — Zhu et al., *MiniScope: A Least Privilege Framework for Authorizing Tool-Calling Agents* (arXiv 2025) — https://arxiv.org/pdf/2512.11147
  - key: confinement framework that reconstructs and enforces least-privilege permission hierarchies for agents
  - why: agent/tool UX tends to recreate ambient authority unless the system forces explicit, bounded grants
  - us: input evidence for IF-ACP validator + budgeting/ledger options; does not replace explicit approvals/caps

- **REF-AIOS-ARXIV24** — Mei et al., *AIOS: LLM Agent Operating System* (arXiv 2024) — https://arxiv.org/pdf/2403.16971
  - key: proposes an OS-like orchestration layer for LLM agents (scheduler/memory/tools) as a first-class system surface
  - why: agent systems tend to grow ambient channels unless the substrate makes authority explicit and auditable
  - us: a research-y precedent for profile (D) motivation; we still pin authority via portals/leases/receipts, not hidden tool glue

## OS design inspirations (mapped to our specs)
- **REF-PLAN9** — Plan 9 papers/docs — https://9p.io/sys/doc/  
  - key: namespaces as composable “views”
  - why: safer control surfaces than ad-hoc toggles
  - us: model “views” as capability-mediated objects
- **REF-PLAN9-NSCROSS** — Namespace Crossings for Plan 9 (namespace mechanics + crossings) — https://www.cs.cmu.edu/~412/history/2006F/nscross/  
  - key: per-process namespaces; why “crossings” are tricky; helps reason about mount semantics
  - us: guidance for D-NS (union mounts + deterministic traversal)
- **REF-UNIONMOUNT-44BSD** — McKusick (1995): Union mounts in 4.4BSD-Lite (design + semantics) — https://papers.freebsd.org/1995/mckusick-union_mounts/
  - key: presents a merged view of two directory trees with shadowing; highlights subtle semantics and mutation limits
  - why: primary reference for union/overlay namespace semantics outside Plan 9
  - us: informs RFC-0032 union/overlay semantics and determinism pitfalls

- **REF-9P** — Plan 9 9P2000 protocol (manpages; version negotiation + pointers) — https://9p.io/magic/man2html/5/version  
  - key: small, uniform protocol for mountable services
  - us: optional service-tree bridge transport for D-NS (kept in user space)
- **REF-PLAN9-FOSSIL** — *Fossil, an Archival File Server* (Plan 9) — https://p9f.org/sys/doc/fossil.pdf  
  - key: file server that exposes `active`/`archive`/`snapshot` trees; snapshots as an inspectable UX primitive
  - why: demonstrates a practical “snapshots as namespaces” interface that works locally and over 9P
  - us: inspiration for D-PERSIST snapshot/clone UX and D-NS view-scoped snapshot mounts
- **REF-PLAN9-FOSSIL-MAN** — fossil(4) man page (Plan 9) — https://9p.io/magic/man2html/4/fossil  
  - key: concrete operational conventions for snapshots + server control
  - us: interface inspiration for snapshot admin and D-INSPECT/diagnostic exports

- **REF-STYX-ARCH** — *The Styx Architecture for Distributed Systems* (Pike, 1999) — https://www.inferno-os.org/inferno/papers/styx.pdf  
  - key: a small file-protocol variant (9P/Styx) used uniformly for local+remote resources
  - why: shows how a thin, uniform protocol makes distributed composition cheap
  - us: reference for the optional service-tree bridge transport in RFC-0032 (keep in user space)
- **REF-PLAN9-AUTH** — *Security in Plan 9* (Cox) — https://9p.io/sys/doc/auth.pdf  
  - key: factotum as a per-user authentication agent
  - why: centralizes key handling + protocol negotiation
  - us: reference design for D-AUTHAGENT; audit via CH-LOG
- **REF-PLAN9-FACTOTUM** — factotum(4) man page — https://9p.io/magic/man2html/4/factotum  
  - key: concrete interface sketch (keys, proto, log)
  - why: shows a narrow file-like API for auth ops
  - us: candidate API shape for an auth-agent service
- **REF-OPENSSH-AGENTRESTRICT** — OpenSSH ssh-agent restriction notes — https://www.openssh.org/agent-restrict.html  
  - key: agent is deliberately simple because it holds private keys; supports per-key restrictions
  - why: reinforces “key-holder is TCB; keep it tiny” and provides a pragmatic restriction vocabulary
  - us: D-CRYPTOSVC key policies (CH-KEYPOL) + op-only interfaces + redaction-safe crypto audit (CH-CRYPTOAUDIT)
- **REF-OPENBSD-SSHADD** — OpenBSD `ssh-add(1)` destination constraints notes — https://man.openbsd.org/ssh-add.1  
  - key: destination-constrained keys and forwarded-agent use require explicit cooperating hops; defaults stay unconstrained unless policy says otherwise
  - why: gives a concrete, deployment-tested example of constrained cross-hop key use that still fails closed on missing support rather than widening silently
  - us: reference for the D-CRYPTOSVC forwarding boundary: explicit narrowed routes only; no transparent forwarded-agent seam on the core contract


- **REF-PLAN9-SECSTORE** — secstore(1) man page — https://9fans.github.io/plan9port/man/man1/secstore.html  
  - key: network “secure store” for keys/credentials used by factotum
  - why: shows a practical recovery/bootstrapping path for secrets without scattering bytes across apps
  - us: optional recovery-vault profile for D-VAULT (provider ingests secrets; apps get handles)
- **REF-APPLE-KEYCHAIN** — Apple Keychain Services (overview) — https://developer.apple.com/documentation/security/keychain-services  
  - key: OS-managed encrypted store for small secrets + APIs for access control
  - why: keychain ergonomics prevents every app building its own vault
  - us: model for a standard vault seam + policy gating (but keep logic in user space)
- **REF-APPLE-KEYCHAIN-DP** — Apple Platform Security: Keychain data protection — https://support.apple.com/guide/security/keychain-data-protection-secb0694df1a/web  
- **REF-APPLE-SYSDIAGNOSE** — Apple sysdiagnose logging instructions (support bundle trigger + notes) — https://podcasters.apple.com/assets/iOS-sysdiagnose-logging-instructions.pdf
  - key: separation of searchable metadata vs secret-value encryption; hardware-assisted protections
  - why: illustrates how “queryability” is a covert-channel knob
  - us: treat indexing/metadata exposure as an explicit policy surface (align with I-OBS-1)
- **REF-ANDROID-KEYSTORE** — Android Keystore system — https://developer.android.com/privacy-and-security/keystore  
  - key: non-exportable key material; restrict when/how keys are used
  - why: shows mainstream demand for “use constraints” (auth-required, mode restrictions)
  - us: inform CH-KEYPOL/CH-SECRETPOL policy fields and enforcement posture
- **REF-ANDROID-KEYATTEST** — Android key attestation docs — https://developer.android.com/privacy-and-security/security-key-attestation  
  - key: evidence that keys are hardware-backed + properties of the key
  - why: bridges “handle-only” APIs with verifiable claims
  - us: map to D-CC/D-ATTEST annex: optional evidence gate for vault/key release
- **REF-HURD-TRANSLATORS** — GNU Hurd translators docs — https://www.gnu.org/software/hurd/hurd/documentation/translators.html  
  - key: attach user-space servers to filesystem nodes (“translators”)
  - why: powerful extensibility without kernel growth
  - us: model as D-TRANS seam inside views; make attachment auditable + sealable

- **REF-HURD-SETTRANS** — GNU Hurd `settrans` docs (attach/remove translators) — https://www.gnu.org/software/hurd/hurd/settrans.html  
  - key: explicit operation to attach a user-space server to a filesystem node (active/passive translators)
  - why: shows how "attach a service at a name" becomes a first-class authorization surface
  - us: reinforces D-NS/D-TRANS posture: view mutation/attach must be capability-authorized, transcripted, and sealable

- **REF-QNX-RESMGR** — QNX Neutrino: Resource Managers (overview) — https://www.qnx.com/developers/docs/6.5.0SP1.update/com.qnx.doc.neutrino_getting_started/s1_resmgr.html  
  - key: user-space “resource managers” implement filesystem/device semantics via message passing and pathname resolution
  - why: a production microkernel shows path-attached user-space servers can be ergonomic and scalable
  - us: reinforces D-TRANS + service-tree posture; make name/attach authority explicit and auditable in views
- **REF-QNX-RESMGR-ATTACH** — QNX: `resmgr_attach()` reference (name/pathspace registration) — https://www.qnx.com/developers/docs/8.0/com.qnx.doc.neutrino.lib_ref/topic/r/resmgr_attach.html  
  - key: resource managers explicitly register pathnames; the OS treats attach as a privileged “pathspace” operation
  - why: clarifies where “mount/attach” becomes an authorization surface (not a convenience call)
  - us: model view mutation/attachment as an explicit capability right; transcript attach/remove actions (CH-LOG)
- **REF-QNX-PULSES** — QNX: Pulses (fixed-size async messages) — https://www.qnx.com/developers/docs/8.0/com.qnx.doc.neutrino.sys_arch/topic/ipc_Pulses.html  
  - key: a bounded, nonblocking async notification primitive with a small payload, delivered via the same receive path as messages
  - why: shows why synchronous RPC alone is awkward for interrupts/timers/backpressure
  - us: motivate an optional CapRPC “oneway/pulse” method profile for notifications without reply coupling
- **REF-QNX-MSGSENDPULSE** — QNX: `MsgSendPulse()` reference (send semantics) — https://www.qnx.com/developers/docs/8.0/com.qnx.doc.neutrino.lib_ref/topic/m/msgsendpulse.html  
  - key: explicit API/constraints for sending a pulse; makes delivery semantics and failure modes concrete
  - why: good precedent for defining crisp “oneway” failure semantics (enqueue vs error) and bounded payload rules
  - us: tighten PO-CAPRPC-ONEWAY around “no silent drop” + bounded payload + interface-marked oneway

- **REF-BFS-ATTR** — BFS/BeOS filesystem retrospective (attributes + indexes) — https://arstechnica.com/information-technology/2018/07/the-beos-filesystem/  
  - key: indexed file attributes and query-driven organization
  - why: search/metadata become first-class UX primitives
  - us: candidate for D-ATTRFS with view-scoped queries and bounded schemas
- **REF-HAIKU-QUERIES** — Haiku docs: attributes + queries — https://www.haikuinsider.org/storage-kit-searching-and-querying-files  
  - key: practical query APIs built atop indexed attributes
  - why: shows ergonomic integration points for applications
  - us: keep query engines user-space; standardize attribute/index hooks
- **REF-PFSD-BFS** — *Practical File System Design with the Be File System* (Giampaolo) — https://nobius.org/~dbg/practical-file-system-design.pdf
  - key: authoritative design notes on BFS attributes, indexes, and live queries
  - why: concrete semantics for indexing/query and live updates without a DB bolt-on
  - us: informs D-ATTRFS + CH-ATTR/CH-ATTRQ bounds and “live query” execution profiles
- **REF-APPLE-NSMETADATAQUERY** — Apple Developer docs: `NSMetadataQuery` — https://developer.apple.com/documentation/foundation/nsmetadataquery
  - key: metadata queries have an initial gathering phase and a second live-update phase
  - why: clean precedent for snapshot-first + optional live updates rather than making every query implicitly persistent
  - us: supports D-ATTRFS posture that live mode is optional/bounded and does not imply background watch semantics
- **REF-APPLE-SPOTLIGHT-QUERYGUIDE** — Apple File Metadata Search Programming Guide — https://developer.apple.com/library/archive/documentation/Carbon/Conceptual/SpotlightQuery/Concepts/Introduction.html
  - key: app-facing metadata queries support stored/often-used queries and asynchronous batching over metadata scopes
  - why: shows the value of saved-query UX while also highlighting the need to keep persistence semantics explicit
  - us: supports shell-owned smart-folder manifests in D-ATTRFS rather than app-visible inventory or ambient global search claims

- **REF-PLAN9-PLUMB** — Plan 9 plumber (“plumbing”) docs — https://9p.io/sys/doc/plumb.html  
  - key: explicit event routing substrate for composition
  - why: reduces ad-hoc observer channels and “stringly” wiring
  - us: inspires D-EVENTBUS, but capability-mediated + schema-pinned
- **REF-SINGULARITY** — Singularity OS papers (contracts/channels) — https://www.microsoft.com/en-us/research/project/singularity/  
  - key: explicit channel contracts shrink reasoning surface
  - why: ABI/schema discipline as security primitive
  - us: CH-* schemas + total validation everywhere
- **REF-SING-OVERVIEW** — *An Overview of the Singularity Project* (MSR TR-2005-135) — https://www.microsoft.com/en-us/research/wp-content/uploads/2005/10/tr-2005-135.pdf  
  - key: contracts as explicit protocol specs for channels
  - why: cheap correctness leverage; bounded reasoning surface
  - us: supports D-CONTRACT evidence/semantics
- **REF-SING-MSGCOMM** — *Language Support for Fast and Reliable Message-based Communication in Singularity OS* — https://www.microsoft.com/en-us/research/wp-content/uploads/2006/04/singsharp.pdf  
  - key: ownership transfer + contracts at scale
  - why: shows how to make message passing practical without hidden sharing
  - us: informs D-CONTRACT + D-IOBUF interplay
- **REF-SING-OSR07** — *Singularity: Rethinking the Software Stack* (OSR 2007) — https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/osr2007_rethinkingsoftwarestack.pdf  
  - key: software-isolated processes + contract channels + manifest-based programs
  - why: “manifested” assumptions make pre-flight validation plausible
  - us: supports D-CONTRACT and motivates D-COMP/CH-COMP as a composition artifact
- **REF-MULTIKERNEL-SOSP09** — *The Multikernel: A new OS architecture for scalable multicore systems* (SOSP 2009) — https://www.sigops.org/s/conferences/sosp/2009/papers/baumann-sosp09.pdf  
  - key: treat the machine as a network of cores; move OS structure to message-passing processes
  - why: explicit messaging makes concurrency and state ownership more analyzable
  - us: reference for staged SMP: “no hidden sharing” defaults and D-CONC/D-MEMMODEL scoping

- **REF-CRDT-INRIA11** — Shapiro et al., *A comprehensive study of Convergent and Commutative Replicated Data Types* (Inria RR-7506, 2011) — https://www.csa.iisc.ac.in/~raghavan/CleanedPods2021/crdt-shapiro-2011.pdf
  - key: Strong Eventual Consistency model; commutative/convergent replicated data types
  - why: principled patterns for RC3 “commutative merge” replication without coordination
  - us: supports D-REPL (RC3) and ties commutativity discipline to cross-cluster metadata replication

- **REF-ESCROW-TODS86** — O'Neil, *The Escrow Transactional Method* (TODS 1986) — https://www.ics.uci.edu/~cs223/papers/p405-o_neil.pdf
  - key: pre-allocate rights so many decrements/allocations can proceed without global coordination while preserving invariants
  - why: the core insight for SlopOS is that coordination-free spending comes from **explicitly issued rights**, not from treating merged summaries as authority
  - us: grounds the `quota` vs `budget` boundary under Hybrid: local spend may be cheap, but issuance / rebalance stays explicit and reviewable
- **REF-BOUNDED-COUNTER-SRDS15** — Balegas et al., *Extending Eventually Consistent Cloud Databases for Enforcing Numeric Invariants* (SRDS 2015) — https://www.dpss.inesc-id.pt/~rodrigo/srds15.pdf
  - key: bounded-counter CRDTs preserve non-negative invariants by distributing/transfering rights explicitly while letting local operations proceed without coordination
  - why: shows a modern escrow-style pattern for replicated numeric limits that still keeps rights transfer explicit
  - us: informs the Phase 1 stance that `quota` RC3 is observational/additive under already-issued credit, while any future credit-transfer protocol must be its own explicit surface

- **REF-COREY-OSDI08** — *Corey: An Operating System for Many Cores* (OSDI 2008) — https://www.usenix.org/event/osdi08/tech/full_papers/boyd-wickizer/boyd_wickizer.pdf
  - key: make sharing explicit; OS structures private-by-default unless the app asks to share
  - why: unnecessary shared kernel state is a primary scalability bottleneck
  - us: supports D-MK as an explicit ‘share scope’ surface; aligns with capability/manifest explicitness
- **REF-TORNADO-OSDI99** — *Tornado: Maximizing Locality and Concurrency in a Shared Memory Multiprocessor OS* (OSDI 1999) — https://www.usenix.org/events/osdi99/full_papers/gamsa/gamsa.pdf
  - key: OS objects with multiple implementations tuned to degree of sharing; locality-first structuring
  - why: demonstrates scalable structuring within an SMP kernel without going fully multikernel
  - us: supports ‘clustered/sharded objects’ as an intermediate D-MK option
- **REF-K42-COMPLETE-06** — *K42: Building a Complete Operating System* (EuroSys 2006) — https://www.cs.bu.edu/~jappavoo/Resources/Papers/Krieger06.pdf
  - key: clustered object model using distribution/replication/partitioning to scale concurrently accessed objects
  - why: concrete design patterns for scalable shared-kernel state without monolithic global locks
  - us: supports a disciplined sharding/replication pattern library for D-MK
- **REF-SCALABLE-COMMUTATIVITY-TOCS13** — *The Scalable Commutativity Rule: Designing Scalable Software for Multicore Processors* (TOCS 2013) — https://www.read.seas.harvard.edu/~kohler/pubs/clements-sc-tocs.pdf
  - key: if operations commute, there exists a conflict-free scalable implementation; interface design can drive scalability
  - why: gives a principled way to design interfaces that scale, not just data structures
  - us: apply to CH-KABI action-set design; make ‘commutes under preconditions’ a proof/test target
- **REF-FUCHSIA-COMPONENTS** — Fuchsia component-based software overview — https://fuchsia.dev/fuchsia-src/get-started/learn/intro/components  
- **REF-FUCHSIA-COMP-MANIFESTS** — Fuchsia: component manifests (what a manifest declares) — https://fuchsia.dev/fuchsia-src/concepts/components/v2/component_manifests
  - key: manifests encode execution + composition + capability routing as data
  - why: shows what makes composition lintable and fail-closed at scale
  - us: reinforces CH-COMP as an artifact seam; keep optional/required + rights explicit
- **REF-FUCHSIA-CAPABILITIES** — Fuchsia: capabilities + routing concepts — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities
  - key: capability types + explicit routing through instance trees
  - why: concrete semantics for ‘who can see what’ queries and debugging
  - us: informs future CH-COMP version bumps (availability/realm boundaries) without kernel bloat
- **REF-FUCHSIA-DICTCAP** — Fuchsia: dictionary capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/dictionary
  - key: bundles multiple capabilities into an immutable, explicitly routed capability object
  - why: concrete precedent for grouped authority handoff without peer inheritance or ambient lookup
  - us: if we ever need authoritative grouped handoff, prefer an explicit routed bundle over hidden pipeline FD passing

- **REF-FUCHSIA-TOPOLOGY** — Fuchsia component topology (instance tree + routing graph) — https://fuchsia.dev/fuchsia-src/concepts/components/v2/topology
  - key: component topology + capability routing as the central composition mechanism
  - why: composition policy is explicit, inspectable, and enforceable
  - us: informs D-COMP and the idea of a pinned “component graph” artifact (CH-COMP)
- **REF-FUCHSIA-CML** — Fuchsia component manifest (.cml) reference — https://fuchsia.dev/reference/cml  
  - key: declared `use`/`offer`/`expose` edges for capabilities
  - why: avoids ambient discovery and makes “who can access what” statically reviewable
  - us: motivates CH-COMP fields for declared imports/exports + routing (without importing Fuchsia’s full framework)

- **REF-FUCHSIA-REALMS** — Fuchsia “realms” (component instance tree boundaries) — https://fuchsia.dev/fuchsia-src/concepts/components/v2/realms  
  - key: explicit hierarchical capability boundaries (realms) and routing paths
  - why: a concrete mental model for “who can route what through whom”
  - us: informs CH-COMP validation rules and future “realm-scoped” composition profiles

- **REF-FUCHSIA-DECL** — Fuchsia component declaration schema (fuchsia.component.decl) — https://fuchsia.dev/reference/fidl/fuchsia.component.decl  
  - key: precise schema-level semantics for `use`/`offer`/`expose` + required/optional availability
  - why: helps avoid “handwavy routing semantics” and supports static linting
  - us: inspiration for extending CH-COMP beyond v0 when we need optional dependencies / availability
- **REF-GENODE-INIT** — Genode “init” component / routing table model — https://genode.org/documentation/genode-foundations/22.05/system_configuration/The_init_component.html  
  - key: per-child service-routing rules express client↔server relationships explicitly
  - why: policy lives in a small, auditable configuration substrate, not scattered across code
  - us: supports D-COMP: treat capability routing as data that can be linted/model-checked

- **REF-GENODE-PKG** — Genode Foundations: package management (depot) — https://genode.org/documentation/genode-foundations/24.05/development/Package_management.html
  - key: signed package depot enabling modular system composition, on-target updates, and rollback
  - why: microkernel ecosystem showing ‘update/rollback’ as an operator default, not a luxury
  - us: strengthens D-FPM/D-ATOMICUPD: treat composition closures as digest-checked artifacts
- **REF-GENODE-SCULPT** — Genode Sculpt OS (integrity-protected updates + rollback, ops workflows) — https://genode.org/documentation/articles/sculpt-24-10
  - key: live system + tweakable composition with integrity-protected update and rollback
  - why: demonstrates how a componentized OS can be operated without ambient scripting
  - us: supports making CH-COMP + update tooling a first-class ecosystem story
- **REF-GENODE-UPDATE-ROLLBACK** — Genode release notes (on-target signed updates + rollback) — https://genode.org/documentation/release-notes/23.02
  - key: update mechanism secured by cryptographic signatures; rollback to prior downloaded versions
  - why: concrete precedent for ‘try new version, fall back on regression’ in a small-system world
  - us: aligns with CH-BOOTSEL trial-boot semantics and D-ATOMICUPD operator posture
- **REF-CAMKES** — CAmkES (seL4 component architecture) docs — https://docs.sel4.systems/projects/camkes/  
  - key: components + statically declared interfaces; templates generate glue code
  - why: codegen can reduce boundary bugs and clarify composition
  - us: inspiration for D-IDL and CH-COMP enforcement without expanding IF-KABI
- **REF-QUBES-ARCH** — Qubes OS architecture spec (2010) — https://www.qubes-os.org/attachment/doc/arch-spec-0.3.pdf  
  - key: security-by-compartmentalization patterns built on a hypervisor boundary
  - why: shows which “split” patterns are operationally useful (GUI, net, secrets) when isolation is real
  - us: inspires early view-object patterns + D-EVENTBUS as a safe cross-domain plumbing seam

- **REF-QUBES-DOC-ARCH** — Qubes OS docs: system architecture (living docs) — https://doc.qubes-os.org/en/latest/developer/system/architecture.html  
  - key: up-to-date architecture overview framing isolation domains + split subsystems
  - why: workstation UX precedent for isolation without ambient cross-domain channels
  - us: informs A-profile “secure workstation” posture narratives without importing Xen/Qubes specifics
- **REF-QUBES-DISPOSABLES** — Qubes OS docs: How to use disposables — https://doc.qubes-os.org/en/latest/user/how-to-guides/how-to-use-disposables.html  
  - key: disposable templates + unnamed disposables that vanish after the launched app ends; ‘open in disposable’ workflows
  - why: demonstrates a usable mental model for risky-task isolation at the UX level
  - us: operational precedent for D-EPHEM (RFC-0050); also supports keeping sanitization as a distinct workflow rather than treating ordinary disposable edit/export as implicit trust promotion

- **REF-QUBES-QFILECOPY** — Qubes OS docs: Inter-qube file copying (qfilecopy / OpenInVM) — https://doc.qubes-os.org/en/latest/developer/services/qfilecopy.html  
  - key: ‘open in DispVM’ copies the file into a DisposableVM for viewing/editing and copies a modified file back only as a distinct follow-on action
  - why: strong precedent for snapshot/copy-in plus explicit copy-back, rather than a live mutable alias into risky-open execution
  - us: informs the `open_untrusted` materialization boundary (`open-untrusted-materialization-boundary-v0.md`) so safe-open stays preview-first and export-explicit

- **REF-QUBES-DISPOSABLE-IMPL** — Qubes OS docs: Disposable implementation — https://doc.qubes-os.org/en/latest/developer/system/disposablevm.html  
  - key: preloaded disposable queue, hidden/unpaused activation, and ‘remove from preload list on use’ semantics
  - why: concrete precedent that warm-start acceleration can preserve fresh-instance semantics instead of reusing a used disposable
  - us: informs D-EPHEM v0 posture on preload queues, one-shot lifetime, and user-space template spawners

- **REF-QUBES-QREXEC** — Qubes OS docs: qrexec (secure inter-domain communication + policy) — https://doc.qubes-os.org/en/latest/developer/services/qrexec.html  
  - key: inter-domain RPC with dom0-mediated authorization, policy layering, and disposable targets (`@dispvm`)
  - why: a real-world “cross-domain services” substrate that stays usable while remaining fail-closed by default
  - us: informs D-CAPRPC + D-POLICY + D-EPHEM + D-PLUMB composition posture

- **REF-QUBES-TEMPLATES** — Qubes OS docs: templates — https://doc.qubes-os.org/en/latest/user/templates/templates.html  
  - key: shared read-only root with per-VM private state; centralized updates for many compartments
  - why: makes “lots of isolated apps” operationally and storage-feasible
  - us: informs D-ATOMICUPD + D-FPM + sealed-image / template profiles

- **REF-QUBES-TEMPLATE-IMPL** — Qubes OS docs: TemplateVM implementation — https://doc.qubes-os.org/en/latest/developer/system/template-implementation.html  
  - key: shared `root.img` with CoW semantics and concurrent versioning
  - why: demonstrates practical storage/version tricks for template-based systems
  - us: informs base-image store + snapshot/rollback interplay

- **REF-QUBES-CLIPBOARD** — Qubes OS docs: secure inter-qube clipboard (plain text) — https://doc.qubes-os.org/en/latest/user/how-to-guides/how-to-copy-and-paste-text.html  
  - key: explicit user-mediated cross-domain paste operation (copy != grant; paste == grant)
  - why: concrete UX precedent for “clipboard is a portal,” not a broadcast channel
  - us: informs D-PLUMB + D-VOLITION posture for clipboard/drag-drop

- **REF-QUBES-SPLITGPG** — Qubes OS docs: Split GPG — https://doc.qubes-os.org/en/latest/user/security-in-qubes/split-gpg.html  
  - key: split-sensitive-service pattern (keep secret keys in a dedicated vault domain; callers get operation-only access)
  - why: shows a high-value workflow users actually adopt, rooted in cross-domain policy mediation
  - us: informs D-CRYPTOSVC/D-VAULT + portal/consent design for operation-only handles

- **REF-BROMIUM-MICROVM** — Bromium whitepaper: Application Isolation and Containment — https://www.bromium.com/wp-content/uploads/2018/03/wp-bromium-application-isolation-and-containment-ps-us-en_0.pdf  
  - key: micro-VM-per-task containment + self-remediation on close
  - why: reinforces the ‘disposable by default’ posture for untrusted content
  - us: inspiration for disposable domain lifecycle semantics and teardown evidence targets
- **REF-INFERNO-BLTJ97** — *The Inferno Operating System* (Bell Labs Tech. J., 1997) — https://inferno-os.org/inferno/papers/bltj.pdf  
  - key: distributed services as a first-class OS goal; uniform interface for local/remote resources
  - why: demonstrates how a small core can support coherent distributed composition semantics
  - us: reference for “remote capability” profiles (D-CAPX) and namespace-as-view discipline
- **REF-SING-CHANCONTRACTS** — *Analyzing Singularity Channel Contracts* (ISSTA 2009) — https://sites.cs.ucsb.edu/~bultan/publications/issta09.pdf  
  - key: static/automated analysis of contract FSMs
  - why: demonstrates tractable tooling for protocol specs
  - us: candidate “model-check fast” evidence path
- **REF-NVLANG-BEAM** — *NVLang: Unified Static Typing for Actor-Based Concurrency on the BEAM* (arXiv 2025) — https://arxiv.org/abs/2512.05224  
  - key: encode actor message protocols as types; typed PIDs/futures enforce protocol conformance
  - why: shows a modern “typed protocol” approach that complements contracts/typestate
  - us: inspiration for D-CONTRACT + D-IDL synergy (protocols as types in Rust wrappers)

- **REF-BARRELFISH** — Barrelfish papers — https://www.barrelfish.org/publications/  
  - key: message passing to avoid hidden shared state
  - why: makes concurrency explicit
  - us: stage multicore; avoid implicit global mutation
- **REF-BARRELFISH-SKB** — Barrelfish System Knowledge Base (SKB) background (thesis) — https://barrelfish.org/publications/ma-schwyda-hwconf.pdf  
  - key: queryable hardware fact base (logic/constraints) used by OS components
  - why: avoids embedding hardware-policy logic in the kernel
  - us: informs D-SKB + CH-HWFACT v0
- **REF-DECLARATIVE-OS** — *Tackling OS Complexity with Declarative Techniques* (Schüpbach, 2012) — https://barrelfish.org/publications/schuepbach-declarative-os.pdf  
  - key: central knowledge service + declarative rules/constraints for configuration and resource allocation
  - why: shows how to keep policy logic out of the kernel while still handling real hardware diversity
  - us: strengthens D-SKB (fact base + purity) and complements D-JOBS (constraint solver posture)
- **REF-EXOKERNEL-SOSP95** — *Exokernel: An Operating System Architecture for Application-Level Resource Management* (SOSP 1995) — https://pages.cs.wisc.edu/~bart/736/papers/exo-sosp95.pdf  
  - key: secure multiplexing with application-level resource management (libOS policy outside the kernel)
  - why: a clean framing for “mechanism in the kernel, policy in user space” that matches our D-METER/D-PRESSURE posture
  - us: justifies keeping accounting/pressure mechanistic while letting unprivileged runtimes decide admission control/caching/QoS

- **REF-NEMESIS** — Nemesis project archive — https://www.cl.cam.ac.uk/research/srg/netos/projects/archive/nemesis/  
  - key: QoS as a first-class design axis
  - why: forces explicit accounting and responsibility
  - us: reference for D-METER + D-PAGER (self-paging)
- **REF-MINIX-RELIABLE-OS** — MINIX 3 “reliable OS” paper — https://www.minix3.org/doc/reliable-os.pdf  
  - key: multi-server design; user-mode drivers + restart/recovery
  - why: driver faults dominate real-world failures; deprivilege the device stack
  - us: motivates D-DRVDOM and I-IORES-1 as first-class axes
- **REF-ERLANG-OTP-PRINCIPLES** — Erlang/OTP supervisor design principles — https://erlang.org/doc/design_principles/sup_princ.html
  - key: supervision trees (structured restart/recovery)
  - why: makes failure handling explicit and composable
  - us: informs RFC-0017 restart policy + supervisor state machine

- **REF-SOLARIS-SMF-BP** — Sun/Oracle blueprint: *Service Management Facility (SMF) in the Solaris 10 OS* — https://www.filibeto.org/sun/lib/blueprints/819-5150.pdf  
  - key: repository-backed manifests + dependency graph + restarters (svc.startd) for structured recovery
  - why: mature precedent for declarative service management + restart semantics that scale operationally
  - us: informs CH-COMP dependency/restart metadata + RFC-0017 validation posture

- **REF-SOLARIS-SMF-CREATESVC** — Oracle docs: Creating an SMF service (manifests + validation) — https://docs.oracle.com/cd/E36784_01/html/E36820/createsvc1.html  
  - key: validate manifests (`svccfg validate`) and apply changes via a standard import workflow
  - why: shows a practical “validate+install” loop for service definitions
  - us: informs our validator-first composition/policy tooling (D-COMP / D-POLICY)

- **REF-SOLARIS-FMA-OVERVIEW** — Oracle Solaris docs: Fault Management Overview (FMA; ereports → diagnosis → response agents) — https://docs.oracle.com/cd/E23824_01/html/821-1451/gliqg.html
  - key: detectors emit typed error reports; diagnosis engines emit suspect lists; response agents mitigate (offline ASRU/FRU, restart services)
  - why: precedent for structured fault handling without whole-system restarts
  - us: informs D-TRIAGE + CH-FAULT/CH-HWEVENT + supervised response agents (bounded, transcripted control paths)

- **REF-SOLARIS-FMA-ADMIN** — Oracle Solaris docs: Managing Faults, Defects, and Alerts (FMA details) — https://docs.oracle.com/cd/E37838_01/html/E61036/gliqg.html
  - key: end-to-end operational flow and terminology (ereport/ireport, diagnosis, suspect lists, actions)
  - why: helps ground a realistic “finding taxonomy” and response workflows
  - us: supports “diagnosis as data” posture: deterministic findings (tags/codes) and bounded response requests via policy-gated control actions

- **REF-SYSTEMD-SOCKET-ACTIVATION** — systemd for Developers #1: Socket Activation — https://0pointer.de/blog/projects/socket-activation.html
  - key: manager-owned listeners handed to services; avoids start ordering; enables restart without dropping new connections
  - why: mature, widely deployed operational pattern
  - us: motivates D-ACTIVATE (stable handles delivered at start)
- **REF-SD-LISTEN-FDS** — `sd_listen_fds(3)` (socket activation + FD store protocol) — https://manpages.debian.org/testing/libsystemd-dev/sd_listen_fds.3.en.html
  - key: minimal protocol for receiving manager-passed descriptors (socket activation + fdstore)
  - why: demonstrates a tiny, closed, well-specified handoff interface
  - us: informs CH-ACTSET delivery semantics and negative tests
- **REF-SYSTEMD-FDSTORE** — systemd: File Descriptor Store — https://systemd.io/FILE_DESCRIPTOR_STORE/
  - key: per-service manager-maintained descriptor set preserved across restarts
  - why: a pragmatic “keep a little continuity” alternative to full checkpoint/restore
  - us: informs D-ACTIVATE handle-store posture + bounds
- **REF-LAUNCHD-ACTIVATE-SOCKET** — Apple: `launch_activate_socket` (launchd socket activation) — https://developer.apple.com/documentation/xpc/launch_activate_socket
  - key: launchd-owned sockets retrieved by name at process start
  - why: cross-OS validation that socket activation is a durable ops primitive
  - us: supports D-ACTIVATE as a portable concept (not Linux-specific)
- **REF-NGINX-CONTROL** — NGINX docs: Controlling nginx (incl. “Upgrading Executable on the Fly”) — https://nginx.org/en/docs/control.html
  - key: zero-downtime upgrade using inherited listening sockets and master/worker handoff
  - why: simple, battle-tested continuity pattern for long-running network services
  - us: reinforces “stable listener identity” as the right abstraction for restarts/upgrades
- **REF-FUCHSIA-RUNNER-STOP** — Fuchsia: `fuchsia.component.runner` Stop/Kill semantics — https://fuchsia.dev/reference/fidl/fuchsia.component.runner
  - key: explicit lifecycle control with bounded grace period (Stop) and escalation (Kill)
  - why: keeps shutdown semantics deterministic and testable
  - us: informs supervisor Stop→Kill hygiene in D-SUPV/D-ACTIVATE

- **REF-SYSTEMD-SERVICE** — systemd manual: `systemd.service` (stop semantics; TimeoutStopSec; KillMode) — https://www.freedesktop.org/software/systemd/man/systemd.service.html
  - key: structured stop behavior with bounded grace period and configurable escalation
  - why: shows the real-world cost of “send a signal and hope”; operators need bounded, testable shutdown semantics
  - us: informs D-QUIESCE + supervisor escalation policy (bounded grace → kill)
- **REF-KUBE-LIFECYCLE-HOOKS** — Kubernetes docs: Container lifecycle hooks (`PreStop`, termination grace period) — https://kubernetes.io/docs/concepts/containers/container-lifecycle-hooks/
  - key: two-phase termination patterns (hook + grace period) used at scale
  - why: demonstrates how orchestrators standardize drain windows and force-kill escalation
  - us: motivates a first-class D-QUIESCE contract rather than per-service stop semantics
- **REF-ERLANG-RELEASE-HANDLING** — Erlang/OTP docs: Release handling (sys:suspend/change_code/resume) — https://www.erlang.org/doc/system/release_handling.html
  - key: cooperative quiescence/suspension as part of safe upgrades
  - why: shows maintenance correctness benefits when services expose explicit lifecycle hooks
  - us: supports D-QUIESCE as an explicit, testable maintenance handshake
- **REF-LINUX-CGROUP-FREEZER** — Linux kernel docs: cgroup v1 freezer subsystem — https://docs.kernel.org/admin-guide/cgroup-v1/freezer-subsystem.html
  - key: hierarchical freeze/unfreeze of task groups; stop-the-world checkpoint helper
  - why: illustrates a non-cooperative fallback and its costs/limits
  - us: contrast case for D-QUIESCE; keep freezer-like techniques as a fallback rather than the primary contract

- **REF-RUMP-KERNEL** — *The rump kernel: A tool for driver development and a toolkit for applications* (AsiaBSDCon 2015) — https://www.netbsd.org/gallery/presentations/justin/2015_AsiaBSDCon/justincormack-abc2015.pdf  
  - key: run kernel subsystems/drivers in user space with minimal adaptation
  - why: enables fast testing, fuzzing, and fault isolation without kernel crashes
  - us: a practical pattern for driver-domain bring-up + verification harnesses (prototype-to-evidence)
- **REF-NEMESIS-SELFPAGING** — *Self-Paging in the Nemesis Operating System* (OSDI 1999) — https://www.usenix.org/conference/osdi-99/presentation/self-paging-nemesis-operating-system  
  - key: isolation/exposure/responsibility in VM design
  - why: deprivileges policy while keeping mechanisms auditable
  - us: optional profile inspiration for D-PAGER
- **REF-MACH-EXTPAGER** — Mach external pager mechanism overview (GNU Hurd docs) — https://www.gnu.org/software/hurd/microkernel/mach/external_pager_mechanism.html  
  - key: separates VM mechanisms (kernel) from backing-store/content policy (user space)
  - why: classic precedent for “user-mode paging policy” in a microkernel
  - us: supports D-PAGER as a kernel-thin seam; keep fault/mapping authority explicit

- **REF-MACH-REQUEST-NOTIFY** — XNU Mach: `mach_port_request_notification` (dead-name notifications) — https://web.mit.edu/darwin/src/modules/xnu/osfmk/man/MP_request_notification.html
  - key: one-shot notifications (via send-once rights) when a port right becomes a dead name
  - why: liveness/failure detection becomes an explicit message, not polling or timeouts
  - us: model “death watch” as an optional primitive feeding supervisors and revocation/cleanup logic (D-SUPV, D-CAPRPC)
- **REF-L4RE-DS-RM** — L4Re concepts: Data Spaces + Region Map (pager IPC on faults) — https://l4re.org/doc/l4re_concepts_ds_rm.html  
  - key: kernel delivers page-fault IPC to a designated pager; pager replies with mapping or error
  - why: shows a minimal, well-studied fault→pager IPC mechanism
  - us: informs CH-FAULT shape + PO-PAGER-ROUTE; keep routing explicit and bounded
- **REF-FUCHSIA-PAGER** — Fuchsia/Zircon pager kernel object docs — https://fuchsia.dev/fuchsia-src/reference/kernel_objects/pager  
  - key: user-space pager service supplies pages to pager-backed VMOs; kernel delivers requests via a port
  - why: modern, production-grade demand-paging seam designed for user-space filesystems
  - us: reference for D-PAGER “VMO-backed” design and minimizing leaked address-space details
- **REF-FUCHSIA-BLOBFS-RAC** — Fuchsia: Random-access compression in BlobFS (pager-backed VMOs) — https://fuchsia.dev/fuchsia-src/concepts/filesystems/random-access-compression  
  - key: pager-backed VMOs enable lazy, random-access loading; FS can implement compression-aware paging
  - why: concrete example of “policy in pager” (prefetch, compression, caching)
  - us: motivates bespoke paging policies (compression, encryption, prefetch) without kernel bloat
- **REF-FUCHSIA-RFC-0226** — Fuchsia RFC 0226: Zircon Pager Writeback (mutable pager-backed VMOs) — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0226_zircon_pager_writeback  
  - key: adds writeback/dirty-page management to pager-backed VMOs with explicit lifecycle semantics
  - why: shows how “mutable mmap-like files” can be layered onto user-pager mechanisms
  - us: informs optional D-PAGER writeback profile; keep dirty-page eviction policy in user space
- **REF-ARRAKIS-OSDI14** — *Arrakis: The Operating System is the Control Plane* (OSDI 2014) — https://www.usenix.org/system/files/conference/osdi14/osdi14-paper-peter_simon.pdf  
  - key: move control-plane policy off the I/O data path; apps/servers access virtualized devices/queues under IOMMU
  - why: shows performance wins and TCB benefits when device models are not the silent bottleneck
  - us: motivates D-IOLEASE + driver domains with IOMMU-first isolation while keeping kernel enforcement small
- **REF-THESEUS-OSDI20** — Theseus OS (OSDI 2020) — https://www.usenix.org/system/files/osdi20-boos.pdf  
  - key: state management as the core modularity problem
  - why: explicit state evolution reduces hidden coupling
  - us: strengthen “interface-as-data + transcripts” posture
- **REF-ZIRCON-HANDLES** — Zircon handles concept — https://fuchsia.dev/fuchsia-src/concepts/kernel/handles  
  - key: handles as the universal reference mechanism
  - why: simplifies authority reasoning
  - us: keep “authority edges” uniform; avoid ambient globals
- **REF-ZIRCON-SIGNALS** — Fuchsia/Zircon signals (waitable object state bits) — https://fuchsia.dev/fuchsia-src/concepts/kernel/signals  
  - key: waitable kernel objects expose a small bitmask of signals (readable/writable/terminated/etc.)
  - why: demonstrates a production signal model that scales across object kinds
  - us: supports D-WAITSET (signals as observations; no payloads)
- **REF-ZIRCON-OBJECT-WAIT-MANY** — Zircon/Fuchsia `zx_object_wait_many` syscall docs — https://fuchsia.dev/reference/syscalls/object_wait_many  
  - key: bounded wait on multiple handles with a per-item waitfor/pending mask
  - why: shows a minimal wait-many API that avoids bespoke per-subsystem waits
  - us: baseline for Option 0/1 in D-WAITSET and bounded delivery semantics
- **REF-ZIRCON-OBJECT-WAIT-ASYNC** — Zircon/Fuchsia `zx_object_wait_async` syscall docs — https://fuchsia.dev/reference/syscalls/object_wait_async  
  - key: default async waiting is level-triggered; `ZX_WAIT_ASYNC_EDGE` is an explicit opt-in with missed-transition caveats
  - why: grounds the decision to keep edge/one-shot behavior out of the portable v0 default seam
  - us: supports D-WAITSET posture that stays level-triggered by default and defers re-arm complexity
- **REF-ZIRCON-PORT-WAIT** — Zircon/Fuchsia `zx_port_wait` syscall docs — https://fuchsia.dev/reference/syscalls/port_wait  
  - key: a mailbox/port primitive to dequeue event packets (FIFO)
  - why: illustrates the “wait set returns packets” shape used for scalable event loops
  - us: inspiration for WaitSet object semantics (bind+tag+batch dequeue)
- **REF-LINUX-EPOLL** — Linux epoll(7) / epoll_wait(2) (I/O event notification) — https://man7.org/linux/man-pages/man7/epoll.7.html  
  - key: scalable readiness notification with interest lists and batched waits
  - why: widely deployed evidence that a wait-set primitive is ecosystem-critical
  - us: informs WaitSet API ergonomics and overflow/backpressure expectations
- **REF-BSD-KQUEUE** — OpenBSD `kqueue(2)` (event notification) — https://man.openbsd.org/kqueue.2  
  - key: a generic event queue where waits return event records
  - why: shows a stable, long-lived design point for multiplexed waits
  - us: informs WaitSet semantics (batch return, user tags) without adopting filter programmability
- **REF-WIN-IOCP** — Windows I/O completion ports overview — https://learn.microsoft.com/en-us/windows/win32/fileio/i-o-completion-ports  
  - key: completion-queue model that unifies async completion delivery through one port
  - why: highlights an alternative to readiness APIs and the value of a single completion queue
  - us: informs D-WAITSET option space and also motivates *not* merging payload queues into the portable v0 wait seam by default
- **REF-WIN-POSTQUEUEDCOMPLETIONSTATUS** — Windows `PostQueuedCompletionStatus` docs — https://learn.microsoft.com/en-us/windows/win32/fileio/postqueuedcompletionstatus  
  - key: user code can inject arbitrary completion packets into an IOCP; the system does not validate those packet payload values
  - why: shows how a wait object can widen into a general in-process control/message queue
  - us: supports the D-WAITSET v0 decision to keep user-injected packets off the core wait seam


- **REF-LINUX-IOURING-PDF** — *Efficient IO with io_uring* (Jens Axboe) — https://kernel.dk/io_uring.pdf  
  - key: design motivation + the submission/completion ring shape (SQ/CQ); avoid per-op syscalls where possible
  - why: canonical design writeup for the submit/completion ring pattern in a widely deployed OS
  - us: informs D-IOQ seam (bounded rings, tags, completion packets) without cloning Linux details

- **REF-LINUX-IOURING-ENTER** — Linux man-pages: `io_uring_enter(2)` — https://man7.org/linux/man-pages/man2/io_uring_enter.2.html  
  - key: submit+wait call over shared SQ/CQ rings; flags and error behavior
  - why: precise interface-level semantics to ground deterministic overflow/submit discussions
  - us: informs D-IOQ option space (doorbell vs submit+wait) and failure-mode vocabulary

- **REF-LINUX-IOURING-REGISTER** — Linux man-pages: `io_uring_register(2)` — https://man7.org/linux/man-pages/man2/io_uring_register.2.html  
  - key: rings may register credential personalities that later SQEs can select explicitly
  - why: a concrete example of queue-local authority rebinding pressure that a smaller portable D-IOQ posture may want to reject
  - us: supports the D-IOQ v0 decision to keep per-SQE credential/personality override off the portable seam

- **REF-LINUX-IOURING-MAN7** — Debian man-pages: `io_uring(7)` — https://manpages.debian.org/testing/liburing-dev/io_uring.7.en.html  
  - key: overview of io_uring concepts (rings, requests, completions) and how they fit together
  - why: concise implementer-facing summary
  - us: context for D-IOQ without importing a large ABI surface into the privileged core

- **REF-WIN-IORING-OVERVIEW** — Microsoft docs: `ioringapi.h` header (I/O Rings API) — https://learn.microsoft.com/en-us/windows/win32/api/ioringapi/  
  - key: API overview describing a submission queue of async ops and a completion queue of results
  - why: production precedent that submit/completion ring queues are a convergent pattern outside Linux
  - us: supports D-IOQ as an ecosystem seam rather than a Linux-only artifact

- **REF-WIN-IORING-CREATE** — Microsoft docs: `CreateIoRing` (ioringapi.h) — https://learn.microsoft.com/en-us/windows/win32/api/ioringapi/nf-ioringapi-createioring  
  - key: creates an I/O ring with configured queue sizes (rounded to powers of two; discoverable via info APIs)
  - why: illustrates bounded sizing and capability discovery for ring queues
  - us: informs D-IOQ queue creation/bounds semantics

- **REF-WIN-IORING-SUBMIT** — Microsoft docs: `SubmitIoRing` (ioringapi.h) — https://learn.microsoft.com/en-us/windows/win32/api/ioringapi/nf-ioringapi-submitioring  
  - key: submits constructed entries and can optionally wait for completions; errors can be reflected via completions
  - why: shows a combined submit+wait shape and explicit completion/error semantics
  - us: informs D-IOQ queue submission/drain semantics without importing Windows-specific completion events into the core queue contract

- **REF-WIN-IORING-REGISTERFILEHANDLES** — Microsoft docs: `BuildIoRingRegisterFileHandles` — https://learn.microsoft.com/en-us/windows/win32/api/ioringapi/nf-ioringapi-buildioringregisterfilehandles  
  - key: file-handle registration lets later SQEs refer to handles by integer index; a new registration replaces the previous one completely
  - why: concrete example of queue-local handle inventory / replacement semantics appearing in a production ring API
  - us: supports the D-IOQ v0 decision to keep public preregistered handle tables off the portable seam

- **REF-WIN-IORING-REGISTERBUFFERS** — Microsoft docs: `BuildIoRingRegisterBuffers` — https://learn.microsoft.com/en-us/windows/win32/api/ioringapi/nf-ioringapi-buildioringregisterbuffers  
  - key: buffer registration lets later SQEs refer to buffers by index; sparse entries and replacement semantics are part of the surface
  - why: shows how queue-local buffer registries quickly acquire lifetime / sparse-slot / replacement rules
  - us: supports the D-IOQ v0 decision to defer any public preregistered buffer inventory until it can be specified as its own reviewable surface

- **REF-MS-WAITONADDRESS** — Microsoft Learn: `WaitOnAddress` (wait on a word to change) — https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitonaddress  
  - key: wait on 1/2/4/8 bytes without allocating an event object; spurious wakeups are allowed; callers re-check the value
  - why: production precedent for wait-on-address as a minimal kernel assist for userspace locks
  - us: informs D-UWAIT API shape (size set, status codes, “re-check after wake” discipline)

- **REF-MS-WAKEBYADDRESSSINGLE** — Microsoft Learn: `WakeByAddressSingle` — https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-wakebyaddresssingle  
  - key: wake one waiter waiting on the target address
  - why: illustrates the paired wake primitive needed for wait-on-address designs
  - us: informs D-UWAIT wake semantics (wake-one vs wake-all; bounded behavior)

- **REF-MS-WAITFUNCS** — Microsoft Learn: “Wait functions” (WaitOnAddress + WakeByAddress*) — https://learn.microsoft.com/en-us/windows/win32/sync/wait-functions  
  - key: ecosystem overview of waiting mechanisms, including wait-on-address and WakeByAddressAll
  - why: concise reference for the “address as sync object” posture and common usage patterns
  - us: additional grounding for D-UWAIT semantics and usage guidance

- **REF-WIN-WAITFORSINGLEOBJECT** — Microsoft Learn: `WaitForSingleObject` — https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitforsingleobject  
  - key: canonical Windows wait primitive with explicit return codes (including WAIT_ABANDONED for mutexes)
  - why: mainstream precedent for “acquired but state may be inconsistent” semantics
  - us: informs D-ROBUSTLOCK’s API/error taxonomy and caller obligations

- **REF-WIN-WAIT_ABANDONED** — The Old New Thing: what WAIT_ABANDONED means (and why it matters) — https://devblogs.microsoft.com/oldnewthing/20260209-00/?p=112049  
  - key: an abandoned mutex means the previous owner exited without releasing it; protected state is suspect
  - why: crisp articulation of recovery requirements and failure modes
  - us: supports D-ROBUSTLOCK guidance: repair+make_consistent or fail-close


- **REF-LINUX-FUTEX2** — Linux man-pages: `futex(2)` — https://man7.org/linux/man-pages/man2/futex.2.html  
  - key: futexes enable userspace fast paths; kernel is entered only when contention requires sleeping/waking
  - why: the most widely deployed wait-on-address primitive in current ecosystems
  - us: informs D-UWAIT contract language and pitfalls (spurious wakeups; requeue patterns)

- **REF-LINUX-FUTEX-PAPER** — *Fuss, Futexes and Furwocks: Fast Userlevel Locking in Linux* (OLS 2002) — https://www.kernel.org/doc/ols/2002/ols2002-pages-479-495.pdf  
  - key: original futex motivation/design and performance discussion
  - why: canonical design writeup for the futex approach
  - us: supports D-UWAIT as “ecosystem-critical” and clarifies the uncontended vs contended split

- **REF-LINUX-RSEQ-DOC** — Linux kernel docs: *Restartable Sequences* — https://docs.kernel.org/userspace-api/rseq.html  
  - key: per-thread rseq area ABI supports restartable regions and fast access to current CPU/node IDs
  - why: primary spec for rseq semantics and constraints
  - us: informs D-RSEQ profile gating, abort semantics, and boundedness constraints

- **REF-LINUX-RSEQ-MAN** — Linux man-pages: `rseq(2)` — https://man7.org/linux/man-pages/man2/rseq.2.html  
  - key: syscall/ABI framing, structure layout notes, and user-space contract summary
  - why: stable API-level reference for implementers
  - us: supports RFC-0113 “minimal seam” and ABI closure

- **REF-REDHAT-RSEQ-GLIBC** — Red Hat Developers: *Why we added restartable sequences support to glibc…* — https://developers.redhat.com/articles/2022/12/22/restartable-sequences-support-glibc-rhel-9  
  - key: practical motivation (malloc/per-CPU data) and adoption tradeoffs
  - why: shows real ecosystem value and footguns
  - us: evidence for “brilliant but under-adopted” status and bounded design constraints

- **REF-LWN-RSEQ-GLIBC** — LWN: *Restartable sequences in glibc* — https://lwn.net/Articles/883104/  
  - key: overview of rseq semantics and how user-space libraries integrate it
  - why: concise, implementation-oriented explanation of the API
  - us: supports the D-RSEQ evidence plan and integration guidance (abort rate, portability)

- **REF-MAN7-MEMBARRIER** — Linux man-pages: `membarrier(2)` — https://man7.org/linux/man-pages/man2/membarrier.2.html  
  - key: Linux couples some rseq-related expedited barrier behavior to explicit membarrier registration rather than making it ambient
  - why: stable API-level reference for what this archive is explicitly *not* standardizing as a public D-RSEQ workflow seam in v0
  - us: supports the posture choice to keep retry/barrier coordination runtime-local and RFC-first if ever surfaced

- **REF-PTHREAD-MUTEXATTR-SETROBUST** — Linux man-pages: `pthread_mutexattr_setrobust(3)` — https://man7.org/linux/man-pages/man3/pthread_mutexattr_setrobust.3.html  
  - key: robust mutexes report `EOWNERDEAD` after owner death; unlocking before `pthread_mutex_consistent()` leaves the mutex permanently unusable as `ENOTRECOVERABLE`
  - why: portable/POSIX-aligned precedent for explicit repair-vs-poison recovery semantics
  - us: informs D-ROBUSTLOCK v0's choice to require `make_consistent()` or transition to `NOT_RECOVERABLE`

- **REF-LINUX-ROBUST-FUTEX-ABI** — Linux kernel docs: *The robust futex ABI* — https://docs.kernel.org/locking/robust-futex-ABI.html  
  - key: kernel-assisted cleanup on task exit sets OWNER_DIED and wakes a waiter
  - why: established pattern for robust shared-memory locks without per-lock kernel objects
  - us: informs D-ROBUSTLOCK semantics, bounds, and exit-path design

- **REF-KERNEL-ROBUST-FUTEXES-TXT** — Linux kernel docs (legacy): `robust-futexes.txt` — https://www.kernel.org/doc/Documentation/robust-futexes.txt  
  - key: rationale and contract for robust mutex cleanup (the “catch-22” that robustness solves)
  - why: short, high-signal explanation of the failure mode
  - us: sharpens D-ROBUSTLOCK motivation and recovery posture

- **REF-LINUX-GET-ROBUST-LIST** — Linux man-pages: `get_robust_list(2)` — https://man7.org/linux/man-pages/man2/get_robust_list.2.html  
  - key: per-thread robust list used by the kernel to find and mark held locks on exit
  - why: ABI precedent for registration-based coverage
  - us: informs RobustSet registration and validation rules

- **REF-LINUX-RCU-WHATIS** — The Linux Kernel documentation: *What is RCU?* — https://docs.kernel.org/RCU/whatisRCU.html  
  - key: introductory explanation of RCU’s read-mostly synchronization model
  - why: practical “grace period” intuition for publish/reclaim patterns
  - us: informs D-RCU motivation and terminology (grace periods; read-side vs update-side)

- **REF-LINUX-RCU-CONCEPTS** — The Linux Kernel documentation: *RCU Concepts* — https://docs.kernel.org/RCU/rcu.html  
  - key: describes the split of updates into “hide from readers” and “reclaim after a grace period”
  - why: concrete statement of the safety condition D-RCU must preserve
  - us: informs D-RCU `synchronize()` semantics and safety notes

- **REF-LINUX-RCU-CHECKLIST** — The Linux Kernel documentation: *Review Checklist for RCU Patches* — https://docs.kernel.org/RCU/checklist.html  
  - key: common RCU pitfalls and required correctness constraints
  - why: lived experience on how RCU is misused in real codebases
  - us: informs D-RCU guidance and test ideas for misuse cases

- **REF-MCKENNEY-PERFBOOK** — Paul E. McKenney (ed.): *Is Parallel Programming Hard, And, If So, What Can You Do About It?* (perfbook) — https://www.kernel.org/pub/linux/kernel/people/paulmck/perfbook/perfbook.2011.08.28a.pdf  
  - key: broad, practical coverage of shared-memory parallel programming including RCU
  - why: high-signal guidance on design tradeoffs and correctness reasoning
  - us: informs D-CONC staging and D-RCU usage guidance/pitfalls

- **REF-HAZARD-POINTERS-MICHAEL** — Maged M. Michael: *Hazard Pointers: Safe Memory Reclamation for Lock-Free Objects* (2004) — https://www.cs.otago.ac.nz/cosc440/readings/hazard-pointers.pdf  
  - key: introduces hazard pointers as an alternative reclamation technique for lock-free structures
  - why: illustrates the ergonomics/overhead tradeoffs vs epoch/grace-period approaches
  - us: informs D-RCU alternatives and library guidance

- **REF-FRASER-PRACTICAL-LOCK-FREEDOM** — Keir Fraser: *Practical lock-freedom* (Cambridge TR-579) — https://www.cl.cam.ac.uk/techreports/UCAM-CL-TR-579.pdf  
  - key: lock-free programming abstractions, including reclamation patterns in real systems
  - why: canonical, implementation-oriented background for lock-free ecosystems
  - us: informs D-RCU profile choices (QSBR/EBR) and evidence ideas

- **REF-HART-MEMRECL-IPDPS06** — Hart, McKenney, Brown: *Making lockless synchronization fast: performance implications of memory reclamation* (IPDPS 2006) — https://www.cecs.uci.edu/~papers/ipdps06/pdfs/1568974892-IPDPS-paper-1.pdf  
  - key: compares reclamation schemes and explains why stalled threads can block QSBR/EBR reclamation
  - why: grounds the “stall posture must be explicit” requirement
  - us: informs D-RCU bounds and supervision-driven stall handling

- **REF-LIBURCU** — Userspace RCU (liburcu) — https://liburcu.org/  
  - key: widely deployed userspace RCU library with multiple RCU flavors (including QSBR variants)
  - why: practical precedent that grace-period synchronization belongs in user space for many systems
  - us: informs D-RCU service/library shape and profiling options

- **REF-CROSSBEAM-EPOCH** — docs.rs: `crossbeam-epoch` — https://docs.rs/crossbeam-epoch  
  - key: Rust epoch-based reclamation crate describing pin/unpin participation, deferred garbage, and `no_std`-friendly deployment outside the global collector
  - why: primary Rust ecosystem precedent for runtime-local EBR without inventing a kernel policy seam
  - us: informs D-RCU Phase-1 guidance that EBR belongs inside runtime-owned domains rather than as a system-global service

- **REF-CONCURRENCY-KIT** — Concurrency Kit (`ck_epoch`, `ck_hp`) — https://concurrencykit.org/  
  - key: practical safe-memory-reclamation toolkit exposing both epoch-based reclamation and hazard pointers, including idle-thread support and bounded-concurrency data structures
  - why: concrete evidence that multiple reclamation families exist, but should remain explicit library/runtime choices rather than a single ambient platform contract
  - us: informs D-RCU’s v0 decision to keep the ecosystem seam QSBR-first and per-subsystem while leaving HP/other variants out of the core contract

- **REF-FREEBSD-UMTX-OP** — FreeBSD man page: `_umtx_op(2)` — https://man.freebsd.org/cgi/man.cgi?query=_umtx_op&sektion=2  
  - key: kernel support for userspace threading primitives (mutexes/condvars), including process-shared variants
  - why: independent precedent for “kernel assists userspace locks” outside Linux/Windows
  - us: informs D-UWAIT bounds/ABI and the “shared vs private” option space

- **REF-FUCHSIA-FUTEX** — Fuchsia/Zircon: Futex kernel object reference — https://fuchsia.dev/fuchsia-src/reference/kernel_objects/futex  
  - key: futex identity is derived from the userspace address; process-local; optional ownership for PI-like behavior
  - why: modern microkernel ecosystem precedent closely aligned with our design posture
  - us: informs D-UWAIT process-local default and pointer-tag normalization

us: informs D-IOQ API design (completion visibility; deterministic error paths)

- **REF-FUCHSIA-VMAR-MAP** — Zircon/Fuchsia `zx_vmar_map` syscall docs — https://fuchsia.dev/reference/syscalls/vmar_map  
  - key: mapping permissions are checked against rights on both the VMAR handle and the VMO handle (incl. execute)
  - why: demonstrates a practical two-key execute gate for executable mappings
  - us: supports D-DYNCODE: require both VSpace permission and MemObj execute right
- **REF-FUCHSIA-VMO-EXEC** — Zircon/Fuchsia `zx_vmo_replace_as_executable` syscall docs — https://fuchsia.dev/reference/syscalls/vmo_replace_as_executable  
  - key: adding execute rights to a VMO requires a distinct exec-authority handle (vmex); upgrades are explicit
  - why: prevents arbitrary "data→code" escalation; makes exec authority easy to audit
  - us: supports `VmExec` as the explicit execmod seam for I-EXECMOD-1
- **REF-EROS-FASTCAP** — *EROS: a fast capability system* (SOSP 1999) — https://sites.cs.ucsb.edu/~chris/teaching/cs290/doc/eros-sosp99.pdf  
  - key: practical performance + capability discipline; discusses revocation/persistence tradeoffs
  - why: realistic baseline for what a pure capability path costs
  - us: informs revocation tradeoffs (RFC-0019) and capability object semantics
- **REF-EROS-SLS-EVOLUTION** — *Design Evolution of the EROS Single-Level Store* — https://rcs.uwaterloo.ca/papers/sls.pdf  
  - key: what makes transparent persistence hard (and what worked) across SLS generations
  - why: prevents handwavy “persistent objects are easy” assumptions
  - us: informs D-PERSIST scope and the decision to keep persistence in user space

- **REF-SEMPEROS** — *SemperOS: A Distributed Capability System* (USENIX ATC 2019) — https://www.usenix.org/system/files/atc19-hille.pdf  
  - key: distributed capability mechanisms and revocation complications under concurrency
  - why: highlights what breaks when scaling capability systems across cores/nodes
  - us: cautionary input for D-CAPX/D-CONC and revocation semantics
- **REF-CAPSYS-PRIMER** — *Capability Myths Demolished* — https://papers.agoric.com/assets/pdf/papers/capability-myths-demolished.pdf  
  - key: clarifies common misconceptions, including “capabilities can’t be revoked”
  - why: gives a crisp conceptual frame for our capability posture
  - us: supports writing precise, constrained revocation and confinement claims
- **REF-REDOX-SYSCALLS** — Redox syscall definitions as data (syscalls.toml) — https://github.com/redox-os/design/blob/master/design/syscalls.toml  
  - key: machine-readable syscall table used as an implementation reference
  - why: “ABI as data” supports generation + auditing
  - us: precedent for D-IDL drift guards and stub generation
- **REF-REDOX-SCHEMES** — Redox book: Schemes (service endpoints as namespaces) — https://doc.redox-os.org/book/schemes.html  
  - key: “everything is a scheme” — OS services exposed via scheme endpoints, VFS-like by default
  - why: ergonomics matter for making “services as objects” a lived reality
  - us: supports D-TRANS/service-tree conventions where endpoints are capability-mediated nodes rather than global names
- **REF-TOCK-CAPS** — Tock kernel capabilities — https://docs.tockos.org/kernel/capabilities/  
  - key: type-enforced privilege tokens in a Rust kernel
  - why: moves internal privilege checks into static structure
  - us: bind token constructors to U-IDs/unsafe obligations
- **REF-TOCK-DESIGN** — Tock design book (capsules, isolation discipline) — https://book.tockos.org/doc/design  
  - key: “capsules” as a language-isolated abstraction; tight constraints on unsafe and dependencies
  - why: a decade of lived experience keeping a Rust kernel maintainable
  - us: supports D-UNSAFE discipline (capsule boundaries + unsafe budgets)

- **REF-TOCK-CAPSULE-ISO** — Tock threat model: capsule isolation — https://book.tockos.org/doc/threat_model/capsule_isolation  
  - key: capsule isolation implemented by banning `unsafe` in capsule code + restricting unaudited deps
  - why: a clear statement of the assumptions and failure modes for language-based isolation
  - us: template for I-UNSAFE-2/PO-UNSAFE-SCAN (bounded unsafe surface as an evidence gate)
- **REF-NIX-GUIX** — Nix/Guix concepts — https://nixos.org/ / https://guix.gnu.org/  
  - key: declarative, reproducible system state
  - why: ops posture influences security posture
  - us: treat config as signed canonical artifact


- **REF-ZFS-PAPER** — *The Zettabyte File System* (Bonwick et al.) — https://www.cs.hmc.edu/~rhodes/cs134/readings/The%20Zettabyte%20File%20System.pdf  
  - key: transactional copy-on-write, constant-time snapshots/clones, end-to-end integrity
  - why: shows snapshots can be cheap enough to use routinely (“boot environments” style rollback)
  - us: inspires D-PERSIST + D-ATOMICUPD composition without privileged magic

- **REF-SOLARIS-BOOTENV** — Oracle Solaris: Boot Environments overview (beadm + ZFS) — https://docs.oracle.com/cd/E59957_01/doc.123/e59971/GUID-2FF3402C-BE90-407C-8400-06C77EA2CF93.htm  
  - key: bootable ZFS snapshot/clone roots managed as first-class “boot environments”
  - why: operational proof that rollback-by-default is usable at scale
  - us: strong precedent for CH-BOOTSEL “pending/tries/commit” semantics and digest-bound activation
- **REF-FREEBSD-BECTL** — FreeBSD `bectl(8)` (ZFS boot environment manager) — https://man.freebsd.org/cgi/man.cgi?bectl%288%29=  
  - key: boot environments as bootable dataset clones; tooling supports activation + listing + rollback
  - why: shows the minimal user-facing affordances that make atomic upgrades non-scary
  - us: informs our boot-selector UX and “activate-once then revert unless committed” state machine
- **REF-ZFS-SENDRECV** — ZFS send/receive snapshot streams (replication) — https://openzfs.github.io/openzfs-docs/man/master/8/zfs-send.8.html  
  - key: portable snapshot streams (full or incremental) for replication/migration
  - why: makes “checkpoint as a transportable artifact” concrete
  - us: inspiration for user-space checkpoint artifact formats (D-CHKPT) without kernel hooks

- **REF-PROJECT-OBERON** — *Project Oberon* (Wirth) — https://people.inf.ethz.ch/wirth/ProjectOberon/PO.System.pdf  
  - key: “small enough to understand” OS/compiler stack with explicit mechanisms
  - why: forces ruthless simplicity and whole-system legibility
  - us: inspiration for D-XS (exit-surface budgets) + spec-first CH-* discipline
- **REF-MIRAGE-PAPERS** — MirageOS paper index — https://mirage.io/papers
  - key: curated bibliography for unikernels + tooling for sealed appliances
  - why: quick on-ramp to the unikernel literature without chasing citations
  - us: supports D-SEAL/D-FPM “sealed image profile” thinking (RFC-0003 §24b)

- **REF-UNIKERNELS-ASPL13** — *Unikernels: Library Operating Systems for the Cloud* (ASPLOS 2013, Madhavapeddy et al.) — https://anil.recoil.org/papers/2013-asplos-mirage.pdf
  - key: compile-time specialization + small sealed images for cloud services
  - why: shows the security/ops wins of “avoid compatibility; seal the appliance”
  - us: treat as a deployment profile layered on D-BOOT/D-FPM/D-SEAL, not a new privileged mechanism

- **REF-AMOEBA-INTRO** — Tanenbaum et al., *The Amoeba Distributed Operating System* (intro) — https://www.cs.vu.nl/pub/amoeba/Intro.pdf  
  - key: capability-based, location-transparent object references; directories + servers in user space
  - why: shows “names = authority” in a distributed setting
  - us: informs D-CAPX (sturdyrefs via CH-SREF) + D-NS (views) without ambient host authority
- **REF-AMOEBA-CACM90** — Tanenbaum et al., *Experiences with the Amoeba Distributed Operating System* (CACM 1990) — https://www.cs.vu.nl/~ast/Publications/Papers/cacm-1990.pdf  
  - key: bullet server immutability; directory server semantics; pragmatic RPC/caching lessons
  - why: concrete “immutable object + atomic directory swap” workflows
  - us: inspiration for D-PERSIST/D-ATOMICUPD profiles without kernel bloat
- **REF-AMOEBA-1990S** — Mullender et al., *Amoeba: a distributed operating system for the 1990s* — https://www.cs.cornell.edu/home/rvr/papers/Amoeba1990s.pdf  
  - key: system architecture overview; bullet service + replication patterns
  - why: concise distributed OS blueprint
  - us: helps scope cross-machine capability routing + fault models (optional)
- **REF-TWIZZLER-ATC20** — Bittman et al., *Twizzler: a Data-Centric OS for Non-Volatile Memory* (USENIX ATC 2020) — https://www.usenix.org/system/files/atc20-bittman.pdf  
  - key: object-based persistent data + object-relative pointers; security at object granularity
  - why: persistent memory breaks the “file I/O is the center” assumption
  - us: motivates keeping D-PERSIST flexible for object graphs + revocation epochs
- **REF-TWIZZLER-TR17** — Bittman et al., *Twizzler: An Operating System for Next-Generation Memory Hierarchies* (tech report) — https://dbittman.com/papers/bittman-ssrc-tr17.pdf  
  - key: deeper design discussion of object references, sharing and recovery
  - why: more detail than the ATC paper on resolver/pointer model
  - us: supports scoping a “persistent object profile” seam without privileged policy
- **REF-MULTICS-RINGS** — Schroeder & Saltzer, *A Hardware Architecture for Implementing Protection Rings* (CACM 1972) — https://web.mit.edu/saltzer/www/publications/multics/M0126.pdf  
  - key: rings + controlled cross-ring calls for protected subsystems
  - why: early, influential “layered privilege” design
  - us: reminder to keep privileged call surfaces tiny; treat intra-domain compartmentalization as optional user-space hardening
- **REF-MULTICS-PROTMULT** — Saltzer, *Protection and the Control of Information Sharing in Multics* — https://web.mit.edu/saltzer/www/publications/protmult.pdf  
  - key: principles + mechanisms for controlled information sharing
  - why: concrete articulation of protected subsystems and tradeoffs
  - us: aligns with our “interfaces-as-data + fail-closed” approach
- **REF-KARGER-2002** — Karger & Schell, *Thirty Years Later: Lessons from the Multics Security Evaluation* (IEEE S&P 2002) — https://gwern.net/doc/cs/security/2002-karger.pdf  
  - key: retrospective on how complexity and special cases became vulnerabilities
  - why: cautionary evidence for long-lived systems
  - us: reinforces exit-surface budgeting (see `docs/30-architecture/exit-surface-budget.md`) + non-claims discipline

## Sandboxing / authority narrowing patterns
- **REF-OPENBSD-33-WX** — OpenBSD 3.3 release notes (W^X) — https://www.openbsd.org/33.html  
  - key: W^X policy as a default platform stance (no writable+executable memory)
  - why: shrinks “turn bytes into code” exploit surface
  - us: supports D-DYNCODE posture (W^X + execmod gating)
- **REF-OPENBSD-WX-KERNEL** — *Kernel W^X Improvements in OpenBSD* (Hackfest 2014/2015 talk) — https://www.openbsd.org/papers/hackfest2015-w-xor-x.pdf  
  - key: practical engineering constraints of enforcing W^X in a real kernel
  - why: highlights failure modes and performance tradeoffs
  - us: evidence reference for implementing W^X and avoiding RWX escape hatches
- **REF-JITDEFENDER** — *JITDefender: A Defense against JIT Spraying Attacks* (IFIP SEC 2011) — https://opendl.ifip-tc6.org/db/conf/sec/sec2011/ChenFMX11.pdf  
  - key: concrete attack/migration pressures around JIT “write then execute”
  - why: motivates treating execmod as explicit, reviewable authority
  - us: informs D-DYNCODE profiles + tests for exec-enabling paths
- **REF-WAR-ON-JITS** — *War on JITs: Software-Based Attacks and Hybrid Defenses* (ACM, 2025) — https://dl.acm.org/doi/10.1145/3731598  
  - key: survey of JIT attack surface and defenses
  - why: consolidates threat patterns beyond one-off spraying attacks
  - us: reference for threat-modeling D-DYNCODE exceptions
- **REF-OPENBSD-PLEDGE** — OpenBSD pledge(2) man page — https://man.openbsd.org/pledge.2  
  - key: one-way restriction via “promises” and exec promises
  - why: captures init→seal discipline in a tiny API
  - us: candidate pattern for D-SEAL in privileged services
- **REF-OPENBSD-UNVEIL** — OpenBSD unveil(2) man page — https://man.openbsd.org/unveil.2  
  - key: path/permission rules for filesystem access + one-way lock
  - why: turns “what files can I open?” into an explicit, sealable surface
  - us: informs view/path capability modeling under D-SEAL
- **REF-BECK-PLEDGEUNVEIL-2018** — *Pledge and Unveil in OpenBSD* (BSDCan 2018, Beck) — https://www.openbsd.org/papers/BeckPledgeUnveilBSDCan2018.pdf  
  - key: design rationale + practical usage of pledge/unveil for making large programs safer
  - why: captures the intended ergonomics and failure modes (deny vs kill, adoption patterns)
  - us: informs CH-PLEDGE semantics, token granularity, and evidence plan for D-SEAL
- **REF-LANDLOCK** — Linux Landlock documentation (kernel.org) — https://docs.kernel.org/userspace-api/landlock.html  
  - key: unprivileged access-control allowing processes to restrict themselves (and descendants)
  - why: shows a deployable ‘self-restriction’ pattern layered atop system-wide controls
  - us: comparative reference for promise-mask inheritance and deny/kill policy choices

- **REF-SERENITY-PLEDGEUNVEIL** — *pledge() and unveil() in SerenityOS* (Kling, 2020) — https://awesomekling.github.io/pledge-and-unveil-in-SerenityOS/  
  - key: independent reimplementation of pledge/unveil with the same one-way “promises” ergonomics
  - why: evidence that the pattern is portable and adoptable in a greenfield OS
  - us: supports “bake-in” priority for CH-PLEDGE + unveil-on-views workflows

- **REF-THREADBOX-ARXIV25** — *Threadbox: Sandboxing for Modular Security* (arXiv, 2025) — https://arxiv.org/html/2506.23683  
  - key: motivates pledge-style promises over syscall-by-syscall filters due to policy authoring and debugging cost; introduces explicit learn/debug modes
  - why: modern usability-driven support for “promise learning” and drift gates
  - us: informs CH-PLEDGE deny-mode logging and CI token-discovery workflows


- **REF-LWN-UNVEIL** — LWN overview of unveil() — https://lwn.net/Articles/767137/  
  - key: comparative discussion of unveil vs Linux hardening mechanisms
  - why: helps avoid importing the wrong abstraction
  - us: sanity-check any path-based or “unveil-like” designs
- **REF-WASM-CM-INTRO** — WebAssembly Component Model: introduction (Bytecode Alliance docs) — https://component-model.bytecodealliance.org/  
  - key: component composition + interface-typed boundaries for Wasm
  - why: a practical substrate for “plugins without ambient authority”
  - us: default IF-SBX payload to Wasm components (D-WASM)
- **REF-WASM-CANONABI** — Component Model canonical ABI overview (Bytecode Alliance docs) — https://component-model.bytecodealliance.org/advanced/canonical-abi.html  
  - key: stable cross-language ABI for component interop
  - why: makes “typed interfaces” operational across languages
  - us: treat import closure + canonical ABI bindings as auditable seams
- **REF-WASI-0-2** — WASI 0.2 (Preview 2) launched (Bytecode Alliance) — https://bytecodealliance.org/articles/WASI-0.2  
  - key: capability-oriented system interfaces designed for the component model
  - why: avoids ambient acquisition; supports interface virtualization
  - us: align D-WASM imports with capability-first interfaces where possible
- **REF-CAPMYTHS** — *Capability Myths Demolished* (Miller, Yee, Shapiro) — https://papers.agoric.com/assets/pdf/papers/capability-myths-demolished.pdf  
  - key: revocation/confinement are possible with the right patterns
  - why: debunks common objections; clarifies threat models
  - us: supports D-CAP/D-MEMBRANE stance choices
- **REF-OCAP-AOCS** — *Analysing Object-Capability Security* (Murray) — https://www.cs.ox.ac.uk/people/toby.murray/papers/AOCS-hyperref.pdf  
  - key: formal analysis of membrane/revocation/sealer patterns under concurrency
  - why: shows subtle failures when patterns move into OS contexts
  - us: informs D-MEMBRANE design + staged concurrency (D-CONC)
- **REF-OCAP-MURPHI** — *Analysing Object-Capability Patterns with Murϕ* (Stefan et al.) — https://cseweb.ucsd.edu/~dstefan/pubs/stefan:2011:ocap.pdf  
  - key: automated counterexample finding for ocap patterns
  - why: “model-check fast” evidence template for patterns
  - us: candidate tooling approach for wrappers/membranes


## Origin tagging / quarantine metadata
- **REF-MOTW-ZONEID** — Zone.Identifier stream name (Windows file system docs, MotW) — https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/6e3f7352-d11c-4d76-8c39-2516a9df36e8  
  - key: origin tagging via alternate data stream storing security zone
  - why: provenance tags influence safe-open decisions and security tooling
  - us: justify D-QUAR: explicit origin/quarantine tags with monotonic rules and keeping derived risky-content outputs classified until an explicit clear/sanitize workflow says otherwise
- **REF-MACOS-GATEKEEPER** — Gatekeeper overview (“Safely open apps on your Mac”, Apple Support) — https://support.apple.com/en-us/102445  
  - key: quarantine-backed checks before first run/open
  - why: shows the value (and UX constraints) of origin-aware execution gates
  - us: default quarantined opens to disposable safe-open workflows (D-QUAR/D-EPHEM)
- **REF-GATEKEEPER-BYPASS** — Gatekeeper bypasses when quarantine is not enforced consistently (Unit 42) — https://unit42.paloaltonetworks.com/gatekeeper-bypass-macos/  
  - key: inconsistent quarantine propagation/enforcement enables bypasses
  - why: emphasizes that tagging must be monotonic + tested against container flows
  - us: laundering corpus + PO-QUAR-PROP (D-QUAR evidence plan)
- **REF-MS-PREVIEW-MOTW** — File Explorer automatically disables preview for files downloaded from the internet (Microsoft Support) — https://support.microsoft.com/en-au/topic/file-explorer-automatically-disables-the-preview-feature-for-files-downloaded-from-the-internet-56d55920-6187-4aae-a4f6-102454ef61fb  
  - key: files carrying Mark of the Web no longer get implicit preview rendering by default
  - why: shows that preview/open is itself a risky parser path and should not silently neutralize quarantine
  - us: supports D-QUAR’s rule that safe-open/view is separate from clear and that dequarantined materialization should be a new artifact rather than an in-place trust mutation
- **REF-MS-PREVIEW-HANDLERS** — Microsoft Learn, *Preview Handlers and Shell Preview Host* — https://learn.microsoft.com/en-us/windows/win32/shell/preview-handlers  
  - key: Windows preview handlers render a lightweight, read-only preview of a file in the reading pane **without launching the associated application**
  - why: shows that preview-pane rendering on mere selection is a real shell surface, not just a hypothetical UX detail
  - us: supports `quarantined-result-preview-boundary-v0.md` by keeping quarantined result rendering metadata-safe unless an explicit review/open step is taken
- **REF-MS-OFFICE-MOTW-MACROS** — Microsoft Learn, *Macros from the internet are blocked by default in Office* — https://learn.microsoft.com/en-us/microsoft-365-apps/security/internet-macros-blocked  
  - key: Office blocks internet-origin VBA macros by default because macros are a common malware/ransomware delivery path
  - why: shows that document-origin trust and embedded active-content execution are separate decisions
  - us: supports keeping `open_untrusted` viewers inert-by-default instead of treating risky-open as permission to run macros
- **REF-ADOBE-PDF-DOCJS** — Adobe Acrobat SDK, *JavaScript Developer Guide: JavaScript contexts* — https://opensource.adobe.com/dc-acrobat-sdk-docs/library/jsdevguide/JS_Dev_Contexts.html  
  - key: PDF documents can include document-level JavaScript that executes in document/open/view contexts
  - why: shows that “open document” can implicitly become “run document-authored code” unless the viewer boundary disables it
  - us: supports `open-untrusted-active-content-boundary-v0.md` and the inert-by-default safe-open decision
- **REF-APPLE-RECENT-ITEMS** — Apple Support, *Open recently used items on Mac* — https://support.apple.com/guide/mac-help/open-recently-used-items-on-mac-mchlp2724/mac  
  - key: macOS exposes durable recent items for apps, documents, and servers, and lets users reopen or clear them
  - why: shows that recent-doc / reopen surfaces are real OS-level persistence surfaces, not hypothetical UI trivia
  - us: supports `open-untrusted-viewer-residue-boundary-v0.md` so risky-open preview does not auto-enroll source objects into durable recent-item menus outside the disposable
- **REF-APPLE-QUICKLOOK** — Apple Support, *View and edit files with Quick Look on Mac* — https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac  
  - key: Quick Look offers a fast, full-size preview of nearly any kind of file **without opening the file**, and is available from Finder, email, messages, and other places
  - why: shows that ambient preview surfaces are a first-class OS affordance that can expose file content before a full open workflow
  - us: supports `quarantined-result-preview-boundary-v0.md` by requiring explicit review/open for quarantined preview rather than ambient Quick Look / hover-card behavior
- **REF-APPLE-SPOTLIGHT-MAC** — Apple Support, *Search for anything with Spotlight on Mac* — https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac  
  - key: Spotlight lists top matches first and can preview or open a top match directly from the search UI
  - why: shows that search result surfaces themselves can become preview/render channels rather than simple metadata lists
  - us: supports `quarantined-result-preview-boundary-v0.md` by keeping quarantined search results metadata-safe until an explicit handle-targeted review/open step occurs
- **REF-MS-WINDOWS-SEARCH-INDEXING** — Microsoft Learn, *Indexing process in Windows Search* — https://learn.microsoft.com/en-us/windows/win32/search/-search-indexing-process-overview  
  - key: Windows Search indexes both properties and file contents, including inverted indices over textual content
  - why: shows that content-derived indexing is a real OS surface and can persist derived artifacts outside the original viewer/request path
  - us: supports `quarantined-content-index-boundary-v0.md` so quarantined bytes stay out of ambient full-text/OCR/embedding/summarization flows unless an explicit derived-output workflow says otherwise
- **REF-APPLE-CORESPOTLIGHT** — Apple Developer Documentation, *Core Spotlight* — https://developer.apple.com/documentation/corespotlight  
  - key: apps can index content they manage for on-device search
  - why: shows that semantic/content indexing is an intentional platform surface, not just filename metadata
  - us: supports `quarantined-content-index-boundary-v0.md` by keeping risky content out of ambient search/assistant indexes until explicit analysis or clear
- **REF-MS-OFFICE-MRU** — Microsoft Learn, *Edit the Windows registry to clear the list of most recently used files in Office* — https://learn.microsoft.com/en-us/troubleshoot/microsoft-365-apps/settings/clear-most-recently-used-file  
  - key: Office maintains MRU file lists across File/Open/SaveAs/Insert flows and persists recent-file shortcuts unless explicitly cleared
  - why: shows that MRU state is a durable reopen/privacy surface worth fencing off from risky-open side effects
  - us: supports `open-untrusted-viewer-residue-boundary-v0.md` so preview/open does not quietly create host-side MRU persistence or reopen hints

## Tracing / observability
- **REF-DTRACE** — *DTrace: Dynamic Tracing in a Production System* (USENIX 2004) — https://www.usenix.org/conference/usenix-04-general-track/dtrace-dynamic-tracing-production-system
- **REF-DTRACE-SAFETY** — “DTrace Safety” (Cantrill, 2005) — https://bcantrill.dtrace.org/2005/07/19/dtrace-safety/  
  - key: provider-published probes + a purpose-built, restricted VM for predicates/actions; fail-safe exception handling
  - us: supports RFC-0015’s “bounded predicates/filters” option without making tracing a kernel footgun
  - key: safe, low-overhead tracing designed as a system primitive
  - why: observability pays huge dividends if it is safe-by-design
  - us: motivates D-TRACE + a pinned CH-TRACE schema exported via IF-OBS
- **REF-DTRACE-PREDICATES** — Predicates in DTrace (Oracle Solaris 11.4 DTrace Guide) — https://docs.oracle.com/en/operating-systems/solaris/oracle-solaris/11.4/dtrace-guide/predicates-dtrace.html
  - key: predicates are evaluated at probe firing time; D intentionally omits loops/if-statements and uses predicates for conditional tracing
  - why: supports our ‘bounded predicate’ stance without importing general control flow
  - us: motivates CH-TPRED as a non-Turing boolean prefilter format (RFC-0073)
- **REF-LINUX-TRACE-EVENTS** — Linux kernel event tracing docs (event formats + field names) — https://docs.kernel.org/trace/events.html
- **REF-LINUX-TRACE-EVENT-FORMAT** — Linux trace event “format” files (field descriptors + print fmt examples) — https://www.kernel.org/doc/html/v5.4/trace/events.html
- **REF-LINUX-TRACE-FILTER** — Linux kernel trace events: event filtering / triggers (kernel.org docs) — https://www.kernel.org/doc/html/v5.4/trace/events.html
  - key: trace events and triggers support boolean filter expressions evaluated against event fields
  - why: shows the pragmatic operator need for cheap near-source filtering
  - us: motivates D-TPRED + bounded field predicates
- **REF-LTTNG-FILTER** — LTTng `enable-event` filter expressions (man page) — https://lttng.org/man/1/lttng-enable-event/v2.12/
  - key: `--filter` expressions evaluate against dynamic event fields; missing fields fail the condition
  - why: another widely used model of safe prefiltering without in-kernel scripting
  - us: motivates CH-TPRED semantics (missing field → false) as an easy fail-closed rule

- **REF-MS-ETW** — Microsoft Win32 docs: Event Tracing (ETW) overview — https://learn.microsoft.com/en-us/windows/win32/api/_etw/
  - key: high-volume, structured event tracing with providers, levels/keywords, and explicit activity/correlation support
  - why: mature operational precedent for “schema-first tracing” as a platform capability
  - us: reinforces D-TRACE + D-TPROBE posture and “correlate by ID” without expanding the privileged core
- **REF-MS-ETW-ACTIVITYID** — Microsoft: Using Activity Identifiers (ETW correlation) — https://learn.microsoft.com/en-us/windows-hardware/drivers/wdf/using-activity-identifiers
  - key: activity IDs associate related events/requests; correlation is built into the tracing model
  - why: shows the practical value of first-class correlation keys in diagnostics
  - us: informs recommended CH-TPROBE `sem` tags (`corr_id`, `trace_id`/`span_id`) and cross-artifact correlation conventions
- **REF-APPLE-OSLOGPRIVACY** — Apple Developer: `OSLogPrivacy` (public/private log fields) — https://developer.apple.com/documentation/os/oslogprivacy
  - key: privacy-by-default redaction model for logs (private fields are redacted unless explicitly public)
  - why: avoids accidental secret leakage via diagnostics at ecosystem scale
  - us: supports D-OBSPOL/D-INSPECT export posture and “classification is data” discipline for diagnostics

- **REF-SYSTEMD-JOURNALD** — `systemd-journald.service(8)` (logging service behavior, limits, streams) — https://man7.org/linux/man-pages/man8/systemd-journald.service.8.html
  - key: a platform logging service with explicit stream limits and well-defined behavior under overload
  - why: operational precedent for “bounded logging + drop behavior” as a platform contract
  - us: informs D-FLIGHTREC ring bounds + deterministic overflow and D-OBSPOL export posture
- **REF-LINUX-RAMOOPS** — Linux kernel docs: ramoops oops/panic logger — https://docs.kernel.org/admin-guide/ramoops.html
  - key: circular “dying breath” logs written to (persistent) RAM to survive a reboot
  - why: crashes are exactly when you lose logs; crash-survivor buffers are high leverage
  - us: optional D-FLIGHTREC crash-survivor ring (small, bounded, sensitive)
- **REF-LINUX-PSTORE** — Linux kernel docs: pstore interface (ABI/testing) — https://www.kernel.org/doc/Documentation/ABI/testing/pstore
  - key: filesystem interface to persistent crash records (read and clear records after reboot)
  - why: a clean model for “store last-gasp records and retrieve them next boot”
  - us: motivates a minimal crash-record export seam folded into CH-SNAPSHOT bundles
- **REF-ANDROID-NATIVE-CRASH** — Android Open Source Project docs: diagnose native crashes (tombstones) — https://source.android.com/docs/core/tests/debug/native-crash
  - key: standardized crash artifacts (tombstones/debuggerd output) aid triage and support workflows
  - why: shows what ecosystems expect “by default” for post-mortem debugging
  - us: informs CH-CRASHCAP payload kinds + incident capture defaults in D-INSPECT/D-FLIGHTREC
- **REF-OTEL-TRACE-API** — OpenTelemetry specification: Trace API identifiers (TraceId/SpanId; W3C alignment) — https://github.com/open-telemetry/opentelemetry-specification/blob/main/specification/trace/api.md
  - key: standardized trace/span identifiers and context propagation expectations
  - why: a de-facto lingua franca for correlating events across components and boundaries
  - us: optional alignment target for trace processor outputs and correlation semantics in CH-TPROBE
- **REF-OTEL-PROCESS-METRICS** — OpenTelemetry semantic conventions: OS process metrics — https://opentelemetry.io/docs/specs/semconv/system/process-metrics/
  - key: standardized names/attributes for process-level CPU, memory, IO, and count metrics
  - why: execution telemetry is useful, but it belongs to an observational metrics vocabulary rather than a replay/authorization seam
  - us: supports the capshell result-sidecar boundary: any future resource-usage reporting should stay a separate, non-authoritative telemetry surface
- **REF-W3C-TRACECONTEXT** — W3C Trace Context — https://www.w3.org/TR/trace-context/
  - key: standard headers/value formats for propagating trace context between services
  - why: enables cross-component correlation without bespoke protocols
  - us: reference for how an ecosystem can carry correlation IDs over existing channels (without adding kernel surfaces)

- **REF-EBPF-INTRO** — eBPF overview (ebpf.io) — https://ebpf.io/what-is-ebpf/
  - key: load-time verification + sandboxed execution model for kernel hooks
  - why: shows why “programmable hooks” are ecosystem gold
  - us: motivates a cautious stance: keep programmable filtering out of the privileged core unless a tiny bounded subset suffices (RFC-0015)
- **REF-EBPF-VERIFIER-HARNESS** — “Harnessing the eBPF Verifier” (Trail of Bits, 2023) — https://blog.trailofbits.com/2023/01/19/ebpf-verifier-harness/
  - key: verifier complexity + the need for CI/testing harnesses
  - why: real-world evidence that verifier correctness is nontrivial
  - us: supports pushing rich programmability to isolated domains and treating any verifier as a separately audited component


- **REF-BPFTRACE** — bpftrace (high-level tracing language for eBPF) — https://github.com/bpftrace/bpftrace
  - key: ergonomic, scriptable “ask one question” observability workflow
  - why: shows what operators actually want from programmable tracing
  - us: motivates D-TRACEPROC: keep the UX but move programmability out of the privileged core
- **REF-BCC** — BCC (BPF Compiler Collection) — https://github.com/iovisor/bcc
  - key: a rich ecosystem forms around safe-ish hooks + libraries
  - why: demonstrates the tooling multiplier effect of programmable observability
  - us: prefer user-space sandboxes (Wasm) over in-kernel VMs while keeping similar tooling affordances

## Fault injection / failure testing
- **REF-FREEBSD-FAILPOINTS** — `fail(9)` man page (FreeBSD kernel fault injection) — https://man.freebsd.org/cgi/man.cgi?query=fail&sektion=9
  - key: named failpoints + user-controlled triggers for error injection
  - why: making failure paths testable is a reliability primitive
  - us: motivates D-FAILPOINT as a bounded dev/test seam (RFC-0048)
- **REF-LINUX-FAULTINJECT** — Linux fault-injection framework docs — https://docs.kernel.org/fault-injection/fault-injection.html
  - key: structured fault injection for alloc and other subsystems; configured via debugfs/boot options
  - why: shows a pragmatic, widely-used “inject failures” substrate
  - us: reference for trigger semantics and bounds in CH-FAIL v0
- **REF-JEPSEN** — Jepsen: distributed systems verification + fault injection (nemesis) — https://github.com/jepsen-io/jepsen
  - key: systematic fault injection as part of correctness testing
  - why: emphasizes that failure modeling is essential, not optional
  - us: motivates designing OS seams that make higher-level fault harnesses easy
- **REF-PINGCAP-FAILPOINT** — PingCAP failpoint (FreeBSD-inspired) — https://github.com/pingcap/failpoint
  - key: language-level failpoints used in production-grade distributed systems
  - why: shows a “small tool, big payoff” engineering pattern
  - us: evidence that failpoints can be adopted widely when ergonomic


## Compatibility runtimes (legacy subsystems in user space)
- **REF-RUMPKERNEL-WIKI** — NetBSD rump kernel wiki — https://wiki.netbsd.org/rumpkernel/
  - key: run kernel subsystems in user space; isolate risky drivers/filesystems
  - why: pragmatic way to reuse mature driver code without moving it into the kernel
  - us: motivates D-RUMPK (RFC-0036) as an optional compatibility bridge
- **REF-RUMPRUN-SEL4** — *A Performance Evaluation of Rump Kernels as a Multi-…* (2017) — https://trustworthy.systems/publications/full_text/Elphinstone_ZMH_17.pdf
  - key: porting/evaluating Rumprun (rump kernel variant) on seL4
  - why: evidence that rump-style compatibility can compose with microkernel designs
  - us: informs our performance and isolation expectations for D-RUMPK

- **REF-RUMPRUN-GITHUB** — Rumprun unikernel/toolchain repository — https://github.com/rumpkernel/rumprun
  - key: practical rump-kernel-based “sealed appliance / compat capsule” toolchain
  - why: grounds what a rump-based runtime actually ships (toolchain, bake/run flow)
  - us: comparison point for D-RUMPK runtime ergonomics (keep behind D-FCELL membrane; do not import donor stacks into privileged core)

- **REF-LKL-GITHUB** — LKL (Linux Kernel Library) repository (overview/README) — https://github.com/lsds/lkl
  - key: run Linux kernel code as a user-space library to reuse subsystems (networking/FS) without a full VM
  - why: plausible “donor stack in a box” tactic for early hardware/filesystem enablement
  - us: candidate compat capsule under D-RUMPK; must remain behind I-COMPAT-1/I-COMPAT-2

- **REF-L4RE-DOC** — L4Re Operating System Framework documentation (overview) — https://l4re.org/doc/
  - key: pragmatic microkernel framework docs with user-space components and capability-based APIs
  - why: shows how a microkernel ecosystem presents driver/server patterns to developers
  - us: reference environment for D-DRVDOM + capability-mediated device access patterns
- **REF-L4RE-DEVICE-DRIVER** — L4Re tutorial: *Simple device driver* — https://l4re.org/tutorials/device-driver.html
  - key: concrete user-space driver construction workflow in an L4-based system
  - why: grounds our driver-domain bring-up expectations in a real microkernel ecosystem
  - us: informs D-DRVDOM evidence plans and “compat capsule” host boundary patterns

- **REF-FUCHSIA-DRIVER-FRAMEWORK** — Fuchsia concepts: Driver framework — https://fuchsia.dev/fuchsia-src/concepts/drivers/driver_framework
  - key: driver hosts as processes/components; isolation + lifecycle management as first-class
  - why: modern existence proof that large-scale systems can run drivers in user space by default
  - us: blueprint for D-DRVDOM + D-SUPV + D-ACTIVATE style lifecycles (drivers as hosted components)
- **REF-FUCHSIA-DRIVER-DEVEL** — Fuchsia driver development guide — https://fuchsia.dev/fuchsia-src/development/drivers/developer_guide/driver-development
  - key: drivers are DSOs loaded into driver host processes under manager control
  - why: reinforces that driver lifecycle and protocol boundaries are operational primitives, not kernel accidents
  - us: informs how we document and test driver-host lifecycle and restart semantics

- **REF-FUCHSIA-DRIVER-NODES** — Fuchsia concepts: Drivers and nodes (topology) — https://fuchsia.dev/fuchsia-src/concepts/drivers/drivers_and_nodes
  - key: drivers are bound into a device/node topology; identities/monikers follow node topology rather than ambient paths
  - why: demonstrates a modern, explicit device graph model that avoids devfs-as-authority
  - us: informs D-SKB/D-DEVGUARD device identity tokens + audit-friendly topology facts

- **REF-WINDOWS-UMDF-OVERVIEW** — Microsoft docs: Overview of UMDF — https://learn.microsoft.com/en-us/windows-hardware/drivers/wdf/overview-of-the-umdf
  - key: mainstream user-mode driver framework with defined interactions and restart/stability posture
  - why: another existence proof that user-mode drivers can be an ecosystem-level reliability strategy
  - us: reinforces “drivers are restartable services” framing for D-DRVDOM + D-SUPV

- **REF-DRAWBRIDGE-ASPL11** — *Rethinking the Library OS from the Top Down* (ASPLOS 2011, Porter et al.) — https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/asplos2011-drawbridge.pdf
  - key: “library OS + picoprocess” isolates full apps with low overhead versus full VMs
  - why: shows a realistic path to legacy-app containment without growing the privileged core
  - us: use as a comparison point for “future compatibility runtimes” under D-RUMPK; keep the compat membrane fail-closed (I-COMPAT-2)

- **REF-DRAWBRIDGE-POSIXPICO** — *How to Run POSIX Apps in a Minimal Picoprocess* (2013, Howell et al.) — https://www.microsoft.com/en-us/research/wp-content/uploads/2013/01/posix-emulation-submitted.pdf
  - key: practical POSIX emulation inside a minimal isolated compartment
  - why: demonstrates where compatibility pain concentrates (ABI coverage, IPC conventions, dynamic linking)
  - us: informs evidence targets and “no raw escape hatches” posture for any POSIX facade

- **REF-GVISOR-COST** — *The True Cost of Containing: A gVisor Case Study* (HotCloud 2019, Young et al.) — https://www.usenix.org/system/files/hotcloud19-paper-young.pdf
  - key: syscall-heavy compatibility boundaries impose measurable overhead; containment can be expensive
  - why: forces honest budgeting/fastpath design if we ever ship a large ABI facade
  - us: motivates batching/shared-memory and strict profiling gates for any userspace-kernel facade

- **REF-GVISOR-GITHUB** — gVisor repository — https://github.com/google/gvisor
  - key: userspace “application kernel” implementing Linux(-like) APIs as a containment boundary
  - why: concrete codebase to study for syscall surface closure, compatibility tax, and testing patterns
  - us: candidate *future* compat runtime family under D-RUMPK only via explicit RFC + evidence; not part of v0 posture


## Capability OSes (lessons worth stealing)
- **REF-CONFUSED-DEPUTY** — Norm Hardy, *The Confused Deputy (or why capabilities might have been invented)* (OSR 1988) — https://www.cs.utexas.edu/~witchel/380L/papers/hardy88confused.pdf
  - key: ambient identity checks let a deputy be tricked into using its own authority
  - why: the canonical problem statement that motivates capability discipline
  - us: keep “who asked?” distinct from “who has authority”; use portals, diffs/receipts, and veto-only bracketing for helpers
- **REF-JAVA-EXTSECARCH** — Wallach et al., *Extensible Security Architectures for Java* (SOSP 1997) — https://www.cs.columbia.edu/~nieh/teaching/e6118_s00/papers/p116-wallach.pdf
  - key: stack inspection + privileged blocks as a practical mechanism for mobile code
  - why: shows how explicit scoped privilege boundaries can make large ecosystems safer
  - us: borrow the *engineering pattern* (scoped privilege) but keep it veto-only and out of the privileged core
- **REF-JAVA-STACKINSPECT** — Wallach & Felten, *Understanding Java Stack Inspection* (IEEE S&P 1998) — https://www.cs.rice.edu/~dwallach/pub/oakland98.pdf
  - key: models stack inspection as a proof construction in access-control logic
  - why: clarifies the semantics of “intersection along the call stack” and where privilege boundaries matter
  - us: motivates call-chain descriptors + explicit privileged blocks for in-process deputies (D-BRACKET)
- **REF-JAVA-ACCESSCONTROLLER** — Oracle Javadoc: `java.security.AccessController` (stack-based checks + privileged boundary semantics) — https://docs.oracle.com/javase/8/docs/api/java/security/AccessController.html
  - key: concrete spec text for how checks stop at privileged frames (with/without explicit context)
  - why: the real-world API contract many systems relied on
  - us: treat “privileged block is scoped” as a non-negotiable invariant for any bracketing seam
- **REF-JAVA-DOPRIVILEGED** — Oracle guide: *API for Privileged Blocks* — https://docs.oracle.com/javase/8/docs/technotes/guides/security/doprivileged.html
  - key: scoped elevation with guaranteed privilege revocation after `run`, even on asynchronous exceptions
  - why: exception-safety is the difference between a guardrail and a footgun
  - us: require exception-safe bracketing (I-BRACKET-2; PO-BRACKET-SCOPE)
- **REF-JAVA-ACCESSCONTROL-HARDEN2017** — Holzinger et al., *Hardening Java's Access Control by Abolishing Implicit Privilege Escalation* (IEEE S&P 2017) — https://www.ieee-security.org/TC/SP2017/papers/90.pdf
  - key: studies access-control shortcuts that undermine stack-based models
  - why: “shortcuts” are where a security model silently collapses
  - us: treat bypass paths for bracketing as a first-class bug class; keep checks centralized and testable
- **REF-OPENJDK-SCOPEDVALUES** — OpenJDK JEP 429: *Scoped Values* — https://openjdk.org/jeps/429
  - key: immutable, dynamically scoped per-request/per-task data with bounded lifetime; preferred over unconstrained thread-locals
  - why: a practical modern pattern for task/request-local helper state that does not quietly become ambient mutable global state
  - us: implementation inspiration for D-BRACKET runtimes to keep borrowed-mode state task-local and lexically bounded rather than ambient
- **REF-PEP-567** — Python PEP 567: *Context Variables* — https://peps.python.org/pep-0567/
  - key: context-local state that works across asynchronous tasks, specifically to avoid `threading.local()` bleed in async code
  - why: helper/plugin ecosystems today are async-heavy; plain thread-local tricks are not enough
  - us: backs the D-BRACKET decision that privilege-bracketing state must be task/request-local, not a bare thread-local toggle
- **REF-PY-CONTEXTVARS** — Python docs: `contextvars` — https://docs.python.org/3/library/contextvars.html
  - key: standard-library guidance to use context variables instead of `threading.local()` to prevent state bleeding in concurrent code
  - why: this is the operational docs-level reminder of the async bleed hazard
  - us: supports the v0 posture that borrowed-mode/call-chain context should use bounded context-local mechanisms rather than ambient mutable globals

- **REF-KEYKOS-NANOKERNEL** — KeyKOS Nanokernel Architecture (paper) — https://css.csail.mit.edu/6.566/2018/readings/keykos.pdf  
  - key: core objects include meters (resource accounting) and checkpointing concepts
  - why: shows explicit accounting can be capability-mediated without being “policy soup”
  - us: candidate inspiration for D-METER (persistence remains optional/non-default)
- **REF-KEYKOS-ARCH85** — *The KeyKOS Architecture* (OSR 1985) — https://dl.acm.org/doi/pdf/10.1145/858336.858337  
  - key: start/resume keys + factories/constructors as first-class composition mechanics
  - why: a concise, systems-level description of “construction without ambient authority”
  - us: informs RFC-0042’s constructor boundary + confinement-test framing

- **REF-KEYKOS-OSR92** — *KeyKOS Architecture* (Key Logic / OSR 1992) — https://pdos.csail.mit.edu/6.828/2008/readings/keykos-osr.pdf  
  - key: clear microkernel framing of KeyKOS “machine model” + reasoning-oriented architecture description
  - why: a compact later writeup that’s widely circulated; easier entry point than scattered vendor docs
  - us: anchor reference for D-PERSIST/D-CONSTR narrative without importing the whole KeyKOS corpus


- **REF-KEYKOS-DOCS** — cap-lore KeyKOS documentation index — https://www.cap-lore.com/Agorics/Library/keykosindex.html  
  - key: operational details of factories, keepers, and confinement patterns
  - why: fills gaps left by papers; useful for “how did they actually do it?”
  - us: reference for constructor patterns and teardown/restart behavior
- **REF-KEYKOS-FACTORY** — cap-lore: KeyKOS Factories (doc page) — https://www.cap-lore.com/CapTheory/KK/Factory.html
  - key: factory/constructor mechanism for stamping out protected subsystems; discusses confinement patterns
  - why: primary “how factories actually work” reference (beyond high-level papers)
  - us: sharpens D-CONSTR and the boundary+confinement-test story (RFC-0042)

- **REF-HYDRA-CH6** — *The Hydra System* (capability book chapter; templates/amplification) — https://homes.cs.washington.edu/~levy/capabook/Chapter6.pdf
  - key: templates for parameter checking, controlled rights amplification, and creation; capability-based protected subsystems
  - why: concrete early design for “type managers” that need internal amplification without leaking raw authority
  - us: informs constructor boundary design and branding/sealing patterns in D-CONSTR


- **REF-EROS-FAST** — EROS: A Fast Capability System (paper draft) — https://www.cs.utah.edu/flux/tmp/draft2.ps  
  - key: capability OS design aimed at commodity hardware performance
  - why: precedent for “caps + practicality” without handwaving
  - us: informs capability semantics and optional constructor patterns
- **REF-EROS-CONFINEMENT** — Verifying the EROS Confinement Mechanism (paper) — https://flint.cs.yale.edu/cs428/doc/eros-verify.pdf  
  - key: confinement test correctness for capability-based construction
  - why: a rare example of proving a nontrivial capability “construction safety” mechanism
  - us: candidate reference for D-CONSTR if we add constructors/templates

- **REF-CAPROS-OVERVIEW** — CapROS overview (site) — https://www.capros.org/overview.html  
  - key: capability OS with **orthogonal persistence** as a core system property
  - why: rare modern continuation of KeyKOS/EROS ideas; shows “persistence without files” as an operational system
  - us: anchor reference for D-PERSIST + “resume is boot” posture

- **REF-CAPROS-USERDRIVERS** — CapROS design note: *Persistence, Non-persistence, and Device Drivers* — https://www.capros.org/design-notes/UserDrivers.html  
  - key: persistence via checkpointing user state/capabilities; device-facing state must be treated explicitly (often non-persistent)
  - why: shows the hard edge: durable authority graphs collide with non-durable hardware state
  - us: informs D-PERSIST boundaries and D-CHKPT device-virtualization posture


- **REF-ORTHOPERSIST-VLDB00** — *Orthogonally Persistent Object Systems* (Atkinson & Morrison) — https://www.vldb.org/journal/VLDBJ4/P319.pdf  
  - key: design principles and failure modes for persistence that’s uniform across object lifetimes
  - why: frames what “orthogonal persistence” buys and what it complicates (esp. concurrency/GC/rollback)
  - us: use as a checklist for bounding D-PERSIST semantics and keeping persistence explicit authority


## I/O and scheduling interface ideas
- **REF-EROS-EWS-SEC04** — *The EROS Window System: robust traceability of user volition* (USENIX Security 2004) — https://www.usenix.org/legacy/publications/library/proceedings/sec04/tech/full_papers/shapiro/shapiro.pdf  
  - key: trusted UI path with explicit, auditable linkage from user actions to effects
  - why: capability systems need a windowing/UX story that resists clickjacking/confused-deputy
  - us: motivates D-VOLITION (volition tokens) as an optional seam feeding IF-CONSENT approvals

- **REF-TREESLS-SOSP23** — *TreeSLS: A Whole-system Persistent Microkernel with Tree-structured State Checkpoint on NVM* (SOSP 2023) — https://ipads.se.sjtu.edu.cn/zh/publications/WuSOSP23.pdf  
  - key: whole-system persistence via a **capability tree** + high-frequency checkpoints; persistence added without forcing app rewrites
  - why: modern microkernel-flavored evidence that “checkpoint the authority graph” can be practical on NVM-era hardware
  - us: sanity-check D-PERSIST + D-CHKPT performance/bootstrapping boundaries (what must be in-kernel vs user space)


- **REF-IO-LITE** — IO-Lite (OSDI 1999 paper) — https://www.usenix.org/events/osdi99/full_papers/pai/pai.pdf  
  - key: unified buffering/caching with shareable buffer objects to eliminate redundant copies
  - why: copyless designs can make IPC/I/O fast without hidden data duplication
  - us: optional inspiration for D-IOBUF with explicit sharing constraints

- **REF-SOLARIS-DOORS** — Oracle Solaris: Doors overview (fast local RPC) — https://docs.oracle.com/en/operating-systems/solaris/oracle-solaris/11.4/prog-interfaces/doors-overview.html
  - key: fast, local RPC invoked via a transferable file descriptor (door handle), optionally attached into the filesystem
  - why: shows that “service handle you can pass” is a sticky UX for least-privilege local calls
  - us: ensure our local cap-RPC has a low-friction handle story and a clear discovery/attachment seam (D-CAPRPC, D-NS, D-ATTRFS)
- **REF-SCHED-ACTIVATIONS** — Scheduler Activations (TOCS 1992) — https://web.eecs.umich.edu/~mosharaf/Readings/Scheduler-Activations.pdf  
  - key: kernel upcalls enabling user-level scheduling without in-kernel policy bloat
  - why: example of a small interface that moves policy out of the kernel
  - us: optional inspiration for D-UPCALL if scheduling needs grow
- **REF-ECOSYSTEM** — *ECOSystem: Managing Energy as a First Class Operating System Resource* (ASPLOS 2002) — https://cseweb.ucsd.edu/~vahdat/papers/ecosystem.pdf  
  - key: unified accounting model for energy as a resource
  - why: shows how to account/price a global resource explicitly
  - us: optional extension idea for D-METER in mobile/edge profiles
- **REF-TCAPS-RTSS17** — *Temporal Capabilities: Access Control for Time* (RTSS 2017) — https://faculty.cs.gwu.edu/gparmer/publications/rtss17tcaps.pdf  
  - key: scheduling/time budgets as delegable capability authority
  - why: keeps scheduling policy out of the kernel while preserving enforceable bounds
  - us: motivates D-TCAP + PO-TCAP-ENF
- **REF-SEL4-MCS** — seL4 MCS scheduling contexts (docs) — https://docs.sel4.systems/Tutorials/mcs.html  
- **REF-SEL4-BIGLOCK-APSYS15** — *For a Microkernel, a Big Lock is Fine* (APSys 2015) — https://dl.acm.org/doi/10.1145/2797022.2797042  
  - us: candidate intermediate SMP profile (big-kernel-lock) before finer-grained concurrency proof work
- **REF-SEL4-LOCK-VERIF-ARXIV24** — *Practical Rely/Guarantee Verification of an Efficient Lock for seL4 on Multicore Architectures* (arXiv 2024) — https://arxiv.org/abs/2407.20559  
  - us: reference for staged SMP proof strategy and lock correctness obligations
  - key: separates CPU time (scheduling contexts) from threads; contexts can be donated via IPC
  - why: concrete, capability-shaped API for temporal isolation
  - us: informs D-TCAP and “time as an object” design shapes
- **REF-LINUX-IOMMUFD** — Linux IOMMUFD userspace API — https://www.kernel.org/doc/html/v6.11/userspace-api/iommufd.html  
  - key: manage IO page tables from userspace via file descriptors
  - why: shows a viable “IOMMU as delegable service” direction
  - us: supports D-DRVDOM/I-IORES-1 for DMA mapping control
- **REF-INTEL-VTD** — Intel VT-d overview — https://edc.intel.com/content/www/us/en/publications/specification-nuc12dcm-nuc12edb/intel-virtualization-technology-for-directed-i-o/  
  - key: DMA remapping + interrupt remapping concepts
  - why: core hardware assumption behind IOMMU-first DMA postures
  - us: supports D-DMA / A-DMA-1 rationale

- **REF-AMD-IOMMU** — AMD I/O Virtualization Technology (IOMMU) Specification (Rev 3.05, 2020) — https://kib.kiev.ua/x86docs/AMD/IOMMU/48882-3.05.pdf  
  - key: AMD-Vi DMA translation + protection model
  - why: primary reference for x86 DMA remapping on AMD platforms
  - us: supports D-DMA posture vocabulary and A-DMA-1 scoping for B/A profiles

- **REF-ARM-SMMUV3** — Arm System Memory Management Unit Architecture Specification (SMMUv3) — https://developer.arm.com/documentation/ihi0070/latest/  
  - key: SMMUv3 translation + isolation model for devices on Arm systems
  - why: primary reference for DMA confinement on Arm platforms
  - us: supports D-DMA posture vocabulary and A-DMA-1 scoping for Arm targets

## Peripheral security / device authorization / hotplug (optional)

- **REF-QUBES-USB** — Qubes OS USB device attach/detach guide — https://doc.qubes-os.org/en/latest/user/how-to-guides/how-to-use-usb-devices.html  
  - key: keep raw USB devices in a dedicated peripheral domain; attachment is explicit and reversible
  - why: shows a usable “deny-by-default, attach-by-intent” workflow for daily use
  - us: motivate D-DEVGUARD + portalized attach; treat auto-attach as an explicit footgun

- **REF-USBGUARD-RHEL7** — RHEL 7 Security Guide: Using USBGuard — https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/7/html/security_guide/sec-using-usbguard  
  - key: deterministic rules decide allow/block/reject for inserted USB devices
  - why: adoptable ops tooling: simple rules + explicit default target
  - us: justify CH-DEVGUARD as optional policy-as-data with first-match semantics

- **REF-USBGUARD-RULELANG** — USBGuard rule language reference — https://usbguard.github.io/documentation/rule-language  
  - key: concrete match fields and decision targets for device authorization
  - why: demonstrates the “small, scriptable surface” that makes policy usable
  - us: keep our schema small and closed-enum; preserve deterministic matching for auditability

- **REF-LINUX-USB-AUTHZ** — Linux kernel USB device authorization docs — https://docs.kernel.org/usb/authorization.html
  - key: kernel-level per-device authorization control (`authorized` / `authorized_default`) for deny-by-default hotplug
  - why: concrete precedent for “device appears ≠ device is usable” without ambient `/dev` assumptions
  - us: reference when prototyping `portal.device.*` flows and when modeling DMA-class hotplug fail-closed posture (D-DEVGUARD/D-IOLEASE)

- **REF-THUNDERSPY-REPORT** — “Breaking Thunderbolt Protocol Security” vulnerability report (Ruytenberg, 2020) — https://thunderspy.io/assets/reports/breaking-thunderbolt-security-bjorn-ruytenberg-20200417.pdf  
  - key: PCIe-tunneling ports expose DMA-class risk and can defeat naïve authorization assumptions
  - why: motivates treating some hotplug as a “bus-to-memory” threat, not just a driver/parser threat
  - us: hard-gate DMA-class hotplug on D-DMA + IOMMU posture; keep pre-OS boot exposure explicit

- **REF-THUNDERCLAP** — *Thunderclap: Exploring Vulnerabilities in Operating System IOMMU Protection via DMA from Untrustworthy Peripherals* (NDSS 2019) — https://www.ndss-symposium.org/ndss-paper/thunderclap-exploring-vulnerabilities-in-operating-system-iommu-protection-via-dma-from-untrustworthy-peripherals/  
  - key: real-world DMA attacks + common IOMMU integration pitfalls
  - why: demonstrates that “IOMMU present” is not enough without careful OS/firmware integration
  - us: supports the fail-closed D-DMA v0 posture and the need for negative tests + explicit scoping of C-ISO-2

- **REF-WIN-KDMA** — Microsoft: Kernel DMA Protection for Thunderbolt — https://learn.microsoft.com/en-us/windows/security/hardware-security/kernel-dma-protection-for-thunderbolt  
  - key: OS-level DMA protection depends on IOMMU/firmware integration and does not protect during boot
  - why: clarifies which parts are OS-enforceable vs firmware assumptions
  - us: reflect OS/firmware boundary explicitly in A-BOOT-1/A-BOOT-2/A-HW-1 and fail closed if posture can’t be met

- **REF-GOODUSB-ACSAC15** — “Defending Against Malicious USB Firmware with GoodUSB” (ACSAC 2015) — https://www.cise.ufl.edu/~butler/pubs/acsac15.pdf  
  - key: USB firmware attacks evade file-based defenses; mitigation can require device-side or protocol-level measures
  - why: reinforces “treat devices as hostile” even when storage is “clean”
  - us: default deny + mediated services; treat descriptor parsing as hostile-input and fuzz/sandbox it

## Deterministic replay (engineering + assurance utility)
- **REF-RR-ATC17** — Engineering Record And Replay For Deployability (USENIX ATC 2017) — https://www.usenix.org/system/files/conference/atc17/atc17-o_callahan.pdf  
  - key: practical record/replay constraints and design choices on stock hardware
  - why: clarifies what “deterministic replay” actually requires
  - us: informs D-RR and the boundary between recorded nondeterminism and replay scope
- **REF-RR-PROJECT** — rr project site — https://rr-project.org/  
  - key: up-to-date documentation of rr’s record/replay model and constraints  
  - why: practical grounding for what inputs must be recorded and what replay guarantees mean  
  - us: informs D-RR boundary design and the “share a replay bundle” workflow

- **REF-RR-QUEUE20** — *The Record-and-Replay Approach to Debugging* (ACM Queue 2020) — https://queue.acm.org/detail.cfm?id=3391621  
  - key: practitioner discussion of rr’s design constraints and why replay is powerful for flaky bugs
  - why: emphasizes deployability + low overhead as the main success factor
  - us: informs "debugger-first" workflow targets layered over CH-KABI/CH-LOG/CH-RR

- **REF-TTD-MS** — Time Travel Debugging overview (Microsoft docs) — https://learn.microsoft.com/en-us/windows-hardware/drivers/debuggercmds/time-travel-debugging-overview  
  - key: captures + replays executions forward/backward; "rewind" debugging session
  - why: mainstream example of time-travel debugging as a practical workflow
  - us: motivates packaging/indexing guidance for CH-RRBUNDLE and replay UX goals

- **REF-FRED-ARXIV12** — *FReD: Automated Debugging via Binary Search through a Process Lifetime* (arXiv 2012) — https://arxiv.org/abs/1212.5204  
  - key: reversible debugging + binary search through time using checkpoint/replay
  - why: shows how replay enables automated root-cause localization for "cause far from symptom" bugs
  - us: motivates optional checkpoint+index payloads in replay bundles and "search through time" tooling

- **REF-PERNOSCO-DATAFLOW** — Pernosco "dataflow" explainer (reverse dataflow over rr traces) — https://pernos.co/about/dataflow/  
  - key: omniscient-style UX that traces value provenance backward in time
  - why: shows the ecosystem value of indexed, queryable traces beyond gdb-style stepping
  - us: motivates keeping replay artifacts shareable and structured so higher-level tools can flourish

- **REF-KENDO-ASPLOS09** — *Kendo: Efficient Deterministic Multithreading in Software* (ASPLOS 2009) — https://www.cag.csail.mit.edu/~mareko/asplos073-olszewski.pdf  
  - key: "deterministic logical time" technique to impose deterministic schedules on lock-based code
  - why: evidence that concurrency replay/determinism is possible but requires explicit abstractions
  - us: informs future D-RR scope expansions (SMP/concurrency) and what might be recorded/pinned


- **REF-VM-REPLAY-VEE16** — Abstractions for Practical Virtual Machine Replay (VEE 2016) — https://users.cs.utah.edu/~regehr/papers/vee16-xentt.pdf  
  - key: argues for replay abstractions and why replay isn’t default
  - why: highlights interface requirements for replayable systems
  - us: informs whether to treat CH-LOG/CH-KABI as a replay substrate

## Crash reporting / dumps / symbolization (optional)

- **REF-CRASHPAD-OVERVIEW** — Crashpad overview design (primary design doc) — https://chromium.googlesource.com/crashpad/crashpad/+/HEAD/doc/overview_design.md
  - key: out-of-process capture and on-demand dumps; avoid doing complex work in a corrupted process
  - why: practical blueprint for ‘crash capture without footguns’
  - us: motivates CH-CRASHCAP posture and supervised crash-handler design

- **REF-SYSTEMD-COREDUMP-MAN** — systemd-coredump manual page — https://www.freedesktop.org/software/systemd/man/systemd-coredump.html
  - key: standardized capture/retention pipeline for crash dumps with journal integration
  - why: demonstrates that crash capture is an ops workflow, not just a debugger feature
  - us: informs retention/rate-limit posture for CH-CRASHCAP payloads

- **REF-MS-MINIDUMP-FILES** — Minidump files overview (Microsoft docs) — https://learn.microsoft.com/en-us/windows/win32/debug/minidump-files
  - key: minidumps are smaller than full dumps but support basic debugging; require binaries + symbols
  - why: mainstream precedent for ‘high signal per byte’ crash artifacts
  - us: justifies recommending minidump-style payloads for crash capsules

- **REF-MS-MINIDUMP-HEADER** — MINIDUMP_HEADER structure reference — https://learn.microsoft.com/en-us/windows/win32/api/minidumpapiset/ns-minidumpapiset-minidump_header
  - why: concrete format anchor for minidump identification/versioning
  - us: supports tooling validation and format tagging in CH-CRASHCAP

- **REF-BREAKPAD-SYMBOLFILES** — Breakpad symbol file format (primary doc) — https://chromium.googlesource.com/breakpad/breakpad/+/master/docs/symbol_files.md
  - key: platform-independent ASCII debug symbol format consumed by minidump processors
  - why: demonstrates a pragmatic ‘debug artifacts as separate files’ ecosystem
  - us: optional debug artifact store formats for symbolization pipelines

- **REF-ELF-BUILDID** — ELF build-id note (`.note.gnu.build-id`) (man7) — https://man7.org/linux/man-pages/man5/elf.5.html
  - key: embedded identifier that uniquely identifies the ELF image contents
  - why: build IDs make dumps symbolizable without relying on paths
  - us: motivates requiring content identity for shipped modules

- **REF-LD-BUILDID** — GNU ld `--build-id` option docs — https://sourceware.org/binutils/docs/ld.html
  - key: requests creation of `.note.gnu.build-id` for linked files
  - why: concrete toolchain knob for enabling build IDs
  - us: supports build pipeline requirements for crash symbolization

- **REF-DEBUGINFOD** — debuginfod (binutils docs) — https://sourceware.org/binutils/docs/binutils/debuginfod.html
  - key: serves ELF/DWARF debugging resources indexed by build-id over HTTP
  - why: proven pattern for ‘fetch symbols by build-id’
  - us: motivates an optional policy-gated debuginfo fetch service for our debug store

- **REF-ELFUTILS-DEBUGINFOD** — elfutils debuginfod services — https://sourceware.org/elfutils/Debuginfod.html
  - key: practical deployment guidance for private servers + upstream federation
  - why: shows how teams actually run this in practice
  - us: informs our ‘local first, optional upstream’ debug artifact posture

## Wire formats / signatures / canonicalization
- **REF-CBOR-RFC8949** — CBOR (RFC 8949) — https://www.rfc-editor.org/rfc/rfc8949.html  
  - key: compact, extensible binary format with canonicalization guidance
  - why: total, deterministic decode is a security primitive
  - us: candidate baseline for CH-* payloads under D-ENC
- **REF-COSE-RFC9052** — COSE (RFC 9052) — https://www.rfc-editor.org/rfc/rfc9052.html  
  - key: standard envelopes for signatures/MAC/encryption over CBOR
  - why: avoids bespoke signing formats for boot/config/provenance
  - us: candidate for signing CH-BOOT/CH-CFG without inventing new crypto encodings
- **REF-COSE-RFC9053** — COSE algorithms (RFC 9053) — https://www.rfc-editor.org/info/rfc9053  
  - key: initial algorithm registry for COSE (obsoletes RFC 8152 alongside RFC 9052)
  - why: keeps “what algorithms are we assuming?” pinned to a stable primary source
  - us: reference point for any COSE-based container profiles used by attestation evidence (D-ATTEST)

- **REF-COSEKEYTHUMBPRINT-RFC9679** — RFC 9679: COSE Key Thumbprint — https://www.rfc-editor.org/info/rfc9679  
  - key: canonical thumbprint over essential COSE_Key parameters; SHA-256 is mandatory support and the result can be used as a compact key identifier
  - why: avoids representation-dependent raw-key vs digest aliases while staying explicit about the thumbprint algorithm
  - us: basis for the D-NAMECERT principal-profile boundary, which freezes admitted `PrincipalRef` identities to `kind="key_hash"`, `alg="cose_key_thumbprint_sha256"`, exact 32-byte thumbprints, and rejects raw `kind="pubkey"` admissions in Phase 1
- **REF-EDDSA-RFC8032** — RFC 8032: Edwards-Curve Digital Signature Algorithm (EdDSA) — https://www.rfc-editor.org/info/rfc8032  
  - key: specifies EdDSA, including Ed25519 / Ed448, and notes deterministic signing/nonbatch verification behavior for the algorithm family
  - why: lets us pin one small direct-signature profile without inventing an archive-local signature scheme
  - us: basis for the D-NAMECERT signature-profile boundary, which freezes admitted bundles to one inline direct `sig.alg="ed25519"` signature over canonical unsigned bundle bytes and declines wrapper-only/keyless/multisignature admission semantics
- **REF-JCS-RFC8785** — JSON Canonicalization Scheme (RFC 8785) — https://www.rfc-editor.org/rfc/rfc8785.html  
  - key: canonical, hashable JSON serialization
  - why: enables deterministic signing/hashing when JSON is used for authoring or interchange
  - us: optional authoring form that must be normalized/transcoded before producing canonical CH-* bytes

- **REF-IPLD-DAG-CBOR** — IPLD DAG-CBOR spec — https://ipld.io/specs/codecs/dag-cbor/spec/
  - key: CBOR profile that rejects non-deterministic encodings to ensure hash-consistent representations
  - why: real-world precedent for “reject non-canonical CBOR” when hashes are a primary binding primitive
  - us: supports D-ENC posture: canonical bytes are deterministic CBOR for `digest(CH-XYZ vN)`

- **REF-WEBAUTHN-3** — W3C WebAuthn Level 3 — https://www.w3.org/TR/webauthn-3/
  - key: requires CTAP2 canonical CBOR encoding form for CBOR messages in conforming implementations
  - why: shows canonical CBOR enforcement in security-critical, widely-deployed stacks
  - us: supports D-ENC posture: deterministic encoding + duplicate-key rejection are interoperability requirements, not niceties
  - key: authenticators are scoped to a relying party and operations require user consent / prove user presence for a concrete authentication ceremony
  - why: useful precedent that human verification should be challenge-bound and scoped, not a reusable ambient grant
  - us: supports D-VOLITION posture: one exact action + one exact summary, not wildcard or batch approval semantics


## Capability systems (pragmatic + hardware)
- **REF-CAPSICUM** — Capsicum: Practical Capabilities for UNIX — https://www.usenix.org/legacy/event/sec10/tech/full_papers/Watson.pdf  
  - key: retrofit capability mode into a Unix-like API surface with minimal kernel additions
  - why: shows how "ambient namespace" is where authority sneaks in
  - us: motivate explicit view/name objects rather than implicit global namespaces
- **REF-FREEBSD-OPEN-CAPMODE** — FreeBSD `open(2)` manual page (capability-mode path restrictions) — https://man.freebsd.org/cgi/man.cgi?query=open&sektion=2  
  - key: in capability mode, `open()` is disallowed and `openat()` paths must stay strictly relative (no absolute path, no `..`, no `AT_FDCWD`)
  - why: concrete primary-source precedent that path reachability is authority, not harmless convenience
  - us: justify a capshell launch posture that treats host absolute-path visibility as ambient authority rather than a portable baseline

- **REF-OPENGROUP-EXEC** — The Open Group Base Specifications: `exec*` functions — https://pubs.opengroup.org/onlinepubs/9799919799/functions/exec.html
  - key: `execlp`/`execvp` PATH search semantics (filename without `/` consults ambient PATH)
  - why: executable choice becomes environment- and host-dependent
  - us: justify capshell posture: explicit, unique exec selector; no ambient PATH resolution
- **REF-OPENGROUP-FCNTL** — The Open Group Base Specifications: `fcntl()` — https://pubs.opengroup.org/onlinepubs/9699919799/functions/fcntl.html
  - key: `FD_CLOEXEC` controls whether a descriptor remains open across exec, and `F_DUPFD_CLOEXEC` exists to avoid non-atomic close-on-exec races
  - why: shows that close-on-exec hygiene is an ambient process-state convention, not a reviewed exact-child-table authority surface
  - us: supports the capshell handle-table posture: exact child authority must come from explicit CH-STDIO / CH-FDSET bindings rather than surviving parent descriptors
- **REF-MAN7-OPEN** — Linux manual page: `open(2)` — https://man7.org/linux/man-pages/man2/open.2.html
  - key: `O_CLOEXEC` exists to atomically set close-on-exec on newly opened descriptors because post-open `fcntl()` is race-prone in multithreaded launchers
  - why: exact child descriptor state cannot safely depend on best-effort descriptor hygiene in the parent process
  - us: supports a fail-closed capshell posture where wrappers construct the child table exactly instead of trusting ambient descriptor flags
- **REF-MAN7-EXECVE** — Linux manual page: `execve(2)` — https://man7.org/linux/man-pages/man2/execve.2.html
  - key: path-based exec plus interpreter/path-related failure modes (`ENOENT`, `ENOEXEC`)
  - why: explicit-exec and script-entry posture need the actual `execve` contract, not folklore
  - us: supports the capshell boundary that keeps executable selection/interpreter choice explicit and fail-closed
- **REF-BUSYBOX-FAQ** — BusyBox FAQ / design notes — https://busybox.net/FAQ.html
  - key: BusyBox explicitly documents that the binary can act like different programs depending on the name used to invoke it, and its startup path sets `applet_name` from `argv[0]` to choose the applet implementation
  - why: concrete primary-source example that invocation/program-name text can be a real startup mode selector
  - us: supports the capshell `argv[0]` posture: reviewed automation should not rely on caller-/wrapper-controlled mode-by-name behavior on the generic seam
- **REF-MAN7-FEXECVE** — Linux manual page: `fexecve(3)` — https://man7.org/linux/man-pages/man3/fexecve.3.html
  - key: execute via an already-open file descriptor rather than a pathname; notes that this avoids the checksum-then-`execve(path)` rename/symlink exchange race
  - why: primary-source precedent for exact-object launch semantics
  - us: supports the capshell executable-object posture: the reviewed exec selector must end at one exact bound object, not a late reopen by name
- **REF-MAN7-EXECVEAT** — Linux manual page: `execveat(2)` — https://man7.org/linux/man-pages/man2/execveat.2.html
- **REF-MAN7-CGROUPS** — Linux manual page: `cgroups(7)` — https://man7.org/linux/man-pages/man7/cgroups.7.html
  - key: child processes inherit parent cgroup membership across `fork()`, and cgroup membership is preserved across `execve()`
  - why: hidden launcher/session cgroup state can silently change child CPU/memory/IO/process-count behavior even when argv/env/cwd are explicit
  - us: supports the capshell resource-envelope posture: reviewed launch should stay on one default compartment envelope rather than on inherited parent shell/session cgroup narrowing
- **REF-MAN7-PERSONALITY** — Linux manual page: `personality(2)` — https://man7.org/linux/man-pages/man2/personality.2.html
- **REF-MAN7-SETARCH** — Linux manual page: `setarch(8)` — https://man7.org/linux/man-pages/man8/setarch.8.html
- **REF-MAN7-SYSTEMD-EXEC** — Linux manual page: `systemd.exec(5)` — https://man7.org/linux/man-pages/man5/systemd.exec.5.html
  - key: service managers can set `SELinuxContext=`, `AppArmorProfile=`, and `SmackProcessLabel=` on executed processes, overriding or selecting execution confinement for the child
  - why: shows that execution labels/profiles are a real launch boundary rather than local wrapper trivia
  - us: supports a capshell posture that treats service-manager confinement selection as ambient unless the runtime normalizes launch to one default compartment baseline
- **REF-MAN7-GETEXECCON** — Linux manual page: `getexeccon(3)` / `setexeccon(3)` — https://man7.org/linux/man-pages/man3/getexeccon.3.html
  - key: `setexeccon()` sets the context used for the next `execve(2)` call and is automatically reset after the next exec
  - why: demonstrates that exec-label selection is explicit launch state, not folklore
  - us: supports the capshell confinement label/profile posture: reviewed launch must not depend on wrapper-selected exec contexts
- **REF-MAN7-PROC-PID-ATTR** — Linux manual page: `proc_pid_attr(5)` — https://man7.org/linux/man-pages/man5/proc_pid_attr.5.html
  - key: `/proc/pid/attr/exec` represents the security attributes assigned on a subsequent `execve(2)`; SELinux uses it for role/domain transitions
  - why: shows that next-exec security labels are concrete inherited launch context
  - us: supports keeping execution-label/profile state out of ambient reviewed capshell meaning
- **REF-UBUNTU-AA-CHANGE-PROFILE** — Ubuntu manual page: `aa_change_profile(2)` / `aa_change_onexec(2)` — https://manpages.ubuntu.com/manpages/xenial/man2/aa_change_profile.2.html
  - key: AppArmor can delay profile changes until the next exec, and delayed change-on-exec takes precedence over exec transition rules within the current profile
  - why: shows that wrapper or helper code can preload exec-time confinement changes that are not visible in argv/env/cwd alone
  - us: supports a capshell posture that treats AppArmor change-on-exec state as ambient unless the membrane normalizes launch to the compartment default profile
  - key: `AT_EMPTY_PATH` executes the file referred to by `dirfd`, including `O_PATH` handles
  - why: concrete kernel primitive for exact-object launch without `/proc` tricks
  - us: supports the capshell executable-object posture and exact-byte staging fallback
- **REF-MAN7-PR-SET-PDEATHSIG** — Linux manual page: `PR_SET_PDEATHSIG(2const)` — https://man7.org/linux/man-pages/man2/pr_set_pdeathsig.2const.html
  - key: a process can request a parent-death signal that is delivered when the parent thread dies and again when ancestor subreapers later die; the setting is preserved across ordinary `execve(2)`
  - why: launcher/session liveness can silently become child lifecycle policy even when argv/env/cwd are explicit
  - us: supports a capshell posture that keeps reviewed child lifetime independent of transient launcher death unless a future explicit lifetime seam exists
- **REF-MAN7-PR-SET-DUMPABLE** — Linux manual page: `PR_SET_DUMPABLE(2const)` — https://man7.org/linux/man-pages/man2/pr_set_dumpable.2const.html
  - key: the `dumpable` attribute normally defaults to `1`; setting it to `0` blocks ordinary `ptrace(PTRACE_ATTACH, ...)` and affects ownership of `/proc/pid` files
  - why: same-principal peer inspection is a real process-state boundary, not just debugger folklore
  - us: supports a capshell launch posture that treats dumpability / procfs visibility as ambient unless the membrane pins a non-inspectable baseline
- **REF-MAN7-PTRACE** — Linux manual page: `ptrace(2)` — https://man7.org/linux/man-pages/man2/ptrace.2.html
  - key: `ptrace()` lets one process observe and control another, and examine and change its memory and registers
  - why: ambient debugger attachability is ambient authority over live process state
  - us: supports the capshell peer-inspection posture: reviewed automation must not silently inherit same-principal tracing/debugging channels
- **REF-MAN7-CREDENTIALS** — Linux manual page: `credentials(7)` — https://man7.org/linux/man-pages/man7/credentials.7.html
  - key: forked children inherit user/group IDs, and `execve(2)` preserves real user/group IDs plus supplementary groups by default
  - why: shows that ambient caller identity is a real inherited baseline, not an implementation accident
  - us: supports a capshell posture that treats caller identity as ambient unless the membrane pins a fixed executor identity
- **REF-MAN7-PATH-RESOLUTION** — Linux manual page: `path_resolution(7)` — https://man7.org/linux/man-pages/man7/path_resolution.7.html
  - key: permission checks consult effective UID and also supplementary groups when resolving filesystem access
  - why: supplementary-group state materially changes launch authority outcomes
  - us: supports forbidding ambient group-membership widening as reviewed capshell workflow input
- **REF-MAN7-PR-SET-NNP** — Linux manual page: `PR_SET_NO_NEW_PRIVS(2const)` — https://man7.org/linux/man-pages/man2/PR_SET_NO_NEW_PRIVS.2const.html
  - key: `no_new_privs` promises that `execve(2)` will not grant privileges that were unavailable without the exec, rendering setuid/setgid bits and file capabilities non-functional
  - why: shows that a one-way no-privilege-gain boundary is implementable at launch rather than aspirational
  - us: supports a fail-closed capshell posture where wrappers use no-new-privileges controls when the platform provides them
- **REF-MAN7-SECCOMP** — Linux manual page: `seccomp(2)` — https://man7.org/linux/man-pages/man2/seccomp.2.html
  - key: `seccomp()` filters are preserved across `execve(2)` and child processes can inherit them; further filters may be added, which makes wrapper-installed syscall filtering a one-way hidden launch constraint unless the membrane prevents it
  - why: shows that syscall-admission policy is real inherited launch context, not just local sandboxing trivia
  - us: supports a capshell posture that treats seccomp / service-manager syscall filters as ambient unless the runtime normalizes launch to the compartment default baseline
- **REF-KERNEL-SECCOMP** — Linux kernel documentation: Seccomp BPF — https://docs.kernel.org/userspace-api/seccomp_filter.html
  - key: seccomp filters constrain child processes to the same filters/system-call ABI when `fork`/`clone` and `execve` are allowed; policy is for minimizing exposed kernel surface, not a generic workflow description language
  - why: reinforces that inherited seccomp is a real execution-context boundary and that logical behavior still needs other explicit controls
  - us: supports a capshell posture that keeps syscall-admission policy out of ambient launch meaning while allowing compartment-level hardening to remain provider-local
- **REF-MAN7-CAPABILITIES** — Linux manual page: `capabilities(7)` — https://man7.org/linux/man-pages/man7/capabilities.7.html
  - key: ambient capabilities are preserved across exec of non-privileged programs and are added to the permitted/effective sets at exec time
  - why: capability state can silently widen child authority even when argv/env/cwd are explicit
  - us: justify treating ambient capability carry-over as forbidden launch context for D-CAPSHELL v0
- **REF-MAN7-SOCKET** — Linux manual page: `socket(2)` — https://man7.org/linux/man-pages/man2/socket.2.html
  - key: `socket()` creates an endpoint for communication in a named address family and chooses the communication semantics for subsequent networking operations
  - why: raw socket construction is itself authority, not inert child process state
  - us: supports keeping `capshell.exec` off ambient socket constructors unless networking is explicitly mediated
- **REF-MAN7-CONNECT** — Linux manual page: `connect(2)` — https://man7.org/linux/man-pages/man2/connect.2.html
  - key: `connect()` attaches a socket to a specific remote address, and the address format depends on the socket address family
  - why: outbound network reachability is an explicit authority exercise, not a harmless launch default
  - us: supports routing reviewed network behavior through D-NETLEASE rather than inherited host stack defaults
- **REF-MAN7-GETADDRINFO** — Linux manual page: `getaddrinfo(3)` — https://man7.org/linux/man-pages/man3/getaddrinfo.3.html
  - key: `getaddrinfo()` returns Internet addresses that may then be used in `bind(2)` or `connect(2)`
  - why: name resolution is part of the authority path to network reachability, not merely string formatting
  - us: supports keeping DNS / resolver behavior off ambient capshell launch defaults and on explicit portal-bound leases
- **REF-MAN7-RESOLV-CONF** — Linux manual page: `resolv.conf(5)` — https://man7.org/linux/man-pages/man5/resolv.conf.5.html
  - key: resolver behavior is configured through resolver state such as `/etc/resolv.conf`, and NSS-facing interfaces like `getaddrinfo(3)` are affected by that DNS resolver configuration
  - why: host-global resolver configuration can silently change reviewed workflow behavior if inherited as launch baseline
  - us: supports declining ambient DNS / resolver defaults for D-CAPSHELL v0 and keeping resolver choice explicit on CH-NETLEASE
- **REF-MAN7-UNIX** — Linux manual page: `unix(7)` — https://man7.org/linux/man-pages/man7/unix.7.html
  - key: AF_UNIX / AF_LOCAL sockets can be unnamed, filesystem-path based, or Linux abstract-namespace sockets independent of the filesystem
  - why: machine-local IPC reachability is itself authority, not inert launch context
  - us: supports declining ambient AF_UNIX namespace reachability as part of D-CAPSHELL launch semantics
- **REF-DBUS-SPECIFICATION** — DBus Specification — https://dbus.freedesktop.org/doc/dbus-specification.html
  - key: the login-session message bus address is given by `DBUS_SESSION_BUS_ADDRESS`; if unset, implementations may discover/derive bus attachment by convention, and the spec also defines a distinct system bus
  - why: session/system bus defaults are machine-local authority conventions, not neutral child process state
  - us: supports declining ambient session/system bus attachment semantics for D-CAPSHELL Phase 1
- **REF-DBUS-LAUNCH** — `dbus-launch(1)` — https://dbus.freedesktop.org/doc/dbus-launch.1.html
  - key: explicit session-bus addresses may include `autolaunch:` fallback, which spawns or discovers a bus by convention
  - why: autolaunch behavior silently turns omission into bus reachability
  - us: supports treating bus autolaunch as forbidden ambient launch context for D-CAPSHELL v0
- **REF-MAN7-SIGPROCMASK** — Linux manual page: `sigprocmask(2)` — https://man7.org/linux/man-pages/man2/sigprocmask.2.html
  - key: a child inherits the parent's signal mask, and the signal mask is preserved across `execve(2)`
  - why: blocked-signal state can silently change reviewed workflow behavior even when argv/env/cwd are explicit
  - us: justify a capshell launch posture that normalizes to an empty blocked-signal mask rather than inheriting shell/session state
- **REF-MAN7-SIGACTION** — Linux manual page: `sigaction(2)` — https://man7.org/linux/man-pages/man2/sigaction.2.html
  - key: during `execve(2)`, handled signal dispositions reset to default but ignored dispositions are left unchanged
  - why: shell trap/ignore state can leak across the launch boundary unless the runner explicitly restores defaults
  - us: justify a capshell launch posture that declines inherited ignored-signal baseline and resets catchable signals to default before exec
- **REF-MAN7-POSIX-SPAWN** — Linux manual page: `posix_spawn(3)` / POSIX semantics — https://man7.org/linux/man-pages/man3/posix_spawn.3.html
  - key: spawn file actions exist to shape the child's descriptor table explicitly rather than inheriting ambient parent descriptor state
  - why: launch descriptor construction can be explicit and bounded without widening the workflow surface into a generic inheritance knob
  - us: supports the capshell handle-table posture: exact child bindings are implementable without reviewing ambient `pass_fds`-style policy
  - key: spawn attributes can explicitly set the child signal mask/default dispositions; otherwise the child inherits the parent's signal state
  - why: shows that normalization is an implementable launch boundary choice rather than a speculative ideal
  - us: supports a fail-closed capshell posture where wrappers normalize signal state or reject when the runtime cannot guarantee it
- **REF-MS-CREATEPROCESS** — Microsoft docs: `CreateProcessW` — https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw
  - key: `lpApplicationName` binds the module directly, but `NULL` falls back to first-token parsing and search-path behavior; batch files require an explicit command interpreter
  - why: shows Win32 launch is name/path-based by default and needs explicit module binding to avoid ambiguous retargeting
  - us: supports the capshell executable-object, script-entry, credential-baseline, and handle-table postures
- **REF-MS-CREATEPROCESSASUSER** — Microsoft docs: `CreateProcessAsUserW` — https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessasuserw
  - key: launching under a different token requires a separate explicit API and token rights
  - why: credential selection is a distinct authority surface, not a harmless launch default
  - us: supports keeping Phase 1 off any hidden per-step token-selection seam and requiring explicit future design if cross-identity launch is needed
- **REF-MS-UPDATETHREADATTR** — Microsoft docs: `UpdateProcThreadAttribute` / `PROC_THREAD_ATTRIBUTE_HANDLE_LIST` — https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute
  - key: Windows provides an explicit handle allowlist for child-process inheritance
  - why: shows that exact child handle-table construction is implementable on handle-table runtimes too
  - us: supports the capshell handle-table posture: wrappers should use an exact allowlist or fail closed, not ambient inheritance
- **REF-OPENGROUP-ENV** — The Open Group Base Specifications: `env` utility — https://pubs.opengroup.org/onlinepubs/9699919799/utilities/env.html
  - key: `env` invokes the named utility using PATH search rules unless a concrete pathname is given
  - why: `#!/usr/bin/env <tool>` quietly reintroduces ambient lookup through a familiar portability idiom
  - us: Phase 1 capshell must treat script interpreter choice as explicit authority, not as a header-driven PATH search
- **REF-LINUX-BINFMT-MISC** — Linux kernel docs: binfmt_misc — https://docs.kernel.org/admin-guide/binfmt-misc.html
  - key: interpreter helpers should not look in PATH; the kernel docs call PATH lookup a security hazard
  - why: strong primary-source warning that interpreter indirection is an authority seam, not harmless convenience
  - us: supports a script-entry posture where capshell ignores shebang/env lookup unless a future explicit policy seam is added
- **REF-OPENGROUP-SHELL-ENV** — The Open Group Shell Command Language: `ENV` startup file semantics — https://pubs.opengroup.org/onlinepubs/9799919799/utilities/V3_chap02.html
  - key: shell startup can execute commands from the `ENV` variable in the current shell environment
  - why: a child environment can quietly choose startup code even when the interpreter path is explicit
  - us: supports a capshell posture that rejects shell startup env hooks instead of treating them as harmless data
- **REF-BASH-STARTUP** — GNU Bash manual: startup files — https://www.gnu.org/s/bash/manual/html_node/Bash-Startup-Files.html
  - key: bash may read `/etc/profile`, `~/.bash_profile`, `~/.profile`, or `~/.bashrc` depending on invocation mode
  - why: shell startup semantics commonly discover executable code from ambient filesystem locations before the user does any explicit work
  - us: supports an integrated-capshell posture that declines implicit rc/profile loading in Phase 1
- **REF-DIRENV** — direnv documentation — https://direnv.net/
  - key: direnv loads `.envrc` (and optionally `.env`) based on the current directory before each prompt
  - why: per-directory shell hooks are an ambient code-loading channel tied to cwd/prompt transitions rather than explicit reviewed actions
  - us: supports a capshell posture where prompt/cwd changes are not hidden code-loading events
- **REF-OPENGROUP-SHELL-CMDLANG** — The Open Group Shell Command Language — https://pubs.opengroup.org/onlinepubs/9799919799/utilities/V3_chap02.html
  - key: the shell language performs word expansions and turns command text into fields/pathnames/commands; `sh` executes commands read from a command line string, standard input, or a file
  - why: a generic “command string” is not inert data; it is a request to invoke a second parser with expansion semantics
  - us: supports keeping `capshell.exec` on structured CH-ARGV rather than adding a hidden shell-language plane
- **REF-OPENGROUP-WORDEXP** — The Open Group `wordexp()` function — https://pubs.opengroup.org/onlinepubs/9699919799/functions/wordexp.html
  - key: `wordexp()` exists specifically to perform the shell's word expansions on text obtained from a user
  - why: shell-style expansion is its own API surface and should not accidentally appear inside a capability runner
  - us: reinforces that argv review and shell-command parsing are different surfaces and must stay separate in D-CAPSHELL
- **REF-BASH-SHELL-EXPANSIONS** — GNU Bash manual: shell expansions — https://www.gnu.org/software/bash/manual/html_node/Shell-Expansions.html
  - key: bash performs brace expansion, tilde expansion, parameter/variable expansion, command substitution, arithmetic expansion, word splitting, filename expansion, and quote removal before execution
  - why: front-end shell convenience can synthesize additional argv words or pathnames from shell state and filesystem enumeration even when the runner itself is capability-safe
  - us: supports an exact-token capshell posture where such expansion does not happen before CH-ARGV review/binding
- **REF-BASH-JOB-CONTROL** — GNU Bash manual: Job Control Basics — https://www.gnu.org/s/bash/manual/html_node/Job-Control-Basics.html
  - key: shell job control is built around foreground/background jobs, suspend/resume, and an interactive interface supplied jointly by the terminal driver and the shell
  - why: foreground/background shell control is a distinct stateful coordination surface, not just text I/O styling
  - us: supports keeping D-CAPSHELL v0 off a portable job-control plane
- **REF-BASH-SIGNALS** — GNU Bash manual: Signals — https://www.gnu.org/s/bash/manual/html_node/Signals.html
  - key: interactive Bash handles `SIGINT`/`SIGTERM`/`SIGHUP` with shell-specific policy, and may resend `SIGHUP` to jobs on exit
  - why: interrupt and hangup behavior in real shells is policy-rich shell/runtime behavior, not a neutral child-launch detail
  - us: supports keeping D-CAPSHELL interruption on explicit request/workflow seams instead of importing host shell signal lore as portable authority
- **REF-OPENGROUP-TERMINAL-IFACE** — The Open Group Base Definitions: General Terminal Interface — https://pubs.opengroup.org/onlinepubs/009695299/basedefs/xbd_chap11.html
  - key: the controlling terminal interacts with foreground/background process groups and can generate or gate signals such as `SIGINT`, `SIGTSTP`, `SIGTTIN`, and `SIGTTOU`
  - why: terminal/session semantics carry process-control consequences that should not quietly appear inside an execution-pack runner
  - us: supports declining implicit PTY / controlling-terminal / job-control semantics in D-CAPSHELL v0
- **REF-OPENGROUP-SH** — The Open Group `sh` utility — https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sh.html
  - key: POSIX `sh` specifies signal-facing behavior such as what happens when the shell receives `SIGINT`
  - why: shell interrupt behavior is part of the shell contract and should not be silently imported as portable capshell semantics
  - us: supports pinning D-CAPSHELL v0 to explicit request/workflow cancellation rather than a hidden portable signal plane
- **REF-MAN7-SCHED** — Linux `sched(7)` manual page — https://man7.org/linux/man-pages/man7/sched.7.html
  - key: the nice value influences CPU scheduling decisions, and real-time scheduling policies/classes are distinct from ordinary time-sharing execution
  - why: launch-time scheduler class and nice value are process/thread state, not inert metadata
  - us: supports pinning D-CAPSHELL to a default non-real-time launch baseline rather than inheriting shell/session CPU-scheduling bias
- **REF-MAN7-SETPRIORITY** — Linux `getpriority(2)` / `setpriority(2)` manual page — https://man7.org/linux/man-pages/man2/setpriority.2.html
  - key: the process scheduling priority (nice value) is preserved across `execve(2)`
  - why: inherited nice state can silently change reviewed workflow behavior unless the launch boundary normalizes it on purpose
  - us: supports declining ambient `nice` inheritance in D-CAPSHELL Phase 1
- **REF-MAN7-SCHED-SETSCHEDULER** — Linux `sched_setscheduler(2)` manual page — https://man7.org/linux/man-pages/man2/sched_setscheduler.2.html
  - key: scheduler policy/parameters are explicit thread attributes, and Linux provides reset-on-fork only because privileged scheduling policies otherwise inherit into children
  - why: scheduler class/priority is another hidden launch-state seam that should not ride along with a reviewed execution pack
  - us: supports normalizing D-CAPSHELL launch to a default non-real-time policy instead of inheriting parent shell/session scheduler state
- **REF-MAN7-SCHED-AFFINITY** — Linux `sched_setaffinity(2)` manual page — https://man7.org/linux/man-pages/man2/sched_setaffinity.2.html
  - key: a child created via `fork(2)` inherits its parent's CPU-affinity mask, and the affinity mask is preserved across `execve(2)`
  - why: inherited CPU masks can silently change reviewed workflow behavior unless the launch boundary normalizes them on purpose
  - us: supports declining ambient CPU-affinity inheritance in D-CAPSHELL Phase 1
- **REF-MAN7-TASKSET** — Linux `taskset(1)` manual page — https://man7.org/linux/man-pages/man1/taskset.1.html
  - key: `taskset` can launch a new command with a chosen CPU affinity mask
  - why: shell-visible wrapper tooling makes affinity inheritance a practical drift source, not a theoretical one
  - us: supports treating CPU-affinity / placement as a real launch-boundary seam under D-CAPSHELL
- **REF-MAN7-SYSTEMD-SYSTEM-CONF** — `systemd-system.conf(5)` manual page — https://man7.org/linux/man-pages/man5/systemd-system.conf.5.html
  - key: `CPUAffinity=` configures the service manager's CPU affinity and the default CPU affinity for all forked-off processes
  - why: service-manager defaults can quietly become inherited launch meaning even when workflow bytes never mention placement
  - us: supports declining inherited service-manager CPU-affinity defaults in D-CAPSHELL Phase 1
- **REF-MS-ASSIGNPROCESSTOJOBOBJECT** — Microsoft docs: `AssignProcessToJobObject` — https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject
  - key: if a process is associated with a job, all child processes it creates are associated with that job by default (unless an allowed breakaway path is used)
  - why: launcher-local job membership can silently become child lifetime policy
  - us: supports a capshell posture that declines inherited launcher-owned Job Object coupling as reviewed workflow meaning
- **REF-MS-JOB-OBJECTS** — Microsoft docs: Job Objects — https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects
  - key: `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` causes all associated processes to terminate when the last job handle closes, including nested-job hierarchies
  - why: wrapper/service launcher liveness can become hidden child teardown policy on Win32 runtimes
  - us: supports keeping D-CAPSHELL off ambient kill-on-launcher-exit coupling and requiring fail-closed behavior when runtimes cannot avoid it
- **REF-MS-SETPROCESSAFFINITYMASK** — Microsoft docs: `SetProcessAffinityMask` — https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-setprocessaffinitymask
  - key: process affinity is inherited by child processes or newly instantiated local processes
  - why: Windows process launch can also carry ambient core pinning across a reviewed boundary unless the runner corrects it
  - us: supports a cross-platform posture where capshell rejects inherited process-affinity masks as reviewed meaning
- **REF-LDSO-MAN7** — Linux `ld.so(8)` manual page — https://man7.org/linux/man-pages/man8/ld.so.8.html
  - key: the ELF dynamic linker uses the program's `.interp` entry and can resolve shared-library dependencies via `DT_RPATH` / `DT_RUNPATH`, `/etc/ld.so.cache`, and trusted default directories
  - why: exact main-binary binding is not enough if startup native dependencies still come from ambient host search state
  - us: supports pinning D-CAPSHELL to an exact startup native code closure rather than ambient loader search at launch, and also supports rejecting loader-search/injection env hooks in CH-ENV v0
- **REF-MAN7-DLOPEN** — Linux manual page: `dlopen(3)` — https://man7.org/linux/man-pages/man3/dlopen.3.html
  - key: native dependency loading can recurse through `DT_RPATH` / `DT_RUNPATH`, `LD_LIBRARY_PATH`, `/etc/ld.so.cache`, and default library directories
  - why: startup shared-library resolution is a real authority seam, not inert implementation detail
  - us: supports treating startup native dependency closure as explicit launch meaning under D-CAPSHELL
- **REF-MS-DLL-SEARCHORDER** — Microsoft docs: Dynamic-link library search order — https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order
  - key: dependent DLL resolution can consult redirection, manifests, the executable folder, system folders, the current directory, and `PATH`, and parent-process DLL-directory state can affect the child
  - why: exact `CreateProcess` module selection is not enough if dependent native code still comes from ambient search order
  - us: supports pinning D-CAPSHELL to an exact startup native code closure rather than ordinary DLL search semantics
- **REF-MS-SETDEFAULTDLLDIRECTORIES** — Microsoft docs: `SetDefaultDllDirectories` — https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-setdefaultdlldirectories
  - key: a process can replace standard DLL search with an explicit, smaller directory set using `LOAD_LIBRARY_SEARCH_*` flags
  - why: Windows needs an explicit process-local mechanism if we want exact staged closure roots instead of standard DLL search order
  - us: supports a fail-closed compat story where staged closure roots are explicit and ambient DLL search remains out of reviewed meaning
- **REF-BASH-FUNCIMPORT** — GNU Bash Reference Manual (`--enable-function-import`) — https://www.gnu.org/s/bash/manual/bash.html
  - key: bash can import function definitions from the environment when function import is enabled
  - why: environment bytes can smuggle executable shell behavior into an otherwise explicit launch
  - us: supports rejecting `BASH_FUNC_*`-style startup/function-import hooks in CH-ENV v0
- **REF-PYTHON-CMDLINE** — Python docs: command line and environment — https://docs.python.org/3/using/cmdline.html
  - key: CPython can execute code from a script path, `-c command`, `-m module`, or `-` / stdin, and isolated mode `-I` narrows ambient import-path/env influence
  - why: explicit interpreters often have multiple code-entry forms beyond `argv[0]`, so quarantine cannot only gate the main executable object
  - us: supports a code-input boundary where quarantined bound objects cannot be laundered into `stdin` / `-c` / module entry under a cleared interpreter
- **REF-NODE-CLI** — Node.js docs: command-line API — https://nodejs.org/api/cli.html
  - key: Node accepts multiple initial code-entry forms including a program entry point, `-e "script"`, and `-` / stdin
  - why: modern runtimes commonly execute code from non-file entry positions, so risky-code gating must cover more than the main executable path
  - us: supports a quarantine boundary that treats bound code-bearing input objects as upstream of the same clear/override gate even when bytes are restaged into eval/stdin entry forms
- **REF-OPENGROUP-ENVVARS** — The Open Group Base Definitions: Environment Variables — https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html
  - key: standard variables such as `HOME`, `PWD`, `OLDPWD`, `TMPDIR`, `LOGNAME`, `LANG`, `LC_*`, `TERM`, and `TZ` affect multiple utilities, functions, and applications
  - why: launcher-injected convenience vars are not inert decoration; they can steer config lookup, cwd reporting, locale/timezone behavior, and terminal-facing behavior across many programs
  - us: supports pinning CH-ENV to exact reviewed entries rather than appending a hidden compatibility baseline under D-CAPSHELL
- **REF-OPENAT2** — Linux `openat2(2)` manual page — https://www.kernel.org/doc/man-pages/online/pages/man2/openat2.2.html
  - key: `RESOLVE_BENEATH` / `RESOLVE_IN_ROOT` are explicit path-resolution constraints designed to detect and block escape from a designated directory/root during pathname resolution
  - why: “start from this cwd” is not a sufficient safety claim if `..`, absolute paths, symlinks, or races can still escape into ambient namespaces
  - us: supports pinning CH-CWD to a no-escape bound-root posture rather than a best-effort starting-directory hint under D-CAPSHELL
- **REF-OPENGROUP-UMASK** — The Open Group System Interfaces: `umask()` — https://pubs.opengroup.org/onlinepubs/9699919799/functions/umask.html
  - key: the file mode creation mask is a **process attribute** used to clear permission bits requested by `open()`, `mkdir()`, and related creation calls
  - why: inheriting parent/login-shell `umask` means file-creation permissions drift from hidden session state rather than from reviewed workflow inputs
  - us: supports pinning D-CAPSHELL to a fixed, non-inherited launch mask rather than ambient host/session defaults
- **REF-OPENGROUP-GETRLIMIT** — The Open Group System Interfaces: `getrlimit()` / `setrlimit()` — https://pubs.opengroup.org/onlinepubs/009696699/functions/getrlimit.html
  - key: resource limits are per-process attributes with soft/hard limits controlling resource consumption
  - why: launch behavior can change via inherited per-process limits even when argv/env/cwd are reviewed
  - us: supports treating parent/session `getrlimit()` state as ambient launch context rather than as reviewed D-CAPSHELL input
- **REF-OPENGROUP-ULIMIT** — The Open Group Shell & Utilities: `ulimit` — https://pubs.opengroup.org/onlinepubs/9799919799/utilities/ulimit.html
  - key: shell `ulimit` reports or sets the resource limits in effect in the process in which it executes
  - why: login-shell and wrapper defaults can silently pre-seed child launches with resource ceilings that never appear in the execution pack
  - us: supports declining inherited shell-session `ulimit` state in Phase 1 D-CAPSHELL
- **REF-XDG-BASEDIR** — XDG Base Directory Specification — https://specifications.freedesktop.org/basedir/latest/
  - key: `XDG_CONFIG_HOME`, `XDG_DATA_HOME`, `XDG_STATE_HOME`, `XDG_CACHE_HOME`, `XDG_RUNTIME_DIR`, `XDG_CONFIG_DIRS`, and `XDG_DATA_DIRS` determine where applications look for per-user config, data, state, caches, and runtime files, often with defaults derived from `$HOME`
  - why: synthesizing XDG variables recreates a host/session-specific config and runtime discovery plane even when argv and explicit handles are already reviewed
  - us: supports a capshell env-baseline posture where XDG location variables appear only when explicitly named in CH-ENV
- **REF-FREEBSD-CAPSICUM** — FreeBSD Capsicum manual page (`capsicum(4)`) — https://man.freebsd.org/cgi/man.cgi?query=capsicum  
  - key: concrete OS interface for entering capability mode and enforcing `ENOTCAPABLE` behavior
  - why: practical operational semantics (and pitfalls) matter for adoption
  - us: informs D-CAPMODE “no ambient acquire” pressure tests and error-surface design
- **REF-FREEBSD-LIBCASPER** — FreeBSD `libcasper(3)` (capability services in capmode) — https://man.freebsd.org/cgi/man.cgi?query=libcasper&sektion=3  
  - key: pre-open explicit service capabilities (e.g., `system.dns`, `system.net`, `system.sysctl`) usable after entering capmode
  - why: shows a practical escape hatch for “ambient-ish” facilities without leaving capmode
  - us: adoption pattern for D-SEAL/D-CAPMODE: open needed services pre-seal, then close introducers
- **REF-CLOUDABI** — CloudABI (capability-oriented POSIX subset) — https://github.com/NuxiNL/cloudabi  
  - key: removes `open()` and other ambient acquisition APIs; capability handles are the norm
  - why: clarifies what “capability-first ABI” feels like in practice
  - us: supports D-CAPMODE and the “no ambient acquire” posture
- **REF-CENET** — CeNet—Capability Enabled Networking: *Towards Least-Privileged Networking* — https://www.flux.utah.edu/download?uid=223
  - key: applies object-capability principles to network communication; authority is distributed as explicit connection capabilities
  - why: demonstrates that “all communication blocked until explicitly allowed” is a coherent design target beyond per-host firewalls
  - us: supports D-NETLEASE posture (no ambient sockets/DNS; leased authority; policy-killable mediation)

- **REF-CHERI-INTRO** — CHERI project (overview + intro report pointers) — https://www.cl.cam.ac.uk/research/security/ctsrd/cheri/  
  - key: architectural capability model with strong pointer integrity and compartmentalization
  - why: informs hardware-assumption boundaries (what we *can* rely on vs must prove in software)
  - us: keep our claims conditional on A-HW-1; treat hardware capabilities as an optional platform annex

- **REF-CHERI-FAQ** — CHERI FAQ (purecap vs hybrid ABIs; terminology) — https://ctsrd-cheri.github.io/cheri-faq/  
  - key: crisp definitions of pure-capability (“purecap”/CheriABI/PCuABI) vs hybrid ABI modes
  - why: keeps “what we rely on” explicit in deployment profiles and provenance
  - us: supports D-CHERI and A-CHERI-1 scoping

- **REF-CHERI-MORELLO** — CHERI: the Arm Morello board (industrial demonstrator) — https://www.cl.cam.ac.uk/research/security/ctsrd/cheri/cheri-morello.html  
- **REF-CHERIBSD** — CheriBSD project site — https://www.cheribsd.org/
  - key: capability-enabled Unix-like OS exploiting CHERI hardware
  - why: practical anchor for what it means to run real stacks under purecap/hybrid constraints
  - us: reference environment for evaluating D-CHERI compartments and toolchain/provenance plumbing
- **REF-CHERIBSD-CAMBRIDGE** — Cambridge CTSRD: CheriBSD status (CheriABI, compartmentalization, temporal safety notes) — https://www.cl.cam.ac.uk/research/security/ctsrd/cheri/cheribsd.html
  - key: documents CheriABI, library compartmentalization, and temporal safety work via revocation
  - why: shows what kinds of OS/ABI changes CHERI adoption pulls in
  - us: informs how we keep pointer-free cross-domain ABIs and record ABI mode in CH-PROV
- **REF-CHERI-ANALYSIS-2026** — *A Security Analysis of CheriBSD and Morello Linux* (arXiv 2026) — https://arxiv.org/abs/2601.19074
  - key: evaluates compartmentalization goals and residual risks in CHERI-enabled OS stacks
  - why: keeps our D-CHERI claims evidence-driven rather than marketing-driven
  - us: seed an evidence plan for exploit-suppression demos + negative tests (what CHERI doesn’t fix)

  - key: concrete evaluation hardware for CHERI-extended Armv8-A
  - why: makes “CHERI track” actionable (not just theoretical)
  - us: candidate hardware target for D-CHERI evidence hooks

- **REF-ARM-MORELLO** — Arm Morello program overview (hardware availability milestone) — https://www.arm.com/architecture/cpu/morello  
  - key: program context + platform pointers
  - why: stable reference for the Morello evaluation context
  - us: helps justify platform selection for a CHERI evaluation track

- **REF-CHERIOT** — CHERIoT platform overview (embedded CHERI compartment model) — https://riscv.org/blog/cheriot-a-study-in-cheri/  
  - key: CHERI applied as a coherent hardware/software platform for embedded systems
  - why: shows a path for capability-hardware use beyond “big” servers
  - us: informs future embedded/IoT deployment profiles (optional)

- **REF-ARM-MTE-INTRO** — Arm: Introduction to the Memory Tagging Extension — https://developer.arm.com/documentation/108035/latest/Introduction-to-the-Memory-Tagging-Extension
  - key: explains MTE tagging model and fault modes
  - why: primary reference for what MTE can and cannot detect
  - us: supports D-MEMTAG profiles and CH-HARDEN memtag semantics
- **REF-ANDROID-MTE** — Android platform docs: Arm memory tagging extension (MTE) — https://source.android.com/docs/security/test/memory-safety/arm-mte
  - key: practical enablement and mode choices (sync/async) for Android
  - why: shows how a large platform stages adoption and handles compatibility
  - us: informs D-MEMTAG rollout strategy and fault policy defaults
- **REF-ANDROID-NDK-MTE** — Android NDK docs: Arm MTE — https://developer.android.com/ndk/guides/arm-mte
  - key: app-facing guidance and expected bug classes caught
  - why: ties MTE to developer ergonomics and real bug classes
  - us: informs compat guidance for legacy components and testing profiles
- **REF-LINUX-MTE** — Linux kernel docs: Memory Tagging Extension (MTE) in AArch64 Linux — https://docs.kernel.org/arch/arm64/memory-tagging-extension.html
  - key: interface model (e.g., PROT_MTE) and constraints
  - why: helps design minimal privileged hooks for memtag enablement
  - us: informs D-MEMTAG mechanism boundary for bare-metal vs compat domains
- **REF-GOOGLEBLOG-MTE** — Google Security Blog: Adopting the Arm Memory Tagging Extension in Android (2019) — https://security.googleblog.com/2019/08/adopting-arm-memory-tagging-extension.html
  - key: adoption rationale and positioning vs sanitizers
  - why: gives a pragmatic argument for “ship what you test” memory safety hardening
  - us: supports D-MEMTAG motivation and evidence framing



## Confidential computing (optional platform assumptions)
- **REF-AMD-SEV** — AMD SEV / SEV-SNP overview — https://www.amd.com/en/developer/sev.html  
  - key: guest memory protection + attestation model on AMD platforms
  - why: potential D-CC profile, but expands firmware/attestation assumptions
  - us: encode assumptions explicitly (A-CC-1) and keep side channels as scoped non-claims
- **REF-AMD-SNP-FWABI** — AMD SEV-SNP Firmware ABI Specification (guest/host interface) — https://www.amd.com/content/dam/amd/en/documents/developer/56860.pdf
  - key: primary interface spec for SNP report generation and related VM management commands
  - why: attestation bindings depend on what the ABI actually carries (e.g., reportdata-style inputs)
  - us: concrete anchor for the SNP annex used by D-ATTEST/CH-ATTESTPACK evidence handling
- **REF-INTEL-TDX** — Intel TDX overview — https://www.intel.com/content/www/us/en/developer/tools/trust-domain-extensions/overview.html  
- **REF-INTEL-TDX-TDVF-MEASUREMENT** — Intel TDX Virtual Firmware Design Guide: TD Measurement — https://cdrdv2-public.intel.com/733585/tdx-virtual-firmware-design-guide-rev-004-20231206.pdf  
  - key: TEE model for VM isolation + attestation on Intel
  - why: similar “benefit + assumption” tradeoffs as SNP
  - us: treat as optional profile extension, not a default guarantee
- **REF-INTEL-TDX-QUOTEEXT** — Intel TDX Module Extension for Quoting (spec) — https://www.intel.com/content/www/us/en/content-details/874303/intel-tdx-module-extension-for-quoting.html
  - key: quoting/attestation extension architecture and token structure notes
  - why: TDX attestation formats evolve; pin a primary spec reference rather than blog summaries
  - us: reference anchor for TDX evidence blobs carried in CH-ATTESTPACK (kind=`tdx_quote`)
- **REF-ARM-CCA** — Arm CCA / Realm Management Extension overview — https://developer.arm.com/Architectures/Confidential%20Compute%20Architecture  
  - key: TEE model for Arm ecosystem
  - why: future-looking target for parametric platform instantiation
  - us: keep abstract machine stable; vary A-IDs per platform annex

- **REF-CCA-TOKEN-DRAFT** — Arm CCA reference attestation token (IETF draft) — https://datatracker.ietf.org/doc/html/draft-ffm-rats-cca-token
  - key: token structure/claims for CCA Platform/Realm attestation tokens
  - why: grounds any CCA evidence handling and avoids inventing a token format
  - us: reference anchor for CH-ATTESTPACK evidence blobs (kind=`cca_token`) and future profile decisions


- **REF-RATS-RFC9334** — IETF RATS Architecture (RFC 9334) — https://www.rfc-editor.org/info/rfc9334
  - key: standard roles and conceptual model for remote attestation (Attester/Verifier/Relying Party)
  - why: gives stable vocabulary + threat-model alignment for D-CC without importing protocol complexity
  - us: frames RFC-0064 flows and keeps CC evidence/policy out of the privileged core

- **REF-CORIM-DRAFT** — Concise Reference Integrity Manifest (CoRIM) (IETF draft) — https://datatracker.ietf.org/doc/draft-ietf-rats-corim/
  - key: CBOR/COSE-based format for distributing reference measurements/endored values
  - why: “what is the verifier comparing against?” is a distinct artifact surface from attestation tokens
  - us: candidate reference-value artifact family for B/C profiles (kept out of privileged core; can be portal-managed via CH-AREF)

- **REF-TCG-CRIM-IM** — TCG Component Reference Integrity Manifest Information Model (CRIM) — https://trustedcomputinggroup.org/wp-content/uploads/TCG-Component-Reference-Integrity-Manifest-Information-Model-Version-1.0-Revision-38_27Feb24.pdf
  - key: information model tying CoRIM/CoMID/CoSWID concepts together
  - why: helps align reference-value vocab without importing a full endorsement protocol
  - us: grounding for any future “reference measurement bundle” design that stays small and content-addressed
- **REF-LINUX-TDX** — Linux kernel docs: Intel TDX (x86) — https://docs.kernel.org/arch/x86/tdx.html
  - key: concrete attestation structure notes (TDREPORT + REPORTDATA) and guest interaction points
  - why: practical grounding for TDX evidence binding and what can be carried as reportdata
  - us: informs RFC-0064 binding strategy for TDX
- **REF-AWS-SNP-ATTEST** — AWS EC2 docs: attesting an instance with AMD SEV-SNP — https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/snp-attestation.html
  - key: guest-accessible SNP attestation reports, launch measurement, and endorsement chain considerations in practice
  - why: concrete “how people actually do it” reference for a first integration target
  - us: informs RFC-0064 SNP annex and verifier expectations
- **REF-AWS-NITROTPM-ATTEST** — AWS EC2 docs: NitroTPM attestation documents — https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/attestation-get-doc.html
  - key: explicit nonce/user-data/public-key fields and live-instance freshness guidance for attestation documents
  - why: practical primary-source reminder that freshness must come from a fresh verifier challenge rather than replaying cached attestation blobs
  - us: informs the microVM attestation-reacquire boundary and attestation-gated secret-release session invalidation
- **REF-AWS-NITROTPM** — AWS EC2 docs: NitroTPM for Amazon EC2 instances — https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/nitrotpm.html
  - key: NitroTPM is a virtual TPM 2.0 device with measured boot, PCR-based remote attestation, and sealing/unsealing semantics
  - why: primary-source reminder that guest-visible TPM devices can quietly become the de facto attestation and sealing plane
  - us: informs the microVM TPM-surface boundary so TPM-device semantics do not bypass D-ATTEST / D-CRYPTOSVC seams
- **REF-CHYP-VFIO** — Cloud Hypervisor docs: VFIO device assignment (`--device path=/sys/bus/pci/devices/...`) — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/vfio.md
  - key: Cloud Hypervisor uses VFIO to assign host PCI devices directly to guests, requires rebinding host devices from native drivers, exposes sysfs-path-based attachment, and warns that whole IOMMU groups may need to be passed through together
  - why: primary-source reminder that passthrough is an explicit device/configuration plane with host binding, IOMMU-group, and direct-DMA consequences
  - us: informs the microVM passthrough-device posture so host-specific VFIO attachment does not silently become portable reviewed meaning
- **REF-CHYP-TPM** — Cloud Hypervisor docs: virtual Trusted Platform Module (vTPM) — https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/tpm.md
  - key: Cloud Hypervisor exposes an optional `--tpm` backed by `swtpm` over a Unix socket and presents `/dev/tpm0` / `/dev/tpmrm0` in the guest
  - why: concrete evidence that guest-visible TPM devices are an explicit VM runtime/config surface, not just attestation prose
  - us: informs the microVM TPM-surface posture so owner-local emulator wiring does not silently become portable reviewed meaning
- **REF-QEMU-VFIO** — QEMU docs: passthrough device configuration (`-device vfio-pci`, IOMMU/iommufd interactions) — https://www.qemu.org/docs/master/system/qemu-manpage.html
  - key: QEMU exposes generic `-device` attachment, requires explicit `vfio-pci`/IOMMU coordination for passthrough devices, and treats DMA remapping/iommufd as configuration surfaces for host-assigned hardware
  - why: primary-source evidence that passthrough devices are a real runtime/device-management plane rather than a harmless implementation detail
  - us: informs the microVM passthrough-device posture so live guest hardware assignment does not silently become portable API meaning
- **REF-QEMU-TPMDEV** — QEMU docs: TPM device options (`-tpmdev`, `-device tpm-*`) — https://www.qemu.org/docs/master/system/qemu-manpage.html
  - key: QEMU supports TPM passthrough and emulator backends as explicit VM/device configuration surfaces
  - why: primary-source reminder that TPM/vTPM exposure is a real guest-device plane with backend and control choices
  - us: informs the microVM TPM-surface posture so backend/device semantics remain implementation-local instead of ambient API meaning
- **REF-AMD-SNP-ATTEST-PDF** — AMD: SEV-SNP Attestation (slides/paper) — https://www.amd.com/content/dam/amd/en/documents/developer/lss-snp-attestation.pdf
  - key: certificate chain retrieval, report generation flow, and the guest/host interface boundaries
  - why: adds vendor-level detail beyond marketing overviews
  - us: supports D-CC assumption articulation and binding strategy
- **REF-ARM-CCA-REALMS** — Arm Learning Path: CCA Realms overview — https://learn.arm.com/learning-paths/servers-and-cloud-computing/cca-container/overview/
  - key: “Realms” as the protected execution environment concept in Arm CCA
  - why: practical grounding for the CCA annex, even if protocol details vary by deployment
  - us: keeps CCA references concrete while we keep the abstract machine stable


## Supply chain / transparency logs
- **REF-SIGSTORE-COSIGN** — Sigstore/Cosign — https://sigstore.dev/ / https://github.com/sigstore/cosign  
  - key: signed artifacts + transparency log integration
  - why: strengthens provenance claims without custom infra
  - us: candidate tooling to support C-PROV-1 under explicit A-TOOL-1 trust assumptions

- **REF-SCITT-ARCH** — IETF SCITT Architecture (draft-ietf-scitt-architecture) — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
  - key: standard framing for transparency-backed supply-chain statements
  - why: interoperable vocabulary for releases that publish signed provenance + log receipts
  - us: map ‘SCITT statements’ to CH-SIGENV over digest-bound CH-* payloads; treat log receipts as optional evidence (D-TLOG/D-WITNESS)
- **REF-SCITT-SCRAPI** — IETF SCITT Reference APIs (draft-ietf-scitt-scrapi) — https://datatracker.ietf.org/doc/draft-ietf-scitt-scrapi/
  - key: interoperable REST API for submitting/querying transparency-backed statements
  - why: practical interop surface if release tooling publishes CH-PROV/CH-UPD anchors to a transparency log
  - us: optional release-tooling integration target; never a kernel dependency
- **REF-SCITT-CCF-RECEIPTS** — IETF COSE Receipts with CCF (draft-ietf-scitt-receipts-ccf-profile) — https://datatracker.ietf.org/doc/draft-ietf-scitt-receipts-ccf-profile/
  - key: compact signed Merkle inclusion proofs (‘receipts’) for ledgers via COSE structures
  - why: concrete receipt format precedent for tlog inclusion evidence
  - us: compare with CH-TLOG v0 minimal anchor expectations; keep receipt formats as interop-layer choices, not privileged dependencies

## Record/replay and determinism (optional)
- **REF-VM-REPLAY-ABSTRACTIONS** — *Abstractions for Practical Virtual Machine Replay* (VEE 2016) — https://users.cs.utah.edu/~regehr/papers/vee16-xentt.pdf  
  - key: pragmatic replay depends on good nondeterminism abstractions and boundaries
  - why: supports “pin the boundary” rather than “log everything”
  - us: informs CH-RR event kinds + D-RR scope choices
- **REF-RR-SURVEY-CACM25** — *Deterministic Record-and-Replay* (CACM 2025) — https://dl.acm.org/doi/10.1145/3724381  
  - key: survey of recent deterministic record/replay techniques and why they matter
  - why: highlights common failure modes (hidden nondeterminism, performance costs)
  - us: sanity-check what we can reasonably claim for D-RR profiles

- **REF-REVERT-OSDI02** — ReVirt: Enabling Intrusion Analysis Through Virtual-Machine Logging and Replay (OSDI 2002) — https://www.usenix.org/conference/osdi-02/revirt-enabling-intrusion-analysis-through-virtual-machine-logging-and-replay  
  - key: shows replay logs as incident evidence; logs enough nondeterminism to replay execution around compromise  
  - why: motivates D-RR beyond debugging; ties replay to forensic workflows  
  - us: informs D-RR scope ladder, retention/export posture, and replay-bundle artifact design
- **REF-PANDA-RE** — PANDA: Platform for Architecture-Neutral Dynamic Analysis — https://panda.re/  
  - key: whole-system record/replay plus analysis plugins; emphasizes shareable replay traces  
  - why: demonstrates value of portable replay artifacts for iterative analyses  
  - us: informs CH-RRBUNDLE packaging and future guest_and_devices scope
- **REF-PANDA-GITHUB** — PANDA source repository — https://github.com/panda-re/panda  
  - key: concrete implementation references for record/replay log chunking and tooling  
  - why: helps sanity-check bundle chunking/validation ideas  
  - us: informs future experiments and evidence harness scaffolding

- **REF-CRIU** — CRIU (Checkpoint/Restore In Userspace) — https://criu.org/Main_Page  
  - key: practical checkpoint/restore for Linux processes/containers; shows the edge cases
  - why: realism about what “transparent C/R” costs
  - us: motivates a cooperative D-CHKPT seam rather than opaque interception

- **REF-DMTCP** — DMTCP (Distributed MultiThreaded Checkpointing) — https://dmtcp.sourceforge.io/  
  - key: user-space checkpointing for many apps (including distributed); plugin model for tricky resources
  - why: demonstrates “C/R in user land” is viable but requires discipline
  - us: informs CH-CKPT manifest fields and restore constraints

- **REF-KUP-ATC16** — *Instant OS Updates via Userspace Checkpoint-and-Restart* (USENIX ATC 2016) — https://www.usenix.org/system/files/conference/atc16/atc16_paper-kashyap.pdf  
  - key: uses userspace checkpoint/restart to enable fast OS updates with minimal kernel coupling
  - why: shows “checkpoint + switch” can be a pragmatic update path when hotpatching is insufficient
  - us: supports D-CHKPT + D-ATOMICUPD integration ideas (update without losing session state)

- **REF-L4-ORTHOCHKPT** — *Transparent Orthogonal Checkpointing Through User-Level* (Skoglund/Ceelen/Liedtke) — https://www.l4ka.org/downloads/publ_2000_skoglund-ceelen-liedtke_transparent-orthogonal-checkpointing.pdf  
  - key: microkernel-style user-level checkpoint server with minimal privileged support
  - why: existence proof for “keep checkpointing out of the kernel” as a design center
  - us: informs D-CHKPT kernel seam minimization + bootstrapping boundaries



## Distributed / networked capabilities (optional)
- **REF-SDSI-RL96** — SDSI: A Simple Distributed Security Infrastructure (1996) — https://www.microsoft.com/en-us/research/publication/sdsi-a-simple-distributed-security-infrastructure/  
  - key: linked local namespaces; names are local to principals (keys)
  - why: avoids global-name complexity while supporting composition and delegation
  - us: motivates D-NAMECERT as a user-space seam that complements views/sturdyrefs
- **REF-SPKI-RFC2692** — RFC 2692: SPKI Requirements — https://www.rfc-editor.org/info/rfc2692  
  - key: focuses requirements around authorization certificates and delegation
  - why: frames why “identity PKI” assumptions are often the wrong tool
  - us: informs the minimal scope for CH-NAMECERT bundles (authorization-first)
- **REF-SPKI-RFC2693** — RFC 2693: SPKI Certificate Theory — https://datatracker.ietf.org/doc/rfc2693/  
  - key: formal-ish model for authorization certificates + delegation
  - why: useful as a crisp, bounded semantics target for model checking
  - us: candidate baseline semantics for PO-NAMECERT-CHAIN (kept out of the privileged core)
- **REF-KEYNOTE-RFC2704** — RFC 2704: The KeyNote Trust-Management System Version 2 — https://www.rfc-editor.org/rfc/rfc2704.html  
  - key: unified language for local policies + credentials with an explicit compliance checker
  - why: sharp contrast for the tempting “portable checker/policy language” seam that we do **not** want to import into D-NAMECERT v0
  - us: informs the Phase 1 choice to keep local naming evidence separate from authority-bearing projection and to keep any richer compliance logic evaluator-local rather than core-portable
- **REF-RT0-DISCOVERY** — *Distributed Credential Chain Discovery in Trust Management* (Journal of Computer Security, 2003) — https://www.cs.purdue.edu/homes/ninghui/papers/discovery_jcs03.pdf  
  - key: RT0 gives a **set-theoretic semantics** for credentials plus **credential graphs** with sound/complete reachability for chain discovery
  - why: a sharp example of the richer searchable trust-management seam we might someday want, but should not silently import into D-NAMECERT v0
  - us: supports the Phase 1 decision to keep NAMECERT evaluation explicit and set-valued without standardizing a ranking/search engine or integrated policy language on the core seam
- **REF-ROBUST-COMPOSITION** — *Robust Composition: Towards a Unified Approach to Access Control and Concurrency Control* (Miller, PhD thesis 2006) — https://www.erights.org/talks/thesis/markm-thesis.pdf  
  - key: SturdyRefs + eventual send/promise patterns for least-authority distributed systems
  - why: sharp guidance on “public bootstrap must be powerless” and how durable refs work
  - us: informs CH-SREF + D-CAPX without importing a distributed-object kernel TCB
- **REF-MACAROONS-NDSS14** — Macaroons (NDSS 2014) — https://www.ndss-symposium.org/ndss2014/ndss-2014-programme/macaroons-cookies-contextual-caveats-decentralized-authorization-cloud/  
  - key: unforgeable credentials that support *delegation with attenuation* via contextual caveats
  - why: a concrete pattern for “capability handoff” across trust boundaries
  - us: candidate token form for D-CAPX (bind tokens to our proxy/service import IDs in Phase 1; ensure monotonic attenuation)
- **REF-CHERI-MACAROONS** — CHERI Macaroons (SILM 2020) — https://www.cl.cam.ac.uk/~arb33/papers/DodsonEtAl-CHERIMacaroons-SILM2020.pdf  
  - key: combines macaroons with host-based capabilities/compartmentalization
  - why: aligns token attenuation with capability hardware/software boundaries
  - us: informs how to bind delegation tokens to concrete authority objects
- **REF-BISCUIT-SPEC** — Biscuit token specification — https://doc.biscuitsec.org/reference/specifications.html  
  - key: datalog-based authorization tokens with offline attenuation and explicit revocation semantics
  - why: an alternative to macaroon-style caveats with more structured policy expressiveness
  - us: candidate “policy-carrying cap token” for D-CAPX (kept optional; proof surface must be bounded)
- **REF-BISCUIT-PTS21** — Biscuit overview slides (Pass the SALT 2021) — https://archives.pass-the-salt.org/Pass%20the%20SALT/2021/slides/PTS2021-Talk-08-Biscuit.pdf  
  - key: design/crypto overview + emphasis on attenuation and audit/replay properties
  - why: quick survey of tradeoffs and attack surface
  - us: helps scope what *not* to pull into the privileged core
- **REF-CAPTP** — CapTP (Capability Transport Protocol) — https://erights.org/elib/distrib/captp/index.html  
  - key: distributed object references as capabilities; explicit handoff preserves least authority
  - why: practical semantics for “remote object caps” (no ambient network authority)
  - us: informs D-CAPX “networked object/proxy” design, especially handoff + GC semantics

- **REF-E-LRM** — *The E Kernel Language Reference Manual* (PDF) — https://erights.org/elang/elangmanual.pdf
  - key: precise semantics for vats/near-vs-far references and event-loop concurrency in E
  - why: canonical source for the vat/turn model and promise/eventual-send discipline
  - us: informs D-TURNS (RFC-0078) and CapRPC runtime guidance (no inbox pumping)

- **REF-E-FAQ** — *Frequently asked questions about E* (event loop concurrency, vats) — https://mumble.net/e/faq.html
  - key: practical explanation of why E insists on event-loop concurrency and how parallelism is achieved
  - why: succinct operator-facing rationale; useful for “why this weird rule?” docs
  - us: supports D-TURNS adoption narratives and training material

- **REF-ERIGHTS-SERIAL** — *Safe Serialization Under Mutual Suspicion* — https://erights.org/data/serial/jhu-paper/intro.html
  - key: distributed-object + capability discipline for serialization; discusses vats as communicating event loops
  - why: connects ocap security to practical engineering hazards (serialization, identity, causality)
  - us: background for D-CAPX + D-TURNS narratives (keep it user-space)

- **REF-SPRITELY-CORE** — *Distributed Objects and Capability Security* (Spritely core paper) — https://files.spritely.institute/papers/spritely-core.html
  - key: modern ocap distributed-object model (OCapN/CapTP), including vat terminology and near/far call constraints
  - why: current, readable prior art for vat/turn semantics without importing a heavyweight framework
  - us: informs D-TURNS, D-CAPX vocabulary, and test ideas for reentrancy/ordering hazards

- **REF-ORLEANS-REQUEST-SCHED** — Microsoft Orleans: request scheduling / reentrancy guidance — https://learn.microsoft.com/en-us/dotnet/orleans/grains/request-scheduling
  - key: default non-reentrant grain execution with explicit interleaving/reentrancy escape hatches
  - why: useful modern contrast showing exactly how easily turn discipline can widen into API-level reentrancy knobs
  - us: supports the D-TURNS v0 choice to keep reentrancy/interleaving implementation-local rather than portable surface area

- **REF-SPRITELY-CAPTP-WHATIS** — Spritely: *What is CapTP, and what does it enable?* — https://spritelyproject.org/news/what-is-captp.html
  - key: approachable explanation of CapTP and its security goals (mutual suspicion, object references as capabilities)
  - why: good onboarding reference that complements the original E CapTP docs
  - us: helps motivate D-CAPX design choices and adoption docs
- **REF-OCAPN** — OCapN (Object Capability Network) — https://ocapn.org/  
  - key: interop suite for CapTP-style capabilities over mutually suspicious networks
  - why: concrete ecosystem for network-cap ideas that stayed niche but sharp
  - us: possible interoperability target for a future user-space “cap gateway” (keep kernel agnostic)
- **REF-UCAN-SPEC** — UCAN specification — https://ucan.xyz/specification/  
  - key: modern delegated-authorization format with attenuated capabilities, proof chains, and offline verification
  - why: useful modern contrast for local-first/content-addressed delegation without importing a global PKI
  - us: informs D-NAMECERT / D-CAPX boundary choices while keeping richer capability vocabularies and caveat semantics out of the privileged core unless we add a separate reviewed seam
- **REF-PRECIS-RFC8264** — RFC 8264: PRECIS Framework: Preparation, Enforcement, and Comparison of Internationalized Strings in Application Protocols — https://www.rfc-editor.org/rfc/rfc8264.html  
  - key: protocols that accept Unicode identifiers must define explicit preparation, enforcement, and comparison behavior
  - why: shows string identity/security is a protocol design surface, not something to leave implicit
  - us: supports the Phase 1 choice to keep CH-NAMECERT authority-bearing labels on a tiny exact-byte ASCII profile rather than importing a broader Unicode identifier class
- **REF-UNICODE-UTS39** — UTS #39: Unicode Security Mechanisms — https://www.unicode.org/reports/tr39/  
  - key: confusable detection, mixed-script/whole-script spoofing checks, and other Unicode identifier security mechanisms
  - why: demonstrates the attack surface that appears once identifiers widen beyond a tiny ASCII class
  - us: supports AC-029 and the decision to keep D-NAMECERT authority-bearing labels ASCII-only in Phase 1 rather than standardizing a moving confusable-policy seam
- **REF-TAHOE-LAFS** — Tahoe-LAFS “Least-Authority Filesystem” — https://tahoe-lafs.org/~trac/lafs.pdf  
  - key: capability-based access control for distributed storage using cryptographic capabilities
  - why: evidence that “capability strings” can work at scale in real systems
  - us: inspiration for D-CAPX usability patterns (cap strings/URLs) and operational guidance
- **REF-W3C-CAPURLS** — W3C TAG note on Capability URLs — https://w3ctag.github.io/capability-urls/2014-07-23.html  
  - key: security guidance for capability-bearing URLs in practice
  - why: helps avoid naïve “secret URL” footguns
  - us: informs threat model + operational constraints if we ever expose cap URLs

## WebAssembly as a verification-friendly sandbox (optional)
- **REF-WASM-CPP18** — Mechanising and verifying the WebAssembly specification (CPP 2018) — https://dl.acm.org/doi/10.1145/3167082  
  - key: mechanised spec + verified interpreter/type checker (Isabelle)
  - why: unusually strong formal foundation for a widely deployed sandbox
  - us: candidate basis for a “Wasm component profile” (D-WASM) with tight, spec-first interfaces
- **REF-WASM-AFP** — Isabelle AFP: WebAssembly mechanisation — https://www.isa-afp.org/entries/WebAssembly.html  
  - key: curated mechanisation with soundness proof and executable artifacts
  - why: lowers “formal semantics tax” compared to bespoke bytecodes
  - us: a plausible starting point for mechanised reasoning about plugin components
- **REF-WATT-THESIS** — Watt thesis on WebAssembly mechanisation (Isabelle/HOL) — https://www.repository.cam.ac.uk/bitstreams/26ee0359-56cb-4dd0-b8e4-26e16e250698/download  
  - key: reports spec bug-finding, type soundness, verified tools, and security extensions
  - why: evidence the mechanisation is *useful*, not just ceremonial
  - us: informs what “proof-driven sandboxing” could look like without kernel entanglement
- **REF-WASI-DESIGN** — WASI Design Principles — https://github.com/WebAssembly/WASI/blob/master/docs/DesignPrinciples.md  
  - key: WASI is explicitly capability-oriented; ambient authority is avoided by design
  - why: aligns with our capability-mediated posture at the ecosystem boundary
  - us: map our view/cap objects to WASI-like capability handles in a user-space runtime

- **REF-WASI-0-2-LAUNCH** — Bytecode Alliance, *WASI 0.2 Launched* (WASI Preview 2) — https://bytecodealliance.org/articles/WASI-0.2
  - key: launch of WASI 0.2/Preview 2; emphasizes component model + interface types
  - why: identifies the moving target we need to pin for reproducible plugin boundaries
  - us: informs RFC-0005’s “WASI-aligned, not WASI-complete” stance and drift-control via digests

## Recovery-oriented computing / crash-only (optional)
- **REF-MICROREBOOT-OSDI04** — Candea et al., *Microreboot: A Technique for Cheap Recovery* (OSDI 2004) — https://www.usenix.org/legacy/event/osdi04/tech/full_papers/candea/candea.pdf
  - key: separate process recovery from data recovery; restart the smallest faulty component
  - why: “microreboot” is a crisp recovery primitive for componentized systems
  - us: bake restartability discipline into D-SUPV + RFC-0041 without kernel magic
- **REF-ROC-COMPUTER04** — Candea & Brown, *Recovery-Oriented Computing: Building Multitier Dependability* (IEEE Computer 2004) — https://www.computer.org/csdl/magazine/co/2004/11/ry060/13rRUwjoND4
  - key: prioritize fast recovery (low MTTR) over trying to prevent every failure
  - why: frames recovery as a design goal and operational discipline
  - us: motivates crash-only services + restart hygiene as an early ecosystem norm (RFC-0041)

## Microkernel pager / deprivileged privilege patterns (optional)
- **REF-L4-UM** — L4 User Manual (IPC on faults; user-level pagers) — https://trustworthy.systems/publications/papers/L4UM_x.2.pdf  
  - key: page faults/exceptions as IPC to user-level handlers (pagers/exception servers)
  - why: classic way to shrink kernel policy and keep TCB small
  - us: supports D-PAGER: faults become explicit messages with a closed surface
- **REF-KPAGES** — User-Level Management of L4 Kernel Memory (MBS 2001) — https://haeberlen.cis.upenn.edu/papers/kpages-mbs2001.pdf  
  - key: user-level control can reduce kernel-memory DoS vectors when carefully constrained
  - why: shows “move policy out” must still account for DoS/quotas
  - us: tie pager delegation to D-METER/D-IOBUF constraints if we adopt it
- **REF-DUNE-OSDI12** — Dune: Safe User-level Access to Privileged CPU Features (OSDI 2012) — https://www.usenix.org/system/files/conference/osdi12/osdi12-final-117.pdf  
  - key: uses virtualization hardware to expose privileged features safely to user processes
  - why: alternative approach to privilege separation that can shrink trusted code
  - us: informs a “deprivileged management plane” and hypervisor-first experiments (keep optional)

## Address translation synthesis / decoding nets (optional)
- **REF-PTGEN-SOSP21** — *Generating correct initial page tables from formal hardware descriptions* (2021) — https://www.retoachermann.ch/publications/achermann21.html  
  - key: model translation structure explicitly and synthesize correct initial tables
  - why: hand-written MMU/IOMMU bring-up code is a recurring isolation footgun
  - us: motivates CH-ADDRNET + generator/checker pipeline (D-ADDRNET)
- **REF-MMAPX-HOTOS21** — *mmapx: A new memory mapping interface for operating systems* (HotOS 2021) — https://www.retoachermann.ch/publications/achermann21mmapx.html  
  - key: memory mapping interfaces must encode intent precisely to avoid mismatches and hidden policy
  - why: mapping APIs tend to accrete special cases that are hard to specify/verify
  - us: informs how we keep runtime mapping operations small (I-MAP-1) and push complex setup into pinned artifacts


## Additional references (added)
- **REF-CAPDL-KUZ10** — capDL: capability distribution language for seL4 (APSys 2010) — https://trustworthy.systems/publications/nicta_full_text/3679.pdf
  - key: describe **state snapshots** of capability distributions
  - why: makes expected vs actual authority edges auditable/debuggable
  - us: informs D-INITSNAP/CH-INIT as a bounded snapshot artifact

- **REF-MICROKIT-VERIFY24** — *Verifying the seL4 Microkit* (2024) — https://trustworthy.systems/publications/papers/Weibel_KPSSH_24.pdf
  - key: verified Microkit runtime + verified mapping from system description to capDL
  - why: shows a tractable proof path for **system initialization artifacts**
  - us: template for ‘spec → snapshot → verified initializer’ pipeline, kept out of kernel

- **REF-MICROKIT-MANUAL** — Microkit User Manual (latest) — https://docs.sel4.systems/projects/microkit/manual/latest/
  - key: system description file (static architecture) compiled into a small initializer/runtime
  - why: concrete guidance for building statically structured microkernel systems with a small abstraction set
  - us: informs CH-COMP→CH-INIT sysgen posture and what must remain closed/validated
- **REF-MICROKIT-GITHUB** — seL4 Microkit SDK source repository — https://github.com/seL4/microkit
  - key: reference implementation layout (tool, initializer, monitor/library) and evolution history
  - why: pragmatic details for how ‘system description → initializer’ pipelines are packaged
  - us: keeps our pipeline grounded in real artifact boundaries (tool vs runtime vs boot)
- **REF-MICROKIT-TUTORIAL** — Microkit tutorial (system description examples) — https://docs.sel4.systems/projects/microkit/tutorial/part1.html
  - key: minimal examples of describing PDs/channels and generating a bootable image
  - why: quick sanity check on what information a static architecture description must carry
  - us: helps keep CH-COMP/CH-INIT authoring expectations realistic for Phase 1

- **REF-REDLEAF-OSDI20** — RedLeaf (OSDI 2020) — https://www.usenix.org/system/files/osdi20-narayanan_vikram.pdf
  - key: Rust safety as an isolation/organization lever inside an OS
  - why: informs what Rust can and cannot replace (hardware isolation still matters)
  - us: supports strong ‘isolate unsafe + deprivilege subsystems’ posture

## Object-capability RPC (optional)
- **REF-CAPNP** — Cap’n Proto (capability-based RPC + schema/IDL) — https://capnproto.org/  
  - key: object-capability RPC model; explicit object references; tight schema-driven interfaces
  - why: a ready-made semantics reference for D-CAPRPC (no ambient endpoints)
  - us: evaluate as a candidate D-IDL+D-CAPRPC substrate or as a reference model
- **REF-CAPNP-RPC** — Cap’n Proto RPC protocol (promise pipelining; persistent caps) — https://capnproto.org/rpc.html  
  - key: capability-based RPC with promise pipelining; protocol supports persistent capabilities
  - why: hard-won ocap-RPC ergonomics (disconnects, pipelining, explicit remote calls) without name-based authority
  - us: concrete constraints for D-CAPRPC promise handles + pipelined-send semantics; stage adoption by profile
- **REF-CAPNP-CXXRPC** — Cap’n Proto: C++ RPC / KJ concurrency docs — https://capnproto.org/cxxrpc.html  
  - key: event-loop concurrency, linear promises, and `then()`/fork discipline in a production Cap’n Proto runtime
  - why: gives a primary implementation reference for promise lifecycle, one-shot consumption, and event-loop composition
  - us: supports D-CAPRPC promise posture: caller-local/session-scoped one-shot handles, deterministic break behavior, and composition with D-TURNS
- **REF-E-REFMECH** — E reference mechanics / promises — https://erights.org/elib/concurrency/refmech.html  
  - key: eventual-send results start as promises; broken references propagate broken promises; promise resolution stays explicit
  - why: captures the classic ocap promise semantics underlying eventual-send / pipelining without importing a language runtime wholesale
  - us: supports D-CAPRPC promise posture: deterministic broken-promise propagation and no ambient synchronous fallback
- **REF-CAPNP-1.0-CANCEL** — Cap’n Proto 1.0 release notes: cancellation should be “opt-out” (allowCancellation schema annotation) — https://capnproto.org/news/2023-07-28-capnproto-1.0.html
  - key: cancellation is a common production footgun when it’s opt-in; make it schema-level and default-friendly
  - why: reinforces that cancellation semantics belong in the interface/profile, not in ad-hoc per-service code
  - us: supports D-REQCTX posture: stubs default to cancellable requests and surface deterministic cancel outcomes

- **REF-GO-CONTEXT** — Go blog: *Go Concurrency Patterns: Context* — https://go.dev/blog/context
  - key: request-scoped cancellation signals + deadlines propagated across API boundaries
  - why: widely deployed pattern that prevents orphan work and makes shutdown tractable
  - us: informs D-REQCTX conventions (ctx passed everywhere; explicit cancel/deadline outcomes)

- **REF-GO-PKG-CONTEXT** — Go package docs: `context` — https://pkg.go.dev/context
  - key: derived contexts cancel their children, `CancelFunc` stops associated timers/references, and `Values` are for request-scoped transit data rather than optional parameters
  - why: primary runtime contract for the sticky-tree propagation/resource-release discipline behind D-REQCTX
  - us: supports D-REQCTX v0 posture: monotonic parent→child propagation, explicit cancel-resource cleanup, and “no baggage store” semantics

- **REF-KOTLIN-CANCEL** — Kotlin docs: *Cancellation and timeouts* (structured concurrency) — https://kotlinlang.org/docs/cancellation-and-timeouts.html
  - key: parent cancellation automatically cancels child coroutines; deadlines/cancellation are first-class
  - why: demonstrates the ergonomics and correctness benefits of structured cancellation propagation
  - us: supports D-REQCTX cancellation propagation guidance for long-lived services and portals

- **REF-VORPUS-TIMEOUTS** — *Timeouts and cancellation for humans* (design essay) — https://vorpus.org/blog/timeouts-and-cancellation-for-humans/
  - key: cancellation tokens + deadlines as a unified model; highlights pitfalls of implicit/exception-based cancellation
  - why: concise articulation of why request contexts prevent subtle resource leaks
  - us: supports making cancellation/deadline semantics explicit and testable (PO-REQCTX-ATTEN)

- **REF-TRIO-CANCELSCOPE** — Trio docs: `CancelScope` / cancellation + timeouts — https://trio.readthedocs.io/en/stable/reference-core.html
  - key: cancellation scopes are non-reentrant, expose an absolute deadline on the run clock, and keep `shield` as a lexical local runtime attribute rather than network-visible metadata
  - why: useful under-adopted import for “absolute deadline intent + local-only shield/cleanup” without turning request context into a distributed baggage protocol
  - us: supports D-REQCTX v0 posture: absolute monotonic deadline intent, no portable shield bit, and explicit fresh-root boundaries for long-lived work

- **REF-CAPNP-FAQ-MALICIOUS** — Cap’n Proto FAQ on malicious peers — https://capnproto.org/faq.html  
  - key: explicitly discusses using capability RPC between mutually-distrusting parties; warns about resource exhaustion
  - why: aligns with our non-claims on availability and motivates D-METER bounds at the boundary
  - us: treat DoS as non-claim initially; require bounded message sizes and optional meters
- **REF-CAPNWEB-2025** — Cap’n Web (object-capability RPC over web transports) — https://blog.cloudflare.com/capnweb-javascript-rpc-library/  
  - key: modern, small-footprint capability RPC over HTTP/WebSocket/postMessage
  - why: shows capability RPC can fit real-world transports without bloating implementation
  - us: inspiration for “capability RPC as an ecosystem primitive” (D-CAPRPC) beyond local IPC
- **REF-SANDSTORM-CAPNP** — Sandstorm source schemas (capnp-based app isolation platform) — https://github.com/sandstorm-io/sandstorm  
  - key: production-ish system built around object-capabilities + Cap’n Proto interfaces
  - why: concrete design patterns for capability routing, least authority, and app packaging
  - us: mine for ecosystem primitives (cap routing, sturdy refs, UX) without importing the whole platform

## Attestation / measured boot claim sets (optional)
- **REF-EAT-RFC9711** — IETF RFC 9711: Entity Attestation Token (EAT) — https://datatracker.ietf.org/doc/rfc9711/  
  - key: standard claims set for attesting device/software state; CBOR-based
  - why: avoid inventing a bespoke claims universe; reuse verifiers/tooling
  - us: CH-ATTEST can embed an EAT payload or align field names to EAT claims
- **REF-DICE-TCG** — TCG overview: Device Identifier Composition Engine (DICE) — https://trustedcomputinggroup.org/what-is-a-device-identifier-composition-engine-dice/  
  - key: lightweight root-of-trust for device identity and measurement binding
  - why: DICE fits “small TCB” profiles where TPM is too heavy
  - us: candidate A-ATTEST-1 foundation in embedded/edge deployment profiles
- **REF-TPM2-PART1** — TCG TPM 2.0 Library Part 1 (Architecture) — https://trustedcomputinggroup.org/wp-content/uploads/Trusted-Platform-Module-2.0-Library-Part-1-Architecture-Version-184-rc2_20Dec24.pdf  
  - key: handle-based objects (keys never leave the TPM) + command/audit structures
  - why: common hardware-backed key custody + attestation building block
  - us: optional annex for D-CRYPTOSVC/D-ATTEST (hardware provider profile) and for audit/session binding ideas
- **REF-TCG-EFI-PLATFORM** — TCG EFI Platform Specification (boot events → PCRs + event log) — https://trustedcomputinggroup.org/resource/tcg-efi-platform-specification/  
  - key: requirements for measuring boot events into PCRs and recording into the Event Log on EFI platforms
  - why: authoritative anchor for “PCR + log” semantics in UEFI deployments
  - us: informs CH-MEASLOG extraction profiles and D-BOOT measured-boot expectations
- **REF-TCG-PC-CLIENT-PFP** — TCG PC Client Platform Firmware Profile Specification (TPM 2.0) — https://trustedcomputinggroup.org/wp-content/uploads/TCG_PCClient_PFP_r1p05_v22_02dec2020.pdf  
  - key: PCR usage and event-log requirements across the pre-OS → OS-present transition
  - why: measured-boot details that operators/verifiers actually depend on
  - us: informs what a “measured boot” profile means for CH-BOOT/CH-MEASLOG
- **REF-TCG-IMELP** — TCG Guidance on Integrity Measurements and Event Log Processing — https://trustedcomputinggroup.org/wp-content/uploads/TCG-Guidance-on-Integrity-Measurements-and-Event-Log-Processing-Version-1.0-RC-1_24February25.pdf  
  - key: verifier-side guidance and pitfalls in event log parsing/replay
  - why: highlights how easy it is to get verification wrong; motivates canonicalization and bounds
  - us: informs PO-MEASLOG-VALIDATE test cases and negative corpus design
- **REF-SYSTEMD-PCR-MEASURE** — systemd.io: TPM2 PCR Measurements Made by systemd — https://systemd.io/TPM2_PCR_MEASUREMENTS/  
  - key: practical catalog of what gets measured and how it appears in the firmware event log
  - why: high-signal operational mapping between tooling and PCR/event-log entries
  - us: reinforces keeping measurement taxonomy in user-space tooling, not kernel code
- **REF-SYSTEMD-MEASURE-MAN** — systemd-measure manual page — https://www.freedesktop.org/software/systemd/man/systemd-measure.html  
  - key: pre-calculate and sign expected PCR values for boot artifacts (UKI/stub workflows)
  - why: practical confirmation that “expected measurement signing” is deployable tooling
  - us: candidate adjunct evidence format referenced via CH-AREF (keep out of privileged core)
- **REF-LINUX-IMA-TEMPLATES** — Linux kernel docs: IMA template management mechanism — https://docs.kernel.org/security/IMA-templates.html  
  - key: structure/semantics of IMA measurement records and templates
  - why: runtime measurement logs are huge; template structure matters for parsing and bounds
  - us: informs optional CH-MEASLOG `source=ima` profiles and the “bounded by default” stance
- **REF-DICE-ANDROID** — Android DICE documentation — https://source.android.com/docs/security/features/dice  
  - key: adoption example; identity chain for firmware loaded during boot
  - why: demonstrates DICE used at scale and how identities relate to boot sequence
  - us: operational reference for profiling assumptions and deployment constraints


- **REF-LINUX-FSVERITY** — Linux kernel docs: fs-verity (read-only file authenticity/integrity via Merkle trees) — https://docs.kernel.org/filesystems/fsverity.html
  - key: file-level Merkle-tree verified reads with a pinned file digest/measurement
  - why: production precedent for “verify on read” without hashing entire files up front
  - us: informs D-VERITY + CH-VBLOB digest/root semantics and fail-closed read behavior
- **REF-LINUX-DMVERITY** — Linux kernel docs: dm-verity device-mapper target — https://docs.kernel.org/admin-guide/device-mapper/verity.html
  - key: block-device integrity verification using a hash tree and a pinned root hash
  - why: widely deployed base-image integrity pattern (read-only verified volumes)
  - us: informs D-VERITY volume-level option and bounded cache/verification posture
- **REF-ANDROID-DMVERITY** — Android docs: implement dm-verity — https://source.android.com/docs/security/features/verifiedboot/dm-verity
  - key: practical deployment guidance for verity-protected partitions in a large ecosystem
  - why: shows how verity roots are managed and integrated with boot/update workflows
  - us: grounding for D-VERITY integration with D-BOOT/D-ATOMICUPD style policies
- **REF-ANDROID-AVB2-README** — Android Verified Boot (AVB) 2.0 reference README — https://android.googlesource.com/platform/external/avb/+/master/README.md
  - key: VBMeta digest chain-of-trust and how root hashes for verified partitions are bound into boot policy
  - why: concrete design for binding verity roots into a boot-verified metadata structure
  - us: informs how D-BOOT/attestation artifacts can pin verity roots and keep “what booted” answerable

- **REF-VENTI-FAST02** — Quinlan & Dorward, *Venti: A New Approach to Archival Data Storage* (FAST 2002) — https://www.usenix.org/conference/fast-02/venti-new-approach-archival-data-storage

- **REF-FOUNDATION-CAS** — Rhea, Cox, Pesterev, *Fast, Inexpensive Content-Addressed Storage in Foundation* — https://swtch.com/~rsc/papers/fndn/

- **REF-FIPS180-4** — NIST, *FIPS 180-4: Secure Hash Standard (SHS)* — https://nvlpubs.nist.gov/nistpubs/fips/nist.fips.180-4.pdf
  - key: normative definition of SHA-1/SHA-2 family including SHA-256
  - why: pins our v0 digest function to a stable, widely reviewed primary spec
  - us: supports D-HASH v0 (SHA-256/32-byte digests) without inventing a bespoke digest format
- **REF-RFC6234** — IETF, *RFC 6234: US Secure Hash Algorithms (SHA and SHA-based HMAC and HKDF)* — https://www.rfc-editor.org/rfc/rfc6234.html
  - key: operational conventions and parameterization for SHA-2 (incl. SHA-256)
  - why: convenient, stable web reference for implementers alongside FIPS
  - us: supports D-HASH v0 documentation and test vectors / implementer clarity

- **REF-RFC6920** — IETF, *RFC 6920: Naming Things with Hashes* — https://www.rfc-editor.org/rfc/rfc6920.html
  - key: `ni:` / `nih:` identifiers and HTTP mapping for hash-named objects
  - why: a standards-track pattern for content-named references (rarely adopted, but sharp)
  - us: candidate locator scheme for CH-AREF and a justification for digest-first typed ids (D-TYPEDID)
- **REF-GIT-HASH-TRANSITION** — Git documentation: *hash-function-transition* — https://git-scm.com/docs/hash-function-transition
  - key: Git as a content-addressed store; formal object naming formula; real SHA-1→SHA-256 transition constraints
  - why: hard-earned lessons on hash agility and the cost of letting multiple encodings leak into surfaces
  - us: keep hash agility profile-scoped and treat digest ids as opaque bytes on privileged seams (D-TYPEDID)
- **REF-MULTIHASH** — Multiformats: *Multihash (self-describing hashes)* — https://multiformats.io/multihash/
  - key: prefix-coded hash algorithm + length so bytes are self-describing
  - why: allows multi-hash coexistence and planned upgrades without ambiguous parsing
  - us: potential future for CH-AREF locators or cross-profile interop; v0 still prefers a fixed profile digest for tiny validators

- **REF-ERIGHTS-OCAP-OVERVIEW** — erights.org, *Object-Capability Model Overview* — https://www.erights.org/elib/capability/overview.html

- **REF-ERIGHTS-POWERBOX** — ERights Wiki, *Capability Patterns: Powerbox Capability Manager* — https://wiki.erights.org/wiki/Walnut/Secure_Distributed_Computing/Capability_Patterns

- **REF-DARPABROWSER-REPORT** — Stiegler, *DarpaBrowser: Final Report* (CapDesk/Powerbox) — https://w.erights.org/papers/darpa-report/html/index.html

## Least-privilege sandboxes & user-driven authorization UX
- **REF-MAKE-LEASTPRIV-RIGHT** — Krohn et al., *Make Least Privilege a Right (Not a Privilege)* — https://www.scs.stanford.edu/~dm/home/papers/krohn%3Aleast-privilege.pdf
  - key: OS affordances and UX patterns that make POLA/least-privilege *easy* rather than exceptional
  - why: least-privilege fails as a product problem as much as a mechanism problem
  - us: treat portals/powerbox/promises as first-class ergonomics, not bolt-ons
- **REF-PLASH** — Seaborn, *Plash: tools for practical least privilege* — https://plash.beasts.org/index.html
  - key: capability-inspired wrappers for legacy Unix programs (filesystem view control + explicit authority handoff)
  - why: shows a migration path for least-privilege without rewriting the world
  - us: informs our compat-domain + view-object wrapper tooling (RFC-0016/D-NS)
- **REF-POLARIS-SOUPS05** — Yee et al., *Polaris: Usable Virus Protection for Windows* (SOUPS 2005 poster) — https://cups.cs.cmu.edu/soups/2005/2005posters/9-yee.pdf
  - key: run unmodified apps under least-privilege via isolated environments + explicit user-mediated file access
  - why: reinforces that compatibility layers need first-class UX for safe file/network handoff
  - us: motivates ‘compat launcher + powerbox’ patterns and default-deny namespaces
- **REF-UDAC-SP12** — Roesner et al., *User-Driven Access Control: Rethinking Permission Granting and Enforcement* (IEEE S\&P 2012) — https://www.microsoft.com/en-us/research/wp-content/uploads/2011/08/user-driven-access-control-nov2011.pdf
  - key: translate user intent embedded in UI actions into system-level access control decisions (ACGs)
  - why: permission prompts are brittle; in-context grants reduce confused-deputy UX failure modes
  - us: complements D-VOLITION + D-POWERBOX: standardize intent tokens + ‘access control gadgets’
- **REF-KANTARA-CONSENT-RECEIPT** — Kantara Initiative, *Consent Receipt Specification* — https://kantarainitiative.org/kantara-initiative-releases-an-open-global-consent-receipt-specification-meets-gdpr-requirements-free-for-download/
- **REF-RFC7807** — IETF, *RFC 7807: Problem Details for HTTP APIs* — https://www.rfc-editor.org/rfc/rfc7807
  - key: standardized, human-readable (and machine-readable) “receipt” recording what consent was granted, when, and under what conditions
  - why: durable, portable proof of authorization improves auditability and helps users understand and revoke prior grants
  - us: motivates CH-RECEIPT v0 as a non-authoritative, digest-bound record for D-EXPLAIN (permissions as receipts, not global toggles)
- **REF-ISO27560-DPV-GUIDE** — DPV guide, *Consent Records and Receipts as per ISO/IEC TS 27560:2023* — https://w3id.org/dpv/guides/consent-27560
  - key: guidance on structuring consent records/receipts with explicit fields and lifecycle semantics (expiry, change, revocation)
  - why: receipts without lifecycle semantics rot; explicit metadata enables compliance and operational debugging
  - us: informs receipt fields (expiry/revocation epoch) and “receipt ledger” lifecycle in D-EXPLAIN
- **REF-FELT-PERMISSIONS-2012** — Felt et al., *Towards Comprehensible and Effective Permission Systems* (UC Berkeley Tech Report, 2012) — https://www2.eecs.berkeley.edu/Pubs/TechRpts/2012/EECS-2012-185.pdf
  - key: users struggle with permission meaning; systems can improve comprehension via context, grouping, and principled UI design
  - why: consent UX is a primary failure mode; better summaries reduce “always allow” behavior
  - us: motivates authority-diff previews and structured summaries (I-EXPLAIN-1) rather than ad-hoc prompts
- **REF-CISPA-RATIONALE-2025** — CISPA, *How wording influences consent behavior for app permissions* (2025) — https://cispa.de/en/rationals
  - key: permission “rationale” wording measurably influences user consent decisions
  - why: free-form rationales are an attack surface (dark patterns); they must be constrained and treated as untrusted
  - us: supports D-EXPLAIN’s rule that bound summaries/diffs are canonical and requester text is decoration only
- **REF-AUTHORITY-ANALYSIS-LP07** — Lowe, *Authority Analysis for Least Privilege Environments* (2007) — https://www.cs.ox.ac.uk/files/2689/analysing_authority.pdf
  - key: analyze authority requirements to help shrink privilege in real systems
  - why: practical least-privilege needs tooling, not just mechanisms
  - us: informs cap-graph linting + ‘unused authority’ CI gates for components
- **REF-SHILL-OSDI14** — Moore et al., *SHILL: A Secure Shell Scripting Language* (OSDI 2014) — https://users.cs.northwestern.edu/~chrdimo/pubs/osdi14-mdkc.pdf
  - key: capability-based scripting with explicit contracts; sandboxes even native executables spawned by scripts
  - why: scripts are a major “ambient authority” vector in real deployments
  - us: motivates a capability-safe automation DSL/tooling layer (scripts as components with declared caps)
- **REF-SANDBOX-ADOPTION-ARXIV24** — Alhindi & Hallett, *Sandboxing Adoption in Open Source Ecosystems* (ACM/IEEE SoSE 2024 workshop; arXiv 2024) — https://arxiv.org/html/2405.06447v1
  - key: empirical adoption study across Debian/Fedora/OpenBSD/FreeBSD; <1% of packages directly call sandbox APIs
  - why: shows “mechanism exists” ≠ adoption; ergonomics and incremental hardening dominate
  - us: prioritize wrapper-first + learn-mode + declarative contracts (D-SEAL/D-CAPSHELL) so sandboxing is the path of least resistance
- **REF-LEASH-CAPSICUM-2025** — Jadidi et al., *Leash: A Transparent Capability-Based Sandboxing Supervisor for Unix Systems* (2025) — https://www.scitepress.org/Papers/2025/131867/131867.pdf
  - key: supervisor/wrapper approach applying Capsicum sandboxes without app source changes
  - why: practical evidence that “transparent wrappers” can deliver least privilege in real ecosystems
  - us: validates the compat-launcher direction; informs learn-mode diagnostics and authority handoff UX
- **REF-UCON-ABC** — Park & Sandhu, *The UCONABC Usage Control Model* (TISSEC 2004) — https://profsandhu.com/journals/tissec/ucon-abc.pdf
  - key: usage control unifies authorizations, obligations, and conditions with ongoing/continuous enforcement
  - why: matches real permission systems (foreground/indicators/expiry) better than one-shot allow prompts
  - us: treat portals as usage-control boundaries: leases + indicators + receipts + continuous checks
- **REF-UCON-ABC-ACM** — Park & Sandhu, UCONABC (ACM DL entry) — https://dl.acm.org/doi/abs/10.1145/984334.984339
  - key: canonical DOI pointer for citation/metadata
  - why: stable entry when a DOI reference is preferred
  - us: bibliography alias for REF-UCON-ABC
- **REF-BISBEY78** — Bisbey & Hollingworth, *Protection Analysis: Final Report* (1978) — https://seclab.cs.ucdavis.edu/projects/history/papers/bisb78.pdf
  - key: classic taxonomy of OS vulnerabilities; highlights name-binding and validation failures as protection errors
  - why: “paths” and name resolution are hazardous authority carriers; mistakes are security flaws
  - us: reinforces view objects + handles-not-paths + TOCTOU-resistant portal flows
- **REF-TAOUP-SECWRAP** — Raymond, *The Art of Unix Programming*: Security wrappers and Bernstein chaining — https://www.catb.org/~esr/writings/taoup/html/ch06s06.html
  - key: wrapper processes that acquire privilege briefly, then drop to least privilege for steady-state
  - why: a simple pattern that scales to messy legacy ecosystems
  - us: aligns with our init→seal posture (D-SEAL) and supports wrapper-based hardening for compat domains
## Microkernel component frameworks & resource accounting
- **REF-GENODE-CORE** — Genode architecture: core + RAM sessions (quota model) — https://genode.org/documentation/architecture/core  
  - key: RAM sessions are quota-bounded allocators; quota is explicitly transferred/loaded
  - why: makes resource exhaustion attributable and composable
  - us: informs D-METER + D-KOBJQ charging rules and refund semantics
- **REF-GENODE-SESSIONS** — Genode common session interfaces (quota at session creation) — https://genode.org/documentation/genode-foundations/24.05/components/Common_session_interfaces.html  
  - key: session creation carries explicit quota; parents provision children
  - why: recursive system structure scales least-privilege + resource control
  - us: map “service trees” and budget delegation to explicit contracts, not global config
- **REF-GENODE-RESMGMT** — Genode forum: kernel resources must be paid for (cap quota) — https://genode.discourse.group/t/system-resource-management/160  
  - key: kernel-maintained object references are scarce; cap quota is first-class
  - why: prevents subtle DoS and “cap leak” pathologies
  - us: charge cap slots/endpoints/notifications to meters when D-KOBJQ is enabled
- **REF-GENODE-MANUAL** — Genode OS Framework manual (N. Feske, 2015) — https://genode.org/files/53bcb8e33fe6602fed25edc3c7b922c5/manual-2015-04-27.pdf  
  - key: recursive, sandboxed component structure; explicit resource assignment
  - why: shows a pragmatic, capability-first OS framework at scale
  - us: harvest patterns for routing, quotas, and restartable subsystems
- **REF-GENODE-SIGNALS** — Genode Base API: asynchronous notifications / signals — https://genode.org/documentation/api/base_index  
  - key: capability-addressed fire-and-forget notifications with reliable counting and no payload
  - why: a mature ocap system keeps notifications smaller than RPC and refuses to smuggle data/authority through them
  - us: motivates a D-CAPRPC oneway adjunct that stays bounded, attachment-free, and non-mailbox in Phase 1

- **REF-BANGA-RESCONTAINERS** — Banga/Druschel/Mogul, *Resource Containers: A New Facility for Resource Management in Server Systems* (OSDI 1999) — https://www.usenix.org/events/osdi99/full_papers/banga/banga.pdf  
  - key: separate protection domains from resource principals (“who pays?”)
  - why: sponsorship/billing confusion is a persistent DoS bug source
  - us: model meters as first-class payers; make payer explicit for resource-creating effects (I-METER-3, PO-METER-PAYER)
- **REF-CGROUPV2** — Linux Kernel docs: Control Group v2 — https://docs.kernel.org/admin-guide/cgroup-v2.html  
  - key: unified hierarchical resource control interface
  - why: hierarchy + delegation patterns are proven in practice (containers, systemd)
  - us: align meter trees with a familiar mental model; avoid reinventing ad-hoc quota plumbing
- **REF-CGROUP-DELEGATION** — systemd.io: cgroup APIs and delegation — https://systemd.io/CGROUP_DELEGATION/  
  - key: practical subtree delegation rules and interface pitfalls
  - why: delegation is where real systems break (ownership, boundaries, surprises)
  - us: treat meter split as explicit delegation with transcript-visible lineage (PO-METER-DELEGATE)
- **REF-MAN7-SYSTEMD-RESOURCE-CONTROL** — systemd manual page: `systemd.resource-control(5)` — https://www.freedesktop.org/software/systemd/man/systemd.resource-control.html
  - key: service units may impose CPU, memory, IO, and task-count controls such as `CPUWeight=`, `CPUQuota=`, `MemoryHigh=`, `MemoryMax=`, and `TasksMax=`
  - why: service-manager resource envelopes are a real hidden launch baseline in mainstream deployments
  - us: supports the capshell resource-envelope posture: reviewed automation should not silently depend on wrapper/service-manager resource ceilings that were never expressed in CH-EXECPACK
- **REF-FUCHSIA-JOBS** — Fuchsia concepts: Jobs — https://fuchsia.dev/fuchsia-src/concepts/process/jobs  
  - key: job tree as a container for processes with top-down policies/quotas
  - why: shows a modern object-based kernel surfacing resource limits in a capability-flavored way
  - us: informs our meter-tree model and exception/supervision boundaries

- **REF-WIN-JOBOBJECTS** — Microsoft Learn: Job Objects (Win32) — https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects
  - key: a securable “process group” object with top-down limits, accounting, and lifecycle control
  - why: real systems need a crisp answer to “who owns these children?” and “who can cap/kill them?”
  - us: treat supervised subtrees as explicit container objects; align meter trees with group lifecycle (D-METER, D-SUPV)
- **REF-ZIRCON-OBJECTS** — Fuchsia reference: Zircon kernel objects overview — https://fuchsia.dev/fuchsia-src/reference/kernel_objects/objects  
  - key: handles with rights; kernel objects as the primary resource interface
  - why: reinforces “object handles, not ambient globals” as an ecosystem-enabling discipline
  - us: keep CH-KABI effects object-mediated; combine with CH-METER for resource attribution
- **REF-FREEBSD-RCTL** — FreeBSD: rctl resource limits (handbook + manpage entrypoint) — https://man.freebsd.org/cgi/man.cgi?query=rctl  
  - key: fine-grained resource limits applied to subjects (process/jail/user)
  - why: operationally mature resource limiting shows what users actually need
  - us: sanity-check which resource kinds matter early (threads/processes/memory/CPU) without importing policy into the kernel


## UI boundary & trusted input (compositor as a security seam)

- **REF-WAYLAND-CH04** — Wayland protocol: *Model of Operation* (Chapter 4) — https://wayland.freedesktop.org/docs/html/ch04.html  
  - key: surfaces are compositor-owned objects; clients cannot access other clients’ surfaces and do not know global surface position
  - why: practical precedent for compositor-mediated pixel isolation and focus-routed input
  - us: anchor D-UICAP to an existence-proof model without committing to a specific toolkit/stack
- **REF-WAYLAND-APA-DATADEVICE** — Wayland protocol specification (Appendix A): `wl_data_device` (copy/paste + drag-drop) — https://wayland.freedesktop.org/docs/html/apa.html  
  - key: explicit offer→accept handshake (`wl_data_source`/`wl_data_offer`) and byte transfer on a passed file descriptor
  - why: shows clipboard/drag-drop as explicit inter-client transfers, not ambient global state
  - us: motivates portal-mediated transfer grants and CH-XFER v0 bounds


- **REF-FUCHSIA-VIEWREF** — Fuchsia Scenic: ViewRefs and view tree concepts — https://fuchsia.dev/fuchsia-src/development/graphics/scenic/concepts/view_ref  
  - key: opaque view identity token used for lifecycle/focus chain participation without granting control
  - why: shows how “identity without authority” can be operationalized in a modern component OS
  - us: inspires UiToken/ViewRef patterns for D-UICAP

- **REF-FUCHSIA-FOCUSCHAIN** — Fuchsia Scenic: focus chain concepts — https://fuchsia.dev/fuchsia-src/development/graphics/scenic/concepts/focus_chain  
  - key: focus chain encodes view-tree hierarchy and is considered sensitive; access is restricted to trusted components (e.g., accessibility manager)  
  - why: shows that even focus metadata can be security-relevant  
  - us: informs D-UICAP posture: restrict focus-chain disclosure and gate any “global input” features behind explicit trusted capabilities  

- **REF-ANDROID-ACCESSIBILITYSERVICE** — Android Developer: AccessibilityService API overview — https://developer.android.com/reference/android/accessibilityservice/AccessibilityService  
  - key: accessibility services can observe UI events and perform actions on behalf of the user; access is mediated by an explicit user enablement flow
  - why: shows that assistive tooling is a legitimate need but is inherently high-risk
  - us: motivates D-UIAUT: observation/injection split, portal mediation, TTL leases, and audit descriptors (CH-UIAUT)

- **REF-APPLE-ACCESSIBILITY-TRUST** — Apple Developer: `AXIsProcessTrustedWithOptions` (accessibility permission gate) — https://developer.apple.com/documentation/applicationservices/1459186-axisprocesstrustedwithoptions
  - key: APIs allow checking/requesting whether the process is trusted for accessibility features
  - why: existence-proof of OS-mediated gating for accessibility/automation power
  - us: supports modeling a11y/automation authority as explicit sessions with indicators and policy clamps (D-UIAUT)

- **REF-WIN-UIACCESS** — Microsoft: `uiAccess` application manifest element (UI privilege for accessibility apps) — https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-securityoverview
  - key: Windows supports a dedicated “UI access” posture for certain assistive applications via manifest + trust requirements
  - why: shows that ecosystems need a standard, explicit way to treat UI automation as privileged
  - us: supports D-UIAUT and reinforces that global injection/observation must be explicit and auditable

- **REF-APPLE-TN2150-SECEVENTINPUT** — Apple Technical Note TN2150: Using Secure Event Input Fairly — https://leopard-adc.pepas.com/technotes/tn2007/tn2150.html  
  - key: `EnableSecureEventInput` blocks keyboard-intercept processes from seeing keystrokes during sensitive entry; callers must disable it promptly  
  - why: existence-proof of an OS-level “secure keyboard entry” mode with real ecosystem impact  
  - us: motivates an optional “secure input session” seam under D-UICAP for password/consent surfaces (lease/TTL to avoid stuck-on states)  

- **REF-IBM-AIX-TRUSTEDPATH** — IBM AIX: trusted path, trusted shell, and Secure Attention Key — https://www.ibm.com/docs/en/aix/7.2.0?topic=security-trusted-path-trusted-shell-secure-attention-key  
  - key: Secure Attention Key (SAK) establishes a trusted communication path to the system for login/password changes  
  - why: non-Windows precedent that the “trusted path entry” problem is universal  
  - us: supports D-UICAP secure-attention semantics and threat-model coverage for fake-login UI  

- **REF-MS-WINLOGON-SAS** — Microsoft Win32: Initializing Winlogon (Secure Attention Sequence registration) — https://learn.microsoft.com/en-us/windows/win32/secauthn/initializing-winlogon  
  - key: Winlogon registers Ctrl+Alt+Del as a secure attention sequence (SAS) so other apps can’t intercept it
  - why: canonical “trusted path entry” pattern to mitigate fake login/credential UI
  - us: informs optional secure-attention delivery in D-UICAP/D-VOLITION profiles

- **REF-ANDROID-BIOMETRICPROMPT** — Android Developers: Show a biometric authentication dialog — https://developer.android.com/identity/sign-in/biometric-auth  
  - key: the biometric authentication prompt is a **system-provided dialog** that is consistent across apps, and authentication type is surfaced explicitly
  - why: deployed precedent for keeping high-risk human verification inside a shell-owned/system-owned prompt rather than app-drawn UI
  - us: supports D-VOLITION posture that user-verification factors stay inside the trusted UI path and remain bound to one exact approval interaction

- **REF-MS-UAC-SECUREDESKTOP** — Microsoft Learn: How User Account Control works (secure desktop elevation prompts) — https://learn.microsoft.com/en-us/windows/security/application-security/application-control/user-account-control/how-it-works
  - key: elevation prompts switch from the user desktop to a dimmed secure desktop that must be responded to before continuing
  - why: concrete precedent that privileged prompts are hosted in a visually distinct mode that occludes the normal desktop
  - us: supports D-UICAP v0 SAS/secure UI mode semantics (freeze/occlude normal surfaces for login/consent)


## Desktop portals & workflow routing

- **REF-XDG-PORTAL** — xdg-desktop-portal documentation — https://flatpak.github.io/xdg-desktop-portal/  
  - key: portal APIs for file access/open-uri/printing/etc via a well-known service
  - why: practical containment pattern deployed on Linux desktops
  - implication: D-PLUMB should return handles/caps, not host paths

- **REF-XDG-PORTAL-REQUEST** — xdg-desktop-portal: Request interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html  
  - key: portal methods return a request handle/object that lives for the duration of the user interaction and emits a `Response` signal when complete
  - why: deployed precedent for request-local completion rather than durable per-app inboxes
  - implication: core D-PLUMB should stay request/response-ish in Phase 1, with bounded request-local completion rather than a generic held-message pickup service

- **REF-XDG-PORTAL-SESSION** — xdg-desktop-portal: Session interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.impl.portal.Session.html  
  - key: long-lived portal families use explicit provider-owned session objects that live for the duration of the session and may be closed by the provider
  - why: strong precedent that portal session lifecycle is a family-owned control object, not a generic resumable capability export
  - implication: D-PLUMB core should keep long-lived sessions family-local and decline a family-agnostic session inventory/resume layer

- **REF-XDG-PORTAL-OPENURI** — xdg-desktop-portal: OpenURI interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html  
  - key: portal workflow to open external URIs and to open/show local items via the host
  - why: makes “open a link / show in file manager” a mediated workflow instead of ambient exec
  - implication: model OpenUri as a portal family (`portal.uri.*`) so sandboxes don’t need ambient `exec` or host tools

- **REF-ANDROID-PACKAGE-VISIBILITY** — Android Developers: Package visibility filtering on Android — https://developer.android.com/training/package-visibility  
  - key: Android filters installed-app visibility by default for apps targeting Android 11+ because the installed-app graph is privacy-sensitive
  - why: “which handlers are installed?” is itself sensitive metadata, not a free probe surface
  - implication: `portal.uri.*` should not expose generic handler inventory or preflight probing to requesters in Phase 1

- **REF-XCALLBACK-URL** — x-callback-url specification — https://x-callback-url.com/specification/  
  - key: standardizes callback parameters like `x-success`, `x-error`, and `x-cancel` so a target app can return control/data to the source app via URL callbacks
  - why: clear example of how a launcher/intents seam can quietly become a callback protocol and second rendezvous channel
  - implication: D-PLUMB v0 should decline callback URL/port registries on the portable seam and keep outcomes on request-local response/receipt paths instead

- **REF-APPLE-CANOPENURL** — Apple Developer Documentation: `UIApplication.canOpenURL(_:)` — https://developer.apple.com/documentation/uikit/uiapplication/canopenurl%28_%3A%29  
  - key: probing whether a URL can be opened is an explicit API surface with declared-scheme requirements
  - why: Apple treats handler discovery as a controlled capability rather than ambient launcher trivia
  - implication: avoid a generic app-visible “can I open this?” oracle under `portal.uri.*`

- **REF-APPLE-LSAPPLICATIONQUERIESSCHEMES** — Apple Launch Services Keys: `LSApplicationQueriesSchemes` — https://developer.apple.com/library/archive/documentation/General/Reference/InfoPlistKeyReference/Articles/LaunchServicesKeys.html  
  - key: apps must declare which URL schemes they intend to test with `canOpenURL:`
  - why: constraining URI-handler probing reduces installed-app fingerprinting
  - implication: SlopOS should keep default-handler memory and scheme-support knowledge shell-owned in Phase 1
- **REF-XDG-PORTAL-PRINT** — xdg-desktop-portal: Print interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Print.html  
  - key: multi-step print workflow (prepare settings, then submit) mediated by a well-known portal
  - why: printing is bidirectional and an exfiltration/parser surface; avoid ambient access to host print subsystems
  - implication: treat printing as a portal family (`portal.print.*`) and gate it like other high-risk workflows
- **REF-ANDROID-PRINT-FRAMEWORK** — Android Developers: Printing custom documents — https://developer.android.com/training/printing/custom-docs  
  - key: apps start a print job through `PrintManager`; the framework asks a `PrintDocumentAdapter` to lay out and write the final print document after user-selected settings are known
  - why: printing is a user-mediated render pipeline, not raw printer access or queue authority
  - implication: SlopOS should keep `portal.print.*` render-first and shell-spooled rather than exposing printer transport/driver APIs to apps
- **REF-ANDROID-KITKAT-PRINTING** — Android 4.4 (KitKat) for Developers — https://developer.android.com/about/versions/kitkat  
  - key: the platform print manager mediates between apps and installed print services, provides shared system UI, and ensures the security of content as it passes across processes
  - why: printing is a system mediation boundary with both UX and cross-process security obligations
  - implication: keep printer discovery, queue policy, and print-service interaction shell-owned in Phase 1
- **REF-APPLE-UIPRINTINTERACTIONCONTROLLER** — Apple Developer Documentation: `UIPrintInteractionController` — https://developer.apple.com/documentation/uikit/uiprintinteractioncontroller  
  - key: the shared interaction controller represents a print job and is the central class for printing in iOS/iPadOS/Mac Catalyst
  - why: primary-platform precedent for printing as an explicit system-controlled interaction, not ambient printer API access
  - implication: SlopOS should keep print workflow user-mediated and avoid app-visible printer inventory or durable queue authority in v0
- **REF-XDG-PORTAL-USB** — xdg-desktop-portal: Usb interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Usb.html  
  - key: mediated monitoring + access requests for connected USB devices
  - why: concrete precedent that “device access” is a workflow (not ambient `/dev`)
  - implication: expose device leasing/authorization via a portal family (`portal.device.*`) aligned with D-DEVGUARD/D-IOLEASE
- **REF-ANDROID-USB-HOST** — Android Developers: USB host overview — https://developer.android.com/develop/connectivity/usb/host  
  - key: apps discover devices, then must obtain user permission before communicating with a chosen USB device
  - why: deployed precedent for explicit per-device approval without ambient bus-wide authority
  - implication: keep future SlopOS device automation keyed to an explicit `device_id`/request flow rather than port-path or global device-list authority

- **REF-XDG-PORTAL-CLIPBOARD** — xdg-desktop-portal: Clipboard interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Clipboard.html  
  - key: session-based clipboard access requests mediated by a well-known portal service
  - why: concrete precedent for “clipboard is a portal,” not a broadcast channel
  - implication: D-PLUMB clipboard/drag-drop should mint leased payload grants and emit a bounded transfer descriptor (CH-XFER)
- **REF-XDG-PORTAL-NOTIFICATION** — xdg-desktop-portal: Notification portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Notification.html  
  - key: sandboxed apps can send/withdraw notifications via a portal; the app cannot learn whether the notification was presented
  - why: central mediation point; avoids a high-fidelity “was it shown?” side channel
  - implication: D-ATTN notifications should be portal-mediated, budgeted, and origin-branded

- **REF-XDG-PORTAL-NETWORKMONITOR** — xdg-desktop-portal: NetworkMonitor interface docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.NetworkMonitor.html  
  - key: mediated network status API for sandboxed apps; not a user-interaction portal
  - why: demonstrates how “network awareness” can be provided without ambient host access
  - implication: prefer portal-mediated network observability; keep outbound connectivity separate and explicitly granted (D-NETLEASE)

- **REF-ANDROID-LOCAL-NET** — Android Developer: Local network permission (Local Network Protections) — https://developer.android.com/privacy-and-security/local-network-permission  
  - key: gates local-network access behind a runtime permission for user privacy
  - why: local networks are sensitive (device discovery + lateral movement)
  - implication: D-NETLEASE should distinguish `local` vs `internet` scope; default deny for disposables

- **REF-LITTLESNITCH** — Objective Development: Little Snitch connection alerts overview — https://help.obdev.at/littlesnitch4/alert-overview  
  - key: prompts the user when an unruled outbound connection occurs; creates allow/deny rules
  - why: per-connection prompting is powerful but can fatigue users
  - implication: support prompt-style policy as an option, but anchor decisions in receipts and allow predeclared safe rules (D-EXPLAIN, D-NETLEASE)

- **REF-MACOS-NETWORKEXT** — Apple Developer: NetworkExtension framework documentation — https://developer.apple.com/documentation/networkextension  
  - key: OS-mediated VPN/relay/content-filter hooks for controlling network traffic
  - why: illustrates that practical per-app control often lives in a dedicated mediation subsystem
  - implication: keep network mediation out of the kernel core; treat it as a portal-backed service with strong boundaries


- **REF-ANDROID-NOTIF-CHANNELS** — Android Developer: create and manage notification channels — https://developer.android.com/develop/ui/views/notifications/channels  
  - key: channels with user-tunable importance levels determine interruption behavior
  - why: scalable control surface for spam/interruption management
  - implication: D-ATTN should use channels + budgets as first-class policy objects

- **REF-APPLE-NOTIF-HIG** — Apple Human Interface Guidelines: managing notifications — https://developer.apple.com/design/human-interface-guidelines/managing-notifications  
  - key: permission and UX guidance for notifications; emphasizes avoiding unnecessary interruptions
  - why: attention is scarce; good defaults prevent notification fatigue
  - implication: default budgets should be conservative; urgent paths must be explicit

- **REF-APPLE-CRITICAL-ALERTS** — Apple Developer: critical alerts entitlement — https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.usernotifications.critical-alerts  
  - key: special authorization for alerts that bypass mute/DND behaviors
  - why: “urgent” channels need explicit elevated consent
  - implication: D-ATTN urgent alerts should be capability-gated and still budgeted

- **REF-NOTIF-PHISH-WOOT12** — USENIX WOOT 2012: abusing notification services on smartphones for phishing and spamming (Xu et al.) — https://www.usenix.org/conference/woot12/workshop-program/presentation/xu  
  - key: notification customization can enable phishing/spam; platforms with stronger origin attribution reduce impact
  - why: notifications are a UI-security surface, not just a UX feature
  - implication: enforce unspoofable origin branding and bounded, non-executable notification content

- **REF-TAPTRAP-SEC25** — USENIX Security 2025: TapTrap (animation-driven tapjacking on Android) — https://www.usenix.org/system/files/usenixsecurity25-beer.pdf  
  - key: UI redressing via animation can subvert permission/intent UX
  - why: reinforces the need for a trusted UI path and action binding
  - implication: notification actions must be volition-gated and bound to digests at render time


- **REF-XDG-PORTAL-SCREENCAST** — xdg-desktop-portal: ScreenCast portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.ScreenCast.html  
  - key: session-based screencast API; persistence modes and restore tokens exist but are optional
  - why: high-risk portal families need explicit lifetimes and revocation
  - implication: model ScreenCast grants as revocable leases with TTL/renew UX
- **REF-XDG-PORTAL-SCREENSHOT** — xdg-desktop-portal: Screenshot portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Screenshot.html  
  - key: sandboxed apps request screenshots via a portal; the portal mediates capture and returns the result to the requester
  - why: demonstrates a real-world mediation pattern for a high-risk UI authority
  - implication: treat screenshots as portal-mediated leased capabilities under D-UICAP + D-PLUMB
- **REF-XDG-PORTAL-REMOTEDESKTOP** — xdg-desktop-portal: RemoteDesktop portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.RemoteDesktop.html  
- **REF-XDG-PORTAL-CAMERA** — xdg-desktop-portal: Camera portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Camera.html  
  - key: mediated access to camera devices for sandboxed apps
  - why: demonstrates per-session user-mediated grants for a high-risk device class
  - implication: model camera access as a portal-issued lease with explicit scope and revocation

- **REF-ANDROID-MEDIAPROJECTION** — Android Developers: Media projection — https://developer.android.com/media/grow/media-projection  
  - key: each media-projection session requires user consent; on Android 14+ the token is single-use and `createVirtualDisplay()` cannot be called repeatedly from one grant
  - why: demonstrates a deployed “explicit start, no silent session replay” posture for screen capture
  - implication: keep Phase 1 capture starts interactive and avoid remembered-session drift
- **REF-APPLE-SCREENCAPTUREKIT** — Apple Developer: Capturing screen content in macOS — https://developer.apple.com/documentation/ScreenCaptureKit/capturing-screen-content-in-macos  
  - key: screen capture requires Screen Recording permission; Apple treats screen capture as a mediated privacy surface
  - why: reinforces that screen capture should be explicit and user-visible rather than ambient
  - implication: keep capture initiation outside ambient APIs and bind it to explicit workflow state
- **REF-APPLE-CONTROL-CENTER-PRIVACY** — Apple Support: Use Control Center on Mac — https://support.apple.com/guide/mac-help/quickly-change-settings-mchl50f94f8f/mac  
  - key: macOS surfaces privacy indicators for microphone, camera, system-audio recording, and location in Control Center/menu bar
  - why: shows the value of a shell-owned indicator surface rather than app-controlled affordances
  - implication: treat non-spoofable indicator state as part of the capture contract

- **REF-PIPEWIRE-ACCESS** — PipeWire docs: Access Control — https://docs.pipewire.org/page_access.html  
  - key: per-client permissions on objects in the media graph
  - why: existence proof that a user-space media server can enforce object-level access controls
  - implication: keep media routing policy out of the privileged core; treat graph access as capability-granted
- **REF-PIPEWIRE-SESSMGR** — PipeWire docs: Session Manager — https://docs.pipewire.org/page_session_manager.html  
  - key: session manager decides which devices are opened and whether clients may access specific resources
  - why: illustrates clean separation of mechanism (graph) and policy (session manager)
  - implication: adopt a portal/session-manager split for capture permissions and routing

- **REF-XDG-PORTAL-AUDIO-ISSUE** — xdg-desktop-portal: Audio portal discussion (static mic permissions problem statement) — https://github.com/flatpak/xdg-desktop-portal/issues/1129  
  - key: highlights that sandboxed audio access often remains a static permission (socket grants) with poor granularity
  - why: motivates making microphone capture a portal-mediated session (like camera/screencast)
  - implication: bake in a first-class mic capture portal in greenfield designs
- **REF-XDG-PORTAL-FILECHOOSER** — xdg-desktop-portal: FileChooser portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileChooser.html  

- **REF-XDG-PORTAL-DOCUMENTS** — xdg-desktop-portal: Documents portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html  
  - key: controlled export of selected host files into a restricted per-app view (document portal / docfs idea)
  - why: concrete precedent for persistent “recent documents” UX in sandboxes without returning host paths
  - implication: standardize a durable, non-bearer document handle (CH-DOCREF) and make persistence explicit (RFC-0089)

- **REF-FLATPAK-SANDBOX-PERMS** — Flatpak docs: sandbox permissions — https://docs.flatpak.org/en/latest/sandbox-permissions.html  
  - key: real-world permission surfaces (filesystem, devices, portals) and the UX/policy tradeoffs
  - why: validates that “portal-first” is how desktop sandboxes stay usable
  - implication: prefer portal-mediated, receipt-bound, revocable grants for high-risk authority (D-PLUMB/D-POWERBOX/D-EXPLAIN)

- **REF-SANDSTORM-POWERBOX** — Sandstorm docs: Powerbox (capability picker UI) — https://docs.sandstorm.io/en/latest/developing/powerbox/  
- **REF-PLASH-POWERBOX** — Plash: *The powerbox: a GUI for granting authority* — https://plash.beasts.org/powerbox.html  
- **REF-YEE-UIDSS-2002** — Yee, *User Interaction Design for Secure Systems* (UC Berkeley tech report) — https://www2.eecs.berkeley.edu/Pubs/TechRpts/2002/CSD-02-1184.pdf  
  - key: session-based remote-desktop API (input capture)
  - why: remote control is a top-tier privilege; must be lease-based and transcripted
  - implication: D-PLUMB should treat RemoteDesktop as a lease requiring fresh user volition

- **REF-ANDROID-SAF-DOCUMENTS** — Android Developers: Storage Access Framework / document providers — https://developer.android.com/guide/topics/providers/document-provider  
  - key: system picker mediates access; persistent URI grants are explicitly user-chosen and rooted in stable document IDs
  - why: strong precedent for separating a manual picker flow from durable reopen semantics
  - implication: keep document persistence explicit, path-free, and non-ambient under `portal.file.*`

- **REF-ANDROID-CREATE-DOCUMENT** — Android Developers: Storage Access Framework / create a new file — https://developer.android.com/training/data-storage/shared/documents-files  
  - key: `ACTION_CREATE_DOCUMENT` is the system-mediated create/save flow, and it **cannot overwrite an existing file**; collisions get a new numbered name instead
  - why: strong precedent for a bounded save/create workflow that is create-new-first rather than overwrite-first
  - us: informs the `open_untrusted` export destination boundary (`open-untrusted-export-destination-boundary-v0.md`) so risky-open keep/export lands as a fresh destination artifact before any later publish/replace decision

- **REF-APPLE-SECBOOKMARK** — Apple security-scoped bookmarks (persistent user-selected file access) — https://developer.apple.com/documentation/professional-video-applications/enabling-security-scoped-bookmark-and-url-access  
  - key: persistent references for sandboxed apps to re-access user-chosen files
  - why: UX demand for persistence beyond a single chooser interaction
  - implication: keep persistence optional; bind to consent transcripts + strong validation

- **REF-SSB-CVE-2025** — Microsoft analysis of CVE-2025-31191 (security-scoped bookmarks abuse) — https://www.microsoft.com/en-us/security/blog/2025/05/01/analyzing-cve-2025-31191-a-macos-security-scoped-bookmarks-based-sandbox-escape/  
  - key: persistent access tokens can be a high-value attack surface if validation/signing is flawed
  - why: cautionary: token lifecycle complexity matters
  - implication: prefer revocable, logged capability grants; fail-closed validation

- **REF-PLAN9-PAPER** — Plan 9 from Bell Labs (paper) — https://css.csail.mit.edu/6.824/2014/papers/plan9.pdf  
  - key: per-process namespaces + uniform resource export
  - why: grounds our D-NS / service-tree thinking
  - implication: keep service exposure uniform and capability-mediated

- **REF-FUCHSIA-APIEVO** — Fuchsia: Platform API evolution guidelines (open protocols, flexible methods/events) — https://fuchsia.dev/fuchsia-src/development/api/evolution
  - key: recommends `open` protocols with `flexible` methods/events to tolerate unknown interactions
  - why: practical, ecosystem-scale guidance for evolvable IPC boundaries
  - implication: D-APIEVO should make “open vs closed” posture explicit and auditable

- **REF-FUCHSIA-RFC0138** — Fuchsia RFC 0138: Handling unknown interactions — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0138_handling_unknown_interactions
  - key: introduces open/ajar/closed protocol modifiers + flexible/strict interactions to define unknown-op behavior
  - why: shows a concrete language+runtime contract for forward compatibility
  - implication: for open interfaces, prefer explicit `UNKNOWN_METHOD` semantics rather than aborting channels

- **REF-CAPNP-EVOL** — Cap'n Proto language docs: Evolving Your Protocol — https://capnproto.org/language.html
  - key: schema evolution rules based on stable field ordinals; add-only and reserved-field practices
  - why: well-used compatibility discipline for capability RPC payloads
  - implication: D-IDL should favor ordinal-tagged fields and “add-only” evolution for stable surfaces

- **REF-TC39-EVENTUALSEND** — TC39 proposal: *eventual-send* (E-language lineage) — https://github.com/tc39/proposal-eventual-send  
  - key: “eventual send” API surface + promise pipelining lineage from E/Waterken
  - why: concise explanation of pipelining semantics and pitfalls in a modern ecosystem
  - us: vocabulary + test ideas for our CapRPC runtime (EVID-2026-074)


- **REF-PROTOBUF-COMPAT** — Protocol Buffers docs: overview + forward/backward compatibility practices — https://protobuf.dev/overview/
  - key: older code can ignore newly added fields; removed fields read as defaults; reserve removed field numbers
  - why: mainstream example of compatibility-by-default via unknown-field behavior
  - implication: for open interfaces, favor encoding/IDL choices that make unknown fields safe to ignore

- **REF-MS-COM-IUNKNOWN** — Microsoft: IUnknown::QueryInterface (COM) — https://learn.microsoft.com/en-us/windows/win32/api/unknwn/nf-unknwn-iunknown-queryinterface%28refiid_void%29
- **REF-MS-WER-USERMODE-DUMPS** — Microsoft: collecting user-mode dumps (WER LocalDumps) — https://learn.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps
  - key: runtime discovery of supported interfaces via stable interface identifiers (IIDs)
  - why: long-lived ecosystem precedent for “object supports multiple interfaces” and explicit interface identity
  - implication: D-APIEVO can optionally standardize an “introspection/meta-interface” pattern for capability objects

- **REF-LINUX-PSI** — Linux kernel: Pressure Stall Information (PSI) docs — https://docs.kernel.org/accounting/psi.html  
  - key: pressure = time spent stalled due to CPU/mem/IO contention; per-cgroup visibility exists
  - why: motivates D-PRESSURE as a scoped “stalled time” signal rather than a global utilization probe
  - implication: export coarse, bounded stall-time signals per resource container/meter; avoid a global oracle

- **REF-SYSTEMD-PRESSURE** — systemd: MEMORY_PRESSURE.md (userspace detection + response) — https://github.com/systemd/systemd/blob/main/docs/MEMORY_PRESSURE.md  
  - key: practical userspace patterns for reacting to memory pressure early (drop caches, reduce footprint)
  - why: shows the value of a stable pressure notification seam for services
  - implication: D-PRESSURE should support low-overhead, rate-limited delivery usable by ordinary services

- **REF-FUCHSIA-MEMORY-PRESSURE** — Fuchsia: fuchsia.memorypressure FIDL + pressure levels — https://fuchsia.dev/reference/fidl/fuchsia.memorypressure  
  - key: constrained pressure levels and expectations (drop non-essential memory; refrain from allocating at CRITICAL)
  - why: reinforces “pressure levels” as a small, ergonomic contract for user-space adaptation
  - implication: CH-PRESSURE v0 uses coarse levels; scope/authority must be explicit to avoid a global oracle

- **REF-WASI-CLOCKS** — WebAssembly/wasi-clocks: Clocks API for WASI — https://github.com/WebAssembly/wasi-clocks
  - key: capability-oriented clock handles (APIs are passed an explicit clock resource)
  - why: makes “time authority” explicit at the sandbox boundary
  - us: prior art for D-NONDET and the `clock` handle in RFC-0005

- **REF-ROUGHTIME-PROTOCOL** — Google Roughtime protocol notes (PROTOCOL.md) — https://roughtime.googlesource.com/roughtime/+/HEAD/PROTOCOL.md
  - key: signed time samples with nonce binding; clients can produce evidence of server misbehavior
  - why: practical bootstrap time on hosts with no RTC, without trusting the network
  - us: basis for CH-TIMEPROOF v0 and D-TIMEPROOF bootstrap posture
- **REF-ROUGHTIME-REPO** — Google Roughtime reference implementation (repo) — https://roughtime.googlesource.com/roughtime
  - key: reference codebase for clients/servers and key material handling
  - why: lowers implementation risk for a portal-scoped timeproof sampler
  - us: candidate implementation inside `portal.clock` while keeping the stable exported artifact as CH-TIMEPROOF

- **REF-ROUGHTIME-IETF** — IETF draft: Roughtime (NTP WG) — https://datatracker.ietf.org/doc/draft-ietf-ntp-roughtime/
  - key: standardized on-wire framing + ecosystem considerations
  - why: reduces bespoke protocol risk; clarifies threat model + reporting inconsistencies
  - us: reference profile for “roughtime” kind in CH-TIMEPROOF
- **REF-RFC-8915** — RFC 8915: Network Time Security (NTS) for NTP — https://datatracker.ietf.org/doc/html/rfc8915
  - key: TLS-based key establishment + AEAD protection for NTP client/server mode
  - why: secures continuous time sync at scale (avoids symmetric-key per-client pain)
  - us: steady-state discipline option for D-TIMEPROOF (note: not publicly verifiable proof)
- **REF-CHRONY-NTS** — chrony FAQ: NTS support and configuration pointers — https://chrony-project.org/faq.html
  - key: NTS is deployed and operationally supported (chrony 4.0+ client/server patterns)
  - why: confirms NTS isn’t theoretical; gives deployment constraints and knobs
  - us: operational inspiration for a user-space time portal implementation
- **REF-CLOUDFLARE-ROUGHTIME** — Cloudflare Time Services: Roughtime docs (endpoints + keys) — https://developers.cloudflare.com/time-services/roughtime/
  - key: production anycast Roughtime service docs (addresses, public keys, usage)
  - why: concrete “real world” reference for bootstrap time and test vectors
  - us: integration test target and example allowlist entry format

- **REF-LINUX-COARSE-CLOCKS** — Red Hat docs: using _COARSE POSIX clocks (`CLOCK_MONOTONIC_COARSE`, `CLOCK_REALTIME_COARSE`) — https://docs.redhat.com/en/documentation/red_hat_enterprise_linux_for_real_time/7/html/tuning_guide/using_coarse_posix_clocks_for_application_timestamping
  - key: coarse clocks can be served in user space (VDSO), with millisecond resolution
  - why: demonstrates a pragmatic “coarse timer” profile that is both fast and less oracle-like
  - us: maps cleanly to `monotonic_coarse` in D-NONDET

- **REF-OPENBSD-GETENTROPY** — OpenBSD `getentropy(2)` — https://man.openbsd.org/getentropy.2
- **REF-LINUX-GETRANDOM** — Linux `getrandom(2)` — https://man7.org/linux/man-pages/man2/getrandom.2.html
  - key: bounded kernel entropy (max 256 bytes) intended for seeding PRNGs; recommends using `arc4random(3)` for routine randomness
  - why: a crisp “entropy as seed” posture that avoids turning kernel RNG into a firehose
  - us: informs CH-ENTROPY defaults (seed + explicit bounds) in D-NONDET

- **REF-MAN7-CLOCK_GETTIME** — Linux `clock_gettime(2)` / `clock_getres(2)` — https://man7.org/linux/man-pages/man2/clock_gettime.2.html
  - key: standard user-space API for reading multiple clocks; clock identity and resolution are API-visible and implementation-specific enough that ambient reads are a real authority surface
  - why: gives the concrete ambient time API baseline that D-NONDET and capshell must not smuggle in by default
  - us: informs `portal.clock` / CH-CLOCK and the capshell no-ambient-time launch posture

- **REF-OPENBSD-ARC4RANDOM** — OpenBSD `arc4random(3)` — https://man.openbsd.org/arc4random.3
  - key: fast per-process CSPRNG; periodically reseeded from kernel entropy
  - why: a widely-copied design that makes correct randomness easy for callers
  - us: informs “seed then local CSPRNG” guidance for entropy handles

- **REF-CHROME-HR-TIMERS** — Chrome blog: aligning high-resolution timers with cross-origin isolation — https://developer.chrome.com/blog/cross-origin-isolated-hr-timers
  - key: restricts timer resolution by default (e.g., 100µs) and relaxes under stronger isolation
  - why: demonstrates real-world timer precision policy as a security/privacy hygiene tool
  - us: motivates “fine clocks are explicit authority” rather than ambient defaults

- **REF-FANTASTIC-TIMERS** — Schwarz et al., *Fantastic Timers and Where to Find Them: High-Resolution Microarchitectural Attacks in JavaScript* (FC 2017) — https://gruss.cc/files/fantastictimers.pdf
  - key: shows attackers can synthesize high-resolution timers even when explicit timers are clamped
  - why: supports our framing that coarse timers are hygiene, not a full side-channel claim
  - us: keep D-SIDECH as a non-claim; treat D-NONDET as “reduce ambient oracles + make high-res explicit”

- **REF-KOPPMANN-ES** — Koppmann, *Extending Object-Capability Systems* (thesis; patterns for membranes, revocation, limited-use and time-limited authority) — https://eprints.cs.univie.ac.at/7140/1/2021-02-19_0702888.pdf  
  - key: concrete pattern vocabulary for wrapping authority (membranes/forwarders) plus limited-use/expiry caveats
  - why: supports D-LEASE as a user-space proxy pattern (not a kernel feature)
  - us: maps to RFC-0066; informs CH-CAPLEASE fields and enforcement failure modes

- **REF-PROTOBUF-TECHNIQUES** — Protocol Buffers docs: Techniques (descriptor sets / self-description) — https://protobuf.dev/programming-guides/techniques/
  - key: `protoc` can emit a `FileDescriptorSet` via `--descriptor_set_out`, representing a set of `.proto` files
  - why: practical canonical IR for D-IDL pinning without hashing raw `.proto` text
  - us: informs canonical `idl_digest` computation guidance

- **REF-CAPNP-IDS** — Cap'n Proto schema language docs: Unique IDs — https://capnproto.org/language.html
  - key: files/types/interfaces have unique IDs; default IDs can be derived from scope ID + name hash; explicit IDs preserve compatibility across renames/moves
  - why: shows a mature “short unambiguous identifier” approach that survives refactors
  - us: informs canonicalization + stable identity strategies for D-IDL

- **REF-FUCHSIA-RFC-0020** — Fuchsia RFC-0020: Interface ordinal hashing — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0020_interface_ordinal_hashing
  - key: hash fully-qualified method names with SHA-256; use a structured ordinal space; compiler errors on clashes with selector overrides
  - why: concrete prior art for hash-derived method ordinals and collision handling
  - us: informs CH-CAPRPC `method_id` policy for open interfaces

- **REF-FUCHSIA-FIDL-LANG** — Fuchsia: FIDL language specification (protocol ordinals) — https://fuchsia.googlesource.com/fuchsia/+/refs/heads/main/docs/reference/fidl/language/language.md
  - key: methods are identified by ordinals derived from SHA-256 of fully qualified names; selector attributes can override
  - why: highlights how wire identity + method selection can be kept compact and evolvable
  - us: informs D-APIEVO and D-IDL ordinal guidance

- **REF-FUCHSIA-FIDL-BINDINGS** — Fuchsia: FIDL bindings specification (ordinal handling conventions) — https://fuchsia.dev/fuchsia-src/reference/fidl/language/bindings-spec
  - key: bindings guidance on ordinals (representation, method ordinal size) and unknown-data handling for flexible types
  - why: shows ecosystem-level discipline needed to make “open protocols” safe in practice
  - us: informs drift guards + tooling conventions for generated code

- **REF-TUF-METADATA** — TUF docs: Roles and metadata — https://theupdateframework.io/docs/metadata/
  - key: required roles (root/targets/snapshot/timestamp) and their responsibilities; metadata structure and expiry intent
  - why: practical operational summary for implementers
  - us: informs D-TUF role expectations + update key hygiene

- **REF-TUF-FAQ** — TUF FAQ — https://theupdateframework.io/docs/faq/
  - key: operational guidance on key compromise recovery and role responsibilities
  - why: highlights expected rotation/recovery flows and out-of-band root recovery
  - us: informs update key-rotation playbook and compromise drills

- **REF-UPTANE-STANDARD2** — Uptane Standard 2.0.0 — https://uptane.org/docs/2.0.0/standard/uptane-standard
  - key: TUF-derived update framework for fleets; director/image-repository split; role semantics and constraints
  - why: concrete profile for per-device/cohort targeting without trusting artifact hosts
  - us: informs optional fleet extension posture for D-TUF

- **REF-UPTANE-BESTPRACTICES** — Uptane deployment best practices — https://uptane.org/docs/latest/deployment/best-practices
  - key: recommended metadata expiration windows and key-storage practices; tradeoffs for offline vs online signing
  - why: complements the standard with deployer-facing hardening guidance
  - us: informs expiry defaults and rotation cadence in the D-TUF playbook

- **REF-PEP-480** — PEP 480: Surviving a compromise of PyPI (TUF integration) — https://peps.python.org/pep-0480/
  - key: applying TUF to a large public repository; compromise/rollback/freeze considerations
  - why: concrete “big ecosystem” notes for TUF-like metadata at scale
  - us: informs channel + delegation thinking for update repositories

- **REF-SIGSTORE-KEYLESS** — Sigstore docs: keyless signing overview — https://docs.sigstore.dev/cosign/signing/overview/
  - key: identity-backed signing flow using OIDC + short-lived certs; verification expectations
  - why: mature, low-ops signing workflow for attestations
  - us: informs optional provenance/attestation signing workflows (CH-PROV containers)

- **REF-SIGSTORE-FULCIO** — Sigstore Fulcio overview — https://docs.sigstore.dev/certificate_authority/overview/
  - key: OIDC-backed short-lived code-signing certificates; auditable CA posture
  - why: clarifies the trust and lifetime model behind keyless signing
  - us: informs how we’d pin/verify identity-based cert chains when using keyless signing

- **REF-IOLITE-OSDI99** — Pai et al., *IO-Lite: A Unified I/O Buffering and Caching System* (OSDI 1999) — https://www.usenix.org/events/osdi99/full_papers/pai/pai.pdf
  - key: unified I/O buffering using immutable buffers + mutable buffer aggregates; aims to reduce redundant copying across IPC/filesystem/network
  - why: a concrete “single-copy where hardware allows” design with explicit safety story
  - us: motivates D-IOBUF’s “immutability/snapshot by default across trust” posture

- **REF-IOLITE-IMMUTABLE** — USENIX IO-Lite notes: *Immutable Buffers and Buffer Aggregates* — https://www.usenix.org/legacyurl/principles-immutable-buffers-and-buffer-aggregates
  - key: IO-Lite makes all I/O buffers immutable to avoid synchronization/consistency/protection problems; sharing is read-only
  - why: highlights the ergonomic/security benefits of immutability for shared-data paths
  - us: informs CH-IOBUF `immutability` semantics and cross-trust defaults

- **REF-FUCHSIA-VMO-CREATE** — Fuchsia Zircon syscall docs: `zx_vmo_create` — https://fuchsia.dev/reference/syscalls/vmo_create
  - key: kernel exposes VMOs as handle-based memory objects with explicit rights (read/write/map/transfer/duplicate)
  - why: production precedent for “memory object handles + rights” as a shared-memory substrate
  - us: informs D-IOBUF handle-rights expectations and audit vocabulary

- **REF-FUCHSIA-VMO-CHILD** — Fuchsia Zircon syscall docs: `zx_vmo_create_child` — https://fuchsia.dev/reference/syscalls/vmo_create_child
  - key: supports child VMOs with different semantics (including copy-on-write variants), with rights rules
  - why: shows a practical snapshot/COW mechanism to avoid mutable-after-send hazards
  - us: informs the “cow_snapshot” option in CH-IOBUF and RFC-0084’s freeze/snapshot backend split

- **REF-XEN-GRANTTABLE** — Xen Project Wiki: Grant Table — https://wiki.xenproject.org/wiki/Grant_Table
  - key: mediated page sharing between domains; underpins split drivers for block/network I/O
  - why: widely deployed inter-domain sharing mechanism with explicit grant semantics
  - us: informs D-IOBUF’s emphasis on explicit sharing objects and bounded rights for cross-domain copyless paths


- **REF-XDG-PORTAL-LOCATION** — XDG Desktop Portal docs: Location portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Location.html
  - key: dedicated portal interface for obtaining location information in sandboxed apps
  - why: production precedent that location is a mediated workflow in desktop sandboxes
  - us: informs `portal.location` family and D-LOCLEASE framing (portal mediation + audit)

- **REF-ANDROID-LOC-PERMS** — Android docs: Request location permissions — https://developer.android.com/develop/sensors-and-location/location/permissions
  - key: guidance on requesting location permissions; distinguishes use cases and accuracy requirements
  - why: widely deployed permission model; shows explicit user consent + posture decisions
  - us: informs coarse vs precise posture and consent/UX expectations for D-LOCLEASE

- **REF-ANDROID-LOC-BACKGROUND** — Android docs: Access location in the background — https://developer.android.com/develop/sensors-and-location/location/background
  - key: background location access is treated as higher risk with additional requirements and guidance
  - why: practical precedent for gating continuous tracking vs “while-in-use” access
  - us: informs D-LOCLEASE `background` posture and policy clamps

- **REF-APPLE-LOCATION-PRECISE** — Apple Developer docs: `CLAccuracyAuthorization.reducedAccuracy` — https://developer.apple.com/documentation/corelocation/claccuracyauthorization/reducedaccuracy
  - key: official Core Location accuracy-authorization state for reduced/approximate location access
  - why: primary platform precedent for per-app accuracy tiers rather than a support-level UX summary
  - us: informs D-LOCLEASE `accuracy` posture (coarse vs precise) and consent wording

- **REF-GEOCLUE-DBUS** — GeoClue Reference Manual: D‑Bus API — https://www.freedesktop.org/software/geoclue/docs/ref-dbus.html
  - key: geolocation service API surface and manager/client model used on Linux desktops
  - why: shows a mature user-space location service architecture and policy integration point
  - us: informs location portal backend/service boundaries and audit vocabulary

- **REF-XDG-PORTAL-INHIBIT** — XDG Desktop Portal docs: Inhibit portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Inhibit.html
  - key: portal interface for inhibiting session transitions (logout/user-switch/suspend/idle) via a close-to-release handle
  - why: production precedent that “prevent suspend/idle” is a mediated workflow in sandboxed desktops
  - us: informs `portal.inhibit` family and D-INHIBITLEASE framing (leases + audit + user-visible reasons)

- **REF-SYSTEMD-INHIBITOR-LOCKS** — systemd: Inhibitor Locks — https://systemd.io/INHIBITOR_LOCKS/
  - key: inhibitor locks to block or delay sleep/shutdown/idle; documents use-cases and semantics
  - why: widely deployed model separating delay vs block and tying locks to explicit holders
  - us: informs D-INHIBITLEASE “delay-by-default; block reserved” posture

- **REF-SYSTEMD-INHIBIT-MAN** — man7: systemd-inhibit(1) — https://man7.org/linux/man-pages/man1/systemd-inhibit.1.html
  - key: describes block/delay inhibitor lock types and intended usage
  - why: precise, implementer-facing description of the semantics deployed in the field
  - us: informs CH-INHIBITLEASE `mode` vocabulary and evidence tests

- **REF-ANDROID-WAKELOCK** — Android API reference: PowerManager.WakeLock — https://developer.android.com/reference/android/os/PowerManager.WakeLock
  - key: wake lock API used to keep device awake; emphasizes explicit acquire/release behavior
  - why: mobile precedent for keep-awake as an explicit authority with strong battery implications
  - us: informs TTL-by-default and strict release semantics for D-INHIBITLEASE profiles

- **REF-ANDROID-SET-WAKELOCK** — Android docs: Set a wake lock — https://developer.android.com/develop/background-work/background-tasks/awake/wakelock/set
  - key: guidance emphasizing short holds and battery impact; recommends alternatives where possible
  - why: operational guidance reflecting hard-won experience with wake lock misuse
  - us: informs default clamps and “prefer jobs; inhibit only while active” guidance

- **REF-XDG-PORTAL-BACKGROUND** — XDG Desktop Portal docs: Background portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Background.html
  - key: portal for requesting background activity and login autostart with a user-visible reason and status surface
  - why: production precedent that “run in background / autostart” is a mediated workflow in sandboxed desktops
  - us: informs `portal.background` family and D-BGLEASE framing (leases + audit + visibility)

- **REF-XDG-PORTAL-SECRET** — XDG Desktop Portal docs: Secret portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Secret.html
  - key: portal interface that returns a per-application secret seed for sandboxed apps
  - why: pragmatic precedent for ‘app secret seed’ without a general keyring API surface
  - us: informs `portal.secret` and CH-APPSECRET posture (bounded metadata; no secret bytes in receipts)

- **REF-SECRET-SERVICE-SPEC** — Secret Service API specification (latest) — https://specifications.freedesktop.org/secret-service/latest/description.html
  - key: standardized model for storing arbitrary secrets (sessions, collections, items with attributes)
  - why: shows the complexity and boundary risks of general key/value secret stores
  - us: keep D-APPSECRET minimal; reserve rich secret storage/sharing for D-VAULT with explicit policies and references

- **REF-ANDROID-BG-EXEC-LIMITS** — Android docs: Background Execution Limits (Android 8.0+) — https://developer.android.com/about/versions/oreo/background
  - key: background service limits and execution restrictions introduced to protect user experience and battery
  - why: mainstream precedent that background execution is dangerous and must be constrained
  - us: informs deny-by-default + preference for D-JOBS and strict clamp posture for D-BGLEASE profiles

- **REF-ANDROID-FGS-RESTRICTIONS** — Android docs: Restrictions on starting a foreground service from the background — https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
  - key: modern Android restricts background-start of foreground services with explicit exceptions; violations throw errors
  - why: concrete precedent for “no hidden background escalation paths” and fail-closed semantics
  - us: informs PO-BGLEASE-ENF negative tests (no bypass to background presence without portal grant)

- **REF-APPLE-BG-MODES** — Apple Developer docs: Configuring background execution modes — https://developer.apple.com/documentation/xcode/configuring-background-execution-modes
  - key: apps must explicitly declare required background modes/capabilities; the platform gates execution accordingly
  - why: mainstream precedent for background as a declared, reviewed capability rather than ambient behavior
  - us: informs D-BGLEASE posture: explicit intent + user-visible listing + periodic review in strict profiles


## Scalability & multicore
- **REF-HWLOC-OBJTYPES** — hwloc documentation: Object Types — https://www.open-mpi.org/projects/hwloc/doc/v2.12.2/group__hwlocality__object__types.html
  - key: NUMA nodes are the smallest memory-resource objects; `Group` objects are arbitrary affinity/grouping helpers and may group NUMA nodes by distance
  - why: supports keeping Phase 1 default clustering anchored on stable memory/locality boundaries instead of auto-promoting arbitrary grouping hints into authority boundaries
  - us: informs `cluster-auto-boundary-v0.md` and `cluster-derivation.md` (NUMA/socket by default; no automatic `die`/group clustering)

- **REF-LINUX-NUMA** — Linux kernel docs: What is NUMA? — https://www.kernel.org/doc/html/v4.18/vm/numa.html
  - key: Linux prefers local allocation on the request’s node and explicitly models NUMA topology for scheduling/locality decisions
  - why: supports treating NUMA as the first-order Phase 1 cross-cluster locality boundary
  - us: informs `cluster-auto-boundary-v0.md` (prefer NUMA when complete; keep cross-node merging explicit)

- **REF-ACPI-PPTT** — ACPI Specification 6.5A: Processor Properties Topology Table (PPTT) / SRAT / SLIT — https://uefi.org/specs/ACPI/6.5_A/
  - key: firmware topology exposes multiple structure layers (processor topology, affinity, locality distance), which are useful but not automatically equivalent to OS authority boundaries
  - why: supports keeping topology richness as input data while requiring explicit policy before promoting finer-grained die/chiplet structure into CH-CLUSTERMAP ownership boundaries
  - us: informs `cluster-auto-boundary-v0.md` (topology richness ≠ automatic boundary widening)

- **REF-LINUX-CACHEINFO** — Linux kernel ABI docs: `/sys/devices/system/cpu/cpu*/cache/index*/...` cache topology attributes — https://coral.googlesource.com/linux-imx/%2B/refs/tags/11-2/Documentation/ABI/testing/sysfs-devices-system-cpu?autodive=0%2F%2F%2F%2F
  - key: Linux exposes cache-sharing relationships (`shared_cpu_list`/`shared_cpu_map`) and cache ids as topology attributes; ids may be non-contiguous and reflect discovered cache instances rather than a universal authority boundary
  - why: supports treating `l3_cache_id` and cache-sharing data as useful placement inputs while avoiding automatic promotion into cluster ownership semantics
  - us: informs `cache-topology-authority-boundary-v0.md` and the CH-HWFACT / CH-CLUSTERMAP locality notes

- **REF-HWLOC-DISTANCES** — hwloc documentation: Retrieve distances between objects — https://www-lb.open-mpi.org/projects/hwloc/doc/v2.12.2/group__hwlocality__distances__get.html
  - key: distances are matrices between objects, typically relative latencies or bandwidths, and may come from the operating system or hardware
  - why: supports treating distance matrices as useful optimization vocabulary while avoiding automatic promotion into authority or ownership semantics
  - us: informs `memory-locality-authority-boundary-v0.md` and future CH-HWFACT locality-hint additions

- **REF-ACPI-HMAT** — ACPI 6.6 NUMA Architecture Platforms / HMAT / SLIT — https://uefi.org/specs/ACPI/6.6/17_NUMA_Architecture_Platforms.html
  - key: firmware may expose relative locality distance plus latency/bandwidth information between initiator and memory target localities
  - why: supports treating richer memory-locality data as descriptive topology input rather than an automatic authority boundary
  - us: informs `memory-locality-authority-boundary-v0.md` and future CH-HWFACT locality-hint additions

- **REF-LINUX-NUMA-BALANCING** — Linux kernel docs: `numa_balancing` — https://docs.kernel.org/admin-guide/sysctl/kernel.html#numa-balancing
  - key: Linux uses NUMA balancing and optional memory-tiering modes to move memory toward the nodes that access it often
  - why: supports keeping locality/tiering as explicit placement and migration policy rather than conflating it with ownership or authorization
  - us: informs `memory-locality-authority-boundary-v0.md` and multicore placement guidance

- **REF-SCR-TOCS15** — Scalable commutativity rule (TOCS) — https://people.csail.mit.edu/nickolai/papers/clements-sc-tocs.pdf
- **REF-KAFKA-PARTITION-ORDER** — Apache Kafka docs: ordering is per partition, not global — https://kafka.apache.org/documentation/
  - key: Kafka provides total order within a partition, not across all partitions in a topic; global order requires collapsing to one partition
  - why: supports scoping ordered streams to the smallest useful shard/key rather than treating order as ambient global infrastructure
  - us: informs `ordering-token-posture-v0.md` and the default “one conflict-key stream, owner-routed” CH-ORDERTOK posture

- **REF-ZK-ZXID** — ZooKeeper Programmer's Guide / Internals: zxid total ordering — https://zookeeper.apache.org/doc/current/zookeeperProgrammers.html
  - key: each ZooKeeper state change receives a unique zxid exposing a global total order
  - why: useful contrast case showing the cost/shape of a true global ordered stream and why it must be an explicit choice rather than a default inheritance from “ordered actions exist”
  - us: informs `ordering-token-posture-v0.md` and the refusal to make CH-ORDERTOK a portable default global sequencer

- **REF-FDB-VERSIONSTAMP** — FoundationDB docs: versionstamps are commit-time serial values — https://apple.github.io/foundationdb/data-modeling.html
  - key: versionstamps are generated at commit time and cannot be fully known/read in the same transaction that writes them
  - why: supports treating `epoch` / `seqno` as issuer-validated evidence fields rather than a client arithmetic API or planner-controlled preallocation surface
  - us: informs `ordering-token-posture-v0.md` and future ordered-action evidence work

- **REF-KNOSSOS-JEPSEN** — Knossos (Jepsen) linearizability checker — https://github.com/jepsen-io/knossos  
  - key: if ops commute in the spec, a scalable implementation exists (coordination is avoidable)
  - why: gives a *design rule* for scalable interfaces, not just scalable code
  - us: annotate CH-KABI/portal actions with commutation predicates + test them (D-COMMUTE)

- **REF-NIX-STORE-OBJECT** — Nix Reference Manual: Nix store / content-addressing store objects — https://nix.dev/manual/nix/2.24/store/ and https://nix.dev/manual/nix/2.26/store/store-object/content-address
  - key: store data are immutable, and content-addressed store objects tie store-path identity to content-derived digests
  - why: concrete ecosystem precedent for exact-byte executable staging / immutable execution objects
  - us: supports the capshell executable-object posture: compat staging may materialize exact bytes, but must not widen into mutable-name reopen semantics

- **REF-MS-WINDOWS-PROPERTY-HANDLERS** — Microsoft Learn, *Understanding Property Handlers* — https://learn.microsoft.com/en-us/windows/win32/properties/building-property-handlers-properties  
- **REF-APPLE-SPOTLIGHT-IMPORTERS** — Apple Developer Documentation Archive, *About Spotlight Importers* — https://developer.apple.com/library/archive/documentation/Carbon/Conceptual/MDImporters/MDImporters.html  
