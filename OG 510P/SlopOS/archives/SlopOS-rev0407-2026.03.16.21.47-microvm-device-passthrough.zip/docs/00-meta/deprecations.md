# Deprecations (tight; prevent drift)

Purpose: keep exactly one canonical source for each concept.

## Current deprecations
- **RFC-0054 → RFC-0069**: consolidate authority diffs/receipts under the typed CH-CAPDIFF design; keep RFC-0054 only as historical narrative.
- **CH-LEASE v0 → CH-IOLEASE v0**: disambiguate “lease” terminology; CH-LEASE was a device/I/O lease descriptor and is now renamed to CH-IOLEASE.


## Deprecation process
1) Mark the old item as **DEPRECATED** (top of file) with a pointer to the canonical replacement.
2) Add an entry here: `old → replacement` + one-line rationale.
3) Update any index/README pointing at the old item.
4) Add a CI guard if the old reference is likely to reappear.
