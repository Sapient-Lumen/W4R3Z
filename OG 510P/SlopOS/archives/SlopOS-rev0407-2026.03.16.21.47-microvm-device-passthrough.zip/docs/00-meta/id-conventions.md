# ID conventions (small, enforceable)

Purpose: make traceability cheap and prevent silent drift.

## Namespaces
- **A-*** assumptions (threat-model prerequisites)
- **ADV-*** adversaries (attacker classes)
- **AC-*** abuse cases (pressure tests)
- **C-*** claims (what we assert)
- **I-*** invariants (state predicates preserved by transitions)
- **D-*** decision nodes (branches; become ADRs)
- **PO-*** proof obligations (to-prove / to-check statements)
- **U-*** unsafe obligations (Rust `unsafe` contracts)
- **IF-*** privileged interfaces/surfaces (entrypoints, control plane)
- **CH-*** schema identifiers (wire/serialization contracts)
- **EVID-*** internal evidence artifacts (our prototypes/proofs/releases)

## Stability
IDs are stable. If renaming is unavoidable, deprecate the old reference and record an alias in `deprecations.md`.

## Family references (allowed shorthand)
In prose we sometimes write `<I-FOO-*>` or `<PO-BAR-*>` to mean “the family of IDs starting with the prefixes `I-<NAME>-` / `PO-<NAME>-`.”
These are **not concrete IDs** and are ignored by the “undefined ID” lint.

## Concrete-ID rule
Any concrete ID reference (e.g., `I-MAP-1`, `PO-BOOT-VERIFY`, `IF-KABI`) must be defined in the corresponding registry/map.
