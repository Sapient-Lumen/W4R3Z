# Profile claim matrix (A–D)

Purpose: pin which **claims (C-IDs)** each product shape expects to **make**.
This reduces drift where a doc casually implies “we guarantee X” for a profile
that was never intended to carry that claim.

Legend:
- **REQ**: required (profile should ship claiming it)
- **REC**: recommended (ship when assumptions/platform permit; otherwise do not claim)
- **OPT**: optional (feature/market dependent)
- **NO**: not a claim goal for that profile (or out-of-scope for Phase 1)

Profiles:
- (A) secure workstation
- (B) cloud micro-VM / hosted compute substrate
- (C) embedded / separation-kernel-ish appliance
- (D) agent/automation OS

Rule: this matrix is **not a fork**. It is a planning surface that says which
claims we intend to *assert* per product shape once evidence exists.

| Claim (C-ID) | (A) workstation | (B) cloud substrate | (C) embedded appliance | (D) agent OS | Notes (scope + assumptions) |
|---|---:|---:|---:|---:|---|
| **C-CAP-1** Capability integrity | REQ | REQ | REQ | REQ | Baseline for all authority surfaces. |
| **C-ISO-1** Spatial isolation | REQ | REQ | REQ | REQ | Core isolation story for all shapes. |
| **C-ISO-2** DMA-aware isolation | REQ | REQ | REC | REQ | If claimed, must satisfy fail-closed D-DMA v0 (`iommu_required`) and A-DMA-1; otherwise **do not claim**. |
| **C-STATE-1** Well-formed transitions | REQ | REQ | REQ | REQ | Needed to make any other claim meaningful. |
| **C-BOOT-1** Boot integrity profile | REQ | REQ | REQ | REQ | Local boot integrity; remote attestation is separate. |
| **C-ATTEST-1** Remote attestation | OPT | REQ | OPT | REC | B’s hosted substrate story expects remote verification/update gates; other profiles may ship offline or treat attestation as an add-on surface. |
| **C-UNSAFE-1** Unsafe confinement | REQ | REQ | REQ | REQ | Engineering discipline (module list + pre/postconditions). |
| **C-CONC-1** Concurrency safety (scoped) | REC | REC | REC | REC | Staged; no liveness claims unless explicitly stated. |
| **C-LLM-1** Non-authoritative proposals | REC | OPT | NO | REQ | D is the primary audience; A may ship LLM tooling but must keep “validators execute” invariant. |
| **C-PROV-1** Provenance + reproducibility (scoped) | REC | REQ | REC | REQ | B/D should be reproducible by default; A/C may phase-in. |
| **C-PROV-2** End-to-end proof-carrying provenance | NO | OPT | NO | OPT | Aspirational (D-PCP v0 is release-only). |
| **C-IFC-1** Scoped information-flow | NO | OPT | OPT | OPT | Optional hardening layer; Phase 1 is typically NO. |
| **C-OBS-1** Redacted observations (scoped) | REC | REC | NO | REC | If IF-OBS is disabled by policy, the claim may be omitted rather than asserted. |
| **C-TIME-1** Monotonic expiry enforcement | OPT | OPT | OPT | OPT | Depends on policy use of expiry/anti-rollback; tied to D-NONDET / D-TIMEPROOF usage. |
| **C-ABI-1** Total, fail-closed privileged ABI | REQ | REQ | REQ | REQ | Essential for “LLMs propose; validators execute” and for auditability. |
| **C-DRV-1** Device logic outside core | REC | REC | REQ | REC | C often needs strict driver/TBC minimization; others still benefit but may stage. |
| **C-HV-1** Closed exit handling (conditional) | OPT | REQ | NO | REQ | B/D assume micro-VM substrate; A may or may not. |

Notes:
- This matrix is intentionally conservative: if a claim is not clearly deliverable
  under Phase 1 assumptions, mark it **REC/OPT/NO** and require explicit evidence
  before moving to **REQ**.
- When a claim is **REC/OPT**, profile documentation MUST not casually imply it is
  claimed; instead point to `docs/20-assurance/claim-registry.md` and this matrix.

References:
- REF-SCSC-GSN
- REF-OMG-SACM-21
