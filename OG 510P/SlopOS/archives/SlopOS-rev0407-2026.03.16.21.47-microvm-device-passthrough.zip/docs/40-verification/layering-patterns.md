# Layering & interface-first verification patterns (tight notes)

Purpose: capture reusable patterns for making verification tractable without duplicating literature.

## Pattern P-LAYER: security-preserving layers
Idea: split a large privileged system into a small verified core + untrusted services, proving that layers preserve security properties while refining specs.
Use when: hypervisor-first or microkernel+services architecture needs a “microkernelization” story.

## Pattern P-ABI: formalize the ABI first
Idea: specify the privileged interface (syscall/hypercall/VM-exit ABI) as the main contract, then prove implementation refines it.
Use when: hardware/ABI complexity dominates; the ABI spec becomes the anchor artifact.

## Pattern P-SLICE: MVP-A2 slice
Idea: pick the smallest claim-bearing slice (capability integrity + mapping discipline + constrained concurrency), and prove it end-to-end before expanding.
Use when: scope threatens to balloon; avoids proof churn.

## What this changes for us
- Prefer designs where *most complexity is deprivileged* and can be treated as untrusted, with explicit capability boundaries.
- Keep the privileged ABI extremely small and stable; it is the proof surface.
- Use bounded model checks early to kill bad designs quickly; reserve A2/A3 for stabilized slices.
