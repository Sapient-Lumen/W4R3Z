# Tooling landscape (keep it comparative, not exhaustive)

## SMT-first (e.g., Verus)
Pros: fast iteration; specs adjacent to code; strong for data-structure invariants.  
Cons: solver trust; may require coding discipline/subset.

## Bounded model checking (e.g., Kani)
Pros: early bug-finding; great for state machines and regression.  
Cons: bounded; not an A2 proof; must be labeled as such.

## Differential randomized testing (DRT) with definitional models
Pros: catches “spec drift” by comparing production code against a small executable reference model; scales well in CI; produces actionable counterexamples.  
Cons: requires maintaining a tiny reference interpreter; equivalence criteria (error taxonomy, normalization) must be pinned.
Use: high-value for CH-* canonical encoders/decoders, CH-KABI dispatch normalization, and ACP validators (D-DRT).  
Refs: REF-CEDAR-SPEC.

## Concurrency bug-finding (e.g., Loom)
Pros: systematically explores interleavings for Rust concurrency code; great for kernel-internal protocol/state-machine libraries before SMP is enabled.  
Cons: still bounded; requires modeling time/IO boundaries carefully.

## Weak-memory / system concurrency checks (research tools)
Pros: recent work shows you can model-check realistic Rust OS concurrency under weak memory assumptions.  
Cons: tool maturity varies; treat as “E2 bug-finding” until the trust story is explicit.

## Deductive verification (e.g., Creusot/Why3)
Pros: alternative path; flexible solver/ITP ecosystem.  
Cons: annotation overhead; translation pipeline trust.

## ITP-first (Isabelle/Coq)
Pros: strongest foundation; great for refinement and meta-properties.  
Cons: proof engineering cost; slower iteration.

## Likely path (candidate)
Hybrid: bounded checks early; SMT proofs for large components; ITP for top-level refinement or security theorems when needed.

## Userspace harnesses for kernel components (rump-style)
Pros: cheap fuzzing/fault injection; reproducible tests without kernel crashes; supports “prototype-to-evidence” loops.  
Cons: requires a clean shim boundary; can hide real hardware timing/ordering issues.  
Use: especially attractive for driver-domain bring-up and for model-check harnesses where the same state machine runs in both “spec” and “prototype” forms.  
Refs: REF-RUMP-KERNEL.

Refs (concurrency): REF-LOOM, REF-CONVEROS.
