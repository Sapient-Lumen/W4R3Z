# Worker-pool cap-graph snapshots v0 (exact `capgraph.before` / `capgraph.after` contract)

Purpose: pin one exact, family-local meaning for the canonical `capgraph.before` / `capgraph.after` members in the first concrete **D-CONSTR** evidence pack so confinement tooling does not drift into whole-system graph dumps, helper-visible graph cuts, or equivalent-but-different snapshot normalizations.
This doc narrows an already-chosen surface: it reuses **CH-CAPG v0** plus the existing constructor harness/evidence seams, and it does **not** introduce a new graph schema, a generic constructor diff language, or an ambient graph-query plane.

Scope:
- applies only to the first concrete D-CONSTR family in `docs/30-architecture/worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-CAPAUD**, **D-COMMUTE**, **D-AREF**, **CH-CAPG v0**, **CH-AREF v0**
- assumes the exact family-local invocation boundary is already fixed by `docs/30-architecture/worker-pool-constructor-invocation-v0.md`
- assumes the exact invocation-manifest object is already fixed by `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- assumes the exact canonical evidence-pack member labels are already fixed by `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- assumes the exact install-only target projections are already fixed by `docs/40-verification/worker-pool-target-projection-v0.md`
- assumes the exact bounded transcript windows are already fixed by `docs/40-verification/worker-pool-transcript-slice-v0.md`
- assumes the exact compact verdict object is already fixed by `docs/40-verification/worker-pool-verdict-summary-v0.md`
- does **not** introduce a second graph schema beside `CH-CAPG v0`, a graph query/list/watch plane, or a constructor-defined helper-inventory surface

## Phase-1 choice

1) **`capgraph.before` / `capgraph.after` are caller-scoped `CH-CAPG v0` receipts, not whole-system graph dumps**
   - The canonical worker-pool evidence pack carries exactly one `capgraph.before` member and exactly one `capgraph.after` member.
   - Each member is one bounded `CH-CAPG v0` receipt (embedded directly or reached by `CH-AREF v0`) over the caller-visible observation scope used by the harness delta predicate.
   - The pair does not widen into whole-system graph exports, per-worker graph dumps, or helper/service inventory snapshots.

2) **Both snapshots come from the same observer cut and normalization profile**
   - The `scope` field MUST be present in both members, and `capgraph.before.scope` and `capgraph.after.scope` MUST be identical.
   - The two members MUST use the same redaction/bounds policy over `nodes` and `edges`, the same `kind` / `etype` vocabularies, and the same reduced `rights` summary profile.
   - The optional `epoch` field MAY differ or be absent, but comparison never depends on exact `epoch` values.
   - Phase 1 therefore declines per-case graph-shape folklore, host-specific helper labels, or “equivalent after normalization” side formats on the canonical pair.

3) **The canonical pair proves one exact caller-reachable delta and nothing wider**
   - The comparison target is the normalized caller-reachable delta from `capgraph.before` to `capgraph.after`.
   - The only newly caller-reachable graph material permitted by the first worker-pool family is the declared export surface: `pool.control` plus `worker[i]` for `0 <= i < pool_size`.
   - Any newly caller-reachable sponsor helper, template fetch route, extra `worker_seed/<label>` reflection, undeclared install helper, or constructor-internal control path is a confinement failure.
   - The canonical pair therefore keys off caller-visible capability reachability, not on internal bring-up order, hidden supervisor structure, or target-seam publication state.

4) **Target publication evidence stays on the target seam, not inside the cap-graph pair**
   - `capgraph.before` / `capgraph.after` do not substitute for `target.before` / `target.after`.
   - Install-mode publication ordering remains evidenced by the exact install-only `CH-SPROJ v0` pair pinned in `docs/40-verification/worker-pool-target-projection-v0.md`.
   - The cap-graph pair therefore carries no target names, alias tables, catalog listings, or constructor-defined projection payloads on the canonical worker-pool surface.

5) **Labels and epochs remain optional and non-authoritative for comparison**
   - The optional `label` field on `nodes` and optional `meta` adornments on `edges` may be present when policy allows, but replay/confinement comparison does not depend on them.
   - Exact comparison keys off the normalized `nodes` / `edges` structure, edge kinds (`holds_cap`, `derives_from`, `maps_view`, `owns`, `charges_to`), and reduced rights summaries that remain visible under the shared redaction profile.
   - The pair carries no raw kernel object identifiers, host PIDs, addresses, or per-run locator folklore.

6) **The canonical pair stays bounded and machine-comparable**
   - The worker-pool family adds no per-case, per-order-variant, or per-tool alternate graph members beyond `capgraph.before` and `capgraph.after`.
   - Tools MAY attach richer graph renderings or host-native dumps outside the canonical member set, but those extras are non-authoritative and MUST NOT affect `verdict.summary`, replay comparison, or confinement verdicts.
   - Sealed compat remains honest: foreign hosted implementations that cannot produce the same caller-scoped bounded pair must fail closed rather than emitting ambient whole-process or host-global graph approximations.

## Out of scope in v0

- A constructor-generic cap-graph diff schema for future families.
- Whole-system graph exports, graph query APIs, or live graph watch surfaces.
- Any requirement to expose helper-only/internal constructor state to make the comparison pass.
- Target-name, catalog, or install-history semantics on the canonical `capgraph.before` / `capgraph.after` pair.
- Host-specific object identifiers, raw addresses, or unredacted helper inventories as authoritative comparison inputs.

## Wiring

- Decision surface: **D-CONSTR**.
- Primary family docs: `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-invocation-manifest-v0.md`.
- Primary verification docs: `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/worker-pool-target-projection-v0.md`, `docs/40-verification/worker-pool-transcript-slice-v0.md`, `docs/40-verification/worker-pool-verdict-summary-v0.md`.
- Reused seams: **CH-CAPG v0**, **CH-AREF v0**, **D-CAPAUD**, **D-COMMUTE**, **D-AREF**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-CAPDL-KUZ10**, **REF-SEL4-COMPREHENSIVE**, **REF-EROS-CONFINEMENT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_capgraph_snapshots.py` (**EVID-2026-372**).
