# Foreign Cell escape suite v0 (AC-071 negative tests)

Purpose: make **sealed compat** (D-FCELL / D-RUMPK) testable and hard to “hand-wave”.

This doc specifies a minimal **negative test suite** that attempts to find ambient channels from inside a Foreign Cell (AC-071).
It is a *contract for evidence tooling*, not an implementation.

Scope:
- applies to any compatibility runtime capsule launched under **CH-FCELL v0** (rump, LKL, picoprocess, userspace-kernel, …)
- focuses on **ambient host effects** (I-COMPAT-1) and **fail-closed ABI/hostcall surfaces** (I-COMPAT-2)

Non-goals:
- performance benchmarking (separate harness)
- proving isolation (this is a drift-catching regression suite)

## Preconditions (v0 posture)

The escape suite is run in at least these two modes:

1) **Fail-closed baseline** (recommended default for CI):
   - `cfg.params.lane.fcell=false` **or** CH-FCELL requests no interop adapters/portals
   - portal lane gates are off by profile defaults (e.g., `cfg.params.lane.portal.net=false`, `cfg.params.lane.portal.file=false`)

2) **Granular deny mode** (adapter present but killable):
   - `cfg.params.lane.fcell=true`
   - CH-FCELL lists an adapter kind in `interop.adapters.enabled`, but either the adapter gate **or** its bound portal gate is off
     - example: `cfg.params.lane.fcell.adapter.posix_socket_via_net_portal=false` while `cfg.params.lane.portal.net=true`

All tests must be **deterministic** under a given mode. “Works sometimes” is a bug.

## What counts as an escape

An escape is any path where the compat capsule can perform host effects (or obtain effect-enabling descriptors) without going through the declared, policy-killable seams:

- portal lanes (`cfg.params.lane.portal.*`)
- compat adapter kinds (`cfg.params.lane.fcell.adapter.*`) via CH-FADAPT receipts
- explicitly attached resources in CH-FCELL `resources.*` (views/docrefs/netleases/clocks/entropy/devices)

Examples of disallowed ambient channels:
- raw host filesystem by path (bypassing `portal.file` / docrefs)
- ambient sockets / DNS resolution (bypassing `portal.net` / netleases)
- ambient privileged debug pipes (bypassing declared routes/handles)

## Evidence contract

For any attempted host effect:

- If an adapter is involved, a CH-FADAPT receipt MUST exist and be transcript-visible (ALLOW/DENY) (PO-FADAPT-EMIT).
- When denied due to lane gating, the denial MUST be deterministic and reviewable (PO-LANE-KILL), typically via CH-DENY with:
  - `deny_code="lane-disabled"` and `reason.kind="lane"` and `reason.ref_key=<cfg.params.lane.* key>`
- For fail-closed ABI/hostcall surfaces, unknown operations MUST reject deterministically (PO-COMPAT-CLOSESET).

The harness should export:
- a transcript slice (CH-LOG) covering each attempt
- any CH-FADAPT receipts emitted
- a cap-graph diff (CH-CAPG) after the suite confirming no unintended authority edges were introduced

## Test matrix (seed)

Each test case is defined by:
- **Stimulus** (what the capsule does)
- **Expected outcome** (deny/allow under which mode)
- **Evidence hooks** (which receipts/log fields must appear)

### FS-1: host sentinel open-by-path (ambient file escape)

- Stimulus: inside the compat capsule, attempt `open("/run/slopos-host-sentinel", O_RDONLY)`.
  - Harness setup: create this file on the host; ensure it is **not** present in the capsule’s rootfs image.
- Expected outcome:
  - Fail-closed baseline: deterministic failure (no read success).
  - Granular deny mode: deterministic failure.
- Evidence hooks:
  - If an adapter is used (e.g., `posix.open_via_doc_portal`), emit CH-FADAPT with `adapter_kind=posix.open_via_doc_portal` and `result.code=DENY`, and bind the portal lane or adapter lane key in the denial reason.

### FS-2: chooser-only open (mediated interop)

- Stimulus: inside the compat capsule, perform the *supported* “open a document” flow (legacy `open` translated via adapter).
- Expected outcome:
  - Fail-closed baseline: deterministic deny.
  - Granular deny mode: deterministic deny (because a lane gate is off).
  - (Optional positive mode, if enabled intentionally): allow only when **both** `cfg.params.lane.portal.file=true` and `cfg.params.lane.fcell.adapter.posix_open_via_doc_portal=true`.
- Evidence hooks:
  - CH-FADAPT receipt (ALLOW/DENY) with `portal_token=portal.file` and issued `docref` digest list on ALLOW.

### NET-1: raw socket + connect (ambient network escape)

- Stimulus: inside the capsule, attempt `socket(AF_INET, SOCK_STREAM, …)` then `connect(1.1.1.1:443)`.
- Expected outcome:
  - Fail-closed baseline: deterministic failure.
  - Granular deny mode: deterministic failure.
- Evidence hooks:
  - If mediated via `posix.socket_via_net_portal`, emit CH-FADAPT with `adapter_kind=posix.socket_via_net_portal` and DENY with bound lane key.

### NET-2: DNS by name (ambient name resolution escape)

- Stimulus: `getaddrinfo("example.com", …)` inside the capsule.
- Expected outcome:
  - Fail-closed baseline: deterministic failure (no ambient DNS).
  - Granular deny mode: deterministic failure.
- Evidence hooks:
  - If translation uses the net portal, receipts are CH-FADAPT (DENY).
  - If the runtime tries to do DNS without invoking an adapter, treat as an escape: record as a hard failure.

### RES-1: clocks/entropy handles absent by default

- Stimulus: attempt to obtain fine time / entropy via any runtime-provided “host service” hook.
- Expected outcome:
  - Baseline: deterministic failure unless CH-FCELL `resources.clocks` / `resources.entropy` explicitly attach handles.
- Evidence hooks:
  - any attempted hostcall must be within the declared closed ABI surface (PO-COMPAT-CLOSESET); unknown hostcall ids reject deterministically.

## Wiring

- Threat anchor: AC-071 (`docs/10-threat-model/abuse-cases.md`).
- Primary POs: PO-COMPAT-NOAMBIENT, PO-COMPAT-CLOSESET, PO-FADAPT-EMIT, PO-LANE-KILL.
- Evidence hook: EVID-2026-206.

See also:
- RFC-0036 (rump capsule), RFC-0083 (driver hosts + compat capsules)
- `docs/30-architecture/foreign-cell-contract.md` (membrane contract)
- `docs/30-architecture/fcell-adapter-kind-registry.md` (closed adapter taxonomy)
