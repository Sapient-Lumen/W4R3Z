# Worker-pool constructor evidence pack v0 (canonical family-local handoff)

Purpose: pin one **canonical, digest-first evidence-pack shape** for the first concrete
**D-CONSTR** family so different harness implementations do not emit “equivalent” but
incomparable bundles.
This doc attaches to the existing worker-pool family / invocation / harness contracts and
reuses existing artifact and transcript seams; it does **not** introduce a generic constructor
receipt protocol, a new evidence lane, or a constructor-global bundle format.

Scope:
- applies only to the first concrete D-CONSTR family in `docs/30-architecture/worker-pool-constructor-family-v0.md`
- reuses existing seams: **CH-CAPG v0**, **CH-LOG v0**, **CH-SPROJ v0**, **CH-AREF v0**, **D-CAPAUD**, **D-AREF**
- assumes the exact invocation boundary is already fixed by `docs/30-architecture/worker-pool-constructor-invocation-v0.md`
- assumes the exact meaning of the required sponsor import is already fixed by `docs/30-architecture/worker-pool-sponsor-surface-v0.md`
- assumes the exact meaning of the optional install import is already fixed by `docs/30-architecture/worker-pool-install-target-surface-v0.md`
- assumes the exact meaning of repeated `worker_seed/<label>` imports is already fixed by `docs/30-architecture/worker-pool-seed-surface-v0.md`
- assumes the exact family-local parameter schema is already fixed by `docs/30-architecture/worker-pool-parameter-schema-v0.md`
- assumes the exact invocation-manifest object is already fixed by `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- assumes the exact caller-scoped cap-graph pair is already fixed by `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`
- assumes the exact install-only target-projection contract is already fixed by `docs/40-verification/worker-pool-target-projection-v0.md`
- assumes the exact transcript-slice contract is already fixed by `docs/40-verification/worker-pool-transcript-slice-v0.md`
- assumes the exact verdict-summary contract is already fixed by `docs/40-verification/worker-pool-verdict-summary-v0.md`
- assumes the harness obligations are already fixed by `docs/40-verification/worker-pool-constructor-harness-v0.md`

Non-goals:
- defining a generic constructor evidence schema shared by all families
- inventing a constructor-specific archive/transport protocol
- replacing the underlying `CH-CAPG v0`, `CH-LOG v0`, or `CH-SPROJ v0` artifacts
- widening the reviewed surface from digest references into ambient locator fetches

## Phase-1 choice

1) **One closed evidence-pack member set fixes the handoff surface**
   - The first worker-pool harness emits one closed pack whose canonical member labels are:
     - `invocation.manifest`,
     - `capgraph.before`,
     - `capgraph.after`,
     - `transcript.slice`,
     - `verdict.summary`,
     - and, for install cases only, `target.before` plus `target.after`.
   - The family adds no alternate label vocabulary, nested per-tool folder conventions, or constructor-global attachment registry.

2) **The invocation manifest is digest-first and import-label exact**
   - `invocation.manifest` MUST bind, by digest/reference, the reviewed invocation contract:
     - worker template/artifact digest set,
     - exact `digest(CH-EXECPACK v2)` worker launch closure,
     - `param_digest = digest(CH-WPOOLPARAM v0)`,
     - import-contract digest,
     - export-contract digest,
     - presence of exactly one `sponsor` import,
     - exact set of `worker_seed/<label>` imports,
     - whether `install_target` was present.
   - Human-readable labels may appear as annotations, but digest/reference identity is authoritative.

3) **Caller-scoped cap-graph snapshots are canonical members**
   - `capgraph.before` and `capgraph.after` MUST follow the exact worker-pool contract pinned in `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`.
   - The pair is caller-scoped, shares one normalization/redaction profile, and proves only the normalized caller-reachable delta used by the harness predicate.
   - The evidence pack does not substitute prose summaries for those snapshots and does not widen observation authority to make the pack look complete.

4) **Install cases add target-seam projections; fresh cases do not**
   - Return-only fresh-pool cases carry no target-seam projection members.
   - If `install_target` is present, `target.before` and `target.after` MUST follow the exact install-only `CH-SPROJ v0` contract pinned in `docs/40-verification/worker-pool-target-projection-v0.md`.
   - This keeps non-commutativity grounded on the target seam rather than on constructor-global sequencing lore.

5) **Transcript evidence is a bounded slice, not a log dump**
   - `transcript.slice` MUST follow the exact case-indexed bounded-window contract pinned in `docs/40-verification/worker-pool-transcript-slice-v0.md`.
   - The pack MUST NOT require a whole-system log export or an ambient log query to validate the family.
   - Transcript members may be embedded or referenced via `CH-AREF v0`, but the pack label vocabulary stays the same either way.

6) **Verdicts are keyed by stable case ids, not prose names**
   - `verdict.summary` MUST follow the exact compact contract pinned in `docs/40-verification/worker-pool-verdict-summary-v0.md`.
   - `verdict.summary` MUST mechanically report results for the stable minimum case-id set:
     - `fresh-commute`,
     - `install-conflict`,
     - `missing-import`,
     - `export-widen`,
     - `ambient-acquire`,
     - `digest-mismatch`.
   - The summary MUST also bind the reviewed `pool_size`, canonical exported names `pool.control` plus `worker[i]`, and pass/fail status for the delta predicate and replay predicate.
   - Tools may render nicer prose around those results, but the stable case ids are what downstream comparison and regression gates rely on.

7) **Human notes are optional and non-authoritative**
   - A pack MAY carry extra operator notes or markdown, but any such notes are outside the canonical member set and MUST NOT affect replay, confinement, or ordering verdicts.
   - Review, CI, and cross-run comparisons key off the canonical member labels and the digest-first/member-exact contract above.

## Out of scope in v0

- A constructor-generic evidence-pack schema for every future family.
- Alternate member labels for equivalent content.
- Per-worker verbose logs, metrics streams, or diagnostics trees as required pack members.
- Automatic artifact fetching from unreviewed `locator` hints.
- Embedding raw authority/capabilities inside the pack itself.

## Wiring

- Decision surface: **D-CONSTR**.
- Family choice: `docs/30-architecture/worker-pool-constructor-family-v0.md`.
- Exact invocation boundary: `docs/30-architecture/worker-pool-constructor-invocation-v0.md`.
- Exact sponsor-import contract: `docs/30-architecture/worker-pool-sponsor-surface-v0.md`.
- Exact install-target contract: `docs/30-architecture/worker-pool-install-target-surface-v0.md`.
- Exact seed-import meaning: `docs/30-architecture/worker-pool-seed-surface-v0.md`.
- Exact family-local parameter schema: `docs/30-architecture/worker-pool-parameter-schema-v0.md`.
- Exact invocation-manifest contract: `docs/30-architecture/worker-pool-invocation-manifest-v0.md`.
- Exact control-handle contract: `docs/30-architecture/worker-pool-control-surface-v0.md`.
- Exact worker-entry contract: `docs/30-architecture/worker-pool-worker-surface-v0.md`.
- Primary harness contract: `docs/40-verification/worker-pool-constructor-harness-v0.md`.
- Exact cap-graph snapshot contract: `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`.
- Exact target-projection contract: `docs/40-verification/worker-pool-target-projection-v0.md`.
- Exact transcript-slice contract: `docs/40-verification/worker-pool-transcript-slice-v0.md`.
- Exact verdict-summary contract: `docs/40-verification/worker-pool-verdict-summary-v0.md`.
- Reused seams: **CH-CAPG v0**, **CH-LOG v0**, **CH-SPROJ v0**, **CH-AREF v0**, **D-CAPAUD**, **D-AREF**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-IN-TOTO**, **REF-IN-TOTO-STATEMENT**, **REF-FUCHSIA-DIAGNOSTICS**, **REF-GENODE-INIT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_evidence_pack.py` (**EVID-2026-361**).
