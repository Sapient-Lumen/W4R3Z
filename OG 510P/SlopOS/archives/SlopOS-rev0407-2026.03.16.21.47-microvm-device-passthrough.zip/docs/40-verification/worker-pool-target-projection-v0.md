# Worker-pool target projection v0 (exact `target.before` / `target.after` contract)

Purpose: pin one exact, family-local meaning for the install-only `target.before` / `target.after` members in the first concrete **D-CONSTR** evidence pack so install ordering evidence does not drift into ambient inventory dumps, target-name folklore, or equivalent-but-different post-state summaries.
This doc narrows an already-chosen surface: it reuses **CH-SPROJ v0** and the existing target seam’s conflict key family, and it does **not** introduce a new constructor-global install protocol, target inventory API, or family-specific projection schema.

Scope:
- applies only to the first concrete D-CONSTR family in `docs/30-architecture/worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-COMMUTE**, **D-CAPAUD**, **D-AREF**, **CH-SPROJ v0**, **CH-AREF v0**
- assumes the exact install import meaning is already fixed by `docs/30-architecture/worker-pool-install-target-surface-v0.md`
- assumes the exact invocation-manifest object is already fixed by `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- assumes the canonical handoff labels are already fixed by `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- assumes the exact bounded replay windows are already fixed by `docs/40-verification/worker-pool-transcript-slice-v0.md`
- assumes the exact compact result layer is already fixed by `docs/40-verification/worker-pool-verdict-summary-v0.md`
- does **not** introduce a second state-projection schema beside `CH-SPROJ v0`, a constructor-defined inventory/list/watch plane, or a target-name/alias protocol on the canonical evidence surface

## Phase-1 choice

1) **`target.before` / `target.after` are install-only `CH-SPROJ v0` receipts, not ambient inventory dumps**
   - The canonical worker-pool evidence pack carries `target.before` and `target.after` only for install cases.
   - Fresh return-only cases omit both members entirely.
   - When present, each member is one `CH-SPROJ v0` receipt (embedded directly or reached by `CH-AREF v0`) rather than a host-native dump, target listing, or constructor-specific summary blob.

2) **Projection identity stays on the target seam**
   - `target.before` and `target.after` MUST carry the same `family` and the same `key_digest`.
   - That `(family, key_digest)` pair is the already-existing owner-visible target seam identity used for install ordering; the worker-pool family adds no constructor-specific projection family token.
   - The canonical pair therefore reuses the target seam’s conflict-key family and serialization witness instead of inventing target-name folklore, constructor-local aliases, or a second ordering namespace.

3) **Projection payload is one exact canonical publication digest**
   - On the canonical member, the relevant `CH-SPROJ v0` payload fields are `family`, `key_digest`, `kind`, and `value_digest`; `meta` stays absent in Phase 1.
   - `target.before.kind` and `target.after.kind` MUST each be `digest`.
   - `target.before.value_digest` and `target.after.value_digest` each summarize exactly the canonical worker-pool publication set: `pool.control` plus `worker[i]` for `0 <= i < pool_size`.
   - That digest is computed over the exact canonical export-name sequence and the target seam’s deterministic per-name publication digests for those names only; unrelated target entries, helper outputs, aliases, target locators, or install history stay out of the canonical payload.
   - Phase 1 therefore declines `kind = present`, `kind = absent`, `kind = digestset`, raw structured target dumps, or family-local target projection variants on the canonical worker-pool evidence surface.

4) **Fresh cases omit target projection members entirely**
   - If `install_mode = return_only`, the evidence pack carries no `target.before` and no `target.after` member.
   - If `install_mode = publish_canonical`, both members are required together.
   - Phase 1 declines half-populated install evidence, background completion folklore, or “commit later” target projection updates outside the reviewed harness run.

5) **Ordering evidence compares exact before/after pairs, not target names**
   - `install-conflict` transcript windows bind the same target-seam projection digest pair that appears in `target.before` / `target.after`.
   - `verdict.summary` stays small: it only records that target projection is required for install cases; it does not duplicate the projection payload.
   - Ordering/confinement comparison therefore keys off the exact before/after digest pair plus transcript order variant (`primary` / `swapped`), not hostnames, paths, catalog entries, or ambient target identity strings.

6) **Metadata stays empty on the canonical member**
   - Phase 1 canonical worker-pool target projections carry no `meta` map.
   - The member label (`target.before` vs `target.after`), shared `(family, key_digest)`, `install_mode`, and `pool_size` already provide the reviewed meaning needed for comparison.
   - Tool-local notes, richer target dumps, or host-native locators MAY exist outside the canonical member, but they are non-authoritative and MUST NOT affect replay, confinement, or ordering verdicts.

## Out of scope in v0

- A constructor-generic target-projection schema for future families.
- A target inventory/list/watch API or install-history browser.
- Carrying target names, paths, catalog identifiers, or alias maps in the canonical projection member.
- Requiring host-native target dumps, filesystem snapshots, or implementation-specific debug objects.
- Any second constructor-defined install plane or target discovery surface.

## Wiring

- Decision surface: **D-CONSTR**.
- Primary family docs: `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-install-target-surface-v0.md`, `docs/30-architecture/worker-pool-invocation-manifest-v0.md`.
- Primary verification docs: `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/worker-pool-transcript-slice-v0.md`, `docs/40-verification/worker-pool-verdict-summary-v0.md`.
- Reused seams: **CH-SPROJ v0**, **CH-AREF v0**, **D-COMMUTE**, **D-CAPAUD**, **D-AREF**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-REALMS**, **REF-FUCHSIA-TOPOLOGY**, **REF-GENODE-INIT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_target_projection.py` (**EVID-2026-371**).
