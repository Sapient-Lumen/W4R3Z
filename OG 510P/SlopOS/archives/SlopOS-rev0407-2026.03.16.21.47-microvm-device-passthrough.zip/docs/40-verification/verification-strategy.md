# Verification strategy (multi-phase)

Goal: convert invariants into machine-checked evidence for a core slice, then expand scope deliberately.

## Layered artifacts (target)
1) Abstract spec (state machine)  
2) Executable model / reference semantics (optional but helpful)  
3) Rust implementation with `unsafe` confined  
4) Refinement: implementation refines spec under A-IDs  

## Phase alignment
- Phase 0/1: invariant design + bounded checks for rapid feedback (e.g., Kani).
- Phase 2: mechanized proof for core slice (A2).
- Phase 3: stronger properties (A3) where scope/model is explicit (info-flow, concurrency).

## Toolchain trust notes
For SMT-based tools, document solver trust assumptions and mitigations (proof replay/certificates where possible).

## “Model-check fast” targets (tight, bounded)
Use bounded model checks early to turn hypotheses into counterexamples/POs quickly:
- **Protocol contracts** (D-CONTRACT): small FSMs for selected channels (PO-CONTRACT-MCHECK).
- **OCap patterns** (D-MEMBRANE): revocation/membrane wrapper automata under staged concurrency assumptions (PO-MEMBRANE-REVOKE).
- **Encodings** (D-ENC): canonical decode/encode roundtrips and rejection cases (PO-ENC-DECODE).
- **Constructor confinement harnesses** (D-CONSTR): start with the pinned worker-pool contract in `worker-pool-constructor-harness-v0.md`, keep `worker-pool-constructor-invocation-v0.md`, `worker-pool-parameter-schema-v0.md`, `worker-pool-sponsor-surface-v0.md`, `worker-pool-install-target-surface-v0.md`, `worker-pool-seed-surface-v0.md`, `worker-pool-invocation-manifest-v0.md`, `worker-pool-control-surface-v0.md`, `worker-pool-describe-summary-v0.md`, `worker-pool-quiesce-state-v0.md`, `worker-pool-slot-state-v0.md`, and `worker-pool-worker-surface-v0.md` equally close at hand so the first family proves caller-scoped cap-graph deltas, replay bindings, canonical import/export names, the exact `CH-WPOOLPARAM v0` meaning behind `param_digest`, the exact `sponsor` meaning, the exact `install_target` meaning, the exact `worker_seed/<label>` meaning, one exact digest-first `invocation.manifest` object, the exact bounded `pool.control` contract, the exact bounded `Describe()` result shape, the exact bounded `quiesce_state` meaning, the exact bounded `worker_slots[*].state` model, the exact restart-budget semantics in `worker-pool-restart-budget-v0.md`, the exact bounded `worker[i]` contract, the exact caller-scoped `capgraph.before` / `capgraph.after` contract in `worker-pool-capgraph-snapshots-v0.md`, the exact install-only `target.before` / `target.after` contract in `worker-pool-target-projection-v0.md`, the exact bounded `transcript.slice` contract in `worker-pool-transcript-slice-v0.md`, the exact compact `verdict.summary` contract in `worker-pool-verdict-summary-v0.md`, and target-seam ordering, and emit the resulting bundle in the canonical label/case-id normal form pinned by `worker-pool-constructor-evidence-pack-v0.md` before constructor lore spreads to other families.
