# Worker-pool verdict summary v0 (exact `verdict.summary` contract)

Purpose: pin one exact, family-local meaning for the canonical `verdict.summary` member in the first concrete **D-CONSTR** evidence pack so regression tooling does not drift into prose-only result reports, per-harness case tables, or equivalent-but-different pass/fail summaries.
This doc narrows an already-chosen surface: it does **not** introduce a generic constructor verdict schema, a constructor-global results service, or a second evidence lane beside the existing pack/harness stack.

Scope:
- applies only to the first concrete D-CONSTR family in `docs/30-architecture/worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-CAPAUD**, **D-COMMUTE**, **CH-LOG v0**, **CH-AREF v0**
- assumes the canonical evidence-pack member labels and stable case ids are already fixed by `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- assumes the exact install-only target-projection pair is already fixed by `docs/40-verification/worker-pool-target-projection-v0.md`
- assumes the exact bounded transcript member is already fixed by `docs/40-verification/worker-pool-transcript-slice-v0.md`
- assumes the exact invocation-manifest object is already fixed by `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- assumes the exact exported handle names and `pool_size` meaning are already fixed by `docs/30-architecture/worker-pool-constructor-invocation-v0.md` and `docs/30-architecture/worker-pool-parameter-schema-v0.md`
- does **not** introduce a generic test-report schema, a constructor inventory UI, or a second source of truth beside the canonical evidence pack

## Phase-1 choice

1) **`verdict.summary` is a case-indexed verdict table, not a prose report**
   - The canonical `verdict.summary` member is one small machine-comparable table over the stable worker-pool case ids.
   - Human prose may be rendered around it, but the portable surface is the exact verdict table below.
   - Phase 1 therefore declines markdown-only verdicts, free-form per-tool JSON shapes, or a constructor-global results API.

2) **One exact summary object binds the reviewed family instance and export shape**
   - The top-level `verdict.summary` object contains exactly:
     - `family`,
     - `invocation_manifest_digest`,
     - `pool_size`,
     - `export_shape`,
     - `overall_verdict`,
     - `cases`.
   - `family` MUST be `worker_pool`.
   - `invocation_manifest_digest` MUST match the canonical digest pinned by `docs/30-architecture/worker-pool-invocation-manifest-v0.md`.
   - `pool_size` MUST match the reviewed `pool_size` encoded under `digest(CH-WPOOLPARAM v0)`.
   - `export_shape` MUST be the exact canonical pair `pool.control` plus `worker[i]`; the summary does not carry caller-chosen aliases, target names, or helper-handle inventories.

3) **Stable case-id order is fixed and comparison-friendly**
   - `cases` is an ordered list closed to exactly:
     - `fresh-commute`,
     - `install-conflict`,
     - `missing-import`,
     - `export-widen`,
     - `ambient-acquire`,
     - `digest-mismatch`.
   - Comparison keys off that stable order and case-id set, not on prose titles or tool-local omission rules.
   - Phase 1 adds no family-local alias names, no case-group nesting, and no optional suppression of negative cases.

4) **Each case row has one exact minimal field set**
   - Every case row contains exactly:
     - `case_id`,
     - `order_variants`,
     - `verdict`,
     - `delta_predicate_ok`,
     - `replay_predicate_ok`,
     - optional `target_projection_required`.
   - `fresh-commute` and `install-conflict` MUST report `order_variants = [`primary`, `swapped`]`.
   - `missing-import`, `export-widen`, `ambient-acquire`, and `digest-mismatch` MUST report `order_variants = [`primary`]`.
   - `verdict` is closed to `pass` or `fail`; Phase 1 does not add warning, flaky, skipped, muted, or xfail states on the canonical summary surface.
   - `target_projection_required` appears only for `install-conflict` and MUST be `true` there.

5) **Predicate results stay explicit instead of collapsing into a single prose outcome**
   - `delta_predicate_ok` records whether the caller-scoped cap-graph delta predicate passed for that case.
   - `replay_predicate_ok` records whether the replay/transcript predicate passed for that case.
   - `verdict = pass` only when the exact required `order_variants` are present and both predicate fields are `true` for the case.
   - `overall_verdict = pass` only when every canonical case row passes.
   - This keeps confinement/replay failures distinguishable without introducing a broader status taxonomy.

6) **The summary is digest-first and deliberately small**
   - `verdict.summary` binds the family instance through `invocation_manifest_digest` rather than through target identity, hostnames, PIDs, or locator hints.
   - The canonical summary carries no whole-log excerpts, no raw capability material, no reflected import inventories, no sponsor identity, and no install-target names.
   - Detailed transcripts remain in `transcript.slice`; target-seam state remains in `target.before` / `target.after`; the summary is the compact comparison layer, not a second evidence archive.

7) **Operator notes remain optional and non-authoritative**
   - Harnesses MAY attach prose notes, richer per-tool status records, or host-native test-output objects outside the canonical `verdict.summary` member.
   - Those extras MUST NOT affect replay/confinement comparison, stable case-id presence, or pack completeness.
   - The exact portable surface is the small case-indexed verdict table above.

## Out of scope in v0

- A generic verdict schema shared by every future constructor family.
- Warning/flaky/skip taxonomies on the canonical worker-pool summary surface.
- Embedding full transcript windows or target projections inside `verdict.summary`.
- Any constructor-global results service, dashboard protocol, or inventory API.
- Host-specific locator strings as authoritative verdict identity.

## Wiring

- Decision surface: **D-CONSTR**.
- Primary family docs: `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-parameter-schema-v0.md`, `docs/30-architecture/worker-pool-invocation-manifest-v0.md`.
- Primary verification docs: `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/worker-pool-target-projection-v0.md`, `docs/40-verification/worker-pool-transcript-slice-v0.md`.
- Reused seams: **D-CAPAUD**, **D-COMMUTE**, **CH-LOG v0**, **CH-AREF v0**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-IN-TOTO-STATEMENT**, **REF-BAZEL-BEP**, **REF-BAZEL-BEP-TESTSUMMARY**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_verdict_summary.py` (**EVID-2026-370**).
