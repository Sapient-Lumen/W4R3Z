# Worker-pool transcript slice v0 (exact `transcript.slice` contract)

Purpose: pin one exact, family-local meaning for the bounded `transcript.slice` member in the first concrete **D-CONSTR** evidence pack so replay/confinement tooling does not drift into per-harness log folklore.
This doc narrows an already-chosen surface: it does **not** introduce a generic transcript schema, a constructor-global log plane, or a requirement to export whole-system logs.

Scope:
- applies only to the first concrete D-CONSTR family in `worker-pool-constructor-family-v0.md`
- reuses existing seams: **D-CONSTR**, **D-CAPAUD**, **D-AREF**, **CH-LOG v0**, **CH-AREF v0**
- assumes the exact harness obligations are already fixed by `worker-pool-constructor-harness-v0.md`
- assumes the canonical evidence-pack member labels and stable case ids are already fixed by `worker-pool-constructor-evidence-pack-v0.md`
- assumes the exact invocation-manifest object is already fixed by `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- assumes install ordering, when present, already stays on the owner-visible target seam pinned by `docs/30-architecture/worker-pool-install-target-surface-v0.md` and uses the exact install-only target-projection pair pinned in `docs/40-verification/worker-pool-target-projection-v0.md`
- does **not** introduce a second transcript schema beside `CH-LOG v0`, a live log query API, or a per-worker verbose diagnostics plane

## Phase-1 choice

1) **`transcript.slice` is a case-indexed window set, not a log dump**
   - The canonical `transcript.slice` member is a bounded set of small **case windows** over ordinary `CH-LOG v0` records.
   - Each window exists only to support replay/confinement comparison for one stable harness case id.
   - The family therefore declines whole-log exports, unbounded ring-buffer dumps, or per-tool transcript folder conventions in Phase 1.

2) **Stable case ids own the slice layout**
   - Window `case_id` values are closed to the stable minimum set already pinned by `worker-pool-constructor-evidence-pack-v0.md`:
     - `fresh-commute`,
     - `install-conflict`,
     - `missing-import`,
     - `export-widen`,
     - `ambient-acquire`,
     - `digest-mismatch`.
   - `fresh-commute` and `install-conflict` each carry exactly two windows with `order_variant` in {`primary`, `swapped`}.
   - `missing-import`, `export-widen`, `ambient-acquire`, and `digest-mismatch` each carry exactly one window with `order_variant = primary`.
   - Phase 1 adds no free-form case names, no prose-only grouping, and no tool-local omission of the swapped-order windows for the commutativity cases.

3) **Each window binds one exact digest target plus ordered log references**
   - Every case window contains exactly:
     - `case_id`,
     - `order_variant`,
     - `invocation_manifest_digest`,
     - `event_refs`,
     - optional `target_projection_digest`.
   - `event_refs` is an ordered list of `CH-LOG v0` digests or `CH-AREF v0` references to canonical `CH-LOG v0` entries.
   - `invocation_manifest_digest` MUST match the canonical `invocation.manifest` member carried by the same evidence pack.
   - `target_projection_digest` appears only for install cases and MUST match the corresponding owner-visible target-seam projection used elsewhere in the pack.

4) **Window contents are small and terminal outcomes are closed**
   - Each case window carries `2..4` `event_refs`.
   - The first referenced event MUST distinguish constructor start.
   - The final referenced event MUST distinguish one closed `terminal_kind` in {`success`, `deny`, `install_commit`, `install_reject`}.
   - Any interior event exists only to mark the install step or a denial boundary; Phase 1 declines verbose helper chatter, per-worker lifecycle traces, or arbitrary user notes inside the canonical window.

5) **Install evidence stays tied to the target seam**
   - Fresh return-only cases omit `target_projection_digest`.
   - `install-conflict` windows MUST bind `target_projection_digest` and include an install-step event in `event_refs`.
   - This keeps non-commutativity grounded on the existing owner-visible target seam rather than on constructor-global sequencing folklore or hidden installer state.

6) **The whole slice stays bounded and comparison-friendly**
   - The canonical `transcript.slice` member carries at most `8` case windows and at most `24` total `event_refs`.
   - Tools MAY embed the referenced `CH-LOG v0` entries or carry them indirectly via `CH-AREF v0`, but normalized comparison keys only off the exact case-window fields above.
   - The pack MUST NOT require an ambient log query, a whole-system log export, or host-specific locator resolution to validate one worker-pool harness run.

7) **Operator notes and full logs remain optional and non-authoritative**
   - Harnesses MAY attach fuller logs, markdown notes, or host-native trace exports outside the canonical `transcript.slice` member.
   - Those extras MUST NOT affect replay/confinement verdicts, stable case-id comparison, or pack completeness.
   - The exact portable surface is the bounded case-indexed window set above, not an ambient log archive.

## Out of scope in v0

- A generic transcript/window schema shared by every future constructor family.
- Streaming or queryable transcript APIs.
- Required per-worker verbose diagnostics or metrics in the canonical window set.
- Host-specific locator strings as authoritative transcript identity.
- Any second admin plane for browsing or rehydrating transcript history.

## Wiring

- Decision surface: **D-CONSTR**.
- Primary family docs: `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-invocation-manifest-v0.md`, `docs/30-architecture/worker-pool-install-target-surface-v0.md`.
- Primary verification docs: `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/worker-pool-target-projection-v0.md`.
- Reused seams: **CH-LOG v0**, **CH-AREF v0**, **D-CAPAUD**, **D-AREF**.
- Assurance hooks: **I-CONSTR-1**, **I-CONSTR-2**, **PO-CONSTR-CONFINE**, **PO-CONSTR-REPLAY**.
- External inspirations: **REF-FUCHSIA-DIAGNOSTICS**, **REF-FUCHSIA-DIAGNOSTICS-SCHEMA**, **REF-IN-TOTO-STATEMENT**, **REF-ANDROID-BUGREPORT**.

## Evidence hook

- CI drift gate: `tools/check_constructor_worker_pool_transcript_slice.py` (**EVID-2026-369**).
