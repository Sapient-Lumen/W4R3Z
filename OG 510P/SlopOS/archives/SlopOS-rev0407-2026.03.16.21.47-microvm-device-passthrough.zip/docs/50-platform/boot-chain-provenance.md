# Boot chain & provenance

Goal: we can say what code is running, resist rollback, and tie artifacts to reproducible builds.

## Boot models
- Verified boot: enforce signed components.
- Measured boot: record hashes for attestation.
Possible: both (enforce + audit), depending on deployment profile.

## Updates & anti-rollback
Adopt patterns from TUF (REF-TUF) and supply-chain frameworks (REF-SLSA, REF-IN-TOTO). Keep policies explicit and testable.

If D-ATOMICUPD is enabled, prefer an A/B-style *trial boot then commit* model: represent the selector state as CH-BOOTSEL (active/LKG/pending + bounded tries) and only mark a deployment “current” after an explicit boot-success mark under the profile’s health predicate (I-ATOMICUPD-3). Record the CH-BOOTSEL digest in CH-BOOT for audit.


Schema contracts for boot/config are pinned as CH-BOOT v0 / CH-CFG v0 (see `docs/30-architecture/boot-manifest-schema-v0.md` and `docs/30-architecture/config-schema-v0.md`); encoding requirements are summarized in `docs/30-architecture/encoding-policy.md`.

## Reproducibility
High-assurance release profiles require reproducible builds (REF-REPRODUCIBLE-BUILDS) and signed provenance attestations.

## Assumptions
- Anti-rollback requires **A-BOOT-2** (monotonic counters or equivalent) per `docs/10-threat-model/assumption-registry.md`.
