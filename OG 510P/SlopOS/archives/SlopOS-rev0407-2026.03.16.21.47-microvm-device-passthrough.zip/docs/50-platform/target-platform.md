# Target platform strategy

Pick a platform that supports the threat model and keeps bring-up + proof obligations manageable.

## Requirements (derived from A-IDs)
- virtualization/isolation primitives adequate for chosen architecture shape
- credible DMA story (IOMMU or explicit weakening)
- emulator + real hardware path
- documentation quality sufficient to model assumptions

## Candidates (v0)
- x86_64: mature virt; complex boot legacy
- ARMv8+: strong privilege model; vendor variation
- RISC-V: openness; ecosystem variability

Decision recorded as ADR with evidence.


## Optional capability-hardware profile (research track)
Even in a Rust-heavy system, we may need to run legacy C/C++ (firmware, vendor drivers, third-party libs). Capability hardware (CHERI line of work) offers fine-grained bounds/permissions and scalable compartmentalization that can reduce bug blast radius.

CheriBSD (and related Morello Linux evaluation work) is a practical reference point for what “CHERI-ready” looks like in a real OS stack and what residual risks remain.

This is *not* required for Phase 1, but we should avoid design choices that preclude a CHERI evaluation later (e.g., designs that rely on treating pointers as raw integers across trusted boundaries).

Decision: D-CHERI (see RFC-0060).

Refs: REF-CHERI-INTRO, REF-CHERI-MORELLO, REF-CHERI-FAQ, REF-CHERIBSD, REF-CHERI-ANALYSIS-2026.
