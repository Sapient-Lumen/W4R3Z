# TCB inventory (claim-specific)

TCB is defined per claim (C-ID). This doc records candidate decompositions and where we expect the trusted boundary to sit.

## Candidate: hypervisor-first
Privileged TCB candidates:
- minimal VM-exit/trap handling
- second-stage translation management (EPT/NPT/Stage-2)
- interrupt routing + minimal scheduler
- capability/object table + allocator
Non-TCB (ideally): drivers, filesystems, network, policy services.

## Candidate: microkernel-first
Privileged TCB candidates:
- threads, IPC, address spaces, capabilities
Potential risk: virtualization later may bloat TCB.

## Devices/DMA
If IOMMU is not used/enforced, device behavior becomes part of the effective TCB for isolation-related claims (must be explicit in C-ISO-2 and A-DMA-1).
