# Unsafe obligation registry (U-IDs)

Purpose: keep `unsafe` reasoning compact and auditable by recording *obligations* (not prose) in one place.  
Rule: every `unsafe` block in privileged code must map to exactly one **U-ID** entry here.

See also: `docs/60-engineering/unsafe-concurrency-policy.md`.

## Entry format
- **U-XXXX**: location (path::item), purpose
  - Preconditions: minimal safety preconditions
  - Preserves: invariants preserved across the unsafe operation (I-IDs)
  - Evidence: EVID links (tests/model checks/proofs), once they exist
  - Notes: review notes, bounded scope, intended refactoring

## Registry (seed, high-probability unsafe sites)
- **U-1001**: <arch>::trap_entry — trap/exit entry/return glue (register save/restore, stack discipline)
  - Preconditions: privileged stack is valid; ABI for saved context is correct; interrupts masked/unmasked only via explicit protocol
  - Preserves: I-STATE-1, I-OBJ-1
  - Evidence: <future E1/E2>
  - Notes: keep assembly minimal; treat as “leaf” unsafe boundary

- **U-1002**: <mm>::page_table_update — manipulate page tables / stage-2 mappings
  - Preconditions: exclusive ownership of mapping objects; TLB protocol is followed; no aliasing of mutable page-table structures
  - Preserves: I-MAP-1, I-SHARE-1, I-STATE-1
  - Evidence: <future E1/E2>
  - Notes: link to D-ARCH/D-ISA mapping model; SMP baseline uses a coarse mapping lock plus an explicit TLB shootdown protocol consistent with D-MEMMODEL (I-CONC-1)

- **U-1003**: <io>::mmio_access — volatile MMIO reads/writes (device registers)
  - Preconditions: access is authorized by a capability; address range is within declared device window; ordering/fences follow D-MEMMODEL
  - Preserves: I-STATE-1, I-DMA-1 (if C-ISO-2 claimed)
  - Evidence: <future E1>
  - Notes: keep device logic out of privileged core when possible (C-DRV-1)

- **U-1004**: <sync>::atomics_fences — architecture atomics/fences and raw pointers in lock-free paths
  - Preconditions: pattern is in the approved subset for D-MEMMODEL; no data races in the modeled execution
  - Preserves: I-CONC-1, I-STATE-1
  - Evidence: <future E2> (litmus suite), <future E3>
  - Notes: avoid lock-free paths early unless required; prefer coarse locking and keep the approved atomic/fence subset small. Any lock-free path must be justified and litmus-tested (PO-MEM-LITMUS).

- **U-1005**: <mem>::zeroize — explicit memory wiping on reuse/quarantine (if adopted)
  - Preconditions: target memory is exclusively owned; wiping cannot race with DMA/other domains under D-DMA policy
  - Preserves: I-STATE-1
  - Evidence: <future E1>
  - Notes: only becomes relevant if ADR adopts remanence/zeroize policy (see D-ZEROIZE)
