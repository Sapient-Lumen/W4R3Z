# Assurance case (compact argument structure)

This is a *template* for building an assurance argument without bloating narrative text.
We use a Goal/Strategy/Context/Evidence structure (GSN-like), but keep it minimal.

## G0 (Top goal)
The privileged core enforces the declared security/correctness claims (C-IDs) under stated assumptions (A-IDs), with evidence (EVID-IDs) sufficient for the targeted assurance level (A0–A3).

## Strategy S0 (Decompose by claims)
For each claim C-*, argue it via:
- invariants I-* that are preserved by all transitions
- implementation/refinement evidence linking code to the spec
- platform/boot assumptions A-* that bound the environment

## Pattern (repeat per claim)
### Goal: C-...
- **Context:** scope + profile (P0/P1/P2) + assumptions (A-IDs)
- **Strategy:** show invariants imply property, and transitions preserve invariants
- **Subgoals:** (typically) spec well-formedness; transition preservation; interface confinement; `unsafe` obligations
- **Evidence:** link to EVID entries (prototype/model-check/proof) and ADR(s)

## Non-goal recording
For anything *not* claimed (e.g., side channels), record explicitly in `non-claims.md` (and keep `assurance-claims.md` short).
