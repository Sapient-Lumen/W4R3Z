# Traceability (Claim → Invariant → Assumption → Evidence → Decision)

This file stays small: it is a pointer map, not a narrative.
Use family references like `<I-BOOT-*>` only as shorthand; concrete IDs are in registries.

| Claim (C-ID) | Invariants (I-IDs) | Assumptions (A-IDs) | Evidence (EVID) | Decision (ADR) |
|---|---|---|---|---|
| C-STATE-1 | I-STATE-1, I-OBJ-1, I-CAP-1 (if applicable) | A-HW-1 | <future E1/E3> | ADR-???? |
| C-CAP-1 | I-CAP-1, I-OBJ-1 | A-HW-1 | EVID-2026-002 (E2), <future E3> | ADR-???? |
| C-ISO-1 | I-MAP-1, I-SHARE-1, I-OBJ-1 | A-HW-1 | EVID-2026-001 (E1), <future E3> | ADR-???? |
| C-ISO-2 | I-MAP-1, I-DMA-1 | A-HW-1, A-DMA-1 | <future E1/E3> | ADR-???? |
| C-BOOT-1 | I-BOOT-1, I-BOOT-2 (if claimed) | A-BOOT-1 (+A-BOOT-2 if anti-rollback) | <future E1/E4> | ADR-???? |
| C-ATTEST-1 | I-ATTEST-1, I-BOOT-1, I-ENC-1 | A-ATTEST-1 (+A-ATTEST-2 if freshness) | EVID-2026-026 (E0), <future E1/E4> | ADR-???? |
| C-UNSAFE-1 | I-UNSAFE-1, I-STATE-1 | A-HW-1 | <future E0/E1> | ADR-???? |
| C-CONC-1 | I-CONC-1, I-STATE-1 | A-HW-2 | <future E1/E2> | ADR-???? |
| C-LLM-1 | I-LLM-1, I-OBS-1 | A-TOOL-1 | <future E1/E2> | ADR-???? |
| C-PROV-1 | I-BOOT-1, I-ENC-1 | A-BOOT-1, A-TOOL-1 | <future E4> | ADR-???? |
| C-PROV-2 | I-PROV-CHAIN-1, I-BOOT-1, I-ENC-1 | A-BOOT-1, A-TOOL-1 | <future E1/E4> | ADR-???? |
| C-IFC-1 | I-IFC-1, I-IFC-2, I-IFC-3 | A-HW-1 | EVID-2026-082 (E0), <future E2/E3> | ADR-???? |
| C-OBS-1 | I-OBS-1, I-LOG-1 | A-HW-1 | <future E1/E2> | ADR-???? |
| C-TIME-1 | I-TIME-1 | A-BOOT-2 | <future E1/E2> | ADR-???? |
| C-ABI-1 | I-STATE-1, I-IF-1, I-ENC-1 | A-HW-1 | <future E1/E2> | ADR-???? |
| C-HV-1 | I-STATE-1, I-IF-1 | A-HW-1 | <future E1/E2> | ADR-???? |
| C-DRV-1 | I-STATE-1, I-DMA-1 (if claimed) | A-DMA-1 | <future E1/E2> | ADR-???? |
