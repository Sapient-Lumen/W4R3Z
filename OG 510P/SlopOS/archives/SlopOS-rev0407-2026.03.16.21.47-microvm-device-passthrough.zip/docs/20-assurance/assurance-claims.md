# Assurance claims (levels and scope)

This doc defines claim maturity levels and points to the Claim Registry (C-IDs).

## Levels (A0–A3)
- **A0:** engineering evidence only (tests, fuzzing, review)
- **A1:** bounded/model-checked (e.g., Kani) evidence
- **A2:** machine-checked functional correctness for a defined core slice (refinement)
- **A3:** stronger security properties (e.g., scoped information-flow) with explicit models

## Canonical claims
See `claim-registry.md` for C-IDs; each C-ID must list:
- scope and assumptions (A-IDs)
- supporting invariants (I-IDs)
- evidence (EVID-IDs)

## Explicit non-claims (default)
Canonical list: `non-claims.md`. Side-channel posture: `docs/10-threat-model/sidechannels.md`.
