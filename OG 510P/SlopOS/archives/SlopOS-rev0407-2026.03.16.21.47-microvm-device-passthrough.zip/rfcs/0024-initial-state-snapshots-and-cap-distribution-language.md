# RFC-0024: Initial state snapshots and capability distribution language (D-INITSNAP)

Status: draft

## Goal
Make the **initial privileged state** (object graph + capability distribution + initial mappings) an explicit, pinned artifact.

This supports:
- **audit/debug**: compare expected vs actual authority distribution
- **system build**: generate init/boot images from a single, reviewable source
- **assurance**: connect boot/config artifacts to a concrete *time-0* abstract-machine state, improving replay/refinement arguments.
- **fast spawn (optional)**: treat CH-INIT as a digest-identified “template image” for low-latency disposable domains (zygote-style warm templates) without adding privileged-kernel logic.

Inspiration: seL4’s **capDL** describes *state snapshots* of capability-based systems and is used both for documentation/debugging and as an input to analysis/initialization tooling.

Template-spawn prior art (pattern, not a dependency): REF-ANDROID-ZYGOTE, REF-ANDROID-MEMORY-OVERVIEW, REF-CHROMIUM-ZYGOTE.

## Non-goals
- This RFC does **not** mandate a full CAmkES-style framework or a complex meta-language.
- This RFC does **not** change the external capability semantics (I-CAP-1).
- This RFC does **not** require dynamic system configuration; it is compatible with D-PART and static profiles.

## Decision (D-INITSNAP)
We add an optional schema **CH-INIT v0** for a bounded “initial snapshot” description.

Options:
- **None (default)**: hand-coded init; time-0 state is implicit.
- **CH-INIT v0 (recommended for D-PART early slice)**: a bounded snapshot validated at boot, with digests bound in CH-BOOT.
- **capDL-compatible dialect**: defer; only pursue if it reduces our tool/proof burden.

## CH-INIT v0 shape
See `docs/30-architecture/init-state-snapshot-schema-v0.md`.

Key properties:
- closed enums + bounded lists
- canonical encoding (I-ENC-1)
- can bind to other artifacts (CH-PART/CH-COMP/CH-ADDRNET) by digest, without duplicating them

## New invariants/obligations
- I-INIT-1, I-INIT-2
- PO-INIT-VALIDATE, PO-INIT-MATCH

## Evidence plan (tight)
E1:
- implement a checker that validates CH-INIT v0 bounds + cross-field consistency
- add a **snapshot-dump** facility (user space) for comparing expected vs actual distributions (structural equality + digest match)

E2:
- bounded model check: **no undeclared initial authority edges** exist beyond CH-INIT (under the selected profile’s bounds)

## Interactions
- D-RR: CH-INIT can act as the replay **initial state seed**.
- D-PART: CH-INIT is a natural companion to CH-PART (static partitions), keeping init strictly policy-as-data.
- D-COMP: CH-INIT may reference CH-COMP rather than duplicating routes.

## Risks
- Snapshot drift: must be caught by CI/lint and bound into CH-BOOT.
- Over-ambition: keep CH-INIT minimal; avoid turning it into a general-purpose programming language.
