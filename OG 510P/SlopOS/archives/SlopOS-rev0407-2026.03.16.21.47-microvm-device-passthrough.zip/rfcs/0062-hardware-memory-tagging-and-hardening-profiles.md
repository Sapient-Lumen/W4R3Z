# RFC-0062: Hardware memory tagging + hardening profiles (D-MEMTAG)

Status: Draft  
Last updated: 2026-02-24

Decision node(s): D-MEMTAG

Goal: make “memory-safety hardening for unsafe/legacy compartments” a **first-class, explicit knob** that can be enabled in production-like builds where hardware support exists (especially Arm MTE), without bloating the privileged core.

Motivation sources: Android’s staged adoption of Arm MTE (and the related sanitizer ecosystem), plus Linux’s MTE interface model. Refs: REF-ANDROID-MTE, REF-ANDROID-NDK-MTE, REF-LINUX-MTE, REF-GOOGLEBLOG-MTE, REF-ARM-MTE-INTRO.

Non-goals:
- Replacing safe-language discipline (D-UNSAFE remains the baseline posture).
- Claiming a full elimination of memory corruption (MTE is probabilistic and profile-scoped).
- Adding a large in-kernel “sanitizer framework.”

## Problem
Even with a Rust-first privileged core, we will run some amount of:
- legacy code (compat domains, shims),
- unsafe code (HAL, critical paths), and
- complex user-space driver stacks.

When memory corruption exists in those compartments, the dominant failure mode is **capability theft + control-flow hijack** inside a privileged-enough domain (e.g., driver domains, gateway services).

We already mitigate blast radius via isolation (D-DRVDOM / D-MICROVM / D-PART) and W^X (D-DYNCODE). What’s missing is a **systematic, reviewable hardening seam** that makes it cheap to run “bug-catching” and exploit-hardening modes for risky compartments *by default where hardware allows*.

## Proposal

### 1) Add an optional platform hardening decision: D-MEMTAG
Add a decision node that selects one of:
- **none (default)**: no hardware tagging hardening.
- **MTE-user (preferred)**: enable Arm MTE for selected *user-space* compartments (drivers, shims, risky parsers) when hardware/ABI support exists.
- **MTE-all (aggressive)**: enable MTE broadly for most user-space components (compatibility permitting).

Notes:
- MTE modes matter. Treat the “synchronous” vs “asynchronous” check mode as a declared policy choice (debug vs production posture).
- Where MTE is unavailable, allow a “software fallback” profile (e.g., HWASan/ASan for tests), but keep it out of runtime TCB.

### 2) Pin hardening intent as data: CH-HARDEN v0
Introduce a small, canonical artifact that declares a component’s hardening posture:
- which hardening features are *required* vs *optional*,
- which hardware features are assumed, and
- which failure behavior is expected (kill-on-fault vs report-only in dev).

This enables:
- review (“why is this driver not hardened?”),
- reproducibility (“what hardening was active?”),
- attestation/provenance binding (D-BOOT / D-PCP synergy), and
- automated checks (“if a component declares memtag required, init refuses to launch it without memtag enabled”).

### 3) Enforcement is user space + narrow privileged hooks
Preferred enforcement model:
- init/component manager reads CH-HARDEN digests bound in CH-BOOT (and/or CH-COMP metadata) and applies process/domain launch flags.
- the privileged core only provides the minimal mechanism needed to:
  - request a memtag-enabled address space / mapping mode (platform-specific), and
  - surface tag faults deterministically to the domain’s fault handler (or kill per profile).

Do **not** make the kernel interpret “hardening policy.” It provides mechanisms; policy is data.

## Candidate invariants / proof obligations
- **I-HARDEN-1 (Hardening profile binding, optional):** if CH-HARDEN is used, the active hardening profile digests are listed in CH-BOOT `artifacts` under a declared role and are exportable for audit; mismatches are treated as policy violations.
- **I-MEMTAG-1 (Declared hardening is enforced, optional):** for components that declare `memtag=require`, launch-time configuration ensures tag-checking is enabled for the declared scope; a component cannot silently start “less hardened” than declared.

- **PO-HARDEN-BIND:** validate that the hardening profile digest(s) used at runtime match the digests bound in the boot/update manifests.
- **PO-MEMTAG-ENF:** for the chosen D-MEMTAG mode, show that launch/mapping paths cannot bypass memtag enablement for `memtag=require` compartments, and that tag faults are handled according to profile.

## Abuse-case pressure test
- **AC-051** targets the “memory corruption → capability theft” path and measures whether D-MEMTAG materially raises the bar without breaking the isolation story.

## Evidence plan (stageable)
E1:
- CH-HARDEN validator + launch-time checks (refuse to launch a `memtag=require` component when memtag is absent)
- a small demo compartment (C/Rust-unsafe) with intentional UAF/overflow, showing MTE catches faults on supported hardware/emulation

E2:
- fuzz a risky parser/driver-compartment with memtag enabled; show crash triage quality and catch-rate vs baseline

E3 (optional):
- mechanize the “no bypass” property for the launch configuration on a bounded slice (e.g., init + domain launcher)

## Alternatives
1) **Rely on ASan/HWASan only**.
   - Pro: strong bug-finding.
   - Con: overhead and build-mode divergence reduce chances of “ship what you test.”

2) **Make CHERI the only hardware memory-safety track**.
   - Pro: strong deterministic guarantees.
   - Con: CHERI adoption is still limited; MTE covers a wider near-term hardware base.

3) **Don’t standardize hardening as data**.
   - Con: hardening becomes ad-hoc flags; audit and provenance binding are lost.

## Open questions
- Should CH-HARDEN attach per-component in CH-COMP (future CH-COMP v1), or be bound via CH-BOOT artifacts only in v0?
- What is the minimal privileged hook we need for memtag enablement across: bare metal, microVM, and partition profiles?
- How should “report-only” vs “kill” be staged between dev/test and production profiles?
