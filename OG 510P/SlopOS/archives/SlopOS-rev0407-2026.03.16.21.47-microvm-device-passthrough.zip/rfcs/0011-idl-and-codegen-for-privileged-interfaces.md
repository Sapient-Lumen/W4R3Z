# RFC-0011: IDL + code generation for privileged interfaces (D-IDL)

Status: Draft

Goal: shrink `unsafe` + drift by making privileged interfaces **generated from a pinned definition**, while keeping CH-* schemas as the canonical cross-boundary contracts.

## Problem
Hand-written marshalling/dispatch code is a classic source of:
- decoder differentials and parser bugs (attack surface)
- silent drift between spec and implementation
- scattered `unsafe` for pointer/length handling

We want the inverse: interface definitions as *data*, generator output as a derived artifact, and drift detection as a build gate.

## Candidate decision: D-IDL
Introduce an **optional** interface-definition layer used for generation and auditing.

Key constraint: CH-* schemas remain the canonical “wire contracts.” D-IDL exists to:
- generate stubs/wrappers for IF-KABI and selected user-space contracts
- generate validators/pretty-printers/docs from the same source
- pin generator version + input digests to prevent silent divergence

## Minimal seam (what we spec)
We define a generator contract (not a new privileged surface):
- Inputs: a pinned IDL (or schema-derived IDL) + generator version
- Outputs: stubs/dispatch tables + conformance tests + a digest manifest
- Guard: build fails if generated output digest doesn’t match the pinned manifest

This can be implemented using:
- a minimal in-repo IDL tailored to CH-KABI/CH-LOG, **or**
- reuse of an existing IDL ecosystem while keeping canonicalization rules explicit.


## Canonical IDL digests + ordinals
If D-IDL is enabled, `idl_digest` values must be computed over a **canonical representation** (compiler IR / descriptor), not raw source text, to avoid spurious drift and ambiguity.

For RPC surfaces that use method selectors (e.g., CH-CAPRPC.method_id), codegen must also treat **ordinals as a compatibility contract** (no reuse/renumbering). For open interfaces, hash-derived ordinals are recommended so additive evolution does not require touching existing ids.

See: `docs/60-engineering/idl-digest-and-ordinal-policy.md` and RFC-0072.

## Invariants / proof obligations
- Add invariants: **I-IDL-1**, **I-IDL-2** (canonical idl_digest), **I-IDL-3** (ordinals are stable when used).
- Add POs: **PO-IDL-DRIFT**, **PO-IDL-CANON**, **PO-ORD-VALIDATE**, **PO-ORD-NOREUSE**.

## Evidence plan (tight)
Phase 0/1:
- E1: generator produces stubs + round-trip decode/encode tests for CH-KABI v0.
- E1: CI gate checks generator version and input digest; drift is fail-closed.

Phase 2:
- E2: bounded model check small parser/state-machine fragments generated from the same definitions ("spec-first → model-check-fast").

## Notes / inspirations
- CAmkES (seL4) shows that component/IDL codegen can keep boundaries explicit without expanding the privileged core.
- Redox’s machine-readable syscall definitions are a pragmatic example of “ABI as data.”

## References
Refs: REF-CAMKES, REF-REDOX-SYSCALLS, REF-PROTOBUF-TECHNIQUES, REF-CAPNP-IDS, REF-FUCHSIA-FIDL-LANG, REF-FUCHSIA-RFC-0020.
