# RFC-0016: Voluntary self-restriction (promises + “unveil”-style narrowing) (D-SEAL)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-SEAL, D-NS, D-CAPMODE

## Summary
Make it *easy* for services, launchers, and compatibility layers to **narrow themselves** after initialization in a way that is:
- **one-way** (monotonic narrowing),
- **reviewable** (small, closed vocab),
- **enforceable** (optionally at the privileged-effect boundary), and
- **auditable** (transcript-visible commitments).

This borrows the ergonomic lesson from OpenBSD’s pledge/unveil: least-privilege adoption succeeds when the default path is low-ceremony and mechanically checkable.

Refs: REF-OPENBSD-PLEDGE, REF-OPENBSD-UNVEIL, REF-BECK-PLEDGEUNVEIL-2018, REF-LWN-UNVEIL, REF-PLASH, REF-CAPSICUM, REF-LANDLOCK.

## Motivation
In a capability system, a component can always drop capabilities. In practice, however:
- large services and compat layers often retain broad internal surfaces;
- exploit chains thrive on *latent* authority that “shouldn’t be used anymore”; and
- auditors want an objective answer to “did this component stop doing X after init?”

A tiny, explicit “self-restriction” mechanism turns "we promise we don’t use X" into something we can test, log, and (optionally) enforce.

## Design

### 1) Two enforcement levels (same semantics)
We support incremental adoption with two levels that share the same conceptual contract.

**L0 — library + audit (no new privileged mechanism):**
- a standard wrapper library refuses disallowed operations *in-process*;
- CI/auditors verify the post-seal **action stream** (privileged-effect requests in CH-KABI/CH-ACP, or replay artifacts in D-RR profiles) contains no forbidden effect kinds after the promise point.

**L1 — privileged-effect enforced (optional):**
- a one-way **promise mask** is installed for the domain;
- disallowed privileged effects fail closed even if the component is compromised.

L0 often suffices for early hardening and “steady-state discipline.” L1 is reserved for high-value targets (compat shims, parsers, network-facing services) where we want mechanical defense-in-depth.

### 2) Promise mask (pledge-style)
A component may commit to a **subset** of privileged effect families it will ever invoke after init:
- the commitment is **one-way** (cannot be widened without an explicitly authorized reconfiguration event);
- violations are handled deterministically (profile chooses deny vs terminate);
- the vocabulary is closed and versioned to keep the seam small.

Concrete contract artifact: **CH-PLEDGE v0** (`docs/30-architecture/pledge-contract-schema-v0.md`).

Mapping principle:
- Promise tokens do not grant authority.
- They only allow *using already-held* authority along certain channels (KABI action kinds, portal intents).

Relationship to other seams:
- **D-CAPMODE** prevents *acquiring* new authority from ambient/global namespaces.
- **CH-PLEDGE** prevents *exercising* certain privileged effects even if the domain still holds the capability to request them.
- **D-SEAL** is the umbrella posture: init → narrow → steady state.

### 3) “Unveil”-style narrowing (handles, not paths)
Path-based “unveil” is valuable mainly for **compatibility domains** (POSIX/WASI-like) that retain path APIs.

In our world:
- the compat filesystem namespace is an explicit **view object**;
- “unveil” becomes a one-way operation that removes subtrees from that view (or seals the view to forbid further mounts);
- no raw path acquisition is introduced: underlying access is still capability-mediated.

This keeps the good part (ergonomic narrowing) while staying aligned with “handles not paths.”

### 4) Spawn-time contracts (supervisors/launchers)
A supervisor may apply a child’s promise mask before the child runs user code:
- `child_promises` MUST be a subset of the parent’s promises;
- the child may further narrow itself post-start.

This mirrors OpenBSD’s “exec promises” idea, without making exec special in the privileged core.


### 4b) Capability services for “ambient-ish” functions (Casper pattern)

A recurring adoption snag for capmode/self-restriction is that many real programs still need a small set of OS facilities that are *traditionally ambient*: DNS resolution, user/group lookup, network interface queries, sysctl reads, timezone/locale info, etc.

Capsicum’s **Casper** framework is a pragmatic answer: before entering capability mode, a program opens an explicit capability channel to a specific **system service** (e.g. `system.dns`, `system.net`, `system.sysctl`). After entering capmode, it can only use those services through the already-held channel — no ambient fallbacks.

Archive posture (portable):
- treat these as ordinary user-space components with pinned interfaces (CH-IFACE)
- open the required service handles during init
- then seal/capmode; close any “service introducer” handle
- keep the vocabulary small and profile-scoped (avoid recreating a giant libc in the name of compatibility)

Maps to: D-SEAL, D-CAPMODE, D-TRANS (adjunct).
Refs: REF-FREEBSD-LIBCASPER, REF-FREEBSD-CAPSICUM.

## 5) Learning/audit mode (token discovery)

A core reason pledge/unveil succeeded operationally is that the policy vocabulary is *human-scale* (promises), and programs can iteratively narrow without having to enumerate raw syscalls. OpenBSD also supports an `execpromises` string so supervisors can apply a child’s initial promises before it runs user code.

Archive posture:
- Treat `violation = "deny"` in CH-PLEDGE as a **complain/learn mode**: deny the forbidden effect, but emit a deterministic, redaction-safe violation record so tooling can suggest the minimal promise set.
- Provide a standard CI harness that runs services under representative workloads in learn mode and fails if the steady-state token set drifts without an explicit review/update.

Engineering doc: `docs/60-engineering/authority-bracketing-and-promise-learning.md`.

Modern validation that this “learnable promises” posture improves usability: SerenityOS has independently adopted pledge/unveil patterns for its base utilities, and recent sandboxing research (Threadbox) explicitly motivates pledge-style promises over syscall-by-syscall filters because of authoring/debug cost.

Refs: REF-OPENBSD-PLEDGE, REF-OPENBSD-UNVEIL, REF-SERENITY-PLEDGEUNVEIL, REF-THREADBOX-ARXIV25.

## Threat-model impact
Helps mitigate:
- post-init privilege creep (“init finished, but the process still *can* do everything”);
- exploit chains that rely on “rarely used” privileged calls remaining available;
- policy drift in large services: the contract becomes a testable steady-state boundary.

Does *not* guarantee confinement if capability distribution is wrong (non-goal):
- if a component is granted a powerful capability and the promised operations include using it, self-restriction won’t save you.

## Assurance/verification impact
New invariants (optional profile):
- **I-PLEDGE-1 (Monotonic narrowing)**: installing/updating a promise mask can only remove promises.
- **I-PLEDGE-2 (No bypass)**: enforcement is applied at every privileged-effect boundary.
- **I-PLEDGE-3 (Monotonic inheritance)**: children cannot start broader than parents.

New proof obligations:
- **PO-PLEDGE-VALIDATE**: CH-PLEDGE validation is total; unknown tokens reject.
- **PO-PLEDGE-ENFORCE**: every privileged-effect dispatch checks the active mask.
- **PO-PLEDGE-INHERIT**: spawn-time installation/inheritance is monotonic and transcript-visible.

Evidence targets:
- negative tests attempting forbidden effects post-seal (deny/kill as configured);
- tests that attempts to “widen” promises fail closed;
- a compat-domain unveil regression suite (“unveiled paths unreachable”).

## Archive impact
- Adds CH-PLEDGE v0 schema doc and schema registry row.
- Adds a pledge token→effect mapping table doc (docs/30-architecture/pledge-token-mapping.md) and a lintable mapping-change workflow (evidence-relevant).

- Expands D-SEAL decision node language to include promise masks and unveil-on-views.
- Adds I-PLEDGE-1..3 and PO-PLEDGE-VALIDATE, PO-PLEDGE-ENFORCE, PO-PLEDGE-INHERIT registry rows.
- Adds a new abuse case for promise-mask bypass/confusion (AC-046).
