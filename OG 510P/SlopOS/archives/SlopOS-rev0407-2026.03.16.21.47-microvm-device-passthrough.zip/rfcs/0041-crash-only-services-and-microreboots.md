# RFC-0041: Crash-only services + microreboot discipline (D-SUPV adjunct)

Status: Draft  
Owner: archive  
Last updated: 2026-02-24

Goal: make recovery *cheap, predictable, and non-amplifying* by adopting a crash-only discipline: when something is wrong, restart the smallest component set that can restore correct behavior (a “microreboot”), rather than layering complicated in-process error recovery.

This RFC is about **designing for restartability**. It does not add privileged mechanisms; it tightens how we use existing seams:
- D-SUPV (supervision trees + restart policy)
- D-CHKPT (optional cooperative checkpoint/restore)
- D-PERSIST / D-ATOMICUPD (snapshots + boot environments)
- D-COMP (manifested component graph)
- D-ACTIVATE (optional stable handles/activation sets for restarts)

## Why bake this in early?
Recovery is usually treated as late-stage ops glue. That’s backwards: restartability is mostly a **design constraint**, and it gets harder to retrofit once services sprawl.

If we adopt crash-only discipline early, we can:
- keep components small and isolated
- simplify error handling paths (fewer “half-broken” states)
- make upgrades safer (quiesce → swap → rollback)
- make debugging easier (restart boundaries are crisp; logs + replay are coherent)

Inspiration line: microrebooting and recovery-oriented computing (REF-MICROREBOOT-OSDI04, REF-ROC-COMPUTER04).

## Core principles (tight)
### 1) Separate *process recovery* from *data recovery*
- Restarting a component should not require rebuilding global state.
- Durable state lives in explicit stores (D-PERSIST) behind capabilities.
- In-memory state should be reconstructible from durable state + bounded replay of recent intent (optional D-RR profile).

### 2) Idempotent start + explicit readiness
- Prefer supervisor-owned stable inbound endpoints (D-ACTIVATE) so restarts don’t require re-binding global listeners or dropping new connections.

- Components must be restartable from any prior crash point.
- Each component exports a readiness/health interface (unprivileged) that:
  - transitions from `Starting` → `Ready`
  - can be probed by the supervisor
  - fails closed (never claims Ready on partial init)

### 3) Authority does not “creep back in” after restart
A restart must not be a hidden reconfiguration.
- The supervisor restarts the component using the same declared manifest routes (D-COMP) and the same seal/capmode posture.
- Any additional authority requires an explicit reconfiguration action (CH-LOG) with explicit authorization.

### 4) Quiesce boundaries are first-class
When restarting a component set, we need consistent boundaries:
- drain/close in-flight requests (D-CONTRACT helps with explicit ownership transfers)
- stop restarts for upstream dependents until the boundary is stable
- optionally take a cooperative checkpoint cut (D-CHKPT) if the component set supports it

## Integration seam (how it fits the archive)
### Supervision trees (D-SUPV)
We keep supervision policy in user space. The key is to standardize *restart hygiene*:
- restarts are rate-limited (avoid cascading failure loops)
- restart actions are transcript-logged (CH-LOG) with component ids and reason codes
- “critical” components fail closed per profile; non-critical components can be restarted aggressively

### Checkpoint/restore (D-CHKPT) as an accelerator, not a requirement
Microreboots do not require checkpointing.
However, checkpoints can reduce recovery time for stateful services:
- a supervised restart may prefer a recent cooperative checkpoint
- restore is subject to I-CKPT-1 (non-amplifying) and I-CKPT-2 (consistent cut)

### Snapshots + boot environments (D-PERSIST/D-ATOMICUPD)
For upgrades:
- take a preflight snapshot of mutable datasets
- install a new immutable deployment
- if anything looks wrong, rollback the deployment pointer + dataset snapshot selection

## New invariant hook
- **I-SUPV-1 (Restart is non-amplifying, optional)**: for profiles enabling D-SUPV, a supervised restart of a component cannot introduce new authority edges beyond those declared by the active CH-COMP routes (or explicit, authorized reconfiguration actions). Any restart-time authority is identical to (or attenuated from) the steady-state authority for that component.

## Proof obligations (seed)
- **PO-SUPV-NOAMP**: restart plans are validated against declared CH-COMP routes and seal/capmode posture; restarts cannot implicitly widen authority.
- **PO-SUPV-RLIMIT**: restart rate-limits are enforced deterministically to avoid unbounded crash loops consuming resources (ties to D-METER/D-TCAP if enabled).

## Evidence plan
Phase 0/1:
- Prototype a tiny supervised service trio (front → worker → store).
- Inject crashes in worker; show:
  - worker microreboot restores service without restarting store
  - worker does not regain init-only authority after seal
  - transcript log captures restart cause + counts

Phase 2:
- Add cooperative checkpoint for worker+store pair; demonstrate faster recovery and that restore does not amplify authority (PO-CKPT-NOAMP).

## Non-goals
- No availability claims (we do not promise “five nines”).
- No global distributed consensus story.
- No kernel-level “restart magic.” All mechanisms remain user space.

## Open questions
- How do we best represent “restart reason codes” so they are useful but not a covert channel? (Likely treat as bounded enums.)
- Should readiness be a standard service-tree node (RFC-0032) for uniform tooling?
