# RFC-0067: Capability crypto services + non-exportable key handles (D-CRYPTOSVC)

Status: draft

## Goal
Make “**keys as capabilities**” a first-class ecosystem seam: long-lived secrets live in a dedicated **crypto provider** (often the D-AUTHAGENT), and clients receive only **key handles** (capabilities) that authorize a bounded set of operations (sign, decrypt, derive, attest).

This bakes in a practical pattern that has repeatedly worked in real systems (Plan 9 factotum; ssh-agent): *the private key never leaves the agent*, and the agent interface stays small and auditable.

## Non-goals
- Claiming confidentiality if the crypto provider itself is compromised (that component becomes a high-value target).
- Defining a full PKI, TLS, or application protocol suite.
- Replacing hardware roots of trust (TPM/TEE/DICE); those remain optional profiles (D-ATTEST / D-CC).

## Why now (greenfield advantage)
Most OSes bolt “key management” on late, after apps have learned to pass raw key bytes around.  
If we standardize key handles early, we can:
- eliminate whole classes of “accidental key export” APIs,
- make delegation ergonomic (D-LEASE + key handles),
- make persistence of authority explicit and auditable (D-PERSIST stores *references*, not secrets),
- and bind crypto use into our explainability/transcript discipline (CH-LOG, D-EXPLAIN) without leaking secrets.

## Candidate decision: D-CRYPTOSVC

Pinned v0 posture follow-up: treat D-CRYPTOSVC as an **op-only, context-bound, explicit-route-only** seam. Phase 1 declines ambient `SSH_AUTH_SOCK`-style discovery, provider-global key inventory, PKCS#11-style slot/session/object semantics, and transparent forwarded-agent behavior on the core seam; those are entropy multipliers unless an explicit future RFC justifies them. `docs/30-architecture/cryptosvc-forwarding-boundary-v0.md` further freezes cross-boundary use to explicit narrowed routes only.

Adopt **pinned, redaction-safe descriptors** for:
- **CH-KEYPOL v0** — usage policy for a key (allowed ops, context strings/purpose tags, rate/confirm hints).
- **CH-KEYREF v0** — a durable, shareable reference to a key object and its policy *without* key material.
- **CH-CRYPTOAUDIT v0** — a transcript payload for crypto operations (input/output digests + attribution).

These schemas do *not* define the byte-for-byte IPC wire format; they define what must be present to make key usage reviewable,
lintable, and consistently auditable across implementations/runtimes.

### Minimal seam (Phase 1-friendly)
- A user-space crypto provider component that:
  - holds key material internally,
  - exports key handles (capabilities) to clients,
  - implements a small closed op set (sign/decrypt/derive/attest),
  - emits CH-CRYPTOAUDIT entries into CH-LOG (digests only).
- Optional: “confirmation required” and rate/budget checks are user-space policy (can integrate with D-BUDGET / D-LEASE).

### Interactions
- **D-AUTHAGENT (RFC-0007):** D-CRYPTOSVC is the “make it crisp and pin it as data” extension to the auth-agent seam.
- **D-LEASE (RFC-0066):** hand out time-/use-limited signing/decrypt authority via leased proxies to a key handle.
- **D-PERSIST (RFC-0065):** store CH-KEYREF in CapStore roots; avoid storing raw secrets. Pair with rollback policy (AC-054).
- **D-NONDET (RFC-0063):** any “freshness” (nonces, challenges) must come from explicit Clock/Entropy handles.
- **D-EXPLAIN / CH-LOG:** crypto usage becomes auditable (“what signed what, under what policy”) without leaking payloads.

## Invariants
- **I-CRYPTO-1 (Op-only key interface, optional):** if D-CRYPTOSVC is enabled, crypto providers expose only declared operations; no interface path returns raw private key bytes (extends I-AUTHAGENT-1).
- **I-CRYPTO-2 (Policy-bound operations, optional):** every crypto operation is checked against the key’s CH-KEYPOL (purpose/context + op kind); violations fail closed and are audit-visible.
- **I-CRYPTO-3 (Explicit-route provider reachability, optional):** provider access is explicit-route only: no ambient path/env/socket discovery, no provider-global list/search inventory API, and no sealed-compat inheritance of host auth-agent channels.

## Proof obligations (early evidence targets)
- **PO-CRYPTOAUDIT-REDACT:** transcript entries never include raw private key material and do not log plaintext inputs unless explicitly declared safe; digests + metadata only.
- **PO-CRYPTOPOL-ENF:** implementation enforces CH-KEYPOL constraints for each operation (negative tests for forbidden contexts/op kinds).
- **PO-CRYPTOSVC-ENF:** Phase 1 keeps the provider seam op-only and explicit-route only; no ambient `SSH_AUTH_SOCK` / path / env discovery, no provider-global key inventory/search API, and no PKCS#11-style slot/session/object semantics on the core seam.

## Abuse case linkage
- Tightens **AC-015** by making “non-export + policy-bound + explicit-route only” checkable against pinned schemas.

## Notes / prior art pointers
- Plan 9: factotum + Plan 9 auth architecture (REF-PLAN9-AUTH, REF-PLAN9-FACTOTUM).
- OpenSSH: agent restriction philosophy (“minimise attack surface; private keys considered part of TCB”) (REF-OPENSSH-AGENTRESTRICT).
- Hardware-backed key profiles: TPM 2.0 handles + auditing as an optional annex (REF-TPM2-PART1).
