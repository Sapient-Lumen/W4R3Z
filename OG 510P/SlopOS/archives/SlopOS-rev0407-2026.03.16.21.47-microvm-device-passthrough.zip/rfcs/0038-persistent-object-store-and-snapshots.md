# RFC-0038: Persistent object store + snapshot semantics (D-PERSIST)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-PERSIST, D-ATTRFS (adjunct), D-ATOMICUPD (adjunct), D-FPM (adjunct)

## Summary
Add an optional **persistent store service** that provides snapshot/clone semantics and (optionally) a *single-level-store* programming model, inspired by KeyKOS/EROS, while keeping the privileged core agnostic.

## Motivation
A greenfield system can choose “persistence as a first-class primitive” rather than bolting it on via ad-hoc backups and fragile upgrade scripts. Benefits:
- cheap, explicit snapshots for recovery and debugging,
- “boot environments” and rollback that naturally pair with atomic base updates,
- durable object identity for capability-bearing references (where appropriate).

The danger is making persistence implicit and unbounded. We want:
- explicit capability-mediated access,
- explicit snapshot lineage,
- bounded metadata/indexing (ties to D-ATTRFS),
- a design that can be implemented in user space and swapped out.

## Integration seam / kernel impact (keep small)
- Kernel exports block/device capabilities and DMA primitives (already needed for I/O).
- Persistence, snapshots, indexing, and integrity checks live in a **user-space store/filesystem domain**.
- Applications see persistence through view mounts/translators (D-NS, D-TRANS), not by privileged magic.

## Design space

### Option A: Snapshotting filesystem service (pragmatic)
- A user-space filesystem server implements copy-on-write snapshots and clones.
- Consider a Fossil-style convention: expose snapshots as a browseable tree (e.g., `/snapshot/<label>/...`) so rollback/forensics are “just namespace navigation”.
- “Boot environments” become a composition pattern: base image (immutable) + mutable overlays for config and state.
- Works well with D-ATOMICUPD and D-FPM’s content-addressed store.

### Option B: Single-level store (KeyKOS/EROS-flavored; ambitious)
- A user-space store provides persistent object IDs and transactions.
- Applications can treat some references as durable (subject to explicit policy and revocation discipline).
- Stronger integration with capability URIs/sturdyrefs is possible, but must preserve non-amplification and revocation invariants.

v0 proposal: adopt **Option A** as the initial target, while designing seams that keep Option B possible.

## Minimal interface (conceptual)
- `Store` capability:
  - `snapshot(dataset, label) -> snapshot_id`
  - `clone(snapshot_id, new_name) -> dataset`
  - `send(snapshot_id, cursor) -> chunk` / `receive(chunk)` (optional replication)
- `Dataset` capability:
  - read/write ops scoped by view; mounts are explicit (D-NS).
- `Index` capability (optional D-ATTRFS):
  - declare CH-ATTR schemas,
  - query by attribute under view-scoped access checks.

## Security/assurance posture
- Snapshot operations are effects; they must be transcript-logged (CH-LOG) and authorized (powerbox if human-approved).
- No ambient access: datasets and indices are capabilities; path lookup occurs only within a view (I-VIEW-1).
- If “durable object IDs” are adopted later, treat them as a security-relevant design change (revocation/epoch discipline must be explicit).

## Evidence plan
- E1: prototype snapshot+clone semantics in a user-space FS server; demonstrate rollback after a simulated crash.
- E2: integrate with D-ATOMICUPD: base image update flips a pointer while preserving a pinned user dataset snapshot.
- E3: negative tests for metadata/indexing: ensure attribute queries respect view authority and cannot exfiltrate hidden names.

## Open questions
- Should snapshots be per-dataset only, or support “coordinated multi-dataset snapshots” as a first-class concept?
- How do we bound index growth and avoid turning indexing into a covert channel?
- What is the minimal integrity story (checksums, scrub) we want in v1 without overpromising?

Refs: REF-KEYKOS-NANOKERNEL, REF-EROS-FASTCAP, REF-EROS-SLS-EVOLUTION, REF-ZFS-PAPER, REF-RPM-OSTREE., REF-PLAN9-FOSSIL, REF-VENTI-FAST02
