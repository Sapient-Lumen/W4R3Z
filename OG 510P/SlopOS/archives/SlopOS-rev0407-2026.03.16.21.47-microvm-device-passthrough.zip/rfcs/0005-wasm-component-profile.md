# RFC-0005: Wasm component profile (D-WASM)

Status: Draft  
Owner: archive  
Last updated: 2026-02-24

Goal: adopt a *verification-friendly* sandbox substrate for plugins/components that aligns with capability-mediated authority **without** expanding the privileged kernel/hypervisor.

## Why consider this?
High-assurance cores routinely lose on ecosystem extensibility: users want to ship bespoke logic (plugins, automations, adapters) but we cannot grow the privileged core into a dynamic extension VM.

Wasm is attractive because:
- it has widely used, relatively small, formally studied semantics (REF-WASM-CPP18, REF-WASM-AFP, REF-WATT-THESIS)
- its non-browser systems interface effort (WASI) is explicitly capability-oriented (REF-WASI-DESIGN)
- the newer component model + interface-types story gives a structured boundary for language interop and resource handles (see REF-WASI-0-2-LAUNCH)

## Candidate decision: D-WASM (where Wasm sits)
Options:
1) **User-space plugin runtime (default)**: Wasm runs inside an ordinary domain/process; the kernel treats the runtime as untrusted code with whatever caps it is given.
2) **Dedicated “component host” service**: a user-space service hosts plugins and enforces init→seal and view constraints; kernel remains unchanged.
3) **Kernel-integrated Wasm**: reject by default (TCB explosion) unless a *verified* runtime slice becomes compelling evidence.

Default posture: (1) first. (2) only if evidence shows it shrinks overall system risk. (3) is a Phase 3+ research track.

## Profile principle: imports are capabilities
Treat host imports as explicit authority:
- a Wasm component receives **handles** only via explicit passing at instantiation
- each handle corresponds to an object/capability in the host domain (or a view object that can resolve within its own namespace)
- no “ambient” filesystem/network/time by default; there are no implicit preopens
- after initialization, the host *may* seal: drop rights/handles/promises and lock views (D-SEAL)

Invariant hook:
- I-WASM-1: imports are capability-mediated; no ambient authority.

## “WASI-aligned, not WASI-complete”
We explicitly do **not** commit to cloning POSIX or implementing the entirety of WASI.

Instead we define a **tight compatibility posture**:
- Align with WASI’s capability style (handle passing; no global namespaces).
- Where we do provide WASI-ish facilities, provide them *as derived views* over our own view/cap objects.
- Keep the privileged core agnostic: all Wasm hosting is user space.

### Recommended minimum host surface (Phase 0/1)
Start with a deliberately small “mini-WASI”:
- `log` (append-only, bounded)
- `kv` (a capability-gated key/value store or state cell)
- `clock` (optional, explicit clock handle; no implicit time; see RFC-0063 / D-NONDET)
- `rng` (optional, explicit entropy handle; see RFC-0063 / D-NONDET)

Each import should map to a capability kind with bounded rights and deterministic error behavior.

### Explicit *resource* handles
Avoid ambient “ints-as-fds”. Prefer a *typed resource handle* boundary:
- host creates a handle object (internally: a cap/proxy)
- guest gets an opaque handle token
- operations are mediated by the host’s capability checks and view constraints

This mirrors the direction of the component model’s `resource` types and is compatible with our own D-CAPRPC and D-CONTRACT stance.

## Binding & drift control (meta-engineering)
Wasm runtimes, interface definitions, and host shims drift quickly; “it worked yesterday” is a supply-chain problem.

We therefore treat the Wasm boundary as a **pinned artifact set**:
- The host records:
  - a digest of the component bytes
  - a digest of the interface definition(s) used for import/export binding (e.g., WIT text canonicalized by tooling)
  - a digest of the host runtime + shim bundle (or a toolchain revision)
- These digests are suitable for inclusion in CH-LOG as observational metadata or as CH-AREF pointers when the artifacts are large.

This is *not* a kernel requirement; it is an operational discipline that supports reproducibility (D-FPM/D-ATOMICUPD) and debugging (D-RR).

## Interop with other decisions
- **D-IDL**: WIT can serve as an unprivileged IDL for plugin/component interfaces; it does not replace CH-* schemas for privileged surfaces.
- **D-CONTRACT**: for message-based plugin protocols, we can derive a CH-CONTRACT FSM from the IDL boundary (or pin a separate contract artifact) to enable runtime monitors and bounded model checks.
- **D-NS / views**: “filesystem access” is modeled as a *view capability* handed to the runtime; any path resolution happens inside that view.
- **D-SEAL**: the host may enforce an init→seal step: once the plugin is “ready,” it cannot request new handles except via explicitly authorized reconfiguration.

## Threats & non-goals
- We do not claim Wasm prevents side channels or DoS by itself.
- We do not claim termination or resource bounding unless D-METER/D-TCAP mechanisms are explicitly used (and evidenced).
- We treat the Wasm runtime as untrusted code *unless* a later profile produces mechanized evidence.

## Evidence plan
Phase 0/1:
- Implement a tiny host boundary (log + kv) inside an ordinary service.
- Negative tests: “ambient access” probes must fail (no implicit fs/network/time).
- Property tests: no API path yields new authority without explicit handle passing (align I-CAP-1/I-VIEW-2).
- Fuzz: component boundary decoding and handle use patterns.

Phase 2:
- If we need stronger assurances: mechanize the host boundary in the same framework as the chosen Wasm semantics (start small).

## Why this may be a unique target
If we can make Wasm plugins a first-class extension story **with explicit capability semantics and evidence hooks**, we can ship a high-assurance core while still enabling bespoke user logic—without importing driver-like TCB bloat.
