# RFC-0072: IDL digests + method ordinals for CapRPC (D-IDL / D-APIEVO refinement)

Status: Draft

Decision node(s): D-IDL (optional), D-APIEVO (optional), D-CAPRPC (optional)

## Motivation
We want CapRPC calls to be:
- **unambiguous** (dispatch cannot guess the interface),
- **upgrade-safe** (new methods don’t break old servers; unknown interactions are deterministic),
- **toolable** (diffs/gates catch accidental renumbering and collisions),
- **small-TCB** (everything here is tooling/user-space; the privileged core only sees CH-CAPRPC frames).

The gap today:
- CH-CAPRPC defines `method_id: u32` but does not standardize *how it is assigned*.
- CH-IFACE carries an optional `idl_digest`, but we do not define what bytes are hashed.

These are classic “ecosystem footguns” that show up *after* an interface gains users.

## Proposal

### 1) Canonical `idl_digest` policy
Clarify D-IDL: `idl_digest` is the digest of a **canonical representation** (compiler IR / descriptor), not raw source text.

Rationale: formatting-only changes should not invalidate pins; drift guards should be robust.

Engineering policy is captured in:
- `docs/60-engineering/idl-digest-and-ordinal-policy.md`

### 2) Introduce CH-ORD v0 (optional)
Add a small artifact to pin the mapping between **method name ↔ method_id**:
- `docs/30-architecture/interface-ordinal-manifest-schema-v0.md` (CH-ORD v0)

This supports:
- codegen drift guards,
- upgrade gates that forbid reusing ordinals,
- audit/debug tooling that can render method names from a bounded, pinned mapping.

### 3) Ordinal assignment policies
We standardize two recommended policies:

**A) Open interfaces: hash-derived ordinals**
- Intended for CH-IFACE.openness=`open`.
- Additive method evolution can happen without renumbering.
- Unknown methods are meaningful: the server can support the *interface family* but not implement every method yet.

Prior art: Fuchsia/FIDL computes method ordinals by hashing fully-qualified method names, and has explicit guidance on ordinals. (REF-FUCHSIA-FIDL-LANG; REF-FUCHSIA-RFC-0020; REF-FUCHSIA-FIDL-BINDINGS)

**B) Closed interfaces: explicit numeric ordinals**
- Intended for privileged/high-assurance surfaces.
- Semantic changes generally mint a new interface identity + adapter.

### 4) Make `UNKNOWN_METHOD` meaningful for open interfaces
For open interfaces, we recommend that CH-IFACE **omit** `idl_digest` so the interface digest can remain stable across additive method additions.

The evolving IDL is still pinned for builds via `idl_digest` in CH-ORD (and any generator manifests), but wire identity stays stable.

## Invariants / proof obligations
- Add **I-IDL-2**: `idl_digest` is computed over a canonical representation for its declared IDL family.
- Add **I-IDL-3**: if CH-ORD is used, method ordinals are stable and never reused for different semantics.
- Add **PO-IDL-CANON**: the chosen canonicalization is explicit and deterministic.
- Add **PO-ORD-VALIDATE**: CH-ORD decoding/validation is canonical and total; uniqueness/bounds hold.
- Add **PO-ORD-NOREUSE**: upgrade tooling rejects ordinal reuse/collision for pinned open interfaces.

## Threats / abuse case
- Ordinal collision or reuse can cause **misdispatch**, enabling confused-deputy behavior if a caller believes it invoked method A but the callee dispatches method B.

Add: AC-060 (ordinal collision/reuse misdispatch).

## Evidence plan
- E0: schema + policy docs + tooling plan (CH-ORD).
- E1: generator emits CH-ORD and a round-trip test manifest; CI gate fails on drift.
- E2: negative-test harness: reorder methods, attempt reuse, attempt collision → must fail closed.

## References
Refs: REF-FUCHSIA-FIDL-LANG, REF-FUCHSIA-RFC-0020, REF-FUCHSIA-FIDL-BINDINGS, REF-PROTOBUF-TECHNIQUES, REF-CAPNP-IDS.
