# RFC-0020: Type-capabilities for kernel-internal authority (Rust posture)

Status: Draft

Goal: shrink `unsafe` surface and reduce accidental privilege inside the privileged core by using **compile-time authority tokens** (“type-capabilities”) to gate sensitive internal APIs.

This is *not* a substitute for the external capability model (I-CAP-1). It is a technique to keep privileged code honest and mechanically reviewable.

Refs: REF-TOCK-OS, REF-SLK.

## Problem
Even if the KABI is minimal, privileged Rust code can still accidentally create bad states:
- calling a HAL routine outside required preconditions
- accessing page tables/interrupt controller without the right sequencing
- violating “only this subsystem may touch this register” policies

We already require U-IDs for `unsafe` (I-UNSAFE-1). Type-capabilities make those obligations easier to enforce by making “who may call what” explicit in the type system.

## Pattern (minimal)
A type-capability is an unforgeable Rust value whose constructor is private to a module/crate.
- Only designated initialization code can mint it.
- Functions that require special privilege take `&TypeCap` (or consume it) as an argument.
- The token is `!Send/!Sync` unless explicitly justified.

Example uses (sketch):
- `PageTableEditCap` required to call page-table mutation routines
- `IrqRouteCap` required to program interrupt routing
- `DmaMapCap` required to create DMA windows

The external capability model still controls *which domain* may request such actions; type-caps are an internal guardrail for correctness and auditability.

## Why this is worth baking in now
Tock’s experience suggests Rust can safely host significant kernel functionality, but that correctness still benefits from explicit capability discipline for sensitive interfaces.
SLK’s “type-capability model” frames how safe-language boundaries can approximate capability discipline internally.

Refs: REF-TOCK-OS, REF-SLK.

## Invariants / obligations (additions)
- **I-TYPECAP-1 (Internal authority is explicit, optional)**: sensitive privileged-internal operations are gated by module-private type-capabilities; no public function provides equivalent power without an explicit token.

Proof obligations (engineering-level):
- **PO-TYPECAP-NOFORGE**: constructors for type-capabilities are private; no stable API allows forging or widening internal authority.
- **PO-TYPECAP-AUDIT**: each type-capability maps to a bounded set of call sites and is listed in a short registry (reviewable surface).

These are “mechanical justification” obligations: enforceable by lint/CI + code review gates.

## Evidence plan (tight)
Phase 0/1:
- add a small CI lint: forbid calling selected `unsafe` functions unless a corresponding token is in scope
- produce a callgraph report for token-gated APIs and treat drift as evidence-relevant

## Archive impact
- Adds RFC-0020 (this file).
- Extends `unsafe-concurrency-policy.md` with a short section.
- Adds a small optional invariant and two PO entries in registries.
