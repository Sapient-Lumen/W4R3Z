# RFC-0031: Powerbox/consent mediators and capability UX

Status: Draft

## Problem
Capability systems reduce ambient authority, but they often fail in practice due to *authority UX*:
- components need additional authority during operation;
- humans/operators need a reviewable place to decide grants;
- automation (including LLM-assisted control planes) needs a safe way to request additional rights without “text becoming authority”.

A common failure mode is the confused deputy: untrusted code gets leverage by providing a *description* (e.g., a path string) that a privileged component resolves using its own ambient authority.

## Goal
Bake in an ecosystem convention that makes authority transfer:
- explicit;
- reviewable;
- mechanically bound to the exact privileged effect.

## Proposal
Adopt **D-POWERBOX**: a *user-space* consent mediator (“powerbox”) that concentrates cross-boundary authority decisions in one place.

In our archive, this is modeled as **IF-CONSENT** (optional) that issues approvals as **CH-AUTHZ v0** tokens:
- IF-CONSENT does *not* directly mutate privileged state.
- It issues CH-AUTHZ approvals bound to an action digest + schema version.
- IF-ACP (validator) remains the enforcement seam; it accepts actions only when presented with a matching CH-AUTHZ (I-AUTHZ-1).

Key design discipline (v0):
- **Canonical summary**: the consent UI/workflow must display a summary derived from canonical bytes/digest of the action, not from untrusted text (I-CONSENT-1).
- **No “freeform” grants**: approvals are per-action (or per small, explicit template) to avoid laundering.
- **Chooser-owned designation**: callers describe a bounded authority shape, but the mediator/provider owns the candidate set and returns concrete capability outcomes rather than ambient names or inventory.

Pinned v0 posture: `docs/30-architecture/powerbox-posture-v0.md` freezes D-POWERBOX as a **designation-scoped, chooser-owned** seam with **no generic remembered-grant library**, **no app-visible approval/candidate inventory**, and **no ambient-name result surface** in Phase 1.

## Why now
This is “low-hanging fruit” from object-capability ecosystems: the powerbox pattern has been used to manage authority transfers across trust boundaries, supporting dynamic negotiation and revocation, while keeping the authority-management code concentrated and reviewable (REF-ERIGHTS-POWERBOX, REF-DARPABROWSER-REPORT).

It also fits our LLM control-plane framing: treat LLM output as an untrusted principal; require explicit approvals/caps for privileged effects; log everything.

## Security hooks
- **I-CONSENT-1** + **I-AUTHZ-1**: approvals must bind to action digests; untrusted text cannot mint approvals.
- **PO-CONSENT-VALIDATE**: consent service and validators enforce closed issuer kinds and fail closed.
- **AC-036**: guard against misleading consent prompts and approval reuse/substitution.

## Evidence plan (tight)
- E1: golden tests that (a) changing any action field changes the digest and breaks the approval; (b) approvals expire deterministically when enabled.
- E1: UI/workflow harness that checks the displayed summary is computed from canonical bytes (not raw model text) for a sample of action kinds.

## Scope notes
- D-POWERBOX is an *ecosystem* feature, not a kernel primitive.
- Phase 1 does **not** claim a generic “always allow” permission-store layer; any durable continuity must stay on an explicit family-specific seam.
- We do not claim it eliminates social-engineering risk; it exists to keep grants explicit and auditable.

## References
REF-ERIGHTS-POWERBOX, REF-ERIGHTS-OCAP-OVERVIEW, REF-DARPABROWSER-REPORT.
