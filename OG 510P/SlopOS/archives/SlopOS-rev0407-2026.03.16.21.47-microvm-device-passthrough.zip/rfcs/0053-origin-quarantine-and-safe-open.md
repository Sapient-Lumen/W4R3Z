# RFC-0053: Origin metadata + quarantine + safe-open defaults (D-QUAR)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-QUAR, D-EPHEM, D-PLUMB, D-POWERBOX

## Summary
Add a first-class concept of **origin** and **quarantine** to reduce real-world “download → execute/open → persist” failures.

Core idea:
- objects created from risky sources carry **origin + quarantine attributes**,
- quarantine is **monotonic** until an explicit, logged clear,
- opening quarantined **document-like** objects routes through a **safe-open** path, while quarantined exact executable/script objects remain deny-by-default until explicit object-local clear/override in Phase 1:
  - disposable domain by default (D-EPHEM),
  - explicit export only (D-PLUMB),
  - optional sanitize-export pipeline (future RFC).

Refs: REF-MOTW-ZONEID, REF-MACOS-GATEKEEPER, REF-GATEKEEPER-BYPASS, REF-MS-PREVIEW-MOTW.

Companion import boundary: if CH-SREF / CH-CAPX restore/import materializes document-like bytes for routine document workflows, the result is still a **fresh local object** that remains quarantined by default; equal bytes do not collapse onto an existing object/docref, and any recorded handoff breadcrumb is only digest-only **`origin.import_ref_digest`** evidence rather than raw bearer metadata or hidden restore/re-fetch authority (`docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`, `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`).

## Problem
Most compromises start with a user interaction with an object of unclear provenance:
- a downloaded document,
- an email attachment,
- a file extracted from an archive,
- a “helpful” script pasted from the internet.

Existing OSes have partial defenses (Mark-of-the-Web, Gatekeeper quarantine), but bypasses are common when:
- metadata is not propagated through containers/extraction,
- clearing happens implicitly or invisibly,
- applications ignore the tag and open/execute anyway.

We already have strong building blocks (disposables + portals/powerbox). We need an ecosystem default that connects them.

## Goals
- Preserve and propagate “this came from outside” signals.
- Make safe behavior the default without banning user choice.
- Provide a **small, testable contract**: quarantine is monotonic; clearing is explicit and logged.
- Ensure “safe-open” composes with disposables and portals.

## Non-goals
- Perfect malware detection.
- A universal file reputation service.
- Solving all covert channels; we focus on the dominant user-facing path.

## Proposed design

### A) Attribute set (D-ATTRFS friendly)
When D-ATTRFS is enabled, the following attribute keys are declared (CH-ATTR v0):
- `origin.source` (enum): {network, email, removable, ipc, unknown}
- `origin.locator_hint` (string, optional): human-facing hint (not authoritative)
- `origin.time` (u64): unix seconds
- `origin.parent_digest` (digest, optional): exact immediate parent object digest for derived objects; required for ordinary safe-open kept/exported output when the parent digest is known
- `origin.chain_digest` (digest, optional): digest of a provenance chain object if CH-PROV is enabled

- `quarantine.state` (enum): {none, quarantined, cleared}
- `quarantine.reason` (enum): {download, attachment, extracted, unknown}
- `quarantine.cleared_by` (string, optional): stable identifier for the clearing workflow / policy

See: docs/30-architecture/origin-quarantine-attrset.md

### B) Monotonic propagation rules
- Any object created from a quarantined object is quarantined unless:
  - it is an explicit, policy-allowed “safe export” action that produces a new artifact with a logged justification, or
  - a user explicitly clears quarantine via the consent mediator (see below).
- Archive extraction propagates quarantine to extracted entries.
- Copies across domains preserve quarantine unless explicitly cleared.

### C) Safe-open default routes
If `quarantine.state == quarantined` and the workflow is a **document-like open/import** operation, the default safe-open path is:
1) Open in disposable domain (D-EPHEM) with a restricted view namespace, and
2) Require explicit export (D-PLUMB) to persist results in trusted locations.

This applies to:
- “open” of documents by risky parsers,
- importing document-like data into risky viewers/parsers.

For **exact executable/script launch**, Phase 1 now makes the opposite narrowing: quarantined executable/script objects do **not** auto-route into safe-open, and the ordinary execution path stays deny-by-default until an explicit object-local clear/override authorizes execution.

### D) Clearing quarantine is explicit + logged
Clearing requires:
- a user-visible action in IF-CONSENT/powerbox,
- transcript logging (CH-LOG) with the object digest and a “clear reason” token,
- optional policy constraints (e.g., only clear after signature verification).

Clearing is a capability-mediated effect; it is not an app-private bit.

## Pinned v0 posture follow-up (2026-03-06)

Phase 1 narrows D-QUAR further in `docs/30-architecture/quarantine-posture-v0.md`:
- clearing is **manual-only, object-local, and non-recursive**,
- safe-open / preview does **not** mutate the source object’s trust state,
- and any dequarantined/sanitized materialization is a **new artifact** with its own digest + transcript-visible reason rather than an in-place laundering step.

Companion v0 posture: `docs/30-architecture/open-untrusted-posture-v0.md` fixes the portable safe-open request as `intent.kind=open_untrusted` on one exact **CH-DOCREF object handle** (not a URI/URL and not a CH-SREF restore/import selector), with a policy-chosen disposable and with export/clear still requiring separate explicit workflows. Companion import→docref boundary: `docs/30-architecture/import-to-docref-boundary-v0.md` pins workflows that start from CH-SREF / CH-CAPX to first materialize a **fresh local object** that is still **quarantined by default** before any CH-DOCREF/safe-open use exists at all. Companion fresh-identity boundary: `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md` keeps that import step **object-local rather than content-addressed trust**, so equal imported bytes do not trigger `reuse_existing` / alias collapse onto a previously trusted local object/docref. Companion materialization boundary: `docs/30-architecture/open-untrusted-materialization-boundary-v0.md` pins the preview input as a request-local stable object rather than a live alias/write-through mount back to the mutable source. Companion active-content boundary: `docs/30-architecture/open-untrusted-active-content-boundary-v0.md` keeps admitted safe-open viewers **inert by default**, so embedded active content (macros, document-level scripts, external submit/fetch actions, helper-launch callbacks, or equivalent viewer hooks) does not execute or cause side effects merely because a quarantined document was admitted to `open_untrusted`; any such effect must cross a new explicit workflow on the existing portal seam. Companion residue boundary: `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md` keeps recent-doc / MRU / thumbnail / autosave / crash-recovery residue inside the disposable by default, so mere preview/open cannot quietly become a persistence lane or durable reopen hint. Companion export-classification boundary: `docs/30-architecture/open-untrusted-export-classification-v0.md` pins ordinary kept output as a **new artifact** that remains **quarantined by default**, unless a distinct sanitize/clear workflow says otherwise. Companion export-destination boundary: `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md` pins ordinary keep/export as **fresh-destination-first**, so risky-open output does not quietly regain overwrite-original / replace-existing semantics. Companion export-lineage boundary: `docs/30-architecture/open-untrusted-export-lineage-boundary-v0.md` pins ordinary kept output to one exact `origin.parent_digest`, so the fresh artifact keeps explicit parent evidence without inheriting source identity/docref continuity. Companion quarantined-execution boundary: `docs/30-architecture/quarantined-execution-boundary-v0.md` keeps quarantined exact executable/script objects off the portable safe-open seam entirely: normal execution stays deny-by-default until explicit object-local clear/override, and Phase 1 adds no portable `run_untrusted` lane. Companion quarantined code-input boundary: `docs/30-architecture/quarantined-code-input-boundary-v0.md` keeps that same gate intact when a bound object is supplying code to a cleared interpreter/runtime through `stdin`, `-c`, `--eval`, module/archive entry, or another declared code-bearing input form. Companion content-index boundary: `docs/30-architecture/quarantined-content-index-boundary-v0.md` keeps quarantined bytes out of ambient full-text indexes, OCR sidecars, embedding stores, assistant memory, and summary caches; authorized discovery remains metadata-safe only until an explicit derived-output workflow yields a new quarantined artifact. Companion derived-attribute boundary: `docs/30-architecture/quarantined-derived-attribute-boundary-v0.md` then keeps those explicit workflows from writing semantic tags/text/classifier outputs back onto the risky source object's metadata, so search/smart-folder predicates target the derived artifact rather than laundering the source. Companion derived-match boundary: `docs/30-architecture/quarantined-derived-match-boundary-v0.md` keeps query/search/smart-folder surfaces from then resurfacing the risky source object by hidden lineage joins, representative substitution, or dedup-style result collapse when the derived artifact matches. Companion result-preview boundary: `docs/30-architecture/quarantined-result-preview-boundary-v0.md` then keeps result rendering **metadata-safe only** even for that exact matching quarantined or derived artifact, so search/launcher UI does not auto-show snippets, thumbnails, preview panes, Quick Look cards, or hover previews from quarantined bytes unless a separate explicit review/open step is taken.

This keeps D-QUAR small enough to implement honestly: “trust this one object” is explicit, “trust this whole tree/archive forever” is not, and verification/notarization/scanning may inform the decision but do not silently auto-clear quarantine.

## Security considerations
- Avoid “implicit clearing” behaviors (opening in a viewer must not auto-clear).
- Container bypasses (disk images, nested archives) are the first attack to test.
- Treat `origin.locator_hint` as non-authoritative to prevent spoofing.

## Alternatives considered
- Rely on app-specific download tagging (too inconsistent).
- Block execution/open outright (bad UX; encourages disabling protections).
- Central reputation servers (privacy + complexity).

## Required invariants / proof obligations / evidence plan
Invariants:
- I-QUAR-1, I-QUAR-2, I-QUAR-3, I-QUAR-6, I-QUAR-4, I-QUAR-5.

Proof obligations:
- PO-QUAR-PROP (propagation),
- PO-QUAR-GATE (safe-open routing + inert-view boundary for embedded active content),
- PO-QUAR-EXEC (quarantined exact execution stays deny-by-default),
- PO-QUAR-CLEAR (explicit + logged clearing),
- PO-QUAR-LOCAL (object-local clear; new-artifact safe export).

Evidence targets:
- EVID-2026-043 (E1): extraction + copy propagation test suite
- EVID-2026-044 (E2): corpus of “laundering” attempts (nested archive, disk image, rename) + regression harness
