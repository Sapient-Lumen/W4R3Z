# RFC-0022: Address decoding nets + page-table generation (D-ADDRNET)

Status: Draft

Goal: make address translation and initial page-table construction **explicit, auditable, and (eventually) mechanizable**, instead of an ad-hoc pile of privileged `unsafe` platform code.

This is an optional seam, but it pays off early: bring-up bugs in address translation often become silent isolation breaks.

Refs: REF-PTGEN-SOSP21, REF-MMAPX-HOTOS21.

## Why this exists
Most OS/hypervisor stacks hand-write platform-specific MMU/IOMMU setup. On modern heterogeneous SoCs, the address-translation story spans:
- CPU page tables
- IOMMU(s)
- interconnect address decoders / bridges

The “decoding nets” line of work treats the platform’s translation structure as a **graph artifact** that can be validated and used to synthesize correct tables. That aligns with our behaviors:
- formalize invariants
- isolate `unsafe`
- prototype-to-evidence

## Design stance (minimal)
### 1) The translation structure is explicit data
Introduce **CH-ADDRNET v0**: a bounded, canonical representation of the platform’s address-translation graph.

Large formal models (full device trees, SoC DSLs) are out of scope for the archive. We only pin the *small, sufficient* model needed to generate/validate initial tables for the chosen platform profile.

### 2) Generation is a build artifact, validation is privileged
Allow a user-space toolchain to:
- read platform facts (CH-HWFACT) and/or a pinned platform description
- emit CH-ADDRNET and generated table artifacts (e.g., “PT blob digest”)

The privileged core:
- validates CH-ADDRNET (closed-world + bounds)
- checks that installed tables correspond to the validated net (at minimum: structural checks; later: mechanized equivalence)

### 3) Keep the kernel interface small
Do not add a “generic MMU programming API.” Prefer:
- a sealed boot-time installation step bound in CH-BOOT, and
- a narrow set of runtime mapping operations that preserve I-MAP-1/I-SHARE-1.

## Candidate invariants / obligations (optional)
- **I-ADDRNET-1 (Pinned translation structure, optional)**: any privileged authorization that depends on address translation uses only translation structures traceable to CH-ADDRNET and the installed tables; no “silent” translation side paths are relied upon.
- **I-PTGEN-1 (Generated tables implement the net, optional)**: the initial page/IOMMU tables installed at boot implement the reachability/permission relation described by CH-ADDRNET within the stated platform scope.

Associated proof obligations:
- **PO-ADDRNET-VALIDATE**: CH-ADDRNET validation is deterministic; rejects unknown node/edge kinds; enforces bounds and well-formedness.
- **PO-ADDRNET-COMPLETE**: for the declared platform scope, CH-ADDRNET is complete w.r.t. pinned CH-HWFACT facts (no “missing bridge edge” surprises without an explicit claim downgrade).
- **PO-PTGEN-CORRECT**: the generator + checker establish that the installed tables correspond to CH-ADDRNET (at least for a bounded subset initially).

## Abuse cases
See AC-027..AC-028.

## Evidence plan (tight)
Phase 1 (E1):
- implement a small CH-ADDRNET validator
- add a **completeness harness**: compare CH-ADDRNET against pinned CH-HWFACT facts for the chosen platform subset (bridges/endpoints present ⇒ modeled)
- generate + install tables for one platform profile (QEMU first), with negative tests:
  - mismatched tables
  - unexpected edges
  - omitted bridge edges/endpoints (AC-027)

Phase 2 (E2):
- bounded check: compare net-derived reachability against table-derived reachability for a constrained address subset

Phase 3 (E3):
- mechanize the “net → table” refinement for the pinned platform subset

## Archive impact
- Adds D-ADDRNET entry in the decision map.
- Adds CH-ADDRNET v0 schema + schema registry row.
- Adds PO/AC/EVID hooks for translation validation + table synthesis.
