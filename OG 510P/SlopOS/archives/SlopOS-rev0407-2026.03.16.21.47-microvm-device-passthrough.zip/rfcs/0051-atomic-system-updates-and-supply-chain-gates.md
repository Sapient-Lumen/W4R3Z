# RFC-0051: Atomic system updates + supply-chain gates (D-ATOMICUPD)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): D-ATOMICUPD, D-FPM, D-UPD-SIGN, D-PCP, D-BOOT

## Summary
Make “base OS” upgrades **atomic** and **revertible** by default, and bind each deployed system image to a verifiable release metadata object.

- The running base is an **immutable deployment** identified by a content digest.
- Upgrades stage a new deployment alongside the current one and activate it at reboot.
- Rollback selects a previous deployment deterministically.
- Update metadata and provenance are explicit, signed artifacts:
  - CH-UPD v0: update/release manifest (what is being installed)
  - CH-BOOT v0: what booted
  - CH-PROV v0: how it was built (optional)

This aligns well with D-FPM (functional build graphs / content-addressed store) but does not require it.

## Motivation
Traditional in-place mutation makes it hard to answer “what is my system?” and easy to brick a machine.
Atomic deployments make failures and audits tractable:

- **Operational**: upgrade/rollback is “switch pointer” not “edit live state”.
- **Security**: the deployment root is a digest; provenance can point to that digest.
- **Assurance**: claims about boot/update can be predicates over explicit bytes.

Systems like rpm-ostree demonstrate that atomic deployments with rollback can be practical at scale.

## Design

### Deployment model
A deployment is a **content-addressed tree** (or closure) rooted at `target_root_digest`.

- The updater fetches/constructs a deployment object, validates it, and stores it.
- The boot selector maintains a small “boot menu” of pinned deployment roots.
- Switching active deployment is an atomic pointer change.

The privileged core need only support:
- measuring/binding CH-BOOT to the booted artifacts (already)
- enforcing an optional rollback floor (I-BOOT-2) if enabled

### Update manifest: CH-UPD v0
CH-UPD is the update system’s “unit of intent”: *what we intend to install*.

Minimum fields:
- `target_root_digest` (deployment root)
- `cfg_digest` (CH-CFG bound to the deployment)
- `artifacts[]` digests/roles (subset mirrors CH-BOOT roles)
- optional `prov_attestation_digest` (signed container whose payload is CH-PROV)
- optional `rollback_floor` (anti-rollback metadata)

CH-UPD is signed per D-UPD-SIGN policy; it can be distributed via TUF-style repository metadata (D-TUF; RFC-0079), but we keep the kernel unaware of TUF.

Recommended: include the chosen CH-UPD digest in CH-BOOT `artifacts` under a role like `upd_manifest` so post-boot audit can link ‘what booted’ to ‘what was installed/approved’.

### Supply-chain gates (optional, D-PCP)
At install time, a verifier can require:
- CH-UPD is signed by an allowlisted key/threshold
- `target_root_digest` corresponds to the fetched deployment tree
- if `prov_attestation_digest` present: provenance is present and bound (PO-PROV-BIND)

A release can also publish transparency anchors (D-TLOG) for independent auditing.

### Rollback semantics
Rollback chooses a *previous* deployment root already present on disk.

- Rollback must be deterministic and auditable: selection logic is simple and recorded.
- Anti-rollback (optional): enforce a monotonic floor in CH-BOOT/CH-UPD.

### Boot selector state + health commit (recommended)
Pure “switch pointer” activation is necessary but not sufficient: we also want **automatic recovery** if a freshly activated deployment boots but fails to reach a healthy steady state (crash loops, early-service failure, etc.).

**Tighten the semantics by pinning health as an artifact**:
- define the profile’s health milestone as **CH-HEALTH v0** (signed, canonical),
- require commits to be bound to the **pending deployment** and the **CH-HEALTH digest** (RFC-0074),
- make the commit operation capability-gated (a `BootCommit`-like authority given only to the health assessor).

Adopt a small, A/B-style **boot selector state machine** that supports a 2‑phase activation:
1. **Stage**: updater writes the candidate deployment and installs `CH-UPD`.
2. **Activate (pending)**: boot selector chooses the pending deployment for the next boot with a bounded `tries_remaining`.
3. **Commit (healthy)**: once the system reaches a configured health milestone, user space marks the boot as successful; the selector then records the deployment as **last-known-good** (LKG) and clears the pending state.
4. **Rollback (auto)**: if `tries_remaining` reaches 0 without a success mark, the selector deterministically falls back to LKG.

Standardize the selector state as a pinned schema:
- **CH-BOOTSEL v0**: small selector state (active/LKG/pending/tries) validated by IF-BOOT (or bootloader layer) and recorded for audit (e.g., CH-BOOT `artifacts` role `boot_selector`).

Notes:
- This is directly inspired by Android’s A/B “tries_remaining / successful_boot” semantics and ChromeOS-style A/B rollback, but we keep the policy surface small and profile-driven.
- ZFS **boot environments** (Solaris/FreeBSD) are a production example of the same idea expressed as “bootable snapshot clones” with *one-shot activation* / auto-revert; treat them as a strong usability precedent for keeping this state machine tiny and deterministic.
- The “mark boot successful” operation must be transcript-visible (CH-LOG) and should be tied to a deterministic health predicate in the chosen profile (e.g., “init reached steady-state + critical services ready + storage mounted”).


### Interaction with user data / persistence
The base OS is immutable; user data and mutable state live in separate stores:
- user home / object store (D-PERSIST optional)
- app data under per-app namespaces/views

Data caveat: atomic deployments do **not** automatically make mutable state rollback-safe.
If D-ATOMICUPD profiles care about safe rollback for stateful services, pair this section with RFC-0097’s **data contracts + migration gates**: declare per-dataset reader/writer compatibility in CH-CFG and require snapshot barriers for breaking migrations.

This prevents a base update from rewriting user state by default.

## Invariants and obligations
Additions (for D-ATOMICUPD profiles):

- **I-ATOMICUPD-1 (Activation is atomic)**: activation either boots the new deployment as described by CH-UPD/CH-BOOT or stays on the prior deployment; no partial activation state is observable.
- **I-ATOMICUPD-2 (Rollback is non-amplifying)**: rollback cannot widen authority (e.g., by re-enabling previously revoked keys/policy) beyond what the selected deployment declares.
- **I-ATOMICUPD-3 (Commit requires health, optional)**: if CH-BOOTSEL is used, a newly activated deployment is not considered “current” until user space marks the boot successful; otherwise the selector deterministically falls back after bounded tries.

Proof obligations:
- **PO-UPD-VERIFY**: update verification is total/deterministic; mismatches fail closed (signature/digest/policy).
- **PO-ATOMICUPD-SWITCH**: deployment activation is an atomic pointer update with a deterministic “active set” invariant.
- **PO-ATOMICUPD-ROLLBACK**: rollback selection uses bounded deterministic rules and enforces optional rollback floors.
- **PO-BOOTSEL-VALIDATE**: boot selector state decoding/validation is total and fail-closed; unknown variants reject deterministically.
- **PO-ATOMICUPD-COMMIT**: the pending→committed transition is monotonic and requires an explicit success mark; decrement/rollback paths cannot be bypassed.

## Threat-model impact
New optional trusted components:
- update service + installer (user space)
- boot selector UI/logic (small; may be in firmware/bootloader layer)

Mitigations:
- keep the update verifier/installer small and policy-driven
- make all update decisions loggable: CH-LOG records CH-UPD digest, chosen target, and result

## Evidence plan
E1: implement a minimal updater that:
- fetches a CH-UPD + deployment root
- verifies digests
- stages and switches the active deployment
- supports rollback

E2: include negative tests for:
- signature mismatch
- digest mismatch
- rollback floor violations
- tampered/invalid CH-BOOTSEL (reject/fail closed)
- boot-success marking misuse (wrong deployment id / replay) must not commit

## References
Refs: REF-RPM-OSTREE, REF-FEDORA-ROLLBACKS, REF-TUF, REF-TUF-SPEC, REF-IN-TOTO, REF-SLSA, REF-SLSA-SPEC-V12, REF-TLOG-SWTCH, REF-ANDROID-AB, REF-CHROMEOS-UPDATEENGINE, REF-FUCHSIA-SWUPDATE, REF-SOLARIS-BOOTENV, REF-FREEBSD-BECTL.
