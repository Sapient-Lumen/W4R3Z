# RFC-0068: Wasm trace-processing pipelines (D-TRACEPROC)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-TRACEPROC, D-TRACE, D-WASM, D-BUDGET

## Summary
Add an *optional* “programmable observability” seam: run **untrusted Wasm components** as trace processors in user space to filter/aggregate **CH-TRACE v0** streams into **redaction-safe** outputs (metrics, digests, summaries), without introducing in-kernel scripting/verifiers.

## Motivation
D-TRACE (RFC-0015) gives us safe, typed tracepoints, but raw trace export can still be:
- too high-volume for always-on use,
- too leaky (side-channel/exfil risk), or
- too operator-hostile (hard to ask “one question” without dumping everything).

Linux eBPF and Solaris DTrace show why programmable hooks become an ecosystem “power tool”, but in-kernel programmability expands the privileged TCB (verifier/helpers/JIT) and complicates assurance.
A greenfield capability OS can bake in the **ecosystem ergonomics** (programmable queries) while keeping programmability outside the privileged core.

## Integration seam / kernel impact (keep small)
No new privileged interface is required:
- Tracepoints remain **predeclared** and exported via IF-OBS as CH-TRACE v0 (D-TRACE).
- A trace-processing service runs in user space and receives trace streams through a capability-granted observation export.
- Trace processors run as Wasm components (D-WASM) inside an existing sandbox boundary (IF-SBX), with explicit budgets (D-BUDGET / D-METER).

Kernel impact: none beyond what D-TRACE already implies.

## Design

### 1) Trace processor model
A **trace processor** is a Wasm component that:
- consumes CH-TRACE v0 records (bounded, typed),
- maintains bounded internal state,
- emits bounded, redaction-safe outputs (typically counters/summary records),
- cannot influence privileged state (observational only).

Processors are installed/removed/configured via **CH-TRACEPROC v1 (v0 compatible)** messages mediated by a trace portal/supervisor.

### 2) Budgets and backpressure
Each processor MUST run under explicit budgets:
- CPU time slice and/or instruction budget per window,
- memory cap,
- output rate cap.

On budget exhaustion or decode failure, behavior is deterministic:
- drop event(s) and emit a bounded “overflow” counter, or
- disable the processor and emit an operator-visible fault (profile-defined).

### 3) Output discipline (redaction-safe by default)
Outputs MUST be bounded and must not contain bearer tokens or secret bytes.
Default output forms:
- counters keyed by small_str tags,
- digests of bounded summaries,
- “top-N” with strict N and value-size limits.

If a processor needs to output potentially sensitive fields, that is an explicit profile decision and must pass through the same redaction/consent mediation used for other observations.

### 4) Determinism and replay posture
Trace processors SHOULD be deterministic given:
- the sequence of CH-TRACE inputs,
- their pinned Wasm artifact digest,
- their pinned CH-TRACEPROC configuration.

Note: traces are observations; they are not replay inputs by default (D-RR). However, determinism here improves debugging and comparability between runs.

## Registries impacted
Add:
- Decision node: **D-TRACEPROC**
- Schema: **CH-TRACEPROC v1 (v0 compatible)**
- Invariant: **I-TRACEPROC-1**
- Proof obligations: **PO-TRACEPROC-SBX**, **PO-TRACEPROC-BOUNDS**
- Abuse case: **AC-056** (trace processors as an exfil/covert-channel vector)

Update:
- Schema registry (CH-TRACEPROC)
- Decision map (D-TRACEPROC)
- Mechanisms (D-TRACEPROC threading)
- OS lessons (eBPF/DTrace → user-space Wasm trace processors)
- Roadmap (prototype + benchmarking)

## Threat-model impact
Primary risk: a trace processor becomes a covert channel/exfil path by encoding secrets into “allowed” outputs.
Mitigations:
- strict output bounds + allowlists,
- redaction policy at export boundaries (I-OBS-1),
- budgets (rate caps) + deterministic overflow behavior,
- prefer digest/counter outputs over raw strings/bytes.

## Assurance/verification impact
We avoid verifying an in-kernel VM/verifier. Instead we verify:
- trace emission is observational only (I-TRACE-1; PO-TRACE-NOSTATE),
- sandbox boundaries are sound for Wasm processors (IF-SBX),
- bounds and redaction policies are enforced at collection/export boundaries.

## Observability / operations impact
Trace processing enables:
- always-on counters and anomaly signals without raw trace dumping,
- safer “on-box” debugging workflows,
- smaller exports to IF-OBS with less side-channel surface.

## Alternatives
- **In-kernel eBPF-like VM**: rejected early due to TCB growth (verifier, helpers, JIT).
- **Pure static tracing only**: keeps TCB minimal but loses the ecosystem ergonomics for on-demand questions and aggregation.

## Evidence plan
- Prototype: a trace-processing service + 2–3 example processors (scheduler/IP C/VM-exit counters).
- Benchmark: overhead disabled vs enabled; compare raw export vs aggregated outputs.
- Abuse-case tests: attempt secret encoding through outputs; ensure policy/bounds block or visibly flag.

## Open questions
- Should the default processor ABI be WIT over CH-TRACE, or a lower-level ring-buffer ABI with typed decoding in the host?
- What minimal “metrics schema” do we standardize (or do we keep outputs as CH-LOG / IF-OBS digests for now)?
