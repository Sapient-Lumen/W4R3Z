# RFC-0019: Capability revocation via epochs/indirection (D-CAP adjunct)

Status: Draft

Goal: make revocation (if we choose to claim it) **explicit, bounded, and mechanizable**. Revocation is not free; this RFC is about a design that keeps the privileged core small and proof obligations honest.

Background lesson: classic capability systems have used (a) **indirection** and (b) **generation/epoch checks** to make revocation practical. EROS in particular explored epoch-style invalidation; modern capability systems still grapple with scalable revocation.

Refs: REF-EROS-FASTCAP, REF-CAPSYS-PRIMER, REF-SEMPEROS.

## Problem
Without revocation:
- confinement often devolves into “tear down the whole domain”
- long-lived services cannot easily retract delegated authority

With revocation:
- we risk large book-keeping structures (derivation trees)
- we risk resurrection bugs (use-after-free style authority reappearance)

We need a revocation story that:
- preserves I-CAP-1 (no implicit amplification)
- has a simple use-site check
- supports a clear “what is revoked” predicate

## Design options (bounded)
### Option A: Epoch/generation check (candidate)
Each revocable object has a `gen` counter.
A capability to that object carries `gen_at_issue`.
At use:
- allow operation iff `cap.gen_at_issue == obj.gen`
- revoke by incrementing `obj.gen` (invalidates all prior caps)

Pros:
- use-site check is constant-time
- revocation is O(1)

Cons:
- coarse: revokes *all* outstanding caps to that object
- must prevent resurrection via object reuse (see Option A.2)

### Option A.2: No-resurrection discipline
To avoid “old cap becomes valid again,” we require:
- object IDs are never reused within the epoch space, or
- object ID reuse is coupled with a fresh `gen` namespace (monotonic) that cannot wrap within system lifetime under stated assumptions

Maps to: I-STATE-1, I-REVOKE-1.

### Option B: Indirection object (membrane/forwarder)
Instead of revoking the target object, you revoke a **wrapper**:
- delegator grants a capability to a revoker/forwarder object
- all uses flow through it (like a membrane)
- revocation disables forwarding

This is already in-scope under D-MEMBRANE; the key constraint is preventing raw-cap leakage.

Maps to: I-MEMBRANE-1/I-MEMBRANE-2, PO-MEMBRANE-REVOKE.

### Option C: Derivation-tree revoke (avoid early)
Maintain derivation metadata and revoke subtrees.
This tends to grow book-keeping and proof surface quickly.

## Proposed stance (for early phases)
- Prefer **Option B** (membranes) for *selective* revocation across boundaries.
- If we need kernel-level revocation, adopt **Option A** (epoch) only for a small set of object types where “revoke all caps” is acceptable.

This keeps revocation semantics honest while avoiding a global derivation graph in the core.

## Invariants / obligations (additions)
- **I-REVOKE-2 (No resurrection, optional)**: once a capability is revoked, it cannot become valid again due to ID reuse or counter wrap within the stated hardware/time assumptions.

Proof obligations:
- **PO-REVOKE-EPOCH**: for epoch-revocable objects, every effectful use checks the generation and rejects mismatches deterministically.
- **PO-REVOKE-NORESURR**: object identity reuse and generation counters cannot cause revoked caps to become valid again under the stated lifetime/monotonicity assumptions.

Abuse case coverage:
- add AC-023 “epoch wrap / ID reuse resurrects authority.”

## Evidence plan (tight)
Phase 1:
- property tests over a small model: create/derive/copy/revoke/use → assert monotonic validity and no resurrection

Phase 2:
- bounded model check for a simplified capability table with generation checks

## Archive impact
- Adds RFC-0019 (this file).
- Extends invariant + proof obligation registries (I-REVOKE-2; PO-REVOKE-EPOCH / PO-REVOKE-NORESURR).
- Extends abuse cases (AC-023).
- Adds a short clarification to `capability-semantics.md`.
