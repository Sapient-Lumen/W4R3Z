# RFC-0056: Outbound network leases via a portal (D-NETLEASE)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-NETLEASE, D-PLUMB, D-EXPLAIN, D-ATTN, D-QUAR

## Summary
Make outbound networking an **explicit, lease-based capability** obtained through a **network portal** (a D-PLUMB family portal), so that:
- components default to **no ambient network**,
- network access is **scoped** (destination/protocol/TTL/budget),
- requests are **consent-able** (authority diffs + receipts) when policy requires, and
- the system can support a “Little Snitch”-style UX without making it the only path.

Concrete wire artifact: **CH-NETLEASE v0** (a redaction-safe record of the granted bounds).

Refs: REF-XDG-PORTAL, REF-XDG-PORTAL-NETWORKMONITOR, REF-LITTLESNITCH, REF-MACOS-NETWORKEXT, REF-ANDROID-LOCAL-NET, REF-CAPSICUM.

## Motivation
Most “least privilege” designs focus on filesystem and devices, but practical compromise/exfiltration often routes through:
- opportunistic outbound connections (C2, data exfil, credential replay),
- DNS as a covert or policy-bypass channel,
- “local network” lateral movement (printers, routers, NAS), and
- background services silently accumulating long-lived sockets.

Today’s mainstream OSes largely treat outbound network as ambient and retrofit controls at the firewall layer.
Greenfield gives us the chance to bake in a clean seam: **networking as a capability** with a **user-space mediation point** (portal) that composes with D-EXPLAIN receipts and D-ATTN notifications.

## Design

### 1) The network authority object
A component that wants network creates/uses sockets only via an explicit capability:
- `NetDialer` (connect-only)
- `NetListener` (listen/accept)
- `DnsResolver` (name lookup)

These are *user-space* objects backed by whatever network stack profile we choose (monolithic stack, user-space stack, microVM gateway, etc.).
The key property is: **no ambient constructor** exists after init in the D-NETLEASE profile.

### 2) Obtaining authority: `portal.net`
The default ergonomic path is a portal request:
1) component submits a request to the network portal (in the same spirit as file-open portals),
2) portal evaluates policy:
   - auto-allow for predeclared low-risk rules (e.g., “fetch updates from pinned endpoint”),
   - require consent for new/broad rules (D-EXPLAIN),
   - optionally raise attention prompts/notifications (D-ATTN) for interactive flows,
3) portal returns a `NetDialer`/`NetListener` handle with **lease bounds**.

The “portal return” is a capability grant and MUST be transcript-visible (CH-LOG) as part of the initiating workflow completion, aligned with I-PLUMB-2.

### 3) Lease bounds (what can a lease express?)
We keep the v0 shape small and practical:
- **scope**: `internet` | `local` | `loopback` | `explicit` (profile-defined)
- **protocol**: `tcp` | `udp` | `tls` | `quic` (closed enum; extensible by new schema versions)
- **destinations** (one of):
  - DNS name + port (optionally with suffix-match)
  - IP prefix + port range
  - service label (policy-resolved to stable endpoints)
- **lifetime**: TTL + optional renewal policy
- **budget** (optional): bytes/time/conn-count caps (useful for “fetch once” style leases)

Wire record: CH-NETLEASE v0. The returned capability is the actual authority; CH-NETLEASE is the audit/receipt-friendly description.

### 4) DNS binding and bypass resistance
Two recurring failure modes in “allow domain X” schemes:
- DNS rebinding / name→IP drift leading to policy escapes
- “resolver split” where the app uses a different resolver than the policy thinks

D-NETLEASE addresses this by making the resolver *part of the lease*:
- a domain-name lease returns a dialer that resolves via the portal’s resolver, and
- the dialer binds each connection attempt to the policy’s chosen name→addr resolution strategy.

Profiles may pick stricter options later (pin first-seen IPs for short TTLs, pin cert SPKI for `tls` leases, etc.).

### 5) Safe-open interaction (D-QUAR)
In D-QUAR profiles, disposable safe-open domains should start with **no net lease** by default.
Export workflows that would “send out” data (upload, email, share) should be explicit portal workflows that:
- show an authority diff (network destination + method),
- emit a receipt (CH-RECEIPT), and
- optionally require volition for interactive sends.

### 6) Relationship to CH-PLEDGE (`portal.net`)
`portal.net` in CH-PLEDGE becomes meaningful with D-NETLEASE:
- Without `portal.net`, a pledged domain cannot request new network leases.
- With `portal.net`, it may request leases, but policy still decides whether consent is required.

This lets “normal” services pledge away network post-init while still using portals in the small number of workflows that genuinely need it.

## Threat-model impact
Helps mitigate:
- silent data exfiltration by compromised components,
- lateral movement over local network,
- covert channels via ambient DNS lookups,
- long-lived background sockets surviving beyond “init finished” boundaries.

New/updated abuse cases:
- AC-047 (network lease bypass / over-broad grants) added.

## Assurance/verification impact
New invariants (optional):
- **I-NETLEASE-1 (No ambient outbound network, optional):** under D-NETLEASE, creating outbound connections requires an explicit network authority object (no ambient socket constructors after init).
- **I-NETLEASE-2 (Lease bounds enforced, optional):** connections/listeners created through a lease cannot exceed the CH-NETLEASE bounds (proto/dest/ttl/budget); violations fail closed.
- **I-NETLEASE-3 (Lease grants are transcripted, optional):** portal grants/denials that create network authority are transcript-logged and (when consented) bind to receipts/approvals.

New proof obligations:
- **PO-NETLEASE-VALIDATE:** CH-NETLEASE validation is total/canonical and enforces a closed set of protocol/scope kinds.
- **PO-NETLEASE-ENFORCE:** the dialer/listener implementation enforces bounds and has no bypass paths (no alternate resolver/transport path).
- **PO-NETLEASE-DNSBIND:** domain-name leases cannot be used with an out-of-band resolver; connection attempts are bound to the lease’s resolution strategy.

Evidence targets:
- golden tests for lease canonicalization + bounds checks;
- negative tests for DNS rebinding and local-network escapes;
- “disposable safe-open has no net” regression tests.

## Alternatives considered
- **Firewall-only (retrofit):** keeps apps unaware but pushes control into a huge, stateful policy engine; hard to make “why was this allowed?” auditable.
- **Only prompts (Little Snitch model):** user fatigue and click-through risks; D-NETLEASE supports prompts as *one* policy mode, not the only mode.
- **Per-app static manifests:** good for some components (updates, daemons) but brittle for interactive workflows; leases keep the runtime story explicit.

## Archive impact
- Adds D-NETLEASE decision node.
- Adds CH-NETLEASE v0 schema doc + schema registry row.
- Adds I-NETLEASE-1..3 and PO-NETLEASE-VALIDATE, PO-NETLEASE-ENFORCE, PO-NETLEASE-DNSBIND registry rows.
- Adds AC-047 and evidence placeholders EVID-2026-058, EVID-2026-059.
- Updates RFC-0016 and `os-lessons.md` to connect pledge/portals/notifications to network.
