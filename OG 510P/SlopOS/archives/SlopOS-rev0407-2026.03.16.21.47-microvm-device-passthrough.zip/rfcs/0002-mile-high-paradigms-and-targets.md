# RFC-0002: Mile-high paradigms + flagship targets (integration map)

## Summary
Capture a bounded set of “low-hanging fruit” paradigms and a few differentiating targets that fit the archive behaviors (constrain-claims, spec-first, proof-driven, minimize-TCB). This RFC does **not** decide; it maps ideas → decision nodes → scoped claims/invariants/POs so we do not lose them.

## Motivation
We want to:
- import the *useful* lessons from adjacent systems without ballooning scope,
- keep targets tied to explicit assumptions and verification costs,
- preserve good ideas as evidence-tracked branches (RFC→ADR), not scattered notes.

## Design (integration map)

### A. Low-hanging paradigms that fit our structure
1) **IFC-lite (labels on a scoped subset)**
- Precedent: HiStar + seL4 info-flow results (REF-HISTAR-SOSP06, REF-SEL4-INFOFLOW).
- Integration:
  - Decision: D-IFC
  - Claim (optional): C-IFC-1
  - Invariants: I-IFC-1/I-IFC-2
  - Proof obligation: PO-IFC-STEP
- Scope rule: do *not* label everything; start with one object/channel class or observation export surface.

2) **Determinism as a verification strategy (Phase-1 concurrency stance)**
- Integration:
  - Decision: D-SCHED (deterministic default)
  - Reinforces: D-CONC staging and D-MEMMODEL delay
- Scope rule: determinism is a method to reduce proof branching early; it is not a performance promise.

3) **Type-enforced privilege tokens inside the TCB**
- Precedent: Tock’s capability tokens in Rust (REF-TOCK-CAPS).
- Integration:
  - Impacts: C-UNSAFE-1 / I-UNSAFE-1 (token constructors become auditable U-IDs)
- Scope rule: tokens supplement capability checks; they do not replace the external capability model.

4) **Uniform “handles” + push naming/policy outwards**
- Precedent: Zircon handles (REF-ZIRCON-HANDLES).
- Integration:
  - Reinforces: C-CAP-1 / I-CAP-1
  - Strengthens: view objects (EVID-2026-007) to avoid ambient namespaces

5) **State-evolution as the primary design object**
- Precedent: Theseus (REF-THESEUS-OSDI20).
- Integration:
  - Reinforces: CH-KABI action sets + transcript logging as “interface-as-data”
  - Connects to: C-STATE-1 + I-STATE-1 + I-LOG-1

6) **MicroVM profile as a verification slice**
- Precedent: Firecracker (REF-FIRECRACKER-NSDI20) + microhypervisor lineage (REF-NOVA-EUROSYS10).
- Integration:
  - Decision: D-MICROVM
  - Reinforces: D-XS, C-HV-1, PO-XS-CLOSESET
- Scope rule: device model is part of the security boundary; keep it declared and closed.

7) **Static partitioning mode (separation-kernel-ish)**
- Precedent: Muen (REF-MUEN-SK).
- Integration:
  - Use as a profile extension to simplify early isolation proofs (C-ISO-1) and keep concurrency bounded.

### B. Targets few can hit (differentiators)
1) **Proof-carrying provenance end-to-end**
- Precedent: in-toto style attestations (REF-IN-TOTO) + reproducible builds (REF-REPRODUCIBLE-BUILDS).
- Integration:
  - Decision: D-PCP
  - Claim (aspirational): C-PROV-2
  - Invariant: I-PROV-CHAIN-1
  - Proof obligation: PO-PROV-BIND
  - Binding hook: CH-BOOT `prov_attestation_digest`
- Scope rule: keep verifier small; encode assumptions (A-TOOL-1, A-BOOT-1); avoid “prove the world.”

2) **Interface-as-data + replayable transcripts**
- Integration:
  - Already present: CH-KABI v0 + CH-LOG contract (EVID-2026-005, EVID-2026-006)
  - Target: make replay/diff testing against the abstract machine a first-class evidence generator.

3) **Parametric platform instantiation (ISA/virt as annexes)**
- Integration:
  - Reinforces: D-ISA, D-ARCH, A-HW-1
  - Target: keep the abstract machine stable while platform annexes supply assumptions.

4) **Optional confidential-computing profile (as assumptions, not magic)**
- Integration:
  - Decision: D-CC
  - Assumption: A-CC-1
  - Scope rule: keep side channels as explicit non-claims unless modeled (D-SIDECH).

## Assumptions impacted (A-IDs)
- Adds A-CC-1 for any D-CC profile.
- Strengthens the “explicit binding” story for A-BOOT-1/A-TOOL-1 if D-PCP pursued.

## Threat-model impact
- IFC-lite changes the *meaning* of observation surfaces (requires explicit observation model).
- D-PCP adds supply-chain attacker resistance goals but must not silently expand trusted components.
- D-MICROVM reduces device-model attack surface by design, but raises availability/performance trade-offs.

## Assurance/verification impact
- New optional claim surface: C-PROV-2, C-IFC-1.
- New POs: PO-PROV-BIND, PO-IFC-STEP.
- Explicitly encourages “slice proofs” (one mechanism end-to-end) rather than broad shallow claims.

## Alternatives
- “Do nothing”: keep ideas in chat; high risk of drift and lost mapping.
- “Make them all claims now”: violates constrain-claims and balloons obligations.
- “New subsystem docs per idea”: increases archive size; this RFC is the smallest stable capture.

## Evidence plan
- For each D-* in scope, the first evidence is a single E1/E2 slice that discharges one new PO:
  - IFC-lite: bounded model-check of a tiny labeled channel reducer (PO-IFC-STEP)
  - PCP: a verifier prototype that checks CH-BOOT binds to a signed attestation (PO-PROV-BIND)
  - MicroVM: exit taxonomy + closed-set enforcement with fuzz/model-check (PO-XS-CLOSESET)

## Open questions
- What is the minimal, non-bloated observation model for IFC-lite that is still meaningful?
- How small can the PCP verifier be while still binding proofs in a useful way?
- Which microVM device model is “minimal but usable” under our threat model?
