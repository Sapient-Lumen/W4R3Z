# RFC-0023: Local naming certificates (SPKI/SDSI-style) (D-NAMECERT)

Status: Draft

Goal: add a small, optional seam for **linked local namespaces** and **delegation** that plays nicely with capability mode and networked capability handoff, without importing a large PKI or global naming scheme.

Refs: REF-SDSI-RL96, REF-SPKI-RFC2692, REF-SPKI-RFC2693, REF-KEYNOTE-RFC2704, REF-RT0-DISCOVERY, REF-BISCUIT-SPEC, REF-UCAN-SPEC, REF-PRECIS-RFC8264, REF-UNICODE-UTS39, REF-COSEKEYTHUMBPRINT-RFC9679, REF-EDDSA-RFC8032, REF-COSE-RFC9052, REF-COSE-RFC9053, REF-CBOR-RFC8949.

## Why this exists
Capability systems often struggle with *usability*: “what is this opaque cap?” and “how do we refer to it safely across time and machines?”

SDSI’s key lesson is that names should be **local**, linkable, and compositional rather than globally hierarchical. SPKI’s focus on **authorization** (not identity) matches our posture: we care about *authority edges* and their attenuation.

We already have **view objects** (name→cap resolution) and **sturdyrefs** (offline capability-bearing references). D-NAMECERT complements those by letting a domain carry a small set of **signed bindings** that name keys and already-authorized local descriptors while keeping capability-bearing import/restore on sharper explicit seams.

## Design stance (minimal)

Pinned v0 posture: `docs/30-architecture/namecert-posture-v0.md` (issuer-local/user-space naming evidence only; no ambient fetch/global resolver; no auto-install into views; no portable policy VM on the core seam).

### 1) Certificates live in user space
The privileged core should not implement certificate parsing or chain discovery.

Instead:
- a user-space “naming service” ingests certificate bundles
- evaluates them under explicit local trust/visibility policy, including an explicit evaluator-local trust-anchor / issuer-allowlist input
- if an authority-bearing result is accepted in Phase 1, materializes it only through explicit **D-NS `view.attach` / `view.detach`** on a concrete `view.slot`, with source `digest(CH-NAMECERT v0)` evidence retained on the target seam (`docs/30-architecture/namecert-projection-boundary-v0.md`)
- binds decisions into CH-LOG / CH-ACPOUT / CH-SPROJ style receipts as appropriate rather than relying on hidden resolver cache state
- if bundles are replicated across clusters, that replication remains **signed bundle-set evidence only**; trust/visibility/activation still come from local explicit naming policy rather than global or ambient resolution (`docs/30-architecture/namecert-replication-boundary-v0.md`)

### 2) Keep the format tiny
Introduce **CH-NAMECERT v0** as a canonical envelope for a small bundle of:
- local name bindings (name → key/cap reference)
- delegation statements (issuer authorizes subject for a named role/capability set)

This is not X.509, not a general policy language, and not a portable revocation/discovery plane.
- `Binding.name` and `Delegation.role` use a tiny **exact-byte lowercase ASCII** profile in Phase 1 rather than a Unicode/PRECIS/confusable-management seam (`docs/30-architecture/namecert-string-profile-v0.md`).
- those admitted labels are also **single opaque atoms** after validation: `.` / `_` / `-` remain ordinary bytes, and D-NAMECERT imports no hierarchy, wildcard, prefix/suffix, or path grammar onto `Binding.name` / `Delegation.role` (`docs/30-architecture/namecert-label-atom-boundary-v0.md`).
- `issuer` / `subject` principal identity is hash-only and canonical in Phase 1: admitted bundles accept only `PrincipalRef.kind="key_hash"` with `alg="cose_key_thumbprint_sha256"` and exact 32-byte thumbprints, while raw `PrincipalRef.kind="pubkey"` admissions reject (`docs/30-architecture/namecert-principal-profile-v0.md`).
- signature semantics remain **inline, direct, and single-profile**: Phase 1 requires the inline `sig` field, accepts only `sig.alg="ed25519"`, verifies over the canonical unsigned bundle bytes, and treats CH-SIGENV / COSE_Sign1 / DSSE / keyless material as extra audit evidence rather than D-NAMECERT admission authority (`docs/30-architecture/namecert-signature-profile-v0.md`).
- `bundle_id` and `created_ms` remain **signed provenance metadata only**: Phase 1 declines latest-bundle-wins, implicit replacement-lineage, or metadata-driven freshness/obsolescence semantics on D-NAMECERT itself (`docs/30-architecture/namecert-metadata-boundary-v0.md`).
- admitted Phase 1 bundles are **non-bearer naming evidence only**: raw CH-SREF / CH-CAPX / raw capability material is forbidden, `TargetRef.kind="sturdyref"` is reserved+rejected, and capability-bearing import stays on explicit D-CAPX / CH-SREF restore routes (`docs/30-architecture/namecert-bearer-boundary-v0.md`).

### 3) Interop with D-CAPX
If D-CAPX is enabled, CH-NAMECERT can help:
- label/organize remote authorities (keys/proxies) in a local namespace
- document delegation edges as explicit evidence objects
- but in Phase 1 any such proxy/service labels remain **observational metadata only**; authority still comes from the explicit local proxy/service import seam rather than from CH-NAMECERT projection
- validity/freshness may gate future admissions under explicit local time policy, but Phase 1 does **not** auto-detach already-materialized `view.slot` bindings when time advances (`docs/30-architecture/namecert-time-boundary-v0.md`)
- later local negative evidence / issuer withdrawal is also admission-scoped only: Phase 1 defines no ambient CRL/OCSP or latest-wins semantics on D-NAMECERT, and learning revocation later does **not** auto-detach already-materialized `view.slot` bindings (`docs/30-architecture/namecert-revocation-boundary-v0.md`)
- when multiple admissible candidates survive evaluation, Phase 1 stays **set-valued**: D-NAMECERT adds no default ranking / winner-selection rule, and any authority-bearing `view.slot` materialization must identify the exact chosen candidate rather than a hidden resolver guess (`docs/30-architecture/namecert-selection-boundary-v0.md`)
- evaluation is **closed-world and bounded** over the explicit presented bundle set: local goal-directed search is allowed, but Phase 1 defines no suspend/resume distributed credential discovery, no issuer-directed retrieval, and no hidden background retry or ambient chase (`docs/30-architecture/namecert-search-boundary-v0.md`)
- admitted Phase 1 delegations imply **no onward delegation**: CH-NAMECERT v0 carries no `may_delegate` / propagation-bit / depth field, so a delegated subject may exercise a grant but may not use that grant as proof that it can issue further CH-NAMECERT delegations unless it is independently authorized under explicit local policy (`docs/30-architecture/namecert-redelegation-boundary-v0.md`)
- trust anchors remain **explicit evaluator-local input**: CH-NAMECERT is not itself a trust root or trust-policy container, bundles cannot self-anchor, and replicated arrivals do not auto-install new trusted issuers (`docs/30-architecture/namecert-trust-root-boundary-v0.md`)
- admitted `bindings` / `delegations` arrays use one **duplicate-free strict normal form**: elements are strictly sorted by canonical bytes, exact duplicates reject, and statement order/repetition never become first-match/last-match or weighted authority semantics (`docs/30-architecture/namecert-normal-form-boundary-v0.md`)
- authority-bearing labels remain **exact-byte lowercase ASCII only**: Phase 1 declines Unicode normalization, case-folding, PRECIS/Stringprep, and confusable-policy semantics on `Binding.name` / `Delegation.role` (`docs/30-architecture/namecert-string-profile-v0.md`)
- those admitted labels are also **single opaque atoms** after validation: Phase 1 does not split `ops.admin` into path segments, infer wildcard/prefix/suffix matches, or import SDSI compound-name syntax directly into the `Binding.name` / `Delegation.role` fields (`docs/30-architecture/namecert-label-atom-boundary-v0.md`)
- principal identity remains **hash-only and canonical**: Phase 1 accepts only `PrincipalRef.kind="key_hash"` with `alg="cose_key_thumbprint_sha256"` and exact 32-byte thumbprints, rejects raw `PrincipalRef.kind="pubkey"` admissions, and leaves verifier-key distribution on explicit local trust-anchor / key-registry policy (`docs/30-architecture/namecert-principal-profile-v0.md`)
- admitted bundles remain non-bearer naming evidence, so raw CH-SREF / CH-CAPX / raw capability material never rides inside CH-NAMECERT and capability-bearing import stays on explicit D-CAPX / CH-SREF seams (`docs/30-architecture/namecert-bearer-boundary-v0.md`)

### 4) Modern contrast without importing the whole stack
Modern delegated-auth ecosystems such as **UCAN** show that content-addressed delegation chains, attenuation, and offline verification can stay in user space. **Biscuit** shows how a richer Datalog-style attenuation language can live in bearer tokens. **KeyNote** goes further and unifies credentials plus local policy behind an explicit compliance checker. **RT0 credential graphs** are another useful contrast: they provide a real searchable representation plus sound/complete reachability for a richer trust-management language. Those are useful reference points, but v0 still makes a smaller choice: **D-NAMECERT is naming/delegation evidence only**, and the archive does **not** silently import UCAN/Biscuit/KeyNote/RT-style capability vocabularies, credential-graph search engines, portable compliance/policy languages, or trust-anchor distribution semantics into the privileged/core seam. If we later want that wider delegated-capability surface or portable trust-policy distribution, it should land as its own reviewed seam rather than by widening CH-NAMECERT in place.

## Candidate invariants / obligations (optional)
- **I-NAME-1 (Local naming is explicit, optional)**: any name→cap resolution that matters for authority is traceable to an explicit view and/or a pinned CH-NAMECERT bundle plus explicit evaluator-local trust-anchor policy; admitted bundles use duplicate-free strictly sorted `bindings` / `delegations` arrays, authority-bearing `Binding.name` / `Delegation.role` labels use an exact-byte lowercase ASCII profile and remain single opaque atoms after validation (no hierarchy/wildcard/path parsing), `issuer` / `subject` refs use one canonical hash-only `PrincipalRef` profile (`kind="key_hash"`, `alg="cose_key_thumbprint_sha256"`, exact 32-byte thumbprints), admitted bundles use one inline direct signature profile (`sig.alg="ed25519"` over canonical unsigned bundle bytes), `bundle_id` / `created_ms` remain signed provenance metadata only, admitted bundles do not carry raw CH-SREF / CH-CAPX / bearer capability material, and no ambient/global name service is consulted.
- **I-NAME-2 (Delegation is non-amplifying, optional)**: evaluating a certificate bundle cannot yield authority beyond what is explicitly delegated; “chain” resolution is monotonic under the declared delegation rules, remains closed-world over the presented explicit bundle set, uses only explicit evaluator-local trust-anchor policy, any evaluator-local revocation/replacement input fails closed rather than widening authority, cycles/revisits are handled deterministically under explicit bounds, Phase 1 grants no implied onward delegation absent a future explicit propagation seam, statement order and multiplicity are non-authoritative, label matching is exact-label and does not split labels on punctuation or apply wildcard/prefix/suffix heuristics, `bundle_id` / `created_ms` are not used as replacement/freshness/winner inputs, and when multiple admissible candidates exist the result stays set-valued rather than silently selecting a winner.
- **I-NAME-3 (Materialization is explicit and source-bound, optional)**: any authority-bearing Phase 1 projection from CH-NAMECERT into local namespace state lands only through explicit D-NS `view.attach` / `view.detach` on concrete `view.slot` keys, and target-seam proposal/receipts retain source `digest(CH-NAMECERT v0)` evidence for the exact chosen candidate; neither time advancing, later revocation evidence, later trust-anchor policy changes, nor metadata-only recency differences silently auto-detach already-materialized bindings, and D-NAMECERT standardizes no hidden winner-selection rule.

Associated proof obligations:
- **PO-NAMECERT-VALIDATE**: CH-NAMECERT decoding/validation is deterministic; rejects unknown variants; enforces bounds; rejects duplicate or non-strictly-sorted `bindings` / `delegations` arrays; `Binding.name` / `Delegation.role` satisfy the exact-byte lowercase ASCII profile, are treated as single opaque atoms after validation, and admit no Unicode normalization or case-folding aliases; admitted Phase 1 bundles accept only `PrincipalRef.kind="key_hash"` with `alg="cose_key_thumbprint_sha256"` and exact 32-byte thumbprints, reject raw `PrincipalRef.kind="pubkey"` admissions, require one inline direct signature profile (`sig.alg="ed25519"`) over canonical unsigned bundle bytes, treat `bundle_id` / `created_ms` as signed provenance metadata only, reject metadata-derived latest-wins or replacement semantics, reject wrapper-only/keyless/multisignature admission semantics, v0 `Delegation` carries no `may_delegate` / propagation / depth semantics beyond the issuer→subject grant itself, and reject `TargetRef.kind="sturdyref"` plus any raw CH-SREF / CH-CAPX / bearer capability material.
- **PO-NAMECERT-CHAIN**: chain evaluation (in user space) is sound w.r.t. the declared delegation semantics, stays closed-world over the presented explicit bundle set, uses only explicit evaluator-local trust-anchor policy, re-checks declared validity/freshness at admission time under explicit local time policy, treats any evaluator-local revocation/replacement input as explicit fail-closed admission data, handles revisits/cycles deterministically under explicit bounds, preserves exact `PrincipalRef` identity under the one canonical thumbprint profile, preserves issuer→verifier binding under the one inline direct Ed25519 signature profile, external wrappers / keyless material cannot substitute for the inline admission signature, reordering or repeating already-admitted statements cannot change the evaluation result, `bundle_id` / `created_ms` cannot silently rank, supersede, or obsolete candidates, label matching is exact-label and therefore performs no dot/slash splitting, wildcard, prefix, or suffix expansion, returns a bounded candidate set when multiple admissible results exist, treats each admitted delegation as terminal for propagation unless a future explicit redelegation seam is present, and cannot amplify authority.
- **PO-NAMECERT-PROJECT**: authority-bearing Phase 1 materialization from CH-NAMECERT into local namespace state is explicit, source-digest-bound, names the exact chosen candidate when multiple admissible results exist, and uses the existing D-NS `view.slot` conflict keys / `svc:view` ordering boundary rather than hidden resolver state or bulk install semantics; neither time advancing, later revocation evidence, later trust-anchor policy changes, nor metadata-only recency differences auto-detaches already-materialized bindings or justifies live authority from implied onward delegation, and never on subtree/prefix/wildcard inference.

## Abuse cases
See AC-029..AC-030.

## Evidence plan (tight)
Phase 1 (E1):
- implement a tiny CH-NAMECERT validator + reference evaluator for one constrained semantics
- negative tests: uppercase/non-ASCII/confusable/normalization rejects for the exact-byte ASCII label profile; delimiter / dotted-label / wildcard confusion reject corpus for the opaque-label-atom boundary; raw-`pubkey` `PrincipalRef` reject corpus plus mixed principal-id alias attacks; wrong-alg / wrapper-only / keyless / multisig reject corpus for the inline signature profile; `bundle_id` / `created_ms` latest-wins and implicit-replacement reject corpus; implied-redelegation reject corpus (`K1 -> K2 -> K3` fails unless `K2` is independently authorized under explicit local policy); name shadowing/alias attacks; chain substitution; ambiguous parsing

Phase 2 (E2):
- bounded model check on “name graph + delegation edges” (reachability/attenuation)

## Archive impact
- Adds D-NAMECERT entry in the decision map.
- Adds CH-NAMECERT v0 schema + schema registry row.
- Adds PO/AC/EVID hooks for certificate bundle validation + chain soundness.
- Adds a projection boundary doc that keeps any authority-bearing materialization on explicit D-NS `view.slot` actions with retained source digests rather than hidden resolver cache state.
- Adds a time boundary doc that keeps CH-NAMECERT validity/freshness as admission-only policy rather than a hidden lease/auto-detach daemon.
- Adds a revocation boundary doc that keeps later withdrawal/negative evidence evaluator-local and admission-scoped rather than a hidden CRL/OCSP/latest-wins control plane.
- Adds a selection boundary doc that keeps multi-candidate evaluation set-valued rather than smuggling in a hidden default winner/ranking rule.
- Adds a search boundary doc that keeps evaluation closed-world and bounded rather than widening into distributed credential discovery or hidden retry/fetch behavior.
- Adds a redelegation boundary doc that keeps delegated subjects from implicitly acquiring onward delegation power unless a future explicit propagation seam is added.
- Adds a normal-form boundary doc that keeps admitted statement arrays duplicate-free and strictly sorted rather than widening D-NAMECERT into order-sensitive or duplicate-weighted resolver semantics.
- Adds a string-profile boundary doc that keeps authority-bearing labels exact-byte lowercase ASCII rather than widening D-NAMECERT into Unicode/PRECIS/confusable-policy semantics.
- Adds a label-atom boundary doc that keeps admitted `Binding.name` / `Delegation.role` values as single opaque atoms rather than silently importing hierarchy, wildcard, prefix/suffix, or path grammar semantics onto the naming seam.
- Adds a principal-profile boundary doc that keeps admitted `PrincipalRef` identities hash-only and canonical rather than silently tolerating raw-key vs digest aliasing or bundle-carried verifier-key semantics.
- Adds a signature-profile boundary doc that keeps D-NAMECERT admission on one inline direct Ed25519 signature profile rather than silently accepting wrapper-only, keyless/X.509, or multisignature semantics.
- Adds a metadata boundary doc that keeps `bundle_id` / `created_ms` signed provenance only rather than silently importing latest-wins, replacement-lineage, or metadata-driven freshness semantics into the naming seam.
- Adds a bearer boundary doc that keeps admitted CH-NAMECERT bundles non-bearer evidence only rather than silently tunneling CH-SREF / CH-CAPX / raw capability material through the naming seam.
