# RFC-0061: Bootstrappable toolchains + diverse double-compiling (D-BOOTSTRAP / D-DDC)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-BOOTSTRAP, D-DDC, D-FPM, D-ATOMICUPD, D-UPD-SIGN

## Summary
Treat *toolchain trust* as a first-class design seam.

- **D-BOOTSTRAP**: keep an explicit path toward building the trusted toolchain from a **small, auditable seed**, reducing reliance on opaque bootstrap binaries.
- **D-DDC**: optionally run **Diverse Double-Compiling (DDC)** checks in the release pipeline to mitigate “trusting trust” attacks against compilers.

This RFC does **not** expand the kernel TCB. It defines build/release obligations and how they bind into existing artifacts (CH-PROV/CH-BOOT/CH-UPD).

## Motivation
Our assurance posture includes C-PROV-1 (reproducible builds + provenance) and update integrity (C-BOOT-1). Those claims quietly depend on the build toolchain.

Two under-adopted but high-leverage lessons:
- A compromised compiler can inject payloads that are absent from source (“trusting trust”).
- A system is easier to audit when the bootstrap seed is intentionally small and the bootstrap chain is explicit.

Baking in the seam now makes later hardening (without architecture churn) much cheaper.

## Design

### 1) Profiles: Bootstrap posture is explicit
Add a *build-side* profile knob (orthogonal to runtime profiles):

- **BP0 (Status quo seed)**: accept a conventional bootstrap toolchain; focus on reproducibility + provenance. (Default for early development.)
- **BP1 (Reduced seed)**: reduce bootstrap binaries where practical; make the seed set explicit, minimized, and hashed.
- **BP2 (Bootstrappable path)**: target a “full-source bootstrap” chain where the remaining binary seed is tiny and inspectable.

The archive should treat BP1/BP2 as optional targets; any release claiming C-PROV-1 must state which BP profile was used.

### 2) DDC checks as an evidence gate (optional)
In DDC, we compare a compiler-under-test binary with a “double-compiled” output produced via an independent path.

For release builds that enable D-DDC:
- build the compiler/toolchain using a second, *diverse* compiler chain
- rebuild the compiler-under-test from source using the newly built compiler
- require a **bit-for-bit match** (or a documented, bounded normalization rule if strictly necessary)

DDC is treated as a *gate* for selected trusted artifacts (at minimum: the compiler used to build privileged-core artifacts).

### 3) Binding into existing artifacts (no new runtime schemas)
We bind bootstrap posture and DDC outcomes into existing provenance/update artifacts:

- **CH-PROV v0**
  - add `materials[]` entries for bootstrap seeds (kind=`toolchain`), including digests of seed artifacts and any pinned bootstrap scripts.
  - add optional `evidence[]` entries for DDC outcomes (kind=`benchmark` for v0; we can refine later), pointing to a digest of a small DDC report.

- **CH-UPD v0 / CH-BOOT v0**
  - if `prov_attestation_digest` is present, post-boot audit can verify the provenance includes the declared bootstrap posture and any DDC evidence digests.

### 4) Threat model / assumptions
Add an explicit assumption:
- **A-TOOL-2 (compiler trust, scoped)**: the compiler/toolchain used to build trusted artifacts corresponds to its source, *unless* mitigated by D-DDC and/or a bootstrappable path.

## Invariants and obligations
No new kernel invariants.

Build/release obligations (engineering gates):
- **PO-PROV-TOOLCHAIN**: provenance for trusted artifacts includes toolchain/seed material digests.
- **PO-DDC-GATE (optional)**: if D-DDC enabled, the DDC match rule is deterministic and fail-closed.

(These are *release pipeline* obligations; they do not create new runtime claims unless explicitly mapped to C-PROV-1 scope.)

## Evidence plan
- E1: implement BP0 provenance binding: CH-PROV materials include toolchain pin + digest; verify it is bound in CH-BOOT/CH-UPD.
- E2: prototype DDC gate for a small compiler component (or a selected sub-toolchain) with a reproducible build environment.
- E3 (optional): migrate to BP1 reduced-seed posture for one platform.

## References
Refs: REF-THOMPSON-TRUST, REF-WHEELER-DDC, REF-BOOTSTRAPPABLE-BUILDS, REF-GUIX-FULLSOURCE, REF-STAGE0.
