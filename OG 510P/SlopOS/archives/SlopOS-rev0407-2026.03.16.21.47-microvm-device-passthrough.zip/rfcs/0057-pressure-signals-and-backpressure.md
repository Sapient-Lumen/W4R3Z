# RFC-0057: Resource pressure + backpressure signals (D-PRESSURE)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-PRESSURE, D-METER, D-TRACE, D-SIDECH

## Summary
Add an **explicit, capability-mediated pressure signal** mechanism so user-space components can adapt under load (shed work, shrink caches, degrade gracefully) without relying on brittle, ambient “system load” probes.

Concrete wire artifact: **CH-PRESSURE v0** (a redaction-safe, bounded event).

Refs: REF-LINUX-PSI, REF-FUCHSIA-MEMORY-PRESSURE, REF-SYSTEMD-PRESSURE.

## Motivation
Quotas (D-METER) answer “how much are you allowed to consume?”, but most real failures are **dynamic**:
- sudden memory reclaim pressure → tail latency spikes → cascade retries → collapse,
- IO backlog → timeouts → retry storms,
- CPU saturation → watchdog/health-check false positives.

Mainstream OSes provide various ad-hoc signals (OOM notifiers, loadavg, vmpressure hooks). Linux’s PSI shows a crisp lesson: **pressure is about stalled time**, not just utilization.

Greenfield gives us a clean seam:
- **pressure is observable**, not authorizing,
- it is **scoped** to an explicit resource container (avoid a global oracle),
- and it is **bounded/coarsened** to keep the side-channel posture explicit.

## Design

### 1) Pressure monitors are capabilities
Introduce a read-only capability:
- `PressureMonitor(resource, scope)` → stream/queue of CH-PRESSURE events.

**Scope** defaults to “your meter subtree” (D-METER) or a declared job/container (Fuchsia-style). A component cannot observe *global* system pressure unless explicitly granted a global monitor.

### 2) Event semantics (coarse + bounded)
The v0 event is intentionally small:
- resource: `mem|cpu|io|net`,
- level: `ok|some|full`,
- window: coarse aggregation window,
- optional stall percentages in basis points.

Emit on:
- level transitions (ok→some→full),
- periodic heartbeats only if policy enables them (rate-limited).

### 3) Backpressure composition patterns
Pressure signals enable *user-space* patterns that stay out of the privileged core:
- adaptive cache eviction (mem pressure),
- queue depth control / admission control (cpu/io pressure),
- retry backoff gates,
- “quality modes” for non-critical work.

For portal-mediated workflows (D-PLUMB), the portal may:
- attach a `PressureMonitor` scoped to the granted session, and/or
- recommend a budget lease (see RFC-0058) sized for “expected work”.

### 4) Side-channel posture
Pressure is a classic **oracle** risk (“did someone else allocate memory?”).
Mitigations in v0:
- scope = per-meter/container (no ambient global),
- coarsen + rate-limit + optional jitter,
- keep the signal non-authoritative: it cannot be used as an approval input (I-PRESSURE-1).

## Threat-model impact
New risks:
- pressure-as-oracle for cross-domain inference,
- event spam as a minor DoS vector.

Mitigations:
- I-PRESSURE-2 (scope), I-PRESSURE-3 (rate-limit/coarsen),
- PO-PRESSURE-SCOPE + PO-PRESSURE-RATELIMIT validation.

## Assurance/verification impact
New invariants (optional):
- **I-PRESSURE-1 (Pressure signals are non-authoritative):** no privileged path accepts CH-PRESSURE as authorization evidence; it is observational only.
- **I-PRESSURE-2 (Pressure observation is scoped):** pressure monitors expose only authorized scopes (meter subtree or explicit container); no ambient global oracle.
- **I-PRESSURE-3 (Bounded/coarse delivery):** pressure event emission is rate-limited/coalesced and uses bounded/coarse fields.

New proof obligations:
- **PO-PRESSURE-VALIDATE:** CH-PRESSURE decoding/validation is total/canonical; unknown variants reject; bounds enforced.
- **PO-PRESSURE-SCOPE:** IF-OBS/export enforces scope: callers cannot observe pressure for containers they do not hold authority to observe.
- **PO-PRESSURE-RATELIMIT:** event delivery is bounded and does not create a high-resolution timing channel beyond the declared profile.

New abuse case:
- **AC-050:** pressure oracle / cross-domain inference.

Evidence targets (initial):
- coarse event-shape golden tests + bounds,
- negative tests: “no global monitor unless granted”,
- fuzz corpus for CH-PRESSURE decode.

## Alternatives considered
- **Global load metrics only:** easy but becomes a cross-domain oracle and is hard to reason about.
- **Quotas only (no pressure):** encourages retry storms and brittle heuristics; misses the “stalled time” insight.
- **Kernel-enforced backpressure policy:** powerful but risks expanding the privileged core; we prefer user-space policy with a small primitive.

## Archive impact
- Adds D-PRESSURE decision node.
- Adds CH-PRESSURE v0 schema doc + schema registry row.
- Adds I-PRESSURE-1..3 and PO-PRESSURE-VALIDATE/PO-PRESSURE-SCOPE/PO-PRESSURE-RATELIMIT registry rows.
- Adds AC-050 and evidence placeholder EVID-2026-064.
