# RFC-0059: Sealed code spaces + dynamic code loading posture (D-DYNCODE)

Status: Draft  
Last updated: 2026-02-24  
Decision node(s): D-DYNCODE, D-WASM, D-ATOMICUPD, D-QUAR, D-CAPMODE

## Summary
Make **executable code** an explicit, reviewable authority boundary:
- default posture: **W^X everywhere** (no RWX) + **no “execmod”** (no turning writable pages into executable) without an explicit capability,
- default posture: **no dynamic native code loading** for high-assurance profiles (no `dlopen`/DSO injection surfaces),
- extensions and third‑party tooling default to **Wasm components** (D-WASM),
- any exception (JITs, dynamic native modules) is a *profile-scoped, capability-gated* escape hatch.

This is primarily an ecosystem + assurance choice: it shrinks exploit surface and makes provenance/attestation stories simpler, at the cost of compatibility with “arbitrary native plugin” cultures.

Refs: REF-OPENBSD-33-WX, REF-OPENBSD-WX-KERNEL, REF-SINGULARITY, REF-SING-OVERVIEW, REF-JITDEFENDER, REF-WAR-ON-JITS.

## Problem
Modern systems accumulate multiple ways for attacker-controlled bytes to become executable:
- RWX mappings (or “write then exec” via `mprotect`),
- dynamic native module loading (DSOs),
- JIT compilation (explicit runtime codegen),
- self-modifying code and runtime patching.

Even if the kernel is memory-safe, these features:
- amplify the impact of userland compromise (turning data injection into code execution),
- complicate provenance (what code is “running” right now?),
- and expand audit scope (dynamic loader + JIT + plug‑in ABI drift).

We want a system posture where “what code can execute” is:
1) **explicit**, 2) **attested**, and 3) **hard to widen accidentally**.

## Design stance
We treat “ability to create executable mappings” as **authority**.
A component that wants dynamic code must obtain it explicitly, and that grant must be:
- visible in the capability graph export (D-CAPAUD),
- optionally consent-mediated in user-facing profiles (D-POWERBOX / D-EXPLAIN),
- and attributable in transcripts (CH-LOG).

### Key split: policy vs mechanism
- **Mechanism:** privileged core enforces W^X and gates transitions into executability.
- **Policy:** user space decides who gets the “exec-authority” capability under a given profile.

## Options
### Option A (recommended for P2 / high-assurance): “sealed code spaces”
- no dynamic native module loading
- no `execmod` (RW→RX) without an explicit capability
- third‑party extensions use Wasm (D-WASM) or “disposable domains” (D-EPHEM)
- updates use atomic images + rollbacks (D-ATOMICUPD)

### Option B (general-purpose): “capability-gated exec”
- allow dynamic loading and JIT only when a process holds a dedicated **ExecMap**/ExecMod capability
- require W^X (no RWX) and enforce a safe JIT pattern (dual-mapping RW+RX or a broker)

### Option C (baseline compatibility): “best effort”
- permit common POSIX semantics (dynamic loader, `mprotect` flips) and rely on hardening + sandboxing
- not recommended for a system claiming tight authority discipline; makes provenance weaker

## Minimal seam (mechanisms we can bake early)

See also: `docs/30-architecture/capability-rights-registry.md` (v0 rights vocabulary + exec/execmod seam).
### 1) W^X as a core invariant
- deny RWX mappings in all profiles
- treat “make executable” as an effectful operation with explicit authorization

### 2) Exec-modification gating (explicit exec authority)
Introduce an explicit **exec-authority** capability (`VmExec` in this RFC) required for either:
- creating/upgrading an executable backing object for bytes that are *not* sealed-artifact text, or
- changing a mapping from writable to executable (RW→RX), i.e. "execmod".

Design note: prefer a **two-key** execute gate: executable mappings require both mapping authority *and* executable backing bytes.
- `mem.map(... perm=X ...)` requires `VSpace.MAP_X` **and** `MemObj.X`.
- a `MemObj` can only gain `X` via `VmExec` (typically held by a loader/JIT broker, not general domains).

Everything else (how JIT is implemented, which runtimes are allowed) stays in user space and profiles.

### 3) Sealed artifact binding (optional refinement)
In stricter profiles, require that executable mappings are *bound to provenance*:
- executable pages are backed by content-addressed, signed artifacts (D-FPM / D-ATOMICUPD),
- the boot/update manifests bind the allowed digests (CH-BOOT / CH-UPD).

## Interactions
- **D-WASM**: default extension runtime avoids native dynamic code in the first place.
- **D-QUAR**: origin metadata + quarantine should treat “wants exec” as high-risk.
- **D-ATOMICUPD**: sealed code spaces align naturally with atomic images and rollbacks.
- **D-RR**: record/replay is easier when code doesn’t mutate at runtime.

## Invariants / proof obligations (sketch)
- **I-WX-1:** privileged core never maps RWX pages.
- **I-EXECMOD-1:** RW→RX transitions (and executable mappings of non-sealed bytes) require explicit exec authority (e.g., `VmExec`), with no bypass.
- **I-EXEC-SOURCE-1 (optional):** in sealed profiles, executable pages are backed by allowed digests.

Proof obligations: PO-WX-ENF, PO-EXECMOD-ENF, PO-EXEC-SOURCE.

## Evidence plan
E0: spec the surface (where executability can be introduced) + add lint rules that flag any new exec-enabling path.
E1: prototype W^X enforcement and execmod gating in a tiny userland demo (map, flip, expect fail unless authorized).
E2: differential tests between a tiny definitional model and the implementation for allowed/denied transitions.
E3: mechanize I-WX-1 + I-EXECMOD-1 for the chosen KABI in the verifier stack.

## Practical caveats
- Some runtimes (JITs, DB engines, browsers) will want execmod. That’s OK: make it **obvious** and **reviewable**.
- If we support JITs, prefer a brokered or dual-mapped design; keep “RW and RX for the same bytes” carefully scoped.

## References
- OpenBSD W^X in release notes: REF-OPENBSD-33-WX
- OpenBSD kernel W^X improvements talk: REF-OPENBSD-WX-KERNEL
- Singularity “sealed code spaces” + contracts mindset: REF-SINGULARITY, REF-SING-OVERVIEW
- Zircon/Fuchsia execute gating examples: REF-FUCHSIA-VMAR-MAP, REF-FUCHSIA-VMO-EXEC
- JIT spraying and mitigations: REF-JITDEFENDER, REF-WAR-ON-JITS
