# RFC-0035: Capability graph export, introspection, and leak tests (D-CAPAUD)

Status: Draft  
Updated: 2026-02-24  
Decision node: D-CAPAUD

Goal: make capability systems *operationally usable* by providing a bounded way to answer:
- “who still has authority X?”
- “did we accidentally leak authority during operation Y?”
- “why can’t component Z access resource R?” (debug)

This is explicitly **not** ambient introspection: exports are policy-gated and redacted, delivered through IF-OBS.

## Design (v0)

### 1) Exported artifact: CH-CAPG v0
Define a redacted, bounded snapshot schema **CH-CAPG v0** and allow IF-OBS to optionally include it in CH-OBS exports.

Key properties:
- no raw kernel IDs or addresses
- stable only within the bundle (small integer node IDs)
- bounded (fails closed when exceeding policy limits)

See: `docs/30-architecture/capability-graph-schema-v0.md`.

### 2) Authority model
Introduce an explicit “audit authority” capability:
- Holding it allows requesting a cap-graph snapshot for a specific scope (domain/component).
- Without it, callers may only receive high-level counters.

No global “list all caps” interface is introduced; scoping is explicit.

### 3) Leak tests (tooling convention)
A leak test is:
1. take snapshot `g0`
2. perform operation under test
3. take snapshot `g1`
4. diff `(nodes, edges)` and assert a predicate (“no new edge from untrusted domain to privileged object kinds”, etc.)

This aligns with the archive’s general approach: confinement tests are *spec artifacts* (predicates over graphs), not hand-wavy prose.

## Risks + mitigations
- **Side-channel / exfil risk**: exporting structure can leak information.
  - Mitigation: redaction, bounding, policy scoping, and default-off in sensitive profiles (maps to C-OBS-1; I-OBS-1). 
- **Attack surface**: exporter bugs.
  - Mitigation: keep schema tiny, deterministic encoding, and make export a pure “read-only” walk over already-maintained tables.

## Evidence plan
- Implement a debug exporter in the prototype (no kernel addresses; bounded output).
- Write 3 leak tests:
  - powerbox flow (should not leak post-consent)
  - service spawn + namespace construction
  - driver-domain hotplug (should not gain new privileged edges)

## Open questions
- Should cap-graph export be available in production profiles at all, or only in “audit builds”?
- Best diff semantics: structural diff vs. semantic diff (rights summaries)?

Refs: REF-CAPSICUM, REF-GENODE-MANUAL.
