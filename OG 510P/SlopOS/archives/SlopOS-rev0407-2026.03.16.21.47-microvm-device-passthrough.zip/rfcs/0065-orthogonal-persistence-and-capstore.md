# RFC-0065: Orthogonal persistence + capability store (D-PERSIST)

Status: draft  
Updated: 2026-02-25

## Goal
Make **durable authority graphs** a first-class *optional* profile by defining a user-space **capability store** (“CapStore”) that can persist:
- objects (pages, blobs, higher-level objects),
- **capabilities/sturdyrefs** (including revocation epochs),
- and **named roots** needed to reconstruct system state after restart,

…without turning persistence into ambient authority or silently expanding the privileged TCB.

This is a “greenfield advantage” feature: many systems bolt persistence on as a file abstraction; capability systems like **KeyKOS/EROS/CapROS** show that *orthogonal persistence* can simplify recovery, upgrades, and auditing when designed in from day one.

## Non-goals
- Making persistence mandatory for the MVP.
- A distributed object database (network replication is out-of-scope for v0).
- Storing raw secrets without explicit ENC policy (this must route through D-ENC + declared key custody).

## Prior art (why this is not fantasy)
- **KeyKOS / EROS / CapROS**: whole-system checkpoints preserve *capability relationships* so “reboot” does not change the security model; construction patterns assume durable authority graphs. (REF-KEYKOS-ARCH85, REF-KEYKOS-OSR92, REF-EROS-FASTCAP, REF-CAPROS-OVERVIEW)
- **CapROS device note**: persistence interacts badly with hardware state; device-facing capabilities often need explicit non-persistent or virtualized semantics. (REF-CAPROS-USERDRIVERS)
- **TreeSLS (SOSP 2023)**: modern microkernel-flavored evidence that following a **capability tree** can capture whole-system state efficiently on NVM-era systems. (REF-TREESLS-SOSP23)

This RFC keeps D-PERSIST optional and explicit because the above systems also show that persistence changes *everything* (time/rollback, GC, device models, upgrade/migration).


## Background / prior art (why this belongs at the ground floor)
- **KeyKOS / EROS / CapROS**: persistent capability systems; “resume is boot” and recovery are native, not bolted on.
- **Orthogonal persistence**: uniform treatment of short-lived vs long-lived objects reduces impedance mismatch and failure modes.
- Our archive already has seeds:
  - sturdyrefs (RFC-0014),
  - checkpoint/restore (D-CHKPT; CH-CKPT),
  - record/replay (D-RR),
  - provenance + transparency anchors (CH-PROV / CH-TLOG).

D-PERSIST is the glue that makes those pieces compose into an *operational* “crash-only + recoverable” OS.

## Design sketch (v0)
### 1) CapStore is a user-space service, not a kernel feature
- Kernel remains responsible only for isolation + minimal object primitives.
- CapStore runs in its own domain(s), supervised like any other critical service.
- CapStore talks to storage via explicit leases (D-IOLEASE / D-NETLEASE where relevant).

### 2) Persistence is explicit authority
No component can make authority durable without an explicit store capability:
- `CapStoreCap`: grants the right to create/update durable objects and/or durable roots.
- `DurableRootCap(name)`: grants the right to update a named root (e.g., `root/system`, `root/user/<uid>`, `root/app/<id>`).

**Invariant:** if you don’t have the store cap, your authority dies on reboot.

### 3) Durable commits are content-addressed + signed
CapStore commits are represented as a schema:
- **CH-CAPSTORE v0**: a commit object that describes updated roots, referenced data blobs/pages, and revocation epoch bindings.
- Commits are content-addressed (CH-AREF) and, when used for boot/resume, must be bound into CH-BOOT/CH-PROV digests.

### 4) Revocation + rollback are first-class
Persisting capabilities makes rollback/resurrection attacks realistic.
v0 stance:
- Each durable root update carries a **monotonic epoch** (logical, and optionally anchored to hardware counters when available).
- Restoring a root with an epoch lower than the last-seen epoch is treated as **adversarial rollback** unless the deployment profile explicitly opts into “rollback allowed” mode (for dev/test).

### 5) Boot: “resume is boot” (optional)
If D-PERSIST is enabled for a profile:
- CH-BOOT may declare a **resume root** (CH-CAPSTORE root + epoch).
- Init may choose between:
  - “fresh boot” (ignore CapStore; useful for recovery), or
  - “resume” (restore a declared root set).

This composes cleanly with D-CHKPT: checkpoints become *named roots* in CapStore.

## Threats / abuse cases
- **Rollback** (restore old roots to re-enable revoked authority or replay vulnerable state).
- **Resurrection** (stale sturdyrefs/caps become valid again after restore).
- **Confused durability** (a component assumes “saved” when it only updated volatile state).

Mitigations (v0):
- explicit DurableRootCap and CH-CAPSTORE epoch checks (I-PERSIST-1..3; PO-CAPSTORE-VALIDATE, PO-PERSIST-NOAMP, PO-PERSIST-ROLLBACK),
- “rollback allowed” is an explicit deployment knob and must gate secret release,
- bind “last seen” epoch into CH-BOOT/CH-PROV for audited boots.

## Alternatives considered
- “Just use files” (POSIX persistence): reintroduces ambient authority + ad-hoc naming; makes durable authority hard to reason about.
- Kernel-managed persistence: expands privileged TCB and mixes policy with mechanism.
- “Only checkpoints” (D-CHKPT without CapStore): loses named roots + durability semantics and pushes rollback problems into every app.

## Evidence plan
- E1: CapStore prototype that persists a small cap-graph + named roots; reboot/resume demo.
- E2: property tests for non-amplification on restore + rollback detection.
- E2+: fuzz CH-CAPSTORE decoder + negative tests (“unknown fields reject deterministically”).

## Registry impact (additions)
- Decision: D-PERSIST.
- Schema: CH-CAPSTORE v0.
- Invariants: I-PERSIST-1..3.
- Proof obligations: PO-PERSIST-NOAMP, PO-PERSIST-ROLLBACK, PO-CAPSTORE-VALIDATE.

## Open questions
- Minimum viable epoch anchoring (logical epoch only vs TPM/TEE monotonic counter binding).
- How to represent GC roots without leaking metadata (privacy vs accountability).
- Whether “single-level store” paging is a later step or kept as an implementation detail under CapStore.
