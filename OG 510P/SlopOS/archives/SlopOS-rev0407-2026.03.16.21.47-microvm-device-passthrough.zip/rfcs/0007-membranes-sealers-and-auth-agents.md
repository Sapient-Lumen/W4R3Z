# RFC-0007: Membranes, sealers, and key-holding auth agents (D-MEMBRANE, D-AUTHAGENT)

Status: Draft

Goal: capture a set of *object-capability* patterns that are unusually compatible with our discipline (explicit authority, auditable edges, bounded mechanisms), but rarely baked in early to OS designs.

We treat these as **ecosystem primitives** (mostly user-space) that can strengthen least-authority, revocation, and supply-chain posture without bloating the privileged core.

## 1) Membranes + revocable forwarders (authority attenuation + revocation)
### Summary
A **membrane** wraps capabilities crossing a boundary (between components, trust zones, plugins, or remote references) so that:
- all authority is mediated through explicit forwarders
- optional revocation can be made **transitive** (revoke the membrane, revoke everything obtained through it)

### Candidate decision: D-MEMBRANE
Options:
1) **User-space membranes** only (default): wrappers/proxies in libraries and gateways (works well with D-WASM and D-CAPX).
2) **Kernel-supported revocation hooks** (avoid unless needed): kernel provides indirection tables/epochs; membranes still user-space.

### Minimal seam
- Provide a canonical “proxy object” pattern: (target_cap, policy_cell) where policy_cell is a revocation/allow bit.
- Ensure our capability semantics (D-CAP) can represent “wrapped” handles without confusing them with raw caps.
- Pair with init→seal (D-SEAL): long-lived services seal and only export wrapped caps across boundaries.

### Invariants
- **I-MEMBRANE-1 (Transitive revocation, optional)**: if a membrane is revoked, any capability wrapped by that membrane (and its descendants) cannot be used to produce effects.
- **I-MEMBRANE-2 (No unwrapped leakage, optional)**: components that export authority across a boundary do so only via declared wrappers; raw, unmediated capabilities do not escape unless explicitly allowed.

### Proof obligations
- **PO-MEMBRANE-REVOKE**: revoke(membrane) disables all wrapped uses in a fail-closed way (no bypass path).

### Abuse case
- **AC-014**: an unwrapped capability leaks across the boundary and bypasses revocation/attenuation.

## 2) Sealers/unsealers (safe opaque passing through untrusted intermediaries)
### Summary
A **sealer/unsealer** pair lets trusted code place an object reference into an opaque box that can be carried through untrusted code and only opened by the holder of the unsealer.

This is a good fit for:
- capability handoff through “dumb” brokers
- plugin hosts passing opaque state to plugins without granting inspection
- bridging to delegation envelopes (D-CAPX) without exposing internal references

### Minimal seam
- Treat sealed boxes as *data objects* that are meaningful only to the unsealer holder.
- Keep this outside the privileged core unless/until it becomes a verified slice.

### Proof obligation
- **PO-SEALER-SOUND**: sealed boxes reveal no usable authority without the unsealer (no confused-deputy via partial unboxing).

## 3) Factotum-style authentication agent (key isolation as a service)
### Summary
A per-user (or per-domain) **authentication agent** holds long-lived keys and runs authentication protocols on behalf of clients. Clients get *capabilities to request operations*, not raw key material.

This pattern centralizes complex crypto/protocol code into one component that can:
- be more heavily audited/verified
- be sealed post-init (D-SEAL)
- apply explicit policies (rate limits, meters, logging) without leaking keys

### Candidate decision: D-AUTHAGENT
Options:
1) **User-space auth agent** (default): a service exporting a small, versioned API; keys never leave.
2) **Hardware-backed keys** (optional platform annex): agent uses TPM/TEE keys; assumptions recorded under A-BOOT-1/A-BOOT-2 and A-CC-1.

### Minimal seam
- Define an interface shape: “sign/challenge/derive-session” ops with explicit inputs and nonces; outputs are deterministic bytes.
- Bind operations to meters (D-METER) and transcripts (CH-LOG) so authentication events are auditable without secret leakage.

### Invariant
- **I-AUTHAGENT-1 (Non-exportable keys, optional)**: private key material is not directly readable/exportable via the agent interface; only declared operations are available.

### Proof obligation
- **PO-AUTHAGENT-NONEXPORT**: the agent API + implementation do not permit raw key extraction (within the stated threat model).

### Abuse case
- **AC-015**: compromised client attempts to extract key material or coerce the agent into signing beyond its delegated authority.

## References
- Object-cap patterns: membranes/revocation/sealers: REF-OCAP-AOCS, REF-OCAP-MURPHI, REF-CAPMYTHS.
- Plan 9 security + factotum: REF-PLAN9-AUTH, REF-PLAN9-FACTOTUM.
