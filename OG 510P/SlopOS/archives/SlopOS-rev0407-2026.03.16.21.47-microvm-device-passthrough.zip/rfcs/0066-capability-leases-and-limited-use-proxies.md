# RFC-0066: Capability leases + limited-use proxies (D-LEASE)

Status: draft

## Goal
Make “**temporary authority**” a first-class *optional* ecosystem seam: portals/gateways should be able to hand out capabilities that are intentionally **short-lived** (time-limited and/or use-limited) without baking policy into the privileged core.

This reduces the blast radius of leaks, makes “share for 10 minutes / 1 time” flows ergonomic, and turns a common ad-hoc pattern (expiring tokens, temporary credentials) into a **capability-shaped** mechanism that composes with D-PLUMB / D-EXPLAIN / D-NONDET / D-PERSIST.

## Non-goals
- Putting wall-clock time or lease policy into the kernel.
- Perfect revocation of already-leaked raw capabilities (if you hand out the raw cap, you’ve already lost).
- Replacing D-MEMBRANE / revocation (RFC-0019); leases complement them.

## Background / prior art (why this belongs at the ground floor)
- Object-capability systems emphasize **attenuation** and patterns like **Revoker/Caretaker** and **Membrane** wrappers to mediate authority without leaking the raw capability (REF-CAPMYTHS; REF-OCAP-AOCS).
- “Limited use” and “expiration” patterns show up repeatedly in capability-inspired systems and web capability URLs (e.g., one-time links, time-limited grants) and can be expressed cleanly as proxy objects (Koppmann: Membrane + Limited Use + expiry caveats) (REF-KOPPMANN-ES).
- Modern platforms routinely rely on **temporary credentials** (expiring access tokens) for practicality; in a capability OS we can model this as *capabilities that are proxies with bounded lifetime* rather than ambient bearer strings.

Greenfield advantage: if lease/proxy issuance is standardized early, higher-level runtimes (workflow portals, CAPX gateways, GUI “share” flows) can default to least-authority without each reinventing token lifecycles.

## Design sketch (v0)

### 1) Leases are implemented as proxy objects (user space)
A **lease** is not a special capability kind; it is a **capability to a proxy** that forwards to an underlying capability under explicit bounds.

Mechanism:
- `LeaseGate` holds `target_cap` privately.
- Callers receive only `leased_cap` (a cap to the `LeaseGate`).
- `LeaseGate` enforces bounds before forwarding.

This is the same “don’t leak raw caps” discipline we already rely on for cross-boundary wrappers (D-MEMBRANE; I-MEMBRANE-2).

### 2) Two bounds are enough for v0
We standardize two first-class bounds that cover most real workflows:

**(a) Use-limited**: allow at most `N` successful forwards.  
**(b) Time-limited**: allow forwards only until a deadline.

Both can be combined (“at most N uses until deadline”).

Time-limited leases use **explicit Clock handles** from D-NONDET:
- LeaseGate requires a `ClockCap` (coarse by default) to evaluate deadlines.
- If a profile forbids ambient time (D-NONDET), the lease gate has no backdoor: no clock, no time checks.

### 3) A redaction-safe descriptor schema: CH-CAPLEASE v0
We introduce **CH-CAPLEASE v0** as a *descriptor* for a leased/proxy capability:
- describes bounds (uses/time), the clock kind/digest used (if any), origin attribution, and a non-authoritative `purpose` string,
- carries **no secrets** and need not reveal the target object identity,
- is suitable for CH-LOG / consent receipts / audit exports.

See: `docs/30-architecture/capability-lease-schema-v0.md`.

### 4) Composition points (why this pays off)
**D-PLUMB portals:** default portal grants to *leased* caps for risky resources (e.g., “open external URL”, “share a directory”) unless the user explicitly chooses “always allow”.  
**D-EXPLAIN:** authority diffs can render lease bounds (“valid for 10 minutes”, “1 use”) and receipts can include `digest(CH-CAPLEASE)`.  
**D-CAPX:** imported remote authority should often arrive as a leased proxy (especially when the remote token already carries expiry caveats).  
**D-PERSIST:** CapStore should treat leases as **non-durable by default**; persisting a leased cap should require explicit policy and should persist only a *sturdyref to the lease issuer*, not the raw underlying capability.

### 5) Failure modes and sharp edges (explicit)
- **Leases don’t rescue a leaked raw cap.** The proxy pattern works only if the raw capability never escapes (I-MEMBRANE-2).
- **Clock quality is a policy decision.** Fine clocks are stronger oracles; prefer coarse clocks for sandboxed/low-trust lease gates (D-NONDET).
- **Expiry is fail-closed.** If the lease gate cannot consult its clock (or the clock handle expires), it must reject forwarding.

## Invariants / proof obligations / abuse cases
- **I-LEASE-1 (Fail-closed expiry, optional):** if D-LEASE is enabled, lease enforcement fails closed on expiry, clock errors, or counter underflow; no “best effort” forwarding.
- **I-LEASE-2 (No unbounded renewal, optional):** lease renewal requires explicit renewal authority; delegates cannot extend TTL/uses without it.
- **I-LEASE-3 (Lease issuance is non-amplifying, optional):** a lease never grants more rights than the wrapped capability (attenuation only).

Proof obligations:
- **PO-LEASE-VALIDATE:** CH-CAPLEASE decoding/validation is total and rejects non-canonical forms (I-ENC-1).
- **PO-LEASE-ENF:** for D-LEASE, forwarding checks are complete (no bypass paths) and deterministic given the declared nondeterminism sources (D-NONDET/D-RR).
- **PO-LEASE-NOAMP:** for D-LEASE, any lease wrapper constructed by a portal/gateway is provably non-amplifying w.r.t. the wrapped capability.

New abuse case:
- **AC-055:** “lease confusion / bypass”: a component believes it delegated a leased cap but accidentally leaks the raw cap (or renews implicitly), resulting in unbounded authority retention.

## Open questions (record now, decide later)
- Do we want a *kernel optimization* for expiring handles in some profiles, or keep leases purely in user space?
- Should CH-CAPLEASE include an optional “target class” label (e.g., `File`, `NetDialer`) for UI rendering, or is that better derived from IDL metadata?
- Should CapStore allow persisting leases at all, or require converting to a durable capability via an explicit “make durable” step with a clear UX?

## Impact / archive changes
- Adds D-LEASE decision node.
- Adds CH-CAPLEASE v0 schema.
- Adds I-LEASE-1..3 invariants, PO-LEASE-VALIDATE/ENF/NOAMP obligations, and AC-055 abuse case.
- Refactors device leasing schema ID: **CH-LEASE v0 → CH-IOLEASE v0** (deprecation recorded).

