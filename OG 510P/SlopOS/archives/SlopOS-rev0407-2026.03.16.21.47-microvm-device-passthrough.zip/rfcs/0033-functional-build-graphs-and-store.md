# RFC-0033: Functional build graphs + content-addressed store (D-FPM)

Status: Draft  
Updated: 2026-02-25  
Decision node: D-FPM

Goal: design for **reproducible, rollback-friendly system composition** by treating builds/installs as evaluation of a build graph whose outputs are content-addressed by their inputs (Nix/Guix lesson). This should strengthen our provenance story (CH-PROV) and make atomic deployments (D-ATOMICUPD) more natural.

Non-goal: shipping a full Nix/Guix clone in Phase 1. The initial goal is a *seam* that we can grow into without re-architecting boot/update and without expanding TCB.

Refs: REF-NIXOS-JFP10, REF-NIX-HOWNIX, REF-GUIX-FPM13, REF-GENODE-PKG, REF-GENODE-UPDATE-ROLLBACK.

## Problem
Traditional systems mutate a shared filesystem state in place (package install/upgrade). This creates failure modes that are hard to reason about:
- “what ran?” is not a stable digest;
- rollbacks are fragile;
- reproducing a build requires rebuilding a moving target;
- provenance attestations (CH-PROV) often point at “steps” but not a verifiable *closure*.

We already want:
- content-addressed artifact references (CH-AREF),
- provenance attestations bound at boot (CH-BOOT `prov_attestation_digest`),
- atomic deployments (D-ATOMICUPD) as an option.

Functional package management aligns these into a single story.

Genode reaches many of the same ends in a capability-oriented, microkernel ecosystem: depot-style packages support modular compositions, on-target update, and rollback to previously downloaded versions (secured by signatures). That's a useful operator reality check: our D-FPM seam should make the "system closure" explicit and keep rollback a default workflow, even when the build graph is produced off-target.


## Proposal (seam-first)
### 1) Introduce a minimal build-derivation record (CH-DERIV v0)
Define a schema for recording:
- the builder identity (tool digest / environment);
- the full input set (digests, including transitive where available);
- declared outputs (digests + roles).

This is not necessarily a “build language”; it is a *record* we can:
- store as evidence;
- bind into CH-PROV as a closure hint;
- audit/diff across releases.

### 2) Treat “system closure” as an artifact
Define “closure” (conceptual):
- a root manifest (boot manifest or component graph),
- plus all referenced artifacts needed to boot and run that manifest.

The closure can be represented as:
- a set of CH-AREF entries (digest + role),
- plus optional CH-DERIV entries explaining how they were produced.

### 3) Keep verification small
IF-BOOT should not grow into a general build verifier.
Instead:
- IF-BOOT verifies *digests and signatures* per CH-BOOT + policy.
- Higher-level reproducibility checks happen in CI/build pipelines and are recorded as EVID artifacts (diff logs, rebuild checks).

## How it composes with existing decisions
- **D-ATOMICUPD:** closures map naturally to immutable deployment trees; switching deployment = switching root digest.
- **CH-PROV:** provenance can optionally include a pointer to derivation/closure manifests, but the binding at boot remains “digest equality”.
- **D-ENC:** derivations are canonical-encoded like other CH-* schemas (reject non-canonical).

## Assurance hooks (invariants + proof obligations)
This RFC relies on a small set of supply-chain invariants:
- I-FPM-1 (store immutability), I-FPM-2 (derivation hash completeness), I-FPM-3 (hermetic evaluation by default).

Proof obligations to discharge (via tests, fuzzing, and later mechanization where practical):
- PO-FPM-STOREIMMUT (immutability enforcement),
- PO-FPM-HASHKEY (hash-key completeness / declared inputs),
- PO-FPM-HERMETIC (no ambient network/host state without explicit declaration).

Threat model touchpoint:
- AC-039 (build store poisoning / impurity).

## Risks & mitigations
- **Storage growth:** requires garbage collection; keep GC policy out of the trusted core.
- **“Reproducible” is not guaranteed:** we gate on *checks* and publish evidence; we do not silently assume it.
- **Developer friction:** keep Phase 1 lightweight (derivation records are optional; standard “cargo build” workflows can still produce CH-AREF outputs).

## Evidence plan
1. Build a small closure (kernel + init + 1 service) twice in CI and record a reproducibility check artifact.
2. Record CH-DERIV for that closure; ensure the toolchain digests are included.
3. Demonstrate that a deployment digest + provenance digest pair can be verified at boot (fail-closed on mismatch).
