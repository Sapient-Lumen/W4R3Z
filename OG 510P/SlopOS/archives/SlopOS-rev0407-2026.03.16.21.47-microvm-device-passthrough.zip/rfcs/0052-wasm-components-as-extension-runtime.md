# RFC-0052: WebAssembly components as the default untrusted extension runtime (D-WASM)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-WASM, D-PLUMB, D-EPHEM, D-CAPMODE

## Summary
Make **Wasm components** the default substrate for third‑party extensions, plugins, and “tool” execution:
- extensions run in an **untrusted sandbox** boundary (IF-SBX) with *no ambient acquisition*,
- authority is received only through **typed capability imports** (WIT interfaces),
- high-risk imports require **consent mediation** (IF-CONSENT) and are transcript-logged,
- quarantined/untrusted payloads default to **disposable domains** (D-EPHEM).

This is an ecosystem choice: we bias toward portability + confinement + composable interfaces, even if “native plugins” remain possible behind stricter profiles.

Refs: REF-WASM-CM-INTRO, REF-WASM-CANONABI, REF-WASI-DESIGN, REF-WASI-0-2.

## Problem
We want an ecosystem where users can install extensions without turning the whole system into “ambient authority + native code everywhere”.
Historically, “plugin systems” become a privileged ambient mess:
- native plugins inherit host process authority,
- scripting runtimes grow huge and dynamic (hard to audit),
- APIs drift, and the only stable interface is “whatever worked last week”.

We already have (or want):
- powerbox/consent mediation (D-POWERBOX / D-PLUMB),
- explicit capability discipline (D-CAPMODE),
- a sandbox boundary (IF-SBX),
- disposable domains for risky flows (D-EPHEM),
- reproducible composition seams (D-FPM).

This RFC specifies a **default extension runtime** that composes with those choices.

## Goals
- A **narrow, spec-first** extension substrate that is:
  - portable across ISAs,
  - sandboxable by default,
  - interface-typed and versionable,
  - compatible with capability security.
- A “small core, rich user space” story: keep the privileged core unchanged.
- Make it easy to build:
  - safe automation glue,
  - application plugins (UI + data transforms),
  - policy-constrained agents/tools.

## Non-goals
- Replacing the whole userspace with Wasm.
- A complete browser-style sandbox in the privileged core.
- Guaranteeing “no side channels”; we aim for explicit profiles + measurable mitigations.

## Proposed design

### A) What runs where
- **Wasm components** are the *default* payload type under IF-SBX.
- The Wasm runtime is a **user-space service** running with least authority, not in the privileged core.
- For untrusted/quarantined payloads, execution defaults to a **disposable domain** template (D-EPHEM).

### B) Authority model: closed, typed imports
A component can only affect the world by calling imported interfaces:
- Imports are a **closed allowlist** (fail closed on unknown imports).
- Imports are **typed** (WIT), and the host injects *capability handles* (not paths, not globals).
- “Open by path” is not an import; components receive directory/file handles already authorized.

This supports:
- I-CAPMODE-1 (no ambient acquisition),
- I-WASM-4 (closed imports),
- I-SBX-1 (sandbox confinement).

### C) Consent + portals for high-risk edges
Any import that crosses a “human safety boundary” (camera, mic, screen, raw input, USB, network egress, secret access):
- must be mediated by IF-CONSENT/powerbox,
- returns a **time/lease-bounded handle** (D-IOLEASE),
- is transcript-logged (CH-LOG).

### D) Profiles (deliberately few)
- **WASM-P0 (safe)**: pure computation + explicit I/O handles only; no network; no raw device.
- **WASM-P1 (networked)**: network handles only via consent/policy; no raw device.
- **WASM-P2 (device)**: explicit device leases only; defaults off; requires strong evidence.

### E) Packaging seam (minimal)
- Installation pins a component by digest (CH-AREF) and records:
  - component digest,
  - declared import set,
  - declared profile (P0/P1/P2),
  - optional signature/provenance (CH-PROV, if enabled).

Initial implementation can store this as a plain manifest in the functional store (D-FPM); a future CH-* schema can standardize it if/when cross-boundary exchange requires it.

## Security considerations
- Treat the runtime/JIT as **untrusted**: it runs inside IF-SBX confinement and does not expand TCB.
- Prefer AOT in hardened profiles; allow JIT only under explicit “unsafe budgets” (U-IDs) if needed.
- Require deterministic “import closure” auditing: any component update that changes imports triggers consent and policy review.

## Alternatives considered
- Native plugins with process isolation only (harder to audit; weaker interface typing).
- A general scripting runtime (Lua/Python/JS): convenient but tends to grow ambient escape hatches.
- eBPF-like in-kernel plugins: fastest but expands trusted core and proof surface.

## Required invariants / proof obligations / evidence plan
Invariants:
- I-WASM-1, I-WASM-2, I-WASM-3, I-WASM-4 (this RFC introduces/uses them; see invariant registry).

Proof obligations:
- PO-WASM-IMPORTS (imports are closed + validated),
- PO-WASM-CONFINE (runtime confinement under IF-SBX),
- PO-WASM-HANDLE (handles cannot be forged / confused).

Evidence targets:
- EVID-2026-041 (E1): import-closure validator + negative test suite
- EVID-2026-042 (E2): fuzz harness for host import adapters + sandbox boundary probes
