# RFC-0071: Interface evolution, open protocols, and adapters (D-APIEVO)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): D-APIEVO, D-CAPRPC, D-IDL, D-ATOMICUPD (optional), D-CONTRACT (optional), D-EXPLAIN (optional)

## Summary
We need an explicit, boring, *auditable* answer to: **how do interfaces evolve without creating security holes or operational fragility?**

This RFC:
- introduces **D-APIEVO** as a design seam for **interface evolution posture**,
- adds **CH-IFACE v0** as the canonical “interface identity + evolution policy” pin,
- refines **CH-CAPRPC v0** semantics so `iface_digest` refers to a **CH-IFACE digest** (not a raw IDL blob),
- standardizes forward-compat behavior for RPC runtimes via stable framework error codes (e.g., `UNKNOWN_IFACE`, `UNKNOWN_METHOD`),
- and makes **adapters/translators** first-class components for compatibility (upgrade-time or runtime).

Refs: REF-FUCHSIA-APIEVO, REF-FUCHSIA-RFC0138, REF-CAPNP-EVOL, REF-PROTOBUF-COMPAT, REF-MS-COM-IUNKNOWN.

## Motivation
Interface churn is inevitable:
- services split/merge,
- semantics sharpen,
- performance demands new bulk paths,
- security hardening changes what’s allowed.

Without an explicit evolution plan, systems tend to drift into one of two failure modes:
1) **“Silent fallback”** (confused-deputy risk): callers retry “something that works” and accidentally invoke a more powerful path.
2) **“Brittle upgrades”**: one component upgrade breaks half the system, because the mismatch is discovered late and is hard to diagnose.

A microkernel-ish system intensifies this: more functionality is in user space, so **interfaces are the system**.

Greenfield advantage: we can bake in a small evolution discipline now, so the ecosystem does not reinvent it ad hoc.

## Design stance
- **Identity is explicit and content-addressed.** Every RPC frame is bound to an explicit interface identity (`iface_digest`).
- **No guessing.** If an interface is unknown, the callee must deterministically refuse (or deterministically report), not “try another interface”.
- **Forward-compat is opt-in.** “Open” interfaces have explicit unknown-op semantics; “closed” interfaces fail hard.
- **Compatibility is a component.** When semantics truly change, ship an adapter/translating component; do not encode silent downgrade logic in clients.

## Interface pins: CH-IFACE v0
CH-IFACE v0 is a small artifact that binds:
- interface identity (`iface_digest`, equal to digest(canonical_bytes(CH-IFACE))),
- the pinned definition digest used for codegen (`idl_digest`, D-IDL),
- an optional protocol contract digest (`contract_digest`, D-CONTRACT),
- and an explicit evolution posture (`openness`, `unknown_method`).

Spec: `docs/30-architecture/interface-descriptor-schema-v0.md`.

**Open-interface note:** for CH-IFACE.openness=`open`, it is often preferable to **omit** `idl_digest` so that `iface_digest` can remain stable while new methods are added. In this posture, the evolving definition is still pinned for builds/codegen via per-release `idl_digest` values and a CH-ORD ordinal manifest (RFC-0072).


### Why digest CH-IFACE (not raw IDL)
Raw IDL bytes often fail to capture the *operational* posture we care about (open vs closed, unknown-op behavior, compatibility breadcrumbs).
Digesting CH-IFACE lets us keep the on-wire identity aligned with the *policy-relevant* pins.

## RPC behavior: unknown interface/method
CH-CAPRPC v0 defines two stable framework-level error codes:
- `UNKNOWN_IFACE` (callee does not support the provided `iface_digest`)
- `UNKNOWN_METHOD` (callee supports `iface_digest` but does not implement `method_id`)

Rules:
- `method_id` assignment MUST be stable (never reused for different semantics). Tooling may pin/validate the mapping via CH-ORD (RFC-0072).
- Callee MUST NOT treat `UNKNOWN_IFACE` as a cue to “guess” an alternate interface.
- For **closed** interfaces (CH-IFACE.openness=`closed`), unknown `method_id` SHOULD fail closed (typically close the channel), unless the profile explicitly allows returning `UNKNOWN_METHOD`.
- For **open** interfaces (CH-IFACE.openness=`open`), unknown `method_id` SHOULD return `UNKNOWN_METHOD` *without side effects*.

This is “open protocol / unknown interaction handling” adapted to our CapRPC framing (compare Fuchsia’s flexible/strict guidance). (REF-FUCHSIA-RFC0138)

## Compatibility via adapters
When a change is not a monotonic extension (new optional fields, new non-effectful methods, etc.), treat compatibility as an explicit component:
- **Translator**: maps requests/responses between old and new interface digests.
- **Facade**: preserves the old interface but internally calls the new provider.
- **Shim domain**: bundles multiple translations and policy gates for legacy subsystems (e.g., a POSIX personality).

Adapters must obey the standard non-amplification rules:
- adapters cannot introduce new authority edges beyond declared routes (I-COMP-1),
- and any “fallback” decision must be transcript-visible (CH-LOG) if it affects authority.

## Upgrade-time gates (optional)
If D-ATOMICUPD is enabled, upgrade tooling can use CH-IFACE breadcrumbs (`supersedes`) to implement a simple gate:
- A deployment must not remove a required `iface_digest` while any installed component still declares/depends on it,
- unless an explicit adapter is included and routed.

This is deliberately conservative: the default is “break loudly and early”, not “paper over”.

## Evidence plan
Add an evidence seam for interface evolution:
- `EVID-2026-068`: CH-IFACE v0 schema + CapRPC unknown-op behavior tests.

Suggested tests (E0/E1):
- Interop matrix: old client vs new server (open interface) returns `UNKNOWN_METHOD` and does not close the channel.
- Closed interface negative tests: unknown `method_id` causes deterministic fail-closed behavior.
- Upgrade gate tests: removing an interface without adapter is rejected by policy tooling.

## Security notes
- “Open” does not mean “loose”: it means **explicitly specified behavior** for unknown calls.
- Never implement “try a different interface” in a generic RPC runtime. That is a classic confused-deputy footgun.
- Prefer adapters over implicit downgrade paths; adapters can be audited, routed, and revoked.

