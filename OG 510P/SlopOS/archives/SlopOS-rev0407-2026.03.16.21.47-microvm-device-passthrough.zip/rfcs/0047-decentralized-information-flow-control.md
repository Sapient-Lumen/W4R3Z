# RFC-0047: Decentralized information-flow control substrate (D-IFC)

Status: Draft  
Owner: archive  
Last updated: 2026-02-25  

Decision node(s): D-IFC

## Summary
Add an *optional* decentralized information-flow control (DIFC) substrate that can be enabled for selected objects/channels to enforce confidentiality/integrity flow constraints **in addition to** (not instead of) the capability model.

The goal is a crisp, narrow seam: labels and tag-privileges are capabilities; the kernel (or a tiny privileged monitor) enforces flow checks on a small set of primitives (IPC send/recv, shared buffer/map, and optionally file/object reads/writes) while higher policy stays in user space.

## Motivation
Capabilities answer “*who may call what*,” but do not by themselves prevent *data* from being copied into a less-trusted domain once it was legitimately obtained. If we care about privacy-style confinement (e.g., “untrusted UI code may compute with secrets but must not exfiltrate them”) or integrity-style constraints (e.g., “trusted decision code must not consume tainted inputs”), DIFC gives a ground-floor mechanism.

Why now:
- It is far cheaper to add label plumbing to **core primitives** early than to retrofit it later.
- Even if deployments never enable it, designing the seam keeps future options open and keeps us honest about observation/side-channel claims.

## Integration seam / kernel impact (keep small)
Minimum privileged mechanism if D-IFC is enabled:
1) Per-domain *current label* (secrecy + integrity) carried by the scheduler/thread context.
2) Optional *object labels* for explicitly-labeled kernel objects (channels/endpoints, shared buffers, pager-backed objects, and any designated persistent object handles).
3) A total, fail-closed `flow_ok(sender_label, receiver_label, op_kind)` check at:
   - message send/receive
   - transfer of endpoint/buffer capabilities (if we model transfer as an op)
   - map/share of buffers
   - (optional) read/write on labeled persistent objects

Everything else stays in user space:
- Tag creation policy (who is allowed to mint tags) is a user-space service.
- Human-facing policy/UIs (consent, portals) remain unchanged.
- Rich policies compile down into label/tag operations.

## Design
### 1) Labels
Each domain/process has:
- `S` (secrecy): set of tags describing what secrets it has observed.
- `I` (integrity): set of tags describing what inputs it might be influenced by.

Each labeled object may also carry `S_obj`, `I_obj` (depending on object kind).

A “tag” is an opaque identifier; the meaning of tags is local to a deployment/application.

### 2) Flow predicate (v0)
Use the conventional DIFC “can-flow-to” predicate:
- **Confidentiality:** data may flow from `A` to `B` only if `S_A ⊆ S_B` (no write-down).
- **Integrity:** data may flow from `A` to `B` only if `I_B ⊆ I_A` (no read-down / no accept higher-integrity claims from lower-integrity senders).

Combined:
`flow_ok(A,B) := (S_A ⊆ S_B) ∧ (I_B ⊆ I_A)`.

Interpretation by primitive:
- IPC send `A → endpoint → B`: enforce `flow_ok(A,B)`.
- Read object into domain: treat as `obj → domain` and enforce `flow_ok(obj, domain)`.
- Write domain into object: treat as `domain → obj` and enforce `flow_ok(domain, obj)`.

This is intentionally minimal; any richer lattice/model must compile down to this predicate or introduce a new D-IFC option with explicit evidence impact.

### 3) Tag privileges
To avoid global administrators, tag privileges are capabilities:
- For a secrecy tag `t`:
  - `t+` allows *adding* `t` to a label’s secrecy set (making it **more** restrictive).
  - `t-` allows *removing* `t` from a label’s secrecy set (declassification).
- For an integrity tag `u`:
  - `u+` allows *adding* `u` to a label’s integrity set (endorsement / claiming higher integrity).
  - `u-` allows *removing* `u` from a label’s integrity set (becoming less “trusted”).

Default rule: a domain can always make itself *more restricted* (add secrecy tags, remove integrity tags) without privilege; operations that could increase the set of allowable flows require explicit privilege tokens.

### 4) Label change operations
Expose two operations to user space (exact interface is profile-dependent):
- `GetLabel()` returns the domain’s current `(S,I)`.
- `SetLabel(new)` attempts to change the label and returns success/failure.

Validation rules (v0):
- Allowed without tag privileges:
  - add secrecy tags (`S := S ∪ Δ`)
  - remove integrity tags (`I := I \ Δ`)
- Requires corresponding privileges:
  - remove secrecy tag `t` requires `t-`
  - add integrity tag `u` requires `u+`

No other label changes are permitted.

### 5) Object labeling
We avoid labeling “everything” in v0. Only the following are labeled *when explicitly created as labeled objects*:
- endpoints/channels (especially cross-domain)
- shared buffer objects (D-IOBUF)
- pager-backed objects / memory objects (D-PAGER)
- persistent store objects if D-PERSIST is enabled

Label propagation rules:
- When a domain reads from an object, it must raise its own secrecy / lower integrity to reflect the influence (this is the classic “taint the reader” rule). Concretely:
  - On successful `read(obj → dom)`, update `S_dom := S_dom ∪ S_obj` and `I_dom := I_dom ∩ I_obj`.
- When a domain writes to an object, update the object similarly (if the object is mutable and labeled):
  - On successful `write(dom → obj)`, update `S_obj := S_obj ∪ S_dom` and `I_obj := I_obj ∩ I_dom`.

This automatic propagation can be disabled per object kind if we instead model “read/write” as transfer of labeled handles; but v0 should prefer the conventional propagation rule because it is easy to reason about and composes with existing OS abstractions (pipes/fds style).

### 6) CH-LABEL v0 (optional schema)
If D-IFC is enabled, label snapshots and tag-privilege inventories may cross trust boundaries (observability, checkpoint/restore, structured policy tooling). Pin a minimal schema:
- CH-LABEL v0: label sets, tag IDs, privilege tokens (non-secret identifiers only; any actual secrets remain as capabilities, not embedded).

See `docs/30-architecture/label-schema-v0.md`.

### 7) Interaction with other decisions
- D-CAPMODE / D-SEAL: DIFC is most useful when ambient acquisition is already blocked; otherwise exfil paths often remain.
- D-PLUMB / portals: portals can optionally attach tags to returned grants (e.g., “this file handle is secret-X”).
- IF-OBS: observation exports must be treated as an explicit sink; policy must decide which labels may be exported and under what declassification authority.
- D-SIDECH: DIFC does not address covert channels; it only constrains explicit flows. We keep timing/microarchitectural channels as non-claims unless modeled.

## Registries impacted
- CH: add CH-LABEL v0 to the schema registry.
- REF: add REF-FLUME-SOSP07 and REF-ASBESTOS-SOSP05 (and optionally a Flume noninterference follow-up).
- RFC index: add RFC-0047 to `rfcs/README.md`.

No new Claims are introduced; this RFC fleshes out the existing C-IFC-1 / <I-IFC-*> / PO-IFC-STEP seam.

## Threat-model impact
If enabled, DIFC expands what we can *meaningfully* claim about data-flow constraints, but also adds:
- a new correctness surface (flow checks + label propagation)
- potential denial-of-service vectors (label growth, tag cardinality)

We keep scope explicit:
- DIFC does not prevent covert channels.
- DIFC does not “fix” a compromised declassifier/endorser; it makes such boundaries explicit and testable.

## Assurance/verification impact
Maps to the existing IFC claim/invariants:
- C-IFC-1 (scoped)
- I-IFC-1/I-IFC-2
- PO-IFC-STEP

Evidence plan should emphasize:
- definitional model of label flow and propagation
- differential tests between model and implementation (D-DRT pattern)
- bounded fuzzing of label/privilege changes + IPC behaviors

## Observability / operations impact
If CH-LABEL is used:
- IF-OBS may export *redacted* label snapshots for debugging (counts, tag IDs hashed/salted per policy) without exporting secrets.
- checkpoint/restore (D-CHKPT) may include label snapshots to preserve flow state.

All exports must respect the observation redaction posture (I-OBS-1).

## Alternatives
1) **Capabilities-only (no DIFC)**
   - Pro: zero complexity.
   - Con: cannot state or enforce “no exfil” style properties; privacy confinement remains ad-hoc.

2) **Mandatory access control (SELinux-style)**
   - Pro: familiar; centralized.
   - Con: tends to become a giant policy surface; hard to keep deterministic/portable; does not naturally encode taint/influence.

3) **Language-level IFC only**
   - Pro: can be very strong in a single language.
   - Con: does not cover polyglot components and OS abstractions; cannot constrain IPC/file descriptors without OS support.

4) **User-space reference monitor only** (à la “IFC in a library”)
   - Pro: smaller kernel change.
   - Con: hard to make complete at IPC/map boundaries without kernel hooks; easier to bypass via unchecked sharing primitives.

## Evidence plan
E1 (prototype):
- Implement label objects for one primitive (channels) and show non-bypass under capmode.
- Negative tests: send from high-secret to low-secret fails; integrity direction fails.

E2 (model + DRT):
- Definitional interpreter for a tiny labeled-IPC machine.
- Differential randomized tests against implementation for: flow_ok, propagation, privilege rules.

E3 (optional mechanization):
- Mechanize PO-IFC-STEP for the chosen primitive subset.

## Open questions
- Tag cardinality limits and GC policy (per-domain bound; per-object bound; failure mode).
- Whether object-label propagation should be mandatory for all labeled object kinds or per-kind.
- How to represent “trusted declassifier” patterns cleanly with constructors + membranes.

## Tightening (2026-02-25): IFC-lite adoption patterns + quarantine interop

This archive already uses **quarantine** (D-QUAR) and **explicit export policy** (D-OBSPOL) to reduce accidental data release.
D-IFC becomes much more adoptable if we treat it as an *overlay* on those flows first, rather than a full-system label explosion.

Recommended IFC-lite sequence:

1) **Treat export surfaces as sinks**:
   - IF-OBS export (CH-OBS / CH-SNAPSHOT) is a sink.
   - Any portal-mediated export (clipboard, file export, network lease issuance) is a sink.
   For IFC-lite, start by labeling these sinks and enforcing `flow_ok(dom, sink)`.

2) **Make declassification/endorsement explicit and transcript-visible**:
   - Tag-removal privileges (`t-`) and integrity-raising privileges (`u+`) are the *only* way to reduce secrecy / increase integrity.
   - Any successful declassify/endorse MUST emit a transcript record (CH-LOG) and be auditable.
   - Any policy/UI-mediated “clear quarantine” action should compile down into a declassify operation.

3) **Quarantine as a first-class tag (interop, optional)**:
   - D-QUAR can be represented as a conventional secrecy tag (e.g., `quarantine`) in deployments that enable D-IFC.
   - “Clear quarantine” becomes “remove `quarantine` tag” under an explicit `quarantine-` privilege minted only by trusted workflows (portals + consent).
   - This keeps quarantine propagation semantics consistent across copy/extract/derive and avoids a parallel, bespoke mechanism.

This sequence yields useful properties early:
- “untrusted code can read quarantined content but cannot export it” becomes a checkable flow constraint,
- and quarantine clear becomes an explicit, testable declassification boundary.

## Security / abuse cases
Add:
- **AC-072 (Label laundering / confused-declassifier)**: a component (or wrapper) removes secrecy tags or adds integrity tags without holding the required privilege capability, or a privileged declassifier is tricked into acting as a confused deputy.

Mitigations:
- require I-IFC-1/I-IFC-2 and add I-IFC-3 (explicit declassify/endorse authority)
- deny-by-default on label changes that widen flows
- transcript visibility (I-LOG-1) for successful label-lowering / integrity-raising operations

## Assurance wiring
This RFC strengthens the IFC seam with an explicit “declassify/endorse” hook:
- add **I-IFC-3 (Declassify/endorse requires explicit authority, optional)**
- add **PO-IFC-DECLASS (No unauthorized label lowering/raising)**

Evidence seed:
- **EVID-2026-082**: D-IFC differential-test harness plan (model vs implementation) for:
  - `flow_ok` checks on one labeled primitive (IPC endpoints) and one sink (IF-OBS export)
  - privilege-checked label changes (attempt tag removal / integrity-add without privileges must fail)
  - quarantine-as-tag integration tests (clear requires privilege + consent transcript)
