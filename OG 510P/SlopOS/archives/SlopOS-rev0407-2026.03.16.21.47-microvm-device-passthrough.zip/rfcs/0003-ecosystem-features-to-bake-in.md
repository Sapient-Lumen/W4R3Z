# RFC-0003: Ecosystem features to bake in early (candidate list)

Status: Draft  
Owner: archive  
Last updated: 2026-02-27

Goal: capture “brilliant but under-adopted” OS ideas that fit our discipline (spec-first, bounded surfaces, explicit invariants, evidence-tracked) and decide which are worth *designing for* now (even if implemented later).

Non-goal: committing to features that expand TCB or explode the abstract machine. Each item here must map to a D-* node and have a minimal “integration seam.”

## 1) Init → seal authority narrowing (OpenBSD pledge/unveil pattern)
- Summary: services often need broad authority during setup and little in steady state; make “seal down” explicit and one-way.
- Candidate decision: D-SEAL.
- Minimal seam:
  - View objects become lockable in steady state (no new mappings after lock) or are replaced with a narrower view.
  - Service-specific “promises” are modeled as capability attenuation + explicit interface disablement.
- Invariants / POs:
  - I-SEAL-1, I-CAP-1, I-VIEW-2.
  - PO-SEAL-ONEWAY.
- Evidence plan: E1 tests on a prototype service demonstrating post-init authority cannot be regained; AC-010 pressure test.
- References: REF-OPENBSD-PLEDGE, REF-OPENBSD-UNVEIL, REF-LWN-UNVEIL.

## 1e) Promise learning mode + drift gates (make narrowing adoptable)
- Summary: sandboxing mechanisms fail when authoring is too expensive. Bake in a low-ceremony **learn mode** for CH-PLEDGE so teams can iterate toward minimal steady-state promises.
- Candidate decision: D-SEAL (CH-PLEDGE).
- Minimal seam:
  - Use `violation = "deny"` as a complain/learn profile.
  - Require deterministic violation records (denied effect kind + pledge digest) so tooling can suggest tokens.
  - CI guard: if `seal_after_init` is set, fail if the post-seal action stream uses effect kinds outside the promised set.
- Evidence plan: a harness that runs representative workloads under learn mode and emits a stable “required token set” report; regression tests that tightening tokens causes deterministic failures.
- References: REF-THREADBOX-ARXIV25, REF-SERENITY-PLEDGEUNVEIL, REF-OPENBSD-PLEDGE.


## 1f) Survivable update repository metadata (TUF/Uptane pattern)
- Summary: signed CH-UPD is necessary, but long-lived deployments need a distribution protocol that detects **freeze/rollback/mix-and-match** and supports **key compromise recovery** without bricking fleets.
- Candidate decision: D-TUF (see RFC-0079).
- Minimal seam:
  - Keep the kernel unaware: TUF metadata lives entirely in the updater/repo tooling.
  - Publish CH-UPD objects as “targets” (digest-addressed) and stage atomic deployments per D-ATOMICUPD.
  - Pin the initial trust anchor (root metadata digest or root key bundle) out of band (install media / provisioning), and record it for audit.
- Invariants / POs:
  - I-TUF-1, I-TIME-1; PO-TUF-VERIFY; AC-067.
- Evidence plan: EVID-2026-077 rotation drill harness (timestamp/targets compromise) + expiry/staleness negative tests.
- References: REF-TUF-SPEC, REF-TUF-METADATA, REF-UPTANE-STANDARD2, REF-UPTANE-BESTPRACTICES, REF-PEP-480.


## 1g) Declarative configuration compilation + generations (Nix/NixOS pattern)
- Summary: config changes become auditable and rollback becomes routine when privileged config is the deterministic *output* of a config compiler, and each evaluation produces a selectable “generation.”
- Candidate decisions: no new kernel mechanism; posture for IF-CFG + D-ATOMICUPD + D-EXPLAIN.
- Minimal seam:
  - Treat CH-CFG as compiled output (canonical CBOR) and keep the privileged core to decode→validate→apply.
  - Maintain a user-space generations store keyed by CH-CFG digest; bind active `cfg_digest` in CH-BOOT.
  - For authority-widening config changes: require D-EXPLAIN diffs/receipts (CH-CAPDIFF + CH-RECEIPT).
  - For boot-critical changes: stage as pending with bounded tries (CH-BOOTSEL) and commit only after health success.
- Evidence plan:
  - deterministic compilation golden tests (same inputs → same CH-CFG bytes)
  - negative tests: reject unknown/invalid policy keys; reject authority-widening config applies without receipts
  - rollback tests: selecting prior config generations is deterministic and non-amplifying
- References: REF-NIXOS-MANUAL, REF-NIX-MANUAL-ROLLBACK, REF-NIXOS-JFP10.

## 1h) Measured boot event logs as pinned evidence (TCG/systemd/IMA pattern)
- Summary: measured boot is only verifiable if event logs are available to replay PCR extensions; standardize a bounded CH-MEASLOG artifact and bind it into CH-BOOT.
- Candidate decisions: D-BOOT (measured branch), D-AREF (optional), D-ATTEST (optional).
- Minimal seam:
  - Tooling extracts platform-native logs (e.g., UEFI event log) and emits CH-MEASLOG; IF-BOOT only validates/binds it.
  - CH-BOOT references `digest(CH-MEASLOG)` via `measurements` and/or lists it in `artifacts` (role `meas_log`).
  - Selected events may carry `ref { role, digest }` bindings to CH-BOOT artifacts to make key measurements mechanically checkable.
- Invariants / POs:
  - I-MEASLOG-1; PO-MEASLOG-VALIDATE.
- Evidence plan: EVID-2026-086 validator tests; later replay-to-PCR harness for the chosen platform profile.
- References: REF-TCG-EFI-PLATFORM, REF-TCG-PC-CLIENT-PFP, REF-TCG-IMELP, REF-SYSTEMD-PCR-MEASURE, REF-LINUX-IMA-TEMPLATES.


## 1i) Preforked “template spawners” for cheap sandboxes (Android/Chromium zygote pattern)
- Summary: disposable sandboxes only become a default user habit if they are **fast** and **cheap**. A widely deployed solution is a long-lived “zygote” that performs expensive setup once, then forks/clones on demand to produce new isolated children that share read-only pages.
- Candidate decisions: D-EPHEM (primary), with optional accelerators via D-INITSNAP and/or D-CHKPT.
- Minimal seam:
  - Define a *user-space* template spawner service that owns one or more warmed templates (per ABI/profile).
  - Spawn children via fork/clone or snapshot-restore, then immediately apply: view install → route install → seal/capmode (D-SEAL/D-CAPMODE).
  - Treat the template process/image as **tainted authority**: keep it minimal, do not give it ambient introducers, and ensure post-fork narrowing is one-way.
  - Prefer “templates as artifacts”: templates are identified by digests (CH-INIT or CH-CKPT), bound in CH-BOOT/CH-CFG, and selectable by policy.
- Evidence plan:
  - microbench: cold spawn vs warm spawn latency + steady-state RSS sharing benefits
  - negative tests: verify no authority amplification from template inheritance; verify disposable reset (PO-EPHEM-RESET)
- References: REF-ANDROID-ZYGOTE, REF-ANDROID-MEMORY-OVERVIEW, REF-CHROMIUM-ZYGOTE.


## 1j) Authenticated time bootstrap + verifiable time proofs (Roughtime/NTS pattern)
- Summary: lots of security machinery assumes credible time (expiry, cert validity), but many devices boot without a trustworthy RTC and hostile networks make unauthenticated NTP an attack surface. Bake in a *user-space* time portal that can bootstrap from signed time samples and optionally provide bounded proof artifacts for audit.
- Candidate decisions: D-TIME (security time source) + D-TIMEPROOF (see RFC-0090) + D-NONDET (explicit clock handles).
- Minimal seam:
  - Keep privileged checks on a monotonic source (I-TIME-1); maintain a monotonic, non-decreasing “secure wall time” lower bound for expiry decisions.
  - Time portal can use Roughtime for bootstrap (signed `(midpoint, radius)` plus misbehavior evidence) and NTS-secured NTP for steady-state discipline.
  - Emit CH-TIMEPROOF receipts as bounded evidence; treat export as CH-OBSPOL scoped metadata (not authority).
- Invariants / POs:
  - I-TIMEPROOF-1/I-TIMEPROOF-2; PO-TIMEPROOF-VALIDATE/PO-TIMEPROOF-VERIFY/PO-TIMEPROOF-APPLY; AC-077.
- Evidence plan: EVID-2026-088 validator + verification golden tests + monotonic-apply negative tests (reject backward time; reject unreasonable jumps without explicit override).
- References: REF-ROUGHTIME-PROTOCOL, REF-ROUGHTIME-IETF, REF-RFC-8915, REF-CHRONY-NTS.




## 1k) SBOM inventory artifacts + subject binding (SPDX/CycloneDX + NTIA/CISA guidance)
- Summary: SBOMs only help if they are mechanically bound to what actually shipped/ran. Bake in a small, digest-bound inventory artifact (CH-SBOM) that can be attached to releases/boots, and optionally link to full SPDX/CycloneDX docs via CH-AREF.
- Candidate decision: D-SBOM (see RFC-0091).
- Minimal seam:
  - Standardize CH-SBOM v0 (bounded inventory) with `subject.digest` set to the deployment root digest (or component digest).
  - Reference it from CH-UPD/CH-BOOT `artifacts[]` with `role = "sbom"`.
  - Enforce subject binding in tooling/verification: reject mismatched SBOMs (I-SBOM-1).
  - Keep exports policy-scoped (CH-OBSPOL): allow redaction or forbidding external SBOM doc exports.
- Invariants / POs:
  - I-SBOM-1, I-SBOM-2.
  - PO-SBOM-VALIDATE, PO-SBOM-BIND.
- Evidence plan: EVID-2026-089 validator + binder negative tests (bounds, subject mismatch) + export redaction tier tests; AC-078.
- References: REF-NTIA-SBOM-MIN2021, REF-CISA-SBOM-MIN2025, REF-SPDX-SPECS, REF-CYCLONEDX-OVERVIEW, REF-CISA-VEX-MINREQ.



## 1l) VEX exploitability statements as pinned, digest-bound evidence (OpenVEX/CSAF/CycloneDX complement)
- Summary: scanners produce false positives and context-dependent findings. Bake in a small, digest-bound VEX artifact (CH-VEX) so “not affected / fixed / under investigation” statements are **reviewable, exportable, and bound to what actually shipped/ran**.
- Candidate decision: D-VEX (see RFC-0092).
- Minimal seam:
  - Standardize CH-VEX v0 (bounded statements) with `subject.digest` set to the deployment root digest (or component digest).
  - Reference it from CH-UPD/CH-BOOT `artifacts[]` with `role = "vex"`.
  - Enforce subject binding in tooling/verification: reject mismatched VEX artifacts (I-VEX-1).
  - Keep exports policy-scoped (CH-OBSPOL): allow redaction of component identifiers; link to full OpenVEX/CSAF/CycloneDX docs via CH-AREF when needed.
  - Treat VEX as **evidence**, not authority: it must not grant privilege or silently bypass update gates.
- Invariants / POs:
  - I-VEX-1, I-VEX-2.
  - PO-VEX-VALIDATE, PO-VEX-BIND.
- Evidence plan: EVID-2026-090 validator + binder negative tests (bounds, enum closure, subject mismatch) + export redaction tier tests; AC-079.
- References: REF-CISA-VEX-MINREQ, REF-OPENVEX-SPEC, REF-OPENVEX-REL, REF-CSAF-ISO.

## 1m) Media capture portals + session descriptors (PipeWire/portal pattern)
- Summary: camera/microphone/screencast/remote-desktop are high-risk authorities. Avoid ambient capture via static sockets or global readback; make capture an explicit, revocable portal session with bounded leases and auditable descriptors.
- Candidate decisions: D-CAPTURE (RFC-0095) as an adjunct to D-UICAP + D-PLUMB + D-LEASE.
- Minimal seam:
  - A user-space capture portal mediates capture requests and returns leased capture endpoints (short TTL, explicit renew).
  - Emit a bounded **CH-CAPTURE v0** descriptor (no media bytes/paths) for each session; log/receipt by digest.
  - Require user-visible indicators in strict profiles; scope escalation and renew require fresh consent/volition.
  - Keep media graph and routing policy in user space (PipeWire-style session manager split).
- Invariants / POs:
  - I-CAPTURE-1/I-CAPTURE-2; PO-CAPTURE-VALIDATE; AC-082.
- Evidence plan: EVID-2026-093 harness plan (no ambient capture; TTL/renew/escalation; indicator discipline; export redaction via CH-OBSPOL).
- References: REF-PIPEWIRE-ACCESS, REF-PIPEWIRE-SESSMGR, REF-XDG-PORTAL-SCREENCAST, REF-XDG-PORTAL-REMOTEDESKTOP, REF-XDG-PORTAL-CAMERA, REF-XDG-PORTAL-AUDIO-ISSUE.

## 1n) Constraint-based background jobs via a job portal (Android/iOS/systemd pattern)
- Summary: background work becomes a power/privacy footgun when apps can set precise alarms or run always-on daemons. Bake in a **constraint-based job scheduler**: apps declare intent + constraints and the system coalesces execution under load/power constraints.
- Candidate decisions: D-JOBS (RFC-0096) plus D-TCAP (runtime bounds), D-PRESSURE (deferral), D-ACTIVATE (trigger via activation), D-NETLEASE (no implicit net), and optional D-PERSIST for durable schedules.
- Minimal seam:
  - A user-space job portal accepts bounded requests and issues a cancellable job ticket capability.
  - Emit a bounded **CH-JOBREQ v0** descriptor (no capability material) for audit/receipts.
  - Enforce minimum periods + flex windows; do not promise exact timestamps; coalesce under pressure.
  - Enforce per-run runtime bounds (wall-time + optional TCaps).
- Invariants / POs:
  - I-JOB-1, I-JOB-2.
  - PO-JOBREQ-VALIDATE, PO-JOBS-ENF.
  - AC-083.
- Evidence plan: EVID-2026-094 job-portal harness plan (no ambient alarms; constraint gating; cancellation; runtime bounds; export redaction via CH-OBSPOL).
- References: REF-ANDROID-JOBINFO, REF-ANDROID-WORKMANAGER, REF-APPLE-BGTASKS, REF-APPLE-BGTASK-EARLIEST, REF-SYSTEMD-TIMER.


## 1n1) Background execution + autostart as leased portal grants (XDG portal/Android/Apple pattern)
- Summary: beyond scheduled jobs, some apps want to keep running invisibly or relaunch automatically. That quickly becomes ambient persistence (spyware/miners), battery drain, and UX trust failure. Bake in an explicit **background portal** so background/autostart are visible, bounded, and revocable, not ad-hoc daemons.
- Candidate decisions: **D-BGLEASE** (RFC-0103) as an adjunct to D-LEASE and D-PLUMB; composes with D-JOBS (prefer jobs for deferrable work).
- Minimal seam:
  - `portal.background.*` mediates requests for (a) background execution and (b) login autostart.
  - Requests carry a bounded user-visible `reason` and optional short `status_message`.
  - The portal returns an explicit BackgroundLease handle; closing/expiry revokes background permission deterministically.
  - Emit a bounded **CH-BGLEASE v0** descriptor (no capability material) for audit/receipts; strict profiles default to redacted exports under CH-OBSPOL.
  - Policy clamps TTL and renewal cadence; `autostart` is revocable and may require stronger approval/volition.
- Invariants / POs:
  - I-BGLEASE-1..3; PO-BGLEASE-VALIDATE/PO-BGLEASE-ENF; AC-088.
- Evidence plan: **EVID-2026-106** schema validator + portal harness plan (deny-by-default; TTL/renew clamps; indicators/status; no implicit net).
- References: REF-XDG-PORTAL-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-ANDROID-FGS-RESTRICTIONS, REF-APPLE-BG-MODES.

## 1n2) Inhibit/keep-awake as leased portal workflows (systemd inhibitor locks/XDG portal/wake locks)
- Summary: preventing idle/suspend/logout/shutdown is a powerful authority that can be abused for battery drain and availability attacks. Bake in an explicit **inhibit portal** so keep-awake behavior is bounded, visible, and auditable, not an ambient API.
- Candidate decisions: **D-INHIBITLEASE** (RFC-0102) as an adjunct to D-LEASE and D-PLUMB; integrates with D-JOBS for short, job-scoped inhibits.
- Minimal seam:
  - `portal.inhibit.*` mediates inhibition requests and returns an inhibition lease handle (close-to-release).
  - Emit a bounded **CH-INHIBITLEASE v0** descriptor (no capability material) for audit/receipts.
  - Default posture: untrusted apps get `delay` inhibits with TTL/grace clamps; `block` inhibits are reserved for allowlisted system components (e.g., update transactions) under policy.
  - Long-lived inhibits imply non-spoofable UI indicators; strict profiles may require consent/volition binding.
- Invariants / POs:
  - I-INHIBIT-1..3; PO-INHIBIT-VALIDATE/PO-INHIBIT-ENF; AC-087.
- Evidence plan: **EVID-2026-105** schema validator + portal harness plan (TTL/renew clamp; no ambient inhibits; block denied for apps; indicator/consent posture).
- References: REF-XDG-PORTAL-INHIBIT, REF-SYSTEMD-INHIBITOR-LOCKS, REF-SYSTEMD-INHIBIT-MAN, REF-ANDROID-WAKELOCK, REF-ANDROID-SET-WAKELOCK.

## 1n3) Application secret seeds via a secret portal (avoid ambient keyrings)
- Summary: many sandboxed apps need a small stable secret seed to encrypt local state. Without a minimal primitive, ecosystems drift into ad hoc files, global keyrings with confusing boundaries, or hardcoded credentials. Bake in a small `portal.secret` workflow so app secrets are explicit, bounded, and auditable.
- Candidate decisions: **D-APPSECRET** (RFC-0104) as an adjunct to D-PLUMB; composes with D-CRYPTOSVC (optional handle-only profile) and is distinct from full secret storage/sharing (D-VAULT).
- Minimal seam:
  - `portal.secret.*` mediates requests for per-application secret seeds under explicit scope (`profile`/`user`/`device`) and bounded parameters.
  - The portal returns either raw bytes (baseline) or a non-exportable seed handle (stricter profile).
  - Emit a bounded **CH-APPSECRET v0** descriptor (no secret bytes) for audit/receipts; strict profiles default to redacted exports under CH-OBSPOL.
  - Rotation is explicit and policy-gated; epoch bumps are transcript-visible.
- Invariants / POs:
  - I-APPSECRET-1..3; PO-APPSECRET-VALIDATE/PO-APPSECRET-ENF; AC-089.
- Evidence plan: **EVID-2026-107** schema validator + portal harness plan (per-app isolation; scope semantics; rotation gating; no secret bytes in transcripts).
- References: REF-XDG-PORTAL-SECRET, REF-ANDROID-KEYSTORE, REF-ANDROID-KEYATTEST, REF-SECRET-SERVICE-SPEC.
## 1o) Trusted path entry + secure input sessions (SAS + secure keyboard entry)
- Summary: users need a spoof-resistant way to “talk to the OS” for login and high-risk approvals (fake login/consent UIs are a perennial attack). Additionally, sensitive entry should be able to suppress global key taps to reduce keylogging/automation risk.
- Candidate decisions: D-UICAP + D-VOLITION (secure-attention entry; secure UI mode), D-LEASE (secure input as a lease).
- Minimal seam:
  - Reserve a Secure Attention Sequence (SAS) delivered only to the secure UI component; entering secure UI mode occludes normal surfaces and denies capture/injection by default.
  - Provide an optional `SecureInputLease` assertion (TTL + explicit release) that suppresses non-authorized keyboard interception during sensitive entry.
  - Ensure visibility + recovery: indicator when active; deterministic “stuck secure input” recovery path.
- Invariants / POs:
  - I-UICAP-2, I-SAS-1.
  - PO-UICAP-FOCUS, PO-SAS-DELIVER.
- Evidence plan: **EVID-2026-095** integration harness (secure desktop entry + secure input TTL/expiry; non-authorized global tap suppression).
- References: REF-MS-WINLOGON-SAS, REF-IBM-AIX-TRUSTEDPATH, REF-APPLE-TN2150-SECEVENTINPUT, REF-FUCHSIA-FOCUSCHAIN.

## 1p) Accessibility/automation as leased, audited sessions (avoid ambient global hooks)
- Summary: assistive tooling and UI automation are valuable, but “global accessibility hooks” are a common malware channel. Bake in a seam where observation/injection are explicit, scoped, leased, and visibly indicated.
- Candidate decisions: **D-UIAUT** (RFC-0099) as an adjunct to **D-UICAP**, plus D-LEASE and D-PLUMB.
- Minimal seam:
  - `portal.a11y.*` mediates grants and returns capability handles; defaults to observation-only.
  - Injection/remote-control requires explicit policy gates + TTL leases + shell-driven indicators.
  - Emit a bounded **CH-UIAUT v0** descriptor (no UI text/titles) for audit/receipts.
- Invariants / POs:
  - I-UIAUT-1..3; PO-UIAUT-VALIDATE/PO-UIAUT-ENF; AC-084.
- Evidence plan: **EVID-2026-101** harness plan (no ambient hooks; observe≠inject; TTL expiry/revoke determinism; indicator non-spoof).
- References: REF-ANDROID-ACCESSIBILITYSERVICE, REF-APPLE-ACCESSIBILITY-TRUST, REF-WIN-UIACCESS.

## 1c) No ambient authority acquisition (Capsicum / CloudABI / WASI pattern)
- Summary: capability systems fail in practice when “open-by-path”, “connect-by-name”, or other ambient acquisition APIs creep back in.
- Candidate decision: D-CAPMODE (see RFC-0010).
- Minimal seam:
  - Keep name resolution inside explicit view objects (I-VIEW-1/I-VIEW-2).
  - Optional per-domain `capmode` switch that forbids `Acquire*` authority actions after init.
- Invariants / POs:
  - I-CAPMODE-1, I-VIEW-1.
  - PO-CAPMODE-ONEWAY.
- Evidence plan: treat AC-008 as the primary pressure test; E1 negative tests for “no ambient fallback”.
- References: REF-CAPSICUM, REF-CLOUDABI, REF-WASI-DESIGN.

## 1b) Manifested component graph + capability routing (Fuchsia/Genode/Singularity)
- Summary: make “what runs + who can access what” an explicit, signed artifact (CH-COMP) so composition can be audited, linted, and fail-closed.
- Candidate decision: D-COMP (see RFC-0009).
- Minimal seam:
  - User-space init/component manager consumes CH-COMP and performs only declared routes.
  - CH-COMP digest is listed in CH-BOOT `artifacts` when used (role = `comp_manifest`).
- Invariants / POs:
  - I-COMP-1, I-COMP-2.
  - PO-COMP-VALIDATE, PO-COMP-BIND.
- Evidence plan: implement a tiny router + validator and pressure-test “no undeclared routes” + “seal-after-init cannot regain routes.”
- References: REF-FUCHSIA-COMPONENTS, REF-FUCHSIA-CML, REF-GENODE-INIT, REF-SING-OSR07.

## 1d) Decentralized information-flow control (HiStar/Flume/Asbestos line)
- Summary: capabilities control *invocation*; DIFC additionally constrains *data flow* (confidentiality/integrity) across IPC, shared memory, and (optionally) persistent objects.
- Candidate decision: D-IFC (see RFC-0047).
- Minimal seam:
  - Per-domain labels + fail-closed flow checks on a tiny primitive subset (IPC + buffer sharing first).
  - Tag privileges are capabilities; tag meaning stays in user space.
  - Keep scope explicit: labeled subset only; covert channels remain non-claims unless D-SIDECH is modeled.
- Invariants / POs:
  - I-IFC-1, I-IFC-2.
  - PO-IFC-STEP.
- Evidence plan: D-DRT style differential tests between a tiny definitional model and implementation on the labeled subset; negative tests for bypass.
- References: REF-HISTAR-SOSP06, REF-FLUME-SOSP07, REF-ASBESTOS-SOSP05.

## 2) Capability-mediated resource meters / quotas (KeyKOS)
- Summary: make resource allocation/consumption explicit, attributable, and delegable via capabilities.
- Candidate decision: D-METER.
- Minimal seam:
  - Introduce a “meter object” type that grants/charges resources (CPU budget, memory pages, I/O credits) via explicit ops.
  - Keep the core small by scoping to one resource first (e.g., pages) and deferring “global fairness.”
- Invariants / POs:
  - I-METER-1.
  - PO-METER-CHARGE.
- Evidence plan: E1 “cannot allocate without meter” tests; later E2 model check on a tiny allocation automaton.
- References: REF-KEYKOS-NANOKERNEL, REF-EROS-FAST.

## 2a) Pressure + backpressure signals (PSI / Fuchsia pressure)
Quotas answer “how much?”, but overload failures are dynamic. Bake in a small, scoped pressure signal seam so user space can implement load shedding/caching/admission control without privileged policy growth.
Maps to: D-PRESSURE; see RFC-0057.

## 2b) Operation-scoped budget leases (“who pays?” tokens)
Avoid implicit sponsorship and confused-deputy billing by making the payer an explicit parameter: budget leases minted from meters and attached to effectful calls (especially portal workflows).
Maps to: D-BUDGET; see RFC-0058.

## 2c) Application-level resource management (Exokernel/Nemesis line)
- Summary: keep the privileged core focused on **protection + multiplexing**, and push most policy choices (admission control, caching, QoS, paging strategy) into unprivileged runtimes/services.
- Candidate decisions: D-METER, D-BUDGET, D-PRESSURE; optional D-PAGER and/or D-UPCALL if evidence shows we need tighter app-level control loops.
- Minimal seam:
  - Meters + budget leases make the payer explicit and prevent “implicit sponsorship.”
  - Pressure signals give user space a coarse, authorized backpressure channel (instead of in-kernel heuristics).
  - If paging policy needs to vary (compression, encryption, prefetch), keep it behind a user-mode pager seam with bounded messages.
- Evidence plan: reuse the D-METER/D-PRESSURE/D-PAGER harness plans already seeded in their RFCs; prefer mechanistic, deterministic tests over “fairness” claims.
- References: REF-EXOKERNEL-SOSP95, REF-NEMESIS, REF-NEMESIS-SELFPAGING, REF-MACH-EXTPAGER.

## 3) Constructors + confinement tests (EROS)
- Summary: build components from explicit authority and prove the construction step cannot leak unintended authority.
- Candidate decision: D-CONSTR.
- Minimal seam:
  - Treat “constructor” as an object that, given a set of input caps, produces a sealed service/domain with a declared exported interface.
  - Confinement test is a *spec artifact* first: a predicate over the constructed capability graph.
- Invariants / POs:
  - Reuse I-CAP-1 and I-STATE-1; constructor-specific invariants should be introduced only if this becomes a real mechanism.
- Evidence plan: E2 bounded model check of the confinement predicate on small graphs; expand only if it proves valuable.
- References: REF-EROS-CONFINEMENT, REF-EROS-FAST.

## 4) Copyless buffer objects (IO-Lite style)
- Summary: avoid redundant copies by making shared buffering/caching explicit objects with safe sharing semantics.
- Candidate decision: D-IOBUF.
- Minimal seam:
  - Introduce an immutable buffer object (or explicit ownership-transfer buffer) as an explicit shared region object.
  - Keep IPC default as bounded-copy; enable buffer objects only where needed.
- Invariants / POs:
  - I-IOBUF-1, I-SHARE-1.
  - PO-IOBUF-OWNERSHIP.
- Evidence plan: E2 negative tests/fuzzing of aliasing/ownership rules; performance evidence only after semantics are pinned.
- References: REF-IO-LITE.

## 5) Kernel→user upcalls for scheduling (scheduler activations)
- Summary: small upcall surfaces can avoid in-kernel scheduling policy growth.
- Candidate decision: D-UPCALL.
- Minimal seam:
  - Treat upcalls as a *declared interface* (IF-*) with a tiny closed set of events.
  - Keep Phase 1 deterministic scheduling unless/until evidence demands more.
- Invariants / POs:
  - Must not expand concurrency claims without an explicit D-CONC/D-MEMMODEL step.
- Evidence plan: stay speculative until Phase 3 unless SMP becomes a primary requirement.
- References: REF-SCHED-ACTIVATIONS.

## 6) Deterministic replay profiles (rr / VM replay)
- Summary: record/replay improves debugging and can strengthen evidence by making privileged effects reproducible within a declared nondeterminism boundary.
- Candidate decision: D-RR.
- Minimal seam:
  - Treat CH-KABI + CH-LOG as the privileged action stream; record nondeterministic inputs explicitly (time, interrupts, device events) for the enabled profile.
  - Keep replay a *profile feature* (not a universal claim).
- Invariants / POs:
  - I-LOG-1, I-ENC-1.
  - I-RR-1, PO-RR-DETERMINISM.
- Evidence plan: E2 replay harness on a small action trace; AC-011 pressure test.
- References: REF-RR-ATC17, REF-VM-REPLAY-VEE16.


## 6c) Time-travel debugging and "search through time" (TTD / Pernosco / FReD)
- Summary: reverse execution is good; *queryable replays* are better. Treat time-travel debugging (step back, dataflow backtraces, bisection through a run) as an **ecosystem target** layered over our pinned replay boundary, not as a privileged feature.
- Candidate decisions: D-RR + D-CHKPT (optional), with D-NONDET eliminating ambient time/entropy so replay inputs are explicit.
- Minimal seam:
  - Make replays shareable (CH-RRBUNDLE) and canonically encoded (D-ENC) so third-party tools can build indexing/query layers without privileged hooks.
  - Encourage optional checkpoint snapshots for large traces (D-CHKPT) so reverse queries can be fast without huge logs.
  - Keep the kernel posture simple: stable action boundary + explicit nondeterminism providers; everything else is user space.
- Evidence plan: demonstrate a small "attach-a-replay" workflow in CI (record → reproduce → minimize) and use it for at least one flaky property test.
- References: REF-TTD-MS, REF-PERNOSCO-DATAFLOW, REF-FRED-ARXIV12, REF-RR-QUEUE20.


## 6d) Crash capsules with stable symbolization (Crashpad/minidump + build-id/debuginfod patterns)
- Summary: bug reports become dramatically more actionable when crash artifacts are *bounded*, *standardized*, and *symbolizable* by content identity (build IDs) rather than paths.
- Candidate decisions: D-INSPECT (CH-CRASHCAP adjunct) + D-OBS/D-OBSPOL + D-FPM (debug artifact store); D-RR optional escalation.
- Minimal seam:
  - Standardize CH-CRASHCAP: bind env digests (boot/cfg/comp) + module build IDs and reference bounded payloads (log/trace/inspect windows, optional dump).
  - Prefer minidump-style dumps where possible (compact + tool-friendly); keep dumps opaque and policy-gated.
  - Store debuginfo in a content-addressed store; optional debuginfod-like fetch service gated by export policy.
- Evidence plan: produce a capsule for a synthetic crash and automatically symbolize it end-to-end using only build IDs + the debug store (no source tree paths).
- References: REF-CRASHPAD-OVERVIEW, REF-MS-MINIDUMP-FILES, REF-ELF-BUILDID, REF-DEBUGINFOD, REF-SYSTEMD-COREDUMP-MAN.

## 6e) On-device triage rules (Fuchsia triage / alert-rule posture)
- Summary: incident workflows improve when "what to collect" is expressed as a **bounded, testable rule set** over structured diagnostics, rather than ad-hoc scripts and "attach a full bugreport" habits.
- Candidate decision: D-TRIAGE (see RFC-0087).
- Minimal seam:
  - CH-TRIAGE v0 rule sets evaluate over CH-INSPECT and/or CH-CRASHCAP and emit bounded findings + advisory snapshot requests (entry kinds + tier).
  - Export tooling MUST still enforce CH-OBSPOL allowlists/bounds and capability gates; triage cannot widen authority.
- Invariants / POs:
  - I-TRIAGE-1/I-TRIAGE-2; PO-TRIAGE-VALIDATE/PO-TRIAGE-EVAL; AC-075.
- Evidence plan: golden tests (fixed inputs → stable findings), and negative tests where triage requests exceeding CH-OBSPOL are rejected deterministically.
- References: REF-FUCHSIA-TRIAGE, REF-PROMETHEUS-ALERT-RULES.

## 6b) Failpoints + fault injection as a first-class seam (FreeBSD/Linux/Jepsen)
- Summary: most robustness failures are “unhappy path” bugs (alloc failure, timeouts, drops). Bake in a deterministic, bounded fault-injection seam so we can continuously test failure handling.
- Candidate decision: D-FAILPOINT (see RFC-0048).
- Minimal seam:
  - A pinned failpoint profile artifact (CH-FAIL v0) describing deterministic triggers + bounded effects.
  - Prefer user-space boundary injection (RPC wrappers, driver domains, storage/net servers); allow a tiny set of in-core hooks only where user space can’t reach.
  - Keep production profiles failpoint-free by default.
- Invariants / POs:
  - I-FAIL-1, I-FAIL-2.
  - PO-FAIL-VALIDATE, PO-FAIL-NOAMP, PO-FAIL-DETERMINISM.
- Evidence plan: E1 tool+golden tests; E2 integrate into D-DRT for one protocol slice.
- References: REF-LINUX-FAULTINJECT, REF-JEPSEN, REF-DTRACE-SAFETY.

## 7) IDL + code generation for privileged surfaces (CAmkES/"ABI as data")
- Summary: hand-written marshalling/dispatch code is a recurrent TCB hazard; codegen from a pinned definition reduces drift and can shrink `unsafe`.
- Candidate decision: D-IDL (see RFC-0011).
- Minimal seam:
  - Treat CH-* schemas as canonical wire contracts; IDL/codegen is a *derived* artifact.
  - CI gate: generator version + input digests pinned; drift is fail-closed.
- Invariants / POs:
  - I-IDL-1.
  - PO-IDL-DRIFT.
- Evidence plan: E1 stub generation + schema roundtrip tests; later E2 bounded checks on generated state-machine fragments.
- References: REF-CAMKES, REF-REDOX-SYSCALLS.

## 8) Static partition policy profile (Muen/Jailhouse)
- Summary: static “cells” with explicit resource assignment yields an early high-assurance plateau and a hypervisor-first deliverable with minimal emulation.
- Candidate decision: D-PART (see RFC-0021).
- Minimal seam:
  - CH-PART policy artifact with mandatory overlap checks; bind digest in CH-BOOT.
  - keep authoring/synthesis in tooling (optionally via CH-HWFACT + SKB), kernel validates+installs.
- Invariants / POs:
  - I-PART-1/I-PART-2.
  - PO-PART-VALIDATE, PO-PART-DMA.
- Evidence plan: E1 policy validator + 2-cell demo; E2 bounded overlap/DMA checks.
- References: REF-MUEN-SYSTEM-SPEC, REF-MUEN-KERNEL-SPEC, REF-JAILHOUSE.

## 9) Address decoding nets + table generation (Decoding Nets line)
- Summary: treat MMU/IOMMU/interconnect translation as an explicit graph artifact and generate/validate initial tables from it.
- Candidate decision: D-ADDRNET (see RFC-0022).
- Minimal seam:
  - CH-ADDRNET v0 + a generator/checker pipeline; bind digests in CH-BOOT when used.
  - keep runtime mapping APIs small; push complexity into pinned boot artifacts.
- Invariants / POs:
  - I-ADDRNET-1, I-PTGEN-1.
  - PO-ADDRNET-VALIDATE, PO-PTGEN-CORRECT.
- Evidence plan: E1 validator + negative tests; E2 bounded reachability comparison.
- References: REF-PTGEN-SOSP21, REF-MMAPX-HOTOS21.

## 10) Linked local namespaces + delegation certificates (SDSI/SPKI)
- Summary: local names bound to keys + authorization-first certificates enable delegation without global naming/identity infrastructure.
- Candidate decision: D-NAMECERT (see RFC-0023).
- Minimal seam:
  - CH-NAMECERT bundle evaluated in user space and projected into views; kernel stays agnostic.
  - transcript-log digests when name/delegation impacts privileged configuration.
- Invariants / POs:
  - I-NAME-1, I-NAME-2.
  - PO-NAMECERT-CHAIN.
- Evidence plan: E1 canonicalization/chain-substitution tests; E2 model check over name graphs.
- References: REF-SDSI-RL96, REF-SPKI-RFC2692, REF-SPKI-RFC2693.

## 11) Transparency logs for provenance and updates (optional)
- Summary: append-only, verifiable logs can make “what was released/installed” independently auditable and reduce trust in a single publisher.
- Candidate decision: D-TLOG (see RFC-0029) with optional witnessed checkpoints D-WITNESS (RFC-0082).
- Minimal seam:
  - keep the kernel out of it; use it to publish signed CH-BOOT/CH-PROV digests and release metadata.
  - treat log inclusion/consistency proofs as *evidence artifacts* rather than a runtime dependency (CH-TLOG v0).
- Evidence plan: integrate only once we have a stable build/release pipeline; prefer E4 release-level evidence.
- References: REF-CT-RFC6962, REF-SIGSTORE-REKOR, REF-TRILLIAN.

## 11b) Veto-only policy bundles for automation guardrails (optional)
- Summary: express operational guardrails (deny-lists, budgets, change-ticket requirements) as a pinned artifact evaluated deterministically in user space.
- Candidate decision: D-POLICY (see RFC-0028).
- Minimal seam:
  - CH-POLICY bundle is *veto-only*: cannot grant authority; only denies otherwise-authorized actions.
  - decisions are transcript-logged (CH-LOG) with policy digest for audit.
- Evidence plan: E1 golden tests + E2 DRT harness for a bounded policy subset.
- References: REF-CEDAR, REF-CEDAR-SPEC.

## 11c) Definitional models + differential randomized testing (DRT) for drift control
- Summary: keep a tiny executable semantics and continuously differential-test it against production validators/decoders.
- Candidate decision: D-DRT (see RFC-0027).
- Minimal seam: reference interpreters for CH-KABI/CH-ACP + fuzz/property harnesses.
- Evidence plan: E2 counterexample-finding artifacts pinned in the evidence index.
- References: REF-CEDAR-SPEC.

## Recommendation (tight)
- Design-for-now (cheap seams, big future payoff): D-SEAL, D-RR.
- Keep as optional mechanisms with explicit non-claims until evidence demands: D-METER, D-IOBUF, D-CONSTR.
- Treat as late-stage only unless requirements force it: D-UPCALL.


### Seed: initial capability distribution as data (capDL-style)
- Bounded snapshot artifact (CH-INIT) describing time-0 authority edges, so debugging/audit can diff expected vs actual distributions.
- Keep it non-Turing-complete; prefer ‘validate+install’ tooling (ties naturally to D-PART).


### Seed: OS as control plane for I/O (Arrakis/Dune line)
- Where hardware permits (IOMMU/virt), keep the privileged core off the I/O data path and lease bounded device queues to user space.
- Treat device models as an explicit TCB budget item; prefer ‘no emulation’ or minimal normalized exits.

## 12) Device attestation tokens bound to boot state (DICE/EAT)
- Summary: enable remote verifiers (update gates, fleet integrity checks) to validate “what booted” by checking a signed token bound to CH-BOOT.
- Candidate decision: D-ATTEST (see RFC-0025).
- Minimal seam:
  - CH-ATTEST v0 payload-to-sign includes `boot_digest = digest(CH-BOOT)` and optional provenance digests.
  - Keep signing keys behind D-AUTHAGENT or hardware RoT; exporting the token is observational and capability-gated.
- Invariants / POs:
  - I-ATTEST-1.
  - PO-ATTEST-BIND, PO-ATTEST-VERIFY (and PO-ATTEST-FRESH if freshness is claimed).
- Evidence plan: E1 negative tests (wrong digest/nonce/key); E1 canonicalization tests; keep protocol details profile-specific.
- References: REF-EAT-RFC9711, REF-DICE-TCG, REF-DICE-ANDROID.

## 13) Object-capability RPC as the default component boundary (Cap’n Proto–style)
- Summary: prevent “ambient endpoint” regressions by making cross-component calls *capabilities* (object references), not names; keep it transcriptable.
- Candidate decision: D-CAPRPC (see RFC-0026).
- Minimal seam:
  - CH-CAPRPC outer frame binds calls to an explicit target handle + pinned interface digest (CH-IFACE), enabling safe interface evolution gates (D-APIEVO).
  - Bind call/return digests into CH-LOG for replay/forensics.
- Invariants / POs:
  - I-CAPRPC-1.
  - PO-CAPRPC-NOAMBIENT, PO-CAPRPC-FRAME.
- Evidence plan: E2 bounded model check on a tiny call graph: “no call without handle”; E1 frame validation tests.
- References: REF-CAPNP, REF-CAPNP-RPC, REF-SANDSTORM-CAPNP.

## 13b) Powerbox / consent mediator pattern (authority UX)

Idea: standardize an optional user-space consent mediator that concentrates cross-boundary authority decisions (a “powerbox”). It can grant/revoke delegated authorities explicitly during operation, and it is a natural place to anchor human/operator approvals for high-risk actions.

Archive hook: D-POWERBOX + IF-CONSENT issuing CH-AUTHZ approvals bound to action digests (I-CONSENT-1).

Further leverage: pair the powerbox with **temporary grants** (D-LEASE): issue time-limited / use-limited proxy capabilities by default for ad-hoc sharing, and record `digest(CH-CAPLEASE)` in consent receipts for audit (RFC-0066).

Refs: REF-ERIGHTS-POWERBOX, REF-DARPABROWSER-REPORT.


## 13c) Cross-domain services + policy as data (Qubes qrexec pattern)

- Summary: a practical “call a service in another domain” substrate becomes safe *and usable* when (a) the call is a **declared service**, (b) authorization is **fail-closed** by default, (c) policy is **layered as data**, and (d) disposable targets are first-class (`@dispvm`).
- Candidate decision hooks: D-CAPRPC + D-POLICY + D-PLUMB + D-EPHEM.
- Minimal seam:
  - represent cross-domain invocations as **CapRPC sessions** to a well-known mediation component (a portal/router), not as ambient “connect by name”
  - policy is evaluated from a pinned CH-POLICY bundle (veto-only) and must be deterministic; “no matching rule” denies
  - allow an explicit disposable target selector (`target=@ephem` analogue) so “open in disposable” and “split service” patterns compose cleanly
  - keep payload transport simple and auditable: typed stdin/stdout-like streams or bounded typed messages (no hidden side channels)
- Invariants / POs:
  - I-CAPRPC-1, I-POLICY-1/I-POLICY-2, I-EPHEM-1/I-EPHEM-2.
  - PO-POLICY-DETERMINISM, PO-POLICY-NONAMP, PO-CAPRPC-NOAMBIENT.
- Evidence plan:
  - prototype a minimal “named service call” wrapper in user space (service + optional `+arg`) backed by CapRPC + CH-POLICY evaluation
  - demonstrate: (1) no-match denies, (2) policy layering works deterministically, (3) `OpenUntrusted` routes to a disposable target and exports require explicit portal grants
- References: REF-QUBES-QREXEC, REF-QUBES-DISPOSABLES, REF-QUBES-SPLITGPG.

## 14) Content-addressed evidence pointers (keep archive small)

Idea: treat heavyweight evidence artifacts as content-addressed objects referenced by digest, not embedded.

Archive hook: D-AREF + CH-AREF v0 artifact references; pairs naturally with D-TLOG anchoring.

Refs: REF-VENTI-FAST02, REF-FOUNDATION-CAS.

## 15) User-space translators / stackable filesystem servers (GNU Hurd style)

Idea: make “attach a server to a path” a first-class extension seam: a *translator* is a user-space object server that exports a filesystem (or filesystem-like) interface for a node/directory. This enables powerful composition (protocol adapters, per-directory policies, synthetic filesystems) **without** importing it into the privileged core.

Candidate decision: D-TRANS.

Minimal seam:
- A **view node** may optionally carry a `translator` capability (resolved within the view).
- Translator attachment/removal is an explicit action (CH-LOG) and is subject to seal/capmode posture (D-SEAL/D-CAPMODE).
  - Reality check: QNX’s “resource managers” treat path attachment as an explicit pathspace operation; we should model attach as a view mutation right and keep it transcript-visible.
- Translators run as normal domains (driver-domain model) and are isolated like any other service.

Invariants / POs:
- I-VIEW-1/I-VIEW-2 (resolution and authority containment).
- I-CAPMODE-1 / PO-CAPMODE-ONEWAY when enabled.
- PO-VIEW-RESOLVE/PO-VIEW-NOAMP (no new authority from resolution).

Evidence plan:
- Prototype a tiny translator that virtualizes a directory subtree and demonstrate: (1) no ambient acquire fallback, (2) post-seal cannot reattach a broader translator.

Refs: REF-HURD-TRANSLATORS, REF-QNX-RESMGR, REF-QNX-RESMGR-ATTACH.

## 16) Indexed file attributes + query as a system primitive (BeOS/Haiku BFS)

Idea: treat file metadata as structured, indexed attributes so “search” becomes a **fast, local query** over the filesystem itself (not a separate indexer). This is an unusually high-leverage UX feature, and it composes naturally with per-process views: queries can run *over a view*, not “the whole machine”.

Candidate decision: D-ATTRFS.

Minimal seam:
- Keep indexing/query engines in user space, but standardize the storage and syscall hooks needed for robust attributes/indexes.
- Scope queries by view objects; treat “attribute schemas” as optional CH-ATTR declarations to bound complexity.

Invariants / POs:
- I-VIEW-2 (capability-mediated access checks for query results).
- I-TRACE-1 (if query auditability is required, export via IF-OBS with redaction).

Evidence plan:
- A minimal prototype over a toy filesystem showing: attribute persistence, indexed lookup, and view-scoped query restrictions.

Refs: REF-BFS-ATTR, REF-HAIKU-QUERIES.

## 17) Atomic system image updates + rollback (OSTree/rpm-ostree pattern)

Idea: treat the “base OS” as an immutable deployment tree; upgrades install a *new* tree and switch boot to it, keeping the old tree available for rollback. This sharply reduces upgrade brick risk and pairs extremely well with our provenance/evidence linkage: a deployment digest can be bound directly in CH-BOOT and CH-PROV.

Candidate decision: D-ATOMICUPD.

Minimal seam:
- Base deployments are immutable, content-addressed trees; mutable state lives in explicitly separated volumes (or view mounts).
- Boot selects a deployment by digest; update creates a new deployment and updates boot selection.
- Bind provenance: if CH-BOOT carries `prov_attestation_digest`, it must match the selected deployment digest (I-PROV-CHAIN-1).

Invariants / POs:
- I-PROV-CHAIN-1 (optional provenance binding).
- I-COMP-2 (composition/policy revisions are pinned per deployment when CH-COMP is used).

Evidence plan:
- Demonstrate: (1) install new deployment, (2) fail boot → rollback works, (3) provenance mismatch fails closed.

Refs: REF-RPM-OSTREE, REF-FEDORA-ROLLBACKS, REF-QUBES-TEMPLATES, REF-QUBES-TEMPLATE-IMPL.


## 17b) Recovery mode + rescue environment (WinRE/Android recovery/systemd rescue targets)

Idea: a recovery environment should be a **first-class boot target** that is independent of the normal user-space stack. In practice this reduces MTTR dramatically when updates, drivers, or policy changes break early boot or input/UI.

Candidate decision: D-RECOVERY (see RFC-0098).

Minimal seam:
- Ship a dedicated recovery deployment root alongside normal updates (CH-UPD/CH-BOOT `artifacts[]` role `recovery_root`).
- Provide at least one **physical presence** entry path (boot menu/recovery button/SAS path), so untrusted software can’t spoof recovery entry.
- Keep recovery **sealed/minimal** by default (no ambient networking/device attach); recovery actions are explicit privileged effects and transcript-visible.

Invariants / POs:
- I-RECOVERY-1.
- PO-RECOVERY-ENTRY, PO-RECOVERY-NOAMP.

Evidence plan:
- Harness: corrupt active root; recovery boots; stage a bounded trial boot via CH-BOOTSEL `pending` and verify fallback.

Refs: REF-WINRE, REF-ANDROID-PARTITIONS, REF-SYSTEMD-SPECIAL.


## 18) Per-process namespaces + union mounts (Plan 9 “Pgrp” lesson)

Idea: keep namespaces **per process/component** and make overlay composition (union mounts) cheap. This is a major usability/least-authority win: “what you can name” becomes a local, explicit object rather than a global policy surface.

Candidate decision: D-NS (see RFC-0032).

Minimal seam:
- View objects gain `clone` + union/overlay operations (still capability-mediated).
- Namespace mutation is an explicit, loggable action (CH-LOG) so replay/debug can answer “what names existed when?”.

Invariants / POs:
- I-VIEW-1/I-VIEW-2 remain the core; union semantics must preserve “no implicit amplification”.
- Optional: add a determinism constraint (“resolve depends only on view graph + mutation transcript”) to keep replay stable.

Evidence plan:
- Model-check small view graphs with overlays; differential tests for resolve determinism across implementations.

Refs: REF-PLAN9, REF-PLAN9-NSCROSS.

## 19) Service trees (Plan 9/Inferno “everything is a file” ergonomics) without ambient authority

Idea: many successful systems made **hierarchical interfaces** the universal UX substrate (Plan 9’s 9P, /proc-style introspection, etc.). We can adopt the ergonomics without importing ambient authority by treating “trees” as an unprivileged convention: a service exports a tree rooted at a capability, and tooling bridges it into file-like views.

Candidate decision: D-NS (tooling convention; no kernel expansion).

Minimal seam:
- A standard “tree adapter” library + CLI: inspect nodes, read/write, traverse, and optionally mount via a user-space bridge.
- Optional: 9P-like transport for remote mounts, but the endpoint is just another capability (no special global networking authority).

Evidence plan:
- Dogfood: make IF-OBS exports browsable through a service tree adapter; verify redaction is preserved.

Refs: REF-9P, REF-PLAN9.

## 20) Functional package management + content-addressed store (Nix/Guix pattern)

Idea: treat installation/updates as *pure build graph evaluation*: outputs are addressed by their inputs, allowing many versions to coexist, reproducibility checks to be automated, and rollbacks to be cheap. This aligns naturally with our “proof-carrying provenance” target and atomic deployments (D-ATOMICUPD).

Candidate decision: D-FPM (see RFC-0033).

Minimal seam:
- Define a minimal build-derivation schema (CH-DERIV) suitable for recording build recipes + input digests.
- Treat “system closure manifests” as inputs to CH-PROV/CH-BOOT bindings (without bloating IF-BOOT).

Evidence plan:
- CI builds the same derivation twice with `--check`-style reproducibility gating; record diffs as EVID artifacts.

Refs: REF-NIXOS-JFP10, REF-NIX-HOWNIX, REF-GUIX-FPM13.

## 21) Capability hardware as an optional profile (CHERI line of work)

Idea: even in a Rust-heavy OS, we’ll often have legacy C/C++ (firmware, drivers, vendor code). Capability hardware (CHERI/Morello-class) can provide **fine-grained bounds and compartmentalization** that reduces bug blast radius.

Candidate decision: D-ISA (as a variant/profile evaluation).

Minimal seam:
- Keep object/cap semantics compatible with pointer provenance constraints (avoid designs that assume “raw integer pointers”).
- Treat “C driver compartments” as an optional profile to evaluate on CHERI-capable hardware.

Evidence plan:
- Prototype one driver-domain compiled with CHERI and measure compartment boundaries + overhead.

Refs: REF-CHERI-INTRO.
## 22) Kernel object quotas (Genode-style cap quota) (optional)

Idea: prevent kernel resource exhaustion by making kernel-maintained references (cap slots/endpoints/notifications) explicitly *paid for* by the allocating component.

Candidate decision: D-KOBJQ (and D-METER).

Minimal seam:
- Extend allocation-carrying privileged actions to include a `charge_to` meter/budget.
- Charge atomically with object creation; fail closed on insufficient budget.

Evidence plan:
- Stress-test driver domains attempting to exhaust endpoints/cap slots; show containment and attribution.

Refs: REF-GENODE-CORE, REF-GENODE-SESSIONS, REF-GENODE-RESMGMT.

## 23) Capability graph export + leak tests (optional)

Idea: capability systems need operational tooling. A bounded, redacted cap-graph export (CH-CAPG) plus diff-based “leak tests” makes authority debugging practical without ambient introspection.

Candidate decision: D-CAPAUD.

Minimal seam:
- Add CH-CAPG v0 and optionally include it in IF-OBS exports (CH-OBS).
- Scope exports by an explicit audit capability; default off in sensitive profiles.

Evidence plan:
- Add 3 leak tests: powerbox, service spawn, driver hotplug; validate no unintended edges.

Refs: REF-CAPSICUM, REF-GENODE-MANUAL, REF-PLAN9.

## 24) Rump kernels: reuse kernel drivers/FS in user space (NetBSD rump kernel)

Idea: accelerate early hardware/filesystem support by running existing kernel subsystems **as libraries in user space**, isolating them like any other driver domain. Rump kernels (NetBSD) are a proven “back alley surgery” technique that can be an excellent fit for a microkernel multiserver OS: the compatibility code is large, but it stays outside the privileged core.

Also: Linux-kernel-library style donor subsystems (LKL) and other compat capsules can serve the same role when rump is not a fit, but they must obey the same explicit membrane and fail-closed rules (see RFC-0083).

Candidate decision: D-RUMPK (see RFC-0036, RFC-0083).

Minimal seam:
- Run rump-backed code as a normal component/driver domain; it receives only explicit I/O/resource capabilities.
- Expose rump-backed filesystems via translators (D-TRANS) and mount into views (D-NS) — no ambient path magic.
- Treat “mount untrusted FS image” as a first-class security use-case: crash/compromise is contained to the rump domain.

Evidence plan:
- Demo: mount a deliberately malformed/untrusted FS image via a rump-backed filesystem component; show the privileged core stays intact and recovery follows supervision policy.

Refs: REF-RUMPKERNEL-WIKI, REF-RUMPKERNEL-ABC2015, REF-RUMPRUN-SEL4, REF-LKL-GITHUB.

## 24b) Unikernels / sealed appliances as a deployment profile (MirageOS line)
- Summary: compile single-purpose services into minimal images that are **sealed** against post-deploy mutation; reduces update/ops surface and makes provenance/attestation crisp.
- Candidate decision hooks: D-SEAL (init→seal), D-FPM/D-ATOMICUPD (digest-addressed closures + rollback), D-BOOT/C-BOOT-1 (boot policy), D-PCP (proof-carrying provenance).
- Minimal seam:
  - treat a “unikernel image” as just another bootable component closure with a pinned manifest and a tiny I/O set (explicit device + net leases).
  - forbid ambient mutable state; any persistence flows through explicit portals/cap stores.
- Invariants / POs:
  - I-SEAL-1, I-BOOT-1, I-FPM-1; PO-FPM-HASHKEY; PO-BOOT-VERIFY.
- Evidence plan: E1: run the same service as (a) normal user-space component and (b) sealed-image profile and compare privileged surface and update/provenance trails.
- References: REF-UNIKERNELS-ASPL13, REF-MIRAGE-PAPERS.

## 24c) Turn-based service runtimes (E/Spritely vat model) (optional)

Idea: capability RPC gets much easier to reason about when services adopt a turn-based event-loop model ("vats") where one inbound message is processed to completion before the next. This avoids a classic footgun: synchronous/await-style stubs that keep a service responsive by pumping inbound messages, enabling **reentrancy** callbacks into half-mutated state.

Candidate decision: D-TURNS (see RFC-0078).

Minimal seam:
- Treat D-TURNS as a user-space runtime profile for selected services (especially those exposed via CapRPC).
- Prefer promise-based APIs and explicit continuations; forbid hidden inbox pumping.
- Add a small reentrancy regression harness to make the hazard and the mitigation testable.

Invariants / POs:
- I-TURNS-1; PO-TURNS-NOREENTR.

Evidence plan:
- Demonstrate an exploitable reentrancy interleaving under an inbox-pumping stub, then show the same test is impossible under D-TURNS enforcement.

References: REF-ROBUST-COMPOSITION, REF-E-LRM, REF-SPRITELY-CORE.

## 25) Safe programmable hooks: eBPF lesson without importing a huge verifier/VM

Idea: ecosystems thrive when third parties can ship *small programs* that filter/aggregate events close to the source (eBPF/XDP, DTrace predicates). However, kernel-resident programmable VMs/verifiers tend to balloon in complexity and become a security/perf tax.

Candidate decision: D-TRACE (bounded predicates) + (optional) “user-space filters” profile.

Minimal seam:
- Keep the privileged core limited to declared tracepoints + optional bounded predicates (RFC-0015).
- Put rich programmable analysis in user space: subscribe to CH-TRACE via IF-OBS and run filters/aggregations in Wasm or native code with explicit capabilities.
- If we ever need ‘near-source’ filtering comparable to eBPF, do it as a **separately isolated tracing domain** that runs a verifier/VM out of the privileged core and produces derived CH-TRACE summaries.

Evidence plan:
- Benchmark: tracepoint → bounded predicate vs tracepoint → user-space filter; quantify overhead and data volume.

Refs: REF-EBPF-INTRO, REF-EBPF-VERIFIER-HARNESS.
## 26) Cooperative checkpoint/restore as a first-class user-space service

Idea: C/R is often added late as a “clever” debugging feature, but it becomes dramatically more useful when designed in early as a **cooperative protocol**. Instead of opaque interception, components participate explicitly: quiesce, export state bundles, and restore under explicit authority. This keeps the seam small and preserves capability discipline (no hidden authority).

Candidate decision: D-CHKPT (see RFC-0037).

Minimal seam:
- A checkpoint manager is just another user-space component with explicit authority to request exports and perform restores.
- State bundles are content-addressed artifacts (CH-AREF) referenced by a pinned manifest (CH-CKPT).
- Quiesce boundaries compose through supervision trees (RFC-0017): stop restarts, drain work, capture a consistent cut.

Evidence plan:
- Demo: checkpoint+restore a small service set; validate `cap graph` is unchanged on restore except for expected rehydration edges.

Refs: REF-CRIU, REF-DMTCP.

## 27) Snapshots + “boot environments” for user data (cheap rollback without privileged magic)

Idea: the best “it didn’t happen” button is an instant snapshot/clone mechanism. Systems like ZFS show that copy-on-write snapshots can be cheap enough to use routinely, enabling safe upgrades, fast rollback, and forensic timelines.

Candidate decision: D-PERSIST (see RFC-0038) + D-ATOMICUPD (adjunct).

Minimal seam:
- Implement snapshots/clones in a user-space filesystem/store server; the privileged core stays agnostic.
- Model boot environments as composition: immutable base image + snapshotable mutable datasets (config/state) mounted into views (D-NS).
- Record snapshot creation/selection as transcripted effects (CH-LOG) and bind to provenance where relevant.

Evidence plan:
- Demo: upgrade creates a preflight snapshot and records a dataset compatibility barrier (RFC-0097); rollback restores both base deployment pointer and a compatible user dataset snapshot.
- Negative: attempt rollback across a breaking migration without restoring a compatible snapshot must fail closed (no “boot into unreadable state”).

Refs: REF-ZFS-PAPER, REF-RPM-OSTREE.

## 28) Crash-only services + microreboots (recovery-oriented computing)

Idea: treat restarts as the *primary* recovery tool. Instead of deep in-process error recovery and complex partial-state handling, design components to be restartable, with durable state factored out behind explicit capabilities.

This is not a kernel feature; it’s a discipline we can bake into our composition + supervision seam early so it becomes “how you build things here.”

Candidate decision: D-SUPV (adjunct; see RFC-0041).

Minimal seam:
- Supervision trees rate-limit and transcript-log restarts.
- Components export explicit readiness; init→seal prevents “init authority” from creeping back in after restart.
- Optional: cooperative checkpoint/restore accelerates recovery but is not required.

Invariants / POs:
- I-SUPV-1 (restart is non-amplifying).
- PO-SUPV-NOAMP, PO-SUPV-RLIMIT.

Evidence plan:
- Dogfood: inject crashes in a service trio and demonstrate microreboot restores correctness without widening authority.

Refs: REF-MICROREBOOT-OSDI04, REF-ROC-COMPUTER04.


## 28b) Activation-owned endpoints + handle handoff (socket activation / FD-store patterns)

Idea: crash-only restarts become *operator-friendly* when inbound endpoints are **manager-owned** and passed into services (so restarts don’t drop new traffic), and when services can optionally preserve a tiny set of handles across restarts (without requiring full checkpoint/restore).

Candidate decision: **D-ACTIVATE** (see RFC-0081).

Minimal seam:
- Supervisor owns stable inbound endpoints and delivers them at start as an activation bundle (CH-ACTSET v0).
- Optional per-component handle store with an explicit allowlist and hard bounds (count + metadata); default `steady_only` (post-seal) to avoid seal bypass.
- Deterministic Stop→Kill lifecycle semantics for bounded shutdown behavior.

Invariants / POs:
- I-ACTIVATE-1 (stable handle continuity) + I-ACTIVATE-2 (store is non-amplifying and phase-gated).
- PO-ACTIVATE-HANDOFF (wrong-instance retrieval fails closed; bounds are enforced deterministically).

Evidence plan:
- Demo: a supervised server restarts repeatedly without dropping new inbound connections; negative tests for wrong-`cid` retrieval and pre-seal `Put()`.

Refs: REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-FDSTORE, REF-SD-LISTEN-FDS, REF-LAUNCHD-ACTIVATE-SOCKET, REF-NGINX-CONTROL.


## 29) Workflow plumbing + portals (Plan 9 plumber + XDG portals pattern)
Lesson: cross-app “glue” is where sandboxes quietly dissolve (file choosers returning paths; clipboard broadcast; “open with” implicit delegation). A portal+router makes these flows explicit, auditable, and capability-shaped.

Candidate decision: D-PLUMB (see RFC-0046).

Minimal seam:
- user-space workflow router published under `/svc/workflow/*`
- pinned routing rules (CH-ROUTE v0) + deterministic evaluation
- optional consent mediation (D-POWERBOX) + spoof-resistant gesture binding (D-VOLITION)

Invariants / POs:
- I-PLUMB-1 (routing is non-amplifying).
- PO-PLUMB-NOAMP (capgraph diff gate on portal completion).

Evidence plan:
- Dogfood: sandboxed “viewer” can open only via portal; demonstrate audit trail and no raw-path ambient access.

Refs: REF-PLAN9-PLUMB, REF-XDG-PORTAL, REF-XDG-PORTAL-DOCUMENTS, REF-QUBES-CLIPBOARD, REF-APPLE-SECBOOKMARK.


## 29b) Capability-mediated UI compositor + secure attention (Wayland lesson)
Lesson: desktop isolation is fragile if apps can globally read pixels or intercept input. Wayland’s model demonstrates a practical security boundary: **clients can’t access other clients’ surfaces** and input is **focus-routed**.

Candidate decision: D-UICAP (see RFC-0080).

Minimal seam:
- UI root/compositor is a user-space component that owns raw input + scanout capabilities.
- Apps receive surface handles and input endpoints as object capabilities; no ambient global window IDs.
- High-risk UI authority (screenshot/screencast/remote-control) is portal-mediated (D-PLUMB) and SHOULD be lease-based (D-LEASE).
- Optional secure attention sequence (SAS) to enter a spoof-resistant “secure UI mode” for login/high-risk consent.

Evidence plan:
- Negative tests: unfocused clients never receive input; clients cannot read other clients’ pixels; captures require portal leases.

Refs: REF-WAYLAND-CH04, REF-XDG-PORTAL-SCREENSHOT, REF-XDG-PORTAL-SCREENCAST, REF-MS-WINLOGON-SAS.


## 29c) Transfer portal for clipboard/drag-drop/share (no ambient broadcast)
Lesson: clipboard and drag-drop are covert, ambient data channels in most desktop stacks. Treat them as **explicit portal transfers** that yield leased payload handles and emit a bounded transfer descriptor for audit and receipts.

Candidate decision: D-PLUMB (adjunct; see RFC-0094).

Minimal seam:
- A user-space transfer portal mediates `Paste`/`DragDrop`/`Share` intents; no app can read “the clipboard” without a specific portal grant.
- Portal grants are **leased** by default (D-LEASE), with strict TTL/use bounds and recommended auto-clear semantics (clipboard).
- Each grant emits a **CH-XFER v0** descriptor digest (redaction-aware) so receipts and incident bundles can answer “what moved between whom, under what bounds” without embedding payload bytes.

Invariants / POs:
- I-XFER-1 (no ambient reads; transfers are explicit and attributable).
- I-XFER-2 (bounded + auto-clear posture; sensitive marking respected).
- PO-XFER-VALIDATE (CH-XFER decode/bounds fail closed).

Evidence plan:
- Dogfood: cross-app paste works only via portal; background reads fail; auto-clear and lease expiry are observable and deterministic.

Refs: REF-QUBES-CLIPBOARD, REF-WAYLAND-APA-DATADEVICE, REF-XDG-PORTAL-CLIPBOARD, REF-ANDROID-SECURE-CLIPBOARD.


## 29d) Location as a portal workflow (explicit leases + coarse/precise posture)
Lesson: location APIs are a high-value privacy surface. Many ecosystems treat location as special (foreground/background access, accuracy tiers). If location is ambient, sandboxes quietly dissolve into covert tracking channels.

Candidate decision: **D-LOCLEASE** (see RFC-0101).

Minimal seam:
- A user-space location portal (`portal.location.*`) mediates one-shot requests, continuous updates, and geofence workflows.
- Portal returns explicit location capabilities and emits a **CH-LOCLEASE v0** descriptor digest (no coordinates) for receipts/audit.
- Requests declare `coarse` vs `precise`; policy clamps, rate-limits, and TTL-bounds grants; background tracking is profile-gated.
- Continuous tracking implies non-spoofable indicators and transcript-visible renew/revoke events.

Invariants / POs:
- I-LOCLEASE-1..3; PO-LOCLEASE-VALIDATE/PO-LOCLEASE-ENF.

Evidence plan:
- Dogfood: a sandboxed weather app can request one-shot **coarse** location only via portal; a navigation app can request precise updates only with explicit consent; expiry and cadence clamps are deterministic; exports redact by default.

Refs: REF-XDG-PORTAL-LOCATION, REF-ANDROID-LOC-PERMS, REF-ANDROID-LOC-BACKGROUND, REF-APPLE-LOCATION-PRECISE, REF-GEOCLUE-DBUS.


## 30) User-driven access control gadgets (CapDesk/UDAC line)
Lesson: “permission prompts” are a leaky abstraction; successful least-privilege systems translate *user intent* embedded in workflows into explicit, audit-friendly authority grants.

Archive hook: this is not a new kernel mechanism — it’s a **standard UX+protocol seam** that composes D-VOLITION + D-POWERBOX + D-PLUMB.

Minimal seam:
- Standardize an **Access Control Gadget (ACG)** UI primitive that can be embedded in apps but renders via the trusted UI path (D-VOLITION).
- ACG produces an intent digest backed by a CH-VOL token; IF-CONSENT mints a scoped, time-bounded CH-AUTHZ grant (optionally persistent via sturdyref) to a *specific* handle/cap, not a path.
- Every grant is transcript-logged with `(policy_digest, volition_digest, capgraph_delta_digest)` so audit can answer “who granted what, when, why”.

Invariants / POs:
- I-VOLITION-1 / PO-VOL-VALIDATE (spoof resistance)
- I-CONSENT-1 / PO-CONSENT-VALIDATE (binding grants to displayed summaries)
- I-PLUMB-1 / PO-PLUMB-NOAMP (no implicit amplification on workflow completion)

Evidence plan:
- Dogfood: implement one portal flow (open/save) end-to-end with ACG; show (1) no ambient file access, (2) grant is scoped+revocable+logged, (3) UI spoof attempts fail.

Refs: REF-ROBUST-COMPOSITION, REF-DARPABROWSER-REPORT, REF-UDAC-SP12.


## 31) Practical least-privilege wrappers for legacy apps (Plash/Polaris pattern)
Lesson: greenfield purity rarely ships alone — the fastest path to a useful ecosystem is often **running existing binaries** inside a least-privilege envelope that makes authority *explicitly handoff-able*.

Candidate decision: no new D-* required; this is an early *ecosystem deliverable* that rides on D-NS + D-SEAL + D-CAPMODE + D-PLUMB.

Minimal seam:
- A “compat launcher” constructs a **default-deny view** (D-NS) for the child: no ambient path roots, no ambient network endpoints.
- All authority comes via explicit caps: portal sessions (D-PLUMB), consent-mediated grants (D-POWERBOX), or a one-way “promise” mask (RFC-0016/D-SEAL) installed immediately post-init.
- Provide an “authority diff” UX (D-EXPLAIN): every new grant shows a cap-graph delta summary (CH-CAPG redacted), emits a CH-RECEIPT record, and uses time-bounded expiration by default.

Invariants / POs:
- I-VIEW-1/I-VIEW-2 + PO-VIEW-NOAMP (naming cannot mint authority)
- I-SEAL-1 + PO-SEAL-ONEWAY (post-init narrowing is one-way)
- I-CAPMODE-1 + PO-CAPMODE-ONEWAY (no ambient acquisition after init)

Evidence plan:
- Start with a simple CLI app: prove it can’t read arbitrary paths or connect arbitrarily without portal mediation; then repeat with a GUI app and clipboard/open-with flows.

Refs: REF-MAKE-LEASTPRIV-RIGHT, REF-PLASH, REF-POLARIS-SOUPS05, REF-AUTHORITY-ANALYSIS-LP07, REF-LEASH-CAPSICUM-2025, REF-SANDBOX-ADOPTION-ARXIV24.


## 31b) Library OS + picoprocess compartments for legacy apps (Drawbridge pattern)
- Summary: for “run legacy apps safely” cases, isolate each app in a **picoprocess** with a per-app **library OS** implementing the compatibility ABI; host integration is only via narrow, explicit channels.
- Candidate decision: treat this as an *alternative* compatibility runtime under D-RUMPK’s “future runtimes” bucket (do not mix into privileged core).
- Minimal seam:
  - treat the compat runtime as a normal supervised component providing an ABI facade; it receives only portal capabilities for the host services it needs.
  - enforce a closed, fail-closed ABI dispatch table (no raw escape hatches / ioctl pass-through by default).
- Invariants / POs:
  - I-COMPAT-1/I-COMPAT-2; PO-COMPAT-CLOSESET/PO-COMPAT-NOAMBIENT.
- Evidence plan: E0/E1: prototype a tiny compatibility facade using our portal patterns; measure syscall tax and surface size; compare against wrapper-only approaches (RFC-0031).
- References: REF-DRAWBRIDGE-ASPL11, REF-DRAWBRIDGE-POSIXPICO, REF-GVISOR-COST.

## 32) Capability-safe automation & scripting (Shill + wrapper patterns)
Lesson: “glue” is where least-privilege goes to die — shell scripts, cron jobs, CI hooks, and admin runbooks routinely accumulate ambient authority and become long-lived attack surfaces.

Candidate decision: treat automation as *components* (D-COMP) with declared caps + post-init narrowing (D-SEAL/D-CAPMODE), and provide a first-class **capability-safe scripting** path.

Minimal seam:
- A capability-safe scripting language/DSL (or a constrained shell mode) where scripts declare a contract: required views/caps + optional portal interactions.
- The runtime enforces default-deny namespaces, with explicit authority handoff only via portals/powerbox.
- Wrapper pattern: allow scripts to perform privileged setup during init, then seal (one-way) into a reduced steady-state for the rest of the pipeline.

Invariants / POs:
- I-SEAL-1 / PO-SEAL-ONEWAY
- I-CAPMODE-1 / PO-CAPMODE-ONEWAY
- I-COMP-1 (composition edges are explicit) / PO-COMP-VALIDATE

Evidence plan:
- Dogfood: re-express a small “admin runbook” as a sealed automation component and show it cannot exceed its declared authority, even when invoking native utilities.

Refs: REF-SHILL-OSDI14, REF-TAOUP-SECWRAP, REF-SANDBOX-ADOPTION-ARXIV24.

## 33) Origin metadata + quarantine + safe-open defaults (MotW/Gatekeeper lesson)
Lesson: many user compromises start with “unknown provenance” objects; systems that tag origin (MotW, Gatekeeper quarantine) help, but only if propagation and clearing are explicit and testable.

Candidate decision: D-QUAR (plus D-EPHEM + D-PLUMB).

Minimal seam:
- Declare a small `origin.*` and `quarantine.*` attribute set (CH-ATTR instance) and propagate it through copy/extract by default.
- Quarantined objects “open” via a safe path: disposable domain by default (D-EPHEM) + explicit export (D-PLUMB).
- Clearing quarantine is a consent-mediated, transcript-logged action (IF-CONSENT/CH-LOG), never an app-private hidden bit.

Invariants / POs:
- I-QUAR-1..4 (monotonic propagation; explicit clear; safe-open default)
- PO-QUAR-PROP / PO-QUAR-GATE / PO-QUAR-CLEAR

Evidence plan:
- Build a laundering corpus (nested archives, disk images, rename/copy flows) and regression-test propagation/clearing rules.

Refs: REF-MOTW-ZONEID, REF-MACOS-GATEKEEPER, REF-GATEKEEPER-BYPASS.

## 34) Wasm components as the default untrusted extension runtime (Component Model / WASI lesson)
Lesson: a portable, spec-first sandbox with typed interfaces and capability discipline is a strong default for plugins/tools; the Wasm component model + WASI design principles align well with our capability and portal story.

Candidate decision: D-WASM (plus IF-SBX, D-CAPMODE, D-PLUMB).

Minimal seam:
- Treat Wasm components as the default IF-SBX payload type.
- Bind authority to a closed, typed import set (WIT); host injects only explicit handles/caps (no ambient open-by-path).
- Route high-risk imports through consent mediation (IF-CONSENT) and issue lease-bounded handles.

Invariants / POs:
- I-WASM-1, I-WASM-4, I-WASM-2, I-WASM-3 (imports are capabilities; closed imports; confinement; no handle forgery)
- PO-WASM-IMPORTS / PO-WASM-CONFINE / PO-WASM-HANDLE

Evidence plan:
- Import-closure validator + negative tests; fuzz host adapters; “escape attempt” suite at the sandbox boundary.

Refs: REF-WASM-CM-INTRO, REF-WASM-CANONABI, REF-WASI-DESIGN, REF-WASI-0-2.
## 35) Sealed code spaces + capability-gated executable mappings (W^X + “no execmod” by default)
Lesson: many real-world exploit chains rely on turning attacker-controlled bytes into executable code (JIT spraying, RW→RX flips, DSO injection). If “make code executable” is treated as **explicit authority**, we can keep most of the ecosystem on the safe side by default and make exceptions obvious and reviewable.

Candidate decision: D-DYNCODE (see RFC-0059).

Minimal seam:
- Enforce W^X (no RWX mappings) in the privileged core.
- Require an explicit “execmod” capability for RW→RX transitions or for mapping non-sealed bytes executable.
- Default third-party extensions to Wasm components (D-WASM) and treat native dynamic modules as a profile-scoped escape hatch.

Evidence plan:
- Prototype execmod gating + negative tests (expected fail without authority); add a lint that flags any new path that can introduce executability.

Refs: REF-OPENBSD-33-WX, REF-OPENBSD-WX-KERNEL, REF-JITDEFENDER, REF-SINGULARITY.
## 36) Programmable observability without a privileged VM (Wasm trace processors)
Lesson: operators want “ask one question” instrumentation (bpftrace/DTrace-style) and always-on low-overhead counters — but in-kernel programmability tends to become a large, subtle TCB (verifiers, helpers, JITs).

Candidate decision: D-TRACEPROC (built on D-TRACE + D-WASM).

Minimal seam:
- Keep kernel tracing mechanistic: predeclared tracepoints + CH-TRACE records (D-TRACE).
- Run *untrusted* trace processors in user space (often Wasm components) that consume CH-TRACE and emit bounded, redaction-safe aggregates.
- Configure processors via a small schema (CH-TRACEPROC) mediated by a trace portal/supervisor; clamp probe sets and enforce budgets.

Invariants / POs:
- I-TRACE-1 (trace is observational)
- I-TRACEPROC-1 (processors are observational + bounded)
- PO-TRACEPROC-SBX / PO-TRACEPROC-BOUNDS

Evidence plan:
- Prototype 2–3 processors (scheduler, IPC, VM-exit counters) and benchmark: raw export vs aggregated outputs.
- Negative tests for high-entropy label injection and rate-modulation covert channels.

Refs: REF-DTRACE, REF-EBPF-INTRO, REF-BPFTRACE, REF-WASM-CM-INTRO, RFC-0068.

## 37) Device guard: deny-by-default hotplug + attach portals (USB/Thunderbolt)

Idea: treat peripherals as hostile-by-default. New hotplug devices are **unauthorized** until a deterministic policy decision allows them. Prefer binding raw devices into a dedicated peripheral/driver domain first (Qubes-style), and require **portalized attach** to grant device authority to workload domains. Optional policy-as-data (CH-DEVGUARD) enables auditability and limited veto-only automation without becoming an ambient “udev”.

Candidate decision: D-DEVGUARD.

Minimal seam:
- User-space device manager receives hotplug events and owns policy decisions.
- Attach/detach emits CH-LOG entries referencing digest(CH-DEVGUARD) and (if used) digest(CH-IOLEASE).
- Gate DMA-class hotplug on the platform’s DMA posture (D-DMA); fail closed if the platform cannot meet the profile.

Evidence plan:
- fuzz device-descriptor parsing and hotplug workflows
- negative tests: no policy ⇒ deny; auto-attach drift is detected via transcripts
- IOMMU confinement sanity checks for leased I/O resources

Refs: REF-QUBES-USB, REF-USBGUARD-RHEL7, REF-USBGUARD-RULELANG, REF-THUNDERSPY-REPORT, REF-WIN-KDMA.
## 38) Immutable, content-addressed “time machine” storage as a standard service (Venti/Bullet line)

Idea: the most reliable rollback/forensics UX is “it didn’t happen” via cheap snapshots. A write-once, hash-addressed block store (Venti) and immutable-file servers (Amoeba Bullet) show an appealing pattern: mutation is expressed as **new objects + new roots**, and history is naturally retained (subject to GC policy).

Candidate posture: no new kernel mechanism required; design-for seams under D-PERSIST + D-CHKPT + D-FPM (adjunct) + D-ATOMICUPD (adjunct).

Minimal seam:
- Standardize a user-space **CAS store + root service** interface: `put(block) -> digest`, `get(digest) -> block`, `publish(root_name, root_digest)`, and signed “receipts” suitable for CH-LOG attachment (no secret bytes).
- Treat “roots” as capabilities/sturdyrefs: sharing a dataset is handing over a root handle, not a path or hostname.
- Encourage mutable overlays in user space (COW views), but require commits to land as immutable objects with explicit ancestry.

Evidence plan:
- Prototype: a small CAS store + root manager + CLI; demo user-data snapshots/rollback and cross-machine sync without privileged magic.
- Negative tests: tamper/rollback attempts are detected via digest mismatch and transcript comparisons.

Refs: REF-VENTI-FAST02, REF-AMOEBA-INTRO, REF-AMOEBA-CACM90, REF-FOUNDATION-CAS.

## 39) Persistent object graphs and cross-run sharing without “deserialize the world” (Twizzler line)

Idea: persistent memory pushes pressure toward a programming model where data is directly mapped and shared across processes and across time. Twizzler’s object-relative pointers and resolver story offer a clean “object graph” framing that avoids rebuilding state from byte streams on every restart.

Candidate decision: D-PERSIST (object profile; capstore via CH-CAPSTORE); D-CAP (revocation/epochs).

Minimal seam:
- Keep persistence as a user-space service, but preserve an OS-level *seam* for mapping persistent objects (read-only by default) and cloning/snapshotting them cheaply (COW).
- Make object identity explicit (stable object IDs) and require resolver-mediated cross-object pointer resolution (no ambient global names).
- Tie persistent references to revocation epochs so old references can be invalidated deterministically during recovery/rotation.

Evidence plan:
- Prototype: a minimal persistent-object mapper + resolver with epoch-based invalidation; demo two apps sharing an object graph safely across restarts.
- Abuse tests: pointer forgery, stale epoch replay, and cross-app correlation via resolver metadata.

Refs: REF-TWIZZLER-ATC20, REF-TWIZZLER-TR17.

## 40) Process containers / job objects: unify group limits + lifecycle cleanup
- Summary: systems need a first-class “process unit” that can carry limits/accounting *and* deterministic teardown semantics (kill-on-close / subtree cleanup) without ad-hoc parent tracking.
- Candidate decision: D-METER + D-SUPV.
- Minimal seam:
  - A user-space supervisor creates a container/job realm and spawns children into it by default.
  - Container root holds the control handle; control handles are non-inherited by default.
  - Meter lineage aligns with the container tree (“who pays” follows “who owns the unit”).
- Invariants / POs:
  - I-METER-3 (explicit payer), I-SUPV-1 (restart is non-amplifying).
  - PO-METER-DELEGATE (delegation lineage).
- Evidence plan: E1 prototype showing: (a) kill-on-close semantics for a subtree, (b) quotas accounted at container root, (c) no escape via inherited control handle.
- References: REF-WIN-JOBOBJECTS, REF-CGROUPV2, REF-CGROUP-DELEGATION, REF-FUCHSIA-JOBS.

## 41) Death-watch notifications: make liveness an explicit message
- Summary: if “endpoint died” is a first-class signal, supervisors and revocation/cleanup logic become simpler and more deterministic than timeout-heavy designs.
- Candidate decision: D-CAPRPC + D-SUPV.
- Minimal seam:
  - Allow registering a one-shot watch on an endpoint/object-cap.
  - Deliver a bounded notification to a watcher capability (no unbounded queues; rate-limited).
- Invariants / POs:
  - I-SUPV-1 (no authority gain via restart), I-CAP-1 (no ambient authority).
  - PO-ABI-TOTAL (watch registration is a closed effect in CH-KABI).
- Evidence plan: E1 tests: crash a supervised service and verify watch delivery + cleanup; fuzz registration/unregistration edge cases.
- References: REF-MACH-REQUEST-NOTIFY.

## 42) Fast local RPC handles as user-space “service fds” (Doors-style)
- Summary: local RPC stays usable when “the service handle” is just another transferable object and can be published for discovery without ambient globals.
- Candidate decision: D-CAPRPC + D-NS.
- Minimal seam:
  - Treat local RPC endpoints as first-class capabilities that can be stored, passed, and optionally attached into service trees.
  - Provide an optional local fast path (copyless when possible) without adding an in-kernel scripting surface.
- Invariants / POs:
  - I-CAP-1 (no ambient authority); I-IF-1 (closed decode surface).
- Evidence plan: microbench: local cap-RPC latency under load; fault tests for publish/unpublish and handle revocation.
- References: REF-SOLARIS-DOORS.

## 43) Constructor/factory components + confinement tests (KeyKOS/EROS/Hydra lineage)
- Summary: most capability/security failures happen during **composition and initialization**. A repeatable constructor/factory pattern plus a confinement test (cap-graph delta) makes “build a confined subsystem” regression-testable.
- Candidate decision: D-CONSTR (see RFC-0042).
- Minimal seam:
  - Constructors are ordinary user-space components that take (a) pinned template digests (CH-COMP/CH-INIT fragments) and (b) parameter data, then return an explicit exported surface.
  - A standard confinement test exports cap-graphs pre/post and fails closed if new caller-reachable authority exceeds the declared exports.
  - Prefer brands (sealers/unsealers) at the boundary to avoid type confusion when wrapping references.
- Invariants / POs:
  - I-CONSTR-1/I-CONSTR-2; PO-CONSTR-CONFINE.
- Evidence plan: E1: one real constructor (e.g., “sandboxed worker pool” or translator-backed mount service) + the confinement test harness (cap-graph diff).
- References: REF-KEYKOS-ARCH85, REF-KEYKOS-FACTORY, REF-EROS-CONFINEMENT, REF-HYDRA-CH6, REF-CAPMYTHS.

## 44) Interop-friendly networked object-capability transport (CapTP/OCapN)
- Summary: if we ever want remote capabilities to be “normal,” we need explicit introduction semantics, stable reference identities, and disconnect as a first-class result — without smuggling in ambient DNS/sockets.
- Candidate decisions: D-CAPX + D-CAPRPC (gateway profile; see RFC-0004).
- Minimal seam:
  - Treat remote-cap use as a user-space gateway that speaks a capability protocol (CapTP/OCapN lineage) and exchanges CH-CAPX envelopes.
  - Keep the privileged core unaware: the kernel only sees local object caps; the gateway mediates remote messages.
  - Standardize “eventual send”/promise semantics at the boundary to avoid hidden blocking and to make latency tolerance explicit.
- Invariants / POs:
  - I-CAPX-1/I-CAPX-2; PO-CAPX-BIND/PO-CAPX-ATTEN; PO-CAPRPC-PIPELINE (if enabled).
- Evidence plan: prototype a minimal gateway with deterministic negative tests (no ambient network acquisition; replayable disconnect behavior).
- References: REF-CAPTP, REF-OCAPN.

## 45) Wait sets + object signals for scalable event loops (epoll/kqueue/IOCP/Zircon ports)
- Summary: ecosystems that make async I/O and event-driven services *pleasant* converge on a single primitive: wait efficiently on many event sources. Without it, stacks drift into polling, bespoke notification APIs, and shutdown-time resource leaks.
- Candidate decision: D-WAITSET (see RFC-0106).
- Minimal seam:
  - Standardize a small, closed set of **signal bits** per object type (readable/writable/peer_closed/terminated/etc.).
  - Provide a WaitSet/port object that can bind `(handle, mask, tag)` and return bounded event batches.
  - Enforce explicit, deterministic overflow behavior (no silent drops) and bounded registrations per domain.
  - Compose with D-REQCTX cancellation/deadlines without ambient time (deadlines require explicit Clock handles when D-NONDET is enabled).
- Invariants / POs:
  - I-WAITSET-1/I-WAITSET-2/I-WAITSET-3; PO-WAITSET-BOUND/PO-WAITSET-NOAMP.
- Evidence plan: EVID-2026-109 harness plan (churn/overflow/cancel/no-ambient-time) + microbench (wait_many vs WaitSet).
- References: REF-ZIRCON-SIGNALS, REF-ZIRCON-OBJECT-WAIT-MANY, REF-ZIRCON-PORT-WAIT, REF-LINUX-EPOLL, REF-BSD-KQUEUE, REF-WIN-IOCP.


## 46) I/O submission queues + completion events: a standard batching seam (io_uring / I/O Rings shape)
- Summary: high-throughput ecosystems eventually need a way to **batch** I/O operations and harvest completions without per-op boundary crossings. If we don’t standardize a seam, stacks accumulate bespoke shared-memory request arrays and one-off fast paths.
- Candidate decision: D-IOQ (see RFC-0107) (adjunct: D-WAITSET, D-IOBUF, D-REQCTX, D-METER).
- Minimal seam:
  - Provide an optional **IoQueue** object with bounded submission/completion rings and a closed opcode set.
  - Operations target only **explicit handles** (no ambient paths); buffer sharing uses explicit shared buffers (D-IOBUF) when enabled.
  - Completions integrate with **D-WAITSET** signal bits so event loops don’t grow a second polling API.
  - Enforce strict bounds: ring sizes, outstanding ops, deterministic overflow behavior; charge allocations to meters when D-METER is enabled.
- Invariants / POs:
  - I-IOQ-1/I-IOQ-2/I-IOQ-3; PO-IOQ-BOUND/PO-IOQ-NOAMP.
- Evidence plan:
  - EVID-2026-110 harness + microbench (per-op IPC vs batched IoQueue for a small closed op set).
- References: REF-LINUX-IOURING-PDF, REF-LINUX-IOURING-MAN7, REF-WIN-IORING-OVERVIEW.


## 47) Quiescence + drain protocol: make maintenance a testable contract
- Summary: ecosystems tend to converge on multi-step shutdown (stop accepting work → drain for a bounded grace period → force kill). If we standardize a small cooperative quiesce contract early, we avoid per-service stop semantics drift and make checkpoint/upgrade pipelines reliable.
- Candidate decision: D-QUIESCE (see RFC-0108) (adjunct: D-REQCTX, D-SUPV, D-ACTIVATE, D-CHKPT).
- Minimal seam:
  - `BeginQuiesce(DRAIN|CANCEL)` capability-gated control action.
  - While QUIESCING, externally-triggered entrypoints deterministically reject with `QUIESCING` (or an explicitly declared queueing policy).
  - Optional `QUIESCENT` waitability (D-WAITSET adjunct) and optional bounded CH-QUIESCE descriptor for transcript correlation.
  - `EndQuiesce(qid)` returns to RUNNING; invalid qid transitions reject deterministically.
- Invariants / POs:
  - I-QUIESCE-1/I-QUIESCE-2/I-QUIESCE-3; PO-QUIESCE-STATE/PO-QUIESCE-GATE.
- Evidence plan:
  - EVID-2026-111 harness plan (new-work gating, explicit cancel outcomes, checkpoint-cut integration).
- References: REF-ERLANG-RELEASE-HANDLING, REF-KUBE-LIFECYCLE-HOOKS, REF-SYSTEMD-SERVICE, REF-LINUX-CGROUP-FREEZER.

## 48) Flight recorder retention rings + incident capture triggers
- Summary: keep the last N seconds/minutes of selected logs/traces/state in bounded ring buffers so crashes/hangs can produce reliable incident captures without “please reproduce with debug logging.”
- Candidate decision: D-FLIGHTREC.
- Minimal seam:
  - a pinned retention policy artifact (CH-FLIGHTPOL) describing per-stream bounds and trigger rules
  - a user-space collector that retains streams and assembles CH-SNAPSHOT bundles on triggers (crash/watchdog/operator/test)
  - export remains CH-OBSPOL scoped and explicitly authorized (no ambient auto-export)
- Invariants / POs:
  - I-FLIGHT-1..3, I-OBSPOL-1, I-OBS-1.
  - PO-FLIGHT-BOUND, PO-FLIGHT-ACCESS.
- Evidence plan: EVID-2026-112 ring-buffer stress tests + deterministic overload behavior + crash-triggered snapshot assembly.
- References: REF-LINUX-RAMOOPS, REF-LINUX-PSTORE, REF-MS-ETW, REF-SYSTEMD-JOURNALD, REF-ANDROID-BUGREPORT, REF-APPLE-SYSDIAGNOSE.

## 49) Wait-on-address (futex) primitives: stop spinning and stop allocating events-per-lock
- Summary: multithreaded runtimes need an efficient way to block on contended locks/condvars without spinning or allocating heavyweight kernel objects. Most OSes converge on a futex-like **wait-on-address** primitive: uncontended operations are user-space atomics; only contention enters the kernel for queueing and scheduling.
- Candidate decision: D-UWAIT (see RFC-0110) (adjunct: D-REQCTX, D-METER, D-RR).
- Minimal seam:
  - process-local `uaddr_wait/uaddr_wake` keyed by normalized user addresses (strip pointer tags when applicable), with `{1,2,4,8}` byte sizes.
  - bounded waiter state (per-process and per-address), chargeable when D-METER is enabled; exhaustion returns deterministic errors.
  - optional D-REQCTX integration so timeouts/cancel have deterministic outcomes without ambient time.
  - explicitly defer PI/owner variants until scheduling profiles justify them.
- Invariants / POs:
  - I-UWAIT-1/I-UWAIT-2/I-UWAIT-3; PO-UWAIT-BOUND/PO-UWAIT-ATOMIC.
- Evidence plan: EVID-2026-113 harness: a minimal mutex+condvar implementation, lost-wake regression tests, bounds/charging stress tests, and replay hook coverage.
- References: REF-MS-WAITONADDRESS, REF-MS-WAKEBYADDRESSSINGLE, REF-MS-WAITFUNCS, REF-LINUX-FUTEX2, REF-LINUX-FUTEX-PAPER, REF-FREEBSD-UMTX-OP, REF-FUCHSIA-FUTEX.


## 50) Robust locks / owner-death semantics: don’t deadlock forever when a lock owner dies
- Summary: if a thread/process terminates while holding a user-space lock stored in shared memory (common in runtimes, SHM IPC, and multi-component systems), other participants can block forever. Mature OSes expose an explicit “owner died / abandoned” outcome (Linux robust futexes; Windows WAIT_ABANDONED) so the next acquirer can repair or fail-close.
- Candidate decision: D-ROBUSTLOCK (see RFC-0111) (adjunct: D-UWAIT, D-METER, D-RR).
- Minimal seam:
  - an opt-in **RobustSet** (quota-bounded) capability that registers shared lock-word addresses within writable/shared regions.
  - on abnormal owner exit, kernel sets an **OWNER_DIED** flag in the lock word and performs a bounded wake (typically via D-UWAIT).
  - the next acquirer receives an explicit `owner_died` result and must either call `make_consistent()` (clear flag after repair) or abandon/restart.
- Invariants / POs:
  - I-ROBUST-1/I-ROBUST-2/I-ROBUST-3; PO-ROBUST-BOUND/PO-ROBUST-NOREUSE.
- Evidence plan: EVID-2026-114 harness: kill owner mid-critical section, verify wake+flag, bounds/charging, and replay hooks.
- References: REF-LINUX-ROBUST-FUTEX-ABI, REF-KERNEL-ROBUST-FUTEXES-TXT, REF-LINUX-GET-ROBUST-LIST, REF-FREEBSD-UMTX-OP, REF-WIN-WAIT_ABANDONED.


## 51) Grace periods (RCU/QSBR/EBR): make read-mostly sharing + reclamation standard
- Summary: once systems have shared regions and long-lived services, they accumulate read-mostly shared state (inspect trees, routing tables, registries). Without a standard grace-period seam, stacks drift into either coarse locks (latency) or bespoke lock-free schemes (use-after-free hazards). Mature ecosystems converge on **grace periods** (RCU/QSBR/EBR) for “publish new version, wait, reclaim old”.
- Candidate decision: D-RCU (see RFC-0112) (adjunct: D-UWAIT, D-WAITSET, D-METER, D-SUPV).
- Minimal seam:
  - a per-subsystem **GraceDomain** handle (user-space service/library preferred) supporting `read_enter/read_exit` (or explicit quiescent points for QSBR profiles) and `synchronize()`.
  - optional `defer_free` queues that reclaim only after a completed grace period.
  - strict bounds: participant registration limits and deferred-free backlog caps; overflow is explicit and deterministic; limbo state is chargeable when D-METER is enabled.
  - waiting should block efficiently (D-UWAIT) or integrate with D-WAITSET signals (avoid polling loops).
  - stall posture is explicit: prolonged non-quiescence triggers supervision/restart rather than silent unbounded retention.
- Invariants / POs:
  - I-RCU-1/I-RCU-2/I-RCU-3; PO-RCU-BOUND/PO-RCU-NOORACLE.
- Evidence plan: EVID-2026-115 GraceDomain prototype + harness (reader traversal under concurrent publish, bounded limbo, stall simulation, deterministic overflow).
- References: REF-LINUX-RCU-WHATIS, REF-LINUX-RCU-CONCEPTS, REF-MCKENNEY-PERFBOOK, REF-HAZARD-POINTERS-MICHAEL, REF-FRASER-PRACTICAL-LOCK-FREEDOM.


## 52) Restartable sequences (rseq): bounded CPU-local fast paths without atomics everywhere
- Summary: high-performance runtimes often want **per-CPU** sharding (allocators, counters, queues). Pure atomics/locks can be expensive; kernel-managed per-CPU objects expand TCB. A small rseq-like primitive enables a class of *bounded* “CPU-local fast paths” that abort cleanly on preemption/migration and fall back to slow paths.
- Candidate decision: D-RSEQ (see RFC-0113) (adjunct: D-SCHED, D-NONDET, D-UWAIT, D-RR, D-METER).
- Minimal seam:
  - per-thread registration of a small “rseq area” used as an ABI (cpu/vcpu id cache + sequence).
  - a closed contract for restartable regions: start/commit/abort addresses and stable abort reason codes; **single commit point** (“no partial commit”).
  - profile gating: enable only where cpu/vcpu id exposure is acceptable (D-NONDET posture); D-RR profiles must disable or virtualize rseq outcomes.
  - strict bounds: region length, no faults/IPC/blocking, bounded registrations; charge bookkeeping to meters when D-METER is enabled.
- Invariants / POs:
  - I-RSEQ-1/I-RSEQ-2/I-RSEQ-3; PO-RSEQ-BOUND/PO-RSEQ-NONDET.
- Evidence plan: EVID-2026-116 harness (forced aborts under migration/preemption; “no partial commit” tests; bounds + abort-rate observability; profile gating).
- References: REF-LINUX-RSEQ-DOC, REF-LINUX-RSEQ-MAN, REF-REDHAT-RSEQ-GLIBC, REF-LWN-RSEQ-GLIBC.


## 53) Verified blobs (fs-verity / dm-verity): Merkle integrity for immutable content
- Summary: ecosystems ship huge immutable artifacts (base OS trees, packages, model weights). Without a standard verified-read seam, stacks drift into ad-hoc hashing, fragile signatures, or “trust the storage” assumptions. Mature OSes converge on **Merkle-tree verified reads**: dm-verity for read-only volumes and fs-verity for file-level verification.
- Candidate decision: D-VERITY (see RFC-0114) (adjunct: D-ATOMICUPD, D-BOOT, D-PAGER, D-DYNCODE, D-AREF, D-METER).
- Minimal seam:
  - a **VerifiedBlob** handle type for immutable content; reads verify and **fail closed** on mismatch.
  - a bounded identity/intent descriptor **CH-VBLOB v0** (non-authoritative) that can be pinned in CH-BOOT/CH-UPD `artifacts[]` and included in transcripts/bundles.
  - allow file-level (fs-verity style) and volume-level (dm-verity style) implementations; keep verification in user-space storage/pager domains when possible.
  - strict bounds and attribution for verification metadata/caches; avoid turning “verify” into unbounded CPU/I/O work.
- Invariants / POs:
  - I-VERITY-1/I-VERITY-2/I-VERITY-3; PO-VBLOB-VALIDATE/PO-VERITY-ENF/PO-VERITY-BOUND.
- Evidence plan: EVID-2026-117 harness: CH-VBLOB validator tests, corruption fail-closed reads, bounded-cache stress tests, and integration with deployment digests (D-ATOMICUPD) and executable provenance checks (D-DYNCODE).
- References: REF-LINUX-FSVERITY, REF-LINUX-DMVERITY, REF-ANDROID-DMVERITY, REF-ANDROID-AVB2-README.



## 1o) Veto-only privilege bracketing for plugin/helper ecosystems (Java stack inspection lesson)
- Summary: even with explicit capabilities, real ecosystems accumulate in-process “deputies” (shared helpers, plugins, compatibility layers) that can accidentally use the host’s internal authority. Bake in a user-space convention where privileged capabilities are **inaccessible by default** while servicing inbound requests, unless code explicitly enters a scoped privileged block.
- Candidate decision: **D-BRACKET** (RFC-0118), adjunct to D-REQCTX/D-PLUMB/D-CAPSHELL.
- Minimal seam:
  - Runtime/library pattern: classify some held caps as *privileged*; run inbound handlers in **borrowed mode** (privileged caps dark); allow privileged effects only in `with_privileged { ... }`.
  - Optional audit hook: attach a bounded CH-CALLCHAIN digest to CH-REQCTX v1 for postmortems and deny-only routing.
  - Keep it **veto-only**: call-chain/context metadata must not grant authority.
- Evidence plan: EVID-2026-118 harness showing borrowed-mode denials, exception-safe scoping, and a deny-only routing example.
- References: REF-CONFUSED-DEPUTY, REF-JAVA-STACKINSPECT, REF-JAVA-DOPRIVILEGED.
