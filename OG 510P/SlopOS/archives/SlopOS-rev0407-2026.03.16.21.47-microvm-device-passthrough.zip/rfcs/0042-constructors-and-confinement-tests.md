# RFC-0042: Constructor objects and confinement tests (D-CONSTR)

Status: Draft  
Last updated: 2026-03-08

Goal: make “build a confined subsystem” a **repeatable, auditable pattern** by standardizing **constructor components** (user-space factories) and a **confinement test** that detects authority leaks using our existing cap-graph / transcript seams.

Pinned v0 posture: `docs/30-architecture/constructor-posture-v0.md` resolves the Phase 1 option set to **ordinary user-space factories plus confinement evidence**. Constructors consume digest-pinned templates and schema-pinned **data-only** parameter objects, return only an explicit exported surface, and rely on cap-graph diff + transcript evidence rather than a constructor brand. Phase 1 declines a kernel constructor framework, a global constructor catalog/inventory, and any generic constructor portal family / ACP / workflow plane. The reusable constructor-family invocation split is now pinned in `docs/30-architecture/constructor-boundary-pattern-v0.md`: template digests + data-only params + explicit authority-import slots + bounded export contracts + receipt bindings, with no generic constructor request/receipt protocol in v0.

Motivation sources: KeyKOS/EROS “constructors” and confinement reasoning (incl. mechanized arguments for the confinement mechanism), plus the broader capability-systems lesson that *construction is where ambient authority sneaks in*. Refs: REF-KEYKOS-NANOKERNEL, REF-KEYKOS-ARCH85, REF-KEYKOS-OSR92, REF-EROS-CONFINEMENT, REF-CAPMYTHS, REF-SHILL-OSDI14.

Non-goals:
- A kernel-resident “constructor framework” (keep TCB small).
- Magical global guarantees (“all constructed subsystems are safe”) without explicit scopes and evidence.
- Making constructors mandatory for all software.

## Problem
Even if the kernel/hypervisor is capability-pure, **composition is where mistakes happen**:
- a template accidentally leaves a powerful capability reachable,
- a helper service holds “just-in-case” authority forever,
- post-init wiring silently widens authority.

We already have seams that can make these failures visible:
- CH-COMP (D-COMP) for declared wiring,
- CH-LOG transcripts for effect provenance,
- D-CAPAUD cap-graph export + leak tests (RFC-0035).

What’s missing is a **first-class pattern** for “stamp out this subsystem repeatedly without re-auditing a new pile of init code every time.”

## Proposal

### 1) Define “constructor components” as normal components
A **constructor** is a standard user-space component that:
- receives a **template reference** (digest of a pinned artifact set; typically CH-COMP and/or CH-INIT fragments),
- receives a small **parameter object** (names, sizes, policy knobs) that is *data, not authority*,
- receives any authority-bearing inputs only through **explicit import slots** rather than through serialized parameter fields,
- returns a **sealed handle** to the constructed subsystem plus an explicit set of exported capabilities (the public surface).

Key rule: the constructor may only *use* authority it already holds. Construction never justifies adding privileged mechanisms.

**Resolved for v0 boundary pattern**: the smallest reusable constructor-family shape is now pinned in `docs/30-architecture/constructor-boundary-pattern-v0.md`: keep template digests, data-only parameters, explicit authority imports, export contracts, and transcript bindings separate, and do **not** standardize a generic constructor request/receipt schema in Phase 1.

### 2) Treat the constructor boundary as an explicit authority boundary
For each constructor, we define a boundary contract:

- **Inputs (authority in):** the capabilities passed to the constructor (including any template fetch capability, space bank, etc.).
- **Outputs (authority out):** the exported surface capabilities returned to the caller.

Confinement means: **no other authority crosses the boundary**, and the constructed internal graph cannot retain backchannels that let the caller gain more than the outputs.

### 3) Standard “confinement test” based on cap-graph diffs
Leverage D-CAPAUD (RFC-0035) to define a standard test:

1. Export a **capability graph snapshot** of:
   - the caller before construction (baseline),
   - the constructor + subsystem after construction (post-state),
2. Compute a bounded **authority delta** at the boundary:
   - the only new “caller-reachable” authorities are the declared constructor outputs,
   - no “leaked” references to internal capabilities exist outside the declared exports,
3. Optionally, run “negative tests” by revoking/attenuating the exported surface and verifying the caller cannot still reach the internal objects (interacts with D-MEMBRANE / RFC-0019).

This is not a proof by itself, but it is a **high-signal regression test** that catches the common failure modes early.

### 4) Integration points (minimal)
- **D-COMP / CH-COMP:** templates are pinned and linted; constructors can emit CH-LOG entries tying instantiation to template digests.
- **D-SEAL:** constructors should run an init→seal transition for constructed services when applicable.
- **D-METER / D-KOBJQ:** constructors are natural sites to “charge” creation costs to a budget/space bank so subsystems can be garbage-collected and accounted.
- **D-CHKPT (optional):** constructor outputs can be checkpointed as a unit for “factory reset” or migration.
- **D-COMMUTE:** v0 introduces **no generic constructor conflict-key family**. Fresh isolated instantiations commute; instantiations that mutate an existing owner-visible slot/name/export table must reuse that target seam’s existing conflict keys and ordering witnesses instead of inventing a constructor-global sequencing plane.

## Candidate invariants / proof obligations
- **I-CONSTR-1 (Constructor confinement, optional):** if D-CONSTR is enabled for a constructor template, the only new caller-reachable authority introduced by instantiation is the declared exported surface; no other authority leaks across the boundary.
- **I-CONSTR-2 (Deterministic construction, optional):** given the same template digests and the same parameter object, the constructor produces the same exported surface structure (up to declared nondeterminism like fresh object IDs).
- **PO-CONSTR-CONFINE:** confinement tests (cap-graph export + delta checks) are sound w.r.t. the declared boundary predicate and fail closed when bounds are exceeded.
- **PO-CONSTR-REPLAY (optional):** constructor events are transcript-logged with enough detail (digests + parameter hashes) to reproduce the construction in replay/testing modes.

## Evidence plan (stageable)
E1 (prototype-to-evidence):
- implement the pinned first constructor family: **sandboxed worker pool** (`docs/30-architecture/worker-pool-constructor-family-v0.md`)
- implement the first concrete harness contract in `docs/40-verification/worker-pool-constructor-harness-v0.md` so confinement/replay evidence is fixed before more constructor families appear
- emit that evidence in the canonical handoff/member-label normal form pinned in `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- keep the canonical `capgraph.before` / `capgraph.after` members on the exact `docs/40-verification/worker-pool-capgraph-snapshots-v0.md` contract instead of whole-system/helper-visible graph folklore
- keep the install-only `target.before` / `target.after` members on the exact `docs/40-verification/worker-pool-target-projection-v0.md` contract instead of target-name or inventory folklore
- keep the compact case-indexed result layer on the exact `docs/40-verification/worker-pool-verdict-summary-v0.md` contract instead of prose-only or flaky/warning result folklore
- keep the exact required `sponsor` meaning on the narrow explicit sponsorship surface pinned in `docs/30-architecture/worker-pool-sponsor-surface-v0.md`
- keep the exact optional `install_target` meaning on the narrow publication-only surface pinned in `docs/30-architecture/worker-pool-install-target-surface-v0.md`
- keep the exact `worker_seed/<label>` meaning on the narrow pool-wide surface pinned in `docs/30-architecture/worker-pool-seed-surface-v0.md`
- keep the exact digest-first invocation-manifest object pinned in `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- keep the exported `pool.control` handle on the exact bounded surface pinned in `docs/30-architecture/worker-pool-control-surface-v0.md`
- keep the exported `worker[i]` handles on the exact bounded surface pinned in `docs/30-architecture/worker-pool-worker-surface-v0.md`
- implement the confinement test harness using the cap-graph exporter

E2 (model-check fast):
- model a small constructor + graph and search for leak counterexamples (align with RFC-0035 methodology)

E3 (mechanize boundary):
- represent the boundary predicate in the abstract machine and show refinement for a bounded constructor interface

## Alternatives
1) **No constructors**: copy/paste init logic per subsystem.  
   - Con: repeated audits; high leak risk.

2) **Templating without confinement tests**.  
   - Con: “policy-as-data” without regression evidence tends to drift.

3) **Kernel-level constructors**.  
   - Con: TCB expansion and proof surface increase; likely unacceptable early.

## Open questions
- How much replay material beyond template/parameter digests and contract digests should constructor transcripts carry before they become too verbose for routine workflows?

Resolved for exact transcript-slice contract: the first worker-pool constructor now has one exact bounded `transcript.slice` meaning in `docs/40-verification/worker-pool-transcript-slice-v0.md`: it is a case-indexed window set over ordered `CH-LOG v0` references, stable case ids own the layout, `fresh-commute` / `install-conflict` each carry `primary` + `swapped` order variants, and Phase 1 declines whole-log dumps or tool-local transcript layouts.

Resolved for first evidence target: Phase 1 now chooses the **sandboxed worker-pool family** as the first concrete D-CONSTR harness because it exercises explicit launch closure, sealing, budgets, and cap-graph confinement evidence without importing namespace or microVM-specific control planes (`docs/30-architecture/worker-pool-constructor-family-v0.md`).

Resolved for first harness contract: the first concrete D-CONSTR evidence contract is `docs/40-verification/worker-pool-constructor-harness-v0.md`, which freezes the invocation digest set, caller-scoped cap-graph delta predicate, replay bindings, and fresh-vs-install ordering tests so future constructor work starts from one closed harness shape instead of ad-hoc evidence folklore.

Resolved for exact family-local invocation profile: the first worker-pool constructor now has one exact invocation boundary in `docs/30-architecture/worker-pool-constructor-invocation-v0.md`: required imports are `sponsor`, zero or more `worker_seed/<label>` slots, and optional `install_target`; params stay data-only and bounded; exported names are canonically `pool.control` plus `worker[i]`; and non-commuting install cases serialize on the target seam rather than inventing label-map or constructor-global ordering folklore.

Resolved for exact family-local parameter schema: the first worker-pool constructor now has one exact digest target for `param_digest` in `docs/30-architecture/worker-pool-parameter-schema-v0.md`: `CH-WPOOLPARAM v0` carries only `pool_size` plus the per-slot restart budget (`restart.max_restarts`, `restart.window_ms`), disables automatic replacement exactly when both are `0`, and keeps `sponsor` / `worker_seed/<label>` / `install_target` out of the object so replay/runtime tooling cannot fork family-local parameter folklore.

Resolved for exact worker-pool sponsor import: the first worker-pool constructor now has one exact `sponsor` meaning in `docs/30-architecture/worker-pool-sponsor-surface-v0.md`: it is required exactly once as the pool-wide reviewed sponsorship root, cannot fall back to ambient caller/session identity, stays immutable for one pool instance, is not reflected on `pool.control` or `worker[i]`, and Phase 1 declines sponsor rotation, per-worker payer splits, and sponsor-inventory/admin drift.

Resolved for exact worker-pool install target: the first worker-pool constructor now has one exact `install_target` meaning in `docs/30-architecture/worker-pool-install-target-surface-v0.md`: it is a publication-only owner-visible target seam for the canonical `pool.control` + `worker[i]` export set, install mode stays distinct from return-only mode, publication is all-or-nothing, and Phase 1 declines rename/remap/catalog or duplicate direct-return drift.

Resolved for exact worker-pool seed imports: the first worker-pool constructor now has one exact `worker_seed/<label>` meaning in `docs/30-architecture/worker-pool-seed-surface-v0.md`: each seed label binds a reviewed worker import label, the seed-label set is pool-wide and uniform across all worker slots, missing/extra labels fail closed, and Phase 1 declines per-worker seed maps, reflected import inventories, and reseed-after-construction semantics.

Resolved for first evidence-pack normal form: the first worker-pool constructor harness now has one canonical handoff pack in `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`: member labels are fixed as `invocation.manifest`, `capgraph.before`, `capgraph.after`, `transcript.slice`, `verdict.summary`, and install-only `target.before` / `target.after`, while verdicts key off stable case ids rather than prose-only naming.
Resolved for exact cap-graph snapshot contract: the first worker-pool constructor now has one exact `capgraph.before` / `capgraph.after` meaning in `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`: both members are caller-scoped same-profile `CH-CAPG v0` receipts over one shared observation scope, comparison keys off the normalized caller-reachable delta only, the only permitted new caller-visible graph material is the canonical `pool.control` + `worker[i]` export surface, and Phase 1 declines whole-system/helper-visible graph dumps or target/install folklore on the canonical pair.

Resolved for exact target-projection contract: the first worker-pool constructor now has one exact install-only `target.before` / `target.after` meaning in `docs/40-verification/worker-pool-target-projection-v0.md`: both members are `CH-SPROJ v0` receipts over the same target-seam `(family, key_digest)` pair, each carries one canonical digest over exactly `pool.control` plus `worker[i]`, fresh cases omit the pair entirely, and Phase 1 declines target-name folklore or inventory/list/watch drift on the canonical evidence surface.

Resolved for exact verdict-summary contract: the first worker-pool constructor now has one exact compact `verdict.summary` meaning in `docs/40-verification/worker-pool-verdict-summary-v0.md`: it is a stable case-id verdict table over the canonical worker-pool export shape, top-level fields are fixed to `family`, `invocation_manifest_digest`, `pool_size`, `export_shape`, `overall_verdict`, and `cases`, each case row carries explicit `delta_predicate_ok` / `replay_predicate_ok` bits, and Phase 1 declines prose-only, flaky, skipped, or target-name result folklore.

Resolved for exact invocation-manifest contract: the first worker-pool constructor now has one exact digest-first manifest object in `docs/30-architecture/worker-pool-invocation-manifest-v0.md`: `invocation.manifest` / `invocation_manifest_digest` bind one canonical field set (`template_set_digest`, `execpack_digest`, `param_digest`, `pool_size`, import/export contract digests, exact `worker_seed_labels`, and `install_mode`) while excluding target identity, helper handles, and fresh instance state.

Resolved for exact exported control handle: the first worker-pool constructor now has one exact `pool.control` contract in `docs/30-architecture/worker-pool-control-surface-v0.md`: `Describe()` returns one bounded fixed-slot summary including `invocation_manifest_digest`, `BeginQuiesce(mode)` / `EndQuiesce(qid)` are the only mutators, and Phase 1 declines scale/reseed/restart/job/admin verbs so the exported control handle cannot turn into a hidden scheduler or second constructor path.

Resolved for exact `Describe()` summary contract: the first worker-pool constructor now has one exact family-local `Describe()` result shape in `docs/30-architecture/worker-pool-describe-summary-v0.md`: the top-level field set is closed to `v`, `invocation_manifest_digest`, `pool_size`, `quiesce_state`, optional `qid`, and `worker_slots`; `qid` follows one exact presence rule; and `worker_slots` is one ordered gap-free slot table instead of an implementation-defined status tree.

Resolved for exact worker-pool `quiesce_state` meaning: the first worker-pool constructor now has one exact pool-level meaning for `quiesce_state` in `docs/30-architecture/worker-pool-quiesce-state-v0.md`: the portable pool vocabulary is closed to `running`, `quiescing`, and `quiescent`; `qid` is absent only in `running`; `quiescent` keeps the active `qid` in force until `EndQuiesce(qid)`; and Phase 1 declines mixed/partial/mode folklore on the canonical summary surface.

Resolved for exact worker-slot state model: the first worker-pool constructor now has one exact meaning for `worker_slots[*].state` in `docs/30-architecture/worker-pool-slot-state-v0.md`: the portable slot vocabulary is closed to `starting`, `running`, `backoff`, `failed`, and `quiescing`; Phase 1 deliberately adds no separate per-slot `quiescent` state; `backoff` is the only temporary-unavailable state; and active pool quiesce suppresses automatic `backoff -> starting` re-entry until `EndQuiesce(qid)` releases ordinary admission again.

Resolved for exact restart-budget semantics: the first worker-pool constructor now has one exact operational meaning for `restart.max_restarts` / `restart.window_ms` in `docs/30-architecture/worker-pool-restart-budget-v0.md`: the budget is per-slot, counts only automatic `backoff -> starting` admissions, the initial fresh occupant does not consume budget, disabled budgets (`0` / `0`) fail closed directly to `failed`, successful occupancy only ages admissions out of the trailing window, and Phase 1 declines pool-wide crash scores or portable retry-timer folklore.

Resolved for exact exported worker entry handle: the first worker-pool constructor now has one exact `worker[i]` contract in `docs/30-architecture/worker-pool-worker-surface-v0.md`: each exported worker handle is a slot-stable typed entry handle for the pinned worker closure, not a raw occupant identity token or per-worker admin wrapper; future calls/new sessions MAY reach a restarted slot occupant, but Phase 1 declines transparent in-flight replay, hidden live-session continuity, and per-worker lifecycle/debug verbs on `worker[i]`.

