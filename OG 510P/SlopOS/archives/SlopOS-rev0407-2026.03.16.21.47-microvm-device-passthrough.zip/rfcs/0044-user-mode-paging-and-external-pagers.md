# RFC-0044: User-mode paging and external pagers (D-PAGER)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-PAGER

## Summary
Introduce an **optional** user-mode paging seam where a designated pager service supplies pages for **pager-backed memory objects**, while the kernel stays a thin mechanism layer. The pinned Phase 1 posture is `docs/30-architecture/pager-posture-v0.md`: object-backed only, no generic per-address-space pager profile in v0.

## Motivation
Microkernels repeatedly rediscover the same leverage point: keep the privileged core small, and move **paging policy and backing-store policy** to user space.

Precedents range from classic external pagers in Mach (REF-MACH-EXTPAGER) to “pager IPC” in L4-family designs (REF-L4RE-DS-RM), and modern production demand paging for user-space filesystems in Zircon/Fuchsia (REF-FUCHSIA-PAGER). The payoff is not just modularity; it enables *bespoke* paging policies (compression, encryption, prefetch, app-specific cache heuristics) without permanently growing the privileged TCB (REF-FUCHSIA-BLOBFS-RAC).

## Integration seam / kernel impact (keep small)
Kernel responsibilities (mechanisms only):
- maintain hardware page tables and perform privileged map/unmap operations (already in the CH-KABI `mem.*` family)
- detect faults and deliver **bounded fault requests** to a designated pager endpoint (D-PAGER)
- enforce that any mapping granted in response to a fault is authorized by explicit capabilities (I-MAP-1, I-CAP-1)

Non-goals for the privileged core:
- filesystem caching, compression, prefetching, writeback scheduling
- “magic” implicit fallback pagers or silent kernel heuristics

## Design
### 1) Phase 1 portable posture: pager-backed memory objects
1. **Pager-backed memory object (the pinned v0 posture):**
   - file/cache objects are represented as VM objects with stable offsets.
   - faults are reported in terms of `(object_id, offset, len, access)` rather than raw virtual addresses.
   - matches the Fuchsia “pager-backed VMO” model (REF-FUCHSIA-PAGER).

Per-address-space pagers are deferred out of the portable v0 posture. They may be revisited only as an explicit future profile/RFC if we can justify the extra leakage/admin surface and keep the authority story sharp.

### 2) Fault request message (CH-FAULT v0)
Define a schema for kernel→pager requests: **CH-FAULT v0** (added to the schema registry). The pinned v0 posture emits the object-backed form only; any raw-virtual-address-bearing variant remains reserved for future work.

Design goals:
- bounded, closed enums; no raw kernel object IDs
- minimize leaked address-space details in the shared-object style (prefer offsets over vaddrs)
- include a one-shot “reply capability” (transferred out-of-band as a capability) so only the intended pager can answer this fault

### 3) Pager response
The pager resolves a fault by performing *existing* privileged operations via held authority:
- map a supplied page/frame into the target address space (I-MAP-1)
- or reject/kill if the access is invalid

Key rule: **the pager cannot conjure authority**. Any mapping/grant still requires explicit rights to the target address space and the relevant memory object (I-PAGER-1).

### 4) Writeback (deferred profile)
If we later need “mutable mmap-like files,” follow a staged profile:
- v0: read-only / read-mostly pager-backed objects only
- v1: explicit dirty tracking + writeback semantics inspired by Zircon’s writeback evolution (REF-FUCHSIA-RFC-0226)

## Registries impacted
- **CH-FAULT v0**: add schema spec + schema-registry row
- **I-PAGER-1**: remains the primary invariant for non-amplifying routing
- **PO-PAGER-ROUTE**: remains the primary proof obligation for routing discipline

(Any writeback semantics would likely add a new invariant and PO-ID later; not in v0.)

## Threat-model impact
Main risks:
- **DoS / priority inversion:** pagers become part of the critical path for fault resolution.
- **Authority leakage:** if a shared pager learns per-process addresses/access patterns.
- **Side channels:** fault timing and working-set shape can leak information.

Controls:
- keep the shared-object style as the default; it reports offsets, not vaddrs (minimization)
- per-AS pagers are **not part of the pinned v0 posture**; if reintroduced later they would be an explicit trust decision and addressed-TCB expansion for that domain
- bounded queues and deterministic “deny” behavior on overflow

## Assurance/verification impact
Evidence targets (staged):
- property tests: malformed CH-FAULT messages are rejected by pagers and do not crash services
- model-check/paper proof sketch: routing rules preserve I-PAGER-1 and do not introduce implicit sharing

## Observability / operations impact
- fault requests can be sampled/aggregated via IF-OBS, but must follow redaction policy (I-OBS-1)
- when D-RR is enabled, fault events likely become part of the declared nondeterminism boundary (D-RR; CH-RR)

## Alternatives
- kernel-only paging: simpler but pushes caching/policy into the privileged core
- monolithic “kernel filesystem cache” with user-space drivers: still leaks policy into TCB
- per-address-space pager profile: flexible but leaks more address-space information and complicates sharing; deferred from the portable v0 seam

## Evidence plan
- prototype a pager-backed object for a tiny read-only filesystem cache and measure:
  - overhead vs kernel-only fault handler
  - ability to keep CH-KABI unchanged (or nearly unchanged)
  - leak tests showing no new ambient sharing edges

## Open questions
- What is the minimal fault request surface that still supports realistic filesystems (batching, readahead hints) while staying object-backed only in v0?
- How do we bound worst-case memory pressure behaviors without forcing kernel policy back in?
- Under what evidence threshold, if any, would a future per-address-space / self-paging profile be worth the extra leakage/admin surface?
