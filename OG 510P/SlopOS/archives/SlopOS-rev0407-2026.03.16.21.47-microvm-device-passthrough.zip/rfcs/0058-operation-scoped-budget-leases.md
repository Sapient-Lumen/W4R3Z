# RFC-0058: Operation-scoped budget leases (D-BUDGET)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-BUDGET, D-METER, D-PLUMB, D-EXPLAIN

## Summary
Introduce **budget leases**: short-lived, attenuation-only “payment tokens” minted from a meter (D-METER) and attached to effectful requests so that metered work happens **only with an explicit payer** and without accidental sponsorship.

Concrete wire artifact: **CH-BUDGET v0** (a redaction-safe budget descriptor).

## Motivation
D-METER gives us accounting, but UX + correctness hinge on *how payers are selected*:
- confused-deputy billing (client tricks a service into paying),
- “invisible sponsorship” (service pays by default because APIs don’t ask for a payer),
- portal workflows that grant authority without bounding the *cost of using it*.

Greenfield opportunity: make “who pays?” mechanically explicit at API seams.

## Design

### 1) Budget leases are derived from meters
A `BudgetLease` is created by splitting/minting from a `Meter`:
- attenuation-only: limits/scope cannot exceed the parent meter,
- optionally time-bounded (expiry) to encourage operation-scoped use.

A budget lease is a *capability* (for spending) and has a **descriptor** (CH-BUDGET v0) for logs/receipts.

### 2) Metered effects require an explicit budget
For any privileged interface that can allocate/consume metered resources:
- the caller must provide a `BudgetLease` (or an explicit profile exemption),
- charges are applied to that lease atomically,
- if the lease is exhausted/expired → fail closed.

This is the mechanical lever that prevents “service pays by accident”.

### 3) Portal composition: consent + bounds
Portals (D-PLUMB) become a natural place to mint budgets:
- `portal.net` returns (NetDialer, BudgetLease) where budget bounds bytes/connections.
- file export portals can attach budgets for compression/sanitization costs.
- D-EXPLAIN can surface “this action may spend up to X net_bytes”.

### 4) Budget scoping (optional)
Budgets may be scope-narrowed:
- bound to a particular lease/destination digest (e.g., CH-NETLEASE digest),
- bound to a service label,
- bound to an object digest.

v0 keeps scoping informal/policy-defined; future schema versions can standardize popular scopes.

## Threat-model impact
New risks:
- budget laundering (smuggling a powerful budget through an unintended channel),
- budget replay across operations if expiry isn’t used.

Mitigations:
- budgets are capabilities; transfers are explicit and show up as new edges (D-CAPAUD) if enabled,
- encourage short TTLs for portal-issued budgets,
- log budget refs in CH-LOG/receipts for audit.

Cross-cluster note (Hybrid / D-REPL): `quota` remains the observational/additive spend-summary lane, while `budget` remains the owner-routed issuer/credit-placement lane. Replicated `budget` metadata may help routing/audit/staleness checks, but it does **not** create portable spend authority or let a receiver infer spendable credit from cached lineage state alone (see `docs/30-architecture/quota-replication-boundary-v0.md` and `docs/30-architecture/budget-replication-boundary-v0.md`).

New abuse case:
- **AC-049:** budget laundering / “sponsorship by stealth”.

## Assurance/verification impact
New invariants (optional):
- **I-BUDGET-1 (Explicit budget for metered effects):** metered privileged effects require an explicit budget/payer handle (or explicit profile exemption); no implicit sponsorship.
- **I-BUDGET-2 (Budget attenuation-only):** budgets derived from a meter can only narrow limits/scope; they cannot amplify authority.
- **I-BUDGET-3 (Fail-closed charging):** charges are atomic and cannot drive a budget negative; exhaustion/expiry fails closed.

New proof obligations:
- **PO-BUDGET-VALIDATE:** CH-BUDGET decoding/validation is total/canonical; bounds enforced.
- **PO-BUDGET-CHARGE:** charging is atomic and monotonic; no negative balances; exceed limit fails closed.
- **PO-BUDGET-NOIMPLICIT:** metered interfaces have no un-gated entrypoints; server-side sponsorship requires explicitly providing a server budget.

Evidence targets (initial):
- “missing budget → reject” negative tests on metered APIs,
- split/attenuation property tests for budgets,
- regression tests that portal-issued budgets show in receipts.

## Alternatives considered
- **Implicit payer selection:** simplest but repeatedly causes billing confused-deputy failures in real systems.
- **Global “current payer” ambient state:** ergonomically nice but breaks capability discipline and auditability.
- **Always charge the caller’s meter implicitly:** works only if the kernel can always identify the caller and never allows proxying; breaks on mediator services and portals.

## Archive impact
- Adds D-BUDGET decision node.
- Adds CH-BUDGET v0 schema doc + schema registry row.
- Adds I-BUDGET-1..3 and PO-BUDGET-VALIDATE/PO-BUDGET-CHARGE/PO-BUDGET-NOIMPLICIT registry rows.
- Adds AC-049 and evidence placeholder EVID-2026-063.
- Adds cross-links from RFC-0012 (meters/budgets) and RFC-0003 (ecosystem features).
