# RFC-0010: Ambient authority elimination + capability mode (D-CAPMODE)

Status: Draft

Goal: make “no ambient authority” a **mechanically enforceable** property for long-lived services and tenants, without growing the privileged core.

## Problem
Even in a capability-first design, *ambient acquisition* can re-enter through:
- “open by path” syscalls that implicitly consult a global namespace
- implicit environment authority (current directory, inherited globals)
- convenience fallbacks (“if not found in view, try system default”)

This reintroduces AC-008 style bugs (namespace confusion) and makes it harder to justify C-CAP-1 and I-VIEW-1/I-VIEW-2 in an adversarial setting.

## Candidate decision: D-CAPMODE
Phase-1 posture pin: `docs/30-architecture/capmode-posture-v0.md` narrows this RFC to **one-way, no ambient acquire after entry**. This RFC remains the design rationale; the posture doc is the authoritative v0 meaning.

Introduce an **optional** per-domain mode switch:
- `capmode = off` (default): domain may still use explicit view objects, but legacy/bring-up profiles may allow controlled “acquire” operations.
- `capmode = on`: domain **cannot acquire new authority from ambient namespaces**; only explicit capability derivation and explicit capability receipt can create new authority edges.

This mirrors the *spirit* of Capsicum’s capability mode and CloudABI/WASI design principles, but maps it onto our view-object model rather than POSIX globals.

## Minimal seam (what we spec)
We do **not** add a new interface surface. Instead, D-CAPMODE is a constraint on existing KABI actions:
- KABI action subset `Acquire*` is profile-gated and *must* be rejected when `capmode=on`.
- View resolution remains the only name→cap path for effectful operations (I-VIEW-1).

Recommended default posture:
- privileged services run `capmode=off` only during early init, then **seal** (`D-SEAL`) and set `capmode=on` permanently.

## Invariants / proof obligations
- Add invariant: **I-CAPMODE-1**.
- Add PO: **PO-CAPMODE-ONEWAY**.

These are intentionally small and align with existing view obligations:
- PO-VIEW-RESOLVE / PO-VIEW-NOAMP remain the core “namespace correctness” work.

## Pressure tests (reuse)
- AC-008 (namespace/view confusion) becomes the primary pressure test for D-CAPMODE.
- AC-010 (forgot to seal) is amplified if capmode isn’t engaged post-init.

## Evidence plan (tight)
Phase 0/1:
- E1 tests: entering capmode disables `Acquire*` actions deterministically.
- Negative tests: ensure “fallback-to-default” code paths do not exist (lint + tests).

Phase 2:
- E2 bounded checks on a tiny abstract-machine fragment that models view resolution + capmode gating.

## References
Refs: REF-CAPSICUM, REF-CLOUDABI, REF-WASI-DESIGN.
