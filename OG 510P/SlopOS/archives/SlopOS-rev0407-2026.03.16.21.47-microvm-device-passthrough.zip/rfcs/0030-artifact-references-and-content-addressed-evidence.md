# RFC-0030: Artifact references and content-addressed evidence (anti-bloat seam)

Status: Draft

## Problem
This archive must remain reviewable and “long-lived”, but evidence artifacts (proof traces, model-checker states, replay logs, fuzz corpora, build closures) can grow without bound.
If we inline heavyweight artifacts, we lose the archive’s primary usability property.

## Goal
Introduce a *small* mechanism that lets us:
- keep the archive text-first;
- refer to heavyweight artifacts by digest;
- preserve mechanical checkability (“you can verify the bytes if you have them”).

## Non-goals
- standardize a particular storage backend (CAS, object store, git annex, etc).
- claim long-term durability or availability (that is an ops/supply-chain claim, not a kernel claim).

## Proposal
Adopt **D-AREF**: represent heavyweight artifacts by a content-addressed reference envelope:
- **CH-AREF v0** (`docs/30-architecture/artifact-reference-schema-v0.md`)

Primary uses (v0):
1) Evidence index entries MAY point to CH-AREF instead of embedding artifacts.
2) Tooling MAY verify/re-fetch artifacts opportunistically, but MUST fail closed when verification is requested and cannot be performed (PO-AREF-VERIFY).

Optional future uses:
- Boot/update gating MAY accept CH-AREF references for manifest-linked artifacts, subject to an allowlisted locator scheme set.

## Security & assurance hooks
- **I-AREF-1**: digest is authoritative; locators are untrusted hints.
- **PO-AREF-VERIFY**: whenever an artifact is fetched/loaded for verification, digest mismatch rejects deterministically.
- **AC-035**: protect against substitution/misbinding.

Notes:
- Content-addressed storage patterns (e.g., Venti) emphasize immutability + dedup; we reuse the *security property* (digest identity), not necessarily the same backend (REF-VENTI-FAST02).
- The transparency-log anchoring seam (D-TLOG) can anchor CH-AREF digests without importing the artifact itself (REF-CT-RFC6962).

## Evidence plan (tight)
- E1: negative tests: (a) locator changes do not change identity; (b) digest mismatch rejects; (c) locator schemes are policy-gated.
- E1: small “verify if present” CLI that checks all CH-AREF entries reachable from the evidence index.

## Open questions
- Do we want a single “project CAS” by default, or do we keep CH-AREF backend-agnostic and let projects choose?
- If we later bind CH-AREF into boot policy, what locator schemes are acceptable (file:, cas:, https: via pinned TUF metadata)?

## References
REF-VENTI-FAST02, REF-FOUNDATION-CAS, REF-CT-RFC6962.
