# RFC-0043: Capsule isolation and unsafe budgets (D-UNSAFE adjunct)

Status: Draft  
Last updated: 2026-02-24

Goal: treat “safe-language kernel” as a **discipline**, not a vibe: keep `unsafe` tightly bounded, make “who may touch what” explicit, and give the project a repeatable way to keep the privileged core from quietly accreting risk.

Motivation sources: Tock’s Rust kernel experience (capability tokens + capsule-like structure) and follow-on verification work, plus RustBelt’s reminder that safety hinges on `unsafe` obligations. Refs: REF-TOCK-OS, REF-TOCK-CAPS, REF-TICKTOCK-TOCK-ISO, REF-RUSTBELT.

Non-goals:
- Proving “no bugs” because the code is in Rust.
- Forbidding all `unsafe` everywhere (hardware reality exists).
- Designing a full kernel-extension framework now.

## Problem
In a Rust-based privileged core, the long-term failure mode is predictable:
- early bring-up adds “temporary unsafe,”
- drivers/complex subsystems creep into the privileged core,
- audits become impossible because `unsafe` is not traceable or budgeted.

We already have a good base invariant (**I-UNSAFE-1**): every `unsafe` site ties to a U-ID with explicit obligations.
What’s missing is an **organizational structure** that makes it hard for `unsafe` and privilege to spread.

## Proposal

### 1) Adopt a “capsule” module discipline
Define a structural rule set:

- **HAL boundary:** a small, explicitly scoped set of crates/modules may contain `unsafe` required for MMIO/CPU instructions/bootstrapping.
- **Privileged core:** default `#![forbid(unsafe_code)]` except for allowlisted modules tied to U-IDs.
- **Capsules (in-core helpers):** safe Rust only; interact with privileged primitives via narrow trait/object interfaces and type-capability tokens (RFC-0020) when warranted.
- **Drivers and complex services:** default to user-space driver domains (D-DRVDOM) unless a specific profile justifies otherwise.

This is intentionally similar to how successful Rust kernels enforce “unsafe only in small places” in practice.

### 2) Introduce an “unsafe budget” artifact (engineering gate)
Add an engineering artifact (human-reviewed, CI-enforced) that answers:
- which crates/modules are allowed to contain `unsafe`,
- which U-IDs exist and where they live,
- rough “budget” expectations (count or risk class), and
- explicit justification for each expansion of the unsafe surface.

This does **not** require new kernel mechanisms; it is a meta-engineering gate that keeps the privileged core auditable over time.

### 3) Tie unsafe budgets to the assurance pipeline
- Unsafe-budget deltas become evidence-relevant events: any increase triggers review and updates to the unsafe obligation registry.
- Optional: require a cap-graph or interface-registry update when unsafe changes correlate with new privileged surfaces (I-IF-1).

## Candidate invariants / proof obligations
- **I-UNSAFE-2 (Unsafe spread is bounded, optional):** `unsafe` sites are confined to allowlisted modules/crates and are budgeted; any new unsafe requires a U-ID entry and a budget update.
- **PO-UNSAFE-SCAN:** the unsafe scan/budget gate is deterministic and complete w.r.t. the repository’s Rust sources: it rejects any `unsafe` site not linked to a U-ID or not covered by the allowlist.
- **PO-UNSAFE-ALLOWLIST:** the allowlist/budget artifact is itself pinned (digest-bound) for releases that claim C-UNSAFE-1 evidence.

## Evidence plan (stageable)
E1:
- implement a simple unsafe scanner + CI rule (“no unsafe outside allowlist; every unsafe references a U-ID”)
- demonstrate “capsule” boundaries on a small kernel slice (e.g., scheduler + IPC path stubs)

E2:
- correlate unsafe boundaries with a bounded set of privileged interfaces; show drift detection catches “interface creep”

E3:
- (optional) mechanize a small unsafe module’s pre/postconditions (Verus/Creusot) as a template for discharging U-IDs

## Alternatives
1) **Rely on code review only**.  
   - Con: drift is slow and invisible until it is too late.

2) **Push everything into user space**.  
   - Con: some minimal unsafe HAL is unavoidable; we still need discipline.

3) **Adopt a heavy static analysis framework now**.  
   - Con: tooling becomes the bottleneck; start with a tiny, auditable scanner.

## Open questions
- What is the right “risk classification” for U-IDs (memory safety vs concurrency vs DMA)?
- How to integrate this with D-MK (multikernel) ownership discipline once SMP profiles turn on?
- Do we want to treat “unsafe in build scripts / macros” specially?

