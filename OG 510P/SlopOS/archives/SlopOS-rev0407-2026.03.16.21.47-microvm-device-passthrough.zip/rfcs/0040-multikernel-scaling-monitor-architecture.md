# RFC-0040: Multikernel-inspired scaling and monitor architecture (D-MK)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-MK, D-CONC, D-SKB

## Summary
Adopt a staged multicore strategy that keeps *ownership of state explicit*: in the D-MK profile, each core runs a small privileged “local kernel” and cross-core coordination happens via explicit message channels and user-space monitors (multikernel-inspired). This is an optional path beyond Phase 1 single-core and a potential alternative to fine-grained shared-kernel locking.

## Motivation
Multicore proof work gets hard when the kernel has large shared mutable state. The multikernel idea is to treat the machine as a distributed system of cores: explicit messaging, per-core ownership, and higher-level coordination in user space.

We already plan to stage concurrency (D-CONC) and keep hardware-policy logic in user space (D-SKB). D-MK provides an architectural “north star” that makes those choices cohere:
- minimize cross-core shared state in the privileged core;
- make all cross-core coordination **explicit** and transcriptable;
- drive placement/topology decisions using CH-HWFACT + SKB, not ad-hoc probing.

## Integration seam / kernel impact (keep small)
Phase 1 (default): single-core kernel, deterministic scheduling posture, minimal IPC.

D-MK profile requirements (later):
- per-core kernel instances or per-core ownership partitions for privileged state (scheduler queues, page-table ownership, endpoint state);
- explicit inter-core messaging primitive (may be implemented using shared memory + IPI, but presented as a bounded “message channel” abstraction to the rest of the system);
- a user-space “monitor” component that maintains any required global state (naming, resource placement policies, cross-core routing).

No new ambient authority: monitors are ordinary components that hold explicit capabilities.

## Design (sketch; stageable)
### A) Ownership rule
Every privileged data structure is assigned an owner core. Only the owner mutates it. Cross-core requests are messages:
- request messages are validated as CH-* values (canonical decode);
- responses are explicit and bounded.

This aligns with “no hidden sharing” principles and reduces the reliance on complicated shared-memory invariants.

### B) Per-core kernel services
The privileged core should prefer per-core services:
- local scheduling/runqueues;
- local IPC endpoint fast paths (when endpoints are local);
- local page-fault handling hooks (routing is explicit; D-PAGER optional).

### C) User-space monitors
Monitors coordinate:
- cross-core capability routing decisions (as policy/data, not privileged hidden rules);
- placement decisions using SKB queries over CH-HWFACT;
- resource accounting aggregation (D-METER) when needed.

Monitors should be restartable (supervision patterns; RFC-0017) and should log coordination decisions that affect privileged configuration (CH-LOG).

### D) Transition path
The expected “gentle” progression:
1) single core (D-CONC stage 0)
2) big-kernel-lock SMP (optional intermediate; keep proof surface bounded)
3) D-MK profile for high-core-count/NUMA systems, if evidence shows it simplifies reasoning or scales better.

## Registries impacted
- Decision map: add D-MK (done).
- I registry: add I-MK-1 (this RFC).
- PO registry: add PO-MK-NOSHARE (this RFC).

## Threat-model impact
- Explicit message channels reduce accidental cross-core state corruption, but introduce message validation obligations (stay within I-ENC-1).
- Monitors become policy-critical components; compromise can misconfigure the system (but cannot exceed their held capabilities).

## Assurance/verification impact
New invariant:
- **I-MK-1 (Per-core ownership, optional):** for D-MK profiles, privileged mutable state is partitioned by owner core; any cross-core coordination that can cause privileged effects occurs only via explicit, schema-validated messages and preserves I-STATE-1/I-CONC-1 within the declared model.

New proof obligation:
- **PO-MK-NOSHARE:** show that no code path mutates non-owned privileged state and that cross-core message decoding/dispatch is total and fail-closed.

## Observability / operations impact
- IF-OBS can export per-core counters: message queue lengths, cross-core request rates, monitor restarts.
- Debug tooling benefits from explicit message transcripts and stable ownership, improving replay and postmortem reconstruction.

## Alternatives
- Fine-grained locking in a shared-kernel SMP: viable but has a heavier proof burden and can hide ownership assumptions in lock discipline.
- Static partitioning only (D-PART): great for early assurance plateaus, but does not address “shared OS services across cores” for general-purpose configurations.

## Evidence plan
- Microbench: local vs remote endpoint operations; cross-core message overhead.
- Litmus/perf tests: ensure message ordering + ownership constraints match D-MEMMODEL/D-CONC assumptions.
- Prototype: a minimal monitor that routes a small set of cross-core requests and logs decisions.

## References
REF-MULTIKERNEL-SOSP09, REF-BARRELFISH, REF-BARRELFISH-SKB.
