# RFC-0054: Authority diffs + consent receipts (D-EXPLAIN)

**DEPRECATED (superseded by RFC-0069):** This RFC’s content is preserved for history, but the canonical design is now **RFC-0069** (typed diffs via CH-CAPDIFF + binding rules). New edits should go to RFC-0069.


Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-EXPLAIN, D-POWERBOX, D-VOLITION, D-PLUMB

## Summary
Define a **human-legible, machine-checkable** contract for permission-granting UX:
(1) show an **authority diff** (what new authority would be added), and
(2) emit a **consent receipt** (CH-RECEIPT v0) that binds the approval UX to the exact action/route that executed.

Goal: make “what did I approve?” and “what changed?” auditably answerable, reduce confused-deputy failures, and improve incident forensics (especially with automation/agents).

## Motivation
We already bind approvals to action digests (CH-AUTHZ) and (optionally) to trusted UI gestures (CH-VOL). That prevents some forms of *approval reuse* and UI spoofing, but it does not fully address:
- **Comprehension gaps**: users approve what they *think* they saw, not what actually executed.
- **Forensics gaps**: after an incident, we need a durable, minimal record: who asked, what was shown, what was granted, what expired/revoked.
- **Grant creep**: repeated “small” grants accumulate; without diffs and history, users can’t see privilege creep until it’s too late.
- **Agent mediation**: if an agent proposes actions, we need a receipt trail that proves the validator + consent path did what it claimed.

This RFC bakes in a “receipt ledger” and “permission diff” as a first-class ecosystem feature (see RFC-0003).

## Integration seam / kernel impact (keep small)
Kernel impact: **none required** beyond existing CH-* validation and capability semantics.

User-space components:
- Consent mediator (IF-CONSENT) and/or ACP (IF-ACP) MUST:
  - compute an **authority diff** summary *from canonical state*, and
  - emit a CH-RECEIPT record on completion (allow or deny).
- Observation export (IF-OBS) MAY export redacted receipts; the UI may also expose a local “Receipts” viewer.

Existing seams used:
- CH-AUTHZ v0 (approval binding)
- CH-VOL v0 (optional trusted UI intent binding)
- CH-LOG v0 (transcript binding action↔result)
- CH-CAPG v0 (redacted cap-graph snapshots / deltas)

## Design

### 1) Authority diff (what changes)
When an action would add authority to a subject domain, the UX MUST present a **delta** relative to the subject’s current authority.

The diff is derived from one of:
- a **capability-graph delta** (preferred): CH-CAPG(snapshot_before) → CH-CAPG(snapshot_after) → diff summary; or
- a **typed grant summary**: structured “grant set” produced by the router/mediator when the grant is not well-modeled as a graph edge (e.g., temporal leases).

Rules:
1) Diffs MUST be computed from **canonical objects** (routing rules, cap routing graph, lease objects), not from requester-supplied strings.
2) Diffs MUST be **stable and comparable**: same input state + action ⇒ same rendered structure (locale is allowed to change only the final human text).
3) Diffs MUST be **minimized**: show only what is necessary to evaluate risk (e.g., “read-only access to this one file handle for 10 minutes”).
4) Diffs MUST highlight: scope, rights, lifetime/expiry, persistence, and any export/persistence implications (D-QUAR/D-EPHEM interaction).

### 2) Consent receipts (CH-RECEIPT v0)
On every consent decision (allow/deny), the mediator MUST emit a CH-RECEIPT record that binds:
- the **requested action** (schema + digest),
- the **rendered summary/diff** (digest of canonical summary structure),
- the **approval evidence** (CH-AUTHZ digest; optional CH-VOL digest),
- the **outcome** (allow/deny + result digest), and
- the **lifetime controls** (expiry, revocation epoch/lease id, if applicable).

Receipts are **non-authoritative** artifacts: they must never be accepted as approvals. They exist to prove what happened.

### 3) Rationale text (optional, constrained)
Requesters MAY attach a rationale payload, but it must be treated as **untrusted**:
- The canonical summary/diff MUST NOT include requester-controlled free text.
- Allowed rationale fields are closed-enum tags (e.g., `purpose: "share-file"`), optional links to internal help docs, and a bounded-length hint string that is displayed only as *non-authoritative* UI decoration.

Rationale research indicates that wording affects consent outcomes; this RFC treats rationales as a UX aid, not an authority-bearing artifact. Refs: REF-CISPA-RATIONALE-2025.

### 4) Receipt storage + privacy posture
Receipts SHOULD be stored locally in a user-visible “receipt ledger” with:
- append-only semantics (log-style), and
- redaction for sensitive payloads (no raw capabilities; no secrets; no ambient paths unless view-scoped and explicitly approved).

Exports are through IF-OBS (CH-OBS/CH-RECEIPT) or via a user-mediated “Export receipts…” portal that produces a redacted bundle.

## Registries impacted
Add/update:
- Decision map: **D-EXPLAIN**
- Schema registry: **CH-RECEIPT v0**
- Invariant registry: **I-EXPLAIN-1..3**
- Proof obligations: **PO-EXPLAIN-SUMMARY, PO-EXPLAIN-RECEIPT-BIND, PO-EXPLAIN-NONAUTH**
- Abuse cases: **AC-042**
- Evidence index: **EVID-2026-046, EVID-2026-047, EVID-2026-048**
- Bibliography: add refs for consent receipts + rationale patterns

## Threat-model impact
Mitigates:
- confused-deputy consent (AC-036): by showing deltas and binding what was shown to what executed.
- “silent privilege creep”: by making grants comparable over time.

New risks:
- receipt ledger becomes a **sensitive dataset** (metadata about user actions). Must be minimized and redacted (C-OBS-1 alignment).
- attackers may attempt to forge receipts; receipt integrity depends on deterministic generation and transcript binding (CH-LOG).

## Assurance/verification impact
New invariants / obligations:
- **I-EXPLAIN-1 (Canonical summary binding)**: the rendered consent summary/diff is a deterministic function of the action/request + relevant policy state, not requester-controlled text.
- **I-EXPLAIN-2 (Receipt binds reality)**: every allow/deny decision yields a receipt that binds action_digest + summary_digest + authz_digest (+ vol_digest if used) + result_digest.
- **I-EXPLAIN-3 (Receipts are non-authoritative)**: receipt artifacts cannot be interpreted as authorization tokens; validators fail closed on schema confusion.

Proof obligations:
- **PO-EXPLAIN-SUMMARY**: show that summary/diff generation depends only on canonical inputs and is total over the action space.
- **PO-EXPLAIN-RECEIPT-BIND**: show receipt fields correctly bind to action and result digests (and cannot be mixed-and-matched).
- **PO-EXPLAIN-NONAUTH**: show no privileged path accepts CH-RECEIPT as approval evidence.

## Observability / operations impact
- A new receipt stream supports “why did this happen?” debugging without granting new authority.
- Receipts integrate with CH-LOG: operators can correlate transcripts with user-visible consent artifacts.
- Redaction policy MUST treat receipts as PII-adjacent: record minimal provenance, avoid raw identifiers, prefer stable pseudonyms.

## Alternatives
- **Rely only on CH-LOG**: too low-level for humans; lacks explicit consent summaries and diff structure.
- **OS-wide ambient permission settings**: tends to reintroduce global authority + configuration drift; conflicts with capability-first UX.
- **Free-form textual prompts**: easy to spoof; hard to audit; breaks digest binding.

## Evidence plan
E1 prototypes:
- Implement a receipt ledger + UI viewer; integrate with a portal flow and a powerbox grant.
- Add tests that:
  - fuzz summary generation for totality and stability,
  - prove digest binding: altering any of (action, summary, authz, result) breaks verification,
  - ensure receipt artifacts cannot be replayed as approvals.

E2:
- DRT: differential test a tiny reference “summary renderer” against an implementation to prevent spec drift.

## Open questions
- How should receipts be surfaced for *batch* actions (e.g., “grant N files”) while keeping diffs comprehensible?
- Do we want optional attestation/signatures on receipts, or is CH-LOG binding sufficient for our threat model?
- What’s the minimal “stable pseudonym” scheme for cap-graph deltas that aids humans without leaking identity?
