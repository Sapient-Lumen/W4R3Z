# RFC-0045: Device leasing and data-plane I/O bypass (D-IOLEASE)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-IOLEASE, D-DRVDOM, D-DMA

## Summary
Introduce an **optional** “device lease” mechanism that lets applications/libraries interact with **virtualized device queues directly** (data plane), while keeping the kernel/hypervisor and a small driver manager in the **control plane**.

## Motivation
High-performance networking/storage workloads often pay disproportionate cost for per-operation kernel mediation, even when the kernel is not adding policy value on the hot path.

Arrakis demonstrated that a clean control-plane/data-plane split plus hardware I/O virtualization can deliver large latency/throughput wins while preserving protection (REF-ARRAKIS-OSDI14). For a greenfield capability OS, **leasing** is the natural shape: treat a device queue (or similar “submit/complete” resource) as an explicit capability that can be granted, monitored, and revoked.

## Integration seam / kernel impact (keep small)
Required privileged mechanisms:
- establish/maintain DMA containment for leased queues via IOMMU policy (I-DMA-1)
- map MMIO doorbells/rings to a lessee with explicit rights (I-IORES-1)
- route/ack interrupts to a lessee endpoint (or a driver-domain proxy)
- revoke a lease (disable queue, tear down mappings) deterministically

Non-goals for the privileged core:
- per-device policy, scheduling, batching, retransmission logic, etc.
- implementing full driver stacks in-kernel

## Design
### 1) Lease object
A **lease** represents a bounded slice of a device’s interface:
- one or more hardware/software queues (TX/RX or submit/complete)
- a bounded DMA window / mapping authority
- optional interrupt vectors (or a notification endpoint)
- explicit expiry/renewal policy (can integrate with D-TCAP)

The lease is minted and managed by a **driver-domain manager** that holds the necessary IO resource capabilities (D-DRVDOM; I-IORES-1).

Important boundary: queue/ring/vector granularity here is a **dataplane lease-shape** decision, not the future `portal.device.*` authorization ordering scope. Attach/grant/revoke policy remains keyed at `device.id` (see `docs/30-architecture/device-lease-ordering-boundary-v0.md`).

### 2) CH-IOLEASE v0 (descriptor schema)
Define **CH-IOLEASE v0** as a pinned descriptor for lease grants (for audit/logging/replay tooling):
- describes *what* was leased (device class, queue slice, DMA window, IRQ routing)
- carries no secret material (capabilities are transferred separately)
- supports deterministic policy checks (“this lease is within the declared bounds”) before installing/mirroring a grant

### 3) Grant / use / revoke lifecycle
- **Grant:** the manager validates the request, configures the IOMMU context, maps doorbells/rings, and emits a CH-LOG entry referencing the CH-IOLEASE digest.
- **Use:** the lessee performs data-plane operations by writing to the leased queue(s) and sharing buffers that are explicitly mapped into the allowed DMA window.
- **Revoke:** the manager disables the queue and invalidates DMA mappings; the kernel/hypervisor must ensure revoked resources cannot continue DMA or signal interrupts.

### 4) Interaction with other decisions
- **D-ADDRNET:** if enabled, leases should be derivable from (and checkable against) the pinned address-decode net so DMA reachability is explicit.
- **D-METER / D-TCAP:** leases can be charged to meters (queue count, pinned buffer bytes) and optionally time-bounded.
- **D-CAPAUD:** cap-graph diffs can detect unintended authority retention after revoke.

## Registries impacted
- **CH-IOLEASE v0**: add schema spec + schema-registry row
- Add invariants:
  - **I-IOLEASE-1 (Lease DMA confinement, optional):** any active lease’s DMA window is a subset of the declared/authorized DMA reachability; no DMA outside the lease’s window is possible.
  - **I-IOLEASE-2 (Lease revocation is effective, optional):** after revoke, the lessee cannot submit work, DMA, or receive interrupts via the revoked lease.
- Add proof obligations:
  - **PO-IOLEASE-CONFINE:** enforcement matches the lease descriptor and cannot be bypassed (IOMMU/queue ownership).
  - **PO-IOLEASE-REVOKE:** revoke tears down all reachability (DMA + IRQ + MMIO) deterministically.

## Threat-model impact
New/changed risks:
- buggy/malicious lessee dataplanes can attempt DMA abuse or ring corruption
- covert channels via queue occupancy/timing
- denial-of-service by monopolizing scarce queues

Controls:
- IOMMU-first posture; no lease without DMA confinement (A-DMA-1; I-DMA-1)
- bounded leases, metered queue/buffer grants (D-METER)
- revocation hooks + cap-graph leak tests to ensure clean teardown

## Assurance/verification impact
This seam is attractive because it creates *crisp* checkable obligations:
- validate a lease descriptor is within policy bounds (deterministic)
- prove/argue that the installed IOMMU/IRQ/MMIO configuration corresponds to the lease (PO-IOLEASE-CONFINE)
- test revocation soundness with adversarial workloads (PO-IOLEASE-REVOKE)

## Observability / operations impact
- lease grants/revokes should be transcript-logged (CH-LOG) with redaction-safe descriptors
- optional metrics: queue occupancy, drops, revoke counts, DMA faults

## Alternatives
- kernel-mediated I/O everywhere: simplest, but loses the point of a capability microkernel dataplane
- SR-IOV whole-function assignment: coarse; harder to meter and share; may be viable as a specific lease backend
- io_uring-style syscalls: improves batching but still keeps mediation on every operation

## Evidence plan
- prototype a leased NIC queue dataplane and compare against a mediated path:
  - latency, throughput, CPU cost
  - revoke correctness under stress
  - DMA containment validation (fault injection)

## Open questions
- What is the minimal **dataplane** lease granularity that stays practical across devices (queues, rings, doorbells, MSI-X), while keeping attach/grant/revoke policy keyed at `device.id` rather than inventing a second generic `portal.device.*` ordering family?
- How do we standardize revocation semantics so drivers can be swapped/restarted safely (D-SUPV)?
- Should CH-IOLEASE be referenced by CH-PART for static-partition profiles (D-PART)?
