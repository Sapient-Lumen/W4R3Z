# RFC-0025: device attestation (DICE + EAT) (optional)

Status: draft

## Goal
Define an **optional**, bounded path to support **remote verification** of the running platform’s boot + configuration state, without expanding the privileged core beyond: (a) producing a measured record (CH-BOOT) and (b) exposing a small, capability-gated export hook.

We explicitly do **not** claim that attestation makes the system secure; it only strengthens *provenance integrity* claims under explicit hardware assumptions.

## Non-goals
- Not a complete confidential-computing design (see D-CC).
- Not mandating a specific root-of-trust (TPM/TEE/etc.); DICE is a primary candidate.
- Not standardizing the signature container format (COSE/JWS/etc.) beyond requiring canonical payload hashing.

## Summary
Introduce:
- **D-ATTEST**: whether we produce a device attestation artifact.
- **CH-ATTEST v0**: a small payload-to-sign schema that binds:
  - a freshness challenge (optional),
  - the active **CH-BOOT digest**,
  - optional provenance digest(s) (CH-PROV),
  - a device identity / public key reference.

We prefer aligning the *claims payload* with **EAT** (Entity Attestation Token) while allowing the outer wrapper to remain project-specific.

## Threats addressed
- **Stale/forged platform claims** to an update server, operator, or remote policy gate.
- **Boot manifest substitution** (attestation claims X, but CH-BOOT is Y).

## New artifacts
- `docs/30-architecture/attestation-token-schema-v0.md` (CH-ATTEST v0)

## Invariants / proof obligations (new)
- **I-ATTEST-1 (Attestation binds to boot state, optional)**: if D-ATTEST is enabled, any attestation presented as “this boot” is cryptographically bound to the current CH-BOOT digest (and policy revision), and cannot be replayed to represent a different boot.
- **PO-ATTEST-VERIFY**: verifier checks the attestation signature chain per policy and rejects invalid structures deterministically.
- **PO-ATTEST-BIND**: verifier confirms `boot_digest == digest(CH-BOOT)` and rejects mismatches.
- **PO-ATTEST-FRESH (conditional)**: if freshness is claimed, verifier enforces nonce/challenge binding and rejects stale responses.

## Evidence plan
- **E1**: unit tests for canonical hashing/encoding of CH-ATTEST.
- **E1**: negative tests (wrong digest, wrong nonce, wrong key) must fail closed.
- **E2**: bounded replay harness proves that attestation export cannot influence privileged state (observational only).

## Interactions
- D-BOOT / D-PCP: CH-ATTEST can carry (or reference) digests of CH-PROV proof bundles.
- D-UPD-SIGN: signature chain policy for attestation artifacts must be explicit.
- IF-OBS: export via IF-OBS must redact secrets; attestation is public but still policy-gated.

## Open questions
- Which device identity strategy is assumed in each deployment profile (TPM EK, DICE CDI-derived key, TEE report key, etc.)?
- Which EAT claim set is minimal for our assurance targets (boot + policy + optional SW IDs)?
