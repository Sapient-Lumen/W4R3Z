# RFC-0017: Supervision trees, reincarnation, and restart policy (CH-COMP extension)

Status: Draft

Goal: bake in a **small, reviewable restart/recovery posture** for user-space services and drivers, without making “reliability policy” a privileged-kernel feature.

We borrow two complementary lessons:
- Erlang/OTP: explicit supervision trees make failure handling structured and composable.
- MINIX 3: a “reincarnation server” can restart crashed drivers/services while keeping the kernel small.
- Solaris SMF: declarative service manifests + dependency-driven restarters (ops-proven restart semantics).

Refs: REF-ERLANG-OTP-PRINCIPLES, REF-MINIX-RELIABLE-OS, REF-SOLARIS-SMF-BP, REF-SOLARIS-SMF-CREATESVC, REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-FDSTORE, REF-FUCHSIA-RUNNER-STOP, REF-WIN-JOBOBJECTS, REF-MACH-REQUEST-NOTIFY.

## Motivation

A supervision system needs **reliable liveness signals** and **bounded teardown semantics**:
A related ergonomics trap is **timeout soup** during shutdown and restart. If enabled, D-REQCTX (RFC-0105) recommends driving teardown via an explicit *shutdown context* (deadline + cancellation) rather than ad-hoc timers scattered through services.

- liveness: “component endpoint died” should be a first-class notification (not timeout soup) where possible.
- teardown: “kill this whole subtree” must be deterministic and resistant to handle-inheritance escapes.

Microkernel-ish architectures push drivers/services into user space, which is good for isolation but creates a practical question:
- who restarts a crashed driver/service?
- how do we prevent restart storms (DoS) or silent degraded operation?
- which components are “critical” enough that failure should fail closed (e.g., reboot, halt, or drop into a safe mode)?

If we leave this as ad-hoc init logic, we lose reviewability and evidence traceability.

Operational lesson: restarts are vastly safer when the supervisor owns inbound endpoints and can restart workers without dropping new connections (socket activation), and when there is a bounded way to preserve selected handles across restarts (FD-store style). We capture this as an optional adjunct: **D-ACTIVATE** (RFC-0081).


## Proposal: minimal restart metadata in CH-COMP v0
Extend component declarations with an optional restart policy (enforced by user-space init/component manager):

### New optional fields (component `c`)
- `activation`: optional activation/handoff posture (see RFC-0081):
  - `stable_exports`: list of supervisor-owned stable exported handle kinds
  - `handle_store`: bounded per-component handle store policy

- `critical`: bool (default false)
  - if true: component failure triggers a profile-defined fail-closed response (e.g., reboot into recovery policy)
- `restart`: optional restart policy object:
  - `policy`: one of `{ never, on_failure, always }`
  - `window_ms`: bounded window for rate limiting
  - `max_restarts`: bounded count within window
  - `backoff_ms`: bounded minimum delay before restart

All fields are bounded and closed-world.

## Enforcement model (keeps TCB small)
- The kernel/hypervisor does **not** implement restart policy.
- A small, auditable user-space supervisor (init/component manager) enforces it.
- Actions taken by the supervisor that affect privileged state (e.g., device reassignment, routing changes) must flow through IF-ACP/IF-KABI and be transcript-logged (CH-LOG).

Lifecycle hygiene (borrow the boring proven bits): supervisors should implement a deterministic `Stop(grace) → Kill()` escalation, so shutdown/restart behavior is testable and bounded (mirrors component runners).

This fits the archive’s “spec-first, proof-driven, minimize-TCB” posture: restart is policy in user space, but the policy is pinned in an artifact we can lint/bind.

## Abuse case addition
- **AC-022: restart storm / reincarnation abuse**
  - attacker triggers repeated crashes to consume CPU/memory/log bandwidth and potentially wedge recovery logic.
  - mitigation is explicit rate limits + meter integration (D-METER/D-TCAP) and deterministic overflow behavior.

## Evidence plan (tight)
Phase 0/1:
- deterministic restart state machine tests (rate limit, backoff, critical handling)
- negative tests: malformed restart fields reject under PO-COMP-VALIDATE

Phase 2:
- bounded model check of the supervisor state machine (small restart automaton) and a “crash injector” adversary

## Archive impact
- Adds RFC-0017 (this file).
- Extends CH-COMP v0 schema doc with `restart` and `critical` fields.
- Adds AC-022 abuse case.
