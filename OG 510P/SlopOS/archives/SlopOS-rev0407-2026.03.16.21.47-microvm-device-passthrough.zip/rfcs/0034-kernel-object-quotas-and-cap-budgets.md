# RFC-0034: Kernel object quotas and cap budgets (D-KOBJQ, D-METER)

Status: Draft  
Updated: 2026-02-24  
Decision nodes: D-KOBJQ, D-METER

Goal: prevent **kernel resource exhaustion** (capability slots, endpoint objects, signal handlers, etc.) with a mechanism that is:
- small (fits the microkernel discipline),
- attributable (charges to explicit meters/budgets), and
- fail-closed (no implicit “best effort” that breaks invariants under pressure).

Motivation: memory-safe code does not prevent *resource* DoS. Many systems discover late that “caps are cheap” is false in practice: kernel-maintained references are globally scarce. Genode’s design makes this explicit via RAM quota and **cap quota**: creating kernel-maintained object references requires budget.

## Design sketch (v0 seam)

### 1) Accountable kernel objects
Classify privileged allocations into:
- **memory-like**: frames, page tables, shared regions (already covered by D-METER scope)
- **reference-like**: capability slots, endpoints/channels, irq objects, notification/signal objects

Introduce a single accounting rule:

> Creating a kernel object or kernel-maintained reference requires presenting a meter/budget authority that is **charged** for the allocation. If insufficient budget exists, creation fails closed.

This is conceptually the same as “session quota” in Genode’s RAM sessions, where quota is loaded from a reference account before allocations succeed.

### 2) Minimal interface impact
- No new global policy surface.
- A small extension to the existing “create object” actions in CH-KABI: each allocation-carrying action includes an optional `charge_to` field that must be present when D-KOBJQ is enabled.
- The core enforces: (a) charge happens atomically with creation, (b) no negative balances, (c) freeing returns charge (or returns to a designated refund meter).

### 3) What is charged (recommended default set)
- `cap_slot`: ability to hold/derive a capability reference
- `endpoint`: IPC endpoint/channel objects
- `irq_obj`: interrupt binding objects
- `notify_obj`: notification/signal handler objects

Policy can later choose whether to charge more object types; the seam is that **some** set exists and is explicit.

## Invariants / POs (additions)
- Extend **I-METER-1** with: *reference-like* kernel resources are charged to meters when enabled.
- New invariant: **I-METER-2 (No free kernel refs)**: if D-KOBJQ is enabled, every live reference-like kernel object is attributable to some meter; revocation/freeing restores charge or burns it explicitly.
- PO candidates: PO-KOBJQ-ATOMIC, PO-KOBJQ-NONEG, PO-KOBJQ-REFUND.

## Alternatives
- “Unlimited caps, rely on GC” — not viable for kernel-maintained refs.
- “Global hard caps per process” — simpler but loses delegation/composability.
- “User-space accounting only” — cannot prevent kernel exhaustion; only observes it.

## Evidence plan
- Prototype: implement charging for endpoint creation + cap-slot growth in a toy KABI.
- Stress: abuse-case AC-??? (resource exhaustion) where an untrusted driver-domain attempts to exhaust endpoints; show failure is contained/attributed and does not impact unrelated domains.
- Measure overhead: charge path adds O(1) bookkeeping on allocations.

## Open questions
- Refund semantics: return to the allocator meter vs. a parent meter? (choose the simplest that composes with space banks)
- Cap-slot model: fixed-size CSpace vs. growable tables (impacts what is “charged”).

Refs: REF-GENODE-CORE, REF-GENODE-SESSIONS, REF-GENODE-RESMGMT.
