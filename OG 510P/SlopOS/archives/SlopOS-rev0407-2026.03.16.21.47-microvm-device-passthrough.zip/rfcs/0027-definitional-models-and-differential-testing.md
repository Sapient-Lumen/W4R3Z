# RFC-0027: Definitional models and differential randomized testing (DRT)

Status: Draft  
Owner: archive  
Last updated: 2026-02-23

## Summary
Adopt a **definitional reference model + differential randomized testing** loop for high-risk surfaces (canonical decoders/encoders, CH-KABI dispatch normalization, ACP validator semantics). The goal is cheap, repeatable counterexample-finding that also strengthens later refinement/proof work.

## Motivation
We rely heavily on “ABI as data” (CH-KABI, CH-ACP, CH-LOG) and on *total, fail-closed* validators. Subtle drift between (a) the intended semantics and (b) the production implementation is a recurring source of security/correctness failures.

There is a proven pattern: maintain a small, executable spec (definitional model) and continuously **differential-test** it against the production implementation. Cedar explicitly does this: it maintains a formalization and uses differential randomized testing between that spec and the Rust implementation (REF-CEDAR-SPEC).

## Design

### D-DRT scope
Define D-DRT as an *evidence/engineering* feature (not a runtime mechanism):
- It produces E2 bug-finding evidence artifacts.
- It reduces the risk of “spec drift” before mechanization.
- It is not a security boundary; it is a quality gate.

### Reference models (definitional implementations)
For each target surface, maintain a **small, pure reference interpreter**:
- **CH-KABI v0**: parse canonical bytes → AST → normalized effect intent (closed enum), with total error codes.
- **CH-ACP v0**: parse canonical bytes → AST → `validate` step relation on a bounded ACP state slice.
- **CH-LOG v0**: encode/decode + replay determinism check for transcript entries.

The reference model should be:
- deterministic and side-effect-free
- bounded and intentionally *not* optimized
- small enough to audit and eventually port into an ITP as an executable spec

### Differential randomized testing loop
Run property-based + coverage-guided fuzzing that compares:
1) **Canonicalization equivalence**: `decode(encode(x)) == x` for well-formed values.
2) **Reject equivalence**: for malformed/non-canonical bytes, both implementations reject with stable error classes.
3) **Semantic equivalence**: for accepted inputs, both implementations compute the same normalized effect intent and/or state transition.

This yields explicit obligations:
- **PO-DRT-ENC**: canonical encode/decode equivalence for CH-* schemas.
- **PO-DRT-DISPATCH**: CH-KABI normalization/dispatch equivalence on accepted inputs.
- **PO-DRT-ACP**: ACP `validate` equivalence on bounded state/action spaces.

### Why this is “tight”
We do not add large proofs; we add **small executable specs** that can later be reused as:
- a refinement reference for mechanization
- a regression oracle for CI
- an artifact to pin in the evidence index

## Assumptions impacted (A-IDs)
None.

## Threat-model impact
None directly (this is an engineering evidence method). Indirectly reduces the chance of authorization/decoder drift.

## Assurance/verification impact
- Adds <PO-DRT-*> obligations.
- Adds E2 evidence artifacts (fuzz/mcheck reports) that support I-ENC-1, PO-ENC-DECODE, PO-ABI-TOTAL, PO-ACT-VALIDATE.

## Alternatives
- **Only fuzz production code**: cheaper, but no semantic oracle; misses “wrong but consistent” behavior.
- **Only mechanize proofs**: strong but slow; DRT catches bugs *before* proof investment and helps stabilize specs.

## Evidence plan
- **E2**: a minimal reference model for CH-ACP `validate` + differential fuzz corpus (including adversarial/malformed encodings).
- **E2**: CH-KABI canonical decoder + normalized-dispatch oracle compared against a prototype kernel dispatcher.
- CI gate: new CH-* versions must ship with at least one DRT harness.

## Open questions
- Where to host the definitional models: in-tree Rust crate vs external ITP-extracted interpreter.
- Which error taxonomy is stable enough to compare (exact codes vs coarse classes).
