# RFC-0037: Checkpoint/restore and migration substrate (D-CHKPT)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-CHKPT, D-RR (adjunct), D-ATOMICUPD (adjunct), D-SUPV (adjunct)

## Summary
Define a **user-space checkpoint manager** and a pinned **checkpoint manifest** (CH-CKPT) to enable cooperative checkpoint/restore, debugging snapshots, and migration hooks **without expanding the privileged core** or violating capability discipline.

## Motivation
We already plan for:
- deterministic replay for evidence/debug (D-RR),
- atomic base updates + rollback (D-ATOMICUPD),
- supervision/restart policy for fault containment (RFC-0017).

Checkpoint/restore complements these by enabling:
- rapid “save, reboot, restore” workflows during bring-up,
- crash-only services with explicit state handoff,
- controlled migration (within a machine; later across machines) for upgrades and maintenance.

Additional ecosystem upside (optional): **warm-start templates**.
If we can restore from a pinned checkpoint quickly, we can use checkpoints (or CH-INIT snapshots) as “template images” for spawning disposable domains with low latency (zygote-style), without adding any privileged-kernel mechanism. The same non-amplification rules apply: templates must not sneak in ambient authority.

The trap: making checkpoint/restore “transparent magic” tends to balloon complexity (interception, kernel hooks, covert state). We want the **minimum seam**: explicit, cooperative exports pinned by schemas and proofs.

Prior art sanity checks:
- **Streaming snapshot replication works**: ZFS send/receive demonstrates a practical “checkpoint stream” model (full or incremental) that is easy to transport and reason about; we can adopt the lesson as a *user-space artifact format* idea without importing ZFS itself.
- **User-space checkpoint tools are real**: CRIU/DMTCP show the edge cases and why opaque “magic” grows hooks; KUP demonstrates checkpoint/restart as a practical *update* mechanism when hotpatching is insufficient.
- **Microkernel-friendly checkpointing exists**: L4-family work demonstrates a user-level checkpoint server can handle most state, with only a minimal privileged seam for the few kernel-resident structures that must be reconstructed.

Refs: REF-CRIU, REF-DMTCP, REF-KUP-ATC16, REF-L4-ORTHOCHKPT, REF-ZFS-SENDRECV.

Template-spawn prior art: REF-ANDROID-ZYGOTE, REF-ANDROID-MEMORY-OVERVIEW, REF-CHROMIUM-ZYGOTE.


## Integration seam / kernel impact (keep small)
v0 assumes **cooperative checkpoints**:
- A component participates only if it exposes a `Checkpoint` interface to the checkpoint manager.
- Components must explicitly serialize their state into a content-addressed artifact and return a CH-AREF pointer.
- The privileged core does **not** implement a general “dump any task” facility for v0 (keep it out of MVP).

Kernel impact:
- none required beyond existing pause/resume and IPC primitives, if already present for debugging.
- If we later need non-cooperative capture for limited domains, gate it behind a dedicated debug capability and keep formats outside the core.

## Design (v0)

### Actors
- **Checkpoint manager (user space)**: orchestrates quiescence, requests exports, produces CH-CKPT, and performs restores under explicit authority.
- **Supervisors (user space)**: provide the quiesce boundary; they can stop restarts during capture and ensure a consistent cut for a component set (RFC-0017).
- **Components**: implement `{prepare, export, restore, resume}` with explicit failure modes.

### Protocol sketch
1. **Select scope**: manager chooses a component set; scope is recorded in CH-CKPT.
2. **Quiesce**:
   - supervisors stop restarts,
   - components reject new work, drain queues, and reach a declared “checkpoint-safe” point.
3. **Export**: each component writes its state bundle and returns a CH-AREF.
4. **Assemble CH-CKPT**:
   - list component IDs and their state artifacts,
   - optionally include a view/namespace snapshot pointer (D-NS),
   - optionally include a redacted capability graph digest (CH-CAPG) for leak tests.
5. **Restore** (explicit authority required):
   - validate CH-CKPT (canonical decode; bounds; artifact verification),
   - construct components under supervision (D-SUPV),
   - feed each component its bundle(s),
   - resume services; emit transcript entries for audit (CH-LOG).

### Security & assurance posture
- **Non-amplification**: restoring a checkpoint must not create new authority edges (I-CKPT-1; PO-CKPT-NOAMP). If a restore would require ambient acquisition, it fails.
- **Secrets are explicit**: checkpoints that require secrets must declare so; secret material is handled via explicit secret providers (e.g., an auth agent) and is never silently embedded.
- **Partial is explicit**: CH-CKPT can describe partial captures (I-CKPT-2); tooling must not assume completeness.
- **No implicit privilege**: a checkpoint bundle is not authority-bearing; restores require explicit “restore” capability.

### Relationship to deterministic replay (D-RR)
- D-RR is about *reproducing* a run given a nondeterminism stream.
- D-CHKPT is about *capturing a state*.
They compose:
- A checkpoint can optionally pin the replay stream position (CH-RR chunk ref) to support “restore then continue replay” debugging.

## Evidence plan
- E1: implement a toy “KV store” service with a supervisor; demonstrate cooperative checkpoint + restore while preserving capability graph (cap snapshot diff).
- E2: negative tests: attempt restore requiring ambient acquisition; verify deterministic rejection (PO-CKPT-NOAMP).
- E3: fuzz CH-CKPT parsing and artifact verification rules (PO-CKPT-VALIDATE, PO-AREF-VERIFY).

## Open questions
- The minimal cooperative quiesce/drain contract is specified in RFC-0108 (D-QUIESCE). Remaining question: which profiles require it vs crash-only fallback?
- Do we want a “Wasm-only checkpoint profile” early (easier isolation), before native components?
- How do we represent device-dependent state (leases vs rebind) without promising transparent migration?

Refs: REF-CRIU, REF-DMTCP, REF-SING-CHANCONTRACTS.
