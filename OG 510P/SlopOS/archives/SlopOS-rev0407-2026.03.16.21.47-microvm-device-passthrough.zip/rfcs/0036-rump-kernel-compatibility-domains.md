# RFC-0036: Rump-kernel compatibility domains for legacy drivers/FS (D-RUMPK)

Status: Draft  
Owner: archive  
Last updated: 2026-02-25

Goal: enable **fast, isolated reuse** of existing kernel driver/filesystem code *without* importing it into the privileged core.

This is an “ecosystem leverage” move: it trades code volume for time-to-hardware and compatibility, while keeping the trusted computing base small by containing that volume inside normal user-space components.

Refs: REF-RUMPKERNEL-WIKI, REF-RUMPKERNEL-ABC2015, REF-RUMPRUN-SEL4, REF-LKL-GITHUB, REF-L4RE-DEVICE-DRIVER, REF-FUCHSIA-DRIVER-FRAMEWORK, REF-WINDOWS-UMDF-OVERVIEW, REF-DRAWBRIDGE-ASPL11, REF-DRAWBRIDGE-POSIXPICO, REF-GVISOR-COST.

Translator attachment posture is separately pinned in `docs/30-architecture/translator-posture-v0.md`: compat-backed filesystem services may be exposed through translators, but attach/remove remains an explicit `view.slot` mutation with no host-global pathspace or translator inventory surface.

## Problem
A greenfield microkernel OS inevitably faces a bootstrapping problem:
- hardware enablement (drivers) is slow to rebuild from scratch
- filesystem/network stacks are huge and full of sharp edges
- bringing that code into the privileged core defeats the point of microkernel minimization

We want a bridge that is:
- **optional** and profile-gated
- **isolated by default** (crash-only containment)
- compatible with our capability discipline (no ambient authority)

## Background: rump kernels (NetBSD)
Rump kernels run selected kernel subsystems as **libraries in user space**. NetBSD uses them for testability and isolation, including mounting untrusted filesystem images by running the filesystem driver in a rump process rather than the kernel. This has also been evaluated in microkernel settings (e.g., Rumprun on seL4). Refs: REF-RUMPKERNEL-WIKI, REF-RUMPRUN-SEL4.

## Alternatives & comparisons (keep the seam, not the illusion)
Rump kernels are one point in a broader design space: “run big legacy surfaces *outside* the privileged core”.

- **Library OS + picoprocess (Drawbridge)**: isolates full applications by moving much of the OS surface into a per-app library OS. Great for “run legacy apps safely”, but the ABI surface is huge and the *compat layer* becomes a large attack surface (still outside the core). Refs: REF-DRAWBRIDGE-ASPL11, REF-DRAWBRIDGE-POSIXPICO.
- **Userspace kernel (gVisor-style)**: implements a Linux(-like) kernel API in userspace as an isolation boundary. It highlights the real *syscall tax* and the engineering effort needed for compatibility coverage. Ref: REF-GVISOR-COST.
- **Linux Kernel Library (LKL)**: runs Linux kernel code as a library in user space to reuse selected subsystems (networking/FS) without a full VM. It is a powerful reuse tactic but still brings a large donor surface; treat it as an untrusted compat capsule behind I-COMPAT-1/I-COMPAT-2. Ref: REF-LKL-GITHUB.
- **Microkernel DDE-style environments (L4Re lineage)**: practical techniques for porting/hosting legacy drivers in user space, often alongside pass-through and guest-VM options. Ref: REF-L4RE-DEVICE-DRIVER.
- **User-space driver frameworks (Fuchsia DF, Windows UMDF)**: isolate drivers in restartable host processes with explicit lifecycles; less “compatibility” and more “operational containment,” but a strong blueprint for D-DRVDOM + D-SUPV + D-ACTIVATE. Refs: REF-FUCHSIA-DRIVER-FRAMEWORK, REF-WINDOWS-UMDF-OVERVIEW.
- **Unikernels / sealed appliances (MirageOS, etc.)**: compile a single-purpose service into a minimal image and seal it against post-deploy mutation. This is more “avoid compatibility” than “provide compatibility”, but it’s a useful *deployment profile* that aligns with D-SEAL/D-FPM/D-BOOT. Ref: REF-UNIKERNELS-ASPL13.

**Our stance (for now):** keep D-RUMPK narrowly scoped to drivers/FS reuse and untrusted-input handling. See also RFC-0083 for the shared “compat capsule membrane” guidance. If we later want legacy *application* compatibility, treat it as a separate user-space subsystem with the same constraints: capability-mediated effects (I-COMPAT-1) and fail-closed ABI dispatch (I-COMPAT-2), with explicit evidence and leak testing (PO-COMPAT-CLOSESET/PO-COMPAT-NOAMBIENT).

## Design stance (minimal seam)
### 1) Rump is *a component runtime*, not a kernel feature
- A “rump domain” is just a normal component/driver domain.
- It receives only explicit I/O/resource capabilities (D-DRVDOM, D-METER, D-KOBJQ).
- It is supervised like any other service (RFC-0017).

### 2) Expose rump-backed services via existing user-space seams
Filesystem case (highest value):
- A rump-backed filesystem driver runs inside a rump domain.
- It exports a filesystem interface via a translator (D-TRANS) so it can be mounted into views (D-NS).
- The rest of the system never sees a special “rump path”; it just sees an ordinary mounted subtree.

Network/storage cases (later):
- Treat as optional future expansions once we have evidence that the authority and performance shape is acceptable.

### 3) Treat “untrusted inputs” as the first-class scenario
Primary motivation is **risk containment**:
- malformed filesystem images or hostile network inputs should not be able to corrupt the privileged core
- failures should be contained to the rump domain and handled by supervision/restart policy

## Threat and assurance notes
- A rump domain may contain a large amount of C code; it should be treated as **untrusted**.
- Capability discipline is non-negotiable: rump domains must not be granted broad ambient naming authority.
- The translator boundary must enforce view-scoped access checks (I-VIEW-2) and keep resolution non-amplifying (PO-VIEW-NOAMP).

## Decision (D-RUMPK)
Options:
1) none (default)
2) rump kernels for filesystem drivers only (recommended first step)
3) broaden to selected storage/network subsystems
4) alternative compatibility runtimes (future; not scoped here)

Evidence to collect:
- time-to-first-mount on a representative FS (e.g., ext2 or a read-only FS)
- containment of crashes/fuzzed inputs (core remains intact)
- resource overhead (memory footprint, IPC/translation cost)
- operational ergonomics (how it composes with views and translators)

## Evidence plan (tight)
Phase 1:
- implement a rump-domain prototype that exports a read-only filesystem via a translator
- fuzz a corpus of malformed images against the rump domain and show:
  - the privileged core does not crash or corrupt state
  - restart policy recovers or quarantines the service deterministically

Phase 2:
- performance characterization: mount + metadata ops + sequential reads
- add a “least authority” audit: cap-graph export (CH-CAPG) confirms no unintended authority edges were introduced during mount

## Archive impact
- Adds this RFC.
- Adds D-RUMPK to the decision map.
- Adds references for rump kernels and a seL4 evaluation.
- Adds a new “ecosystem seed” entry (RFC-0003 §24) and a short lesson mapping entry.
