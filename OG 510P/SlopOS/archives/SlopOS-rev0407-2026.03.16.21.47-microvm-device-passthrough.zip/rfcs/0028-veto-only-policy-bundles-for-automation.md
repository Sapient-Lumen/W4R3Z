# RFC-0028: Veto-only policy bundles for automation (Cedar profile)

Status: Draft  
Owner: archive  
Last updated: 2026-02-23

## Summary
Introduce an optional **policy-bundle seam** (D-POLICY) for IF-ACP (and optionally CH-COMP routing) where a pinned, deterministic policy engine can **only deny** actions that would otherwise be accepted by explicit capability/approval checks.

This adds defense-in-depth and auditability without creating a new authority-granting mechanism.

## Motivation
We want a practical, reviewable way to express operational guardrails (“ACP may never write boot policy”, “max N mints per session”, “deny reconfiguration unless change ticket is present”) while keeping the kernel security story centered on **capabilities + deterministic validators**.

A good candidate is Cedar: an open-source policy language and evaluation engine with a published reference guide and supporting tooling (REF-CEDAR). Cedar also ships a separate formalization + differential testing infrastructure (REF-CEDAR-SPEC), which aligns with our spec-first / evidence-driven posture.

## Design

### D-POLICY (non-amplifying posture)
- **Policy is a veto, not a grant**: acceptance requires *both* (1) existing explicit authorization (caps/approvals) and (2) policy “allow”.
- Therefore, a policy engine bug cannot create new authority edges; it can only fail to impose an additional operational restriction.
- Policy evaluation is **deterministic** and depends only on pinned inputs (CH-POLICY) + the candidate action (CH-ACP).

### Where policy runs
- Policy evaluation is a **user-space** service used by IF-ACP (and optionally by the component manager).
- The privileged core stays policy-agnostic.

### Inputs and bindings
When D-POLICY is enabled:
- A **CH-POLICY v0** bundle is loaded (by init/IF-BOOT policy) and its digest is optionally listed in CH-BOOT `artifacts`.
- IF-ACP includes `policy_digest` in transcript entries for accept/reject decisions (CH-LOG).
- Policy evaluation is applied *after* basic CH-ACP validation (schema/expiry/binding) and *before* emitting any privileged effect.

### Semantics hook in ACP
Extend the ACP validator semantics slice:
- `Policy` in `S_acp` becomes an explicit, pinned **CH-POLICY** handle.
- Add an optional check: `policy_allows(policy, a, ctx)`.
  - `ctx` is bounded and must not include untrusted observations unless they are explicitly authenticated/pinned.
  - Tool outputs remain data (I-OBS-2).

### Obligations
- **I-POLICY-1**: policy inputs are pinned (digest + engine revision) and evaluation is deterministic.
- **I-POLICY-2**: policy is non-amplifying: it cannot be used as the sole basis for authorization.
- **PO-POLICY-DETERMINISM**: `policy_allows` is deterministic and total (fail-closed on errors).
- **PO-POLICY-NONAMP**: acceptance still requires explicit authorization (caps/approvals) regardless of policy outcome.

## Assumptions impacted (A-IDs)
None.

## Threat-model impact
- Helps constrain ACP “authority laundering” in practice by encoding session budgets/deny-lists, but does **not** by itself prove I-LLM-2 (sequence properties still require an explicit ledger/fuel model).
- Adds an implementation component (policy engine) whose failures should not expand authority due to veto-only design.

## Assurance/verification impact
- New CH schema: CH-POLICY v0.
- Adds <PO-POLICY-*> obligations; evidence is primarily E1/E2 (tests + DRT harness).

## Alternatives
- **OPA/Rego**: powerful but larger surface; can still be adopted later behind CH-POLICY.
- **Zanzibar-style graph authorization**: good for large distributed systems, but our runtime authority is capability-based; keep any such system as advisory tooling rather than enforcement.
- **No policy engine**: acceptable early, but then all operational guardrails become ad-hoc code paths.

## Evidence plan
- **E1**: golden-policy tests: deterministic decisions and fail-closed behavior.
- **E2**: DRT harness comparing a definitional policy model (or a simplified reference interpreter) against the chosen production engine for a bounded policy subset.

## Open questions
- Should CH-POLICY embed policy text vs refer by digest to separate artifacts? (v0 prefers digests to keep bundles small.)
- Which contexts are allowed for policy decisions (strictly action fields + pinned config; no tool outputs by default).
