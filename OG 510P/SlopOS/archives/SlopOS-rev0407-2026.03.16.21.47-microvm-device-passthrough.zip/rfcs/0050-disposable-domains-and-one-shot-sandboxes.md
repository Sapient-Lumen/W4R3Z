# RFC-0050: Disposable domains + one-shot sandboxes (D-EPHEM)

Status: Draft  
Updated: 2026-03-09  
Decision node(s): D-EPHEM, D-PLUMB, D-SEAL, D-CAPMODE, D-SUPV

## Summary
Add an optional “**disposable domain**” mechanism: a supervisor can spawn short-lived, **auto-reset** execution environments for risky tasks (opening untrusted documents, previewing downloads, running third‑party scripts). By default, disposable domains:

- start from a pinned template image/config
- run **sealed** (D-SEAL) and (optionally) in capability mode (D-CAPMODE)
- have **no persistence** except via explicit export portals
- are destroyed deterministically, revoking all leases and durable handles

This is a *user-space* policy and UX feature built on existing primitives (domains/components, views, portals, leasing), not a privileged-kernel feature.

## Motivation
Real users do risky things every day. The best “least privilege” posture is often **don’t make a permanent mess**:

- Open the sketchy PDF in a disposable and delete it afterwards.
- Browse in a disposable and kill it when you’re done.
- Run a one-off tool in a disposable that cannot silently persist creds/keys.

Qubes demonstrates operational value with “disposable qubes” and a clear UX mental model. Some commercial systems use “micro‑VM per task/tab” isolation for similar reasons.

We want that value without rebuilding a whole hypervisor OS in the base design:

- the disposable is *a policy posture* that composes with our capabilities, views, portals, and leasing.

## Non-goals
- Prove that a disposable domain prevents all exploitation (out of scope).
- Make disposables the only containment story.
- Require virtualization; disposables can be implemented as process domains, microVM domains (D-MICROVM), or static partitions (D-PART) depending on the platform profile.

## Design

### Core concept
**Disposable domain** = a domain with:
- **ephemeral writable layer** (overlay) over a pinned template
- default-deny view and networking posture
- strict export surface: only portal-mediated exports

### Lifecycle
1. **Spawn**: supervisor creates a new domain from a template (template digest pinned by CH-BOOT/CH-CFG policy).
2. **Configure**: install a narrow view (RFC-0032), routes (CH-COMP/CH-ROUTE), and a budget (D-METER/D-TCAP if enabled).
3. **Seal**: domain voluntarily drops promises and enters sealed steady state (RFC-0016). Optionally enter D-CAPMODE.
4. **Use**: user performs the risky task.
5. **Destroy**: supervisor tears down the domain and any attached leases; all capability handles become invalid.

### Fast spawn: warm templates (“zygote” pattern)
Disposable domains are only a default habit if spawn latency is low. A practical, widely deployed pattern is to keep a **long‑lived template spawner** that performs expensive setup once (loader/linker work, runtime init, cache warmup), then forks/clones on demand:

- **Template spawner (user space)** owns one or more warmed templates (often per ABI/profile).
- **Spawn** clones a child (fork/clone or snapshot‑restore), then immediately applies the disposable posture: install view/routes → seal/capmode.
- **Safety posture**: treat the template as *tainted authority*.
  - Keep it minimal and avoid giving it ambient introducers.
  - Ensure post‑spawn narrowing is **one‑way** (D-SEAL/D-CAPMODE) so inheritance cannot widen authority.
  - Bind template identity by digest (CH-INIT or CH-CKPT) in CH-BOOT/CH-CFG so “what template created this disposable” is auditable.

This keeps the privileged core unchanged: it is an ecosystem/runtime choice layered on D-EPHEM.

Pinned follow-up: `docs/30-architecture/disposable-domain-posture-v0.md` fixes the Phase 1 meaning — digest-pinned templates are allowed, but disposables remain fresh one-shot instances with explicit export-only persistence, no hidden session/network continuity, and mandatory entropy/identity refresh before user payload runs.

### Storage semantics
- The disposable’s writable layer is ephemeral and **must not** be mounted into persistent global stores.
- Persistence is possible only by **export** operations that materialize an object into a destination store under explicit authority.

### Exports (strict)
Exports use the workflow router/portals (RFC-0046):
- `ExportFile`, `ExportText`, `ExportArtifact` are explicit intents.
- completion requires cap-graph diff gates (D-CAPAUD if enabled) and (optionally) consent/volition.
- default policy: exports are **deny by default** unless the user chooses a destination.

### Device and high-risk privileges
Disposables should not directly attach physical devices by default.
If device access is granted, it should be via D-IOLEASE (RFC-0045) with short TTLs and explicit revocation.

### UX patterns
Provide a few “blessed” entry points:
- “Open in Disposable” action for file manager and browser downloads.
- “Paste into Disposable” for content that should not reach persistent apps.
- “Run Script in Disposable” for automation, with strict portal-only I/O.

### Where this sits in the architecture
This is primarily a **supervisor + templates + portal policy** design.

Kernel requirements: none beyond existing domain isolation and capability revocation semantics.

## Invariants and obligations
Additions (for D-EPHEM profiles):

- **I-EPHEM-1 (Disposable reset)**: on destroy, disposable writable state is not reachable by any subsequent domain unless explicitly exported.
- **I-EPHEM-2 (Export is explicit)**: any state that leaves a disposable crosses a portal/grant boundary and is transcript-logged.

Proof obligations:
- **PO-EPHEM-RESET**: destroy path fully tears down the writable layer and revokes leases; reuse is impossible under stated assumptions.
- **PO-EPHEM-EXPORT**: any cross-domain export surface is mediated (CH-ROUTE/IF-CONSENT) and non-amplifying.

## Threat-model impact
New optional trusted components:
- disposable supervisor/runtime (user space)
- template store / builder (likely already present under D-FPM/D-ATOMICUPD)

Key mitigations:
- keep disposables policy-driven; supervisor is restartable (D-SUPV)
- bind template digests in CH-BOOT/CH-CFG and validate deterministically
- record exports/denials in CH-LOG for audit

## Evidence plan
E1: prototype “Open in Disposable” flow using a minimal template + ephemeral overlay; tests ensure no persistence without explicit export.

E1: negative tests: attempt to bypass portal export via path tricks, name confusion, and implicit clipboard routes.

E2: cap-graph diff gates for exports (if D-CAPAUD enabled) and deterministic teardown/reuse checks.

## References
Refs: REF-QUBES-ARCH, REF-QUBES-DISPOSABLES, REF-BROMIUM-MICROVM, REF-PLASH, REF-XDG-PORTAL, REF-ANDROID-ZYGOTE, REF-ANDROID-MEMORY-OVERVIEW, REF-CHROMIUM-ZYGOTE.
