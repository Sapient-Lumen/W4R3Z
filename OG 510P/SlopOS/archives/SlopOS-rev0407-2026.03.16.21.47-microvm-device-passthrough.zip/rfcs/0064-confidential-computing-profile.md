# RFC-0064: Confidential-computing profile (D-CC)

Status: draft

## Goal
Make **confidential computing** (TEE-backed VM isolation + remote attestation) a **first-class *optional* deployment extension** that:
- never becomes an implicit guarantee (“magic security”),
- binds CC attestation evidence to **our own boot/provenance artifacts** (CH-BOOT / CH-PROV),
- stays **out of the privileged core** (policy and protocols live in user space),
- and is explicit about what *is not* improved (e.g., side channels).

## Non-goals
- Not a mandate to support any specific CC technology.
- Not a complete attestation transport/protocol spec (profiles may use COSE/JWS/EAT, cloud-provider APIs, or custom).
- Not a claim of side-channel resistance or “hypervisor removal”. CC mode changes assumptions; it does not delete threats.

## Summary
Introduce **D-CC** as an optional profile extension (see `deployment-profiles.md`) with two sub-modes:
- **attest-only**: remote parties can *verify* boot state, but isolation assumptions are unchanged.
- **enforced-isolation**: remote parties can additionally assume the CC substrate enforces a documented isolation model (A-CC-1).

We standardize one key design move:
> **Always bind CC evidence to our own `boot_digest`** (digest(CH-BOOT)) using a technology-native “reportdata/nonce/user-data” field.

Concrete mapping strategy:
- A user-space **attestation binder** requests a CC report/quote/token from the platform, supplying **REPORTDATA = H(boot_digest || policy_rev || nonce)** (or a canonical equivalent).
- The binder emits a **CH-ATTEST v0** payload where `boot_digest` and `freshness.nonce` are verified by the verifier and cross-checked against the embedded CC evidence.
- Any additional CC claims (e.g., measurement registers, platform security version) ride in `eat_payload` (optional) or in an external, profile-specific container referenced by CH-ATTEST (via CH-AREF if large).

This aligns the CC story with the RATS roles and vocabulary (Attester/Verifier/Relying Party) without importing RATS protocol complexity into the kernel. (REF-RATS-RFC9334)

## Why this is worth “baking in” now
CC ecosystems repeatedly fail in practice because evidence is:
- **unbound** to the application’s actual configuration (you verify the wrong thing),
- **unfresh** (nonce confusion/replay),
- or **over-claimed** (“CC == secure”).

By treating D-CC as a *profile extension* and requiring **digest binding to CH-BOOT**, we make CC usable as a clean gate for:
- secret release (keys, decryption material) from external systems,
- supply-chain/rollout policy (“only deploy to verified state X”),
- and audited provenance (“what did we actually run?”).

## Threat model alignment
### What D-CC can help with
- A remote party wants evidence that a machine is running an expected OS build/config (ties into C-PROV-1/C-PROV-2 via CH-PROV digests).
- A remote party wants to release secrets only after verifying a specific boot state.

### What D-CC does *not* automatically solve
- Side channels (timing/microarchitectural) unless separately scoped/mitigated (D-SIDECH).
- Local physical attackers who can subvert the CC root-of-trust assumptions (unless explicitly modeled).
- Compromised guest software after boot (attestation answers “what booted”, not “what happens next”).

## Platform annexes (minimal, practical)
We do not require vendor-perfect detail in Phase 1; we require the **binding surface** and **assumption surface** be explicit.

### AMD SEV-SNP (example)
- CC evidence: SNP attestation report includes a launch measurement and is signed/endorsed by AMD-rooted keys; cloud providers may expose the report to guests via guest drivers/APIs. (REF-AWS-SNP-ATTEST, REF-AMD-SNP-ATTEST-PDF)
- Binding hook: use the report’s user-data/nonce field (where available) to carry `H(boot_digest || nonce)`.

### Intel TDX (example)
- CC evidence: TDX attestation involves a TDREPORT (includes 64-byte REPORTDATA) and quote generation; the report includes measurements and platform SVNs. (REF-LINUX-TDX)
- Binding hook: set TDREPORT REPORTDATA to `H(boot_digest || nonce)`; verifier checks the quote’s REPORTDATA matches the CH-ATTEST binding.

### Arm CCA (future-looking)
- CC evidence: CCA defines protected execution environments (“Realms”) and a platform+realm attestation story; deployments typically wrap this in a higher-level protocol to gate secret release. (REF-ARM-CCA-REALMS)
- Binding hook: require a realm-provided “challenge/user-data” field that can carry `H(boot_digest || nonce)` (profile-specific).

## Interface + artifacts
No new privileged interfaces are required beyond existing attestation/export seams.

Required artifacts already exist:
- CH-BOOT v0: measured record (boot state)
- CH-ATTEST v0: payload-to-sign / verifier binding
- CH-PROV v0: optional provenance payload

Recommended:
- If CC evidence containers are large, reference them using **CH-AREF** to avoid bloating the archive and to keep verifier logic digest-driven.

## Operational pattern: attestation-gated secret release
A typical flow (RATS terms in parentheses):
1) OS boots and emits CH-BOOT.
2) Attestation binder (Attester) requests CC evidence with REPORTDATA bound to boot_digest + nonce.
3) Binder presents CH-ATTEST + CC evidence to a Verifier.
4) Relying party releases a scoped secret only if:
   - signature chain + endorsements validate per policy,
   - embedded REPORTDATA matches `H(boot_digest || nonce)`,
   - `boot_digest == digest(CH-BOOT)`,
   - (optional) prov_digest matches the expected provenance bundle.
5) If the runtime also uses `ext.microvm` clone/restore acceleration, any later generation-witness change invalidates the freshness-bound attestation/export state and the relying-party secret-release session; a fresh nonce/reportdata exchange is required rather than resuming a cached pre-restore session (`microvm-attestation-reacquire-posture-v0.md`).
6) Even after that fresh exchange, the portable attestation claim remains about the current boot/provenance lineage and freshness binding; it does not, by itself, prove one exact resumed warm-start leaf or restored memory image. If policy cares which admitted leaf was resumed, that identity must come from separate explicit lineage/admission evidence (`microvm-attestation-scope-posture-v0.md`).
7) That exact resumed leaf identity, if exported at all, remains owner-local admission/provenance evidence rather than a guest-visible leaf-id API or a new `CH-ATTEST` claim; Phase 1 standardizes no portable warm-start leaf identity schema (`microvm-resume-admission-evidence-posture-v0.md`).

## Evidence plan (for promotion to ADR)
- **E1**: unit tests for the binder mapping: nonce inclusion, boot_digest hashing, fail-closed validation.
- **E1**: negative tests: replay (nonce mismatch), substituted CH-BOOT digest, substituted CC evidence container.
- **E2**: one platform integration (SNP or TDX) demonstrating end-to-end bind + verify, even if the “verifier” is a test harness.

## Interactions
- D-ATTEST (RFC-0025): D-CC is a *profile* that feeds into CH-ATTEST.
- D-TLOG / D-AREF: helpful for publishing/verifying evidence digests out-of-band.
- D-SIDECH: CC mode must not silently expand claims; side channels remain explicit non-claims unless modeled.

## Open questions
- Which CC technology is the first “reference implementation” target (SNP vs TDX vs CCA emulator)?
- What is the minimum verifier policy format we accept (static allowlist of measurement digests vs structured policy bundle)?
