# RFC-0049: Temporal capabilities + scheduling contexts (D-TCAP / D-SCHED / D-UPCALL)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-TCAP, D-SCHED, D-UPCALL, D-METER

## Summary
Make **CPU time** a first-class, capability-mediated resource by adopting a **scheduling-context** model (seL4 MCS-style): a schedulable entity (thread/vCPU) runs only when it holds a **Temporal Capability** (TCap) that carries a budget/period/priority grant. TCaps are normal capabilities: they can be delegated and attenuated, and they compose with existing resource meters (D-METER).

Key extra win: enable **passive servers** and **time donation over synchronous IPC**, so an RPC-style server can run “on the caller’s time” without the kernel needing to implement policy-heavy priority inheritance.

This RFC sharpens and supersedes the D-TCAP sketch in RFC-0008, turning it into a concrete design seam that stays mechanistic in the privileged core.

## Motivation
We want to avoid the classic OS trap where scheduling policy becomes implicit, ambient, and unverifiable:
- “Who is allowed to consume CPU?” is an access-control question.
- “Who pays for this server’s work?” is an accounting question.
- “Who can cause priority inversion?” is a correctness/security question.

Scheduling-context capabilities (seL4 MCS) show a compact approach: represent time as a capability object bound to a thread; allow controlled transfer/donation of that object across IPC, keeping the kernel’s role mostly **mechanistic enforcement** rather than policy (REF-SEL4-SCHEDCTX-EUROSYS18; REF-SEL4-MCS-TUTORIAL).

Temporal Capabilities (TCaps) in the COMPOSITE line of work pursue a similar goal: integrate CPU management into a capability-based access-control system, decoupling scheduling decisions from the authority to consume time (REF-TCAPS-RTSS17).

## Design constraints
- **Kernel stays mechanistic:** kernel enforces budgets and well-formed transfer rules; user space chooses policies.
- **Deterministic enforcement path:** budget accounting/expiration and failure modes must be total and fail-closed (I-ENC-1 + PO-*).
- **Composable with D-METER:** time is just another charged resource; no “parallel accounting universe.”
- **Usable for RPC:** passive server + donation is a first-class supported pattern, not an accident.

## Proposal
### 1) Scheduling contexts as TCaps
Introduce a kernel object (conceptually, a scheduling context) whose capability is the **TCap**.

A TCap grants:
- **budget**: max execution time per period (or per replenishment window)
- **period** (optional for periodic threads)
- **priority / criticality class** (closed set)
- optional flags: `preemptible`, `donatable`, `replenish_policy`

A thread/vCPU is runnable iff it has a TCap **bound**.

### 2) Bind/unbind rules
- A runnable entity has at most one bound TCap.
- Unbinding makes the entity **passive** (cannot run until it receives a donated/bound TCap).
- Budget depletion causes deterministic blocking/yield behavior per profile (fail-closed semantics: either stop running or switch to an explicitly configured “overrun” mode).

This mirrors the “passive server” model in seL4’s MCS extensions (REF-SEL4-MCS-TUTORIAL).

### 3) Time donation over synchronous IPC (passive servers)
For an RPC call to a passive server:
- Caller performs `Call` (or equivalent rendezvous).
- If callee is passive and waiting on the endpoint, the kernel **donates** the caller’s TCap to the callee for the duration of the call.
- The callee is “borrowing” the TCap; it must be returned on reply (or at most when the call frame is unwound). In seL4, the donated scheduling context is returned when the reply capability is consumed / unbound (REF-SEL4-API-SC-UNBIND).

This gives two desirable properties with minimal kernel policy:
- **No free server time:** servers don’t run unless someone donates time.
- **Accounting is automatic:** the caller pays for the callee’s work.

### 4) User-level scheduling policy via D-UPCALL
If D-UPCALL is enabled, the kernel surfaces *events* (budget exhausted, replenishment point, wakeups) to a user-level scheduler component.

Kernel responsibilities remain narrow:
- enforce budgets and transfer rules
- deliver upcalls / notifications
- prevent forged time authority (I-TCAP-1)

### 5) Composition with D-METER
Time budgets should be chargeable to a meter:
- creating a TCap consumes/locks some meter budget
- replenishment/period rules can charge “time debt” explicitly
- metering makes denial-of-service analysis clearer (“this tenant ran out of time budget”) instead of ambiguous scheduler behavior

### 6) CH-TCAP v0 for pinned/auditable configuration
To make initial state and configuration auditable (and replayable), define **CH-TCAP v0** as a redaction-safe descriptor for a TCap’s intended parameters.

Primary uses:
- CH-INIT entries for `kind: TCap` can carry `params` conforming to CH-TCAP v0.
- CH-LOG can reference `digest(CH-TCAP)` when creating/delegating a “named” budget grant in privileged configuration flows.

## Registries impacted
- **Schema:** add **CH-TCAP v0** + schema-registry entry.
- **Invariants:** add
  - **I-TCAP-2 (Borrowed time is returned, optional):** for donation-enabled profiles, donated TCaps are returned to the original owner under all call/abort paths; no TCap is lost, duplicated, or retained past the donation scope.
  - **I-TCAP-3 (Passive servers cannot run on ambient time, optional):** a passive server has no runnable state without a bound/donated TCap; the kernel never schedules it “for free.”
- **Proof obligations:** add
  - **PO-TCAP-VALIDATE (ENC/TIME):** CH-TCAP decoding/validation is deterministic; enforces bounds and closed enums; rejects unknown variants.
  - **PO-TCAP-DONATE (TIME/SCHED):** donation semantics preserve authority/accounting: no duplication, bounded depth, deterministic return on reply/abort.

## Threat-model impact
New/changed risks:
- **DoS via time exhaustion:** callers can starve themselves (intended) or starve shared services if policy allows unlimited donation.
- **Budget laundering:** attempting to create runnable time without owning a TCap (must be prevented by I-TCAP-1/I-TCAP-3).
- **Covert channels:** timing and cache effects remain an explicit non-claim unless D-SIDECH is adopted; time-as-cap helps define boundaries but does not magically fix microarchitectural channels.

Controls:
- TCap creation is capability-mediated and metered (D-METER, PO-METER-CHARGE)
- bounded donation depth and explicit “donatable” flag
- optional tie-in to time-protection scopes if ever adopted (REF-SEL4-TIMEPROTECTION)

## Assurance/verification impact
This design is attractive because it isolates obligations:
- budget accounting invariants are local and mechanistic
- donation paths are enumerable and can be model checked
- user-level scheduling policy can be reasoned about separately from the kernel’s enforcement core

## Evidence plan
- E1: prototype single-core TCap enforcement + passive server donation in a toy kernel model; property tests for conservation/return.
- E2: model-check donation/return state machine (bounded call depth) + budget depletion behavior.
- E3: mechanize PO-TCAP-DONATE preservation in the chosen proof framework once the interface stabilizes.

## Alternatives
- Classic priority inheritance in kernel: works, but drags policy into the privileged core.
- Strict time-and-space partitioning (TSP): simple but inefficient; poor fit for cooperative systems.
- “Just use cgroups”: mixes policy and enforcement; doesn’t integrate with capability authority.

## Open questions
- What is the minimal set of TCap fields we should commit to in v0 to keep proofs tractable?
- Should donation be limited to explicit endpoints only (no “implicit donation”)?
- How do we represent/charge server work that is *not* triggered by a specific caller (timers, IO interrupts)?
