# RFC-0008: Event plumbing, temporal capabilities, and driver domains

Status: Draft  
Last updated: 2026-02-23  

## Summary
This RFC proposes three **low-cost, high-leverage** directions that fit our spec-first, capability-mediated posture and can be implemented largely in **user space** without expanding the privileged core:

1. **D-EVENTBUS**: a Plan 9 “plumber”-style *event routing* substrate, but **capability-mediated** and schema-pinned.
2. **D-TCAP**: **temporal capabilities** (time/CPU as explicit authority) to unify scheduling rights with resource accounting.
3. **D-DRVDOM**: “driver domains” with **explicit I/O resource capabilities** and an **IOMMU-first** posture, keeping device logic outside the core.

These are framed as *optional profiles/mechanisms* until evidence supports upgrading them into ADRs/claims.

## Motivation (why these are unusually good fits)
- They reinforce our core behaviors: constrain-claims, minimize-TCB, spec-first, prototype-to-evidence.
- They are “compositional primitives”: they let user space express powerful policies **without** importing policy into the kernel/hypervisor.
- They enable targets that many projects avoid because they require *cross-cutting discipline*: capability mediation + determinism + provenance + explicit interfaces.

## Proposal

### 1) D-EVENTBUS: capability-mediated event plumbing (Plan 9 plumber, but least-authority)
Goal: a small substrate for routing UI/ops/control-plane events among services without ambient broadcast channels.

Sketch:
- Events are **typed** (CH-* schema), **canonical-encoded** (I-ENC-1), and optionally logged (CH-LOG).
- Subscription is via an **event capability**; topics are rights, not strings.
- The router itself can be a user-space service; privileged involvement should be *zero* unless we later prove a tight kernel primitive is necessary.

Expected wins:
- A clean place to integrate operator workflows, ACP proposals, and observation export while preserving “no ambient authority”.
- A natural “composition layer” to borrow Plan 9 ergonomics (linking, routing, pipelines) without importing Plan 9’s ambient naming.

Additions required elsewhere:
- Invariants: I-EVENT-1, I-EVENT-2
- Proof obligations: PO-EVENT-NOAMBIENT, PO-EVENT-SCHEMA
- Abuse case: AC-017

### 2) D-TCAP: temporal capabilities (time/CPU as explicit authority)

Note: the concrete scheduling-context + time-donation design is detailed in RFC-0049; this section remains a high-level motivation stub.
Goal: make **CPU time / scheduling rights** a first-class capability-managed resource.

Sketch:
- A *temporal capability* represents a budget/priority/period grant (or a slice of scheduling authority) that can be delegated/attenuated like other caps.
- Charging and attribution can unify with meters (D-METER) rather than adding a parallel accounting model.
- Start with a constrained profile (single-core + deterministic scheduling) so the abstract machine can model it without concurrency explosion.

Expected wins:
- A clean “least authority” story for scheduling policy: the kernel/hypervisor enforces *mechanistic rules*; user space holds policy.
- A path to “QoS as authority” without turning the privileged core into a policy engine.

Additions required elsewhere:
- Invariant: I-TCAP-1
- Proof obligation: PO-TCAP-ENF
- Abuse case: AC-018

### 3) D-DRVDOM: driver domains + explicit I/O resource capabilities
Goal: keep device logic outside the privileged core while preserving strong isolation and avoiding “driver TCB creep”.

Sketch:
- Drivers run in user space (“driver domains”).
- Device access is mediated through explicit capability objects for:
  - MMIO/PIO ranges
  - IRQ endpoints
  - DMA windows / IOMMU mappings
- The DMA posture is still governed by D-DMA/A-DMA-1, but D-DRVDOM makes the *architectural split* explicit.

A particularly “juicy” option:
- Treat *IOMMU management* as a **delegable capability-controlled service** (user space can create device address spaces and mappings under authority). This mirrors modern “IOMMU from userspace” trends and aligns tightly with our minimal-core posture.


Bridge strategy (optional):
- Reuse existing driver code in user space via **rump kernels** (NetBSD) to accelerate bring-up while keeping the privileged core small.
- Treat rump-based drivers as untrusted components: they only receive explicit MMIO/IRQ/DMA capabilities and run behind restartable supervision.
- This is a *migration tactic*, not an architectural dependency: long-term we still want native driver-domain APIs and reduced legacy baggage.
Refs: REF-RUMPKERNEL-ABC2015, REF-RUMPKERNEL-TUT.
Expected wins:
- Reliability/security: driver faults can be contained/restarted without collapsing the whole system.
- Assurance: device/model complexity sits outside the privileged proof surface.

Additions required elsewhere:
- Invariant: I-IORES-1 (and it composes with I-DMA-1)
- Proof obligation: PO-IORES-AUTH
- Abuse case: AC-019

## Alternatives / non-goals
- Not trying to copy a full Plan 9 UX stack; we only steal the *routing primitive* (and keep it capability-mediated).
- Not claiming full real-time scheduling or global QoS; TCaps can start as a narrow authority mechanism for a constrained profile.
- Not committing to a specific device framework; D-DRVDOM defines the boundary and proof hooks first.

## Evidence plan (tight and staged)
- **E1 prototypes**:
  - user-space event router with capability-checked subscribe/publish; negative tests for ambient injection.
  - temporal-cap budget enforcement in a toy scheduler model.
  - driver-domain “hello device” with explicit MMIO/IRQ caps and an IOMMU-mapped buffer demo (where hardware supports).
- **E2 bounded model checks**:
  - model-check an event routing core (topics/rights) + a tiny capability graph.
  - model-check tcap mint/attenuate/charge rules in the abstract machine.
- **E3 mechanization**:
  - prove preservation of I-EVENT-1/I-TCAP-1/I-IORES-1 for the relevant transition rules.

## References (REF)
- Plan 9 plumbing: REF-PLAN9-PLUMB
- Temporal capabilities: REF-TCAPS-RTSS17
- User-mode drivers & reliability: REF-MINIX-RELIABLE-OS
- Static partition hypervisor practice: REF-JAILHOUSE
- Userspace IOMMU management: REF-LINUX-IOMMUFD
