# RFC-0060: CHERI-ready compartmentalization profile (D-CHERI)

Status: Draft  
Last updated: 2026-02-25  
Decision node(s): D-CHERI, D-ISA, D-DRVDOM, D-UNSAFE, D-CAPMODE

## Summary
Define an **optional** platform/profile track for **capability hardware** (CHERI / Morello / CHERI-RISC-V; and CHERIoT for embedded) that we can adopt *without* entangling the core design.

The aim is to:
- keep Phase‑1 bring‑up simple (no CHERI dependency),
- avoid design choices that make a CHERI evaluation *hard later* (e.g., pointer-as-int across trust boundaries),
- use CHERI where it shines: **shrinking the blast radius of unsafe code** (drivers, parsers, legacy C/C++ runtimes) via **fine-grained bounds/permissions** and cheap compartments.

Refs: REF-CHERI-INTRO, REF-CHERI-FAQ, REF-CHERI-MORELLO, REF-ARM-MORELLO, REF-CHERIOT, REF-CHERIBSD, REF-CHERIBSD-CAMBRIDGE, REF-CHERI-ANALYSIS-2026.

## Problem
Even with a Rust-heavy system, we will likely host some unsafe surfaces:
- vendor/legacy C/C++ (device stacks, codecs, DBs, compression),
- “systems glue” that benefits from C ABIs,
- third‑party plugins/tooling we don’t fully trust.

Pure software isolation (microkernel domains, Wasm components, language sandboxes) is strong, but:
- it can be expensive to make *very fine-grained* compartments,
- it doesn’t directly prevent memory-corruption primitives inside a compartment.

CHERI offers a different lever: **memory safety + compartmentalization support in the architecture** (unforgeable, bounds‑carrying pointers/capabilities), reducing common exploitation paths *within* a domain.

CheriBSD is a useful reality check: it extends a production Unix stack to use CHERI hardware for memory protection and software compartmentalization (pure-capability CheriABI), and the project has integrated work on library/co-process compartmentalization and temporal safety via capability revocation. Recent analyses also treat CheriBSD/Morello Linux as concrete systems to evaluate exploit suppression and residual risks.


## Decision surface (D-CHERI)
D-CHERI chooses whether we:
1) ignore capability hardware entirely (baseline),
2) support a **hybrid** CHERI ABI mode (legacy pointers + explicit `__capability` pointers),
3) support **pure-capability** (“purecap”) processes/compartments for stronger guarantees,
4) (long-term) consider CHERI in privileged components (kernel/driver runtimes) if it improves claims without ballooning TCB.

This is explicitly **profile-scoped**:
- High-assurance profile may prefer purecap user-mode compartments for unsafe code.
- Dev/desktop profile may use hybrid mode to keep toolchains and third‑party software easy.

## Design constraints (what we bake in now)
### 1) No cross-domain “raw pointer” contracts
All privileged or cross-domain interfaces (IF-*) must avoid “pointer-as-data” patterns:
- use explicit buffer descriptors, handles, or copy semantics;
- IDL/codegen (D-IDL) should produce pointer-free wire contracts by default;
- any “shared memory” ABI must be expressed as *capability-scoped mappings*, not address assumptions.

This improves baseline safety and also keeps CHERI adoption straightforward.

### 2) Capability model stays software-defined
We do **not** require CHERI to implement our object capabilities:
- kernel caps remain explicit objects/handles with our derivation + revocation rules,
- CHERI capabilities are treated as a *separate* hardware mechanism that can harden memory references inside compartments.

This avoids coupling our security story to a specific ISA.

### 3) Compartment strategy for unsafe code
Preferred pattern:
- run unsafe/legacy code in **driver domains / leaf compartments** (D-DRVDOM),
- bind them to narrow views (D-NS) and strict budgets (D-BUDGET),
- optionally compile the compartment as **purecap** (or hybrid initially), depending on profile.

### 4) Toolchain + provenance hooks
If D-CHERI is enabled for a profile:
- build graph (D-FPM) must record the ABI mode (baseline / hybrid / purecap) as an input,
- provenance (CH-PROV) must record compiler + flags sufficient to reproduce the ABI mode,
- deployment profiles must declare whether CHERI properties are relied on (A-CHERI-1).

## Security/assurance implications
- Baseline remains valid without CHERI.
- CHERI-enabled compartments can justify *profile-specific* claims like “memory-corruption blast radius is bounded to a compartment and cannot directly forge pointers outside its bounds” **conditional on A-CHERI-1**.
- CHERI does not replace our “no ambient acquire” discipline: capability routing and namespace controls remain the primary authority boundaries.

## Evidence hooks
- E1: build/run a minimal user-mode “unsafe plugin” compartment in QEMU/Morello or CHERI-RISC-V, demonstrate exploit class suppression (simple OOB write no longer yields control-flow hijack).
- E2: microbench + latency impact for IPC + shared-memory patterns under hybrid vs purecap.
- E3: cross-check a small formal model of “capability pointers can’t be forged” against our interface contracts (no pointer passing).

## Open questions
- Do we want *any* kernel-side CHERI reliance, or keep CHERI strictly user-mode?
- Which ABI mode should be the first evaluation target: hybrid (portability) vs purecap (clean semantics)?
- Where is the best “seam” to host legacy libraries: per-service, per-driver, or per-plugin runtime?

