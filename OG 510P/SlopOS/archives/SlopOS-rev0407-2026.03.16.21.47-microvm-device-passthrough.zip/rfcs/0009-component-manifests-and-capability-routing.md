# RFC-0009: Component manifests and capability routing (D-COMP)

Status: Draft  
Last updated: 2026-02-25

Goal: make the **system composition policy** explicit and reviewable by pinning a component graph (what runs, what it can import/export, and how capabilities are routed) as a signed, canonical artifact (**CH-COMP**), without importing a large privileged framework.

Motivation sources: Singularity’s “manifest-based programs” (pre-flight validation) and explicit contracts, plus Fuchsia/Genode’s “capability routing as composition” posture. Refs: REF-SING-OSR07, REF-FUCHSIA-COMPONENTS, REF-FUCHSIA-CML, REF-FUCHSIA-REALMS, REF-FUCHSIA-DECL, REF-GENODE-INIT.

Non-goals:
- Building a full “component framework” inside the kernel/hypervisor.
- Dynamic service discovery as ambient authority.
- Claiming global security guarantees from manifests alone (this is a seam, not a proof).

## Problem
Even with a capability kernel/hypervisor, systems tend to accrete *ambient* composition:
- “init scripts” that implicitly widen authority,
- ad-hoc service discovery,
- undocumented wiring of “who can talk to what,”
which makes audits and proofs brittle.

We want composition to be:
- **data** (versioned, signed, hashed),
- **lintable** (CI can check shape and authority edges),
- **bindable** (boot can measure the active composition),
- **enforceable** (user space refuses undeclared routes).

## Proposal
Adopt **CH-COMP v0** (see `docs/30-architecture/component-manifest-schema-v0.md`) as an optional artifact:
- Listed in CH-BOOT `artifacts` when used (role = `comp_manifest`).
- Consumed by a user-space init/component manager that:
  - launches components,
  - performs declared capability routing only,
  - drives init→seal transitions for `seal_after_init` components,
  - enforces optional readiness barriers (`ready.required`) via a one-shot ReadyToken handshake (RFC-0074),
  - emits transcript entries (CH-LOG) tying effects to manifest+action digests.

Kernel/hypervisor impact: *none required* beyond existing KABI actions for “create domain”, “map”, “grant cap”, etc.


### Optional: compile CH-COMP into a time-0 snapshot (Microkit/capDL lesson)
For some profiles (especially static/embedded/high-assurance), we want to minimize runtime degrees of freedom by compiling the declared architecture into a concrete time‑0 object/capability graph.

We can support this without changing the privileged core by treating CH-COMP as the authoring artifact and producing a bounded **CH-INIT** snapshot (D-INITSNAP) at build time:
- tools expand `routes` into concrete capability edges with explicit rights attenuation,
- tools allocate initial objects deterministically (IDs stable under a chosen ordering),
- boot lists and binds both digests (CH-COMP and CH-INIT) when snapshot mode is used.

At boot, a tiny initializer can install CH-INIT directly and then hand off to a user-space supervisor; audits can still ask “who could ever talk to X?” by reading CH-COMP, while “what actually existed at time‑0?” is pinned by CH-INIT.

This is the Microkit/capDL lesson: *treat architecture as data; generate the initializer; keep runtime small and testable*.

Refs: REF-MICROKIT-MANUAL, REF-MICROKIT-GITHUB, REF-CAPDL-KUZ10, REF-MICROKIT-VERIFY24.


### Borrowed manifest semantics (keep the lesson, not the framework)
Fuchsia’s component framework is valuable less for its machinery and more for its *declaration posture*: capabilities and routes are expressed as data, and tools can answer “who could ever see X?” by reading manifests rather than reverse-engineering init scripts.

We keep that posture but flatten it for CH-COMP v0:
- `imports` corresponds to a component’s declared `use` capabilities;
- `exports` corresponds to declared `expose` capabilities;
- `routes` corresponds to explicit routing (`offer`/`expose`) between instances;
- per-route `rights` is mandatory so capability reduction is reviewable and lintable.

Later versions can add realm-like boundaries and availability semantics without changing the privileged core: they remain validator rules over a pinned artifact.

Refs: REF-FUCHSIA-COMP-MANIFESTS, REF-FUCHSIA-CAPABILITIES, REF-FUCHSIA-CML.



### Optional: activation-owned endpoints and handle handoff (socket activation style)
Crash-only discipline becomes dramatically more usable when restarts don’t drop inbound traffic and don’t require ad-hoc “start ordering.”
We can get that without changing the privileged core by treating some exports as **supervisor-owned stable handles** and passing them into each service instance at start (socket activation), with an optional per-component handle store for continuity across restarts.

This is an ops-proven pattern (systemd socket activation + FD store; launchd socket activation; nginx on-the-fly upgrade), translated into capability terms.
See **RFC-0081 (D-ACTIVATE)** and the CH-COMP `activation` fields (v0 extension).

Refs: REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-FDSTORE, REF-LAUNCHD-ACTIVATE-SOCKET, REF-NGINX-CONTROL.

### Availability semantics (future extension)
Fuchsia’s component model provides precise semantics for **required vs optional** dependencies and for how routing availability behaves through a realm tree. We don’t need to import their whole framework, but we should steal the lesson:

- treat “this capability must be present” vs “use it if available” as an explicit declaration, not an ad-hoc runtime convention;
- make routing paths and boundaries (realms) visible so linting can answer “could this component ever see X?” statically.

For CH-COMP v0 we treat all `imports` as **required**. If/when we need optional deps, bump CH-COMP and add an `availability` field (required/optional/same_as_target) or equivalent, with deterministic validation rules.

Refs: REF-FUCHSIA-REALMS, REF-FUCHSIA-DECL.

## Candidate invariants / proof obligations
- **I-COMP-1 (No undeclared routes, optional)**: cross-component authority edges exist only if declared by CH-COMP routes (or otherwise recorded as explicit reconfiguration actions).
- **I-COMP-2 (Composition is digest-bound, optional)**: the running system’s composition graph is bound to the measured CH-COMP digest in CH-BOOT and is exportable via IF-OBS/CH-LOG.
- **PO-COMP-VALIDATE**: CH-COMP decoding/validation is deterministic and closed-world (unknown variants reject).
- **PO-COMP-BIND**: if CH-COMP is used, its digest is present in CH-BOOT and can be attested/exported for audit/replay.

## Evidence plan (stageable)
E1 (prototype-to-evidence):
- implement a tiny CH-COMP validator + router (user space)
- prove by tests that:
  - undeclared routes fail closed
  - seal_after_init components cannot regain dropped routes post-seal (integration with D-SEAL)

E2 (model-check fast):
- bounded model check on small graphs: “authority edges are monotonic attenuation-only” given the selected D-CAP semantics.

E3 (mechanize refinement):
- refine the CH-COMP semantics into the abstract machine model as an *environment configuration predicate*, without introducing new privileged mechanisms.

## Alternatives
1) **No manifest**: keep wiring implicit in init code.  
   - Pro: minimal upfront work.  
   - Con: composition becomes unreviewable; proofs/assurance drift.

2) **Kernel-resident component framework**.  
   - Pro: enforcement is “stronger” (in theory).  
   - Con: expands TCB and proof surface; likely violates minimize-TCB.

3) **Adopt Fuchsia/Genode wholesale**.  
   - Pro: mature feature sets.  
   - Con: scope explosion; mismatched to our small-core verification target.

## Open questions
- How to represent “namespaces/views” in CH-COMP without strings-as-authority (likely by referencing view-object instances).
- Which cap_kinds are in the v0 closed set (must align with `capability-semantics.md`).
- Restart/reincarnation policy is now captured minimally in CH-COMP v0 via `restart` + `critical` fields (see RFC-0017).

