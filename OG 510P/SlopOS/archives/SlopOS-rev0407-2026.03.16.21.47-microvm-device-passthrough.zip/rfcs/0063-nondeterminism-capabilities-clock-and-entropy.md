# RFC-0063: Nondeterminism capabilities (Clock + Entropy handles) (D-NONDET)

Status: Draft

Goal: make **time** and **randomness** explicit, capability-shaped authorities so that:
- D-RR can truly pin the nondeterminism boundary (time/entropy are not “ambient syscalls”)
- untrusted code (plugins, parsers, compat domains) does not automatically get high-resolution clocks
- testing/simulation can swap providers (deterministic clocks/entropy) without ad-hoc hooks

## Problem
Most OS APIs treat time and randomness as ambient:
- `clock_gettime()` / `gettimeofday()`
- `/dev/urandom` / `getrandom()`

This creates three recurring failures:
1) **Replay breaks by default**: any code path that consults time/entropy implicitly creates a hidden input channel.
2) **Fingerprinting + timing oracles become ubiquitous**: high-resolution clocks are powerful oracles even if we make no side-channel *claims*.
3) **Testability suffers**: “fake time” and “fake randomness” become special cases instead of an explicit seam.

The archive already calls out “avoid ambient time/entropy” in D-RR and D-WASM, but does not yet define the mechanism.

## Non-goals
- Not a claim of general side-channel resistance (D-SIDECH remains a non-claim unless adopted).
- Not a promise of perfect wall-clock accuracy or secure NTP.
- Not a requirement that every component must operate without time; instead, time access must be explicit.

## Prior art
- **WASI Clocks**: capability-oriented clock handles rather than implicit global clock functions (REF-WASI-CLOCKS).
- **OpenBSD getentropy()/arc4random()**: treat kernel entropy primarily as **seed material** with bounded reads; use fast per-process CSPRNG thereafter (REF-OPENBSD-GETENTROPY, REF-OPENBSD-ARC4RANDOM).
- **Timer precision clamping** in browsers: coarse timers as hygiene against some attacks/fingerprinting, but not a full mitigation (REF-CHROME-HR-TIMERS, REF-FANTASTIC-TIMERS).

## Design summary
Introduce an optional decision:
- **D-NONDET**: time + entropy are accessed only via explicit **Clock** and **Entropy** capabilities.

These capabilities are normally issued by user-space portals (or a host shim in a microVM profile):
- `portal.clock`: issues clock handles/leases (coarse by default)
- `portal.entropy`: issues entropy handles/leases (seed-by-default)

The kernel provides **minimal primitives** for:
- stable, monotonic counters used internally for safety checks (e.g., anti-rollback in boot)
- capability objects and IPC routing

…but does *not* provide ambient “time syscalls” to arbitrary domains under D-NONDET profiles.

### Clock capabilities
Clock handles are typed by **kind**:
- `monotonic_coarse` (default): low-resolution elapsed time
- `monotonic_fine` (explicit grant): higher-resolution elapsed time
- `realtime` (optional): wall clock (may jump; used for UX/log display)

Note: `monotonic_coarse` maps cleanly to existing “coarse clock” practice (e.g., `CLOCK_MONOTONIC_COARSE` in a VDSO) where millisecond granularity is acceptable (REF-LINUX-COARSE-CLOCKS).

A clock handle is described by **CH-CLOCK v0** (`docs/30-architecture/clock-descriptor-schema-v0.md`).

Policy stance (hygiene, not a side-channel claim):
- most components get only `monotonic_coarse` by default
- `monotonic_fine` is treated like “microphone access for the CPU”: it is an explicit authority

### Entropy capabilities
Entropy handles are typed by **quality** and **intended use**:
- `seed`: bounded high-quality bytes for seeding a local CSPRNG (default)
- `stream`: longer-lived stream (rare; explicit)
- `deterministic`: test/replay provider (never for crypto)

An entropy handle is described by **CH-ENTROPY v0** (`docs/30-architecture/entropy-descriptor-schema-v0.md`).

Default stance (aligned with OpenBSD):
- the privileged entropy provider caps reads to small buffers (e.g., 256 bytes/call) suitable for seeding (REF-OPENBSD-GETENTROPY)
- components build a per-domain CSPRNG after seeding

### Integration with D-RR
If D-RR is enabled, time and entropy are part of the pinned boundary:
- replay mode stubs `Clock` reads from `time_tick` events in CH-RR
- replay mode stubs `Entropy` reads from `entropy` events in CH-RR
- any other time/entropy source is a divergence (I-RR-2)

This keeps the kernel replay-agnostic while making replay feasible.

### Integration with D-WASM
D-WASM already recommends `clock` and `rng` imports as explicit handles.
D-NONDET defines what those handles *are*, and how they bind to replay/testing.

## Invariants (additions)
- **I-NONDET-1 (No ambient nondeterminism, optional)**: if D-NONDET is enabled, domains obtain time/entropy only via explicit Clock/Entropy handles; no ambient global clock/RNG APIs exist for those domains.
- **I-NONDET-2 (Resolution is authority, optional)**: high-resolution time sources (fine clocks) are issued only by explicit authorization; coarse clocks cannot be upgraded by derivation.
- **I-NONDET-3 (Entropy quality is explicit, optional)**: entropy handles declare quality; deterministic/test entropy cannot satisfy any cryptographic-randomness precondition.
- **I-NONDET-4 (Replay binding, optional)**: for D-RR replay mode, Clock/Entropy reads are served only from the declared CH-RR event stream kinds for the profile; mismatches diverge.

## Proof obligations (additions)
- **PO-NONDET-NOAMBIENT**: under D-NONDET profiles, there is no ambient syscall/import path that yields time/entropy without an explicit handle.
- **PO-CLOCK-VALIDATE**: CH-CLOCK validation is deterministic and enforces closed enums/bounds; “fine clock requires explicit grant” policy is enforceable.
- **PO-ENTROPY-VALIDATE**: CH-ENTROPY validation is deterministic and enforces bounds/quality labeling; deterministic-vs-crypto separation.
- **PO-NONDET-RR**: replay mode correctly routes Clock/Entropy reads through CH-RR events (or rejects), preserving I-RR-2.

## Abuse case tie-in
- **AC-052**: nondeterminism confusion/bypass — security-sensitive code accidentally uses deterministic entropy or obtains a fine clock via an ambient bypass.

## Evidence plan (tight)
Phase 0/1:
- “Ambient probes” tests: attempts to read time/entropy without handles fail deterministically.
- Wasm host harness: a component with only `clock=monotonic_coarse` and `rng=seed`.
- Replay harness: show identical results for a small action slice where time/entropy are consulted.

Phase 2:
- Fuzz/negative tests for CH-CLOCK/CH-ENTROPY decoders and policy validators.
- Leak tests: ensure fine-clock handles do not appear in default cap graphs for untrusted domains.

## Notes / open questions
- Jittered clocks as hygiene: likely a policy layer decision; avoid baking jitter into contracts unless justified.
- Wall-clock authority and authenticated sync: see RFC-0090 (D-TIMEPROOF) for a user-space time portal posture and monotonic “secure wall time” rules.

## Archive impact
- Adds CH-CLOCK v0 and CH-ENTROPY v0 schemas.
- Adds D-NONDET to the decision map.
- Adds invariants/POs and an abuse case for nondeterminism confusion.
- Threads the seam into D-WASM and D-RR where they already require “no ambient time/entropy”.
