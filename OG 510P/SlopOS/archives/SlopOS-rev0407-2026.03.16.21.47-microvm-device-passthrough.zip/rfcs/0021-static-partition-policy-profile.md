# RFC-0021: Static partition policy profile (D-PART)

Status: Draft

Goal: provide a **high-assurance early slice** where isolation comes primarily from **static resource assignment** described by a small, canonical policy artifact, rather than from complex dynamic privilege logic.

This is an optional profile that can serve both:
- a *separation-kernel-first* architecture branch, and
- a *hypervisor-first* deliverable that minimizes device emulation and policy.

Refs: REF-MUEN-SYSTEM-SPEC, REF-MUEN-KERNEL-SPEC, REF-JAILHOUSE.

## Why this exists
Static partitioning is an attractive “first plateau” for assurance because:
- the privileged core can be closer to an installer/validator for a fixed policy
- many hazards become **configuration-time obligations** (overlaps, device assignment, DMA windows)
- it yields a concrete, testable microVM/hypervisor-first profile with a tight exit surface

Muen’s lesson is to treat the system as a **policy-described composition** where resources are fixed at integration time and the policy can be analyzed before execution. Jailhouse is a modern “partitioning hypervisor” example that emphasizes *simplicity over features* and avoids emulation by splitting existing hardware into isolated “cells.”

## Design stance (minimal)
### 1) Partition policy is explicit data
Introduce **CH-PART v0**: a canonical partition policy artifact.

Properties:
- static partitions (“cells”) with explicit CPU/memory/device/IRQ assignment
- explicit, bounded cross-partition communication channels (or none)
- no dynamic device discovery within the privileged core (discovery is separate: CH-HWFACT + user-space SKB if needed)

### 2) Kernel/hypervisor role
In this profile the privileged core:
- validates CH-PART deterministically (I-ENC-1)
- installs partitioning controls (MMU + IOMMU per D-DMA posture)
- exposes a minimal “partition lifecycle” KABI surface (start/stop/query)

Policy *authoring* remains outside the privileged core.

### 3) Interaction with other seams
- **D-MICROVM**: D-PART is a natural “no emulation” microVM profile.
- **D-METER / D-TCAP**: partitions can be charged/budgeted; avoid embedding sched policy.
- **D-SKB**: optional helper to synthesize CH-PART from CH-HWFACT in user space; kernel still validates.

## Candidate invariants / obligations (optional)
- **I-PART-1 (No cross-partition overlap, optional)**: CPU sets, physical memory ranges, and device resources assigned to different partitions do not overlap unless explicitly represented as a shared object/channel with explicit participants and rights.
- **I-PART-2 (Partition communication is declared, optional)**: any cross-partition communication occurs only via declared channels and preserves I-SHARE-1/I-MAP-1.

Associated proof obligations:
- **PO-PART-VALIDATE**: CH-PART validation is deterministic; rejects overlaps/unknown variants; enforces closed sets.
- **PO-PART-NOOVERLAP**: runtime enforcement matches the validated policy (no “silent” extra mappings/resources).
- **PO-PART-DMA**: device DMA windows cannot target other partitions or privileged memory under the chosen D-DMA posture.

## Abuse cases
See AC-024..AC-026.

## Evidence plan (tight)
Phase 1 (E1):
- write a policy validator for CH-PART (overlap checks, closed enums, bounds)
- QEMU demo with 2 partitions + one shared channel (optional) + negative tests

Phase 2 (E2):
- bounded model check of a simplified “resource assignment + enforcement” model (overlap + DMA constraints)

## Archive impact
- Adds D-PART entry in the decision map.
- Adds CH-PART v0 schema + schema registry row.
- Adds PO/AC/EVID hooks for partition-policy validation and DMA containment.
