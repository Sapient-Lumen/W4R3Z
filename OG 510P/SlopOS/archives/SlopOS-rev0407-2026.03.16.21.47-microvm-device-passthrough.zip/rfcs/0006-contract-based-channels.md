# RFC-0006: Contract-based channels (protocol state machines) (D-CONTRACT)

Status: Draft

Goal: borrow the most *verification-friendly* idea from Singularity: treat each channel/endpoint pair as governed by an explicit **protocol contract** (a finite-state machine over message kinds), so protocol reasoning becomes *bounded* and amenable to model checking.

Non-goals:
- Not moving a large runtime/typechecker into the privileged core.
- Not claiming “all protocols are safe” or “no DoS.” This is about **reducing ambiguity** and **preventing protocol confusion**.

## Problem
Our microkernel/hypervisor posture prefers explicit, closed surfaces. But even with CH-* schemas, IPC protocols can still drift into:
- implicit “out-of-band” messages
- hand-rolled state machines
- confused-deputy bugs caused by protocol desynchronization

We want a low-cost seam that improves correctness *without* growing the kernel.

## Candidate decision: D-CONTRACT (protocol contracts)
Options (stageable):
1) **Library-enforced contracts** (default candidate): generated wrappers enforce the state machine for each endpoint; violations fail closed in the caller.
2) **Optional runtime monitor** (still user-space): a small monitor checks transitions for selected critical interfaces.
3) **Kernel-enforced contracts** (avoid unless proven necessary): kernel tracks contract state for endpoints.

Default posture: start with (1), maybe add (2) for critical paths, keep (3) as a non-default escape hatch.

## Minimal seam
- Each privileged interface (IF-*) that uses message passing has an associated **contract spec** (finite state machine) stored as a pinned artifact (CH-CONTRACT v0) and referenced from the interface registry.
- Messages remain CH-* schemas (D-ENC); the contract is a predicate over *message kinds + endpoint state* (see `docs/30-architecture/channel-contract-schema-v0.md`).
- If we ever enable copyless/ownership-transfer buffers (D-IOBUF), the contract can also specify when ownership moves.

## Invariants
- **I-CONTRACT-1 (Protocol obedience, optional)**: for endpoints governed by a contract, message exchanges follow the declared state machine; illegal transitions are rejected deterministically.
- **I-CONTRACT-2 (Ownership transfer is explicit, optional)**: if a message transfers ownership of an endpoint or buffer object, that transfer is explicit in the contract and cannot be duplicated.

## Proof obligations (scoped)
- **PO-CONTRACT-OBEY**: generated wrappers or monitors are sound w.r.t. the contract semantics (no illegal transition is accepted).
- **PO-CONTRACT-MCHECK**: bounded model checks cover key contracts (deadlock-free, no unexpected terminal states) within declared bounds.

## Abuse cases to pressure-test
- **AC-016**: protocol desynchronization / message confusion yields unintended authority or state corruption.

## Evidence plan (tight)
Phase 0/1:
- Pick 1–2 critical protocols (e.g., pager fault IPC if D-PAGER is enabled; or a microVM control channel).
- Generate wrappers + property tests: “illegal transition rejected” + “decode totality.”

Phase 2:
- Model-check the contract state machines (small automata): reachability, dead ends, and forbidden transitions.
- If ownership transfer exists, check linearity properties (“no double-free / no dup ownership”).

Phase 3:
- Consider mechanizing the contract DSL semantics if we decide to *claim* contract correctness as part of an assurance slice.

## References
- Singularity channel contracts and message-based comm: REF-SING-CHANCONTRACTS, REF-SING-MSGCOMM, REF-SING-OVERVIEW.
- Typed actor protocol work (message protocols as types): REF-NVLANG-BEAM.
- Session types literature is a conceptual cousin, but only relevant if we choose to formalize contracts beyond simple FSMs (optional; keep out of core).
