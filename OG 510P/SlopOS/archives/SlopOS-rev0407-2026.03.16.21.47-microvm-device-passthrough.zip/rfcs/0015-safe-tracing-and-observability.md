# RFC-0015: Safe tracing and tracepoints (D-TRACE)

Status: Draft

Goal: add **high-leverage observability** (debug/diagnostic tracing) without bloating the privileged core or turning “debug features” into an ambient exfiltration channel.

This RFC treats tracing as an *adjunct* to IF-OBS, aligned with our archive behaviors:
- constrain claims (side-channel posture remains D-SIDECH; timing is still a non-claim by default)
- minimize TCB (no in-kernel scripting engines)
- prototype-to-evidence (bench + fuzz + deterministic logs)

## Problem
We want:
- visibility into boundary events (VM exits, IPC, scheduler decisions, policy rejects)
- post-mortem and “pressure-test abusecases” workflows
- to keep trace exports explicit, redactable, and capability-mediated

But:
- tracing can become an implicit privileged surface
- dynamic instrumentation can be an integrity risk if it injects code or changes control flow
- “always on” logging can become a covert channel or a performance foot-gun

## Design stance (minimal)
### 1) Tracepoints are **declared**, not injected
We adopt a DTrace-like lesson (“safe dynamic instrumentation”), but in a smaller shape:
- a **closed** set of tracepoint IDs is compiled into the privileged core
- each tracepoint has a fixed event shape (typed args; bounded)
- enabling tracing selects subsets of tracepoint IDs; no arbitrary code runs in-kernel

### 1b) Optional: bounded predicates/filters (still safe)
DTrace’s lesson is not “run a general scripting engine in the kernel” — it’s “**make the dynamic part safe by design**”. If we need filtering (to reduce overhead/data volume), prefer a tiny, non-Turing-complete predicate VM/profile:

- no loops; bounded instruction count;
- bounded stack/heap; fail-closed on overflow;
- read-only access to event args + a small set of helpers (time, cpu id, etc.) as explicitly modeled inputs;
- output is a boolean (keep/drop) and optionally a bounded projection of fields.

This keeps the privileged surface small while capturing the main operational win: *turn on a probe, filter it safely, and don’t crash the box*.

Refs: REF-DTRACE-SAFETY.

Concrete specs: **RFC-0073** defines **CH-TPRED v0** (bounded boolean predicates over CH-TRACE fields) and threads it into trace configuration as an optional prefiltering seam (**D-TPRED**). **RFC-0077** defines **CH-TPROBE v0** (tracepoint descriptor manifest) as the field schema table for tools/predicates (**D-TPROBE**).

Contrast: eBPF shows the *ecosystem* value of programmable hooks close to the source, but it also highlights why we should be cautious about importing a large verifier/VM into the privileged core. If we need richer programmability than bounded predicates, prefer running it in an **isolated tracing domain** (user space) that consumes CH-TRACE streams and emits derived summaries, keeping the core’s tracing surface small. Refs: REF-EBPF-INTRO, REF-EBPF-VERIFIER-HARNESS.


Refs: REF-DTRACE.

### 2) Tracing is capability-mediated and redactable
- enabling a trace stream requires explicit authority (a trace capability granted by composition policy)
- export uses existing IF-OBS pathways and redaction policy (I-OBS-1)
- by default, trace payloads must avoid secrets (no raw keys, no raw capability-bearing strings; no raw pointers)

### 3) Tracing is bounded and fail-closed
- trace buffers are bounded (ring buffers with explicit drop/overflow policy)
- tracing must not allocate unboundedly or “panic on overflow”
- if the trace subsystem is misconfigured, the safe behavior is **no trace**, not degraded isolation

## Candidate wire contract
Introduce **CH-TRACE v0** as a small, canonical event record schema. CH-OBS may optionally include a bounded list of CH-TRACE entries or a digest/pointer to a trace chunk.
If D-TPROBE is enabled, pin a **CH-TPROBE v0** manifest digest for the active trace stream(s) so tools/predicates can interpret `probe` + `args` with a stable field mapping (names/types/redaction). See RFC-0077.

Correlation posture (recommended): do not expand CH-TRACE v0 for “spans,” but standardize correlation keys via CH-TPROBE `sem` tags (`corr_id`, `trace_id`, `span_id`, `parent_span_id`) so traces can be joined with inspect snapshots and receipts. This is inspired by ETW activity IDs and aligns with OpenTelemetry/W3C Trace Context conventions.


Maps to: I-ENC-1; PO-ENC-DECODE; PO-OBS-REDACT.

## Invariants (additions)
- **I-TRACE-1 (Trace is observational, optional)**: for the chosen D-TRACE profile, emitting trace events cannot create authority and cannot change abstract-machine state transitions except by producing observation outputs; any trace buffering behavior is bounded and does not widen authority.

This is intentionally weaker than “no timing perturbation.” Timing effects remain a D-SIDECH topic.

## Proof obligations (add)
- **PO-TRACE-NOSTATE**: trace emission paths are total and cannot mutate privileged state except bounded trace buffers; trace cannot influence dispatch decisions; overflow behavior is deterministic and non-fatal.
- **PO-TRACE-OFF**: when D-TRACE is disabled, tracepoints have no effect on abstract-machine state (no buffer writes, no capability checks).

## Abuse cases (coverage)
- trace used as an exfiltration channel (covered by AC-005/AC-006 + I-OBS-1)
- trace amplification via “enable everything” (covered by D-XS + a bounded allowlist per profile)

## Evidence plan (tight)
Phase 0/1:
- microbench: tracepoint hot-path overhead disabled vs enabled
- fuzz: trace event encoder/decoder for CH-TRACE v0
- harness tests for bounded predicate programs (reject unsafe/oversize programs deterministically)
- negative tests: ensure secrets/capability strings are rejected/redacted in exports

Phase 2:
- bounded model check on a minimal “trace buffer + enable mask + export” model to show PO-TRACE-NOSTATE properties under declared bounds

## Archive impact
- Adds RFC-0015 (this file).
- Adds CH-TRACE v0 schema + schema registry row.
- Extends invariants/proof obligations registries with I-TRACE-1, PO-TRACE-NOSTATE, PO-TRACE-OFF.
- Adds a small D-TRACE entry in the decision map.
