# RFC-0048: Failpoints and fault-injection profiles (D-FAILPOINT)

Status: Draft  
Last updated: 2026-02-24

Goal: bake in a **first-class, deterministic fault-injection seam** so we can continuously test “unhappy paths” (allocation failures, message drops, retries, timeouts, partial availability) without turning the privileged core into a chaos engine.

This is an ecosystem multiplier: if failure paths are easy to exercise, libraries, drivers, and services become robust earlier—and verification/DRT becomes more meaningful because the system is forced to handle “expected failures” explicitly.

Motivation refs: Linux fault-injection framework; Jepsen’s “nemesis” fault model; DTrace’s explicit “destructive actions” opt-in posture. Refs: REF-LINUX-FAULTINJECT, REF-JEPSEN, REF-DTRACE-SAFETY.

Non-goals:
- A generic in-kernel scripting system.
- Probabilistic chaos in production by default.
- Injecting undefined behavior (memory corruption) as a first-class mechanism.

## Problem
Most system failures that matter in practice are not the “happy path” bugs:
- allocators fail and error handling is untested,
- IPC is delayed/dropped/reordered across real deployments,
- restarts and partial availability are normal,
- drivers time out, return partial data, or see transient IRQ storms.

Without a cheap, repeatable seam for injecting these conditions, we either:
1) ship brittle software, or
2) add ad-hoc, unreviewed test hooks everywhere.

## Proposal

### 1) Decision node: D-FAILPOINT
Adopt **failpoints** as a profile-scoped mechanism:
- **Dev/test profiles:** failpoints can be enabled from a pinned artifact.
- **Release profiles:** failpoints are disabled/compiled out (or must be absent from CH-BOOT `artifacts`).

The mechanism is intentionally “dumb but useful”: a stable failpoint ID, deterministic triggers, and a bounded effect set.

### 2) Contract artifact: CH-FAIL v0
Introduce a pinned failpoint profile schema (**CH-FAIL v0**) describing:
- which failpoints exist (by stable ID),
- their trigger rules (deterministic counters / optional seeded PRNG),
- their effects (return error, delay, drop, etc.), and
- strict bounds (max rules, max delay, max drop rate).

CH-FAIL is not an ambient config file. It is an explicit, digest-pinned artifact. In dev/test boots it may appear in CH-BOOT `artifacts` (role `failpoints_profile`) and be surfaced to components that support failpoints.

### 3) Where failpoints live (keep the privileged core small)
Preferred layering:
1) **User space first:** inject faults at component boundaries (RPC wrappers, driver-domain boundaries, storage/network servers). This covers a large fraction of real-world failure modes.
2) **Privileged core second (minimal):** allow failpoints only at a few well-chosen seams where user space can’t reach:
   - allocation failure seams
   - selected IPC send/receive seams
   - optional scheduler/timeout seams

This keeps the privileged core from becoming “the chaos runtime.”

### 4) Determinism + replay integration
Two supported postures:
- **Deterministic triggers only** (default): triggers are functions of (failpoint ID, local counters, pinned parameters).
- **Seeded probability** (optional): if probabilistic triggers are needed, they must be driven by a pinned `seed` and an explicitly declared PRNG; for D-RR profiles, either (a) treat the PRNG stream as replay input, or (b) treat each “fired” decision as a CH-RR event.

## Candidate invariants / proof obligations
- **I-FAIL-1 (Failpoints do not create authority, optional):** failpoint evaluation can only *restrict* behavior (fail, delay, drop) and cannot mint capabilities, widen rights, or enable otherwise-forbidden effects.
- **I-FAIL-2 (Failpoint evaluation is deterministic, optional):** given CH-FAIL and an abstract event stream (including counters and optional seed), whether a failpoint fires and which effect applies is deterministic.

- **PO-FAIL-VALIDATE:** CH-FAIL decoding/validation is canonical, total, and enforces strict bounds; unknown variants reject deterministically.
- **PO-FAIL-NOAMP:** failpoint effects cannot widen authority; any failpoint hook is observational or failure-inducing only.
- **PO-FAIL-DETERMINISM:** the failpoint evaluator is deterministic under the declared trigger semantics; dev/test runs are reproducible given the profile.

## Evidence plan
E1:
- a tiny CH-FAIL validator tool + golden tests (accept/reject, bounds, determinism).
- a toy component that supports failpoints at 2–3 seams (e.g., allocation + RPC send) with negative tests.

E2:
- integrate failpoints into a D-DRT harness for one protocol slice: demonstrate that injected failures preserve protocol invariants (no undefined states).

E3:
- optional mechanization of the failpoint evaluator (tiny) + proof that it is deterministic and cannot mint authority.

## Alternatives
1) **No built-in seam; rely on ad-hoc tests.**
   - Con: failure paths remain untested; hooks proliferate and become unreviewable.

2) **Full chaos framework in kernel.**
   - Con: large TCB, hard to audit, likely to outgrow the microkernel scope.

3) **Only probabilistic injection.**
   - Con: flaky tests; poor replay/debug; undermines evidence.

## Open questions
- Which failpoint IDs should be standardized for Phase 1 (alloc, IPC, timers) vs left to user-space services?
- What is the minimal “drop/delay” semantics that stays compatible with D-RR (i.e., how much is modeled as replay input)?
- Should “destructive” effects (forced panic/halt) require an explicit opt-in flag analogous to DTrace’s destructive-actions gate?
