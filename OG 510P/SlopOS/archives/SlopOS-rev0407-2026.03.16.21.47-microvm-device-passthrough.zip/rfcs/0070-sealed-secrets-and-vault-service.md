# RFC-0070: Sealed secrets + vault service (D-VAULT)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-VAULT, D-CRYPTOSVC, D-PERSIST, D-CC (optional), D-NONDET, D-EXPLAIN (optional)

## Summary
Standardize a **secret/credential vault** as a first-class ecosystem seam:

- secrets are **objects** managed by a dedicated provider (often the crypto provider / auth agent),
- clients receive **capability handles** to request *bounded operations* (read, wrap, rotate, attest), not raw storage access,
- every secret has an explicit, reviewable **policy descriptor** (**CH-SECRETPOL v0**),
- persistence uses **durable references** (**CH-SECRETREF v0**) so CapStore stores *references*, not secret bytes,
- high-risk releases can be gated by existing evidence seams: **CH-AUTHZ + CH-VOL + CH-CAPDIFF** (optional), plus **attestation binding** in D-CC profiles.

This is “keys as capabilities” (RFC-0067) extended to *credentials and opaque secrets* so apps stop inventing bespoke keychains, config-file vaults, and ad hoc “secret export” APIs.

Refs: REF-PLAN9-FACTOTUM, REF-PLAN9-SECSTORE, REF-APPLE-KEYCHAIN, REF-ANDROID-KEYSTORE, REF-SECRET-SERVICE-SPEC, REF-TPM2-PART1.

Pinned v0 posture follow-up: keep D-VAULT **ref-bound, provider-owned, and non-inventory** in Phase 1.
Portable authority is CH-SECRETPOL/CH-SECRETREF plus the closed op set; Phase 1 declines a Secret Service-style
collection/item/session/search object model and treats remote recovery/federation as an explicit profile annex rather than default seam behavior.

## Motivation
Many systems get “key handles” right (ssh-agent, TPM/TEE APIs) but leave **everything else** (API tokens, session secrets, recovery material) as raw bytes scattered across:
- config files,
- dot-directories,
- app-private databases,
- or one-off “vault” daemons with unpinned interfaces.

Greenfield advantage: if we define a small vault seam now, we can:
- keep secret-handling interfaces **tiny and auditable**,
- bind secret release to **consent + receipts** where appropriate (D-VOLITION/D-EXPLAIN),
- make secret persistence explicit and rollback-aware (D-PERSIST),
- and let “hardware-backed” become a *deployment profile*, not an app rewrite (D-CC / D-ATTEST / TPM).

## Design stance
- **No ambient secret access.** Reading a secret is an explicit capability-mediated operation.
- **No silent export paths.** Policies can require “op-only” semantics (e.g., “use to sign” but never reveal bytes), or allow reveal with explicit evidence.
- **Everything reviewable as data.** Policy is a pinned schema (CH-SECRETPOL). Durable references are a pinned schema (CH-SECRETREF).

The vault remains a **user-space service**. The privileged core does not gain new policy logic.

## Model (v0)
### Secret object
A secret is an object inside the provider:
- stored encrypted-at-rest using provider-managed keys (often D-CRYPTOSVC),
- optionally backed by hardware sealing (TPM/TEE) in deployment profiles,
- referenced externally via a stable secret identifier (sid).

### Operations (closed set; enforced by provider)
- `read` — return secret bytes (only if policy permits, and evidence requirements satisfied)
- `wrap` — return a wrapped/encrypted blob for transfer (no plaintext reveal to caller)
- `rotate` — replace underlying secret value (bounded by policy; may require confirmation)
- `delete` — delete/revoke the secret object (bounded by policy)

(Providers may support additional domain-specific operations *internally*, but the cross-component contract stays small.)

The portable Phase 1 contract is intentionally **not** a collection/item/session/search broker.
Inventory, labels, or attribute search may exist inside a provider for UX, but they are not portable/app-facing core-seam semantics without a future RFC.

### Evidence / gating (re-use existing seams)
CH-SECRETPOL can require one or more of:
- **authorization**: a valid CH-AUTHZ bound to the action digest,
- **volition** (optional): a CH-VOL token from the trusted UI path (D-VOLITION),
- **explainability binding** (optional): a CH-CAPDIFF digest bound into CH-VOL/CH-RECEIPT (D-EXPLAIN),
- **attestation** (optional): a D-CC profile gate where secret release depends on evidence bound to our `boot_digest = digest(CH-BOOT)`.

This keeps “policy” in user space and uses already-specified evidence objects.

### Persistence (D-PERSIST integration)
- CapStore stores **CH-SECRETREF** objects, not secret bytes.
- A CH-SECRETREF points to the provider and pins the policy digest.
- Rotations update the provider-side value; the reference remains stable unless policy changes.

### Remote recovery (optional; Plan 9 style)
For user-facing profiles, allow a “recovery vault” mode inspired by Plan 9 secstore:
- the provider can fetch an encrypted secret bundle after strong user authentication,
- the bundle decrypts only into the provider (not the requesting app),
- the resulting local secret objects inherit pinned policies.

This is explicitly a profile choice; do not assume network recovery exists, is always-on, or silently widens normal provider reachability.

## Schemas
- **CH-SECRETPOL v0** — secret usage policy descriptor: [secret-policy-schema-v0.md](../docs/30-architecture/secret-policy-schema-v0.md)
- **CH-SECRETREF v0** — durable secret reference (no secret bytes): [secretref-schema-v0.md](../docs/30-architecture/secretref-schema-v0.md)

## Threats & abuse cases
Primary new abuse case:
- **AC-058 (Secret release confused deputy):** a compromised app tries to induce the vault to reveal/export a secret using the wrong context, wrong policy digest, or a replayed consent token.

Mitigations:
- policy-bound enforcement (I-VAULT-1; PO-SECRETPOL-ENF)
- purpose/context tags (CH-SECRETPOL) with fail-closed checking (I-VAULT-2)
- bind approvals to action+policy digests (D-VOLITION/D-EXPLAIN), not requester strings (I-VOLITION-1; I-EXPLAIN-4)
- optional attestation binding (D-CC) for “only release to verified boot image” secrets

## Evidence plan
- E0: minimal provider prototype: `vault.put/read/wrap/rotate` with CH-SECRETPOL parsing + fail-closed validation.
- E1: fuzz + negative tests: mismatched policy digest, invalid contexts, replayed authz, missing evidence → deterministic reject.
- E2: DRT against a tiny “policy reference model” for CH-SECRETPOL checks (D-DRT).

## Open questions
- Should `read` be off-by-default for user secrets, with `wrap` preferred?
- How do we bind a requesting component identity (image_digest / cid) to a vault request without expanding the privileged core? (possible answer: supervisor-mediated RPC endpoints + declared routes in CH-COMP).
- Do we want a “lease-by-default” pattern for secret handles (D-LEASE), so credentials are naturally time-bounded?

