# RFC-0013: Deterministic record/replay boundary (D-RR)

Status: Draft

Goal: define a **small, explicit** seam for deterministic replay that supports:
- evidence/forensics (reproduce “what privileged code did”)
- faster debugging (replay divergences are themselves evidence)
- early verification leverage (collapse nondeterminism where feasible)

## Problem
We want “well-formed state evolution” and “replayable transcripts” without pretending we can fully determinize the world.

If replay is an afterthought, we get:
- hidden sources of nondeterminism (time, interrupts, device reads)
- logs that are not sufficient to reproduce behavior
- unverifiable hand-waving about what the system “should have done”

## Non-goals
- Not claiming *full* deterministic replay by default.
- Not logging everything (must not explode archive size).
- Not requiring custom hardware.


## Prior art (why this is worth it)
- **rr**: practical deployable user-space record/replay; demonstrates how pinning nondeterministic inputs changes debugging economics.
- **ReVirt**: VM logging + replay for post-compromise forensics; shows that replay is an evidence tool, not just a debugger.
- **PANDA**: whole-system record/replay + dynamic analyses; highlights why “shareable replays” matter for research/IR workflows.

Refs: REF-RR-ATC17, REF-RR-PROJECT, REF-REVERT-OSDI02, REF-PANDA-RE, REF-PANDA-GITHUB.

## Replay bundles for sharing + evidence (CH-RRBUNDLE)
To make replay useful in practice, we need a **portable artifact** that can be handed to another machine/person/tool.
CH-RRBUNDLE v0 is a small manifest that:
- lists the bundle payload files (CH-RR, CH-LOG, optional CH-KABI / CH-CKPT / rr_index),
- digest-binds them (sha256),
- and optionally annotates encryption and redaction.

This enables:
- “attach a replay” bug reports (like an rr trace, but schema-governed),
- incident-response evidence handoff (bundle digests can be anchored via D-TLOG),
- offline verification that a replay transcript is untampered.

Schema: CH-RRBUNDLE v0 (`docs/30-architecture/replay-bundle-schema-v0.md`).
New proof obligations: PO-RR-BUNDLE, PO-RR-ACCESS.

## Candidate stance: replay as a pinned nondeterminism boundary
We introduce a small CH-* schema that represents **only the nondeterministic inputs** required to replay a chosen scope.

Scopes (D-RR, by increasing ambition):
1) **kabi-only (quiescent)**: replay CH-KABI actions + CH-LOG results; interrupts are disabled/treated as divergences; CH-RR carries only minimal time/entropy.
2) **kabi-only (interrupt-aware)**: still replay CH-KABI actions + CH-LOG results, but interrupt/exception delivery that affects privileged transitions must be represented explicitly as CH-RR events.
3) **guest+devices**: replay a microVM profile; record declared device inputs + interrupts.
4) **full system**: ambitious; deferred unless a strong value case appears.

### Microkernel-friendly replay note
A microkernel makes a **message transcript** a natural unit of replay: many cross-component effects already occur via IPC/RPC boundaries. A practical progression is:
- start with kabi-only replay for the privileged core semantics (what the kernel *accepted* and returned)
- then extend the recorded boundary for selected domains by capturing delivery ordering and message payload digests at the IPC boundary (still as an *explicit profile*, not a universal claim)

This mirrors the lesson from rr: the hard part is correctly defining and capturing the **nondeterminism boundary**, not “logging everything.” Refs: REF-RR-ATC17.


The core point: the scope is explicit, and any input outside it is a *replay divergence* (AC-011).

## Mechanism seam
- CH-LOG remains the canonical transcript of accepted privileged actions and results.
- **CH-RR v0** represents the associated nondeterministic input stream (see `docs/30-architecture/replay-stream-schema-v0.md`).

The privileged core should not “know replay”; it should:
- expose a stable action boundary (CH-KABI)
- avoid ambient time/entropy in that boundary (or route it through CH-RR)

## Invariants (additions)
- **I-RR-1** already exists.
- **I-RR-2 (Pinned nondeterminism boundary, optional)**
  - for a D-RR profile, all nondeterministic inputs that can affect abstract-machine results are represented either as:
    - an explicit CH-KABI action field (canonical), or
    - an explicit CH-RR event
  - any other source is treated as a divergence (fail-closed in “replay mode”).

## Proof obligations (additions)
- **PO-RR-DETERMINISM** already exists.
- **PO-RR-BOUNDARY**
  - for the chosen D-RR scope, prove/check that the abstract machine reads nondeterminism *only* via the declared CH-RR event kinds (closed set), and that “replay mode” disables or stubs all other sources.

## Abuse cases (ties)
- AC-011 captures replay divergence as an abuse case.

## Evidence plan (tight)
Phase 0/1:
- implement a replay harness for **kabi-only (quiescent)**:
  - feed CH-KABI + CH-RR into an abstract-machine interpreter
  - assert CH-LOG output matches byte-for-byte (canonical)
- property tests: “same inputs => same outputs” for a chosen subset of actions

Phase 2:
- bounded model check of a tiny action subset + RR events
  - start with `time_tick`/`entropy`
  - add `irq`/`fault` for the interrupt-aware profile (explicitly modeling delivery ordering)


## Tooling targets (explicitly user-space)
The privileged core should not implement debuggers. But we *can* make the ecosystem tractable by standardizing the artifacts that powerful tools need.

Targets this boundary enables:
- **Reverse execution**: classic time-travel debugging by replaying forward from checkpoints (rr-style) instead of mutating state backwards.
- **"Search through time"**: automated bisection over a replay to find the earliest point an invariant fails (FReD-style).
- **Queryable traces**: higher-level tools can index CH-RR/CH-LOG/CH-TRACE and answer questions like "where did this value come from?" (omniscient UX), without expanding privileged TCB.

Design implications (salient):
- Make bundle formats stable and boring (CH-RRBUNDLE + canonical encoding), because tooling ecosystems outlive kernels.
- Prefer **optional checkpoint+index payloads** (D-CHKPT) to keep core replay streams small while enabling fast reverse queries.
- Keep nondeterminism explicit and capability-mediated (D-NONDET), so "recorded inputs" are reviewable and exportable under policy.
## Practical note
The quiescent profile is primarily a *proof/debugging* aid for privileged action semantics under controlled conditions. Forensic usefulness in the presence of races/interrupt storms requires the interrupt-aware (or broader) scopes and should be treated as an explicit, evidence-bearing expansion.

## Notes from other systems
- VM replay work emphasizes that practicality comes from **good abstractions for nondeterminism**, not from logging “everything” (REF-VM-REPLAY-ABSTRACTIONS).

- rr demonstrates that record/replay can be operationally useful when recording overhead is low and replay integrates with existing debuggers (reverse execution). Treat this as a tooling target layered over our pinned CH-KABI/CH-LOG/CH-RR seam, not as a kernel requirement. Refs: REF-RR-ATC17.
- Record/replay surveys emphasize how many bugs are really “nondeterminism boundary” bugs (REF-RR-SURVEY-CACM25).

## Archive impact
- Adds/updates CH-RR v0 schema.
- Clarifies that kabi-only has a quiescent and interrupt-aware profile.


## Privacy and access control (must be explicit)
Replay artifacts can capture secrets and personal data. Stance:
- **Record minimally by default** (kabi-only profiles first).
- **Export is mediated** (portal path) and can require D-EXPLAIN receipts describing included payload kinds + size.
- **At-rest protection**: bundles MAY be encrypted; the manifest stays digest-bound to ciphertext payloads.
- **Retention is policy-controlled**: \1 See RFC-0109 (D-FLIGHTREC).

Threats: exfiltration of recordings; coercing high-scope replay to capture data.
Mitigations: I-RR-3 + PO-RR-ACCESS, plus explicit abuse cases (AC-045).
