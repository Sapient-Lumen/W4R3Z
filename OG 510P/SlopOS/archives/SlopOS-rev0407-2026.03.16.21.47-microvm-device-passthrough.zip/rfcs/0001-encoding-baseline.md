# RFC-0001: Canonical encoding baseline for CH-* (D-ENC / D-UPD-SIGN)

## Context
Multiple trust boundaries depend on stable, canonical bytes:
- IF-BOOT verifies policy/config/artifact bindings (C-BOOT-1)
- IF-ACP binds approvals to action digests (I-AUTHZ-1)
- IF-OBS exports redacted, replayable records (I-LOG-1)

Therefore, "wire format" is a correctness/security primitive, not a serialization convenience.

Constraints:
- deterministic decode/encode (I-ENC-1; PO-ENC-DECODE)
- small parsers (TCB pressure)
- stable hashing/signing story

## Options (seed)
### O1: Canonical CBOR + COSE envelopes
- CBOR payloads with canonicalization (REF-CBOR-RFC8949)
- COSE for signing/MAC of the canonical bytes (REF-COSE-RFC9052)

Pros:
- standard, widely-used formats
- avoids bespoke crypto envelope encoding

Cons:
- still needs careful parser selection and canonicalization enforcement

### O2: Custom minimal encoding
Pros:
- smallest possible parser

Cons:
- high design/verification cost; easy to get canonicalization wrong
- harder interoperability and tooling

## Proposed experiments (evidence gates)
- E1: property tests for a chosen CH slice (CH-ACP or CH-KABI):
  - non-canonical encodings reject
  - canonical round-trip stable
- E2: bounded model check of decoder totality for the same slice

If O1 cannot be made to satisfy these quickly with bounded effort, revisit O2.

## Non-decisions
- crypto suite and key management (D-UPD-SIGN)
- full attestation protocol design (outside current scope)

## Affected IDs
- Schemas: CH-BOOT v0, CH-CFG v0, CH-ACP v0, CH-LOG v0, CH-KABI v0
- POs: PO-ENC-DECODE, PO-BOOT-VERIFY, PO-BOOT-BIND, PO-ACT-BIND
- Evidence: EVID-2026-006 (schema set + encoding policy)
