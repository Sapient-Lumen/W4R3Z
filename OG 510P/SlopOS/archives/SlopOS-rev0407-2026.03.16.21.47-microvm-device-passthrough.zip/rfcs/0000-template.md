# RFC-XXXX: <title>

Status: Draft  
Owner: <name or team>  
Updated: YYYY-MM-DD  
Decision node(s): D-...  
Profiles: <which deployment/profile(s) enable this; default posture>

## Summary
One paragraph: what changes.

## Motivation
Why needed now? What becomes possible? What breaks without it?

## Integration seam / privileged impact (keep small)
What is the *minimum* privileged mechanism/interface required? What stays in user space?

## TCB delta / `unsafe` delta (make it explicit)
- New trusted components (if any):
- TCB size notes (why acceptable):
- New or expanded `unsafe` obligations (U-*):
- New implicit dependencies to avoid (e.g., clocks, entropy, naming):

## Design
Precise semantics; interfaces; state model deltas.

## Profile gating + defaults
- Default posture (off/on/deny-by-default):
- If enabled: what is fail-closed vs best-effort?
- Opt-in knobs as *data* (CH-*):

## Registries impacted
Which registries change? (IF-/CH-/C-/I-/PO-/A-/U-/AC-). List concrete IDs to add/update.

## Threat-model impact
New attacker capabilities? New assumptions? New trusted components?

## Abuse cases / pressure tests
Which AC-* scenarios become relevant? Which new ones are needed?

## Assurance/verification impact
Which Claims/Invariants change? What proof obligations appear/disappear?

## Observability / operations impact
What new logs/metrics/traces exist? What redaction policies apply?

## Compatibility + migration
- Wire/schema compatibility story (versioning, adapters):
- Upgrade/downgrade behavior (fail-closed?):
- Interaction with replay/snapshots (D-RR/D-CHKPT):

## Alternatives
Enumerate credible alternatives; why rejected.

## Evidence plan
What will decide? (prototype, benchmark, model check, proof sketch). Define exit criteria.

## Open questions
What is unknown and how will it be resolved?
