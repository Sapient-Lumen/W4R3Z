# D-UPCALL posture v0 (no portable kernel→user scheduling-upcall seam)

Purpose: pin an implementable **Phase 1** meaning for **D-UPCALL** so kernel→user scheduling event vectoring does not quietly become a portable callback ABI, hidden runtime contract, or ambient control plane.
It narrows the decision-map stub and RFC-0049 into one compact posture adjacent to **D-SCHED**, **D-TCAP**, **D-WAITSET**, **D-IOQ**, **D-REQCTX**, and **D-QUIESCE**.

## Posture (v0)

1) **No portable kernel→user scheduling-upcall interface in Phase 1**
   - The portable **D-UPCALL** contract in v0 is **none**.
   - Phase 1 does **not** standardize scheduler-activations callbacks, per-address-space virtual-multiprocessor notifications, timeout-fault delivery as an application-visible scheduling ABI, or a user-mode scheduler entrypoint registered with the kernel.
   - If a kernel/runtime uses local upcalls or notifications internally, that remains implementation-local beneath the native reviewed seams.

2) **Existing explicit seams own the useful event vocabulary already**
   - CPU-time authority, passivity, and donation stay on **D-TCAP** / **D-SCHED**.
   - Scalable waiting stays on **D-WAITSET** / **D-UWAIT**; async completion stays on **D-IOQ**; deadlines/cancellation stay on **D-REQCTX**; cooperative maintenance stays on **D-QUIESCE**.
   - D-UPCALL therefore adds no second generic event vector for budget exhaustion, wakeups, completion delivery, cancellation, or drain coordination.

3) **No portable scheduler callback / entrypoint registration ABI**
   - Phase 1 adds no portable `register_scheduler`, `scheduler_entry`, `upcall_stack`, `activation_context`, or equivalent ABI.
   - There is no portable kernel-owned callback stack, preemption continuation frame, or event-specific trapframe contract on this seam.
   - This keeps the privileged core mechanistic and prevents runtimes from depending on one ambient kernel callback shape.

4) **No portable event-driven vCPU or processor-allocation contract**
   - Phase 1 does **not** standardize a contract where the kernel reallocates processors/vCPUs to an address space and vectors those changes to a user scheduler.
   - There is no portable “you now own N processors/vCPUs” control plane, and no reviewed meaning for processor-allocation upcalls, wakeup vectors, or preemption callbacks.
   - Products that need local runtime schedulers or hypervisor-specific event channels must treat them as owner-local tactics, not native SlopOS semantics.

5) **No portable timeout-fault / budget-exhaustion callback surface**
   - Budget depletion semantics remain those already pinned by **D-SCHED** / **D-TCAP**.
   - Phase 1 does **not** standardize a portable user-space timeout-fault handler, budget-overrun callback, replenishment callback, or scheduler-side exception channel.
   - Any provider-local timeout notification remains beneath explicit admission/accounting seams and must not become a new authority path.

6) **No portable scheduler inventory, runnable-thread oracle, or peer steering plane**
   - D-UPCALL adds no portable API for “which runnable thread blocked or woke”, “which CPU/vCPU was reallocated”, “who was preempted”, or “reconsider scheduling now for peer X”.
   - Observable runtime state remains bounded by the existing inspection / observation seams rather than a new scheduler-event oracle.
   - This prevents D-UPCALL from quietly reintroducing ambient scheduler topology/state leakage.

7) **No new workflow / ACP / conflict-key family in v0**
   - Phase 1 introduces no portal family, no **CH-ACP** kind, and no conflict-key family for scheduler-event delivery or scheduler registration.
   - There are therefore no new externally visible actions to classify for commutativity in v0; the posture is a refusal boundary, not a control surface.
   - Any future reviewed scheduler-event/admin plane must return RFC-first with explicit event vocabulary, conflict keys, serialization boundary, and evidence hooks.

8) **Sealed compat remains killable and non-ambient**
   - Foreign/compat runtimes MAY use local scheduler-activation, UMS-like, or event-channel techniques internally, but they MUST NOT recreate an ambient native scheduling-upcall meaning for reviewed SlopOS components.
   - Disabling the relevant compat lane/profile must fail closed for adapters that depend on those techniques.
   - This keeps ecosystem ideas importable as local tactics without letting them outrun the authority substrate.

## Phase 1 non-goals (explicitly deferred)

- Scheduler-activations style kernel event vectoring as portable application/runtime meaning.
- A portable user-mode scheduler registration ABI or callback stack contract.
- A portable timeout-fault / budget-exhaustion / replenishment callback surface.
- A portable event-driven vCPU / processor-allocation upcall contract.
- A workflow / ACP family for scheduler-event delivery or scheduler registration.

## Wiring

- Decision surface:
  - `decision-map.md` (D-UPCALL)
- Primary adjacent runtime seams:
  - `scheduling-posture-v0.md`
  - `temporal-capability-schema-v0.md`
  - `waitset-posture-v0.md`
  - `ioq-posture-v0.md`
  - `reqctx-posture-v0.md`
  - `quiesce-posture-v0.md`
- History / rationale:
  - `rfcs/0049-temporal-capabilities-and-scheduling-contexts.md`
- Discovery/profile surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future scheduler-event/control surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_upcall_posture.py` fails `make lint` if this posture stops being discoverable, loses the **none in Phase 1 / existing seams own events / no scheduler registration ABI / no event-driven vCPU contract / no timeout-fault callback / no workflow-ACP surface** posture, or drops its primary REF wiring.

## References

- REF-SCHED-ACTIVATIONS.
- REF-SEL4-MCS-TUTORIAL.
- REF-SEL4-API-SC-UNBIND.
- REF-WIN-UMS.
