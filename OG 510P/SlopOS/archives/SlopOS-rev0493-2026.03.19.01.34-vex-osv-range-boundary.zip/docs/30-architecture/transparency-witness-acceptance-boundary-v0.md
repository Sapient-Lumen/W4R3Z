# Transparency-witness acceptance boundary v0 (explicit local witness policy only; no checkpoint-selected witness plane)

Purpose: pin the **Phase 1** meaning of witness cosignatures around **D-WITNESS** and **D-TLOG** so extra checkpoint signatures do not quietly choose which witnesses count, what quorum is required, or what additional semantics a checkpoint now carries.

Entropy cost justification: `transparency-log-posture-v0.md` already pins witnesses to *optional corroboration*, and `tlog-replication-boundary-v0.md` already says trusted logs/witnesses stay local explicit policy. The remaining ambiguity is narrower and still expensive: **how witness identities, thresholds, and any extra witness statements are accepted**. One small boundary closes that gap without adding a new schema family, witness-policy object, or online discovery/negotiation service.

## Posture (v0)

1) **Accepted witness identities, quorums, and extra statements remain explicit local policy.**
   - Verifiers/monitors decide which witness public keys, names, supported versions, and quorum rules count for one `log_id`.
   - Sigsum-style trust policy is the right mental model: logs, witnesses, and quorum rules are configured as explicit local trust policy rather than inferred from whatever checkpoint happened to arrive.
   - In SlopOS Phase 1, that means witness acceptance stays under explicit local policy and assurance anchors **I-TLOG-2** and **PO-TLOG-WITNESS**.

2) **Cosignature presence does not auto-enroll witnesses or raise the quorum.**
   - A checkpoint may carry one log signature plus zero or more witness signatures, and clients may ignore signatures that do not match the locally configured witness tuples.
   - Unknown/extra signature lines, mirrored checkpoints, or extra attached witness bundles therefore do **not** by themselves expand the trusted witness set, change an M-of-N rule, or upgrade a release to “audit-complete”.
   - Phase 1 adds no portable “whatever signatures are present define the quorum” rule.

3) **Witness semantics stay checkpoint-consistency-first.**
   - A C2SP `cosignature/v1` statement is, first, evidence that the witness observed a checkpoint consistent with the append-only history it had seen for that log.
   - Additional witness claims such as mirroring, hardware residency, retention, operator independence, or extra validation checks are **out-of-band policy facts**; they do not arise merely from the witness name, endpoint, checkpoint extension lines, or signature presence.
   - If local policy wants such stronger statements, it must bind them explicitly to exact witness keys/versions.

4) **Witness timestamps remain evidence, not ambient freshness or time authority.**
   - Cosignature timestamps may support audit/debug/freshness policy, but they do not become global wall-clock authority, lease freshness, rollout order, or a replacement for already-pinned **D-TIME** / **D-TIMEPROOF** semantics.
   - A newer witness timestamp therefore does **not** outrun local verification policy, repository freshness rules, or signing-time evidence requirements by itself.

5) **“Audit-complete” is a local policy conclusion, not a checkpoint-carried grant.**
   - A release/channel may define “audit-complete” as “exact checkpoint tuple + exact witness threshold + exact local freshness rules + exact monitor policy”.
   - Missing, stale, mismatched, or insufficient witness evidence may therefore downgrade or fail that local conclusion.
   - The checkpoint or witness bundle itself does **not** carry a bearer-grade “audit-complete” flag that another verifier must honor.

6) **Sealed compat remains honest.**
   - Compat/import paths that auto-load witness sets, quorum rules, or witness metadata from host config, environment variables, registry annotations, or ambient network lookups must remain killable by policy and must not create hidden authority via paths, env vars, or implicit network fetch.
   - A compat path that cannot verify without ambient witness discovery must fail closed for portable Phase 1 semantics.

7) **No native witness-policy inventory, discovery, or negotiation plane in v0.**
   - Phase 1 adds no native “list witnesses for this log”, “discover a quorum policy”, “fetch the latest witness set”, “ask a checkpoint which witnesses matter”, or “negotiate acceptable witnesses” service.
   - Exact witness evidence may travel through existing artifact/evidence seams, but acceptance policy remains out-of-band and killable.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no new ACP kind, and no new conflict-key namespace.
   - It only narrows what witness acceptance is allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native witness-policy object/schema in Phase 1.
- No checkpoint-selected quorum or auto-enrollment semantics.
- No witness-name / URL / endpoint-based authority inference.
- No portable rule that cosignature timestamps define global freshness or time.
- No native witness discovery / watch / negotiation plane.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, witnessed transparency almost always drifts in four expensive directions:

- **Checkpoint signatures start choosing trust.** Whatever witness lines appear on a checkpoint silently become the witness set or quorum rule.
- **Extra witness statements become folklore.** Operators infer “this witness also mirrored / stored / checked X” from names, URLs, or marketing rather than explicit pinned policy.
- **Witness timestamps become ambient freshness.** A later witness timestamp gets mistaken for install freshness, signing-time proof, or global time discipline.
- **Audit-complete becomes a portable badge.** A witness bundle gets treated as a bearer-grade approval token rather than a local evidence conclusion.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** download/update verification can use witnessed transparency without inheriting whatever signatures or witness URLs happen to be present.
- **Cloud micro-VM / hosted substrate (B):** fleet policy can require witnessed checkpoints while keeping accepted witness keys/quorums explicit and reviewable.
- **Embedded / separation-kernel-ish appliance (C):** appliances can ship tiny pinned witness policy and reject all ambient witness discovery.
- **Agent / automation OS (D):** agents may carry witness bundles as evidence, but they cannot smuggle “trust these witnesses” or “this is audit-complete” decisions inside the checkpoint they want admitted.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-WITNESS**, **D-TLOG**.
- Adjacent seams:
  - `docs/30-architecture/transparency-log-posture-v0.md`
  - `docs/30-architecture/transparency-log-anchor-schema-v0.md`
  - `docs/30-architecture/tlog-replication-boundary-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md`
- Assurance anchors:
  - **I-TLOG-2**, **PO-TLOG-WITNESS**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_transparency_witness_acceptance_boundary.py` keeps the boundary small and discoverable (**EVID-2026-474**).

## References

- REF-COSI-2015
- REF-TLOG-CHECKPOINT
- REF-TLOG-COSIGNATURE
- REF-TRANSPARENCY-WITNESS
- REF-SIGSUM-GETTING-STARTED
