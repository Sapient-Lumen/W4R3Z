# D-UICAP posture v0 (trusted UI path without picking a UI stack)

Purpose: resolve **OQ-0004 (D-UICAP scope)** by pinning a narrow, implementable v0 scope for capability-mediated UI.

This is a posture document, not a new schema.
It does **not** pick a toolkit, compositor protocol, remote display protocol, or desktop UX.

## Posture (v0)

**v0 posture:** if D-UICAP is enabled, SlopOS treats the UI boundary as a capability seam and supports a spoof-resistant trusted entry (SAS) for high-risk flows, while keeping the privileged core small.

Minimum required properties (when enabled):

1) **Surface isolation** (I-UICAP-1): no ambient pixel readback or cross-client surface control.
2) **Focus-gated input** (I-UICAP-2): unfocused clients do not receive input; “global” interception/injection is capability-gated.
3) **High-risk UI authority is portal-only** (D-PLUMB): capture/remote-control/screenshot/automation sessions are workflow-mediated (and SHOULD be leased under D-LEASE).
4) **Secure attention entry (SAS) is supported for interactive profiles that claim spoof resistance** (I-SAS-1): a non-interceptable user gesture that enters a visually distinct secure UI mode.

### Scope by product shape (A–D) (guidance; not authority)

| Shape | D-UICAP default | SAS / secure UI mode | D-VOLITION | D-UIAUT (automation) |
|---|---|---|---|---|
| (A) secure workstation | **on (recommended)** | **required** for login/unlock + high-risk consent surfaces | on (recommended) | observation-only by default; injection is portal + lease + explicit policy |
| (B) cloud micro-VM / substrate | off (default) | n/a | optional (headless approvals via external console if present) | off (default) |
| (C) embedded / separation appliance | off (default) | optional (only if interactive local admin UI exists) | optional | off (default) |
| (D) agent/automation OS | optional | **required** if any human approval surface is claimed | on (recommended when human-in-loop exists) | on (expected), but injection remains leased + transcript-visible |

Notes:
- “Default” here is guidance: profiles remain policy-driven via normal config/lane posture surfaces.
- When D-UICAP is off, any “desktop-like” UI is treated as untrusted application space; do **not** claim spoof resistance.

### Secure attention + secure UI mode (v0 semantics)

If SAS is enabled, v0 semantics are:

- SAS is delivered **only** to the secure UI component(s) (PO-SAS-DELIVER / I-SAS-1).
- SAS enters a visually distinct **secure UI mode** that occludes/freezes normal surfaces.
- While in secure UI mode:
  - normal applications do not receive input;
  - capture and injection authorities are disabled unless explicitly permitted by policy;
  - high-risk prompts (login/unlock, consent/powerbox) are hosted only by the secure UI component.

This posture is compatible with multiple implementation strategies:
- hardware-driven attention keys where available,
- reserved key chord (Ctrl+Alt+Del style) if the platform can deliver it exclusively,
- out-of-band console/management UI on headless targets.

## Phase 1 non-goals (explicitly deferred)

To keep v0 implementable and prevent scope creep, D-UICAP v0 does **not** require:

- a specified compositor IPC protocol,
- a specified rendering stack/toolkit,
- global hotkey APIs for third-party apps,
- cross-client accessibility tree/text readback as ambient capability,
- “secure input session” leases for arbitrary sensitive widgets (defer until evidence pressure exists).

If any of the above becomes necessary, introduce it via an RFC and attach new evidence hooks.

## Wiring

- Decision surface: `decision-map.md` (D-UICAP) and OQ-0004.
- Related surfaces:
  - `portal-family-registry.md` (high-risk UI authority is portal-only)
  - `capability-lease-posture-v0.md` (D-LEASE; leasing for capture/automation sessions)
  - `microvm-display-input-posture-v0.md` (under `ext.microvm`, guest-visible display/input devices stay non-portable; trusted UI and remote-control meaning still ride on D-UICAP / portal seams)
- RFC context: RFC-0080 (UI authority posture + SAS notes).
- Evidence hooks:
  - EVID-2026-078 (compositor harness negative tests)
  - EVID-2026-095 (SAS + secure mode integration harness)
  - Drift gate evidence: EVID-2026-213
- CI drift gate: `tools/check_uicap_scope_posture.py`.

## References

- REF-MS-WINLOGON-SAS
- REF-MS-UAC-SECUREDESKTOP
- REF-IBM-AIX-TRUSTEDPATH
- REF-QUBES-ARCH (trusted UI boundary precedent; comparison only)
