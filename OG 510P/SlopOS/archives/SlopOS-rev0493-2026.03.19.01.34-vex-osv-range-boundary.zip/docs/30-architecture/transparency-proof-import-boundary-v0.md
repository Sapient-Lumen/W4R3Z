# Transparency-proof import boundary v0 (exact imported proof artifact; no inline witness/proof drift)

Purpose: pin the **Phase 1** transport/import seam for offline transparency proofs around **D-TLOG** and **D-WITNESS** so witnessed inclusion evidence does not sprawl into ad-hoc inline `CH-TLOG` fields, bespoke JSON witness bundles, or live fetch-at-verify folklore.

This boundary is intentionally narrow. It does **not** define a new native proof schema. Instead, it chooses one exact interop shape for portable offline proof handoff and keeps native SlopOS authority on the already-pinned `CH-TLOG`, verification-verdict, and witness-acceptance seams.

## Posture (v0)

1) **CH-TLOG stays the small native anchor; offline proof transport stays external.**
   - `CH-TLOG v0` continues to bind **one exact `leaf_digest` of `leaf_kind` to one exact checkpoint tuple**.
   - Merkle inclusion paths, checkpoint-note text, witness cosignature lines, and other offline-proof bytes do **not** silently expand the native `CH-TLOG` surface.
   - When a verifier needs the full inclusion+witness package offline, Phase 1 carries that package as an **exact external artifact** referenced by `CH-AREF v0` or an enclosing release-bundle manifest.

2) **Portable offline proof import prefers one exact ecosystem artifact: `c2sp.org/tlog-proof@v1`.**
   - Phase 1 prefers the C2SP transparency-proof text artifact because it already composes the exact ingredients needed for offline verification: checkpoint, optional witness cosignatures, inclusion index, and Merkle inclusion proof.
   - A release bundle MAY therefore ship a `*.tlog-proof` file (or equivalent exact bytes) as a referenced artifact while keeping `CH-TLOG` itself bounded.
   - Phase 1 does **not** add inline witness-signature arrays to `CH-TLOG`, and it does **not** standardize a second native SlopOS proof schema for the same job.

3) **Imported proof bytes remain exact evidence under explicit local log/witness policy.**
   - A `tlog-proof@v1` artifact is useful because it is self-contained and offline-verifiable against a fixed set of trusted log and witness public keys.
   - Its meaning remains subordinate to explicit local verifier policy already pinned by `transparency-log-posture-v0.md`, `transparency-witness-acceptance-boundary-v0.md`, `verification-policy-selection-boundary-v0.md`, and `verification-verdict-boundary-v0.md`.
   - Proof presence therefore does **not** auto-authorize install, boot, rollout, approval, or a waiver.

4) **Opaque `extra` data stays non-authoritative.**
   - C2SP `tlog-proof@v1` allows optional opaque extra data, but that field is not authenticated and MUST NOT be implicitly trusted.
   - Phase 1 therefore treats any imported `extra` payload as correlation/debug context only unless a future explicit adjunct says otherwise.
   - No profile may use `extra` data to smuggle trust roots, witness policy, target locators, release channels, or approval state.

5) **Proof import does not create an ambient discovery/fetch plane.**
   - Verifiers consume exact proof bytes that were explicitly handed to them.
   - Proof contents do **not** imply permission to fetch tiles, query witness endpoints, follow monitoring prefixes, or discover mirror infrastructure at verification time.
   - Any online refresh/reconstruction remains tooling-only, policy-killable, and outside the native authority substrate.

6) **Additional cosigner statements stay out-of-band local-policy meaning.**
   - C2SP cosignatures are checkpoint-consistency-first, and any extra statements attached to a given `(name, public key, supported version)` tuple are defined out of band.
   - Phase 1 therefore refuses to treat proof-carried witness or mirror signatures as self-describing durability, availability, or review guarantees.
   - If a local deployment wants to treat some witness as a mirror or require additional statements, that meaning stays an explicit local policy attachment to the trusted witness tuple.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how transparency proof artifacts are carried and interpreted.
   - Importing or verifying an offline proof adds no new externally visible action kind, no conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native native tlog-proof / witness-bundle schema family in Phase 1.
- No inline witness-signature array or inclusion-path payload on `CH-TLOG v0`.
- No native tile-fetch / witness-query / mirror-discovery / proof-refresh API.
- No rule that proof-carried `extra` data is authenticated, portable policy, or approval state.
- No witness/mirror auto-discovery from proof contents.

## Why this is worth pinning

The archive already had the right security split, but not one transport choice. RFC-0082 still allowed either a digest-bound witness bundle or inline witness signatures “if bounded”. That ambiguity is cheap in prose and expensive in tooling. Choosing one exact import shape now buys three things:

- **Less entropy:** one portable offline-proof handoff shape instead of native-schema-vs-inline-vs-ad-hoc-bundle drift.
- **Smaller native seam:** `CH-TLOG` stays a compact anchor instead of growing proof transport obligations.
- **Better interop:** C2SP `tlog-proof@v1` is already designed as a self-contained offline-verifiable proof artifact, so SlopOS can import it cleanly without inheriting an online transparency client plane.

## Profile effect (A–D)

- **Secure workstation (A):** power users can keep proofs as explicit attached evidence without turning package names or fetched URLs into ambient authority.
- **Cloud micro-VM substrate (B):** release pipelines can hand off one exact proof artifact to auditors/agents and cache it offline, while install verdicts still remain local policy.
- **Embedded / separation appliance (C):** the portable boot/update substrate stays small; witnessed transparency proofs remain detached evidence artifacts rather than another parser inside the critical path.
- **Agent / automation OS (D):** agents may carry exact proof files as evidence, but they cannot smuggle witness policy, channels, or approval authority inside inline proof metadata.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-TLOG**, **D-WITNESS**, **D-AREF**, **D-PCP**.
- Adjacent meaning pins:
  - `docs/30-architecture/transparency-log-posture-v0.md`
  - `docs/30-architecture/transparency-witness-acceptance-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/30-architecture/transparency-log-anchor-schema-v0.md`
- Engineering / RFC surfaces:
  - `docs/60-engineering/pcp-posture-v0.md`
  - `rfcs/0029-transparency-log-anchors-for-evidence.md`
  - `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md`
- Assurance anchors:
  - **I-TLOG-1**, **I-TLOG-2**, **I-AREF-1**, **PO-TLOG-VERIFY**, **PO-TLOG-WITNESS**, **PO-AREF-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_transparency_proof_import_boundary.py` keeps the split small and discoverable (**EVID-2026-475**).

## References

- **REF-TLOG-PROOF**
- **REF-TLOG-CHECKPOINT**
- **REF-TLOG-COSIGNATURE**
- **REF-TRANSPARENCY-WITNESS**
