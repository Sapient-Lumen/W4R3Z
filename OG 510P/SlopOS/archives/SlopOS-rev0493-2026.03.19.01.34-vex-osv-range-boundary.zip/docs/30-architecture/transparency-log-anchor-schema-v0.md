# CH-TLOG v0 (transparency log anchor, informal)

Purpose: provide a compact, verifiable “this digest was logged” record for release/provenance/signing-event evidence.
Posture note: the portable meaning of D-TLOG is pinned in `transparency-log-posture-v0.md`: CH-TLOG binds one exact artifact digest to one exact append-only log state, inclusion evidence is not complete log verification, checkpoint order is not freshness/time/runtime authority, and Phase 1 adds no native latest/query/watch/admin plane.

Key design rule: the **kernel does not depend on the log**. Log anchoring is an evidence pipeline (D-TLOG).

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- anchors only small digests/metadata; large objects live elsewhere
- supports third-party auditing: checkpoint signatures + consistency progression

## Shape (v0)
An anchor record `t` contains:
- `schema`: fixed `CH-TLOG v0`
- `log_id`: identifier for the target log instance (string)
- `pubkey_id`: identifier for the log’s public key used to verify checkpoints
- `leaf_kind`: closed enum (e.g., `boot_digest`, `prov_digest`, `sigenv_digest`, `signed_statement_digest`, `release_bundle_digest`, `proof_bundle_digest`)
  - companion boundary `proof-bundle-role-boundary-v0.md`: `proof_bundle_digest` anchors exact external bundle bytes only; it does not compress bundle completeness or policy approval into the leaf kind
- `leaf_digest`: digest of the anchored artifact
- `checkpoint`:
  - `tree_size`: u64
  - `root_hash`: bytes
  - `signature`: bytes (over `tree_size || root_hash`, exact format profile-specific)
- `inclusion_proof_digest`: optional digest of a stored inclusion proof object (kept out-of-band); portable offline handoff prefers an exact external proof artifact rather than inline proof bytes (see `transparency-proof-import-boundary-v0.md`)
- `prior_checkpoint_digest`: optional digest link to an earlier checkpoint (for consistency verification); newer checkpoints do not outrun local freshness/policy by themselves

Hybrid / replication note: if CH-TLOG artifacts travel under `object_family = tlog`, replicated checkpoints/proofs remain **evidence only**. They do not by themselves authorize boot/update/runtime actions, rotate trusted log keys/origins/witness sets, or supply global time/order semantics; those choices stay local explicit policy (see `tlog-replication-boundary-v0.md`). Companion `transparency-witness-acceptance-boundary-v0.md` further pins that multiple/unknown checkpoint signatures do not define the accepted witness set, quorum, or audit-complete meaning, while companion `transparency-proof-import-boundary-v0.md` pins that witnessed/inclusion proof transport stays an exact external artifact instead of an inline `CH-TLOG` expansion.

## Verification obligations
- PO-TLOG-VERIFY:
  - checkpoint signature verifies against the pinned public key
  - if `prior_checkpoint_digest` present, the verifier checks consistency between checkpoints (append-only growth)
  - mismatch/verification failure is treated as “anchor invalid” (evidence rejected)

Refs: REF-CT-RFC6962, REF-TLOG-SWTCH, REF-TESSERA, REF-SIGSTORE-REKOR.
