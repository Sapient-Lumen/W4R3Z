# virtio-iommu mechanism note (v0)

Purpose: capture a **small, implementable** mechanism option for DMA confinement *inside* a guest when we use a virtio-first microVM device model.

This doc does **not** change any claims. The portable Phase-1 meaning of guest-visible vIOMMU exposure is pinned separately in `microvm-virtual-iommu-posture-v0.md`: no ambient reviewed `virtio-iommu` / endpoint-attach / map-unmap / fault-status / address-width plane is admitted unless a later RFC pays for it. It attaches to:
- **D-DMA** posture (DMA containment must be fail-closed when C-ISO-2 is claimed),
- **D-MICROVM** posture (virtio-first, declared device model),
- and the driver-domain direction in `mechanisms.md` (device logic outside the privileged core).

## What virtio-iommu is (in one paragraph)

`virtio-iommu` is a paravirtual IOMMU device. It gives the guest a standard way to manage I/O virtual addresses (IOVAs) for endpoints behind it (virtio devices and, in some designs, passed-through devices). In practice, it can provide a **guest-visible DMA translation/control seam** without emulating a full physical IOMMU model.

## Why this fits SlopOS (optional; B-first)

For product shape **(B) cloud micro-VM / hosted compute substrate**, virtio-iommu is a useful option because it:
- keeps the **device model paravirtual** (aligned with `ext.microvm`),
- improves nested-virt / device-assignment ergonomics (guest can reason about IOVA space),
- can make DMA confinement *inside the guest* more explicit and evidenceable.

## Hard constraints (keep D-DMA honest)

1) **virtio-iommu is not a substitute for host IOMMU/SMMU.**
   - D-DMA `iommu_required` (for C-ISO-2) still depends on host-side enforcement for *physical* DMA.

2) **It must be declared and killable.**
   - If used, `virtio-iommu` must be part of the declared microVM device set (no “it appears sometimes”).
   - Profiles/policy must be able to disable it deterministically (no ambient vIOMMU).

3) **No ambient inspection channels.**
   - Any “introspection” about mappings must remain a bounded, schema-pinned receipt/projection surface (e.g., CH-SPROJ v0), not ad-hoc debugging hooks.

4) **Keep the ‘juicy ecosystem feature’ imports honest.**
   - crosvm’s CoIOMMU is an interesting optimization for **trusted** VFIO devices because it can reduce whole-VM pinning pressure, but its own docs explicitly say it does **not** provide intra-guest protection. That makes it a useful research import and a poor candidate for ambient portable meaning in Phase 1. Keep it implementation-local unless an RFC pays for the trust model and evidence story.

## Phase-1 stance (decision vocabulary)

Phase 1 does not require virtio-iommu, but we treat it as an **approved mechanism candidate** for later B-profile hardening. The new posture doc means exactly one thing here: approved mechanism candidate does **not** mean approved portable guest contract.

If adopted, it should be wired under D-DMA evidence hooks:
- negative tests around “deny-by-default mapping” when posture preconditions are not met,
- and swap-order/serialization tests around any portal/service actions that create mapping authority.

## References (primary)

- virtio spec v1.3 (device definitions; includes virtio-iommu). (REF-VIRTIO-1.3)
- Cloud Hypervisor IOMMU docs (virtio-iommu design/constraints). (REF-CHYP-IOMMU)
- Linux virtio-iommu DT binding note (plumbing surface; useful for embedded/Arm platforms). (REF-LINUX-VIRTIO-IOMMU-DTB)
- virtio spec source repository (for diffing / tracking updates). (REF-OASIS-VIRTIO-SPEC-REPO)
- crosvm CoIOMMU docs (trusted-device-only fine-grained pinning optimization; not intra-guest protection). (REF-CROSVM-COIOMMU)
