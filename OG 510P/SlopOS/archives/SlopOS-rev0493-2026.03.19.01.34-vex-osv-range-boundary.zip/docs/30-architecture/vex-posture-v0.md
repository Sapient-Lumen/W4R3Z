# VEX posture v0 (digest-bound exploitability evidence; no suppression/feed/authority semantics)

Purpose: pin the Phase-1 meaning of **D-VEX** so exploitability statements do not quietly turn into scanner-suppression folklore, ambient advisory feeds, or a second authority path.

This posture is intentionally narrower than a full vulnerability-management platform. It fixes the portable meaning of **CH-VEX admission and use** while keeping vendor publication cadence, external advisory ecosystems, and local triage workflows outside the native authority substrate unless another seam admits them explicitly.

## Posture (v0)

1) **CH-VEX is digest-bound exploitability evidence only.**
   - Accepted VEX meaning is the bounded statement set bound to one exact `subject.digest` under **I-VEX-1**, **I-VEX-2**, **PO-VEX-VALIDATE**, and **PO-VEX-BIND**.
   - CH-VEX MUST NOT by itself authorize boot, update, import, vulnerability suppression, or policy widening.

2) **One subject, one bounded statement snapshot; no portable feed/supersession semantics.**
   - A CH-VEX artifact names one subject digest and one bounded statement set.
   - Phase 1 adds no native “latest advisory wins”, “merge this vendor feed with that scanner feed”, “subscribe to updates”, or “apply document supersession chains automatically” meaning.

3) **Closed status/justification enums are the portable vocabulary; `vuln_id` stays an exact label.**
   - `status` and `justification.kind` remain closed under **I-VEX-2**.
   - Companion `vex-vulnerability-identity-boundary-v0.md` further pins that `vuln_id` is one exact statement label rather than a native alias / upstream / related graph, canonical-vulnerability selector, or cross-ID suppression key; any advisory-ID correlation stays verifier-local.
   - Companion `vex-statement-key-boundary-v0.md` further pins that `statements[]` order is non-authoritative and one exact scoped statement key carries at most one live statement; duplicate or contradictory same-key rows fail closed rather than triggering a native last-wins or timestamp-precedence rule.
   - Companion `vex-priority-signal-boundary-v0.md` further pins that imported CVSS / EPSS / KEV / vendor-severity style signals do not become a native install-veto, waiver, or rollout-priority plane; any thresholds or score-fusion logic stay verifier-local.
   - Companion `vex-cpe-applicability-boundary-v0.md` further pins that imported CPE names / applicability expressions stay imported targeting evidence rather than a native same-product, applicability, or install-scope rule; any CPE dictionary / match / applicability evaluation stays verifier-local.
   - Companion `vex-reference-locator-boundary-v0.md` further pins that imported advisory references / locator fields stay bounded descriptive evidence rather than a native fetch, discovery, or resolver rule; any dereference/prioritization stays verifier-local.
  - Companion `vex-osv-range-boundary-v0.md` further pins that imported OSV package/range semantics stay imported advisory matching evidence rather than a native same-component, version-ordering, or update-selection rule; any OSV ecosystem/package/range evaluation stays verifier-local.
   - Human-readable notes, actions, references, and external docs stay bounded adjunct evidence rather than an open narrative policy language.

4) **Inventory linkage is explicit and subject-bound when present.**
   - If `inventory_digest` is present, it is a pointer to **CH-SBOM** evidence for the same subject.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` further pins that multiple exact SBOM/VEX artifacts do not become one native vulnerability/applicability closure merely because they are attached together or linked by `inventory_digest`.
   - Companion `sbom-bomref-identity-boundary-v0.md` further pins that CycloneDX `bom-ref` labels remain document-local imported identifiers rather than a native cross-artifact component identity or suppression join key.
   - Companion `sbom-purl-identity-boundary-v0.md` further pins that imported `purl` stays a package label rather than a native cross-artifact component identity or suppression join key; any normalization/correlation across package ecosystems stays verifier-local.
   - Companion `sbom-component-version-boundary-v0.md` further pins that component/subject `version` labels stay descriptive imported evidence rather than a native same-component, newer-than, or suppression join rule; any version comparison/canonicalization/range reasoning stays verifier-local.
   - Companion `vex-component-absence-boundary-v0.md` further pins that `component_not_present` plus one selected inventory does not become a native absence oracle; completeness and component matching stay verifier-local rather than riding on one linked inventory or one naming convention.
   - Companion `vex-remediation-selection-boundary-v0.md` further pins that `fixed` and remediation/action text do not become a native patch-plan selector, minimum-safe-version oracle, or successor-target chooser; update selection stays explicit on CH-UPD / TUF / local policy rather than riding on advisory prose or version labels.
   - Companion `vex-investigation-deferral-boundary-v0.md` further pins that `under_investigation` and VEX timing fields do not become a native install hold, grace window, or waiver authority; unresolved-advisory caution/review posture stays verifier-local rather than riding on advisory cadence or timestamps.
   - Phase 1 adds no ambient component-resolution or package-lookup service that reinterprets VEX statements against some other inventory.

5) **Author/generator/contact fields are hints, not trust roots.**
   - `author.*`, `generator.*`, and similar metadata are observational only.
   - If a profile/product wants signed or attestable VEX publication, that trust rides on explicit **D-SIGENV**, **D-TLOG**, **D-TIME**, or packaging policy rather than on CH-VEX metadata itself.

6) **VEX is reviewable evidence, not an ambient scanner-suppression channel.**
   - Local tooling MAY use CH-VEX as one input to triage, reporting, or release readiness.
   - Phase 1 standardizes no privileged-core “ignore this CVE forever”, no scanner-specific suppression registry, and no hidden waiver carry-forward semantics on D-VEX itself.

7) **Export and disclosure stay policy-scoped.**
   - Publishing/exporting VEX material remains governed by **D-OBSPOL** and adjacent release policy because statement content may leak mitigations, component versions, or topology.
   - Phase 1 adds no ambient “list all advisories” inventory service and no hidden export of internal mitigations outside explicit policy.

8) **No portable live fetch / discovery / watcher plane in v0.**
   - D-VEX adds no native advisory feed discovery, polling, subscription, or remote-resolution contract.
   - Tooling may carry VEX artifacts in release bundles, provenance sets, or owner-local repositories, but Phase 1 does not standardize a runtime advisory service.

9) **No new workflow / ACP / conflict-key family in v0.**
   - D-VEX reuses existing update/provenance/observation/admission seams.
   - Any future VEX waiver/ack/publication workflow must return RFC-first with explicit conflict keys, commutativity rules, serialization boundary, and evidence.

## Phase 1 non-goals (explicitly deferred)

- No scanner-suppression registry or “ignore finding” authority path on CH-VEX.
- No portable feed/discovery/subscription protocol.
- No ambient supersession/latest-wins semantics across multiple advisories.
- No unsigned metadata shortcut where `author` / `contact` / `generator` becomes trusted identity.
- No mandatory import of full OpenVEX / CSAF / CycloneDX advisory semantics into the privileged core.
- No new workflow / ACP family for VEX publication, waiver, or acknowledgement.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-SBOM**, **D-OBSPOL**, **D-SIGENV**, **D-TLOG**, **D-TIME**.
- Core schema / supply-chain seams:
  - `docs/30-architecture/vex-schema-v0.md` (CH-VEX v0).
  - `docs/30-architecture/sbom-schema-v0.md` (CH-SBOM v0).
  - `docs/30-architecture/artifact-reference-schema-v0.md` (CH-AREF v0).
  - `docs/60-engineering/supply-chain-repro.md`.
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`.
- Assurance anchors:
  - Invariants: **I-VEX-1**, **I-VEX-2**.
  - Proof obligations: **PO-VEX-VALIDATE**, **PO-VEX-BIND**, **PO-AREF-VERIFY**.
  - Adjacent seams: **D-SBOM** for inventory context, **D-OBSPOL** for export control, **D-SIGENV** for signature/admission policy, **D-TLOG** for transparency anchoring, **D-TIME** for freshness policy.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - `tools/check_supply_chain_evidence_posture.py` keeps the posture small and discoverable together with D-SBOM (EVID-2026-458).

## References

- REF-CISA-VEX-MINREQ
- REF-OPENVEX-SPEC
- REF-OPENVEX-REL
- REF-CSAF-ISO
- REF-UBUNTU-VEX
