# D-SKB posture v0 (explicit fact base; pure named queries; no ambient inventory/probing seam)

Purpose: pin an implementable **Phase 1** meaning for **D-SKB** so hardware discovery and placement logic can live in user space without quietly regrowing into an ambient `/sys`/`/proc` inventory contract, an in-kernel logic engine, or a generic query/programming surface that outpaces the proof story.
It narrows RFC-0018 into one compact posture adjacent to **CH-HWFACT v0**, **CH-HWEVENT v0**, **D-DEVGUARD**, **D-MK**, and sealed-compat rules so runtimes, validators, operators, and LLM-authored tooling can reason about one default shape.

## Posture (v0)

1) **Explicit fact artifacts, not ambient probing, drive portable meaning**
   - If **D-SKB** is enabled, portable hardware knowledge starts from explicit **CH-HWFACT v0** and optional **CH-HWEVENT v0** records, not from arbitrary late privileged probing.
   - Security-relevant device, routing, or topology decisions therefore remain traceable to a declared fact base under **I-HWFACT-1** rather than “whatever the runtime happened to discover right now.”
   - In plain terms: portable SlopOS meaning is the digest-bound fact base, not an ambient host inventory tree.

2) **SKB stays user space; no privileged-core logic/query engine**
   - The SKB is a **user-space** service over explicit fact artifacts; the kernel / hypervisor does not grow a Prolog / Datalog / CLP / SQL engine.
   - Privileged code may validate, expose, or apply bounded artifacts, but it does not become the place where hardware-policy search or query execution lives.
   - This imports the useful Barrelfish lesson—move hardware reasoning out of the kernel—without importing a larger privileged policy brain.

3) **Portable query surface is named + bounded; no portable free-form query language in v0**
   - Phase 1 standardizes at most a **small set of named queries** (for example CPU topology, IOMMU presence, bounded device lookup, or bounded route suggestions) with stable schema-bound results.
   - Phase 1 deliberately declines a portable text-query / REPL / “submit arbitrary Prolog/Datalog/CLP program” seam.
   - Local richer reasoning engines may exist beneath the SKB, but their syntax and evaluation model remain implementation-local until a future RFC pays that entropy cost explicitly.

4) **Queries used for policy/config are pure and epoch-bound**
   - Queries that affect privileged configuration must satisfy **PO-SKB-PURITY**: deterministic given declared **CH-HWFACT / CH-HWEVENT** inputs, transcript-visible when they drive authoritative changes, and attributable to one explicit fact epoch.
   - Optional hotplug/fact evolution therefore uses explicit `{epoch, event_seq}` progression rather than “re-run the query against mutable live state and hope it still means the same thing.”
   - This keeps replay/audit honest for device attach, routing, and multicore placement decisions.

5) **Results are recommendations/observations until another seam authorizes them**
   - SKB outputs are **non-authoritative** recommendations, summaries, or bounded lookup results unless another already-defined seam (for example CH-CFG installation, D-DEVGUARD policy, or an explicit admin action) validates and applies them.
   - An SKB answer therefore does **not** itself bind a driver, expose a device, widen authority, or mutate the running system.
   - This prevents the query layer from silently becoming a second control plane.

6) **Topology richness stays hint-only unless another surface says otherwise**
   - Cache groups, CPU capacity/performance classes, NUMA distance matrices, memory tiers, hwloc-style `Group` objects, and similar richer topology facts remain **placement hints only** in Phase 1 unless a separate RFC-first surface upgrades them.
   - The existing boundary docs for cache, CPU-capacity, and memory-locality authority remain authoritative here.
   - D-SKB may therefore help choose among already-authorized placements, but it does not create new ownership, budget, replay, or replication semantics by discovery alone.

7) **No portable ambient inventory tree, watch socket, or host path contract**
   - Phase 1 exposes no portable `/sys` / `/proc` / devfs-like inventory schema, no portable “subscribe to all hardware changes” socket/path protocol, and no portable shell-visible topology database path.
   - Observation/export remains on explicit already-authorized seams; any local host representation is implementation detail.
   - This keeps sealed compat honest: native meaning does not depend on ambient filesystem or global service discovery.

8) **Device names/paths/labels are never authority**
   - Human-readable device names, bus paths, or topology labels may aid debugging and UX, but they remain non-authoritative under **D-DEVGUARD** and **D-IOLEASE**.
   - If an authoritative decision cares about hardware identity, it must bind stable bounded identifiers/digests from the fact base and, when relevant, the current `{epoch, event_seq}`.
   - This keeps “helpful inventory text” from turning into a hidden policy key.

9) **No new workflow / ACP / conflict-key family in v0**
   - This doc adds no new dedicated SKB portal family, no **CH-ACP** kind for “run query,” and no new conflict-key family.
   - Ordinary read-only SKB lookups commute with themselves in the D-COMMUTE sense because they do not mutate the reviewed system state; any later action that applies a result must declare its own ordering/serialization on the owning seam.
   - If a future design wants mutable query programs, cache invalidation commands, or admin mutation verbs, it must pay an RFC-first entropy cost and say what commutes, what does not, where serialization lives, and how that is evidenced/tested.

## Phase 1 non-goals (explicitly deferred)

- A portable general-purpose Prolog / Datalog / CLP / SQL query/programming interface.
- A privileged-core hardware-policy engine.
- A portable ambient hardware inventory filesystem, daemon socket, or watch protocol.
- Query answers that directly mutate hardware policy, bind drivers, or create authority edges by themselves.
- Hidden device-name / path / label semantics for authorization.

## Wiring

- Decision surface:
  - `decision-map.md` (D-SKB)
- Primary schema / fact surfaces:
  - `hardware-facts-schema-v0.md`
  - `hardware-event-schema-v0.md`
  - `schema-registry.md` (CH-HWFACT v0, CH-HWEVENT v0)
- Adjacent architecture surfaces:
  - `rfcs/0018-system-knowledge-base-and-hardware-facts.md`
  - `cache-topology-authority-boundary-v0.md`
  - `cpu-capacity-authority-boundary-v0.md`
  - `memory-locality-authority-boundary-v0.md`
  - `device-authorization-and-hotplug-portals.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-HWFACT-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-HWFACT-BIND**, **PO-SKB-PURITY**, **PO-HWEVENT-VALIDATE**)
- Discovery/history surfaces:
  - `README.md`
  - `docs/README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future mutable SKB query/control plane must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_skb_posture.py` fails `make lint` if this posture stops being discoverable, loses the **explicit fact-artifact / user-space only / named-query only / pure epoch-bound / no ambient inventory-probing / no new workflow-ACP surface** posture, or drops its primary REF wiring.

## References

- REF-BARRELFISH-SKB.
- REF-DECLARATIVE-OS.
- REF-FUCHSIA-DRIVER-FRAMEWORK.
- REF-FUCHSIA-DRIVER-NODES.
- REF-HWLOC-OBJTYPES.
