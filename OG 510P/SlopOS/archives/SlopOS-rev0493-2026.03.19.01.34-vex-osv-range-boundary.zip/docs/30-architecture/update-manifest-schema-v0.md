# CH-UPD v0 (update / release manifest, informal)

Purpose: represent “what we intend to install” as explicit, canonical bytes that can be signed, logged, and verified.

Phase-1 meaning is pinned in `update-posture-v0.md`: **CH-UPD is digest-bound install intent only**. It does not become repository metadata, a rollout/cohort-control object, or a verification-summary / approval-verdict channel. Companion verdict semantics are pinned in `verification-verdict-boundary-v0.md`: verification/approval verdict meaning stays consumer-local rather than traveling inside CH-UPD.

Design goal: a **small** manifest that binds update intent to the same digest universe used by CH-BOOT and CH-PROV.

Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- binds a target deployment root to the configuration/policy used
- supports optional anti-rollback floor semantics (I-BOOT-2)

## Shape (v0)
A manifest `u` contains:
- `schema`: fixed `CH-UPD v0`
- `target_root_digest`: digest of the deployment root tree (content-addressed)
- `cfg_digest`: digest of the `CH-CFG v0` artifact to apply with this deployment
- `artifacts`: closed list of `{ name_tag, digest, role }` (bounded)
  - role examples: `kernel`, `init`, `policy`, `comp_manifest`, `sbom`, `vex`, `proof_bundle`
  - companion boundary `proof-bundle-role-boundary-v0.md`: `proof_bundle` remains a descriptive adjunct-evidence role only; local policy must still say whether any exact bundle digest matters and generic role presence never implies a verdict
- `rollback_floor`: optional `{ counter_id, min_value }`
- `prov_attestation_digest`: optional digest of a signed provenance envelope/container (e.g., CH-SIGENV) that signs a `CH-PROV v0` payload digest
  - companion boundary `provenance-container-selection-boundary-v0.md`: if an imported provenance container packages multiple statements, statement selection/reconciliation stays verifier-local
  - companion boundary `update-evidence-subject-boundary-v0.md`: adjunct evidence appraises the already-pinned staged cohort only; provenance extra subjects do not widen what CH-UPD installs
  - companion boundary `provenance-coverage-policy-boundary-v0.md`: CH-UPD carries exact provenance evidence digests only; it does not carry or select a portable provenance-coverage profile
  - companion boundary `provenance-evidence-set-boundary-v0.md`: multiple exact provenance-bearing artifacts do not jointly define a native provenance closure, fallback rule, or completeness claim
  - companion boundary `sbom-vex-evidence-set-boundary-v0.md`: multiple exact `sbom` / `vex` evidence artifacts do not jointly define a native applicability closure, fallback rule, or completeness claim
  - companion boundary `vex-component-absence-boundary-v0.md`: `component_not_present` plus one selected inventory does not define a native component-absence oracle or completeness verdict on CH-UPD
  - companion boundary `vex-remediation-selection-boundary-v0.md`: `fixed` / remediation text do not define a native patch-plan or update-target selector on CH-UPD
  - companion boundary `vex-investigation-deferral-boundary-v0.md`: `under_investigation` / VEX time fields do not define a native install-hold or defer-update selector on CH-UPD
  - companion boundary `vex-priority-signal-boundary-v0.md`: imported vulnerability scores / threat-list signals do not define a native install-veto, rollout-priority, or urgency selector on CH-UPD
  - companion boundary `vex-cpe-applicability-boundary-v0.md`: imported CPE names / applicability expressions do not define a native install-target selector, product-identity oracle, or applicability-closure rule on CH-UPD
- `created_at`: optional timestamp (informational; not used for authorization)
- `expires_at`: optional timestamp (informational; policy may require freshness)

## Verification obligations
- verify signatures / threshold policy per deployment profile (D-UPD-SIGN)
- verify `cfg_digest` matches the applied config (PO-CFG-VERIFY)
- verify each listed artifact digest matches fetched/installed content (PO-AREF-VERIFY when CH-AREF is used)
- verify `target_root_digest` matches the staged deployment tree (PO-UPD-VERIFY)
- if `rollback_floor` present: enforce at install/boot time (I-BOOT-2)
- if `prov_attestation_digest` present: verify it is present/valid and bound to the staged artifacts (PO-PROV-BIND); local policy may require provenance over exact staged digests chosen from `target_root_digest`, `cfg_digest`, and exact `artifacts[]` digests already pinned by CH-UPD; extra subjects remain extra evidence context only

Notes:
- `target_root_digest` + `cfg_digest` are the authoritative install-intent binding. Names, filenames, version strings, channel labels, and repo paths remain operator/debug metadata only; companion release-name/version semantics are pinned separately in `release-identity-boundary-v0.md`.
- `artifacts[]` is a bounded adjunct digest set, not a recursive fetch/install-order plan, package inventory protocol, or dependency solver; companion `update-evidence-subject-boundary-v0.md` further pins that grouped adjunct evidence cannot redefine the install subject beyond the pinned staged cohort.
- Companion `provenance-required-subject-boundary-v0.md` further pins that any stricter provenance requirement must be chosen from those exact already-pinned staged digests rather than from every subject present in a larger release attestation.
- Companion `provenance-coverage-policy-boundary-v0.md` further pins that carrier-borne provenance fields name exact evidence bytes only and do not choose which provenance-coverage policy is in force.
- Companion `provenance-evidence-set-boundary-v0.md` further pins that multiple exact provenance-bearing artifacts do not jointly define a native provenance closure or fallback rule on CH-UPD.
- Companion `sbom-vex-evidence-set-boundary-v0.md` further pins that multiple exact `sbom` / `vex` evidence artifacts do not jointly define a native applicability closure or fallback rule on CH-UPD.
- Companion `vex-component-absence-boundary-v0.md` further pins that `component_not_present` plus one selected inventory does not define a native component-absence oracle on CH-UPD; completeness judgment remains verifier-local.
- Companion `vex-remediation-selection-boundary-v0.md` further pins that `fixed` / remediation text do not define a native patch-plan or update-target selector on CH-UPD; successor selection remains explicit CH-UPD / TUF / repository policy.
Companion `vex-investigation-deferral-boundary-v0.md` further pins that `under_investigation` / VEX time fields do not define a native install-hold or defer-update selector on CH-UPD; unresolved-advisory caution remains explicit local policy rather than carrier meaning.
Companion `vex-priority-signal-boundary-v0.md` further pins that imported vulnerability scores / threat-list signals do not define a native install-veto, rollout-priority, or urgency selector on CH-UPD; score thresholds and prioritization remain explicit verifier-local policy rather than carrier meaning.
Companion `vex-cpe-applicability-boundary-v0.md` further pins that imported CPE names / applicability expressions do not define a native install-target selector, product-identity oracle, or applicability-closure rule on CH-UPD; any CPE matching or logical evaluation remains explicit verifier-local policy rather than carrier meaning.
- `created_at` / `expires_at` are informational until explicit policy validates them; freshness / freeze / replay protection stays on D-TUF, D-TIME, and local verifier policy rather than on “newest timestamp wins” semantics inside CH-UPD itself.
- CH-UPD does not dictate the distribution protocol. It can be transported inside TUF metadata or other channels, but the privileged boot path remains agnostic.
- CH-UPD is not repository metadata, a rollout/cohort policy object, or a verification/approval verdict. TUF/Uptane roles, staged-rollout policy, and health/admission outcomes stay on separate seams.
- If D-ATOMICUPD uses A/B-style health-commit semantics, the boot selector state (CH-BOOTSEL) SHOULD store the chosen `upd_digest` so post-boot audit can link selection/rollback decisions to a specific signed intent.
