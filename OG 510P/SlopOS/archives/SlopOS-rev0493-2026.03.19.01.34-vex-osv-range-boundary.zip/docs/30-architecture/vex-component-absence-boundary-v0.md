# VEX component-absence boundary v0 (`component_not_present` stays exact evidence, not a native absence oracle)

Purpose: pin the Phase-1 meaning of **component-scoped absence claims** across **D-VEX**, **D-SBOM**, **D-ATOMICUPD**, **D-BOOT**, and **D-AREF** so one `component_not_present` statement plus one linked inventory cannot quietly become a portable proof that no relevant vulnerable component exists for the whole install/boot cohort.

Entropy cost justification: the archive already pins CH-VEX / CH-SBOM as digest-bound evidence and already refuses cross-artifact applicability closure, but real ecosystems still ship rich product identifiers, component graphs, and completeness annotations. Leaving the relationship unstated invites expensive drift later: absence from one SBOM, or one VEX `component_not_present` statement, starts acting like a native component-presence oracle for every verifier. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** may carry a `justification.kind == "component_not_present"` statement and may optionally point at one exact `inventory_digest`.
- **CH-SBOM v0** still inventories one exact subject with one bounded component set.
- **Verifier-local policy** still answers whether any chosen inventory is completeness-sufficient for the particular question being asked.

## Posture (v0)

1) **`component_not_present` is exact evidence about one already-bound subject, not a native total-absence verdict.**
   - A CH-VEX statement with `justification.kind == "component_not_present"` says that the producer claims the named vulnerability is not relevant for the already-bound subject because the relevant component is absent.
   - That statement is reviewable evidence only.
   - Phase 1 does **not** import a native rule that this automatically proves release-wide, fleet-wide, cross-configuration, or cross-packaging absence of every relevant vulnerable component.

2) **Absence from one selected CH-SBOM is not a portable completeness proof by itself.**
   - `inventory_digest` and any referenced CH-SBOM remain pointers to one exact inventory artifact for the same subject.
   - A component missing from one selected SBOM does not by itself prove that the subject is globally free of that component or every repackaged/embedded variant of it.
   - Whether one selected inventory is completeness-sufficient remains verifier-local policy; companion `sbom-vex-evidence-set-boundary-v0.md` already pins that multiple exact inventories/advisories do not form one native applicability closure either.

3) **Stable identifiers carry any portable component match when present; richer naming stays imported evidence only.**
   - When present, exact `content_digest` / `build_id` style identifiers carry the most portable component-scoping meaning.
   - `name`, `version`, `purl`, `supplier`, OpenVEX identifier maps, IRIs, CycloneDX `bom-ref`, and similar rich labels remain hints or imported-format semantics rather than a new native SlopOS component-resolution grammar.
   - Companion `sbom-bomref-identity-boundary-v0.md` further pins that CycloneDX `bom-ref` remains a document-local imported label rather than a native cross-artifact component identity or completeness oracle.
   - Phase 1 therefore adds no native fuzzy match / alias / “same package under another label” rule for component-scoped VEX evaluation.

4) **Component-scoped absence claims do not auto-lift or auto-expand.**
   - A statement about one selected component identifier does not automatically generalize to all sibling components, all architectures, all subpackages, all embedded copies, or all alternative inventories for the same subject.
   - Subject binding still lives first on the exact CH-VEX / CH-SBOM subject digest, and any finer-grained reasoning remains explicit verifier-local logic.

5) **Imported completeness/composition semantics stay imported evidence unless another seam admits them.**
   - External SBOM/VEX documents may carry richer completeness/composition concepts such as CycloneDX dependency/composition metadata or producer-specific completeness labels.
   - Those may help a verifier reason about confidence, but Phase 1 does **not** promote them into a native completeness/absence oracle on D-SBOM or D-VEX.
   - Companion `verification-material-discovery-boundary-v0.md` still pins that discovering such richer material is explicit and killable rather than ambient.

6) **Each selected artifact still verifies on its own seam.**
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds the exact subject digest the verifier cares about.
   - **PO-SBOM-BIND** still answers whether one selected CH-SBOM artifact binds that same subject digest.
   - **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, and **PO-AREF-VERIFY** still answer carrier/evidence integrity for the already-pinned cohort.
   - No portable “absence proven” verdict is created merely by co-packaging a VEX statement with an inventory digest.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing VEX/SBOM/update/boot/evidence seams interpret component-scoped absence claims.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native component-absence oracle or completeness grammar on CH-VEX / CH-SBOM.
- No portable fuzzy component-resolution / alias / package-identity rule across names, purls, `bom-ref`, or importer-specific labels.
- No rule that one `component_not_present` statement or one selected inventory proves release-wide absence by itself.
- No automatic import of CycloneDX composition/completeness metadata or OpenVEX inheritance/product-resolution semantics into the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is helpful but deliberately richer than our Phase-1 authority substrate:
- OpenVEX treats `component_not_present` as a machine-readable justification and encourages rich product identifiers such as purls and hashes to help processors match products.
- CycloneDX explicitly warns that components not represented in a dependency graph may still have **unknown dependencies**, and uses composition metadata to express completeness/unknown-ness rather than assuming absence implies completeness.
- NTIA SBOM guidance and implementation guidance both distinguish **unknown / partial / known / root** completeness states, which is a strong signal that “not seen in one inventory” is not a universal truth without an explicit completeness story.

Pinning that split now keeps SlopOS from quietly inheriting “absence from one inventory plus one VEX statement proves total non-presence” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** vendors may attach exploitability statements without making local decision quality depend on hidden package-alias folklore.
- **Cloud micro-VM substrate (B):** fleet scanners may consume richer SBOM/VEX packs, but policy remains explicit about what counts as completeness-sufficient evidence for one image cohort.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can reject claims that need richer completeness reasoning instead of importing a whole package-identity engine.
- **Agent/automation OS (D):** agents may reason over richer external evidence, but they cannot smuggle “missing from this inventory means globally absent” into portable meaning.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-SBOM**, **D-ATOMICUPD**, **D-BOOT**, **D-AREF**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/sbom-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-SBOM-1**, **I-SBOM-2**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-AREF-1**.
  - **PO-VEX-BIND**, **PO-SBOM-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_component_absence_boundary.py` keeps the split small and discoverable (**EVID-2026-483**).

## References

- **REF-OPENVEX-SPEC**
- **REF-CYCLONEDX-DEPENDENCIES**
- **REF-NTIA-SBOM-HOWTO**
