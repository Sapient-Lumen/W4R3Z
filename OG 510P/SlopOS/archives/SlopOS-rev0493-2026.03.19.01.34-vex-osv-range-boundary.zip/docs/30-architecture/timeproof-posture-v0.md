# Timeproof posture v0 (evidence-first, lower-bound-only, Roughtime-only export)

Purpose: pin the Phase-1 meaning of **D-TIMEPROOF** so authenticated time does not drift into an ambient clock-setting channel,
a hidden scheduler dependency, or an ever-growing “secure time protocol” surface in the privileged core.

This posture is intentionally narrower than RFC-0090: it pins the **v0 exported/evidence surface** and the allowed effect on
security time, not the full implementation strategy inside the user-space time portal.

## Posture (v0)

1) **Observational export only.** Producing **CH-TIMEPROOF v0** MUST be observational: exporting a proof artifact is evidence emission, not a privileged state transition. Sampling may feed portal-local bookkeeping, but CH-TIMEPROOF export itself MUST NOT directly configure unrelated system state.
2) **Lower-bound only.** If a verified timeproof is used for security decisions, it MAY only advance the monotonic `secure_time_lb` / `secure_time_now` lower-bound mechanism described by RFC-0090 and **I-TIMEPROOF-2**. It MUST NOT directly step app-visible realtime backward, rewrite scheduler state, or bypass expiry/anti-rollback policy through an implicit “set the clock” path. Guest-visible paravirtual clocks, clocksource/RTC policy, and disruption markers under `ext.microvm` remain observational inputs rather than CH-TIMEPROOF replacements (`microvm-time-source-posture-v0.md`; `microvm-clock-disruption-posture-v0.md`).
3) **Roughtime-only portable proof in v0.** Phase 1 accepts portable/exported CH-TIMEPROOF artifacts only for `kind="roughtime"` with `authority.kind="pubkey_hash"`. Any `kind="other"` / `authority.kind="other"` value is reserved for a future RFC and MUST reject fail-closed in v0.
4) **NTS is local discipline, not a second export format.** NTS-secured NTP (RFC 8915) MAY be used inside the user-space time portal for steady-state discipline, but in v0 it does not become a second CH-TIMEPROOF proof kind and does not by itself satisfy evidence-bearing workflows. Any future device-signed/NTS-derived portable proof format requires a new RFC.
5) **Requests stay non-ambient.** `portal.clock.timeproof.sample` MUST bind `timereq_digest = digest(CH-TIMEREQ v0)`, and CH-TIMEREQ MUST remain endpoint-free: no DNS names, IPs, or server identities travel in the request descriptor. Authority/server selection stays in portal policy.
6) **Network/time authority stays killable.** Sampling requires both `cfg.params.lane.portal.clock` and `cfg.params.lane.timeproof`; missing/false values MUST deny fail-closed. Any network activity needed for timeproof sampling flows through explicit leased networking (D-NETLEASE), never ambient NTP/DNS.
7) **No scheduler coupling.** A successful timeproof sample MUST NOT implicitly enqueue jobs, revive background presence, widen an inhibit, or satisfy timer/alarm requests. D-TIMEPROOF is evidence + security-time posture, not a scheduler or persistence seam.
8) **Export remains bounded and privacy-scoped.** CH-TIMEPROOF and CH-TIMEREQ metadata (authority ids, nonce hashes, RTT, coarse receive monotonic counters) are potentially sensitive. Export MUST remain bounded and scoped by observation policy / receipt hygiene.

## Phase 1 non-goals (explicitly deferred)

- No privileged-core time-sync protocol or ambient clock-setting API.
- No second portable CH-TIMEPROOF proof kind beyond `roughtime`.
- No NTS-derived device-signed “time state receipt” in v0.
- No timeproof-driven scheduler/alarm semantics.
- No claim that authenticated time is required in all profiles; D-TIMEPROOF remains optional and profile-shaped.

## Wiring

- Decision surface: `decision-map.md` → **D-TIMEPROOF**.
- Schema surfaces:
  - `timeproof-request-schema-v0.md` → **CH-TIMEREQ v0**.
  - `time-proof-schema-v0.md` → **CH-TIMEPROOF v0**.
- Portal / ACP surfaces:
  - `portal-family-registry.md` → `portal.clock.*`.
  - `docs/70-llm-control/acp-action-kind-registry.md` → `portal.clock.timeproof.sample`.
  - `docs/70-llm-control/acp-validator-semantics.md` → **PO-ACP-TIMEPROOF-SAMPLE**.
- Assurance hooks:
  - Invariants: **I-TIMEREQ-1**, **I-TIMEPROOF-1**, **I-TIMEPROOF-2**, **I-TIMEPROOF-3**.
  - Proof obligations: **PO-TIMEREQ-VALIDATE**, **PO-TIMEPROOF-VALIDATE**, **PO-TIMEPROOF-VERIFY**, **PO-TIMEPROOF-APPLY**, **PO-TIMEPROOF-ENF**.
- Related postures:
  - `security-time-posture-v0.md` (D-TIME pins security time as policy-local monotonic lower-bound state rather than ambient wall-clock/admin folklore).
  - `nondet-posture-v0.md` (no ambient time/RNG; explicit Clock handles).
  - `microvm-clock-disruption-posture-v0.md` (guest-visible VM clocks under `ext.microvm` are observational only; disruption invalidates local refinement instead of becoming proof/lease authority).
  - `network-lease-posture-v0.md` (no ambient networking/DNS).
  - `observation-export-posture-v0.md` (bounded, pull-only export discipline).
  - `namecert-time-boundary-v0.md` (verified time may change future D-NAMECERT admission outcomes, but does not auto-detach already-materialized live bindings).
- Policy kill switches:
  - `cfg.params.lane.portal.clock`
  - `cfg.params.lane.timeproof`
- CI drift gate: `tools/check_timeproof_posture.py` (EVID-2026-244).

## References

- REF-ROUGHTIME-PROTOCOL
- REF-ROUGHTIME-IETF
- REF-RFC-8915
