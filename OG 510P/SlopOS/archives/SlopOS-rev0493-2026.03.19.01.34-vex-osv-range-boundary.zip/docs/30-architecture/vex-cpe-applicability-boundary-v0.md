# VEX CPE/applicability boundary v0 (imported CPE names and applicability expressions stay evidence, not native install-scope authority)

Purpose: pin the Phase-1 meaning of **CPE-shaped product targeting imported through VEX/advisory evidence** across **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, and **D-POLICY** so CPE names, match strings, and applicability-language expressions do not quietly become a portable same-product oracle, install-target selector, or applicability-closure rule.

Entropy cost justification: the archive already pins `vuln_id`, `purl`, component `version`, advisory priority signals, and remediation text to evidence semantics only. The remaining cheap-but-dangerous ambiguity is the widely reused product-targeting layer underneath many advisories: CPE names and CPE applicability expressions. If left loose, one tool will start treating a matched CPE as “this is definitely the same product”, another will use applicability logic as “therefore install/deny this cohort”, and a third will smuggle platform targeting or completeness assumptions in through external advisory docs. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema or a native product-targeting engine.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** may still point at richer external advisory material through `external_doc_aref`.
- Imported CSAF / CVE / vendor advisories may still carry CPE names, CPE match strings, or CPE applicability expressions.
- **CH-UPD v0** and **CH-BOOT v0** still carry the only native install/boot cohort meaning.
- **Verifier-local policy/tooling** may still evaluate imported CPE targeting logic, but that logic stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **Imported CPE names are targeting evidence only.**
   - A CPE name or match string records one imported product-labeling claim from an outside ecosystem.
   - Phase 1 therefore treats CPE strings as descriptive targeting evidence, not as a native SlopOS product identity root or same-product oracle.
   - Matching CPE text across advisories, SBOMs, release bundles, or owner-local inventories carries no portable same-product meaning by itself.

2) **Imported applicability expressions do not become native install or boot scope.**
   - CPE Applicability Language can express logical combinations of CPE names to describe IT platforms.
   - Phase 1 may ingest those exact bytes as evidence through external advisory material, but it does **not** elevate them into a native “this CH-UPD applies”, “this CH-BOOT is ineligible”, “this component is definitely present”, or “this product set is complete” rule.
   - Any evaluation of applicability expressions remains verifier-local policy over imported evidence rather than portable archive semantics.

3) **Exact carrier meaning still rides on digests and reviewed cohorts.**
   - `target_root_digest`, `cfg_digest`, and exact adjunct digests on CH-UPD / CH-BOOT remain the only portable install/boot cohort meaning.
   - A matching CPE name, a vulnerable-platform list, or a satisfied applicability expression does not widen or redefine what those carriers install or boot.
   - Companion `update-evidence-subject-boundary-v0.md` already pins that supporting evidence may appraise the pinned cohort but may not redefine the subject.

4) **Imported CPE targeting does not create a native applicability closure or completeness claim.**
   - A CPE match in one advisory plus one linked inventory does not prove that every relevant component/platform is covered.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that several exact SBOM/VEX artifacts do not jointly define one native vulnerability/applicability closure.
   - This boundary further pins that richer CPE targeting syntax is still evidence only; it does not become the hidden closure engine for those artifacts.

5) **Imported CPE targeting does not become a native remediation, suppression, or priority selector.**
   - A satisfied CPE match or applicability expression does not by itself mean “suppress this finding”, “this update is the fix”, “block boot”, “install now”, or “this advisory outranks another one”.
   - Companion `vex-remediation-selection-boundary-v0.md`, `vex-priority-signal-boundary-v0.md`, and `vex-vulnerability-identity-boundary-v0.md` already keep remediation, priority, and advisory identity semantics on explicit local seams.
   - CPE targeting must not become the back door that recreates those policy decisions implicitly.

6) **No portable CPE normalization, dictionary lookup, or matching engine exists in v0.**
   - CPE Naming defines well-formed names and bindings; CPE Applicability Language builds logical platform statements on top of those names.
   - Phase 1 still adds no native CPE dictionary query, wildcard expansion, vendor/product normalization, edition/language normalization, logical-expression evaluator, or latest-dictionary-wins rule.
   - If an owner wants those capabilities, they remain verifier-local tooling under explicit policy rather than privileged-core semantics.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported product-targeting evidence fits with existing VEX/update/boot seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native CPE identity, alias, or same-product registry.
- No native CPE applicability evaluator on CH-VEX / CH-UPD / CH-BOOT.
- No rule that imported CPE targeting selects an update cohort, blocks boot, proves applicability closure, or suppresses a finding.
- No portable CPE dictionary / match-string / normalization service in the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but more expressive than our Phase-1 authority substrate:
- CPE Naming defines well-formed names and bindings for product identifiers.
- CPE Applicability Language builds logical statements over CPE names to describe IT platforms.
- Those capabilities are precisely why CPE is attractive in advisories and scanners — and precisely why it is too easy to let it quietly become hidden product identity, install-scope, or completeness authority if the seam is left loose.

Pinning the split now keeps SlopOS from inheriting “matched CPE means same thing everywhere” folklore just because external advisory ecosystems already rely on it heavily.

## Profile effect (A–D)

- **Secure workstation (A):** scanners may still consume vendor advisories with CPE targeting, but a matched CPE cannot silently suppress findings or choose updates.
- **Cloud micro-VM substrate (B):** fleet policy may use imported targeting evidence, but portable rollout/install meaning still stays on exact reviewed cohorts rather than advisory platform expressions.
- **Embedded / separation appliance (C):** offline verifiers stay small because they need not ship a portable CPE dictionary and applicability engine in the reviewed core.
- **Agent/automation OS (D):** agents may reason over imported advisory targeting, but they cannot smuggle “this CPE matched, therefore act” into native authority semantics without explicit local policy.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_cpe_applicability_boundary.py` keeps the split small and discoverable (**EVID-2026-498**).

## References

- **REF-CPE23-NAMING**
- **REF-CPE23-APPLICABILITY**
- **REF-OPENVEX-SPEC**
- **REF-CSAF-SPEC**
