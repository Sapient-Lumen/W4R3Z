# Verification verdict boundary v0 (consumer-local evaluation; no native verified-good / waiver plane)

Purpose: pin the Phase-1 meaning of **verification conclusions** across **D-PCP**, **D-SIGENV**, **D-TUF**, **D-ATOMICUPD**, and **D-TLOG** so the archive does not quietly overload signed evidence into a portable “verified-good”, “approved”, or “waived” control plane.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-PROV v0** answers *how these digests were produced*.
- **CH-SIGENV v0** answers *which exact payload digest was signed under local policy*.
- **D-TUF** answers *which repository metadata view is fresh and consistent enough to trust for fetching*.
- **CH-UPD v0** answers *which exact digest-bound deployment/config binding we intend to install*.
- **CH-TLOG v0** answers *which signed digests were anchored for audit evidence*.

## Posture (v0)

1) **Verification is a consumer-local evaluation of exact evidence under explicit local policy.**
   - Phase 1 verification means evaluating exact digests, signatures, repository metadata, and optional transparency evidence against explicit local expectations.
   - The portable evidence inputs are the artifact bytes and their bound evidence objects; the conclusion only exists relative to the verifier’s roots, policy revision, and freshness assumptions.
   - A verifier result therefore does not become ambient truth merely because an artifact carries provenance, signatures, or transparency receipts.

2) **No native `verified-good`, waiver, or approval schema in v0.**
   - Phase 1 standardizes no native VSA/SVR/verification-summary/waiver schema family or equivalent portable verdict artifact.
   - The archive intentionally declines to make “pass”, “approved for install”, “policy exception granted”, or “safe for fleet” a first-class authority object.
   - Any future portable verdict or waiver surface must return RFC-first with explicit subjects, trust roots, freshness rules, conflict keys, commutativity rules, serialization boundary, and evidence.

3) **Third-party verification summaries remain imported evidence, not install authority.**
   - Ecosystem formats that summarize or delegate verification work are useful as imports and audit records.
   - They may help a deployment cache expensive checks or rely on an external reviewer, but they do not by themselves authorize install, boot, secret release, or admission in SlopOS.
   - If retained, they travel as explicit evidence attachments or handoff artifacts and stay subordinate to local verifier policy.

4) **Verification conclusions are scoped to verifier roots, policy, and freshness.**
   - A recorded pass is only meaningful together with the exact verifier trust roots, expected builders/issuers, policy version, and time/freshness context that produced it.
   - Key rotation, policy changes, expiry windows, rollback floors, or a different repository view may invalidate an earlier conclusion without changing the underlying artifact digest.
   - Phase 1 therefore refuses to treat an old “verified” bit as a portable evergreen property of an artifact.

5) **TUF target verification stays client-local; release/update labels do not inherit verification truth.**
   - Repository metadata and target verification remain verifier/client behavior under **D-TUF** and local policy.
   - Release labels, package names, channel names, and handoff slugs remain observational identifiers under `release-identity-boundary-v0.md`; they do not inherit “verified” meaning by association.
   - Likewise, **CH-UPD v0** remains digest-bound install intent only and does not become a cached verification or approval carrier.

6) **SCITT / transparency / attestation interop may carry reviewer or endorser statements, but application policy remains local.**
   - Transparency services, signed statements, and reviewer/endorser attestations are useful interoperability mechanisms.
   - Phase 1 may import or emit such artifacts through tooling, but their interpretation remains an application-level local-policy decision rather than privileged-core truth.
   - Optional registration, query, or receipt APIs remain tooling concerns and do not create a native verification-discovery plane.

7) **No portable verification-query, badge, feed, or latest-verified plane in v0.**
   - Phase 1 adds no native “is verified?”, “show policy verdict”, “latest verified release”, “track verification state”, or “feed me waivers” surface.
   - Dashboards, CI systems, and package ecosystems may expose those views externally, but they remain owner-local tooling rather than authority substrate semantics.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing evidence and update seams are interpreted.
   - Any future publication, acknowledgement, or waiver workflow must pay for its own RFC, conflict keys, serialization story, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No native verification-summary or policy-verdict schema.
- No portable waiver / suppression / exception object.
- No rule that a signature/provenance/transparency artifact is self-authenticating without a local verifier.
- No “approved by X” install shortcut where external reviewer statements automatically authorize use.
- No portable verification cache/query/watch API.
- No latest-verified or verified-channel semantics.

## Why this is worth pinning

The surrounding ecosystem is explicitly split:
- current SLSA build guidance says provenance only helps when a verifier checks it against trusted roots and expectations;
- SLSA’s Verification Summary Attestation documents a delegated verification-decision artifact, but that format is retired as a core SLSA attestation format;
- the in-toto attestation framework still defines a VSA predicate type that records a verification decision;
- TUF keeps target verification in the client/repository-security model rather than on package labels;
- SCITT allows statements from issuers, reviewers, or endorsers, but application-level verification policy still sits above the transparency substrate.

Pinning that split now prevents SlopOS from slowly reinventing a hidden trust-distribution or waiver system under the names of provenance, signing, update, or transparency.

## Profile effect (A–D)

- **Secure workstation (A):** security tools and vendors may publish verdicts, but local install/admission policy remains inspectable and killable.
- **Cloud micro-VM substrate (B):** fleet operators can cache or delegate verification work without turning third-party passes into silent admission authority.
- **Embedded / separation appliance (C):** verifiers can stay small and explicit; a prior “passed CI” badge never outruns local trust roots and rollback policy.
- **Agent/automation OS (D):** agents may consume external verification artifacts as evidence, but they cannot smuggle in “verified therefore do it” authority through badges, feeds, or waivers.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-PCP**, **D-SIGENV**, **D-TUF**, **D-ATOMICUPD**, **D-TLOG**.
- Adjacent meaning pins:
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/release-identity-boundary-v0.md`
- Engineering/application surfaces:
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `docs/60-engineering/update-repository-metadata-and-key-rotation.md`
- Assurance anchors:
  - **I-PROV-CHAIN-1**, **I-SIGENV-1**, **I-ATOMICUPD-1**.
  - **PO-PROV-BIND**, **PO-SIGENV-VERIFY**, **PO-UPD-VERIFY**, **PO-TLOG-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_verification_verdict_boundary.py` keeps the split small and discoverable (**EVID-2026-462**).

## References

- **REF-SLSA-VERIFYING-ARTIFACTS**
- **REF-SLSA-VSA-RETIRED**
- **REF-IN-TOTO-VSA**
- **REF-TUF-SPEC**
- **REF-SCITT-ARCH**
