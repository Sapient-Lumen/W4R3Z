# Verification-policy selection boundary v0 (policy stays explicit local input; no artifact-selected/default-policy plane)

Purpose: pin the **Phase 1** meaning of verification/appraisal policy around **D-POLICY**, **D-SIGENV**, **D-KEYLESS**, and **D-ATTEST** so evidence artifacts do not quietly choose, resolve, or fetch the policy that will judge them.

Entropy cost justification: `verification-verdict-boundary-v0.md`, `attestation-endorsement-boundary-v0.md`, `signature-trust-root-boundary-v0.md`, and `verification-material-discovery-boundary-v0.md` already pin evidence, endorsements/reference values, trust roots, and attachment discovery to explicit local meaning. The remaining ambiguity is **who selects the policy bundle / expectations / appraisal rules that evaluate that evidence**. One narrow boundary closes that gap without adding a new schema family, verifier protocol, or policy-discovery service.

## Posture (v0)

1) **Verification/appraisal policy remains explicit verifier-owner input.**
   - For attestation, RFC 9334 explicitly treats appraisal policy as something the Verifier Owner configures/programs/obtains for the verifier; it is not selected by the Evidence itself.
   - For supply-chain evidence, accepted verification meaning remains “check exact evidence against explicit local expectations / allowed builders / allowed issuers / allowed roots / allowed predicates”.
   - In SlopOS Phase 1, that means verification/appraisal policy stays an explicit local input under **D-POLICY**, **I-POLICY-1**, **I-POLICY-2**, **PO-POLICY-DETERMINISM**, and **PO-POLICY-NONAMP**.

2) **Evidence artifacts do not choose which policy is in force.**
   - **CH-SIGENV**, **CH-PROV**, **CH-ATTEST**, **CH-ATTESTPACK**, **CH-SBOM**, **CH-VEX**, and similar evidence may be *checked against* policy, but they do not get to say which **CH-POLICY** / **CH-POLICYHANDLE** / verifier expectation set must be used.
   - Bundle labels, policy IDs, OCI annotations, repo names, issuer URLs, release labels, or attestation predicate fields therefore do **not** select policy by themselves.
   - Phase 1 adds no portable “artifact-selected policy”, “policy ID inside the bundle chooses evaluation semantics”, or “issuer/repository chooses the matching policy automatically” rule.

3) **Policy resolution/discovery/remapping are tooling-only and policy-killable.**
   - Ecosystem tools may choose to resolve policy from a TUF repository, a local directory, a cluster object, or other deployment-local configuration.
   - In SlopOS, that behavior remains **tooling-only / owner-local deployment plumbing**, not substrate meaning for **D-SIGENV** or **D-ATTEST**.
   - A deployment may package exact **CH-POLICY** artifacts, exact **CH-POLICYHANDLE** descriptors, or exact policy manifests through existing content-addressed seams, but there is no native policy-discovery / policy-ID resolution / latest-policy lookup plane in Phase 1.

4) **Changing policy affects future verification, not past evidence.**
   - Replacing a local policy bundle, changing a policy directory, changing a cluster admission policy, or repointing a TUF-style policy source MAY change how future verification is performed.
   - It MUST NOT retroactively rewrite old signed evidence, mutate prior receipts, or turn a past verification result into a portable “still approved because the default policy changed” verdict.
   - Prior decisions remain bound to the exact policy digest/handle recorded at the time, or remain unbound if a profile chose not to record one.

5) **Recorded policy identity is an audit anchor, not a grant.**
   - When a verifier/validator records `digest(CH-POLICY v0)` or `digest(CH-POLICYHANDLE v0)`, that digest is an observational handle naming the semantics in force.
   - It is **not** a bearer grant, not a delegation token, and not a proof that another verifier must reach the same result unless it also adopts the same explicit policy inputs.
   - This keeps **CH-POLICY** / **CH-POLICYHANDLE** consistent with `verification-verdict-boundary-v0.md`: policy identity can be exported as evidence, but portable approval authority does not arise from merely naming a policy.

6) **Sealed compat remains honest.**
   - Compat/import paths that auto-load policy from host config directories, registry annotations, environment variables, or ambient TUF / OCI metadata must remain killable by policy and must not create hidden authority via paths, env vars, or implicit network fetch.
   - A compat path that cannot verify without ambient policy discovery must fail closed for portable Phase 1 semantics.

7) **No native policy inventory, query, or watch plane in v0.**
   - Phase 1 adds no native “which policies are available?”, “fetch latest policy for this artifact”, “watch policy channel”, “discover policy by issuer/repository”, or “ask the registry / forge / attester which policy to use” service.
   - Exact policy artifacts may travel through existing explicit seams (release bundles, **CH-AREF**, provisioning payloads, or deployment-local config), but discovery remains out-of-band and killable.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary introduces no new portal family, no new ACP kind, and no conflict-key namespace.
   - It only narrows what policy selection and policy discovery are allowed to mean.

## Phase 1 non-goals (explicitly deferred)

- No native policy-discovery / policy-ID resolution / latest-policy API in Phase 1.
- No artifact-selected policy semantics for signatures, provenance, attestations, SBOMs, or VEX.
- No portable TUF-policy repository client in privileged verification code.
- No registry / forge / issuer / repo-owner lookup plane for choosing verification policy.
- No portable claim that changing default policy retroactively rewrites prior verification evidence.
- No new workflow / ACP / conflict-key family in v0.

## Why this boundary exists

Without this pin, verification policy almost always drifts in four expensive directions:

- **Evidence starts choosing its judge.** Bundle IDs, issuer hints, or repo names quietly select which policy gets applied.
- **Deployment plumbing becomes substrate meaning.** Local directories, cluster policy objects, or TUF-backed policy sources silently become portable verifier semantics.
- **Policy updates rewrite history.** A changed policy source gets treated as if it can retroactively approve or revoke already-recorded evidence.
- **Ambient discovery erodes sealed compat.** Tool defaults, env vars, or registry lookups become hidden authority channels that are hard to review and harder to disable.

Pinning the seam now keeps all four product shapes honest:
- **Secure workstation (A):** operator review stays explicit about which expectation set is being applied rather than inheriting per-tool defaults.
- **Cloud micro-VM / hosted substrate (B):** admission/control planes can pin cluster-local policy without letting artifact annotations or repo naming conventions choose the judge.
- **Embedded / separation-kernel-ish appliance (C):** appliances can ship tiny built-in policy handles and reject all ambient policy discovery.
- **Agent / automation OS (D):** agents may carry policy artifacts for audit, but they cannot smuggle “use this policy” selectors inside the evidence they want admitted.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-POLICY**, **D-SIGENV**, **D-KEYLESS**, **D-ATTEST**.
- Adjacent seams:
  - `docs/30-architecture/policy-bundle-schema-v0.md`
  - `docs/30-architecture/policy-handle-schema-v0.md`
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/attestation-posture-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `rfcs/0028-veto-only-policy-bundles-for-automation.md`
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-POLICY-1**, **I-POLICY-2**, **I-SIGENV-1**, **I-ATTEST-1**
  - **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**, **PO-SIGENV-VERIFY**, **PO-ATTEST-VERIFY**
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_verification_policy_selection_boundary.py` keeps the boundary small and discoverable (**EVID-2026-472**).

## References

- REF-RATS-RFC9334
- REF-SLSA-VERIFYING-ARTIFACTS
- REF-DOCKER-ATTEST
- REF-SIGSTORE-POLICY-CONTROLLER-API
