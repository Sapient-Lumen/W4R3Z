# VEX statement-key boundary v0 (`statements[]` stays an unordered exact-key snapshot, not a native history/conflict-resolution plane)

Purpose: pin the Phase-1 meaning of **repeated or contradictory CH-VEX statements** across **D-VEX**, **D-POLICY**, and **D-AREF** so one artifact does not quietly grow a native “latest statement wins”, timestamp-precedence, or within-document supersession language.

Entropy cost justification: the archive already pins CH-VEX as one bounded exploitability snapshot for one exact subject digest, but real VEX ecosystems are richer than that. OpenVEX defines a statement as the intersection of product, vulnerability, and status, treats statements as valid at a point in time, and shows document evolution by preserving earlier statements with explicit timestamps when a later document version is issued. CSAF likewise makes contradicting product-status groups within one vulnerability item invalid. Leaving normalized CH-VEX vague here invites expensive drift later: statement order starts acting authoritative, `issued_at_s` silently becomes “newest wins”, or duplicated/conflicting rows for the same scoped issue become a hidden local merge language. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** still carries one bounded `statements[]` list for one already-bound subject digest.
- **Exact statement-key uniqueness** is part of native CH-VEX meaning.
- **Richer history / supersession / multi-document reconciliation** remains verifier-local or imported evidence unless another seam explicitly admits more.

## Posture (v0)

1) **CH-VEX is one unordered bounded statement snapshot for one already-bound subject.**
   - A CH-VEX artifact still says: for this exact `subject.digest`, here is one bounded set of exploitability statements.
   - `statements[]` order is serialization only; Phase 1 does **not** import a native “first wins”, “last wins”, or “scan in order until a matching status appears” rule.

2) **One exact statement key carries at most one live native statement inside one CH-VEX artifact.**
   - For Phase 1, the exact native statement key is:
     - top-level `subject.digest`, plus
     - exact `vuln_id`, plus
     - exact component scope if present, otherwise the explicit whole-subject scope.
   - Component scope remains exact-keyed rather than fuzzy: if `component.content_digest` / `build_id` / `name` / `version` / `purl` bytes differ, they are different native keys unless some verifier-local policy deliberately correlates them.

3) **Duplicate or contradictory statements for one exact key are invalid; there is no native conflict-resolution rule.**
   - If one CH-VEX artifact carries two statements for the same exact native key, validators fail closed whether the rows are byte-identical duplicates or carry different `status`, `justification`, `action`, or timing fields.
   - Phase 1 deliberately adds no native “newer timestamp wins”, “more severe status wins”, “fixed beats affected”, or “under_investigation temporarily masks not_affected” rule.

4) **Statement timestamps remain evidence, not within-artifact precedence authority.**
   - `generated_at_s`, `issued_at_s`, and `expires_at_s` may inform local review/freshness policy.
   - Companion `vex-investigation-deferral-boundary-v0.md` already pins that those timing fields do not become a native hold/defer or grace-period selector.
   - This boundary further pins that they also do **not** become a native per-key precedence or reconciliation rule inside one CH-VEX artifact.

5) **History/supersession across advisory revisions stays outside CH-VEX v0 native meaning.**
   - OpenVEX and CSAF can model advisory evolution over time.
   - Phase 1 CH-VEX does **not** import a native document-version/history chain, statement tombstone, or per-key supersession protocol.
   - If a producer wants to publish a changed view, it publishes a new CH-VEX artifact digest or points at richer imported advisory evidence via **CH-AREF**.

6) **Verifier-local reconciliation is still allowed, but it stays local and explicit.**
   - A verifier may compare several CH-VEX artifacts, external advisories, or signed publication records and choose its own local precedence rules.
   - Companion `verification-policy-selection-boundary-v0.md` already pins that evidence does not choose which reconciliation policy is in force.
   - Companion `verification-verdict-boundary-v0.md` already pins that any resulting appraisal remains consumer-local rather than becoming a portable approval/suppression state.

7) **No fuzzy component merge rule leaks in through statement keys.**
   - Companion `vex-component-absence-boundary-v0.md` already pins that component matching/completeness stay verifier-local rather than riding on one naming convention.
   - This boundary further pins that CH-VEX native key uniqueness is based on the exact encoded component scope only; there is no native merge across `purl`, `name`, aliasing, or SBOM-derived component identity.

8) **Co-packaging multiple CH-VEX artifacts does not create a native multi-document precedence rule either.**
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that multiple exact SBOM/VEX artifacts do not become one applicability closure.
   - This boundary further pins that even when several CH-VEX artifacts are co-packaged, Phase 1 adds no native “latest artifact wins”, “prefer smaller scope”, or “prefer vendor-issued statement” rule.

9) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing VEX/policy/reference seams interpret repeated statements.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native “last statement wins” / timestamp-precedence rule inside `statements[]`.
- No native duplicate-row tolerance or dedup-by-keeping-one rule.
- No portable within-document history/supersession chain on CH-VEX.
- No native conflict-resolution ladder across `affected` / `fixed` / `not_affected` / `under_investigation`.
- No native fuzzy component merge rule for determining statement-key equality.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- OpenVEX defines a statement as product(s) + vulnerability + status, treats statements as valid at a point in time, and shows advisory evolution by preserving earlier statements when a later document version is issued.
- CSAF requires that the same product not appear in contradicting status groups for one vulnerability item.

Pinning that split now keeps SlopOS from quietly inheriting statement-order folklore, timestamp-precedence heuristics, or hidden merge logic on the native seam.

## Profile effect (A–D)

- **Secure workstation (A):** review tooling can compare advisories over time without turning one artifact’s internal row order into suppression authority.
- **Cloud micro-VM substrate (B):** fleet verifiers stay deterministic when multiple advisory producers or pipeline stages emit overlapping VEX material.
- **Embedded / separation appliance (C):** offline verifiers stay small because one CH-VEX artifact either has one exact statement per key or it is invalid.
- **Agent/automation OS (D):** agents cannot smuggle hidden “pick the latest row” heuristics into portable authority; any multi-artifact reasoning stays explicit policy.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-POLICY**, **D-AREF**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/vex-investigation-deferral-boundary-v0.md`
  - `docs/30-architecture/vex-component-absence-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/30-architecture/decision-map.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-POLICY-1**, **I-POLICY-2**, **I-AREF-1**.
  - **PO-VEX-VALIDATE**, **PO-VEX-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_statement_key_boundary.py` keeps the split small and discoverable (**EVID-2026-487**).

## References

- **REF-OPENVEX-SPEC**
- **REF-CSAF-SPEC**
