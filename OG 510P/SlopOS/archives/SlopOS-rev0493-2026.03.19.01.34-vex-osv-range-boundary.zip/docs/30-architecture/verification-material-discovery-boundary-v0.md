# Verification-material discovery boundary v0 (explicit artifact inputs only; no ambient sidecar/referrer discovery plane)

Purpose: pin the Phase-1 meaning of **verification-material discovery** across **D-SIGENV**, **D-KEYLESS**, **D-AREF**, and **D-NETLEASE** so signature verification does not quietly inherit neighboring-file lookup, registry-referrer chase, or “whatever bundle the tool found first” folklore.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-SIGENV v0** answers *which payload digest was signed*.
- **Supporting certificates / chains / transparency / timestamp material** answer *what exact evidence is available for verification*.
- **CH-AREF v0** answers *how exact supporting artifacts may be referenced by digest, with locators staying untrusted hints*.
- **Verifier-local policy** answers *which explicit verification-material artifacts are required, trusted, sufficient, and fresh enough*.

## Posture (v0)

1) **Verification consumes explicit artifact bytes plus explicit verification-material artifacts only.**
   - Phase 1 verification takes one exact artifact (or exact digest-bound subject) plus zero or more exact verification-material artifacts supplied explicitly by the caller, profile, bundle packaging, or local policy.
   - Distribution and discovery of those inputs are separate concerns; they do not become native substrate meaning merely because some ecosystem tool can auto-find them.
   - Exact bytes and digests remain authoritative; discovery paths and attachment mechanisms remain operational hints only.

2) **Neighboring-file / sidecar discovery is tooling-only, not native authority.**
   - Sigstore’s client guidance recommends that explicit user-supplied inputs take precedence and only then suggests trying sidecar names such as `{input}.sigstore.json` or `{input}.sigstore`.
   - Phase 1 standardizes **no portable sibling-file naming convention**, no automatic “same directory” bundle search, no hidden `.sig` / `.cert` / `.bundle` co-discovery rule, and no ambient filesystem walk for verification material.
   - If a tool chooses to support sidecar discovery locally, that remains owner-local UX above the authority substrate rather than reviewed platform semantics.

3) **OCI attachment / referrer discovery is tooling-only and policy-killable.**
   - OCI registries and related tooling now support attaching signatures, attestations, SBOMs, and other metadata artifacts via `subject` links and referrers APIs.
   - Phase 1 does **not** import `GET /v2/<name>/referrers/<digest>`, fallback-tag chase, registry attachment enumeration, or artifact-type filtering as native verification meaning.
   - Any registry/referrer fetch remains explicit tooling above the substrate and, if networked, must use already-pinned **D-NETLEASE** controls. Turning it off must not change the meaning of locally supplied evidence.

4) **Bundle/attachment presence does not define “the right” verification materials.**
   - A Sigstore bundle may be “everything required to verify a signature” for one ecosystem policy profile, and OCI referrers may enumerate associated artifacts, but neither fact creates a universal “latest applicable bundle”, “first discovered bundle wins”, or “registry attachment set is authoritative” rule for SlopOS.
   - Explicit user-supplied bytes, explicit profile wiring, or exact digest-bound packaging MAY be preferred; local policy still decides what is required and how conflicting candidates are handled.
   - Discovery order, tie-breaking, and fallback behavior remain verifier-local policy/UX rather than substrate meaning.

5) **Supporting material may be packaged or referenced, but discovery stays out-of-band and digest-bound.**
   - Certificates, intermediate allowlists, transparency entries, timestamp responses, and Sigstore/OCI bundles may be carried as exact artifacts (for example through **CH-AREF** or release bundles) and verified by digest.
   - Their presence does not imply that verifiers must chase more material, reinterpret the artifact subject, or consult the network to finish verification.
   - A locator, sibling filename, registry URL, referrers response, or repo attachment listing therefore remains a hint about *where exact bytes might be found*, not portable authority in itself.

6) **No native verification-material inventory, query, or watch plane in v0.**
   - Phase 1 adds no `list signatures`, `discover bundles`, `watch new referrers`, `find best verification materials`, or `refresh attachments` surface.
   - It also adds no standard local cache, mirror, or attachment database that outruns explicit verifier inputs.
   - Any future discovery/query surface must return RFC-first with explicit trust model, attachment subject rules, kill switches, conflict keys, commutativity/serialization story, and evidence hooks.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing signature/evidence/reference/network seams are interpreted.
   - Any future attachment publication, referrer synchronization, sidecar import, or bundle watch workflow must pay for its own RFC, conflict keys, serialization boundary, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No portable `{input}.sigstore.json` / `{input}.sigstore` / sibling-sidecar discovery contract.
- No native OCI referrers / fallback-tag / registry-attachment enumeration plane.
- No universal discovery order or “best bundle” selection rule.
- No machine-global verification-material cache authority.
- No rule that attached or discovered bundles outrun explicit verifier-local policy.

## Why this is worth pinning

The surrounding ecosystem is explicitly split:
- the Sigstore bundle format describes a portable object containing signature content plus verification material;
- the Sigstore client spec says verification consumes explicit artifact + bundle + root inputs, says the **distribution of those inputs is out of scope**, and only *recommends* a CLI-side discovery order where explicit user inputs win before implicit sidecar lookup;
- OCI distribution now standardizes a referrers API for discovering artifacts associated to a manifest digest, including filtering and fallback-tag behavior in some client flows.

Pinning that split now prevents SlopOS from slowly reinventing a hidden sibling-file probe, registry crawler, or “whatever bundle the tool happened to find” authority plane under the names of signature verification or interop convenience.

## Profile effect (A–D)

- **Secure workstation (A):** local verification stays inspectable; users may carry explicit sidecars or bundles without turning the desktop into an ambient registry/referrer client.
- **Cloud micro-VM substrate (B):** fleet tooling may mirror or fetch attachments externally, yet verifier meaning remains local and explicit rather than “whatever the registry currently lists”.
- **Embedded / separation appliance (C):** offline verification stays small and deterministic; exact packaged evidence can ship with the image without implying a live attachment-discovery protocol.
- **Agent/automation OS (D):** agents may reason over explicit bundles/attachments, but they cannot smuggle in filesystem or registry search authority through implicit discovery order.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-AREF**, **D-NETLEASE**.
- Adjacent meaning pins:
  - `docs/30-architecture/signature-envelope-posture-v0.md`
  - `docs/30-architecture/signature-envelope-schema-v0.md`
  - `docs/30-architecture/artifact-resolution-posture-v0.md`
  - `docs/30-architecture/signature-trust-root-boundary-v0.md`
  - `docs/30-architecture/keyless-issuer-discovery-boundary-v0.md`
- Engineering / profile surfaces:
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`
- Assurance anchors:
  - **I-SIGENV-1**, **I-KEYLESS-1**, **I-AREF-1**.
  - **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**, **PO-AREF-VERIFY**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_verification_material_discovery_boundary.py` keeps the split small and discoverable (**EVID-2026-471**).

## References

- **REF-SIGSTORE-BUNDLE**
- **REF-SIGSTORE-CLIENT-SPEC**
- **REF-OCI-DISTRIBUTION-REFERRERS**
