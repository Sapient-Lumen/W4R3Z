# VEX OSV range boundary v0 (imported OSV package/range semantics stay evidence, not native version authority)

Purpose: pin the Phase-1 meaning of **OSV-shaped affected-package / ecosystem / range fields imported through VEX/advisory evidence** across **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, and **D-POLICY** so external OSV records do not quietly become a portable same-component oracle, version-ordering engine, applicability closure, or update-selection rule.

Entropy cost justification: the archive already pins imported `purl`, component/advisory `version`, CPE targeting, remediation text, advisory references, and priority signals to evidence semantics only. The remaining cheap-but-dangerous ambiguity is the compact package-range language carried by OSV: `affected[].package`, `ecosystem`, `name`, optional `purl`, `ranges[]`, `events`, and enumerated `versions`. If left loose, one verifier will treat OSV range evaluation as a native “is this definitely the same component?” oracle, another will let an `introduced`/`fixed` pair choose an update target, and a third will smuggle ecosystem-specific version ordering into the privileged core by accident. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema family or a native advisory database.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** may still point at richer external advisory material through `external_doc_aref`.
- Imported **OSV** records may still carry affected `package`, `ecosystem`, `name`, optional `purl`, `versions`, and `ranges[].events` fields.
- **CH-UPD v0** and **CH-BOOT v0** still carry the only native install/boot cohort meaning.
- **Verifier-local policy/tooling** may still parse or evaluate imported OSV records, but that evaluation stays explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **Imported OSV package identity is targeting evidence only.**
   - In OSV, an `affected[].package` object identifies a package using ecosystem-specific `ecosystem` and `name` fields, with optional `purl`.
   - Phase 1 therefore treats those fields as descriptive advisory targeting evidence, not as a native SlopOS component identity root or same-component oracle.
   - Matching OSV package labels across advisories, SBOMs, release bundles, or owner-local inventories carries no portable same-component meaning by itself.

2) **Imported OSV ranges and version lists do not become a native version-ordering plane.**
   - OSV `versions` lists and `ranges[].events` are ecosystem-shaped, and unsupported ecosystems may have to enumerate versions rather than rely on compact range forms.
   - Phase 1 may ingest those exact bytes as evidence through external advisory material, but it does **not** elevate them into a native `newer_than`, `fixed_by_successor`, `same_package`, or “this version is definitely affected/not affected” rule.
   - Any range expansion, ordering, normalization, or matching remains verifier-local policy over imported evidence rather than portable archive semantics.

3) **Imported OSV range evaluation does not redefine install or boot subjects.**
   - `target_root_digest`, `cfg_digest`, and exact adjunct digests on CH-UPD / CH-BOOT remain the only portable install/boot cohort meaning.
   - An OSV package match, one enumerated affected version, or a satisfied `introduced` / `fixed` / `last_affected` / `limit` range does not widen or redefine what those carriers install or boot.
   - Companion `update-evidence-subject-boundary-v0.md` already pins that supporting evidence may appraise the pinned cohort but may not redefine the subject.

4) **Imported OSV events do not become a native remediation or successor-target selector.**
   - `introduced`, `fixed`, `last_affected`, and `limit` are useful imported advisory boundaries.
   - They do **not** by themselves mean “install this successor”, “this exact CH-UPD is the fix”, “block boot until version X”, or “suppress the finding because the target is beyond this range”.
   - Companion `vex-remediation-selection-boundary-v0.md` already keeps update-choice meaning on explicit CH-UPD / TUF / repository-local policy seams.

5) **Imported OSV records do not create a native applicability, suppression, or completeness closure.**
   - Multiple `affected[]` entries, multiple ecosystems, multiple repositories, or one expanded `versions` list plus one linked inventory do not jointly define a native closure rule.
   - Companion `sbom-vex-evidence-set-boundary-v0.md` already pins that several exact SBOM/VEX artifacts do not jointly define one native vulnerability/applicability closure.
   - This boundary further pins that richer OSV package/range syntax is still evidence only; it does not become the hidden closure engine for those artifacts.

6) **No portable OSV evaluator, ecosystem database, or alias map exists in v0.**
   - Phase 1 adds no native OSV ecosystem registry, range-expansion service, package-name normalization table, repository-selection rule, or alias map for package labels.
   - If an owner wants those capabilities, they remain verifier-local tooling under explicit policy rather than privileged-core semantics.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported OSV advisory semantics fit with existing VEX/update/boot seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native OSV package identity, ecosystem registry, or same-component oracle.
- No native OSV range evaluator on CH-VEX / CH-UPD / CH-BOOT.
- No rule that imported OSV `introduced` / `fixed` / `last_affected` / `limit` events select an update cohort, block boot, or suppress a finding.
- No portable OSV range-expansion service, ecosystem database, or package-alias map in the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but more expressive than our Phase-1 authority substrate:
- OSV package identity is ecosystem-shaped (`ecosystem` + `name`, optionally `purl`).
- OSV range handling is ecosystem-specific enough that unsupported ecosystems may have to enumerate concrete `versions` instead.
- That flexibility is precisely why OSV is practical in advisory databases — and precisely why it is too easy to let it quietly become hidden same-component, version-ordering, or update-choice authority if the seam is left loose.

Pinning the split now keeps SlopOS from inheriting “OSV says this version is fixed, therefore install that release” folklore just because external advisory tooling already reasons that way.

## Profile effect (A–D)

- **Secure workstation (A):** workstation tooling may still import OSV advisories, but package/range evaluation cannot silently suppress findings or choose updates.
- **Cloud micro-VM substrate (B):** fleet policy may still consume OSV material, but portable rollout/install meaning still stays on exact reviewed cohorts rather than advisory version-range logic.
- **Embedded / separation appliance (C):** offline verifiers stay small because they need not ship a portable ecosystem-specific version solver in the reviewed core.
- **Agent/automation OS (D):** agents may reason over imported OSV package/range evidence, but they cannot smuggle “OSV says fixed after X” into native authority semantics without explicit local policy.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-AREF**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`
  - `docs/30-architecture/sbom-purl-identity-boundary-v0.md`
  - `docs/30-architecture/sbom-component-version-boundary-v0.md`
  - `docs/30-architecture/vex-remediation-selection-boundary-v0.md`
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_osv_range_boundary.py` keeps the split small and discoverable (**EVID-2026-500**).

## References

- **REF-OSV-VERSIONS**
- **REF-OSV-SCHEMA**
- **REF-PURL-SPEC**
