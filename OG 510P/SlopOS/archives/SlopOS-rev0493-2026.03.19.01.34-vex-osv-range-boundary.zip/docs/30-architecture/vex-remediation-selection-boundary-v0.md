# VEX remediation-selection boundary v0 (`fixed` / action text stay evidence, not a native patch-plan selector)

Purpose: pin the Phase-1 meaning of **remediation-shaped VEX evidence** across **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-TUF**, and **D-AREF** so a `status == "fixed"` statement or one remediation/action note cannot quietly become a portable update target, minimum-safe-version oracle, or patch-plan language.

Entropy cost justification: the archive already pins CH-VEX as digest-bound exploitability evidence and CH-UPD as digest-bound install intent, but real VEX ecosystems still carry remediation hints, fixed-status publication cadence, version labels, and richer CSAF/CycloneDX advisory links. Leaving that relationship unstated invites expensive drift later: one VEX statement starts acting like “install this release”, “anything older is unsafe”, or “this advisory selects the right patch plan”. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** may carry `status == "fixed"` and bounded remediation/action text.
- **CH-UPD v0** still carries the only native install target meaning.
- **Verifier-local / repository-local policy** may relate those artifacts, but the relation is not portable merely because both artifacts are present.

## Posture (v0)

1) **`fixed` is evidence about the already-bound subject, not a native successor selector.**
   - A CH-VEX statement with `status == "fixed"` says the producer claims the already-bound subject version contains a fix for the named vulnerability.
   - That statement may reduce scanner noise or support release-readiness review for that exact subject.
   - Phase 1 does **not** import a native rule that this identifies the next install target, the minimum acceptable version, or the preferred successor release for some other subject.

2) **Remediation/action text is advisory evidence, not a portable patch-plan language.**
   - Bounded `action` text on CH-VEX remains human-oriented remediation context.
   - It may inform owner-local triage or release notes, but it does not become an executable workflow, ACP action, package-manager instruction, or automatic update recipe.
   - If tooling wants actionable rollout instructions, that meaning must live on explicit update/repository/workflow seams rather than inside CH-VEX prose.

3) **Version labels and product identifiers inside VEX stay observational for remediation selection.**
   - `subject.name`, `subject.version`, component `name` / `version` / `purl`, and similar labels may help operators understand a statement.
   - They do **not** become a native version-ordering, semantic-version comparison, “newer-is-safe”, or minimum-patched-version rule on D-VEX itself.
   - Exact update/install authority still lives on digest-pinned CH-UPD / CH-BOOT / TUF-selected artifacts, not on advisory labels.

4) **No automatic join from VEX evidence to repository/update selection in v0.**
   - A verifier or repository may explicitly consult both CH-VEX and CH-UPD / TUF metadata, but Phase 1 adds no native rule that `fixed` or remediation text chooses one CH-UPD, one TUF target, one channel, or one rollout cohort.
   - Companion `verification-material-discovery-boundary-v0.md` already pins that discovering more evidence is explicit and killable rather than ambient.
   - Companion `verification-policy-selection-boundary-v0.md` already pins that appraisal policy stays verifier-local rather than being selected by artifact contents.

5) **Cross-subject upgrade advice stays imported evidence unless another seam admits it.**
   - External OpenVEX / CSAF / CycloneDX documents may talk about remediation, version ranges, product trees, or fixed versions across multiple product identifiers.
   - Those richer relations may inform a verifier or operator, but Phase 1 does **not** promote them into a native cross-subject upgrade-selection grammar on CH-VEX / CH-UPD.
   - If SlopOS later wants portable remediation planning, that must return RFC-first as a separate decision surface.

6) **Each selected artifact still verifies on its own seam.**
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds the exact subject digest the verifier cares about.
   - **PO-UPD-VERIFY** and **PO-BOOT-VERIFY** still answer install/boot cohort integrity for the exact digests already pinned on those carriers.
   - **PO-AREF-VERIFY** still answers whether an attached external advisory reference resolves to the exact imported document expected.
   - No portable “install this fix” verdict is created merely by co-packaging VEX evidence with update metadata.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing exploitability/update/repository/evidence seams interpret remediation-shaped VEX fields.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native patch-plan / remediation-selection / minimum-safe-version grammar on CH-VEX.
- No rule that `status == "fixed"` selects a successor CH-UPD, TUF target, or rollout cohort.
- No semantic-version / range / newest-wins ordering on VEX product labels.
- No executable workflow / ACP / package-manager instruction language hidden inside VEX remediation text.
- No automatic import of CSAF remediation/product-tree semantics or CycloneDX/OpenVEX fixed-version relations into the privileged core.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but deliberately richer than our Phase-1 authority substrate:
- OpenVEX defines `fixed` as meaning the listed product versions contain a fix, and requires an `action_statement` for `affected`; that is excellent evidence, but it is still statement-shaped advisory data rather than an OS-native install-target selector.
- OpenVEX’s sample evolution shows new VEX documents tracking advisory status as knowledge changes, which is a strong signal that publication cadence and product-version advice belong to the advisory layer rather than to a single native update object.
- CSAF is explicitly about structured information on products, vulnerabilities, and the status of impact and remediation among interested parties; that richness is valuable, but it also means remediation planning is broader than the small digest-first authority substrate we want in Phase 1.

Pinning that split now keeps SlopOS from quietly inheriting “a fixed-status advisory or remediation note chooses the patch you should install” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** vendors may publish VEX with fixed-status and mitigation guidance without turning advisory text into ambient updater behavior.
- **Cloud micro-VM substrate (B):** fleet policy may combine advisories with explicit rollout logic, but `fixed` does not silently select the image digest or cohort.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can require exact CH-UPD / TUF targets instead of importing version-range reasoning from advisories.
- **Agent/automation OS (D):** agents may read richer advisories, but they cannot smuggle “this VEX says fixed, therefore pick that update” into portable authority.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-TUF**, **D-AREF**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/decision-map.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-TUF-1**, **I-AREF-1**.
  - **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-TUF-VERIFY**, **PO-AREF-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_remediation_selection_boundary.py` keeps the split small and discoverable (**EVID-2026-484**).

## References

- **REF-OPENVEX-SPEC**
- **REF-CISA-VEX-MINREQ**
- **REF-CSAF-ISO**
