# Decision map (major branches + decision evidence)

Each D-* is an RFC topic; once evidence exists it becomes an ADR.
Rule: decisions that change claims, interfaces, or TCB must update registries.

Drift gate: `tools/check_decision_map_refs.py` enforces that any `D-...` identifier referenced in the `docs/` tree has a corresponding entry in this map (prevents orphan decision ids and keeps the decision→evidence surfaces discoverable).

Related drift gate: `tools/check_assurance_token_refs.py` enforces registry-closure for A-/C-/I-/PO- references across repo markdown (keeps decision→invariant/PO/evidence chains coherent under LLM edits).

Related index: `posture-index.md` enumerates v0 posture docs (small meaning pins) so Phase-1 posture decisions remain discoverable.

## D-ARCH: architecture shape
Options: hypervisor-first; microkernel-first; separation-kernel-first.  
Evidence: privileged surface size, exit/IPC complexity, proof surface; alignment with threat model and supply-chain posture.

## D-ISA: initial ISA family
Options: x86_64; AArch64; RISC-V (S-mode; H extension if hypervisor-first).  
Evidence: virtualization + IOMMU maturity; trap/MMU simplicity; bring-up speed; availability of formal ISA semantics.

## D-CHERI: optional capability-hardware profile
Options: ignore; hybrid ABI support; pure-capability (“purecap”) compartments; user-mode only vs privileged adoption.  
Evidence: reduction in memory-corruption exploitability for unsafe compartments; performance/compatibility impact; toolchain/provenance feasibility.

## D-MEMTAG: hardware memory tagging + hardening profiles (optional)
Options: ignore; Arm MTE for selected user-space compartments; broader MTE posture; software-sanitizer-only for tests.
Evidence: catch-rate and exploit-hardening gains for unsafe/legacy compartments; overhead/compatibility impact; ability to bind hardening intent as data (CH-HARDEN) without expanding the privileged core.
See: RFC-0062.


## D-VERIF: verification program
Options: Verus-first; proof-assistant-first; hybrid (model-check early, mechanize later).  
Evidence: ability to express invariants/refinement; trust story; iteration speed; proof maintenance plan.

## D-DRT: definitional models + differential randomized testing (evidence method)
Options: none (ad hoc tests); DRT for CH-KABI/CH-ACP only; DRT for all CH-* schemas + validators.  
Evidence: counterexample-finding speed; ability to keep reference models tiny/auditable; reduction of “spec drift” before mechanization.

## D-KABI: privileged ABI shape + minimization strategy
Options: syscall ABI; hypercall ABI; static partition ABI; ABI-as-action-set.  
Evidence: totality/fail-closed behavior; stable encoding; reducible action space for proofs (<PO-ABI-*>).

## D-CAP: capability semantics (derive/mint/revoke)
Options: derivation-only attenuation; allow amplification via explicit “authority objects”; revocation model (none / lazy / eager / epoch).  
Evidence: ability to specify/verify I-CAP-1 + I-REVOKE-1; complexity of revocation proofs; impact on KABI and object model.

## D-COMP: manifested system composition (component graph + capability routing)
Options: no manifest (hand-coded init); minimal CH-COMP consumed by user-space init; richer framework (realms/dynamic resolution).  
Evidence: ability to make cross-component authority edges explicit (reviewable + lintable), tie composition to provenance (CH-BOOT binding), and enforce “no undeclared routes” (I-COMP-1) without expanding the privileged core.

## D-SUPV: supervision trees and restart policy (optional)
Options: none; Erlang/OTP-style supervision trees in user space; MINIX3-style reincarnation server; hybrid (structured restart + component-level policy).  
Evidence: ability to recover from driver/service faults without privileged policy, keep failure handling reviewable/lintable, and integrate with updates/checkpoints (D-ATOMICUPD, D-CHKPT) while preserving authority discipline (I-CAP-1).
v0 posture: D-SUPV stays **component-rooted and user-space** in Phase 1: supervision targets are explicit `cid` roots from CH-COMP rather than ambient PID/process ancestry, lifecycle control is bounded **Stop→Kill** rather than a portable signal/jobspec plane, restart is manifest/activation replay only, and there is **no portable pidfd / Job Object / process-descriptor control plane**. See `docs/30-architecture/supervision-posture-v0.md`.

## D-ACTIVATE: activation-owned stable handles + bounded handle stores (optional)
Options: none (default); supervisor-owned stable exports + activation set delivery (CH-ACTSET) + optional per-component handle store (RFC-0081).
Evidence: restart continuity without dropped inbound traffic; deterministic Stop→Kill lifecycle; handle-store phase gating interacts cleanly with D-SEAL; wrong-instance restore fails closed and bounds prevent DoS.
v0 posture: D-ACTIVATE stays **supervisor-owned, inbound-only, and continuity-only** in Phase 1: stable handles are activation-delivered public endpoints, CH-ACTSET remains descriptive rather than bearer authority, and any optional handle store is per-`cid`, manifest-closed, bounded, and non-inventory rather than a general persistence/export seam. See `docs/30-architecture/activation-posture-v0.md`.
See: RFC-0017 (restart policy seam), RFC-0041 (crash-only/microreboot discipline).


## D-INITSNAP: initial state snapshots / capability distribution (optional)
Options: none (implicit init); CH-INIT snapshot validated at boot; adopt/import capDL-style snapshot language.
Evidence: seL4 capDL + Microkit show that a static system description compiled into an initializer can keep runtime tiny and make “boot matches snapshot” arguments tractable.
Evidence: ability to pin time-0 authority edges for audit/debug, seed D-RR replay, and enable mechanized ‘boot reaches snapshot’ arguments without expanding privileged policy logic.
v0 posture: `CH-INIT` stays **boot-bound and time-0 only** in Phase 1: there is **no portable runtime create/apply/patch/list/watch/export plane**, warm restore/checkpoint/continuity stay on explicit **D-CHKPT / D-EPHEM** seams, and constructors may consume `digest(CH-INIT)` without turning `CH-INIT` into a constructor control plane. See `init-snapshot-posture-v0.md`.

## D-CAPX: capability export/import across trust boundaries (optional)
Options: proxy-based CapTP-style references; cryptographic bearer tokens (macaroons/biscuit); hybrid.  
Evidence: ability to bind remote authority to local objects (I-CAPX-1) and keep attenuation monotonic (I-CAPX-2) without importing a large distributed-systems TCB.

Adjunct: CH-SREF (“sturdyrefs” / offline capabilities) as an out-of-band handoff/persistence seam (RFC-0014).

v0 posture: D-CAPX itself stays a **gateway-owned, proxy-first import** seam in Phase 1: accepted CH-CAPX binds only to local proxy/service objects, routine workflow/observation surfaces carry `digest(CH-CAPX v0)` rather than raw bytes, and there is no ambient resolver, app-visible token inventory/probing API, or portable caveat-policy VM on the core seam. See `docs/30-architecture/capx-posture-v0.md`.
v0 posture: D-CAPX / CH-SREF stays **explicit restore-only, off-by-default, and non-inventory** in Phase 1: CH-SREF bytes are secret-bearing restore material, routine workflow/observation surfaces carry `digest(CH-SREF)` rather than raw bytes, and there is no ambient resolver or app-visible sturdyref inventory/search/watch API. See `docs/30-architecture/sturdyref-posture-v0.md`.
Companion import→docref boundary: when a workflow starts from CH-SREF / CH-CAPX and wants routine document workflows, Phase 1 must first materialize a **fresh local object**, classify it as outside-world input, and only then mint a provider-local CH-DOCREF. The resulting docref is not a hidden bearer-backed wrapper, does not silently re-fetch remote bytes on reopen, and does not turn local save into remote write-back. Companion fresh-identity boundary: even if the imported bytes already exist locally, this bridge stays **fresh-object-identity-first** with no `reuse_existing` / content-equality alias laundering across quarantine/trust state. Companion bearer-provenance boundary: the imported fresh local object may record one exact **`origin.import_ref_digest`** naming the accepted bearer handoff, but provenance stays digest-only evidence rather than raw CH-SREF / CH-CAPX metadata or hidden restore/re-fetch authority. See `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`, and `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`.

## D-CAPRPC: object-capability RPC profile (optional)
Options: none (default); adopt a capability-RPC frame (CH-CAPRPC) for component calls with payloads governed by pinned CH-IFACE descriptors (D-IDL); optionally support promise pipelining/persistent capabilities in later phases.
v0 posture: live D-CAPRPC references stay **explicit, connection-specific, and session-scoped** in Phase 1; disconnect is **fail-stop**; there is no portable transparent reconnect/resume or session/object inventory surface. Continuity requires an explicit new session plus explicit bootstrap/introducer capability or explicit CH-CAPX/CH-SREF import/restore. See `docs/30-architecture/caprpc-session-posture-v0.md`.
v0 posture: if the promise/pipelining adjunct is enabled, promise handles stay **caller-local, session-scoped, and one-shot** in Phase 1; pipelining targets only unresolved **capability results**; there is no portable promise inventory/combinator/admin surface. See `docs/30-architecture/caprpc-promise-posture-v0.md`.
v0 posture: if the oneway/pulse adjunct is enabled, methods stay **interface-marked**, **enqueue-or-error**, and **current-session only** in Phase 1; CH-CAPRPC does **not** grow a third frame kind, oneway payloads stay **`<= 256 bytes`** with **zero capability attachments**, and there is no durable mailbox/callback/admin surface. See `docs/30-architecture/caprpc-oneway-posture-v0.md`.
Evidence: whether RPC boundaries can remain capability-mediated (no ambient endpoints), transcriptable (CH-LOG), and small enough to model-check; integration with D-CAPX/CH-SREF for remote and offline references. Under Hybrid, replicated `caprpc_proxy` state is pinned to **owner-routed metadata only**; live callable authority still requires an explicit local proxy/handle or import/restore event (`caprpc-proxy-replication-boundary-v0.md`).

## D-APIEVO: interface evolution posture (optional)
Options: treat all interfaces as closed (break/replace only); allow “open” interfaces that can be safely extended with explicit unknown-op semantics; support adapters/translators as first-class components for compatibility.
Evidence: ability to upgrade components without confused-deputy fallbacks; deterministic error reporting for unknown interface/method; tooling that can gate upgrades when required interfaces disappear (CH-IFACE supersedes breadcrumbs + CH-BOOT/CH-UPD policy).
See: RFC-0071.

## D-NAMECERT: local naming certificates (optional)
Options: none (default); user-space SPKI/SDSI-style local name+delegation bundles (CH-NAMECERT); integrate with views/sturdyrefs.  
Evidence: whether local namespaces + delegation improve usability/auditability without importing PKI complexity; ability to keep evaluation out of the privileged core and retain non-amplifying semantics (I-NAME-2). Cross-cluster `namecert` replication, when enabled under Hybrid, is pinned to **signed bundle-set evidence only**; local explicit policy still decides trust/visibility/activation (`namecert-replication-boundary-v0.md`).
v0 posture: `namecert-posture-v0.md` pins D-NAMECERT as an **issuer-local, user-space naming-evidence seam**: no privileged-core chain evaluator, no ambient fetch/global resolver, no automatic view install, and no portable policy/caveat VM on the core seam. `namecert-projection-boundary-v0.md` further pins Phase 1 authority-bearing materialization to explicit D-NS `view.attach` / `view.detach` on concrete `view.slot` keys with retained source `digest(CH-NAMECERT v0)` evidence; there is no bulk bundle install or hidden resolver-cache activation path. `namecert-time-boundary-v0.md` additionally freezes validity/freshness as **admission-only**: CH-NAMECERT time checks may deny future admissions, but live `view.slot` bindings do not auto-detach on expiry or timeproof updates. `namecert-revocation-boundary-v0.md` similarly keeps later negative evidence / issuer withdrawal **evaluator-local and admission-scoped**: no ambient CRL/OCSP or latest-wins resolver semantics, and no automatic `view.detach` when revocation is learned. `namecert-selection-boundary-v0.md` closes the remaining ambiguity when multiple admissible candidates exist: Phase 1 evaluation is **set-valued**, D-NAMECERT standardizes no default ranking/winner rule, and any live binding must identify the exact chosen candidate with retained source digests rather than a hidden resolver choice. `namecert-search-boundary-v0.md` then freezes the evaluator itself as **closed-world and bounded** over one explicit bundle set: local goal-directed search is allowed, but there is no suspend/resume distributed credential discovery, ambient fetch/chase, or hidden background retry, and cycle/bound exhaustion fails closed rather than widening authority. `namecert-redelegation-boundary-v0.md` closes the adjacent propagation seam: admitted Phase 1 delegations carry **no implied onward delegation** because CH-NAMECERT v0 carries no `may_delegate` / propagation-bit / depth field, so multi-hop delegation chains reject unless each issuer is independently authorized under explicit local policy. `namecert-trust-root-boundary-v0.md` closes the trust seam around that evaluator: trust anchors are explicit evaluator-local input, CH-NAMECERT is not itself a trust root or trust-policy container, replicated arrivals cannot auto-install anchors, and changing local trust policy only affects future admissions rather than silently rewriting live bindings. `namecert-normal-form-boundary-v0.md` closes the adjacent statement-representation seam: admitted `bindings` / `delegations` arrays use one duplicate-free strict normal form, are strictly sorted by canonical element bytes, reject exact duplicates, and do not acquire first-match/last-match or duplicate-weight semantics. `namecert-string-profile-v0.md` closes the remaining string-identity seam: authority-bearing `Binding.name` / `Delegation.role` labels stay exact-byte lowercase ASCII only, so D-NAMECERT imports no Unicode normalization, case-folding, PRECIS, or confusable-policy machinery in Phase 1. `namecert-label-atom-boundary-v0.md` closes the adjacent label-structure seam: admitted labels are single opaque atoms after validation, `.` / `_` / `-` remain ordinary bytes, and D-NAMECERT imports no hierarchy, wildcard, prefix/suffix, or path grammar onto `Binding.name` / `Delegation.role`. `namecert-principal-profile-v0.md` closes the adjacent principal-identity seam: admitted `PrincipalRef` values are hash-only and canonical (`kind="key_hash"`, `alg="cose_key_thumbprint_sha256"`, exact 32-byte thumbprints), raw `kind="pubkey"` admissions reject, and verifier-key distribution stays on explicit local trust-anchor / key-registry policy instead of widening CH-NAMECERT into a mixed identity-encoding surface. `namecert-signature-profile-v0.md` closes the signature seam itself: admitted bundles use one inline direct Ed25519 signature over the canonical unsigned bundle bytes, and wrapper-only/keyless/multisignature acceptance stays out of D-NAMECERT admission. `namecert-metadata-boundary-v0.md` closes the adjacent bundle-lifecycle seam: `bundle_id` / `created_ms` remain signed provenance only, so D-NAMECERT imports no latest-wins, implicit replacement-lineage, or metadata-driven freshness/obsolescence semantics. `namecert-bearer-boundary-v0.md` closes the adjacent authority-transport seam: admitted CH-NAMECERT bundles never carry raw CH-SREF / CH-CAPX / raw capability material, `TargetRef.kind="sturdyref"` is reserved+rejected in Phase 1, and any capability-bearing import/restore stays on explicit D-CAPX / CH-SREF routes rather than piggybacking on naming evidence.

## D-NS: view/namespace semantics (v1) (optional)
Options: minimal v0 views (bind/mount/resolve only); per-process copy-on-write namespaces with **union mounts** (Plan 9 style); add “service trees” (file-like hierarchies) as a tooling/introspection convention (optionally 9P-like transport for remote mounts).
Evidence: usability wins without ambient authority; ability to keep resolve pure + non-amplifying (I-VIEW-1/I-VIEW-2); performance of union/overlay; auditability of namespace mutation (CH-LOG binding) and interaction with sealing (D-SEAL).
v0 posture: Phase 1 pins **explicit view namespaces** (single-slot binding; no privileged `open(path)`); see `docs/30-architecture/view-namespace-posture-v0.md`. Under Hybrid, cross-cluster `view` replication is pinned to **owner-routed slot-binding metadata only**; replicated summaries may aid caching/inspection but cannot auto-activate bindings in a receiver's active local view (`view-replication-boundary-v0.md`).
v1 ergonomics (per-process clones, union mounts, service trees) remain in RFC-0032.


## D-MEMBRANE: membranes / revocable forwarders (optional)
Options: user-space membranes/wrappers; kernel-supported indirection (epochs/tables) if needed.  
Evidence: ability to make attenuation/revocation *transitive* across boundaries without leaking raw capabilities; overhead; proof surface.

## D-AUTHAGENT: key-holding authentication agent (optional)
Options: user-space “factotum/ssh-agent style” service; hardware-backed keys (TPM/TEE) as a profile annex.  
Evidence: reduction of key-material exposure; minimal interface shape; auditability (CH-LOG) without secret leakage; explicit assumptions.

## D-CRYPTOSVC: capability crypto services + key policy pins (optional)
Options: ad hoc agent APIs; adopt pinned descriptors (CH-KEYPOL/CH-KEYREF/CH-CRYPTOAUDIT) for reviewable key handles and redaction-safe crypto audit; hardware-backed provider annex (TPM/TEE) vs software-only agent.  
Evidence: ability to eliminate key-export APIs (I-CRYPTO-1), enforce purpose/context constraints (I-CRYPTO-2), keep provider reachability explicit-route only without ambient socket/env or provider-global inventory drift (I-CRYPTO-3), make delegation + persistence safe (D-LEASE/D-PERSIST), and keep audit transcripts useful without leaking secrets (PO-CRYPTOAUDIT-REDACT, PO-CRYPTOSVC-ENF).
v0 posture: D-CRYPTOSVC stays **op-only, context-bound, and explicit-route only** in Phase 1: no ambient `SSH_AUTH_SOCK`-style discovery, no provider-global key inventory, no PKCS#11-style slot/session/object model on the core seam, and **no transparent forwarded-agent seam**. Cross-domain/compat delegation may happen only through explicit narrowed routes that preserve-or-tighten CH-KEYPOL constraints. See `docs/30-architecture/cryptosvc-posture-v0.md` and `docs/30-architecture/cryptosvc-forwarding-boundary-v0.md`.
See: RFC-0067.

## D-APPSECRET: per-application secret seeds via a portal (optional)
Options: none (default); add a secret portal (portal.secret) that issues per-application secret seeds for local encryption/integrity without introducing ambient keyring APIs. Emit a bounded CH-APPSECRET descriptor for receipts/audit. Optional stricter profile returns a non-exportable seed handle instead of bytes (composes with D-CRYPTOSVC).
v0 posture: D-APPSECRET stays a **minimal app-scoped seed seam**, not a vault: `scope="profile"` is the default posture, named secret inventory / cross-app sharing are out of scope, and rotation is explicit rather than silent or background-driven. See `docs/30-architecture/app-secret-posture-v0.md`.
Evidence: whether we can satisfy common app needs (local DB encryption, integrity tags) while preserving authority discipline: per-app isolation (I-APPSECRET-1), no secret bytes in transcripts/exports (I-APPSECRET-2), explicit rotation semantics and policy gating (I-APPSECRET-3), and fail-closed validation/enforcement (PO-APPSECRET-VALIDATE/PO-APPSECRET-ENF). Abuse-case coverage includes AC-089.

## D-VAULT: sealed secrets + vault service (optional)
Options: no standard vault (apps manage secrets ad hoc); standardize a user-space vault with pinned secret policy + durable secret references (CH-SECRETPOL/CH-SECRETREF) layered on D-CRYPTOSVC; add hardware sealing/attestation gates only in deployment profiles (TPM/TEE/D-CC).
Evidence: ability to eliminate ad hoc secret-export APIs; policy-bound context/evidence checks (I-VAULT-1/I-VAULT-2); keep the portable surface ref-bound and non-inventory (I-VAULT-3, PO-VAULT-REFONLY); rollback-safe persistence story when combined with D-PERSIST; ability to bind high-risk releases to volition/receipt seams (D-VOLITION/D-EXPLAIN) without expanding the privileged core.
v0 posture: D-VAULT stays **ref-bound, provider-owned, and non-inventory** in Phase 1: portable secret authority is CH-SECRETPOL/CH-SECRETREF plus the closed op set, while collection/item/session/search semantics and recovery/federation remain explicit future/profile work. See `docs/30-architecture/vault-posture-v0.md`.
See: RFC-0070.

## D-CONTRACT: contract-based channels (protocol state machines) (optional)
Options: library-enforced protocol FSMs (default); optional user-space runtime monitor; kernel-enforced contracts (avoid unless required).  
Evidence: prevention of protocol confusion; model-check tractability on small FSMs; codegen/maintenance impact; interaction with D-ENC and KABI.

## D-PAGER: user-mode pager/exception handling (optional)
Options: kernel-only paging (default); **object-backed only in Phase 1**; richer per-address-space/self-paging profiles only with an explicit new RFC/ADR.  
Evidence: kernel TCB reduction vs authority leakage and DoS; ability to keep fault surface closed and auditable (CH-KABI/CH-LOG) and to preserve isolation invariants.
v0 posture: `ext.user_mode_pager` means explicit pager-backed memory objects only: **CH-FAULT v0** requests stay object+offset based, there is **no per-address-space pager** or raw-virtual-address fault routing in Phase 1, mutable writeback is deferred, and pager/admin inventory drift is out of scope. See `pager-posture-v0.md`.
See: RFC-0044.

## D-CONC: concurrency scope (staged)
Options:
- UP-only prototypes (bring-up only; not a flagship verification end state)
- SMP-big-lock baseline (verified multicore sequentialization point)
- SMP-refined locking/sharding
- Hybrid/multikernel evolutions when scale requires

Evidence: proof complexity vs scalability; performance requirements; ability to specify an explicit memory model (D-MEMMODEL).
See: docs/30-architecture/multicore-architecture-options.md.


## D-COMMUTE: interface-first scalability via commutativity

**Status**: Required discipline for privileged action surfaces (ADR-0005).

Options:
- Ignore (traditional “correctness first; hope it scales”)
- Annotate action specs with conflict keys + commutation predicates (documentation only)
- Enforce commutativity claims via generated tests and evidence hooks (preferred)
  - Pin per-action metadata on stable surfaces: `hot-action-surface-v0.md` for the hot privileged surface, `docs/70-llm-control/acp-action-kind-registry.md` for CH-ACP kinds (conflict keys, ordering witnesses, retry safety), and `docs/70-llm-control/acp-commutativity-predicate-registry.md` for per-kind commutation predicates + normalized observation boundary.
- Use commutativity metadata as a scheduler/planner hint (optional; must not affect correctness)

Receipt surface note: when D-COMMUTE observability is in scope, ordering failures MUST remain digest-bound and non-ambient: CH-DENY for `conflict-key-invalid` / `order-witness-*` binds `conflict_key_digest` and/or `order_digest` so transcripts can name the serialization domain without implementation logs (I-DENY-4; PO-DENY-ORDER-BIND).

Pinned v0 posture: `ordering-token-posture-v0.md` (ordering witnesses stay scope-bound and owner-minted; one conflict-key stream only; no portable sequencer/range-allocation/global-stream surface).

Evidence: spec-level commutation proofs/tests (PO-COMMUTE-SPEC, PO-COMMUTE-TEST); reduced coordination in hot paths; ability to evolve from SMP → hybrid/multikernel without ABI breakage.

See: `commutativity-and-interface-scalability.md` (REF-SCR-TOCS15), `serialization-boundary-registry.md` (closed `validator`/`svc:<name>`/`none` tokens for ordered kinds), `hot-action-surface-v0.md` (pinned hot surface v0), `conflict-key-family-registry.md` (closed CH-CONFLICTKEY family allowlist), and `conflict-key-derivation-registry.md` (pins deterministic tuple→digest derivation for the digest-valued `*_key` payload fields used by pinned surfaces), plus `typed-id-contract-v0.md` (pins canonical encoding for the `*_id` inputs that feed `ck_id(..)`).



## D-TYPEDID: canonical encoding for core typed identifiers (v0: opaque digests)

**Status**: Adopt v0 contract (Revised184).

Problem: several hot action / ACP seams refer to typed ids (`as_id`, `endpoint_id`, `view_id`, `device_id`, …)
that feed conflict keys and ordered-stream scopes. If their encoding is “profile-defined”, drift
becomes inevitable and commutativity evidence rots.

Decision (v0): for the core ids that feed `ck_id(..)` / `ck_domain(..)` on pinned surfaces,
represent ids as **opaque digest bytes**: a `bstr` of length `hashlen` (profile digest length).
See: `typed-id-contract-v0.md`.

Evidence: deterministic canonical encoding (raw bytes); minimal privileged validation (length check);
keeps hash agility profile-scoped; closes an otherwise-open “tuple encoding” ambiguity in D-COMMUTE
without inventing new schema surface area.

See: `typed-id-contract-v0.md`, `conflict-key-derivation-registry.md`, `conflict-key-schema-v0.md`.
References: REF-RFC6920, REF-GIT-HASH-TRANSITION, REF-MULTIHASH.


## D-HASH: profile hash suite (v0: SHA-256, fixed length)

**Status**: Adopt v0 contract (Revised194).

Problem: many pinned seams say “profile hash” / “profile digest length” without defining the
hash suite. Leaving it implicit invites drift:
- mixed digest algorithms across validators/tools,
- length mismatches that break receipt correlation,
- and human-facing encodings (hex/base64) accidentally becoming privileged inputs.

Decision (v0):
- `digest(bytes) := SHA-256(bytes)`
- `hashlen := 32`
- digests on privileged seams are raw digest bytes (no in-band algorithm tags).

Entropy justification: we spend **one** decision surface (D-HASH) to collapse ambiguity across
typed ids (D-TYPEDID), conflict keys / ordering scopes (D-COMMUTE), and receipt hooks. We do **not**
introduce a new schema surface for digests in v0.

See: `profile-hash-suite-v0.md`.
References: REF-FIPS180-4, REF-RFC6234.


## D-RETRYSAFE: deterministic retry + dedupe keys for validator-executed actions

**Status**: Required discipline for the LLM-first action surface.

Problem: in an agent-driven system, retries are normal (timeouts, restarts, duplicate delivery).
If retry behavior is left implicit, implementations tend to:
- accidentally repeat effects (double grants, double jobs, duplicate background grants), or
- smuggle in ambient state/order as a hidden idempotency mechanism.

Decision (v0): for any externally visible action kind that claims **at-least-once-safe** retry semantics,
we require a **schema-pinned, explicit idempotency/dedupe key**:
- the key is named in the kind’s registry row (stable diff surface),
- the key is carried in an existing bound descriptor (or the action params) and is **non-authoritative**,
- validators/owner services suppress duplicates *before* any effect, and
- outcomes are transcript-visible (CH-LOG/CH-ACPOUT) so duplicate suppression is auditable; when CH-ACPOUT is emitted for an accepted-but-deduped proposal, producers SHOULD set `effect="duplicate_suppressed"` (CH-ACPOUT v0) so tooling can distinguish “applied” from “suppressed” without implementation-specific logs.

Canonical examples (already present surfaces):
- `capshell.exec` uses CH-EFFCON `contract_id` as the idempotency key for duplicate suppression (paired with the capshell output normal form: exportable outputs are CH-AREF digests and duplicates return the same output digests; see `capshell-output-normal-form-v0.md`).
- `portal.clock.timeproof.sample` uses CH-TIMEREQ `req_id`.
- `portal.jobs.submit` uses CH-JOBREQ `job_id`.
- `portal.background.request` uses CH-BGREQ `req_id`.
- `portal.attn.request` uses CH-NOTIF `.id` for upsert/dedupe semantics.

Evidence: small retry/dedup harnesses (swap-order + duplicate-delivery) complement D-COMMUTE tests;
Jepsen/Knossos-style reasoning applies to ordered streams and dedupe keys (REF-KNOSSOS-JEPSEN).

Guardrail: `tools/check_retry_dedupe_wiring.py` fails `make lint` if any ACP kind marked
*at-least-once-safe* does not name an explicit stable dedupe key token.

## D-MK: multicore structure (SMP vs multikernel vs hybrid)

**Status**: Adopt **Hybrid** as the default direction (ADR-0005). SMP variants remain permitted as *in-cluster* implementations/profiles.
Options:
- Shared-kernel SMP (possibly big-kernel-lock as an early verified baseline)
- SMP with explicit sharding/replication of key state (clustered objects)
- Multikernel-style per-core kernels/monitors coordinating via explicit messages
- Hybrid: multikernel across NUMA/chiplets; SMP within a cluster
- Application-directed sharing (Corey-style) as an explicit configuration surface

Evidence: ability to keep ownership of shared state explicit (reduce hidden sharing) and stage proof obligations; scalability on many cores/NUMA; interaction with determinism/replay; how cleanly CH-HWFACT/SKB can drive placement and topology decisions. Phase 1 narrows default cluster derivation so `preferred_boundary = auto` chooses **NUMA → socket → core_group**, while `die` remains explicit-policy-only (`cluster-auto-boundary-v0.md`), freezes cache/LLC facts as **placement hints only** rather than ownership selectors (`cache-topology-authority-boundary-v0.md`), freezes asymmetric CPU-capacity / performance-class facts as **placement hints only** rather than ownership or authority selectors (`cpu-capacity-authority-boundary-v0.md`), freezes NUMA-distance / HMAT latency-bandwidth / memory-tier facts as **placement hints only** rather than distance-adaptive ownership or authority selectors (`memory-locality-authority-boundary-v0.md`), and caps the flagship claim envelope at **<=64 logical CPUs**, **<=8 clusters**, and **<=16 logical CPUs per cluster** (`cluster-phase1-envelope-v0.md`). `hybrid-phase1-boundary-v0.md` records that this Phase 1 Hybrid authority/claim surface is now closed rather than open-ended.
See: docs/30-architecture/multicore-architecture-options.md.

## D-CLUSTERMAP: cluster derivation + partition artifact (Hybrid adjunct)

**Status**: Required seam for Hybrid (ADR-0005). Early phases may default to a single cluster, but the artifact surface is stable.

Options:
- Implicit/opaque kernel clustering (avoid; hard to audit and reason about)
- User-space derivation from CH-HWFACT with optional profile knobs, emitting CH-CLUSTERMAP (preferred)
- Profile-pinned cluster maps (static configs for appliances / separation profiles)
- Adaptive clustering at runtime (avoid early; tends to explode proof surface and observability)

Evidence: determinism (PO-CLUSTERMAP-DERIVE), fail-closed validation (PO-CLUSTERMAP-VALIDATE), and ability to state cross-cluster ownership/replication contracts against stable cluster ids. Phase 1 claim scope is further bounded by `cluster-phase1-envelope-v0.md`, and the combined v0 authority posture is closed by `hybrid-phase1-boundary-v0.md`.
See: `cluster-derivation.md`, `cluster-auto-boundary-v0.md`, `cache-topology-authority-boundary-v0.md`, `memory-locality-authority-boundary-v0.md`, `cluster-phase1-envelope-v0.md`, `hybrid-phase1-boundary-v0.md`, and CH-CLUSTERMAP v0.

## D-REPL: cross-cluster replication/consistency contracts (Hybrid adjunct)

**Status**: Adopt a conservative v0 contract vocabulary and schema seam (ADR-0006).

Options:
- Implicit global services/shared state (avoid; defeats Hybrid)
- Ad-hoc per-service replication semantics (avoid; hard to audit and prove)
- Bounded contract vocabulary (RC0..RC4) expressed as CH-REPLCONTRACT (preferred)
- Strong global consensus for broad state (defer; must be explicit and justified)

Evidence: ability to state ownership and ordering requirements against stable cluster ids; fail-closed validation (PO-REPLCONTRACT-VALIDATE); no authority amplification from replicated metadata (PO-REPL-NOAMP); compatibility with D-COMMUTE tests for RC3 objects (PO-REPL-MERGE).
See: `replication-contracts-v0.md` and CH-REPLCONTRACT v0.

Guardrails: treat CH-REPLCONTRACT `object_family` tokens as registry-closed (see `replication-object-family-registry.md`) and pin A–D default guidance in `profile-repl-defaults.md` so global ordering (RC4) stays rare and explicit. For `object_family = quota`, replicated RC3 state is observational additive spend summary only; authorization still comes from local explicit payer authority, while issuance/rebalance stays on the owner-routed `budget` seam (see `quota-replication-boundary-v0.md`). For `object_family = budget`, replicated RC1 state is owner-routed issuer / lease-lineage metadata only; non-owner caches may aid routing/audit/staleness checks, but they must not mint local spend authority, widen leases, or infer portable credit from cached lineage state (see `budget-replication-boundary-v0.md`). For `object_family = transcript`, replicated RC3 state is content-addressed CH-LOG event-set evidence only; it may support audit/replay bundles/export, but cannot satisfy local approval/policy checks, authorize replay/resubmission, instantiate handles or leases, or turn transcript arrival order into runtime sequencing/freshness authority (see `transcript-replication-boundary-v0.md`). For `object_family = receipt`, replicated RC3 state is immutable digest-addressed evidence only; it may support audit/explanation/export but cannot satisfy local approval/policy checks, authorize replay/resubmission, or resurrect handles/leases named by receipt fields (see `receipt-replication-boundary-v0.md`). For `object_family = caprpc_proxy`, replicated state is owner-routed endpoint/proxy metadata only; callable authority still requires an explicit local proxy/handle or CH-CAPX / CH-SREF import/restore event (see `caprpc-proxy-replication-boundary-v0.md`). For `object_family = tlog`, replicated RC4 material is append-only evidence only; local explicit policy still pins trusted logs/witnesses, and checkpoint order must not become runtime admission, control, or time authority (see `tlog-replication-boundary-v0.md`). `hybrid-phase1-boundary-v0.md` records that these family meanings now close the Phase 1 Hybrid replication surface rather than leaving a residual open question.


## D-SCHED: scheduling stance (verification-first)
Options: deterministic (Phase 1 default); nondeterministic but constrained; SMP-first.  
Evidence: whether determinism can collapse early proof obligations; interaction with time/interrupts; compatibility with the platform profile.
Pinned v0 posture: `scheduling-posture-v0.md` (portable scheduling stays TCap-first with closed CH-TCAP urgency classes; no ambient priority/class or scheduler-admin plane, no portable fairness/share/latency promise, and no global scheduler inventory/oracle).

## D-TURNS: turn-based concurrency for selected services (optional)
Options: none (default); per-service event-loop ("vat") runtimes for selected components; profile-mandated turn-based delivery for specified service sets (often those exposed via CapRPC).  
Evidence: reduction in reentrancy/ordering hazards; easier deterministic replay/logging (D-RR); improved reasoning/verification tractability; measurable overhead vs threaded runtimes and ability to shard explicitly when needed.
Pinned v0 posture: `turns-posture-v0.md` (per-component runtime discipline; exactly one active turn per vat; far calls stay async; no hidden inbox pumping; no portable reentrancy/interleaving knob; no new workflow/ACP surface).
External actions emitted from a turn keep their existing conflict-key and ordering-witness semantics; D-TURNS itself does not introduce a new portable conflict-key family or sequencing API.
See: RFC-0078; interacts with RFC-0026 (CapRPC).

## D-REQCTX: request contexts (deadlines + cancellation + trace correlation) (optional)
Options: ad hoc per-interface params (default); standard request-context conventions + CH-REQCTX descriptors; integrate into CapRPC framing (CH-CAPRPC v1 `ctx_digest`) for correlation.

Evidence: reduction in orphan work and shutdown complexity (avoid timeout soup); deterministic cancel/timeout outcomes that are replay/log-friendly; ability to keep context **non-authoritative** and bounded (no covert “baggage” store); adoption ergonomics in stub generators and supervisors.
Pinned v0 posture: `reqctx-posture-v0.md` (sticky parent→child propagation; one absolute monotonic deadline intent; no portable baggage/detach/shield semantics; no workflow/ACP surface).
See: RFC-0105.

Note: CH-REQCTX v1 includes optional untyped digest lists (`budget_desc_digests`, `tcap_desc_digests`) for audit/deny-only correlation. When a consumer treats `budget_desc_digests` as required sponsorship (e.g., `capshell.exec` under `cfg.params.capshell.require_budget_lease=true`), interpretation is pinned as type-strict and non-ambient (no locator deref): see `reqctx-budget-ref-posture-v0.md`. Likewise, if any consumer treats `tcap_desc_digests` as required temporal sponsorship, it MUST be type-strict and non-ambient: see `reqctx-tcap-ref-posture-v0.md`. Hard boundary: CH-REQCTX sponsorship lists stay bare digests; any future typed/multi-schema sponsorship must live outside CH-REQCTX as its own explicit surface (`reqctx-sponsorship-evolution-boundary-v0.md`).

## D-BRACKET: privilege bracketing + call-chain contexts (optional)
Options: none (default); user-space runtime convention that makes **privileged capabilities** inaccessible by default when servicing inbound requests (borrowed mode), unless code explicitly enters a scoped privileged block; optionally attach a bounded CH-CALLCHAIN digest in CH-REQCTX v1 for audit/deny-only routing.
Evidence: whether the pattern materially reduces in-process confused-deputy incidents in plugin/helper ecosystems; ability to keep the mechanism **veto-only** (never grants authority), exception-safe (no privilege leakage), and adoptable in real codebases without growing the privileged core.
Pinned v0 posture: `bracket-posture-v0.md` (borrowed-mode default; task/request-local dynamic scope; explicit exception-safe privileged blocks; bounded optional deny-only CH-CALLCHAIN; no portable stack inspection or workflow/ACP surface).
See: RFC-0118.

## D-QUIESCE: quiescence + drain protocol for maintenance operations (optional)
Options:
- ad hoc stop semantics/signals per service (default)
- cooperative quiesce + drain/cancel protocol (recommended seam)
- stop-the-world freezer as the primary maintenance primitive (avoid early)

Evidence: ability to shut down and upgrade services under load without orphan work; ability to obtain a consistent cut for checkpoint/restore; bounded and deterministic outcomes (no silent background work after cancel); composability with D-REQCTX (deadlines), D-SUPV (escalation), D-ACTIVATE (continuity), and D-CHKPT (capture).
Pinned v0 posture: `quiesce-posture-v0.md` (cooperative component-local control; one active qid; `DRAIN|CANCEL` only; no force-kill/global freeze semantics; no workflow/ACP surface).
See: RFC-0108.



## D-WAITSET: wait sets + object signals for scalable event loops (optional)
Options:
- wait_many only (baseline; O(n) scan)
- wait_many + WaitSet with observational signal bits and explicit bindings (recommended)
- packet queues / user-injected events on the same seam (defer; hidden control-plane risk)
- programmable filters (avoid early)

Pinned v0 posture: `waitset-posture-v0.md` (observational signal bits; explicit bindings; level-triggered by default; `tag + observed_mask` only; no packet queue/user injection; no workflow/ACP surface).
Evidence: scalability of event-driven servers and driver loops; ability to keep the API bounded and deterministic; interaction with D-REQCTX cancellation and D-NONDET clock/timeout posture; assurance that waiting cannot amplify authority (I-WAITSET-1) or quietly widen into a packet/control-plane seam.
See: RFC-0106.


## D-UWAIT: wait-on-address (futex) primitives for userspace synchronization (optional)
Options:
- none (spin/poll or heavy kernel objects)
- process-local wait-on-address on one aligned 32-bit word; wait + wake only (recommended seam)
- cross-process wait-on-address for explicitly shared regions (defer until justified)
- add requeue / PI / owner variants (defer; expands scheduler coupling)

Pinned v0 posture: `uwait-posture-v0.md` (process-local only; aligned 32-bit wait word; wait + wake only; no requeue/PI/workflow surface).
Evidence: reduce CPU waste and watchdog false positives from spinning; enable pthread/runtime compatibility without per-lock kernel objects; bounded and attributable waiter state avoids DoS; interacts cleanly with D-REQCTX (timeouts/cancel) and D-RR (replay determinism) without creating a cross-domain signaling seam.
See: RFC-0110.


## D-ROBUSTLOCK: robust locks + owner-death semantics for shared synchronization (optional)
Options:
- none (timeouts / supervision-only recovery)
- per-thread RobustSet + explicit `OWNER_DIED` / `NOT_RECOVERABLE` states for component-local user-space mutex words (recommended seam)
- cross-process / shared-region robust recovery (defer until a shared wait contract exists)
- kernel-managed lock objects (reject; expands TCB and policy surface)

Pinned v0 posture: `robustlock-posture-v0.md` (runtime-owned per-thread RobustSet; mutex-only; component-local; explicit `make_consistent()` or poison-to-`NOT_RECOVERABLE`; no workflow/ACP surface).
Evidence: prevent permanent deadlock when an owner terminates while holding a mutex; make both “protected state may be inconsistent” and “repair failed / abandoned” explicit to successors; keep cleanup bounded/charged (D-METER), non-amplifying, and generation-safe; defer cross-process robustness until D-UWAIT grows an explicit shared wait contract; integrate with deterministic replay (D-RR) without turning recovery into a kernel lock-manager seam.
See: RFC-0111.


## D-RCU: grace periods + deferred reclamation for read-mostly shared state (optional)
Options:
- none (locks/refcounts only)
- user-space GraceDomain service/library (QSBR/EBR/RCU patterns) (recommended seam)
- kernel-assisted participant tracking (avoid unless required; expands TCB)

Evidence: whether we can make read-mostly shared state fast for readers without importing a large kernel policy surface; bounded limbo/deferred-free growth under stalls; clean integration with D-UWAIT/D-WAITSET for blocking waits; determinism hooks for D-RR profiles.
Pinned v0 posture: `rcu-posture-v0.md` (QSBR-first; per-subsystem/user-space GraceDomains; no ambient/global collector; no new workflow surface).
See: RFC-0112.


## D-RSEQ: restartable sequences + CPU-local fast paths (optional)
Options:
- none (atomics/locks only)
- user-mode rseq regions + per-thread cpu-id cache (Linux rseq lineage) (recommended seam)
- kernel-managed per-CPU objects (reject; expands TCB/policy surface)

Evidence: whether we need a kernel-assisted primitive for *bounded* “CPU-local fast paths” (per-CPU allocators/counters/queues) without turning every operation into a syscall; interaction with D-SCHED migration and D-NONDET posture (CPU-id as a potential oracle); profile gating for D-RR determinism.
Pinned v0 posture: `rseq-posture-v0.md` (runtime-owned single-slot thread registration; no ambient `getcpu`/topology oracle; explicit abort-to-slow-path; no new workflow surface).

See: RFC-0113.


## D-IOQ: I/O submission queues + completion events (optional)
Options:
- none (per-op IPC/syscalls)
- bounded IoQueue object (shared rings + doorbell; io_uring/I/O rings shape) (recommended seam)
- rich programmable I/O language (avoid early)

Evidence: whether batching reduces boundary-crossing overhead for I/O-heavy services and drivers without expanding the privileged core; clean integration with D-WAITSET signals; preservation of capability discipline (targets are explicit handles); bounded rings and deterministic overflow behavior.
Pinned v0 posture: `ioq-posture-v0.md` (provider-owned batching; explicit handles only; one SQE → one op; no path constructors, chain/message-ring drift, or workflow/ACP surface).
See: RFC-0107.


## D-SEAL: initialization→sealed steady-state posture (capability attenuation)
Options: none (default); voluntary init→seal discipline in key services; profile-mandated seal for selected components.  
Concrete mechanisms (stackable):
- **capability attenuation**: drop capabilities and revoke introducers after init (baseline).
- **promise masks** (optional): install a one-way allowlist of effect families the domain may invoke (CH-PLEDGE v0).
- **namespace narrowing** (optional): "unveil"-style reduction by sealing/removing subtrees from view objects (D-NS).
- **capability mode** (optional): forbid any ambient/global acquisition after init (D-CAPMODE).

Evidence: (1) monotonicity (cannot widen post-seal); (2) enforcement at every privileged-effect boundary (no bypass fast paths); (3) ergonomics/uptake in large services and compat shims; (4) similarity to pledge/unveil patterns while keeping "handles not paths."

Pinned v0 posture: `seal-posture-v0.md`.


## D-DYNCODE: dynamic code loading + executable memory policy (W^X / execmod) (optional)
Options:
- sealed code spaces (no dynamic native modules; exec mappings bound to sealed artifacts)
- capability-gated “execmod” (RW→RX flips and non-sealed exec mappings require explicit authority)
- permissive baseline (compat-first; not recommended for tight provenance)

Evidence: (1) W^X enforcement (no RWX); (2) “execmod” gating is non-bypassable at the KABI; (3) profile feasibility for JIT-heavy apps (broker/dual-map patterns); (4) supply-chain / attestation clarity when executable pages are digest-bound (D-ATOMICUPD).  
See RFC-0059 for the detailed posture and evidence plan.


## D-VERITY: verified blobs + Merkle integrity for immutable content (optional)
Options:
- none (default)
- file-level verified blobs (fs-verity-style; VerifiedBlob objects)
- volume-level verified roots (dm-verity-style; verity-protected read-only volumes)
- hybrid (volumes for base OS; VerifiedBlob for packages/app artifacts)

v0 posture: `verity-posture-v0.md` pins D-VERITY to **explicit immutable VerifiedBlob handles plus optional deployment-local verity roots**: file-level verified blobs are the portable artifact unit, `CH-VBLOB v0` stays descriptor-only/non-authoritative, reads fail closed, and Phase 1 declines mutable repair/writeback, generic proof export, or a verity inventory/admin plane.
Evidence: whether we can make “immutable bytes stay immutable” mechanically checkable without inflating the privileged core: fail-closed verified reads, digest identity that composes with CH-AREF/CH-UPD/CH-BOOT provenance, bounded verification caches (D-METER), and clear diagnostics for integrity failures.
See: RFC-0114 and `verity-posture-v0.md`.


## D-CAPMODE: ambient authority elimination (capability mode) (optional)
Options: none (default); per-process “capability mode” that forbids authority acquisition from ambient namespaces; system-wide “no ambient acquire” profile.
v0 posture: `capmode-posture-v0.md` pins D-CAPMODE as **one-way, no ambient acquire after entry**: already-held explicit handles remain usable and explicit handoff remains allowed, but path/env/default-service/DNS/global fallback must fail closed, D-CAPMODE adds no new IF-/CH-/ACP/admin surface, and long-lived services are expected to compose it with D-SEAL rather than treating capmode alone as sufficient narrowing.
Evidence: ability to enforce “no new authority from globals” without bloating IF-KABI; alignment with views (I-VIEW-1/I-VIEW-2) and seal patterns (D-SEAL); ease of mechanical justification.

## D-TRANS: user-space translators / stackable filesystem servers (optional)
Options: none (default); “translator” servers attachable to view nodes (per-path or per-directory); a constrained set of standard translators (net, proc, auth, vfs adapters) as profiles.  
Evidence: whether extensibility can live in user space without reintroducing ambient authority; ability to keep resolution inside view objects (I-VIEW-1/I-VIEW-2) and keep translator attachment an explicit, auditable action (CH-LOG binding), similar to GNU Hurd “translators”.
v0 posture: `translator-posture-v0.md` pins D-TRANS as **view-local translators attached only through explicit `view.slot` mutations**: no global pathspace registration, no translator inventory/search/admin plane, no translator stacks/chains in Phase 1, and no separate translator ACP family; externally visible attach/remove continues to use `view.attach` / `view.detach` with existing `view.slot` conflict keys and `svc:view` ordering.

## D-ATTRFS: filesystem attributes + query as a first-class primitive (optional)
See: RFC-0100 (CH-ATTRQ v0) and `attrfs-posture-v0.md`.
Options: no special metadata (default); xattr-style key/value attributes only; indexed attributes + query language (BeOS/Haiku BFS style) scoped by views.  
Phase-1 pin: indexed attributes and smart queries stay **view-scoped, snapshot-first, and handle-returning**; saved queries / smart folders stay **shell-owned manifests** rather than an app-visible inventory or background watch seam. In other words, saved queries / smart folders stay shell-owned manifests, not an application inventory API. Companion metadata-safe query/index boundary: quarantined objects may still appear in authorized metadata views, but Phase 1 forbids ambient **content-derived extraction** (full-text/OCR/embedding/summary pipelines) from quarantined bytes outside an explicit workflow that yields a new quarantined artifact. Companion derived-attribute boundary: even those explicit workflows must not perform **source-object semantic back-write** by writing semantic text/tags/classifier outputs back onto the risky source object’s queryable metadata; queryable semantics live on the separate derived artifact instead. Companion derived-match boundary: **no source resurfacing by derived matches** — even then, query/smart-folder/search surfaces must not resurface the risky source object by hidden lineage joins, representative substitution, or dedup-style result collapse; exact hit identity stays on the derived artifact unless a relation is followed explicitly. See `docs/30-architecture/quarantined-content-index-boundary-v0.md`, `docs/30-architecture/quarantined-derived-attribute-boundary-v0.md`, and `docs/30-architecture/quarantined-derived-match-boundary-v0.md`.
Evidence: whether attribute indexing/query improves UX and auditability without becoming a covert channel or integrity hole; ability to bound attribute schema (CH-ATTR) and query predicates (CH-ATTRQ) and ensure access checks are capability-mediated (I-VIEW-2).

## D-PERSIST: orthogonal persistence + capability store (optional)
See: RFC-0065 (CH-CAPSTORE v0).
Options: mutable filesystem only; snapshotting CoW filesystem service; **CapStore** with named durable roots; broader “orthogonal persistence” profile (KeyKOS/EROS style) implemented as a user-space store.  
Evidence: whether durability can remain **explicit authority** (no ambient persistence), restore is non-amplifying (I-PERSIST-2), and rollback/resurrection is detectable and policy-gated (I-PERSIST-3).


## D-ATOMICUPD: atomic system image updates + rollback (optional)
Options: traditional package mutation (avoid for base); A/B partitions with bounded tries + health-commit (CH-BOOTSEL); immutable deployments with content-addressed trees (OSTree/rpm-ostree style) plus per-deployment provenance binding (CH-PROV/CH-BOOT).
Evidence: whether atomic rollback meaningfully reduces update failure modes and supports our evidence linkage (prov digest ↔ deployment digest) without bloating trusted boot logic; and (if profiles require it) whether **mutable data rollback hazards** are made explicit via CH-CFG `data_contracts` + snapshot barriers (RFC-0097) rather than hidden footguns.
v0 posture: **digest-bound install intent only**. CH-UPD binds one target deployment root plus one config/policy binding, `artifacts[]` stays a bounded adjunct digest set, and Phase 1 adds **no channel/rollout/verdict semantics**, repository-metadata meaning, or privileged-core query/feed plane; release names/version labels remain observational distribution identifiers rather than install or verdict authority (`release-identity-boundary-v0.md`); verification stays consumer-local evaluation of exact evidence under local policy, with no native verified-good/waiver/latest-verified plane (`verification-verdict-boundary-v0.md`); companion `proof-bundle-role-boundary-v0.md` further pins that `proof_bundle` remains a descriptive adjunct-evidence role rather than a native proof/verdict schema; companion `update-evidence-subject-boundary-v0.md` further pins that supporting evidence may appraise the pinned install cohort but must not widen CH-UPD into a release-wide or bundle-wide subject definition; companion `provenance-required-subject-boundary-v0.md` further pins that local policy may require provenance only for exact already-pinned carrier digests rather than every subject present in a larger release attestation; companion `provenance-coverage-policy-boundary-v0.md` further pins that carrier-borne provenance fields name exact evidence bytes only and do not choose which provenance-coverage policy is in force; companion `provenance-container-selection-boundary-v0.md` further pins that imported multi-statement provenance containers remain packaging only rather than a native union/preference/completeness rule; companion `provenance-evidence-set-boundary-v0.md` further pins that multiple exact provenance-bearing artifacts do not jointly define a native provenance closure or fallback rule; companion `sbom-vex-evidence-set-boundary-v0.md` further pins that multiple exact SBOM/VEX artifacts do not jointly define a native vulnerability/applicability closure or fallback rule; companion `sbom-bomref-identity-boundary-v0.md` further pins that imported CycloneDX `bom-ref` stays a document-local join label rather than a native cross-artifact component identity; companion `vex-component-absence-boundary-v0.md` further pins that `component_not_present` plus one linked inventory does not define a native component-absence oracle; companion `vex-remediation-selection-boundary-v0.md` further pins that `fixed` / remediation text do not define a native patch-plan or update-target selector; companion `vex-investigation-deferral-boundary-v0.md` further pins that `under_investigation` / VEX time fields do not define a native hold/defer selector; companion `vex-priority-signal-boundary-v0.md` further pins that imported CVSS / EPSS / KEV / vendor-severity style signals do not define a native install-veto, rollout-priority, or update-selection rule; companion `vex-cpe-applicability-boundary-v0.md` further pins that imported CPE names / applicability expressions do not define a native install-target, same-product, or applicability rule; companion `vex-osv-range-boundary-v0.md` further pins that imported OSV package / ecosystem / range semantics do not define a native same-component, version-ordering, or update-selection rule; see `docs/30-architecture/update-posture-v0.md`.



## D-TUF: survivable update repository metadata (optional)
Options: none (direct CH-UPD fetch + signatures only); TUF baseline (root/targets/snapshot/timestamp); fleet extension (Uptane director split).
Evidence: resistance to rollback/freeze/mix-and-match; operational feasibility of key rotation and compromise recovery without bricking fleets; integration with D-ATOMICUPD/D-TLOG while keeping privileged boot agnostic.
v0 adjunct boundary: `signature-trust-root-boundary-v0.md` pins that D-TUF may distribute trusted verification material, but trusted roots still remain explicit local verifier input or explicit provisioning artifacts, and Phase 1 adds no native trusted-root/self-anchoring/service-discovery plane.
See: RFC-0079.

## D-UPTANE: fleet-grade update distribution extensions (optional)
Options: none (default); Uptane-style director split layered on D-TUF for multi-ECU/fleet management scenarios.
Evidence: whether the additional roles/infrastructure reduce real fleet risk (replay/rollback and compromise blast radius) enough to justify operational complexity; ability to keep the privileged boot path agnostic and keep failure modes fail-closed.
Note: D-UPTANE is a **profile extension**; D-TUF remains the baseline decision node.
See: RFC-0079 and `docs/60-engineering/update-repository-metadata-and-key-rotation.md`.


## D-HEALTH: explicit health predicate + boot-success commit (optional)
Options: implicit success (avoid); time-only heuristic (weak); **pinned health predicate artifact (CH-HEALTH) + capability-gated commit**, with audit evidence (CH-HEALTHREC) and optional readiness barrier integration (CH-COMP `ready`).
Evidence: whether we can make “boot success” non-ambiguous, spoof-resistant, and transcript-visible to support A/B rollback semantics (CH-BOOTSEL) and structured recovery (D-SUPV) without importing a scripting VM or large policy engine.
See: RFC-0074 (health predicates + boot-success commit), RFC-0051 (atomic updates), RFC-0017 (supervision).

## D-RECOVERY: recovery mode + rescue environment (optional)
Options: none (default); manual recovery target (boot menu / physical presence); manual + bounded trial-boot loop via CH-BOOTSEL pending; auto-enter recovery after repeated failures (defer until evidence justifies extra selector state).
Evidence: whether we can keep a recovery environment bootable independent of the normal stack, provenance-bound like any other deployment, and fail-closed on entry (physical presence) while avoiding a hidden privileged admin shell.
v0 posture: D-RECOVERY stays a **sealed dedicated `recovery_root` boot target** in Phase 1: entry is manual/physical-presence-first or an explicit trial-boot assist only, recovery boot never counts as main-boot success, and there is **no portable remote rescue/admin shell or hidden automatic failover counter state**. See `docs/30-architecture/recovery-posture-v0.md`.
See: RFC-0098.

## D-FPM: functional build graphs + content-addressed store (optional)
Options: conventional package mutation; semi-immutable base image + mutable apps; functional package management (Nix/Guix-like) where build outputs are addressed by their inputs and system configuration composes a verifiable closure.
Evidence: reproducibility and rollback ergonomics; how easily we can bind derivations/closures into provenance (CH-PROV) and atomic deployments (D-ATOMICUPD) without bloating IF-BOOT; storage overhead and GC; ability to keep “install” effects as explicit, reviewable actions (CH-KABI/CH-ACP).

## D-SBOM: SBOM artifacts and closure binding (optional)
Options: none (default); publish normalized CH-SBOM only; attach full external SBOM documents (SPDX/CycloneDX) via CH-AREF; attach VEX exploitability statements as a separate CH-VEX artifact (or link to external VEX docs via CH-AREF).
Evidence: ability to bind SBOMs to the exact deployed root/component digest (avoid drift), keep exports bounded/policy-scoped (CH-OBSPOL), and integrate with provenance/transparency logs without expanding IF-BOOT.
v0 posture: D-SBOM stays **digest-bound inventory evidence only** in Phase 1: one subject per artifact, stable component identifiers carry the portable binding, generator metadata stays informational, and there is **no merge/union/delta/fetch service in Phase 1** plus no package-manager/authority semantics on CH-SBOM itself. Companion `sbom-vex-evidence-set-boundary-v0.md` further pins that multiple exact SBOM/VEX artifacts do not jointly define a native vulnerability/applicability closure or fallback rule. Companion `sbom-bomref-identity-boundary-v0.md` further pins that imported CycloneDX `bom-ref` stays a document-local join label rather than a native cross-artifact component identity. Companion `sbom-purl-identity-boundary-v0.md` further pins that imported `purl` stays a package label rather than a native cross-artifact component identity. Companion `sbom-component-version-boundary-v0.md` further pins that imported component/advisory `version` labels stay descriptive rather than a native cross-artifact same-component or version-ordering rule. Companion `sbom-supplier-origin-boundary-v0.md` further pins that imported supplier/origin labels stay provenance evidence rather than a native trust, support-owner, or remediation-owner rule. Companion `sbom-license-metadata-boundary-v0.md` further pins that imported component license metadata stays evidence rather than a native allow/deny or obligation rule. Companion `sbom-external-reference-locator-boundary-v0.md` further pins that imported SPDX/CycloneDX URL/locator fields stay descriptive evidence rather than a native fetch or resolver rule. Companion `sbom-document-supersession-boundary-v0.md` further pins that external SBOM document identity/version fields stay imported document metadata rather than a native latest-wins or freshness rule. Companion `sbom-spdx-reference-boundary-v0.md` further pins that imported SPDX `SPDXID` / `ExternalDocumentRef` syntax stays document-scoped evidence rather than a native cross-artifact join or resolver rule. Companion `sbom-spdx-relationship-boundary-v0.md` further pins that imported SPDX relationship edges stay document-graph evidence rather than a native dependency, closure, or causality rule. Companion `vex-component-absence-boundary-v0.md` further pins that `component_not_present` plus one linked inventory does not define a native component-absence oracle. See `docs/30-architecture/sbom-posture-v0.md`.
See: RFC-0091.

## D-VEX: vulnerability exploitability statements (optional)
Options: none (default); publish normalized CH-VEX only; attach full external VEX documents (OpenVEX/CSAF/CycloneDX) via CH-AREF; optionally link to a CH-SBOM digest for component context.
Evidence: ability to reduce vulnerability-scanner noise with digest-bound, reviewable statements (avoid drift), while keeping exports bounded/policy-scoped (CH-OBSPOL) and avoiding “VEX as authority” in the privileged core.
v0 posture: D-VEX stays **digest-bound exploitability evidence only** in Phase 1: one subject per bounded statement set, closed status/justification vocabulary, and there are **no scanner-suppression, feed-discovery, or latest-advisory-wins semantics in Phase 1**; author/generator fields remain informational and trust must ride on explicit signature/admission policy. Companion `sbom-vex-evidence-set-boundary-v0.md` further pins that multiple exact SBOM/VEX artifacts do not jointly define a native vulnerability/applicability closure or fallback rule. Companion `sbom-bomref-identity-boundary-v0.md` further pins that imported CycloneDX `bom-ref` stays a document-local join label rather than a native cross-artifact component identity. Companion `sbom-purl-identity-boundary-v0.md` further pins that imported `purl` stays a package label rather than a native cross-artifact component identity. Companion `sbom-component-version-boundary-v0.md` further pins that imported component/advisory `version` labels stay descriptive rather than a native cross-artifact same-component or version-ordering rule. Companion `vex-component-absence-boundary-v0.md` further pins that `component_not_present` plus one linked inventory does not define a native component-absence oracle. Companion `vex-remediation-selection-boundary-v0.md` further pins that `fixed` / remediation text do not define a native patch-plan or update-target selector. Companion `vex-vulnerability-identity-boundary-v0.md` further pins that `vuln_id` stays an exact statement label rather than a native alias / upstream / related graph, canonical-vulnerability selector, or cross-ID suppression key. Companion `vex-statement-key-boundary-v0.md` further pins that `statements[]` stays an unordered exact-key snapshot rather than a native last-wins / history / conflict-resolution plane. Companion `vex-priority-signal-boundary-v0.md` further pins that imported CVSS / EPSS / KEV / vendor-severity style signals do not become a native install-veto, waiver, rollout-priority, or update-selection rule. Companion `vex-cpe-applicability-boundary-v0.md` further pins that imported CPE names / applicability expressions do not define a native same-product, install-target, or applicability rule. Companion `vex-reference-locator-boundary-v0.md` further pins that imported advisory references / locator fields do not become a native fetch, discovery, or resolver rule. Companion `vex-osv-range-boundary-v0.md` further pins that imported OSV package / ecosystem / range semantics do not define a native same-component, version-ordering, or update-selection rule. See `docs/30-architecture/vex-posture-v0.md`.
See: RFC-0092.

## D-BOOTSTRAP: bootstrappable toolchains + minimal trust seed (optional)
Options: conventional bootstrap binaries (default); reduced binary seed (Guix/Mes-style); “stage0” style minimal chain; full-source bootstrap target.  
Evidence: whether we can keep the seed set small and explicitly listed; ability to bind seed/toolchain digests into CH-PROV and keep release profiles honest without bloating IF-BOOT.  
See: RFC-0061.

## D-DDC: diverse double-compiling as a compiler-trust mitigation (optional)
Options: none (default); DDC gate for the compiler used to build trusted artifacts; broader DDC gates for the release toolchain.  
Evidence: determinism and bit-for-bit matching under the chosen reproducibility posture; ability to make failures explainable and bind outcomes into provenance (CH-PROV) without expanding runtime TCB.  
See: RFC-0061.

## D-POWERBOX: consent mediators / powerbox UX (optional)
Options: none (default); user-space powerbox service (IF-CONSENT) issuing CH-AUTHZ approvals; integrate with ACP (IF-ACP) for high-risk actions.
Evidence: whether UX-mediated grants reduce capability confusion without importing UI/agent complexity into the privileged core; ability to bind human consent to action digests (I-CONSENT-1).
v0 posture: D-POWERBOX stays **designation-scoped and chooser-owned** in Phase 1: requesters describe a bounded resource/authority shape, while the mediator/provider owns the candidate set and returns concrete capability outcomes (CH-AUTHZ / handles / typed artifacts), not ambient names, callback routes, or a generic remembered-grant library. See `docs/30-architecture/powerbox-posture-v0.md`.

## D-VOLITION: trusted UI path + volition tokens (optional)
Options: none (default); user-space UI root emits CH-VOL “volition tokens” bound to a rendered action-summary digest; integrate with IF-CONSENT so approvals require a fresh volition token.
Evidence: whether we can prevent UI spoofing/clickjacking style confused-deputy approvals while keeping UI complexity out of the privileged core; ability to bind consent to a user gesture and to an action digest (I-VOLITION-1, I-CONSENT-1) with fail-closed validation.
v0 posture: Phase 1 pins CH-VOL as **fresh, local-only, one-shot gesture evidence**: no batch/wildcard approvals, no export/import semantics, and no session-restore / cached approval reuse. See `docs/30-architecture/volition-posture-v0.md`.

## D-UICAP: capability-mediated UI compositor + secure attention (optional)
Options: no pinned UI contract (default); user-space compositor/UI root that mediates **surfaces + input** as object-capabilities; focus-gated input delivery; screenshot/screencast/remote-control only via portal workflows (D-PLUMB) and ideally lease-based (D-LEASE). Optional secure attention sequence (SAS) to enter a “secure UI mode” for login/high-risk consent.

Evidence: whether we can make UI isolation usable without ambient global window state: (a) surface isolation (no screen scrape), (b) focus-gated input (no global keylogging), (c) portal-mediated high-risk UI authority with clear receipts; and whether SAS can be delivered in a non-interceptable way without expanding the kernel TCB.

v0 scope posture is pinned in `docs/30-architecture/uicap-scope-posture-v0.md` (resolves OQ-0004).

See: RFC-0080.

## D-UIAUT: accessibility/automation sessions (optional)
Options: none (default); observation-only accessibility sessions; injection-capable sessions (higher-risk); dev/test-only automation; remote-control automation via portals with strict leases.
Evidence: whether we can support assistive tooling and UI automation without reintroducing ambient global hooks: (a) no ambient UI tree/text readback, (b) injection/remote control only via explicit portal grants with TTLs and indicators, (c) focus-chain and UI structure disclosure treated as sensitive metadata.
v0 posture: Phase 1 pins D-UIAUT as **manual-only** and **observation-first**: no ACP automation kind, no hidden persistence/relaunch semantics, and `observe != inject` remains explicit. See `docs/30-architecture/ui-automation-posture-v0.md`.
See: RFC-0099.


## D-CAPTURE: portal-mediated media capture sessions (optional)
Options: none (default); user-space capture portal that mediates camera/microphone/screencast/remote-desktop sessions as explicit, attributable **leases** and emits CH-CAPTURE descriptors for audit/receipts.

Evidence: whether we can eliminate ambient capture paths (audio-server sockets, global screen readback), enforce TTL/renew/escalation via portal mediation, and require user-visible indicators without expanding the privileged core.

v0 posture: Phase 1 pins D-CAPTURE as **manual-only**, **indicator-bound**, and **non-persistent**: no ACP automation kind, no restore-token / remembered-session semantics, and no background/headless start. See `docs/30-architecture/capture-portal-posture-v0.md`.

See: RFC-0095.

## D-EXPLAIN: authority diffs + consent receipts (optional)
Options: none (default); require “authority diff” previews for any grant that adds authority; emit CH-RECEIPT records bound to action + shown diff/summary + result.
Preferred diff structure: CH-CAPDIFF v0 (see RFC-0069).
Adjunct (validator-facing, UI-optional): emit **CH-DENY v0** records for deterministic validator rejections (policy/lane/ordering/schema), bound from CH-LOG via `deny_digest`, so “killable by policy” and fail-closed workflows remain mechanically auditable without treating rejections as approvals. `deny_code` values are closed-world per `deny-code-registry.md`.
Evidence: whether diff+receipt reduces confused-deputy and “grant creep” without spamming the user; ability to make the shown diff a deterministic function of the approved action + relevant state (I-EXPLAIN-1) and to bind receipts to reality (I-EXPLAIN-2) while keeping receipts non-authoritative (I-EXPLAIN-3).

v0 posture: Phase 1 pins D-EXPLAIN as **canonical shell-owned CH-CAPDIFF summaries plus non-authoritative CH-RECEIPT evidence**: requester prose may decorate prompts but never define `summary_digest`; wildcard/batch approval reuse is out of scope; and D-EXPLAIN itself does **not** standardize a generic receipt ledger / list / watch / sync / permission-store/admin plane. See `docs/30-architecture/explain-posture-v0.md`.

## D-LEASE: capability leases + limited-use proxies (optional)
Options: none (default); or standardize **time-limited / use-limited** capability proxies as a user-space pattern for “temporary authority”.

If enabled: portals/gateways SHOULD default to issuing **leased proxy capabilities** (not raw caps) when crossing trust boundaries or when UX expects “temporary share” semantics. Leases are implemented in user space using membranes/forwarders (D-MEMBRANE) plus optional Clock handles (D-NONDET) for time-based expiry.

Impacts:
- Adds **CH-CAPLEASE v0** (redaction-safe descriptor; no secrets) for audit/consent receipts.
- Adds invariants I-LEASE-1..3, proof obligations PO-LEASE-VALIDATE/ENF/NOAMP, and abuse case AC-055.
- Composes naturally with D-PLUMB (portal grants), D-EXPLAIN (authority diffs), D-CAPX (imported tokens), and D-PERSIST (non-durable-by-default).

See: RFC-0066.

v0 posture: Phase 1 pins leases as proxy authority (no raw cap export; no unbounded renewal; no ambient time authority); see `docs/30-architecture/capability-lease-posture-v0.md`.


## D-NETLEASE: outbound network leases via a portal (optional)
Option: keep outbound networking ambient (not recommended); or make outbound network authority **explicit and lease-based**.

If enabled: components obtain outbound networking only via a network portal (`portal.net`) that returns scoped `NetDialer`/`NetListener` capabilities with a redaction-safe **CH-NETLEASE** descriptor. This composes with D-PLUMB (workflow routing), D-EXPLAIN (authority diffs + receipts), and D-ATTN (optional prompts/notifications).

If enabled, expose the **lease request seam** as an ACP kind (`portal.net.request`) so **LLMs propose; deterministic validators execute** and receipts/transcripts remain the stable product surface. ACP proposals bind `netreq_digest = digest(CH-NETREQ v0)` (bounded request descriptor); the portal returns **CH-NETLEASE v0** (bounds receipt) and an opaque network authority handle.

Impacts:
- Adds CH-NETREQ v0 (bounded request descriptor) and CH-NETLEASE v0 (bounds descriptor), plus optional invariants I-NETLEASE-1..3.
- Adds proof obligations PO-NETLEASE-VALIDATE/ENFORCE/DNSBIND and abuse case AC-047.
- Strengthens D-QUAR safe-open: disposables start with no network lease by default.

See: RFC-0056.

v0 posture: Phase 1 pins **no ambient sockets/DNS** (portal-issued leased network authority only); see `docs/30-architecture/network-lease-posture-v0.md`.

## D-LOCLEASE: location leases via a portal (optional)
Options: keep location ambient (not recommended); or make location authority **explicit and lease-based** via a location portal.

If enabled: components obtain location only via a location portal (`portal.location`) that returns scoped location capabilities with a redaction-safe **CH-LOCLEASE** descriptor. Policy can clamp **coarse vs precise**, enforce TTL/cadence, and gate background tracking; continuous tracking should imply shell-driven indicators.

Impacts:
- Adds CH-LOCLEASE v0 (bounds descriptor; no coordinates).
- Adds invariants I-LOCLEASE-1..3, proof obligations PO-LOCLEASE-VALIDATE/PO-LOCLEASE-ENF, and abuse case AC-086.
- Should not imply networking; if providers require network lookups, that authority remains inside the portal/service (composes with D-NETLEASE).

See: RFC-0101.

v0 posture: Phase 1 pins **manual-only, coarse-first, and non-persistent** location workflows; no ACP kind, no `background="always"` product claim, and no geofence wakeups as a relaunch/scheduler seam. See `docs/30-architecture/location-lease-posture-v0.md`.

## D-ATTN: attention authority + notifications (optional)
Options: none (default); notification portal (`portal.attn.*`) with origin branding + explicit lane kill switch (`cfg.params.lane.portal.attn`), using CH-NOTIF v0 as the bounded request seam; notification channels + per-app budgets; `importance="urgent"` is a policy-gated hint in v0 (future durable TTL/renew/revoke semantics, if ever needed, require a **separate RFC-first surface** rather than an implicit lease-like widening).
If enabled, expose the attention request seam as an ACP kind (`portal.attn.request`) so **LLMs propose; deterministic validators execute** and receipts/transcripts remain the stable product surface.
Evidence: whether we can bound notification spam/phishing, make notification origin unspoofable, and ensure notification actions require fresh volition (D-VOLITION) and show authority diffs (D-EXPLAIN) when they grant new authority; interaction with D-QUAR safe-open flows and D-EPHEM disposables.
See: RFC-0055.

v0 stance: do **not** introduce a dedicated attention-lease descriptor; treat urgency as a policy-gated CH-NOTIF `importance` hint, and freeze CH-NOTIF as an **ephemeral request seam** whose meaning may not be widened in place into durable interruption authority (see `docs/30-architecture/attention-lease-posture-v0.md` and `docs/30-architecture/attention-durable-interrupt-boundary-v0.md`).

## D-PLUMB: workflow router + portals (optional)
Options: none (default); user-space workflow router that mediates open/save/share/clipboard/drag-drop via portal sessions, a pinned CH-PLUMBMSG envelope for intent messages (canonical `intent.kind` taxonomy pinned in `intent-kind-registry.md`), and CH-ROUTE deterministic routing rules; optional CH-XFER v0 transfer descriptors for auditable transfer grants (RFC-0094); integrate with D-POWERBOX and D-VOLITION for user-mediated grants that return capabilities (not paths); optional document portal providing durable handles (CH-DOCREF) for “recent documents” without ambient paths (RFC-0089).
Phase 1 posture is pinned in `plumb-posture-v0.md`: D-PLUMB stays **explicit-invocation and request-local** rather than turning into a durable inbox/outbox service. The portable seam declines generic `Subscribe(port)` / held-message pickup, callback URL/port registries, app-visible route/handler inventory, durable retries, and any new CH-ACP/conflict-key surface; route evaluation + request lifecycle ordering live inside `svc:workflow.router`, while independent requests commute with respect to authority because the router mints none.
Portal-session posture is pinned in `portal-session-posture-v0.md`: generic portal request/session objects stay **provider-owned request/session** control objects with **one terminal outcome** and **family-local** long-lived sessions only. D-PLUMB v0 therefore declines a family-agnostic resume/restore-token layer, generic list/watch APIs over live portal objects, and caller-supplied callback rendezvous; any stronger continuity or inventory semantics must return under a specific portal family RFC/posture rather than back-propagating into the core.
Evidence: whether explicit routing + portal handles reduce ambient authority and confused-deputy flows; ability to audit grants/denials; ability to keep the privileged core agnostic while supporting a rich desktop/workflow ecosystem.
Profile defaults: recommended `cfg.params.lane.portal.*` defaults for A–D are pinned (non-authoritatively) in `profile-lane-defaults.md` to keep “no forks” honest and keep default posture reviewable.

v0 transfer posture: Phase 1 pins `portal.xfer.*` as a **manual-only, sink-pull, non-history** workflow: `copy` publishes an offer, but cross-component delivery happens only on explicit paste/drop/share; cross-boundary transfers default to short-lived one-shot/auto-clear grants; there is no background clipboard observation or clipboard-history service. See `docs/30-architecture/transfer-portal-posture-v0.md`.

v0 document-portal posture: Phase 1 pins `portal.file.*` / CH-DOCREF as **manual-only, explicit-persistence, non-bearer reopen**: chooser results are ephemeral by default, durable CH-DOCREF issuance requires explicit user/policy choice, reopen cannot widen rights or target scope, and there is no app-visible grant inventory/list API in v0. Safe-open composes with this seam by resolving CH-DOCREF once and then materializing a request-local stable input object; the document portal is not a live write-through preview backchannel, risky-open preview/open does **not** auto-enroll the source object into durable recent-doc / MRU / reopen surfaces, and ordinary risky-open keep/export remains **fresh-destination-first** rather than overwriting an existing object inside the same workflow. Companion import→docref boundary: bearer restore/import may feed this seam only by first minting a **fresh local object** plus provider-local docref, not a hidden bearer-backed reopen shim. Companion fresh-identity boundary: that import step must also refuse `reuse_existing` / content-equality alias reuse, so equal bytes do not collapse onto a previously trusted local object/docref. Companion bearer-provenance boundary: imported fresh local objects may keep one exact **`origin.import_ref_digest`** for the accepted bearer handoff, but routine document metadata never carries raw bearer bytes/capability URLs or hidden restore semantics. See `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md`, `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`, and `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`.

v0 OpenURI posture: Phase 1 pins `portal.uri.*` as **manual-only, scheme-gated, launch-only**: opening a link / showing an item stays a shell-owned mediation flow, not an installed-app oracle or callback channel; `file://` and raw paths do not bypass `portal.file.*`, and there is no app-visible handler inventory/probing API in v0. See `docs/30-architecture/openuri-portal-posture-v0.md`.

v0 `open_untrusted` posture: Phase 1 pins `intent.kind=open_untrusted` as an **object-only, `docref`-only** safe-open request on one exact handle: `uri` subjects reject, `sturdyref` subjects reject and stay on explicit D-CAPX / CH-SREF restore/import paths, policy chooses the disposable/template/reuse posture, default launch stays no-net + continuity-free, and export/clear remain separate explicit workflows rather than being hidden inside preview success. Companion import→docref boundary: if a workflow starts from CH-SREF / CH-CAPX and wants safe-open, it must first mint a **fresh local object** plus provider-local docref rather than a hidden bearer-backed shim. Companion fresh-identity boundary: that import step is **fresh-object-identity-first**, so equal imported bytes do not collapse onto an existing local object/docref by `reuse_existing` / content-equality alias. Companion bearer-provenance boundary: that imported fresh local object may record one exact **`origin.import_ref_digest`** as digest-only evidence of the accepted bearer handoff, without leaking raw bearer metadata or hidden restore/re-fetch semantics into routine document flows. Companion materialization boundary: the selected `docref` is resolved once into a request-local stable input object (snapshot/staged-copy style), not a live alias/write-through mount back to the mutable source. Companion active-content boundary: admitted viewers remain inert-by-default rather than executing document-authored code or side effects. Companion residue boundary: mere preview/open does **not** populate durable recent-doc / MRU / reopen / thumbnail / autosave / crash-recovery surfaces outside the disposable. Companion content-index boundary: quarantined bytes do **not** silently flow from risky-open/import into host/global full-text indexes, OCR sidecars, embedding stores, assistant memory, or summary caches; authorized discovery remains metadata-safe only until an explicit analysis workflow yields a new quarantined artifact. Companion result-preview boundary: even when the exact quarantined or derived artifact is the right search/query result, UI result rendering stays **metadata-safe result rendering** only — no ambient snippets, thumbnails, preview panes, or hover previews from quarantined bytes; richer preview routes through an explicit review/open step on the exact handle. See `docs/30-architecture/quarantined-result-preview-boundary-v0.md`. Companion export-classification boundary: ordinary safe-open output that is kept becomes a **new artifact** that remains **quarantined by default** unless a separate sanitize/clear workflow says otherwise. Companion export-destination boundary: ordinary keep/export is **fresh-destination-first**, so the risky-open workflow does not overwrite the source or replace an existing destination object in place. Companion export-lineage boundary: ordinary kept output records one exact `origin.parent_digest`, so the fresh artifact keeps explicit parent evidence without inheriting source `docref` identity or path/filename folklore as lineage. Companion quarantined-execution boundary: exact executable/script objects do **not** route through `open_untrusted`; ordinary execution remains deny-by-default until explicit object-local clear/override, and Phase 1 adds no portable `run_untrusted` lane. See `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`, `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/open-untrusted-active-content-boundary-v0.md`, `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md`, `docs/30-architecture/quarantined-content-index-boundary-v0.md`, `docs/30-architecture/open-untrusted-export-classification-v0.md`, `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md`, and `docs/30-architecture/open-untrusted-export-lineage-boundary-v0.md`.

v0 print posture: Phase 1 pins `portal.print.*` as **manual-only, render-first, shell-spooled**: applications submit bounded rendered artifacts via a prepare→submit workflow, but get no app-visible printer inventory, no durable queue authority, and no print-to-file/path loophole around `portal.file.*`. See `docs/30-architecture/print-portal-posture-v0.md`.

## D-CAPSHELL: capability-safe shell + automation components (optional)
Options: none (default); wrapper-first runner (Plash/Capsicum style) with learn-mode; integrated capshell (interactive + automation) with capability wallets and explicit effect contracts.
Evidence: whether we can eliminate ambient authority in “glue” workflows (shell scripts, cron, CI, admin runbooks) while keeping adoption cheap (learn mode, deterministic violations) and preserving capability discipline (views/portals/sealing).
Companion discovery surface: `capshell-launch-boundary-index.md` keeps the current front-end + launch-boundary adjunct set enumerable so new no-ambient launch promises do not drift into orphan prose.
If enabled:
- standardize **CH-EFFCON v0** as the *veto-only* effect contract descriptor bound to a CH-WALLET core digest (no bearer secrets; no ambient paths/env as permissions).
- standardize **CH-ARGV v0** as the typed argv token list for automation execution, so workflows bind to already-held descriptor digests rather than ambient host paths/env; executable selection is **explicit and unique**: validators require exactly one `role="exec"` selector and runners never consult an ambient PATH (see `capshell-exec-selector-posture-v0.md`).
- pin **capshell executable-object posture v0**: once the explicit `role="exec"` selector is bound, `capshell.exec` must launch that one exact executable object rather than reopening a mutable path/document name at the last moment. Phase 1 allows exact-byte staging only as a fail-closed compatibility shim, and compat membranes that cannot preserve exact-object launch semantics fail closed. See `capshell-exec-object-posture-v0.md`.
- pin **quarantined-execution boundary v0**: exact executable/script objects that remain quarantined are still deny-by-default until explicit object-local clear/override, and `open_untrusted` is not a fallback launch lane. See `quarantined-execution-boundary-v0.md`.
- pin **quarantined code-input boundary v0**: a cleared interpreter/runtime must not launder a quarantined bound code object by restaging it as `stdin`, `-c`, `--eval`, module/archive entry, or another code-bearing input form; explicit object-local clear/override still gates execution. See `quarantined-code-input-boundary-v0.md`.
- pin **safe-open active-content boundary v0**: document-shaped risky-open stays **inert by default**. Embedded active content (macros, document-level scripts, external submit/fetch actions, helper-launch callbacks, or equivalent viewer hooks) does not execute or cause side effects inside `open_untrusted`; any hyperlink/print/file effect must cross a new explicit workflow on the existing portal seam. See `open-untrusted-active-content-boundary-v0.md`.
- pin **capshell `argv[0]` posture v0**: exact executable-object binding is still insufficient if caller-controlled or wrapper-controlled program-name text can switch startup mode. Phase 1 derives child `argv[0]` from the reviewed `role="exec"` selector, forbids `exec -a` / alias / login-shell-style spoofing as reviewed semantics, and treats mode-by-name tools as non-portable unless ordinary reviewed argv already expresses the mode. See `capshell-argv0-posture-v0.md`.
- pin **capshell native code-closure posture v0**: exact executable-object binding is still insufficient if the loader/interpreter/shared-library startup set can be satisfied from ambient host search state. Phase 1 therefore binds one exact startup native code closure, forbids `/etc/ld.so.cache`, default `/lib*` / `/usr/lib*`, current-directory, package-alias, or ordinary DLL-search-order dependency resolution as reviewed meaning, and allows only exact staged-closure materialization as a compatibility shim. See `capshell-code-closure-posture-v0.md`.
- pin **capshell script-entry posture v0**: when a workflow runs a script/text artifact, the interpreter itself remains the explicit `role="exec"` selector; shebangs are non-authoritative metadata, and Phase 1 forbids `#!/usr/bin/env` or ENOEXEC-style shell fallback inside the runner. Companion quarantined code-input boundary: if a bound object is supplying code to that interpreter, quarantine still gates execution even when the bytes arrive via `stdin`, `-c`, module/archive entry, or similar runtime-specific forms. See `capshell-exec-object-posture-v0.md`, `capshell-script-entry-posture-v0.md`, and `quarantined-code-input-boundary-v0.md`.
- standardize **CH-ENV v0** as the typed environment token list for automation execution, so workflow runners do not inherit ambient environments and descriptor references bind to already-held handles.
- pin **capshell environment posture v0**: child environments are complete+explicit only, and Phase 1 rejects startup/resolution env hooks (`PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, `BASH_FUNC_*`) rather than silently scrubbing or inheriting them. See `capshell-env-startup-posture-v0.md`.
- pin **capshell env-baseline posture v0**: the child environment for `capshell.exec` is exactly CH-ENV, not “declared entries plus launcher defaults”; Phase 1 forbids runner-synthesized `HOME`, `PWD`, `OLDPWD`, `TMPDIR`, `TERM`, `LANG`/`LC_*`, `TZ`, and `XDG_*` injection from login/session/TTY/cwd/request context state, and explicit seams such as CH-CWD/CH-STDIO do not secretly mint env. See `capshell-env-baseline-posture-v0.md`.
- pin **capshell command-string posture v0**: `capshell.exec` accepts structured CH-ARGV only; the runner must not auto-tokenize a free-form string, apply shell expansions, or satisfy the action via hidden `sh -c` / `system()` indirection. Explicit shells remain allowed only as the bound `role="exec"` selector, with any command string left as ordinary argv data. Companion quarantined code-input boundary: a quarantined bound object must not be reserialized into that command-string position to bypass explicit clear/override. See `capshell-command-string-posture-v0.md` and `quarantined-code-input-boundary-v0.md`.
- pin **capshell startup-profile posture v0**: integrated capshell startup is explicit-only; Phase 1 declines implicit rc/profile file loading and per-directory hooks (`/etc/profile`, `~/.profile`, `~/.bashrc`, `.envrc`, `.env`, venv auto-activation), so prompt/cwd transitions are not hidden code-loading events. See `capshell-startup-profile-posture-v0.md`.
- pin **capshell word-expansion posture v0**: integrated/front-end capshell does not perform shell-like pre-exec expansion before reviewed CH-ARGV is formed; literal tokens stay exact, and Phase 1 declines globbing, `~` lookup, `$VAR` / `${...}` expansion, `$(...)`, brace expansion, word splitting, pathname expansion, and similar conveniences unless an explicitly chosen interpreter later does so under its own semantics. See `capshell-word-expansion-posture-v0.md`.
- standardize **CH-CWD v0** as the typed working-directory selector for automation execution, so workflow runners do not inherit ambient host cwd and directory bindings are explicit and handle-based.
- pin **capshell cwd-root posture v0**: CH-CWD binds a cwd root rather than advisory path text; `kind="empty"` must yield a fresh/sealed empty cwd root, and compat/path-based resolution must not escape via `..`, absolute-path fallback, or hidden host-root rebasing. If the active platform or membrane cannot prove that safety bar, execution fails closed rather than downgrading to ambient cwd semantics. See `capshell-cwd-root-posture-v0.md`.
- pin **capshell handle-table posture v0**: child descriptor state for `capshell.exec` is exact CH-STDIO + CH-FDSET only. Phase 1 adds no reviewed `pass_fds` / inherit-handles surface, runners must construct an exact child handle/FD table rather than relying on ambient `FD_CLOEXEC` / inheritable-handle hygiene or wrapper defaults, and compat membranes that cannot guarantee that posture fail closed. See `capshell-handle-table-posture-v0.md`.
- pin **capshell umask posture v0**: `capshell.exec` must not inherit an ambient host/session file mode creation mask; Phase 1 fixes the launch `umask` at `0o077`, other execution-pack seams do not secretly mint or repair it, and compat membranes must either preserve that fixed launch posture or fail closed. See `capshell-umask-posture-v0.md`.
- pin **capshell resource-limit posture v0**: `capshell.exec` must not inherit parent shell/session `ulimit` / `getrlimit()` state. Phase 1 adds no reviewed per-step `rlimit` surface, forces `RLIMIT_CORE = 0` at launch, and treats any other launch ceilings as runtime/provider policy independent of parent shell/session state. See `capshell-rlimit-posture-v0.md`.
- pin **capshell launch signal-state posture v0**: `capshell.exec` must not inherit blocked-signal masks or ignored shell trap state from the parent shell/session. Phase 1 adds no reviewed per-step signal-state surface, launch normalizes to an empty blocked-signal mask plus default dispositions for catchable signals, and compat membranes that cannot guarantee that posture fail closed. See `capshell-signalstate-posture-v0.md`.
- pin **capshell launch scheduling posture v0**: `capshell.exec` must not inherit ambient `nice` or scheduler-policy state from the parent shell/session. Phase 1 adds no reviewed per-step scheduling surface, launch normalizes to the default non-real-time time-sharing policy with neutral nice `0`, and compat membranes that cannot guarantee that posture fail closed. See `capshell-scheduling-posture-v0.md`.
- pin **capshell launch CPU-affinity / placement posture v0**: `capshell.exec` must not inherit ambient CPU affinity or wrapper/service-manager placement state from the parent shell/session. Phase 1 adds no reviewed per-step affinity surface, launch normalizes to the default eligible CPU set for the active execution compartment, and compat membranes that cannot guarantee that posture fail closed. See `capshell-affinity-posture-v0.md`.
- pin **capshell launch resource-envelope posture v0**: `capshell.exec` must not inherit wrapper-/session-defined cgroup / Job Object resource limits, CPU quota/weight, memory caps, I/O throttles, or process-count ceilings as hidden workflow meaning. Phase 1 adds no reviewed per-step resource-envelope surface, launch normalizes to the default resource-controller envelope for the active execution compartment, and compat membranes that cannot guarantee that posture fail closed. See `capshell-resource-envelope-posture-v0.md`.
- pin **capshell execution-domain / personality posture v0**: `capshell.exec` must not inherit wrapper-/session-defined execution-domain or personality state. Phase 1 adds no reviewed per-step ABI/personality surface, launch normalizes to the default native execution-domain / personality baseline, and compat membranes that cannot guarantee that posture fail closed. See `capshell-personality-posture-v0.md`.
- pin **capshell confinement label/profile posture v0**: `capshell.exec` must not inherit wrapper-/service-manager-selected SELinux / AppArmor / SMACK execution label/profile state. Phase 1 adds no reviewed per-step confinement-label/profile surface, launch normalizes to the default confinement label/profile baseline for the active execution compartment, and compat membranes that cannot guarantee that posture fail closed. See `capshell-mac-profile-posture-v0.md`.
- pin **capshell peer-inspection / dumpability posture v0**: `capshell.exec` must not inherit host-default same-principal debugger / ptrace / `/proc` visibility. Phase 1 adds no reviewed per-step debugger / peer-inspection surface, launch normalizes to a non-dumpable / non-peer-inspectable baseline, and compat membranes that cannot guarantee that posture fail closed. See `capshell-peer-inspection-posture-v0.md`.
- pin **capshell launcher-lifetime posture v0**: `capshell.exec` must not inherit wrapper-/session-defined parent-death or kill-on-launcher-exit coupling. Phase 1 adds no reviewed per-step die-with-parent/detach surface, launch keeps child lifetime independent of transient launcher/wrapper death inside the active execution compartment, and compat membranes that cannot guarantee that posture fail closed. See `capshell-launcher-lifetime-posture-v0.md`.
- pin **capshell launch syscall-admission posture v0**: `capshell.exec` must not inherit wrapper-/session-defined seccomp or `SystemCallFilter=` policy as hidden workflow meaning. Phase 1 adds no reviewed per-step syscall-filter surface, launch normalizes to the default syscall-admission baseline for the active execution compartment, and compat membranes that cannot guarantee that posture fail closed. See `capshell-syscall-filter-posture-v0.md`.
- pin **capshell launch privilege-gain posture v0**: `capshell.exec` must not gain privilege via setuid/setgid bits, file capabilities, ambient capability carry-over, or similar privileged-exec metadata. Phase 1 adds no reviewed per-step credential/capability elevation surface, launch must guarantee no privilege gain across `exec` (using one-way no-new-privileges controls where available), and compat membranes that cannot guarantee that posture fail closed. See `capshell-privgain-posture-v0.md`.
- pin **capshell launch credential-baseline posture v0**: `capshell.exec` must not inherit ambient caller identity, supplementary-group widening, or borrowed login/access-token state as reviewed workflow meaning. Phase 1 adds no reviewed per-step UID/GID/group/token surface, runners must launch under a provider-/membrane-fixed least-privilege executor identity (or fail closed), and compat membranes must not preserve login-session or helper-process identity as a hidden side channel. See `capshell-credential-baseline-posture-v0.md`.
- pin **capshell launch network posture v0**: `capshell.exec` must not inherit ambient socket constructors or host-global DNS/resolver state as a portable baseline. Phase 1 adds no reviewed per-step raw socket/resolver surface, networked behavior stays on explicit D-NETLEASE / `portal.net` / `CH-NETLEASE` seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving host stack defaults. See `capshell-network-posture-v0.md`.
- pin **capshell launch local-IPC posture v0**: `capshell.exec` must not inherit ambient local IPC namespace reachability, AF_UNIX/session-bus defaults, or bus autolaunch behavior as a portable baseline. Phase 1 adds no reviewed per-step AF_UNIX / session-bus surface, local IPC stays on explicit descriptor/route seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving machine-local IPC lore. See `capshell-local-ipc-posture-v0.md`.
- pin **capshell launch filesystem posture v0**: `capshell.exec` must not inherit ambient host filesystem namespace reachability or a host-global absolute-path baseline. Phase 1 adds no reviewed per-step `open(path)` / namespace-lookup surface, file authority stays on explicit CH-CWD / CH-FDSET / D-NS / D-POWERBOX seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving host-path lore. See `capshell-filesystem-posture-v0.md`.
- pin **capshell launch nondeterminism posture v0**: when D-NONDET is enabled, `capshell.exec` must not inherit ambient `clock_gettime()` / timer-style time reads, host wall-clock / monotonic defaults, or ambient `getrandom()` / machine-RNG behavior as a portable baseline. Phase 1 adds no reviewed per-step clock / entropy surface, portable time/entropy stays on explicit D-NONDET / `portal.clock` / `portal.entropy` seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving host nondeterminism lore. See `capshell-nondet-posture-v0.md`.
- standardize **CH-STDIO v0** as typed stdio bindings for automation execution, so workflow runners do not inherit ambient host stdio/TTY state and all stream bindings are explicit and handle-based.
- pin **capshell terminal/job-control posture v0**: `capshell.exec` does not imply a PTY, controlling terminal, process-group/session control, or a portable `fg` / `bg` / `jobs` plane; Phase 1 keeps interactive terminal UX local-only, and deferred/background presence stays on D-JOBS / D-BGLEASE rather than hidden shell session state. See `capshell-job-control-posture-v0.md`.
- pin **capshell interrupt/cancel posture v0**: portable interruption for `capshell.exec` stays on explicit request/workflow seams (D-REQCTX / D-JOBS / D-BGLEASE / D-QUIESCE), not on signal names, jobspecs, shell-exit SIGHUP conventions, or a hidden `kill` plane. Local UX may map Ctrl-C into cancellation, but raw signal handling remains implementation detail. See `capshell-interrupt-cancel-posture-v0.md`.
- standardize **CH-FDSET v0** as typed extra child-handle bindings for automation execution (slots >= 3), so workflow runners do not inherit an ambient host handle/FD table and all extra bindings are explicit and handle-based.
- standardize **CH-EXECPACK v2** as the capshell *execution pack* completeness seal: `capshell.exec` binds the complete execution context (CH-EFFCON/ARGV/ENV/CWD/STDIO/FDSET) plus `reqctx_digest = digest(CH-REQCTX v1)` and optional `plumbmsg_digest = digest(CH-PLUMBMSG v0)` for an explicit, non-authoritative workflow intent envelope, preventing ambient workflow context and implicit correlation/intent drift.
- pin **capshell pipeline posture v0**: shell-like pipelines are sequences of stage-local CH-EXECPACK v2 actions; Phase 1 forbids direct peer handle/FD passing between stages, and cross-stage handoff uses existing explicit surfaces (CH-AREF digests, CH-PLUMBMSG digests, or explicit portal outputs rebound into the next stage). See `capshell-pipeline-posture-v0.md`.
- pin **capshell learn-mode posture v0**: adoption help is **observational only** — denied effects/bind failures remain denials, suggestion reports are non-authoritative and stage-local (bound at least to CH-EFFCON `contract_id`, `wallet_core_digest`, and the exact CH-ARGV exec selector), and Phase 1 forbids auto-edit/auto-approve/auto-rerun behavior or any new `capshell.learn.*` ACP/admin plane. See `capshell-learnmode-posture-v0.md`.
- add an optional runner surface **IF-CAPSHELL** that executes steps only when an explicit CH-EFFCON is present and validated.
- expose automation execution as a CH-ACP kind (e.g., `capshell.exec`) so **LLMs propose; validators execute** and receipts/transcripts remain the stable product surface.
- standardize **CH-ACPOUT v0** as a non-authoritative ACP outcome receipt (digest-only) so accept/reject outcomes are schema-pinned and tooling does not drift into ad-hoc strings.
- pin **capshell result sidecar boundary v0**: the replay-stable `capshell.exec` result remains CH-EFFCON `contract_id` + returned `digest(CH-AREF v0)` outputs; any future named-output or resource-usage structure must live in one separate digest-referenced sidecar descriptor family, not inside CH-EXECPACK/CH-ACPOUT metadata or path conventions. See `capshell-result-sidecar-boundary-v0.md`.
- keep the lane policy-killable via `cfg.params.lane.capshell` (see `config-toggle-registry.md`); when disabled, dependent actions must reject deterministically and be transcript-visible (PO-LANE-KILL).
- optionally tighten workflow ambient-authority posture via `cfg.params.capshell.minimal_context` (veto-only): when true, `capshell.exec` requires a minimal execution context (empty CH-ENV, CH-CWD `kind="empty"`, CH-STDIO `(null, drop, drop)`, empty CH-FDSET). Recommended per-profile defaults are pinned in `profile-workflow-defaults.md` (no forks).
- optionally tighten explicit workflow-intent posture via `cfg.params.capshell.require_plumbmsg` (veto-only): when true, `capshell.exec` requires CH-EXECPACK v2 to include `plumbmsg_digest = digest(CH-PLUMBMSG v0)` and validators must validate CH-PLUMBMSG before any effect. Missing intent envelopes fail closed and are transcript-visible (recommended CH-DENY code: `plumbmsg-missing`). Recommended per-profile defaults are pinned in `profile-workflow-defaults.md` (no forks).
- optionally tighten “explicit sponsorship” posture via `cfg.params.capshell.require_budget_lease` (veto-only): when true **and** `cfg.params.lane.metering=true`, `capshell.exec` requires the bound CH-REQCTX v1 to include at least one CH-BUDGET v0 lease digest (resolved + validated) so automation never runs on implicit sponsorship (D-BUDGET; I-BUDGET-1). Recommended per-profile defaults are pinned in `profile-workflow-defaults.md` (no forks).
See: RFC-0115.

## D-WALLET: capability wallet descriptors for drift gates (optional)
Options: none (default); user-space runners/portals emit **CH-WALLET v0** descriptors as non-authoritative summaries of active authority; tools use `wallet_core_digest` for prompts, receipts, and CI drift gates.
Evidence: whether we can make "what authority is active" cheap to inspect and "authority widening" cheap to reject **without** adding privileged mechanisms: closed-world inventories, strict bounds, stable authority digests, and clean composition with D-EXPLAIN (CH-CAPDIFF) and one-way tightening (D-SEAL/D-CAPMODE).
Pinned v0 posture: CH-WALLET is a **summary-only** review artifact. Phase 1 uses **`wallet_core_digest`** (normalized core only) for prompts, receipts, CI drift gates, and CH-EFFCON binding; `digest(CH-WALLET)` is correlation only. Wallets do **not** carry/import/merge authority, do not reopen descriptors, and do not replace the explicit handoff rules pinned in `wallet-posture-v0.md` and `capshell-pipeline-posture-v0.md`.
See: RFC-0116.

## D-EPHEM: disposable domains / one-shot sandboxes (optional)
Options: none (default); disposable process domains; disposable microVM domains (D-MICROVM); disposable partition cells (D-PART).
v0 stance: D-EPHEM is a **user-space posture**, not a new privileged spawn plane. Phase 1 allows digest-pinned warm templates / preloaded clones / snapshot-restore accelerators, but disposables stay **fresh one-shot instances**: no reuse after first use, no hidden persistence/session/network continuity, mandatory entropy/identity refresh before user payload runs, and persistence remains export-only (`disposable-domain-posture-v0.md`).
Evidence: whether disposables materially reduce real-world compromise persistence and improve UX for risky tasks without expanding the privileged core; ability to make exports explicit via portals (D-PLUMB) and keep disposal/teardown deterministic and auditable.

## D-QUAR: origin metadata + quarantine + safe-open defaults (optional)
Options: none (default); origin/quarantine tags only; tags + safe-open routing; tags + safe-open + sanitizing exports.
v0 stance: quarantine is **monotonic**, clear is **manual-only and object-local** (never recursive), safe-open does **not** mutate source trust in place, and any dequarantined/sanitized materialization is a **new artifact** with its own digest + transcript-visible justification. The portable safe-open request is `intent.kind=open_untrusted`: one exact `docref`, not a URI and not a `sturdyref`, with policy-chosen disposable posture, a request-local stable input object for the preview itself, an **inert-by-default viewer/runtime boundary** for document-embedded active content, a **no durable viewer residue outside the disposable** boundary for recent-doc / MRU / thumbnail / autosave / crash-recovery state, and separate explicit export/clear flows; workflows that start from CH-SREF / CH-CAPX must first cross the explicit **fresh local object** bridge pinned in `import-to-docref-boundary-v0.md`, and the resulting imported document-like object is still **quarantined by default**. Companion fresh-identity boundary: quarantine/origin are object-local rather than content-addressed trust, so equal imported bytes do not justify `reuse_existing` / aliasing onto an existing local object/docref. Companion bearer-provenance boundary: imported fresh local objects may keep one exact **`origin.import_ref_digest`** naming the accepted bearer handoff, but that breadcrumb stays digest-only evidence rather than raw bearer metadata or hidden refresh authority. Ordinary safe-open export remains **quarantined by default** unless a distinct sanitize/clear workflow says otherwise, ordinary keep/export is **fresh-destination-first** rather than overwrite-in-place, and ordinary kept output records one exact `origin.parent_digest` so the new artifact retains explicit parent evidence instead of path/filename folklore. Companion quarantined-execution boundary: quarantined exact executable/script objects do not auto-coerce into `open_untrusted`; ordinary exact execution remains deny-by-default until explicit object-local clear/override, and Phase 1 adds no portable `run_untrusted` lane. Companion quarantined code-input boundary: a cleared interpreter/runtime cannot launder a quarantined bound code object by restaging it as `stdin`, `-c`, `--eval`, module/archive entry, or another code-bearing input form. Companion safe-open active-content boundary: embedded macros, document-level scripts, external submit/fetch actions, or helper-launch callbacks must not execute or cause side effects inside `open_untrusted`; any still-exposed hyperlink/print/file effect crosses a new explicit workflow on the existing portal seam. Companion derived-attribute boundary: even explicit OCR / summarize / classify / embed workflows may not write semantic source-object attributes back onto the risky object; durable semantic fields live on a separate derived artifact instead, so smart folders/search do not start matching the source by hidden back-write. (see `quarantine-posture-v0.md`, `import-to-docref-boundary-v0.md`, `import-to-docref-fresh-identity-boundary-v0.md`, `import-to-docref-bearer-provenance-boundary-v0.md`, `open-untrusted-posture-v0.md`, `open-untrusted-materialization-boundary-v0.md`, `open-untrusted-active-content-boundary-v0.md`, `open-untrusted-viewer-residue-boundary-v0.md`, `open-untrusted-export-classification-v0.md`, `open-untrusted-export-destination-boundary-v0.md`, `open-untrusted-export-lineage-boundary-v0.md`, `quarantined-content-index-boundary-v0.md`, `quarantined-derived-attribute-boundary-v0.md`, `quarantined-execution-boundary-v0.md`, and `quarantined-code-input-boundary-v0.md`).
Evidence: whether monotonic tagging + default-to-disposable materially reduces compromise persistence; bypass resistance for extraction/container formats; ability to keep clearing explicit and transcript-logged.

## D-WASM: Wasm components as the default extension runtime (optional)
Options: native-only; Wasm for plugins/tools (default); Wasm-first user space; mixed runtime targets.
Evidence: confinement/TCO of the runtime under IF-SBX; interface typing + import closure auditing; performance; cross-ISA portability; alignment with D-CAPMODE/D-PLUMB and D-FPM supply-chain posture.

## D-IDL: interface definition + code generation (optional)
Options: handwritten marshalling (avoid); minimal IDL that generates stubs/validators; reuse an existing IDL (e.g., CAmkES-style, WIT-like, Cap’n Proto) while keeping CH-* schemas canonical.
Evidence: whether codegen shrinks `unsafe` and improves traceability (I-UNSAFE-1), keeps IF-KABI small (D-KABI/D-XS), and reduces drift between spec and implementation.
If enabled: require canonical `idl_digest` computation and stable method ordinals (CH-ORD) where CapRPC is used (RFC-0072).

## D-METER: resource accounting + denial-of-service controls (optional)
Options: none (default); meter/quota objects in the core; delegated accounting in userland.  
If enabled: treat **meters** as capability-shaped budget containers that can be split attenuation-only; any resource-creating privileged effect must name an explicit **payer** (a meter) and transcript-log a redaction-safe **CH-METER v0** descriptor digest.
Pinned v0 payer posture: payer authority is **explicit and non-ambient** (`budget-payer-semantics-v0.md`) — no portable current-payer register, no cgroup/job/container-membership fallback, and no hidden sponsor rebinding.
Evidence: whether the mechanism can stay small while enabling bounded resource consumption, clear payer attribution (avoid confused-deputy billing), and deterministic fail-closed exhaustion. Under Hybrid, replicated quota summaries remain observational only; explicit payer authority is still local at the execution site (see `quota-replication-boundary-v0.md`).


## D-KOBJQ: kernel object quotas (cap slots/endpoints) (optional)
Options: none (default); cap-slot quotas only; cap-slot + endpoint/object quotas (Genode-style).  
Evidence: whether we can prevent kernel resource exhaustion with a small mechanism (charged to meters) without enlarging IF-KABI/IF-OBS significantly.

## D-BUDGET: operation-scoped budget leases (optional)
Options: none (default); explicit budget handles required for metered effects; portal-issued budgets (common) + ad-hoc budgets (advanced).  
Evidence: whether explicit “who pays?” tokens reduce confused-deputy billing and make resource use auditable without harming ergonomics (especially for portal workflows).
Pinned v0 payer posture: no ambient current-payer or payer-lookup plane, no silent callee sponsorship default, and no container-membership payer identity; spends keep the existing additive/local semantics while mint/split/revoke serialize at the issuer seam (`budget-payer-semantics-v0.md`).
See: RFC-0058 (CH-BUDGET v0; I-BUDGET-1..3; PO-BUDGET-VALIDATE/PO-BUDGET-CHARGE/PO-BUDGET-NOIMPLICIT). Under Hybrid, replicated `budget` state remains owner-routed issuer / lease-lineage metadata only; non-owner caches may aid routing/audit/staleness checks, but they do not create portable spend authority (`budget-replication-boundary-v0.md`).

## D-PRESSURE: resource pressure + backpressure signals (optional)
Options: none (default); coarse per-container pressure levels; PSI-like stall-time signals (scoped + rate-limited).  
Evidence: whether a small, scoped observability primitive enables robust load-shedding/latency control in user space without becoming a cross-domain oracle.
See: RFC-0057 (CH-PRESSURE v0; I-PRESSURE-1..3; PO-PRESSURE-VALIDATE/PO-PRESSURE-SCOPE/PO-PRESSURE-RATELIMIT) and `pressure-posture-v0.md`.
Pinned v0 posture: pressure is **scoped observational CH-PRESSURE over IF-OBS only**; there is **no portable PSI trigger / procfs / env-var / socket protocol**, no portable client-writable pressure-watch plane, and delivery stays coarse/coalesced/rate-limited so the seam does not become a global oracle or workflow API by drift.

## D-JOBS: constraint-based background work via a job portal (optional)
Options: none (default); user-space job portal for deferrable work; optional periodic profiles; optional durability under D-PERSIST.
Evidence: whether we can eliminate ambient cron/alarms, coalesce background work for power/latency, and enforce bounded runtime (wall time + optional TCaps) without growing the privileged core.
See: RFC-0096 (CH-JOBREQ v0) and `job-portal-posture-v0.md`.
If enabled: expose job submission as an ACP kind `portal.jobs.submit` so **LLMs propose; validators execute** and outcomes are transcript-visible (CH-ACPOUT/CH-DENY); keep the lane policy-killable via `cfg.params.lane.portal.jobs` (PO-LANE-KILL; PO-ACP-JOBS-SUBMIT).

## D-BGLEASE: background execution + login autostart as leased authority (optional)
Options: none (default); background portal for background execution only; background + autostart grants with periodic review; strict profiles deny-by-default with volition for long-lived grants.
Evidence: whether we can eliminate ambient daemons/autostart registries, enforce TTL/renewal clamps, provide user-visible indicators, and compose cleanly with D-JOBS and other portalized authorities (no implicit net/file/device/location).
See: RFC-0103 (CH-BGREQ v0, CH-BGLEASE v0; I-BGREQ-1; I-BGLEASE-1..3; PO-BGREQ-VALIDATE/PO-BGLEASE-VALIDATE/PO-BGLEASE-ENF; AC-088) and `background-lease-posture-v0.md`.
If enabled: expose background grant requests as an ACP kind `portal.background.request` so **LLMs propose; validators execute** and outcomes are transcript-visible (CH-ACPOUT/CH-DENY); bind `bgreq_digest = digest(CH-BGREQ v0)` and keep the seam policy-killable via `cfg.params.lane.portal.background` (PO-LANE-KILL; PO-ACP-BGLEASE-REQUEST).


## D-INHIBITLEASE: inhibit leases for idle/suspend/logout/shutdown via a portal (optional)
Options: none (default); user-space inhibit portal issuing leased inhibition handles (delay-by-default); privileged block inhibits for system components under policy; optional monitor session for transition state updates.
v0 stance: `portal.inhibit.*` is **manual-only**, and inhibit leases are **live, close-to-release, current-session scoped** handles rather than durable registrations or future-dated keep-awake records (see `docs/30-architecture/inhibit-lease-posture-v0.md`).
Evidence: whether we can eliminate ambient keep-awake APIs, clamp TTL/renewal, and make long-lived inhibits visible and auditable without embedding power policy in the privileged core or letting D-INHIBITLEASE drift into D-JOBS/D-BGLEASE semantics.
See: RFC-0102 (CH-INHIBITLEASE v0; I-INHIBIT-1..3; PO-INHIBIT-VALIDATE/PO-INHIBIT-ENF; AC-087) and `inhibit-lease-posture-v0.md`.

## D-CAPAUD: capability graph export for audit/debug (optional)
Options: none (default); debug-only; policy-gated export via IF-OBS (CH-CAPG).  
Evidence: usefulness for leak detection and audits versus side-channel risk; ability to keep exports bounded and redacted.

## D-TCAP: temporal capabilities (time/CPU as explicit authority) (optional)
Options: none (default); temporal capabilities (TCaps) for CPU budgets/periods/priority; TCaps integrated with D-METER accounting.  
See RFC-0049 for the scheduling-context + time-donation design seam.
Evidence: ability to model and enforce time/CPU authority deterministically in early phases; whether it shrinks scheduling policy in the core while remaining mechanistic.

## D-IOBUF: copyless I/O buffer objects (optional)
Options: bounded-copy IPC only (default); immutable shared buffer objects; IO-Lite style unified buffering with explicit sharing.  
Evidence: performance vs proof/TCB cost; ability to maintain “no hidden sharing” and stable ownership semantics.
See: RFC-0084.

## D-SKB: system knowledge base / hardware facts posture (optional)
Options: none (default); user-space SKB consuming CH-HWFACT; optional CH-HWEVENT event log for post-boot fact evolution (hotplug/link state); richer query engine (CLP/Datalog) in user space; named-query IDL surface for a small set of stable queries.
Evidence: whether pushing hardware discovery/selection logic out of the privileged core shrinks TCB while keeping decisions deterministic and auditable (bind CH-HWFACT digest in CH-BOOT; bind hotplug decisions to `{epoch,event_seq}` when enabled). Cache/LLC facts under CH-HWFACT are pinned to **placement hints only** in v0; they may improve locality/scheduling, but any promotion into an ownership boundary must land as a separate RFC-first surface (`cache-topology-authority-boundary-v0.md`). Asymmetric CPU-capacity / performance-class facts are likewise pinned to **placement hints only** in v0; they may improve scheduler ranking or performance-point selection, but any promotion into cluster, budget, or replay authority must land as a separate RFC-first surface (`cpu-capacity-authority-boundary-v0.md`). NUMA-distance / HMAT latency-bandwidth / memory-tier facts are likewise pinned to **placement hints only** in v0; they may improve placement or migration ranking, but any promotion into distance-adaptive ownership, replication, or admission authority must land as a separate RFC-first surface (`memory-locality-authority-boundary-v0.md`).
Pinned posture: [`skb-posture-v0.md`](skb-posture-v0.md) (explicit CH-HWFACT/CH-HWEVENT fact base; user-space SKB only; portable queries stay named+bdd and pure/epoch-bound; no ambient inventory/probing or free-form query-language seam).
Notes: with D-DEVGUARD, treat hotplug notifications as fact-evolution events (CH-HWEVENT) so attach/detach policy remains transcript-visible and race-resistant; never treat device names/paths as authority.


## D-RR: deterministic record/replay substrate (optional)
Options: none; transcript-only replay for privileged actions; broader replay profiles with explicit nondeterminism providers (D-NONDET); full system replay for targeted profiles.  
Evidence: ability to make state evolution auditable and reproducible; hardware nondeterminism constraints; value for debugging/evidence **and** incident handoff.
Notes: treat *time-travel debugging* as a user-space ecosystem layer over CH-KABI/CH-LOG/CH-RR; optional D-CHKPT accelerates reverse queries. Replicated CH-LOG material remains evidence-only under Hybrid and must not become replay/admission/runtime-order authority (`transcript-replication-boundary-v0.md`). See RFC-0013 and `docs/60-engineering/diagnostics-stack.md`.
Additional wiring: when CH-LOG entries carry `deny_digest` (CH-DENY v0), replay/audit bundles (CH-RRBUNDLE) SHOULD include the referenced denial records (deny_stream) or explicitly declare a redaction profile that omits them (PO-RR-BUNDLE-CLOSURE).

## D-NONDET: nondeterminism authority (clock + entropy handles) (optional)
Options: ambient POSIX-like time/RNG APIs (avoid); explicit Clock/Entropy handles issued by `portal.clock`/`portal.entropy` portals (or host shims); deterministic providers for test/replay.
Evidence: ability to eliminate ambient time/entropy acquisition (I-NONDET-1), keep high-resolution timing as explicit authority (I-NONDET-2), and bind clock/entropy reads to CH-RR in replay profiles (I-NONDET-4).
See: RFC-0063 (CH-CLOCK v0, CH-ENTROPY v0).
Pinned posture: [`nondet-posture-v0.md`](nondet-posture-v0.md) (no ambient time/RNG; explicit Clock/Entropy handles; fine clocks are explicit authority).

ACP/portal seam (optional, but preferred when D-NONDET is enabled):
- Entropy handles/leases are obtained only via ACP kind `portal.entropy.request` binding `entreq_digest = digest(CH-ENTREQ v0)` (no ambient RNG constructors; lane kill switch `cfg.params.lane.portal.entropy`; PO-ACP-ENTROPY-REQUEST; I-NONDET-1).
- Clock/timeproof sampling is obtained via `portal.clock.timeproof.sample` binding `timereq_digest = digest(CH-TIMEREQ v0)` (no ambient NTP; lane kill switches `cfg.params.lane.portal.clock` + `cfg.params.lane.timeproof`).


## D-CHKPT: checkpoint/restore + migration substrate (optional)
Options: none; cooperative checkpoints (quiesce + explicit state export/import); limited checkpoints for Wasm components only; transparent user-space C/R via runtime interception (avoid for MVP).  
Evidence: ability to support debugging, fast reboot, and live upgrade/migration without violating capability invariants (no authority amplification), while keeping secret handling explicit and restore semantics bounded.

## D-UPCALL: kernel→user upcall interface for scheduling (optional)
Options: none; scheduler-activations style upcalls; event-driven vCPU model only.  
Evidence: whether upcalls reduce kernel scheduling policy while preserving isolation guarantees and not exploding concurrency proofs.
Pinned v0 posture: `upcall-posture-v0.md` (Phase 1 portable contract is **none**: **no portable kernel→user scheduling-upcall interface**, no scheduler-activations callback ABI, no timeout-fault callback plane, no event-driven vCPU contract, and no scheduler registration surface; existing TCap/wait/completion/cancellation seams already own the useful event vocabulary).

## D-CONSTR: constructor/confinement mechanism for building components (optional)
Options: none; EROS/KeyKOS-style constructor objects + confinement test; limited “service templates” only.  
Evidence: whether it shrinks authority at component boundaries, improves auditability, and stays expressible in the abstract machine. See RFC-0042.

v0 posture: `constructor-posture-v0.md` pins D-CONSTR to **ordinary user-space factory components plus confinement evidence**: constructors consume digest-pinned templates and schema-pinned **data-only** parameter objects, return only an explicit exported surface, and rely on cap-graph diff + transcript evidence rather than a constructor label. The reusable Phase 1 invocation split lives in `constructor-boundary-pattern-v0.md`: **template digests + data-only params + explicit authority-import slots + bounded export contracts + receipt bindings**, with **no generic constructor request/receipt protocol**. Phase 1 adds **no kernel constructor framework**, **no global constructor catalog/inventory**, and **no generic constructor portal family / ACP / workflow plane**. D-CONSTR introduces **no generic conflict-key family in v0**: fresh isolated instantiations commute, while any instantiation that mutates an owner-visible slot/name/export table must reuse the target seam’s existing conflict keys and ordering witnesses. The first concrete evidence target is pinned in `worker-pool-constructor-family-v0.md`: a **sandboxed worker-pool family** built from one exact `digest(CH-EXECPACK v2)` launch closure plus explicit imports/exports, with no autoscaling plane, heterogeneous mixed-image pools, or constructor-specific job protocol. `worker-pool-constructor-invocation-v0.md` then closes the remaining family-local folklore by fixing the exact invocation boundary: required imports are `sponsor`, zero or more `worker_seed/<label>` slots, and optional `install_target`; params stay data-only and bounded; exported names are canonically `pool.control` plus `worker[i]`; return-only invocations commute while install cases serialize on the target seam. `worker-pool-parameter-schema-v0.md` then fixes the exact family-local data-only parameter object itself as **CH-WPOOLPARAM v0**: one digest-first schema carrying only `pool_size` plus a per-slot restart budget (`restart.max_restarts`, `restart.window_ms`), with automatic replacement disabled exactly when both are `0`, and no capability material, import digests, or caller-chosen export labels. `worker-pool-sponsor-surface-v0.md` fixes what that required sponsor import actually means: exactly one pool-wide reviewed sponsorship root, no ambient payer/session fallback, no sponsor rotation or per-worker sponsor splits, and no sponsor-inventory/admin drift on runtime surfaces. `worker-pool-install-target-surface-v0.md` fixes what that optional install import actually means: one publication-only owner-visible target seam, exact canonical installation of `pool.control` plus `worker[i]`, all-or-nothing publication, and no rename/remap/catalog or duplicate direct-return drift. `worker-pool-seed-surface-v0.md` fixes what those repeated seed imports actually mean: each `worker_seed/<label>` binds one reviewed worker import label, the seed-label set is pool-wide and uniform across all worker slots, missing/extra labels fail closed, and Phase 1 adds no per-worker seed maps, reflected import inventories, or reseed-after-construction semantics. `worker-pool-invocation-manifest-v0.md` then fixes the exact digest-first runtime/evidence object those invocations point at: `invocation.manifest` / `invocation_manifest_digest` carry one canonical field set (`template_set_digest`, `execpack_digest`, `param_digest`, `pool_size`, import/export contract digests, exact `worker_seed_labels`, and `install_mode`) and exclude target identity, helper handles, and fresh instance state. `worker-pool-control-surface-v0.md` finally narrows the exported control handle itself: `Describe()` returns one bounded fixed-slot summary including `invocation_manifest_digest`, `BeginQuiesce(mode)` / `EndQuiesce(qid)` are the only mutators, and Phase 1 adds no scale, reseed, restart, job, or inventory/admin verbs on `pool.control`. `worker-pool-describe-summary-v0.md` then fixes the exact family-local shape of that bounded summary itself: the top-level field set is closed to `v`, `invocation_manifest_digest`, `pool_size`, `quiesce_state`, optional `qid`, and `worker_slots`; `qid` follows one exact presence rule; and `worker_slots` is one ordered gap-free slot table instead of an implementation-defined status tree. `worker-pool-quiesce-state-v0.md` then fixes the exact pool-level meaning of `quiesce_state` under that same summary: the portable pool vocabulary is closed to `running`, `quiescing`, and `quiescent`; `qid` is absent only in `running`; `quiescent` keeps the active `qid` in force until `EndQuiesce(qid)`; and Phase 1 adds no mixed/partial/mode folklore on the canonical summary surface. `worker-pool-slot-state-v0.md` then closes the remaining summary-state folklore under that handle: `worker_slots[*].state` is a closed slot-local vocabulary of exactly `starting`, `running`, `backoff`, `failed`, and `quiescing`; there is no separate per-slot `quiescent` or restart/debug taxonomy; `backoff` is the only temporary-unavailable state; and active pool quiesce suppresses automatic `backoff -> starting` re-entry until `EndQuiesce(qid)` releases admission again. `worker-pool-restart-budget-v0.md` then closes the remaining operational folklore behind `restart.max_restarts` / `restart.window_ms`: the budget is per-slot, counts only automatic `backoff -> starting` admissions, the initial fresh occupant does not consume budget, disabled budgets fail closed directly to `failed`, and successful occupancy only ages admissions out of the trailing window instead of side-resetting them. `worker-pool-worker-surface-v0.md` then narrows the exported worker handles themselves: each `worker[i]` is a slot-stable typed entry handle for the pinned worker closure, not a raw occupant identity token or per-worker admin wrapper, and Phase 1 adds no transparent session continuity or per-worker lifecycle/debug verbs on that handle. `docs/40-verification/worker-pool-capgraph-snapshots-v0.md` closes the remaining cap-graph member folklore by fixing `capgraph.before` / `capgraph.after` as caller-scoped same-profile `CH-CAPG v0` receipts, compared only on the normalized caller-reachable delta over exactly `pool.control` plus `worker[i]`, with no whole-system or helper-visible graph dumps. `docs/40-verification/worker-pool-target-projection-v0.md` closes the install-only target-seam evidence gap by fixing `target.before` / `target.after` as `CH-SPROJ v0` receipts over the same target-seam `(family, key_digest)` pair, each carrying one canonical digest over exactly `pool.control` plus `worker[i]` and no target-name or inventory folklore. `docs/40-verification/worker-pool-transcript-slice-v0.md` closes the remaining transcript folklore by fixing `transcript.slice` as a case-indexed bounded window set over ordered `CH-LOG v0` references, with stable case ids and `primary` / `swapped` order variants instead of whole-log dumps or tool-local transcript layouts. `docs/40-verification/worker-pool-verdict-summary-v0.md` then closes the remaining result-summary folklore by fixing `verdict.summary` as one exact case-indexed verdict table over the canonical worker-pool export shape, with explicit `delta_predicate_ok` / `replay_predicate_ok` bits instead of prose-only or flaky/warning status drift. See `constructor-posture-v0.md`.

## D-MEMMODEL: memory model stance (SMP/Hybrid baseline)
Options:
- small, explicit primitive set for privileged code (e.g., single-copy atomic + acquire/release + fences); forbid ad-hoc atomics
- stronger ordering for simplicity (at explicit performance cost)
- architecture-specific axioms with a pinned litmus suite per target ISA

Evidence: existence of tractable model checks/litmus suites (PO-MEM-LITMUS); ability to link concrete atomic/fence patterns to invariants and to D-COMMUTE conflict-key/ordering boundaries under multicore execution (I-CONC-1).

## D-DMA: DMA model
Options: IOMMU-required; devices-in-TCB; constrained I/O (no DMA).  
Evidence: threat-model requirements; hardware availability; ability to make C-ISO-2 either provable or explicitly weakened.

v0 posture: Phase 1 treats DMA-aware isolation as **fail-closed**: if we claim C-ISO-2,
the active posture must be **IOMMU/SMMU required**; otherwise DMA-class attach/lease flows
deny-by-default and C-ISO-2 is not claimed. Pinned in `dma-posture-v0.md`.

## D-ADDRNET: address translation synthesis posture (optional)
Options: ad-hoc platform code (avoid); CH-ADDRNET + generator/checker pipeline; mechanized refinement later.  
Evidence: whether we can treat page-table/IOMMU setup as a pinned artifact with validation (PO-ADDRNET-VALIDATE) and eventually mechanized correspondence (PO-PTGEN-CORRECT) without bloating the privileged core.

## D-DRVDOM: driver domains / deprivileged device logic (optional)
Options: in-kernel drivers; user-space driver domains with IO resource caps; mixed (critical drivers only).  
Evidence: TCB reduction vs performance/complexity; ability to mediate MMIO/IRQ/DMA via explicit objects and satisfy I-DMA-1/I-IORES-1 under A-DMA-1.
See: RFC-0008, RFC-0045, RFC-0083.

## D-DEVGUARD: device authorization and hotplug portals (optional)
Options: ambient devfs/udev-like device exposure (avoid); deny-by-default hotplug + explicit attach portals; allow only into a dedicated peripheral domain; deterministic rule policy as data (CH-DEVGUARD).  
Evidence: ability to treat peripherals as explicit capability grants, preserve transcript visibility, and fail closed when DMA posture cannot be met (D-DMA).  
v0 posture: Phase 1 device attach/lease workflows are manual-only via `portal.device.*` (no ACP kind); no ambient device namespace; consent receipts required. Future automation is pre-committed to `family="device.id"` conflict keys bound to explicit typed `device_id` values rather than paths/serials/UI labels, and OQ-0009 is resolved by pinning `device.id` as the **only** future ACP-visible attach-policy ordering family (queue/endpoint sequencing stays below the policy seam). Pinned in `io-lease-posture-v0.md` and `device-lease-ordering-boundary-v0.md`.  
See: RFC-0085, RFC-0045.

## D-IOLEASE: device leasing / data-plane bypass for I/O (optional)
Options: none (default); lease bounded device queues/resources to user space (driver domains/library dataplanes); kernel/hypervisor stays control-plane only.
Evidence: ability to keep device models out of the TCB while maintaining DMA containment (D-DMA/D-ADDRNET) and explicit authorization/logging for lease grant/revoke.
v0 posture: Phase 1 lease issuance is manual-only via `portal.device.*` and requires CH-RECEIPT; automation surfaces are deferred. When automation arrives, attach/grant/revoke ordering/serialization keys only on `device.id` (`device_key = ck_id("device.id", device_id)`); queue-local details stay internal to the granted lease / driver host rather than a second portal policy family. Pinned in `io-lease-posture-v0.md` and `device-lease-ordering-boundary-v0.md`.
See: RFC-0045.


## D-FCELL: Foreign Cell compatibility membrane (sealed legacy/POSIX lane)
Options: none (default); enable a **Foreign Cell** lane with an explicit, fail-closed membrane contract ([foreign-cell-contract.md](foreign-cell-contract.md)) and non-authoritative launch manifests (CH-FCELL v0).

Evidence:
- ability to keep the privileged core unchanged while hosting a legacy ABI
- negative tests for ambient filesystem/network/time acquisition from inside the cell (AC-071)
- policy-killable behavior (boot-time and runtime) with deterministic failures
- compatibility membrane invariants remain satisfied (I-COMPAT-1/I-COMPAT-2/I-FCELL-1)

Notes:
- v0 CH-FCELL manifest validators MUST accept only `runtime.kind="rump"` (reserved kinds reject) per `rumpk-selection-posture-v0.md` (keeps sealed compat honest).
- D-FCELL pins the *membrane*. D-RUMPK selects the runtime strategy inside the cell.
- The lane kill switch is `cfg.params.lane.fcell` (see `config-toggle-registry.md`); when disabled, `fcell.*` actions reject deterministically and emit receipt/log evidence (PO-LANE-KILL).
- Adapter-mediated interop is additionally killable per adapter kind via `cfg.params.lane.fcell.adapter.<adapter_kind>` (normalize `.`→`_`) checked alongside the bound portal lane gate (fail closed; PO-LANE-KILL).
- Adapter-mediated host effects on behalf of a cell MUST be portalized and accompanied by per-op CH-FADAPT receipts (v0 or v1) (portal token + issued handle digests), enabling mechanical “interop only via portals/intents/receipts” audits (PO-FADAPT-EMIT). In profiles that propagate request context end-to-end, CH-FADAPT v1 MAY carry `reqctx_digest = digest(CH-REQCTX v1)` as a non-authoritative correlation/veto-only hook.
- Adapter kinds are a closed, reviewable set in `fcell-adapter-kind-registry.md` (prevents compat interop drift and keeps audits mechanical).
- Adapter receipts participate in D-COMMUTE via derived `cell.adapter` conflict keys and optional ordering witnesses (CH-CONFLICTKEY/CH-ORDERTOK); see `fcell-commutativity-contract-v0.md`.


## D-RUMPK: rump-kernel compatibility domains for legacy drivers/FS (optional)
Options: none (default); use rump kernels for untrusted filesystem images only; broaden to selected network/storage drivers; hosted rump domains as a driver-dev/test tool; alternative compatibility runtimes (Linux-kernel-library / userspace-kernel / library-OS picoprocess) for legacy stacks.
Evidence: time-to-hardware/portability wins versus code-volume risk; ability to keep the privileged core unchanged by running legacy subsystems in isolated domains; membrane must satisfy D-FCELL and remain capability-mediated (I-COMPAT-1/I-COMPAT-2); performance and memory overhead; ergonomics of exposing compat-backed services via translators (D-TRANS) and views (D-NS).
v0 posture: pin the initial internal runtime choice and scope (rump kernels, filesystem-image handling only) in `rumpk-selection-posture-v0.md`.
See: RFC-0036, RFC-0083.


## D-BOOT: boot/update model
Options: verified boot; measured boot; both; anti-rollback.  
Evidence: operational needs; supply-chain attacker model (ADV-SUPPLY); reproducibility feasibility.

## D-ATTEST: device attestation posture (optional)
Options: none (default); produce an attestation token bound to CH-BOOT (CH-ATTEST) using a hardware RoT (e.g., DICE/TPM/TEE) and optionally align claims with EAT.
Evidence: whether verifiers can check binding (boot digest, policy revision) and freshness under explicit assumptions without adding privileged complexity; operational value for update gates and fleet integrity.
v0 posture: pin the Phase 1 meaning of remote attestation as a **boot-bound, observational token export** (CH-ATTEST v0) with a **policy-killable** export surface (`cfg.params.lane.attest.export`), no privileged provider-specific parsing, and explicit (optional) freshness. Companion endorsement/reference boundary: endorsement/reference inputs remain verifier-local appraisal material, IF-ATTEST exports no live fetch/query plane, and `endorsement_aref_digests` stay exact artifact hints rather than latest-applicable truth (`attestation-endorsement-boundary-v0.md`). Under `ext.microvm`, generation change invalidates freshness-bound attestation exports and any attestation-gated release sessions instead of resuming them across clone/restore. See `attestation-posture-v0.md`, `attestation-endorsement-boundary-v0.md`, and `microvm-attestation-reacquire-posture-v0.md`.

## D-PCP: proof-carrying provenance target
Options: “attest build only” (C-PROV-1); “end-to-end binding” (C-PROV-2); “release-only PCP” vs “every boot PCP”.  
Evidence: whether we can bind running binaries to source+spec+proof bundles without ballooning TCB; operational viability; verifier simplicity.
v0 posture: **release-only PCP** (CI/release artifact); boot-time verification stays small: IF-BOOT verifies binding (PO-PROV-BIND) when enabled, but does not validate bulky proofs/models. CH-PROV meaning is pinned separately in `docs/30-architecture/provenance-posture-v0.md`: digest-bound build provenance evidence only, no release-registry/verdict/query semantics. Companion release-identity boundary: release names/version labels remain observational distribution identifiers rather than install or verdict authority (`release-identity-boundary-v0.md`). Verification-verdict boundary: verification stays consumer-local evaluation of exact evidence under local policy, with no native verified-good/waiver/latest-verified plane (`verification-verdict-boundary-v0.md`). Companion `provenance-required-subject-boundary-v0.md` further pins that local policy may require provenance only for exact already-pinned carrier digests rather than every subject in a larger release attestation. Companion `provenance-coverage-policy-boundary-v0.md` further pins that carrier-borne provenance fields name exact evidence bytes only and do not choose which provenance-coverage policy is in force. Companion `provenance-container-selection-boundary-v0.md` further pins that imported multi-statement provenance containers remain packaging only rather than a native union/preference/completeness rule. Companion `provenance-evidence-set-boundary-v0.md` further pins that multiple exact provenance-bearing artifacts do not jointly define a native provenance closure or fallback rule. Pinned in `docs/60-engineering/pcp-posture-v0.md`.
Companion `proof-bundle-role-boundary-v0.md` further pins that `proof_bundle` remains a descriptive adjunct-evidence role rather than a native proof/verdict schema.


## D-AREF: artifact references / content-addressed evidence (optional)
Options: none (default); allow CH-AREF pointers for heavyweight evidence (proofs, corpora, logs); optional external CAS backing; policy-gated locator schemes.
Evidence: ability to keep the archive small while preserving mechanical checkability (digest binding), and avoid locator-based attacks (scheme allowlists; fail closed) (I-AREF-1).
See: `artifact-resolution-posture-v0.md` (v0: no privileged locator dereference; resolution is portalized and lane-killable).
## D-TLOG: transparency-log anchoring for evidence (optional)
Options: none (default); publish signed digests to an external transparency log (CH-TLOG anchors); run a private tile-based log for releases.  
Evidence: operational value for independent auditing; tooling maturity; keeping this entirely out-of-band (no kernel dependency).
v0 posture: transparency-log material remains an **evidence lane only**. CH-TLOG binds one exact artifact digest to one exact append-only log state, inclusion evidence is not complete log verification, checkpoint order must not become runtime admission/control/time authority, and Phase 1 adds no native latest/query/watch/admin plane (`transparency-log-posture-v0.md`, `tlog-replication-boundary-v0.md`). Offline inclusion+witness proof transport is a separate exact import seam: portable handoff prefers C2SP `tlog-proof@v1` (or another explicit exact external proof artifact) referenced by digest, while `CH-TLOG` itself stays small and does not grow inline witness/proof payloads (`transparency-proof-import-boundary-v0.md`). Reviewer/endorser statements anchored through transparency remain evidence imports only; Phase 1 adds no native verified-good/waiver/latest-verified plane (`verification-verdict-boundary-v0.md`).
Companion `proof-bundle-role-boundary-v0.md` further pins that `proof_bundle` / `proof_bundle_digest` denote exact adjunct bundle bytes only rather than a native proof/verdict schema.

## D-WITNESS: witnessed checkpoints for transparency logs (optional)
Options: none (default); require threshold witness signatures over log checkpoints for “audit-complete” releases; optionally anchor to multiple independent logs.
Evidence: availability of practical witness stacks (or independent operators), cost/ops overhead, and whether witnessed checkpoints meaningfully reduce split-view/equivocation risk without coupling boot to external infrastructure.
v0 posture: witness material is **explicit optional corroboration only**. Threshold witness signatures strengthen split-view resistance when checked against a locally pinned witness set and threshold, but witnesses do not auto-enroll trust, rotate quorums, or turn checkpoints into install/freshness authority (`transparency-log-posture-v0.md`). The narrower witness-policy seam is pinned in `transparency-witness-acceptance-boundary-v0.md`: checkpoint signatures do not define the trusted witness set, quorum, or any “audit-complete” conclusion. Portable offline inclusion+witness handoff is pinned separately in `transparency-proof-import-boundary-v0.md`: proof bytes travel as an exact external artifact rather than inline `CH-TLOG` cargo or a second native proof schema.

## D-UPD-SIGN: signature posture for update/config artifacts
Options: embedded signatures in CH-*; detached envelope objects (CH-SIGENV / DSSE-style); hybrid; optional keyless profiles (D-KEYLESS) that accept cert-bound identities.  
Evidence: verifier simplicity (B0/B3), distribution constraints, unambiguous binding to digests.

## D-SIGENV: signature envelope format for signed CH-* payloads (optional)
Options: none (default early); CH-SIGENV v0 (DSSE-style type+digest binding) as the canonical envelope; embedded vs detached distribution.  
Evidence: prevent type-confusion; make verification tooling uniform; keep verifiers small; interop with TUF (D-TUF) and transparency anchors (D-TLOG).
v0 posture: **typed digest-binding plus local policy**. Accepted meaning is the verified binding of `(payload.schema, payload.digest)`; verification is offline-first and policy-local, signer hints are non-authoritative, and transparency/timestamp material remains evidence rather than a hidden online dependency. Exact signing-time evidence is pinned separately in `signing-time-evidence-boundary-v0.md`: payload-only timestamps do not automatically prove signature creation time, and timestamp material never becomes freshness/approval/time-admin authority by itself. Certificate/path inputs are pinned separately in `certificate-path-input-boundary-v0.md`: AIA / `caIssuers` locator fields are hints only, presented chains do not auto-expand trust, and Phase 1 adds no native AIA/caIssuers/alternate-chain plane. Certificate-status handling is pinned separately in `certificate-status-evidence-boundary-v0.md`: CRL / delta-CRL / OCSP locators are hints only, status artifacts remain exact local evidence rather than portable approval/install authority, and Phase 1 adds no native OCSP/CRL/status-cache plane. Certificate identity interpretation is pinned separately in `certificate-identity-evidence-boundary-v0.md`: SAN / subject / issuer / custom OID fields remain exact signed evidence under explicit local interpretation, EKU / policy OIDs remain verifier-local predicates, and Phase 1 adds no native best-identity/wildcard-grammar/repo-owner lookup plane. Signature trust roots are pinned separately in `signature-trust-root-boundary-v0.md`: trusted roots stay explicit local verifier input or explicit D-TUF/provisioning artifacts, trusted-root carriers remain adjunct artifacts, and Phase 1 adds no native trusted-root/self-anchoring/service-discovery plane. Signature-algorithm acceptance is pinned separately in `signature-algorithm-acceptance-boundary-v0.md`: algorithm identifiers remain exact signed evidence, accepted signature/message algorithms stay explicit verifier-local policy, multi-signature records do not create strongest-wins negotiation, and Phase 1 adds no native algorithm-negotiation/capability-advertisement plane. Keyless issuer discovery is pinned separately in `keyless-issuer-discovery-boundary-v0.md`: OIDC/OAuth issuer metadata and SigningConfig-style service descriptors remain signer/client online config, keyless verification does not require `.well-known` / OAuth metadata / JWKS / UserInfo / introspection fetch, and Phase 1 adds no native issuer-discovery/.well-known/JWKS plane. Verification-material discovery is pinned separately in `verification-material-discovery-boundary-v0.md`: explicit artifact bytes and explicit verification-material artifacts remain authoritative, sidecar/referrer lookup stays tooling-only, and Phase 1 adds no native sidecar/referrer/registry-discovery plane. Successful CH-SIGENV verification is evidence, not a portable approval verdict, and Phase 1 adds no native verified-good/waiver/latest-verified plane (`verification-verdict-boundary-v0.md`). Pinned in `signature-envelope-posture-v0.md`.
See: RFC-0093.

## D-KEYLESS: keyless signing posture (Sigstore-style) (optional)
Options: none (default); accept `keyless_cert` signatures under issuer+identity allowlists; higher-assurance channels may require a transparency anchor (D-TLOG) and short validity windows.  
Evidence: operational burden reduction vs reliance on external identity/CA infrastructure; time/freshness interactions; revocation/incident workflows; audit value of public logs.
v0 posture: **optional explicit issuer/identity policy only**. If enabled, keyless admission requires explicit issuer allowlists, identity checks, certificate-validity checks under D-TIME, accepted signature/message algorithms remain explicit verifier-local policy under `signature-algorithm-acceptance-boundary-v0.md`, explicit verifier-local certificate/path inputs under `certificate-path-input-boundary-v0.md`, explicit local certificate-status policy under `certificate-status-evidence-boundary-v0.md`, explicit local interpretation of SAN / subject / custom-OID claims under `certificate-identity-evidence-boundary-v0.md`, trusted roots stay explicit local verifier input or explicit D-TUF/provisioning artifacts under `signature-trust-root-boundary-v0.md`, and OIDC/OAuth discovery metadata and SigningConfig-style service descriptors remain signer/client online config under `keyless-issuer-discovery-boundary-v0.md`; Phase 1 adds no portable repo-owner/account-status lookup, browser login loop, or ambient Fulcio/Rekor dependency, and no native issuer-discovery/.well-known/JWKS plane. Pinned in `signature-envelope-posture-v0.md`.
See: RFC-0093.


## D-ENC: canonical encoding and hashing
Options:
- **Canonical CBOR (recommended):** canonical CBOR (REF-CBOR-RFC8949) as the *normative bytes* for all CH-* payloads.
- **Authoring JSON (optional):** accept JSON for human authoring only, but require JCS canonicalization (REF-JCS-RFC8785) and deterministic transcoding to canonical CBOR before hashing/signing.
- **Other (defer):** protobuf-with-canonicalization or a bespoke format (avoid early unless evidence forces it).

Evidence:
- deterministic decode + stable hashing as a security primitive (I-ENC-1; PO-ENC-DECODE)
- parser auditability and "fail closed" behavior under malformed inputs
- ability to keep schema evolution disciplined (closed enums; reject unknown keys by default)

v0 posture (pinned for hashing semantics):
- `digest(CH-XYZ vN)` hashes the schema's **canonical bytes** as defined in `schema-canonical-bytes-v0.md`.

## D-MICROVM: microVM profile (hypervisor-first slice)
Options: minimal paravirt device set; “no emulation” (fail-closed); limited emulation (declared + closed).  
Evidence: exit-surface budget; device-model TCB; whether the profile yields a compelling A2/A3 slice.

v0 posture (pinned for Phase 1 scope discipline):
- `ext.microvm` means **virtio-first, declared, and fail-closed** (no hidden devices).
- v0 includes **no legacy emulation** (ACPI/BIOS-era glue; broad PCI(e) ecosystem).
- microVM is **not** a compatibility escape hatch; Phase 1 does not adopt “run Linux guests” as a hidden POSIX/legacy path.
- See: `microvm-profile-posture-v0.md`, `host-guest-channel-posture-v0.md`, `microvm-memory-topology-posture-v0.md`, `microvm-cpu-topology-posture-v0.md`, `microvm-cache-hierarchy-posture-v0.md`, `microvm-numa-topology-posture-v0.md`, `microvm-nested-virt-posture-v0.md`, `microvm-network-topology-posture-v0.md`, `microvm-network-feature-posture-v0.md`, `microvm-block-topology-posture-v0.md`, `microvm-persistent-memory-posture-v0.md`, `microvm-memory-backing-posture-v0.md`, `microvm-page-tracking-posture-v0.md`, `microvm-memory-dedup-posture-v0.md`, `microvm-console-channel-posture-v0.md`, `microvm-bootstrap-metadata-posture-v0.md`, `microvm-entropy-surface-posture-v0.md`, `microvm-tpm-surface-posture-v0.md`, `microvm-device-passthrough-posture-v0.md`, `microvm-virtual-iommu-posture-v0.md`, `microvm-backend-offload-posture-v0.md`, `microvm-lifecycle-signal-posture-v0.md`, `microvm-display-input-posture-v0.md`, `microvm-audio-capture-posture-v0.md`, `microvm-usb-redirection-posture-v0.md`, `microvm-virtio-serial-port-posture-v0.md`, `microvm-clipboard-dragdrop-posture-v0.md`, `microvm-shared-memory-doorbell-posture-v0.md`, `microvm-bus-topology-posture-v0.md`, `microvm-interrupt-topology-posture-v0.md`, `microvm-platform-identity-posture-v0.md`, `microvm-firmware-state-posture-v0.md`, `microvm-time-source-posture-v0.md`, `microvm-crash-report-surface-posture-v0.md`, `microvm-pmu-profiling-posture-v0.md`, `microvm-paravirt-enlightenment-posture-v0.md`, `microvm-semihosting-posture-v0.md`, `microvm-guest-agent-posture-v0.md`, `microvm-debug-introspection-posture-v0.md`, `microvm-management-api-posture-v0.md`, `microvm-live-migration-posture-v0.md`, `microvm-snapshot-posture-v0.md`, `microvm-generation-witness-posture-v0.md`, `microvm-clock-disruption-posture-v0.md`, `microvm-attestation-reacquire-posture-v0.md`, `microvm-attestation-scope-posture-v0.md`, `microvm-resume-admission-evidence-posture-v0.md`, `microvm-template-snapshot-cut-posture-v0.md`, `microvm-template-lineage-posture-v0.md`, `microvm-template-resume-class-posture-v0.md`, `microvm-restore-repair-barrier-posture-v0.md`, `microvm-template-distribution-posture-v0.md`, and `microvm-template-availability-posture-v0.md`.
- Guest-visible memory topology is fixed at admission: Phase 1 adds no portable balloon / virtio-mem / ACPI memory-hotplug control/status plane, and changing guest-visible RAM means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity (`microvm-memory-topology-posture-v0.md`).
- Guest-visible CPU topology is fixed at admission too: Phase 1 adds no portable vCPU hotplug / CPU online-offline / hotpluggable-slot control/status plane, and changing guest-visible vCPU count/topology or SMT means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity (`microvm-cpu-topology-posture-v0.md`).
- Guest-visible cache hierarchy and cache-QoS meaning are pinned too: Phase 1 adds no portable guest-visible L1/L2/L3 cache inventory or cache-sharing-topology plane and no portable CAT / CDP / CMT cache-allocation-or-monitoring plane, so any owner-local cache descriptor shaping, partitioning, or monitoring remains implementation-local and reviewed CPU / placement / performance meaning stays on explicit admission / topology / observation seams rather than ambient cache descriptors or QoS knobs (`microvm-cache-hierarchy-posture-v0.md`).
- Guest-visible NUMA / proximity-domain topology is pinned too: Phase 1 adds no portable guest NUMA-node / CPU-to-node / memory-to-node plane and no portable SLIT / HMAT latency-bandwidth-memory-side-cache plane, so any owner-local locality shaping, distance tuning, or heterogeneous-memory hinting remains implementation-local and reviewed memory / CPU / placement meaning stays on explicit admission / topology seams rather than ambient guest locality tables (`microvm-numa-topology-posture-v0.md`).
- Guest-visible nested virtualization is pinned too: Phase 1 adds no portable VMX / SVM / guest-hypervisor-acceleration plane and no portable nested-specific enlightenment-or-assist plane, so any owner-local nested enablement, CPU-feature passthrough, or L1 optimization choice remains implementation-local and reviewed compatibility / isolation meaning stays on explicit D-FCELL and activation seams rather than ambient guest hypervisor capability (`microvm-nested-virt-posture-v0.md`).
- Guest-visible network topology is fixed at admission too: Phase 1 adds no portable NIC hotplug / attach-detach / link-state / interface-status control/status plane, and changing guest-visible NIC inventory/topology means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity (`microvm-network-topology-posture-v0.md`).
- Guest-visible NIC acceleration/tuning meaning is pinned too: Phase 1 adds no portable multiqueue / RSS / hash-report / offload / queue-size / speed-duplex plane, so any owner-local queue budgeting, ring sizing, RSS steering, packet-hash export, mergeable-buffer choice, or host/guest offload exposure remains implementation-local and reviewed network authority / performance / observation meaning stays on explicit D-NETLEASE / topology / observation seams rather than ambient virtio-net tuning knobs (`microvm-network-feature-posture-v0.md`).
- Guest-visible block topology is fixed at admission too: Phase 1 adds no portable disk hotplug / hot-remove / media-insert-eject / tray-or-device-status control/status plane, and changing guest-visible block-device inventory/topology means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity (`microvm-block-topology-posture-v0.md`).
- Guest-visible persistent-memory meaning is pinned too: Phase 1 adds no portable `virtio-pmem` / NVDIMM / persistent-memory-flush-or-durability plane, no portable boot-from-pmem or DAX-rootfs contract, owner-local backing-file / DAX / flush discipline remains implementation-local, and reviewed storage / provenance / boot meaning stays on explicit block / verity / activation seams rather than ambient guest pmem devices (`microvm-persistent-memory-posture-v0.md`).
- Host-side guest-RAM backing is pinned too: Phase 1 adds no portable anonymous-vs-file-vs-memfd-vs-shm backing plane, no portable hugepages / THP / prefault / prealloc / shared-mapping plane, owner-local backing-file path, memfd sealing, mapping flags, and page-size choice remain implementation-local, and reviewed memory / snapshot / backend-offload / performance meaning stays on explicit topology / snapshot / offload seams rather than ambient host memory-backing modes (`microvm-memory-backing-posture-v0.md`).
- Host-side guest-memory page tracking is pinned too: Phase 1 adds no portable dirty-log / dirty-ring / page-access-bitmap / dirty-rate / working-set-estimation plane, owner-local write-protect / clear-and-reprotect / ring-sizing / throttling / diff-snapshot accounting policy remains implementation-local, and reviewed snapshot / migration / observation / performance meaning stays on explicit snapshot / migration / admission / observation seams rather than ambient VMM page-tracking machinery (`microvm-page-tracking-posture-v0.md`).
- Host-side guest-memory dedup is pinned too: Phase 1 adds no portable `mem-merge` / mergeable-memory / KSM plane, no portable merged-page / page-sharing-status contract, owner-local `MADV_MERGEABLE` marking and KSM scan policy remain implementation-local, and reviewed memory-isolation / tenancy meaning stays on explicit admission / topology seams rather than ambient content-based page sharing (`microvm-memory-dedup-posture-v0.md`).
- Guest-visible serial/console directionality is fixed at admission too: Phase 1 adds no portable interactive serial/console input, no console/monitor multiplex or backend-status plane, and any admitted serial/console surface is off/null or a write-only diagnostic sink rather than a host control channel (`microvm-console-channel-posture-v0.md`).
- Guest-visible metadata/bootstrap channels are absent too: Phase 1 adds no portable MMDS / IMDS / fw_cfg / config-drive / cloud-init datasource plane, so bootstrap authority rides on reviewed boot artifacts or explicit post-boot seams instead of a hidden host metadata path (`microvm-bootstrap-metadata-posture-v0.md`).
- Guest-visible entropy-device/source meaning is pinned too: Phase 1 adds no portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality-status plane, owner-local boot seeding stays implementation-local, and post-init entropy authority still rides on explicit D-NONDET seams rather than ambient guest device reads (`microvm-entropy-surface-posture-v0.md`).
- Guest-visible TPM/vTPM meaning is pinned too: Phase 1 adds no portable TPM2 command-status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane, owner-local TPM enablement/backend choice stays implementation-local, and attestation/key-sealing meaning still rides on explicit D-ATTEST and D-CRYPTOSVC seams rather than ambient guest TPM device calls (`microvm-tpm-surface-posture-v0.md`).
- Guest-visible device-passthrough meaning is pinned too: Phase 1 adds no portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane, owner-local host binding/attachment details stay implementation-local, and DMA-class device authority still rides on explicit D-DMA and D-IOLEASE seams rather than ambient guest passthrough devices (`microvm-device-passthrough-posture-v0.md`).
- Guest-visible vIOMMU meaning is pinned too: Phase 1 adds no portable `virtio-iommu` / domain-endpoint-attach / map-unmap / fault-status / address-width plane, owner-local vIOMMU enablement and endpoint placement stay implementation-local, and DMA meaning still rides on explicit D-DMA and D-IOLEASE seams rather than ambient guest remap control (`microvm-virtual-iommu-posture-v0.md`).
- Host-side backend offload meaning is pinned too: Phase 1 adds no portable `vhost-user` / `vhost-vdpa` / `VDUSE` / backend-socket / queue-handoff / backend-rebind-status plane, so any owner-local external backend process/device choice remains implementation-local and does not become a portable host control channel or guest-visible runtime API (`microvm-backend-offload-posture-v0.md`).
- Guest-visible display/input meaning is pinned too: Phase 1 adds no portable `virtio-gpu` / scanout / EDID / cursor / capset / `virtio-input` / raw-input-event-device-inventory plane, so any owner-local renderer stack, display-forwarding path, or host input plumbing remains implementation-local and trusted UI/capture/remote-control meaning stays on explicit D-UICAP and D-PLUMB seams rather than ambient guest devices (`microvm-display-input-posture-v0.md`).
- Guest-visible audio/capture meaning is pinned too: Phase 1 adds no portable `virtio-snd` / playback-capture-stream-mixer-jack-chmap plane, so any owner-local audio backend or media graph remains implementation-local and microphone/system-audio capture meaning stays on explicit D-CAPTURE, D-UICAP, and D-PLUMB seams rather than ambient guest devices (`microvm-audio-capture-posture-v0.md`).
- Guest-visible USB redirection is pinned too: Phase 1 adds no portable `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane, so any owner-local client-device forwarding stack, filter policy, or proxy helper remains implementation-local and reviewed device / capture / credential meaning stays on explicit D-IOLEASE and already-pinned portal seams rather than ambient redirected USB buses (`microvm-usb-redirection-posture-v0.md`).
- Guest-visible `virtio-serial` / named-port meaning is pinned too: Phase 1 adds no portable `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane, so any owner-local helper-channel naming, guest-path binding, or host chardev/socket wiring remains implementation-local and reviewed console / transfer / guest-helper meaning stays on already-pinned explicit seams rather than ambient helper ports (`microvm-virtio-serial-port-posture-v0.md`).
- Guest-visible shared-memory/doorbell meaning is pinned too: Phase 1 adds no portable `ivshmem-plain` / `ivshmem-doorbell` / `ivshmem-flat` / peer-id / shared-memory-region / interrupt-doorbell plane, so any owner-local shared-memory server, FD distribution, or peer interrupt plumbing remains implementation-local and reviewed shared-region meaning stays on explicit D-IOBUF and D-PLUMB seams rather than ambient guest BARs or peer-notify devices (`microvm-shared-memory-doorbell-posture-v0.md`).
- Guest-visible bus topology meaning is pinned too: Phase 1 adds no portable PCI-vs-MMIO transport promise, no stable PCI-BDF / segment / root-port / slot / ACPI-device-path inventory contract, and no bus-rescan / hotplug / address-assignment plane, so any owner-local bus layout, address allocation, or enumeration strategy remains implementation-local and policy-significant topology changes still require new admission rather than a live bus-admin control plane (`microvm-bus-topology-posture-v0.md`).
- Guest-visible interrupt topology meaning is pinned too: Phase 1 adds no portable APIC / PIC / IOAPIC / GIC controller-model plane, no portable IRQ / GSI / vector / MSI routing or interrupt-remapping plane, owner-local irqchip mode, controller placement, and vector allocation remain implementation-local, and policy-significant interrupt-topology changes still require new admission rather than a live guest-visible rewire plane (`microvm-interrupt-topology-posture-v0.md`).
- Guest-visible platform identity meaning is pinned too: Phase 1 adds no portable CPUID vendor / brand / hypervisor-signature plane, no portable SMBIOS / DMI manufacturer / product / serial / UUID / OEM-string identity plane, owner-local branding and feature masking remain implementation-local, and provenance / attestation meaning stays on explicit D-ATTEST plus deployment evidence rather than ambient guest probes (`microvm-platform-identity-posture-v0.md`).
- Guest-visible firmware description meaning is pinned too: Phase 1 adds no portable ACPI table-set / namespace / AML plane, no portable device-tree node/property vocabulary, and no portable EFI configuration-table / firmware-table inventory or override plane, so owner-local ACPI-vs-DTB-vs-firmware choice remains implementation-local and portable meaning stays on already-pinned bus / interrupt / lifecycle / bootstrap / identity seams rather than ambient table probes (`microvm-firmware-description-posture-v0.md`).
- Guest-visible firmware state is pinned too: Phase 1 adds no portable UEFI variable-store / `Boot####`-`BootOrder`-`BootNext` plane, no portable Secure-Boot key-enrollment or signature-database plane, and no guest-triggerable `SetVariable()` admin contract, so owner-local firmware-state persistence/protection remains implementation-local and provenance/lifecycle meaning stays on explicit activation / attestation evidence rather than ambient firmware-variable reads (`microvm-firmware-state-posture-v0.md`).
- Guest-visible clocksource and wall-clock policy are pinned too: Phase 1 adds no portable clocksource-name plane, no portable RTC base / progression policy plane, and no guest-visible set-clock or source-switch admin plane, so owner-local clocksource shaping remains implementation-local and authority-bearing time stays on explicit D-NONDET / D-TIMEPROOF seams rather than ambient guest time reads (`microvm-time-source-posture-v0.md`).
- Guest-visible panic and crash-reporting surfaces are pinned too: Phase 1 adds no portable `pvpanic` / guest-panicked notification plane, no portable `vmcoreinfo` dump-note plane, and no portable `pstore`-ERST-ramoops crash-record plane, so owner-local panic notification and crash-record storage remain implementation-local and shareable failure evidence stays on explicit D-OBS / D-INSPECT / D-FLIGHTREC / `CH-CRASHCAP` seams rather than ambient guest devices or filesystems (`microvm-crash-report-surface-posture-v0.md`).
- Guest-visible PMU/profiling surfaces are pinned too: Phase 1 adds no portable PMU-version / counter / PMI / PMU-filter plane and no portable `LBR` / `Intel PT` / `PEBS` / `IBS` / `SPE` profiling plane, so owner-local vPMU/profiler virtualization remains implementation-local and reviewed profiling/observation meaning stays on explicit D-OBS / D-TRACE seams rather than ambient guest counters, interrupts, or trace buffers (`microvm-pmu-profiling-posture-v0.md`).
- Guest-visible paravirtual enlightenments are pinned too: Phase 1 adds no portable KVM paravirt-feature / MSR / shared-page / hypercall plane, no portable Hyper-V enlightenment / SynIC / VMBus plane, and no portable Xen hypercall / event-channel / grant-table / XenStore plane, so owner-local hypervisor-assist exposure remains implementation-local and reviewed time / interrupt / profiling / channel meaning stays on already-pinned explicit seams rather than ambient hypervisor-specific guest ABIs (`microvm-paravirt-enlightenment-posture-v0.md`).
- Guest-visible semihosting is pinned too: Phase 1 adds no portable Arm semihosting trap / operation plane, no portable semihosting target / userspace / arg plane, and no portable host file / debugger-console / command / time truth via semihosting, so owner-local semihosting enablement and routing remain implementation-local and reviewed file / console / time / bootstrap meaning stays on already-pinned explicit seams rather than ambient debug-host trap calls (`microvm-semihosting-posture-v0.md`).
- In-guest management helpers are pinned too: Phase 1 adds no portable QEMU Guest Agent / Hyper-V integration-services / VMware Tools lifecycle-file-admin plane, no portable metadata-heartbeat-observation plane, and no portable quiesce-time-sync-snapshot-assist plane, so owner-local guest-agent installation/enabling remain implementation-local and reviewed lifecycle / file / observation / time / bootstrap meaning stays on already-pinned explicit seams rather than ambient host↔guest management daemons (`microvm-guest-agent-posture-v0.md`).
- Host-side guest debugging and memory introspection are pinned too: Phase 1 adds no portable gdbstub / remote-debug plane, no portable guest-memory-dump / vmcore-export plane, and no portable physical-memory-exam or debug-attach transport/auth contract, so any owner-local debugger socket, dump-file workflow, or monitor-relay setup remains implementation-local and reviewed observation / inspection / crash evidence stays on explicit D-OBS / D-INSPECT / `CH-CRASHCAP` seams rather than ambient VMM debug endpoints (`microvm-debug-introspection-posture-v0.md`).
- Host-side VMM management APIs are pinned too: Phase 1 adds no portable monitor / QMP / REST / D-Bus control plane, no portable lifecycle-config-mutation plane, and no portable VM-info / events / counters plane, so any owner-local control socket, API transport, or orchestration frontend remains implementation-local and reviewed lifecycle / observation / topology / snapshot meaning stays on already-pinned explicit seams rather than ambient VMM control endpoints (`microvm-management-api-posture-v0.md`). Live migration is pinned separately too: Phase 1 `ext.microvm` adds no portable precopy / postcopy / stop-and-copy / failover plane, no portable migration-channel / URI / auth contract, and no portable convergence / downtime / device-state-transfer contract, so any owner-local migration transport, destination coordination, or switchover logic remains implementation-local and reviewed cross-host continuity meaning stays on explicit activation / evidence / snapshot seams rather than ambient VMM migration machinery (`microvm-live-migration-posture-v0.md`).
- Warm restore is implementation-local only: no ambient network/vsock/session continuity, and clone/restore must refresh entropy and instance identity before payload.
- When guest-side repair after clone/restore is needed, it observes one explicit generation witness only: prefer VMClock `vm_generation_counter`, otherwise VMGenID; broken sessions are never the restore detector.
- Precision-time repair is separate: VMClock `disruption_marker` / `clock_status` invalidate local clock refinements without turning guest clocks into proof/lease authority.
- Freshness-bound attestation exports and attestation-gated secret-release sessions are generation-scoped: after generation change they are reacquired through explicit existing seams rather than resumed as hidden snapshot continuity.
- Even after that fresh exchange, attestation remains boot/provenance-bound rather than proving one exact resumed warm-start leaf; exact leaf identity/admission stays on separate explicit lineage evidence (`microvm-attestation-scope-posture-v0.md`).
- If policy distinguishes which exact reusable warm-start leaf or owner-local checkpoint was resumed, that identity remains owner-local admission/provenance evidence rather than a guest-visible leaf-id API or new `CH-ATTEST` claim (`microvm-resume-admission-evidence-posture-v0.md`).
- Reusable warm-start templates are cut **before** secret ingress and live imported authority, so snapshots taken after secret/session admission remain owner-local recovery artifacts rather than ordinary fan-out bases.
- The reusable template itself is a parent-bound, leaf-resumable derived accelerator rather than a public diff/base chain or mutable deployment object: any internal layering/merge order stays implementation-local, and refresh happens by cutting a new leaf under the owning lineage rather than mutating a published template in place (`microvm-template-lineage-posture-v0.md`).
- Reusable warm-start leaves and owner-local recovery checkpoints stay owner-local admission accelerators rather than a portable/public artifact class: portable distribution ships cold parent lineage, and each owner/runtime cuts/adopts warm leaves locally instead of importing shareable warm-state blobs (`microvm-template-distribution-posture-v0.md`).
- Reusable warm-start leaves remain owner-local, semantically optional accelerators rather than a portable cache-residency promise: owners may evict, deactivate, or regenerate leaves locally without changing cold parent deployment identity, and Phase 1 adds no public cache hit/miss or `Pending` / `Active` / `Inactive` lifecycle plane (`microvm-template-availability-posture-v0.md`).
- Each reusable leaf is admitted only under one exact reviewed resume class: heterogeneous CPU/device/kernel fleets are normalized before the cut, and cross-class restore fails closed instead of becoming an ambient best-effort compatibility promise (`microvm-template-resume-class-posture-v0.md`).
- Once such a reusable leaf is resumed, clone-sensitive repair completes before any externally visible action or readiness claim; old sessions/leases are not probed as a repair oracle, and Phase 1 still adds no portable checkpoint-hook or restore-complete control plane (`microvm-restore-repair-barrier-posture-v0.md`).

## D-PART: static partition policy profile (optional)
Options: none (default); static “cells” with CH-PART policy + no emulation; partitioning hypervisor slice.  
Evidence: whether policy-as-data + overlap validation yields a strong early deliverable with small TCB; whether DMA/IOMMU posture is tractable (PO-PART-DMA).

## D-CC: confidential-computing stance (optional)
See: RFC-0064.
Options: none (default); TEE-backed profile (SEV-SNP / TDX / CCA); “attestation only” vs “enforced isolation guarantees”.  
Evidence: explicit assumption set (A-CC-1); init/measurement correctness; residual side-channel posture (D-SIDECH). If combined with `ext.microvm`, freshness-bound attestation/export and secret-release sessions must be reacquired after generation change rather than inherited from a pre-restore attestation exchange (see `microvm-attestation-reacquire-posture-v0.md`). Even then, the portable attestation claim remains boot/provenance-bound rather than identifying one exact resumed warm-start leaf unless separate explicit lineage/admission evidence says so (see `microvm-attestation-scope-posture-v0.md`), and that exact leaf identity, if recorded at all, remains owner-local admission/provenance evidence rather than a guest-visible leaf-id API (see `microvm-resume-admission-evidence-posture-v0.md`).

## D-IFC: information-flow stance (optional)
Options: none (default); IFC-lite on selected channels/observations; stronger noninterference model.  
Evidence: ability to define an observation model and prove/validate it without exploding the state space; alignment with C-OBS-1 and D-SIDECH.
See: RFC-0047 (D-IFC), CH-LABEL v0, and AC-072.

## D-LLM: LLM-assisted operations posture
Options: “LLM proposes; deterministic validator executes”; “no LLM in privileged loop”; limited read-only copilots.  
Evidence: threat model (prompt injection / tool abuse); ability to prove “text cannot create authority” (<I-LLM-*>; <PO-ACT-*>).
v0 posture: `llm-operations-posture-v0.md` (proposal-only; explicit tool/context catalogs; prompts/descriptions stay non-authoritative; no dynamic connector install/discovery seam).

## D-POLICY: veto-only policy bundles for operational guardrails (optional)
Options: none (default); veto-only policy engine for ACP and composition constraints (CH-POLICY); richer pinned contexts (still veto-only).  
Evidence: practical ability to encode guardrails without creating authority; determinism and auditability; keeping policy out of the privileged core.
Receipt surface note: when CH-DENY v0 is emitted for policy/authority failures (`missing-approval`, `expired-approval`, `policy-deny`), denials MUST bind `reason.kind="policy"` and `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)` so “which policy was in force?” is non-ambient and transcript-visible.
v0 adjunct boundary: `verification-policy-selection-boundary-v0.md` (policy selection stays explicit local verifier-owner configuration; evidence/bundle fields do not choose which policy is in force; no native policy-discovery / policy-ID resolution / latest-policy plane).

## D-EVENTBUS: capability-mediated event plumbing (optional)
Options: none (default); user-space event router with capability-checked publish/subscribe; privileged primitive (only if later justified).  
Evidence: whether it reduces ambient channels and helps operator/ACP workflows without expanding the privileged core; ability to validate schemas and log deterministically.

## D-OBS: observation export posture (IF-OBS)
Options: minimal export (CH-OBS only); richer export (logs/traces/inspect/cap-graphs); local-only vs shareable bundles; sanitized-only default vs operator-authorized full exports.
Evidence: risk of data exfiltration/covert channels vs operator/incident value; ability to enforce redaction/minimization deterministically (I-OBS-1) and keep exports non-authoritative (I-OBS-2); impact on side-channel scope (D-SIDECH).
v0 posture: `observation-export-posture-v0.md` (pull-only exports; `cfg.params.lane.obs.export` kill switch; no ambient indexing/exfil).

## D-OBSPOL: observation export policy artifact (optional)
Options: implicit/compiled policy (default early); pinned policy-as-data (CH-OBSPOL) selected by profile/tier; per-workflow policy digests bound into exported artifacts.
Evidence: reviewability + deterministic enforcement; ability to keep “what we export” explicit, bounded, and auditable without expanding privileged code paths.
See: RFC-0076.

## D-TRIAGE: on-device triage rules and diagnosis predicates (optional)
Options: none (default); pinned triage rules (CH-TRIAGE) evaluated over inspect/crash artifacts; triage + snapshot assembly integration (advisory only).
Evidence: whether triage materially reduces "dump everything" behavior without increasing exfil risk; ability to keep rule evaluation bounded/deterministic (I-TRIAGE-1) and non-authoritative (I-TRIAGE-2); ability to test rule sets with golden inputs; interaction with CH-OBSPOL and portal workflows.
See: RFC-0087.


## D-TRACE: tracing/tracepoints posture (optional)
Options: none (default); static tracepoints only; patchable/static-key tracepoints; user-space only (no kernel events).
Evidence: safety (no code injection); explicit authorization + redaction via IF-OBS; overhead when disabled/enabled; impact on side-channel scope (D-SIDECH).

## D-TRACEPROC: programmable trace processing pipelines (optional)
Options: none (default); user-space processors over CH-TRACE (recommended); in-kernel programmable hooks (avoid early).
Evidence: ability to answer “one question” without dumping raw traces; overhead vs raw export; strength of bounds/redaction against exfil/covert channels; composability with D-WASM and D-BUDGET.
See: RFC-0068.

## D-TPROBE: tracepoint descriptor manifest (optional)
Options: none (default); ship a pinned tracepoint schema table (CH-TPROBE) with the build/profile; optionally include/advertise the CH-TPROBE digest alongside exported trace artifacts.
Evidence: ability to name/type-check trace fields for predicates and tools; avoidance of index-based interpretation bugs; enforcement of redaction/semantic constraints (e.g., no raw addrs) using field metadata; fail-closed behavior on schema mismatches.
See: RFC-0077.

## D-TPRED: trace predicates / prefiltering (optional)
Options: none (default); portal-only filtering (recommended early); optional source-prefilter for selected probes via CH-TPRED.
Evidence: ability to reduce trace volume/overhead without in-kernel scripting; validator simplicity; bounded evaluation cost; determinism of drop/overflow behavior; interaction with D-TRACEPROC and D-SIDECH.
See: RFC-0073.

## D-INSPECT: structured diagnostics trees + snapshot bundles (optional)
Options: none (default); per-component inspect trees exported as CH-INSPECT snapshots; optional crash capsules (CH-CRASHCAP) and support/incident snapshot bundles (CH-SNAPSHOT) assembled by user-space tooling.
Evidence: whether structured state snapshots materially reduce reliance on stringly logs; bounded CPU/memory overhead under adversarial components; redaction/minimization posture (I-OBS-1) and export gating; usefulness for incident workflows (crash reports, topology, counters).
See: RFC-0075.

## D-FLIGHTREC: flight recorder retention rings + incident capture triggers (optional)
Options: none (default); volatile-only rings (recommended baseline); bounded persistent retention; crash-survivor region (pstore-like) for last-gasp logs.
Evidence: bounded overhead under high event rates; deterministic overload behavior (drop/rotate); no scope amplification beyond CH-OBSPOL; whether incident workflows materially improve (crash/hang triage time, reduced “please reproduce with debug logs”).
See: RFC-0109.

## D-FAILPOINT: failpoints and fault injection posture (optional)
Options: none (default); dev/test-only failpoints loaded from a pinned profile (CH-FAIL); limited in-core hooks for seams user space cannot reach.
Evidence: ability to exercise failure paths without TCB bloat; determinism/replay compatibility (D-RR); bounded damage radius and no authority amplification (I-FAIL-1).

## D-SIDECH: side-channel scope posture
Options: explicit non-claim (default); scoped timing-only; bounded microarchitectural model.  
Evidence: ability to specify/mechanize an observation model; cost/benefit; explicit non-claims in `assurance-claims.md`.

## D-UNSAFE: Rust subset and boundary
Options: minimal unsafe HAL; wider unsafe but audited; unsafe in external drivers only.  
Evidence: ability to tie each unsafe site to a U-ID + invariant contract (C-UNSAFE-1; U-*).

## D-ZEROIZE: memory remanence policy
Options: always-zeroize; zeroize on cross-domain reuse; best-effort only (non-claim).  
Evidence: threat model for remanence; performance budget; feasibility of proving enforcement (<I-REUSE-*>; <PO-ZEROIZE-*>).

## D-TIME: time source for security policies
Options: none (no expiry/anti-rollback); monotonic counter only; secure RTC + counter; monotonic + authenticated time bootstrap (D-TIMEPROOF).
Evidence: threat model for rollback/expiry; availability of monotonic hardware source; ability to make C-TIME-1 meaningful under A-BOOT-2.
See: `security-time-posture-v0.md`.

Wiring (v0 seed):
- Phase-1 portable meaning is **policy-local monotonic lower-bound security time** for expiry / anti-rollback, not “whatever app-visible wall clock the host exposes”.
- App-visible `kind="realtime"` clocks remain observational/application-facing; they do not silently define security time.
- Phase 1 adds **no portable wall-clock setting, RTC write, or timezone/calendar admin plane**.
- Secure RTC readings, authenticated timeproofs, rollback floors, and any explicitly-admitted signing-time evidence are provider/local-policy inputs to one model rather than competing portable time domains.
- Signature/transparency timestamp evidence does not automatically advance security time or app-visible realtime; any such transformation remains explicit local policy (`signing-time-evidence-boundary-v0.md`).

## D-TIMEPROOF: authenticated network time bootstrap + time proofs (optional)
Options: none (default); Roughtime-style signed time samples for bootstrap; NTS-secured NTP for steady-state; hybrid (Roughtime bootstrap + NTS discipline).
Evidence: whether deployments lack a trustworthy RTC; whether expiry-based mechanisms (D-TUF, cert validity) must function at first boot; network adversary model; acceptable privacy leakage (time server identifiers, RTT); ability to keep security time monotonic (I-TIME-1) while still exporting bounded proof artifacts (CH-TIMEPROOF).
See: RFC-0090 and `timeproof-posture-v0.md`.

Wiring (v0 seed):
- User-space implementation is a portal-clock extension (no privileged time-sync protocol in kernel).
- LLM-first invocation uses ACP kind `portal.clock.timeproof.sample` bound to `timereq_digest = digest(CH-TIMEREQ v0)`; the portal emits `CH-TIMEPROOF v0` as bounded evidence.
- Phase-1 posture is **evidence-first + lower-bound-only**: verified samples may advance `secure_time_lb`, but do not become an ambient clock-setting or scheduler surface.
- Phase-1 portable/exported proof kind is **Roughtime-shaped only**; NTS may discipline portal-local time but does not become a second CH-TIMEPROOF kind without a future RFC.
- Profile kill switches: `cfg.params.lane.portal.clock` **and** `cfg.params.lane.timeproof` (missing/false fail closed; PO-LANE-KILL).


## D-XS: exit/entry surface budget
Options: strict closed action sets with tight budgets vs flexible interfaces.  
Evidence: proof tractability; exploit surface; ability to enforce PO-XS-CLOSESET; see `exit-surface-budget.md`.
