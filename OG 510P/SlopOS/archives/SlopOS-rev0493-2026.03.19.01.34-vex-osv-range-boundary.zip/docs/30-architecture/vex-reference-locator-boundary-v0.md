# VEX reference/locator boundary v0 (imported advisory references stay evidence, not native fetch/resolver authority)

Purpose: pin the Phase-1 meaning of **reference/link-shaped fields imported through VEX/advisory evidence** across **D-VEX**, **D-AREF**, **D-NETLEASE**, and **D-POLICY** so `references[]`, OpenVEX advisory links, CSAF reference/remediation URLs, and richer CycloneDX/OpenVEX/CSAF locator material do not quietly become a portable fetch instruction, resolver plane, latest-by-link rule, or evidence-closure channel.

Entropy cost justification: the archive already keeps CH-VEX digest-bound, already keeps CH-AREF locator hints non-authoritative, and already keeps advisory identity, priority, remediation, and product-targeting semantics verifier-local. What remains cheap-but-dangerous is the locator-rich part of real advisory documents: OpenVEX carries per-statement links and action text, CSAF carries references, remediations, and URL-bearing advisory context, and CycloneDX VEX commonly links out to advisories and exploitability resources. Leaving that relationship unstated invites expensive drift later: imported advisory links start acting like a native fetch plan, a hidden “consult the vendor now” rule, or a side-door evidence-discovery channel. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** may still carry bounded `references[]` strings and may still point at one exact external advisory document via `external_doc_aref`.
- **CH-AREF v0** may still bind exact imported artifacts by digest, with locators staying hints only.
- **Verifier-local policy/tooling** may still parse, display, or explicitly dereference imported advisory references/links, but dereferencing remains explicit and killable rather than silently becoming native archive meaning.

## Posture (v0)

1) **Imported advisory references/links stay descriptive evidence only.**
   - CH-VEX `references[]`, imported OpenVEX links, CSAF references/remediation URLs, and similar CycloneDX/OpenVEX/CSAF locator material record where upstream tooling says more context may exist.
   - Phase 1 therefore treats these values as imported descriptive references, not as native SlopOS fetch instructions, trust roots, or “the rest of the evidence set lives over there” authority.

2) **No native auto-follow / fetch plane rides on imported advisory links.**
   - An imported advisory URL, remediation link, bug tracker reference, vendor KB URL, or exploitability statement link does not imply “fetch this now,” “follow this to complete verification,” or “consult the network to finish interpretation.”
   - Any dereference remains explicit local tooling above the authority substrate and, if networked, must use already-pinned **D-NETLEASE** controls.
   - Companion `artifact-resolution-posture-v0.md` already pins that locators are hints only; this boundary further pins that imported VEX/advisory links stay on the same non-authoritative side of the line.

3) **Exact evidence binding still rides on digests, not imported references.**
   - Exact CH-VEX bytes are still bound by their digest, and any richer external advisory document is still bound only if selected explicitly through **CH-AREF** digest verification.
   - An imported statement reference, advisory URL, ticket number, or remediation link therefore carries no portable authority to replace the current document, widen the evidence set, outrun a digest mismatch, or define “the newest advisory.”
   - Companion `verification-material-discovery-boundary-v0.md` already pins that verification material discovery stays explicit; advisory references do not become a back door around that split.

4) **No native mirror / fallback / latest-by-link rule exists in Phase 1.**
   - If a CH-VEX artifact or imported external advisory carries several references (for example, vendor advisory, ticket, documentation page, exploit note, bug tracker, or remediation download), Phase 1 imports no rule for which one is preferred, freshest, authoritative, or complete.
   - Matching hostnames, repeated links, shared document titles, or “this advisory references that advisory” patterns do not create a native supersession, mirror, or follow-up rule.
   - Any prioritization, retry, or fallback behavior remains verifier-local tooling/policy rather than carrier-visible semantics.

5) **Imported references do not create native closure, alias, or policy-import semantics.**
   - A statement `references[]` entry or richer imported advisory link may help local tooling correlate discussion or evidence, but it does not by itself widen CH-VEX into a recursive advisory-closure language.
   - Following a reference does not natively create “same vulnerability family,” “same product family,” “therefore fixed,” “therefore not affected,” or “therefore block/install” semantics.
   - Companion `vex-vulnerability-identity-boundary-v0.md`, `vex-remediation-selection-boundary-v0.md`, `vex-priority-signal-boundary-v0.md`, and `vex-cpe-applicability-boundary-v0.md` already pin those adjacent seams; this boundary keeps imported advisory links from silently reopening them.

6) **Human-facing convenience links do not become trust or support authority.**
   - Vendor KB links, case/ticket URLs, issue tracker references, documentation pages, and similar advisory convenience fields may help operators inspect or route work.
   - They do not become a native support-owner oracle, vendor-trust hint, waiver source, remediation owner, or escalation path in Phase 1.
   - Companion `sbom-supplier-origin-boundary-v0.md` already pins adjacent supplier/origin labels to provenance evidence only; imported advisory links stay on that same evidence side of the line.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how imported VEX/advisory references fit with existing VEX/reference/network seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native `references[]` / advisory-link fetch contract.
- No portable mirror selection, retry, or latest-by-link rule for imported advisory material.
- No automatic chase from advisory references into a wider evidence set.
- No imported-link-based trust, support-routing, or remediation authority.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is intentionally richer than our authority substrate:
- OpenVEX keeps the core document lightweight while still carrying statement-scoped references and action text that point readers toward outside advisory context.
- CSAF is a broader security-advisory format with references, remediation information, product trees, and other URL-bearing context across the advisory lifecycle.
- CycloneDX external references are designed to link BOM/VEX objects to outside resources such as advisories, exploitability statements, documentation, or distribution material.

Pinning that split now prevents SlopOS from quietly reinventing an ambient advisory crawler, “follow the vendor KB link” resolver, or latest-linked-advisory authority plane under the names of VEX interoperability or convenience.

## Profile effect (A–D)

- **Secure workstation (A):** local tools may still display or optionally open imported advisory links, but the workstation does not inherit a hidden trust/fetch plane from VEX metadata.
- **Cloud micro-VM substrate (B):** fleet tooling may mirror or enrich advisory evidence externally, yet verifier meaning stays local and digest-bound rather than “whatever the linked advisory URL currently serves.”
- **Embedded / separation appliance (C):** offline verifiers stay small because imported advisory links never require a URL crawler or resolver engine to preserve VEX meaning.
- **Agent/automation OS (D):** agents may reason over imported advisory reference graphs, but they cannot smuggle ambient network/discovery authority through one helpful-looking `references[]` entry or vendor URL.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-AREF**, **D-NETLEASE**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/artifact-resolution-posture-v0.md`
  - `docs/30-architecture/verification-material-discovery-boundary-v0.md`
  - `docs/30-architecture/vex-vulnerability-identity-boundary-v0.md`
  - `docs/30-architecture/vex-remediation-selection-boundary-v0.md`
  - `docs/30-architecture/vex-priority-signal-boundary-v0.md`
  - `docs/30-architecture/vex-cpe-applicability-boundary-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-AREF-1**, **I-NETLEASE-1**, **I-NETLEASE-2**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-VEX-BIND**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**, **PO-LANE-KILL**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_reference_locator_boundary.py` keeps the split small and discoverable (**EVID-2026-499**).

## References

- **REF-OPENVEX-SPEC**
- **REF-CSAF-SPEC**
- **REF-CYCLONEDX-EXTERNAL-REFERENCES**
