# VEX priority-signal boundary v0 (scores / threat lists stay evidence, not native rollout authority)

Purpose: pin the Phase-1 meaning of **priority-shaped vulnerability evidence** across **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-AREF**, and **D-POLICY** so imported CVSS severity, EPSS probabilities, KEV presence, CSAF threat/risk annotations, and similar advisory-prioritization signals cannot quietly become a portable install veto, rollout priority lane, or update-selection rule.

Entropy cost justification: the archive already pins CH-VEX as digest-bound exploitability evidence and CH-UPD as digest-bound install intent, but real advisory ecosystems still publish rich prioritization material: CVSS severity, EPSS exploitation probability, known-exploited flags/catalog membership, threat scores, and product-specific urgency notes. Leaving that relationship unstated invites expensive drift later: one attached advisory score starts acting like “must install now”, “block boot”, “skip because low priority”, or “prefer this update cohort”. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** stays a bounded exploitability statement set for one exact subject digest.
- Richer advisory scoring/prioritization material may arrive through **external docs** referenced via **CH-AREF**, verifier-local feeds, or local tooling.
- **CH-UPD v0** and **CH-BOOT v0** still carry the only native install/boot cohort meaning.
- **Verifier-local policy** may consult prioritization signals, but the relation is not portable merely because those signals are present.

## Posture (v0)

1) **Imported vulnerability scores and threat lists are evidence about the already-bound subject, not native action selectors.**
   - CVSS severity, EPSS probability/percentile, KEV catalog membership, CSAF threat/risk fields, and similar imported prioritization signals may inform how urgently an operator treats a finding.
   - Those signals remain evidence about a vulnerability claim and the already-bound subject or component scope.
   - Phase 1 does **not** import a native rule that any one score, percentile, or threat-list hit directly means “install now”, “block install”, “block boot”, “defer install”, or “pick this successor update”.

2) **No portable scoring formula or precedence rule exists in v0.**
   - Phase 1 adds no native formula that combines CVSS, EPSS, KEV, vendor severity, threat intelligence, or product-local exposure into one portable SlopOS priority verdict.
   - It also adds no native precedence rule such as “KEV beats EPSS”, “highest CVSS wins”, “latest threat score wins”, or “critical severity implies fail closed everywhere”.
   - If an owner wants a fused prioritization policy, that logic stays verifier-local and explicit.

3) **Priority-shaped fields do not create a native rollout or scheduling plane.**
   - Imported urgency/severity labels may influence owner-local review, ticketing, or repository policy.
   - They do **not** become a native rollout percentage, install ordering, fleet-priority class, boot scheduling class, or ACP/workflow action on D-ATOMICUPD / D-BOOT.
   - Companion `verification-policy-selection-boundary-v0.md` already pins that appraisal policy stays verifier-local rather than being selected by artifact contents.

4) **Carrier meaning stays digest-first even when richer advisory context is attached.**
   - `target_root_digest`, `cfg_digest`, and exact adjunct digests on CH-UPD / CH-BOOT remain the only portable install/boot cohort meaning.
   - An attached external advisory document, KEV flag, EPSS score sheet, or CVSS vector does not widen or redefine what those carriers install or boot.
   - Companion `update-evidence-subject-boundary-v0.md` already pins that supporting evidence may appraise the pinned cohort but may not redefine the subject.

5) **Thresholds and exceptions stay local policy, not artifact semantics.**
   - Rules like “fail if KEV-listed”, “require review when EPSS > x”, “ignore if CVSS < y”, or “allow only if vendor severity < z” may be useful.
   - In Phase 1, every such threshold or exception remains owner-local policy over imported evidence rather than native archive meaning.
   - No portable `critical`, `urgent`, `high-risk`, `actively_exploited`, or `safe-enough` verdict vocabulary is created merely by importing advisory metadata.

6) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing exploitability/update/boot/evidence seams interpret imported priority signals.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native CVSS / EPSS / KEV / vendor-severity score field on CH-VEX.
- No portable formula that fuses several advisory-priority signals into one install or boot verdict.
- No native install-veto / hold / waive / rollout-priority semantics based solely on imported vulnerability scores or threat lists.
- No portable threshold vocabulary such as `critical_implies_block` or `actively_exploited_implies_force_update`.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but deliberately richer than our Phase-1 authority substrate:
- CVSS is an open framework for communicating vulnerability characteristics and severity, including base, threat, environmental, and supplemental metrics.
- EPSS publishes a probability of exploitation activity in the next 30 days plus a percentile for context.
- CISA positions the Known Exploited Vulnerabilities catalog as an authoritative source of vulnerabilities exploited in the wild and recommends using it as an **input** to vulnerability-management prioritization.
- CSAF is a broader structured advisory language for products, vulnerabilities, impact, remediation, and related context.

Those are all strong reasons to *consume* priority-shaped evidence. They are not reasons to let one imported score or threat-list hit quietly become native install/boot authority inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** desktop review tooling may use vendor severity or KEV presence for triage without turning one imported score into hidden updater behavior.
- **Cloud micro-VM substrate (B):** fleet policy may combine EPSS/KEV/vendor intelligence with rollout logic, but prioritization still stays explicit repository/fleet policy rather than carrier meaning.
- **Embedded / separation appliance (C):** offline verifiers stay small because they need not implement score fusion, threshold languages, or advisory feed precedence inside the portable core.
- **Agent/automation OS (D):** agents may read richer advisory feeds, but they cannot smuggle “KEV says urgent, therefore install this now” into portable authority without an explicit owner-local policy seam.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-AREF**, **D-POLICY**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/decision-map.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-AREF-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-AREF-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_priority_signal_boundary.py` keeps the split small and discoverable (**EVID-2026-497**).

## References

- **REF-CVSS-V40-SPEC**
- **REF-EPSS-FAQ**
- **REF-CISA-KEV-CATALOG**
- **REF-CSAF-SPEC**
