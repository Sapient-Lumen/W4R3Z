# Signature-envelope posture v0 (typed digest binding; local verification; keyless is adjunct policy)

Purpose: pin the Phase-1 meaning of **D-SIGENV** (and the optional **D-KEYLESS** adjunct) so signed artifacts do not drift back into wrapper folklore, ambient online trust, or identity-by-hint semantics.

This posture is intentionally narrower than a full signing service. It defines the **portable meaning of CH-SIGENV verification and admission** while keeping signing workflows, KMS/HSM choices, certificate transport, and transparency interoperability outside the native authority substrate unless another seam admits them explicitly.

## Posture (v0)

1) **CH-SIGENV binds typed digests, not filenames, locators, or ambient bytes.**
   - Accepted signature meaning is the verified binding of **`(payload.schema, payload.digest)`** under **I-SIGENV-1** and **PO-SIGENV-VERIFY**.
   - A verifier MUST reject any attempt to treat pathnames, URLs, package names, mutable tags, or out-of-band payload bytes as the portable signed subject.

2) **Verification is offline-first and policy-local.**
   - Phase 1 verification uses locally available payload bytes, local trust roots / allowed keys / allowed issuers, and local policy.
   - D-SIGENV adds no portable live fetch of certificates, intermediate chains, transparency proofs, policy bundles, or identity metadata from ambient network services.
   - Companion boundary `certificate-path-input-boundary-v0.md` pins that AIA / `caIssuers` locator fields are hints only, presented chains do not auto-expand trust, and certificate/path inputs remain explicit verifier-local policy inputs.
   - Companion boundary `certificate-status-evidence-boundary-v0.md` pins that CRL / OCSP / certificate-status inputs remain explicit local evidence and policy inputs, that freshness/soft-fail handling stays local, and that Phase 1 adds no native OCSP/CRL/status-cache plane.
   - Companion boundary `certificate-identity-evidence-boundary-v0.md` pins that SAN / subject / issuer / custom OID fields remain exact signed evidence under explicit local interpretation, that EKU / policy OIDs remain verifier-local predicates, and that Phase 1 adds no native best-identity / wildcard-grammar / repo-owner lookup plane.
   - Companion boundary `signature-trust-root-boundary-v0.md` pins that trusted roots, transparency-log keys, CT-log keys, and TSA roots remain explicit local policy inputs or explicit D-TUF/provisioning artifacts, that trusted-root carriers stay adjunct artifacts rather than native authority objects, and that Phase 1 adds no native trusted-root/self-anchoring/service-discovery plane.
   - Companion boundary `signature-algorithm-acceptance-boundary-v0.md` pins that signature/message algorithm identifiers remain exact signed evidence, that accepted signature/message algorithms stay explicit verifier-local policy, and that multiple signatures do not create strongest-wins negotiation or a native algorithm-capability advertisement plane.
   - Companion boundary `keyless-issuer-discovery-boundary-v0.md` pins that OIDC/OAuth issuer metadata and SigningConfig-style service descriptors remain signer/client online config, that keyless verification does not require `.well-known`, OAuth metadata, JWKS, UserInfo, or introspection fetch, and that Phase 1 adds no native issuer-discovery/login plane.
  - Companion boundary `verification-material-discovery-boundary-v0.md` pins that sidecar naming conventions, OCI referrers, and similar verification-material discovery mechanisms remain tooling-only; verification still consumes explicit artifact bytes plus explicit verification-material artifacts; and Phase 1 adds no native sidecar/referrer/registry-discovery plane.
   - Companion boundary `verification-policy-selection-boundary-v0.md` pins that signature/provenance evidence does not select which policy bundle or expectation set is in force; policy selection remains explicit local verifier-owner configuration rather than bundle-selected or repo-selected folklore.
   - Companion boundary `verification-verdict-boundary-v0.md` pins that successful CH-SIGENV verification is evidence, not a portable approval verdict or latest-verified status bit.
  - Companion boundary `provenance-container-selection-boundary-v0.md` pins that provenance container multiplicity stays verifier-local rather than becoming native signature-envelope semantics.

3) **Signer hints are non-authoritative.**
   - `key_id` in `direct_key` signatures is an unauthenticated hint only and MUST NOT drive security decisions by itself.
   - `issuer`, `identity.subject`, `identity.repo`, `identity.workflow`, and `identity.commit` in `keyless_cert` signatures are non-authoritative hints unless they are re-derived and accepted under explicit local policy.

4) **Keyless is an optional adjunct, not the default trust model.**
   - If **D-KEYLESS** is disabled, `keyless_cert` admissions reject.
   - If **D-KEYLESS** is enabled, admission requires explicit issuer allowlists, identity-claim policy, and certificate-validity checks under **D-TIME** / **PO-KEYLESS-VERIFY**.
   - Phase 1 adds no portable “current repo owner”, “current workflow identity”, or external account-status lookup plane.

5) **Transparency and timestamp material remain evidence, not ambient authority.**
   - `tlog_anchor_digest` and any out-of-band bundle / timestamp / inclusion material may strengthen audit and signing-time evidence under **D-TLOG**, but they do not create a mandatory online Rekor/Fulcio dependency for the base portable meaning of CH-SIGENV.
   - Exact signing-time meaning is pinned in `signing-time-evidence-boundary-v0.md`: timing evidence must cover the relevant signature / envelope / signed-statement bytes rather than relying on payload-only timestamps, and it never becomes freshness, approval, or time-admin authority by itself.
   - Accepted logs, witnesses, and timestamp authorities remain explicit local policy inputs rather than a hidden global default.

6) **No portable signing-agent / remote-key / workflow-control plane in v0.**
   - D-SIGENV standardizes a verification/admission artifact, not a generic runtime signing API.
   - Phase 1 adds no portable signing daemon, agent socket, HSM/KMS selector, browser login loop, certificate enrollment control plane, or workflow-triggered “sign now” portal.

7) **Detached verification material stays out-of-band and digest-bound.**
   - Certificates, chains, bundles, inclusion proofs, and timestamp records may be carried as explicit artifacts (for example through **CH-AREF** or bundle packaging), but CH-SIGENV itself remains small and bounded. Sidecar naming conventions, OCI referrers, and similar verification-material discovery mechanisms remain tooling-only under `verification-material-discovery-boundary-v0.md`; they do not become native verification authority.
   - Phase 1 does not import a second portable envelope-with-embedded-proof format as native meaning.

8) **No new workflow / ACP / conflict-key family in v0.**
   - D-SIGENV and D-KEYLESS do not introduce a new portal family, ACP kind, or conflict-key namespace.
   - Automation continues to consume signed artifacts as explicit inputs on existing update/provenance/admission seams rather than through a generic signing workflow surface.

## Phase 1 non-goals (explicitly deferred)

- No generic PKCS#11 / KMS / remote-signer portability promise.
- No portable online certificate-chain discovery or OCSP / CRL / CA-admin surface.
- No portable certificate-status inventory/watch/latest-status plane.
- No portable Rekor / Fulcio client protocol in privileged code.
- No portable `.well-known` / OAuth metadata / JWKS / UserInfo / introspection client in privileged code.
- No claim that every profile must enable keyless signing.
- No generic bundle format admission beyond explicit local packaging / CH-AREF references.
- No runtime “trust this identity because the hosting forge says so” policy shortcut.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-SIGENV**, **D-KEYLESS**, **D-UPD-SIGN**, **D-TLOG**, **D-TIME**.
- Core schema / supply-chain seams:
  - `docs/30-architecture/signature-envelope-schema-v0.md` (CH-SIGENV v0).
  - `docs/60-engineering/supply-chain-repro.md`.
  - `docs/60-engineering/pcp-posture-v0.md`.
  - `docs/30-architecture/signing-time-evidence-boundary-v0.md`.
  - `rfcs/0093-signature-envelopes-and-keyless-signing.md`.
- Assurance anchors:
  - Invariants: **I-SIGENV-1**, **I-KEYLESS-1**.
  - Proof obligations: **PO-SIGENV-VALIDATE**, **PO-SIGENV-VERIFY**, **PO-KEYLESS-VERIFY**.
  - Adjacent seams: **D-TIME** for certificate-validity windows, **D-TLOG** for optional audit/timestamp evidence, **D-TUF** for trust-root distribution when a deployment chooses it.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - `tools/check_signature_envelope_posture.py` keeps the posture small and discoverable (EVID-2026-453).

## References

- REF-DSSE
- REF-DSSE-BACKGROUND
- REF-SIGSTORE-KEYLESS
- REF-SIGSTORE-FULCIO-OIDC
- REF-SIGSTORE-BUNDLE
- REF-SIGSTORE-REKOR
- REF-SIGSTORE-TIMESTAMPS
- REF-RFC3161-TSP
- REF-RFC9921-TST-HEADER
- REF-TUF-SPEC
