# Update-evidence subject boundary v0 (adjunct evidence appraises one pinned install cohort only)

Purpose: pin the Phase-1 subject/applicability boundary for **adjunct evidence carried with CH-UPD v0** across **D-ATOMICUPD**, **D-PCP**, **D-SBOM**, **D-VEX**, and **D-TLOG** so attached provenance / SBOM / VEX / proof artifacts do not quietly redefine what an update means to install.

Entropy cost justification: the archive already says CH-UPD is digest-bound install intent only, but nearby docs still leave one expensive ambiguity: whether attached evidence applies to the exact `(target_root_digest, cfg_digest)` cohort, to “the release” in some looser sense, or to whatever subject set a packaged bundle happens to mention. One narrow boundary buys that down without inventing a new schema family or a new verifier workflow.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how already-pinned seams fit together:
- **CH-UPD v0** answers *which exact deployment root plus config/policy binding we intend to install*.
- **CH-PROV v0** answers *how exact subject digests were produced*.
- **CH-SBOM v0** and **CH-VEX v0** answer *which exact subject digest an inventory or exploitability statement applies to*.
- **CH-TLOG v0** and imported proof artifacts answer *which exact bytes were anchored for audit evidence*.
- **Verification/appraisal policy** still answers *which exact evidence is required, sufficient, and fresh enough*.

## Posture (v0)

1) **CH-UPD fixes the install subject first; attached evidence may appraise that subject, not redefine it.**
   - The authoritative install cohort remains the exact `target_root_digest` plus exact `cfg_digest` already pinned by **CH-UPD v0**.
   - `prov_attestation_digest` and `artifacts[]` digests may supply supporting evidence about that cohort, but they do **not** widen the install subject to “this release”, “all bundle members”, or “whatever the attestation also mentions”.
   - Phase 1 therefore refuses the shortcut “the attached evidence covers more, so the update silently means more”.

2) **Provenance attached through `prov_attestation_digest` is admissible only as evidence about the staged cohort.**
   - If `prov_attestation_digest` is present, local policy may require that the verified CH-PROV subject set includes the staged `target_root_digest`, `cfg_digest`, or other exact staged adjunct digests the profile says must be provenance-bound.
   - Extra subjects inside a provenance statement remain extra evidence context; they do **not** enlarge the CH-UPD install subject or create multi-target install semantics.
   - Missing required subject bindings fail the provenance check under **PO-PROV-BIND**; extra subject bindings do not change what CH-UPD installs.

3) **SBOM and VEX attachments stay exact subject-bound evidence, not release-wide labels.**
   - When `artifacts[]` carries `role = sbom` or `role = vex`, the referenced CH-SBOM / CH-VEX artifact must still satisfy the already-pinned subject-binding rules under **I-SBOM-1** / **PO-SBOM-BIND** and **I-VEX-1** / **PO-VEX-BIND**.
   - A statement scoped to some other component, package name, or release label does not become applicable merely because it shipped in the same update bundle.
   - Subject mismatch therefore remains a deterministic evidence mismatch, not a reason to reinterpret the update subject.

4) **`proof_bundle` and transparency artifacts stay evidence about exact bytes, not install-subject expansion.**
   - `proof_bundle` remains one descriptive adjunct-evidence role for one exact artifact digest, per `proof-bundle-role-boundary-v0.md`.
   - Imported transparency proofs and `CH-TLOG v0` anchors remain evidence about exact artifact or proof bytes, per `transparency-proof-import-boundary-v0.md` and `transparency-log-posture-v0.md`.
   - Neither bundle membership nor transparency inclusion can silently upgrade CH-UPD from “install this cohort” to “install whatever else these proofs mention”.

5) **Adjunct evidence may be stricter than install intent, but never looser and never broader.**
   - Local policy may require additional evidence about the staged cohort before install, boot, or promotion succeeds.
   - Failing or missing required evidence can therefore block a local verdict.
   - Passing evidence only appraises the already-pinned cohort; it does not authorize sibling artifacts, alternative configs, broader release families, or later “latest compatible” replacements.

6) **Discovery and grouping remain non-authoritative.**
   - Release archives, OCI attachment sets, sidecars, and handoff bundles may group CH-UPD with many supporting artifacts.
   - That grouping is operational packaging, not a second subject-definition language.
   - Which grouped artifacts matter remains explicit local policy and exact digest binding, not “everything nearby applies”.

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows evidence applicability around existing update/provenance/supply-chain seams.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native “release-wide evidence closure” schema inside CH-UPD.
- No rule that a provenance statement’s full subject set becomes the install subject.
- No rule that grouped SBOM/VEX/bundle artifacts apply transitively to every artifact in the release.
- No bundle-membership or transparency-membership shortcut that widens what CH-UPD installs.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The adjacent ecosystems are explicit about subject binding but leave packaging/composition up to consumers:
- in-toto Statements bind attestations to specific `subject` artifacts by digest;
- SLSA provenance exists so consumers can verify an artifact was built according to expectations;
- TUF targets metadata describes which target files clients may trust and fetch, but those metadata roles do not make unrelated attached evidence part of the target itself.

Pinning that split now keeps SlopOS from quietly sliding into release-bundle folklore where “all the evidence next to an update” becomes a second, fuzzier definition of what the update installs.

## Profile effect (A–D)

- **Secure workstation (A):** offline review bundles may carry rich evidence, but the local installer still knows exactly which root/config cohort is under consideration.
- **Cloud micro-VM substrate (B):** release pipelines may attach fleet-wide evidence packs without accidentally turning one manifest into a multi-subject deployment grant.
- **Embedded / separation appliance (C):** air-gapped update verification stays deterministic because supporting evidence can fail closed without silently broadening install scope.
- **Agent/automation OS (D):** agents may reason over many attached artifacts, but they cannot smuggle “this evidence mentions more subjects” into broader install authority.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATOMICUPD**, **D-PCP**, **D-SBOM**, **D-VEX**, **D-TLOG**.
- Adjacent meaning pins:
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/provenance-posture-v0.md`
  - `docs/30-architecture/proof-bundle-role-boundary-v0.md`
  - `docs/30-architecture/transparency-proof-import-boundary-v0.md`
  - `docs/30-architecture/verification-verdict-boundary-v0.md`
  - `docs/30-architecture/sbom-posture-v0.md`
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/60-engineering/pcp-posture-v0.md`
  - `docs/60-engineering/supply-chain-repro.md`
- Assurance anchors:
  - **I-ATOMICUPD-1**, **I-PROV-CHAIN-1**, **I-SBOM-1**, **I-VEX-1**.
  - **PO-UPD-VERIFY**, **PO-PROV-BIND**, **PO-SBOM-BIND**, **PO-VEX-BIND**, **PO-TLOG-VERIFY**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_update_evidence_subject_boundary.py` keeps the split small and discoverable (**EVID-2026-477**).

## References

- **REF-IN-TOTO-STATEMENT**
- **REF-SLSA-PROVENANCE**
- **REF-SLSA-VERIFYING-ARTIFACTS**
- **REF-TUF-SPEC**
