# D-NONDET posture v0 (no ambient time/RNG; explicit Clock/Entropy handles)

Purpose: pin an implementable v0 meaning for **D-NONDET** that keeps nondeterminism least-authority (I-NONDET-1), keeps high-resolution timing honest as an authority grant (I-NONDET-2), keeps entropy quality explicit (I-NONDET-3), and keeps replay profiles evidenceable (I-NONDET-4).

This doc is intentionally narrow: it does **not** define a full time-sync protocol, a scheduler API, or a cryptographic RNG interface for apps. It pins the **authority substrate**: how time/entropy enter the system.

## Posture (v0)

1) **No ambient time APIs (time is explicit authority)**
   - If D-NONDET is enabled, post-init components MUST NOT have ambient access to time sources (no implicit `clock_gettime`, no ambient realtime/monotonic reads).
   - Time enters a domain only via an explicit **Clock handle** issued by `portal.clock` and described by **CH-CLOCK v0**.
   - Rationale: ambient clocks create covert channels and make replay/testing dishonest.

2) **No ambient RNG APIs (entropy is explicit authority)**
   - If D-NONDET is enabled, post-init components MUST NOT have ambient access to RNG/entropy sources (no implicit `getrandom`, no ambient `/dev/urandom`).
   - Entropy enters a domain only via an explicit **Entropy handle** issued by `portal.entropy` and described by **CH-ENTROPY v0**.
   - Design intent: treat privileged entropy primarily as **seed material** (REF-OPENBSD-GETENTROPY).

3) **Resolution is authority (fine time requires explicit grant)**
   - `portal.clock` SHOULD issue `kind="monotonic_coarse"` by default.
   - `kind="monotonic_fine"` MUST require explicit authorization (profile/policy), and coarse clocks MUST NOT be derivable into fine clocks.
   - `kind="realtime"` is a privileged surface and is only issued when D-TIME is enabled (security policies need wall-clock) and profile policy permits.

4) **Replay binding (D-RR) is explicit and fail-closed**
   - Clock/Entropy handles intended for replay MUST set `replayable=true` (CH-CLOCK/CH-ENTROPY).
   - In replay profiles (D-RR + D-NONDET), reads MUST be served from CH-RR nondeterminism events (`time_tick` / `entropy`) and MUST fail closed on mismatch (I-NONDET-4).

5) **Time proofs are a separate, killable authority (optional)**
   - Authenticated wall-clock bootstrap and exportable time samples use D-TIMEPROOF and CH-TIMEPROOF v0.
   - The only v0 automation surface is ACP kind `portal.clock.timeproof.sample`, which binds `timereq_digest = digest(CH-TIMEREQ v0)` and emits CH-TIMEPROOF v0.
   - Lane gates are mandatory and fail-closed:
     - `cfg.params.lane.portal.clock` (time portal)
     - `cfg.params.lane.timeproof` (timeproof sampling)
   - NTS/NTP and Roughtime are *implementation choices inside the portal*; the stable exported artifact is CH-TIMEPROOF (REF-ROUGHTIME-PROTOCOL; REF-RFC-8915; REF-ROUGHTIME-REPO).

6) **Sealed compat constraints (keep legacy time/RNG killable and non-ambient)**
   - Any Foreign Cell bridge that would recreate ambient time/RNG MUST be:
     - policy-killable by the same lanes (`cfg.params.lane.portal.clock`, `cfg.params.lane.portal.entropy`), and
     - incapable of creating ambient channels (no implicit `TZ`, no implicit NTP, no implicit host RNG device nodes).
   - v0 stance: do **not** standardize compat shims for time/RNG in Phase 1; keep them behind an RFC/ADR.

## Phase 1 non-goals (explicitly deferred)

- No standardized time-sync protocol in v0 (NTP/Roughtime/etc remain portal policy/implementation).
- No promise of high-resolution clocks by default (fine clocks remain explicit authority).
- No ambient RNG API surface for components (entropy remains handle-scoped).

## Profile guidance (A–D) (non-authoritative)

- **(A) Secure workstation**: allow `monotonic_coarse` by default; allow `realtime` only for trusted desktop services; prefer timeproof for audit/export; entropy is `seed` by default.
- **(B) Cloud micro-VM substrate**: default to `monotonic_coarse`; gate `monotonic_fine` tightly (side-channel posture); prefer timeproof bootstrap for security policies; entropy is `seed` with strict caps.
- **(C) Embedded / separation-kernel-ish appliance**: prefer `monotonic_coarse` only; often disable `realtime` entirely; timeproof optional for signed logs; entropy may be hardware-backed seeds only.
- **(D) Agent/automation OS**: default to `monotonic_coarse`; enable timeproof for evidence-bearing actions; keep `monotonic_fine` rare; deterministic entropy is explicit for tests/replay.

## Wiring

- Schemas:
  - `clock-descriptor-schema-v0.md` (CH-CLOCK v0)
  - `entropy-descriptor-schema-v0.md` (CH-ENTROPY v0)
  - `entropy-request-schema-v0.md` (CH-ENTREQ v0)
  - `timeproof-request-schema-v0.md` (CH-TIMEREQ v0)
  - `microvm-generation-witness-posture-v0.md` (for `ext.microvm` clone/restore hygiene, guest-visible witness changes trigger entropy reseed rather than relying on copied RNG state or broken transport side effects)
  - `microvm-entropy-surface-posture-v0.md` (for `ext.microvm` entropy-device hygiene, owner-local boot seeding does not become a portable post-init authority path and guest-visible entropy-device/source semantics stay off the reviewed product contract)
  - `microvm-clock-disruption-posture-v0.md` (for `ext.microvm` precision-time hygiene, VMClock `disruption_marker` / `clock_status` invalidate local refinements without turning guest clocks into authority-bearing proof/expiry inputs)
  - `microvm-time-source-posture-v0.md` (for `ext.microvm` guest-visible time-source hygiene, clocksource naming, RTC base/progression policy, and guest-visible set-clock/source-switch semantics stay implementation-local rather than portable authority-bearing meaning)
  - `time-proof-schema-v0.md` (CH-TIMEPROOF v0)
- Decision surface: `decision-map.md` (D-NONDET, D-TIME, D-TIMEPROOF)
- Portal families: `portal-family-registry.md` (`portal.clock.*`, `portal.entropy.*`)
- Capshell launch adjunct: `capshell-nondet-posture-v0.md` (when D-NONDET is enabled, reviewed `capshell.exec` must not inherit ambient `clock_gettime()` / timer or `getrandom()` / RNG defaults; portable time/entropy stays on explicit `portal.clock` / `portal.entropy` seams)
- ACP surfaces:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`portal.clock.timeproof.sample`, `portal.entropy.request`)
  - `docs/70-llm-control/acp-validator-semantics.md` (PO-ACP-TIMEPROOF-SAMPLE, PO-ACP-ENTROPY-REQUEST)

CI drift gate:
- `tools/check_nondet_posture.py` fails `make lint` if this posture stops being discoverable, loses its “no ambient time/RNG” constraints, or drops minimal REF wiring.

## References

- Entropy-as-seed hygiene: REF-OPENBSD-GETENTROPY.
- Fine-grained timing as a security surface: REF-SEL4-TIMEPROTECTION.
- “Timer interrupts as explicit authority” precedent: REF-SEL4-IRQ-TUTORIAL.
- Authenticated time inputs (implementation options): REF-ROUGHTIME-PROTOCOL; REF-ROUGHTIME-IETF; REF-RFC-8915; REF-ROUGHTIME-REPO.
- D-TIME v0 posture: `security-time-posture-v0.md` (security time is policy-local monotonic lower-bound state; app-visible realtime stays observational).
- D-TIMEPROOF v0 posture: `timeproof-posture-v0.md` (evidence-first, lower-bound-only, Roughtime-only export in Phase 1).
