# VEX investigation-deferral boundary v0 (`under_investigation` stays evidence, not a native grace/defer authority)

Purpose: pin the Phase-1 meaning of **investigation-shaped VEX evidence** across **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**, and **D-TIME** so `status == "under_investigation"` plus VEX timing fields cannot quietly become a portable install hold, grace window, waiver, or “wait until this expires” policy language.

Entropy cost justification: the archive already pins CH-VEX as digest-bound exploitability evidence and CH-UPD / CH-BOOT as digest-bound install carriers, but real VEX ecosystems still publish evolving advisory states, timestamps, and last-updated hints while operators naturally want to defer action until an investigation finishes. Leaving that relationship unstated invites expensive drift later: one VEX statement starts acting like “block this rollout until the vendor decides”, “temporarily suppress this finding until `expires_at_s`”, or “this unresolved advisory automatically creates a grace period”. One narrow boundary buys that ambiguity down without inventing a new `CH-*` schema.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how existing seams fit together:
- **CH-VEX v0** may carry `status == "under_investigation"` plus informational time fields.
- **CH-UPD v0** and **CH-BOOT v0** still carry the only native install/boot target meaning.
- **Verifier-local policy** may react conservatively to unresolved exploitability evidence, but that reaction is not portable merely because one VEX artifact is present.

## Posture (v0)

1) **`under_investigation` is unresolved evidence about the already-bound subject, not a native hold/defer command.**
   - A CH-VEX statement with `status == "under_investigation"` says the producer has not yet concluded whether the named vulnerability affects the already-bound subject.
   - That statement may inform dashboards, review queues, or verifier-local caution for that exact subject.
   - Phase 1 does **not** import a native rule that the subject is automatically blocked, deferred, grace-perioded, temporarily approved, or temporarily waived until more advisory data arrives.

2) **VEX timing fields are informational evidence, not automatic grace windows.**
   - `generated_at_s`, `issued_at_s`, and `expires_at_s` on CH-VEX remain exact evidence about publication and freshness context.
   - Verifier-local policy may impose freshness requirements or require re-review when evidence is stale.
   - Those fields do **not** become a portable “suppress until expiry”, “re-enable after investigation deadline”, or “defer rollout for N hours” contract on D-VEX itself.

3) **Advisory state transitions do not create native rollout state machines in v0.**
   - An ecosystem may publish successive VEX documents as knowledge evolves from `under_investigation` to `affected`, `not_affected`, or `fixed`.
   - Phase 1 does **not** import a native rule that this sequence defines rollout pause/resume behavior, automatic supersession, or repository-side hold semantics.
   - Companion `vex-remediation-selection-boundary-v0.md` already pins that even `fixed` status does not choose a successor update target.

4) **Any defer/require-review policy stays verifier-local and explicit.**
   - A product profile, repository, or owner-local verifier may choose to fail closed, require human review, or demand fresher evidence when only `under_investigation` data exists.
   - That posture must ride on explicit local policy inputs under **D-POLICY**, not on a portable rule hidden inside CH-VEX status values or timestamps.
   - Companion `verification-policy-selection-boundary-v0.md` already pins that evidence does not choose which policy is in force.

5) **No portable join from VEX timing/state to install or boot scheduling.**
   - CH-UPD / CH-BOOT may pin exact VEX artifacts as adjunct evidence.
   - Co-packaging VEX with update/boot metadata does **not** create a native “hold this update until investigation ends”, “pause boot until advisory expires”, or “latest unresolved advisory blocks activation” rule.
   - Install/boot scheduling, rollout sequencing, and retry timing stay on explicit update / repository / operator workflows rather than on advisory-state folklore.

6) **Imported richer advisory systems stay imported evidence unless another seam admits them.**
   - External OpenVEX / CSAF / CycloneDX documents may carry richer timestamps, revision history, analysis state, or remediation cadence.
   - Those details may inform verifiers or operators, but Phase 1 does **not** promote them into a native grace/hold/waiver language on CH-VEX / CH-UPD / CH-BOOT.
   - If SlopOS later wants portable advisory-driven hold state, that must return RFC-first as a separate decision surface with explicit conflict keys and evidence.

7) **Each selected artifact still verifies on its own seam.**
   - **PO-VEX-BIND** still answers whether one selected CH-VEX artifact binds the exact subject digest the verifier cares about.
   - **PO-UPD-VERIFY** and **PO-BOOT-VERIFY** still answer install/boot cohort integrity for the exact already-pinned digests.
   - **PO-POLICY-DETERMINISM** and **PO-POLICY-NONAMP** still answer whether verifier-local policy is explicit and non-amplifying.
   - No portable “temporarily blocked”, “temporarily allowed”, or “grace-period active” verdict is created merely by co-packaging VEX evidence with carriers.

8) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing exploitability/update/boot/policy/time seams interpret investigation-shaped VEX evidence.
   - It introduces no new externally visible action kind, no new conflict-key family, and no serialization surface of its own.

## Phase 1 non-goals (explicitly deferred)

- No native install-hold / defer-update / grace-period / temporary-waiver grammar on CH-VEX.
- No rule that `under_investigation` pauses a rollout, blocks a boot, or suppresses a finding until `expires_at_s`.
- No native advisory supersession / pause-resume state machine driven by successive VEX documents.
- No portable “review required” or “review completed” verdict encoded on CH-VEX.
- No new workflow / ACP / conflict-key family in v0.

## Why this is worth pinning

The surrounding ecosystem is useful but intentionally richer than our Phase-1 authority substrate:
- OpenVEX includes `under_investigation` in the closed status vocabulary and defines timestamps that describe when statement information was known or updated, which is valuable evidence but not a portable rollout/waiver contract.
- CycloneDX VEX similarly models exploitability/analysis state as contextual vulnerability evidence rather than as a package-manager or rollout scheduler.
- CSAF is about structured security advisories and remediation/impact status among interested parties, which is broader than the small digest-first install/boot authority substrate we want in Phase 1.

Pinning that split now keeps SlopOS from quietly inheriting “unresolved advisory state means automatic update hold until someone clears it” folklore.

## Profile effect (A–D)

- **Secure workstation (A):** operators may surface unresolved advisories prominently without turning advisory cadence into hidden updater behavior.
- **Cloud micro-VM substrate (B):** fleet policy may choose cautious rollout gates, but `under_investigation` does not silently become a portable hold signal across tenants or tooling.
- **Embedded / separation appliance (C):** offline verifiers stay small because they can require explicit local policy for unresolved advisories rather than importing advisory-timer semantics.
- **Agent/automation OS (D):** agents may read unresolved advisories, but they cannot smuggle “this update is on hold until the vendor finishes investigating” into portable authority.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-VEX**, **D-ATOMICUPD**, **D-BOOT**, **D-POLICY**, **D-TIME**.
- Adjacent meaning pins:
  - `docs/30-architecture/vex-posture-v0.md`
  - `docs/30-architecture/vex-schema-v0.md`
  - `docs/30-architecture/update-posture-v0.md`
  - `docs/30-architecture/update-manifest-schema-v0.md`
  - `docs/30-architecture/boot-manifest-schema-v0.md`
  - `docs/30-architecture/verification-policy-selection-boundary-v0.md`
  - `docs/30-architecture/decision-map.md`
  - `docs/60-engineering/supply-chain-repro.md`
  - `rfcs/0092-vex-artifacts-and-exploitability-statements.md`
- Assurance anchors:
  - **I-VEX-1**, **I-VEX-2**, **I-ATOMICUPD-1**, **I-BOOT-1**, **I-POLICY-1**, **I-POLICY-2**.
  - **PO-VEX-BIND**, **PO-UPD-VERIFY**, **PO-BOOT-VERIFY**, **PO-POLICY-DETERMINISM**, **PO-POLICY-NONAMP**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `tools/check_vex_investigation_deferral_boundary.py` keeps the split small and discoverable (**EVID-2026-485**).

## References

- **REF-OPENVEX-SPEC**
- **REF-CISA-VEX-MINREQ**
- **REF-CYCLONEDX-OVERVIEW**
- **REF-CSAF-ISO**
