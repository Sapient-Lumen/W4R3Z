# D-SUPV posture v0 (component-rooted user-space supervision; no ambient process-tree control plane)

Purpose: pin an implementable **Phase 1** meaning for **D-SUPV** so restart/recovery stays explicit,
reviewable, and composable without quietly becoming an ambient process-control story through raw PIDs,
process trees, shell jobs, `pidfd`, Job Objects, or host service-manager folklore.
It narrows RFC-0017 and RFC-0041 into one compact posture adjacent to **CH-COMP v0**,
**D-ACTIVATE**, **D-SEAL**, **D-CAPSHELL**, **D-JOBS**, and sealed-compat rules.

## Posture (v0)

1) **User-space, component-rooted policy only**
   - If **D-SUPV** is enabled, the portable supervision contract is enforced by a small user-space
     supervisor/component manager over explicit **CH-COMP v0** component identities (`cid`) and
     declared restart metadata.
   - The kernel/hypervisor may provide low-level death/wait notifications, but it does **not**
     expose a reviewed restart-policy DSL or ambient global service-manager API as portable meaning.

2) **Explicit component roots, not ambient PID / process-tree ancestry**
   - Portable supervision targets are explicit component/service roots selected by deployment policy
     and **CH-COMP v0 `cid`**, not raw PIDs, parent/child ancestry, shell jobspecs, cgroup paths,
     inherited Job Object membership, or “everything in this host subtree.”
   - This keeps D-SUPV attached to the archive’s declared composition graph instead of host-local
     process-accounting folklore.

3) **Deterministic bounded `Stop(grace) → Kill()` discipline; no portable signal / jobspec / parent-death control plane**
   - Phase 1 portable lifecycle control is a deterministic bounded supervisor discipline:
     request cooperative stop, wait a bounded grace period, then escalate to termination.
   - There is **no portable reviewed signal-name, process-group, shell jobspec, `SIGHUP`,
     `PR_SET_PDEATHSIG`, or parent-death API surface** on D-SUPV itself.
   - Host implementations may map the bounded stop/kill discipline onto local primitives, but those
     mappings remain owner-local beneath the posture.

4) **Restart is manifest/activation replay only**
   - Restarted components come back under the same declared **CH-COMP** routes and the same
     seal/capmode posture; restart must not quietly widen authority, resurrect init-only handles, or
     rebind a broader route set.
   - When continuity is needed, Phase 1 uses already-pinned **D-ACTIVATE** stable exports / handle
     store semantics rather than hidden inherited descriptors, global listener rebinding, or generic
     checkpoint/restore side channels.

5) **No portable process-descriptor / `pidfd` / Job Object control plane in v0**
   - Phase 1 standardizes **no portable process/job descriptor inventory or control API**:
     no `pidfd_open()` / `pidfd_getfd()` / `pidfd_send_signal()` style contract,
     no portable Job Object member-enumeration / nested-job / kill-on-close plane,
     no portable arbitrary-client wait/inspect/terminate-by-handle API,
     and no portable “adopt this host process subtree into the supervisor” surface.
   - If a provider uses such facilities internally, they remain implementation-local and must not
     become reviewed application/workflow meaning under the same portable profile.

6) **Critical handling stays manifest-bool + profile policy**
   - `critical: true` means the supervisor applies a profile-defined fail-closed reaction when the
     component fails or exhausts its restart budget.
   - Phase 1 adds no portable heuristic classifier based on executable path, service-unit name,
     launcher ancestry, or host-manager metadata.

7) **Restart budgets and reasons are bounded, deterministic, and transcript-visible**
   - `restart.window_ms`, `max_restarts`, and `backoff_ms` remain bounded deterministic inputs under
     **PO-SUPV-RLIMIT**; restart exhaustion must not degrade into hidden infinite retry loops.
   - Restart causes, counts, and escalation outcomes SHOULD be transcript-visible/log-exportable as
     bounded codes or digests rather than opaque unbounded strings.

8) **Sealed compat remains non-ambient**
   - Foreign Cells and host adapters may realize supervision with host-specific service managers,
     `pidfd`, Job Objects, or similar facilities behind the membrane, but they must not make those
     host surfaces part of the native portable contract.
   - Compat layers that require an ambient host init/service-manager protocol to preserve semantics
     must fail closed rather than smuggling that protocol into SlopOS meaning.

9) **This doc adds no new workflow / ACP / conflict-key family**
   - Phase 1 introduces no dedicated supervisor portal family, no `supervision.*` ACP action kind,
     and no dedicated conflict-key family for restart/kill requests.
   - Any future external supervision control surface must come back RFC-first, declare its conflict
     keys, say whether actions commute, name its serialization boundary, and explain how ordering is
     evidenced/tested.

## Phase 1 non-goals (explicitly deferred)

- A portable process-tree / PID / jobspec inventory, watch, or control API.
- A portable `pidfd` / Job Object / kill-on-close / nested-job semantics contract.
- Supervisor-selected authority widening, generic descriptor inheritance, or implicit rebind logic on restart.
- A generic global init/service-manager DSL or remote supervision admin plane.
- Treating shell/session/launcher ancestry as the reviewed ownership model for restartable work.

## Wiring

- Decision surface:
  - `decision-map.md` (D-SUPV)
- Primary schema / adjacent posture surfaces:
  - `component-manifest-schema-v0.md`
  - `activation-posture-v0.md`
  - `capshell-launcher-lifetime-posture-v0.md`
  - `capshell-job-control-posture-v0.md`
  - `capshell-interrupt-cancel-posture-v0.md`
  - `job-portal-posture-v0.md`
  - `quiesce-posture-v0.md`
- RFC history:
  - `rfcs/0017-supervision-trees-and-restart-policy.md`
  - `rfcs/0041-crash-only-services-and-microreboots.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-SUPV-1**, **I-ACTIVATE-1**, **I-ACTIVATE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-SUPV-NOAMP**, **PO-SUPV-RLIMIT**, **PO-ACTIVATE-HANDOFF**, **PO-ACTIVATE-CONTINUITY**)
- Discovery/history surfaces:
  - `docs/README.md`
  - `README.md`
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/30-architecture/posture-index.md`
  - `docs/00-meta/evidence-index.md`
  - `tools/README.md`
- This doc adds **no new workflow / ACP / conflict-key family** in v0; any future external supervisor/admin surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_supervision_posture.py` fails `make lint` if this posture stops being discoverable,
  loses the **component-rooted / bounded Stop→Kill / no portable pidfd-or-Job-Object control plane /
  manifest+activation replay only / no new workflow-ACP surface** posture, or drops its primary REF wiring.

## References

- REF-ERLANG-OTP-PRINCIPLES.
- REF-MINIX-RELIABLE-OS.
- REF-SYSTEMD-SOCKET-ACTIVATION.
- REF-SYSTEMD-FDSTORE.
- REF-FUCHSIA-RUNNER-STOP.
- REF-WIN-JOBOBJECTS.
- REF-LINUX-PIDFD.
