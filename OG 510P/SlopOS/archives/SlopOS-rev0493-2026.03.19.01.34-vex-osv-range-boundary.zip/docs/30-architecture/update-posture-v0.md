# Update posture v0 (digest-bound install intent; no channel/rollout/verdict semantics)

Purpose: pin the Phase-1 meaning of **D-ATOMICUPD** / **CH-UPD v0** so update intent does not quietly regrow into repository-metadata folklore, rollout/control policy, or a hidden verification-summary channel.

This posture is intentionally narrower than the wider TUF / Uptane / A/B / image-update ecosystem. It fixes the portable meaning of **CH-UPD admission and use** while keeping repository freshness metadata, staged-rollout policy, fleet targeting, verification summaries, and live query/discovery APIs outside the native authority substrate unless another seam admits them explicitly.

## Posture (v0)

1) **CH-UPD is digest-bound install intent only.**
   - Accepted CH-UPD meaning is the bounded statement **“install this exact deployment root with this exact configuration/policy binding”** under **I-ATOMICUPD-1**, **I-ATOMICUPD-2**, **PO-UPD-VERIFY**, and the relevant boot/rollback obligations.
   - CH-UPD MUST NOT by itself authorize network fetch, repository trust, policy widening, fleet enrollment, or a hidden “approved-good release” verdict.

2) **One manifest, one target deployment/config cohort; no portable channel/ring/percentage-rollout semantics.**
   - A CH-UPD artifact describes one reviewed target deployment root (`target_root_digest`) and one reviewed config/policy binding (`cfg_digest`).
   - Phase 1 adds no native “stable/testing ring”, “deploy to 10%”, “VIN/cohort targeting”, “supersedes prior release”, or “latest release on channel X” meaning. Any such rollout logic remains explicit repository/fleet tooling outside D-ATOMICUPD itself.

3) **Digest binding is authoritative; names, labels, and packaging metadata are observational.**
   - The portable binding is `target_root_digest`, `cfg_digest`, and the exact adjunct digests listed in `artifacts[]`.
   - Filenames, package names, version strings, channel labels, repo paths, and UI-friendly release names are operator/debug aids only and MUST NOT become ambient compatibility or authorization selectors.

4) **`artifacts[]` is a bounded attachment set, not a fetch plan or package inventory protocol.**
   - `artifacts[]` may pin adjunct evidence/closure digests such as `kernel`, `init`, `recovery_root`, `sbom`, `vex`, `upd_manifest`, `proof_bundle`, or `boot_selector`.
   - Companion boundary `proof-bundle-role-boundary-v0.md` pins that `proof_bundle` remains a descriptive adjunct-evidence role only; local policy must still say whether any exact bundle digest matters.
   - Companion boundary `update-evidence-subject-boundary-v0.md` further pins that supporting evidence may appraise the pinned `(target_root_digest, cfg_digest)` cohort but must not widen or redefine what CH-UPD installs.
   - Companion boundary `provenance-required-subject-boundary-v0.md` further pins that any stricter provenance requirement must be chosen only from those exact already-pinned staged digests rather than from every subject in a larger release attestation.
   - Companion boundary `provenance-coverage-policy-boundary-v0.md` further pins that there is no artifact-borne provenance-coverage profile or policy-tier selector on CH-UPD; carrier-borne provenance fields name exact evidence bytes only.
   - Companion boundary `provenance-evidence-set-boundary-v0.md` further pins that there is no native cross-artifact provenance closure, union, or fallback rule on CH-UPD; several exact provenance-bearing artifacts stay several exact evidence inputs.
   - Companion boundary `sbom-vex-evidence-set-boundary-v0.md` further pins that there is no native cross-artifact SBOM/VEX applicability closure on CH-UPD; several exact inventory/exploitability artifacts stay several exact evidence inputs.
   - Companion boundary `vex-component-absence-boundary-v0.md` further pins that there is no native component-absence oracle on CH-UPD; `component_not_present` plus one selected inventory may inform local verdicts, but completeness judgment stays verifier-local.
   - Companion boundary `vex-remediation-selection-boundary-v0.md` further pins that there is no native patch-plan or update-target selector on CH-UPD; `fixed` / remediation text may inform local policy, but successor selection stays on explicit CH-UPD / TUF / repository logic.
   - Companion boundary `vex-investigation-deferral-boundary-v0.md` further pins that there is no native install-hold or defer-update selector on CH-UPD; `under_investigation` / VEX time fields may inform local caution or review, but hold/grace behavior stays on explicit local policy rather than advisory cadence.
   - Companion boundary `vex-priority-signal-boundary-v0.md` further pins that there is no native install-veto, rollout-priority, or urgency selector on CH-UPD; imported vulnerability scores / threat-list signals may inform local triage, but thresholds and score fusion stay on explicit verifier-local policy rather than advisory folklore.
   - Companion boundary `vex-cpe-applicability-boundary-v0.md` further pins that there is no native install-target selector, product-identity oracle, or applicability-closure rule on CH-UPD; imported CPE names / applicability expressions may inform local targeting checks, but matching and logical evaluation stay explicit verifier-local policy rather than advisory folklore.
   - Companion boundary `vex-osv-range-boundary-v0.md` further pins that there is no native OSV-derived version-ordering or successor-selection rule on CH-UPD; imported OSV package / ecosystem / range semantics may inform local advisory matching, but any range expansion, fixed-version reasoning, or package correlation stays explicit verifier-local policy rather than carrier meaning.
   - Phase 1 adds no recursive fetch/install order, no package-manager semantics, no “install every listed component independently”, and no hidden dependency solver. Retrieval and transport remain external tooling concerns.

5) **Timestamps and freshness hints are informational until explicit policy validates them.**
   - `created_at` and `expires_at` may inform local policy, but they are not trusted merely because they appear in CH-UPD.
   - Freshness / freeze / replay protection remains on explicit **D-TUF**, **D-TIME**, and local verifier policy rather than on unauthenticated clock assumptions or “newest timestamp wins” folklore inside CH-UPD itself.

6) **CH-UPD is not repository metadata, a verification summary, or a policy verdict.**
   - Repository consistency/freshness roles such as TUF `root` / `targets` / `snapshot` / `timestamp` stay on **D-TUF**.
   - Verification results, waivers, health outcomes, and admission conclusions remain separate receipts/evidence; Phase 1 does not overload CH-UPD into a “verified-good”, “all checks passed”, or “approved for fleet” object.

7) **Rollback semantics are explicit and bounded; there is no latest-wins or implicit supersession rule.**
   - If `rollback_floor` is present, it is the only native monotonic anti-rollback field carried on CH-UPD.
   - Phase 1 adds no implicit “newer replaces older”, no semantic-version ordering, and no hidden precedence rule among multiple CH-UPD artifacts beyond explicit selector/repository policy.

8) **Distribution and discovery stay tooling-only.**
   - CH-UPD may be carried by TUF/Uptane-style repositories or owner-local stores, but Phase 1 does not standardize a privileged-core update-feed client, query API, or ambient release-discovery protocol.
   - Consumers already holding one CH-UPD artifact may verify it under local policy; discovering more manifests is a separate explicit tooling concern.

9) **No new workflow / ACP / conflict-key family in v0.**
   - D-ATOMICUPD reuses existing boot/signature/time/transparency/evidence seams.
   - Any future publication/approval/rollout workflow for updates must return RFC-first with explicit conflict keys, commutativity rules, serialization boundary, and evidence.

## Phase 1 non-goals (explicitly deferred)

- No channel/ring/cohort/percentage rollout language inside CH-UPD.
- No repository freshness / delegation / snapshot semantics inside CH-UPD.
- No verification-summary / waiver / approval-verdict semantics inside CH-UPD.
- No package inventory / dependency solver / component-level mutation semantics inside `artifacts[]`.
- No latest-wins / semantic-version ordering / supersession rules on the native seam.
- No privileged-core query / feed / discovery plane for updates.
- No new workflow / ACP family for update publication or approval.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-ATOMICUPD**, **D-TUF**, **D-UPD-SIGN**, **D-BOOT**, **D-TIME**.
- Core schema / lifecycle seams:
  - `docs/30-architecture/update-manifest-schema-v0.md` (CH-UPD v0).
  - `docs/30-architecture/boot-selector-state-schema-v0.md` (CH-BOOTSEL v0).
  - `docs/30-architecture/recovery-posture-v0.md`.
  - `docs/30-architecture/signature-envelope-posture-v0.md`.
  - `docs/30-architecture/provenance-posture-v0.md`.
  - `docs/30-architecture/update-evidence-subject-boundary-v0.md`.
  - `docs/30-architecture/sbom-posture-v0.md`.
  - `docs/30-architecture/vex-posture-v0.md`.
  - `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`.
  - `docs/60-engineering/update-repository-metadata-and-key-rotation.md`.
- Assurance anchors:
  - Invariants: **I-ATOMICUPD-1**, **I-ATOMICUPD-2**, **I-ATOMICUPD-3**, **I-BOOT-2**.
  - Proof obligations: **PO-UPD-VERIFY**, **PO-ATOMICUPD-SWITCH**, **PO-ATOMICUPD-ROLLBACK**, **PO-BOOTSEL-VALIDATE**, **PO-ATOMICUPD-COMMIT**, **PO-SIGENV-VERIFY**, **PO-PROV-BIND**.
  - Adjacent seams: **D-TUF** for repository metadata/freshness, **D-UPD-SIGN** / **D-SIGENV** for signature policy, **D-TIME** for freshness policy, **D-RECOVERY** for sealed rescue targets.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - `tools/check_update_posture.py` keeps the posture small and discoverable (**EVID-2026-460**).

## References

- REF-RPM-OSTREE
- REF-ANDROID-AB
- REF-CHROMEOS-UPDATEENGINE
- REF-TUF-SPEC
- REF-UPTANE-STANDARD2
