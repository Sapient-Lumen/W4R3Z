# LLM-operations posture v0 (proposal-only, explicit tool/context catalogs, no prompt authority)

Purpose: pin the Phase-1 meaning of **D-LLM** so the agent/automation shape does not quietly regrow ambient memory, prompt-as-policy, or dynamic connector folklore.

The archive already has the ACP validator semantics, request-context bindings, and threat notes. This posture makes the missing small hard decision explicit: **LLM output is proposal material only**, and the surrounding tool/context surfaces stay explicit, bounded, and killable rather than becoming a second authority substrate.

## Posture (v0)

1) **Text is proposal-only.**
   - Model output, prompt completions, chain-of-thought surrogates, tool annotations, and retrieved text are **non-authoritative inputs** only.
   - Privileged effects MUST still flow through explicit schemas plus explicit authorization under **I-LLM-1**, **PO-ACT-VALIDATE**, and **PO-ACT-BIND**.

2) **The portable effectful seam is CH-ACP plus existing reviewed portals/components.**
   - Phase 1 LLM-driven effects use the already-pinned **IF-ACP** validator path, existing `portal.*` families, `capshell.exec`, or other explicitly reviewed seams.
   - D-LLM does **not** add a second “agent runtime may just do things” execution path.

3) **Tool, resource, and prompt catalogs are explicit and bounded.**
   - Any tool/resource/prompt surface exposed to an LLM MUST be attached by explicit local configuration, profile policy, or reviewed session wiring.
   - Phase 1 imports **no portable ambient connector discovery**, no hidden filesystem/network/service inventory, and no native assumption that the available tool list may widen at runtime without explicit local review.

4) **Prompts and metadata do not carry authority.**
   - System prompts, prompt templates, tool descriptions, resource descriptions, and example transcripts MAY inform proposals, but they MUST NOT by themselves grant permissions, select a payer, override policy, bind approvals, or widen the accepted schema/field set.
   - Policy remains on explicit CH-POLICY / approvals / lane gates / config, not in prompt prose.

5) **Memory is explicit or it does not count.**
   - Durable memory, retrieval corpora, prior transcripts, vector indexes, and scratchpads only matter when attached through explicit artifact / observation seams.
   - Phase 1 imports **no hidden cross-run memory**, no ambient “current conversation state” authority, and no implicit retrieval plane that silently widens what the validator may trust.

6) **Model/provider identity is observational, not privileged.**
   - Choosing a model family, provider, sampler, or host runtime may affect quality/latency, but MUST NOT change what actions are authorized.
   - Swapping providers or local-vs-remote execution is not a portable permission primitive in v0.

7) **No portable self-extension / connector-install / prompt-programming control plane in v0.**
   - D-LLM adds no native install/enable/disable/list/watch surface for tools, connectors, prompts, memories, or policies.
   - Any future such workflow must return RFC-first on an explicit reviewed seam with conflict keys, kill switches, and evidence.

8) **Human approval stays explicit when required.**
   - If a workflow/profile requires user consent, higher-grade approval, or narrow route selection, the approval object remains explicit and transcript-visible.
   - “The model asked for it” or “the tool suggested it” is never sufficient authority.

9) **No new workflow / ACP / conflict-key family in v0.**
   - D-LLM is a posture over existing validator, receipt, request-context, observation, and policy seams.
   - This doc adds no new `portal.*` family, no new CH-ACP kind, and no new conflict-key namespace.

## Phase 1 non-goals (explicitly deferred)

- No portable MCP-style tools/resource/prompt listing or list-changed contract as native authority semantics.
- No portable server-initiated sampling / elicitation / logging callback plane in privileged code.
- No generic long-lived agent memory substrate or hidden prompt store.
- No “prompt text is policy” or “tool description is capability” shortcut.
- No portable auto-install / auto-enable / auto-discover connector ecosystem.
- No claim that hosted providers, frontier models, or proprietary agent runtimes are part of the TCB.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-LLM**.
- Core control-plane seams:
  - `docs/70-llm-control/README.md`.
  - `docs/70-llm-control/llm-threats.md`.
  - `docs/70-llm-control/acp-action-schema-v0.md` (CH-ACP v0).
  - `docs/70-llm-control/acp-validator-semantics.md`.
  - `docs/30-architecture/request-context-schema-v1.md` (CH-REQCTX v1).
  - `docs/30-architecture/observation-export-posture-v0.md` and `docs/30-architecture/observation-export-policy-schema-v0.md` for explicit observation/memory inputs.
- Assurance anchors:
  - Claim: **C-LLM-1**.
  - Invariants: **I-LLM-1**, **I-LLM-2**, **I-OBS-2**.
  - Proof obligations: **PO-ACT-VALIDATE**, **PO-ACT-BIND**, **PO-ACT-COMPOSE**, **PO-OBS-NOTAUTH**.
  - Adjacent decision surfaces: **D-POLICY**, **D-REQCTX**, **D-OBS**, **D-CAPSHELL**, **D-COMMUTE**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - `docs/00-meta/llm-runbook.md` adds it to the must-read set so future archive passes do not forget the boundary.
  - `tools/check_llm_posture.py` keeps the posture discoverable and prevents prompt-authority / hidden-memory / dynamic-tool-catalog drift (EVID-2026-456).

## References

- REF-MCP-SPEC
- REF-MCP-TOOLS
- REF-MINISCOPE-ARXIV25
- REF-AIOS-ARXIV24
