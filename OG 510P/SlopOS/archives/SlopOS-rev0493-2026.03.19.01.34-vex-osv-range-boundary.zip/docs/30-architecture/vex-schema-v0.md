# CH-VEX v0: normalized vulnerability exploitability statements (digest-bound)

Purpose: represent VEX (Vulnerability Exploitability eXchange) as a **bounded, content-addressed evidence artifact** that can be attached to releases/boots and verified for *subject binding*.

This schema is intentionally small and normalized; it is not a full OpenVEX/CSAF/CycloneDX replacement.
If richer advisory metadata is needed, link to an external document via CH-AREF.

References: REF-CISA-VEX-MINREQ, REF-OPENVEX-SPEC, REF-OPENVEX-REL, REF-CSAF-ISO.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-VEX v0 := {
  v: 0,

  subject: {
    kind: tstr,            ; closed enum: "deployment_root" | "component" | "bundle"
    digest_alg: tstr,      ; e.g., "sha256"
    digest: bstr,          ; digest bytes
    name?: tstr,           ; optional display name (bounded)
    version?: tstr,        ; optional display version (bounded)
  },

  generated_at_s?: uint,   ; informational only

  author?: {
    org?: tstr,            ; bounded
    contact?: tstr,        ; bounded
  },

  generator?: {
    comp_id?: tstr,        ; optional identity of generator component/tooling
    tool?: tstr,           ; optional tool name
    tool_ver?: tstr,       ; optional tool version
  },

  inventory_digest?: { digest_alg: tstr, digest: bstr },  ; optional: digest of a CH-SBOM for the same subject

  statements: [ + VexStatement ],    ; bounded list

  external_doc_aref?: { digest_alg: tstr, digest: bstr }, ; optional: digest of a CH-AREF that locates a full OpenVEX/CSAF/CycloneDX doc

  meta?: { * tstr => any }           ; optional; MUST be ignored unless explicitly allowlisted
}

VexStatement := {
  vuln_id: tstr,          ; bounded exact label; e.g., "CVE-2025-12345" (do not assume only CVE)

  status: tstr,           ; closed enum: "affected" | "not_affected" | "fixed" | "under_investigation"

  ; Optional component scoping. If absent, statement applies to the whole subject.
  component?: {
    content_digest?: { digest_alg: tstr, digest: bstr },  ; stable identity preferred
    build_id?: bstr,                                  ; optional build-id (bounded)
    name?: tstr,                                      ; optional (may be redacted)
    version?: tstr,                                   ; optional (may be redacted)
    purl?: tstr,                                      ; optional (may be redacted)
  },

  ; Why we say not_affected (or other statuses). Keep a closed set.
  justification?: {
    kind: tstr,        ; closed enum:
                      ;  "component_not_present" |
                      ;  "vulnerable_code_not_present" |
                      ;  "vulnerable_code_not_in_execute_path" |
                      ;  "vulnerable_code_cannot_be_controlled_by_adversary" |
                      ;  "inline_mitigations_already_exist" |
                      ;  "requires_configuration_not_present" |
                      ;  "unknown"    ; allowlisted fallback

    note?: tstr        ; bounded; short human hint; MUST NOT be unbounded narrative
  },

  action?: tstr,          ; bounded; optional short remediation hint (non-normative)

  issued_at_s?: uint,     ; informational
  expires_at_s?: uint,    ; informational; policy may require bounded freshness windows

  references?: [* tstr]   ; bounded list of reference strings/IDs (not raw secrets)
}

Notes:
- CH-VEX is **evidence**, not authority. It must not be treated as an authorization input.
- `inventory_digest` is an optional pointer to a CH-SBOM digest that provides component context.
- Companion `vex-component-absence-boundary-v0.md` further pins that `component_not_present`, absence from one selected inventory, or richer imported completeness metadata do not become a native absence oracle; completeness and component matching stay verifier-local.
- Companion `vex-remediation-selection-boundary-v0.md` further pins that `fixed`, `action`, or richer imported remediation metadata do not become a native patch-plan selector, minimum-safe-version oracle, or successor-target chooser; exact update selection stays on CH-UPD / TUF / local policy.
- Companion `vex-investigation-deferral-boundary-v0.md` further pins that `under_investigation`, `generated_at_s`, `issued_at_s`, and `expires_at_s` do not become a native hold/defer or grace-period selector; unresolved-advisory handling stays explicit verifier-local policy.
- Companion `vex-vulnerability-identity-boundary-v0.md` further pins that `vuln_id` is one exact advisory label only; richer alias / upstream / related / canonicalization semantics stay verifier-local or imported evidence only.
- Companion `sbom-purl-identity-boundary-v0.md` further pins that component-scoped `purl` remains imported package-reference evidence rather than a native same-component join key or canonical package identity; matching/normalizing package URLs stays verifier-local.
- Companion `sbom-component-version-boundary-v0.md` further pins that `subject.version` and component-scoped `version` remain imported descriptive labels rather than native same-component or version-ordering semantics; matching or ordered version strings stay verifier-local.
- Companion `vex-statement-key-boundary-v0.md` further pins that `statements[]` order has no semantics and one exact native statement key is `(vuln_id, component-scope)` within the already-bound subject and MUST appear at most once; duplicate or contradictory same-key rows fail closed rather than invoking a native last-wins / history rule.
- Companion `vex-priority-signal-boundary-v0.md` further pins that richer advisory scoring / prioritization signals stay imported evidence rather than a native install-veto, waiver, or rollout-priority plane; any CVSS / EPSS / KEV / vendor-severity thresholds remain verifier-local policy.
- Companion `vex-cpe-applicability-boundary-v0.md` further pins that richer imported CPE names / applicability expressions remain targeting evidence rather than a native same-product, applicability, or install-scope rule; any CPE dictionary / match / applicability evaluation stays verifier-local.
- Companion `vex-reference-locator-boundary-v0.md` further pins that statement `references[]` and richer imported advisory links stay descriptive evidence rather than a native fetch, discovery, resolver, or latest-by-link rule; any dereference/prioritization stays verifier-local.
- Companion `vex-osv-range-boundary-v0.md` further pins that imported OSV package / ecosystem / range fields stay advisory matching evidence rather than a native same-component, version-ordering, update-selection, or suppression rule; any OSV range expansion/evaluation stays verifier-local.
- `external_doc_aref` is a pointer to a CH-AREF record that can locate a full VEX document.
- `meta` exists for local-only annotations and MUST NOT affect verification.

## Validation rules (minimum)
A CH-VEX validator MUST be total and fail closed:
1) `v == 0`.
2) `subject.kind` and each statement `status` and `justification.kind` are allowlisted closed enums.
3) `subject.digest_alg` is allowlisted; `subject.digest` is present and length-bounded.
4) `statements` length is bounded; each statement enforces string/list bounds.
5) Unknown fields reject (or are rejected by canonical CBOR decode); `meta` MUST be ignored unless explicitly allowlisted.
6) If `inventory_digest` is present, it MUST be a digest reference to a CH-SBOM artifact for the same subject under the chosen profile mapping.
7) If `external_doc_aref` is present, it MUST be a digest reference to a CH-AREF object; the CH-AREF validator applies (PO-AREF-VERIFY).
8) `statements[]` order carries no native semantics, and for the already-bound subject each exact native statement key (`vuln_id` + exact optional component scope, with absent component meaning whole-subject scope) MUST appear at most once; duplicate or contradictory same-key rows MUST be rejected (PO-VEX-VALIDATE).

## Binding rules (recommended)
When a CH-VEX digest is referenced as an artifact:
- If `role == "vex"` in CH-UPD `artifacts[]`, verifiers SHOULD check:
  `vex.subject.kind == "deployment_root"` and `vex.subject.digest == upd.target_root_digest`.
- If `role == "vex"` in CH-BOOT `artifacts[]`, verifiers SHOULD check:
  `vex.subject.digest == boot.root_digest` (or the active deployment root digest).

These checks support I-VEX-1 and PO-VEX-BIND.

## Security notes
- **Avoid drift**: subject binding prevents “VEX for A shipped with B.”
- **Noise reduction vs suppression**: VEX reduces false positives but can also be abused to hide real issues. Treat statements as signed, reviewable evidence and scope export.
- **Export hygiene**: VEX may leak internal mitigations/topology; exporting CH-VEX should be governed by CH-OBSPOL tiers, and optional component identifiers may be redacted.
- **DoS bounds**: keep statement list length and string sizes bounded; large external docs should be referenced via CH-AREF.
