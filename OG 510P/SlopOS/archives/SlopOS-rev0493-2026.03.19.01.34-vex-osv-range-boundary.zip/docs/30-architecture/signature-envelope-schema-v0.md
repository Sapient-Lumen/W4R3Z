# CH-SIGENV v0 (signature envelope over payload digests, informal)

Purpose: provide a small, canonical “this payload digest was signed” envelope for CH-* artifacts.

Pinned posture: `signature-envelope-posture-v0.md` fixes the Phase-1 meaning of D-SIGENV / D-KEYLESS as **typed digest-binding plus local policy**: verification is offline-first and policy-local, signer hints are non-authoritative, keyless stays optional explicit issuer/identity policy, and transparency material remains evidence rather than an ambient online dependency. Companion boundary `keyless-issuer-discovery-boundary-v0.md` pins that issuer metadata/discovery docs and signer-side service descriptors remain adjunct artifacts rather than native CH-* meaning, companion `verification-material-discovery-boundary-v0.md` pins that sidecar names / OCI referrers / attachment enumeration remain out-of-band discovery hints rather than native verification authority, while `verification-verdict-boundary-v0.md` keeps successful signature verification from silently becoming a portable approval or waiver object, and `signing-time-evidence-boundary-v0.md` pins signing-time evidence to exact signing-event bytes rather than payload-only timestamp folklore.

Design rules:
- the envelope signs a **payload digest + payload type** (domain separation)
- no requirement to embed the payload bytes (keep envelopes small)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- bounded lists and closed enums (no unbounded narratives)

This schema is DSSE-inspired: signatures are computed over a pre-auth encoding of `(payload.schema, payload.digest)` rather than over an ad-hoc concatenation.

Refs: REF-DSSE, REF-DSSE-BACKGROUND.

## Shape (v0)
An envelope `s` contains:
- `schema`: fixed `CH-SIGENV v0`

### Payload binding
- `payload`:
  - `schema`: bounded string (e.g., `CH-UPD v0`, `CH-PROV v0`, `CH-CFG v0`)
  - `digest`: digest of the canonical payload bytes (same digest namespace as CH-BOOT)
  - `size_bytes`: optional u64 (informational)

### Signatures
- `signatures`: bounded list of signature records (at least 1)

Each signature record `sig` contains:
- `kind`: closed enum `{ direct_key, keyless_cert }`
- `alg`: closed enum (v0): `{ ed25519, ecdsa_p256_sha256, rsa_pss_sha256 }` (exact signature-algorithm identifier for this record; acceptance remains explicit verifier-local policy under `signature-algorithm-acceptance-boundary-v0.md`)
- `sig_bytes`: bytes

Signer material (depends on `kind`):
- if `kind = direct_key`:
  - `key_id`: bounded string (must match an allowlisted verifier key id; unauthenticated hint only, never sufficient for a security decision by itself)
  - `pubkey_spki`: optional bytes (SPKI DER) (may be omitted if the verifier already knows the key by `key_id`)
- if `kind = keyless_cert`:
  - `cert_digest`: digest of the leaf X.509 certificate (DER)
  - `issuer`: bounded string (OIDC issuer / CA instance identifier)
  - `identity`: bounded identity hints (non-authoritative; policy-checked):
    - `subject`: bounded string
    - `repo`: optional bounded string (e.g., `org/repo`)
    - `workflow`: optional bounded string
    - `commit`: optional bounded string

Optional transparency anchoring:
- `tlog_anchor_digest`: optional digest of a `CH-TLOG v0` artifact relevant to the signing event (for example anchoring the exact CH-SIGENV bytes, a signed statement/envelope digest, or a higher-level signed bundle digest under explicit local policy); it MUST NOT be interpreted as a generic “payload timestamp = signature time” shortcut

## Verification obligations
- PO-SIGENV-VALIDATE: deterministic decode, canonical bytes, bounds, closed enums.
- PO-SIGENV-VERIFY: verify signatures over the DSSE-style pre-auth encoding of `(payload.schema, payload.digest)`.
- PO-KEYLESS-VERIFY (if enabled): validate cert chain + issuer allowlist + identity allowlist + validity window.

Notes:
- `key_id` in `direct_key` records is an unauthenticated hint; verifiers must not use it as authority by itself.
- `alg` is exact signed evidence of how the signature was produced, not a portable statement that the verifier must accept that algorithm; accepted signature/message algorithms remain explicit verifier-local policy, and multiple signatures do not imply strongest-wins fallback or negotiation (`signature-algorithm-acceptance-boundary-v0.md`).
- `identity` fields in `keyless_cert` records are **hints**; verifiers must not trust them unless they re-derive/check against the certificate claims per the profile policy.
- Certificate bytes, bundle payloads, inclusion proofs, and any RFC 3161 / COSE timestamp records are intentionally out-of-band. If needed, store them as content-addressed blobs and reference via CH-AREF in a higher-level bundle. Sidecar names / OCI referrers / attachment enumeration remain out-of-band discovery hints under `verification-material-discovery-boundary-v0.md`; they do not become native verification authority.
- Exact signing-time semantics are pinned separately in `signing-time-evidence-boundary-v0.md`: payload-only timestamps prove earlier payload existence, not necessarily signature creation time.
- Phase 1 verification is offline-first and policy-local: CH-SIGENV does not imply any portable online fetch of cert chains, transparency proofs, timestamp chains, or identity metadata.
- Companion boundary `certificate-path-input-boundary-v0.md` pins that certificate/path inputs remain explicit local policy inputs rather than ambient discovery, and that AIA / `caIssuers` locator fields do not create a native alternate-chain or trust-store search plane.
- Companion boundary `certificate-status-evidence-boundary-v0.md` pins that certificate-status artifacts remain explicit local evidence inputs rather than ambient latest-status discovery, and that CRL / delta-CRL / OCSP locator fields do not create a native status-fetch or cache-authority plane.
- Companion boundary `certificate-identity-evidence-boundary-v0.md` pins that certificate-borne SAN / subject / issuer / custom OID claims remain exact signed evidence under explicit local interpretation rather than ambient best-identity selection, wildcard matching, or repo-owner lookup semantics.
- Companion boundary `signature-trust-root-boundary-v0.md` pins that trusted-root carriers and signer-service descriptors remain adjunct artifacts rather than native CH-* meaning, that trust roots/log keys/TSA roots stay explicit local inputs or explicit D-TUF/provisioning artifacts, and that CH-SIGENV does not imply bundle self-anchoring or service-discovery semantics.
