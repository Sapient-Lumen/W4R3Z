# Transparency-log posture v0 (exact append-only audit evidence; no latest/query/freshness authority)

Purpose: pin the Phase-1 meaning of **D-TLOG** (and its optional **D-WITNESS** adjunct) so transparency anchors stop inheriting ecosystem folklore about discovery APIs, latest-checkpoint truth, or online policy oracles.

This posture is intentionally narrower than a generic transparency service. It defines the **portable meaning of CH-TLOG evidence** while keeping log hosting, submission APIs, query paths, mirror topologies, and operator playbooks outside the native authority substrate unless another seam admits them explicitly.

## Posture (v0)

1) **CH-TLOG binds one exact artifact digest to one exact log state.**
   - Accepted meaning is the verified claim that **`leaf_digest` of `leaf_kind`** was included relative to the exact checkpoint carried or referenced by the anchor.
   - `log_id`, `pubkey_id`, `tree_size`, `root_hash`, and any proof digests are part of that exact evidence tuple.
   - A verifier MUST reject any attempt to treat filenames, release names, mutable tags, package coordinates, or unauthenticated locators as the portable anchored subject.

2) **Inclusion evidence is not the same thing as complete log verification.**
   - A valid inclusion proof answers whether one exact entry was present at one exact log state.
   - Append-only growth, same-view/equivocation resistance, and semantic review of logged entries are distinct checks that remain explicit verifier work.
   - Phase 1 therefore refuses to equate “has a receipt” with “the log is fully verified” or “the publisher is approved”.

3) **Verification is offline-first and policy-local.**
   - Phase 1 verification uses locally available anchor material, locally pinned log public keys / acceptable origins / witness policy, and local policy.
   - D-TLOG adds no portable requirement to query a live log, fetch fresh checkpoints, chase proof URLs, or contact witnesses before an anchor has any meaning.
   - Tooling may refresh evidence online, but privileged-core meaning must remain evaluable from exact artifacts plus local policy.

4) **Checkpoint order is append-only evidence, not global freshness, time, or runtime sequencing authority.**
   - `tree_size`, checkpoint succession, and witness countersignatures speak only about append-only log evolution for one `log_id`.
   - They do not become a wall-clock, lease-freshness source, scheduler order oracle, rollout channel clock, or ambient “later therefore better” rule.
   - Any freshness or expiry decision still rides on explicit local policy plus already-pinned **D-TIME**, **D-TUF**, and verification-verdict seams.

5) **Witnesses remain explicit optional corroboration, not auto-discovered trust.**
   - If **D-WITNESS** is enabled, witness material strengthens split-view resistance only when checked against a locally pinned witness set and threshold.
   - accepted witness identities/quorums/extra statements stay explicit local policy; witness signatures do not auto-enroll new witnesses, rotate quorums, or silently promote a checkpoint into install or approval authority.
   - Phase 1 adds no native witness discovery, gossip, or threshold-negotiation plane; the narrower witness-policy seam is pinned in `transparency-witness-acceptance-boundary-v0.md`.

6) **CH-TLOG and SCITT-style receipts remain evidence artifacts, not install or approval shortcuts.**
   - Transparency anchors may strengthen auditability for signed statements, provenance, or updates.
   - They do not by themselves authorize boot, install, secret release, ACP admission, or policy waiver, and they do not replace local verification of the underlying signed statement.
   - Exact signing-time meaning is pinned separately in `signing-time-evidence-boundary-v0.md`: logging or timestamping raw payload bytes alone does not automatically prove when a later signature was created.
   - This keeps D-TLOG aligned with the already-pinned release-identity and verification-verdict boundaries.

7) **Offline proof transport stays exact and external.**
   - If a deployment wants a self-contained inclusion+witness package, Phase 1 carries an exact external proof artifact (prefer C2SP `tlog-proof@v1`) by digest via `CH-AREF`, release-bundle manifests, or other explicit evidence handoff.
   - `CH-TLOG` does not grow inline witness-signature arrays, Merkle path blobs, or an ad-hoc proof-refresh protocol; the narrower transport/import seam is pinned in `transparency-proof-import-boundary-v0.md`.
   - Imported proof bytes remain evidence under explicit local log/witness policy and do not create install, approval, or discovery authority.

8) **No native submission/query/watch/admin surface in v0.**
   - Phase 1 adds no portable `submit`, `lookup`, `get latest checkpoint`, `watch log`, `discover mirrors`, or `refresh receipt` API on the authority substrate.
   - Rekor, Tessera, SCITT receipt/query APIs, and witness networks remain tooling/interop choices above the native seams.
   - Any future online transparency client surface must return RFC-first with its own subject model, trust roots, conflict keys, commutativity story, serialization boundary, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No portable transparency-service client or admin API.
- No “latest checkpoint wins” or “newer receipt outruns older local policy” rule.
- No use of checkpoint order/tree size as a global time source, sequencer, or rollout oracle.
- No automatic witness discovery, quorum negotiation, or trust-root rotation from evidence artifacts.
- No rule that a transparency receipt alone satisfies install, boot, or approval policy.

## Wiring

- Decision surfaces:
  - `docs/30-architecture/decision-map.md` → **D-TLOG**, **D-WITNESS**, **D-PCP**, **D-SIGENV**, **D-ATOMICUPD**.
- Core seams:
  - `docs/30-architecture/transparency-log-anchor-schema-v0.md` (CH-TLOG v0).
  - `docs/30-architecture/tlog-replication-boundary-v0.md`.
  - `docs/30-architecture/transparency-witness-acceptance-boundary-v0.md`.
  - `docs/30-architecture/transparency-proof-import-boundary-v0.md`.
  - `docs/30-architecture/verification-verdict-boundary-v0.md`.
  - `docs/30-architecture/release-identity-boundary-v0.md`.
- Engineering / RFC surfaces:
  - `docs/60-engineering/pcp-posture-v0.md`.
  - `docs/60-engineering/supply-chain-repro.md`.
  - `rfcs/0029-transparency-log-anchors-for-evidence.md`.
  - `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md`.
- Assurance anchors:
  - **I-TLOG-1**, **I-TLOG-2**, **PO-TLOG-VERIFY**, **PO-TLOG-WITNESS**.
- Discovery / CI:
  - `docs/30-architecture/posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this posture.
  - `tools/check_transparency_log_posture.py` keeps the posture small and discoverable (**EVID-2026-464**).

## References

- **REF-CT-RFC9162**
- **REF-TESSERA**
- **REF-TRANSPARENCY-WITNESS**
- **REF-TRANSPARENCY-VERIFY**
- **REF-SCITT-CCF-RECEIPTS**
