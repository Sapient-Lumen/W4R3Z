# D-PCP v0 posture: release-only proof-carrying provenance

**Status:** pinned v0 posture (no new schemas; tooling-only interop).  
**Decision surface:** D-PCP (see `docs/30-architecture/decision-map.md`).

## One-sentence
Proof-carrying provenance (PCP) is a **release pipeline artifact**: we bind what boots to signed, digest-addressed provenance (and optional transparency receipts), while keeping boot-time verification small and deterministic.

## v0 posture (hard decision)
**v0 posture: release-only PCP.**

- PCP is produced **at release time** (CI/build farm) and shipped alongside update metadata.
- IF-BOOT may verify *binding* if a profile enables it, but IF-BOOT does **not** validate proofs/models/large evidence corpora.
- Higher-assurance profiles MAY require that a deployment root includes:
  - `digest(CH-PROV v0)` and a validating `CH-SIGENV v0` over that digest (D-SIGENV), and
  - optionally a `CH-TLOG v0` anchor (D-TLOG) and/or witness-backed checkpoint policy (D-WITNESS).

Non-goals for v0:
- “PCP on every boot” (boot should remain offline-capable and non-brittle).
- making the kernel or IF-BOOT speak a specific transparency API.
- embedding bulky proof bytes in the boot path.

## What “proof-carrying” means in SlopOS artifacts
PCP is a *digest-bound bundle* shaped around existing seams:

- **Subject:** the booted deployment is already digest-addressed (CH-BOOT `root_digest`, profile hash suite; D-BOOT/D-HASH).
- **Provenance statement:** CH-PROV v0 points at the subject digests and records build inputs / derivations (CH-DERIV) and other typed evidence pointers via CH-AREF (D-AREF). Phase-1 meaning is pinned separately in `docs/30-architecture/provenance-posture-v0.md`: CH-PROV is digest-bound build provenance evidence only, not a release registry statement, verification summary, or recursive query/fetch protocol.
- **Release identity boundary:** release names/version strings/purls/slugs remain observational distribution identifiers under `docs/30-architecture/release-identity-boundary-v0.md`; mapping those labels to install authority still requires exact digests plus explicit update/signature policy.
- **Verification-verdict boundary:** verification conclusions remain consumer-local under `docs/30-architecture/verification-verdict-boundary-v0.md`; imported summaries or reviewer statements may travel as evidence, but there is no native verified-good/waiver/latest-verified plane and no third-party install shortcut.
- **Signature envelope:** CH-SIGENV v0 signs `(payload.schema, payload.digest)` (prevents type confusion; D-SIGENV). Its v0 posture is pinned in `docs/30-architecture/signature-envelope-posture-v0.md`: verification is offline-first and policy-local, keyless is optional explicit issuer/identity policy, and transparency material stays evidence rather than a hidden online dependency. Companion `docs/30-architecture/signing-time-evidence-boundary-v0.md` pins signing-time evidence to exact signing-event bytes instead of payload-only timestamps, while companion `docs/30-architecture/certificate-status-evidence-boundary-v0.md` pins CRL / delta-CRL / OCSP handling to explicit local evidence and policy rather than ambient latest-status discovery.
- **Optional transparency receipt:** CH-TLOG v0 anchors the signed digest into one exact append-only log state (D-TLOG/D-WITNESS). The portable meaning is pinned in `docs/30-architecture/transparency-log-posture-v0.md`: inclusion evidence does not silently imply full log verification, and checkpoint order is never freshness/time/runtime authority. Companion `docs/30-architecture/transparency-witness-acceptance-boundary-v0.md` pins that witness identities/quorums remain explicit local policy rather than checkpoint-selected trust, while companion `docs/30-architecture/transparency-proof-import-boundary-v0.md` pins that offline inclusion+witness handoff prefers an exact external `tlog-proof@v1` artifact (or equivalent explicit proof bytes by digest) rather than inline proof cargo on `CH-TLOG` itself.
- **Proof-bundle role boundary:** companion `docs/30-architecture/proof-bundle-role-boundary-v0.md` pins that `proof_bundle` remains a descriptive role label for exact adjunct evidence artifacts rather than a native proof or verdict schema.
- **Update-evidence subject boundary:** companion `docs/30-architecture/update-evidence-subject-boundary-v0.md` pins that PCP/evidence attachments may appraise the exact staged cohort, but they do not redefine what CH-UPD installs or turn broader provenance subject sets into broader install authority.
- **Provenance-required subject boundary:** companion `docs/30-architecture/provenance-required-subject-boundary-v0.md` pins that required provenance coverage stays exact and carrier-pinned rather than expanding to every subject in a larger release attestation.
- **Provenance-coverage policy boundary:** companion `docs/30-architecture/provenance-coverage-policy-boundary-v0.md` pins that coverage selection remains verifier-local rather than turning CH-UPD / CH-BOOT into policy-tier selectors.
- **Provenance-container selection boundary:** companion `docs/30-architecture/provenance-container-selection-boundary-v0.md` pins that one exact provenance container may package multiple attestations, but statement selection/reconciliation stays verifier-local rather than carrier-visible semantics.
- **Provenance-evidence set boundary:** companion `docs/30-architecture/provenance-evidence-set-boundary-v0.md` pins that several exact provenance-bearing artifacts stay several exact evidence inputs rather than one native closure; cross-artifact union/fallback/completeness remains verifier-local.

This supports C-PROV-1 as a baseline (“attest build”) and makes C-PROV-2 (“end-to-end binding”) achievable *without* putting proof validators in the boot path.

## Profile implications (A–D)
We keep one substrate and let profiles dial requirements:

- (A) **Secure workstation:** default dev channels accept “no PCP” during iteration; high-assurance channels MAY require CH-PROV+CH-SIGENV and allow offline verification.
- (B) **Cloud micro-VM substrate:** fleet policy can require PCP for *all* promoted images; transparency anchoring is attractive for multi-operator auditing.
- (C) **Embedded / separation appliance:** strongest fit for “PCP required” (static compositions, tight update channels); prefer fewer roots and smaller verifier footprints.
- (D) **Agent/automation OS:** PCP is a safety primitive for toolchains and policies; agents can reason over receipts and refuse to act when provenance is missing/ambiguous.

## SCITT interop (optional, tooling-only)
If we want to interoperate with external “transparency-backed statements” ecosystems without importing their protocols into privileged code:

- Treat `digest(CH-PROV v0)` (or `digest(CH-UPD v0)`) as the **statement subject**.
- Treat CH-SIGENV as our canonical “statement signature” object (DSSE-like digest+type binding).
- Treat CH-TLOG as our minimal “log receipt anchor” seam.

Release tooling MAY additionally emit a SCITT-compatible statement/receipt bundle for ecosystem interoperability (REF-SCITT-ARCH, REF-SCITT-SCRAPI, REF-SCITT-CCF-RECEIPTS). The archive stays strict: privileged code consumes **our** schemas; SCITT formats remain an *interop layer*.

## Assurance anchors
- **PO-PROV-BIND:** if CH-BOOT includes a provenance digest, IF-BOOT verifies it is valid and bound to the booted root/policy (see `docs/20-assurance/proof-obligation-registry.md`).
- **I-PROV-CHAIN-1:** provenance and subject digests remain coherently bound (no “floating” attestations).
- **I-TLOG-1 (optional):** if transparency anchoring is claimed, anchors must verify as valid receipts.

## Evidence hooks
- **EVID-2026-212:** PCP posture drift gate + wiring checks (prevents “PCP means everything at boot” drift and keeps SCITT/receipt discussion tooling-only).

