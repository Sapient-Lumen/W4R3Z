# Release bundle manifest contract

Purpose: make the user-facing zip a **self-describing handoff artifact** instead of a bag of files whose contents must be inferred from the directory tree.

## Embedded manifest

Each archive produced by `make package-release STAMP=... SLUG=...` MUST include a root-level `RELEASE-MANIFEST.json`.

The manifest is tooling metadata, not a privileged schema or policy surface. The release-identity split is pinned in `docs/30-architecture/release-identity-boundary-v0.md`: for one bundle, `files[].sha256` is authoritative for integrity while `archive_name`, `revision`, and `slug` stay descriptive packaging metadata.

## Required fields

`RELEASE-MANIFEST.json` MUST record:
- `manifest_version`
- `archive_name`
- `revision` (from the top `CHANGELOG.md` entry)
- `revision_date`
- `packaging_timestamp`
- `slug`
- `context_pack_path`
- `files[]`, sorted by path, where each file row records at least:
  - `path`
  - `size`
  - `sha256`


## Round-trip extraction posture

Because the handoff artifact is itself a zip, unpacking a prior release bundle will materialize `RELEASE-MANIFEST.json` in the repo root. That extracted file is **not** authoritative repo input. It is unpacked bundle residue.

Rules:
- working-tree copies of `RELEASE-MANIFEST.json` MUST be ignored by packaging input selection;
- a fresh embedded manifest is regenerated for every new release bundle from the current repo tree;
- verification/review should inspect the manifest **inside the bundle being handed off**, not an extracted residue copy;
- the canonical packager self-verifies the just-built bundle against its embedded manifest before reporting success.

## Canonicalization rules

- `files[]` order is lexicographic by `path`.
- Every packaged member uses the explicit packaging timestamp from `STAMP`, not source mtimes.
- Every packaged member uses canonical archive permissions (`0644`) rather than host-specific mode leakage.
- `RELEASE-MANIFEST.json` is written last so readers can inspect the payload and then the summary.

## Why this exists

- Keeps the handoff archive reviewable without unpacking it blindly.
- Keeps bundle identity digest-authoritative: `files[].sha256` is what matters for integrity, while archive names/slugs remain descriptive.
- Makes zip payload drift observable (file list, sizes, digests).
- Keeps the packaging story aligned with archive policy: prefer hashes/pointers over copied prose (`docs/00-meta/archive-policy.md`).
- Moves the release handoff closer to reproducible-build discipline without inventing a larger release system (`REF-REPRO-BUILDS-ARCHIVES`, `REF-PYTHON-ZIPFILE`).

## Wiring

- Packaging command: `make package-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>`
- Bundle verification: `make verify-release BUNDLE=/abs/path/to/SlopOS-rev####-YYYY.MM.DD.HH.MM-<slug>.zip`
- Packager: `tools/package_release.py`
- Verifier: `tools/verify_release_bundle.py`
- Primary contract: `docs/60-engineering/release-packaging-contract.md`
- Drift gates / evidence hooks: `tools/check_release_bundle_manifest_contract.py`, `EVID-2026-278`; `tools/check_release_manifest_roundtrip_posture.py`, `EVID-2026-279`; `tools/check_release_bundle_verification_contract.py`, `EVID-2026-280`; `tools/check_release_package_self_verify.py`, `EVID-2026-281`
