# LLM runbook (avoid archive amnesia)

This runbook is a **process guardrail** for editing this living archive.
It exists to reduce “LLM drift” and keep revisions **tight, composable, and reviewable**.

## Non-negotiables (must not degrade)

1) **No ambient authority**: authority must be explicit, inspectable, and reviewable end-to-end (especially in workflows: shell/automation/CLI/UI).
2) **Sealed compatibility**: POSIX/legacy runs only as a **Foreign Cell** behind a fail-closed membrane; interop only via portals/intents/receipts; killable by policy.
3) **Multicore verification is required**: no “single-core-only” proof plan.
4) **Scalability direction**:
   - Hybrid multicore (ADR-0005): multikernel across clusters/NUMA/chiplets; SMP within a cluster.
   - Interface-first scalability: design hot-path actions to **commute** under explicit preconditions when possible; make non-commutative boundaries explicit.
5) **LLM-first ecosystem**: LLMs propose; deterministic validators execute. Schemas + validators + receipts are the stable product surface.

## Must-read set (refresh before making changes)

- `README.md`
- `docs/README.md`
- `docs/00-meta/charter.md`
- `docs/00-meta/trajectory-map.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/30-architecture/profile-default-artifact-boundary-v0.md`
- `docs/00-meta/profile-claim-matrix.md`
- `docs/30-architecture/posture-index.md`
- `docs/30-architecture/posture-doc-conventions.md`
- `docs/00-meta/archive-policy.md`
- `docs/00-meta/id-conventions.md`
- `docs/00-meta/bibliography.md`
- `docs/00-meta/evidence-index.md`
- `docs/10-threat-model/threat-model.md`
- `docs/10-threat-model/assumption-registry.md`
- `docs/20-assurance/claim-registry.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/20-assurance/non-claims.md`
- `docs/20-assurance/traceability.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/schema-registry.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/commutativity-and-interface-scalability.md`
- `docs/30-architecture/state-projection-schema-v0.md`
- `docs/30-architecture/typed-id-contract-v0.md`
- `docs/30-architecture/profile-hash-suite-v0.md`
- `docs/30-architecture/schema-canonical-bytes-v0.md`
- `docs/30-architecture/nondet-posture-v0.md`
- `docs/30-architecture/waitset-posture-v0.md`
- `docs/30-architecture/ioq-posture-v0.md`
- `docs/30-architecture/quiesce-posture-v0.md`
- `docs/30-architecture/rcu-posture-v0.md`
- `docs/30-architecture/uwait-posture-v0.md`
- `docs/30-architecture/robustlock-posture-v0.md`
- `docs/30-architecture/rseq-posture-v0.md`
- `docs/30-architecture/activation-posture-v0.md`
- `docs/30-architecture/timeproof-posture-v0.md`
- `docs/30-architecture/transparency-log-posture-v0.md`
- `docs/30-architecture/transparency-witness-acceptance-boundary-v0.md`
- `docs/30-architecture/transparency-proof-import-boundary-v0.md`
- `docs/30-architecture/proof-bundle-role-boundary-v0.md`
- `docs/30-architecture/update-evidence-subject-boundary-v0.md`
- `docs/30-architecture/provenance-required-subject-boundary-v0.md`
- `docs/30-architecture/provenance-coverage-policy-boundary-v0.md`
- `docs/30-architecture/provenance-container-selection-boundary-v0.md`
- `docs/30-architecture/provenance-evidence-set-boundary-v0.md`
- `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
- `docs/30-architecture/sbom-bomref-identity-boundary-v0.md`
- `docs/30-architecture/sbom-purl-identity-boundary-v0.md`
- `docs/30-architecture/sbom-component-version-boundary-v0.md`
- `docs/30-architecture/sbom-supplier-origin-boundary-v0.md`
- `docs/30-architecture/sbom-license-metadata-boundary-v0.md`
- `docs/30-architecture/sbom-external-reference-locator-boundary-v0.md`
- `docs/30-architecture/sbom-document-supersession-boundary-v0.md`
- `docs/30-architecture/sbom-spdx-reference-boundary-v0.md`
- `docs/30-architecture/sbom-spdx-relationship-boundary-v0.md`
- `docs/30-architecture/vex-component-absence-boundary-v0.md`
- `docs/30-architecture/vex-remediation-selection-boundary-v0.md`
- `docs/30-architecture/vex-investigation-deferral-boundary-v0.md`
- `docs/30-architecture/vex-vulnerability-identity-boundary-v0.md`
- `docs/30-architecture/vex-statement-key-boundary-v0.md`
- `docs/30-architecture/vex-priority-signal-boundary-v0.md`
- `docs/30-architecture/vex-cpe-applicability-boundary-v0.md`
- `docs/30-architecture/vex-reference-locator-boundary-v0.md`
- `docs/30-architecture/vex-osv-range-boundary-v0.md`
- `docs/30-architecture/signing-time-evidence-boundary-v0.md`
- `docs/30-architecture/certificate-path-input-boundary-v0.md`
- `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
- `docs/30-architecture/certificate-identity-evidence-boundary-v0.md`
- `docs/30-architecture/signature-trust-root-boundary-v0.md`
- `docs/30-architecture/keyless-issuer-discovery-boundary-v0.md`
- `docs/30-architecture/verification-material-discovery-boundary-v0.md`
- `docs/30-architecture/signature-algorithm-acceptance-boundary-v0.md`
- `docs/30-architecture/proof-bundle-role-boundary-v0.md`
- `docs/30-architecture/verification-policy-selection-boundary-v0.md`
- `docs/30-architecture/reqctx-posture-v0.md`
- `docs/30-architecture/turns-posture-v0.md`
- `docs/30-architecture/caprpc-session-posture-v0.md`
- `docs/30-architecture/caprpc-promise-posture-v0.md`
- `docs/30-architecture/caprpc-oneway-posture-v0.md`
- `docs/30-architecture/bracket-posture-v0.md`
- `docs/30-architecture/ordering-token-posture-v0.md`
- `docs/30-architecture/io-lease-posture-v0.md`
- `docs/30-architecture/device-lease-ordering-boundary-v0.md`
- `docs/30-architecture/capability-lease-posture-v0.md`
- `docs/30-architecture/seal-posture-v0.md`
- `docs/30-architecture/capmode-posture-v0.md`
- `docs/30-architecture/reqctx-budget-ref-posture-v0.md`
- `docs/30-architecture/reqctx-sponsorship-evolution-boundary-v0.md`
- `docs/30-architecture/capshell-launch-boundary-index.md`
- `docs/30-architecture/capshell-output-normal-form-v0.md`
- `docs/30-architecture/capshell-result-sidecar-boundary-v0.md`
- `docs/30-architecture/capshell-pipeline-posture-v0.md`
- `docs/30-architecture/capshell-learnmode-posture-v0.md`
- `docs/30-architecture/capshell-script-entry-posture-v0.md`
- `docs/30-architecture/capshell-exec-object-posture-v0.md`
- `docs/30-architecture/quarantined-execution-boundary-v0.md`
- `docs/30-architecture/quarantined-code-input-boundary-v0.md`
- `docs/30-architecture/open-untrusted-active-content-boundary-v0.md`
- `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md`
- `docs/30-architecture/quarantined-content-index-boundary-v0.md`
- `docs/30-architecture/quarantined-derived-attribute-boundary-v0.md`
- `docs/30-architecture/quarantined-derived-match-boundary-v0.md`
- `docs/30-architecture/quarantined-result-preview-boundary-v0.md`
- `docs/30-architecture/capshell-argv0-posture-v0.md`
- `docs/30-architecture/capshell-env-startup-posture-v0.md`
- `docs/30-architecture/capshell-code-closure-posture-v0.md`
- `docs/30-architecture/capshell-env-baseline-posture-v0.md`
- `docs/30-architecture/capshell-cwd-root-posture-v0.md`
- `docs/30-architecture/capshell-handle-table-posture-v0.md`
- `docs/30-architecture/capshell-umask-posture-v0.md`
- `docs/30-architecture/capshell-rlimit-posture-v0.md`
- `docs/30-architecture/capshell-signalstate-posture-v0.md`
- `docs/30-architecture/capshell-scheduling-posture-v0.md`
- `docs/30-architecture/capshell-affinity-posture-v0.md`
- `docs/30-architecture/capshell-resource-envelope-posture-v0.md`
- `docs/30-architecture/capshell-personality-posture-v0.md`
- `docs/30-architecture/capshell-mac-profile-posture-v0.md`
- `docs/30-architecture/capshell-peer-inspection-posture-v0.md`
- `docs/30-architecture/capshell-launcher-lifetime-posture-v0.md`
- `docs/30-architecture/capshell-syscall-filter-posture-v0.md`
- `docs/30-architecture/capshell-privgain-posture-v0.md`
- `docs/30-architecture/capshell-credential-baseline-posture-v0.md`
- `docs/30-architecture/capshell-network-posture-v0.md`
- `docs/30-architecture/capshell-local-ipc-posture-v0.md`
- `docs/30-architecture/capshell-filesystem-posture-v0.md`
- `docs/30-architecture/capshell-nondet-posture-v0.md`
- `docs/30-architecture/capshell-command-string-posture-v0.md`
- `docs/30-architecture/capshell-startup-profile-posture-v0.md`
- `docs/30-architecture/capshell-word-expansion-posture-v0.md`
- `docs/30-architecture/capshell-job-control-posture-v0.md`
- `docs/30-architecture/capshell-interrupt-cancel-posture-v0.md`
- `docs/30-architecture/background-lease-posture-v0.md`
- `docs/30-architecture/inhibit-lease-posture-v0.md`
- `docs/30-architecture/notification-request-schema-v0.md`
- `docs/30-architecture/attention-lease-posture-v0.md`
- `docs/30-architecture/attention-durable-interrupt-boundary-v0.md`
- `docs/30-architecture/location-lease-posture-v0.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/namecert-posture-v0.md`
- `docs/30-architecture/namecert-projection-boundary-v0.md`
- `docs/30-architecture/namecert-time-boundary-v0.md`
- `docs/30-architecture/namecert-revocation-boundary-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/namecert-search-boundary-v0.md`
- `docs/30-architecture/namecert-redelegation-boundary-v0.md`
- `docs/30-architecture/namecert-trust-root-boundary-v0.md`
- `docs/30-architecture/namecert-string-profile-v0.md`
- `docs/30-architecture/namecert-label-atom-boundary-v0.md`
- `docs/30-architecture/namecert-principal-profile-v0.md`
- `docs/30-architecture/namecert-signature-profile-v0.md`
- `docs/30-architecture/namecert-metadata-boundary-v0.md`
- `docs/30-architecture/namecert-normal-form-boundary-v0.md`
- `docs/30-architecture/namecert-bearer-boundary-v0.md`
- `docs/30-architecture/capx-posture-v0.md`
- `docs/30-architecture/sturdyref-posture-v0.md`
- `docs/30-architecture/import-to-docref-boundary-v0.md`
- `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`
- `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`
- `docs/30-architecture/wallet-posture-v0.md`
- `docs/30-architecture/volition-posture-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`
- `docs/30-architecture/explain-posture-v0.md`
- `docs/30-architecture/ui-automation-posture-v0.md`
- `docs/30-architecture/capture-portal-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/open-untrusted-posture-v0.md`
- `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`
- `docs/30-architecture/open-untrusted-export-classification-v0.md`
- `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md`
- `docs/30-architecture/open-untrusted-export-lineage-boundary-v0.md`
- `docs/30-architecture/plumb-posture-v0.md`
- `docs/30-architecture/portal-session-posture-v0.md`
- `docs/30-architecture/print-portal-posture-v0.md`
- `docs/30-architecture/disposable-domain-posture-v0.md`
- `docs/30-architecture/quarantine-posture-v0.md`
- `docs/30-architecture/attrfs-posture-v0.md`
- `docs/30-architecture/quarantined-content-index-boundary-v0.md`
- `docs/30-architecture/quarantined-derived-match-boundary-v0.md`
- `docs/30-architecture/constructor-posture-v0.md`
- `docs/30-architecture/constructor-boundary-pattern-v0.md`
- `docs/30-architecture/worker-pool-constructor-family-v0.md`
- `docs/30-architecture/worker-pool-constructor-invocation-v0.md`
- `docs/30-architecture/worker-pool-parameter-schema-v0.md`
- `docs/30-architecture/worker-pool-sponsor-surface-v0.md`
- `docs/30-architecture/worker-pool-install-target-surface-v0.md`
- `docs/30-architecture/worker-pool-seed-surface-v0.md`
- `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- `docs/30-architecture/worker-pool-control-surface-v0.md`
- `docs/30-architecture/worker-pool-describe-summary-v0.md`
- `docs/30-architecture/worker-pool-quiesce-state-v0.md`
- `docs/30-architecture/worker-pool-restart-budget-v0.md`
- `docs/30-architecture/worker-pool-slot-state-v0.md`
- `docs/30-architecture/worker-pool-worker-surface-v0.md`
- `docs/40-verification/worker-pool-constructor-harness-v0.md`
- `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`
- `docs/40-verification/worker-pool-target-projection-v0.md`
- `docs/40-verification/worker-pool-transcript-slice-v0.md`
- `docs/40-verification/worker-pool-verdict-summary-v0.md`
- `docs/30-architecture/translator-posture-v0.md`
- `docs/30-architecture/pager-posture-v0.md`
- `docs/30-architecture/verity-posture-v0.md`
- `docs/30-architecture/provenance-posture-v0.md`
- `docs/30-architecture/attestation-endorsement-boundary-v0.md`
- `docs/30-architecture/release-identity-boundary-v0.md`
- `docs/30-architecture/verification-verdict-boundary-v0.md`
- `docs/30-architecture/certificate-path-input-boundary-v0.md`
- `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
- `docs/30-architecture/certificate-identity-evidence-boundary-v0.md`
- `docs/30-architecture/signature-trust-root-boundary-v0.md`
- `docs/30-architecture/signature-algorithm-acceptance-boundary-v0.md`
- `docs/30-architecture/keyless-issuer-discovery-boundary-v0.md`
- `docs/30-architecture/update-posture-v0.md`
- `docs/30-architecture/update-evidence-subject-boundary-v0.md`
- `docs/30-architecture/provenance-required-subject-boundary-v0.md`
- `docs/30-architecture/job-portal-posture-v0.md`
- `docs/30-architecture/transfer-portal-posture-v0.md`
- `docs/30-architecture/hot-action-surface-v0.md`
- `docs/30-architecture/quota-replication-boundary-v0.md`
- `docs/30-architecture/budget-replication-boundary-v0.md`
- `docs/30-architecture/namecert-replication-boundary-v0.md`
- `docs/30-architecture/caprpc-proxy-replication-boundary-v0.md`
- `docs/30-architecture/view-replication-boundary-v0.md`
- `docs/30-architecture/tlog-replication-boundary-v0.md`
- `docs/30-architecture/receipt-replication-boundary-v0.md`
- `docs/30-architecture/transcript-replication-boundary-v0.md`
- `docs/30-architecture/cache-topology-authority-boundary-v0.md`
- `docs/30-architecture/cpu-capacity-authority-boundary-v0.md`
- `docs/30-architecture/memory-locality-authority-boundary-v0.md`
- `docs/30-architecture/hybrid-phase1-boundary-v0.md`
- `docs/30-architecture/hot-action-boundaries-v0.md`
- `docs/30-architecture/foreign-cell-contract.md`

## When working on multicore direction (refresh before edits touching concurrency/placement)

- `docs/30-architecture/multicore-architecture-options.md`
- `docs/30-architecture/cluster-derivation.md`
- `docs/30-architecture/cluster-auto-boundary-v0.md`
- `docs/30-architecture/cluster-phase1-envelope-v0.md`
- `docs/30-architecture/cache-topology-authority-boundary-v0.md`
- `docs/30-architecture/cpu-capacity-authority-boundary-v0.md`
- `docs/30-architecture/memory-locality-authority-boundary-v0.md`
- `docs/30-architecture/hybrid-phase1-boundary-v0.md`
- `docs/30-architecture/commutativity-and-interface-scalability.md`
- `docs/30-architecture/state-projection-schema-v0.md`

## How to make changes

- Prefer **small, composable edits** (one concept per doc).
- New ideas must:
  - attach to an existing decision/schema/invariant/PO/evidence hook, **or**
  - introduce exactly one new decision surface or schema with an explicit entropy justification.
- Keep sealed-compat honest:
  - no ambient channels (implicit paths/env/implicit net);
  - foreign-cell interop must be portalized and policy-killable.
- Keep Hybrid + commutativity honest:
  - for any new/modified externally visible action, specify conflict keys and commutativity conditions;
  - if non-commutative, state the minimal required serialization boundary and where it lives.
- Keep links and registries wired:
  - update `docs/README.md` for new key docs;
  - if adding/modifying a v0 posture doc (`*-posture-v0.md`), update `docs/30-architecture/posture-index.md`;
  - if adding/modifying a microVM posture doc, keep `docs/30-architecture/microvm-profile-posture-v0.md` as the one-stop discovery surface and add/refresh the matching `check_microvm_<name>_posture.py` drift gate;
  - register new CH/IF/D/REF/EVID IDs where appropriate.

## Per-iteration requirement

Each iteration must include at least ONE of:
- an entropy-reducing refactor (dedupe/simplify/unify/wiring),
- a new guardrail/tool/check that prevents drift/amnesia,
- or a new integrated feature/idea explicitly profiled and wired into registries + discovery.

## Required outputs for each run

1) A high-level summary of what changed and why (tie back to the non-negotiables and the four product shapes).
2) A concise list of new/updated files.
3) Any new/updated open questions captured (prefer `docs/00-meta/trajectory-map.md`).
   - Use stable **OQ-####** ids so follow-ups can reference open questions without copying prose.
   - When resolving an OQ, keep the stable `OQ-####` id under **Recently resolved**, link the closing boundary/posture doc, and mention at least one attached surface or evidence hook.
   - Keep `docs/00-meta/trajectory-map.md` **OQ-only and short** (max 8 bullets); move posture-only closure notes or older overflow to `docs/00-meta/resolved-history.md`.
4) Confirm `make lint` was run and fix failures.
5) Keep `out/context_pack.md` honest: it must carry both current open questions and a compact recently-resolved OQ summary, it must point back to `docs/00-meta/resolved-history.md` so future passes retain full closure history even when the short window rotates, and its `## New in latest revision` bullets must stay a faithful mirror of the top `CHANGELOG.md` entry.
6) Provide a working link to the latest zipped archive (prefer the canonical `make handoff-release ...` one-shot path, or `make package-release ...` when debugging the split steps, rather than a manually renamed zip). `make package-release ...` must self-verify the produced bundle against its embedded `RELEASE-MANIFEST.json` before reporting success, and you should still use `make verify-release ...` when re-checking an existing artifact. Do not treat extracted residue copies in the workspace as authoritative.

## Commands

- Lint/hygiene: `make lint` (runs archive lints + discovery-surface checks)
- Generate a compact context pack for future runs: `make context-pack` (writes `out/context_pack.md`).
- Preferred one-shot handoff path: `make handoff-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>` (regenerates `out/context_pack.md`, runs `make lint`, then builds the canonical self-verifying zip via `make package-release ...`).
- Package the canonical handoff zip directly when debugging split steps: `make package-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>` (derives `rev####` from the top `CHANGELOG.md` entry, requires a fresh `out/context_pack.md` whose header revision/date and `## New in latest revision` bullets still mirror that top changelog entry, includes it in the bundle, embeds a fresh `RELEASE-MANIFEST.json`, ignores any extracted residue copy in the workspace, normalizes member metadata to `STAMP`, excludes `out/_ci_*`, and self-verifies the just-built bundle before reporting success).
- Verify the produced handoff zip: `make verify-release BUNDLE=/abs/path/to/SlopOS-rev####-YYYY.MM.DD.HH.MM-<slug>.zip` (checks the bundle filename, embedded `RELEASE-MANIFEST.json`, exact file list / size / SHA-256s, and canonical zip metadata on the artifact being handed off).
