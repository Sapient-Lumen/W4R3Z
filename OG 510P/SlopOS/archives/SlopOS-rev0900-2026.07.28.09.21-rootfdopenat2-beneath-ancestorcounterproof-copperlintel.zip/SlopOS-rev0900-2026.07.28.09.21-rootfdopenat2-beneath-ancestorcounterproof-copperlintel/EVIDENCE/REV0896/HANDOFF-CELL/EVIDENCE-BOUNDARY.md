# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently build the rev0896 hosted
handoff vertical and produce byte-identical canonical products. The inherited
no-replace burn, principal custody, immutable publication, exact launch,
fixed query, endpoint publication, process-instance identity, message identity,
and claim-before-parse campaigns remain intact. Three independent Python
oracles check the inherited campaign, the endpoint claim cut, and the new
hosted settlement seam.

V8 adds one bounded client-side construction inside the existing handoff-cell
island. The sole settlement entry consumes the existing move-only
`ClaimedPending` before examining request meaning. An exact request reaches one
and only one `submit_exact` callsite. No-return, unavailable, malformed, and
foreign observations preserve uncertainty. The separate reopen path contains
one exact query callsite and no submission path; exact terminal records refine
the result, and an exact linearized unused observation refines to no-effect
without authorizing a late first dispatch. Every returned or copied observation
is query-only and carries neither response nor retry authority.

Four scheduled process-death cuts retain the crucial distinction between
submission and knowledge of submission: death after the claim but before submit
reopens as exact-unused/no-effect under the hosted provider contract; death
after effect, no-effect, or uncertain commit reopens by exact query to the
corresponding result. Sixteen coherent local claim histories against one shared
scripted provider cause sixteen submissions but one fresh provider commit, one
effect, and fifteen duplicate observations. That is evidence for adapter
ordering under the fake provider contract, not proof of a protected provider.

The retained countermodels prevent promotion. A malformed response may follow a
committed effect; coherent provider clones each commit an effect; finite
idempotency retention permits the same identity to effect again; and distinct
providers can return byte-identical result records after two effects. Provider
identity, writer custody, deduplication lifetime, restore/failover lineage,
newestness, and independently appraised owner admission therefore remain open.
The named host interface is a premise, not authority, and no cloud provider is
admitted by this evidence.

All earlier limits remain: administration-plane closure, executable and
dependency identity, signal/ptrace and cgroup lifecycle, machine/service
incarnation, endpoint retirement and successor selection, protected storage,
external monotonic rollback floor, stable media, source-to-binary proof, and
independent owner ratification. Epoch Zero remains the truthful state.
