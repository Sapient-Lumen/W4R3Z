# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently built the rev0890 hosted
handoff vertical and produced byte-identical canonical products. The original
no-replace handoff, principal-custody, immutable publication, and inherited
launch/query campaigns remain intact. A separate Python oracle checks all
cases and retained countermodels without trusting the C++ judgments.

The new construction separates three events which rev0889 had collapsed:
provider listener creation, public-name publication, and query connection. A
provider worker first entered final numeric UID/GID 21001, empty supplementary
and capability sets, and `no_new_privs`; its exact post-exec descriptor table
contained a provider root, a private staging directory, and a report channel,
but no query data socket. It then bound fixed `bound.sock`. A distinct root
publisher moved that already-bound socket inode into fixed `query.sock` in a
root-owned mode-0711 public directory using `renameat2(RENAME_NOREPLACE)`. Only
after that publication did UID 21003 exec with a public-directory descriptor
and create its own connection. On this recorded Linux host, the renamed
listener accepted the connection, and `SO_PEERCRED` on both connected sides
reported the final provider and query principals. Per-message credentials,
fixed result query, ancillary-rights rejection, and malformed-byte rejection
remained in force.

The campaign retains the restart obstruction rather than erasing it. When the
provider died, the pathname socket remained but connection failed with
`ECONNREFUSED`. A fresh provider could bind a private staged listener, yet
no-replace publication returned `EEXIST` and preserved both the stale public
inode and the fresh staged inode. The candidate contains no automatic unlink,
cleanup, retry, or repair entrypoint. Cleanup is a separately visible
administrative act.

Three counterexamples define the cut. First, when the provider itself owns a
writable public directory, a same-UID process can unlink a still-live pathname
socket and bind a distinct listener at the same leaf; bind-after-drop alone is
not endpoint freshness. Second, stale endpoint cleanup cannot be treated as
harmless restart hygiene because it chooses which endpoint epoch becomes
public. Third, the root publisher in this hosted campaign can explicitly unlink
the stale leaf and publish the fresh listener. The public-name custodian,
launcher, executable, mount/namespace administration, signal/ptrace/cgroup
lifecycle, privileged credential forgery, and provider-root selection remain
open premises.

This is Linux-hosted shape evidence. The inode-preserving rename and pathname
socket behavior are observed here and depend on Linux/VFS contracts; they are
not a portable endpoint protocol, stable-media theorem, authenticated provider,
independent actor, protected epoch token, source-to-binary admission proof, or
release authority. No seal or epoch advance is established.
