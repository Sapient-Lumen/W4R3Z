# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently build the rev0892 hosted handoff
vertical and produce byte-identical canonical products. The original no-replace
handoff, principal-custody, immutable publication, exact-launch, fixed-query,
staged endpoint-publication, process-instance, and message-identity campaigns
remain intact. A separate Python oracle checks every case and retained
countermodel without trusting the C++ judgments.

The V6 construction adds one externally supplied expected-provider capsule to
the valid query actor. The capsule consists of a fixed 96-byte memfd record and
a pidfd. After exec, the actor requires exact principals, canonical reserved
bytes, nonzero serial and opaque owner-binding bytes, exact write/grow/shrink
and seal seals, close-on-exec descriptors, a live pidfd-shaped object, and
record/pidfd pidfs identity agreement. It then closes both expectation
descriptors before creating the AF_UNIX data socket. The connected
`SO_PEERPIDFD` identity must equal the consumed expected process before any
request byte is sent. A mismatch closes the connection.

This is a real narrowing of the effect path: the fixed result rendezvous now
depends on an external process expectation rather than merely observing a peer
after connection. It is not owner admission. The root harness observes the
provider pidfd, writes the opaque binding, seals the record, and supplies it.
The same sealed record and pidfd can be duplicated before the actor-local burn.
Therefore immutability is not provenance, process equality is not policy, and a
move-only C++ object is not a globally unique spend. Two new counterexamples
retain those defeats instead of allowing the hosted constructor to impersonate
an owner root.

`SO_PEERPIDFD` still identifies the exact peer process reached by the fresh
post-entry connection. `SO_PASSPIDFD` still causes each message to carry one
automatic `SCM_PIDFD`; the receive path requires that identity to equal the
retained peer pidfd before interpreting request or response bytes. Received
process references and all `SCM_RIGHTS` descriptors are close-on-exec, rejected
or consumed as evidence, and closed before payload semantics. The valid query
retains only the connection's hidden peer pidfd and observes it become pollable
after provider exit. No native process descriptor is exported as generic
process-control authority.

All earlier namespace and administration defeats remain. A provider-writable
public parent permits same-UID live replacement, a stale public leaf blocks
no-replace restart, and the privileged publisher can unlink and republish.
Ordinary workers enter fixed nonroot principals with empty capability sets, but
root, expectation-constructor custody, executable/dependency identity, mount
and namespace administration, signal/ptrace/cgroup lifecycle, machine/service
incarnation, endpoint retirement, successor selection, stable media, and owner
ratification remain premises.

This is Linux 6.12 hosted shape evidence. Memfd seals, pidfd object checks,
pidfs device/inode equality, automatic process ancillary data, poll behavior,
and AF_UNIX option composition are scoped to the recorded host and pinned
source profile. They are not a portable process identity, protected admission
constructor, authenticated provider, globally one-use expectation, durable
spend receipt, independently admitted endpoint epoch, stable-media theorem,
source-to-binary proof, release authority, or epoch advance.
