# Exact etcd release acquisition boundary

## Retained positive evidence

The official `SHA256SUMS` product for etcd `v3.6.14` was retrieved from the
upstream GitHub release and retained byte-for-byte. Its own SHA-256 is
`9348ebc1c9c0afaf29a55cedd8e788fe5ac9f425812ca0f6b4eab3268b6f409b`.
The upstream line for `etcd-v3.6.14-linux-amd64.tar.gz` names
`ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5`.
The release page reports `v3.6.14`, dated 2026-07-23, as the current v3.6
maintenance release and marks `v3.7.1` as latest overall. The upstream patch
notice says v3.6.14 fixes security and reliability defects. The exact patch is
therefore the only admitted V10 v3.6 release hypothesis, rather than the older
`v3.6.13` surveyed in rev0897. It is not represented as latest overall, and
v3.7.1 cannot be silently substituted without a new contract review.

Official sources:

- https://github.com/etcd-io/etcd/releases/tag/v3.6.14
- https://github.com/etcd-io/etcd/releases/download/v3.6.14/SHA256SUMS
- https://etcd.io/blog/2026/07/23/etcd-v3.5.26-v3.6.14-and-v3.7.1-are-now-available/

## Retained negative evidence

The exact Linux amd64 archive was not available inside this cloudtainer. No
`etcd`, `etcdctl`, or `etcdutl` executable and no Docker-compatible runtime was
present. Go was present, but direct module acquisition was not available. A
content-fetch route exposed the release response metadata but would not retain
the gzip artifact, while shell-side network acquisition was unavailable.
Consequently no etcd process was launched, no cluster/data directory or roots
were provisioned, and no provider transaction was attempted.

`RELEASE-ADMISSION-NEGATIVE.json` is the output of the same fail-closed release
gate that a later operator can run against supplied bytes. It stops at
`RELEASE_ARCHIVE_MISSING`. `SELF-TEST.json` proves only that missing, mismatched,
path-traversing, and symlink-bearing inputs stop; it does not admit the absent
upstream archive.

## What this evidence does not promote

The checksum file and release pin do not constitute an owner, authenticate a
cluster, protect administrative roots, establish newest history, prove restore
continuity, submit the rendered transaction, prove provider commit, or authorize
response/retry. The C++ V10 campaign's eighteen positive dossiers are synthetic
logic fixtures. Its one actual host row is `RUNTIME_UNAVAILABLE`.
