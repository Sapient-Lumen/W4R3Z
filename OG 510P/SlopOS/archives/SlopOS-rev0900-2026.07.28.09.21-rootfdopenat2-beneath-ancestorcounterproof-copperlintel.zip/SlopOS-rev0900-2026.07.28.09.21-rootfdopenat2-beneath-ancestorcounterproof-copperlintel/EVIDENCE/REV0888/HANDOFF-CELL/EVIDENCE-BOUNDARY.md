# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently built the rev0888 hosted
handoff vertical and produced byte-identical canonical products. The original
twelve cases in the no-replace handoff campaign remain intact, including the malformed FIFO rejection. Seven principal cases, ten
fixed no-replace result/publication cases, and three additional counterexamples are
now replayed by a separate Python oracle.

The scoped positive observation is this: on the recorded cloudtainer host, a
process running as numeric provider UID 21001 created fixed owner-only child
`cell`, staged and burned exact pending identity, retained immutable
`UNCERTAIN` result/publication version 1, then appended exact result/publication
version 2. A distinct workload UID 21002 could not traverse the provider root,
open `pending`, or link, rename, or unlink inside the cell. Under the candidate
API, fixed final keys failed without replacement; version 2 required uncertain version 1; and a
publication required its exact result. Staging residue failed stop and exposed
no mutating protocol-recovery operation.

The hosted adapter still selects and provisions the provider root; that premise is not authenticated. This is not provider authentication or complete custody. Three negative controls
are decisive: a same-UID peer can chmod and mutate an owner file; a writable
descriptor opened before `setresuid` remains writable afterward; and a
root-equivalent actor bypasses discretionary owner-only mode. The earlier hard link, already-open writable descriptor, and coherent local rollback counterexamples also remain. Exact
descriptor construction, administration-plane closure, mount/snapshot writers,
stable media, destructive power loss, external rollback floor, independently
provisioned reopen, and admitted source-to-binary identity are all unproved.

The process campaign relies on documented Linux rename and credential
semantics; it does **not** independently prove Linux rename atomicity, the kernel, or the filesystem. `HOST-PROFILE.json`
records the construction host only. No protected spent identity, authenticated
provider, stable-media result service, authority, seal, or epoch advance is
established.
