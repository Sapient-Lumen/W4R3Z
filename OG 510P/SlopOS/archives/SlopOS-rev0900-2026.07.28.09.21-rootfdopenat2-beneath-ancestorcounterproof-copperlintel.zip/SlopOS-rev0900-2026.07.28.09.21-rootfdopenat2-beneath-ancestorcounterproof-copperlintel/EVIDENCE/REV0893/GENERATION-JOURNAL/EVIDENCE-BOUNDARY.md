# Generation-journal evidence boundary

The retained Clang, GCC, sanitizer, and independently reconstructed Python
products establish byte-identical agreement for the unchanged finite hosted
generation-journal/recovery algebra and for a new content-bound
compare-and-append spend relation. The latter includes a canonical 352-byte
SHA-256-bound spend record, 20 relation cases, 5,632 rejected one-bit record
mutations, a sixteen-contender same-spend race with one `advanced` outcome and
fifteen `already_current` outcomes, and two foreign-spend races that each stop
the stale loser.

The campaign also retains the decisive counterexamples. A scalar monotonic
floor identifies order but not the winning spend. Blind increment and blind
extend are not expected-head compare-and-append. Replaying the bytes of an
`advanced` response creates two hosted invoke decisions, so response bytes are
not a nonduplicable capability.

The evidence does **not** establish an authenticated provider, exclusive writer
custody, stable-media ordering, physical rollback resistance, a durable global
spend, source-to-binary identity, a protected effect, or an independent actor.
The compare-and-append service is still a hosted relation. No authority is
granted.
