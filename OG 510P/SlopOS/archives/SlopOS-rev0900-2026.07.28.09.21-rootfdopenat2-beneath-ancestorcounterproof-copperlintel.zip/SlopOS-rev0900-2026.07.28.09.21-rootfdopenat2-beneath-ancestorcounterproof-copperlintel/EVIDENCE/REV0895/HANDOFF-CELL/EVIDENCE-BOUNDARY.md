# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently build the rev0895 hosted
handoff vertical and produce byte-identical canonical products. The inherited
no-replace burn, principal-custody, immutable publication, exact-launch,
fixed-query, endpoint-publication, process-instance, and message-identity
campaigns remain intact. Independent Python oracles check both the inherited
campaign and the endpoint claim-before-parse construction.

V7 adds one fixed hosted cut: `pending` is renamed to `claimed` with
`RENAME_NOREPLACE` before the leaf is opened, read, compared, or decoded and
before semantic request bytes are inspected. Only a directory-synchronized
fresh exact post-rename observation yields an internal move-only
`ClaimedPending`; the only parser accepts that object as an rvalue and consumes
it before reading request length, magic, generations, or bindings. A completed
rename followed by failed directory synchronization remains claimed but mints
no token, enters no parser, and reopens query-only. Copyable outcomes, duplicate
calls, and reopen/recovery observations are query-only and carry no response
authority.
Malformed content or payload remains claimed and fail-stops; there is no
reverse rename, repair, retry, settlement, or recovery-apply surface.

The campaign retains the boundary rather than exaggerating it. Sixteen
processes sharing one hosted directory produce one fresh claim and one parser
entry. Four process-death cuts show that reopen cannot reenter payload meaning
after the namespace cut. A hard-link alias, an inherited writable descriptor,
a coherent directory clone, and a local snapshot rollback each defeat stronger
claims about singular object custody, immutable content, globally unique spend,
and newest history. Two coherent histories can each claim and parse once.
Thus the move-only token is a local control-flow device, not external authority.

All earlier limits remain: root and administration custody, provider
provenance, owner admission, executable/dependency identity, signal/ptrace and
cgroup lifecycle, machine/service incarnation, endpoint retirement and
successor selection, protected storage, external monotonic rollback floor,
exact effect/no-effect/uncertain settlement, stable media, source-to-binary
proof, and independent owner ratification. This evidence advances Epoch Zero
construction but does not authorize an epoch transition.
