# C++20 evidence boundary

Clang and GCC compiled the same C++20 source with warnings as errors. CTest was used only to inventory eight registered tests. Each governed campaign and each of eight source-separated audits executed exactly once per retained compiler lane. Canonical outputs are byte-identical; compiler-produced executable files are neither retained as release products nor byte-compared.

The process lane binds a process lifetime, descriptor-selected initial executable, normalized descriptor topology, credential/capability observations, and terminal pidfd result inside a hosted profile. It deliberately retains counterexamples showing that pidfd lifetime is not an executable epoch, no_new_privs is not exec closure, and a coherent transcript is not provider authentication. It yields no process-custody, provider-authentication, or authority result.

The trace and crash lanes remain synthetic/logical. Source-separated checkers remain same-actor, shared-protocol evidence. Isabelle sources remain `UNREPLAYED_ENVIRONMENT_UNAVAILABLE`.
The legacy broad-candidate source manifest also binds the current
`CANDIDATE/README.md` source map as non-build metadata. A README-only evolution
does not retroactively reconstruct compiler products; its row is refreshed to
prevent stale checkpoint identity while all executable and audited source bytes
remain independently bound by the same manifest and package-local manifests.
