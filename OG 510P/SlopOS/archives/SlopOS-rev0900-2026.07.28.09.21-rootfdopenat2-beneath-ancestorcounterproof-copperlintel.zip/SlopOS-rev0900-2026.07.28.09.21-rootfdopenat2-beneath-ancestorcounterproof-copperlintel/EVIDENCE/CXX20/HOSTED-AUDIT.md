# Hosted evidence audit

The retained compiler lanes compare 472 canonical files totaling 3397600 bytes. They include the inherited authority, uncertainty, path, crash, trace-intake, and trace-subject campaigns plus the rev0883 process-lifetime/initial-exec wedge.

The process campaign contains 14 live cases, 9 launch-closed candidates, 2 fail-closed cases, 9 model states, 72 saturated transitions, and 5 retained counterexamples. Process-custody, provider-authenticated, and authority-bearing results are all zero.
