# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently build the rev0897 hosted
handoff vertical and produce byte-identical canonical products. The inherited
no-replace burn, principal custody, immutable publication, exact launch, fixed
query, endpoint publication, process identity, message identity, local
claim-before-parse, and hosted one-attempt settlement campaigns remain intact.
Four independent Python oracles check the inherited campaign, endpoint claim,
settlement, and owner-pinned provider-history observation.

V8 remains a bounded client-side settlement theorem. A fresh local claim is
consumed before request meaning, an exact request reaches one submit callsite,
and reopen contains only exact query. Lost, unavailable, malformed, and foreign
observations remain uncertain. The fake provider is a premise: coherent clones,
finite retention, and byte-identical cross-provider results defeat global spend,
provider identity, rollback closure, protected effect, and protected settlement.

V9 adds a separate query-only cryptographic appraisal seam. An exact SHA-256
pin selects one 320-byte owner-signed provider genesis. The provider key named
there verifies one 320-byte append observation, after which every expected
history-edge field is compared. Candidate code contains public verification
only; deterministic private seeds and signing remain harness-only. No pin,
envelope, or `ProviderGenesisObservation` can enter settlement, endpoint claim,
or payload parsing.

The V9 counterproofs are theorem boundaries. Exact bytes replay. Coherent copies
verify independently. One provider key signs conflicting successors, and one
owner key signs alternate geneses; explicit repinning selects either. Every
one-bit mutation is rejected, but signatures do not constitute an owner, prove
provider execution or compare-and-commit, select newest history, prevent restore
rollback, make a spend singular, or authorize response or retry.

Official etcd contracts make the missing operated profile concrete: completed KV
operations are durable and strictly serializable, while timeout or network loss
leaves the client uncertain. Snapshot restore overwrites member and cluster IDs
and starts a new logical cluster; revision bumping addresses revision regression
but is not an owner-governed continuity proof. A future provider profile must
therefore bind admitted resource/incarnation, administrative roots, restore and
migration lineage, exact transaction/query modes, lifetime duplicate semantics,
and independent appraisal.

All earlier limits remain: constituted owner authority, independent root
provisioning and rotation, protected keys and provider state, writer/admin/backup
custody, executable/dependency identity, external monotonic rollback floor,
stable media, physical destructive cuts, source-to-binary proof, protected
effect/settlement, and independent reopen. Epoch Zero remains truthful.
