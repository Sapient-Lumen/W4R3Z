# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently built the hosted Linux handoff
cell and produced byte-identical canonical campaign products. The independent
Python audit agrees on twelve cases, three actual scheduled process-death cuts,
one winner among sixteen process contenders, and three retained
counterexamples. It also exhausts two small abstract relations: the rev0886
split handoff has one locally ambiguous empty observation class, while the
no-replace name relation has no empty live/pending namespace state.

The positive result is narrow. On this host, one fixed
`renameat2(..., RENAME_NOREPLACE)` call produced a process-visible transition
from fixed leaf `live` to fixed leaf `pending`; query follows the admission
call and never restores `live`. A malformed FIFO is burned and then rejected as
nonregular without blocking the query-only reader. The three SIGKILL cuts are
before the admission call, after `burn_before_decode()` returns (therefore
after its directory-sync attempt), and after exact readback. There is no tested
cut inside the rename-to-directory-fsync interval.

The campaign does **not** independently prove Linux rename atomicity. The
abstract no-empty-state conclusion relies on the documented kernel rename
contract and is checked separately from the process observations. The caller
selects and provisions the retained directory descriptor, so route and cell
custody also remain external premises.

The evidence defeats stronger identity claims. A hard link and an already-open
writable descriptor survive rename; a coherent local rollback reproduces the
pre-burn observation. Directory fsync was called, but no physical-power-loss,
device-cache, filesystem-recovery, protected-provider, authenticated-query,
external-floor, independent-actor, or source-to-binary experiment occurred.
`HOST-PROFILE.json` records the construction host only. No protected spent
identity, stable-media result, or authority is established.
