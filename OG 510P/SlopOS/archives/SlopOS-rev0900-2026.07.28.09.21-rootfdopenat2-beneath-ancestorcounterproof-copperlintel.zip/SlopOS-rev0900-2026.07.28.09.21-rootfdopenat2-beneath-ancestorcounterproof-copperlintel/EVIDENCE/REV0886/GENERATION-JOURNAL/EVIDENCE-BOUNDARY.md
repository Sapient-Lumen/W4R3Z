# Generation-journal evidence boundary

The retained Clang, GCC, sanitizer, and independently reconstructed Python
products establish byte-identical agreement for one finite hosted
generation-journal/recovery algebra, one canonical 128-byte record grammar,
and one move-only C++ proof-shape boundary. The finite saturation contains 69
reachable states, 25 events per state, and 1,725 transitions. The boundary
campaign also rejects generation wrap and retains a deliberate alternate valid
record with recomputed CRC to demonstrate that codec checks are not writer
authentication.

The evidence does **not** establish stable-media ordering, physical-power-loss
survival, protected spent-receipt identity, endpoint authenticity, writer
exclusivity, rollback resistance, source-to-binary identity, a nonforgeable
capability, a protected effect, or an independent actor. Abstract persistence
and query events are model labels. No authority is granted.
