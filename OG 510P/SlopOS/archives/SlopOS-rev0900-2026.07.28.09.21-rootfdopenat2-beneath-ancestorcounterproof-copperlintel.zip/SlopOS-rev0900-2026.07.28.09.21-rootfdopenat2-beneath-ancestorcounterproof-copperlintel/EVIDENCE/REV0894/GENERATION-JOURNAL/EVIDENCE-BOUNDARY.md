# Generation-journal evidence boundary

The retained Clang, GCC, sanitizer, and independently reconstructed Python
products establish byte-identical agreement for the finite hosted
generation-journal, the content-bound compare-and-append relation, and the
rev0894 local joined-admission fault adapter.

The spend relation retains a canonical 352-byte SHA-256-bound record, 20
relation cases, 5,632 rejected one-bit mutations, a sixteen-contender race with
one `advanced` observation and fifteen `already_current` observations, and two
foreign-successor races. Every detached append response is query-only; replaying
the accepted response creates zero invoke decisions.

The joined adapter co-commits one exact floor successor and one fixed endpoint
admission row in one local SQLite transaction. Sixteen exact contenders converge
to one row. Three precommit process-crash cuts recover predecessor/zero-entry;
one postcommit-before-reply cut recovers target/one-entry. Copying the returned
result creates zero new rows and zero authorities.

The retained negative controls are equally governing. A deliberately split
floor-only commit reaches target-without-entry and fails closed. A coherent
pre-spend database clone admits independently in two histories. One SCM_RIGHTS
message observed twice with MSG_PEEK and once normally installs three descriptor
references. Therefore local transaction atomicity and descriptor delivery are
not global one-use spend authority.

The evidence does **not** establish an authenticated provider, owner-admitted
genesis, exclusive writer custody outside the cloudtainer, physical power-loss
behavior, rollback resistance, protected endpoint claim, protected effect, exact
result settlement, or an independent actor. No authority is granted.
