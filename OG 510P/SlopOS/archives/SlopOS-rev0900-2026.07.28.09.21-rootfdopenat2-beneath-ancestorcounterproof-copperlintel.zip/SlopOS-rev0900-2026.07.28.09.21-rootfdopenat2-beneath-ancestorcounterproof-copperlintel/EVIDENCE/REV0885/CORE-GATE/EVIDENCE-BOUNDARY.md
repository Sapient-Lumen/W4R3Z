# Core-gate evidence boundary

The retained Clang, GCC, and sanitizer products establish deterministic
agreement for one finite hosted relation. They do not authenticate input,
constitute an owner, make the permit nonforgeable, isolate the endpoint,
prove stable storage or power-loss behavior, authenticate reconciliation,
bind a machine, or supply an independent actor. Compiler agreement is an
observation about these products, not a proof of C++20 semantics or release
custody.
