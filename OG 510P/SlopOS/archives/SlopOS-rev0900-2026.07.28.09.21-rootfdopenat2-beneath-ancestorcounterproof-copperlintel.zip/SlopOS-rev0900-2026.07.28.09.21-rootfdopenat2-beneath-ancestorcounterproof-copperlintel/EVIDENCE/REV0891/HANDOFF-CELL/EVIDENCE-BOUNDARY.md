# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently built the rev0891 hosted handoff
vertical and produced byte-identical canonical products. The original no-replace
handoff, principal-custody, immutable publication, exact-launch, fixed-query,
and staged endpoint-publication campaigns remain intact. A separate Python
oracle checks every case and retained countermodel without trusting the C++
judgments.

The V5 construction adds one hidden process reference to each connected
endpoint. `SO_PEERPIDFD` identifies the exact peer process reached by the fresh
post-entry connection. `SO_PASSPIDFD` causes each message to carry one automatic
`SCM_PIDFD`; the receive path requires that identity to equal the retained peer
pidfd before interpreting request or response bytes. Received process
references and all `SCM_RIGHTS` descriptors are close-on-exec, rejected or
consumed as evidence, and closed before payload semantics. The connected
provider and query descriptor inventories expand to nine and seven respectively,
while the prebind and preconnect inventories remain exact.

The valid query stays alive after the fixed response and observes the provider
pidfd become pollable after provider exit. This is a bounded process-lifetime
observation. It does not classify the endpoint effect, retire the stale public
leaf, authorize cleanup, or prove stable media.

Two new counterexamples define the process boundary. On a socketpair created
before `fork`, `SO_PEERPIDFD` identifies the creator while message-time
`SCM_PIDFD` identifies the forked sender. After provider P1 exits, the root
publisher explicitly removes the stale leaf and publishes a same-UID provider
P2. A fresh query observes a distinct process identity at the same fixed public
path, but no owner-admitted expected provider token exists. Replacement is
visible; successor authorization remains absent.

All rev0890 namespace defeats remain: a provider-writable public parent permits
same-UID live replacement, a stale public leaf blocks no-replace restart, and
the privileged publisher can unlink and republish. Ordinary workers enter fixed
nonroot principals with empty capability sets, but root, privileged credential
selection, executable/dependency identity, mount and namespace administration,
signal/ptrace/cgroup lifecycle, machine/service incarnation, and publisher
constitution remain premises.

This is Linux 6.12 hosted shape evidence. Pidfd equality through pidfs
device/inode, automatic process ancillary data, poll behavior, and AF_UNIX
option composition are scoped to the recorded host and pinned source profile.
They are not a portable process identity, process registry, authenticated
provider, independently admitted endpoint epoch, stable-media theorem,
source-to-binary proof, release authority, or epoch advance. The native pidfd is
not exported as generic process-control authority.
