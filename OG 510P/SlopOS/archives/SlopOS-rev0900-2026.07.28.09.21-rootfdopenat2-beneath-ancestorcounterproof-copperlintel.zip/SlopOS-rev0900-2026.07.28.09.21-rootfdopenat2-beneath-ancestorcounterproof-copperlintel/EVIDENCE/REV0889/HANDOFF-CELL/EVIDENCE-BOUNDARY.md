# Handoff-cell evidence boundary

Clang, GCC, and Clang ASan/UBSan independently built the rev0889 hosted
handoff vertical and produced byte-identical canonical products. The original
no-replace handoff, principal-custody, and immutable publication campaigns
remain intact. A separate Python oracle also checks fifteen launch/query cases
and three launch/query counterexamples.

The new scoped positive observation is narrow. On the recorded Linux
cloudtainer, a root-owned test launcher constructed two post-`execveat`
descriptor tables, closed the ambient suffix with `close_range(...,
CLOSE_RANGE_UNSHARE)`, dropped both workers to fixed numeric UIDs with empty
supplementary and capability sets plus `no_new_privs`, and observed the exact
open descriptors from `/proc/self/fd`. The provider accepted only one fixed
query message from current UID 21003, opened no caller-selected path or
version, joined fixed `cell/pending` to fixed `cell/result.2`, and returned the
exact immutable result. The query object has no apply, repair, cleanup, retry,
publication, or mutation operation. A silent query timed out without mutation.

Three counterexamples define the cut. `SO_PEERCRED` on a socketpair created by
the root launcher continued to report the credentials in effect at
`socketpair(2)`, not the post-drop sender. Per-message `SCM_CREDENTIALS` under
`SO_PASSCRED` identified the current unprivileged senders in this scoped run,
but privileged credential forgery and the administration plane remain open.
`SCM_RIGHTS` installed a descriptor in the provider before payload validation;
the provider rejected and closed it, and the evidence retains the injection as
authority rather than inert metadata. Finally, an off-by-one `close_range`
start preserved undeclared descriptor 7 after exec.

This does not authenticate the provider, exclude a root-equivalent supervisor,
prove an independent actor, prove source-to-binary admission, close namespace,
mount, snapshot, cgroup, signal, ptrace, or lifecycle administration, establish
stable media or destructive power-loss survival, or provide an external
rollback floor. The provider root and executable descriptor are still selected
by the hosted adapter. Linux manual contracts are premises, not properties
proved by this campaign. No authority, seal, or epoch advance is established.
