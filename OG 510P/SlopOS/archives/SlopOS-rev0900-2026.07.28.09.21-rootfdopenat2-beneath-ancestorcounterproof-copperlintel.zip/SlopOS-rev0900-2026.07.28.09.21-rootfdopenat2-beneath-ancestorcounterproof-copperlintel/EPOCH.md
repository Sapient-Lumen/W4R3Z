# Epoch state

```text
EPOCH_ZERO / E0-A.AUTHENTIC-SPINE / HOSTED-CANDIDATE / OPEN
```

## Judgment

Epoch Zero remains the only truthful state. Rev0900 closes one ancestor-lookup
ambiguity and then discovers an earlier type-safety cut: opening first and
checking `fstat` afterward can already cross FIFO or device semantics. The
production locator now requires the atomic Linux `OPENAT2_REGULAR` premise in the same bounded open. The
retained Linux 6.12.13 host lacks that premise and therefore stops before a
candidate descriptor exists.

Rev0900 does not acquire or admit the exact archive, activate a binary, operate
a cluster, attempt a provider transaction, constitute an owner, protect state,
establish external currentness, prove settlement, or support an independently
provisioned reopen. Exact rev0874 remains the last sealed living lineage.

## Linked construction sequence

```text
rev0885  burn-before-validation core gate
rev0886  exact journal and query-only recovery
rev0887  no-replace handoff and rollback counterproof
rev0888  scoped principal and immutable publication versions
rev0889  launch/message descriptor and process checks
rev0890  bind/publication split and stale endpoint stop
rev0891  process-instance observation and retirement stop
rev0892  sealed expected-process burn before connection, actor-local only
rev0893  content-bound compare-and-append; scalar order rejected
rev0894  local floor/entry transaction; detached responses inert
rev0895  local endpoint claim before record and payload meaning
rev0896  one-attempt hosted settlement; recovery exact-query-only
rev0897  owner-pinned signed history observation; restore/donor counterproof
rev0898  exact etcd profile gate; runtime absence retained
rev0899  one-open write-sealed passive ingress; pathname substitution rejected
rev0900  root-FD fixed-leaf locator; atomic type gate and FIFO counterproof
```

This is cumulative hosted proofwork, not cumulative authority.

## What rev0900 proves

```text
root pathname != already-open root descriptor
successful descriptor duplication != retained identity theorem
O_PATH != directory shape != effective-UID ownership != mode 0700
final-component O_NOFOLLOW != all-component lookup confinement
open then fstat != atomic regular-file-only acquisition
unsupported regular-only contract -> stop before candidate acquisition
synthetic descriptor-ready relation row != retained host readiness
root endpoint equality != uninterrupted profile custody
raw descriptor number != persistent receipt identity
rooted regular same-device leaf != immutable or provenance-authenticated bytes
V11 sealed exact bytes remain mandatory before passive archive semantics
```

The retained pure relation has 24 cases and 11 countermodels, including two
synthetic descriptor-ready rows for a supporting kernel. The Linux probe has 21
cases and 11 counterexamples and retains zero production-ready descriptors on
this host. It reproduces the legacy FIFO open-before-shape-check defect,
ancestor-symlink widening, visible-root replacement, profile drift, profile ABA,
and pre-snapshot leaf mutation.

## What remains false

```text
production_candidate_descriptor_ready = false
release_archive_admitted = false
release_activation_performed = false
operated_etcd_profile = false
provider_transaction_attempted = false
provider_commit_proved = false
administration_plane_closed = false
external_currentness_proved = false
root_profile_continuity_proved = false
owner_constitution_proved = false
protected_settlement = false
living_law = false
```

## Promotion rule

Do not advance the epoch because a future-kernel relation admits, a descriptor
is stable across rename, endpoint metadata agrees twice, a digest matches, or a
verifier passes. Promotion still requires constituted owners, protected one-use
admission, one bounded effect, honest settlement, external anti-rollback
currentness, and independent reopen. Remain in Epoch Zero.
