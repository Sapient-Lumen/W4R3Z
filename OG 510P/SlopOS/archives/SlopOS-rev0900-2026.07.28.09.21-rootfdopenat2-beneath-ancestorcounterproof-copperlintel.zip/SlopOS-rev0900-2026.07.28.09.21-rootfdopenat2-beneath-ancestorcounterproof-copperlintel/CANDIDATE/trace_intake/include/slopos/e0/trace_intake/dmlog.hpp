#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <vector>

namespace slopos::e0::trace_intake {

inline constexpr std::uint64_t kWriteLogMagic = 0x6a736677736872ULL;
inline constexpr std::uint64_t kWriteLogVersion = 1ULL;
inline constexpr std::uint64_t kLogFlushFlag = 1ULL << 0U;
inline constexpr std::uint64_t kLogFuaFlag = 1ULL << 1U;
inline constexpr std::uint64_t kLogDiscardFlag = 1ULL << 2U;
inline constexpr std::uint64_t kLogMarkFlag = 1ULL << 3U;
inline constexpr std::uint64_t kLogMetadataFlag = 1ULL << 4U;
inline constexpr std::size_t kSuperBytes = 28U;
inline constexpr std::size_t kEntryBytes = 32U;

using Bytes = std::vector<std::uint8_t>;

enum class ParseCode {
    ok,
    truncated_super,
    bad_magic,
    bad_version,
    bad_sector_size,
    misaligned_length,
    truncated_entry,
    unknown_flags,
    invalid_combination,
    invalid_mark,
    unsupported_discard,
    out_of_range,
    truncated_payload,
    trailing_bytes,
};

enum class EventKind { write, fua_write, flush, mark };

struct Event {
    std::size_t index{};
    EventKind kind{EventKind::write};
    std::uint64_t sector{};
    std::uint64_t nr_sectors{};
    bool metadata{};
    std::string mark{};
    Bytes data{};
};

struct ParsedLog {
    std::uint32_t sector_size{};
    std::uint64_t advertised_entries{};
    std::size_t used_bytes{};
    bool end_mark_present{};
    std::vector<Event> events{};
};

struct ParseResult {
    bool ok{};
    ParseCode code{ParseCode::truncated_super};
    std::string detail{};
    ParsedLog log{};
};

struct CampaignReport {
    bool ok{};
    std::size_t cases{};
    std::size_t accepted{};
    std::size_t rejected{};
    std::size_t accepted_entries{};
    std::size_t replay_prefixes{};
    std::size_t unique_images{};
    std::size_t parser_disagreements{};
    std::size_t marks{};
    std::size_t flushes{};
    std::size_t fua_writes{};
    std::size_t end_marks{};
    bool mark_replay_stutter{};
    bool final_image_not_unique_trace{};
    bool advertised_prefix_not_target_absence{};
    bool end_mark_without_target_flush{};
    bool structural_acceptance_not_authenticity{};
    std::string detail{};
};

[[nodiscard]] ParseResult parse_strict(
    std::span<const std::uint8_t> raw,
    std::uint64_t baseline_sectors);

[[nodiscard]] ParseResult parse_reference(
    std::span<const std::uint8_t> raw,
    std::uint64_t baseline_sectors);

[[nodiscard]] Bytes replay_prefix(
    std::span<const std::uint8_t> baseline,
    const ParsedLog& log,
    std::size_t event_count);

[[nodiscard]] bool equivalent(
    const ParseResult& lhs,
    const ParseResult& rhs) noexcept;

[[nodiscard]] std::string parse_code_name(ParseCode code);
[[nodiscard]] std::string event_kind_name(EventKind kind);
[[nodiscard]] std::uint64_t fnv1a64(std::span<const std::uint8_t> bytes) noexcept;
[[nodiscard]] std::string hex64(std::uint64_t value);
[[nodiscard]] CampaignReport run_dmlog_campaign(const std::filesystem::path& output);

}  // namespace slopos::e0::trace_intake
