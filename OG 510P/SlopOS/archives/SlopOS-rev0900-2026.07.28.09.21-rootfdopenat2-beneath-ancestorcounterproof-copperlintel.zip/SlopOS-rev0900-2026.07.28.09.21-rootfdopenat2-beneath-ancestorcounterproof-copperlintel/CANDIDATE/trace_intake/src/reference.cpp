#include "slopos/e0/trace_intake/dmlog.hpp"

#include <utility>

namespace slopos::e0::trace_intake {
namespace {

[[nodiscard]] std::uint64_t decode_u64(
    const std::span<const std::uint8_t> block,
    const std::size_t start) noexcept {
    std::uint64_t answer = 0U;
    std::uint64_t factor = 1U;
    for (std::size_t position = start; position < start + 8U; ++position) {
        answer += static_cast<std::uint64_t>(block[position]) * factor;
        factor *= 256U;
    }
    return answer;
}

[[nodiscard]] std::uint32_t decode_u32(
    const std::span<const std::uint8_t> block,
    const std::size_t start) noexcept {
    std::uint32_t answer = 0U;
    std::uint32_t factor = 1U;
    for (std::size_t position = start; position < start + 4U; ++position) {
        answer += static_cast<std::uint32_t>(block[position]) * factor;
        factor *= 256U;
    }
    return answer;
}

[[nodiscard]] bool approved_sector_size(const std::uint32_t value) noexcept {
    switch (value) {
        case 512U:
        case 1024U:
        case 2048U:
        case 4096U: return true;
        default: return false;
    }
}

[[nodiscard]] bool zeros_from(
    const std::span<const std::uint8_t> block,
    const std::size_t start) noexcept {
    if (start > block.size()) return false;
    for (std::size_t index = start; index < block.size(); ++index) {
        if (block[index] != 0U) return false;
    }
    return true;
}

[[nodiscard]] ParseResult no(const ParseCode code, const char* detail) {
    return ParseResult{false, code, detail, {}};
}

[[nodiscard]] bool range_fits(
    const std::uint64_t first,
    const std::uint64_t count,
    const std::uint64_t limit) noexcept {
    return first <= limit && count <= limit - first;
}

}  // namespace

ParseResult parse_reference(
    const std::span<const std::uint8_t> raw,
    const std::uint64_t baseline_sectors) {
    if (raw.size() < kSuperBytes) {
        return no(ParseCode::truncated_super, "reference: short super header");
    }
    const std::uint32_t sector_size = decode_u32(raw, 24U);
    if (decode_u64(raw, 0U) != kWriteLogMagic) {
        return no(ParseCode::bad_magic, "reference: magic");
    }
    if (decode_u64(raw, 8U) != kWriteLogVersion) {
        return no(ParseCode::bad_version, "reference: version");
    }
    if (!approved_sector_size(sector_size)) {
        return no(ParseCode::bad_sector_size, "reference: sector size");
    }
    const std::size_t stride = static_cast<std::size_t>(sector_size);
    if (raw.size() < stride) {
        return no(ParseCode::truncated_super, "reference: short super sector");
    }
    if ((raw.size() / stride) * stride != raw.size()) {
        return no(ParseCode::misaligned_length, "reference: alignment");
    }
    const auto super = raw.first(stride);
    if (!zeros_from(super, kSuperBytes)) {
        return no(ParseCode::invalid_combination, "reference: super padding");
    }

    ParsedLog answer{};
    answer.sector_size = sector_size;
    answer.advertised_entries = decode_u64(super, 16U);
    std::size_t sector_cursor = 1U;
    const std::uint64_t allowed = kLogFlushFlag | kLogFuaFlag
        | kLogDiscardFlag | kLogMarkFlag | kLogMetadataFlag;

    for (std::uint64_t ordinal = 0U; ordinal < answer.advertised_entries; ++ordinal) {
        const std::size_t total_sectors = raw.size() / stride;
        if (sector_cursor >= total_sectors) {
            return no(ParseCode::truncated_entry, "reference: missing entry sector");
        }
        const auto header = raw.subspan(sector_cursor * stride, stride);
        const std::uint64_t address = decode_u64(header, 0U);
        const std::uint64_t count = decode_u64(header, 8U);
        const std::uint64_t flags = decode_u64(header, 16U);
        const std::uint64_t inline_bytes = decode_u64(header, 24U);
        if ((flags | allowed) != allowed) {
            return no(ParseCode::unknown_flags, "reference: unknown flags");
        }

        Event event{};
        event.index = static_cast<std::size_t>(ordinal);
        if ((flags & kLogMarkFlag) != 0U) {
            if (flags != kLogMarkFlag || address != 0U || count != 0U
                || inline_bytes == 0U
                || inline_bytes > static_cast<std::uint64_t>(stride - kEntryBytes)) {
                return no(ParseCode::invalid_mark, "reference: mark shape");
            }
            const std::size_t mark_length = static_cast<std::size_t>(inline_bytes);
            for (std::size_t index = 0U; index < mark_length; ++index) {
                const std::uint8_t value = header[kEntryBytes + index];
                if (value < 0x20U || value > 0x7eU) {
                    return no(ParseCode::invalid_mark, "reference: mark characters");
                }
                event.mark.push_back(static_cast<char>(value));
            }
            if (!zeros_from(header, kEntryBytes + mark_length)) {
                return no(ParseCode::invalid_mark, "reference: mark padding");
            }
            event.kind = EventKind::mark;
            if (event.mark == "dm-log-writes-end") answer.end_mark_present = true;
            answer.events.push_back(std::move(event));
            ++sector_cursor;
            continue;
        }
        if ((flags & kLogDiscardFlag) != 0U) {
            return no(ParseCode::unsupported_discard, "reference: discard profile");
        }
        if ((flags & kLogFlushFlag) != 0U) {
            if (flags != kLogFlushFlag || address != 0U || count != 0U
                || inline_bytes != 0U || !zeros_from(header, kEntryBytes)) {
                return no(ParseCode::invalid_combination,
                          "reference: pure flush only");
            }
            event.kind = EventKind::flush;
            answer.events.push_back(std::move(event));
            ++sector_cursor;
            continue;
        }
        if ((flags & ~(kLogFuaFlag | kLogMetadataFlag)) != 0U
            || count == 0U || inline_bytes != 0U
            || !zeros_from(header, kEntryBytes)) {
            return no(ParseCode::invalid_combination,
                      "reference: write combination");
        }
        if (!range_fits(address, count, baseline_sectors)) {
            return no(ParseCode::out_of_range, "reference: target range");
        }
        const std::uint64_t remaining_sectors = static_cast<std::uint64_t>(
            total_sectors - sector_cursor - 1U);
        if (count > remaining_sectors) {
            return no(ParseCode::truncated_payload, "reference: payload");
        }
        event.kind = (flags & kLogFuaFlag) != 0U
            ? EventKind::fua_write : EventKind::write;
        event.sector = address;
        event.nr_sectors = count;
        event.metadata = (flags & kLogMetadataFlag) != 0U;
        const std::size_t payload_start = (sector_cursor + 1U) * stride;
        const std::size_t payload_size = static_cast<std::size_t>(count) * stride;
        event.data.assign(raw.begin() + static_cast<std::ptrdiff_t>(payload_start),
                          raw.begin() + static_cast<std::ptrdiff_t>(
                              payload_start + payload_size));
        answer.events.push_back(std::move(event));
        sector_cursor += static_cast<std::size_t>(count) + 1U;
    }
    if (sector_cursor * stride != raw.size()) {
        return no(ParseCode::trailing_bytes, "reference: trailing bytes");
    }
    answer.used_bytes = raw.size();
    return ParseResult{true, ParseCode::ok, "reference accepted", std::move(answer)};
}

}  // namespace slopos::e0::trace_intake
