#include "slopos/e0/trace_intake/dmlog.hpp"

#include <algorithm>
#include <iomanip>
#include <limits>
#include <sstream>
#include <utility>

namespace slopos::e0::trace_intake {
namespace {

[[nodiscard]] std::uint32_t read_le32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t i = 0U; i < 4U; ++i) {
        value |= static_cast<std::uint32_t>(bytes[offset + i])
            << static_cast<unsigned int>(8U * i);
    }
    return value;
}

[[nodiscard]] std::uint64_t read_le64(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t i = 0U; i < 8U; ++i) {
        value |= static_cast<std::uint64_t>(bytes[offset + i])
            << static_cast<unsigned int>(8U * i);
    }
    return value;
}

[[nodiscard]] bool valid_sector_size(const std::uint32_t value) noexcept {
    return value == 512U || value == 1024U || value == 2048U || value == 4096U;
}

[[nodiscard]] bool all_zero(const std::span<const std::uint8_t> bytes) noexcept {
    return std::all_of(bytes.begin(), bytes.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] bool printable_mark(const std::span<const std::uint8_t> bytes) noexcept {
    return !bytes.empty() && std::all_of(
        bytes.begin(), bytes.end(), [](const std::uint8_t byte) {
            return byte >= 0x20U && byte <= 0x7eU;
        });
}

[[nodiscard]] ParseResult reject(const ParseCode code, std::string detail) {
    return ParseResult{false, code, std::move(detail), {}};
}

[[nodiscard]] bool multiplication_overflows(
    const std::uint64_t count,
    const std::uint32_t sector_size,
    std::size_t& out) noexcept {
    const auto limit = static_cast<std::uint64_t>(
        std::numeric_limits<std::size_t>::max() / sector_size);
    if (count > limit) return true;
    out = static_cast<std::size_t>(count) * static_cast<std::size_t>(sector_size);
    return false;
}

}  // namespace

ParseResult parse_strict(
    const std::span<const std::uint8_t> raw,
    const std::uint64_t baseline_sectors) {
    if (raw.size() < kSuperBytes) {
        return reject(ParseCode::truncated_super, "super header shorter than 28 bytes");
    }
    const std::uint64_t magic = read_le64(raw, 0U);
    const std::uint64_t version = read_le64(raw, 8U);
    const std::uint64_t advertised = read_le64(raw, 16U);
    const std::uint32_t sector_size = read_le32(raw, 24U);
    if (magic != kWriteLogMagic) {
        return reject(ParseCode::bad_magic, "write-log magic mismatch");
    }
    if (version != kWriteLogVersion) {
        return reject(ParseCode::bad_version, "write-log version mismatch");
    }
    if (!valid_sector_size(sector_size)) {
        return reject(ParseCode::bad_sector_size, "unsupported logical sector size");
    }
    if (raw.size() < static_cast<std::size_t>(sector_size)) {
        return reject(ParseCode::truncated_super, "super sector truncated");
    }
    if ((raw.size() % static_cast<std::size_t>(sector_size)) != 0U) {
        return reject(ParseCode::misaligned_length, "trimmed export is not sector aligned");
    }
    if (!all_zero(raw.subspan(
            kSuperBytes, static_cast<std::size_t>(sector_size) - kSuperBytes))) {
        return reject(ParseCode::invalid_combination, "nonzero super padding");
    }

    ParsedLog parsed{};
    parsed.sector_size = sector_size;
    parsed.advertised_entries = advertised;
    parsed.events.reserve(static_cast<std::size_t>(
        std::min<std::uint64_t>(advertised, 4096U)));
    std::size_t offset = static_cast<std::size_t>(sector_size);
    const std::uint64_t known_flags = kLogFlushFlag | kLogFuaFlag
        | kLogDiscardFlag | kLogMarkFlag | kLogMetadataFlag;

    for (std::uint64_t entry_index = 0U; entry_index < advertised; ++entry_index) {
        if (offset > raw.size()
            || raw.size() - offset < static_cast<std::size_t>(sector_size)) {
            return reject(ParseCode::truncated_entry,
                          "advertised entry header is missing");
        }
        const auto header = raw.subspan(offset, sector_size);
        const std::uint64_t target_sector = read_le64(header, 0U);
        const std::uint64_t nr_sectors = read_le64(header, 8U);
        const std::uint64_t flags = read_le64(header, 16U);
        const std::uint64_t data_len = read_le64(header, 24U);
        if ((flags & ~known_flags) != 0U) {
            return reject(ParseCode::unknown_flags,
                          "entry contains unknown flag bits");
        }

        Event event{};
        event.index = static_cast<std::size_t>(entry_index);
        if ((flags & kLogMarkFlag) != 0U) {
            if (flags != kLogMarkFlag || target_sector != 0U
                || nr_sectors != 0U || data_len == 0U
                || data_len > static_cast<std::uint64_t>(
                    static_cast<std::size_t>(sector_size) - kEntryBytes)) {
                return reject(ParseCode::invalid_mark,
                              "mark shape is outside strict profile");
            }
            const std::size_t mark_size = static_cast<std::size_t>(data_len);
            const auto mark_bytes = header.subspan(kEntryBytes, mark_size);
            if (!printable_mark(mark_bytes)
                || !all_zero(header.subspan(kEntryBytes + mark_size))) {
                return reject(ParseCode::invalid_mark,
                              "mark bytes or padding are noncanonical");
            }
            event.kind = EventKind::mark;
            event.mark.assign(mark_bytes.begin(), mark_bytes.end());
            parsed.end_mark_present = parsed.end_mark_present
                || event.mark == "dm-log-writes-end";
            parsed.events.push_back(std::move(event));
            offset += static_cast<std::size_t>(sector_size);
            continue;
        }

        if ((flags & kLogDiscardFlag) != 0U) {
            return reject(ParseCode::unsupported_discard,
                          "discard semantics are not admitted by the first profile");
        }

        if ((flags & kLogFlushFlag) != 0U) {
            if (flags != kLogFlushFlag || target_sector != 0U
                || nr_sectors != 0U || data_len != 0U
                || !all_zero(header.subspan(kEntryBytes))) {
                return reject(ParseCode::invalid_combination,
                              "only a pure preflush entry is admitted");
            }
            event.kind = EventKind::flush;
            parsed.events.push_back(std::move(event));
            offset += static_cast<std::size_t>(sector_size);
            continue;
        }

        const std::uint64_t allowed_write_flags = kLogFuaFlag | kLogMetadataFlag;
        if ((flags & ~allowed_write_flags) != 0U || nr_sectors == 0U
            || data_len != 0U || !all_zero(header.subspan(kEntryBytes))) {
            return reject(ParseCode::invalid_combination,
                          "write entry shape is outside strict profile");
        }
        if (target_sector > baseline_sectors
            || nr_sectors > baseline_sectors - target_sector) {
            return reject(ParseCode::out_of_range,
                          "write range exceeds declared baseline");
        }
        std::size_t payload_size = 0U;
        if (multiplication_overflows(nr_sectors, sector_size, payload_size)) {
            return reject(ParseCode::out_of_range, "payload size overflow");
        }
        const std::size_t payload_offset = offset
            + static_cast<std::size_t>(sector_size);
        if (payload_offset > raw.size() || payload_size > raw.size() - payload_offset) {
            return reject(ParseCode::truncated_payload,
                          "write payload is shorter than declared range");
        }
        event.kind = (flags & kLogFuaFlag) != 0U
            ? EventKind::fua_write : EventKind::write;
        event.sector = target_sector;
        event.nr_sectors = nr_sectors;
        event.metadata = (flags & kLogMetadataFlag) != 0U;
        const auto payload = raw.subspan(payload_offset, payload_size);
        event.data.assign(payload.begin(), payload.end());
        parsed.events.push_back(std::move(event));
        offset = payload_offset + payload_size;
    }

    if (offset != raw.size()) {
        return reject(ParseCode::trailing_bytes,
                      "trimmed export contains bytes beyond advertised entries");
    }
    parsed.used_bytes = offset;
    return ParseResult{true, ParseCode::ok,
                       "strict dm-log-writes v1 profile accepted",
                       std::move(parsed)};
}

Bytes replay_prefix(
    const std::span<const std::uint8_t> baseline,
    const ParsedLog& log,
    const std::size_t event_count) {
    if (event_count > log.events.size() || log.sector_size == 0U
        || (baseline.size() % log.sector_size) != 0U) {
        return {};
    }
    Bytes image(baseline.begin(), baseline.end());
    for (std::size_t index = 0U; index < event_count; ++index) {
        const Event& event = log.events[index];
        if (event.kind != EventKind::write && event.kind != EventKind::fua_write) {
            continue;
        }
        const std::size_t target = static_cast<std::size_t>(event.sector)
            * static_cast<std::size_t>(log.sector_size);
        if (target > image.size() || event.data.size() > image.size() - target) {
            return {};
        }
        std::copy(event.data.begin(), event.data.end(),
                  image.begin() + static_cast<std::ptrdiff_t>(target));
    }
    return image;
}

bool equivalent(const ParseResult& lhs, const ParseResult& rhs) noexcept {
    if (lhs.ok != rhs.ok || lhs.code != rhs.code) return false;
    if (!lhs.ok) return true;
    if (lhs.log.sector_size != rhs.log.sector_size
        || lhs.log.advertised_entries != rhs.log.advertised_entries
        || lhs.log.used_bytes != rhs.log.used_bytes
        || lhs.log.end_mark_present != rhs.log.end_mark_present
        || lhs.log.events.size() != rhs.log.events.size()) {
        return false;
    }
    for (std::size_t index = 0U; index < lhs.log.events.size(); ++index) {
        const Event& a = lhs.log.events[index];
        const Event& b = rhs.log.events[index];
        if (a.index != b.index || a.kind != b.kind || a.sector != b.sector
            || a.nr_sectors != b.nr_sectors || a.metadata != b.metadata
            || a.mark != b.mark || a.data != b.data) {
            return false;
        }
    }
    return true;
}

std::string parse_code_name(const ParseCode code) {
    switch (code) {
        case ParseCode::ok: return "OK";
        case ParseCode::truncated_super: return "TRUNCATED_SUPER";
        case ParseCode::bad_magic: return "BAD_MAGIC";
        case ParseCode::bad_version: return "BAD_VERSION";
        case ParseCode::bad_sector_size: return "BAD_SECTOR_SIZE";
        case ParseCode::misaligned_length: return "MISALIGNED_LENGTH";
        case ParseCode::truncated_entry: return "TRUNCATED_ENTRY";
        case ParseCode::unknown_flags: return "UNKNOWN_FLAGS";
        case ParseCode::invalid_combination: return "INVALID_COMBINATION";
        case ParseCode::invalid_mark: return "INVALID_MARK";
        case ParseCode::unsupported_discard: return "UNSUPPORTED_DISCARD";
        case ParseCode::out_of_range: return "OUT_OF_RANGE";
        case ParseCode::truncated_payload: return "TRUNCATED_PAYLOAD";
        case ParseCode::trailing_bytes: return "TRAILING_BYTES";
    }
    return "INVALID_PARSE_CODE";
}

std::string event_kind_name(const EventKind kind) {
    switch (kind) {
        case EventKind::write: return "WRITE";
        case EventKind::fua_write: return "FUA_WRITE";
        case EventKind::flush: return "FLUSH";
        case EventKind::mark: return "MARK";
    }
    return "INVALID_EVENT_KIND";
}

std::uint64_t fnv1a64(const std::span<const std::uint8_t> bytes) noexcept {
    std::uint64_t value = 14695981039346656037ULL;
    for (const std::uint8_t byte : bytes) {
        value ^= static_cast<std::uint64_t>(byte);
        value *= 1099511628211ULL;
    }
    return value;
}

std::string hex64(const std::uint64_t value) {
    std::ostringstream stream;
    stream << std::hex << std::setfill('0') << std::setw(16) << value;
    return stream.str();
}

}  // namespace slopos::e0::trace_intake
