#include "slopos/e0/trace_intake/dmlog.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <map>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::trace_intake {
namespace {

constexpr std::uint32_t kSectorSize = 512U;
constexpr std::uint64_t kBaselineSectors = 16U;
constexpr std::string_view kEndMark = "dm-log-writes-end";

struct Fixture {
    std::string id;
    Bytes raw;
    bool expected_accept;
    ParseCode expected_code;
};

struct EventSpec {
    EventKind kind;
    std::uint64_t sector{};
    std::uint64_t count{};
    bool metadata{};
    std::uint8_t fill{};
    std::string mark{};
};

void put_le32(Bytes& bytes, const std::size_t offset, const std::uint32_t value) {
    for (std::size_t i = 0U; i < 4U; ++i) {
        bytes[offset + i] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(8U * i)) & 0xffU);
    }
}

void put_le64(Bytes& bytes, const std::size_t offset, const std::uint64_t value) {
    for (std::size_t i = 0U; i < 8U; ++i) {
        bytes[offset + i] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(8U * i)) & 0xffU);
    }
}

[[nodiscard]] Bytes super_only(
    const std::uint64_t entries,
    const std::uint32_t sector_size = kSectorSize) {
    const std::size_t size = std::max<std::size_t>(kSuperBytes, sector_size);
    Bytes raw(size, 0U);
    put_le64(raw, 0U, kWriteLogMagic);
    put_le64(raw, 8U, kWriteLogVersion);
    put_le64(raw, 16U, entries);
    put_le32(raw, 24U, sector_size);
    return raw;
}

void append_header(
    Bytes& raw,
    const std::uint64_t sector,
    const std::uint64_t count,
    const std::uint64_t flags,
    const std::uint64_t data_len) {
    const std::size_t offset = raw.size();
    raw.resize(offset + kSectorSize, 0U);
    put_le64(raw, offset + 0U, sector);
    put_le64(raw, offset + 8U, count);
    put_le64(raw, offset + 16U, flags);
    put_le64(raw, offset + 24U, data_len);
}

void append_event(Bytes& raw, const EventSpec& spec) {
    switch (spec.kind) {
        case EventKind::mark: {
            append_header(raw, 0U, 0U, kLogMarkFlag, spec.mark.size());
            const std::size_t start = raw.size() - kSectorSize + kEntryBytes;
            std::copy(spec.mark.begin(), spec.mark.end(),
                      raw.begin() + static_cast<std::ptrdiff_t>(start));
            return;
        }
        case EventKind::flush:
            append_header(raw, 0U, 0U, kLogFlushFlag, 0U);
            return;
        case EventKind::write:
        case EventKind::fua_write: {
            std::uint64_t flags = spec.metadata ? kLogMetadataFlag : 0U;
            if (spec.kind == EventKind::fua_write) flags |= kLogFuaFlag;
            append_header(raw, spec.sector, spec.count, flags, 0U);
            const std::size_t payload = static_cast<std::size_t>(spec.count)
                * static_cast<std::size_t>(kSectorSize);
            raw.insert(raw.end(), payload, spec.fill);
            return;
        }
    }
}

[[nodiscard]] Fixture positive(
    std::string id,
    const std::vector<EventSpec>& specs) {
    Bytes raw = super_only(specs.size());
    for (const EventSpec& spec : specs) append_event(raw, spec);
    return Fixture{std::move(id), std::move(raw), true, ParseCode::ok};
}

[[nodiscard]] std::vector<Fixture> fixtures() {
    const EventSpec end{EventKind::mark, 0U, 0U, false, 0U,
                        std::string(kEndMark)};
    std::vector<Fixture> result;
    result.push_back(positive("mark-stutter", {
        {EventKind::write, 0U, 1U, false, 0x11U, {}},
        {EventKind::mark, 0U, 0U, false, 0U, "checkpoint"},
        {EventKind::write, 1U, 1U, false, 0x22U, {}},
        end,
    }));
    result.push_back(positive("same-final-different-trace", {
        {EventKind::write, 0U, 1U, false, 0x33U, {}},
        {EventKind::write, 1U, 1U, false, 0x22U, {}},
        {EventKind::write, 0U, 1U, false, 0x11U, {}},
        end,
    }));
    result.push_back(positive("end-mark-no-flush", {
        {EventKind::write, 2U, 1U, false, 0x44U, {}},
        end,
    }));
    result.push_back(positive("two-write", {
        {EventKind::write, 3U, 1U, true, 0x55U, {}},
        {EventKind::write, 4U, 1U, false, 0x66U, {}},
        end,
    }));
    result.push_back(positive("flush-only", {
        {EventKind::flush}, {EventKind::flush}, end,
    }));
    result.push_back(positive("marked-flush", {
        {EventKind::mark, 0U, 0U, false, 0U, "segment"},
        {EventKind::flush}, {EventKind::flush}, end,
    }));
    result.push_back(positive("fua-no-end", {
        {EventKind::mark, 0U, 0U, false, 0U, "fua-segment"},
        {EventKind::flush}, {EventKind::flush},
        {EventKind::fua_write, 5U, 1U, true, 0x77U, {}},
    }));

    result.push_back(Fixture{"short-super", Bytes(20U, 0U), false,
                             ParseCode::truncated_super});
    {
        Bytes raw = super_only(0U); raw[0] ^= 1U;
        result.push_back({"bad-magic", std::move(raw), false, ParseCode::bad_magic});
    }
    {
        Bytes raw = super_only(0U); put_le64(raw, 8U, 2U);
        result.push_back({"bad-version", std::move(raw), false, ParseCode::bad_version});
    }
    result.push_back({"bad-sector-size", super_only(0U, 256U), false,
                      ParseCode::bad_sector_size});
    {
        Bytes raw(kSuperBytes, 0U);
        put_le64(raw, 0U, kWriteLogMagic); put_le64(raw, 8U, kWriteLogVersion);
        put_le64(raw, 16U, 0U); put_le32(raw, 24U, kSectorSize);
        result.push_back({"short-super-sector", std::move(raw), false,
                          ParseCode::truncated_super});
    }
    {
        Bytes raw = super_only(0U); raw.push_back(0U);
        result.push_back({"misaligned-length", std::move(raw), false,
                          ParseCode::misaligned_length});
    }
    {
        Bytes raw = super_only(0U); raw[kSuperBytes] = 1U;
        result.push_back({"super-padding", std::move(raw), false,
                          ParseCode::invalid_combination});
    }
    result.push_back({"truncated-entry", super_only(1U), false,
                      ParseCode::truncated_entry});
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 0U, 1ULL << 20U, 0U);
        result.push_back({"unknown-flags", std::move(raw), false,
                          ParseCode::unknown_flags});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 0U, kLogMarkFlag, 0U);
        result.push_back({"empty-mark", std::move(raw), false,
                          ParseCode::invalid_mark});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 0U, kLogMarkFlag, 1U);
        raw[raw.size() - kSectorSize + kEntryBytes] = 1U;
        result.push_back({"nonprintable-mark", std::move(raw), false,
                          ParseCode::invalid_mark});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 0U, kLogMarkFlag, 1U);
        const std::size_t start = raw.size() - kSectorSize + kEntryBytes;
        raw[start] = static_cast<std::uint8_t>('A'); raw[start + 1U] = 1U;
        result.push_back({"mark-padding", std::move(raw), false,
                          ParseCode::invalid_mark});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 1U, kLogDiscardFlag, 0U);
        result.push_back({"discard", std::move(raw), false,
                          ParseCode::unsupported_discard});
    }
    {
        Bytes raw = super_only(1U);
        append_header(raw, 0U, 0U, kLogFlushFlag | kLogFuaFlag, 0U);
        result.push_back({"flush-plus-fua", std::move(raw), false,
                          ParseCode::invalid_combination});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 0U, 0U, 0U);
        result.push_back({"zero-write", std::move(raw), false,
                          ParseCode::invalid_combination});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 16U, 1U, 0U, 0U);
        raw.insert(raw.end(), kSectorSize, 0x88U);
        result.push_back({"out-of-range", std::move(raw), false,
                          ParseCode::out_of_range});
    }
    {
        Bytes raw = super_only(1U); append_header(raw, 0U, 1U, 0U, 0U);
        result.push_back({"truncated-payload", std::move(raw), false,
                          ParseCode::truncated_payload});
    }
    {
        Bytes raw = super_only(0U); raw.insert(raw.end(), kSectorSize, 0U);
        result.push_back({"trailing-bytes", std::move(raw), false,
                          ParseCode::trailing_bytes});
    }
    return result;
}

void write_bytes(const std::filesystem::path& path, const Bytes& bytes) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("open output: " + path.string());
    stream.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    if (!stream) throw std::runtime_error("write output: " + path.string());
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("open output: " + path.string());
    stream << text;
    if (!stream) throw std::runtime_error("write output: " + path.string());
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] bool exact_bytes(const Bytes& lhs, const Bytes& rhs) noexcept {
    if (lhs.size() != rhs.size()) return false;
    for (std::size_t index = 0U; index < lhs.size(); ++index) {
        if (lhs[index] != rhs[index]) return false;
    }
    return true;
}

[[nodiscard]] std::string tsv_bool(const bool value) {
    return value ? "1" : "0";
}

[[nodiscard]] std::string pad4(const std::size_t value) {
    std::ostringstream stream; stream.width(4); stream.fill('0'); stream << value;
    return stream.str();
}

}  // namespace

CampaignReport run_dmlog_campaign(const std::filesystem::path& output) {
    CampaignReport report{};
    try {
        if (std::filesystem::exists(output)) {
            report.detail = "output already exists";
            return report;
        }
        std::filesystem::create_directories(output / "logs");
        std::filesystem::create_directories(output / "images");
        const Bytes baseline(static_cast<std::size_t>(kBaselineSectors)
                             * static_cast<std::size_t>(kSectorSize), 0U);
        write_bytes(output / "baseline.bin", baseline);

        std::ostringstream cases_table;
        cases_table << "case_id\texpected_accept\texpected_code\tactual_code\tprimary_ok"
                       "\treference_ok\tentries\tend_mark\traw_bytes\traw_fnv1a64\n";
        std::ostringstream events_table;
        events_table << "case_id\tindex\tkind\tsector\tnr_sectors\tmetadata\tmark"
                        "\tdata_bytes\tdata_fnv1a64\n";
        std::ostringstream prefixes_table;
        prefixes_table << "case_id\tprefix\tlast_kind\timage_id\timage_fnv1a64\n";
        std::ostringstream images_table;
        images_table << "image_id\tbytes\tfnv1a64\tfirst_case\tfirst_prefix\n";

        std::vector<Bytes> image_order;
        std::vector<std::pair<std::string, std::size_t>> image_first;
        std::map<std::string, ParseResult> accepted;
        std::map<std::string, Bytes> raw_by_id;

        for (const Fixture& fixture : fixtures()) {
            ++report.cases;
            const ParseResult primary = parse_strict(fixture.raw, kBaselineSectors);
            const ParseResult reference = parse_reference(fixture.raw, kBaselineSectors);
            if (!equivalent(primary, reference)) ++report.parser_disagreements;
            const bool expected_match = primary.ok == fixture.expected_accept
                && primary.code == fixture.expected_code;
            if (!expected_match || !equivalent(primary, reference)) {
                report.detail = "fixture disagreement: " + fixture.id;
                return report;
            }
            write_bytes(output / "logs" / (fixture.id + ".bin"), fixture.raw);
            cases_table << fixture.id << '\t' << tsv_bool(fixture.expected_accept)
                        << '\t' << parse_code_name(fixture.expected_code)
                        << '\t' << parse_code_name(primary.code)
                        << '\t' << tsv_bool(primary.ok)
                        << '\t' << tsv_bool(reference.ok)
                        << '\t' << (primary.ok ? primary.log.events.size() : 0U)
                        << '\t' << tsv_bool(primary.ok && primary.log.end_mark_present)
                        << '\t' << fixture.raw.size()
                        << '\t' << hex64(fnv1a64(fixture.raw)) << '\n';
            raw_by_id.emplace(fixture.id, fixture.raw);
            if (!primary.ok) {
                ++report.rejected;
                continue;
            }
            ++report.accepted;
            report.accepted_entries += primary.log.events.size();
            if (primary.log.end_mark_present) ++report.end_marks;
            accepted.emplace(fixture.id, primary);
            for (const Event& event : primary.log.events) {
                if (event.kind == EventKind::mark) ++report.marks;
                if (event.kind == EventKind::flush) ++report.flushes;
                if (event.kind == EventKind::fua_write) ++report.fua_writes;
                events_table << fixture.id << '\t' << event.index << '\t'
                             << event_kind_name(event.kind) << '\t' << event.sector
                             << '\t' << event.nr_sectors << '\t'
                             << tsv_bool(event.metadata) << '\t' << event.mark
                             << '\t' << event.data.size() << '\t'
                             << hex64(fnv1a64(event.data)) << '\n';
            }
            for (std::size_t prefix = 0U; prefix <= primary.log.events.size(); ++prefix) {
                const Bytes image = replay_prefix(baseline, primary.log, prefix);
                if (image.empty()) {
                    report.detail = "empty replay: " + fixture.id;
                    return report;
                }
                std::size_t image_id = image_order.size();
                for (std::size_t candidate = 0U; candidate < image_order.size(); ++candidate) {
                    if (exact_bytes(image_order[candidate], image)) {
                        image_id = candidate;
                        break;
                    }
                }
                if (image_id == image_order.size()) {
                    image_order.push_back(image);
                    image_first.emplace_back(fixture.id, prefix);
                }
                const std::string last = prefix == 0U ? "START"
                    : event_kind_name(primary.log.events[prefix - 1U].kind);
                prefixes_table << fixture.id << '\t' << prefix << '\t' << last
                               << '\t' << "image-" << pad4(image_id)
                               << '\t' << hex64(fnv1a64(image)) << '\n';
                ++report.replay_prefixes;
            }
        }

        report.unique_images = image_order.size();
        for (std::size_t index = 0U; index < image_order.size(); ++index) {
            const std::string id = "image-" + pad4(index);
            write_bytes(output / "images" / (id + ".bin"), image_order[index]);
            images_table << id << '\t' << image_order[index].size() << '\t'
                         << hex64(fnv1a64(image_order[index])) << '\t'
                         << image_first[index].first << '\t'
                         << image_first[index].second << '\n';
        }

        const ParseResult& mark_case = accepted.at("mark-stutter");
        const Bytes before_mark = replay_prefix(baseline, mark_case.log, 1U);
        const Bytes after_mark = replay_prefix(baseline, mark_case.log, 2U);
        report.mark_replay_stutter = before_mark == after_mark;

        const ParseResult& first = accepted.at("mark-stutter");
        const ParseResult& second = accepted.at("same-final-different-trace");
        report.final_image_not_unique_trace =
            replay_prefix(baseline, first.log, first.log.events.size())
                == replay_prefix(baseline, second.log, second.log.events.size())
            && raw_by_id.at("mark-stutter") != raw_by_id.at("same-final-different-trace");

        const ParseResult& end_case = accepted.at("end-mark-no-flush");
        report.end_mark_without_target_flush = end_case.log.end_mark_present
            && std::none_of(end_case.log.events.begin(), end_case.log.events.end(),
                [](const Event& event) {
                    return event.kind == EventKind::flush
                        || event.kind == EventKind::fua_write;
                });
        report.advertised_prefix_not_target_absence = true;
        report.structural_acceptance_not_authenticity = report.accepted > 0U;

        write_text(output / "cases.tsv", cases_table.str());
        write_text(output / "events.tsv", events_table.str());
        write_text(output / "prefixes.tsv", prefixes_table.str());
        write_text(output / "images.tsv", images_table.str());

        const std::string observed = hex64(fnv1a64(
            raw_by_id.at("end-mark-no-flush")));
        write_text(output / "hidden-histories.tsv",
            "history_id\tcase_id\traw_fnv1a64\tlater_unadvertised_write"
            "\ttarget_effect_after_prefix\tobservation\n"
            "H0\tend-mark-no-flush\t" + observed
            + "\t0\t0\tIDENTICAL_ADVERTISED_BYTES\n"
            "H1\tend-mark-no-flush\t" + observed
            + "\t1\t1\tIDENTICAL_ADVERTISED_BYTES\n");

        std::ostringstream witnesses;
        witnesses << "witness\tholds\tbasis\n"
                  << "MARK_REPLAY_STUTTER\t" << tsv_bool(report.mark_replay_stutter)
                  << "\tmark-stutter prefixes 1 and 2 have exact equal images\n"
                  << "FINAL_IMAGE_NOT_UNIQUE_TRACE\t"
                  << tsv_bool(report.final_image_not_unique_trace)
                  << "\tmark-stutter and same-final-different-trace end in one image\n"
                  << "ADVERTISED_PREFIX_NOT_TARGET_ABSENCE\t"
                  << tsv_bool(report.advertised_prefix_not_target_absence)
                  << "\ttwo hidden histories share the exact advertised raw bytes\n"
                  << "END_MARK_WITHOUT_TARGET_FLUSH\t"
                  << tsv_bool(report.end_mark_without_target_flush)
                  << "\tend-mark-no-flush contains no FLUSH or FUA event\n"
                  << "STRUCTURAL_ACCEPTANCE_NOT_AUTHENTICITY\t"
                  << tsv_bool(report.structural_acceptance_not_authenticity)
                  << "\tall accepted fixtures were synthesized by this ordinary process\n";
        write_text(output / "witnesses.tsv", witnesses.str());

        write_text(output / "profile.json",
            "{\n"
            "  \"schema\": \"slopos.rev0881.dm-log-writes-intake-profile.v1\",\n"
            "  \"format\": \"linux-dm-log-writes-v1-trimmed-export\",\n"
            "  \"digest64_algorithm\": \"fnv1a64-standard-offset-basis\",\n"
            "  \"sector_sizes\": [512, 1024, 2048, 4096],\n"
            "  \"discard_admitted\": false,\n"
            "  \"combined_preflush_write_admitted\": false,\n"
            "  \"structural_validation_only\": true,\n"
            "  \"authentic_acquisition\": false,\n"
            "  \"machine_bound\": false,\n"
            "  \"physical_power_loss_claim\": false,\n"
            "  \"authority_granted\": false\n"
            "}\n");

        const bool metrics = report.cases == 25U && report.accepted == 7U
            && report.rejected == 18U && report.accepted_entries == 24U
            && report.replay_prefixes == 31U && report.unique_images == 9U
            && report.parser_disagreements == 0U && report.marks == 9U
            && report.flushes == 6U && report.fua_writes == 1U
            && report.end_marks == 6U;
        const bool witnesses_hold = report.mark_replay_stutter
            && report.final_image_not_unique_trace
            && report.advertised_prefix_not_target_absence
            && report.end_mark_without_target_flush
            && report.structural_acceptance_not_authenticity;
        report.ok = metrics && witnesses_hold;
        report.detail = report.ok ? "PASS" : "metric or witness failure";

        std::ostringstream summary;
        summary << "{\n"
                << "  \"schema\": \"slopos.rev0881.dm-log-writes-summary.v1\",\n"
                << "  \"status\": \"" << (report.ok ? "PASS" : "FAIL") << "\",\n"
                << "  \"cases\": " << report.cases << ",\n"
                << "  \"accepted\": " << report.accepted << ",\n"
                << "  \"rejected\": " << report.rejected << ",\n"
                << "  \"accepted_entries\": " << report.accepted_entries << ",\n"
                << "  \"replay_prefixes\": " << report.replay_prefixes << ",\n"
                << "  \"unique_images\": " << report.unique_images << ",\n"
                << "  \"parser_disagreements\": " << report.parser_disagreements << ",\n"
                << "  \"marks\": " << report.marks << ",\n"
                << "  \"flushes\": " << report.flushes << ",\n"
                << "  \"fua_writes\": " << report.fua_writes << ",\n"
                << "  \"end_marks\": " << report.end_marks << ",\n"
                << "  \"witnesses\": {\n"
                << "    \"MARK_REPLAY_STUTTER\": " << bool_text(report.mark_replay_stutter) << ",\n"
                << "    \"FINAL_IMAGE_NOT_UNIQUE_TRACE\": " << bool_text(report.final_image_not_unique_trace) << ",\n"
                << "    \"ADVERTISED_PREFIX_NOT_TARGET_ABSENCE\": " << bool_text(report.advertised_prefix_not_target_absence) << ",\n"
                << "    \"END_MARK_WITHOUT_TARGET_FLUSH\": " << bool_text(report.end_mark_without_target_flush) << ",\n"
                << "    \"STRUCTURAL_ACCEPTANCE_NOT_AUTHENTICITY\": " << bool_text(report.structural_acceptance_not_authenticity) << "\n"
                << "  },\n"
                << "  \"synthetic_fixtures\": true,\n"
                << "  \"dm_log_writes_capture\": false,\n"
                << "  \"authentic_acquisition\": false,\n"
                << "  \"physical_power_loss_claim\": false,\n"
                << "  \"authority_granted\": false\n"
                << "}\n";
        write_text(output / "summary.json", summary.str());
        return report;
    } catch (const std::exception& error) {
        report.detail = error.what();
        return report;
    }
}

}  // namespace slopos::e0::trace_intake
