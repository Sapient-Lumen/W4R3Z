#include "slopos/e0/fence/host.hpp"

#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>

namespace slopos::e0::fence::host {
namespace {

[[nodiscard]] std::string_view expected_before(const Cut cut) noexcept {
    switch (cut) {
        case Cut::initialized: return "EMPTY_STABLE";
        case Cut::c1_admitted: return "C1_INERT";
        case Cut::pending_retained: return "C1_PREPARED";
        case Cut::c2_readback:
        case Cut::selector_advanced:
        case Cut::floor_advanced:
        case Cut::confirmed_advanced:
        case Cut::pending_retired:
        case Cut::activation_consumed:
        case Cut::dispatch_entered: return "C2_UNCERTAIN";
        case Cut::exact_no_effect_result:
            return "C2_EXACT_NO_EFFECT_OBSERVED";
        case Cut::effect_observed: return "C2_EFFECT_OBSERVED";
        case Cut::c3_effect_completed: return "EFFECT_COMPLETED";
        case Cut::c4_effect_published: return "EFFECT_PUBLISHED";
    }
    return "UNKNOWN";
}
[[nodiscard]] std::string_view expected_after(const Cut cut) noexcept {
    switch (cut) {
        case Cut::initialized: return "EMPTY_STABLE";
        case Cut::c1_admitted: return "C1_INERT";
        case Cut::pending_retained: return "C1_PREPARED";
        case Cut::c2_readback:
        case Cut::selector_advanced:
        case Cut::floor_advanced:
        case Cut::confirmed_advanced:
        case Cut::pending_retired:
        case Cut::activation_consumed:
        case Cut::dispatch_entered: return "UNCERTAINTY_PUBLISHED";
        case Cut::exact_no_effect_result: return "NO_EFFECT_PUBLISHED";
        case Cut::effect_observed:
        case Cut::c3_effect_completed:
        case Cut::c4_effect_published: return "EFFECT_PUBLISHED";
    }
    return "UNKNOWN";
}

}  // namespace

CampaignReport run_campaign(const std::filesystem::path& supplied_root,
                            const std::filesystem::path& self) {
    (void)self;
    CampaignReport report{};
    const std::filesystem::path root =
        std::filesystem::absolute(supplied_root);
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    std::filesystem::create_directories(root / "cuts", ec);
    if (ec) {
        report.detail = "create campaign root: " + ec.message();
        return report;
    }
    std::ofstream table(root / "campaign.tsv",
                        std::ios::binary | std::ios::trunc);
    if (!table) {
        report.detail = "open campaign table";
        return report;
    }
    table << "cut\tcrash_class\trecovered_class\teffect_before"
             "\teffect_after\trecovery_created_effect\tstatus\n";

    for (const Cut cut : kCuts) {
        const std::filesystem::path cut_root = root / "cuts" / cut_name(cut);
        const std::filesystem::path crash = cut_root / "crash";
        const std::filesystem::path recovered = cut_root / "recovered";
        std::string detail;
        if (!materialize_cut(crash, cut, detail)) {
            report.detail = std::string(cut_name(cut)) + ": " + detail;
            return report;
        }
        const Classification before = classify(crash);
        ++report.classifications;
        if (!before.ok || before.label != expected_before(cut)) {
            report.detail = std::string(cut_name(cut))
                + ": unexpected pre-recovery class " + before.label
                + " detail=" + before.detail;
            return report;
        }
        std::filesystem::copy(crash, recovered,
            std::filesystem::copy_options::recursive, ec);
        if (ec) {
            report.detail = std::string(cut_name(cut))
                + ": copy specimen: " + ec.message();
            return report;
        }
        const RecoveryResult recovery = recover_without_first_effect(recovered);
        ++report.recoveries;
        ++report.classifications;
        if (recovery.created_first_effect) ++report.recovery_created_effects;
        if (!recovery.ok || recovery.after.label != expected_after(cut)) {
            report.detail = std::string(cut_name(cut))
                + ": unexpected recovery class " + recovery.after.label
                + " detail=" + recovery.detail;
            return report;
        }
        if (recovery.after.label == "UNCERTAINTY_PUBLISHED") {
            ++report.uncertainty_publications;
        } else if (recovery.after.label == "NO_EFFECT_PUBLISHED") {
            ++report.no_effect_publications;
        } else if (recovery.after.label == "EFFECT_PUBLISHED") {
            ++report.effect_publications;
        }
        table << cut_name(cut) << '\t' << before.label << '\t'
              << recovery.after.label << '\t'
              << (recovery.effect_before ? 1 : 0) << '\t'
              << (recovery.effect_after ? 1 : 0) << '\t'
              << (recovery.created_first_effect ? 1 : 0) << "\tPASS\n";
        ++report.cuts;
    }
    report.ok = table.good() && report.cuts == kCuts.size()
        && report.recovery_created_effects == 0U
        && report.uncertainty_publications == 7U
        && report.no_effect_publications == 1U
        && report.effect_publications == 3U;
    report.detail = report.ok
        ? "rooted process-cut campaign preserves uncertainty and first-effect fence"
        : "campaign accounting failure";
    return report;
}

}  // namespace slopos::e0::fence::host
