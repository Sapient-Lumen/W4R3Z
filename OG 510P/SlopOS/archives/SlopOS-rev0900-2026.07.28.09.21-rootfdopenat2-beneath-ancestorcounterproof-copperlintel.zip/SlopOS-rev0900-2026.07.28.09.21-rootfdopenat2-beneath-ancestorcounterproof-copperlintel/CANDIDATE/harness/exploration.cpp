#include "slopos/e0/fence/harness.hpp"

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <map>
#include <queue>
#include <sstream>
#include <string>
#include <vector>

namespace slopos::e0::fence {
namespace {

struct Parent final {
    std::size_t from{};
    Event event{Event::admit};
    bool present{};
};
struct Edge final {
    std::size_t from{};
    Event event{Event::admit};
    Outcome outcome{Outcome::rejected};
    std::size_t to{};
    bool effect{};
};

[[nodiscard]] bool same_result(const StepResult& a,
                               const StepResult& b) noexcept {
    return a.outcome == b.outcome && a.state == b.state
        && a.effect_emitted == b.effect_emitted;
}

[[nodiscard]] std::string json_escape(const std::string& value) {
    std::string out;
    out.reserve(value.size() + 16U);
    for (const char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: out += c; break;
        }
    }
    return out;
}

void fnv_update(std::uint64_t& h, const std::string& text) noexcept {
    for (const char raw : text) {
        const auto c = static_cast<unsigned char>(raw);
        h ^= static_cast<std::uint64_t>(c);
        h *= 1099511628211ULL;
    }
}

[[nodiscard]] std::string hex64(const std::uint64_t value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0') << std::setw(16) << value;
    return out.str();
}

}  // namespace

ExplorationReport explore(const std::string& certificate_path,
                          const std::string& relation_path) {
    ExplorationReport report{};
    const State initial = initial_state();
    if (!state_invariant(initial)) {
        report.detail = "initial invariant failed";
        return report;
    }

    std::map<State, std::size_t> ids;
    std::vector<State> states;
    std::vector<std::size_t> depth;
    std::vector<Parent> parents;
    std::queue<std::size_t> work;
    ids.emplace(initial, 0U);
    states.push_back(initial);
    depth.push_back(0U);
    parents.push_back(Parent{});
    work.push(0U);
    std::vector<Edge> edges;

    while (!work.empty()) {
        const std::size_t from = work.front();
        work.pop();
        const State before = states[from];
        report.maximum_depth = std::max(report.maximum_depth, depth[from]);
        if (before.recovered && before.durable == DurableKind::c2) {
            ++report.recovered_c2_states;
        }
        for (const Event event : kEvents) {
            const StepResult core = step_core(before, event);
            const StepResult model = step_model(before, event);
            ++report.differential_checks;
            if (!same_result(core, model)) {
                report.detail = "differential mismatch at "
                    + state_key(before) + " event="
                    + std::string(event_name(event));
                return report;
            }
            ++report.invariant_checks;
            if (!state_invariant(core.state)) {
                report.detail = "successor invariant failed at "
                    + state_key(before) + " event="
                    + std::string(event_name(event)) + " successor="
                    + state_key(core.state);
                return report;
            }
            if (core.outcome == Outcome::rejected
                && (core.state != before || core.effect_emitted)) {
                report.detail = "rejection changed state";
                return report;
            }
            std::size_t to = from;
            if (core.outcome == Outcome::applied) {
                ++report.applied_edges;
                const auto [it, inserted] = ids.emplace(core.state, states.size());
                to = it->second;
                if (inserted) {
                    states.push_back(core.state);
                    depth.push_back(depth[from] + 1U);
                    parents.push_back(Parent{from, event, true});
                    work.push(to);
                }
            } else {
                ++report.rejected_edges;
            }
            if (event == Event::restart && core.outcome == Outcome::applied) {
                ++report.restart_edges;
            }
            if (core.effect_emitted) {
                ++report.effect_edges;
                if (before.recovered) ++report.recovered_first_effect_edges;
            }
            if (event == Event::complete_no_effect
                && core.outcome == Outcome::applied) {
                ++report.exact_no_effect_completion_edges;
                if (before.dispatch == DispatchKnowledge::unknown) {
                    ++report.unknown_no_effect_completion_edges;
                }
            }
            if (event == Event::complete_uncertain
                && core.outcome == Outcome::applied) {
                ++report.uncertainty_completion_edges;
            }
            if (event == Event::advance_selector
                && core.outcome == Outcome::applied) {
                ++report.selector_advance_edges;
                if (before.recovered || before.reconcile_only) {
                    ++report.selector_advance_from_recovery;
                }
            }
            edges.push_back(Edge{from, event, core.outcome, to,
                                 core.effect_emitted});
        }
    }

    report.states = states.size();
    report.events_per_state = kEvents.size();
    report.transitions = edges.size();

    // Find the retained full-restoration duplicate witness.
    for (std::size_t id = 0; id < states.size(); ++id) {
        if (states[id].effect_count >= 2U) {
            report.duplicate_effect_with_floor_regression = true;
            std::vector<std::string> path;
            std::size_t cursor = id;
            while (parents[cursor].present) {
                path.emplace_back(event_name(parents[cursor].event));
                cursor = parents[cursor].from;
            }
            std::reverse(path.begin(), path.end());
            report.rollback_counterexample = "start";
            for (const auto& part : path) {
                report.rollback_counterexample += " -> " + part;
            }
            report.rollback_counterexample += " -> effects=2";
            break;
        }
    }

    // Search the same finite graph while excluding every edge that regresses
    // the observed external floor.  This is conditional evidence only.
    struct ProductNode final { std::size_t id; bool successor_seen; };
    std::vector<std::array<bool, 2U>> seen(states.size(), {false, false});
    std::queue<ProductNode> monotone;
    const bool initial_seen = states[0].floor == FloorKind::successor;
    seen[0][initial_seen ? 1U : 0U] = true;
    monotone.push(ProductNode{0U, initial_seen});
    while (!monotone.empty()) {
        const ProductNode node = monotone.front();
        monotone.pop();
        const std::size_t from = node.id;
        if (states[from].effect_count >= 2U) {
            report.duplicate_effect_under_floor_monotonicity = true;
            break;
        }
        const std::size_t base = from * kEvents.size();
        for (std::size_t i = 0; i < kEvents.size(); ++i) {
            const Edge& edge = edges[base + i];
            if (edge.outcome != Outcome::applied) continue;
            const bool next_is_successor =
                states[edge.to].floor == FloorKind::successor;
            if (node.successor_seen && !next_is_successor) continue;
            const bool next_seen = node.successor_seen || next_is_successor;
            const std::size_t lane = next_seen ? 1U : 0U;
            if (!seen[edge.to][lane]) {
                seen[edge.to][lane] = true;
                monotone.push(ProductNode{edge.to, next_seen});
            }
        }
    }

    std::uint64_t fnv = 1469598103934665603ULL;
    std::ofstream relation;
    if (!relation_path.empty()) {
        relation.open(relation_path, std::ios::binary | std::ios::trunc);
        if (!relation) {
            report.detail = "cannot open relation output";
            return report;
        }
        const std::string header =
            "from_id\tevent\toutcome\tto_id\teffect\tfrom_state\tto_state\n";
        relation << header;
        fnv_update(fnv, header);
    }
    for (const Edge& edge : edges) {
        const std::string line = std::to_string(edge.from) + "\t"
            + std::string(event_name(edge.event)) + "\t"
            + std::string(outcome_name(edge.outcome)) + "\t"
            + std::to_string(edge.to) + "\t"
            + (edge.effect ? "1" : "0") + "\t"
            + state_key(states[edge.from]) + "\t"
            + state_key(states[edge.to]) + "\n";
        fnv_update(fnv, line);
        if (relation) relation << line;
    }
    if (relation && !relation) {
        report.detail = "relation write failed";
        return report;
    }
    report.relation_fnv1a64 = hex64(fnv);

    report.ok = report.transitions == report.states * kEvents.size()
        && report.recovered_first_effect_edges == 0U
        && report.unknown_no_effect_completion_edges == 0U
        && report.uncertainty_completion_edges > 0U
        && report.exact_no_effect_completion_edges > 0U
        && report.duplicate_effect_with_floor_regression
        && !report.duplicate_effect_under_floor_monotonicity;
    report.detail = report.ok
        ? "saturated differential relation preserves uncertainty and recovery fence"
        : "required relation property missing";

    if (!certificate_path.empty()) {
        std::ofstream out(certificate_path,
                          std::ios::binary | std::ios::trunc);
        if (!out) {
            report.ok = false;
            report.detail = "cannot open certificate output";
            return report;
        }
        out << "{\n"
            << "  \"schema\": \"slopos.rev0879.crash-refinement.v1\",\n"
            << "  \"status\": \"" << (report.ok ? "PASS" : "FAIL") << "\",\n"
            << "  \"states\": " << report.states << ",\n"
            << "  \"transitions\": " << report.transitions << ",\n"
            << "  \"events_per_state\": " << report.events_per_state << ",\n"
            << "  \"maximum_depth\": " << report.maximum_depth << ",\n"
            << "  \"differential_checks\": " << report.differential_checks << ",\n"
            << "  \"invariant_checks\": " << report.invariant_checks << ",\n"
            << "  \"effect_edges\": " << report.effect_edges << ",\n"
            << "  \"recovered_first_effect_edges\": "
            << report.recovered_first_effect_edges << ",\n"
            << "  \"unknown_no_effect_completion_edges\": "
            << report.unknown_no_effect_completion_edges << ",\n"
            << "  \"uncertainty_completion_edges\": "
            << report.uncertainty_completion_edges << ",\n"
            << "  \"exact_no_effect_completion_edges\": "
            << report.exact_no_effect_completion_edges << ",\n"
            << "  \"rollback_counterexample\": \""
            << json_escape(report.rollback_counterexample) << "\",\n"
            << "  \"duplicate_under_floor_monotonicity\": "
            << (report.duplicate_effect_under_floor_monotonicity
                    ? "true" : "false") << ",\n"
            << "  \"relation_fnv1a64\": \""
            << report.relation_fnv1a64 << "\"\n"
            << "}\n";
        if (!out) {
            report.ok = false;
            report.detail = "certificate write failed";
        }
    }
    return report;
}

}  // namespace slopos::e0::fence
