#include "slopos/e0/fence/model.hpp"

namespace slopos::e0::fence {
namespace {

[[nodiscard]] StepResult reject(const State& s) noexcept {
    return StepResult{Outcome::rejected, s, false};
}
[[nodiscard]] StepResult accept(const State& s,
                                const bool effect = false) noexcept {
    return StepResult{Outcome::applied, s, effect};
}
[[nodiscard]] bool clear(const State& s) noexcept {
    return !s.pending_activation && !s.dispatch_permit;
}
[[nodiscard]] bool pred_stable(const State& s) noexcept {
    return !s.selector_successor && !s.confirmed_successor
        && s.pending == PendingKind::absent
        && s.floor == FloorKind::predecessor;
}
[[nodiscard]] bool prepared(const State& s) noexcept {
    return !s.selector_successor && !s.confirmed_successor
        && s.pending == PendingKind::exact
        && s.floor == FloorKind::predecessor;
}
[[nodiscard]] bool selector_waits_floor(const State& s) noexcept {
    return s.selector_successor && !s.confirmed_successor
        && s.pending == PendingKind::exact
        && s.floor == FloorKind::predecessor;
}
[[nodiscard]] bool floor_waits_confirmation(const State& s) noexcept {
    return s.selector_successor && !s.confirmed_successor
        && s.pending == PendingKind::exact
        && s.floor == FloorKind::successor;
}
[[nodiscard]] bool confirmation_waits_cleanup(const State& s) noexcept {
    return s.selector_successor && s.confirmed_successor
        && s.pending == PendingKind::exact
        && s.floor == FloorKind::successor;
}
[[nodiscard]] bool successor_stable(const State& s) noexcept {
    return s.selector_successor && s.confirmed_successor
        && s.pending == PendingKind::absent
        && s.floor == FloorKind::successor;
}
[[nodiscard]] bool terminal(const DurableKind d) noexcept {
    return d == DurableKind::c3_no_effect || d == DurableKind::c3_effect
        || d == DurableKind::c3_uncertain || d == DurableKind::c4_no_effect
        || d == DurableKind::c4_effect || d == DurableKind::c4_uncertain;
}

}  // namespace

StepResult step_model(const State& input, const Event e) noexcept {
    State s = input;

    if (e == Event::admit) {
        if (s.durable != DurableKind::empty || !pred_stable(s) || !clear(s)
            || s.current_effect_occurred) return reject(input);
        s.durable = DurableKind::c1;
        s.recovered = false;
        s.reconcile_only = false;
        s.dispatch = DispatchKnowledge::not_entered;
        return accept(s);
    }
    if (e == Event::prepare_exact || e == Event::prepare_wrong) {
        if (s.durable != DurableKind::c1 || !pred_stable(s) || !clear(s)) {
            return reject(input);
        }
        s.pending = e == Event::prepare_exact
            ? PendingKind::exact : PendingKind::wrong;
        return accept(s);
    }
    if (e == Event::plan_c2) {
        if (s.durable != DurableKind::c1 || !prepared(s) || !clear(s)) {
            return reject(input);
        }
        s.durable = DurableKind::c2;
        if (s.recovered) {
            s.dispatch = DispatchKnowledge::unknown;
            s.pending_activation = false;
            s.reconcile_only = true;
        } else {
            s.dispatch = DispatchKnowledge::not_entered;
            s.pending_activation = true;
        }
        return accept(s);
    }
    if (e == Event::advance_selector) {
        if (s.durable != DurableKind::c2 || !prepared(s)
            || s.dispatch_permit) return reject(input);
        s.selector_successor = true;
        return accept(s);
    }
    if (e == Event::advance_floor) {
        if (s.durable != DurableKind::c2 || !selector_waits_floor(s)
            || s.dispatch_permit) return reject(input);
        s.floor = FloorKind::successor;
        return accept(s);
    }
    if (e == Event::advance_confirmed) {
        if (s.durable != DurableKind::c2 || !floor_waits_confirmation(s)
            || s.dispatch_permit) return reject(input);
        s.confirmed_successor = true;
        return accept(s);
    }
    if (e == Event::retire_pending) {
        if (s.durable != DurableKind::c2 || !confirmation_waits_cleanup(s)
            || s.dispatch_permit) return reject(input);
        s.pending = PendingKind::absent;
        return accept(s);
    }
    if (e == Event::activate_exact || e == Event::activate_mismatch) {
        if (s.durable != DurableKind::c2 || !s.pending_activation
            || s.recovered || s.reconcile_only
            || s.dispatch != DispatchKnowledge::not_entered
            || !successor_stable(s)) return reject(input);
        s.pending_activation = false;
        if (e == Event::activate_exact) s.dispatch_permit = true;
        return accept(s);
    }
    if (e == Event::enter_dispatch_exact
        || e == Event::enter_dispatch_mismatch) {
        if (s.durable != DurableKind::c2 || !s.dispatch_permit
            || s.recovered || s.reconcile_only
            || s.dispatch != DispatchKnowledge::not_entered
            || !successor_stable(s)) return reject(input);
        s.dispatch_permit = false;
        if (e == Event::enter_dispatch_exact) {
            s.dispatch = DispatchKnowledge::unknown;
            s.reconcile_only = true;
        }
        return accept(s);
    }
    if (e == Event::return_no_effect) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown || s.recovered
            || s.current_effect_occurred || !clear(s)) return reject(input);
        s.dispatch = DispatchKnowledge::exact_no_effect;
        return accept(s);
    }
    if (e == Event::return_effect) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown || s.recovered
            || s.current_effect_occurred || s.effect_count >= 2U
            || !clear(s)) return reject(input);
        s.current_effect_occurred = true;
        ++s.effect_count;
        s.dispatch = DispatchKnowledge::exact_effect;
        return accept(s, true);
    }
    if (e == Event::return_malformed) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown || s.recovered
            || !clear(s)) return reject(input);
        s.reconcile_only = true;
        return accept(s);
    }
    if (e == Event::reconcile_no_effect) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown
            || (!s.recovered && !s.reconcile_only)
            || s.current_effect_occurred || !clear(s)) return reject(input);
        s.dispatch = DispatchKnowledge::exact_no_effect;
        return accept(s);
    }
    if (e == Event::reconcile_effect) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown
            || (!s.recovered && !s.reconcile_only)
            || !s.current_effect_occurred || !clear(s)) return reject(input);
        s.dispatch = DispatchKnowledge::exact_effect;
        return accept(s);
    }
    if (e == Event::reconcile_malformed) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown
            || (!s.recovered && !s.reconcile_only) || !clear(s)) {
            return reject(input);
        }
        s.reconcile_only = true;
        return accept(s);
    }
    if (e == Event::complete_no_effect) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::exact_no_effect
            || !successor_stable(s) || !clear(s)) return reject(input);
        s.durable = DurableKind::c3_no_effect;
        return accept(s);
    }
    if (e == Event::complete_effect) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::exact_effect
            || !successor_stable(s) || !clear(s)) return reject(input);
        s.durable = DurableKind::c3_effect;
        return accept(s);
    }
    if (e == Event::complete_uncertain) {
        if (s.durable != DurableKind::c2
            || s.dispatch != DispatchKnowledge::unknown
            || !successor_stable(s) || !clear(s)) return reject(input);
        s.durable = DurableKind::c3_uncertain;
        s.reconcile_only = true;
        return accept(s);
    }
    if (e == Event::publish_no_effect) {
        if (s.durable != DurableKind::c3_no_effect || !clear(s)) {
            return reject(input);
        }
        s.durable = DurableKind::c4_no_effect;
        return accept(s);
    }
    if (e == Event::publish_effect) {
        if (s.durable != DurableKind::c3_effect || !clear(s)) {
            return reject(input);
        }
        s.durable = DurableKind::c4_effect;
        return accept(s);
    }
    if (e == Event::publish_uncertain) {
        if (s.durable != DurableKind::c3_uncertain || !clear(s)) {
            return reject(input);
        }
        s.durable = DurableKind::c4_uncertain;
        return accept(s);
    }
    if (e == Event::restart) {
        s.pending_activation = false;
        s.dispatch_permit = false;
        s.recovered = true;
        if (s.durable == DurableKind::c2) {
            s.dispatch = DispatchKnowledge::unknown;
            s.reconcile_only = true;
        } else if (s.durable == DurableKind::c1) {
            s.reconcile_only = true;
        }
        return accept(s);
    }
    if (e == Event::observe_floor_predecessor
        || e == Event::observe_floor_successor
        || e == Event::observe_floor_unavailable
        || e == Event::observe_floor_malformed
        || e == Event::observe_floor_wrong_identity) {
        if (!clear(s)) return reject(input);
        if (e == Event::observe_floor_predecessor) {
            s.floor = FloorKind::predecessor;
        } else if (e == Event::observe_floor_successor) {
            s.floor = FloorKind::successor;
        } else if (e == Event::observe_floor_unavailable) {
            s.floor = FloorKind::unavailable;
        } else if (e == Event::observe_floor_malformed) {
            s.floor = FloorKind::malformed;
        } else {
            s.floor = FloorKind::wrong_identity;
        }
        return accept(s);
    }
    if (e == Event::rollback_local_keep_floor) {
        if (!terminal(s.durable) || s.effect_count == 0U) return reject(input);
        s.durable = DurableKind::c1;
        s.selector_successor = false;
        s.confirmed_successor = false;
        s.pending = PendingKind::exact;
        s.pending_activation = false;
        s.dispatch_permit = false;
        s.recovered = true;
        s.reconcile_only = true;
        s.dispatch = DispatchKnowledge::not_entered;
        s.current_effect_occurred = true;
        return accept(s);
    }
    if (e == Event::rollback_local_and_floor) {
        if (!terminal(s.durable) || s.effect_count == 0U) return reject(input);
        s.durable = DurableKind::c1;
        s.selector_successor = false;
        s.confirmed_successor = false;
        s.pending = PendingKind::exact;
        s.floor = FloorKind::predecessor;
        s.pending_activation = false;
        s.dispatch_permit = false;
        s.recovered = false;
        s.reconcile_only = false;
        s.dispatch = DispatchKnowledge::not_entered;
        s.current_effect_occurred = false;
        return accept(s);
    }
    if (e == Event::rollback_c2_keep_floor) {
        if (!terminal(s.durable) || s.effect_count == 0U) return reject(input);
        s.durable = DurableKind::c2;
        s.selector_successor = true;
        s.confirmed_successor = true;
        s.pending = PendingKind::absent;
        s.pending_activation = false;
        s.dispatch_permit = false;
        s.recovered = true;
        s.reconcile_only = true;
        s.dispatch = DispatchKnowledge::unknown;
        s.current_effect_occurred = true;
        return accept(s);
    }
    return reject(input);
}

}  // namespace slopos::e0::fence
