# Recovery fence

The recovery fence is the authority boundary between completing known durable
installation work and creating a first selected effect.

On restart:

- activation continuation is erased;
- dispatch permit is erased;
- C1 and C2 become reconciliation-only;
- C2 outcome knowledge is widened to unknown;
- no recovery transition recreates activation or dispatch authority.

A live process that already entered dispatch may still receive an exact return.
That is not a second dispatch. The relation therefore permits `return-effect`
or `return-no-effect` after the permit has already been consumed, but rejects
all new activation and dispatch-entry edges from recovered state.

Recovery may:

- finish successor installation when exact representations permit;
- appraise exact endpoint or effect evidence;
- complete and publish `EFFECT`, `NO_EFFECT`, or `UNCERTAIN`;
- refuse malformed or contradictory images.

Recovery may not:

- infer no-effect from absence;
- mint a pending activation continuation;
- mint a dispatch permit;
- emit the first selected effect;
- turn a restorable floor into rollback authority by description.
