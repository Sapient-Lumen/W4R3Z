# Trace subject closure

A structurally valid log is only a byte object. Before a native trace can be used
as evidence, one exact acquisition subject must close at least the following
joins.

## Required packet

1. Packet schema and canonicalization version.
2. Constituted operator role and run authorization.
3. Kernel source/build identity, command line, boot identity, modules, and
   relevant configuration.
4. Exact `dm-log-writes` implementation and userspace producer/replayer
   identities.
5. Source device, target device, log device, complete block graph, logical and
   physical sector sizes, queue capabilities, cache declarations, and FUA/flush
   behavior.
6. Filesystem type/version/features, mkfs record, mount namespace, mount options,
   and superblock identity.
7. Complete writer set, capability set, namespace ownership, descriptor
   inheritance policy, and hostile-writer exclusions.
8. Exact workload executable, inputs, schemas, operation identity, and start
   image.
9. Every mark request and return, target creation/removal record, unmount/close
   record, export range, exact exported bytes, and digest algorithm/domain.
10. Native-to-normalized event mapping version, replay command, replayed image
    identities, and two reopener results.
11. Retention, privacy, redaction, failure, retry, and compromise disposition.

## Evidence ladder

```text
STRUCTURALLY_VALID
  -> DETERMINISTICALLY_REPLAYED
  -> EXPORT_CLOSED
  -> CAPTURE_BOUND
  -> MACHINE_BOUND
  -> DESTRUCTIVELY_OBSERVED
  -> AUTHORITY_ADMISSIBLE
```

Rev0881 reaches only the first two rungs, and only for synthetic fixtures. No
higher rung is inferred from a valid format, an end mark, a replay result, root
inside this cloudtainer, or agreement between same-actor implementations.

## Closure rule

A missing field, ambiguous field, stale environment projection, nonexact tool
identity, unclosed writer set, or unexplained bytes after the advertised export
range yields `INCOMPLETE` or `FAIL_STOP`. It never yields acquisition or
machine-bound authority by default.
