# Checked invariants

## Inherited authority relation

- recovery never creates a first selected effect;
- a dispatch permit is consumed before effect emission;
- `UNKNOWN` never completes as `NO_EFFECT`;
- exact effect/no-effect completion requires matching evidence;
- reconciliation never emits the first selected effect;
- complete local-plus-floor rollback duplicate remains reachable;
- conditional successor-floor monotonicity blocks that duplicate only in the
  explored finite relation.

## Rev0880 logical crash profile

- `MARK` leaves stable and pending images unchanged;
- every generated image is exactly 3072 bytes and content-addressed once;
- two C++ reopeners agree semantically on every generated image;
- Python independently reconstructs every trace, cut, pending set, survival
  mask, image and classification;
- C1 and C2 plus absent result never classify `NO_EFFECT`;
- local C3/C4 effect or no-effect without a matching exact result fails stop;
- good effect and no-effect traces reach exact terminal classifications;
- the three named counterexamples remain present.

All invariants are bounded by the declared state, trace and logical persistence
domains.
