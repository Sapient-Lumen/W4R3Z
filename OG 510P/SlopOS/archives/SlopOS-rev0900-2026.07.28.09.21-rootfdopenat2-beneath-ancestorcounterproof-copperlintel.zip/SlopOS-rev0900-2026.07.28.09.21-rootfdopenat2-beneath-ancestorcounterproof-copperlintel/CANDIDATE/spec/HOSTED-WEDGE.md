# Hosted wedge

The hosted wedge materializes fourteen named process cuts around one harmless
file effect. Each crash tree is classified, copied, reopened, and reconciled by
another invocation. A Python reopener independently classifies the retained
bytes.

Seven C2 specimens that lack exact endpoint evidence close as
`UNCERTAINTY_PUBLISHED`. One exact no-effect specimen closes as
`NO_EFFECT_PUBLISHED`. Three effect-bearing specimens close as
`EFFECT_PUBLISHED`. Recovery creates no absent effect.

The hosted floor and endpoint result are ordinary files. They are test doubles,
not protected providers. The campaign injects process boundaries, not power
loss, torn writes, device-cache loss, block reordering, hostile concurrent
writers, mount replacement, or complete-image rollback.

The wedge is useful because it makes the result trilemma executable and because
it preserves the distinction between:

- selected effect;
- evidence that the effect occurred;
- exact endpoint result;
- terminal publication.
