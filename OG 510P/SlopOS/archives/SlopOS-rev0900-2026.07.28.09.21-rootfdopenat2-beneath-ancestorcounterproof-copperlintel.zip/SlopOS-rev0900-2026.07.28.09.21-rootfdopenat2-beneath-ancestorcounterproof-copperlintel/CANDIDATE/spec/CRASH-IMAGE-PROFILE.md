# Bounded logical crash-image profile v1

## Image grammar

The image is exactly 3072 bytes, divided into six 512-byte blocks:

| Block | Meaning |
|---:|---|
| 0 | exact profile header and operation binding |
| 1–2 | exact sealed rev0874 two-slot durable-cut journal |
| 3 | predecessor or successor floor test double |
| 4 | selected endpoint-effect test marker |
| 5 | exact endpoint-result test record |

Any unrecognized block value or incoherent cross-block join is `FAIL_STOP`.

## Operation grammar

```text
WRITE(domain, block, bytes)
FLUSH(domain)
MARK(label)
```

Domains are `LOCAL`, `FLOOR`, and `ENDPOINT`. A write enters that domain's
pending sequence. At a crash before the corresponding flush, any subset of the
pending writes may survive; when multiple surviving writes target one block,
the last selected write wins. A flush atomically moves all pending writes in
that domain into the model's stable image. A mark changes no image state.

This is a finite over-approximation chosen for proof and oracle construction.
It assumes 512-byte block atomicity, exact known block values, three independent
flush domains, no media corruption, and no behavior outside the enumerated
write grammar. It does not model filesystem allocation, journal transactions,
writeback error propagation, device cache dishonesty, torn sectors, controller
reordering, DMA, firmware, or electrical interruption.

## Reopeners

- `classify_with_sealed_recovery` invokes exact sealed rev0874 journal recovery,
  then joins floor, effect and result blocks.
- `classify_with_exact_map` maps each journal slot independently to exact known
  records and checks adjacent-generation successor semantics without importing
  the first reopener.
- `verify_crash_images.py` independently reconstructs the traces, pending sets,
  survival masks, images, local mapping and terminal classification.

The two C++ reopeners and Python checker remain same-actor, shared-protocol
assurance. They are not an independent stewardship lane.
