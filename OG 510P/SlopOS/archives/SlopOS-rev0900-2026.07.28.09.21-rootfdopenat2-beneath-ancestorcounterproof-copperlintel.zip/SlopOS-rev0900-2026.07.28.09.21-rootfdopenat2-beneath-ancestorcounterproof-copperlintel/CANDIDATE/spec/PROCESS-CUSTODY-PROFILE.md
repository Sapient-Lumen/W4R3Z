# Hosted process-lifetime and initial-exec profile

Rev0883 constructs one narrow hosted profile. It is not a process-custody
provider and it grants no effect authority.

## Positive observation

For each accepted live case, one supervisor process:

1. enters a dedicated nonroot `65534:65534` credential and zero-capability floor;
2. creates a child with `clone3(CLONE_PIDFD)`;
3. retains the returned pidfd and report socket;
4. normalizes descriptors 0, 1 and 2 to controlled `/dev/null` endpoints;
5. closes every undeclared descriptor;
6. sets `PR_SET_PDEATHSIG(SIGKILL)` and preserves `no_new_privs`;
7. selects the initial ELF object through `execveat(execfd, "", ..., AT_EMPTY_PATH)`;
8. joins the child report to the live `/proc/<pid>/exe`, start-time, credentials,
   capabilities and descriptor observations while the child is stopped on an
   explicit acknowledgement boundary; and
9. consumes terminal status with `waitid(P_PIDFD)`.

The bounded positive result is:

```text
HOSTED_LAUNCH_CLOSED_CANDIDATE
```

It means the selected host process observed one initial launch under the
specified profile. It does not mean the executable can never change, the
provider is authenticated, the process is protected from a same-host adversary,
or the child owns any effect authority.

## Identity coordinates

The profile keeps these identities separate:

```text
numeric PID
process lifetime / pidfd
process start time
initial executable descriptor
live executable image
executable epoch
credential and capability floor
report channel
provider identity
```

A pidfd is a lifetime handle. It is not an executable-epoch handle. The same
pidfd and start time may span worker A and worker B after `execveat`.

## Fail-closed cases

An undeclared descriptor or a report/executable mismatch yields `FAIL_CLOSED`.
No local repair, report rewrite, or publication step converts either result into
custody.

## Mandatory nonclaims

- `executable_continuity_bound=false`
- `process_custody_results=0`
- `provider_authenticated_results=0`
- `authority_bearing_results=0`
- `independent_actor=false`
- `deployment_profile=false`
