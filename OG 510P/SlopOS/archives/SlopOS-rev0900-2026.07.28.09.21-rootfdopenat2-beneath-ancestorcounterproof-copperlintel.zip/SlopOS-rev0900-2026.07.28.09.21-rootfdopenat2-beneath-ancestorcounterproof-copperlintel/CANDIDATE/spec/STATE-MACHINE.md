# State machine

## Durable journal classes

```text
EMPTY
C1                       admitted, inert
C2                       selected operation retained; outcome not yet located
C3_NO_EFFECT             exact no-effect appraisal completed
C3_EFFECT                exact effect appraisal completed
C3_UNCERTAIN             outcome could not be located
C4_NO_EFFECT             no-effect result published
C4_EFFECT                effect result published
C4_UNCERTAIN             uncertainty published
```

C2 is deliberately nonterminal. It does not encode whether dispatch was never
entered, entered and returned, entered and lost its return, or produced an
effect whose local observation was lost.

## Ephemeral authority

`pending_activation` exists only in one live process after exact planning.
Exact C2 readback consumes it and may produce one `dispatch_permit`. Every
activation attempt consumes the pending continuation. Every dispatch-entry
attempt consumes the permit before the endpoint is entered. Restart clears
both fields.

## Outcome knowledge

```text
NOT_ENTERED
UNKNOWN
EXACT_NO_EFFECT
EXACT_EFFECT
```

A cold reopen of any C2 state widens local knowledge to `UNKNOWN`. This is true
even when the materializing process knew that its named cut preceded dispatch;
that process-local history is not present in the retained C2 image.

Only an exact return or exact reconciliation result may change `UNKNOWN` to an
exact outcome. Malformed, absent, unavailable, or contradictory result evidence
preserves uncertainty.

## Installation and selected effect

Successor installation has its own ordered representations:

```text
pending transition
  -> successor selector
  -> successor external floor
  -> successor confirmation
  -> pending retirement
```

Recovery may finish those installation steps. They are not the selected effect.
The later selected effect requires a still-live, nonrecovered activation
continuation and one consumed permit.

## Terminal rule

```text
UNKNOWN         -> C3_UNCERTAIN -> C4_UNCERTAIN
EXACT_NO_EFFECT -> C3_NO_EFFECT -> C4_NO_EFFECT
EXACT_EFFECT    -> C3_EFFECT    -> C4_EFFECT
```

There is no `UNKNOWN -> C3_NO_EFFECT` edge.
