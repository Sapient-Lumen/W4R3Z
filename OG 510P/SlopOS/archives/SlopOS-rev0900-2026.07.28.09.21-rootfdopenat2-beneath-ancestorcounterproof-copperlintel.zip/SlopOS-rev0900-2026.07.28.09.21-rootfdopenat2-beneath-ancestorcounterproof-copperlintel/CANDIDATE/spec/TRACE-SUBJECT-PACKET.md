# Trace-subject packet v1

## Purpose

The packet binds exact acquisition declarations, lifecycle observations, trace
bytes and deterministic replay products without allowing the packet to assert
its own trust. It is an evidence-envelope protocol, not an acquisition provider,
attestation format, authorization policy or effect capability.

The packet has five separate inputs:

```text
proposal bytes
witness bytes
receipt bytes
trace bytes
baseline bytes
```

No filename, directory location or archive proximity participates in packet
identity. Every join is over exact retained bytes or a declared scalar.

## Canonical record grammar

Proposal, Witness and Receipt are UTF-8-compatible ASCII TSV records. Each line
contains exactly one field name, one horizontal tab and one nonempty value. The
field order is fixed. Records end with one LF. CR, NUL, duplicate fields,
unknown fields, reordered fields, empty values and noncanonical integers are
rejected.

Canonical atoms contain printable ASCII, exclude tab and backslash, and are at
most 256 bytes. Booleans are exactly `0` or `1`. Unsigned integers have no sign
or leading zero. Signed integers have no plus sign, negative zero or redundant
leading zero. SHA-256 values are exactly 64 lowercase hexadecimal characters.

## Proposal fields

```text
schema
run_id
operation_sha256
capture_profile
sector_size
baseline_bytes
baseline_sha256
workload_image_sha256
workload_inputs_sha256
target_device_sha256
log_device_sha256
block_graph_sha256
writer_policy_sha256
export_offset_bytes
export_length_bytes
trace_schema
```

The Proposal declares the exact operation and acquisition subject expected by
the consumer. It is not evidence that the declared subject existed.

## Witness fields

```text
schema
run_id
authorization_id
challenge_id
machine_sha256
boot_id
kernel_sha256
supervisor_image_sha256
supervisor_instance_sha256
supervisor_pid
pidfd_bound
mount_namespace
user_namespace
pid_namespace
preclean_observed
target_created_once
workload_launched_once
workload_exit_observed
workload_exit_code
stdout_sha256
stderr_sha256
target_remove_status
export_read_observed
writer_closure_observed
direct_aliases_closed
log_aliases_closed
process_restarted
complete
```

These are observations attributed to a provider. They do not authenticate that
provider. In particular, a numeric PID and a packet Boolean called
`pidfd_bound` are not process-instance custody. The native provider must make
that relation externally observable and independently appraisable.

## Receipt fields and acyclic identity

```text
schema
run_id
proposal_sha256
witness_sha256
trace_sha256
trace_bytes
normalized_sha256
replay_manifest_sha256
export_close_state
publication_id
subject_sha256
```

`subject_sha256` is SHA-256 over the canonical Receipt fields preceding
`subject_sha256`. It is deliberately acyclic. Proposal, Witness and trace bytes
are joined through their separate SHA-256 fields. The baseline is joined through
the Proposal. Publication identity is inside the subject, but publication does
not promote the evidence rung.

## Validation order

The constrained validator performs these cuts in order:

1. Parse all three records under the strict grammar.
2. Parse them again under a separately structured reference parser and require
   exact record equality.
3. Join all `run_id` values.
4. Reject identical declared target and log device identities.
5. Join baseline size and SHA-256.
6. Join exported trace length and Receipt trace length.
7. Join Proposal, Witness and trace byte identities through the Receipt.
8. Recompute the acyclic Receipt subject digest.
9. Parse the trace through the rev0881 strict and reference parsers.
10. Recompute normalized-event and replay-manifest bytes and join their digests.
11. Require uninterrupted lifecycle observations, exact target removal and
    export-read closure.
12. Require declared writer, direct-alias and log-alias closure.
13. Consult a separately supplied `ValidationContext` for any capture-bound
    promotion.

Rejected packets return no retained evidence rung in this hosted interface. A
future typed API may retain a diagnostic partial rung, but it must not make a
failed packet consumable as accepted evidence.

## Evidence rungs

```text
NONE
STRUCTURALLY_VALID
DETERMINISTICALLY_REPLAYED
EXPORT_CLOSED_CANDIDATE
CAPTURE_BOUND
```

The packet bytes alone can reach at most `EXPORT_CLOSED_CANDIDATE`.
`CAPTURE_BOUND` additionally requires all of the following from the external
validation context:

```text
provider_authenticated
machine_binding_verified
supervisor_process_custody_verified
exclusive_writer_verified
fixture_only == false
```

The packet has no fields that can nominate these values. The hosted campaign
supplies a fixture-only context and therefore produces zero capture-bound
results.

## Failure codes

```text
MALFORMED_RECORD
NONCANONICAL_RECORD
FIELD_INVALID
JOIN_MISMATCH
BASELINE_MISMATCH
TRACE_REJECTED
REPLAY_MISMATCH
SUPERVISOR_CUSTODY_INCOMPLETE
EXPORT_NOT_CLOSED
WRITER_CUSTODY_INCOMPLETE
```

Failure is inert. It never creates retry, compensation, publication, approval or
effect authority.

## Digest contract

SHA-256 is the packet custody identity. The hosted implementation includes
known-answer checks for the empty string and `abc`. This is an implementation
observation, not a proof of the hash implementation, compiler or hardware.
Every digest domain is fixed by its containing field and canonical schema.

## Mandatory nonclaims

Packet acceptance does not prove native acquisition, provider identity, machine
identity, boot identity, PID continuity, namespace ownership, exclusive writer
closure, absence of aliases, completeness of the exported log, physical target
durability, power-loss behavior or control authority. Even an externally
capture-bound packet remains neutral evidence for a separately governed
appraisal and relying-party policy.
