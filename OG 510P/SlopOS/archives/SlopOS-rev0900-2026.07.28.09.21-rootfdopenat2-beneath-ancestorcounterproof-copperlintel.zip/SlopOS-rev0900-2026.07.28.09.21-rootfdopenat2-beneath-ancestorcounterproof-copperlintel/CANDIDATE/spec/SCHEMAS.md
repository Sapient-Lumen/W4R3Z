# Retained candidate schemas

## Inherited outputs

- `slopos.rev0879.crash-refinement.v1`
- `slopos.rev0879.observation-ambiguity.v1`
- `slopos.rev0880.crash-image-summary.v1`
- `slopos.rev0880.crash-image-audit.v1`
- `slopos.rev0881.dm-log-writes-summary.v1`
- `slopos.rev0881.dm-log-writes-audit.v1`

## Rev0882 packet records

- `slopos.trace-subject.proposal.v1`
- `slopos.trace-subject.witness.v1`
- `slopos.trace-subject.receipt.v1`
- strict trace schema `linux.dm-log-writes.v1.strict-subset`

## Rev0882 campaign outputs

- `slopos.rev0882.trace-subject-campaign.v1`
- `slopos.rev0882.trace-subject-audit.v1`
- `slopos.rev0882.cxx20-summary.v1`

Canonical field order and digest domains are specified in
`TRACE-SUBJECT-PACKET.md`. Packet records never serialize authoritative provider
trust or effect permission.


## Rev0883 process-lifetime outputs

- `slopos.process-report.v1`
- `slopos.rev0883.process-custody-campaign.v1`
- `slopos.rev0883.process-custody-audit.v1`
- `slopos.rev0883.cxx20-summary.v1`

The report is an untrusted join input. It contains no provider trust, process
custody, appraisal, policy or effect-authority field.
