# Cold-image observation law

A cold image is an observation of durable bytes, not a unique execution history.
Let `observe(history)` return the reopened image. The rev0880 campaign retains:

```text
observe(initial-before-dispatch)
  = observe(effect ; full local+floor+endpoint rollback)
```

The common image contains C1, predecessor floor, absent endpoint marker and
absent endpoint result. The image-only oracle returns `UNCERTAIN`.

A live uninterrupted process may know that no dispatch has occurred because it
retains process-local authority history. After restart, that provenance is gone
unless it was carried by a protected, nonrestorable and independently joined
provider. C1 bytes alone therefore do not prove no-effect.

This is a non-identifiability result: when two admissible histories with
different effect facts map to the same observation, no deterministic classifier
of that observation alone can soundly distinguish them. More parser agreement
cannot recover information erased by the observation function.
