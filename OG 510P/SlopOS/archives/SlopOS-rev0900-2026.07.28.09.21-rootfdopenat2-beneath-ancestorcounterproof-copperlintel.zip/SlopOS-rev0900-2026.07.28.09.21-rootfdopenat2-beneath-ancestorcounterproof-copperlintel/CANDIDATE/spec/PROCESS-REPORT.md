# Canonical process report v1

Schema: `slopos.process-report.v1`

The record is UTF-8-compatible printable ASCII, tab-separated, newline
terminated and emitted in exactly this field order:

```text
schema
phase
executable_id
pid
ppid
uid
gid
no_new_privs
cap_inheritable_zero
cap_permitted_zero
cap_effective_zero
cap_bounding_zero
cap_ambient_zero
fd0_normalized
fd1_normalized
fd2_normalized
report_fd_present
next_exec_fd_present
unexpected_fd_count
```

Integers are minimal unsigned decimal. Booleans are `0` or `1`. Unknown,
duplicate, reordered, missing and noncanonical fields are rejected.

The report is an untrusted statement. Acceptance only allows the supervisor to
attempt live joins. It is never a provider credential, attestation result,
relying-party decision or effect permit.
