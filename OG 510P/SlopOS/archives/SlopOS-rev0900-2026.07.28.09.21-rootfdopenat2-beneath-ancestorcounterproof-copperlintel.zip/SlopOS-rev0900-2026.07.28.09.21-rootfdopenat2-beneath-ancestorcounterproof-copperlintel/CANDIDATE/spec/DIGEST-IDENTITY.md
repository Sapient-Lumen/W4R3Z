# Digest identity and domain

A digest string is not a complete identity. Every digest-bearing field must bind:

```text
algorithm identifier
algorithm parameters or version
input encoding
canonicalization rule
domain separator / object type
exact byte length
digest bytes
```

Rev0881 uses `fnv1a64-standard-offset-basis` only for compact diagnostic tables.
It is noncryptographic and cannot satisfy content custody, adversarial collision
resistance, signatures, or release identity. SHA-256 remains the checkpoint
content-custody algorithm.

Inherited rev0879/rev0880 evidence is not silently rewritten: one inherited lane
and another lane used different FNV-1a offset bases while both labels omitted the
variant. The incident is preserved, and new evidence names the exact algorithm.
