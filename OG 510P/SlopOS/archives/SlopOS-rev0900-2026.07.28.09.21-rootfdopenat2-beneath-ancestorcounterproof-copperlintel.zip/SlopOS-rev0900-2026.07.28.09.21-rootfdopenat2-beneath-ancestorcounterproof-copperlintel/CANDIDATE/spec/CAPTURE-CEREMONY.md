# Capture ceremony v1

## Purpose

The ceremony models the minimum control-plane ordering needed to construct an
export-closed candidate. It is a bounded state machine, not a native supervisor
and not a theorem about Linux process, namespace, block-device or storage
semantics.

## Phases

```text
IDLE
AUTHORIZED
NAMESPACE_CLOSED
DEVICES_BOUND
TARGET_ACTIVE
WORKLOAD_RUNNING
WORKLOAD_TERMINAL
TARGET_REMOVED
EXPORT_READ
EXPORT_CLOSED
PUBLISHED
FAILED
INCOMPLETE
```

The happy path is linear:

```text
authorize
  -> close namespace
  -> bind devices
  -> create target and consume authorization
  -> launch workload
  -> observe terminal workload status
  -> remove target exactly
  -> read declared export
  -> close export subject
  -> publish without promotion
```

## State resources

The model tracks five resources:

```text
authorization_live
run_identity_live
target_live
export_closed
published
```

Authorization is consumed when the target becomes active. Run identity becomes
live at that cut. Export closure is impossible while the target is live.
Publication requires an already closed export and does not alter the evidence
rung.

## Failure and incompleteness

`MISMATCH` moves any nonterminal run to `FAILED` and erases authorization, run
identity, target liveness, export closure and publication state.

`HIDDEN_WRITER` is rejected in `IDLE`; after authorization it moves the ceremony
to `FAILED`. The model does not allow a declared hidden writer to coexist with
export closure.

`REMOVE_TARGET_UNKNOWN` from `WORKLOAD_TERMINAL` moves to `INCOMPLETE`. It cannot
be reinterpreted as successful removal or export closure.

`RESTART` is a stutter only in `IDLE`, `EXPORT_CLOSED` and `PUBLISHED`. From every
active intermediate phase it moves to `INCOMPLETE` and erases live run identity.
The restarted process receives no authority to resume the original ceremony by
assertion.

## Saturated hosted relation

The campaign explores every one of fifteen events from every reachable state.
The resulting relation contains 13 reachable states and 195 edges: 41 applied
and 154 preserving rejections. The constrained and reference implementations
agree on every edge, and all 208 source/successor invariant checks pass.

The retained negative results are:

```text
restart after activation closes export: false
unknown target removal closes export:   false
hidden writer can export:                false
publication promotes capture:            false
```

## Native-provider obligations not modeled

A real supervisor must additionally establish constituted run authorization,
atomic process-instance acquisition, executable continuity, mount/user/PID
namespace creation and custody, capability and privilege floors, complete block
graph and device identities, target-table lifetime, writer and alias closure,
workload input/output custody, exact target removal, export-range closure,
receipt publication, recovery, cancellation and compromise handling.

The model intentionally has no transition from packet publication to effect
permission.
