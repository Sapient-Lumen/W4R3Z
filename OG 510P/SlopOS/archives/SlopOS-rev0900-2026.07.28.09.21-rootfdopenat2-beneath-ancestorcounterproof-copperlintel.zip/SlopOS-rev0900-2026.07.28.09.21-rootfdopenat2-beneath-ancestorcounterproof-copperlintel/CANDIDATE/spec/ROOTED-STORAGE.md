# Rooted Linux storage profile

The hosted adapter captures one absolute root with `openat2`, rejects symbolic
and magic links across that path walk, opens six fixed child directories beneath
the retained root descriptor, and retains every directory descriptor and
`st_dev`/`st_ino` identity for the transaction lifetime.

All later operations are against fixed child directory descriptors and validated
single-component leaf names. The adapter never reopens a caller-supplied root or
child path after capture.

Mutable replacement:

```text
exclusive temporary regular file
  -> complete write
  -> file fsync
  -> renameat2 replacement
  -> containing-directory fsync
  -> exact descriptor-relative readback
```

Immutable publication uses `RENAME_NOREPLACE`. An exact incumbent is accepted
only after exact byte comparison; a different incumbent is a conflict.

The adversarial campaign checks root, ancestor, fixed-child, final-component,
and magic-link rejection; `..`, slash, and absolute-leaf rejection; root and
child path rebinding after descriptor capture; no-replace incumbent behavior;
and retained directory identities.

This is a hosted profile observation, not a theorem about every Linux kernel,
filesystem, mount namespace, device, or concurrent-writer environment. It also
does not prevent an actor with stronger namespace or descriptor authority from
mutating the captured directories.
