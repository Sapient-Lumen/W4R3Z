# Strict dm-log-writes v1 intake profile

## Status

This is a laboratory intake and deterministic replay profile for **synthetic**
fixtures. It is not a trace-acquisition provider, machine receipt, durability
certificate, rollback floor, endpoint result, or authority source.

The profile accepts a deliberately small, closed subset of the Linux
`dm-log-writes` v1 userspace format. Strictness is intentional: an unrecognized
entry is rejected rather than interpreted generously.

## Admitted representation

- Magic: `0x006a736677736872`.
- Format version: `1`.
- Sector size: exactly 512, 1024, 2048, or 4096 bytes.
- The superblock occupies one declared sector; bytes after the fixed fields are
  zero.
- Every entry header occupies one declared sector; unused header bytes are zero.
- Admitted event kinds are plain write, FUA write, flush, and printable ASCII
  mark.
- Write data is whole-sector, in range of the declared baseline, and follows its
  header immediately.
- A mark has nonempty printable ASCII data and zero padding.
- The exact terminal mark `dm-log-writes-end` is recognized as a capture-end
  observation.

## Rejected representation

The intake rejects truncation, trailing bytes, unknown flags, discard,
zero-length writes, out-of-range writes, malformed marks, unsupported sector
sizes, and combined preflush-plus-write entries. Rejecting the combined case is
not a claim that the kernel cannot receive it; it means this profile refuses to
invent an ordering rule before the native-to-normalized mapping is frozen.

## Replay semantics

Plain and FUA writes update the declared baseline image. Flushes and marks are
replay stutters: they delimit or describe order but do not themselves modify
image bytes. Consequently:

- a mark is not a target-device flush;
- the end mark is not a target-device flush;
- an end mark does not establish that the advertised byte prefix is the last
  target-side event;
- an accepted log does not establish who produced it, on which machine, under
  which kernel, or with which writer custody;
- equal final images do not establish equal traces.

## Source separation

`parse_strict` and `parse_reference` are separately structured C++20 parsers.
The campaign requires exact agreement over seven accepted and eighteen rejected
fixtures. A separately written Python consumer reconstructs all accepted events,
replay prefixes, image identities, and five negative witnesses without importing
either C++ parser.

## Mandatory nonclaims

The retained profile and summary must keep all of the following false:

```text
dm_log_writes_capture
authentic_acquisition
machine_bound
physical_power_loss_claim
authority_granted
```
