# Flush domains and evidence planes

Rev0880 separates three notions that historical work repeatedly risked
collapsing:

1. **Observer marker** — labels a trace position; carries no persistence claim.
2. **Flush request/completion in a declared profile** — moves pending writes to
   the profile's stable image.
3. **Protected endpoint result** — exact evidence about the selected effect,
   bound to the operation and produced by a separately governed provider.

A marker may help correlate acquisition. It cannot authorize a state advance.
A returned host call may be evidence under a named machine contract. It is not
by itself a physical durability theorem. An endpoint result may narrow outcome
knowledge only after its authenticity, operation binding, freshness, provider
identity and durability are independently established.

The authority machine consumes typed appraisal results. It must not consume raw
trace marks or let acquisition tooling choose retry, compensation, publication
or effect routing.
