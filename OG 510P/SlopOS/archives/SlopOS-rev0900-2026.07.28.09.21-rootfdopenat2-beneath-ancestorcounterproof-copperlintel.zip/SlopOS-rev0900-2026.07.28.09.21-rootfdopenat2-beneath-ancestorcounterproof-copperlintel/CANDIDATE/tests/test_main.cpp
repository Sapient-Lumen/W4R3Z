#include "slopos/e0/fence/core.hpp"
#include "slopos/e0/fence/model.hpp"

#include <cstdlib>
#include <iostream>
#include <string_view>

namespace f = slopos::e0::fence;

namespace {

[[noreturn]] void fail(const std::string_view message) {
    std::cerr << "TEST_FAIL=" << message << '\n';
    std::exit(1);
}

f::State apply(f::State state, const f::Event event,
               const bool expect_effect = false) {
    const auto a = f::step_core(state, event);
    const auto b = f::step_model(state, event);
    if (a.outcome != f::Outcome::applied || b.outcome != f::Outcome::applied
        || a.state != b.state || a.effect_emitted != b.effect_emitted
        || a.effect_emitted != expect_effect || !f::state_invariant(a.state)) {
        fail(f::event_name(event));
    }
    return a.state;
}

void reject(const f::State& state, const f::Event event) {
    const auto a = f::step_core(state, event);
    const auto b = f::step_model(state, event);
    if (a.outcome != f::Outcome::rejected
        || b.outcome != f::Outcome::rejected
        || a.state != state || b.state != state
        || a.effect_emitted || b.effect_emitted) {
        fail(f::event_name(event));
    }
}

f::State live_to_permit() {
    f::State s = f::initial_state();
    s = apply(s, f::Event::admit);
    s = apply(s, f::Event::prepare_exact);
    s = apply(s, f::Event::plan_c2);
    s = apply(s, f::Event::advance_selector);
    s = apply(s, f::Event::advance_floor);
    s = apply(s, f::Event::advance_confirmed);
    s = apply(s, f::Event::retire_pending);
    s = apply(s, f::Event::activate_exact);
    return s;
}

void uncertainty_after_reopen() {
    f::State s = f::initial_state();
    s = apply(s, f::Event::admit);
    s = apply(s, f::Event::prepare_exact);
    s = apply(s, f::Event::plan_c2);
    s = apply(s, f::Event::advance_selector);
    s = apply(s, f::Event::advance_floor);
    s = apply(s, f::Event::advance_confirmed);
    s = apply(s, f::Event::retire_pending);
    s = apply(s, f::Event::restart);
    if (s.dispatch != f::DispatchKnowledge::unknown || !s.recovered
        || !s.reconcile_only) fail("restart did not widen C2");
    reject(s, f::Event::complete_no_effect);
    reject(s, f::Event::enter_dispatch_exact);
    s = apply(s, f::Event::complete_uncertain);
    s = apply(s, f::Event::publish_uncertain);
    if (s.durable != f::DurableKind::c4_uncertain) {
        fail("uncertainty not published");
    }
}

void exact_no_effect_only() {
    f::State s = live_to_permit();
    s = apply(s, f::Event::enter_dispatch_exact);
    reject(s, f::Event::complete_no_effect);
    s = apply(s, f::Event::return_no_effect);
    s = apply(s, f::Event::complete_no_effect);
    s = apply(s, f::Event::publish_no_effect);
    if (s.durable != f::DurableKind::c4_no_effect
        || s.current_effect_occurred) fail("exact no-effect path");
}

void effect_path_and_reconcile() {
    f::State s = live_to_permit();
    s = apply(s, f::Event::enter_dispatch_exact);
    s = apply(s, f::Event::return_effect, true);
    s = apply(s, f::Event::restart);
    if (s.dispatch != f::DispatchKnowledge::unknown
        || !s.current_effect_occurred) fail("restart forgot ghost effect");
    s = apply(s, f::Event::reconcile_effect);
    s = apply(s, f::Event::complete_effect);
    s = apply(s, f::Event::publish_effect);
    if (s.durable != f::DurableKind::c4_effect || s.effect_count != 1U) {
        fail("effect reconcile path");
    }
}

void mismatch_consumes() {
    f::State s = live_to_permit();
    s = apply(s, f::Event::enter_dispatch_mismatch);
    reject(s, f::Event::enter_dispatch_exact);
    if (s.dispatch_permit) fail("mismatch retained permit");
}

void full_restore_witness() {
    f::State s = live_to_permit();
    s = apply(s, f::Event::enter_dispatch_exact);
    s = apply(s, f::Event::return_effect, true);
    s = apply(s, f::Event::complete_effect);
    s = apply(s, f::Event::publish_effect);
    s = apply(s, f::Event::rollback_local_and_floor);
    s = apply(s, f::Event::plan_c2);
    s = apply(s, f::Event::advance_selector);
    s = apply(s, f::Event::advance_floor);
    s = apply(s, f::Event::advance_confirmed);
    s = apply(s, f::Event::retire_pending);
    s = apply(s, f::Event::activate_exact);
    s = apply(s, f::Event::enter_dispatch_exact);
    s = apply(s, f::Event::return_effect, true);
    if (s.effect_count != 2U) fail("rollback duplicate missing");
}

}  // namespace

int main() {
    uncertainty_after_reopen();
    exact_no_effect_only();
    effect_path_and_reconcile();
    mismatch_consumes();
    full_restore_witness();
    std::cout << "TESTS=PASS\n";
    return 0;
}
