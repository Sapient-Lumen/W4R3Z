#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::process_custody {

inline constexpr std::string_view kReportSchema = "slopos.process-report.v1";
inline constexpr int kReportFd = 10;
inline constexpr int kNextExecFd = 11;
inline constexpr int kInitialExecFd = 12;

struct Report {
    std::string schema{};
    std::string phase{};
    std::string executable_id{};
    std::uint64_t pid{};
    std::uint64_t ppid{};
    std::uint64_t uid{};
    std::uint64_t gid{};
    bool no_new_privs{};
    bool cap_inheritable_zero{};
    bool cap_permitted_zero{};
    bool cap_effective_zero{};
    bool cap_bounding_zero{};
    bool cap_ambient_zero{};
    bool fd0_normalized{};
    bool fd1_normalized{};
    bool fd2_normalized{};
    bool report_fd_present{};
    bool next_exec_fd_present{};
    std::uint64_t unexpected_fd_count{};

    auto operator<=>(const Report&) const = default;
};

enum class ReportCode {
    ok,
    malformed,
    noncanonical,
    schema_mismatch,
    field_invalid,
};

struct ParseResult {
    bool ok{};
    ReportCode code{ReportCode::malformed};
    Report report{};
    std::string detail{};
};

[[nodiscard]] std::string report_code_name(ReportCode code);
[[nodiscard]] std::string serialize_report(const Report& report);
[[nodiscard]] ParseResult parse_report_strict(std::span<const std::uint8_t> bytes);
[[nodiscard]] ParseResult parse_report_reference(std::span<const std::uint8_t> bytes);

// The abstract relation intentionally models process lifetime and executable
// epoch as distinct coordinates. It has no event that authenticates a provider
// or grants effect authority.
enum class Phase {
    idle,
    process_created,
    exec_a,
    observed_a,
    exec_b,
    observed_b,
    exited,
    waited,
    published,
};

enum class Event {
    clone_pidfd,
    exec_a_by_fd,
    observe_a_exact,
    exec_b_same_lifetime,
    observe_b_exact,
    process_exit,
    wait_pidfd,
    publish,
};

struct State {
    Phase phase{Phase::idle};
    bool pidfd_bound{};
    bool no_new_privs{};
    bool initial_launch_closed{};
    bool executable_replaced{};
    bool executable_continuity_bound{};
    bool provider_authenticated{};
    bool authority_granted{};

    auto operator<=>(const State&) const = default;
};

enum class Outcome { applied, rejected };

struct Transition {
    Outcome outcome{Outcome::rejected};
    State state{};
};

[[nodiscard]] State initial_state();
[[nodiscard]] Transition step_core(const State& state, Event event);
[[nodiscard]] Transition step_reference(const State& state, Event event);
[[nodiscard]] bool invariant(const State& state);
[[nodiscard]] std::string phase_name(Phase phase);
[[nodiscard]] std::string event_name(Event event);
[[nodiscard]] std::string outcome_name(Outcome outcome);
[[nodiscard]] std::vector<Event> all_events();

struct CampaignReport {
    bool ok{};
    std::string detail{};
    std::size_t live_cases{};
    std::size_t launch_closed_candidates{};
    std::size_t fail_closed_cases{};
    std::size_t parser_cases{};
    std::size_t parser_disagreements{};
    std::size_t model_states{};
    std::size_t model_transitions{};
    std::size_t model_applied{};
    std::size_t model_rejected{};
    std::size_t counterexamples{};
    std::size_t process_custody_results{};
    std::size_t provider_authenticated_results{};
    std::size_t authority_bearing_results{};
};

[[nodiscard]] CampaignReport run_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& worker_a,
    const std::filesystem::path& worker_b);

}  // namespace slopos::e0::process_custody
