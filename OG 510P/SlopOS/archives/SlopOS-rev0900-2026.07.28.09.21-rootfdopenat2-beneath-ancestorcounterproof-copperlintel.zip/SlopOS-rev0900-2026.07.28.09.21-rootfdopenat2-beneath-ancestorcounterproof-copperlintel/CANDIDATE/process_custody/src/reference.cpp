#include "slopos/e0/process_custody/custody.hpp"

#include <charconv>
#include <map>
#include <string>
#include <string_view>

namespace slopos::e0::process_custody {
namespace {

[[nodiscard]] bool decimal(const std::string& text, std::uint64_t& value) {
    if (text.empty() || (text.size() > 1U && text.front() == '0')) return false;
    const auto result = std::from_chars(text.data(), text.data() + text.size(), value);
    return result.ec == std::errc{} && result.ptr == text.data() + text.size();
}

[[nodiscard]] bool bit(const std::string& text, bool& value) {
    if (text == "0") { value = false; return true; }
    if (text == "1") { value = true; return true; }
    return false;
}

[[nodiscard]] ParseResult bad(const ReportCode code, const char* detail) {
    return ParseResult{false, code, {}, detail};
}

}  // namespace

ParseResult parse_report_reference(const std::span<const std::uint8_t> bytes) {
    if (bytes.empty() || bytes.size() > 4096U) {
        return bad(ReportCode::malformed, "framing");
    }
    if (bytes.back() != '\n') {
        return bad(ReportCode::noncanonical, "terminal-newline");
    }
    std::string text(reinterpret_cast<const char*>(bytes.data()), bytes.size());
    if (text.find('\0') != std::string::npos || text.find('\r') != std::string::npos) {
        return bad(ReportCode::malformed, "control");
    }
    std::map<std::string, std::string> fields;
    std::size_t start = 0;
    while (start < text.size()) {
        const auto end = text.find('\n', start);
        if (end == std::string::npos) return bad(ReportCode::malformed, "line");
        const std::string line = text.substr(start, end - start);
        const auto tab = line.find('\t');
        if (tab == std::string::npos) {
            return bad(ReportCode::malformed, "separator");
        }
        if (line.find('\t', tab + 1U) != std::string::npos) {
            return bad(ReportCode::noncanonical, "extra-separator");
        }
        const std::string key = line.substr(0U, tab);
        const std::string value = line.substr(tab + 1U);
        if (key.empty() || !fields.emplace(key, value).second) {
            return bad(ReportCode::malformed, "duplicate");
        }
        start = end + 1U;
    }
    static constexpr const char* required[] = {
        "schema", "phase", "executable_id", "pid", "ppid", "uid", "gid",
        "no_new_privs", "cap_inheritable_zero", "cap_permitted_zero",
        "cap_effective_zero", "cap_bounding_zero", "cap_ambient_zero",
        "fd0_normalized", "fd1_normalized", "fd2_normalized",
        "report_fd_present", "next_exec_fd_present", "unexpected_fd_count",
    };
    if (fields.size() != std::size(required)) return bad(ReportCode::malformed, "field-count");
    for (const char* key : required) {
        if (!fields.contains(key)) return bad(ReportCode::malformed, "missing");
    }

    Report report;
    report.schema = fields["schema"];
    report.phase = fields["phase"];
    report.executable_id = fields["executable_id"];
    if (report.schema != kReportSchema) return bad(ReportCode::schema_mismatch, "schema");
    if (report.phase != "ENTRY" ||
        (report.executable_id != "worker-a" && report.executable_id != "worker-b")) {
        return bad(ReportCode::field_invalid, "text-field");
    }
    if (!decimal(fields["pid"], report.pid) || report.pid == 0U ||
        !decimal(fields["ppid"], report.ppid) || report.ppid == 0U ||
        !decimal(fields["uid"], report.uid) ||
        !decimal(fields["gid"], report.gid) ||
        !decimal(fields["unexpected_fd_count"], report.unexpected_fd_count)) {
        return bad(ReportCode::field_invalid, "number");
    }
    struct BoolField { const char* key; bool* value; };
    BoolField bools[] = {
        {"no_new_privs", &report.no_new_privs},
        {"cap_inheritable_zero", &report.cap_inheritable_zero},
        {"cap_permitted_zero", &report.cap_permitted_zero},
        {"cap_effective_zero", &report.cap_effective_zero},
        {"cap_bounding_zero", &report.cap_bounding_zero},
        {"cap_ambient_zero", &report.cap_ambient_zero},
        {"fd0_normalized", &report.fd0_normalized},
        {"fd1_normalized", &report.fd1_normalized},
        {"fd2_normalized", &report.fd2_normalized},
        {"report_fd_present", &report.report_fd_present},
        {"next_exec_fd_present", &report.next_exec_fd_present},
    };
    for (const auto& item : bools) {
        if (!bit(fields[item.key], *item.value)) return bad(ReportCode::field_invalid, "bit");
    }
    if (serialize_report(report) != text) return bad(ReportCode::noncanonical, "canonical-order");
    return ParseResult{true, ReportCode::ok, std::move(report), "ok"};
}

}  // namespace slopos::e0::process_custody
