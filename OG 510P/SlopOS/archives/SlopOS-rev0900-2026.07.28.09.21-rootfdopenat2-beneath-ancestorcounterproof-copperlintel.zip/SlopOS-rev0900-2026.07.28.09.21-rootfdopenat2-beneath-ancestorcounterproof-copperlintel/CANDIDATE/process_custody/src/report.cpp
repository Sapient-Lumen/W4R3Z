#include "slopos/e0/process_custody/custody.hpp"

#include <array>
#include <charconv>
#include <limits>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::process_custody {
namespace {

[[nodiscard]] bool safe_token(const std::string_view value) {
    if (value.empty() || value.size() > 96U) return false;
    for (const char raw : value) {
        const auto ch = static_cast<unsigned char>(raw);
        if (!(ch == static_cast<unsigned char>('-') ||
              ch == static_cast<unsigned char>('_') ||
              ch == static_cast<unsigned char>('.') ||
              (ch >= '0' && ch <= '9') ||
              (ch >= 'A' && ch <= 'Z') ||
              (ch >= 'a' && ch <= 'z'))) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool parse_u64(const std::string_view text, std::uint64_t& out) {
    if (text.empty() || (text.size() > 1U && text.front() == '0')) return false;
    std::uint64_t value{};
    const auto result = std::from_chars(text.data(), text.data() + text.size(), value, 10);
    if (result.ec != std::errc{} || result.ptr != text.data() + text.size()) return false;
    out = value;
    return true;
}

[[nodiscard]] bool parse_bool(const std::string_view text, bool& out) {
    if (text == "0") { out = false; return true; }
    if (text == "1") { out = true; return true; }
    return false;
}

[[nodiscard]] std::vector<std::string_view> lines(const std::string_view text) {
    std::vector<std::string_view> result;
    std::size_t begin = 0;
    while (begin < text.size()) {
        const auto end = text.find('\n', begin);
        if (end == std::string_view::npos) return {};
        result.push_back(text.substr(begin, end - begin));
        begin = end + 1U;
    }
    return result;
}

[[nodiscard]] std::pair<std::string_view, std::string_view> split_line(
    const std::string_view line) {
    const auto tab = line.find('\t');
    if (tab == std::string_view::npos || line.find('\t', tab + 1U) != std::string_view::npos) {
        return {};
    }
    return {line.substr(0U, tab), line.substr(tab + 1U)};
}

[[nodiscard]] ParseResult invalid(const ReportCode code, const std::string& detail) {
    return ParseResult{false, code, {}, detail};
}

}  // namespace

std::string report_code_name(const ReportCode code) {
    switch (code) {
        case ReportCode::ok: return "OK";
        case ReportCode::malformed: return "MALFORMED";
        case ReportCode::noncanonical: return "NONCANONICAL";
        case ReportCode::schema_mismatch: return "SCHEMA_MISMATCH";
        case ReportCode::field_invalid: return "FIELD_INVALID";
    }
    return "UNKNOWN";
}

std::string serialize_report(const Report& report) {
    std::string out;
    const auto add = [&out](const std::string_view key, const std::string& value) {
        out.append(key);
        out.push_back('\t');
        out.append(value);
        out.push_back('\n');
    };
    const auto add_bool = [&add](const std::string_view key, const bool value) {
        add(key, value ? "1" : "0");
    };
    add("schema", report.schema);
    add("phase", report.phase);
    add("executable_id", report.executable_id);
    add("pid", std::to_string(report.pid));
    add("ppid", std::to_string(report.ppid));
    add("uid", std::to_string(report.uid));
    add("gid", std::to_string(report.gid));
    add_bool("no_new_privs", report.no_new_privs);
    add_bool("cap_inheritable_zero", report.cap_inheritable_zero);
    add_bool("cap_permitted_zero", report.cap_permitted_zero);
    add_bool("cap_effective_zero", report.cap_effective_zero);
    add_bool("cap_bounding_zero", report.cap_bounding_zero);
    add_bool("cap_ambient_zero", report.cap_ambient_zero);
    add_bool("fd0_normalized", report.fd0_normalized);
    add_bool("fd1_normalized", report.fd1_normalized);
    add_bool("fd2_normalized", report.fd2_normalized);
    add_bool("report_fd_present", report.report_fd_present);
    add_bool("next_exec_fd_present", report.next_exec_fd_present);
    add("unexpected_fd_count", std::to_string(report.unexpected_fd_count));
    return out;
}

ParseResult parse_report_strict(const std::span<const std::uint8_t> bytes) {
    if (bytes.empty() || bytes.size() > 4096U) return invalid(ReportCode::malformed, "size");
    for (const auto byte : bytes) {
        if (byte == 0U || byte == '\r') return invalid(ReportCode::malformed, "control");
    }
    const std::string_view text(reinterpret_cast<const char*>(bytes.data()), bytes.size());
    if (text.back() != '\n') return invalid(ReportCode::noncanonical, "terminal-newline");
    const auto parsed_lines = lines(text);
    if (parsed_lines.size() != 19U) return invalid(ReportCode::malformed, "line-count");
    constexpr std::array<std::string_view, 19> keys = {
        "schema", "phase", "executable_id", "pid", "ppid", "uid", "gid",
        "no_new_privs", "cap_inheritable_zero", "cap_permitted_zero",
        "cap_effective_zero", "cap_bounding_zero", "cap_ambient_zero",
        "fd0_normalized", "fd1_normalized", "fd2_normalized",
        "report_fd_present", "next_exec_fd_present", "unexpected_fd_count",
    };
    std::array<std::string_view, 19> values{};
    for (std::size_t i = 0; i < keys.size(); ++i) {
        const auto [key, value] = split_line(parsed_lines[i]);
        if (key != keys[i]) return invalid(ReportCode::noncanonical, "field-order");
        values[i] = value;
    }

    Report report;
    report.schema = std::string(values[0]);
    report.phase = std::string(values[1]);
    report.executable_id = std::string(values[2]);
    if (report.schema != kReportSchema) return invalid(ReportCode::schema_mismatch, "schema");
    if (report.phase != "ENTRY") return invalid(ReportCode::field_invalid, "phase");
    if ((report.executable_id != "worker-a" && report.executable_id != "worker-b") ||
        !safe_token(report.executable_id)) {
        return invalid(ReportCode::field_invalid, "executable-id");
    }
    if (!parse_u64(values[3], report.pid) || report.pid == 0U ||
        !parse_u64(values[4], report.ppid) || report.ppid == 0U ||
        !parse_u64(values[5], report.uid) ||
        !parse_u64(values[6], report.gid)) {
        return invalid(ReportCode::field_invalid, "numeric-identity");
    }
    std::array<bool*, 11> bools = {
        &report.no_new_privs,
        &report.cap_inheritable_zero,
        &report.cap_permitted_zero,
        &report.cap_effective_zero,
        &report.cap_bounding_zero,
        &report.cap_ambient_zero,
        &report.fd0_normalized,
        &report.fd1_normalized,
        &report.fd2_normalized,
        &report.report_fd_present,
        &report.next_exec_fd_present,
    };
    for (std::size_t i = 0; i < bools.size(); ++i) {
        if (!parse_bool(values[7U + i], *bools[i])) {
            return invalid(ReportCode::field_invalid, "boolean");
        }
    }
    if (!parse_u64(values[18], report.unexpected_fd_count)) {
        return invalid(ReportCode::field_invalid, "unexpected-fd-count");
    }
    const std::string canonical = serialize_report(report);
    if (canonical != text) return invalid(ReportCode::noncanonical, "roundtrip");
    return ParseResult{true, ReportCode::ok, std::move(report), "ok"};
}

}  // namespace slopos::e0::process_custody
