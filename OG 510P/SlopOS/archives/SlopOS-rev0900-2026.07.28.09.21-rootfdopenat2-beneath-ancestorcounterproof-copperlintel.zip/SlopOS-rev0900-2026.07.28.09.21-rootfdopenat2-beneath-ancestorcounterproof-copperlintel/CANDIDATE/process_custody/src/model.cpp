#include "slopos/e0/process_custody/custody.hpp"

#include <array>
#include <string>
#include <vector>

namespace slopos::e0::process_custody {

State initial_state() { return {}; }

namespace {

[[nodiscard]] Transition reject(const State& state) {
    return Transition{Outcome::rejected, state};
}

[[nodiscard]] Transition apply(State state) {
    return Transition{Outcome::applied, state};
}

}  // namespace

Transition step_core(const State& state, const Event event) {
    State next = state;
    switch (event) {
        case Event::clone_pidfd:
            if (state.phase != Phase::idle) return reject(state);
            next.phase = Phase::process_created;
            next.pidfd_bound = true;
            return apply(next);
        case Event::exec_a_by_fd:
            if (state.phase != Phase::process_created || !state.pidfd_bound) return reject(state);
            next.phase = Phase::exec_a;
            next.no_new_privs = true;
            return apply(next);
        case Event::observe_a_exact:
            if (state.phase != Phase::exec_a || !state.pidfd_bound || !state.no_new_privs) {
                return reject(state);
            }
            next.phase = Phase::observed_a;
            next.initial_launch_closed = true;
            return apply(next);
        case Event::exec_b_same_lifetime:
            if (state.phase != Phase::observed_a || !state.pidfd_bound) return reject(state);
            next.phase = Phase::exec_b;
            next.executable_replaced = true;
            next.executable_continuity_bound = false;
            return apply(next);
        case Event::observe_b_exact:
            if (state.phase != Phase::exec_b || !state.pidfd_bound || !state.no_new_privs) {
                return reject(state);
            }
            next.phase = Phase::observed_b;
            return apply(next);
        case Event::process_exit:
            if (state.phase != Phase::observed_b) return reject(state);
            next.phase = Phase::exited;
            return apply(next);
        case Event::wait_pidfd:
            if (state.phase != Phase::exited || !state.pidfd_bound) return reject(state);
            next.phase = Phase::waited;
            return apply(next);
        case Event::publish:
            if (state.phase != Phase::waited) return reject(state);
            next.phase = Phase::published;
            return apply(next);
    }
    return reject(state);
}

Transition step_reference(const State& state, const Event event) {
    const auto expected = [event](const Phase phase) {
        switch (event) {
            case Event::clone_pidfd: return phase == Phase::idle;
            case Event::exec_a_by_fd: return phase == Phase::process_created;
            case Event::observe_a_exact: return phase == Phase::exec_a;
            case Event::exec_b_same_lifetime: return phase == Phase::observed_a;
            case Event::observe_b_exact: return phase == Phase::exec_b;
            case Event::process_exit: return phase == Phase::observed_b;
            case Event::wait_pidfd: return phase == Phase::exited;
            case Event::publish: return phase == Phase::waited;
        }
        return false;
    };
    if (!expected(state.phase)) return reject(state);
    State next = state;
    if (event == Event::clone_pidfd) {
        next.phase = Phase::process_created;
        next.pidfd_bound = true;
    } else if (event == Event::exec_a_by_fd) {
        if (!state.pidfd_bound) return reject(state);
        next.phase = Phase::exec_a;
        next.no_new_privs = true;
    } else if (event == Event::observe_a_exact) {
        if (!state.pidfd_bound || !state.no_new_privs) return reject(state);
        next.phase = Phase::observed_a;
        next.initial_launch_closed = true;
    } else if (event == Event::exec_b_same_lifetime) {
        if (!state.pidfd_bound) return reject(state);
        next.phase = Phase::exec_b;
        next.executable_replaced = true;
        next.executable_continuity_bound = false;
    } else if (event == Event::observe_b_exact) {
        if (!state.pidfd_bound || !state.no_new_privs) return reject(state);
        next.phase = Phase::observed_b;
    } else if (event == Event::process_exit) {
        next.phase = Phase::exited;
    } else if (event == Event::wait_pidfd) {
        if (!state.pidfd_bound) return reject(state);
        next.phase = Phase::waited;
    } else {
        next.phase = Phase::published;
    }
    return apply(next);
}

bool invariant(const State& state) {
    if (state.provider_authenticated || state.authority_granted) return false;
    if (state.phase != Phase::idle && !state.pidfd_bound) return false;
    if ((state.phase == Phase::exec_a || state.phase == Phase::observed_a ||
         state.phase == Phase::exec_b || state.phase == Phase::observed_b ||
         state.phase == Phase::exited || state.phase == Phase::waited ||
         state.phase == Phase::published) && !state.no_new_privs) {
        return false;
    }
    if (state.initial_launch_closed &&
        (state.phase == Phase::idle || state.phase == Phase::process_created ||
         state.phase == Phase::exec_a)) {
        return false;
    }
    if (state.executable_replaced &&
        (state.phase != Phase::exec_b && state.phase != Phase::observed_b &&
         state.phase != Phase::exited && state.phase != Phase::waited &&
         state.phase != Phase::published)) {
        return false;
    }
    if (state.executable_replaced && state.executable_continuity_bound) return false;
    return true;
}

std::string phase_name(const Phase phase) {
    switch (phase) {
        case Phase::idle: return "IDLE";
        case Phase::process_created: return "PROCESS_CREATED";
        case Phase::exec_a: return "EXEC_A";
        case Phase::observed_a: return "OBSERVED_A";
        case Phase::exec_b: return "EXEC_B";
        case Phase::observed_b: return "OBSERVED_B";
        case Phase::exited: return "EXITED";
        case Phase::waited: return "WAITED";
        case Phase::published: return "PUBLISHED";
    }
    return "UNKNOWN";
}

std::string event_name(const Event event) {
    switch (event) {
        case Event::clone_pidfd: return "CLONE_PIDFD";
        case Event::exec_a_by_fd: return "EXEC_A_BY_FD";
        case Event::observe_a_exact: return "OBSERVE_A_EXACT";
        case Event::exec_b_same_lifetime: return "EXEC_B_SAME_LIFETIME";
        case Event::observe_b_exact: return "OBSERVE_B_EXACT";
        case Event::process_exit: return "PROCESS_EXIT";
        case Event::wait_pidfd: return "WAIT_PIDFD";
        case Event::publish: return "PUBLISH";
    }
    return "UNKNOWN";
}

std::string outcome_name(const Outcome outcome) {
    return outcome == Outcome::applied ? "APPLIED" : "REJECTED";
}

std::vector<Event> all_events() {
    return {
        Event::clone_pidfd,
        Event::exec_a_by_fd,
        Event::observe_a_exact,
        Event::exec_b_same_lifetime,
        Event::observe_b_exact,
        Event::process_exit,
        Event::wait_pidfd,
        Event::publish,
    };
}

}  // namespace slopos::e0::process_custody
