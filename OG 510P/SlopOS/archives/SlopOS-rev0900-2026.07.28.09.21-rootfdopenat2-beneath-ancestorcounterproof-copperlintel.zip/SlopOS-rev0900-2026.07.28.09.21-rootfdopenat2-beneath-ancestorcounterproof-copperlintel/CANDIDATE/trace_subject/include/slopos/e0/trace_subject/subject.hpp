#pragma once

#include "slopos/e0/trace_intake/dmlog.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <vector>

namespace slopos::e0::trace_subject {

using Bytes = std::vector<std::uint8_t>;

inline constexpr const char* kProposalSchema = "slopos.trace-subject.proposal.v1";
inline constexpr const char* kWitnessSchema = "slopos.trace-subject.witness.v1";
inline constexpr const char* kReceiptSchema = "slopos.trace-subject.receipt.v1";
inline constexpr const char* kTraceSchema = "linux.dm-log-writes.v1.strict-subset";

struct Proposal {
    std::string schema{};
    std::string run_id{};
    std::string operation_sha256{};
    std::string capture_profile{};
    std::uint64_t sector_size{};
    std::uint64_t baseline_bytes{};
    std::string baseline_sha256{};
    std::string workload_image_sha256{};
    std::string workload_inputs_sha256{};
    std::string target_device_sha256{};
    std::string log_device_sha256{};
    std::string block_graph_sha256{};
    std::string writer_policy_sha256{};
    std::uint64_t export_offset_bytes{};
    std::uint64_t export_length_bytes{};
    std::string trace_schema{};
};

struct Witness {
    std::string schema{};
    std::string run_id{};
    std::string authorization_id{};
    std::string challenge_id{};
    std::string machine_sha256{};
    std::string boot_id{};
    std::string kernel_sha256{};
    std::string supervisor_image_sha256{};
    std::string supervisor_instance_sha256{};
    std::uint64_t supervisor_pid{};
    bool pidfd_bound{};
    std::string mount_namespace{};
    std::string user_namespace{};
    std::string pid_namespace{};
    bool preclean_observed{};
    bool target_created_once{};
    bool workload_launched_once{};
    bool workload_exit_observed{};
    std::int64_t workload_exit_code{};
    std::string stdout_sha256{};
    std::string stderr_sha256{};
    std::string target_remove_status{};
    bool export_read_observed{};
    bool writer_closure_observed{};
    bool direct_aliases_closed{};
    bool log_aliases_closed{};
    bool process_restarted{};
    bool complete{};
};

struct Receipt {
    std::string schema{};
    std::string run_id{};
    std::string proposal_sha256{};
    std::string witness_sha256{};
    std::string trace_sha256{};
    std::uint64_t trace_bytes{};
    std::string normalized_sha256{};
    std::string replay_manifest_sha256{};
    std::string export_close_state{};
    std::string publication_id{};
    std::string subject_sha256{};
};

enum class PacketCode {
    ok,
    malformed_record,
    noncanonical_record,
    schema_mismatch,
    field_invalid,
    join_mismatch,
    baseline_mismatch,
    trace_rejected,
    replay_mismatch,
    export_not_closed,
    writer_custody_incomplete,
    supervisor_custody_incomplete,
};

enum class EvidenceRung {
    none,
    structurally_valid,
    deterministically_replayed,
    export_closed_candidate,
    capture_bound,
};

struct ValidationContext {
    bool provider_authenticated{};
    bool machine_binding_verified{};
    bool supervisor_process_custody_verified{};
    bool exclusive_writer_verified{};
    bool fixture_only{true};
};

struct PacketInput {
    Bytes proposal_bytes{};
    Bytes witness_bytes{};
    Bytes receipt_bytes{};
    Bytes trace_bytes{};
    Bytes baseline_bytes{};
};

struct ValidationResult {
    bool ok{};
    PacketCode code{PacketCode::malformed_record};
    EvidenceRung rung{EvidenceRung::none};
    bool strict_reference_agree{};
    bool authority_granted{};
    bool authentic_acquisition{};
    bool machine_bound{};
    bool capture_bound{};
    std::string detail{};
    Proposal proposal{};
    Witness witness{};
    Receipt receipt{};
    std::string normalized_sha256{};
    std::string replay_manifest_sha256{};
};

[[nodiscard]] std::string sha256_hex(std::span<const std::uint8_t> bytes);
[[nodiscard]] std::string sha256_hex(std::string_view text);
[[nodiscard]] bool is_sha256_hex(std::string_view text) noexcept;

[[nodiscard]] Bytes serialize_proposal(const Proposal& proposal);
[[nodiscard]] Bytes serialize_witness(const Witness& witness);
[[nodiscard]] Bytes serialize_receipt_without_subject(const Receipt& receipt);
[[nodiscard]] Bytes serialize_receipt(const Receipt& receipt);

[[nodiscard]] bool parse_proposal_strict(
    std::span<const std::uint8_t> bytes, Proposal& out, std::string& detail);
[[nodiscard]] bool parse_witness_strict(
    std::span<const std::uint8_t> bytes, Witness& out, std::string& detail);
[[nodiscard]] bool parse_receipt_strict(
    std::span<const std::uint8_t> bytes, Receipt& out, std::string& detail);

[[nodiscard]] bool parse_proposal_reference(
    std::span<const std::uint8_t> bytes, Proposal& out, std::string& detail);
[[nodiscard]] bool parse_witness_reference(
    std::span<const std::uint8_t> bytes, Witness& out, std::string& detail);
[[nodiscard]] bool parse_receipt_reference(
    std::span<const std::uint8_t> bytes, Receipt& out, std::string& detail);

[[nodiscard]] Bytes normalized_events(
    const trace_intake::ParsedLog& log);
[[nodiscard]] Bytes replay_manifest(
    std::span<const std::uint8_t> baseline,
    const trace_intake::ParsedLog& log);

[[nodiscard]] ValidationResult validate_packet(
    const PacketInput& input,
    const ValidationContext& context);

[[nodiscard]] std::string packet_code_name(PacketCode code);
[[nodiscard]] std::string evidence_rung_name(EvidenceRung rung);

// Hosted capture-ceremony model. This models control-plane ordering only.
enum class CeremonyPhase {
    idle,
    authorized,
    namespace_closed,
    devices_bound,
    target_active,
    workload_running,
    workload_terminal,
    target_removed,
    export_read,
    export_closed,
    published,
    failed,
    incomplete,
};

enum class CeremonyEvent {
    authorize,
    close_namespace,
    bind_devices,
    create_target,
    launch_workload,
    observe_exit_success,
    observe_exit_failure,
    remove_target_success,
    remove_target_unknown,
    read_export,
    close_export,
    publish,
    restart,
    hidden_writer,
    mismatch,
};

struct CeremonyState {
    CeremonyPhase phase{CeremonyPhase::idle};
    bool authorization_live{};
    bool run_identity_live{};
    bool target_live{};
    bool export_closed{};
    bool published{};

    [[nodiscard]] auto key() const noexcept {
        return std::tuple{phase, authorization_live, run_identity_live,
                          target_live, export_closed, published};
    }
    [[nodiscard]] bool operator==(const CeremonyState&) const noexcept = default;
};

struct CeremonyStep {
    bool applied{};
    CeremonyState next{};
};

[[nodiscard]] CeremonyStep ceremony_step(
    const CeremonyState& state, CeremonyEvent event) noexcept;
[[nodiscard]] CeremonyStep ceremony_step_reference(
    const CeremonyState& state, CeremonyEvent event) noexcept;
[[nodiscard]] bool ceremony_invariant(const CeremonyState& state) noexcept;
[[nodiscard]] std::string ceremony_phase_name(CeremonyPhase phase);
[[nodiscard]] std::string ceremony_event_name(CeremonyEvent event);

struct CampaignReport {
    bool ok{};
    std::size_t packet_cases{};
    std::size_t packet_accepted{};
    std::size_t packet_rejected{};
    std::size_t parser_disagreements{};
    std::size_t export_closed_candidates{};
    std::size_t capture_bound_results{};
    std::size_t ceremony_states{};
    std::size_t ceremony_transitions{};
    std::size_t ceremony_events_per_state{};
    std::size_t ceremony_applied_edges{};
    std::size_t ceremony_rejected_edges{};
    std::size_t ceremony_differential_checks{};
    std::size_t ceremony_invariant_checks{};
    std::size_t restart_edges{};
    bool restart_after_activation_closes_export{};
    bool unknown_remove_closes_export{};
    bool publication_promotes_capture{};
    bool hidden_writer_can_export{};
    bool coherent_forgery_accepted_as_candidate{};
    bool coherent_forgery_authentic{};
    bool numeric_pid_proves_process_custody{};
    bool hidden_writer_same_packet_different_history{};
    bool packet_authority_granted{};
    bool sha256_known_answer_pass{};
    std::string detail{};
};

[[nodiscard]] CampaignReport run_trace_subject_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::trace_subject
