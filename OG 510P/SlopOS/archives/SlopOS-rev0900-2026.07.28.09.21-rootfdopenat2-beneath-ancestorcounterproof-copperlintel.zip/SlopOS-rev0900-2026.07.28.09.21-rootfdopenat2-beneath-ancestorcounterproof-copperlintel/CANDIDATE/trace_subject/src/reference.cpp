#include "slopos/e0/trace_subject/subject.hpp"

#include <charconv>
#include <map>
#include <set>
#include <string_view>

namespace slopos::e0::trace_subject {
namespace {

using Record = std::map<std::string, std::string>;

[[nodiscard]] bool read_record(
    const std::span<const std::uint8_t> bytes,
    Record& out,
    std::string& detail) {
    const std::string text(bytes.begin(), bytes.end());
    if (text.empty() || text.back() != '\n' || text.find('\r') != std::string::npos
        || text.find('\0') != std::string::npos) {
        detail = "reference framing rejected";
        return false;
    }
    out.clear();
    std::size_t start = 0U;
    while (start < text.size()) {
        const std::size_t end = text.find('\n', start);
        if (end == std::string::npos || end == start) {
            detail = "reference empty/missing line";
            return false;
        }
        const std::string_view line(text.data() + static_cast<std::ptrdiff_t>(start),
                                    end - start);
        const std::size_t tab = line.find('\t');
        if (tab == std::string_view::npos || tab == 0U
            || line.find('\t', tab + 1U) != std::string_view::npos
            || tab + 1U == line.size()) {
            detail = "reference tab grammar rejected";
            return false;
        }
        const std::string key(line.substr(0U, tab));
        const std::string value(line.substr(tab + 1U));
        if (!out.emplace(key, value).second) {
            detail = "reference duplicate key";
            return false;
        }
        start = end + 1U;
    }
    return true;
}

[[nodiscard]] bool exact_keyset(
    const Record& record, const std::set<std::string>& expected,
    std::string& detail) {
    std::set<std::string> actual;
    for (const auto& [key, value] : record) {
        (void)value;
        actual.insert(key);
    }
    if (actual != expected) {
        detail = "reference key set mismatch";
        return false;
    }
    return true;
}

[[nodiscard]] bool u64(const std::string& text, std::uint64_t& value) noexcept {
    if (text.empty() || (text.size() > 1U && text.front() == '0')) return false;
    const auto parsed = std::from_chars(text.data(), text.data() + text.size(), value, 10);
    return parsed.ec == std::errc{} && parsed.ptr == text.data() + text.size();
}

[[nodiscard]] bool i64(const std::string& text, std::int64_t& value) noexcept {
    if (text.empty() || text.front() == '+'
        || (text.size() > 1U && text.front() == '0')
        || (text.size() > 2U && text.front() == '-' && text[1] == '0')) {
        return false;
    }
    const auto parsed = std::from_chars(text.data(), text.data() + text.size(), value, 10);
    return parsed.ec == std::errc{} && parsed.ptr == text.data() + text.size();
}

[[nodiscard]] bool boolean(const std::string& text, bool& value) noexcept {
    if (text == "0") { value = false; return true; }
    if (text == "1") { value = true; return true; }
    return false;
}

[[nodiscard]] bool atom(const std::string& text) noexcept {
    if (text.empty() || text.size() > 256U) return false;
    for (const char value : text) {
        const auto byte = static_cast<unsigned char>(value);
        if (byte < 0x21U || byte > 0x7eU || value == '\t' || value == '\\') return false;
    }
    return true;
}

[[nodiscard]] bool hash(const std::string& text) noexcept {
    if (text.size() != 64U) return false;
    for (const char value : text) {
        if (!((value >= '0' && value <= '9') || (value >= 'a' && value <= 'f'))) return false;
    }
    return true;
}

[[nodiscard]] bool exact_bytes(
    const std::span<const std::uint8_t> bytes, const Bytes& canonical) noexcept {
    if (bytes.size() != canonical.size()) return false;
    for (std::size_t index = 0U; index < bytes.size(); ++index) {
        if (bytes[index] != canonical[index]) return false;
    }
    return true;
}

const std::set<std::string> kProposalKeys = {
    "schema", "run_id", "operation_sha256", "capture_profile", "sector_size",
    "baseline_bytes", "baseline_sha256", "workload_image_sha256",
    "workload_inputs_sha256", "target_device_sha256", "log_device_sha256",
    "block_graph_sha256", "writer_policy_sha256", "export_offset_bytes",
    "export_length_bytes", "trace_schema",
};
const std::set<std::string> kWitnessKeys = {
    "schema", "run_id", "authorization_id", "challenge_id", "machine_sha256",
    "boot_id", "kernel_sha256", "supervisor_image_sha256",
    "supervisor_instance_sha256", "supervisor_pid", "pidfd_bound",
    "mount_namespace", "user_namespace", "pid_namespace", "preclean_observed",
    "target_created_once", "workload_launched_once", "workload_exit_observed",
    "workload_exit_code", "stdout_sha256", "stderr_sha256",
    "target_remove_status", "export_read_observed", "writer_closure_observed",
    "direct_aliases_closed", "log_aliases_closed", "process_restarted", "complete",
};
const std::set<std::string> kReceiptKeys = {
    "schema", "run_id", "proposal_sha256", "witness_sha256", "trace_sha256",
    "trace_bytes", "normalized_sha256", "replay_manifest_sha256",
    "export_close_state", "publication_id", "subject_sha256",
};

}  // namespace

bool parse_proposal_reference(
    const std::span<const std::uint8_t> bytes, Proposal& out, std::string& detail) {
    Record r;
    if (!read_record(bytes, r, detail) || !exact_keyset(r, kProposalKeys, detail)) {
        return false;
    }
    Proposal value{};
    value.schema = r.at("schema");
    value.run_id = r.at("run_id");
    value.operation_sha256 = r.at("operation_sha256");
    value.capture_profile = r.at("capture_profile");
    if (!u64(r.at("sector_size"), value.sector_size)
        || !u64(r.at("baseline_bytes"), value.baseline_bytes)) return false;
    value.baseline_sha256 = r.at("baseline_sha256");
    value.workload_image_sha256 = r.at("workload_image_sha256");
    value.workload_inputs_sha256 = r.at("workload_inputs_sha256");
    value.target_device_sha256 = r.at("target_device_sha256");
    value.log_device_sha256 = r.at("log_device_sha256");
    value.block_graph_sha256 = r.at("block_graph_sha256");
    value.writer_policy_sha256 = r.at("writer_policy_sha256");
    if (!u64(r.at("export_offset_bytes"), value.export_offset_bytes)
        || !u64(r.at("export_length_bytes"), value.export_length_bytes)) return false;
    value.trace_schema = r.at("trace_schema");
    const bool fields_ok = value.schema == kProposalSchema && atom(value.run_id)
        && hash(value.operation_sha256) && atom(value.capture_profile)
        && (value.sector_size == 512U || value.sector_size == 1024U
            || value.sector_size == 2048U || value.sector_size == 4096U)
        && value.baseline_bytes > 0U && value.baseline_bytes % value.sector_size == 0U
        && hash(value.baseline_sha256) && hash(value.workload_image_sha256)
        && hash(value.workload_inputs_sha256) && hash(value.target_device_sha256)
        && hash(value.log_device_sha256) && hash(value.block_graph_sha256)
        && hash(value.writer_policy_sha256) && value.export_offset_bytes == 0U
        && value.export_length_bytes > 0U && value.trace_schema == kTraceSchema;
    if (!fields_ok || !exact_bytes(bytes, serialize_proposal(value))) {
        detail = "reference proposal is not canonical";
        return false;
    }
    out = std::move(value);
    return true;
}

bool parse_witness_reference(
    const std::span<const std::uint8_t> bytes, Witness& out, std::string& detail) {
    Record r;
    if (!read_record(bytes, r, detail) || !exact_keyset(r, kWitnessKeys, detail)) {
        return false;
    }
    Witness value{};
    value.schema = r.at("schema");
    value.run_id = r.at("run_id");
    value.authorization_id = r.at("authorization_id");
    value.challenge_id = r.at("challenge_id");
    value.machine_sha256 = r.at("machine_sha256");
    value.boot_id = r.at("boot_id");
    value.kernel_sha256 = r.at("kernel_sha256");
    value.supervisor_image_sha256 = r.at("supervisor_image_sha256");
    value.supervisor_instance_sha256 = r.at("supervisor_instance_sha256");
    if (!u64(r.at("supervisor_pid"), value.supervisor_pid)
        || !boolean(r.at("pidfd_bound"), value.pidfd_bound)) return false;
    value.mount_namespace = r.at("mount_namespace");
    value.user_namespace = r.at("user_namespace");
    value.pid_namespace = r.at("pid_namespace");
    if (!boolean(r.at("preclean_observed"), value.preclean_observed)
        || !boolean(r.at("target_created_once"), value.target_created_once)
        || !boolean(r.at("workload_launched_once"), value.workload_launched_once)
        || !boolean(r.at("workload_exit_observed"), value.workload_exit_observed)
        || !i64(r.at("workload_exit_code"), value.workload_exit_code)) return false;
    value.stdout_sha256 = r.at("stdout_sha256");
    value.stderr_sha256 = r.at("stderr_sha256");
    value.target_remove_status = r.at("target_remove_status");
    if (!boolean(r.at("export_read_observed"), value.export_read_observed)
        || !boolean(r.at("writer_closure_observed"), value.writer_closure_observed)
        || !boolean(r.at("direct_aliases_closed"), value.direct_aliases_closed)
        || !boolean(r.at("log_aliases_closed"), value.log_aliases_closed)
        || !boolean(r.at("process_restarted"), value.process_restarted)
        || !boolean(r.at("complete"), value.complete)) return false;
    const bool fields_ok = value.schema == kWitnessSchema && atom(value.run_id)
        && atom(value.authorization_id) && atom(value.challenge_id)
        && hash(value.machine_sha256) && atom(value.boot_id)
        && hash(value.kernel_sha256) && hash(value.supervisor_image_sha256)
        && hash(value.supervisor_instance_sha256) && value.supervisor_pid > 0U
        && atom(value.mount_namespace) && atom(value.user_namespace)
        && atom(value.pid_namespace) && hash(value.stdout_sha256)
        && hash(value.stderr_sha256) && atom(value.target_remove_status);
    if (!fields_ok || !exact_bytes(bytes, serialize_witness(value))) {
        detail = "reference witness is not canonical";
        return false;
    }
    out = std::move(value);
    return true;
}

bool parse_receipt_reference(
    const std::span<const std::uint8_t> bytes, Receipt& out, std::string& detail) {
    Record r;
    if (!read_record(bytes, r, detail) || !exact_keyset(r, kReceiptKeys, detail)) {
        return false;
    }
    Receipt value{};
    value.schema = r.at("schema");
    value.run_id = r.at("run_id");
    value.proposal_sha256 = r.at("proposal_sha256");
    value.witness_sha256 = r.at("witness_sha256");
    value.trace_sha256 = r.at("trace_sha256");
    if (!u64(r.at("trace_bytes"), value.trace_bytes)) return false;
    value.normalized_sha256 = r.at("normalized_sha256");
    value.replay_manifest_sha256 = r.at("replay_manifest_sha256");
    value.export_close_state = r.at("export_close_state");
    value.publication_id = r.at("publication_id");
    value.subject_sha256 = r.at("subject_sha256");
    const bool fields_ok = value.schema == kReceiptSchema && atom(value.run_id)
        && hash(value.proposal_sha256) && hash(value.witness_sha256)
        && hash(value.trace_sha256) && value.trace_bytes > 0U
        && hash(value.normalized_sha256) && hash(value.replay_manifest_sha256)
        && atom(value.export_close_state) && atom(value.publication_id)
        && hash(value.subject_sha256);
    if (!fields_ok || !exact_bytes(bytes, serialize_receipt(value))) {
        detail = "reference receipt is not canonical";
        return false;
    }
    out = std::move(value);
    return true;
}

}  // namespace slopos::e0::trace_subject
