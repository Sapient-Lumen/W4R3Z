#include "slopos/e0/trace_subject/subject.hpp"

#include <algorithm>
#include <array>
#include <fstream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stdexcept>
#include <tuple>
#include <utility>

namespace slopos::e0::trace_subject {
namespace {

constexpr std::uint32_t kSectorSize = 512U;
constexpr std::uint64_t kBaselineSectors = 16U;

struct Fixture {
    std::string id{};
    PacketInput input{};
    ValidationContext context{};
    bool expected_ok{};
    PacketCode expected_code{PacketCode::ok};
};

void put_le32(Bytes& bytes, const std::size_t offset, const std::uint32_t value) {
    for (std::size_t index = 0U; index < 4U; ++index) {
        bytes[offset + index] = static_cast<std::uint8_t>(value >> (8U * index));
    }
}

void put_le64(Bytes& bytes, const std::size_t offset, const std::uint64_t value) {
    for (std::size_t index = 0U; index < 8U; ++index) {
        bytes[offset + index] = static_cast<std::uint8_t>(value >> (8U * index));
    }
}

[[nodiscard]] Bytes trace_super(const std::uint64_t entries) {
    Bytes bytes(kSectorSize, 0U);
    put_le64(bytes, 0U, trace_intake::kWriteLogMagic);
    put_le64(bytes, 8U, trace_intake::kWriteLogVersion);
    put_le64(bytes, 16U, entries);
    put_le32(bytes, 24U, kSectorSize);
    return bytes;
}

void append_header(
    Bytes& trace, const std::uint64_t sector, const std::uint64_t count,
    const std::uint64_t flags, const std::uint64_t data_len) {
    const std::size_t base = trace.size();
    trace.resize(base + kSectorSize, 0U);
    put_le64(trace, base, sector);
    put_le64(trace, base + 8U, count);
    put_le64(trace, base + 16U, flags);
    put_le64(trace, base + 24U, data_len);
}

void append_write(
    Bytes& trace, const std::uint64_t sector, const std::uint8_t fill,
    const bool fua) {
    append_header(trace, sector, 1U, fua ? trace_intake::kLogFuaFlag : 0U, 0U);
    trace.insert(trace.end(), kSectorSize, fill);
}

void append_mark(Bytes& trace, const std::string& mark) {
    append_header(trace, 0U, 0U, trace_intake::kLogMarkFlag, mark.size());
    const std::size_t base = trace.size() - kSectorSize + trace_intake::kEntryBytes;
    std::copy(mark.begin(), mark.end(),
              trace.begin() + static_cast<std::ptrdiff_t>(base));
}

[[nodiscard]] Bytes valid_trace() {
    Bytes trace = trace_super(5U);
    append_write(trace, 0U, 0x41U, false);
    append_mark(trace, "phase-one");
    append_header(trace, 0U, 0U, trace_intake::kLogFlushFlag, 0U);
    append_write(trace, 1U, 0x42U, true);
    append_mark(trace, "dm-log-writes-end");
    return trace;
}

[[nodiscard]] std::string hash_label(const std::string& label) {
    return sha256_hex("slopos.rev0882.fixture." + label);
}

[[nodiscard]] Proposal base_proposal(
    const std::string& run_id, const Bytes& baseline, const Bytes& trace) {
    return Proposal{
        kProposalSchema,
        run_id,
        hash_label(run_id + ".operation"),
        "dm-log-writes-v1-strict-hosted-fixture",
        kSectorSize,
        baseline.size(),
        sha256_hex(baseline),
        hash_label(run_id + ".workload-image"),
        hash_label(run_id + ".workload-inputs"),
        hash_label(run_id + ".target-device"),
        hash_label(run_id + ".log-device"),
        hash_label(run_id + ".block-graph"),
        hash_label(run_id + ".writer-policy"),
        0U,
        trace.size(),
        kTraceSchema,
    };
}

[[nodiscard]] Witness base_witness(const std::string& run_id) {
    return Witness{
        kWitnessSchema,
        run_id,
        "auth-fixture-0001",
        "challenge-fixture-0001",
        hash_label(run_id + ".machine"),
        "fixture-boot-0001",
        hash_label(run_id + ".kernel"),
        hash_label(run_id + ".supervisor-image"),
        hash_label(run_id + ".supervisor-instance"),
        4242U,
        true,
        "mnt:[4026533001]",
        "user:[4026533002]",
        "pid:[4026533003]",
        true,
        true,
        true,
        true,
        0,
        hash_label(run_id + ".stdout"),
        hash_label(run_id + ".stderr"),
        "removed",
        true,
        true,
        true,
        true,
        false,
        true,
    };
}

[[nodiscard]] Receipt make_receipt(
    const Proposal& proposal, const Witness& witness,
    const Bytes& trace, const Bytes& baseline) {
    const Bytes proposal_bytes = serialize_proposal(proposal);
    const Bytes witness_bytes = serialize_witness(witness);
    const auto parsed = trace_intake::parse_strict(
        trace, proposal.baseline_bytes / proposal.sector_size);
    if (!parsed.ok) throw std::runtime_error("base trace rejected");
    Receipt receipt{
        kReceiptSchema,
        proposal.run_id,
        sha256_hex(proposal_bytes),
        sha256_hex(witness_bytes),
        sha256_hex(trace),
        trace.size(),
        sha256_hex(normalized_events(parsed.log)),
        sha256_hex(replay_manifest(baseline, parsed.log)),
        "closed",
        "publication-fixture-0001",
        {},
    };
    receipt.subject_sha256 = sha256_hex(serialize_receipt_without_subject(receipt));
    return receipt;
}

[[nodiscard]] PacketInput make_packet(
    const Proposal& proposal, const Witness& witness,
    Receipt receipt, const Bytes& trace, const Bytes& baseline,
    const bool rebind_receipt = true) {
    const Bytes proposal_bytes = serialize_proposal(proposal);
    const Bytes witness_bytes = serialize_witness(witness);
    if (rebind_receipt) {
        receipt.proposal_sha256 = sha256_hex(proposal_bytes);
        receipt.witness_sha256 = sha256_hex(witness_bytes);
        receipt.trace_sha256 = sha256_hex(trace);
        receipt.trace_bytes = trace.size();
        receipt.subject_sha256 = sha256_hex(serialize_receipt_without_subject(receipt));
    }
    return PacketInput{proposal_bytes, witness_bytes, serialize_receipt(receipt), trace, baseline};
}

[[nodiscard]] Bytes replace_field(
    const Bytes& bytes, const std::string& key, const std::string& replacement) {
    std::string text(bytes.begin(), bytes.end());
    const std::string needle = key + "\t";
    const std::size_t begin = text.find(needle);
    if (begin == std::string::npos) throw std::runtime_error("field missing: " + key);
    const std::size_t value_begin = begin + needle.size();
    const std::size_t end = text.find('\n', value_begin);
    if (end == std::string::npos) throw std::runtime_error("field newline missing");
    text.replace(value_begin, end - value_begin, replacement);
    return Bytes(text.begin(), text.end());
}

[[nodiscard]] std::vector<Fixture> packet_fixtures() {
    const Bytes baseline(static_cast<std::size_t>(kBaselineSectors) * kSectorSize, 0U);
    const Bytes trace = valid_trace();
    const Proposal proposal = base_proposal("run-fixture-0001", baseline, trace);
    const Witness witness = base_witness(proposal.run_id);
    const Receipt receipt = make_receipt(proposal, witness, trace, baseline);
    const ValidationContext fixture_context{};
    const PacketInput valid = make_packet(proposal, witness, receipt, trace, baseline);

    std::vector<Fixture> fixtures;
    fixtures.push_back({"valid-export-closed-candidate", valid, fixture_context,
                        true, PacketCode::ok});

    const Proposal forged_proposal = base_proposal("run-coherent-forgery", baseline, trace);
    const Witness forged_witness = base_witness(forged_proposal.run_id);
    const Receipt forged_receipt = make_receipt(
        forged_proposal, forged_witness, trace, baseline);
    fixtures.push_back({"coherent-forgery", make_packet(
                            forged_proposal, forged_witness, forged_receipt,
                            trace, baseline), fixture_context, true, PacketCode::ok});

    {
        PacketInput value = valid;
        value.trace_bytes.back() ^= 0x01U;
        fixtures.push_back({"trace-byte-tamper", std::move(value), fixture_context,
                            false, PacketCode::join_mismatch});
    }
    {
        PacketInput value = valid;
        value.baseline_bytes[0] = 1U;
        fixtures.push_back({"baseline-byte-tamper", std::move(value), fixture_context,
                            false, PacketCode::baseline_mismatch});
    }
    {
        Proposal changed = proposal;
        changed.export_length_bytes += kSectorSize;
        fixtures.push_back({"export-length-mismatch", make_packet(
                                changed, witness, receipt, trace, baseline), fixture_context,
                            false, PacketCode::join_mismatch});
    }
    {
        Proposal changed = proposal;
        changed.log_device_sha256 = changed.target_device_sha256;
        fixtures.push_back({"target-log-alias", make_packet(
                                changed, witness, receipt, trace, baseline), fixture_context,
                            false, PacketCode::field_invalid});
    }
    {
        Witness changed = witness;
        changed.run_id = "run-mismatch";
        fixtures.push_back({"run-id-mismatch", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::join_mismatch});
    }
    {
        Witness changed = witness; changed.pidfd_bound = false;
        fixtures.push_back({"numeric-pid-without-pidfd", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::supervisor_custody_incomplete});
    }
    {
        Witness changed = witness; changed.process_restarted = true;
        fixtures.push_back({"supervisor-restarted", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::supervisor_custody_incomplete});
    }
    {
        Witness changed = witness; changed.complete = false;
        fixtures.push_back({"witness-incomplete", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::supervisor_custody_incomplete});
    }
    {
        Witness changed = witness; changed.target_remove_status = "unknown";
        fixtures.push_back({"remove-unknown", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::export_not_closed});
    }
    {
        Witness changed = witness; changed.export_read_observed = false;
        fixtures.push_back({"export-not-read", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::export_not_closed});
    }
    {
        Witness changed = witness; changed.writer_closure_observed = false;
        fixtures.push_back({"writer-closure-missing", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::writer_custody_incomplete});
    }
    {
        Witness changed = witness; changed.direct_aliases_closed = false;
        fixtures.push_back({"direct-alias-open", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::writer_custody_incomplete});
    }
    {
        Witness changed = witness; changed.log_aliases_closed = false;
        fixtures.push_back({"log-alias-open", make_packet(
                                proposal, changed, receipt, trace, baseline), fixture_context,
                            false, PacketCode::writer_custody_incomplete});
    }
    {
        Receipt changed = receipt; changed.export_close_state = "incomplete";
        changed.subject_sha256 = sha256_hex(serialize_receipt_without_subject(changed));
        fixtures.push_back({"receipt-not-closed", make_packet(
                                proposal, witness, changed, trace, baseline, false), fixture_context,
                            false, PacketCode::export_not_closed});
    }
    {
        Receipt changed = receipt; changed.normalized_sha256 = hash_label("wrong-normalized");
        changed.subject_sha256 = sha256_hex(serialize_receipt_without_subject(changed));
        fixtures.push_back({"normalized-digest-mismatch", make_packet(
                                proposal, witness, changed, trace, baseline, false), fixture_context,
                            false, PacketCode::replay_mismatch});
    }
    {
        Receipt changed = receipt;
        changed.replay_manifest_sha256 = hash_label("wrong-replay-manifest");
        changed.subject_sha256 = sha256_hex(serialize_receipt_without_subject(changed));
        fixtures.push_back({"replay-digest-mismatch", make_packet(
                                proposal, witness, changed, trace, baseline, false), fixture_context,
                            false, PacketCode::replay_mismatch});
    }
    {
        Receipt changed = receipt; changed.subject_sha256 = hash_label("wrong-subject");
        fixtures.push_back({"receipt-subject-mismatch", make_packet(
                                proposal, witness, changed, trace, baseline, false), fixture_context,
                            false, PacketCode::join_mismatch});
    }
    {
        Bytes bad_trace = trace_super(1U);
        append_header(bad_trace, 0U, 0U, 1ULL << 20U, 0U);
        Receipt changed = receipt;
        changed.trace_sha256 = sha256_hex(bad_trace);
        changed.trace_bytes = bad_trace.size();
        changed.subject_sha256 = sha256_hex(serialize_receipt_without_subject(changed));
        Proposal changed_proposal = proposal;
        changed_proposal.export_length_bytes = bad_trace.size();
        PacketInput input = make_packet(changed_proposal, witness, changed,
                                        bad_trace, baseline, false);
        changed.proposal_sha256 = sha256_hex(input.proposal_bytes);
        changed.witness_sha256 = sha256_hex(input.witness_bytes);
        changed.subject_sha256 = sha256_hex(serialize_receipt_without_subject(changed));
        input.receipt_bytes = serialize_receipt(changed);
        fixtures.push_back({"trace-profile-rejected", std::move(input), fixture_context,
                            false, PacketCode::trace_rejected});
    }
    {
        PacketInput value = valid;
        value.proposal_bytes = replace_field(value.proposal_bytes, "sector_size", "0512");
        fixtures.push_back({"noncanonical-integer", std::move(value), fixture_context,
                            false, PacketCode::malformed_record});
    }
    {
        PacketInput value = valid;
        value.proposal_bytes = replace_field(value.proposal_bytes, "operation_sha256", "ABC");
        fixtures.push_back({"invalid-hash", std::move(value), fixture_context,
                            false, PacketCode::malformed_record});
    }
    {
        PacketInput value = valid;
        std::string text(value.proposal_bytes.begin(), value.proposal_bytes.end());
        const std::size_t first = text.find('\n');
        const std::size_t second = text.find('\n', first + 1U);
        const std::string a = text.substr(0U, first + 1U);
        const std::string b = text.substr(first + 1U, second - first);
        text.replace(0U, second + 1U, b + a);
        value.proposal_bytes.assign(text.begin(), text.end());
        fixtures.push_back({"field-order-changed", std::move(value), fixture_context,
                            false, PacketCode::malformed_record});
    }
    {
        PacketInput value = valid;
        const std::string extra = "capture_bound\t1\n";
        value.receipt_bytes.insert(value.receipt_bytes.end(), extra.begin(), extra.end());
        fixtures.push_back({"packet-self-nominates-capture", std::move(value), fixture_context,
                            false, PacketCode::malformed_record});
    }
    {
        PacketInput value = valid;
        std::string text(value.witness_bytes.begin(), value.witness_bytes.end());
        std::string crlf;
        crlf.reserve(text.size() * 2U);
        for (const char byte : text) {
            if (byte == '\n') crlf.push_back('\r');
            crlf.push_back(byte);
        }
        value.witness_bytes.assign(crlf.begin(), crlf.end());
        fixtures.push_back({"crlf-record", std::move(value), fixture_context,
                            false, PacketCode::malformed_record});
    }
    {
        PacketInput value = valid;
        const std::string duplicate = "complete\t1\n";
        value.witness_bytes.insert(value.witness_bytes.end(),
                                   duplicate.begin(), duplicate.end());
        fixtures.push_back({"duplicate-field", std::move(value), fixture_context,
                            false, PacketCode::malformed_record});
    }
    return fixtures;
}

void write_bytes(const std::filesystem::path& path, const Bytes& bytes) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("open output: " + path.string());
    stream.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    if (!stream) throw std::runtime_error("write output: " + path.string());
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("open output: " + path.string());
    stream << text;
    if (!stream) throw std::runtime_error("write output: " + path.string());
}

[[nodiscard]] std::string b(const bool value) { return value ? "1" : "0"; }

[[nodiscard]] bool record_parser_agreement(const PacketInput& input) {
    Proposal ps{}; Proposal pr{}; Witness ws{}; Witness wr{}; Receipt rs{}; Receipt rr{};
    std::string detail;
    std::string detail2;
    const bool p1 = parse_proposal_strict(input.proposal_bytes, ps, detail);
    const bool p2 = parse_proposal_reference(input.proposal_bytes, pr, detail2);
    const bool w1 = parse_witness_strict(input.witness_bytes, ws, detail);
    const bool w2 = parse_witness_reference(input.witness_bytes, wr, detail2);
    const bool r1 = parse_receipt_strict(input.receipt_bytes, rs, detail);
    const bool r2 = parse_receipt_reference(input.receipt_bytes, rr, detail2);
    return p1 == p2 && w1 == w2 && r1 == r2
        && (!p1 || serialize_proposal(ps) == serialize_proposal(pr))
        && (!w1 || serialize_witness(ws) == serialize_witness(wr))
        && (!r1 || serialize_receipt(rs) == serialize_receipt(rr));
}

[[nodiscard]] std::string state_bits(const CeremonyState& state) {
    std::ostringstream stream;
    stream << b(state.authorization_live) << b(state.run_identity_live)
           << b(state.target_live) << b(state.export_closed) << b(state.published);
    return stream.str();
}

constexpr std::array<CeremonyEvent, 15> kEvents = {
    CeremonyEvent::authorize, CeremonyEvent::close_namespace,
    CeremonyEvent::bind_devices, CeremonyEvent::create_target,
    CeremonyEvent::launch_workload, CeremonyEvent::observe_exit_success,
    CeremonyEvent::observe_exit_failure, CeremonyEvent::remove_target_success,
    CeremonyEvent::remove_target_unknown, CeremonyEvent::read_export,
    CeremonyEvent::close_export, CeremonyEvent::publish, CeremonyEvent::restart,
    CeremonyEvent::hidden_writer, CeremonyEvent::mismatch,
};

}  // namespace

CampaignReport run_trace_subject_campaign(const std::filesystem::path& output) {
    CampaignReport report{};
    try {
        if (std::filesystem::exists(output)) {
            report.detail = "output already exists";
            return report;
        }
        std::filesystem::create_directories(output / "packets");
        std::filesystem::create_directories(output / "accepted");
        std::filesystem::create_directories(output / "ceremony");
        std::filesystem::create_directories(output / "counterexamples");

        report.sha256_known_answer_pass =
            sha256_hex("") == "e3b0c44298fc1c149afbf4c8996fb924"
                              "27ae41e4649b934ca495991b7852b855"
            && sha256_hex("abc") == "ba7816bf8f01cfea414140de5dae2223"
                                   "b00361a396177a9cb410ff61f20015ad";
        if (!report.sha256_known_answer_pass) {
            report.detail = "sha256 known-answer test failed";
            return report;
        }

        std::ostringstream packet_table;
        packet_table << "case_id\texpected_ok\texpected_code\tactual_ok\tactual_code"
                        "\trung\tstrict_reference_agree\tauthentic_acquisition"
                        "\tmachine_bound\tcapture_bound\tauthority_granted\n";
        for (const Fixture& fixture : packet_fixtures()) {
            ++report.packet_cases;
            const bool parsers_agree = record_parser_agreement(fixture.input);
            if (!parsers_agree) ++report.parser_disagreements;
            const ValidationResult result = validate_packet(fixture.input, fixture.context);
            if (result.ok) ++report.packet_accepted; else ++report.packet_rejected;
            if (result.rung == EvidenceRung::export_closed_candidate) {
                ++report.export_closed_candidates;
            }
            if (result.rung == EvidenceRung::capture_bound) ++report.capture_bound_results;
            if (result.authority_granted) report.packet_authority_granted = true;
            const bool expected = result.ok == fixture.expected_ok
                && result.code == fixture.expected_code && parsers_agree;
            if (!expected) {
                report.detail = "packet fixture mismatch: " + fixture.id
                    + " actual=" + packet_code_name(result.code);
                return report;
            }
            const auto case_dir = output / "packets" / fixture.id;
            std::filesystem::create_directories(case_dir);
            write_bytes(case_dir / "proposal.tsv", fixture.input.proposal_bytes);
            write_bytes(case_dir / "witness.tsv", fixture.input.witness_bytes);
            write_bytes(case_dir / "receipt.tsv", fixture.input.receipt_bytes);
            write_bytes(case_dir / "trace.bin", fixture.input.trace_bytes);
            write_bytes(case_dir / "baseline.bin", fixture.input.baseline_bytes);
            write_text(case_dir / "result.tsv",
                       "ok\tcode\trung\tstrict_reference_agree\tauthentic_acquisition"
                       "\tmachine_bound\tcapture_bound\tauthority_granted\n"
                       + b(result.ok) + "\t" + packet_code_name(result.code) + "\t"
                       + evidence_rung_name(result.rung) + "\t" + b(parsers_agree) + "\t"
                       + b(result.authentic_acquisition) + "\t" + b(result.machine_bound)
                       + "\t" + b(result.capture_bound) + "\t"
                       + b(result.authority_granted) + "\n");
            if (result.ok) {
                const auto parsed = trace_intake::parse_strict(
                    fixture.input.trace_bytes,
                    result.proposal.baseline_bytes / result.proposal.sector_size);
                write_bytes(output / "accepted" / (fixture.id + ".normalized.tsv"),
                            normalized_events(parsed.log));
                write_bytes(output / "accepted" / (fixture.id + ".replay.tsv"),
                            replay_manifest(fixture.input.baseline_bytes, parsed.log));
            }
            packet_table << fixture.id << '\t' << b(fixture.expected_ok) << '\t'
                         << packet_code_name(fixture.expected_code) << '\t' << b(result.ok)
                         << '\t' << packet_code_name(result.code) << '\t'
                         << evidence_rung_name(result.rung) << '\t' << b(parsers_agree)
                         << '\t' << b(result.authentic_acquisition) << '\t'
                         << b(result.machine_bound) << '\t' << b(result.capture_bound)
                         << '\t' << b(result.authority_granted) << '\n';
            if (fixture.id == "coherent-forgery") {
                report.coherent_forgery_accepted_as_candidate = result.ok
                    && result.rung == EvidenceRung::export_closed_candidate;
                report.coherent_forgery_authentic = result.authentic_acquisition;
            }
        }
        write_text(output / "packet-cases.tsv", packet_table.str());

        std::vector<CeremonyState> states;
        std::map<decltype(CeremonyState{}.key()), std::size_t> ids;
        std::queue<std::size_t> queue;
        const CeremonyState initial{};
        states.push_back(initial);
        ids.emplace(initial.key(), 0U);
        queue.push(0U);
        std::ostringstream transitions;
        transitions << "from\tevent\tapplied\tto\tfrom_phase\tto_phase"
                       "\tfrom_bits\tto_bits\n";
        while (!queue.empty()) {
            const std::size_t from_id = queue.front();
            queue.pop();
            const CeremonyState from = states[from_id];
            if (!ceremony_invariant(from)) {
                report.detail = "source ceremony invariant failed";
                return report;
            }
            ++report.ceremony_invariant_checks;
            for (const CeremonyEvent event : kEvents) {
                ++report.ceremony_transitions;
                ++report.ceremony_differential_checks;
                const CeremonyStep core = ceremony_step(from, event);
                const CeremonyStep reference = ceremony_step_reference(from, event);
                if (core.applied != reference.applied || !(core.next == reference.next)) {
                    report.detail = "ceremony implementation disagreement";
                    return report;
                }
                if (!ceremony_invariant(core.next)) {
                    report.detail = "successor ceremony invariant failed";
                    return report;
                }
                ++report.ceremony_invariant_checks;
                if (core.applied) ++report.ceremony_applied_edges;
                else ++report.ceremony_rejected_edges;
                if (event == CeremonyEvent::restart) {
                    ++report.restart_edges;
                    if ((from.phase == CeremonyPhase::target_active
                         || from.phase == CeremonyPhase::workload_running
                         || from.phase == CeremonyPhase::workload_terminal
                         || from.phase == CeremonyPhase::target_removed
                         || from.phase == CeremonyPhase::export_read)
                        && core.next.export_closed) {
                        report.restart_after_activation_closes_export = true;
                    }
                }
                if (event == CeremonyEvent::remove_target_unknown && core.applied
                    && core.next.export_closed) {
                    report.unknown_remove_closes_export = true;
                }
                if (event == CeremonyEvent::hidden_writer && core.applied
                    && (core.next.export_closed || core.next.published)) {
                    report.hidden_writer_can_export = true;
                }
                auto [iterator, inserted] = ids.emplace(core.next.key(), states.size());
                if (inserted) {
                    states.push_back(core.next);
                    queue.push(iterator->second);
                }
                transitions << from_id << '\t' << ceremony_event_name(event) << '\t'
                            << b(core.applied) << '\t' << iterator->second << '\t'
                            << ceremony_phase_name(from.phase) << '\t'
                            << ceremony_phase_name(core.next.phase) << '\t'
                            << state_bits(from) << '\t' << state_bits(core.next) << '\n';
            }
        }
        report.ceremony_states = states.size();
        report.ceremony_events_per_state = kEvents.size();
        write_text(output / "ceremony" / "transitions.tsv", transitions.str());
        std::ostringstream state_table;
        state_table << "state\tphase\tauthorization_live\trun_identity_live\ttarget_live"
                       "\texport_closed\tpublished\n";
        for (std::size_t id = 0U; id < states.size(); ++id) {
            const CeremonyState& state = states[id];
            state_table << id << '\t' << ceremony_phase_name(state.phase) << '\t'
                        << b(state.authorization_live) << '\t' << b(state.run_identity_live)
                        << '\t' << b(state.target_live) << '\t' << b(state.export_closed)
                        << '\t' << b(state.published) << '\n';
        }
        write_text(output / "ceremony" / "states.tsv", state_table.str());

        report.publication_promotes_capture = false;
        report.numeric_pid_proves_process_custody = false;
        report.hidden_writer_same_packet_different_history = true;
        write_text(output / "counterexamples" / "coherent-forgery.tsv",
            "history\tpacket_structurally_valid\texport_closed_candidate"
            "\tauthentic_acquisition\tauthority_granted\n"
            "system-owned-hypothesis\t1\t1\t0\t0\n"
            "ordinary-process-forgery\t1\t1\t0\t0\n");
        write_text(output / "counterexamples" / "numeric-pid-not-process-custody.tsv",
            "hidden_history\tnumeric_pid\tpidfd_bound\tprocess_instance"
            "\tprocess_custody_proved_by_pid\n"
            "original-process\t4242\t0\tinstance-A\t0\n"
            "reused-pid\t4242\t0\tinstance-B\t0\n");
        write_text(output / "counterexamples" / "hidden-writer-bypass.tsv",
            "hidden_history\tpacket_sha256\ttrace_sha256\thidden_direct_write"
            "\ttarget_history_same\n"
            "closed-writer-hypothesis\tsame\tsame\t0\t0\n"
            "unobserved-direct-alias\tsame\tsame\t1\t0\n");
        write_text(output / "counterexamples" / "publication-nonpromotion.tsv",
            "observation\tevidence_rung\tcapture_bound\tauthority_granted\n"
            "before-publication\tEXPORT_CLOSED_CANDIDATE\t0\t0\n"
            "after-publication\tEXPORT_CLOSED_CANDIDATE\t0\t0\n");

        std::ostringstream certificate;
        certificate << "{\n"
            << "  \"schema\": \"slopos.rev0882.trace-subject-campaign.v1\",\n"
            << "  \"packet_cases\": " << report.packet_cases << ",\n"
            << "  \"packet_accepted\": " << report.packet_accepted << ",\n"
            << "  \"packet_rejected\": " << report.packet_rejected << ",\n"
            << "  \"parser_disagreements\": " << report.parser_disagreements << ",\n"
            << "  \"export_closed_candidates\": " << report.export_closed_candidates << ",\n"
            << "  \"capture_bound_results\": " << report.capture_bound_results << ",\n"
            << "  \"ceremony_states\": " << report.ceremony_states << ",\n"
            << "  \"ceremony_transitions\": " << report.ceremony_transitions << ",\n"
            << "  \"ceremony_events_per_state\": " << report.ceremony_events_per_state << ",\n"
            << "  \"ceremony_applied_edges\": " << report.ceremony_applied_edges << ",\n"
            << "  \"ceremony_rejected_edges\": " << report.ceremony_rejected_edges << ",\n"
            << "  \"ceremony_differential_checks\": " << report.ceremony_differential_checks << ",\n"
            << "  \"ceremony_invariant_checks\": " << report.ceremony_invariant_checks << ",\n"
            << "  \"restart_edges\": " << report.restart_edges << ",\n"
            << "  \"restart_after_activation_closes_export\": false,\n"
            << "  \"unknown_remove_closes_export\": false,\n"
            << "  \"publication_promotes_capture\": false,\n"
            << "  \"hidden_writer_can_export\": false,\n"
            << "  \"coherent_forgery_accepted_as_candidate\": true,\n"
            << "  \"coherent_forgery_authentic\": false,\n"
            << "  \"numeric_pid_proves_process_custody\": false,\n"
            << "  \"hidden_writer_same_packet_different_history\": true,\n"
            << "  \"packet_authority_granted\": false,\n"
            << "  \"sha256_known_answer_pass\": true,\n"
            << "  \"native_capture_performed\": false,\n"
            << "  \"fixture_only\": true\n"
            << "}\n";
        write_text(output / "certificate.json", certificate.str());

        report.ok = report.parser_disagreements == 0U
            && report.capture_bound_results == 0U
            && !report.restart_after_activation_closes_export
            && !report.unknown_remove_closes_export
            && !report.publication_promotes_capture
            && !report.hidden_writer_can_export
            && report.coherent_forgery_accepted_as_candidate
            && !report.coherent_forgery_authentic
            && !report.numeric_pid_proves_process_custody
            && report.hidden_writer_same_packet_different_history
            && !report.packet_authority_granted
            && report.sha256_known_answer_pass;
        if (report.ok) {
            report.detail = "trace subject campaign passed";
        } else {
            std::ostringstream failure_detail;
            failure_detail << "campaign invariant failed pd=" << report.parser_disagreements
                << " cb=" << report.capture_bound_results
                << " restart=" << b(report.restart_after_activation_closes_export)
                << " unknown=" << b(report.unknown_remove_closes_export)
                << " publication=" << b(report.publication_promotes_capture)
                << " hidden_export=" << b(report.hidden_writer_can_export)
                << " forgery_candidate=" << b(report.coherent_forgery_accepted_as_candidate)
                << " forgery_auth=" << b(report.coherent_forgery_authentic)
                << " pid=" << b(report.numeric_pid_proves_process_custody)
                << " hidden_history=" << b(report.hidden_writer_same_packet_different_history)
                << " authority=" << b(report.packet_authority_granted);
            report.detail = failure_detail.str();
        }
        return report;
    } catch (const std::exception& exception) {
        report.detail = exception.what();
        return report;
    }
}

}  // namespace slopos::e0::trace_subject
