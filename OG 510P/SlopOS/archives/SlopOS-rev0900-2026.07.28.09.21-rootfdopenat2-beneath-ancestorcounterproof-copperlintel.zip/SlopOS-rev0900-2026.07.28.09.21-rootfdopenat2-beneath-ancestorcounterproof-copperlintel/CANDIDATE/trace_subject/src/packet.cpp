#include "slopos/e0/trace_subject/subject.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <limits>
#include <sstream>
#include <string_view>
#include <utility>

namespace slopos::e0::trace_subject {
namespace {

using Fields = std::vector<std::pair<std::string, std::string>>;

[[nodiscard]] Bytes bytes_from_string(const std::string& text) {
    return Bytes(text.begin(), text.end());
}

[[nodiscard]] std::string string_from_bytes(
    const std::span<const std::uint8_t> bytes) {
    return std::string(bytes.begin(), bytes.end());
}

[[nodiscard]] bool canonical_atom(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 256U) return false;
    return std::all_of(value.begin(), value.end(), [](const char byte) {
        const auto u = static_cast<unsigned char>(byte);
        return u >= 0x21U && u <= 0x7eU && byte != '\t' && byte != '\\';
    });
}

[[nodiscard]] bool parse_u64(
    const std::string_view text, std::uint64_t& value) noexcept {
    if (text.empty() || (text.size() > 1U && text.front() == '0')) return false;
    const char* const begin = text.data();
    const char* const end = begin + static_cast<std::ptrdiff_t>(text.size());
    const auto result = std::from_chars(begin, end, value, 10);
    return result.ec == std::errc{} && result.ptr == end;
}

[[nodiscard]] bool parse_i64(
    const std::string_view text, std::int64_t& value) noexcept {
    if (text.empty()) return false;
    if ((text.size() > 1U && text.front() == '0')
        || (text.size() > 2U && text.front() == '-' && text[1] == '0')
        || text.front() == '+') {
        return false;
    }
    const char* const begin = text.data();
    const char* const end = begin + static_cast<std::ptrdiff_t>(text.size());
    const auto result = std::from_chars(begin, end, value, 10);
    return result.ec == std::errc{} && result.ptr == end;
}

[[nodiscard]] bool parse_bool(
    const std::string_view text, bool& value) noexcept {
    if (text == "1") {
        value = true;
        return true;
    }
    if (text == "0") {
        value = false;
        return true;
    }
    return false;
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "1" : "0";
}

[[nodiscard]] bool exact_fields(
    const std::span<const std::uint8_t> bytes,
    const std::span<const std::string_view> keys,
    Fields& out,
    std::string& detail) {
    if (bytes.empty() || bytes.back() != static_cast<std::uint8_t>('\n')) {
        detail = "record must end with one LF";
        return false;
    }
    const std::string text = string_from_bytes(bytes);
    if (text.find('\r') != std::string::npos || text.find('\0') != std::string::npos) {
        detail = "CR and NUL are forbidden";
        return false;
    }
    std::size_t cursor = 0U;
    out.clear();
    out.reserve(keys.size());
    for (const std::string_view key : keys) {
        const std::size_t newline = text.find('\n', cursor);
        if (newline == std::string::npos) {
            detail = "missing field line";
            return false;
        }
        const std::string_view line(text.data() + static_cast<std::ptrdiff_t>(cursor),
                                    newline - cursor);
        const std::size_t tab = line.find('\t');
        if (tab == std::string_view::npos || line.find('\t', tab + 1U) != std::string_view::npos) {
            detail = "each line must contain one tab";
            return false;
        }
        if (line.substr(0U, tab) != key) {
            detail = "field order/name mismatch at " + std::string(key);
            return false;
        }
        const std::string_view value = line.substr(tab + 1U);
        if (value.empty()) {
            detail = "empty value at " + std::string(key);
            return false;
        }
        out.emplace_back(std::string(key), std::string(value));
        cursor = newline + 1U;
    }
    if (cursor != text.size()) {
        detail = "unknown or trailing fields";
        return false;
    }
    return true;
}

[[nodiscard]] Bytes serialize_fields(const Fields& fields) {
    std::ostringstream stream;
    for (const auto& [key, value] : fields) stream << key << '\t' << value << '\n';
    return bytes_from_string(stream.str());
}

constexpr std::array<std::string_view, 16> kProposalKeys = {
    "schema", "run_id", "operation_sha256", "capture_profile", "sector_size",
    "baseline_bytes", "baseline_sha256", "workload_image_sha256",
    "workload_inputs_sha256", "target_device_sha256", "log_device_sha256",
    "block_graph_sha256", "writer_policy_sha256", "export_offset_bytes",
    "export_length_bytes", "trace_schema",
};

constexpr std::array<std::string_view, 28> kWitnessKeys = {
    "schema", "run_id", "authorization_id", "challenge_id", "machine_sha256",
    "boot_id", "kernel_sha256", "supervisor_image_sha256",
    "supervisor_instance_sha256", "supervisor_pid", "pidfd_bound",
    "mount_namespace", "user_namespace", "pid_namespace", "preclean_observed",
    "target_created_once", "workload_launched_once", "workload_exit_observed",
    "workload_exit_code", "stdout_sha256", "stderr_sha256",
    "target_remove_status", "export_read_observed", "writer_closure_observed",
    "direct_aliases_closed", "log_aliases_closed", "process_restarted", "complete",
};

constexpr std::array<std::string_view, 11> kReceiptKeys = {
    "schema", "run_id", "proposal_sha256", "witness_sha256", "trace_sha256",
    "trace_bytes", "normalized_sha256", "replay_manifest_sha256",
    "export_close_state", "publication_id", "subject_sha256",
};

[[nodiscard]] Fields proposal_fields(const Proposal& value) {
    return {
        {"schema", value.schema}, {"run_id", value.run_id},
        {"operation_sha256", value.operation_sha256},
        {"capture_profile", value.capture_profile},
        {"sector_size", std::to_string(value.sector_size)},
        {"baseline_bytes", std::to_string(value.baseline_bytes)},
        {"baseline_sha256", value.baseline_sha256},
        {"workload_image_sha256", value.workload_image_sha256},
        {"workload_inputs_sha256", value.workload_inputs_sha256},
        {"target_device_sha256", value.target_device_sha256},
        {"log_device_sha256", value.log_device_sha256},
        {"block_graph_sha256", value.block_graph_sha256},
        {"writer_policy_sha256", value.writer_policy_sha256},
        {"export_offset_bytes", std::to_string(value.export_offset_bytes)},
        {"export_length_bytes", std::to_string(value.export_length_bytes)},
        {"trace_schema", value.trace_schema},
    };
}

[[nodiscard]] Fields witness_fields(const Witness& value) {
    return {
        {"schema", value.schema}, {"run_id", value.run_id},
        {"authorization_id", value.authorization_id},
        {"challenge_id", value.challenge_id}, {"machine_sha256", value.machine_sha256},
        {"boot_id", value.boot_id}, {"kernel_sha256", value.kernel_sha256},
        {"supervisor_image_sha256", value.supervisor_image_sha256},
        {"supervisor_instance_sha256", value.supervisor_instance_sha256},
        {"supervisor_pid", std::to_string(value.supervisor_pid)},
        {"pidfd_bound", bool_text(value.pidfd_bound)},
        {"mount_namespace", value.mount_namespace},
        {"user_namespace", value.user_namespace}, {"pid_namespace", value.pid_namespace},
        {"preclean_observed", bool_text(value.preclean_observed)},
        {"target_created_once", bool_text(value.target_created_once)},
        {"workload_launched_once", bool_text(value.workload_launched_once)},
        {"workload_exit_observed", bool_text(value.workload_exit_observed)},
        {"workload_exit_code", std::to_string(value.workload_exit_code)},
        {"stdout_sha256", value.stdout_sha256}, {"stderr_sha256", value.stderr_sha256},
        {"target_remove_status", value.target_remove_status},
        {"export_read_observed", bool_text(value.export_read_observed)},
        {"writer_closure_observed", bool_text(value.writer_closure_observed)},
        {"direct_aliases_closed", bool_text(value.direct_aliases_closed)},
        {"log_aliases_closed", bool_text(value.log_aliases_closed)},
        {"process_restarted", bool_text(value.process_restarted)},
        {"complete", bool_text(value.complete)},
    };
}

[[nodiscard]] Fields receipt_preimage_fields(const Receipt& value) {
    return {
        {"schema", value.schema}, {"run_id", value.run_id},
        {"proposal_sha256", value.proposal_sha256},
        {"witness_sha256", value.witness_sha256}, {"trace_sha256", value.trace_sha256},
        {"trace_bytes", std::to_string(value.trace_bytes)},
        {"normalized_sha256", value.normalized_sha256},
        {"replay_manifest_sha256", value.replay_manifest_sha256},
        {"export_close_state", value.export_close_state},
        {"publication_id", value.publication_id},
    };
}

[[nodiscard]] Fields receipt_fields(const Receipt& value) {
    Fields fields = receipt_preimage_fields(value);
    fields.emplace_back("subject_sha256", value.subject_sha256);
    return fields;
}

[[nodiscard]] bool common_proposal_valid(const Proposal& value) noexcept {
    return value.schema == kProposalSchema && canonical_atom(value.run_id)
        && is_sha256_hex(value.operation_sha256)
        && canonical_atom(value.capture_profile)
        && (value.sector_size == 512U || value.sector_size == 1024U
            || value.sector_size == 2048U || value.sector_size == 4096U)
        && value.baseline_bytes > 0U
        && (value.baseline_bytes % value.sector_size) == 0U
        && is_sha256_hex(value.baseline_sha256)
        && is_sha256_hex(value.workload_image_sha256)
        && is_sha256_hex(value.workload_inputs_sha256)
        && is_sha256_hex(value.target_device_sha256)
        && is_sha256_hex(value.log_device_sha256)
        && is_sha256_hex(value.block_graph_sha256)
        && is_sha256_hex(value.writer_policy_sha256)
        && value.export_offset_bytes == 0U && value.export_length_bytes > 0U
        && value.trace_schema == kTraceSchema;
}

[[nodiscard]] bool common_witness_valid(const Witness& value) noexcept {
    return value.schema == kWitnessSchema && canonical_atom(value.run_id)
        && canonical_atom(value.authorization_id) && canonical_atom(value.challenge_id)
        && is_sha256_hex(value.machine_sha256) && canonical_atom(value.boot_id)
        && is_sha256_hex(value.kernel_sha256)
        && is_sha256_hex(value.supervisor_image_sha256)
        && is_sha256_hex(value.supervisor_instance_sha256)
        && value.supervisor_pid > 0U && canonical_atom(value.mount_namespace)
        && canonical_atom(value.user_namespace) && canonical_atom(value.pid_namespace)
        && is_sha256_hex(value.stdout_sha256) && is_sha256_hex(value.stderr_sha256)
        && canonical_atom(value.target_remove_status);
}

[[nodiscard]] bool common_receipt_valid(const Receipt& value) noexcept {
    return value.schema == kReceiptSchema && canonical_atom(value.run_id)
        && is_sha256_hex(value.proposal_sha256) && is_sha256_hex(value.witness_sha256)
        && is_sha256_hex(value.trace_sha256) && value.trace_bytes > 0U
        && is_sha256_hex(value.normalized_sha256)
        && is_sha256_hex(value.replay_manifest_sha256)
        && canonical_atom(value.export_close_state)
        && canonical_atom(value.publication_id) && is_sha256_hex(value.subject_sha256);
}

[[nodiscard]] bool records_equal(const Proposal& lhs, const Proposal& rhs) noexcept {
    return serialize_proposal(lhs) == serialize_proposal(rhs);
}
[[nodiscard]] bool records_equal(const Witness& lhs, const Witness& rhs) noexcept {
    return serialize_witness(lhs) == serialize_witness(rhs);
}
[[nodiscard]] bool records_equal(const Receipt& lhs, const Receipt& rhs) noexcept {
    return serialize_receipt(lhs) == serialize_receipt(rhs);
}

[[nodiscard]] ValidationResult failure(
    const PacketCode code, std::string detail) {
    ValidationResult result{};
    result.code = code;
    result.detail = std::move(detail);
    return result;
}

}  // namespace

Bytes serialize_proposal(const Proposal& proposal) {
    return serialize_fields(proposal_fields(proposal));
}

Bytes serialize_witness(const Witness& witness) {
    return serialize_fields(witness_fields(witness));
}

Bytes serialize_receipt_without_subject(const Receipt& receipt) {
    return serialize_fields(receipt_preimage_fields(receipt));
}

Bytes serialize_receipt(const Receipt& receipt) {
    return serialize_fields(receipt_fields(receipt));
}

bool parse_proposal_strict(
    const std::span<const std::uint8_t> bytes, Proposal& out, std::string& detail) {
    Fields fields;
    if (!exact_fields(bytes, kProposalKeys, fields, detail)) return false;
    Proposal value{};
    value.schema = fields[0].second;
    value.run_id = fields[1].second;
    value.operation_sha256 = fields[2].second;
    value.capture_profile = fields[3].second;
    if (!parse_u64(fields[4].second, value.sector_size)
        || !parse_u64(fields[5].second, value.baseline_bytes)) {
        detail = "invalid proposal integer";
        return false;
    }
    value.baseline_sha256 = fields[6].second;
    value.workload_image_sha256 = fields[7].second;
    value.workload_inputs_sha256 = fields[8].second;
    value.target_device_sha256 = fields[9].second;
    value.log_device_sha256 = fields[10].second;
    value.block_graph_sha256 = fields[11].second;
    value.writer_policy_sha256 = fields[12].second;
    if (!parse_u64(fields[13].second, value.export_offset_bytes)
        || !parse_u64(fields[14].second, value.export_length_bytes)) {
        detail = "invalid proposal export integer";
        return false;
    }
    value.trace_schema = fields[15].second;
    if (!common_proposal_valid(value)) {
        detail = "proposal field validation failed";
        return false;
    }
    out = std::move(value);
    return true;
}

bool parse_witness_strict(
    const std::span<const std::uint8_t> bytes, Witness& out, std::string& detail) {
    Fields fields;
    if (!exact_fields(bytes, kWitnessKeys, fields, detail)) return false;
    Witness value{};
    value.schema = fields[0].second;
    value.run_id = fields[1].second;
    value.authorization_id = fields[2].second;
    value.challenge_id = fields[3].second;
    value.machine_sha256 = fields[4].second;
    value.boot_id = fields[5].second;
    value.kernel_sha256 = fields[6].second;
    value.supervisor_image_sha256 = fields[7].second;
    value.supervisor_instance_sha256 = fields[8].second;
    if (!parse_u64(fields[9].second, value.supervisor_pid)
        || !parse_bool(fields[10].second, value.pidfd_bound)) {
        detail = "invalid witness pid/pidfd";
        return false;
    }
    value.mount_namespace = fields[11].second;
    value.user_namespace = fields[12].second;
    value.pid_namespace = fields[13].second;
    if (!parse_bool(fields[14].second, value.preclean_observed)
        || !parse_bool(fields[15].second, value.target_created_once)
        || !parse_bool(fields[16].second, value.workload_launched_once)
        || !parse_bool(fields[17].second, value.workload_exit_observed)
        || !parse_i64(fields[18].second, value.workload_exit_code)) {
        detail = "invalid witness lifecycle fields";
        return false;
    }
    value.stdout_sha256 = fields[19].second;
    value.stderr_sha256 = fields[20].second;
    value.target_remove_status = fields[21].second;
    if (!parse_bool(fields[22].second, value.export_read_observed)
        || !parse_bool(fields[23].second, value.writer_closure_observed)
        || !parse_bool(fields[24].second, value.direct_aliases_closed)
        || !parse_bool(fields[25].second, value.log_aliases_closed)
        || !parse_bool(fields[26].second, value.process_restarted)
        || !parse_bool(fields[27].second, value.complete)) {
        detail = "invalid witness closure fields";
        return false;
    }
    if (!common_witness_valid(value)) {
        detail = "witness field validation failed";
        return false;
    }
    out = std::move(value);
    return true;
}

bool parse_receipt_strict(
    const std::span<const std::uint8_t> bytes, Receipt& out, std::string& detail) {
    Fields fields;
    if (!exact_fields(bytes, kReceiptKeys, fields, detail)) return false;
    Receipt value{};
    value.schema = fields[0].second;
    value.run_id = fields[1].second;
    value.proposal_sha256 = fields[2].second;
    value.witness_sha256 = fields[3].second;
    value.trace_sha256 = fields[4].second;
    if (!parse_u64(fields[5].second, value.trace_bytes)) {
        detail = "invalid receipt trace_bytes";
        return false;
    }
    value.normalized_sha256 = fields[6].second;
    value.replay_manifest_sha256 = fields[7].second;
    value.export_close_state = fields[8].second;
    value.publication_id = fields[9].second;
    value.subject_sha256 = fields[10].second;
    if (!common_receipt_valid(value)) {
        detail = "receipt field validation failed";
        return false;
    }
    out = std::move(value);
    return true;
}

Bytes normalized_events(const trace_intake::ParsedLog& log) {
    std::ostringstream stream;
    stream << "schema\tslopos.normalized-dmlog-events.v1\n"
           << "sector_size\t" << log.sector_size << "\n"
           << "event_count\t" << log.events.size() << "\n"
           << "index\tkind\tsector\tnr_sectors\tmetadata\tmark\tdata_bytes\tdata_sha256\n";
    for (const trace_intake::Event& event : log.events) {
        stream << event.index << '\t' << trace_intake::event_kind_name(event.kind)
               << '\t' << event.sector << '\t' << event.nr_sectors << '\t'
               << bool_text(event.metadata) << '\t' << event.mark << '\t'
               << event.data.size() << '\t' << sha256_hex(event.data) << '\n';
    }
    return bytes_from_string(stream.str());
}

Bytes replay_manifest(
    const std::span<const std::uint8_t> baseline,
    const trace_intake::ParsedLog& log) {
    std::ostringstream stream;
    stream << "schema\tslopos.trace-replay-prefix-manifest.v1\n"
           << "baseline_sha256\t" << sha256_hex(baseline) << "\n"
           << "prefixes\t" << (log.events.size() + 1U) << "\n"
           << "prefix\tlast_kind\timage_bytes\timage_sha256\n";
    for (std::size_t prefix = 0U; prefix <= log.events.size(); ++prefix) {
        const Bytes image = trace_intake::replay_prefix(baseline, log, prefix);
        const std::string last_kind = prefix == 0U
            ? "initial" : trace_intake::event_kind_name(log.events[prefix - 1U].kind);
        stream << prefix << '\t' << last_kind << '\t' << image.size() << '\t'
               << sha256_hex(image) << '\n';
    }
    return bytes_from_string(stream.str());
}

ValidationResult validate_packet(
    const PacketInput& input,
    const ValidationContext& context) {
    Proposal strict_proposal{};
    Proposal reference_proposal{};
    Witness strict_witness{};
    Witness reference_witness{};
    Receipt strict_receipt{};
    Receipt reference_receipt{};
    std::string detail;
    if (!parse_proposal_strict(input.proposal_bytes, strict_proposal, detail)
        || !parse_witness_strict(input.witness_bytes, strict_witness, detail)
        || !parse_receipt_strict(input.receipt_bytes, strict_receipt, detail)) {
        return failure(PacketCode::malformed_record, detail);
    }
    std::string reference_detail;
    if (!parse_proposal_reference(input.proposal_bytes, reference_proposal, reference_detail)
        || !parse_witness_reference(input.witness_bytes, reference_witness, reference_detail)
        || !parse_receipt_reference(input.receipt_bytes, reference_receipt, reference_detail)
        || !records_equal(strict_proposal, reference_proposal)
        || !records_equal(strict_witness, reference_witness)
        || !records_equal(strict_receipt, reference_receipt)) {
        return failure(PacketCode::noncanonical_record,
                       "strict/reference record parser disagreement: " + reference_detail);
    }

    ValidationResult result{};
    result.strict_reference_agree = true;
    result.proposal = strict_proposal;
    result.witness = strict_witness;
    result.receipt = strict_receipt;
    result.rung = EvidenceRung::structurally_valid;

    if (strict_proposal.run_id != strict_witness.run_id
        || strict_proposal.run_id != strict_receipt.run_id) {
        return failure(PacketCode::join_mismatch, "run_id join mismatch");
    }
    if (strict_proposal.target_device_sha256 == strict_proposal.log_device_sha256) {
        return failure(PacketCode::field_invalid, "target and log device identities coincide");
    }
    if (strict_proposal.baseline_bytes != input.baseline_bytes.size()
        || strict_proposal.baseline_sha256 != sha256_hex(input.baseline_bytes)) {
        return failure(PacketCode::baseline_mismatch, "baseline bytes or digest mismatch");
    }
    if (strict_proposal.export_length_bytes != input.trace_bytes.size()
        || strict_receipt.trace_bytes != input.trace_bytes.size()) {
        return failure(PacketCode::join_mismatch, "trace byte length join mismatch");
    }
    if (strict_receipt.proposal_sha256 != sha256_hex(input.proposal_bytes)
        || strict_receipt.witness_sha256 != sha256_hex(input.witness_bytes)
        || strict_receipt.trace_sha256 != sha256_hex(input.trace_bytes)) {
        return failure(PacketCode::join_mismatch, "receipt byte identity join mismatch");
    }
    if (strict_receipt.subject_sha256
        != sha256_hex(serialize_receipt_without_subject(strict_receipt))) {
        return failure(PacketCode::join_mismatch, "acyclic receipt subject digest mismatch");
    }

    const std::uint64_t baseline_sectors = strict_proposal.baseline_bytes
        / strict_proposal.sector_size;
    const auto parsed = trace_intake::parse_strict(input.trace_bytes, baseline_sectors);
    const auto parsed_reference = trace_intake::parse_reference(
        input.trace_bytes, baseline_sectors);
    if (!trace_intake::equivalent(parsed, parsed_reference)) {
        return failure(PacketCode::trace_rejected, "trace parser disagreement");
    }
    if (!parsed.ok || parsed.log.sector_size != strict_proposal.sector_size) {
        return failure(PacketCode::trace_rejected,
                       "strict trace intake rejected: " + parsed.detail);
    }
    const Bytes normalized = normalized_events(parsed.log);
    const Bytes replay = replay_manifest(input.baseline_bytes, parsed.log);
    result.normalized_sha256 = sha256_hex(normalized);
    result.replay_manifest_sha256 = sha256_hex(replay);
    if (strict_receipt.normalized_sha256 != result.normalized_sha256
        || strict_receipt.replay_manifest_sha256 != result.replay_manifest_sha256) {
        return failure(PacketCode::replay_mismatch,
                       "normalized event or replay manifest digest mismatch");
    }
    result.rung = EvidenceRung::deterministically_replayed;

    if (!strict_witness.pidfd_bound || strict_witness.process_restarted
        || !strict_witness.preclean_observed || !strict_witness.target_created_once
        || !strict_witness.workload_launched_once
        || !strict_witness.workload_exit_observed || !strict_witness.complete) {
        return failure(PacketCode::supervisor_custody_incomplete,
                       "witness lacks uninterrupted supervisor lifecycle closure");
    }
    if (strict_witness.target_remove_status != "removed"
        || !strict_witness.export_read_observed
        || strict_receipt.export_close_state != "closed") {
        return failure(PacketCode::export_not_closed,
                       "target removal/export closure is not exact");
    }
    if (!strict_witness.writer_closure_observed
        || !strict_witness.direct_aliases_closed
        || !strict_witness.log_aliases_closed) {
        return failure(PacketCode::writer_custody_incomplete,
                       "writer or alias closure is incomplete");
    }
    result.rung = EvidenceRung::export_closed_candidate;

    const bool externally_bound = context.provider_authenticated
        && context.machine_binding_verified
        && context.supervisor_process_custody_verified
        && context.exclusive_writer_verified && !context.fixture_only;
    if (externally_bound) {
        result.rung = EvidenceRung::capture_bound;
        result.capture_bound = true;
        result.authentic_acquisition = true;
        result.machine_bound = true;
    }
    result.ok = true;
    result.code = PacketCode::ok;
    result.authority_granted = false;
    result.detail = "packet accepted without control authority";
    return result;
}

std::string packet_code_name(const PacketCode code) {
    switch (code) {
        case PacketCode::ok: return "OK";
        case PacketCode::malformed_record: return "MALFORMED_RECORD";
        case PacketCode::noncanonical_record: return "NONCANONICAL_RECORD";
        case PacketCode::schema_mismatch: return "SCHEMA_MISMATCH";
        case PacketCode::field_invalid: return "FIELD_INVALID";
        case PacketCode::join_mismatch: return "JOIN_MISMATCH";
        case PacketCode::baseline_mismatch: return "BASELINE_MISMATCH";
        case PacketCode::trace_rejected: return "TRACE_REJECTED";
        case PacketCode::replay_mismatch: return "REPLAY_MISMATCH";
        case PacketCode::export_not_closed: return "EXPORT_NOT_CLOSED";
        case PacketCode::writer_custody_incomplete: return "WRITER_CUSTODY_INCOMPLETE";
        case PacketCode::supervisor_custody_incomplete:
            return "SUPERVISOR_CUSTODY_INCOMPLETE";
    }
    return "UNKNOWN";
}

std::string evidence_rung_name(const EvidenceRung rung) {
    switch (rung) {
        case EvidenceRung::none: return "NONE";
        case EvidenceRung::structurally_valid: return "STRUCTURALLY_VALID";
        case EvidenceRung::deterministically_replayed:
            return "DETERMINISTICALLY_REPLAYED";
        case EvidenceRung::export_closed_candidate:
            return "EXPORT_CLOSED_CANDIDATE";
        case EvidenceRung::capture_bound: return "CAPTURE_BOUND";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::trace_subject
