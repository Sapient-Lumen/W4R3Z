#include "slopos/e0/trace_subject/subject.hpp"

namespace slopos::e0::trace_subject {
namespace {

[[nodiscard]] CeremonyState terminal_state(const CeremonyPhase phase) noexcept {
    return CeremonyState{phase, false, false, false, false, false};
}

[[nodiscard]] CeremonyStep reject(const CeremonyState& state) noexcept {
    return CeremonyStep{false, state};
}

[[nodiscard]] CeremonyStep apply(const CeremonyState& state) noexcept {
    return CeremonyStep{true, state};
}

}  // namespace

CeremonyStep ceremony_step(
    const CeremonyState& state, const CeremonyEvent event) noexcept {
    if (state.phase == CeremonyPhase::failed
        || state.phase == CeremonyPhase::incomplete) {
        return reject(state);
    }
    if (event == CeremonyEvent::mismatch) {
        return apply(terminal_state(CeremonyPhase::failed));
    }
    if (event == CeremonyEvent::hidden_writer) {
        if (state.phase == CeremonyPhase::idle) return reject(state);
        return apply(terminal_state(CeremonyPhase::failed));
    }
    if (event == CeremonyEvent::restart) {
        switch (state.phase) {
            case CeremonyPhase::idle:
            case CeremonyPhase::export_closed:
            case CeremonyPhase::published:
                return reject(state);
            default:
                return apply(terminal_state(CeremonyPhase::incomplete));
        }
    }

    CeremonyState next = state;
    switch (state.phase) {
        case CeremonyPhase::idle:
            if (event != CeremonyEvent::authorize) return reject(state);
            next.phase = CeremonyPhase::authorized;
            next.authorization_live = true;
            return apply(next);
        case CeremonyPhase::authorized:
            if (event != CeremonyEvent::close_namespace) return reject(state);
            next.phase = CeremonyPhase::namespace_closed;
            return apply(next);
        case CeremonyPhase::namespace_closed:
            if (event != CeremonyEvent::bind_devices) return reject(state);
            next.phase = CeremonyPhase::devices_bound;
            return apply(next);
        case CeremonyPhase::devices_bound:
            if (event != CeremonyEvent::create_target || !state.authorization_live) {
                return reject(state);
            }
            next.phase = CeremonyPhase::target_active;
            next.authorization_live = false;
            next.run_identity_live = true;
            next.target_live = true;
            return apply(next);
        case CeremonyPhase::target_active:
            if (event != CeremonyEvent::launch_workload) return reject(state);
            next.phase = CeremonyPhase::workload_running;
            return apply(next);
        case CeremonyPhase::workload_running:
            if (event != CeremonyEvent::observe_exit_success
                && event != CeremonyEvent::observe_exit_failure) {
                return reject(state);
            }
            next.phase = CeremonyPhase::workload_terminal;
            return apply(next);
        case CeremonyPhase::workload_terminal:
            if (event == CeremonyEvent::remove_target_unknown) {
                return apply(terminal_state(CeremonyPhase::incomplete));
            }
            if (event != CeremonyEvent::remove_target_success) return reject(state);
            next.phase = CeremonyPhase::target_removed;
            next.target_live = false;
            return apply(next);
        case CeremonyPhase::target_removed:
            if (event != CeremonyEvent::read_export) return reject(state);
            next.phase = CeremonyPhase::export_read;
            return apply(next);
        case CeremonyPhase::export_read:
            if (event != CeremonyEvent::close_export) return reject(state);
            next.phase = CeremonyPhase::export_closed;
            next.export_closed = true;
            return apply(next);
        case CeremonyPhase::export_closed:
            if (event != CeremonyEvent::publish) return reject(state);
            next.phase = CeremonyPhase::published;
            next.published = true;
            return apply(next);
        case CeremonyPhase::published:
        case CeremonyPhase::failed:
        case CeremonyPhase::incomplete:
            return reject(state);
    }
    return reject(state);
}

CeremonyStep ceremony_step_reference(
    const CeremonyState& state, const CeremonyEvent event) noexcept {
    if (state.phase == CeremonyPhase::failed || state.phase == CeremonyPhase::incomplete) {
        return {false, state};
    }
    if (event == CeremonyEvent::mismatch) {
        return {true, terminal_state(CeremonyPhase::failed)};
    }
    if (event == CeremonyEvent::hidden_writer) {
        return state.phase == CeremonyPhase::idle
            ? CeremonyStep{false, state}
            : CeremonyStep{true, terminal_state(CeremonyPhase::failed)};
    }
    if (event == CeremonyEvent::restart) {
        const bool stable = state.phase == CeremonyPhase::idle
            || state.phase == CeremonyPhase::export_closed
            || state.phase == CeremonyPhase::published;
        return stable ? CeremonyStep{false, state}
                      : CeremonyStep{true, terminal_state(CeremonyPhase::incomplete)};
    }

    const auto move = [&](const CeremonyPhase expected,
                          const CeremonyPhase successor) noexcept {
        if (state.phase != expected) return CeremonyStep{false, state};
        CeremonyState next = state;
        next.phase = successor;
        return CeremonyStep{true, next};
    };

    switch (event) {
        case CeremonyEvent::authorize: {
            CeremonyStep result = move(CeremonyPhase::idle, CeremonyPhase::authorized);
            if (result.applied) result.next.authorization_live = true;
            return result;
        }
        case CeremonyEvent::close_namespace:
            return move(CeremonyPhase::authorized, CeremonyPhase::namespace_closed);
        case CeremonyEvent::bind_devices:
            return move(CeremonyPhase::namespace_closed, CeremonyPhase::devices_bound);
        case CeremonyEvent::create_target: {
            if (state.phase != CeremonyPhase::devices_bound || !state.authorization_live) {
                return {false, state};
            }
            CeremonyState next = state;
            next.phase = CeremonyPhase::target_active;
            next.authorization_live = false;
            next.run_identity_live = true;
            next.target_live = true;
            return {true, next};
        }
        case CeremonyEvent::launch_workload:
            return move(CeremonyPhase::target_active, CeremonyPhase::workload_running);
        case CeremonyEvent::observe_exit_success:
        case CeremonyEvent::observe_exit_failure:
            return move(CeremonyPhase::workload_running, CeremonyPhase::workload_terminal);
        case CeremonyEvent::remove_target_success: {
            CeremonyStep result = move(CeremonyPhase::workload_terminal,
                                       CeremonyPhase::target_removed);
            if (result.applied) result.next.target_live = false;
            return result;
        }
        case CeremonyEvent::remove_target_unknown:
            return state.phase == CeremonyPhase::workload_terminal
                ? CeremonyStep{true, terminal_state(CeremonyPhase::incomplete)}
                : CeremonyStep{false, state};
        case CeremonyEvent::read_export:
            return move(CeremonyPhase::target_removed, CeremonyPhase::export_read);
        case CeremonyEvent::close_export: {
            CeremonyStep result = move(CeremonyPhase::export_read,
                                       CeremonyPhase::export_closed);
            if (result.applied) result.next.export_closed = true;
            return result;
        }
        case CeremonyEvent::publish: {
            CeremonyStep result = move(CeremonyPhase::export_closed,
                                       CeremonyPhase::published);
            if (result.applied) result.next.published = true;
            return result;
        }
        case CeremonyEvent::restart:
        case CeremonyEvent::hidden_writer:
        case CeremonyEvent::mismatch:
            break;
    }
    return {false, state};
}

bool ceremony_invariant(const CeremonyState& state) noexcept {
    switch (state.phase) {
        case CeremonyPhase::idle:
            return !state.authorization_live && !state.run_identity_live
                && !state.target_live && !state.export_closed && !state.published;
        case CeremonyPhase::authorized:
        case CeremonyPhase::namespace_closed:
        case CeremonyPhase::devices_bound:
            return state.authorization_live && !state.run_identity_live
                && !state.target_live && !state.export_closed && !state.published;
        case CeremonyPhase::target_active:
        case CeremonyPhase::workload_running:
        case CeremonyPhase::workload_terminal:
            return !state.authorization_live && state.run_identity_live
                && state.target_live && !state.export_closed && !state.published;
        case CeremonyPhase::target_removed:
        case CeremonyPhase::export_read:
            return !state.authorization_live && state.run_identity_live
                && !state.target_live && !state.export_closed && !state.published;
        case CeremonyPhase::export_closed:
            return !state.authorization_live && state.run_identity_live
                && !state.target_live && state.export_closed && !state.published;
        case CeremonyPhase::published:
            return !state.authorization_live && state.run_identity_live
                && !state.target_live && state.export_closed && state.published;
        case CeremonyPhase::failed:
        case CeremonyPhase::incomplete:
            return !state.authorization_live && !state.run_identity_live
                && !state.target_live && !state.export_closed && !state.published;
    }
    return false;
}

std::string ceremony_phase_name(const CeremonyPhase phase) {
    switch (phase) {
        case CeremonyPhase::idle: return "IDLE";
        case CeremonyPhase::authorized: return "AUTHORIZED";
        case CeremonyPhase::namespace_closed: return "NAMESPACE_CLOSED";
        case CeremonyPhase::devices_bound: return "DEVICES_BOUND";
        case CeremonyPhase::target_active: return "TARGET_ACTIVE";
        case CeremonyPhase::workload_running: return "WORKLOAD_RUNNING";
        case CeremonyPhase::workload_terminal: return "WORKLOAD_TERMINAL";
        case CeremonyPhase::target_removed: return "TARGET_REMOVED";
        case CeremonyPhase::export_read: return "EXPORT_READ";
        case CeremonyPhase::export_closed: return "EXPORT_CLOSED";
        case CeremonyPhase::published: return "PUBLISHED";
        case CeremonyPhase::failed: return "FAILED";
        case CeremonyPhase::incomplete: return "INCOMPLETE";
    }
    return "UNKNOWN";
}

std::string ceremony_event_name(const CeremonyEvent event) {
    switch (event) {
        case CeremonyEvent::authorize: return "AUTHORIZE";
        case CeremonyEvent::close_namespace: return "CLOSE_NAMESPACE";
        case CeremonyEvent::bind_devices: return "BIND_DEVICES";
        case CeremonyEvent::create_target: return "CREATE_TARGET";
        case CeremonyEvent::launch_workload: return "LAUNCH_WORKLOAD";
        case CeremonyEvent::observe_exit_success: return "OBSERVE_EXIT_SUCCESS";
        case CeremonyEvent::observe_exit_failure: return "OBSERVE_EXIT_FAILURE";
        case CeremonyEvent::remove_target_success: return "REMOVE_TARGET_SUCCESS";
        case CeremonyEvent::remove_target_unknown: return "REMOVE_TARGET_UNKNOWN";
        case CeremonyEvent::read_export: return "READ_EXPORT";
        case CeremonyEvent::close_export: return "CLOSE_EXPORT";
        case CeremonyEvent::publish: return "PUBLISH";
        case CeremonyEvent::restart: return "RESTART";
        case CeremonyEvent::hidden_writer: return "HIDDEN_WRITER";
        case CeremonyEvent::mismatch: return "MISMATCH";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::trace_subject
