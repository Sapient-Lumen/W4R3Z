#include "slopos/e0/fence/host.hpp"

#include "slopos/e0/fence/core.hpp"
#include "slopos/e0/fence/rooted.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <vector>

namespace slopos::e0::fence::host {
namespace {

const std::vector<std::uint8_t> kPredecessor{
    'S','L','O','P','O','S','-','P','O','I','N','T','-','V','1','\n','1','\n'};
const std::vector<std::uint8_t> kSuccessor{
    'S','L','O','P','O','S','-','P','O','I','N','T','-','V','1','\n','2','\n'};
const std::vector<std::uint8_t> kPending{
    'S','L','O','P','O','S','-','T','R','A','N','S','I','T','I','O','N','-','V','1','\n'};
const std::vector<std::uint8_t> kNoEffectResult{
    'S','L','O','P','O','S','-','E','N','D','P','O','I','N','T','-','V','1','\n',
    'N','O','_','E','F','F','E','C','T','\n'};
const std::vector<std::uint8_t> kEffectResult{
    'S','L','O','P','O','S','-','E','N','D','P','O','I','N','T','-','V','1','\n',
    'E','F','F','E','C','T','\n'};
const std::vector<std::uint8_t> kEffect{
    'S','L','O','P','O','S','-','T','E','S','T','-','E','F','F','E','C','T','-','V','1','\n',
    'o','p','e','r','a','t','i','o','n','=','4','1','\n'};

template <std::size_t N>
[[nodiscard]] std::span<const std::uint8_t> as_span(
    const std::array<std::uint8_t, N>& value) noexcept {
    return std::span<const std::uint8_t>(value.data(), value.size());
}
[[nodiscard]] bool exact(const FileRead& read,
                         const std::span<const std::uint8_t> expected) noexcept {
    return read.ok && !read.absent && read.bytes.size() == expected.size()
        && std::equal(read.bytes.begin(), read.bytes.end(), expected.begin(),
                      expected.end());
}
[[nodiscard]] bool exact(const FileRead& read,
                         const std::vector<std::uint8_t>& expected) noexcept {
    return exact(read, std::span<const std::uint8_t>(expected.data(),
                                                     expected.size()));
}

[[nodiscard]] std::string durable_kind(const FileRead& journal) {
    if (!journal.ok || journal.absent) return "malformed";
    const Fixtures& f = fixtures();
    const auto eq = [&](const journal::DurableCutV1Image& image) {
        return exact(journal, as_span(image));
    };
    if (eq(f.empty)) return "empty";
    if (eq(f.c1)) return "c1";
    if (eq(f.c2)) return "c2";
    if (eq(f.c3_no_effect)) return "c3-no-effect";
    if (eq(f.c3_effect)) return "c3-effect";
    if (eq(f.c3_uncertain)) return "c3-uncertain";
    if (eq(f.c4_no_effect)) return "c4-no-effect";
    if (eq(f.c4_effect)) return "c4-effect";
    if (eq(f.c4_uncertain)) return "c4-uncertain";
    return "malformed";
}

[[nodiscard]] std::string endpoint_kind(const FileRead& result) {
    if (!result.ok) return "malformed";
    if (result.absent) return "absent";
    if (exact(result, kNoEffectResult)) return "exact-no-effect";
    if (exact(result, kEffectResult)) return "exact-effect";
    return "malformed";
}

[[nodiscard]] std::string external_kind(const FileRead& selector,
                                        const FileRead& confirmed,
                                        const FileRead& pending,
                                        const FileRead& floor) {
    if (!selector.ok || selector.absent || !confirmed.ok || confirmed.absent
        || !pending.ok || !floor.ok || floor.absent) return "malformed";
    const bool sp = exact(selector, kPredecessor);
    const bool ss = exact(selector, kSuccessor);
    const bool cp = exact(confirmed, kPredecessor);
    const bool cs = exact(confirmed, kSuccessor);
    const bool fp = exact(floor, kPredecessor);
    const bool fs = exact(floor, kSuccessor);
    const bool pa = pending.absent;
    const bool pe = exact(pending, kPending);
    if (sp && cp && pa && fp) return "stable-predecessor";
    if (sp && cp && pe && fp) return "prepared";
    if (ss && cp && pe && fp) return "selected-floor-pending";
    if (ss && cp && pe && fs) return "floor-advanced";
    if (ss && cs && pe && fs) return "confirmed-cleanup-pending";
    if (ss && cs && pa && fs) return "stable-successor";
    return "contradictory";
}

[[nodiscard]] bool finish_installation(RootedStore& store,
                                       std::string phase,
                                       std::string& detail) {
    if (phase == "prepared") {
        if (!store.replace(Area::install, "selector.bin", kSuccessor, detail)) {
            return false;
        }
        phase = "selected-floor-pending";
    }
    if (phase == "selected-floor-pending") {
        if (!store.replace(Area::floor, "floor.bin", kSuccessor, detail)) {
            return false;
        }
        phase = "floor-advanced";
    }
    if (phase == "floor-advanced") {
        if (!store.replace(Area::install, "confirmed.bin", kSuccessor,
                           detail)) return false;
        phase = "confirmed-cleanup-pending";
    }
    if (phase == "confirmed-cleanup-pending") {
        if (!store.remove_if_present(Area::install, "pending.bin", detail)) {
            return false;
        }
        phase = "stable-successor";
    }
    if (phase != "stable-successor") {
        detail = "C2 external phase cannot be safely reconciled: " + phase;
        return false;
    }
    return true;
}

}  // namespace

Classification classify(const std::filesystem::path& supplied_root) {
    Classification result{};
    std::string detail;
    auto store_opt = RootedStore::open(
        std::filesystem::absolute(supplied_root), detail);
    if (!store_opt.has_value()) {
        result.detail = detail;
        return result;
    }
    RootedStore& store = *store_opt;
    const FileRead journal = store.read(Area::journal, "current.bin", 1024U);
    const FileRead selector = store.read(Area::install, "selector.bin", 128U);
    const FileRead confirmed = store.read(Area::install, "confirmed.bin", 128U);
    const FileRead pending = store.read(Area::install, "pending.bin", 128U);
    const FileRead floor = store.read(Area::floor, "floor.bin", 128U);
    const FileRead endpoint = store.read(Area::endpoint, "result.bin", 128U);
    const FileRead effect = store.read(Area::effects, "effect.bin", 256U);

    result.durable = durable_kind(journal);
    result.external_phase = external_kind(selector, confirmed, pending, floor);
    result.endpoint_result = endpoint_kind(endpoint);
    if (!effect.ok) {
        result.detail = "effect read failed: " + effect.detail;
        return result;
    }
    if (effect.absent) {
        result.effect_present = false;
    } else if (exact(effect, kEffect)) {
        result.effect_present = true;
    } else {
        result.detail = "malformed effect incumbent";
        return result;
    }
    if (result.endpoint_result == "malformed"
        || result.durable == "malformed"
        || result.external_phase == "malformed"
        || result.external_phase == "contradictory") {
        result.detail = "malformed or contradictory rooted image";
        return result;
    }
    if (result.effect_present
        && result.endpoint_result == "exact-no-effect") {
        result.detail = "effect/no-effect contradiction";
        return result;
    }

    if (result.durable == "empty"
        && result.external_phase == "stable-predecessor"
        && !result.effect_present && result.endpoint_result == "absent") {
        result.label = "EMPTY_STABLE";
    } else if (result.durable == "c1"
               && result.external_phase == "stable-predecessor"
               && !result.effect_present) {
        result.label = "C1_INERT";
    } else if (result.durable == "c1"
               && result.external_phase == "prepared"
               && !result.effect_present) {
        result.label = "C1_PREPARED";
    } else if (result.durable == "c2") {
        const bool allowed_phase = result.external_phase == "prepared"
            || result.external_phase == "selected-floor-pending"
            || result.external_phase == "floor-advanced"
            || result.external_phase == "confirmed-cleanup-pending"
            || result.external_phase == "stable-successor";
        if (!allowed_phase) {
            result.detail = "C2 has invalid installation phase";
            return result;
        }
        if (result.effect_present
            || result.endpoint_result == "exact-effect") {
            result.label = "C2_EFFECT_OBSERVED";
        } else if (result.endpoint_result == "exact-no-effect") {
            result.label = "C2_EXACT_NO_EFFECT_OBSERVED";
        } else {
            // This includes cuts known by the live materializer to precede
            // dispatch.  A cold reopener does not inherit that knowledge.
            result.label = "C2_UNCERTAIN";
        }
    } else if (result.durable == "c3-no-effect"
               && !result.effect_present) {
        result.label = "NO_EFFECT_COMPLETED";
    } else if (result.durable == "c4-no-effect"
               && !result.effect_present) {
        result.label = "NO_EFFECT_PUBLISHED";
    } else if (result.durable == "c3-effect"
               && result.effect_present) {
        result.label = "EFFECT_COMPLETED";
    } else if (result.durable == "c4-effect"
               && result.effect_present) {
        result.label = "EFFECT_PUBLISHED";
    } else if (result.durable == "c3-uncertain") {
        result.label = "UNCERTAINTY_COMPLETED";
    } else if (result.durable == "c4-uncertain") {
        result.label = "UNCERTAINTY_PUBLISHED";
    } else {
        result.detail = "unclassified coherent-looking image";
        return result;
    }
    if (!store.identities_unchanged(detail)) {
        result.detail = detail;
        return result;
    }
    result.ok = true;
    result.detail = "rooted exact classification";
    return result;
}

RecoveryResult recover_without_first_effect(
    const std::filesystem::path& supplied_root) {
    RecoveryResult result{};
    const std::filesystem::path root = std::filesystem::absolute(supplied_root);
    const Classification before = classify(root);
    if (!before.ok) {
        result.detail = "pre-recovery classification: " + before.detail;
        return result;
    }
    result.effect_before = before.effect_present;
    std::string detail;
    auto store_opt = RootedStore::open(root, detail);
    if (!store_opt.has_value()) {
        result.detail = detail;
        return result;
    }
    RootedStore& store = *store_opt;
    const Fixtures& f = fixtures();

    if (before.durable == "c2") {
        if (!finish_installation(store, before.external_phase, detail)) {
            result.detail = detail;
            return result;
        }
        const FileRead endpoint = store.read(
            Area::endpoint, "result.bin", 128U);
        const FileRead effect = store.read(Area::effects, "effect.bin", 256U);
        if (!endpoint.ok || !effect.ok) {
            result.detail = "result/effect reread failed";
            return result;
        }
        if ((!effect.absent && exact(effect, kEffect))
            || exact(endpoint, kEffectResult)) {
            if (!store.replace(Area::journal, "current.bin",
                               as_span(f.c3_effect), detail)
                || !store.replace(Area::journal, "current.bin",
                                  as_span(f.c4_effect), detail)) {
                result.detail = detail;
                return result;
            }
        } else if (exact(endpoint, kNoEffectResult)) {
            if (!store.replace(Area::journal, "current.bin",
                               as_span(f.c3_no_effect), detail)
                || !store.replace(Area::journal, "current.bin",
                                  as_span(f.c4_no_effect), detail)) {
                result.detail = detail;
                return result;
            }
        } else {
            // Ordinary absence and malformed/unavailable endpoint evidence are
            // retained as uncertainty.  Recovery never converts them to
            // no-effect and never creates the selected effect.
            if (!store.replace(Area::journal, "current.bin",
                               as_span(f.c3_uncertain), detail)
                || !store.replace(Area::journal, "current.bin",
                                  as_span(f.c4_uncertain), detail)) {
                result.detail = detail;
                return result;
            }
        }
    } else if (before.durable == "c3-effect") {
        if (!store.replace(Area::journal, "current.bin",
                           as_span(f.c4_effect), detail)) {
            result.detail = detail;
            return result;
        }
    } else if (before.durable == "c3-no-effect") {
        if (!store.replace(Area::journal, "current.bin",
                           as_span(f.c4_no_effect), detail)) {
            result.detail = detail;
            return result;
        }
    } else if (before.durable == "c3-uncertain") {
        if (!store.replace(Area::journal, "current.bin",
                           as_span(f.c4_uncertain), detail)) {
            result.detail = detail;
            return result;
        }
    }

    result.after = classify(root);
    result.effect_after = result.after.effect_present;
    result.created_first_effect = !result.effect_before && result.effect_after;
    result.ok = result.after.ok && !result.created_first_effect;
    result.detail = result.ok
        ? "recovery reconciled installation and terminal result without first effect"
        : "recovery classification or first-effect fence failed";
    return result;
}

}  // namespace slopos::e0::fence::host
