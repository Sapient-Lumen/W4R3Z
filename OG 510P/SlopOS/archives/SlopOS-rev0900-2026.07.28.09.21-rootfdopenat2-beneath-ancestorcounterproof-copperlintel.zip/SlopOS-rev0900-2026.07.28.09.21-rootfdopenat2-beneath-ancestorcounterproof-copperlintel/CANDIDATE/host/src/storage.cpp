#include "slopos/e0/fence/host.hpp"

#include "slopos/e0/fence/core.hpp"
#include "slopos/e0/fence/rooted.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <span>
#include <string>
#include <vector>

namespace slopos::e0::fence::host {
namespace {

const std::vector<std::uint8_t> kPredecessor{
    'S','L','O','P','O','S','-','P','O','I','N','T','-','V','1','\n','1','\n'};
const std::vector<std::uint8_t> kSuccessor{
    'S','L','O','P','O','S','-','P','O','I','N','T','-','V','1','\n','2','\n'};
const std::vector<std::uint8_t> kPending{
    'S','L','O','P','O','S','-','T','R','A','N','S','I','T','I','O','N','-','V','1','\n'};
const std::vector<std::uint8_t> kNoEffectResult{
    'S','L','O','P','O','S','-','E','N','D','P','O','I','N','T','-','V','1','\n',
    'N','O','_','E','F','F','E','C','T','\n'};
const std::vector<std::uint8_t> kEffectResult{
    'S','L','O','P','O','S','-','E','N','D','P','O','I','N','T','-','V','1','\n',
    'E','F','F','E','C','T','\n'};
const std::vector<std::uint8_t> kEffect{
    'S','L','O','P','O','S','-','T','E','S','T','-','E','F','F','E','C','T','-','V','1','\n',
    'o','p','e','r','a','t','i','o','n','=','4','1','\n'};
const std::vector<std::uint8_t> kProfile{
    'H','O','S','T','E','D','-','T','E','S','T','-','O','N','L','Y','\n',
    'N','O','T','-','A','-','P','R','O','T','E','C','T','E','D','-','E','N','D','P','O','I','N','T','\n'};

[[nodiscard]] bool prepare_layout(const std::filesystem::path& root,
                                  std::string& detail) {
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    ec.clear();
    for (const char* name : {"journal", "install", "floor", "endpoint",
                             "effects", "meta"}) {
        std::filesystem::create_directories(root / name, ec);
        if (ec) {
            detail = "create layout: " + ec.message();
            return false;
        }
        std::filesystem::permissions(
            root / name, std::filesystem::perms::owner_all,
            std::filesystem::perm_options::replace, ec);
        if (ec) {
            detail = "chmod child: " + ec.message();
            return false;
        }
    }
    std::filesystem::permissions(root, std::filesystem::perms::owner_all,
        std::filesystem::perm_options::replace, ec);
    if (ec) {
        detail = "chmod root: " + ec.message();
        return false;
    }
    return true;
}

template <std::size_t N>
[[nodiscard]] std::span<const std::uint8_t> as_span(
    const std::array<std::uint8_t, N>& value) noexcept {
    return std::span<const std::uint8_t>(value.data(), value.size());
}

[[nodiscard]] bool at_or_after(const Cut value, const Cut threshold) noexcept {
    return static_cast<std::size_t>(value) >= static_cast<std::size_t>(threshold);
}

[[nodiscard]] bool write_cut_meta(RootedStore& store, const Cut cut,
                                  std::string& detail) {
    const std::string text = std::string(cut_name(cut)) + "\n";
    const std::vector<std::uint8_t> data(text.begin(), text.end());
    return store.replace(Area::meta, "cut.txt", data, detail);
}

}  // namespace

std::string_view cut_name(const Cut cut) noexcept {
    switch (cut) {
        case Cut::initialized: return "00-initialized";
        case Cut::c1_admitted: return "01-c1-admitted";
        case Cut::pending_retained: return "02-pending-retained";
        case Cut::c2_readback: return "03-c2-readback";
        case Cut::selector_advanced: return "04-selector-advanced";
        case Cut::floor_advanced: return "05-floor-advanced";
        case Cut::confirmed_advanced: return "06-confirmed-advanced";
        case Cut::pending_retired: return "07-pending-retired";
        case Cut::activation_consumed: return "08-activation-consumed";
        case Cut::dispatch_entered: return "09-dispatch-entered";
        case Cut::exact_no_effect_result: return "10-exact-no-effect-result";
        case Cut::effect_observed: return "11-effect-observed";
        case Cut::c3_effect_completed: return "12-c3-effect-completed";
        case Cut::c4_effect_published: return "13-c4-effect-published";
    }
    return "unknown";
}
bool parse_cut(const std::string_view text, Cut& cut) noexcept {
    for (const Cut candidate : kCuts) {
        if (cut_name(candidate) == text) {
            cut = candidate;
            return true;
        }
    }
    return false;
}

bool materialize_cut(const std::filesystem::path& supplied_root,
                     const Cut cut, std::string& detail) {
    const std::filesystem::path root = std::filesystem::absolute(supplied_root);
    if (!prepare_layout(root, detail)) return false;
    std::string open_detail;
    auto store_opt = RootedStore::open(root, open_detail);
    if (!store_opt.has_value()) {
        detail = open_detail;
        return false;
    }
    RootedStore& store = *store_opt;
    const Fixtures& f = fixtures();
    if (!store.replace(Area::journal, "current.bin", as_span(f.empty), detail)
        || !store.replace(Area::install, "selector.bin", kPredecessor, detail)
        || !store.replace(Area::install, "confirmed.bin", kPredecessor, detail)
        || !store.replace(Area::floor, "floor.bin", kPredecessor, detail)
        || !store.replace(Area::meta, "PROFILE.txt", kProfile, detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::c1_admitted)
        && !store.replace(Area::journal, "current.bin", as_span(f.c1), detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::pending_retained)
        && !store.replace(Area::install, "pending.bin", kPending, detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::c2_readback)
        && !store.replace(Area::journal, "current.bin", as_span(f.c2), detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::selector_advanced)
        && !store.replace(Area::install, "selector.bin", kSuccessor, detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::floor_advanced)
        && !store.replace(Area::floor, "floor.bin", kSuccessor, detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::confirmed_advanced)
        && !store.replace(Area::install, "confirmed.bin", kSuccessor, detail)) {
        return false;
    }
    if (at_or_after(cut, Cut::pending_retired)
        && !store.remove_if_present(Area::install, "pending.bin", detail)) {
        return false;
    }

    if (cut == Cut::exact_no_effect_result) {
        if (!store.replace(Area::endpoint, "result.bin", kNoEffectResult,
                           detail)) return false;
    } else if (cut == Cut::effect_observed
               || cut == Cut::c3_effect_completed
               || cut == Cut::c4_effect_published) {
        const CreateStatus created = store.create_no_replace(
            Area::effects, "effect.bin", kEffect, detail);
        if (created != CreateStatus::created) return false;
        if (!store.replace(Area::endpoint, "result.bin", kEffectResult,
                           detail)) return false;
    }
    if (cut == Cut::c3_effect_completed
        || cut == Cut::c4_effect_published) {
        if (!store.replace(Area::journal, "current.bin",
                           as_span(f.c3_effect), detail)) return false;
    }
    if (cut == Cut::c4_effect_published
        && !store.replace(Area::journal, "current.bin",
                          as_span(f.c4_effect), detail)) return false;

    if (!write_cut_meta(store, cut, detail)) return false;
    if (!store.identities_unchanged(detail)) return false;
    detail = "rooted hosted cut materialized";
    return true;
}

bool dump_schema(const std::filesystem::path& root, std::string& detail) {
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    std::filesystem::create_directories(root, ec);
    if (ec) {
        detail = "create schema root: " + ec.message();
        return false;
    }
    auto write = [&](const std::string& name,
                     const std::span<const std::uint8_t> data) {
        std::ofstream out(root / name, std::ios::binary | std::ios::trunc);
        out.write(reinterpret_cast<const char*>(data.data()),
                  static_cast<std::streamsize>(data.size()));
        return out.good();
    };
    const Fixtures& f = fixtures();
    const std::array<std::pair<const char*, journal::DurableCutV1Image>, 9U>
        images{{
            {"empty.bin", f.empty}, {"c1.bin", f.c1}, {"c2.bin", f.c2},
            {"c3-no-effect.bin", f.c3_no_effect},
            {"c3-effect.bin", f.c3_effect},
            {"c3-uncertain.bin", f.c3_uncertain},
            {"c4-no-effect.bin", f.c4_no_effect},
            {"c4-effect.bin", f.c4_effect},
            {"c4-uncertain.bin", f.c4_uncertain},
        }};
    for (const auto& [name, image] : images) {
        if (!write(name, as_span(image))) {
            detail = "write schema image";
            return false;
        }
    }
    if (!write("predecessor.bin", kPredecessor)
        || !write("successor.bin", kSuccessor)
        || !write("pending.bin", kPending)
        || !write("endpoint-no-effect.bin", kNoEffectResult)
        || !write("endpoint-effect.bin", kEffectResult)
        || !write("effect.bin", kEffect)) {
        detail = "write schema object";
        return false;
    }
    detail = "schema dumped";
    return true;
}

}  // namespace slopos::e0::fence::host
