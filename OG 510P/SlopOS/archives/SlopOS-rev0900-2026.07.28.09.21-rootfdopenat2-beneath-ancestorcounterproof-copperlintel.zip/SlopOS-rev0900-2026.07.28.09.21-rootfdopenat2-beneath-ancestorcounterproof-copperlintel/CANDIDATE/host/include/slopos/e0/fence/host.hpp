#pragma once

#include <array>
#include <cstddef>
#include <filesystem>
#include <string>
#include <string_view>

namespace slopos::e0::fence::host {

enum class Cut : std::size_t {
    initialized,
    c1_admitted,
    pending_retained,
    c2_readback,
    selector_advanced,
    floor_advanced,
    confirmed_advanced,
    pending_retired,
    activation_consumed,
    dispatch_entered,
    exact_no_effect_result,
    effect_observed,
    c3_effect_completed,
    c4_effect_published,
};

inline constexpr std::array<Cut, 14U> kCuts{{
    Cut::initialized, Cut::c1_admitted, Cut::pending_retained,
    Cut::c2_readback, Cut::selector_advanced, Cut::floor_advanced,
    Cut::confirmed_advanced, Cut::pending_retired,
    Cut::activation_consumed, Cut::dispatch_entered,
    Cut::exact_no_effect_result, Cut::effect_observed,
    Cut::c3_effect_completed, Cut::c4_effect_published,
}};

struct Classification final {
    bool ok{};
    std::string label{};
    std::string durable{};
    std::string external_phase{};
    std::string endpoint_result{};
    bool effect_present{};
    std::string detail{};
};

struct RecoveryResult final {
    bool ok{};
    bool effect_before{};
    bool effect_after{};
    bool created_first_effect{};
    Classification after{};
    std::string detail{};
};

struct CampaignReport final {
    bool ok{};
    std::size_t cuts{};
    std::size_t classifications{};
    std::size_t recoveries{};
    std::size_t recovery_created_effects{};
    std::size_t uncertainty_publications{};
    std::size_t no_effect_publications{};
    std::size_t effect_publications{};
    std::string detail{};
};

[[nodiscard]] std::string_view cut_name(Cut cut) noexcept;
[[nodiscard]] bool parse_cut(std::string_view text, Cut& cut) noexcept;
[[nodiscard]] bool materialize_cut(const std::filesystem::path& root,
                                   Cut cut, std::string& detail);
[[nodiscard]] Classification classify(const std::filesystem::path& root);
[[nodiscard]] RecoveryResult recover_without_first_effect(
    const std::filesystem::path& root);
[[nodiscard]] bool dump_schema(const std::filesystem::path& root,
                               std::string& detail);
[[nodiscard]] CampaignReport run_campaign(const std::filesystem::path& root,
                                          const std::filesystem::path& self);

}  // namespace slopos::e0::fence::host
