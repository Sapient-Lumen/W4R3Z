# Candidate source map

Everything in this directory is nonauthoritative Epoch-Zero source.  Private
constructors, move-only values, deterministic campaigns, and byte-identical
compiler products do not create protected authority.

## Current proof seam

- `core_gate/` — C++20 finite relation for burn-before-validation, fixed effect,
  one dispatch receipt, and no recovery mint.
- `generation_journal/` — C++20 finite relation and canonical 128-byte record
  codec for exact pending identity, one fixed consecutive-generation endpoint,
  immutable result versions, and query-only reconciliation.
- `handoff_cell/` — Linux C++20 feasibility construction for one fixed
  `live -> pending` `RENAME_NOREPLACE` admission cut.  It depends only on the
  generation-journal codec files named in its retained source manifest.

These packages are source islands, not one protected product.  Their refinement
and open gap are documented in `DESIGN/HANDOFF-CELL-REFINEMENT.md`.

## Retained older subjects

Other directories preserve earlier hosted relations, parsers, crash-image and
trace experiments.  They remain available for regression and excavation but
are not automatically current product work.  `OFFICE/DOCUMENT-REGISTER.tsv`
defines the maintained reading surface.

## Boundary

Candidate source must not compile against or read `OFFICE/`, `EVIDENCE/`,
`EXCAVATION/`, `REVIEW/`, `RESEARCH/`, or `PREDECESSOR/`.  Vault extracts are
premises, retained evidence is observation, and office prose is governance
state.  None may be laundered into source authority.

## Rev0898 handoff V10

`handoff_cell` now includes an exact etcd v3.6.14 release/transaction profile
and query-only dossier classifier. It is deliberately non-operational: no etcd
runtime, transport, provider mutation, response, retry or effect route is added.

# rev0898 — exact etcd v3.6.14 profile gate, query-only classifier, runtime stop

- Reopened exact rev0897 as the sole parent and preserved exact rev0874 as the
  last sealed living lineage.
- Added package-local C++20 V10 release/profile constants, a deterministic
  four-compare/three-write/four-query plan and an ordered query-only dossier
  classifier with no socket, process, provider mutation, retry, response,
  endpoint parser, claim, settlement or effect route.
- Retained nineteen V10 cases and seven countermodels. Exactly one row is an
  actual host observation and reports `RUNTIME_UNAVAILABLE`; all eighteen other
  dossiers are explicitly synthetic.
- Reconstructed 56 exact source inputs into 36 canonical products totaling
  50,122 bytes per Clang, GCC and Clang ASan/UBSan lane; every product is
  byte-identical and the independent oracle reports no disagreement.
- Retained the official v3.6.14 checksum product and built a whole-archive
  fail-closed admission gate. Missing, wrong-digest, traversal, symlink,
  duplicate, nonregular, incomplete and version-mismatch inputs cannot become
  an admitted release.
- Kept the actual gate result at `STOP / RELEASE_ARCHIVE_MISSING`; no cluster or
  provider transaction was fabricated.
- Extended the zero-copy provider-history custody spine to 37 exact sources,
  232,458 bytes, 25 laws, 14 countermodels and five build inputs.
- Advanced Repository V22 without adding a semantic island, SDK, daemon,
  database abstraction, queue or retry worker.
- Judgment: remain Epoch Zero. The next admissible work must operate and
  independently appraise the exact profile with complete administration,
  restore succession and external currentness premises.

## Rev0899 handoff V11

V11 adds descriptor-pinned, write-sealed passive release ingress. The host
adapter opens one locator once, captures a complete anonymous memfd, applies and
verifies the write/grow/shrink/seal barrier, then compares the pinned digest
before any archive semantics. The pure relation requires a coherent observation
prefix and rejects early parse even when a later digest mismatch would also
reject. It opens no path or process itself, grants no activation authority, and
keeps the exact archive-absent host result explicit.

The retained V11/V12 evidence has 72 audited sources, 52 canonical products and
76,154 bytes per lane. V11 retains seventeen relation cases, nine countermodels,
twelve Linux descriptor cases and six syscall counterexamples. V12 adds
twenty-four rooted relation cases, eleven countermodels, twenty-one root-FD syscall
cases and eleven syscall counterexamples.

## Rev0900 handoff V12

V12 adds a caller-rooted fixed-leaf release locator without adding a semantic
island. The pure C++20 relation requires an already-pinned `O_PATH` directory,
a fixed archive leaf, and the complete `openat2` beneath/no-symlink/no-magic-
link/no-cross-mount policy. A separate host probe distinguishes a pinned root from a reopened pathname
after replacement, retains profile-drift and ABA controls, and proves that a
rooted regular leaf still is not immutable content. Its ancestor-symlink case
uses a deliberately widened regression path; the production leaf is one exact
component.

The Python admission tool now supports a fail-closed `--root-fd` mode that
enters the existing V11 write-sealed snapshot pipeline. It accepts no root path
or leaf argument and grants no owner, provenance, activation, provider, or
epoch authority. The retained host stops before leaf acquisition because `OPENAT2_REGULAR` is
unavailable; the exact archive is independently absent.
