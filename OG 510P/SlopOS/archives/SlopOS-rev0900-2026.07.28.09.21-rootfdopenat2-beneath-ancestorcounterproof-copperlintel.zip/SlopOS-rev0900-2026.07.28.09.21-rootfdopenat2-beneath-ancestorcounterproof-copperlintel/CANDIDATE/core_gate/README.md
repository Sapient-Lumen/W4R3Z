# Epoch-Zero core gate

This is a small hosted construction of the prospective SlopOS product nucleus,
not a new acquisition/provider family. It carries one exact state relation from
bound evidence through separate appraisal and relying-party decision to one
volatile permit, one gate entry, one endpoint result, reconciliation, and
publication.

The candidate transition function and C++ reference are independently spelled.
`proof/verify_relation.py` is a third implementation that reconstructs the
entire reachable relation from retained TSV output. Clang and GCC outputs are
required to be byte-identical, and a sanitizer lane executes the same campaign.

A deny decision is deliberately inert inside this gate; a denial response is
not modeled as `NO_EFFECT`. Publication closes v1, so later supersession of a
published `UNCERTAIN` result remains a generation-journal interface obligation.

It proves only finite protocol shape. It does **not** authenticate evidence,
constitute owners, protect a capability, isolate an endpoint, prove stable
storage, bind a machine, or supply an independent actor.
