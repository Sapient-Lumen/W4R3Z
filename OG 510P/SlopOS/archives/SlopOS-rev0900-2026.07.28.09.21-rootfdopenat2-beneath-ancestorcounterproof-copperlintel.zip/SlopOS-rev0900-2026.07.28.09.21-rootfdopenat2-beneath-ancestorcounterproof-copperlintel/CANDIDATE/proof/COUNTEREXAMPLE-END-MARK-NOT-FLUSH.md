# Counterexample: end mark is not target flush

The accepted `end-mark-no-flush` fixture contains one plain write followed by the
exact `dm-log-writes-end` mark and contains no flush or FUA event. Strict parsing
and deterministic replay therefore accept an end-marked log for which the
normalized target-flush count is zero.

The witness refutes `end mark -> target device flushed`. It does not assert how a
particular kernel/device pair persisted the write.
