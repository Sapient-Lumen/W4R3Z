# Counterexample: local absence is not no-effect

Consider the cold observation:

```text
journal = exact C2
local effect marker = absent
```

It is compatible with at least these histories:

- dispatch was never entered;
- dispatch entered and produced no effect, then no return arrived;
- the effect occurred but its local marker was not retained;
- an exact no-effect result exists outside the local observation;
- an exact effect result exists outside the local observation;
- the endpoint produced an effect and only a malformed result was observed.

At least one history has no effect and at least one has an effect. Therefore no
deterministic function of that local observation alone can soundly produce
`NO_EFFECT` for all represented histories.

Rev0879 carries the collision as a small generated table and rechecks it in a
second language. The correction is a three-way result: exact effect, exact
no-effect, or uncertainty.
