# Counterexample: digest text without algorithm identity

Two inherited lanes labeled a 64-bit value as FNV-1a while using different offset
bases. Equal labels did not denote one algorithm, and consumers could not infer
the variant from the hexadecimal width.

Rev0881 therefore requires algorithm, encoding, canonicalization, domain, byte
length, and digest value to travel together. FNV-1a remains diagnostic only.
