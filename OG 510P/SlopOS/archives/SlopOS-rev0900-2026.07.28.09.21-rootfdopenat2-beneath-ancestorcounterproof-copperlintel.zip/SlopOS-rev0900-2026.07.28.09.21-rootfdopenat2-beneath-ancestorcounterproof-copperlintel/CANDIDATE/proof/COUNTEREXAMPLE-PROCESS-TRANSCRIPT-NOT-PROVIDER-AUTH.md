# Counterexample: transcript is not provider authentication

Every field in `slopos.process-report.v1` can be produced by ordinary user-space
code. Canonical syntax, parser agreement and coherent joins do not identify the
actor that produced the report or establish that a separately constituted
provider controlled the observation.

Provider authentication must arrive from an external trust relation and still
produces neutral evidence rather than effect authority.
