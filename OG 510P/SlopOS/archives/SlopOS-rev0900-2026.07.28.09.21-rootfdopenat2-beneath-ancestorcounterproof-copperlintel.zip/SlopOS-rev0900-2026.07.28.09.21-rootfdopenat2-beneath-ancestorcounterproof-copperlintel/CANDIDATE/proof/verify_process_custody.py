#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

SCHEMA = "slopos.rev0883.process-custody-campaign.v1"
AUDIT_SCHEMA = "slopos.rev0883.process-custody-audit.v1"


def fail(detail: str) -> None:
    raise SystemExit(f"PROCESS_CUSTODY_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path, header: list[str]) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != header:
            fail(f"header={path.name}")
        return list(reader)


def bit(value: str, label: str) -> bool:
    if value == "true":
        return True
    if value == "false":
        return False
    fail(f"boolean={label}:{value}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Source-separated rev0883 process-custody audit")
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    root = args.campaign.resolve()

    certificate = json.loads((root / "certificate.json").read_text(encoding="utf-8"))
    expected_certificate = {
        "authority_bearing_results": 0,
        "counterexamples": 5,
        "executable_continuity_bound": False,
        "fail_closed_cases": 2,
        "fixture_transcript_provider_authenticated": False,
        "launch_closed_candidates": 9,
        "live_cases": 14,
        "model_applied": 8,
        "model_events_per_state": 8,
        "model_rejected": 64,
        "model_states": 9,
        "model_transitions": 72,
        "parser_cases": 22,
        "parser_disagreements": 0,
        "process_custody_results": 0,
        "provider_authenticated_results": 0,
        "schema": SCHEMA,
        "status": "PASS",
    }
    if certificate != expected_certificate:
        fail("certificate")

    parser_rows = read_tsv(root / "parser-cases.tsv", [
        "case", "expected_accepted", "strict_accepted", "reference_accepted",
        "strict_code", "reference_code", "agree",
    ])
    if len(parser_rows) != 22 or len({row["case"] for row in parser_rows}) != 22:
        fail("parser-case-count")
    for row in parser_rows:
        expected = bit(row["expected_accepted"], row["case"])
        strict = bit(row["strict_accepted"], row["case"])
        reference = bit(row["reference_accepted"], row["case"])
        if expected != strict or strict != reference or not bit(row["agree"], row["case"]):
            fail(f"parser-disagreement={row['case']}")
        if row["strict_code"] != row["reference_code"]:
            fail(f"parser-code={row['case']}")

    live_header = [
        "case", "disposition", "launch_closed_candidate", "fail_closed", "pidfd_bound",
        "same_process_lifetime", "descriptor_selected_exec", "path_rebind_retained_inode",
        "absolute_path_bypassed_dirfd", "executable_replaced", "no_new_privs_persisted",
        "nonroot_zero_capability_floor", "stdio_normalized", "descriptor_topology_closed",
        "exact_executable_join", "parser_agreement", "terminal_wait_by_pidfd",
        "provider_authenticated", "authority_granted",
    ]
    live = read_tsv(root / "live-cases.tsv", live_header)
    if len(live) != 14 or len({row["case"] for row in live}) != 14:
        fail("live-case-count")
    by_name = {row["case"]: row for row in live}
    topology = {f"stdio-topology-{mask:03b}" for mask in range(8)}
    candidates = topology | {"path-rebind-retained-execfd"}
    fail_closed = {
        "unexpected-descriptor-fails-closed",
        "report-executable-mismatch-fails-closed",
    }
    observed_counterexamples = {
        "absolute-execveat-ignores-dirfd",
        "pidfd-spans-exec-replacement",
        "no-new-privs-persists-across-exec",
    }
    if set(by_name) != candidates | fail_closed | observed_counterexamples:
        fail("live-case-set")
    for name, row in by_name.items():
        if bit(row["provider_authenticated"], name) or bit(row["authority_granted"], name):
            fail(f"promotion={name}")
        if not bit(row["pidfd_bound"], name) or not bit(row["parser_agreement"], name) or \
           not bit(row["terminal_wait_by_pidfd"], name):
            fail(f"lifetime-or-parser={name}")
        if name in candidates:
            if row["disposition"] != "HOSTED_LAUNCH_CLOSED_CANDIDATE" or \
               not bit(row["launch_closed_candidate"], name) or bit(row["fail_closed"], name):
                fail(f"candidate={name}")
            for field in ("nonroot_zero_capability_floor", "stdio_normalized",
                          "descriptor_topology_closed", "exact_executable_join"):
                if not bit(row[field], f"{name}:{field}"):
                    fail(f"candidate-field={name}:{field}")
        elif name in fail_closed:
            if row["disposition"] != "FAIL_CLOSED" or \
               not bit(row["fail_closed"], name) or bit(row["launch_closed_candidate"], name):
                fail(f"fail-closed={name}")
        else:
            if row["disposition"] != "COUNTEREXAMPLE_OBSERVED" or \
               bit(row["launch_closed_candidate"], name) or bit(row["fail_closed"], name):
                fail(f"counterexample-disposition={name}")

    if not bit(by_name["path-rebind-retained-execfd"]["path_rebind_retained_inode"], "rebind"):
        fail("path-rebind-witness")
    if not bit(by_name["absolute-execveat-ignores-dirfd"]["absolute_path_bypassed_dirfd"], "absolute"):
        fail("absolute-dirfd-witness")
    for name in ("pidfd-spans-exec-replacement", "no-new-privs-persists-across-exec"):
        row = by_name[name]
        if not bit(row["same_process_lifetime"], name) or \
           not bit(row["executable_replaced"], name) or \
           not bit(row["no_new_privs_persisted"], name):
            fail(f"exec-replacement-witness={name}")

    relation_header = [
        "state_id", "phase", "pidfd_bound", "no_new_privs", "initial_launch_closed",
        "executable_replaced", "executable_continuity_bound", "provider_authenticated",
        "authority_granted", "event", "outcome", "next_state_id", "next_phase",
    ]
    relation = read_tsv(root / "relation.tsv", relation_header)
    if len(relation) != 72:
        fail("relation-count")
    phases = [
        "IDLE", "PROCESS_CREATED", "EXEC_A", "OBSERVED_A", "EXEC_B",
        "OBSERVED_B", "EXITED", "WAITED", "PUBLISHED",
    ]
    events = [
        "CLONE_PIDFD", "EXEC_A_BY_FD", "OBSERVE_A_EXACT", "EXEC_B_SAME_LIFETIME",
        "OBSERVE_B_EXACT", "PROCESS_EXIT", "WAIT_PIDFD", "PUBLISH",
    ]
    expected_event = {phase: events[index] if index < len(events) else None
                      for index, phase in enumerate(phases)}
    seen = set()
    applied = 0
    rejected = 0
    for row in relation:
        state_id = int(row["state_id"])
        next_id = int(row["next_state_id"])
        if state_id < 0 or state_id >= 9 or next_id < 0 or next_id >= 9:
            fail("state-id")
        if row["phase"] != phases[state_id] or row["next_phase"] != phases[next_id]:
            fail("phase-id-join")
        key = (state_id, row["event"])
        if key in seen or row["event"] not in events:
            fail("relation-saturation")
        seen.add(key)
        for field in ("provider_authenticated", "authority_granted"):
            if bit(row[field], f"relation:{state_id}:{field}"):
                fail("relation-promotion")
        should_apply = row["event"] == expected_event[row["phase"]]
        if should_apply:
            applied += 1
            if row["outcome"] != "APPLIED" or next_id != state_id + 1:
                fail(f"applied-edge={key}")
        else:
            rejected += 1
            if row["outcome"] != "REJECTED" or next_id != state_id:
                fail(f"preserving-rejection={key}")
    if len(seen) != 72 or applied != 8 or rejected != 64:
        fail("relation-metrics")

    counterexamples = read_tsv(root / "counterexamples.tsv", ["id", "observed", "proves", "result"])
    expected_ids = {
        "PIDFD_NOT_EXEC_EPOCH",
        "ABSOLUTE_EXECVEAT_BYPASSES_DIRFD",
        "PATH_IS_NOT_EXECUTED_INODE",
        "NO_NEW_PRIVS_NOT_EXEC_CLOSURE",
        "TRANSCRIPT_NOT_PROVIDER_AUTH",
    }
    if {row["id"] for row in counterexamples} != expected_ids or \
       any(row["result"] != "false" for row in counterexamples):
        fail("counterexamples")

    audit = {
        "authority_bearing_results": 0,
        "counterexamples": 5,
        "fail_closed_cases": 2,
        "launch_closed_candidates": 9,
        "live_cases": 14,
        "model_applied": 8,
        "model_rejected": 64,
        "model_states": 9,
        "model_transitions": 72,
        "parser_cases": 22,
        "parser_disagreements": 0,
        "process_custody_results": 0,
        "provider_authenticated_results": 0,
        "schema": AUDIT_SCHEMA,
        "source_separated": True,
        "status": "PASS",
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("PROCESS_CUSTODY_AUDIT=PASS live_cases=14 candidates=9 fail_closed=2 "
          "parser_cases=22 states=9 transitions=72 authority=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
