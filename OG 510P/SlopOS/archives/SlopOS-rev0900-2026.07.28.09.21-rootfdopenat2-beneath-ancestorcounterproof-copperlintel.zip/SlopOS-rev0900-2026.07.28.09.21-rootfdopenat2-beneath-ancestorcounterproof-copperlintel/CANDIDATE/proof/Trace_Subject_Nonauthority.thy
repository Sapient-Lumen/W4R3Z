theory Trace_Subject_Nonauthority
  imports Main
begin

datatype evidence_rung =
    RNone
  | RStructurallyValid
  | RDeterministicallyReplayed
  | RExportClosedCandidate
  | RCaptureBound

record validation_context =
  provider_authenticated :: bool
  machine_binding_verified :: bool
  process_custody_verified :: bool
  exclusive_writer_verified :: bool
  fixture_only :: bool

definition externally_bound :: "validation_context \<Rightarrow> bool" where
  "externally_bound c \<longleftrightarrow>
      provider_authenticated c \<and>
      machine_binding_verified c \<and>
      process_custody_verified c \<and>
      exclusive_writer_verified c \<and>
      \<not> fixture_only c"

definition packet_rung :: "bool \<Rightarrow> validation_context \<Rightarrow> evidence_rung" where
  "packet_rung export_closed c =
      (if \<not> export_closed then RNone
       else if externally_bound c then RCaptureBound
       else RExportClosedCandidate)"

lemma fixture_never_capture_bound:
  assumes "fixture_only c"
  shows "packet_rung True c = RExportClosedCandidate"
  using assms by (simp add: packet_rung_def externally_bound_def)

lemma packet_fields_cannot_supply_context:
  assumes "\<not> externally_bound c"
  shows "packet_rung True c \<noteq> RCaptureBound"
  using assms by (simp add: packet_rung_def)

definition publish :: "evidence_rung \<Rightarrow> evidence_rung" where
  "publish r = r"

lemma publication_nonpromotion:
  "publish RExportClosedCandidate = RExportClosedCandidate"
  by (simp add: publish_def)

datatype ceremony_phase =
    Idle | Authorized | NamespaceClosed | DevicesBound | TargetActive
  | WorkloadRunning | WorkloadTerminal | TargetRemoved | ExportRead
  | ExportClosed | Published | Failed | Incomplete

fun restart :: "ceremony_phase \<Rightarrow> ceremony_phase" where
  "restart Idle = Idle"
| "restart ExportClosed = ExportClosed"
| "restart Published = Published"
| "restart p = Incomplete"

lemma active_restart_not_export_closed:
  assumes "p \<in> {Authorized, NamespaceClosed, DevicesBound, TargetActive,
                    WorkloadRunning, WorkloadTerminal, TargetRemoved, ExportRead}"
  shows "restart p \<noteq> ExportClosed"
  using assms by (cases p) auto

datatype hidden_history = ClosedWriter | HiddenAliasWriter

fun packet_observation :: "hidden_history \<Rightarrow> nat" where
  "packet_observation ClosedWriter = 0"
| "packet_observation HiddenAliasWriter = 0"

lemma packet_not_history_injective:
  "ClosedWriter \<noteq> HiddenAliasWriter \<and>
   packet_observation ClosedWriter = packet_observation HiddenAliasWriter"
  by simp

definition authority_granted :: "evidence_rung \<Rightarrow> bool" where
  "authority_granted r = False"

lemma capture_evidence_still_nonauthoritative:
  "\<not> authority_granted RCaptureBound"
  by (simp add: authority_granted_def)

end
