# Counterexample: numeric PID is not process custody

A numeric PID can denote different process instances at different times. The
retained witness gives two hidden histories the same observed value `4242`:

```text
original process instance A
later reused PID process instance B
```

The scalar PID does not distinguish them. A pidfd acquired atomically with
process creation is useful for stable signaling and wait operations, but even a
packet assertion `pidfd_bound=1` is not proof that such a descriptor existed,
remained under supervisor custody, referred to the expected executable, or was
joined to every retained observation.

Process custody requires an external provider contract and evidence, not a
number inside the packet.
