# Counterexample — mark is not flush

Trace: `bad-mark-is-not-flush`.

1. Write the C2 journal slot but do not flush `LOCAL`.
2. Emit an observer mark named as though C2 had been observed.
3. Advance and flush the successor floor.
4. create and flush an exact endpoint effect and exact `EFFECT` result.
5. Crash while the pending C2 write is lost.

The reopened image contains C1, successor floor, exact effect and exact result.
It is `FAIL_STOP`. Treating the mark as a persistence barrier would incorrectly
permit a cross-domain state that the local journal never durably admitted.

Retained witness: `MARK_IS_NOT_FLUSH` in `witnesses.tsv`.
