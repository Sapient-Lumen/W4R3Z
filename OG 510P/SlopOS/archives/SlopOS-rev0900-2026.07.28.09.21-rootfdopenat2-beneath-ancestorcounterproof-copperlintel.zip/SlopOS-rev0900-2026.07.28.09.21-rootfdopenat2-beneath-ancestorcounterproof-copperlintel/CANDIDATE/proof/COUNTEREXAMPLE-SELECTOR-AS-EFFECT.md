# Counterexample: selector replacement is not the selected effect

The inherited safe installation order is selector before floor. A crash after
selector replacement and before floor advancement allows selector replacement
to be repeated without any floor regression. Therefore monotonicity of the
external floor cannot prove at-most-once for selector replacement while
preserving that installation order.

The correction is to classify selector movement as reconcilable installation.
The later selected effect occurs only after selector, floor, confirmation, and
pending retirement are coherent, and only while a live exact-readback
continuation survives. Restart may finish installation but cannot mint the
continuation or permit needed for the first selected effect.
