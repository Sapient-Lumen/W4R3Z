#!/usr/bin/env python3
"""Recheck the observation-collision table without importing C++ code."""
from __future__ import annotations

import argparse
import collections
import csv
import json
from pathlib import Path

HEADER = [
    "history", "effect_occurred", "durable", "local_marker",
    "endpoint_result", "local_observation", "extended_observation",
]
EXPECTED_HISTORIES = {
    "crash-before-dispatch", "dispatch-entered-no-return-no-effect",
    "effect-occurred-marker-not-stable", "effect-occurred-marker-malformed",
    "effect-occurred-marker-exact", "endpoint-exact-no-effect",
    "endpoint-exact-effect", "endpoint-malformed-after-effect",
}


def audit(table: Path, certificate: Path) -> dict[str, object]:
    with table.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        assert reader.fieldnames == HEADER, reader.fieldnames
        rows = list(reader)
    assert {row["history"] for row in rows} == EXPECTED_HISTORIES
    assert len(rows) == len(EXPECTED_HISTORIES)
    local: dict[str, set[int]] = collections.defaultdict(set)
    extended: dict[str, set[int]] = collections.defaultdict(set)
    for row in rows:
        assert row["effect_occurred"] in {"0", "1"}
        assert row["durable"] == "c2"
        assert row["local_observation"] == f"c2|{row['local_marker']}"
        assert row["extended_observation"] == f"{row['local_observation']}|{row['endpoint_result']}"
        effect = int(row["effect_occurred"])
        local[row["local_observation"]].add(effect)
        extended[row["extended_observation"]].add(effect)
    assert local["c2|absent"] == {0, 1}
    ambiguous_local = sum(len(values) > 1 for values in local.values())
    exact_extended = sum(len(values) == 1 for values in extended.values())
    cert = json.loads(certificate.read_text(encoding="utf-8"))
    expected = {
        "schema": "slopos.rev0879.observation-ambiguity.v1",
        "status": "PASS",
        "hidden_histories": len(rows),
        "local_observation_classes": len(local),
        "ambiguous_local_classes": ambiguous_local,
        "exact_extended_classes": exact_extended,
    }
    for key, value in expected.items():
        assert cert.get(key) == value, (key, cert.get(key), value)
    assert "c2|absent" in cert.get("witness", "")
    return {
        "status": "PASS",
        "hidden_histories": len(rows),
        "local_observation_classes": len(local),
        "ambiguous_local_classes": ambiguous_local,
        "exact_extended_classes": exact_extended,
        "collision": "c2|absent admits both effect and no-effect histories",
        "local_absence_implies_no_effect": False,
        "source_separated": True,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--table", type=Path, required=True)
    p.add_argument("--certificate", type=Path, required=True)
    p.add_argument("--json", type=Path)
    a = p.parse_args()
    report = audit(a.table, a.certificate)
    if a.json:
        a.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "AMBIGUITY_AUDIT=PASS"
        f" histories={report['hidden_histories']}"
        f" ambiguous_local_classes={report['ambiguous_local_classes']}"
        " local_absence_implies_no_effect=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
