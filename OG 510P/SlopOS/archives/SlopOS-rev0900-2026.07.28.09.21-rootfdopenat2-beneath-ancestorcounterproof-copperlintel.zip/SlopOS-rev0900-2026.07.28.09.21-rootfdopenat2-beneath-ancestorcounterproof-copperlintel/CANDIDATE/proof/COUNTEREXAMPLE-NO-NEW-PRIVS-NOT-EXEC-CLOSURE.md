# Counterexample: no_new_privs is not exec closure

Worker A and worker B both observe `NoNewPrivs: 1` while one process lifetime
crosses from executable A to executable B.

`no_new_privs` limits privilege gain through exec. It does not prohibit exec,
name one executable epoch, authenticate a provider, or create process custody.
