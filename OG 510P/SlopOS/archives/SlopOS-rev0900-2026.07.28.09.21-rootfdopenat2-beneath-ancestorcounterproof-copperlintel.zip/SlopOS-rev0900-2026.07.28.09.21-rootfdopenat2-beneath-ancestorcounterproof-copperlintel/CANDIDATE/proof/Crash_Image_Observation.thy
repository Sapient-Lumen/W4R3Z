theory Crash_Image_Observation
  imports Main
begin

text ‹Unreplayed Epoch Zero proof design.  An image observation can erase the
      distinction between a fresh history and an effect followed by rollback.›

datatype outcome = Effect | NoEffect

typedecl history
typedecl image

consts observe :: "history ⇒ image"
consts actual :: "history ⇒ outcome"

locale rollback_collision =
  fixes fresh :: history
    and rolled_back :: history
  assumes same_image: "observe fresh = observe rolled_back"
      and different_outcome: "actual fresh ≠ actual rolled_back"
begin

theorem no_sound_image_classifier:
  fixes classify :: "image ⇒ outcome"
  shows "classify (observe fresh) ≠ actual fresh ∨
         classify (observe rolled_back) ≠ actual rolled_back"
proof (rule ccontr)
  assume "¬ (classify (observe fresh) ≠ actual fresh ∨
             classify (observe rolled_back) ≠ actual rolled_back)"
  then have a: "classify (observe fresh) = actual fresh" and
            b: "classify (observe rolled_back) = actual rolled_back"
    by auto
  from a b same_image have "actual fresh = actual rolled_back" by simp
  with different_outcome show False by contradiction
qed

end

end
