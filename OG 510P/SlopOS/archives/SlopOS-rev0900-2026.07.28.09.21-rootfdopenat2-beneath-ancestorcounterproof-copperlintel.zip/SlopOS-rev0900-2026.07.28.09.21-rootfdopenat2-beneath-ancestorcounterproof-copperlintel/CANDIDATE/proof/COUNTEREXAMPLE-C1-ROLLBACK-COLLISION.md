# Counterexample — C1 rollback collision

Trace: `bad-whole-image-rollback`.

The trace durably reaches the selected effect and an exact `EFFECT` result, then
restores the local two-slot journal, floor, endpoint marker and endpoint result
to their predecessor bytes. The final 3072-byte image is byte-for-byte equal to
the initial image.

Thus the following histories collide:

```text
H0: initial image; no effect yet
H1: effect occurred; all restorable evidence rolled back
observe(H0) = observe(H1)
effect(H0) != effect(H1)
```

Any image-only rule that labels the shared C1 image `NO_EFFECT` is unsound over
this history set. A protected nonrestorable floor or protected endpoint history
is a premise, not an optimization.

Retained witness: `ROLLBACK_IMAGE_COLLIDES_WITH_INITIAL`.
