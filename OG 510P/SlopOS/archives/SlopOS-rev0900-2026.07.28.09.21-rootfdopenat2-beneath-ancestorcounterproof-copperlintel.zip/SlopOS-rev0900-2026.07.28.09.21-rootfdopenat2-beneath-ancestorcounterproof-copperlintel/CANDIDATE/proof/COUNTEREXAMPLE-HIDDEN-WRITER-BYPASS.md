# Counterexample: hidden writer bypass

Two histories can retain the same packet and the same logging trace while
differing in a direct write performed through an alias that bypasses the logging
target:

```text
closed-writer hypothesis -> no bypass
unobserved direct alias   -> target history diverges
```

A packet Boolean stating `direct_aliases_closed=1` cannot rule out the second
history. The statement is useful only when joined to separately established
namespace, device, descriptor, capability and exclusive-writer custody.

The ceremony therefore fails on an observed hidden writer, while the packet
validator refuses to promote its own writer assertions to capture binding.
