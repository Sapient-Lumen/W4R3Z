# Counterexample: advertised prefix is not target absence

Two hidden histories retain identical advertised log bytes. In one, no later
target event occurs. In the other, a later event exists outside the exported
prefix. Any classifier consuming only the advertised bytes returns the same
answer for both histories.

Therefore an exact prefix proves only that exact prefix. It does not prove that
no later target-side event occurred unless export closure and writer custody are
separately established.
