# Counterexample: structural acceptance is not authenticity

Every accepted rev0881 log was synthesized by an ordinary unprivileged test
process. The strict parser correctly accepts their format. None was acquired
from a `dm-log-writes` target.

Thus `structurally valid -> authentically acquired` is false by direct witness.
Authenticity requires a governed acquisition path, exact subject closure, and
protected provenance outside the byte grammar.
