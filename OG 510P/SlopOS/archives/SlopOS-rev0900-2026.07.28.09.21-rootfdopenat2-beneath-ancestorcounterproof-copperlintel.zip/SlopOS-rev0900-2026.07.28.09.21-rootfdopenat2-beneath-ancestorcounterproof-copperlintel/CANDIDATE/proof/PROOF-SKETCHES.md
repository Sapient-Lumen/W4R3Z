# Proof sketches

## P1 — canonical packet differential validation

The constrained parser requires exact ordered fields. The reference parser
constructs a key map and independently validates the same semantic types. For
every one of 26 fixtures, both parsers must produce equal Proposal, Witness and
Receipt values before packet validation proceeds. The mutation corpus covers
byte tampering, baseline mismatch, cross-record joins, malformed trace,
noncanonical integers and hashes, reordered/duplicated/unknown fields, CRLF,
lifecycle restart, uncertain removal and incomplete writer closure.

## P2 — exact subject and replay joins

Receipt hashes bind exact Proposal, Witness and trace bytes. Proposal binds the
baseline. The validator replays the exact trace over the exact baseline and
recomputes normalized-event and replay-manifest bytes. The Receipt subject hash
is over a fixed acyclic preimage. Any selected mutation is rejected before an
export-closed candidate is returned.

## P3 — coherence/nonauthenticity separation

Two packets are coherent and accepted. Both use the fixture-only context, so
both remain export-closed candidates with no machine, acquisition, capture or
authority claim. One is explicitly labeled an ordinary-process forgery. Thus
packet coherence cannot imply authentic acquisition.

## P4 — ceremony saturation

Breadth-first exploration starts at `IDLE`, applies all fifteen events to every
new state, and retains preserving rejections as relation edges. It reaches 13
states and 195 edges. A separately structured transition function agrees on all
edges. A Python checker reconstructs each phase successor and verifies relation
saturation and reachability.

## P5 — failure erasure and restart confinement

`MISMATCH` and post-authorization `HIDDEN_WRITER` lead to `FAILED` with all live
resources erased. `REMOVE_TARGET_UNKNOWN` and active-phase `RESTART` lead to
`INCOMPLETE`, also erasing live resources. Neither terminal state has an export
closure transition. Restart therefore cannot reconstruct the original run
identity or manufacture export closure.

## P6 — PID and hidden-writer noninjectivity

The same numeric PID is compatible with two process instances. The same packet
and trace are compatible with target histories that differ by a direct bypass
writer. These observation maps are noninjective; process and writer custody must
be supplied by a protected external provider relation.

## P7 — publication and authority nonpromotion

Publication is modeled only after export closure and changes only the published
bit. The packet evidence rung and `authority_granted=false` remain unchanged.
The validator likewise sets authority false even on the unexercised
capture-bound branch.

## P8 — inherited storage and authority laws

Rev0879 still retains zero recovered first-effect edges and the whole-image
rollback duplicate. Rev0880 retains C1 history collision and exact
EFFECT/NO_EFFECT/UNCERTAIN/FAIL_STOP classification. Rev0881 retains strict trace
intake and marker/end-marker nonauthority. Rev0882 adds subject-packet and
capture-ceremony joins but discharges none of the protected external premises.

## P9 — limits

The results are finite protocol and implementation observations. They do not
prove C++ semantics, compiler correctness, Linux behavior, pidfd provenance,
namespace closure, device identity, writer exclusivity, physical durability,
authentic acquisition or release authority. Isabelle source remains unreplayed.


## P10 — process lifetime and executable epoch separation

The live supervisor receives a pidfd atomically with child creation, joins the
child entry report to the live process start time and executable bytes, then
acknowledges worker A. Worker A executes worker B through a retained descriptor.
Worker B has the same numeric PID and start time and is waited through the same
pidfd. Therefore process-lifetime identity is not executable-epoch identity.

## P11 — initial descriptor-selected launch

For nine accepted cases, the child enters a nonroot zero-capability floor,
normalizes descriptors 0–2, closes undeclared descriptors, sets parent-death and
no-new-privileges constraints, and executes the selected ELF through an empty
`execveat` path. The supervisor joins the exact live executable and terminal
status. This bounds only the initial launch; no event authenticates a provider or
prohibits a later exec.

## P12 — process report differential validation

The strict parser consumes nineteen fields in exact order. The reference parser
first builds a closed key map, validates types, then requires canonical
reserialization. Twenty-two fixtures cover framing, controls, schema, field
order, duplicates, unknown fields, integers and booleans. Both implementations
agree on every case, and a separately written Python checker reconstructs the
retained tables.

## P13 — abstract nonpromotion relation

The nine-state relation saturates eight events over every reachable state. Its
only applied path is creation, initial exec, observation, replacement, second
observation, exit, pidfd wait and publication. `provider_authenticated` and
`authority_granted` are false in every source and successor state. Publication
therefore changes distribution only.
