# Counterexample: absolute execveat path bypasses dirfd

The live campaign supplies an invalid dirfd and an absolute worker-A pathname.
The execution succeeds because the absolute path does not use the dirfd.

Therefore a retained directory descriptor has no constraining force unless the
profile also constrains the path form and flags.
