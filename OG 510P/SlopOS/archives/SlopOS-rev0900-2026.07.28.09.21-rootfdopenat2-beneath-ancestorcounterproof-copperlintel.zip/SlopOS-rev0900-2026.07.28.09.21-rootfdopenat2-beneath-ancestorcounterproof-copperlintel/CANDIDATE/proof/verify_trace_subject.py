#!/usr/bin/env python3
"""Source-separated reconstruction of the rev0882 trace-subject campaign."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

PROPOSAL_KEYS = [
    "schema", "run_id", "operation_sha256", "capture_profile", "sector_size",
    "baseline_bytes", "baseline_sha256", "workload_image_sha256",
    "workload_inputs_sha256", "target_device_sha256", "log_device_sha256",
    "block_graph_sha256", "writer_policy_sha256", "export_offset_bytes",
    "export_length_bytes", "trace_schema",
]
WITNESS_KEYS = [
    "schema", "run_id", "authorization_id", "challenge_id", "machine_sha256",
    "boot_id", "kernel_sha256", "supervisor_image_sha256",
    "supervisor_instance_sha256", "supervisor_pid", "pidfd_bound",
    "mount_namespace", "user_namespace", "pid_namespace", "preclean_observed",
    "target_created_once", "workload_launched_once", "workload_exit_observed",
    "workload_exit_code", "stdout_sha256", "stderr_sha256",
    "target_remove_status", "export_read_observed", "writer_closure_observed",
    "direct_aliases_closed", "log_aliases_closed", "process_restarted", "complete",
]
RECEIPT_KEYS = [
    "schema", "run_id", "proposal_sha256", "witness_sha256", "trace_sha256",
    "trace_bytes", "normalized_sha256", "replay_manifest_sha256",
    "export_close_state", "publication_id", "subject_sha256",
]
HASH_FIELDS = {
    "operation_sha256", "baseline_sha256", "workload_image_sha256",
    "workload_inputs_sha256", "target_device_sha256", "log_device_sha256",
    "block_graph_sha256", "writer_policy_sha256", "machine_sha256",
    "kernel_sha256", "supervisor_image_sha256", "supervisor_instance_sha256",
    "stdout_sha256", "stderr_sha256", "proposal_sha256", "witness_sha256",
    "trace_sha256", "normalized_sha256", "replay_manifest_sha256", "subject_sha256",
}
BOOL_FIELDS = {
    "pidfd_bound", "preclean_observed", "target_created_once",
    "workload_launched_once", "workload_exit_observed", "export_read_observed",
    "writer_closure_observed", "direct_aliases_closed", "log_aliases_closed",
    "process_restarted", "complete",
}
MAGIC = 0x6A736677736872
VERSION = 1
FLUSH = 1
FUA = 2
DISCARD = 4
MARK = 8
METADATA = 16


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def parse_record(raw: bytes, keys: list[str]) -> dict[str, str] | None:
    if not raw or not raw.endswith(b"\n") or b"\r" in raw or b"\0" in raw:
        return None
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError:
        return None
    lines = text[:-1].split("\n")
    if len(lines) != len(keys):
        return None
    result: dict[str, str] = {}
    for expected, line in zip(keys, lines, strict=True):
        if line.count("\t") != 1:
            return None
        key, value = line.split("\t")
        if key != expected or not value:
            return None
        result[key] = value
    return result


def canonical_uint(text: str) -> int | None:
    if not text or (len(text) > 1 and text[0] == "0") or not text.isdigit():
        return None
    return int(text)


def canonical_int(text: str) -> int | None:
    if not text or text.startswith("+"):
        return None
    if text.startswith("-"):
        if len(text) == 1 or not text[1:].isdigit() or (len(text) > 2 and text[1] == "0"):
            return None
    elif not text.isdigit() or (len(text) > 1 and text[0] == "0"):
        return None
    return int(text)


def atom(text: str) -> bool:
    return 0 < len(text) <= 256 and all(0x21 <= ord(c) <= 0x7E and c not in "\t\\" for c in text)


def digest(text: str) -> bool:
    return len(text) == 64 and all(c in "0123456789abcdef" for c in text)


def record_semantics(record: dict[str, str], kind: str) -> bool:
    if any(not digest(record[key]) for key in HASH_FIELDS & record.keys()):
        return False
    if any(record[key] not in {"0", "1"} for key in BOOL_FIELDS & record.keys()):
        return False
    if kind == "proposal":
        sector = canonical_uint(record["sector_size"])
        baseline = canonical_uint(record["baseline_bytes"])
        offset = canonical_uint(record["export_offset_bytes"])
        length = canonical_uint(record["export_length_bytes"])
        return (
            record["schema"] == "slopos.trace-subject.proposal.v1"
            and atom(record["run_id"]) and atom(record["capture_profile"])
            and sector in {512, 1024, 2048, 4096}
            and baseline is not None and baseline > 0 and baseline % sector == 0
            and offset == 0 and length is not None and length > 0
            and record["trace_schema"] == "linux.dm-log-writes.v1.strict-subset"
        )
    if kind == "witness":
        pid = canonical_uint(record["supervisor_pid"])
        exit_code = canonical_int(record["workload_exit_code"])
        return (
            record["schema"] == "slopos.trace-subject.witness.v1"
            and all(atom(record[key]) for key in [
                "run_id", "authorization_id", "challenge_id", "boot_id",
                "mount_namespace", "user_namespace", "pid_namespace",
                "target_remove_status",
            ])
            and pid is not None and pid > 0 and exit_code is not None
        )
    trace_bytes = canonical_uint(record["trace_bytes"])
    return (
        record["schema"] == "slopos.trace-subject.receipt.v1"
        and atom(record["run_id"]) and trace_bytes is not None and trace_bytes > 0
        and atom(record["export_close_state"]) and atom(record["publication_id"])
    )


@dataclass(frozen=True)
class Event:
    kind: str
    sector: int = 0
    count: int = 0
    metadata: bool = False
    mark: str = ""
    data: bytes = b""


def parse_trace(raw: bytes, baseline_sectors: int) -> tuple[int, list[Event]] | None:
    if len(raw) < 28:
        return None
    magic, version, advertised, sector_size = struct.unpack_from("<QQQI", raw, 0)
    if magic != MAGIC or version != VERSION or sector_size not in {512, 1024, 2048, 4096}:
        return None
    if len(raw) < sector_size or len(raw) % sector_size or any(raw[28:sector_size]):
        return None
    offset = sector_size
    events: list[Event] = []
    known = FLUSH | FUA | DISCARD | MARK | METADATA
    for _ in range(advertised):
        if offset + sector_size > len(raw):
            return None
        header = raw[offset:offset + sector_size]
        target, count, flags, data_len = struct.unpack_from("<QQQQ", header, 0)
        if flags & ~known:
            return None
        if flags & MARK:
            if flags != MARK or target or count or not data_len or data_len > sector_size - 32:
                return None
            mark_bytes = header[32:32 + data_len]
            if any(b < 0x20 or b > 0x7E for b in mark_bytes) or any(header[32 + data_len:]):
                return None
            events.append(Event("MARK", mark=mark_bytes.decode("ascii")))
            offset += sector_size
            continue
        if flags & DISCARD:
            return None
        if flags & FLUSH:
            if flags != FLUSH or target or count or data_len or any(header[32:]):
                return None
            events.append(Event("FLUSH"))
            offset += sector_size
            continue
        if flags & ~(FUA | METADATA) or count == 0 or data_len or any(header[32:]):
            return None
        if target > baseline_sectors or count > baseline_sectors - target:
            return None
        size = count * sector_size
        payload = raw[offset + sector_size:offset + sector_size + size]
        if len(payload) != size:
            return None
        events.append(Event("FUA_WRITE" if flags & FUA else "WRITE", target, count,
                            bool(flags & METADATA), data=payload))
        offset += sector_size + size
    if offset != len(raw):
        return None
    return sector_size, events


def normalized(sector_size: int, events: list[Event]) -> bytes:
    lines = [
        "schema\tslopos.normalized-dmlog-events.v1",
        f"sector_size\t{sector_size}",
        f"event_count\t{len(events)}",
        "index\tkind\tsector\tnr_sectors\tmetadata\tmark\tdata_bytes\tdata_sha256",
    ]
    for index, event in enumerate(events):
        lines.append(
            f"{index}\t{event.kind}\t{event.sector}\t{event.count}\t"
            f"{1 if event.metadata else 0}\t{event.mark}\t{len(event.data)}\t{sha(event.data)}"
        )
    return ("\n".join(lines) + "\n").encode()


def replay_manifest(baseline: bytes, sector_size: int, events: list[Event]) -> bytes:
    images: list[bytes] = [baseline]
    image = bytearray(baseline)
    for event in events:
        if event.kind in {"WRITE", "FUA_WRITE"}:
            begin = event.sector * sector_size
            image[begin:begin + len(event.data)] = event.data
        images.append(bytes(image))
    lines = [
        "schema\tslopos.trace-replay-prefix-manifest.v1",
        f"baseline_sha256\t{sha(baseline)}",
        f"prefixes\t{len(images)}",
        "prefix\tlast_kind\timage_bytes\timage_sha256",
    ]
    for index, image_bytes in enumerate(images):
        kind = "initial" if index == 0 else events[index - 1].kind
        lines.append(f"{index}\t{kind}\t{len(image_bytes)}\t{sha(image_bytes)}")
    return ("\n".join(lines) + "\n").encode()


def classify(case_dir: Path) -> tuple[bool, str, str]:
    proposal_raw = (case_dir / "proposal.tsv").read_bytes()
    witness_raw = (case_dir / "witness.tsv").read_bytes()
    receipt_raw = (case_dir / "receipt.tsv").read_bytes()
    trace = (case_dir / "trace.bin").read_bytes()
    baseline = (case_dir / "baseline.bin").read_bytes()
    proposal = parse_record(proposal_raw, PROPOSAL_KEYS)
    witness = parse_record(witness_raw, WITNESS_KEYS)
    receipt = parse_record(receipt_raw, RECEIPT_KEYS)
    if proposal is None or witness is None or receipt is None:
        return False, "MALFORMED_RECORD", "NONE"
    if not record_semantics(proposal, "proposal") or not record_semantics(witness, "witness") \
            or not record_semantics(receipt, "receipt"):
        return False, "MALFORMED_RECORD", "NONE"
    if len({proposal["run_id"], witness["run_id"], receipt["run_id"]}) != 1:
        return False, "JOIN_MISMATCH", "NONE"
    if proposal["target_device_sha256"] == proposal["log_device_sha256"]:
        return False, "FIELD_INVALID", "NONE"
    if int(proposal["baseline_bytes"]) != len(baseline) or proposal["baseline_sha256"] != sha(baseline):
        return False, "BASELINE_MISMATCH", "NONE"
    if int(proposal["export_length_bytes"]) != len(trace) or int(receipt["trace_bytes"]) != len(trace):
        return False, "JOIN_MISMATCH", "NONE"
    if receipt["proposal_sha256"] != sha(proposal_raw) or receipt["witness_sha256"] != sha(witness_raw) \
            or receipt["trace_sha256"] != sha(trace):
        return False, "JOIN_MISMATCH", "NONE"
    preimage = b"".join(
        f"{key}\t{receipt[key]}\n".encode() for key in RECEIPT_KEYS[:-1]
    )
    if receipt["subject_sha256"] != sha(preimage):
        return False, "JOIN_MISMATCH", "NONE"
    trace_result = parse_trace(trace, int(proposal["baseline_bytes"]) // int(proposal["sector_size"]))
    if trace_result is None or trace_result[0] != int(proposal["sector_size"]):
        return False, "TRACE_REJECTED", "NONE"
    sector_size, events = trace_result
    norm = normalized(sector_size, events)
    replay = replay_manifest(baseline, sector_size, events)
    if receipt["normalized_sha256"] != sha(norm) or receipt["replay_manifest_sha256"] != sha(replay):
        return False, "REPLAY_MISMATCH", "NONE"
    lifecycle = [
        "pidfd_bound", "preclean_observed", "target_created_once",
        "workload_launched_once", "workload_exit_observed", "complete",
    ]
    if any(witness[key] != "1" for key in lifecycle) or witness["process_restarted"] != "0":
        return False, "SUPERVISOR_CUSTODY_INCOMPLETE", "NONE"
    if witness["target_remove_status"] != "removed" or witness["export_read_observed"] != "1" \
            or receipt["export_close_state"] != "closed":
        return False, "EXPORT_NOT_CLOSED", "NONE"
    if any(witness[key] != "1" for key in [
        "writer_closure_observed", "direct_aliases_closed", "log_aliases_closed",
    ]):
        return False, "WRITER_CUSTODY_INCOMPLETE", "NONE"
    return True, "OK", "EXPORT_CLOSED_CANDIDATE"


PHASE_SHAPE = {
    "IDLE": "00000", "AUTHORIZED": "10000", "NAMESPACE_CLOSED": "10000",
    "DEVICES_BOUND": "10000", "TARGET_ACTIVE": "01100",
    "WORKLOAD_RUNNING": "01100", "WORKLOAD_TERMINAL": "01100",
    "TARGET_REMOVED": "01000", "EXPORT_READ": "01000",
    "EXPORT_CLOSED": "01010", "PUBLISHED": "01011",
    "FAILED": "00000", "INCOMPLETE": "00000",
}
EVENTS = [
    "AUTHORIZE", "CLOSE_NAMESPACE", "BIND_DEVICES", "CREATE_TARGET",
    "LAUNCH_WORKLOAD", "OBSERVE_EXIT_SUCCESS", "OBSERVE_EXIT_FAILURE",
    "REMOVE_TARGET_SUCCESS", "REMOVE_TARGET_UNKNOWN", "READ_EXPORT",
    "CLOSE_EXPORT", "PUBLISH", "RESTART", "HIDDEN_WRITER", "MISMATCH",
]


def ceremony_step(phase: str, event: str) -> tuple[bool, str]:
    if phase in {"FAILED", "INCOMPLETE"}:
        return False, phase
    if event == "MISMATCH":
        return True, "FAILED"
    if event == "HIDDEN_WRITER":
        return (False, phase) if phase == "IDLE" else (True, "FAILED")
    if event == "RESTART":
        return (False, phase) if phase in {"IDLE", "EXPORT_CLOSED", "PUBLISHED"} else (True, "INCOMPLETE")
    edges = {
        ("IDLE", "AUTHORIZE"): "AUTHORIZED",
        ("AUTHORIZED", "CLOSE_NAMESPACE"): "NAMESPACE_CLOSED",
        ("NAMESPACE_CLOSED", "BIND_DEVICES"): "DEVICES_BOUND",
        ("DEVICES_BOUND", "CREATE_TARGET"): "TARGET_ACTIVE",
        ("TARGET_ACTIVE", "LAUNCH_WORKLOAD"): "WORKLOAD_RUNNING",
        ("WORKLOAD_RUNNING", "OBSERVE_EXIT_SUCCESS"): "WORKLOAD_TERMINAL",
        ("WORKLOAD_RUNNING", "OBSERVE_EXIT_FAILURE"): "WORKLOAD_TERMINAL",
        ("WORKLOAD_TERMINAL", "REMOVE_TARGET_SUCCESS"): "TARGET_REMOVED",
        ("WORKLOAD_TERMINAL", "REMOVE_TARGET_UNKNOWN"): "INCOMPLETE",
        ("TARGET_REMOVED", "READ_EXPORT"): "EXPORT_READ",
        ("EXPORT_READ", "CLOSE_EXPORT"): "EXPORT_CLOSED",
        ("EXPORT_CLOSED", "PUBLISH"): "PUBLISHED",
    }
    successor = edges.get((phase, event))
    return (False, phase) if successor is None else (True, successor)


def verify_ceremony(campaign: Path) -> dict[str, int]:
    states_rows = read_tsv(campaign / "ceremony" / "states.tsv")
    states = {row["state"]: row for row in states_rows}
    if len(states) != len(states_rows):
        raise ValueError("duplicate ceremony state id")
    for row in states_rows:
        bits = "".join(row[key] for key in [
            "authorization_live", "run_identity_live", "target_live", "export_closed", "published",
        ])
        if PHASE_SHAPE.get(row["phase"]) != bits:
            raise ValueError(f"bad ceremony state shape {row}")
    transitions = read_tsv(campaign / "ceremony" / "transitions.tsv")
    seen: set[tuple[str, str]] = set()
    applied = 0
    for row in transitions:
        key = (row["from"], row["event"])
        if key in seen:
            raise ValueError("duplicate ceremony edge")
        seen.add(key)
        if row["from"] not in states or row["to"] not in states or row["event"] not in EVENTS:
            raise ValueError("unknown ceremony identity")
        expected_applied, expected_phase = ceremony_step(states[row["from"]]["phase"], row["event"])
        if row["applied"] != ("1" if expected_applied else "0") \
                or states[row["to"]]["phase"] != expected_phase:
            raise ValueError(f"ceremony mismatch {row}")
        if row["from_phase"] != states[row["from"]]["phase"] \
                or row["to_phase"] != states[row["to"]]["phase"]:
            raise ValueError("ceremony phase projection mismatch")
        applied += expected_applied
    if len(seen) != len(states) * len(EVENTS):
        raise ValueError("ceremony relation is not saturated")
    reachable = {"0"}
    changed = True
    while changed:
        changed = False
        for row in transitions:
            if row["from"] in reachable and row["to"] not in reachable:
                reachable.add(row["to"])
                changed = True
    if reachable != set(states):
        raise ValueError("unreachable retained ceremony state")
    return {"states": len(states), "transitions": len(transitions), "applied": applied}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--campaign", required=True, type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign
    case_rows = read_tsv(campaign / "packet-cases.tsv")
    accepted = 0
    rejected = 0
    for row in case_rows:
        case_dir = campaign / "packets" / row["case_id"]
        actual_ok, actual_code, actual_rung = classify(case_dir)
        expected_ok = row["actual_ok"] == "1"
        if (actual_ok, actual_code, actual_rung) != (expected_ok, row["actual_code"], row["rung"]):
            raise ValueError(f"packet reconstruction mismatch: {row['case_id']}")
        result_rows = read_tsv(case_dir / "result.tsv")
        if len(result_rows) != 1 or result_rows[0]["authority_granted"] != "0" \
                or result_rows[0]["capture_bound"] != "0":
            raise ValueError("packet result overpromotion")
        if actual_ok:
            accepted += 1
            proposal = parse_record((case_dir / "proposal.tsv").read_bytes(), PROPOSAL_KEYS)
            assert proposal is not None
            trace_result = parse_trace((case_dir / "trace.bin").read_bytes(),
                                       int(proposal["baseline_bytes"]) // int(proposal["sector_size"]))
            assert trace_result is not None
            norm = normalized(*trace_result)
            replay = replay_manifest((case_dir / "baseline.bin").read_bytes(), *trace_result)
            if norm != (campaign / "accepted" / f"{row['case_id']}.normalized.tsv").read_bytes() \
                    or replay != (campaign / "accepted" / f"{row['case_id']}.replay.tsv").read_bytes():
                raise ValueError("accepted canonical output mismatch")
        else:
            rejected += 1
    ceremony = verify_ceremony(campaign)
    certificate = json.loads((campaign / "certificate.json").read_text())
    expected = {
        "packet_cases": len(case_rows), "packet_accepted": accepted,
        "packet_rejected": rejected, "ceremony_states": ceremony["states"],
        "ceremony_transitions": ceremony["transitions"],
        "ceremony_applied_edges": ceremony["applied"],
    }
    for key, value in expected.items():
        if certificate.get(key) != value:
            raise ValueError(f"certificate mismatch {key}")
    mandatory_false = [
        "capture_bound_results", "parser_disagreements",
        "restart_after_activation_closes_export", "unknown_remove_closes_export",
        "publication_promotes_capture", "hidden_writer_can_export",
        "coherent_forgery_authentic", "numeric_pid_proves_process_custody",
        "packet_authority_granted", "native_capture_performed",
    ]
    if any(certificate.get(key) not in {0, False} for key in mandatory_false):
        raise ValueError("certificate mandatory nonclaim failed")
    if certificate.get("coherent_forgery_accepted_as_candidate") is not True \
            or certificate.get("hidden_writer_same_packet_different_history") is not True \
            or certificate.get("fixture_only") is not True \
            or certificate.get("sha256_known_answer_pass") is not True:
        raise ValueError("counterexample certificate missing")
    for name in [
        "coherent-forgery.tsv", "numeric-pid-not-process-custody.tsv",
        "hidden-writer-bypass.tsv", "publication-nonpromotion.tsv",
    ]:
        if not (campaign / "counterexamples" / name).is_file():
            raise ValueError(f"missing counterexample {name}")
    audit = {
        "schema": "slopos.rev0882.trace-subject-audit.v1",
        "status": "PASS",
        **expected,
        "ceremony_rejected_edges": ceremony["transitions"] - ceremony["applied"],
        "capture_bound_results": 0,
        "native_capture_performed": False,
        "authority_granted": False,
        "source_separated": True,
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print(
        "TRACE_SUBJECT_AUDIT=PASS"
        f" packet_cases={len(case_rows)} accepted={accepted} rejected={rejected}"
        f" states={ceremony['states']} transitions={ceremony['transitions']}"
        " capture_bound=0 native_capture=false authority_granted=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
