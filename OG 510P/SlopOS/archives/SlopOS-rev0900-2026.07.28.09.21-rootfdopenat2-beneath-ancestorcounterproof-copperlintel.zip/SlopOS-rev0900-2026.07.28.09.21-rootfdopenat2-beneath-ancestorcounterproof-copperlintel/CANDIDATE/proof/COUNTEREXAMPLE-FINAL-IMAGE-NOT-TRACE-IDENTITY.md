# Counterexample: final image is not trace identity

`mark-stutter` and `same-final-different-trace` contain different event sequences
and different raw bytes but replay to one exact final image. Marks stutter and a
later overwrite erases an earlier write from the final image.

Consequently a final image cannot identify the trace that produced it. Image
identity and trace identity require separate domains and separate custody.
