#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

BLOCK = 512
BLOCKS = 6
IMAGE_SIZE = BLOCK * BLOCKS


def fail(detail: str) -> None:
    raise SystemExit(f"CRASH_IMAGE_AUDIT=FAIL detail={detail}")


def read_exact(path: Path, size: int) -> bytes:
    data = path.read_bytes()
    if len(data) != size:
        fail(f"size path={path} expected={size} observed={len(data)}")
    return data


def fnv1a64(data: bytes) -> str:
    value = 14695981039346656037
    for byte in data:
        value ^= byte
        value = (value * 1099511628211) & ((1 << 64) - 1)
    return f"{value:016x}"


@dataclass(frozen=True)
class Parsed:
    outcome: str
    local: str
    floor: str
    result: str
    effect: int


def load_schema(root: Path) -> dict[str, bytes]:
    names = {
        "header.bin": BLOCK,
        "floor-predecessor.bin": BLOCK,
        "floor-successor.bin": BLOCK,
        "endpoint-effect.bin": BLOCK,
        "result-no-effect.bin": BLOCK,
        "result-effect.bin": BLOCK,
        "zero.bin": BLOCK,
        "journal-c1.bin": BLOCK * 2,
        "journal-c2.bin": BLOCK * 2,
        "journal-c3-no-effect.bin": BLOCK * 2,
        "journal-c3-effect.bin": BLOCK * 2,
        "journal-c3-uncertain.bin": BLOCK * 2,
        "journal-c4-no-effect.bin": BLOCK * 2,
        "journal-c4-effect.bin": BLOCK * 2,
        "journal-c4-uncertain.bin": BLOCK * 2,
        "initial-image.bin": IMAGE_SIZE,
    }
    observed = {p.name for p in root.iterdir() if p.is_file()}
    if observed != set(names):
        fail(f"schema files missing={sorted(set(names)-observed)} extra={sorted(observed-set(names))}")
    return {name: read_exact(root / name, size) for name, size in names.items()}


def slots(image: bytes) -> tuple[bytes, bytes]:
    return image[BLOCK:2 * BLOCK], image[2 * BLOCK:3 * BLOCK]


def exact_local(image: bytes, schema: dict[str, bytes]) -> str:
    slot0, slot1 = slots(image)
    zero = schema["zero.bin"]
    maps: list[dict[bytes, tuple[int, str]]] = [
        {
            schema["journal-c2.bin"][:BLOCK]: (2, "C2"),
            schema["journal-c4-no-effect.bin"][:BLOCK]: (4, "C4_NO_EFFECT"),
            schema["journal-c4-effect.bin"][:BLOCK]: (4, "C4_EFFECT"),
            schema["journal-c4-uncertain.bin"][:BLOCK]: (4, "C4_UNCERTAIN"),
        },
        {
            schema["journal-c1.bin"][BLOCK:]: (1, "C1"),
            schema["journal-c3-no-effect.bin"][BLOCK:]: (3, "C3_NO_EFFECT"),
            schema["journal-c3-effect.bin"][BLOCK:]: (3, "C3_EFFECT"),
            schema["journal-c3-uncertain.bin"][BLOCK:]: (3, "C3_UNCERTAIN"),
        },
    ]
    records: list[tuple[int, str] | None] = []
    for idx, block in enumerate((slot0, slot1)):
        if block == zero:
            records.append(None)
        elif block in maps[idx]:
            records.append(maps[idx][block])
        else:
            return "INVALID"
    present = [record for record in records if record is not None]
    if not present:
        return "INVALID"
    if len(present) == 1:
        return present[0][1]
    older, newer = sorted(present, key=lambda value: value[0])
    successors = {
        "C1": {"C2"},
        "C2": {"C3_NO_EFFECT", "C3_EFFECT", "C3_UNCERTAIN"},
        "C3_NO_EFFECT": {"C4_NO_EFFECT"},
        "C3_EFFECT": {"C4_EFFECT"},
        "C3_UNCERTAIN": {"C4_UNCERTAIN"},
    }
    if newer[0] != older[0] + 1 or newer[1] not in successors.get(older[1], set()):
        return "INVALID"
    return newer[1]


def classify(image: bytes, schema: dict[str, bytes]) -> Parsed:
    block = [image[i * BLOCK:(i + 1) * BLOCK] for i in range(BLOCKS)]
    local = exact_local(image, schema)
    floor = (
        "PREDECESSOR" if block[3] == schema["floor-predecessor.bin"] else
        "SUCCESSOR" if block[3] == schema["floor-successor.bin"] else
        "INVALID"
    )
    result = (
        "ABSENT" if block[5] == schema["zero.bin"] else
        "NO_EFFECT" if block[5] == schema["result-no-effect.bin"] else
        "EFFECT" if block[5] == schema["result-effect.bin"] else
        "INVALID"
    )
    effect = 0 if block[4] == schema["zero.bin"] else 1 if block[4] == schema["endpoint-effect.bin"] else -1
    if block[0] != schema["header.bin"] or "INVALID" in {local, floor, result} or effect < 0:
        return Parsed("FAIL_STOP", local, floor, result, max(effect, 0))
    if local == "C1":
        if floor == "PREDECESSOR" and result == "ABSENT" and effect == 0:
            return Parsed("UNCERTAIN", local, floor, result, effect)
        return Parsed("FAIL_STOP", local, floor, result, effect)
    if local == "C2":
        if floor == "PREDECESSOR" and (result != "ABSENT" or effect != 0):
            return Parsed("FAIL_STOP", local, floor, result, effect)
        if result == "ABSENT":
            return Parsed("UNCERTAIN", local, floor, result, effect)
        if floor != "SUCCESSOR":
            return Parsed("FAIL_STOP", local, floor, result, effect)
        if result == "EFFECT" and effect == 1:
            return Parsed("EFFECT", local, floor, result, effect)
        if result == "NO_EFFECT" and effect == 0:
            return Parsed("NO_EFFECT", local, floor, result, effect)
        return Parsed("FAIL_STOP", local, floor, result, effect)
    if floor != "SUCCESSOR":
        return Parsed("FAIL_STOP", local, floor, result, effect)
    if local in {"C3_NO_EFFECT", "C4_NO_EFFECT"}:
        outcome = "NO_EFFECT" if result == "NO_EFFECT" and effect == 0 else "FAIL_STOP"
        return Parsed(outcome, local, floor, result, effect)
    if local in {"C3_EFFECT", "C4_EFFECT"}:
        outcome = "EFFECT" if result == "EFFECT" and effect == 1 else "FAIL_STOP"
        return Parsed(outcome, local, floor, result, effect)
    if local in {"C3_UNCERTAIN", "C4_UNCERTAIN"}:
        if result == "ABSENT":
            return Parsed("UNCERTAIN", local, floor, result, effect)
        if result == "EFFECT" and effect == 1:
            return Parsed("EFFECT", local, floor, result, effect)
        if result == "NO_EFFECT" and effect == 0:
            return Parsed("NO_EFFECT", local, floor, result, effect)
        return Parsed("FAIL_STOP", local, floor, result, effect)
    return Parsed("FAIL_STOP", local, floor, result, effect)


def journal_write(before: bytes, after: bytes) -> tuple[int, bytes]:
    changed = [i for i in range(2) if before[i * BLOCK:(i + 1) * BLOCK] != after[i * BLOCK:(i + 1) * BLOCK]]
    if len(changed) != 1:
        fail("journal transition does not change exactly one slot")
    slot = changed[0]
    return 1 + slot, after[slot * BLOCK:(slot + 1) * BLOCK]


def write_map(schema: dict[str, bytes]) -> dict[str, tuple[str, int, bytes]]:
    mapping: dict[str, tuple[str, int, bytes]] = {}
    for label, before, after in (
        ("write-c2-slot", "journal-c1.bin", "journal-c2.bin"),
        ("write-c3-effect-slot", "journal-c2.bin", "journal-c3-effect.bin"),
        ("write-c4-effect-slot", "journal-c3-effect.bin", "journal-c4-effect.bin"),
        ("write-c3-no-effect-slot", "journal-c2.bin", "journal-c3-no-effect.bin"),
        ("write-c4-no-effect-slot", "journal-c3-no-effect.bin", "journal-c4-no-effect.bin"),
    ):
        block, data = journal_write(schema[before], schema[after])
        mapping[label] = ("LOCAL", block, data)
    mapping.update({
        "rollback-local-slot-0": ("LOCAL", 1, schema["journal-c1.bin"][:BLOCK]),
        "rollback-local-slot-1": ("LOCAL", 2, schema["journal-c1.bin"][BLOCK:]),
        "write-floor-successor": ("FLOOR", 3, schema["floor-successor.bin"]),
        "rollback-floor-predecessor": ("FLOOR", 3, schema["floor-predecessor.bin"]),
        "write-endpoint-effect": ("ENDPOINT", 4, schema["endpoint-effect.bin"]),
        "rollback-effect-absent": ("ENDPOINT", 4, schema["zero.bin"]),
        "write-result-effect": ("ENDPOINT", 5, schema["result-effect.bin"]),
        "write-result-no-effect": ("ENDPOINT", 5, schema["result-no-effect.bin"]),
        "write-result-no-effect-late": ("ENDPOINT", 5, schema["result-no-effect.bin"]),
        "rollback-result-absent": ("ENDPOINT", 5, schema["zero.bin"]),
    })
    return mapping


def apply_selected(stable: bytes, pending: dict[str, list[tuple[int, bytes]]], masks: tuple[int, int, int]) -> bytes:
    result = bytearray(stable)
    for device, mask in zip(("LOCAL", "FLOOR", "ENDPOINT"), masks, strict=True):
        for index, (block, data) in enumerate(pending[device]):
            if mask & (1 << index):
                result[block * BLOCK:(block + 1) * BLOCK] = data
    return bytes(result)


def audit(campaign: Path, json_path: Path | None) -> None:
    summary = json.loads((campaign / "summary.json").read_text(encoding="utf-8"))
    if summary.get("schema") != "slopos.rev0880.crash-image-summary.v1" or summary.get("status") != "PASS":
        fail("summary identity")
    if summary.get("physical_power_loss_claim") is not False or summary.get("dm_log_writes_capture") is not False:
        fail("claim boundary")
    schema = load_schema(campaign / "schema")
    initial = schema["initial-image.bin"]
    expected_initial = bytearray(IMAGE_SIZE)
    expected_initial[:BLOCK] = schema["header.bin"]
    expected_initial[BLOCK:3 * BLOCK] = schema["journal-c1.bin"]
    expected_initial[3 * BLOCK:4 * BLOCK] = schema["floor-predecessor.bin"]
    if bytes(expected_initial) != initial:
        fail("initial image derivation")

    image_dir = campaign / "images"
    image_paths = sorted(p for p in image_dir.iterdir() if p.is_file())
    images = {p.name: read_exact(p, IMAGE_SIZE) for p in image_paths}
    if len(set(images.values())) != len(images):
        fail("duplicate unique image files")
    image_name_by_bytes = {data: name for name, data in images.items()}

    with (campaign / "index.tsv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    required = [
        "record_id", "trace", "cut", "operation", "kind", "device",
        "pending_local", "pending_floor", "pending_endpoint", "mask_local",
        "mask_floor", "mask_endpoint", "image", "fnv1a64", "class_sealed",
        "class_exact", "local", "floor", "endpoint_result", "effect_present", "witness",
    ]
    if not rows or list(rows[0]) != required:
        fail("index header")
    outcomes: Counter[str] = Counter()
    by_cut: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    witnesses: Counter[str] = Counter()
    for expected_id, row in enumerate(rows):
        if int(row["record_id"]) != expected_id:
            fail(f"record id {row['record_id']}")
        data = images.get(row["image"])
        if data is None:
            fail(f"missing image {row['image']}")
        if fnv1a64(data) != row["fnv1a64"]:
            fail(f"fnv {row['image']}")
        parsed = classify(data, schema)
        observed = Parsed(row["class_sealed"], row["local"], row["floor"], row["endpoint_result"], int(row["effect_present"]))
        if parsed != observed or row["class_exact"] != parsed.outcome:
            fail(f"classification record={expected_id} parsed={parsed} observed={observed}")
        if parsed.local in {"C1", "C2"} and parsed.result == "ABSENT" and parsed.outcome == "NO_EFFECT":
            fail(f"absence narrowed record={expected_id}")
        outcomes[parsed.outcome] += 1
        by_cut[(row["trace"], int(row["cut"]))].append(row)
        if row["witness"] != "-":
            witnesses[row["witness"]] += 1
    if set(row["image"] for row in rows) != set(images):
        fail("unreferenced or missing unique image")

    with (campaign / "operations.tsv").open(encoding="utf-8", newline="") as stream:
        operations = list(csv.DictReader(stream, delimiter="\t"))
    if operations and list(operations[0]) != ["trace", "index", "kind", "device", "block", "label"]:
        fail("operations header")
    traces: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in operations:
        if int(row["index"]) != len(traces[row["trace"]]):
            fail(f"operation index trace={row['trace']}")
        traces[row["trace"]].append(row)
    if set(traces) != {"good-effect", "good-no-effect", "bad-mark-is-not-flush", "bad-result-after-local-completion", "bad-whole-image-rollback"}:
        fail(f"trace set {sorted(traces)}")

    writes = write_map(schema)
    simulated_records = 0
    for trace, ops in traces.items():
        stable = initial
        pending: dict[str, list[tuple[int, bytes]]] = {"LOCAL": [], "FLOOR": [], "ENDPOINT": []}
        for cut in range(len(ops) + 1):
            actual = by_cut.get((trace, cut), [])
            if not actual:
                fail(f"missing cut trace={trace} cut={cut}")
            expected: set[tuple[int, int, int, int, int, int, str]] = set()
            for ml in range(1 << len(pending["LOCAL"])):
                for mf in range(1 << len(pending["FLOOR"])):
                    for me in range(1 << len(pending["ENDPOINT"])):
                        data = apply_selected(stable, pending, (ml, mf, me))
                        name = image_name_by_bytes.get(data)
                        if name is None:
                            fail(f"simulated image not materialized trace={trace} cut={cut}")
                        expected.add((len(pending["LOCAL"]), len(pending["FLOOR"]), len(pending["ENDPOINT"]), ml, mf, me, name))
            observed = {
                (int(r["pending_local"]), int(r["pending_floor"]), int(r["pending_endpoint"]),
                 int(r["mask_local"]), int(r["mask_floor"]), int(r["mask_endpoint"]), r["image"])
                for r in actual
            }
            if expected != observed or len(actual) != len(expected):
                fail(f"cut enumeration trace={trace} cut={cut}")
            simulated_records += len(expected)
            if cut == len(ops):
                continue
            op = ops[cut]
            kind, device, label = op["kind"], op["device"], op["label"]
            if kind == "WRITE":
                spec = writes.get(label)
                if spec is None or spec[0] != device or spec[1] != int(op["block"]):
                    fail(f"write specification trace={trace} label={label}")
                pending[device].append((spec[1], spec[2]))
            elif kind == "FLUSH":
                for block, data in pending[device]:
                    mutable = bytearray(stable)
                    mutable[block * BLOCK:(block + 1) * BLOCK] = data
                    stable = bytes(mutable)
                pending[device].clear()
            elif kind == "MARK":
                pass
            else:
                fail(f"operation kind {kind}")
    if simulated_records != len(rows):
        fail("simulated record count")

    def cut_images(trace: str, operation: str) -> set[bytes]:
        return {images[row["image"]] for row in rows if row["trace"] == trace and row["operation"] == operation}

    if cut_images("bad-mark-is-not-flush", "write-c2-slot") != cut_images("bad-mark-is-not-flush", "mark-c2-without-flush"):
        fail("mark is not stuttering")
    rollback_rows = [row for row in rows if row["witness"] == "ROLLBACK_IMAGE_COLLIDES_WITH_INITIAL"]
    if len(rollback_rows) != 1 or images[rollback_rows[0]["image"]] != initial or rollback_rows[0]["class_sealed"] != "UNCERTAIN":
        fail("rollback collision witness")
    if witnesses != Counter({
        "MARK_IS_NOT_FLUSH": 1,
        "RESULT_MUST_PRECEDE_LOCAL_NARROWING": 1,
        "ROLLBACK_IMAGE_COLLIDES_WITH_INITIAL": 1,
    }):
        fail(f"witnesses {witnesses}")

    expected_summary = {
        "traces": len(traces),
        "cuts": sum(len(ops) + 1 for ops in traces.values()),
        "records": len(rows),
        "unique_images": len(images),
        "classifications": len(rows),
        "cross_reopener_disagreements": 0,
    }
    for key, value in expected_summary.items():
        if summary.get(key) != value:
            fail(f"summary {key}")
    if summary.get("outcomes") != dict(outcomes):
        fail(f"outcome summary expected={dict(outcomes)} observed={summary.get('outcomes')}")
    for key in ("mark_stutters", "mark_not_flush_witness", "result_before_completion_witness", "rollback_image_collision_witness", "final_effect", "final_no_effect"):
        if summary.get(key) is not True:
            fail(f"summary boolean {key}")

    audit = {
        "schema": "slopos.rev0880.crash-image-audit.v1",
        "status": "PASS",
        "source_separated": True,
        "independent_actor": False,
        "physical_power_loss_claim": False,
        "traces": len(traces),
        "cuts": expected_summary["cuts"],
        "records": len(rows),
        "unique_images": len(images),
        "outcomes": dict(outcomes),
        "witnesses": dict(witnesses),
        "simulation_reconstructed": True,
        "image_only_c1_no_effect": False,
    }
    if json_path is not None:
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "CRASH_IMAGE_AUDIT=PASS"
        f" traces={len(traces)} cuts={expected_summary['cuts']} records={len(rows)}"
        f" unique_images={len(images)} effect={outcomes['EFFECT']}"
        f" no_effect={outcomes['NO_EFFECT']} uncertain={outcomes['UNCERTAIN']}"
        f" fail_stop={outcomes['FAIL_STOP']} witnesses={sum(witnesses.values())}"
        " source_separated=true independent_actor=false power_loss_claim=false"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Source-separated rev0880 bounded crash-image checker")
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    audit(args.campaign.resolve(), args.json.resolve() if args.json else None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
