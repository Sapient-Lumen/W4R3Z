#!/usr/bin/env python3
"""Audit the rooted descriptor/path-adversary campaign table."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

EXPECTED = (
    ("root-symlink", "reject"),
    ("ancestor-symlink", "reject"),
    ("fixed-child-symlink", "reject"),
    ("dotdot-leaf", "reject"),
    ("slash-leaf", "reject"),
    ("absolute-leaf", "reject"),
    ("magic-or-leaf-symlink", "reject"),
    ("root-path-rebind", "retained-fd-target"),
    ("child-path-rebind", "retained-child-fd-target"),
    ("exact-incumbent", "created-then-exact"),
    ("wrong-incumbent", "conflict"),
    ("retained-identities", "unchanged"),
)


def audit(path: Path) -> dict[str, object]:
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        assert reader.fieldnames == ["case", "expected", "observed", "status"]
        rows = list(reader)
    assert [(row["case"], row["expected"]) for row in rows] == list(EXPECTED)
    assert all(row["status"] == "PASS" and row["observed"] for row in rows)
    return {
        "status": "PASS",
        "cases": len(rows),
        "passed": sum(row["status"] == "PASS" for row in rows),
        "root_path_rebind_retained_fd": True,
        "child_path_rebind_retained_fd": True,
        "no_replace_wrong_incumbent_refused": True,
        "all_component_hosted_profile": True,
        "deployment_kernel_theorem": False,
        "exclusive_writer_claim": False,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--table", type=Path, required=True)
    p.add_argument("--json", type=Path)
    a = p.parse_args()
    report = audit(a.table)
    if a.json:
        a.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"PATH_AUDIT=PASS cases={report['cases']} passed={report['passed']} all_component_hosted_profile=true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
