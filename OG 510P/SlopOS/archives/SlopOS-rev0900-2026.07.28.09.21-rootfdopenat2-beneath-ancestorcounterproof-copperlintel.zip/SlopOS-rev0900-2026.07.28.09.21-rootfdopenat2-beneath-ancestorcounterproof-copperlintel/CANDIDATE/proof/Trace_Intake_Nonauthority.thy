theory Trace_Intake_Nonauthority
  imports Main
begin

datatype event = Write nat nat | Flush | Mark

type_synonym image = "nat => nat"

fun apply_event :: "event => image => image" where
  "apply_event (Write address value) image = image(address := value)"
| "apply_event Flush image = image"
| "apply_event Mark image = image"

fun replay :: "event list => image => image" where
  "replay [] image = image"
| "replay (event # rest) image = replay rest (apply_event event image)"

lemma mark_stutters:
  "replay [Mark] image = image"
  by simp

lemma flush_stutters_in_image_projection:
  "replay [Flush] image = image"
  by simp

lemma different_traces_same_image:
  "[Write 0 1, Mark] ~= [Mark, Write 0 1] &
   replay [Write 0 1, Mark] (\<lambda>_. 0) =
   replay [Mark, Write 0 1] (\<lambda>_. 0)"
  by simp

lemma observation_collision_prevents_exact_classification:
  assumes "observe h0 = observe h1"
      and "fact h0 ~= fact h1"
  shows "classify (observe h0) ~= fact h0 |
         classify (observe h1) ~= fact h1"
  using assms by auto

end
