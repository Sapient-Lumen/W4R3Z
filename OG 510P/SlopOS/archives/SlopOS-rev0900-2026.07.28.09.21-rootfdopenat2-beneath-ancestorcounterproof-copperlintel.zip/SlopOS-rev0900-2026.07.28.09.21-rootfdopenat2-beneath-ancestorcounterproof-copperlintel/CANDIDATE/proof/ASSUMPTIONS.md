# Assumptions and limits

## Hosted packet assumptions

- Inputs are finite byte strings and the baseline fits the rev0881 strict trace
  replay profile.
- Proposal, Witness and Receipt use the exact canonical v1 TSV grammar.
- SHA-256 known-answer checks pass for two standard vectors; this is diagnostic,
  not a cryptographic proof.
- The constrained and reference C++ parsers are separately structured but share
  types, serializers and the same actor.
- The Python checker shares the written protocol vocabulary but not the C++
  record parsers or ceremony transition implementation.
- The capture ceremony is finite and models ordering, not operating-system or
  hardware semantics.

## External context assumption

`CAPTURE_BOUND` is reachable only when an external `ValidationContext` states all
provider, machine, process-custody and exclusive-writer predicates and the input
is not a fixture. Rev0882 supplies no such trusted context and tests no real
provider. The interface is a boundary declaration, not a discharged premise.

## Explicitly unavailable premises

- No fixture was acquired from a live device-mapper target.
- No authenticated capture provider, machine/boot binding, process-instance
  custody, namespace ownership, executable continuity or exclusive writer set is
  established.
- No packet field is treated as proof of its own producer or environment.
- No capture-bound result grants approval, policy, retry or effect authority.
- No target durability, electrical interruption, protected endpoint result or
  protected rollback floor is established.
- FNV-1a remains diagnostic and noncryptographic.
- Isabelle is unavailable; retained theories are unreplayed source.
- Same-actor source separation is not independent stewardship.
