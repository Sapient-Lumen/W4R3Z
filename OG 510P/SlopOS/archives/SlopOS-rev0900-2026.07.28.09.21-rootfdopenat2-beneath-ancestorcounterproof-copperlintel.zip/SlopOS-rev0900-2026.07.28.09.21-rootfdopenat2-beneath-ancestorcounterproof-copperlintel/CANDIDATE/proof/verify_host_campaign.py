#!/usr/bin/env python3
"""Source-separated reopener for rev0879 hosted process-cut specimens.

It does not import or invoke the C++ classifier/recovery implementation.  It
reads exact fixture bytes and reconstructs the claimed classifications.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path

CUTS = (
    "00-initialized", "01-c1-admitted", "02-pending-retained",
    "03-c2-readback", "04-selector-advanced", "05-floor-advanced",
    "06-confirmed-advanced", "07-pending-retired",
    "08-activation-consumed", "09-dispatch-entered",
    "10-exact-no-effect-result", "11-effect-observed",
    "12-c3-effect-completed", "13-c4-effect-published",
)
EXPECTED_CRASH = {
    CUTS[0]: "EMPTY_STABLE",
    CUTS[1]: "C1_INERT",
    CUTS[2]: "C1_PREPARED",
    **{cut: "C2_UNCERTAIN" for cut in CUTS[3:10]},
    CUTS[10]: "C2_EXACT_NO_EFFECT_OBSERVED",
    CUTS[11]: "C2_EFFECT_OBSERVED",
    CUTS[12]: "EFFECT_COMPLETED",
    CUTS[13]: "EFFECT_PUBLISHED",
}
EXPECTED_RECOVERED = {
    CUTS[0]: "EMPTY_STABLE",
    CUTS[1]: "C1_INERT",
    CUTS[2]: "C1_PREPARED",
    **{cut: "UNCERTAINTY_PUBLISHED" for cut in CUTS[3:10]},
    CUTS[10]: "NO_EFFECT_PUBLISHED",
    CUTS[11]: "EFFECT_PUBLISHED",
    CUTS[12]: "EFFECT_PUBLISHED",
    CUTS[13]: "EFFECT_PUBLISHED",
}
REQUIRED_SCHEMA = {
    "empty.bin", "c1.bin", "c2.bin",
    "c3-no-effect.bin", "c3-effect.bin", "c3-uncertain.bin",
    "c4-no-effect.bin", "c4-effect.bin", "c4-uncertain.bin",
    "predecessor.bin", "successor.bin", "pending.bin", "effect.bin",
    "endpoint-no-effect.bin", "endpoint-effect.bin",
}


@dataclass(frozen=True)
class Classification:
    label: str
    durable: str
    phase: str
    endpoint: str
    effect: bool


def regular_tree(root: Path) -> None:
    assert root.is_dir() and not root.is_symlink(), root
    for base, directories, files in os.walk(root, followlinks=False):
        base_path = Path(base)
        for name in directories + files:
            path = base_path / name
            mode = os.lstat(path).st_mode
            assert not stat.S_ISLNK(mode), f"symlink in specimen: {path}"
            assert stat.S_ISDIR(mode) or stat.S_ISREG(mode), f"special path: {path}"


def read_required(path: Path) -> bytes:
    mode = os.lstat(path).st_mode
    assert stat.S_ISREG(mode), f"missing/nonregular: {path}"
    return path.read_bytes()


def read_optional(path: Path) -> bytes | None:
    try:
        mode = os.lstat(path).st_mode
    except FileNotFoundError:
        return None
    assert stat.S_ISREG(mode), f"optional nonregular: {path}"
    return path.read_bytes()


def classify(root: Path, schema: dict[str, bytes]) -> Classification:
    regular_tree(root)
    journal = read_required(root / "journal/current.bin")
    durable_by_bytes = {
        schema["empty.bin"]: "empty",
        schema["c1.bin"]: "c1",
        schema["c2.bin"]: "c2",
        schema["c3-no-effect.bin"]: "c3-no-effect",
        schema["c3-effect.bin"]: "c3-effect",
        schema["c3-uncertain.bin"]: "c3-uncertain",
        schema["c4-no-effect.bin"]: "c4-no-effect",
        schema["c4-effect.bin"]: "c4-effect",
        schema["c4-uncertain.bin"]: "c4-uncertain",
    }
    assert journal in durable_by_bytes, f"unknown journal: {root}"
    durable = durable_by_bytes[journal]

    selector = read_required(root / "install/selector.bin")
    confirmed = read_required(root / "install/confirmed.bin")
    floor = read_required(root / "floor/floor.bin")
    pending = read_optional(root / "install/pending.bin")
    p = schema["predecessor.bin"]
    s = schema["successor.bin"]
    exact_pending = schema["pending.bin"]
    if selector == p and confirmed == p and floor == p and pending is None:
        phase = "stable-predecessor"
    elif selector == p and confirmed == p and floor == p and pending == exact_pending:
        phase = "prepared"
    elif selector == s and confirmed == p and floor == p and pending == exact_pending:
        phase = "selected-floor-pending"
    elif selector == s and confirmed == p and floor == s and pending == exact_pending:
        phase = "floor-advanced"
    elif selector == s and confirmed == s and floor == s and pending == exact_pending:
        phase = "confirmed-cleanup-pending"
    elif selector == s and confirmed == s and floor == s and pending is None:
        phase = "stable-successor"
    else:
        raise AssertionError(f"contradictory external phase: {root}")

    endpoint_bytes = read_optional(root / "endpoint/result.bin")
    if endpoint_bytes is None:
        endpoint = "absent"
    elif endpoint_bytes == schema["endpoint-no-effect.bin"]:
        endpoint = "exact-no-effect"
    elif endpoint_bytes == schema["endpoint-effect.bin"]:
        endpoint = "exact-effect"
    else:
        raise AssertionError(f"malformed endpoint result: {root}")

    effect_bytes = read_optional(root / "effects/effect.bin")
    if effect_bytes is None:
        effect = False
    else:
        assert effect_bytes == schema["effect.bin"], f"malformed effect: {root}"
        effect = True
    assert not (effect and endpoint == "exact-no-effect"), f"effect/no-effect contradiction: {root}"

    if durable == "empty" and phase == "stable-predecessor" and endpoint == "absent" and not effect:
        label = "EMPTY_STABLE"
    elif durable == "c1" and phase == "stable-predecessor" and not effect:
        label = "C1_INERT"
    elif durable == "c1" and phase == "prepared" and not effect:
        label = "C1_PREPARED"
    elif durable == "c2":
        assert phase in {
            "prepared", "selected-floor-pending", "floor-advanced",
            "confirmed-cleanup-pending", "stable-successor",
        }
        if effect or endpoint == "exact-effect":
            label = "C2_EFFECT_OBSERVED"
        elif endpoint == "exact-no-effect":
            label = "C2_EXACT_NO_EFFECT_OBSERVED"
        else:
            label = "C2_UNCERTAIN"
    elif durable == "c3-no-effect" and not effect:
        label = "NO_EFFECT_COMPLETED"
    elif durable == "c4-no-effect" and not effect:
        label = "NO_EFFECT_PUBLISHED"
    elif durable == "c3-effect" and effect:
        label = "EFFECT_COMPLETED"
    elif durable == "c4-effect" and effect:
        label = "EFFECT_PUBLISHED"
    elif durable == "c3-uncertain":
        label = "UNCERTAINTY_COMPLETED"
    elif durable == "c4-uncertain":
        label = "UNCERTAINTY_PUBLISHED"
    else:
        raise AssertionError(
            f"unclassified: {root} durable={durable} phase={phase} endpoint={endpoint} effect={effect}"
        )
    return Classification(label, durable, phase, endpoint, effect)


def audit(campaign: Path, schema_root: Path) -> dict[str, object]:
    schema_paths = {path.name: path for path in schema_root.iterdir() if path.is_file()}
    assert set(schema_paths) == REQUIRED_SCHEMA, (set(schema_paths), REQUIRED_SCHEMA)
    schema = {name: path.read_bytes() for name, path in schema_paths.items()}
    assert len(set(schema.values())) == len(schema), "schema images must be byte-distinct"

    with (campaign / "campaign.tsv").open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        assert reader.fieldnames == [
            "cut", "crash_class", "recovered_class", "effect_before",
            "effect_after", "recovery_created_effect", "status",
        ]
        rows = list(reader)
    assert [row["cut"] for row in rows] == list(CUTS)

    created = 0
    uncertainty = 0
    no_effect = 0
    effect_publications = 0
    classifications = 0
    for row in rows:
        cut = row["cut"]
        crash = classify(campaign / "cuts" / cut / "crash", schema)
        recovered = classify(campaign / "cuts" / cut / "recovered", schema)
        classifications += 2
        assert crash.label == EXPECTED_CRASH[cut], (cut, crash)
        assert recovered.label == EXPECTED_RECOVERED[cut], (cut, recovered)
        assert row["crash_class"] == crash.label
        assert row["recovered_class"] == recovered.label
        assert int(row["effect_before"]) == int(crash.effect)
        assert int(row["effect_after"]) == int(recovered.effect)
        made = int(not crash.effect and recovered.effect)
        created += made
        assert int(row["recovery_created_effect"]) == made
        assert row["status"] == "PASS"
        uncertainty += recovered.label == "UNCERTAINTY_PUBLISHED"
        no_effect += recovered.label == "NO_EFFECT_PUBLISHED"
        effect_publications += recovered.label == "EFFECT_PUBLISHED"
    assert created == 0
    assert (uncertainty, no_effect, effect_publications) == (7, 1, 3)
    return {
        "status": "PASS",
        "cuts": len(rows),
        "classifications": classifications,
        "recoveries": len(rows),
        "recovery_created_effects": created,
        "uncertainty_publications": uncertainty,
        "no_effect_publications": no_effect,
        "effect_publications": effect_publications,
        "local_absence_closed_no_effect": False,
        "process_cut_only": True,
        "power_loss_claim": False,
        "source_separated": True,
        "independent_actor": False,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--campaign", type=Path, required=True)
    p.add_argument("--schema", type=Path, required=True)
    p.add_argument("--json", type=Path)
    a = p.parse_args()
    report = audit(a.campaign, a.schema)
    if a.json:
        a.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "HOST_REOPEN_AUDIT=PASS"
        f" cuts={report['cuts']} classifications={report['classifications']}"
        f" recovery_created_effects={report['recovery_created_effects']}"
        f" uncertainty_publications={report['uncertainty_publications']}"
        " local_absence_closed_no_effect=false power_loss_claim=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
