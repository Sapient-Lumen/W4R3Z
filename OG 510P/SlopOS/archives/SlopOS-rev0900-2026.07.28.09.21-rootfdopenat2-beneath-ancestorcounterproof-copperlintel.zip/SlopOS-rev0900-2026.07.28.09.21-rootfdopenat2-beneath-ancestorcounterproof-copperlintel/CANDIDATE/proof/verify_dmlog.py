#!/usr/bin/env python3
"""Source-separated audit for the rev0881 synthetic dm-log-writes corpus."""
from __future__ import annotations

import argparse
import csv
import json
import struct
from dataclasses import dataclass
from pathlib import Path

MAGIC = 0x6A736677736872
VERSION = 1
FLUSH = 1 << 0
FUA = 1 << 1
DISCARD = 1 << 2
MARK = 1 << 3
METADATA = 1 << 4
KNOWN = FLUSH | FUA | DISCARD | MARK | METADATA
SECTOR_SIZES = {512, 1024, 2048, 4096}
BASELINE_SECTORS = 16


class AuditError(RuntimeError):
    pass


@dataclass(frozen=True)
class Event:
    kind: str
    sector: int = 0
    nr_sectors: int = 0
    metadata: bool = False
    mark: str = ""
    data: bytes = b""


@dataclass(frozen=True)
class Parsed:
    code: str
    sector_size: int = 0
    advertised: int = 0
    events: tuple[Event, ...] = ()

    @property
    def ok(self) -> bool:
        return self.code == "OK"


def fail(detail: str) -> None:
    raise AuditError(detail)


def read_tsv(path: Path, header: list[str]) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != header:
            fail(f"header {path.name}: {reader.fieldnames}")
        return list(reader)


def fnv1a64(data: bytes) -> str:
    value = 0xCBF29CE484222325
    for byte in data:
        value ^= byte
        value = (value * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return f"{value:016x}"


def zero(data: bytes) -> bool:
    return not any(data)


def parse(raw: bytes) -> Parsed:
    if len(raw) < 28:
        return Parsed("TRUNCATED_SUPER")
    magic, version, advertised, sector_size = struct.unpack_from("<QQQI", raw, 0)
    if magic != MAGIC:
        return Parsed("BAD_MAGIC")
    if version != VERSION:
        return Parsed("BAD_VERSION")
    if sector_size not in SECTOR_SIZES:
        return Parsed("BAD_SECTOR_SIZE")
    if len(raw) < sector_size:
        return Parsed("TRUNCATED_SUPER")
    if len(raw) % sector_size:
        return Parsed("MISALIGNED_LENGTH")
    if not zero(raw[28:sector_size]):
        return Parsed("INVALID_COMBINATION")

    offset = sector_size
    events: list[Event] = []
    for _ in range(advertised):
        if offset + sector_size > len(raw):
            return Parsed("TRUNCATED_ENTRY")
        header = raw[offset : offset + sector_size]
        target, count, flags, data_len = struct.unpack_from("<QQQQ", header, 0)
        if flags & ~KNOWN:
            return Parsed("UNKNOWN_FLAGS")
        if flags & MARK:
            if (flags != MARK or target != 0 or count != 0 or data_len == 0
                    or data_len > sector_size - 32):
                return Parsed("INVALID_MARK")
            mark_bytes = header[32 : 32 + data_len]
            if (not all(0x20 <= b <= 0x7E for b in mark_bytes)
                    or not zero(header[32 + data_len :])):
                return Parsed("INVALID_MARK")
            events.append(Event("MARK", mark=mark_bytes.decode("ascii")))
            offset += sector_size
            continue
        if flags & DISCARD:
            return Parsed("UNSUPPORTED_DISCARD")
        if flags & FLUSH:
            if (flags != FLUSH or target != 0 or count != 0 or data_len != 0
                    or not zero(header[32:])):
                return Parsed("INVALID_COMBINATION")
            events.append(Event("FLUSH"))
            offset += sector_size
            continue
        if count == 0 or data_len != 0 or not zero(header[32:]):
            return Parsed("INVALID_COMBINATION")
        if flags not in {0, FUA, METADATA, FUA | METADATA}:
            return Parsed("INVALID_COMBINATION")
        if target > BASELINE_SECTORS or count > BASELINE_SECTORS - target:
            return Parsed("OUT_OF_RANGE")
        payload_bytes = count * sector_size
        payload_start = offset + sector_size
        payload_end = payload_start + payload_bytes
        if payload_end > len(raw):
            return Parsed("TRUNCATED_PAYLOAD")
        events.append(Event(
            "FUA_WRITE" if flags & FUA else "WRITE",
            sector=target,
            nr_sectors=count,
            metadata=bool(flags & METADATA),
            data=raw[payload_start:payload_end],
        ))
        offset = payload_end
    if offset != len(raw):
        return Parsed("TRAILING_BYTES")
    return Parsed("OK", sector_size, advertised, tuple(events))


def replay(baseline: bytes, parsed: Parsed, prefix: int) -> bytes:
    if not parsed.ok or prefix < 0 or prefix > len(parsed.events):
        fail("invalid replay request")
    image = bytearray(baseline)
    for event in parsed.events[:prefix]:
        if event.kind in {"WRITE", "FUA_WRITE"}:
            start = event.sector * parsed.sector_size
            end = start + len(event.data)
            if end > len(image):
                fail("replay outside baseline")
            image[start:end] = event.data
    return bytes(image)


def event_row(case_id: str, index: int, event: Event) -> dict[str, str]:
    return {
        "case_id": case_id,
        "index": str(index),
        "kind": event.kind,
        "sector": str(event.sector),
        "nr_sectors": str(event.nr_sectors),
        "metadata": "1" if event.metadata else "0",
        "mark": event.mark,
        "data_bytes": str(len(event.data)),
        "data_fnv1a64": fnv1a64(event.data),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    root = args.campaign.resolve()

    expected_profile = {
        "schema": "slopos.rev0881.dm-log-writes-intake-profile.v1",
        "format": "linux-dm-log-writes-v1-trimmed-export",
        "digest64_algorithm": "fnv1a64-standard-offset-basis",
        "sector_sizes": [512, 1024, 2048, 4096],
        "discard_admitted": False,
        "combined_preflush_write_admitted": False,
        "structural_validation_only": True,
        "authentic_acquisition": False,
        "machine_bound": False,
        "physical_power_loss_claim": False,
        "authority_granted": False,
    }
    if json.loads((root / "profile.json").read_text()) != expected_profile:
        fail("profile")

    cases = read_tsv(root / "cases.tsv", [
        "case_id", "expected_accept", "expected_code", "actual_code",
        "primary_ok", "reference_ok", "entries", "end_mark", "raw_bytes",
        "raw_fnv1a64",
    ])
    events = read_tsv(root / "events.tsv", [
        "case_id", "index", "kind", "sector", "nr_sectors", "metadata",
        "mark", "data_bytes", "data_fnv1a64",
    ])
    prefixes = read_tsv(root / "prefixes.tsv", [
        "case_id", "prefix", "last_kind", "image_id", "image_fnv1a64",
    ])
    images = read_tsv(root / "images.tsv", [
        "image_id", "bytes", "fnv1a64", "first_case", "first_prefix",
    ])
    hidden = read_tsv(root / "hidden-histories.tsv", [
        "history_id", "case_id", "raw_fnv1a64", "later_unadvertised_write",
        "target_effect_after_prefix", "observation",
    ])
    witnesses = read_tsv(root / "witnesses.tsv", ["witness", "holds", "basis"])
    if len(cases) != 25 or len({row["case_id"] for row in cases}) != 25:
        fail("case set")
    baseline = (root / "baseline.bin").read_bytes()
    if len(baseline) != 8192 or any(baseline):
        fail("baseline")

    derived_events: list[dict[str, str]] = []
    derived_prefixes: list[dict[str, str]] = []
    image_ids: dict[bytes, str] = {}
    image_first: dict[str, tuple[str, int]] = {}
    parsed_by_case: dict[str, Parsed] = {}
    raw_by_case: dict[str, bytes] = {}
    accepted = rejected = entries_count = marks = flushes = fua = ends = 0

    for row in cases:
        case_id = row["case_id"]
        raw = (root / "logs" / f"{case_id}.bin").read_bytes()
        parsed = parse(raw)
        expected_accept = row["expected_accept"] == "1"
        if (row["expected_code"] != parsed.code or row["actual_code"] != parsed.code
                or (row["primary_ok"] == "1") != parsed.ok
                or (row["reference_ok"] == "1") != parsed.ok
                or expected_accept != parsed.ok
                or int(row["raw_bytes"]) != len(raw)
                or row["raw_fnv1a64"] != fnv1a64(raw)):
            fail(f"case row {case_id}")
        raw_by_case[case_id] = raw
        if not parsed.ok:
            rejected += 1
            if row["entries"] != "0" or row["end_mark"] != "0":
                fail(f"rejected projection {case_id}")
            continue
        accepted += 1
        parsed_by_case[case_id] = parsed
        entries_count += len(parsed.events)
        end_present = any(e.kind == "MARK" and e.mark == "dm-log-writes-end"
                          for e in parsed.events)
        ends += int(end_present)
        if int(row["entries"]) != len(parsed.events) or (row["end_mark"] == "1") != end_present:
            fail(f"accepted projection {case_id}")
        for index, event in enumerate(parsed.events):
            derived_events.append(event_row(case_id, index, event))
            marks += int(event.kind == "MARK")
            flushes += int(event.kind == "FLUSH")
            fua += int(event.kind == "FUA_WRITE")
        for prefix in range(len(parsed.events) + 1):
            image = replay(baseline, parsed, prefix)
            if image not in image_ids:
                image_id = f"image-{len(image_ids):04d}"
                image_ids[image] = image_id
                image_first[image_id] = (case_id, prefix)
            image_id = image_ids[image]
            last = "START" if prefix == 0 else parsed.events[prefix - 1].kind
            derived_prefixes.append({
                "case_id": case_id,
                "prefix": str(prefix),
                "last_kind": last,
                "image_id": image_id,
                "image_fnv1a64": fnv1a64(image),
            })

    if events != derived_events:
        fail("event table")
    if prefixes != derived_prefixes:
        fail("prefix table")
    derived_images: list[dict[str, str]] = []
    for image, image_id in image_ids.items():
        path = root / "images" / f"{image_id}.bin"
        if path.read_bytes() != image:
            fail(f"image bytes {image_id}")
        first_case, first_prefix = image_first[image_id]
        derived_images.append({
            "image_id": image_id,
            "bytes": str(len(image)),
            "fnv1a64": fnv1a64(image),
            "first_case": first_case,
            "first_prefix": str(first_prefix),
        })
    if images != derived_images:
        fail("image table")

    expected_hidden = [
        {"history_id": "H0", "case_id": "end-mark-no-flush",
         "raw_fnv1a64": fnv1a64(raw_by_case["end-mark-no-flush"]),
         "later_unadvertised_write": "0", "target_effect_after_prefix": "0",
         "observation": "IDENTICAL_ADVERTISED_BYTES"},
        {"history_id": "H1", "case_id": "end-mark-no-flush",
         "raw_fnv1a64": fnv1a64(raw_by_case["end-mark-no-flush"]),
         "later_unadvertised_write": "1", "target_effect_after_prefix": "1",
         "observation": "IDENTICAL_ADVERTISED_BYTES"},
    ]
    if hidden != expected_hidden:
        fail("hidden histories")

    mark_case = parsed_by_case["mark-stutter"]
    witness_values = {
        "MARK_REPLAY_STUTTER": replay(baseline, mark_case, 1) == replay(baseline, mark_case, 2),
        "FINAL_IMAGE_NOT_UNIQUE_TRACE": (
            replay(baseline, mark_case, len(mark_case.events))
            == replay(baseline, parsed_by_case["same-final-different-trace"], 4)
            and raw_by_case["mark-stutter"] != raw_by_case["same-final-different-trace"]),
        "ADVERTISED_PREFIX_NOT_TARGET_ABSENCE": hidden[0]["raw_fnv1a64"] == hidden[1]["raw_fnv1a64"]
            and hidden[0]["target_effect_after_prefix"] != hidden[1]["target_effect_after_prefix"],
        "END_MARK_WITHOUT_TARGET_FLUSH": (
            any(e.kind == "MARK" and e.mark == "dm-log-writes-end"
                for e in parsed_by_case["end-mark-no-flush"].events)
            and not any(e.kind in {"FLUSH", "FUA_WRITE"}
                        for e in parsed_by_case["end-mark-no-flush"].events)),
        "STRUCTURAL_ACCEPTANCE_NOT_AUTHENTICITY": accepted > 0,
    }
    if {row["witness"] for row in witnesses} != set(witness_values):
        fail("witness set")
    if any((row["holds"] == "1") != witness_values[row["witness"]]
           or not row["basis"] for row in witnesses):
        fail("witness rows")

    expected_summary = {
        "schema": "slopos.rev0881.dm-log-writes-summary.v1",
        "status": "PASS",
        "cases": 25,
        "accepted": 7,
        "rejected": 18,
        "accepted_entries": 24,
        "replay_prefixes": 31,
        "unique_images": 9,
        "parser_disagreements": 0,
        "marks": 9,
        "flushes": 6,
        "fua_writes": 1,
        "end_marks": 6,
        "witnesses": witness_values,
        "synthetic_fixtures": True,
        "dm_log_writes_capture": False,
        "authentic_acquisition": False,
        "physical_power_loss_claim": False,
        "authority_granted": False,
    }
    if json.loads((root / "summary.json").read_text()) != expected_summary:
        fail("summary")
    if (accepted, rejected, entries_count, len(derived_prefixes), len(image_ids),
            marks, flushes, fua, ends) != (7, 18, 24, 31, 9, 9, 6, 1, 6):
        fail("derived metrics")

    audit = {
        "schema": "slopos.rev0881.dm-log-writes-audit.v1",
        "status": "PASS",
        "cases": 25,
        "accepted": 7,
        "rejected": 18,
        "entries": 24,
        "prefixes": 31,
        "unique_images": 9,
        "witnesses": witness_values,
        "source_separated": True,
        "synthetic_fixtures": True,
        "authentic_acquisition": False,
        "physical_power_loss_claim": False,
        "authority_granted": False,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print("DMLOG_AUDIT=PASS cases=25 accepted=7 rejected=18 entries=24 "
          "prefixes=31 unique_images=9 witnesses=5 source_separated=true "
          "synthetic=true authentic_acquisition=false "
          "physical_power_loss_claim=false authority_granted=false")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AuditError as error:
        raise SystemExit(f"DMLOG_AUDIT=FAIL detail={error}")
