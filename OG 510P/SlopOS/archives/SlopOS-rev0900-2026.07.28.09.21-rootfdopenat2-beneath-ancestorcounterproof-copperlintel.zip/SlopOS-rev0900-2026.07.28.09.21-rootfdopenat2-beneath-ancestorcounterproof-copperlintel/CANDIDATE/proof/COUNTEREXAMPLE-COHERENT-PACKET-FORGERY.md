# Counterexample: coherent packet forgery

An ordinary unprivileged process can synthesize Proposal, Witness, Receipt,
baseline and trace bytes that satisfy every canonical grammar, digest, replay and
lifecycle join in the packet validator.

The hosted corpus retains two accepted histories:

```text
system-owned-hypothesis -> EXPORT_CLOSED_CANDIDATE
ordinary-process-forgery -> EXPORT_CLOSED_CANDIDATE
```

Both have `authentic_acquisition=false` and `authority_granted=false`. The packet
observation is therefore compatible with authentic and inauthentic producer
histories. No function of packet coherence alone can distinguish them.

The correction is not another self-asserted packet field. Capture binding must
consume separately authenticated provider, machine, process-custody and
exclusive-writer facts.
