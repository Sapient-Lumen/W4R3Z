#!/usr/bin/env python3
"""Source-separated structural audit of the retained rev0879 relation.

This checker deliberately does not import, compile, or call either C++
transition implementation.  It treats relation.tsv as an untrusted claimed
finite graph and rechecks the authority-relevant graph properties.
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
from dataclasses import dataclass
from pathlib import Path

EVENTS = (
    "admit", "prepare-exact", "prepare-wrong", "plan-c2",
    "advance-selector", "advance-floor", "advance-confirmed",
    "retire-pending", "activate-exact", "activate-mismatch",
    "enter-dispatch-exact", "enter-dispatch-mismatch",
    "return-no-effect", "return-effect", "return-malformed",
    "reconcile-no-effect", "reconcile-effect", "reconcile-malformed",
    "complete-no-effect", "complete-effect", "complete-uncertain",
    "publish-no-effect", "publish-effect", "publish-uncertain", "restart",
    "observe-floor-predecessor", "observe-floor-successor",
    "observe-floor-unavailable", "observe-floor-malformed",
    "observe-floor-wrong-identity", "rollback-local-keep-floor",
    "rollback-local-and-floor", "rollback-c2-keep-floor",
)
HEADER = ["from_id", "event", "outcome", "to_id", "effect", "from_state", "to_state"]


@dataclass(frozen=True)
class State:
    durable: str
    selector: str
    confirmed: str
    pending: str
    floor: str
    activation: int
    permit: int
    recovered: int
    reconcile_only: int
    dispatch: str
    current_effect: int
    effects: int


@dataclass(frozen=True)
class Edge:
    source: int
    event: str
    outcome: str
    target: int
    effect: int
    before: State
    after: State


def fail(message: str) -> None:
    raise AssertionError(message)


def parse_bit(token: str, prefix: str) -> int:
    if token not in (prefix + "0", prefix + "1"):
        fail(f"bad {prefix} bit: {token}")
    return int(token[-1])


def parse_state(text: str) -> State:
    parts = text.split("|")
    if len(parts) != 12:
        fail(f"state field count: {text}")
    durable, selector, confirmed, pending, floor, pa, dp, rec, recon, dispatch, ce, effects = parts
    if durable not in {
        "empty", "c1", "c2", "c3-no-effect", "c3-effect", "c3-uncertain",
        "c4-no-effect", "c4-effect", "c4-uncertain",
    }:
        fail(f"durable: {durable}")
    if selector not in {"P", "S"} or confirmed not in {"P", "S"}:
        fail("selector/confirmed")
    if pending not in {"absent", "exact", "wrong"}:
        fail(f"pending: {pending}")
    if floor not in {"predecessor", "successor", "unavailable", "malformed", "wrong-identity"}:
        fail(f"floor: {floor}")
    if dispatch not in {"not-entered", "unknown", "exact-no-effect", "exact-effect"}:
        fail(f"dispatch: {dispatch}")
    try:
        count = int(effects)
    except ValueError as exc:
        raise AssertionError(f"effect count: {effects}") from exc
    if count < 0 or count > 2:
        fail(f"effect count bound: {count}")
    return State(
        durable, selector, confirmed, pending, floor,
        parse_bit(pa, "pa"), parse_bit(dp, "dp"), parse_bit(rec, "r"),
        parse_bit(recon, "x"), dispatch, parse_bit(ce, "ce"), count,
    )


def fnv1a64(data: bytes) -> str:
    h = 1469598103934665603
    for byte in data:
        h ^= byte
        h = (h * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return f"{h:016x}"


def audit(relation: Path, certificate: Path) -> dict[str, object]:
    raw = relation.read_bytes()
    if not raw.endswith(b"\n"):
        fail("relation missing final newline")
    with relation.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames != HEADER:
            fail(f"relation header: {reader.fieldnames}")
        rows = list(reader)
    cert = json.loads(certificate.read_text(encoding="utf-8"))
    if cert.get("schema") != "slopos.rev0879.crash-refinement.v1" or cert.get("status") != "PASS":
        fail("certificate identity/status")

    edges: list[Edge] = []
    states: dict[int, State] = {}
    by_source: dict[int, list[Edge]] = collections.defaultdict(list)
    for index, row in enumerate(rows, 1):
        try:
            source = int(row["from_id"])
            target = int(row["to_id"])
            effect = int(row["effect"])
        except ValueError as exc:
            raise AssertionError(f"numeric row {index}") from exc
        if source < 0 or target < 0 or effect not in (0, 1):
            fail(f"numeric domain row {index}")
        if row["event"] not in EVENTS or row["outcome"] not in {"applied", "rejected"}:
            fail(f"event/outcome row {index}")
        before = parse_state(row["from_state"])
        after = parse_state(row["to_state"])
        edge = Edge(source, row["event"], row["outcome"], target, effect, before, after)
        edges.append(edge)
        by_source[source].append(edge)
        if source in states and states[source] != before:
            fail(f"source state disagreement {source}")
        states[source] = before
        if target in states and states[target] != after:
            fail(f"target state disagreement {target}")
        states[target] = after

    ids = sorted(states)
    if ids != list(range(len(ids))):
        fail("state ids not contiguous")
    if len(rows) != len(states) * len(EVENTS):
        fail("relation not saturated")
    for state_id in ids:
        lane = by_source.get(state_id, [])
        if [edge.event for edge in lane] != list(EVENTS):
            fail(f"event lane/order {state_id}")
        if len(lane) != len(EVENTS):
            fail(f"event lane size {state_id}")

    applied: dict[int, list[Edge]] = collections.defaultdict(list)
    recovered_effects = 0
    unknown_no_effect = 0
    uncertainty_edges = 0
    exact_no_effect_edges = 0
    effect_edges = 0
    restart_edges = 0
    for edge in edges:
        if edge.outcome == "rejected":
            if edge.target != edge.source or edge.after != edge.before or edge.effect:
                fail(f"reject mutation: {edge.source}/{edge.event}")
            continue
        applied[edge.source].append(edge)
        if edge.effect:
            effect_edges += 1
            if edge.before.recovered:
                recovered_effects += 1
            if edge.event != "return-effect":
                fail(f"unexpected effect event: {edge.event}")
            if edge.before.durable != "c2" or edge.before.dispatch != "unknown" or edge.before.permit:
                fail("effect without entered/consumed dispatch")
            if edge.after.effects != edge.before.effects + 1 or not edge.after.current_effect:
                fail("effect ghost accounting")
        if edge.event == "complete-no-effect":
            exact_no_effect_edges += 1
            if edge.before.dispatch == "unknown":
                unknown_no_effect += 1
            if edge.before.dispatch != "exact-no-effect":
                fail("no-effect completion lacked exact no-effect knowledge")
        if edge.event == "complete-uncertain":
            uncertainty_edges += 1
            if edge.before.dispatch != "unknown" or edge.after.durable != "c3-uncertain":
                fail("uncertainty completion shape")
        if edge.event == "restart":
            restart_edges += 1
            if edge.after.activation or edge.after.permit or not edge.after.recovered:
                fail("restart retained/minted live authority")
            if edge.after.durable in {"c1", "c2"} and not edge.after.reconcile_only:
                fail("restart failed to fence active journal recovery")
            if edge.after.durable == "c2" and edge.after.dispatch != "unknown":
                fail("restart failed to widen C2 knowledge")
        if edge.before.recovered and edge.effect:
            fail("recovered first effect")
        # reconcile_only forbids a new activation/dispatch edge.  A live
        # process that already entered dispatch may still receive its exact
        # return; only recovered states are forbidden from emitting an effect.

    # Every claimed state must be graph-reachable from state zero using applied edges.
    reached = {0}
    queue = collections.deque([0])
    parent: dict[int, tuple[int, str]] = {}
    while queue:
        source = queue.popleft()
        for edge in applied[source]:
            if edge.target not in reached:
                reached.add(edge.target)
                parent[edge.target] = (source, edge.event)
                queue.append(edge.target)
    if reached != set(ids):
        fail(f"unreachable states: {sorted(set(ids)-reached)[:8]}")

    duplicate_ids = [state_id for state_id, state in states.items() if state.effects >= 2]
    if not duplicate_ids:
        fail("rollback duplicate witness absent")
    witness_id = min(duplicate_ids)
    witness_events: list[str] = []
    cursor = witness_id
    while cursor != 0:
        source, event = parent[cursor]
        witness_events.append(event)
        cursor = source
    witness_events.reverse()
    if "rollback-local-and-floor" not in witness_events or witness_events.count("return-effect") < 2:
        fail("duplicate witness lacks full rollback/two effects")

    # Conditional product search: after successor floor is seen, exclude every
    # applied edge whose target floor is not successor.  This rechecks the C++
    # report without assuming any real provider has this property.
    initial_seen = states[0].floor == "successor"
    product_seen = {(0, initial_seen)}
    product_queue = collections.deque([(0, initial_seen)])
    monotone_duplicate = False
    while product_queue:
        source, successor_seen = product_queue.popleft()
        if states[source].effects >= 2:
            monotone_duplicate = True
            break
        for edge in applied[source]:
            next_is_successor = edge.after.floor == "successor"
            if successor_seen and not next_is_successor:
                continue
            item = (edge.target, successor_seen or next_is_successor)
            if item not in product_seen:
                product_seen.add(item)
                product_queue.append(item)
    if monotone_duplicate:
        fail("duplicate reachable under conditional successor-floor monotonicity")

    observed = {
        "states": len(states),
        "transitions": len(edges),
        "events_per_state": len(EVENTS),
        "effect_edges": effect_edges,
        "recovered_first_effect_edges": recovered_effects,
        "unknown_no_effect_completion_edges": unknown_no_effect,
        "uncertainty_completion_edges": uncertainty_edges,
        "exact_no_effect_completion_edges": exact_no_effect_edges,
        "duplicate_under_floor_monotonicity": monotone_duplicate,
        "relation_fnv1a64": fnv1a64(raw),
    }
    for key, value in observed.items():
        if cert.get(key) != value:
            fail(f"certificate mismatch {key}: {cert.get(key)!r} != {value!r}")
    if recovered_effects != 0 or unknown_no_effect != 0 or uncertainty_edges == 0 or exact_no_effect_edges == 0:
        fail("authority property accounting")
    if cert.get("rollback_counterexample") is None or "rollback-local-and-floor" not in cert["rollback_counterexample"]:
        fail("certificate rollback witness")

    return {
        "status": "PASS",
        **observed,
        "reachable_states": len(reached),
        "restart_edges": restart_edges,
        "rollback_duplicate_witness": "start -> " + " -> ".join(witness_events) + " -> effects>=2",
        "source_separated": True,
        "independent_actor": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--relation", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    report = audit(args.relation, args.certificate)
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "RELATION_AUDIT=PASS"
        f" states={report['states']} transitions={report['transitions']}"
        f" recovered_first_effect_edges={report['recovered_first_effect_edges']}"
        f" unknown_no_effect_completion_edges={report['unknown_no_effect_completion_edges']}"
        f" uncertainty_completion_edges={report['uncertainty_completion_edges']}"
        " rollback_counterexample=retained monotone_floor_duplicate=no"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
