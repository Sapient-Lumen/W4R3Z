theory Process_Lifetime_Exec_Epoch
  imports Main
begin

datatype phase = Idle | Created | ExecA | ObservedA | ExecB | ObservedB | Exited | Waited | Published

datatype event = ClonePidfd | ExecAByFd | ObserveA | ExecBSameLifetime |
                 ObserveB | ProcessExit | WaitPidfd | Publish

record state =
  phase :: phase
  pidfd_bound :: bool
  no_new_privs :: bool
  initial_launch_closed :: bool
  executable_replaced :: bool
  executable_continuity_bound :: bool
  provider_authenticated :: bool
  authority_granted :: bool

fun step :: "state => event => state option" where
  "step s ClonePidfd = (if phase s = Idle then Some (s\<lparr>phase := Created, pidfd_bound := True\<rparr>) else None)" |
  "step s ExecAByFd = (if phase s = Created \<and> pidfd_bound s
      then Some (s\<lparr>phase := ExecA, no_new_privs := True\<rparr>) else None)" |
  "step s ObserveA = (if phase s = ExecA \<and> pidfd_bound s \<and> no_new_privs s
      then Some (s\<lparr>phase := ObservedA, initial_launch_closed := True\<rparr>) else None)" |
  "step s ExecBSameLifetime = (if phase s = ObservedA \<and> pidfd_bound s
      then Some (s\<lparr>phase := ExecB, executable_replaced := True,
                    executable_continuity_bound := False\<rparr>) else None)" |
  "step s ObserveB = (if phase s = ExecB \<and> pidfd_bound s \<and> no_new_privs s
      then Some (s\<lparr>phase := ObservedB\<rparr>) else None)" |
  "step s ProcessExit = (if phase s = ObservedB then Some (s\<lparr>phase := Exited\<rparr>) else None)" |
  "step s WaitPidfd = (if phase s = Exited \<and> pidfd_bound s
      then Some (s\<lparr>phase := Waited\<rparr>) else None)" |
  "step s Publish = (if phase s = Waited then Some (s\<lparr>phase := Published\<rparr>) else None)"

definition safe :: "state => bool" where
  "safe s \<longleftrightarrow> \<not> provider_authenticated s \<and> \<not> authority_granted s"

lemma step_preserves_nonauthority:
  assumes "safe s" and "step s e = Some t"
  shows "safe t"
  using assms by (cases e; auto simp: safe_def split: if_splits)

lemma exec_replacement_breaks_continuity:
  assumes "step s ExecBSameLifetime = Some t"
  shows "pidfd_bound t \<and> executable_replaced t \<and> \<not> executable_continuity_bound t"
  using assms by (auto split: if_splits)

lemma publication_does_not_authenticate:
  assumes "step s Publish = Some t"
  shows "provider_authenticated t = provider_authenticated s \<and>
         authority_granted t = authority_granted s"
  using assms by (auto split: if_splits)

end
