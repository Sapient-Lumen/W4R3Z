# Counterexample — local narrowing before result custody

Trace: `bad-result-after-local-completion`.

1. Durably admit C2 and advance the successor floor.
2. Write a local C3 `NO_EFFECT` completion.
3. Flush `LOCAL` before writing and flushing the exact endpoint result.
4. Crash.

The reopened image says C3 `NO_EFFECT` while the endpoint-result block is
absent. This is not merely `UNCERTAIN`; it is an integrity contradiction and
classifies `FAIL_STOP`. A local terminal claim must not outrun the exact result
that justifies it.

Retained witness: `RESULT_MUST_PRECEDE_LOCAL_NARROWING`.
