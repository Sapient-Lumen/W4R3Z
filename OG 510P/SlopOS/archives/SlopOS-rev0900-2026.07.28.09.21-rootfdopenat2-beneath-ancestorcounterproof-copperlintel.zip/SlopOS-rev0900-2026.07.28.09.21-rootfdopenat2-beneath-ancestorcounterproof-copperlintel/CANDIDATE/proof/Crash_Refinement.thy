theory Crash_Refinement
  imports Main
begin

datatype phase = Empty | C1 | C2 | C3No | C3Yes | C3Unknown
               | C4No | C4Yes | C4Unknown
datatype knowledge = NotEntered | Unknown | ExactNo | ExactYes
datatype actual_outcome = NoEffect | Effect
datatype marker = Absent | ExactMarker | MalformedMarker

record machine =
  phase :: phase
  recovered :: bool
  activation :: bool
  permit :: bool
  knowledge :: knowledge
  emitted :: nat

fun restart :: "machine \<Rightarrow> machine" where
  "restart s = s\<lparr>recovered := True, activation := False, permit := False,
                    knowledge := (if phase s = C2 then Unknown else knowledge s)\<rparr>"

fun complete_no :: "machine \<Rightarrow> machine" where
  "complete_no s =
     (if phase s = C2 \<and> knowledge s = ExactNo
      then s\<lparr>phase := C3No\<rparr> else s)"

fun complete_unknown :: "machine \<Rightarrow> machine" where
  "complete_unknown s =
     (if phase s = C2 \<and> knowledge s = Unknown
      then s\<lparr>phase := C3Unknown\<rparr> else s)"

fun dispatch_entry :: "machine \<Rightarrow> machine" where
  "dispatch_entry s =
     (if phase s = C2 \<and> \<not> recovered s \<and> permit s
      then s\<lparr>permit := False, knowledge := Unknown\<rparr> else s)"

record hidden_history =
  actual :: actual_outcome
  durable :: phase
  local_marker :: marker

abbreviation no_history :: hidden_history where
  "no_history \<equiv> \<lparr>actual = NoEffect, durable = C2, local_marker = Absent\<rparr>"
abbreviation yes_history :: hidden_history where
  "yes_history \<equiv> \<lparr>actual = Effect, durable = C2, local_marker = Absent\<rparr>"

definition local_observation :: "hidden_history \<Rightarrow> phase \<times> marker" where
  "local_observation h = (durable h, local_marker h)"

lemma restart_authority_free:
  "\<not> activation (restart s) \<and> \<not> permit (restart s)"
  by simp

lemma restart_c2_unknown:
  assumes "phase s = C2"
  shows "knowledge (restart s) = Unknown"
  using assms by simp

lemma unknown_does_not_complete_no:
  assumes "phase s = C2" "knowledge s = Unknown"
  shows "complete_no s = s"
  using assms by simp

lemma unknown_completes_unknown:
  assumes "phase s = C2" "knowledge s = Unknown"
  shows "phase (complete_unknown s) = C3Unknown"
  using assms by simp

lemma recovered_dispatch_entry_nonemitting:
  assumes "recovered s"
  shows "emitted (dispatch_entry s) = emitted s"
  using assms by simp

lemma local_collision:
  "local_observation no_history = local_observation yes_history
   \<and> actual no_history \<noteq> actual yes_history"
  by (simp add: local_observation_def)

text \<open>
  The collision lemma records the key negative result: exact C2 plus an absent
  local marker cannot determine the actual effect outcome.  This theory is a
  compact design proof, not the complete C++ relation.  It is retained as
  UNREPLAYED_ENVIRONMENT_UNAVAILABLE in rev0879.
\<close>

end
