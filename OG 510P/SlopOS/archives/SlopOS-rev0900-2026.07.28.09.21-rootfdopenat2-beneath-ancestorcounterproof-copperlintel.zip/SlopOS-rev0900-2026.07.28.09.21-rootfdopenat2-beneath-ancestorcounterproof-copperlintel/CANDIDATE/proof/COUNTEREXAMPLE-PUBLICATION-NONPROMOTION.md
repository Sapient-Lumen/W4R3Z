# Counterexample: publication does not promote evidence

Before and after immutable publication, the same hosted packet remains:

```text
EXPORT_CLOSED_CANDIDATE
capture_bound = false
authority_granted = false
```

Publication improves availability and custody of exact bytes. It does not
authenticate the producer, establish completeness, bind a machine, close a
writer set or grant control authority. Any design in which a receipt becomes
more trusted merely because it was published confuses custody with provenance.
