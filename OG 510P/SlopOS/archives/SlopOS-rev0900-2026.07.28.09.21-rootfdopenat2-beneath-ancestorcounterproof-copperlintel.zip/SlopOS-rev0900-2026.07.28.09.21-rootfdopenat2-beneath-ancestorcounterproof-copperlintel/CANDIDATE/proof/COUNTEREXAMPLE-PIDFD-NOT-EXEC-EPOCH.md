# Counterexample: pidfd is not executable epoch

One child is created with `clone3(CLONE_PIDFD)`. Worker A enters, reports and
waits. The supervisor records the pidfd, process start time and executable A.
Worker A then executes worker B through a retained descriptor. Worker B reports
under the same numeric PID and the same process start time, and the same pidfd
remains the terminal wait handle.

Therefore:

```text
same pidfd and start time
  does not imply
same executable epoch
```
