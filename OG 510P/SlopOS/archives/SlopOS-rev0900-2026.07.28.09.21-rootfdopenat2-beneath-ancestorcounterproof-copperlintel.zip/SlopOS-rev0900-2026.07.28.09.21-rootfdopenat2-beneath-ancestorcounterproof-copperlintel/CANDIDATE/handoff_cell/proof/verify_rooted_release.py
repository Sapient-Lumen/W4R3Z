#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "CANDIDATE/handoff_cell"


def fail(detail: str) -> None:
    raise SystemExit(f"ROOTED_RELEASE_AUDIT=FAIL detail={detail}")


def rows(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != fields:
            fail(f"header={path.name} observed={reader.fieldnames}")
        output = list(reader)
    if any(any(value is None or value == "" for value in row.values()) for row in output):
        fail(f"empty_or_short_row={path.name}")
    return output


def source_shape() -> dict[str, object]:
    header = (SOURCE / "include/slopos/e0/handoff_cell/rooted_release_locator.hpp").read_text(encoding="utf-8")
    implementation = (SOURCE / "src/rooted_release_locator.cpp").read_text(encoding="utf-8")
    campaign = (SOURCE / "harness/rooted_release_campaign.cpp").read_text(encoding="utf-8")
    joined = header + implementation
    for fragment in (
        "RootedReleaseObservationV1", "RootedReleaseAssessment",
        "root_descriptor_cloexec_duplicate", "root_descriptor_o_path",
        "root_descriptor_not_o_path", "root_profile_reobserved_equal",
        "root_profile_continuity_proved", "resolve_beneath",
        "resolve_no_symlinks", "resolve_no_magiclinks", "resolve_no_xdev",
        "regular_only_open_enforced", "regular_only_policy_unavailable",
        "regular_only_contract_violated", "post_open_shape_is_contract_check_only",
        "root_path_reopen_rejected", "candidate_descriptor_ready",
        "candidate_bytes_read = false", "archive_digest_compared = false",
        "archive_parsed = false", "owner_custody_proved = false",
        "source_provenance_proved = false",
    ):
        if fragment not in joined:
            fail(f"source fragment={fragment}")
    for fragment in (
        "widened_leaf_tail_nofollow_follows_ancestor_symlink",
        "reopening_root_path_switches_tree",
        "ordinary_directory_fd_is_not_opath_profile",
        "prelookup_profile_is_not_postlookup_profile",
        "equal_profile_endpoints_are_not_continuity",
        "post_open_fstat_is_too_late", "rooted_open_is_not_content_identity",
        "same_device_is_not_provenance",
        "rooted_candidate_is_not_activation", "caller_reopens_root_path",
        "root_path_replaced_after_pin",
    ):
        if fragment not in campaign:
            fail(f"campaign fragment={fragment}")
    return {
        "authority_grant_callsites": 0,
        "descriptor_duplication_distinct_from_identity": True,
        "fixed_leaf_only": True,
        "o_path_premise_explicit": True,
        "ordered_root_prefix": True,
        "root_path_reopen_rejected": True,
        "regular_only_open_premise_explicit": True,
        "root_profile_continuity_proved": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()

    case_fields = [
        "case", "disposition", "observation_coherent", "root_descriptor_pinned",
        "root_descriptor_o_path", "root_identity_retained",
        "root_profile_reobserved_equal", "root_profile_continuity_proved",
        "hosted_private_root_profile", "fixed_leaf_only",
        "all_component_symlink_rejection", "beneath_restriction",
        "cross_mount_rejection", "regular_only_open_enforced",
        "post_open_shape_is_contract_check_only", "root_path_replacement_ignored",
        "candidate_descriptor_ready", "candidate_bytes_read",
        "archive_digest_compared", "archive_parsed", "caller_root_path_authority",
        "owner_custody_proved", "source_provenance_proved", "activation_authority",
        "provider_operation_authority", "root_path_replaced",
        "retained_counterexample", "judgment",
    ]
    cases = rows(args.campaign / "rooted-release-cases.tsv", case_fields)
    counters = rows(args.campaign / "rooted-release-counterexamples.tsv",
                    ["counterexample", "reproduced", "defeats", "retained_law"])
    if len(cases) != 24 or len(counters) != 11:
        fail(f"inventory cases={len(cases)} counterexamples={len(counters)}")
    if any(row["reproduced"] != "true" for row in counters):
        fail("counterexample reproduction")

    expected = {
        "missing_root_descriptor": "ROOT_DESCRIPTOR_UNAVAILABLE",
        "incoherent_downstream_flags": "OBSERVATION_INCOHERENT",
        "unduplicated_root_descriptor": "ROOT_DESCRIPTOR_UNPINNED",
        "ordinary_directory_descriptor_without_opath": "ROOT_DESCRIPTOR_NOT_OPATH",
        "root_not_directory": "ROOT_NOT_DIRECTORY",
        "root_owner_mismatch": "ROOT_PROFILE_REJECTED",
        "root_mode_not_private": "ROOT_PROFILE_REJECTED",
        "caller_selected_leaf": "ROOT_PROFILE_REJECTED",
        "openat2_unavailable": "RESOLUTION_POLICY_UNAVAILABLE",
        "beneath_missing": "RESOLUTION_POLICY_UNAVAILABLE",
        "all_symlink_rejection_missing": "RESOLUTION_POLICY_UNAVAILABLE",
        "magiclink_rejection_missing": "RESOLUTION_POLICY_UNAVAILABLE",
        "cross_mount_rejection_missing": "RESOLUTION_POLICY_UNAVAILABLE",
        "regular_only_open_unavailable": "REGULAR_ONLY_POLICY_UNAVAILABLE",
        "caller_reopens_root_path": "ROOT_PATH_REOPEN_REJECTED",
        "leaf_not_attempted": "FIXED_LEAF_UNAVAILABLE",
        "fixed_leaf_missing": "FIXED_LEAF_UNAVAILABLE",
        "leaf_policy_rejected": "FIXED_LEAF_POLICY_REJECTED",
        "root_identity_changed": "ROOT_IDENTITY_CHANGED",
        "root_profile_changed_after_lookup": "ROOT_PROFILE_CHANGED",
        "regular_only_contract_violation": "REGULAR_ONLY_CONTRACT_VIOLATED",
        "leaf_cross_device": "LEAF_CROSS_DEVICE",
        "exact_rooted_candidate_descriptor": "CANDIDATE_DESCRIPTOR_READY",
        "root_path_replaced_after_pin": "CANDIDATE_DESCRIPTOR_READY",
    }
    observed = {row["case"]: row for row in cases}
    if set(observed) != set(expected):
        fail("case names")
    for name, disposition in expected.items():
        row = observed[name]
        if row["disposition"] != disposition:
            fail(f"disposition case={name} observed={row['disposition']}")
        ready = disposition == "CANDIDATE_DESCRIPTOR_READY"
        if row["candidate_descriptor_ready"] != str(ready).lower():
            fail(f"ready case={name}")
        for field in (
            "root_profile_continuity_proved", "candidate_bytes_read",
            "archive_digest_compared", "archive_parsed",
            "caller_root_path_authority", "owner_custody_proved",
            "source_provenance_proved", "activation_authority",
            "provider_operation_authority",
        ):
            if row[field] != "false":
                fail(f"authority field={field} case={name}")
    for row in cases:
        if row["candidate_descriptor_ready"] == "true" and (
            row["root_descriptor_pinned"] != "true"
            or row["root_descriptor_o_path"] != "true"
            or row["root_identity_retained"] != "true"
            or row["root_profile_reobserved_equal"] != "true"
            or row["regular_only_open_enforced"] != "true"
            or row["post_open_shape_is_contract_check_only"] != "true"
        ):
            fail(f"ready descriptor missing ordered premise case={row['case']}")
        if row["candidate_descriptor_ready"] == "false" and row["root_path_replacement_ignored"] != "false":
            fail(f"nonready path replacement overclaim case={row['case']}")
    if observed["unduplicated_root_descriptor"]["root_identity_retained"] != "false":
        fail("duplication mislabeled as retained identity")
    ordinary = observed["ordinary_directory_descriptor_without_opath"]
    if ordinary["root_descriptor_pinned"] != "true" or ordinary["root_descriptor_o_path"] != "false":
        fail("ordinary descriptor did not isolate O_PATH premise")
    if observed["root_path_replaced_after_pin"]["root_path_replacement_ignored"] != "true":
        fail("root replacement not ignored")
    if observed["caller_reopens_root_path"]["root_path_replacement_ignored"] != "false":
        fail("root reopen retained authority")

    summary = json.loads((args.campaign / "rooted-release-summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "activation_authority": False,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "candidate_bytes_read": False,
        "cases": 24,
        "counterexamples_reproduced": 11,
        "fixed_leaf": "etcd-v3.6.14-linux-amd64.tar.gz",
        "openat2_resolution": "RESOLVE_BENEATH|RESOLVE_NO_SYMLINKS|RESOLVE_NO_MAGICLINKS|RESOLVE_NO_XDEV",
        "openat2_regular_required": True,
        "owner_custody_proved": False,
        "path_replacement_ready_descriptors": 1,
        "provider_operation_authority": False,
        "ready_descriptors": 2,
        "post_open_shape_is_contract_check_only": True,
        "root_descriptor_profile": "CALLER_SUPPLIED_O_PATH_DIRECTORY",
        "root_profile_continuity_proved": False,
        "root_profile_endpoint_equality_only": True,
        "root_path_reopen_rejections": 1,
        "schema": "slopos.rev0900.rooted-release-locator-evidence.v5",
        "source_provenance_proved": False,
        "status": "PASS",
    }
    if summary != expected_summary:
        fail(f"summary={summary!r}")

    aggregate = json.loads((args.campaign / "summary.json").read_text(encoding="utf-8"))
    for key, value in (
        ("rooted_release_cases", 24),
        ("rooted_release_counterexamples", 11),
        ("rooted_release_ready_descriptors", 2),
        ("rooted_release_path_replacement_ready_descriptors", 1),
        ("rooted_release_root_path_reopen_rejections", 1),
        ("rooted_release_owner_custody_proved", False),
        ("schema", "slopos.rev0900.handoff-cell-campaign.v12"),
    ):
        if aggregate.get(key) != value:
            fail(f"aggregate field={key} value={aggregate.get(key)!r}")

    report = {
        "activation_authority": False,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "cases": len(cases),
        "counterexamples": len(counters),
        "openat2_regular_required": True,
        "post_open_shape_is_contract_check_only": True,
        "descriptor_duplication_distinct_from_identity": True,
        "o_path_premise_explicit": True,
        "owner_custody_proved": False,
        "ready_descriptors": 2,
        "root_path_reopen_rejections": 1,
        "root_profile_changed_endpoints_rejected": True,
        "root_profile_continuity_proved": False,
        "root_profile_endpoint_equality_only": True,
        "schema": "slopos.rev0900.rooted-release-independent-audit.v5",
        "source_provenance_proved": False,
        "source_shape": source_shape(),
        "status": "PASS",
    }
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "ROOTED_RELEASE_AUDIT=PASS cases=24 counterexamples=11 ready=2 "
        "opath=explicit regular_only=true duplication_is_not_identity=true profile_continuity=false "
        "path_replacement_ready=1 root_reopen_rejected=1 owner_custody=false "
        "digest=false parse=false activation=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
