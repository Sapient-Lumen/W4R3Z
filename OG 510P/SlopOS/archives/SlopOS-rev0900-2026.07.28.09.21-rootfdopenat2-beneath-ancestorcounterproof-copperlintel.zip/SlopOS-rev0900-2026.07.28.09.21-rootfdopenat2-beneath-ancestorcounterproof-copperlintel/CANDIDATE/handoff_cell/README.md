# Hosted handoff vertical

This C++20 Linux package is one hosted proof island. It is not a protected
capability, authenticated provider, admitted endpoint epoch, durable result
service, product daemon, or release.

## Current refinement

V1–V7 established a bounded sequence of local facts: fixed no-replace handoff,
principal separation, immutable result versions, exact launch descriptor
census, authority-first ancillary rejection, staged endpoint publication,
process-instance observation, actor-local burn of one sealed expected-process
capsule, and finally fixed `pending -> claimed` before record or proposer
meaning. The V7 winner receives one internal move-only `ClaimedPending` only
after exact readback and successful directory synchronization. Every duplicate,
synchronization-uncertain outcome, and reopen is query-only.

V8 adds a **hosted one-attempt settlement adapter** inside this same island:

```text
fresh local claim
  -> consume before request meaning
  -> exact request makes one submit_exact call
  -> exact bound terminal record refines the result
  -> no-return / unavailable / malformed / foreign remains uncertain

reopen
  -> one query_exact call
  -> zero submit calls
  -> exact-unused may refine to no-effect under the provider premise
  -> no retry authority
```

The public `SettlementObservation` is copyable but powerless. It always remains
query-only and has `response_authority=false` and `retry_authority=false`.
There is no resubmit, retry, compensation, publication, reverse-claim, or
recovery-apply entrypoint.

## Evidence

The V8 campaign adds:

```text
14 settlement cases
4 scheduled settlement process-death cuts
16 coherent local histories against one shared scripted provider
16 submissions / 1 fresh provider commit / 15 duplicates / 1 effect
4 settlement countermodels
```

An independent Python oracle verifies the exact case inventory, source order,
one submit callsite, zero recovery-submit paths, exact crash outcomes, and
absence of response or retry authority.

The four governing V8 defeats are not caveats:

- a malformed return may follow a committed effect;
- coherent provider clones can each commit the same effect;
- finite idempotency retention permits a later duplicate effect; and
- distinct providers can emit byte-identical result records after two effects.

Therefore the provider object is a premise, not authority. V8 proves client
settlement behavior only under one supplied provider history. It does not prove
provider identity, exclusive writer custody, lifetime deduplication, restore or
failover continuity, external newestness, stable media, protected effect, or
protected settlement.

## V9 owner-pinned history observation

V9 adds a fixed 320-byte owner/provider genesis and a fixed 320-byte provider append observation. The exact genesis is selected by a SHA-256 pin and verified with an owner Ed25519 public key; the append is verified with the provider key named by that genesis and compared against every expected history-edge field. The returned `ProviderGenesisObservation` is copyable, replayable, query-only evidence. It has no response, retry, claim, effect, commit, or settlement authority and no endpoint/parser route.

The deterministic campaign retains twenty semantic cases, rejects all 2,560 one-bit mutations of each envelope, and retains five countermodels: self-selected roots, replay, coherent copies, conflicting successors signed by one provider key, and alternate owner-signed geneses. The implementation relies on OpenSSL public verification and SHA-256; deterministic private seeds and signing occur only in the harness. This construction describes signed bytes. It does not prove that an admitted provider executed a compare-and-commit, that the observation is newest, or that restore preserves the same history.

## Build and run

Build and run outside the checkpoint as root. Root is used only by the hosted
principal, publisher, and expectation-construction counterboundary campaigns.

```text
cmake -S CANDIDATE/handoff_cell -B /tmp/slopos-handoff-build -G Ninja
cmake --build /tmp/slopos-handoff-build
/tmp/slopos-handoff-build/slopos_handoff_cell campaign /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_campaign.py \
  /tmp/slopos-handoff-output --json /tmp/slopos-handoff-output/audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_endpoint_claim.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/endpoint-claim-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_settlement.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/settlement-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_provider_genesis.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/provider-genesis-audit.json
```

No build tree, binary, Python bytecode, temporary socket, database, snapshot,
or native process descriptor belongs in the checkpoint.

The GNU Release build deliberately compiles only `harness/campaign.cpp` at
`-O2`. GCC 14.2 was directly observed spending more than the cloudtainer command
envelope on that one proof-driver translation unit at `-O3`, while `-O2`
completed in seconds and reproduced the same canonical outputs. Candidate
library sources retain the selected Release optimization. This bounded compile
policy is an operator-resource constraint, not evidence of semantic equivalence
between arbitrary optimization modes.

## Inherited endpoint boundary

The provider still binds fixed `bound.sock` only after final-principal entry. A
separate publisher moves the same socket inode to fixed `query.sock` with
`RENAME_NOREPLACE`. The later query inherits no data socket, consumes one
sealed expected-process capsule before connect, and retains the connection only
when hidden connect-time and message-time process observations agree. Native
pidfds are never exported as generic process-control authority.

Those observations do not authenticate who selected the executable, minted the
capsule, published the endpoint, or controls root-equivalent administration.
Provider death is not effect completion, endpoint retirement, or successor
admission.

## Nonclaims

No owner genesis, protected provider constructor, authentic owner binding,
executable/dependency continuity, machine or service incarnation, durable
spend, global duplicate closure, stable endpoint epoch, stable media,
destructive power-loss proof, external rollback floor, authenticated provider,
independent appraiser, admitted source-to-operated-binary identity, release
authority, or epoch advance is established.

Read `spec/HANDOFF-CELL-V8.md`,
`DESIGN/HOSTED-CLAIM-SETTLEMENT.md`,
`EXCAVATION/SETTLEMENT-CUSTODY-SPINE/JUDGMENT.md`, and retained rev0896 handoff
evidence before reusing any result. V7 remains the inherited local
claim-before-parse premise; V6 remains the inherited expected-process premise.

## V10–V12 release-profile airlock

V10 retains the exact etcd v3.6.14 transaction/query profile as query-only
classification. V11 adds ordered, write-sealed passive release ingress. V12 now
adds a descriptor-rooted fixed-leaf locator prefix:

```text
caller-supplied O_PATH directory fd
  -> CLOEXEC duplicate
  -> effective-UID-owned mode-0700 hosted profile
  -> fixed etcd-v3.6.14-linux-amd64.tar.gz leaf
  -> openat2(BENEATH|NO_SYMLINKS|NO_MAGICLINKS|NO_XDEV, OPENAT2_REGULAR)
  -> post-open regular/same-device contract check only
  -> bounded candidate fd on a supporting host
  -> V11 complete pread capture into sealed memfd
  -> digest comparison and passive archive semantics
```

V12 contributes 24 finite relation cases and 11 countermodels. Exactly two ready
rows are synthetic supporting-host premises. The standalone Linux root-FD probe
contributes 21 syscall cases and 11 counterexamples,
including unsupported `OPENAT2_REGULAR`, the FIFO-open-before-`fstat` defect,
explicit `O_PATH` and duplication/identity separation, root-path replacement
versus pinned-root identity, profile drift and
`0700 -> 0755 -> 0700` ABA, and mutation of a rooted leaf before snapshot
capture. The ancestor-symlink escape uses a deliberately widened two-component
regression path; production accepts only the exact one-component leaf.

The retained 6.12.13 host cannot satisfy the atomic regular-only premise and
therefore produces no production candidate descriptor; there is no open-then-
`fstat` fallback. The profile is deliberately narrow. A host-private root is not constituted
owner custody; same-device is not provenance; rooted open is not immutable
content; sealed exact bytes are not activation; and activation is not provider
operation, commit, currentness, settlement, or authority. The exact archive is
absent, so no positive admission is claimed.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_release_fd_probe /tmp/slopos-handoff-output
/tmp/slopos-handoff-build/slopos_release_rootfd_probe /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_release_ingress.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/release-ingress-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_rooted_release.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/rooted-release-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_release_rootfd_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/release-rootfd-audit.json
```

Read `spec/HANDOFF-CELL-V12.md`,
`DESIGN/ROOTFD-BOUND-RELEASE-LOCATOR.md`, and the retained rev0900 evidence
boundary before reusing the locator result.
