# Repository V21 — three islands, two noncomposable handoff seams

## Decision

Repository V21 retains exactly three hosted semantic islands:

```text
CANDIDATE/core_gate
CANDIDATE/generation_journal
CANDIDATE/handoff_cell
```

Rev0897 extends only `handoff_cell`. No product target and no fourth island is added.

## Current responsibilities

`core_gate` owns the abstract burn-before-validation and bounded-effect relation. `generation_journal` owns canonical record identity, immutable result refinement, content-bound compare/append, and the hosted local floor/entry join. `handoff_cell` owns fixed namespace admission, principal/launch experiments, endpoint publication and process observations, sealed expected-process consumption, claim-before-parse, V8 hosted one-attempt settlement, and V9 owner-pinned provider-history observation.

The handoff package contains **47 files**. Fresh reconstruction additionally imports exactly three transparent generation-journal codec files, for **50 audited source files**. The three compiler lanes retain **31 canonical products** totaling **41,845 bytes per lane**. OpenSSL Crypto is one declared host-library dependency for SHA-256 and public Ed25519 verification. Candidate code contains no private-key route; deterministic signing is harness-only.

## Noncomposition is part of the architecture

V8 and V9 coexist but do not compose into authority:

```text
ProviderGenesisObservation --X--> HostedSettlement::settle_exact
ProviderGenesisObservation --X--> EndpointClaimCell
ProviderGenesisObservation --X--> PayloadAfterClaim
settlement observation       --X--> response or retry authority
```

This prevents a copyable signed statement from becoming a one-use claim or effect permission.

## Anti-islands

The repository still contains no owner/key service, signature or receipt service, transparency log, provider daemon, spend daemon, retry worker, endpoint/process registry, generic database layer, launcher/query/publisher service, orchestration layer, policy language, or product executable.

## Donor custody

Five implementation/proof files and one specification were recovered from an unlinked sibling cloudtainer experiment. `EXCAVATION/UNLINKED-SIBLING-DONORS.tsv` records exact source and destination identities and marks the donor as **not lineage** and **not living law**. Rev0896 hosted settlement is the sole parent. This converts otherwise orphaned proofwork into auditable source material without silently merging authority or parenthood.

## Dependency boundary

Candidate build inputs remain only the three candidate packages, the three explicit codec dependencies, and declared host toolchains/libraries. Office, evidence, excavation, design, research, review, predecessor, and donor records are not build inputs.

## Replaceability and next cut

The V9 envelope is scaffolding. A real provider profile must subsume its exact fields while moving trust to a constituted owner root, independently provisioned pin, protected provider executable/key/state, exclusive writer/admin/backup custody, exact transactional/query semantics, restore-lineage admission, external rollback floor, stable-media profile, and independent appraisal.

Repository V21 is hosted, unsealed, nonauthoritative, and source-to-operated-binary incomplete. **Remain in Epoch Zero.**
