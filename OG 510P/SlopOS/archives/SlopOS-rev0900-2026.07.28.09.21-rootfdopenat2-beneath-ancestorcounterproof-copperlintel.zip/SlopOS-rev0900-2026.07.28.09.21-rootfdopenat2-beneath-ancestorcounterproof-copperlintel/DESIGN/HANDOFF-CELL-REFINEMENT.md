# Handoff-cell refinement through V12

## One island, bounded strata

```text
V1-V7  local namespace, principal, process, publication, query and claim cuts
V8     one local claim -> at most one hosted provider submit attempt
V9     owner-key/pin-bound signed provider-history representation, query-only
V10    exact etcd v3.6.14 transaction/query profile, not operated
V11    one-open complete capture, write-sealed passive release bytes
V12    supplied-root fixed-leaf locator with atomic regular-file-only premise
```

V12 does not create authority and cannot replace V11. The caller-root relation
separates descriptor duplication, `O_PATH`, directory shape, effective-UID
ownership, mode `0700`, fixed leaf, complete resolution policy, atomic
regular-only open, pre/post identity and endpoint-profile observations.

The earlier open-then-`fstat` design was unsound as a harmless type barrier. A
retained FIFO fixture returns a descriptor before post-open rejection. V12 now
requires Linux `OPENAT2_REGULAR` in the opening syscall. A successful post-open
shape check is only verification that the kernel contract behaved as required.
The retained 6.12.13 host rejects the new bit, so production readiness is false
and no candidate descriptor is acquired.

Two of the 24 pure relation cases are descriptor-ready only under a synthetic
supporting-host premise. They are not actual host evidence. The 21-case Linux
probe retains 11 counterexamples, including the unsupported policy stop and FIFO
defect. Clang, GCC and Clang ASan/UBSan retain 52 byte-identical products over 72
audited sources, totaling 76154 canonical bytes per lane.

No upstream provenance, protected root, owner constitution, continuous profile
custody, immutable source, positive archive receipt, activation, operated
cluster, provider commit, external currentness, protected settlement or living
law is established. Remain in Epoch Zero.
