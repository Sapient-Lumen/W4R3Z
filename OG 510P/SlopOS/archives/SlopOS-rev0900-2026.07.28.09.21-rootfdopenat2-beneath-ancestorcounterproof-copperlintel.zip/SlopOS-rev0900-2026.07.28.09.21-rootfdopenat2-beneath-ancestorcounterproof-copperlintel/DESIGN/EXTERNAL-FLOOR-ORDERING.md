# External floor ordering

The selected installation order remains:

```text
successor selector
  -> successor external floor
  -> successor confirmation
  -> pending retirement
  -> live exact-readback activation
  -> selected effect
```

Moving the floor before a viable successor selector can invalidate every local
predecessor image before a successor is installed. Treating selector movement
as the selected effect fails at-most-once because selector can repeat without
floor regression. The selected effect therefore follows completed installation.

The bounded relation finds no duplicate after excluding every post-successor
floor regression. This is not a provider proof. A real floor still requires
constituted genesis, identity, exclusive writer, compare/advance, exact readback,
uncertain-return behavior, reset ceremony, and compromise recovery.
