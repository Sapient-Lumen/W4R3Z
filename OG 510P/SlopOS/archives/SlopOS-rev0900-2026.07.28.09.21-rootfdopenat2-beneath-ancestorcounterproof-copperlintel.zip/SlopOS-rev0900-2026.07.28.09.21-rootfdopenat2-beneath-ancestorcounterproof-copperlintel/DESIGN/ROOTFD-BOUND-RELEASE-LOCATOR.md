# Root-FD-bound exact release locator

## Problem

Rev0899 removed post-open archive-path reuse but still began from a pathname.
Rev0900's first correction moved to a caller-supplied root descriptor and a
complete `openat2` resolution mask, but it still opened the leaf before a later
`fstat` rejected nonregular shape. A FIFO fixture proved that this inherited
pattern had already crossed the dangerous boundary.

The correction must not become a downloader, installer, release service,
generic path sandbox, or new semantic island. It must not pretend that a
private directory is owner constitution or upstream provenance.

## Narrow construction

The operator passes an already-open root descriptor rather than a root path.
The adapter performs this exact prefix:

```text
caller-supplied descriptor
-> F_DUPFD_CLOEXEC local duplicate
-> explicit O_PATH check
-> directory + effective-UID owner + mode 0700 pre-observation
-> verify complete openat2 resolution support against the pinned root
-> verify v7.2-rc5 OPENAT2_REGULAR support without touching the release leaf
-> exact one-component leaf: etcd-v3.6.14-linux-amd64.tar.gz
-> one raw openat2 with O_RDONLY|CLOEXEC|NOFOLLOW|NONBLOCK|OPENAT2_REGULAR
-> BENEATH|NO_SYMLINKS|NO_MAGICLINKS|NO_XDEV
-> bounded regular same-device candidate descriptor
-> root object and profile endpoint reobservation
-> close duplicate; retain no raw descriptor number in evidence
```

There is no fallback. `ENOSYS`, unsupported-policy `EINVAL`, unavailable
regular-only flag, symlink, mount, beneath, profile, or contract failures stop.
No caller-selected leaf, root pathname, reconstructed `/proc/self/fd` path,
weaker lookup, or open-then-`fstat` path enters production.

## Why post-open shape is not the barrier

`fstat` can validate a successful regular-only open, but cannot make an earlier
open harmless. The retained legacy fixture opens a FIFO with the superseded
flags and receives a descriptor before rejecting the shape. Old-vault verifier
and SDK intake code used the same pattern. Those sources remain immutable
counterexamples rather than templates.

Linux v7.2-rc5 defines `OPENAT2_REGULAR` in the upper 32 bits and `EFTYPE` for a
wrong type. Unknown upper bits fail with `EINVAL`, allowing an older host to
stop before candidate acquisition. The cloudtainer's 6.12.13 kernel takes that
stop. This exact release-candidate pin must be revalidated against final v7.2
and the target host before any activation.

## What the descriptor establishes

A directory descriptor names an already-open filesystem object. Replacing the
visible pathname after pinning does not retarget operations relative to that
descriptor. A later open of the pathname can select a different tree, which is
why pathname reopen is outside the admitted path.

Successful duplication alone is not identity retention. The relation requires
coherent pre/post object equality. Equal owner/mode/shape samples are only
endpoint observations. A retained `0700 -> 0755 -> 0700` ABA shows they do not
prove uninterrupted profile custody.

## Exact input language and future-widening counterproof

The production leaf is one compile-time component, neither `.` nor `..` and
containing no slash. The Linux probe nevertheless retains a widened
`ancestor/leaf` fixture. Tail-only `O_NOFOLLOW` follows an ancestor symlink in
that widened path; the complete `openat2` mask rejects it. This is an evolution
guard, not an accepted input.

## Why this is still not custody

The root descriptor is a supplied premise. Mode `0700`, effective-UID
ownership, endpoint equality, and regular-only lookup do not prove an
independently constituted owner, continuous control, or upstream provenance. A
regular file can still have another writer.

Therefore any future positive output is only a mutable candidate descriptor.
The existing V11 seal barrier remains mandatory:

```text
rooted candidate fd
!= immutable bytes
-> complete pread capture
-> private unlinked sealable memfd
-> F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL
-> digest recomputed from sealed bytes
-> exact digest comparison
-> passive archive inspection only
```

## API boundary

The C++ relation exports only `RootedReleaseAssessment`. The Python operator may
hold a candidate internally only long enough to enter V11. Neither surface
exports a root or leaf descriptor, descriptor number, archive member,
executable path, process authority, provider client, retry surface, or
promotion token.

## Hosted and next-path judgment

On this host, production stops at `HOST_OPENAT2_REGULAR_UNAVAILABLE` before
leaf lookup. Exact archive absence is a separate datacube fact. A next positive
passive receipt requires either a target host whose **final** regular-only
contract is revalidated, or a separately governed acquisition actor that
supplies an already-open candidate descriptor so SlopOS itself performs no
special-object open. Neither route weakens to a local path open. Remain in
Epoch Zero.
