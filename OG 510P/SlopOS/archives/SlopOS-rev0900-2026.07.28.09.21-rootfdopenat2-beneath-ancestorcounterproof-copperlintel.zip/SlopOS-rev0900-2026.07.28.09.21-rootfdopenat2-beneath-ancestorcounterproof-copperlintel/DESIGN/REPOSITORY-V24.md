# Repository V24 — three islands and a fail-closed release airlock

## Judgment

Repository V24 retains exactly three semantic islands:

```text
CANDIDATE/core_gate
CANDIDATE/generation_journal
CANDIDATE/handoff_cell
```

There is no downloader, installer, package manager, release daemon, provider
SDK, database service, retry worker, registry, generic path sandbox or fourth
library. Handoff Cell V12 is a relation plus host counterproof inside the
existing handoff island. The Python admission tool is an operator proof
instrument, not a runtime service.

## V12 boundary

V12 requires one supplied `O_PATH` root, one fixed leaf, the complete
`openat2` resolution mask and `OPENAT2_REGULAR` in the same open. It has no
open-then-`fstat`, `openat`, path reopen or weaker fallback. Post-open shape is
only a contract check. The retained Linux 6.12.13 host cannot satisfy the
regular-only premise and therefore produces zero production-ready descriptors.
Two relation-ready observations are synthetic and cannot enter an activation or
provider path.

The handoff package contains 69 package-local files plus three exact codec
dependencies, for 72 audited sources. Fresh Clang, GCC and Clang ASan/UBSan lanes
produce 52 byte-identical canonical products totaling 76,154 bytes per lane.
V12 retains 24 pure relation cases and 11 countermodels; the Linux probe retains
21 cases and 11 counterexamples.

## Required downstream cut

On a future supporting host, a V12 descriptor can enter only V11 complete
capture and write sealing. It cannot enter claim parsing, provider submission,
activation, cluster operation or settlement. Rooted regular shape is not
provenance or immutable content.

## Anti-waste rule

Do not build a general safe-path library, release manager, downloader, staging
filesystem, simulated provider or broad compatibility fallback around this
theorem. Revalidate the final Linux UAPI, obtain one positive passive receipt,
and add executable surface only when a real authority boundary requires it.
Remain in Epoch Zero.
