# Repository design v8

```text
core/
  authority-state/
  effect-gate/

protocol/
  operation/
  evidence/
  appraisal/
  approval/
  endpoint-result/
  publication/
  trace-subject/
  process-subject/

policy/
  relying-party/

providers/
  acquisition/tpm/
  acquisition/block-trace/
  capture-supervisor/
  process-custody/
  executable-continuity/
  approval/
  endpoint/
  floor/
  storage/

effects/
  generation-journal/

lab/
  authority-relation/
  process/launch-custody/
  process/exec-replacement/
  crash/logical-profile/
  trace/intake/
  trace/subject-packet/
  path/
  fixtures/

proof/
  formal/
  source-separated-checkers/

vault/
  imports/
  blobs/

releases/
  candidates/
  sealed/

office/
  constitution/
  decisions/
  incidents/
  gates.tsv
  obligations.tsv
  claims.tsv
  state.json
```

## Dependency law

`core/` may consume typed appraisals and protected one-use capabilities. It must
not parse `/proc`, pidfds, executable maps, raw TPM objects, block traces, crash
images, vault capsules, compiler logs or release manifests.

The launch supervisor, executable-continuity observer, process-custody provider,
provider appraiser, relying-party policy and protected effect route are separate
packages and separate types. A synthetic fixture cannot inhabit a
`ProviderAuthenticatedProcessCustody` type.

## Release law

The datacube is primarily laboratory, custody and office machinery around a much
smaller prospective core. Full immutable capsules are reserved for deliberate
authority gates. Intermediate work uses content-addressed blobs and sparse
path/mode/digest manifests without changing lineage semantics.
