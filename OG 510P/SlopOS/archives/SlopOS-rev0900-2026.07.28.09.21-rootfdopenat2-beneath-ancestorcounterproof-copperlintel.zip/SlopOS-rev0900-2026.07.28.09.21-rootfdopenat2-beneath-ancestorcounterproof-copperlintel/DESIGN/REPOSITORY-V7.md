# Proposed repository v7

```text
core/
  state/                       minimal deterministic authority state
  effect-gate/                 one bounded permit-consumption interface

protocol/
  operation/
  evidence/
  appraisal/
  approval/
  endpoint-result/
  publication/
  trace-subject/               canonical Proposal/Witness/Receipt schemas
  provider-context/            externally rooted capture-binding result

policy/
  relying-party/               authorization, retry and compensation policy

providers/
  acquisition/
    tpm/                       neutral TPM evidence producer
    block-trace/
      supervisor/              privileged ceremony owner
      appraiser/               separate provider/process/writer verifier
      linux-dmlog-v1/          native mapping profile
  approval/                    owner/user approval mint
  floor/                       protected anti-rollback generation service
  endpoint/                    one-use effect and exact-result provider
  storage/linux-openat2/       declared hosted storage profile

effects/
  generation-journal/          first harmless bounded effect

lab/
  authority-relation/
  crash/logical-profile/
  trace/dmlog-intake/
  trace/subject-packet/
  trace/capture-ceremony/
  trace/native-replay/
  crash/power-loss/
  path/
  fixtures/

proof/
  formal/
  checkers/

vault/
  imports/
  blobs/
  snapshot-manifests/

releases/
  candidates/
  sealed/

office/
  constitution/
  decisions/
  incidents/
  gates.tsv
  obligations.tsv
  claims.tsv
  state.json
```

## Dependency law

`core/` may consume typed appraisals and protected capabilities. It must not
parse raw TPM objects, block traces, trace-subject packets, crash images, vault
capsules, compiler logs or release manifests.

Acquisition providers emit neutral evidence. The provider appraiser may promote
an exact packet to a capture-bound result, but neither component selects retry,
compensation, publication or effect routing.

Synthetic fixtures and native evidence use distinct types and storage roots.
No fixture constructor can produce a native or capture-bound type.
