# Proposed repository v6

```text
core/
  state/                    minimal deterministic authority machine
  effect-gate/              one bounded permit-consumption interface
protocol/
  operation/ evidence/ appraisal/ approval/
  endpoint-result/ publication/ trace-subject/
policy/
  relying-party/            separately governed authorization/retry policy
providers/
  acquisition/tpm/          neutral attestation producer
  acquisition/block-trace/  privileged capture and export closure
  approval/                  constituted local approval mint
  floor/                     protected compare/advance provider
  endpoint/                  protected one-use effect and result provider
  storage/linux-openat2/     declared hosted path profile
effects/
  generation-journal/       first fixed harmless effect
lab/
  authority-relation/       finite state exploration
  crash/logical-profile/    rev0880 logical image oracle
  trace/dmlog-intake/        rev0881 strict synthetic intake
  trace/native-replay/       future machine-bound capture/replay
  crash/power-loss/         future destructive experiments
  path/ fixtures/
proof/
  formal/ checkers/
vault/
  imports/ blobs/
releases/
  candidates/ sealed/
office/
  constitution/ decisions/ incidents/
  gates.tsv obligations.tsv claims.tsv state.json
```

## Dependency law

`core/` accepts typed appraisals and protected capabilities. It never parses raw
TPM objects, filesystem traces, crash images, vault capsules, compiler logs or
release manifests. Acquisition providers emit neutral evidence. They do not
select policy, retry, compensation, effect route, or publication.

## Trace law

Native acquisition and strict intake are separate packages and separate types.
A structurally valid byte stream cannot inhabit a `CaptureBoundTrace` type
without an exact subject-closure packet and export-close receipt. Test fixtures
have a conspicuous synthetic type barrier.

## Digest law

Every digest field names algorithm, encoding, canonicalization and domain.
Noncryptographic diagnostic hashes never satisfy vault or release custody.

## History law

Constitutional decisions and incidents constrain typed office state. Narrative
status files are generated or drift-checked projections. Intermediate work may
use digest-addressed blobs and sparse path/mode/digest manifests; immutable full
capsules remain at deliberate authority gates. Storage deduplication never
changes lineage or authority.
