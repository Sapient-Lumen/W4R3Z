# Result trilemma

A post-dispatch authority machine needs at least three terminal appraisals:

```text
EFFECT       exact evidence locates the selected effect
NO_EFFECT    exact evidence locates nonexecution
UNCERTAIN    available evidence cannot locate the effect
```

`NO_EFFECT` is not a default or timeout branch. It is a positive claim that may
release a reservation, permit compensation, or influence a future owner policy.
It therefore needs evidence at least as exact as `EFFECT`.

## Rev0896 refinement

The hosted settlement seam makes the following interpretation executable:

```text
no reply                         -> UNCERTAIN
provider unavailable             -> UNCERTAIN
malformed response               -> UNCERTAIN
foreign operation identity       -> UNCERTAIN
exact bound EFFECT record        -> EFFECT
exact bound NO_EFFECT record     -> NO_EFFECT
exact bound UNCERTAIN record     -> UNCERTAIN
exact linearized UNUSED query    -> NO_EFFECT, under provider premise only
```

A malformed return can follow a committed effect, so parse failure cannot mean
no-effect. A query that says unused is meaningful only when it is exact,
linearized over the same protected provider history, retained for the full
governed lifetime, and resistant to clone/restore/replacement. Rev0896 exercises
that contract in a fake provider and explicitly does not establish those
premises for a real provider.

## Appraisal is not authority

The trilemma separates:

1. what effect actually occurred;
2. what exact evidence survived and is bound to this operation;
3. which provider history produced that evidence; and
4. what authority an owner policy may grant from the appraisal.

A verifier or recovery worker may emit an uncertainty observation. It may not
hide uncertainty by retrying, manufacturing absence evidence, or promoting a
copyable result to a capability. In V8 every settlement observation is
query-only and carries neither response nor retry authority.
