# Exact etcd v3.6.14 operated-profile gate

## Decision

The next provider-history experiment is not “use etcd.” It is one exact,
reconstructable profile whose premises are either retained or absent. Rev0899 retains the exact release and transaction-shape gate and corrects the
passive byte-ingress implementation. The exact archive still could not be
acquired in the construction host, so no positive admission or operation is
claimed.

## Admission ladder

Each rung is distinct and fail-closed:

```text
A. upstream release metadata and checksum product retained
B. exact archive bytes admitted by digest and safe inventory
C. exact binary/version identities retained
D. owner and appraiser roots provisioned outside provider data
E. fixed client/peer trust, members, bootstrap and administration inventory
F. fixed authenticated cluster operated
G. fixed four-compare/three-write transaction attempted once
H. fixed four-key linearizable query retained after every outcome
I. failure/restore/clone/currentness attacks retained
J. independent appraiser reopens the dossier without candidate roots
```

Rev0899 reaches A, constructs a descriptor-pinned passive gate for B, and
retains only a negative actual B result because the archive is absent. It does
not reach B through J.

## Why absence is an evidence result

Substituting the installed Go toolchain, an older etcd package, a locally rebuilt
binary, an unpinned container image, or synthetic server would erase the exact
release premise while producing a visually plausible “experiment.” That would
be worse than no experiment. `RELEASE_ARCHIVE_MISSING` and
`RUNTIME_UNAVAILABLE` are therefore successful fail-closed outcomes, not failed
attempts to hide.

## Fixed transaction shape

The experiment may compare only:

```text
head == predecessor
floor == exact floor identity
version(spend/<operation>) == 0
version(entry/<operation>) == 0
```

and on success write only:

```text
head := successor
spend/<operation> := exact spend record
entry/<operation> := exact pending entry
```

Failure and recovery query the same four keys linearly. No automatic retry or
first dispatch may occur during recovery.

## Administration is inside the theorem

The retained profile must bind—not merely document—every principal capable of:

```text
issuing client or peer certificates
changing authentication or root roles
adding/removing/promoting members
writing the SlopOS prefix through another credential
snapshotting, copying, restoring or migrating data
changing startup flags, data directories or release bytes
rolling back, cloning, replacing or retiring the cluster
changing the external currentness witness
```

A least-privilege application credential does not close these authorities.

## Restore rule

Official etcd recovery semantics make restore a new logical cluster with new
cluster/member identities. Therefore a restored provider is foreign by default.
It may become a successor only through an owner-governed continuity ceremony
that also proves no newer history survives elsewhere. Revision bumping can
protect watch consumers from revision regression; it cannot constitute that
ceremony.

## Acceptance rule

A later cut is accepted only when retained evidence demonstrates all of:

```text
exact admitted release bytes
actual authenticated operated cluster
complete fixed profile and administration inventory
one attempted fixed transaction with honest outcome uncertainty
linearizable query after delivered, failed and lost replies
leader-loss and stale-read negative controls
snapshot/restore and coherent-clone countermodels
external nonrollback currentness witness
independently provisioned appraisal and reopen
```

Until then `operated_etcd_profile=false`, `provider_commit_proved=false`, and
Epoch Zero remains truthful.
