# Trace-subject packet and ceremony design

## Separation of concerns

```text
untrusted proposal         declares the expected subject
privileged provider        performs and observes one ceremony
packet builder             canonically binds exact bytes
strict intake              validates and deterministically replays
provider appraiser         verifies external capture-binding facts
relying-party policy       decides whether evidence is acceptable
protected effect gate      consumes a distinct one-use capability
```

The packet builder and intake component never receive effect-routing authority.
The provider cannot choose relying-party policy. The relying party cannot
retroactively alter the captured subject.

## Type ladder

```text
TraceSubjectProposal
TraceSubjectWitness
TraceSubjectReceipt
SyntheticPacket
StructurallyValidPacket
DeterministicallyReplayedPacket
ExportClosedCandidate
CaptureBoundEvidence
AppraisedEvidenceResult
EffectAuthorization
```

There is no constructor from an untrusted packet field to
`CaptureBoundEvidence`. There is no constructor from any evidence rung directly
to `EffectAuthorization`.

## Trust-context rule

External trust facts are not serialized into the packet as authoritative
booleans. They are obtained by a provider appraiser through separately rooted
channels and supplied as a validation context. The exact context schema,
provenance and independent operation remain open work.

## Failure discipline

Every mismatch is terminal for that packet. Uncertain target removal, restart
during an active run, writer-set violation or lost run identity produces
`INCOMPLETE` or `FAILED`, not a resumable success path. Publication may preserve
bytes but cannot resurrect the run identity or increase the evidence rung.
