# Process lifetime and executable epoch

A process lifetime and an executable epoch are independent coordinates.

```text
clone3 + pidfd        -> names one process lifetime
execveat(empty path)  -> selects one initial executable object
/proc/<pid>/exe join  -> observes one executable at one time
later exec            -> creates a new executable epoch inside the same lifetime
waitid(P_PIDFD)       -> consumes terminal state for the same lifetime
```

The rev0883 wedge closes only the initial launch observation. It does not install
an exec monitor, deny later exec, bind the ELF interpreter and shared objects,
close mutable executable mappings, or authenticate the observer. Any future
provider result must name these limits explicitly.

The provider should emit neutral evidence. A separate appraiser applies provider
roots and subject policy. A separately governed relying party decides whether an
appraised result can contribute to one bounded effect. No process transcript may
skip those layers.
