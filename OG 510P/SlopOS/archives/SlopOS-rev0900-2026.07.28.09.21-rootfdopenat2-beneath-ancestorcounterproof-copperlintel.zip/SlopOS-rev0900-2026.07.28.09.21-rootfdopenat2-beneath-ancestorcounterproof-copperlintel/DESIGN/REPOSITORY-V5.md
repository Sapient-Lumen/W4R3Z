# Proposed repository v5

```text
core/
  state/                  minimal deterministic authority machine
  types/                  canonical operation, appraisal and terminal types
  effect-gate/            one bounded permit-consumption interface
protocol/
  operation/
  evidence/
  appraisal/
  approval/
  endpoint-result/
  publication/
policy/
  relying-party/          separately governed authorization and retry policy
providers/
  acquisition/tpm/        neutral attestation evidence producer
  approval/               owner/user approval mint
  floor/                  protected compare/advance anti-rollback provider
  endpoint/               protected one-use effect and exact-result provider
  storage/linux-openat2/  declared hosted path profile
lab/
  authority-relation/     finite state exploration
  crash/logical-profile/  rev0880 image grammar and oracle
  crash/block-trace/      privileged trace acquisition and replay
  crash/power-loss/       destructive machine-bound experiments
  path/                   namespace and path adversaries
  fixtures/               conspicuous nonauthoritative test doubles
proof/
  formal/                 theorem sources and replay records
  checkers/               source-separated evidence consumers
vault/
  imports/                immutable imported premises and source custody
  blobs/                  digest-addressed duplicate content
releases/
  candidates/             sparse vertical claims
  sealed/                 independently reconstructed governed releases
office/
  constitution/
  decisions/
  incidents/
  gates.tsv
  obligations.tsv
  claims.tsv
  state.json
```

## Dependency rule

`core/` consumes typed appraisals and protected capabilities. It must not parse
TPM objects, filesystem traces, raw crash images, vault capsules, compiler logs,
or release manifests. Evidence providers do not select policy or effects.
Laboratory fixtures never satisfy production provider interfaces without an
explicit test-only type barrier.

## History rule

Intermediate checkpoints should bind path, mode, size and digest through sparse
manifests over content-addressed blobs. Complete immutable capsules remain at
deliberate authority gates. Deduplication changes storage representation, not
lineage or authority.
