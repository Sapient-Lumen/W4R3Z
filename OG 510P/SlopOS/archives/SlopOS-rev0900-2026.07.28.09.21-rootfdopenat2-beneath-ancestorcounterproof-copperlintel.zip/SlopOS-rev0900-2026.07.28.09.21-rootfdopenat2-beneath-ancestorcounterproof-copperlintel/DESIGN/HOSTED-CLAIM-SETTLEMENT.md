# Hosted claim settlement — one attempt, query-only recovery

## Purpose

Rev0896 connects two already-established hosted laws without pretending to
close their custody gap:

```text
V7 local claim before proposer meaning
+
generation-journal effect / no-effect / uncertain result identity
=
V8 client settlement seam
```

The seam exists to prevent two common failures:

1. retrying after reply loss because “no response” was flattened to no-effect;
2. allowing a recovery process to mint the first submission because it can see
   a claimed record but not the original local witness.

## API cut

`HostedSettlement::settle_exact` accepts the move-only V7 `ClaimedPending` as an
rvalue. It burns that object through the same parser gate before request length
or fields are inspected. An exact request causes one call to the supplied
`HostedSettlementProvider::submit_exact`. There is no loop and no query branch
in this entry.

`HostedSettlement::reconcile_exact` accepts only the canonical pending record.
It can issue one exact provider query and has no path to `submit_exact`.

The split is architectural:

```text
submission eligibility is noncopyable and local
settlement evidence is copyable and powerless
```

A `SettlementObservation` can report `EFFECT`, `NO_EFFECT`, `UNCERTAIN`,
`FAIL_STOP`, malformed request, or missing/spent claim. It cannot invoke,
resubmit, retry, compensate, publish, restore, or mint another claim.

## Honest interpretation table

| provider observation | immediate/reopen interpretation | may submit later? |
|---|---|---|
| exact bound EFFECT | EFFECT | no |
| exact bound NO_EFFECT | NO_EFFECT | no |
| exact bound UNCERTAIN | UNCERTAIN | no |
| exact bound FAIL_STOP | FAIL_STOP | no |
| no return | UNCERTAIN | no |
| unavailable | UNCERTAIN | no |
| malformed response | UNCERTAIN | no |
| foreign result identity | UNCERTAIN | no |
| exact linearized unused query | NO_EFFECT under provider premise | no |

The last row is easy to misuse. “Unused” is meaningful only when query is exact
for the same operation identity, linearized over the same protected provider
history, and durable across the governed lifetime. Rev0896 exercises that
contract in a fake provider; it does not prove a real provider supplies it.

## What the shared-provider race shows

Sixteen independent coherent local namespace histories can each produce one
fresh V7 claim. When all sixteen call one shared scripted provider, that
provider records one fresh commit, fifteen duplicates, and one effect. This is
the shape the authentic provider must preserve.

It is not a proof that local claims compose into global one-use. Replacing the
shared provider with two coherent provider clones immediately produces two
effects. Clearing the provider's remembered terminal record produces another
effect. Thus global one-use lives in provider identity and retained history,
not in the client call graph.

## Crash semantics

A killed submitter leaves the local endpoint record claimed. Reopen cannot
recover `ClaimedPending`; it can only query. The retained cuts distinguish:

```text
claim happened, submit did not        -> exact unused / no-effect
provider committed effect             -> exact effect
provider committed no-effect          -> exact no-effect
provider committed uncertain          -> exact uncertain
```

No response bytes are promoted to authority. No crash branch retries.

## Why this remains hosted

The cloudtainer chooses the provider object and can create another one, restore
an earlier one, erase its retained identity, or return arbitrary bytes. V8 also
does not bind a provider to a constituted owner, resource identifier, account,
region, consensus group, backup lineage, or release binary. Its exact result
record binds the operation fields, not the identity of the history that emitted
it.

Therefore:

```text
hosted_settlement_adapter_implemented = true
protected_settlement                  = false
protected_effect                      = false
provider_identity_proved              = false
provider_rollback_floor               = false
response_authority                    = false
retry_authority                       = false
```

## Authentic replacement criterion

A real replacement must preserve the V8 source-level laws and additionally
name and prove:

- constituted owner genesis and admission threshold;
- exact provider resource/index and incarnation identity;
- writer executable, service, machine, and administrator set;
- compare/submit/query linearization relation;
- full-lifetime consumed-identity retention;
- snapshot, backup, restore, migration, replica, and failover semantics;
- stable-media and physical-failure classification;
- independently rooted query/appraisal path;
- compromise, retirement, rotation, and successor ceremony; and
- binding from exact provider result to one owner-authorized bounded effect.

Until then, the hosted interface is a falsifiable specification and harness
fixture, not an operational provider abstraction.
