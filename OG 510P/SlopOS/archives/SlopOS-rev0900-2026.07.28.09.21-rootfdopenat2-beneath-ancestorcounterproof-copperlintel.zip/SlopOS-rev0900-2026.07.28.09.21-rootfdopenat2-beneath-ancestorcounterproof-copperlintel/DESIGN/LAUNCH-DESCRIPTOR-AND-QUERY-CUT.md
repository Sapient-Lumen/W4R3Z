# Launch descriptor and query cut

**Status:** rev0889 hosted Epoch-Zero construction. This document specifies a
bounded Linux experiment, not a provider, product, portability contract, or
authority grant.

## Defect under test

Rev0888 established a scoped DAC relation only after a process was already
running under a disposable provider UID. It did not show how that actor entered
its principal with an exact authority inventory, nor how a different actor
could query a fixed immutable result without receiving repair or dispatch
power.

Two tempting substitutions are wrong:

```text
all unwanted fds are probably CLOEXEC       != exact post-exec descriptor table
SO_PEERCRED says who sent this packet now    != creation-time peer coordinate
```

A third mistake is worse: treating ancillary data as ignorable metadata even
though `SCM_RIGHTS` can install live open-file-description authority before the
request payload is interpreted.

## Actor constitution used by the hosted campaign

A root-equivalent laboratory launcher performs only the experiment's host-side
constitution. It opens `/proc/self/exe` with `O_PATH`, duplicates fixed
resources into declared slots, closes the ambient suffix with an unshared
`close_range`, narrows groups and credentials, sets `no_new_privs`, and enters
the executable object with `execveat(..., AT_EMPTY_PATH)`.

Observed provider table after `exec`:

```text
0 stdin
1 stdout
2 stderr
4 provider-root directory, read/search use in the bounded query object
5 query SOCK_SEQPACKET endpoint
6 report endpoint
```

Observed query table after `exec`:

```text
0 stdin
1 stdout
2 stderr
5 query SOCK_SEQPACKET endpoint
6 report endpoint
```

Fd 3 carries the executable object before `exec` and is close-on-exec. The
intended ambient closure begins at fd 7. A negative-control launcher begins at
fd 8 and demonstrates that fd 7 survives. Exactness is therefore a constructed
cut with a retained off-by-one defeat, not a claim that CLOEXEC hygiene was
adequate.

The launcher remains a dominant premise. It can choose roots, UIDs, code,
channel endpoints, and process lifecycle. This construction says nothing about
owner constitution or protection from root-equivalent administration.

## Credential relation

Let `C_create(s)` be credentials fixed when Unix-domain socket `s` is created or
connected, and `C_msg(m)` be credentials attached to delivered message `m`.
The campaign demonstrates:

```text
C_create(socketpair) = root launcher
C_msg(valid query)   = query uid 21003
C_msg(wrong query)   = wrong uid 21002
```

Therefore:

```text
C_create(s) does not refine C_msg(m) after a credential transition.
```

The provider enables `SO_PASSCRED`, requires exactly one `SCM_CREDENTIALS`
record, and compares the message UID with the one fixed expected query UID.
Missing, duplicate, malformed, truncated, or unexpected control data fails
closed.

This authenticates only the ordinary-host relation exercised in the campaign.
A sufficiently privileged process may forge credential fields or replace the
channel. The provider itself is not authenticated by the query actor. The
administration plane remains open.

## Authority-first receive order

For every received packet, define `R(m)` as the set of file descriptions
installed from ancillary rights and `P(m)` as the payload parse event. The
required safety order is:

```text
receive(m)
  -> enumerate all control
  -> close every member of R(m)
  -> reject if R(m) was nonempty or control was incomplete/unexpected
  -> validate exactly one C_msg(m)
  -> P(m)
```

The forbidden order is `P(m) -> inspect R(m)`. Payload validity cannot
launder an authority-bearing packet. Rev0889 retains an injected-rights case
and checks that payload parsing did not occur and the provider descriptor table
returned to its exact baseline.

## Fixed query object

`FixedResultQuery` accepts only:

```text
provider_root_fd
expected_provider_uid
```

It validates the provider-root and fixed `cell`, opens fixed `pending` and
`result.2` leaves read-only with no symlink following, requires regular
single-link provider-owned 128-byte records with no write bits, performs
canonical decoding, and requires:

```text
pending:  kind=PENDING, sequence=1, result=NONE
result.2: kind=RESULT, sequence=2, exact terminal result
operation fields(pending) = operation fields(result.2)
```

There is no path input, route, version selector, apply, dispatch, retry,
cleanup, unlink, replacement, repair, or recovery mutation. A timeout means
query failure only; it does not prove no effect and grants no resend.

## Finite refinement proof

The independent oracle checks three small relations in addition to canonical
bytes.

### Descriptor relation

```text
D_provider = {0,1,2,4,5,6}
D_query    = {0,1,2,5,6}
D_bad      = D_query union {7}
```

The admitted tables equal the first two sets. `D_bad` is retained and rejected.

### Credential-coordinate relation

```text
peer credential coordinate    = creator/root
valid message coordinate      = query uid 21003
wrong message coordinate      = query uid 21002
```

The oracle refuses any rule that substitutes the peer coordinate for the
message coordinate.

### Receive-order relation

```text
no rights -> credential -> payload parse may proceed
rights    -> close rights -> reject; payload parse count remains zero
```

This is a shape proof over retained observations. It does not prove the Linux
kernel implementation or an external deployment.

## What was observed

The campaign retains fifteen launch/query cases and three launch/query
counterexamples across Clang, GCC, and Clang ASan/UBSan reconstruction lanes.
Canonical products are required to be byte-identical and are checked by a
separate Python oracle. The construction also preserves the prior handoff,
principal, publication, and six earlier counterexamples.

## Nonclaims

Not proved: provider or owner identity, administration closure, privileged
credential-forgery resistance, independent channel creation, mount/snapshot
custody, endpoint operation, source-to-binary identity, dynamic-loader closure,
post-entry executable integrity, stable media, physical power-loss survival,
external rollback floor, independent evidence custody, protected admission,
protected effect, protected result, governed release, or authority.

## Next admissible refinement

Move constitution outside the root-created socketpair. An owner-named external
provider must enter its final principal, bind its own fixed endpoint, and expose
a connection to a separately provisioned query actor. The attack matrix must
include administrator substitution, forged credentials, channel replacement,
descriptor injection, endpoint replacement, restart, rollback, destructive
media cuts, and independent reopen. No new hosted family is justified first.

## Rev0890 successor correction

The former next step—bind the public endpoint after provider credential
transition—was necessary but insufficient. A same-UID restart can replace a
pathname whenever the provider principal controls its parent directory.
Rev0890 therefore retains this document as the V3 launch/query seam and moves
the current endpoint design to
`PROVIDER-BIND-AND-ENDPOINT-PUBLICATION.md`.

The V4 construction removes the inherited query data socket, binds a fixed
listener inside the final provider principal, separates public-name mutation
into a no-replace publisher, and connects the query actor afterward. It also
retains stale collision and publisher replacement instead of calling either
restart success. Exact descriptor tables and authority-first ancillary handling
remain unchanged.
