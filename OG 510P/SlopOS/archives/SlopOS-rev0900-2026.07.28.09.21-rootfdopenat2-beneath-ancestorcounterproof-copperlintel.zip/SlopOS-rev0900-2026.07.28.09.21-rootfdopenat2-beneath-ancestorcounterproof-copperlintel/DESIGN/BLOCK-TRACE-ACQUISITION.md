# Privileged block-trace acquisition contract

## Purpose

Acquire one exact native trace for the harmless journal/effect workload, close
its export subject, replay eligible prefixes into fresh baseline copies, and
feed those images to independent reopeners. This is an evidence provider, not an
authorization policy or protected result service.

## Subject binding

The retained packet must satisfy `CANDIDATE/spec/TRACE-SUBJECT-CLOSURE.md`,
including exact kernel/build/boot, block graph, devices, queue/cache/FUA/flush
declarations, filesystem/mount namespace, complete writer set, workload,
baseline, target table lifetime, mark calls and returns, close/removal results,
export range, native tool identities, replay mapping and reopener identities.

## Acquisition sequence

1. Authorize one fresh disposable machine/run under a constituted operator role.
2. Create distinct baseline/target/log devices under a private namespace.
3. Establish and verify the exclusive writer set.
4. Create the exact `dm-log-writes` target and retain its table/status.
5. Format/mount the exact filesystem subject.
6. Execute the exact bounded workload; record mark requests and returns only as
   logging-plane observations.
7. Unmount, close and remove the target; retain every return and failure.
8. Export a declared exact byte range and prove the export is closed.
9. Validate through strict intake; replay eligible prefixes from fresh baseline
   copies under a frozen native-to-normalized mapping.
10. Reopen with two separately operated implementations and retain divergences.

## Nonclaims

A mark is not a target flush. `dm-log-writes-end` is not a target flush. A valid
log is not authentic acquisition. A replayed prefix is not electrical power
loss. A successful filesystem check is not a SlopOS terminal result. This
rev0882 cloudtainer lacks the privilege and devices required to run the lane.
