# Next vertical construction

## Immediate theorem to seek

Admit one exact descriptor-ingress capability without performing a weaker local
open. Either revalidate final Linux `OPENAT2_REGULAR` on the target host and use
V12, or receive an already-open candidate descriptor from a separately governed
acquisition actor and reject nonregular shape before any read.

Then produce one positive passive receipt for the exact
`etcd-v3.6.14-linux-amd64.tar.gz` without extracting or executing any member:

```text
admitted acquisition channel and descriptor-custody statement
-> admitted regular-only V12 result OR governed pre-opened candidate fd
-> V11 complete capture and write-seal barrier
-> exact sealed-byte SHA-256 comparison
-> passive archive inventory and exact required-member hashes
-> immutable receipt: admitted=true, extraction=false, execution=false
```

The receipt must distinguish source channel, open-time responsibility,
descriptor premise, rooted observations when present, sealed snapshot identity,
expected and observed digests, archive semantics, and every authority nonclaim.
Root endpoint equality remains samples, not continuity.

## Following theorem

After the passive receipt exists, construct a separate descriptor-bound
activation-only gate with fixed executable identity, closed descriptor table,
fixed credentials/environment, no network, no provider data, and an explicit
negative control proving a passive receipt cannot trigger it.

## Stop rule

No admitted descriptor ingress means no archive read. No positive passive
receipt means no activation. No activation means no cluster operation. No
constituted owner/appraiser roots, complete administration inventory, restore
succession, and external currentness means no provider or epoch promotion.
Missing premises are evidence, not an invitation to simulate them.
