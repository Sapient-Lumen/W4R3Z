# Detached predecessor transport

## Waste corrected

Rev0886 unpacked to roughly 128 MB. Its embedded rev0885 predecessor ZIP alone
was 107,302,744 bytes—more than four times the rest of the working datacube and
the dominant share of every new close. Embedding the next exact predecessor
would have copied all of that recursive ancestry again.

Rev0887 stopped the recurrence by detaching rev0886. Rev0888 continues the
rule: `PREDECESSOR/RECEIPT.json` records exact rev0887 filename, byte count,
manifest-file count, SHA-256 digest, and revision label. The predecessor archive
itself is absent.

## Resume contract

Basic resume is self-contained:

```text
python3 -B TOOLS/resume.py basic
```

It validates the current manifest, office, candidates, evidence, excavation,
receipt, and nonclaims without fetching or opening ancestry.

Deep lineage is optional and explicit:

```text
python3 -B TOOLS/open_lineage.py \
  --predecessor /path/to/exact-rev0887.zip \
  --workspace ABSENT-OUTSIDE-DIR
```

The tool rejects a missing, wrong-sized, or wrong-digest archive before
extraction, then verifies rev0887's own checkpoint and its linked rev0886/sealed rev0874
projections. Full older bytes remain separate explicit inputs rather than hidden
recursive transport. No network fetch, archive search, or pathname guess is performed by the
checkpoint.

## What the receipt does not prove

The receipt proves exact identity only after bytes are supplied. It does not
prove that a copy will remain available, that a remote store is honest, that a
download came from an owner, or that the predecessor was ratified as living
law. Availability and retention must be governed separately.

For that reason, thin transport is a local waste correction, not a complete
lineage-storage system. O45 remains open for retention horizon, replication,
loss procedure, and content-addressed acquisition. The office should prefer an
owner-governed content-addressed store over recursive archive nesting when such
a store is constituted.

## Close rule

A linked checkpoint must fail closure if `PREDECESSOR/` contains a ZIP or any
file other than the receipt and its explanatory README. The receipt is small,
manifested, and checked against `CHECKPOINT.json`. Basic reopen must never
silently require external predecessor bytes.
