# Authority-spine proof plan

The central proof target is not “the software usually behaves.” It is that no
actor can obtain or recreate effect authority except through one exact governed
join, and that every cut after entry has a conservative, exact result meaning.
The proof must connect source, machine mechanisms, durable state, and operator
constitution; a finite model alone cannot close the theorem.

## Safety invariants

**P1 — evidence nonpromotion.** Acquisition evidence cannot authorize, choose a
route, or mint a permit. Appraisal and relying decision remain separate typed
steps over one exact subject.

**P2 — complete allow join.** A live permit exists only after exact agreement of
operation identity, evidence subject, appraisal subject, decision subject,
policy version, owner scope, endpoint, and rollback floor.

**P3 — consume before inspect.** On every presented gate entry, the capability is
irreversibly consumed before parsing, subject comparison, alias resolution,
route checking, or endpoint invocation. Any failure after presentation leaves no
retry authority.

**P4 — one fixed effect.** A permit can address one system-selected endpoint and
at most one generation transition. Proposer-controlled route or replacement is
impossible at the capability level, not merely rejected by a string comparison.

**P5 — recovery no-mint.** Startup, replay, reconciliation, timeout, and operator
recovery cannot create first-dispatch authority. After an uncertain cut they can
only observe and narrow the exact pending operation.

**P6 — uncertainty monotonicity.** Missing, malformed, unauthenticated, or
nonreturning observations never become `NO_EFFECT`. Only an authenticated exact
reconciliation for the bound operation may narrow `UNCERTAIN`.

**P7 — result precedence.** Once `EFFECT`, `NO_EFFECT`, `UNCERTAIN`, or
`FAIL_STOP` is durably retained, publication reproduces that result and cannot
re-run policy or the effect.

**P7a — denial response boundary.** A relying-party deny creates no permit and
no effect. Its response is separately published and must never be represented as
endpoint `NO_EFFECT`.

**P7b — result revision boundary.** The result service must state whether an
authenticated reconciliation can supersede an already-published `UNCERTAIN`, and
if so bind every publication to a monotonic result version. Rev0885 core-gate v1
closes on publication and does not discharge this interface.

**P8 — external newestness.** A restorable image cannot prove it is the newest
image. Stable dispatch is blocked unless a separately protected rollback floor
and the selected local generation agree exactly.

**P9 — exclusive writer premise.** Result and floor claims require a proved
writer topology. A process transcript, PID, path, or packet assertion is not
exclusive-writer custody.

**P10 — bounded resources.** Every attacker-controlled length, count, depth, and
work factor is bounded before allocation or iteration; exhaustion is typed
rejection or incompleteness, never authorization.

## What rev0885 discharges

The C++20 core gate exhaustively checks a finite abstraction of P1–P7 and the
inert half of P7a. Its 45
reachable states, 26 events per state, and 1,170 saturated edges agree between a
candidate, a separately written C++ reference, and a Python reconstruction.
Witnesses show six invalid entry classes consume the permit and that recovery
mints zero permits. Clang/GCC canonical products are byte-identical and the same
campaign passes ASan/UBSan.

This is meaningful proofwork because it consolidates the gate law into one
small relation. It does not discharge the mechanism premises. Booleans are not
nonforgeable capabilities, enum subjects are not authenticated identities, and
an in-memory counter is not a durable generation journal.

## Required mechanism lemmas

| Lemma | Required evidence |
|---|---|
| capability unforgeability and linear consumption | kernel/hypervisor capability construction, adversarial duplication tests, and code proof at the entry cut |
| fixed endpoint binding | capability target identity plus alias/replacement closure |
| authentic evidence acquisition | externally provisioned provider root, machine enrollment, freshness, and bounded canonical statement |
| separate appraisal | independently provisioned appraiser root and reproducible policy interpretation |
| durable exact result | crash-safe journal protocol, write/readback ordering, destructive power cuts, and authenticated reconciliation |
| external rollback floor | nonrestorable monotonic service or device primitive with failure-closed availability semantics |
| exclusive writer custody | boot-to-shutdown topology and negative hidden-writer campaign |
| independent reconstitution | separate actor, implementation, roots, machine, and retained-input rebuild |

## Refinement chain

The intended refinement is:

```text
finite gate relation
  <= typed protocol implementation
  <= capability entry mechanism
  <= generation-journal endpoint and result service
  <= named-machine provider/appraiser deployment
  <= destructive recovery campaign
  <= independently reconstructed governed release
```

Each `<=` is an explicit simulation/refinement obligation. A test pass at a lower
line cannot be narrated as a theorem about a higher one. Counterexamples and
unknowns stay retained until the relevant mechanism closes them.

## Small next construction

Implement the generation-journal endpoint behind an interface that has no permit
minting operation. It receives only an already-consumed dispatch record, writes
one pending generation, performs post-write readback, invokes the harmless fixed
effect once, and durably records one terminal result. Recovery accepts an exact
pending identifier and returns reconciliation only. This can be tested in the
cloudtainer with simulated cuts, but authority claims wait for a named machine,
protected capability, external floor, and destructive power campaign.
