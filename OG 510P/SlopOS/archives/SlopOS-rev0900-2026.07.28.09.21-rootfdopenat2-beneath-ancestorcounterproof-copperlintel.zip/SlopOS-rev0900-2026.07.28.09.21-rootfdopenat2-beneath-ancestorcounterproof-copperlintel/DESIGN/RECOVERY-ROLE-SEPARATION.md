# Recovery role separation — storage repair is not protocol reconciliation

## Correction

“Recovery is query-only” is a protocol law, not a claim that every layer beneath
that query can reopen without mutation. Rev0887 found a concrete case where
those meanings diverge: an interrupted SQLite rollback-journal transaction can
leave a hot journal. SQLite must obtain write authority, restore pages, flush,
and retire the journal before the database is sane for ordinary reads. A
read-only opener can instead fail with `SQLITE_READONLY_ROLLBACK`.

Therefore a strictly read-only protocol reconciler must not be described as the
principal that performs storage-engine recovery. Doing so hides write authority
inside a supposedly query-only surface.

## Required roles

A future result cell needs at least four separately named roles:

1. **Storage custodian.** Owns the filesystem/database recovery procedure and
   may perform only the writes required by the declared storage engine and
   threat model. It cannot mint an operation, route, endpoint, retry, or result.
2. **Protocol reconciler.** Receives one exact spent operation identity and an
   authenticated query capability. It may read/query and append a later result
   version; it cannot invoke or re-invoke the effect.
3. **Provider.** Owns the fixed effect endpoint and authentic result source. Its
   API must expose completion lookup keyed by the exact operation identity.
4. **Appraiser.** Independently verifies identity, floor, provider response,
   result version, and non-retry behavior. It does not share the provider root.

A valid restart sequence is therefore:

```text
exclusive storage custody
  -> engine-specific repair/replay
  -> structural and version verification
  -> relinquish mutation authority or enter declared append-only result mode
  -> protocol query/reconciliation
  -> independent appraisal
```

The storage custodian may mutate the substrate, but that fact must be visible in
the threat model, audit trail, and failure cuts. The protocol reconciler remains
query-only with respect to the governed effect.

## SQLite lesson, not SQLite endorsement

Official SQLite documentation describes hot-journal detection, exclusive
locking, rollback writes, journal retirement, and the read-only rollback error.
It also distinguishes synchronous modes; in rollback mode, `EXTRA` adds a
directory sync after journal unlink, while `FULL` alone is not necessarily a
power-loss durability claim on every filesystem.

This makes SQLite useful for exposing the role boundary. It does not make a
SQLite file a protected spent receipt. A deployment would still need named
filesystem and device semantics, exclusive writer custody, authenticated
provider state, external rollback protection, destructive cuts, and independent
reopen. Rev0887 retains the architectural finding but does not retain an SQLite
implementation as current source.

## Design rule

Every future “query-only recovery” claim must answer two questions separately:

- Who is allowed to repair or replay the storage engine, and exactly what may
  that role write?
- After storage is sane, what protocol operation is the reconciler allowed to
  perform?

If either answer is implicit, the vertical fails stop. A storage library must
not smuggle effect authority into repair, and a protocol API must not pretend
that refusing effect retry removes the need for substrate recovery.
