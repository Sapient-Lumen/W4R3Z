# Repository V19 — three islands, endpoint claim refinement

## Decision

Repository V19 retains exactly three hosted semantic islands:

```text
CANDIDATE/core_gate
CANDIDATE/generation_journal
CANDIDATE/handoff_cell
```

Rev0895 extends only `handoff_cell`. No product target and no fourth semantic
island is added.

## Current island responsibilities

`core_gate` owns the abstract burn-before-validation and bounded-effect
relation. `generation_journal` owns exact pending/result identity, immutable
refinement, content-bound compare-and-append, and the hosted floor/entry join.
`handoff_cell` owns fixed namespace admission, scoped principal experiments,
launch descriptor topology, fixed result query, endpoint publication,
process/message identity observations, sealed expected-process consumption, and
now fixed endpoint claim before payload meaning.

The handoff island now contains **35 package files**. The new endpoint-claim files are package-local:

```text
include/slopos/e0/handoff_cell/endpoint_claim.hpp
src/endpoint_claim.cpp
harness/endpoint_claim_campaign.hpp
harness/endpoint_claim_campaign.cpp
proof/verify_endpoint_claim.py
spec/HANDOFF-CELL-V7.md
```

The handoff package continues to reuse exactly three generation-journal codec
sources. This is an explicit source dependency, not a service boundary.

## Anti-islands

The repository still contains no:

```text
spend daemon
token service
claim service
endpoint registry
process registry
generic admission service
generic database layer
launcher service
query service
publisher service
cleanup or retry daemon
policy language
product executable
```

The endpoint claim is a narrow hosted proof adapter. It neither listens on a
new endpoint nor exports a generic API. It performs no effect and no settlement.

## Delete-or-replace rule

The hosted `EndpointClaimCell` is replaceable proof scaffolding. An authentic owner-admitted provider successor must subsume its fixed ordering and add owner genesis,
protected writer/provider custody, nonrollback claim state, stable-media and
failure classification, exact effect settlement, compromise/retirement, and an
independently provisioned appraisal path. When that relation exists, the hosted
filesystem adapter should remain only as a counterexample harness or be
removed; it must not become an operational database/path service.

## Dependency boundary

Build inputs are limited to the three candidate packages and declared host
libraries/toolchain. Evidence, excavation, office, research, review, and
predecessor material remain non-build inputs. The old vault is cross-indexed by
path, size, and digest and is never copied into candidate source.

## Current nonclaims

Repository shape does not establish architecture admission. V19 remains hosted,
unsealed, nonauthoritative, source-to-binary incomplete, and outside the living
project. **Remain in Epoch Zero.** It does not prove a protected pending claim, global spend, stable
endpoint epoch, durable settlement, or independent reopen.
