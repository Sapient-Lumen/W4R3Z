# Crash-image construction status and next edge

Rev0880 completes the **bounded logical oracle** selected by rev0879. It does
not complete the storage gate.

Completed logical layer:

- fixed six-block schema;
- explicit `WRITE`, `FLUSH`, and observer-only `MARK` grammar;
- bounded survival-subset enumeration;
- two C++ reopeners plus source-separated Python reconstruction;
- exact four-way terminal classification;
- retained minimal counterexamples.

The next storage edge is a **privileged block-trace acquisition lane** on a
named disposable subject. It must capture the actual write/flush completion
order beneath the selected filesystem, replay exact prefixes into fresh images,
and pass those images to the existing terminal oracle. Trace marks may segment
a log but may not stand in for flush completion.

No result from the logical layer or a simulated trace may be promoted to
physical power-loss behavior. Destructive interruption on named hardware remains
a later and separate obligation.
