# Protected endpoint-result contract

A terminal `EFFECT` or `NO_EFFECT` appraisal must be backed by a separately
governed provider history. Local absence, trace silence, response loss, a
claimed pathname, process death, or successful recovery is insufficient.

## Minimum binding

The authentic provider contract must bind:

- constituted owner and provider-admission epoch;
- exact provider account/project, resource/index, consensus group, and
  incarnation identity;
- canonical operation identity and bounded effect kind;
- endpoint instance and generation;
- exact attempt/duplicate identity and governed retention lifetime;
- terminal value: `EFFECT`, `NO_EFFECT`, `UNCERTAIN`, or fail-stop;
- provider sequence/freshness relation and external newestness evidence;
- result authentication and anti-substitution relation;
- submit and query linearization semantics;
- process, machine, network-partition, and power-loss behavior;
- backup, snapshot, point-in-time restore, clone, migration, and failover
  semantics;
- all writer, restore, replacement, deletion, and account-recovery principals;
- independent readback/appraisal and separately provisioned reopen; and
- compromise, reset, revocation, retirement, rotation, and successor behavior.

## Client law inherited from V8

```text
one fresh claimed request -> at most one submit callsite
ambiguous submit outcome  -> UNCERTAIN
reopen                     -> exact query only
reopen submit paths        -> zero
copyable result            -> no response or retry authority
```

A provider's exact-unused response may support `NO_EFFECT` only when it is
linearized over the same admitted history and cannot be produced by retention
expiry, stale replica, clone, restore, or resource replacement. Otherwise the
correct appraisal is `UNCERTAIN` or fail-stop.

## Non-equivalences

```text
transactional write != protected provider history
idempotency token != lifetime consumed identity
strong read != authenticated provider incarnation
backup restore != continuity of the original resource
byte-identical result != same writer or same effect history
signed result != authorization to retry or release
```

The ordinary result blocks in old hosted images remain schema fixtures and
counterexample inputs only.
