# Repository design v16 — expected-process gate without admission laundering

**Status:** current rev0892 Epoch-Zero repository direction. It supersedes v15
for active planning; v4 through v15 remain historical reasoning.

## Repository purpose

The repository exists to make one bounded authority membrane falsifiable from
premise through interruption, retained result, and independent reopen. It is
not an endpoint framework, process registry, credential service, archive
museum, or product shell. A new file is justified only when it tightens the
selected vertical, independently checks a claim, preserves a decisive defeat,
or makes the linked office safer to reopen and close.

The heart of the mission remains:

> one bounded effect may cross from untrusted proposal into execution only
> through protected one-use admission whose exact identity and honest result
> survive interruption, rollback, and independent appraisal.

Rev0892 improves the pre-effect process relation. It does not yet own the
admission constructor or the durable spend.

## Physical truth

```text
CANDIDATE/
  core_gate/              hosted burn-before-validation relation
  generation_journal/     hosted pending/result codec and finite relation
  handoff_cell/           selected Linux vertical:
                           - fixed live -> pending no-replace cut
                           - scoped final principals and exact fd tables
                           - immutable result/publication versions
                           - fixed query-only result surface
                           - staged listener and separate no-replace publication
                           - hidden peer pidfd and per-message process agreement
                           - sealed expected-process capsule burned before connect
                           - exact expected/connected process comparison
  ...                     older proof subjects retained, not active product

EXCAVATION/               immutable premise/counterexample custody and
                           digest-bound zero-copy cross-indexes; never runtime
EVIDENCE/                 retained observations; never authority or release
OFFICE/                   exact reopen/close continuity and current governance
DESIGN/                   current contracts plus explicit historical versions
RESEARCH/                 primary-source reading and marked speculation
REVIEW/                   judgments and source ledger
TOOLS/                    read-only verification, reconstruction, deterministic close
PREDECESSOR/              exact detached selected-parent receipt only
```

The repository has three active hosted semantic islands: `core_gate`,
`generation_journal`, and `handoff_cell`. Rev0892 adds no process registry,
endpoint registry, token service, admission daemon, publisher service, cleanup
daemon, generic launcher, query service, or fourth island.

## Vault and living project boundary

The vault is immutable custody of premise, ancestry, incidents, and
counterexamples. It may be read, hashed, cross-indexed, and distilled. It is not
compiled, imported at runtime, or silently promoted into current law.

The living project is only owner-admitted protocol, policy, provider, effect,
state, and release. This linked Epoch-Zero cube does not yet possess that owner
admission. Its candidate sources are hosted experiments; its design and office
records govern construction practice but do not rewrite the last sealed living
lineage, rev0874.

The new sealed-provider-expectation spine cross-indexes fifteen sources totaling
91,316 bytes and copies zero of them. The rev0891 branch-custody record stores
four whole-archive receipts and 94 sibling-only file receipts while duplicating
zero sibling archive bytes. Those are anti-waste custody devices, not source
imports.

## Dependency graph

The handoff build may read only its own transparent package plus three retained
generation-journal codec files. Its current transparent source inventory is 32
files: 29 within `CANDIDATE/handoff_cell` and three codec dependencies. No
target compiles, generates, or runs from `OFFICE`, `DESIGN`, `RESEARCH`,
`REVIEW`, `EXCAVATION`, `EVIDENCE`, or `PREDECESSOR`.

The 96-byte expectation format is fixed in the handoff contract; no code is
generated from prose or evidence. The campaign and independent oracle read
canonical products from an external work directory. Build trees, binaries,
Python bytecode, native descriptors, and temporary sockets never belong in the
checkpoint.

## Active target classes

- `model_*`: executable semantic relation with mandatory nonauthority boundary;
- `lab_*`: reconstruction, fault injection, host observation, or comparison;
- `product_*`: forbidden until owner genesis, operated external custody,
  destructive evidence, independent appraisal, and release gates exist.

Precise Linux types do not upgrade a model into a product. A sealed memfd, a
pidfd, a close-before-connect order, and byte-identical three-lane output are
hosted evidence only.

## Selected vertical

```text
owner/genesis                              OPEN
  -> executable/provider custody           HOSTED PARTIAL, ADMIN OPEN
  -> expected-provider constructor         SELF-MINTED HOST FIXTURE ONLY
  -> sealed fixed expectation shape        HOSTED OBSERVED
  -> exact record/pidfd process agreement  HOSTED OBSERVED
  -> actor-local burn before connect        HOSTED OBSERVED
  -> durable globally unique spend         OPEN
  -> final-principal listener bind          HOSTED OBSERVED
  -> separate public-name publication      HOSTED OBSERVED, PUBLISHER OPEN
  -> later fixed-leaf query connection      HOSTED OBSERVED
  -> connected peer == expected process     HOSTED OBSERVED, OWNER OPEN
  -> per-message process agreement          HOSTED OBSERVED, ADMIN OPEN
  -> fixed endpoint invocation              LOCAL SHAPE ONLY
  -> exact pending identity                 LOCAL SHAPE ONLY
  -> immutable honest result                LOCAL SHAPE ONLY, MEDIA OPEN
  -> fixed query-only exposure              HOSTED OBSERVED
  -> external rollback floor                OPEN
  -> independent reopen/appraisal           OPEN
```

Only one arrow may be deepened at a time. The current positive relation ends at
“connected peer equals the actor-locally consumed expected process.” It must not
be restated as “owner-authorized provider admitted exactly once.”

## Object rule for expected endpoint construction

A future design must keep at least these objects distinct:

```text
owner-admission statement
expectation constructor process and executable
sealed expectation record
record descriptor slot
provider pidfd descriptor slot
provider process instance
staging parent
public parent
listener inode/open file description
public pathname
connected socket
query principal
publication / retirement / spend receipt
```

Descriptor copies may refer to the same record or process. A pathname may refer
to a different listener after retirement and republish. A connected socket may
outlive or diverge from the public name. An exact process may still be
unadmitted. A receipt may describe a spent relation without granting live
power. Any design that calls these collectively “the endpoint token” is
rejected.

## Admission rule for new code

A proposed source family is admitted only when all are true:

1. it names one open obligation in the selected vertical;
2. the existing three islands cannot honestly host the cut;
3. one executable negative control can falsify the intended claim;
4. an independent checker can consume stable canonical products;
5. no vault, office, design, research, review, evidence, or predecessor path is
   a build/runtime dependency;
6. the public authority surface is narrower than the wrapped kernel mechanism;
7. interruption and duplicate-custody states are named before coding; and
8. deletion criteria are written before construction.

Rev0892 required no new family. Two implementation files inside `handoff_cell`
were sufficient, and two negative controls defeat provenance and global one-use.

## Anti-waste rules

Reject:

- a token service when one fixed record and one process descriptor suffice for
  the present counterexample;
- cryptography before a protected constructor and owner namespace exist;
- a serial called unique without a durable spend relation;
- move-only C++ ownership called one-use in a system with `dup` and transfer;
- exact memfd seals called provenance;
- exact pidfd equality called owner admission or executable continuity;
- more PID-shaped observations before the constructor is governed;
- cleanup logic used to compensate for leaked listener custody;
- connection failure used as a retirement oracle;
- sibling checkpoint code merged without one corresponding campaign and close;
- a revision label used as lineage identity;
- copied vault prose when a digest-bound cross-index suffices;
- a new schema when a fixed function or fixed record suffices;
- ordinary DAC used as root or management-plane closure;
- local immutable names advertised as stable media; and
- evidence, receipts, or checkpoint hashes advertised as authority.

## Selected next cut

The next construction is a **protected expectation constructor plus durable
spend experiment**, still inside Epoch Zero. It must begin outside the query
transport, bind one owner-admitted provider epoch to one exact process and query
principal, and expose no generic mint/retry route. Its negative controls must
include root self-mint exclusion, duplicate descriptors, process death between
construction and spend, interruption around the spend cut, and coherent
rollback. If those cannot be represented without a new semantic island, the
island proposal must first satisfy the admission rule above.

## Epoch stop

Remain in Epoch Zero while any of these are absent: authentic owner genesis,
protected constructor, globally unique durable spend, source-to-operated-binary
identity, closed privileged administration, stable media, destructive reset
evidence, external rollback floor, independent appraisal, and release
identity. Hosted precision is progress, not authority.
