# Surface constitution

SlopOS currently has several adjacent surfaces with different authority. Their
physical proximity in one datacube is a convenience, not a promotion mechanism.

| Surface | Meaning | May change here? | Can govern an effect? |
|---|---|---:|---:|
| sealed vault | exact premise, ancestry, and historical artifacts | no | no, unless separately admitted into living law |
| living lineage | last deliberately constituted SlopOS law, presently rev0874 | no | only within its stated scope; this checkpoint does not extend it |
| linked checkpoint | resumable office and construction proposal, presently rev0885 | yes before closure | no |
| candidate source | hosted implementation or proof experiment | yes before closure | no |
| retained evidence | observation of a named build or campaign | replace only by explicit reconstruction | no |
| office | typed claims, gates, obligations, incidents, and procedures | yes before closure | no; it records governance rather than impersonating it |
| release | governed source/binary/proof identity admitted by owners | absent | potentially, after constitution and enrollment |

## Promotion is an explicit transaction

No file becomes living law because it is newest, because a checker passes, or
because it appears under a directory named `current`. Promotion requires a
constituted owner set, an identified candidate, a complete claim/nonclaim record,
a successful gate decision, a release identity, and an immutable admission
record. A later checkpoint may propose this transaction but cannot infer it.

## Read and write rules

The root read order is authoritative for office resumption. Vault and retained
evidence are read-only. Reconstructors write only to caller-selected external
work directories. The sole checkpoint predecessor is an exact archive, not an
unpacked editable copy. Closure normalizes modes, refreshes the content manifest,
verifies every local projection, tests fresh-destination extraction, and creates
one deterministic archive.

## Boundary failures to reject

- Treating a vault decision as automatically current.
- Treating a process, directory, compiler, or key inside one cloudtainer as an
  independent actor or separately provisioned provider.
- Treating an evidence packet, transcript, or digest as authorization.
- Treating a terminal receipt as a durable protected result.
- Treating a generic ZIP extractor's permission choices as checkpoint identity.
- Reusing an extraction destination and then blaming the archive for residue or
  permission failures.
- Letting a resume or verification command mutate the checkpoint it is judging.

## Present authority statement

Rev0885 contains a stronger candidate relation, a deeper historical derivation,
and a safer closure contract. It still has no constituted owner, authenticated
provider, protected one-use capability, protected endpoint, durable result
service, external rollback floor, independent actor, sealed release, or epoch
advance. Epoch Zero therefore remains the only coherent label.
