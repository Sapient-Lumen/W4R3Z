# Native capture supervisor profile

## Required operating boundary

The future supervisor must be a small, privilege-separated provider operated on
one fresh named disposable Linux storage subject. It should have a privileged
setup/teardown component and a constrained workload component. Its complete
subject includes the supervisor executable, kernel and boot, namespace graph,
capability transitions, device graph, target table, baseline, workload, export
range, receipt destination and all helper executables.

## Process-instance custody

Prefer process creation that returns a pidfd atomically with child creation.
Retain and use that descriptor for wait and signal operations. Numeric PIDs are
diagnostic only. The supervisor must also bind the executable image, argument and
environment bytes, descriptor topology, namespaces, credentials, capabilities,
`no_new_privs`, seccomp policy and terminal wait status. A pidfd alone does not
establish those joins.

## Writer closure

Before target activation, enumerate and close all known direct target and log
device aliases. Place workload and helpers inside a private mount namespace with
only the intended logging-target path. Drop unneeded capabilities and prevent
helper re-entry into privileged namespaces. Keep device descriptors under one
supervisor-owned topology. Retain explicit checks and failures; do not infer
exclusive writer closure merely from absence in a process list.

The design must state its adversary limit. Namespace and capability discipline
may constrain ordinary child processes, but does not by itself prove exclusivity
against a same-host privileged adversary, kernel compromise, firmware or
out-of-band device access.

## Ceremony ownership

One supervisor invocation owns:

```text
run authorization
preclean
namespace and device binding
target creation
workload creation and wait
target removal
export read and range closure
receipt publication
failure/incomplete disposition
```

No restarted invocation may inherit a live run identity by filename or run ID.
It may inspect and quarantine remnants, but cannot complete the original
ceremony unless a separately designed recovery protocol provides protected
continuity.

## Output

The provider emits exact Proposal, Witness, Receipt, trace and baseline bytes.
It additionally emits external evidence used by a separately operated appraiser
to establish provider, machine, process and writer custody. The packet itself
remains authority-free.
