# Repository design v13 — one vertical through launch and fixed query

**Status:** current rev0889 Epoch-Zero repository direction. It supersedes v12
for active planning; v4 through v12 remain historical reasoning.

## Repository purpose

The repository exists to make one bounded authority claim falsifiable from
constitution through interruption and independent reopen. It is not a museum of
schemas and not a package collection. Each new source file must either tighten
the selected vertical, independently check it, preserve a decisive
counterexample, or make the office safer to resume and close.

## Physical truth

```text
CANDIDATE/
  core_gate/              hosted burn-before-validation relation
  generation_journal/     hosted pending/result codec and finite relation
  handoff_cell/           selected Linux vertical:
                           - fixed live -> pending no-replace cut
                           - scoped provider-principal cell
                           - immutable result/publication versions
                           - exact hosted launch descriptor tables
                           - fixed query-only result surface
  ...                     older hosted subjects retained, not active product

EXCAVATION/               immutable premise/counterexample custody and
                           digest-bound cross-indexes; never build input
EVIDENCE/                 retained observations; never authority
OFFICE/                   reopen/close continuity and current governance
DESIGN/                   current contracts plus explicit historical versions
RESEARCH/                 primary-source reading and marked speculation
REVIEW/                   judgments and source ledger
TOOLS/                    read-only verification, reconstruction, close
PREDECESSOR/              detached exact immediate-predecessor receipt only
```

Rev0889 adds no `launcher/`, `query_service/`, `identity/`, `sandbox/`,
`authority_graph/`, or fourth state machine. Launch and query code belong in
`handoff_cell` because they close the next seam in O57→O59.

## Dependency graph

The selected C++ package may depend only on its own transparent files and the
three retained generation-journal codec files required to encode/decode the
fixed 128-byte record. No target compiles, generates, or runs from `OFFICE`,
`DESIGN`, `RESEARCH`, `REVIEW`, `EXCAVATION`, `EVIDENCE`, or `PREDECESSOR`.

The new launch/query custody spine is deliberately a cross-index: sixteen
existing source records are digest-bound in place and zero source bytes are
copied. This is the preferred correction for repeated vault excavation.

## Active target classes

- `model_*`: executable semantic relation with mandatory nonauthority boundary;
- `lab_*`: reconstruction, fault injection, host observation, or comparison;
- `product_*`: forbidden until owner admission, operated external custody,
  destructive evidence, and release gates exist.

`handoff_cell` remains model/lab code. Class names such as `PrincipalCell` and
`FixedResultQuery` do not constitute product authority.

## Selected vertical

```text
owner/genesis                     OPEN
  -> executable/provider custody  HOSTED PARTIAL, ADMIN OPEN
  -> exact descriptor table       HOSTED OBSERVED
  -> protected one-use admission  LOCAL SHAPE ONLY
  -> fixed endpoint invocation    OPEN
  -> exact pending identity       LOCAL SHAPE ONLY
  -> immutable honest result      LOCAL SHAPE ONLY, MEDIA OPEN
  -> fixed query-only exposure    HOSTED OBSERVED
  -> external rollback floor      OPEN
  -> independent reopen           OPEN
```

The repository may deepen only one of these arrows at a time. Local shape is
never relabeled as external custody.

## Admission rule for new code

A proposed source family is admitted only when all are true:

1. it names one open obligation in the selected vertical;
2. the existing package cannot honestly host the cut;
3. one negative control can falsify its intended claim;
4. an independent checker can read stable canonical products;
5. the code has no vault/evidence/runtime dependency; and
6. deletion criteria are written before construction.

Rev0889 meets the rule by extending the existing handoff package. A generic
launcher framework would not.

## Anti-waste rules

Reject:

- a new schema or packet when a fixed function suffices;
- a new hosted actor family before the external provider experiment;
- copied vault prose when a digest-bound cross-index suffices;
- credential labels used as complete principal identity;
- CLOEXEC hygiene used as exact descriptor construction;
- `SO_PEERCRED` used as current post-drop message identity;
- payload parsing before ancillary-right rejection;
- query timeout used as retry permission or no-effect evidence;
- cleanup, route, version choice, or repair hidden in reconciliation;
- local immutable names advertised as stable media;
- evidence, receipts, transcripts, or checkers promoted to authority;
- recursive predecessor archives; and
- repository-wide refactors that do not remove an open proof premise.

Prefer one cut, one counterexample, one oracle, one retained evidence set, one
current decision, and one externally operable next experiment.

## Future product admission

`product/provider/*` remains prospective. It requires an owner-ratified epoch,
provider and administration identity, exact executable and descriptor custody,
root/mount/snapshot inventory, fixed endpoint, compromise procedure, and
separately constituted appraiser. `product/result/*` additionally requires
stable media, destructive cuts, immutable uncertainty/refinement semantics,
external rollback observation, and independent reopen. `product/release/*`
requires admitted source-to-binary identity and governed release authority.

## Epoch judgment

Rev0889 improves one hosted seam and catches a credential-coordinate error that
could have certified the wrong actor. It does not establish the external root of
trust. Exact rev0874 remains the last sealed living lineage; rev0889 remains a
linked laboratory office in Epoch Zero.
