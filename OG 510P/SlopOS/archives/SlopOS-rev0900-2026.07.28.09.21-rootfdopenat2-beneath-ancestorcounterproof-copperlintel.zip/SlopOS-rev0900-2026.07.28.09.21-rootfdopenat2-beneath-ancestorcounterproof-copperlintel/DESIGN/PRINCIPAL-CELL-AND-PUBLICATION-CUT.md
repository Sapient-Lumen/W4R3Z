# Principal cell and immutable publication cut

**Status:** current rev0888 Epoch-Zero design contract; hosted and
nonauthoritative.

## Why this is still the selected vertical

Rev0887 proved a useful local name shape but accepted a caller-selected cell
directory. Rev0888 does not create a fourth model. It extends the same handoff
vertical far enough to distinguish three things that were about to collapse:

```text
provider-principal pathname exclusion
exact descriptor and administration custody
stable immutable result truth
```

The first can be observed locally. The other two remain open.

## Hosted construction

A process already running as one declared nonzero provider UID receives one
owner-only provider-root descriptor. It creates only fixed child `cell`, exports
no cell descriptor, stages exact pending bytes internally, and performs the V1
fixed no-replace handoff. Results and their publication are appended under fixed
versioned leaves:

```text
live -> pending
result.1 = UNCERTAIN
publication.1
result.2 = exact refinement
publication.2
```

Every result/publication append uses a fixed staging leaf, file fsync, one
`RENAME_NOREPLACE` bind, and directory fsync. Existing final leaves are never
replaced. Version 2 is legal only after immutable uncertain version 1 with the
same operation identity. Publication cannot precede or disagree with its exact
result. Query methods are fixed-leaf, nonmutating reads.

## Scoped positive relation

On the retained host:

- provider UID 21001 creates fixed owner-only cell mode `0700`;
- workload UID 21002 receives no cell or object descriptor;
- workload path open, link, rename, and unlink attempts fail;
- both result and publication versions remain exact and queryable;
- duplicate finals preserve existing bytes; and
- staging residue and invalid refinement fail stop.

This relation excludes only the declared unprivileged workload principal under
the observed Linux DAC contract.

## Counterproofs that define the real boundary

A same-UID peer can chmod and mutate. A writable descriptor inherited before
credential narrowing remains writable. A root-equivalent actor bypasses DAC.
Hard-link aliases, already-open writers, and coherent local rollback remain
from V1. Therefore none of these phrases is allowed:

```text
protected provider
exclusive writer custody
stable result service
exactly once
rollback resistant
authoritative
```

## Ordering and failure meaning

A successful no-replace bind followed by directory-sync failure is bound with
sync uncertainty, never rejection or a retry grant. A stage file present after
a crash or conflict is substrate residue. Query-only protocol reconciliation
does not unlink, rename, or repair it. A separately authorized storage-recovery
principal must handle such writes under a future platform contract.

## Authentic next experiment

Operate one owner-named external provider with:

1. an exact launch descriptor table and capability floor;
2. separately constituted administration and workload principals;
3. a provider-owned root whose mount/snapshot writers are enumerated;
4. one fixed harmless endpoint and authenticated bounded query;
5. stable result media challenged at every append/publish cut;
6. an external monotonic rollback floor; and
7. an independently provisioned reopen actor.

A negative result is acceptable. Another local schema family is not.

## Rev0889 launch/query adjacency

The principal cell is now entered through an executed hosted launch profile
rather than assumed only after credential transition. This closes an observed
shape—exact post-`exec` fd inventories—and retains an off-by-one leak as a
counterexample. It does not authenticate who supplied the provider-root fd or
who administers the launcher.

A separate fixed query surface reads only canonical `pending` and immutable
`result.2` after validating per-message query credentials. Descriptor-bearing
requests are closed and rejected before payload parse. The query surface has no
repair, cleanup, route, result-version, dispatch, or retry function. These facts
narrow protocol reconciliation; they do not prove the result medium or provider
is protected.
