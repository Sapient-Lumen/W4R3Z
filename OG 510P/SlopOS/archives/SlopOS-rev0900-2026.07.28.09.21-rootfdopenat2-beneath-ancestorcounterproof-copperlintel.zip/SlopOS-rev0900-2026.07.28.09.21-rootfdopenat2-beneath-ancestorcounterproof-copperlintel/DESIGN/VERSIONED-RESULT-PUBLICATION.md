# Versioned result publication

## Why uncertainty is a result

After one fixed endpoint invocation, transport loss or malformed return can
leave two hidden histories: effect happened or effect did not happen. The
honest result is `UNCERTAIN`. Suppressing it until reconciliation hides the
operational state; overwriting it later destroys what the system knew and what
a relying party may have observed.

The result service therefore stores immutable versions.

## Keys and values

```text
ResultKey = (owner_epoch, operation_id, result_version)
PublicationKey = (owner_epoch, operation_id, publication_version)

ResultValue = {
  endpoint_id,
  generation_from,
  generation_to,
  request_digest,
  spent_receipt_digest,
  terminal_class,
  evidence_digest,
  created_by_component,
  created_at_witness
}
```

Version 1 is the first terminal observation and may be `EFFECT`, `NO_EFFECT`,
`UNCERTAIN`, or `FAIL_STOP`. Only version-1 `UNCERTAIN` can be refined, once, to
version 2. Version 2 is exact `EFFECT`, `NO_EFFECT`, or `FAIL_STOP` from
query-only reconciliation.

## Append laws

- inserting an existing result or publication key fails without replacement;
- publication references an already retained exact result version;
- publication version never exceeds result version;
- result version 2 requires exact version 1 and the same immutable operation
  fields;
- terminal class may change only from `UNCERTAIN` at v1 to an exact class at v2;
- evidence and provenance are bound into each version rather than patched in
  place;
- publishing or reading a result grants no effect, route, retry, or capability;
- garbage collection is a governed retention action, not ordinary overwrite.

## Relying view

A relying party asks for the greatest published version it is authorized to
observe. That projection may move from 1 to 2, but both underlying versions
remain addressable for audit. A consumer that cached version 1 can detect that
version 2 exists; it cannot reinterpret v1 as if it had always been exact.

## Failure cuts

```text
result v1 durable, publication v1 absent     -> result exists, not yet published
publication v1 durable                       -> uncertainty may be relied upon
result v2 durable, publication v2 absent     -> exact refinement exists privately
publication v2 durable                       -> exact refinement becomes current view
```

A postpublication error cannot be reported as rejection. Recovery reads the
no-replace key and returns the existing exact record.

## Storage nonclaim

The rev0886 128-byte codec and finite publication counter model these laws. CRC
is corruption detection only. Stable media, authenticated writers, directory
persistence, rollback resistance, retention, and independent reopen are open
platform obligations.
## Rev0888 hosted filesystem realization

`CANDIDATE/handoff_cell` now realizes the four fixed leaves with file fsync,
`RENAME_NOREPLACE`, and directory fsync. It confirms no-overwrite, predecessor,
operation-identity, and publication-order laws under the recorded host contract.
A duplicate final leaves fixed staging residue and fails stop; query-only
protocol reconciliation exposes no cleanup write.

This is not the stable-media service required by O59. The provider root is
host-selected, root-equivalent administration remains open, alternate
mount/snapshot writers are untested, no physical power-loss campaign occurred,
and no external floor distinguishes coherent rollback.

