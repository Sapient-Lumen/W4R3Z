# Repository design v17 — content-bound spend relation without a spend daemon

**Status:** current rev0893 Epoch-Zero repository direction. It supersedes v16
for active planning; v4 through v16 remain historical reasoning.

## Repository purpose

The repository exists to make one bounded authority membrane falsifiable from
proposal through protected admission, one effect, honest result, interruption,
rollback, and independent reopen. It is not an operating-system breadth tree,
service manager, token platform, archive museum, or authority merely because
its tests are precise.

The mission remains:

> one bounded effect may cross from untrusted proposal into execution only
> through protected one-use admission whose exact identity and honest result
> survive interruption, rollback, and independent appraisal.

Rev0893 closes one provider-independent proof gap: a spend floor must compare
and retain exact content head as well as generation. It does not yet operate the
protected floor or join its winner to the effect.

## Physical truth

```text
CANDIDATE/
  core_gate/              hosted burn-before-validation relation
  generation_journal/     hosted pending/result relation plus canonical
                           content-bound spend record and compare-and-append cut
  handoff_cell/           selected Linux descriptor/process/endpoint vertical
  ...                     older proof subjects retained, not active product

EXCAVATION/               immutable premise/counterexample custody; never runtime
EVIDENCE/                 retained observations; never authority or release
OFFICE/                   exact reopen/close continuity and current governance
DESIGN/                   current contracts plus explicit historical versions
RESEARCH/                 primary-source reading and marked speculation
REVIEW/                   judgments and source ledger
TOOLS/                    read-only verification, external reconstruction, close
PREDECESSOR/              exact detached immediate-parent receipt only
```

There are exactly three active hosted semantic islands: `core_gate`,
`generation_journal`, and `handoff_cell`. Rev0893 adds no spend daemon, token
service, process registry, endpoint registry, generic admission service,
publisher daemon, cleanup daemon, generic launcher, query service, service
manager, or fourth island.

## Current source boundary

The generation-journal package now contains 29 transparent source/spec/proof
files. Its build reads only its own package. The retained handoff build remains
29 `handoff_cell` files plus three transparent generation-journal codec
dependencies, for 32 inputs. No target compiles, imports, generates, or runs
from `EXCAVATION`, `EVIDENCE`, `OFFICE`, `DESIGN`, `RESEARCH`, `REVIEW`, or
`PREDECESSOR`.

The new spend codec and relation are housed in `generation_journal` because
that island already owns exact pending identity, invocation refinement,
result versions, and query-only recovery. Creating a separate spend service
would have hidden the provider question behind an interface before writer
custody or rollback had been proved.

## Vault and living project

The vault is immutable premise, ancestry, incident, and counterexample custody.
It may be read, hashed, and distilled into current bounded laws. It is not
current product source or living law.

The living project is only what constituted owners admit as protocol, policy,
provider, effect, protected state, result, release identity, and compromise
procedure. Exact rev0874 remains the last sealed living lineage. Rev0893 is a
linked resumable office and hosted proof surface.

The new spend/rollback custody spine cross-indexes 20 exact sources and 110,653
bytes while copying zero source bytes. It preserves the sealed scalar-floor
implementation unchanged and records the precise boundary: its ordering theorem
requires exclusive writer custody and does not independently identify which
foreign content won.

## Selected vertical

```text
owner/genesis                               OPEN
  -> constructor executable/input custody   OPEN
  -> owner-admitted provider process         OPEN
  -> sealed expected-process shape           HOSTED OBSERVED
  -> actor-local burn before connect         HOSTED OBSERVED
  -> canonical content-bound spend record    HOSTED MODELLED
  -> expected-generation+head compare        HOSTED MODELLED
  -> one append winner / foreign conflict    HOSTED MODELLED
  -> exact already-current query-only        HOSTED MODELLED
  -> protected writer and stable media       OPEN
  -> external rollback floor                 OPEN
  -> nonreplayable append-to-endpoint join   OPEN
  -> final-principal endpoint relation       HOSTED OBSERVED, ADMIN OPEN
  -> exact pending/result identity           HOSTED MODELLED
  -> immutable honest result                 HOSTED MODELLED, MEDIA OPEN
  -> retirement and successor authority      OPEN
  -> independent reopen/appraisal            OPEN
```

The present theorem ends at “one modeled compare-and-append winner.” It must not
be restated as “one protected globally unique effect.”

## Object rule

At minimum, keep these distinct:

```text
owner statement
constructor image and process
expectation record
spend record
floor identity
floor generation
floor content head
append request
append response
protected winner custody
endpoint admission
provider process instance
publication receipt
pending-result identity
immutable result version
retirement/successor decision
```

A generation is not a content head. An append response is not winner custody.
A signed receipt is not a callable capability. Exact already-current is not
permission to reinvoke. Local database durability is not external rollback.
Provider death is not settlement or endpoint retirement.

## Admission rule for new code

A source family is admitted only when all are true:

1. it closes or falsifies one named P0 obligation in the selected vertical;
2. the existing three islands cannot honestly host the cut;
3. its public authority surface and deletion criteria are written first;
4. at least one executable negative control defeats the strongest tempting
   claim;
5. an independently spelled checker consumes canonical outputs;
6. no vault/office/design/research/review/evidence/predecessor dependency enters
   build or runtime;
7. crash, rollback, duplicate-writer, and prior-outcome states are named before
   coding; and
8. success cannot be inferred from one label, scalar, pathname, response byte
   string, or process-local wrapper.

Rev0893 needed no new family. Three implementation files, three headers, one
campaign extension, one independent verifier, and bounded specifications inside
the existing generation-journal island were sufficient.

## Anti-waste rules

Reject:

- a daemon before the protected writer's owner and lifecycle are named;
- a scalar counter called spend identity;
- TPM increment or extend called compare-and-append without a protected stale-
  writer check;
- an `advanced` response called a one-use capability;
- local SQLite called an external floor when snapshots restore it with the host;
- signatures added before constructor provenance and owner namespace exist;
- retries that turn exact already-current into another invocation;
- more endpoint/process observations before the spend-to-effect join is owned;
- a fourth semantic island that merely wraps existing candidate functions;
- copied vault sources when a digest-bound cross-index suffices;
- monolithic evidence commands as the only resume path;
- build products, bytecode, sockets, or temporary databases inside the cube;
- revision label, filename, checkpoint coherence, or retained evidence promoted
  to living authority.

## Selected next cut

The next construction is a **protected compare-and-append provider and
nonreplayable endpoint join**, not another record format. It must name owner
and floor genesis, exact writer executable/process, external rollback domain,
stable-media profile, independent reader, and compromise procedure before
implementation. Mandatory defeats include competing writers, stale expected
head, crash before/after append, replayed response, coherent cloudtainer
rollback, backup/restore divergence, provider replacement, and independent
reopen.

A local transactional provider may be used first as a fault-injection adapter,
but its status must remain hosted until its storage and administration are
outside the rollback subject.

## Epoch stop

Remain in Epoch Zero while authentic owner genesis, protected constructor,
protected writer, globally unique durable spend, nonreplayable effect join,
source-to-operated-binary identity, stable media, destructive reset evidence,
external rollback, independent appraisal, and release identity remain absent.
