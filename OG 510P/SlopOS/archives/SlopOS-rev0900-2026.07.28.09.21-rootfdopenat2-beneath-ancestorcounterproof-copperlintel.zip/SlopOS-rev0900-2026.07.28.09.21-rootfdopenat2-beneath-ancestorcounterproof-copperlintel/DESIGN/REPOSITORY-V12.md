# Repository design v12 — one vertical, two scoped cuts

**Status:** current rev0888 Epoch-Zero repository direction. It supersedes v11
for active planning; earlier versions remain historical reasoning.

## Purpose

The repository exists to make one bounded authority claim falsifiable from
source through destructive operation. Vault, office, research, and evidence are
custody and reasoning surfaces. They are never product dependencies.

## Current physical truth

```text
CANDIDATE/
  core_gate/              hosted burn-before-validation relation
  generation_journal/     hosted pending/endpoint/result relation and codec
  handoff_cell/           one Linux handoff vertical, now including:
                           - fixed live -> pending no-replace cut
                           - scoped provider-principal cell factory
                           - immutable result/publication append cut
  ...                     older hosted subjects retained, not current product

EXCAVATION/               immutable premise/counterexample custody
EVIDENCE/                 immutable observations
OFFICE/                   linked-office continuity and governance proposals
DESIGN/                   current and historical contracts
RESEARCH/                 primary-source reading and marked speculation
TOOLS/                    read-only verification, reconstruction, close
PREDECESSOR/              detached exact receipt only
```

Rev0888 deliberately does **not** add `result_cell/`, `sandbox/`, `identity/`,
or another packet family. Principal and publication work stays in
`handoff_cell/` because it tests the same O57→O59 vertical.

## Dependency rule

The handoff package depends only on three transparent generation-journal codec
files. It does not compile or run against office, evidence, excavation,
research, review, or predecessor content. The old-vault principal spine is
premise custody only.

## Target classes

- `product_*`: owner-admitted source eligible for governed release;
- `model_*`: executable semantics with explicit no-authority boundary;
- `lab_*`: reconstruction, fault injection, acquisition, or comparison.

The current handoff target remains a hosted model/lab construction. A C++ class
named `PrincipalCell` does not make it a product or protected provider.

## Current refinement boundary

```text
core_gate protected receipt premise
    -> handoff cell exact pending identity
    -> fixed endpoint premise
    -> immutable result/publication versions
```

Only the middle local shapes execute here. The arrows still require provider
authentication, exact descriptor topology, administration closure, endpoint
rendezvous, stable media, rollback floor, and independent reopen.

## Anti-waste and anti-laundering rules

Reject:

- a fourth hosted semantic island for a seam already owned by `handoff_cell`;
- UID, mode bits, namespaces, or private constructors advertised as complete
  custody;
- credential dropping advertised as revocation of inherited descriptors;
- immutable local filenames advertised as stable-media truth;
- cleanup writes hidden inside query-only reconciliation;
- generic sandbox, capability-graph, result-schema, or orchestration frameworks
  before the named external vertical operates;
- any vault/evidence path entering a build; and
- recursive predecessor archives.

Prefer one executable cut, one independent oracle, one retained defeat, one
current decision, and one exact next external experiment.

## Required future product tree

The v11 prospective layout remains valid, but admission now has a sharper gate:
`product/provider/cell` cannot exist merely because the hosted principal
campaign passes. It requires owner ratification and operated evidence for exact
descriptor/capability topology, administration ownership, root/mount custody,
and compromise procedure. `product/provider/result` additionally requires
stable media, destructive cuts, external rollback observation, and independent
reopen.

## Epoch judgment

Rev0888 improves the selected proof seam and compresses old-vault insight. It
is still a linked laboratory office. Exact rev0874 remains the last sealed
living lineage.
