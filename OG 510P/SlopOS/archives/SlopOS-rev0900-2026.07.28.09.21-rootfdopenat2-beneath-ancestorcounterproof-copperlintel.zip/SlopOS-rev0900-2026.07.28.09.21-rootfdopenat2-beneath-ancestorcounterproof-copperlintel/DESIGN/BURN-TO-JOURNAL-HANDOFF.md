# Burn-to-journal handoff

## Problem statement

The core gate's safety cut is capability consumption before validation. The
generation endpoint's safety cut is exact pending readback before invocation.
A crash can occur between those cuts. If the protected gate forgets the exact
consumed operation before the journal retains it, local recovery cannot know
which operation may have crossed the authority boundary.

This is the highest-priority construction gap in rev0886.

## Retained indistinguishability witness

The local journal observation `EMPTY` has at least two histories:

| history | protected capability history | local journal |
|---|---|---|
| unspent | capability remains live | `EMPTY` |
| spent-before-bind | capability was consumed and the process died before exact pending identity was retained | `EMPTY` |

Therefore `EMPTY` cannot authorize retry and cannot prove no effect. A protected
spent receipt, co-committed pending identity, or endpoint-owned atomic binding
must distinguish these histories before recovery may construct even a
query-only binding.

## Required protected record

A spent identity must bind at least:

```text
owner_epoch
capability_issuer
capability_generation
operation_id
canonical_request_digest
fixed_endpoint_id
generation_from
generation_to = generation_from + 1
consumption_counter_or_unique_nonce
consumed_at_monotonic_witness
state = SPENT_PENDING | COMPLETED
```

The record must be queryable after process and machine restart by exact
operation identity. It must not contain a reusable bearer capability. Query
access and apply access are distinct.

## Acceptable implementations

### A. Co-located atomic transition

The protected gate and generation cell share one transaction:

```text
verify live capability
consume capability
insert exact SPENT_PENDING row
commit
```

Only the committed row can authorize construction of a volatile invocation
ticket. This is the smallest proof surface when gate and endpoint can share a
trust domain.

### B. Protected spent-receipt primitive

The capability provider atomically changes a one-use capability from LIVE to
SPENT and stores the exact operation binding in protected state. The generation
service later queries that state and creates only a query binding after restart.

This preserves component separation but enlarges the provider protocol and the
cross-component proof.

### C. Endpoint-owned compare-and-bind

The endpoint consumes a protected one-use reference and atomically creates the
pending identity before any effect. This may collapse “gate” and “endpoint” into
one component. That collapse is acceptable if it reduces the trusted surface;
architecture names are not worth an extra distributed transaction.

## Rejected implementations

The following do not close the gap:

- write a local file after consuming an unrelated remote capability;
- rely on a C++ move-only object surviving only in process memory;
- infer the operation from the newest request in a queue;
- scan ordinary logs and choose the most plausible match;
- mint a replacement apply token during recovery;
- retry the request with a newly generated idempotency key;
- use CRC, file mode, rename, or fsync as an authenticity primitive; or
- store a bearer capability in a restorable checkpoint image.

## Recovery protocol

Recovery takes an operation identifier from protected inventory, not from a
caller-supplied guess:

```text
spent = provider.query_spent(owner_epoch, operation_id)
if absent:
    no query binding; do not infer unspent if provider is unavailable
if mismatch:
    FAIL_STOP
if exact SPENT_PENDING or COMPLETED:
    construct query-only binding
    endpoint.query_exact(operation_id, generations, request_digest)
```

No recovery branch calls apply. Provider unavailability preserves uncertainty.
A different successor fails stop. Exact predecessor is no-effect. The exact
same successor is effect.

## Atomicity decision test

Before choosing a platform, ask whether the protected capability state,
endpoint mutation, and completion record can commit in one transaction. If not,
name every inter-commit cut and retain uncertainty at each. A design that uses
two storage systems but describes one atomic effect is rejected.

## Proof obligations

1. Unspent and spent-before-local-bind histories are distinguished by protected
   state after restart.
2. Every spent identity maps to exactly one operation and endpoint generation
   pair.
3. A spent identity cannot be returned to LIVE by restoring local storage.
4. Recovery has no code path to apply, route, retry, or mint.
5. Endpoint effect and completion/result retention are atomic, or every gap is
   represented as uncertainty with exact query rendezvous.
6. Garbage collection cannot remove spent/completion identity while a retry or
   reconciliation reference can remain valid.
7. Owner epoch rollover makes stale identities fail closed rather than alias a
   new operation.

The hosted C++ package proves only API-shape and finite-relation consequences.
It does not implement these premises.

## Rev0887 executable refinement

`CANDIDATE/handoff_cell` now instantiates the smallest local form of the
co-located cut.  Exact pending bytes are pre-staged under the inert fixed leaf
`live`; one `renameat2(..., RENAME_NOREPLACE)` call removes that leaf and binds
the fixed leaf `pending`; decoding follows the rename.  Sixteen racing processes
produce one successful bind, and scheduled process death never recreates a
locally burned `live` name.

This narrows but does not discharge the contract above.  Hard-link aliasing, an
already-open writable descriptor, and coherent snapshot rollback are retained
counterexamples.  The candidate does not own staging, exclude alternate writers,
authenticate a provider, operate the endpoint, establish stable media, or bind
an external floor.  O57 therefore remains open at the protected-provider layer.
See `HANDOFF-CELL-REFINEMENT.md` for the exact theorem and nonclaims.

## Rev0893 correction — spend identity is content-bound

The actor-local expectation burn still outruns durable global identity. Rev0893
now freezes the provider-independent repair: one canonical spend record must be
atomically compared and appended against exact floor identity, predecessor
generation, **and predecessor content head**. A scalar floor cannot distinguish
which foreign successor won.

The exact already-current successor is query-only and cannot mint another
endpoint invocation. Foreign, scalar-only, unavailable, malformed, or
identity-mismatched observations fail closed. However, an accepted `advanced`
response remains replayable evidence in the pure model. The unresolved handoff
is therefore narrower and sharper:

```text
one protected compare-and-append winner
  -> one nonduplicable endpoint admission
  -> one exact pending/result identity
```

No response byte string, signature, local transaction, or move-only wrapper may
stand in for that join.
