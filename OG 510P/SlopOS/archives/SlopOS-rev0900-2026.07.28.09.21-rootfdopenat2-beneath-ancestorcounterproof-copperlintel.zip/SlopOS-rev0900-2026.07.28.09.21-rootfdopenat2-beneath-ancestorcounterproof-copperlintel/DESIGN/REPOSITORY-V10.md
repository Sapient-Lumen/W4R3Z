# Repository design v10 — one authority vertical

**Status:** current Epoch-Zero repository direction for rev0886.  
**Supersedes for active planning:** `REPOSITORY-V9.md`. Earlier versions remain
historical design evidence.

## Design objective

The repository must make the authority membrane easier to audit than any
surrounding vocabulary. It should be possible to follow one operation from
inert protocol values to a protected result without traversing the vault,
review essays, generated evidence, or a family of domain schemas.

The repository is not yet a release repository. Rev0874 remains the last sealed
living ancestor; rev0886 is a nonauthoritative linked construction checkpoint.

## Current physical truth

```text
CANDIDATE/
  protocol/                  value encodings and no-authority parsers
  core_gate/                 one-use entry and fixed-effect relation
  generation_journal/        post-burn pending/result/query relation
  authority/ journal/ ...    inherited hosted proof subjects

EXCAVATION/                  immutable selected premise custody
EVIDENCE/                    retained outputs, never source or authority
TOOLS/                       read-only reconstruction and closure tools
OFFICE/                      current checkpoint state, decisions, obligations
DESIGN/                      current contracts plus historical versions
RESEARCH/                    external observations and explicit speculation
PREDECESSOR/                 one exact linked checkpoint archive
```

Only `CANDIDATE/` may contain prospective product source. Even there, inherited
hosted subjects are not automatically current product. `OFFICE/DOCUMENT-REGISTER.tsv`
defines the current reading and construction surface.

Two current bounded source islands carry the selected proof seam:

- `CANDIDATE/core_gate` models burn-before-validation and emits a consumed
  dispatch receipt; and
- `CANDIDATE/generation_journal` models exact pending identity, one fixed
  generation endpoint, query-only recovery, and immutable result versions.

Both islands must not depend on `OFFICE/`, must not depend on `EVIDENCE/`, must
not depend on `EXCAVATION/`, and must not depend on `PREDECESSOR/`. Those
surfaces can verify or explain candidate source but can never be linked into it.

## Intended product vertical

When owner-ratified work begins, move toward this narrow tree rather than adding
new top-level doctrine families:

```text
product/
  protocol/
    operation_id.hpp
    generation.hpp
    result.hpp
    wire/
  membrane/
    appraisal/
    decision/
    gate/
    handoff/
  endpoint/
    generation_cell/
  result/
    store/
    publication/
  platform/
    capability_provider/     one protected implementation
    stable_storage/          one declared implementation
    rollback_floor/          one external implementation
  service/
    daemon/
  tests/
    relation/
    codec/
    destructive/

lab/
  hosted_models/
  reconstruction/
  acquisition/

vault/
  sealed/                    immutable ancestry and source archives

office/
  constitution/
  decisions/
  obligations/
  release/
```

The important shape is the dependency direction:

```text
protocol <- membrane <- endpoint <- result <- service
                 ^          ^          ^
                 +--- platform premises +

lab -> observes product
vault -> supplies reviewed premises only
product -/-> lab, vault, office, evidence, predecessor
```

## Current component contracts

### Protocol

Protocol types carry exact identities and vocabulary. Parsing them never grants
permission, chooses a route, or declares effect truth.

### Core gate

The gate consumes one presented live capability before validation. It either
rejects/fails stop or emits one already-consumed operation receipt for one fixed
effect. Recovery cannot use the gate to mint a first dispatch.

### Burn-to-journal handoff

The handoff must couple capability consumption to protected operation identity.
A process-local move-only type is only a hosted shape. The required real
primitive is specified in `BURN-TO-JOURNAL-HANDOFF.md`.

### Generation endpoint

The first endpoint is intentionally tiny: compare exact predecessor and, at
most once, install the exact consecutive successor bound to one operation. It
accepts no caller-selected route. Recovery can query exact state but cannot
apply.

### Result service

The result service retains immutable versions. Revision 1 may be uncertainty;
query-only reconciliation may append exact revision 2. Publication is a
separate no-replace append and never creates effect authority.

### Platform premises

Protected capability, authenticated endpoint identity, stable storage,
exclusive writer custody, owner epoch, and rollback floor are supplied by
named platform implementations. Their interfaces must not permit hosted tests
to masquerade as production protection.

## Build graph rule

Every maintained target must belong to one of three explicit classes:

1. `product_*` — owner-ratified source eligible for release;
2. `model_*` — finite/reference semantics with no authority claim; or
3. `lab_*` — acquisition/reconstruction tooling excluded from product linkage.

No target may read `EXCAVATION/`, `OFFICE/`, `EVIDENCE/`, `REVIEW/`, or
`PREDECESSOR/` at runtime or compile time. Exact vault imports, when temporarily
needed for proof comparison, live under a named `vendor/revNNNN/` boundary and
must be removed or owner-adopted before release.

## Anti-waste rules

Reject a proposed addition unless it closes a named vertical obligation. In
particular:

- no new noun family when an existing operation/result type suffices;
- no schema-plus-fixture-plus-checker bundle whose only theorem is prose
  conformance;
- no new evidence intake before a source and relying decision are named;
- no recursive archive copy except the single exact linked predecessor;
- no generated build products in the checkpoint;
- no “capability” type whose nonforgeability depends only on C++ visibility;
- no “durable” claim without reopen after destructive cuts; and
- no “exactly once” claim that lacks operation identity, effect/result atomicity,
  rendezvous, and retention.

## Revision unit

A productive revision should contain one narrow construction and its closure:

```text
one obligation
+ one current contract
+ one implementation seam
+ one independent oracle
+ one retained counterexample
+ one office decision
+ one next authentic experiment
```

Rev0886 follows this unit for generation-journal and result-version semantics.
The next revision should not widen the hosted state space. It should implement
or falsify the protected burn-to-journal identity premise on a named external
machine.
