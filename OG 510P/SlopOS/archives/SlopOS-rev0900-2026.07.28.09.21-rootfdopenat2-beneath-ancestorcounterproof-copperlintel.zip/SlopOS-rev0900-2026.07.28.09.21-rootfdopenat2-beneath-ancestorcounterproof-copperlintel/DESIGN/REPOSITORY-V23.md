# Repository V23 — three islands and one sealed passive airlock

## Judgment

Repository V23 retains exactly three semantic islands:

```text
CANDIDATE/core_gate
CANDIDATE/generation_journal
CANDIDATE/handoff_cell
```

There is no provider SDK, service daemon, downloader, package manager,
registry, retry worker, release manager, queue, database abstraction, or fourth
library. Handoff Cell V11 remains a pure relation inside the existing handoff
island. The Linux admission tool is an operator proof instrument, not a new
semantic island or runtime dependency.

## Handoff strata

```text
V1-V7  local namespace, principal, process, publication, query and claim cuts
V8     one local claim -> at most one hosted provider submit attempt
V9     owner-pinned signed provider-history representation, query-only
V10    exact v3.6.14 transaction/query profile, not operated
V11    one-open, ordered, write-sealed passive release ingress, not activated
```

The strata do not compose into authority. A V11 report cannot enter V7 parsing,
V8 submission, V9 appraisal, or V10 operation. V11 grants no lifecycle or
authority. No synthetic C++ exact-passive row is an actual archive admission.
No database package and no release service exists in the candidate, and no
product target is emitted.

## Source and evidence surface

The handoff package contains 61 package-local files plus 3 exact codec
dependencies, for 64 audited sources. Fresh Clang, GCC, and Clang ASan/UBSan
lanes produce 44 byte-identical canonical products totaling 59,882 bytes per
lane. V11 contributes 17 relation cases, 9 relation countermodels, 12 Linux
descriptor/seal cases, and 6 syscall counterexamples.

The C++ candidate has zero path, tar, memfd, process, socket, extraction,
execution, provider-mutation, retry, response, claim, or settlement entrypoints
arising from V11. Host operations live only in
`TOOLS/admit_etcd_v3614_release.py`, its negative controls, and the standalone
syscall probe.

## Operator boundary

The admission tool resolves one path once, copies the opened regular file into
a sealable memfd, installs the complete write/grow/shrink/seal set, recomputes
the digest from sealed bytes, and only then compares or parses. Inventory and
required-member hashing consume that same object. No release member is
materialized or executed.

The reconstruction tool supports explicit `--resume` of an interrupted external
work directory. It replays configure, bounded one-job build, campaigns and
independent audits before retention. This removes repeated full recompilation
without accepting partial outputs as evidence.

## Anti-waste rule

The old vault remains exact premise and counterexample custody. Spines
cross-index exact paths, sizes and digests without copying vault bytes into
build inputs. Do not create a release service, generic installer, simulated
provider, or fourth island to make an unavailable rung appear complete.

## Next repository change

The next legitimate cut is exact archive acquisition followed by a successful
**passive** receipt from this corrected gate. A separate descriptor-bound,
no-network activation-only gate may follow. Cluster operation and epoch
promotion may not skip either rung. Remain in Epoch Zero.
