# Owner-pinned provider history — signed description, not operated truth

## Decision

Rev0897 adds one narrow V9 grammar to the existing `handoff_cell` island while retaining the V8 hosted settlement theorem unchanged. An externally supplied owner public key and exact SHA-256 digest select one canonical signed provider genesis; the provider key named there verifies one complete signed append observation. The result is query-only evidence. It does not enter endpoint claim, payload parsing, settlement, retry, response, effect, or commit authority.

The construction is intentionally a **description of a proposed provider-history edge**, not a provider. It exists because Epoch Zero repeatedly approached the same category error: a sealed record, peer coordinate, signed response, or exact transcript was almost promoted into the state transition it described.

## Exact relation

```text
OwnerGenesisPin
+ 320-byte canonical owner-signed provider genesis
+ 320-byte canonical provider-signed append observation
+ complete expected history-edge tuple
    -> exact signed observation | fail-closed disposition
```

The complete tuple binds owner and provider epochs, observation serial, generation edge, exact genesis digest, floor identity, predecessor and successor heads, spend record, and pending entry. Verification order is canonical decode, exact digest pin, owner signature, append decode and genesis/floor binding, provider signature, then complete expected-field comparison.

## Why pin and signature are distinct

A signature says that a holder of one key signed one canonical body. It does not select which of several bodies signed by that key is current. The digest pin selects one exact signed representation. The pin is itself a premise: the hosted harness self-selects it, so owner constitution and independent provisioning remain false. Rotation, compromise, loss, retirement, and successor rules are not hidden inside cryptography.

## Why the append remains observation

One provider key can sign two incompatible successors. Exact bytes can replay. Coherent copies can verify independently. An owner key can sign alternate geneses. Those retained countermodels establish that signature validity is not compare-and-commit, exclusive writer custody, non-equivocation, currentness, global one-use, stable media, or settlement.

`ProviderGenesisObservation` is therefore copyable and explicitly carries:

```text
query_only = true
response_authority = false
protected_provider_state = false
globally_unique_spend = false
```

No API accepts it as `ClaimedPending`, `PayloadAfterClaim`, or a settlement request.

## Relation to V8 settlement

V8 proves a client-side ordering theorem under one supplied hosted provider history: consume the fresh local claim before request meaning, submit an exact request at most once, and make reopen exact-query-only. V9 does not strengthen that provider premise. It only makes a candidate owner/provider-history identity statement exact and then proves that the statement still cannot cross into V8.

The composed negative theorem is stronger than either seam alone:

```text
signed history description != operated provider history
hosted one-attempt client != protected settlement
```

## Concrete provider profile suggested by etcd

Official etcd contracts are useful because they expose both a strong transactional relation and the missing custody boundaries. KV operations are durable and strictly serializable when complete; a client may remain uncertain after timeout or network disruption. Default range reads are linearizable, while serializable reads may be stale. Responses expose cluster ID, member ID, revision, and Raft term, but those coordinates do not constitute SlopOS ownership. Snapshot restore overwrites member and cluster IDs and starts a new logical cluster. Revision bump and compaction can prevent revision regression for consumers, but do not prove owner-governed continuity.

Therefore an etcd-backed successor must bind at least:

```text
owner-admitted cluster genesis and exact cluster ID
member set, peer/client trust roots, and provider executable/image
root-role, membership, snapshot, restore, migration, and deletion custody
fixed linearizable Txn and Range semantics
exact keyspace, compare tuple, result tuple, and revision interpretation
restore/failover lineage and new-cluster admission rule
external nonrollback floor and independently provisioned appraiser
```

## Anti-waste rule

Do not add another receipt wrapper, signature envelope, generic key service, registry, retry worker, or fourth semantic island. The next accepted construction must change the operated custody domain. The V9 harness is replaceable scaffolding and a permanent counterproof, not a product architecture.

## Epoch judgment

This is real Epoch-Zero progress: the provider-history premise is exact and its nonauthority is executable. No constituted owner, protected provider, nonrollback currentness, protected effect, or independent reopen has been admitted. Epoch Zero remains truthful.
