# Core-gate to generation-journal refinement

## Scope

`CANDIDATE/core_gate` proves the one-use entry shape and abstract fixed-effect
outcomes. `CANDIDATE/generation_journal` refines the post-entry portion into
pending identity, one invocation, versioned result, immutable publication, and
query-only reconciliation.

Neither package grants real authority. The refinement is a hosted semantic
contract between two independently checked finite relations.

## Mapping

| core-gate fact | generation-journal fact | preserved law |
|---|---|---|
| permit consumed at entry | already-consumed receipt accepted | no validation failure leaves a live permit |
| fixed route/effect | fixed endpoint id and g→g+1 operation | proposer cannot choose a route |
| endpoint effect return | revision-1 `EFFECT` | one effect maximum |
| endpoint no-effect return | revision-1 `NO_EFFECT` | exact predecessor remains |
| nonreturn before/after effect | revision-1 `UNCERTAIN` | local absence does not narrow truth |
| malformed before/after effect | revision-1 `UNCERTAIN` | parser failure is not denial |
| recovery reconcile | exact spent bind plus query only | recovery never applies |
| reconciled predecessor | revision-2 `NO_EFFECT` | exact no-effect closure |
| reconciled same successor | revision-2 `EFFECT` | exact effect closure |
| reconciled other successor | revision-2 `FAIL_STOP` | conflict has no selected winner |
| publish result | append exact result version | publication creates no authority |
| recover-mint/route/retry attempt | explicit rejected event | no hidden dispatch family |

## Interface cut

The abstract interface between the packages is not a plain data struct in the
future product. It is the protected handoff:

```text
CoreGate.consume(capability, operation)
  -> ProtectedSpentIdentity(operation, owner_epoch, capability_generation)

GenerationCell.bind_pending(ProtectedSpentIdentity)
  -> PendingIdentity
```

The hosted `ConsumedDispatchReceipt` is deliberately named a proof shape and
is publicly constructible only through `HostedGateFixture`. That prevents the
source from implying nonforgeability while still allowing boundary tests.

## New counterexample introduced by composition

Core-gate alone can prove that entry burns a permit. Generation-journal alone
can prove that exact pending readback precedes invocation. Composition exposes
a new cut between burn and pending bind. The local journal cannot distinguish
unspent from spent-before-bind after process loss. Thus the two local proofs do
not compose into crash-safe authority without a protected identity premise.

This is not a failure of either local invariant; it is a missing cross-component
refinement obligation. `GJ10` and office obligation `O57` carry it.

## Maintained checks

- exhaustive C++ candidate/reference comparison;
- independent Python reconstruction of the generation relation and codec;
- explicit core-to-generation mapping in `proof/REFINEMENT.tsv`;
- cross-compiler canonical output equality;
- ASan/UBSan execution;
- repository boundary checks excluding vault, office, evidence, and acquisition
  dependencies; and
- retained handoff witness.

## Open proof

A release proof must replace abstract operation receipts with the exact
owner-ratified capability provider and prove source-to-binary identity for both
components. It must also show that endpoint effect, completion record, result
version, publication, and rollback floor satisfy their declared atomic and
stable-media cuts on the named machine.
