# Endpoint claim before parse

## The seam this revision closes

The previous hosted work could create one fixed endpoint-admission row, but the
row still stopped before the endpoint-side authority cut. A careless next step
would inspect request bytes, validate the pending object, or derive a token and
only afterward mark the row consumed. That ordering reopens retry, crash, and
malformed-input ambiguity: a rejected or interrupted request can look unused
although semantic work already began.

Rev0895 makes the smaller ordering law executable inside the existing
`handoff_cell` island:

```text
fixed namespace claim
  precedes object meaning
  precedes proposer payload meaning
  precedes any possible future effect
```

## Narrow construction

The hosted adapter renames fixed `pending` to fixed `claimed` with
`RENAME_NOREPLACE`. Only after success does it open and exactly validate the
claimed record. Only the fresh exact path whose directory `fsync` reports
success creates an internal move-only `ClaimedPending`. A successful rename
followed by failed directory sync remains claimed but query-only. The sole
payload parser accepts the token type as an rvalue and burns it before
inspecting request length or content.

Every returned observation is copyable, query-only, and explicitly carries
`response_authority=false`. Duplicate claim, process reopen, and recovery
observation cannot reconstruct the internal token. Malformed record and
malformed payload remain claimed. There is no reverse rename, repair, retry,
settle, respond, publish, or effect API.

## What the type system contributes

The move-only object prevents accidental ordinary C++ copies inside one
process. Requiring it at the sole parser entry makes preclaim payload parsing
visible to source review. Consuming it before `request_matches` makes malformed
and exact payloads share the same eligibility burn.

That is useful proof scaffolding. It is not external authority. Memory can be
snapshotted, process state can be forked before construction, files can have
aliases and writers, and the whole directory can be cloned or rolled back. The
implementation therefore names the object `ClaimedPending`, not `Permit`,
`Capability`, `Authorization`, or `Spend`.

## Refinement relation

The new code refines one hosted history to four abstract states:

```text
PENDING                = namespace pending, no parser token
CLAIMED_FRESH          = namespace claimed, one process-local parser token
CLAIMED_SYNC_UNCERTAIN = namespace claimed, no token; directory sync failed
CLAIMED_SPENT          = namespace claimed, no parser token
```

The namespace has only two visible states. `CLAIMED_FRESH`,
`CLAIMED_SYNC_UNCERTAIN`, and `CLAIMED_SPENT` differ solely in local control
flow and observations; reopen sees all three as query-only `claimed`. That
asymmetry is intentional. It prevents recovery
from minting first authority, while also showing why durable settlement must be
an external provider relation rather than inferred from local memory.

## Counterproofs govern the interpretation

The campaign retains four stronger-claim defeats:

- a hard link remains an equivalent name for the claimed inode;
- an inherited writable descriptor can alter bytes after claim validation;
- two coherent directory histories each claim once; and
- snapshot restoration makes an old `pending` history current again.

The clone result is decisive: the positive theorem is **one parser entry per
coherent local history**, not one parser entry globally. The writer result is
also decisive: the token captures exact bytes observed after the namespace cut,
not continuing exclusive custody of the inode.

## Crash reading

Four process-death cuts distinguish the fixed ordering:

```text
before claim call                   -> pending / no token
raw rename before validation        -> claimed / reopen query-only
after fresh token before payload    -> claimed / reopen query-only
after payload before reply          -> claimed / reopen query-only
```

These cuts prove that this API does not reenter payload semantics after the
namespace claim. They do not prove stable media, power-loss behavior, or exact
effect settlement. A deterministic `O_PATH` fault also proves that a successful
rename followed by directory-sync error remains
`claimed_exact_sync_uncertain`, mints no parser token, and reopens query-only. It
cannot be called unused and it cannot authorize first semantics.

## Repository judgment

This belongs in `handoff_cell`; it is the next refinement of the already fixed
handoff and endpoint seam. Creating a claim daemon, token server, queue, path
registry, recovery worker, or generic transaction framework would add
horizontal surface without changing custody. Repository V19 therefore remains
exactly three hosted semantic islands.

## Authentic successor

The next vertical must replace the host-selected directory with a constituted
provider operation that owns exact pending-entry genesis, compare/claim,
writer exclusion, rollback resistance, durability classification, compromise,
retirement, and independent appraisal. The protected provider must expose a
fixed claim operation, not return authority-shaped bytes. After claim it must
bind the exact operation to effect/no-effect/uncertain settlement without
recovery minting a first dispatch.

## Rev0896 continuation

V8 consumes the same internal `ClaimedPending` at the settlement entry and
privately retains the canonical pending bytes only long enough to make one exact
provider call. It does not weaken the V7 rule: malformed request meaning still
occurs after consumption and produces zero provider calls; duplicates and
reopen still cannot reconstruct the witness. Settlement recovery is a separate
query-only function with no submission path. See
`HOSTED-CLAIM-SETTLEMENT.md`.
