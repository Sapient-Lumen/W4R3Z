# Repository design v18 — joined-admission fault adapter without a fourth island

**Status:** current rev0894 Epoch-Zero repository direction. It supersedes v17
for active planning. Earlier repository designs remain historical reasoning,
not current source selection.

## Repository purpose

The repository exists to make one bounded authority membrane falsifiable from
untrusted proposal through protected one-use admission, one fixed effect,
honest result, interruption, rollback, and independent reopen. It is not an
operating-system breadth tree, generic orchestration platform, service manager,
database framework, token system, or authority because its hosted tests pass.

The governing mission remains:

> one bounded effect may cross from proposal into power only through a protected
> one-use admission whose exact identity and honest result survive interruption,
> rollback attempts, and independently provisioned appraisal.

Rev0894 corrects one local composition error: an exact floor successor and its
fixed endpoint-admission row now share one hosted transaction, and every
returned response is observation-only. It does not operate the authentic
provider or endpoint.

## Physical truth

```text
CANDIDATE/
  core_gate/              hosted consume-before-parse relation
  generation_journal/     hosted pending/result algebra, exact spend relation,
                           and SQLite joined-admission fault adapter
  handoff_cell/           bounded Linux descriptor/process/endpoint vertical
  ...                     older proof subjects retained, not active product

EXCAVATION/               immutable premise and counterexample custody
EVIDENCE/                 retained observations, never authority or release
OFFICE/                   exact reopen/close continuity and current governance
DESIGN/                   current contracts plus explicit historical versions
RESEARCH/                 primary-source reading and marked speculation
REVIEW/                   construction judgments and source ledger
TOOLS/                    read-only verification, external reconstruction, close
PREDECESSOR/              detached exact immediate-parent receipt only
```

There are exactly three active hosted semantic islands. Rev0894 adds no spend
daemon, database service, token service, process registry, endpoint registry,
generic admission service, publisher daemon, cleanup daemon, launcher, query
service, service manager, or product target.

## Current source boundary

`CANDIDATE/generation_journal` contains 37 transparent source, specification,
proof, and verifier files. Its build reads only that package plus the admitted
host toolchain and system SQLite/Threads libraries. The handoff build retains
29 package files plus three explicit generation-journal codec dependencies, for
32 source inputs. No target compiles, imports, generates, or executes from
`EXCAVATION`, `EVIDENCE`, `OFFICE`, `DESIGN`, `RESEARCH`, `REVIEW`, or
`PREDECESSOR`.

SQLite is an explicit hosted test dependency, not a new semantic island and not
an authority provider. The adapter has no network listener, daemon lifecycle,
repair endpoint, generic SQL abstraction, migration framework, or product API.
Its deletion criterion is explicit: replace it when an owner-admitted provider
refines the same exact classifications under stronger custody and rollback
premises.

## Vault and living project

The vault is immutable premise, ancestry, incident, and counterexample custody.
It is read and digest-bound; it is never current product source, runtime input,
or permission to revive an old subsystem.

The living project is only what constituted owners admit as protocol, policy,
provider, protected state, effect, result, release identity, and compromise
procedure. Exact rev0874 remains the last sealed living lineage. Rev0894 is a
linked, unsealed, nonauthoritative office and proof surface.

The joined-admission custody spine cross-indexes old vault, sealed lineage,
linked design, current candidate, and primary-source research without copying
source bytes into the build. It carries forward the exact laws that response
interpretation consumes attempt identity, recovery does not mint first apply,
rollback floors live outside restorable images, and selector/entry identity
must precede or share the spend transition.

## Selected vertical

```text
owner constitution and floor genesis                 OPEN
constructor/source/binary custody                    OPEN
owner-admitted provider/index identity               OPEN
sealed expected-process shape                        HOSTED OBSERVED
actor-local burn before connect                      HOSTED OBSERVED
canonical content-bound spend record                 HOSTED MODELLED
exact expected-generation+head comparison            HOSTED MODELLED
local floor+fixed-entry transaction                  HOSTED EXECUTED
copyable response is query-only                      HOSTED EXECUTED
local process-crash no-split cuts                     HOSTED EXECUTED
coherent clone/global-spend defeat                    COUNTEREXAMPLE
SCM_RIGHTS one-use defeat                            COUNTEREXAMPLE
external rollback floor and stable media             OPEN
protected fixed endpoint entry/claim                 OPEN
exact pending/result settlement                      HOSTED MODELLED, MEDIA OPEN
retirement, compromise, successor                    OPEN
independent reopen/appraisal                         OPEN
```

The present positive theorem ends at one exact local transaction and one exact
row. It must not be restated as a globally unique spend, protected invocation,
or exactly-once effect.

## Object rule

Keep at least these unlike things unlike:

```text
owner statement
constructor image and process
provider/index identity
floor point and canonical spend record
local database image and external rollback domain
transaction commit and physical stable-media fact
endpoint-admission row and endpoint claim
append/join response and protected authority
queued SCM_RIGHTS message and open file description
file descriptor number and object custody
pending entry, effect attempt, result, settlement, retirement
transport archive and admitted release identity
```

A coherent row is not a protected provider. A transaction is not a global
history. A descriptor reference is not one-use. `already_current` is not retry
permission. Provider death is not settlement. Checkpoint coherence is not
living law.

## Admission rule for new code

A new source family is admitted only when all are true:

1. it closes or falsifies one named P0 obligation in the selected vertical;
2. none of the existing three islands can honestly host the cut;
3. public authority surface, protected state, and deletion criteria are written
   before implementation;
4. at least one executable negative control defeats the strongest tempting
   interpretation;
5. independent code reconstructs canonical outputs;
6. no vault/office/design/research/review/evidence/predecessor path enters build
   or runtime;
7. crash, rollback, duplicate-custodian, prior-outcome, and compromise states
   are named before coding; and
8. success cannot be inferred from a label, scalar, response, pathname, UID,
   PID, fd, database transaction, or process-local move/close operation.

Rev0894 required no new family. The bounded adapter, campaign, verifier, and
specifications fit the generation-journal island.

## Anti-waste rules

Reject:

- a fourth service that wraps the joined function without changing custody;
- a generic database repository or migration layer around one fixed schema;
- a broker whose only “one-use” property is receiving one fd or message;
- `SCM_RIGHTS`, `pidfd_getfd`, move-only C++, or actor-local close called global
  consumption;
- local SQLite atomicity called external rollback resistance;
- `synchronous=FULL`, `fsync`, or green crash tests called physical power-loss
  proof without the VFS/filesystem/device profile;
- a remote database called independent without owner, restore, failover,
  administrative, and stale-clone procedures;
- retries that turn `already_current` or uncertainty into another endpoint
  entry;
- more endpoint/process observation breadth before protected claim/settlement;
- copied vault sources when a digest-bound cross-index is sufficient;
- build outputs, temporary databases, sockets, bytecode, or compiler state
  inside the checkpoint; and
- revision labels, filenames, evidence, or coherent offices promoted to living
  authority.

## Selected next cut

The next construction is an **owner-admitted nonrollback provider with internal
pending-entry custody**, not more SQLite schema or another transport wrapper.
It must name owner/floor genesis, exact provider/index identity, writer binary
and lifecycle, stable-media/backup/restore domain, independent reader, and
compromise/successor rules. Its operation must make the exact floor successor
and actual fixed pending-entry identity one protected transition. The endpoint
must claim or consume that entry before parsing proposer bytes and settle exact
result or bounded uncertainty without returning a replayable authority object.

Mandatory attacks include competing writers, stale expected head, response
loss, coherent cloudtainer rollback, provider backup/restore, provider
replacement, duplicate endpoint claimants, process death before/after effect,
and independently provisioned reopen.

## Epoch stop

Remain in Epoch Zero while authentic owners, protected constructor/writer,
external nonrollback spend, stable media, protected fixed effect, authenticated
result, independent appraisal, source-to-operated-binary custody, compromise
procedure, and admitted release identity remain absent.
