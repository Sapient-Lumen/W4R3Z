# Repository design v15 — one vertical through process-instance evidence

**Status:** current rev0891 Epoch-Zero repository direction. It supersedes v14
for active planning; v4 through v14 remain historical reasoning.

## Repository purpose

The repository exists to make one bounded authority claim falsifiable from
constitution through interruption and independent reopen. It is not a museum of
schemas, an endpoint framework, or a process observability product. Every new
source must tighten the selected vertical, independently check it, preserve a
decisive counterexample, or make the office safer to resume and close.

## Physical truth

```text
CANDIDATE/
  core_gate/              hosted burn-before-validation relation
  generation_journal/     hosted pending/result codec and finite relation
  handoff_cell/           selected Linux vertical:
                           - fixed live -> pending no-replace cut
                           - scoped provider-principal cell
                           - immutable result/publication versions
                           - exact hosted launch descriptor tables
                           - fixed query-only result surface
                           - final-principal staged listener
                           - separate no-replace public-name publication
                           - later fresh query connection and stale collision
                           - hidden peer pidfd, message agreement, death evidence
  ...                     older hosted subjects retained, not active product

EXCAVATION/               immutable premise/counterexample custody and
                           digest-bound zero-copy cross-indexes; never build input
EVIDENCE/                 retained observations; never authority
OFFICE/                   reopen/close continuity and current governance
DESIGN/                   current contracts plus explicit historical versions
RESEARCH/                 primary-source reading and marked speculation
REVIEW/                   judgments and source ledger
TOOLS/                    read-only verification, reconstruction, close
PREDECESSOR/              detached exact immediate-predecessor receipt only
```

Rev0891 adds no `process_registry/`, `endpoint_registry/`, `publisher/`,
`launcher/`, `query_service/`, `recovery_daemon/`, identity framework, or fourth
hosted semantic island. Process-instance evidence remains in `handoff_cell`
because it closes the next observational seam of the same O57→O59 vertical.

## Dependency graph

The selected C++ package may depend only on its own transparent files and the
three retained generation-journal codec files required to encode/decode the
fixed 128-byte record. No target compiles, generates, or runs from `OFFICE`,
`DESIGN`, `RESEARCH`, `REVIEW`, `EXCAVATION`, `EVIDENCE`, or `PREDECESSOR`.

The process-instance/endpoint-epoch custody spine cross-indexes fourteen
existing old-vault, sealed, and linked records totaling 76,106 bytes and copies
zero source bytes. This is the preferred correction for repeated vault
excavation: compress premise into executable law and a retained defeat rather
than duplicating archive prose.

## Active target classes

- `model_*`: executable semantic relation with mandatory nonauthority boundary;
- `lab_*`: reconstruction, fault injection, host observation, or comparison;
- `product_*`: forbidden until owner admission, operated external custody,
  destructive evidence, and release gates exist.

`handoff_cell`, `ProviderEndpoint`, pidfd comparison, and the publisher function
remain model/lab code. Their names and kernel precision do not constitute
product authority.

## Selected vertical

```text
owner/genesis                         OPEN
  -> executable/provider custody      HOSTED PARTIAL, ADMIN OPEN
  -> exact descriptor table           HOSTED OBSERVED
  -> final-principal listener bind     HOSTED OBSERVED
  -> separate public-name publication HOSTED OBSERVED, PUBLISHER OPEN
  -> later query connection            HOSTED OBSERVED
  -> exact peer process reference      HOSTED OBSERVED, OWNER ADMISSION OPEN
  -> per-message process agreement     HOSTED OBSERVED, PRIVILEGED BOUNDARY OPEN
  -> peer death observation            HOSTED OBSERVED, RETIREMENT OPEN
  -> protected one-use admission       LOCAL SHAPE ONLY
  -> fixed endpoint invocation         OPEN
  -> exact pending identity            LOCAL SHAPE ONLY
  -> immutable honest result           LOCAL SHAPE ONLY, MEDIA OPEN
  -> fixed query-only exposure         HOSTED OBSERVED
  -> external rollback floor           OPEN
  -> independent reopen                OPEN
```

The repository may deepen only one arrow at a time. Stable process identity is
not relabeled as an authenticated provider epoch.

## Nine-object rule

Any future endpoint design must distinguish at least:

```text
staging parent
public parent
listener inode/open file description
public pathname
connected socket
numeric principal coordinate
peer process instance
owner-admitted endpoint epoch
publication/retirement receipt
```

Executable/dependency identity and machine/service incarnation must also be
named when the owner-admission edge is attempted. A design that collapses these
into “the endpoint” or “the process” is rejected until mutation, lifetime,
freshness, endorsement, and recovery authorities are separately named.

## Admission rule for new code

A proposed source family is admitted only when all are true:

1. it names one open obligation in the selected vertical;
2. the existing package cannot honestly host the cut;
3. one negative control can falsify its intended claim;
4. an independent checker can read stable canonical products;
5. the code has no vault/evidence/runtime dependency;
6. its authority surface is narrower than the mechanism it wraps; and
7. deletion criteria are written before construction.

Rev0891 meets the rule without a new source family: one existing endpoint object
retains a hidden pidfd, the campaign adds sender/lifetime checks, and the
counterexamples prevent creator identity and replacement detection from becoming
provider admission.

## Anti-waste rules

Reject:

- a new schema or packet when a fixed function suffices;
- a process registry when one hidden comparison handle suffices;
- more PID-shaped observations before an owner-admission constructor exists;
- copied vault prose when a digest-bound cross-index suffices;
- bind-after-drop used as endpoint freshness;
- unlink-before-bind used as restart hygiene;
- a socket pathname, UID, numeric PID, pidfd, or transcript used as provider
  epoch by itself;
- `SO_PEERPIDFD` on a pre-created channel used as current-sender identity;
- process death observation used as endpoint retirement or effect completion;
- replacement detection used as successor authorization;
- a native pidfd exported as generic signal/inspection authority without a
  separately admitted controller;
- ordinary DAC used as root/management-plane closure;
- local immutable names advertised as stable media;
- evidence, receipts, transcripts, or checkers promoted to authority;
- recursive predecessor archives; and
- repository-wide refactors that do not remove an open proof premise.

Prefer one cut, one counterexample, one oracle, one retained evidence set, one
current decision family, and one externally operable next experiment.

## Deletion criteria

The hosted pidfd refinement should be removed or demoted when either:

- an admitted external provider supplies a narrower, inspected endpoint-epoch
  mechanism whose expected process token, retirement, and successor rules are
  independently constituted; or
- the admitted target cannot support the process-reference relation and the
  negative result is retained.

It must not quietly become production process supervision merely because the
local campaign is green.

## Future product admission

`product/provider/*` remains prospective. It requires an owner-ratified epoch,
provider and administration identity, exact source/executable/dependency and
descriptor custody, protected machine/service incarnation, root/mount/snapshot
inventory, constructor/name-publisher/retirement roles, expected process token,
fixed endpoint epoch, compromise procedure, and separately constituted
appraiser. `product/result/*` additionally requires stable media, destructive
cuts, immutable uncertainty/refinement semantics, external rollback
observation, and independent reopen. `product/release/*` requires admitted
source-to-binary identity and governed release authority.

## Epoch judgment

Rev0891 corrects the inference that exact peer-process identity constitutes an
admitted provider. It demonstrates a narrower connection-local pidfd/message
agreement and process-death observation while retaining creator/sender and
replacement/admission defeats. It does not establish the external root of
trust. Exact rev0874 remains the last sealed living lineage; rev0891 remains a
linked laboratory office in Epoch Zero.
