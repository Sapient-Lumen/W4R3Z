# Descriptor-pinned, write-sealed passive release ingress

## Judgment

A release pathname is a locator, not release identity. An opened descriptor
stabilizes which inode is read across namespace replacement, but it does not
make that inode immutable. An unlinked temporary file is likewise anonymous,
not immutable: any already-open writer may still change its bytes after a hash
has been computed. Rev0899 therefore establishes a stricter hosted cut:
**capture once, write-seal the complete captured inode, rehash the sealed bytes,
then compare and parse**.

The inherited rev0898 gate had reopened one supplied path across hash,
inventory, extraction, and execution. The first rev0899 repair removed those
reopens and activation, but its initial anonymous read-write snapshot still
left a time-of-check/time-of-use gap between streaming digest state and later
archive interpretation. That gap is now closed on this Linux host with inode-
wide file seals.

## Exact hosted cut

```text
caller locator
  -> os.open(O_RDONLY|O_CLOEXEC|O_NONBLOCK|O_NOFOLLOW), exactly once
  -> fstat: bounded regular file
  -> memfd_create(MFD_CLOEXEC|MFD_ALLOW_SEALING)
  -> copy complete source with pread/pwrite while computing a streaming digest
  -> require exact byte count and source mutation sentinels
  -> F_ADD_SEALS(F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL)
  -> F_GET_SEALS confirms the complete required set
  -> recompute SHA-256 from the now write-sealed bytes
  -> require streaming digest == sealed digest
  -> compare sealed digest with the system-pinned v3.6.14 digest
  -> parse and inventory only that same sealed memfd
  -> stream-hash etcd, etcdctl and etcdutl from that same sealed memfd
  -> emit a copyable passive report
```

After the first open, the supplied pathname never reenters production
admission. A later rename, unlink, or replacement changes only future pathname
resolution. `O_NOFOLLOW` closes only a final-component symlink and proves no
ancestor-path provenance. Rev0900 adds an optional upstream V12 prefix: the
caller supplies an already-open `O_PATH` directory descriptor, the adapter opens
only the fixed release leaf with the complete `openat2` beneath/no-symlink/no-
magic-link/no-cross-mount policy, and no root pathname is accepted or reopened.
That prefix narrows namespace resolution but does not replace this seal barrier.

## Why sealing precedes the authoritative digest

Descriptor retention fixes object identity, not bytes. Unlinking or changing
mode bits also fails to revoke an already-open writer. The C++20 syscall probe
reproduces both counterexamples. A sealable memfd is populated completely and
then receives `F_SEAL_WRITE`, `F_SEAL_GROW`, `F_SEAL_SHRINK`, and
`F_SEAL_SEAL`. Seals are inode properties, so every descriptor for that memfd
observes the same restrictions; the retained writer and both resize directions
fail with `EPERM`.

The streaming digest computed during copy is a transfer check, not final
release identity. The gate recomputes SHA-256 after the required seals are
installed and compares that sealed digest with both the streaming digest and
the pinned upstream value. Archive semantics are unreachable unless this
ordered prefix is complete.

This remains hosted Linux process custody. A sealed memfd is not durable media,
independent custody, provenance, external rollback protection, or owner
constitution. Existing writable shared mappings must not exist when
`F_SEAL_WRITE` is added; this gate creates none.

## Ordered observations, not a Boolean bag

Handoff Cell V11 treats evidence as an ordered custody prefix. Downstream facts
cannot invent missing prerequisites. A row that claims exact bytes, inventory,
or required-member hashes without an observed locator open, descriptor pin,
regular source, complete snapshot, write seal, and prior digest comparison is
`OBSERVATION_INCOHERENT`, not a partial success.

The pure C++20 relation has 17 cases and 9 countermodels. It includes an
independent wrong-digest/early-parse case, an incoherent-Boolean-bag case, an
unsealed-snapshot rejection, two synthetic activation-boundary violations, and
two exact passive fixtures. `ReleaseIngressAssessment` is a report only; no
claim, settlement, endpoint, or provider API consumes it.

## Passive means no activation

The production gate extracts no member, materializes no executable, runs no
supplied code, opens no network socket, and attempts no provider transaction.
A future activation-only gate must be separate, descriptor-bound, no-network,
credential-fixed, inheritance-closed, time-bounded, and explicitly
nonauthoritative. Activation would still not prove cluster operation, provider
commit, currentness, settlement, or living law.

## Current host result

The exact `etcd-v3.6.14-linux-amd64.tar.gz` archive remains absent from this
cloudtainer. The actual result is therefore `RELEASE_ARCHIVE_MISSING`. Rev0899
proved the sealed byte-custody shape; rev0900 adds the descriptor-rooted locator
prefix. Neither revision claims that upstream archive bytes arrived.

**Remain in Epoch Zero.**
