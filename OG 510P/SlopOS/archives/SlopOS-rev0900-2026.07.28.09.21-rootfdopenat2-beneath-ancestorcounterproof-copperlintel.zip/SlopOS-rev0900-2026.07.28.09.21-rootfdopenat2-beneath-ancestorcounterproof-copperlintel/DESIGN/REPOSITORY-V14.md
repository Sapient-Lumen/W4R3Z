# Repository design v14 — one vertical through endpoint construction and publication

**Status:** current rev0890 Epoch-Zero repository direction. It supersedes v13
for active planning; v4 through v13 remain historical reasoning.

## Repository purpose

The repository exists to make one bounded authority claim falsifiable from
constitution through interruption and independent reopen. It is not a museum of
schemas and not a package collection. Each new source file must tighten the
selected vertical, independently check it, preserve a decisive counterexample,
or make the office safer to resume and close.

## Physical truth

```text
CANDIDATE/
  core_gate/              hosted burn-before-validation relation
  generation_journal/     hosted pending/result codec and finite relation
  handoff_cell/           selected Linux vertical:
                           - fixed live -> pending no-replace cut
                           - scoped provider-principal cell
                           - immutable result/publication versions
                           - exact hosted launch descriptor tables
                           - fixed query-only result surface
                           - final-principal staged listener
                           - separate no-replace public-name publication
                           - later fresh query connection and stale collision
  ...                     older hosted subjects retained, not active product

EXCAVATION/               immutable premise/counterexample custody and
                           digest-bound cross-indexes; never build input
EVIDENCE/                 retained observations; never authority
OFFICE/                   reopen/close continuity and current governance
DESIGN/                   current contracts plus explicit historical versions
RESEARCH/                 primary-source reading and marked speculation
REVIEW/                   judgments and source ledger
TOOLS/                    read-only verification, reconstruction, close
PREDECESSOR/              detached exact immediate-predecessor receipt only
```

Rev0890 adds no `endpoint_registry/`, `publisher/`, `launcher/`,
`query_service/`, `recovery_daemon/`, identity framework, or fifth state
machine. Endpoint construction and publication remain in `handoff_cell` because
they close the next seam of the same O57→O59 vertical.

## Dependency graph

The selected C++ package may depend only on its own transparent files and the
three retained generation-journal codec files required to encode/decode the
fixed 128-byte record. No target compiles, generates, or runs from `OFFICE`,
`DESIGN`, `RESEARCH`, `REVIEW`, `EXCAVATION`, `EVIDENCE`, or `PREDECESSOR`.

The endpoint-publication custody spine is a zero-copy cross-index: sixteen
existing source records are digest-bound in place and zero source bytes are
copied. This remains the preferred correction for repeated vault excavation.

## Active target classes

- `model_*`: executable semantic relation with mandatory nonauthority boundary;
- `lab_*`: reconstruction, fault injection, host observation, or comparison;
- `product_*`: forbidden until owner admission, operated external custody,
  destructive evidence, and release gates exist.

`handoff_cell`, `ProviderEndpoint`, and the publisher function remain model/lab
code. Their names do not constitute product authority.

## Selected vertical

```text
owner/genesis                         OPEN
  -> executable/provider custody      HOSTED PARTIAL, ADMIN OPEN
  -> exact descriptor table           HOSTED OBSERVED
  -> final-principal listener bind     HOSTED OBSERVED
  -> separate public-name publication HOSTED OBSERVED, PUBLISHER OPEN
  -> later query connection            HOSTED OBSERVED
  -> protected one-use admission       LOCAL SHAPE ONLY
  -> fixed endpoint invocation         OPEN
  -> exact pending identity            LOCAL SHAPE ONLY
  -> immutable honest result           LOCAL SHAPE ONLY, MEDIA OPEN
  -> fixed query-only exposure         HOSTED OBSERVED
  -> external rollback floor           OPEN
  -> independent reopen                OPEN
```

The repository may deepen only one arrow at a time. A split ordinary-DAC
relation is not relabeled as an authenticated endpoint epoch.

## Six-object rule

Any future endpoint design must distinguish at least:

```text
staging parent
public parent
listener inode/open file description
public pathname
connected socket
publication/retirement receipt
```

A design that collapses these into “the endpoint” is rejected until its
mutation, lifetime, freshness, and recovery authorities are separately named.
This rule comes directly from the old vault's parent-anchor, handle, receipt,
and namespace-commit record and from the rev0890 live replacement defeat.

## Admission rule for new code

A proposed source family is admitted only when all are true:

1. it names one open obligation in the selected vertical;
2. the existing package cannot honestly host the cut;
3. one negative control can falsify its intended claim;
4. an independent checker can read stable canonical products;
5. the code has no vault/evidence/runtime dependency; and
6. deletion criteria are written before construction.

Rev0890 meets the rule by adding one small endpoint object and campaign to the
existing handoff package. A generic endpoint manager or restart framework would
not.

## Anti-waste rules

Reject:

- a new schema or packet when a fixed function suffices;
- a new hosted actor family before the external provider experiment;
- copied vault prose when a digest-bound cross-index suffices;
- bind-after-drop used as endpoint freshness;
- unlink-before-bind used as restart hygiene;
- a socket pathname used as provider lifetime, identity, or receipt;
- `SO_PEERCRED` used as a stable endpoint epoch token;
- ordinary DAC used as root/management-plane closure;
- a publisher's no-replace operation used as proof the publisher cannot replace;
- stale endpoint cleanup hidden in provider startup or query reconciliation;
- query timeout used as retry permission or no-effect evidence;
- local immutable names advertised as stable media;
- evidence, receipts, transcripts, or checkers promoted to authority;
- recursive predecessor archives; and
- repository-wide refactors that do not remove an open proof premise.

Prefer one cut, one counterexample, one oracle, one retained evidence set, one
current decision, and one externally operable next experiment.

## Deletion criteria

The hosted endpoint-publication code should be removed or demoted when either:

- an admitted external provider supplies a narrower, inspected endpoint-epoch
  mechanism with explicit retirement/recovery authority; or
- the target platform cannot support the required no-replace and custody
  relation and the negative result is retained.

It must not quietly become production infrastructure merely because the local
campaign is green.

## Future product admission

`product/provider/*` remains prospective. It requires an owner-ratified epoch,
provider and administration identity, exact executable and descriptor custody,
root/mount/snapshot inventory, constructor/name-publisher/retirement roles,
fixed endpoint epoch, compromise procedure, and separately constituted
appraiser. `product/result/*` additionally requires stable media, destructive
cuts, immutable uncertainty/refinement semantics, external rollback
observation, and independent reopen. `product/release/*` requires admitted
source-to-binary identity and governed release authority.

## Epoch judgment

Rev0890 corrects the false inference that final-principal bind alone creates a
fresh endpoint. It demonstrates a narrower staged-bind/no-replace-publication
shape and keeps the stale and privileged-publisher paths visible. It does not
establish the external root of trust. Exact rev0874 remains the last sealed
living lineage; rev0890 remains a linked laboratory office in Epoch Zero.
