# Repository design v11 — executable cut, explicit custody gap

**Status:** current Epoch-Zero repository direction for rev0887. It supersedes
`REPOSITORY-V10.md` for active planning; earlier versions remain historical
reasoning, not current law.

## Repository purpose

The repository exists to make one bounded authority claim falsifiable from
source through destructive operation. It is not a museum of every useful
vocabulary found in the vault. The shortest auditable path must run from exact
protocol identity, through one protected admission cut and one fixed effect, to
an immutable queryable result.

Rev0887 is still a linked laboratory office. Exact rev0874 remains the last
sealed living lineage. Nothing under this root is release-authoritative.

## Physical truth in this checkpoint

```text
CANDIDATE/
  core_gate/                 hosted burn-before-validation relation
  generation_journal/        hosted pending/endpoint/result relation and codec
  handoff_cell/              Linux fixed-name no-replace feasibility cell
  protocol/                  inherited value-level parsing and encodings
  ...                        retained older hosted proof subjects

EVIDENCE/                    immutable observations; never source or authority
EXCAVATION/                  exact selected vault premises and counterexamples
OFFICE/                      current linked-office state and resumption protocol
DESIGN/                      current contracts plus explicitly historical design
RESEARCH/                    primary-source observations and marked speculation
TOOLS/                       read-only verifiers, reconstruction, and close tools
PREDECESSOR/                 detached exact receipt and explanation; no ZIP
```

Three bounded source islands describe one seam: `CANDIDATE/core_gate/`,
`CANDIDATE/handoff_cell/`, and `CANDIDATE/generation_journal/`.

```text
core_gate --conceptual spent receipt--> handoff_cell --exact pending bytes-->
                                                           generation_journal
```

This arrow is a refinement obligation, not a compiled product graph.
`handoff_cell` reuses only the generation-journal record codec as a transparent
source dependency. It does not depend on office, evidence, excavation,
research, review, or predecessor content. The hosted adapter still accepts a
caller-selected directory; that is an explicit provider premise, not routing
closure. Old-vault extracts are premise custody only and cannot enter a build.

## Required future layout

Owner-ratified construction should converge on a narrow product tree:

```text
product/
  protocol/                  operation, generation, result, wire identities
  provider/
    cell/                    provider-owned cell choice, staging, writer/alias custody
    endpoint/                one fixed effect endpoint
    result/                  immutable versions and exact query
    rollback_floor/          external monotonic witness client
  service/                   bounded daemon and administration surface
  release/                   admitted source, lockfiles, build and signatures

tests/
  relation/                  finite/reference refinement
  destructive/              power-cut, rollback, conflict and reopen campaigns
  interoperability/         exact query and version retention

lab/
  hosted_models/             core gate, journal, handoff feasibility
  reconstruction/           compiler and oracle campaigns
  acquisition/              native evidence collection

vault/                       immutable ancestry and source archives
office/                      constitution, decisions, obligations and releases
```

Dependency direction is one-way:

```text
protocol <- provider cell <- fixed endpoint <- result service
                     ^                ^              ^
                     +----- declared platform premises -----+

tests/lab -> observe product
vault/office/evidence/review -/-> product
```

## Target classes

Every build target must declare exactly one class:

- `product_*`: owner-admitted source eligible for governed release;
- `model_*`: executable semantics with an explicit no-authority boundary;
- `lab_*`: acquisition, reconstruction, fault injection, or comparison tooling.

A target is rejected if it reads `EXCAVATION/`, `OFFICE/`, `EVIDENCE/`,
`REVIEW/`, `RESEARCH/`, or `PREDECESSOR/` at compile time or runtime. A copied
vault idea becomes current only through a living decision, a new bounded source
implementation, and proof tied to a named obligation.

## Current component contracts

### Core gate

Consume before validation; stop on every failed entry; emit no reusable permit;
recovery never mints first dispatch. Its move-only C++ shape is not protected
nonforgeability.

### Handoff cell

Staged exact identity is inert. Admission attempts one fixed `live -> pending`
`RENAME_NOREPLACE` transition. A successful rename followed by sync failure is
name-bound with durability uncertainty. Query performs no mutation, uses
nonblocking open before type inspection, and retains `pending` on rejection.
The cell does not choose or authenticate its directory, prove the kernel,
close aliases/writers, or establish stable media.

### Generation journal

Accept one exact pending identity, expose one fixed consecutive-generation
endpoint, permit at most one invocation, retain uncertainty honestly, append
exact result refinement without reapplying, and expose query-only recovery. Its
checksum is corruption detection, not authentication.

### Provider premises

The product cell must join provider-owned cell selection, staging, and
writer/alias custody. Exclusive owner epoch, endpoint identity, stable storage,
authenticated and bounded query, rollback floor, and independent reopen must be
supplied by named implementations and tested at real failure boundaries. They
cannot be represented merely by private constructors, pathnames, or comments.

## Anti-waste rules

A revision should add no schema family, packet, board, transcript, or noun unless
it closes a named obligation in the selected vertical. Prefer this unit:

```text
one obligation
+ one executable cut
+ one independent oracle
+ one retained defeat
+ one decision
+ one named authentic next experiment
```

Reject recursively embedded predecessor archives; generated build products;
source manifests that admit bytecode; blocking query surfaces controlled by
staged object type; durability claims without destructive reopen; identity
claims based only on pathnames; and exactly-once language without protected
identity, rendezvous, retention, and an uncertainty state.

## Current revision judgment

Rev0887 is useful Epoch-Zero construction because it replaces an abstract
“transaction” placeholder with one small executable local cut, a fail-closed
query correction, and reproducible counterproofs. It is not a reason to widen
the hosted repository. The next repository change should be a provider-owned
named-machine vertical or a falsification of that design, not a fourth semantic
island.

## Recovery and ancestry boundaries

Storage recovery and protocol reconciliation are separate roles. Candidate
source must not gain effect authority through an engine-repair path.
`PREDECESSOR/` is a transport receipt surface only and is never a source or
runtime dependency. Basic resume remains self-contained; deep lineage is an
explicit digest-checked external operation.
