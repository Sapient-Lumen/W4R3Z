# Hosted transactional join — local floor successor plus fixed endpoint entry

**Status:** rev0894 Epoch-Zero hosted fault-adapter design. This closes one
local split-state bug. It is not a protected provider, global spend floor,
protected endpoint, or living SlopOS authority.

## Why this cut exists

Rev0893 supplied the provider-independent exact compare-and-append relation,
but the host-facing response boundary still permitted a dangerous
interpretation:

```text
accepted `advanced` bytes -> invoke_once
```

Ordinary response bytes are copyable. Replaying one accepted response therefore
reproduced the decision. The defect was not fixed by adding a nonce, signature,
move-only wrapper, descriptor, or “do not replay” instruction. Those mechanisms
can authenticate or narrow access, but they do not make a detached response
nonduplicable.

The smallest useful correction is to remove endpoint authority from the
response and move endpoint admission into the same protected-state transition
as the exact floor successor.

## Hosted state machine

The current adapter stores two relations in one SQLite image:

```text
floor singleton:
  floor_identity, generation_be, head, current_record

endpoint admission:
  spend_head, floor_identity, successor_generation_be, exact_record,
  provider_subject, publication_receipt, expectation_record,
  operation, pending_result
```

A valid request already binds one canonical 352-byte spend record to the exact
predecessor and derived successor. The hosted transition is:

```text
BEGIN IMMEDIATE
  compare complete floor identity + generation + head
  conditionally update exact floor row
  insert one exact fixed endpoint-admission row
COMMIT
re-read complete floor and complete entry bindings
```

A fresh exact request returns `admitted`. An exact duplicate returns
`already_current`. Both responses are query-only and have
`response_authority=false`. Foreign, stale, malformed, unavailable, or identity-
mismatched requests fail closed. No public API accepts a result as a ticket.

## What “joined” means here

Within the exercised local database domain, a clean reopened state cannot
contain the exact target floor without the exact endpoint row when the public
joined transition is used. Four explicit process-death cuts retain:

```text
after BEGIN                    -> predecessor, 0 rows
floor updated, before insert   -> predecessor, 0 rows
entry inserted, before COMMIT  -> predecessor, 0 rows
after COMMIT, before reply     -> target,      1 exact row
```

The first three retries admit the exact request. The last retry observes
`already_current` and remains query-only. Sixteen concurrent exact writers yield
one admission, fifteen exact observations, and one final row. Two foreign-
successor orderings each retain one winner and one conflict.

This is a local transaction theorem for the tested SQLite build, VFS,
filesystem, process-crash cuts, and exact adapter. It is not a physical power-
loss, hardware, remote failover, or global-history theorem.

## Negative controls that define the boundary

### Split floor update and later enqueue

A deliberately unsafe helper commits only the floor update. Reopen reaches the
forbidden state `target + zero entries`. Independent observation classifies it
malformed/uncertain and fails stop. Therefore two separately successful calls
do not implement this join.

### Coherent pre-spend snapshot

The SQLite backup API creates a consistent pre-spend clone. The same exact
request is admitted once in the original and once in the clone. Each local
image is internally exact; the combined governance history has two admissions.
Therefore one local transaction is not an external nonrollback spend floor.

### Descriptor transport

One `SCM_RIGHTS` sequenced-packet message is received twice with `MSG_PEEK` and
once normally. Linux installs three descriptors referring to one open file
description; reads share the offset. Descriptor delivery is therefore
transport/access, not one-use custody. Any later descriptor-based gate must
consume protected state and make all duplicates converge to already-consumed.

## Repository placement

This adapter remains inside `CANDIDATE/generation_journal` because it refines
that island's exact spend, pending identity, and query-only recovery relation.
It does not justify a new database layer, broker, spend daemon, endpoint
registry, token service, or generic persistence service. SQLite is one explicit
hosted dependency of this proof package and has no authority role.

The adapter is deletable when an owner-admitted provider implements the same
observable classifications and stronger rollback/stable-media premises. The
canonical records, boundary cases, crash cuts, clone counterexample, and query-
only response law should survive that replacement.

## Remaining authentic vertical

The next construction must replace the cloudtainer-owned rollback domain with:

```text
owner-admitted floor/provider genesis
+ exact provider/index anti-substitution identity
+ admitted sole-writer or equivalent concurrency closure
+ declared stable-media, backup, restore, migration, and compromise profile
+ floor successor and actual fixed pending entry in one protected operation
+ endpoint-side claim/consume before parsing proposer bytes
+ exact pending/result settlement and bounded uncertainty
+ independently provisioned reopen and appraisal
```

No detached success object, fd, pathname, PID, scalar, database row, or local
lock may stand in for that conjunction.

## Holding

The local split is worth closing now because it makes the future provider
contract smaller and falsifiable. The global claim remains false because the
entire image, writer, executable, and evidence custody are still controlled by
the cloudtainer.

Remain in Epoch Zero.
