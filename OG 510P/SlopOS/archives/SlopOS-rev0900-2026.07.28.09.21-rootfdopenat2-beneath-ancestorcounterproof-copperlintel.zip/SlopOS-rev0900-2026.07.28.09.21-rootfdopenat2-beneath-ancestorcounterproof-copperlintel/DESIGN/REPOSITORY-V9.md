# Repository v9: make the authority spine the dependency spine

The repository should stop mirroring the order in which assurance experiments
were accumulated. The product tree must instead mirror the one authority path
that SlopOS is allowed to execute. Historical custody, laboratory evidence, and
operator state remain first-class, but none may be an implicit dependency of the
product.

## Prospective living layout

```text
product/
  core/gate/                 one-use transition coordinator; no acquisition code
  protocol/
    operation/               canonical inert request and subject identity
    evidence/                provider statement; never an authorization
    appraisal/               separately rooted interpretation
    decision/                relying-party allow/deny and exact scope
    result/                  EFFECT | NO_EFFECT | UNCERTAIN | FAIL_STOP
    publication/             exact terminal-result projection only
  effects/
    generation-journal/      one harmless fixed endpoint and reconciliation API

providers/
  acquisition/               machine-bound evidence acquisition implementations
  appraisal/                 root/policy interpreters, separately provisioned
  result/                    protected result retention and read service
  rollback-floor/            nonrestorable newestness authority

proof/
  model/                     executable relations and independent specifications
  formal/                    replayable theorem projects and environment lock
  campaigns/                 destructive and fault-injection campaign definitions

lab/
  fixtures/                  explicitly synthetic inputs
  harness/                   hosted differential and sanitizer lanes
  observations/              generated, replaceable laboratory products

office/
  constitution/              admitted living decisions only
  state/                     typed gates, obligations, claims, threats, owners
  operations/                resume, close, enroll, release, revoke procedures

vault/
  sealed/                    immutable exact ancestors and source archives
  indexes/                   content-addressed identities and derivation records
  extracts/                  selected reading copies, never package dependencies

releases/
  manifests/                 governed source/binary/proof identities
  attestations/              provider, builder, checker, and owner statements
  revocations/               prospective invalidation records
```

## Dependency law

`product/core/gate` may depend only on typed protocol interfaces and the selected
fixed-effect interface. It must not include or parse raw TPM event logs, block
traces, `/proc` state, compiler logs, vault documents, office ledgers, ZIP
metadata, or laboratory receipts. Those are evidence-provider, operator, or
custody concerns.

The dependency direction is one-way:

```text
provider -> protocol value -> core gate -> fixed effect -> terminal result
                         ^          |
                         |          v
                    relying policy  protected result service
```

A richer evidence source cannot gain more authority merely because it supplies
more bytes. A proof or checker may reject a candidate, but it cannot mint a
permit. Vault material can explain or constrain a design decision, but source in
`product/` may not import from `vault/`.

## Current mapping

`CANDIDATE/core_gate/` is the first precursor to `product/core/gate`. It freezes
the central finite relation and the burn-before-validation law, but its permit is
an ordinary in-process value and its endpoint is simulated. The older
`CANDIDATE/` tree remains a laboratory corpus for evidence, trace, crash, and
process-custody questions. Its rev0883 source manifest deliberately excludes
`core_gate/`; the new subtree has a separate manifest and verifier. Historical
evidence must never be regenerated merely to absorb later source. The older tree
is not to be moved wholesale into `product/`.

`EXCAVATION/AUTHORITY-SPINE/` is the selected premise set from sealed rev0874.
Its files remain byte-exact historical custody; they are not headers or sources
to compile. The new gate restates the needed law through a smaller interface and
records the derivation separately.

## Package admission rule

A package proposed for the future living tree must declare:

1. the authority it can create, consume, observe, or never possess;
2. the exact typed inputs and outputs at its trust boundary;
3. the owner and threat model that choose its policy;
4. the failure and uncertainty behavior at every nonreturn cut;
5. the proof obligations and destructive tests that discharge its claims;
6. the explicit nonclaims that remain outside the package.

A package is rejected when it exists only to preserve an old experiment, when it
combines evidence acquisition with relying policy, or when its output is called a
result without protected retention and exact reconciliation.

## Generated products

Build trees, compiler executables, sanitizer logs, campaign output, and evidence
bundles live outside source and are retained only by an explicit evidence
manifest. The checkpoint may carry selected retained evidence, but reconstruction
must write to an external directory. No generated product may be required to
understand or edit the source tree.

## Migration order

1. Ratify canonical protocol types and the gate relation without promoting the
   hosted implementation.
2. Build one fixed generation-journal endpoint and protected result service.
3. Replace the in-process permit with a nonforgeable one-use capability whose
   consumption is ordered before all entry validation.
4. Connect authentic provider and appraiser lanes on one named external machine.
5. Perform destructive recovery campaigns and independent reconstruction.
6. Only then admit a governed living release layout.

This order is intentionally vertical. Adding a ninth evidence family before
steps 2–4 would increase review and transport cost without crossing an authority
boundary.
