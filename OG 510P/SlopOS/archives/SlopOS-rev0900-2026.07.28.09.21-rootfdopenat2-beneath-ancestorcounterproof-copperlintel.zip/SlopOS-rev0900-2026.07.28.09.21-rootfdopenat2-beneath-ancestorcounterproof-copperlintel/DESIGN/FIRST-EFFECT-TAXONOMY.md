# First-effect taxonomy

The word “effect” must be qualified.

- **Installation effect:** selector, floor, confirmation, or pending-state
  movement. Recovery may reconcile these when exact representations permit.
- **Selected protected effect:** the operation for which first-dispatch
  authority exists. Recovery cannot create this.
- **Observation effect:** creation of evidence or a local marker that an effect
  happened. It does not itself prove the selected effect.
- **Publication effect:** immutable release of a terminal appraisal. It is later
  than completion and must not overwrite a different incumbent.
- **Compensation effect:** a separately authorized operation after an uncertain
  or failed transaction. It is never implicit rollback.

Rev0879's harmless selected effect is an ordinary file fixture. The taxonomy is
more durable than that implementation.
