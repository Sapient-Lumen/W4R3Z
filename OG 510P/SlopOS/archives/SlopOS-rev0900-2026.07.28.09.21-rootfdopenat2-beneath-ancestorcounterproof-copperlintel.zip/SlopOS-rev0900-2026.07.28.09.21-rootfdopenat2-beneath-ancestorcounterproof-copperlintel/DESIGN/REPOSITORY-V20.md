# Repository V20 — three islands, settlement remains package-local

## Decision

Repository V20 retains exactly three hosted semantic islands:

```text
CANDIDATE/core_gate
CANDIDATE/generation_journal
CANDIDATE/handoff_cell
```

Rev0896 extends only `handoff_cell`. No product target and no fourth semantic
island is added.

## Responsibilities

`core_gate` owns abstract burn-before-validation and one bounded effect.
`generation_journal` owns exact pending/result identity, immutable refinement,
content-bound compare-and-append, and the hosted local floor/entry join.
`handoff_cell` owns fixed namespace admission, scoped principal experiments,
launch descriptor topology, fixed result query, staged endpoint publication,
process/message observations, sealed expected-process consumption, V7 local
claim-before-parse, and now V8 one-attempt hosted settlement with query-only
recovery.

The handoff package contains **41 package files** and reuses exactly three
`generation_journal` codec sources as source dependencies. The six V8 files are
package-local:

```text
include/slopos/e0/handoff_cell/hosted_settlement.hpp
src/hosted_settlement.cpp
harness/settlement_campaign.hpp
harness/settlement_campaign.cpp
proof/verify_settlement.py
spec/HANDOFF-CELL-V8.md
```

`endpoint_claim.hpp` and `endpoint_claim.cpp` are refined only enough to let the
settlement class privately retain the consumed canonical pending bytes. No
public token or provider credential is added.

## Anti-islands

The repository still contains no:

```text
settlement daemon
retry worker
compensation worker
spend daemon
token or claim service
endpoint or process registry
generic admission or persistence layer
cloud-provider SDK wrapper
launcher, query, publisher, or cleanup service
policy language
product executable
```

`HostedSettlementProvider` is an abstract harness premise inside one package,
not a separately deployed service and not an admitted architecture boundary.

## Why a provider interface is not a provider product

The two-method interface makes the missing relation executable:
`submit_exact` and `query_exact`. It deliberately omits configuration, endpoint
selection, credentials, resource creation, retries, timeouts, failover,
serialization frameworks, generic transactions, and lifecycle management.
Adding those before owner/provider custody is selected would turn an unknown
premise into accidental architecture and increase deletion cost.

## Delete-or-replace rule

The hosted settlement adapter is replaceable scaffolding. An authentic
owner-admitted provider must subsume its exact one-attempt and query-only laws
while adding protected provider identity, exclusive writer/administrator
custody, lifetime duplicate retention, rollback/restore continuity, stable
media, exact effect binding, and independent appraisal. After that, the fake
provider and local directory adapter remain only as negative-control harnesses
or are removed.

## Dependency boundary

Candidate build inputs remain limited to the three hosted packages and declared
host toolchain/libraries. Evidence, excavation, research, office, review,
predecessor, and old-vault bytes are never build inputs. Old sources enter only
through exact path/size/digest cross-indexes and bounded current judgments.

## Current judgment

Repository V20 is coherent but unsealed and nonauthoritative. It implements a
hosted settlement seam, not protected settlement. It proves no global spend,
stable endpoint epoch, provider provenance, rollback resistance, durable
result, independent reopen, or living architecture. **Remain in Epoch Zero.**
