# Content-bound spend floor — provider-independent cut

**Status:** current rev0894 Epoch-Zero hosted design. The exact compare-and-
append relation remains provider-independent. Rev0894 corrects its detached
response meaning and composes it with one local joined-admission fault adapter.
No provider is selected, authenticated, or operated.

## The question

Can every contender and later reopener learn, from protected state outside the
restorable candidate image, whether one exact expectation spend is unused, won
by this exact successor, won by a foreign successor, consumed by one endpoint,
or unknowable?

A scalar monotonic number cannot answer the exact-identity part. A detached
success response cannot answer the one-use part. A transaction inside one
restorable image cannot answer the global-history part. The complete contract
must bind content, order, provider custody, pending-entry identity, consumption,
and settlement.

## Minimal floor point

```text
FloorPoint := (floor_identity, generation, head)
```

`floor_identity` names the provider/index/line. `generation` orders successors.
`head` identifies the exact accumulated state. All three are compared. The head
is never inferred from the scalar generation.

A proposed successor is one canonical 352-byte `SLOPSP01` record binding owner
statement, constructor image/epoch, spend serial, exact predecessor generation
and head, provider subject, publication receipt, expectation record, bounded
operation, and pending-result identity. Its canonical digest derives the target
head. Integrity hashing freezes the hosted grammar; it does not authenticate
the writer.

## Provider-independent relation

```text
compare_and_append(
  exact floor identity,
  expected=(generation, head),
  canonical successor record,
  target=(generation+1, derived successor head)
)
```

The relation classifies `advanced`, exact `already_current`, `conflict`,
`unavailable`, `malformed`, or `identity_mismatch`. Blind increment is not
expected-head comparison. Blind extend accumulates content but does not reject a
stale expected head. A provider built from weaker primitives must prove its
protected writer, serialization, crash recovery, and lifecycle.

The local generation journal forms a request only from exact `fresh` or exact
`prepared` state. Exact already-current is query-only. Foreign successor,
scalar-only observation, unavailable floor, identity mismatch, local-ahead
state, or generation jump fails closed.

## Rev0894 response correction

Every detached response is now observation-only:

```text
advanced/query result:
  query_only = true
  response_authority = false

already_current/query result:
  query_only = true
  response_authority = false
```

The sixteen-contender spend race still has one storage winner and fifteen exact
already-current observations, but all sixteen results are query-only. Copying
the accepted response creates zero invoke decisions. No public API accepts a
returned result as a dispatch ticket.

This supersedes the rev0893 hosted interpretation that named the sole
`advanced` response `invoke_once`. The rev0893 replay counterexample remains
historical evidence of why that interpretation was wrong.

## Local joined-admission refinement

`DESIGN/HOSTED-TRANSACTIONAL-JOIN.md` composes the exact relation with one fixed
endpoint-admission projection inside a package-local SQLite transaction:

```text
BEGIN IMMEDIATE
  compare exact predecessor
  update exact floor to canonical successor
  insert exact fixed pending-entry row
COMMIT
read back complete floor and entry
```

Across four exercised process-crash cuts, clean reopen is predecessor with zero
entry or target with one exact entry. Sixteen exact writers converge to one
entry. A deliberately split floor-only commit reaches target with zero entry
and fails closed.

This closes a local append/enqueue split. It does not make the database a
protected provider or make the entry globally unique.

## Counterproofs that govern provider selection

A coherent pre-spend SQLite backup is submitted in two images; both admit the
same exact request. Therefore one local all-or-none transaction is not an
external rollback floor.

One queued `SCM_RIGHTS` message is received twice with `MSG_PEEK` and once
normally; three descriptor aliases are installed. Therefore an fd cannot be
promoted to one-use endpoint authority. The endpoint must consume protected
entry state and make duplicate aliases converge to already-consumed/query-only.

## Provider-selection gate

No TPM, database, filesystem, cloud service, or consensus system is selected as
a provider until the office can name and attack:

- constituted owner and floor/provider genesis;
- exact provider/index identity and anti-substitution binding;
- admitted writer executable, process, and dependency closure;
- sole-writer or equivalent concurrency theorem;
- stable-media and destructive power-loss profile;
- backup, restore, snapshot, migration, and rollback domain;
- one protected successor plus fixed pending-entry operation;
- endpoint-side claim/consume before parsing proposer detail;
- exact pending/result settlement and uncertainty behavior;
- independent reader/appraiser roots; and
- compromise, rotation, retirement, and successor procedure.

A local SQLite implementation is a useful fault adapter. A remote SQL service
is not independent by name. A TPM counter or extend index is useful only behind
an exact protected writer and content-bound compare relation. A signed response
is evidence, not one-use permission.

## Nonclaims

Rev0894 does not prove owner constitution, authentic constructor, protected
provider, exclusive writer, durable global spend, stable media, physical power
loss, external rollback resistance, protected endpoint claim, exactly-once
effect, authenticated result, independent reopen, or release authority. It
remains Epoch Zero.
