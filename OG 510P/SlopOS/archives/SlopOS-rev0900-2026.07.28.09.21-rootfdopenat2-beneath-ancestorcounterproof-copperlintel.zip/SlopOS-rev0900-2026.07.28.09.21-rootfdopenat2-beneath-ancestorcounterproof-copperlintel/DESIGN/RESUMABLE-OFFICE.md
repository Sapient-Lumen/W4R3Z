# Resumable office

A resumable checkpoint must let a new actor distinguish four things without
conversation context:

1. exact linked ancestry and sealed lineage;
2. current candidate claims and mandatory nonclaims;
3. retained evidence versus work that must be reconstructed;
4. completed stages versus interrupted or unavailable stages.

Rev0880 uses:

- one exact read order;
- typed gate, obligation, claim and closure tables;
- a mode-preserving bootstrap extractor;
- basic, retained-evidence and restartable compiler lanes;
- an idempotent direct lineage walker;
- deterministic manifest generation and ZIP closure;
- explicit `INCOMPLETE` handling for partial stages;
- source-separated crash-image reconstruction.

No script can set `seal_pass`, mutate living law, constitute owners or advance
an epoch. Those are governance transitions, not successful command exits.
