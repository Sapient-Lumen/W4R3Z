# Process instance and endpoint epoch — observation through expectation

## Problem

A socket pathname, UID/GID, numeric PID, executable path, live pidfd, and
owner-admitted provider epoch answer different questions. Rev0891 established
that a fresh connection can retain the exact peer process and that each message
sender can be checked against it. It also proved that exact replacement
detection does not identify an authorized successor.

Rev0892 asks the next narrower question: can the query receive an expected
process before connect and require the fixed endpoint to resolve to it without
pretending that the expectation is already owner admission?

## Coordinates

```text
Cnum   numeric UID/GID/PID observations
Pexp   process named by externally supplied sealed record + pidfd
Pconn  process named by fresh connection's hidden SO_PEERPIDFD
Pmsg   process named by automatic SCM_PIDFD on one message
X      governed executable/dependency identity
Eowner owner-admitted machine/service/provider incarnation
Npub   listener object currently selected by public pathname
S      globally unique durable expectation spend
```

V6 establishes `Pexp == Pconn == Pmsg` for the accepted hosted path. It does not
establish `X`, `Eowner`, an authorized `Npub`, or `S`.

## External expectation boundary

The expected process arrives before the data transport as two descriptors:

- one exact sealed 96-byte record addressed to the query principal; and
- one pidfd whose pidfs device/inode equals the record.

The query validates both after entering its final principal. This avoids the
circular inference “the endpoint told me which endpoint to trust.” The record's
opaque owner-binding field is retained for shape stability but intentionally has
no accepted semantics until a protected owner constructor exists.

## Spend-before-connect order

The actor copies neutral scalar observations, closes the record descriptor,
closes the supplied pidfd, marks the wrapper consumed, and only then creates the
query socket. The new connection's hidden peer pidfd is compared with `Pexp`.
Mismatch destroys the connection before any request or ancillary right flows.
Each later message must separately supply `Pmsg == Pconn` before bytes.

This order prevents the query actor from retaining native admission inputs while
holding the effect channel. It does not prevent another process or descriptor
slot from retaining copies.

## Countermodels

### Immutable self-assertion

Root can mint canonical bytes, insert the actual provider process, seal the
memfd, and transfer both descriptors. The relation succeeds. Therefore
immutability and process equality are not provenance or owner admission.

### Duplicated custody

Root duplicates both descriptors before transfer. Closing the query's pair does
not close the duplicate pair because descriptor slots and underlying kernel
objects differ. Therefore move-only wrapper lifetime is not a globally unique
spend.

### Same path and principal, different process

Privileged retirement and republish can leave path, UID, GID, protocol, and
application behavior unchanged while `Pconn` changes. Process comparison detects
the change. It does not decide whether the new process is an authorized
successor.

### Creator versus sender

A channel created before fork may have a connect-time peer associated with the
creator while a later message is sent by the child. Per-message pidfd agreement
is required for the intended post-entry connection relation.

## Host scope

On the admitted 64-bit Linux profile, pidfs device/inode equality is used only
as a same-process comparison for live pidfds. It is not a portable identity
across kernels, PID namespaces, hosts, reboot, archival reopen, or future pidfd
implementations. The native pidfds remain private and are never treated as
persistent owner tokens.

## Endpoint-epoch requirement still open

A real endpoint epoch needs an independently retained chain binding:

```text
owner genesis
-> governed constructor executable and inputs
-> exact provider process and executable/dependencies
-> machine/service incarnation
-> public publication receipt
-> query principal and allowed effect
-> globally unique durable spend
-> retirement decision
-> separately authorized successor
```

Rev0892 supplies only a host-local process discriminator inside that future
chain. Epoch Zero remains correct.
