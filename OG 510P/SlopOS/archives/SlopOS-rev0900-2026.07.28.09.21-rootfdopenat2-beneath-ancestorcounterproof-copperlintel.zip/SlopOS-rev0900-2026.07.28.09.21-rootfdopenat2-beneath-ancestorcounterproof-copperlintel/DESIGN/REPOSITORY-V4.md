# Repository v4 status

This projection is superseded by `REPOSITORY-V5.md`. V5 adds an explicit split
between logical crash semantics, privileged block-trace acquisition and
physical power-loss campaigns, and gives protected endpoint-result custody a
first-class provider boundary.

The constitutional dependency remains unchanged: the minimal core consumes
typed appraisals and protected capabilities; it does not ingest raw evidence or
laboratory artifacts.
