# Provider bind and endpoint publication

**Status:** rev0890 hosted Epoch-Zero design and counterproof. This is a Linux
pathname-socket custody experiment, not an authenticated provider, durable
endpoint registry, restart protocol, or authority grant.

## The corrected question

Rev0889 left a plausible but false next step: let the provider enter its final
UID and then bind its public pathname. That does improve the credential
coordinate, but it does not establish a fresh provider epoch. If the same
principal can mutate the endpoint's parent directory, a later same-UID process
can unlink a live or stale pathname and bind a different socket at the same
name. “Bound after dropping privilege” is therefore not “name is bound to this
provider epoch.”

Rev0890 asks a narrower question:

```text
Can the final-principal provider create the listener while a different
custodian alone publishes the public name with a no-replace operation, and can
a later query actor connect without inheriting the data socket?
```

The hosted answer is yes on the recorded Linux/ext4 host. The stronger endpoint
epoch and administration claims remain false.

## Actors and objects

Let:

- `P` be the provider process after final UID/GID entry;
- `N` be the public-name publisher;
- `Q` be the later query process;
- `A` be the still-dominant root-equivalent administrator;
- `Ds` be a provider-owned mode-0700 staging directory;
- `Dp` be a publisher-owned mode-0711 public directory;
- `L` be the bound/listening socket inode;
- `ns = Ds/bound.sock` be the fixed staged name;
- `np = Dp/query.sock` be the fixed public name;
- `Cq` and `Cp` be the query/provider ends of a connected socket; and
- `Rpub` be the canonical observation that no-replace publication completed.

These objects are not interchangeable. In particular:

```text
L != ns != np != Cq != Cp != Rpub
```

A pathname names the socket object for lookup; it is not the lifetime of the
listening file description, a provider identity, a connection, or a durable
receipt.

## Authority table

| Authority | P | N | Q | A |
|---|---:|---:|---:|---:|
| bind fixed `Ds/bound.sock` | yes | no | no | can override |
| retain/use listener `L` | yes | no | no | can interfere |
| mutate `Ds` | scoped yes | no | no | yes |
| publish `ns -> np` no-replace | no | yes | no | yes |
| unlink/replace `np` | denied by ordinary DAC | yes if explicitly exercised | no | yes |
| connect to fixed `np` | no need | no | yes | yes |
| choose path/route/version/retry | no | no | no | yes outside candidate |
| prove provider epoch freshness | no | no | no | no |

The table is deliberately asymmetric. `P` owns socket construction but not the
public parent. `N` owns the one publication transition but remains a dangerous
administrative premise. `Q` owns only a fresh connection attempt. The candidate
contains no automatic cleanup transition.

## State machine

The bounded namespace state is:

```text
ABSENT
  P.bind_fixed_stage
    -> STAGED(L at ns)
  N.renameat2(RENAME_NOREPLACE)
    -> PUBLISHED(L at np, ns absent)
  Q.connect + P.accept
    -> CONNECTED(L at np, Cq/Cp live)
  provider/listener death
    -> STALE(np still names socket inode, connect fails)
```

A fresh provider may create `STAGED(L2)` while `STALE(np=L1)` remains. The only
candidate publication result is then `EEXIST`; both names remain and the system
fails stop. There is no transition from `STALE` to `ABSENT` or `PUBLISHED(L2)`
inside provider bind, query, or protocol reconciliation.

The root publisher counterexample can explicitly perform:

```text
STALE(L1) --unlink(np)--> ABSENT --publish(L2)--> PUBLISHED(L2)
```

That path is retained as a defeat, not normalized as restart hygiene.

## Invariants exercised

1. `P` binds only after exact final hosted credentials, empty groups/capability
   sets, `no_new_privs`, and exact prebind descriptor census.
2. `P` binds only fixed `bound.sock`, never unlinks before bind, and accepts no
   caller-selected leaf.
3. `N` publishes only fixed `bound.sock -> query.sock` with
   `renameat2(..., RENAME_NOREPLACE)` and verifies that the device/inode moved
   unchanged.
4. `P` lacks ordinary-DAC mutation authority over `Dp` after publication.
5. `Q` is exec-entered with no inherited data socket, creates its own socket,
   and connects only after publication.
6. Connected/accepted `SO_PEERCRED` coordinates and per-message
   `SCM_CREDENTIALS` agree in the hosted run.
7. `SCM_RIGHTS`, malformed control, malformed bytes, and wrong-UID connections
   still fail closed before result interpretation.
8. Provider death leaves a stale name; connection fails and no-replace restart
   remains blocked until a separately authorized judgment occurs.

## Three counterproofs that govern reuse

### Final-principal bind is not endpoint freshness

When the public parent is writable by the provider UID, a same-UID process can
unlink a still-live pathname and bind a different socket at the same leaf. The
old listener remains alive through its descriptor, while future path lookups
reach the replacement. Final credentials alone do not bind name to epoch.

### Stale cleanup is administration, not hygiene

A dead listener can leave the pathname behind. Automatically unlinking it
before every bind destroys evidence and grants the restart path authority to
select a new endpoint epoch. Collision must fail stop; cleanup requires an
explicitly governed recovery role and freshness decision.

### Split custody does not close the publisher

The root-equivalent publisher can unlink and republish. Ordinary DAC prevents
`P` from doing so, but does not constrain `A`, mount/snapshot replacement,
ptrace/signal/lifecycle control, or management-plane substitution. The hosted
publisher is a premise, not a protected registry.

## Linux-specific premise

The construction relies on the recorded Linux behavior and contracts for
pathname Unix sockets, directory permissions, `renameat2(RENAME_NOREPLACE)`,
accepted/connect-time credentials, and the survival of a listening socket
across a same-filesystem pathname rename. The implementation reaches fixed
leaves through `/proc/self/fd/<dirfd>/...` and cross-checks that the procfs path
still names the supplied directory descriptor. This is a host-specific
technique, not a portability or source-to-binary theorem.

The current `unix(7)` wording is clearest for connected stream sockets and some
socket-pair cases; the retained host also returned the expected `SO_PEERCRED`
values for connected `SOCK_SEQPACKET`. Rev0890 records that as an observation,
not a portable guarantee.

## Nonclaims

Rev0890 does not establish:

- a stable or cryptographically bound endpoint epoch;
- provider executable, owner, machine, mount, or service identity;
- publisher/recovery/admin closure;
- resistance to root-equivalent replacement or privileged credential forgery;
- durable publication or survival across physical power loss;
- a freshness oracle for stale endpoint cleanup;
- an independently rooted query actor;
- source-to-operated-binary admission; or
- Epoch-Zero completion.

## Next external experiment

The next provider experiment must name three authorities separately before any
restart is attempted:

1. **constructor** — admits and launches the provider and its exact resources;
2. **name/epoch publisher** — binds one public endpoint to one admitted provider
   epoch without provider mutation authority; and
3. **retirement/recovery authority** — decides, from independently retained
   evidence, when a stale endpoint may be retired and what successor epoch may
   be published.

Those roles may be implemented by one operated system only if their combined
power is explicit, governed, attacked, and externally witnessed. Hiding all
three in “bind after drop” would repeat the old vault's most expensive error:
compressing distinct authorities into one persuasive name.
