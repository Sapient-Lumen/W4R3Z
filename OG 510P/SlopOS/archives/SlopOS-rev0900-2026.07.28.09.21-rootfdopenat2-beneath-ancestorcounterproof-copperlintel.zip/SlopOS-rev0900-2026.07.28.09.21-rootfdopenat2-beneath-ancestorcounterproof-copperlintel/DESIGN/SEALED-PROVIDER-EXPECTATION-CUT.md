# Sealed provider expectation cut

**Status:** current rev0892 Epoch-Zero design and counterproof.

## The narrow construction

The handoff vertical now receives one fixed 96-byte sealed record and one pidfd
at exact post-exec descriptors 7 and 8. The query validates the pair, closes
both descriptors before creating its AF_UNIX socket, then requires the
connection's `SO_PEERPIDFD` identity to equal the consumed expectation before
sending request bytes.

The change is intentionally smaller than “provider admission.” It introduces a
place where a future independent owner constructor can speak without allowing
the query, endpoint, or payload to nominate its own expected provider.

## Proof coordinates

Keep these values separate:

```text
R  = immutable expectation record
D  = supplied pidfd
P  = process instance named by D and R
C  = process reached by the fresh connection
B  = opaque owner-binding bytes inside R
A  = owner admission and constructor provenance
S  = globally durable spend state
```

Rev0892 establishes:

```text
sealed(R)
identity(D) = process(R) = P
burn_actor_copy(R,D) precedes connect
identity(C) = P precedes request bytes
```

It does not establish:

```text
B authenticates A
A authorized P
no duplicate of R or D exists
a durable S records one global spend
P binds admitted executable/dependencies/machine/service epoch
```

## Why the record is fixed now

The byte shape separates mechanism from future governance. Principals and
process identity are parseable now. The 32-byte binding is opaque so no hosted
code gets to invent a signature format, root namespace, or trust policy. Exact
reserved bytes make later extensions versioned instead of ambient.

The seals are exact rather than minimum. An unexpected extra seal is rejected
so the admitted evidence describes one reviewed object state. The record is
unlinked and exact-sized. Neither property establishes provenance.

## Why burn precedes connect

A pidfd can carry signal, namespace, `pidfd_getfd`, advice, wait, and other
process-facing surfaces depending on caller privilege and kernel API. The query
needs only a comparison fact. Closing the supplied pidfd before socket creation
minimizes the period in which observation and control share one descriptor.

The connection retains its own hidden peer pidfd because V5 still requires
message-time `SCM_PIDFD` agreement and bounded exit observation. That descriptor
never escapes the scoped `EndpointConnection` API.

## Countermodel 1 — root-minted truth

Root launches P, observes P, writes “P” into R, seals R, and sends R+D. Every
local check succeeds. The system has proved internal consistency of root's
statement, not owner ratification. The positive run is therefore also a
negative control for provenance.

## Countermodel 2 — duplicated custody

Before sending R+D, root duplicates both descriptors. The query burns its pair;
root retains the duplicates. File seals are inode-wide and descriptor
duplication preserves the same open objects. Move-only language semantics
prevent accidental copies inside one API expression, not kernel-level copies
before adoption.

## Severe waste avoided

The wrong response would be a process registry, endpoint registry, general
identity document, local CA, daemon, or retry service around the same
root-minted fact. Such breadth would make the self-assertion more elaborate
without changing its owner. The next implementation should instead protect one
constructor and one spend relation.

## Next exact cut

Build a constructor boundary that cannot be invoked by the query or publisher
and cannot merely copy their assertions. It should:

1. receive one constituted owner decision and fixed provider image identity;
2. create or adopt one exact process through a separately controlled launch
   path;
3. bind the process to machine/service incarnation and publication receipt;
4. issue one expectation addressed to one query/effect identity;
5. commit a durable spend-before-effect record that duplicates cannot replay;
6. expose only comparison and exact result query to the appraiser; and
7. survive independent reopen with the hosted root unavailable.

A falsification at any of those steps is more valuable than another local
identity feature.
