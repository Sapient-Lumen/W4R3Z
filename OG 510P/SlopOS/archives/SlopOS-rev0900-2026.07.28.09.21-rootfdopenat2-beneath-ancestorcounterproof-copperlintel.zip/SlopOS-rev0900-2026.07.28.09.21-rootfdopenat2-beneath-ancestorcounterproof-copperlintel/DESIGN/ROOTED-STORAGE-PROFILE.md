# Rooted storage profile

Rev0879 defines a Linux-hosted profile rather than a portable storage API.

The profile captures an absolute root with all-component symlink and magic-link
rejection, then opens and retains six fixed child directory descriptors beneath
that root. All subsequent names are validated single components and all I/O is
relative to a retained child descriptor.

The profile requires:

- private root and child directory modes;
- same-device fixed children;
- regular `0600` data files;
- bounded exact reads with before/after identity and size checks;
- exclusive temporary creation;
- file synchronization before rename;
- containing-directory synchronization after rename or unlink;
- exact readback;
- no-replace immutable publication;
- exact incumbent acceptance and wrong-incumbent refusal.

The profile does not claim protection from stronger mount-namespace actors,
concurrent holders of the same descriptors/directories, kernel defects, or
unsupported filesystem semantics.
