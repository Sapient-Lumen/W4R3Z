# Repository V22 — three islands and one exact non-operational provider gate

## Judgment

Repository V22 retains exactly three semantic islands:

```text
CANDIDATE/core_gate
CANDIDATE/generation_journal
CANDIDATE/handoff_cell
```

No etcd package, provider SDK, fourth library, daemon, registry, queue, retry
worker, or generic storage abstraction is added. The V10 etcd profile seam is
inside `handoff_cell` because it classifies evidence at the existing handoff/
settlement boundary and has no independent authority or lifecycle.

## Handoff-cell strata

```text
V1-V7  local no-replace, principal/process/publication/query/claim proofwork
V8     one local claim -> at most one hosted provider submission attempt
V9     owner-pinned signed provider-history representation, query-only
V10    exact v3.6.14 release/transaction profile and dossier classifier,
       explicitly not operated
```

V8, V9 and V10 remain noncomposable in authority terms. V8 cannot accept a V9
or V10 observation as settlement. V9 cannot claim provider execution. V10
cannot submit its rendered plan or enter endpoint parsing.

## Build boundary

CMake builds one C++20 static candidate and one deterministic harness. V10 adds:

```text
include/.../etcd_history_profile.hpp
src/etcd_history_profile.cpp
harness/etcd_history_profile_campaign.{hpp,cpp}
proof/verify_etcd_history_profile.py
spec/HANDOFF-CELL-V10.md
```

The candidate surface has zero socket, process, file, TLS, gRPC, etcdctl,
provider-mutation, retry, response, endpoint-parser or settlement entrypoints
from V10 types.

## Evidence boundary

Three fresh lanes—Clang, GCC and Clang ASan/UBSan—must agree byte-for-byte on 36
canonical products. V10 contributes nineteen classifier cases, seven
counterexamples, one deterministic plan, one summary and one independent audit.
Only one case is an actual host observation and it reports runtime unavailable;
the other eighteen are explicitly synthetic.

Release acquisition evidence lives under:

```text
EVIDENCE/REV0898/ETCD-PROFILE
```

It retains the official checksum product, a fail-closed missing-archive receipt,
self-tests and the acquisition boundary. It is evidence, not a runtime input.

## Vault and dependency rule

The vault and excavation remain immutable premise/counterexample custody. The
provider-history custody spine cross-indexes exact sources by path, byte count
and digest without copying them into a new subsystem. No vault, research,
review, evidence, office or donor path is a candidate build dependency.

## Next repository change

Do not increment the repository shape for more grammar. The next meaningful
change is an operated-profile evidence fixture outside the candidate source tree
that supplies exact admitted binaries, fixed configuration, roots, transaction
and query dossiers to the existing V10 classifier. It must not create a fourth
semantic island.

## Exact inventory

```text
core gate package files: 11
generation journal package files: 37
handoff cell package files: 53
inherited generation codec dependencies: 3
handoff audited source files: 56
canonical products per lane: 36
canonical bytes per lane: 50,122
hosted semantic islands: 3
etcd runtime dependencies: 0
provider service islands: 0
product targets: 0
```

`operated_etcd_profile=false`. No fourth island is admitted. Remain in Epoch
Zero.
