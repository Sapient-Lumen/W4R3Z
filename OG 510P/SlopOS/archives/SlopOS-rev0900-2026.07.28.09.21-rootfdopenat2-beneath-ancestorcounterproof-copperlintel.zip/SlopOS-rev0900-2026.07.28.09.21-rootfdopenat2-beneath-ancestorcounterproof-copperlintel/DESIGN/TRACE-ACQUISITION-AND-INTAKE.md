# Trace acquisition and intake separation

## Acquisition lane

Runs only on a fresh, named and privileged storage subject. It creates the
logging target, closes the namespace and writer set, executes one exact workload,
closes the target, exports an exact byte range, and emits a subject-bound receipt.
This lane may fail or remain incomplete; it never emits control authority.

## Intake lane

Consumes only exact bytes plus a declared grammar and baseline. It validates,
normalizes and replays. It cannot infer who produced the bytes, whether export
closed, whether later writes existed, or which machine/device semantics applied.

## Appraisal lane

A separately governed verifier may decide whether an acquisition receipt and
intake result satisfy an evidence policy. The relying party then applies its own
authorization policy. Neither lane chooses an effect.

## Required type barriers

```text
SyntheticTraceBytes
StructurallyValidTrace
DeterministicallyReplayedTrace
ExportClosedTrace
CaptureBoundTrace
MachineBoundTrace
DestructivelyObservedTrace
AuthorityAdmissibleResult
```

Conversions are explicit, evidence-bearing and monotone. No cast exists from a
lower rung based on filename, root ownership, parser success, end marker or
narrative assertion.
