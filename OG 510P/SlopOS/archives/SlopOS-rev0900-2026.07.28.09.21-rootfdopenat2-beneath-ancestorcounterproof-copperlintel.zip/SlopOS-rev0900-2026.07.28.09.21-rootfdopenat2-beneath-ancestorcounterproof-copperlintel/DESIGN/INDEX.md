# Design index

## Current construction surface

1. `REPOSITORY-V24.md` — exactly three semantic islands, 72 audited handoff
   sources including three exact codec dependencies, and no downloader,
   provider service, retry worker, product target, or fourth island.
2. `ROOTFD-BOUND-RELEASE-LOCATOR.md` — caller-supplied `O_PATH` root,
   fixed release leaf, complete `openat2` resolution mask, root-reopen and
   ancestor-symlink counterproofs, and explicit owner/provenance nonclaims.
3. `FD-PINNED-PASSIVE-RELEASE-INGRESS.md` — V11 complete capture, inode-wide
   write/grow/shrink/seal barrier, digest recomputation, and passive archive
   semantics on one sealed object.
4. `ETCD-V3614-OPERATED-PROFILE-GATE.md` — exact release-byte, root,
   administration, cluster, transaction, query, restore, currentness and
   independent-appraisal ladder. The checksum is retained; the archive and
   operated provider remain absent.
5. `OWNER-PINNED-PROVIDER-HISTORY.md` — V9 signed representation, donor custody,
   and restore-identity boundary.
6. `HOSTED-CLAIM-SETTLEMENT.md` — V8 one-attempt submit, honest uncertainty and
   query-only recovery.
7. `ENDPOINT-CLAIM-BEFORE-PARSE.md` — local fixed namespace claim before record
   and payload meaning, with clone/writer/rollback limits.
8. `HOSTED-TRANSACTIONAL-JOIN.md`, `CONTENT-BOUND-SPEND-FLOOR.md`,
   `RESULT-TRILEMMA.md`, and `ENDPOINT-RESULT-CONTRACT.md` — transaction,
   result, and settlement premises that remain local and nonauthoritative.
9. `SEALED-PROVIDER-EXPECTATION-CUT.md`,
   `PROCESS-INSTANCE-AND-ENDPOINT-EPOCH.md`,
   `PROVIDER-BIND-AND-ENDPOINT-PUBLICATION.md`, and
   `LAUNCH-DESCRIPTOR-AND-QUERY-CUT.md` — accumulated process, endpoint,
   publication and query-coordinate boundaries.
10. `HANDOFF-CELL-REFINEMENT.md` — accumulated V1 through V12 hosted laws and
    mandatory nonclaims.
11. `NEXT-VERTICAL-CONSTRUCTION.md` — exact rooted passive archive admission,
    then a separate descriptor-bound no-network activation gate.

## Composition rule

V8 through V12 coexist inside the handoff island but do not compose into
protected authority. A rooted candidate descriptor is not immutable bytes; a
sealed exact archive is not activation; one client attempt is not provider
commit; signed history is not spend; and an exact-current classifier result is
not operation or external currentness. The official checksum product is
release evidence, not an admitted archive, binary, cluster, owner, or successor.

## Historical trail

`REPOSITORY-V23.md` remains the exact rev0899 projection and is superseded only
for the current office. Earlier designs remain retained history. Epoch Zero
continues.
