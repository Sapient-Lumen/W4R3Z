# Bootstrap open

From the extracted checkpoint root:

```sh
python3 -B TOOLS/resume.py basic
```

A successful reopen verifies the exact rev0899 parent receipt, whole-tree
manifest and immutable modes, office projections, Repository V24, custody
spines, exactly three candidate islands, V12/V11 retained evidence, the
regular-only host stop, archive nonadmission, and read-only behavior.

For a fresh handoff reconstruction:

```sh
rm -rf /tmp/slopos-handoff-reconstruct
python3 -B TOOLS/reconstruct_handoff_cell.py \
  --work /tmp/slopos-handoff-reconstruct
```

The result must report 72 audited sources, 52 canonical products and 76,154
canonical bytes per compiler lane; byte-identical Clang/GCC/sanitizer products;
24 rooted relation cases with 11 countermodels; and 21 Linux root-FD cases with
11 counterexamples. It must also report `OPENAT2_REGULAR` required, unsupported
on the retained host, production candidate readiness false, FIFO-open-before-
`fstat` reproduced, archive admission false, extraction false, execution false,
provider operation false, and authority false.

Extracted root: `SlopOS-rev0900-2026.07.28.09.21-rootfdopenat2-beneath-ancestorcounterproof-copperlintel`

Canonical transport: `SlopOS-rev0900-2026.07.28.09.21-rootfdopenat2-beneath-ancestorcounterproof-copperlintel.zip`
