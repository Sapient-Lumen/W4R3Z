# Start here — Helm rev0221

Current surface: `Helm-rev0221-2026.05.26.00.28-auditexport-proofportability-retentionindex-goldlock`.

Read `context-pack.json`, `RELEASE-MANIFEST.json`, `fixtures/portal-net-consent-export/audit-export-pack.json`, and `fixtures/portal-net-consent-export/portal-retention-index.json` first.
