# ADR 0056 — Notification/escalation before notifier or incident runtime

Status: accepted for rev0219 candidate fixture

Decision: add notification/escalation proof strips after execution truth, before any notifier, incident runtime, attention scheduler, workflow engine, policy engine, or backend.

Why: execution-stage evidence can be visually or operationally overclaimed by a toast, badge, push preview, inbox row, acknowledgement, or escalation route. Helm must prove those surfaces preserve uncertainty, denial, partial remainder, duplicate suppression, and settlement mismatch without becoming authority.

Non-decisions: no notification service, no incident system, no escalation workflow, no policy engine, no attention scheduler, no runtime delivery guarantees.
