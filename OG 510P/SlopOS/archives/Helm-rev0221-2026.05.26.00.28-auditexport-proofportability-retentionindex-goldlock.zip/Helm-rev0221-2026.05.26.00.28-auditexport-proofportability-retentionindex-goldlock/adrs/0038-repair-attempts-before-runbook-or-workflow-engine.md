# ADR 0038: Repair attempts before runbook or workflow engine

Date: 2026-05-18  
Status: Accepted for candidate proof fixture  
Revision: rev0203

## Context

rev0202 made custody handoffs explicit. The next temptation is to jump directly to runbooks, tickets, automations, or incident workflows. That would freeze too much too early and reintroduce the old lie that “work item progressed” equals “source state repaired.”

Helm needs one smaller object first: a repair attempt packet.

## Decision

Admit `repair_attempt_packet` as the next release-readiness proof-fixture object.

A repair attempt packet records exact attempt lineage, performed steps, evidence delta, remainder bridge, and handback requirements after custody handoff. It is non-authoritative for repair completion, release readiness, current live truth, obligation closure, policy, workflow completion, ticket completion, or settlement.

## Consequences

- Helm can inspect what was tried without owning a workflow engine.
- Partial progress and blocked slices remain visible.
- Reruns/redrives can preserve story identity while gaining new attempt identity.
- Evidence output and handback become first-class before closure claims.
- No canonical runbook/ticket/automation platform is chosen.

## Deferred

Runbook engine, workflow runtime, ticketing engine, incident platform, automation runner, job scheduler, policy engine, approval engine, event bus, backend, semantic layer, table format, global memory store, and new pillar remain deferred.
