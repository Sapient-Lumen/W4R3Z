# ADR 0055 — Portal case catalog before proof-stack runtime

Status: accepted-for-proof-fixture

Decision: add a generated portal case catalog and checker after the portal layer registry.

Reason: the portal-net companion cube now has many parallel proof packs. The registry checks layer-level drift; the case catalog checks item-level drift: case ids, posture fields, classification pins, target action refs, and unregistered packs.

Non-decisions: proof-stack runtime, registry service, schema registry, documentation generator, policy engine, workflow engine, backend, global memory, and new pillar.
