# ADR 0052 — Arming ceremony before consent or policy runtime

Status: accepted-for-proof-fixture

Decision: add an arming-ceremony proof strip after interpretation/readback and before SlopOS order/admission.

Reason: rev0216 proved displayed evidence can be interpreted faithfully. That is still not consent, not final arm, and not authority. A separate fresh local final gesture must bind the exact destination, payload, effect, cancellation path, arm-copy, and arm-cut digest.

Non-decisions: consent engine, approval engine, policy engine, renderer runtime, dark-pattern classifier, workflow engine, backend, global memory, and new pillar.
