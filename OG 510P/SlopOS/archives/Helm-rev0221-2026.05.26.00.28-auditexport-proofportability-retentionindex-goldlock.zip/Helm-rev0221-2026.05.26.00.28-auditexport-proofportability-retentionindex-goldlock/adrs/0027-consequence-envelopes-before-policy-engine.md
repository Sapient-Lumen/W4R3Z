# ADR 0027: Consequence envelopes before policy engine

Status: accepted

Date: 2026-05-15

## Context

rev0191 added reconciliation traces. They make contradictions checkable, but they do not fully answer what happens when the operator proceeds from a trace into consequence.

Without a next object, Helm risks hiding blast radius, audience, receipt plan, and retreat path behind product copy or button state.

## Decision

Add consequence projections / consequence envelopes as fixture-side product proof objects.

The first admitted shape is `schemas/consequence-projection.schema.json`, populated by `fixtures/release-readiness/consequence-projections.json`, and checked by `tools/check_consequence_projections.py`.

## Consequences

- Every reconciliation trace in the release-readiness specimen now has one consequence projection.
- Strong verbs remain forbidden unless a projection names a receipt/recheck plan and supporting invariant.
- Refusal receipts, quarantine/adoption branches, history renders, and freeze-to-review paths get affected-set and retreat copy.
- External effects are explicitly absent from the first specimen; if added later, they must require receipt and notice preflight.

## Non-decisions

- no policy engine;
- no workflow engine;
- no notifier;
- no authorization language;
- no backend, table format, query language, or semantic layer;
- no CRDT/sync ontology;
- no global provenance store;
- no new pillar;
- no full SlopOS boundary-family import.

## Reopen triggers

Reopen if a second specimen cannot reuse the envelope shape, if projection fixtures become a hidden policy engine, or if operators still need prose outside the fixture to understand what a strong move would affect.
