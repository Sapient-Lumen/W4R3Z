# ADR 0022: Specimen cube and flight recorder before engine

Status: accepted

## Context

ADR 0021 accepted specimen grammar before backend choice.
The next risk is that the grammar remains prose-only.

Current outside pressure from semantic layers, table formats, local analytics, pre-aggregations, local-first sync, triage tools, merge queues, context propagation, browser-mediated identity, desktop portals, command surfaces, and local recall all supports the same lesson: powerful derivative surfaces are safe only when their source cut, serving lane, posture, basis, invalidators, next verbs, and receipt paths stay visible.

But none of that pressure justifies choosing a canonical backend now.

## Decision

Helm will define a **specimen cube** and a **specimen event record** before choosing a canonical datacube backend.

The specimen cube is accepted as a proof-fixture and UI-truth model.
The release-readiness proof fixture is accepted as the first concrete test case.

## Consequences

### Positive

- Helm can now test whether its truth grammar explains actual UI flows.
- The seven pillars can share one record grammar without becoming one UI.
- Backend/storage/semantic-layer choices remain replaceable.
- Mockups can be checked for live/saved/cut/derived/receipt collapse.
- Imported arrivals, stale fences, rechecks, promotions, and receipts are now fixture-testable.

### Negative

- The archive gets a small schema/checker layer.
- Some records will feel too verbose until UI chip/popover renderings are mocked.
- The first checker is intentionally shallow and could create false confidence if treated as full assurance.

### Non-decisions

This ADR does not select:

- DuckDB;
- DuckLake;
- Iceberg;
- Delta;
- Cube;
- dbt MetricFlow;
- Databricks metric views;
- Observable Framework;
- SQLite/Turso/Electric;
- a production event store;
- a telemetry pipeline;
- or a global workspace object.

## Reopen if

- the event record cannot explain the release-readiness fixture;
- the chip/popover/inspector UI feels like internal plumbing;
- every useful prototype immediately needs one backend-specific feature;
- specimen records become ambient surveillance rather than proof paths;
- strong verbs still happen without basis and receipts.
