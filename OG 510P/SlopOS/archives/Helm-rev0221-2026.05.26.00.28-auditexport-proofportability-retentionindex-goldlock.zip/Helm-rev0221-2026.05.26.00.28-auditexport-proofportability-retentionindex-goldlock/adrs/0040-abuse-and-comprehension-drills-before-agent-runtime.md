# ADR 0040: Abuse and comprehension drills before agent runtime

Status: accepted  
Date: 2026-05-21  
Revision: rev0205

## Context

rev0204 introduced Helm's first explicit companion seam with SlopOS through the `portal-net-consent-export` specimen. That proved the ordinary path: proposal, authority diff, trusted path, fresh volition, SlopOS admission or denial, digest-only receipt, retry guard, and retention posture.

The next risk is not a missing engine. The next risk is overfitting to polite fixtures. A companion shell that only renders accepted/denied cases can still fail when a card is spoofed, a flow resumes in the background, scope widens after consent, Recall returns history as if it were authority, duplicate replay is celebrated as a second success, request IDs mismatch, retention exceeds budget, labels drift, receipts cross subjects, or copy omits material denial facts.

## Decision

Add abuse drills and operator comprehension cards before agent runtime, network portal implementation, consent engine, policy engine, or UI polish.

rev0205 therefore adds:

- `fixtures/portal-net-consent-export/abuse-drill-pack.json`
- `fixtures/portal-net-consent-export/operator-comprehension-cards.json`
- `schemas/portal-net-abuse-drill.schema.json`
- `schemas/operator-comprehension-card.schema.json`
- `tools/check_portal_net_abuse_drill.py`
- `tools/check_operator_comprehension_cards.py`
- `helm.portal_abuse_hazard` classification pins

## Consequences

Good:

- The companion seam must now prove bad-path legibility.
- Operator copy becomes a checked surface, not polish folklore.
- Hazard labels are pinned before future revisions rename them.
- Helm remains a witness and pre-arm blocker without becoming SlopOS, policy, or security authority.

Bad:

- More fixture ceremony.
- More copy to maintain before final UI.
- Some hazards are still synthetic until a rendered board or agent harness exists.

## Non-decisions

This ADR does not create an agent runtime, tool protocol adapter, OAuth client/server, MCP client/server, desktop portal daemon, security scanner, policy language, workflow runtime, consent service, accessibility certification, or final copywriting system.
