# ADR-0015 — ambient adjacency does not widen activity scope

## Status

Accepted — rev0014.

## Context

Helm already froze:
- request-vs-live truth,
- entry-artifact truth,
- and binding-witness posture for non-exact joins.

That solved several important continuity lies,
but one dangerous move remained easy:
a saved/planned activity could still inherit nearby workspace, profile, account, browser-session, provider, or remote context by convenience and then count that widened situation as “the same activity.”

SlopOS keeps refusing silent widening across exact reveal, request-state, session-selection, and request-local metadata seams.
Schell keeps pressuring launch kits, cockpits, origin surfaces, and preflight honesty.
DelayBasin's scope-witness / active-request / ambient-roster discipline makes the missing refinement explicit.

## Decision

Helm freezes one narrow posture:

**nearby ambient context does not silently widen activity scope.**

When Helm suggests or claims continuity for an activity,
it should be able to distinguish:
- which scope axes were actually in play,
- which nearby ambient surfaces were excluded,
- and when scope became widened, unknown, or operator-switched.

This does **not** require a final activity ontology or one universal scope algebra.
It only says activity continuity should not silently inherit nearby context by glow.

## Consequences

Positive:
- entry kits, cockpits, capsules, Recall cues, and binding witnesses gain a clearer honesty rule
- profile/account/browser/remote/workspace-like drift becomes easier to reject consistently
- future activity scope witnesses now have a firm cross-cutting reason to exist

Negative / cost:
- some quick-return flows will need compact scope explanation rather than a flatter “same activity” badge
- the archive still needs to learn the smallest good scope witness rather than merely naming the rule

## What remains open

- the smallest reusable activity scope witness shape
- which scope axes deserve default visibility versus inspect-only detail
- which high-risk axis changes should require review versus compact witness only
- how scope witnesses should compose with binding witness cards without becoming clutter
