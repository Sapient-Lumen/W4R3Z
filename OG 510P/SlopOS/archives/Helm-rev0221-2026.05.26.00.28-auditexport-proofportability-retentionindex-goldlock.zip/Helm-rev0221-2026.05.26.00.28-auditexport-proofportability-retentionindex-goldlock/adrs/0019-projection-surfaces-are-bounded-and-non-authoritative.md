# ADR-0019 — projection surfaces are bounded and non-authoritative by default

## Status

Accepted — rev0023.

## Context

Helm has accumulated a growing family of warm shell luxuries:
- command docks,
- preview rails,
- facet strips,
- review strips,
- sticky context strips,
- live lenses,
- cockpit cards,
- and exact trail cues.

Those ideas are promising,
but they also create a recurring drift risk:
small fast surfaces quietly turn into second workflows,
second launchers,
second continuity stories,
or general dashboard religion.

SlopOS's datacube is now teaching one especially reusable law:
helpful derived faces should be bounded,
explicit about source and materialization,
and visibly weaker than the authoritative seam they project from.
CH-SPROJ,
namecert projection,
and OpenURI materialization boundaries all converge on that lesson.

## Decision

Helm freezes one narrow cross-cutting posture:

**compact shell luxuries that project already-legible truth are projection surfaces.
They are bounded,
typed,
and non-authoritative by default.
They must not silently smuggle in a second workflow or a stronger authority domain.**

This does **not** decide the final UI for docks,
rails,
strips,
lenses,
or cockpit cards.
It only decides the law they must obey.

## Consequences

Positive:
- warm cross-pillar moves now share one anti-drift law
- Helm can build fast shell luxuries without quietly creating second constitutions
- SlopOS's strongest datacube lesson now improves Helm's product shape directly

Negative / cost:
- some tempting accelerators will now need to route stronger actions back into owning reviewed lanes
- certain dashboard-like shortcuts will be demoted or forced to declare their source and limits more clearly

## What remains open

- the smallest compelling projection-surface specimen spanning more than one surface family
- when exact trail cues deserve their own candidate contract
- whether future trust ladders or quick-key promotion surfaces should be treated as projection-family members or their own narrower contracts
