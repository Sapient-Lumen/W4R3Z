# ADR 0033: Obligation ledgers before workflow or ticketing engine

Date: 2026-05-16T04:12:00-04:00  
Status: accepted for candidate proof fixture

## Context

rev0197 added exception leases. A lease can be active, denied, expired, or redeemed, but each posture creates follow-through pressure. Without a first-class due-work record, Helm would hide obligations inside prose, alert rules, ticket comments, or invisible operator memory.

## Decision

Admit `obligation_ledger` entries as the next release-readiness proof object.

Each entry must bind to a source exception lease, carry owner/accountable party, due time, exit condition, debt budget, required evidence, escalation behavior, non-authority scope, forbidden strong effects, closure proof, and visible operator controls.

## Consequences

Helm can now prove that exceptions create accountable service work without choosing a workflow runtime, ticketing system, policy engine, service catalog, SLO engine, cost engine, backend, semantic layer, table format, or new pillar.

## Non-decision

No ticketing engine. No workflow engine. No policy engine. No service catalog. No scorecard engine. No incident/alerting platform. No SLO engine. No cost engine. No backend or semantic-layer choice.
