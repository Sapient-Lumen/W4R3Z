# ADR 0043: Surface continuity before handoff runtime

Status: accepted  
Date: 2026-05-22  
Revision: rev0208

## Context

rev0204 proved the SlopOS portal-net companion seam. rev0205 added abuse and comprehension drills. rev0206 added ingress quarantine and trace replay. rev0207 added egress manifests and recovery sheets. The remaining near-term seam is continuity: operators will expect to resume or inspect an action across windows, devices, notifications, assistive surfaces, QR links, clipboard text, or agent surfaces.

## Decision

Admit a checked surface-continuity proof pack before any handoff runtime. A continuity witness is useful evidence, but it is not authority. Consequential continuation after a surface change requires fresh local volition, same digest binding, current trusted-path state, visible expiry, and non-authority copy.

## Consequences

Helm may render continuity strips. Helm may not treat handoff as consent, device authentication as action approval, ambient sync as authorization, or remote-agent continuation as a spendable human gesture. Runtime handoff protocols, passkey binding, push notification transport, clipboard/QR runtimes, workflow engines, policy engines, and global memory remain deferred.
