# ADR 0042: Egress manifests and recovery sheets before runtime

Status: accepted  
Date: 2026-05-22  
Revision: rev0207

## Context

The portal-net specimen had consent, abuse drills, operator comprehension, ingress quarantine, and seam traces. It still needed proof for the moment after action start: cancellation, abort, timeout, duplicate retry, revoke, compensation, stale reattempt, cross-device continuation, and retention sweep.

## Decision

Add checked egress manifests and recovery sheets before any browser-agent runtime or network portal implementation. The recovery sheet distinguishes no-effect, uncertain, duplicate, future-only revoke, new compensation action, fresh-basis retry, fresh-volition continuation, and minimized history.

## Consequences

Helm may show recovery and handback affordances. It may not claim remote undo, delivery confirmation, workflow completion, or policy authority. Silent retry after uncertainty remains forbidden.

## Deferred

Undo protocol, remote delete protocol, event store, job scheduler, workflow engine, policy engine, authorization server, MCP adapter, browser agent runtime, and new pillar.
