# ADR 0028: Commit capsules before deployment engine

Status: Accepted  
Date: 2026-05-15

## Context

rev0192 consequence envelopes made Helm rehearse what a reconciled contradiction would affect. The next risk is letting a rehearsed move turn into local consequence without a bounded, observable, abortable, and reversible packet.

Outside systems point in this direction: progressive delivery tools stage exposure and analysis, feature flag systems record change history and scheduled changes, policy engines emit decision logs, Kubernetes can dry-run mutation admission, and provenance systems bind evidence to subjects. Helm should learn the discipline without importing their control planes.

## Decision

Add `commit_capsule` as a release-readiness proof-fixture object before choosing any deployment engine, policy engine, workflow runtime, flag system, notifier, authorization language, backend, table format, semantic layer, or new pillar.

## Consequences

- Every consequence projection in the release-readiness specimen has one capsule.
- Capsules can shrink but not broaden consequence projections.
- Local durable state needs receipt/tombstone behavior.
- Dry runs cannot mint receipt authority.
- History pins cannot answer current questions.
- Review cuts cannot impersonate promotion.
- Settlement stays false until a later specimen earns it.

## Deferred

- rollout/deployment engine;
- policy engine;
- feature flag control plane;
- notifier;
- workflow runtime;
- CRDT/sync model;
- backend/query/table/semantic layer;
- authorization language;
- external-effect capsule semantics;
- new pillar.
