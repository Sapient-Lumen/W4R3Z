# ADR 0025: Evidence budgets before cost engine

Status: accepted
Date: 2026-05-14

## Context

rev0187 gave Helm a specimen cube. rev0188 made event truth queryable by surface cards. rev0189 made product motion checkable by lane transition contracts.

The next risk is economic and experiential: a move can be lawful while the user still cannot tell why it is instant, why a button is refused, why a recheck is required, or why a receipt cannot be reused as current truth.

External systems reinforce the pattern: freshness checks, cache keys, attestations, snapshot references, carried lineage/context, and merge queues are all useful because they tell users when reuse is safe and when rechecks or receipts are required.

## Decision

Admit `evidence_budget_entry` as a fixture-side proof object and add `fixtures/release-readiness/evidence-budget-ledger.json` plus `tools/check_evidence_budget_ledger.py`.

An evidence budget entry must name target event/contract, evidence kind/state, decision, cost class, budget units, cache key fields, verbs allowed to reuse the evidence, verbs forbidden from reusing it, visible reason, miss reason, required gate kinds, source refs, and weakness posture.

## Consequences

- Helm can now test evidence reuse, cache misses, recheck requirements, receipt-only posture, and over-spend refusals.
- Static cards, transition contracts, and evidence budgets compose into a stronger proof fixture.
- Designers can prototype a truth rail plus evidence meter without committing to a backend, workflow engine, cost engine, or semantic-layer product.
- Disabled buttons and slow rechecks get copy-ready reasons.

## Non-decisions

- no cost engine;
- no scheduler;
- no billing/spend accounting;
- no canonical provenance store;
- no workflow engine;
- no backend, table format, query language, or semantic layer;
- no new pillar;
- no full SlopOS boundary-family import.

## Reopen trigger

Reopen if evidence budgets become fake-precise accounting, a hidden workflow engine, or a reason to skip required gates instead of explaining them.

