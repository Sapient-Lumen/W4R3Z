# ADR 0060: Audit export before proof portability runtime

Date: 2026-05-26T00:28:00-04:00
Status: Accepted for rev0221 fixture layer

## Context

Helm now has appeal/correction, notification, execution, arming, interpretation,
presentation, sync, temporal, effect, resource, namespace, capability, continuity,
ingress, egress, and companion-seam proof strips. The next failure mode is making
portable proof too powerful: export bundles, support packages, attestations, or
machine summaries might be mistaken for consent, verdict, current truth, or
SlopOS admission.

## Decision

Admit an audit/export fixture layer before any proof-portability runtime. The
layer carries manifests, digest chains, omitted refs, redaction sweep witnesses,
recipient binding, and reimport rebind state as evidence only.

## Non-decisions

No audit exporter runtime, support portal, attestation protocol, reimport engine,
policy engine, workflow engine, backend, global memory, or new pillar is admitted.
