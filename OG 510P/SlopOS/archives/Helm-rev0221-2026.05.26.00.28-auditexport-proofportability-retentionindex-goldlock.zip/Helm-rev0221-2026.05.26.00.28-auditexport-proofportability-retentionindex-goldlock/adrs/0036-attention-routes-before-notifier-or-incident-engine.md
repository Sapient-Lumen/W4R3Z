# ADR 0036: Attention routes before notifier or incident engine

Status: accepted  
Revision: rev0201

## Context

rev0200 introduced repair arbitration packets. Once Helm chooses a local repair order, the next practical pressure is to notify, page, quiet, digest, or assign someone. Without a bounded object, Helm would either become a generic notification center or let pages/digests/quieting imply outcomes they cannot prove.

## Decision

Admit `attention_route_packet` as a candidate proof-fixture object.

The object may route attention, name recipients/channels, group/bundle/digest/quiet/inhibit messages, carry redelivery windows, and emit notice-witness claim-strength records.

It may not become delivery truth, seen truth, acknowledgement truth, repair completion, approval, release readiness, policy, notifier, incident platform, alerting backend, paging provider, scheduler, workflow engine, SLO engine, scorecard engine, ownership registry, backend truth, semantic-layer truth, table-format truth, global memory, or a new pillar.

## Consequences

- Helm can say who should be interrupted next without pretending the route fixed anything.
- Quiet and digest states remain visible with reason and expiry.
- Notice cards can be useful without becoming read receipts or approvals.
- SlopOS D-ATTN pressure stays honored: urgent is a policy-gated hint, not a durable grant.

## Reopen trigger

Reopen if route packets are treated as seen/acknowledged/fixed truth, if quieting hides source degradation, if broad broadcasts become default, or if a second specimen cannot reuse the object shape.
