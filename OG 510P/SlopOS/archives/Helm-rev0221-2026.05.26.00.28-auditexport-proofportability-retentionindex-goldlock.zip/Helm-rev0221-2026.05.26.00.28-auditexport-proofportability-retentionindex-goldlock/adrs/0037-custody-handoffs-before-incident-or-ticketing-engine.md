# ADR 0037: Custody handoffs before incident or ticketing engine

Status: accepted  
Revision: rev0202

## Context

rev0201 introduced attention route packets. Once Helm can route a page, bundle, digest, quiet watch, or guarded repeat, the next temptation is to treat acknowledgement as resolution or assignment as ownership. That would recreate the oldest incident-management and task-board lie: someone interacted with the route, therefore the work is handled.

## Decision

Admit `custody_handoff_packet` as a candidate proof-fixture object.

The object may record scoped acceptance, bounded delegation, explicit decline, missed acknowledgement timeout, quiet/watch custody, no-ack-required digest posture, redelivery, and residual due work.

It may not become repair completion, incident resolution, source owner truth, approval, release readiness, settlement, policy, workflow completion, ticket completion, notification delivery truth, seen truth, scheduler truth, SLO/scorecard truth, backend truth, semantic-layer truth, table-format truth, global memory, or a new pillar.

## Consequences

- Helm can distinguish accepted custody from repair.
- Delegation becomes useful without becoming an ownership registry edit.
- Declines and missed timeouts produce visible redelivery instead of silent decay.
- Quiet watch and no-ack-required digest states stay weaker than recovery or completion.

## Reopen trigger

Reopen if custody packets are used to close obligations, if acknowledgement becomes repair/resolution, if delegation silently changes source ownership, if missed acks disappear, or if a second specimen cannot reuse the object shape.
