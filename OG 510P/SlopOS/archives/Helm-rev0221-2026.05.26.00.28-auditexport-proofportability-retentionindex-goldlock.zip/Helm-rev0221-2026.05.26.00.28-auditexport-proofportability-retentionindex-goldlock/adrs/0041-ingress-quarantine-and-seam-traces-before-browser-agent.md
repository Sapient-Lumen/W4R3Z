# ADR 0041: ingress quarantine and seam traces before browser agent

## Status

Accepted in rev0206.

## Context

rev0204 proved a SlopOS companion seam for `portal.net.request`. rev0205 proved bad-path consent/export comprehension. The next risk is the return path: remote content may try to become instruction, authority, future consent, or Recall memory.

## Decision

Add checked ingress-quarantine drills and a digest-checked seam trace ledger before any browser agent, network portal implementation, prompt-injection classifier, policy engine, or backend trace system.

## Consequences

- Helm now proves returned content remains data until locally reviewed.
- Helm now proves trace replay is a witness surface, not fresh authority.
- Prompt-injection pressure is recorded as product seam pressure without importing a security scanner.
- Future rendering work must show action, abuse, ingress, and trace strips together.

## Non-decisions

No browser agent runtime, no content scanner, no policy engine, no network portal, no OAuth/MCP adapter, no event store, and no distributed tracing format are selected here.
