# ADR 0031: Counterexample dockets before ranking or memory engine

Status: Accepted  
Date: 2026-05-15

## Context

rev0195 added precedent cards so Helm can learn from settled local history. The next risk is overfit learning: a precedent can match a future shape while being materially wrong, too broad, stale, or unsafe under current coverage.

Older Helm notes already emphasized calibration witnesses, miss ledgers, coverage gaps, and wake/attention truth. SlopOS reinforces the archive lesson: companion boundary families are valuable when they stop authority laundering, but they should not become ambient control planes. The right Helm move is smaller: make the failure of a learned card inspectable.

Outside systems point in the same direction. dbt data tests return failing records that disprove assertions. Git rerere records reusable resolutions but exposes clear/forget behavior. Sentry fingerprint rules make grouping explicit while preserving override seams. OPA decision logs keep input/decision crumbs for audit and debug. Feast validation and drift tools demonstrate that schema/distribution mismatch should be visible before stronger reuse.

## Decision

Add `counterexample_case` as a proof-fixture object before choosing a ranking engine, memory engine, recommender, policy engine, workflow runtime, feature-flag control plane, backend, semantic layer, table format, global memory store, or new pillar.

## Consequences

- Every release-readiness precedent card now has one counterexample case.
- Precedents list their counterexample refs.
- Counterexamples can keep with note, narrow, demote, suspend, or revoke-candidate.
- Counterexamples cannot strengthen a precedent, broaden scope, auto-apply, become policy, or answer release readiness.
- The first release-readiness learning loop now has both positive precedent and negative counter-precedent evidence.

## Deferred

- ranking engine;
- memory engine;
- recommender or personalization engine;
- policy/rule engine;
- feature-flag control plane;
- workflow runtime;
- global memory inheritance;
- production drift/validation engine;
- backend/query/table/semantic layer;
- new pillar.
