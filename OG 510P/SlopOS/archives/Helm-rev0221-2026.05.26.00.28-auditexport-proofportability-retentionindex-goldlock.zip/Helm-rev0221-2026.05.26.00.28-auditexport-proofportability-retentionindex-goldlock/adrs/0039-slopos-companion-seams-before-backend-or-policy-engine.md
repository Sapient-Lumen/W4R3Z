# ADR 0039: SlopOS companion seams before backend or policy engine

Status: accepted  
Revision: rev0204

## Context

rev0203 made repair attempts first-class but stayed inside the release-readiness specimen. Helm still needed to prove that it can be a shell companion to SlopOS without becoming SlopOS's validator, policy engine, network portal, workflow engine, or backend.

## Decision

Add `portal-net-consent-export` as the second specimen and pin the Helm ↔ SlopOS seam:

- Helm renders proposal, authority diff, trusted-path state, volition, receipt, retry guard, and retention posture.
- SlopOS owns ACP validation, `portal.net.request`, `svc:portal.net`, exact replay dedupe, order tokens, `CH-ACPOUT`/`CH-DENY`, and issued-bounds descriptors.

Also add classification pins and retention posture checks before widening UI or backend work.

## Consequences

Good:

- Helm now has a concrete SlopOS-backed action specimen.
- Consent, retry, receipt, and retention are checked together.
- Enum-like labels get pinned before drift.
- The repair-attempt board now has retention/retry/recheck/handback authority columns.

Costs:

- The fixture has more cross-cutting fields.
- Future specimens must decide whether they need the full consequence chain or a weaker read-only chain.

## Non-decisions

No policy engine, workflow engine, ticketing engine, network portal implementation, canonical backend, query language, semantic layer, table format, global memory, or new pillar is chosen.
