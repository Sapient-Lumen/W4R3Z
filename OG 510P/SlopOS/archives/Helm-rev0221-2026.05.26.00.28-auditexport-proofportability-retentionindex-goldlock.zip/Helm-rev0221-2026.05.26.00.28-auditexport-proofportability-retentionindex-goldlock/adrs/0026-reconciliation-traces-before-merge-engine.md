# ADR 0026: Reconciliation traces before merge engine

Status: accepted
Date: 2026-05-15

## Context

rev0187 made Helm truth concrete as event records. rev0188 made those records back surface affordances. rev0189 made lane transitions lawful. rev0190 added evidence economics.

The next failure mode is disagreement: all those objects can be individually correct while the user still needs to know what happens when live, saved, stale, imported, reviewed, and historical truths conflict.

The archive already contained a strong old seed around reconcile recipes and resolution memories. That seed should now be pulled forward, but not as a universal merge manager.

## Decision

Admit `reconciliation_trace` as a fixture-side object and add:

- `schemas/reconciliation-trace.schema.json`
- `fixtures/release-readiness/reconciliation-traces.json`
- `tools/check_reconciliation_traces.py`
- architecture and assurance docs for reconciliation traces, refusal receipts, and suggestion-only resolution memory.

A trace must cite real events, contracts, evidence entries, and existing contradiction pairs. It must preserve losing truths, scope winners to the question being answered, forbid strong verbs for stale/refused evidence, and require refusal receipt copy where basis drift blocks a consequential move.

## Consequences

- Helm can test contradiction behavior without choosing a merge engine.
- Refusal becomes a durable, inspectable product object rather than a generic error.
- Resolution memory stays useful but suggestion-only.
- The release-readiness specimen now proves static UI truth, motion truth, evidence economics, and contradiction behavior.

## Non-decisions

- no universal merge/reconcile engine;
- no workflow runtime;
- no CRDT or sync ontology;
- no backend, table format, or semantic layer;
- no automatic resolution memory authority;
- no new pillar;
- no full SlopOS boundary-family import.

## Reopen trigger

Reopen if traces become hidden workflow/merge machinery, if refusal receipts are treated as approvals, or if a second specimen cannot reuse the trace grammar.
