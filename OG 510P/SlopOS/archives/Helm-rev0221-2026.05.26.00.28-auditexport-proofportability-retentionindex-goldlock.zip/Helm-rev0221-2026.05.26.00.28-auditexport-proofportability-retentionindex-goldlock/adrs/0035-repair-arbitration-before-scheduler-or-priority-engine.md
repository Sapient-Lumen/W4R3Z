# ADR 0035: Repair arbitration before scheduler or priority engine

Status: accepted  
Date: 2026-05-18  
Revision: rev0200

## Context

rev0199 introduced service covenants. Once covenants exist, Helm needs to choose what to repair first when multiple covenants compete for scarce attention or resource slots. Without a first-class object, Helm would either hide losers behind a score, invent a silent scheduler, or let the loudest owner win.

## Decision

Admit `repair_arbitration_packet` as a candidate proof-fixture object.

A repair arbitration packet may locally order, split, park, or defer repair work. It must name source covenants, source obligations, scarce resource pools, demand rows, selected sequence, deferrals, fairness guards, visible copy, and forbidden strong effects.

## Consequences

- Helm can make tradeoffs visible before it has a scheduler, ticketing engine, or policy engine.
- Deferred covenants keep their source posture, owner, due/degradation copy, and escalation path.
- Scarce resources must be named; implicit sponsorship is forbidden.
- Queue position cannot authorize release readiness, current readiness, approval, policy, health score, SLO truth, or global memory.

## Non-decisions

No scheduler, priority engine, SLO engine, scorecard engine, service catalog, ownership registry, alerting/incident platform, ticketing/workflow engine, policy engine, ranking engine, cost engine, budget engine, backend, query language, semantic layer, table format, global memory store, or new pillar is selected.
