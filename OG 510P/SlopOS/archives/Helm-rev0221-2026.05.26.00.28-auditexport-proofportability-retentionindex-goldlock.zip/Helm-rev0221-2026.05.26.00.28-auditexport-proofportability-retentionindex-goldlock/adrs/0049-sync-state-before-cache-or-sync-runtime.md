# ADR 0049 — Sync state before cache or sync runtime

Status: accepted for proof fixture

Date: 2026-05-24

## Context

rev0213 made temporal authority visible, but a different stale-authority path remains: local state. A shell can have cached receipts, offline cards, partial sync reports, local mutation queues, stale lease snapshots, Recall results, delayed revocations, and resume cursors. These are useful for explanation, but dangerous if rendered as fresh permission.

## Decision

Add sync/cache-state strips to the portal-net consent/export specimen before adding any cache engine, sync engine, offline queue runtime, conflict resolver, tombstone service, or revocation runtime.

The strip must show cache origin, cache/server/revocation epochs, partial sync, conflicts, tombstones, local queue, digest comparison, lease snapshot, Recall snapshot posture, delayed revocation, and recheckpoint state.

## Consequences

Helm can explain stale or partial local state without becoming a synchronizer. SlopOS remains the authority boundary. Offline cache is read-only unless fresh local volition and SlopOS admission re-establish the action.

## Non-decisions

This ADR does not add a cache engine, sync engine, local-first database, offline queue, conflict resolver, tombstone service, revocation registry, session manager, policy engine, workflow engine, backend, global memory, or new pillar.
