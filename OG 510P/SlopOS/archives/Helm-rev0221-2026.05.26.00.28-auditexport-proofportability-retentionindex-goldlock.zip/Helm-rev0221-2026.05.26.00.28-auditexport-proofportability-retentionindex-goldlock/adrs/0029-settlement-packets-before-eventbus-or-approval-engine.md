# ADR 0029: Settlement packets before event bus or approval engine

Status: Accepted  
Date: 2026-05-15

## Context

rev0193 commit capsules made rehearsed consequences locally commit-able. The next ambiguity is the word “settled.” In most products, settled sounds stronger than it is: users may read it as approved, current, publishable, or globally durable.

Outside systems reinforce the need for small closure packets. CloudEvents has a compact event envelope discipline. SLSA/in-toto binds predicates to subjects and materials. Kubernetes finalizers make cleanup/closure gates explicit. OPA decision logs preserve decision inputs and results. GitHub deployment statuses preserve inactive/transient state. Temporal-style sagas keep forward and compensating actions visible. Helm should steal the packet discipline, not the control planes.

## Decision

Add `settlement_packet` as a proof-fixture object before choosing any event bus, approval engine, deployment engine, workflow runtime, policy engine, global attestation store, backend, semantic layer, table format, distributed transaction model, or new pillar.

## Consequences

- Every commit capsule has a settlement packet.
- Dry runs can only block settlement.
- Refusals can settle as history, not approval.
- Restricted imports can settle as local/quarantine branches, not global trust.
- Recall pins can settle as indexes, not current truth.
- Review cuts can settle as queue artifacts, not promotion.
- Finalizer keys, tombstone policy, event envelope, and non-authority copy become checkable.

## Deferred

- release-readiness approval packet;
- external effect settlement;
- event bus / CloudEvents transport;
- policy engine / authorization language;
- workflow runtime or saga framework;
- global provenance/attestation store;
- backend/query/table/semantic layer;
- CRDT/sync ontology;
- new pillar.
