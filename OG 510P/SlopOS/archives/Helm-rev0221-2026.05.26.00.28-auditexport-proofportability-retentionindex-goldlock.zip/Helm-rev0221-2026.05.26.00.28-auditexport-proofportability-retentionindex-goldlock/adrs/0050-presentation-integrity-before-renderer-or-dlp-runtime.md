# ADR 0050 — Presentation integrity before renderer or DLP runtime

Status: accepted for proof fixture

Date: 2026-05-25

## Context

rev0214 made local/offline/sync state visible without letting cached evidence become fresh authority. A different path remains: the display itself. A shell can be correct internally while leaking sensitive fields, hiding stale-history posture, overclaiming approval with a badge, copying plaintext through the clipboard, dropping warnings from assistive copy, or letting remote content visually spoof authority.

## Decision

Add presentation-integrity strips to the portal-net consent/export specimen before adding any renderer runtime, DLP scanner, screenshot service, clipboard manager, localization system, screen-share runtime, accessibility engine, or policy/runtime adapter.

The strip must show surface origin, trusted-path state, redaction overlay, data class, stale and receipt badges, authority-badge posture, visual diff, copy channels, screen-share posture, screenshot/export posture, assistive copy completeness, localized-copy match, and non-authority text.

## Consequences

Helm can explain and contain display-time leakage or overclaim without becoming the rendering or DLP substrate. SlopOS remains the authority boundary. Display success, redaction success, and visible UI chrome remain evidence only.

## Non-decisions

This ADR does not add a renderer, DLP scanner, screenshot service, clipboard manager, localization runtime, screen-share runtime, accessibility engine, policy engine, workflow engine, backend, global memory, or new pillar.
