
# ADR-0014 — non-exact bindings require witnesses

## Status

Accepted — rev0013.

## Context

Helm now has enough saved/planned continuity artifacts that one more continuity lie is becoming dangerous:
even after admitting that saved entry artifacts are not live state, the shell could still silently rebind those artifacts to nearby live targets and present the result as ordinary success.

Current outside tools already show the pressure:
saved workspaces, profiles, quick task-entry objects, and structured summon surfaces are all attractive,
but they often stop short of a beautiful explicit account of reuse and repair.

SlopOS keeps refusing silent nearby substitutes across exact reveal, session-selection, recent-items, launch-completion, and request-state seams.
Schell now has enough launch-kit / cockpit / preflight pressure that continuity matching can no longer stay implicit.

## Decision

Helm freezes one narrow posture:

**when Helm binds saved or planned task-entry structure to current live targets non-exactly, the join should stay witnessable rather than silent.**

This does **not** require one universal matching engine or giant workspace/session ontology.
It only says repaired / substituted / ambiguous joins should remain inspectable and downgradeable instead of collapsing into one flattering continuity story.

## Consequences

Positive:
- capsules, templates, cockpits, and entry kits can stay useful without bluffing about repaired matches
- hidden target substitution becomes easier to reject consistently
- future binding witness cards now have a firm cross-cutting reason to exist

Negative / cost:
- some return-to-task flows will be a little more explicit than legacy helper tools
- the archive still needs to learn the smallest good witness card rather than merely naming the rule

## What remains open

- the smallest reusable binding witness card shape
- the final slot / anchor / target taxonomy
- how much detail should surface by default versus behind inspect / expand
- which remote/profile/account-like joins deserve mandatory review versus compact witness only
