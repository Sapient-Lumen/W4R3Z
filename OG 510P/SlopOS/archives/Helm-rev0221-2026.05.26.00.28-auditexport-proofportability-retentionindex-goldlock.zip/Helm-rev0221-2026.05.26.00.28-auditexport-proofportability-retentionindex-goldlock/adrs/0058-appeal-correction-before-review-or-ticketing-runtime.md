# ADR 0058 — Appeal/correction before review or ticketing runtime

Status: accepted for rev0221.  
Date: 2026-05-26T00:28:00-04:00.

## Context

After notification/escalation truth, Helm must support contested outcomes and corrections without rewriting history. Operators need a way to mark a success claim disputed, note a denial recheck, withdraw a false-positive alert, backfill a missed alert, link superseded copy, and record rectification.

## Decision

Add `appeal-correction-pack.json`, schema, checker, docs, classification pins, companion seam refs, case-catalog rows, and action-ref matrix refs before any appeal engine, support-ticketing system, correction workflow, moderation queue, or backend.

## Consequences

A correction can affect future display or route review, but it cannot mutate prior receipts, silently retry, reverse remote effects, bypass SlopOS, or become authority.
