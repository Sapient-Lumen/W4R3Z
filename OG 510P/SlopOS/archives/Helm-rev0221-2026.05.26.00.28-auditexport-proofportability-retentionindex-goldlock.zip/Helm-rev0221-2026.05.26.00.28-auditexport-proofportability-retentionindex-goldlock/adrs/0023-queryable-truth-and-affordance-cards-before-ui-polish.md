# ADR 0023: Queryable truth and affordance cards before UI polish

Status: accepted

## Context

ADR 0022 accepted the specimen cube and flight recorder before choosing a backend. rev0187 added records and a shallow checker.

The next risk is that the cube remains a debugging artifact while the product UI invents chips, buttons, refusals, and green states that are not actually backed by the record grammar.

Current outside pressure supports the same lesson: semantic definitions, snapshots, pre-aggregations, local-first sync, lineage facets, context propagation, triage inboxes, and merge queues are valuable only when their basis, freshness, staging, and receipts remain visible.

## Decision

Helm accepts **surface affordance cards** and a **query pack** as the next proof-fixture layer.

A surface affordance card maps one specimen event to product behavior:

- visible chip;
- headline/body copy;
- primary affordance;
- secondary affordances;
- forbidden affordances;
- required visible fields;
- recheck/receipt gate.

The release-readiness fixture now includes cards, query assertions, generated query results, and checkers.

## Consequences

### Positive

- Mockups can be tested against product truth before UI polish.
- Buttons cannot silently outrun safe next verbs.
- Contradictions become deliberate product material.
- AI/Omnibox/Flow proposals can compile to rungs instead of acts.
- Backend/storage/query-language choices remain deferred.

### Negative

- More fixture files exist.
- Card copy can feel overly explicit until designers tune chip/popover/inspector layers.
- The checker may create false confidence if treated as production authorization.

### Non-decisions

This ADR does not select:

- SQL or a query language;
- DuckDB, DuckLake, Iceberg, Delta, Cube, dbt, Databricks, Observable, Electric, LiveStore, or any other backend;
- a production telemetry pipeline;
- a UI framework;
- a new pillar;
- full SlopOS boundary-family machinery.

## Reopen if

- the affordance cards feel like bureaucratic paperwork rather than product truth;
- designers cannot build compact chip rows from cards;
- the query pack cannot explain the next serious mockup;
- the checker blocks good UI patterns for reasons that are only schema artifacts;
- strong verbs still appear without fresh basis, receipts, or explicit exception.
