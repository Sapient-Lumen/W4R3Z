# ADR 0021: Specimen grammar before backend choice

Status: accepted

## Context

rev0185 admitted lightweight boundary watchrail cards for serious Helm surfaces.
Continued research and companion-cube evaluation show that the next risk is not missing vocabulary; it is missing a concrete product proof loop.

Modern semantic layers, table formats, local analytics tools, workflow products, triage tools, preview surfaces, branch systems, authorization specs, observability systems, and durable workflow engines all validate the same lesson: fast/powerful derivative surfaces are only trustworthy when they say their source cut, serving lane, posture, stale fence, and receipt path.

But none of those sources justify freezing a canonical backend or universal semantic taxonomy for Helm now.

## Decision

Helm will define a **specimen grammar** before choosing a canonical datacube backend.

The first specimen grammar must cover:
- saved view object,
- exact front-door handle,
- door pack manifest,
- restricted imported arrival,
- peek panel,
- triage lane item,
- review queue item,
- patrol route,
- promotion receipt,
- same-object five-truths inspector.

## Consequences

### Positive

- Helm gets a product-testable target instead of a storage debate.
- The seven pillars stay stable.
- Door packs and patrol routes become concrete enough to prototype.
- Local analytics can be explored without engine religion.
- SlopOS boundary discipline is translated into operator-facing truth rather than copied wholesale.

### Negative

- Backend questions remain open.
- Some architecture documents will still feel vocabulary-heavy until a UI specimen exists.
- A specimen contract may need revision after real interaction design pressure.

### Non-decisions

This ADR does not select:
- a semantic layer,
- a metric grammar,
- a table format,
- a database,
- a queue implementation,
- a local-first sync engine,
- an agent authority model,
- or a universal workspace object.

## Reopen if

- a small specimen cannot be built without choosing a backend;
- the watchrail grammar makes the UI feel like infrastructure jargon;
- operators still confuse live/saved/cut/derived/receipt lanes;
- imported/adopted, preview/action, cached/live, or reviewed/promoted remain unclear after specimen testing.
