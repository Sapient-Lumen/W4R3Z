# ADR 0053 — Portal layer registry before proof-stack runtime

Status: accepted-for-proof-fixture

Decision: add a portal layer registry and checker as an audit/refactor surface.

Reason: the portal-net specimen now has many peer proof packs. A central registry prevents silent drift in pack paths, schemas, checkers, docs, ADRs, classification schemes, counts, and companion action ref keys without creating a runtime or workflow engine.

Non-decisions: proof-stack runtime, registry service, documentation generator, schema registry service, workflow engine, backend, policy engine, global memory, and new pillar.
