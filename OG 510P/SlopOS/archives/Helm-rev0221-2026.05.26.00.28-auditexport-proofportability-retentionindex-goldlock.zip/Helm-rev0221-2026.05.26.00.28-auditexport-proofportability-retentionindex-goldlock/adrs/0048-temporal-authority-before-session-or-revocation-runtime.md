# ADR 0048: temporal authority before session or revocation runtime

Status: accepted for rev0214

## Context

After rev0212, Helm can show resource/body shape and downstream effect propagation for the portal-net companion specimen. The next failure mode is temporal overclaim: an approval, volition token, callback, retry window, retention budget, schema descriptor, membership epoch, or dedupe window may look reusable after it has expired or been revoked.

## Decision

Add `fixtures/portal-net-consent-export/temporal-authority-pack.json`, `schemas/temporal-authority-pack.schema.json`, and `tools/check_temporal_authority_pack.py` before building any session manager, token service, revocation service, callback runtime, policy engine, workflow engine, backend, or SlopOS portal implementation.

## Consequences

Helm can render an expiry/revocation/epoch strip and refuse stale temporal claims without importing enforcement. SlopOS remains the owner of admission, order validity, exact replay/dedupe, and durable receipts.

## Non-decisions

No session runtime, revocation registry, authorization server, token introspection service, clock service, callback runtime, retry scheduler, policy engine, workflow engine, backend, global memory, or new pillar is introduced.
