# ADR 0047: Effect propagation before event runtime

Status: accepted as candidate proof fixture in rev0212

## Context

rev0211 proved resource/body shape. That still leaves an effect seam: a correct payload can create unlisted notifications, webhook fanout, billing/quota spend, deletion cascades, permission grants, follow-on jobs, subscriptions, external recipients, callback drift, or missing postcondition evidence.

## Decision

Add `effect_propagation_pack` to the portal-net companion specimen and validate it with `tools/check_effect_propagation_pack.py`.

## Consequences

Helm now has a checked strip for primary effect, side-effect inventory, callbacks/webhooks, billing/quota, deletion cascades, permission grants, jobs/subscriptions, external recipients, idempotency effect, downstream trace, and postcondition receipt. The strip is evidence and product copy; it is not authorization, consent, policy, live truth, event-bus delivery, tracing success, billing approval, workflow completion, or SlopOS admission.
