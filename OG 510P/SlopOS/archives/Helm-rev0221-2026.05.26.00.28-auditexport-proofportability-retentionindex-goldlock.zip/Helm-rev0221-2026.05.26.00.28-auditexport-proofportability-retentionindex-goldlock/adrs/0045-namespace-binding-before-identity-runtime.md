# ADR 0045: Namespace binding before identity runtime

Status: accepted
Date: 2026-05-22
Revision: rev0210

## Context

rev0209 proved capability provenance across shared surfaces and delegation. That still leaves a dangerous gap: a valid actor, session, and fresh gesture may point at the wrong account, tenant, workspace, destination, issuer, audience, endpoint, environment, or subject namespace.

## Decision

Add a checked namespace/audience binding pack before any identity runtime, OAuth/OIDC/MCP adapter, authorization server, namespace registry, endpoint ownership protocol, redirect policy engine, or backend implementation.

## Consequences

Helm must show namespace binding as evidence, not authority. Wrong namespace, stale membership, redirect rebinding, audience mismatch, endpoint-owner uncertainty, tenant alias collision, staging/prod issuer mix-up, and cross-tenant subject collisions must block, refuse, quarantine, or require a fresh authority diff before SlopOS admission.

## Non-decisions

No namespace runtime, identity provider, OAuth adapter, OIDC adapter, MCP adapter, authorization server, endpoint ownership protocol, redirect policy engine, workflow engine, policy engine, backend, global memory, or new pillar is added.
