# ADR 0024: Lane transition contracts before workflow engine

Status: accepted
Date: 2026-05-13

## Context

rev0188 made Helm's specimen cube queryable by surface affordance cards. That prevents static UI lies: wrong chip, wrong button, hidden weakness, missing invalidator, missing gate.

The next risk is dynamic: a user presses an honest button and the target surface silently changes truth class, drops its cut, hides its basis, or turns a receipt into live truth.

## Decision

Admit `lane_transition_contract` as a fixture-side proof object and add the first release-readiness promotion drill.

A transition contract must name source event, target event, transition verb, source/target truth lane, required prior events, gates, preserved fields, forbidden mutations, operator copy, failure mode, and weaker-than policy.

## Consequences

- Helm can now test product motion, not just static card truth.
- The Release readiness specimen can prove a path through saved view, patrol route, review queue, fresh recheck, promotion receipt, and Recall history.
- The checker can catch hidden promote paths, live/receipt collapse, missing gates, and missing weakness posture.
- Helm still avoids choosing a workflow engine, backend, query language, semantic-layer product, or new pillar.

## Non-decisions

- no production workflow runtime;
- no canonical event store;
- no storage engine;
- no table/lake format;
- no permission model;
- no full SlopOS boundary family import.

## Reopen trigger

Reopen if a second specimen cannot reuse the contract shape, or if the contract shape starts to look like a disguised workflow engine rather than a proof fixture.
