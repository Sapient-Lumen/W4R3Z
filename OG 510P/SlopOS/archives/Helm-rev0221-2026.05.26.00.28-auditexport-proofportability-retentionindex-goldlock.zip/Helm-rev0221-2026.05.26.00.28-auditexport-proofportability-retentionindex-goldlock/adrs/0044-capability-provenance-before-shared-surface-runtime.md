# ADR 0044 — Capability provenance before shared-surface runtime

Status: accepted for Helm rev0209.  
Date: 2026-05-22.

## Context

rev0208 proved continuity across surfaces. That still leaves a harder question: a surface can be continuous while the actor, account subject, device profile, delegation state, or token provenance changes.

## Decision

Add `capability-provenance-pack.json`, schema, checker, classification pins, architecture note, and assurance invariants before any shared-surface runtime.

## Consequences

Helm can now show why a card is blocked or rechecked on a shared device, borrowed device, family profile, kiosk, screen-share surface, remote-control channel, service account, copied receipt, revoked delegate, or orphaned token. The strip is not authority and cannot approve, arm, replay, or expand a `portal.net.request`.

Deferred: shared-surface runtime, auth protocol, passkey binding, OAuth/MCP adapter, authorization server, policy engine, workflow engine, backend, global memory, and new pillar.
