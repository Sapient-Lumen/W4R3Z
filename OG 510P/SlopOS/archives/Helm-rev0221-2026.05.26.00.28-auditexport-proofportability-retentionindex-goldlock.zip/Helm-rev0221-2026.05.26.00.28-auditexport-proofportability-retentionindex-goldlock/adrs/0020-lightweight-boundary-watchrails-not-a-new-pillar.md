# ADR 0020: Lightweight boundary watchrails, not a new pillar

Status: accepted as a proof-order ratchet
Date: 2026-05-13

## Context

Helm has been converging on a stable seven-pillar shell plus one nearby Terminal/Capshell front-end family.
The latest datacube work made saved view objects, exact front-door handles, restricted imported arrivals, triage lanes, compare/review/promote exits, door packs, patrol routes, peeks, and review queues more concrete.

SlopOS is simultaneously developing stronger boundary-family machinery.
That machinery is valuable, but SlopOS is still in design phase and Helm is a desktop shell product, not the SlopOS assurance archive.

The question is whether Helm should:

1. add a new pillar,
2. import SlopOS boundary-family machinery wholesale,
3. choose a data/semantic backend,
4. or add a smaller honesty surface.

## Decision

Helm will add a **lightweight boundary watchrail card** as a proof-order ratchet.

The card is required for serious new Helm datacube specimens, especially:
- saved views,
- door packs,
- patrol routes,
- peek/glance surfaces,
- triage lanes,
- review queues,
- imported arrivals,
- promoted/published artifacts,
- and action/flow outputs.

The card must disclose:
- subject family,
- exact subject reference or weaker descriptor,
- source cut,
- serving lane,
- personal/shared/imported/restricted/adopted/published posture,
- promotion path,
- stale fences,
- and receipt/lineage path.

## Non-decision

This ADR does not choose:
- a new pillar,
- a universal workspace/dashboard,
- full SlopOS boundary-family coverage gates,
- a semantic layer product model,
- DuckDB/DuckLake/Iceberg/Delta/Lance/Arrow/etc. as canonical backend,
- or an agent authorization plane.

## Consequences

Positive:
- Helm can make powerful adjacent surfaces without hiding basis, freshness, source, or authority.
- Door packs and patrol routes become safer and more premium.
- Omnibox, Object Browser, Operations Center, Recall, Exchange, Desktop Flow, and Tiling Shell share one tiny truth vocabulary.
- SlopOS's best habit is preserved without importing its full process weight.

Negative / cost:
- Every serious surface needs a little more metadata.
- Designers must keep chip language humane rather than turning it into infrastructure jargon.
- The vocabulary may need revision after specimens reveal missing classes.

## Follow-through

Build one proof specimen:
- one saved view,
- one door pack,
- one patrol route,
- one restricted imported arrival,
- one peek,
- one review queue item,
- one promotion receipt.

Every object in the loop should show the same watchrail card at chip / popover / inspector depth.
