# ADR 0061: Portal retention index before privacy or proof runtime

Date: 2026-05-26T00:28:00-04:00
Status: Accepted for rev0221 audit/refactor surface

## Context

The portal proof stack now contains many evidence-bearing strips. Retention
posture exists across most cases, but drift can hide copy inventory, expiry,
minimization, or sweep-witness state.

## Decision

Admit a recomputed portal retention index as cube hygiene. It audits retention
posture across registered layers without becoming policy, deletion proof,
consent, authority, or runtime.

## Non-decisions

No privacy runtime, deletion protocol, retention scheduler, DLP engine,
proof-portability runtime, policy engine, workflow engine, backend, global
memory, or new pillar is admitted.
