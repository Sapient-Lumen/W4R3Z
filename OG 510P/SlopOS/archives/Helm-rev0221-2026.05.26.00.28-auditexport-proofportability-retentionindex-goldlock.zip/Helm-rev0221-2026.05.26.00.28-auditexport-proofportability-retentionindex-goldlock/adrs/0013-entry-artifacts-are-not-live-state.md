
# ADR-0013: entry artifacts are not live state

## Status
Accepted

## Context

Helm now has multiple saved or selection-oriented continuity objects nearby:
- capsules,
- layout templates,
- typed seeds,
- activity cockpit candidates,
- and possible future entry kits.

Outside tools also keep showing strong appetite for saved task-entry artifacts:
workspaces, profiles, layouts, and quick-launch arrangements.
At the same time, SlopOS keeps pressing the opposite of a common desktop lie:
request keys, issued descriptors, launch admission, and historical receipts should not quietly become current mutable truth.
Schell's launch-kit work sharpens the same point for shell-facing task entry.

## Decision

Helm freezes one narrow cross-cutting rule:
**saved entry artifacts are guidance, history, or planned shape unless Helm has reacquired live evidence; selecting them does not by itself prove current live state.**

This is not a final launch-kit schema.
It is a posture that should pressure Recall, Tiling Shell, Omnibox, Overview, Operations Center, activity cockpit cards, and future activity entry kits.

## Consequences

Good:
- Helm can add better task-entry objects without regressing into fake session folklore
- capsules, templates, cockpit cards, and entry kits can cooperate more cleanly
- attach / restore / relaunch / fresh-launch ladders become easier to keep honest

Bad:
- some saved-setup UX will need sharper wording and more explicit badges than ordinary workspace tools use
- early prototypes may feel less magically "done" because they will be forced to show uncertainty or missing live basis
