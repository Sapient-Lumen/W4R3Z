# ADR 0046: Resource shape before payload runtime

Status: accepted as candidate proof fixture in rev0211

## Context

rev0210 proved namespace/audience binding. That still leaves a payload seam: a correct endpoint can receive the wrong body, too many fields, stale attachments, an expanded row set, a mislabeled MIME body, a compressed archive with hidden members, or a derived summary masquerading as the original payload.

## Decision

Add `resource_shape_pack` to the portal-net companion specimen and validate it with `tools/check_resource_shape_pack.py`.

## Consequences

Helm now has a checked strip for schema, projection, attachment inventory, row scope, transform lineage, query parameter freeze, archive inventory, and response-shape drift. The strip is evidence and product copy; it is not authorization, policy, payload truth, a DLP engine, a schema validator service, an API gateway, or SlopOS admission.
