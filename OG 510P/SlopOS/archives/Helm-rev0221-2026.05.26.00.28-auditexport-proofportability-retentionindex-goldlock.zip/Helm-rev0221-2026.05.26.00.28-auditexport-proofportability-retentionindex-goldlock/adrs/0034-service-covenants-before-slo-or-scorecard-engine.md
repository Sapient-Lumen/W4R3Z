# ADR 0034 — Service covenants before SLO or scorecard engine

Status: accepted  
Date: 2026-05-18  
Revision: rev0199

## Context

rev0198 introduced obligation ledgers. The next temptation is to summarize obligations with a health score, SLO, alert, service catalog component, or ticket dashboard. That would be premature and would risk hiding the one breached promise behind a green aggregate.

## Decision

Admit `service_covenant` as a candidate proof-fixture object.

A service covenant records a bounded operating promise, its evidence window, breach triggers, repair rhythm, owner/accountable party, scorecard fences, visible copy, and source obligations.

## Consequences

- Helm can render covenant chips and repair commands without choosing an SLO engine.
- Helm can show breach/paused/at-risk/observing/kept posture without claiming release readiness.
- Helm can reuse SRE/scorecard/alerting/catalog ideas while keeping source obligations openable.
- Rollups are navigation-only in v0.

## Non-decisions

No SLO engine, scorecard engine, service catalog, ownership registry, alerting/incident platform, ticketing engine, workflow runtime, policy engine, ranking engine, cost engine, backend, query language, semantic layer, table format, global memory, or new pillar is selected.
