# ADR 0051: Interpretation/readback before comprehension runtime

Status: accepted candidate for rev0216.

## Context

rev0215 added presentation-integrity strips for redaction, badges, visual diffs, screenshots, clipboard, assistive copy, localization, and spoofed surface chrome. That is necessary but insufficient. A correct display can still be misunderstood, summarized incorrectly, translated too weakly, narrated incompletely, or read back with the wrong destination/payload/effect.

## Decision

Add `interpretation-readback-pack.json`, a schema, a checker, documentation, and classification pins before any runtime. The proof pack covers summary fidelity, plain-language copy, exact-copy availability, localized warning match, assistive narration completeness, high-impact readback, ambiguity routing, jargon/glossary coverage, and generated-summary overclaim quarantine.

## Consequences

- Helm may render interpretation/readback strips beside portal-net rows.
- Helm may refuse or quarantine summaries/readbacks that change material facts.
- Helm still may not treat summary, readback, confidence, glossary, translation, or assistive narration as authority.
- Helm still does not ship a comprehension engine, readback runtime, AI summarizer runtime, localization runtime, accessibility engine, glossary engine, policy engine, workflow engine, backend, global memory, or new pillar.

