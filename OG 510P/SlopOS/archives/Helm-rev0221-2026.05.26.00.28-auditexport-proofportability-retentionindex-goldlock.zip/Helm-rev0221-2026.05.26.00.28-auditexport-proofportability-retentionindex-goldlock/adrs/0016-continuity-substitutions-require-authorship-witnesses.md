# ADR-0016 — continuity substitutions require authorship witnesses

## Status

Accepted — rev0015.

## Context

Helm already froze:
- request-vs-live truth,
- entry-artifact truth,
- binding-witness posture,
- and activity-scope truth.

That solved several important continuity lies,
but one dangerous move remained easy:
a continuity surface could admit that a join was repaired or that scope changed,
while still hiding who proposed,
chose,
or executed the substitute path.

SlopOS keeps refusing silent concrete-target choice across handler-selection,
session-selection,
exact-reveal,
and request-state seams.
Schell keeps pressuring authorship badges,
review lanes,
restore honesty,
launch-kit honesty,
and exact handoff bundles.
DelayBasin's authorship-witness / autonomy-posture discipline makes the missing refinement explicit.

## Decision

Helm freezes one narrow posture:

**when Helm repairs,
widens,
switches,
reuses,
or delegates continuity,
it should not hide who proposed,
chose,
or executed that move.**

This does **not** require a full autonomy constitution,
a giant review bureaucracy,
or one total theory of every collaborative lane.
It only says continuity substitutions should not launder authorship.

## Consequences

Positive:
- entry kits,
cockpits,
Recall cues,
binding witnesses,
and scope witnesses gain a clearer honesty rule
- AI-rich or helper-rich continuity surfaces are less likely to inherit operator authorship by fluency alone
- future continuity choice witnesses now have a firm cross-cutting reason to exist

Negative / cost:
- some continuity surfaces will need one more tiny witness or inspect path instead of a flatter repaired/same-activity badge
- the archive still needs to learn the smallest good continuity choice witness rather than merely naming the rule

## What remains open

- the smallest reusable continuity choice witness shape
- which role lanes deserve default visibility versus inspect-only detail
- which continuity substitutions should remain proposal-only until explicit approval
- how continuity choice witnesses should compose with binding and scope witnesses without becoming clutter
