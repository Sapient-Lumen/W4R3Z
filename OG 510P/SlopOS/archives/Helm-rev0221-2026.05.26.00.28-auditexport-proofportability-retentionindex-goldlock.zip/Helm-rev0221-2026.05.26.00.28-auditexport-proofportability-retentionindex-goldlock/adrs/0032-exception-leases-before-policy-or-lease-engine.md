# ADR 0032: Exception leases before policy or lease engine

Status: Accepted  
Date: 2026-05-16

## Context

rev0196 added counterexample dockets so learned behavior can be challenged. The next risk is exception laundering: a temporary waiver, mute, quarantine extension, or hold can quietly become approval, policy, or folklore if Helm has no small record for ownership, scope, expiry, renewal, and residue.

Older Helm notes already had an exception witness and waiver lease pressure map. SlopOS adds a useful companion lesson: lease/grant descriptors are exact issued-bounds evidence, not current live grant truth. Outside systems reinforce the shape: Vault leases carry TTL/renew/revoke semantics; Kubernetes finalizers block deletion until cleanup; LaunchDarkly lifecycle stages keep temporary flags from becoming debt; PagerDuty/New Relic suppression keeps underlying events or policies visible while muting notifications; GitHub bypass requests keep bypass reviewable; OPA decision logs keep decision context for audit/debug.

## Decision

Add `exception_lease` as a proof-fixture object before choosing a policy engine, exception governance console, generic lease manager, alerting platform, workflow runtime, approval engine, feature-flag control plane, backend, semantic layer, table format, global memory store, or new pillar.

## Consequences

- Every release-readiness counterexample case now has one exception lease.
- Leases cover active, denied, expired, and redeemed postures.
- Each lease names the interrupted rule, grant/denial source, scope, expiry, renewal posture, underlying truth, forbidden strong effects, and expiry behavior.
- Lease descriptors prove issued exception bounds only; they do not prove current live grant state.
- Temporary exception truth stays separate from compliance, readiness, approval, publication, policy, and global memory.

## Deferred

- policy/rule engine;
- generic lease manager;
- exception governance console;
- alerting/incident platform;
- feature-flag lifecycle platform;
- approval engine;
- workflow runtime;
- global memory inheritance;
- backend/query/table/semantic layer;
- new pillar.
