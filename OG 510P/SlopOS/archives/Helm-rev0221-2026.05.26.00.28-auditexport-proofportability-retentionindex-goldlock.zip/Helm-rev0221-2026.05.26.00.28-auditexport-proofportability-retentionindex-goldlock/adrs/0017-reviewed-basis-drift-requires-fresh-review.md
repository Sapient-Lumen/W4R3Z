# ADR-0017 — reviewed basis drift requires fresh review

## Status

Accepted — rev0016.

## Context

Helm already froze:
- request-vs-live truth,
- entry-artifact truth,
- binding-witness posture,
- activity-scope truth,
- and continuity-switch authorship truth.

That solved several important continuity lies,
but one dangerous move remained easy:
a surface could stay honest about saved-vs-live posture,
join basis,
scope,
and chooser,
while still letting an old review or strong-action affordance silently carry onto newer mutable state.

SlopOS already has the sharpest local teacher for this in its approval-basis posture:
approval binds one exact action and does not silently follow a newer mutable basis.
Schell is now directly pressuring basis packets,
compare-and-set review,
and stale-basis refusal.
DelayBasin keeps pushing the archive toward exact basis witnesses and fail-closed stale paths instead of flattering carry.

## Decision

Helm freezes one narrow posture:

**when a strong shell-facing action depends on reviewed mutable basis,
that basis should not silently follow a newer state.
Basis drift requires fresh review or a weaker next step.**

This does **not** require a global approval cache,
a giant workflow system,
or a final compare-and-set algebra.
It only says strong actions should not inherit floating latest-state legitimacy.

## Consequences

Positive:
- saved-task and task-return surfaces gain a clearer honesty rule
- entry kits,
cockpits,
Recall,
route cards,
and receipt-derived actions become less likely to overclaim
- future basis packets now have a firm cross-cutting reason to exist

Negative / cost:
- some strong-action surfaces will need a small inspect/review-again/hold ladder instead of a flatter continue button
- the archive still needs to learn the smallest good basis packet rather than merely naming the rule

## What remains open

- the smallest reusable basis packet shape
- which basis fields should be visible by default versus inspect-only
- when fresh bind is enough versus when full review again is required
- whether any future force/override path is worth admitting on shell-owned strong actions

