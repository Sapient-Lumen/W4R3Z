# ADR-0012: request-vs-live truth is a cross-cutting freeze

## Status
Accepted

## Context

Helm's current best ideas increasingly depend on rich cards and continuity surfaces:
rehearsal cards, capsule diffs, layout rebinding, richer provider cards, and possible activity cockpit cards.

That richness is valuable, but it also creates a common failure mode:
products begin to blur proposal, launch, restore, and current observation into one flattering success story.
SlopOS keeps pressuring the opposite lesson through exact reveal, request-state honesty, recent-items boundaries, launch-completion boundaries, and durable-status boundaries.

## Decision

Helm freezes one narrow cross-cutting rule:
**requested truth, admitted truth, live truth, and historical truth must not silently collapse into one another on strong-action or continuity surfaces.**

This is not a giant universal state machine.
It is a posture that should pressure Omnibox, Recall, Exchange, Operations Center, Desktop Flow, and future cockpit surfaces.

## Consequences

Good:
- Helm can add richer cards without losing honesty
- Recall and Exchange get a clearer shared truth model
- Overview and future cockpit surfaces are less likely to become glamorous lie surfaces

Bad:
- some apparently “simple” UX will now need sharper wording and status distinctions
- prototypes that only model a happy path will look less complete than they first expected
