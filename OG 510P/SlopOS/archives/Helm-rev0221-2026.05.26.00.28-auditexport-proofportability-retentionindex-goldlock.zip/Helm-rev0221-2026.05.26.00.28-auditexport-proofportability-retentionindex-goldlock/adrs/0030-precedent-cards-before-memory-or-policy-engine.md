# ADR 0030: Precedent cards before memory or policy engine

Status: Accepted  
Date: 2026-05-15

## Context

rev0194 settlement packets closed local consequence without laundering closure into approval. The next ambiguity is learning. Once Helm records a refusal, quarantine, review cut, or recall pin, the product should become smarter the next time a similar shape appears. But “learned” is dangerous: it can silently become law, policy, global memory, or invisible personalization.

Older Helm notes already wanted activity memory seeds and context recipes. The new settlement discipline lets us revive that idea safely: source settlement first, scope second, non-authority always visible.

Outside systems reinforce the split. Git rerere records and reuses conflict resolutions, but still exposes enablement and forget/abort operations. Sentry grouping uses fingerprints to cluster events, but grouping is not the same as correctness. OpenTelemetry and OpenFeature show the value of explicit context keys and precedence. OPA decision logs, Kubernetes finalizers, in-toto links, and Temporal message handling show that small durable crumbs beat magic memory.

## Decision

Add `precedent_card` as a proof-fixture object before choosing any memory engine, recommender, policy engine, rule engine, workflow runtime, feature-flag control plane, backend, semantic layer, table format, global attestation store, or new pillar.

## Consequences

- Every release-readiness settlement packet now has a scoped precedent card.
- Precedent cards may warn, suggest, prefill, rank, or annotate.
- First-pass cards may not auto-apply or unlock strong verbs.
- Default candidates require explicit adoption.
- Source settlement, scope, expiry, revalidation, revocation, and escape hatch become checkable.
- The old activity-memory-seed idea remains useful but narrowed by settlement non-authority.

## Deferred

- actual memory engine;
- recommender/ranking engine;
- rule/policy engine;
- cross-activity memory inheritance;
- team-wide default promotion;
- counterexample-led auto-demotion;
- global attestation store;
- backend/query/table/semantic layer;
- new pillar.
