# ADR-0018 — delegated or background work requires explicit adoption

## Status

Accepted — rev0017.

## Context

Helm already froze:
- request-vs-live truth,
- entry-artifact truth,
- binding-witness posture,
- activity-scope truth,
- continuity-switch authorship truth,
- and reviewed-basis truth.

That solved several continuity and strong-action lies,
but one dangerous move remained easy:
a delegated helper,
background lane,
or repair surface could still write straight into the operator's authoritative live activity and only explain itself afterward.

SlopOS already supplies the best local teaching for exact mutable basis and repair-before-effectful-ready posture.
Schell is now directly pressuring proposal-only repair,
exact handoff bundles,
and launch/cockpit honesty.
DelayBasin keeps pushing toward shadow-vs-authoritative separation and non-authoritative sinks.

## Decision

Helm freezes one narrow posture:

**when delegated,
background,
or repair work produces mutable candidate state,
that work should not silently become authoritative live activity.
It should stay isolated until the operator or another clearly named surface explicitly adopts it.**

This does **not** require a universal branch manager,
a giant merge UI,
or a final collaboration constitution.
It only says helpful work should not become hidden live-lane mutation.

## Consequences

Positive:
- richer background and delegated help now have a clear honesty boundary
- basis packets,
  continuity witnesses,
  and task-return surfaces gain a better place to land candidate work
- Helm can become more magical without becoming more ambient

Negative / cost:
- some helper flows will need a compact adoption/reject/hold ladder instead of a flat auto-apply path
- the archive still needs to learn the smallest good shadow-lane specimen rather than merely naming the rule

## What remains open

- the smallest reusable shadow work lane shape
- when tiny suggestions can stay inline rather than opening a side lane
- which adoption steps deserve default visibility versus inspect-only detail
- whether any future force/override adoption path is worth admitting on shell-owned surfaces
