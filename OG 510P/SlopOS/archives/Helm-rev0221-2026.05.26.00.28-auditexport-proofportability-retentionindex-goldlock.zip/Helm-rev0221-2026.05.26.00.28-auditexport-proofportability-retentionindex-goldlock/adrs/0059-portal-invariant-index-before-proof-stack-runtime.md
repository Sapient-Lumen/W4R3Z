# ADR 0059 — Portal invariant index before proof-stack runtime

Status: accepted for rev0221.  
Date: 2026-05-26T00:28:00-04:00.

## Context

The portal-net proof stack now contains many checked layers. Each layer carries invariants, forbidden effects, and non-authority vocabularies. Without a central audit surface, these lists can drift independently.

## Decision

Add `portal-invariant-index.json` and `tools/check_portal_invariant_index.py`. The index is generated from registered layer packs and validates invariant, must-not, and non-authority coverage by layer.

## Consequences

The index improves cube hygiene and reviewability. It is not policy, authority, runtime order, consent, or proof that any action is safe.
