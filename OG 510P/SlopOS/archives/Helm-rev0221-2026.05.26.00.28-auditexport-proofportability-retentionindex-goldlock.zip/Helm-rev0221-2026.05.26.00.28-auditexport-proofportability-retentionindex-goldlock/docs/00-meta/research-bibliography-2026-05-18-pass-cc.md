# Research bibliography — pass CC — 2026-05-18

Revision: rev0200

- Google SRE Workbook — Alerting on SLOs — https://sre.google/workbook/alerting-on-slos/
- Google SRE Workbook — Implementing SLOs — https://sre.google/workbook/implementing-slos/
- Kubernetes — API Priority and Fairness — https://kubernetes.io/docs/concepts/cluster-administration/flow-control/
- GitHub Docs — Managing a merge queue — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
- GitLab Docs — Merge trains — https://docs.gitlab.com/ci/pipelines/merge_trains/
- OpenCost Specification — https://opencost.io/docs/specification/
- Datadog Docs — SLO burn rate alerts — https://docs.datadoghq.com/service_level_objectives/burn_rate/
- Datadog API Docs — SLO Status Corrections — https://docs.datadoghq.com/api/latest/service-level-objective-corrections/
- SlopOS `budget-lease-schema-v0.md`
- SlopOS `budget-payer-semantics-v0.md`
- SlopOS `capshell-scheduling-posture-v0.md`
- SlopOS `cpu-capacity-authority-boundary-v0.md`
