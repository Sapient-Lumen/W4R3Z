# Research bibliography — 2026-03-23 — pass XCVII

- XDG Desktop Portal documentation — FileChooser
  - used for: chooser-owned file access,
    portal-mediated grants,
    and explicit persistence hooks through the Documents portal
- XDG Desktop Portal documentation — Documents portal
  - used for: controlled file exposure,
    restricted mount semantics,
    and explicit document-store persistence posture
- VS Code documentation — Workspace Trust / Restricted Mode
  - used for: productive restricted-first posture,
    visible trust chrome,
    and disabling higher-risk features until trust is granted
- Apple Support — Quick Look on Mac
  - used for: preview as a first-class workflow rather than a dead-end affordance
- Microsoft Support — File Explorer disables preview for internet-downloaded files
  - used for: preview as a real security boundary,
    not an automatically harmless act
- Figma Help Center — Guide to branching
  - used for: compare side-by-side or overlay,
    review,
    and approve/merge posture
- Figma Help Center — Review branch changes
  - used for: review summaries,
    suggest-changes posture,
    and explicit approval workflow
- VS Code documentation — Terminal Shell Integration
  - used for: command detection,
    working-directory detection,
    decorations,
    and navigation from semantic terminal landmarks
- WezTerm documentation — Shell Integration
  - used for: OSC 7 / OSC 133 / OSC 1337,
    prompt/input/output zoning,
    and command-output navigation
- iTerm2 documentation — Shell Integration
  - used for: marks,
    command status,
    recent directories,
    and explicit prompt / output boundaries
- Raycast documentation — Quicklinks / Shared Quicklinks
  - used for: personal-versus-shared accelerators,
    import posture,
    and parameterized quick starters
- Plan 9 documentation — plumbing
  - used for: typed routing ancestry and non-authoritative message dispatch
- SlopOS RFC 0031 — powerbox / consent mediators and capability UX
  - used for: chooser-owned designation,
    reviewable grants,
    and anti-confused-deputy law
- SlopOS RFC 0046 — workflow plumbing + portals
  - used for: capability-safe routing,
    portal front doors,
    and non-authoritative plumb envelopes
- SlopOS RFC 0053 — origin, quarantine, and safe-open
  - used for: foreign-arrival posture,
    safe-open separation,
    and preview-versus-open honesty
- SlopOS RFC 0069 — capability diffs for consent + receipts
  - used for: typed review objects,
    approval diff posture,
    and aftermath receipts
- SlopOS RFC 0089 — document portal + durable file handles
  - used for: explicit persistence posture and handle-bearing front doors
- SlopOS RFC 0117 — plumb messages + CLI intents
  - used for: typed routing envelopes and CLI/GUI substrate discipline
