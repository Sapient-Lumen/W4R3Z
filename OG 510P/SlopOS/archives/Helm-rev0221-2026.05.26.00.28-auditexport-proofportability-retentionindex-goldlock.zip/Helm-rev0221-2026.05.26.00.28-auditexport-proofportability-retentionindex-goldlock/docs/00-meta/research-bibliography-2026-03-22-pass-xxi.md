# Research bibliography — 2026-03-22 pass XXI

Official/public sources consulted in this pass:

- VS Code Docs — Manage chat sessions  
  https://code.visualstudio.com/docs/copilot/chat/chat-sessions
- VS Code Docs — Revert changes with checkpoints and editing requests  
  https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- VS Code Docs — Using agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code Docs — December 2025 (version 1.108) / Copy breadcrumbs path  
  https://code.visualstudio.com/updates/v1_108
- VS Code Docs — February 2026 (version 1.110) / Fork a chat session  
  https://code.visualstudio.com/updates/v1_110
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — PowerToys Command Palette overview  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Airtable Support — Getting started with Airtable views  
  https://support.airtable.com/docs/getting-started-with-airtable-views
- Airtable Support — Using the view share menu in Airtable  
  https://support.airtable.com/docs/using-the-view-share-menu-in-airtable
- Airtable Support — Airtable Sync Integrations Overview  
  https://support.airtable.com/docs/airtable-sync-integrations-overview
- Linear Docs — Custom Views  
  https://linear.app/docs/custom-views
- Linear Docs — Favorites  
  https://linear.app/docs/favorites
- Linear Docs — Projects  
  https://linear.app/docs/projects
- Notion Help — Using database views  
  https://www.notion.com/help/guides/using-database-views
- Notion Help — Layouts  
  https://www.notion.com/help/layouts
- Notion Help — Database templates  
  https://www.notion.com/help/database-templates
- Figma Help — Guide to Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Figma Help — Compare changes in Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Figma Help — Dev Mode statuses and notifications  
  https://help.figma.com/hc/en-us/articles/26781702258583-Dev-Mode-statuses-and-notifications
