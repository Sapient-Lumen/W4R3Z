# Research bibliography — 2026-03-23 — pass XCVIII

- Arc Help Center — Little Arc: Quick Lookups & Instant Triaging
  - used for: temporary weak browsing windows,
    triage posture,
    and explicit move-into-sidebar promotion
- Arc Help Center — Peek: Preview Sites From Pinned Tabs
  - used for: keep-place preview posture and quick-action weak windows
- Arc Help Center — Air Traffic Control: Automate Your Link Routing
  - used for: route rules,
    weak default arrival,
    and exact activity/space overrides
- PowerToys documentation — Workspaces utility
  - used for: activity-shaped launch bundles,
    capture/relaunch posture,
    and exact desktop-state starters
- PowerToys documentation — Command Palette Dock
  - used for: persistent tiny command surfaces pinned to the screen edge
- PowerToys documentation — Adding Dock support to your extension
  - used for: dock bands as atomic strips and pinning nested commands
- PowerToys documentation — Peek utility
  - used for: fast system-level preview without full application open
- VS Code documentation — Workspace Trust / Restricted Mode
  - used for: productive restricted-first posture and explicit capability gating
- VS Code documentation — VS Code for the Web
  - used for: lightweight safer browse/edit lanes with explicit limitations and upgrade path
- VS Code July 2025 release notes — Chat checkpoints
  - used for: exact restore points for assisted or review-heavy work
- Warp documentation — Blocks
  - used for: command/output grouping,
    bookmarkable units,
    and input-output distinction
- Warp documentation — Notebooks
  - used for: searchable runnable documentation kept near terminal action
- Obsidian Help — Bases
  - used for: multiple editable,
    filterable,
    sortable views over one corpus
- Ghostty documentation — Shell Integration
  - used for: shell-owned prompt marks and navigation affordances
- Ghostty documentation — Secure input indication
  - used for: shell-owned sensitive-input signaling and compact trust chrome
- Apple Support — Quick Look on Mac
  - used for: preview as a real first-class workflow
- Microsoft Support — File Explorer disables preview for internet-downloaded files by default
  - used for: preview as a real boundary rather than an automatically harmless act
- Figma Help Center — branching and review docs
  - used for: compare / review / promote lanes before stronger landing
- XDG Desktop Portal documentation — FileChooser and Documents portal
  - used for: chooser-owned front doors,
    controlled persistence,
    and bounded document exposure
