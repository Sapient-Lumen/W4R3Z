# Research bibliography — 2026-03-23 — pass XCIX

- PowerToys documentation — Workspaces utility
  - used for: saved launch bundles,
    captured desktop structure,
    arguments on relaunch,
    and shortcut-pinned front doors
- Warp documentation — Launch Configurations
  - used for: saved windows/tabs/panes as explicit named starters,
    plus UI-and-YAML configuration
- Warp documentation — Session Restoration
  - used for: local restoration of windows/tabs/panes plus recent command-output blocks,
    and the distinction between saved launch structure and restored prior work
- Windows Terminal documentation — Startup settings / persistedWindowLayout
  - used for: layout-only restore semantics,
    saved pane/profile structure,
    and clear limits on restored content
- iTerm2 documentation — Session Restoration
  - used for: stronger reconnective restoration via long-lived servers,
    showing that restoration can sometimes be genuinely live
- GitHub Docs — viewing all issues and pull requests / saved views
  - used for: saved-view objects as first-class cross-repository monitoring surfaces
- Obsidian Help — Bases
  - used for: multiple editable views over one local corpus,
    saved as `.base` files or embedded blocks
- Obsidian Help — Workspaces
  - used for: task-shaped saved application layouts distinct from view objects
- VS Code documentation — Profiles
  - used for: profile-per-workspace associations,
    new-window-with-profile,
    export/import,
    and previewable profile adoption
- VS Code December 2025 release notes — import profile by drag and drop
  - used for: import-preview posture for shareable profile-like bundles
- VS Code documentation — VS Code for the Web
  - used for: lightweight,
    sandboxed browse/edit lane with explicit upgrade path to stronger environments
- PowerToys documentation — Command Palette Dock
  - used for: tiny persistent pinned command surfaces and dock bands
- Linear Docs — Triage
  - used for: named triage inboxes near the main workflow
- Figma Help Center — Guide to branching
  - used for: compare / review / promote,
    side-by-side or overlay review,
    merge flow,
    and checkpoint-bearing stronger landing
