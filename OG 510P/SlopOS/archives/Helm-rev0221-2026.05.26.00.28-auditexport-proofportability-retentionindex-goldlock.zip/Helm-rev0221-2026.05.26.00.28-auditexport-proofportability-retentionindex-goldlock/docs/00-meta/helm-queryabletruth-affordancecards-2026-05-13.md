# Helm queryable truth and affordance cards — 2026-05-13

Status: rev0188 research/design synthesis.

## Thesis

rev0187 proved that a Helm specimen can be recorded.
rev0188 asks the harder product question: can the record decide what the user is allowed to see and do?

The answer should be yes, but only for a bounded proof fixture.
Do not choose a backend yet.
Do not invent a global UI framework yet.
Do not add a pillar.

Add a small bridge:

> **surface affordance card = event record + visible chip + allowed next verbs + forbidden verbs + explanation + receipt/recheck gate**

This is the missing joint between the datacube and Helm's product feel.

## Why this is the next seam

The specimen cube can validate field shape, but product collapse usually happens one layer above data:

- a stale row gets a green-looking button;
- a receipt is shown like current truth;
- a cached summary hides its build cut;
- an imported packet is useful but the UI makes it look local;
- a review queue item was once reviewed, but the source definition moved;
- Recall shows history without saying whether the old state is live now.

The fix is not more schema.
The fix is **queryable affordance law**.

## Decision pressure from outside

Modern semantic layers show that reusable definitions are valuable, but Helm must not let a definition front door become a truth claim. Metric views, dbt metrics, and Cube models all reinforce definition reuse; Helm's contribution is to keep the definition revision, source cut, and serving lane visible.

Table formats and lake/catalog systems show that exact snapshots, branches, tags, and commits matter. Helm should steal their named-reference humility while refusing to pick a table format prematurely.

OpenLineage and OpenTelemetry show the value of small contextual records and correlation. Helm should steal facets and causal context, not ambient surveillance.

Precomputation systems show that users love speed. Helm should steal refresh keys, build cuts, and static snapshots, not invisible freshness.

Local-first systems show that shaped sync and local materializers can make interfaces feel instant. Helm should steal shape/sync posture and deterministic materializers, not fake global consensus.

Triage and merge-queue systems show that staging, rejection reasons, revalidation, and queue receipts are product gold. Helm should steal that without becoming a developer tool.

## Lessons from companion archives

### SlopOS

Keep: boundary-family discipline, flight-recorder humility, invariant registries, and historical receipts not proving current live state.

Reject for Helm v0: full kernel-grade boundary proliferation at the product surface.

Translate into Helm: small cards that confess boundary, lane, source cut, and next safe verb.

### Foundry

Keep: semantic spine, serving-lane humility, pinned-cut discipline.

Translate into Helm: every semantic shortcut gets a chip and a recheck path.

### Harbor

Keep: temporal witnesses, contract subsets, lineage guards.

Translate into Helm: imports and exports remain restricted until local adoption/publish/settle receipts exist.

### Schell

Keep: basis cards, activation receipts, environment epochs.

Translate into Helm: strong verbs need fresh basis and environment posture.

### Steward

Keep: bootstrap reconciliation, cause condition, light process.

Translate into Helm: stale refusal should explain the cause and offer the next smallest honest move.

### ViewFS

Keep: prefix badges, folder ghosts, list lanterns.

Translate into Helm: tiny visible honesty beats inspector-only truth.

### Ward

Keep: resolution bindings, tier witnesses, hybrid seams.

Translate into Helm: evidence is smaller than verdict; verdict is smaller than durable release.

## Must-learn lessons from the past

1. Users route around slow truth. Make weak rungs pleasant.
2. Users over-trust green. Label the class of green.
3. Dashboards rot silently. Show build cuts and invalidators.
4. Review queues become cargo cults. Revalidate before consequence.
5. Import pipelines launder foreign truth. Keep restricted/adoptable/local explicit.
6. Receipts become false authority. Scope every receipt.
7. AI proposals become ambient acts. Force them through rung compilation.
8. Local-first state feels current. Sync posture must be visible.
9. Semantic layers make definitions reusable. Reuse must not hide dimensions or cuts.
10. Product delight fails if honesty is a tax. Make chips, refusals, and rechecks feel like superpowers.

## Nifty ideas to steal now

- **Contradiction as a view mode**: show live/saved/cut/derived/receipt disagreement as a compact comparison, not an error dialog.
- **Primary button earned by basis**: button labels change from `Recheck` to `Promote` only when the backing record supports the stronger rung.
- **Tiny refusal copy**: every blocked act offers a smaller next move.
- **Build-cut chip**: derived summaries carry `built from C7`-style chips by default.
- **Arrival posture ladder**: `restricted → adoptable → adopted/promoted` is a visible product rail.
- **Receipt scope chips**: `local consequence`, `sent`, `receiver-visible`, `durable`, and `historical-only` should not share one checkmark.
- **Query-pack demos**: prototype UI with tiny JSONL and query snapshots before picking a backend.
- **Intent compiler**: every Omnibox/AI/Flow proposal compiles to a safe next verb list before rendering action controls.

## Moves that would make Helm awesome

1. **The button explains itself.** Hover/press on `Recheck` says exactly which drift blocked promotion.
2. **The same object has five lights.** Live, saved, cut, derived, receipt lanes appear as a tiny consistent strip.
3. **Recall never lies.** Old work returns with a `historical` chip and a one-click recheck.
4. **Imports are useful before trusted.** Peek and compare are delightful; promote is gated.
5. **Fast lanes are honest by construction.** Cached/local analytic panels are fast because they are allowed to be weaker and visibly so.
6. **Every refusal is a route.** `Promote blocked` is paired with `compare`, `recheck`, or `retreat`.
7. **Every serious mock has a fixture.** Designers cannot invent a badge/button that the query pack cannot explain.

## Pull-the-trigger recommendation

Accept `surface_affordance_card` and the `release-readiness` query pack as fixture contracts.

Do not freeze a production schema.
Do not choose DuckDB, Iceberg, DuckLake, Cube, dbt, Databricks, Observable, Electric, or LiveStore yet.
Do not add a pillar.

The next prototype should be a tiny UI over the query pack: chip row, popover, inspector, and primary-button state for the same ten records.
