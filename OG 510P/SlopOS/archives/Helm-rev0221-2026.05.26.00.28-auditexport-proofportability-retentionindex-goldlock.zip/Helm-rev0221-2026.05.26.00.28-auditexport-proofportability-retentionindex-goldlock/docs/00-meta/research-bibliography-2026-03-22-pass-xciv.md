# Research bibliography — pass XCIV — 2026-03-22

## Sources reviewed this pass

- Kubernetes — Safely Drain a Node
- Kubernetes — Disruptions / eviction and `terminationGracePeriodSeconds`
- AWS Elastic Load Balancing — target deregistration delay (`draining` → `unused`)
- Envoy — draining listeners and graceful drain timeout
- systemd — `EXTEND_TIMEOUT_USEC` for bounded shutdown extension
- Temporal — cancellation and termination
- nginx — graceful `quit` versus fast `stop`

## Companion archive surfaces re-read this pass

- SlopOS — `docs/30-architecture/quiesce-posture-v0.md`
- SlopOS — `rfcs/0105-request-contexts-deadlines-and-cancellation.md`
- SlopOS — `rfcs/0112-grace-periods-and-deferred-reclamation.md`
- Steward — `docs/30-architecture/quiesce-posture-v0.md`
- Steward — `docs/30-architecture/stop-deferral-posture-v0.md`
- ViewFS — `rfcs/0039-viewfs-keep-cancel-terminate-forget-reset-and-rerun-separate.md`

## Why these mattered

- Kubernetes strengthened **no-new-work plus bounded graceful termination**.
- AWS ELB strengthened **draining with a named timeout and a visible post-timeout state**.
- Envoy strengthened **graceful drain that still has an eventual hard edge**.
- systemd strengthened **explicit timeout extension rather than ambient indefinite shutdown**.
- Temporal strengthened **cancel versus terminate**.
- nginx strengthened **graceful quit versus fast stop**.
