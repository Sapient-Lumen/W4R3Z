# Research bibliography — 2026-03-23 pass CXXX

## Official sources revisited for this pass

- GitHub Docs — GraphQL enums: `IssueClosedStateReason` and `IssueStateReason`
- GitHub Docs — REST issues API `state_reason`
- Atlassian Support — Configure resolutions in a Jira workflow
- Atlassian Support — Best practices on using the Resolution field in Jira Cloud
- PagerDuty Support — Incidents
- PagerDuty Support — Reopen Incidents
- Sentry Docs — Issue Status
- Sentry Docs — Releases

## Why these were useful

These sources all reinforced the same product lesson:
modern systems that feel trustworthy keep **resolution class**,
**status**,
**reopen / regression law**,
and **future comeback conditions** separate instead of flattening them into one generic `done` state.
