# Research bibliography — 2026-03-23 pass CXV

1. **Apple Spotlight actions and quick keys**
   - Why it mattered: Spotlight can search for actions, narrow to action-only results, and assign quick keys.
   - Helm pull: Omnibox should gain an explicit typed action mode rather than stopping at launcher/search behavior.

2. **Microsoft PowerToys Command Palette**
   - Why it mattered: Command Palette is now a fast, customizable, extensible launcher for commands, apps, and development tools.
   - Helm pull: a broad summon surface can stay strong if it remains structured and attributable.

3. **Apple Quick Look**
   - Why it mattered: weak preview remains one of the best inspect-before-open patterns in desktop history.
   - Helm pull: keep preview → compare → promote as a core shell grammar.

4. **Notion Home + Command Search**
   - Why it mattered: Home assembles recents, shortcuts, calendar, and tasks, while Command Search stays globally summonable and keyboard-driven.
   - Helm pull: weak Overview landing plus fast global summon is a powerful pairing.

5. **Raycast Quicklinks + AI Commands**
   - Why it mattered: quicklinks support dynamic placeholders, selected-text quick search, and hotkeys; AI Commands bind typed arguments and `{selection}`.
   - Helm pull: promoted exact landmarks and selection-scoped typed actions can coexist in one shell-owned command surface.

6. **Obsidian Command Palette, Bookmarks, and Workspaces-linked behavior**
   - Why it mattered: pinned commands, bookmark groups, linked views, and saved layouts show a humane return-to-work stack without giant dashboard machinery.
   - Helm pull: exact landmarks and saved layout/front-door posture are better than generic recents.

7. **Windows Click to Do**
   - Why it mattered: selection-first actions over what is on screen make delight feel precise instead of ambient.
   - Helm pull: Helm should warm direct-gesture and selection-scoped action flows.

8. **VS Code agent sessions + Copilot CLI sessions**
   - Why it mattered: multiple background sessions can remain observable, parallel, and independent from a unified session list.
   - Helm pull: helper/session rosters should become a first-class shell truth next to adoption harbors.

9. **VS Code worktrees + Figma branching**
   - Why it mattered: parallel exploration stays trustworthy when it remains separate from the live lane until explicit review/merge/adopt.
   - Helm pull: branch/adopt posture is still one of Helm's strongest luxury moves.

10. **Slack canvases and version-history controls**
   - Why it mattered: rich surfaces stay safer when restoration and sharing controls remain explicit.
   - Helm pull: Overview-like surfaces can be rich and useful so long as they stay visibly weaker than stronger source truth.

11. **Windows Recall**
   - Why it mattered: searchable continuity is powerful, but giant memory capture remains a warning as much as an inspiration.
   - Helm pull: exact object/activity timelines are still the better Recall direction.
