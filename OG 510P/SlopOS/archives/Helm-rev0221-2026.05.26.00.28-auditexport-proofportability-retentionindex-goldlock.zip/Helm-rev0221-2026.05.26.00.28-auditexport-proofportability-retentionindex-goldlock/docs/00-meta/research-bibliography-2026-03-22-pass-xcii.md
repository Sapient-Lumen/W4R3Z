# Research bibliography — pass XCII

1. GitHub Docs — Re-running workflows and jobs
   - source: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs
   - used for: rerun-failed-jobs posture, specific-job rerun posture, and previous-attempt history

2. GitHub Docs — Using the REST API to interact with checks
   - source: https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks
   - used for: check status-versus-conclusion separation, stale conclusion, and bounded check output details

3. GitHub Docs — Workflow commands / job summaries
   - source: https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-commands
   - used for: per-step summaries grouped into per-job workflow-run summaries

4. Google AIP — Long-running operations
   - source: https://google.aip.dev/151
   - used for: done/response/error posture, operation metadata, and execution-phase error separation

5. Google Drive API docs — Manage long-running operations
   - source: https://developers.google.com/workspace/drive/api/guides/long-running-operations
   - used for: polling posture, pending-versus-done operation state, operation identity, and expiry of historical operation handles

6. AWS Systems Manager docs — Automation statuses
   - source: https://docs.aws.amazon.com/systems-manager/latest/userguide/automation-statuses.html
   - used for: overall execution status versus per-step status

7. AWS Systems Manager API Reference — StepExecution
   - source: https://docs.aws.amazon.com/systems-manager/latest/APIReference/API_StepExecution.html
   - used for: step start/end time, failure details, inputs, outputs, and exact per-step aftermath

8. AWS Step Functions docs — Restarting state machine executions with redrive
   - source: https://docs.aws.amazon.com/step-functions/latest/dg/redrive-executions.html
   - used for: preserve successful step history, rerun only unsuccessful states, and redrive ancestry

9. AWS Step Functions docs — Viewing a Distributed Map Run execution
   - source: https://docs.aws.amazon.com/step-functions/latest/dg/concepts-examine-map-run.html
   - used for: item-processing status and child-execution detail posture

10. Kubernetes docs — Jobs
   - source: https://kubernetes.io/docs/concepts/workloads/controllers/job/
   - used for: completedIndexes / failedIndexes, per-index failure truth, terminal conditions, and overall-failed despite partial success posture
