# Research bibliography — 2026-05-15 — pass CLXXXVII

Primary outside references reviewed for rev0194:

1. CloudEvents specification — https://github.com/cloudevents/spec/blob/main/cloudevents/spec.md
2. CloudEvents overview — https://cloudevents.io/
3. SLSA Provenance v1 — https://slsa.dev/provenance/v1
4. in-toto SLSA provenance predicate page — https://github.com/in-toto/attestation/blob/main/spec/predicates/provenance.md
5. OpenTelemetry semantic conventions — https://opentelemetry.io/docs/concepts/semantic-conventions/
6. OpenTelemetry semantic conventions for events — https://opentelemetry.io/docs/specs/semconv/general/events/
7. Kubernetes finalizers — https://kubernetes.io/docs/concepts/overview/working-with-objects/finalizers/
8. Open Policy Agent decision logs — https://openpolicyagent.org/docs/management-decision-logs
9. GitHub deployments REST API — https://docs.github.com/en/rest/deployments/deployments
10. GitHub deployment statuses REST API — https://docs.github.com/github-ae@latest/rest/deployments/statuses
11. OpenFeature evaluation context — https://openfeature.dev/specification/sections/evaluation-context
12. OpenFeature hooks — https://openfeature.dev/specification/sections/hooks
13. Temporal compensating actions / sagas — https://temporal.io/blog/compensating-actions-part-of-a-complete-breakfast-with-sagas

Companion archive pressure reviewed locally:

- SlopOS rev0695, especially posture index / boundary family discipline.
- Foundry rev0074, semantic spines, serving lanes, pinned cuts.
- Harbor rev0075, temporal witnesses and lineage guards.
- Steward rev0165, bootstrap reconciliation and light process lessons.
- Schell rev0227, basis cards and activation receipts.
- ViewFS rev0137, prefix badges, folder ghosts, list lanterns.
- Ward rev0059, resolution bindings and tier witnesses.
