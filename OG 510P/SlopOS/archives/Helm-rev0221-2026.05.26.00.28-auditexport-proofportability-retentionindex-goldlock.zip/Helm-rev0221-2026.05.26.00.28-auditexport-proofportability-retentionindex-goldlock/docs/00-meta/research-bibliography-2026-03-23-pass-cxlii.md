# Research bibliography — 2026-03-23 pass CXLII

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-DAGSTER-HEALTH-2026B | https://docs.dagster.io/guides/observe/asset-health-status | one compact health state over latest materialization + freshness + checks is a strong precedent for Helm watch summaries |
| REF-DAGSTER-CHECKS-2026B | https://docs.dagster.io/api/dagster/asset-checks | attached checks staying bound to one asset are a strong precedent for exact watched-slice checks |
| REF-DAGSTER-FRESHNESS-2026B | https://docs.dagster.io/guides/observe/asset-freshness-policies | explicit freshness policies are a strong precedent for watch cadence and drift budgets |
| REF-DATAHUB-ASSERTIONS-2026B | https://docs.datahub.com/docs/managed-datahub/observe/assertions | assertions as building blocks of data contracts are a strong precedent for inspectable watch expectations |
| REF-DATAHUB-OPEN-ASSERTIONS-2026B | https://docs.datahub.com/docs/assertions/open-assertions-spec | freshness / volume / column / custom SQL / schema assertion families are a strong precedent for typed watch rules |
| REF-DATAHUB-SMART-ASSERTIONS-2026B | https://docs.datahub.com/docs/managed-datahub/observe/smart-assertions | family-scoped monitoring rules and anomaly monitors are a strong precedent for watch rules over matching/new slices |
| REF-DATAFOLD-DIFF-2026B | https://docs.datafold.com/data-diff/cross-database-diffing/creating-a-new-data-diff | full row / column / value diff is a strong precedent for variance-aware watch posture |
| REF-DATAFOLD-MONITORS-2026B | https://docs.datafold.com/llms.txt | monitor families plus diff / test / metric / schema monitoring are strong precedents for Helm watch families |
| REF-GX-CHECKPOINT-2026B | https://docs.greatexpectations.io/docs/core/trigger_actions_based_on_results/run_a_checkpoint/ | validation result followed by actions is a strong precedent for result-versus-reaction separation |
| REF-GRAFANA-ALERT-VIEW-2026B | https://grafana.com/docs/grafana/latest/alerting/monitor-status/alerts-page/ | a consolidated firing/pending alert view is a strong precedent for current watch-state lanes |
| REF-GRAFANA-ANNOTATIONS-2026B | https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/annotate-visualizations/ | saved annotations tied to dashboards are a strong precedent for overlay/event layers weaker than source truth |
| REF-MONTE-CARLO-MONITORS-AS-CODE-2026B | https://docs.getmontecarlo.com/docs/monitors-as-code | YAML monitors-as-code is a strong precedent for governed watch rollout without hidden policy |
| REF-MONTE-CARLO-COMPARISON-MONITORS-2026B | https://docs.getmontecarlo.com/docs/comparison-rules | comparison monitors and segmented deltas are a strong precedent for variance-aware watch posture |
