# Helm: rehearsal decks, group checks, and drift sentries — 2026-03-23

## The call in this revision

Keep the seven pillars.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes** as the datacube law.

But make the next proof object more concrete:

**Helm should now try proving one bounded rehearsal deck.**

Not a new pillar.
Not a giant simulator.
Not a giant home plane.

A compact deck.

## Why this now looks worth proving

Helm already has many warm ideas:
- action rehearsal cards
- reviewed slices / cohort windows
- basis explorers
- rule-insight cards
- landing trains / guarded promotion ladders
- patrol routes
- settlement witnesses
- calibration witnesses

The problem is that they still risk feeling like a bag of luxuries unless the operator can carry them through one humane loop:

1. show me what would happen to this exact thing
2. show me what nearby cohort or reviewed slice would also move
3. show me why this would pass or fail
4. show me what grouped promotion context changes the answer
5. tell me when the rehearsal has drifted or gone stale
6. later reopen what actually happened

That loop is what the rehearsal deck should prove.

## What a rehearsal deck is

A **rehearsal deck** is a shell-owned,
bounded,
pre-act workspace over one exact strong act,
one exact reviewed slice,
or one exact promotion candidate.

It should be able to carry several explicit faces:

- **exact-subject rehearsal**
- **cohort delta / reviewed-slice lane**
- **rule or validator insight**
- **group-check lane**
- **drift sentry**
- **promotion rung**
- **later settle / calibrate reopen**

Not every specimen needs all seven faces at once.
But that is the pressure map.

## The most important new idea: grouped checks are part of truthful rehearsal

A lot of shell previews fail for the same reason bad merge stories fail:
they pretend the candidate lands alone.

But many strong acts do not land alone.
They land:
- against a newer head
- beside earlier queued changes
- with a receiver's current posture
- with a guarded audience rung
- or with changed resource pressure

That means Helm should increasingly admit one question directly:

**what other exact facts or neighbors is this proposal being checked with right now?**

That is the job of the group-check lane.

## The second important new idea: rehearsal needs drift sentries

A beautiful preview becomes dangerous the moment its basis silently moved.

So every stronger rehearsal should have a compact **drift sentry** that can say things like:
- basis unchanged
- compared basis changed
- grouped check set changed
- sample too small
- cache stale
- rule set changed
- receiver lag increased
- queue rebuilt
- re-review required

This is better than a vague stale badge because it tells the operator what kind of trust fell apart.

## What this does for the pillars

### Tiling Shell
A deck can show:
- one exact restore or landing rehearsal
- one rebind / repair lane
- one grouped promotion or target-lane check
- one drift sentry when current lane basis changed

### Omnibox
A deck can deepen a strong result into:
- exact-subject preview
- least-widening alternatives
- validator / rule lane
- recheck if result basis drifted

### Object Browser
A deck can hold:
- one reviewed slice
- one cohort delta lane
- one publish/reveal rehearsal
- one settlement reopen path later

### Operations Center
A deck can connect:
- why-this-would-pass
- guarded rung
- grouped promotion context
- drift / pause reasons
- settlement and later calibration

### Desktop Flow
A deck can keep together:
- packet preview
- validator result
- predicted-live or dry-run lane
- headroom / adaptation sentry
- later effect receipt and miss analysis

### Recall
A deck can compare:
- exact historical footing
- current bind / repair result
- drift sentry
- and later what actually remained durable

### Exchange
A deck can show:
- exact recipient or route rehearsal
- cohort / audience delta
- rule / policy insight
- grouped send or publish posture
- later delivery / settlement reopen

## What to steal

Steal:
- exact-subject plus cohort-delta in one place
- grouped checks before stronger promotion
- explicit invalidation instead of hidden carry-forward
- bounded investigation feel instead of giant dashboard feel
- later reopen tied to the earlier footing

## What to refuse

Refuse:
- one all-knowing readiness score
- giant simulation ambitions
- grouped promotion hidden behind isolated green-check cards
- stale previews that keep looking live
- a deck that silently becomes shared authority just because it was useful

## Product judgment

The next wise pull is still not a new pillar.

The next wise pull is:

**prove one bounded rehearsal deck built on truth axes and reopen routes,
then see whether that single object makes several warm Helm luxuries suddenly cohere.**

That looks like a much better path to “super awesome” than growing the center again.
