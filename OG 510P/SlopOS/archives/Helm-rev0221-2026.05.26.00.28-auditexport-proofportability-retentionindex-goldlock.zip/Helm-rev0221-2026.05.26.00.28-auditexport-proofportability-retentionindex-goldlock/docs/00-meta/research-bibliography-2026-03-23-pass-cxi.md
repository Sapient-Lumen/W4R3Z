# Research bibliography — 2026-03-23 — pass CXI

1. Microsoft Graph — **UploadSession / createUploadSession**
   - URLs:
     - https://learn.microsoft.com/en-us/graph/api/resources/uploadsession?view=graph-rest-1.0
     - https://learn.microsoft.com/en-us/graph/api/driveitem-createuploadsession?view=graph-rest-1.0
   - Why it mattered: Graph makes the resumable handle and the exact remainder visible through `expirationDateTime` and `nextExpectedRanges`, and explicitly preserves the session until expiry for explicit commit/error recovery.

2. tus protocol — **resumable upload spec**
   - URLs:
     - https://tus.io/protocols/resumable-upload
     - https://tus.io/faq
   - Why it mattered: tus keeps unfinished-upload truth compact and exact with `Upload-Offset`, optional `Upload-Expires`, and `HEAD` for retrieving the current offset before resuming.

3. Amazon S3 — **multipart upload, ListParts, ListMultipartUploads**
   - URLs:
     - https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpuoverview.html
     - https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListParts.html
     - https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListMultipartUploads.html
   - Why it mattered: S3 proves that already-uploaded parts and in-progress upload sessions are queryable truths, which means the remaining slice is not just “start over.”

4. GitHub Docs — **managing / re-running workflow runs**
   - URLs:
     - https://docs.github.com/actions/managing-workflow-runs
     - https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs
   - Why it mattered: GitHub keeps rerun-all, rerun-failed, and rerun-one-job distinct, with a bounded rerun window, which validates remainder-scoped recovery instead of one universal retry.

5. AWS Step Functions — **redrive executions**
   - URLs:
     - https://docs.aws.amazon.com/step-functions/latest/apireference/API_RedriveExecution.html
     - https://docs.aws.amazon.com/step-functions/latest/dg/redrive-executions.html
   - Why it mattered: Step Functions preserves successful-step history and resumes from the unsuccessful step, which is excellent pressure for a first-class remainder witness.

6. Kubernetes — **Jobs / Indexed Jobs**
   - URLs:
     - https://kubernetes.io/docs/concepts/workloads/controllers/job/
   - Why it mattered: Kubernetes keeps `completedIndexes` and `failedIndexes` visible even when overall job state is failed, which is near-perfect “exact remainder” evidence.

7. Google Drive / google.longrunning — **manage long-running operations**
   - URLs:
     - https://developers.google.com/workspace/drive/api/guides/long-running-operations
     - https://docs.cloud.google.com/run/docs/reference/rpc/google.longrunning
   - Why it mattered: Drive keeps a named LRO handle, binds polling to the same user, keeps availability finite, and generic google.longrunning cleanly separates get / wait / cancel / delete-no-longer-interested semantics.

## Companion-cube anchors revisited

- `docs/30-architecture/lease-descriptor-state-boundary-v0.md` (SlopOS)
- `docs/30-architecture/background-request-state-posture-v0.md` (SlopOS)
- `docs/30-architecture/job-request-state-posture-v0.md` (SlopOS)
- `docs/80-terminal/handoff-ladders-observation-truth-and-completion-humility.md` (Schell)
- `docs/70-shell/truthful-completions-and-routing.md` (ViewFS)
- `docs/30-architecture/handles-refs-and-receipts.md` (ViewFS)
- `docs/30-architecture/runtime-cycle-witness-posture-v0.md` (Steward)
- `docs/30-architecture/freshness-decay-posture-v0.md` (Steward)

## Current judgment

The strongest outside and companion-cube pressure now converges on this aftermath / recovery chain:

**effect receipt → continuation handle → remainder witness → repair ladder**

with current-live truth still staying stronger than all four.
