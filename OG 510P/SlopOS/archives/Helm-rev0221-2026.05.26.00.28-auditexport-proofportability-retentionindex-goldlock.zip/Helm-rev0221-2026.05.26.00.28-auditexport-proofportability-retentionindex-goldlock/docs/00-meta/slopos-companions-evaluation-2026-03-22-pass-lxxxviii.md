# SlopOS + companions evaluation — 2026-03-22 — pass LXXXVIII

Purpose: continue mining SlopOS, Schell, ViewFS, and Steward for laws Helm should steal **now** while those companion cubes are still design-phase systems.

## Main judgment

This pass strengthens one specific conclusion:
Helm should treat **active borrowed power** as a first-class shell truth.

The next compact answer now looks like:
- **active-borrow beacons**
- **brake rails**

That is a cleaner next move than another pillar,
and a better use of SlopOS-style discipline than importing more datacube machinery.

## 1. SlopOS keeps teaching the same law in several authority families: live use must stay leased,
visible,
and revocable

SlopOS's capture,
background,
inhibit,
secure-input,
and accessibility/automation seams keep converging on a shared product law:
if the system lends out powerful ongoing behavior,
that behavior should be bounded,
visible,
and revocable.

The deepest lesson for Helm is not the substrate shape.
It is the shell law:
- issued authority is one truth
- currently borrowed authority is another truth
- actively consuming or exposing something **right now** is a third truth

Helm should steal that distinction.

## 2. Schell adds the anti-spoof requirement: hot-state honesty belongs in trusted shell chrome

Schell's pressure around trusted chrome and anti-spoof separation makes the next step clearer.
It is not enough for Helm to approve a strong act in trusted chrome once.
If that act leaves something visibly hot later,
the ongoing indicator should also stay in shell-owned chrome,
not inside PTY or app theater.

That keeps “camera is hot,”
“screen is being shared,”
“automation is live,”
or “background presence is still admitted” from becoming provider folklore.

## 3. ViewFS keeps the family split honest

ViewFS remains a strong teacher because it keeps observe,
attach,
control,
exec,
and sideband lanes visibly distinct.
That matters here.

An active beacon should not just say “something is active.”
It should keep the active family legible:
- observe
- attach
- control
- reveal
- automation
- background
- capture

Otherwise the shell gains an indicator but loses the meaning cut.

## 4. Steward keeps the chrome small and humane

Steward's label humility and compact trusted chrome direction are the right corrective pressure.
Helm should not answer this problem with a giant dashboard first.
It should start with:
- one tiny shell-owned active beacon
- one nearby truthful brake rail
- one route to the fuller revoke/narrow/manage surface when needed

## 5. What Helm should steal now

### Steal
- one compact **active-borrow beacon** for exact on-air / hot-now truth
- one adjacent **brake rail** for stop,
pause,
mute,
narrow,
or escalate-to-manage
- one explicit split between **lease window** and **active use now**
- one exactness grade for live control so the shell can admit coarse substrate brakes honestly
- one weaker **recently-used** or historical residue surface that never impersonates live hot-state truth

### Do not steal yet
- no giant privacy or policy center in v0
- no attempt to flatten every live signal into one status family
- no historical grant receipts pretending to be live kill switches
- no belief that a design-phase companion datacube has already earned final UX machinery

## 6. Candidate shell move

The next sharp Helm move is therefore not another pillar.
It is one compact answer to a new shell question:

**what exact borrowed power is actively hot right now,
and what truthful brake is nearby?**

That answer now looks like:
- **active-borrow beacon**
- plus **brake rail**.

## Judgment

SlopOS and the companion cubes are still best treated as teachers of **laws**.
This pass says the relevant law is now:

**if Helm lends out strong ongoing power,
it should keep current hot-state visible in shell-owned chrome and keep a nearby truthful brake,
without confusing that with issuance history or giant settings machinery.**
