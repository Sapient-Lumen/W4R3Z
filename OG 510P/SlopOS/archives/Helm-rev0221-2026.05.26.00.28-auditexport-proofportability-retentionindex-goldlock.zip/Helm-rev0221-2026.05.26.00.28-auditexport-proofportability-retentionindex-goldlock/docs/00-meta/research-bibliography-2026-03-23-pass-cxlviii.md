# Research bibliography — 2026-03-23 pass CXLVIII

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-GERRIT-LABEL-COPYCONDITION-2026G | https://gerrit-review.googlesource.com/Documentation/config-labels.html | explicit `copyCondition` and `changekind` values show a strong precedent for conditional carry-forward by typed change class |
| REF-GERRIT-ATTENTION-SET-2026G | https://gerrit-review.googlesource.com/Documentation/user-attention-set.html | turn-based attention is a strong precedent for later review-turn chips rather than a giant workflow center |
| REF-GITHUB-RULESETS-STALE-REVIEW-2026G | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets | exact diff binding, stale approval dismissal, and `most recent reviewable push` support graded re-review with weak carry-forward residue |
| REF-GITHUB-ENVIRONMENTS-REVIEWERS-2026G | https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments | required reviewers, non-self review, wait timer, and custom protection rules are strong precedents for bounded sharper-action gates |
| REF-GITHUB-MANAGE-ENVIRONMENTS-2026G | https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments | reviewer-set size, self-review prevention, and wait-timer configuration show how a small sharp-action gate can stay explicit |
| REF-GITLAB-APPROVAL-RULES-2026G | https://docs.gitlab.com/user/project/merge_requests/approvals/rules/ | approval rules define how many approvals are needed and which users should provide them; strong precedent for scoped reviewer-set hints |
| REF-GITLAB-CODEOWNERS-ADVANCED-2026G | https://docs.gitlab.com/user/project/codeowners/advanced/ | sectioned code ownership with multiple required groups is a strong precedent for one-of versus one-from-each review shapes |
| REF-GITLAB-CODEOWNERS-SYNC-2026G | https://docs.gitlab.com/development/code_owners/ | deleting outdated approval rules and recreating file-scoped ones is a strong precedent for packet/regeneration when changed scope shifts |
| REF-GITLAB-CODE-REVIEW-GUIDELINES-2026G | https://docs.gitlab.com/development/code_review/ | eligible approvers, domain experts, reviewer capacity, re-request review, and remove-all-approvals-on-new-commits are useful pressure for humane review packets |
| REF-NX-AFFECTED-2026G | https://nx.dev/docs/features/ci-features/affected | minimum affected-set computation is a strong precedent for review-packet scope narrowing |
| REF-FIGMA-GUIDE-TO-BRANCHING-2026G | https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching | exact branch footing, compare views, update-from-main, and version-history checkpoints remain strong precedents for packet footing honesty |
| REF-FIGMA-REVIEW-BRANCH-2026G | https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes | `review again` remains a strong precedent for reopening review without pretending old approval never existed |
| REF-FIGMA-UPDATES-FROM-MAIN-2026G | https://help.figma.com/hc/en-us/articles/5665728006423-Get-updates-from-main-files | exact update-from-main behavior and conflict resolution remain useful precedents for footing drift and re-review packets |
