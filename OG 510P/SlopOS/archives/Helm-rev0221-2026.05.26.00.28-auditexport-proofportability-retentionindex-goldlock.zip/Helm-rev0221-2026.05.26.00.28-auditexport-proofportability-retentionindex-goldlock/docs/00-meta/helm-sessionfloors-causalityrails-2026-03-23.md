# Helm — session floors and causality rails

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one universal causal-consistency service.

The strongest next move is smaller:
**warm session floors + causality rails as the shell-owned seam above read guarantee cards and consistency cuts.**

Helm can already say:
- what exact footing counted,
- what died,
- how it renewed or overlapped,
- what guard a cutover depended on,
- whether the boundary crossed,
- who has observed the result,
- and what class of read a person is looking at now.

What it still answers too weakly is:
- **once a user or deck has already seen a stronger footing, how do we prevent silent backward motion?**
- **what lower bound does this surface still owe that user?**
- **is the current view still on the same causal rail, or did it fall onto a cheaper path below the user's floor?**

## The lesson Helm must learn from the past

Past systems repeatedly commit a third sin after flattening `done` and flattening `current`:
**they forget what the user already knew.**

That creates haunted shell behavior:
- a user writes or reviews something,
  then opens a search result that is cheaper but older;
- a deck shows a strong read,
  then a nearby pane silently reopens through a weaker index or replica path;
- a follow-up act depends on earlier footing,
  but the shell no longer remembers the lower bound the person is standing on.

Helm should refuse the myth that each read is independent just because it is fresh enough in isolation.

## What the outside world is teaching right now

### Azure Cosmos DB: a session has a floor
Cosmos DB says Session consistency guarantees monotonic reads,
monotonic writes,
and read-your-writes within a single session.
That is a direct precedent for Helm:
**once a session has seen newer data,
it should not silently show older data later.**

### MongoDB: causality is a visible rail, not just a freshness number
MongoDB's driver docs say causally consistent sessions guarantee read your writes,
monotonic reads,
monotonic writes,
and writes follow reads,
subject to explicit session and concern requirements.
That is exactly the shape of a Helm **causality rail**.

### Couchbase: lower-bound consistency can be a first-class query knob
Couchbase distinguishes `not_bounded`,
`at_plus`,
and `request_plus`.
`at_plus` uses a lower-bound scan vector and can implement read-your-own-writes.
That is an unusually good steal for Helm because it proves the shell can keep a **lower bound** without forcing every read into the strongest class.

### Spanner: strongest globally ordered view is its own class
Spanner's external consistency and strong reads reinforce that the highest-order guarantee is not the same as any arbitrary later fetch.
That matters because Helm should keep `same session floor` and `strongest global order` visibly distinct.

## What the companion cubes are teaching now

### Keep from SlopOS
Keep exact witness basis and boundary discipline.
A shell should not let a new cheap path silently replace the footing that a serious act already depended on.

### Keep from Ward
Ward's read cuts,
staleness budgets,
and revalidation fences are the strongest local pressure here.
Helm should add a visible **held floor** beside those cuts.

### Keep from Schell
Keep caught-up-through humility and generation lamps.
A session floor is the shell analogue of `caught up through here`.

### Keep from ViewFS
Keep observed-versus-private-versus-committed separation.
Add the further distinction between:
- the version currently being viewed,
- and the lower bound already held by the viewer.

### Keep from Steward and Foundry
Keep reconnect/downgrade honesty,
readiness-generation posture,
and stale-status fences.
They reinforce the rule that silent continuity downgrades are worse than visible cheaper paths.

## Bright steals for Helm

1. **Session floor**
   - a shell-owned lower-bound footing remembered for a person,
     deck,
     or serious work surface.
2. **Causality rail**
   - a tiny nearby rail like `holding your floor`, `below your floor`, `upgrade to continue`, `explicit downgrade required`.
3. **Downgrade verbs**
   - `open below floor`, `reset floor`, `continue with cheaper read`, `reacquire stronger footing`.
4. **Floor-aware open/search**
   - quick opens can stay cheap,
     but if they would violate the held floor,
     Helm should say so.
5. **Floor compare**
   - let a user compare the cheap current path against the held floor before acting.

## What not to keep

Do not keep:
- one shell-wide hidden sticky session context,
- one global token regime across all pillars,
- or one assumption that a later fetch can silently replace the user's earlier footing.

The shell should keep a tiny grammar,
let providers supply evidence,
and make downgrade/reset explicit.

## Why this makes Helm super awesome

This makes Helm feel premium in a way most systems still miss.
A person can ask:
- `am I still on the footing I already reviewed?`
- `did this open path fall below my session floor?`
- `can I keep moving cheaply, or do I need to reacquire stronger footing?`
- `what exactly would I lose if I downgrade?`

That is a much better shell feel than one giant datacube center.
Not because Helm promises one truth,
but because it remembers **what this exact user or deck already knows** and refuses silent backward motion.
