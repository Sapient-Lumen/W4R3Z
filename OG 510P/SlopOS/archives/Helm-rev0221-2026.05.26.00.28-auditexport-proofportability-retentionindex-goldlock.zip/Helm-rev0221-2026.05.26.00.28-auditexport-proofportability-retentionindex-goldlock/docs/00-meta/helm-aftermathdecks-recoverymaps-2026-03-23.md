# Helm: aftermath decks + recovery maps — 2026-03-23

## The call in this revision

Keep the seven pillars stable.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes**,
**bounded rehearsal decks**,
**pillar-specific recipes**,
and **landing trains with attempt-aware lineage** as the current grammar.

But add one narrower post-act mirror:

**after any serious stronger act,
Helm should be able to open one bounded aftermath deck with a nearby recovery map,
so settlement,
continuation,
exact remainder,
repair choice,
and later calibration stay together without pretending they are the same truth.**

## Why this now looks like the right next move

Helm's loop is getting stronger in three places:
- **before** the act: reviewed slices,
  basis explorers,
  rule-insight cards,
  rehearsal decks,
  guarded ladders
- **during** the act: landing trains,
  queue/group truth,
  attempt lineage,
  continuation handles
- **after** the act: settlement witnesses,
  commit cards,
  effect receipts,
  slot verdict ledgers,
  remainder witnesses,
  repair ladders,
  calibration witnesses

What still feels scattered is the operator surface after something important has already happened.
The objects are good.
The bounded home for them is still too implicit.

A serious post-act story often needs to answer all of these at once:
- what exact story and attempt is this?
- what settlement class has really landed?
- is there still one exact live continuation window?
- what exact smaller slice remains?
- what is the narrowest honest next recovery rung?
- what later compare or calibration path should reopen here?

That is exactly what a bounded **aftermath deck** and compact **recovery map** are for.

## The new split Helm should preserve

### 1. Aftermath deck
A bounded shell-owned post-act workspace for one exact story family.

It should gather:
- story id and attempt id
- basis stamp / queue footing / reviewed slice relation
- settlement witness and nearby commit card
- effect receipt and slot / subset truth
- continuation handle weather when one exists
- exact remainder witness when one exists
- repair ladder / reversal warrant choices
- later compare and calibration reopen paths

It is not current-live truth.
It is not a global operations dashboard.
It is not one giant workflow center.

### 2. Recovery map
A compact shell-owned map of honest next rungs around that deck.

It should keep visibly different:
- continue now
- poll / wait
- rerun failed subset
- redrive from failed step
- replay on fresh basis
- compensate / reverse
- hold / cite / export
- widen scope only explicitly

The map should prefer the smallest exact remainder before broader reruns.

## What current official patterns are teaching

The outside pressure lines up unusually well:
- **Grafana Investigations** keeps one investigation bounded,
  lets operators view items on a timeline,
  and compare the same items across time ranges.
- **Datadog Notebooks** combine live data with investigation / postmortem writing,
  and version history lets teams restore or clone a prior version without erasing the change trail.
- **Honeycomb Board Templates** and **Obsidian Bases** reinforce the same lesson:
  many views over one footing,
  with reusable starters,
  not one giant center.
- **GitHub** keeps queue/group truth,
  ruleset evaluate/insight posture,
  and rerun-failed-jobs adjacent rather than flattening everything into one pass/fail row.
- **AWS Step Functions** redrive preserves successful-step history while continuing from the failed step.
- **Google long-running operations** keep one named continuation handle with poll/cancel posture.
- **LaunchDarkly** keeps exact-context preview,
  unsaved-change preview,
  cohort-percentage test runs,
  and guarded rollout monitoring distinct.

Taken together,
those products argue that Helm should not merely have the right objects.
It should give them one bounded post-act home.

## What the companion cubes are still teaching

### SlopOS
Keep exact basis,
exact witness posture,
and weaker-versus-stronger truth.
The deck must never let historical or derived surfaces impersonate current-live truth.

### Schell
Keep proposal / review / run / later-outcome separation.
The deck must be outcome-side and aftermath-side,
not another proposal surface wearing new clothes.

### ViewFS
Keep apply / snapshot / adoption / receipt separation.
The deck can gather those objects,
not collapse them.

### Harbor
Keep route choice and receiver-visible aftermath distinct.
The deck must show both without blending them.

### Ward
Keep freshness fences and revalidation obvious.
A deck should be able to go stale,
ask for refresh,
and reopen basis routes cleanly.

### Steward
Keep typed recovery pressure.
The recovery map should say what kind of recovery is honest,
not gesture toward one vague retry.

## What to keep from older inspirations

Keep:
- bounded multi-view surfaces
- exact footing reopen routes
- time-shift compare
- copy-on-write restore / clone history
- personal-first workspaces that can later be shared
- smaller-before-broader repair moves

Peel away:
- one shell-sized status center
- one universal incident/postmortem system
- decks that overclaim authority
- auto-widened repair scope
- any UI that turns historical truth into live truth by proximity

## Why this could make Helm super awesome

### 1. The operator loop becomes complete
Rehearse,
land,
then reopen the exact aftermath in one bounded place.

### 2. Helm can stay small while feeling premium
A good aftermath deck is much cheaper than a giant workflow center,
but much more humane than scattered receipts and rows.

### 3. Calibration gets a natural home
Later misses,
surprises,
and reliability notes can reopen the exact story they are criticizing.

### 4. Exchange and Recall get noticeably better
Transfers,
publishes,
materializations,
restores,
and returns can all carry one premium post-act home instead of logs plus memory.

## Pull-the-trigger judgment

Do **not** add a pillar.
Do **not** freeze one universal incident center.

But it now looks wise to warm one more compact support move very explicitly:

**bounded aftermath decks with nearby recovery maps**
for serious stronger acts,
kept weaker than current-live truth and smaller than a workflow religion.
