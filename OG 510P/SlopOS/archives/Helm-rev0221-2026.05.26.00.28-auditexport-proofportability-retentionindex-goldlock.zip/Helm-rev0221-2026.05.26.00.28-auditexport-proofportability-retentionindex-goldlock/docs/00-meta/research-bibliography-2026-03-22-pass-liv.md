# Research bibliography — 2026-03-22 — pass LIV

1. **Obsidian Help — Introduction to Bases**
   - source: https://obsidian.md/help/bases
   - used for: Bases as local database-like views over Markdown files and properties

2. **Obsidian Help — Views**
   - source: https://obsidian.md/help/bases/views
   - used for: several explicit views with unique configuration over one base

3. **Obsidian Developer Docs — Build a Bases view**
   - source: https://docs.obsidian.md/plugins/guides/bases-view
   - used for: custom view extensibility under host-owned Bases law

4. **Airtable Support — Getting started with Airtable views**
   - source: https://support.airtable.com/docs/getting-started-with-airtable-views
   - used for: view types over one underlying table

5. **Airtable Support — Using the view share menu in Airtable**
   - source: https://support.airtable.com/docs/using-the-view-share-menu-in-airtable
   - used for: explicit create-link / sync / publish / link-settings flow and visible sync activity

6. **Airtable Support — Getting started with Airtable Interface Designer**
   - source: https://support.airtable.com/docs/getting-started-with-airtable-interface-designer
   - used for: smaller role-shaped interface pages, granular permissions, and end-user-specific surfaces over larger data truth

7. **VS Code Docs — Workspace Trust**
   - source: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
   - used for: Restricted Mode, explicit trust enable, banner/badge posture, and blocked stronger capabilities on unfamiliar folders

8. **VS Code Docs — Profiles in Visual Studio Code**
   - source: https://code.visualstudio.com/docs/configure/profiles
   - used for: explicit carried setup objects that can be switched, exported, imported, and shared

9. **VS Code Release Notes — January 2026 (version 1.109)**
   - source: https://code.visualstudio.com/updates/v1_109
   - used for: terminal opening in restricted workspaces as an explicit opt-in rather than ambient allowance

10. **Microsoft Learn — PowerToys Workspaces utility for Windows desktop management**
   - source: https://learn.microsoft.com/en-us/windows/powertoys/workspaces
   - used for: capture/edit/pin desktop workspaces as launchable front doors rather than live sessions

11. **GitHub Docs — Managing your views**
   - source: https://docs.github.com/en/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/managing-your-views
   - used for: project views as explicit tabs over one project truth

12. **GitHub Docs — Using the activity view to see changes to a repository**
   - source: https://docs.github.com/en/repositories/viewing-activity-and-data-for-your-repository/using-the-activity-view-to-see-changes-to-a-repository
   - used for: compare-changes access from an activity surface

13. **Figma Help — Guide to branching**
   - source: https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
   - used for: explicit branches, restore/archive, and checkpoints around branch create/merge

14. **Figma Help — Compare changes in Dev Mode**
   - source: https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
   - used for: bounded compare changes close to recent activity and version history

15. **Linear Docs — Triage**
   - source: https://linear.app/docs/triage
   - used for: one dedicated keyboard-first triage lane rather than burying operational inboxes in generic lists
