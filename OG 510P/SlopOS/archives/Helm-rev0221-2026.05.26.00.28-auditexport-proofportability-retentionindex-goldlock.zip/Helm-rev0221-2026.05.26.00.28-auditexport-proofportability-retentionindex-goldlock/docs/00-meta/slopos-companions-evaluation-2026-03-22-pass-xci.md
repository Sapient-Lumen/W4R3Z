# SlopOS + companions evaluation — pass XCI

This pass sharpened one small question:

**what should Helm learn from mature just-in-time privilege systems without turning into an admin console?**

## SlopOS still teaches the deepest rule

SlopOS keeps paying off when it insists on:
- exact admission seams,
- request-versus-live humility,
- lease discipline,
- and no hidden chooser or ambient widening.

That is exactly the frame Helm needs here.
An old approval,
a design-time possibility,
or a remembered grant is **not** the same thing as a live active borrowed window.

So the bounded take from SlopOS is:
- keep strong acts on explicit shell seams,
- keep duration and reviewed-basis posture visible,
- and do not let a helper/tool/provider quietly inherit broader power because the shell already knows it once worked.

## Schell and Steward make the shell-facing answer clearer

Schell keeps teaching that reviewed or stronger shell decisions should cross one trusted shell-owned seam,
not dissolve into app content or terminal folklore.
That makes **elevation tickets** feel locally earned:
a small trusted-chrome object can carry reason,
requested duration,
reduced scope,
approval posture,
and later point to the actual live borrowed window.

Steward keeps sharpening the label/status side of the same lesson.
A shell that says only "allowed" or "granted" is lying by compression.
For temporary stronger power,
Helm should keep at least these states visibly distinct:
- eligible
- requested
- pending approval
- approved but not active yet
- active borrowed
- hot/on-air now when relevant
- expiring soon
- ended / withdrawn / denied / historical only

## ViewFS is the best companion teacher for after-state honesty

ViewFS keeps reinforcing that observe,
attach,
control,
and sideband state are different lanes.
That directly helps Helm here:
- an **elevation ticket** is not the same thing as an **authority window**,
- an **authority window** is not the same thing as an **active-borrow beacon**,
- and a **de-elevation rail** is not the same thing as a historical receipt or a generic revoke handle.

That separation matters because the trustworthy shell answer is not one object.
It is one short ladder:
**eligible or reviewable → requested/pending → active borrowed → hot now if actually in use → ended/degraded/historical**.

## What Helm should steal

1. **Eligibility is weaker than activation.**
   A thing may be allowed to request stronger power later without already holding it.

2. **Temporary power should be reason-bearing and duration-bearing.**
   The shell should be able to show why the request exists,
   how long it asked for,
   what max duration applies,
   and whether a narrower scope was chosen.

3. **Approval is a state, not a boolean.**
   Pending,
   approved,
   denied,
   withdrawn,
   and expired are better than one flattened grant badge.

4. **Live stronger power should have a nearby early end path.**
   Timeout is not enough.
   The shell should make end-now,
   narrow,
   or drop-back-to-eligible easy.

5. **Keep the shell object small.**
   Helm does not need a giant RBAC center.
   It needs one honest shell ticket for temporary stronger power.

## What not to steal

- giant enterprise workflow religion
- ticket-system cosplay where every action requires bureaucracy
- hidden auto-renew or hidden privilege carry-forward
- approval receipts that impersonate current active power
- device/session/location requirements that disappear after activation without any reminder of what was actually checked

## Judgment

Because SlopOS and Schell are still design-phase systems,
Helm should still steal **their laws more than their machinery**.
This pass says one more law is now worth warming:

> temporary stronger power should travel through a compact shell-owned ticket that keeps eligibility,
> approval,
> activation,
> hot use,
> and early end visibly different.
