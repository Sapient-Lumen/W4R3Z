# Helm: grace budgets + cut-through receipts — 2026-03-22

## Headline

Helm should get **better at bounded graceful endings, not broader at lifecycle theater**.
The next compact move worth warming is:

- **grace-budget chips**
- **cut-through receipts**

## Why now

Helm now has:
- quiesce rails for no-new-work maintenance posture,
- drain witnesses for current phase and blocker truth,
- freshness-horizon chips for live-claim decay,
- condition strips for compact status grammar,
- and effect receipts for exact historical aftermath.

What it still lacks is one clean answer to:

- **how long is the graceful window actually expected to last?**
- **what exactly happens when that grace budget expires?**
- **did this story end gracefully, or did someone cut through it?**

Without that,
Helm risks another familiar lie:
- “draining” that never names its deadline,
- “still stopping” that never says whether extension is possible,
- and “done” that hides whether the ending was cooperative or forceful.

## The good pattern

### Grace-budget chips

A grace-budget chip should carry:
- one exact subject, cohort, or lane witness
- one exact budget start
- one declared grace deadline or remaining time
- one budget source (`policy-default`, `operator-requested`, `provider-fixed`, or equivalent)
- one extension posture (`not-extendable`, `extendable-by-policy`, or `extended`)
- one expiry action (`cut-through`, `force-close`, `detach`, `mark failed`, or another exact local ending)
- one link to the active quiesce rail or drain witness when present

### Cut-through receipts

A cut-through receipt should carry:
- one exact predecessor rail or witness
- one exact expiry or escalation reason
- one exact moment graceful handling ended
- one exact stronger ending that happened instead
- one truthful residual-state note when the forced ending is not identical to full cleanup
- one ancestry link to the final effect receipt or teardown rail when those exist

## What to keep from older inspirations

Keep:
- Kubernetes-style grace periods and maintenance-state honesty
- AWS load-balancer-style draining timeout with a visible post-timeout state
- Envoy-style graceful drain before closure with an explicit drain timeout
- systemd-style bounded shutdown time plus explicit extension messages
- Temporal-style cancel-versus-terminate separation
- nginx-style graceful quit versus fast stop distinction

Peel away:
- infinite “stopping…” limbo
- hidden automatic extensions
- one ambiguous stop badge that covers drain, timeout, terminate, detach, and cleanup
- fake calm that hides the fact that grace elapsed and a stronger ending took over

## Why this makes Helm more awesome

This move upgrades several existing Helm surfaces:

- **Operations Center** can show “draining, 37s left, auto-cut-through if unchanged” instead of one vague stopping pill.
- **Recall** can preserve whether a calm historical card ended gracefully or by forced cut-through.
- **Exchange** can keep “stop admitting new arrivals” distinct from “terminate remaining sessions when grace expires.”
- **Trusted chrome** can give operators one humane, shell-owned answer during maintenance: budget, extension posture, blockers, and exact post-expiry action.

## Pull-the-trigger judgment

This is worth warming now.
Not as a new pillar,
and not as a giant lifecycle controller,
but as one more compact shell law:

**graceful maintenance should be bounded,
expiry-honest,
and explicit about whether the story ended cooperatively or by cut-through.**
