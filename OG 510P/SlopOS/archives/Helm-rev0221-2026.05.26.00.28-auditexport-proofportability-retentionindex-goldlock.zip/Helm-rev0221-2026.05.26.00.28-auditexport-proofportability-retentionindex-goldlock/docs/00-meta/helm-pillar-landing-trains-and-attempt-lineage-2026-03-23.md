# Helm: pillar landing trains and attempt lineage — 2026-03-23

## The call in this revision

Keep the seven pillars.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes**,
**bounded rehearsal decks**,
and **pillar-specific recipes** as the current datacube grammar.

But add one narrower cross-pillar support object:

**when a recipe or reviewed slice crosses into a stronger lane,
Helm should be able to hand it to one optional landing train with attempt-aware lineage,
continuation handles,
and exact remainder truth.**

## Why this now looks wiser than more deck machinery

The deck recipe pass made Helm more concrete.
But it also made a missing seam more obvious.
A deck can prepare,
compare,
and stage work.
It still needs a humane answer to:

**what if this stronger landing is ordered,
group-checked,
retried,
partially complete,
or still live through one exact continuation handle?**

Today many products answer that with folklore:
- “green enough”
- “retry”
- “still running”
- “partial”
- or one history row pretending to be live next-step truth

Helm can do better.

## The new split Helm should preserve

### 1. Landing train
A compact ordered promotion object for several candidates aimed at one stronger authoritative lane.

It should answer:
- where am I in line?
- what exact grouped basis / queue weather was I checked against?
- was I rebuilt,
  invalidated,
  paused,
  continued,
  rolled back,
  or removed?

### 2. Attempt lineage
A compact distinction between:
- one durable story identity
- and one particular attempt within that story

That keeps rebuilds,
runs,
reruns,
and redrives visible without fragmenting history into unrelated blobs.

### 3. Continuation handle
A compact live witness that there is still one exact truthful next-step window.

Examples:
- poll
- wait
- continue
- cancel
- redrive failed execution
- rerun failed subset
- reopen unresolved slots

### 4. Remainder witness
A compact unfinished-slice witness for what exactly is still left.

That keeps “partial” from flattening into prose.

## What current official patterns are teaching

The outside pressure lines up unusually well:
- GitHub merge queue and merge-group checks keep grouped landing distinct from isolated PR checks.
- GitHub `run_attempt` keeps attempt identity distinct from whole-run identity.
- Step Functions redrive keeps successful history while continuing from the failed step.
- Kubernetes indexed jobs keep successful and failed subsets explicit.
- Google long-running operations keep one named live continuation handle with done / response / error posture.
- LaunchDarkly guarded rollouts keep staged exposure,
  monitoring,
  and rollback separate from one-step landing.

That is more than enough pressure to justify a local Helm move.

## How this fleshes the pillars

### Tiling Shell
Layout restore,
workspace migration,
or session repair can queue into one stronger landing lane instead of impersonating immediate settled truth.

### Omnibox
Multi-target or higher-authority actions can keep one story id,
one attempt id,
and exact remainder when only some targets completed.

### Object Browser
Publish / adopt / reveal acts can keep grouped checks,
queue order,
and exact continuation after a partial or paused landing.

### Operations Center
This is the clearest home.
Apply,
promote,
repair,
redrive,
and observe partial remainder without inventing one more giant control plane.

### Desktop Flow
Longer multi-step flows can preserve exact attempt history and explicit continuation windows without pretending the flow is one opaque job.

### Recall
Restores,
rehydration,
and return-to-work stories become sharper when old receipts do not impersonate still-live continuation handles.

### Exchange
Take / route / materialize / adopt sequences can preserve which exact transfer story is still live,
what exact subset remains,
and which attempt is current.

## What to keep from older inspirations

Keep:
- exact footing
- ordered stronger lanes when order matters
- partial remainder smaller than original cohort
- stable story identity with explicit attempts
- live continuation weaker than settled outcome
- pause / continue / rollback honesty

Drop or defer:
- giant deployment center ambition
- one workflow engine to rule every pillar
- generic retry language
- silent regrouping after basis drift
- history rows that pretend they are still live handles

## First specimen worth proving

The best first specimen still looks like one **Object Browser or Operations Center landing train**:
- one exact reviewed slice
- one stronger target lane
- at least two candidate items or two attempts of the same story
- one grouped-check or invalidation event
- one continuation handle
- one remainder witness when only part of the story remains
- and one later settlement / calibration reopen path

## Product sentence this revision supports

Helm gets super awesome not by adding another pillar,
but by making every serious stronger act legible:
**where it is in line,
what exact grouped footing it was checked on,
which attempt this is,
what can still be continued,
and what exact smaller slice remains.**
