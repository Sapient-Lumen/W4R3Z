# Research bibliography — 2026-03-22 — pass LXXXIII

1. **Google Drive API docs — Choose Google Drive API scopes**
   - source: https://developers.google.com/workspace/drive/api/guides/api-specific-auth
   - used for: separating the highest scopes an app may ever request from the specific scopes requested in a session

2. **Google OAuth docs — Using OAuth 2.0 for Web Server Applications**
   - source: https://developers.google.com/identity/protocols/oauth2/web-server
   - used for: incremental authorization, include-granted-scopes posture, token revocation, and time-based access

3. **Google OAuth overview — Using OAuth 2.0 to Access Google APIs**
   - source: https://developers.google.com/identity/protocols/oauth2
   - used for: scope as the resource/operation boundary on issued access tokens

4. **XDG Desktop Portal docs — File Chooser**
   - source: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileChooser.html
   - used for: exact chosen-file access via portal-mediated selection and cross-session accessibility through the Documents portal

5. **XDG Desktop Portal docs — Documents**
   - source: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
   - used for: per-app document permissions, grant/revoke/delete posture, and exact file-to-app permission mapping

6. **AWS IAM docs — Temporary security credentials in IAM**
   - source: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp.html
   - used for: temporary borrowed credentials as a model for lease windows

7. **AWS IAM docs — Compare AWS STS credentials**
   - source: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_sts-comparison.html
   - used for: session policies as an intersection-bounding model for borrowed power

8. **Chrome for Developers — The File System Access API**
   - source: https://developer.chrome.com/docs/capabilities/web-apis/file-system-access
   - used for: exact file handles, user-gesture file selection, and the handle-versus-permission split

9. **Chrome for Developers blog — Persistent permissions for the File System Access API**
   - source: https://developer.chrome.com/blog/persistent-permissions-for-the-file-system-access-api
   - used for: allow-this-time versus allow-on-every-visit posture and per-item revocation
