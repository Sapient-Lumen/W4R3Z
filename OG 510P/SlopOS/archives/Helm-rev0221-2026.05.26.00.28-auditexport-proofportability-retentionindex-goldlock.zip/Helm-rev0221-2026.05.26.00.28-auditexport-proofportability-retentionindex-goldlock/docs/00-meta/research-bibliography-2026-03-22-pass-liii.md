# Research bibliography — 2026-03-22 — pass LIII

1. **GitHub Docs — About protected branches**
   - source: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
   - used for: exact diff state at approval time, dismiss-stale-approvals posture, and most-recent-reviewable-push discipline

2. **GitHub Docs — Comparing commits**
   - source: https://docs.github.com/en/pull-requests/committing-changes-to-your-project/viewing-and-comparing-commits/comparing-commits
   - used for: compare branches/tags/commits as explicit compared-basis surfaces

3. **GitHub Docs — About comparing branches in pull requests**
   - source: https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-comparing-branches-in-pull-requests
   - used for: three-dot merge-base comparison and “what the pull request introduces” basis law

4. **VS Code docs — Revert changes with checkpoints and editing requests**
   - source: https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
   - used for: exact checkpoint restore, revert-subsequent-changes posture, and edit-prior-request distinction

5. **VS Code docs — Git Branches and Worktrees in VS Code**
   - source: https://code.visualstudio.com/docs/sourcecontrol/branches-worktrees
   - used for: compare worktree changes with workspace before migration

6. **Notion Docs — Create a view query**
   - source: https://developers.notion.com/reference/create-view-query
   - used for: cached result-set creation, `query_id`, and 15-minute expiry posture

7. **Notion Docs — Get view query results**
   - source: https://developers.notion.com/reference/get-view-query-results
   - used for: 404-after-expiry behavior on saved/cached result slices

8. **Google Docs Editors Help — Find what's changed in a file**
   - source: https://support.google.com/docs/answer/190843?co=GENIE.Platform%3DDesktop&hl=en
   - used for: blue-dot changed-since-last-viewed cue, version history, restore/copy earlier version, named versions, and merged-revisions warning

9. **Figma Help — View a file's version history**
   - source: https://help.figma.com/hc/en-us/articles/360038006754-View-a-file-s-version-history
   - used for: named versions, non-destructive restore, duplicate-a-version, share-a-version, and autosave checkpoints after restore

10. **Figma Help — Request a branch review**
    - source: https://help.figma.com/hc/en-us/articles/5691414603543-Request-a-branch-review
    - used for: preview changes before merge and explicit review status outcomes

11. **Figma Help — Merge branch into main file**
    - source: https://help.figma.com/hc/en-us/articles/5691189138839-Merge-branch-into-main-file
    - used for: side-by-side and overlay compare views plus whole-branch merge posture
