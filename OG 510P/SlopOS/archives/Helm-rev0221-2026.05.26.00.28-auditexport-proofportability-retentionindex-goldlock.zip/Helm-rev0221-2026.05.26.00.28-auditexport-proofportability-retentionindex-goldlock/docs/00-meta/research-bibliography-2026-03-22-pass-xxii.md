# Research bibliography — 2026-03-22 pass XXII

Official/public sources consulted in this pass:

- VS Code Docs — Using agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- VS Code Docs — User and workspace settings  
  https://code.visualstudio.com/docs/configure/settings
- VS Code Docs — Revert changes with checkpoints and editing requests  
  https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- VS Code Docs — December 2025 (version 1.108) / Copy breadcrumbs path  
  https://code.visualstudio.com/updates/v1_108
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — Adding Dock support to your extension  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Apple Support — Take actions and shortcuts in Spotlight on Mac  
  https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac
- Apple Support — Search for anything with Spotlight on Mac  
  https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac
- Apple Support — Spotlight keyboard shortcuts on Mac  
  https://support.apple.com/guide/mac-help/spotlight-keyboard-shortcuts-mh26783/mac
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Apple Support — What's new in the updates for macOS Tahoe 26  
  https://support.apple.com/en-us/122868
- Arc Help Center — Split View: View Multiple Tabs at Once  
  https://resources.arc.net/hc/en-us/articles/19335393146775-Split-View-View-Multiple-Tabs-at-Once
- Arc Help Center — Pinned Tabs: Tabs you want to stick around  
  https://resources.arc.net/hc/en-us/articles/19231060187159-Pinned-Tabs-Tabs-you-want-to-stick-around
- Arc Help Center — Arc for Windows 2023-2026 release notes (Peek and command actions)  
  https://resources.arc.net/hc/en-us/articles/22513842649623-Arc-for-Windows-2023-2026-Release-Notes
- Notion Docs — Working with views  
  https://developers.notion.com/guides/data-apis/working-with-views
- Notion Docs — Creating pages from templates  
  https://developers.notion.com/guides/data-apis/creating-pages-from-templates
- Airtable Support — Getting started with Airtable views  
  https://support.airtable.com/docs/getting-started-with-airtable-views
- Airtable Support — Using the view share menu in Airtable  
  https://support.airtable.com/docs/using-the-view-share-menu-in-airtable
- Figma Help — Compare changes in Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Docs — Session Navigation  
  https://docs.warp.dev/terminal/sessions/session-navigation
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- Obsidian Help — Introduction to Bases  
  https://help.obsidian.md/bases
- Obsidian Help — Workspaces  
  https://help.obsidian.md/plugins/workspaces
- Obsidian Help — How Obsidian stores data  
  https://help.obsidian.md/data-storage
