# Helm: datacube truth axes and basis routes — 2026-03-23

## The call in this revision

Keep the seven pillars.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep the newer **reviewed-slice round-trip** as the right connective tissue.

What changes in this pass is narrower and more useful:
Helm should make its datacube richer through two shell-wide laws,
not through another pillar,
another center,
or one giant operator dashboard.

Those laws are:

1. every compact shell surface should expose a small set of **truth axes**
2. every nontrivial derived surface should expose one exact **basis reopen route**

That is how Helm gets more luxurious without getting more dishonest.

## Why this is the right next move

Helm already has many good candidate luxuries:
- state tuples
- reviewed slices / cohort windows
- basis explorers
- rule-insight cards
- guarded promotion ladders
- patrol decks
- settlement witnesses
- calibration witnesses

What it still needs is a cleaner answer to this question:

**when a card, strip, deck, tile, or row says something important, what exact truth is it claiming, how fresh is that truth, what footing supports it, and how do I reopen that footing?**

Without that answer,
Helm risks becoming a beautiful blob.
With it,
Helm keeps becoming sharper.

## The lessons Helm must learn from the past

### 1. One badge always lies eventually

A shell can survive many small object families.
It does not survive one flattering scalar.
The past keeps showing the same failure mode:
`healthy`,
`ready`,
`shared`,
`reviewed`,
`current`,
and `done`
start life as conveniences,
then quietly absorb too many truths.

### 2. Preview must stay weaker than live truth

The user can love previews,
diffs,
plans,
recommendations,
and guardrails.
But a preview is still not a live effect,
and a prediction is still not settlement.
Any shell that forgets that becomes delightful right before it becomes dangerous.

### 3. Mutable basis must not hide in the air

If a reviewed action depends on the current head,
current target,
current queue item,
current route,
or current audience,
that basis must be carried explicitly.
Otherwise an old review silently rides onto a new subject.
That is poison.

### 4. Approximate success is still a different truth class

A repaired restore,
a parent browse instead of exact reveal,
a cached diff,
a stale usable answer,
a preview asset,
or an adapter-backed rendering may still be useful.
But they are not the same truth as the exact requested thing.
Helm must keep rewarding those distinctions.

### 5. Giant cubes usually compensate for missing boundary objects

When a design keeps wanting one enormous control center,
it is often because it lacks a few smaller objects:
- saved views
- reviewed slices
- basis explorers
- settlement surfaces
- calibration links
- bounded patrol decks

The cure is rarely one bigger cube.
It is usually a few better cuts.

## What the local companion archives are teaching right now

### SlopOS

The current SlopOS bundle keeps teaching three brutal laws:
- approval must bind one **exact mutable basis**, not a floating head
- selection should return a **bounded candidate set**, not a hidden winner
- exact show-item intent should **fail closed** rather than degrade into a nearby browse

That is perfect Helm pressure.
It says the datacube should favor **exact basis, explicit choice, and honest failure** over helpful blur.

### Schell

Schell remains one of Helm's best teachers because it is still embryonic.
It keeps forcing the separation between:
- proposal
- review
- run
- later outcome

Helm should keep stealing that stage law,
not freeze all of Schell's chrome.

### ViewFS

ViewFS keeps proving that editable text,
parsed structures,
advisory diagnostics,
compiled command packets,
prepared actions,
and durable receipts are different truths.
That is exactly the pressure Helm needs for Browser,
Flow,
and Omnibox surfaces.

### Harbor, Foundry, Ward, and Steward

These companions keep repeating the same warning in different costumes:
- coarse origin is weaker than durable trust
- actor path matters for audit but is smaller than current authority
- read cuts and staleness budgets must stay distinct from current truth
- adaptation and backpressure are not the same as failure or readiness

Together they are telling Helm to prefer **typed cuts** over dashboard mythology.

## The current official steals worth taking seriously

### GitHub

GitHub's current ruleset stack is a very strong model for Helm.
Rulesets are explicit objects;
Rule Insights show pass / fail / bypass events and can also show what would have happened in **Evaluate** mode;
merge queue sits on top as a separate promotion mechanism rather than collapsing rule posture into immediate merge truth.
That is almost a direct recipe for Helm's **rule-insight cards**, **guarded promotion ladders**, and **settlement rows**.

### LaunchDarkly

LaunchDarkly is still one of the best current teachers for the space between preview and rollout.
Its targeting test runs let you compare **current targeting** with **unsaved changes** for one exact context,
and guarded rollouts progressively increase traffic while monitoring metrics for regressions and can pause or roll back.
That is exactly the shape Helm wants for **exact-subject preview**, **cohort windows**, and **guarded promotion with pause-on-regression**.

### Terraform

Terraform still keeps the strongest plan-only law.
A speculative plan describes what would happen,
but carries no intent to apply.
That is a crisp reminder that Helm previews should stay useful while still being visibly weaker than stronger acts.

### Kubernetes

Kubernetes Server-Side Apply keeps field ownership inspectable through `managedFields`,
and `kubectl apply view-last-applied` gives a direct reopen path to the last applied basis.
That is a beautiful proof that **basis inspection** can be first-class and compact instead of hidden in lore.

### Argo CD

Argo CD's current diff strategies are also very instructive.
It distinguishes desired state from live state,
can generate a predicted live state with Server-Side Diff in dry-run mode,
and it says exactly when cached diff results will be refreshed.
Helm should steal that honesty around **predicted live**, **cached compare**, and **refresh triggers**.

### OPA

OPA decision logs preserve the queried policy,
input,
bundle metadata,
and other information useful for auditing and offline debugging.
That is strong support for Helm keeping later audit and calibration attached to the original decision footing rather than just the final verdict label.

## The datacube truth axes Helm should emphasize now

Helm already has state-tuple pressure.
This pass sharpens where that pressure matters most.

A compact shell surface should try to answer these questions:

1. **scope** — what exact subject, slice, or cohort is this claim about?
2. **phase** — is this proposal, review, guarded exposure, live state, settlement, or history?
3. **freshness** — is this current, stale-but-usable, historical, or unknown?
4. **basis** — what witness produced this claim?
5. **settlement** — what has actually landed durably so far?
6. **reopen route** — where do I go to inspect the exact footing?

Not every tiny chip needs every axis printed at once.
But every serious card should have them available.

## Basis routes are the secret sauce

The cube gets much better when every serious surface can reopen one exact footing.
A basis route might reopen:
- the reviewed slice
- the exact target set
- the rule-insight card that justified a move
- the last applied basis
- the settlement witness
- the calibration witness tied to that same slice

This is the move that turns Helm from “pretty summary shell” into “shell that can defend its own claims.”

## Moves that could make Helm super awesome

### 1. Exact-subject rehearsal everywhere

Any stronger mutable or reveal-class act should be able to answer:
**show me this on one exact subject first**.
Not a confidence score.
Not a marketing preview.
One exact subject,
one exact slice,
one exact cohort window.

### 2. Why-this-would-pass cards

Before a stronger act,
Helm should increasingly be able to say:
- what rule stack matters
- what currently passes
- what fails
- what would require bypass
- what footing those claims stand on

That is much more useful than one generic “blocked” state.

### 3. Compact truth tuples in nearby chrome

The datacube becomes dramatically better when small nearby chrome can admit:
- preview only
- stale usable
- basis drifted
- settled locally
- replicated but not receiver-visible
- historical only

That kind of honesty feels premium,
not bureaucratic.

### 4. Patrol decks instead of giant dashboards

A patrol deck should stay bounded:
one round,
one issue,
one slice,
one review packet,
one reopen path.
The deck should be allowed to mix narrative,
live evidence,
rule weather,
and settlement truth,
but it should refuse to become an omniscient center.

### 5. Templates that confess mapping debt

Templates are worth stealing only when they admit their missing fields,
uncertain footing,
or weak bindings.
A “great template start, but these three mappings are unresolved” surface is much better than false universality.

### 6. Calibration that reopens the earlier promise

When Helm later says,
“that prediction missed,”
it should reopen the exact earlier rule-insight or slice rather than invent a post-hoc explanation.
That is the difference between trust-building and theater.

## What is wise to decide now

It is still **not** wise to add another pillar.
It is still **not** wise to freeze a giant datacube center.

It **is** wise to say:
- every pillar should increasingly expose compact **truth axes**
- every serious surface should increasingly expose one exact **basis reopen route**
- and the shared reviewed-slice round-trip is the right connective tissue that carries those truths across the product

That is a narrow trigger,
but a very good one.
