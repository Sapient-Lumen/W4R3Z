# SlopOS + companions evaluation — 2026-03-22 — pass LXXXVII

Purpose: continue mining SlopOS, Schell, ViewFS, and Steward for laws Helm should steal **now** while those companion cubes are still design-phase systems.

## Main judgment

This pass strengthens one specific conclusion:
Helm does **not** need to let strong review and approval surfaces live inside ordinary app content.
It needs a **small trusted chrome / review lane**.

The best next shape now looks like:
- **trusted chrome lanes**
- **host-effect witnesses**

That is the smallest shell-native move that can make imports, strong actions, and protected follow-ups feel much more trustworthy without forcing a new pillar or a giant security constitution.

## 1. SlopOS still teaches the deepest rule: mediation and approval belong on explicit seams

SlopOS keeps converging on the same lesson through approval-basis, chooser, and auth-mediation families:
**authority-bearing review should not be smuggled through ordinary content surfaces.**

That matters directly for Helm.
A shell should be able to say:
- this row or packet asked for a stronger act,
- this stronger act moved into a shell-owned review lane,
- this approval or denial had one exact local basis,
- and this historical review surface is weaker than current live authority.

Without that split,
imports,
previews,
and strong asks drift into folklore.

## 2. Schell is now the clearest teacher: trusted chrome must stay outside PTY or app flow

Schell's `trusted-chrome-secure-review-lanes-and-anti-spoof-separation.md` is the strongest companion pressure in this pass.
Its key lesson is that one shell can have several visible truth grades:
- raw content,
- inferred structure,
- shell-attested structure,
- and trusted chrome.

That is exactly the shell law Helm needs.
Strong review cards,
grant prompts,
deny/hold cards,
and protected follow-up prompts should not be rendered as if they were just another part of the pane,
page,
or imported surface.

## 3. Steward sharpens the same answer: chrome is useful, but it is not the transcript and it is not authority

Steward's chrome-lane,
label-surface,
and surface-diagnostics postures keep reinforcing a healthy split:
- compact shell chrome can summarize,
- diagnostics can explain,
- but neither should silently become the canonical record or the authority itself.

That is the right pressure for Helm.
A trusted chrome lane should stay:
- shell-owned,
- compact,
- obvious,
- transcript-visible through receipts or witness lines,
- but still distinct from the ordinary content flow.

## 4. ViewFS keeps the lane-separation lesson honest

ViewFS remains most useful here as a teacher of lane separation.
Its observe / attach / control / exec / sideband split keeps showing why “I can see it” must not silently become “I can control it.”

That is exactly why a trusted chrome lane matters.
A provider row,
watch stream,
imported preview,
or attached pane may motivate a stronger act.
The final trustworthy review or approval surface should still move into shell-owned chrome.

## 5. What Helm should steal now

### Steal
- one compact **trusted chrome lane** outside ordinary provider or app surfaces
- one visible **trust ladder** such as raw / inferred / shell-attested / trusted-chrome
- one **review-lane rule**: high-risk approval/denial surfaces do not live only inside content flow
- one **host-effect witness** family for title changes,
  clipboard writes,
  link opens,
  protected prompts,
  or other shell-side effects requested by weaker-origin surfaces
- transcript-visible receipts that say **trusted chrome hosted this decision**

### Do not steal yet
- no giant secure-attention or OS-auth mythology in v0
- no giant badge/chrome framework
- no app-embedded faux security theater
- no attempt to make every prompt a universal policy studio
- no design-phase overfitting to unsettled companion machinery

## 6. Candidate shell move

The next sharp Helm move is therefore not another pillar.
It is one compact answer to a common shell question:

**where do authority-bearing review and approval surfaces live,
and how does the shell confess when weaker-origin content asked for a host-side effect?**

That answer now looks like:
- **trusted chrome lane**
- plus **host-effect witness**.

## Judgment

SlopOS and the companion cubes are still worth treating mainly as teachers of **laws**.
This pass says the relevant law is now:

**strong review should move into shell-owned trusted chrome,
and weaker-origin content should only be able to request shell-side effects through witnessed,
reviewable seams.**

Helm should prove that before it invents bigger security or policy machinery.
