# Helm obligation ledgers / follow-through dues — 2026-05-16

## Core move

rev0198 adds **obligation ledgers** after exception leases.

The product idea is deliberately small: after Helm grants, denies, expires, or redeems a temporary exception, the system should show what work is still owed. That work needs an owner, due time, evidence, debt budget, escalation, closure proof, and an explicit warning that the obligation cannot itself authorize release readiness.

## Why this matters

Exceptions without obligation ledgers become folklore. A stale warning gets silenced and nobody remembers to recheck. A quarantine branch gets extended and nobody decides. An outage exception expires and Recall starts sounding current. A redeemed hold becomes a de facto policy. The ledger prevents that.

## Pull the trigger

Pull the trigger on:

- `obligation_ledger` as a candidate proof-fixture object;
- one or more obligations for every release-readiness exception lease;
- five postures: due, blocked, overdue, discharged, and monitoring;
- visible debt budget and escalation fields;
- the rule that debt budget explains urgency but never becomes authority.

Do not pull the trigger on ticketing/workflow/policy/service-catalog/SLO/cost engines yet.

## Helm-specific phrasing

Obligations are not tickets. They are **truth-bearing due-work rows** in Helm’s datacube. A ticket may later be a projection of one. A workflow may later process one. A scorecard may later summarize one. But the source object should stay small and specimen-proven first.
