# Research bibliography — 2026-03-23 pass CLIII

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GITHUB-RULESETS-EVALUATE-2026L | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets | GitHub contributes explicit Evaluate mode and Rule Insights for would-pass / would-fail truth without enforcement. |
| REF-LAUNCHDARKLY-TEST-RUN-2026L | https://launchdarkly.com/docs/home/flags/preview-rules | LaunchDarkly contributes exact-context test runs plus percentage summaries after targeting changes. |
| REF-AWS-IAM-POLICY-SIM-2026L | https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_testing-policies.html | AWS IAM contributes safe policy simulation plus unusually clear caveats: live results can differ and no response body is produced. |
| REF-TERRAFORM-PLAN-2026L | https://developer.hashicorp.com/terraform/cli/commands/plan | Terraform contributes speculative-plan versus saved-plan distinction. |
| REF-HCP-TERRAFORM-SPEC-2026L | https://developer.hashicorp.com/terraform/cloud-docs/workspaces/run/modes-and-options | HCP Terraform contributes plan-only/speculative runs that show possible changes and Sentinel policy checks but cannot apply. |
| REF-K8S-DRY-RUN-KEP-2026L | https://github.com/kubernetes/enhancements/blob/master/keps/sig-api-machinery/576-dry-run/README.md | Kubernetes contributes the law that dry-run should reveal whether a request would have succeeded and what would have happened while staying as close as possible to live response shape. |
| REF-KUBECTL-DIFF-2026L | https://kubernetes.io/docs/reference/kubectl/generated/kubectl_diff/ | kubectl contributes direct server-side diff posture in the CLI. |
| REF-ARGOCD-SERVER-SIDE-DIFF-2026L | https://argo-cd.readthedocs.io/en/stable/user-guide/diff-strategies/ | Argo CD contributes cached server-side dry-run diff plus explicit caveats for new resources and creation-time webhook validation. |
| REF-OPA-EXPLAIN-2026L | https://www.openpolicyagent.org/docs/rest-api | OPA contributes query explanations and trace events for inspectable policy reasoning. |
| REF-OPA-DECISION-LOGS-2026L | https://www.openpolicyagent.org/docs/management-decision-logs | OPA contributes decision logs with policy, input, bundle metadata, and audit/debug value. |
