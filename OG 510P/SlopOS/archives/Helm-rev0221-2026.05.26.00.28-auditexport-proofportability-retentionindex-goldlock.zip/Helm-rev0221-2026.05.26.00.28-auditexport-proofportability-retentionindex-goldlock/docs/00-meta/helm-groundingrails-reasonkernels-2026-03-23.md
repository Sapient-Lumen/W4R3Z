# Helm grounding rails + reason kernels — 2026-03-23

Purpose: name the strongest next cross-cutting move now that Helm has warmed **state tuples** but still needs a better answer to:

**why does this tiny surface currently say this,
and what is the smallest humane path to inspect more?**

## Main idea

Helm now has enough status grammar.
It needs a better **explanation grammar**.

The answer is to warm three cooperating pieces:
- **state tuples** for what the compact surface is claiming
- **grounding witnesses** for what class of witness produced the claim
- **why rails** for one bounded explanation seam near the compact surface

A why rail should not be a hidden log viewer.
It should not be a giant provenance graph.
It should be the smallest shell-owned reveal that can answer:
- why this state
- why now
- why not stronger
- and what to inspect next

## Reason kernels

The smallest useful explanation atom looks like a **reason kernel**.
A reason kernel would likely carry:
- one short machine-readable reason code
- one short human-readable message
- one since/observed time
- one witness class
- one redaction/withheld-support hint when relevant
- one inspect exit to the stronger source surface

That is enough to make tiny chrome feel grounded instead of mystical.

## Why this now looks ripe

State tuples already separate:
- phase
- typed conditions
- freshness
- basis
- last durable outcome

But users still need a quick answer to:
- what witness produced the current condition?
- what changed most recently?
- why did this fall from current-live to last-confirmed?
- why is this held or restricted?
- what details are being withheld?

Grounding witnesses and why rails are the missing seam.

## What this lets Helm do better

### 1. Make compact chrome answerable
A reality-strip slot,
current-live beacon,
Recall postcard,
or Operations row can now answer *why* without becoming huge.

### 2. Keep explanation bounded
The first reveal can stay one layer above logs,
receipts,
or raw provider payloads.

### 3. Preserve weak-vs-strong truth
A why rail can point to a stronger source surface without pretending the compact surface is now authoritative.

### 4. Keep redaction visible
If some support is hidden,
Helm can say so directly instead of making the explanation look mysteriously incomplete.

### 5. Make stronger next moves obvious
A reason kernel can point toward:
- inspect basis
- inspect operation
- revalidate now
- open receipt
- open review
- narrow/revoke
- hold

## What not to steal

- no giant always-open diagnostics pane
- no one universal confidence score
- no raw logs as the default reveal
- no pretending message text is proof by itself
- no explanation that erases freshness or witness class

## Pull-the-trigger judgment

Keep the seven pillars stable.
Keep state tuples.
Do not add another pillar.

But now it looks wise to **promote grounding witnesses and why rails** as the next cross-pillar proof target.

If Helm gets this right,
it can feel much smarter because every tiny shell surface gains a humane answer to:

**what exactly am I seeing,
why does it currently say this,
and what stronger truth can I inspect next?**
