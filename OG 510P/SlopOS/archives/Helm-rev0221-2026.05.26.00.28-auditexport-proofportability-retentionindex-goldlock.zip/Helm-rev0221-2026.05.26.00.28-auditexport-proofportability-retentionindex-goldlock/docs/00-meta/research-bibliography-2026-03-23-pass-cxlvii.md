# Research bibliography — 2026-03-23 pass CXLVII

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-GITHUB-RULESETS-STALE-REVIEW-2026F | https://docs.github.com/en/enterprise-cloud@latest/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets | exact reviewed-diff state, stale approval dismissal, and `most recent reviewable push` give Helm a strong precedent for graded re-review gates |
| REF-FIGMA-REQUEST-BRANCH-REVIEW-2026F | https://help.figma.com/hc/en-us/articles/5691414603543-Request-a-branch-review | request / review / approve / changes-suggested posture is a strong precedent for review-gate state |
| REF-FIGMA-GUIDE-TO-BRANCHING-2026F | https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching | exact branch-from-main footing, update-from-main posture, compare views, and review-again pressure are strong precedents for Helm review windows |
| REF-DAGSTER-CHANGED-IN-BRANCH-2026F | https://docs.dagster.io/guides/build/assets/asset-selection-syntax/reference | typed reasons like `CODE_VERSION`, `DEPENDENCIES`, `METADATA`, and `NEW` are a strong precedent for Helm change classes |
| REF-DAGSTER-ASSET-VERSIONING-2026F | https://docs.dagster.io/guides/build/assets/asset-versioning-and-caching | `Unsynced` posture after code/dependency/data drift is a strong precedent for review invalidation tied to concrete change kinds |
| REF-DBT-DEFER-STATE-2026F | https://docs.getdbt.com/reference/node-selection/defer | logical compare footing versus applied serving footing is a strong precedent for different re-review causes |
| REF-DBT-CONFIGURE-STATE-2026F | https://docs.getdbt.com/reference/node-selection/configure-state | separate `--state` and `--defer-state`, plus result/source-status selectors, are a strong precedent for typed review triggers |
| REF-DATAFOLD-DIFF-MONITORS-2026F | https://docs.datafold.com/data-monitoring/monitors/data-diff-monitors | row/column discrepancy monitoring is a strong precedent for data-facing change classes |
| REF-DATAFOLD-DIFF-CREATE-2026F | https://docs.datafold.com/data-diff/cross-database-diffing/creating-a-new-data-diff | row/column/value-level detail is a strong precedent for staged diff depth |
| REF-DATAFOLD-DIFF-BEST-PRACTICES-2026F | https://docs.datafold.com/data-diff/cross-database-diffing/best-practices | primary-key-first and per-column-limit guidance is a strong precedent for partial-but-honest compare posture |
| REF-LOOKER-CONTENT-VALIDATOR-2026F | https://docs.cloud.google.com/looker/docs/content-validation | scoped validation, no-undo caution, and development-state validation are strong precedents for later review packets and scoped blast checks |
