# Research bibliography — 2026-03-22 — pass LX

1. **Grafana Plugins documentation — Investigations App**
   - source: https://grafana.com/docs/plugins/grafana-investigations-app/latest/
   - used for: collect interesting signals into manageable lists; annotate them; compare time ranges; navigate signals without many tabs

2. **Grafana Cloud documentation — Run investigations**
   - source: https://grafana.com/docs/grafana-cloud/machine-learning/assistant/guides/investigation/
   - used for: prompt-driven multi-agent investigations; structured report; timeline; activity log; explicit use of the manual Investigations app when manual curation/share is desired

3. **Datadog documentation — Notebooks**
   - source: https://docs.datadoghq.com/notebooks/
   - used for: collaborative rich-text investigation docs with live graphs; templates for incident report/postmortem/runbook shapes

4. **Datadog documentation — Incident Investigation**
   - source: https://docs.datadoghq.com/incident_response/incident_management/investigate/
   - used for: incident details page with properties, signals, documents, responders, notifications, condensed timeline, and recent timeline entries

5. **Elastic documentation — Cases**
   - source: https://www.elastic.co/docs/explore-analyze/cases
   - used for: incidents/document findings/evidence/comments/files in one place with external push/update paths

6. **Linear documentation — Custom Views**
   - source: https://linear.app/docs/custom-views
   - used for: view links, favoriting, default page posture, and view subscriptions as the stronger underlying source object

7. **Linear documentation — Favorites**
   - source: https://linear.app/docs/favorites
   - used for: folders and personal shortcuts as a reminder that the lighter access layer should stay visibly lighter than the stronger source object
