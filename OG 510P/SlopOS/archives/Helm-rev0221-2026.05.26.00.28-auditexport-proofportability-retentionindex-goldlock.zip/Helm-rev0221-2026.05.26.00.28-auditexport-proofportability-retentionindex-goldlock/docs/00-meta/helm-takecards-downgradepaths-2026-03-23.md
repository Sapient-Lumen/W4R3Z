# Helm: take cards + downgrade paths — 2026-03-23

## Headline

Helm should probably add one compact Exchange object for this sentence:

**for this exact offered material and this exact candidate receiver/route,
this is the best honest take available now —
in this representation,
with this operation class,
with these losses or downgrade paths,
and with this edit / confirm / fresh-intent posture.**

That object should be a **take card**.

## Why now

Helm now has a useful pre-route story:
- ingress packets
- transfer offers
- receiver-fit cards
- review strips
- gesture runways
- helper escorts
- route witnesses
- effect receipts

What it still lacks is the compact truth between **offer exists** and **take happened**.
Without that,
Helm still risks five familiar lies:
- a receiver suggestion pretending to mean the receiver can really take the richest form
- `text/html` silently degrading to plain text with no witness
- “share” pretending not to care whether the final act was copy,
  move,
  link,
  attach,
  open-in-place,
  or import
- source-requested move/cut posture pretending the target accepted that operation
- preview imagery or inline style pretending the receiving route will preserve the same representation

## The move

A Helm take card should be:
- shell-owned
- attached to one exact transfer offer and one exact candidate receiver/route
- weaker than the take itself
- explicit about one chosen representation
- explicit about one chosen operation class
- able to show downgrade,
  edit-before-send,
  materialize-first,
  or trust-needed posture
- and easy to promote into a stronger route witness or effect receipt

## Why this is different from nearby objects

- **transfer offer** = what exact source is offering,
  in what representations,
  before a receiver is chosen
- **receiver-fit card** = whether a traveled portable shell object can land on a receiver at all
- **review strip** = compact preflight truth for a stronger action
- **gesture runway** = prepared sensitive act that still stops at a fresh human seam
- **route witness / effect receipt** = what route was actually chosen or what actually happened
- **take card** = for one exact offer and one exact candidate receiver,
  what take is honestly available right now,
  with what chosen representation,
  chosen operation,
  losses,
  and extra steps

That distinction matters.
A receiver may accept a file but not a directory handle.
A route may accept plain text but not rich text.
A source may request move while the target only accepts copy.
A share target may require user edit/confirm before final send.
None of that means the offer was wrong.
It means the **take** needs its own truth object.

## Strongest ideas worth stealing

### 1. Preflight shareability is a real feature
Helm should normalize the idea that the shell can say:
- this exact data is shareable here
- this exact richer form is not
- this receiver only accepts these file types
- this route would require a different representation

That beats optimistic send-and-fail.

### 2. Source wish and receiver acceptance are different truths
Helm should preserve:
- source-requested operation
- receiver-accepted operation
- final actual operation

That is more honest than one generic shared badge.

### 3. Downgrade is not shameful,
 but it must be visible
Great systems already do this implicitly.
Helm should surface it explicitly:
- rich text → plain text
- directory handle → zip or file list
- open-in-place → copy/import
- image preview only → no durable attachment
- file promise → materialize first

### 4. Receiver-side edit/confirm can be part of success
Some good targets should open the exact subject in a confirm/edit posture.
That is not failure.
It is an honest take mode.

### 5. Expensive packaging should stay pay-on-take
If a richer representation or promised artifact is expensive,
Helm should let the take card say so instead of eagerly paying every cost before the receiver actually asks.

## What to keep from older inspirations

Keep:
- typed ingress and typed offers
- preview-before-adopt joy
- exact chosen-target followthrough
- promised-material humility
- route witnesses and effect receipts as separate aftermath truth
- direct-gesture seams for the last strong act when needed

Peel away:
- “copy/paste/share” as one universal action myth
- silent representation downgrade
- stale route memory pretending to mean current receiver fit
- eager conversion into every possible format before anybody asks
- generic success toasts that erase whether the route really copied,
  linked,
  imported,
  attached,
  or opened in place

## Why this could make Helm super awesome

### 1. Exchange gets a premium truthful middle step
Helm can feel unusually exact without becoming bureaucratic.
One tiny card can explain what will really happen if you take this route.

### 2. Rich exchange stops feeling spooky
Drag/drop,
clipboard,
share,
and helper-produced artifacts can stay luxurious without pretending every receiver is equally capable.

### 3. Receiver mismatch becomes graceful instead of annoying
The shell can say:
- choose plain text,
- zip first,
- open a confirm window,
- request stronger permission,
- or pick a different route.

### 4. Saved routes become smarter without becoming hidden defaults
Helm can remember that a receiver often takes HTML-as-plain-text,
that a given route needs edit-first,
or that another route preserves the richer form — while still showing that truth at the moment of choice.

### 5. Helpers get more useful without stealing authorship
A helper escort can prepare likely takes,
compare receivers,
and precompute downgrade options,
but the shell still owns the truthful take card and the final stronger route.

## Pull-the-trigger judgment

Helm still should not freeze one universal clipboard backend,
one final packet ontology,
or a giant share/attach/import framework.
But it probably **is** time to warm one compact Exchange sequel:

**take cards** — shell-owned,
route-local,
reviewable pre-take objects that preserve exact offer,
exact candidate receiver,
chosen representation,
chosen operation class,
downgrade or edit/confirm posture,
and remaining capability/trust gaps
without pretending the route already happened.
