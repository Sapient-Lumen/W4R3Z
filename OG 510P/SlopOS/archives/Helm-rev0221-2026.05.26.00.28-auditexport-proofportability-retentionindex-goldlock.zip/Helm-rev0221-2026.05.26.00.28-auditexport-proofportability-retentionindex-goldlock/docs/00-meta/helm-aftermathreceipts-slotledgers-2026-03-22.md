# Helm: aftermath receipts + slot verdict ledgers — 2026-03-22

## Headline

Helm should get **better at exact aftermath, not bigger at workflow theater**.
The next compact move worth warming is:

- **effect receipts**
- **slot verdict ledgers**

## Why now

Basis stamps solved one important question:

**what exact basis is this thing talking from?**

Action warrants and drift gates solved the next two:

- **what exact strong change is being proposed?**
- **does the reviewed basis still bind strongly enough to proceed?**

What Helm still needs to answer cleanly is the post-act pair:

- **what exact historical effect happened?**
- **which exact subset landed, failed, stayed pending, default-filled, or was rerun later?**

Without that,
Helm risks three lies:

- a success badge that hides what really happened
- a historical action row that impersonates current-live truth
- a partial landing that dissolves into “mostly worked” prose

## The good pattern

### Effect receipts

An effect receipt should carry:
- one exact source act witness
- one exact outcome class
- one exact basis relation
- one exact affected-set witness or compact changed-set ref
- one currentness relation showing whether this is historical-only,
  matched-by-current,
  superseded,
  or unknown against current live truth
- one next-step ladder such as inspect / compare / rerun subset / repair / reverse / cite

### Slot verdict ledgers

A slot verdict ledger should carry:
- one exact owner surface witness
- one durable row for each carried slot / step / branch / item family that mattered
- one verdict vocabulary such as accepted-exact,
  accepted-rebound,
  default-filled,
  left-pending,
  failed-needs-repair,
  refused,
  dropped-by-choice,
  or rerun-succeeded-later
- one compact summary count block
- one repair relation when a later rerun / redrive / replay touched only part of the prior effect

## What to keep from older inspirations

Keep:
- run-summary pages and previous-attempt history
- status-versus-conclusion separation
- polling / pending / done / response / error posture
- per-step or per-index status rows
- rerun-failed-subset and redrive-from-failure posture
- preserving successful history when only the broken subset reruns

Peel away:
- giant workflow consoles
- universal task-state constitutions
- success chips that overclaim currentness
- history rewriting when only a subset is repaired
- one giant log as the only durable aftermath surface

## Why this makes Helm more awesome

This move makes many warm Helm ideas more serious:

- Omnibox can reopen exact historical shell actions through receipts instead of vague recent rows
- Object Browser can show exact historical effect plus exact partial aftermath instead of one green label
- Desktop Flow can carry historical stepwise aftermath without pretending the graph is still live now
- Exchange can make selective landing truth durable instead of prose-only
- Recall can compare exact historical receipt truth with current-live drift
- Operations Center can show pending,
  partially landed,
  rerun subset,
  superseded,
  and historical-only as different states

## Pull-the-trigger judgment

It is wise to warm this now.
Not as a new pillar,
and not as a giant workflow engine,
but as one more compact support proof:
**effect receipts + slot verdict ledgers for exact stronger aftermath.**
