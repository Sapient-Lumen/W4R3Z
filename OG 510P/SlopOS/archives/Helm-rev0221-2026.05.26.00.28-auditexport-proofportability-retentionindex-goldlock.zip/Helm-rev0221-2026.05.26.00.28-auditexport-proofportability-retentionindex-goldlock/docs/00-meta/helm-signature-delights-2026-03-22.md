# Helm signature delights — 2026-03-22

Purpose: name the compact moves that could make Helm feel unusually good before a giant constitution is necessary.

## 1. Parameterized front doors
A front door should be able to carry:
- exact target family
- typed placeholders / parameters
- profile / space posture
- current-live relation
- one inspect-first launch ladder

This is one of the clearest “wow” moves because it makes starters reusable without pretending they are already live.

## 2. Peek without losing your place
Every major shell surface should support a small peek that can:
- preview
- show trust / freshness / derivation
- and promote explicitly to split,
  focus,
  open,
  adopt,
  or attach

## 3. Exact-scope chips beside strong acts
Before reveal,
export,
share,
mute,
rerun,
or apply,
Helm should be able to show:
- exact cohort now
- expected current reach
- dynamic-rule caveat if the set can grow later
- one nearby narrow / broaden path

## 4. Reviewed-basis freshness that can go stale
A warrant,
review,
or approval should visibly bind to what was reviewed.
If the basis changes,
Helm should admit it.
That honesty will feel premium,
not bureaucratic.

## 5. Title witness chips
Small source chips like `shell`,
`override`,
`restored`,
or `profile` would make Helm's chrome feel much more trustworthy than ordinary terminals or desktops.

## 6. Triage lane with explainable suggestions
Operations Center should have one obvious inbox for things that need sorting,
routing,
or adoption.
AI suggestions can help,
but they should arrive as explainable proposals,
not invisible action.

## 7. Continuity postcards
Instead of bluffing a full restore,
Helm can show a tiny card:
- exact return available
- repaired return available
- historical only
- permission needed
- import/adoption needed

That one move could make Recall dramatically more humane.

## Closing judgment

These are the kinds of moves that make Helm feel “super awesome” without asking it to become a giant workspace suite,
a giant admin surface,
or a giant AI operating system.
