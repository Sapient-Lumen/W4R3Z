# Research bibliography — 2026-03-21 pass XVI

Official/public sources consulted in this pass:

- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — PowerToys Command Palette overview  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- Microsoft Learn — Adding Dock support to your extension  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Raycast — Quicklinks  
  https://www.raycast.com/core-features/quicklinks
- Raycast — Clipboard History  
  https://www.raycast.com/core-features/clipboard-history
- Raycast — Notes  
  https://www.raycast.com/core-features/notes
- Raycast — Window Management  
  https://www.raycast.com/core-features/window-management
- Raycast — Home / hotkeys and aliases  
  https://www.raycast.com/
- Apple Support — Take actions and shortcuts in Spotlight on Mac  
  https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- VS Code Docs — User interface / Breadcrumbs  
  https://code.visualstudio.com/docs/getstarted/userinterface
- VS Code Docs — Source Control overview / Timeline view  
  https://code.visualstudio.com/docs/sourcecontrol/overview
- VS Code Release Notes — December 2025 / Copy Breadcrumbs Path  
  https://code.visualstudio.com/updates/v1_108
- VS Code Docs — Tutorial: Work with agents in VS Code  
  https://code.visualstudio.com/docs/copilot/agents/agents-tutorial
- VS Code Docs — Copilot CLI sessions in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/copilot-cli
- VS Code Docs — Cloud agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/cloud-agents
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- WezTerm Docs — Workspaces / Sessions  
  https://wezterm.org/recipes/workspaces.html
- WezTerm Docs — Launcher Menu  
  https://wezterm.org/config/launch.html
- Arc Help Center — Spaces: Distinct Browsing Areas  
  https://resources.arc.net/hc/en-us/articles/19228064149143-Spaces-Distinct-Browsing-Areas
- Arc Help Center — Split View: View Multiple Tabs at Once  
  https://resources.arc.net/hc/en-us/articles/19335393146775-Split-View-View-Multiple-Tabs-at-Once
- Obsidian Help — Workspaces  
  https://obsidian.md/help/plugins/workspaces
- Linear Docs — Search  
  https://linear.app/docs/search
- Linear Docs — Triage  
  https://linear.app/docs/triage
