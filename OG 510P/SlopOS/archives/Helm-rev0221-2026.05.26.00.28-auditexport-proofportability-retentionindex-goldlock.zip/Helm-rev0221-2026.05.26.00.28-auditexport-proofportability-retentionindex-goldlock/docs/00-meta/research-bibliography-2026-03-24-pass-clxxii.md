# Research bibliography — 2026-03-24 — pass CLXXII

Primary sources reviewed for this pass:

1. Git remote branches / remote-tracking branches — bookmarks to last known remote state and tracking-branch posture.
2. Git branch docs — explicit upstream configuration via `branch.<name>.remote` / `branch.<name>.merge`, `--track`, `--set-upstream-to`, and `--unset-upstream`.
3. Git status docs — ahead/behind counts relative to upstream.
4. Figma branching guide — branches begin as exact replicas of main and can receive explicit updates from main.
5. Figma get updates from main files — branch receives and reviews upstream changes from main.
6. Figma merge branch into main — explicit review/merge surface, merge archives the branch.
7. Figma view/manage branches — archived unmerged branches can be restored; merged branches cannot.
8. Kubernetes Server-Side Apply — managed fields, shared ownership, conflicts, and ownership transfer/relinquish posture.
