# Research bibliography — 2026-03-22 — pass XLV

Purpose: record the sources used for the activity-memory-seed and context-recipe pass.

## Primary sources

1. **Projects in ChatGPT**
   - project memory
   - project-only memory
   - shared-project boundary tightening
   - why useful: validates scoped work objects whose memory contract can tighten when shared
   - source: https://help.openai.com/en/articles/10169521-projects-in-chatgpt

2. **ChatGPT Atlas release notes**
   - browser memories
   - explicit “remember this” capture
   - visibility toggles and archive/clear controls
   - why useful: validates explicit remembered context that stays under user control
   - source: https://help.openai.com/en/articles/12591856-chatgpt-atlas-release-notes

3. **VS Code prompt files**
   - workspace versus user-profile prompt file placement
   - why useful: validates explicit scope-local remembered instructions rather than one global mushy memory plane
   - source: https://code.visualstudio.com/docs/copilot/customization/prompt-files

4. **VS Code AI customization overview**
   - instructions
   - prompt files
   - custom agents
   - agent skills
   - parent-repository discovery under trust
   - why useful: validates typed layered customization and trust-aware discovery rather than ambient inheritance
   - source: https://code.visualstudio.com/docs/copilot/customization/overview

5. **VS Code Workspace Trust**
   - restricted mode
   - trust-gated enablement and extension overrides
   - why useful: validates that imported/shared remembered context should not be granted ordinary authority by default
   - source: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust

6. **VS Code Profiles**
   - export/import/share of customization sets
   - why useful: validates saveable shareable structure that is still not identical to live truth
   - source: https://code.visualstudio.com/docs/configure/profiles

7. **Raycast Teams / Quicklinks / Shared Snippets**
   - shared quicklinks and snippets
   - why useful: validates compact reusable remembered actions and text fragments without requiring a giant memory system
   - sources:
     - https://manual.raycast.com/getting-started-with-teams
     - https://manual.raycast.com/quicklinks
     - https://manual.raycast.com/raycast-for-teams-beta/shared-snippets

8. **Warp session management and planning**
   - launch configurations
   - session navigation/restoration
   - persistent plan editor and version history
   - why useful: validates saved starters that benefit from explicit nearby remembered guidance
   - sources:
     - https://docs.warp.dev/terminal/sessions
     - https://docs.warp.dev/agent-platform/capabilities/planning

9. **PowerToys Workspaces**
   - capture desktop state
   - quick-launch into an ideal project/activity layout
   - why useful: validates structure starters that still need explicit local remembered context nearby
   - source: https://learn.microsoft.com/en-us/windows/powertoys/workspaces

10. **Linear projects**
    - attached issue views as tabs inside a project
    - why useful: validates scoped work frames with attached perspectives
    - source: https://linear.app/docs/projects

11. **Google Docs tabs**
    - current tab versus all tabs export/print
    - why useful: validates grouped structure with a still-important current-subthing distinction
    - source: https://support.google.com/docs/answer/15499791

12. **Chrome saved tab groups**
    - saved groups in the bookmarks bar and across devices
    - why useful: validates saveable grouped starters that still are not the same thing as current live state
    - source: https://support.google.com/chrome/answer/2391819

## SlopOS sources re-read this pass

1. `docs/30-architecture/openuri-recent-items-boundary-v0.md`
2. `docs/30-architecture/openuri-materialization-boundary-v0.md`
3. `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`
4. `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`
5. `docs/30-architecture/lease-descriptor-state-boundary-v0.md`
6. `docs/30-architecture/attestation-collateral-status-boundary-v0.md`
7. `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md`

## Why these sources mattered

This pass was not about finding another pillar.
It was about checking whether today’s strongest tools are rewarding:
- explicit remembered context,
- scoped memory,
- trust-aware customization,
- compact reusable prompts/snippets,
- and starters that remain weaker than live truth.

They are.
