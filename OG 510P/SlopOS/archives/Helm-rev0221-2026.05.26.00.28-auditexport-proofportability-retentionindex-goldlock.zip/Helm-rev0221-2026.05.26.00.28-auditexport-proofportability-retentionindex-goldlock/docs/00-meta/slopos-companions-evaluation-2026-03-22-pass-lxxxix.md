# SlopOS + companions evaluation — 2026-03-22 — pass LXXXIX

Purpose: continue reading SlopOS, Schell, ViewFS, and Steward as design-phase teachers rather than as settled machinery donors.

## Main judgment

This pass sharpens one lesson that now feels strong enough to partially freeze:

**Helm should stop letting live-looking status linger forever.**

A shell-owned claim that says **current**,
**hot**,
**ready**,
or **healthy** should carry:
- a last-confirmed witness,
- a visible freshness horizon,
- and an honest downgrade path once that horizon passes.

That is a law worth pulling a little harder now,
while still leaving the final chrome shapes warm.

## 1. What SlopOS is actually teaching right now

SlopOS still looks most useful as a teacher of **discipline boundaries**:
- issuance is not current use,
- request state is not live state,
- exact selection beats nearby retargeting,
- and leased authority should not quietly outlive its proof of liveness.

Because SlopOS is still design-phase work,
Helm should mostly steal the **law** underneath it:
**live-looking truth needs renewal and expiry posture.**

What to keep:
- lease-versus-live separation
- explicit mediation
- exact basis / exact holder posture
- no ambient “still probably current” folklore

What not to keep yet:
- any temptation to invent a giant shell-wide lease calculus before one tiny shell specimen proves the UX
- broader datacube machinery whose main job would be preserving flattering continuity rather than preserving exactness

## 2. Schell is a strong teacher for freshness honesty in trusted chrome

Schell keeps pressuring Helm in a specific way:
if a surface is shell-important,
it should not rely on PTY or app-local text alone to say whether it is still current.

Its watch-witness,
time-ground,
and trusted-chrome instincts all reinforce the same product law:
- show when a statement was last grounded,
- keep current/live distinct from remembered/replayed,
- and let the shell own the downgrade when the shell can no longer prove freshness.

That is exactly the right companion pressure for Helm's Omnibox,
Operations Center,
Recall,
and live borrowed-power strips.

## 3. ViewFS keeps proving that watch and settle posture should decay honestly

ViewFS continues to help most when it insists on:
- watch blocks instead of magical subscriptions,
- settle badges instead of eternal “working” glow,
- and lane separation between observe,
  attach,
  control,
  exec,
  and sideband behavior.

That matters because stale status is often created by **lane confusion**.
A shell says “active” long after it only has an old observation,
or says “ready” long after it only has a remembered settle.

Helm should steal the underlying law:
**when live proof drops away,
downgrade to last-confirmed or stale rather than preserving the stronger badge.**

## 4. Steward is especially aligned on freshness decay

Steward has been one of the clearest companion teachers for:
- remembered versus current labels,
- guide diagnostics that admit approximation or staleness,
- replay review cards with explicit freshness,
- and shell chrome that says when it is showing remembered convenience rather than live authority.

That is very close to what Helm needs now.
The missing move is simply to make that discipline more explicit on shell-wide status surfaces.

## 5. What Helm should steal now

### Pull a little trigger now
Admit one cross-cutting law more firmly:

**every shell-owned current-live or hot-state claim should carry `last_confirmed_at` plus one visible freshness horizon,
and should degrade when that horizon passes.**

That does not force a giant new object family.
It just stops Helm from accidentally shipping flattering stale badges.

### Warm, not frozen yet
- exact chip language for “fresh until / stale after / last confirmed / unknown now”
- exact decay ladders for each family
- whether horizons are implicit defaults,
  object-local policy,
  or explicit shell-owned companions

## 6. Best first proofs

- one Operations Center row that degrades from **hot now** → **last confirmed** → **stale / needs revalidate**
- one active-borrow beacon with a visible freshness horizon and truthful fallback when substrate renewal stops
- one Recall reopen card that says **remembered** instead of **current** after the horizon passes
- one Object Browser watchpoint or glance card that can be shown stale-while-revalidating without impersonating current-live truth

## Judgment

SlopOS,
Schell,
ViewFS,
and Steward still should not drag Helm into a larger constitution.
But together they now justify one firmer shell law:

**liveness without expiry turns into superstition.**

Helm should keep the pillars stable,
but it should start expecting live-looking shell claims to say when they were last confirmed,
when that confidence expires,
and what downgrade or revalidation move comes next.
