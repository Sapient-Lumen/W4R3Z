# Helm: pillar round-trips and reviewed slices — 2026-03-23

## The call in this revision

Helm still does **not** need another pillar.
The seven pillars still look right.
The admitted next shell-wide ratchet still looks right too:
**settlement witnesses + commit cards** should tell the truth about accepted versus durable versus replicated versus receiver-visible aftermath.

The calibration cluster still looks right too:
- **calibration witnesses**
- **miss ledgers**
- **outcome-gap strips**
- and maybe later **reliability notes**

What changes in this revision is not the pillar count.
It is the way Helm should **flesh the pillars out**.

The strongest move now is to give every pillar the same humane round-trip:

1. one **saved view / entry object / front door**
2. one **reviewed slice or cohort window**
3. one **basis explorer**
4. one **rule-insight card**
5. one **guarded promotion ladder**
6. one **settlement witness or commit card**
7. one later **calibration witness / miss ledger**

That is how Helm becomes super awesome without becoming one giant cube.

## Why reviewed slices matter so much

Helm has warmed many good nouns already:
- saved view objects
- checkpoint branches
- smart decks
- live inspector decks
- semantic recipe cards
- serve-path strips
- validator rails
- patrol routes
- settlement witnesses
- calibration witnesses

But those luxuries become much better when they all bind to one exact **reviewed slice** or **cohort window**.
The slice is what makes the later story honest.
It answers:
- what exact thing was being looked at?
- what exact scope was being judged?
- what exact footing did the judgment stand on?
- what exact subset was promoted or exposed?
- what exact outcome came back later?

Without that slice,
Helm drifts toward flattering chrome.
With it,
Helm keeps a real shell memory.

## Pillar uplift map

### Tiling Shell
The shell should get more luxurious through:
- explicit named workspace objects
- exact restore footing and bluff admission
- patrol starts for “return me to this exact operational round”

Do not let workspace glamour become universal state mythology.

### Omnibox
The Omnibox should increasingly summon:
- exact front doors
- saved views
- reviewed slices
- rule-insight cards before stronger moves
- patrol decks for bounded revisits

Do not let search magic become ambient authority.

### Object Browser
This pillar should become the strongest home for:
- saved multi-view objects
- reviewed slices
- basis explorers
- compare-to-live previews
- publication ladders

Do not let Browser convenience collapse result slices,
saved views,
and live truth.

### Operations Center
Ops should increasingly carry:
- guarded promotion ladders
- settlement rows
- calibration reopen paths
- patrol decks for one bounded issue or slice

Do not let Ops regress into process theater or all-green theater.

### Desktop Flow
Flow should emit:
- plan-only artifacts
- reviewed slices
- inspectable rule-insight cards
- later settlement and calibration hooks

Do not let graphs quietly become unreviewed ambient execution.

### Recall
Recall should bind remembered work to:
- exact or approximate return posture
- basis explorer links
- later settlement and miss links
- one patrol deck if the revisit is operational rather than nostalgic

Do not let “recent” pretend to be continuity.

### Exchange
Exchange should increasingly reveal:
- exact cohort windows
- route class
- audience class
- guarded reveal/publish ladders
- receiver-visible settlement aftermath

Do not let “shared” flatten all reveal classes.

## What is wise to decide now

It is **not** yet wise to add a pillar.
It **is** wise to treat **reviewed slices / cohort windows plus round-trip links** as a shared design spine for all seven pillars.

That is a narrow enough decision to be useful,
and broad enough to stop the archive from scattering into unrelated luxury ideas.

## What to keep from older inspirations

Keep:
- saved views instead of one giant browser state
- explicit workspaces instead of one ambient session blob
- preview / peek / inspect before stronger motion
- compact investigation workspaces instead of dashboard sprawl
- exact handles and return paths instead of title/path nostalgia
- explicit sync/share ladders instead of magical portability

Drop or keep resisting:
- universal dashboards
- silent sync-everything pressure
- pretty “healthy” badges that hide basis and age
- proposal surfaces that quietly execute
- restore stories that hide partiality or repair

## Product judgment

The strongest current shape is now:
- keep **settlement witnesses + commit cards** admitted,
- keep the **calibration cluster** warm,
- keep the **basis explorer / rule-insight / guarded promotion / patrol deck** cluster warm,
- and flesh the pillars through one shared **reviewed-slice round-trip grammar** rather than through another pillar or another center.

That is the clearest path to a Helm that feels richly alive,
sharp,
and powerful while still staying honest.
