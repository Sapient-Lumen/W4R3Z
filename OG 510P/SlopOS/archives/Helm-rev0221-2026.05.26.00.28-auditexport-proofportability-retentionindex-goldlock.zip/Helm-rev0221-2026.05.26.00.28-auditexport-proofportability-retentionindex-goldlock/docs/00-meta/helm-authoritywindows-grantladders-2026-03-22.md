# Helm: authority windows + grant-rung ladders — 2026-03-22

## The newest strong lesson

Helm now has enough bounded objects to stop being vague about stronger authority.
What it still lacked was a humane answer to:
- what exact authority exists here right now?
- how broad is it really?
- how long does it last?
- is there an isolated-lane alternative?
- how do I narrow or revoke it later without spelunking provider settings?

The answer now looks like:
**authority windows + grant-rung ladders + revoke handles**.

## Why this is worth keeping

These moves make several warmed objects better at once:
- **action warrants** can point to the exact authority family they need
- **drift gates** can demote old broad grants when basis changed
- **receiver-fit cards** can say what authority did *not* travel
- **shadow work lanes** can offer a safer broader temporary rung than the live lane
- **Operations Center** can finally show current grants, expiry, and revoke nearby
- **Recall** can separate historical grant evidence from current-live authority

## The compact product shape

### Authority window
One bounded shell object for one explicit authority relation.
It should expose:
- holder
- subject / target class
- grant rung
- reviewed basis relation when relevant
- start / expiry / revoked / drifted posture
- current-live witness relation
- revoke / narrow / reacquire next moves

### Grant-rung ladder
One humane chooser for distinct authority rungs.
A first proof likely only needs:
- inspect / no grant
- exact once
- this ask
- this activity
- isolated side lane only
- named persistent scope

### Revoke handle
One nearby live control bound to one authority window or one current-live grant family.
It should keep these acts distinct:
- revoke now
- suspend
- narrow to weaker rung
- narrow subject
- move to isolated-lane only

## Biggest anti-goal

Do **not** build a giant permission center.
Do **not** let imported or historical authority impersonate live authority.
Do **not** let the cheerful broad persistent rung become default law.

## What seems wise to pull the trigger on now

Warm the family explicitly.
Keep it narrow.
Prove it on one or two authority families first.
Good first proof slices would be:
- one browser/tool/site-action family
- one file-or-route/apply family
- one isolated-lane alternative
- one Operations Center inspect/revoke row

That looks much more promising than inventing another giant object family or adding another pillar.
