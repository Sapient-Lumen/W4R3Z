# SlopOS + companions evaluation — 2026-03-22 — pass LXXXIII

Purpose: re-read the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one tighter question:
**what should Helm learn now about capability budgets, current borrowed leases, and renewal discipline?**

## 1. SlopOS keeps teaching that a budget should exist before a surface sprawls

`exit-surface-budget.md` is nominally about privileged entrypoints,
but the rule generalizes beautifully:
**enumerate,
close the set,
budget the variants,
and treat growth as an explicit event.**

Helm should steal that for shell-facing power too.
A front door,
recipe,
flow fragment,
or helper lane should be able to declare:
- which authority families it may ever ask for,
- which subject classes it may target,
- and which widening events require a visibly stronger step.

That is the beginning of a **capability budget**.

## 2. SlopOS still keeps the hardest lease lesson: issued evidence is not current live state

`lease-descriptor-state-boundary-v0.md` remains one of the most valuable teachings in the entire companion set.
A descriptor can be exact issuance-bounded evidence of one reviewed grant shape,
without proving that the grant is still active,
renewable,
or attached to the same holder now.

Helm should import that almost verbatim.
A saved front door,
entry kit,
recipe,
receipt,
or remembered handle may help explain how power was obtained,
but it must not impersonate the shell's current-live lease truth.

## 3. SlopOS also keeps insisting that renewal must not silently widen

`background-lease-posture-v0.md` says background and autostart are distinct grant bits,
and renew/retry flows must not silently widen a live grant.
That is exactly the rule Helm needs once recipes,
front doors,
and remembered handles start helping people reacquire power.

Helm should let reentry be easy.
It should not let reentry quietly smuggle in:
- a broader subject,
- a longer duration,
- a new lane,
- or a stronger persistence class.

## 4. SlopOS's portal notes keep hinting that leases should be ordinary shell truth, not a special emergency path

Across the bibliography and posture docs,
SlopOS keeps treating device access,
clipboard transfer,
background presence,
location,
and other risky seams as portal-mediated,
budgeted,
and often lease-shaped.

That is a huge design clue.
Helm should not reserve lease language for scary expert corners.
Leases should become ordinary shell truth wherever strong temporary borrowing already exists.

## 5. ViewFS and Steward keep the subject exact and the chrome humble

ViewFS remains a good teacher for explicit attenuation and explicit bundles.
Steward remains a good teacher for chooser exactness,
label humility,
and action surfaces that point at concrete targets instead of nearby vibes.

Those two pressures make Helm's next answer sharper:
- budgets should bind exact subject classes,
  not ambient provider families by folklore
- lease windows should cite exact holder,
  exact subject,
  exact rung,
  and exact expiry/revoke posture
- labels should help orientation,
  but stronger witnesses should stay inspectable

## 6. The design-phase lesson now

Because the companion cubes are still in design phase,
Helm should freeze the **law** before it freezes a huge family machine.
That law now looks like this:

1. a shell object may declare a **capability budget**
2. current-live shell truth records only the **lease window** actually borrowed now
3. historical descriptors and recipes help explanation,
   not live authority
4. renewal may reacquire,
   narrow,
   isolate,
   or expire,
   but not silently widen

## 7. Best next Helm proof slices after this pass

- one front door with a visible budget chip and a narrower live lease chip
- one recipe import that preserves budget but starts with no live lease
- one remembered handle that can reacquire the same subject on a narrower or equal rung
- one renewal refusal where widening would require a fresh ask
- one Operations Center row that shows borrowed-now truth separately from historical issuance evidence

## Judgment

SlopOS and the companion cubes are still most useful when they teach **discipline over glamour**.

The next Helm gain is not another pillar,
and not even necessarily a big new object family.
It is a calmer shell law:
- **budget what may ever be asked**
- **show what is borrowed now**
- **make renewal honest about sameness,
  narrowing,
  widening,
  and expiry**

That would make Helm's datacube much more durable while still keeping decisions pleasantly small.
