# Helm datacube pillars: bounded views, restricted arrivals, and activity front doors — 2026-03-22

Purpose: continue fleshing out Helm's datacube as a companion to SlopOS without freezing too much too early.

## Main takeaway

Helm's datacube should not be a giant universal cube.
It should be a shell-owned system of:
- **saved view objects**,
- **bounded derivative view decks**,
- **activity front doors**,
- **current-live beacons**,
- **restricted imported arrivals**,
- **bounded compare surfaces**,
- and **explicit share/sync/publish receipts**.

That shape keeps the pillars strong without adding new pillars.

## What each pillar should now learn

### Tiling Shell

Keep workspaces,
placement,
and launch structure strong.
But learn one important humility from PowerToys-style workspace capture:
a saved desktop arrangement is a **front door**,
not proof that current work is already live.

### Omnibox

It should search and act over:
- exact shell objects,
- saved view objects,
- activity front doors,
- current-live beacons,
- and one obvious triage lane.

Imported or unfamiliar results should show trust posture right in the summon surface.

### Object Browser

This is where the datacube becomes obvious.
The Browser should treat:
- saved view objects,
- multiple explicit view types,
- restricted imported views,
- publication/share ladders,
- compare-from-activity,
- and exact reveal/reopen
as normal product truth,
not optional add-ons.

### Operations Center

It should explain the derivative world honestly:
- what was shared,
- what was synced,
- what publication/sync activity happened,
- what compare/change paths exist,
- what imported surfaces are blocked,
- and what stronger adoption step remains.

### Desktop Flow

Flows should operate on the same exact objects and saved views,
not on private side-state.
A flow-produced or imported front door should stay restricted until adopted.

### Recall

Recall should make the difference between:
- current-live beacon,
- saved front door,
- saved view,
- checkpoint,
- and historical receipt
painfully clear.

A user returning to work should be able to tell whether Helm is reopening the current thing,
opening the saved way in,
or offering only historical evidence.

### Exchange

Exchange should treat views,
decks,
front doors,
and starters as typed packet subjects.
Route,
share,
publish,
import,
and attach should remain visibly different acts.

## Lessons we must learn from the past

1. **Ambient power feels magical before it feels rotten.**
   Keep the reach,
   refuse the ambience.

2. **Saved setup is not live setup.**
   Front doors are good.
   Fake live sessions are not.

3. **Dashboards rot into authority if left unchecked.**
   Derivative surfaces must keep provenance and basis visible.

4. **Search and preview cannot be bolt-ons.**
   A datacube without query-first browsing is just shelfware.

5. **Host law must outrank plugin romance.**
   Extensibility matters,
   but the shell must still own review,
   receipts,
   trust,
   and visibility.

6. **Compare must bind an exact basis.**
   “Changed” is useful.
   “Changed compared to what?” is the real product question.

## Nifty ideas worth stealing

### Steal aggressively

- **local-first view objects**
  - Obsidian keeps proving the shape.

- **custom views under host law**
  - Extensible,
    but still shell-owned.

- **explicit share / sync / publish activity for views**
  - Airtable is the clean teacher.

- **restricted mode for imported surfaces**
  - VS Code Workspace Trust is the best current precedent.

- **launchable activity front doors**
  - PowerToys Workspaces validates the move.

- **compare changes from the activity surface itself**
  - GitHub and Figma both validate this.

- **one dedicated triage lane**
  - Linear keeps proving that users need a named operational inbox.

- **non-destructive checkpoints around restore / branch / merge**
  - Figma still validates this strongly.

### Steal carefully

- **role-shaped interface pages**
  - useful for front doors and receiver-local views,
    but still derivative

- **export/import profiles and carried setup bundles**
  - useful,
    but should not smuggle live state or local overlays

### Resist

- one giant dashboard religion
- ambient sync mythology
- universal workspace mythology
- plugin-defined authority planes
- global always-on index mythology

## What looks wise to pull the trigger on

### Prove soon

1. **saved view objects**
2. **checkpoint branches**
3. **imported-surface trust posture**
4. **activity entry kits / front doors**

### Keep warm

1. **view decks**
2. **deck recipes**
3. **role-shaped interface pages**
4. **personal/shared/published accelerators**

These are exciting,
but they should remain derivative until the stronger saved-view and trust stories are proven.

## Moves that could make Helm super awesome

### 1. Make every front door a tiny truthful control room

A great front door should show:
- preferred door,
- current-live beacon relation,
- one triage lane,
- one compare/changes button,
- trust posture,
- and a clear relaunch / restore / attach / fresh-start ladder.

### 2. Make views promote explicitly

Preview,
view,
compare,
materialize,
adopt,
publish,
and activate should stay visibly different strengths.
That is where Helm can feel unusually honest and unusually strong.

### 3. Make imported shells obviously restricted before they are powerful

An imported view,
deck,
or front door should not quietly wear local-truth clothing.
If stronger actions are blocked,
Helm should say exactly which ones and why.

### 4. Make publication visible in the ops surface

A derivative surface should be able to answer:
who shared this,
where it went,
what tier it is on now,
and whether the receiver still has to fit or adopt it.

### 5. Keep one exact object identity across pillars

The same exact object should be able to survive:
Omnibox → Object Browser → Operations Center → Recall → Exchange
without being copied into five parallel folk ontologies.

## Judgment

Helm does not need more pillars.
It needs a sharper datacube shape.

That shape now looks like:
- **saved views as first-class shell objects**
- **front doors as saved ways back into work**
- **restricted arrivals before adoption**
- **bounded compare near activity**
- **explicit publication/share/sync witnesses**
- **current-live beacons that stay stronger than all of the above**
