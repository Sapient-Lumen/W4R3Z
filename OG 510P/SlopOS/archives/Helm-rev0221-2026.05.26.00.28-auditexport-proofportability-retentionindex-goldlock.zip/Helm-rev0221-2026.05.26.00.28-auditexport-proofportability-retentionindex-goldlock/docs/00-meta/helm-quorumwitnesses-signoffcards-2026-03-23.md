
# Helm quorum witnesses + signoff cards — 2026-03-23

## Why this pass happened

After **succession witnesses**,
Helm could say who currently has the baton,
how the baton moved,
and whether the stronger lane survived the relay.
But it still lacked one humane operator answer:

**even if the baton is in the right hands,
what signoff threshold still stands between candidate work and an authoritative move,
whose signoffs count,
and are those signoffs still valid on the current basis?**

That gap appears across:
- adoption gates between a parallel lane and foreground checkout
- review-gated publish or apply acts
- code-owner or role-owner review rules
- consensus rules where one decline still blocks movement
- optional review versus required review
- stale approval dismissal after basis drift
- bypass-allowed versus genuinely satisfied gate truth

## Product judgment

The next narrow trigger is now worth pulling:

- keep the seven pillars stable
- do not add a new pillar
- keep **succession witnesses** for baton / relay truth
- keep **exception witnesses** for bypass / waiver truth
- promote **quorum witnesses** as the shell-owned compact answer to `what exact signoff gate exists here, how much of it is satisfied, and is that satisfaction still valid on this basis?`
- promote **signoff cards** as the tiny nearby rendering for that gate truth

A quorum witness answers:
- exact subject or bounded cohort
- exact gate / rule family / approval step
- exact reviewed or compared basis
- required count,
  counted count,
  remaining count,
  and optional-versus-required posture
- whose approvals are eligible to count
- whether self-approval,
  author approval,
  or same-pusher approval is disallowed
- whether any decline / veto / requested-changes posture blocks movement
- whether one or more earlier approvals went stale,
  were dismissed,
  or no longer bind the current basis
- whether bypass exists,
  is forbidden,
  or would be weaker than genuine quorum satisfaction
- what exact next move is honest: request review,
  wait,
  refresh basis,
  replace approver,
  bypass-under-exception,
  or merge / adopt / apply

A signoff card answers that truth in one small human-facing form.

## Why this is worth stealing

The current official pressure is unusually clean:

- GitHub branch protection can require a specific number of approvals,
  can require code-owner review,
  and can dismiss stale approvals when new code-modifying commits or a new merge base invalidate the earlier basis
- GitLab approval rules explicitly separate optional rules from required rules,
  allow multiple rules at once,
  and let one approval reduce the remaining count for every rule that approver belongs to
- LaunchDarkly approval settings explicitly separate approvals-required,
  self-approval policy,
  consensus-required policy,
  and bypass eligibility
- Jira Service Management approval steps explicitly separate who can approve,
  who is grouped into approver sets,
  and what workflow movement is blocked until those approvals arrive
- Figma keeps review state visible,
  but also reminds us that `approved` is not always the same thing as `merged` or even `merge-required`

Those systems feel humane because they distinguish **holder truth**,
**signoff-threshold truth**,
**basis-validity truth**,
**bypass truth**,
and **final outcome truth**.

## Lessons Helm must learn from the past

- `approved` is too flattering if the product cannot say **which rule** it satisfied.
- `ready to merge` is too flattering if earlier approvals no longer bind the current basis.
- `review requested` is too flattering if the gate is optional rather than required.
- `needs approval` is too vague if the product hides whether the blocker is count,
  role,
  veto,
  self-approval prohibition,
  or stale basis.
- `bypassed` is too flattering if it impersonates real quorum satisfaction.
- the right shell magic is not hiding the gate;
  it is making the threshold,
  counted signers,
  stale-basis downgrades,
  and bypass posture obvious at a glance.

## What Helm should keep

Keep:
- succession witnesses
- commitment witnesses
- exception witnesses
- footing marks
- review strips
- reality strips
- Overview / Recall / Operations Center as weak projection surfaces

Add more clearly:
- **quorum witnesses** near review strips,
  adoption gates,
  promotion rails,
  and rule-bound stronger actions
- **signoff cards** near reality strips,
  Overview tiles,
  Recall return points,
  and Operations Center rows

## What Helm should refuse

Do not:
- build a giant approvals dashboard
- flatten required,
  optional,
  stale,
  vetoed,
  bypassed,
  and satisfied posture into one green badge
- let old signoffs silently follow a newer mutable basis
- let holder truth impersonate signoff truth
- let bypass or admin override impersonate genuine quorum satisfaction
- let an `approved` label imply merge,
  adoption,
  or live success by adjacency

## Practical effect on Helm surfaces

A good compact Helm surface should increasingly be able to say:
- `2/3 signoffs • code-owner rule missing • current basis`
- `security quorum met • app-owner rule stale after latest push`
- `approval optional • merge authority still local`
- `consensus blocks apply • Lee requested changes`
- `quorum satisfied on reviewed basis • merge queue will retest on latest target`
- `bypass available only under exception witness`

That is a better next move than another pillar,
another review dashboard,
or another mushy `approved` story.
