# Helm remainder witnesses + residue ledgers — 2026-03-23

## Why this pass happened

After **resolution witnesses**, Helm could explain how something ended.
But it still could not answer the next humane operator question cleanly enough:

**what exact smaller slice is still left, and what exact local residue did not travel?**

That gap shows up everywhere:
- partial imports
- partial applies
- rerun-failed flows
- resumable uploads/downloads
- repair after expired live handles
- portable surfaces that leave local bindings behind

## Product judgment

The next narrow trigger is now worth pulling:

- keep the seven pillars stable
- do not add a new pillar
- promote **remainder witnesses** as the shell-owned exact-leftovers object
- promote **residue ledgers** as the shell-owned left-behind / omitted-travel truth object

A remainder witness answers:
- what smaller slice is unfinished now
- what exact ids / ranges / indexes / slots remain
- what stronger continuation or live truth it is related to
- what smallest honest retry / resume action is available

A residue ledger answers:
- what stayed local
- what was intentionally omitted
- what the receiver must rebind or re-earn
- why portability does not mean sameness

## Why this is worth stealing

The current official pressure is unusually consistent:

- Microsoft Graph exposes `nextExpectedRanges`
- Google Cloud Storage exposes persisted `Range` progress
- Google Drive keeps resumable upload first-class
- tus formalizes offset truth as protocol truth
- S3 multipart upload preserves successful parts and lists them
- Step Functions redrive resumes from the unsuccessful step instead of replaying everything
- GitHub Actions reruns failed jobs
- Kubernetes Indexed Jobs keep per-index retry / failure posture

All of those systems feel more humane because they preserve the exact unfinished slice.

## Lessons Helm must learn from the past

- `partial` is too flattering if the exact leftover slice is still unknown.
- `retry` is too blunt if the system already knows the smaller honest remainder.
- expired live handles should not erase still-valid remainder truth.
- portability lies when local-only residue stays unnamed.
- the right shell magic is not replaying everything; it is preserving just enough exactness to continue honestly.

## What Helm should keep

Keep:
- current-live beacons
- continuation handles
- effect receipts
- repair ladders
- resolution witnesses
- reality strips
- Overview / Recall / Operations Center as compact projection surfaces

Add more clearly:
- **remainder witnesses** near receipts / handles / repair ladders
- **residue ledgers** near portable cores / landing manifests / receiver-fit cards

## What Helm should refuse

Do not:
- build a universal job scheduler
- build a giant transfer dashboard
- turn remainder truth into fake current-live truth
- silently recreate omitted residue on the receiver just to look magical
- replay whole cohorts by default when the shell already knows the exact smaller leftover slice

## Practical effect on Helm surfaces

A good compact Helm surface should increasingly be able to say:
- `upload incomplete • 2 ranges remain`
- `rerun failed subset • 3 indexes left`
- `apply partial • 2 targets unresolved`
- `portable command shared • local profile binding omitted`
- `entry kit traveled • trust posture must be re-earned on receiver`

That is a better next move than another pillar,
another reminder center,
or another memory object.
