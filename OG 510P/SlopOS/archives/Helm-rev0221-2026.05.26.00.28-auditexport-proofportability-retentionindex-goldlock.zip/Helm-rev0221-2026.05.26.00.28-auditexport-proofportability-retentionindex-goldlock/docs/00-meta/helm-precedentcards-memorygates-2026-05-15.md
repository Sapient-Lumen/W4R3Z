# Helm precedent cards and memory gates — 2026-05-15

Revision: rev0195  
Focus: guarded learning after settlement

## Main judgment

Pull the trigger on **precedent cards**. Do not pull the trigger on a memory engine.

rev0194 made local closure honest. The next product opportunity is to let Helm learn from closed local history, but the learning must be smaller than law. The lesson should be visible, scoped, inspectable, forgettable, and revalidatable.

## Why this is the next hard layer

A shell that never learns feels dumb. A shell that learns invisibly feels dangerous. Helm needs the middle path:

- settlement packets are source history;
- precedent cards are scoped hints or warnings;
- default candidates remain adoption-required;
- rules and policy stay deferred.

## What we kept from older Helm inspiration

The old **activity memory seed** idea was right in spirit: users need small remembered warnings, routes, checklists, and source pointers near the work. What was missing was a strong proof chain. rev0195 adds that chain: no seed without settlement, scope, non-authority, and escape.

## What we rejected

- one giant personalization plane;
- ambient memory harvested from recency;
- cross-scope inheritance by default;
- learned defaults that silently become global behavior;
- AI suggestions that hide their source basis;
- policy-by-accumulated-history.

## The super-awesome move

Helm can feel like it remembers the work without being creepy:

`Last time this shape appeared, it settled as refusal history because the basis drifted. I can prefill the refusal copy and route a fresh recheck. Inspect / dismiss / forget.`

That is a power move because it is useful, tiny, and honest.

## Next work

Prototype a compact precedent strip and then deliberately create a counterexample specimen. If a precedent cannot survive being wrong, stale, dismissed, and forgotten, it is not safe enough for Helm.
