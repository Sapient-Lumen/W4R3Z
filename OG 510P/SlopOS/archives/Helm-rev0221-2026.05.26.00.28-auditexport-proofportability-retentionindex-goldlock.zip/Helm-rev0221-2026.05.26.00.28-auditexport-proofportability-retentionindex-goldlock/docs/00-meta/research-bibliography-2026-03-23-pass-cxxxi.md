# Research bibliography — 2026-03-23 pass CXXXI

- Microsoft Graph uploadSession — https://learn.microsoft.com/en-us/graph/api/resources/uploadsession?view=graph-rest-1.0
- Microsoft Graph attachment createUploadSession — https://learn.microsoft.com/en-us/graph/api/attachment-createuploadsession?view=graph-rest-1.0
- Google Cloud Storage performing resumable uploads — https://docs.cloud.google.com/storage/docs/performing-resumable-uploads
- Google Cloud Storage resumable uploads overview — https://docs.cloud.google.com/storage/docs/resumable-uploads
- Google Drive upload file data / resumable uploads — https://developers.google.com/workspace/drive/api/guides/manage-uploads
- tus resumable upload protocol — https://tus.io/protocols/resumable-upload
- Amazon S3 multipart upload overview — https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpuoverview.html
- Amazon S3 ListParts — https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListParts.html
- AWS Step Functions RedriveExecution — https://docs.aws.amazon.com/step-functions/latest/apireference/API_RedriveExecution.html
- AWS Step Functions redrive executions guide — https://docs.aws.amazon.com/step-functions/latest/dg/redrive-executions.html
- GitHub Actions re-run workflows and jobs — https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs
- Kubernetes Jobs — https://kubernetes.io/docs/concepts/workloads/controllers/job/
- Kubernetes v1.33 backoff limit per index GA — https://kubernetes.io/blog/2025/05/13/kubernetes-v1-33-jobs-backoff-limit-per-index-goes-ga/
