# Helm: reach previews + affected-set witnesses — 2026-03-22

## Headline

Helm already has a better answer to **what exact cohort is in play** than it had a few passes ago.
What it still needed was a better answer to:

**what would this stronger move actually touch right now?**

That gap is small enough to solve without a new pillar.
The next move worth warming is:

- **reach previews**
- **affected-set witnesses**

## Why this move now

Authority windows answer power.
Reveal windows answer visibility.
Cohort windows answer exact admitted subset.
Minimization ladders answer how much broader the shell is asking to go.

But none of those by themselves answer the operator's final practical question before a stronger act:
- what exactly is in scope right now,
- what is merely rule-derived,
- what might widen later if the scope is dynamic,
- and what did the shell actually think would be touched?

That question now shows up everywhere:
- mute these watchpoints
- reveal this redacted slice
- rerun failed subset
- publish this packet
- apply this candidate lane
- accept these library-like downstream updates
- export this selected cohort

## Candidate law

A **reach preview** should stay weaker than the act.
It is not the act.
It is the shell-owned pre-act witness of expected reach.

An **affected-set witness** should stay weaker than live truth.
It is not “everything that matters forever.”
It is the compact exact or counted set that the shell predicted,
reviewed,
or later observed as touched by one bounded act.

## What to keep

- exact-item / exact-cohort defaults
- human-readable reach summaries
- drilldown to exact items where practical
- explicit dynamic-scope caveats
- per-instance review where concrete downstream targets exist
- neighbor surfaces for predicted reach versus observed aftermath

## What to reject

- giant blast-radius theater
- ambient “this may affect many things” vagueness
- silent widening from static selection to dynamic rule match
- one-number risk badges replacing inspectable reach
- assuming predicted reach and observed outcome are the same object

## Where Helm gets especially better

### Omnibox
Quick actions can stay fast without becoming reckless.
A quick action can show one compact reach chip before promotion into a warrant.

### Exchange
Export,
reveal,
attach,
and handoff moves can finally say not just who or what was selected,
but what the stronger move would actually include.

### Operations Center
Mute,
rerun,
repair,
reveal,
and apply flows get a bounded impact preview instead of depending on memory or giant tables.

### Recall
Reopen,
rerun,
reverse,
quote,
and handoff can all stay bound to exact predicted reach rather than drifting into whole-family repair.

## Pull-the-trigger judgment

Do not add a new pillar.
Do warm **reach previews** and **affected-set witnesses** now as a small cross-cutting family.
They strengthen action warrants,
reveal windows,
authority moves,
quiet windows,
Exchange,
Recall,
Omnibox,
and Operations Center all at once.
