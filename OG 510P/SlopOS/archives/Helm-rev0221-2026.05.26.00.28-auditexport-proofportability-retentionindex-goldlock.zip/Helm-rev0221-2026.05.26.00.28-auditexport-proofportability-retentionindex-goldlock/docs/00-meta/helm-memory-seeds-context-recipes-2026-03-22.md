# Helm memory seeds and context recipes — 2026-03-22

Purpose: name the next small support move that could make Helm feel much smarter without relaxing its truth discipline.

## Main judgment

Helm likely wants **activity memory seeds**.
It may later want tiny **context recipes** built from them.

That still does **not** mean “give Helm one giant memory system.”

The right direction is:
- explicit remembered things,
- explicit scope,
- explicit source witness,
- explicit share/adopt ladder,
- and explicit inferiority to live truth.

## What should count as a memory seed

A memory seed is a small shell-owned remembered thing such as:
- a fact worth not re-deriving every time
- a short instruction or warning
- a source excerpt or selected quote
- a preferred subview or object pointer
- a route or account reminder
- a recurring review checklist fragment
- a tiny question to ask on return

A seed is not:
- the live lane
- the current-live beacon
- the activity spine
- the resource shelf
- the entry kit
- or a silent AI-wide memory blob

## Why Helm should care

Saved structure alone is not enough.
A saved view,
checkpoint,
entry kit,
or workspace starter often still needs a few remembered truths nearby:
- what this activity is trying to do
- which scope/account/provider is correct
- what must be checked before action
- which view matters first
- what mistake to avoid

Without that,
users either recreate the same context every time,
or the system starts smuggling it through ambient history and opaque personalization.

Memory seeds are the middle path.

## What is worth stealing

### Keep

1. **Explicit remember-this capture**
   - remember this selection
   - remember this page
   - remember this object
   - remember this instruction for this activity

2. **Scope-aware placement**
   - personal
   - activity-local
   - shared activity
   - imported restricted
   - published starter

3. **Source witness**
   - where the seed came from
   - when it was captured
   - which view/object/page/receipt grounded it

4. **Inspect / archive / forget**
   - remembered context should be manageable as ordinary shell truth,
     not buried in one settings cave

5. **Visible influence**
   - if Omnibox,
     Recall,
     entry kits,
     planning,
     or agents are using memory seeds,
     the shell should say so

### Reject

1. ambient harvesting from open/recent/preview by default
2. hidden cross-scope inheritance
3. remembered instructions silently outranking live currentness
4. imported memory seeds quietly becoming local trusted memory
5. turning memory into a second invisible authority plane

## Super-awesome moves this unlocks

### 1. Remember this for this activity
A universal shell move on selections,
results,
views,
routes,
and pages.

### 2. Tiny remembered warnings on reentry
“Use staging org, not prod.”
“Open the metrics view first.”
“Last time the profile axis widened here.”

### 3. Memory strips near front doors and beacons
An entry kit or current-live beacon can show two or three remembered truths nearby without pretending they are live state.

### 4. Inspectable memory influence in Omnibox and Recall
A result can say:
- matched current-live beacon
- matched saved view
- lifted by activity memory seed

### 5. Shareable memory seeds with weaker imported posture
Shared starter kits can carry a few remembered instructions,
but the receiver should still adopt them explicitly.

### 6. Tiny context recipes
A recipe could combine:
- two memory seeds
- one prompt/instruction
- one saved view
- one route hint

That is enough to make an entry kit or planning surface feel much more alive.

## Pull-the-trigger judgment

Still do not add a pillar.

Still keep **saved view objects** and **checkpoint branches** as the main proof targets.

But **activity memory seeds** now look like a very good next support contract to define,
especially because they sharpen Omnibox,
Recall,
activity spines,
entry kits,
and AI/planning surfaces all at once.

Context recipes should stay warm for now,
but they now look plausibly worth proving after memory seeds exist.
