# SlopOS + companions evaluation — 2026-03-23 pass CXL

## Why this pass happened

The last Helm revision made the strongest adjacent cluster explicit:
**health tiles, use rails, publish previews, draft/live honesty, and maybe later version windows.**

This pass asked the next nearby question:
**what should make those surfaces semantically legible and serving-path honest once people depend on them?**

The companion cubes still say the same big thing:
- freeze laws before big centers,
- keep shell-owned truth stronger than explanation,
- and do not let design-phase convenience harden into fake authority.

## What SlopOS still teaches best

### 1) Family/index discipline will matter even more once Helm has semantic, serve, and validation furniture
SlopOS's `boundary-family-map`, `adjunct-family-map`, and singleton discipline are still one of the best long-game lessons in the ecology.
They matter even more now,
because semantic recipe cards,
serve strips,
validator rails,
health tiles,
and use rails could easily multiply into a folklore maze.

Helm should steal a lighter equivalent before those witness families start rhyming too hard.

### 2) Descriptor/history truth is still weaker than current live truth
SlopOS keeps repeating the same excellent boundary:
issued descriptors,
historical receipts,
and provider-local metadata are not portable current-state oracles.

That transfers directly here.
A semantic recipe,
a validator result,
or a serve-path row should never outrank:
- the exact live source truth,
- the exact observed basis,
- or the exact current shell object being acted on.

### 3) Design-phase humility says: warm one proving slice, not a giant semantic center
SlopOS is still design-phase,
and that remains a gift.
It keeps showing that the right move is often:
- pin the law,
- add one bounded seam,
- and resist inventing one giant center too early.

Helm should treat semantic recipe / serve-path / validation work the same way.
Warm the cluster,
prove one humane specimen,
and resist the urge to declare a universal semantic catalog.

## What Schell still teaches best

### 1) Checkpoint humility transfers directly to `as-of` footing and validator rails
Schell keeps insisting that proposal,
checkpoint,
exact execution,
and later residue are different truths.
That transfers directly here.
A validator result is not current runtime proof.
A snapshot footing is not live current truth.
A draft semantic recipe is not the current published recipe.

### 2) Separate lanes make semantic surfaces safer
Schell's recurring lesson about separate lanes still matters:
- draft lane,
- compare lane,
- publish/adopt lane,
- receipt/history lane.

If Helm grows semantic recipe cards and validator rails,
it should keep those lanes explicit instead of collapsing them into one smart recipe object.

## What ViewFS still teaches best

### 1) Query manifest, snapshot, materialized collection, and live bind are different things
ViewFS keeps pressing exactly the distinction Helm needs here.
A query manifest,
result snapshot,
live feed,
and adopted local object are different things.
That is the emotional texture Helm needs for serve-path strips.

### 2) Basis/apply/adoption still beats fake publication magic
ViewFS remains the best nearby teacher for basis / apply / adoption texture.
That means a deck or brief should be able to say:
- semantic recipe basis X,
- served via path Y,
- observed as of Z,
- candidate publish here,
- adopted live there,
without collapsing those into one comforting save object.

## What Foundry, Harbor, and Steward add

### Foundry
Foundry's layer/check pressure still says the same useful thing:
check posture belongs next to the exact layer being judged.
That now extends naturally to semantic recipe and validator posture.

### Harbor
Harbor keeps teaching that route discovery,
trust,
and aftermath are separate truths.
That matters for published decks and shared briefs:
consumer routes and dependency knowledge do not become authority.

### Steward
Steward keeps teaching that presence,
discovery,
and lease-like trust posture should stay explicit.
That is a useful reminder that “official” and “verified” marks can help discovery while still remaining weaker than real authority or current live footing.

## Lessons Helm must learn from the past

### Must learn #1: semantic recipe is not current truth
A recipe is valuable.
It is still not the same thing as the current live object,
current basis,
or current served answer.

### Must learn #2: cached, precomputed, snapshot, subscribed, and live-direct are different truths
If Helm flattens all serving paths into one timeless result surface,
it will age into dashboard folklore fast.

### Must learn #3: `as-of` footing must be visible
People routinely overread “current” surfaces.
Helm should get better at saying what exact footing produced a visible answer,
including when logical time and wall-clock time differ.

### Must learn #4: validation is preflight, not proof
A validator rail can prevent breakage and explain blast radius.
It should not impersonate runtime health,
policy approval,
or live source truth.

### Must learn #5: verified / official marks are helpful but weak
Trust markers can improve discovery.
They should stay weaker than exact basis,
exact freshness,
exact checks,
and exact serve-path truth.

## What Helm should steal now

- a SlopOS-style family/index discipline before semantic and validation families multiply too far
- Schell's checkpoint humility for draft semantic recipes,
  validator results,
  and snapshot/live posture
- ViewFS query-manifest / snapshot / live-bind distinctions for serve-path strips
- Foundry's exact check attachment rather than floating semantic confidence vibes
- Harbor and Steward's refusal to let visibility,
discovery,
or dependence marks impersonate authority

## Product judgment

Do **not** freeze a giant semantic center.
Do **not** freeze a giant validation center.
Do **not** let serve-path strips or trust badges become a second authority plane.

But do keep warming an adjacent cluster around:
- semantic recipe cards,
- serve-path strips,
- explicit `as-of` footing,
- validator rails,
- and maybe later verified / official discovery marks.

That looks like the next best way to make Helm's datacube feel super truthful and super useful
once reviewed slices,
smart decks,
and richer evidence briefs start becoming depended-on shell objects.
