# Research bibliography — 2026-03-22 — pass LXXVI

Primary outside teachers consulted in this pass:

- Datadog downtimes documentation — preview affected monitors and later matching inclusion
- Datadog events API — impacted resources field
- HashiCorp Terraform `plan` command reference — execution plan and preview-before-apply posture
- Figma library update review flow — side-by-side / overlay / per-instance review before apply
- Google OAuth consent screen guidance — human-visible scope summaries and narrowest-scope advice
- Chrome `activeTab` documentation — temporary current-tab reach as an alternative to broad persistent host reach
- Android Selected Photos Access — exact selected media sets and temporary partial-access posture
- Slack security / optional scopes guidance — admin-approved optional-scope supersets
- Microsoft Entra PIM overview — time-bound and approval-bound stronger activation posture
