# Helm: glance windows + promote lanes — 2026-03-23

## Headline

Helm should now warm one more delight-bearing support move:
**glance windows**.

A glance window is not:
- a tiny summary card
- a generic preview pane
- a full ordinary open
- or a durable saved view

It is a **temporary weak shell window** for looking,
triaging,
and then either closing or explicitly promoting.

## The sharpened lesson from the past

One of the easiest ways to make a shell feel fake is to force everything into a false binary:
preview or open,
closed or live,
saved or current.

The better lesson is:
**some exploration should stay temporary,
weak,
and easy to discard without losing your place.**

That is worth preserving as its own product seam.

## What a glance window should do

A good Helm glance window should:
- open quickly from Omnibox,
  Object Browser,
  Exchange ingress,
  terminal links,
  or outside-app arrivals
- keep the originating context legible
- show exact subject,
  source posture,
  and any restricted / foreign / derived / historical caveats nearby
- allow explicit promote steps such as split,
  focus,
  adopt,
  save to shelf,
  route into activity,
  or open stronger
- decay,
  auto-archive,
  or stay visibly temporary unless promoted

## Why this is better than reusing generic preview

A generic preview pane is often too weak or too buried.
A full open is often too strong or too sticky.

Glance windows solve a different product need:
- “look at this without losing my place”
- “triage this before it becomes part of my activity”
- “decide whether this deserves stronger context”

That makes them a stronger candidate than trying to stretch preview panes into a whole weak-browse grammar.

## The nifty ideas worth stealing

### 1. Weak default arrival for unsorted links
Links arriving from elsewhere should often land in a glance window first.
That makes foreign or unsorted arrivals useful without instantly polluting activity context.

### 2. Route rules that can override the weak default
For known cohorts,
Helm should allow exact route rules:
- this domain to this activity
- this object family to this space
- this sender or source to this shelf or lane
- otherwise keep the weak default

### 3. Auto-archive temporary exploration
A glance window should be allowed to fade into archive / Recall posture automatically,
with visible temporaryness from the start.
That is much more honest than pretending every opened thing became durable work.

### 4. Tiny scoped dock bands
If a glance becomes recurrently useful,
Helm should allow tiny dock-band promotion:
- personal/local by default
- activity-shared only by explicit move
- published only by stronger deliberate move

### 5. Compare before stronger adoption
For imported,
foreign,
or helper-produced things,
a glance window should be able to hand off into compare / review / promote lanes rather than one flattering adopt button.

## Pillar consequences

### Tiling Shell
- glance windows should be easy to park,
split,
and dismiss without feeling modal or second-class
- promoted glance windows should cross into stronger layout posture visibly

### Omnibox
- Omnibox should be able to target **open in glance** as a first-class outcome
- route rules and scoped dock promotions should stay typed and inspectable

### Object Browser
- Browser should keep preview,
glance,
open,
adopt,
and compare visibly different
- imported or historical objects should often prefer glance-first posture

### Recall
- temporary windows should decay into honest historical residue,
not fake current continuity
- reopen from Recall should admit whether it is reopening a glance residue or a stronger saved object

### Exchange
- outside arrivals,
shared links,
and foreign objects should often land glance-first
- stronger import / adopt / publish should remain separate promotions

### Terminal/Capshell
- terminal-origin links or exact command outputs should be able to open in glance windows without pretending the terminal owns the whole navigation model

## What to keep warm rather than freeze

Keep warm:
- rich route-rule languages
- giant workspace-capture constitutions
- universal notebook/runtime surfaces
- giant dock ecosystems

The first proof should stay small:
**one temporary weak window,
one promote ladder,
one decay story,
and one route override story.**

## Judgment

Helm can become noticeably more awesome if it treats temporary weak exploration as a first-class shell luxury.

That move respects the old inspirations,
fits the companion cubes,
and adds a kind of delight most shells still blur away.
