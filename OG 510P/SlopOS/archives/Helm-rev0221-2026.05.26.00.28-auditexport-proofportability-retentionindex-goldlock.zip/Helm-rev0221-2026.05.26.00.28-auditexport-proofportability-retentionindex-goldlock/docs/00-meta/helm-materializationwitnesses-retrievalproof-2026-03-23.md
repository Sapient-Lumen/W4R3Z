# Helm: materialization witnesses + retrieval proof — 2026-03-23

## Headline

Helm should probably add one compact Exchange object for this sentence:

**for this exact offered material,
through this exact chosen route,
the receiver actually acquired or materialized this exact representation,
in this exact temporary / in-place / staged / durable-local posture,
with this exact strongest-known retrieval proof —
without pretending the receiver's user-meaningful work is already finished.**

That object should be a **materialization witness**.

## Why now

Helm's Exchange chain is now much better than it used to be:
- transfer offers
- take cards
- route witnesses
- gesture-runway and helper-escort support for stronger seams
- and generic effect receipts

What it still lacks is the compact truth between:
- **this exact route was chosen**
- and **this exact durable effect later landed**

Without that missing middle,
Helm still risks four familiar lies:
- a chosen route pretending the payload was actually retrieved
- a temporary receiver-side copy pretending it is a durable local import
- an in-place readable handle pretending it is owned local state
- or one generic "shared / opened / imported" badge erasing whether the far side only staged,
  copied,
  opened in place,
  or finished the actual user task

## The move

A Helm materialization witness should be:
- shell-owned
- attached to one exact transfer offer and one exact route witness
- stronger than route choice
- weaker than downstream effect receipt
- explicit about what the receiver actually acquired
- explicit about whether that acquisition is temporary,
  in-place,
  exported,
  staged,
  or durable-local
- and easy to open into later effect receipts,
  cleanup / closure receipts,
  or reroute / re-materialize repairs

## Why this is different from nearby objects

- **transfer offer** = what exact source is offering before a route is chosen
- **take card** = what one candidate receiver could honestly take right now
- **route witness** = what exact receiver / route was actually chosen and what strongest-known handoff truth the shell has
- **materialization witness** = what the receiving side actually retrieved or wrote after the route crossed the seam
- **effect receipt** = what exact later durable user-meaningful aftermath landed

That distinction matters.
A chooser callback may prove route choice.
A quick route may prove remembered target reuse.
A portal retrieve call may prove file export and retrieval.
A file promise may prove that a promised file was finally written.
None of that automatically means the receiver's real semantic work is already done.

## Strongest ideas worth stealing

### 1. ReportDataRetrieved is the perfect rung name
Windows basically gifts Helm the conceptual seam.
`ReportStarted()`,
`ReportDataRetrieved()`,
and `ReportCompleted()` are not the same event.
Helm should steal that law,
not necessarily the API names.

### 2. Retrieval sessions should stay visible
XDG FileTransfer is the best proof that retrieval has its own lifetime:
- start transfer
- add files
- retrieve files
- maybe autostop
- maybe stop manually

Helm should let a witness say:
- not yet retrieved
- retrieved once and closed
- retrieved and still open
- closed without retrieval

### 3. Materialization class should stay typed
Apple's APIs make the key point obvious.
The far side may get:
- an item loaded in memory
- a temporary file copy
- an in-place readable file
- a promised file written to destination

Those are all good outcomes,
but they are not the same outcome.

### 4. Receiver-local confirm/edit is still a valid success mode
Android's receive guidance is a strong reminder that many good routes end in:
- payload retrieved
- compose / edit / confirm surface opened
- later user decision

That should stay a first-class truthful landing state.

### 5. Temporary delegated access is part of the witness
Per-URI permissions,
session-scoped document export,
and one-shot retrieval all show that the witness should preserve access lifetime,
not just "got it".

## What to keep from older inspirations

Keep:
- typed plumbing and route humility
- portal-shaped retrieval and export seams
- compare / review / promote before strong consequences
- exact receipts instead of one mushy completion badge
- file-promise luxury without pretending the file already existed

Peel away:
- hidden receiver-local assumptions
- one generic open/import/share success story
- automatic promotion from temporary copy to durable ownership
- any UI that erases in-place versus copied versus staged versus durable-local
- giant universal exchange machinery before one humane specimen works

## Why this could make Helm super awesome

### 1. Exchange would feel even more premium
Helm could tell the truth about exactly what crossed the seam,
not just where it was aimed.
That is rare.

### 2. Promised and deferred transfer would stop feeling spooky
Drag/drop,
paste,
attach,
and share could all stay delightful without pretending bytes or files already exist on the far side.

### 3. Operations Center and Recall get much stronger history
A route witness plus materialization witness plus effect receipt gives a beautiful ladder of what the shell actually knows.

### 4. Repair becomes much cleaner
When something stalls,
Helm can say whether the problem is:
- route not chosen,
- route chosen but payload not retrieved,
- payload retrieved but receiver-local confirm/edit still pending,
- or downstream effect failed later

## Pull-the-trigger judgment

Helm still should not freeze one universal exchange backend,
file-materialization ontology,
or receiver-state protocol.
But it probably **is** time to warm one compact sequel after route witnesses:

**materialization witnesses** — shell-owned post-handoff acquisition witnesses that preserve exact offer,
exact chosen route,
exact retrieved representation,
materialization class,
retrieval-proof source,
closure / expiry posture,
and what still remains weaker than durable downstream effect.
