# Helm: change classes, re-review gates, and carry-forward rails — 2026-03-23

After **delta briefs**,
**since cards**,
**salience lenses**,
and **quiet witnesses**,
Helm now has a tighter adjacent question:

**once the shell can say what changed since the exact footing trust bound to,
how should it decide what strength of review should reopen?**

The most promising next cluster is not another global badge.
It is:
- **change classes**
- **re-review gates**
- and maybe later **carry-forward rails** or **review packets**

## Why this matters

A strong `since` surface helps answer **what changed**.
That is already a big step.
But operators will immediately ask the next question:

- does this change only reopen inspect posture?
- does it demand one fresh approval on the latest push?
- does it demand full re-review?
- or is this a reset / reacquire class that no ordinary review should cover?

If Helm cannot answer that,
then old review glow will either float too far,
or every tiny change will trigger one coarse ceremony.
Both outcomes are bad.

## Candidate objects

### 1. Change class verdict
A compact classification attached to one delta brief or reviewed slice.
Good early classes might include:
- `display-or-metadata-only`
- `serve-path-only`
- `freshness-or-health-only`
- `row-or-value-delta`
- `semantic-recipe`
- `dependency-or-coverage`
- `new-scope-or-audience`
- `reset-or-reacquire-class`

The point is not universal taxonomy purity.
The point is to stop treating every change as the same kind of return work.

### 2. Re-review gate
A compact statement of what strength of fresh review now fits.
Good early gates might include:
- `no-rereview; inspect only`
- `inspect-before-publish`
- `latest-push recheck`
- `full rereview`
- `reconsent or reacquire`

A gate is not the review itself.
It is the shell-owned answer to **what strength of review should reopen now?**

### 3. Carry-forward rail (later)
A bounded statement of what still carries forward even while stronger review no longer binds.
For example:
- stable anchors still true
- old notes still inspectable
- old owner/watch posture still relevant
- some downstream checks still unchanged

But the carry-forward rail must stay visibly weaker than fresh review on the newest footing.

### 4. Review packet / recheck packet (later)
A later object that could gather:
- exact compared footing
- change class verdict
- scoped downstream validation
- blindspots
- and the exact next decision surface

This should remain later.
The first proof slice does not need a case-management center.

## What Helm should probably do now

### 1. Keep `what changed` separate from `what review now fits`
A delta brief is not the re-review gate.
A re-review gate is not the final review.

### 2. Let change kind influence the next gate
A serving-path-only change may reopen inspect posture.
A semantic-recipe or dependency change may reopen stronger review.
A reset-class change may reopen reacquire rather than ordinary review.

### 3. Keep compare depth visible
A gate should increasingly know whether the compare result was:
- row-level only,
- value-level,
- dependency-level,
- downstream-validation scoped,
- or partially blind.

### 4. Preserve weaker carry-forward truth without lying
Helm should be allowed to say that some stable anchors still hold,
without pretending that old approval or action-fit still fully binds.

## Guardrails

1. **Do not let old approval float free of exact footing.**
2. **Do not let every change trigger the same ceremony.**
3. **Do not let carry-forward rails impersonate fresh review.**
4. **Do not let reset-class drift hide inside ordinary re-review.**
5. **Do not let partial compare depth bluff exhaustive review input.**
6. **Do not freeze a giant taxonomy before one humane proving slice exists.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

- since `last-reviewed`, only serving path changed → **inspect-before-publish**
- since `last-reviewed`, semantic recipe and one dependency changed → **latest-push recheck**
- since `published`, scope widened and one downstream use stayed unvalidated → **full rereview**
- since `last-confirmed`, footing moved into reset-class / reacquire territory → **reacquire, not ordinary review**

That would make Helm much more truthful than a single stale badge,
without turning it into an approval bureaucracy.
