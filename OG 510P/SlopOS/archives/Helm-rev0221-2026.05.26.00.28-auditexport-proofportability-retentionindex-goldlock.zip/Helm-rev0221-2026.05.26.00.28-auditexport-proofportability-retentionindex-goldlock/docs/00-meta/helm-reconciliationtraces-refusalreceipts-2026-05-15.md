# Helm reconciliation traces + refusal receipts — 2026-05-15

## Current judgment

Pull the trigger on **reconciliation traces**.

Do not pull the trigger on a merge engine, workflow runtime, CRDT/object-sync ontology, datacube backend, table format, semantic layer, or new pillar.

rev0190 made Helm's evidence economics checkable. The next problem is not more evidence. It is **what Helm does when multiple correct pieces of evidence disagree**.

## The move

Add one small product-proof object:

**reconciliation trace** = a compact record that says which events/evidence disagree, which question is being answered, what wins only for that question, what losing truth remains visible, what recipe applies, which verbs stay forbidden, and what refusal/history copy the user sees.

The release-readiness fixture now includes five traces:

1. live head vs stale derived summary;
2. saved definition @13 vs review cut @12;
3. restricted import vs local promotion receipt;
4. promotion receipt vs Recall currentness question;
5. patrol route setup vs frozen review cut.

## Lessons we must learn from the past

### 1. Divergence is not a command

Old systems routinely say something is diverged, stale, or out of date, then hide whether the next move will merge, replay, overwrite, recheck, restore, quarantine, or refuse. Helm must never let a posture imply an unstated recipe.

### 2. Refusal is a product object

A stale review refusal is not a mere disabled button. It is evidence: the operator asked for consequence, the basis drifted, the shell refused, and a repair path exists. That refusal should be durable enough to inspect later without becoming an approval.

### 3. Current, reviewed, imported, and historical are different winners

A live head can win current status. A review cut can win “what was reviewed.” An import can win “what arrived.” A receipt can win “what happened.” No one lane wins all questions.

### 4. Remembered resolutions are suggestions

Resolution memory is useful, but it is dangerous if it silently becomes authority. A remembered conflict pick must re-bind to the current compare cut before it does anything consequential.

### 5. Losing truth must survive repair

A recheck should not erase the stale sidecar. A refusal should not erase the old review. A local promotion should not launder a restricted import. Recall should not upgrade history into live truth.

## Brilliant ideas worth stealing

- **Merge queue removal reasons**: when a staged move falls out of a queue, name why.
- **Write-audit-publish branches**: isolate candidate work, audit it, then publish only after checks.
- **Data freshness badges**: show stale/current as first-class state, not hidden logs.
- **Validation results**: keep pass/fail evidence inspectable over time.
- **Lineage facets/context crumbs**: attach small metadata packets, not one global ontology.
- **Workflow event histories**: replay decisions from a log, but avoid importing a workflow runtime.
- **Supply-chain attestations**: bind inputs/materials/subjects, but do not mistake attestation for authority.
- **SlopOS boundary maps**: require coverage and fail-closed semantics, but shrink them to Helm-scale traces.

## What to peel away

- giant merge dashboards;
- automatic conflict resolution;
- confidence scores for “probably safe”;
- branch-head folklore;
- generic error strings;
- hidden queue removals;
- workflow runtime terminology in the shell UI;
- OS-scale boundary-family machinery on every product row.

## Why this makes Helm super awesome

The signature product moment is not a bigger dashboard. It is a row that calmly says:

> Promotion refused: review basis drifted from release-view@12 to release-view@13. Recheck to continue.

Or:

> Live head wins current status. Stale summary kept for comparison. Recheck before consequence.

That is a premium shell behavior: fast when proof is cheap, careful when consequence is expensive, and honest when truths disagree.

## Pull-the-trigger decision

Accepted now:

- `reconciliation_trace` schema;
- release-readiness reconciliation trace fixture;
- checker that ensures contradiction pairs are covered;
- refusal receipt candidates for blocked consequence;
- suggestion-only posture for resolution memory.

Deferred:

- merge engine;
- workflow engine;
- backend;
- query language;
- table format;
- semantic layer;
- global provenance store;
- new pillar;
- full SlopOS boundary-family import.
