# Helm / Schell treaty v0

Purpose: state how Helm should advance while Schell is still immature.

## Decision

Helm does **not** stop while Schell matures.

Instead Helm splits its motion:

1. **Keep advancing shell-owned desktop truth**
   - compositor ownership
   - shell graph
   - tiling shell
   - omnibox
   - object browser
   - operations center
   - desktop flow
   - control-tier boundaries

2. **Name shell-facing seams early, but keep them provisional**
   - session lineage
   - reviewed action / approval / receipt shape
   - ingress packets
   - selection packets
   - execution grounds
   - attach / resume honesty

3. **Do not let terminal convenience silently set Helm architecture**
   - Helm should not backfill ambient session folklore just because terminal UX pressure is real

4. **Treat terminal/capshell as a native front-end family, not as an eighth pillar by default**
   - promote it later only if it earns a genuinely separate truth domain rather than richer local shell UX over shared truth

## Why

Schell is already forcing the right questions:
- history is too thin; lineage matters
- reviewed actions need explicit basis and receipt truth
- ingress from paste/drop/clipboard is not just text
- restoration and attach/resume are useful but can lie about live truth
- execution grounds must be explicit rather than prompt folklore

Those pressures are real, but they mostly sharpen Helm's shell treaty rather than blocking compositor, object, flow, or operator work.

## Working rule

Helm may harden any shell-facing contract that remains compatible with these Schell pressures:
- **lineage-first** rather than history-only
- **reviewed action** rather than naked side-effect launch
- **receipt-bearing** rather than prompt-return folklore
- **explicit ingress** rather than ambient pasted authority
- **execution-ground witness** rather than cwd/env/session magic
- **restoration honesty** rather than flattering continuity theater
- **source grading** rather than one undifferentiated history rail for operator, delegated, imported, and warm local state

## Freeze boundary

Until Schell is more mature, Helm should avoid freezing:
- final terminal language details
- final shell syntax
- final pane/session restoration semantics
- final remote attach/forward posture

## Wiring

- related docs: `../30-architecture/terminal-posture-v0.md`, `../30-architecture/capshell-posture-v0.md`, `../30-architecture/shell-session-lineage-posture-v0.md`, `../30-architecture/reviewed-action-receipt-posture-v0.md`, `../30-architecture/execution-ground-posture-v0.md`, `../30-architecture/ingress-packets-posture-v0.md`
