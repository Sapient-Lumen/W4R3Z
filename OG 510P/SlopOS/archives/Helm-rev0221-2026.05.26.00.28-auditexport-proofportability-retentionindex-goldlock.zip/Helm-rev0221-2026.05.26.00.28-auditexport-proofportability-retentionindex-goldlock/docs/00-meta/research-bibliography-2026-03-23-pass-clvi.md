# Research bibliography — 2026-03-23 pass CLVI

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-OBSIDIAN-BASES-VIEWS-2026N | https://obsidian.md/help/bases/views | Obsidian contributes one-base-many-views discipline for saved view families. |
| REF-LOOKER-EXPLORES-2026N | https://docs.cloud.google.com/looker/docs/viewing-and-interacting-with-explores | Looker contributes personal exploration that does not affect other users. |
| REF-HONEYCOMB-BOARDS-2026N | https://docs.honeycomb.io/investigate/observe/boards | Honeycomb contributes investigation workspaces with queries, SLOs, text panels, and live refresh. |
| REF-HONEYCOMB-BOARD-TEMPLATES-2026N | https://docs.honeycomb.io/investigate/observe/boards | Honeycomb contributes template-start acceleration with explicit field-mapping repair when the template does not fit the data. |
| REF-DATADOG-NOTEBOOKS-2026N | https://docs.datadoghq.com/notebooks/ | Datadog contributes collaborative narrative-plus-live-data investigation surfaces. |
| REF-GRAFANA-INVESTIGATIONS-2026N | https://grafana.com/docs/plugins/grafana-investigations-app/latest/ | Grafana contributes bounded lists of interesting signals to reduce tab sprawl during investigations. |
| REF-WEZTERM-WORKSPACES-2026N | https://wezterm.org/recipes/workspaces.html | WezTerm contributes explicit named workspaces with visible active-workspace switching. |
| REF-RAYCAST-CLOUD-SYNC-2026N | https://manual.raycast.com/cloud-sync | Raycast contributes explicit personal sync posture for quicklinks, snippets, and extensions. |
| REF-RAYCAST-TEAMS-2026N | https://manual.raycast.com/getting-started-with-teams | Raycast contributes explicit team-sharing posture distinct from personal sync. |
| REF-GITHUB-RULESETS-EVALUATE-2026N | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets | GitHub continues to contribute evaluate-without-enforce posture. |
| REF-GITHUB-RULE-INSIGHTS-2026N | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository | GitHub continues to contribute inspectable pass/fail/bypass aftermath for rule evaluation. |
| REF-GITHUB-MERGE-QUEUE-2026N | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | GitHub continues to contribute settlement as an explicit queued rung. |
| REF-LAUNCHDARKLY-PREVIEW-RULES-2026N | https://launchdarkly.com/docs/home/flags/preview-rules | LaunchDarkly continues to contribute exact-context plus percent-split preview for targeting changes. |
| REF-LAUNCHDARKLY-GUARDED-ROLLOUTS-2026N | https://launchdarkly.com/docs/home/releases/guarded-rollouts | LaunchDarkly continues to contribute guarded promotion with pause/rollback on regression. |
| REF-TERRAFORM-PLAN-2026N | https://developer.hashicorp.com/terraform/cli/commands/plan | Terraform continues to contribute speculative-plan posture that is weaker than apply. |
| REF-HCP-TERRAFORM-SPEC-2026N | https://developer.hashicorp.com/terraform/cloud-docs/workspaces/run/modes-and-options | HCP Terraform continues to contribute plan-only runs that cannot apply. |
| REF-K8S-SSA-2026N | https://kubernetes.io/docs/reference/using-api/server-side-apply/ | Kubernetes continues to contribute inspectable field ownership. |
| REF-KUBECTL-VIEW-LAST-APPLIED-2026N | https://kubernetes.io/docs/reference/kubectl/generated/kubectl_apply/kubectl_apply_view-last-applied/ | kubectl continues to contribute direct basis inspection. |
| REF-ARGOCD-DIFF-STRATEGIES-2026N | https://argo-cd.readthedocs.io/en/stable/user-guide/diff-strategies/ | Argo CD continues to contribute explicit desired-vs-live diff surfaces. |
| REF-ARGOCD-MANIFEST-CACHE-2026N | https://argo-cd.readthedocs.io/en/stable/operator-manual/high_availability/ | Argo CD continues to contribute visible cache-key and invalidation law. |
| REF-OPA-DECISION-LOGS-2026N | https://openpolicyagent.org/docs/management-decision-logs | OPA continues to contribute durable decision-basis logging. |
