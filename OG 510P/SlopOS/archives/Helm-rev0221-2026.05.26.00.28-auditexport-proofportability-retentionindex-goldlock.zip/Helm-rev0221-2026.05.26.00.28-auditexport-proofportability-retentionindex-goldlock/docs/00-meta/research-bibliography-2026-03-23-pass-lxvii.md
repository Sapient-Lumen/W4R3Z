# Research bibliography — 2026-03-23 — pass LXVII

## Sources consulted for this pass

1. Atlassian Support — Create and manage playbooks
   - playbook steps can be instructional or automation-rule steps
   - each step run generates output
   - execution output can include log messages and key-value pairs
2. Atlassian Support — Run a playbook and view outputs
   - operators can view outputs at the playbook level for runs that have been executed
3. PagerDuty Support — Automation Actions
   - action runs create parent records with expandable node/step data
   - results are available in the Automation Actions Log and output reports
4. AWS Systems Manager User Guide — Systems Manager Automation
   - runbooks include one or more steps
   - each step has inputs, behavior, and outputs
5. AWS CLI Reference — describe-automation-step-executions
   - active and terminated step executions are inspectable
   - filters include step execution status, step name, and action
6. AWS Systems Manager API Reference — AutomationExecution
   - execution objects expose progress counters aggregating step execution statuses
7. GitHub Docs — Re-running workflows and jobs
   - operators can re-run all jobs, failed jobs only, or one specific job
8. GitHub Docs — REST API endpoints for workflow runs
   - workflow runs expose explicit `status` or `conclusion`
9. GitHub Docs — Workflow commands
   - per-step summaries roll into job summaries shown on the workflow run summary page
