# Research bibliography — 2026-03-23 pass CXLIV

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-DBT-MODEL-ACCESS-2026D | https://docs.getdbt.com/docs/mesh/govern/model-access | governance features add trust and stability but can make rollbacks harder and increase maintenance if adopted too early |
| REF-OPENMETADATA-CLASSIFICATION-2026D | https://docs.open-metadata.org/v1.12.x/how-to-guides/data-governance/classification/classification | `Verified` versus `Unverified` readiness is a useful precedent for weak consumption-readiness marks that stay weaker than semantics |
| REF-METABASE-CONTENT-VERIFICATION-2026D | https://www.metabase.com/docs/latest/exploration-and-organization/content-verification | verified items are a useful precedent for weak trust/discovery marks rather than total action authority |
| REF-METABASE-OFFICIAL-COLLECTIONS-2026D | https://www.metabase.com/docs/latest/exploration-and-organization/collections | official collections and Library are strong precedents for curated entry points separated from ad hoc analysis |
| REF-LOOKER-SELF-SERVICE-EXPLORE-2026D | https://docs.cloud.google.com/looker/docs/exploring-self-service | uncertified/ungoverned versus certified Explore posture is a useful precedent for explicit trust stages with notes |
| REF-LOOKER-EXPLORE-CACHE-2026D | https://docs.cloud.google.com/looker/docs/viewing-and-interacting-with-explores | explicit clear-cache-and-refresh is a strong precedent for overrideable serving-path honesty |
| REF-LOOKER-ALERT-HISTORY-2026D | https://docs.cloud.google.com/looker/docs/admin-panel-alerts-and-schedules-alert-history | running/complete/failed status, owner, and stale-data warnings are strong precedents for compact history posture |
| REF-CUBE-QUERY-HISTORY-2026D | https://cube.dev/docs/product/administration/workspace/query-history | SQL, pre-aggregation, security-context, and queue confession are strong precedents for serve-path honesty |
| REF-GX-CHECKPOINT-ACTIONS-2026D | https://docs.greatexpectations.io/docs/core/trigger_actions_based_on_results/create_a_checkpoint_with_actions/ | validation-then-action sequencing is a strong precedent for keeping checks separate from later action |
| REF-DATAHUB-ASSERTIONS-2026D | https://docs.datahub.com/docs/managed-datahub/observe/assertions | assertions as building blocks of data contracts are a good precedent for contract verification staying explicit |
| REF-DATAHUB-INCIDENTS-2026D | https://docs.datahub.com/docs/incidents/incidents | unhealthy-state incidents with independent lifecycle are a good precedent for stronger response posture staying separate |
| REF-DATAHUB-SUBSCRIPTIONS-2026D | https://docs.datahub.com/docs/managed-datahub/subscription-and-notification | subscriptions stay weaker than ownership and are a good precedent for notification posture |
| REF-GITHUB-DEPLOYMENT-PROTECTION-2026D | https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments | manual approvals and custom protection rules are strong precedents for bounded stronger-act gates |
| REF-LAUNCHDARKLY-APPROVALS-2026D | https://launchdarkly.com/docs/home/releases/approvals | explicit approvals are a strong precedent for stronger-rollout review without ambient magic |
| REF-MDN-USER-ACTIVATION-2026D | https://developer.mozilla.org/en-US/docs/Web/Security/Defenses/User_activation | fresh local user activation is a strong precedent for gating sensitive actions on recent trusted interaction |
