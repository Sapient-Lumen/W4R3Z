# Helm pull-the-trigger-soon map — 2026-03-22

Purpose: separate what now looks wise to prove soon from what should remain warm or merely inspirational.

## Tier A — prove soon

These still look like the clearest primary proof targets:

1. **saved view objects**
2. **checkpoint branches**

Why these two:
- they sharpen several pillars at once
- they are strongly validated by current products
- they fit SlopOS's bounded projection / explicit materialization law
- they can be proved in narrow specimens
- they do not require a giant dashboard,
  sync,
  or workspace constitution

## Tier B — define as support stack soon

These now look worth treating as one reusable shell grammar:

1. **imported-surface trust posture**
2. **activity entry kits / front doors**
3. **preview-promotion ladders**
4. **landing rehearsals / arrival overlays**
5. **materialization bays**
6. **publication ladders + promotion receipts**

Why this stack matters:
- it prevents weak or imported surfaces from bluffing that they already did the stronger act
- it gives saved views,
  shared views,
  imported front doors,
  and receiver-local adoption a humane landing path
- it helps Omnibox,
  Object Browser,
  Recall,
  Exchange,
  Desktop Flow,
  and Operations Center at once

## Tier C — keep warm but do not overfreeze

1. **view decks**
2. **deck recipes**
3. **role-shaped interface pages**
4. **personal/shared/published accelerators**
5. **one dedicated triage lane per activity/front door**

These look promising,
but they should remain derivative of stronger saved views,
trust posture,
front-door law,
and explicit publication/adoption.

## Tier D — actively resist

1. giant dashboard religion
2. universal workspace mythology
3. ambient sync mythology
4. history theater that overpromises exact return
5. any move that lets preview,
   arrival,
   publication,
   or saved setup impersonate live local truth

## Current product judgment

If Helm wants to become super awesome without losing discipline,
its next major gain still comes from getting the **middle state** right:
explicit views,
restricted arrivals,
truthful front doors,
and named stronger adoption moves.
