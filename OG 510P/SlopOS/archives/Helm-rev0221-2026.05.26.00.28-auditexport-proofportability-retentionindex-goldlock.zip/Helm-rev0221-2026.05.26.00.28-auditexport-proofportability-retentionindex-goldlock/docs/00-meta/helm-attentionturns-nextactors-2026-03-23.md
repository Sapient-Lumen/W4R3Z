# Helm: attention-turn chips, next-actor rails, and who-acts-now truth — 2026-03-23

After **carry-forward rails** and **review packets**,
Helm now has a tighter adjacent question:

**once the shell knows what weakly carries and what packet should open next,
how should it say whose turn it actually is now,
without confusing that with ownership,
watching,
acknowledgement,
or broad reviewer eligibility?**

The most promising next cluster is:
- **attention-turn chips**
- **next-actor rails**
- and maybe later **reviewer-load hints** or **reminder nudges**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. everyone vaguely connected to a slice looks like they are equally on the hook, or
2. the shell keeps rich carry-forward and review-packet truth,
but still cannot answer the humane tiny question:
   **who is actually expected to look next?**

Operators need a third answer:
- broad owner remains visible,
- subscribers remain visible,
- coverage remains visible,
- old review residue remains inspectable,
- **but one small current-turn object says who is actually expected to act now and why.**

## Candidate objects

### 1. Attention-turn chip
A tiny current-turn rendering.

Good early fields:
- exact subject label
- current footing or packet ref
- turn class chip:
  - `awaiting-author`
  - `awaiting-reviewer`
  - `awaiting-domain-review`
  - `awaiting-reacquire`
  - `awaiting-merge-holder`
  - `no-active-turn`
- optional stage chip:
  - `initial-look`
  - `latest-push-recheck`
  - `risk-review`
  - `downstream-use-check`
- optional expiry / nudge-after chip
- one strongest nearby exit

### 2. Next-actor rail
A slightly richer nearby object that can say:
- who is eligible
- who is currently requested
- whether the current ask is broad or narrowed
- why this role was chosen
- whether a prior ask was reopened or resent
- whether the shell believes nobody currently has the baton

### 3. Reviewer-load hint (later)
A later bounded hint that can say:
- `specific-person requested`
- `one-of-team requested`
- `team audience, individual actor narrowed`
- `busy actor skipped`
- `round-robin suggestion`
- `load-balanced suggestion`

This should stay hint-sized until Helm proves it needs stronger routing machinery.

## What Helm should probably do now

### 1. Keep turn truth separate from owner truth
The owner may stay stable for months.
The current turn may move many times in one day.
They should not render as the same thing.

### 2. Keep turn truth separate from watcher / subscriber truth
Watching is advisory.
Current turn is a stronger claim.

### 3. Keep turn truth separate from ack truth
An acknowledged burden may still be waiting on someone else.

### 4. Keep turn truth separate from merge / adoption truth
`approved` is not `merged`.
`ready for review` is not `review complete`.
`requested` is not `accepted`.

### 5. Let the shell say “no active turn” honestly
Not every slice should always look assigned.
Sometimes the right answer is that no one is currently expected to act.

### 6. Keep reminders and re-requests explicit
If Helm wants a fresh look,
it should be able to say that the turn was reopened,
re-requested,
or nudged.
That should not be smuggled in through a generic stale glow.

## Guardrails

1. **Do not let attention-turn chips impersonate ownership.**
2. **Do not let subscribers or bots quietly count as current actors.**
3. **Do not let next-actor rails become a giant workflow center.**
4. **Do not let load hints silently become hidden law.**
5. **Do not let `approved` quietly imply `merged` or `adopted`.**
6. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

- broad owner: `Revenue Ops`
- watchers: `weekly brief`, `billing health deck`
- carry-forward: old notes + unchanged downstream check still informative
- current turn: `awaiting recipe-owner recheck`
- stage: `latest-push recheck`
- ask shape: `specific Maya requested; broader team not pinged`
- nudge-after: `tomorrow 10:00`
- merge/adoption state: `approved earlier footing only; not yet republished`

That would make Helm much better than ambient watcher spam,
sticky stale approval,
or a giant review board.
