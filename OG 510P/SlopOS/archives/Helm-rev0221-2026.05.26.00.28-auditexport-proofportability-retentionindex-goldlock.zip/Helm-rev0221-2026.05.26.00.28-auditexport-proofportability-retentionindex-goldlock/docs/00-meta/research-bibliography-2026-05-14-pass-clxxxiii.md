# Research bibliography — 2026-05-14 — pass CLXXXIII

Load-bearing sources used for the rev0190 evidence-budget pass:

- Dagster docs — Asset freshness policies — https://docs.dagster.io/guides/observe/asset-freshness-policies
- Dagster docs — Asset checks — https://docs.dagster.io/api/dagster/asset-checks
- dbt Developer Hub — dbt Semantic Layer — https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl
- dbt Developer Hub — Exports for saved queries — https://docs.getdbt.com/docs/use-dbt-semantic-layer/exports
- Bazel docs — Remote caching — https://bazel.build/remote/caching
- Bazel docs — Debugging remote cache hits — https://bazel.build/remote/cache-remote
- Nix Reference Manual — content-addressed store — https://nix.dev/manual/nix/2.26/store/store-object/content-address
- Nix Reference Manual — garbage collector roots — https://nix.dev/manual/nix/2.25/package-management/garbage-collector-roots
- SLSA — Provenance v1 — https://slsa.dev/provenance/v1
- in-toto Attestation Framework — https://github.com/in-toto/attestation
- GitHub Docs — Artifact attestations — https://docs.github.com/en/actions/concepts/security/artifact-attestations
- Apache Iceberg docs — Branching and tagging — https://iceberg.apache.org/docs/latest/branching/
- lakeFS docs — Versioning internals — https://docs.lakefs.io/latest/understand/how/versioning-internals/
- OpenLineage docs — Facets and extensibility — https://openlineage.io/docs/spec/facets/
- OpenTelemetry docs — Baggage — https://opentelemetry.io/docs/concepts/signals/baggage/
- GitHub Docs — Managing a merge queue — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
- Linear Docs — Triage — https://linear.app/docs/triage
- DataHub docs — Assertions — https://docs.datahub.com/docs/managed-datahub/observe/assertions
- DataHub docs — Freshness Assertions — https://docs.datahub.com/docs/managed-datahub/observe/freshness-assertions
- Great Expectations docs — Checkpoint — https://docs.greatexpectations.io/docs/reference/api/checkpoint_class/

