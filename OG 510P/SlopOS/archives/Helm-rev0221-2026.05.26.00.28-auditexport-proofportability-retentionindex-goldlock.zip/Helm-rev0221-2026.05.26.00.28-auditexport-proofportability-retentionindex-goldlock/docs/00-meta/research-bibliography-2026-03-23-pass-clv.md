# Research bibliography — 2026-03-23 pass CLV

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GITHUB-RULESETS-EVALUATE-2026N | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets | GitHub contributes evaluate-without-enforce posture for stronger acts. |
| REF-GITHUB-RULE-INSIGHTS-2026N | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository | GitHub contributes inspectable pass/fail/bypass Rule Insights after evaluation. |
| REF-GITHUB-MERGE-QUEUE-2026N | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | GitHub contributes settlement as an explicit queued rung rather than a hidden final step. |
| REF-LAUNCHDARKLY-PREVIEW-RULES-2026N | https://launchdarkly.com/docs/home/flags/preview-rules | LaunchDarkly contributes exact-context and approximate cohort preview for targeting changes. |
| REF-LAUNCHDARKLY-GUARDED-ROLLOUTS-2026N | https://launchdarkly.com/docs/home/releases/guarded-rollouts | LaunchDarkly contributes monitored progressive exposure with pause-on-regression posture. |
| REF-TERRAFORM-PLAN-2026N | https://developer.hashicorp.com/terraform/cli/commands/plan | Terraform contributes speculative plans that describe effects without implied apply intent. |
| REF-HCP-TERRAFORM-SPEC-2026N | https://developer.hashicorp.com/terraform/cloud-docs/workspaces/run/modes-and-options | HCP Terraform contributes speculative plans that show possible changes and policy effects but cannot apply. |
| REF-K8S-SSA-2026N | https://kubernetes.io/docs/reference/using-api/server-side-apply/ | Kubernetes contributes explicit field management and managed-fields inspectability. |
| REF-KUBECTL-VIEW-LAST-APPLIED-2026N | https://kubernetes.io/docs/reference/kubectl/generated/kubectl_apply/kubectl_apply_view-last-applied/ | kubectl contributes a direct basis-inspection seam worth stealing for basis explorers. |
| REF-ARGOCD-DIFF-STRATEGIES-2026N | https://argo-cd.readthedocs.io/en/stable/user-guide/diff-strategies/ | Argo CD contributes close-to-live dry-run diff plus explicit diff-cache invalidation law. |
| REF-OPA-DECISION-LOGS-2026N | https://openpolicyagent.org/docs/management-decision-logs | OPA contributes durable decision-basis logging for later audit and debugging. |
