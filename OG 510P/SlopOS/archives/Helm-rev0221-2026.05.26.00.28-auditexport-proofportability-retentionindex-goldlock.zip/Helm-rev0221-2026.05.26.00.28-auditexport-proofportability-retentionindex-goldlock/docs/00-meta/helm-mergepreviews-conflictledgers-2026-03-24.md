# Helm — merge previews and conflict ledgers

## Current judgment

Do **not** add a new pillar.
Do **not** freeze a universal merge manager.
Do **not** let a reconcile recipe or remembered resolution hint impersonate a finished result.

The strongest next move is smaller:
**warm merge previews + conflict ledgers as the shell-owned seam after reconcile recipes and resolution memories.**

## What Helm can already say

Helm can already say:
- what footing crossed a seam,
- what became local here,
- what origin that local floor still tracks,
- whether it is in sync, ahead, behind, diverged, detached, or origin-lost,
- and what broad repair class is intended now.

What Helm still answers too weakly is:
- **what would that chosen repair produce right now?**
- **what still conflicts, and in what exact way?**
- **which reused conflict choices were applied as hints?**
- **what nearby restore point or reject path exists if the preview is unacceptable?**

## The lesson Helm must learn from the past

Past systems keep making the same repair mistake:
**they tell you the reconcile class, but they hide the provisional result and the unresolved remainder.**

That creates spooky shell behavior:
- a surface says `update with rebase`, but you never see the predicted result as an object of its own;
- a repeated conflict is auto-solved by remembered history, but the person is not shown that it was a hint rather than fresh truth;
- a preview once looked clean, then the basis moved, but the UI still acts like the old preview remains good enough.

Helm should refuse that whole family of mistakes.

## The next narrow seam

### Merge preview
A **merge preview** is a shell-owned preview artifact bound to:
- one divergence card,
- one exact compare basis,
- one reconcile recipe,
- and one preview run moment.

It can be:
- `clean-preview`,
- `hint-assisted-preview`,
- `unresolved-preview`,
- `structural-conflict-preview`,
- `stale-preview`,
- or `abandoned-preview`.

A preview can show a would-be result and still be weaker than adoption.
That is the point.

### Conflict ledger
A **conflict ledger** is the compact remainder surface beside the preview.
It records:
- exact conflict zones or classes,
- any remembered-resolution hints that were reused,
- whether force/override would be required,
- whether the preview basis has drifted,
- and the exact next verbs: review, restore, repeat, detach, or accept.

## Why this is better than more cube

This move makes the pillars richer without turning Helm into one giant repair center.
It gives each serious pillar one humane answer to:
- what recipe is being considered,
- what that recipe would yield,
- what still blocks it,
- and how to back out cleanly.

That is enough to make Helm feel calmer and smarter without freezing a universal theory of version control.

## The best things to steal

1. **Git merge-tree** style preview artifacts
2. **AUTO_MERGE** style conflict-bearing preview trees
3. **rerere but reviewable** remembered hints
4. **server-side dry-run + diff** posture from Kubernetes
5. **restore-before-update** posture from Figma when repair goes sideways

## What not to keep

Do not keep:
- silent auto-resolution,
- previews that become accepted by lingering on screen,
- or one generic `conflicted` badge that hides whether the trouble is textual, structural, basis-stale, or ownership/force related.

## Why this makes Helm super awesome

Because it creates a premium repair loop:
- choose a reconcile class,
- see one exact preview artifact,
- inspect one compact conflict ledger,
- decide whether to accept, revise, restore, or detach,
- and only then let settlement witnesses matter.

That is better than more center.
It is a better operator loop.
