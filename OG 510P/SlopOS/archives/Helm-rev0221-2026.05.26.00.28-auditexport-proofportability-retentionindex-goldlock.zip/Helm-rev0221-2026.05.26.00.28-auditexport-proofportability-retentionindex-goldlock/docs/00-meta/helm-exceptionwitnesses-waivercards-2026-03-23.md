# Helm exception witnesses + waiver cards — 2026-03-23

## Why this pass exists

After state tuples,
why rails,
delta briefs,
footing marks,
salience lenses,
coverage witnesses,
quiet witnesses,
delivery witnesses,
disposition witnesses,
revisit witnesses,
and commitment witnesses,
Helm can now say a lot about a surfaced thing.

But it still lacked one small answer to a very practical question:

**is this requirement actually satisfied,
or are we proceeding under an explicit exception,
bypass,
downtime,
pause,
or waiver?**

That answer should not be hidden in:
- a greenish badge
- an acknowledgement bit
- a muted notification
- a paused SLA
- an approved bypass request
- a downtime schedule
- a policy override comment
- or the source object's current-live row alone

It needs its own compact shell-owned truth object.

## Main judgment

Helm should now admit **exception witnesses**,
with tiny nearby **waiver cards**.

An exception witness is not:
- the source truth
- the delivery witness
- the quiet witness
- the disposition witness
- the revisit witness
- the commitment witness
- the final outcome
- or a giant policy/governance center

It is the exact answer to:
- what requirement,
  gate,
  promise,
  rule,
  or condition is not actually being satisfied?
- what explicit exception posture now allows continuation,
  silence,
  or temporary passage?
- who asked for it,
  who granted it,
  and why?
- what exact scope,
  lane,
  audience,
  or subject does it cover?
- when does it start,
  expire,
  require recheck,
  or get revoked?
- and what exact stronger redeem / revoke / re-review exit should open next?

## Why this matters for Helm's pillars

### Overview
Overview can now stay weak but still say:
- `push gate bypass approved • expires in 3d`
- `monitor muted for maintenance • states still moving`
- `approval waived for flag copy • flag-only scope`
- `SLA paused awaiting customer • not yet met`

without pretending any of those mean the requirement is actually satisfied.

### Recall
Recall can explain not just what changed,
what stance was chosen,
when it should return,
and what was promised,
but whether the remembered thing is living under an exception:
- `saved, wake tomorrow 10:00, review promised by noon, approval waiver active`
- `warning acknowledged, no local promise, downtime still active`
- `bypass expired since last visit`

### Operations Center
Ops rows can stop flattening:
- active exception
- approved-but-unused exception
- expired exception
- paused enforcement
- muted notification
- acknowledged risk
- and true recovery

into one vague “handled” or “green enough” bit.

### Omnibox / Object Browser
Helm can offer exact next-step verbs like:
- request-exception
- approve-exception
- deny-exception
- revoke-exception
- extend-with-reason
- redeem-now
- reopen-gate

without pretending the underlying subject changed yet.

## What Helm should steal

- GitHub delegated bypass with reviewer identity,
  reason capture,
  status filtering,
  and seven-day expiry
- LaunchDarkly required approval defaults with explicit bypass posture for some object classes but not others
- Datadog downtimes with exact scope previews,
  recurrence,
  audit notifications,
  and the law that state transitions continue underneath silence
- Jira's measured / paused / breached / completed SLA distinction
- PagerDuty's acknowledgement-versus-resolution distinction and timeout-driven return to triggered

## What Helm should refuse

- one universal “override” badge
- treating bypass as compliance
- treating mute or downtime as health
- silent permanent waivers
- exceptions with no scope,
  no reason,
  or no expiry/recheck posture
- treating exception witnesses as another enterprise policy empire

## Pull-the-trigger conclusion

The next good Helm move is not another pillar.
It is one more cross-pillar ratchet:

**commitment truth tells you what was promised.**
**exception truth tells you whether a requirement is actually being met or only being bypassed, paused, or waived.**

That is the missing seam between truthful obligation and truthful compliance.
