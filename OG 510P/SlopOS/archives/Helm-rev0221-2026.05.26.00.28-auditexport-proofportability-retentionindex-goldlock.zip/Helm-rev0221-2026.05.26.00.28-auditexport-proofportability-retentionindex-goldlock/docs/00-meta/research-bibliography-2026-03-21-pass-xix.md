# Research bibliography — 2026-03-21 pass XIX

Official/public sources consulted in this pass:

- Obsidian Help — Introduction to Bases  
  https://help.obsidian.md/bases
- Obsidian Help — Views  
  https://help.obsidian.md/bases/views
- Arc Help Center — Peek: Preview Sites From Pinned Tabs  
  https://resources.arc.net/hc/en-us/articles/19335302900887-Peek-Preview-Sites-From-Pinned-Tabs
- Arc Help Center — Split View: View Multiple Tabs at Once  
  https://resources.arc.net/hc/en-us/articles/19335393146775-Split-View-View-Multiple-Tabs-at-Once
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Docs — Session Management  
  https://docs.warp.dev/terminal/sessions
- Warp Docs — Session Navigation  
  https://docs.warp.dev/terminal/sessions/session-navigation
- Warp Docs — Command Palette  
  https://docs.warp.dev/terminal/command-palette
- Warp Docs — URI Scheme  
  https://docs.warp.dev/terminal/more-features/uri-scheme
- WezTerm Docs — Workspaces / Sessions  
  https://wezterm.org/recipes/workspaces.html
- WezTerm Docs — ShowLauncherArgs  
  https://wezterm.org/config/lua/keyassignment/ShowLauncherArgs.html
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Apple Support — Take actions and shortcuts in Spotlight on Mac  
  https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac
- Apple Support — Search for anything with Spotlight on Mac  
  https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Deeplinks  
  https://manual.raycast.com/deeplinks
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- VS Code Release Notes — December 2025 / Copy Breadcrumbs Path  
  https://code.visualstudio.com/updates/v1_108
- VS Code Docs — Using agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
