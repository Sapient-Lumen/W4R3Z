# Research bibliography — 2026-03-23 pass CXII

1. **MDN — HTTP conditional requests**
   - Why it mattered: the web's `If-Match` / `If-Unmodified-Since` / `If-Range` family is an almost perfect proof that partial continuation and mutable-basis match are different truths.
   - Helm pull: revalidation checkpoints and drift gates should fail closed on changed basis rather than silently following latest.

2. **Google Cloud Storage — Request preconditions**
   - Why it mattered: generation and metageneration preconditions make safe read-modify-write and conditional replace explicit and mechanical.
   - Helm pull: reviewed basis should be exact witness material, not ambient “current”.

3. **GitHub Docs — Pull request update branch / expected_head_sha**
   - Why it mattered: GitHub keeps reviewed head SHA explicit and rejects the action if the head changed.
   - Helm pull: strong next moves should carry expected-basis guards instead of silent head-following.

4. **Kubernetes — kubectl scale preconditions**
   - Why it mattered: even tiny strong operator actions can require `--resource-version` or `--current-replicas` as explicit preconditions.
   - Helm pull: the basis-check seam is valuable even for small acts, not only giant workflows.

5. **Microsoft Graph — driveItem createUploadSession / file update**
   - Why it mattered: resumable or deferred file flows still admit `if-match`, which proves handle existence and basis validity are separate truths.
   - Helm pull: continuation handles and revalidation checkpoints should remain distinct shell objects.
