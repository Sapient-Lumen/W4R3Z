# Helm: quarantine ribbons + endorsement receipts — 2026-03-23

## Headline

Helm should get **better at foreign-arrival honesty, not broader at trust theater**.
The next compact move worth warming is:

- **quarantine ribbons**
- **endorsement receipts**

## Why now

Helm now has:
- trusted chrome lanes for shell-owned stronger-act seams,
- host-effect witnesses for weaker-origin asks,
- access verdict cards for blocked-state honesty,
- least-widening previews for smaller next steps,
- freshness-horizon chips for live-looking decay,
- and intent sparks for fresh user-initiation honesty.

What it still lacks is one clean answer to:

- **where did this thing come from?**
- **is it still quarantined or only safe-openable?**
- **did I endorse the exact source object, or only a fresh derivative?**
- **is this reopen path running on live authority now, or only on a historical endorsement receipt?**

Without that,
Helm risks another familiar lie:
- recents that forget why an object was risky,
- previews that feel like they cleared the source object,
- copied artifacts that impersonate their origin,
- and “open succeeded once” folklore laundering itself into future trust.

## The good pattern

### Quarantine ribbons

A quarantine ribbon should carry:
- one exact source or arrival route class
- one exact risk posture (`quarantined`, `safe-open only`, `endorsement requested`, `endorsed exact object`, `derivative only`, or equivalent)
- one exact scope (`source object`, `bounded derivative`, `session only`, or equivalent)
- one nearby why / inspect path
- one nearby safe-open / endorse / export-derivative ladder

### Endorsement receipts

An endorsement receipt should carry:
- one exact object or derivative id
- one exact trusted shell lane that admitted the change
- one reason or basis witness when relevant
- one scope statement saying what was cleared and what was not
- one resulting reopen / exec / attach posture
- one historical link back to the earlier quarantine ribbon

## What to keep from older inspirations

Keep:
- Gatekeeper's split between downloaded-software provenance,
  first-open approval,
  and later launch posture
- Windows / Office posture where zone-of-origin and Mark-of-the-Web survive long enough to change later stronger behavior
- Chrome's habit of keeping dangerous,
  suspicious,
  unverified,
  and insecure visibly different
- VS Code's proof that Restricted Mode can feel normal and useful rather than shameful
- ViewFS and Schell seam cuts around safe-open,
  exact reveal,
  and derivative honesty

Peel away:
- giant trusted-location folklore
- giant provenance dashboards before one tiny ribbon works
- preview-success-equals-clear shortcuts
- any myth that moving a risky object somewhere friendly erases the arrival story

## Why this makes Helm more awesome

This move upgrades several existing Helm surfaces:

- **Object Browser** can keep inspect,
  reveal,
  safe-open,
  endorse,
  and export-derivative visibly different.
- **Recall** can preserve the arrival story instead of flattening risky recents into ordinary openables.
- **Exchange** can keep foreign ingress,
  guarded handoff,
  and exact derivative export more honest.
- **Operations Center** can explain exactly why something is blocked,
  restricted,
  safe-open only,
  or admitted on one narrow receipt.
- **Trusted chrome** can keep endorsement as a shell-owned historical act rather than an app-local shrug.

## Pull-the-trigger judgment

This is worth warming now.
Not as a new pillar,
and not as a giant trust console,
but as one more compact shell law:

**foreign or risky arrivals should keep origin evidence,
quarantine state,
safe-open posture,
explicit endorsement,
derivative-versus-source distinction,
and live authority on separate visible seams.**
