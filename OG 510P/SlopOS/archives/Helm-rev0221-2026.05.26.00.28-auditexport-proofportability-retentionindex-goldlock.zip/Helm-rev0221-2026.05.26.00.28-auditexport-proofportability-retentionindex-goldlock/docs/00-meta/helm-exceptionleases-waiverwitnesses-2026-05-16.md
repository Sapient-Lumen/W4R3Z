# Helm rev0197 research pass — exception leases, waiver witnesses, expiry rails

Revision: rev0197  
Date: 2026-05-16

## Pull-the-trigger recommendation

Pull the trigger on `exception_lease` as the next proof-fixture object.

Do **not** choose a policy engine, approval engine, generic lease manager, feature flag system, alerting platform, workflow runtime, backend, semantic layer, table format, CRDT/sync ontology, or new pillar.

## Why this is the next seam

rev0196 gave Helm counterexamples. Counterexamples tell Helm when learned behavior is wrong or too broad. The next user need is temporary exception handling:

- “I know the warning exists, but silence it for this session after compare proof.”
- “Please waive this review gate.”
- “Keep the quarantine branch open while I adopt locally.”
- “Provider is down; let Recall compare past receipts without calling it current.”
- “Hold this default route until queue coverage is repaired.”

Those are not approvals. They are temporary exceptions. Helm needs an object that makes them visible, scoped, expiring, and revocable.

## What changed in the fixture

Added:

- `schemas/exception-lease.schema.json`
- `fixtures/release-readiness/exception-leases.json`
- `tools/check_exception_leases.py`
- `docs/30-architecture/exception-leases-v0.md`
- `docs/30-architecture/release-readiness-exception-lease-drill-v0.md`
- `docs/20-assurance/helm-exception-lease-invariants-v0.md`
- `adrs/0032-exception-leases-before-policy-or-lease-engine.md`

The release-readiness specimen now has one exception lease for every counterexample case.

## The main product law

Exception leases must never repaint the interrupted rule as satisfied.

A lease can say:

- exception active;
- waiver denied;
- hold redeemed;
- expired and wake recheck;
- quarantine extended;
- warning collapsed for one session.

It cannot say:

- approved;
- ready;
- current;
- policy passed;
- safe forever;
- source truth upgraded.

## Old inspiration kept

The old exception witness / waiver lease idea was worth keeping, but only after the newer proof ladder existed. The old idea was too easy to turn into a governance panel. In rev0197 it is just a fixture object tied to counterexamples.

## SlopOS lesson kept

SlopOS’s lease family is valuable because it refuses to let a descriptor become live authority. Helm should copy that discipline directly: an exception lease descriptor proves issued bounds, owner, reason, and expiry; it does not prove the exception is still live, the underlying rule passed, or release readiness is current.

## Best steal

Borrow lease TTL, finalizer, stale-flag cleanup, alert suppression, bypass review, and decision-log crumbs. Do not borrow their control planes.
