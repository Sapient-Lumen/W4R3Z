# Helm: attention windows + quiet budgets — 2026-03-22

Purpose: name the next compact support move that now looks worth warming after the latest SlopOS reread and current-tool pass.

## Main idea

Helm now has:
- saved view objects,
- linked views,
- exact front-door handles,
- view subscriptions,
- glance derivations,
- watchpoints,
- patrol routes,
- evidence briefs,
- response kits,
- and timeline markers.

What is still missing is one shell-owned object for:
**bounded attention governance.**

The right answer now looks like:
- keep the **saved view** as the durable exact source,
- let the **watchpoint** say what state Helm thinks the source is in,
- let the **subscription** carry the bounded attention relation,
- let the **timeline marker** explain what changed around it,
- and add one explicit **attention window** for when delivery may interrupt, digest, stay quiet, or escalate into a narrower critical rung.

## 1. What an attention window is

An **attention window** is a shell-owned bounded attention-governance object.

It may govern:
- one exact view subscription,
- one watchpoint,
- one patrol route,
- one digest lane,
- or one bounded set of related shell-owned attention subjects.

It can carry:
- exact target refs
- time shape (fixed or recurring)
- policy mode (quiet / active-only / digest-only / maintenance / critical-only)
- channel / interruption rung
- optional rate or burst budget
- optional authored reason / note
- scope posture
- provenance/authorship posture
- exact inspect / end-now / disable / adopt actions

It is stronger than scattered provider settings because it keeps the target,
the time law,
the interruption posture,
and the reason together.
It is weaker than live truth because it does not prove the watched thing is healthy,
recovered,
or completed.

## 2. Why this now looks necessary

Helm already has a decent answer to:
- what the source is,
- what the watched state is,
- what changed nearby,
- and what to do next.

But it still lacked a good answer to:
- why the watch is quiet right now,
- whether this is a recurring quiet rule or a one-off silence,
- whether delivery is allowed only during business hours,
- whether a maintenance period suppresses delivery without declaring recovery,
- and whether a narrow critical-only rung exists without widening into giant urgent-law folklore.

That is a real product gap.
Attention windows fill it without forcing Helm into giant notification-center ambition,
giant scheduling law,
or fake “if it is quiet, it must be healthy” mythology.

## 3. What current tools taught this pass

The outside pattern is now specific enough to steal:
- Grafana validates the split among **mute timings**, **active time intervals**, and **silences**, and explicitly says these suppress notifications without stopping evaluation.
- Datadog validates scoped downtimes, group scope, and preview of affected monitors.
- PagerDuty validates explicit maintenance windows with current / future / past visibility and an explicit difference between maintenance and disabling a service indefinitely.
- Android validates channelized notifications where users control visibility and interruption level.
- XDG Desktop Portal validates a send/withdraw request seam where the app cannot even learn whether a notification was shown.
- Apple validates that stronger critical-alert interruption needs a narrower entitlement and can break through silence/Focus.

The thing to steal is not “become Grafana + Datadog + PagerDuty + mobile OS settings in one shell.”
It is:
**make quieting and interruptibility first-class, exact, scoped, inspectable, and clearly weaker than source truth and watchpoint state.**

## 4. What Helm should keep and reject

### Keep
- recurring quiet windows
- one-off silences
- active-only delivery periods
- digest-only quiet posture
- narrow critical-only interruption rungs
- preview of affected targets before a broad quiet rule lands
- explicit difference between quiet, maintenance, disabled, and healthy
- exact jump-back-to-source and inspect-watchpoint paths
- imported/shared attention windows that arrive in weaker posture first

### Reject
- giant always-on inbox mythology
- quiet == healthy
- urgent == foreground steal
- apps/providers choosing durable attention law invisibly
- notification presentation as proof that the user saw or approved something
- hidden scheduler/workflow engine creep under “quiet hours”

## 5. What now looks wise to pull the trigger on

### Pull the trigger now
- **attention windows** as candidate shell objects

### Advance with them
- view subscription → attention-window links
- watchpoint → visible quiet / muted / maintenance posture
- Overview / Operations → inspectable attention state chips
- timeline markers → maintenance/range context
- patrol routes → recurring “during patrol only” or digest-after-patrol posture

### Keep warm
- quiet-budget templates by team or activity
- machine suggestions for likely quiet windows based on repeated suppressions
- critical-rung review receipts and “why this broke through” witness

## 6. Why this could make Helm super awesome

This move gives Helm a better answer to:
**"why is this quiet, and what still remains true underneath the quiet?"**

A user could:
- see a watchpoint still evaluating in warning,
- also see that delivery is currently under a weekend quiet window,
- inspect the exact quiet rule,
- end it early or convert it to digest-only,
- attach a maintenance range marker,
- and later hand off the same bounded context without pretending the quiet window itself proved recovery.

That is better than:
- generic Do Not Disturb folklore,
- provider-specific hidden mute settings,
- or giant notification centers that confuse seeing with knowing.

## Judgment

Helm still does not need another pillar.
It needs one more compact shell object.

The best next move now looks like:
- **attention windows**
- plus **quiet-budget posture** around exact targets,
  recurring/fixed time shape,
  interruption rung,
  budget/rate,
  scope posture,
  provenance,
  and honest non-recovery humility

That gives Helm a much better attention grammar without sacrificing the anti-folklore discipline it has been learning from SlopOS all along.
