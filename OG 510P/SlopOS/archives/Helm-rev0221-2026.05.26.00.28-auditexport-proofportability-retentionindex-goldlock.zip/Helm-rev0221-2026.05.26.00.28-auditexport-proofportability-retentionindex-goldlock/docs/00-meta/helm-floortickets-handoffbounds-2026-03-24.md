# Helm — floor tickets and handoff bounds

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one universal cross-device continuity substrate.

The strongest next move is smaller:
**warm floor tickets + handoff bounds as the shell-owned seam after session floors and causality rails.**

Helm can already say:
- what exact footing counted,
- what died,
- how it renewed or overlapped,
- what guard a cutover depended on,
- whether the boundary crossed,
- who has observed the result,
- what class of read a person is looking at now,
- and whether a later view still honors the lower-bound floor a user or deck already holds.

What it still answers too weakly is:
- **when that floor travels through a deck, link, share, import, or device handoff, what exactly crossed the seam?**
- **can the receiver verify or strengthen that footing here, or is it only a lower-bound carried claim?**
- **how do we stop imported continuity from silently bluffing local authority?**

## The lesson Helm must learn from the past

Past systems keep repeating another continuity sin after flattening `done`, flattening `current`, and flattening `fresh enough`:
**they flatten carried footing into local truth.**

That creates haunted shell behavior:
- a reviewed deck is shared and opens elsewhere, but the receiver cannot tell whether it is standing on the sender's footing or only on a weaker local read;
- a share/import path carries enough evidence to compare or cite, but the shell flatters that into editable current authority;
- a cross-device reopen preserves a lower bound, but later surfaces silently overclaim it as if nothing about locality, audience, or receiver verification changed.

Helm should refuse the myth that a portable floor is the same thing as live local footing.

## What the outside world is teaching right now

### Azure Cosmos DB: portable session evidence is still a read-side minimum barrier
Cosmos DB documents that session tokens can be passed between client instances, says their contents should not be modified, and recommends using passed session tokens only for **read operations**. It also says the session token is a **minimum version barrier**, not a request for one exact historical version.
That is a direct precedent for Helm:
**a floor ticket can be portable,
but it should remain a bounded read-side footing claim rather than ambient write authority.**

### MongoDB: causal footing can cross sessions, but only explicitly
MongoDB says operations can be causally consistent across different sessions by advancing a session's operation time and cluster time to match another session.
That is exactly the shape of a Helm carried-footing act:
**explicit transfer,
explicit advance,
not ambient invisible continuity.**

### Couchbase: targeted lower-bound packets beat giant global consistency
Couchbase's `MutationState` and `consistentWith` / `AT_PLUS` model is especially useful because it lets a query or search carry a targeted set of mutations and wait only for those,
rather than forcing full `request_plus` strength.
That suggests a beautiful Helm move:
**carry only the floor that matters for this deck / share / compare,
not one giant global portability regime.**

### Spanner and CockroachDB: exact timestamps and lower bounds should stay typed
Spanner makes `READ_TIMESTAMP`, `MIN_READ_TIMESTAMP`, and stale/strong modes explicit.
CockroachDB keeps `with_min_timestamp` and `with_max_staleness` explicit and can even error when a nearest-replica lower-bound read cannot be honored locally.
That means Helm should keep:
- exact carried footing,
- lower-bound carried footing,
- stronger local footing,
- and receiver-cannot-honor-this-here
as visibly different classes.

## What the companion cubes are teaching now

### Keep from SlopOS
Keep provider-locality discipline.
A provider-native session token,
clock,
or lower-bound vector should not become generic shell authority just because it crossed one seam.

### Keep from Ward
Ward's read cuts,
staleness budgets,
and revalidation fences imply that a received floor needs a receiver-side truth strip,
not just a sender-side claim.

### Keep from Schell
Keep restored-versus-live humility and strongest-next-verb discipline.
A carried floor should say whether the best next verb is inspect,
compare,
refresh,
adopt locally,
or reacquire stronger live footing.

### Keep from ViewFS
ViewFS is especially instructive here:
remembered designators,
exact continuity lockers,
revalidated live handles,
and durable receipts are different truths.
A **floor ticket** should stay closer to a remembered / bounded continuity object than to current live authority.

### Keep from Harbor / Exchange / materialization witnesses
Route truth and receiver materialization truth matter.
A receiver that fetched or staged bytes is still not automatically a receiver that honors the sender's earlier floor.
Helm should keep those truths separate.

## Bright steals for Helm

1. **Floor ticket**
   - a shell-owned,
     portable,
     read-oriented footing packet that can cross from one person / deck / device / share to another without pretending to be one ambient session.
2. **Handoff bound**
   - a tiny receiver-side strip like `verified here`, `stronger here`, `lower-bound only`, `receiver cannot verify`, `expired`, `downgrade required`.
3. **Receiver-strengthening verb**
   - `upgrade to local strong`, `adopt local floor`, `compare against carried floor`, `continue read-only from carried floor`.
4. **Portable-floor scope classes**
   - same-device,
     cross-device,
     shared-with-audience,
     compare-only,
     cite-only,
     read-only.
5. **Floor loss on import stays visible**
   - if a receiver cannot honor the carried floor,
     Helm should show exactly that instead of flattering the import as equivalent.

## What not to keep

Do not keep:
- one shell-wide hidden roaming session token,
- automatic carryover of lower bounds into stronger write acts,
- or any move that lets imported footing impersonate local live authority.

The shell should keep a tiny grammar,
let providers supply evidence,
and make receiver-side verification or downgrade explicit.

## Why this makes Helm super awesome

This makes Helm feel premium at one of the hardest continuity seams in modern systems.
A person can ask:
- `what footing am I carrying from the earlier review or device?`
- `does this receiver actually honor that floor here?`
- `is this share only compare-worthy or also safe for read-only continuation?`
- `what exactly would I gain by upgrading locally?`
- `what exactly would I lose if I keep going below the carried floor?`

That is a much better shell feel than one giant roaming cube.
Not because Helm promises universal continuity,
but because it keeps **carried footing,
receiver verification,
and local live truth** visibly separate.
