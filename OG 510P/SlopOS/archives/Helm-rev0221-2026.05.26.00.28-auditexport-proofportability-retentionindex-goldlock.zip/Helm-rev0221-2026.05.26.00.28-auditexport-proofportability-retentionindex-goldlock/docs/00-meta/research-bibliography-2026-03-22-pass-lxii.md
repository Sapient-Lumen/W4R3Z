# Research bibliography — 2026-03-22 — pass LXII

1. Grafana docs — *Annotate visualizations*
   - URL: https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/annotate-visualizations/
   - used for: manual panel annotations; range annotations; dashboard-wide annotation queries; event markers; tag filtering

2. Grafana docs — *Annotations HTTP API*
   - URL: https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/annotations/
   - used for: organization vs dashboard/panel scope; point/range fields; taggable annotation model

3. Datadog docs — *Annotations*
   - URL: https://docs.datadoghq.com/dashboards/annotations/
   - used for: manual time-series markers with descriptions; precision timestamp editing; persistence from dashboard widgets into notebooks

4. Honeycomb docs — *Customize Results / Markers*
   - URL: https://docs.honeycomb.io/investigate/query/customize-results
   - used for: markers as interesting points in time; point/range posture; environment-wide vs dataset-local scope

5. Honeycomb docs — *Manage Environment Markers*
   - URL: https://docs.honeycomb.io/configure/environments/manage-markers
   - used for: environment-level markers across datasets

6. Honeycomb docs — *List All Markers*
   - URL: https://docs.honeycomb.io/api/markers/list-all-markers
   - used for: explicit start_time / end_time / message fields for marker shape

7. PagerDuty docs — *Recent Changes*
   - URL: https://support.pagerduty.com/main/docs/recent-changes
   - used for: change-event details; recent changes; time-based / related-service / intelligent change correlations

8. PagerDuty docs — *Past Incidents*
   - URL: https://support.pagerduty.com/main/docs/past-incidents
   - used for: recent-versus-relevant historical similarity; same-service scoping; useful historical-neighbor lane ideas

9. Atlassian support — *What is the incident timeline?*
   - URL: https://support.atlassian.com/jira-service-management-cloud/docs/what-is-the-incident-timeline/
   - used for: mixed automatic/manual timeline posture and real-time incident history

10. Atlassian support — *Access and modify the incident timeline*
   - URL: https://support.atlassian.com/opsgenie/docs/access-and-modify-the-incident-timeline/
   - used for: manual timeline entries and real-time updating incident history
