# Helm: effect receipts + rerun ledgers — 2026-03-23

## Headline

Helm should probably stop leaving the strongest post-act answer to toasts,
activity rows,
and fuzzy memory.

The next support layer worth pulling forward is:
- **effect receipts**
- **slot verdict ledgers**

with one extra law now made explicit:

**a durable effect receipt should belong to one exact act or one exact rerun attempt,
and a slot verdict ledger should preserve partial aftermath without rewriting earlier attempts.**

## Why now

Helm's Exchange and strong-act ladder is finally getting good:
- action warrants
- drift gates
- transfer offers
- take cards
- route witnesses
- materialization witnesses

But after the stronger rung fires,
Helm still falls back too easily to:
- success toasts
- generic recent rows
- vague completed labels
- or one historical badge that hides what only partially landed

That is exactly where the companion cubes and public systems keep disagreeing with old shell folklore.

## The move

### Effect receipts

A Helm effect receipt should answer:
- what exact strong act happened
- on what exact basis relation
- in what exact attempt
- with what bounded terminal outcome class
- with what exact changed-set or affected-set summary
- and how that historical effect now relates to current live truth

### Slot verdict ledgers

A slot verdict ledger should keep partiality explicit.
It should answer things like:
- accepted-exact
- accepted-rebound
- default-filled
- left-pending
- refused
- failed-needs-repair
- rerun-succeeded-later

The key new emphasis is that rerun / redrive history should not overwrite the first attempt.
It should relate to it.

## Why this is different from nearby objects

- **route witness** = what exact receiver / route was chosen
- **materialization witness** = what exact payload the far side acquired
- **effect receipt** = what exact bounded durable aftermath landed for one act / one attempt
- **slot verdict ledger** = how exact sub-parts or slots fared within that aftermath
- **current-live beacon** = what is live now

That distinction matters because many current systems keep proving that:
- a callback may only mean dismissal,
- a promise may only mean popup launched,
- an execution may preserve prior successful steps,
- and an overall failed run may still have many succeeded subparts.

## Strongest ideas worth stealing

### 1. Stable run id, incrementing attempt id
GitHub's `run_id` plus `run_attempt` is exactly the kind of tiny law Helm wants.
A historical effect should be reopenable by stable act identity,
while each rerun attempt stays distinct.

### 2. Done / error / response as a bounded terminal contract
Google long-running operations are a great reminder that terminal truth can stay small:
- metadata while in flight
- done false or true
- exactly one of error or response on completion
Helm effect receipts should stay that disciplined.

### 3. Preserve successful history when rerunning broken subsets
AWS Step Functions redrive is a direct argument against history rewriting.
Successful steps stay in history.
Only the failed subset reruns.
That should shape Helm's repair and rerun story.

### 4. Overall failure can coexist with partial success
Kubernetes Indexed Jobs are excellent proof that whole-object failure and per-index success can coexist.
Helm should steal that law directly.

### 5. Completion callbacks can be weaker than they sound
Apple activity completion and Web Share promise timing both warn against overclaiming.
Helm should keep callback truth,
handoff truth,
and durable effect truth separate.

## What to keep from older inspirations

Keep:
- exact historical receipts
- partial rerun / redrive posture
- comparison of historical aftermath against current live state
- compact bounded outcome vocabularies
- inspectable attempt history

Peel away:
- giant workflow dashboards
- universal completion constitutions
- success labels that hide partial truth
- reruns that rewrite the first attempt
- any UI that lets historical aftermath impersonate current-live truth

## Why this could make Helm super awesome

### 1. Recall becomes much stronger
Recall could reopen one exact act,
one exact attempt,
and one exact partial aftermath without pretending any of it is still live now.

### 2. Operations Center becomes much more trustworthy
Instead of generic success rows,
it could show:
- applied-exact
- applied-partial
- pending-protected
- failed-needs-repair
- rerun-succeeded-later
- superseded

### 3. Exchange gets a complete premium ladder
Offer,
take,
route,
materialization,
and durable aftermath all become visible rungs.
That is rare and genuinely luxurious.

### 4. Repair becomes humane
A receipt could lead directly to:
- compare to current
- rerun failed subset
- reverse exact effect
- inspect unresolved slots
- or admit downstream unknown honestly

## Pull-the-trigger judgment

The seven pillars still look stable.
Helm still should not grow a giant workflow religion.
But it now looks wise to pull the next compact support move forward again:

**effect receipts + slot verdict ledgers with attempt-aware rerun lineage.**
