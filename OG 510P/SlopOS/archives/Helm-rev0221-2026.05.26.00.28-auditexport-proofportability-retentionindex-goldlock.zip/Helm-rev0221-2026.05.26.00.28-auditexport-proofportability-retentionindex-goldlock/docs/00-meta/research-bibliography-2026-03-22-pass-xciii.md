# Research bibliography — pass XCIII — 2026-03-22

## Sources reviewed this pass

- Kubernetes — Safely Drain a Node
- HAProxy — Management Guide (`ready` / `drain` / `maint` administrative state)
- XDG Desktop Portal — Inhibit portal documentation
- Temporal — Interrupt a Workflow: cancellation and termination
- Apple Documentation Archive — Searching File Metadata with `NSMetadataQuery`

## Companion archive surfaces re-read this pass

- SlopOS — `docs/30-architecture/quiesce-posture-v0.md`
- SlopOS — `docs/30-architecture/worker-pool-quiesce-state-v0.md`
- Steward — `docs/30-architecture/quiesce-posture-v0.md`
- Steward — `docs/30-architecture/stop-deferral-posture-v0.md`
- ViewFS — `rfcs/0039-viewfs-keep-cancel-terminate-forget-reset-and-rerun-separate.md`
- ViewFS — `rfcs/0040-viewfs-keep-observe-attach-control-and-sideband-lanes-separate.md`

## Why these mattered

- Kubernetes strengthened the distinction between **unschedulable / draining / resumed**.
- HAProxy strengthened the distinction between **ready / drain / maintenance**.
- XDG Portal strengthened **narrow handle-based inhibition with an explicit reason**.
- Temporal strengthened **cancel versus terminate**.
- Apple strengthened **pause live updates while inspecting moving results**.
