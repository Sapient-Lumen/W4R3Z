# Helm honest arrival stack — 2026-03-22

Purpose: name the smallest reusable shell grammar Helm seems to need between weak inspection and strong local truth.

## Main idea

Helm increasingly needs one shell-wide **strength ladder**:

1. **preview** — inspect without overclaiming
2. **compare or rehearse** — show how this would live here, or how it differs from one exact basis/local candidate
3. **materialize or adopt** — take an explicit stronger step
4. **live/local truth** — ordinary shell truth after the stronger step succeeds

This is not a new pillar.
It is the missing middle-state grammar that makes several existing candidate moves feel coherent.

## Why this matters now

Without this stack,
Helm risks forcing too many jobs onto only two states:

- weak inspection
- or already-live truth

That is exactly where shells start lying.

The likely victims would be:
- imported view objects
- checkpoint-derived branches
- deck recipes
- portable accelerator bands
- dock items
- route receipts and replay surfaces
- shared or published shell luxuries

## The four rungs

### 1. Preview

Preview remains weak.
It may inspect,
show provenance,
and expose bounded nearby actions.
But it does not yet claim adoption,
open-local truth,
or live continuity.

### 2. Compare / rehearse

This is the missing humane middle.
A surface may:
- compare one arriving thing against one exact basis or one explicit local candidate
- render provisionally on the receiver
- show unresolved slots,
  near matches,
  and local defaults still in play

But it still does not count as adopted.

### 3. Materialize / adopt

Here the shell takes a named stronger act.
This is where:
- fresh local identity may be minted
- a stronger local binding may be chosen
- a checkpoint-based branch may become an admitted local branch
- a recipe may become a local deck or command band

This should leave durable witness.

### 4. Live/local truth

Only after the stronger step succeeds should the shell use ordinary active/local/live language.

## Cross-pillar effects

### Omnibox
- preview first
- compare/rehearse for imported/shared surfaces
- explicit adopt/materialize before pretending the result is now ordinary local truth

### Object Browser
- saved view objects benefit immediately
- imported or shared views can be inspected,
  rehearsed,
  compared,
  and only then adopted

### Recall
- checkpoints benefit from preview,
  compare,
  restore,
  and branch staying visibly distinct

### Exchange
- packets,
  imports,
  and shared surfaces need arrival overlay plus landing rehearsal before stronger landing acts

### Desktop Flow
- graph fragments,
  starters,
  and helper-produced candidates need a materialization/adoption step instead of silent write-through

### Operations Center
- status rows should be able to say previewed,
  rehearsed,
  materialized,
  adopted,
  denied,
  or live rather than only “done/not done”

### Tiling Shell
- launch recipes,
  dock items,
  and layout starters become more honest if they can be rehearsed before adoption

## Pull-the-trigger judgment

Helm should not freeze a giant new constitution for this.

But it does look wise to start treating the following as one support stack:

- preview-promotion ladders
- imported-surface trust posture
- landing rehearsals
- arrival overlays
- materialization bays

That stack is probably the cleanest path to making Helm richer without making it less truthful.
