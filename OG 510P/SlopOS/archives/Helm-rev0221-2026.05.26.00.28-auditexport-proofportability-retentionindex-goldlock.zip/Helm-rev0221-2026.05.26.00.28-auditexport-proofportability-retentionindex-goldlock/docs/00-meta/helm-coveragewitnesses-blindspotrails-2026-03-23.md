# Helm coverage witnesses + blindspot rails — 2026-03-23

## Narrow thesis

After **footing marks** and **salience lenses**,
Helm still lacks one compact shell-owned answer to:

**what exact space did this compact surface actually look at,
and what stayed outside view?**

That is not the same as:
- a state tuple
- a why rail
- a footing mark
- a delta brief
- a salience lens
- a watchpoint
- or a generic citation list

It is the next seam those surfaces need in order to stop bluffing completeness.

## What to keep

Keep:
- the seven pillars
- typed action mode
- landmarks
- reality strips
- continuity postcards
- state tuples
- grounding witnesses + why rails
- delta briefs
- footing marks
- salience lenses
- watchpoints and view subscriptions

## What to peel away

Peel away:
- recap language that sounds universal when it only covered one lane,
one source family,
or one time cut
- cited summaries that never say what sources were out of range,
stale,
or unauthorized
- compact operational cards that hide their time window
- “checked everything” vibes created by one flattering surface with no declared blind spots

## The next shell-wide seam

Helm should admit **coverage witnesses**,
with tiny nearby **blindspot rails**.

A coverage witness says:
- which source families,
lane families,
accounts,
windows,
footholds,
or saved views were inspected
- what time window or compared cut applied
- what freshness and authorization posture each source carried
- which source families were explicitly outside scope
- and which widen / resync / inspect exit should open next

A blindspot rail says:
- what important nearby truth stayed outside view
- whether that absence is because of staleness,
authorization,
out-of-range posture,
non-adoption,
or deliberate narrowing
- and what the cheapest honest next move is

## Good first blindspot classes

Good first classes look like:
- `stale-source`
- `unauthorized-source`
- `out-of-range-window`
- `not-adopted-lane`
- `grouped-and-inspectable`
- `excluded-by-lens`
- `not-yet-revalidated`
- `shared-ops-not-covered`
- `personal-only-coverage`
- `historical-only-coverage`

## Why this is worth pulling now

Because once Helm can say both:
- **since what footing?**
- **under what salience lens?**
- and **over what actual inspected coverage?**

its compact surfaces become much calmer and much harder to misread.

A delta brief can say:
- compared against `last-reviewed`
- under `review-critical`
- over `foreground lane + review queue + last 24h`
- with `candidate lane not covered`

A watchpoint can say:
- law = `count above threshold`
- lens = `blocker-and-threshold`
- coverage = `one saved view over prod lanes only`
- blindspot = `staging and imported lanes excluded`

A continuity postcard can say:
- this is a personal return slice
- based on your `last-visited` footing
- counting blocker/adoption/owner-confirmation changes
- but not claiming shared operational completeness

That is a real product ratchet.
It makes Helm feel more exact,
more humane,
and more super-awesome without another pillar.

## Pull-the-trigger judgment

It now looks wise to pull one narrow trigger:

**promote shell-owned coverage witnesses,
with inspectable blindspot rails as their tiny nearby face.**

That is the next honest move after salience lenses.
