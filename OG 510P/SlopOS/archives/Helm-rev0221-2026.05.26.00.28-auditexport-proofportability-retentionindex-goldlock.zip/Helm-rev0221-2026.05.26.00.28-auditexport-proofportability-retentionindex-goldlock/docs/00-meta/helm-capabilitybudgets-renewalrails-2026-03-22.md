# Helm: capability budgets + renewal rails — 2026-03-22

Purpose: identify the next small upgrade above authority windows,
grant-rung ladders,
exact remembered handles,
and capability recipes.

## Main claim

Helm should add one calmer upstream rule:

- a shell thing can declare a **capability budget**
- a shell thing can hold a **current lease window**
- returning to power should go through an explicit **renewal rail**

That sounds modest,
but it would clean up a lot of ambiguity.

## 1. Capability budgets

A **capability budget** is not current authority.
It is a shell-owned statement of the strongest asks a surface may later make.

Good candidates:
- front doors
- entry kits
- capability recipes
- Desktop Flow fragments
- helper lanes
- import packets that may later materialize into stronger local acts

A budget should be compact.
It can name things like:
- authority families it may ask for
- admitted subject classes
- max exposure class it may request
- whether it may ask for persistence
- whether it may ask for live-lane power or only isolated-lane power

What a budget is **for**:
- setting expectations early
- making later asks less surprising
- letting the shell tell the difference between
  “this is inside the declared plan”
  and
  “this is a widening event”

What a budget is **not**:
- current-live authority
- a hidden pre-approval
- a giant policy studio
- proof that every later ask inside the budget should be auto-granted

## 2. Lease windows

A **lease window** is the current-live truth.
It says what exact borrowing exists now.

A good lease window would show:
- exact holder
- exact subject or cohort
- exact rung
- lane posture
- start / expiry / persistent-until-revoked posture
- revoke or narrow controls
- relation to the broader budget,
  if any

This lets Helm stay calm about a common confusion:
remembered handles,
recipes,
and historical receipts can all survive,
but the lease window is still the thing that says what is borrowed **now**.

## 3. Renewal rails

A **renewal rail** is the explicit next-step grammar from an old,
expired,
revoked,
or about-to-expire lease.

The important moves are not all the same.
Helm should keep them visibly distinct:

- **renew same**
  - same subject,
    same rung,
    same lane
- **renew narrower**
  - same subject,
    lower rung or shorter duration
- **move to isolated lane**
  - broader room,
    but only in side work
- **broaden with fresh ask**
  - larger subject,
    longer duration,
    stronger persistence,
    or stronger lane
- **let expire / keep recipe only**
  - preserve the starter without pretending the power remained live

The key law:
**renewal must never silently widen.**

## 4. Why this is worth stealing now

Helm already has many ingredients that become better under this rule:

### Omnibox
A result can show:
- budget declared,
- current lease absent,
- renew same,
- or widen with fresh ask.

### Operations Center
A row can show:
- this thing may ask for X,
- but it is currently borrowing only Y,
- and that Y expires in 14 minutes.

### Recall
A remembered item can say:
- exact handle remembered,
- old lease expired,
- safe reacquire available,
- broader old power not automatically returning.

### Exchange
An imported recipe or packet can preserve the declared budget,
while arriving with zero live local lease.
That is a very good honesty move.

### Desktop Flow
A fragment can declare the families it may ask for,
then consume only narrow per-run leases until an operator explicitly promotes it.

## 5. Super-awesome moves hiding inside this

### Borrowed-now ribbon
A tiny shell-wide strip or chip family that answers:
- what am I borrowing now?
- from whom?
- for what exact subject?
- until when?
- what is the next honest renewal move?

### Budget chips on front doors and recipes
A front door should not only say what it opens.
It should also be able to say:
- may ask for file access to one project root
- may ask for publish to guarded-link only
- may ask for background presence in isolated lane only

That would make starters feel unusually legible.

### Renewal compare
When a lease is reacquired,
Helm should be able to compare:
- previous subject,
- requested subject,
- previous rung,
- requested rung,
- previous lane,
- requested lane.

That would make widening events much harder to hide.

### Recipe survives,
lease does not
This may be one of the best product feelings in the whole system.
A recipe can remain useful and portable,
while its live lease has expired honestly.
The user keeps the convenience,
without inheriting stale authority mythology.

## 6. What to keep from older inspirations

Keep:
- temporary first,
  stronger later
- exact chosen subjects
- per-item revoke
- incremental asking in context
- session-policy intersection / attenuation
- restricted-first imports

Peel away:
- giant all-up permission dashboards
- ambient persistence by default
- sticky approvals that reappear broader than before
- recipes or bookmarks masquerading as live power

## 7. Current judgment

Do **not** add a pillar.
Do **not** build a giant policy constitution.

Do make one new datacube split more explicit:

- **capability budget**
- **current lease window**
- **renewal rail**

That looks like one of the cleanest remaining ways to make Helm super awesome without making Helm more bloated.
