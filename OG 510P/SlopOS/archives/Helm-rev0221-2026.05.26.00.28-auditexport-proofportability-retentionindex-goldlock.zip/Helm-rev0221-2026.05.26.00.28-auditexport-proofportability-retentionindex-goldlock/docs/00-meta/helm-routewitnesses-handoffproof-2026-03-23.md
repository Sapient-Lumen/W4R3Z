# Helm: route witnesses + handoff proof — 2026-03-23

## Headline

Helm should probably add one compact Exchange object for this sentence:

**for this exact offered material,
this exact chosen receiver / route was actually selected,
through this exact chooser path,
in this exact representation / operation posture,
and this is the strongest handoff truth the shell currently has —
without pretending the final downstream effect is already known.**

That object should be a **route witness**.

## Why now

Helm now has a much better Exchange story than it did before:
- ingress packets
- transfer offers
- receiver-fit cards
- take cards
- review strips
- gesture runways
- helper escorts
- and generic effect receipts

What it still lacks is the compact truth between:
- **this route looks viable**
- and **this route later produced durable effect truth**

Without that missing middle,
Helm still risks four familiar lies:
- a remembered or highlighted direct target pretending it was definitely chosen now
- a take card pretending the route actually happened
- a chooser callback pretending the downstream effect is already finished
- or a single “shared / sent / opened” badge erasing whether the shell only knows route choice,
  handoff admission,
  receiver-local confirm UI,
  or durable effect

## The move

A Helm route witness should be:
- shell-owned
- attached to one exact transfer offer and one exact chosen receiver / route
- stronger than a take card
- weaker than an effect receipt
- explicit about how the route was chosen
- explicit about what the shell knows now and what remains provider-local or pending
- and easy to open into later effect receipts,
  route weather,
  or repair / retry lanes

## Why this is different from nearby objects

- **transfer offer** = what exact source is offering before a route is chosen
- **take card** = what one candidate receiver could honestly take right now
- **route witness** = what route / receiver the user actually chose,
  through what chooser path,
  with what chosen representation / operation posture,
  and what handoff truth the shell currently has
- **effect receipt** = what exact durable aftermath later landed

That distinction matters.
A chooser may tell us the selected target.
A quick route may have a remembered id and supported formats.
A direct target may launch the right receiver-local UI.
A web share promise may resolve at popup launch on one platform and after data handoff on another.
None of that means the final downstream effect is already proven.

## Strongest ideas worth stealing

### 1. Chosen route deserves its own witness
Android chooser callbacks,
Windows QuickLink ids,
and Apple sharing-service selection are all evidence that route choice is a meaningful surface.
Helm should admit that directly.

### 2. Prewarmed route luxury is worth stealing
Sharing Shortcuts and QuickLinks prove that route memory can make exchange feel dramatically faster.
Helm should steal this,
but keep freshness,
supported-format weather,
and explicit user choice visible.

### 3. Route memory should be typed and stale-aware
A saved route that used to work for files may not fit today's offer.
A remembered contact or target may have decayed.
A route witness should let Helm say:
- remembered but stale
- remembered and format-fit
- helper-suggested only
- direct target chosen now
- quick route reopened from history

### 4. Handoff truth and effect truth are different rungs
The shell should be proud when it knows only:
- selected target,
- handoff admitted,
- receiver-local confirm surface opened,
- or provider-local completion unknown.

That humility is better than a fake completed badge.

### 5. One-shot and closing routes should stay visible
If a route autostops after one retrieval,
opens a confirm/edit surface,
or yields no durable completion callback,
that should remain part of the witness.

## What to keep from older inspirations

Keep:
- typed plumbing / exact route humility
- chooser magic that stays weaker than authority
- route-local memory with freshness weather
- compare / review / promote grammar before stronger acts
- durable effect receipts as a later separate object

Peel away:
- hidden default routes that silently override user intent
- one generic sent/shared/opened toast
- giant universal share ontologies
- prewarmed targets that never admit staleness
- route ranking that cannot explain itself

## Why this could make Helm super awesome

### 1. Exchange would feel unbelievably crisp
Helm could show exactly what was chosen and what is merely expected next.
That is rare.

### 2. Fast remembered routes would stop feeling spooky
Users could enjoy quick routes,
direct targets,
and helper suggestions without wondering whether the shell secretly chose for them.

### 3. Cross-surface reuse becomes much cleaner
Omnibox,
Recall,
Object Browser,
Terminal/Capshell,
and Operations Center could all cite the same route witness.

### 4. Later receipts get much better
A route witness is the perfect parent for:
- one effect receipt
- one canceled / closed route outcome
- one retry / reroute repair move
- or one “downstream effect unknown” humility badge

## Pull-the-trigger judgment

Helm still should not freeze one universal exchange backend,
full ranking engine,
or mega route ontology.
But it probably **is** time to warm one compact sequel after take cards:

**route witnesses** — shell-owned chosen-route objects that preserve exact offer,
exact selected receiver,
chooser path,
representation / operation posture,
route freshness / memory weather,
and strongest-known handoff truth without flattering route choice into durable effect. 
