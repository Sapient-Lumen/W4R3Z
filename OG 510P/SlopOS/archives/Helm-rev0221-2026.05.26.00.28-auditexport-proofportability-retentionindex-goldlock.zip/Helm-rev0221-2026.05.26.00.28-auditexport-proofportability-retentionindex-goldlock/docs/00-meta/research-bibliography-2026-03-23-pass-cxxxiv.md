
# Research bibliography — 2026-03-23 pass CXXXIV

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-GITHUB-REQUIRED-REVIEWS-2026 | https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests/approving-a-pull-request-with-required-reviews | required review counts and stale-review dismissal after code-modifying commits |
| REF-GITHUB-BRANCH-PROTECTION-2026 | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/managing-a-branch-protection-rule | required approval counts, merge-base stale dismissal, code-owner requirement, recent-push approval option |
| REF-GITHUB-MERGE-QUEUE-2026 | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | checks retested against latest target branch and queued changes |
| REF-GITLAB-APPROVAL-RULES-2026 | https://docs.gitlab.com/user/project/merge_requests/approvals/rules/ | multiple approval rules, optional versus required rules, eligible approvers, counted approvals |
| REF-LAUNCHDARKLY-APPROVAL-SETTINGS-2026 | https://launchdarkly.com/docs/home/releases/approvals-settings | approvals required count, self-approval, consensus-required, approval enforcement |
| REF-LAUNCHDARKLY-APPROVAL-REQUESTS-2026 | https://launchdarkly.com/docs/home/releases/approval-requests | required approvals and bounded bypass posture |
| REF-JIRA-APPROVAL-STEPS-2026 | https://support.atlassian.com/jira-service-management-cloud/docs/set-up-approvals/ | approvers and approver-group fields plus workflow-blocking approval steps |
| REF-FIGMA-BRANCH-REVIEW-2026 | https://help.figma.com/hc/en-us/articles/5691414603543-Request-a-branch-review | one-or-more reviewers and explicit review outcomes |
| REF-FIGMA-BRANCH-MERGE-2026 | https://help.figma.com/hc/en-us/articles/5691189138839-Merge-branch-into-main-file | approved state remains separate from merge authority and final merge |
