# Research bibliography — 2026-03-22 pass XXVII

## Primary outside sources used in this pass

- Microsoft Learn — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Microsoft Learn — **Workspace Trust**
  - https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- Microsoft Learn — **Copilot CLI sessions in Visual Studio Code**
  - https://code.visualstudio.com/docs/copilot/agents/copilot-cli
- Microsoft Learn — **Revert changes with checkpoints and editing requests**
  - https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- Microsoft Learn — **Using agents in Visual Studio Code**
  - https://code.visualstudio.com/docs/copilot/agents/overview
- Raycast Manual — **Cloud Sync**
  - https://manual.raycast.com/cloud-sync
- Raycast Manual — **Shared Quicklinks**
  - https://manual.raycast.com/quicklinks/shared-quicklinks
- Raycast Manual — **Deeplinks**
  - https://manual.raycast.com/deeplinks
- Obsidian Help — **How Obsidian stores data**
  - https://obsidian.md/help/data-storage
- Warp docs — **Launch Configurations**
  - https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp docs — **URI Scheme**
  - https://docs.warp.dev/terminal/more-features/uri-scheme
- WezTerm docs — **Workspaces / Sessions**
  - https://wezterm.org/recipes/workspaces.html
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — **Adding Dock support to your extension**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Notion Docs — **Working with views**
  - https://developers.notion.com/guides/data-apis/working-with-views
- Figma Help — **Guide to Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Figma Help — **Compare changes in Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode

## Main local teacher documents re-opened in SlopOS rev0585

- `rfcs/0032-view-namespace-semantics-v1.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0053-origin-quarantine-and-safe-open.md`
- `rfcs/0054-authority-diffs-and-consent-receipts.md`

## What these sources mainly taught this pass

- **Figma / VS Code checkpoints**: explicit compare bases,
  snapshots,
  and “what version am I looking at?” truth deserve a reusable compact witness
- **VS Code Profiles / Trust / Copilot CLI**: carried structure should arrive inspectably,
  but trust,
  isolation,
  and apply steps still live on the receiver side
- **Raycast**: exact action handles can carry small start context,
  while sync/share exclusions make omitted-local residue first-class truth
- **Obsidian / Warp / WezTerm / PowerToys**: saveable or pinnable shell structure is real,
  but mutable layout residue,
  hidden-until-activated workspaces,
  and explicit dock bands remain distinct classes
- **Notion**: views remain explicit first-class objects with dashboard composition rather than ambient sameness
