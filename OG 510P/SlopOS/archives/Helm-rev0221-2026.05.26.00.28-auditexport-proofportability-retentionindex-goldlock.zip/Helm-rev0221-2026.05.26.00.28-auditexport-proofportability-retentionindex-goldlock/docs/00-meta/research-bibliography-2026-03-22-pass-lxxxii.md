# Research bibliography — 2026-03-22 — pass LXXXII

1. **Nix Reference Manual — Profiles**
   - source: https://nix.dev/manual/nix/2.28/package-management/profiles.html
   - used for: profiles as the mechanism for different configurations plus atomic upgrades and rollbacks

2. **Nix Reference Manual — `nix-env --rollback`**
   - source: https://releases.nixos.org/nix/nix-2.29.1/manual/command-ref/nix-env/rollback.html
   - used for: previous-generation rollback posture and profile-as-generations wording

3. **Nix Reference Manual — `nix-env --delete-generations`**
   - source: https://releases.nixos.org/nix/nix-2.20.0/manual/command-ref/nix-env/delete-generations.html
   - used for: retention / pruning posture over old generations

4. **Docker Docs — Image digests**
   - source: https://docs.docker.com/dhi/core-concepts/digests/
   - used for: immutable digest posture as a model for exact generations or pinned handles

5. **Docker Docs — `docker image tag`**
   - source: https://docs.docker.com/reference/cli/docker/image/tag/
   - used for: movable tag posture and the default-to-`latest` warning as a model for floating aliases

6. **AWS S3 User Guide — Download and upload objects with presigned URLs**
   - source: https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html
   - used for: exact-object, time-bounded, revocable share-link posture

7. **Tailscale Docs — Tailscale Serve**
   - source: https://tailscale.com/docs/features/tailscale-serve
   - used for: sharing one local service within the tailnet rather than widening to the whole machine or the public internet

8. **Tailscale Docs — Funnel vs. sharing devices**
   - source: https://tailscale.com/docs/reference/funnel-vs-sharing
   - used for: public-link vs single-resource vs whole-device sharing distinctions and quarantined-device posture

9. **VS Code Docs — Profiles in Visual Studio Code**
   - source: https://code.visualstudio.com/docs/configure/profiles
   - used for: profile objects that can be created, switched, shared, and imported without becoming live-state mythology
