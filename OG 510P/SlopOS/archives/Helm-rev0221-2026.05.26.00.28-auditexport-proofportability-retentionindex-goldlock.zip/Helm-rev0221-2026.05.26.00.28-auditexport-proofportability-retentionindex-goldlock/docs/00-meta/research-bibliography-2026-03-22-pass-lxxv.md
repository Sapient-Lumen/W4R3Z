# Research bibliography — 2026-03-22 — pass LXXV

Purpose: record the sources used for the least-reach / exact-cohort pass.

## Primary outside sources

- Android Developers — Grant partial access to photos and videos
- Android Developers — Photo picker
- Chrome for Developers — `activeTab` permission
- Chrome for Developers — File System Access API
- WICG File System Access explainer
- Google Identity — OAuth 2.0 best practices
- Google Drive Picker overview
- Slack Help — Understand app permissions

## What these sources were used for

- **Android photo picker / Selected Photos Access**: selected subset instead of whole library; reselection; partial access; temporary URI posture.
- **Chrome `activeTab`**: exact current-tab access after explicit invocation instead of persistent all-sites scope.
- **File System Access API + explainer**: chooser-first handles, persisted handles that may still be re-prompted or revoked, and limited view semantics.
- **Google OAuth best practices**: incremental authorization, smallest/most-limited scope guidance, and contextual requests.
- **Google Drive Picker**: selected-file access instead of giant Drive-management semantics.
- **Slack app permissions**: explicit view/post/perform posture and narrower newer scopes.
