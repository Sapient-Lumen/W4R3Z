# SlopOS + companions evaluation — 2026-03-23 pass CXLIII

## Why this pass happened

The last Helm revision made the strongest adjacent cluster explicit:
**watch leases, drift budgets, distrust bands, and maybe later wake ladders.**

This pass asked the next nearby question:
**once Helm can say who is watching and when old evidence becomes suspect, how should it tell the truth about who actually owns reaction, who has acknowledged the current posture, and whether anyone is really on duty right now?**

The companion cubes still say the same big thing:
- freeze laws before giant centers,
- keep shell-owned truth stronger than explanation,
- and do not let design-phase convenience harden into fake authority.

## What SlopOS still teaches best

### 1) Family/index discipline matters even more once receiver furniture starts multiplying
SlopOS keeps showing why closed families and singleton contracts matter.
If Helm adds owner chips,
ack rails,
and coverage lamps,
it will need the same hygiene so ownership,
subscription,
watch duty,
and live authority do not blur together.

### 2) Imported metadata must not quietly become present-tense local truth
SlopOS remains an excellent teacher for this:
provider-local metadata,
historical descriptors,
and imported posture are useful,
but still weaker than current local truth.
That transfers directly here.
An imported recipient list,
shared watch definition,
or inherited owner label should not quietly count as current local responsibility.

## What Ward now teaches best

### 1) Receiver stance is different from signal delivery
Ward's new attenuation-event / receiver-stance work is the sharpest local teacher for this pass.
It keeps pressing that a later signal is not yet the local action;
the receiver still chooses a stance.
That maps directly into Helm.
A slice can have a subscription,
a warning,
or a shared handoff,
without that meaning the local receiver has accepted ownership of reaction.

### 2) Status receivers matter more than generic watchers
Ward also keeps teaching that continuous status needs named receiver lanes.
That is a strong hint for Helm:
watching should eventually grow a stronger local receiver shape,
not just a flat recipient list.

## What Steward now teaches best

### 1) Presence advertisement is not readiness
Steward's presence-advertisement posture is a very good local warning here.
Published presence,
renewal,
withdrawal,
and expiry are different truths from readiness and current serving truth.
For Helm,
a slice can show:
- recipients configured,
- ownership named,
- a watch lease active,
- or coverage currently absent.
Those should stay visibly different.

### 2) Observation subscriptions are observational, not mutating
Steward's observation-subscription posture is also directly relevant.
Subscriptions bind to explicit targets and reduce polling,
but they do not replace explicit reads or stronger source truth.
That maps cleanly into Helm:
subscribed is weaker than acknowledged,
and acknowledged is weaker than resolved.

## What Harbor still teaches best

### 1) Route and authority are still different truths
Harbor keeps teaching that route visibility,
receiver identity,
and current authority should not collapse.
Helm should keep that same discipline.
A slice may be routed to a team,
owned by someone else,
and currently covered by a temporary override.
Those are not one badge.

## What Schell and ViewFS still teach best

### Schell
Schell still teaches that wake,
response,
resolution,
and residue are different truths.
That transfers directly here:
acknowledged is not resolved,
and current response ownership is not historical authorship.

### ViewFS
ViewFS still teaches exact footing and renewed consent.
That matters because ownership and acknowledgement should stay tied to one exact reviewed slice,
not to a fuzzy changing view family.

## Lessons Helm must learn from the past

### Must learn #1: subscriber is not owner
A recipient list is useful.
It is still weaker than named responsibility.

### Must learn #2: acknowledged is not resolved
The incident world keeps teaching this same truth.
Acknowledgement usually means “someone is working it,”
not “the underlying condition is gone.”

### Must learn #3: recipients are not coverage
A list of interested people is not the same as current on-duty coverage,
backup coverage,
or explicit gap.

### Must learn #4: maintenance or mute is not health
Quieted delivery can be legitimate.
It still should not rewrite underlying watch or slice health.

### Must learn #5: creator authority and recipient visibility are different truths
Shared subscriptions,
alerts,
or briefs often deliver the creator's view to recipients.
That is useful,
but Helm should keep receiver visibility and source authority visibly separate.

## What Helm should steal now

- SlopOS-style family/index hygiene before owner / ack / coverage families multiply too far
- Ward's receiver-stance humility so delivery never impersonates local ownership
- Steward's presence-versus-readiness split so configured recipients never impersonate active coverage
- Steward's subscription humility so observation transport never impersonates stronger truth
- Harbor's refusal to let route impersonate authority
- Schell's acknowledged-versus-resolved separation
- ViewFS exact-footing discipline so owner/ack state always binds to one exact reviewed slice

## Product judgment

Do **not** freeze a giant on-call center.
Do **not** freeze a giant receiver/governance console.
Do **not** let subscriptions,
owner labels,
or acknowledgement chips become a second authority plane.

But do keep warming one adjacent cluster around:
- **owner chips**
- **ack rails**
- **coverage lamps / gap witnesses**
- and maybe later explicit **shadow or handoff lanes**

That now looks like the next best way to make Helm's datacube feel super truthful and super useful
once reviewed slices,
smart decks,
replayable answers,
and watched evidence start depending on actual human receivers instead of just abstract monitoring posture.
