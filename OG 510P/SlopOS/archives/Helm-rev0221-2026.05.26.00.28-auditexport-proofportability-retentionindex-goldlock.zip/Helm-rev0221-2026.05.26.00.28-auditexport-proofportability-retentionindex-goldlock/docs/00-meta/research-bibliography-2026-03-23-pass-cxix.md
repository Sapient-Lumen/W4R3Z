# Research bibliography — 2026-03-23 pass CXIX

1. Kubernetes Pod Lifecycle
   - URL: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/
   - Why it mattered: phase is explicitly not a comprehensive rollup, and Pod conditions carry `reason` and `message` fields.

2. GitHub REST API — Check runs
   - URL: https://docs.github.com/en/rest/checks/runs
   - Why it mattered: separates `status` from `conclusion`, provides `details_url`, structured output, and exact annotations.

3. systemd `systemctl` source/manpage material
   - URL: https://cgit.freedesktop.org/systemd/systemd/tree/src/systemctl/systemctl.c
   - Why it mattered: explicitly describes ACTIVE as the high-level unit activation state and SUB as the low-level state.

4. Argo CD metrics
   - URL: https://argo-cd.readthedocs.io/en/latest/operator-manual/metrics/
   - Why it mattered: exposes separate `sync_status`, `health_status`, and application conditions.

5. Argo CD resource health
   - URL: https://argo-cd.readthedocs.io/en/latest/operator-manual/health/
   - Why it mattered: common health checks depend on observed generation matching desired generation.

6. Argo CD `argocd app get`
   - URL: https://argo-cd.readthedocs.io/en/stable/user-guide/commands/argocd_app_get/
   - Why it mattered: current-operation detail is revealable on demand rather than flattened into summary state.

7. Argo CD security
   - URL: https://argo-cd.readthedocs.io/en/stable/operator-manual/security/
   - Why it mattered: explanation and logs can stay useful while still redacting sensitive support.

8. PowerToys Command Palette Dock
   - URL: https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
   - Why it mattered: validates a tiny always-near command surface that stays weaker than a full control plane.

9. PowerToys Command Palette overview
   - URL: https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
   - Why it mattered: keeps typed modes, pinned commands, and command-first invocation explicit.

10. Raycast Quicklinks
    - URL: https://manual.raycast.com/quicklinks
    - Why it mattered: selected text can feed the first argument of a promoted quick action without pretending ambient context is free.
