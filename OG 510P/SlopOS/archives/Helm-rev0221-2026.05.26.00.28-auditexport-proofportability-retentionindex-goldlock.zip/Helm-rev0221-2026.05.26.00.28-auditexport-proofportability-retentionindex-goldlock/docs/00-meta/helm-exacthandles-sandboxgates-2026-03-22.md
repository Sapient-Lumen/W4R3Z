# Helm exact handles, sandbox lanes, and protection gates — 2026-03-22

Purpose: identify the next few moves that could make Helm feel dramatically better without expanding it into a giant new datacube constitution.

## The shortest answer

Helm gets more awesome when it makes three things first-class:

1. **exact remembered handles**
2. **constrained helper lanes**
3. **named protection gates**

These are not giant new pillars.
They are cross-pillar ratchets that make the existing pillars sharper,
safer,
and more delightful.

## 1. Exact remembered handles

Helm should remember a reopened thing as an exact handle whenever the host allows it,
not as a flattering title/path story.

A great Helm handle card could show:
- exact subject kind
- last-known label / thumbnail / path as secondary comfort
- current access posture: current,
  stale,
  revoked,
  repairable,
  re-requestable
- last resolved basis or identity witness
- nearby re-request / relink / inspect controls

Why it matters:
- **Omnibox** can summon real remembered things,
  not just fuzzy recents
- **Recall** can tell live,
  handle-backed,
  repaired,
  and historical return stories apart
- **Exchange** can travel subjects honestly
- **Object Browser** can say whether a thing is truly reopenable,
  only historically known,
  or matched approximately

## 2. Requested-target pickers

When Helm suspects the user means one exact thing,
it should open the chooser already pointed at that thing.

Examples:
- “Reconnect this shared sheet” should open on that sheet,
  not a giant drive browser
- “Repair this route” should start on the missing subject,
  not a whole provider home
- “Grant this folder again” should begin at the prior exact folder

Why it matters:
it preserves intent,
keeps chooser universes bounded,
and makes consent feel exact rather than ambient.

## 3. Constrained helper lanes

Helm should let helpers be powerful **inside explicit bounds**.

A helper lane should be able to show:
- mode: observe,
  suggest,
  prepare,
  adoption-ready,
  apply-capable
- file/object bounds
- network/peer bounds
- allow / ask / deny posture
- what boundary was hit
- whether outputs are only proposals,
  only previews,
  or adoption-ready artifacts

Why it matters:
this is the cleanest path to stronger shell assistance without ambient-trust mythology.

## 4. Named protection gates

A strong act should be able to stop at a visible gate stack before execution.

Possible gates:
- reviewer gate
- delay / quiet-window gate
- environment / audience gate
- custom policy gate
- exact-basis freshness gate
- external system approval gate

The shell should keep these visibly different from:
- the plan or warrant
- the current live object
- the final effect receipt

Why it matters:
Helm stops pretending that “ready” means “admitted,”
and operators can see what still stands between proposal and effect.

## 5. Signature delights these moves enable

### A. Reopen that actually means something
A Recall card says:
- `current-live`
- `exact handle`
- `repair needed`
- `historical only`

That is much better than one generic reopen button.

### B. Helpers that feel brave but not scary
A helper lane badge says:
- `suggest only`
- `sandboxed: repo + docs/`
- `network: github.com only`
- `ask before publish`

That is a premium shell feeling.

### C. Strong acts with visible stairs
A publish/apply card says:
- `plan ready`
- `reviewer gate pending`
- `quiet window starts 18:00`
- `custom policy passed`
- `execute now`

That feels much more trustworthy than a better confirm dialog.

## 6. Pull-trigger guidance

### Pull now

- exact remembered handles as a product goal
- requested-target chooser starts
- helper-lane sandbox badges and bounds
- named protection gates as a shell concept

### Keep warm

- giant policy studios
- giant background-agent frameworks
- universal continuity mythology
- giant remembered-object taxonomies

## Closing judgment

Helm does not need a bigger constitution to feel super awesome.

It needs:
- **remember exactly**
- **help inside bounds**
- **gate stronger acts visibly**

That is enough to make the seven pillars feel much more mature.
