# SlopOS companions evaluation — 2026-03-23 pass CXLIX

## Purpose

Continue mining **SlopOS**, **Schell**, **ViewFS**, **Ward**, **Harbor**, and **Foundry**
after the carry-forward / review-packet pass by asking one tighter question:

**what should Helm learn next if it wants current review turns,
re-opened review,
and small human handoffs to stay legible
without confusing them with ownership,
coverage,
or broad watch posture?**

## 1. SlopOS keeps teaching that attention is a bounded shell truth,
not a side effect of history

Recent SlopOS attention surfaces still make the same broad law clear:
there is a difference between durable status,
durable interrupt,
lease,
background request,
and actual current attention.
That matters for Helm.
A review packet may survive.
An owner may persist.
But the currently expected human turn should still be a separate tiny truth.

**Take for Helm:**
keep current actor truth separate from reviewer history,
ownership,
and broad notification audience.

## 2. ViewFS keeps teaching that watchers are advisory,
not current turn

ViewFS repeatedly insists that watchers,
notifications,
rebuild feeds,
and trusted badges stay separate from stronger authority or adoption truth.
That maps directly onto Helm’s new seam.
A person can be watching a slice,
subscribed to a change,
or eligible to review,
without that meaning it is actually their turn now.

**Take for Helm:**
`watching`, `eligible`, and `act next` should not collapse.

## 3. Ward keeps teaching that receivers and watch duty are not the same as current reaction duty

Ward’s recent receiver / watch-duty / attenuation work keeps reinforcing a strong law:
there is a difference between someone who receives status,
someone who owns a watch,
and someone who must react to the current state under current footing.
That is exactly the law Helm now needs.
The next-actor rail should sit near owner chips,
ack rails,
and coverage lamps,
but should not be replaced by them.

**Take for Helm:**
receiver truth,
ack truth,
and current-turn truth are neighboring lanes,
not synonyms.

## 4. Harbor helps because risk ladders imply different turn shapes

Harbor keeps teaching that not every move needs the same sharpness.
That means Helm should resist one permanent review roster.
For low-risk inspect or brief posture,
no active turn may be needed.
For a publish-shaped move,
a small narrowed next-actor rail may matter.
For a stronger action,
non-self or staged next-turn pressure may become appropriate later.

**Take for Helm:**
turn-taking should increasingly follow action-fit and risk ladder,
not a single ambient governance story.

## 5. Schell keeps teaching review-again humility

Schell’s design pressure around checkpoint humility,
outcome witnesses,
and `edit and review again` fits the seam directly.
A changed proposal should be able to say:
- old discussion remains inspectable,
- current footing changed,
- this is the next person or role expected to look,
- and here is the exact packet they should inspect.

**Take for Helm:**
attention-turn chips should compose with review packets,
not replace them.

## 6. Foundry helps because nearby configuration and overlays do not decide current human turn

Foundry keeps warning that overlays,
config layers,
external checks,
and live instance posture are different truths.
That matters here because the shell should not infer the current reviewer or operator turn from whichever nearby overlay looks busiest.
Turn truth should be explicit.

**Take for Helm:**
never derive active-turn authority from incidental adjacency.

## Product judgment

The admitted next shell-wide ratchet is still **settlement witnesses + commit cards**.
That remains the right decision.

But the next adjacent cluster now looks worth naming explicitly:
- **attention-turn chips**
- **next-actor rails**
- and maybe later **reviewer-load hints**

Those objects would let Helm say something stronger than:
`someone should probably look at this.`

They could say:
- broad owner stays Maya,
- watch lease stays active,
- old review weakly carries notes and affected scope,
- current turn is now `recipe owner recheck`,
- backup turn is `downstream-use owner`,
- and no active turn should be shown once the request is satisfied or withdrawn.

## Laws Helm should keep learning from the past

1. **Owner is not next actor.**
2. **Subscriber is not next actor.**
3. **Acked is not next actor.**
4. **Coverage exists even when no active turn exists.**
5. **Old review residue is not a current request.**
6. **Current turn should stay human-scale and shell-owned, not become a workflow empire.**

## Best bounded take now

Warm **attention-turn chips** and **next-actor rails** beside the already-warmed carry-forward rails and review packets.
Keep them tiny.
Keep them current-footing-bound.
Keep them separate from owners,
watchers,
acknowledgers,
and broad eligibility.
