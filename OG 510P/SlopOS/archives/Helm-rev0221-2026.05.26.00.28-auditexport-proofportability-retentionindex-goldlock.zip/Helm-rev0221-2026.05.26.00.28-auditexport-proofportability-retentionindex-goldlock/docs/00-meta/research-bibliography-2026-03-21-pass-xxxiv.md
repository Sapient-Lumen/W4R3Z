# Research bibliography — 2026-03-21 — pass XXXIV

Primary outside references reviewed in this pass:

- Visual Studio Code — Profiles documentation
- Visual Studio Code — December 2025 (1.108) release notes
- Figma Help — Move published components
- Figma Help — Explore component properties
- Figma Help — What's new from Schema 2025
- Notion Developers — Update a data source
- Notion Developers — Programmatic workspace setup for public integrations
- Notion Developers — Authorization (template duplication during auth)
- Raycast Manual — Cloud Sync
- Raycast Manual — Shared Quicklinks
- Obsidian Help — How Obsidian stores data
- Warp Docs — Launch Configurations
- Warp Docs — URI Scheme
- PowerToys Command Palette — Dock docs and extension dock support docs
