# Helm: time markers + causal breadcrumbs — 2026-03-22

Purpose: name the next compact support move that now looks worth warming after the latest SlopOS reread and current-tool pass.

## Main idea

Helm now has:
- saved view objects,
- linked views,
- exact front-door handles,
- view subscriptions,
- glance derivations,
- watchpoints,
- patrol routes,
- evidence briefs,
- and response kits.

What is still missing is one shell-owned object for:
**bounded time-and-change witness.**

The right answer now looks like:
- keep the **saved view** as the durable exact source,
- let **watchpoints** say what state the shell has evaluated,
- let **evidence briefs** gather why the matter matters,
- let **response kits** gather what to do next,
- and add one explicit **timeline marker** for what changed, when, and with what exact source posture.

## 1. What a timeline marker is

A **timeline marker** is a shell-owned bounded time witness.

It may be:
- a point in time,
- or a time range.

It may point at:
- one exact saved view,
- one watchpoint,
- one effect receipt,
- one route witness,
- one evidence member,
- one response-kit output receipt,
- or one imported change/deploy/incident event.

It can carry:
- exact source ref
- exact time or time range
- type / tag / class
- optional short authored note
- provenance/authorship posture
- local-vs-wider scope posture
- exact jump-back-to-source
- optional nearby-correlation hint

It is stronger than a vague note pile because it keeps exact source,
exact time,
and exact scope together.
It is weaker than live truth because it does not prove current-live state,
and it definitely does not prove causation.

## 2. Why this now looks necessary

A **watchpoint** can say something is warning.
A **glance derivation** can show a tiny summary.
A **brief** can gather evidence.
A **response kit** can guide the next steps.

But Helm still needed a clean object for:
- "what changed nearby before this?"
- "which exact deploy / incident / feature-flag / operator note should I look at?"
- "is this a point event or a time range?"
- "is this marker local to this view/activity or wider than that?"
- "what exact source or receipt produced this marker?"

That is a real product gap.
Timeline markers fill it without forcing Helm into giant timeline religion,
giant event-bus ambition,
or causal overclaim.

## 3. What current tools taught this pass

The outside pattern is now specific enough to steal:
- Grafana validates query- or panel-linked event markers with tags and point/range posture.
- Datadog validates manual annotations that persist when a widget moves into a notebook.
- Honeycomb validates environment-wide versus dataset-local markers and explicit point/range marker fields.
- PagerDuty validates recent changes, explicit change-event details, recent-vs-relevant history, and visible correlation reasons.
- Atlassian validates mixed automatic/manual incident timelines.

The thing to steal is not “become Grafana + PagerDuty + Atlassian in one shell.”
It is:
**make time-and-change witness first-class, exact, bounded, source-visible, scope-visible, and clearly weaker than the source truth it annotates.**

## 4. What Helm should keep and reject

### Keep
- exact jump-back-to-source from every marker
- point versus range posture
- type/tag grouping
- local versus wider scope witness
- provenance/authorship posture
- recent-change correlation hints with explicit reasons
- historical-neighbor lanes that can sort recent versus relevant
- marker use inside watchpoints, briefs, response kits, Recall, and weak Overview cards

### Reject
- giant universal timeline ambition
- markers that silently become current-live proof
- markers that silently become causal proof
- hidden ingestion/event-bus folklore
- giant annotation graffiti across every surface
- imported/shared markers that silently adopt local authority

## 5. What now looks wise to pull the trigger on

### Pull the trigger now
- **timeline markers** as candidate shell objects

### Advance with them
- watchpoint → nearby markers
- evidence brief → marker member lists
- response kit → recent-change context lane
- Recall / Overview → tiny marker-derived breadcrumb strips
- imported/shared markers in restricted posture

### Keep warm
- reasoned recent-vs-relevant historical-neighbor lanes
- light machine help suggesting candidate markers or correlations
- exact “because this was surfaced” witness on marker suggestions

## 6. Why this could make Helm super awesome

This move gives Helm a better answer to:
**"what changed around this, and what should I inspect next?"**

A user could:
- see a watchpoint,
- open the nearby timeline markers,
- inspect one exact deploy marker,
- jump to the exact receipt or source view,
- add the marker to a brief,
- launch a response kit with the change context nearby,
- and later hand off the same bounded context without pretending the marker itself is verdict or live truth.

That is better than:
- generic recents,
- giant dashboards,
- or one giant timeline trying to be source, verdict, and memory all at once.

## Judgment

Helm still does not need another pillar.
It needs one more compact shell object.

The best next move now looks like:
- **timeline markers**
- plus **causal-breadcrumb posture** around exact time/range witness,
  source posture,
  scope posture,
  provenance,
  and honest non-causal humility

That gives Helm a much better time-and-change grammar without sacrificing the anti-folklore discipline it has been learning from SlopOS all along.
