# Research bibliography — 2026-03-23 pass CXVII

1. **Apple Spotlight actions and quick keys**
   - Why it mattered: strong evidence that the main doorway should stay typed, action-oriented, and promotable into faster repeat paths.
   - Helm pull: keep Omnibox action mode central while letting the strip stay the tiny always-near companion rather than the main command surface.

2. **Microsoft PowerToys Command Palette + Dock**
   - Why it mattered: one fast command layer plus one persistent edge toolbar is a useful “doorway plus tiny always-near face” pattern.
   - Helm pull: reality strips should stay tiny and instant, while Omnibox remains the deeper typed doorway.

3. **Apple Quick Look**
   - Why it mattered: weak preview remains the gold standard for inspect-before-commit delight.
   - Helm pull: any strip-adjacent quick act should preserve weak-first posture and open stronger surfaces when needed.

4. **Windows Click to Do + Recall**
   - Why it mattered: selection-scoped action and searchable continuity are useful, but giant memory still reads as warning as much as inspiration.
   - Helm pull: favor exact landmarks, postcards, and strip slots over screenshot-theater continuity.

5. **VS Code agents, Copilot CLI sessions, and Git worktrees**
   - Why it mattered: background help feels trustworthy when sessions stay isolated, visible, inspectable, and linked to explicit working trees.
   - Helm pull: session-attention embers should stay adjacent to current-live truth without impersonating it.

6. **Figma branching and merge review**
   - Why it mattered: exploratory work stays luxurious when it is clearly non-main until review and merge.
   - Helm pull: adoption and review should remain visibly stronger than strip-level attention cues.

7. **Obsidian Bookmarks + Workspaces**
   - Why it mattered: promoted handles and saved layouts make return-to-work pleasant without needing a giant dashboard object.
   - Helm pull: landmarks plus front doors plus tiny strip cues beat giant home religion.

8. **Raycast Quicklinks + Shared Quicklinks**
   - Why it mattered: intentional promoted links and team-shared quick access show how promotion beats recency.
   - Helm pull: landmarks should stay explicit, typed, and optionally shareable without becoming ambient authority.

9. **Notion Home + Command Search**
   - Why it mattered: Home assembles task and shortcut context while Command Search stays globally summonable.
   - Helm pull: keep Overview weak and assembled; keep command summon separate; let the strip be smaller still.
