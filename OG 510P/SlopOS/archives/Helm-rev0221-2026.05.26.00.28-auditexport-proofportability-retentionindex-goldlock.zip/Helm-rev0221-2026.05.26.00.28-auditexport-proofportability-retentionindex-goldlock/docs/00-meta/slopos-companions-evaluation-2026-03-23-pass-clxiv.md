# SlopOS companions evaluation — 2026-03-23 pass CLXIV

Question for this pass:
what do SlopOS and the companion cubes teach Helm once **footing marks** and typed **delta ladders** already exist?
What smaller next object helps the shell say when an earlier footing no longer survives exactly,
without freezing a giant sync or replay constitution?

## Main judgment

The companion family now points to one very specific answer:
**Helm should warm footing death cards and residue ladders.**

This is still not a new pillar.
It is a compact cross-pillar honesty seam for:
- exact death of prior footing,
- exact reset scope,
- weaker surviving residue,
- and typed next verbs.

## What SlopOS contributes

SlopOS remains the constitutional teacher,
not the noun donor.
The key take is still:
**reviewed or exact footing must not silently inherit later mutable truth.**

For Helm,
that means a dead footing card should never quietly remap an old reviewed footing onto a newer live basis.
The old footing can survive as evidence,
comparison source,
or audit residue,
but not as fresh authority.

SlopOS therefore mainly contributes three laws here:
1. exact footing is worth naming;
2. dead footing can remain useful evidence;
3. reset or re-acquire must be explicit when exact footing no longer holds.

## What Schell contributes

Schell is the clearest local teacher for this exact move.
Its recent work on **anchor death cards**,
**cursor expiry**,
and **reset-scope humility** says that a review watermark,
first-unseen anchor,
source cursor,
survival posture,
and death/reset receipt are different truths.

Helm should not import the terminal vocabulary wholesale,
but it should steal the law almost unchanged:
- survival posture is not the same as unread/change posture,
- dead anchors still leave residue,
- and the strongest honest next verb depends on the death cause.

## What ViewFS contributes

ViewFS keeps five or six token-like truths apart:
continuation cursor,
sync watermark,
live subscription,
rebuilt snapshot,
gap verdict,
and receipt/history.
That is nearly a direct precursor for Helm's return-loop grammar.

Helm should especially steal ViewFS's refusal to let one token answer:
- what page/change comes next,
- what point was processed through,
- whether follow is still live,
- what state is currently rendered,
- and what repair is needed.

In Helm terms,
a footing death card should sit beside,
not replace:
- footing mark,
- delta ladder,
- resumption brief,
- and gap verdict.

## What Ward contributes

Ward's recent read-cut / staleness-budget / ambiguity-window / revalidation-fence specimen sharpens the difference between:
- a coherent earlier observation,
- uncertainty near the edge of that observation,
- and a later stronger check required before high-risk consequence.

That is exactly why Helm should keep **residue ladders**.
The old footing may still be:
- good enough for orientation,
- good enough for compare,
- or good enough for historical explanation,
while still being too weak for stronger acts.

## What Steward contributes

Steward keeps snapshot,
observation cursor,
protective adaptation,
and typed repair pressure visibly smaller than giant policy state.
The relevant lesson for Helm is not brownout behavior itself.
It is that **protective response and next legal move should be specific**.

So when footing dies,
Helm should say something like:
- `history only`
- `rebuild same subject`
- `latest-only cursor`
- `continue as new`
- `refresh before act`

not one vague `recover` button.

## What Harbor contributes

Harbor keeps route,
landing,
audience,
and adoption truth separate.
For Helm,
that suggests that a dead footing card should never quietly widen audience or reveal.
A history-only residue should remain history-only,
not become a new live link or new reveal authority.

## What Foundry contributes

Foundry keeps runtime evidence,
discharge,
caveat,
and actor path small and explicit.
That makes it a good teacher for **what weaker residue still survives**.
If a footing died,
Helm should still be able to say whether what remains is:
- old generated output,
- compared basis,
- delivery proof,
- route proof,
- or historical transcript only.

## Companion synthesis

Together the family now suggests this compact shell grammar:

1. **footing mark** — what earlier footing counted.
2. **delta ladder** — what exact next round or reset path exists.
3. **footing death card** — whether the earlier footing still survives,
   and what killed it when it does not.
4. **residue ladder** — what weaker residue still survives,
   and what strength it still has.

That grammar is much better than adding another pillar,
and better than a giant replay or sync center.

## Best current local decision

Keep the seven pillars stable.
Keep **settlement witnesses + commit cards** admitted.
Keep **calibration witnesses / miss ledgers** warm.
Keep **bounded rehearsal**,
**landing**,
**aftermath**,
**resumption**,
**footing marks**,
and **delta ladders** as the current grammar.

And now warm one narrower next seam:
**footing death cards + residue ladders**.
