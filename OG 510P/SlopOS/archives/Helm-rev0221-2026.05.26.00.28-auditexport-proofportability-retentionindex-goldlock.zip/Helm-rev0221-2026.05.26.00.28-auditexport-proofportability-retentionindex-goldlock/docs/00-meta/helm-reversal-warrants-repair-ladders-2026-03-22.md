# Helm reversal warrants + repair ladders — 2026-03-22

Purpose: name the next compact shell move after effect receipts and slot verdict ledgers.

## Main idea

Helm likely now wants one shell-owned object for:

**what exact historical effect am I being asked to undo,
revert,
or compensate for now?**

That object should be a **reversal warrant**.

And because real recovery is rarely one all-or-nothing button,
Helm likely also wants one adjacent answer to:

**what is the smallest honest next recovery rung for this exact situation?**

That second surface should be a **repair ladder**.

## Why this matters now

Helm already has useful nearby objects:

- **effect receipts** — what exact effect happened
- **slot verdict ledgers** — what exact slots or parts landed,
  default-filled,
  rebounded,
  stayed pending,
  or were refused
- **action warrants** — what exact stronger act is being proposed
- **drift gates** — whether that proposal still matches reviewed mutable basis
- **claim envelopes** — what the result is actually claiming
- **reliance ladders** — the right next responsible move
- **current-live beacons** — what is actually live now

What Helm still lacks is a compact durable answer to:

- what exact effect a recovery move is bound to
- whether the recovery is true undo,
  compensating reverse,
  redo,
  rerun failed subset,
  replay on fresh basis,
  or hold
- whether the blast radius is local,
  shared,
  or cross-activity
- whether the original authority/basis still justifies the move
- and which exact next rungs remain safe after partial recovery

Without that,
Helm risks slipping back into:
- generic Undo that flatters itself as universal,
- Retry buttons that do not say what they are retrying,
- Restore verbs that hide blast radius,
- and repair theater that quietly becomes a second hidden workflow plane.

## What a reversal warrant is

A **reversal warrant** is the recovery-side sibling of an action warrant.
It is not a receipt,
not a magic undo button,
and not a giant rollback engine.
It is the shell-owned exact proposal object for one stronger reverse or compensating act.

A useful first reversal warrant would carry:
- one source effect receipt or exact historical act witness
- one reversal family such as undo / revert / compensating-apply / restore-before / revoke / reopen
- one exact reviewed basis relation:
  current-live,
  historical receipt,
  checkpoint,
  or slot ledger
- one blast-radius witness:
  local,
  activity-scoped,
  shared,
  published,
  or receiver-visible
- one drift relation that says whether the target stayed reversible,
  became partial,
  or now requires fresh review
- one next-step ladder:
  inspect,
  rehearse,
  apply reversal,
  open repair ladder,
  or hold

The point is not the noun.
The point is the law:

**reversal deserves exact proposal truth too.**

## What a repair ladder is doing here

A **repair ladder** is the bounded next-step sibling of a reversal warrant.
It exists because many aftermaths are not best handled by total undo.

A useful repair ladder would keep visibly different:
- undo exact effect
- redo exact effect
- rerun failed subset
- rerun one exact failed item
- replay original proposal on fresh reviewed basis
- reopen unresolved slots
- branch-and-fix instead
- hold / inspect / cite the current aftermath

That is how Helm can be stronger than today's common retry/restore affordances without turning into a giant incident manager.

## Relation to nearby Helm objects

### Not an effect receipt
An effect receipt is historical aftermath truth.
A reversal warrant is a new exact proposal about how to respond to that aftermath.

### Not a drift gate
A drift gate says whether the mutable basis still matches.
A reversal warrant says what exact reverse or compensating act is now being proposed.

### Not a slot verdict ledger
A slot verdict ledger explains partial outcomes.
A repair ladder chooses the smallest honest next recovery rung for those outcomes.

### Not a giant recovery pillar
Helm still does not need that.
This should remain a compact support grammar.

## Why this seems especially worth stealing

Current products are increasingly good at:
- preview before apply,
- explicit restore,
- non-destructive version history,
- exact rerun of failed subsets,
- and keeping some undo nearby.

They are still often weak at:
- exact proposal truth for reversal,
- blast-radius honesty on recovery,
- basis/authority truth for reruns,
- and keeping redo / rerun / replay / compensate / restore meaningfully distinct.

That is where Helm can be unusually good.

## Super-awesome moves this unlocks

### 1. Every strong act can grow a truthful recovery side
A receipt can point to one nearby reversal warrant or repair ladder,
instead of leaving the user with folklore like “I think I can undo this somehow.”

### 2. Partial failure gets a bounded humane response
Instead of vague retry,
Helm can say:
- these three slots landed,
- two stayed pending,
- one failed,
- rerun failed slots,
  reopen slot review,
  or reverse the entire effect.

### 3. Shared or published recovery can stay explicit
A reversal warrant can say when a restore or revert affects only you,
an activity,
a team surface,
or a published/shared receiver-visible thing.

### 4. AI-assisted shell actions become less scary
If AI can propose strong acts,
it should also be able to propose exact reversal or bounded repair on top of durable receipts.

## What not to steal

- do not promise universal undo
- do not let retry hide whether it is redo,
  replay,
  rerun subset,
  or compensating reverse
- do not let reversal quietly follow drift without fresh review
- do not let repair ladders impersonate current-live truth
- do not build a giant recovery bureaucracy before one tiny slice works

## Pull-the-trigger judgment

Still yes:
- **saved view objects**
- **checkpoint branches**

Now also worth defining as support contracts:
- **reversal warrants**
- **repair ladders**

If Helm gets this right,
it can feel safer than current review/apply systems not because it promises magic undo,
but because it stays exact about **what can still be reversed,
what only can be repaired,
and what now requires a fresh stronger act.**
