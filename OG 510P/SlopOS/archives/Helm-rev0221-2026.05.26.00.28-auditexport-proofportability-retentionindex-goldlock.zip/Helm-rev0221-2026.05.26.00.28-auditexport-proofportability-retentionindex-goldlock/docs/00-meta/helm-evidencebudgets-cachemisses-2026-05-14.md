# Helm evidence budgets and cache-miss honesty — 2026-05-14

## Headline

rev0190 moves Helm from **lawful transitions** to **evidence economics**.

rev0189 could prove that a button-to-target move was legal. rev0190 asks the next harder product question: what proof is the move spending, what proof is cheap to reuse, what proof has gone stale, and what miss reason must the user see when a shortcut cannot be honored?

## Pull-the-trigger decision

Admit `evidence_budget_entry` as a fixture-side proof object and add the first release-readiness evidence budget ledger.

Do not admit an evidence marketplace, workflow engine, semantic-layer product, storage backend, table format, or new pillar.

## Why now

Cards and transition contracts prevent static and dynamic truth collapse. They still leave one premium-product failure mode: the system may do the right thing but make it feel arbitrary or slow.

A great shell should be able to say:

- this view is cheap because it reuses a saved definition;
- this summary is instant but stale, so the promote button is refused;
- this recheck costs one provider call and earns a fresh basis;
- this promotion spends the fresh basis into a scoped receipt;
- this Recall row is cheap history and must not buy current truth.

That is evidence economics. It turns invisible waiting, disabled buttons, stale chips, and receipt copy into one explainable product grammar.

## Lessons we must learn from the past

1. **Cache hits are addictive.** If cached proof makes the product feel magical, teams will eventually spend it where it does not apply unless the miss reason is first-class.
2. **Freshness checks are product UX, not only data ops.** A stale asset is not a backend exception; it is a surface state with copy, a primary next verb, and a refusal reason.
3. **Attestation is evidence, not authority.** Signed or structured provenance says where something came from; local policy still decides whether it is enough.
4. **Branch/tag/snapshot names are cuts, not truth itself.** They are excellent handles as long as Helm does not promote them into current reality.
5. **Queues hide cost.** Review and merge queues feel like automation, but the honest move is staged consequence with explicit rechecks and removal/failure reasons.
6. **SlopOS is right about exact evidence.** Helm should steal the separation discipline, not the full OS-scale boundary family.
7. **The UI should explain denied reuse.** A disabled or missing button is not enough; users need the cache-miss / stale-basis / receipt-is-history reason.

## Nifty ideas worth stealing now

- from build systems: content/action-key style reuse and cache-miss explanations;
- from data orchestration: asset freshness, checks, and data-quality assertions as visible state;
- from software supply chain attestations: small subject-bound evidence objects with predicate type and scope;
- from table/lake versioning: named cuts, branches, tags, commits, and retention as handles rather than authority;
- from OpenLineage/OpenTelemetry: compact facets and carried context, not a global truth graph;
- from merge queues and triage inboxes: staged consequence, required rechecks, removal reasons, and accountable ownership;
- from ViewFS/Steward/Ward/Foundry/Harbor: cache, evidence, trust, serving lanes, and boundary crossings must stay separate.

## What rev0190 adds

- `schemas/evidence-budget-entry.schema.json`
- `fixtures/release-readiness/evidence-budget-ledger.json`
- `tools/check_evidence_budget_ledger.py`
- architecture notes for evidence budgets and cache-miss UX
- assurance invariants for evidence economics
- ADR 0025: evidence budgets before cost engine

## Product rule

A Helm surface may be fast because it reuses evidence. It may not be ambiguous about the exact evidence it reused, the gates it did not pay, or the miss reason that forces a slower move.

## High-value Helm move

Prototype an **evidence meter** beside the truth rail. Each row can show:

- reused proof;
- missing proof;
- cost class;
- cache key fields;
- stale/fresh/receipt-only state;
- why this button is cheap, expensive, refused, or recheck-gated.

This should not feel like compliance. It should feel like a cockpit instrument that explains why Helm is being careful and where the operator can pay for stronger truth.

