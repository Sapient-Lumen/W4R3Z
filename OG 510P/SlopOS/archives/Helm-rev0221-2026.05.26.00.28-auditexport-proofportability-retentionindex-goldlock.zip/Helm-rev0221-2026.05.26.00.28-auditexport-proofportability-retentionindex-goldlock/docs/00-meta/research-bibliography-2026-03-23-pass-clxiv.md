# Research bibliography — 2026-03-23 pass CLXIV

Official product and primary-source materials consulted for this pass:

- Google Calendar API — Synchronize resources efficiently
  - https://developers.google.com/workspace/calendar/api/guides/sync
- Google Calendar API — Events: list
  - https://developers.google.com/workspace/calendar/api/v3/reference/events/list
- Microsoft Graph — Use delta query to track changes in Microsoft Graph data
  - https://learn.microsoft.com/en-us/graph/delta-query-overview
- OneDrive API — Error responses
  - https://learn.microsoft.com/en-us/onedrive/developer/rest-api/concepts/errors?view=odsp-graph-online
- Dropbox Developers — Detecting Changes Guide
  - https://developers.dropbox.com/detecting-changes-guide
- Kubernetes Docs — API Concepts
  - https://kubernetes.io/docs/reference/using-api/api-concepts/
- Google Cloud Pub/Sub — Snapshot resource reference
  - https://docs.cloud.google.com/pubsub/docs/reference/rest/v1/Snapshot
- MongoDB Docs — Change Streams
  - https://www.mongodb.com/docs/manual/changestreams/
- Temporal Docs — Continue-As-New
  - https://docs.temporal.io/workflow-execution/continue-as-new
