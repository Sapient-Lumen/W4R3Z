# Helm entry kits + continuity postcards — 2026-03-23

Purpose: continue fleshing out Helm’s pillars by tightening the product answer to one real user need:
**“take me back to the thing I was doing”**
without lying about what Helm actually found.

## Main judgment

Helm should probably pull the trigger on a pair,
not a giant object:
- **activity entry kits** as saved front doors
- **continuity postcards** as compact return-truth cards

That pair is stronger than a generic workspace story and safer than full restore mythology.

## Why now

The internal cubes and outside products are lining up.
The pattern is consistent:
- saved launch structure is useful
- saved views are useful
- lightweight safe lanes are useful
- true reconnection can sometimes exist
- but users suffer when those things are presented as one undifferentiated “resume” promise

Helm already has many of the ingredients:
- current-live beacons
- saved views
- exact front-door handles
- glance windows
- compare / review / promote lanes
- binding witnesses
- activity scope witnesses
- continuity choice witnesses
- rehearsal cards

What it lacks is one humane **return grammar** that composes those ingredients.

## The split Helm should keep

### Activity entry kit = the saved door
The entry kit is the saved starter.
It should be able to carry:
- one preferred front door
- nearby attached saved views
- one optional triage lane
- one compare / changes path nearby
- profile / provider / space affinity hints when exact and useful
- current-live relation if one exists
- import / shared posture if it arrived from elsewhere

But it should stay weaker than live truth.
It points toward work.
It is not proof that the work is live.

### Continuity postcard = the answer about what relation exists now
The postcard is the compact explanation.
It should be able to say things like:
- **current-live**
- **exact attachable**
- **exact saved door**
- **saved launchable**
- **repaired return available**
- **historical only**
- **import / adoption needed**
- **permission or trust needed**
- **unavailable**

That is much more useful than a vague restore badge.

## What makes this awesome instead of bureaucratic

### 1. It reduces false hope
A user can tell whether Helm found:
- the actual live lane,
- the saved way in,
- a repair path,
- or only history.

That honesty will feel premium because the alternative in most tools is flattering ambiguity.

### 2. It makes saved views even more valuable
Saved views stop being isolated nice-to-haves.
They become attached surfaces that an entry kit can open immediately,
compare against,
or promote from.

### 3. It gives Recall a humane core
Recall should not only say “here is something from before.”
It should help the user understand whether that something is:
- current,
- restorable,
- reattachable,
- launchable,
- or merely evidentiary.

### 4. It gives Omnibox and Object Browser stronger verbs
A summon result can now offer:
- inspect postcard
- open saved door
- attach to live target
- compare current vs remembered
- rehearse repair
- relaunch fresh
- adopt imported door

That is a much better action grammar than plain open.

### 5. It avoids giant workspace religion
The pair is compositional.
It does not require Helm to invent one mega-object that owns:
- layout
- views
- profiles
- history
- live targets
- sync
- and collaboration

## What Helm should steal from outside products

Steal:
- PowerToys / Warp style launch bundles
- GitHub / Obsidian style saved views
- VS Code style profile-associated doors and import preview
- VS Code Web style lightweight weak lanes
- Figma style compare / review / promote around stronger landings
- Linear style one obvious triage lane near incoming work

Do not steal:
- full-session resurrection mythology as the default story
- hidden automatic profile switching
- giant workspace objects that mean everything
- sync-first remembered-state sprawl
- dashboard pages that quietly become authority planes

## What to prove next

### Small specimen A
One activity entry kit that can:
- open its preferred saved view
- show a postcard with `current-live` versus `saved-launchable`
- and branch to attach / relaunch / fresh start

### Small specimen B
One imported/shared entry kit that lands restricted,
shows `import-adoption-needed`,
and lets the receiver preview,
rebind,
and adopt only selected attached surfaces.

### Small specimen C
One repaired return path that says:
- expected target not found
- near match found with one widened axis
- inspect basis
- rehearse repair
- proceed knowingly or fresh start

## Pillar effect

This does not add a pillar.
It sharpens several existing ones at once:
- **Tiling Shell** gets a better return-to-work story
- **Omnibox** gets stronger summon verbs
- **Object Browser** gets truer saved-door objects
- **Operations Center** gets a better explanation surface
- **Recall** gets an honest continuity grammar
- **Exchange** gets clearer import/adoption posture
- **Desktop Flow** gets better starter and repair lanes

## Closing judgment

The next super-awesome Helm move is not more archive machinery.
It is a humane return grammar:
**entry kits for saved doors,
continuity postcards for return truth,
and current-live beacons remaining the stronger now.**
