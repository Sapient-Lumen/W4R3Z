# Helm access verdicts + least-widening previews — 2026-03-22

Purpose: name the next compact support moves that look worth proving after budgets,
leases,
renewal rails,
change cursors,
retry keys,
and teardown rails without adding another pillar.

## Main idea

Helm already has good objects for:
- what may later be asked for,
- what is borrowed now,
- how old mutable state is,
- how same-act retries behave,
- and whether teardown is still pending.

What still feels missing is a calmer answer to one everyday shell question:

**why exactly is this stronger act blocked,
and what is the smallest honest next delta?**

The next compact answer looks like:
- **access verdict cards**
- and **least-widening previews**.

## 1. Access verdict cards

An **access verdict card** is a shell-owned bounded explanation object over one exact requested act.

It should be able to say:
- exact subject,
- exact requested act,
- lane or holder posture,
- current verdict:
  - allowed,
  - denied,
  - restricted,
  - stale,
  - missing-live-lease,
  - hidden-policy,
  - unsupported,
  - or unknown,
- determining blocker when known,
- visibility gaps when not all policy or source facts are inspectable,
- and nearby safe inspect paths.

### Why it is worth stealing

People should not have to widen authority blindly just to learn why something failed.
The shell should be able to answer that question directly.

### What it should not do

- not become authority itself
- not flatten simulated results into live results
- not become a giant policy center
- not pretend it knows the blocker when visibility is incomplete

## 2. Least-widening previews

A **least-widening preview** is a shell-owned counterfactual comparison object next to a blocked or gated stronger act.

It should let Helm compare plausible next deltas such as:
- inspect only,
- current-only grant,
- exact-subject grant,
- isolated-lane execution,
- activity-scoped widening,
- guarded-link rather than public,
- or broader persistent scope.

It should also be able to say:
- which candidate would likely admit the act,
- which candidates remain blocked,
- which ones cannot be simulated honestly,
- and which candidate is the narrowest viable move.

### Why it is worth stealing

When blocked-state explanation is absent,
people ask for too much power.
A least-widening preview lets Helm stay generous **without** becoming mushy.
It can offer the smaller path before the broader path.

### What it should not do

- not auto-grant the winning delta
- not hide the difference between live and simulated admission
- not promise exact success when the preview is only policy-side
- not bypass basis drift,
  trust,
  or lane restrictions just because the preview looks positive

## 3. Why these two belong together

They protect opposite sides of the same frustrating edge:
- **access verdict card** explains the current refusal or restriction truth
- **least-widening preview** explains the smallest honest move that could change that truth

Together they make “no” much more useful.

## 4. Best first proofs

### Pull the trigger soon
- warm **access verdict cards** as a candidate shell object
- warm **least-widening previews** as a candidate shell object

### Great first demos
- one blocked publish or apply act with a verdict card that names policy,
  lane,
  or stale-basis blocker precedence
- one least-widening preview comparing exact-subject,
  current-only,
  isolated-lane,
  and persistent widening
- one hidden-policy case where the card admits incomplete visibility instead of bluffing
- one restricted-first imported surface where inspect remains available while stronger execution is blocked

## 5. Pillar pressure

- **Omnibox** benefits from exact blocked-action explanation and narrow alternative rungs next to stronger quick actions
- **Object Browser** benefits from clearer why-not posture on share,
  publish,
  reveal,
  or adopt paths
- **Operations Center** benefits from durable blocked/gated rows that are more informative than generic failure state
- **Desktop Flow** benefits from policy-aware dry-run and lane-aware least-widening choices before stronger automation
- **Recall** benefits from explaining why a remembered handle is inspectable,
  stale,
  or blocked from stronger reuse
- **Exchange** benefits from choosing guarded-link,
  current-only,
  or exact-subject routes before broad reveal
- **Terminal/Capshell** benefits from explicit why-not and least-widening posture instead of budget-missing folklore or broad fallback asks

## Judgment

Helm still does not need another pillar.
It needs a calmer answer to blocked stronger acts.
The right answer now looks like:
- **access verdict cards** for exact refusal/restriction truth
- **least-widening previews** for smallest-honest-next-delta comparison

That pair looks like one of the best remaining ways to make Helm feel both stricter and more humane. 
