# Helm resource shelves — 2026-03-22

Purpose: name the next compact shell object that now looks worth defining under activity spines without adding a new pillar.

## Main idea

Helm likely wants a **resource shelf**.

A resource shelf is a shell-owned curated grouped resource surface.
It can gather:
- links
- files
- messages
- docs
- canvases/lists-like resources
- saved view objects
- checkpoints
- and other exact references

The shelf is not the activity spine.
The shelf is not the current-live lane.
The shelf is not a command dock.
The shelf is not a review ticket.

The shelf is the **curated resource layer** around a piece of work.

## Why this seems timely now

The archive already has several strong objects:
- activity spines
- saved view objects
- checkpoint branches
- view decks
- command docks
- review tickets

But current tools keep showing one more real need:
people want a compact place to gather the important resources for a task,
project,
or scoped work frame.

Today that often appears as:
- stacks
- folders
- bookmarks
- tab groups
- tab headers
- or collections

The opportunity for Helm is to keep the useful part while refusing the fake continuity part.

## What to keep

### 1. Exact grouped resources
A shelf should gather exact members,
not vague vibes.
It should be able to say what each thing is.

### 2. Deep-linkable members
Each member should be linkable,
revealable,
or exact-openable where the substrate supports it.

### 3. Current versus all export
If a shelf contains sections or a selected member,
Helm should make it easy to share:
- this exact member
- this section
- or the whole shelf

### 4. Explicit share/posture rungs
A shelf may be:
- personal
- shared
- published
- or imported in a weaker posture

That ladder should stay explicit.

### 5. Shelf-inside-spine composition
A resource shelf can live inside an activity spine.
That gives Helm a nice split:
- the spine frames the work
- the shelf curates the resources

### 6. Member-type truth
A message should remain a message.
A view should remain a view.
A checkpoint should remain a checkpoint.
A shelf should not flatten everything into one generic tile blob.

## What not to keep

### 1. Auto-capture from recents/open
Do not let every opened or recent thing silently join the shelf.
Membership should be authored.

### 2. Shelf-as-live-workspace
Do not let the shelf pretend that grouped resources equal current live state.

### 3. Shelf-as-permission-engine
Sharing a shelf should not quietly change who can open every member unless that stronger act is made explicit.

### 4. Shelf-as-note/blob ontology
Do not make the shelf a giant mixed notes,
annotation,
collaboration,
sync,
and live-presence constitution.

## Why this can make Helm super awesome

Because it gives Helm a compact,
daily-useful object that sits between random bookmarks and giant workspace mythology.

A great shelf could make it feel natural to:
- gather the right links,
  docs,
  messages,
  views,
  and checkpoints for one task
- keep one favorite front door
- preview members quickly
- share or publish the grouped arrangement explicitly
- export current versus all
- and move between Omnibox,
  Recall,
  Object Browser,
  Exchange,
  and activity spines without losing orientation

That is a lot of product leverage for one small support object.

## The separation that matters

The archive now has a cleaner stack:

- **activity spine** — work frame
- **resource shelf** — curated grouped resources
- **view deck** — grouped explicit views
- **command dock** — grouped actions
- **review ticket** — stable review slice
- **current-live beacon** — actual live-lane reentry cue

That separation is one of the best ways to keep Helm honest while still making it feel rich.

## Pull-the-trigger judgment

Still no new pillar.

But it now looks wise to define one support contract:

**resource shelf** — a shell-owned curated grouped-resource object that stays weaker than live truth,
stronger than random bookmarks,
and honest about member type,
share posture,
and current-versus-all export.
