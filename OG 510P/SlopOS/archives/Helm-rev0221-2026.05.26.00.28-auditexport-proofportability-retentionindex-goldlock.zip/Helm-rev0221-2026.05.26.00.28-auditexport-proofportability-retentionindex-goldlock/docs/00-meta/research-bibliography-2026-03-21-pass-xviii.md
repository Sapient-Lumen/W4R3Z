# Research bibliography — 2026-03-21 pass XVIII

Official/public sources consulted in this pass:

- VS Code Release Notes — December 2025 / Copy Breadcrumbs Path  
  https://code.visualstudio.com/updates/v1_108
- VS Code Docs — Revert changes with checkpoints and editing requests  
  https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- VS Code Docs — Manage chat sessions  
  https://code.visualstudio.com/docs/copilot/chat/chat-sessions
- VS Code Docs — Using agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code Docs — Copilot CLI sessions in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/copilot-cli
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- Apple Support — Take actions and shortcuts in Spotlight on Mac  
  https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac
- Apple Support — Spotlight keyboard shortcuts on Mac  
  https://support.apple.com/guide/mac-help/spotlight-keyboard-shortcuts-mh26783/mac
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Apple Support — Use the Preview pane in the Finder on Mac  
  https://support.apple.com/guide/mac-help/use-the-preview-pane-in-the-finder-on-mac-mchl1e4644c2/mac
- Apple Support — Perform quick actions in the Finder on Mac  
  https://support.apple.com/guide/mac-help/perform-quick-actions-in-the-finder-on-mac-mchl97ff9142/mac
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Dynamic Placeholders  
  https://manual.raycast.com/dynamic-placeholders
- Raycast Manual — Deeplinks  
  https://manual.raycast.com/deeplinks
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- Arc Help Center — Peek: Preview Sites From Pinned Tabs  
  https://resources.arc.net/hc/en-us/articles/19335302900887-Peek-Preview-Sites-From-Pinned-Tabs
- Arc Help Center — Little Arc: Quick Lookups & Instant Triaging  
  https://resources.arc.net/hc/en-us/articles/19235387524503-Little-Arc-Quick-Lookups-Instant-Triaging
- Obsidian Help — Introduction to Bases  
  https://help.obsidian.md/bases
- Obsidian Help — Views  
  https://help.obsidian.md/bases/views
- Obsidian Help — How Obsidian stores data  
  https://help.obsidian.md/data-storage
- Obsidian Help — File recovery  
  https://help.obsidian.md/plugins/file-recovery
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — Adding Dock support to your extension  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
