# SlopOS + companion-cube evaluation — 2026-03-23 — pass CVII

## Frame for this pass

This pass asks a narrower Exchange question than the previous one.
Helm now has:
- transfer offers
- take cards
- receiver-fit posture
- gesture-runway / helper-escort support for stronger routes
- and generic effect receipts

What still wants a first-class shell object is the sentence:

**the user chose this exact receiver / route,
by this exact system lane,
for this exact offered material,
in this exact representation / operation posture,
but that still is not the same as durable effect truth.**

That missing middle now looks like a **route witness**.

## What SlopOS keeps teaching

### 1. Imported completion must stay provider-local until the boundary truly earns promotion
The `mcp-completion-import-boundary` family still matters because it keeps warning against a classic shell mistake:
importing provider-local selection or completion convenience and then pretending it became a portable chooser truth.

Helm should learn the same lesson for Exchange routes.
A route witness should record:
- the exact chosen route or receiver,
- the exact chooser or target family,
- and the exact local boundary that admitted the handoff,

without pretending that the downstream provider's own completion or finishing semantics became shell-owned live truth.

### 2. Session selection and launch admission are different seams
SlopOS keeps separating:
- request,
- selection,
- admission,
- and later observed state.

That separation is directly reusable.
For Helm Exchange,
**chosen receiver** is not the same thing as:
- route fit,
- route admission,
- performed effect,
- or current live state of the receiver.

### 3. Shell-owned truth should stay compact and exact
The best SlopOS move is still seam discipline.
It does not need a giant universal route ontology to be useful.
That argues for one modest witness object rather than a large share subsystem.

## What ViewFS keeps teaching

### 1. Requests, candidates, selections, imports, and results are different strengths
ViewFS already keeps saying this in different local forms:
- requests-candidates-selections-and-imports
- route-plans-approval-checkpoints-and-result-cards
- handles-refs-and-receipts
- imports-exports-transfers-and-promised-files

That stack is basically a proof that Helm should not collapse:
- a remembered route,
- a chosen route,
- a started import,
- and a landed result card.

### 2. Route plans are weaker than route witnesses
A ViewFS route-plan card is still pre-act explanatory truth.
Helm's route witness should be stronger than that:
**the shell should know which exact route or target the user actually picked.**

But it should stay weaker than the result card / effect receipt.
That distinction now feels worth promoting in Helm directly.

### 3. Result cards remain aftermath truth
ViewFS is a useful reminder not to overburden the route witness.
The route witness should say what was chosen and admitted.
The result card / effect receipt should say what actually happened after the route took over.

## What Schell keeps teaching

### 1. Chooser luxury is great as long as it stays weaker than shell truth
`chooser-witnesses-ranked-recall-and-preview-humility.md` is exactly the warning Helm still needs.
Ranking,
preview,
and convenience can all feel magical,
but the exact chosen action still needs its own witness.

A Helm Exchange chooser can be brilliant.
It still needs a compact route witness that says:
- what was picked,
- from what candidate source,
- under what ranking or prewarm posture,
- and what Enter / click / tap actually committed.

### 2. Handoff admitted is a real seam
`handoff-ladders-observation-truth-and-completion-humility.md` is probably the best direct companion lesson for this pass.
Proposal,
review,
handoff admission,
observed target state,
and completion are not one truth.

That is almost a ready-made law for Helm Exchange.
A route witness should live at the handoff seam,
not masquerade as full completion or receiver effect.

### 3. Share and drop witnesses already imply route witnesses
Schell's share / drop / clipboard witness docs all keep the same moral:
copy offers,
file offers,
and public-share posture should not flatten into one generic success story.

Helm can now reuse that directly.

## What Steward keeps teaching

### 1. Compact status channels beat folklore
Steward's emphasis on label surfaces,
trusted chrome,
and compact accountable status is a useful design style for Helm.
A route witness should be shell-owned,
small,
and visible in trusted chrome rather than being buried in app-local history.

### 2. Activation receipts are not the whole story
Steward keeps separate:
- activation,
- label/status,
- current service state,
- and later receipts.

That supports the same Helm law:
selected route,
admitted route,
completed handoff,
and durable effect should remain separate named truths.

## Lessons Helm must keep learning from the past

1. **Do not let chooser magic become authority.**
2. **Do not let route selection impersonate finished effect.**
3. **Do not let saved routes become invisible defaults.**
4. **Do not let stale direct targets keep the prestige of fresh ones.**
5. **Do not freeze one universal share / clipboard / handoff backend too early.**

## What looks worth pulling forward now

Helm is probably ready to warm one more Exchange specimen:

**route witnesses** — compact shell-owned chosen-route objects that preserve:
- exact transfer offer,
- exact selected receiver / target,
- chooser path or route family,
- chosen representation and operation posture,
- whether the route was manual,
  prewarmed,
  quick-targeted,
  remembered,
  or helper-suggested,
- and what aftermath semantics are still pending.

That looks like the smallest honest next move after transfer offers and take cards.
