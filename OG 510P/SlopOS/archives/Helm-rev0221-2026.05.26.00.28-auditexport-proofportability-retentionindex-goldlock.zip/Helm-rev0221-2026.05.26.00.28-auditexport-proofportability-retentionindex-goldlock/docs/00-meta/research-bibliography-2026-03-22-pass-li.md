# Research bibliography — 2026-03-22 — pass LI

1. **GitHub Docs — About GitHub Copilot coding agent**
   - source: https://docs.github.com/en/copilot/concepts/agents/coding-agent/about-coding-agent
   - used for: human review requirements, default workflow approval gate, and the rule that the requesting developer cannot approve the PR

2. **GitHub Docs — Configuring settings for GitHub Copilot coding agent**
   - source: https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/configuring-agent-settings
   - used for: explicit warning that skipping workflow approval can expose secrets or write access

3. **GitHub Docs — Control deployments / required reviews**
   - source: https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/control-deployments
   - used for: waiting approvals and automatic failure after 30 days

4. **GitHub Docs — Manage environments**
   - source: https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments
   - used for: required reviewers, prevent self-review, and wait-timer configuration

5. **VS Code docs — Use tools with agents**
   - source: https://code.visualstudio.com/docs/copilot/agents/agent-tools
   - used for: Default Approvals vs Bypass Approvals vs Autopilot

6. **VS Code release notes 1.111**
   - source: https://code.visualstudio.com/updates/v1_111
   - used for: permission level applies only to the current session and the warning about bypassing approval prompts

7. **VS Code docs — Copilot CLI sessions**
   - source: https://code.visualstudio.com/docs/copilot/agents/copilot-cli
   - used for: worktree isolation auto-bypassing approval prompts

8. **Chrome for Developers — One-time permissions**
   - source: https://developer.chrome.com/blog/one-time-permissions
   - used for: “Allow this time” and expiry after active interaction stops

9. **Chrome for Developers — activeTab permission**
   - source: https://developer.chrome.com/docs/extensions/develop/concepts/activeTab
   - used for: temporary page access tied to explicit invocation and revoked on navigation/close

10. **Chrome for Developers — Persistent permissions for the File System Access API**
    - source: https://developer.chrome.com/blog/persistent-permissions-for-the-file-system-access-api
    - used for: session-shaped access vs stronger persistent access

11. **Android Developers — Permissions updates in Android 11**
    - source: https://developer.android.com/about/versions/11/privacy/permissions
    - used for: “Only this time” temporary permission and auto-reset for unused apps

12. **OpenAI Help — Projects in ChatGPT**
    - source: https://help.openai.com/en/articles/10169521-projects-in-chatgpt
    - used for: app-link sources and explicit approve-access step

13. **OpenAI Help — ChatGPT Enterprise & Edu release notes**
    - source: https://help.openai.com/en/articles/10128477-chatgpt-enterprise-edu-release-notes
    - used for: current projects Chats/Sources split

14. **Google Docs Editors Help — Collaborate with Gemini in Google Sheets**
    - source: https://support.google.com/docs/answer/14218565
    - used for: Action preview card plus nearby Settings and Undo after Apply
