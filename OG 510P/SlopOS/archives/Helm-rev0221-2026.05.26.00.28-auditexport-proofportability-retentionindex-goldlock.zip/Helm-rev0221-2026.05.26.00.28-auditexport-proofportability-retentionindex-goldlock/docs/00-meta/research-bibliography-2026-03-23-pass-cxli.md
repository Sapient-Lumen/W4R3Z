# Research bibliography — 2026-03-23 pass CXLI

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-LAKEFS-BRANCH-DIFF-2026 | https://docs.lakefs.io/v1.74/integrations/python-versioning-branches/ | branch/commit diff plus merge/cherry-pick/revert is a strong precedent for explicit compare lanes and reversible trial posture |
| REF-DBT-DEFER-2026B | https://docs.getdbt.com/reference/node-selection/defer | separate logical-state comparison from applied-state deferral is a strong precedent for replaying against alternate footing honestly |
| REF-DBT-CLONE-2026B | https://docs.getdbt.com/reference/commands/clone | zero-copy clone or pointer-view compare environments are a strong precedent for safe prod-like compare lanes |
| REF-DBT-STATE-2026B | https://docs.getdbt.com/reference/node-selection/state-selection | compare current project state against manifest state is a strong precedent for exact from/to basis comparison |
| REF-DVC-EXPERIMENTS-2026 | https://doc.dvc.org/user-guide/experiment-management | tracking params, metrics, and plots is a good precedent for bounded replay evidence |
| REF-DVC-METRICS-DIFF-2026 | https://doc.dvc.org/command-reference/metrics/diff | compact delta cards over changed metrics are a strong precedent for Helm variance cards |
| REF-OBSERVABLE-HISTORY-2026 | https://observablehq.com/documentation/notebooks/history | exact historical reopen posture is a strong precedent for Replay and Recall honesty |
| REF-OBSERVABLE-FORKING-2026 | https://observablehq.com/documentation/notebooks/forking | forks as explicit copies are a strong precedent for compare-lane and draft/live separation |
| REF-OBSERVABLE-VERSION-PINNING-2026 | https://observablehq.com/documentation/embeds/advanced | URL-level version pinning is a strong precedent for exact pinned-share posture |
| REF-HEX-HISTORY-VERSIONS-2026B | https://learn.hex.tech/docs/explore-data/projects/history-and-versions | timeline-visible versions are a strong precedent for exact replay basis and old-version reopen truth |
| REF-HEX-PUBLISH-SHARE-2026B | https://learn.hex.tech/docs/share-insights/apps/publish-and-share-apps | publish preview diff plus published-default/current-input/collaborative-session links are strong precedents for pinned-share posture |
| REF-DAGSTER-ASSET-VERSIONING-2026 | https://docs.dagster.io/guides/build/assets/asset-versioning-and-caching | code/data-version reasoning is a strong precedent for basis-aware rerun prediction |
| REF-DAGSTER-ASSET-SELECTION-2026B | https://docs.dagster.io/guides/build/assets/asset-selection-syntax | precise path-based selection is a good precedent for exact replay slice selection |
