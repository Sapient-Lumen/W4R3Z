# Research bibliography — 2026-05-15 — pass CLXXXIX

- Git rerere documentation — https://git-scm.com/docs/git-rerere
- Sentry Fingerprint Rules — https://docs.sentry.io/concepts/data-management/event-grouping/fingerprint-rules/
- OpenFeature — https://openfeature.dev/
- Open Policy Agent decision logs — https://www.openpolicyagent.org/docs/management-decision-logs
- dbt data tests — https://docs.getdbt.com/docs/build/data-tests
- Feast feature views and schema validation — https://docs.feast.dev/getting-started/concepts/feature-view
- Evidently Data Drift preset — https://docs.evidentlyai.com/metrics/preset_data_drift
