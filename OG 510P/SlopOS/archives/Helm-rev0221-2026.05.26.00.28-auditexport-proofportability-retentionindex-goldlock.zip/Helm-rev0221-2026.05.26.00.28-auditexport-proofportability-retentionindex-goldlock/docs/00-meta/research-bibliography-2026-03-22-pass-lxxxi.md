# Research bibliography — 2026-03-22 — pass LXXXI

1. **Vercel Docs — Deploying to Vercel**
   - source: https://vercel.com/docs/deployments
   - used for: deployment objects with unique URLs and the general preview-deployment model

2. **Vercel Docs — Promoting a preview deployment to production**
   - source: https://vercel.com/docs/deployments/promote-preview-to-production
   - used for: explicit preview → production promotion posture

3. **Vercel Docs — Sharing a Preview Deployment**
   - source: https://vercel.com/docs/deployments/sharing-deployments
   - used for: branch links versus commit links and the floating-versus-pinned handle distinction

4. **Vercel Docs — Accessing Deployments through Generated URLs**
   - source: https://vercel.com/docs/deployments/generated-urls
   - used for: commit URL versus branch URL access posture

5. **VS Code Docs — Git Branches and Worktrees in VS Code**
   - source: https://code.visualstudio.com/docs/sourcecontrol/branches-worktrees
   - used for: compare with workspace and migrate-from-worktree posture

6. **Git Docs — git-worktree**
   - source: https://git-scm.com/docs/git-worktree
   - used for: multiple working trees attached to one repository and exact side-lane relation

7. **Figma Help — Guide to branching**
   - source: https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
   - used for: branch review, side-by-side or overlay compare, and explicit approve/merge posture

8. **Google Docs Editors Help — Suggest edits in Google Docs**
   - source: https://support.google.com/docs/answer/6033474?co=GENIE.Platform%3DDesktop&hl=en
   - used for: accept-or-reject suggestion posture and deferred edit truth

9. **Kubernetes Docs — Server-Side Apply**
   - source: https://kubernetes.io/docs/reference/using-api/server-side-apply/
   - used for: managed fields, explicit conflicts, and forced ownership transfer on conflict

10. **Android Developers — Permissions updates in Android 11**
   - source: https://developer.android.com/about/versions/11/privacy/permissions
   - used for: one-time permissions and auto-reset pressure on temporary exact grants

11. **Android Developers — Grant partial access to photos and videos**
   - source: https://developer.android.com/about/versions/14/changes/partial-photo-video-access
   - used for: Selected Photos Access as exact-subject permission posture

12. **Apple Developer Documentation — Enabling Security-Scoped Bookmark and URL Access**
   - source: https://developer.apple.com/documentation/professional-video-applications/enabling-security-scoped-bookmark-and-url-access
   - used for: persistent access to specific file-system resources instead of broad ambient reach
