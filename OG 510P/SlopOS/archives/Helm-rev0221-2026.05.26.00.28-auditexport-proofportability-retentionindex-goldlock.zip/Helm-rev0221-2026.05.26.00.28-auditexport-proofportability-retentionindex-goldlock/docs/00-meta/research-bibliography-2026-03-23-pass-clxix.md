# Research bibliography — 2026-03-23 — pass CLXIX

| Ref | Source | Used for |
| --- | --- | --- |
| REF-COSMOS-SESSION-CONSISTENCY-2026H | https://learn.microsoft.com/en-us/dotnet/api/microsoft.azure.cosmos.consistencylevel?view=azure-dotnet | session consistency guarantees: monotonic reads, monotonic writes, and read-your-writes |
| REF-MONGODB-CAUSAL-SESSIONS-2026H | https://www.mongodb.com/docs/drivers/node/v6.x/crud/transactions/ | causal consistency guarantees and session/thread requirements |
| REF-COUCHBASE-QUERY-CONSISTENCY-2026H | https://docs.couchbase.com/cloud/n1ql/n1ql-manage/query-settings.html | `not_bounded` vs `at_plus` vs `request_plus`, lower-bound vectors, and RYOW |
| REF-SPANNER-EXTERNAL-CONSISTENCY-2026H | https://docs.cloud.google.com/spanner/docs/true-time-external-consistency | strongest ordered read/transaction class and observable commit ordering |
