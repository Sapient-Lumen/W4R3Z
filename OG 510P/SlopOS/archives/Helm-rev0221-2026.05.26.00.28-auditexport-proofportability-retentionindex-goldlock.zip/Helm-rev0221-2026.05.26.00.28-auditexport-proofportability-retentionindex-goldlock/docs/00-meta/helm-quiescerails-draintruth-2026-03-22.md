# Helm: quiesce rails + drain truth — 2026-03-22

## Headline

Helm should get **better at graceful maintenance posture, not broader at lifecycle mythology**.
The next compact move worth warming is:

- **quiesce rails**
- **drain witnesses**

## Why now

Helm already has:
- brake rails for exact hot-now control,
- teardown rails for requested-versus-complete removal,
- condition strips for compact multi-axis status,
- freshness-horizon chips for live-claim decay,
- and effect receipts for exact historical aftermath.

What it still lacks is one clean answer to:

- **how do I stop admitting new work without lying that the thing is stopped?**
- **how do I let current work drain or cancel without hiding the phase?**
- **how do I show whether a later force cut-through happened?**

Without that,
Helm risks three familiar lies:
- “paused” meaning five different things,
- “quiet” meaning nothing current is happening,
- and “stopped” meaning graceful cleanup definitely completed.

## The good pattern

### Quiesce rails

A quiesce rail should carry:
- one exact subject or cohort witness
- one exact mode (`drain` or `cancel`)
- one stated reason
- one started-at time
- one optional grace budget
- one visible no-new-work policy
- one resume path
- one separate escalate / cut-through path

### Drain witnesses

A drain witness should carry:
- one exact owner or cohort witness
- one live-confirmed or historical-only posture
- one phase such as
  - running
  - quiescing-drain
  - quiescing-cancel
  - quiescent
  - resumed
  - cut-through
  - completed-historical
- one exact in-flight count or exact blocker list when available
- one last-confirmed time and expiry horizon
- one pointer to the ending receipt when the story finishes

## What to keep from older inspirations

Keep:
- Kubernetes-style no-new-work-before-maintenance posture
- HAProxy-style ready / drain / maintenance distinctions
- portal-style narrow inhibition handles with user-visible reasons
- Temporal-style cancel-versus-terminate separation
- Spotlight-style pause-live-updates-while-inspecting posture

Peel away:
- giant freeze graphs
- hidden queue-behind-boundary semantics
- universal stop models
- fake guarantees that quiescent means exportable or fully cleaned up
- one vague stop button that also means detach / forget / revoke / unshare

## Why this makes Helm more awesome

This move upgrades several existing Helm surfaces:

- **Operations Center** can say draining versus quiescent versus cut-through instead of one flattened hold badge.
- **Object Browser** can temporarily freeze live-derived movement while the operator inspects a moving set.
- **Exchange** can keep “stop taking new arrivals” distinct from “revoke existing reveal”.
- **Recall** can explain whether a calm-looking surface is truly quiescent, merely historical, or only last-confirmed.
- **Trusted chrome** can make maintenance lanes humane without turning them into giant infrastructure consoles.

## Pull-the-trigger judgment

This is worth warming now.
Not as a new pillar,
and not as a universal orchestration engine,
but as one more compact shell law:

**graceful maintenance posture should be explicit,
live,
and phase-honest.**
