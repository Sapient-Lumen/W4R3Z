# Helm state tuples + live-until — 2026-03-23

Purpose: continue fleshing out Helm's pillars by tightening one shell-wide law that now looks increasingly ready:
**how should Helm keep compact state surfaces truthful once many different shell objects start looking “live enough” at a glance?**

## Main judgment

Helm is likely ready to warm one cross-cutting answer:
- a shell-owned **state tuple** law
- with one explicit **live-until** / freshness axis

This is not a new pillar.
It is a compact grammar that many existing Helm moves now need.

## Why now

Helm already has many good compact support objects:
- condition strips
- freshness-horizon chips
- observed-basis chips
- current-live beacons
- continuity postcards
- reality strips
- saved views
- watchpoints
- drain witnesses
- effect receipts

What is still missing is one disciplined rule for how these surfaces should talk about state.
Without that,
Helm risks asking one tiny chip or strip to impersonate all of these at once:
- current phase
- current caveats
- live freshness
- observed basis
- last completed result
- restored-versus-live posture

## What a state tuple should keep separate

A useful first state tuple should likely keep at least five axes distinct.

### 1. Phase
What lifecycle posture is true now?
Examples:
- idle
- running
- waiting
- draining
- completed
- historical only

### 2. Conditions
What typed small truths are also true now?
Examples:
- restricted
- degraded
- muted
- stale while revalidating
- waiting on peer
- teardown requested
- imported / trust needed

### 3. Freshness / live-until
How current is the observation?
A good shell surface should be able to say:
- observed at
- fresh until / live until
- last confirmed
- stale but usable
- historical only
- unknown / cannot verify

### 4. Basis
What kind of witness produced this state?
Examples:
- direct shell semantic marker
- provider or runtime report
- reviewed durable receipt
- observed subscription
- remembered shell-local context
- derived shell projection

### 5. Last outcome
What was the most recent completed or durable result?
Examples:
- success
- partial
- cancelled
- failed
- action required
- repaired return
- no durable outcome yet

## Why this makes Helm better

### 1. Tiny surfaces stop lying by compression
A strip,
chip,
or beacon can stay tiny while still admitting that:
- the phase is `running`,
- the condition is `waiting on peer`,
- the freshness is `last confirmed 18s ago`,
- the basis is `publisher report`,
- and the last durable outcome was `failure`.

That is much better than one reassuring green dot.

### 2. Reality strips become much sharper
Reality strips are worth warming,
but only if their tiny chrome can project richer truth faithfully.
A state tuple is the missing grammar underneath them.

### 3. Saved views and restored objects stay useful without impersonating live state
A saved view may be stale.
A restored object may be rich but non-live.
A receipt may show historical success.
A state tuple lets those all stay legible without flattening them.

### 4. Review and action gates get more humane
Strong actions get much easier to explain when the shell can say exactly what is missing:
not just “unavailable,”
but:
- historical only,
- stale basis,
- waiting on renewal,
- last run succeeded,
- current condition restricted.

### 5. Helm steals a law that many current systems already validate
The outside proof stack is unusually aligned:
- Apple validates explicit stale posture for live-looking activity surfaces.
- Android validates live-now versus recent-history separation.
- GitHub validates status versus conclusion.
- Kubernetes validates phase versus conditions.
- semantic terminal integrations validate basis-rich state instead of transcript folklore.

## What Helm should steal from outside products

Steal:
- Apple `staleDate` discipline for live-looking projections
- Android live indicator plus historical timeline split
- GitHub status / conclusion separation
- Kubernetes phase / condition separation
- Windows Terminal semantic-basis metadata
- iTerm2 and PowerToys proof that tiny persistent surfaces are worth it

Do not steal:
- one universal state taxonomy for all providers on day one
- dashboard-first status culture
- hidden refresh that rewrites saved meaning without witness
- decorative motion as evidence
- one traffic-light badge pretending to summarize all truth

## What to prove next

### Small specimen A
One current-live beacon backed by a state tuple:
- phase
- one condition row
- one `live_until`
- one basis label
- one last outcome residue

### Small specimen B
One reality strip slot that compresses the tuple honestly,
then expands into a postcard-like explainer.

### Small specimen C
One saved-view or restored-object card that says:
- historical / restored posture
- freshness unknown or stale
- last durable outcome known
- revalidate / reopen path nearby

## Pillar effect

This does not add a pillar.
It sharpens many of them at once:
- **Tiling Shell** gets more honest live-versus-restored posture
- **Omnibox** gets clearer summon / open / act gating
- **Object Browser** gets better saved-view and imported-surface status
- **Operations Center** gets better multi-axis status without log-diving first
- **Recall** gets better restored-versus-historical truth
- **Exchange** gets better imported / restricted / trusted / completed distinctions

## Pull-the-trigger judgment

Because SlopOS and Schell are still design-phase cubes,
this looks like exactly the kind of thing Helm should freeze now.
Not a giant object.
Not a giant ontology.
A shell law.

The next especially promising move is therefore:
**freeze a shell-owned state tuple law with explicit live-until posture,
so Helm's smallest surfaces become more truthful as they become more glanceable.**
