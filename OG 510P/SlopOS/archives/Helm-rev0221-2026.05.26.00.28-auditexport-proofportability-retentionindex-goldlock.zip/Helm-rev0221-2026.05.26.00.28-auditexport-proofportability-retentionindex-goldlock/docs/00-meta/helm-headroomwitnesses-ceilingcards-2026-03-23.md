# Helm headroom witnesses + ceiling cards — 2026-03-23

## Why this pass happened

After **quorum witnesses**,
Helm could say:
- who has the baton now
- what signoff threshold still stands
- whether exceptions,
  promises,
  and endings are distinct truths

But it still lacked one humane operator answer:

**even if I am allowed and approved,
do I still have enough headroom to do the thing now,
under what ceiling,
and what honest next move exists when the ceiling is hot?**

That gap appears across:
- publish or apply acts gated by rate or seat ceilings
- lane-local budgets and shared payer budgets
- queue,
  burst,
  or namespace ceilings
- object-count,
  storage,
  and concurrency ceilings
- fixed system limits versus adjustable quotas
- recent success that no longer predicts current capacity

## Product judgment

The next narrow trigger is now worth pulling:

- keep the seven pillars stable
- do not add a new pillar
- keep **authority windows** for permission / grant truth
- keep **quorum witnesses** for signoff-threshold truth
- promote **headroom witnesses** as the shell-owned compact answer to `what exact ceiling applies here, how much headroom remains, when does it reset/refill, and what honest next move exists?`
- promote **ceiling cards** as the tiny nearby rendering for that headroom truth

A headroom witness answers:
- exact subject,
  cohort,
  lane,
  payer,
  project,
  namespace,
  route,
  or channel scope
- exact ceiling family:
  budget,
  quota,
  rate limit,
  seat cap,
  storage cap,
  concurrency cap,
  burst allowance,
  or mixed family
- current usage math:
  used,
  hard,
  remaining,
  percent,
  and optional projected-after-this-act
- ceiling posture:
  fixed,
  adjustable,
  burst,
  sustained,
  soft advisory,
  or hard-blocking
- reset / refill / decay posture:
  next reset,
  rolling window,
  refill rate,
  manual increase required,
  or unknown
- payer / sponsor relation when spendability depends on who pays
- blocker truth:
  hot now,
  near ceiling,
  exhausted,
  historical-only,
  or inferred-only
- next honest move:
  wait,
  narrow,
  request increase,
  switch payer,
  use another lane,
  or stop

A ceiling card answers that truth in one small human-facing form.

## Why this is worth stealing

The current official pressure is unusually clean:

- Kubernetes keeps used versus hard quota explicit
- GitHub keeps remaining budget and reset horizon explicit in rate-limit handling
- Google Cloud separates adjustable quotas from fixed system limits and supports monitoring plus alerts
- AWS makes increaseability and request workflow explicit
- Slack keeps burst tiers,
  per-minute limits,
  and special-scope ceilings explicit

Those systems feel humane because they distinguish **authority truth**,
**signoff truth**,
and **headroom truth**.

## Lessons Helm must learn from the past

- `allowed` is too flattering if the product hides that no headroom remains.
- `ready` is too flattering if success last hour is standing in for capacity right now.
- `quota reached` is too vague if the product hides whether the ceiling is burst,
  sustained,
  fixed,
  adjustable,
  or scoped to another payer.
- `retry later` is too vague if the product hides the reset or refill law.
- `budget available` is too flattering if the product hides that the shown surface is merely observational quota rather than spend authority.
- the right shell magic is not hiding the ceiling;
  it is making scope,
  remaining headroom,
  reset law,
  and recovery move obvious at a glance.

## What Helm should keep

Keep:
- authority windows
- quorum witnesses
- reality strips
- Overview / Recall / Operations Center as weak projection surfaces

Add more clearly:
- **headroom witnesses** near action warrants,
  publish/apply rails,
  watchpoints,
  reality strips,
  and Operations Center rows
- **ceiling cards** near Overview tiles,
  Recall return points,
  Omnibox stronger-action affordances,
  and route/promotion surfaces

## What Helm should refuse

Do not:
- build a giant billing/quota center first
- flatten fixed,
  adjustable,
  burst,
  sustained,
  and historical-only posture into one exhausted badge
- let authority windows impersonate spendability
- let signoff completion impersonate current capacity
- let old success receipts imply fresh headroom
- let retry buttons hide whether the honest move is wait,
  narrow,
  switch payer,
  or request increase

## Practical effect on Helm surfaces

A good compact Helm surface should increasingly be able to say:
- `allowed • 18% headroom left • rolling reset`
- `quota full • adjustable • request increase`
- `authority live • payer budget exhausted`
- `signoff complete • seat cap blocks publish`
- `burst open • sustained cap near hot`
- `historical success only • current headroom unknown`

That is a better next move than another pillar,
another quota dashboard,
or another flattering `ready` story.
