# Helm awesome ladders — 2026-03-22

Purpose: name the concrete shell moves that now look both delightful and honest enough to make Helm feel special.

## Tier A — strongest “wow, but true” moves

### 1. Peek, then choose the stronger verb
From Omnibox,
Recall,
Object Browser,
Exchange,
or a dock pin:

- peek this
- open this
- reenter the live lane
- save as a named view
- branch from checkpoint
- rehearse locally
- adopt here

One preview,
one tiny ladder,
no pretending the stronger move already happened.

### 2. Current-live beacon
Recall should have one obvious cue that means:

**this is not merely recent; this is the live lane you can really jump back into.**

That is a much stronger and rarer power than generic history.

### 3. Save this result as a real shell object
A useful search result,
filter result,
or exact object slice should be able to become:

- a saved view object
- a dock item
- a deck member
- an exact action key target

But only through an explicit stronger save/materialize step.

### 4. Restricted landing that still feels premium
A shared or imported shell object should be able to land with:

- inspect-only posture
- preview
- compare against local basis
- rehearse locally
- explicit adopt

This is safer,
but it also feels more premium because the shell is telling the truth.

### 5. Move-versus-copy as a first-class shell choice
When moving shell luxuries across boundaries,
Helm should let people choose:

- preserve lineage here
- publish as copy
- fork as new branch
- instantiate fresh local starter

That is one of the biggest ways Helm can feel more powerful than current shells without becoming harder to trust.

## Tier B — likely next best moves

### 6. Confirmable exact action keys
Hotkeys and deeplink-style entries should be able to remain:

- exact
- inspectable
- optionally confirmable when strong
- honest about locality and trust posture

### 7. Route-aware open receipts
After a meaningful open/share/attach/import act,
Helm should make it easy to inspect:

- who handled it
- what route was used
- whether the result was preview,
  open,
  materialization,
  restore,
  or publication

### 8. Personal / shared / published command bands
Docks and command bands become much better when they say:

- this is mine
- this is shared with the team/activity
- this is published/promoted

### 9. Basis-aware branch from here
Checkpoint branch should let the user say:

- compare with now
- restore toward this
- fork from here
- keep ancestry visible

without flattening all of those into resume theater.

## Tier C — keep warm but do not overbuild yet

### 10. Giant workspace portability
Still too easy to overpromise.
Better to prove portable cores,
local overlays,
arrival rehearsal,
and materialization bays first.

### 11. Universal recents federation
Likely a trap.
Shell-owned recency with exact labels is better than collecting provider folklore.

### 12. Giant timeline theater
Checkpoint compare is good.
Universal time travel religion is not required yet.

## The deeper pattern

The best Helm moves now share one shape:

- the shell gives you a compact weak contact point
- it keeps one or two stronger verbs nearby
- it tells you the truth about what has not happened yet
- and it gives you a better stronger workflow when you really want it

That is exactly the kind of design move that can make Helm super awesome without turning it into a giant constitutional maze.
