# Research bibliography — 2026-03-22 pass LXXIV

Primary sources reviewed for this pass:

1. Notion Help Center — Sharing & permissions
   - https://www.notion.com/help/sharing-and-permissions
   - used for web-link access,
     link expiration,
     public-link disabling,
     and access-level posture

2. Google Drive Help — Share files from Google Drive
   - https://support.google.com/drive/answer/2494822
   - used for Viewer / Commenter / Editor roles and add-expiry posture

3. Dropbox Help — How to set shared link permissions
   - https://help.dropbox.com/share/set-link-permissions
   - used for password-protected links,
     expiration dates,
     and disabled-after-expiry posture

4. Figma Help — Manage public link sharing and open sessions
   - https://help.figma.com/hc/en-us/articles/5726756336791-Manage-public-link-sharing-and-open-sessions
   - used for password requirements,
     required expirations,
     workspace-specific public-link settings,
     disable-public-links posture,
     and auto-ending open sessions

5. Figma Help — Share files and prototypes
   - https://help.figma.com/hc/en-us/articles/360040531773-Share-files-and-prototypes
   - used for audience choices,
     view/edit access,
     search visibility,
     and admin-disabled public-link posture

6. Amazon S3 User Guide — Download and upload objects with presigned URLs
   - https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html
   - used for presigned URL expiry,
     credential-bound invalidation,
     and bearer-token posture

7. Atlassian Support — Prevent public links
   - https://support.atlassian.com/security-and-access-policies/docs/prevent-public-links/
   - used for org-admin public-link policy,
     disabling creation,
     and turning off existing public links
