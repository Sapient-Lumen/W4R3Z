# Research bibliography — 2026-05-15 pass CLXXXIV

This pass supports Helm rev0191: reconciliation traces, refusal receipts, contradiction recipes, and suggestion-only resolution memory.

| ID | Source | Why it matters for Helm |
|---|---|---|
| WEB-CLXXXIV-ICEBERG-BRANCHING | Apache Iceberg, Branching and Tagging, https://iceberg.apache.org/docs/latest/branching/ | Named branches/tags and historical snapshots pressure Helm toward explicit cuts and audit/publish gates. |
| WEB-CLXXXIV-LAKEFS-HOOKS | lakeFS, Actions and Hooks, https://docs.lakefs.io/v1.79/howto/hooks/ | Pre-commit/pre-merge hooks are a precedent for gates before consequence. |
| WEB-CLXXXIV-DAGSTER-FRESHNESS | Dagster, Asset freshness policies, https://docs.dagster.io/guides/observe/asset-freshness-policies | Freshness status belongs in product surfaces, not hidden logs. |
| WEB-CLXXXIV-DBT-FRESHNESS | dbt, Source freshness, https://docs.getdbt.com/docs/deploy/source-freshness | Freshness snapshots and SLA posture support stale/recheck copy. |
| WEB-CLXXXIV-GITHUB-MERGE-QUEUE | GitHub Docs, Managing a merge queue, https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | Required checks on queued changes and removal reasons inspire refusal receipts. |
| WEB-CLXXXIV-TEMPORAL-HISTORY | Temporal Docs, Events and Event History, https://docs.temporal.io/workflow-execution/event | Replayable event histories inspire traceable product decisions without importing workflow runtime. |
| WEB-CLXXXIV-OPENLINEAGE-FACETS | OpenLineage, Understanding and Using Facets, https://openlineage.io/docs/1.35.0/guides/facets/ | Atomic metadata facets support small evidence refs over giant provenance graphs. |
| WEB-CLXXXIV-OTEL-CONTEXT | OpenTelemetry, Context propagation, https://opentelemetry.io/docs/concepts/context-propagation/ | Context crumbs help correlate boundaries without becoming authority. |
| WEB-CLXXXIV-DATAHUB-ASSERTIONS | DataHub, Assertions, https://docs.datahub.com/docs/managed-datahub/observe/assertions | Data-quality assertion failures are product truth; useful for refusal/recheck posture. |
| WEB-CLXXXIV-GX-VALIDATION | Great Expectations, Validation Result, https://docs.greatexpectations.io/docs/0.18/reference/learn/terms/validation_result/ | Saved validation results support inspectable refusal/history surfaces. |
| WEB-CLXXXIV-INTOTO-LINK | in-toto Attestation, Link predicate, https://github.com/in-toto/attestation/blob/main/spec/predicates/link.md | Subject/material/step binding informs small receipts and refusal evidence packets. |
| WEB-CLXXXIV-REKOR | Sigstore Docs, Rekor overview, https://docs.sigstore.dev/logging/overview/ | Transparency and retrieval pressure receipts to be durable and inspectable, but not automatically authoritative. |
