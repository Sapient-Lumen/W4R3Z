# Research bibliography — 2026-03-23 — pass CXXVI

- GitHub Docs — Managing notifications from your inbox
  - used for: `Save`, `Done`, `Unsubscribe`, `Read`, and `Unread` as distinct triage options
  - url: https://docs.github.com/en/subscriptions-and-notifications/how-tos/viewing-and-triaging-notifications/managing-notifications-from-your-inbox
- Slack Help — Introducing the new Activity view in Slack
  - used for: `mark as read` versus `clear notification`, plus saved custom views
  - url: https://slack.com/help/articles/46751260742035-Introducing-the-new-Activity-view-in-Slack
- Linear Docs — Inbox
  - used for: read/unread versus delete/snooze/unsubscribe, plus snooze returning unread
  - url: https://linear.app/docs/inbox
- Linear Docs — Triage
  - used for: accept / duplicate / decline / snooze / ask-for-more-information posture and surfaced rule conflicts
  - url: https://linear.app/docs/triage
- PagerDuty Support — Incidents
  - used for: `triggered` versus `acknowledged` versus `resolved`, plus acknowledgement halting escalation without implying fix completion
  - url: https://support.pagerduty.com/main/docs/incidents
- PagerDuty Support — Navigate the Incidents Page
  - used for: incident actions like acknowledge, reassign, resolve, snooze, and merge
  - url: https://support.pagerduty.com/main/docs/navigate-the-incidents-page
