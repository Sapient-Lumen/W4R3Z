# Research bibliography — 2026-03-22 — pass LVII

1. **Notion Docs — Create a view query**
   - source: https://developers.notion.com/reference/create-view-query
   - used for: cached result-set creation, `query_id`, `expires_at`, and 15-minute expiry posture

2. **Notion Docs — Get view query results**
   - source: https://developers.notion.com/reference/get-view-query-results
   - used for: pagination over cached result sets and 404-after-expiry behavior

3. **Notion Docs — Working with views**
   - source: https://developers.notion.com/guides/data-apis/working-with-views
   - used for: create → paginate → delete pattern on cached view-query results

4. **Grafana Docs — Configure recording rules**
   - source: https://grafana.com/docs/grafana/latest/alerting/alerting-rules/create-recording-rules/
   - used for: pre-computing frequently used or expensive expressions into new metrics

5. **Grafana Docs — Alert rules fundamentals**
   - source: https://grafana.com/docs/grafana/latest/alerting/fundamentals/alert-rules/
   - used for: recording rules as periodically evaluated derivative metrics later used by dashboards and alerts

6. **Jira Cloud — Manage filters**
   - source: https://support.atlassian.com/jira-software-cloud/docs/manage-filters/
   - used for: saved-filter subscriptions and first-200-results delivery bound

7. **Atlassian Analytics — Dashboard settings**
   - source: https://support.atlassian.com/analytics/docs/dashboard-settings/
   - used for: how viewed freshness / up-to-date posture is configurable on dashboards

8. **Atlassian Analytics — Refresh and examine chart data**
   - source: https://support.atlassian.com/analytics/docs/refresh-and-examine-chart-data/
   - used for: manual chart refresh when cached data is old enough

9. **Atlassian Analytics — Set up dashboard subscriptions**
   - source: https://support.atlassian.com/analytics/docs/set-up-dashboard-subscriptions/
   - used for: refreshing expired/older-than-30-minute charts before sending dashboard subscriptions
