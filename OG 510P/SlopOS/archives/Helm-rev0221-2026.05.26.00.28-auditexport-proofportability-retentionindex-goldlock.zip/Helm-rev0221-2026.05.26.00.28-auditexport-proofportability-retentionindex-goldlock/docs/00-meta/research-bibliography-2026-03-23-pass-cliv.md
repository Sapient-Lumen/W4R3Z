# Research bibliography — 2026-03-23 pass CLIV

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GITHUB-RULESETS-EVALUATE-2026M | https://docs.github.com/enterprise-cloud@latest/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets | GitHub contributes evaluate-without-enforce posture and later Rule Insights for pass/fail/bypass visibility. |
| REF-GITHUB-RULE-INSIGHTS-2026M | https://docs.github.com/enterprise-cloud@latest/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository | GitHub contributes explicit later review of what would have passed or failed under Evaluate mode. |
| REF-LAUNCHDARKLY-TEST-RUN-2026M | https://launchdarkly.com/docs/home/flags/preview-rules | LaunchDarkly contributes exact-context preview plus percentage-shift preview for targeting changes. |
| REF-AWS-IAM-POLICY-SIM-2026M | https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_testing-policies.html | AWS IAM contributes simulator usefulness plus live-environment caveats and no-response-body honesty. |
| REF-TERRAFORM-PLAN-2026M | https://developer.hashicorp.com/terraform/cli/commands/plan | Terraform contributes speculative-plan truth distinct from applyable plans. |
| REF-HCP-TERRAFORM-SPEC-2026M | https://developer.hashicorp.com/terraform/cloud-docs/workspaces/run/modes-and-options | HCP Terraform contributes plan-only speculative runs that cannot apply but still show possible changes and policy effects. |
| REF-K8S-API-VALIDATION-2026M | https://kubernetes.io/docs/concepts/overview/kubernetes-api/ | Kubernetes contributes the law that `--dry-run=server` gives more precise validation because admission-time checks also run. |
| REF-KUBECTL-COMMANDS-DRY-RUN-2026M | https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands | kubectl contributes explicit client-vs-server dry-run semantics and non-persistence posture. |
| REF-ARGOCD-DIFF-STRATEGIES-2026M | https://argo-cd.readthedocs.io/en/stable/user-guide/diff-strategies/ | Argo CD contributes server-side dry-run diff, diff caching posture, admission-controller participation, and new-resource caveats. |
| REF-OPA-DECISION-LOGS-2026M | https://openpolicyagent.org/docs/management-decision-logs | OPA contributes durable decision logs with policy, input, bundle metadata, and audit/debug value. |
