# SlopOS companions evaluation — 2026-03-23 pass CL

## Purpose

Continue mining **SlopOS**, **Steward**, **Harbor**, **Ward**, **ViewFS**, and **Schell**
after the attention-turn / next-actor pass by asking one tighter question:

**once Helm can say who should act,
how should it say by when,
under what exact kind of clock,
and what happens if that clock expires
without confusing promise,
silence,
maintenance,
renewal,
or escalation?**

## 1. SlopOS keeps teaching that recency and assurance are neighboring truths, not one timer

Recent SlopOS recency / assurance work keeps reinforcing the right broad law:
older evidence may still matter,
but exact freshness class,
current-live assurance,
and boundary-crossing trust should not be compressed into one warm “still okay” story.

That matters for Helm because a turn clock should not quietly become a trust verdict.
A slice can be:
- under current review,
- stale for strong action,
- still inspectable,
- and temporarily quieted for attention
all at once.

**Take for Helm:**
keep timing class separate from truth class.

## 2. Steward is the strongest local teacher for exact countdown honesty

Steward’s retry-advice and renewal-window work is extremely relevant here.
It keeps saying:
- earliest-follow-up hints are useful,
- `retry-advice-missing` is not the same as `retry now`,
- renewal confirms continuity of one exact live claim,
- and a missed renewal should fail stale/closed rather than drift into ambient persistence.

That maps directly onto Helm.
A turn clock should be able to say:
- `nudge after 10:00`,
- `wait until 14:03`,
- `expires waiting for reply`,
- `renewed through 14:15`,
- or `retry not before 14:20`
without pretending those are one generic deadline.

**Take for Helm:**
countdown truth should stay exact,
typed,
and smaller than lifecycle mythology.

## 3. Harbor keeps teaching that prepared turns, returned proofs, and durable adoption each have their own age

Harbor’s adoption-clocks and timebound-code work keeps the same lesson sharp:
parcel age,
returned-proof age,
timebound token lifetime,
and durable adoption age are different clocks.
That is a powerful local reminder for Helm.
A reviewed slice may have:
- a current actor clock,
- a current maintenance/silence clock,
- a current adoption/publish wait clock,
- and a current replay/compare footing age,
and those should not be flattened.

**Take for Helm:**
one subject may carry several small clocks,
and each should stay attached to its own seam.

## 4. Ward keeps teaching that later incident facts may trigger local holds without becoming remote commands

Ward’s incident-watch and local-spend-hold pressure is useful here too.
A later event can narrow local action,
but that does not mean the remote event source now owns the local clock grammar.
Helm should steal that humility.
An escalation rail may widen or reopen a local turn,
but it should stay shell-owned and footing-bound.

**Take for Helm:**
fact arrival,
local hold,
and next escalation are neighboring but separate truths.

## 5. ViewFS keeps teaching that live basis and later review windows should stay exact

ViewFS keeps reinforcing basis/drift/reconsent separation.
That still matters because a cool-off window,
review-again window,
or stale-fence reopening should bind to exact footing,
not to a flattering slice name.

**Take for Helm:**
turn clocks should be footing-bound.

## 6. Schell keeps teaching that checkpoints and review-again posture need explicit windows

Schell’s checkpoint humility and edit-review-again posture keep pushing toward explicit return loops.
The shell should be able to say:
- this old review packet still carries weak notes,
- this new footing reopened review,
- this is the current actor,
- and this is the current re-review window or next wake point.

**Take for Helm:**
time after change should stay visible,
not hidden behind generic stale glow.

## Product judgment

The admitted next shell-wide ratchet is still **settlement witnesses + commit cards**.
That remains the right decision.

But the next adjacent cluster now looks worth naming explicitly:
- **turn clocks**
- **escalation rails**
- and maybe later **timer-provenance cards**

Those objects would let Helm say something much better than:
`Alex has the baton.`

They could say:
- Maya is still the broad owner,
- Alex is the current actor,
- this is a `review-window` clock until tomorrow 10:00,
- if it expires it widens to release-review,
- this maintenance silence ends at 09:30 but does not imply recovery,
- and the only live retry advice here is `not before 14:20`.

## Laws Helm should keep learning from the past

1. **Due date is not promise.**
2. **Ack timeout is not commitment.**
3. **Maintenance silence is not calm.**
4. **Renewal is not broad health.**
5. **Escalation is not authority widening by magic.**
6. **One subject may honestly carry several small clocks at once.**
7. **Every clock should stay attached to exact footing, actor set, or seam.**

## Best bounded take now

Warm **turn clocks** and **escalation rails** beside attention-turn chips and next-actor rails.
Keep them tiny.
Keep them typed.
Keep them footing-bound.
Keep `promise`,
`wait`,
`snooze`,
`maintenance`,
`retry-not-before`,
`ack-timeout`,
and `escalation-at`
visibly separate.
