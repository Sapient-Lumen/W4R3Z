# SlopOS companions evaluation — 2026-03-23 pass CLIII

## Purpose

Continue mining **SlopOS**, **ViewFS**, **Foundry**, **Harbor**, **Ward**, **Steward**, and **Schell**
after the rule-stack / precedence-trace pass by asking one tighter question:

**once Helm can say what currently governs a slice,**
**how should it say what a proposed rule, waiver, or review change would do without pretending the trial is already live truth?**

## 1. SlopOS keeps teaching exact provider-local and policy-local humility

SlopOS keeps pressing the same hard lesson:
imported metadata,
provider-local policy,
helper discovery,
and durable receipts should not collapse into portable active truth.
That matters here because Helm trial objects should stay shell-owned,
scenario-bound,
and explicit about whose policy world they were evaluating.
A trial packet is not a portable approval object.
A simulated pass is not adopted aftermath.

## 2. ViewFS is still the strongest local teacher for prepare-versus-commit truth

ViewFS keeps the seam between:
- intent,
- prepared plan,
- approval checkpoint,
- committed execution,
- and result receipt.

That is almost exactly the lesson Helm needs for datacube-side trials.
The shell should be able to hold a tiny trial witness and a shadow verdict
without collapsing them into execution,
live state,
or durable history.
ViewFS also already warmed least-widening previews,
reach previews,
affected-set witnesses,
and shadow-work posture.

## 3. Foundry keeps pressing config-layer and overlay-gate honesty

Foundry keeps making a useful point:
a configured gate,
an overlay proposal,
a passed check,
and the effective live layer should stay visibly distinct.
That suggests Helm needs a reality-gap strip whenever a trial only exercised policy layers,
config overlays,
or preflight checks,
rather than full live motion.

## 4. Harbor and Ward keep pushing exact scope and missing-lane confession

Harbor's risk ladders and timebound codes,
plus Ward's local holds after later facts,
keep suggesting that a pleasant-looking preview can still miss crucial scope,
time,
or receiver posture.
So Helm trials need exact affected-set truth and explicit missing-lane confession,
not a flattering green badge.

## 5. Steward and Schell keep pressing preview weaker than active truth

Steward keeps discovery,
presence,
and readiness separate.
Schell keeps proposal,
review,
and run separate.
Both keep warning that something can be visible,
previewable,
or even prepared
without yet being live authoritative truth.
That is the core discipline Helm should steal here.

## Product judgment

The admitted next shell-wide ratchet still stays **settlement witnesses + commit cards**.

But the next adjacent cluster now looks strong enough to name explicitly:
- **trial witnesses**
- **shadow verdicts**
- **reality-gap strips**
- and maybe later **promotion packets**

The lesson Helm must keep learning from the companions is simple:
**prepared or simulated truth is not live truth.**

A super-useful Helm slice should be able to say:
- this is the live governing posture,
- this exact proposed change was trialed,
- this is the predicted verdict,
- this exact scope was covered,
- these lanes were not covered,
- and this remains weaker than adoption,
  activation,
  or aftermath.

Keep it tiny.
Keep it inspectable.
Keep it weaker than shell truth.
