# Helm synthesis — reality strips + continuity postcards — 2026-03-23

## Headline

After landmarks,
the next narrow move worth pulling is:
**a reality strip.**

And the right explanatory companion is:
**a continuity postcard.**

## Why this is the right next move

Helm already knows how to talk about:
- current-live beacons,
- landmarks,
- active-borrow beacons,
- freshness-horizon chips,
- condition strips,
- helper/session lights,
- and exact object timelines in Recall.

What it was still missing was one clean answer to:

**what should stay always-near so the shell can tell me what is true now,
what I can truthfully get back to,
and what side work is asking for attention?**

The answer should not be:
- giant home,
- giant memory,
- giant workspace object,
- or giant task-manager dashboard.

It should be:
- one tiny shell-owned strip,
- projecting stronger truths,
- with one small return card when return truth needs explanation.

## What a reality strip is

A reality strip is a **tiny always-near projection surface**.
It is not the authority itself.
It is the small face of stronger shell truth.

A good first strip likely composes:
- one **current-live slot**
- one **borrowed-now slot** with a nearby brake or narrow exit
- one **return-truth slot** that opens a continuity postcard
- one **freshness / condition slot**
- and at most one optional **session-attention ember** when helper or adoption work deserves return

## What a continuity postcard is

A continuity postcard is the compact explanation for a return claim.
It answers:
- is this really current-live,
- exact but launchable,
- exact but attachable,
- repaired,
- permission-gated,
- import/adoption-needed,
- or historical only?

The postcard is not the lane.
It is not the landmark.
It is not the authority.
It is the shell's compact confession about what kind of return truth is actually available.

## Why this makes Helm better

Landmarks solved **what should stay close**.
Reality strips solve **what should stay visible now**.
Continuity postcards solve **what kind of way back do I actually have**.

That is a very good sequence.
It makes the product feel more inevitable,
not more complicated.

## Strip laws

### 1. Projection, not authority
The strip summarizes stronger objects.
It never outranks them.

### 2. Live, borrowed, return, freshness, and attention stay separate
A strip can place them next to each other.
It must not flatten them into one status glow.

### 3. Decay must be visible
When a stronger witness disappears,
the strip should degrade to last-confirmed,
stale,
restricted,
or historical.

### 4. Session attention stays weaker than live truth
An ember can ask for review,
resume,
or adoption.
It must not imply the main lane already changed.

### 5. Continuity explanation belongs in postcards, not in giant inline chrome
The strip should stay tiny.
When return truth is subtle,
it should open a postcard.

### 6. Overview stays bigger and weaker
Overview can still be the pilot panel.
The strip is the tiny always-near face.
Those are different jobs.

## Great moves worth stealing now

- a **persistent tiny strip** rather than a whole dashboard
- **current-live chips** that visibly degrade
- **borrowed-now with brake nearby**
- **promoted landmarks feeding return paths**
- **session embers** that request attention without claiming adoption
- **compare / repair / revalidate** exits that stay one action away from the postcard

## Things to refuse

- no giant dashboard constitution
- no one flattering badge
- no silent restore engine
- no auto-promotion from recents into importance
- no session ember that pretends to be current-live adoption

## Pull-the-trigger judgment

This is now a wise narrow trigger.

Helm should keep the seven pillars stable,
keep action mode,
keep landmarks,
and now point the next proof energy at:
- one tiny reality strip specimen,
- with one continuity postcard specimen beneath it,
- before adding any broader home / dashboard / workspace machinery.
