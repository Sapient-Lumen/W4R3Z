# Research bibliography — 2026-03-21 pass XXV

Official/public sources consulted in this pass:

- VS Code Docs — Profiles in Visual Studio Code  
  https://code.visualstudio.com/docs/configure/profiles
- VS Code Docs — Settings Sync  
  https://code.visualstudio.com/docs/configure/settings-sync
- VS Code Docs — Using agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code Docs — November 2025 (version 1.107)  
  https://code.visualstudio.com/updates/v1_107
- VS Code Docs — Security / Workspace Trust baseline  
  https://code.visualstudio.com/docs/copilot/security
- Obsidian Help — How Obsidian stores data  
  https://help.obsidian.md/data-storage
- Obsidian Help — Introduction to Bases  
  https://help.obsidian.md/bases
- Obsidian Help — Views  
  https://help.obsidian.md/bases/views
- Raycast Manual — Deeplinks  
  https://manual.raycast.com/deeplinks
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — Adding Dock support to your extension  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Figma Help — Compare changes in Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Figma Help — Guide to Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Notion Docs — Working with views  
  https://developers.notion.com/guides/data-apis/working-with-views
- Airtable Support — Using the view share menu in Airtable  
  https://support.airtable.com/docs/using-the-view-share-menu-in-airtable
- WezTerm Docs — Workspaces / Sessions  
  https://wezterm.org/recipes/workspaces.html
- WezTerm Docs — Launcher Menu  
  https://wezterm.org/config/lua/config/launch_menu.html
