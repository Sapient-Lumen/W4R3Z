# SlopOS companions evaluation — 2026-03-23 pass CLIV

## Purpose

Continue mining **SlopOS**, **ViewFS**, **Foundry**, **Harbor**, **Ward**, **Steward**, and **Schell**
after the trial-witness / shadow-verdict pass by asking one tighter question:

**once Helm can say what a proposed change predicted,**
**how should it compare that prediction with later reality without collapsing preview and aftermath into one thing?**

## 1. SlopOS keeps teaching provider-local humility and durable receipt discipline

SlopOS keeps pressing the same hard lesson:
provider-local policy,
imported checks,
helper-generated previews,
and durable shell receipts should not collapse into one flattering truth blob.
That matters here because a later match between preview and reality is still not a reason to let imported simulation become shell authority.
Calibration should stay shell-owned,
exact-footing,
and tied to actual shell receipts.

## 2. ViewFS is still the strongest local teacher for prepare → commit → result separation

ViewFS keeps the seam between:
- prepared basis,
- approval checkpoint,
- committed execution,
- and result receipt.

That is almost exactly the lesson Helm needs.
A calibration witness should relate a prepared or previewed change to a later landed result,
without pretending they were the same object all along.
ViewFS also makes it clear that a drifted basis should explain some misses better than any generic `wrong preview` story.

## 3. Foundry keeps pressing declared-vs-observed humility

Foundry keeps making the useful point that:
- declared interface/world,
- policy check,
- observed realization,
- and adopted local meaning
stay different truths.

That suggests Helm needs typed miss classes.
Some preview gaps are not mistakes;
they are simply truths the preview never claimed.

## 4. Harbor and Ward keep pushing membrane aftermath and later-fact exactness

Harbor keeps teaching that a crossing and its aftermath at the membrane are not the same object.
Ward keeps teaching that later facts,
rechecks,
and receipt half-life matter.
Together they push Helm toward one clean law:
a preview may have been honest,
and later still need a calibration witness that says the footing shifted,
a receiver diverged,
or a later fact reopened the story.

## 5. Steward and Schell keep warning against proposal/result collapse

Steward keeps discovery,
presence,
and readiness apart.
Schell keeps proposal,
review,
and run apart.
Both therefore reinforce Helm's need for a small compare object rather than one magical truth badge.
The question is not whether preview and aftermath collapse.
They should not.
The question is how Helm remembers the exact relation between them.

## Product judgment

The admitted next shell-wide ratchet still stays **settlement witnesses + commit cards**.

But the next adjacent cluster now looks strong enough to name explicitly:
- **calibration witnesses**
- **miss ledgers**
- **outcome-gap strips**
- and maybe later **reliability notes**

The lesson Helm must keep learning from the companions is simple:
**predicted truth that later matched is still not aftermath truth,
but the relation between them is worth making first-class.**

A super-useful Helm slice should be able to say:
- this exact proposed change was trialed,
- this exact prediction was made,
- this exact later outcome landed,
- these parts held,
- these parts diverged,
- footing changed here,
- runtime or foreign-response omissions stayed outside the preview here,
- and this remains a compare object,
  not a retroactive promotion of the preview into authority.

Keep it tiny.
Keep it inspectable.
Keep it weaker than shell truth.
