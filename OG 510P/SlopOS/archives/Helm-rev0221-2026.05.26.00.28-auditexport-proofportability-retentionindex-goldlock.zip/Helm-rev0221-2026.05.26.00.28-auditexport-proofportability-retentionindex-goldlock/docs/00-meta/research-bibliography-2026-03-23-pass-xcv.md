# Research bibliography — 2026-03-23 — pass XCV

Primary sources reviewed for this pass:

- WHATWG HTML Living Standard — interaction / APIs gated by user activation
  - https://html.spec.whatwg.org/multipage/interaction.html
- MDN — User activation
  - https://developer.mozilla.org/en-US/docs/Web/Security/Defenses/User_activation
- MDN — Web Share API
  - https://developer.mozilla.org/en-US/docs/Web/API/Web_Share_API
- MDN — `Window.showOpenFilePicker()`
  - https://developer.mozilla.org/en-US/docs/Web/API/Window/showOpenFilePicker
- MDN — `MediaDevices.getDisplayMedia()`
  - https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getDisplayMedia
- W3C / WICG — Captured Surface Control
  - https://w3c.github.io/mediacapture-surface-control/
- W3C — Payment Request API
  - https://www.w3.org/TR/payment-request/

Companion archives reread during this pass:

- SlopOS-rev0635-2026.03.22.18.47-address-selection-boundary.zip
- Schell-rev0114-2026.03.22.15.21-titlewitnesses-displaylabels-overridehumility-namequay.zip
- ViewFS-rev0040-2026.03.22.16.02-observeattach-controlplanes-sidebands-helmsman.zip
- Steward-rev0058-2026.03.23.05.41-label-surfaces-trusted-chrome-avocet.zip

Notes:
- The useful pattern was the combination of **fresh expiring intent**, **consumable intent**, and an even stricter **same-dispatch / direct-gesture** tier for a narrower class of especially sensitive acts.
- The main non-pattern was broadening this into a giant universal permission maze.
