# Research bibliography — 2026-03-22 — pass XLVIII

Purpose: official/public sources for the action-warrant and drift-gate pass.

## Primary outside sources

- OpenAI Help — Projects in ChatGPT
  - https://help.openai.com/en/articles/10169521-projects-in-chatgpt
  - used for: explicit project sources from Slack/Google Drive and project-scoped context pressure

- Notion Developers — Create a view query
  - https://developers.notion.com/reference/create-view-query
  - used for: stable cached result sets with explicit expiration

- VS Code Docs — Revert changes with checkpoints and editing requests
  - https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
  - used for: exact restore points, reverting previous request batches, and changed-file visibility

- VS Code Release Notes 1.110
  - https://code.visualstudio.com/updates/v1_110
  - used for: Agent Debug visibility for loaded prompt files, skills, hooks, and tool calls

- VS Code Docs — Use Agent Skills in VS Code
  - https://code.visualstudio.com/docs/copilot/customization/agent-skills
  - used for: portable skills, on-demand loaded capabilities, and explicit customization surfaces

- Google Docs Editors Help — Collaborate with Gemini in Google Sheets
  - https://support.google.com/docs/answer/14218565?hl=en
  - used for: action preview card, apply/settings/undo, analysis steps, preview/insert separation

- Google Workspace Updates Blog — Gemini in Sheets advanced editing actions
  - https://workspaceupdates.googleblog.com/2025/05/use-gemini-google-sheets-advanced-actions.html
  - used for: current product framing around natural-language edits as explicit spreadsheet actions

- GitHub Docs — Asking GitHub Copilot to create a pull request
  - https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/create-a-pr
  - used for: explicit delegate-to-agent flow, confirmation, and reviewer handoff

- GitHub Docs — Reviewing a pull request created by GitHub Copilot
  - https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/review-copilot-prs
  - used for: review requirement, non-counting self-approval, and iterative review comments

- GitHub Docs — Configuring settings for GitHub Copilot coding agent
  - https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/configuring-agent-settings
  - used for: explicit “Approve and run workflows” path and warning that workflows may access secrets

## SlopOS internal teacher surfaces re-read this pass

- `docs/30-architecture/approval-basis-posture-v0.md`
- `docs/30-architecture/attention-durable-status-boundary-v0.md`
- `docs/30-architecture/attestation-collateral-status-boundary-v0.md`
- `docs/30-architecture/capshell-result-sidecar-boundary-v0.md`
