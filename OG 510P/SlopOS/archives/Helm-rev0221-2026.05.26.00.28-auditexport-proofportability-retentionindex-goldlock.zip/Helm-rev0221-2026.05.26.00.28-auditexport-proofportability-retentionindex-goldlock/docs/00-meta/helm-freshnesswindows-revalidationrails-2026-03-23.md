# Helm freshness windows + revalidation rails — 2026-03-23

Purpose: name the strongest next cross-cutting move now that Helm has many bounded support objects,
but still lacks one shell-wide answer to:

**how long is this object meaningfully fresh,
what happens when it decays,
and how should the shell help me re-check it?**

## Main idea

Helm already has many places where freshness matters:
- basis stamps
- glance derivations
- watchpoints
- claim envelopes
- reliance ladders
- receiver-fit cards
- Overview cards
- review tickets
- patrol routes
- evidence briefs

But today freshness mostly appears as scattered hints.

The next better move is to add one cross-cutting law:
- **freshness windows** — bounded freshness/decay posture carried by one exact shell object
- **revalidation rails** — explicit next-step rails for how freshness is refreshed,
  checked,
  or downgraded

## What a freshness window should say

A useful freshness window should be able to say:
- what exact object it belongs to
- what exact source/basis it depends on
- when it was cut / observed / computed
- how long it counts as fresh
- whether stale is still usable in any weaker sense
- when it becomes expired / hold-only
- whether the receiver can verify freshness locally at all

A good first posture ladder now looks like:
- fresh
- stale but usable while revalidating
- stale only as explicit fallback / if-error posture
- expired / hold
- unknown / unverifiable

## What a revalidation rail should say

A good revalidation rail should make the next move explicit:
- background revalidate
- revalidate now
- reopen exact source
- compare current against stamped basis
- invalidate by tag/family/provider reason
- hold / require review again

It should also be able to record:
- when revalidation happened
- why it happened
- whether it succeeded,
  failed,
  or downgraded to stale fallback

## Why this makes Helm better

### 1. Saved and derived surfaces stop bluffing “latest”

A glance card can be useful even when not live.
The trick is to say so plainly.

### 2. Overview can stay weak without feeling dead

Overview does not need to become live-everything dashboard theater.
It can show a bounded card plus:
- fresh/stale posture
- revalidation reason
- and one stronger path back to source

### 3. Claim envelopes and reliance ladders get much sharper

A good claim envelope should be able to say not just what grounded a claim,
but whether the grounding is still fresh enough for the current rung.

A good reliance ladder should be able to say:
- safe to quote now
- safe to save weakly
- inspect source first
- revalidate first
- hold because freshness is no longer strong enough

### 4. Travel and share stay honest

A handoff packet or receiver-fit card can admit:
- basis exact,
- freshness unknown on this receiver,
- source reopen available,
- strong adoption blocked until revalidation.

### 5. Watch and attention surfaces stop overclaiming

Evaluation may still be running while a watch summary card is stale.
Quieting attention may still be in effect while the watch itself is warning.
Those different truths should stay distinct.

## What not to build

- not a giant cache dashboard
- not a universal TTL bureaucracy
- not hidden background refresh that rewrites saved meaning without witness
- not one timestamp badge pretending to solve freshness,
  drift,
  and authority together
- not a new pillar

## Pull-the-trigger judgment

Keep the seven pillars stable.
Keep saved views and checkpoint branches as the strongest proof targets.

But it now looks wise to harden one more cross-cutting law:
**freshness windows + revalidation rails**.

This is one of those moves that can make Helm feel dramatically better without broadening it.
It gives many existing objects a cleaner life cycle,
and it keeps the deepest SlopOS lesson intact:

**freshness is posture,
not portable authority.**
