# Helm: exception witnesses, waiver leases, and explicit break-glass residue — 2026-03-23

After **attention-turn chips**,
**next-actor rails**,
and **turn clocks**,
Helm now has a tighter adjacent question:

**once the shell knows who should act and under what exact clock,**
**how should it say that movement is happening under an exception without repainting that exception as normal healthy compliance?**

The most promising next cluster is:
- **exception witnesses**
- **waiver leases**
- and maybe later **breakglass beacons**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. every exception becomes one vague override badge, or
2. the shell can tell you who owns,
   watches,
   acks,
   and clocks a slice,
   but still cannot answer the humane question:
   **what stronger rule is being bypassed here,
   for whom,
   until when,
   and what remains true underneath?**

Operators need a third answer:
- the reviewed slice stays visible,
- the footing stays visible,
- the current actor and clocks stay visible,
- **and one compact exception object says what rule is unsatisfied,
  what exception class is active,
  what scope it covers,
  what lease it runs under,
  and what wakes or fences when the lease ends.**

## Candidate objects

### 1. Exception witness
A compact shell-owned truth object for one exact unsatisfied rule or gate.

Good early fields:
- exact subject / footing / reviewed-slice ref
- requirement or gate ref
- exception class:
  - `bypass-approved`
  - `waived-active`
  - `maintenance-active`
  - `silenced`
  - `inhibited`
  - `paused`
  - `transient-auto-pause`
  - `breakglass-used`
  - `expired`
  - `rescinded`
  - `denied`
- requester and granter / source
- scope
- what still evaluates or moves underneath
- strongest nearby inspect / redeem / revoke / recheck exit

### 2. Waiver lease
A small bounded time object for temporary exception posture.

Good early fields:
- exception witness ref
- start_at
- end_at or explicit end condition
- lease kind:
  - `maintenance-through`
  - `silence-until`
  - `pause-while`
  - `breakglass-once`
  - `downtime-window`
  - `policy-bypass-window`
- what expiry does:
  - `wake-notifications`
  - `reopen-review`
  - `recheck-gate`
  - `fence-strong-action`
  - `return-to-triggered`
  - `leave-historical-residue`
- whether renewal / extension is allowed

### 3. Breakglass beacon (later)
A later inspectable card that can say:
- a sharper protection rule was bypassed,
- by whom,
- on what exact footing,
- under what emergency rationale,
- and what residue or mandatory follow-up remains.

## What Helm should probably do now

### 1. Keep exception classes typed
`maintenance-active`
is not
`bypass-approved`.

### 2. Keep the interrupted requirement visible
The shell should say what stronger rule remains unsatisfied.
Do not hide the gate behind a generic override chip.

### 3. Keep evaluation truth separate from attention truth
A silence or downtime may suppress notifications while the underlying state still changes.

### 4. Keep pause separate from pass
Paused review,
paused SLA,
or paused attention
is not completed,
met,
or healthy.

### 5. Keep exceptions scope-bound and footing-bound
A useful exception should say:
- exact slice
- exact lane / environment / target set
- exact footing
- exact exclusions

### 6. Keep expiry consequence explicit
When the lease ends,
Helm should say whether it:
- wakes notifications,
- widens attention,
- reopens review,
- fences publish / commit / deploy,
- or merely leaves residue for later inspection.

### 7. Keep imported exception posture weaker than local reliance
If Helm only observed a foreign bypass or maintenance window,
it should say so.
Do not silently convert observed exception posture into local operator law.

## Guardrails

1. **Do not let exception witnesses impersonate healthy/compliant state.**
2. **Do not let waiver leases replace underlying reviewed-slice or rule truth.**
3. **Do not let admin or owner power become invisible bypass folklore.**
4. **Do not let break-glass posture become routine default posture.**
5. **Do not let this seam become a giant governance console.**
6. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

> owner remains Maya.
> current turn remains Alex.
> review window expires at 10:00.
> deployment gate is not satisfied.
> exception witness says `breakglass-used` on `prod deploy approval`.
> waiver lease is `breakglass-once` for this exact deployment footing.
> notifications remain live.
> strong publish stays fenced after this lease ends until re-review.
> residue requires follow-up and cannot masquerade as ordinary clean green.

That would make Helm much better at telling the truth about temporary exceptions
without turning it into a giant incident,
audit,
or governance empire.
