# Research bibliography — 2026-03-23 pass CXIII

1. **Microsoft Graph — Delta query overview**
   - Why it mattered: delta queries keep paging and delta links distinct, but also say `410 Gone` means restart with full synchronization and that tokens have bounded validity.
   - Helm pull: reset should be a first-class shell truth, not a hidden repair.

2. **Google Calendar API — Synchronize resources efficiently**
   - Why it mattered: incremental sync keeps `pageToken` and `nextSyncToken` distinct, requires the exact same query during incremental pagination, and says `410` should trigger a full wipe and full sync.
   - Helm pull: restart scope should be explicit, not one generic refresh story.

3. **Google Drive API — changes.getStartPageToken**
   - Why it mattered: Drive shows that some bookmark families are durable enough that the starting change token does not expire.
   - Helm pull: change-cursor families should stay typed; decay is not universal.

4. **Dropbox — Detecting Changes Guide**
   - Why it mattered: folder cursors serve as pointers to a folder at a particular time, longpoll waits on a saved cursor, and team-log cursor expiration requires a new starting query.
   - Helm pull: last-seen, wait-from-here, and reset-from-new-baseline should remain distinct shell truths.

5. **Kubernetes — API Concepts**
   - Why it mattered: Kubernetes distinguishes exact versus best-effort watch starts, warns about arbitrarily stale starts, and requires clients to tolerate `410 Gone` when older resource versions are not retained.
   - Helm pull: resume semantics and reset semantics belong in the shell, not in invisible implementation folklore.

6. **Apple File Provider / CloudKit docs**
   - Why it mattered: File Provider treats sync anchors as explicit change positions and exposes `syncAnchorExpired`; CloudKit exposes `changeTokenExpired` when the old token is stale and sync must restart.
   - Helm pull: dead bookmarks should preserve evidence while honestly admitting reset-from-beginning posture.
