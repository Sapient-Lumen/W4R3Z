# Helm consequence envelopes and rehearsal sheets — 2026-05-15

Purpose: record the rev0192 design ratchet.

## Decision

Pull the trigger on **consequence projections / consequence envelopes** as the next proof-fixture object after reconciliation traces.

Do not choose a policy engine, workflow engine, notifier, backend, query language, semantic layer, table format, authorization language, CRDT/sync ontology, global provenance store, or new pillar.

## Why now

rev0191 could say what to do when multiple truths disagree. That still leaves the product one button away from ambiguity: does refusal create an object, does quarantine notify anyone, does a review cut affect shared state, what is the blast radius, and how does the operator retreat?

rev0192 makes those questions checkable.

## The new object

A consequence projection binds:

- one reconciliation trace;
- all source events affected by the trace;
- affected surfaces;
- audience and exposure scope;
- preflight checks;
- state-change class and blast radius;
- receipt plan;
- forbidden/safe next verbs;
- visible copy;
- retreat path;
- invariants.

## Must learn from the past

- From ambient desktop automation: never let “the button worked last time” become authority.
- From dashboard sprawl: never let a summary tile hide its source cut, staleness, or consequence path.
- From VCS/merge tools: preview, queue, and merge are different; keeping them distinct is the whole product.
- From security prompts: giant modal walls teach users to click through. Tiny exact rehearsal sheets teach users what is at stake.
- From SlopOS: fail closed, keep boundary coverage explicit, and make outcome receipts non-authoritative unless another object grants authority.

## Brilliant steal

The outside world has useful pieces:

- merge queues recheck against the target-plus-queue state;
- feature/progressive-delivery systems rehearse rollout analysis before full exposure;
- policy engines produce decision logs useful for audit and debugging;
- lineage systems carry compact facets rather than giant stories;
- semantic/export systems materialize reusable answers while keeping definition/cut/freshness visible.

Helm should steal the shape: a compact pre-consequence sheet, not the whole system.

## Product magic

The magic move is “show me the consequence before I spend it.”

A Helm operator should be able to hover or open a sheet that says:

```text
Affects: review queue item 884 + refusal receipt candidate
External effect: none
Required before stronger move: recheck against release-view@13
Forbidden now: promote, publish, settle
Retreat: preserve stale review as history
```

That is how Helm can feel premium without becoming a workflow platform.
