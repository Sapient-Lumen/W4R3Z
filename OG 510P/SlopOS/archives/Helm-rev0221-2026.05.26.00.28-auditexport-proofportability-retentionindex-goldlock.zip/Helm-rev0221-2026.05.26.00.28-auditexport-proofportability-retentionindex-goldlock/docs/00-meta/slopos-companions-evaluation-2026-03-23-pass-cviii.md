# SlopOS + companion-cube evaluation — 2026-03-23 — pass CVIII

## Frame for this pass

Helm's Exchange line is now much clearer than it was a few revisions ago:
- transfer offers
- take cards
- route witnesses
- and generic effect receipts

The next missing middle is not "final success".
It is the smaller sentence:

**for this exact transfer offer,
through this exact chosen route,
the receiving side really did acquire or materialize this exact representation —
but that still is not the same as user-meaningful downstream completion.**

That missing middle now looks like a **materialization witness**.

## What SlopOS keeps teaching

### 1. Imported or provider-local completion does not automatically become shell truth
SlopOS keeps freezing boundaries where imported provider-local signals stay weaker than shell-owned state.
That matters here.
A receiving app may:
- fetch bytes,
- open a granted handle,
- or write a temporary local copy,
without proving that the user's higher-level goal is finished.

Helm should learn the same lesson.
A materialization witness should say what exact acquisition or local write happened,
not pretend it already knows the receiver's final semantic effect.

### 2. Materialization and export are separate seams from route choice
The SlopOS open-untrusted and import/materialization boundaries remain useful teachers.
The recurrent lesson is:
- request,
- route/admission,
- local materialization,
- and later durable outcome
are different strengths.

That argues strongly against letting a route witness impersonate "the file is now there" when the receiver has not actually retrieved it yet.

### 3. Fresh local identity still matters
SlopOS keeps insisting that fresh local materialization,
rebind,
and durable authority should not silently collapse.
Helm should keep that discipline.
A materialization witness should preserve whether the far side got:
- a temporary copy,
- an in-place readable handle,
- a writable export,
- a receiver-local staging object,
- or a durable local import.

## What ViewFS keeps teaching

### 1. Promises, transfers, imports, and results are distinct
ViewFS is almost a direct proof sketch for this pass.
It already argues that import,
export,
transfer,
share,
and promise-later materialization should remain separate seams.

That means Helm should not blur:
- route chosen,
- bytes retrieved,
- receiver-local staging,
- and durable imported object.

### 2. Receipts should be class-honest
ViewFS keeps live handles,
durable refs,
and receipts separate.
That same law should apply inside Exchange:
- transfer offer
- take card
- route witness
- materialization witness
- effect receipt

Each is a different witness class.
The shell gets more trustworthy when it admits that explicitly.

### 3. Promised files are not already-live objects
ViewFS's pressure around promised files and later materialization is exactly what Helm needs now.
A promised route can be luxurious.
But the shell should still know whether the receiver has actually pulled the bytes yet,
and under what temporary or durable posture.

## What Schell keeps teaching

### 1. Handoff admitted and target-observed are different
Schell's handoff and completion humility docs keep warning against a single flattering completion story.
That same warning applies here.
"The target got far enough to retrieve or stage the payload" is a useful truth,
but it is still weaker than "the target completed the user-meaningful work."

### 2. Drop / copy / share witnesses imply one more rung
Schell already treats drop,
clipboard,
and share witnesses as typed seams.
A materialization witness simply adds the next rung:
**the route crossed,
and the far side really fetched or wrote the payload.**

### 3. Path truth and file truth should stay humble
Schell's path-translation and file-offer honesty are good reminders that receiver-local materialization may be:
- temporary,
- translated,
- sandbox-exported,
- or confirm-surface-bound.
The shell should keep that posture visible.

## What Steward keeps teaching

### 1. Tiny truthful channels beat summary folklore
Steward keeps pushing compact,
trusted,
status-honest surfaces.
That suggests a materialization witness should be small and inspectable,
not another giant activity log.

### 2. "Acquired" deserves its own status rung
Steward's label and activation thinking reinforces that
selected,
acquired,
processing,
completed,
and failed should not all become one badge.
Helm can steal that law directly.

## Lessons Helm must keep learning from the past

1. **Do not let chosen route impersonate retrieved payload.**
2. **Do not let retrieved payload impersonate finished user work.**
3. **Do not let temporary copies masquerade as durable imports.**
4. **Do not let in-place access masquerade as local ownership.**
5. **Do not let one-shot or auto-closing transfer sessions disappear from history.**

## What looks worth pulling forward now

Helm is probably ready to warm one more Exchange specimen:

**materialization witnesses** — compact shell-owned post-handoff objects that preserve:
- exact transfer offer,
- exact chosen route witness,
- exact retrieved or materialized representation,
- temporary versus in-place versus durable-local posture,
- retrieval / acquisition proof source,
- one-shot / autostop / closure semantics,
- and what stronger downstream effect still remains unknown.

That now looks like the smallest honest next move after route witnesses.
