# Research bibliography — 2026-03-21 — pass XII

## Preview / browse / action-adjacent pressure

- Apple Quick Look docs — full-size preview without opening the file.
- Apple Finder Preview pane docs — metadata-rich preview beside browsing.
- Apple Finder Quick Actions docs — bounded actions available directly from the preview/browse surface.
- Microsoft PowerToys Peek docs — fast cross-type preview.
- Microsoft PowerToys File Explorer add-ons docs — preview and thumbnail extensions for more file types.
- Microsoft PowerToys Crop And Lock docs — cropped / thumbnail derivative windows.

## Overview / spatial companion pressure

- GNOME Activities overview docs — live windows,
  workspaces,
  dash,
  and type-to-search in one surface.
- KDE Activities docs — multiple activity containments and the caution that they can become a parallel worldview.

## Command palette / root-search pressure

- Microsoft PowerToys Command Palette overview and extensibility docs.
- Raycast main product page,
  Quicklinks docs,
  Dynamic Placeholders manual,
  Snippets docs,
  and Window Management docs.
- Alfred workflow Palette / Prefabs / Automation Tasks docs and workflows overview.
- KRunner docs — recent entity recall and broad run/search utility.

## Terminal-local luxury pressure

- VS Code terminal shell integration docs — command guide,
  sticky scroll,
  quick fixes,
  and run-recent-command.
- WezTerm docs — command palette,
  launch menu,
  pane object,
  and local multiplexer richness.
- fish interactive docs — autosuggestions and cheap inert delight.

## Flow / reuse / support-machinery pressure

- Node-RED subflows docs.
- Node-RED flow-structure docs for link nodes and reusable fragments.
- Unreal Engine Blueprints docs.
- acme manual page from Plan 9 from User Space.

## Current use in Helm

This pass mainly pressures:
- Preview as shell-wide inspect-before-commit with bounded action ladders,
- Overview as the spatial companion to Omnibox,
- typed quicklinks / placeholders / snippet seeds,
- command-boundary witnesses and source-labeled recent-command recall for terminal/capshell,
- prefab/subflow-like reusable Flow fragments,
- and the decision to keep terminal/capshell as a front-end family while proving Helm with one compact cross-pillar slice first.
