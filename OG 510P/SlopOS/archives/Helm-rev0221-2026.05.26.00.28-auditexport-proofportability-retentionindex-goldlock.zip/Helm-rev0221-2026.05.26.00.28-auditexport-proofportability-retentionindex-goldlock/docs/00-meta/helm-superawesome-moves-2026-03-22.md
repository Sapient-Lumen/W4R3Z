# Helm super-awesome moves — 2026-03-22

Purpose: name the concrete interactions that could make Helm feel meaningfully better than today's shells without requiring a giant constitutional freeze first.

## Tier A — strongest bets

### 1. Preview anywhere, then promote intentionally
A result in Omnibox,
Object Browser,
Recall,
Exchange,
or Operations Center should be able to open into a compact preview with:
- provenance / route / source posture
- tiny bounded actions
- exact reveal/open where supported
- promote to split,
pin,
branch-from-here,
import,
or adopt

This is one of the clearest “wow” moves because it compresses search,
triage,
and commitment into one grammar.

### 2. Fork from a checkpoint everywhere continuity matters
The user should be able to say:
- restore to this point
- compare to this point
- branch from this point
- pin this point as a named checkpoint

That makes Recall and Desktop Flow feel dramatically stronger without pretending history is reversible magic.

### 3. Imported things land in restricted posture first
Imagine a shared view,
flow fragment,
deck,
workspace recipe,
or external result slice arriving with a visible weaker posture:
inspect,
preview,
rebind,
adopt,
or hold.

That would make Helm safer and more legible while also making sharing feel more premium.

## Tier B — likely next best moves

### 4. Activity spine objects
A single activity spine could tie together:
- saved views
- checkpoints
- current route receipts
- associated dock items
- launch/layout starters
- one current-live beacon
- one explicit scope or memory fence

Not a new pillar;
just a shell-owned way to keep a piece of work coherent.

The crucial trick is that sharing the spine may need to tighten the boundary rather than widen it.

### 5. Personal / shared / published dock bands
A dock should not just be a pile of favorites.
It should expose which items are:
- personal only
- shared with a team/activity
- published or promoted artifacts

### 6. Current-live beacons with scope witness chips
A saved view,
entry kit,
checkpoint,
or resource shelf should be able to sit next to one stronger shell-owned beacon that says:
- this is the real live lane now
- this is only historical
- this is current but widened
- this is imported/shared weaker relation

A tiny scope witness should say what counted and what stayed out.

### 6A. Remember this for this activity
A universal shell move on results, selections, views, pages, routes, and receipts.
The operator should be able to save one tiny remembered fact, warning, or instruction with:
- explicit scope
- source witness
- inspect / archive / forget controls
- and visible later influence in Omnibox, Recall, spines, or entry kits

### 6B. Ask or act with this exact loadout
A universal shell move on tabs, files, views, objects, seeds, tools, and prompt fragments.
The operator should be able to:
- add or remove current context explicitly
- choose current only versus selected set versus saved activity loadout
- preview the proposed action with the loadout visible
- and inspect a small contribution witness afterwards

### 7. Exact compare over shell objects
Not just text diffs.
View config diff,
route diff,
checkpoint diff,
branch diff,
recipe diff,
publication diff.

### 8. Route-aware exchange receipts
Every meaningful open/share/import/attach/forward should make it easy to inspect:
- who handled it
- by which route
- whether it produced live truth,
a receipt,
a preview,
or only a staged artifact

## Tier C — ideas to keep warm

### 9. View decks that stay derivative
Useful,
especially as activity front doors.
But they should stay visibly weaker than the objects they summarize.

### 10. Stable compare or review tickets
Great for long review sessions or handoff.
But they should remain bounded and purpose-specific,
not become the hidden general object model.

### 11. Portable workspace packets
Potentially powerful.
Still too easy to overpromise.
Better to get imported-surface trust posture right first.

## Pull-the-trigger judgment

Still yes:
- saved view objects
- checkpoint branches

Now also worth defining as support contracts:
- preview-promotion ladders
- imported-surface trust posture
- activity entry kits / front doors
- current-live beacons
- activity scope witnesses
- activity memory seeds
- context loadouts
- contribution witnesses
