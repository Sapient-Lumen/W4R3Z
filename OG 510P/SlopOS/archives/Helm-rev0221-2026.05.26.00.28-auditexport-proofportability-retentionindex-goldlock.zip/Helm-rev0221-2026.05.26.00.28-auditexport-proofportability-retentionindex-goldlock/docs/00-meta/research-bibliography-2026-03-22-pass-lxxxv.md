# Research bibliography — 2026-03-22 — pass LXXXV

- AWS IAM policy simulator
  - key: can test and troubleshoot identity-based policies,
    permissions boundaries,
    specific resources,
    and context keys
  - why: strong precedent for exact counterfactual permission checks
  - caution: simulator results can differ from the live environment
  - source: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_testing-policies.html

- Google Cloud Policy Troubleshooter
  - key: evaluates allow,
    deny,
    and principal access boundary policies for a principal/resource/permission tuple and explains relevant policies
  - why: strongest precedent here for exact blocked-state explanation
  - source: https://docs.cloud.google.com/iam/docs/troubleshoot-policies

- Kubernetes `kubectl auth can-i`
  - key: asks whether an exact verb is allowed on an exact resource or object,
    and pairs with impersonation
  - why: good teacher for tiny exact authorization questions instead of role folklore
  - source: https://kubernetes.io/docs/reference/kubectl/generated/kubectl_auth/kubectl_auth_can-i/

- VS Code Workspace Trust / Restricted Mode
  - key: disables or limits risky features in restricted mode and exposes the list of disabled features in the trust editor
  - why: blocked state can still be inspectable and productively explained
  - source: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust

- AWS IAM Access Analyzer access preview
  - key: previews proposed public or cross-account access before deployment
  - why: strong precedent for preview-before-widen posture
  - source: https://docs.aws.amazon.com/IAM/latest/UserGuide/access-analyzer-preview-access-apis.html

- AWS IAM Access Analyzer policy validation
  - key: validates policies against grammar and best practices,
    with warnings,
    errors,
    and suggestions
  - why: good precedent for actionable preflight findings before attaching stronger permissions
  - source: https://docs.aws.amazon.com/IAM/latest/UserGuide/access-analyzer-policy-validation.html

- Google Cloud principal access boundary policies
  - key: define what resources a principal is eligible to access;
    fail closed;
    and are distinct from allow grants
  - why: strongest current precedent for upper-bound eligibility that should not be confused with actual grant
  - source: https://docs.cloud.google.com/iam/docs/principal-access-boundary-policies

- Chrome `chrome.permissions`
  - key: request declared optional permissions at runtime so users understand why they are needed and grant only what is necessary
  - why: excellent precedent for least-widening asks and human-timed permission expansion
  - source: https://developer.chrome.com/docs/extensions/reference/api/permissions

- Cedar authorization diagnostics
  - key: authorization responses include the decision,
    determining policies,
    and error conditions
  - why: strong precedent for verdict-plus-diagnostics instead of a silent allow/deny bit
  - source: https://docs.cedarpolicy.com/auth/authorization.html

- OPA decision logs
  - key: decision logs record policy queries,
    inputs,
    bundle metadata,
    and other debugging context
  - why: good precedent for durable after-the-fact explanation that does not itself become standing authority
  - source: https://openpolicyagent.org/docs/management-decision-logs

- OPA Envoy dry-run
  - key: dry-run allows requests while decision logs show what would have happened
  - why: clean teacher that simulated verdicts and live verdicts should stay visibly different
  - source: https://openpolicyagent.org/docs/envoy
