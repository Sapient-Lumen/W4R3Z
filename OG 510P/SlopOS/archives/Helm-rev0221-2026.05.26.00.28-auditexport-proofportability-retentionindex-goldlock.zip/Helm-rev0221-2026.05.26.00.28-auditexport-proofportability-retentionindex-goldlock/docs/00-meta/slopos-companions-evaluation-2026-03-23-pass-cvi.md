# SlopOS companion-cube evaluation — 2026-03-23 — pass CVI

## Purpose

Continue reading **SlopOS**, **ViewFS**, **Schell**, and **Steward** as design-phase teachers for Helm,
without pretending any one cube has already finished the law for the whole shell.

This pass asks the next Exchange question after transfer offers:

**what object should Helm add so one exact offered thing and one exact candidate receiver can tell the truth about chosen representation,
chosen operation,
expected downgrade,
and edit / confirm / materialize-first posture — without collapsing preflight fit,
actual take,
and later receipt truth into one flattering “share succeeded” story?**

## Strongest lesson from SlopOS

SlopOS keeps teaching a constitutional habit that matters here too:
**provider-local suggestions,
launch offers,
and bounded candidate sets should stay weaker than reviewed selection and downstream completion.**

Read against Exchange,
that means Helm should not let:
- a suggested receiver pretend to be chosen truth
- a provider-preferred operation pretend to be target-accepted truth
- a launchable route pretend to be completion or landed-state truth

The transferable Helm lesson is:
**candidate take is its own seam.**
It needs one honest shell-owned object before the system upgrades into route witness or receipt.

## Strongest lesson from ViewFS

ViewFS keeps refusing the lie that:
**offered data,
promised outputs,
retrieved representations,
and materialized receiver-local state are the same thing.**

That pressure gets sharper here.
A receiver may be able to take:
- plain text,
- HTML,
- a file,
- a directory handle,
- an open-in-place grant,
- or only a downgraded import.

Those are not equal truths.
Helm therefore wants a **take card** that can say:
- exact take available
- exact take with user edit/confirm
- take only after materialization
- weaker downgraded take
- or no honest take on this route

## Strongest lesson from Schell

Schell's ingress and terminal notes keep teaching that path-looking or text-looking material often still hides stronger type truth.
A paste or drop may carry:
- text/plain and text/html,
- a file offer,
- a shell-facing route,
- or one exact selection owner/source.

That pushes Helm away from string-first exchange mythology.
It also pushes Helm to keep downgrade visible.
If a terminal route only takes text/plain,
that is a different take than attaching or importing the richer object.

## Strongest lesson from Steward

Steward keeps teaching that exact target truth and aftermath truth should stay separate.
It does not help to say “activated” or “shared” if the user really needs to know:
- which target was chosen,
- in what mode,
- and what actually happened there.

That is exactly why Helm should avoid jumping straight from offer to receipt.
The pre-take evaluation belongs on its own seam.

## What Helm should keep from these cubes

Keep:
- provider-local suggestion staying weaker than reviewed route choice
- typed offered material staying visible long enough to choose wisely
- promised or provider-backed material staying weaker than receiver-local state
- exact target followthrough and receipts after the route is taken
- selection / route / completion / receipt staying different truths

Peel away:
- one generic “share” or “paste” success story
- silent downgrade from rich to weak representation
- source-requested move/cut pretending to guarantee target-accepted move
- stale route memory pretending to mean current fit
- any temptation to call the route “done” before the receiver has really taken it

## Current judgment

Helm now probably wants a compact Exchange sequel to transfer offers:
**take cards** — one route-local pre-take object that can say what this receiver can honestly accept,
with what chosen representation,
with what operation class,
with what losses or extra steps,
and with what review or confirm posture,
before route witness or effect receipt truth arrives later.
