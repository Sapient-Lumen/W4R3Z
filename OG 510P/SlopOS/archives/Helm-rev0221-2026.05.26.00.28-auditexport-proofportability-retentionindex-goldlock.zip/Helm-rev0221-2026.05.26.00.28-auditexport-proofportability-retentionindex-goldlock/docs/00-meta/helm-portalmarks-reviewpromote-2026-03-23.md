# Helm: portal marks + review promote — 2026-03-23

## Headline

Helm should now get a little bolder about **delight surfaces**,
but only where shell law is already strong.

The strongest current awesome moves look like this:
- **portal-shaped front doors**
- **productive restricted preview**
- **compare / review / promote lanes**
- **semantic command landmarks**
- **scoped accelerators**

## The sharpened lesson from the past

Power gets better when the shell keeps adjacent truths separate.
That means:
- front door is not ambient possession
- preview is not ordinary open
- compare is not merge
- approval is not current-live authority forever
- command landmarks are not the same thing as scraped terminal guesses
- personal quicklinks are not shared or published workflow truth

## What is now worth pulling the trigger on

### 1. Portal-shaped front doors should become a real Helm law

Across Omnibox,
Object Browser,
Exchange,
and Desktop Flow,
Helm should prefer chooser-owned,
parameterized,
inspectable entry surfaces that yield:
- one exact object or handle
- one explicit scope statement
- one explicit persistence story
- and one visible stronger-step ladder nearby

This is a better law than path folklore,
ambient picker results,
or “open with…” myths.

### 2. Restricted-first preview should be a premium path

Helm already believes in preview and safe-open.
The next move is emotional as much as architectural:
restricted-first should feel excellent.

That means:
- fast preview
- obvious reveal of exact subject
- obvious open / safe-open / compare / adopt exits
- visible quarantine or review posture when relevant
- and no shaming tone in the chrome

### 3. Semantic command landmarks are worth warming now

The terminal/capshell family should stop depending on screen archaeology for everything valuable.
If the shell can report prompt,
input,
output,
current working directory,
mark,
and exit status through a narrow treaty,
Helm gets:
- better jump and selection
- better finish notifications
- better recent-command recall
- better command/output reentry
- and better bridge surfaces into Recall and Operations Center

## What should stay warm rather than frozen

### Compare / review / promote lanes
These look increasingly right,
but the shell should prove them with a compact specimen before treating them as a giant universal subsystem.
The first answer should likely cover:
- imported artifacts
- checkpoint compare
- helper-proposed changes
- and promoted previews

### Scoped accelerators
Helm should absolutely steal local,
shared,
and published accelerator scope.
But it should still avoid turning every shortcut into cloud religion,
team policy,
or giant launcher bureaucracy.

### Typed approval diffs
These look increasingly right for stronger shell actions.
But Helm only needs the humane slice first:
one compact review object plus one aftermath receipt,
not a massive permission-management product.

## Pillar consequences

### Tiling Shell
- side-by-side or overlay compare should be a normal layout affordance for review-heavy moves
- restricted preview should fit naturally into split and stack layouts instead of feeling like a modal exile

### Omnibox
- front doors should admit personal,
  activity-shared,
  and published scope
- quick starters should carry explicit “exact handle / parameterized starter / search template” posture
- stronger actions should have nearby compare or review exits when basis drift matters

### Object Browser
- preview must stay clearly weaker than open,
  materialize,
  or publish
- imported or historical objects should be able to land in review-first posture with compare and adopt nearby

### Operations Center
- stronger shell acts should have compact typed review summaries and aftermath receipts
- active semantic command landmarks should be inspectable when terminal work is part of the operational story

### Desktop Flow
- flow front doors should be portal-shaped and typed
- promoted preview or helper results should move through visible compare / review / promote rails instead of “run this graph and trust it” folklore

### Recall
- command history should get better through semantic landmarks,
  not only through shell-text guessing
- reopen and restore flows should reuse compare/review posture when old state still needs fit or trust

### Exchange
- ingress should prefer portal/document-handle posture over raw path folklore
- foreign arrivals should preserve quarantine,
  derivative,
  and endorsement honesty
- shared starters should admit whether they are local,
  shareable,
  or published

### Terminal/Capshell
- the family should warm a narrow semantic-landmark treaty now
- host-owned stronger acts should still stay on trusted shell seams,
  with landmarks remaining observational rather than authority-bearing

## What to peel away

Peel away:
- giant archive machinery cloned from still-fluid companion cubes
- any myth that preview is always harmless
- any myth that shortcuts are either purely personal or instantly universal
- any assumption that routed text or routed messages should themselves count as power

## Judgment

Helm still does **not** need more pillars.
But it is now worth getting more ambitious about a few support moves that can make the product feel obviously better:
- portal front doors
- productive restricted preview
- compare / review / promote lanes
- semantic command landmarks
- scoped accelerators

Those are the kinds of moves that can make Helm feel super awesome without forcing a giant constitutional freeze first.
