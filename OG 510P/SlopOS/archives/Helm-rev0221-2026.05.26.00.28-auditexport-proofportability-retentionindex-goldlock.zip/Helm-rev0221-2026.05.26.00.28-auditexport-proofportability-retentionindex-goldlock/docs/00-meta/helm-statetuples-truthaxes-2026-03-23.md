# Helm synthesis — state tuples + truth axes — 2026-03-23

## Headline

After landmarks,
reality strips,
and continuity postcards,
the next narrow move worth pulling is:
**state tuples.**

## Why this is the right next move

Helm already knows how to talk about:
- current-live beacons,
- landmarks,
- reality strips,
- continuity postcards,
- freshness-horizon chips,
- condition strips,
- session-attention embers,
- and exact object timelines.

What it was still missing was one clean answer to:

**what compact status grammar keeps all of those surfaces truthful?**

The answer should not be:
- one green dot,
- one flattering badge,
- one generic status column,
- or one giant health dashboard.

It should be:
- one shell-owned tuple,
- attached to one exact subject,
- carrying several different claim axes without pretending they are one thing.

## What a state tuple is

A state tuple is the shell's compact answer to:
- what phase is this exact thing in,
- what conditions currently shape it,
- how fresh is that claim,
- what basis supports it,
- and what was the last durable outcome?

That is enough grammar to make tiny chrome honest.

## The five truth axes Helm should freeze first

### 1. Phase
A simple high-level summary.
Examples:
- running
- completed
- waiting
- restored
- historical only

### 2. Typed conditions
The reasons phase alone is insufficient.
Examples:
- review needed
- waiting on peer
- restricted
- revalidating
- adoption ready
- drifted

### 3. Freshness
How old or live the claim is.
Examples:
- current live
- last confirmed
- stale usable
- historical only
- unknown

### 4. Basis
What kind of witness produced the claim.
Examples:
- runtime/provider report
- semantic shell witness
- observed subscription
- reviewed durable receipt
- remembered shell-local projection
- derived shell summary

### 5. Last durable outcome
What the most recent durable result was,
which is often not the same as the current phase.
Examples:
- success
- cancelled
- failure
- merged
- duplicate suppressed
- no-op

## Why this makes Helm better

Landmarks solved **what should stay close**.
Reality strips solved **what should stay visible now**.
Continuity postcards solved **what kind of way back is actually available**.

State tuples solve **how all of those surfaces can stay honest without growing huge**.

That is a very good next move because it strengthens several pillars at once:
- **Overview** gets tuple-backed tiles instead of vague badges.
- **Operations Center** gets rows that separate current waiting/degraded truth from last success/failure.
- **Recall** gets postcard-backed return truth that can admit current phase versus last outcome.
- **Exchange** gets cards that distinguish imported/restricted/completed posture.
- **Object Browser** gets inspectable exact object status without folklore.
- **Omnibox / landmarks** get more truthful promotion weather.

## Great moves worth stealing now

- **Kubernetes phase vs conditions**
- **GitHub status vs conclusion**
- **systemd ActiveState / SubState / Result**
- **Raycast Quick Search** for exact selected-text argument fill on promoted action templates
- **Click to Do** for local-first selection-scoped action with explicit provider choice

## Things to refuse

- no one flattering status glow
- no last success masquerading as current readiness
- no transient attention chrome masquerading as durable consequence truth
- no remembered shell state masquerading as live proof
- no ambient silent argument fill from vague context

## Pull-the-trigger judgment

This is now a wise narrow trigger.

Helm should keep the seven pillars stable,
keep typed action mode,
keep landmarks,
keep reality strips and continuity postcards,
and now point the next proof energy at:
- one shell-owned **state tuple** specimen,
- rendered through one current-live beacon,
- one reality-strip slot,
- one Recall postcard,
- and one Operations row,
- before adding any larger dashboard,
  workspace,
  or health-board machinery.

## Warm follow-on steal

Once tuples exist,
a very promising ergonomic follow-on is:
**argument-fed action landmarks** — promoted quick actions that can accept one exact selected subject or selected-text argument without regressing into ambient context folklore. 
