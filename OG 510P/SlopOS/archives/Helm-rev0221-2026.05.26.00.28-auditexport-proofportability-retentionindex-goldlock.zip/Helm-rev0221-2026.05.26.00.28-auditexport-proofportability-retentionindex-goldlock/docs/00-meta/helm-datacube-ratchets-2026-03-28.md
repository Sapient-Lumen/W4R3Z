# Helm — datacube ratchets and no-regrets proof cluster

## Current judgment

Helm still does **not** need another pillar.
It also still does **not** need one universal workspace object,
one giant home/dashboard plane,
or one giant datacube constitution.

The strongest current move is to **pull the trigger on a very small cluster that should make Helm obviously better fast**:
- **saved view objects**,
- **exact front-door handles**,
- **restricted / fit-required imported arrivals**,
- **one named triage lane**,
- and **explicit compare / review / promote exits**.

## What looks wise to freeze now

### 1. Saved view objects
Helm should treat views as first-class shell objects.
That means a view is:
- summonable,
- pinnable,
- inspectable,
- shareable,
- and still clearly weaker than the stronger truth it looks at.

### 2. Exact front-door handles
Helm should have one tiny reusable noun for “the exact way back in.”
Smaller than a whole activity spine.
Smaller than a whole entry kit.
Still stronger than vague recents.

### 3. Restricted arrival posture
Imported,
shared,
or checkpoint-derived surfaces should land honest first:
- inspect-only,
- restricted,
- fit-required,
- adoptable,
- adopted.

### 4. One triage lane near the door
Helm should have one obvious place where new work,
new drift,
new asks,
or imported arrivals can be reviewed before they join stronger flow.

### 5. Compare / review / promote exits
Helm should keep safe exploration,
preview,
import,
and branch-like side work useful,
but the stronger move should still be explicit.

## What to keep warm,
not freeze yet

- **view decks**
- **deck recipes**
- **watchpoints + subscriptions**
- **publication ladders + promotion receipts**
- **role-shaped entry pages**
- **patrol routes**
- **evidence briefs / response kits**

These are promising,
but they should remain derivative until the smaller proof cluster earns them.

## What not to keep

Do not keep:
- one universal workspace myth
- giant cockpit dashboards that become authority by occupancy
- plugin-defined truth planes
- silent import→adopt widening
- ambient sync mythology
- profile/provider affinity that silently chooses the stronger target
- view decks pretending to be live continuity

## Per-pillar cuts

### Tiling Shell
Lean on front-door handles,
entry kits,
and one tiny reality-adjacent return face.
Do not make tiling layouts impersonate live sessions.

### Omnibox
Search and act over exact saved views,
front-door handles,
triage lanes,
and restricted imported surfaces.
Imported hits should show their weaker posture right there.

### Object Browser
Treat saved views,
compare lanes,
restricted arrivals,
and adoption/promote paths as ordinary product truth.
This is where the datacube should feel explicit.

### Operations Center
Make triage,
review,
publication/import activity,
and blocked stronger actions inspectable.
Do not become a giant dashboard religion.

### Desktop Flow
Let flows target the same saved views and front doors.
Imported or helper-produced flow fragments should stay weaker until adopted.

### Recall
Keep live,
saved door,
saved view,
historical receipt,
and imported carry posture painfully distinct.
Return should feel humane,
not magical.

### Exchange
Route shared views,
front doors,
and recipes as typed arrivals.
Arrival is not adoption.
Receiver fit should stay explicit.

## Why this makes Helm super awesome

Because it gives Helm a premium everyday loop:
- keep several excellent views over one truth,
- return through one exact door,
- review new arrivals in one named lane,
- compare or branch safely,
- and only then promote into stronger local truth.

That is the kind of shell that feels calm,
sharp,
and trustworthy without becoming huge.
