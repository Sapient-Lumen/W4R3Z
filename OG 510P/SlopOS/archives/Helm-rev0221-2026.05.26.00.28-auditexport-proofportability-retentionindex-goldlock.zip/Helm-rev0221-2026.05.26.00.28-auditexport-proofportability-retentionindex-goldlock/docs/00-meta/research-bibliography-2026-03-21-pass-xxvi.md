# Research bibliography — 2026-03-21 pass XXVI

## Primary outside sources used in this pass

- Microsoft Learn — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Microsoft Learn — **Git Branches and Worktrees in VS Code**
  - https://code.visualstudio.com/docs/sourcecontrol/branches-worktrees
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Notion Docs — **Working with views**
  - https://developers.notion.com/guides/data-apis/working-with-views
- Notion Docs — **Create a view**
  - https://developers.notion.com/reference/create-view
- Figma Help — **Guide to Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Figma Help — **Compare changes in Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Raycast Manual — **Deeplinks**
  - https://manual.raycast.com/deeplinks
- Raycast Manual — **Cloud Sync**
  - https://manual.raycast.com/cloud-sync
- Raycast Manual — **Shared Quicklinks**
  - https://manual.raycast.com/quicklinks/shared-quicklinks
- Obsidian Help — **How Obsidian stores data**
  - https://obsidian.md/help/data-storage
- WezTerm docs — **Workspaces / Sessions**
  - https://wezterm.org/recipes/workspaces.html
- Warp docs — **Launch Configurations**
  - https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp docs — **URI Scheme**
  - https://docs.warp.dev/terminal/more-features/uri-scheme
- Apple Support — **View and edit files with Quick Look on Mac**
  - https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac

## Main local teacher documents re-opened in SlopOS rev0585

- `rfcs/0032-view-namespace-semantics-v1.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0053-origin-quarantine-and-safe-open.md`
- `rfcs/0054-authority-diffs-and-consent-receipts.md`

## What these sources mainly taught this pass

- **Notion**: explicit view objects and dashboard/widget composition over one stronger substrate
- **Figma**: compare-against-basis plus propagated developer resources as secondary companions
- **Raycast**: exact deeplink handles with small start context plus explicit non-synced local residue
- **VS Code**: exportable/importable structure plus review/apply after isolated work
- **Warp / WezTerm / PowerToys / Apple**: saveable launchable structures and compact shell surfaces that still remain honest about activation and object strength
