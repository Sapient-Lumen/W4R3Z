# Research bibliography — 2026-03-22 — pass XLII

## Current tools and support docs

- Dropbox Dash homepage — stacks preserve original access settings and easy preview in one context-rich shared link.
- Dropbox Dash help — search / ask / write / organize; stacks organize files, apps, and browser links in one place.
- Slack help — tabs, folders, links, files, canvases, and lists in channel/DM headers.
- Google Docs help — document tabs, direct tab links, duplicate/move, current-tab versus all-tabs export/print.
- Google Chrome help — saved tab groups in bookmarks bar and cross-device pinning.
- Linear docs — custom views and project-attached views.
- OpenAI help — project-only memory and shared-project boundary tightening.
- Raycast manual — shared quicklinks and JSON import.
- Figma help — review/approve/merge branching with side-by-side or overlay compare.
- Obsidian Sync — selective sync and recovery.

## Why these sources matter for this pass

This pass was mainly about deciding whether Helm wants one more shell object beneath activity spines:
a compact curated grouped-resource object.
