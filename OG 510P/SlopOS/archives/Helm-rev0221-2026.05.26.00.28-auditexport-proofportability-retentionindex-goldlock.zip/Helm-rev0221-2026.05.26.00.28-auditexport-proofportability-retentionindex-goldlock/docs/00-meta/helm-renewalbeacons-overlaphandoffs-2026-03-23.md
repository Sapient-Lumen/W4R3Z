# Helm: renewal beacons + overlap handoffs — 2026-03-23

Keep the seven pillars stable.
Do not add another pillar.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **footing marks**, typed **delta ladders**, **footing death cards**, and **residue ladders** as the current substrate grammar beneath humane return loops.

But after making dead footing explicit,
one narrower preventative seam now looks worth warming:

**renewal beacons** so the shell can say when exact footing is approaching expiry, compaction, removal, or reauthorization pressure before it dies,
paired with **overlap handoffs** so the shell can replace continuity objects honestly when a system requires brief coexistence between old and new footing.

## Why this now looks necessary

A footing death card answers:
- did the old footing die?
- what killed it?
- what weaker residue still remains?

But premium systems do something better before that moment:
- they show the remaining continuity budget,
- they name the exact renewal or replacement verb,
- and they sometimes require a short overlap between old and new watches, channels, subscriptions, or handles.

Without that seam,
Helm is tempted to wait until failure,
then explain death after the fact.
That is honest,
but not awesome.

## The smallest object pair

### Renewal beacon
A compact shell-owned receipt that says:
- what exact footing / channel / cursor / lease / subscription is in play,
- what kind of continuity budget governs it,
- how much trustworthy budget remains,
- whether renewal-in-place exists,
- whether replacement requires overlap,
- which actor owns the renewal,
- and what exact next verbs are honest now.

Likely first classes:
- `stable` — no immediate continuity pressure visible
- `renew-soon` — same footing can be renewed or extended
- `replace-with-overlap` — replacement is required and overlap is the honest path
- `replace-without-overlap` — replacement is required but no overlap guarantee exists
- `risk-of-compaction` — history window is shrinking and continuity may die soon
- `non-renewable` — no renewal verb exists; only reacquire / rebuild remains

### Overlap handoff
A compact shell-owned receipt for continuity swaps that says:
- what old footing or channel is being retired,
- what new footing replaces it,
- whether both were simultaneously active,
- what proof bridges the handoff,
- whether any gap remains possible,
- and when the old footing is safe to stop.

The point is not to invent one giant live-sync subsystem.
The point is to stop forcing operators to learn these swap rules from provider folklore.

## What the web now teaches

The current official product pressure converges on this pair.

Google Drive push channels include an expiration header, have no automatic renewal, and are explicitly expected to be replaced with a new `watch` request; the docs even warn about an overlap period where both channels may be active.
Google Calendar push channels similarly use explicit channels and expiration timestamps.
Microsoft Graph subscriptions expire, should be renewed well before expiry, and can emit lifecycle notifications such as `reauthorizationRequired`, `subscriptionRemoved`, and `missed`.
Dropbox tells clients to always store the latest cursor even when no results are returned, because unused cursors may expire and later force a reset.
etcd watch progress notifications and bookmarks expose how far a stream is known to be caught up, while compaction limits the available history window.
Kubernetes Lease objects keep `renewTime` explicit, and Pub/Sub lease management exists exactly because static deadlines are too blunt for variable work.
Pub/Sub snapshots also have bounded lifetime known at creation.

Together these are almost a design brief for Helm:
**continuity should not only die honestly;
it should age, warn, renew, and hand off honestly too.**

## What this lets Helm do better

### Recall
Recall can stop pretending every remembered footing is equally durable.
It can say:
- `anchor stable`
- `renew within 12m`
- `replace channel with overlap`
- `history window shrinking`
- `non-renewable; plan rebuild`

### Operations Center
Runs,
streams,
watchers,
landing trains,
and remote continuations can show a compact live continuity budget,
not just alive/dead.

### Object Browser
Saved views,
reopen routes,
since-cuts,
and compare surfaces can show whether the old footing is safe,
approaching compaction,
or already mid-handoff to a new footing.

### Exchange
Delivery,
materialization,
and route aftermath can expose whether a continuation token,
upload session,
or watcher is being renewed,
replaced,
or allowed to expire.

## Lessons Helm must keep learning from the past

- Waiting for failure is honest but often too late.
- `expires soon` is not enough without a named renewal verb.
- Renewal in place and replace-with-overlap are different truths.
- A new continuity object should not silently inherit trust from the old one without a visible bridge.
- Progress bookmarks and renewal clocks are weaker than live success,
  but stronger than silence.
- Dead footing should remain inspectable,
  but living footing should show its remaining budget before it dies.

## Awesome moves this enables

- one tiny countdown / horizon chip on serious cards;
- one `renew now` or `replace with overlap` affordance when the verb is shell-owned;
- one tiny overlap strip that says `old + new active`, `bridged`, or `possible gap`;
- one calm compaction-risk ribbon for long-lived watchers;
- one explicit distinction between `extend`, `replace`, `reacquire`, and `rebuild`.

## Best current decision

Still do not add another pillar.
Still do not build a universal sync center.
Still do not flatten continuity into one scalar.

But it now looks wise to warm **renewal beacons** and **overlap handoffs** as the next humane preventative seam above **footing death cards** and **residue ladders**.
