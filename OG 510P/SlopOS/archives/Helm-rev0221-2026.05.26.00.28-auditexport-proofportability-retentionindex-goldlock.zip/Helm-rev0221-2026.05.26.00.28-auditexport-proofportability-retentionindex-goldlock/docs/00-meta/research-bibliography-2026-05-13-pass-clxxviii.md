# Research bibliography — 2026-05-13 pass CLXXVIII

This file records the online sources consulted for the pass and the design pressure extracted from them. It is intentionally a bibliography and synthesis pointer, not a dependency list.

## Semantic layers and metrics

- Databricks documentation — Metric views. Pressure: define business measures centrally while separating measure definitions from dimension groupings and query surfaces. URL: https://docs.databricks.com/aws/en/metric-views/
- dbt Developer Hub — dbt Semantic Layer and MetricFlow docs. Pressure: semantic models, entities, dimensions, and metrics help avoid duplicate metric logic; Helm should steal consistency pressure but not a vendor taxonomy. URLs: https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl and https://docs.getdbt.com/docs/build/about-metricflow
- Cube documentation — Pre-aggregations. Pressure: materialized query results can make common queries fast, but the surface must admit that a serving lane is being used. URL: https://cube.dev/docs/product/caching/using-pre-aggregations

## Lakehouse, local analytics, snapshots, and transport

- Apache Iceberg documentation — Evolution. Pressure: partition specs can evolve; physical layout should be hidden from users but tracked in metadata and basis cards. URL: https://iceberg.apache.org/docs/latest/evolution/
- DuckDB documentation — Lakehouse formats. Pressure: open table formats provide ACID/snapshot-history style guarantees, and support differs by format; Helm should avoid picking one prematurely. URL: https://duckdb.org/docs/lts/lakehouse_formats
- DuckLake 1.0 announcement. Pressure: catalog metadata can be stored in SQL and made more legible; metadata is a design surface. URL: https://ducklake.select/2026/04/13/ducklake-10/
- DuckDB documentation — Why DuckDB. Pressure: local analytics and "run where the data lives" are useful, but should remain an implementation lane rather than Helm's identity. URL: https://duckdb.org/why_duckdb
- Apache Arrow documentation — Arrow and Flight SQL. Pressure: columnar interchange and SQL-over-Arrow can be a useful substrate for fast datacube previews, but not a user-facing truth model. URLs: https://arrow.apache.org/ and https://arrow.apache.org/docs/format/FlightSql.html
- Observable Framework documentation — Data loaders. Pressure: precomputed static snapshots can make data apps fast and safer while requiring cache/build freshness honesty. URL: https://observablehq.observablehq.cloud/framework/data-loaders

## Product/workflow surfaces

- GitHub Docs — Project views. Pressure: saved tabs, filters, sorts, and grouped views are recurring-work primitives. URL: https://docs.github.com/en/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/customizing-a-view
- Airtable Support — Personal views and collaborative views. Pressure: personal/shared view posture belongs in the product model. URL: https://support.airtable.com/docs/personal-views
- Linear Docs — Triage. Pressure: team inbox with accept, duplicate, decline, and snooze verbs validates a bounded review lane. URL: https://linear.app/docs/triage
- Microsoft Learn — PowerToys Peek. Pressure: preview can be fast and system-wide without becoming open/adopt/activate. URL: https://learn.microsoft.com/en-us/windows/powertoys/peek
- GitHub Docs — Merge queue. Pressure: queues should revalidate against latest base and remove failing entries rather than treating earlier review as eternal. URL: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue

## Authorization, agents, observability, and durable history

- Model Context Protocol specification — Authorization. Pressure: tool/resource authorization should be explicit and transport-aware, not ambient. URL: https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization
- RFC 9396 — OAuth 2.0 Rich Authorization Requests. Pressure: fine-grained JSON authorization details are a good model for action-purpose disclosure. URL: https://www.rfc-editor.org/rfc/rfc9396.html
- OpenTelemetry documentation. Pressure: context propagation and correlated traces/metrics/logs are useful inspiration for Helm's receipt crumbs. URL: https://opentelemetry.io/docs/
- Temporal documentation — Event History. Pressure: durable histories can recover/replay workflows; Helm should preserve receipt history without pretending replay equals live provider truth. URL: https://docs.temporal.io/workflows#event-history
