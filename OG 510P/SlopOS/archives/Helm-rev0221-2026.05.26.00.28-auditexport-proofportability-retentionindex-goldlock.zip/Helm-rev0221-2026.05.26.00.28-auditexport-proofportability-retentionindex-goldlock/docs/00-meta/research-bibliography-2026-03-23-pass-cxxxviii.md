# Research bibliography — 2026-03-23 pass CXXXVIII

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-LAKEFS-BRANCH-2026 | https://docs.lakefs.io/v1.66/quickstart/branch/ | zero-copy branch creation is a strong precedent for cheap exploratory branch labs |
| REF-LAKEFS-PRS-2026 | https://docs.lakefs.io/v1.70/howto/pull-requests/ | reviewable pull requests with query/test/modify-before-merge are strong pressure for adopt/merge gates |
| REF-LAKEFS-HOOKS-2026 | https://docs.lakefs.io/v1.79/howto/hooks/ | `pre-commit` / `pre-merge` hooks are a strong model for visible pre-adoption checks |
| REF-DAGSTER-SELECTION-2026 | https://docs.dagster.io/api/dagster/assets | selection algebra plus checks-for-assets is a good model for reviewed target-set promotion |
| REF-DAGSTER-CHECKS-2026 | https://docs.dagster.io/dagster-basics-tutorial/asset-checks | attached checks that verify asset properties are a strong precedent for check bundles on chosen slices |
| REF-DAGSTER-FRESHNESS-2026 | https://docs.dagster.io/guides/observe/asset-freshness-policies | warning versus failing freshness posture is a good model for Helm freshness lamps |
| REF-OPENLINEAGE-COLUMN-2026 | https://openlineage.io/docs/spec/facets/dataset-facets/column_lineage_facet/ | fine-grained column lineage supports compact explain/why rails rather than vague graph theater |
| REF-GRAFANA-ANNOTATE-2026 | https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/annotate-visualizations/ | saved dashboards with built-in annotations and tag filtering are a good overlay pattern for decks |
| REF-GRAFANA-SNAPSHOT-2026 | https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/snapshot/ | explicit snapshot payloads, share URLs, and delete keys are a strong model for frozen snapshot-share objects |
| REF-GRAFANA-SHARE-2026 | https://grafana.com/docs/grafana/latest/visualizations/dashboards/share-dashboards-panels/ | direct links, snapshots, embeds, and reports show that shared surfaces need distinct share classes |
| REF-OBSERVABLE-NOTEBOOKS-2026 | https://observablehq.com/documentation/notebooks/ | interactive editable documents are a useful model for bounded evidence-brief workbenches |
| REF-OBSERVABLE-HISTORY-2026 | https://observablehq.com/documentation/notebooks/history | version history, compare, restore, and fork-from-history are strong workbench patterns |
| REF-OBSERVABLE-FORKING-2026 | https://observablehq.com/documentation/notebooks/forking | explicit fork posture and workspace/visibility law are useful for brief forks |
| REF-SUPERSET-OVERVIEW-2026 | https://superset.apache.org/ | virtual datasets, semantic layer, cross-filters, and drill features are useful for semantic deck recipes and drill rails |
