# Helm: door packs, patrol routes, personal/shared splits, and review queues — 2026-03-28

## Current judgment

Keep the **datacube proof cluster** from rev0183.
Do **not** add a new pillar.
Do **not** retreat into a giant workspace object.

The next elegant move is downstream of the cluster:
**compose it into one premium everyday shell object and one premium recurring round.**

That means:
- **door packs** as tiny truthful control rooms
- **patrol routes** as bounded revisit loops over those packs and nearby views
- **personal-versus-shared splits** as a visible datacube law
- **peek surfaces** that stay derivative and reversible
- **review queues** that keep compare / review / promote honest

## What a door pack is

A **door pack** is not a new pillar and not a giant master object.
It is a shell-owned composition around one exact area of work.

A good first door pack would gather:
- one exact front-door handle
- one primary saved view
- one nearby triage lane
- one compare / review / promote queue
- one honest arrival / adoption badge
- one tiny peek surface
- optional watchpoint or glance chips
- optional personal overlays that remain visibly smaller than the shared pack

It should feel like:
- richer than a bookmark,
- calmer than a dashboard,
- and more truthful than a “workspace” blob.

## What a patrol route is

A **patrol route** is a bounded recurring round across exact existing shell objects.
Rev0183 already left this warm.
What changes here is the composition judgment:
**door packs are the best likely stops.**

A patrol route should:
- point at exact packs / views / compare surfaces,
- keep route definition shareable,
- keep resume state personal,
- allow one bounded dynamic lane when the source is explicit,
- and remain weaker than the source objects it visits.

## What the pillars should learn now

### Tiling Shell
A door pack can be the best way to reopen one activity-shaped layout without pretending remembered layout is current-live proof.

### Omnibox
The Omnibox should summon:
- exact saved views,
- exact door packs,
- patrol starts/resume,
- and queue items
without flattening them into one generic “open” action.

### Object Browser
This should likely be the home of pack inspection:
what the pack points at,
what is shared,
what is personal,
what is weak,
and what still needs review.

### Operations Center
This is where review queues,
triage pressure,
stale fences,
and blocked stronger actions become visible.
A queue badge should not impersonate settled truth.

### Desktop Flow
Flows should be able to target door packs,
produce restricted arrivals next to a pack,
and queue items for review/promote rather than pretending flow output is already adopted.

### Recall
Recall should distinguish:
- the historical receipt,
- the saved view,
- the door pack,
- the patrol resume point,
- and the current live thing.

### Exchange
Exchange should be able to move door packs and patrol definitions as **typed arrivals** that stay weaker than receiver-local adoption.

## Lessons we must learn from the past

### 1. Do not let one gorgeous landing page become fake truth
We have seen this repeatedly across tools:
if the landing surface becomes the center,
it starts impersonating live truth,
personal state,
shared state,
and historical memory all at once.
Door packs must stay small enough to resist this.

### 2. Imported usefulness must stay weaker than local adoption
A borrowed or shared object can be useful immediately.
That is good.
But it should not arrive already wearing the badge of local truth.

### 3. Personal overlays and shared definitions are different strengths
A filter I like,
a pack I shared,
and the team-facing default route are not the same thing.
Helm should keep those distinctions visible.

### 4. Preview is a luxury because it is reversible
Peek/Quick Look style surfaces are powerful precisely because they avoid commitment.
Helm should preserve that weakness as a feature.

### 5. A repeated round is better than a universal dashboard
Most recurring work is a bounded patrol,
not a command center.
Patrol routes should therefore become the humane answer to repetition.

## Steals worth keeping

- **GitHub saved views** for recurring stale-work rounds
- **Airtable My views / All views** for personal/shared separation
- **VS Code workspace/profile placement** for explicit scope law
- **Quick Look / Peek** for derivative preview posture
- **merge queue / update plans** for explicit review-promote lanes with stale fences

## Things not worth keeping

- giant dashboards that try to become workflow constitutions
- ambient profile/account/provider choice
- previews that silently write or adopt
- one queue that claims to settle everything
- personal tweak state mutating shared truth by accident

## Pull-the-trigger judgment

Yes,
but pull the trigger on a **specimen**,
not a worldview.

The right specimen now is:
- one exact saved view,
- one door pack around it,
- one restricted imported adjacent surface,
- one triage lane,
- one review/promote queue,
- one peek panel,
- and one patrol route that revisits the pack and one nearby compare surface.
