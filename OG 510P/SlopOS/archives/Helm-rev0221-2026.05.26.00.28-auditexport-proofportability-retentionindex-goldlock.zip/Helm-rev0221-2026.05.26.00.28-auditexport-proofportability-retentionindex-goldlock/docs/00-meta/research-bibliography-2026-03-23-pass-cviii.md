# Research bibliography — 2026-03-23 — pass CVIII

## Primary outside sources reviewed in this pass

1. Microsoft Learn — **ShareOperation Class**
   - URL: https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.sharetarget.shareoperation?view=winrt-26100
   - Why it mattered: Windows explicitly models `ReportStarted()`, `ReportDataRetrieved()`, `ReportCompleted()`, and background-submitted share status, which is direct evidence that payload acquisition and final completion are different truths.

2. Microsoft Learn — **Receive data — UWP applications**
   - URL: https://learn.microsoft.com/en-us/windows/uwp/app-to-app/receive-data
   - Why it mattered: the guide explains activation, supported formats, and share-status reporting, including the recommendation to tell the system when the app has acquired the data it needs.

3. XDG Desktop Portal — **FileTransfer**
   - URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
   - Why it mattered: transfer is explicitly staged as `StartTransfer` → `AddFiles` → `RetrieveFiles` → `StopTransfer`, with `autostop` and retrieval closure semantics.

4. Apple Developer Documentation — **NSItemProvider**
   - URL: https://developer.apple.com/documentation/Foundation/NSItemProvider
   - Why it mattered: Apple frames item providers as cross-process conveyors of data or files, which supports the idea that offered material and later acquired material are different stages.

5. Apple Developer Documentation — **loadFileRepresentation(...) / loadInPlaceFileRepresentation(...) / loadItem(...)**
   - URLs:
     - https://developer.apple.com/documentation/foundation/nsitemprovider/loadfilerepresentation%28for%3Aopeninplace%3Acompletionhandler%3A%29
     - https://developer.apple.com/documentation/foundation/nsitemprovider/loadfilerepresentation%28fortypeidentifier%3Acompletionhandler%3A%29
     - https://developer.apple.com/documentation/foundation/nsitemprovider/loadinplacefilerepresentation%28fortypeidentifier%3Acompletionhandler%3A%29
     - https://developer.apple.com/documentation/foundation/nsitemprovider/loaditem%28fortypeidentifier%3Aoptions%3Acompletionhandler%3A%29
   - Why it mattered: Apple keeps temporary-copy, in-place, and generic loaded-item acquisition as explicit different calls instead of one flattened materialization story.

6. Apple Developer Documentation — **NSFilePromiseProvider / NSFilePromiseReceiver / writePromiseTo / receivePromisedFiles**
   - URLs:
     - https://developer.apple.com/documentation/appkit/nsfilepromiseprovider
     - https://developer.apple.com/documentation/appkit/nsfilepromisereceiver
     - https://developer.apple.com/documentation/appkit/nsfilepromiseproviderdelegate/filepromiseprovider%28_%3Awritepromiseto%3Acompletionhandler%3A%29
     - https://developer.apple.com/documentation/appkit/nsfilepromisereceiver/receivepromisedfiles%28atdestination%3Aoptions%3Aoperationqueue%3Areader%3A%29
   - Why it mattered: file promises are fulfilled later, after the route has effectively crossed, which is excellent evidence for a separate materialization witness rung.

7. Android Developers — **Send simple data to other apps**
   - URL: https://developer.android.com/training/sharing/send
   - Why it mattered: senders are urged to use specific MIME types and temporary per-URI permissions, which reinforces that the receiving side's access mode and lifetime are part of the transfer truth.

8. Android Developers — **Receive simple data from other apps**
   - URL: https://developer.android.com/training/sharing/receive
   - Why it mattered: Google says users who tap a share target should be able to confirm and edit the shared content before using it, which is strong evidence that retrieved payload and final user-meaningful outcome are different seams.

9. Android Developers — **Provide Direct Share targets**
   - URL: https://developer.android.com/training/sharing/direct-share-targets
   - Why it mattered: direct targets should not be stale, and tapping one should land directly on the chosen subject, which helps keep route choice separate from later processing.

10. Chrome for Developers — **Receiving shared data with the Web Share Target API**
    - URL: https://developer.chrome.com/docs/capabilities/web-apis/web-share-target
    - Why it mattered: shared content lands in an app-defined route / handler, which reinforces that route choice and in-app materialization / effect are not one event.

## Companion-cube surfaces re-read in this pass

### SlopOS
- `docs/30-architecture/mcp-completion-import-boundary-v0.md`
- `docs/30-architecture/tool-ui-file-boundary-v0.md`
- `docs/30-architecture/import-to-docref-boundary-v0.md`
- `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`

### ViewFS
- `rfcs/0020-viewfs-keep-import-export-transfer-share-and-promises-separate.md`
- `rfcs/0008-viewfs-keep-handles-refs-and-receipts-separate.md`
- `rfcs/0012-viewfs-keep-previews-and-extractors-separate-from-authority.md`
- `rfcs/0017-viewfs-keep-checkpoints-clones-backups-and-publication-separate.md`

### Schell
- `docs/80-terminal/handoff-ladders-observation-truth-and-completion-humility.md`
- `docs/80-terminal/drop-witnesses-file-offers-and-path-translation-humility.md`
- `docs/80-terminal/share-witnesses-replay-capsules-and-publication-humility.md`
- `docs/80-terminal/commit-windows-and-visual-certainty.md`

### Steward
- `docs/30-architecture/activation-receipt-posture-v0.md`
- `docs/30-architecture/label-surface-posture-v0.md`
- `docs/30-architecture/trusted-chrome-lane-posture-v0.md`
- `docs/30-architecture/target-anchor-posture-v0.md`

## Bottom line

This pass reinforces a more honest Exchange sequence worth keeping warm:
**offer → take card → route witness → materialization witness → effect receipt**.
That looks meaningfully stronger than any one generic "shared" or "opened" badge.
