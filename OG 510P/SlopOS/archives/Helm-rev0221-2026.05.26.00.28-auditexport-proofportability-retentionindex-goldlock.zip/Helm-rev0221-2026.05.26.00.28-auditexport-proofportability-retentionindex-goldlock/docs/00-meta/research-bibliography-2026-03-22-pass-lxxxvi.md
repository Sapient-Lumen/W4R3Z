# Research bibliography — 2026-03-22 — pass LXXXVI

Used in this pass.

1. Kubernetes community — API conventions / conditions standardization KEP
   - URL: https://github.com/kubernetes/enhancements/blob/master/keps/sig-api-machinery/1623-standardize-conditions/README.md
   - used for: common condition schema as a product law rather than one-off badge folklore

2. Kubernetes docs — Pods / `status.observedGeneration`
   - URL: https://kubernetes.io/docs/concepts/workloads/pods/
   - used for: explicit observed-basis versus mutable desired basis

3. Argo CD docs — Resource health
   - URL: https://argo-cd.readthedocs.io/en/latest/operator-manual/health/
   - used for: compact health classes, observed-generation checks, and no-child-inheritance-by-default posture

4. GitHub docs — About status checks
   - URL: https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/collaborating-on-repositories-with-code-quality-features/about-status-checks
   - used for: pending/passing/failing overview and the distinction between checks and commit statuses

5. GitHub REST guide — checks
   - URL: https://docs.github.com/en/enterprise-server%403.20/rest/guides/using-the-rest-api-to-interact-with-checks
   - used for: status-versus-conclusion split and stale conclusion posture

6. Google Cloud Vertex AI docs — long-running operations
   - URL: https://docs.cloud.google.com/vertex-ai/docs/general/long-running-operations
   - used for: metadata + done + response/error compact operation status grammar

7. VS Code docs — Workspace Trust / Restricted Mode
   - URL: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
   - used for: blocked-but-browseable posture, visible restricted badge, and explicit disabled-feature lists

8. systemd NEWS
   - URL: https://cgit.freedesktop.org/systemd/systemd/tree/NEWS?id=v216
   - used for: active-state plus sub-state filtering and showing condition-check results in `systemctl status`
