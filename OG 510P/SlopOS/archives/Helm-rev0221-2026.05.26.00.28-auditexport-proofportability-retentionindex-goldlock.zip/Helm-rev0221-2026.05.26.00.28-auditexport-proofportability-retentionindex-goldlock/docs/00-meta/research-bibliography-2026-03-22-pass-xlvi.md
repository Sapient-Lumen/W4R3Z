# Research bibliography — 2026-03-22 — pass XLVI

Purpose: record the sources used for the context-loadout and contribution-witness pass.

## Primary sources

1. **Projects in ChatGPT**
   - project chats/files prioritized as context
   - project-only memory boundaries
   - why useful: validates scoped current context that should stay bounded rather than ambient
   - source: https://help.openai.com/en/articles/10169521-projects-in-chatgpt

2. **ChatGPT release notes — Add sources to your projects from anywhere**
   - add sources from apps, conversations, or quick text inputs
   - why useful: validates explicit gathered sources rather than only whatever happens to be open nearby
   - source: https://help.openai.com/en/articles/6825453-chatgpt-release-notes

3. **VS Code tools**
   - configure tools per current request
   - why useful: validates that tools are part of the current context contract, not invisible background weather
   - source: https://code.visualstudio.com/docs/copilot/concepts/tools

4. **VS Code prompt files**
   - workspace versus profile placement
   - tools/agent frontmatter
   - tool list priority
   - prompt source visibility
   - why useful: validates typed, scoped, inspectable current request setup
   - source: https://code.visualstudio.com/docs/copilot/customization/prompt-files

5. **VS Code AI customization overview**
   - instructions, prompts, agents, skills, hooks, MCP
   - trust-gated parent discovery
   - centralized customization editor
   - why useful: validates layered request context that is explicit and trust-aware rather than ambient
   - source: https://code.visualstudio.com/docs/copilot/customization/overview

6. **VS Code 1.110 release notes**
   - Agent Debug panel shows loaded prompt files, skills, hooks, and other customizations for a session
   - why useful: validates a compact witness for what actually got loaded
   - source: https://code.visualstudio.com/updates/v1_110

7. **VS Code Workspace Trust**
   - Restricted Mode and trust-gated enablement
   - why useful: validates weaker starting posture for imported/shared loadouts
   - source: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust

8. **Gemini in Chrome**
   - current tab by default
   - up to 10 shared open tabs on computer
   - why useful: validates explicit selected context rather than ambient browser state
   - source: https://support.google.com/chrome/answer/16283624

9. **Google Workspace Privacy Hub**
   - users can stop sharing the current tab or any selected tabs
   - why useful: validates removability and ongoing operator control over selected context
   - source: https://knowledge.workspace.google.com/admin/gemini/generative-ai-in-google-workspace-privacy-hub

10. **Linear Custom Views**
    - durable filtered views that can be saved, shared, favorited, subscribed to, and owned
    - why useful: validates explicit saved views as ingredients rather than hidden global mode
    - source: https://linear.app/docs/custom-views

11. **Linear Projects**
    - attached issue views as project tabs
    - copy view link / favorites / tabs / shared access posture
    - why useful: validates views as explicit current work ingredients inside a scoped frame
    - source: https://linear.app/docs/projects

12. **Linear changelog — advanced filters and subscribe to a view**
    - AND/OR filters, subscriptions, dashboards
    - why useful: validates strong explicit view composition and notifications without ambient magic
    - source: https://linear.app/changelog

13. **Notion working with views**
    - dashboard views made from widget views over different data sources
    - why useful: validates multi-view compositions as explicit ingredients rather than hidden context
    - source: https://developers.notion.com/guides/data-apis/working-with-views

14. **Google Docs tabs**
    - current tab versus all tabs export/print
    - why useful: validates current-subthing versus whole-group distinction
    - source: https://support.google.com/docs/answer/15499791

15. **Google Sheets with Gemini**
    - analysis steps
    - sources reveal
    - action preview card before apply
    - why useful: validates contribution witnesses and pre-apply review surfaces
    - source: https://support.google.com/docs/answer/14356410

## SlopOS sources re-read this pass

1. `docs/30-architecture/attestation-collateral-status-boundary-v0.md`
2. `docs/30-architecture/attention-durable-status-boundary-v0.md`
3. `docs/30-architecture/openuri-recent-items-boundary-v0.md`
4. `docs/30-architecture/openuri-materialization-boundary-v0.md`
5. `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`
6. `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`

## Why these sources mattered

This pass was not about adding another pillar.
It was about checking whether today’s strongest tools are rewarding:
- explicit current context selection,
- current-versus-whole scope choices,
- trust-aware request setup,
- visible loaded context,
- visible used sources,
- and preview-before-apply actions.

They are.
