# SlopOS companions evaluation — 2026-03-23 — pass CLXVIII

## Theme
After warming **observation acks + visibility frontiers**,
the next useful question is:

**once Helm can say who has seen the newer state,
how should it say what class of read the user is actually looking at,
what staleness or stability bound applies,
and what stronger reread is required next?**

The companion family converges very strongly on that question.

## SlopOS

### What to keep
Keep SlopOS's exact witness basis discipline.
Keep its refusal to let ambient `latest` or unbounded helper reads stand in for reviewed truth.

### What that means for Helm
SlopOS implies a direct law for Helm:
**a serious read should stay bound to explicit footing and explicit strength,
not to folklore about whatever happened to be fetched most recently.**

### What not to steal
Do not import all of SlopOS's provider-local nouns into shell chrome.
Steal the exactness law,
not the namespace.

## Ward

### What to keep
Ward is the strongest local teacher for this pass.
Keep its:
- read cuts,
- staleness budgets,
- ambiguity windows,
- revalidation fences,
- stable frontier posture.

### What that means for Helm
Ward is already saying that:
- current-enough orientation,
- stable committed visibility,
- bounded stale read,
- and high-risk reread before consequence

are different truths.
That maps almost directly onto Helm's need for read guarantee cards and consistency cuts.

## Schell

### What to keep
Keep Schell's generation lamps,
since-cut supplements,
and caught-up-through humility.

### What that means for Helm
Schell reinforces the rule that a lane can be honest only through some boundary.
That is exactly the emotional posture Helm needs for `exact stale`, `bounded stale`, `stable frontier`, and `current strong` distinctions.

## ViewFS

### What to keep
Keep ViewFS's split between:
- observed validator,
- private writable session,
- commit precondition,
- committed version,
- receipt/history.

### What that means for Helm
The next thing Helm should preserve beside those is:
**the class of read through which the committed version is currently being viewed.**
A committed version can still be:
- private,
- not yet search-visible,
- stable but not freshest,
- or cheaply readable only behind a safe cut.

## Steward and Foundry

### What to keep
Keep Steward's readiness-generation posture and Foundry's stale-status fences.

### What that means for Helm
Both teach that old green status can remain historically true while failing to describe the strongest current readable truth.
That is strong support for keeping read posture explicit.

## Synthesis
The companion family is now pushing Helm toward one compact support pair:
- **consistency cuts** — exact read footing with explicit strength or staleness posture,
- **read guarantee cards** — the tiny nearby rendering of what class of truth the user is actually seeing.

That is a much better next move than:
- a bigger datacube center,
- a universal consistency layer,
- or another pillar.

## Keep / drop summary

### Keep as law
- exact basis for serious reads
- stable frontier smaller than head truth
- staleness and ambiguity are truths, not defects to hide
- stronger consequences may require stronger rereads

### Keep as object candidates
- consistency cut
- read guarantee card
- maybe later compare-two-cuts strip

### Drop for now
- one shell-wide consistency ontology
- imported provider-local vocabulary in everyday Helm chrome
- any move that lets one visibility ack silently impersonate strongest current read truth
