# Helm — reconcile recipes and resolution memories

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one universal branch/merge/sync manager.
Do **not** let divergence posture imply that the shell already knows how reconciliation should happen.

The strongest next move is smaller:
**warm reconcile recipes + resolution memories as the shell-owned seam after upstream tethers and divergence cards.**

Helm can already say:
- what footing crossed a seam,
- what the receiver could verify,
- what local slice was grafted,
- what adoption receipt proves a local floor exists here,
- what origin that local floor still tracks,
- and whether the local floor is in sync, ahead, behind, diverged, detached, or origin-lost.

What it still answers too weakly is:
- **what reconcile class is intended now?**
- **does this move merge, replay local changes on top of upstream, take upstream wholesale, preserve only a subset, or detach?**
- **which conflict choices can be suggested from prior human work, and which still require a fresh review?**

## The lesson Helm must learn from the past

Past systems keep replaying a reconciliation mistake:
**they tell you that two things diverged, but they hide the exact class of repair they are about to perform.**

That creates spooky shell behavior:
- a review surface suggests `update`, but does not say whether it will merge or rewrite local lineage;
- an auto-resolution path reuses an old conflict choice without saying it is only a remembered suggestion;
- a failed merge/update leaves half-applied aftermath, but the shell still looks calm because it flattened restore posture into `try again`.

Helm should refuse the myth that `diverged` automatically means `merge me however you like`.

## What the outside world is teaching right now

### Git / GitHub: divergence needs an explicit reconcile class
Git says that when local and remote branches have diverged,
you need to specify how to reconcile them with `--rebase` or `--no-rebase`.
GitHub likewise lets a pull request branch be updated with either a merge commit or a rebase.
That is a strong Helm precedent:
**the shell should make reconcile class explicit rather than burying it in one generic update verb.**

### Git range-diff: compare the *new proposed series* against the *old proposed series*
`git range-diff` compares two versions of a patch series or two commit ranges.
That pressures Helm toward a delightful idea:
**compare the reconcile proposal itself**, not just the state before and after.

### Git rerere: remembered resolutions are useful, but they are not magic
`git rerere` records conflicted automerge results and corresponding hand-resolved results,
and can later apply previously recorded hand resolutions.
But Git also preserves abort/forget flows,
and related commands expose `--no-rerere-autoupdate` specifically so you can double-check the reused result before accepting it.
That is a great Helm lesson:
**resolution memory should stay suggestion-grade and revocable.**

### Figma: conflict choice can be side-by-side, all-or-nothing upstream intake, and restore-aware
Figma notifies branches when updates from main are available,
but does not allow cherry-picking only some upstream changes from main.
Conflicts are reviewed side-by-side with explicit `main` versus `branch` picks,
and incomplete merge/update docs tell people to either repeat conflict resolution or restore to a `Before update` / `Before merge` checkpoint.
That suggests another Helm rule:
**reconcile recipes should say whether intake is whole-upstream or subset-based, and restore should be a first-class verb.**

### Kubernetes Server-Side Apply: force is a different move from normal apply
Server-Side Apply tracks field managers and rejects conflicting writes unless the client forces an override, which transfers ownership.
That pressures Helm to keep ordinary reconcile, forced take, and ownership-transfer consequences visibly different.

## What the companion cubes are teaching now

### Keep from SlopOS
Keep conflict-key discipline,
minimal serialization boundaries,
and explicit replication classes.
A reconcile recipe should name its class and consequence surface,
not dissolve into generic sync folklore.

### Keep from Ward
Ward's read cuts and revalidation fences say a reconcile recipe must bind one exact compared basis.
A recipe that cannot name its compare cut is too vague.

### Keep from Schell
Schell keeps strongest-next-verb pressure honest.
That is excellent here:
- maybe the right next verb is `merge`,
- maybe it is `replay local on latest`,
- maybe it is `take upstream`,
- maybe it is `restore before update`,
- and maybe it is `detach`.

### Keep from ViewFS
ViewFS is still the best teacher for keeping carried packets,
remembered designators,
current handles,
and durable receipts separate.
A reconcile recipe should stay like a plan object,
not collapse into either the carried patch or the result floor.

### Keep from Steward
Steward's replay-diff and review-before-run pressure is exactly what Helm needs for remembered conflict choices.
A prior resolution can be a useful hint,
but it should stay visibly weaker than a fresh, basis-bound review.

## Bright steals for Helm

1. **Reconcile recipe**
   - one explicit shell plan over a divergence card saying `merge`, `rebase/replay-local`, `take upstream`, `pick subset`, `detach`, or `rebind later`.
2. **Resolution memory**
   - one bounded memory of prior human conflict choices, keyed by conflict shape and compare basis, offered as a suggestion rather than authority.
3. **Proposal-vs-proposal compare**
   - a tiny `range-diff`-style compare lane for two versions of a reconcile plan.
4. **Restore-before-update / restore-before-merge checkpoints**
   - especially valuable when a reconcile path partially succeeds or leaves residue.
5. **Force/override badges**
   - clearly stronger than ordinary reconcile and clearly different from later settlement.

## What not to keep

Do not keep:
- one giant universal VCS/merge manager,
- silent auto-reconcile on every divergence,
- or unreviewed remembered conflict choices that look like shell truth.

Keep the shell grammar small:
one recipe,
one result/repair surface,
and one optional remembered-resolution lane.

## Why this makes Helm super awesome

This is the premium move that keeps reconciliation powerful **without** making it spooky.
A person can ask:
- `what reconcile class is this?`
- `will this rewrite local lineage or preserve it?`
- `is this whole-upstream intake or subset-based?`
- `are these remembered conflict picks just hints?`
- `can I restore to the before-update footing if this goes wrong?`

That is better than a bigger cube.
Not because Helm promises one final merge universe,
but because it keeps **divergence posture, reconcile class, remembered conflict hints, and restore posture** visibly different.
