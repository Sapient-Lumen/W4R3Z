# Helm: turn clocks, escalation rails, and exact time-kind truth — 2026-03-23

After **attention-turn chips** and **next-actor rails**,
Helm now has a tighter adjacent question:

**once the shell knows who should act,
how should it say by when,
under what exact kind of clock,
and what happens if the clock expires,
without collapsing promise,
wait,
snooze,
maintenance,
retry,
and escalation into one generic countdown?**

The most promising next cluster is:
- **turn clocks**
- **escalation rails**
- and maybe later **timer-provenance cards**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. every clock looks like a due date, or
2. the shell knows who should act,
   but still cannot answer the humane tiny question:
   **what kind of time pressure is actually in force here?**

Operators need a third answer:
- broad owner remains visible,
- current actor remains visible,
- current packet / footing remains visible,
- **and one small time object says what kind of clock is active now and what happens when it expires.**

## Candidate objects

### 1. Turn clock
A tiny typed timing rendering.

Good early fields:
- exact subject / footing / packet ref
- actor set or lane ref
- **clock kind**:
  - `nudge-after`
  - `due-by`
  - `review-window`
  - `wait-until`
  - `ack-timeout`
  - `escalation-at`
  - `snooze-until`
  - `wake-on-new-activity`
  - `maintenance-through`
  - `retry-not-before`
- exact origin:
  - `promise`
  - `policy`
  - `maintenance`
  - `silence`
  - `snooze`
  - `retry-advice`
- optional expiry consequence
- optional strongest nearby exit

### 2. Escalation rail
A slightly richer nearby object that can say:
- current actor set
- current clock
- what happens on expiry:
  - `nudge same actor`
  - `re-notify`
  - `widen audience`
  - `hand to next actor`
  - `return to triggered`
  - `reopen review`
  - `hold stronger action`
- why that consequence exists
- whether the consequence is policy,
  promise,
  or merely suggestion

### 3. Timer-provenance card (later)
A later inspectable card that can say:
- issuer or source of the clock
- exact footing it binds to
- whether the clock is relative or absolute underneath
- whether the host can prove pause/resume
- whether the clock was superseded,
  renewed,
  or expired

## What Helm should probably do now

### 1. Keep promise clocks separate from policy clocks
`I’ll review by noon`
is not the same thing as
`ack timeout returns in 20m`.

### 2. Keep maintenance clocks separate from health
A maintenance-through clock can be honest without implying the underlying slice is healthy.

### 3. Keep snooze clocks separate from deadlines
`wake me tomorrow`
and
`must answer by tomorrow`
are different truths.

### 4. Keep retry hints separate from permission
`retry not before 14:20`
is timing advice,
not success promise or authority.

### 5. Keep escalation separate from silent widening
If the clock expires,
the shell should say whether it merely nudges,
widens,
reopens,
or blocks.
That should not be hidden in dead-looking buttons or folklore.

### 6. Let one subject carry several small clocks
A reviewed slice may honestly have:
- a current actor review window,
- a current maintenance silence,
- and a current retry-not-before hint
at the same time.

## Guardrails

1. **Do not let turn clocks impersonate commitment witnesses.**
2. **Do not let ack timeout impersonate human promise.**
3. **Do not let maintenance-through impersonate recovery.**
4. **Do not let retry-not-before impersonate future success.**
5. **Do not let escalation rails become a giant workflow scheduler.**
6. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

> owner stays Maya.
> current turn stays Alex.
> current packet is `latest-push-recheck`.
> current turn clock is `review-window until Tue 10:00`.
> if it expires,
> escalate to `release-owner recheck`.
> maintenance silence ends at 09:30 but evaluation is still live underneath.
> retry advice on publish is `not before 14:20`.
> none of those clocks changes the underlying footing or truth class by themselves.

That would make Helm much better at telling the truth about time pressure
without turning it into a giant ticketing or scheduler empire.
