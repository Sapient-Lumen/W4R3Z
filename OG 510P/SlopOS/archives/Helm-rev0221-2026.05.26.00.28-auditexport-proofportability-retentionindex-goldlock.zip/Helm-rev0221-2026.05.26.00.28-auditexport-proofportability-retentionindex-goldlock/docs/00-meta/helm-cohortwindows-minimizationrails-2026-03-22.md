# Helm synthesis — cohort windows + minimization rails — 2026-03-22

## The new pressure

Helm now has many useful bounded objects:
views,
handles,
subscriptions,
watchpoints,
briefs,
response kits,
packets,
warrants,
receipts,
reveal windows,
audience ladders,
authority windows.

But one practical question was still under-modeled:

**what exact subset is this ask, reveal, export, route, or action actually about right now?**

## The answer that now looks strongest

### Cohort windows
A shell-owned bounded object that says:
- what exact selected subset is in play,
- where it came from,
- how it was chosen,
- whether it is still live,
- and what broader family it does **not** imply.

### Minimization ladders
A humane chooser that says:
- exact item
- selected cohort
- saved cohort / view result
- activity cohort
- wider family only when justified

## Why this matters

Without this law, Helm risks flattering itself in exactly the wrong places:
- a saved view result becomes whole-project truth,
- a share/export widens from selected results to whole source,
- a helper proposal operates on the whole provider because “that is easier,”
- a retry silently broadens reach,
- a loadout gets mistaken for an execution cohort.

## Good steals

- chooser-first exact handles
- selected-photos / current-tab / chosen-file style language
- incremental widening only when feature intent demands it
- visible why when broader reach was necessary
- re-prompt / reselection / revalidation when exact subset truth decays

## Things to reject

- default whole-account/workspace reach
- auto-widen on failure
- one vague “selected” badge that hides exact blast radius
- turning minimization into a giant policy studio

## Pull-the-trigger judgment

This looks worth warming now.
Not as a pillar,
and not as a giant governance suite,
but as one compact cross-cutting family:

- `cohort-window`
- `minimization-ladder`

That would make several existing Helm moves sharper at once:
context loadouts,
claim envelopes,
reveal windows,
authority windows,
action warrants,
Exchange,
Recall,
and Operations Center.
