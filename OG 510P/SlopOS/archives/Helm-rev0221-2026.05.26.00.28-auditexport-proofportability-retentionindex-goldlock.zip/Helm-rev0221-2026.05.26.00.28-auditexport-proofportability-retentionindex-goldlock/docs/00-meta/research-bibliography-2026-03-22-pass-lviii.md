# Research bibliography — 2026-03-22 — pass LVIII

1. **Grafana Docs — Create and link alert rules to panels**
   - source: https://grafana.com/docs/grafana/latest/alerting/alerting-rules/link-alert-rules-to-panels/
   - used for: panel-linked alert rules, create-from-panel flow, dashboard/panel annotations, and explicit warning that panel queries and alert-rule queries are not synchronized

2. **Grafana Docs — Configure mute timings and active time intervals**
   - source: https://grafana.com/docs/grafana/latest/alerting/configure-notifications/mute-timings/
   - used for: mute timings suppress notifications without stopping evaluation or removing alert instances from the UI

3. **Grafana Docs — Configure silences**
   - source: https://grafana.com/docs/grafana/latest/alerting/configure-notifications/create-silence/
   - used for: fixed-window silences that suppress notifications but do not interrupt alert evaluation

4. **Kibana Docs — Create and manage alerting rules with Kibana**
   - source: https://www.elastic.co/docs/explore-analyze/alerting/alerts/create-manage-rules
   - used for: rule health, flapping detection, summary-versus-per-alert actions, snooze versus disable, and continued checks during snooze

5. **Datadog Docs — Query Value Widget**
   - source: https://docs.datadoghq.com/dashboards/widgets/query_value/
   - used for: narrow status widgets with conditional formatting and a clear query-backed value posture

6. **Sentry Docs — Metric Alert Configuration**
   - source: https://docs.sentry.io/product/alerts/create-alerts/metric-alert-config/
   - used for: filters translating into a Discover query shown in the alert-configuration chart

7. **Grafana Docs — Manage library panels**
   - source: https://grafana.com/docs/grafana-cloud/visualizations/dashboards/build-dashboards/manage-library-panels/
   - used for: reusable panels plus visible “where is this being used?” posture

8. **Atlassian Analytics — Dashboard settings**
   - source: https://support.atlassian.com/analytics/docs/dashboard-settings/
   - used for: cache duration as explicit freshness posture and the performance tradeoff of fresher data

9. **Atlassian Analytics — Set up dashboard subscriptions**
   - source: https://support.atlassian.com/analytics/docs/set-up-dashboard-subscriptions/
   - used for: refreshing cached chart data before subscription delivery when the cache is expired or older than 30 minutes

10. **Atlassian Analytics — Refresh and examine chart data**
    - source: https://support.atlassian.com/analytics/docs/refresh-and-examine-chart-data/
    - used for: per-chart manual refresh and chart-data inspection as a stronger follow-on path
