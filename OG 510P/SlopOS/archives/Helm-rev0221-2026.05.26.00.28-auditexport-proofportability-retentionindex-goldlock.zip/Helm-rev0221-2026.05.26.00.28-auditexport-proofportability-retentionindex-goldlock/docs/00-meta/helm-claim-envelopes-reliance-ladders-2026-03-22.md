# Helm claim envelopes + reliance ladders — 2026-03-22

Purpose: name the next compact shell move that can make Helm smarter and more truthful once current context and contribution posture are already explicit.

## Main idea

Helm likely wants one shell-owned object for:

**what exactly is this output claiming, and how strong is that claim?**

That object should be a **claim envelope**.

And once the claim is on screen,
Helm likely wants one small answer to:

**what is the right next step for this envelope? inspect, double-check, save, cite, share, adopt, or apply?**

That next-step grammar should be a **reliance ladder**.

## Why this matters now

Helm already has several useful things that are close but not identical:

- **context loadouts** — what was intentionally in play
- **contribution witnesses** — what actually influenced the run
- **review strips** — tiny preflight surfaces
- **route witnesses** — transfer/action route truth
- **current-live beacons** — stronger cues for what is really live now
- **memory seeds** — explicit remembered hints and warnings
- **saved view objects** — durable perspectives and queries

What Helm still lacks is one small shell-owned answer to:

- this sentence is based on exact current local state
- this sentence is source-backed but still needs checking
- this statement is a synthesis/inference across multiple inputs
- this bit is remembered guidance or preference
- this is a proposed action, not a completed change
- this point is unresolved or on hold

Without that,
Helm risks slipping back into:
- source-chip theater,
- one-box answer flattening,
- proposals that look like facts,
- and inference that wears the badge of observation.

## What a claim envelope is

A **claim envelope** is a shell-owned bounded output object for one ask, compare, proposal, summary, route recommendation, or plan.

A good early envelope should be able to carry mixed claim classes such as:
- **observed** — exact current local/live basis
- **sourced** — backed by explicit files/links/citations
- **derived** — inference or synthesis across inputs
- **remembered** — explicit seed, preference, instruction, or prior saved note
- **proposed** — a next action that is not yet applied
- **unresolved** — a hold, missing evidence, or low-confidence gap

The important thing is not the noun.
The important thing is the law:

**output claim class is explicit.**

## What a reliance ladder is

A **reliance ladder** is the honest next-step surface next to an envelope.
It should be able to say things like:
- inspect sources
- double-check
- save as source
- save as review ticket
- cite/quote/share
- adopt into activity memory
- preview/apply this change
- hold / rereview because the basis is stale or weak

This is a much better Helm magic than “looks grounded” or one giant confidence number.

## Relation to nearby Helm objects

### Not a contribution witness
A contribution witness explains what got used.
A claim envelope explains what the output is saying.

### Not a review strip
A review strip is a tiny preflight or readiness surface.
A claim envelope is the bounded output itself.

### Not a receipt
A receipt proves a stronger completed action or durable outcome.
A claim envelope may sit before that point,
or link to it when the stronger move is done.

### Not a saved view object
A saved view gives one durable perspective.
A claim envelope may cite or embed a view basis,
but the envelope is still a result object, not the view itself.

## Why this seems especially worth stealing

Today’s best products are getting much better at:
- showing sources,
- exposing analysis steps,
- previewing actions before apply,
- revealing loaded context,
- and warning that sources themselves may still be imperfect.

That is exactly where Helm can be unusually good.
The shell can make output class and reliance posture first-class across:
- Omnibox
- Object Browser
- Recall
- Exchange
- Operations Center
- Desktop Flow
- terminal/capshell
- and any AI-assisted ask/action surface

## Super-awesome moves this unlocks

### 1. Mixed claim envelopes instead of flat answer boxes
One answer can visibly mix:
- observed current-state claims,
- sourced claims,
- derived synthesis,
- remembered warnings,
- and proposed changes.

### 2. Tiny “why trust this?” chips without fake certainty
Not giant provenance theater.
Just one honest compact envelope with:
- claim class
- freshness hint
- source or basis affordance
- and next-step ladder

### 3. Better proposal UX
A proposed route, edit, launch, or change can sit as:
- proposal
- preview
- apply/adopt
- receipt
instead of one flattened blob.

### 4. Save outputs without laundering them into timeless truth
The operator can save an envelope as:
- project source
- review ticket
- shelf item
- activity note
- claim packet
while keeping freshness and claim class visible.

### 5. Bring AI help closer to shell honesty
Helm can feel dramatically smarter without becoming more mystical,
because it can say both:
- what was in play,
- and what the result actually claims.

## What not to steal

- do not invent one universal confidence score
- do not let citations impersonate correctness
- do not let proposals impersonate receipts
- do not save every response by default
- do not build a giant provenance graph before one tiny envelope works

## Pull-the-trigger judgment

Still yes:
- **saved view objects**
- **checkpoint branches**

Now also worth defining as support contracts:
- **claim envelopes**
- **reliance ladders**

If Helm gets this right,
it can feel more trustworthy than current AI-rich shells precisely because it refuses to flatten different claim strengths into one answer box.
