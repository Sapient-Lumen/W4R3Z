# Helm: pillar decks and recipe ladders — 2026-03-23

## The call in this revision

Keep the seven pillars.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes** and the **bounded rehearsal deck** as the current datacube law.

But do not standardize one universal deck system yet.

The best next move is smaller:

**give every pillar one first deck recipe and one honest ladder for materialize / refresh / snapshot / share / reopen.**

That fleshes Helm much more concretely without pretending we already know the final shell workbench constitution.

## Why this now looks wiser than more nouns

Helm already has plenty of warm luxuries:
- reviewed slices
- basis explorers
- rule-insight cards
- guarded promotion ladders
- patrol decks
- settlement witnesses
- calibration witnesses
- deck recipes

What it still lacks is one product-shaped answer to this question:

**if every pillar gets a humane pre-act loop,
what starter object would an operator actually invoke?**

The answer now looks like:
- not a giant home dashboard,
- not a notebook religion,
- not another pillar,
- but one **pillar-specific recipe** that materializes one bounded deck on demand.

## What current systems are teaching

The outside world is unusually aligned here:
- one footing can support multiple explicit views
- templates are starters,
  not authority
- repeated investigations get much better when compare context survives reuse
- sync and sharing should climb explicit ladders
- none of that removes the need for exact-subject,
  grouped-check,
  and drift-honest instances

That is exactly what Helm needs.

## What to keep from old inspirations

Keep:
- many views over one footing
- saved starters
- compare-to-earlier reuse
- compact investigation feel
- explicit share classes
- comments / markers / residue that survive reuse

Drop or defer:
- one universal notebook plane
- one giant dashboard religion
- templates that quietly become current live truth
- implicit collaboration by ambient sync
- any saved layout that impersonates exact present authority

## First recipe ideas by pillar

### 1. Tiling Shell — landing / repair deck
A starter for one exact landing,
restore,
or repair act.
Faces:
- exact act
- adjacent or grouped target context
- repair or fallback lane
- drift sentry
- later settlement reopen

### 2. Omnibox — least-widening launch deck
A starter for one exact result that might turn into action.
Faces:
- exact subject
- least-widening alternatives
- rule-insight lane
- freshness or drift lane
- later route / receipt reopen

### 3. Object Browser — reviewed-slice publish deck
A starter for one explicit reviewed slice or cohort window.
Faces:
- reviewed membership
- cohort delta
- reveal / publish rule lane
- audience rung
- later settlement / calibration reopen

### 4. Operations Center — guarded promotion deck
A starter for one stronger promotion candidate.
Faces:
- why-this-would-pass
- grouped-check lane
- pause / regroup / rebuild posture
- promotion rung
- later aftermath / miss reopen

### 5. Desktop Flow — packet-to-receipt deck
A starter for one prepared act moving toward execution.
Faces:
- compiled packet
- validator or rule lane
- predicted effect or live compare
- headroom / adaptation sentry
- later effect receipt / miss reopen

### 6. Recall — restore / rebind deck
A starter for one exact historical footing.
Faces:
- original footing
- current bind or repair lane
- drift sentry
- difference from historical expectation
- later settled remainder or miss reopen

### 7. Exchange — audience / route deck
A starter for one route or audience change.
Faces:
- exact recipient or route
- nearby audience delta
- policy / route insight
- grouped send or publish context
- later delivery / settlement reopen

## The ladders Helm should now make explicit

### Recipe ladder
- local scratch recipe
- personal reusable recipe
- shared starter recipe

### Deck ladder
- materialized deck instance
- refreshed/rechecked deck instance
- frozen snapshot / handoff deck
- later settlement or calibration reopen

These ladders matter because the past keeps teaching the same failure:
people treat a saved starter,
a stale instance,
a shared snapshot,
and a current live deck as if they were one thing.
They are not.

## What could make Helm feel super awesome

- every pillar has one obvious starter deck instead of one abstract promise
- operators can reuse starter shapes without inheriting fake live truth
- comments,
  markers,
  and compare context can survive reuse
- every materialized deck still binds exact footing and drift posture
- frozen handoffs stay frozen,
  while later settlement and calibration reopen the original footing

## Product judgment

The next wise pull is still not another pillar.
The next wise pull is also probably not a giant universal deck spec.

The next wise pull is:

**collect first pillar-specific deck recipes,
prove a few high-pressure specimens,
and keep recipe-vs-instance-vs-snapshot-vs-outcome unmistakably separate.**

That is the cleanest way to make Helm more concrete,
more reusable,
and more awesome without freezing too much too early.
