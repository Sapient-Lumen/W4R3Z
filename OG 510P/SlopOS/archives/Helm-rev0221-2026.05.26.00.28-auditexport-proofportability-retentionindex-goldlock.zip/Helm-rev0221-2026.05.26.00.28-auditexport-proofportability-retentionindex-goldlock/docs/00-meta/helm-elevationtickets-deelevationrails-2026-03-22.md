# Helm: elevation tickets + de-elevation rails

This pass asks a small but important shell question:

**what object should Helm use when a person may temporarily step into stronger power without pretending that possibility, pending approval, active borrowing, and hot use are all the same thing?**

## Main answer

Add two warm cross-pillar candidates:
- **elevation tickets**
- **de-elevation rails**

Keep them small.
Do not turn them into a giant IAM center.

## Elevation ticket

An **elevation ticket** is a compact shell-owned temporary-power object.
It sits between a front door / review / warrant and a live authority window.

It should be able to say:
- what stronger family is being asked for
- exact or reduced scope
- who is asking
- why they are asking
- any incident / support / approval reference
- what extra authentication or condition still applies
- requested duration and max duration
- whether it is merely eligible,
  currently requested,
  pending approval,
  approved-but-not-active,
  active,
  denied,
  withdrawn,
  expired,
  or historical only
- what nearby live borrowed window or hot beacon it created
- what early-end path exists

## Why this is not just an authority window

An authority window says **what power exists now or recently existed**.
That is already useful.

But Helm is still missing one compact object for the weaker/liminal states:
- may request later
- requested but not yet approved
- approved but not yet active
- active for duration X under condition Y

Those states are too important to leave as provider folklore.

## Why this is not just a review ticket

A review ticket is about stable reviewable basis.
An elevation ticket is about temporary stronger power.
They may link,
but they are not the same object.

One obvious good pattern is:
- review ticket
- elevation ticket
- authority window
- active-borrow beacon

That ladder is much more truthful than one generic “approved” badge.

## De-elevation rail

A **de-elevation rail** is the nearby shell-owned rail for leaving stronger temporary power before timeout.

Good next moves might include:
- end now
- end after current exact act
- narrow from wider scope to reduced scope
- move stronger work into an isolated lane
- keep eligibility but drop active borrowing
- inspect historical receipt

That is intentionally different from:
- a brake rail for an on-air sensor/capture state
- a generic revoke handle
- a historical receipt

## Why this makes Helm more awesome

Because most systems still make temporary stronger power feel either:
- scary and bureaucratic,
- or dangerously sticky and ambient.

Helm can do better by making it:
- compact,
- trusted-chrome hosted,
- reason-bearing,
- duration-bearing,
- scope-honest,
- and easy to end early.

That is the kind of move people actually feel.

## Best early proof

A first specimen should probably be one narrow family such as:
- one exact route/apply family,
- one provider/action family,
- or one helper-lane execution family.

The proof only needs:
- eligible
- pending approval
- active for N minutes
- expiring soon
- end now / narrow / inspect receipt

If that specimen works,
Helm gets a very shell-native answer to temporary stronger power without adding a giant new constitution.
