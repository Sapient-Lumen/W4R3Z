# Helm bright steals and hard refusals — 2026-03-22

Purpose: collect the best ideas worth stealing now,
name the lessons Helm absolutely must learn from the past,
and separate them from the temptations that only look brilliant for five minutes.

## Lessons we must learn from the past

### 1. Hidden chooser logic destroys trust
If several candidates are plausible,
the shell should not silently pick a winner and then pretend the user chose it.

### 2. Nearby success is not exact success
Revealing something nearby,
reopening something adjacent,
or sharing something broader is not the same act.

### 3. Labels are not identity
Titles,
badges,
profile names,
restored names,
and imported labels are useful orientation,
not durable truth by themselves.

### 4. Saved,
historical,
and live state must not collapse
A saved starter,
a past checkpoint,
and the current-live lane are three different strengths.
Flattening them makes Recall and Exchange lie.

### 5. Broad grants make powerful products feel cheap
The best current systems are getting narrower,
more moment-of-use,
and more exact.
Helm should too.

### 6. AI must suggest before it acts
Invisible action is exactly the wrong thing for shell law.
The right shape is proposal,
reason,
operator decision,
then receipt.

## Bright steals

### From Warp and Raycast
- parameterized front doors
- typed arguments
- linkable/summonable starters
- small reusable commands that do not impersonate live continuity

### From Arc and Figma
- inert peek
- explicit promote steps
- review statuses
- checkpoints around stronger merge/adopt moves

### From Chrome,
Android,
Google Drive,
and Google Workspace
- current-only or exact-subject grants
- selected-cohort access instead of whole-world access
- user-visible grant rungs

### From GitHub
- review bound to exact basis
- stale-on-diff downgrade
- most-recent-push approval posture for sensitive paths

### From Linear
- triage lane as a first-class inbox
- explain-why suggestions
- operator-owned accept / decline / inspect posture

## Moves that could make Helm super awesome

### 1. A universal strong-act preflight strip
Before any strong act,
Helm should be able to show:
- exact subject
- scope/cohort
- reviewed basis
- freshness / drift
- why this suggestion exists
- next stronger rung

### 2. A tiny witness-chip grammar across pillars
Small chips like:
- `current-live`
- `historical`
- `restored`
- `preview`
- `restricted`
- `stale`
- `suggested`
- `override`

would make the whole shell feel more trustworthy very quickly.

### 3. Continuity postcards instead of fake restore confidence
Recall can become dramatically more humane if it tells the truth in one tiny card.

### 4. Receiver-fit before import/adopt
Exchange gets much better when arrival is not yet adoption.
A receiver-fit card can say what matched,
what is local-only,
and what still needs a human decision.

### 5. Suggestion-first ops,
not automation-first ops
Operations Center can feel magical if triage,
routing,
and repair suggestions are rich and explainable,
without becoming hidden shell law.

## Hard refusals

- one giant omniscient cube
- one universal workspace object
- one universal AI action plane
- dashboard-overclaim
- ambient sync mythology
- saved layouts pretending to be live continuity
- preview surfaces that quietly execute or widen scope
- terminal-local memory pretending to be system truth
- display labels quietly outranking stronger witnesses

## Closing judgment

Helm will become super awesome by making the same few truths feel brilliant everywhere:
exact target,
exact scope,
exact basis,
explicit promotion,
and humble suggestions.
Not by becoming bigger.
