# Research bibliography — 2026-03-23 — pass CLXVI

Sources consulted for the precondition-strip / cutover-proof pass.

1. Google Cloud Storage — Request preconditions
   https://docs.cloud.google.com/storage/docs/request-preconditions

2. Amazon S3 — Conditional writes
   https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-writes.html

3. Amazon S3 — CompleteMultipartUpload API
   https://docs.aws.amazon.com/AmazonS3/latest/API/API_CompleteMultipartUpload.html

4. etcd — API / transactions
   https://etcd.io/docs/v3.6/learning/api/

5. Kubernetes — kubectl scale
   https://kubernetes.io/docs/reference/kubectl/generated/kubectl_scale/

6. Kubernetes — API concepts / watch bookmarks
   https://kubernetes.io/docs/reference/using-api/api-concepts/

7. Microsoft Graph — createUploadSession
   https://learn.microsoft.com/en-us/graph/api/driveitem-createuploadsession?view=graph-rest-1.0

8. Microsoft Graph / OneDrive — resumable file upload
   https://learn.microsoft.com/en-us/onedrive/developer/rest-api/api/driveitem_createuploadsession?view=odsp-graph-online

9. Microsoft Graph — uploadSession resource
   https://learn.microsoft.com/en-us/graph/api/resources/uploadsession?view=graph-rest-1.0

10. Google Drive API — Manage uploads
    https://developers.google.com/workspace/drive/api/guides/manage-uploads
