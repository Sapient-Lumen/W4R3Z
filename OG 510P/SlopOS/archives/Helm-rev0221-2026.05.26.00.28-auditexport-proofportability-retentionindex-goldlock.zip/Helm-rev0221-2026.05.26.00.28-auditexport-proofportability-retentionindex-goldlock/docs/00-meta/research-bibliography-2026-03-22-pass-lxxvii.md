# Research bibliography — 2026-03-22 — pass LXXVII

Primary internal teacher documents re-opened in this pass:

- SlopOS: `docs/30-architecture/namecert-selection-boundary-v0.md`
- SlopOS: `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- SlopOS: `docs/30-architecture/network-lease-address-selection-boundary-v0.md`
- Steward: `docs/30-architecture/label-surface-posture-v0.md`
- Steward: `docs/30-architecture/chrome-lane-posture-v0.md`
- Steward: `docs/30-architecture/assist-surface-posture-v0.md`
- ViewFS: `docs/30-architecture/previews-extractors-and-observation-surfaces.md`
- ViewFS: `docs/30-architecture/slopos-seam-map.md`
- Schell: `docs/80-terminal/title-witnesses-display-labels-and-override-humility.md`

Primary outside teachers consulted in this pass:

- Warp Launch Configurations — https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Workflows — https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
- Raycast Quicklinks — https://manual.raycast.com/quicklinks
- Arc Peek — https://resources.arc.net/hc/en-us/articles/19335302900887-Peek-Preview-Sites-From-Pinned-Tabs
- Arc Profiles — https://resources.arc.net/hc/en-us/articles/19227964556183-Profiles-Separate-Work-Personal-Browsing
- Figma library update review — https://help.figma.com/hc/en-us/articles/360039234193-Review-and-accept-library-updates
- Figma variable modes — https://help.figma.com/hc/en-us/articles/15343816063383-Modes-for-variables
- Chrome `activeTab` — https://developer.chrome.com/docs/extensions/develop/concepts/activeTab
- Android Selected Photos Access — https://developer.android.com/about/versions/14/changes/partial-photo-video-access
- Google Workspace app access controls — https://knowledge.workspace.google.com/admin/apps/control-which-apps-access-google-workspace-data
- Google Workspace `currentonly` scopes — https://developers.google.com/workspace/add-ons/concepts/workspace-scopes
- Terraform `plan` — https://developer.hashicorp.com/terraform/cli/commands/plan
- Terraform `apply` saved-plan mode — https://developer.hashicorp.com/terraform/cli/commands/apply
- Datadog downtime scoping — https://docs.datadoghq.com/monitors/guide/scoping_downtimes/
- Datadog Notebooks — https://docs.datadoghq.com/notebooks/
- Linear Triage — https://linear.app/docs/triage
- Linear Triage Intelligence — https://linear.app/docs/triage-intelligence
- GitHub CODEOWNERS — https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners
- GitHub required reviewer rule — https://github.blog/changelog/2026-02-17-required-reviewer-rule-is-now-generally-available/
- GitHub rulesets / stale approval behavior — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets
- Microsoft Recall privacy and control — https://support.microsoft.com/en-us/windows/privacy-and-control-over-your-recall-experience-d404f672-7647-41e5-886c-a3c59680af15
- Apple Handoff — https://support.apple.com/en-us/102426
- Notion synced blocks — https://www.notion.com/help/synced-blocks
- Kubernetes Server-Side Apply — https://kubernetes.io/docs/reference/using-api/server-side-apply/

Short reading judgment:

- strongest starter/front-door pressure: Warp + Raycast
- strongest inert-preview pressure: Arc + Figma
- strongest narrow-grant pressure: Chrome + Android + Google Workspace
- strongest reviewed-basis pressure: Terraform + GitHub
- strongest humble-AI pressure: Linear
- strongest weak-reuse pressure: Notion + Figma + Datadog + Handoff
