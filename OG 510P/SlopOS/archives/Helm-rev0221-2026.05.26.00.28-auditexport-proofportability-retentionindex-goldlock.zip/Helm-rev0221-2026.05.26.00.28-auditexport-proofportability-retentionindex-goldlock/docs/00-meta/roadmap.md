
# Roadmap

## Phase 0 — meaning pins and archive control
- settle shell/compositor ownership
- settle control-tier boundaries
- settle object-browser and reveal semantics
- settle recall and reentry honesty
- settle exchange and typed transfer routing
- settle terminal/capshell posture
- settle the Helm/Schell treaty for shell-facing seams
- freeze pillar contracts so Helm does not regress into app-bundle thinking
- add compact startup, status, question, and import-memory surfaces so revisions stop depending on chronology and chat memory

## Phase 1 — proof-bearing slice

Preferred first slice: **exact object → reviewed action → route → receipt → recall**

- shell graph with windows/workspaces/focus
- Tiling Shell with directional focus, layout transforms, and shell-owned workspaces
- Omnibox over shell objects/actions including recall and exchange subjects
- Object Browser with split views, query views, bulk operations, exact reveal, and exact object reopen
- Operations Center with windows/jobs/background/automation sessions/transfers/receipts/grants
- Desktop Flow over shell graph with hotkeys, layout rules, object actions, recall jumps, and exchange routes
- Recall with one obvious current-live reentry cue, liveness badges, activity trail, and hold cards for non-live strong actions
- Exchange with typed ingress/selection packets, exact route witnesses, and visible transfer / attach / forward receipts
- explicit raw automation session with visible indicator and kill switch
- one reviewed shell-facing action with lineage and receipt
- one proof that terminal/capshell can participate in the same cross-pillar slice without becoming the hidden master ontology
- archive control surfaces exercised by at least one honest startup/reentry pass
- typed provider path for Omnibox demonstrated by at least one provider family
- Flow observability/reuse demonstrated by one debug lane plus one reusable fragment specimen
- request-vs-live truth demonstrated on at least one route / restore / status slice
- entry-artifact truth demonstrated on at least one capsule / template / entry-kit slice
- binding-witness posture demonstrated on at least one non-exact capsule / template / entry-kit join
- reviewed-basis truth demonstrated on at least one strong action over saved / historical / delegated basis
- delegated-adoption truth demonstrated on at least one delegated or background mutable-work slice
- candidate cross-cut moves narrowed enough to prove or demote: Preview, Overview, workspace/activity capsules, activity spines, activity cockpit cards, activity entry kits, binding witness cards, activity scope witnesses, continuity choice witnesses, basis packets, review strips, exact-object recency, reusable flow fragments, shadow work lanes, preview rails, facet strips, command docks, adoption harbors, view decks, materialization bays, surface locality tiers, drift beacons, deck recipes, receiver fit cards, and rebind ladders
- projection-surface posture demonstrated by at least one small specimen spanning more than one family member (for example dock + rail, strip + lens, or cockpit card + sticky strip)

## Phase 1.5 — cross-cutting shell power pass
- Preview candidate contract and provider posture
- Overview candidate contract as Omnibox's spatial companion
- workspace/activity capsule candidate contract with exact/repaired/partial/unavailable honesty
- query-first browsing and plumbing-grade routing tightened where they pressure multiple pillars
- breadcrumb / outline / timeline cues tightened where they help Recall and Object Browser
- live-lens candidate contract narrowed enough to prove or demote
- snippet / quicklink / placeholder seed candidate narrowed enough to prove or demote
- activity cockpit candidate narrowed enough to prove or demote
- activity entry kit candidate narrowed enough to prove or demote
- binding witness card candidate narrowed enough to prove or demote
- activity scope witness candidate narrowed enough to prove or demote
- continuity choice witness candidate narrowed enough to prove or demote
- basis packet candidate narrowed enough to prove or demote
- review-strip candidate narrowed enough to prove or demote
- exact-object-recency candidate narrowed enough to prove or demote
- flow-fragment candidate narrowed enough to prove or demote
- shadow work lane candidate narrowed enough to prove or demote
- preview-rail candidate narrowed enough to prove or demote
- facet-strip candidate narrowed enough to prove or demote
- command-dock candidate narrowed enough to prove or demote
- adoption-harbor candidate narrowed enough to prove or demote
- exact-trail, trust-ladder, exact-action-key, live-lens, view-deck, materialization-bay, surface-locality, drift-beacon, deck-recipe, basis-stamp, and residue-ledger warmth narrowed enough to prove or demote or keep as pressure

## Phase 2 — deeper automation and Schell integration
- tighter terminal/capshell contract
- richer structural UI graph
- stronger failure inspection and receipts
- ingress / selection / exchange packet family shared more explicitly across surfaces
- execution-ground witnesses on reviewed shell-facing actions
- richer continuity around attach, resume, restore, and remote peer witnesses
- optional sealed compat lanes if ever admitted
- decide whether Helm needs a fuller transfer ledger beyond the current foreign-pressure memory

## What should wait for Schell
- final shell syntax
- final session restore/attach semantics
- final remote forwarding and peer-witness posture

## Added pressure in rev0013

- one binding-witness specimen visible across at least capsule / template / entry-kit surfaces
- one proof that repaired or ambiguous saved-to-live joins stay inspectable rather than silently counting as exact continuity
- continued push toward one rehearsal-card specimen, one capsule-diff specimen, one layout-template-and-rebinding specimen, one cockpit specimen, and one entry-kit specimen


## Added pressure in rev0018

- one proof that an exact object can survive across Omnibox, Object Browser, Exchange, Operations Center, Recall, and terminal/capshell without parallel state silos
- one compact specimen of reviewed action, route witness, receipt or denial, and later Recall return over that same object

## Added pressure in rev0017

- one proof that delegated or background mutable work can stay isolated from the operator's live lane without turning Helm into a giant branch manager
- one specimen where a cockpit, entry kit, repair card, or delegated helper opens a compact shadow work lane and requires explicit adoption before the live lane changes

## Added pressure in rev0016

- one proof that a strong action can refuse sticky reviewed-basis carry without turning into a giant workflow bureaucracy
- one specimen where an entry kit, cockpit, route card, or receipt-derived action opens a tiny basis packet and requires review again when the basis drifted

## Added pressure in rev0015

- one proof that a repaired or widened continuity path can name proposer / chooser / executor posture without becoming a giant review bureaucracy
- one specimen where an entry kit, cockpit, binding witness, or scope witness opens a tiny continuity choice witness instead of laundering authorship

## Added pressure in rev0014

- one proof that a same-activity claim can name included axes and excluded nearby ambient context without turning into a giant ontology
- one specimen where an entry kit, cockpit, or binding witness opens a small scope witness instead of silently inheriting profile/account/browser/remote/workspace glow

## Added pressure in rev0019

- one proof that stronger actions can use tiny review strips instead of giant modal review bureaucracy
- one proof that Recall can center on exact-object recency with source labels instead of vague recent-items folklore
- one proof that Desktop Flow can reuse a status-bearing fragment without copy-paste drift or opaque black-box packaging

## Added pressure in rev0021

- one proof that preview can keep a compact bounded next-step rail without collapsing into open/import/attach folklore
- one proof that Omnibox, Recall, or Exchange can use typed facet pivots without exploding into separate mini-products or provider spam

## Added pressure in rev0023

- one proof that compact shell luxuries can stay bounded projections over stronger shell truth instead of slowly becoming second authority domains
- one specimen where a projection surface degrades honestly when its source, basis, or authority disappears


## Added pressure in rev0024

- one proof that exact trails can stay copyable, typed, and shell-owned across at least two pillars without bluffing live continuity
- one proof that a trust ladder can stay compact enough to help preview/import/delegated-work cases without becoming a giant constitution
- one proof that promotable exact action keys can preserve review-first and blocked postures instead of bypassing them


## Added pressure in rev0025

- one proof that multiple explicit views over one stronger shell truth can be gathered as a compact deck without becoming a dashboard religion or fake continuity object
- one proof that a weaker or derived surface can use an explicit materialization bay to become a stronger local or live thing without hiding that second workflow inside the first one
- renewed pressure to prove live lenses as a delightful projection-surface specimen rather than leaving them as prestige clutter



## Added pressure in rev0026

- one proof that a shell luxury can stay visibly personal/local by default and still promote explicitly into a portable or shared form
- one proof that live lenses can feel delightful without turning into hidden control channels or fake independent objects
- renewed pressure to keep docks, keys, decks, seeds, and trust posture honest about which locality tier they belong to


## Added pressure in rev0027

- one proof that a compact drift beacon can compare an exact current subject against one exact reviewed or remembered basis without becoming giant timeline theater
- one proof that a deck recipe can materialize a deck-like cluster as a reusable starter without impersonating live continuity or a second workspace system
- renewed pressure to connect beacons, decks, harbors, basis packets, and live lenses without adding more pillars


## Added pressure in rev0031

- one proof that a portable shell surface can land on a receiver with a compact fit story that names what matched, what was omitted because it is local-only, and what stronger steps are actually safe here
- one proof that receiver-local rebinding can stay explicit and authored for paths, providers, profiles, sessions, placements, or activities without turning into a giant import wizard or hidden self-healing engine
- renewed pressure to keep portable cores, local overlays, handoff packets, promotion receipts, and materialization bays cooperating around a truthful landing story


## Added pressure in rev0033

- one proof that a portable or derived surface can carry a tiny exact basis stamp without pretending that carried basis equals current live sameness
- one proof that omission truth can stay compact and useful through a residue ledger instead of disappearing into sync folklore or giant diff theater
- renewed pressure to keep landing manifests, fit cards, rebind ladders, portable cores, and local overlays honest about both carried basis and omitted residue


## Added pressure in rev0034

- one proof that a portable or derived surface can carry a compact explicit anchor map instead of depending on ambient search, guessed bindings, or fuzzy receiver magic
- one proof that a surface can explicitly inherit bounded receiver-default classes without laundering omitted residue or widening local authority
- renewed pressure to keep landing manifests, residue ledgers, fit cards, rebind ladders, local overlays, exact action keys, and deck recipes cooperating around truthful carried slots and truthful defaults


## Added pressure in rev0036

- one proof that a portable or saved surface can land into a receiver-local rehearsal mode before adoption without pretending the rehearsal is already local durable truth
- one proof that Helm can surface similar local candidates with typed mismatch reasons and explicit choose-and-rebind authorship instead of quietly claiming exact continuity
- renewed pressure to keep landing manifests, anchor maps, basis stamps, residue ledgers, fit cards, and rebind ladders cooperating around truthful arrival without giant import wizardry

## Added pressure in rev0045

- one proof that generic open can stay weak while current-live reentry, durable save/materialize, publication, and branch remain visibly stronger separate acts
- one proof that Recall can center on shell-owned exact recency and current-live cues instead of provider-side launch history or recent-items folklore
- renewed pressure to keep preview ladders, launch ladders, exact action keys, materialization bays, and publication ladders cooperating around truthful open semantics



## Added pressure in rev0046

- one proof that Helm can keep **recipes**, **review tickets/snapshots**, and **live instances** visibly different forms while still making them easy to move between
- one proof that longer compare/paging/route-review flows can use a compact stable review ticket instead of hovering over live-shifting truth or flattening into fake durable objects
- renewed pressure to keep saved view objects, checkpoint branches, Recall, Omnibox, Object Browser, and Exchange cooperating under a three-form law rather than ambient “latest” folklore

## Added pressure in rev0047

- one proof that Helm can gather saved views, checkpoints, quick actions, and launch/layout starters under one named activity spine without pretending that the spine itself is current live truth
- one proof that sharing an activity spine can tighten scope and memory boundaries instead of widening them by ambient convenience
- renewed pressure to keep saved view objects, checkpoint branches, review tickets, publication ladders, and current-live beacons cooperating under explicit scoped work rather than a giant workspace constitution


## Added pressure in rev0048

- one proof that Helm can curate grouped resources under a resource shelf without pretending that the grouped set is the current-live lane or a hidden shared workspace
- one proof that current-versus-all export/share can stay explicit for a grouped shell surface instead of disappearing into convenience
- renewed pressure to keep activity spines, saved view objects, checkpoint branches, publication ladders, and current-live beacons cooperating with a weaker curation layer rather than one giant workspace/blob ontology

## Added pressure in rev0049

- one proof that Helm can give a scoped activity one saved front door without pretending the saved starter is already the current-live lane
- one proof that an activity entry kit can compose a preferred view or shelf, a launch/layout starter, and a checkpoint relation without collapsing those object types into one workspace blob
- renewed pressure to keep activity spines, resource shelves, saved view objects, checkpoint branches, and current-live beacons cooperating under a humane return-to-work grammar rather than flattering resume mythology

## Added pressure in rev0051

- one proof that Helm can remember a small activity-scoped fact, warning, or instruction explicitly without turning recents/opened context into ambient memory folklore
- one proof that imported/shared remembered context begins in weaker posture and does not silently outrank current-live beacons or fresh review
- renewed pressure to keep activity spines, entry kits, current-live beacons, scope witnesses, Omnibox, Recall, and AI/planning surfaces cooperating around explicit remembered context rather than hidden personalization

## Added pressure in rev0052

- one proof that a reviewed slice can carry a compact health tile without collapsing latest-run, freshness, and exact failing checks into one flattering badge
- one proof that a published or reviewed deck-like object can reveal downstream use and affected-set posture without turning dependency visibility into authority or a giant catalog center
- one proof that draft, compare-to-live, published, frozen, and history-only posture stay visibly different when richer deck or brief workbench behavior appears


## Added pressure in rev0147

- one proof that a deck-like shell surface can reveal its semantic recipe without turning Helm into one universal semantic-layer center
- one proof that live-direct, cached, precomputed, frozen, and subscription-fed answers can stay visibly different through a tiny serve-path strip instead of timeless-result folklore
- one proof that Helm can surface logical `as-of` footing and validator-before-publish posture without pretending either one is source truth or runtime proof

## Added pressure in rev0148

- one proof that a reviewed slice can mint a replay capsule with exact recipe, exact inputs, exact footing, and one alternate compare footing without pretending the request is already the answer
- one proof that a replay answer can yield a compact variance card for output / input / basis / recipe / serve-path delta without opening a giant notebook or diff studio
- one proof that published-default, current-input, collaborative-session, pinned-version, and replay-result links can stay visibly different across Recall and Exchange
