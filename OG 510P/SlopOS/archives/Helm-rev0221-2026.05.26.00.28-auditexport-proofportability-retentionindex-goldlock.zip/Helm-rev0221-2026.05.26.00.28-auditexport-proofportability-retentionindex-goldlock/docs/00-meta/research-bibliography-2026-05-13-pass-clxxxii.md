# Research bibliography — 2026-05-13 pass CLXXXII

Load-bearing outside references for rev0189:

- Databricks — Unity Catalog metric views and materialization: https://docs.databricks.com/aws/en/business-semantics/metric-views/ and https://docs.databricks.com/aws/en/business-semantics/metric-views/materialization
- Snowflake — Semantic views overview: https://docs.snowflake.com/en/user-guide/views-semantic/overview
- dbt — Semantic Layer and entities: https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl and https://docs.getdbt.com/docs/build/entities
- Cube — Pre-aggregations: https://cube.dev/docs/product/data-modeling/reference/pre-aggregations
- Apache Iceberg — Branching and tagging: https://iceberg.apache.org/docs/latest/branching/
- lakeFS — data versioning docs: https://docs.lakefs.io/
- OpenLineage — facets and extensibility: https://openlineage.io/docs/spec/facets/
- OpenTelemetry — context propagation and baggage: https://opentelemetry.io/docs/concepts/context-propagation/ and https://opentelemetry.io/docs/concepts/signals/baggage/
- DuckDB — Parquet overview and direct Parquet querying: https://duckdb.org/docs/current/data/parquet/overview.html and https://duckdb.org/docs/current/guides/file_formats/query_parquet.html
- Polars — lazy Parquet scan: https://docs.pola.rs/py-polars/html/reference/api/polars.scan_parquet.html
- Observable Framework — data loaders: https://observablehq.observablehq.cloud/framework/data-loaders
- GitHub — managing a merge queue: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
- Linear — Triage: https://linear.app/docs/triage
- Notion — views, filters, sorts, and groups: https://www.notion.com/help/views-filters-and-sorts
- Airtable — view collaboration types: https://support.airtable.com/docs/getting-started-with-airtable-views

These sources are not adopted as Helm dependencies. They are pressure sources for small product-shaped rules.
