# Helm three-form law — 2026-03-22

Purpose: name one shell-wide law that keeps several current Helm ideas from flattening into each other.

## The law

Helm increasingly wants three visibly different forms:

1. **recipe / definition**
2. **ticket / snapshot / stable review slice**
3. **live instance / current lane**

These are related,
but they are not interchangeable.

## Why this matters

Helm is accumulating many saved or derived shell objects:

- saved view objects
- deck recipes
- launch configurations
- command bands
- checkpoints
- arrival overlays
- route proposals
- compare surfaces
- and future activity-facing shell objects

Without a simpler law,
the shell will keep being tempted to blur them into one convenience story.

The three-form law keeps the story honest.

## Form 1 — recipe / definition

A recipe says how something should be viewed,
launched,
arranged,
or composed.

Examples:
- saved view object
- deck recipe
- launch configuration
- command band definition
- activity entry object

A recipe can often be:
- named
- summoned
- pinned
- shared/published by explicit rung
- materialized into something stronger

But a recipe is **not** a current live instance.

## Form 2 — ticket / snapshot / stable review slice

A ticket is a bounded cut of truth suitable for review,
paging,
compare,
handoff,
or route inspection.

Examples:
- query result ticket from a saved view
- checkpoint snapshot
- route review ticket
- arrival compare ticket
- batch-action review ticket

A ticket can often be:
- inspected
- paged
- compared
- annotated
- handed off
- expired or marked historical
- branched from where the lineage story is explicit

But a ticket is **not** the recipe that produced it,
and it is **not** the current live lane.

## Form 3 — live instance / current lane

A live instance is the currently bound,
active,
or otherwise stronger present-tense shell truth.

Examples:
- current active view over a live subject
- current live window/pane arrangement
- active route/session/provider binding
- current adopted local object
- current branch or lane the operator is really in

A live instance can often be:
- reentered
- acted on
- checkpointed
- revealed
- bound to stronger receipts

But it is **not** the same as a recipe,
and it should not quietly collapse into a historical ticket.

## Form transitions should stay explicit

Useful transitions include:

- recipe → preview
- recipe → materialization bay → local/adopted object
- recipe → published/shared recipe
- live instance → checkpoint ticket
- ticket → compare / annotate / handoff
- ticket → restore or branch-from-here
- live instance → current-live reentry

The important rule is:
**the shell should name the transition instead of pretending the forms were always the same.**

## Why this makes Helm better

This law sharpens several current Helm bets at once:

- **saved view objects** stop fighting with result slices
- **checkpoint branches** stop fighting with live continuity
- **Recall** gets clearer about live reentry versus historical return
- **Omnibox** can target different verbs by form
- **Object Browser** can show views,
  tickets,
  and live subjects without flattening them
- **Exchange** can hand off bounded review surfaces without claiming receiver-side activation
- **materialization bays** and **arrival overlays** become easier to explain

## What to avoid

- do not let recipes impersonate live continuity
- do not let tickets impersonate current liveness
- do not let live mutable lists pretend to be stable review objects
- do not let “latest” folklore pick the strongest form automatically
- do not let handoff/export flatten recipe,
  ticket,
  and live forms into one portable blob

## Pull-the-trigger judgment

This law is strong enough to use as guidance now.

What is still warm rather than frozen is the exact ticket object model.
The most promising compact next move is therefore:

**define one review ticket contract and prove it in one or two families.**
