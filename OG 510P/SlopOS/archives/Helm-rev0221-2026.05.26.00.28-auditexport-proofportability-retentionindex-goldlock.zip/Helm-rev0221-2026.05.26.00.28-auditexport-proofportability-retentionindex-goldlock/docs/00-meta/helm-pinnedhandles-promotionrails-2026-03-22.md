# Helm pinned handles, promotion rails, and facet ownership — 2026-03-22

Purpose: identify the next few moves that could make Helm feel dramatically better without growing another pillar or a giant new object court.

## The shortest answer

Helm gets more awesome when it makes three things obvious:

1. **whether a handle is pinned or floating**
2. **whether a thing is still in rehearsal or already promotable/live**
3. **who owns which facet when a composite shell object conflicts**

These are not new pillars.
They are shell-wide honesty upgrades.

## 1. Pinned versus floating handles

Helm should stop making every reopen,
share,
and act-now handle look the same.

Two handle classes are especially valuable:

- **Pinned handles**
  - exact reviewed basis
  - exact historical subject
  - exact snapshot / exact branch / exact deployment / exact route witness
  - never silently follows later drift

- **Floating handles**
  - intentionally follows the latest current branch,
    activity,
    service,
    cohort,
    or current-live beacon
  - useful for front doors and patrol starts
  - great when the operator wants "take me to what's current now"

A great Helm handle card would show:
- subject kind
- pinned or floating posture
- basis or follower target
- current access / freshness posture
- drift or rebinding warning if relevant
- available next moves

Why it matters:
- **Omnibox** becomes much clearer about what a summon really means
- **Recall** can stop blurring "the thing I saw" with "the thing that is current now"
- **Exchange** can share either an exact reviewed thing or a current-following entry point honestly
- **Object Browser** can make reopen truth legible at a glance

## 2. Rehearsal → compare → promote rails

Helm already has preview,
landing rehearsal,
shadow work lanes,
and adoption harbors warming.
This pass says they should cohere into one more legible rail.

A strong shell rail now looks like:

1. **rehearsal lane exists as a real addressable object**
2. **compare surface explains difference against the authoritative lane**
3. **promotion rail names gates and drift posture**
4. **promotion or refusal leaves an effect receipt**

This is important because rehearsal should not be throwaway.
When a preview,
helper lane,
repair lane,
or imported landing is good,
the user should be able to promote it rather than recreate it.

What makes the rail trustworthy:
- exact relation to one live subject or exact basis
- compare-before-promote by default for stronger acts
- drift or gate failure is explicit
- refusal leaves the live lane untouched
- promotion creates an aftermath witness instead of a friendly ghost status

Why it matters:
- **Desktop Flow** can stage stronger control without fire-and-forget mutation
- **Operations Center** can show rehearsals,
  promotion-ready items,
  drifted candidates,
  and effects as separate truths
- **Recall** can reopen candidate work without laundering it into live truth
- **Exchange** can land imported surfaces honestly before adoption

## 3. Facet ownership and conflict posture

As Helm gains more saved views,
entry kits,
decks,
resource shelves,
response kits,
and cockpit surfaces,
it will keep accumulating composite objects.

Composite objects are delightful until they hit the same silent failure every product hits:
quiet last-write-wins.

Helm should instead consider a smaller,
humane version of managed-field conflict posture.
Not everywhere.
Only where conflict meaning really matters.

A shell facet could be owned by:
- the user directly
- a pinned local override
- an imported recipe
- a helper lane proposal
- a receiver-local default fill
- a live derivation that remains explicitly weaker than authored override

When two of those want the same slot,
Helm should be able to say so.

A good facet conflict card would show:
- exact surface and exact facet/slot
- current owner / previous owner
- proposed new owner
- whether the change is safe,
  conflicting,
  stale,
  or takeover-required
- choose / refuse / keep-local / transfer-ownership actions

Why it matters:
- saved views become safer to evolve
- imported surfaces stop pretending they landed cleanly when they only half did
- helper proposals stop quietly overwriting user pins
- default fill and local overrides stay visible instead of mystical

## 4. Signature delights these moves enable

### A. Honest reopen
A Recall row can say:
- `pinned exact` 
- `floating current` 
- `handle stale` 
- `repair needed`

That is much better than one vague reopen button.

### B. A real rehearsal lane
A helper-generated fix,
imported deck,
or route repair can open in a side lane that says:
- `rehearsal`
- `compare with live`
- `promotion gates: freshness passed, reviewer pending`
- `promote`

That feels premium.

### C. Conflict without mystery
A saved deck card can say:
- `facet conflict: sidebar query`
- `current owner: user pin`
- `incoming owner: imported recipe`
- `take over / keep local / split copy`

That is a lot better than quietly stomping on the user's surface.

## 5. Pull-trigger guidance

### Pull now
- pinned and floating handle badges/cards
- rehearsal lanes with compare-before-promote posture
- promotion rails that name drift and gates
- facet ownership badges on the handful of composite objects where overwrites would be painful

### Keep warm
- giant universal ownership ledgers
- giant promotion-court workflows
- universal recipe studios
- automatic multi-actor merge magic for every shell object

## Closing judgment

Helm does not need a bigger constitution to feel more magical.

It needs to make three truths much easier to see:
- **is this handle pinned or floating?**
- **is this thing still rehearsing or ready to promote?**
- **who owns this facet if I change it?**

Those are exactly the kinds of product moves that feel brilliant in use and still age well.
