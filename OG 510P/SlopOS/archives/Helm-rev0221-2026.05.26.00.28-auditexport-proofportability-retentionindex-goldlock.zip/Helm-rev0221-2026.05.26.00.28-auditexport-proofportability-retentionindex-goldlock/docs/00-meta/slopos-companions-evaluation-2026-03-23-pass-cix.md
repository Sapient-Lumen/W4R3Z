# SlopOS + companion-cube evaluation — 2026-03-23 — pass CIX

Purpose: test whether the next Helm move should be **durable aftermath truth** rather than another earlier Exchange rung.

## Main result

Yes.
The strongest aligned lesson from SlopOS,
Schell,
ViewFS,
and Steward is now:

**do not let route admission,
payload acquisition,
runtime acknowledgement,
stepwise success,
and durable user-meaningful completion collapse into one flattering completion story.**

Helm already has a much better pre-act and mid-act ladder than most systems:
- basis stamps
- action warrants
- drift gates
- transfer offers
- take cards
- route witnesses
- materialization witnesses

What still feels underpowered is the post-act answer:
- **what exact durable effect landed?**
- **what exact subset landed, stayed pending, failed, or was rerun later?**

That keeps pointing back to two warm support specimens:
- **effect receipts**
- **slot verdict ledgers**

## What SlopOS is still teaching

### 1. Imported or provider-local completion should stay weaker than shell truth
The current SlopOS completion-import boundaries keep insisting that provider suggestions,
provider-local completion,
and imported progress are not durable selector or workflow truth.
That same discipline should continue after Exchange handoff:
receiver-local or provider-local completion should not automatically become Helm's durable historical truth.

### 2. Effect descriptors are narrower than authority or live state
SlopOS `effect-contract-schema-v0.md` is still useful here.
Its effect contracts are explicitly non-authoritative descriptors that bind a declared act to reviewed authority and a bounded effect family.
That is the same law Helm should preserve on the far side of a strong act:
a durable effect receipt should describe what landed,
not silently become authority,
live state,
or a universal task engine.

### 3. Completion and materialization boundaries are already warning against folklore
The OpenURI,
materialization,
and MCP completion boundaries all keep saying some form of:
- launch is not later app truth
- materialization is not durable semantic completion
- imported completion is not reviewed shell state

Helm should harvest that law directly instead of inventing a new one.

## What Schell is still teaching

Schell's handoff and completion humility docs keep reinforcing that a shell should preserve:
- what was handed off
- what was actually observed
- and what still remains downstream or user-local

That maps almost perfectly onto a Helm aftermath ladder:
- route witness
- materialization witness
- effect receipt
- optional rerun / repair relation

Schell also keeps teaching that completion witnesses should stay modest and source-aware.
That supports attempt-bound effect receipts rather than one global triumphant completion badge.

## What ViewFS is still teaching

ViewFS remains the clearest teacher that:
- live handles,
- durable refs,
- and transcript receipts
are different strengths.

That matters now because an effect receipt should remain **historical aftermath**,
not a re-opened live handle and not a current-state oracle.
ViewFS also keeps validating that routing truth and completion truth belong in separate receipts.

## What Steward is still teaching

Steward's activation receipts and runtime-cycle witnesses are a strong reminder that:
- delivery,
- acknowledgement,
- control-ready,
- and serve-ready
are different truths
- and exact-run evidence belongs to one concrete cycle.

Helm should steal that exact-run / exact-attempt discipline.
One effect receipt should belong to one exact stronger act or one exact rerun attempt,
not to the whole activity forever.

## The practical lesson Helm must learn from the past

The past failure mode is still **false unification**.
Systems feel smooth when they hide distinctions,
but they become spooky,
hard to debug,
and impossible to trust.

For Helm's post-act surfaces,
that means at least these truths must stay separate:
- chosen route
- payload acquired
- receiver-local confirm/edit opened
- durable effect landed
- partial subset landed
- later rerun / redrive / retry succeeded
- current live state now matches history

## Pull-the-trigger judgment

It is now wise to warm **effect receipts + slot verdict ledgers** again,
this time as the post-materialization rung of the Exchange / strong-act ladder.

Not as a new pillar.
Not as a giant workflow product.
But as the smallest honest answer to:

**what exactly happened,
what only partially happened,
and what attempt now owns that history?**
