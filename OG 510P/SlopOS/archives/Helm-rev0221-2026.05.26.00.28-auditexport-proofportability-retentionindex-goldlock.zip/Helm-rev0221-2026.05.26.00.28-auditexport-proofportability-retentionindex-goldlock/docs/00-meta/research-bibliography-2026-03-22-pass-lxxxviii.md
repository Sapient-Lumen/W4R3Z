# Research bibliography — 2026-03-22 — pass LXXXVIII

Used in this pass.

1. W3C — Media Capture and Streams
   - URL: https://www.w3.org/TR/mediacapture-streams/
   - used for: the split between granted access and present recording via an “on air” indicator, plus easy revocation of granted permissions

2. W3C — Screen Capture
   - URL: https://www.w3.org/TR/screen-capture/
   - used for: live indicators for display capture and the advice to provide a means to stop active capture

3. Android Developers — Request runtime permissions
   - URL: https://developer.android.com/training/permissions/requesting
   - used for: Android 12 privacy indicators for microphone and camera access

4. Android Developers — Explain access to more sensitive information
   - URL: https://developer.android.com/training/permissions/explaining-access
   - used for: device-wide camera/microphone toggles and their immediate effect on apps

5. Apple Support — Use Control Center on Mac
   - URL: https://support.apple.com/guide/mac-help/quickly-change-settings-mchl50f94f8f/mac
   - used for: Mac privacy indicators and showing which apps are using microphone, camera, system audio, or location

6. Apple Support — Control access to hardware features on iPhone
   - URL: https://support.apple.com/guide/iphone/control-access-to-hardware-features-iph168c4bbd5/ios
   - used for: permission review/change posture and recent camera/microphone use messaging in Control Center

7. Apple Support — Control access to screen and system audio recording on Mac
   - URL: https://support.apple.com/guide/mac-help/control-access-screen-system-audio-recording-mchld6aa7d23/mac
   - used for: app-by-app screen and system-audio recording control

8. Microsoft Support — Windows camera, microphone, and privacy
   - URL: https://support.microsoft.com/en-us/windows/windows-camera-microphone-and-privacy-a83257bc-e990-d54a-d212-b5e41beba857
   - used for: live camera/microphone indicators, coarse-vs-exact control differences, and per-site/per-app control posture

9. Microsoft Support — Customize the Taskbar in Windows
   - URL: https://support.microsoft.com/en-us/windows/customize-the-taskbar-in-windows-0657a50f-0cc7-dbfd-ae6b-05020b195b07
   - used for: dynamic system-tray privacy indicators for location, microphone, and camera

10. Google Chrome Help — Use Gemini in Chrome
    - URL: https://support.google.com/chrome/answer/16283624
    - used for: removing one shared tab and keeping exact active shared-tab control near the live surface

11. Google Chrome Help — Go Live with Gemini in Chrome
    - URL: https://support.google.com/chrome/answer/16363185
    - used for: pausing current-tab sharing, removing exact tabs, and stopping all shared tabs as a model for active-cohort brake rails
