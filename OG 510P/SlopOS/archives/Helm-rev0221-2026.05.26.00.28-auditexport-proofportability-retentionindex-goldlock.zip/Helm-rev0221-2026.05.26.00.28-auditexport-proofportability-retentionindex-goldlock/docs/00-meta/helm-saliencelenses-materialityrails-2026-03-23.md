# Helm salience lenses + materiality rails — 2026-03-23

## Narrow thesis

After **footing marks**,
Helm still lacks one compact shell-owned answer to:

**what kinds of change counted here,
what got intentionally suppressed,
and why is this compact surface surfacing now?**

That is not the same as:
- state tuples
- why rails
- footing marks
- delta briefs
- watchpoints
- or recap layout density

It is the next seam those surfaces need in order to stop lying by over-reporting,
under-reporting,
or pretending every event matters equally.

## What to keep

Keep:
- the seven pillars
- typed action mode
- landmarks
- reality strips
- continuity postcards
- state tuples
- grounding witnesses + why rails
- delta briefs
- footing marks
- watchpoints and view subscriptions

## What to peel away

Peel away:
- generic “important updates” language with no declared event families
- one universal ranking score pretending to explain attention
- dense activity rivers that bury review/adoption/trust changes under harmless churn
- quiet suppression that hides basis drift,
  verification expiry,
  or receipt arrival

## The next shell-wide seam

Helm should admit **salience lenses**,
with tiny inspect faces that can feel like **materiality rails**.

A salience lens says:
- which change families counted
- which ones were suppressed or grouped
- whose perspective the lens reflects
- what threshold or audience made the change surface
- and which stronger compare/review/repair lane should open next

## Good first salience families

Good first counted families look like:
- blocker introduced or cleared
- review requested / stale / approved / dismissed
- adoption possible / blocked / completed
- basis drifted
- receipt arrived / failed / superseded
- freshness expired or confidence decayed
- audience widened / narrowed
- ownership or verification changed
- direct ask / mention / assignment
- state bucket crossed threshold

Good first suppressed families look like:
- repeated unchanged polls
- repeated countdown ticks
- harmless timestamp churn
- consecutive low-value status updates of the same class
- personal read-state noise when the current lens is shared operational truth

## Why this is worth pulling now

Because once Helm can say both:
- **since what footing?**
- **under what salience lens?**

its compact surfaces become much calmer.
A delta brief can say:
- compared against `last-reviewed`
- counting `review-requested`, `basis-drifted`, and `receipt-arrived`
- suppressing repetitive `waiting` motion

A watchpoint can say:
- evaluated over this exact saved view
- with a blocker-and-threshold lens
- muted for delivery,
  but still degraded underneath

An Overview tile can say:
- this is a personal triage lens,
  not shared operational severity

That is a real product ratchet.
It makes Helm feel more exact,
more humane,
and more “super awesome” without another new pillar.

## Pull-the-trigger judgment

It now looks wise to pull one narrow trigger:

**promote shell-owned salience lenses,
with inspectable materiality rails as their tiny nearby face.**

That is the next honest move after footing marks.
