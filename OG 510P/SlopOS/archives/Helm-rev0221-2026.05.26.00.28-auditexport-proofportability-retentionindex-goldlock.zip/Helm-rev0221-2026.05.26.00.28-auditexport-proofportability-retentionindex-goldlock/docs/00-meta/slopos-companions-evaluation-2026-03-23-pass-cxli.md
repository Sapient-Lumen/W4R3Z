# SlopOS + companions evaluation — 2026-03-23 pass CXLI

## Why this pass happened

The last Helm revision made the strongest adjacent cluster explicit:
**semantic recipe cards, serve-path strips, `as-of` footing, validator rails, and maybe later weak verified / official marks.**

This pass asked the next nearby question:
**once Helm can explain what a slice means and how it was served, how should it re-run that exact slice on another footing and explain the delta honestly?**

The companion cubes still say the same big thing:
- freeze laws before big centers,
- keep shell-owned truth stronger than explanation,
- and do not let design-phase convenience harden into fake authority.

## What SlopOS still teaches best

### 1) Family/index discipline will matter even more once Helm has replay and variance furniture
SlopOS's family maps and singleton discipline still matter.
They matter even more now,
because replay capsules,
variance cards,
compare lanes,
serve strips,
and validator rails could easily multiply into a folklore maze.

Helm should steal a lighter equivalent before those families rhyme too hard.

### 2) Historical or descriptor evidence is still weaker than current live truth
SlopOS keeps repeating the same excellent lesson:
issued descriptors,
historical receipts,
and provider-local metadata are useful,
but they are not portable current-state oracles.

That transfers directly here.
A replay capsule,
old version,
or compare branch should never outrank:
- the exact live source truth,
- the exact observed basis,
- or the exact current shell object being acted on.

### 3) Design-phase humility still says: prove one humane replay slice, not a giant experiment center
SlopOS is still design-phase,
and that remains helpful.
The right move is still:
- pin the law,
- add one bounded seam,
- and resist inventing one giant center too early.

Helm should treat replay and variance work the same way.
Warm the cluster,
prove one humane specimen,
and resist the urge to declare a universal experiment lab.

## What Schell still teaches best

### 1) Proposal, checkpoint, execution, and residue are different truths
Schell keeps insisting that:
- proposal,
- checkpoint,
- exact execution,
- and later residue
are different truths.

That transfers directly here.
A replay request is not the replay result.
A replay result is not the publish decision.
A result delta is not the later adoption receipt.

### 2) Separate lanes make compare work safer
Schell's recurring lesson about separate lanes still matters:
- draft lane,
- compare lane,
- publish/adopt lane,
- receipt/history lane.

If Helm grows replay capsules and variance cards,
it should keep those lanes explicit instead of collapsing them into one smart rerun object.

## What ViewFS still teaches best

### 1) Basis record, drift verdict, reconsent, and renewed artifact are different things
ViewFS is the sharpest local teacher for this pass.
Its basis/drift/reconsent split maps almost perfectly onto replay work:
- one exact old basis record,
- one present-time drift verdict,
- one fresh approval or explicit compare choice,
- and one renewed artifact/result.

That means Helm should avoid pretending an old reviewed slice can simply be replayed forever with no fresh footing check.

### 2) Delta recipe, basis, apply session, and reconstructed target are different classes
ViewFS also keeps pressing the useful distinction between:
- delta recipe,
- exact basis requirement,
- current apply session,
- and reconstructed target.

That transfers directly.
A replay capsule,
current compare run,
and resulting compared answer should stay separate classes.

## What Harbor, Foundry, and Steward add

### Harbor
Harbor keeps teaching that route discovery,
trust,
and aftermath are separate truths.
That matters for current-input and collaborative-session links: visibility and routability do not become authority.

### Foundry
Foundry's exact check attachment still says the same useful thing:
check posture belongs next to the exact layer or candidate being judged.
That extends naturally to replay results and variance cards.

### Steward
Steward keeps teaching that presence,
discovery,
and lease-like trust posture should stay explicit.
That is a useful reminder that version-pinned and collaborative links can help work without silently becoming current live state.

## Lessons Helm must learn from the past

### Must learn #1: replay request is not replay result
A replay capsule is valuable.
It is still not the same thing as the later rerun answer.

### Must learn #2: pinned inputs are not live defaults
Current-input links,
remembered filters,
and old version pins should stay visibly different from current published defaults.

### Must learn #3: compare lane is not mainline
Branch,
clone,
deferred,
and pinned-history compare lanes should stay visibly weaker than published or adopted truth.

### Must learn #4: variance is explanation, not adoption
A variance card can be wonderful.
It should not impersonate publish,
policy,
or settlement.

### Must learn #5: exact from/to footing matters
A diff without exact compared bases turns into folklore fast.
Helm should keep exact from/to footing visible whenever it compares results.

## What Helm should steal now

- a SlopOS-style family/index discipline before replay and variance families multiply too far
- Schell's lane separation for replay request / compare lane / adoption / receipt
- ViewFS basis-versus-drift-versus-renewal texture for replay honesty
- Harbor's refusal to let visibility routes impersonate authority
- Foundry's check-attachment posture on replay results
- Steward's discovery/lease humility for shared current-input and collaborative-session links

## Product judgment

Do **not** freeze a giant experiment lab.
Do **not** freeze a universal branch manager.
Do **not** let replay summaries or version pins become a second authority plane.

But do keep warming an adjacent cluster around:
- replay capsules,
- variance cards,
- compare lanes,
- and maybe later explicit pinned-share posture.

That looks like the next best way to make Helm's datacube feel super truthful and super useful
once reviewed slices,
smart decks,
and richer evidence briefs start becoming depended-on shell objects that people want to replay,
compare,
and share exactly.
