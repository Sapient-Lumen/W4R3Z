# Research bibliography — 2026-03-23 pass CLXII

## External official product/doc pressure reopened in this pass

- GitHub Actions — contexts reference (`run_id`, `run_number`, `run_attempt`)
- GitHub — merge queue / `merge_group`
- GitHub — ruleset Evaluate mode and Rule Insights posture
- AWS Step Functions — redrive from unsuccessful step,
  preserve successful-step history,
  keep original version/alias association
- Temporal — Continue-As-New / execution chain / same workflow id,
  new run id,
  fresh history
- Google Cloud — long-running operations poll / cancel / finite retention
- Microsoft Graph — upload sessions,
  `expirationDateTime`,
  `nextExpectedRanges`,
  resume,
  cancel,
  explicit commit behavior
- Dropbox — cursor expiry / reset and fresh relist requirement
- Kubernetes — watch bookmarks,
  `sendInitialEvents`,
  synced-through resource version
- Grafana — time-range compare for the same investigation items
- Datadog — notebook version history restore / clone
- Honeycomb — board templates
- Obsidian — bases views
- Raycast — shared quicklinks

## Local companion surfaces reopened in parallel

- SlopOS locality / boundary / weaker-vs-stronger truth surfaces
- Schell proposal / review / run / receipt / proof-artifact pressure
- ViewFS cursor / watermark / subscription / snapshot / gap / receipt separation
- Ward read cuts / staleness budgets / ambiguity windows / revalidation fences
- Steward restart-budget / repair-gate / typed recovery posture
- Harbor route / receiver-visible aftermath separation
- Foundry runtime evidence smaller than verdict

## Resulting judgment

Helm should complement aftermath decks and recovery maps with a compact **resumption brief** and typed **gap verdict**,
so operators can return later without having to infer continuity,
change significance,
or reset class from logs,
timestamps,
or wishful thinking.
