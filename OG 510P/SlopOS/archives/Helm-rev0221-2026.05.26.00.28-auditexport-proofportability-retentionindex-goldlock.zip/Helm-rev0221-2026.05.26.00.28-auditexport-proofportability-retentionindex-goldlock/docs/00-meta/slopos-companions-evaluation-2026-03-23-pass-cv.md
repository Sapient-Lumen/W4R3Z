# SlopOS companion-cube evaluation — 2026-03-23 — pass CV

## Purpose

Continue reading **SlopOS**, **ViewFS**, **Schell**, and **Steward** as design-phase teachers for Helm,
without pretending any one cube has already finished the law for the whole shell.

This pass asks a narrower Exchange question:

**what object should Helm add so offered material can stay typed, multi-representation, promised, and weak until an exact route is chosen — without collapsing offer, selector, route, materialization, and receiver-local authority into one flattering “shared” state?**

## Strongest lesson from SlopOS

SlopOS keeps teaching the same constitutional cut from several angles:
**provider-local suggestion or launch mechanics are not selector truth, and accepted handoff is not downstream completion or current receiver state.**

That pressure is especially clear when read together:
- `mcp-completion-import-boundary-v0.md` says provider-suggested arguments remain bounded suggestions rather than durable selector/default/workflow truth.
- `namecert-selection-boundary-v0.md` says bounded candidate sets should stay explicit rather than silently picking one winner.
- `openuri-launch-completion-boundary-v0.md` says launch admission is not target completion or live receiver truth.
- `openuri-session-selection-boundary-v0.md` says generic launch must not smuggle browser-profile/session choice.

The transferable Helm lesson is:
**an offer is not a route,
and a suggested or available target is not yet a chosen receiver.**

That matters directly for Exchange.
If Helm receives typed material from clipboard, drop, drag, helper output, or a share surface,
it still needs one honest object for “what is being offered here?” before it upgrades that situation into “where did it land?”

## Strongest lesson from ViewFS

ViewFS keeps refusing one especially tempting lie:
**promised outputs, transfer offers, request wrappers, and durable refs are not already-materialized live authority.**

Its non-claims pressure is extremely useful for Helm.
A transfer offer should therefore be able to say:
- this representation is already materialized,
- this one is provider-backed open-in-place,
- this one is promised on demand,
- this one is preview-only,
- or this one would require a stronger receiver-local import/materialization step.

That makes Exchange much more honest than path paste folklore or one universal “attachment” blob.

## Strongest lesson from Schell

Schell’s ingress and shell-facing route work still teaches that paste, drop, and selection should remain typed and visible where authority matters.
A text-looking payload may really be:
- a selection,
- a document-like thing,
- a proposed command,
- a remote attach route,
- or a shell-facing object that should not be flattened too early.

That pushes Helm toward a **transfer offer** object rather than a string-first ingress myth.
The offer can preserve multiple candidate representations and let later route choice stay explicit.

## Strongest lesson from Steward

Steward keeps teaching two useful shell habits:
- target selection should stay separate from foreground/focus or handler reuse folklore,
- and invocation receipts should say what actually happened.

That is a perfect reminder for Exchange.
Helm needs the pre-route object first,
and then it needs a separate route witness or receipt later.
The offer should not pretend the landing already happened.

## What Helm should keep from these cubes

Keep:
- provider-local suggestion staying weaker than reviewed selection
- explicit candidate sets instead of hidden winner rules
- launch / handoff admission staying weaker than downstream completion
- promised or provider-backed material staying weaker than materialized receiver-local state
- shell-owned typed ingress and route honesty
- receipts that say what actually happened after the route is taken

Peel away:
- one universal clipboard/attachment/share blob
- hidden default-target memory being treated as current selection truth
- “available representation” being mistaken for “already materialized file”
- generic completion or suggestion lists masquerading as user choice
- any temptation to call a target “selected” before Helm has a real choice receipt or route witness

## Current judgment

Helm still should **not** freeze a giant clipboard backend,
share-sheet religion,
or final packet ontology.
But it probably **is** time to warm one compact specimen for the Exchange pillar:

**transfer offers** — shell-owned,
weak,
reviewable offered-material objects that preserve exact source,
exact representation menu,
materialization posture,
preview hints,
and route-adjacent possibilities
without pretending a receiver or route has already been chosen.

That feels like a genuine Exchange-specific Helm move,
not just another global shell abstraction.
