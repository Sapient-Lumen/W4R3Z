# Research bibliography — 2026-03-22 — pass LXXIX

Primary internal teacher documents re-opened in this pass:

- SlopOS: `docs/30-architecture/namecert-selection-boundary-v0.md`
- SlopOS: `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- SlopOS: `docs/30-architecture/powerbox-posture-v0.md`
- SlopOS: `docs/30-architecture/openuri-portal-posture-v0.md`
- Schell: `START_HERE.md`
- ViewFS: `docs/70-shell/follow-tails-attach-rails-and-control-panes.md`
- ViewFS: `docs/70-shell/chooser-sheets-staging-trays-and-grant-ledgers.md`
- ViewFS: `docs/70-shell/ceiling-pills-narrowing-previews-and-scope-fuses.md`
- Steward: `docs/30-architecture/label-surface-posture-v0.md`
- Steward: `docs/30-architecture/chrome-lane-posture-v0.md`
- Steward: `docs/30-architecture/chooser-surface-posture-v0.md`

Primary outside teachers consulted in this pass:

- Warp Launch Configurations — https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp URI Scheme — https://docs.warp.dev/terminal/more-features/uri-scheme
- Raycast Arguments — https://developers.raycast.com/information/lifecycle/arguments
- Arc Peek — https://resources.arc.net/hc/en-us/articles/19335302900887-Peek-Preview-Sites-From-Pinned-Tabs
- Android Selected Photos Access — https://developer.android.com/about/versions/14/changes/partial-photo-video-access
- Google Drive API scopes / `drive.file` guidance — https://developers.google.com/workspace/drive/api/guides/api-specific-auth
- Google Picker overview — https://developers.google.com/workspace/drive/picker/guides/overview
- Google Picker display guide — https://developers.google.com/workspace/drive/api/guides/picker
- Google Workspace add-on `currentonly` scopes — https://developers.google.com/workspace/add-ons/concepts/workspace-scopes
- VS Code Workspace Trust — https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- GitHub protected branches — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
- Linear Triage — https://linear.app/docs/triage
- Linear Triage Intelligence — https://linear.app/docs/triage-intelligence
- Terraform plan — https://developer.hashicorp.com/terraform/cli/commands/plan
- Terraform apply — https://developer.hashicorp.com/terraform/cli/commands/apply
- Figma guide to branching — https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
- Figma version history — https://help.figma.com/hc/en-us/articles/360038006754-View-a-file-s-version-history
- Tailscale Serve — https://tailscale.com/docs/features/tailscale-serve
- Tailscale Funnel — https://tailscale.com/docs/features/tailscale-funnel

Short reading judgment:

- strongest anti-hidden-chooser teacher: SlopOS `namecert-selection-boundary-v0.md`
- strongest exact-not-nearby teacher: SlopOS `openuri-showitem-exactness-boundary-v0.md`
- strongest request-local chooser teacher: SlopOS `powerbox-posture-v0.md`
- strongest current restricted-first teacher: VS Code Workspace Trust
- strongest picker-scoped access cluster: Android Selected Photos Access + Google Picker + `drive.file` + Google Workspace `currentonly`
- strongest front-door pressure: Warp + Raycast
- strongest weak-preview pressure: Arc + Figma
- strongest reviewed-basis pressure: Terraform saved plans + GitHub stale review rules
- strongest triage posture: Linear
- strongest exposure-ladder pressure: Tailscale Serve + Funnel
