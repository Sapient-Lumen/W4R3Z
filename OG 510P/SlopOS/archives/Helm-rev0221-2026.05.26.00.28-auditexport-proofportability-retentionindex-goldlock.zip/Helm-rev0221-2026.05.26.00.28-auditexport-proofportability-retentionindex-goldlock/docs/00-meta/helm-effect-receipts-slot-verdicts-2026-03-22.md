# Helm effect receipts + slot verdict ledgers — 2026-03-22

Purpose: name the next compact shell move after action warrants and drift gates.

## Main idea

Helm likely now wants one shell-owned object for:

**what exact effect actually happened after the stronger act?**

That object should be an **effect receipt**.

And because many strong shell acts are partial,
selective,
or receiver-local,
Helm likely also wants one adjacent answer to:

**which exact slots or classes landed,
rebounded,
default-filled,
stayed pending,
or were refused?**

That second surface should be a **slot verdict ledger**.

## Why this matters now

Helm already has useful nearby objects:

- **context loadouts** — what was intentionally in play
- **contribution witnesses** — what actually influenced the run
- **claim envelopes** — what the output claims
- **reliance ladders** — the right next responsible move
- **action warrants** — what exact stronger change is being proposed
- **drift gates** — whether the reviewed basis still matches the mutable thing
- **current-live beacons** — what is actually live now

What Helm still lacks is a compact durable answer to:

- what exact effect happened
- what exact affected set changed
- what remained partial or refused
- how this effect relates to current-live truth now
- and what the safest nearby next rung is:
  inspect,
  undo,
  redo,
  reopen unresolved slots,
  or compare against current drift

Without that,
Helm risks slipping back into:
- Apply buttons that vanish into folklore,
- “done” badges that carry too much semantic weight,
- imported or selective landings that quietly become “mostly succeeded,”
- and AI-assisted actions that look responsible before the act but vague after it.

## What an effect receipt is

An **effect receipt** is the durable post-act sibling of an action warrant.
It is not merely “success.”
It is the shell-owned witness for one exact completed,
partially-completed,
no-op,
or refused effect.

A useful first effect receipt would carry:
- source warrant or source act witness
- exact subject / owner surface
- exact effect classification
- exact affected-set or changed-set witness
- exact reviewed basis witness when relevant
- relation to any rollback / redo / restore path
- relation to current-live beacon when current truth later diverges

The point is not the noun.
The point is the law:

**strong effects deserve durable exact aftermath truth.**

## What a slot verdict ledger is doing here

Slot verdict ledgers were already warm in Helm.
This pass makes their role clearer.
They are the durable partial-outcome sibling of effect receipts.

A whole-surface effect receipt can say:
- what effect happened,
- where,
- and how strong it was.

A slot verdict ledger can then say:
- which exact slots landed exactly,
- which rebound choices were taken,
- which defaults filled omitted classes,
- which slots stayed pending,
- and which were refused or dropped.

That is how Helm can outgrow today’s coarse all-or-nothing review tools without building a giant sync religion.

## Relation to nearby Helm objects

### Not a current-live beacon
An effect receipt is historical durable truth.
A current-live beacon is the stronger answer to what is live now.

### Not an action warrant
A warrant is pre-act proposal truth.
An effect receipt is post-act aftermath truth.

### Not a claim envelope
A claim envelope explains what a result is saying.
An effect receipt witnesses what the stronger shell act actually did.

### Not a giant audit warehouse
These should start compact.
One durable effect witness and,
when needed,
one compact slotwise ledger are enough for a first specimen.

## Why this seems especially worth stealing

Current products are increasingly good at:
- preview before apply,
- staged review,
- explicit undo/redo,
- conflict handling,
- and keeping privileged follow-on as a stronger rung.

They are still often weak at:
- durable exact aftermath truth,
- partial structured outcome truth,
- and keeping current-live truth separate from historical effect truth.

That is where Helm can be unusually good.

## Super-awesome moves this unlocks

### 1. Exact post-change cards that stay useful later
A stronger act can leave behind one durable card that says:
- what changed,
- what didn’t,
- and how to inspect or undo it.

### 2. Better AI-assisted shell actions
AI can propose with a warrant,
and after adoption Helm can keep an exact effect receipt instead of a disappearing “done.”

### 3. Honest partial landing and import stories
A shared starter,
route,
deck,
dock band,
or selective adoption can stay richly partial without turning into a mystery later.

### 4. Better Recall and Operations Center truth
Helm can let people return to real prior actions,
not just vague history rows.

## What not to steal

- do not make every tiny action into giant PR bureaucracy
- do not let effect receipts impersonate current-live truth forever
- do not let whole-surface success hide slotwise partiality
- do not let undo/redo become ambient magical repair without durable witnesses
- do not build a giant workflow archive before one tiny aftermath slice works

## Pull-the-trigger judgment

Still yes:
- **saved view objects**
- **checkpoint branches**

Now also worth defining as support contracts:
- **effect receipts**
- **slot verdict ledgers**

If Helm gets this right,
it can feel stronger than current review/apply systems precisely because it will not stop at proposal honesty;
it will also keep **aftermath honesty**.
