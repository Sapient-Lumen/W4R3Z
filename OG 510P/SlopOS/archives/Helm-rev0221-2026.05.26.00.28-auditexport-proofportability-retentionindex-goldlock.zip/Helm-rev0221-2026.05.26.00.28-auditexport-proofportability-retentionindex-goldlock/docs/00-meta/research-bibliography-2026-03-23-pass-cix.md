# Research bibliography — 2026-03-23 — pass CIX

1. Microsoft Learn — **Receive data / ShareOperation status methods**
   - URLs:
     - https://learn.microsoft.com/en-us/windows/uwp/app-to-app/receive-data
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.sharetarget.shareoperation.reportdataretrieved?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.sharetarget.shareoperation.reportcompleted?view=winrt-26100
   - Why it mattered: Windows explicitly separates started, data-retrieved, and completed share status, which is direct evidence that payload acquisition and final completion are different truths.

2. Apple Developer Documentation — **UIActivityViewController completionWithItemsHandler**
   - URLs:
     - https://developer.apple.com/documentation/uikit/uiactivityviewcontroller/completionwithitemshandler-swift.typealias
     - https://developer.apple.com/documentation/uikit/uiactivityviewcontroller/completionwithitemshandler-swift.property
   - Why it mattered: Apple's callback fires when an activity completes or when the controller is dismissed, which is a useful warning that callback timing may still be weaker than durable downstream effect.

3. MDN — **Navigator.share() / Web Share API**
   - URLs:
     - https://developer.mozilla.org/en-US/docs/Web/API/Navigator/share
     - https://developer.mozilla.org/en-US/docs/Web/API/Web_Share_API
   - Why it mattered: Web Share's resolution timing differs by platform, which is another proof that route/handoff timing should not be flattened into one universal completion story.

4. Google Cloud / Google Workspace — **google.longrunning Operation and Drive long-running operations**
   - URLs:
     - https://docs.cloud.google.com/service-infrastructure/docs/service-management/reference/rpc/google.longrunning
     - https://developers.google.com/workspace/drive/api/guides/long-running-operations
   - Why it mattered: long-running operations keep metadata, done/not-done, and exactly one of error/response separate, which is a strong model for effect receipts with bounded terminal truth.

5. AWS Step Functions — **Redrive executions / DescribeExecution**
   - URLs:
     - https://docs.aws.amazon.com/step-functions/latest/dg/redrive-executions.html
     - https://docs.aws.amazon.com/step-functions/latest/apireference/API_DescribeExecution.html
   - Why it mattered: redrive preserves successful-step history and reruns only the unsuccessful step, which is direct support for attempt-bound receipts and subset-preserving repair history.

6. GitHub Docs — **workflow run attempts, reruns, and logs**
   - URLs:
     - https://docs.github.com/en/actions/reference/workflows-and-actions/contexts
     - https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs
     - https://docs.github.com/en/rest/actions/workflow-runs
   - Why it mattered: GitHub keeps run identity distinct from run-attempt identity, allows rerunning failed jobs or a specific job, and exposes attempt-specific retrieval and logs.

7. Kubernetes — **Indexed Jobs / per-index failure handling**
   - URLs:
     - https://kubernetes.io/docs/concepts/workloads/controllers/job/
   - Why it mattered: Kubernetes keeps `completedIndexes` and `failedIndexes` distinct and can still mark the overall job failed, which is excellent support for slot verdict ledgers and partial aftermath truth.

## Companion-cube anchors revisited

- `docs/30-architecture/effect-contract-schema-v0.md` (SlopOS)
- `docs/30-architecture/mcp-completion-import-boundary-v0.md` (SlopOS)
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md` (SlopOS)
- `docs/30-architecture/openuri-materialization-boundary-v0.md` (SlopOS)
- `docs/80-terminal/handoff-ladders-observation-truth-and-completion-humility.md` (Schell)
- `docs/70-shell/truthful-completions-and-routing.md` (ViewFS)
- `docs/30-architecture/handles-refs-and-receipts.md` (ViewFS)
- `docs/30-architecture/runtime-cycle-witness-posture-v0.md` (Steward)
- `docs/30-architecture/activation-receipt-posture-v0.md` (Steward)

## Current judgment

The best outside and companion-cube pressure now converges on the same post-act ladder:

**route witness → materialization witness → effect receipt → slot verdict ledger / rerun lineage**.
