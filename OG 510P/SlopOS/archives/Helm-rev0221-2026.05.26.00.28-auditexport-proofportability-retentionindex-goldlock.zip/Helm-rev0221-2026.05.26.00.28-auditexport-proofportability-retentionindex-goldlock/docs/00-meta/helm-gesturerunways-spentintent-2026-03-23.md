# Helm: gesture runways + spent intent — 2026-03-23

## Headline

Helm should get **better at preparing sensitive acts up to the exact human seam**,
not broader at delayed automation theater.
The next compact move worth warming is:

- **gesture runways**
- with explicit **spent-intent** posture

## Why now

Helm already has:
- intent sparks,
- direct-gesture gates,
- trusted chrome lanes,
- host-effect witnesses,
- access verdict cards,
- action warrants,
- drift gates,
- and state tuples for compact truthful shell chrome.

What it still lacks is one humane shell object for the final approach to a sensitive act.

Without that,
Helm risks two opposite failures:
- making people redo too much setup manually at the last moment,
- or letting prepared context, helper work, or old clicks quietly spend authority later.

## The good pattern

### Gesture runways

A gesture runway should carry:
- one exact act family
- one exact subject
- one prepared parameter set or narrowed choice set
- one reviewed basis witness when that matters
- one final requirement class:
  - `fresh-spark-required`
  - `direct-gesture-required`
  - `manual-only`
- one expiry posture
- one visible abort / hold / re-arm path
- one linked result path after success,
  refusal,
  expiry,
  or cancellation

### Spent-intent posture

A runway should also admit when fresh intent is:
- still live
- already spent
- expired
- voided by basis drift
- or irrelevant because direct same-gesture execution is required

That keeps the shell from implying that a prepared act is still launchable merely because it is still visible.

## What to keep from older inspirations

Keep:
- transient-versus-sticky activation
- activation-consuming acts
- chooser-bound final steps
- prompt-every-time capture start
- one-session / one-use capture tokens
- user-controlled request handles with bounded lifetime
- one-gesture-per-strong-open posture

Peel away:
- giant permissions bureaucracy
- global click-history dashboards
- helper laundering of direct user meaning
- queue-first replay of sensitive acts
- modal spam that forgets prepared context

## Why this makes Helm more awesome

This move upgrades several already-warm Helm surfaces:

- **Omnibox** can prepare a strong act richly,
  then stop at one exact shell-owned final step.
- **Exchange** can prepare a reveal/export/open/control move without pretending the sensitive crossing already happened.
- **Recall** can reopen a historical or helper-prepared act as a runway rather than a spooky rerun.
- **Operations Center** can explain not just that an act is blocked,
  but whether it is waiting for direct gesture,
  expired,
  already spent,
  or invalidated by drift.
- **Trusted chrome** can feel luxurious because the human only needs to supply the final seam,
  not rebuild the whole setup.

## Pull-the-trigger judgment

This now looks warm enough to admit as the next compact support proof.
Not as a new pillar,
and not as a giant policy subsystem,
but as one premium shell object:

**gesture runways — shell-owned prepared act lanes that preserve setup,
stop at the exact fresh/direct human seam,
and then issue an honest success / refusal / expiry result.**
