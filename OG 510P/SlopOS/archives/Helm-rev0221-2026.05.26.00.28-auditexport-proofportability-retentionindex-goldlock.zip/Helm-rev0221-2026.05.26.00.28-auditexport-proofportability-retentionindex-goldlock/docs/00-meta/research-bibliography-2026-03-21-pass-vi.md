
# Research bibliography — 2026-03-21 — pass VI

## Internal teacher cubes

- Helm-rev0011-2026.03.21.14.13-requesttruth-activitycockpit.zip
- SlopOS-rev0576-2026.03.21.06.08-openuri-speculative-loading-boundary.zip
- Schell-rev0031-2026.03.21.02.14-completioncards-paramhelp-preflighthonesty-originbadges-hintfoundry.zip
- DelayBasin-rev0142-2026.03.21.10.03-sessionaffinity-stickyreuse-shadowgate-nosessioncourt-affinityglass.zip

## External sources consulted in this pass

- PowerToys Command Palette overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- PowerToys Command Palette extensibility overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/extensibility-overview
- PowerToys Workspaces — https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- PowerToys Peek — https://learn.microsoft.com/en-us/windows/powertoys/peek
- GNOME Activities overview — https://help.gnome.org/gnome-help/shell-introduction.html
- GNOME workspaces — https://help.gnome.org/gnome-help/shell-workspaces.html
- Obsidian Workspaces — https://obsidian.md/help/plugins/workspaces
- VS Code user interface / Timeline — https://code.visualstudio.com/docs/getstarted/userinterface
- VS Code multi diff editor (January 2024 release notes) — https://code.visualstudio.com/updates/v1_86
- VS Code Profiles — https://code.visualstudio.com/docs/configure/profiles
- VS Code agents overview and Agent Sessions docs — https://code.visualstudio.com/docs/copilot/agents/overview and https://code.visualstudio.com/blogs/2025/11/03/unified-agent-experience and https://code.visualstudio.com/blogs/2026/02/05/multi-agent-development
- Node-RED sidebar / debug docs — https://nodered.org/docs/user-guide/editor/sidebar/ and https://nodered.org/docs/user-guide/editor/sidebar/debug
- Raycast Quicklinks / Dynamic Placeholders / Snippets — https://manual.raycast.com/quicklinks and https://manual.raycast.com/dynamic-placeholders and https://manual.raycast.com/snippets

## What these sources were used for

This pass was mainly about task entry, saved setup artifacts, session/status surfaces, tiny accelerators, and truthful launch-state UX.
The goal was not to broaden Helm's pillars.
The goal was to decide whether the archive had reached the point where:
- entry-artifact truth should be frozen narrowly,
- and activity entry kits should be added as a candidate move.
