# Research bibliography — 2026-05-15 pass CLXXXVI

- Argo Rollouts canary: https://argo-rollouts.readthedocs.io/en/stable/features/canary/
- Argo Rollouts rollback window: https://argo-rollouts.readthedocs.io/en/stable/features/rollback/
- Flagger deployment strategies: https://docs.flagger.app/usage/deployment-strategies
- LaunchDarkly change history: https://launchdarkly.com/docs/home/releases/change-history
- LaunchDarkly scheduled changes: https://launchdarkly.com/docs/home/releases/scheduled-changes
- OpenFeature evaluation context: https://openfeature.dev/specification/sections/evaluation-context
- OpenFeature hooks: https://openfeature.dev/specification/sections/hooks
- OPA decision logs: https://openpolicyagent.org/docs/management-decision-logs
- Kubernetes server-side apply: https://kubernetes.io/docs/reference/using-api/server-side-apply/
- Kubernetes dry-run KEP: https://github.com/kubernetes/enhancements/blob/master/keps/sig-api-machinery/576-dry-run/README.md
- SLSA specification v1.2: https://slsa.dev/spec/v1.2/
- SLSA provenance: https://slsa.dev/spec/v1.0/provenance
- in-toto attestation spec: https://github.com/in-toto/attestation/blob/main/spec/README.md
- OpenTelemetry baggage: https://opentelemetry.io/docs/concepts/signals/baggage/
- OpenTelemetry event semantic conventions: https://opentelemetry.io/docs/specs/semconv/general/events/
- Temporal message handling: https://docs.temporal.io/handling-messages
- GitHub merge queue: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
