# SlopOS + companion cubes evaluation — 2026-03-23 pass CXII

Purpose: continue harvesting the narrowest laws Helm should steal from SlopOS, ViewFS, Schell, and Steward before freezing more shell machinery.

## Strongest pressure from SlopOS now

The most useful SlopOS lesson in this pass is not a new artifact family. It is a boundary law.

`approval-basis-posture-v0.md` and `acp-precondition-witness-posture-v0.md` keep saying the same thing in different words:
- old approval is not current approval
- mutable basis must already be encoded in exact action bytes or exact witness material
- ambient `latest` / `current` / `head now` must not be allowed to impersonate reviewed basis
- and preconditions are veto-only witness gates, not a second hidden policy engine

That is exactly the law Helm needs as its aftermath / continuation family gets stronger.
A continuation handle or remainder witness can be exact and still be unsafe to reuse on a drifted basis.

## Strongest pressure from ViewFS now

ViewFS is even more explicit.
RFC-0027 keeps:
- reuse candidate
- basis record
- drift check
- reconsent checkpoint
- renewed artifact
- and reuse receipt

separate on purpose.

RFC-0018 does the same for concurrency and contention:
- optimistic precondition
- create-if-absent guard
- short lease
- ownership hint
- conflict artifact
- explicit override

Those distinctions are gold for Helm.
They say the next premium move is not a giant continuity or retry wizard.
It is a small shell-owned truth for whether the old reviewed basis still binds the next stronger move.

## What Schell keeps teaching

Schell still matters because terminal and shell work keeps punishing false continuity.
A historic completion, transcript, or restored surface is not the same thing as present authority to continue.
So the terminal-facing lesson remains:
- live now
- historical receipt
- exact continuation
- and fresh review-again

should stay visibly different.

## What Steward keeps teaching

Steward keeps reinforcing that tiny status objects must be basis-honest and decay-honest.
That pressure now applies directly to aftermath and reuse surfaces:
- last confirmed is not current
- observed-on-basis-X is not permission to act on current basis Y
- and stale evidence should degrade into revalidate / compare / hold rather than silently riding forward

## What Helm should pull warmer now

### Revalidation checkpoints

Helm now has:
- effect receipts
- continuation handles
- remainder witnesses
- repair ladders

But it still lacks one compact shell-owned answer to:

**does the old reviewed basis still bind this next stronger act?**

A revalidation checkpoint should likely carry:
- one exact source witness (receipt / handle / warrant / return card)
- one exact reviewed basis reference
- one present-time relation to current basis
- one exact reason when it no longer binds
- one nearby next ladder: proceed, compare, refresh bind, review again, fresh chooser, or hold

### Keep drift gates, but stop asking them to do all the work

`drift-gate-candidate-contract-v0.md` remains right,
but Helm now wants one more user-facing object than a raw gate verdict.
The gate tells you whether the old basis still matches.
The checkpoint tells you what kind of fresh human or issuer step is now required.

## What to avoid

Do not:
- build a universal approval cache
- let old success mutate into current approval
- let “retry” or “resume” silently follow a newer head
- let remainder truth impersonate basis-match truth
- or build a giant workflow bureaucracy before one compact proof-bearing checkpoint exists

## Pull-the-trigger judgment

The seven pillars still look stable.
This is not a new pillar.
But it now looks wise to warm one more compact support specimen:

**revalidation checkpoints** beside **drift gates**,
so Helm can preserve exact historical effect and exact unfinished remainder while still refusing fake continuity on a changed basis.
