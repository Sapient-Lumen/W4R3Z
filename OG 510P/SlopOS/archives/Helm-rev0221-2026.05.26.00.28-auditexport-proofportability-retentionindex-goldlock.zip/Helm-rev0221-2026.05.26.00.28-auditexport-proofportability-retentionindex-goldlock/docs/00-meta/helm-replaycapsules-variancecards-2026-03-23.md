# Helm replay capsules, variance cards, and compare lanes — 2026-03-23

## The current call

Helm still does **not** need another pillar right now.
The seven pillars still look right.
The next admitted shell-wide ratchet is still **settlement witnesses + commit cards**.

But the archive now has enough pressure to say something sharper about what should make Helm amazing after the current semantic / serve / footing work:
**reviewed slices, smart decks, and richer evidence briefs should eventually be able to replay one exact slice on one alternate footing, environment, branch, or moment — and then explain what changed without lying that the replay request, the replay result, the diff summary, and the current live answer are all the same thing.**

## The lessons Helm must learn from the past

### 1) A replay request is not the replay result
Old products love a button that says `rerun`, `refresh`, or `compare` while smuggling several truths together.
Helm should resist that.
A replay capsule should bind:
- one exact source slice or brief,
- one exact recipe / basis / input posture,
- one target footing or alternate basis,
- and one requested rerun lane.

The visible result should remain a later distinct thing.

### 2) Pinned inputs are not current defaults
Current inputs,
remembered filters,
branch heads,
version-pinned notebooks,
and last-viewed parameters are all useful.
They are not the same as the current default meaning of the source object.

### 3) Variance explanation is not adoption
A good variance card may explain:
- what changed in the result,
- what changed in inputs,
- what changed in basis,
- what changed in recipe,
- or what changed in serve path.

That is still weaker than publish,
adopt,
merge,
or bless-live.

### 4) Experimental lanes should stay visibly weaker than live truth
A zero-copy clone,
a deferred reference,
a fork,
a version-pinned brief,
or a compare branch can be wonderful.
They should still stay visibly weaker than the current live shell object or published slice until an explicit adopt/publish/fast-forward step lands.

### 5) Version and history should stay useful without becoming folklore
Exact old versions,
forks,
version pinning,
and side-by-side experiment diffs are wonderful because they preserve basis.
They become dangerous only when the operator can no longer tell whether they are looking at:
- the old pinned thing,
- the current live thing,
- or one fresh replay candidate.

## Great ideas worth stealing now

### A) Replay capsules
A reviewed slice,
smart deck,
or evidence brief should increasingly be able to mint one compact replay capsule bound to:
- exact subject,
- exact semantic recipe or query basis,
- exact inputs / filters,
- exact serve-path and `as-of` footing when relevant,
- and one requested alternate footing such as current-live,
  pinned historical,
  deferred prod state,
  clone branch,
  or compare branch.

### B) Variance cards
The result of a replay should increasingly be able to yield one compact variance card that can confess:
- output delta,
- changed dependencies,
- changed inputs,
- changed recipe or version,
- changed serving path,
- and whether the compared answer is still within the same trustworthy footing window.

### C) Compare lanes
Helm should increasingly distinguish:
- compare-in-place,
- replay-on-current-live,
- replay-on-pinned-old-basis,
- replay-on-branch / clone / deferred state,
- and replay-history-only.

That distinction is where Helm can feel unusually adult.

### D) Pinned share links
Shared deck-like or brief-like surfaces should increasingly be able to confess whether a link points at:
- current published defaults,
- current inputs,
- a collaborative live session,
- one exact frozen version,
- or one exact replay/compare result.

### E) Reversible trial posture
A compare lane that allows merge,
cherry-pick,
revert,
or fast-forward is valuable precisely because those moves remain visible later,
not because the lane quietly counted as mainline all along.

## Pillar-by-pillar pressure

### Object Browser
Steal:
- mint replay capsule from reviewed slice / deck / brief
- inspect exact pinned inputs and footing before rerun
- compare source answer to replay answer with one variance card
- keep compare lane visibly weaker than publish/adopt

### Operations Center
Steal:
- replay job rows,
- branch / clone / deferred-state compare rows,
- parameter / input / version mismatch rows,
- and result-delta rows that can jump back to exact compared runs.

### Recall
Steal:
- reopen exact old version,
- reopen current live,
- reopen pinned inputs,
- or rerun old footing on current truth without flattering them into one return action.

### Exchange
Steal:
- links and packets that confess published-default versus current-input versus collaborative-session versus pinned-version posture,
- and imported compare packets that remain inspect-only until adopted locally.

### Evidence briefs
Steal:
- brief members that can carry one replay capsule,
- one variance card,
- and one frozen compared cut,
without becoming a giant notebook or experiment lab.

## Moves that could make Helm super awesome

### 1) Replay this exact slice on current truth
From any reviewed slice or smart deck:
- take the exact recipe,
- exact filters,
- exact footing,
- rerun on current-live,
- and then show one variance card that says what changed and why.

### 2) Compare draft math to published meaning
Let a local recipe fork or deck override run against deferred prod state,
zero-copy clone state,
or a compare branch,
then show one result-delta card before any publish/adopt move exists.

### 3) Share one exact argued view
A brief or deck should be able to share:
- published defaults,
- current inputs,
- collaborative session,
- frozen version,
- or exact compare result,
with each posture staying explicit.

### 4) Make reruns basis-honest
Do not just say `refresh`.
Offer:
- rerun on current live,
- replay on pinned old basis,
- replay on deferred prod state,
- replay on clone branch,
- compare old served answer to new answer,
- or open history only.

### 5) Keep the compare lane reversible
If a compare branch or replay lane becomes strong enough to matter,
Helm should make merge,
fast-forward,
revert,
and cherry-pick posture inspectable afterwards.
That makes experimentation feel powerful without turning drafts into folklore mainline.
