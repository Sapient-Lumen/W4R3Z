# Research bibliography — 2026-03-23 — pass C

- Apple Developer documentation — Live Activities / ActivityKit / HIG
  - used for: glanceable current-state surfaces,
    ongoing activity posture,
    and up-to-date task/event information across devices
- Android Developers — runtime permission guidance with privacy indicators
  - used for: live microphone/camera use indicators
- Android Developers — Android 12 Privacy Dashboard overview
  - used for: timeline-style recent-use posture distinct from live indicators
- Microsoft Support — Windows camera, microphone, and privacy
  - used for: live-use indicators,
    nearby control surfaces,
    and app/website privacy controls
- Microsoft Learn — PowerToys Command Palette Dock
  - used for: tiny persistent edge toolbar / dock-band validation
- Microsoft Learn — PowerToys Workspaces
  - used for: saved launch/layout structure distinct from live continuity
- Microsoft Learn — Windows Terminal startup / persistedWindowLayout
  - used for: layout restore that explicitly excludes pane contents
- Kubernetes documentation — Pod Lifecycle / Pod conditions
  - used for: multi-axis status grammar instead of one phase myth
- GitHub Docs — status checks
  - used for: separating state-in-progress from final conclusion
- GitHub Docs — viewing all issues and pull requests / saved views
  - used for: saved views as first-class stale-aware monitoring surfaces
