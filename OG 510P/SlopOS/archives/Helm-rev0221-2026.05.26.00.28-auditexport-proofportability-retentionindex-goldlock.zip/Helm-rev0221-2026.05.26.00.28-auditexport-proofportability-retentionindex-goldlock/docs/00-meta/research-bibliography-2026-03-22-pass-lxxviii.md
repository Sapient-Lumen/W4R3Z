# Research bibliography — 2026-03-22 — pass LXXVIII

Primary internal teacher documents re-opened in this pass:

- SlopOS: `docs/30-architecture/architecture-overview.md`
- SlopOS: `docs/00-meta/roadmap.md`
- SlopOS: `docs/30-architecture/namecert-selection-boundary-v0.md`
- SlopOS: `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- SlopOS: `docs/30-architecture/network-lease-address-selection-boundary-v0.md`
- Schell: `docs/00-meta/research-synthesis-2026-03-20.md`
- Schell: `docs/00-meta/slopos-datacube-evaluation-pass-xciv.md`
- Steward: `docs/30-architecture/architecture-overview.md`
- Steward: `docs/30-architecture/design-principles-v0.md`
- Steward: `docs/30-architecture/decision-map.md`
- ViewFS: `rfcs/0037-viewfs-keep-resources-prompts-tools-apps-and-bindings-separate.md`
- ViewFS: `rfcs/0040-viewfs-keep-observe-attach-control-and-sideband-lanes-separate.md`

Primary outside teachers consulted in this pass:

- Warp Launch Configurations — https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp URI Scheme — https://docs.warp.dev/terminal/more-features/uri-scheme
- Arc Peek — https://resources.arc.net/hc/en-us/articles/19335302900887-Peek-Preview-Sites-From-Pinned-Tabs
- Chrome `activeTab` — https://developer.chrome.com/docs/extensions/develop/concepts/activeTab
- Android Selected Photos Access — https://developer.android.com/about/versions/14/changes/partial-photo-video-access
- Android Photo Picker — https://developer.android.com/training/data-storage/shared/photo-picker
- Google Drive `drive.file` scope — https://developers.google.com/workspace/drive/api/guides/api-specific-auth
- Google Workspace add-on `currentonly` scopes — https://developers.google.com/workspace/add-ons/concepts/workspace-scopes
- GitHub protected branches — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
- GitHub branch protection rule details — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/managing-a-branch-protection-rule
- Linear Triage — https://linear.app/docs/triage
- Linear Triage Intelligence — https://linear.app/docs/triage-intelligence
- Raycast for Teams / shared quicklinks and commands — https://www.raycast.com/blog/bringing-raycast-to-teams
- Raycast typed arguments — https://www.raycast.com/blog/inputs-for-script-commands
- Figma request branch review — https://help.figma.com/hc/en-us/articles/5691414603543-Request-a-branch-review
- Figma guide to branching — https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching

Short reading judgment:

- strongest design-phase teacher: SlopOS roadmap + candidate-architecture posture
- strongest anti-hidden-chooser teacher: SlopOS namecert selection boundary
- strongest exact-not-nearby teacher: SlopOS openuri show-item exactness boundary
- strongest front-door pressure: Warp + Raycast
- strongest inert-preview pressure: Arc + Figma
- strongest narrow-grant pressure: Chrome + Android + Google Drive + Google Workspace
- strongest reviewed-basis pressure: GitHub branch protection rules
- strongest humble-AI pressure: Linear triage + suggestion reasons
