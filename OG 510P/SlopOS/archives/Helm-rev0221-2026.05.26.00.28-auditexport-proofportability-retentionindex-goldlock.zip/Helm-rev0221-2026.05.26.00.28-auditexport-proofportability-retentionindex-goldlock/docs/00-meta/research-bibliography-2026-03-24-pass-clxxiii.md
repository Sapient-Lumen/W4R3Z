# Research bibliography — 2026-03-24 — pass CLXXIII

Primary sources reviewed for this pass:

1. Git pull docs — divergent branches require specifying reconcile mode (`--rebase` or `--no-rebase`).
2. GitHub docs: keeping a pull request in sync with the base branch — update via merge or rebase, with conflicts blocking the easy path.
3. Git range-diff docs — compare two versions of a patch series / two commit ranges.
4. Git rerere docs — record and reapply previously hand-resolved conflicts; clear/forget support.
5. Git cherry-pick docs — continue / skip / abort sequencer posture and optional rerere autoupdate with double-check lane.
6. Figma docs: get updates from main files — all-or-nothing updates from main, side-by-side conflict resolution with main-vs-branch choices.
7. Figma docs: incomplete merges or updates — restore-before-update / restore-before-merge posture after partial failure.
8. Kubernetes Server-Side Apply docs — explicit field ownership, conflicts, and force/ownership transfer.
