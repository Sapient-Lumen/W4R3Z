# Research bibliography — 2026-03-23 — pass LXIX

## Sources consulted for this pass

1. GitHub Docs — Managing a merge queue
   - merge queue re-checks queued work against the latest target branch and pull requests already ahead in the queue
   - workflows must trigger on `merge_group` for required checks to run in queue context
   - reordering can force full rebuilds of in-progress pull requests
2. GitLab Docs — Merge trains
   - merge requests are compared to earlier merge requests in the train to ensure they work together
   - later pipelines restart when earlier queued items fail or are removed
   - GitLab shows order and queue status in a dedicated merge train view
3. Vercel Docs — Promoting deployments
   - preview deployments can be promoted to production through an explicit confirmation flow
   - teams can stage a production-like deployment first and promote it later
   - instant rollback and preview promotion are distinct actions
4. Netlify Docs — Deploy Previews
   - deploy previews let teams preview, review, and experience changes without publishing them to production
   - previews can also be built from agent runs, not only pull / merge requests
5. LaunchDarkly Docs — Guarded rollouts
   - guarded rollouts progressively increase exposure while monitoring metrics for regressions
   - regressions can pause a rollout and optionally roll it back automatically
   - guarded rollout tiles keep metric-by-metric health visible
6. Argo Rollouts Docs — Analysis & progressive delivery
   - canary rollout steps can set traffic weight, pause, run analysis, and then continue or abort
   - inline analysis blocks further promotion until the result is known
