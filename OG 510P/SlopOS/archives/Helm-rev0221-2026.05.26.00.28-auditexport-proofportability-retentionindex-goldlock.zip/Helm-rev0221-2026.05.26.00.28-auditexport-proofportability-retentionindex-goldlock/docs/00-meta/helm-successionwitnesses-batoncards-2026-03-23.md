# Helm succession witnesses + baton cards — 2026-03-23

## Why this pass happened

After **retreat witnesses**,
Helm could say what kind of comeback or shelter happened,
to what footing,
and what did not come back.
But it still lacked one humane operator answer:

**when responsibility or live attention moves,
who actually has the baton now,
what kind of relay happened,
and did the stronger lane survive the handoff?**

That gap appears across:
- live-checkout handoff between foreground and repair lanes
- review lane versus direct-user reassignment
- policy-preserving escalation versus policy-dropping one-off relay
- shared baton versus exclusive baton
- pending acceptance versus accepted relay
- timeout return versus durable holder change

## Product judgment

The next narrow trigger is now worth pulling:

- keep the seven pillars stable
- do not add a new pillar
- keep **work claims** for current-touch / occupancy truth
- promote **succession witnesses** as the shell-owned compact answer to `who has the baton now, how did it move, and what survives that move?`
- promote **baton cards** as the tiny nearby rendering for that relay truth

A succession witness answers:
- exact subject or cohort
- previous holder and current holder
- relay class
- acceptance state
- whether policy / lane continuity was preserved,
  replaced,
  narrowed,
  or dropped
- whether the baton is single,
  shared,
  or queue-next
- expiry / renewal / return posture
- what exact next move is honest: wait,
  renew,
  accept,
  reclaim,
  override,
  or inspect history

A baton card answers that truth in one small human-facing form.

## Why this is worth stealing

The current official pressure is clean:

- Kubernetes Lease keeps holder identity,
  acquire time,
  renew time,
  lease duration,
  and transition count explicit
- PagerDuty incident reassignment distinguishes policy-preserving escalation/policy relay from direct-user relay that drops the policy lane
- GitHub assignees clarify who is working without pretending the work is done
- GitLab multiple assignees make shared responsibility and explicit self-removal visible

Those systems feel humane because they distinguish **holder truth**,
**policy continuity truth**,
**shared responsibility truth**,
and **outcome truth**.

## Lessons Helm must learn from the past

- `owned by` is too flattering if the product cannot say how the baton got there.
- `assigned` is too flattering if policy continuity changed or was dropped.
- `working on it` is too flattering if acceptance is still pending.
- `someone has it` is too flattering if the baton already expired back.
- the right shell magic is not hiding the relay;
  it is making baton class,
  policy continuity,
  and expiry / return posture obvious at a glance.

## What Helm should keep

Keep:
- work claims
- commitment witnesses
- revisit witnesses
- delivery / disposition witnesses
- reality strips
- Overview / Recall / Operations Center as weak projection surfaces

Add more clearly:
- **succession witnesses** near work claims,
  commitment witnesses,
  and live-checkout / lane handoff flows
- **baton cards** near reality strips,
  Overview tiles,
  Recall return points,
  and Operations Center rows

## What Helm should refuse

Do not:
- build a universal assignment dashboard
- flatten shared,
  exclusive,
  queued,
  pending-accept,
  and expired-return posture into one owner badge
- let direct-user reassignment impersonate policy-preserving relay
- let stale baton residue look like current holder truth
- let handoff imply outcome,
  adoption,
  or durable effect by adjacency

## Practical effect on Helm surfaces

A good compact Helm surface should increasingly be able to say:
- `foreground checkout → repair lane • accepted • returns on release`
- `incident baton → next escalation level • policy preserved`
- `direct relay to Maya • policy lane dropped`
- `shared baton • Maya + Lee • Sam removed self after review slice`
- `baton expired back to queue • no current holder`

That is a better next move than another pillar,
another owner dashboard,
or another mushy `handled by` story.
