# Research bibliography — 2026-03-22 — pass XLI

Primary references consulted for this pass:

- OpenAI Help Center — Projects in ChatGPT:
  https://help.openai.com/en/articles/10169521-projects-in-chatgpt
- Linear Docs — Custom Views:
  https://linear.app/docs/custom-views
- Linear Docs — Projects:
  https://linear.app/docs/projects
- Arc Help Center — Spaces: Distinct Browsing Areas:
  https://resources.arc.net/hc/en-us/articles/19228064149143-Spaces-Distinct-Browsing-Areas
- Arc Help Center — Pinned Tabs: Tabs you want to stick around:
  https://resources.arc.net/hc/en-us/articles/19231060187159-Pinned-Tabs-Tabs-you-want-to-stick-around
- Google Chrome Help — Manage tabs in Chrome (desktop):
  https://support.google.com/chrome/answer/2391819?co=GENIE.Platform%3DDesktop&hl=en
- Google Docs Editors Help — Use document tabs in Google Docs:
  https://support.google.com/docs/answer/15499791?co=GENIE.Platform%3DDesktop&hl=en
- Obsidian Help — Workspaces:
  https://help.obsidian.md/plugins/workspaces
- Obsidian Help — Introduction to Bases:
  https://help.obsidian.md/bases
- Warp docs — Launch Configurations:
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Microsoft Learn — PowerToys Workspaces utility:
  https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- Raycast Manual — Getting Started with Teams:
  https://manual.raycast.com/getting-started-with-teams
- Apple Support — Take actions and shortcuts in Spotlight on Mac:
  https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac
- Apple Support — Search with Spotlight on Mac:
  https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac
- Apple Support — Search your Clipboard history in Spotlight on Mac:
  https://support.apple.com/guide/mac-help/search-your-clipboard-history-mchl40d5b86b/mac
- Figma Help — Guide to branching:
  https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
