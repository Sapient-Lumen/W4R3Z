# SlopOS + companions evaluation — pass XCIII — 2026-03-22

## Headline

This round says Helm should borrow one more **small operating law** from the companion cubes:

**maintenance posture must stay explicit.**

Not everything should jump directly from **live** to **stopped**.
Sometimes the honest move is:
- stop admitting new work,
- let exact current work drain or cancel under a declared mode,
- show whether the surface is still hot,
- and keep the escalation path visibly separate.

## What SlopOS is teaching now

SlopOS is the clearest teacher here.
Its quiesce posture is unusually disciplined:
- quiesce is **component-local**,
- one active quiesce epoch is enough,
- `DRAIN` and `CANCEL` are different,
- new work gating must be explicit,
- and force-kill stays outside the cooperative seam.

That is exactly the kind of law Helm can steal without copying SlopOS's still-fluid machinery.

The key non-take is just as important:
Helm should **not** inherit a giant global freeze framework,
a hidden queue-behind-boundary story,
or a fake universal lifecycle model.

## What Steward contributes

Steward sharpens the shell feel of the same idea.
It keeps saying:
- quiesce is cooperative and bounded,
- stop deferral is a tiny attributable grace request,
- busy/draining truth belongs near the exact frame or pane,
- and prepare/drain/cleanup helpers should surface as bounded evidence instead of disappearing into logs.

That is great pressure for Helm's Operations Center,
Recall,
and trusted shell chrome.

## What ViewFS contributes

ViewFS keeps the lane cuts honest.
Its recent RFCs reinforce that:
- cancel is not terminate,
- detach is not delete,
- observe is not attach,
- control is not sideband,
- and durable history is not current control.

That matters because Helm will be tempted to make quiesce into a vague universal stop button.
ViewFS is a reminder not to do that.

## What Schell contributes

Schell keeps supplying the shell-side warning:
stronger transitions should cross a shell-owned lane,
with humane explanation,
not dissolve into content or prose.

That means a future Helm quiesce rail should probably feel like:
- a small trusted maintenance strip,
- a stated mode (`drain` or `cancel`),
- a visible reason and budget,
- current blocker truth,
- and a separate explicit escalation path.

## What to keep

Keep:
- cooperative drain posture,
- no-new-work honesty,
- exact current-vs-historical state distinction,
- bounded grace windows,
- frame-local busy/draining chrome,
- and explicit cancel / terminate / detach separation.

Peel away:
- giant orchestrator fantasies,
- nested maintenance grammars,
- hidden retry queues,
- implicit subtree freeze semantics,
- and magical “paused therefore safe/exportable/shareable” folklore.

## Main judgment

Helm is ready to warm one more compact law:

> a shell-owned surface should be able to say
> **running**,
> **quiescing (drain)**,
> **quiescing (cancel)**,
> **quiescent**,
> **resumed**,
> and **force-cut-through happened**
> without collapsing those into one vague paused/stopped story.

That looks like a real product gain,
not just archive decoration.
