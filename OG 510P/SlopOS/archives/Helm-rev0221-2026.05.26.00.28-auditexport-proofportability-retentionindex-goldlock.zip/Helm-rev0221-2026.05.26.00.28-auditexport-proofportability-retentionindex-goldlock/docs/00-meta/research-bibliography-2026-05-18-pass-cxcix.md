# Research bibliography — pass CXCIX — 2026-05-18

- Google SRE, "Service Level Objectives" — measurement conditions, workload-specific objectives, error budgets, and control loops.
  - https://sre.google/sre-book/service-level-objectives/
- Google SRE Workbook, "Example Error Budget Policy" — non-punitive policy, change freezes, reliability work, and escalation.
  - https://sre.google/workbook/error-budget-policy/
- Atlassian Compass, "What are scorecards?" — component health criteria, weights, and team standards.
  - https://support.atlassian.com/compass/docs/what-are-scorecards/
- Backstage, "System Model" — shared terminology for systems/resources and catalog relations.
  - https://backstage.io/docs/features/software-catalog/system-model/
- Prometheus, "Alerting rules" — pending/firing windows, labels, annotations, and conditions.
  - https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/
- Prometheus, "Recording rules" — precomputed expressions and evaluation intervals.
  - https://prometheus.io/docs/prometheus/latest/configuration/recording_rules/
- OpenFeature, "Hooks" — before/after/error/finally lifecycle stages.
  - https://openfeature.dev/docs/reference/concepts/hooks/
- CloudEvents specification — context attributes and compact event envelopes.
  - https://github.com/cloudevents/spec/blob/main/cloudevents/spec.md
