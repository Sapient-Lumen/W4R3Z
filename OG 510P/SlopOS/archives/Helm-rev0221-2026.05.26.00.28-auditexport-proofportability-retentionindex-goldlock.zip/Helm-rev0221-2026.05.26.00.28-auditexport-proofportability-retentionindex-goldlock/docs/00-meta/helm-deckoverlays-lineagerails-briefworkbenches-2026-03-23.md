# Helm — deck overlays, lineage rails, and brief workbenches — 2026-03-23

## The current call

Helm still does **not** need another pillar.
Helm still does **not** need a giant notebook suite,
a giant BI center,
or a giant lineage console.
The next admitted shell-wide ratchet is still **settlement witnesses + commit cards**.

But the archive now has enough pressure to say something stronger about what could make Helm unusually good next:

**smart decks become much more powerful when Helm can add overlays,
checks,
explain rails,
snapshot shares,
and bounded brief workbenches without collapsing those additions into live truth.**

## Why this cluster matters

The earlier deck/branch/freshness cluster answered:
- how saved work should differ from live work,
- how branches should differ from mainline,
- and how freshness should stay visible.

This adjacent cluster answers the next questions:
- how do I explain what I am seeing?
- how do I mark what mattered?
- how do I check the chosen slice before acting?
- how do I share a frozen view honestly?
- how do I gather evidence without turning Helm into a giant notebook product?

## The lessons Helm must learn from the past

### 1) Annotation is not state
Old systems constantly smear together:
- the thing,
- the note about the thing,
- the alert on the thing,
- and the proof that the thing changed.

Helm should refuse that.
A deck overlay,
annotation,
marker,
or tag should stay visibly weaker than the saved or live source object underneath it.

### 2) Selection is not authority
A visible slice,
search result,
or drill result is not automatically a reviewed target set.
Helm should increasingly let people **promote** a slice into a reviewed target-set object,
with explicit checks and basis posture,
instead of laundering visible convenience into authority.

### 3) Explainability must stay local and useful
The past keeps showing the same trap:
lineage maps become big,
beautiful,
and hard to use.
Helm should favor compact explain rails that can answer a concrete local why question over giant default graph theaters.

### 4) Workbenches must stay bounded
People do need to gather,
annotate,
compare,
and explain.
But if Helm lets that become ambient case-engine sprawl,
it will lose the shell-owned exactness that makes it special.

## Brilliant ideas worth stealing

### A) Deck overlays
Any saved or live deck should be able to gather:
- manual annotations,
- timeline markers,
- alert/incident markers,
- review markers,
- and tags,
without pretending overlays changed the underlying source truth.

### B) Reviewed target-set promotion
A strong result slice should be promotable into:
- one reviewed target-set object,
- with explicit cardinality,
- exact basis,
- freshness posture,
- and attached checks.

### C) Attached checks
Checks should travel with the reviewed slice.
That means Helm can say:
- what was selected,
- which checks were run,
- which ones warned,
- which ones failed,
- and what exact basis they evaluated.

### D) Lineage rails
Helm should eventually answer compact local questions like:
- what upstream roots fed this row?
- which earlier deck or receipt produced this artifact?
- which column or field contributed here?
- what downstream things will care if I adopt this?

### E) Snapshot-share objects
When sharing,
Helm should distinguish:
- live deck,
- frozen snapshot deck,
- share link,
- exported handoff packet,
- and imported receiver-local copy.

A snapshot share object with explicit revoke/delete posture would be extraordinarily honest.

### F) Brief workbenches
Helm already wants bounded evidence briefs.
The next move is to let some briefs become richer workbenches with:
- history,
- compare,
- fork-from-history,
- merge-back/adopt,
- annotations,
- and exact source refs,
while still staying weaker than live shell truth.

## What is worth keeping from old inspirations

Keep:
- saved-query objects,
- drill rails,
- compare posture,
- branch/fork posture,
- annotations as overlays,
- and history-aware curation.

Do **not** keep:
- giant dashboards as authority centers,
- notebooks that drift away from exact sources,
- lineage maps with no local explain lane,
- or shares that look live when they are only frozen payloads.

## Moves that could make Helm super awesome

### 1) Annotate this deck
Right from a saved or live deck:
- drop a marker,
- tag it,
- bind it to a time/span/row slice,
- and keep it inspectably weaker than deck truth.

### 2) Promote to reviewed target set
From any result slice:
- freeze reviewed membership,
- attach checks,
- show freshness and basis,
- and hand the stronger set to later acts.

### 3) Explain this row
A one-click local rail could answer:
- why this appears,
- what upstream sources contributed,
- what exact basis or branch produced it,
- and what downstream consequences adoption might have.

### 4) Share frozen, not fake-live
From any deck or brief:
- create a frozen snapshot share,
- keep the share class explicit,
- and preserve revoke/delete posture nearby.

### 5) Fork this brief from history
An evidence brief should eventually be forkable from an older state,
rich enough to annotate and compare,
and still clearly weaker than the current-live shell lane.

## Product judgment

The immediate trigger is **still not** a giant workbench freeze.
But this cluster now looks too good to ignore.

Helm should keep warming:
- deck overlays,
- reviewed target-set promotion,
- attached checks,
- lineage rails,
- snapshot-share objects,
- and bounded brief workbenches.

That is one of the cleanest ways to make the shell feel super awesome while staying honest.
