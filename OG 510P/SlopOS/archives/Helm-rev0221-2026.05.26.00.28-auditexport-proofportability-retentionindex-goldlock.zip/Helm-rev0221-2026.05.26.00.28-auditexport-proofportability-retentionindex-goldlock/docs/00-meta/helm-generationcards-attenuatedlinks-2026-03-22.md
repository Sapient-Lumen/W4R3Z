# Helm generation cards, attenuated links, and capability recipes — 2026-03-22

Purpose: identify the next few moves that could make Helm feel more magical while still keeping the pillars stable.

## The shortest answer

Helm gets better when it clearly separates five kinds of thing:

1. **current-live beacons**
2. **exact generations**
3. **floating aliases / front doors**
4. **attenuated reveal links**
5. **capability recipes**

Those are not five new pillars.
They are five different strengths of shell truth.

## 1. Generation cards and rollback rails

A strong shell object should not mutate into mystery.
When a saved view,
front door,
deck recipe,
or promoted landing artifact changes materially,
Helm should be able to preserve and show generations.

A good generation card would show:
- subject kind
- exact generation id
- what it followed from
- what changed from the previous generation
- whether it is current,
  historical,
  promoted,
  or superseded
- available compare / restore / branch / share moves

Why this matters:
- **Recall** gets much more truthful than generic recents
- **Object Browser** can treat history as exact generations rather than vibes
- **Omnibox** can summon an exact generation or a floating alias intentionally
- **Operations Center** can show promotion / rollback as normal activity instead of emergency ritual

## 2. Attenuated reveal links

Helm already has reveal windows and audience ladders warming.
This pass says one especially good shell object is an **attenuated reveal link**.

That object would represent:
- one exact subject or cohort
- one audience class
- one reveal shape
- one expiry posture
- one revoke path
- one route class

Examples:
- a guarded link to one saved view for 24 hours
- a named-cohort link to one exact generation
- a public link to one weak preview,
  but not to the live lane

Why this matters:
- **Exchange** gets much more precise
- **Operations Center** can show current versus historical reveal truth cleanly
- **Recall** can explain what was shared without pretending it is still visible now
- **Object Browser** can inspect a share without turning it into broad workspace mythology

## 3. Capability recipes

A capability recipe is not a live grant.
It is not a current-live beacon.
It is not even necessarily an exact generation.

It is a weaker,
portable shell object that says how to **reassemble a good starting position**.

A recipe might include:
- preferred front door
- expected saved views
- exact generations it was derived from
- exact handles it hopes to reacquire
- grant requests it may need to ask for again
- helper lane posture if preparation is needed
- notes about what will stay approximate or need repair

This is excellent for:
- sharing ways of working
- moving between devices or accounts
- importing someone else's setup in restricted-first posture
- resuming after a local environment changed

Why it matters:
- **Tiling Shell** gets portable starters without pretending they are live sessions
- **Omnibox** can summon recipes as recipes
- **Exchange** can move portable shell setups without laundering them into authority
- **Desktop Flow** can target recipe materialization or recipe upgrade explicitly

## 4. How these fit together

These three moves are powerful because they fit together cleanly:

- **generation** = exact historical or reviewed basis
- **floating alias** = current-following convenience door
- **attenuated link** = narrow travel / reveal surface
- **capability recipe** = portable reassembly plan

A delightful shell should let the user move between them explicitly:
- inspect current live
- pin the current state into a generation
- attach a floating alias for ordinary reentry
- create a guarded attenuated link for sharing
- export a weaker capability recipe for reuse elsewhere

## 5. Pillar implications

### Tiling Shell
Treat layouts and front doors as things that can have generations and recipe posture,
not only one mutable present.

### Omnibox
Summon current live,
exact generation,
floating alias,
attenuated link,
and recipe as visibly different result classes.

### Object Browser
Make compare,
rollback,
inspect-link,
and inspect-recipe ordinary browser acts.

### Operations Center
Show generation promotion,
rollback,
link expiry,
revoke,
and recipe materialization as separate rows.

### Desktop Flow
Allow flows to emit recipes,
generations,
and attenuated links explicitly instead of only side effects.

### Recall
Stop blurring “what I have now” with “what I once promoted” or “what I can probably reconstruct.”

### Exchange
Get much more honest about one-subject sharing,
expiring links,
and portable-but-weaker setup recipes.

## 6. Pull-trigger guidance

### Pull now
- generation cards on the handful of shell objects that most need compare/rollback dignity
- attenuated reveal links for one-resource sharing
- visible distinction between exact generation and floating alias

### Keep warm
- capability recipes as a first-class portable shell object
- recipe import / materialize / repair posture
- generation pruning policy surfaces that stay compact rather than sprawling

## Closing judgment

Helm does not need one bigger datacube object.
It needs a more legible strength ladder.

The next great shell move is to make it easy to see whether something is:
- live,
- exact,
- floating,
- narrowly shared,
- or only recipe-grade portable.

That would be a substantial quality jump without a constitutional sprawl.
