# Helm: open, recall, and stronger truth — 2026-03-22

Purpose: make one cross-cutting shell law easier to see:
Helm should stop flattering ordinary **open** into stronger acts that deserve their own posture,
receipts,
and review surfaces.

## The core distinction

Helm now wants at least five different strengths that many tools still blur together:

1. **peek / preview**
2. **open / reveal / ordinary inspection**
3. **current-live reentry**
4. **materialize / adopt / save as durable shell object**
5. **publish / share / branch / fork / promote**

The mistake from the past is acting as if these are all flavors of one big friendly verb.
They are not.

## Why this matters now

Helm is warming:

- saved view objects
- checkpoint branches
- imported-surface trust posture
- landing rehearsal
- arrival overlay
- materialization bays
- command docks
- exact action keys
- publication ladders

All of those become much easier to lie about if the shell keeps treating “open” as a magic universal act.

## The shell law

### Peek is not open
A peek may be rich,
fast,
and delightful.
It should still remain weaker than ordinary open or reveal.

### Open is not current-live reentry
Opening something historical,
imported,
or receipt-derived is not the same as returning to the current active live lane.
Recall should make that difference obvious.

### Open is not save
A previewed result,
a temporary filter,
or a once-touched object should not quietly become a durable saved shell object just because it was useful.
Saving should be explicit.

### Open is not materialize
If a view,
recipe,
handoff packet,
checkpoint,
or imported surface needs a stronger local instantiation step,
that should happen in a materialization bay,
rehearsal,
or other explicit workflow.

### Open is not publish
Sharing,
public promotion,
team exposure,
or receiver-side availability should remain separate stronger acts.

### Open is not branch
Restore,
branch-from-here,
fork-as-copy,
and fresh instantiation are stronger continuity acts.
They should not hide behind a generic “resume/open again” story.

## What this means for the pillars

### Omnibox
Omnibox should treat open as a rung,
not as the whole ladder.
Every result family should be able to keep preview,
open,
reenter,
save,
and stronger acts distinct.

### Object Browser
The browser should let people inspect and reveal quickly,
but keep durable save,
import,
adoption,
and publication explicit.

### Recall
Recall should become the pillar that distinguishes current-live reentry from history,
restoration,
receipt-backed return,
and merely recent hints.
This is one of the biggest places Helm can beat recent-items folklore.

### Exchange
Exchange should show that send/share/import/open/attach/forward are different route strengths,
not one blurred “open with” family.

### Operations Center
Ops should explain which stronger step happened.
Did the shell only preview?
Did it launch?
Did it materialize?
Did it publish?
Did it restore from checkpoint?
The center should know.

### Desktop Flow
Flows should wire stronger verbs explicitly.
A graph edge should not hide that a downstream step was materialization,
publication,
or branch creation.

## The best user-facing moves this enables

1. **peek here, save as view**
2. **peek here, reenter live lane**
3. **open history, branch from checkpoint**
4. **open portable recipe, rehearse locally, then adopt**
5. **open shared view, inspect in restricted posture, then publish locally or keep private**
6. **open dock item, confirm strong deeplink-like action, then continue**

## What to keep from old inspirations

Keep:

- instant summon
- tiny nearby actions
- saved structure that is easy to reuse
- keyboard-first preview and reveal
- compact shell-owned continuity cues

Drop or weaken:

- the idea that every useful thing should auto-save itself
- the idea that recent/opened should double as durable truth
- the idea that launch should quietly pick profile,
session,
or account context for you
- the idea that publication and activation are basically the same move

## Judgment

This now looks like one of Helm's most important cross-cutting laws.

The shell becomes both **more delightful** and **more honest** if it keeps:

- preview weak
- open bounded
- current-live reentry explicit
- save/materialize explicit
- publish/branch explicit

That is a much better foundation for saved view objects,
checkpoint branches,
command docks,
exact action keys,
and Recall than any amount of giant dashboard or sync mythology.
