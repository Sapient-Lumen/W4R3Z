# Helm commitment witnesses + promise cards — 2026-03-23

## Why this pass exists

After state tuples,
why rails,
delta briefs,
footing marks,
salience lenses,
coverage witnesses,
quiet witnesses,
delivery witnesses,
disposition witnesses,
and revisit witnesses,
Helm can now say a lot about a surfaced thing.

But it still lacked one small answer to a very practical question:

**what was actually promised here, by whom, to whom, by when or under what condition, and what happens if that promise slips?**

That answer should not be hidden in:
- an assignee badge
- a due date badge
- a reminder or wake card
- an SLA timer
- a work claim
- an acknowledgement flag
- or the underlying source status

It needs its own compact shell-owned truth object.

## Main judgment

Helm should now admit **commitment witnesses**,
with tiny nearby **promise cards**.

A commitment witness is not:
- the source truth
- the delivery witness
- the disposition witness
- the revisit witness
- the due date by itself
- the assignee field by itself
- the current-live beacon
- the work claim
- the final outcome
- or a project-management empire

It is the exact answer to:
- what promise now exists for this surfaced thing?
- who made it,
  to which audience,
  lane,
  or counterpart?
- what target or condition qualifies the promise?
- what basis or assumptions was it made against?
- when is it on track,
  at risk,
  slipped,
  rescoped,
  handed off,
  or met?
- and what exact stronger surface redeems or repairs the promise?

## Why this matters for Helm's pillars

### Overview
Overview can now stay weak but still say:
- `review promised by Fri 15:00 • by release lane`
- `follow-up promised after partner reply`
- `migration answer due within SLA window • owner changed`
- `handoff promised to next on-call • escalation if missed`

without pretending any of those already mean the outcome happened.

### Recall
Recall can explain not just what changed,
what stance was chosen,
and when it should return,
but what promise exists now:
- `saved, wake tomorrow 10:00, answer promised by noon`
- `acknowledged, timeout returns in 20m, no human promise recorded`
- `delegated, responder promised reply after next patrol round`

### Operations Center
Ops rows can stop flattening:
- assigned
- acknowledged
- reminded
- due soon
- at-risk SLA
- promised by X
- breached
- rescoped
- and handed off

into one vague “owned” or “handled” bit.

### Omnibox / Object Browser
Helm can offer exact next-step verbs like:
- promise-by
- commit-after
- mark-at-risk
- rescope-target
- handoff-promise
- break-promise-with-reason
- mark-met-with-receipt

without assuming the subject itself changed yet.

## What Helm should steal

- GitHub's clear assignee posture without pretending assignee means guaranteed completion
- Notion's separate owner and due-date properties
- Jira's explicit due / overdue / due-in-next window grammar
- Jira Service Management's separate SLA timers
- Slack's separate save / remind / complete posture
- PagerDuty's assignment / acknowledgement / escalation / resolution separation
- PagerDuty's explicit policy-preserving reassignment versus one-off user reassignment

## What Helm should refuse

- one universal “owner means done soon” badge
- treating due dates as promises
- treating reminders as commitments
- treating active work as guaranteed outcome
- treating missed promises as silent decay
- treating policy escalation and personal promise as the same thing
- treating commitment witnesses as another giant task board

## Pull-the-trigger conclusion

The next good Helm move is not another pillar.
It is one more cross-pillar ratchet:

**revisit truth tells you when or why it should come back.**
**commitment truth tells you what exact promise exists once someone owns that return.**

That is the missing seam between truthful followthrough-return and truthful obligation.
