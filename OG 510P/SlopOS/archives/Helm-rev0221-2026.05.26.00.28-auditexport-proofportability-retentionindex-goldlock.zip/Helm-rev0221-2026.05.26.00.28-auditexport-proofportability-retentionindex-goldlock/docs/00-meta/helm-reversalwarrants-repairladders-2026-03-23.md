# Helm reversal warrants + repair ladders — 2026-03-23

Purpose: name the next compact shell move after landing trains,
guarded promotion,
and post-act receipts.

## Main idea

Helm now has a much better answer to:
- what exact basis a strong act was reviewed against
- what exact strong change is being proposed
- whether that basis drifted
- what exact effect happened
- which slots landed,
  default-filled,
  rebounded,
  failed,
  or stayed pending
- and how candidate work may be separated,
  adopted,
  queued,
  or staged

What Helm still lacked was a clean recovery-side answer to two questions:

**what exact historical effect am I being asked to reverse,
restore,
or compensate for now?**

and

**what is the smallest honest next repair rung for this exact aftermath?**

The first answer should be a **reversal warrant**.
The second answer should be a **repair ladder**.

## Why this now looks ripe

The outside pattern is now strong enough to stop being hand-wavy.
GitHub makes reversal a new pull request rather than a history eraser.
GitHub Actions keeps rerun-all,
rerun-failed,
and rerun-one-job visibly different.
Kubernetes lets rollback target an exact previous rollout or a specific revision.
Vercel frames recovery as restore service first,
investigate,
then deploy a fix.
Argo Rollouts is explicit that rollback can restore live health without rewriting Git for you.
LaunchDarkly keeps rollback scope explicit enough that dependent flags may still need separate work.

Together,
those systems keep teaching one law:

**recovery is not one button and not one kind of truth.**

## Reversal warrants

A reversal warrant should be the recovery-side sibling of an action warrant.
It should stay:
- exact,
- reviewed,
- blast-radius-aware,
- drift-aware,
- and visibly tied to one prior effect receipt,
  checkpoint,
  or reviewed historical change.

It should answer:
- what exact prior effect is under discussion
- whether this is true undo,
  restore-before,
  compensating reverse,
  revoke,
  reopen,
  or another admitted family
- what lane it expects to touch
- whether it still binds cleanly now
- and where the resulting new receipt would appear if applied

## Repair ladders

A repair ladder should be the humane next-step sibling of a reversal warrant.
It should exist because real recovery is often not “reverse all” or “do nothing.”

It should keep visibly different:
- undo exact effect
- redo exact effect
- rerun failed subset
- rerun one exact failed item
- replay original proposal on fresh reviewed basis
- reopen unresolved slots
- branch-and-fix
- compensate shared/public fallout
- hold,
  inspect,
  or cite the current aftermath

The main point is not the ladder metaphor.
The point is that **retry is too vague** for Helm now.

## What this lets Helm do better than today's systems

### 1. Every strong act can carry one honest recovery side

A user should not have to guess whether a powerful action can be reversed,
redone,
repaired,
or only compensated.
The receipt should be able to point to the right sibling object.

### 2. Partial failure gets a bounded humane answer

Instead of vague retry,
Helm can say:
- these slots landed,
- these stayed pending,
- this one failed,
- rerun failed subset,
  reopen unresolved,
  reverse all,
  or branch-and-fix.

### 3. Live rollback can stay separate from authored repair

Helm can learn the Argo/Vercel lesson directly:
recovery of live usefulness may need to happen first,
while authored history,
publication,
or shared packet repair may still be a later explicit step.

### 4. AI-assisted strong acts become less scary

If AI can propose strong acts,
it should also be able to propose exact reversal or bounded repair on top of durable receipts.
That makes trust more earned and less theatrical.

## What not to steal

- no universal Undo myth
- no retry button that hides whether it is redo,
  rerun subset,
  replay on fresh basis,
  or compensate
- no live rollback that silently rewrites every neighboring authored lane
- no giant incident manager,
  giant rollback console,
  or hidden self-healing bureaucracy

## Pull-the-trigger judgment

Still yes:
- **saved view objects**
- **checkpoint branches**

Now also worth explicitly warming as support contracts:
- **reversal warrants**
- **repair ladders**

If Helm gets this right,
it will feel safer than many current review/apply systems not because it promises magic undo,
but because it stays exact about:
- what can still be reversed,
- what only can be repaired,
- what should be rerun narrowly,
- and what now requires a fresh stronger act.
