# Helm: resumption briefs + gap verdicts — 2026-03-23

## The call in this revision

Keep the seven pillars stable.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes**,
**bounded rehearsal decks**,
**pillar-specific recipes**,
**landing trains with attempt-aware lineage**,
and **bounded aftermath decks + nearby recovery maps** as the current grammar.

But add one narrower re-entry seam:

**after a serious stronger act already has an aftermath deck,
Helm should be able to open one compact resumption brief with a typed gap verdict,
so a returning operator can see what changed since the last trustworthy footing,
what exact continuation still exists,
what exact continuity broke when it does not,
and what the smallest honest next move is.**

## Why this now looks like the right next move

Helm's loop is getting good objects at every phase:
- **before** the act: reviewed slices,
  basis explorers,
  rule-insight cards,
  rehearsal decks,
  guarded ladders
- **during** the act: landing trains,
  queue/group truth,
  attempt lineage,
  continuation handles
- **after** the act: settlement witnesses,
  commit cards,
  effect receipts,
  slot verdict ledgers,
  remainder witnesses,
  recovery maps,
  calibration witnesses

What still feels too scattered is the moment a person **comes back later**.
An aftermath deck is a good bounded post-act home,
but the shell still wants a faster re-entry seam.

A serious return often needs to answer all of these at once:
- what exact story and attempt is this?
- what exact earlier footing am I returning from?
- what changed since that footing?
- what stayed stable enough not to re-open?
- is there still one exact continuation handle?
- if not, what exact gap class blocked continuity?
- what is the smallest honest next rung now?

That is exactly what a compact **resumption brief** and typed **gap verdict** are for.

## The split Helm should preserve

### 1. Resumption brief
A compact shell-owned re-entry object for one exact story family,
often opening into an aftermath deck or delta brief.

It should gather:
- story id and attempt id
- last trusted footing / basis stamp / reviewed slice relation
- later footing or current-live beacon relation
- compact delta brief or compared-bases pointer
- continuation-handle weather when one exists
- typed gap verdict when continuity has broken or become uncertain
- exact remainder relation when only part is still actionable
- smallest honest next-rung suggestions
- stronger exits into compare,
  refresh,
  deck,
  repair,
  or calibration

It is not current-live truth.
It is not the aftermath deck itself.
It is not one giant recap engine.

### 2. Gap verdict
A compact shell-owned explanation of what blocked exact continuation.

A first vocabulary should stay small:
- **expired**
- **retention-window-lost**
- **provider-reset**
- **basis-drifted**
- **root-changed**
- **actor-mismatch**
- **authority-narrowed**
- **unsupported**
- **unknown**

The verdict should orient the next move rather than imitate a diagnosis essay.

## What current official patterns are teaching

The outside pressure lines up unusually well:
- **GitHub Actions** keeps `run_id`, `run_number`, and `run_attempt` distinct,
  which is exactly the difference between story identity,
  run family,
  and later attempts.
- **GitHub merge queue** and `merge_group` keep grouped landing truth and later checks tied to the latest base and queued neighbors.
- **AWS Step Functions** redrive continues from the unsuccessful step while preserving successful-step history and keeping the original version/alias binding.
- **Temporal Continue-As-New** keeps one durable workflow identity while starting a fresh run id and fresh event history.
- **Google long-running operations** keep one named operation with poll/cancel posture and finite retention.
- **Microsoft Graph upload sessions** expose `expirationDateTime` and `nextExpectedRanges`,
  which is exactly the kind of continuation weather and exact remainder Helm should surface.
- **Dropbox** cursor reset posture shows that a dead continuation should explain that a new root/list pass is required rather than bluffing continuity.
- **Kubernetes** watch bookmarks show the difference between “synced through resource version X” and “still following live now.”
- **Grafana time-range compare** and **Datadog version history** show that bounded items should survive later compare,
  restore,
  and clone without history rewrite.

Taken together,
those products argue that Helm should not only have the right post-act home.
It should also have a compact honest **way back in**.

## What the companion cubes are still teaching

### SlopOS
Keep exact basis,
exact witness posture,
and weaker-versus-stronger truth.
A re-entry brief must not claim continuity without exact footing.

### Schell
Keep proposal / review / run / later-outcome separation.
A resumption brief must stay downstream of run and aftermath,
not become a backdoor proposal surface.

### ViewFS
Keep continuation cursor,
watermark,
live subscription,
rebuilt snapshot,
gap verdict,
and receipt separate.
Helm should steal that distinction nearly whole.

### Ward
Keep read cuts,
staleness budgets,
ambiguity windows,
and revalidation fences obvious.
A brief should be able to say stale-check-first or refresh-required without shame.

### Steward
Keep typed recovery pressure.
A gap verdict should orient toward continue,
wait,
rerun-failed-subset,
redrive,
rebuild,
replay-on-fresh-basis,
or hold — not one vague retry.

### Harbor
Keep route truth and receiver-visible aftermath distinct.
A re-entry brief can show both,
but should not blur them.

### Foundry
Keep runtime evidence smaller than verdict.
A brief can surface diagnostics,
but those should not silently become settlement truth.

## How this fleshes the pillars

### Omnibox
A return result should be able to say not only “recent” or “related,”
but “changed since your last trusted footing,”
“continuation still live,”
or “gap verdict: provider reset.”

### Object Browser
Objects should reopen through one brief that compares last-trusted basis to current footing before asking for stronger acts.

### Operations Center
Serious promotions and applies should reopen first into resumption briefs,
then into full aftermath decks when needed.

### Desktop Flow
A paused or partially completed flow should explain whether it can continue exactly,
continue only after revalidation,
or only replay from a fresh reviewed basis.

### Recall
Recall gets much more premium if it can reopen “what changed since you last trusted this” instead of just “what you touched before.”

### Exchange
Transfers,
routes,
materializations,
and deliveries need a fast way to say whether continuation still exists and what exact remainder or reset posture now applies.

### Terminal / Capshell
Run history,
reattach,
rerun,
and follow surfaces should keep attempt lineage,
gap class,
and exact smaller-next-rung truth visible.

## What to keep from older inspirations

Keep:
- bounded compare over the same items
- clone / restore without rewriting lineage
- versioned work surfaces that remain weaker than live truth
- exact remainder before broad rerun
- personal-first re-entry surfaces that can later be shared

Peel away:
- one giant return timeline
- one ambient summary surface that pretends to know the right comparison basis
- magical `resume` language that hides gap class
- restored views that pretend nothing changed in between

## Why this could make Helm super awesome

### 1. Return loops become first-class
Helm stops being merely good at rehearsal and aftermath,
and becomes good at **coming back later**.

### 2. Drift becomes actionable rather than theatrical
The shell can name the compared bases,
show the change,
and say whether the next move is continue,
refresh,
relist,
redrive,
or replay.

### 3. The premium feeling stays compact
A resumption brief is much cheaper than a giant recap system,
but much better than scattered rows,
logs,
and vague “updated” badges.

### 4. Recall and Exchange get noticeably stronger
Those pillars get the most value from exact continuity and exact gap class being visible in one small place.

## Pull-the-trigger judgment

Do **not** add a pillar.
Do **not** freeze one universal re-entry center.

But it now looks wise to warm one more compact shell move very explicitly:

**resumption briefs with typed gap verdicts**
for serious stronger stories,
kept weaker than current-live truth and smaller than an aftermath deck.
