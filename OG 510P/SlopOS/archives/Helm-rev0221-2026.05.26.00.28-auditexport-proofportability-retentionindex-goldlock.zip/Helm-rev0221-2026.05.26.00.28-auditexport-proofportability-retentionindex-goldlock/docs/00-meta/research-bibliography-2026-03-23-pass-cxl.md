# Research bibliography — 2026-03-23 pass CXL

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-DBT-SEMANTIC-MODELS-2026 | https://docs.getdbt.com/docs/build/semantic-models | semantic models as the foundation for data definition is a strong precedent for Helm semantic recipe cards |
| REF-DBT-SEMANTIC-LAYER-2026 | https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl | centralized metric definitions for downstream tools is strong pressure for reusable shell-owned semantic recipes |
| REF-DBT-SL-ARCH-2026 | https://docs.getdbt.com/docs/use-dbt-semantic-layer/sl-architecture | query-time SQL generation from semantic definitions is a strong precedent for recipe-backed deck answers |
| REF-CUBE-QUERY-HISTORY-2026 | https://cube.dev/docs/product/administration/workspace/query-history | visible accelerated-versus-non-accelerated query posture is a strong precedent for Helm serve-path strips |
| REF-CUBE-BUILD-HISTORY-2026 | https://cube.dev/docs/product/administration/workspace/pre-aggregations | build-history posture is a good model for revealable precomputed serving truth |
| REF-MATERIALIZE-SUBSCRIBE-2026B | https://materialize.com/docs/sql/subscribe/ | `AS OF` lower-bound query footing is a strong precedent for Helm as-of markers |
| REF-MATERIALIZE-DURABLE-SUBSCRIBE-2026 | https://materialize.com/docs/transform-data/patterns/durable-subscriptions/ | snapshot-first versus updates-only posture is a strong precedent for live/snapshot subscription honesty |
| REF-MATERIALIZE-MZ-NOW-2026 | https://materialize.com/docs/sql/functions/now_and_mz_now/ | logical query time versus wall-clock time is a strong precedent for Helm footing honesty |
| REF-LOOKER-CONTENT-VALIDATOR-2026 | https://docs.cloud.google.com/looker/docs/content-validation | validator-before-change and schedule-break risk is a strong precedent for Helm validator rails |
| REF-LOOKER-CI-VALIDATOR-2026 | https://docs.cloud.google.com/looker/docs/ci-content-validator | scoped and incremental validation is a strong precedent for bounded Helm validation lanes |
| REF-LOOKER-CERTIFICATION-2026 | https://docs.cloud.google.com/looker/docs/content-certification | certifier metadata plus revoke-on-edit posture is a strong precedent for weak trust markers |
| REF-LOOKER-EXPLORE-REFRESH-2026 | https://docs.cloud.google.com/looker/docs/viewing-and-interacting-with-explores | visible data age, query time, and clear-cache/refresh is a good precedent for serve-path confession |
| REF-METABASE-VERIFICATION-2026 | https://www.metabase.com/docs/latest/exploration-and-organization/content-verification | verified-item markers are a good precedent for lightweight trust/discovery posture |
| REF-METABASE-COLLECTIONS-2026 | https://www.metabase.com/docs/latest/exploration-and-organization/collections | official collections and curated-library posture is a good precedent for weak official marks and scratch-vs-source-of-truth separation |
| REF-OPENMETADATA-CONTRACTS-2026B | https://docs.open-metadata.org/v1.12.x/how-to-guides/data-contracts | schema/semantics/quality/SLA/status contract breadth is strong pressure for Helm semantic promise cards |
