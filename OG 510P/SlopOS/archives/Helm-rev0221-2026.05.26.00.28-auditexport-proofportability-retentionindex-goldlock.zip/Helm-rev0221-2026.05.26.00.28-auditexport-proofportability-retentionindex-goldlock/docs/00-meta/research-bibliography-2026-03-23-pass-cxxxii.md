# Research bibliography — 2026-03-23 pass CXXXII

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-K8S-ROLLOUT-UNDO-2026 | https://kubernetes.io/docs/reference/kubectl/generated/kubectl_rollout/kubectl_rollout_undo/ | exact rollback target and revision-specific undo |
| REF-ARGO-ABORT-2026 | https://argo-rollouts.readthedocs.io/en/stable/generated/kubectl-argo-rollouts/kubectl-argo-rollouts_abort/ | abort versus full revert; previous ReplicaSet active while spec.template stays new |
| REF-ARGO-ROLLBACK-WINDOW-2026 | https://argo-rollouts.readthedocs.io/en/stable/features/rollback/ | fast-tracked rollback window within recent revisions |
| REF-GITHUB-REVERT-PR-2026 | https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/reverting-a-pull-request | revert as a new pull request rather than history erasure |
| REF-FIGMA-VERSION-HISTORY-2026 | https://help.figma.com/hc/en-us/articles/360038006754-View-a-file-s-version-history | restore creates checkpoints and preserves comments from all versions |
| REF-LD-KILL-SWITCH-2026 | https://launchdarkly.com/docs/home/flags/killswitch | emergency shutoff as operational retreat class |
| REF-LD-GUARDED-ROLLOUT-ROLLBACK-2026 | https://launchdarkly.com/docs/home/releases/managing-guarded-rollouts | rollback of prerequisite flag does not automatically roll back dependents |
