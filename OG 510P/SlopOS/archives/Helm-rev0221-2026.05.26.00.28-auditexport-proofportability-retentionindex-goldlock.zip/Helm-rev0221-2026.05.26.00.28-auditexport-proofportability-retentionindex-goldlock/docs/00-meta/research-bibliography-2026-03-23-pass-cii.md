# Research bibliography — 2026-03-23 — pass CII

- MDN — User activation / transient vs sticky activation
  - used for: fresh-intent windows, expiry, and consumption posture
- HTML Living Standard — APIs gated by user activation
  - used for: transient-activation-consuming versus non-consuming split
- MDN — `showOpenFilePicker()` / `showDirectoryPicker()` / `showSaveFilePicker()`
  - used for: chooser-bound final steps that require transient activation
- MDN — `FileSystemHandle.requestPermission()`
  - used for: exact remembered handles that still need a fresh user step for stronger permission
- MDN — `getDisplayMedia()`
  - used for: prompt-every-time screen capture, transient activation, and non-persistent go-ahead posture
- Android Developers — MediaProjection / screen capture
  - used for: one-session user consent, one-use token posture, and system-owned stop surface
- XDG Desktop Portal documentation — Request / FileChooser / OpenURI / Background
  - used for: bounded request handles, user-controlled chooser/open seams, and explicit background/autostart requests
- MDN — `window.open()` and Window Management API guidance
  - used for: one gesture per strong open and reuse-over-fan-out posture
