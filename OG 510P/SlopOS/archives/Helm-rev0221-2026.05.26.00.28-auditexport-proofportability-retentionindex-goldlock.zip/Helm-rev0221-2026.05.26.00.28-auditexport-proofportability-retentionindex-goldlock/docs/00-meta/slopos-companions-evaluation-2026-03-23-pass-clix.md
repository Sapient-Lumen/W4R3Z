# SlopOS companions evaluation — 2026-03-23 pass CLIX

## Purpose

Continue evaluating **SlopOS**, **Schell**, **ViewFS**, **Harbor**, **Foundry**, **Ward**, and **Steward** after the rehearsal-deck pass by asking one narrower product question:

**what is the cleanest decision-light way to flesh all seven Helm pillars now,
without freezing one universal deck constitution?**

## Answer up front

The best next move is:
- keep the bounded rehearsal deck as the live proof object,
- but define **first pillar-specific deck recipes** and explicit **recipe ladders**,
- so each pillar gets one humane starter loop without Helm pretending all work fits one center.

That means:
- a recipe stays weaker than a live deck,
- a materialized deck still binds exact footing,
- grouped checks and drift sentries stay on the instantiated deck,
- and snapshot/handoff/share remain explicit second steps.

## 1. SlopOS still supplies the constitutional laws

SlopOS keeps teaching the laws the recipe system must never break:
- approval binds one exact mutable basis
- exact show-item intent should fail closed rather than degrade into nearby browse
- bounded candidate sets should stay visible rather than quietly selecting a winner
- preview metadata and other helper-local surfaces stay weaker than portable truth

Those laws mean a Helm recipe can only be a starter.
It cannot carry live approval,
currentness,
or exact reveal truth by itself.

## 2. Schell proves recipes and runs must stay on different stages

Schell continues to teach the clean stage split:
- proposal
- review
- run
- later outcome

That is exactly why a recipe should never be mistaken for a run surface,
and why a materialized deck should still be visibly pre-act until settlement or later calibration arrives.

## 3. ViewFS proves each pillar recipe needs several truth faces

ViewFS keeps parse,
diagnostics,
packets,
prepared acts,
and durable receipts distinct.
That is strong pressure against one generic deck card.
A pillar recipe should instead materialize a **small multi-face deck** where different truth classes remain visible.

## 4. Ward proves a recipe is not enough without revalidation posture

Ward’s read cuts,
staleness budgets,
and revalidation fences keep reinforcing the same law:
a good starter shape is useless if it hides freshness decay.
So every instantiated Helm deck should still expose drift sentry posture and reopen routes.

## 5. Steward proves pressure types belong in the instantiated deck

Steward’s adaptation work keeps teaching that operators need typed pressure,
not one flattering mood.
That means pillar recipes may name the likely faces,
but the actual deck instance still needs to say whether the live issue is queue rebuild,
receiver lag,
low sample size,
headroom pressure,
or something else.

## 6. Harbor and Foundry keep recipe reuse humble

Harbor keeps preview cues and labels smaller than durable trust.
Foundry keeps actor path and caveat discharge smaller than current authority.
Together they teach a very useful recipe law:
reusable starter structure is valuable,
but **it must stay smaller than present authority,
live route truth,
or settled aftermath.**

## 7. The companions together point at one sharper pillar move

The companions do not ask Helm for:
- one universal dashboard,
- one giant notebook plane,
- one universal deck spec,
- or one early collaboration religion.

They ask for something smaller:
- one shell-wide rehearsal grammar,
- several pillar-specific starter recipes,
- and explicit ladders for materialize / refresh / snapshot / share / reopen.

## Product judgment

Keep the seven pillars stable.
Keep **settlement witnesses + commit cards** admitted.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes** and **bounded rehearsal decks** as the current datacube law.

And now flesh Helm in the most decision-light way available:

**define one first deck recipe for each pillar,
prove a few of them as specimens,
and let the rest stay warm until the shell pressure says which ones deserve full promotion.**
