# Research bibliography — 2026-03-22 — pass LXXXIV

1. **MDN — ETag header**
   - source: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/ETag
   - used for: version witnesses and mid-air-collision prevention when paired with `If-Match`

2. **MDN — If-Match header**
   - source: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/If-Match
   - used for: compare-before-mutate posture on exact prior versions

3. **Kubernetes docs — API concepts**
   - source: https://kubernetes.io/docs/reference/using-api/api-concepts/
   - used for: `resourceVersion`, watch resumption, and bookmark events as honest caught-up witnesses

4. **Google Drive API guide — Retrieve changes**
   - source: https://developers.google.com/workspace/drive/api/guides/manage-changes
   - used for: `startPageToken` as an explicit resume point for later change retrieval

5. **Google Drive API reference — `changes.watch`**
   - source: https://developers.google.com/workspace/drive/api/reference/rest/v3/changes/watch
   - used for: subscribing to changes from an explicit tokenized change stream

6. **Stripe API reference — Idempotent requests**
   - source: https://docs.stripe.com/api/idempotent_requests
   - used for: safe retry posture with one same-act key instead of duplicate side effects

7. **Stripe docs — Advanced error handling**
   - source: https://docs.stripe.com/error-low-level
   - used for: retry guidance and the model that repeated POSTs become safely retryable with an idempotency key

8. **Kubernetes docs — Finalizers**
   - source: https://kubernetes.io/docs/concepts/overview/working-with-objects/finalizers/
   - used for: explicit delete-requested versus delete-complete state and cleanup blockers that keep the object visible

9. **Kubernetes docs — Garbage collection**
   - source: https://kubernetes.io/docs/concepts/architecture/garbage-collection/
   - used for: `deletionTimestamp` and foreground deletion as a model for pending teardown truth
