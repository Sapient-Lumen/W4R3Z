# Helm: footing death cards + residue ladders — 2026-03-23

Keep the seven pillars stable.
Do not add another pillar.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **footing marks** and typed **delta ladders** as the current substrate grammar beneath resumption briefs.

But after that,
one narrower seam now looks worth warming:

**footing death cards** so the shell can say when an earlier footing no longer survives exactly,
what killed it,
and what scope is affected;
paired with **residue ladders** so the shell can say what weaker evidence still remains and what strength it still has.

## Why this now looks necessary

A footing mark answers:
- since what exact earlier footing?

A delta ladder answers:
- what exact next round,
  poll,
  rebuild,
  or reacquire path exists from there?

But a returning operator often needs one missing answer first:

- does that earlier footing still survive exactly?
- if not,
  what exact kind of death happened?
- what weaker residue still exists?
- and is the next honest move `continue`,
  `latest-only`,
  `rebuild`,
  `continue-as-new`,
  or `history only`?

Without that seam,
Helm is tempted to overuse `stale`,
`reset`,
`retry`,
or `resume unavailable`.
Those are not strong enough.

## The smallest object pair

### Footing death card
A compact shell-owned receipt that says:
- what exact footing died,
- what kind of footing it was,
- what killed it,
- what reset scope follows,
- what weaker residue still survives,
- and what strongest honest next verbs are now.

### Residue ladder
A compact shell-owned strength ladder for what remains after exact footing dies.
Likely first classes:
- `exact footing survives`
- `same identity new chain`
- `compared basis only`
- `digest only`
- `history only`
- `no useful residue`

The point is not to create a giant taxonomy.
The point is to stop flattening all post-footing states into one generic failure or one fake resume.

## What the web now teaches

The current official product pressure converges on this pair.

Google Calendar invalidates old sync tokens and requires full resync.
OneDrive and Microsoft Graph treat delta tokens as snapshot state and require sync reset when the token dies.
Dropbox returns reset on expired cursor and also offers a weaker latest-only cursor path.
Kubernetes separates synced-through bookmarks from current watch and explicitly tolerates `410 Gone` for older resource versions.
Pub/Sub snapshots have bounded expiry.
MongoDB distinguishes `resumeAfter` from `startAfter` after invalidation.
Temporal shows how identity may continue while exact earlier history does not by starting a new run with the same workflow id and a fresh run id.

Together these are almost a design brief for Helm:
**continuity loss needs typed death causes,
weaker residue classes,
and exact next verbs.**

## What this lets Helm do better

### Recall
Recall can reopen with one exact answer:
- `review footing survives`
- `review footing gone; compared basis only`
- `last exact footing expired; new chain available`
- `history only`

### Object Browser
Saved views,
snapshots,
replay capsules,
and compare surfaces can say whether an earlier footing is still exact,
rebuilt,
partially comparable,
or history-only.

### Operations Center
Runs,
jobs,
flows,
and landing trains can say whether earlier footing survives,
whether only attempt lineage survives,
or whether the operator is now on a new chain.

### Exchange
Materialization,
landing,
delivery,
and route aftermath can preserve route/effect residue without bluffing that earlier footing still supports exact continuation.

### Omnibox and Desktop Flow
Quick reopen or continue actions can stop promising magical resume.
They can choose the strongest honest next verb from the death card and residue ladder instead.

## Lessons Helm must keep learning from the past

- Never silently remap dead footing onto newer live truth.
- `resume unavailable` is too vague.
- Dead footing is not automatically source failure.
- Reset scope matters.
- Weak residue should stay inspectable even when strong footing dies.
- Identity continuity and history continuity are different truths.

## Awesome moves this enables

- one tiny death chip on serious cards;
- one small residue chip beside compare or reopen actions;
- `jump nearest honest residue` without calling it exact resume;
- `same identity, new chain` as a first-class return posture;
- calm reset-scope chips such as `relist`, `rebuild same subject`, `latest-only`, `continue as new`, `history only`.

## Best current decision

Still do not add another pillar.
Still do not build a giant sync center.

But it now looks wise to warm **footing death cards** and **residue ladders** as the next compact honesty seam beneath **footing marks** and typed **delta ladders**.
