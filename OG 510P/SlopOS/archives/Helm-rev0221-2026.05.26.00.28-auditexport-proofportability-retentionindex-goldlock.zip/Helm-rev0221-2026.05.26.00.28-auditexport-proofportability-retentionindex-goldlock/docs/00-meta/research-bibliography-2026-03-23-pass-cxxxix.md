# Research bibliography — 2026-03-23 pass CXXXIX

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-DAGSTER-FRESHNESS-2026B | https://docs.dagster.io/guides/observe/asset-freshness-policies | freshness policy posture is a strong model for Helm health windows |
| REF-DAGSTER-CHECKS-2026B | https://docs.dagster.io/dagster-basics-tutorial/asset-checks | attached checks remain a good precedent for reviewed-slice health components |
| REF-DAGSTER-HEALTH-2026 | https://docs.dagster.io/guides/observe/asset-health-status | one combined health status over latest materialization, freshness, and checks is a strong model for compact Helm health tiles |
| REF-DBT-EXPOSURES-2026 | https://docs.getdbt.com/docs/build/exposures | downstream dashboards/apps/analysis as named exposures is a strong model for Helm use rails |
| REF-DBT-FRESHNESS-2026B | https://docs.getdbt.com/docs/deploy/source-freshness | warn/error freshness windows are a good pattern for basis-honest health posture |
| REF-DBT-QUERY-HISTORY-2026 | https://docs.getdbt.com/docs/explore/model-query-history | consumption visibility is strong pressure for downstream-use and investment posture |
| REF-DBT-VERSIONS-2026 | https://docs.getdbt.com/docs/mesh/govern/model-versions | latest-versus-pinned versions plus deprecation windows are strong precedents for depended-on published slice versions |
| REF-DATAHUB-IMPACT-2026 | https://docs.datahub.com/docs/act-on-metadata/impact-analysis | concrete upstream/downstream impact analysis is a good model for Helm use and affected-set rails |
| REF-DATAHUB-ASSERTIONS-2026 | https://docs.datahub.com/docs/managed-datahub/observe/assertions | attached assertions are a good precedent for keeping checks bound to concrete reviewed objects |
| REF-HEX-HISTORY-2026 | https://learn.hex.tech/docs/explore-data/projects/history-and-versions | saved versions versus published live versions is a strong draft/live lesson |
| REF-HEX-SCHEDULED-2026 | https://learn.hex.tech/docs/share-insights/scheduled-runs | scheduled runs always using the published version is a strong precedent for draft/live honesty |
| REF-HEX-MODELING-WORKBENCH-2026 | https://learn.hex.tech/docs/connect-to-data/semantic-models/semantic-authoring/semantic-authoring-overview | publish preview with changes, references, and test lanes is a strong model for Helm compare-before-adopt surfaces |
| REF-HEX-REVIEWS-2026 | https://learn.hex.tech/changelog/2024-04-03 | rich diff plus compare-current-draft-to-published is a good precedent for humane review-before-publish posture |
