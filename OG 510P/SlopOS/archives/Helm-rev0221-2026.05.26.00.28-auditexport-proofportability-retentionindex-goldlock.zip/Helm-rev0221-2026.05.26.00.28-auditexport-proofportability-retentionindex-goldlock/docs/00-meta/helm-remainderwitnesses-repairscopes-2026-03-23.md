# Helm: remainder witnesses + repair scopes — 2026-03-23

## Headline

Helm should probably stop asking one object to do too many jobs.

An **effect receipt** should say what exact historical aftermath landed.
A **continuation handle** should say whether there is still one exact decaying way to continue now.
A **remainder witness** should say what exact unfinished / failed / unresolved slice still remains.
A **repair ladder** should say what humane next move remains,
preferably starting from that smaller exact slice.

## Why now

Helm's aftermath story is much better than it used to be:
- effect receipts
- slot verdict ledgers
- continuation handles
- repair ladders

But one important question still falls awkwardly between them:

**what exactly is left?**

Without a distinct object,
Helm risks three bad stories:
- treating the original selected cohort as if it were still the right repair scope
- treating a live continuation handle as if it fully explained the unfinished slice
- or treating any partial outcome as one vague failed / pending badge

## The move

### Remainder witnesses

A remainder witness should be one compact shell-owned witness for:
- one exact historical aftermath or continuation context
- one exact unfinished / failed / unresolved slice
- one exact expression of that slice
- and one exact weather relation showing whether it is still live,
shell-derived historical,
stale-check-first,
or partially unknown

The slice should stay explicit:
- remaining byte ranges
- failed job indexes
- unresolved rows or slots
- pending recipients
- receiver-local not-yet-confirmed items
- or another admitted small vocabulary

### Repair scopes

Repair ladders get better when they can admit not just whether a continuation handle still exists,
but also whether one exact remainder witness exists.
That lets the ladder say things like:
- resume exact remaining ranges
- rerun failed jobs only
- redrive from the unsuccessful step
- reopen unresolved slots only
- widen back to the whole original cohort
- or hold because the exact remainder is partially unknown

## Strongest ideas worth stealing

### 1. Exact remaining slices should be fields,
not prose
`nextExpectedRanges`,
`Upload-Offset`,
`ListParts`,
and `failedIndexes` all keep the unfinished slice concrete.
Helm should steal that directly.

### 2. Handle death should not erase remainder truth
A continuation handle can expire or be lost.
That should not force Helm to forget the smaller exact unfinished slice if the shell still knows it.

### 3. Narrow repair should be the default,
not an advanced option
GitHub rerun-failed and Step Functions redrive both prove that operators often want the smallest honest continuation or repair scope.
Helm should prefer the remainder by default before offering widen-to-all.

### 4. Remainder is not the original cohort
The original cohort answers what the act started from.
The remainder answers what is still left after history happened.
That distinction is subtle and worth protecting.

### 5. Remainder is not the affected set
Affected-set witnesses are about what was predicted or observed as touched.
A remainder witness is about what still remains.
Those can overlap,
but they are not the same object.

## What to keep from older inspirations

Keep:
- exact subset truth
- compact weather / freshness posture
- humane next-step ladders
- small proof-bearing objects instead of giant orchestration ideology
- shell-owned presentation over provider-native mechanics

Peel away:
- giant DAG / queue / planner ambition
- any UI that silently widens recovery scope
- any story that makes a dead continuation handle the only memory of what was left
- any badge that tries to be cohort,
affected set,
remainder,
continuation,
and current-live truth all at once

## Why this could make Helm super awesome

### 1. Helm could answer “what is left?” precisely
Not just what happened,
and not just whether resume still exists,
but what exact smaller slice is still unfinished.

### 2. Operations Center becomes calmer and more actionable
Instead of generic failed / pending rows,
it can show:
- remaining ranges 128–255 MiB
- failed indexes 3,7,9
- unresolved slots 2 of 11
- continuation alive until 14:22
- or handle dead but exact remainder still known

### 3. Recall gets more honest
Recall can distinguish:
- historical effect only
- effect + live continuation handle
- effect + exact remainder but no live continuation
- effect + partially unknown remainder
- current-live beacon stronger than all of them

### 4. Exchange gains a premium aftermath chain
Offer,
take,
route,
materialization,
effect,
continuation,
remainder,
and repair become distinct visible rungs.
That is unusual,
and it would feel deeply intentional.

## Pull-the-trigger judgment

The seven pillars still look stable.
This is not a new pillar.
But it now looks wise to warm one more compact support move:

**remainder witnesses**,
with **repair ladders** learning to prefer them as the default repair scope when exact remainder truth exists.
