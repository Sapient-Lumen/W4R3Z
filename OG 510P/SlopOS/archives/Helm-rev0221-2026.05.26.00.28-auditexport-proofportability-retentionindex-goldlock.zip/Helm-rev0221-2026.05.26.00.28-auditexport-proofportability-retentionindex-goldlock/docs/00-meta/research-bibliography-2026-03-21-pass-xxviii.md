# Research bibliography — 2026-03-21 pass XXVIII

## Primary outside sources used in this pass

- Visual Studio Code docs — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Visual Studio Code docs — **Settings Sync**
  - https://code.visualstudio.com/docs/configure/settings-sync
- Visual Studio Code docs — **User and workspace settings**
  - https://code.visualstudio.com/docs/configure/settings
- Visual Studio Code release notes — **July 2023 (version 1.81)**
  - https://code.visualstudio.com/updates/v1_81
- Visual Studio Code release notes — **December 2025 (version 1.108)**
  - https://code.visualstudio.com/updates/v1_108
- Raycast Manual — **Quicklinks**
  - https://manual.raycast.com/quicklinks
- Raycast Manual — **Dynamic Placeholders**
  - https://manual.raycast.com/dynamic-placeholders
- Figma Help — **Code Connect**
  - https://help.figma.com/hc/en-us/articles/23920389749655-Code-Connect
- Figma Help — **Guide to Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — **Adding Dock support to your extension**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Warp docs — **Launch Configurations**
  - https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp docs — **URI Scheme**
  - https://docs.warp.dev/terminal/more-features/uri-scheme
- WezTerm docs — **Workspaces / Sessions**
  - https://wezterm.org/recipes/workspaces.html
- Obsidian Help — **Introduction to Bases**
  - https://obsidian.md/help/bases
- Obsidian Help — **How Obsidian stores data**
  - https://obsidian.md/help/data-storage
- Notion Docs — **Working with views**
  - https://developers.notion.com/guides/data-apis/working-with-views

## Main local teacher documents re-opened in SlopOS rev0585

- `docs/30-architecture/view-objects.md`
- `docs/30-architecture/capability-semantics.md`
- `docs/30-architecture/approval-basis-posture-v0.md`
- `docs/30-architecture/capshell-affinity-posture-v0.md`
- `docs/30-architecture/capshell-scheduling-posture-v0.md`
- `docs/30-architecture/capx-posture-v0.md`

## What these sources mainly taught this pass

- **Figma / Raycast / Warp / PowerToys**: portable or pinnable surfaces work best when their callable inputs and bindings are explicit,
  not ambient
- **VS Code Profiles / settings scopes / partial profiles**: some classes can inherit receiver defaults honestly,
  but only when that inheritance is explicit and bounded
- **Obsidian / Notion**: views remain first-class explicit structures over stronger local substrate,
  not a mandate for one giant datacube UI
- **SlopOS view objects / approval-basis / capshell seams**: explicit resolution,
  explicit basis,
  and explicit omission law are still the right teachers for Helm
