# Helm condition strips + observed-basis chips — 2026-03-22

Purpose: name the next compact status move that looks worth proving after access verdict cards,
least-widening previews,
change cursors,
and teardown rails.

## Main idea

Helm already has many promising honesty objects.
But many surfaces still risk collapsing too much into one vague status pill.

The shell needs a calmer shared answer to two questions:

1. **what state is this exact thing in?**
2. **what exact mutable basis was that state observed against?**

The next compact answer looks like:
- **condition strips**
- **observed-basis chips**

## 1. Condition strips

A **condition strip** is a compact shell-owned projection surface over one exact subject.

It is the place where Helm can keep small state classes visibly different,
for example:
- ready
- progressing
- waiting
- restricted
- degraded
- suspended
- stale
- muted
- teardown-requested
- unknown

The important part is not the exact vocabulary.
The important part is that one strip can hold **several small truths without pretending they are one thing**.

### Why it is worth stealing

A single green/red/yellow badge forces too many meanings together.
Helm needs a small shared surface that can say:
- this is progressing,
- this is restricted,
- this is stale,
- this is muted,
- this is pending teardown,
without turning each pillar into its own bespoke status dialect.

### What it should not do

- not become a giant event center
- not become durable authority itself
- not replace receipts,
  warrants,
  or live leases
- not silently inherit child state unless a contract says so
- not flatten historical observations into live truth

## 2. Observed-basis chips

An **observed-basis chip** is a compact shell-owned witness chip next to a status,
verdict,
or summary.

It should be able to say things like:
- observed on current basis
- observed on older basis
- observed on basis N
- historical only
- cannot compare to current
- current changed since this was observed

### Why it is worth stealing

Many of Helm's sharpest laws already depend on exact mutable basis.
But status surfaces still too easily imply that an observation is about “now” when it is really about:
- the last seen basis,
- a prior generation,
- a saved review slice,
- or a stale watch result.

The chip makes that relation explicit.

### What it should not do

- not impersonate current-live authority
- not collapse into a generic stale badge
- not hide the exact compared basis when one exists
- not force a giant version-vector story where a simple exact witness would do

## 3. Why these two belong together

Condition strips answer:
**what compact state classes are currently known?**

Observed-basis chips answer:
**how current is that knowledge with respect to the mutable basis?**

Together they stop a lot of shell confusion:
- progressing but on current basis
- healthy but on old basis
- restricted and current
- muted but still unhealthy underneath
- teardown requested and current,
  not gone
- historical success,
  not current live readiness

## 4. Best first proofs

### Pull the trigger soon
- warm **condition strips** as a candidate shell object
- warm **observed-basis chips** as a candidate shell object

### Great first demos
- one Operations row for a long-running strong act showing progressing vs completed and an observed-basis chip
- one Browser saved-view row showing restricted / degraded / healthy / stale posture without one flattering badge
- one Recall card that says historical status observed on basis X rather than wearing a live badge
- one watchpoint card where muted stays visibly different from healthy
- one access verdict card that can attach an observed-basis chip when verdict depends on older review or older observed source state

## 5. Pillar pressure

- **Omnibox** benefits when quick results can show progressing / restricted / stale posture without opening a full inspector
- **Object Browser** benefits when saved views,
  glances,
  and watchpoints stop flattening health,
  freshness,
  and mute posture
- **Operations Center** benefits the most because long-running,
  gated,
  partial,
  and teardown-pending work needs a shared small status grammar
- **Desktop Flow** benefits when fragments and helper lanes can show waiting / restricted / failed / ready posture without giant logs-first panels
- **Recall** benefits when historical status can stay visible but basis-honest
- **Exchange** benefits when reveal,
  publication,
  and route cards can keep progressing / exposed / expired / revoked / stale posture visibly different
- **Terminal/Capshell** benefits when blocked,
  restricted,
  progressing,
  and historical state can be surfaced as shell-owned chrome without becoming a second truth system

## Judgment

Helm still does not need another pillar.
It needs one compact status grammar that can travel across pillars.

The right answer now looks like:
- **condition strips**
- **observed-basis chips**

That pair looks like one of the cleanest remaining ways to make Helm more trustworthy and more legible at the same time.
