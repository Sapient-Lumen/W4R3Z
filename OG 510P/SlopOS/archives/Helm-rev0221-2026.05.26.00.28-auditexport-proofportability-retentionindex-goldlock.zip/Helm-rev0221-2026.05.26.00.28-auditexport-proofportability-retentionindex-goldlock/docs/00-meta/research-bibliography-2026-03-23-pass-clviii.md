# Research bibliography — 2026-03-23 — pass CLVIII

## Current official product docs reviewed in this pass

- GitHub Docs — About rulesets
- GitHub Docs — Available rules for rulesets
- GitHub Docs — Managing a merge queue
- LaunchDarkly Docs — Testing changes to flag targeting
- LaunchDarkly Docs — Creating guarded rollouts
- Argo CD Docs — Diff Strategies
- Kubernetes Docs — Server-Side Apply
- Kubernetes Docs — `kubectl apply view-last-applied`
- OPA Docs — Decision Logs
- Grafana Docs — Investigations App
- Datadog Docs — Notebooks
- Obsidian Help — Bases views
- Honeycomb Docs — Board Templates
- Raycast Manual — Cloud Sync
- Raycast Manual — Shared Quicklinks

## Main current takes captured from those sources

- LaunchDarkly keeps exact-context preview and cohort-percentage change together,
  which is ideal pressure for one shell rehearsal surface that shows both one subject and one slice.
- GitHub keeps Evaluate-mode / Rule-Insights truth separate from enforcement,
  and merge queue keeps grouped-check / rebuild truth visible instead of pretending each candidate lands in isolation.
- Argo CD keeps predicted-live compare useful while documenting cache refresh and invalidation triggers.
- Kubernetes and OPA keep decision footing reopenable later through field/basis inspection and decision logs.
- Grafana and Datadog validate bounded investigation workspaces rather than giant always-on dashboards.
- Obsidian, Honeycomb, and Raycast reinforce multi-view, templated, and explicit personal-versus-shared deck posture.

## Local companion surfaces reopened in parallel

- SlopOS approval-basis / exact-reveal / selection-boundary posture docs
- Schell proposal / review / run / outcome separation surfaces
- ViewFS parse / diagnostics / packet / receipt separation surfaces
- Ward read-cut / staleness-budget / revalidation-fence surfaces
- Steward adaptation-witness / cache-trim / headroom surfaces
- Harbor coarse-origin / preview-asset / label-honesty surfaces
- Foundry discharge-witness / caveat-hold / actor-path surfaces
- Helm action rehearsal / landing train / patrol route / view deck candidate docs

## Product sentence this pass supports

Helm should likely prove one **bounded rehearsal deck** next —
built from exact-subject preview, cohort delta, grouped checks, drift sentries, and later reopenable settlement/calibration —
instead of adding another pillar or another giant center.
