# Helm — preview warrants and enactment bonds

## Current judgment

Do **not** add a new pillar.
Do **not** freeze a universal plan/apply center.
Do **not** let a preview artifact imply that Helm can later claim exact sameness without one explicit stronger receipt.

The strongest next move is smaller:
**warm preview warrants + enactment bonds as the shell-owned seam after merge previews and conflict ledgers.**

## What Helm can already say

Helm can already say:
- what local floor exists here,
- what origin it still tracks,
- what divergence posture exists,
- what reconcile recipe is proposed,
- what preview that recipe would yield right now,
- and what unresolved remainder still blocks adoption.

What Helm still answers too weakly is:
- **is this preview only inspectable, or can Helm later claim it enacted this exact preview?**
- **what invalidates that claim?**
- **which previews deserve a saved-plan or queue-bound guarantee class, and which must stay inspect-only?**
- **what exact receipt ties a later accept/apply/cutover back to one earlier preview?**

## The lesson Helm must learn from the past

Past systems keep making the same preview mistake:
**they show a beautiful rehearsal, then they quietly blur rehearsal into later action.**

That creates false calm:
- a speculative plan looks authoritative even though later state may differ,
- a queue result is treated as stable even after group membership changes,
- a dry-run feels exact even though admission or provider rules only partially constrain what later persists,
- a saved plan or constrained apply exists but the UI does not explain that it is a stronger class than ordinary preview.

Helm should refuse that whole family of mistakes.

## The next narrow seam

### Preview warrant
A **preview warrant** is a tiny shell-owned guarantee card that answers:
- what this preview is bound to,
- how strong the later sameness claim can be,
- what invalidates it,
- and whether a stronger re-check is still required.

Good warrant classes now look like:
- `inspect-only`
- `recheck-required`
- `queue-bound`
- `saved-plan-bound`
- `provider-limited`
- `invalidated`

### Enactment bond
An **enactment bond** is the later receipt that answers:
- did Helm enact exactly what was previewed,
- did it have to rebuild/recheck first,
- did drift invalidate the preview,
- did constraint checking stop the action,
- or did the provider diverge in a way Helm must surface explicitly?

The enactment bond is still weaker than settlement.
It only tells the truth about preview-to-action relation.

## Why this is better than more cube

This move makes the existing pillars richer without inventing another center.
It lets every serious pillar say:
- here is the preview,
- here is how strong its later claim can be,
- here is what would invalidate it,
- and here is the exact receipt if we really did enact it.

That is a much better operator loop than a prettier preview.

## The best things to steal

1. **Terraform speculative vs saved plan** distinction
2. **HCP Terraform automatic cancellation of outdated speculative plans**
3. **Pulumi update plans** that constrain later update to the planned operations and fail on discrepancies
4. **Kubernetes dry-run side-effects law** that keeps provider limits explicit
5. **GitHub merge queue rebuild** when the queue/base changes
6. **Git merge-tree / rerere** preview and remembered-hint posture,
   but still weaker than acceptance

## What not to keep

Do not keep:
- one generic `preview passed` badge,
- or any shell myth where a nice preview can later be claimed as enacted without saying why.

Also do not keep the opposite mistake:
- forcing every preview through a saved-plan regime.

Most previews should stay weak.
Only some deserve a warrant.

## Why this makes Helm super awesome

Because it gives Helm a premium rehearsal-to-action loop:
- choose a recipe,
- see one preview,
- see one compact warrant telling how strong that preview really is,
- act later with one enactment bond,
- and then let settlement witnesses tell the later aftermath truth.

That is the kind of shell honesty people remember.
