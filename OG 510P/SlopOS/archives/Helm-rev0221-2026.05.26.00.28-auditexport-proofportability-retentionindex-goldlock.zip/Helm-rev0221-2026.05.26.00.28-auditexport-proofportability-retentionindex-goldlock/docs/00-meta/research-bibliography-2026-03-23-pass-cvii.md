# Research bibliography — 2026-03-23 — pass CVII

## Primary outside sources reviewed in this pass

1. MDN — **Navigator.share()**
   - URL: https://developer.mozilla.org/en-US/docs/Web/API/Navigator/share
   - Why it mattered: the docs explicitly note that `share()` resolves at different moments on Windows versus Android, which is strong evidence that route selection / handoff and durable effect are not one universal truth.

2. Android Developers — **Send simple data to other apps**
   - URL: https://developer.android.com/training/sharing/send
   - Why it mattered: Android Sharesheet supports chooser callbacks with `ChooserResult`, custom chooser actions, and route-specific completion information about what target the user selected.

3. Android Developers — **Provide Direct Share targets**
   - URL: https://developer.android.com/training/sharing/direct-share-targets
   - Why it mattered: Direct Share / Sharing Shortcuts are published in advance, freshness matters, stale or irrelevant targets should be avoided, and tapped direct targets should land directly on the chosen subject UI.

4. Microsoft Learn — **Windows ShareTarget QuickLink namespace docs**
   - URLs:
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.sharetarget.quicklink.id?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.sharetarget.quicklink.title?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.sharetarget.quicklink.supporteddataformats?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer?view=winrt-26100
   - Why it mattered: Windows keeps remembered share targets typed, named, and format-scoped rather than flattening route memory into one universal default.

5. Microsoft Learn — **DataPackage / ShareCompleted / ShareCanceled / OperationCompleted**
   - URLs:
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage.sharecompleted?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage.sharecanceled?view=winrt-26100
   - Why it mattered: route and aftermath events are explicitly modeled and should not be flattened into one shell status bit.

6. Chrome for Developers — **Web Share Target API**
   - URL: https://developer.chrome.com/docs/capabilities/web-apis/web-share-target
   - Why it mattered: installed web apps can register as share targets, declare accepted shapes in the manifest, and sometimes need their own landing page to disambiguate in-app destinations.

7. XDG Desktop Portal — **FileTransfer**
   - URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
   - Why it mattered: retrieval is a later explicit step, sessions can autostop after first retrieval, and closure is signaled — a strong reminder that chosen route and later retrieval/effect are separate truths.

8. XDG Desktop Portal — **Documents**
   - URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
   - Why it mattered: exported files become visible through a controlled mount, permissions are explicit, and persistence/session scope is a route-local property rather than universal exchange truth.

9. Apple Developer Documentation — **NSSharingServicePicker delegate / UIActivityViewController completion handlers**
   - URLs:
     - https://developer.apple.com/documentation/appkit/nssharingservicepickerdelegate/sharingservicepicker%28_%3Adidchoose%3A%29
     - https://developer.apple.com/documentation/uikit/uiactivityviewcontroller/completionwithitemshandler-swift.typealias
   - Why it mattered: Apple also preserves a chosen-service seam and a later completion seam, even if the exact completion meaning stays route-specific.

## Companion-cube surfaces re-read in this pass

### SlopOS
- `docs/30-architecture/mcp-completion-import-boundary-v0.md`
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
- `docs/30-architecture/openuri-session-selection-boundary-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`

### ViewFS
- `docs/30-architecture/requests-candidates-selections-and-imports.md`
- `docs/70-shell/route-plans-approval-checkpoints-and-result-cards.md`
- `docs/30-architecture/handles-refs-and-receipts.md`
- `docs/30-architecture/imports-exports-transfers-and-promised-files.md`

### Schell
- `docs/80-terminal/chooser-witnesses-ranked-recall-and-preview-humility.md`
- `docs/80-terminal/handoff-ladders-observation-truth-and-completion-humility.md`
- `docs/80-terminal/share-witnesses-replay-capsules-and-publication-humility.md`
- `docs/80-terminal/drop-witnesses-file-offers-and-path-translation-humility.md`

### Steward
- `docs/30-architecture/activation-receipt-posture-v0.md`
- `docs/30-architecture/chrome-lane-posture-v0.md`
- `docs/30-architecture/label-surface-posture-v0.md`
- `docs/30-architecture/target-anchor-posture-v0.md`

## Bottom line

This pass reinforces a compact Exchange sequence worth keeping warm:
**offer → take card → route witness → effect receipt**.
That looks more honest than any single “shared” or “sent” badge. 
