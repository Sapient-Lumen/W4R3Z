# SlopOS companion-cube evaluation — 2026-03-23 — pass CIV

## Purpose

Continue reading **SlopOS**, **ViewFS**, **Schell**, and **Steward** as design-phase teachers for Helm,
without pretending any one of them has already settled the law for the whole shell.

This pass asks a narrower question:

**what object should Helm add so “someone or something is touching this exact subject now” becomes truthful, decaying, and reviewable without collapsing into authority, assignment, task progress, or history?**

## Strongest lesson from SlopOS

SlopOS keeps repeating one constitutional move in different costumes:
**live capability/lease state is weaker or stronger than adjacent bookkeeping depending on the seam,
but it is never the same thing as the bookkeeping.**

That pressure comes through several nearby documents again:
- RFC-0058 keeps payer choice explicit with **operation-scoped budget leases** rather than invisible sponsorship.
- RFC-0049 keeps time donation and schedulable CPU budgets explicit rather than ambient.
- RFC-0031 keeps request/consent objects separate from granted outcomes.
- RFC-0039 keeps trusted-path human volition separate from historical proof residue.

The transferable shell lesson is:
**a live coordination claim should stay distinct from the power that could act,
from the request that asked,
and from the receipt that later explains what happened.**

That is exactly the law Helm needs if it wants a humane “someone is working on this now” surface.

## Strongest lesson from ViewFS

ViewFS is unusually explicit that:
- immediate request
- accepted task wrapper
- progress lane
- input-required checkpoint
- final retrievable result
- and durable receipt

are all different strengths.

That is the cleanest internal warning against turning a work claim into “the task,”
“the result,”
or “proof that authority still exists.”

A Helm work claim should therefore be:
- narrower than a task system,
- weaker than the underlying authority,
- and stronger than a vague recent-activity badge.

## Strongest lesson from Schell

Schell’s recall-aging work keeps teaching that searchable memory and action readiness are different.
A remembered command can stay useful while its **action lease** decays.

That transfers directly:
- a work claim without recent renewal should not keep impersonating live occupancy,
- a stale claim may still be historically valuable,
- and handback / release / takeover posture should be explicit instead of silently optimistic.

## Strongest lesson from Steward

Steward’s freshness-decay posture remains the best compact teacher for small chrome truth.
It keeps saying:
- do not build a universal heartbeat religion,
- do name freshness / renewal / last-known posture,
- and let status decay honestly in place.

That is exactly the right pressure for Helm work claims.
The shell needs one tiny claim object that can say:
- active,
- renewing,
- stale,
- conflicting,
- handback-requested,
- released,
- historical-only,
without pretending that a historical lock row is still a live guard.

## What Helm should keep from these cubes

Keep:
- exact subject binding
- live-versus-historical humility
- explicit renewal / expiry posture
- helper/automation power staying separate from mere coordination claims
- request / task / progress / result / receipt separation
- shell-owned compact chrome for who-what-why-now truth

Peel away:
- giant universal lock managers
- hidden background heartbeat folklore
- claim objects that secretly widen authority
- indefinite stale occupancy that never decays into review/override posture
- any temptation to say “assigned” or “running” when the real truth is only “last renewed recently”

## Current judgment

Helm still should **not** freeze a universal collaboration or locking platform.
But it probably **is** time to warm one compact specimen:

**work claims** — shell-owned, decaying, reviewable coordination objects over one exact subject or bounded cohort,
with explicit holder, purpose, shared/exclusive/delay posture, renewal freshness, and honest handback/release truth.

That feels like a real Helm move,
not a copy of somebody else’s infrastructure console.
