# Research bibliography — 2026-05-13 pass CLXXIX

## Semantic and metric layers

- Databricks Metric Views — https://docs.databricks.com/aws/en/business-semantics/metric-views/
- Databricks Metric View YAML reference — https://docs.databricks.com/aws/en/business-semantics/metric-views/yaml-reference
- Cube introduction — https://cube.dev/docs/product/introduction
- Cube pre-aggregations — https://cube.dev/docs/product/caching/using-pre-aggregations

## Table formats, local analytics, transport, snapshots

- Apache Iceberg evolution — https://iceberg.apache.org/docs/latest/evolution/
- Apache Iceberg partitioning — https://iceberg.apache.org/docs/latest/partitioning/
- DuckLake snapshots — https://ducklake.select/docs/stable/duckdb/usage/snapshots.html
- DuckDB overview — https://duckdb.org/
- Apache Arrow Flight RPC — https://arrow.apache.org/docs/format/Flight.html
- Observable Framework data loaders — https://observablehq.observablehq.cloud/framework/data-loaders

## Product workflow surfaces

- GitHub merge queue — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
- GitHub rulesets / stale review behavior — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets
- Linear Triage — https://linear.app/docs/triage
- Airtable views — https://support.airtable.com/docs/getting-started-with-airtable-views
- Airtable view organization — https://support.airtable.com/docs/organizing-airtable-views
- Microsoft PowerToys Peek — https://learn.microsoft.com/en-us/windows/powertoys/peek
- Figma branching best practices — https://www.figma.com/best-practices/branching-in-figma/
- Figma get updates from main files — https://help.figma.com/hc/en-us/articles/5665728006423-Get-updates-from-main-files
- VS Code Profiles — https://code.visualstudio.com/docs/configure/profiles
- VS Code Workspace Trust — https://code.visualstudio.com/docs/editing/workspaces/workspace-trust

## Authorization, observability, durable history, local-first

- MCP authorization spec — https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization
- OAuth 2.0 Rich Authorization Requests / RFC 9396 — https://datatracker.ietf.org/doc/html/rfc9396
- OpenTelemetry context propagation — https://opentelemetry.io/docs/concepts/context-propagation/
- Temporal event history — https://docs.temporal.io/encyclopedia/event-history
- Ink & Switch local-first essay — https://www.inkandswitch.com/essay/local-first/
