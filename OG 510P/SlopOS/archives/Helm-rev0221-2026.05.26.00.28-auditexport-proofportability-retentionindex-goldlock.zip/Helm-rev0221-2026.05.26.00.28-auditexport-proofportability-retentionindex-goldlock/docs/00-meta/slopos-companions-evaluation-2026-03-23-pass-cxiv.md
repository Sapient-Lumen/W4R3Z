# SlopOS + companion cubes evaluation — 2026-03-23 pass CXIV

Purpose: evaluate what the current companion cubes are teaching Helm now that several shell support objects are warm enough to compare against modern external product patterns.

## Strongest pressure from SlopOS now

SlopOS keeps teaching the same hard lesson in richer and richer forms:
**truth should stay exact, typed, and narrowly scoped, even when the product wants to feel magical.**

That still matters more than any specific feature steal.
The lessons Helm must keep learning from SlopOS are:
- descriptors are not live state
- issued grants are not current grants
- old witnesses do not float forward
- local policy and chooser truth should stay visible
- and boundary families matter because otherwise convenience language starts laundering real differences

For Helm, that means:
- do not let Overview become a second authority plane
- do not let Recall history impersonate current-live truth
- do not let helper or branch lanes quietly become foreground reality
- and do not let shell luxuries outrun typed shell objects

## Strongest pressure from ViewFS now

ViewFS keeps teaching that watching, rebuilding, receiving events, and owning a stable view are different strengths.
That lesson now applies beyond watchpoints.
It also applies to:
- Overview cards versus source objects
- Recall timelines versus current-live beacons
- branch/adoption posture versus live lane posture

ViewFS therefore strengthens a wider Helm law:
**derived surfaces should stay visibly derived.**

## Strongest pressure from Schell now

Schell is increasingly useful as Helm's “parallel luxury without silent mutation” teacher.
Its repo lanes, baseline cards, wake tickets, autonomy dials, and answer/input posture all reinforce a single shell law:
- parallel work is valuable
- suggestions are valuable
- drafts are valuable
- but live checkout truth must remain obvious

For Helm, that strongly validates:
- shadow work lanes
- adoption harbors
- checkpoint branches
- current-live beacons
- and exact handback / merge / reject posture

## Strongest pressure from Steward now

Steward still sharpens the discipline of tiny typed status surfaces.
That matters more than ever as Helm imagines richer landings and timelines.

The lesson is:
- status should name the exact condition
- decay should be typed
- and historical evidence should remain inspectable without overclaiming liveness

That is exactly the law Helm needs if Recall and Overview are going to get stronger without becoming mush.

## What Helm must learn from the past

### 1. Do not ship convenience folklore as shell truth

The past keeps producing the same failure mode:
- recents become fake continuity
- history becomes fake liveness
- dashboards become fake authority
- plugins become fake architecture

Helm has to keep refusing all four.

### 2. Do not freeze mega-objects before cross-pillar verbs are earned

SlopOS is still in design phase,
and that is useful.
It reinforces that strong archives earn their big nouns slowly.
Helm should therefore continue freezing:
- verbs
- proof slices
- narrow support objects
- and visible distinctions

before it freezes giant datacube machinery.

### 3. Exploration must stay visibly separate from live state

Schell, Figma-style branching, and worktree-style parallelism all say the same thing:
people love parallel luxury,
but only when the live lane remains obvious.

### 4. History is valuable only when its claim strength is honest

ViewFS and Steward keep pushing this.
A timeline, receipt, watch card, history entry, or restored artifact can be extremely useful,
but it should not overclaim what it knows.

## What now looks worth warming harder in Helm

### Weak Overview landing

This now looks increasingly wise to prove soon.
Not because Helm needs a new pillar,
but because the product needs one obvious, humane, shell-owned place to re-enter work without building a giant dashboard religion.

### Object timelines inside Recall

Helm should likely get better through exact subject timelines:
- one object
- one activity
- one saved view
- one route
- one lane

not one universal memory slurry.

### Adoption harbors and branch truth

This is the other move that increasingly looks worth proving hard.
Helm already has many of the nouns.
The product win comes when exploration, delegation, preview, and merge/adopt become visibly one coherent family.

## Pull-the-trigger judgment

The seven pillars still look stable.
The best current move is not “add an eighth thing.”
It is:

**make the existing pillars feel joined by proving one humane return-to-work cluster:**
- weak Overview landing
- object timelines in Recall
- adoption harbors / branch truth beside current-live beacons

That cluster looks like the next place where Helm could become super awesome without betraying the archive's discipline.
