# Research bibliography — 2026-03-23 — pass CVI

## Primary outside sources reviewed in this pass

1. Apple Developer Documentation — **NSItemProvider / registered type identifiers / representation conformance / preferred presentation style / preview imagery**
   - URLs:
     - https://developer.apple.com/documentation/Foundation/NSItemProvider
     - https://developer.apple.com/documentation/foundation/nsitemprovider/registeredtypeidentifiers
     - https://developer.apple.com/documentation/foundation/nsitemprovider/hasrepresentationconforming%28totypeidentifier%3Afileoptions%3A%29
     - https://developer.apple.com/documentation/foundation/nsitemprovider/preferredpresentationstyle-swift.property
     - https://developer.apple.com/documentation/foundation/nsitemprovider/previewimagehandler
   - Why it mattered: provider-side representations can be enumerated and tested before load, while preview and presentation hints stay weaker than actual take truth.

2. Apple Developer Documentation — **NSFilePromiseProvider**
   - URLs:
     - https://developer.apple.com/documentation/appkit/nsfilepromiseprovider
     - https://developer.apple.com/documentation/AppKit/supporting-collection-view-drag-and-drop-through-file-promises
   - Why it mattered: promised future files reinforce that the route may still need later materialization.

3. Microsoft Learn — **DataPackage / RequestedOperation / DataPackageOperation / AcceptedOperation / SetDataProvider**
   - URLs:
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage.requestedoperation?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackageoperation?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.ui.xaml.drageventargs.acceptedoperation?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage.setdataprovider?view=winrt-26100
   - Why it mattered: requested-versus-accepted-versus-performed operation truth, plus delayed rendering for expensive representations.

4. MDN / W3C / web.dev — **Web Share API / canShare / share_target / file sharing patterns**
   - URLs:
     - https://developer.mozilla.org/en-US/docs/Web/API/Web_Share_API
     - https://developer.mozilla.org/en-US/docs/Web/API/Navigator/canShare
     - https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Manifest/Reference/share_target
     - https://web.dev/patterns/files/share-files
   - Why it mattered: preflight shareability, declared accepted share-target file types, and fresh user activation for final send.

5. Android Developers — **send simple data / receive simple data / Direct Share targets / Android 14 Sharesheet improvements**
   - URLs:
     - https://developer.android.com/training/sharing/send
     - https://developer.android.com/training/sharing/receive
     - https://developer.android.com/training/sharing/direct-share-targets
     - https://developer.android.com/about/versions/14/features
   - Why it mattered: specific MIME discipline, preview behavior, confirm/edit-on-receive guidance, direct-share target publication, and newer receiver-adjacent custom actions.

6. XDG Desktop Portal — **FileTransfer**
   - URLs:
     - https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
     - https://github.com/flatpak/xdg-desktop-portal/blob/main/data/org.freedesktop.portal.FileTransfer.xml
   - Why it mattered: retrieve is a real step, file exchange is session-shaped, and sessions can autostop after the first retrieval.

## Companion-cube surfaces re-read in this pass

### SlopOS
- `docs/30-architecture/mcp-completion-import-boundary-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
- `docs/30-architecture/openuri-session-selection-boundary-v0.md`

### ViewFS
- `docs/30-architecture/imports-exports-transfers-and-promised-files.md`
- `docs/70-shell/shipping-lanes-boundary-previews-and-promised-outputs.md`

### Schell
- `docs/80-terminal/drop-witnesses-file-offers-and-path-translation-humility.md`
- `docs/80-terminal/clipboard-witnesses-copy-offers-and-egress-honesty.md`

### Steward
- `docs/90-inspirations/lessons-from-the-past.md`
- `docs/90-inspirations/steal-these-ideas.md`

## Bottom line

This pass reinforces a compact Exchange sequel worth keeping close:
**what is on offer,
what one chosen receiver can honestly take,
what actually happened,
and what durable aftermath remains are different strengths,
and Helm gets better when it preserves all four.**
