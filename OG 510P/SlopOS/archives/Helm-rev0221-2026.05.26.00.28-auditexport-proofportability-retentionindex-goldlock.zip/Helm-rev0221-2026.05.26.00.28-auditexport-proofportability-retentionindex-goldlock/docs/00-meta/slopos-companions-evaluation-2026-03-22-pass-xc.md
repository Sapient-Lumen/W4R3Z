# SlopOS + companions evaluation — 2026-03-22 — pass XC

Question for this pass: **what do SlopOS, Schell, ViewFS, and Steward teach Helm about conditional power, visible caveats, and subtree revoke while those cubes are still in design phase?**

## Short answer

They keep pointing at the same lesson:
**freeze the laws for narrowed power before freezing more datacube machinery.**

In this pass the strongest law is:

> a grant, link, recipe, or delegated share should be able to say not only **what it reaches**, but also **under what caveats it remains valid**, **what context is still missing**, and **what descendants should die if the parent is revoked**.

That is much more useful right now than another giant family.

## 1. SlopOS keeps teaching exact mediated power, not ambient folklore

The SlopOS bundle remains strongest when read as a teacher of:
- exact mutable basis,
- lease discipline,
- approval/receipt separation,
- request-versus-live humility,
- and explicit mediation at every boundary.

For Helm, the next implication is simple:
if delegated or shared power carries conditions,
those conditions should not disappear into backend folklore.
The shell should be able to surface a compact **caveat sheet** over one exact object.

Good SlopOS-aligned caveat axes now look like:
- time window,
- holder or cohort,
- route or audience class,
- exact subject family,
- current lane,
- freshness requirement,
- review-basis requirement,
- and optional live-context requirement.

What Helm should **not** steal from SlopOS yet:
- giant taxonomies of tokens or families before the shell proves their humane read shape,
- overly elaborate machinery for conditionality before the shell proves one compact visible caveat posture,
- any temptation to treat condition evaluation as a silent backend-only fact.

## 2. ViewFS is the clearest companion teacher in this pass

ViewFS has become unusually useful here.
Its caveat, witness, and trust notes keep reinforcing that:
- attenuation should be explicit,
- caveats should be inspectable,
- freshness should stay separate from authority,
- and explanation should remain weaker than permission.

That suggests two direct Helm steals:
1. **caveat sheets** on links, handles, recipes, delegated helpers, and live borrow objects
2. **delegation subtrees** in Operations so parent/child relation and subtree revoke stay legible

This is better than one generic Shared or Allowed badge.

## 3. Schell keeps pressure on humane rendering

Schell remains the companion most likely to stop Helm from making this ugly.
It keeps emphasizing:
- trusted chrome,
- anti-spoof separation,
- humble labels,
- exact handoff bundles,
- and compact review/guide surfaces.

For this pass, Schell says:
- render caveats as small shell-owned chips or drawers,
- keep missing context distinct from denied,
- keep live subtree revoke in trusted chrome or shell-owned Operations lanes,
- and never let app content impersonate the shell's conditional-power explanation.

## 4. Steward keeps the label discipline honest

Steward's current direction is still useful as a warning system.
It reinforces that labels need to admit:
- historical,
- current,
- stale,
- replayed,
- guide-only,
- and active-now distinctions.

That makes it a good companion for this rule:
**a caveat sheet is not authority.**
It is an explanation surface over authority.

Likewise,
**a delegation subtree is not the grant.**
It is the shell-owned visibility surface over ancestry,
attenuation,
and revoke blast radius.

## 5. Concrete design pressure on Helm

The strongest shell-native additions now look like:

### A. Caveat sheets
A compact sheet for one exact object showing:
- scope class,
- duration / expiry,
- current lane,
- audience or route class,
- holder / cohort constraints,
- freshness requirement,
- review-basis requirement,
- missing-context fields when the shell cannot yet determine whether the act is currently admissible,
- and whether those caveats were inherited or locally added.

### B. Delegation subtrees
A compact tree or chain for one exact grant/share object showing:
- parent object,
- current derived objects,
- attenuation deltas between parent and child,
- subtree-live versus historical-only posture,
- and revoke-this versus revoke-subtree posture.

### C. Conditional verdicts that are not flattened into deny
When an act is not currently admissible because a condition is unfilled,
Helm should prefer:
- **conditional / missing context**

rather than a vague no.

That is one of the clearest “steal this” ideas in the entire archive so far.

## 6. Lessons from the past, sharpened again

Past systems keep failing in familiar ways:
- conditionality is buried in backend policy text,
- delegation ancestry becomes impossible to inspect,
- revoke only kills the visible head and leaves children alive,
- or the UI collapses allow / deny / maybe-if-context into one badge.

Helm should refuse all four mistakes.

## 7. Pull-the-trigger judgment

This is close to a wise trigger.
Not a pillar trigger.
A **law + specimen** trigger.

Recommended next freeze:
- warm **caveat sheets** as a reusable shell projection surface,
- warm **delegation subtrees** as a reusable Exchange/Operations surface,
- and teach access verdict cards to admit **conditional / missing-context** posture.

Keep bigger datacube machinery fluid.
