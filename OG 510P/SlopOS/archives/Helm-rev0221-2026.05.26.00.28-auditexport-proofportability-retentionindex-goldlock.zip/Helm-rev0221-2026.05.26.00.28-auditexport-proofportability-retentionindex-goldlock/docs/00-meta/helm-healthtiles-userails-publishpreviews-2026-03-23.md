# Helm — health tiles, use rails, and publish previews — 2026-03-23

## The current call

Helm still does **not** need another pillar.
Helm still does **not** need a giant BI center,
a giant governance catalog,
or a giant notebook suite.
The next admitted shell-wide ratchet is still **settlement witnesses + commit cards**.

But the archive now has enough pressure to say something stronger about what could make Helm unusually good after the overlay/check/lineage cluster:

**reviewed slices become much more trustworthy when Helm can say whether they are healthy,
who depends on them,
what would change if they were promoted,
and whether the operator is looking at draft or live truth.**

## Why this cluster matters

The earlier clusters answered:
- saved versus live,
- branch versus main,
- freshness versus stale,
- and overlay/check/lineage versus source truth.

This adjacent cluster answers the next questions:
- can I trust this slice right now?
- who will care if I change it?
- what exactly am I about to publish or adopt?
- am I looking at a draft,
a live published surface,
a frozen share,
or history only?

## The lessons Helm must learn from the past

### 1) Summary is not truth
People absolutely benefit from compact health summaries.
But old systems constantly let one badge pretend to be the whole story.
Helm should refuse that.
A health tile should stay visibly weaker than:
- the exact slice,
- the exact checks,
- the exact freshness window,
- and the exact supporting receipts.

### 2) Downstream use is not authority
It is incredibly useful to know who uses something.
But consumer lists,
subscriptions,
references,
and impact rails should remain consequence visibility,
not hidden approval or hidden policy.

### 3) Draft is not live
As soon as decks or briefs gain richer workbench behavior,
Helm must keep:
- draft,
- compare-to-live,
- published/live,
- frozen snapshot,
- and historical receipt
visibly separate.

### 4) Mature depended-on objects deserve migration honesty
If a published slice becomes materially depended on,
mutate-in-place replacement may become the wrong default.
Helm should stay open to latest-versus-pinned posture,
deprecation windows,
and explicit migration truth.

## Brilliant ideas worth stealing

### A) Health tiles
Any reviewed slice,
saved deck,
or live inspector deck should be able to show one compact health tile built from:
- latest successful or failed refresh/materialization posture,
- freshness posture,
- attached checks,
- and observed basis.

The tile is for orientation.
It is not the canonical truth.

### B) Use rails
A reviewed slice or published deck should eventually be able to answer:
- who uses this,
- what downstream surfaces depend on it,
- what exact references point here,
- and what likely breaks or drifts if I change it.

### C) Publish previews
Before a stronger adopt/publish act,
Helm should increasingly offer one compact preview that can show:
- what changed since live,
- what exact basis the draft came from,
- what references/use rails point here,
- and one tiny test/explore lane.

### D) Strict draft-versus-live scheduling truth
If Helm ever runs deck refreshes,
subscriptions,
or notifications on a schedule,
it should be extremely explicit about whether the schedule uses:
- the live published version,
- a pinned frozen snapshot,
- or some private draft.

The safest default still looks like:
**scheduled/public truth runs the published object,
not the draft.**

### E) Version windows
If a reviewed slice becomes depended on enough,
Helm should keep the option for:
- latest versus pinned version posture,
- deprecation windows,
- and explicit migration cards
instead of only mutate-in-place replacement.

## What is worth keeping from old inspirations

Keep:
- compact health summaries,
- explicit checks,
- exposure/dependency visibility,
- compare-before-publish,
- and saved-versus-published version history.

Do **not** keep:
- one authority badge that hides the exact failure,
- giant dependency walls with no local actionability,
- draft work silently becoming live,
- or abrupt replacement for heavily depended-on published objects.

## Moves that could make Helm super awesome

### 1) Is this slice healthy?
Right from a deck or reviewed slice:
- one compact health tile,
- revealable failing checks,
- revealable freshness window,
- revealable observed basis.

### 2) Who depends on this?
Right from the same surface:
- one compact use rail,
- a count or named list of downstream references,
- and one affected-set preview before stronger acts.

### 3) Show me draft versus live
When editing or comparing:
- one obvious current live version,
- one obvious current draft,
- and one compare lane that keeps them distinct.

### 4) Publish with references in view
Before publish/adopt:
- show changed members,
- show downstream users,
- show health posture,
- and show whether the act is publish,
adopt,
snapshot,
or share.

### 5) Keep migration humane
If the object is depended on enough:
- allow pinned consumers,
- allow latest alias posture,
- and carry visible deprecation windows instead of springing surprise breakage.

## Product judgment

The immediate trigger is still **not** a giant governance center.
But this cluster now looks too good to ignore.

Helm should keep warming:
- health tiles,
- use rails,
- publish previews,
- draft-versus-live posture,
- and later maybe version windows for depended-on published objects.

That is one of the cleanest ways to make the shell feel super awesome while staying honest.
