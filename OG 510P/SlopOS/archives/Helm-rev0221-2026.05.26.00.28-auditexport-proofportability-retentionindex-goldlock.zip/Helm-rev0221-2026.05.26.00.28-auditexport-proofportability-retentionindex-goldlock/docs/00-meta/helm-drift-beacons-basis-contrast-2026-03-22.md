# Helm: drift beacons + basis contrast cards — 2026-03-22

Purpose: name the next compact support layer that now looks worth promoting again after drift gates, reviewed-basis law, and post-grant control.

## Main claim

Helm is finally getting good enough at:
- selected context,
- output claim posture,
- exact proposed change,
- aftermath truth,
- truthful recovery,
- authority duration,
- and post-grant narrowing/revocation.

That makes one new gap much easier to see:

**when the current thing drifted from the thing you reviewed,
saved,
remembered,
or adopted,
where is the tiny shell-owned cue and where is the bounded compare surface that tells the truth without becoming giant diff bureaucracy?**

The next likely answer is:
- **drift beacons**
- **basis contrast cards**

## Why this now looks mature enough

Outside tools are converging on the same pattern:
- GitHub binds approval to an exact diff state and can dismiss stale approvals when the diff changes.
- VS Code lets you compare worktree changes against the workspace and restore exact checkpoints.
- Notion treats saved result slices as real but explicitly expiring.
- Google Docs surfaces “updated since you last viewed” and named versions.
- Figma gives visual compare before merge and leaves restore non-destructive with fresh checkpoints.

SlopOS is converging from the harsher side:
- explicit local evidence only,
- no ambient latest chase,
- freshness metadata as hints not verdicts,
- and transient attention cues staying weaker than durable truth.

Those pressures line up unusually well.

## What Helm should probably steal

### 1. Every saveable or reviewable object should be able to grow one weak drift cue

A drift beacon should be able to say:
- unchanged
- changed
- materially drifted
- expired
- basis missing
- freshness unknown

That cue should work for:
- entry kits,
- activity spines,
- resource shelves,
- saved view objects,
- review tickets,
- action warrants,
- effect receipts,
- and exact Recall returns.

### 2. Every important beacon should have one stronger compare sibling nearby

This is the basis contrast card.
Not a giant universal diff tool.
A small shell-owned compare surface should show:
- current subject witness,
- basis witness,
- bounded change families or counts,
- compare posture,
- and the honest next ladder.

### 3. Review should not silently follow drift

Helm already learned this through drift gates.
Now it needs the humane front-end answer:
when something drifted,
show the cue,
show the bounded compare,
then offer:
- inspect,
- review again,
- update basis,
- branch from old basis,
- or hold.

### 4. Weak currentness and strong basis should coexist

Sometimes the right cue is only:
“someone changed this since you last viewed it.”
That is useful.
But it stays weaker than:
“this changed since the exact named basis you approved at 11:12.”
Helm should support both.

## What is worth keeping from older inspirations

Keep:
- named versions
- compare-with-workspace
- stale-review dismissal on exact diff change
- side-by-side and overlay comparison
- expiring saved result slices
- small changed-since-you-looked cues

Peel away:
- giant universal history viewers
- auto-refresh that silently swaps the basis
- changed badges with no witness
- every micro-change becoming an alert
- fake timelessness for saved slices and saved views

## What would make Helm super awesome here

### drift beacons on the front doors of work

A saved entry kit,
activity spine,
view deck,
or resource shelf could quietly say:
- **unchanged since named basis**
- **changed in 2 slots**
- **material drift — review before apply**
- **basis expired**

That would feel magical and honest.

### one click into a basis contrast card

Not a mode switch into giant history.
Just one compact compare card with:
- current on one side,
- basis on the other,
- bounded digest in the middle,
- and clear next ladders.

### drift-aware stronger actions

Action warrants,
repair ladders,
reversal warrants,
and revoke handles should all be able to inherit this.
If the basis drifted,
Helm should not merely gray out Apply.
It should say why,
show the compare,
and name the next rung.

### better Recall without fake continuity

Recall becomes much more powerful when it can say:
- here is the exact thing you last trusted,
- here is what it looks like now,
- and here is whether to continue,
branch,
refresh,
or hold.

That is a luxury worth stealing.

## Why this is better than a new pillar

It sharpens many existing pillars at once:
- **Recall** gets truthful changed-since basis return
- **Object Browser** gets stronger compare cues over exact objects
- **Operations Center** gets visible drift against reviewed or adopted state
- **Exchange** gets better compare-before-adopt and compare-before-refresh
- **Omnibox** gets bounded inspect/review-again ladders instead of only stale-disable
- **Desktop Flow** gets small drift truth over reusable fragments and side lanes

That is exactly the kind of leverage Helm should prefer right now.

## Current judgment

Do **not** add a pillar.
Do keep **saved view objects** and **checkpoint branches** as the main proof targets.

But the next compact support layer that now looks worth defining again is:
- **drift beacons**
- **basis contrast cards**
