# Research bibliography — 2026-03-22 — pass LII

1. **Chrome Web Store Help — Install and manage extensions**
   - source: https://support.google.com/chrome_webstore/answer/2664769
   - used for: on-click vs current-site vs all-sites extension access rungs

2. **Chrome for Developers — The `activeTab` permission**
   - source: https://developer.chrome.com/docs/extensions/develop/concepts/activeTab
   - used for: temporary access tied to explicit invocation and revoked on navigation/close

3. **Chrome for Developers — Persistent permissions for the File System Access API**
   - source: https://developer.chrome.com/blog/persistent-permissions-for-the-file-system-access-api
   - used for: per-item revoke and broader site-level revoke posture

4. **VS Code docs — Copilot CLI sessions**
   - source: https://code.visualstudio.com/docs/copilot/agents/copilot-cli
   - used for: worktree vs workspace isolation and permission-level differences

5. **VS Code docs — Use tools with agents**
   - source: https://code.visualstudio.com/docs/copilot/agents/agent-tools
   - used for: terminal auto-approve allow/deny rules and regex patterns

6. **VS Code docs — Security**
   - source: https://code.visualstudio.com/docs/copilot/security
   - used for: trusted-domain/content approval flow, auto-approval notifications, warning banners, and sandboxing stronger than auto-approval rules alone

7. **Android Developers — Permissions updates in Android 11**
   - source: https://developer.android.com/about/versions/11/privacy/permissions
   - used for: one-time permissions and auto-reset for unused apps

8. **Android Developers — Request runtime permissions**
   - source: https://developer.android.com/training/permissions/requesting
   - used for: process termination on revoked one-time permission and self-revoke APIs on Android 13+

9. **GitHub Docs — Reviewing and revoking personal access tokens in your organization**
   - source: https://docs.github.com/en/organizations/managing-programmatic-access-to-your-organization/reviewing-and-revoking-personal-access-tokens-in-your-organization
   - used for: org-level review/revoke and partial residual behavior after revoke

10. **GitHub Docs — Enforcing policies for personal access tokens in your enterprise**
    - source: https://docs.github.com/en/enterprise-cloud@latest/admin/enforcing-policies/enforcing-policies-for-your-enterprise/enforcing-policies-for-personal-access-tokens-in-your-enterprise
    - used for: maximum lifetime policy and fine-grained PAT default lifetime posture

11. **GitHub Docs — About GitHub Copilot coding agent**
    - source: https://docs.github.com/en/enterprise-cloud@latest/copilot/concepts/agents/coding-agent/about-coding-agent
    - used for: sandbox posture, restricted branch/token behavior, human review, and approve-and-run workflow gate

12. **OpenAI Help — Projects in ChatGPT**
    - source: https://help.openai.com/en/articles/10169521-projects-in-chatgpt
    - used for: app-link source addition and explicit approve-access step
