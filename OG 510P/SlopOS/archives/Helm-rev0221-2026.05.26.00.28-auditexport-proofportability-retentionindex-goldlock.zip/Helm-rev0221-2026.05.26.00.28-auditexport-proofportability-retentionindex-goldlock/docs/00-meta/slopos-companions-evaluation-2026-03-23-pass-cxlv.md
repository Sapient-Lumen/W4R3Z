# SlopOS + companions evaluation — 2026-03-23 pass CXLV

## Why this pass happened

The last Helm revision made the strongest adjacent cluster explicit:
**action-fit strips, reliance ladders over reviewed slices, fresh-intent gates, and maybe later bounded approval / protection hooks.**

This pass asked the next nearby question:
**once Helm can say what a slice is fit for right now, how should it say whether older review, watch, owner, or action-fit truth still binds after the footing has changed?**

The companion cubes still say the same big thing:
- freeze laws before giant centers,
- keep shell-owned truth stronger than explanation,
- and do not let design-phase convenience harden into fake continuity.

## What SlopOS still teaches best

### 1) Generation witnesses beat folklore
SlopOS keeps teaching a crucial law through generation witnesses and freshness-bound assurance:
when clone/restore or generation change happens,
old attestation/export comfort does not silently continue.
A new generation needs fresh observation and sometimes fresh reacquire posture.

That transfers directly into Helm.
A new slice footing,
semantic recipe revision,
serving-path epoch,
or published version should be able to fence older trust surfaces without inventing a giant control plane.

### 2) Recency and assurance boundaries are stronger than good vibes
SlopOS also keeps pushing the same repair discipline:
current assurance is bound to exact current conditions.
History is useful,
but it does not magically stay live.

Helm should keep the same humility.
Old review,
old watch coverage,
or old action fit may remain inspectable,
but should not quietly masquerade as still-binding truth.

## What ViewFS now teaches best

### 1) Basis, drift, reconsent, and renewed authority are different seams
ViewFS is one of the sharpest local teachers for this pass.
Its basis-record / drift-check / reconsent split is almost the exact product pressure Helm now feels.
A prior success or prior review is useful,
but it is not automatically current authority.

That suggests Helm should explicitly separate:
- the older reviewed epoch,
- the current footing relation,
- the stale-fence verdict,
- and any later reconsent or renewed action-fit posture.

### 2) Renewal can narrow instead of only extending
ViewFS also keeps teaching that renewal may narrow,
not just re-grant.
That matters for Helm because a reviewed slice may move from:
- fit to act,
- to fit to brief,
- to inspect only,
without becoming worthless.

## What Steward now teaches best

Steward's readiness-generation posture is a beautiful teacher for Helm.
It says status should preserve **which generation it actually observed**.
That means:
- current runtime cycle can remain live,
- while readiness still honestly belongs to an older generation,
- and `generation unknown` can be healthier than fake precision.

Helm should steal exactly that posture for reviewed slices,
smart decks,
and richer evidence briefs.
A slice may be visible and still useful while health,
coverage,
validation,
or action-fit remain attached to an older observed footing.

## What Ward now teaches best

Ward's newest pass sharpened three ideas that matter directly here:
- **root epoch**
- **threshold reset**
- **delegation freeze**

Ward is teaching that some changes are not ordinary drift.
Some changes are reset-class events that should not masquerade as routine verification success.

That gives Helm one especially useful refusal:
not every footing change is just `stale`.
Some should be typed more strongly as:
- reset-class,
- re-review required,
- old delegation frozen,
- or out-of-band trust refresh needed.

## Lessons Helm must learn from the past

### Must learn #1: old review glow is not current footing
A slice can keep the same title,
owner,
and broad meaning while its actual reviewed footing changed.
Helm should not let old review survive that invisibly.

### Must learn #2: desired and observed are different truths
A newer semantic recipe,
contract,
or deck basis may already exist,
while health / coverage / action-fit truth still belongs to the earlier observed footing.
Helm should preserve that lag honestly.

### Must learn #3: stale is not always the right downgrade word
Some changes are ordinary drift.
Others are reset-class events.
Helm should keep room for both.

### Must learn #4: temporary control artifacts should age toward retirement
Old overrides,
old approvals,
old temporary branches,
and old one-off controls should not inherit endless ambient authority.

## Current Helm judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Do not change that.

But the next adjacent cluster worth warming now looks like:
- **epoch stamps** for exact reviewed footing
- **stale-fence strips** for desired-versus-observed relation
- **reset witnesses** for stronger invalidation classes
- and maybe later **reconsent rails** or **delegation freezes** where the stronger rung should pause instead of quietly carrying forward

That cluster feels unusually well-supported by SlopOS,
ViewFS,
Steward,
and Ward all at once.
