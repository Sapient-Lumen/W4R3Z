# Research bibliography — 2026-03-23 — pass LXX

## Sources consulted for this pass

1. GitHub Docs — Reverting a pull request
   - reverting a merged pull request creates a **new pull request** containing one revert of the merge commit from the original merged pull request
   - the resulting pull request must still be merged
   - merge conflicts or non-GitHub merges may require manual commit-level revert instead

2. GitHub Docs — Re-running workflows and jobs
   - GitHub Actions supports rerunning all jobs,
     rerunning only failed jobs,
     or rerunning one specific job
   - reruns can optionally enable diagnostic / debug logging
   - earlier attempts remain reviewable from the workflow history

3. Kubernetes Docs — `kubectl rollout undo`
   - rollback can target the previous rollout or one exact named revision
   - undo also supports server dry-run
   - rollback is a named act,
     not generic retry folklore

4. Vercel Docs — Rolling back a production deployment
   - Vercel frames recovery as roll back to restore service,
     investigate the root cause,
     then deploy a fix
   - the guide also keeps direct promotion of an existing good deployment separate from a new deploy

5. Argo Rollouts Docs — FAQ / abort / rollback window
   - rollback in Argo Rollouts changes the cluster back to the stable version and marks the application degraded,
     but does not write anything back to Git
   - the documented next step is usually to fix the issue and roll forward
   - abort stops rollout progression and reverts rollout steps,
     but the template still reflects the new version until it is changed back
   - rollback windows can fast-track recent rollback targets by skipping repeated steps

6. LaunchDarkly Docs — Managing guarded rollouts
   - LaunchDarkly supports manual rollback,
     automatic rollback on detected regression or sample-ratio mismatch,
     and stop-monitoring-early posture
   - rolling back a prerequisite flag does not automatically roll back dependent flags,
     reinforcing that recovery scope must stay explicit
