# Helm: carry-forward rails, review packets, and who-acts-next truth — 2026-03-23

After **change classes** and **re-review gates**,
Helm now has a tighter adjacent question:

**once the shell knows what kind of change happened and what strength of re-review now fits,
what weaker truth may honestly carry forward,
and what exact packet should it gather for the next reviewer or operator?**

The most promising next cluster is:
- **carry-forward rails**
- **review packets**
- and maybe later **attention-turn chips**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. every changed slice acts as though all prior review vanished into smoke, or
2. old review glow floats forward with no exact law about what still binds.

Both are wrong.
Operators need a third answer:

- these parts still carry weakly,
- these parts do not,
- this is who should look now,
- and this is the packet of truth they should inspect.

## Candidate objects

### 1. Carry-forward rail
A compact statement of what still carries from the older reviewed footing,
kept visibly weaker than fresh review.

Good early carry candidates:
- unchanged stable anchors
- old notes still inspectable
- owner or audience context still relevant
- unchanged downstream checks still informative
- watch / coverage posture still relevant to inspection

Bad carry candidates:
- blocked action-fit magically restored
- sharp publish or commit authority restored
- reset-class or reacquire-class change flattened into ordinary review
- reviewer-set policy inferred from the packet itself

### 2. Review packet
A gatherable packet for the next review or recheck turn.

Good early contents:
- exact compared footing
- change class verdict
- re-review gate
- compare depth
- affected-set witness
- blindspots
- carry-forward rail
- current owner / ack / coverage posture
- candidate reviewer-set or review-scope hint
- exact next surface: inspect, recheck, full re-review, or reacquire

The packet is not the review.
It is the bounded object that says what the next turn is about.

### 3. Attention-turn chip (later)
A later tiny surface that answers:
**who is expected to act next?**

This should stay much smaller than a workflow or incident center.
It only needs to make turn-taking legible.

### 4. Reviewer-set hint (later)
A later bounded hint that can say:
- recipe owner review
- downstream-use owner review
- action-mode or exposure review
- domain review
- or `one of these groups` versus `one from each group`

This must stay hint-sized unless and until Helm proves it needs stronger policy machinery.

## What Helm should probably do now

### 1. Keep carry-forward separate from re-review gate
A carry-forward rail says what still weakly holds.
A re-review gate says what fresh work reopened.
They are not the same object.

### 2. Tie carry-forward to typed conditions
If Helm cannot say why something carries,
it should not carry.
Conditioned carry-forward is honest.
Floating residue is folklore.

### 3. Keep packets scoped and exact
A packet should talk about one exact changed footing and one review turn.
Not a general case file.

### 4. Let affected scope shape reviewer burden
When possible,
Helm should aim for:
- smallest affected review scope,
- explicit blindspots,
- and exactly named areas or use-rails touched.

### 5. Let some sharper actions require extra gates
For sharper moves,
Helm may later want:
- one-of-N or one-from-each-group review shapes,
- no self-review,
- or short wait windows.
That should remain later and bounded.

## Guardrails

1. **Do not let carry-forward rails restore blocked authority.**
2. **Do not let review packets become a giant case-management plane.**
3. **Do not let reviewer hints harden into hidden policy before a proof slice exists.**
4. **Do not let affected-set claims bluff exhaustive scope.**
5. **Do not let reset-class change ride ordinary carry-forward.**
6. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

- exact footing reviewed at `epoch-17`
- since then: `semantic-recipe` + `dependency-or-coverage`
- stable anchors carried: owner context, previous notes, one unchanged downstream check
- not carried: publish authority, high-risk action-fit
- affected scope: `billing-revenue`, `ops-dashboard`, `weekly-brief`
- blindspot: one cold consumer lane not revalidated
- review packet opened for: recipe owner + one downstream-use owner
- gate: `latest-push recheck` before publish,
  `full rereview` before strong action

That would make Helm dramatically better than either a single stale badge or a giant review bureaucracy.
