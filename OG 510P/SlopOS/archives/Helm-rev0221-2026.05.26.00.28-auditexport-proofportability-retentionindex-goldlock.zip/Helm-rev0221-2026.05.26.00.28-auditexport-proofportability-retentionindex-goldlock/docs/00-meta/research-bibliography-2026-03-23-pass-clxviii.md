# Research bibliography — 2026-03-23 — pass CLXVIII

| Ref | Source | Used for |
| --- | --- | --- |
| REF-MONGODB-READ-CONCERN-MAJORITY-2026H | https://www.mongodb.com/docs/manual/reference/read-concern-majority/ | majority-committed view and rollback-safe read class |
| REF-POSTGRES-SYNCHRONOUS-COMMIT-2026H | https://www.postgresql.org/docs/current/runtime-config-wal.html | `remote_write` vs `on` vs `remote_apply` and standby query visibility |
| REF-KAFKA-CONSUMER-ISOLATION-2026H | https://docs.confluent.io/platform/current/installation/configuration/consumer-configs.html | `read_committed`, last stable offset, and stable-readable frontier |
| REF-DYNAMODB-READ-CONSISTENCY-2026H | https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/HowItWorks.ReadConsistency.html | committed writes versus eventual / strong read paths |
| REF-COCKROACH-FOLLOWER-READS-2026H | https://www.cockroachlabs.com/docs/stable/follower-reads | closed timestamp and safe historical follower reads |
| REF-SPANNER-TIMESTAMP-BOUNDS-2026H | https://docs.cloud.google.com/spanner/docs/timestamp-bounds | exact staleness and bounded staleness read classes |
