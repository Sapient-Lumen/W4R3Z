# Helm context loadouts + contribution witnesses — 2026-03-22

Purpose: name the next compact shell move that can make Helm smarter and more humane without letting context sprawl turn into ambient authority.

## Main idea

Helm likely wants one shell-owned object for:

**what is intentionally in play for this ask, compare, route, or action right now?**

That object should be a **context loadout**.

And once the ask/action finishes,
Helm likely wants one small answer to:

**what actually influenced the result or proposal?**

That witness should be a **contribution witness**.

## Why this matters now

Helm already has several useful things that are *close* but not identical:

- **activity spines** — scoped work frames
- **resource shelves** — curated grouped resources
- **activity entry kits / front doors** — saved preferred ways back in
- **current-live beacons** — stronger cues for what is truly live now
- **activity memory seeds** — explicit remembered facts, warnings, and instructions
- **saved view objects** — durable query/perspective objects

What Helm still lacks is one small shell-owned answer to:

- these three tabs
- this one saved view
- these two files
- this warning seed
- these tools
- and this instruction fragment

are the exact context for *this* ask or compare.

Without that,
Helm risks slipping back into:
- ambient tab folklore,
- hidden prompt weather,
- invisible tool enablement,
- and “the model just looked around” mythology.

## What a context loadout is

A **context loadout** is a shell-owned selected set of current ingredients for one bounded act.

Good early members include:
- current tab or selected tabs
- files / objects / views
- memory seeds
- route or provider hints
- tools
- instruction/prompt fragments
- maybe one activity spine reference

The important thing is not the noun.
The important thing is the law:

**selected current context is explicit.**

## What a contribution witness is

A **contribution witness** is the honest after-surface.
It should be able to say things like:
- selected 5 context members
- actually used 3
- one tool was enabled but not used
- one member was skipped because it was out of scope
- one action path was previewed and then applied

This is a much better Helm magic than “trust me, the AI used the right stuff.”

## Relation to nearby Helm objects

### Not a resource shelf
A shelf is a durable curated collection.
A loadout is a current bounded selected set for one act.

### Not an activity spine
A spine is a scoped work frame.
A loadout can be assembled inside a spine,
but it should stay smaller and more temporary.

### Not an entry kit
An entry kit gets you back into work.
A loadout is the current selection for one ask/compare/route/action after you are already there.

### Not a memory seed
A seed is one remembered thing.
A loadout can include seeds,
but it does not turn them into current-live truth.

### Not a current-live beacon
A beacon is stronger.
A loadout explains what is in play for a request.
It does not prove what is live now.

## Why this seems especially worth stealing

Today’s best products are not just “remembering more.”
They are getting much better at:
- choosing context explicitly,
- bounding it,
- revealing it,
- and letting the operator remove or refine it.

That is exactly where Helm can be unusually good.
The shell can make context selection a first-class power across:
- Omnibox
- Object Browser
- Recall
- Exchange
- Operations Center
- Desktop Flow
- and terminal/capshell

## Super-awesome moves this unlocks

### 1. Ask with this exact loadout
From almost any surface:
- select objects/tabs/views/files
- hit ask/compare/plan
- see a compact loadout strip before send

### 2. Save this loadout as a tiny starter
The operator can keep a one-off selection,
or save it as:
- activity-local
- personal reusable
- shared/imported restricted

### 3. Show contribution witnesses automatically after meaningful AI help
Not giant provenance theater.
Just one honest witness chip/strip/card with inspectable detail.

### 4. Keep “current only” visibly weaker than “selected set” and “saved activity loadout”
Helm should make it very easy to understand the difference between:
- current thing only
- selected set
- saved current loadout
- wider project/activity context

### 5. Make pre-apply actions feel premium instead of scary
If an action is proposed,
Helm should prefer:
- preview
- inspect loadout
- inspect likely effect
- then apply/adopt

## What not to steal

- do not auto-include everything nearby
- do not let imported/shared loadouts arrive as ordinary local defaults
- do not let contribution witnesses become giant forensic theater before one tiny witness works
- do not let loadouts turn into a second invisible policy plane

## Pull-the-trigger judgment

Still yes:
- **saved view objects**
- **checkpoint branches**

Now also worth defining as support contracts:
- **context loadouts**
- **contribution witnesses**

If Helm gets this right,
it can feel dramatically smarter than current shells while staying *more explicit* than them, not less.
