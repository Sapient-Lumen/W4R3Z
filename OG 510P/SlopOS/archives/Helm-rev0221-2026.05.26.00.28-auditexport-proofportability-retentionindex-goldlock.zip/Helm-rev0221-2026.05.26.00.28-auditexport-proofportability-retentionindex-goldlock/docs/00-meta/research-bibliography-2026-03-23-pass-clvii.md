# Research bibliography — 2026-03-23 — pass CLVII

## Current official product docs reviewed in this pass

- GitHub Docs — About rulesets
- GitHub Docs — Managing rulesets for a repository (Rule Insights)
- GitHub Docs — Available rules for rulesets
- GitHub Docs — Managing a merge queue
- GitHub Changelog — Custom properties and rule insights improvements (SHA filtering)
- LaunchDarkly Docs — Testing changes to flag targeting
- LaunchDarkly Docs — Contexts
- LaunchDarkly Docs — Individual targeting
- LaunchDarkly Docs — Creating guarded rollouts
- LaunchDarkly Docs — Progressive rollouts
- HashiCorp Developer — `terraform plan`
- Kubernetes Docs — Server-Side Apply
- Kubernetes Docs — `kubectl apply view-last-applied`
- Argo CD Docs — Diff Strategies
- OPA Docs — Decision Logs

## Main current takes captured from those sources

- GitHub continues to separate rulesets,
  rule insights,
  evaluate-mode evidence,
  and merge queue promotion instead of turning them into one branch badge.
- LaunchDarkly continues to separate exact-context preview,
  unsaved-versus-current targeting comparison,
  guarded rollout,
  and ordinary progressive rollout.
- Terraform continues to keep speculative planning weaker than apply intent.
- Kubernetes continues to expose both field ownership and last-applied footing.
- Argo CD continues to distinguish desired,
  live,
  and predicted-live compare,
  and documents cache refresh triggers.
- OPA continues to preserve decision basis for later audit and debugging.

## Local companion surfaces reopened in parallel

- SlopOS `docs/30-architecture/approval-basis-posture-v0.md`
- SlopOS `docs/30-architecture/namecert-selection-boundary-v0.md`
- SlopOS `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- Schell command/review/run separation docs
- ViewFS parse / diagnostics / packet / receipt separation surfaces
- Harbor coarse-origin / preview-asset / label-honesty specimen
- Foundry discharge witness / caveat hold / actor-path specimen
- Ward read-cut / staleness-budget / revalidation-fence specimen
- Steward adaptation-witness / cache-trim / concurrency-cap surfaces

## Product sentence this pass supports

Helm should get richer through **truth axes + basis reopen routes** on top of the reviewed-slice round-trip,
not through another pillar or one giant omniscient datacube center.
