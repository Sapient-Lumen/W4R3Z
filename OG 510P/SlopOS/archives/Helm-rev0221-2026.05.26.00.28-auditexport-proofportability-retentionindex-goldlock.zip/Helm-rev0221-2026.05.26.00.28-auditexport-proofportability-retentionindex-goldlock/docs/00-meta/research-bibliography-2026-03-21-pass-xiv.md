# Research bibliography — 2026-03-21 — pass XIV

## Preview, bounded actions, and live derivative surfaces

- Apple Quick Look docs.
- Apple Finder Preview pane docs.
- Apple Finder Quick Actions docs.
- Microsoft PowerToys Crop And Lock docs.
- GNOME Activities overview docs.
- Raycast Windows changelog entries for Quick Look.

## Launch ladders, entry objects, and mode separation

- Warp Launch Configurations docs.
- Warp Workflows docs.
- Warp environment-variable / subshell docs.
- WezTerm launcher-menu and domain docs.
- Warp Agent Modality docs.

## Anchored context, status, and provider-hosted progress

- VS Code terminal shell integration docs.
- VS Code 1.104 / 1.109 release notes for terminal sticky-scroll and terminal context improvements.
- Microsoft PowerToys Command Palette overview docs.
- Microsoft PowerToys Command Palette extension-toolkit docs (status/progress surfaces).
- Node-RED subflows docs.

## Current use in Helm

This pass mainly pressures:
- preview-adjacent bounded actions as an Object Browser and cross-pillar shell move,
- launch ladders as honest saved entry objects rather than fake continuity,
- sticky context strips as small source anchors for long-lived results,
- host-owned status/progress surfaces in Omnibox, Operations Center, and Desktop Flow,
- and retention humility as a warning to keep warm while SlopOS and Schell both remain in design phase
