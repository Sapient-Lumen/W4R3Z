# Research bibliography — 2026-03-22 — pass LV

1. **Notion Docs — Working with views**
   - source: https://developers.notion.com/guides/data-apis/working-with-views
   - used for: views as first-class resources over one underlying database with per-view configuration

2. **Notion Help — Using linked databases**
   - source: https://www.notion.com/help/guides/using-linked-databases
   - used for: linked copies of the same underlying content appearing in multiple pages

3. **GitHub Docs — Customizing views in your project**
   - source: https://docs.github.com/en/issues/planning-and-tracking-with-projects/customizing-views-in-your-project
   - used for: multiple project views over one project truth

4. **GitHub Changelog — Hierarchy view in GitHub Projects is now generally available**
   - source: https://github.blog/changelog/2026-03-19-hierarchy-view-in-github-projects-is-now-generally-available/
   - used for: hierarchy preserved as a view option rather than a separate product domain

5. **GitHub Docs — Comparing commits**
   - source: https://docs.github.com/en/pull-requests/committing-changes-to-your-project/viewing-and-comparing-commits/comparing-commits
   - used for: explicit compare surfaces across branches, tags, commits, forks, and dates

6. **Arc Help Center — Spaces: Distinct Browsing Areas**
   - source: https://resources.arc.net/hc/en-us/articles/19228064149143-Spaces-Distinct-Browsing-Areas
   - used for: distinct context groupings with explicit space boundaries

7. **Arc Help Center — Profiles: Separate Work & Personal Browsing**
   - source: https://resources.arc.net/hc/en-us/articles/19227964556183-Profiles-Separate-Work-Personal-Browsing
   - used for: explicit identity/cookie/history scope attached to one or more spaces

8. **VS Code Docs — Profiles in Visual Studio Code**
   - source: https://code.visualstudio.com/docs/configure/profiles
   - used for: explicit switchable/exportable/importable setup bundles

9. **Raycast Manual — Quicklinks**
   - source: https://manual.raycast.com/windows/quicklinks
   - used for: tiny summonable handles to URLs, file paths, and deeplinks

10. **Microsoft Learn — PowerToys Workspaces utility for Windows desktop management**
   - source: https://learn.microsoft.com/en-us/windows/powertoys/workspaces
   - used for: capture/edit/pin relaunchable workspace starters as front doors rather than live truth

11. **Linear Docs — Triage**
   - source: https://linear.app/docs/triage
   - used for: dedicated triage inbox posture

12. **Linear Docs — Triage Intelligence**
   - source: https://linear.app/docs/triage-intelligence
   - used for: explainable issue-property/duplicate/relationship suggestions with accept/decline and configurable auto-apply

13. **Figma Help — Guide to branching**
   - source: https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
   - used for: controlled exploration spaces separate from the original file

14. **Figma Help — Review branch changes**
   - source: https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes
   - used for: nearby review/merge flows on explicit branches

15. **Obsidian Help — Introduction to Bases**
   - source: https://obsidian.md/help/bases
   - used for: local database-like views over one local substrate

16. **Obsidian Developer Docs — Build a Bases view**
   - source: https://docs.obsidian.md/plugins/guides/bases-view
   - used for: custom linked/custom view extensibility under host-owned law
