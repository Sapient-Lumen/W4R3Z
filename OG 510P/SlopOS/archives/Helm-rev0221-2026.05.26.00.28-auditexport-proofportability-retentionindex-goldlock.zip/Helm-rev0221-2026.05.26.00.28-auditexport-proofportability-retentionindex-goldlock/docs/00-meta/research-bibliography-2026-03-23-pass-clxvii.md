# Research bibliography — 2026-03-23 — pass CLXVII

| Ref | Source | Used for |
| --- | --- | --- |
| REF-K8S-PODS-OBSERVED-GENERATION-2026E | https://kubernetes.io/docs/concepts/workloads/pods/ | current Pod docs keep `status.observedGeneration` explicit as the generation the reported status reflects |
| REF-K8S-API-OBSERVED-GENERATION-2026E | https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.26/ | controller status objects keep `observedGeneration` explicit across workload APIs |
| REF-K8S-RESIZE-OBSERVED-GENERATION-2026E | https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/ | `observedGeneration` is explicitly described as the latest pod specification the kubelet has acknowledged |
| REF-ELASTIC-INDEX-REFRESH-2026E | https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-index | `refresh=true|wait_for|false` is explicit visibility-to-search control |
| REF-ELASTIC-UPDATE-REFRESH-2026E | https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-update | update operations keep the same search-visibility distinction |
| REF-ELASTIC-BULK-REFRESH-2026E | https://www.elastic.co/docs/api/doc/elasticsearch/operation/operation-bulk | bulk operations explicitly separate write success from search-visible refresh |
| REF-CLOUDFRONT-INVALIDATION-STATUS-2026E | https://docs.aws.amazon.com/cloudfront/latest/APIReference/API_Invalidation.html | invalidation status remains explicit until `Completed` |
| REF-CLOUDFRONT-GET-INVALIDATION-2026E | https://docs.aws.amazon.com/cloudfront/latest/APIReference/API_GetInvalidation.html | downstream cache invalidation completion is a distinct observable state |
| REF-CLOUDFRONT-WAITER-2026E | https://docs.aws.amazon.com/cli/latest/reference/cloudfront/wait/invalidation-completed.html | waiter support reinforces invalidation completion as a first-class frontier |
| REF-GOOGLE-LRO-PROTO-2026E | https://docs.cloud.google.com/datastore/docs/reference/data/rpc/google.longrunning | `done=false` versus `done=true`, with `response` or `error` on completion |
| REF-GOOGLE-LRO-LIVESTREAM-2026E | https://docs.cloud.google.com/livestream/docs/how-to/manage-long-running-operations | official workflow for polling an LRO until `done=true` |
| REF-GOOGLE-LRO-DOTNET-2026E | https://docs.cloud.google.com/dotnet/docs/reference/help/long-running-operations | completed can still be faulted; polling returns fresh state |
