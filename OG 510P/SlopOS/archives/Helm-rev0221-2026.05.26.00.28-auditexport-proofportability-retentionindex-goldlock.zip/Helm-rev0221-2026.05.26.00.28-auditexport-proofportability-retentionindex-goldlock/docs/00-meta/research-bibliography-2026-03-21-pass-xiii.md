# Research bibliography — 2026-03-21 — pass XIII

## Launchers, review surfaces, and typed root search

- Microsoft PowerToys Command Palette overview docs.
- Microsoft PowerToys Command Palette extensibility and extension-toolkit docs.
- Warp command-palette docs.
- Warp workflows docs.
- Warp launch configurations docs.
- Raycast Notes docs and Raycast notes quicklink writeup.

## Recency, source grading, and terminal context cues

- Alfred clipboard-history docs.
- Alfred snippets docs.
- VS Code terminal shell integration docs.
- VS Code 1.103 / 1.106 / 1.108 release notes for sticky scroll, diagnostics, terminal reveal, and shell-history handling.
- Warp agent-modality docs for terminal-block vs agent-conversation separation.

## Live derivative surfaces and overview pressure

- Microsoft PowerToys Crop And Lock docs.
- Microsoft PowerToys overview page.
- GNOME Activities overview and workspace docs.
- Raycast Windows changelog entry for Quick Look.
- Raycast window-layouts changelog entry.

## Reusable automation / fragment pressure

- Node-RED subflows docs.
- Node-RED flow-structure docs.
- Node-RED nodes docs for status and config-node patterns.
- WezTerm launcher-menu docs and changelog notes.
- Warp workflow docs again as reusable command objects.

## Current use in Helm

This pass mainly pressures:
- review strips as tiny cross-pillar preflight surfaces,
- exact-object recency as a stronger Recall direction,
- reusable Flow fragments as a Desktop Flow requirement,
- launch ladders / entry objects as honest saved starting points rather than fake live continuity,
- and stronger pillar wording around exact reveal,
  activation/focus ownership,
  route/source grading,
  and request-vs-live truth
