# Helm: action warrants + drift gates — 2026-03-23

## Headline

Helm should get **better at exact proposed change, not bigger at workflow theater**.
The next compact move worth warming is:

- **action warrants**
- **drift gates**

## Why now

Basis stamps solved one important question:

**what exact basis is this thing talking from?**

But Helm's stronger surfaces still keep needing the next two questions answered cleanly:

- **what exact strong change is being proposed?**
- **does the reviewed basis still bind strongly enough to proceed?**

Without that,
Helm risks two lies:

- an `Apply` button that hides what will really change
- a saved review that quietly survives mutable drift and acts on the wrong thing later

## The good pattern

### Action warrants

An action warrant should carry:
- one exact action subject
- one exact proposed effect
- one exact reviewed basis witness
- one affected-set witness or compact diff-like summary
- one optional context witness when it materially shaped the proposal
- one next-step ladder such as inspect / compare / adjust / apply / hold

### Drift gates

A drift gate should carry:
- one exact warrant reference
- one exact comparison between reviewed basis and current mutable basis
- one typed verdict such as `match`, `drifted`, `partial`, `expired`, or `unknown`
- one compact changed-reason summary
- one downgraded next-step ladder

## What to keep from older inspirations

Keep:
- PR-style proposal-before-merge honesty
- branch-review and compare-before-apply posture
- expected-head / expected-version / compare-and-set guards
- optimistic concurrency and conflict surfacing
- explicit review / approve / apply boundaries

Peel away:
- giant workflow constitutions
- giant team ticket ritual as the price of exactness
- every small interaction becoming ceremony
- silent latest-following after old review
- green confidence badges that replace actual affected-set witness

## Why this makes Helm more awesome

This move makes many warm Helm ideas more serious:

- Omnibox can propose exact strong shell acts instead of flattering quick-action blur
- Object Browser preview can graduate into exact warrant instead of generic apply
- Desktop Flow can hand strong acts off to reviewable shell objects instead of flattening them into scripts
- Exchange can make attach/import/publish acts exact about subject,
  basis,
  and route
- Recall can reopen older strong actions honestly behind drift gates
- Operations Center can show pending,
  drifted,
  held,
  applied,
  and refused strong acts as different states

## Pull-the-trigger judgment

It is wise to warm this now.
Not as a new pillar,
and not as a giant workflow engine,
but as one more compact support proof:
**action warrants + drift gates for exact strong change.**
