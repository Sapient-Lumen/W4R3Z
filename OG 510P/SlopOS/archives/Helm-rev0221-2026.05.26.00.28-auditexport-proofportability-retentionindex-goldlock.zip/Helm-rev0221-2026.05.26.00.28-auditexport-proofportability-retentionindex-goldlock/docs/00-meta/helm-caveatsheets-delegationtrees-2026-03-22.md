# Helm caveat sheets, conditional verdicts, and delegation trees — 2026-03-22

Purpose: identify one more **small shell law** that could make Helm super awesome without adding pillars.

## The shortest answer

Helm should get better at saying:
- **what conditions are attached to this exact power?**
- **what context is still missing before this would work?**
- **what descendants exist below this delegated object, and what dies if I revoke here?**

That suggests three small shell answers:
1. **caveat sheets**
2. **conditional / missing-context verdicts**
3. **delegation subtrees**

## 1. Caveat sheets

A caveat sheet is a shell-owned projection surface over one exact share,
grant,
handle,
recipe,
front door,
or delegated helper object.

It should preserve only the caveats that matter to a human operator.
Not every byte of backend policy.
Not every provider quirk.
Just the bounded conditions that make the object narrower than raw ambient authority.

Good first caveat classes:
- exact subject / cohort only
- lane only
- read-only / preview-only / one-next-act only
- current session / current activity only
- until time X
- while freshness proof remains within horizon
- only if basis still equals Y
- only if route / audience class remains Z
- only if current context fields are present and satisfy the caveat

That would give Helm a much more graceful answer than one scary permissions panel or one fake Allowed badge.

## 2. Conditional verdicts

Helm already has access verdict cards warming.
This pass sharpens their vocabulary.

Some blocked-looking acts are not really denied.
They are **conditional**.
Examples:
- would work if current network matches
- would work if the exact holder is still present
- would work if current lane is isolated
- would work if the review basis is still exact
- would work if freshness is renewed

That is a great shell answer because it can keep:
- denied,
- conditional,
- stale,
- expired,
- restricted,
- unsupported,
- and unknown

visibly different.

The best UI trick here is simple:
show the **missing context fields** or **unsatisfied caveat classes** rather than asking the operator to infer them.

## 3. Delegation trees

Once Helm has attenuated reveal links,
recipes,
renewals,
and delegated helper work,
it needs ancestry honesty.

A delegation tree should let the operator inspect:
- parent object
- child or derived objects
- attenuation delta between each step
- local caveats versus inherited caveats
- whether each node is live,
  historical,
  revoked,
  or unknown
- and whether revoking here kills one node or the whole subtree

This is especially important because many systems become unsafe or confusing precisely when delegated children survive in folklore after the parent is forgotten.

## 4. What to steal from the outside

- **Macaroons** teach that caveats can travel with the credential and constrain when/where/by who/for what purpose.
- **Biscuit** teaches that offline attenuation is real and that parent revoke should have a descendant story.
- **SpiceDB** teaches the brilliant product move of **conditional permission plus missing-context fields**.
- **AWS STS session policies** teach that narrowing should be intersection-only and should never overclaim more than the parent allowed.

## 5. What to steal from the companion cubes

- **SlopOS**: exact mediation, lease discipline, and exact basis binding
- **ViewFS**: caveat chips, witness drawers, freshness separation, explicit attenuation
- **Schell**: trusted chrome and humane rendering of explanation surfaces
- **Steward**: label humility and current-vs-historical honesty

Together they say:
**make caveats visible,
make ancestry visible,
and keep explanation weaker than authority.**

## 6. Moves that could make Helm super awesome

### A. Omnibox caveat preview
Before promoting a strong act,
let summon show a tiny caveat strip:
- exact generation only
- guarded-link only
- expires in 2h
- current cohort only
- stale until revalidated

### B. Exchange subtree inspection
On one share or recipe,
show a small chain:
- original front door
- narrowed guarded link
- narrower receiver-specific relay
- expired child
- live child

### C. Operations subtree revoke
Give revoke three honest choices when the substrate allows it:
- revoke this node
- revoke descendants too
- inspect descendants first

### D. Conditional next-step cards
If a strong act is blocked by missing context,
show the smallest next delta:
- enter isolated lane
- reacquire freshness
- reopen exact handle
- move onto corp network
- switch audience from public to guarded-link

## 7. Pull-the-trigger judgment

This is wise to warm now.
It is still too early to universalize the backend encoding.

So the trigger should be:
- freeze one visible **caveat-sheet** specimen,
- freeze one visible **delegation-subtree** specimen,
- and let access verdict cards learn **conditional / missing-context** posture.
