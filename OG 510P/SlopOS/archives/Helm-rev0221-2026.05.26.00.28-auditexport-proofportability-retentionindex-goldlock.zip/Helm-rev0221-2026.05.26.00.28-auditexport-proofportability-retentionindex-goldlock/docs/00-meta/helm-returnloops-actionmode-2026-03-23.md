# Helm return loops + action mode — 2026-03-23

Purpose: answer the next product question after the recent pillar-ratchet pass:
**what concrete move would make Helm feel much more “super awesome” without forcing too many early architecture decisions?**

## Main call

The next quality jump is not another pillar.
It is one **unbelievably good return loop**.

A strong return loop would let a user:
1. summon from anywhere,
2. orient instantly,
3. jump to one exact landmark or current-live beacon,
4. inspect what changed,
5. act through one typed command surface,
6. and, if needed, branch or delegate without losing track of what is live.

That is a bigger product win than adding another noun family.

## The return loop Helm should aim for

### 1. Summon

Helm should feel unbeatable at instant summon:
- Omnibox,
- exact action keys,
- promoted landmarks,
- exact front doors,
- and maybe one weak Overview summon.

### 2. Orient

A weak Overview landing should answer just enough:
- what is live now,
- what I was doing,
- what is worth returning to,
- what is waiting on me,
- and whether any helper/session work is in flight.

### 3. Jump

The jump targets should feel exact:
- current-live beacon,
- saved view,
- object,
- activity cockpit,
- branch/harbor item,
- session,
- or one promoted landmark.

### 4. Inspect delta

Before strong action, Helm should often offer one weak but exact inspect step:
- object timeline,
- compare from basis,
- glance window,
- or current-vs-remembered contrast.

### 5. Act

This is the biggest fresh trigger.
Helm should admit a stronger **typed action mode inside Omnibox**.
Not a mushy launcher-plus-plugin soup.
A typed shell action surface.

### 6. Branch or delegate without losing reality

When the task should happen in a side lane or helper session,
Helm should make that luxury obvious and safe:
- helper/session roster,
- work claim,
- shadow lane,
- adoption harbor,
- current-live badge nearby.

## What to keep from the old inspirations

### i3
Keep:
- deterministic placement confidence
- obvious focus truth
- keyboard seriousness

Peel away:
- power as austerity theater

### AHK
Keep:
- directness
- desktop-bending joy
- user-shaped acceleration

Peel away:
- hidden ambient mutation
- forgotten macro substrate

### Rofi / launcher culture
Keep:
- instant summon
- fuzzy speed
- one doorway, many intents

Peel away:
- result mush
- untyped actions
- plugin sprawl as architecture

### Dolphin / browser culture
Keep:
- object-first browsing
- exact reveal
- preview before full commitment

Peel away:
- “everything is basically a file” flattening

### task-manager dream
Keep:
- live truth
- resource honesty
- failure visibility

Peel away:
- table worship as the default human interface

## Ideas worth stealing right now

### 1. Typed action mode

The best command systems now combine:
- typed actions,
- hotkeys,
- pinning,
- exact arguments,
- and explicit provider identity.

Helm should steal all of that.

### 2. Promoted landmarks

Bookmarks, quicklinks, pinned commands, front doors, and saved layouts are all versions of the same move:
**take something worth returning to and make it exact, durable, and one jump away.**

### 3. Selection-scoped action

One of the nicest kinds of magic is:
- select one exact thing,
- see what can be done with it,
- and act without opening a whole new application religion.

### 4. Session rosters

If users are going to live with helpers, background agents, delegated tasks, and side lanes, they need an exact roster more than they need more notification spam.

### 5. Saved layout return paths

Workspaces, layouts, linked views, and exact front doors should make re-entry feel luxurious without becoming a giant home-screen ideology.

## Lessons from the past we should keep obeying

1. **recents are weaker than landmarks**
2. **history is weaker than live truth**
3. **background promise is weaker than adopted result**
4. **command convenience should not outrun typed meaning**
5. **landing surfaces should orient, not rule**
6. **preview should stay weaker than promote**

## Pull-the-trigger judgment

What is wise to pull now is not a new pillar.
It is one compact new seam:

**Omnibox action mode**

and one broader product posture:

**Helm should optimize for return loops, not for giant dashboard or giant memory mythology.**
