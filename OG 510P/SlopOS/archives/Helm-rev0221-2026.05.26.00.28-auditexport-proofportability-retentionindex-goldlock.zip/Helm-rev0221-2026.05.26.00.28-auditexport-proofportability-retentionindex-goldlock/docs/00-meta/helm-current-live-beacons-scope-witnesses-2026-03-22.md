# Helm current-live beacons and scope witnesses — 2026-03-22

Purpose: name the next compact support move that now looks worth defining without adding a pillar.

## Main idea

Helm likely wants two small cooperating shell objects:

- **current-live beacon**
- **activity scope witness**

The beacon answers:
**what is actually live now?**

The witness answers:
**in what scope is that claim true, and what nearby context stayed out?**

## Why this matters now

Helm already has enough saved/grouped structure to become genuinely powerful:

- saved view objects
- checkpoint branches
- review tickets
- activity spines
- resource shelves
- activity entry kits / front doors

That is good.
But it creates a new risk.

If Helm does not name a stronger current-live object and a stronger scope witness,
then:
- entry kits start flattering themselves into live sessions
- spines start flattering themselves into current activity
- shelves start flattering themselves into current work
- recents start flattering themselves into Recall authority
- imported/shared starters start flattering themselves into local sameness

## What to keep

### 1. One current-live beacon should stay stronger than every saved/grouped shell object

A current-live beacon should beat:
- recent/opened history
- a front door / entry kit
- a saved view
- a checkpoint
- a resource shelf
- a review ticket
- even an activity spine

The spine may host the beacon.
It should not replace it.

### 2. The beacon should be exact when Helm really knows

Good first beacon states likely include:

- exact live
- live but widened
- historical relation only
- imported/shared weaker relation
- unknown / unavailable

The shell should not fake exactness.

### 3. Scope witness should ride on meaningful continuity claims

A scope witness does not need to appear everywhere.
It matters when Helm is saying:
- this is the same activity
- this restore/attach/reuse path is still the right one
- this current-live beacon still belongs to this scoped work frame
- this saved starter still points into the same scoped context

### 4. Scope witness should say both what counted and what did not count

The witness should not just say “work profile”.
It should also be able to say what stayed out:
- adjacent browser profile
- neighboring project
- nearby remote
- visible but unrelated workspace
- sibling grouped resources
- imported context not yet adopted

### 5. Beacon and witness should cooperate with recall/open/materialize laws

Current-live beacons help Recall stay stronger than recents.
Scope witnesses help reuse/restore/attach stay honest.
Together they support the older law that generic open stays weak.

## What not to keep

### 1. No giant currentness dashboard
This should not become a second Operations Center.

### 2. No ambient profile/session glow
Nearby context should not silently count.

### 3. No fake cross-device resume promises
A saved or shared object may point toward continuity,
but that is not identical to live currentness.

### 4. No forced witness chrome everywhere
Only stronger continuity claims need the witness.

## Why this can make Helm super awesome

Because it upgrades the whole shell at once.

### Omnibox
Results can say:
- this opens a saved starter
- this points to the current live lane
- this is only historical
- this is current but widened

### Recall
Recall gains one obvious stronger answer than “recently opened”.

### Object Browser
Saved views and grouped resources can sit next to a live beacon instead of pretending to be the lane.

### Exchange
Current-subthing versus all-grouped-things choice becomes more honest.

### Desktop Flow
Flows can target beacons and witnesses instead of vague session folklore.

### Operations Center
Ops can stay the place for broad live honesty,
while the beacon stays the compact answer for one activity.

## Pull-the-trigger judgment

Still yes:
- saved view objects
- checkpoint branches

Also now worth defining or refreshing soon:
- **current-live beacon**
- **activity scope witness**

That looks like the next real leverage point.
