# Helm: watchpoints + state honesty — 2026-03-22

Purpose: name the next compact support move that now looks worth warming after the latest SlopOS reread and current-tool pass.

## Main idea

Helm now has:
- saved view objects,
- linked views,
- exact front-door handles,
- view subscriptions,
- glance derivations,
- drift beacons,
- basis contrast cards,
- and a weak Overview direction.

What is still missing is one shell-owned object for **durable evaluated state**.

The right answer now looks like:
- keep the **saved view** as the durable exact source,
- let it optionally source one explicit **watchpoint**,
- let the watchpoint carry current evaluation state plus delivery posture,
- let a tiny watch card or glance represent that state in Overview or Operations,
- and keep stronger inspection routed back to the exact source view and the watchpoint details.

## 1. What a watchpoint is

A **watchpoint** is a shell-owned evaluated-state object bound to one exact saved view and one declared evaluation law.

It is stronger than a mere glance card because it owns durable state such as:
- current evaluation verdict
- last successful evaluation
- last state transition
- degraded / stale / flapping posture
- delivery posture such as muted, snoozed, or active

It is weaker than live authority because it still depends on the source view,
its basis,
and its freshness/evaluation posture.

## 2. Why this now looks necessary

A **subscription** is primarily about delivery.
A **glance derivation** is primarily about compact summary.
But Helm still needed a clean object for:
- “this thing is being watched”
- “this is its current evaluated state”
- “delivery is muted, but evaluation is still running”
- “the source view drifted, so this watchpoint needs review”

That is a real product gap.
Watchpoints fill it without forcing Helm into giant observability or incident-management culture.

## 3. What current tools taught this pass

The outside pattern is now specific enough to steal:
- Grafana links alert rules to panels but explicitly warns when the source query and the alert query are no longer synchronized.
- Grafana and Kibana both distinguish suppressed notifications from continued evaluation.
- Kibana exposes rule health and flapping-like state instead of pretending every rule is just green or red.
- Datadog's query-value pattern shows that a tiny status card can be useful when it is narrow and unambiguous.
- Grafana library panels show the value of visible “where is this reused?” posture for derivative/reusable status surfaces.

## 4. What Helm should keep and reject

### Keep
- exact saved views as the durable source objects
- explicit evaluation law for durable watch state
- muted-versus-disabled honesty
- tiny status cards derived from stronger source truth
- visible source drift and refresh posture
- source-open / inspect-watchpoint paths next to any tiny watch card

### Reject
- giant alerting constitutions
- notification history as the durable watch ledger
- hidden sync between a source view and a copied watch law
- muted delivery pretending to mean recovery
- provider-owned daemon folklore hidden under shell chrome

## 5. What now looks wise to pull the trigger on

### Pull the trigger now
- **watchpoints** as candidate shell objects

### Advance with them
- explicit **muted / snoozed / disabled / degraded** posture in Operations and Overview
- **source-drift** posture between a watchpoint and its source view

### Keep warm
- usage-witness / where-used surfaces for reused watch cards and linked derivative surfaces
- digest delivery paths that summarize watchpoint changes without replacing watchpoint truth

## 6. Why this could make Helm super awesome

This move makes Helm feel both more alive and more trustworthy.

A user could:
- keep a triage view under watch,
- see a tiny warning card in Overview,
- see that evaluation is still running even though delivery is muted,
- see that the watchpoint is flapping or stale,
- and jump straight back to the exact source view or watchpoint details.

That is a much better feeling than either:
- giant dashboard sprawl,
- or one vanished notification that leaves no durable state behind.

## Judgment

Helm still does not need another pillar.
It needs one more compact shell object.

The best next move now looks like:
- **watchpoints**
- plus **state honesty** around evaluate / mute / snooze / disable / drift

That makes Helm's datacube more useful,
more inspectable,
and more humane without turning it into a hidden monitoring daemon or a fake universal command center.
