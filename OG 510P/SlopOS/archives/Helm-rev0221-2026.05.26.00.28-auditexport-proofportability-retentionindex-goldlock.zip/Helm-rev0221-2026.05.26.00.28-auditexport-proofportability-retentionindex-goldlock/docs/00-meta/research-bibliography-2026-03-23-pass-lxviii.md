# Research bibliography — 2026-03-23 — pass LXVIII

## Sources consulted for this pass

1. Figma Help Center — Guide to branching
   - branches are controlled environments for exploring changes without editing the original file
   - branches can be submitted for review and merged once approved
2. Google Docs Help — Suggest edits in Google Docs
   - suggestions change the document without changing the original text until the owner approves
   - the document can be previewed with suggestions accepted or rejected
3. Google Docs API — Work with suggestions
   - suggestions are effectively deferred edits waiting for approval
   - `SuggestionsViewMode` supports inline and preview representations
4. GitHub Docs — About pull requests
   - pull requests are proposals to merge changes into a project
   - draft pull requests cannot be merged and do not automatically request code owner review
5. Git documentation — `git worktree`
   - one repository can support multiple linked working trees at the same time
6. GitHub Docs — About GitHub Copilot coding agent
   - the agent works autonomously in a GitHub Actions-powered environment and creates pull requests with results
   - draft pull requests created by the agent must be reviewed and merged by a human
   - the agent cannot mark its pull requests ready for review, approve them, or merge them
   - by default workflows do not run until a human approves and runs them
7. GitHub Docs — Managing coding agents
   - agent sessions can be initiated, monitored, and managed from explicit session surfaces
8. GitHub Docs — Reviewing a pull request created by GitHub Copilot
   - privileged workflows are held behind explicit approve-and-run posture by default
