# Helm retreat witnesses + refuge cards — 2026-03-23

## Why this pass happened

After **remainder witnesses** and **residue ledgers**,
Helm could explain what exact smaller slice remains
and what exact local residue did not travel.
But it still lacked one humane operator answer:

**when the system retreats, what kind of retreat happened, to what exact footing, and what did not come back with it?**

That gap appears across:
- rollout abort versus full authored revert
- rollback to a previous revision versus fast-tracked temporary shelter
- restore of historical content versus erasure of later history
- kill-switch shutoff versus full dependent-system rollback
- revert-as-new-act versus hidden deletion mythology

## Product judgment

The next narrow trigger is now worth pulling:

- keep the seven pillars stable
- do not add a new pillar
- promote **retreat witnesses** as the shell-owned compact answer to `what exact retreat posture is active now?`
- promote **refuge cards** as the tiny nearby rendering for that retreat truth

A retreat witness answers:
- what retreat family happened
- what exact footing or prior revision is serving now
- whether the retreat is temporary shelter, authored revert, historical restore, or kill-switch disablement
- what forward-pointing authored/live truth still remains
- what dependent or local residue did **not** come back with the retreat
- what follow-on act is still needed to make the retreat complete or durable

A refuge card answers that truth in one small human-facing form.

## Why this is worth stealing

The current official pressure is unusually crisp:

- `kubectl rollout undo` can roll back to the previous rollout or to a specific revision
- Argo Rollouts `abort` makes the previous ReplicaSet active but leaves `spec.template` on the new version until a fuller revert happens
- Argo rollback windows fast-track rollback within a recent revision window instead of replaying every step
- GitHub revert creates a new pull request instead of erasing prior history
- Figma restore adds fresh checkpoints and keeps later comments rather than pretending history vanished
- LaunchDarkly kill switch flags shut off functionality quickly, while guarded-rollout rollback does **not** automatically roll back dependent flags

All of those systems feel more humane because they distinguish **retreat class** from one flattering universal `rolled back` story.

## Lessons Helm must learn from the past

- `rolled back` is too flattering if the system cannot say **to what exact footing**.
- `restored` is too flattering if later comments, history, or dependent state still remain.
- `aborted` is too flattering if authored/live forward pointers still target the newer version.
- `kill switch active` is not the same thing as `all dependent effects reverted`.
- the right shell magic is not hiding retreat complexity; it is making retreat class and leftover forward residue obvious at a glance.

## What Helm should keep

Keep:
- reversal warrants
- repair ladders
- remainder witnesses
- residue ledgers
- current-live beacons
- reality strips
- Overview / Recall / Operations Center as weak projection surfaces

Add more clearly:
- **retreat witnesses** near reversal warrants, repair ladders, and current-live beacons
- **refuge cards** near reality strips, Overview tiles, Recall return points, and Operations Center rows

## What Helm should refuse

Do not:
- build a universal rollback orchestrator
- flatten abort, rollback, revert, restore, and kill-switch into one badge
- let temporary shelter impersonate durable authored retreat
- silently imply that dependents or comments/history also returned when they did not
- erase historical acts just because a retreat happened later

## Practical effect on Helm surfaces

A good compact Helm surface should increasingly be able to say:
- `traffic retreated to stable rs • authored template still new`
- `rollback window hit • steps skipped • revision 42 serving`
- `revert PR open • merged history preserved`
- `restored v128 • later comments retained`
- `kill switch on • dependent flags unchanged`

That is a better next move than another pillar,
another dashboard plane,
or another mushy `rolled back` story.
