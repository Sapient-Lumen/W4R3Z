# SlopOS + companions evaluation — 2026-03-23 pass CXLVI

## Why this pass happened

The last Helm revision made the strongest adjacent cluster explicit:
**epoch stamps, stale-fence strips, reset witnesses, and maybe later reconsent rails or delegation freezes.**

This pass asked the next nearby question:
**once Helm can say what exact footing older trust bound to, and whether it still binds, how should it say what changed since that footing without collapsing into giant timeline or recap folklore?**

The companion cubes still say the same big thing:
- freeze laws before giant centers,
- keep shell-owned truth stronger than explanation,
- and do not let design-phase convenience harden into fake continuity.

## What SlopOS still teaches best

### 1) Explicit compared footing beats vague recency
SlopOS's datacube remains strongest as a discipline engine.
Its most useful lesson here is not `show more history`.
It is `keep compared footing explicit and bounded`.
A datacube answer should increasingly be able to say what exact view,
materialization,
or reviewed boundary it is comparing from.
That is a direct teacher for Helm delta briefs.

### 2) Recency and assurance boundaries still matter more than recap glow
SlopOS also keeps pushing the same humility:
current assurance is bound to exact current conditions.
History is useful,
but it does not become current merely because it is nearby.
That means any Helm change brief should stay weaker than current-live proof and weaker than the exact reviewed footing it compares.

## What ViewFS now teaches best

### 1) Basis / drift / reconsent gives Helm the right internal grammar
ViewFS is still one of the clearest local teachers for this pass.
Its basis-record,
drift-check,
and reconsent split says that the shell should compare exact footing,
not vague `before` and `after` folklore.
That makes ViewFS a direct teacher for delta briefs,
since cards,
and later review windows.

### 2) Delta truth is smaller than reconsent truth
ViewFS also keeps the crucial distinction alive:
knowing what changed is not the same as deciding renewed authority.
That is exactly right for Helm.
A delta brief should open re-review,
not impersonate it.

## What Steward now teaches best

Steward's readiness-generation posture keeps pressing the same lesson:
desired and observed stay visibly different.
That matters here because a good change brief should be able to say not only that something changed,
but also whether the visible status still belongs to the prior observed footing.
Without that,
change briefs risk becoming flattering recaps.

## What Ward now teaches best

Ward is still the best local teacher for distrust that ages rather than erases history.
Its root epochs,
threshold resets,
and delegation freezes keep saying the same thing:
old truth can remain inspectable without remaining spendable.
That makes Ward a direct teacher for review windows.
A later Helm review window should compare against the exact footing that the human or watch really signed off on,
not just any earlier recognizable state.

## What Harbor now teaches best

Harbor's risk ladders are unexpectedly useful here.
They suggest that not every change belongs in one compact answer.
A small change brief increasingly wants one **salience lens**:
what counts as material under the current decision or exposure class?
That is a much healthier next step than one universal severity score.

## What Foundry now teaches best

Foundry's lazy hydration,
prefetch witness,
and cold-read debt work is a beautiful reminder that partial inspection should confess itself.
A Helm change brief may sometimes compare two footings without covering every cold path,
foreign dependency,
or unhydrated region.
That means a good brief increasingly wants one coverage note or blindspot rail instead of bluffing completeness.

## Lessons Helm must learn from the past

### Must learn #1: `updated` is not an answer
If the shell can say what exact footing trust bound to,
it should increasingly also say what changed since that footing.
A timestamp or generic `updated` label is too weak.

### Must learn #2: compared change and renewed authority are different truths
A delta brief is smaller than reconsent,
re-review,
or renewed action-fit.
Helm should keep those truths separate.

### Must learn #3: quiet can be strong if coverage is explicit
`No qualifying change` is a real answer,
but only when the shell says what bases,
what lens,
and what blindspots were involved.

### Must learn #4: significance should be chosen locally
A change that matters for `act now` may not matter for `brief only`.
Harbor's risk-ladder lesson should keep Helm from flattening all salience into one global importance badge.

## Current Helm judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Do not change that.

But the next adjacent cluster worth warming now looks like:
- **delta briefs** bound to exact footing
- **since cards** as the humane tiny rendering
- **salience lenses** for what counted in the compact answer
- **quiet witnesses** for strong no-change posture
- and maybe later **review windows** or **recheck windows** where Helm wants one exact answer to what changed since a human or watch actually bound trust to the slice

That cluster feels unusually well-supported by SlopOS,
ViewFS,
Steward,
Ward,
Harbor,
and Foundry all at once.
