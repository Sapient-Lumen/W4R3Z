# Research bibliography — 2026-03-23 — pass LXXII

1. Notion API — Create a view query
   - URL: https://developers.notion.com/reference/create-view-query
   - why useful: validates explicit cached result slices with `query_id`, `expires_at`, and short-lived saved query posture

2. TanStack Query docs — Important defaults
   - URL: https://tanstack.com/query/v5/docs/framework/react/guides/important-defaults
   - why useful: validates explicit freshness windows (`staleTime`) and separate background refetch triggers

3. RFC 5861 — HTTP Cache-Control Extensions for Stale Content
   - URL: https://datatracker.ietf.org/doc/html/rfc5861
   - why useful: validates named stale fallback classes such as `stale-while-revalidate` and `stale-if-error`

4. Chrome / Workbox docs — Caching resources during runtime
   - URL: https://developer.chrome.com/docs/workbox/caching-resources-during-runtime
   - why useful: validates practical stale-while-revalidate and network-first product posture

5. Vercel docs — Data Cache for Next.js
   - URL: https://vercel.com/docs/caching/runtime-cache/data-cache
   - why useful: validates time-based, on-demand, and tag-based revalidation as separate rails

6. Vercel changelog — Caching details now available in Runtime Logs
   - URL: https://vercel.com/changelog/caching-details-now-available-in-runtime-logs
   - why useful: validates visible revalidation reasons instead of opaque background refresh

7. Grafana docs — Data source management / query caching
   - URL: https://grafana.com/docs/grafana/latest/administration/data-source-management/
   - why useful: validates surface-shaped freshness budgets tied to panel interval and query range

8. Microsoft Learn — Data refresh in Power BI
   - URL: https://learn.microsoft.com/en-us/power-bi/connect-data/refresh-data
   - why useful: validates tile refresh as a scheduled snapshot lane distinct from more live data modes

9. GitHub Docs — About protected branches
   - URL: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
   - why useful: validates stale reliance downgrade when the reviewed diff changes
