# Helm settlement packets and closure ledgers — 2026-05-15

rev0194 moves one step beyond commit capsules.

## Thesis

Helm should make closure trustworthy by making it weaker than approval by default.

A settlement packet is the small object that says:

- what capsule closed;
- what source receipts were present;
- what finalizer keys were cleared or remain open;
- what event crumb was emitted;
- what local artifact became durable;
- what tombstone or supersession rule applies;
- what the packet is **not** authority for.

## Pull the trigger

Admit settlement packets / closure ledgers as checked fixture objects.

## Do not pull the trigger

Do not choose an event bus, approval engine, deployment engine, workflow runtime, policy engine, authorization language, global attestation store, canonical backend, semantic layer, table format, distributed transaction model, CRDT/sync ontology, or new pillar.

## Why this is a Helm move

Helm is a shell/compositor. Its premium move is not to become the database of record. Its premium move is to stop a user from mistaking a refusal receipt, quarantine branch, history pin, or review cut for release approval.

## Product delight

One honest line beats a giant audit panel:

`Settled as refusal history • release-view@12 ≠ @13 • not approval • fresh review opened`

That line is simultaneously humane and strict.
