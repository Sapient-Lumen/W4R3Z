# Research bibliography — 2026-05-15 pass CLXXXV

This pass supports Helm rev0192: consequence envelopes, rehearsal sheets, affected sets, blast radius, receipt plans, and retreat paths.

| ID | Source | Why it matters for Helm |
|---|---|---|
| WEB-CLXXXV-DBT-SAVED-QUERIES | dbt Docs, Saved queries, https://docs.getdbt.com/docs/build/saved-queries | Saved query reuse pressures Helm to keep definition identity visible. |
| WEB-CLXXXV-DBT-EXPORTS | dbt Docs, Write queries with exports, https://docs.getdbt.com/docs/use-dbt-semantic-layer/exports | Exports/materialization pressure Helm to distinguish reusable output from live truth. |
| WEB-CLXXXV-DAGSTER-FRESHNESS | Dagster Docs, Asset freshness policies, https://docs.dagster.io/guides/observe/asset-freshness-policies | Fresh/overdue health posture supports visible recheck gates. |
| WEB-CLXXXV-DAGSTER-CHECKS | Dagster Docs, Asset checks, https://docs.dagster.io/guides/test/asset-checks | Checks inspire simple per-property gates before consequence. |
| WEB-CLXXXV-ICEBERG-BRANCHING | Apache Iceberg, Branching and Tagging, https://iceberg.apache.org/docs/latest/branching/ | Named references to snapshots support frozen review cuts. |
| WEB-CLXXXV-LAKEFS-HOOKS | lakeFS Docs, Actions and Hooks, https://docs.lakefs.io/v1.60/howto/hooks/ | Pre-merge hooks inspire pre-consequence rehearsals. |
| WEB-CLXXXV-GITHUB-MERGE-QUEUE | GitHub Docs, Managing a merge queue, https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | Required checks on latest target-plus-queue reinforce recheck-before-promote. |
| WEB-CLXXXV-OPA-DECISION-LOGS | Open Policy Agent Docs, Decision Logs, https://openpolicyagent.org/docs/management-decision-logs | Decision logs inspire compact decision/audit crumbs without choosing a policy engine. |
| WEB-CLXXXV-OPENFEATURE-CONTEXT | OpenFeature Spec, Evaluation Context, https://openfeature.dev/specification/sections/evaluation-context | Evaluation context pressures Helm to carry consequence inputs explicitly. |
| WEB-CLXXXV-OPENFEATURE-HOOKS | OpenFeature Spec, Hooks, https://openfeature.dev/specification/sections/hooks | Lifecycle hooks inspire pre/after/error/finally thinking around product verbs. |
| WEB-CLXXXV-ARGO-ANALYSIS | Argo Rollouts Docs, Analysis, https://argo-rollouts.readthedocs.io/en/stable/features/analysis/ | Analysis templates inspire explicit success/failure criteria before wider exposure. |
| WEB-CLXXXV-FLAGGER-METRICS | Flagger Docs, Metrics Analysis, https://docs.flagger.app/usage/metrics | Canary metrics inspire gradual exposure with measurable gates. |
| WEB-CLXXXV-OPENLINEAGE-FACETS | OpenLineage, Facets & Extensibility, https://openlineage.io/docs/spec/facets/ | Atomic facets support compact evidence packets. |
| WEB-CLXXXV-OTEL-BAGGAGE | OpenTelemetry, Baggage, https://opentelemetry.io/docs/concepts/signals/baggage/ | Context propagation supports small carried consequence context, not authority. |
| WEB-CLXXXV-INTOTO-ATTESTATION | in-toto Attestation Framework, https://github.com/in-toto/attestation/blob/main/docs/README.md | Subject-bound attestations inspire receipts that are durable but not automatic approvals. |
