# Research bibliography — 2026-03-23 pass CL

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GITHUB-ENVIRONMENTS-2026I | https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments | GitHub environments contribute required reviewers plus an explicit wait timer for sharper actions. |
| REF-PAGERDUTY-INCIDENTS-2026I | https://support.pagerduty.com/main/docs/incidents | PagerDuty incidents make acknowledgement-versus-resolution explicit and say acknowledgement timeout returns the incident to triggered and resumes escalation. |
| REF-PAGERDUTY-CONFIG-SERVICE-2026I | https://support.pagerduty.com/main/docs/configurable-service-settings | PagerDuty service settings contribute acknowledgement-timeout posture and current-on-call re-notify behavior. |
| REF-PAGERDUTY-ESCALATION-2026I | https://support.pagerduty.com/main/docs/escalation-policies | PagerDuty escalation policies contribute explicit escalation timeout windows. |
| REF-PAGERDUTY-MAINTENANCE-2026I | https://support.pagerduty.com/main/docs/maintenance-windows | PagerDuty maintenance windows contribute a temporary-disable posture with explicit time bounds. |
| REF-GRAFANA-MUTE-TIMINGS-2026I | https://grafana.com/docs/grafana/latest/alerting/configure-notifications/mute-timings/ | Grafana keeps mute timings / silences distinct and explicitly says they suppress notifications without stopping evaluation. |
| REF-GRAFANA-FUNDAMENTALS-2026I | https://grafana.com/docs/grafana/latest/alerting/fundamentals/ | Grafana fundamentals contribute the one-time silence versus recurring mute-timing distinction. |
| REF-DATADOG-DOWNTIMES-2026I | https://docs.datadoghq.com/monitors/downtimes/ | Datadog downtimes contribute scoped scheduled mute posture, recurrence, and exact affected-target previews. |
| REF-LINEAR-TRIAGE-2026I | https://linear.app/docs/triage | Linear triage contributes snooze-until-time or until-new-activity return posture. |
| REF-LINEAR-INBOX-2026I | https://linear.app/docs/inbox | Linear inbox contributes reappearance as new/unread after snooze expiry or intervening activity. |
| REF-JSM-SLA-CONDITIONS-2026I | https://support.atlassian.com/jira-service-management-cloud/docs/set-up-sla-conditions/ | Jira Service Management contributes explicit start / pause / stop timer conditions. |
| REF-JSM-SLA-VIEW-2026I | https://support.atlassian.com/jira-service-management-cloud/docs/what-are-slas-and-how-do-i-view-them-in-my-service-project/ | Jira Service Management contributes visible paused-versus-running-versus-breached SLA posture. |
