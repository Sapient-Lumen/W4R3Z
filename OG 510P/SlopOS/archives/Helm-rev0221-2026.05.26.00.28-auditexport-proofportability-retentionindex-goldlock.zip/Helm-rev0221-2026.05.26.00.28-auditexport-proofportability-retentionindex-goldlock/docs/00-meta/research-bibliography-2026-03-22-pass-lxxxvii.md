# Research bibliography — 2026-03-22 — pass LXXXVII

Used in this pass.

1. W3C — Permissions specification
   - URL: https://www.w3.org/TR/permissions/
   - used for: the rule that permission to use powerful features is generally given and controlled through browser UI

2. Chrome for Developers — One-time permissions in Chrome
   - URL: https://developer.chrome.com/blog/one-time-permissions
   - used for: explicit temporary-versus-persistent permission choices and site-controls posture

3. VS Code docs — Workspace Trust / Restricted Mode
   - URL: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
   - used for: restricted-but-browseable posture, visible banner/badge/overlay review surfaces, and disabling execution-rich features until trust is granted

4. Android Developers — Request runtime permissions
   - URL: https://developer.android.com/training/permissions/requesting
   - used for: tying permission requests to specific user actions, removing permission access, and keeping permission posture user-legible

5. Android Developers — Grant partial access to photos and videos
   - URL: https://developer.android.com/about/versions/14/changes/partial-photo-video-access
   - used for: selected-scope access, temporary media grants, and not assuming full-library access
