# SlopOS companions evaluation — 2026-03-23 pass CLI

## Purpose

Continue mining **SlopOS**, **Harbor**, **Ward**, **Foundry**, **ViewFS**, **Steward**, and **Schell**
after the turn-clock / escalation-rail pass by asking one tighter question:

**once Helm can say who should act and under what kind of clock,**
**how should it say that movement is happening under an explicit exception without laundering that exception into fake compliance, fake calm, or fake completion?**

## 1. SlopOS keeps teaching that recency, assurance, and boundary truth should not be laundered through convenience

Recent SlopOS recency / assurance work still reinforces the broad law Helm needs:
strong-looking status should not outrank exact footing,
and convenience should not quietly become stronger truth.
That matters here because an exception should not silently repaint a slice as ordinary green.

**Take for Helm:**
exception posture must stay weaker than the requirement it interrupts.

## 2. Harbor is the strongest local teacher for bounded detours and resettable temporary posture

Harbor keeps emphasizing detour leases,
route reset cards,
and the separation among prepared request,
returned proof,
and durable adoption.
That is a near-perfect teacher for Helm.
A waiver should often behave like a lease:
- explicitly begun,
- explicitly ending,
- restartable or resettable,
- and never mistaken for durable satisfied state.

**Take for Helm:**
make temporary exception posture lease-shaped instead of sticky folklore.

## 3. Ward keeps teaching that later facts can impose local holds without magically rewriting remote truth

Ward's local-hold,
root-epoch,
and threshold-reset pressure remains useful.
A later fact can narrow or freeze what the local side is willing to do,
but it does not thereby convert every upstream claim into local law.
That supports Helm's exception posture strongly.
A local maintenance hold,
watch suppression,
or action fence should stay shell-owned and inspectable.

**Take for Helm:**
local exception truth should stay local,
visible,
and exact about what it narrows.

## 4. Foundry keeps teaching overlay gates and confext checks instead of one universal clean-state story

Foundry's latest confext-check / config-layer / overlay-gate work pushes exactly the right kind of humility.
A system can keep moving with overlays,
checks,
and compatibility gates in play,
but that does not mean everything is now universally clean.
That is useful pressure for Helm because bypass,
override,
and maintenance should remain visibly narrower than normal cleared posture.

**Take for Helm:**
an exception should name what gate remains unsatisfied,
not disappear into a global “allowed” bit.

## 5. ViewFS keeps teaching basis, drift, and reconsent separation

ViewFS keeps repeating the useful law that changed footing can reopen stronger review without invalidating every weaker truth.
That matters here because a waiver lease should bind to exact footing,
exact target set,
and exact change class.
If the footing changes,
Helm should be willing to narrow,
expire,
or recheck the exception.

**Take for Helm:**
exceptions should be footing-bound,
not free-floating labels.

## 6. Steward keeps teaching renewal-window and retry-advice humility

Steward's renewal / countdown posture keeps another nearby truth sharp:
a missed renewal,
a wait-until,
and a retry-not-before hint are already different clocks.
That means Helm should not let waiver leases collapse back into generic timers.
Some exception clocks quiet attention,
some delay stronger action,
some merely schedule a recheck.

**Take for Helm:**
exception timing should stay typed,
not just “expires at.”

## 7. Schell keeps teaching review-again and outcome-lane separation

Schell remains a good reminder that changed footing,
new edits,
and renewed review pressure should not be hidden inside stale glow.
That supports a useful next move for Helm:
when an exception expires,
reopens,
or is rescinded,
operators should see the stronger inspect / re-review / recheck path immediately.

**Take for Helm:**
exception expiry should point to the next honest lane,
not just vanish.

## Product judgment

The admitted next shell-wide ratchet is still **settlement witnesses + commit cards**.
That remains the right decision.

But the next adjacent cluster now looks worth naming explicitly:
- **exception witnesses**
- **waiver leases**
- and maybe later **breakglass beacons**

Those objects would let Helm say something much better than:
`override active.`

They could say:
- this exact requirement is not fully satisfied,
- this exact exception class is allowing motion anyway,
- this exact scope is covered,
- this exact lease ends at 22:00,
- evaluation remains live underneath,
- and expiry reopens review / wakes notifications / fences strong action instead of pretending nothing happened.

## Laws Helm should keep learning from the past

1. **Bypass is not satisfaction.**
2. **Mute is not calm.**
3. **Pause is not completion.**
4. **Maintenance is not health.**
5. **Observed foreign exception is not local reliance by default.**
6. **Every exception should bind to an exact requirement, footing, and scope.**
7. **Expiry should leave residue and a next-lane truth, not a memory hole.**

## Best bounded take now

Warm **exception witnesses** and **waiver leases** beside turn clocks,
attention turns,
and coverage posture.
Keep them tiny.
Keep them typed.
Keep them footing-bound.
Keep `bypass`,
`maintenance`,
`silence`,
`pause`,
`inhibition`,
`transient-auto-pause`,
and later `break glass`
visibly separate.
