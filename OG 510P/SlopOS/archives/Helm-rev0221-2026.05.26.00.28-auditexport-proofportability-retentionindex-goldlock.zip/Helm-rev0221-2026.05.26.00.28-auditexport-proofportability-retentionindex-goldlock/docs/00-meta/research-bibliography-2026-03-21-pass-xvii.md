# Research bibliography — 2026-03-21 pass XVII

Official/public sources consulted in this pass:

- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — Adding Dock support to your extension  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Apple Support — Take actions and shortcuts in Spotlight on Mac  
  https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac
- Apple Support — Search for anything with Spotlight on Mac  
  https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- VS Code Docs — User interface / Timeline view  
  https://code.visualstudio.com/docs/getstarted/userinterface
- VS Code Docs — Code Navigation / Breadcrumbs  
  https://code.visualstudio.com/docs/editing/editingevolved
- VS Code Docs — Using agents in Visual Studio Code  
  https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code Docs — Profiles in Visual Studio Code  
  https://code.visualstudio.com/docs/configure/profiles
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- VS Code Docs — Use Agent Skills in VS Code  
  https://code.visualstudio.com/docs/copilot/customization/agent-skills
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Clipboard History  
  https://manual.raycast.com/windows/clipboard-history
- Raycast Manual — Dynamic Placeholders  
  https://manual.raycast.com/dynamic-placeholders
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Docs — Workflows  
  https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
- WezTerm Docs — Workspaces / Sessions  
  https://wezterm.org/recipes/workspaces.html
- Arc Help Center — Spaces: Distinct Browsing Areas  
  https://resources.arc.net/hc/en-us/articles/19228064149143-Spaces-Distinct-Browsing-Areas
- Arc Help Center — Split View: View Multiple Tabs at Once  
  https://resources.arc.net/hc/en-us/articles/19335393146775-Split-View-View-Multiple-Tabs-at-Once
- Obsidian Help — Workspaces  
  https://obsidian.md/help/plugins/workspaces
- Obsidian Help — How Obsidian stores data  
  https://obsidian.md/help/data-storage
