# Research bibliography — 2026-03-23 — pass CLXI

## Current official product docs reviewed in this pass

- GitHub Docs — Managing a merge queue
- GitHub Docs — Creating rulesets for a repository
- GitHub Docs — Events that trigger workflows (`merge_group`)
- GitHub Docs — Re-running workflows and jobs
- LaunchDarkly Docs — Testing changes to flag targeting
- LaunchDarkly Docs — Guarded rollouts
- AWS Step Functions — Restarting state machine executions with redrive
- Google Cloud Docs — Long-running operations (Vertex AI)
- OPA Docs — Decision Logs
- Grafana Investigations App docs
- Grafana Investigations — Time Range Compare
- Honeycomb Docs — Board Templates
- Datadog Docs — Notebooks
- Datadog Docs — Version History for Notebooks
- Obsidian Help — Bases
- Argo CD Docs — Diff Strategies / Server-Side Diff
- Kubernetes Docs — Server-Side Apply

## Main current takes captured from those sources

- Good systems keep grouped landing,
  exact continuation,
  exact remainder,
  and rerun/redrive choices close to the same story.
- Good workspaces offer multiple views over one bounded footing instead of one giant center.
- Good post-act surfaces preserve version / clone / restore lineage rather than overwriting history.
- Good compare surfaces can reopen the same bounded items across later time windows.

## Local companion surfaces reopened in parallel

- SlopOS approval-basis / precondition / witness posture docs
- Schell proposal / review / run / later-outcome separation surfaces
- ViewFS apply / snapshot / adoption / receipt separation surfaces
- Harbor route / aftermath separation surfaces
- Ward revalidation / staleness / fence surfaces
- Steward typed pressure and bounded recovery surfaces
- Foundry runtime-evidence humility surfaces
- Helm rehearsal,
  landing,
  continuation,
  remainder,
  repair,
  settlement,
  and calibration candidate docs

## Product sentence this pass supports

Helm should complement rehearsal decks and landing trains with one bounded **aftermath deck** and nearby **recovery map**,
so serious stronger acts can be reopened,
compared,
repaired,
and later calibrated without collapsing into a giant workflow center.
