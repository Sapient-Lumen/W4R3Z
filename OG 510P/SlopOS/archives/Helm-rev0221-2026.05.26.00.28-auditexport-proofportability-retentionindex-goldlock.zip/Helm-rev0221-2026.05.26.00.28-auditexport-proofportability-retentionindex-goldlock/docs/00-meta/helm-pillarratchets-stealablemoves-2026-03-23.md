# Helm pillar ratchets + stealable moves — 2026-03-23

Purpose: answer the wider product question after another outside pass and another re-read of the companion cubes:
**what should Helm keep, what should it peel away, what lessons from the past are non-negotiable, and which next moves would make the product feel unmistakably great?**

## Short answer

Keep the seven pillars.
Do not add a new pillar.
Do not freeze giant cross-pillar machinery yet.

But do get more decisive about the product-shaped ratchets around them.
The best near-term cluster now looks like:
- **weak Overview landing**
- **object timelines in Recall**
- **adoption harbors / branch truth beside current-live beacons**
- **typed action mode inside Omnibox**
- **preview → compare → promote grammar everywhere**

## What Helm should keep from the old inspirations

### i3
Keep:
- deterministic spatial grammar
- obvious focus and placement truth
- keyboard-first confidence

Peel away:
- the expectation that power must stay texty or austere to remain honest

### AHK
Keep:
- low-latency directness
- user-shaped automation
- the joy of bending the desktop to your will

Peel away:
- invisible ambient mutation
- fragile hidden scripts as the real substrate

### Rofi / launcher culture
Keep:
- instant summon
- fuzzy finding speed
- “one doorway, many intents” feel

Peel away:
- untyped result mush
- action ambiguity
- plugin sprawl as architecture

### Dolphin / strong browser culture
Keep:
- object-first browsing
- exact reveal
- preview before commitment
- route clarity

Peel away:
- file-manager assumptions as if every shell object were “just a file”

### god-tier task-manager dream
Keep:
- operational honesty
- live truth
- failures and resource use as first-class
- trustworthy current state

Peel away:
- table religion
- the idea that overview means “show every process and counter”

## Lessons Helm must learn from the past

### 1. Convenience wants to lie

Every mature tool drifts toward the same flattering shortcuts:
- recent becomes live
- preview becomes open
- branch becomes adopted
- granted once becomes granted now
- historical evidence becomes current authority

Helm has to keep refusing that drift on purpose.

### 2. Giant memory is not the same as good recall

The product world keeps rediscovering that memory features feel magical until they become creepy, noisy, or overclaiming.
Helm Recall should therefore stay:
- exact
- object-bound
- claim-strength aware
- and current-live adjacent

not a screenshot religion.

### 3. Landing surfaces should orient, not rule

The home/dashboard graveyard is full of products that tried to become the master plane.
Helm should let Overview be small, assembled, and honest.
That will make it more loved, not less ambitious.

### 4. Parallel luxury only works when merge/adopt truth is obvious

Users love branches, drafts, side lanes, and helpers.
They hate not knowing what is live.
Helm should keep taking the second half more seriously than most tools do.

### 5. Freeze verbs and laws before mega-objects

This remains one of the archive's best instincts.
Helm is getting stronger because it keeps naming:
- preview versus promote
- reviewed basis versus live basis
- route versus materialization
- handle versus receipt
- bookmark versus reset

That discipline should continue.

## Nifty ideas worth stealing

### 1. Action mode in Omnibox

Steal from Spotlight and modern command palettes:
- action search
- typed arguments
- quick-key assignment
- visible provider families
- calculator / small transforms / exact object acts nearby

This makes Omnibox feel deeper without widening authority invisibly.

### 2. Per-object timelines in Recall

Steal from VS Code Timeline:
- one subject timeline
- local versus durable history filters
- compare from chosen points
- recent-change context that stays exact

This would make Recall feel rich while preserving humility.

### 3. Weak Overview landing

Steal from Notion Home and the better parts of workspace home surfaces:
- recent handles
- shortcuts/front doors
- upcoming or outstanding work cues
- one bounded ops slice
- one or two watch or timeline cues

But keep all of it visibly derivative from stronger shell truth.

### 4. Review-before-adopt branching luxury

Steal from Figma branches and worktree UX:
- safe exploration
- explicit review
- merge/adopt/reject
- visible lineage
- exact live lane badge nearby

This is one of the clearest routes to making Helm feel premium.

### 5. Quick Look everywhere

Keep proving that the shell can let users:
- preview
- annotate lightly
- compare
- and only then open/promote/materialize

That grammar is broadly applicable across Object Browser, Recall, Exchange, and Overview.

## Moves that could make Helm super awesome

### 1. One unbelievably good return-to-work loop

This is the biggest one.
Imagine:
- summon Overview or Omnibox
- see one exact current-live beacon
- see one exact remembered handle or activity cockpit
- inspect one object timeline
- compare what changed
- jump into the live lane or adopt a branch deliberately

If Helm nails that loop,
it will feel unlike ordinary desktops.

### 2. Current-live truth that is always obvious

Most systems are surprisingly bad at this.
Helm can be unusually good.
Every relevant surface should make it obvious whether you are looking at:
- live
- historical
- restored
- branched
- delegated
- or merely proposed truth

### 3. Rich luxury with tiny honest objects

Helm's most distinctive move may be that it can feel sophisticated without hiding architecture.
That means:
- more tiny typed cards
- more adjacent witnesses
- better promote ladders
- calmer but stronger trusted chrome

### 4. A command surface that acts without becoming spooky

There is enormous delight in typed shell actions.
The trick is to keep them:
- typed
- inspectable
- parameterized
- source-labeled
- and bounded by current authority

### 5. A humane branch/adopt story across multiple pillars

This could unify Desktop Flow, Recall, Exchange, Object Browser, and Terminal/Capshell more than almost anything else.
The product win is not “branching” as such.
It is the feeling that experimentation is always available,
but live truth is never ambiguous.

## Pull-the-trigger judgment

What I would actually pull the trigger on now is **not** another pillar.
It is one product-shaping proof cluster:

1. refresh **Overview** toward a weak assembled landing
2. refresh **Recall** toward exact object timelines
3. refresh **adoption harbors / branch truth** so exploratory work never impersonates live
4. let **Omnibox** grow a clearer action mode that feels first-party and typed

That is enough decision for now.
It sharpens the pillars without prematurely freezing the whole datacube.
