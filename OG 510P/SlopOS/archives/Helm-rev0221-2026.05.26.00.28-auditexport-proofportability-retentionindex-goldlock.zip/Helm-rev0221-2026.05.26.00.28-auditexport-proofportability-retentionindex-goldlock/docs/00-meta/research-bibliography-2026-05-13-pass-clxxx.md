# Research bibliography — 2026-05-13 pass CLXXX

## Semantic layers / metric views

- Databricks Unity Catalog metric views — https://docs.databricks.com/aws/en/business-semantics/metric-views/
- dbt MetricFlow — https://docs.getdbt.com/docs/build/about-metricflow
- dbt dimensions / SCD Type II — https://docs.getdbt.com/docs/build/dimensions
- Cube pre-aggregations reference — https://cube.dev/docs/product/data-modeling/reference/pre-aggregations
- Cube pre-aggregation refresh — https://cube.dev/docs/product/caching/refreshing-pre-aggregations

## Table formats / snapshots / local analytics

- Apache Iceberg branching and tagging — https://iceberg.apache.org/docs/latest/branching/
- MotherDuck DuckLake concepts — https://motherduck.com/docs/concepts/ducklake/
- MotherDuck DuckLake integration docs — https://motherduck.com/docs/integrations/file-formats/ducklake/
- DuckDB Wasm — https://duckdb.org/docs/current/clients/wasm/overview.html
- DuckDB Quack remote protocol — https://duckdb.org/2026/05/12/quack-remote-protocol.html
- Observable Framework data loaders — https://observablehq.observablehq.cloud/framework/data-loaders
- Observable Framework DuckDB — https://observablehq.observablehq.cloud/framework/lib/duckdb

## Local-first / sync

- Electric Sync — https://electric.ax/sync/
- Electric GitHub — https://github.com/electric-sql/electric
- Turso local-first — https://turso.tech/local-first
- Turso embedded replicas docs — https://docs.turso.tech/features/embedded-replicas/introduction
- Logux actions and undo — https://logux.org/guide/concepts/action/

## Queues, triage, review

- Linear Triage — https://linear.app/docs/triage
- Linear web forms for Asks — https://linear.app/changelog/2026-04-02-web-forms-for-linear-asks
- GitHub managing a merge queue — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
- GitHub merging with a merge queue — https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/merging-a-pull-request-with-a-merge-queue

## Context, MCP, security

- OpenTelemetry Baggage — https://opentelemetry.io/docs/concepts/signals/baggage/
- OpenTelemetry context propagation — https://opentelemetry.io/docs/concepts/context-propagation/
- OpenTelemetry MCP semantic conventions — https://opentelemetry.io/docs/specs/semconv/gen-ai/mcp/
- MCP security best practices — https://modelcontextprotocol.io/docs/tutorials/security/security_best_practices

## Browser/desktop platform surfaces

- MDN FedCM API — https://developer.mozilla.org/en-US/docs/Web/API/FedCM_API
- Chrome FedCM docs — https://developer.chrome.com/docs/identity/fedcm
- Chrome FedCM 143 update — https://developer.chrome.com/blog/fedcm-chrome-143-updates
- XDG Desktop Portals — https://snapcraft.io/docs/explanation/snap-development/xdg-desktop-portals/
- GNOME portals with unsandboxed apps — https://blogs.gnome.org/ignapk/2025/06/04/using-portals-with-unsandboxed-apps/
- Apple App Intents — https://developer.apple.com/documentation/appintents
- Apple App Shortcuts — https://developer.apple.com/documentation/appintents/app-shortcuts
- Raycast AI Commands — https://manual.raycast.com/ai/ai-commands
- Raycast Quicklinks — https://manual.raycast.com/quicklinks
- Microsoft Recall user docs — https://support.microsoft.com/en-us/windows/retrace-your-steps-with-recall-aa03f8a0-a78b-4b3e-b0a1-2eb8ac48701c
- Microsoft Recall management docs — https://learn.microsoft.com/en-us/windows/client-management/manage-recall
- KDE Activities docs — https://docs.kde.org/trunk_kf6/en/plasma-desktop/plasma-desktop/activities-interface.html
- KDE Activities workflow blog — https://blogs.kde.org/2026/01/17/streamline-plasma-with-activities-to-be-more-focused-and-productive/
