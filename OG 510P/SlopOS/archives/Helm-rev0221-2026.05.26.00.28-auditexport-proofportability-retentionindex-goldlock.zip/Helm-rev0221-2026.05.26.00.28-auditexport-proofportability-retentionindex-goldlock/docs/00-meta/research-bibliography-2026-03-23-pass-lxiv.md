# Research bibliography — 2026-03-23 — pass LXIV

Primary outside references used in this pass:

- Apple Support — Handoff requirements and nearby-device continuation posture.
- Visual Studio Code Profiles documentation — export/import, preview, gist/file sharing, and manual import posture.
- Raycast Quicklinks and Shared Quicklinks docs — local-not-synced personal quicklinks, org-shared synced quicklinks, and JSON import posture.
- Grafana dashboard links and data links docs — carrying time range and template variables into linked destinations.
- FIDO credential exchange specifications — dedicated travel format/protocol for credentials.
- Apple AuthenticationServices credential import/export manager docs — dedicated import/export seams for passwords and passkeys.

Teacher archives re-read in this pass:

- SlopOS `auth-continuation-export-boundary-v0.md`
- SlopOS `credential-exchange-boundary-v0.md`
- Schell archive surfaces around shell packets, handoff ladders, startup footing, overlay truth, and migration humility
