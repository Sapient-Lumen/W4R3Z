# Helm idea buckets — 2026-03-22

Purpose: split today's good ideas into categories that reduce drift instead of producing one giant “brilliant ideas” blob.

## Global judgment

Helm should now sort ideas into three buckets:

1. **truth sharpeners** — ideas that make shell truth clearer and stronger
2. **launch / preview sharpeners** — ideas that make the shell feel excellent while staying weaker than truth
3. **spectacle traps** — ideas that look rich but would probably make Helm less honest

This matters because Helm's main risk is no longer lack of interesting ideas.
It is letting too many interesting ideas pretend to be equally foundational.

## Bucket A — truth sharpeners

These moves are the best current candidates for making Helm super awesome.
They improve power and honesty together.

### 1. Saved view objects

Why it matters:
- lets the Object Browser treat views as durable shell objects
- gives Omnibox something exact to summon
- gives Recall something sharper than “last filtered list” folklore
- gives Exchange / publication ladders a real shell payload

What to keep:
- inspectable config
- many views over one stronger subject
- deck composition over views
- share / publish / export by explicit rung
- distinction between definition and result slice

What to resist:
- treating the view itself as the live subject
- letting dashboard layout become the constitution too early
- universal query-ticket law before one family proves it

### 2. Checkpoint branches

Why it matters:
- gives Recall a stronger story than recents or snapshots folklore
- gives Desktop Flow a humane path from history to experimentation
- gives Operations Center a clearer restore / repair / fork story

What to keep:
- exact basis capture
- explicit restore versus fork versus inspect-only
- compact divergence explanation later
- ability to compare side-by-side or overlay

What to resist:
- pretending restore means total environment resurrection
- history religion before one shell specimen works
- giant version-control machinery for every shell object family

### 3. Restricted activation / trust posture

Why it matters:
- keeps imported / shared / uncertain structures from auto-becoming local truth
- composes with saved views,
  deck recipes,
  dock items,
  launch recipes,
  and checkpoint restoration

### 4. Publication ladders plus lineage / fork witness

Why it matters:
- clarifies how shell luxuries cross locality tiers
- prevents copy,
  share,
  publish,
  and activate from collapsing into one flattering story

## Bucket B — launch / preview sharpeners

These are exciting and likely worth doing,
but they should remain visibly weaker than the truth sharpeners.

### 1. Peek → split / open / pin ladders
### 2. Command docks and command bands
### 3. Launch configurations and workspace recipes
### 4. Action quick keys and tiny mnemonic surfaces
### 5. Session navigation across live / historical / saved structures

The key law:
these moves are best when they are **projections over stronger objects**,
not when they become a second hidden control plane.

## Bucket C — spectacle traps

These are the moves Helm should be very suspicious of.

### 1. Giant dashboard religion
A huge dashboard can feel powerful while making provenance,
authority,
and liveness harder to read.

### 2. Ambient sync mythology
The more cross-device / cross-user magic Helm adds,
the more it must resist pretending that travel equals activation.

### 3. One giant workspace super-object
Layouts,
views,
launches,
trust posture,
shared packets,
and live tasks should not collapse into one giant “workspace” ontology.

### 4. Pretty history theater
Timeline walls and snapshot galleries can be seductive,
but Helm needs exact return,
restore,
fork,
comparison,
and receipts more than it needs nostalgia wallpaper.

## Pillar implications

### Tiling Shell
- strongest new pressure: launch recipes,
  peek promotion,
  command docks
- caution: do not let saved layouts impersonate continuity

### Omnibox
- strongest new pressure: exact summonable views,
  quick keys,
  preview promotion
- caution: do not flatten live objects,
  views,
  routes,
  and receipts into one giant result list

### Object Browser
- strongest new pressure: saved view objects and view decks
- caution: do not let deck layout outrun object truth

### Operations Center
- strongest new pressure: trust posture,
  restore / fork status,
  live-versus-restored honesty
- caution: do not let badges or status shelves impersonate completion

### Desktop Flow
- strongest new pressure: checkpoint branches,
  launch recipes,
  materialization witness
- caution: do not build universal graph/version machinery too early

### Recall
- strongest new pressure: checkpoints,
  branches,
  exact reentry,
  divergence cues
- caution: do not let restored state impersonate current live state

### Exchange
- strongest new pressure: view / recipe travel,
  publication ladders,
  lineage/fork witness
- caution: do not let published or shared payloads count as active receiver truth

## Pull-the-trigger judgment

The cleanest “do it now” choice is:

1. write a **saved-view-object candidate contract**
2. write a **checkpoint-branch candidate contract**

Those two moves give Helm the best chance of becoming super awesome because they make the shell's objects,
history,
preview,
and travel story feel richer **without** requiring one giant up-front constitutional freeze.
