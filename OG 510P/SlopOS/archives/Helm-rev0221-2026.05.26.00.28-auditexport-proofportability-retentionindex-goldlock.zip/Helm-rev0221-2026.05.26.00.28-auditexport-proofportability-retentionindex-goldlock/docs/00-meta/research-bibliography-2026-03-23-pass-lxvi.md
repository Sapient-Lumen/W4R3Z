# Research bibliography — 2026-03-23 — pass LXVI

## Sources consulted for this pass

1. GitHub Docs — About pull requests
   - pull requests as proposals to merge code changes into a project
2. GitHub Docs — Reviewing proposed changes in a pull request
   - review diffs,
     leave comments,
     mark files viewed,
     approve or request changes
3. GitHub Docs — REST API endpoints for pull requests
   - `expected_head_sha` on pull-request branch update,
     422 on mismatch
4. GitHub Docs — GraphQL input objects
   - `expectedHeadOid` on merge,
     auto-merge,
     and merge-queue enqueue flows
5. Figma Help — Guide to branching
   - branches as controlled environments,
     review-and-merge flows,
     explicit updates from main,
     conflict resolution before apply
6. Kubernetes Docs — Coordinated Leader Election
   - `resourceVersion` optimistic concurrency control,
     only one concurrent update succeeds on version mismatch
7. Kubernetes Docs — Server-Side Apply
   - conflicts when one manager would overwrite fields owned by another manager
8. RFC 9110 — HTTP Semantics
   - `If-Match` as a lost-update prevention mechanism,
     412 / precondition-failed posture for state-changing methods when the validator does not match
