# Research bibliography — 2026-03-24 — pass CLXXI

Primary sources reviewed for this pass:

1. Azure Cosmos DB consistency levels — session tokens as minimum version barriers and passed-token guidance.
2. MongoDB read isolation / consistency / recency — causal consistency across sessions via advanced operation time and cluster time.
3. Couchbase SDK SQL++ query docs — `ConsistentWith(MutationState)` / `AT_PLUS` for targeted lower-bound consistency.
4. Apache Kafka consumer docs — current position versus committed position and recovery semantics.
5. Git fetch docs — remote-tracking branch update semantics.
6. Git merge docs — explicit incorporation into the current branch.
