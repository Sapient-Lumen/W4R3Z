# Research bibliography — 2026-03-23 pass CLXIII

Official product and primary-source materials consulted for this pass:

- GitHub Docs — Contexts reference (run_id / run_number / run_attempt)
  - https://docs.github.com/en/actions/reference/workflows-and-actions/contexts
- GitHub Docs — Managing a merge queue
  - https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
- AWS Step Functions — Restarting state machine executions with redrive
  - https://docs.aws.amazon.com/step-functions/latest/dg/redrive-executions.html
- Temporal Docs — Continue-As-New
  - https://docs.temporal.io/workflow-execution/continue-as-new
- Microsoft Graph — Use delta query to track changes in Microsoft Graph data
  - https://learn.microsoft.com/en-us/graph/delta-query-overview
- Microsoft Graph — user: delta
  - https://learn.microsoft.com/en-us/graph/api/user-delta?view=graph-rest-1.0
- Google Calendar API — Synchronize resources efficiently
  - https://developers.google.com/workspace/calendar/api/guides/sync
- Google Calendar API — Events: list
  - https://developers.google.com/workspace/calendar/api/v3/reference/events/list
- Google Drive API — Retrieve changes
  - https://developers.google.com/workspace/drive/api/guides/manage-changes
- Kubernetes Docs — API Concepts (watch bookmarks / sendInitialEvents / resourceVersionMatch)
  - https://kubernetes.io/docs/reference/using-api/api-concepts/
- Dropbox Developers — HTTP documentation (list_folder/continue reset examples)
  - https://www.dropbox.com/developers/documentation/http/documentation
