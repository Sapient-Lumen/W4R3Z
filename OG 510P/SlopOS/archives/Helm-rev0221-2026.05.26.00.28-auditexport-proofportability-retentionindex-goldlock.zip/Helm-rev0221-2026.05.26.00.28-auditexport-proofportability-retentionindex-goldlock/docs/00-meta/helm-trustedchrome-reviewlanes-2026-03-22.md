# Helm trusted chrome + review lanes — 2026-03-22

Purpose: name the next shell-native honesty move that looks worth proving after condition strips and observed-basis chips.

## Main idea

Helm already has many promising honesty objects.
But many strong asks still risk ending inside ordinary provider rows,
import previews,
terminal content,
or app-owned surfaces.

The shell needs a calmer shared answer to two questions:

1. **where do authority-bearing review and approval surfaces live?**
2. **how does the shell confess when weaker-origin content asked for a host-side effect?**

The next compact answer looks like:
- **trusted chrome lane**
- **host-effect witness**

## 1. Trusted chrome lane

A **trusted chrome lane** is a compact shell-owned presentation lane outside ordinary content flow.

It is the place where Helm can keep stronger review and approval posture visibly separate,
for example:
- grant or deny prompts
- public / guarded-link reveal confirmations
- adopt / promote / publish confirmations
- restricted-mode explanations
- protected follow-up prompts
- high-confidence route and target witnesses

### Why it is worth stealing

The best current systems keep powerful-feature review in host UI or browser UI,
not in the untrusted or ordinary content surface.
Helm should do the same.

A provider row,
terminal pane,
or imported preview may motivate the request.
But the final trustworthy review surface should be shell chrome.

### What it should not do

- not become a giant dashboard
- not become the only transcript of what happened
- not replace receipts,
  warrants,
  or current-live truth
- not turn every small action into a scary modal ritual
- not pretend raw or inferred content earned trusted-chrome status

## 2. Host-effect witnesses

A **host-effect witness** is a compact shell-owned witness for a shell-side effect requested by weaker-origin content.

It should be able to say things like:
- raw content asked to set a title
- shell-attested content asked to open a link
- imported surface asked to copy to clipboard
- terminal content asked for a stronger review prompt
- app content requested a reveal or publish action but the shell held it for review

### Why it is worth stealing

Many shell luxuries are also spoof surfaces:
- titles,
- badges,
- clipboard writes,
- link opens,
- and embedded “approve this” UI.

Helm needs a tiny witness object that says:
- what was requested,
- what origin grade it came from,
- what the shell did,
- and whether trusted chrome took over.

### What it should not do

- not create authority by itself
- not become a giant audit ledger
- not pretend decorative chrome equals exact identity
- not flatten allow,
  hold,
  downgrade,
  and deny into one hidden decision

## 3. Why these two belong together

Trusted chrome lanes answer:
**where does the shell place stronger review truth?**

Host-effect witnesses answer:
**what weaker-origin request caused the shell to show or refuse that stronger review path?**

Together they stop a lot of shell confusion:
- imported preview asked for adoption,
  but trusted chrome hosted the real approval
- terminal content suggested a public reveal,
  but the shell held it for review
- raw title text changed the label,
  but only as a witnessed weaker-origin effect
- restricted material stayed browseable,
  but protected actions moved into trusted chrome

## 4. Best first proofs

### Pull the trigger soon
- warm **trusted chrome lane** as a candidate shell object
- warm **host-effect witness** as a candidate shell object

### Great first demos
- one Browser import card that stays restricted until adoption is approved in trusted chrome
- one Omnibox stronger action that jumps to a shell-owned review lane instead of finishing inline
- one Exchange publish / guarded-link / public confirm card in trusted chrome
- one Terminal/Capshell witness for title / clipboard / link-open / stronger-review requests

## 5. Pillar pressure

- **Omnibox** benefits when stronger quick actions can keep suggestion and approval visibly separate
- **Object Browser** benefits when import,
  adopt,
  publish,
  and reveal prompts stop living only inside provider rows
- **Operations Center** benefits when grant,
  deny,
  hold,
  and protected follow-up surfaces have one shell-owned home
- **Desktop Flow** benefits when helper-backed stronger acts can pivot into trusted review instead of hidden inline mutation
- **Recall** benefits when historical approval receipts can point back to one exact trusted-chrome decision
- **Exchange** benefits when imported,
  attached,
  shared,
  and published effects stop blurring content previews with final authority
- **Terminal/Capshell** benefits the most because PTY or app content can stay useful without impersonating the shell's strongest truth

## Judgment

Helm still does not need another pillar.
It needs one compact answer to where the shell places stronger review truth.

The right answer now looks like:
- **trusted chrome lane**
- **host-effect witness**

That pair looks like one of the cleanest remaining ways to make Helm more trustworthy,
more shell-native,
and more awesome at the same time.
