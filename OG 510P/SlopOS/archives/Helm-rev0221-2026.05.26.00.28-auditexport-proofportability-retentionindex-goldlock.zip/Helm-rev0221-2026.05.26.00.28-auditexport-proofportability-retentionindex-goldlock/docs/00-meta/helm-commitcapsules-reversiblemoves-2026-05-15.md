# Helm commit capsules and reversible moves — 2026-05-15

rev0193 moves Helm one step beyond consequence envelopes.

## Thesis

Helm should not make operators choose between “nothing happened” and “an opaque effect happened.” It needs a compact packet for bounded local consequence: a commit capsule.

A commit capsule says:

- which consequence projection it implements;
- what preconditions were visible;
- what freeze window bounds it;
- what surfaces and events are affected;
- what signals and context crumbs are emitted;
- when abort is still possible;
- what receipt or pin is created;
- how retreat/tombstone works;
- what it cannot authorize.

## Pull the trigger

Admit commit capsules as checked fixture objects.

## Do not pull the trigger

Do not choose a deployment engine, policy engine, workflow runtime, feature flag system, notifier, authorization language, backend, table format, semantic layer, or new pillar.

## Why this is a Helm move

Helm is a shell/compositor. Its magic is not to be the backend. Its magic is to make consequence legible at the moment of action. A commit capsule is the exact packet a premium shell should render beside a button that could otherwise lie.

## Product delight

A capsule can become one beautiful UI strip:

`Review cut • release-view@13/C8 • abort until visible to queue • not promotion • tombstone if hidden`

That line is the opposite of enterprise sludge. It gives the operator confidence without making them read a policy proof.
