# SlopOS + companions evaluation — 2026-03-22 — pass LXXXI

Purpose: re-read the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one tighter question:
**what should Helm learn now about rehearsal, promotion, and composite-surface authorship while those companion cubes are still in design phase?**

## 1. SlopOS still teaches the hardest law in the room: an issued artifact is not current live truth

`lease-descriptor-state-boundary-v0.md` remains one of the most important teachings for Helm.
A descriptor can be exact issuance-bounded evidence without becoming a portable oracle for current live state.

Helm should keep stealing that law everywhere:
- a remembered handle is not the same thing as current access
- a rehearsal lane is not the same thing as the authoritative live lane
- a published or shared handle is not the same thing as current audience truth
- a previous approval is not the same thing as current admission

That law is more valuable than any specific SlopOS object family.

## 2. SlopOS also keeps refusing ambient persistence mythology

`background-lease-posture-v0.md` is still a very healthy warning.
It says durable presence should be bounded, revocable, visible, and narrower than a generic daemon religion.

For Helm that means:
- side work should prefer explicit rehearsal lanes over invisible background mutation
- promote/apply should remain a stronger step than "the helper already did it"
- anything persistent should show its scope, lease posture, and kill path

Helm should steal the discipline, not the full background-lease family.

## 3. Approval in SlopOS binds one exact mutable basis, not a flattering later cousin

`approval-basis-posture-v0.md` keeps pressing the same truth:
reviewed authority binds one exact mutable basis and should not silently follow the next convenient version.

That now connects very naturally to three Helm moves:
- **pinned handles** for exact reviewed or exact historical basis
- **floating handles** for intentionally latest-following entry points
- **promotion rails** that fail closed, downgrade, or ask again when the reviewed basis drifted

Helm should not leave those differences implicit.
They should be product-visible.

## 4. SlopOS keeps preview weaker than open, and open weaker than trust

`openuri-preview-metadata-boundary-v0.md` and `quarantined-result-preview-boundary-v0.md` are still teaching exactly the right thing:
preview is useful precisely because it stays weaker.
Selection, hover, and result-list presence should not quietly become richer capability seams.

That matters a lot for Helm's rehearsal story.
A rehearsal lane should be allowed to:
- render candidate structure
- compare against live truth
- surface predicted effects
- collect gate posture

But it must not quietly count as adoption, execution, or live continuity.

## 5. Schell still strengthens the case for a smaller native meaning floor

Schell keeps reminding Helm that native shell meaning should stay small, explicit, and membrane-friendly.
That lesson becomes sharper when composite objects start looking attractive.

The practical read for Helm is:
- do not let one giant deck, cockpit, or activity object pretend it now owns every sub-part's truth
- let labels, titles, and display summaries remain humble chrome over stronger anchors
- prefer compact authorship and witness strips over hidden merge magic

Schell is a good warning against turning every nice composite surface into a new constitution.

## 6. Steward keeps teaching exact chooser return, ephemeral-by-default selection, and postureful chrome

`chooser-surface-posture-v0.md` is an excellent Helm teacher.
Chooser output should resolve to exact targets or selectors when possible, stay ephemeral by default, and keep downgrade visible when only weaker matched text survives.

That pushes Helm toward:
- requested-target repair/regrant/rebind starts
- pinned/floating handle badges instead of one generic "reopen"
- chooser actions that promote into explicit rails instead of quietly pasting text back into the command world

Steward also keeps pressing label humility.
The shell should show posture, not hide it under pretty chrome.

## 7. ViewFS remains the best companion teacher for lane separation

`follow-tails-attach-rails-and-control-panes.md` keeps the core shell lesson very crisp:
observe/query/follow,
interactive attach,
control messages,
injected exec/debug,
sideband forwarding,
and durable history are different lanes.

Helm should generalize that lesson beyond terminals.
Rehearsal,
review,
promotion,
live control,
effect aftermath,
and historical recall are also different lanes.

The more the shell keeps those lanes visible,
the more trustworthy the datacube becomes.

## 8. The design-phase lesson is now very clear

Because SlopOS and Schell are still design-phase cubes,
Helm should mostly steal:
- seam cuts
- refusal laws
- downgrade posture
- current-vs-historical discipline
- preview-vs-open-vs-trust discipline
- exact chooser return discipline
- lane separation

Helm should mostly avoid stealing:
- giant family proliferation
- speculative registries
- large policy consoles
- hidden background mythology
- any assumption that a rich archive means the object model is already settled

## 9. Best next Helm moves after this re-read

### Pull warmer now
- **pinned vs floating handles**
- **rehearsal → compare → promote rails**
- **facet ownership / conflict posture** for composite saved views, decks, entry kits, and cockpit surfaces

### Keep warm only
- giant capability-recipe studios
- universal facet-ownership engines
- auto-healing merge systems for composite surfaces
- giant promotion courts

## Judgment

The companion cubes are still strongest when they teach **laws, not lavish machinery**.

Helm should take the next step by making three things much more legible:
- whether a handle is **pinned** or **floating**
- whether a thing is merely in **rehearsal** or actually **promoted**
- who currently owns which **facet** of a composite shell object when conflicts matter

That would make Helm feel sharper without adding another pillar or a giant new object court.
