# Helm awesome ratchets and exposure ladders — 2026-03-22

Purpose: identify the few moves Helm can ratchet now that would make it feel dramatically better without committing to giant unfinished machinery.

## The shortest answer

Helm gets more awesome by making strong acts:
- narrower,
- more inspectable,
- more reviewable,
- more staged,
- and more honest about exposure.

It does **not** get more awesome by becoming one giant omniscient datacube.

## Five ratchets worth pulling now

### 1. Parameterized front doors
Every major pillar gets stronger if Helm can treat:
- “open the project cockpit”
- “open the compare view for this branch”
- “start the dev-service stack for this workspace”
- “resume triage for this queue”
- “re-enter this activity with this exact subject”

as typed summonable front doors with a small number of explicit parameters.

Why now:
this helps Omnibox,
Tiling,
Recall,
Flow,
and Exchange at once without forcing a giant new object family.

### 2. Saved-plan posture for strong acts
Before a strong apply/adopt/publish/import/reconfigure step,
Helm should be able to hold a compact saved plan object that shows:
- exact subject
- exact target
- exact scope or audience
- reviewed basis
- drift status
- strongest next rung
- expected affected set

Why now:
this makes Flow,
Exchange,
Recall,
and Operations feel premium immediately.

### 3. Restricted-first adoption harbor
Imported,
borrowed,
rebound,
or helper-generated things should first land in a quiet restricted harbor.
They should be:
- inspectable,
- previewable,
- comparable,
- maybe runnable in weaker local ways,
- but not yet ordinary local truth.

Why now:
this is one of the cleanest ways to keep Helm powerful without ambient trust mythology.

### 4. Exposure ladders
Helm should separate:
- local only
- named/private cohort
- org/workspace/tailnet
- guarded-link / expiring bearer
- public

and also separate:
- preview
- open locally
- share privately
- publish broadly
- expose publicly

Why now:
shells usually blur these meanings badly.
Getting this right would make Helm feel unusually adult.

### 5. Adopt the narrowest safe rung
Helm should have one fast gesture meaning:
**take the narrowest legal version of this act.**

Examples:
- once instead of persistent
- selected cohort instead of all
- read-only instead of mutable
- local preview instead of public exposure
- receipt-only instead of fake success

Why now:
it is both safer and more delightful than making every user answer the full policy tree every time.

## Moves that could become signature Helm delights

### Continuity postcards
Tiny return cards that say:
- `current-live`
- `exact saved front door`
- `historical only`
- `repaired return`
- `adoption needed`

### Witness-chip grammar
Tiny cross-pillar chips such as:
- `current-live`
- `preview`
- `restricted`
- `stale`
- `reviewed`
- `historical`
- `suggested`
- `override`
- `public`
- `guarded-link`

### Service cards with exposure truth
A service should be able to say:
- listening only
- previewable locally
- opened locally
- shared privately
- org/tailnet visible
- public
- stale / dead / historical

### Explain-why triage
A suggestion should be able to say:
- why it was surfaced
- what exact subject it refers to
- what exact rung it is proposing
- what stronger or weaker alternatives exist

## What not to freeze yet

- one universal workspace object
- one universal collaboration object
- one giant always-on live cube
- big family machinery for every warm idea
- giant policy consoles

## Closing judgment

Helm can become super awesome with a surprisingly small number of ratchets.

The best near-term path is:
- parameterized front doors
- saved plans
- restricted-first adoption
- exposure ladders
- narrowest-safe-rung ergonomics

That is enough to make the whole system feel smarter,
calmer,
and more trustworthy.
