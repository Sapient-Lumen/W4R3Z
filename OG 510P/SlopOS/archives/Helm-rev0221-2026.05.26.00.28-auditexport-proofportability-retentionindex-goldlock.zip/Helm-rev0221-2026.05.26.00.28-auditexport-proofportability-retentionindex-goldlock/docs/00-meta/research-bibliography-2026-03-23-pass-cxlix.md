# Research bibliography — 2026-03-23 pass CXLIX

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GERRIT-ATTENTION-SET-2026H | https://gerrit-review.googlesource.com/Documentation/user-attention-set.html | Gerrit gives Helm the clearest precedent for explicit human attention sets, turn-passing, and bots staying out of the human review turn. |
| REF-GERRIT-COPYCONDITION-ATTENTION-2026H | https://gerrit-review.googlesource.com/Documentation/config-labels.html | Gerrit shows that carried approvals and current attention are different truths: copy conditions may preserve weak residue while outdated votes reopen attention. |
| REF-GITHUB-CODEOWNERS-2026H | https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners | GitHub code owners teach automatic review requests, draft-versus-ready posture, and base-branch ownership footing. |
| REF-GITHUB-PR-REVIEWS-2026H | https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests/about-pull-request-reviews | GitHub keeps request-versus-re-request review explicit, which is strong pressure for Helm turn-reopen truth. |
| REF-GITHUB-TEAM-CODE-REVIEW-SETTINGS-2026H | https://docs.github.com/en/enterprise-cloud@latest/organizations/organizing-members-into-teams/managing-code-review-settings-for-your-team | GitHub’s team review settings contribute audience-versus-actor separation, auto assignment, load-balance / round-robin routing, and busy-status honesty. |
| REF-GITLAB-MR-REVIEWS-2026H | https://docs.gitlab.com/user/project/merge_requests/reviews/ | GitLab contributes explicit reviewer states plus the Review requested inbox shape. |
| REF-GITLAB-CODE-REVIEW-GUIDELINES-2026H | https://docs.gitlab.com/development/code_review/ | GitLab’s own review guidelines teach re-request posture, area-specific asks, and explicit stage-specific review requests. |
| REF-FIGMA-BRANCH-REQUEST-REVIEW-2026H | https://help.figma.com/hc/en-us/articles/5691414603543-Request-a-branch-review | Figma contributes request/resend review, in-review versus approved state, and approved-but-not-merged honesty. |
