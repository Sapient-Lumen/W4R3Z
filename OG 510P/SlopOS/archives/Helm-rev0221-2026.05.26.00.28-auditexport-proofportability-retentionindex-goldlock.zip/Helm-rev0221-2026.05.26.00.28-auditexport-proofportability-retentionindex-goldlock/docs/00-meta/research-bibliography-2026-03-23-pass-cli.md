# Research bibliography — 2026-03-23 pass CLI

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GRAFANA-SILENCES-2026J | https://grafana.com/docs/grafana/latest/alerting/configure-notifications/create-silence/ | Grafana contributes the core law that silences suppress notifications without interrupting alert evaluation. |
| REF-GRAFANA-MUTE-TIMINGS-2026J | https://grafana.com/docs/grafana/latest/alerting/configure-notifications/mute-timings/ | Grafana contributes recurring mute timings, active time intervals, and the fixed-start/end versus recurring distinction. |
| REF-PROMETHEUS-ALERTMANAGER-2026J | https://prometheus.io/docs/alerting/latest/alertmanager/ | Alertmanager contributes silencing and inhibition as first-class neighboring exception classes. |
| REF-PAGERDUTY-MAINTENANCE-2026J | https://support.pagerduty.com/main/docs/maintenance-windows | PagerDuty contributes time-bounded maintenance windows, visible current/future/past windows, and explicit early termination. |
| REF-PAGERDUTY-SERVICE-SETTINGS-2026J | https://support.pagerduty.com/main/docs/configurable-service-settings | PagerDuty contributes auto-pause incident notifications and acknowledgement-timeout posture distinct from maintenance or resolution. |
| REF-DATADOG-DOWNTIMES-2026J | https://docs.datadoghq.com/monitors/downtimes/ | Datadog contributes scoped downtime targeting, preview of affected monitors, group scope, and recurring schedule posture. |
| REF-DATADOG-DOWNTIME-AFTERMATH-2026J | https://docs.datadoghq.com/monitors/guide/prevent-alerts-from-monitors-that-were-in-downtime/ | Datadog contributes explicit aftermath law when downtime ends or is cancelled and suppressed notifications become eligible again. |
| REF-GITHUB-RULESETS-2026J | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets | GitHub rulesets contribute explicit bypass permissions and layered rule posture. |
| REF-GITHUB-ENVIRONMENTS-2026J | https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments | GitHub environments contribute required reviewers, wait timers, deployment protection rules, and admin bypass posture. |
| REF-GITHUB-BREAKGLASS-2026J | https://github.blog/changelog/2023-03-01-github-actions-admins-can-now-bypass-environment-protection-rules/ | GitHub explicitly frames environment-rule bypass as break glass, which sharpens Helm's later breakglass-beacon idea. |
| REF-JSM-SLA-CONDITIONS-2026J | https://support.atlassian.com/jira-service-management-cloud/docs/set-up-sla-conditions/ | Jira Service Management contributes explicit start / pause / finish conditions and the waiting-for-customer pause precedent. |
