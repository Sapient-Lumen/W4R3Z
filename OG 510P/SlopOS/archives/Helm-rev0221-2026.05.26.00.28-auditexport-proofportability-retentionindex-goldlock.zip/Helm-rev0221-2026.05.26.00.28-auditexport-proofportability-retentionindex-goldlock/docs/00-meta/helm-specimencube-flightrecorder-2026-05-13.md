# Helm specimen cube and flight recorder — 2026-05-13

## Current judgment

rev0186 made the right move by defining a **specimen grammar** before a backend choice.
rev0187 should now make that grammar falsifiable.

The next Helm object should be a **specimen cube**: a tiny operator-truth datacube that records how one subject moves across live, saved, cut, derived, and receipt lanes while crossing Helm's seven pillars.

This is not a BI cube.
This is not a warehouse design.
This is not a global index.
This is not a SlopOS boundary-family import.
This is a **flight recorder for shell truth**.

## The pull-trigger decision

Pull the trigger on a **specimen-event record** for proof fixtures.

The record is accepted as:

- a product-design proof fixture;
- a common test vocabulary across pillars;
- a way to catch truth collapse in mockups;
- a seed for later telemetry/receipt design only if proven useful.

The record is not accepted as:

- a production protocol;
- a storage schema;
- an analytics contract;
- an authorization interface;
- an obligation for every tiny UI detail.

## Why this is the right next move

The archive already knows the words: source cut, serving lane, posture, stale fence, receipt path, five truth lanes.
The risk now is that those words remain pretty but untested.

A small event record forces Helm to answer concrete questions:

- Does every peek know whether it is imported, cached, live, or historical?
- Does every review queue item name the basis it reviewed?
- Does every stale refusal give a safe next verb?
- Does every promotion prove a fresh enough recheck?
- Can every pillar render the same truth differently without changing the truth?
- Can Recall return to a specimen without flattering remembered state into live state?
- Can Exchange import a useful packet while keeping it weaker than local adoption?

## Helm's specimen cube axes

The minimum useful cube has ten axes.

### 1. Subject axis

The subject must be exact enough to avoid dashboard mush.
Possible subject classes:

- exact object;
- selected cohort;
- saved-view result slice;
- door pack;
- patrol route;
- queue item;
- imported arrival;
- receipt family;
- activity front door;
- shell flow fragment.

A label is not identity. If the subject cannot be identified exactly, the record must say `subject_strength: approximate` or stay out of strong paths.

### 2. Truth lane axis

The five lanes remain the center:

- current-live;
- saved-definition;
- cut/snapshot;
- derived/serving;
- receipt.

The cube should make lane collisions visible instead of smoothing them.

### 3. Source cut axis

Every serious record names what cut made the visible claim possible:

- provider live head;
- account/profile/policy generation;
- query definition revision;
- table snapshot/tag/branch;
- imported packet id;
- build cut;
- review cut;
- receipt id.

### 4. Serving lane axis

Serving lane says how the surface is being served:

- direct;
- cached;
- precomputed;
- subscribed;
- local analytic;
- imported;
- reconstructed;
- receipt-only.

A serving lane is not an implementation leak. It is user-safety truth when a lane is weaker than live source truth.

### 5. Posture axis

Posture answers what can honestly happen now:

- current;
- restricted;
- adoptable;
- proposed;
- stale;
- blocked;
- settling;
- historical;
- unknown.

### 6. Basis axis

Basis carries the reviewed ingredients:

- definition rev;
- source cut;
- policy/account/profile;
- environment epoch;
- dependency cuts;
- reviewer posture;
- invalidators.

Review without basis is theater.

### 7. Verb rung axis

Verb rungs keep next moves ordered:

- peek;
- inspect;
- compare;
- recheck;
- adopt;
- promote;
- publish;
- settle;
- decline;
- duplicate;
- quarantine;
- retreat.

### 8. Surface axis

Surface says where the truth was rendered or acted on:

- Tiling Shell;
- Omnibox;
- Object Browser;
- Operations Center;
- Desktop Flow;
- Recall;
- Exchange;
- Capshell-family.

The point is not to make one UI. The point is to keep one truth grammar across different UI faces.

### 9. Invalidation axis

Every weaker or basis-bound lane should answer what breaks it:

- source definition changed;
- provider cursor reset;
- account/profile changed;
- credential/lease expired;
- dependency cut changed;
- downstream audience unknown;
- preaggregation refresh key changed;
- local receipt too old for consequence;
- imported packet not adopted.

### 10. Receipt path axis

The record names the proof path:

- no receipt required for weak peek;
- receipt available;
- receipt pending;
- receipt required before stronger act;
- receipt impossible without recheck;
- receipt historical only.

## What the old inspirations still teach

### i3 and tiling WMs

Keep deterministic spatial confidence and keyboard-first fluency.
Do not keep the idea that spatial placement alone is the shell.

### AutoHotkey and automation cultures

Keep user-shaped leverage and low-latency directness.
Do not keep invisible ambient mutation as the real substrate.

### Rofi, Spotlight, Raycast, command palettes

Keep instant summon, action search, short commands, quicklinks, and delight.
Do not keep untyped result mush or plugin sprawl as architecture.

### Dolphin, Finder, Quick Look, object browsers

Keep preview, exact reveal, rich query views, bulk action, and route clarity.
Do not keep folder/path ontology as master law.

### KDE Activities and workspace cultures

Keep workflow ramp-up, saved activity shape, and multi-screen/task-context comfort.
Do not let saved activity shape impersonate current live truth.

### Windows Recall and timeline memories

Keep local return-to-work ambitions and object recall comfort.
Do not keep screenshot religion, creepy capture defaults, or timeless memory claims.

### XDG portals and chooser models

Keep host-mediated exact grants and native chooser comfort.
Do not hide how grants were minted, how long they last, or what exact subject they cover.

### App Intents / Shortcuts / system actions

Keep first-class actions and entities that can be surfaced across the system.
Do not let intent exposure bypass Helm's exact subject, posture, and receipt rules.

## New brilliant Helm moves worth stealing or inventing

### 1. The specimen strip

Every serious object can show a tiny strip:

`subject • truth lane • source cut • posture • safe next verb`

The strip is not decoration. It is the smallest visible answer to “what am I looking at and what can I safely do next?”

### 2. Flight-recorder replay

A Release readiness specimen should be replayable as a design artifact:

- show imported arrival;
- peek;
- triage;
- stale refusal;
- recheck;
- promote;
- receipt;
- recall later.

If the replay cannot explain a UI claim from event records, the UI is likely lying or underspecified.

### 3. Query the shell about truth, not just content

Omnibox should eventually answer questions like:

- “show stale review items that can be rechecked now”;
- “show imported packs not adopted here”;
- “show door packs with cached lanes older than their review basis”;
- “show promotions whose receipts are settling”;
- “show saved views whose live source definition drifted.”

That is the datacube becoming product magic.

### 4. Rung previews

A blocked or stale action should show the smallest next rung:

- peek only;
- inspect source cut;
- compare cut to live;
- recheck;
- adopt;
- promote;
- publish;
- settle.

This turns refusal into guidance without auto-widening authority.

### 5. Local analytic sidecar, but as a weak lane

Helm can use local analytical storage for speed.
The product contract should be that derived lanes confess build cut, invalidators, and stronger truth lane.

### 6. Negative space as a feature

Do not add a giant home object yet.
The release-readiness fixture should use a door pack, not a dashboard constitution.
If the door pack feels small but powerful, Helm is on the right track.

## Lessons Helm must learn from the past

1. **Convenience wants to lie.** Every shortcut wants to become “current” in the user's head.
2. **Saved is not live.** This is the oldest desktop continuity bug.
3. **Preview is not adoption.** Looking must remain weaker than local consequence.
4. **A dashboard is a derivative, not an oracle.** It should confess source cut and lane.
5. **Review without basis is theater.** A review queue without a reviewed cut is cosplay.
6. **Fast is not fresh.** Cached/precomputed/local lanes can be delightful and wrong.
7. **Receipts are not grants.** A receipt proves something happened; it does not reopen authority.
8. **Imports must start weak.** Useful before trusted; stronger after local adoption.
9. **Ambience always starts as luxury.** It ends as unexplainability unless bounded.
10. **AI action must climb rungs.** Propose, explain, compare, receive approval, then act with receipt.

## Current recommendation

Build one release-readiness mock/prototype from the fixture.
For every visible chip or button in the mock, force it to correspond to a specimen event record field.
If a button has no honest record field, delete the button or add the missing truth.

Keep collecting backend ideas, but make them compete to serve the specimen cube rather than become the specimen cube.
