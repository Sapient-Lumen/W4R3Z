# Helm: intent sparks + gesture gates — 2026-03-23

## Headline

Helm should get **better at fresh-intent honesty, not broader at permission theater**.
The next compact move worth warming is:

- **intent sparks**
- **direct-gesture gates**

## Why now

Helm now has:
- trusted chrome lanes for shell-owned stronger-act seams,
- host-effect witnesses for weaker-origin asks,
- access verdict cards for blocked-state honesty,
- capability budgets and lease windows for authority posture,
- active-borrow beacons for on-air truth,
- and freshness-horizon chips for live-looking decay.

What it still lacks is one clean answer to:

- **is this act still riding fresh user intent, or only an old remembered context?**
- **can this act spend a short-lived recent spark, or must it happen in the direct gesture lane itself?**
- **did a helper, queue, or replay try to launder old intent into a later stronger act?**

Without that,
Helm risks another familiar lie:
- delayed prompts that feel spooky,
- helpers that spend yesterday's confidence as if it were current,
- and shell surfaces that cannot tell “fresh yes now” from “historical yes once.”

## The good pattern

### Intent sparks

An intent spark should carry:
- one exact trusted shell origin
- one exact target, cohort, or review subject when known
- one start time
- one expiry posture
- one usage mode (`single-spend`, `multi-use-until-expiry`, or equivalent)
- one state (`live`, `spent`, `expired`, `voided`)
- one visible downgrade to historical residue once it is no longer live

### Direct-gesture gates

A direct-gesture gate should carry:
- one exact host-owned gesture lane
- one exact act family that must happen inside that lane
- one explicit refusal reason when the request arrives later, indirectly, or via replay
- one nearby re-arm or “do this directly now” affordance when safe

## What to keep from older inspirations

Keep:
- HTML's split between sticky and transient activation
- the idea that some uses **consume** fresh intent
- chooser-bound acts like share and file picking remaining gesture-bound
- screen-capture control showing that some acts deserve stricter-than-transient directness
- payment flow posture that keeps high-value UI tied to immediate user initiation

Peel away:
- ambient “user probably still means it” guessing
- generic prompt spam for every tiny move
- giant global activation dashboards
- replayable strong acts that can be launched long after the user stopped looking

## Why this makes Helm more awesome

This move upgrades several existing Helm surfaces:

- **Omnibox** can distinguish suggestions that are inspect-only from actions that need a fresh shell-owned spark.
- **Exchange** can keep weak share / export preparation separate from the moment a real public or cross-app handoff is launched.
- **Operations Center** can show why a stronger act is blocked: no live spark, spark already spent, or direct-gesture-only gate required.
- **Trusted chrome** can keep high-risk approvals, reveals, or control transfers tightly bound to the user's current act instead of to stale surrounding context.

## Pull-the-trigger judgment

This is worth warming now.
Not as a new pillar,
and not as a giant web-style permission bureaucracy,
but as one more compact shell law:

**some strong acts should ride a short-lived shell-owned intent spark,
and a narrower set should require an even stricter direct-gesture gate that cannot be laundered through delay or indirection.**
