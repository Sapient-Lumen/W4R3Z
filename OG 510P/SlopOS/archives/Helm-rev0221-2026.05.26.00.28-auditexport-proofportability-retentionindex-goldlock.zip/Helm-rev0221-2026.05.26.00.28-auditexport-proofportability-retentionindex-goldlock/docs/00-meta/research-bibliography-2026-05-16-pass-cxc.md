# Research bibliography — pass CXC — 2026-05-16

- HashiCorp Vault — Lease, Renew, and Revoke — https://developer.hashicorp.com/vault/docs/concepts/lease
- Kubernetes — Finalizers — https://kubernetes.io/docs/concepts/overview/working-with-objects/finalizers/
- Kubernetes — Garbage Collection / owner references — https://kubernetes.io/docs/concepts/architecture/garbage-collection/
- LaunchDarkly — Flag statuses and lifecycle stages — https://launchdarkly.com/docs/home/flags/flag-status
- LaunchDarkly — Reducing technical debt from feature flags — https://launchdarkly.com/docs/guides/flags/technical-debt
- PagerDuty — Maintenance Windows — https://support.pagerduty.com/main/docs/maintenance-windows
- New Relic — Muting rules: Suppress notifications — https://docs.newrelic.com/docs/alerts/get-notified/muting-rules-suppress-notifications/
- GitHub Docs — Managing requests to bypass push protection — https://docs.github.com/en/code-security/how-tos/secure-your-secrets/manage-bypass-requests/managing-requests-to-bypass-push-protection
- GitHub Docs — Creating rulesets for a repository — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/creating-rulesets-for-a-repository
- Open Policy Agent — Decision Logs — https://openpolicyagent.org/docs/management-decision-logs
