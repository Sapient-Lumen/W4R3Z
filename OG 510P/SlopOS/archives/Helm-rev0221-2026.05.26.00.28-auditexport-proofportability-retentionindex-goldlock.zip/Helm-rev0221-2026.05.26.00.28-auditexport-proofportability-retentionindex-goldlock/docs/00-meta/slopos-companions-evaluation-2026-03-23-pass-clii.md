# SlopOS companions evaluation — 2026-03-23 pass CLII

## Purpose

Continue mining **SlopOS**, **ViewFS**, **Foundry**, **Harbor**, **Ward**, **Steward**, and **Schell**
after the exception-witness / waiver-lease pass by asking one tighter question:

**once Helm can say that motion is happening under an explicit exception,**
**how should it say where that rule or exception came from, what scope it really binds to, and what nearby candidates lost?**

## 1. SlopOS keeps teaching that exact policy authorship and veto-only lanes matter

SlopOS keeps pushing the same hard lesson:
policy-bearing material,
review-bearing material,
helper proposals,
and durable receipts should not collapse into one magic configuration soup.
That pressure matters for Helm because a datacube slice will eventually carry health,
action-fit,
watch,
and exception posture.
Once that happens,
people will need a truthful answer to **whose rule this really is**.

## 2. ViewFS is the strongest local teacher for this seam

ViewFS now has the crispest nearby grammar:
- **origin stacks**
- **trust shutters**
- **override ledgers**
- imported helper material that stays proposal-shaped
- effective winner chips that do not erase loser reasons

That is almost directly reusable for Helm,
with one translation:
Helm's objects are not config settings,
but reviewed slices,
health/use/exception surfaces,
and shell-side evidence.

## 3. Foundry reinforces layer and overlay humility

Foundry keeps teaching that overlays,
config layers,
confext checks,
and gates are neighboring but different truths.
For Helm that means a visible override or overlay should not silently become the active governing layer.
The shell needs a better answer to:
- active layer,
- advisory layer,
- blocked layer,
- and imported-only layer.

## 4. Harbor and Ward keep pushing scope and local-hold exactness

Harbor's timebound codes and risk ladders,
plus Ward's later-fact local holds,
keep suggesting that one visible rule may not cover all scopes or all times equally.
Helm therefore needs exact affected-scope posture and exact hold source,
not just one flattering all-clear or one frightening red badge.

## 5. Steward and Schell keep pressing lane separation

Steward keeps teaching that discovery,
readiness,
activation,
and presence are not the same thing.
Schell keeps teaching that proposal,
review,
and run remain separate even when they sit close together.
That is good pressure for Helm too:
source lane,
trust gate,
current winner,
and durable history should stay different seams.

## Product judgment

The admitted next shell-wide ratchet still stays **settlement witnesses + commit cards**.

But the next adjacent cluster now looks strong enough to name explicitly:
- **rule stacks**
- **trust shutters**
- **precedence traces**
- and maybe later **override ledgers**

The lesson Helm must keep learning from the companions is simple:
**active truth is not the same thing as visible alternative material.**

A super-useful Helm slice should be able to say:
- this is the active rule or exception posture,
- this is where it came from,
- this is the scope it actually binds to,
- these nearby candidates lost,
- these lost by precedence,
- these were withheld by trust,
- and these are merely imported or historical.

Keep it tiny.
Keep it inspectable.
Keep it weaker than shell truth.
