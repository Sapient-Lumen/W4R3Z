# Helm delivery witnesses + notice cards — 2026-03-23

## Narrow thesis

After **quiet witnesses**,
Helm still lacks one compact shell-owned answer to:

**what happened in the attention layer for this subject,
and how strong is that claim?**

That is not the same as:
- a watchpoint state
- a quiet witness
- an attention window
- a notification history dump
- a read cursor by itself
- or a generic inbox badge

It is the next seam those surfaces need in order to stop bluffing that “a thing showed up” means “a person saw it and handled it.”

## What to keep

Keep:
- the seven pillars
- typed action mode
- landmarks
- reality strips
- continuity postcards
- state tuples
- grounding witnesses + why rails
- delta briefs
- footing marks
- salience lenses
- coverage witnesses + blindspot rails
- quiet witnesses + stillness cards
- watchpoints,
  subscriptions,
  and attention windows

## What to peel away

Peel away:
- the assumption that posted means presented
- the assumption that presented means seen
- the assumption that read means acknowledged
- the assumption that acknowledged means fixed or adopted
- the assumption that a quiet inbox implies quiet source state
- one generic “handled” bit where `cleared`, `saved`, `snoozed`, and `acknowledged` should differ

## The next shell-wide seam

Helm should admit **delivery witnesses**,
with tiny nearby **notice cards**.

A delivery witness says:
- what exact subject,
  event family,
  or saved slice this attention claim belongs to
- which watchpoint,
  subscription,
  attention window,
  or lane relation produced it
- what exact audience / account / profile / device / lane the claim applies to
- what **delivery class** is being claimed
- whether presentation is known,
  unknown,
  or impossible to prove from the substrate
- whether the user merely read,
  cleared,
  saved,
  snoozed,
  or explicitly acknowledged the item
- and which reopen / inspect / compare / acknowledge / widen exit should open next

A notice card is the tiny derivative face for that claim.
It belongs in places like:
- Overview
- Recall
- watchpoint tiles
- subscription rows
- reality strips
- and session-attention surfaces

## Good first delivery classes

Good first classes look like:
- `eligible-not-delivered`
- `suppressed-by-window`
- `queued-for-digest`
- `delivered`
- `presented-unknown`
- `read`
- `cleared`
- `saved-for-later`
- `snoozed`
- `acknowledged`

## Why this is worth pulling now

Because once Helm can say both:
- **what kind of calm can I claim here?**
- and **what happened in the attention layer about it?**

its compact surfaces become dramatically safer to trust.

A watchpoint tile can say:
- quiet = `no threshold-crossing change observed`
- delivery = `queued for digest`
- next = `open digest lane`

A reality-strip chip can say:
- current live lane unchanged
- notice = `acknowledged by Alex; foreground unchanged`
- next = `open candidate lane`

An Overview card can say:
- `review-critical change observed`
- notice = `read on this device; saved for later`
- without pretending the shared lane already adopted the change.

## Pull-the-trigger judgment

It now looks wise to pull one narrow trigger:

**promote shell-owned delivery witnesses,
with tiny notice cards as their nearby face.**

That is the next honest move after quiet witnesses.
