# SlopOS + companion cubes evaluation — 2026-03-23 pass CXV

Purpose: continue evaluating SlopOS, Schell, ViewFS, and Steward now that Helm's next likely product jump is less about another noun family and more about **humane return loops, typed actions, and explicit parallel-session truth**.

## Strongest fresh pressure from SlopOS now

SlopOS keeps teaching Helm one uncomfortable but extremely valuable lesson:
**the convenience surface should never be allowed to smuggle stronger truth than the underlying seam actually owns.**

This pass makes four SlopOS lessons especially important.

### 1. Recent/history hints are not protocol truth

The OpenURI recent-items boundary keeps refusing a portable recent-items or reopen-authority plane on top of ordinary launch.
That is a giant gift to Helm.
It means Helm should keep treating:
- recents,
- Home/Overview lists,
- recall suggestions,
- and return-to-work hints

as **shell-owned weak cues**, not as silent durable authority or fake “still-live” proof.

### 2. Launch is not placement, reuse, or new-context truth

SlopOS's launch-disposition boundary refuses to collapse mediated open into tab choice, window reuse, split placement, or instance policy.
For Helm this matters immediately:
- Omnibox action mode should dispatch an exact act,
- but placement/reveal/bring-forward/new-lane choice should stay a nearby explicit rung when it matters.

The shell may make placement feel great.
It should not make placement folklore invisible.

### 3. Request identity is not current live grant truth

The background-request-state posture keeps request identity, dedupe identity, and current portal-owned grant state separate.
Helm should copy that discipline for helper lanes, work claims, session rosters, and adoption harbors:
- a work request is not an active helper,
- an active helper is not an adopted result,
- and an old receipt is not proof that the helper still holds live footing.

### 4. Workflow routing should stay explicit and non-oracular

The plumb posture refuses a durable hidden inbox, handler inventory oracle, or ambient launcher helper seam.
That directly strengthens Helm's typed-provider instinct.
Omnibox providers should stay:
- typed,
- attributable,
- explicit about subject and action family,
- and unable to masquerade as an invisible universal bus.

## Strongest fresh pressure from Schell now

Schell keeps getting more useful as Helm's teacher for **parallel luxury without live-lane ambiguity**.
Its repo lanes, live-checkout humility, and adoption gates argue for one more concrete Helm principle:

**parallel sessions need a roster, not just a pile of after-the-fact receipts.**

That means Helm should increasingly think in terms of:
- helper/session rosters,
- exact live-lane badges,
- adoption-ready versus still-shadow posture,
- and explicit drop/keep/adopt review.

## Strongest fresh pressure from ViewFS now

ViewFS remains Helm's best warning against over-trusting derived surfaces.
Its linked/derived/watch/history instincts keep pointing at the same law:
- linked views are useful,
- saved layouts are useful,
- history and bookmarks are useful,
- but they remain weaker than the exact subject truths underneath them.

That pressure now applies directly to Overview, Recall, and promoted landmarks.
A landmark can be wonderful.
It is still not the same thing as current-live proof.

## Strongest fresh pressure from Steward now

Steward keeps refining tiny status and claim-strength surfaces instead of one generic stale/alive glow.
That matters more as Helm gets richer return loops.
A return loop only feels trustworthy if the small chrome around it can say:
- current-live,
- remembered,
- held,
- drifted,
- adoption-ready,
- muted,
- or historical

without collapsing those into one flattering “looks fine” badge.

## What Helm should learn right now from the companions

### 1. Weak return surfaces are good; fake authority is not

Helm should keep building weak Overview and Recall cues.
It should keep refusing the idea that those cues can silently become live truth.

### 2. Exact action is different from exact placement

A shell can make actions feel incredibly direct while still keeping reveal/placement/reuse posture explicit.
That is worth protecting.

### 3. Session truth deserves first-class shape

Once helper or background work becomes common, the product should expose exact sessions and their footing rather than relying only on notifications, receipts, or vibes.

### 4. Landmarks should be promoted exact handles, not fuzzy nostalgia

Bookmarks, quicklinks, saved layouts, pinned commands, and front doors are all promising.
But they should remain exact shell-owned handles, not recency mush.

## Pull-the-trigger judgment

The companions still do **not** justify a new pillar.
They do justify one sharper next proof cluster:

**typed action mode + exact landmarks + session/adoption truth,**

because that cluster turns Helm's existing pillars into a stronger return loop while preserving the archive's hard laws about exactness, weak-versus-strong truth, and non-ambient power.
