# Research bibliography — 2026-03-23 pass CXVI

1. **Apple Spotlight actions and quick keys**
   - Why it mattered: Spotlight keeps reinforcing that actions should be globally summonable, keyboard-first, and promotable into faster repeat paths.
   - Helm pull: action mode should compose naturally with promoted action landmarks and exact action keys.

2. **Microsoft PowerToys Command Palette**
   - Why it mattered: Command Palette frames a broad summon surface as a fast command layer rather than just a search box.
   - Helm pull: Omnibox can stay broad if actions and landmarks remain structured and attributable.

3. **Apple Quick Look**
   - Why it mattered: weak preview remains the gold standard for inspect-before-commit.
   - Helm pull: landmarks and action templates should keep preview/promote posture close.

4. **Windows Click to Do**
   - Why it mattered: direct-on-screen selection keeps action delight precise instead of ambient.
   - Helm pull: exact selected slices should be promotable into reusable action landmarks without losing witness truth.

5. **VS Code agent sessions + Copilot CLI sessions**
   - Why it mattered: background and terminal sessions can stay visible, resumable, and tied to explicit repository/worktree choices.
   - Helm pull: session-attention lights and rosters should sit next to landmarks and adoption harbors.

6. **VS Code worktrees + Figma branching**
   - Why it mattered: parallel work stays trustworthy when it is isolated and clearly non-live until explicit review or merge.
   - Helm pull: session lights should report side-work posture without implying live adoption.

7. **Raycast Quicklinks**
   - Why it mattered: promoted links and templated quick searches show how intentional bookmarks beat casual history.
   - Helm pull: promoted landmarks should become a first-class exact family.

8. **Obsidian Bookmarks + Workspaces**
   - Why it mattered: bookmark groups and saved workspaces show a humane return stack built from promoted handles rather than giant dashboards.
   - Helm pull: grouped landmarks and saved layout starters are better than vague recents.

9. **Notion Home + Command Search**
   - Why it mattered: Home assembles tasks, calendar, and shortcuts while Command Search stays globally summonable.
   - Helm pull: weak Overview landing plus promoted landmarks plus command summon is the right product triangle.

10. **Windows Recall**
   - Why it mattered: searchable continuity is powerful, but giant memory capture is still a warning as much as an inspiration.
   - Helm pull: prefer exact timelines, landmarks, and session lights over screenshot-theater continuity.
