# Helm — read guarantee cards and consistency cuts

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one universal consistency layer.

The strongest next move is smaller:
**warm read guarantee cards + consistency cuts as the shell-owned seam above visibility frontiers.**

Helm can already say:
- what exact footing counted,
- what died,
- how it renewed or overlapped,
- what guard a cutover depended on,
- whether the boundary crossed,
- and which downstream observer or audience has caught up.

What it still answers too weakly is:
- **what exact read class is this surface showing right now?**
- **is this the freshest current read, a stable committed view, a boundedly stale nearby read, or just one audience's lagging view?**
- **what stronger reread or revalidation is required before a stronger consequence is honest?**

## The lesson Helm must learn from the past

Past systems repeatedly commit a second sin after `done` flattening:
**they flatten every read into `current enough`.**

That hides crucial operator truth:
- a node can know something newer than the majority-safe view;
- a replica can be query-visible without being the freshest current source;
- a cheap nearby read can be safe only because it sits behind a closed or bounded frontier;
- a search/index path can be visible at one cut while primary truth is already further ahead;
- and a globally current read may cost much more or require a stronger route than a boundedly stale one.

Helm should refuse the myth that one `open`, `view`, or `current` act always means the same read posture.

## What the outside world is teaching right now

### MongoDB: newer local view is not the same as majority-committed view
MongoDB keeps `read concern "majority"` explicit and says it returns data acknowledged by a majority and guaranteed not to roll back.
That is a direct precedent for Helm:
**one node's latest observed state can be a different class from the durable committed view you rely on.**

### PostgreSQL: replica durability and replica query visibility are different classes
PostgreSQL's `synchronous_commit` modes separate `remote_write`, `on`, and `remote_apply`.
That is extremely valuable pressure for Helm because it says:
- durable on a standby,
- durable after OS crash,
- and visible to queries on the standby

are different truths.

### Kafka: `read_committed` stops at the stable frontier, not the high watermark
Kafka's `isolation.level=read_committed` reads only through the last stable offset.
That is a direct precedent for Helm's need to show **stable frontier** rather than pretending every append-head is safe to read through.

### DynamoDB: committed is not the same as strongly current, and some paths stay eventual
DynamoDB explicitly offers eventually consistent versus strongly consistent reads, while GSIs and streams stay eventually consistent.
That is an excellent reminder that Helm should tell the truth about **path-specific read class**, not just object identity.

### CockroachDB and Spanner: cheap nearby reads are safe because their cuts are explicit
CockroachDB follower reads depend on `AS OF SYSTEM TIME` staying at or below the closed timestamp.
Spanner makes exact staleness and bounded staleness first-class timestamp bounds.
That is exactly the premium move Helm should steal:
**cheap nearby reads should be safe because the cut is named, not because the shell fakes present truth.**

## What the companion cubes are teaching now

### Keep from SlopOS
Keep exact basis discipline.
A read should stay bound to explicit witness material rather than ambient `latest` folklore.

### Keep from Ward
Ward is the clearest local teacher here.
Its read cuts,
staleness budgets,
ambiguity windows,
and revalidation fences are basically the perfect companion pressure for Helm's next seam.
Helm should steal the law even if it keeps lighter shell chrome.

### Keep from Schell
Keep `caught-up-through` humility and generation-lamp posture.
Schell keeps reminding Helm that one lane may honestly be current only through some boundary rather than to the absolute present.

### Keep from ViewFS
Keep the separation between observed validator,
private writable session,
commit precondition,
and committed version.
The next thing to preserve beside that split is the **read class of the version a person is actually looking at now**.

### Keep from Steward and Foundry
Steward's readiness-generation posture and Foundry's stale-status fences both reinforce the same rule:
old green status can remain historically correct while failing to describe the strongest current readable truth.

## Bright steals for Helm

1. **Read guarantee cards**
   - tiny cards like `majority-safe`, `exact-stale 4s`, `bounded stale <=15s`, `controller seen g12`, `search-visible`, `current strong`.
2. **Consistency cuts**
   - explicit saved read cuts that can be reopened,
     compared,
     or upgraded.
3. **Upgrade-read verbs**
   - `reopen stronger`, `revalidate on primary`, `refresh to stable frontier`, `compare cheap read to strong read`.
4. **Mixed-era alarms**
   - if one deck combines `search-visible`, `majority-safe`, and `desired g13 / observed g12`, Helm should admit the era mix instead of smoothing it away.
5. **Consequence fences**
   - stronger actions should say which read class they require,
     not just whether the object is visible.

## What not to keep

Do not keep:
- one shell-wide consistency taxonomy too early,
- one ambient `latest` read class,
- or one assumption that observer-visible implies strongest safe consequence.

The shell should keep a tiny grammar,
let providers supply evidence,
and preserve the ability to upgrade from a cheaper cut to a stronger cut.

## Why this makes Helm super awesome

This makes Helm feel premium in a way most systems still miss.
A person can ask:
- `what exact kind of read am I looking at?`
- `is this cheap because it is boundedly stale?`
- `is this majority-safe or merely locally latest?`
- `what stronger reread do I need before I promote, publish, or settle?`
- `what changed between the cheap read and the stronger one?`

That is a much better shell feel than one giant datacube center.
Not because Helm promises one truth,
but because it keeps **read truth classes** first-class and reopenable.
