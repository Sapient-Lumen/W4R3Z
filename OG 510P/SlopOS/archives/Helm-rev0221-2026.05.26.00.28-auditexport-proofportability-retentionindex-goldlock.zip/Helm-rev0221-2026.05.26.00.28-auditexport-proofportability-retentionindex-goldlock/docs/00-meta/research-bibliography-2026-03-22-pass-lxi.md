# Research bibliography — 2026-03-22 — pass LXI

## Sources used this pass

1. Atlassian Support — *Get started with playbooks*
   - URL: https://support.atlassian.com/jira-service-management-cloud/docs/get-started-with-playbooks/
   - used for: step-by-step playbooks plus automation rules as a bounded guided-response object

2. Atlassian Support — *Run a playbook and view outputs*
   - URL: https://support.atlassian.com/jira-service-management-cloud/docs/run-a-playbook-and-view-outputs/
   - used for: instructional-vs-automated steps, progress, execution outputs, and run status

3. Atlassian Support — *Playbook templates for Jira Service Management*
   - URL: https://support.atlassian.com/jira-service-management-cloud/docs/playbook-templates-for-jira-service-management/
   - used for: recurring templates with predefined steps and reusable automation mappings

4. Grafana docs — *Labels and annotations*
   - URL: https://grafana.com/docs/grafana/latest/alerting/fundamentals/alert-rules/annotation-label/
   - used for: runbook_url plus dashboard/panel linkage on alert rules

5. Grafana docs — *Template annotations and labels*
   - URL: https://grafana.com/docs/grafana/latest/alerting/alerting-rules/templates/
   - used for: dynamic instructions and customized runbook links based on query labels

6. Grafana docs — *Alerting best practices*
   - URL: https://grafana.com/docs/grafana/latest/alerting/guides/best-practices/
   - used for: first-responder-oriented actionable alert design and guidance linkage

7. PagerDuty Support — *Automation Actions*
   - URL: https://support.pagerduty.com/main/docs/automation-actions
   - used for: push-button diagnostics/remediation and visible action output logs

8. Datadog docs — *Context Links*
   - URL: https://docs.datadoghq.com/dashboards/guide/context-links/
   - used for: exact cross-surface jump grammar from widgets into related pages and third-party systems
