# SlopOS + companion-cube evaluation — 2026-03-23 — pass CXI

Purpose: test whether the next Helm move should be **exact remainder truth** after partial landing,
expired continuation,
or mixed provider/local aftermath — rather than another generic retry story or a bigger workflow machine.

## Main result

Yes.
The strongest aligned lesson from SlopOS,
Schell,
ViewFS,
and Steward is now:

**the exact unfinished / failed / unresolved slice is its own truth.**

Helm can now already say much more than it could a few revisions ago:
- what exact cohort the act started from
- what route or materialization happened
- what durable effect historically landed
- what exact continuation family is still alive now
- and what humane repair choices remain nearby

What still falls between those objects is this question:

**what exactly is still left?**

That surviving slice can be:
- remaining byte ranges
- failed indexes
- unresolved import rows
- pending recipients
- unresolved slots
- or another exact smaller remainder

and that slice is not always the same thing as:
- the original selected cohort
- the observed affected set
- the still-live continuation handle
- or the broad repair ladder

That keeps pointing toward one compact new support specimen:
- **remainder witnesses**

with one immediately useful consequence:
- **repair ladders should default to the remainder when that remainder is exact**

## What SlopOS is still teaching

### 1. Request identity and live provider state stay separate
SlopOS keeps refusing to let request ids,
lease descriptors,
and durable receipts pretend they are still-live provider state.
That same law now applies one level lower too:
if a provider can say what exact unfinished slice remains,
Helm should keep that as one exact witness instead of flattening it into “retry available.”

### 2. Import / materialization boundaries imply smaller aftermath objects
SlopOS repeatedly keeps promised,
materialized,
imported,
and durable-local truth separate.
That makes the next Helm lesson sharper:
a partial import or partial retrieval often leaves one smaller exact remainder,
not one vague failed operation.

### 3. Expired continuation should not erase useful remainder truth
One of SlopOS's best recurring laws is that dead live state should not erase durable historical evidence.
The same should hold for exact remaining work.
A continuation handle can expire while Helm still honestly knows:
- which byte ranges are still missing
- which rows were refused
- which recipients did not receive
- or which slots stayed unresolved

## What Schell is still teaching

Schell keeps pushing attach / restore / resume humility.
It keeps warning that “you can get back somewhere near there” is weaker than “you are still attached to the live thing.”
That same pressure now argues for one sibling truth:
**you may no longer have an exact live continuation handle,
but you can still know the exact remainder.**

That is excellent Helm pressure because it lets Recall,
Exchange,
and Operations Center preserve one smaller truthful next target without pretending the original continuation window survived.

## What ViewFS is still teaching

ViewFS remains the clearest teacher that:
- live now,
- exact handle,
- durable ref,
- and receipt-only
are different strengths.

The new payoff is that **remainder witness** looks like another middle strength:
- weaker than current-live truth
- often weaker than a still-live continuation handle
- but stronger than one vague failed/pending summary

It also is not the same as the original cohort.
The original cohort answers “what did we mean to operate on?”
The remainder answers “what exact smaller slice is still unfinished now or in aftermath memory?”

## What Steward is still teaching

Steward keeps insisting on dynamic conditions,
freshness decay,
and exact runtime-cycle evidence.
That is directly relevant here:
- a live handle can go stale
- a status badge can decay
- but the exact unfinished subset can still remain inspectable

Steward's freshness discipline is a reminder that remainder witnesses should also admit weather:
- exact and current
- shell-derived historical remainder
- stale-check-first
- partially unknown

## The practical lesson Helm must learn from the past

The past failure mode is still **false unification**.
The sharper form now is:

**do not let the original cohort,
the observed affected set,
the exact remainder,
the live continuation handle,
and the repair choices collapse into one cheerful retry story.**

If Helm gets this wrong,
it will quietly widen too much work,
lose the smallest honest rerun scope,
or pretend that dead continuation windows still answer “what is left?”

## Pull-the-trigger judgment

It looks wise to warm **remainder witnesses** now.
Not as a new pillar.
Not as a giant workflow graph.
But as one compact exact unfinished-slice object beside:
- effect receipts
- slot verdict ledgers
- continuation handles
- cohort windows
- affected-set witnesses
- and repair ladders

That feels like the smallest honest next answer to:

**what exactly is left,
and can Helm keep that smaller truth visible even after the live continuation window decays?**
