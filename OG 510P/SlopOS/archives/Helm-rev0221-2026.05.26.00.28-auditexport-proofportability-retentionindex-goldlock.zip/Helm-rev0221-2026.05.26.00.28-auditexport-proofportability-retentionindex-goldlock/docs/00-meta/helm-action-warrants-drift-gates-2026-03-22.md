# Helm action warrants + drift gates — 2026-03-22

Purpose: name the next compact shell move after explicit current context and explicit output claim posture.

## Main idea

Helm likely wants one shell-owned object for:

**what exact change is being proposed here,
and what exactly am I approving if I proceed?**

That object should be an **action warrant**.

And because many proposed changes rest on mutable basis,
Helm likely wants one small adjacent answer to:

**does this warrant still bind the thing I reviewed,
or did the basis drift enough that the stronger rung should disappear?**

That second surface should be a **drift gate**.

## Why this matters now

Helm already has several useful things that are close but not identical:

- **context loadouts** — what was intentionally in play
- **contribution witnesses** — what actually influenced the run
- **claim envelopes** — what the result is claiming
- **reliance ladders** — the right next responsible move
- **review tickets** — stable-enough review slices
- **basis packets** — tiny basis witness strips
- **current-live beacons** — what is actually live right now

What Helm still lacks is one compact shell-owned answer to:

- this exact edit / route / attach / import / delete / apply action
- on this exact reviewed basis
- with this exact affected-set story
- under this exact context posture
- is what you are being asked to approve right now

Without that,
Helm risks slipping back into:
- Apply buttons that flatter the operator about what will really happen,
- preview cards that silently stay valid after drift,
- strong actions that piggyback on generic open/status surfaces,
- and AI-assisted edits that look precise without an exact approved-effect object.

## What an action warrant is

An **action warrant** is a compact shell-owned bounded action object for one strong proposed change.

A useful first warrant would carry:
- exact proposed effect
- exact target / subject
- exact reviewed basis witness
- affected-set witness or diff-like summary
- context/loadout witness when relevant
- privilege or follow-on-risk posture when relevant
- honest next-step ladder

The point is not the noun.
The point is the law:

**strong proposed change is explicit.**

## What a drift gate is

A **drift gate** is the compact shell-owned gate next to an action warrant that says whether the warrant is still eligible for its stronger next rung.

A useful first drift gate should be able to say things like:
- exact match → stronger rung still available
- drifted → review again
- partial match → inspect and refresh bind
- unknown → hold / inspect-only
- privileged follow-on blocked until separate approval

This is much better Helm magic than:
- one green badge,
- one confidence number,
- or an ordinary Apply button that hides basis drift.

## Relation to nearby Helm objects

### Not a claim envelope
A claim envelope explains what the output is saying.
An action warrant explains the exact strong change being proposed.

### Not a receipt
A receipt is durable evidence that the stronger act happened.
An action warrant sits before that.

### Not a review ticket
A review ticket gives you a bounded stable slice for paging and comparing.
An action warrant is the specific exact proposed change that may emerge from such a review.

### Not merely a basis packet
A basis packet is the tiny basis witness.
An action warrant is the stronger whole object that uses basis,
effect,
affected-set,
and next-step posture together.

## Why this seems especially worth stealing

Current products are converging on three good habits:
- reviewable proposal objects instead of invisible in-place mutation
- explicit apply/undo or review/merge boundaries
- separate approval for more privileged follow-on execution

Helm can be unusually good here.
The shell can make action warrants reusable across:
- Omnibox
- Object Browser
- Recall
- Exchange
- Desktop Flow
- Operations Center
- terminal/capshell
- and AI-assisted propose/apply surfaces

## Super-awesome moves this unlocks

### 1. Exact apply cards instead of vague “looks good?” blobs
A proposed edit,
attach,
route,
rebind,
import,
or publish action can live in one compact warrant.

### 2. Privileged follow-on as a separate stronger rung
A warrant can allow:
- inspect,
- adopt,
- apply,
- or approve-and-run
without pretending those are one thing.

### 3. Drift-aware return to half-reviewed actions
A saved or reopened warrant can come back with:
- still exact,
- drifted,
- partial,
- or expired posture.

### 4. Better AI-assisted shell actions
Helm can feel smarter because it can propose exact strong actions,
without hiding the actual target,
basis,
or risk posture.

### 5. Safer delegation without giant workflow religion
Delegated work can return as a warrant for review,
not as ambiently-mutated live truth.

## What not to steal

- do not turn every tiny operation into PR theater
- do not let one warrant become a universal workflow bureaucracy
- do not let warrants quietly survive basis drift
- do not let a warrant impersonate a receipt
- do not let generic preview/open/status surfaces smuggle warrant semantics

## Pull-the-trigger judgment

Still yes:
- **saved view objects**
- **checkpoint branches**

Now also worth defining as support contracts:
- **action warrants**
- **drift gates**

If Helm gets this right,
it can feel much stronger on the action side without adding another pillar,
because it will finally have one honest shell-owned answer to:

**what exact thing am I approving right now?**
