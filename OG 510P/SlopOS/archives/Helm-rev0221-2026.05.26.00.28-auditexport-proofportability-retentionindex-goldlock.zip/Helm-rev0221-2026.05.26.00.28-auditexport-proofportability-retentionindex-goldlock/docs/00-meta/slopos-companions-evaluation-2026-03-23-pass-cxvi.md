# SlopOS + companion cubes evaluation — 2026-03-23 pass CXVI

Purpose: continue evaluating SlopOS, Schell, ViewFS, and Steward now that Helm has admitted typed action mode and needs to decide what should become **durable promoted return power** versus what should stay **weak orientation only**.

## Strongest fresh pressure from SlopOS now

SlopOS keeps giving Helm the same hard gift:
**the shell must never let a convenience surface claim stronger truth than the underlying seam actually owns.**

This pass makes three SlopOS lessons especially important.

### 1. Recent-items posture means landmarks must be promoted, not inherited

The OpenURI recent-items boundary keeps refusing to let ordinary launch become durable reopen authority or a portable history plane.
That means Helm should keep a hard distinction between:
- casual history,
- shell-owned recents,
- and promoted landmarks.

A landmark can be exact and durable-looking.
It should still be an explicit shell-owned promoted handle, not a recent row that slowly gained folklore.

### 2. Launch completion humility means landmark weather is not current-live truth

The OpenURI launch-completion boundary keeps refusing to treat launch admission as proof that the target completed, rendered, or was really consumed.
That directly strengthens a Helm landmark law:
- a landmark may have weather,
- but weather is not identity,
- and identity is not current-live truth.

A return point can say historical, drifted, or attention-needed without pretending it proves the live lane.

### 3. Lease-descriptor posture means old receipts and descriptors do not prove current helper state

The lease-descriptor state boundary keeps issuance evidence separate from current live state.
Helm should copy that discipline for session lights and adoption harbors:
- a work claim is not a running helper,
- a helper receipt is not current session footing,
- and a landmark back to side work is not proof that the side lane is still safe to adopt.

## Strongest fresh pressure from ViewFS now

ViewFS keeps making the landmark shape clearer.
Its advisory recents/palettes rule and handles/refs/receipts split together imply that a Helm landmark should be treated as:
- a promoted exact handle or typed template,
- maybe with attached weak organization or weather,
- but not as a replacement for live handle truth or receipt truth.

That is a major simplification.
Helm does not need landmark magic.
It needs **promoted exactness plus honest weather**.

## Strongest fresh pressure from Schell now

Schell keeps proving that side work becomes humane only when session truth is directly inspectable.
Its session-lineage and repo-lane posture keep pointing at the same Helm conclusion:
- landmarks should get you back in,
- but session lights should tell you whether there is anything alive, drifted, adoption-ready, or waiting.

That is why session lights now look like the right weak companion to landmarks instead of another giant helper dashboard.

## Strongest fresh pressure from Steward now

Steward keeps reinforcing tiny typed status and claim-strength cues.
That matters more once landmarks exist.
A promoted return point only feels trustworthy if nearby chrome can say:
- live,
- historical,
- drifted,
- held,
- muted,
- or adoption-needed

without turning those statuses into fake authority.

## What Helm should learn right now from the companions

### 1. Promotion should be explicit
Landmarks should be promoted exact handles or typed templates, not auto-grown recents.

### 2. Landmark weather should stay weaker than current-live truth
Helpful status is good.
Overclaiming is not.

### 3. Session attention deserves shell-owned visibility
If there is helper or background work, the shell should surface it directly rather than relying on after-the-fact receipts or notification folklore.

### 4. Overview should assemble, not rule
Landmarks and session lights both point toward a weak landing surface, not a new master plane.

## Pull-the-trigger judgment

The companion cubes still do **not** justify a new pillar.
They do justify one sharper next move:

**admit a landmark protocol, keep session lights warm, and keep both weaker than current-live truth.**

That is the most coherent way to turn action mode, Recall, Overview, and helper-side work into one humane return loop without freezing a giant dashboard or memory object.
