# Research bibliography — 2026-03-22 — pass LIX

1. **Linear Docs — Custom Views**
   - source: https://linear.app/docs/custom-views
   - used for: saved/shared/favorited custom views and using favorite views as a default page

2. **Linear Docs — Favorites**
   - source: https://linear.app/docs/favorites
   - used for: sidebar favorites plus favorite folders as a bounded personal grouping surface

3. **Raycast Manual — Quicklinks (Windows manual)**
   - source: https://manual.raycast.com/windows/quicklinks
   - used for: tiny exact handles over URLs, file paths, and deeplinks

4. **Raycast Manual — Shared Quicklinks**
   - source: https://manual.raycast.com/quicklinks/shared-quicklinks
   - used for: personal versus shared quicklink posture and organization-scoped handles

5. **Airtable Support — Interface layout: Overview**
   - source: https://support.airtable.com/docs/airtable-interface-layout-overview
   - used for: weak landing pages that highlight key pages and resources rather than becoming the authority plane

6. **Grafana Docs — Dashboard list**
   - source: https://grafana.com/docs/grafana/latest/visualizations/panels-visualizations/visualizations/dashboard-list/
   - used for: dynamic lists based on starred, recent, search-query, and tag-backed membership

7. **Grafana Docs — Manage playlists**
   - source: https://grafana.com/docs/grafana/latest/visualizations/dashboards/create-manage-playlists/
   - used for: ordered sequential rounds and situational-awareness playback

8. **Grafana Docs — Manage dashboard links**
   - source: https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/manage-dashboard-links/
   - used for: explicit dashboard/panel/data links as related-surface jumps

9. **Grafana Docs — Configure data links and actions**
   - source: https://grafana.com/docs/grafana/latest/visualizations/panels-visualizations/configure-data-links/
   - used for: context-carrying links and actions that preserve source context

10. **Atlassian Analytics — Home page**
    - source: https://support.atlassian.com/analytics/docs/home-page/
    - used for: a home/catalog surface that remains weaker than the dashboards it links to
