# Helm revisit witnesses + wake cards — 2026-03-23

## Why this pass exists

After state tuples,
why rails,
delta briefs,
footing marks,
salience lenses,
coverage witnesses,
quiet witnesses,
delivery witnesses,
and disposition witnesses,
Helm can now say a lot about a surfaced thing.

But it still lacked one small answer to a very practical question:

**when or why should this come back?**

That answer should not be hidden in:
- a due date badge
- a snooze chip
- a delivery witness
- a disposition witness
- a patrol route by itself
- a source-side reminder
- or the underlying source status

It needs its own compact shell-owned truth object.

## Main judgment

Helm should now admit **revisit witnesses**,
with tiny nearby **wake cards**.

A revisit witness is not:
- the source truth
- the delivery witness
- the disposition witness
- the current-live beacon
- the patrol route
- the final outcome
- or a generic scheduler

It is the exact answer to:
- what return law is armed for this surfaced thing?
- is the return time-based,
  activity-based,
  footing-based,
  timeout-based,
  or due-soon?
- who armed it,
  for what lane,
  and with what audience scope?
- when does it wake,
  expire,
  degrade,
  or become overdue?
- and what exact stronger surface should redeem the wake?

## Why this matters for Helm's pillars

### Overview
Overview can now stay weak but still say:
- `saved for later • wake tomorrow 10am`
- `delegated • return on new activity`
- `review lane • due soon`
- `acknowledged • timeout returns in 18m`

without pretending those are source outcomes.

### Recall
Recall can explain not just what changed and what stance was chosen,
but what return law now exists:
- `last seen, accepted, wake on basis drift`
- `saved, remind Friday 09:00`
- `snoozed until next activity`

### Operations Center
Ops rows can stop flattening:
- snoozed
- due soon
- timed return
- next patrol round
- and timeout-based resurface

into one vague “later” bit.

### Omnibox / Object Browser
Helm can offer exact next-step verbs like:
- remind-at
- snooze-until
- wake-on-new-activity
- review-again-on-drift
- attach-to-patrol-round
- re-arm-after-timeout

without assuming the subject itself changed yet.

## What Helm should steal

- GitHub's scheduled reminders
- Slack's separate save-versus-remind posture
- Linear's `time or new activity, whichever comes first` wake rule
- PagerDuty's acknowledgement-timeout and snooze-expiry returns
- Notion's simple date/time reminder posture

## What Helm should refuse

- one universal “later” bit
- treating due dates as delivered attention
- treating reminders as proof of progress
- treating personal wake law as team law
- treating revisits as another giant inbox or task engine

## Pull-the-trigger conclusion

The next good Helm move is not another pillar.
It is one more cross-pillar ratchet:

**delivery truth tells you what happened in attention.**
**disposition truth tells you what stance was chosen.**
**revisit truth tells you when or why it should come back.**

That is the missing seam between triage posture and trustworthy followthrough.
