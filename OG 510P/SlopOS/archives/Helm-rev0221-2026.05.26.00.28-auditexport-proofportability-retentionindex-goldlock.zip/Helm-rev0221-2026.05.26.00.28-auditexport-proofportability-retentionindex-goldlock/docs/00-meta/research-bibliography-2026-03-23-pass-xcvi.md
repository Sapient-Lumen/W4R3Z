# Research bibliography — 2026-03-23 — pass XCVI

- Apple Platform Security — Gatekeeper and runtime protection in macOS
  - used for: downloaded-software verification,
    first-open approval posture,
    provenance tracking for files written by downloaded software
- Microsoft Learn — Attachment Manager policy settings
  - used for: zone-of-origin information,
    risk assessment posture,
    the warning that removing zone information weakens protection
- Microsoft Learn — Macros from the internet are blocked by default in Office
  - used for: Mark-of-the-Web as a separate arrival-risk signal,
    guarded handling,
    and explicit unblock posture
- Google Safe Browsing overview
  - used for: visible unsafe-resource classification,
    dangerous-content posture,
    and user-visible warning seams
- Chrome Help — Download a file / dangerous-download warnings
  - used for: dangerous / suspicious / unverified / insecure download classes and override posture
- VS Code documentation — Workspace Trust / Restricted Mode
  - used for: browse-first / trust-later posture,
    visible restricted chrome,
    and keeping auto-execution blocked until explicit trust
- ViewFS — `origin-quarantine-and-trust-transitions.md`
  - used for: exact seam split between origin, quarantine, safe-open, trust, derivative, and live authority
- ViewFS RFC 0015 — keep origin, quarantine, safe-open, and trust transitions on separate seams
  - used for: adoption-test language and anti-collapse posture
- Schell — `object-cards-exact-reveal-and-safe-open-honesty.md`
  - used for: exact reveal,
    safe-open ladders,
    and staging-before-launch posture
