# Helm promotion contracts and simulation drills — 2026-05-13

## Headline

rev0189 moves Helm from checked **cards** to checked **moves**.

A surface affordance card says what a chip/button may show. A lane transition contract says what must be preserved, rechecked, gated, refused, or minted when the operator presses that button.

## Pull-the-trigger decision

Admit `lane_transition_contract` as a fixture-side proof object.

Do not admit a workflow engine, backend, global query language, or new pillar yet.

## Why now

rev0188 could prove that a stale card shows `recheck` instead of `promote`. But the next likely lie is subtler: a correct button changes the world and the target surface quietly forgets why the move was lawful.

Helm needs transition contracts before UI polish because the premium product loop is all about movement:

- summon a door pack;
- turn it into a saved view candidate;
- arm a patrol route;
- queue a review cut;
- recheck the cut against live truth;
- promote with a receipt;
- recall the receipt later as history.

Each move should feel fast. Each move must also confess what it is weaker than.

## Lessons we must learn from the past

1. **Workflow glamour hides truth collapse.** Rich products often make the transition beautiful and forget to say what changed truth class.
2. **Queues can launder authority.** A review queue item can look like approval even when it is only a cut waiting for recheck.
3. **Saved views are setup, not reality.** Reuse is powerful only if definition revision and live recheck remain visible.
4. **Patrol routes must not become background approval.** Automation can watch and queue; consequence still needs a gate.
5. **Receipts are scoped history.** A receipt records what Helm did. It does not prove current provider state.
6. **Import/adoption/promote must stay separated.** SlopOS is right about refusing imported semantics as portable truth; Helm should express that refusal as product chips and contracts.
7. **A drill is better than a doctrine pile.** If a concept cannot run through a small specimen fixture, it is not ready to become core Helm law.

## Nifty ideas worth stealing now

- from semantic layers: stable definitions and composability, but only with source cuts and allowed dimensions visible;
- from materialized query systems: acceleration witnesses and refresh keys, but never invisible freshness;
- from table/lake versioning: branches/tags/snapshots as named cuts, but not lakehouse lock-in;
- from lineage systems: extensible facets around a run or dataset, but not a surveillance graph;
- from context propagation: small carried context, but not global identity truth;
- from triage and merge queues: stage, recheck, group, reject, and receipt before consequence;
- from saved/personal/locked views: different collaboration postures, but not a belief that view configuration equals data truth.

## High-value Helm move

Prototype the Release readiness drill as an on-screen **truth rail** beside the Operations Center card stack. Every row should show:

- lane;
- cut;
- posture;
- next contract;
- gate state;
- receipt or recheck requirement;
- what the row is weaker than.

This could become one of Helm's signature pleasures: the user moves faster because the shell does not hide the epistemic debt.

## What not to keep from SlopOS

Do not copy full boundary-family machinery into Helm. It is excellent for an OS assurance archive and too heavy for the shell product surface.

Keep the lesson: exact imported/request/local/admission/evidence semantics must not widen by implication.

Translate it into product-sized artifacts: chips, cards, contracts, stale fences, and drills.
