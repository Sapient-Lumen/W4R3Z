# Research bibliography — 2026-03-22 — pass XL

Primary references consulted for this pass:

- Notion docs — Working with views:
  https://developers.notion.com/guides/data-apis/working-with-views
- Notion docs — Create a view query:
  https://developers.notion.com/reference/create-view-query
- Notion docs — Get view query results:
  https://developers.notion.com/reference/get-view-query-results
- VS Code docs — Workspace Trust:
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- VS Code docs — Manage chat sessions:
  https://code.visualstudio.com/docs/copilot/chat/chat-sessions
- VS Code docs — Revert changes with checkpoints and editing requests:
  https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- PowerToys docs — Workspaces utility:
  https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- Warp docs — Session Management:
  https://docs.warp.dev/terminal/sessions
- Warp docs — Session Restoration:
  https://docs.warp.dev/terminal/sessions/session-restoration
- Chrome Help — Manage tabs in Chrome (desktop):
  https://support.google.com/chrome/answer/2391819?co=GENIE.Platform%3DDesktop&hl=en
- Obsidian docs — Workspaces:
  https://help.obsidian.md/plugins/workspaces
- Obsidian docs — How Obsidian stores data:
  https://help.obsidian.md/data-storage
- Figma docs — Guide to branching:
  https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
- Figma docs — Review branch changes:
  https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes
- Figma docs — View a file's version history:
  https://help.figma.com/hc/en-us/articles/360038006754-View-a-file-s-version-history
