# Helm: helper escorts + downscoped delegation — 2026-03-23

## Headline

Helm should make helpers feel more capable **by escorting them narrowly**,
not by letting them borrow the operator's whole weather system.

The next compact move worth warming is:

- **helper escorts**
- with explicit **downscoped delegation** posture

## Why now

Helm already has a lot of nearby law:
- shadow work lanes
- adoption harbors
- action warrants
- capability budgets
- authority windows
- lease windows
- gesture runways
- delegation subtrees
- caveat sheets
- trusted chrome lanes

What it still lacks is one humane object for this question:

**how can a helper,
repair lane,
or delegated flow do valuable bounded work without inheriting the operator's ambient reach or impersonating the operator's final authorship?**

## The move

A helper escort should carry:
- one exact helper or delegated lane identity
- one exact subject or bounded cohort
- one narrowed family of allowed operations
- one visible file/object / network / provider scope
- one expiry or use budget
- one basis or observation witness when relevant
- one explicit statement of what the helper may only prepare,
  not finish
- one nearby narrow / revoke / renew / inspect path

## Why this is different from nearby objects

- **authority window** = what authority exists or existed
- **shadow work lane** = where delegated candidate work lives
- **gesture runway** = the prepared final human seam for one sensitive act
- **delegation subtree** = ancestry and blast radius map
- **helper escort** = the narrow helper-side slice of power itself

That distinction matters.
Without it,
Helm risks either:
- giant helper bureaucracy,
- or helpers that quietly wear the operator's badge.

## What to keep from older inspirations

Keep:
- capability attenuation
- time-bounded and use-bounded delegation
- one-time / only-this-time posture
- exact subject binding
- approval and justification when truly needed
- tokens or bookmarks that can persist as **scoped** carryover
- revocation and expiry as normal healthy endings

Peel away:
- broad ambient helper inheritance
- bearer folklore as the product surface
- giant token consoles
- permanent helper superpowers just because setup once felt convenient
- magical replays of old helper authority from historical receipts

## Why this could make Helm super awesome

### 1. Helpers become trustworthy by default
A helper can feel smart because it can:
- inspect exact objects,
- gather evidence,
- compute diffs,
- draft actions,
- stage handoff packets,
- and prepare runways,
without being allowed to silently publish,
send,
reveal broadly,
or spend direct human seams.

### 2. The operator finally gets a truthful nearby helper card
Helm could show:
- who the helper is
- what it can currently see or touch
- what it is blocked from doing
- when the escort expires
- and how to narrow,
  renew,
  or revoke it

That is much more humane than ambient assistant mysticism.

### 3. Delegation can degrade honestly
An escort can shift from:
- `active`
- to `expiring`
- to `boundary-hit`
- to `expired`
- to `historical-only`
without implying that saved setup still equals live power.

### 4. Stronger acts stay glorious
The escort does not kill magic.
It makes the *good* magic possible:
- helper prepares beautifully
- operator sees exact proposal
- final strong act still happens through warrant,
  adoption,
  or runway

That sequence is much more impressive than fake autonomy.

## Pull-the-trigger judgment

Helm still should not freeze giant helper architecture.
But it probably **is** time to warm one compact specimen:

**helper escorts — shell-owned downscoped delegation objects that let helpers do narrow,
expiring,
non-amplifying work over exact subjects while preserving the operator's stronger authorship,
live authority,
and final human seams.**
