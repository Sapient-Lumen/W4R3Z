# Helm pillar proof map — 2026-03-22

Purpose: flesh out the seven pillars,
plus Terminal/Capshell,
without prematurely freezing giant family machinery.

Each pillar gets three buckets:
- **prove soon** — the next concrete specimen worth building or pinning harder
- **keep warm** — strong pressure worth preserving without overcommitting
- **refuse** — a temptation likely to make Helm less honest

## Global rule

Helm should currently freeze **cross-pillar verbs** more confidently than **cross-pillar mega-objects**.
The verbs worth converging now are:
- peek
- inspect scope
- inspect basis
- promote
- review
- grant once / this activity / persistent
- adopt
- repair
- revoke

## 1. Tiling Shell

### Prove soon
- **peek → split / focus / open** as a first-class promotion ladder
- **saved layout as front door** rather than as fake continuity

### Keep warm
- profile-scoped spaces
- stronger adjacent inspection and compare surfaces

### Refuse
- layout religion as product identity
- saved placement pretending to be current-live truth

## 2. Omnibox

### Prove soon
- **parameterized front doors** with typed placeholders
- **review freshness chips** beside stronger launch or apply actions

### Keep warm
- suggestion-first triage hints
- typed pivots over object,
action,
route,
and receipt families

### Refuse
- one mixed row that blurs preview,
execution,
and live completion
- ambient context scraping masquerading as intelligence

## 3. Object Browser

### Prove soon
- **exact reveal + weak preview + explicit promote**
- **linked weak views** that stay visibly weaker than source truth

### Keep warm
- context modes
- per-instance compare / per-instance review when downstream effects are concrete

### Refuse
- giant dashboard collapse
- labels or browser chrome quietly becoming object identity

## 4. Operations Center

### Prove soon
- **triage lane** for sorting,
routing,
and adoption
- **observe / attach / control** distinction for live sessions and background work

### Keep warm
- designated-review lanes
- richer explanation drawers for why something is stale,
denied,
held,
or suggested

### Refuse
- admin-console cosplay
- silent auto-apply or hidden background mutation

## 5. Desktop Flow

### Prove soon
- **saved-plan → inspect → apply** posture for stronger flows
- **shadow lane / adoption harbor** for delegated or background-generated work

### Keep warm
- managed-facet ownership
- collaborative partial-authority edits

### Refuse
- decorative spaghetti canvases
- “the agent did it” as enough provenance

## 6. Recall

### Prove soon
- **current-live beacon** that clearly outranks generic recents
- **continuity postcards** that say exact return,
repaired return,
historical only,
or adoption-needed

### Keep warm
- checkpoint branches
- private and local recall controls

### Refuse
- one total timeline religion
- restored labels quietly impersonating current-live truth

## 7. Exchange

### Prove soon
- **exact-scope share/import** with inspectable audience or cohort
- **receiver-fit cards** before stronger import/adoption

### Keep warm
- weak synced mirrors for read-mostly reuse
- visibility-only audience lanes

### Refuse
- ambient sync mythology
- publication pretending to be receiver-side activation

## 8. Terminal/Capshell

### Prove soon
- **title/source witness chips** so chrome can admit shell,
override,
restored,
profile,
or imported posture
- **reviewed action receipts** that stay stronger than terminal-local folklore

### Keep warm
- semantic marks and exact handoff slices
- shell/terminal zones for prompt,
input,
output,
review,
and receipt

### Refuse
- cwd/env/session mythology as master ontology
- terminal-local history pretending to be desktop truth

## Best five-proof sequence right now

1. parameterized front doors
2. peek → promote
3. exact-scope grants
4. triage lane + explain-why suggestions
5. continuity postcards

## Closing judgment

This is enough pillar shape for now.
If Helm proves these specimens well,
it can keep the pillars stable while learning a lot more before larger freezes.
