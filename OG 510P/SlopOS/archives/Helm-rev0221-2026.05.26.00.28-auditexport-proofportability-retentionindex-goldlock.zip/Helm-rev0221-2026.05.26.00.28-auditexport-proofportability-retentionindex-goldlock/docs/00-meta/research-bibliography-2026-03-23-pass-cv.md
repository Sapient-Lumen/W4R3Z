# Research bibliography — 2026-03-23 — pass CV

## Primary outside sources reviewed in this pass

1. Apple Developer Documentation — **NSItemProvider**
   - URL: https://developer.apple.com/documentation/Foundation/NSItemProvider
   - Why it mattered: one item can convey data or a file across drag/drop, copy/paste, and extension handoff; useful proof that Exchange should preserve offered representations.

2. Apple Developer Documentation — **registerDataRepresentation / registerFileRepresentation / previewImageHandler**
   - URLs:
     - https://developer.apple.com/documentation/foundation/nsitemprovider/registerdatarepresentation%28for%3Avisibility%3Aloadhandler%3A%29
     - https://developer.apple.com/documentation/Foundation/NSItemProvider/registerFileRepresentation%28for%3Avisibility%3AopenInPlace%3AloadHandler%3A%29
     - https://developer.apple.com/documentation/foundation/nsitemprovider/previewimagehandler
   - Why it mattered: representation-specific load handlers, open-in-place posture, and preview hints.

3. Apple Developer Documentation — **NSFilePromiseProvider / file promises**
   - URLs:
     - https://developer.apple.com/documentation/appkit/nsfilepromiseprovider
     - https://developer.apple.com/documentation/AppKit/supporting-collection-view-drag-and-drop-through-file-promises
   - Why it mattered: promised future files and deferred materialization until drop/promise completion.

4. Microsoft Learn — **DataPackage / SetDataProvider**
   - URLs:
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage?view=winrt-26100
     - https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.datatransfer.datapackage.setdataprovider?view=winrt-26100
   - Why it mattered: enumerable formats, available-format inspection, and deferred expensive packaging until the target actually requests a format.

5. Android Developers — **Send simple data / Direct Share targets**
   - URLs:
     - https://developer.android.com/training/sharing/send
     - https://developer.android.com/training/sharing/direct-share-targets
   - Why it mattered: specific MIME discipline, previewable Sharesheet content, prepublished direct-share targets for speed, stale-target hygiene, and exact chosen-target followthrough.

6. Chrome for Developers / MDN — **File System Access drag-and-drop handles**
   - URLs:
     - https://developer.chrome.com/docs/capabilities/web-apis/file-system-access
     - https://developer.mozilla.org/en-US/docs/Web/API/DataTransferItem/getAsFileSystemHandle
   - Why it mattered: file-versus-directory handle truth, stronger dropped handles, and explicit experimental / limited-availability posture.

## Companion-cube surfaces re-read in this pass

### SlopOS
- `docs/30-architecture/mcp-completion-import-boundary-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
- `docs/30-architecture/openuri-session-selection-boundary-v0.md`

### ViewFS
- `docs/20-assurance/non-claims.md`
- `docs/30-architecture/observe-attach-control-and-sideband-lanes.md`

### Schell
- ingress / selection / remote-handoff notes carried forward in the current archive

### Steward
- `docs/30-architecture/link-surface-posture-v0.md`
- `docs/30-architecture/workspace-snapshot-posture-v0.md`

## Bottom line

This pass reinforces a compact Exchange law worth keeping close:
**offered material,
chosen route,
materialized receiver state,
and later receipts are different strengths,
and Helm should preserve that distinction instead of flattening everything into one “shared thing.”**
