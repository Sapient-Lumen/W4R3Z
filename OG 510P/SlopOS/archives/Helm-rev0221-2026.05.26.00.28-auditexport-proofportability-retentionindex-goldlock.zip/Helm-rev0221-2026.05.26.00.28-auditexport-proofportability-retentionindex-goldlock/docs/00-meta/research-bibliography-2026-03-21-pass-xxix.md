# Research bibliography — 2026-03-21 pass XXIX

## Primary outside sources used in this pass

- Visual Studio Code docs — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Visual Studio Code release notes — **December 2025 (version 1.108)**
  - https://code.visualstudio.com/updates/v1_108
- Visual Studio Code docs — **Workspace Trust**
  - https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- Visual Studio Code docs — **Copilot CLI sessions in Visual Studio Code**
  - https://code.visualstudio.com/docs/copilot/agents/copilot-cli
- Visual Studio Code release notes — **November 2025 (version 1.107)**
  - https://code.visualstudio.com/updates/v1_107
- Figma Help — **Guide to branching**
  - https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
- Figma Help — **Review branch changes**
  - https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes
- Figma Help — **Merge branch into main file**
  - https://help.figma.com/hc/en-us/articles/5691189138839-Merge-branch-into-main-file
- Figma Help — **Code Connect**
  - https://help.figma.com/hc/en-us/articles/23920389749655-Code-Connect
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Warp docs — **Launch Configurations**
  - https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp docs — **URI Scheme**
  - https://docs.warp.dev/terminal/more-features/uri-scheme
- Warp docs — **Session Navigation**
  - https://docs.warp.dev/terminal/sessions/session-navigation
- Warp docs — **Markdown Viewer**
  - https://docs.warp.dev/terminal/more-features/markdown-viewer
- WezTerm docs — **Multiplexing**
  - https://wezterm.org/multiplexing.html

## Main local teacher documents re-opened in SlopOS rev0585

- `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- `docs/30-architecture/approval-basis-posture-v0.md`
- `docs/30-architecture/lease-descriptor-state-boundary-v0.md`
- `docs/30-architecture/openuri-materialization-boundary-v0.md`
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
- `docs/30-architecture/capability-semantics.md`

## What these sources mainly taught this pass

- **VS Code Profiles / drag-and-drop import / worktree isolation**: arrivals should be previewable,
  inspectable,
  and review/apply shaped rather than instantly live
- **Figma branching / review / merge**: compare-before-merge and review-again flows keep candidate changes weaker than adopted main truth
- **Warp Launch Configurations / URI / Session Navigation**: saved/session structures are strongest when launch targets remain explicit,
  inspectable,
  and keyboard-addressable
- **SlopOS exactness and approval-basis postures**: exact requests and exact reviewed basis should fail closed rather than degrade into “something nearby” success
