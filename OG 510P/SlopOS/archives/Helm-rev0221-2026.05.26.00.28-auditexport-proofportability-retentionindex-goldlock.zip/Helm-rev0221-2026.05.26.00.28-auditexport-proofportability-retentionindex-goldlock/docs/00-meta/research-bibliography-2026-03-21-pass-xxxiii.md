# Research bibliography — 2026-03-21 pass XXXIII

## Primary outside sources used in this pass

- Visual Studio Code docs — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Visual Studio Code docs — **Git Branches and Worktrees in VS Code**
  - https://code.visualstudio.com/docs/sourcecontrol/branches-worktrees
- Visual Studio Code release notes — **December 2025 (version 1.108)**
  - https://code.visualstudio.com/updates/v1_108
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Figma Help — **Compare changes in Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Figma Help — **Review and accept library updates**
  - https://help.figma.com/hc/en-us/articles/360039234193-Review-and-accept-library-updates
- Figma Help — **Swap components and instances**
  - https://help.figma.com/hc/en-us/articles/360039150413-Swap-components-and-instances
- Obsidian Help — **Introduction to Bases**
  - https://obsidian.md/help/bases
- Obsidian Help — **How Obsidian stores data**
  - https://obsidian.md/help/data-storage
- Raycast Manual — **Cloud Sync**
  - https://manual.raycast.com/cloud-sync
- Raycast Manual — **Shared Quicklinks**
  - https://manual.raycast.com/quicklinks/shared-quicklinks

## Main local teacher documents re-opened in SlopOS rev0585

- `docs/30-architecture/state-projection-schema-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/namecert-projection-boundary-v0.md`
- `docs/30-architecture/view-objects.md`
- `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`

## What these sources mainly taught this pass

- **VS Code Profiles / worktree compare / preview import**: small compare surfaces and explicit migration are stronger than silent environment replacement
- **PowerToys Dock**: persistent compact shell surfaces work best when their structure is typed,
  bounded,
  and composed from explicit regions or bands
- **Figma compare changes / library updates / swap instances**: compare should stay visible,
  updates can be individual or all-at-once,
  and repeated choice works best when the unit and scope are explicit
- **Obsidian Bases / workspace files**: view definitions travel more cleanly than mutable local workspace residue,
  reinforcing Helm's portable-structure/local-overlay split
- **Raycast selective sync / shared quicklinks**: travel-safe accelerators and local-sensitive state should not be collapsed into one shared-memory story
- **SlopOS CH-SPROJ / namecert selection**: bounded non-authoritative projection and set-valued evaluation are the right datacube lessons for Helm landing and compare
