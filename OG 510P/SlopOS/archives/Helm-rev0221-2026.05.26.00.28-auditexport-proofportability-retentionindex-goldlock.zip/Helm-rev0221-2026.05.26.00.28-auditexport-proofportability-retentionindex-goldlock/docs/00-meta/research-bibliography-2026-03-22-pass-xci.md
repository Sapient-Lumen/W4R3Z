# Research bibliography — pass XCI

1. Google Cloud IAM docs — Privileged Access Manager overview
   - source: https://docs.cloud.google.com/iam/docs/pam-overview
   - used for: just-in-time temporary privilege elevation, entitlement attributes, justification requirements, maximum duration, optional approvers, multi-party approvals, audit logs, and automatic role removal at grant end

2. Google Cloud IAM docs — Request temporary elevated access with PAM
   - source: https://docs.cloud.google.com/iam/docs/pam-request-temporary-elevated-access
   - used for: fixed-duration grant requests and automatic role removal when a grant ends

3. Google Cloud IAM docs — Revoke grants in PAM
   - source: https://docs.cloud.google.com/iam/docs/pam-revoke-grants
   - used for: explicit revoke and revoke-all-grants posture

4. Microsoft Learn — Activate Microsoft Entra roles in PIM
   - source: https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/pim-how-to-activate-role
   - used for: eligible-versus-active posture, reduced-scope activation, reason entry, approval-pending state, status viewing, and deactivation

5. Microsoft Learn — Configure Microsoft Entra role settings in PIM
   - source: https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/pim-how-to-change-default-settings
   - used for: Conditional Access / MFA on activation, justification, ticket information, approver requirements, emergency-access warning, and eligible-versus-active assignment durations

6. Linux man-pages — sudoers_timestamp(5)
   - source: https://man7.org/linux/man-pages/man5/sudoers_timestamp.5.html
   - used for: short-lived cached privilege windows and default per-terminal separation

7. Kubernetes docs — Certificates and Certificate Signing Requests
   - source: https://kubernetes.io/docs/reference/access-authn-authz/certificate-signing-requests/
   - used for: request-versus-approval-versus-issued-result posture and requested lifetime via `spec.expirationSeconds`
