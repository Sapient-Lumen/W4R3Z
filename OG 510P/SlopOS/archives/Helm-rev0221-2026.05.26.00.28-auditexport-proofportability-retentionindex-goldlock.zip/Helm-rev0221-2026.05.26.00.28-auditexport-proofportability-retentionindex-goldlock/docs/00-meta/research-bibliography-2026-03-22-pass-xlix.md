# Research bibliography — 2026-03-22 — pass XLIX

Purpose: official/public sources for the effect-receipt and slot-verdict-ledger pass.

## Primary outside sources

- GitHub Docs — About GitHub Copilot coding agent
  - https://docs.github.com/en/copilot/concepts/agents/coding-agent/about-coding-agent
  - used for: human review requirement, agent approval limits, restricted branch/workflow posture, and separate approve-and-run-workflows path

- GitHub Docs — Reviewing a pull request created by GitHub Copilot
  - https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/review-copilot-prs
  - used for: non-counting self-approval and iterative human review posture

- GitHub Docs — Asking GitHub Copilot to create a pull request
  - https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/create-a-pr
  - used for: explicit agent session, reviewer handoff, and confirmation before task start

- VS Code Docs — Revert changes with checkpoints and editing requests
  - https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
  - used for: exact checkpoint restore, batch revert, and changed-after-this-point semantics

- VS Code Release Notes 1.103
  - https://code.visualstudio.com/updates/v1_103
  - used for: redo-after-restore phrasing on checkpoints

- Google Docs Editors Help — Collaborate with Gemini in Google Sheets
  - https://support.google.com/docs/answer/14218565?hl=en
  - used for: action preview card, explicit Apply, and nearby Settings / Undo after completion

- Figma Learn — Review branch changes
  - https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes
  - used for: explicit branch review posture and the limitation that approval applies to all changes in a branch

- Figma Learn — Merge branch into main file
  - https://help.figma.com/hc/en-us/articles/5691189138839-Merge-branch-into-main-file
  - used for: review-and-merge flow and conflict-resolution posture

## SlopOS internal teacher surfaces re-read this pass

- `docs/30-architecture/acp-acceptance-completion-posture-v0.md`
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
- `docs/30-architecture/lease-descriptor-state-boundary-v0.md`
- `rfcs/0055-attention-authority-and-notifications.md`
