# SlopOS + companion cubes evaluation — 2026-03-23 pass CXIII

Purpose: continue harvesting the narrowest laws Helm should steal from SlopOS, ViewFS, Schell, and Steward before freezing more shell machinery.

## Strongest pressure from SlopOS now

The most useful SlopOS lesson in this pass is about **generation and witness humility**.

SlopOS keeps insisting that:
- one exact generation witness is meaningful
- old witness material should not silently float forward to a new generation
- and freshness / reacquire / re-attest / re-admit should remain explicit when the old witness no longer binds current reality

That law maps very well onto change cursors.
A last-seen position is useful,
but it is still not live truth,
and it must not be silently repaired into a newer generation or current stream head.

## Strongest pressure from ViewFS now

ViewFS is almost tailor-made for this move.
Its watchers, notifications, and rebuild work keep these separate:
- watch registration
- event feed
- rebuilt snapshot
- watch receipt
- degraded or rebuild-required state

That means Helm should probably keep at least three adjacent but different things visible:
- current evaluated watch state
- last-known stream position / resume point
- reset-required or rebuild-required posture

ViewFS also keeps basis record,
drift check,
and reconsent separate.
That helps because a dead bookmark is not the same as a drifted reviewed basis.

## What Schell keeps teaching

Schell still keeps the terminal side honest.
A restored session,
a remembered transcript,
and a still-live attach point are not the same.
That pushes Helm toward the same rule for change streams:
- last seen
- caught up through
- resume still possible
- and reset required

should remain visibly different.

## What Steward keeps teaching

Steward keeps reinforcing tiny status surfaces with decay and typed condition posture.
That matters here because “stale” is too weak.
Helm wants tiny status objects that can say:
- caught up through token X
- token expired
- source pruned
- reset exact scope `/work/design`
- or history only

rather than one yellow warning blob.

## What Helm should pull warmer now

### Refresh change cursors

Helm already had the right noun,
but the companion cubes now justify using it more seriously.
A change cursor should carry:
- one exact source / stream family
- one exact last-seen / caught-up / resume posture
- one exact validity posture
- and one explicit relation to watchpoints or saved views without becoming them

### Add reset cards beside them

Helm now also needs one small sibling object when the cursor can no longer resume.
That card should preserve:
- which cursor died
- why if known
- what scope must reset
- and what old truth still survives as historical evidence

## What to avoid

Do not:
- let watch health impersonate bookmark validity
- let bookmark validity impersonate current-live state
- silently widen a scoped rebuild into a full mirror wipe
- or build a giant sync engine before one proof-bearing bookmark/reset pair exists

## Pull-the-trigger judgment

The seven pillars still look stable.
This is not a new pillar.
But it now looks wise to warm one older specimen and one nearby sibling:

**change cursors** plus **reset cards**,
so Helm can keep last-seen / resume-from / rebuild-required / reset-scope truth explicit instead of hiding them inside current-live badges or vague refresh folklore.
