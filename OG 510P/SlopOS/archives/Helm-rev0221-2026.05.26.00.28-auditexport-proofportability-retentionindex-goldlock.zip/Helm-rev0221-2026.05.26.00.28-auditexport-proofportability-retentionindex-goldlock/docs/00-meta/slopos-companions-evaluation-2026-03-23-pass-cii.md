# SlopOS + companions evaluation — 2026-03-23 — pass CII

Purpose: continue evaluating the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one narrower question:
**what practical shell object should Helm add so strong acts can be prepared generously without laundering stale or indirect intent into the final step?**

## Headline

The companion cubes now point toward one especially promising design-phase ratchet:
Helm should likely warm **gesture runways**.

A gesture runway is a compact shell-owned prepared lane for one sensitive act that can be:
- inspected,
- narrowed,
- compared,
- and made ready,

but that still stops at the exact seam where **fresh or direct user intent** must happen for real.

This is not a new pillar.
It is a humane support object sitting on top of already-warm work such as:
- intent sparks,
- direct-gesture gates,
- trusted chrome lanes,
- action warrants,
- drift gates,
- and access verdict cards.

## 1. SlopOS keeps teaching manual-only seams and no silent widening

The current SlopOS bundle keeps paying off whenever it refuses to let a prepared request quietly become a live grant.
That pressure shows up very clearly in:
- `capture-portal-posture-v0.md`, where capture is manual-only in phase 1, every start stays interactive, and sessions are live rather than resumptive,
- `background-lease-posture-v0.md`, where background and autostart stay distinct grant bits and renewal must not silently widen,
- and several mediation-boundary indexes, where imported metadata or past success never gets to pose as current authority.

For Helm, the lesson is simple:
preparation can be powerful,
but the final authority-bearing seam must remain explicit.
A shell should be able to say:
- prepared,
- waiting for direct gesture,
- gesture consumed,
- expired,
- refused,
- or completed,
without flattening those into one bland "ready" state.

## 2. Steward keeps teaching replay refusal and stale-fence honesty

Steward's replay-gate work is especially relevant here.
It keeps insisting that remembered or restored commands reopen as pending reviewed actions,
not as ambient reruns.
Its provisional-state and freshness-decay docs reinforce the same discipline:
- tentative state is useful,
- late exactness outranks early optimism,
- and stale support evidence should visibly degrade instead of lingering as confidence theater.

Gesture runways are the stronger-act sibling of that lesson.
The shell should absolutely help stage a move.
It should not pretend that a prepared move is already entitled to fire later.

## 3. ViewFS keeps teaching lane splits around live interaction

ViewFS remains strongest when it distinguishes:
- observe,
- attach,
- control,
- injected exec/debug,
- sideband tunnels,
- and durable history.

That is the same anti-collapse law again.
A watched live object,
a queued control,
and an old transcript are not the same kind of connection.

Gesture runways let Helm apply that lesson to stronger shell actions:
- helper-prepared is not user-fired,
- user-fired now is not historical approval residue,
- and one act family may allow a fresh short-lived spark while another still requires a direct shell-owned gesture lane.

## 4. Schell keeps teaching reviewed action plus visible authorship

Schell's charter remains firm that command intent should become a first-class artifact,
that side effects deserve lanes,
and that automation must not erase the human.
That fits gesture runways almost perfectly.

A runway is basically the humane shell artifact for:
- who prepared the act,
- what exact subject is being acted on,
- which basis was reviewed,
- what still needs an immediate human gesture,
- and what happened after that gesture was or was not supplied.

That keeps Helm from regressing into either of two old mistakes:
- dumb modal prompts with no preparation,
- or clever automation that quietly spends stale human meaning.

## 5. What Helm should pull forward now

### Pull forward confidently
- one **gesture runway** object for prepared-sensitive acts
- one rule that prepared state is weaker than current live authority
- one visible distinction between:
  - spark-required,
  - direct-gesture-required,
  - manual-only,
  - expired,
  - and completed
- one clear nearby final-step affordance in trusted shell chrome
- one linked receipt or verdict after success, refusal, or expiry

### Keep warm, not frozen
- a giant global activation ledger
- generic delayed auto-approve flows
- queue or helper lanes that silently inherit live directness
- replayable capture/share/export/control acts
- broad automation exceptions that erase the point of the seam

## 6. The lesson we must learn from the past keeps sharpening

Past systems repeatedly make one of two bad tradeoffs:
- they force the user to do everything manually again because prepared state is not trusted at all,
- or they let preparation quietly become later authority.

Helm should learn the third way:
**prepare almost everything,
then stop exactly where the human seam still matters.**

That is the kind of move that can make Helm feel both luxurious and trustworthy.

## Judgment

Because SlopOS and the companion cubes are still design-phase systems,
this looks like exactly the kind of thing Helm should freeze now:
not a giant subsystem,
but one premium shell object.

The next especially promising move is therefore:
**gesture runways — shell-owned prepared act lanes that stop at fresh-intent or direct-gesture seams instead of laundering stale intent into later authority.**
