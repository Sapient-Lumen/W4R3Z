# Research bibliography — 2026-03-23 — pass CIV

## Primary outside sources reviewed in this pass

1. MDN — **Web Locks API**
   - URL: https://developer.mozilla.org/en-US/docs/Web/API/Web_Locks_API
   - Why it mattered: shared/exclusive modes, conditional acquire (`ifAvailable`), queryable held/requested state, and automatic release posture.

2. Kubernetes documentation — **Leases**
   - URL: https://kubernetes.io/docs/concepts/architecture/leases/
   - Why it mattered: tiny live coordination objects carrying holder identity, renew time, lease duration, and transition history.

3. systemd / logind manual documentation — **Inhibitor locks**
   - URLs:
     - https://www.freedesktop.org/wiki/Software/systemd/inhibit/
     - https://man7.org/linux/man-pages/man5/org.freedesktop.login1.5.html
   - Why it mattered: `what` / `who` / `why` / `mode` metadata and the strong distinction between `delay`, `block`, and `block-weak` inhibition posture.

4. git-lfs documentation — **git-lfs-lock(1)**
   - URL: https://github.com/git-lfs/git-lfs/blob/main/docs/man/git-lfs-lock.adoc
   - Why it mattered: explicit lock ownership intended to block updates by other users and push-time verification rather than optimistic folklore.

5. GitLab documentation — **File locking**
   - URL: https://docs.gitlab.com/user/project/file_lock/
   - Why it mattered: visible in-flight work ownership, read-only / blocked edges, and branch-sensitive enforcement rather than universal ambient blocking.

## Companion-cube surfaces re-read in this pass

### SlopOS
- `rfcs/0058-operation-scoped-budget-leases.md`
- `rfcs/0049-temporal-capabilities-and-scheduling-contexts.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0039-volition-tokens-and-trusted-ui-path.md`

### ViewFS
- `docs/30-architecture/requests-tasks-progress-and-results.md`
- `docs/30-architecture/design-splits-and-non-decisions.md`

### Schell
- `docs/80-terminal/recall-half-lives-rerun-leases-and-aging-humility.md`

### Steward
- `docs/30-architecture/freshness-decay-posture-v0.md`
- `docs/90-inspirations/lessons-from-the-past.md`

## Bottom line

This pass reinforces a simple shell law worth keeping close:
**live coordination claims should be small,
reviewable,
decaying,
and never mistaken for broader power or final outcome.**
