# Research bibliography — 2026-03-21 pass XXXII

## Primary outside sources used in this pass

- Visual Studio Code docs — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Visual Studio Code release notes — **December 2025 (version 1.108)**
  - https://code.visualstudio.com/updates/v1_108
- Figma Help — **Review branch changes**
  - https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes
- Figma Help — **Review and accept library updates**
  - https://help.figma.com/hc/en-us/articles/360039234193-Review-and-accept-library-updates
- WezTerm docs — **InputSelector**
  - https://wezterm.org/config/lua/keyassignment/InputSelector.html
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Obsidian Help — **How Obsidian stores data**
  - https://help.obsidian.md/data-storage
- Obsidian Help — **Introduction to Bases**
  - https://help.obsidian.md/bases

## Main local teacher documents re-opened in SlopOS rev0585

- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/namecert-projection-boundary-v0.md`
- `docs/30-architecture/approval-basis-posture-v0.md`
- `docs/30-architecture/capability-wallet-schema-v0.md`
- `docs/30-architecture/view-objects.md`

## What these sources mainly taught this pass

- **VS Code Profiles / profile import preview / new window with profile**: imported or switched structure benefits from a weaker inspectable arrival mode before it becomes live working posture
- **Figma branch review / library updates**: side-by-side and overlay compare are useful,
  but selective acceptance also needs a way to name exactly which units were updated one-by-one versus all-at-once
- **WezTerm InputSelector / PowerToys Dock**: bounded explicit selection surfaces are more honest than hidden likely-winner inference,
  especially when they stay typed and small
- **Obsidian Bases / local workspace files**: saved view structures travel more cleanly than mutable local layout residue,
  reinforcing Helm's separation between carried structure and receiver-local outcome
- **SlopOS namecert projection/selection and exact basis posture**: evaluation should stay set-valued,
  materialization should stay explicit,
  and exact chosen candidates should retain provenance rather than dissolving into resolver folklore
