# Research bibliography — 2026-03-22 — pass LVI

1. **Linear Docs — Custom Views**
   - source: https://linear.app/docs/custom-views
   - used for: durable saved/shared/favorited views plus view-linked subscriptions and Slack notifications

2. **Linear Docs — Triage**
   - source: https://linear.app/docs/triage
   - used for: triage as a dedicated inbox separate from the main workflow

3. **Linear Docs — Triage Intelligence**
   - source: https://linear.app/docs/triage-intelligence
   - used for: suggestion-first triage posture before stronger automation

4. **Airtable Support — Using the view share menu in Airtable**
   - source: https://support.airtable.com/docs/using-the-view-share-menu-in-airtable
   - used for: explicit share/sync/publish rungs and sync activity visibility on views

5. **Airtable Support — Interface layout: Overview**
   - source: https://support.airtable.com/docs/airtable-interface-layout-overview
   - used for: landing pages that highlight key pages and resources

6. **Airtable Support — Getting started with Interface Designer**
   - source: https://support.airtable.com/docs/getting-started-with-airtable-interface-designer
   - used for: publish-first role-shaped landing surfaces rather than exposing the full base everywhere

7. **Raycast Manual — Quicklinks**
   - source: https://manual.raycast.com/quicklinks
   - used for: tiny summonable handle objects for exact routes back in

8. **Raycast Manual — Shared Quicklinks**
   - source: https://manual.raycast.com/quicklinks/shared-quicklinks
   - used for: organization-shared small entry objects

9. **Raycast Manual — Deeplinks**
   - source: https://manual.raycast.com/deeplinks
   - used for: externally triggered command entry with confirm-before-run posture

10. **Microsoft Learn — PowerToys Workspaces utility for Windows desktop management**
    - source: https://learn.microsoft.com/en-us/windows/powertoys/workspaces
    - used for: captured, editable, pinnable relaunchable workspace starters

11. **Arc Help Center — Spaces: Distinct Browsing Areas**
    - source: https://resources.arc.net/hc/en-us/articles/19228064149143-Spaces-Distinct-Browsing-Areas
    - used for: explicit grouped contexts and project-shaped spaces

12. **Arc Help Center — Profiles: Separate Work & Personal Browsing**
    - source: https://resources.arc.net/hc/en-us/articles/19227964556183-Profiles-Separate-Work-Personal-Browsing
    - used for: explicit identity/cookie/history scope across one or more spaces

13. **Notion Docs — Working with views**
    - source: https://developers.notion.com/guides/data-apis/working-with-views
    - used for: views as first-class resources over one underlying substrate

14. **GitHub Docs — Managing your views**
    - source: https://docs.github.com/en/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/managing-your-views
    - used for: multiple explicit project views over one project truth

15. **GitHub Docs — Browsing sub-issues**
    - source: https://docs.github.com/en/issues/tracking-your-work-with-issues/using-issues/browsing-sub-issues
    - used for: hierarchy data as a property of a view rather than a wholly separate product ontology

16. **Obsidian Help — Introduction to Bases**
    - source: https://obsidian.md/help/bases
    - used for: local database-like views with several explicit views over one local substrate
