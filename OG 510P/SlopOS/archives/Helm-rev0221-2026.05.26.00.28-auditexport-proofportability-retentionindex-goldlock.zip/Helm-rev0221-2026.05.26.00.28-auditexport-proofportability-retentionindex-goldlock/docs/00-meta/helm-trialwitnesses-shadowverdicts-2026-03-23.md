# Helm: trial witnesses, shadow verdicts, and reality-gap strips — 2026-03-23

After **rule stacks** and **precedence traces**,
Helm now has a tighter adjacent question:

**once the shell can say which rule currently wins,**
**how should it say what would happen under a proposed rule, exception, or review change without pretending the trial is live truth?**

The most promising next cluster is:
- **trial witnesses**
- **shadow verdicts**
- **reality-gap strips**
- and maybe later **promotion packets**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. previews stay implicit,
   buried in helper-specific tooling,
   and never become shell truth at all, or
2. a dry-run,
   simulator,
   or evaluate mode gets rendered so confidently that it quietly outranks live review,
   live coverage,
   or live aftermath.

Operators need a third answer:
- the reviewed slice stays visible,
- the current active posture stays visible,
- the proposed change stays visible,
- **and one compact trial-shaped surface says what the shell could honestly test,
  what it predicted,
  and what it still could not know.**

## Candidate objects

### 1. Trial witness
A compact shell-owned trial packet over one exact proposed change.

Good early fields:
- exact subject / footing / reviewed-slice ref
- proposed change packet ref
- evaluation mode:
  - `evaluate-only`
  - `policy-simulator`
  - `plan-only`
  - `server-dry-run`
  - `targeting-test`
  - `shadow-route`
- scenario inputs / scope / affected-set selector
- live basis timestamp or revision
- explicit omissions list

### 2. Shadow verdict
A tiny predicted outcome surface.

Good early fields:
- trial-witness ref
- verdict class:
  - `would-pass`
  - `would-fail`
  - `would-widen`
  - `would-narrow`
  - `would-route-here`
  - `would-deny`
  - `unknown`
- affected-set summary
- strongest promoted-next-step path

### 3. Reality-gap strip
A tiny confession that says why the trial is weaker than live truth.

Good early fields:
- trial-witness ref
- gap class:
  - `no-live-side-effect`
  - `no-runtime-response`
  - `synthetic-context`
  - `missing-cross-scope-facts`
  - `resource-create-blindspot`
  - `cached-compare`
  - `policy-only-check`
- inspect path into exact omitted facts

### 4. Promotion packet (later)
A later packet that can say:
- this exact trial packet was reviewed,
- this much of it is being promoted,
- under this exact footing,
- with these remaining reality gaps now discharged or still fenced.

## What Helm should probably do now

### 1. Keep trial footing exact
A trial without exact basis,
scenario,
scope,
and compared live footing will become superstition fast.

### 2. Keep trial and live separate
A shadow verdict is not a settlement witness,
not an active rule,
and not live service truth.

### 3. Keep the omissions visible
The most important line in the object may be:
**"this trial could not know X."**

### 4. Keep proposed change smaller than giant planning systems
Helm needs a humane shell-owned trial object,
not a universal planner,
workflow center,
or giant speculative environment platform.

### 5. Keep promotion explicit
A helpful trial should make review and adoption easier,
not silently become current truth.

## Guardrails

1. **Do not let evaluate-mode truth outrank live truth.**
2. **Do not let policy-only simulations pretend they know runtime aftermath.**
3. **Do not let cached diffs or synthetic contexts hide their gaps.**
4. **Do not let trial objects become silent execution plans.**
5. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

> active publish posture remains fenced.
> trial witness evaluates a reviewed waiver proposal under this exact footing.
> shadow verdict says `would-pass` for these exact targets and `would-fail` for these others.
> reality-gap strip says the trial is policy-only,
> does not know runtime response bodies,
> and did not cover this foreign dependency lane.
> promotion packet remains absent,
> so current live posture is unchanged.

That would make Helm much better at truthful preflight and `what if?`
without turning it into a giant simulator center or letting previews outrank adoption.
