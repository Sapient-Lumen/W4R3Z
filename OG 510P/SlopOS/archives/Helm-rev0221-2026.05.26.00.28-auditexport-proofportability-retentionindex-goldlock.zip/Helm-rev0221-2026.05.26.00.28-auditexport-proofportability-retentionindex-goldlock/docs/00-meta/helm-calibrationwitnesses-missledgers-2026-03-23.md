# Helm: calibration witnesses, miss ledgers, and outcome-gap strips — 2026-03-23

After **trial witnesses** and **shadow verdicts**,
Helm now has a tighter adjacent question:

**once the shell can say what a proposed change was predicted to do,**
**how should it say what later actually happened without pretending preview and aftermath are the same object?**

The most promising next cluster is:
- **calibration witnesses**
- **miss ledgers**
- **outcome-gap strips**
- and maybe later **reliability notes**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. previews stay isolated,
   helpful in the moment,
   and then vanish before anyone learns whether they were right, or
2. previews earn folklore status,
   where people start saying a dry-run or simulator is "usually right"
   without any exact shell-owned relation between the prediction and the later outcome.

Operators need a third answer:
- the **trial witness** stays visible,
- the **shadow verdict** stays visible,
- the **effect receipt** or other aftermath witness stays visible,
- and one compact calibration-shaped surface says **what matched, what missed, what changed underneath, and what the preview still never claimed to know.**

## Candidate objects

### 1. Calibration witness
A compact shell-owned link between one exact trial packet and one exact later outcome packet.

Good early fields:
- trial-witness ref
- shadow-verdict ref
- later effect-receipt / slot-verdict / closure witness ref
- same-footing or changed-footing class
- comparison lens:
  - `policy-outcome-only`
  - `affected-set`
  - `route`
  - `timing`
  - `receiver-visible`
  - `foreign-response`
- explicit unmatched-lane note

### 2. Miss ledger
A tiny typed record of what differed.

Good early fields:
- calibration-witness ref
- miss class:
  - `footing-shifted-before-act`
  - `omitted-runtime-fact`
  - `foreign-response-differed`
  - `new-resource-blindspot`
  - `cached-preview-aged-out`
  - `receiver-path-diverged`
  - `partial-match`
  - `prediction-held`
- exact affected subset
- inspect path into source omission or later changed fact

### 3. Outcome-gap strip
A tiny confession near the result.

Good early fields:
- calibration-witness ref
- gap posture:
  - `prediction-held`
  - `held-with-omissions`
  - `diverged-by-footing`
  - `diverged-by-runtime`
  - `diverged-by-scope`
  - `not-comparable`
- strongest next inspect path

### 4. Reliability note (later)
A later packet that may say:
- this preview mode keeps matching for this narrow class,
- under these exact footing constraints,
- with these known omission classes,
- without turning that into a universal confidence score.

## What Helm should probably do now

### 1. Keep the comparison exact
No calibration without one exact trial witness and one exact later outcome packet.
A vibe-level memory that "the preview looked right" is not enough.

### 2. Keep prediction and aftermath as separate truths
A calibration witness relates them.
It must not merge them.

### 3. Preserve the original omissions
If a trial declared a runtime blindspot,
that blindspot should still be visible later.
Live success must not retroactively flatter the preview.

### 4. Prefer typed miss classes over one score
A miss ledger is more honest than a global simulator confidence badge.
Helm should say **how** the preview missed,
not just reduce everything to a percentage.

### 5. Keep this seam smaller than a simulation-quality center
Helm needs one humane trial→aftermath compare object,
not a giant policy analytics product.

## Guardrails

1. **Do not let calibration witnesses replace effect receipts.**
2. **Do not let later success erase original preview omissions.**
3. **Do not let per-change calibration become a flattering global score too early.**
4. **Do not let changed footing masquerade as preview failure or preview success.**
5. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

> current publish posture remains fenced.
> trial witness predicted `would-pass` for this exact scope under this exact footing.
> later effect receipt landed for most of that scope,
> but the calibration witness marks `foreign-response-differed` for these exact receivers,
> and `footing-shifted-before-act` for this late-added branch.
> the outcome-gap strip therefore says `held-with-omissions`,
> not full success,
> and opens the miss ledger instead of flattering the preview.

That would make Helm much better at truthful learning from previews
without turning it into a giant simulator-quality center
or letting dry-runs slowly become folklore truth.
