
# Helm footing marks + compared-basis classes — 2026-03-23

Purpose: name the strongest next cross-cutting move now that Helm has **state tuples**,
**grounding witnesses + why rails**,
and **delta briefs**,
but still lacks one humane answer to:

**what exact earlier footing am I comparing against when I say “since”?**

## Main idea

Helm now has useful layers for compact truth:
- **state tuples** for what the compact surface is claiming now
- **grounding witnesses + why rails** for why the shell currently believes it
- **delta briefs** for what changed between two exact bases
- strong source surfaces like timelines,
  compares,
  receipts,
  review lanes,
  and adoption harbors

What is still missing is one compact shell-owned answer to the baseline question.
Not a giant baseline service.
Not ambient memory.
Not another dashboard.

The next object Helm should warm is a **footing mark**.

A footing mark answers:
- what earlier basis are we comparing from?
- what class of footing is it?
- who or what established it?
- is it personal,
  shared,
  reviewed,
  adopted,
  lane-relative,
  or receipt-backed?
- and is that footing current,
  stale,
  expired,
  superseded,
  or historical only?

## Why this now looks ripe

Delta briefs made the next problem obvious.
They need explicit `from` and `to` bases,
but in real use the `from` side is often not just an object id.
It is a **kind of earlier footing** such as:
- last visited
- last checked
- last confirmed
- last reviewed
- last adopted
- shared base with foreground
- receipt-backed checkpoint

Without a footing mark,
Helm risks falling back to:
- “since last time” with no semantics
- personal read state masquerading as team confirmation
- stale approval pretending to survive a moved merge base
- and compact change chrome improvising its baseline ad hoc

## What this lets Helm do better

### 1. Make delta briefs honest about their baseline
A since card can say whether it means:
- since **you last visited**
- since **it was last confirmed**
- since **the last reviewed basis**
- since **the last adopted footing**
- or since **the shared base with the foreground lane**

### 2. Keep Recall stronger than recents
Recall can preserve **last-visited** footing without pretending that visit state equals confirmation,
approval,
or adoption.

### 3. Keep current-live beacons calmer
A beacon can compare `last-confirmed` to `live-now` without forcing the timestamp itself to carry all the semantics.

### 4. Keep adoption and review surfaces basis-aware
Lane cards,
adoption harbors,
and review strips can point at `last-reviewed` or `shared-base` footings without laundering those into current-live truth.

### 5. Keep Overview tiles compact but not mushy
A tile can show one tiny change cue,
but the shell still knows whether the earlier footing is personal,
shared,
reviewed,
or receipt-backed.

## What not to steal

- no giant universal baseline registry before the first proof-bearing slice
- no anonymous “since last time” language
- no flattening of read,
  reviewed,
  confirmed,
  adopted,
  and receipt-backed footing into one generic history marker
- no personal footing quietly presented as shared truth
- no stale approval surviving a moved compared base by inertia

## Pull-the-trigger judgment

Keep the seven pillars stable.
Do not add another pillar.
Do not freeze a giant recap or memory product.

But it now looks wise to **promote footing marks, with explicit footing classes,** as the next companion object beside delta briefs.

If Helm gets this right,
it becomes more awesome at the moment users most often lose trust:
**coming back,
seeing a change cue,
and asking “since what exactly?”**
