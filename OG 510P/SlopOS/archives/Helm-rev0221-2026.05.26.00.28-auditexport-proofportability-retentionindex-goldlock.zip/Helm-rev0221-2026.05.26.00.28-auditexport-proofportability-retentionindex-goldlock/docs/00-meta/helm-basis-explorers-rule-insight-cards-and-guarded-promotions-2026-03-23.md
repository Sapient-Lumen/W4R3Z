# Helm: basis explorers, rule-insight cards, guarded promotion ladders, and patrol decks — 2026-03-23

## The current call

Helm still does **not** need another pillar.
The seven pillars still look right.
The next admitted shell-wide ratchet still looks right too:
**settlement witnesses + commit cards** should tell the truth about accepted versus durable versus replicated versus receiver-visible aftermath.

The calibration cluster also still looks right:
- **calibration witnesses**
- **miss ledgers**
- **outcome-gap strips**
- and maybe later **reliability notes**

But the strongest new cross-pillar luxury pressure is now clearer too.
If Helm wants to feel **super awesome** without becoming a giant fake omniscient cube,
it should keep harvesting:
- **basis explorers**
- **rule-insight cards**
- **guarded promotion ladders**
- and **patrol decks**

Those four ideas fit the archive's real laws:
multiple explicit views over one underlying truth,
preview weaker than apply,
compare weaker than settle,
and reviewable exact basis before stronger action.

## Why this cluster matters

Helm already has good pressure around:
- saved view objects
- smart decks and live inspector decks
- checkpoint branches
- freshness lamps
- trial witnesses and calibration witnesses
- settlement witnesses and commit cards
- semantic recipe cards, serve-path strips, and validator rails

What is still missing is the humane connective tissue between them.
A luxurious shell should increasingly answer:
- **what exact basis am I looking at?**
- **why does this look safe or passable?**
- **what rung am I on: preview, evaluate, guarded exposure, or settled aftermath?**
- **what exact patrol deck or route should I come back through later?**

That is the practical reason this cluster is exciting.
It makes the pillars feel much sharper without creating another center.

## Candidate objects

### 1. Basis explorer
A tiny shell-owned inspect surface for any reviewed, derived, proposed, or published shell object.

Good early fields:
- exact source ref / saved view / deck / slice / branch / recipe ref
- reviewed-basis stamp or footing mark
- current-vs-historical posture
- serve-path class:
  - `live-direct`
  - `cached`
  - `precomputed`
  - `snapshot`
  - `historical-receipt`
- freshness / lag / recheck posture
- exact changed-since basis path
- optional owned-facet or managed-slice hints when the shell truly knows them

Why it is worth stealing:
people keep needing one obvious answer to **what exact thing this nice summary or action is standing on**.

### 2. Rule-insight card
A tiny shell-owned `would-pass / would-fail / bypass-needed / not-comparable` card over one exact stronger act and one exact footing.

Good early fields:
- exact subject ref
- exact scope / cohort / affected-set ref
- reviewed-basis stamp
- evaluated rule/gate family refs
- insight posture:
  - `would-pass`
  - `would-fail`
  - `would-need-bypass`
  - `unknown`
  - `not-comparable`
- strongest failed or bypassed condition
- link to later settlement or calibration witness when reality lands

Why it is worth stealing:
current tools increasingly prove that **evaluate-without-enforce** is a real product luxury.
Helm should copy that without turning insights into authority.

### 3. Guarded promotion ladder
A tiny shell-owned ladder that keeps these rungs distinct:
- preview only
- evaluate only
- reviewed ready
- guarded exposure
- durable settled
- rolled back / paused / diverged later

Good early fields:
- exact proposal ref
- cohort / audience / receiver class
- pause-on signal / metric family refs
- current rung
- next allowed rung
- exact pause / rollback / bypass reason
- link to commit card, settlement witness, and later calibration witness

Why it is worth stealing:
Helm should increasingly let strong moves happen **progressively and inspectably** rather than through one giant apply button.

### 4. Patrol deck
This cluster does **not** need a new giant dashboard.
It needs a bounded multi-view object that can carry:
- one exact live deck or inspect deck
- one exact snapshot or branch view
- one exact compare/calibration lane
- one exact settlement / aftermath lane
- one tiny return route for the next review pass

That is the right shape because it keeps one humane round visible without inventing universal operator theater.

## Lessons Helm must keep learning from the past

### 1. One scalar always lies eventually
One green badge,
one `healthy`,
one `ready`,
one `shared`,
one `reviewed`,
one `done` badge,
one `safe to apply` ribbon:
all of them eventually flatten too many truths.
Helm should keep preferring tiny stacks of typed truths.

### 2. Preview delight is only safe when preview stays weaker than live truth
A lovely preview that can silently apply,
publish,
merge,
route,
or widen scope is a trap.
Helm should steal evaluate-mode luxury,
not preview-equals-authority mythology.

### 3. Giant cubes are usually a symptom of missing explicit objects
If the shell keeps needing one huge dashboard,
that is often proof that saved views,
review packets,
patrol decks,
receipts,
calibration objects,
and basis explorers are still too weak.

### 4. Imported or local analytical help must stay visibly derived
Local sidecars,
helper-local evaluations,
provider-local policy simulators,
and imported response summaries are useful.
They are still weaker than shell truth.

### 5. Design-phase siblings should influence Helm by law, not by vibe
SlopOS,
Schell,
ViewFS,
Foundry,
Harbor,
Ward,
and Steward are still moving.
The right move is to steal their **disciplines**,
not prematurely freeze all of their nouns into Helm.

## What to keep from the inspirations

Keep:
- **SlopOS** family-index discipline, request-vs-live separation, exact handles, and provider-local humility
- **Schell** proposal/review/run separation and descriptive-not-magical chrome
- **ViewFS** prepare/compile/commit/result separation and basis/diff honesty
- **Foundry** declared-versus-observed humility
- **Harbor** origin/preview/label honesty at crossings
- **Ward** staleness budgets and revalidation fences
- **Steward** readiness / pressure / backpressure / adaptation separation

## What not to keep

Do not keep:
- a giant omniscient shell warehouse
- giant workflow bureaucracy before small witness slices prove themselves
- hidden background analysis that silently upgrades derived data into shell authority
- one universal score for prediction quality or simulator trust
- terminal-local or provider-local convenience chrome that outranks shell-owned witnesses

## Moves that could make Helm super awesome

### 1. “Open basis” everywhere
Any derived card,
review strip,
smart deck,
trial witness,
or settlement surface should open one exact basis explorer.

### 2. “Why this would pass” cards beside stronger acts
Before publish,
merge,
route,
adopt,
or expose,
Helm should increasingly show one tiny rule-insight card.

### 3. Preview → evaluate → guarded → settle ladders
Strong changes should increasingly move through explicit rungs rather than one mushy action.

### 4. Patrol decks instead of giant control centers
A compact shell-owned round-trip object is more believable than one giant always-on dashboard.

### 5. Later calibration tied back to the exact insight
If a rule-insight card or guarded promotion existed before the act,
a later calibration witness should be able to compare that exact pre-act story with what actually landed.

## Closing judgment

The strongest near-term product move is now:
**keep settlement witnesses + commit cards admitted,**
**keep calibration witnesses warm,**
**and keep harvesting basis explorers, rule-insight cards, guarded promotion ladders, and patrol decks until one or two become obviously worth freezing as the next narrow contract.**
