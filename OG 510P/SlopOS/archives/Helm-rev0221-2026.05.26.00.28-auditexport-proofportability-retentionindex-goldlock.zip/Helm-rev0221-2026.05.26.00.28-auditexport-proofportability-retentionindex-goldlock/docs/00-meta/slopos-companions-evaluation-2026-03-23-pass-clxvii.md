# SlopOS companions evaluation — 2026-03-23 — pass CLXVII

## Theme
After warming **precondition strips + cutover proofs**,
the next useful question is:

**once a guarded act crossed,
what exact downstream surface has actually observed it,
and what still lags?**

The companion family converges very strongly on that question.

## SlopOS

### What to keep
Keep SlopOS's exact-witness discipline from `acp-precondition-witness-posture-v0.md`.
Keep its refusal to let ambient `latest` or hidden queries stand in for reviewed basis.
Keep its receipt-replication humility from `receipt-replication-boundary-v0.md`.

### What that means for Helm
SlopOS implies a very important law for Helm:
**evidence arrival or replication is not the same thing as current effect authority or universal visibility.**
That is the right constitutional pressure behind observation acks and visibility frontiers.

### What not to steal
Do not inherit all of SlopOS's object-family vocabulary into Helm.
Steal the law,
not the namespace.

## Schell

### What to keep
Keep Schell's pressure around:
- stability strips,
- generation lamps,
- since-cut supplements,
- caught-up-through posture,
- and refresh/reset humility.

### What that means for Helm
Schell is already saying that:
- current lane identity,
- newly ready state,
- stable-enough state,
- observed generation,
- and extendable snapshot/change posture

are different truths.
That maps almost directly onto Helm's need for audience-specific observation acks and visibility frontiers.

## ViewFS

### What to keep
Keep ViewFS's separation between:
- observed validator,
- private writable session,
- coordination hold,
- commit precondition,
- committed version,
- and receipt/history.

### What that means for Helm
The next thing Helm should preserve beside that split is:
**which frontier the committed version has actually crossed for a given audience.**
A committed version is not automatically search-visible,
receiver-visible,
or controller-observed.

## Ward

### What to keep
Ward is especially valuable here.
Its specimen flows already pressure:
- desired state versus observed generation versus condition set,
- commit witness versus stable frontier versus finality class versus exposure gate.

### What that means for Helm
Ward is the clearest local teacher that:
- accepted,
- committed,
- visible to this reader,
- and finalized enough for the strongest consequence

must stay separate.
Helm should steal that shape very directly.

## Foundry

### What to keep
Keep Foundry's:
- intent generation,
- observed generation,
- stale-status fence.

### What that means for Helm
Foundry reinforces the rule that old green status may remain historically true while failing to describe the newest intended state.
That is the exact emotional bug Helm should prevent.

## Steward

### What to keep
Keep Steward's readiness-generation posture.
It explains that a runtime cycle may continue while readiness/status still describes an older generation.

### What that means for Helm
This is a very strong precedent for calm operator chrome like:
- `ready @ g12 while desired g13`
- `controller seen`
- `warming`
- `generation unknown`

instead of one overconfident `ready` bit.

## Harbor and Foundry-adjacent reminder
Harbor's preview/cache-label honesty remains useful here too:
visible preview assets,
cached discovery cues,
and label honesty are all reminders that **what one surface can show now is not universal current truth.**

## Synthesis
The companion family is now pushing Helm toward one compact support pair:
- **observation acks** — what exact observer has actually seen the newer basis,
- **visibility frontiers** — how far a given audience can honestly rely on it.

That is a much better next move than:
- a bigger datacube center,
- a universal propagation engine,
- or another pillar.

## Keep / drop summary

### Keep as law
- exact witness basis
- observed-versus-desired humility
- stable frontier / exposure gate honesty
- receipt/history weaker than live effect truth

### Keep as object candidates
- observation ack
- visibility frontier
- maybe later audience-scoped exposure gates beside settlement witnesses

### Drop for now
- one universal propagation taxonomy
- provider-specific vocabulary leakage into Helm's everyday shell chrome
- any attempt to make one ack imply universal settlement
