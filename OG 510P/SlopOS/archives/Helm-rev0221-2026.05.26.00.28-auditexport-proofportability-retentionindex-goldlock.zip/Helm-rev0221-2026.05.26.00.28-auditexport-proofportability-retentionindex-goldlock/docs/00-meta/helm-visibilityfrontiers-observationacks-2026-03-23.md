# Helm — visibility frontiers and observation acks

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one universal propagation or settlement engine.

The strongest next move is smaller:
**warm visibility frontiers + observation acks as the shell-owned seam between guarded cutover and later settlement.**

Helm already has better answers for:
- what exact footing counted,
- what died,
- how to renew or replace it,
- what exact precondition a serious act depended on,
- and whether the boundary crossed under that guard.

What it still answers too weakly is:
- who has actually seen the newer state,
- what audience can rely on it now,
- and whether the shell is merely looking at stored truth,
  controller-seen truth,
  search-visible truth,
  cache-propagated truth,
  or receiver-visible truth.

## The lesson Helm must learn from the past

Past systems repeatedly commit the same sin:
**they turn `accepted` or `stored` into `done`.**

That flattening hides some of the most important operator truths:
- desired state can move before status catches up;
- a controller can acknowledge generation `N` while UI chrome still summarizes generation `N-1`;
- a document can be written but not yet visible to search;
- a CDN invalidation can be created but not yet completed;
- a long-running operation can exist and even carry progress metadata while `done=false`;
- and one receiver or cache path can be current while others lag.

Helm should refuse the myth that one green bit can summarize all of that.

## What the outside world is teaching right now

### Kubernetes: desired generation is not observed generation
Current Kubernetes docs keep `metadata.generation` and `status.observedGeneration` explicit,
and newer Pod docs make it clear that status can name which generation the current status actually reflects.
That is a direct precedent for Helm:
**never let old green status impersonate truth about newer intent.**

### Elasticsearch: write success is not search visibility unless refresh says so
Elasticsearch keeps refresh semantics explicit:
`refresh=true`, `wait_for`, and `false` have meaning specifically around **visibility to search**.
That is an excellent precedent for Helm because it keeps `stored` separate from `search-visible`.

### CloudFront: invalidation requested is not invalidation completed
CloudFront keeps invalidation state explicit and waitable until status becomes `Completed`.
That is a good reminder that downstream visibility can lag after the initiating act succeeds.

### Google long-running operations: operation existence is not completion
Google's long-running operation model keeps `done=false` separate from `done=true`,
and completed operations still split into `response` or `error`.
That is a strong precedent for Helm's refusal to treat one accepted request or one named continuation as settled effect.

## What the companion cubes are teaching now

### Keep from SlopOS
Keep SlopOS's exactness around precondition witnesses,
and keep its receipt-replication humility.
Replication or evidence arrival should not silently become current effect or visibility truth.

### Keep from Schell
Keep Schell's generation-lamp and since-cut-supplement pressure.
Schell is basically already teaching that `current lane`, `caught up through`, and `warming/stable` are different truths.

### Keep from ViewFS
Keep ViewFS's separation between observed validator,
private writable session,
commit precondition,
committed version,
and receipt/history.
The next thing to preserve beside that is the **frontier through which the committed version is actually observable**.

### Keep from Ward and Foundry
Ward's `desired state / observed generation / condition set / teardown gate` and `commit witness / stable frontier / finality class / exposure gate` pressure are extremely close to what Helm needs.
Foundry's intent-generation versus observed-generation versus stale-status-fence split reinforces the same law.

### Keep from Steward
Steward's readiness-generation posture is a great reminder that a live cycle can continue while status still belongs to an older generation.

## Bright steals for Helm

1. **Observed-generation chips**
   - tiny status like `seen through g12` or `status still g11`.
2. **Audience-labeled frontiers**
   - `stored only`, `controller seen`, `search visible`, `cache invalidation pending`, `receiver visible`, `settled`.
3. **Wait/poll rails that admit lag honestly**
   - not one spinner,
   but one compact next verb grounded in the actual frontier.
4. **Index/refresh humility on publish surfaces**
   - especially in Object Browser and Exchange.
5. **Controller-seen truth in Operations Center**
   - strong actions should be able to say whether they are looking at desired intent or observed status.

## What not to keep

Do not keep:
- one universal `done` badge,
- one ambient `latest status` myth,
- or one propagation center that tries to explain every backend the same way.

The shell should instead keep a tiny shared grammar and let providers or pillars supply the specific evidence.

## Why this makes Helm super awesome

This move makes Helm feel smarter exactly where modern tools usually feel spooky.
An operator can ask:
- `did it cross?`
- `who has seen it?`
- `which audience can trust it now?`
- `what still lags?`
- and `what is the smallest honest next step?`

That is a premium shell feel.
Not because Helm predicts everything,
but because it refuses to lie about where observation and visibility actually stop.
