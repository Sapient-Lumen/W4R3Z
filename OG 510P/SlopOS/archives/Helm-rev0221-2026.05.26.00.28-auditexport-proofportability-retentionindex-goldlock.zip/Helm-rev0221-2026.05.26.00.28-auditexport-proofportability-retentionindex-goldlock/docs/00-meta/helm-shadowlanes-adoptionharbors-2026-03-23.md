# Helm synthesis — shadow work lanes + adoption harbors — 2026-03-23

## Headline

The next compact move worth warming is:
**shadow work lanes + adoption harbors**.

Helm now has better pre-act grammar and better post-act grammar.
What it was still missing was one compact answer to:

**where does delegated, helper, background, or repair work live while it is useful but not yet authoritative?**

## The shape that now looks right

- **shadow work lane**
  - one exact side lane related to one live subject or repair target
  - clearly weaker than the authoritative live lane
  - can carry candidate mutable work, helper output, or repair attempts
  - keeps exact authorship, basis, and drift posture visible

- **adoption harbor**
  - one honest shell-owned inspection/apply surface for candidate side work
  - supports inspect / adopt selected / adopt all / review again / keep separate / reject / hold
  - keeps preview/diff and drift posture near the stronger rung

## Why this is better than the alternatives

Better than silent helper mutation:
- the operator keeps one authoritative live lane
- side work does not steal authorship or currentness

Better than a giant branch manager:
- the move stays compact and shell-owned
- it can exist across Operations Center, Desktop Flow, Exchange, Omnibox, and Recall without becoming a separate product empire

Better than notifications or agent logs:
- the important truth is not merely that the helper ran
- the important truth is what candidate work exists, what it started from, how it drifted, and what the honest next move is

## Pull-the-trigger judgment

This now looks warm enough to admit as the next compact support proof.
Do **not** make it a new pillar.
Do **not** turn it into giant collaboration court law.
But do start proving:
- one shadow work lane specimen
- one adoption harbor specimen
- one drifted lane specimen
- one rejected lane specimen
- one exact tie-back to action warrants, drift gates, effect receipts, and slot verdict ledgers

## Must-keep laws

- candidate lane is weaker than authoritative live lane
- preview is weaker than adoption
- old lane readiness does not silently survive basis drift
- helper or delegated authorship does not silently inherit operator authority
- history of candidate work is useful, but it is not proof that the live lane changed

## Super-awesome angle

This is one of the best remaining chances for Helm to feel unusually magical **and** unusually honest.
A great shell should be able to let assistants, helpers, flows, or future agent systems do impressive side work,
without ever making the operator wonder:

**did that just change my real workspace already?**
