
# Research bibliography — 2026-03-21 — pass VII

## Internal teacher cubes

- Helm-rev0012-2026.03.21.14.49-entrytruth-activitykits.zip
- SlopOS-rev0576-2026.03.21.06.08-openuri-speculative-loading-boundary.zip
- Schell-rev0031-2026.03.21.02.14-completioncards-paramhelp-preflighthonesty-originbadges-hintfoundry.zip
- DelayBasin-rev0142-2026.03.21.10.03-sessionaffinity-stickyreuse-shadowgate-nosessioncourt-affinityglass.zip

## External sources consulted in this pass

- PowerToys Workspaces — https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- PowerToys FancyZones — https://learn.microsoft.com/en-us/windows/powertoys/fancyzones
- PowerToys Command Palette overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- PowerToys Peek — https://learn.microsoft.com/en-us/windows/powertoys/peek
- GNOME visual overview / Activities overview — https://help.gnome.org/gnome-help/shell-introduction.html
- GNOME start applications / instant search / drag to workspace — https://help.gnome.org/gnome-help/shell-apps-open.html
- GNOME workspaces — https://help.gnome.org/gnome-help/shell-workspaces.html
- Obsidian Workspaces — https://obsidian.md/help/plugins/workspaces
- VS Code agent overview — https://code.visualstudio.com/docs/copilot/agents/overview
- VS Code cloud agents — https://code.visualstudio.com/docs/copilot/agents/cloud-agents
- VS Code multi-agent development blog — https://code.visualstudio.com/blogs/2026/02/05/multi-agent-development
- VS Code release notes February 2026 (Agent Debug panel) — https://code.visualstudio.com/updates/v1_110
- VS Code release notes June 2025 (session log) — https://code.visualstudio.com/updates/v1_102
- VS Code Profiles — https://code.visualstudio.com/docs/configure/profiles
- VS Code Source Control / Timeline — https://code.visualstudio.com/docs/sourcecontrol/overview
- Node-RED sidebar / info / debug docs — https://nodered.org/docs/user-guide/editor/sidebar/ and https://nodered.org/docs/user-guide/editor/sidebar/info and https://nodered.org/docs/user-guide/editor/sidebar/debug
- Raycast Quicklinks / Snippets / Dynamic Placeholders — https://manual.raycast.com/quicklinks and https://manual.raycast.com/snippets and https://manual.raycast.com/dynamic-placeholders

## What these sources were used for

This pass was mainly about reuse honesty, saved-to-live binding, structured witness cards, unified session/status surfaces, and tiny accelerators that stay inspectable.
The goal was not to broaden Helm's pillars.
The goal was to decide whether the archive had reached the point where:
- non-exact binding / reuse witness posture should be frozen narrowly,
- and binding witness cards should be added as a candidate move.
