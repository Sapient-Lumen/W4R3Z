# Helm: continuation handles + repair ladders — 2026-03-23

## Headline

Helm should probably stop asking one object to do two jobs.

An **effect receipt** should say what exact historical aftermath landed.
A **continuation handle** should say whether there is still one exact,
decaying,
truthful way to continue,
poll,
resume,
redrive,
rerun,
or cancel that story now.
A **repair ladder** should say what humane next move remains if that window is weak,
subset-only,
or gone.

## Why now

Helm's aftermath story is now much better than it was:
- effect receipts
- slot verdict ledgers
- attempt-aware rerun lineage

But one important question still falls awkwardly between those objects and current-live beacons:

**is there still an exact continuation path here,
and what kind of path is it?**

Without a distinct object,
Helm risks two bad stories:
- treating a historical receipt as if it were still a live continuation window
- or treating every next step as the same vague retry / resume button

## The move

### Continuation handles

A continuation handle should be one compact shell-owned witness for:
- one exact historical act,
  effect,
  slot ledger,
  or pending provider operation
- one exact continuation family
- one exact validity / expiry posture
- one exact actor / basis / same-user relation
- and one exact remainder or failed-subset witness when relevant

The family should stay explicit:
- poll status
- wait until done
- cancel
- resume upload
- complete deferred commit
- redrive failed execution
- rerun failed subset
- rerun one exact failed item
- reopen unresolved slots
- or hold only

### Repair ladders

Repair ladders now become better if they can admit whether an exact continuation handle still exists.
That lets the ladder say things like:
- continue exact pending handle
- poll again
- rerun failed subset
- replay on fresh basis
- compare against current
- compensate / branch-and-fix
- or hold because the exact continuation window expired

## Strongest ideas worth stealing

### 1. Explicit expiry and window ownership
Microsoft Graph upload sessions are excellent because they make expiry,
resume remainder,
and deferred completion concrete.
Helm should steal that honesty directly.

### 2. Stable operation handles instead of spinner folklore
Google long-running operations show that a named operation handle can be polled,
waited on,
cancelled,
or dropped if the client no longer cares.
That is a beautiful model for shell-owned continuation handles.

### 3. Rerun and redrive are not the same move
GitHub rerun families and Step Functions redrive both prove that the next move after failure is not one generic retry.
It matters whether Helm is:
- rerunning all
- rerunning failed subset
- rerunning one exact item
- redriving from the failed step
- or replaying on fresh basis

### 4. Same-user / original-actor truth belongs near the handle
GitHub and Google Drive are especially useful here.
A continuation path can be exact but still bound to the original actor,
the same SHA/ref,
or the same user identity.
Helm should surface that rather than hiding it in provider error text.

### 5. Continuation and current-live truth should stay distinct
A continuation handle may still be available even when Helm does not yet know the current semantic end-state.
That is okay.
The point is not to impersonate live truth;
it is to preserve exact next-move truth.

## What to keep from older inspirations

Keep:
- exact recovery objects
- attempt-aware rerun lineage
- no fake cross-device or cross-surface resume mythology
- explicit compare-to-current after historical success
- humane next-step ladders instead of one theatrical undo/retry button

Peel away:
- giant incident manager ambition
- universal resumability claims
- any UI that hides expiry or subset-only continuation
- any story that lets a dead handle keep sounding live

## Why this could make Helm super awesome

### 1. Helm could answer “what now?” much more honestly
Not just what happened,
but what exact next motion is still possible.

### 2. Operations Center becomes humane without becoming huge
Instead of generic failed / retry rows,
it can show:
- exact handle still live
- expires in 8 minutes
- same user required
- failed subset only
- redrive available
- handle expired → open repair ladder

### 3. Recall gets better without fake resume promises
Recall can distinguish:
- historical effect only
- effect + live continuation handle
- effect + expired continuation handle
- current-live beacon stronger than both

### 4. Exchange gains a complete premium aftermath chain
Offer,
take,
route,
materialization,
effect,
continuation,
and repair become distinct visible rungs.
That is unusual,
and it would feel extremely thoughtful.

## Pull-the-trigger judgment

The seven pillars still look stable.
This is not a new pillar.
But it now looks wise to warm one more compact support move:

**continuation handles**,
with **repair ladders** refreshed right beside them.
