# Research bibliography — 2026-03-21 pass XXXI

## Primary outside sources used in this pass

- Visual Studio Code docs — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Visual Studio Code release notes — **July 2023 (version 1.81)**
  - https://code.visualstudio.com/updates/v1_81
- Visual Studio Code docs — **Settings Sync**
  - https://code.visualstudio.com/docs/configure/settings-sync
- Visual Studio Code docs — **User and workspace settings**
  - https://code.visualstudio.com/docs/configure/settings
- Figma Help — **Code Connect**
  - https://help.figma.com/hc/en-us/articles/23920389749655-Code-Connect
- Figma Help — **Use slots to build flexible components in Figma**
  - https://help.figma.com/hc/en-us/articles/38231200344599-Use-slots-to-build-flexible-components-in-Figma
- Raycast Manual — **Shared Quicklinks**
  - https://manual.raycast.com/quicklinks/shared-quicklinks

## Main local teacher documents re-opened in SlopOS rev0585

- `docs/30-architecture/capability-wallet-schema-v0.md`
- `docs/30-architecture/namecert-projection-boundary-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/approval-basis-posture-v0.md`
- `docs/30-architecture/lease-descriptor-state-boundary-v0.md`

## What these sources mainly taught this pass

- **VS Code Profiles / partial profiles / settings scopes / sync exclusions**: a useful travel form needs one stable carried structure,
  but local defaults,
  user scope,
  workspace scope,
  and remote-window exclusions still matter and should remain explicit
- **Figma Code Connect / slots**: structured slot/property mappings make flexible landing more honest when the shell says which slots are carried,
  parameterized,
  or still need local fill
- **Raycast shared quicklinks**: some exact handles can travel or be shared while personal/local quick structure still stays local and unsynced
- **SlopOS wallet-core and namecert boundaries**: stable core digests,
  explicit projection,
  explicit selection,
  and explicit source provenance are stronger teachers than any giant sync or resolver mythology
