# Helm: reveal windows + audience ladders — 2026-03-22

## The newest strong lesson

Helm now has publication ladders,
promotion receipts,
authority windows,
claim envelopes,
handoff packets,
and receiver-fit cards.
What it still lacked was one humane answer to:
- who can currently see this?
- by what route did that visibility happen?
- what shape of truth is actually visible?
- how long does that visibility last?
- how do I narrow,
  rotate,
  disable,
  or republish it later without spelunking provider-specific settings?

The answer now looks like:
**reveal windows + audience ladders**.

## Why this is worth keeping

These moves make several warmed objects better at once:
- **publication ladders** can point to the stronger current reveal sibling rather than acting like they solved live visibility forever
- **promotion receipts** can remain historical witnesses instead of impersonating current audience truth
- **claim envelopes** can admit summary-only,
  preview-only,
  or redacted reveal shapes per audience rung
- **handoff packets** and **receiver-fit cards** can say what visibility did or did not travel
- **Operations Center** can finally show what is visible now,
  what is only historical,
  what expires soon,
  and what is public versus named
- **Recall** can separate “was once shared” from “is still revealable now”

## The compact product shape

### Reveal window
One bounded shell object for one explicit reveal relation.
It should expose:
- subject / surface family
- route class
  - named invite
  - group / org / workspace
  - guarded link
  - public link
  - signed bearer route
- audience class
  - exact recipients,
    named group,
    org/workspace,
    or public
- reveal shape
  - full
  - comment
  - edit
  - preview-only
  - summary-only
  - redacted
- start / expiry / disabled / revoked / historical posture
- policy posture
  - allowed,
    blocked,
    or downgraded by org/workspace policy
- current-live witness relation
- narrow / rotate / disable / republish next moves

### Audience ladder
One humane chooser for distinct reveal rungs.
A first proof likely only needs:
- local only
- named collaborators
- org / workspace only
- guarded link
  - password,
    signed,
    or email-auth where relevant
- time-boxed public

Not every family needs every rung.
Many should stop early.

## Biggest anti-goal

Do **not** build a giant ACL studio.
Do **not** let historical publish/share receipts impersonate current audience truth.
Do **not** let public or bearer routes silently count as named-collaborator equivalence.
Do **not** widen preview/summary routes into full reveal by default.

## What seems wise to pull the trigger on now

Warm the family explicitly.
Keep it narrow.
Prove it on one or two surface families first.
Good first proof slices would be:
- one saved view or brief with named-collaborator and org-only rungs
- one guarded link with expiry
- one public/time-boxed reveal that can be disabled by policy
- one bearer packet or signed-route specimen that stays visibly weaker and shorter-lived
- one Operations Center row showing live,
  expiring,
  disabled,
  and historical reveal posture

That looks much more promising than inventing another giant object family or adding another pillar.
