# Research bibliography — 2026-03-22 pass LXXIII

Primary sources reviewed for this pass:

1. Android Developers — Permissions updates in Android 11
   - https://developer.android.com/about/versions/11/privacy/permissions
   - used for one-time permissions and auto-reset

2. Android Developers — Request runtime permissions
   - https://developer.android.com/training/permissions/requesting
   - used for runtime permission UX and remove-app-access posture

3. Chrome Web Store Help — Install and manage extensions
   - https://support.google.com/chrome_webstore/answer/2664769
   - used for on-click / current-site / specific-sites / all-sites extension site access controls

4. Chrome for Developers — Protect user privacy
   - https://developer.chrome.com/docs/extensions/develop/security-privacy/user-privacy
   - used for `activeTab` and optional permission guidance

5. GitHub Docs — Managing your personal access tokens
   - https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens
   - used for fine-grained token expiration, resource owner, and repository access posture

6. GitHub Docs — Token expiration and revocation
   - https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/token-expiration-and-revocation
   - used for GitHub App user access token default expiry

7. VS Code Docs — Workspace Trust
   - https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
   - used for Restricted Mode and inspect-without-full-trust posture
