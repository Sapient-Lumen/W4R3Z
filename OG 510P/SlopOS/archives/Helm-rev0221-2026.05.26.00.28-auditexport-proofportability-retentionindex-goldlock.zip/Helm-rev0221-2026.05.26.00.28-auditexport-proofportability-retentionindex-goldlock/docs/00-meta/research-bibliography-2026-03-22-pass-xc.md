# Research bibliography — 2026-03-22 — pass XC

Focus for this pass: visible caveats, conditional permissions, offline attenuation, and subtree revoke.

1. Google Research — *Macaroons: Cookies with Contextual Caveats for Decentralized Authorization in the Cloud* (NDSS 2014)
   - used for: caveats that attenuate and contextually confine when/where/by who/for what purpose

2. Eclipse Biscuit docs — Home
   - used for: offline attenuation and decentralized verification as a practical authorization shape

3. Eclipse Biscuit docs — Revocation
   - used for: revoking a parent should also revoke derived tokens; revocation-list dissemination ideas

4. Authzed / SpiceDB docs — Caveats
   - used for: conditional relationships, partial binding of caveat context, conditional permission, and missing-context fields

5. AWS IAM docs — Compare AWS STS credentials
   - used for: session policies as intersection-only narrowing over temporary credentials
