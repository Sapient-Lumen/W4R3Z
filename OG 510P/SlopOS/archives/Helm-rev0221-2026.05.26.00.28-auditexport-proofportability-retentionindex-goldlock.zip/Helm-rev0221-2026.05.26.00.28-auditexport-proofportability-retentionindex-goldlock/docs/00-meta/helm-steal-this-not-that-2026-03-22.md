# Helm: steal this, not that — 2026-03-22

Purpose: separate durable steal-worthy product laws from ideas that only look attractive when decontextualized.

## Steal this

### Saved view objects, not “filters with delusions of grandeur”
Keep the notion that one underlying truth can support many named views,
each with its own configuration,
entry surfaces,
and share/publication rungs.
Do **not** let the view pretend to be the live subject.

### Checkpoints, restore, and branch-from-here
Keep explicit basis-bearing checkpoints and the ability to restore or fork from them.
Do **not** let restore and branch collapse into one flattering story.

### Imported-surface trust posture
Keep the idea that newly imported or shared shell surfaces can begin in a weaker posture.
Do **not** make trust a hidden implementation detail.

### Preview that can promote
Keep the idea that preview is a real shell move,
not dead-end chrome.
Do **not** make preview silently become open,
adopt,
or publish.

### Personal / shared / published accelerators
Keep explicit scope and strength for quicklinks,
command bands,
and shell shortcuts.
Do **not** treat every pinned thing as universally portable or team-safe.

### Saveable structure without fake continuity
Keep launch configurations,
workspace layouts,
workspaces,
and decks as valuable saved structures.
Do **not** let them impersonate live current truth.

### Compare surfaces that preserve lineage differences
Keep side-by-side,
overlay,
and branch review.
Do **not** flatten move,
copy,
fork,
merge,
and publish into one “updated” badge.

## Do not steal this

### Giant dashboard religion
Dashboards are useful,
but they are derivative surfaces.
Helm should not let decks become the constitution.

### Ambient sync mythology
Cross-device or cross-user convenience is real.
But ambient silent sameness is how systems start lying about locality,
trust,
and authorship.

### “Everything is a branch” universalism
Branching is powerful where lineage matters.
Not every preview,
recipe,
or saved layout needs full branch semantics.

### Hidden helper magic
If a system imported,
rebound,
restored,
or reused something on the user's behalf,
Helm should be able to show that fact cleanly.

### Saved setups as fake sessions
Saved setups are good.
Pretending they are still live is bad.

## The old inspirations that still deserve protection

Keep:
- deterministic shell ownership of placement and focus
- instant summon/search/act surfaces
- query-first browsing plus reveal/preview excellence
- strong operational honesty about what the machine is actually doing
- visible leverage for automation without making the whole shell ambient

Drop or weaken:
- regex/title/class folk law as the main shell extension model
- file/path and process tables as the master ontologies
- plugin romance that outruns host law
- any nostalgia for hidden persistence just because it once felt powerful

## Judgment

The smartest way to make Helm feel novel is not to invent alien nouns.
It is to combine a few already-proven moves under stronger shell law:

- views as objects
- checkpoints as basis
- preview as a promotable state
- imports as initially weaker than local truth
- accelerators as scoped and runged
- decks and recipes as derivative and honest
