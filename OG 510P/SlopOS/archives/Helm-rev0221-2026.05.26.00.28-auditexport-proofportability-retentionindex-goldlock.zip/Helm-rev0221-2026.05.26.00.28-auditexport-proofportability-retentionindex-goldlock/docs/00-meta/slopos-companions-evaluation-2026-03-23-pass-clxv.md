# SlopOS + companions evaluation — 2026-03-23 — pass CLXV

This pass asked:
after Helm can say what footing counted,
what died,
and what weaker residue remains,
what do SlopOS and the sibling cubes teach about continuity *before* death and during replacement?

## Main local judgment

Treat the companions as constitutional pressure again,
not as noun donors.
The strongest local lesson is that Helm should keep continuity **typed, bounded, and replacement-honest**.
That supports warming **renewal beacons + overlap handoffs**.

## What each nearby datacube teaches here

### SlopOS
SlopOS keeps teaching that descriptors,
leases,
boundaries,
and live state must not silently collapse into one truth.
For Helm,
that means a renewal beacon should be shell-owned continuity posture,
not a fake guarantee that the outside system is still healthy.

### Schell
Schell is the strongest immediate teacher.
Its current pressure around anchor death cards,
cursor expiry,
reset scope,
review watermarks,
and first-unseen anchors says continuity must distinguish:
- the old anchor,
- the exact way it dies,
- and the next honest reset.
The next local upgrade is to surface the *approach* to that death,
not only the death itself.

### ViewFS
ViewFS keeps separating editable buffers,
parsed structures,
diagnostics,
compiled packets,
and durable receipts.
Across other slices,
it also keeps cursor,
packet,
and route truths distinct.
For Helm,
that argues against one giant continuity object.
A renewal beacon should name exactly what is aging,
and an overlap handoff should bridge only the exact object family involved.

### Ward
Ward’s read cuts,
staleness budgets,
and revalidation fences strongly support a visible continuity budget.
A footing can remain useful while its budget shrinks.
That is exactly the territory a renewal beacon should occupy.

### Steward
Steward’s adaptation honesty,
cache trim pressure,
and concurrency caps all reinforce one lesson:
repair verbs must stay narrow.
A continuity warning is not permission for the shell to improvise a giant recovery ritual.
The beacon should name `renew`, `replace`, `rebind`, or `rebuild` precisely.

### Harbor and Foundry
Harbor’s route/admission humility and Foundry’s off-native realization humility both argue that replacement bridges should stay explicit.
A new continuity object should not quietly inherit the full truth or authority of the old one.
That is why an overlap handoff needs a visible bridge proof rather than one flattering “continued” state.

## What Helm should keep from old inspirations

Keep:
- exact basis;
- weak-vs-strong truth classes;
- tiny typed cards instead of one center;
- visible reset scope;
- distinct route / materialization / receipt / history truth;
- careful audience and locality discipline.

Drop or keep warm only:
- any temptation to make one universal continuity dashboard;
- any single abstract token plane that pretends channels,
cursors,
watches,
sessions,
and upload handles are all the same thing;
- any eager automation that renews or replaces footing without telling the operator what changed.

## Pillar pressure

This seam is cross-pillar,
but it is most valuable now in:
- **Recall**, where old anchors and reviewed cuts decay over time;
- **Object Browser**, where watched collections and saved continuity routes may age;
- **Operations Center**, where long-lived watchers,
  streams,
  runs,
  and landing trains benefit from continuity budgets and overlap receipts;
- **Exchange**, where sessions,
  transfers,
  and notification channels age or require swap.

## Product judgment

Helm still does not need another pillar.
It also still does not need one universal sync or watch center.

But the local cube family now supports one narrower move:
make continuity age visible before it dies,
and make replacement bridges visible when old and new footing overlap.
