# Research bibliography — 2026-03-23 — pass CX

1. GitHub Docs — **re-running workflows and jobs / contexts reference**
   - URLs:
     - https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs
     - https://docs.github.com/en/actions/reference/workflows-and-actions/contexts
     - https://docs.github.com/en/enterprise-cloud@latest/actions/reference/security/oidc
   - Why it mattered: GitHub keeps rerun-all, rerun-failed, and rerun-one-job visibly different; reruns use the original actor's privileges and original SHA/ref; and `run_attempt` increments per re-run.

2. AWS Step Functions — **redrive executions / retry behavior**
   - URLs:
     - https://docs.aws.amazon.com/step-functions/latest/dg/redrive-executions.html
     - https://docs.aws.amazon.com/step-functions/latest/dg/concepts-error-handling.html
   - Why it mattered: Step Functions makes redrive an explicit bounded move, preserves successful-step history, restarts from the unsuccessful step, and resets retry counts on redrive.

3. Microsoft Graph — **createUploadSession**
   - URLs:
     - https://learn.microsoft.com/en-us/graph/api/driveitem-createuploadsession?view=graph-rest-1.0
   - Why it mattered: upload sessions expose exact resumable continuation truth via `expirationDateTime`, `nextExpectedRanges`, fragment-by-fragment expiry extension, and optional deferred commit.

4. Google Drive / google.longrunning / AIP-151 — **pollable operations and bounded terminal result**
   - URLs:
     - https://developers.google.com/workspace/drive/api/guides/long-running-operations
     - https://developers.google.com/optimization/service/reference/rpc/google.longrunning
     - https://google.aip.dev/151
   - Why it mattered: long-running operations keep a named handle for poll / wait / cancel / delete, keep `done` separate from `error` vs `response`, and Drive makes the handle's user binding and finite availability explicit.

5. Kubernetes — **Indexed Job per-index retry and status**
   - URLs:
     - https://kubernetes.io/docs/concepts/workloads/controllers/job/
   - Why it mattered: Kubernetes keeps exact remainder and subset truth (`completedIndexes`, `failedIndexes`) even when overall job status is failed, which is excellent pressure for continuation handles and repair ladders.

## Companion-cube anchors revisited

- `docs/30-architecture/lease-descriptor-state-boundary-v0.md` (SlopOS)
- `docs/30-architecture/background-request-state-posture-v0.md` (SlopOS)
- `docs/30-architecture/job-request-state-posture-v0.md` (SlopOS)
- `docs/30-architecture/openuri-materialization-boundary-v0.md` (SlopOS)
- `docs/80-terminal/handoff-ladders-observation-truth-and-completion-humility.md` (Schell)
- `docs/70-shell/truthful-completions-and-routing.md` (ViewFS)
- `docs/30-architecture/handles-refs-and-receipts.md` (ViewFS)
- `docs/30-architecture/runtime-cycle-witness-posture-v0.md` (Steward)
- `docs/30-architecture/activation-receipt-posture-v0.md` (Steward)

## Current judgment

The strongest outside and companion-cube pressure now converges on the same aftermath / recovery chain:

**effect receipt → continuation handle → repair ladder**

with current-live truth still staying stronger than all three.
