# Research bibliography — 2026-03-23 — pass CLIX

## Current official product docs reviewed in this pass

- GitHub Docs — About rulesets
- GitHub Docs — Managing rulesets for a repository
- GitHub Docs — Merging a pull request with a merge queue
- LaunchDarkly Docs — Testing changes to flag targeting
- Argo CD Docs — Diff Strategies
- Kubernetes Docs — Server-Side Apply
- OPA Docs — Decision Logs
- Grafana Docs — Investigations App
- Grafana Docs — Time Range Compare in Investigations
- Datadog Docs — Notebooks
- Obsidian Help — Bases views
- Honeycomb Docs — Board Templates
- Raycast Manual — Cloud Sync
- Raycast Manual — Shared Quicklinks

## Main current takes captured from those sources

- Obsidian strengthens the case for many explicit views over one footing.
- Honeycomb and Datadog strengthen the case for template galleries and reusable starter structures.
- Grafana strengthens the case for reusable investigations whose compare context and comments survive reuse.
- GitHub and LaunchDarkly keep exact-subject,
  grouped-check,
  and cohort-delta truth central even when richer workspaces exist.
- Raycast strengthens the case for explicit sync/share ladders rather than ambient collaboration.

## Local companion surfaces reopened in parallel

- SlopOS approval-basis / exact-reveal / preview-boundary posture docs
- Schell proposal / review / run / outcome separation surfaces
- ViewFS parse / diagnostics / packet / receipt separation surfaces
- Ward read-cut / staleness-budget / revalidation-fence surfaces
- Steward adaptation / headroom / cache-trim surfaces
- Harbor coarse-origin / preview-asset / label-honesty surfaces
- Foundry discharge-witness / actor-path / caveat-hold surfaces
- Helm rehearsal deck, deck recipe, reviewed-slice, and settlement/calibration candidate docs

## Product sentence this pass supports

Helm should probably flesh all seven pillars by defining **first pillar-specific rehearsal-deck recipes** and explicit **recipe/share ladders**,
while keeping recipes weaker than live decks and keeping instantiated decks bound to exact footing,
rule insight,
grouped checks,
drift sentries,
and later reopenable aftermath.
