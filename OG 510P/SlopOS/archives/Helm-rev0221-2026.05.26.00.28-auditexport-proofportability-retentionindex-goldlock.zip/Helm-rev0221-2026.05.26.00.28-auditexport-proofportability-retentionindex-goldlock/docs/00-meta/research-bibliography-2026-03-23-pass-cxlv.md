# Research bibliography — 2026-03-23 pass CXLV

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-GITHUB-PROTECTED-BRANCHES-STALE-REVIEWS-2026D | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches | approvals bind to an exact reviewed diff and can be dismissed as stale when the diff changes |
| REF-K8S-PODS-OBSERVED-GENERATION-2026D | https://kubernetes.io/docs/concepts/workloads/pods/ | `metadata.generation` versus `status.observedGeneration` is a strong precedent for desired-versus-observed footing honesty |
| REF-DAGSTER-ASSET-VERSIONING-UNSYNCED-2026D | https://docs.dagster.io/guides/build/assets/asset-versioning-and-caching | visible `Unsynced` posture after code, dependency, or parent-data change is a strong precedent for stale-fence chrome |
| REF-DBT-MODEL-VERSIONS-2026D | https://docs.getdbt.com/docs/mesh/govern/model-versions | version windows, pinning, and live-version classes are strong precedents for epoch relations |
| REF-DBT-DEPRECATION-DATE-2026D | https://docs.getdbt.com/reference/resource-properties/deprecation_date | deprecation windows that block deletion under enforced contracts are a strong precedent for compatibility / retirement pressure |
| REF-LAUNCHDARKLY-FLAG-HEALTH-2026D | https://launchdarkly.com/docs/home/releases/flag-health | temporary control objects aging into stale/cleanup posture are a strong precedent for retirement pressure rather than forever-green control state |
