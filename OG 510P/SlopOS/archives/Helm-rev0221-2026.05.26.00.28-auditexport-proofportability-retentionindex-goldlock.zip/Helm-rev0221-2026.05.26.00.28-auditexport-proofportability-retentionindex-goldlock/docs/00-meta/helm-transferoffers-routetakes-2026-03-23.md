# Helm: transfer offers + route takes — 2026-03-23

## Headline

Helm should probably add one compact Exchange object for this sentence:

**this exact source is offering this exact material,
in these possible representations,
with this preview and trust posture,
and these are the nearby routes that could take it — but no receiver has been chosen yet.**

That object should be a **transfer offer**.

## Why now

Helm already has useful neighboring moves:
- ingress packets
- handoff packets
- route witnesses
- receiver-fit cards
- reach previews
- quarantine ribbons
- basis stamps
- helper escorts
- work claims
- action warrants

What it still lacks is the Exchange object between “material arrived” and “material landed.”
Without that,
Helm keeps risking four familiar lies:
- preview pretending to mean import happened
- a suggested target pretending to mean a receiver was chosen
- a promised file pretending to mean a local file already exists
- a many-representation item pretending to be only one lossy string

## The move

A Helm transfer offer should be:
- shell-owned
- over one exact offered thing or bounded bundle
- weaker than a chosen route
- able to preserve multiple representations
- explicit about materialization posture
- previewable without overclaiming ownership
- and easy to promote into a stronger route-specific act

## Why this is different from nearby objects

- **ingress packet** = how material entered
- **handoff packet** = a portable travel form for one admitted shell surface
- **route witness** = what exact route was chosen or attempted
- **receiver-fit card** = how well one target can accept the thing
- **effect receipt** = what actually happened later
- **transfer offer** = what is being offered now,
  in what representations,
  with what preview / promise / trust posture,
  before the take

That distinction matters.
A source may offer both HTML and plain text.
A drop may offer a directory handle.
A share surface may offer a preview and several route suggestions.
None of that means the receiver already owns materialized local state.

## Strongest ideas worth stealing

### 1. One offered thing can have several useful representations
Helm should keep the representation menu visible when it matters:
- plain text
- rich text / HTML
- image
- file
- directory
- URI
- object ref
- promised file
- provider-backed open-in-place

That is better than flattening early.

### 2. Deferred materialization is a feature
Windows and Apple both show the same idea:
do not do expensive or irreversible work until the taker really asks.
Helm should let an offer say:
- already materialized
- promised on demand
- provider-backed open in place
- preview only
- receiver-local import required

### 3. Preview should stay weak
The shell should gladly show a preview,
thumbnail,
metadata,
or quick compare,
but preview must not impersonate import,
attach,
open,
or publish truth.

### 4. Fast route suggestions are great,
but they are not selection truth
Android Direct Share is a strong reminder that suggestions can be fast and still remain only suggestions.
Helm should preserve:
- likely next receivers,
- recent exact routes,
- and saved route patterns,
while still requiring a real take.

### 5. Route-specific take receipts should come later
When a user or helper really chooses:
- insert
- quote
- import
- attach
- forward
- publish
- or open in place,
that later act deserves its own witness or receipt.
The offer should not smuggle that later truth early.

## What to keep from older inspirations

Keep:
- typed ingress
- explicit route choice
- preview-before-adopt joy
- exact chosen-target followthrough
- promised-material humility
- quarantine / trust posture near the seam

Peel away:
- universal clipboard religion
- path paste as the hidden final answer
- silent auto-conversion to whatever the receiver happens to like
- stale remembered targets masquerading as current choice
- “shared” badges that erase whether the route was insert,
  attach,
  publish,
  or only previewed

## Why this could make Helm super awesome

### 1. Exchange finally gets a real specimen family
Not just philosophy.
A transfer offer is a concrete proof-bearing object for one pillar that has stayed a little too prose-only.

### 2. Clipboard / drag / share / helper output all get calmer
They can feel richer without becoming spooky.
The shell can say what is on offer before it says what happened.

### 3. Omnibox and Recall get better route honesty
A recalled share,
dropped object,
or helper-produced artifact can reopen as an offer,
not as fake already-landed truth.

### 4. Receiver mismatch becomes easier to explain
The shell can say:
- this target only accepts plain text,
- this route would require import,
- this representation is only promised,
- or this environment cannot take the stronger handle.

### 5. Exchange can feel premium without becoming bureaucratic
A tiny transfer offer chip or card can make many routes feel obvious,
inspectable,
and fast.

## Pull-the-trigger judgment

Helm still should not freeze one final universal packet schema,
clipboard backend,
or giant share framework.
But it probably **is** time to warm one compact Exchange specimen:

**transfer offers** — shell-owned,
weak,
reviewable offered-material objects that preserve exact source,
multiple representations,
preview hints,
materialization posture,
trust/freshness notes,
and nearby route possibilities
without pretending a receiver or route has already been chosen.

That looks like a real next Helm move,
and it advances one pillar directly.
