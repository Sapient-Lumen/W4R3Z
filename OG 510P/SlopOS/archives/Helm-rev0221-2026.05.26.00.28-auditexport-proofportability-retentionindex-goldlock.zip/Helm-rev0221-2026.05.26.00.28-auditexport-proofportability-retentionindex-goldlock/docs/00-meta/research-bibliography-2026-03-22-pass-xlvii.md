# Research bibliography — 2026-03-22 — pass XLVII

Purpose: record the sources used for the claim-envelope and reliance-ladder pass.

## Primary sources

1. **Projects in ChatGPT**
   - add project instructions
   - add links from apps as project sources
   - save a response as a reusable project source
   - why useful: validates explicit current sources and saveable outputs that can become future ingredients
   - source: https://help.openai.com/en/articles/10169521-projects-in-chatgpt

2. **VS Code 1.110 release notes**
   - Agent Debug panel shows loaded prompt files, skills, hooks, tool calls, and chat events in real time
   - why useful: validates rich input-side visibility and pressures Helm to make output-side claim posture equally explicit
   - source: https://code.visualstudio.com/updates/v1_110

3. **Gemini Apps — sources and double-check**
   - sources can be shown when available
   - double-check can mark statements as likely similar, likely different, or not evaluable
   - why useful: validates keeping claims, evidence, and checking moves visibly separate
   - source: https://support.google.com/gemini/answer/14143489

4. **Google Workspace with Gemini — use sources**
   - Gemini can miss a source it used
   - Gemini can cite a document not directly used for a specific point
   - Gemini can in some cases make up a source
   - why useful: validates that source chips are evidence aids, not verdict badges
   - source: https://support.google.com/a/users/answer/16813283

5. **Google Sheets with Gemini**
   - analysis steps
   - source inspection for Drive/Gmail-backed answers
   - action preview card before Apply
   - why useful: validates claim/evidence surfaces plus a clear preview/apply ladder for proposed changes
   - source: https://support.google.com/docs/answer/14356410

6. **Google Drive — Gemini for research & analysis**
   - suggested sources are not used until explicitly added
   - citations open the originating file
   - saved projects lock in a specific set of source files
   - why useful: validates explicit selected sources, citation chips, and saveable scoped result contexts
   - source: https://support.google.com/drive/answer/16963068

7. **Notion working with views**
   - dashboard/widget views
   - create a view query with `query_id`
   - cached results have TTL and can be explicitly deleted
   - why useful: validates stable result slices that should carry freshness and expiry posture rather than timeless truth
   - source: https://developers.notion.com/guides/data-apis/working-with-views

8. **Notion get view query results**
   - cached result retrieval and expiration behavior
   - why useful: reinforces the need for saveable outputs that remain honest about staleness and expiry
   - source: https://developers.notion.com/reference/get-view-query-results

## SlopOS sources re-read this pass

1. `docs/30-architecture/verification-verdict-boundary-v0.md`
2. `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
3. `docs/30-architecture/attestation-collateral-status-boundary-v0.md`
4. `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
5. `docs/30-architecture/openuri-recent-items-boundary-v0.md`

## Why these sources mattered

This pass was about checking whether today’s strongest tools are rewarding:
- explicit sources,
- visible checking moves,
- preview-before-apply output posture,
- saveable outputs with freshness limits,
- and richer visibility into what a system did **without** pretending that those surfaces amount to universal truth.

They are.
