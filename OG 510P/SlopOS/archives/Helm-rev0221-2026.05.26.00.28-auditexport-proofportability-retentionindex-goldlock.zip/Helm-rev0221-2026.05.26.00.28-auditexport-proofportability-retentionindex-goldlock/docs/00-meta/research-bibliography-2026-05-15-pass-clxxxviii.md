# Research bibliography — 2026-05-15 — pass CLXXXVIII

Load-bearing sources reviewed for rev0195:

- Git rerere documentation — recorded conflict-resolution reuse, forget/abort commands.
- Sentry fingerprint rules and issue grouping documentation — shape matching, fingerprint overrides, grouping limitations.
- OpenTelemetry context propagation and semantic conventions — correlation keys and common names across signals.
- OpenFeature evaluation context specification — scoped context, precedence, context propagation.
- OPA decision logs documentation — decision ids and audit/debug events.
- Kubernetes finalizers documentation — finalizer keys and deletion/cleanup gates.
- in-toto attestation link predicate documentation — subject/material/byproduct shape.
- Temporal message-handling documentation — durable handlers, atomicity, idempotency pressure.

Research conclusion: Helm should steal small explicit envelopes, not control planes.
