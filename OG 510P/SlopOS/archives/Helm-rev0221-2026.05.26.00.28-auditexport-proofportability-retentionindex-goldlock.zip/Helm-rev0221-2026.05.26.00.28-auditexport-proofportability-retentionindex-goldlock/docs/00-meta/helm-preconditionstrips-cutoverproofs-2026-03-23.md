# Helm: precondition strips + cutover proofs — 2026-03-23

Keep the seven pillars stable.
Do not add another pillar.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **footing marks**, typed **delta ladders**, **footing death cards**, **residue ladders**, **renewal beacons**, and **overlap handoffs** as the current substrate grammar beneath humane return loops.

But after making continuity age and replacement posture explicit,
one narrower guarded-transition seam now looks worth warming:

**precondition strips** so the shell can say what exact basis an act depends on,
paired with **cutover proofs** so the shell can say whether the boundary crossed under that guard,
failed closed,
raced,
or now requires a restart-class rebuild.

## Why this now looks necessary

A renewal beacon answers:
- is this footing aging?
- what renewal or replacement verb exists?
- did the old/new swap happen with overlap?

But premium systems also do something stricter at the moment of action:
- they compare against an exact witness,
- they fail closed if the witness no longer matches,
- and they preserve the difference between mismatch,
  race,
  disappearance,
  and restart-required aftermath.

Without that seam,
Helm is tempted to say `replace`, `commit`, `publish`, or `land` as though every serious move were just one button plus a spinner.
That is comforting,
but not honest.

## The smallest object pair

### Precondition strip
A compact shell-owned guard card that says:
- what exact subject or pending transition is in play,
- what witness material it compares against,
- what kind of guard it is,
- whether the guard means `must still equal`, `must still be absent`, `must still be this version`, `must still be this run/replica count`, or `must continue sequentially`,
- and what exact next verbs remain if the guard breaks.

Likely first classes:
- `exact-match`
- `absent-only`
- `version-still-current`
- `replica-count-still-current`
- `sequential-upload-range`
- `opaque-token-still-valid`
- `unknown-provider-guard`

### Cutover proof
A compact shell-owned result receipt for a guarded transition that says:
- what was attempted,
- what exact guard it relied on,
- whether it crossed atomically under that guard,
- whether it failed closed,
- whether it lost a race,
- whether partial progress exists,
- and whether the next honest move is retry,
  rebind,
  restart,
  or rebuild.

The point is not to invent one giant transaction plane.
The point is to stop forcing operators to infer guarded-cutover truth from hidden provider folklore.

## What the web now teaches

The current official product pressure converges on this pair.

Google Cloud Storage request preconditions let clients require exact generation or metageneration matches, can combine multiple preconditions on one request, and fail the whole request with `412 Precondition Failed` if any guard no longer holds.
A special `ifGenerationMatch=0` mode says `create only if no live version exists`, which is a wonderfully explicit no-clobber guard.
Amazon S3 conditional writes do the same at HTTP level: `If-None-Match` protects create-if-absent, `If-Match` protects replace-if-current, and the docs keep `412` mismatch separate from `409 Conflict` races and `404` disappeared-target cases.
etcd transactions make the same deeper move in another shape: atomic `If/Then/Else` guarded by compare inputs, i.e. compare-and-swap as a first-class primitive.
`kubectl scale` likewise allows `--current-replicas` or `--resource-version` preconditions and says those conditions are validated before the scale is attempted.
Microsoft Graph upload sessions add a valuable commit lesson: uploaded fragments and final creation are not the same truth; the last-byte commit may still fail with a conflict, and explicit commit can carry `If-Match` plus a source upload URL.
Google Drive resumable uploads keep another important distinction visible: do not assume the server received all bytes just sent, use the returned `Range`/status to determine the next step, and restart from scratch when the session URI has expired.

Together these are almost a design brief for Helm:
**serious acts should not only name what they would change;
they should confess the exact guard that made the attempt honest,
and the exact cutover class that followed.**

## What this lets Helm do better

### Recall
Recall can stop pretending an earlier reviewed slice is safe to republish just because it was once correct.
It can say:
- `guarded by exact reviewed basis`
- `guard failed closed`
- `raced; refresh current footing`
- `restart required`

### Operations Center
Scale,
promotion,
landing trains,
continuations,
and aftermath decks can show one compact guard strip and one cutover proof,
not just `attempted` or `failed`.

### Object Browser
Publish,
replace,
move,
and materialize acts can expose whether they were `create only if absent`, `replace only if current`, or `lost race / restart`.

### Exchange
Upload sessions,
transfer routes,
and receiver-visible publication can expose whether bytes were merely staged,
which ranges remain,
and whether final commit crossed under an exact guard.

## Lessons Helm must keep learning from the past

- `looks current` is weaker than `guarded by exact current witness`.
- Renewal/replacement posture is not the same as guarded commit posture.
- `409`, `412`, and `404` tell different recovery stories and should stay different.
- Partial upload progress is not final publication.
- A guard can prove a clean veto without proving durable effect.
- Ambient `latest` is not a precondition basis.

## Awesome moves this enables

- one tiny `guarded by ETag X` or `create only if absent` strip on serious actions;
- one `crossed under guard`, `failed closed`, or `lost race` result line;
- one exact next verb such as `refresh basis`, `retry`, `restart session`, or `rebuild`;
- one refusal to let yesterday's reviewed footing silently become today's mutation authority.

## Best current decision

Still do not add another pillar.
Still do not build a universal transaction center.
Still do not flatten guarded transitions into one comfort badge.

But it now looks wise to warm **precondition strips** and **cutover proofs** as the next guarded seam above **renewal beacons** and **overlap handoffs**.
