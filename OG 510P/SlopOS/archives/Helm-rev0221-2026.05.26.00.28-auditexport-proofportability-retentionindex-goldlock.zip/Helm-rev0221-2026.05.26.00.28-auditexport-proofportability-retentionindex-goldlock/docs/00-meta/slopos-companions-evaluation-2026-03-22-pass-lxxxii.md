# SlopOS + companions evaluation — 2026-03-22 — pass LXXXII

Purpose: re-read the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one tighter question:
**what should Helm learn now about generations, attenuation, and recipe-grade portability while those companion cubes are still in design phase?**

## 1. SlopOS keeps teaching that rollback should be ordinary, not ceremonial

`adrs/0004-config-as-compiled-artifact-and-generations.md` is one of the clearest design wins in SlopOS.
It refuses live-file folklore,
keeps privileged logic small,
and treats **generations** as the normal UX for change and rollback.

Helm should steal that posture for shell-owned strong objects:
- saved views
- front doors
- deck recipes
- promotion-ready landing artifacts
- capability recipes

The lesson is not “copy Nix.”
The lesson is:
**if a strong shell surface can materially change,
it should be easy to name the current generation,
compare to the previous one,
and roll back without drama.**

## 2. SlopOS also keeps the hardest humility: an exact generation is still not current live truth

`lease-descriptor-state-boundary-v0.md` is still the right warning.
An issued descriptor can be exact about what was reviewed or issued,
without becoming a portable oracle for what is live now.

That means Helm should distinguish at least four things:
- **current-live beacon**
- **exact generation**
- **floating alias/front door**
- **capability recipe**

If Helm blurs those,
its datacube becomes flattering but dishonest.
If it keeps them separate,
it gets a much better reopening,
sharing,
and rollback story.

## 3. ViewFS teaches that attenuation and grouping should be explicit objects, not ambient inheritance

`rights-attenuation-and-bundles.md` stays a very healthy companion note.
Attenuation should be cheap,
visible,
and one-way.
Bundles should be explicit transport/grouping objects,
not hidden namespace inheritance.

That pushes Helm toward two good moves:
- **attenuated reveal links / share tickets** that are visibly narrower than full workspace or device sharing
- **capability recipes** that explicitly name what exact handles,
  authorities,
  or launch ingredients are needed

Helm should steal the explicitness,
not a giant bundle studio.

## 4. Steward keeps reminding Helm that exact selection is the real start of safe sharing

`chooser-surface-posture-v0.md` still feels exactly right.
Chooser outputs should resolve to exact selectors or anchors when possible,
stay ephemeral by default,
and keep downgrade visible when only weaker matched text survives.

That is very relevant for Helm's share model.
A good attenuated link should start from:
- one exact selected object,
- one exact saved view,
- one exact cohort,
- or one exact generation,

not from ambient “whatever was nearby” folklore.

## 5. Schell keeps the display layer humble

Schell's title/label/witness posture remains a useful warning.
Generation names,
share-link labels,
and recipe titles will be useful,
but they should still cite stronger witnesses.

Helm should let labels help orientation,
while making sure these stronger truths stay inspectable:
- exact subject
- exact generation or floating alias relation
- authority rung
- expiry / revocation posture
- current-live versus historical posture

## 6. The design-phase lesson is becoming more specific

Because the companion cubes are still design-phase systems,
Helm should mostly freeze:
- the split between current-live truth and exact generations
- the split between exact generations and floating aliases
- explicit attenuation posture for shared / traveled links
- recipe objects staying weaker than live grants
- rollback as normal UX rather than emergency mode

Helm should avoid freezing:
- giant policy studios
- giant bundle catalogs
- universal capability registries
- a huge permanence story for every recipe or generation family

## 7. Best next Helm moves after this pass

### Pull warmer now
- **generation cards and rollback rails** for strong saved shell objects
- **attenuated reveal links / share tickets** with exact subject,
  audience class,
  expiry,
  and revoke posture
- **capability recipes** as weaker-than-live portable starters

### Keep warm only
- giant universal bundle editors
- giant generation-control consoles
- automatic recipe healing that silently reacquires more than it admitted
- public-link mythology for everything

## Judgment

The companion cubes are still most valuable when they teach **discipline**.

The next Helm gain is not a new pillar.
It is a cleaner shell grammar around:
- **current live**
- **exact generation**
- **floating alias**
- **attenuated link**
- **capability recipe**

That would make Helm's datacube stronger,
more portable,
and much more honest.
