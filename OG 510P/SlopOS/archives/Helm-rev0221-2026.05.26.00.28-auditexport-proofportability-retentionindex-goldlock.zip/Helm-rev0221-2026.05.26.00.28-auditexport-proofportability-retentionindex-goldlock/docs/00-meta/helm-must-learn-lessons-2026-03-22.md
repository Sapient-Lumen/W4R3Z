# Helm must-learn lessons from the past — 2026-03-22

Purpose: keep the archive honest about the failures Helm most needs to avoid.

## 1. Hidden chooser logic always looks smart right before it becomes creepy

If several candidates are plausible,
the shell should admit that.
A silent winner is rarely a gift.

## 2. Nearby success is not exact success

Open parent directory is not reveal exact item.
Reopen a saved starter is not resume the live thing.
Public link is not named private share.
Preview is not adopt.

## 3. Labels are navigation help,
not durable truth

Titles,
badges,
restored names,
imported labels,
detector guesses,
and AI summaries are useful.
They are not the deepest truth available.

## 4. Saved,
historical,
and live must remain separate

A good shell can help users move between those states quickly.
A good shell should not flatten them.

## 5. Ambient access always overpromises

Broad default reach feels magical for a minute.
Then it becomes impossible to reason about.

Helm should begin with exact subject,
current thing,
or chosen subset.

## 6. Review must bind to exact mutable basis

A review without basis is theater.
A plan without basis is theater.
A restored action without basis is nostalgia.

## 7. Restricted-first is more humane than all-or-nothing trust

People often want to inspect before they adopt,
browse before they trust,
and preview before they empower.
The shell should help that.

## 8. One giant cube always sounds more elegant than it feels

In practice,
giant cubes tend to create:
- dashboard overclaim,
- ambient sync mythology,
- invisible widening,
- blurred object classes,
- and fake certainty.

## 9. Suggestions must stay weaker than action

The right AI stance is:
propose,
explain,
let the operator choose,
receipt what happened.

## 10. Exposure classes matter

Local,
private,
org-visible,
guarded-link,
and public are not cosmetic distinctions.
They are product truth.

## Final reminder

Helm should feel brilliant because it makes power legible,
not because it hides complexity behind confidence theater.
