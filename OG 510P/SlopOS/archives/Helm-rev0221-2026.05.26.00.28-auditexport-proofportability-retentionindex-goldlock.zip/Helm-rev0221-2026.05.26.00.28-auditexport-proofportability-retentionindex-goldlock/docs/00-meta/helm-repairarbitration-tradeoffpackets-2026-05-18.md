# Helm repair arbitration / tradeoff packets — 2026-05-18

Revision: rev0200

## Pull the trigger

Accept **repair arbitration packets** as the next proof-fixture object.

This is not a scheduler. It is not a priority engine. It is not a scorecard. It is not a release readiness answer. It is the smallest honest object that lets Helm answer: when several covenants need repair, what goes first, what is deferred, what resource is being spent, and what remains degraded?

## Why this is a Helm-grade move

Helm’s datacube is getting good at truth lanes, evidence, consequences, settlement, learning, exceptions, obligations, and covenants. The next failure mode is ordinary product pressure: users will ask for a single “what do I fix now?” answer. If Helm answers with a score, it will erase the strongest lesson from the past: one unresolved breach remains unresolved even if the portfolio looks mostly green.

Repair arbitration keeps the magic useful:

- it gives a clear next move;
- it names the scarce slot;
- it preserves every source covenant posture;
- it leaves losers visible;
- it records a starvation guard;
- it refuses to become a scheduler or policy engine.

## Lessons from the past

- Do not let a queue hide work. The old “work queue as truth” lie causes due work to vanish under priority labels.
- Do not let urgent become permanent. Critical work may preempt, but repeated preemption must create a fairness guard.
- Do not let kept become invisible. A kept covenant can be parked, not erased.
- Do not let resource ownership be ambient. Scarce slots must name owner, expiry, and sponsor.
- Do not let “mostly healthy” become a product mood. The board can group by posture but cannot reduce truth to a grade.

## Nifty ideas to steal

- Burn-rate thinking: urgency should depend on window and rate of harm, not just label color.
- Fair queueing: same-priority streams should not starve each other.
- Merge train/queue honesty: queue position should be visible, tested against moving context, and re-run after removals.
- Cost allocation: spend is clearer when tied to named resources and owners.
- Correction windows: planned deferral must leave an explicit record.

## Hard refusals

No hidden scheduler, no global priority policy, no implicit owner preference, no automatic SLO/scorecard authority, no release approval from queue position, no current-readiness answer from arbitration, no global memory precedent from repair order.

## Next proof

Render the repair board and port one arbitration packet to a second specimen without adding fields.
