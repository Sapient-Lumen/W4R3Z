# Research bibliography — 2026-03-22 — pass XLIII

## Current tools and support docs

- OpenAI help — Projects in ChatGPT; shared projects force project-only memory and keep context bounded to resources inside the project.
- Linear docs — Projects, attached issue views as tabs, project details/resources, and custom views with favorites/default-page behavior.
- Slack help — tabs and folders in channel/DM headers; files, links, and pinned messages can move in and out of folders.
- Dropbox Dash docs — Stacks as shareable grouped resources with one context-rich entry surface.
- VS Code docs — Profiles editor, export/import/share, and preview before import/export.
- Warp docs — Launch Configurations for saving windows, tabs, and panes per project.
- Microsoft Learn — PowerToys Workspaces for capturing a desktop state and relaunching it quickly.
- Google Chrome help — saved tab groups in the bookmarks bar and on other devices under the same account.
- Google Docs help — tabs with direct links and explicit current-tab versus all-tabs export/print.

## Why these sources matter for this pass

This pass was mainly about deciding whether Helm should sharpen an older warm object:
**activity entry kits / front doors**.
