# Research bibliography — 2026-03-21 — pass IX

Compact outside source memory for pass IX.

## Handoff / session / review pressure

- VS Code agent overview documentation
- VS Code custom agents / handoffs documentation
- VS Code cloud agents documentation
- VS Code chat sessions documentation
- VS Code February 2026 release notes

## Launch / reuse / workspace pressure

- Microsoft PowerToys Workspaces documentation
- Microsoft PowerToys Command Palette documentation
- Microsoft PowerToys Peek documentation
- Microsoft PowerToys FancyZones documentation

## Scope / private-share / accelerator pressure

- VS Code browser agent tools documentation
- VS Code Profiles documentation
- Raycast Quicklinks documentation
- Raycast Dynamic Placeholders documentation

## Small witness-panel pressure

- GNOME Help: Activities overview / workspaces
- Node-RED sidebar / debug sidebar documentation
- Obsidian Workspaces documentation

## Pass-IX bounded take

The current external idea harvest most strongly supports two Helm moves:
- freeze continuity-choice/authorship truth narrowly,
- and explore continuity choice witnesses as compact shell-owned continuity luxuries.
