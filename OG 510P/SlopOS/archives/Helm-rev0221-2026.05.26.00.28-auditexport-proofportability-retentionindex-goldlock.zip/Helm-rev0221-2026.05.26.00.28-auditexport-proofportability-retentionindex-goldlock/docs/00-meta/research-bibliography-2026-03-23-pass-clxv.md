# Research bibliography — 2026-03-23 — pass CLXV

Sources consulted for the renewal-beacon / overlap-handoff pass.

1. Google Drive API — Notifications for resource changes
   https://developers.google.com/workspace/drive/api/guides/push

2. Google Calendar API — Push notifications
   https://developers.google.com/workspace/calendar/api/guides/push

3. Google Calendar API — Synchronize resources efficiently
   https://developers.google.com/workspace/calendar/api/guides/sync

4. Google Calendar API — Handle API errors
   https://developers.google.com/workspace/calendar/api/guides/errors

5. Microsoft Graph — Update subscription
   https://learn.microsoft.com/en-us/graph/api/subscription-update?view=graph-rest-1.0

6. Microsoft Graph — Reduce missing subscriptions and change notifications
   https://learn.microsoft.com/en-us/graph/change-notifications-lifecycle-events

7. Microsoft Graph — Delta query overview / user delta
   https://learn.microsoft.com/en-us/graph/api/user-delta?view=graph-rest-1.0

8. Microsoft OneDrive — Error responses
   https://learn.microsoft.com/en-us/onedrive/developer/rest-api/concepts/errors?view=odsp-graph-online

9. Dropbox — Detecting Changes Guide
   https://developers.dropbox.com/detecting-changes-guide

10. etcd — API guarantees
    https://etcd.io/docs/v3.4/learning/api_guarantees/

11. etcd — Interacting with etcd
    https://etcd.io/docs/v3.6/dev-guide/interacting_v3/

12. Kubernetes — Leases
    https://kubernetes.io/docs/concepts/architecture/leases/

13. Google Cloud Pub/Sub — Extend ack time with lease management
    https://docs.cloud.google.com/pubsub/docs/lease-management

14. Google Cloud Pub/Sub — Snapshot reference
    https://docs.cloud.google.com/pubsub/docs/reference/rest/v1/Snapshot
