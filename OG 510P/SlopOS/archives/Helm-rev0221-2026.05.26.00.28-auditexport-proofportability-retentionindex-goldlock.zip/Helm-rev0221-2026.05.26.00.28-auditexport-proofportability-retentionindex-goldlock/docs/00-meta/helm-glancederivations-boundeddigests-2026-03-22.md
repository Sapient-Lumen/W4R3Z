# Helm: glance derivations + bounded digests — 2026-03-22

Purpose: name the next compact support move that now looks worth warming after the latest SlopOS reread and current-tool pass.

## Main idea

Helm now has:
- saved view objects,
- review tickets,
- drift beacons,
- basis contrast cards,
- view subscriptions,
- exact front-door handles,
- and a weak Overview direction.

What is still missing is one small object for **glanceable derivative state**.

The right answer now looks like:
- keep the **saved view** as the durable exact source,
- let it emit a small shell-owned **glance derivation**,
- let subscriptions prefer **bounded digests** over raw floods,
- and let Overview lean on those glance derivations without pretending they are live truth.

## 1. Glance derivations

A **glance derivation** is a small shell-owned derivative object computed from one exact source view or one exact review ticket.

It can express things like:
- count
- threshold state
- top-N summary
- compact delta since basis
- degraded / unavailable / expired posture
- one tiny trend or rollup

It is not the source view itself.
It is not current-live proof.
It is not a giant dashboard widget family.

### Why this now looks valuable

The current tools keep converging on the same pattern:
- Notion makes saved slices cached and expiring,
- Grafana pre-computes repeated expensive queries into smaller derivative metrics,
- Jira subscriptions stay attached to saved filters and keep delivery bounded,
- Atlassian Analytics keeps dashboard freshness and subscription refresh posture explicit.

Helm can steal the principle without becoming an observability suite:
**small derivative summary artifacts are good when they stay source-witnessed, expiring, and weaker than the stronger source lane.**

## 2. Bounded digests

Helm subscriptions should often deliver a **digest**, not the whole result universe.

Good first digest shapes are:
- changed count
- top three entries
- one threshold crossing
- one compact delta since last fire
- one open-the-source-view path

This is better than giant raw result spam,
and it keeps the shell honest that the notification is only a derived summary.

## 3. Overview should borrow glances, not become a dashboard constitution

Overview is already warming as a weak landing surface.
This pass sharpens how it should stay healthy.

Overview should be able to show:
- current-live beacons,
- linked views,
- exact front-door handles,
- maybe one bounded ops slice,
- and a few **glance derivations**.

That is enough.
The right feeling is “glance and jump back in,”
not “live in a permanent giant dashboard.”

## 4. What this keeps and what it rejects

### Keep
- exact saved view objects
- review tickets as stable-enough slices
- subscriptions attached to exact source views
- explicit freshness / expiry / stale posture
- open-the-source-view paths next to summaries

### Reject
- giant live home-screen mythology
- summary cards that overwrite source truth
- subscriptions that dump everything
- silent auto-refresh under review
- hidden background derivation daemons that users cannot inspect

## 5. What now looks wise to pull the trigger on

### Pull the trigger now
- **glance derivations** as candidate shell objects

### Advance with them
- **bounded digest delivery** as the preferred delivery posture for many view subscriptions

### Keep warm
- richer overview tile composition
- small trend/history siblings of glance derivations
- publication/share ladders for derived glances when those start to travel

## 6. Why this could make Helm super awesome

This move gives Helm something many products get wrong:
**small honest power.**

A user could:
- see a saved triage view as a count-plus-top-three digest,
- see an at-risk view as a threshold card,
- see that a derived glance is stale or expired,
- click straight into the exact stronger source view,
- and still keep Overview compact instead of dashboard-bloated.

That feels fast,
humane,
and unusually truthful.

## Judgment

Helm still does not need another pillar.
It needs one more support object.

The best next move now looks like:
- **glance derivations**
- plus **bounded digest delivery** for view subscriptions

That makes Helm more glanceable,
more composable,
and more alive without turning the datacube into a giant command center or hidden summary machine.
