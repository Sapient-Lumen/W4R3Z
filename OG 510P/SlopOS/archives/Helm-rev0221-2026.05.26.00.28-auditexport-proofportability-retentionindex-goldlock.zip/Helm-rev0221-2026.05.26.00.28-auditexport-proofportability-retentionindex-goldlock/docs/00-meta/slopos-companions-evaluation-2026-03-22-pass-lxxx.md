# SlopOS + companion-cube evaluation — 2026-03-22 — pass LXXX

This pass asked a tighter question than rev0085:

**which design-phase lessons now justify new Helm ratchets around exact remembered handles,
constrained helper lanes,
and named protection gates?**

The answer is still conservative:
**freeze the discipline,
freeze a few ergonomic ratchets,
and keep the giant family machine warm.**

## 1. SlopOS is still the best teacher for exact-not-nearby truth

SlopOS continues to earn trust where it refuses flattering shortcuts:

- chooser-owned candidate universes stay bounded
- exact reveal/select stays stronger than “something nearby probably counts”
- request-local portals stay weaker than portable authority
- descriptor,
  live state,
  and historical evidence stay visibly separate

For Helm,
that means one very concrete import:
**remembered access should prefer exact handles over approximate paths,
labels,
or guessed reopens.**

If Helm wants to reopen,
re-enter,
attach,
or share something later,
it should try to carry an exact subject witness,
not a comforting story about where something used to be.

## 2. SlopOS is still best stolen as a discipline engine,
not as a family count target

SlopOS keeps proving that small seam cuts matter more than giant nouns.
Its datacube is strongest when it says:

- this meaning is not that meaning
- this chooser is not that authority
- this historical evidence is not current-live truth
- this exact success must not silently widen

Helm should steal that moral pressure directly.
It should **not** respond by cloning a huge parallel forest of object families before shell proof pressure demands them.

## 3. Schell keeps proving that labels,
previews,
and restored names stay weaker than identity

Schell remains one of the best warnings against glamorous shell folklore.
Its title,
label,
and override work keeps teaching that the comfort layer is useful,
but weaker than exact subject truth.

That lesson becomes more important once Helm starts remembering exact handles.
A remembered handle may have:
- a nice label,
- a last-known location,
- a restored title,
- a suggested local match,
- or a historical thumbnail,

but those comforts must stay weaker than the exact handle,
its access posture,
and its current-resolve result.

## 4. ViewFS keeps proving that lane separation matters more as Helm gets more capable

ViewFS keeps pressing the same lesson from different angles:

- observe
- attach
- control
- debug / exec
- sideband / exposure
- transcript / history

must remain distinct lanes.

That lands directly on Helm's next step.
If Helm introduces helper lanes,
adoption harbors,
or more autonomous operator aids,
then those lanes need visible differences in:
- allowed verbs
- allowed files / objects
- allowed hosts / peers
- adoption status
- result truth

Otherwise the shell will quietly regress into “one connected thing with vibes.”

## 5. Steward keeps proving that chrome should surface posture,
not hide it

Steward's recent posture docs keep reinforcing a valuable shell habit:
chrome should reveal source,
precision,
trust,
checkpoint,
and activation posture without pretending those labels are the truth themselves.

That is exactly the right companion pressure for three new Helm moves:

1. **remembered handles** should show whether access is current,
   stale,
   re-requestable,
   or merely historical
2. **helper lanes** should show permission mode,
   sandbox bounds,
   and whether they are observational,
   preparatory,
   or adoption-ready
3. **protection gates** should show what is still waiting,
   who must approve,
   what rule fired,
   and whether the gate result is historical or current

## 6. What looks wise to ratchet now

### Ratchet now

1. **Exact remembered handles**
   - carry exact subject witnesses for reopened files,
     folders,
     services,
     routes,
     and shared objects where the host makes that possible
   - keep labels,
     paths,
     and thumbnails explicitly secondary
   - show re-request / repair posture nearby instead of bluffing continuity

2. **Constrained helper lanes**
   - helper or delegated work should run with visible bounds,
     not ambient shell reach
   - file/object scope,
     network scope,
     and permission mode should all stay inspectable

3. **Named protection gates for stronger acts**
   - publish,
     apply,
     expose,
     and route-commit steps should be able to wait on visible gate outcomes
   - review,
     delay,
     policy,
     and custom external checks should stay separate from execution truth

4. **Requested-target pickers**
   - when Helm is asking for access to one likely thing,
     start the chooser near that exact target instead of dropping users into a giant generic browse universe

### Keep warm

- one universal collaboration object
- giant shared-workspace mythology
- giant policy consoles
- whole-system background-agent religion
- family proliferation just because a move has a good name

## 7. What this means for Helm's pillars

- **Tiling Shell** should carry exact front-door handles and remembered object anchors without pretending that everything is still live.
- **Omnibox** should summon exact remembered handles,
  show re-request posture,
  and make the narrowest safe rung fast.
- **Object Browser** should distinguish current handle access,
  stale handle memory,
  and nearby local guesses.
- **Operations Center** should show helper-lane sandbox bounds,
  named protection gates,
  and gate outcomes as first-class status.
- **Desktop Flow** should let stronger flows stop at protection gates instead of faking success early.
- **Recall** should say whether return is live,
  exact-handle-backed,
  repaired,
  or merely historical.
- **Exchange** should make requested-target pickers,
  receiver-fit,
  and exact-handle travel ordinary product truth.
- **Terminal/Capshell** should wear permission mode,
  sandbox bounds,
  and remembered-handle posture openly instead of hiding behind PTY folklore.

## Closing judgment

SlopOS and the companion cubes are still strongest when they teach **discipline before machinery**.

The next durable Helm leap is not a larger datacube.
It is a tighter shell grammar where:
- exact remembered handles beat path nostalgia
- constrained helper lanes beat ambient helper reach
- named protection gates beat hidden final-step magic

That makes Helm more powerful **and** more honest at the same time.
