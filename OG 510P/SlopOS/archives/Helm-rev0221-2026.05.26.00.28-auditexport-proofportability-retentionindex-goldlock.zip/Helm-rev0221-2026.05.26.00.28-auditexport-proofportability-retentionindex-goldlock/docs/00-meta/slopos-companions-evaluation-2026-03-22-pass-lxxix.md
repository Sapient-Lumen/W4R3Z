# SlopOS + companion-cube evaluation — 2026-03-22 — pass LXXIX

This pass asked a narrower question than the previous one:

**which lessons from SlopOS's datacube are now strong enough to ratchet into Helm,
and which companion-cube ideas should remain warm rather than frozen?**

The answer is still:
**freeze the laws early,
freeze a few ratchets early,
and keep the larger families warm.**

## 1. SlopOS is still teaching the most important shell lesson: candidate truth beats flattering certainty

The strongest tiny SlopOS documents still punch above their weight.

`namecert-selection-boundary-v0.md` says evaluation may yield a bounded candidate set and must not quietly pick a winner.
`openuri-showitem-exactness-boundary-v0.md` says exact reveal/select must not silently degrade into nearby browse.
`powerbox-posture-v0.md` keeps chooser-owned candidate universes and refuses app-visible ambient grant inventory.
`openuri-portal-posture-v0.md` keeps launch request-local,
manual,
scheme-gated,
and one-way.

Taken together,
these teach a stable Helm law:

- candidate sets may be real,
- exactness matters,
- chooser universes stay bounded,
- and request-local convenience must not become portable authority.

## 2. SlopOS's datacube is most valuable as a discipline engine, not as a shape to clone

SlopOS remains strongest where it:
- keeps candidate architecture explicit,
- cuts one question into one visible seam,
- refuses silent widening,
- and separates request,
  descriptor,
  live state,
  and historical evidence.

That makes SlopOS a very good parent teacher for Helm.
It does **not** make SlopOS a template for one giant Helm object family.

The lesson Helm should steal is:
**separate meanings earlier than you separate interfaces,
and separate interfaces earlier than you freeze giant families.**

## 3. Schell keeps proving that the native meaning floor should stay smaller than the comfort layer

Schell continues to insist that:
- shell-known truth should stay exact and narrow,
- renderer-local or helper-local luxuries should remain weaker,
- labels and previews should keep provenance,
- and rich help should suggest before it claims.

Helm should ratchet that directly:
labels,
preview cards,
restored names,
imported summaries,
and AI hints should all stay weaker than exact identity,
current-live beacons,
basis witnesses,
and receipts.

## 4. ViewFS keeps proving that operational lanes matter more than giant live-session mythology

ViewFS's best shell work keeps pressing the same separation:

- observe
- attach
- control
- debug/exec
- sideband/exposure
- transcript/history

are **different lanes**.

That is a major Helm lesson for Operations Center,
Recall,
Exchange,
and Terminal/Capshell.
A beautiful shell lies the instant those lanes collapse into one vague “connected” state.

## 5. Steward keeps proving that chrome must stay humble

Steward's label,
chooser,
and chrome postures keep teaching three durable truths:

- visible chrome text is not canonical identity,
- chooser results should resolve to exact targets when possible,
- and observation surfaces should stay observational unless a stronger seam is invoked.

Helm should steal that everywhere.
It is one of the cleanest ways to avoid building a shell that *looks* premium while quietly becoming folklore-driven.

## 6. What looks wise to ratchet now

Not a bigger constitution.
Just a few stronger laws and specimens.

### Ratchet now

1. **Restricted-first imported posture**
   - imported,
     rebound,
     borrowed,
     or helper-generated things start inspectable and weaker than local live truth until adopted.

2. **Saved-plan / reviewed-basis posture for stronger acts**
   - any materially stronger change should be able to carry exact basis,
     exact scope,
     and an inspect-before-apply step.

3. **Exposure ladders instead of one generic share/open state**
   - local preview/open,
     named/private cohort,
     org/tailnet,
     guarded-link,
     and public should stay visibly different.

4. **Narrowest-safe-rung ergonomics**
   - the best default shortcut should often be:
     adopt the narrowest legal version of this act.

5. **Candidate truth before action truth**
   - if a choice still exists,
     Helm should show it rather than pretending it has already been resolved.

### Keep warm

- giant workspace objects
- universal collaboration state
- giant live dashboards
- durable cross-provider sync mythology
- heavyweight family machinery for every warm idea

## 7. What this means for Helm's pillars

- **Tiling Shell** should make saved layout/front-door truth honest rather than simulate continuity.
- **Omnibox** should become the best place to summon parameterized front doors and inspect stronger acts before promotion.
- **Object Browser** should make exact reveal,
  restricted arrivals,
  and adoption posture ordinary product truth.
- **Operations Center** should become the place where observe/attach/control/exposure lanes are unmistakably different.
- **Desktop Flow** should make saved-plan → inspect → apply a first-class posture.
- **Recall** should tell the truth about current-live,
  historical,
  repaired,
  and adoption-needed return paths.
- **Exchange** should own exact audience/exposure ladders and receiver-fit before adoption.
- **Terminal/Capshell** should wear title/source/exposure witnesses openly rather than hiding behind terminal folklore.

## Closing judgment

SlopOS's datacube is still a very strong parent teacher,
but its greatest gift to Helm is not a giant family tree.

Its greatest gift is a moral one:

**be exact about stronger acts,
humble about weaker surfaces,
and explicit whenever a human choice still exists.**
