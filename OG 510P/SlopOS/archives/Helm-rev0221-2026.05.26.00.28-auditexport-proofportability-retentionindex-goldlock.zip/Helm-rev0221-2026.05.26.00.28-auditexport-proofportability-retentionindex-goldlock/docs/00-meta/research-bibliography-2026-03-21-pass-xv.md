# Research bibliography — 2026-03-21 pass XV

Official/public sources consulted in this pass:

- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Apple Support — What's new in the updates for macOS Tahoe 26  
  https://support.apple.com/en-us/122868
- Apple Support — Search for anything with Spotlight on Mac  
  https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac
- Apple Support — Search your Clipboard history in Spotlight on Mac  
  https://support.apple.com/guide/mac-help/search-your-clipboard-history-mchl40d5b86b/mac
- Apple Support — Perform quick actions in the Finder on Mac  
  https://support.apple.com/guide/mac-help/perform-quick-actions-in-the-finder-on-mac-mchl97ff9142/mac
- GNOME Help — Visual overview of GNOME  
  https://help.gnome.org/gnome-help/shell-introduction.html
- Microsoft Learn — PowerToys Command Palette overview  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — PowerToys Command Palette extensibility overview  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/extensibility-overview
- Microsoft Learn — PowerToys Crop And Lock  
  https://learn.microsoft.com/en-us/windows/powertoys/crop-and-lock
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Docs — URI Scheme  
  https://docs.warp.dev/terminal/more-features/uri-scheme
- Warp Docs — Agent Modality  
  https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality
- Warp Docs — Interacting with Agents  
  https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents
- WezTerm Docs — Launching Programs / Launcher Menu  
  https://wezterm.org/config/launch.html
- WezTerm Docs — launch_menu  
  https://wezterm.org/config/lua/config/launch_menu.html
- VS Code Docs — Terminal Shell Integration  
  https://code.visualstudio.com/docs/terminal/shell-integration
- Node-RED Docs — Subflows  
  https://nodered.org/docs/user-guide/editor/workspace/subflows
- Raycast Windows Changelog — v0.50 Quick Look  
  https://www.raycast.com/changelog/windows/0-50
