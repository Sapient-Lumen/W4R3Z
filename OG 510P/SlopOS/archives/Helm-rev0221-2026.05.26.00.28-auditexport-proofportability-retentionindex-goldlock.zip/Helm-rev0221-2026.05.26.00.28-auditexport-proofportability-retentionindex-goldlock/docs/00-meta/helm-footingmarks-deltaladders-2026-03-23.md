# Helm: footing marks + delta ladders — 2026-03-23

## The call in this revision

Keep the seven pillars stable.
Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **truth axes + exact reopen routes**,
**bounded rehearsal decks**,
**pillar-specific recipes**,
**landing trains with attempt-aware lineage**,
**bounded aftermath decks + recovery maps**,
and **compact resumption briefs + typed gap verdicts** as the current grammar.

But add one narrower substrate move under the return loop:

**when Helm says “since,”
it should be able to point at one explicit footing mark,
and when it offers the next step,
it should show one typed delta ladder rather than one vague refresh/resume promise.**

## Why this now looks like the right next move

Resumption briefs improved Helm's answer to:
- what changed since the last trustworthy footing
- what exact continuation still exists
- what exact gap class broke continuity
- and what the smallest honest next rung is

But they still risk one soft spot:
**what exactly counts as the earlier footing?**

Without an explicit footing mark,
Helm can still drift into folklore:
- last visited impersonating last reviewed
- personal memory impersonating shared confirmation
- a dead provider token impersonating a valid “since” anchor
- or the shell silently changing the baseline because a fresher row is nearby

A footing mark fixes that.
A delta ladder then keeps the next-round paths visibly different.

## What a footing mark should answer

A footing mark is the shell-owned answer to:
- which earlier footing counts here?
- what class of footing is it?
- who or what established it?
- is it personal,
  shared,
  reviewed,
  receipt-backed,
  or historical-only?
- and is that footing still current enough,
  stale-check-first,
  superseded,
  or dead?

The key luxury is not more storage.
It is visible footing class.

## What a delta ladder should answer

A delta ladder is the shell-owned answer to:
- are we still finishing the current round?
- do we now have a new baseline for the next round?
- is there only a wake signal with no changed payload yet?
- can we open a changed set from the mark?
- do we have to rebuild the same scope from a fresh baseline?
- or has this fallen all the way to reacquire / history-only posture?

That means the ladder should keep rungs like these visibly different:
- finish current page or batch
- adopt new baseline mark for next round
- poll / wait for change
- open changed set since mark
- rebuild same scope from fresh footing
- full reacquire
- hold / cite / inspect only

## What current official patterns are teaching

### Google Calendar
Incremental sync begins with a full sync,
then persists a sync token.
The same query shape matters,
and expired sync tokens force a full resync.
That is a very strong argument for visible footing marks and typed reset rungs.

### Google Drive
Drive keeps `nextPageToken` and `newStartPageToken` distinct,
and change notifications only say that new changes are available.
That is almost a perfect teaching example for delta ladders:
current-round token,
future-round baseline,
and wake-without-details are different truths.

### Microsoft Graph
Graph delta keeps `@odata.nextLink` and `@odata.deltaLink` distinct,
and the docs say to save and reuse the whole returned URL.
That argues for shell-owned wrapping of opaque provider handles rather than half-decoding them into UI folklore.

### Kubernetes
Watch bookmarks plus `sendInitialEvents=true` show a very premium move:
a system can expose exact “synced through X” truth without pretending to be all-knowing live truth.
That is close to an ideal footing-mark precedent.

### Dropbox
Dropbox reset posture proves that dead continuity still leaves useful evidence.
A dead footing mark can still anchor explanation,
comparison,
and reset scope even after resume is impossible.

### Step Functions,
Temporal,
and GitHub
These systems keep story identity,
run lineage,
and later attempts distinct.
That is exactly the pressure Helm should preserve when a footing mark is tied to one story family but later delta work or later attempts move elsewhere.

## What the companion cubes are still teaching

### SlopOS
Keep exact basis and weaker-versus-stronger truth.
A footing mark must stay weaker than live truth.

### Schell
Keep stage separation.
A footing mark should visibly say whether it is review footing,
run footing,
outcome footing,
or only visit/history footing.

### ViewFS
Keep cursor,
watermark,
live subscription,
rebuilt snapshot,
gap verdict,
and receipt separate.
A delta ladder should steal that separation almost whole.

### Ward
Keep read cuts,
staleness budgets,
and revalidation fences.
A mark should be allowed to be stale-check-first instead of pretending freshness.

### Steward
Keep typed repair pressure.
A ladder should offer narrow next rungs before broad replay.

## How this fleshes the pillars

### Omnibox
A search result could say not only “changed” but “changed since your last reviewed mark” or “provider reset; new baseline required.”

### Object Browser
Saved views,
folders,
and live collections could reopen from one visible footing mark instead of one magical recency row.

### Operations Center
Apply / promote / publish / rerun stories could preserve reviewed or last-confirmed footing marks and then open the next delta or reset rung from there.

### Desktop Flow
Paused or partially completed flows could preserve a user-trusted footing mark and later reopen with a typed advancement ladder rather than broad rerun folklore.

### Recall
Recall becomes much more premium if it can distinguish:
- last visited
- last checked
- last confirmed
- last reviewed
- shared base
- receipt-backed history

### Exchange
Imports,
routes,
materializations,
and sync-backed deliveries can all show one honest mark and one honest ladder without becoming a giant sync religion.

### Terminal / Capshell
Command histories,
output groups,
log follows,
and attempt-aware runs can all benefit from explicit mark class plus exact next-round posture.

## What to keep from older inspirations

Keep:
- exact basis,
  exact bookmarks,
  and inspectable “synced through” markers
- restore/clone/reopen without rewriting lineage
- dead-token honesty instead of fake continuity
- bounded workspaces over one footing
- personal-first marks that can later be shared explicitly

Peel away:
- one ambient “since last time” memory plane
- one token that silently means both current paging and future baseline
- wake signals dressed up as changed-set truth
- auto-advanced baselines that the operator never explicitly trusted

## Pull-the-trigger judgment

This is still not a new pillar.
It is also not a full sync engine.

But it now looks wise to pull one narrower trigger:

**make the last trusted footing first-class through footing marks,
and make the next small change path first-class through delta ladders.**

That is the cleanest next way to make Helm's datacube feel brilliant without freezing too much too early.
