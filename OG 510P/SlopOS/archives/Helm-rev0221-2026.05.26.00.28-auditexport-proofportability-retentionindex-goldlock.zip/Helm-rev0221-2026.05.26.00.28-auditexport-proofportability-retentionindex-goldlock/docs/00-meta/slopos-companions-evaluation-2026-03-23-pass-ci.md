# SlopOS + companions evaluation — 2026-03-23 — pass CI

Purpose: continue evaluating the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one narrower question:
**what compact grammar should Helm freeze so tiny shell surfaces stop flattening live truth, stale truth, last outcome, and weak remembered context into one badge?**

## Headline

The companion cubes now point toward one especially useful design-phase ratchet:
Helm should likely warm a shell-owned **state tuple** law.

That law would keep at least these axes distinct for one exact subject:
- **phase** — what lifecycle posture is true right now, if any
- **conditions** — typed current caveats such as waiting / restricted / degraded / muted / stale
- **freshness** — how current the observation is, including one visible `live_until` or decay story
- **basis** — what witness or observation class produced the claim
- **last outcome** — what the most recent completed or durable result actually was

This is not a new pillar.
It is a cross-cutting shell grammar.

## 1. SlopOS keeps teaching exact boundary slices instead of one flattering state blob

The recent SlopOS bundle keeps proliferating exact boundary docs for MCP completion import, prompt import, logging import, OpenURI launch completion, result export, and many other narrow seams.
That pressure is useful.
It keeps reminding Helm that:
- request admission is not completion,
- import posture is not execution truth,
- attention/status surfaces are not durable records,
- and exact boundary meaning is cheaper to keep honest than one giant generic state field.

For Helm, the lesson is clear:
compact shell status should not say merely “good” or “done.”
It should admit what kind of truth it is carrying.

## 2. ViewFS keeps teaching recipe / snapshot / live feed separation

ViewFS stays strongest when it separates:
- query manifest,
- result snapshot,
- live feed,
- selector surface,
- and live authority.

That is basically the same law in another costume.
A saved recipe is not a current result set.
A current result set is not a live subscription.
A live subscription is not automatic authority over every match.

Helm should steal that discipline for shell status.
A current phase, a current condition set, and a last durable outcome are related.
They are not the same object.

## 3. Schell keeps teaching live / restored / historical honesty

Schell's reentry and restoration work keeps insisting that `live`, `restored`, `historical`, `receipt`, and `unknown` are not weak synonyms.
Its hold-card posture also reinforces that refusal gets much more humane when the shell can explain:
- what object you are touching,
- what truth class it currently has,
- what witness is missing,
- and what stronger path exists.

That maps directly onto Helm.
A state tuple should let tiny chrome say whether something is:
- currently running,
- merely last confirmed,
- restored but not reacquired,
- or completed historically with one known outcome.

## 4. Steward is the closest direct teacher again

Steward's freshness-decay and dynamic-condition docs are almost a direct draft for this move.
They keep pressing several aligned lessons:
- observed truth ages unless the seam says otherwise,
- dynamic conditions are observations, not boot-order mythology,
- successful activation is not proof that the world is currently usable,
- and shell chrome should decay honestly once the anchor or renewal path is gone.

That means Helm should stop asking one strip or chip to say everything.
Instead, it should keep:
- lifecycle phase,
- condition rows,
- freshness horizon,
- observation basis,
- and last durable outcome
as visibly separate small truths.

## 5. What Helm should pull forward now

### Pull forward confidently
- one **state tuple** law for compact shell status
- one rule that **phase**, **conditions**, **freshness**, **basis**, and **last outcome** stay separate axes
- one requirement that tiny surfaces such as reality strips, condition strips, beacons, and postcards may compress those axes visually but may not collapse them semantically
- one `live_until` / `fresh_until` posture for live-looking projections
- one nearby inspect / revalidate / focus / explain exit on compressed state surfaces

### Keep warm, not frozen
- a giant universal event/state ontology
- one mandatory status vocabulary for every provider and every pillar
- fake currentness produced from remembered shell context alone
- dashboard religion dressed up as state semantics
- hidden mutation or control hidden inside glanceable state chrome

## 6. The lesson we must learn from the past keeps sharpening

Older systems keep making the same mistake:
they take several adjacent truths — running, ready, waiting, failed, stale, restored, recently used, permission granted, permission hot now, and historical success — and crush them into one shiny icon.

Helm should learn the opposite lesson:
**the more glanceable a shell surface becomes, the more disciplined its grammar has to be.**

## Judgment

Because SlopOS and the companion cubes are still design-phase systems,
this looks like exactly the kind of thing Helm should freeze now:
not a giant object,
but a small constitutional grammar.

The next especially promising move is therefore:
**a shell-owned state tuple law that keeps phase, conditions, freshness, basis, and last outcome distinct enough that reality strips, condition strips, beacons, saved views, and hold cards stop lying by compression.**
