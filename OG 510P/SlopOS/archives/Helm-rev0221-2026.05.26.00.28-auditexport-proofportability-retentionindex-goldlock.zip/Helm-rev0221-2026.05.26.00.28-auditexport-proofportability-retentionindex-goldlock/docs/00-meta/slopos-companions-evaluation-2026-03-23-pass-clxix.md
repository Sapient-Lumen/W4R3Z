# SlopOS companions evaluation — 2026-03-23 — pass CLXIX

## Theme
After warming **read guarantee cards + consistency cuts**,
the next useful question is:

**once Helm can say what class of read a person is seeing,
how should it keep that person from silently falling below the strongest footing they already saw or acted from?**

The companion family points toward one narrow answer:
**session floors + causality rails**.

## SlopOS

### What to keep
Keep SlopOS's boundary discipline and refusal to let ambient `latest` stand in for exact witness-bound truth.
Keep its instinct that provider-local evidence and shell-facing posture are not the same object.

### What that means for Helm
SlopOS implies that if a user reviewed or acted on footing `F`,
a later shell view should not quietly replace `F` with some weaker path just because it was faster or more local.
Helm should preserve a visible floor,
not just a new fetch timestamp.

## Ward

### What to keep
Ward remains the strongest local teacher.
Keep:
- read cuts,
- staleness budgets,
- ambiguity windows,
- revalidation fences.

### What that means for Helm
Ward already implies that not every later read is a safe continuation of the earlier one.
The next rich seam is to add:
- **the last trusted floor**, and
- the exact rail that says whether the new view still honors it.

## Schell

### What to keep
Keep generation lamps,
since-cut supplements,
and caught-up-through humility.

### What that means for Helm
Schell reinforces that `caught up through X` is a meaningful truth.
A session floor is the shell analogue:
`do not show me less than the footing this task already depended on unless you say so.`

## ViewFS

### What to keep
Keep the separation between observed validator,
private writable session,
commit precondition,
committed version,
and receipt/history.

### What that means for Helm
ViewFS pushes Helm toward a further split:
**the version being viewed** and **the floor the viewer already holds** are not the same thing.
A person can be looking through a cheaper path while still carrying a stronger lower bound from earlier work.

## Steward and Foundry

### What to keep
Keep readiness-generation posture,
stale-status fences,
reconnect honesty,
and downgrade/replay differences.

### What that means for Helm
These systems keep warning that users suffer when the system silently swaps one continuity class for another.
That is strong support for a visible causality rail and explicit downgrade verb.

## Synthesis
The companion family now pushes Helm toward one compact support pair:
- **session floor** — the shell-owned lower bound of what this person/deck already knows or requires,
- **causality rail** — the tiny nearby truth that says whether the current view still honors that floor,
requires upgrade,
or requires explicit downgrade/reset.

That is a much better next move than:
- a larger datacube center,
- a universal session protocol,
- or another pillar.

## Keep / drop summary

### Keep as law
- once serious footing is seen,
silent backward motion is a defect
- the last trusted floor belongs to the shell,
not to one transport or provider alone
- downgrade/reset should be explicit,
not smuggled in as a cheap open/search path
- continuity with prior footing is a different question from freshness alone

### Keep as object candidates
- session floor
- causality rail
- maybe later downgrade card

### Drop for now
- provider-native session-token vocabulary in everyday Helm chrome
- one giant causal-consistency subsystem
- any move that hides lower-bound loss behind one stale or refreshed badge
