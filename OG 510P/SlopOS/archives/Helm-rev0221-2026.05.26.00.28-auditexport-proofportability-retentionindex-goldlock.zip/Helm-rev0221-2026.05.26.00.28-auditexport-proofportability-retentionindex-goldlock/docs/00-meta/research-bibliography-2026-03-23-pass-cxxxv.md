# Research bibliography — 2026-03-23 pass CXXXV

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-K8S-RESOURCEQUOTA-2026 | https://kubernetes.io/docs/concepts/policy/resource-quotas/ | explicit `hard` and `used` quota truth for aggregate namespace ceilings |
| REF-GITHUB-REST-RATELIMITS-2026 | https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api | remaining budget, reset horizon, and secondary-rate-limit retry posture |
| REF-GITHUB-REST-TROUBLESHOOT-2026 | https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api | `retry-after`, `x-ratelimit-remaining`, and `x-ratelimit-reset` handling |
| REF-GCLOUD-CLOUDQUOTAS-2026 | https://docs.cloud.google.com/docs/quotas | quota monitoring, alerts, and limit-adjustment workflow |
| REF-GCLOUD-QUOTA-METRICS-2026 | https://docs.cloud.google.com/monitoring/alerts/using-quota-metrics | charting and alerting on quota usage versus limit |
| REF-GCLOUD-QUOTAS-SYSTEM-LIMITS-2026 | https://docs.cloud.google.com/monitoring/quotas | quotas typically adjustable versus fixed system limits |
| REF-AWS-SERVICE-QUOTAS-REQUEST-2026 | https://docs.aws.amazon.com/servicequotas/latest/userguide/request-quota-increase.html | adjustable account-level and resource-level quota increase flow |
| REF-AWS-SERVICE-QUOTAS-HISTORY-2026 | https://docs.aws.amazon.com/servicequotas/latest/userguide/quota-history.html | increase-request outcomes and tracking posture |
| REF-SLACK-RATE-LIMITS-2026 | https://docs.slack.dev/apis/web-api/rate-limits/ | tiered per-minute ceilings, bursts, and special-scope limits |
