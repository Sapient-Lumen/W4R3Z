# SlopOS + companions evaluation — 2026-03-23 pass CXLVIII

## Why this pass happened

The previous Helm revision made **change classes** and **re-review gates** the next adjacent cluster.
That immediately raises the next local design question:
**what weaker truth may honestly carry forward,
and what exact packet should Helm gather for the next reviewer or operator?**

The companion cubes support this question unusually well.
The answer is not “preserve every old green light.”
The answer is:
- keep exact footing,
- keep carry-forward visibly weaker than fresh review,
- keep reviewer burden scoped,
- and keep the next handoff or recheck packet explicit and small.

## What SlopOS still teaches best

### 1) Accepted policy stays explicit local policy
The strongest SlopOS lesson for this pass is not about dashboards.
It is about policy boundaries.
Its witness/quorum and provenance/coverage boundary discipline keeps saying the same thing:
**what counts, who counts, and what exact coverage is in force should stay explicit local policy rather than being inferred from whatever bundle arrived.**
For Helm that means:
- carry-forward conditions should be shell policy,
- reviewer-set or quorum logic should be shell policy,
- and a review packet should name the evidence and the scope,
  but should not secretly define policy by itself.

### 2) Coverage maps stay discoverable
SlopOS also keeps rewarding family maps and singleton discipline.
That matters here because review packets and carry-forward rails are exactly the kinds of things that can become folklore if they are not wired into stable discovery surfaces.

## What ViewFS now teaches best

ViewFS keeps giving Helm the right grammar:
**basis, drift, reconsent, and renewed authority are different truths.**
That remains the best local support for a carry-forward rail.
A rail should be allowed to say:
- stable anchors unchanged,
- old notes still inspectable,
- prior compare still partly informative,
without pretending that fresh authority or action-fit still binds.

## What Ward now teaches best

Ward is still the sharpest local teacher for the phrase **witness carry-forward**.
It keeps saying that historical residue can remain valuable without counting as present approval.
That is almost the whole law of a Helm carry-forward rail.
Ward also keeps pressure on watch duty and later incident signals,
which means packets should be able to say whether later watch posture or distrust bands altered the value of the older review.

## What Harbor now teaches best

Harbor sharpens the question of **what action is fit now**.
That matters here because carry-forward is not just informational.
Some carried truth may still support inspect or brief.
Some may still support limited publish preparation.
Other moves should remain fenced until fresh review lands.
That makes action-fit a natural consumer of carry-forward rails.

## What Foundry now teaches best

Foundry's config layers and overlay gates keep reinforcing that **where the change landed** matters.
Not every changed layer should summon the same reviewer set.
That is excellent pressure for review packets:
a packet should increasingly be able to say which layer or overlay changed,
which review scope that touches,
and which previously valid approval group is now partly outdated.

## What Schell now teaches best

Schell is the clearest local teacher for `edit and review again`.
Its terminal/trust posture keeps insisting that a later stronger action often needs secure review handoffs rather than reuse of prior receipt authority.
That makes it a direct teacher for review packets as explicit handoff objects,
not hidden context.

## Lessons Helm must learn from the past

### Must learn #1: old review should not collapse to either “fully valid” or “gone”
A useful system preserves some inspectable residue,
but only under named carry conditions.

### Must learn #2: carry-forward is for weak truth, not for renewed authority
Owner context,
stable audience,
unchanged anchors,
old notes,
and maybe some scoped checks may carry.
Fresh approval and sharp action authority should not.

### Must learn #3: reviewer burden should follow affected scope
The next reviewer set should be tied to changed layer,
affected uses,
or changed ownership scope,
not just sprayed at everyone who once cared.

### Must learn #4: policy should stay shell-local
A packet may describe coverage,
affected scope,
blindspots,
reviewer hints,
and carry rails.
It should not secretly become the constitution.

## Current Helm judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Do not move that.

But the next adjacent cluster now looks sharper and more product-ready than in the prior revision:
- **carry-forward rails**
- **review packets**
- and maybe later **attention-turn chips**

That cluster feels well-supported by SlopOS,
ViewFS,
Ward,
Harbor,
Foundry,
and Schell together.
It could make Helm super awesome because the shell could say:
**these truths still carry weakly from the old footing,
these truths do not,
these are the blindspots,
and this is the exact packet and reviewer turn that now fits.**
