# Helm synthesis — landmark protocols + session lights — 2026-03-23

## Headline

After action mode, the next narrow move worth admitting is:
**a first-class landmark protocol.**

And the right nearby weak companion is:
**session-attention lights.**

## Why this is the right next move

Helm already knows how to talk about:
- exact handles,
- front doors,
- action keys,
- current-live beacons,
- Recall timelines,
- and helper/adoption truth.

What it was still missing was one clean answer to:

**what should the operator be able to intentionally keep one jump away?**

The current outside tools, plus SlopOS/ViewFS/Schell/Steward, all point at the same answer:
not giant recents,
not giant memory,
not giant home.

Instead:
- exact promoted landmarks,
- one weak landing surface that assembles them,
- and tiny session lights that say whether background work deserves attention.

## What a landmark is

A landmark is a **shell-owned promoted return point**.
It should be stronger than casual history but weaker than current-live proof.

Good landmark families probably include:
- **object landmarks** — exact object or view return points
- **front-door landmarks** — saved layout/activity starters
- **action landmarks** — promoted typed action templates
- **compare landmarks** — named compare-from-here or timeline entry points

The point is not to flatten those into one token.
The point is to let the shell say:

**this is worth keeping close, and here is exactly what kind of kept thing it is.**

## Landmark laws

### 1. Promotion is explicit
Recent history is not enough.
A landmark should be intentionally promoted.

### 2. Landmark identity is exact
A landmark should preserve one exact object, view, route, front door, or typed template — or say exactly which slot is still empty.

### 3. Landmark weather is separate from landmark identity
A landmark can say:
- live now,
- historical only,
- drifted,
- attention-needed,
- adoption-needed,
- or unknown.

But those are weather classes.
They are not the underlying identity.

### 4. Landmark groups stay advisory
Grouping or shelving landmarks is useful.
It should not become hidden authority or hidden currentness.

### 5. Landmark opening does not prove completion
Returning through a landmark is still not proof that the live lane changed, that a target completed, or that helper work was adopted.

## What session lights are

Session lights are **small shell-owned attention cues** about helper or delegated work.

They should answer questions like:
- is something still running,
- does something need review,
- is something adoption-ready,
- did something drift,
- or is something historical only?

They should not become a second control plane.
They should sit near:
- Overview,
- Operations Center,
- Recall,
- and maybe the landmark shelf.

## Super-awesome angle

This is one of the best remaining chances for Helm to feel unusually good without overfreezing architecture.

A great return loop would become:
- summon,
- hit one landmark,
- see one or two tiny session lights,
- compare if needed,
- act through typed action mode,
- and adopt only when the stronger rung is really deserved.

That is a much better product story than:
- another pillar,
- another dashboard,
- or another giant memory object.

## Pull-the-trigger judgment

Pull one narrow trigger now:
- admit a **landmark candidate contract**.

Keep one nearby pressure warm but not overfrozen:
- **session-attention lights**.

That is enough to make Helm's next revision of the return loop feel much more inevitable.
