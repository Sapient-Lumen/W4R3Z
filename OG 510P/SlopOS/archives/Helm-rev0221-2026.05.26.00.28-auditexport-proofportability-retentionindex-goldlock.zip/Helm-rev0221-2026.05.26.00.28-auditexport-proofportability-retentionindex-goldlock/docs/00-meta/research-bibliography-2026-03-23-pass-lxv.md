# Research bibliography — 2026-03-23 — pass LXV

## Sources consulted for this pass

1. GitHub Docs — About commits
   - commit SHA as the unique identifier for specific changes,
     time,
     and author
2. GitHub Docs — Comparing commits
   - compare across branches,
     tags,
     commits,
     forks,
     and dates
3. GitHub Docs — REST API endpoints for pull requests
   - `expected_head_sha` on pull-request branch update
4. GitHub Docs — Workflow syntax for GitHub Actions
   - pinning to commit SHA is safest for stability and security
5. Grafana Docs — Manage dashboard version history
   - compare versions,
     inspect JSON diff,
     restore previous versions non-destructively
6. Notion Docs — Create a view query
   - `query_id`,
     `expires_at`,
     15-minute cached-query expiry
7. Notion Docs — Working with views
   - query expiry and stable pagination language
8. Figma Help — View a file's version history
   - checkpoints,
     named versions,
     descriptions,
     contributor/time witness,
     share specific version,
     duplicate for handoff,
     restore non-destructively
9. Figma Help — Review and accept library updates
   - explicit accept/update flow for published changes
10. Google Docs Editors Help — Find what's changed in a file
    - named versions,
      restore/copy previous versions,
      human-visible version milestones
11. MDN — HTTP conditional requests
    - optimistic locking,
      fail on mismatch,
      then restart or show a diff
12. MDN — HTTP headers / conditional headers
    - ETag / If-Match posture as version witness inputs
