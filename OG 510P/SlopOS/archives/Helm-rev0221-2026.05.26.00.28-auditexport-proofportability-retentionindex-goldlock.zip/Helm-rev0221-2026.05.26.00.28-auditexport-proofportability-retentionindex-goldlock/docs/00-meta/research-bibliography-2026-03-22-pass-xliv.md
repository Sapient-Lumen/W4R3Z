# Research bibliography — 2026-03-22 — pass XLIV

Purpose: record the sources used for the current-live-beacon and scope-witness pass.

## Primary sources

1. **Projects in ChatGPT**
   - scope boundary
   - project-only memory
   - shared projects tightening memory posture
   - why useful: validates explicit scoped work objects and context fences

2. **ChatGPT release notes / Business & Enterprise release notes**
   - shared projects
   - shared project context
   - why useful: validates that sharing often changes the memory/context contract rather than merely copying a bundle

3. **VS Code Workspace Trust**
   - restricted mode
   - explicit trust posture
   - why useful: validates visible trust and scope posture instead of ambient execution rights

4. **VS Code Profiles / Workspaces / checkpoints / sessions**
   - saveable profiles
   - import/export/share
   - checkpoints and fork-from-checkpoint
   - why useful: validates saved structure, branching, and explicit stronger actions

5. **Linear custom views / favorites / projects**
   - saved and favorite-able custom views
   - attached project views as tabs
   - project overview versus issue views
   - why useful: validates saved view objects near scoped project work without collapsing them into the live task lane

6. **Google Docs tabs**
   - active-tab links
   - duplicate tab
   - current-tab versus all-tabs export/print
   - why useful: validates grouped resources plus explicit current-subthing choice

7. **Dropbox Dash release notes**
   - Stacks
   - visual customizable grouped work
   - inline previews / comments / simplified sharing
   - why useful: validates grouped resource curation while also warning against overclaiming liveness

8. **Slack tabs / folders / pins / Later**
   - shared tabs and folders in a conversation
   - personal saved-for-later lane
   - why useful: validates the difference between shared group curation and personal later/reentry surfaces

9. **Arc Spaces / Profiles / Peek / Folders**
   - distinct spaces
   - profile-scoped cookies/history/settings
   - grouped tabs and preview
   - why useful: validates explicit context separation and lightweight preview near stronger truth

10. **Chrome manage tabs / saved tab groups**
    - saved tab groups in bookmarks bar
    - current grouped tab management
    - why useful: validates saved grouped work as useful but still not equivalent to current live state

11. **Apple Quick Look / Finder Preview / Quick Actions**
    - lightweight preview
    - nearby bounded actions
    - why useful: validates inspect-near-action without flattening into stronger acts

12. **PowerToys Command Palette**
    - one summon surface for commands, apps, and actions
    - why useful: validates typed fast entry surfaces

## SlopOS sources re-read this pass

1. `docs/30-architecture/openuri-recent-items-boundary-v0.md`
2. `docs/30-architecture/openuri-materialization-boundary-v0.md`
3. `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
4. `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`
5. `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`
6. `docs/30-architecture/open-untrusted-export-classification-v0.md`
7. `docs/30-architecture/lease-descriptor-state-boundary-v0.md`

## Why these sources mattered

This pass was not about finding another pillar.
It was about checking whether today's strongest tools are rewarding:
- explicit scope,
- explicit currentness,
- explicit grouped-work boundaries,
- and honest strength differences between preview,
  saved structure,
  and live truth.

They are.
