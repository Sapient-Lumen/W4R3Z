# Research bibliography — 2026-03-22 — pass L

Official/public sources reviewed for this pass:

1. GitHub Docs — Re-running workflows and jobs
   - https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs
2. GitHub Docs — Reverting a pull request
   - https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/reverting-a-pull-request
3. GitHub Docs — Reverting a commit in GitHub Desktop
   - https://docs.github.com/en/desktop/managing-commits/reverting-a-commit-in-github-desktop
4. Visual Studio Code Docs — Revert changes with checkpoints and editing requests
   - https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
5. Visual Studio Code Docs — Review AI-generated code edits
   - https://code.visualstudio.com/docs/copilot/chat/review-code-edits
6. Google Docs Editors Help — Collaborate with Gemini in Google Sheets
   - https://support.google.com/docs/answer/14218565?hl=en
7. Figma Learn — View a file's version history
   - https://help.figma.com/hc/en-us/articles/360038006754-View-a-file-s-version-history
8. Figma Learn — Guide to branching
   - https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
9. Figma Learn — Incomplete merges or updates
   - https://help.figma.com/hc/en-us/articles/5691750511383-Incomplete-merges-or-updates

Companion internal sources re-read in this pass:

- SlopOS `docs/30-architecture/recovery-posture-v0.md`
- SlopOS `docs/30-architecture/microvm-restore-repair-barrier-posture-v0.md`
- SlopOS `docs/30-architecture/acp-acceptance-completion-posture-v0.md`
- Helm `docs/30-architecture/effect-receipt-candidate-contract-v0.md`
- Helm `docs/30-architecture/slot-verdict-ledger-candidate-contract-v0.md`
- Helm `docs/30-architecture/action-warrant-candidate-contract-v0.md`
- Helm `docs/30-architecture/drift-gate-candidate-contract-v0.md`
