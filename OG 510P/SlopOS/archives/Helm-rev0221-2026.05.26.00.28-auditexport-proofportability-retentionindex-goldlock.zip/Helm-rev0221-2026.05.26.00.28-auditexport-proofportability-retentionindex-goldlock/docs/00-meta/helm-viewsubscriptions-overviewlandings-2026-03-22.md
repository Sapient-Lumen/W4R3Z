# Helm view subscriptions + overview landings — 2026-03-22

Purpose: name the next compact support moves that now look worth proving after the latest SlopOS reread and web pass.

## Main idea

Helm now has a better answer to a question that has been hanging in the air for a while:

**how does the datacube become more alive without becoming a giant cube or a giant dashboard?**

The best answer right now is:
- keep **saved views** as first-class objects,
- let them appear as **linked views** in more places,
- let some of them carry bounded **view subscriptions**,
- and let **Overview** become a weak landing surface composed from those exact things.

## 1. View subscriptions

A **view subscription** is a shell-owned attention relation attached to one exact saved view object.

It is not a generic daemon.
It is not a hidden workflow engine.
It is not a giant activity timeline.

It means something closer to:
- tell me when an item enters this view,
- tell me when an item exits this view,
- tell me when one small declared threshold or state change happens,
- keep the subscription inspectable and revocable,
- and let the shell say where the attention went.

### Why this is worth stealing

Linear Custom Views made the latent value obvious:
a saved view becomes much more useful when it can also drive attention.

SlopOS then sharpens the law:
- the query/view must stay bounded,
- live mode must stay optional,
- subscriptions must stay revocable,
- and persistence must not silently widen into app-owned background watch folklore.

### The Helm law

A subscription should bind:
- one exact saved view object or explicit query digest,
- one declared attention class,
- one locality/trust posture,
- one delivery family,
- and one revocation path.

It should not silently gain:
- broad background work rights,
- remote mutation authority,
- or universal notification inventory semantics.

## 2. Overview landings

Overview already existed as a candidate shell surface.
This pass sharpens what it should be.

Overview should not be a giant control dashboard.
It should be a **weak landing surface** built from a few exact ingredients:
- linked views,
- front-door handles,
- one or two current-live beacons,
- one bounded ops slice,
- and maybe one compare path nearby.

### Why this is worth stealing

Airtable's Overview layout,
PowerToys workspace starters,
Arc's distinct spaces,
and the continuing pressure from activity-shaped shells all point to the same humane product truth:
people want one glanceable place to get back in,
not one giant place that pretends to be the world.

### The Helm law

Overview should:
- summarize,
- orient,
- and offer exact next entry paths.

Overview should not:
- own the authoritative state model,
- silently choose identity/profile/provider scope,
- or replace Omnibox/Object Browser/Operations Center with one flattering home surface.

## 3. Shared handles stay warm

This pass also makes one warm move look better:
**shared handles**.

Raycast Shared Quicklinks and Airtable's explicit share/sync/publish posture both suggest that tiny entry objects can travel well.
Helm should keep that idea,
but only with clear source,
audience,
trust tier,
and promotion receipts.

## 4. External trigger posture

Raycast Deeplinks added a useful nuance.
A tiny handle can be externally invokable,
but stronger actions can still begin in confirm posture.

Helm should steal that.
A shared/imported/external handle may be a great front door,
but it should not silently count as an already-approved strong action.

## 5. What feels wise to pull the trigger on now

### Pull the trigger now
- **view subscriptions**
- **Overview as a weak landing surface built from linked views and handles**

### Keep warm
- **shared handles with publication/posture receipts**
- **externally triggered handle confirmation ladders**

## 6. Lessons we must keep learning from the past

1. **Alive does not mean ambient.**
2. **A landing surface is healthiest when it is made of exact smaller objects.**
3. **Notifications are not durable work truth.**
4. **A subscription is stronger than a bookmark but weaker than a workflow constitution.**
5. **The shell gets better when attention belongs to saved views and receipts, not to hidden daemons.**

## Judgment

Helm still does not need another pillar.
It needs a better support stack.

The best next additions now look like:
- saved views that can carry bounded subscriptions,
- and an Overview surface that is clearly a landing surface assembled from those exact shell objects.

That makes Helm more alive,
more useful,
and more honest — which is exactly the right direction for the datacube.
