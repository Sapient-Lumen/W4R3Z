# Research bibliography — 2026-03-24 — pass CLXX

| Ref | Source | Used for |
| --- | --- | --- |
| REF-COSMOS-SESSION-TOKENS-2026I | https://learn.microsoft.com/en-us/azure/cosmos-db/consistency-levels | session tokens can be passed between client instances and act as a minimum version barrier |
| REF-COSMOS-RELIABILITY-2026I | https://learn.microsoft.com/en-us/azure/reliability/reliability-cosmos-db-nosql | best practice to use passed session tokens only for read operations |
| REF-MONGODB-CAUSAL-XSESSION-2026I | https://www.mongodb.com/docs/manual/core/read-isolation-consistency-recency/ | causal guarantees plus advancing operation / cluster time across sessions |
| REF-COUCHBASE-MUTATIONSTATE-2026I | https://docs.couchbase.com/sdk-api/couchbase-node-client/classes/MutationState.html | mutation packets as targeted carried lower-bound evidence |
| REF-COUCHBASE-CONSISTENTWITH-2026I | https://docs.couchbase.com/sdk-api/couchbase-java-client/com/couchbase/client/java/query/QueryOptions.html | `consistentWith(MutationState)` for query-side targeted consistency |
| REF-SPANNER-TIMESTAMP-BOUNDS-2026I | https://docs.cloud.google.com/spanner/docs/timestamp-bounds | strong vs bounded vs exact timestamp bounds |
| REF-SPANNER-SESSION-CMDS-2026I | https://docs.cloud.google.com/spanner/docs/jdbc-session-mgmt-commands | `READ_TIMESTAMP` and `MIN_READ_TIMESTAMP` as typed carried time claims |
| REF-COCKROACH-AOST-2026I | https://www.cockroachlabs.com/docs/stable/as-of-system-time | `with_max_staleness` / `with_min_timestamp` as explicit lower-bound read posture |
| REF-COCKROACH-FUNCTIONS-2026I | https://www.cockroachlabs.com/docs/stable/functions-and-operators | nearest-only error posture and lower-bound read selection details |
