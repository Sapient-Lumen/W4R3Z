# SlopOS + companions evaluation — 2026-03-22 — pass LXXXV

Purpose: re-read the uploaded SlopOS,
Schell,
ViewFS,
and Steward bundles with one tighter question:
**what should Helm learn now about blocked-state honesty,
policy explanation,
and least-widening alternatives?**

## 1. SlopOS keeps teaching that request identity,
explanation,
and live authority must stay separate

SlopOS is still the hardest teacher here.
Its request-state family keeps saying that a request id is not live provider state.
Its explain posture keeps saying that canonical summaries and receipts are evidence,
not authority.
Its deny-precedence posture keeps saying that blocker classes should stay deterministic.

That transfers directly into Helm.
An access verdict card should be allowed to say:
- denied by policy,
- denied by stale basis,
- denied by lane restriction,
- denied by missing live lease,
- or explanation incomplete because visibility is limited,

without laundering those into one generic “failed.”

## 2. SlopOS also keeps teaching that budget failure should stay explicit rather than silently broadened away

The capshell budget requirement and explicit `budget-missing` deny code are extremely good design pressure.
They show a healthy product instinct:
when the act is too strong for the current posture,
name the exact missing class rather than silently falling back to a bigger grant.

Helm should steal that almost verbatim.
A blocked stronger act should prefer:
- show the missing narrow prerequisite,
- show the least-widening alternative,
- and keep the broad persistent grant as a later rung,
not the cheerful default.

## 3. ViewFS is the clearest companion teacher for why-records,
deny ceilings,
and advice that does not become authority

ViewFS keeps separating witness packs,
caveat sets,
freshness evidence,
why-records,
validation,
policy,
advice,
diagnostics,
logs,
deny ceilings,
scope eligibility,
and escalation attempts.
That is a gift for Helm.

It means a shell can say:
- this is the authoritative blocker,
- this is shell advice,
- this is the likely narrower alternative,
- and this is durable history,

without flattening them.
That is exactly the distinction Helm needs for access verdict cards and least-widening previews.

## 4. Steward keeps the chrome lesson: blocked features should still explain themselves

Steward's README keeps pushing explicit surface diagnostics so shell and terminal affordances can explain why they are enabled,
degraded,
denied,
or stale.
That is the right chrome law for Helm too.

A blocked act should not make the shell feel dumb.
It should make the shell feel precise.
The operator should be able to see:
- what exact gate blocked the act,
- what inspect path remains,
- whether a narrower route exists,
- and whether broader trust or grant is actually justified.

## 5. Schell keeps pointing toward ground cards instead of a giant permission theology

Schell's capability-ground cards and config-ground cards ask a humane question:
**why did this feature work here,
and why not there?**
That is powerful because it keeps the answer small,
reviewable,
and context-shaped.

Helm should copy that product instinct.
Do not answer blocked-state frustration with a giant policy center.
Answer it with one compact verdict card and one compact least-widening preview.

## 6. Design-phase lesson now looks sharper

Because SlopOS and Schell are still design-phase systems,
Helm should freeze **small laws of refusal and explanation** before it freezes giant policy families.
This pass suggests four such laws:

1. blocked-state classes must stay visibly different
2. explanation is evidence,
   not authority
3. least-widening alternatives should appear before broad grant pressure
4. previewed or simulated admission is weaker than live authority

## 7. Best next proof slices after this pass

- one blocked stronger act with an **access verdict card** that names the exact blocker class
- one least-widening preview comparing current-only,
  exact-subject,
  isolated-lane,
  and broader persistent alternatives
- one case where explanation is incomplete because Helm lacks rights to inspect the determining blocker fully
- one restricted-first lane where inspect remains available even though stronger execution is blocked
- one policy/lease/basis conflict where the card keeps blocker precedence visible instead of collapsing everything into one red badge

## Judgment

The companion cubes are again most valuable when they teach **discipline under refusal**.
This pass says Helm should get better at one ordinary but important shell experience:
when something stronger cannot happen yet,
show exactly why,
show what remains safely inspectable,
and show the smallest honest next delta.

The right answer is not a bigger constitution.
It is two smaller shell-owned witnesses:
**access verdict cards and least-widening previews.**
