# Research bibliography — 2026-03-21 — pass XI

## Isolation and adoption pressure

- VS Code agents tutorial — background agents can use Git worktrees to isolate file changes from the main workspace and prevent conflicts.
- VS Code security docs — background agents run in a separate Git worktree with limited tool access.
- VS Code November 2025 update notes — background-agent worktrees can be reviewed and merged or directly applied back into the main workspace.
- Git worktree docs — multiple working trees are distinct checked-out working states attached to one repository.
- VS Code Copilot coding-agent docs — delegated work can create a branch / pull request for later review.

## Conflict and ownership pressure

- Kubernetes Server-Side Apply docs — managed fields, conflicts, and explicit force-conflicts ownership transfer.
- Kubernetes API concepts — resource-version and server-side-apply conflict handling.
- MDN `If-Match` docs — conditional update / compare-and-set semantics for mutation.

## Current use in Helm

This pass mainly pressures:
- delegated-adoption truth as a new narrow freeze,
- shadow work lanes as a new candidate move,
- and continued coupling between basis packets,
  continuity witnesses,
  and any future adoption surface.
