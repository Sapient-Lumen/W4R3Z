# Helm change cursors + finalizer rails + retry keys — 2026-03-22

Purpose: name the next compact support moves that look worth proving after the latest SlopOS reread and outside pass without adding another pillar.

## Main idea

Helm already has:
- basis stamps,
- watchpoints,
- action warrants,
- drift gates,
- effect receipts,
- reversal warrants,
- and repair ladders.

What still feels missing is a calmer way to handle three ordinary kinds of uncertainty:
- **has the mutable thing moved since I last saw it?**
- **is this retry the same act or a second act?**
- **is teardown requested or actually finished?**

The next compact answer looks like:
- **change cursors**,
- **retry keys**,
- and **teardown rails**.

## 1. Change cursors

A **change cursor** is a shell-owned witness over one exact mutable source,
view,
stream,
or handle.

It should be able to say:
- this surface last saw version X,
- resume from here,
- changed since this cursor,
- caught up through at least this cursor,
- or this cursor can no longer resume honestly.

This is smaller than a watchpoint.
A watchpoint carries evaluated state.
A change cursor carries last-seen / resume / changed-since truth.

### Why it is worth stealing

People constantly need to know whether something changed since a review,
preview,
reopen,
or saved entry.
That should not require a giant sync engine.
It should require one exact witness.

### What it should not do

- not impersonate current-live truth forever
- not become a giant background subscription engine
- not replace basis stamps
- not silently repair an expired cursor into latestness

## 2. Retry keys

A **retry key** is a shell-owned same-act witness for stronger mutable or provider-facing work.

It should let Helm say:
- this retry is the same intended act,
- it is still in flight / already landed / conflicted,
- here is the linked warrant or receipt,
- and pressing again will not quietly duplicate side effects.

### Why it is worth stealing

Strong acts increasingly cross unreliable boundaries:
helpers,
providers,
networks,
imports,
remote APIs.
When the transport gets ambiguous,
users should not have to guess whether Apply again means “resume” or “do it twice.”

### What it should not do

- not replace warrants
- not replace receipts
- not become a hidden workflow runner
- not hide parameter mismatch under one cheerful reused key

## 3. Teardown rails

A **teardown rail** is a shell-owned pending-removal object.

It should let Helm say:
- removal/revoke/retire/detach requested,
- blocker set is these exact things,
- cleanup or drain is still in progress,
- force path exists or does not,
- and final disappearance has not happened yet.

### Why it is worth stealing

The shell will increasingly own:
- grants,
- reveal links,
- publications,
- linked views,
- front doors,
- helper lanes,
- saved flows,
- and checkpoint-like surfaces.

Many of those will need exact teardown honesty.
“Delete” should not always mean “gone right now.”
Sometimes it should mean “pending,
visible,
and blocked by these exact relationships.”

### What it should not do

- not become a trash can or archive substitute
- not hide cleanup blockers
- not silently force-remove because the shell wants to look smooth
- not pretend historical receipts are live teardown state

## 4. Why these three belong together

They all protect a different edge of stronger shell truth:

- **change cursor** protects against stale mutation and fake latestness
- **retry key** protects against duplicate stronger effects under retry ambiguity
- **teardown rail** protects against cliff-edge disappearance and hidden cleanup lag

Together they make Helm much calmer where real systems usually get mushy.

## 5. Best first proofs

### Pull the trigger soon
- warm **change cursors** as a candidate shell object
- warm **retry keys** as a candidate shell object
- warm **teardown rails** as a candidate shell object

### Great first demos
- a watched saved view that can say changed-since-last-review with one cursor chip
- one provider-facing stronger act that safely retries under the same key and resolves to one exact receipt path
- one revoke/unpublish/remove flow that enters pending teardown and shows exact blockers before final completion

## 6. Pillar pressure

- **Object Browser** benefits from changed-since / resume-from honesty on mutable saved views and linked views
- **Operations Center** benefits from same-act retry rows and pending teardown rows
- **Recall** benefits from “this reopening is older than current source” honesty without fake live proof
- **Desktop Flow** benefits from safe retry identity on provider-backed or helper-backed stronger acts
- **Exchange** benefits from teardown truth on unpublish / revoke / detach flows and from change cursors on traveling mutable references

## Judgment

Helm still does not need another pillar.
It needs calmer support truth at three messy edges of real work:
- stale mutable sources,
- retry ambiguity,
- and cleanup-before-disappearance.

That makes **change cursors,
retry keys,
and teardown rails** some of the best remaining “super awesome” steals.
