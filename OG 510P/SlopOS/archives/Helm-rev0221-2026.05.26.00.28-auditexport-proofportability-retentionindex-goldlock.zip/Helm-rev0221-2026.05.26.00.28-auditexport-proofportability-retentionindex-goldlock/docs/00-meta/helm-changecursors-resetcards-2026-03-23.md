# Helm change cursors + reset cards — 2026-03-23

Purpose: tighten one older Helm specimen that now looks newly important after the aftermath / continuation work.

## The new pressure

Helm already has much better answers for:
- what historically happened
- what exact continuation family still exists now
- what exact remainder is still left
- and whether an old reviewed basis still binds a stronger next move

But there is still one shell question that stays slightly mushy:

**what exact stream position did I last see,
can I still resume from it,
and when do I have to admit reset instead of pretending continuity?**

That matters because these are not the same truth:
- the last change token I saved
- the current-live state of the source
- a watchpoint's evaluated state
- the reviewed basis for a stronger action
- a still-live continuation handle
- and a server-forced reset from the beginning

If Helm collapses them,
it will start lying in the most common way modern sync and watch systems lie:
- quietly replacing an expired cursor with latest
- acting like a dead bookmark still proves continuity
- or hiding “wipe and resync” under a cheerful refresh button

## Why the outside world now reinforces this

The best current systems all keep a sharp bookmark/reset seam:
- Microsoft Graph delta query keeps `@odata.nextLink` and `@odata.deltaLink` distinct, but can also return `410 Gone` with a reset request and finite token validity
- Google Calendar incremental sync keeps `pageToken` and `nextSyncToken` distinct, requires the exact same query while paginating, and says `410` means wipe local state and perform a full sync
- Google Drive change tracking shows that some stream positions are durable enough that the start page token does not expire
- Dropbox folder and team-log cursors prove that “last seen” and “longpoll from here” are useful first-class truths, while expired cursors still require an explicit new baseline
- Kubernetes resource versions and watch bookmarks prove that exact stream position, exact start semantics, stale-start risk, and `410 Gone` reset are different facts
- Apple CloudKit and File Provider keep change tokens / sync anchors first-class and explicitly admit when they are too old and sync must restart from the beginning

The shared lesson is simple:
**resume position is its own shell truth,
and forced reset is its own shell truth too.**

## The move

### Refresh change cursors

Change cursors should now be read more strongly as one compact shell-owned answer to:
- what exact source / stream this bookmark belongs to
- what family it speaks (`delta token`, `sync token`, `sync anchor`, `resource version`, `cursor`, `generation`, `etag`, or another admitted family)
- whether it is meant for compare, resume, catch-up, or watch recovery
- and whether it is still usable,
  stale-but-inspectable,
  or no longer resumable

### Add reset cards beside them

A reset card should be the honest sibling object for when continuity fails.
It should say:
- which exact cursor or bookmark died
- why it died if known
- what reset scope is honestly required now
- what truth still survives from the old bookmark
- and what next step Helm can still offer nearby

A useful first reset vocabulary now looks like:
- cursor expired
- source history pruned
- source recreated / replaced
- comparison rights changed
- local cache lost
- provider requires full resync
- unknown reset reason

And a useful restart-scope vocabulary looks like:
- replay exact same query from fresh start token
- full rescan of exact bound scope
- wipe local mirror and rehydrate
- choose fresh source / drive / folder
- history-only; no automatic resume

## Strongest ideas worth stealing

### 1. Resume and reset should both be explicit

A bookmark that is good enough to resume should say so.
A bookmark that died should also say so.
Do not make the operator infer this from an error toast.

### 2. Reset scope matters as much as reset itself

“Start over” is too vague.
The shell should say whether the restart is:
- the same exact query with a fresh token,
- a rescan of one bound scope,
- a full wipe of one local mirror,
- or a fresh source choice because the old stream identity is gone.

### 3. Old bookmark truth can remain useful after death

A dead cursor can still preserve:
- what source it belonged to
- what family it spoke
- what last-good position was seen
- and what last known basis or view it supported

Helm should keep that evidence without pretending it is resumable.

### 4. Reset is smaller than generic repair

A reset card is not a giant repair ladder or workflow engine.
It is a narrow continuity-honesty object that keeps dead-bookmark truth inspectable and nearby-actionable.

### 5. Watchpoints and current-live surfaces must stay separate

A watchpoint may still say the last evaluated state looked healthy.
A cursor/reset card should still be able to say the resume position is stale,
ambiguous,
or dead.
Those truths should remain adjacent,
not fused.

## What to keep from older inspirations

Keep:
- last-seen chips and changed-since posture
- watch/rebuild honesty
- explicit stream-family badges
- exact restart scope
- typed reset rather than generic stale

Peel away:
- hidden auto-heal to latest
- silent bookmark replacement
- giant sync-engine abstractions before one compact shell object exists
- any UI that turns “cursor died” into “all good, refreshed”

## Why this could make Helm super awesome

### 1. Helm could be unusually honest about continuity

The shell could say:
- last seen at resource version 912337
- watch bookmark caught up through 912337
- resume no longer possible: server pruned older history
- exact next rung: full rescan of `/work/design` scope

That is premium compared with most current systems.

### 2. Saved views and watch surfaces get calmer

A saved view could keep:
- last seen cursor
- caught-up-through bookmark
- reset required
- exact restart scope
- and compare against last good snapshot

without pretending the view is still live.

### 3. Exchange and Recall both gain better return honesty

Exchange can say whether a routed follow-up or sync-backed intake can still resume from exact prior position.
Recall can say whether an old bookmark is still resumable or has fallen back to historical-only.

### 4. Helm avoids growing a giant sync religion

One compact cursor family plus one honest reset card is enough to make a lot of shell surfaces dramatically better without turning Helm into a synchronization platform.

## Pull-the-trigger judgment

The pillars still look stable.
This is not a new pillar.
But it now looks wise to pull an older specimen warmer:

**refresh change cursors** and add **reset cards** beside them,
so Helm can preserve exact last-seen / resume-from truth,
admit exact reset-scope truth,
and refuse to launder dead bookmarks into fake continuity.
