# Research bibliography — 2026-03-23 pass CLII

| Ref | URL | Why it matters for Helm |
|---|---|---|
| REF-GIT-CONFIG-SHOW-ORIGIN-SCOPE-2026K | https://git-scm.com/docs/git-config | Git contributes compact origin-and-scope inspection with `--show-origin` and `--show-scope`. |
| REF-VSCODE-WORKSPACE-TRUST-2026K | https://code.visualstudio.com/docs/editing/workspaces/workspace-trust | VS Code contributes Restricted Mode, visible-withheld workspace posture, and status-bar truth about untrusted workspaces. |
| REF-VSCODE-WORKSPACE-TRUST-EXT-2026K | https://code.visualstudio.com/api/extension-guides/workspace-trust | VS Code contributes `restrictedConfigurations` and typed trust-sensitive extension posture. |
| REF-VSCODE-POLICIES-2026K | https://code.visualstudio.com/docs/enterprise/policies | VS Code contributes organization-managed settings with visible lock/managed posture. |
| REF-VSCODE-MCP-MANAGE-2026K | https://code.visualstudio.com/docs/copilot/customization/mcp-servers | VS Code contributes workspace-vs-user-profile MCP sources, discovery from other apps, and trust review pressure for local servers. |
| REF-GRAFANA-SILENCES-2026K | https://grafana.com/docs/grafana/latest/alerting/configure-notifications/create-silence/ | Grafana contributes silence attachment to a specific Alertmanager plus evaluation-vs-notification separation. |
| REF-DATADOG-DOWNTIMES-2026K | https://docs.datadoghq.com/monitors/downtimes/ | Datadog contributes exact scoped targeting and affected-set preview for downtimes. |
| REF-GITHUB-RULESETS-2026K | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets | GitHub contributes explicit bypass permissions on rulesets. |
| REF-GITHUB-ENVIRONMENTS-2026K | https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments | GitHub contributes separate deployment protection rules, required reviewers, delays, and custom third-party gates. |
| REF-ALERTMANAGER-INHIBITION-2026K | https://prometheus.io/docs/alerting/latest/alertmanager/ | Alertmanager reinforces that inhibition is a distinct suppressing relation rather than a generic waiver. |
| REF-PAGERDUTY-INCIDENTS-2026K | https://support.pagerduty.com/main/docs/incidents | PagerDuty reinforces that acknowledgement, timeout, and resumed escalation are different truths. |
| REF-JSM-SLA-CONDITIONS-2026K | https://support.atlassian.com/jira-service-management-cloud/docs/set-up-sla-conditions/ | Jira Service Management reinforces typed start / pause / finish conditions rather than one generic timer or state badge. |
