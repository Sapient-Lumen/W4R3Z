# Helm: rule stacks, trust shutters, and precedence traces — 2026-03-23

After **exception witnesses** and **waiver leases**,
Helm now has a tighter adjacent question:

**once the shell knows that a stronger rule is being interrupted,**
**how should it say where that rule or exception came from, what scope it binds to, and what nearby candidates lost?**

The most promising next cluster is:
- **rule stacks**
- **trust shutters**
- **precedence traces**
- and maybe later **override ledgers**

## Why this matters

Without this seam,
Helm will drift toward one of two bad stories:

1. every fence,
   waiver,
   or health mark becomes source-free folklore, or
2. the shell can tell you the active posture,
   but cannot answer the humane question:
   **whose rule is this,
   what scope does it really cover,
   and what lost to it?**

Operators need a third answer:
- the reviewed slice stays visible,
- the footing stays visible,
- the exception or health posture stays visible,
- **and one compact source-shaped surface says which lane authored the current posture,
  which lanes were merely visible,
  and why they did not win.**

## Candidate objects

### 1. Rule stack
A compact shell-owned source stack for one exact active rule or exception relation.

Good early fields:
- exact subject / footing / reviewed-slice ref
- active posture ref (health / watch / action-fit / exception / rule)
- source class:
  - `owner-org`
  - `system-policy`
  - `workspace-local`
  - `reviewed-local`
  - `imported-helper`
  - `historical-receipt`
  - `foreign-observed`
  - `manual-current-turn`
- scope / lane / selector
- current admissibility:
  - `active`
  - `withheld`
  - `advisory`
  - `expired`
  - `imported-only`
  - `history-only`

### 2. Trust shutter
A tiny visible-withheld signal.

Good early fields:
- rule-stack ref
- withheld source ref
- reason class:
  - `trust-closed`
  - `review-required`
  - `restricted-lane`
  - `not-local-authority`
  - `sensitive-scope`
- strongest inspect / review / promote path

### 3. Precedence trace
A nearby inspectable winner/loser explanation.

Good early fields:
- winning source ref
- losing source refs
- loser reasons:
  - `higher-precedence-won`
  - `trust-shutter-closed`
  - `scope-miss`
  - `expired`
  - `advisory-only`
  - `imported-not-reviewed`
- exact scope and footing of the comparison

### 4. Override ledger (later)
A later card that can say:
- a lower or foreign lane was promoted,
- by whom,
- under what exact reviewed footing,
- and what residue or recheck obligation remains.

## What Helm should probably do now

### 1. Keep source classes typed
`owner-org` is not `workspace-local`.
`imported-helper` is not `reviewed-local`.

### 2. Keep source and reason separate
`why rails` explain why the shell believes something.
A **rule stack** should explain where that governing posture came from.
Both matter.
They are not the same seam.

### 3. Keep withheld distinct from overridden
Something can be visible but not admissible.
That is not the same thing as losing to a stronger active winner.

### 4. Keep imported and historical material weaker than active truth
Discovery,
foreign observation,
and durable receipts can stay useful without becoming live authority.

### 5. Keep exact scope visible
A scoped silence,
downtime,
or bypass should reveal the exact monitor set,
alert manager,
environment,
or reviewed slice it binds to.

### 6. Keep this seam smaller than a policy cockpit
The goal is one humane answer to origin and precedence,
not a giant governance center.

## Guardrails

1. **Do not let rule stacks replace underlying requirement truth.**
2. **Do not let trust shutters silently become active state.**
3. **Do not let imported or historical material quietly outrank reviewed local footing.**
4. **Do not let loser explanations vanish behind one generic “managed” or “waived” badge.**
5. **Do not let this seam outrank settlement witnesses + commit cards.**

## Super-awesome move

A reviewed Helm slice could eventually say something like:

> current action-fit remains `inspect-only`.
> exception witness says `waived-active` on publish approval.
> rule stack says the active waiver came from owner/org policy,
> workspace-local proposal is visible but withheld,
> imported helper waiver is present but not reviewed,
> and the narrower reviewed-local rule still governs the compare lane.
> precedence trace shows which candidates lost by trust,
> which lost by higher precedence,
> and which are merely advisory.

That would make Helm much better at telling the truth about rule origin
without turning it into a giant policy,
compliance,
or workflow empire.
