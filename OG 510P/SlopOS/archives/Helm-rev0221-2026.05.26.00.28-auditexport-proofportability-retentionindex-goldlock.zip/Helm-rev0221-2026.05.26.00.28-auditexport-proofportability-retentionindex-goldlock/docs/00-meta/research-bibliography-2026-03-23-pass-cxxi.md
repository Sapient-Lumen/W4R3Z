
# Research bibliography — 2026-03-23 — pass CXXI

- Slack Help Center — Guide to AI features in Slack
  - used for: unread-only summaries, summary sources, and scoped catch-up baselines
  - url: https://slack.com/help/articles/25076892548883-Guide-to-AI-features-in-Slack
- Slack Help Center — Slack updates and changes
  - used for: refresh recap and “new updates since the last time you checked” posture
  - url: https://slack.com/help/articles/115004846068-Slack-updates-and-changes
- Figma Help Center — Guide to branching
  - used for: branch review against main, side-by-side or overlay compare, and review/approve/merge separation
  - url: https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
- VS Code docs — Source Control in VS Code
  - used for: subject-local timeline history and explicit compare-from-here posture
  - url: https://code.visualstudio.com/docs/sourcecontrol/overview
- GitHub Docs — Available rules for rulesets
  - used for: stale approvals when the merge base changes, explicit review footing, and re-approval requirements
  - url: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets
- LaunchDarkly docs — Requesting approvals
  - used for: pending changes, review-before-save posture, and proposal-versus-live separation
  - url: https://launchdarkly.com/docs/home/releases/approval-requests
- Notion Help Center — Wikis & verified pages
  - used for: owner-backed verification, confirmation footing, and expiry-driven re-verification
  - url: https://www.notion.com/help/wikis-and-verified-pages
- Linear changelog — Collapsed issue history
  - used for: noise collapse after baseline selection, grouped consecutive events, and change-feed de-noising
  - url: https://linear.app/changelog/page/4
