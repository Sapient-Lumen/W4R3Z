# Research bibliography — 2026-03-21 pass XXX

## Primary outside sources used in this pass

- Visual Studio Code docs — **Profiles in Visual Studio Code**
  - https://code.visualstudio.com/docs/configure/profiles
- Visual Studio Code release notes — **December 2025 (version 1.108)**
  - https://code.visualstudio.com/updates/v1_108
- Visual Studio Code release notes — **July 2023 (version 1.81)**
  - https://code.visualstudio.com/updates/v1_81
- Figma Help — **Guide to branching**
  - https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
- Figma Help — **Compare changes in Dev Mode**
  - https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Figma Help — **Review and accept library updates**
  - https://help.figma.com/hc/en-us/articles/360039234193-Review-and-accept-library-updates
- Obsidian Help — **Introduction to Bases**
  - https://help.obsidian.md/bases
- Obsidian Help — **Views**
  - https://help.obsidian.md/bases/views
- Obsidian Help — **Bases syntax**
  - https://help.obsidian.md/bases/syntax
- Microsoft Learn — **PowerToys Command Palette Dock**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — **Adding Dock support to your extension**
  - https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support

## Main local teacher documents re-opened in SlopOS rev0585

- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/openuri-materialization-boundary-v0.md`
- `docs/30-architecture/openuri-launch-disposition-boundary-v0.md`
- `docs/30-architecture/openuri-preview-metadata-boundary-v0.md`
- `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- `docs/30-architecture/approval-basis-posture-v0.md`

## What these sources mainly taught this pass

- **VS Code Profiles / drag-and-drop import / partial profiles**: arrivals should be previewed,
  compared,
  and allowed to adopt only bounded classes rather than silently replacing whole environments
- **Figma branching / compare changes / library updates**: comparison surfaces should stay weaker than merge,
  and operators benefit from one-by-one versus update-all acceptance choices
- **Obsidian Bases**: saved views can travel as explicit view syntax without implying that mutable workspace residue traveled too
- **PowerToys Dock**: compact persistent shell surfaces become more useful when their units are explicit bands/items rather than fuzzy launcher mush
- **SlopOS selection and OpenURI boundaries**: comparison,
  launch,
  materialization,
  and exact selection should stay distinct workflows rather than being laundered into one convenient success story
