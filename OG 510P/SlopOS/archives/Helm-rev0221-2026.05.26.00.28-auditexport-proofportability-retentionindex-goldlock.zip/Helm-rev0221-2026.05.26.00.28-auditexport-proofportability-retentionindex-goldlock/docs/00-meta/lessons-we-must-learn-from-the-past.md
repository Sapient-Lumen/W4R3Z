# Lessons we must learn from the past

Purpose: separate **hard-earned desktop lessons** from shiny feature collection.

This is a Helm doc, not a nostalgia shrine. The point is to remember which patterns repeatedly worked, which repeatedly rotted, and which only looked powerful because users had no better substrate.

## The must-learn list

### 1. Ambient authority always feels better before it feels worse

Old desktop power cultures often won because they gave users immediate leverage:
- global hooks
- synthetic input
- scriptable titles and classes
- path-paste glue
- helper processes that could touch anything

That power is real.
But it reliably creates:
- invisible persistence
- weak explainability
- race-condition automation
- security surprises
- support nightmares
- “I do not know why my desktop just did that” moments

Helm must keep the reach while refusing the ambience.

### 2. Window management alone is never enough

Great WMs matter, but they are not the whole desktop.

Past systems often overfit to:
- placement
- decoration
- tiling algorithms
- config elegance

and underfit to:
- browsing
- continuity
- routing
- transfer truth
- operations honesty
- automation introspection

Helm should remember that the window surface is only one face of desktop truth.

### 3. Launchers become central the moment they stop being launchers

The best summon surfaces evolve from:
- “run this app”
to
- “find the thing, switch the context, take the action, and show me why”

The lesson is not “build a cooler launcher.”
The lesson is:
**the summon surface becomes central when it understands real desktop objects and actions.**

### 4. File managers stagnate when search and preview are bolt-ons

The past keeps teaching this:

A browser that only excels at folder traversal eventually feels cramped.
The winning moves are:
- instant preview
- query views
- tags/attributes
- saved views
- strong bulk operations
- exact reveal
- good keyboard paths

Helm should make those normal, not optional.

### 5. “Recent items” is not continuity

Many desktops quietly substituted:
- recent files
- shell history
- toasts
- app-local restore
for actual continuity.

That is not enough.

Users need:
- where they were
- what state was live
- whether a return is exact or approximate
- what changed
- what is gone
- what still needs permission or repair

Recall only earns its place if it provides that.

### 6. “Task manager” UIs usually explain the wrong machine

Classic task managers center:
- processes
- memory
- CPU
- kill buttons

That is useful but incomplete.
Modern desktop truth also includes:
- jobs
- flows
- routes
- transfers
- background presence
- grants
- restore failures
- denied actions

Helm should not regress to process theater.

### 7. Visual programming without observability becomes decorative spaghetti

The graph is not the magic.
The support machinery is the magic:
- debug views
- status cues
- error surfaces
- packageable subgraphs
- search and outline
- performance visibility
- disable/hold/breakpoint-like moves

Desktop Flow needs those from day one of serious use.

### 8. Users love spatial overview when it is fast and honest

Overviews succeed when they:
- reduce lost-window anxiety
- make workspace state legible
- allow direct manipulation
- stay keyboard-friendly

They fail when they:
- become heavy
- become mouse-only theater
- hide exactness
- split from the main action model

Helm should steal the good version.

### 9. Session restore should always admit when it is bluffing

Approximate restore can be extremely valuable.
The mistake is pretending it is exact.

Helm should normalize badges like:
- exact
- repaired
- partial
- unavailable

and make the reasons inspectable.

### 10. Extensibility wins, but only when the host keeps the law

Plugin systems are worth having.
But the host must still own:
- review
- lifecycle
- receipts
- exactness
- visibility
- failure reporting
- revocation

Helm should not let extension culture erase shell law.

### 11. Requests, launches, and notifications are not the same thing as outcomes

Past systems often quietly blurred:
- requested action
- launched helper
- visible toast/spinner
- and durable successful outcome

Those are not the same truth.

Helm should keep proposal, route, launch, live observation, receipt, denial, and drift visibly distinct wherever promises matter.

### 12. Saved setup is not live setup

Users clearly love:
- workspaces
- profiles
- launch kits
- saved layouts
- and return-to-task shortcuts

The lesson is **not** that saved entry artifacts are fake.
The lesson is that they rot when they overclaim.

A saved setup may preserve:
- intended shape
- useful hints
- likely targets
- or last-known continuity

But it should not quietly impersonate:
- a live session
- a live window set
- current remote/profile/account truth
- or current grants and attachments

Helm should make saved entry artifacts feel powerful by giving them honest ladders — inspect, attach, restore, relaunch, fresh launch, or hold — rather than by pretending they are already live.

### 13. Derived surfaces rot when they hide derivation

Past systems repeatedly gave users:
- saved searches
- smart folders
- sidebars
- dashboards
- pinned shortcuts
- and compare views

The good versions were powerful because they stayed visibly derived.
The bad versions rotted because users could no longer tell:
- what the surface was derived from
- which basis it still depended on
- whether it was local,
  shared,
  historical,
  or current
- and whether it still needed re-materialization,
  re-check,
  or re-approval

Helm should treat provenance as a product feature,
not as a hidden debug panel.

### 22. Sharing is not the same thing as activation

Past systems also kept making one flattering mistake:
if something could be exported,
synced,
shared,
or published,
people were encouraged to talk about it as though it were already live in every relevant place.

That mistake creates:
- ambient sync mythology
- hard-to-explain scope changes
- ghost state on the receiver side
- and permissions that feel inherited by vibe

Helm should normalize a stronger distinction:
- local
- activity-local
- portable/exportable
- shared
- published
- and separately materialized/adopted/live

A published thing may be useful.
It is still not automatically a live local thing.

### 21. The substitute path should never inherit authorship by elegance alone

Past systems increasingly offer:
- handoffs
- suggested next steps
- reuse of existing state
- delegated helpers
- guided recovery

Those moves can be excellent.
The rot begins when the system stops saying who chose the substitute.

Users forgive:
- uncertainty
- staged review
- proposal-only fallbacks
- forced-reuse warnings

more quickly than they forgive:
- hidden authorship laundering
- “the system chose this for you” disguised as “you are back where you were”
- delegated changes that wear the operator's badge by fluency alone

Helm should normalize tiny witnesses that can answer:
- who proposed this continuation path
- who chose it
- who executed it
- whether the shell is showing a suggestion, a forced fallback, a delegated handoff, or an exact carry

That is especially important as Helm grows richer AI-shaped help and stronger task-return luxuries.

### 22. Approval should not follow the head just because the shell remembers the task

One of the easiest ways for a powerful system to become dangerous is:
- the user reviews one thing
- the underlying mutable basis changes
- the system still offers the same strong action as if nothing meaningful changed

Mainstream systems increasingly refuse this.
That is a lesson worth stealing.

Helm should normalize:
- exact reviewed basis
- stale-basis refusal
- review again
- inspect drift
- and explicit fresh bind

instead of:
- sticky approval
- floating “latest now” action buttons
- or continuity cards that remember the task but forget the basis

### 23. A portable handoff is not live continuity

Modern tools increasingly let people export,
share,
import,
or deeplink useful setup objects.
That is good.
The rot begins when the traveling object starts pretending it already recreated live local state on the receiver side.

Helm should normalize a better distinction:
- packetized handoff
- inspectable import
- materialize locally
- adopt into activity
- trust or review when needed
- and only then stronger live claims

A useful packet is a luxury.
A packet that pretends to be live continuity is future folklore.

### 24. Publication without a witness becomes myth surprisingly quickly

Past systems often made export,
share,
sync,
and publish feel easy in the moment,
but hard to explain later.
Users lose track of:
- what actually crossed a scope boundary
- where it went
- who can see it now
- what was redacted
- whether the receiver still needed materialization or trust
- and how to revoke or compare the new publication state

Helm should leave compact durable witnesses for cross-tier moves.
A promotion receipt is not bureaucracy.
It is how the shell keeps portability from dissolving into myth.

## What this means for Helm

We should protect these directions aggressively:

- shell-owned truth over folklore
- exactness over “helpful” approximation where promises matter
- visible raw power over ambient raw power
- preview/query/overview as normal desktop moves
- continuity and transfer as first-class product concerns
- activity-scope truth over nearby-context folklore
- reviewed-basis truth over sticky-head approval folklore
- better debugging and honesty surfaces than old desktop power cultures ever had

## Things to keep repeating to ourselves

- The goal is not to make hacks impossible; it is to make them non-foundational.
- The goal is not to freeze everything early; it is to freeze the right invariants.
- The goal is not to copy historical apps; it is to preserve the powers they made feel indispensable.


### 13. Hidden reuse is where continuity systems start lying

The dangerous moment is often not the first save.
It is the later quiet reuse: an existing window is reused, a near-enough session is rebound, a remembered slot is repaired, or a last-seen destination silently inherits authority.
That feels helpful in the short run, but it is exactly where continuity systems begin flattering the user instead of telling the truth.

Helm should normalize a better grammar:
- exact
- repaired
- ambiguous
- unavailable

The system can still be luxurious.
It just should not hide the join.
A witnessed repaired join is a luxury.
A silent repaired join is future folklore.

### 21. Helpful background work should not become live truth by surprise

As systems get more agentic and task-return luxuries get richer,
a new failure mode appears:
- the operator stays in one live lane,
- a helper or background lane does real mutable work elsewhere,
- and the system quietly lands that work into the live story before adoption is truly visible.

Good tools are increasingly refusing that move.
They isolate background work,
keep review or apply moments visible,
and make promotion explicit.

Helm should normalize:
- isolated candidate lanes for meaningful delegated mutable work,
- compact adoption cards,
- basis-aware adopt / reject / hold ladders,
- and a clear difference between proposal, candidate work, and authoritative live state.

That is how Helm gets more magical **without** getting more ambient.

### 22. Launch kits are helpful, but they are not continuity

Modern tools keep proving that saved launch configurations,
quicklinks,
entry objects,
and launcher menus are useful.

The mistake is treating those objects as proof that:
- the old task is still live
- the right remote/profile/account is still attached
- the right window is still reusable
- or the shell can skip review because it has seen this before

Helm should let users save strong starting points,
but keep the ladder explicit:
- fresh launch
- attach
- reuse
- repaired return
- historical replay
- or hold

### 21. History gets far better when it remembers source and authority grade

A giant undifferentiated recent-items bucket feels convenient at first,
but it quickly loses trust.

The better lesson from modern tools is that recency becomes much more useful when entries preserve:
- where they came from
- who authored them
- whether they are live,
  historical,
  delegated,
  imported,
  or request-only
- and what honest next action is still allowed

Helm should make Recall care about exact objects,
exact actions,
routes,
and receipts — not just app/file nostalgia.

### 22. Reuse only scales when fragments carry status and can still be opened up

Flow systems keep repeating the same lesson:
copy-paste reuse rots,
opaque prefabs rot,
and giant canvases rot.

What survives is:
- reusable fragments
- visible status
- inspectable internals
- provenance/version cues
- and obvious failure/hold surfaces

Desktop Flow should learn that before it accumulates pretty spaghetti.


### 21. Preview should stay lighter than open, but richer than a tooltip

A lot of systems got this half right.
They offered either:
- tiny useless thumbnails
- or a full open-first workflow

The better move is a shell-owned preview that can still carry:
- source
- route
- metadata
- and a few bounded next actions

Helm should learn that preview becomes strategic when it sits adjacent to action **without** claiming it already committed anything.

### 22. “Forget that” almost never means one storage plane

As shells and desktops get smarter, they accumulate:
- visible viewport history
- scrollback
- durable local history
- restored sessions
- recent items
- preview residue
- and maybe synced history

The lesson is not that memory is bad.
The lesson is that the system should stop pretending that:
- clear screen
- clear visible history
- suppress future retention
- prune durable local memory
- and erase exported or synced residue

are all the same action.

Helm does not need a giant retention constitution yet,
but it should remember this warning when shaping Recall and Operations Center.

### 22. One giant mixed search surface eventually lies

Past launchers, palettes, and search surfaces keep proving a pattern:
flat mixed lists feel magical at first, then confusing.

The user eventually needs to know whether they are seeing:
- an object
- an action
- a route
- a receipt
- transfer history
- or a merely suggested next move

Helm should keep one fast summon path while still allowing typed pivots when they improve honesty.

### 21. Preview becomes dangerous the moment it feels equivalent to open

The best systems keep rediscovering preview because it is humane.
But the line matters.

Preview can render, inspect, summarize, and stage bounded next actions.
It should not quietly count as:
- open
- import
- attach
- trust escalation
- or execution

Helm should make preview feel strong by making the nearby next ladder good, not by blurring the boundary.

### 21. The first workflow should not quietly smuggle in a second workflow

Past systems repeatedly make one move that feels magical for a while and rotten later:
- open becomes open + place + reuse + foreground + authorize
- preview becomes preview + open + import
- history becomes history + continuity proof
- background helper becomes helper + live mutation

The convenience is real.
The ambiguity cost is real too.

Helm should normalize the stronger law:
**if a second workflow matters, it should appear as a second workflow.**

That means separate ladders, witnesses, holds, or review/apply steps instead of hiding richer power behind one innocent-looking verb.

### 22. Background power only stays lovable when apply/adopt stays explicit

Modern tools increasingly show the right instinct:
- isolate background work,
- track it clearly,
- show what changed,
- then let the operator apply/adopt it deliberately.

The failure mode is just as common:
- helpers mutate the authoritative lane by surprise,
- history laundered into authorship,
- stale basis mistaken for safe apply,
- or “done” standing in for review.

Helm should make background and delegated power feel amazing by making it:
- visible,
- inspectable,
- drift-aware,
- and explicitly adoptable.

That is a stronger kind of magic than silent merge folklore.

### 21. Derived surfaces should stay derived

A lot of desktop products slowly drift into trouble the same way:
- a status edge becomes a second dashboard
- a dock becomes a second launcher constitution
- a preview surface becomes hidden open/import authority
- a watch window or lens starts pretending independence

The power is not the mistake.
The mistake is forgetting that these surfaces are derivative.

Helm should normalize compact projection surfaces that are:
- bounded
- typed
- source-witnessed
- and non-authoritative by default

That is how Helm gets more magical without growing a second truth machine in the chrome.


### 22. The cube is not the truth

Systems that collect many useful views often drift into a bad belief:
that because a compact derived surface is useful, it can stand in for the stronger truth underneath it.

That is how dashboards become second control planes, saved views become live proof, and history summaries become operational truth.

Helm should steal the better law instead:
- multiple views are good
- keyed projections are good
- compact trails are good
- but each still remains a view over stronger truth unless an explicit stronger step happens

The shell should win by letting people pivot among great views, not by letting the view impersonate the world.


### 21. Multiple views beat one flattering summary

Systems often get more useful by adding more views.
They get worse when one of those views quietly claims to be the canonical story.

The better lesson is:
- many explicit views are good
- named pivots are good
- compact comparative surfaces are good
- but each still stays a view unless a stronger explicit step happens

Helm should get more powerful by making excellent view decks, not by pretending one summary chrome surface is the world.

### 22. Materialization should stay explicit and provenance-bearing

Past systems repeatedly hide strong changes behind weak verbs:
- preview that quietly imports
- open that quietly creates durable identity
- compare that quietly saves over the original
- candidate work that quietly becomes live truth

The shell should steal the opposite habit.
When a weaker or derived thing becomes a stronger local or live thing, the step should:
- be explicit
- name the target form
- preserve provenance
- and prefer fresh identity where equality would otherwise launder meaning

That is how Helm keeps delight without turning charm into drift.


### 21. Great local tools often rot when they quietly become shared truth

Modern power tools keep rediscovering the same boundary:

- some setup is personal
- some is workspace-shaped
- some can travel
- some should be shared
- and some should stay stubbornly local

The rot starts when a system quietly assumes every useful surface should sync, restore everywhere, or count as team truth.

That mistake creates:
- noisy repos
- confusing profile/workspace/device overlap
- false continuity
- and surprising leaks of personal or sensitive habits

Helm should normalize explicit promotion between locality tiers rather than ambient portability.

A local dock, a local lens arrangement, or a personal action key may be excellent precisely because it is local.
A portable or shared version should be a second workflow, not a flattering side effect.


### 21. Saved views and templates are recipes, not live truth

Modern tools keep proving that users love:
- saved views
- filters
- layouts
- favorites
- templates
- launch configurations
- reusable starters

Those are all good.
The rot begins when a saved starter quietly claims:
- current live bindings
- current trust
- current availability
- current local materialization

Helm should treat reusable starters as recipes until an explicit materialization step earns a stronger claim.

### 22. Change awareness beats fake continuity

One of the most valuable luxuries modern tools keep adding is not just restore or history.
It is:
- compare changes
- checkpoints
- drift cues
- ready-for-review or changed-since status
- inspectable forks

Users do not need the shell to bluff that nothing changed.
They need the shell to help them answer:
- what changed
- since when
- compared to what
- and whether they should review again

Helm should normalize compact change-aware surfaces instead of forcing users to choose between fake continuity and giant forensic tools.

## Pass XXVIII addendum

- what did not travel is part of the truth
- what may use receiver defaults should be stated explicitly, not hidden as ambient fallback
- saved surfaces should carry slot law, not just vibes about where they belong


### 25. Move, copy, and instantiate are not the same story

Past systems often blurred:
- move
- duplicate
- export/import
- template instantiation
- and “same thing in a new place”

That blur feels convenient right until users need to answer:
- why updates no longer propagate
- why two nearly identical things diverged
- whether a receiver got the same object or a fresh copy
- what counted as ancestry versus live linkage

Helm should normalize an explicit choice between:
- preserve lineage
- fork as copy
- instantiate from starter

The luxury is not hiding the difference.
The luxury is making the difference easy to understand and easy to choose.
