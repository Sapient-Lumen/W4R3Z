# SlopOS companions evaluation — 2026-03-23 pass CLX

## Purpose

Continue evaluating **SlopOS**, **Schell**, **ViewFS**, **Harbor**, **Foundry**, **Ward**, and **Steward** after the pillar-recipe pass by asking one tighter question:

**what should Helm learn next if pillar-specific deck recipes are real,
but stronger cross-pillar landings still need order,
attempt history,
live continuation truth,
and honest partial remainder?**

## Answer up front

The best next move is not a new pillar.
It is one compact support cluster:
- **landing trains**
- **attempt-aware lineage**
- **continuation handles**
- **remainder witnesses**

That cluster gives stronger acts a humane after-review path without turning Helm into a workflow religion.

## 1. SlopOS still teaches that reviewed basis and preconditions must stay exact and local

SlopOS keeps rewarding the same discipline:
review binds one exact mutable basis,
and preconditions should name exact local witness material.
That means a Helm landing train should never say “probably still fine.”
It should say:
- exact target lane
- exact queue order
- exact reviewed basis or grouped basis
- exact invalidation reason when the story drifted

## 2. Schell still teaches proposal / review / run / later outcome separation

Schell’s stage separation remains one of Helm’s best protections against mush.
A recipe is not a run.
A queued landing is not a settled outcome.
A rerun is not the same thing as the original attempt.
That pressure makes attempt-aware lineage look much more necessary,
not less.

## 3. ViewFS still teaches basis / apply / adoption / snapshot / receipt separation

ViewFS repeatedly keeps parse,
diagnostics,
packets,
apply sessions,
adoption,
and durable receipts distinct.
That law maps directly onto the new move.
A landing train should be a promotion object.
A continuation handle should be a live next-step object.
A remainder witness should be an unfinished-slice object.
None of them should collapse into one status row.

## 4. Ward still teaches freshness fences and revalidation before stronger moves

Ward’s read cuts,
staleness budgets,
and revalidation fences keep saying the same thing:
a queue item or older review packet is not safe forever.
That is excellent pressure for landing-train invalidation weather and for continuation handles that can become expiring,
stale-check-first,
or gone.

## 5. Harbor still teaches route choice and aftermath are different truths

Harbor’s route / trust / aftermath posture remains extremely useful here.
A chosen lane,
receiver,
or audience class is not the same thing as later meaningful completion.
That is why a landing train,
a continuation handle,
and a settlement witness should remain neighbors,
not synonyms.

## 6. Foundry still teaches runtime evidence is not a verdict

Foundry helps because it keeps confext checks,
overlays,
and runtime observations smaller than actual verdicts.
That is the exact humility Helm needs once queued or staged landings exist.
Interim evidence may help,
but it must not impersonate final durable truth.

## 7. Steward still teaches typed pressure and bounded recovery

Steward’s adaptation pressure argues against one vague retry button.
When a stronger act degrades,
operators need the smallest honest next rung:
- rebuild queue item
- rerun failed subset
- continue exact handle
- widen on fresh basis
- or stop
That is exactly what repair ladders become better at once continuation handles and remainder witnesses exist.

## Product judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **pillar-specific recipes** and **bounded rehearsal decks** as the current starter grammar.

But the next adjacent cluster now looks warm enough to name much more explicitly:
- **landing trains** for stronger grouped promotion
- **attempt-aware lineage** so one story and its retries stay readable
- **continuation handles** so live next-step windows stay exact
- **remainder witnesses** so partial completion stays smaller than the original cohort

That cluster is the cleanest next way to make Helm’s datacube feel sharper without freezing one giant center.
