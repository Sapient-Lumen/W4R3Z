# Helm linked views + front-door handles — 2026-03-22

Purpose: name the next two compact support moves that look worth proving after the latest outside pass without adding a pillar or turning Helm into a giant workspace system.

## Main idea

Helm now looks ready for two more practical datacube moves:

- **linked views** — borrow one saved view by reference inside other surfaces
- **exact front-door handles** — tiny summonable entry objects smaller than full entry kits

A third move looks promising but should remain warmer than these two:

- **suggestion-first triage** — explainable routing/duplicate/next-step suggestions that stay weaker than operator adoption

## 1. Linked views

A **linked view** is not a copy.
It is not a screenshot.
It is not a new authority domain.

It is one saved view object borrowed by reference inside another shell surface such as:
- an activity entry kit
- a view deck
- a cockpit card
- Overview
- a triage lane
- a compare/review surface

### Why this is worth stealing

Notion linked databases,
GitHub multiple project views,
GitHub hierarchy view,
and Obsidian Bases all point toward the same humane product truth:
people want to reuse one underlying structured view in several places,
with different framing,
without maintaining several independent copies.

### The Helm law

A linked view should keep:
- source witness
- basis witness
- trust/locality tier
- exact subject family or explicit query basis
- and visible degradation when the source is stale,
  missing,
  imported-restricted,
  or no longer authorized

### The key win

This would let Helm's datacube feel much richer without getting bigger.
Instead of creating more view families,
Helm can let the best saved views travel farther.

## 2. Exact front-door handles

An **exact front-door handle** is a very small shell-owned entry object.

It can point at one exact thing such as:
- one saved view
- one activity entry kit
- one triage lane
- one compare path
- one exchange route
- one provider deeplink
- one scoped launch path

### Why this is worth stealing

Raycast Quicklinks and PowerToys Workspaces both show that tiny named handles are powerful.
People do not always want a full project shell object.
Often they want:
- the fast way back in,
- the exact route to the compare surface,
- or the exact summonable launch for one recurring path.

### The Helm law

A front-door handle should be:
- exact
- summonable
- pinnable
- attachable to other surfaces
- shareable or importable when safe
- and clearly weaker than current-live truth

A handle should never pretend:
- this lane is definitely live now
- this profile/provider/session is already correct now
- or this imported path is already adopted local truth

## 3. Suggestion-first triage

Helm should absolutely steal the best part of modern triage systems:
not just a queue,
but a queue that can say:
- likely team
- likely route
- likely duplicate
- likely compare path
- likely next surface

But the first posture should be:
- **suggest**
- **inspect why**
- **accept / decline**
- maybe **save local guidance**

not silent global auto-apply.

## 4. Profile-scoped front doors

This is not a separate new contract yet,
but it now looks important enough to sharpen in entry-kit law.

A front door should be able to remember:
- preferred profile
- preferred provider/account
- preferred browser/space
- last-good lane

But those should remain:
- hints
- witnesses
- or stronger explicit attach choices

They should not be ambiently assumed.

## 5. What feels wise to pull the trigger on now

### Pull the trigger now
- **linked views**
- **exact front-door handles**

These are compact,
fit the current direction,
and improve product feel without rewriting Helm's constitution.

### Sharpen now but keep warm
- **profile-scoped front doors**
- **suggestion-first triage**
- **hierarchy-preserving overlays inside views**

These should be proven inside existing entry-kit,
view,
and triage surfaces before becoming their own bigger architecture claims.

## 6. Lessons we must keep learning from the past

1. **Tiny entry objects are safer than giant project abstractions.**
2. **Borrowed views are better than copied dashboards.**
3. **Profile affinity is useful; silent profile choice is dangerous.**
4. **Suggestions are useful; silent adoption becomes folklore fast.**
5. **The shell should get richer by composing exact objects, not by inventing one new master object every week.**

## Judgment

Helm now has a better next-step sequence:

- keep the seven pillars stable
- keep saved view objects and checkpoint branches as the main proofs
- add **linked views** and **exact front-door handles** as compact support proofs
- sharpen **profile-scoped front doors** inside activity entry kits
- keep **triage intelligence** in explainable suggestion posture until stronger review machinery is ready
