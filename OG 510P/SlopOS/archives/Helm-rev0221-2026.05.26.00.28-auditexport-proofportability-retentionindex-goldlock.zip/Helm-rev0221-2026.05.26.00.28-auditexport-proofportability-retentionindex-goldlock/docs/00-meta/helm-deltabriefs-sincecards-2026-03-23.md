# Helm delta briefs + since cards — 2026-03-23

Purpose: name the strongest next cross-cutting move now that Helm has **state tuples** and **why rails** but still lacks a humane answer to:

**what changed since my last trustworthy basis, and should I care?**

## Main idea

Helm now has three useful layers:
- **state tuples** for what the compact surface is claiming
- **grounding witnesses + why rails** for why the shell currently believes that claim
- strong source surfaces like receipts, timelines, compare lanes, and review/adoption views

What is still missing is a bounded middle seam for change.
Not a giant timeline.
Not a chatty recap.
Not a fake omniscient summary.

The next object Helm should warm is a **delta brief**.
A **since card** is one likely rendering of that object in compact chrome.

A delta brief answers:
- what exact earlier basis are we comparing against?
- what exact later basis or live witness are we comparing to?
- what actually changed?
- what stayed stable?
- which changes matter enough to promote?
- and what stronger diff or inspection surface should open next?

## Why this now looks ripe

Grounding witnesses and why rails make compact status answerable.
But operators also need one nearby answer to:
- what changed since last-confirmed?
- what changed since I bookmarked this landmark?
- what changed since the last review/adoption basis?
- what changed since I last looked at this activity?

Without that seam Helm risks falling back to:
- raw timelines
- log theater
- vague “updated” badges
- giant recap folklore
- or casual memory that is not basis-aware

Delta briefs look like the missing glue between exact timelines and tiny chrome.

## What this lets Helm do better

### 1. Make return loops feel immediate without bluffing
Recall can say not just **where you can return**, but **what moved since you last trusted this path**.

### 2. Keep overview tiles and strip slots honest
A compact tile can open a delta brief rather than forcing the operator to infer change from timestamps alone.

### 3. Distinguish explanation from change
A why rail answers **why this claim exists now**.
A delta brief answers **what changed between two exact bases**.
They are neighbors, not substitutes.

### 4. Keep review/adoption calmer
A lane, adoption harbor item, or current-live beacon can show what changed since the last accepted footing without pretending that all changes are equal.

### 5. Support bounded recaps without giant memory
Slack-style recaps and Linear-style collapsed history are useful only when they stay scoped.
Helm should steal the boundedness and source-awareness, not the ambient-summary fantasy.

## What not to steal

- no giant activity feed pretending to be truth
- no AI-only summary without exact compared bases
- no flattening of authoritative diff and inferred recap
- no “updated” badge without changed axes or stronger inspect exits
- no causal claims unless the witness actually supports them

## Pull-the-trigger judgment

Keep the seven pillars stable.
Do not add another pillar.
Do not freeze a giant recap/dashboard/history product.

But it now looks wise to **promote delta briefs (with since cards as a likely tiny rendering)** as the next cross-pillar proof target.

If Helm gets this right,
it becomes more awesome at the exact moment users feel friction most:
**coming back, noticing drift, and deciding whether the change matters.**
