# Helm — floor grafts and adoption receipts

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one roaming continuity substrate.
Do **not** let imported footing silently become local authority.

The strongest next move is smaller:
**warm floor grafts + adoption receipts as the shell-owned seam after floor tickets and handoff bounds.**

Helm can already say:
- what footing was held,
- what crossed a handoff seam,
- whether the receiver can verify or strengthen it here,
- and whether the honest next move is compare,
  continue read-only,
  upgrade locally,
  or downgrade / reacquire.

What it still answers too weakly is:
- **when has the receiver actually made that carried footing its own here?**
- **what part of the carried footing became a local floor, and what stayed imported-only?**
- **what exact receipt proves the local adoption happened, under which cut, and with which omissions or downgrades?**

## The lesson Helm must learn from the past

Past systems keep repeating a continuity mistake after flattening `done`, `current`, and `carried enough`:
**they flatten fetched or imported footing into adopted local footing.**

That creates haunted shell behavior:
- a shared deck opens and looks current enough,
  so the receiver forgets it is still only standing on carried read-side evidence;
- a receiver verifies part of a carried floor,
  but the shell flatters the whole imported object into local authority;
- a future act depends on what was locally adopted,
  but the shell only remembers that something crossed a seam,
  not what actually got grafted into local footing.

Helm should refuse the myth that `opened here` means `owned here`.

## What the outside world is teaching right now

### Azure Cosmos DB: passed session tokens stay read-side minimum barriers
Cosmos DB says passed session tokens should not be modified,
recommends them for read operations,
and treats them as a minimum version barrier rather than a request for one historical version.
That is a direct precedent for Helm:
**a carried floor can be portable,
but it is still not local write authority until the receiver explicitly chooses a local footing.**

### MongoDB: causal footing can cross sessions explicitly
MongoDB lets a client session advance operation time and cluster time so it can be consistent with another session.
That is already very close to a Helm handoff.
The missing shell move is the next step:
**after explicit transfer,
what exact local session or deck adopted that footing and now owes it going forward?**

### Couchbase: targeted lower-bound evidence is worth carrying
Couchbase `MutationState` / `consistentWith` shows that a receiver can carry just the lower-bound mutations that matter.
That strongly suggests Helm should graft only the footing that the next act depends on,
not everything that arrived in the packet.

### Kafka: current position and committed position are different truths
Kafka's consumer docs separate the consumer's current position from the committed position that is stored securely and recoverable on restart.
That is an unusually good steal for Helm:
**receiver-local working footing and receiver-durably-adopted footing are different truths.**

### Git: fetched remote-tracking state is not the same thing as local branch adoption
Git fetch updates remote-tracking branches;
Git merge incorporates named commits into the current branch.
That is almost a perfect shell metaphor:
**a floor ticket can arrive and be inspectable here without that footing yet being grafted into the receiver's local mainline.**

## What the companion cubes are teaching now

### Keep from SlopOS
Keep provider-locality discipline and exact witness posture.
A floor graft should remain a shell-owned local act backed by provider evidence,
not a claim that one provider's session token became universal shell truth.

### Keep from Ward
Ward's read cuts,
staleness budgets,
and revalidation fences imply that a graft must name the exact cut it adopted.
A local receiver should not say `mine now` without a cut witness.

### Keep from Schell
Schell keeps restored-versus-live humility and strongest-next-verb discipline sharp.
A carried floor may support inspect or compare.
A graft is the moment Helm can say `this receiver now owes this floor locally`.

### Keep from ViewFS
ViewFS is still a great teacher here:
remembered designators,
continuity lockers,
revalidated live handles,
and durable receipts are different truths.
A **floor graft** should stay closer to a local continuity locker;
an **adoption receipt** should stay durable evidence rather than a live oracle.

### Keep from Harbor / Exchange / materialization witnesses
Route truth,
receiver acquisition truth,
and local adoption truth are still not the same thing.
A receiver may have fetched bytes,
opened a deck,
or verified one claim,
and still not have grafted that footing into a local floor.

## Bright steals for Helm

1. **Floor graft**
   - one explicit receiver-local act that turns a carried floor ticket into a local remembered floor for one deck,
     work surface,
     session,
     or bounded saved object.
2. **Adoption receipt**
   - one durable receipt that says exactly what ticket or basis was grafted,
     under which cut,
     into which local scope,
     with what omissions,
     downgrades,
     or blocked verbs.
3. **Working vs committed local footing**
   - one tiny distinction between `using this now` and `durably adopted here`.
4. **Selective graft**
   - adopt the slice that matters for the next act,
     leave the rest imported-only and visible.
5. **No silent upgrade from carried to local strong**
   - if a stronger local footing exists,
     Helm may strengthen on graft,
     but it should say so.

## What not to keep

Do not keep:
- one hidden automatic handoff-to-adoption path,
- one rule that opened shared state becomes local mainline by default,
- or one universal merge language for all footing packets.

Keep the shell grammar small,
make the graft explicit,
and keep the receipt durable.

## Why this makes Helm super awesome

This makes Helm feel premium right at the moment where modern systems usually get spooky.
A person can ask:
- `what carried footing am I using right now?`
- `has this receiver actually adopted it locally yet?`
- `what exactly was grafted, and what stayed imported-only?`
- `is this only a working floor, or is it durably adopted here too?`
- `what exact local cut and receipt would I reopen later to justify a stronger move?`

That is better than a bigger cube.
Not because Helm promises universal continuity,
but because it tells the truth about the difference between **carried footing,
working local footing,
and durably adopted local footing.**
