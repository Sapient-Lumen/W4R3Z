# Research bibliography — 2026-03-23 pass CXXXVII

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-MONGODB-WRITECONCERN-2026 | https://www.mongodb.com/docs/manual/reference/write-concern/ | staged write acknowledgment still matters: `w`, journaling, majority, and timeout law are different truths |
| REF-KAFKA-PRODUCER-ACKS-2026 | https://kafka.apache.org/41/configuration/producer-configs/ | producer `acks` remains an official durability dial rather than one universal success state |
| REF-KAFKA-MIN-ISR-2026 | https://kafka.apache.org/41/configuration/topic-configs/ | `min.insync.replicas` keeps visibility/durability law separate from mere request acceptance |
| REF-S3-REPLICATION-STATUS-2026 | https://docs.aws.amazon.com/AmazonS3/latest/userguide/replication-status.html | explicit `PENDING` / `COMPLETED` / `FAILED` / `REPLICA` remains a great settlement teacher |
| REF-ICEBERG-BRANCHING-2026 | https://iceberg.apache.org/docs/latest/branching/ | branches/tags as named snapshot references with independent retention is strong pressure for saved decks and checkpoint branches |
| REF-DOLT-BRANCHES-2026 | https://docs.dolthub.com/sql-reference/version-control/branches | commit-graph branches for isolated work, historical analysis, and lineage are a strong branch-backed-shell precedent |
| REF-FIGMA-BRANCHING-2026 | https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching | humane branch UX: exact replica of main, update from main, review/merge, and version-history checkpoints |
| REF-MATERIALIZE-SUBSCRIBE-2026 | https://materialize.com/docs/sql/subscribe/ | point-in-time select versus live subscribed change stream is a clean model for live inspector decks |
| REF-DBT-SOURCE-FRESHNESS-2026 | https://docs.getdbt.com/docs/deploy/source-freshness | freshness rendered as a visible SLA-facing product surface is a strong pattern for Helm freshness lamps |
| REF-DUCKDB-PARQUET-2026 | https://duckdb.org/docs/stable/guides/file_formats/query_parquet | direct local analytical reads with pushdown/parallelism are a good model for a non-authoritative Helm analytics sidecar |
