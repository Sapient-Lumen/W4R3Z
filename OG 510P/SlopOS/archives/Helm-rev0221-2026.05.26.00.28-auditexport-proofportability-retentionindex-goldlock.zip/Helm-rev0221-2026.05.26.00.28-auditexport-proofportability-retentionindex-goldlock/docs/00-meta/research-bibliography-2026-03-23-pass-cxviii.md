# Research bibliography — 2026-03-23 pass CXVIII

1. **Kubernetes Pod lifecycle and Pod conditions**
   - Why it mattered: phase is explicitly only a high-level summary, while conditions stay separate and extensible.
   - Helm pull: state tuples should keep phase and typed conditions separate rather than flattening everything into one badge.

2. **GitHub status checks / check runs**
   - Why it mattered: checks distinguish status from conclusion, so current progress and final result are not the same field.
   - Helm pull: keep current phase distinct from last durable outcome in tuples, postcards, and Ops rows.

3. **systemd ActiveState / SubState / Result**
   - Why it mattered: systemd separates coarse state, more specific substate, and remembered result.
   - Helm pull: Helm should adopt a similar multi-axis shell grammar without copying systemd's exact vocabulary.

4. **Microsoft PowerToys Command Palette + Dock**
   - Why it mattered: the typed doorway remains central, while pinned shortcuts and docked quick access provide small persistent utility.
   - Helm pull: keep Omnibox as the doorway; keep any persistent shell face tiny and tuple-backed.

5. **Raycast Quicklinks + Quick Search**
   - Why it mattered: promoted quick actions stay explicit, and selected text can fill the first argument of a template.
   - Helm pull: keep action landmarks explicit and optionally argument-fed when the subject/selection is exact.

6. **Windows Click to Do**
   - Why it mattered: selection-scoped action remains magical in the safest way when analysis is local-first and outbound sharing only happens after the user chooses an action.
   - Helm pull: favor exact selected subjects and explicit provider handoffs over ambient context guessing.

7. **Figma branching + review/merge**
   - Why it mattered: side work stays luxurious when review state, comparison, merge, and archive posture are explicit.
   - Helm pull: use tuple-backed review/adoption posture instead of letting side work wear current-live certainty.
