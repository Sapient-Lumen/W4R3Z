# SlopOS + companions evaluation — 2026-03-23 — pass CLXVI

This pass asked:
after Helm can say what footing counted,
what aged,
and whether replacement overlapped honestly,
what do SlopOS and the sibling cubes teach about **guarded transitions** themselves?

## Main local judgment

Treat the companions as constitutional pressure again,
not as noun donors.
The strongest local lesson is that Helm should keep guarded acts **exact, veto-first, family-bounded, and recovery-typed**.
That supports warming **precondition strips + cutover proofs**.

## What each nearby datacube teaches here

### SlopOS
SlopOS is the strongest direct teacher in this pass because it already has a narrow precondition posture.
Its ACP precondition witness work insists that preconditions are **veto-only exact witness gates**,
not ambient queries,
not `latest` lookups,
and not a second policy engine.
That is almost a ready-made constitutional rule for Helm.
A precondition strip should say what exact witness an act depends on,
then fail closed when it no longer matches.

### Schell
Schell keeps anchor death,
cursor expiry,
and reset-scope humility separate.
For guarded acts,
that means a broken guard should not collapse into generic retry language.
It should stay typed:
refresh basis,
continue with new anchor,
or full restart.

### ViewFS
ViewFS keeps packets,
parsers,
diagnostics,
receipts,
roots,
handles,
and later publication on visibly different seams.
That argues against one giant generic cutover object.
A cutover proof should stay tied to the exact family in motion:
publish,
rebind,
move,
commit,
or session finalize.

### Ward
Ward's read cuts,
staleness budgets,
and revalidation fences reinforce the idea that guards should bind to exact review cuts,
not ambient currentness.
That makes precondition strips especially natural for Recall and Object Browser.

### Steward
Steward's concurrency caps,
adaptation honesty,
and repair narrowness keep teaching the same lesson:
recovery verbs matter.
`failed closed`,
`lost race`,
`target disappeared`,
and `restart required` are not the same thing.

### Harbor and Foundry
Harbor's route humility and Foundry's adoption humility both argue that crossing a boundary under guard is still weaker than durable later effect.
That is why cutover proofs should remain distinct from settlement witnesses.

## What Helm should keep from old inspirations

Keep:
- exact witness basis;
- weak-vs-strong truth classes;
- tiny typed cards instead of one center;
- explicit mismatch / conflict / reset classes;
- distinct stage / commit / receipt / settlement truth;
- careful audience and locality discipline.

Drop or keep warm only:
- any temptation to build a universal transaction center;
- any hidden query language under shell guards;
- any comfort language that flattens veto,
race,
and restart into `try again`.

## Pillar pressure

This seam is cross-pillar,
but it is most valuable now in:
- **Object Browser**, where publish / replace / move / materialize acts need exact no-clobber and exact-current guards;
- **Operations Center**, where scale / promote / land acts need current-attempt or current-version guards;
- **Exchange**, where staged bytes,
  missing ranges,
  guarded commits,
  and restart-required upload aftermath must stay visibly distinct;
- **Recall**, where remembered basis should not silently become live mutation authority.

## Product judgment

Helm still does not need another pillar.
It also still does not need one universal transaction or mutation center.

But the local cube family now supports one narrower move:
make guarded acts explicit about what exact basis they depend on,
and preserve whether the crossing succeeded under guard,
failed closed,
raced,
or now needs a stronger restart.
