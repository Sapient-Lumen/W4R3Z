# SlopOS + companions evaluation — 2026-03-22 — pass LXXXIV

Purpose: re-read the uploaded SlopOS, Schell, ViewFS, and Steward bundles with one tighter question:
**what should Helm learn now about change cursors, safe retries, and teardown honesty?**

## 1. SlopOS keeps teaching that exact evidence must stay smaller than live truth

SlopOS is still the hardest teacher here.
Its lease-descriptor posture keeps saying the same durable thing:
issued evidence is not current-live state.
That rule transfers directly to Helm's next move.

A **change cursor** should be:
- exact evidence of what was last seen,
- or an exact resume point for a change stream,
- but not a universal “still current now” oracle.

That is the key lesson to steal.
Do not make mutable-source optimism look like live certainty.

## 2. SlopOS also keeps proving that seam growth should be budgeted before it becomes folklore

The boundary-family discipline in SlopOS keeps pushing one excellent design instinct:
name the seam,
close the variants,
and make widening explicit.

That is useful for both new support moves in this pass.
A retry key should not silently widen into a hidden job scheduler.
A teardown rail should not silently widen into a giant lifecycle engine.
Both should stay compact shell seams with visible limits.

## 3. ViewFS is the clearest teacher for teardown honesty

ViewFS keeps splitting requests,
selections,
grants,
binds,
loans,
recalls,
expiry,
and receipts into separate seams.
That separation makes one point hard to ignore:
**requesting removal is not the same thing as disappearance.**

Helm should steal that law for destructive or narrowing acts.
When something is being revoked,
detached,
retired,
or unpublished,
the shell should be able to keep a visible pending-teardown object until the blockers clear.

## 4. Steward keeps the chrome lesson: blocked teardown must read like truth, not a mystery

Steward's strongest enduring lesson is still humble chrome.
Labels and cards should orient,
not flatter.
That matters a lot for teardown.

If Helm grows teardown rails,
Operations and Browser should show:
- what is pending,
- what exact dependents or cleanup conditions are blocking,
- whether a force path exists,
- and what exactly will remain afterward.

That is much better than a pretty spinner and much better than disappearing the object too early.

## 5. Schell keeps warning against over-growing the meaning floor

Schell is still design-phase,
which makes its restraint useful.
The lesson here is not to invent a new giant noun.
It is to add three smaller witnesses:
- one for mutable-source progress,
- one for safe retry identity,
- one for pending teardown truth.

That fits the treaty Helm already has with Schell:
smaller native meaning floor,
more explicit witnesses,
and fewer magical transitions.

## 6. The design-phase lesson now

Because SlopOS and Schell are still in design phase,
Helm should freeze **laws of honesty** more quickly than it freezes giant family machines.
This pass suggests three such laws:

1. last-seen or resume-from evidence is weaker than current-live truth
2. retrying a strong act should preserve same-act identity or fail visibly
3. teardown request and teardown completion should stay separate states

## 7. Best next Helm proof slices after this pass

- one linked view or watched source with a visible change cursor and changed-since posture
- one warrant-backed stronger act that can be retried safely with one visible retry key and one deduplicated receipt path
- one revoke / detach / remove case that enters a pending teardown rail with blocker rows instead of vanishing instantly
- one blocked teardown case that points to the exact dependent object keeping removal incomplete
- one expired/unusable cursor case that demands refresh or rebind instead of bluffing latestness

## Judgment

The companion cubes are still most useful when they teach **discipline under ambiguity**.
This pass says Helm should get better at three kinds of ambiguity in particular:
- mutable-source drift,
- retry uncertainty,
- and cleanup-before-disappearance.

The right response is not a bigger constitution.
It is three smaller shell-owned witnesses:
**change cursors,
retry keys,
and teardown rails.**
