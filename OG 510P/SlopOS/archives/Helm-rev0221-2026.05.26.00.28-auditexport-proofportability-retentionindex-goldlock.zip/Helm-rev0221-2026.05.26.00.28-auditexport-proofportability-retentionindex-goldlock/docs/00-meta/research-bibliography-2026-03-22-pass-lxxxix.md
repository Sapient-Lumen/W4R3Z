# Research bibliography — 2026-03-22 — pass LXXXIX

Used in this pass.

1. Kubernetes — Leases
   - URL: https://kubernetes.io/docs/concepts/architecture/leases/
   - used for: node-heartbeat use of Lease objects and the idea that `renewTime` is the current-live witness for availability

2. Kubernetes — Coordinated Leader Election
   - URL: https://kubernetes.io/docs/concepts/cluster-administration/coordinated-leader-election/
   - used for: explicit expiry rule `current time > renewTime + leaseDurationSeconds`

3. systemd — sd_notify
   - URL: https://www.freedesktop.org/software/systemd/man/latest/sd_pid_notify_with_fds.html
   - used for: `WATCHDOG=1`, `WATCHDOG=trigger`, and `EXTEND_TIMEOUT_USEC=` as explicit renewal / timeout-extension posture

4. IETF — RFC 9111: HTTP Caching
   - URL: https://www.rfc-editor.org/rfc/rfc9111.html
   - used for: fresh-versus-stale grammar, `max-age`, and `must-revalidate`

5. IETF — RFC 5861: HTTP Cache-Control Extensions for Stale Content
   - URL: https://www.rfc-editor.org/rfc/rfc5861.html
   - used for: `stale-while-revalidate` as a weaker-but-explicit served-stale posture

6. Android Developers — Explain access to more sensitive information
   - URL: https://developer.android.com/training/permissions/explaining-access
   - used for: Privacy Dashboard timelines and current microphone/camera indicators

7. Apple Support — Control access to the microphone on Mac
   - URL: https://support.apple.com/guide/mac-help/control-access-to-the-microphone-on-mac-mchla1b1e1fe/mac
   - used for: microphone indicator that shows when the microphone is in use or has been used recently

8. Apple Support — What’s in the menu bar on Mac?
   - URL: https://support.apple.com/guide/mac-help/whats-in-the-menu-bar-mchlp1446/mac
   - used for: menu-bar privacy indicators and the distinction between current use surfaces and nearby review surfaces

9. Microsoft Support — Windows camera, microphone, and privacy
   - URL: https://support.microsoft.com/en-us/windows/windows-camera-microphone-and-privacy-a83257bc-e990-d54a-d212-b5e41beba857
   - used for: current camera/microphone indicators plus permission review and detected-app history posture
