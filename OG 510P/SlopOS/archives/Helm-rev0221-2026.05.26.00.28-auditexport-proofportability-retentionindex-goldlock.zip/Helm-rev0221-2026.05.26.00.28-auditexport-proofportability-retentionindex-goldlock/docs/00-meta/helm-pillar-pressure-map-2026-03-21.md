# Helm pillar pressure map — 2026-03-21

Purpose: collect the strongest current ideas for Helm by pillar,
without pretending every good idea is already constitutional law.

## Global judgment

The seven pillars still look right.
The biggest opportunity now is **not more pillars**.
It is stronger shell-owned objects and better truth-bearing cross-cuts.

The current high-value cross-cuts are:
- saved view objects
- deck/deck-like layouts
- basis stamps
- checkpoint / fork / restore
- publication ladders
- lineage modes
- fork receipts
- personal / shared / published accelerator tiers
- command docks
- preview promotion ladders

## 1. Tiling Shell

### Keep from the old inspirations
- i3-grade placement discipline
- keyboard-first navigation
- overview / split / adjacent inspection as native shell moves

### Great current pressure to steal
- Arc-style **Peek → open tab / split view** promotion
- PowerToys-style **persistent dock bands** on a screen edge
- Warp / Obsidian-style **saveable layouts** that can be recalled without pretending they are still live
- WezTerm / Warp-style **launchable session structures**

### Best Helm translation
- command docks as persistent shell-owned bands
- peek surfaces that can promote into split/focus/open
- saved layout objects that stay visibly weaker than live state
- exact visible witness when a saved layout becomes a fresh materialization,
  a repaired reuse,
  or an exact reattachment

### Resist
- pure window-management religion
- layout files pretending to be continuity proof
- pinned strips that quietly acquire ambient privilege

## 2. Omnibox

### Keep from the old inspirations
- Rofi-grade summon speed
- typed pivots instead of one giant undifferentiated search bucket

### Great current pressure to steal
- Spotlight-style **action-first invocation**
- Spotlight-style **quick keys** for repeated actions
- Warp session search by prompt / running command / status
- Notion / Airtable / Obsidian style **view objects** as summonable subjects

### Best Helm translation
- exact action keys and quick mnemonics
- provider pivots for object / action / route / recall / exchange
- preview-first result items with bounded next actions
- result identities that stay stable enough to compare,
  route,
  pin,
  or promote

### Resist
- one giant mixed result list
- omnibox results pretending that request,
  preview,
  and live completion are the same thing

## 3. Object Browser

### Keep from the old inspirations
- Dolphin-grade browsing power
- saved views,
  query views,
  preview,
  and strong bulk actions

### Great current pressure to steal
- Notion **views as first-class resources**
- Notion **dashboard widgets / multi-view layouts**
- Airtable's many view types over one underlying table
- Obsidian Bases as lightweight local-first view definitions
- Quick Look as rich but weaker-than-open preview

### Best Helm translation
- first-class saved view objects
- view decks as small multi-view shells over one subject family
- query result slices that can stay stable long enough for review / pagination / export
- preview rails and exact trails that keep derivation visible

### Resist
- turning the Object Browser into a fake spreadsheet platform
- giant dashboard religion
- path worship as the primary desktop model

## 4. Operations Center

### Keep from the old inspirations
- “god-tier task manager” honesty
- live jobs,
  failures,
  resources,
  and background presence as first-class truth

### Great current pressure to steal
- Warp Session Navigation across live sessions
- VS Code Workspace Trust / Restricted Mode
- VS Code checkpoints and restore
- compare-against-basis surfaces from VS Code / Figma

### Best Helm translation
- searchable activity / job / session inventory
- explicit trust posture for imported,
  untrusted,
  or not-yet-adopted surfaces
- basis-aware restore / fork / compare
- stronger visibility into background candidate work versus adopted live work

### Resist
- process theater without task truth
- hidden background mutation
- approval that silently follows changed mutable state

## 5. Desktop Flow

### Keep from the old inspirations
- AHK-grade leverage
- first-class desktop programming rather than automation as a plugin afterthought

### Great current pressure to steal
- VS Code checkpoint / fork workflows
- Notion programmatic workspace setup instead of static template duplication alone
- Warp launch structures as saved starting points
- Obsidian's split between substrate,
  views,
  and layouts

### Best Helm translation
- branchable flow history
- reusable fragments with status and inspectable innards
- entry kits / deck recipes / launch structures as explicit starters
- materialization bays that show when a recipe became a current live cluster

### Resist
- decorative spaghetti
- giant prefab graveyards
- templates that impersonate live continuity

## 6. Recall

### Keep from the old inspirations
- exact reentry over recent-items folklore
- continuity posture over vague “opened before” memory

### Great current pressure to steal
- VS Code checkpoints and restore
- VS Code forked chat/session branches
- Figma compare-against-history
- Warp session restoration with live-session navigation

### Best Helm translation
- basis-aware checkpoints
- branch/fork from a prior point without overwriting the old path
- exact recency over objects,
  actions,
  routes,
  receipts,
  and source grades
- later compare surfaces that can explain why two paths diverged

### Resist
- one giant timeline religion
- history entries without source / authority grade
- repaired return masquerading as exact return

## 7. Exchange

### Keep from the old inspirations
- typed transfer,
  route awareness,
  and inspectable attach/share/import/export

### Great current pressure to steal
- Airtable share / sync / publish distinctions
- Raycast personal versus shared quicklinks
- Notion duplication versus programmatic setup
- Figma preserve-lineage move versus publish-as-copy

### Best Helm translation
- publication ladders across locality tiers
- lineage modes before the stronger act
- fork receipts after a copy/fork/starter-instantiation
- personal / cross-device / team-shared / published classes for shell accelerators and packets
- residue ledgers so local-only state stops disappearing into mythology

### Resist
- ambient sync folklore
- copy and move decided by vibe
- publication that impersonates receiver-side activation

## Which moves now seem mature enough to prove

### Pull soon
- first-class saved view objects
- command docks
- checkpoint / fork / restore for one narrow Recall or Flow specimen
- personal / shared / published accelerator tiers
- publication ladders plus lineage modes plus fork receipts on one surface family

### Keep warm
- stable query-result tickets for long review / paging flows
- richer deck/dashboard layout law
- adaptive starter generation from higher-level intent
- deeper slotwise carry/reset law across copied decks or entry kits

## Closing judgment

Helm becomes super awesome by doing three things at once:

1. making more shell objects **real**,
2. making more strong moves **explicit**,
3. and making more luxuries **truthful instead of ambient**.

That is the path that keeps the pillars strong while letting the product feel increasingly magical.
