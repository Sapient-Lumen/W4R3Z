# Helm resolution witnesses + closure cards — 2026-03-23

## Why this pass happened

After state tuples,
why rails,
delta briefs,
footing marks,
salience lenses,
coverage witnesses,
quiet witnesses,
delivery witnesses,
disposition witnesses,
revisit witnesses,
commitment witnesses,
and exception witnesses,
Helm still lacked one compact answer to the last practical question:

**how did this tracked thing actually end?**

Not `what changed`.
Not `what did I see`.
Not `what stance did I choose`.
Not `when does it come back`.
Not `what did I promise`.
Not `was an exception active`.

But:
- was it fixed?
- completed?
- duplicated?
- canceled?
- not planned?
- archived?
- resolved in the next release?
- reopened?
- regressed?

That is the missing seam.

## Product judgment

Helm should now admit **resolution witnesses**,
with tiny nearby **closure cards**.

A resolution witness is not:
- the effect receipt
- the source timeline
- the commitment witness
- the exception witness
- the work claim
- or current-live truth

It is the shell-owned compact answer to:
- what exact tracked thing ended?
- by what ending class?
- by whom?
- against what footing or evidence?
- with what successor / duplicate / release / receipt relation?
- and under what reopen or regression law?

## Why this is worth stealing

GitHub keeps close reason typed.
Jira keeps Resolution separate from status.
PagerDuty keeps resolved and reopened distinct while preserving context.
Sentry keeps resolved,
archived,
and regressed separate,
and even supports release-bounded resolution classes.

All of those are better than one flattering `done` badge.

## What Helm should keep

Keep:
- effect receipts as historical action aftermath
- exception witnesses as bypass / waiver / pause truth
- commitment witnesses as promise truth
- wake cards and revisit witnesses as return law

Add:
- **resolution witnesses** for ending truth
- **closure cards** for tiny rendering

## What Helm should refuse

Do not:
- build a generic issue tracker inside the shell
- let `closed` impersonate `fixed`
- let archived / muted posture impersonate resolution
- let `duplicate` sever the trail to the successor object
- let `resolved` impersonate `will never come back`

## Practical effect on Helm surfaces

A good compact surface should increasingly be able to say things like:
- `review request closed • duplicate of release decision`
- `incident resolved • reopen available`
- `bug resolved in next release • regresses if seen again`
- `promise marked met • receipt linked`
- `candidate lane closed • not planned`

That is a better next move than another pillar,
another dashboard,
or another giant memory plane.
