# SlopOS + companions evaluation — 2026-03-23 pass CXLII

## Why this pass happened

The last Helm revision made the strongest adjacent cluster explicit:
**replay capsules, variance cards, compare lanes, and maybe later explicit pinned-share posture.**

This pass asked the next nearby question:
**once Helm can explain a slice, replay it, and compare it, how should it tell the truth about ongoing dependence — who is watching, what drift is acceptable, and when old evidence should become suspect instead of quietly staying green?**

The companion cubes still say the same big thing:
- freeze laws before giant centers,
- keep shell-owned truth stronger than explanation,
- and do not let design-phase convenience harden into fake authority.

## What SlopOS still teaches best

### 1) Family/index discipline matters even more once watch and decay furniture starts multiplying
SlopOS's family maps and singleton discipline matter even more now,
because watch leases,
drift budgets,
distrust bands,
and wake ladders could easily become another folklore maze.

Helm should steal a lighter equivalent before those families rhyme too hard.

### 2) Historical residue is useful, but still weaker than current live truth
SlopOS keeps repeating one excellent lesson:
issued descriptors,
historical receipts,
and provider-local metadata are useful,
but they are not portable current-state oracles.

That transfers directly here.
An old green watch summary,
old replay result,
or old brief should never outrank:
- the exact live source truth,
- the exact current observed basis,
- or the current shell object being acted on.

### 3) Design-phase humility still says: prove one humane watched slice, not a giant observability tower
SlopOS is still design-phase,
and that remains helpful.
The right move is still:
- pin the law,
- add one bounded seam,
- and resist inventing one giant center too early.

Helm should treat watched-slice work the same way.

## What Ward now teaches best

### 1) Watch duty is different from first verification
Ward's recent passes are the sharpest local teacher for this revision.
They keep pressing the idea that:
- first verification,
- later watch duty,
- auditor lag,
- and current spend posture
are different truths.

That maps cleanly into Helm.
A slice can look healthy now,
but still demand later watch,
recheck,
or distrust if the footing ages out.

### 2) Old residue may need distrust, not deletion
Ward's bundle-half-life / distrust-notice pressure is also a great fit.
A once-useful replay result,
shared brief,
or monitored slice may remain inspectable
while still becoming too old to spend through blindly.

That suggests Helm increasingly wants one compact distrust band
rather than only fresh versus stale.

## What Schell still teaches best

### 1) Watch state, wake state, action, and resolution are different truths
Schell keeps insisting that:
- proposal,
- checkpoint,
- execution,
- residue,
- and later return law
stay separate.

That transfers directly here.
A watch breach is not the wake.
A wake is not the action.
An action is not the resolution receipt.

### 2) Separate lanes keep watch UX humane
Schell's lane discipline still matters:
- observed state lane,
- compare lane,
- response lane,
- history lane.

If Helm grows watch leases and distrust bands,
it should keep those lanes explicit instead of hiding them in one super-tile.

## What ViewFS still teaches best

### 1) Basis, drift verdict, reconsent, and renewed artifact are different things
ViewFS remains the sharpest local teacher for the exact-footing side.
A watched slice should be able to keep separate:
- the old reviewed basis,
- the current drift verdict,
- any fresh approval or reconsent,
- and the renewed result.

### 2) Compared bases matter even when the answer is “still green”
ViewFS also keeps pressing the useful distinction between recipe,
basis,
current apply session,
and reconstructed target.

That is a direct warning for Helm:
a current watch summary that says “healthy” still needs revealable footing when people depend on it.

## What Harbor, Foundry, and Steward add

### Harbor
Harbor keeps teaching that route,
visibility,
and authority are separate truths.
A visible watch path or share path should not impersonate ownership or current source authority.

### Foundry
Foundry's check-attachment posture still matters.
Checks,
diff budgets,
and distrust posture should stay attached to the exact reviewed slice or replay result being judged.

### Steward
Steward keeps teaching that discovery,
presence,
and lease-like trust posture should stay explicit.
That is a useful reminder that imported/shared watch definitions should remain inspectable and adoptable rather than silently armed.

## Lessons Helm must learn from the past

### Must learn #1: green now is not green forever
A compact healthy state is useful.
It still needs a visible half-life,
recheck pressure,
or distrust band once people start spending through it.

### Must learn #2: watcher is not owner
Who is watching a slice,
who depends on it,
and who owns source truth are different things.
Helm should not flatten them.

### Must learn #3: quiet is not recovered
Muted,
snoozed,
missing-data,
no-change,
and recovered are different truths.
Helm should keep refusing that convenience collapse.

### Must learn #4: drift budgets are not proof
A threshold or acceptable band is useful.
It is still weaker than exact source truth,
exact result diff,
and later adoption or settlement.

### Must learn #5: old evidence may become suspect without becoming worthless
A watched answer,
shared brief,
or replay result may remain inspectable history
while no longer being safe to act through blindly.

## What Helm should steal now

- a SlopOS-style family/index discipline before watch and distrust families multiply too far
- Ward's watch-duty and distrust-notice humility for old green results
- Schell's lane separation for observed state / wake / response / receipt
- ViewFS basis-versus-drift-versus-renewal texture for watched slices
- Harbor's refusal to let route or visibility impersonate authority
- Foundry's check-attachment posture on budgets and distrust bands
- Steward's lease/adoption humility for imported or shared watch definitions

## Product judgment

Do **not** freeze a giant observability center.
Do **not** freeze a giant governance console.
Do **not** let watch summaries or distrust notices become a second authority plane.

But do keep warming an adjacent cluster around:
- watch leases,
- drift budgets,
- distrust bands,
- and maybe later wake ladders.

That looks like the next best way to make Helm's datacube feel super truthful and super useful
once reviewed slices,
smart decks,
richer evidence briefs,
and replayable results start becoming depended-on shell objects that people must keep watching over time.
