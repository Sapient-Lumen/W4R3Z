# Helm: evidence briefs + curated signals — 2026-03-22

Purpose: name the next compact support move that now looks worth warming after the latest SlopOS reread and current-tool pass.

## Main idea

Helm now has:
- saved view objects,
- linked views,
- exact front-door handles,
- view subscriptions,
- glance derivations,
- watchpoints,
- patrol routes,
- drift beacons,
- basis contrast cards,
- and a weak Overview direction.

What is still missing is one shell-owned object for **bounded curated investigation**.

The right answer now looks like:
- keep the **saved view** as the durable exact source,
- let patrol routes handle repeated rounds,
- let Overview remain a weak landing surface,
- let exact handles stay tiny,
- let watchpoints and glances carry state,
- and add one explicit **evidence brief** for the exact things the operator wants their future self or teammate to inspect.

## 1. What an evidence brief is

An **evidence brief** is a shell-owned bounded collection of exact shell objects plus a little authored or machine-assisted explanation.

Its members might include:
- exact saved views
- exact linked views
- exact watchpoints
- exact glance derivations
- exact review tickets or compare cards
- exact receipts or route witnesses
- exact front-door handles
- one small summary / hypothesis / next-step note

It is stronger than a pile of tabs or a freeform note because it keeps exact source witness.
It is weaker than live authority because it still depends on stronger source objects,
freshness,
and current-live proof.

## 2. Why this now looks necessary

A **patrol route** is a round.
A **watchpoint** is evaluated state.
A **subscription** is delivery.
A **glance derivation** is tiny summary.
An **activity spine** is the wider work frame.
A **handoff packet** is how some things travel.

But Helm still needed a clean object for:
- “these are the five exact signals that explain why I think this matters”
- “capture this investigation without opening a giant notebook product”
- “let AI help gather evidence but land the result in something inspectable and bounded”
- “share the exact trail of evidence without sharing my whole activity spine”
- “turn a watchpoint firing into a compact inspectable brief instead of a notification pile”

That is a real product gap.
Evidence briefs fill it without forcing Helm into dashboard sprawl,
full document-editor culture,
or case-management religion.

## 3. What current tools taught this pass

The outside pattern is now specific enough to steal:
- Grafana Investigations validates collecting interesting signals into one manageable list with annotations, time-range comparison, and easy navigation between items.
- Grafana Assistant Investigations validates an AI mode that gathers evidence in the background and produces a structured report, timeline, and activity log.
- Datadog Notebooks validates live-data-backed investigation documents and reusable templates.
- Datadog Incident Details validates tabbed investigation with properties, signals, documents, notifications, and timeline summaries.
- Elastic Cases validates one place that can gather alerts, evidence, files, comments, and external push/update paths.
- Linear still validates keeping the stronger object as a saved/favorited view underneath the lighter curation layer.

The thing to steal is not “build a notebook suite.”
It is:
**make curation first-class, exact, bounded, and clearly weaker than source truth.**

## 4. What Helm should keep and reject

### Keep
- exact source refs inside every brief
- one weak summary / hypothesis layer above the refs
- visible authored-versus-machine-assisted notes
- easy jump-back-to-source from every brief member
- easy attach to activity spines, patrol routes, and handoff packets
- optional frozen versus freshness-tracking posture

### Reject
- giant freeform notebook sprawl as the default investigation object
- case/workflow-engine law sneaking in under the word “brief”
- AI-generated summaries outranking the collected evidence
- imported/shared briefs silently becoming local live truth
- curation objects pretending they already proved current liveness

## 5. What now looks wise to pull the trigger on

### Pull the trigger now
- **evidence briefs** as candidate shell objects

### Advance with them
- activity-spine membership
- patrol-route stops that can point into or out of a brief
- watchpoint → brief ladders
- brief → handoff packet travel
- manual versus AI-assisted authorship witness

### Keep warm
- templated brief seeds
- brief-to-postmortem export
- one weak “compare time ranges” mode for brief members
- brief-level stakeholder summary cards that stay weaker than the evidence lane

## 6. Why this could make Helm super awesome

This move makes Helm feel like a real desk that can remember **why something matters**,
not just where it lives.

A user could:
- capture a watchpoint firing,
- pull in one saved view,
- add one compare card,
- attach one receipt,
- annotate the likely cause,
- share the bounded brief,
- and still jump back to stronger source truth at every step.

That is better than:
- one giant dashboard,
- one sprawling notebook,
- or one vague “incident” object that silently turns into workflow law.

## Judgment

Helm still does not need another pillar.
It needs one more compact shell object.

The best next move now looks like:
- **evidence briefs**
- plus **bounded curated-signal posture** around exact refs, weak summary, source witness, authorship witness, and easy jump-back-to-source

That gives Helm a better investigation grammar without sacrificing the honesty it has been earning from SlopOS all along.
