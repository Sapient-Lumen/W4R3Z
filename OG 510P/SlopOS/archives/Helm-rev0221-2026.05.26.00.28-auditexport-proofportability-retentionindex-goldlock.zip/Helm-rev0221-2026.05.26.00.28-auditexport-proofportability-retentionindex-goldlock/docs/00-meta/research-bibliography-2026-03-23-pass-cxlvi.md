# Research bibliography — 2026-03-23 pass CXLVI

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-GITHUB-COMPARE-COMMITS-2026E | https://docs.github.com/en/pull-requests/committing-changes-to-your-project/viewing-and-comparing-commits/comparing-commits | explicit `base` / `compare` footing is a strong precedent for exact compared bases in Helm delta briefs |
| REF-GITHUB-PR-REVIEW-2026E | https://docs.github.com/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests | pull-request review stays anchored to explicit diffs between base and compare branches |
| REF-GITHUB-DEPENDENCY-REVIEW-2026E | https://docs.github.com/en/enterprise-server%403.20/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests/reviewing-dependency-changes-in-a-pull-request | rich diffs that summarize added / removed / updated dependencies and their impact are a strong precedent for salience lenses |
| REF-LAKEFS-DIFF-REFS-2026E | https://docs.lakefs.io/v1.74/integrations/python-versioning-branches/ | comparing refs and counting added / removed / modified objects is a strong precedent for exact change briefs |
| REF-FIGMA-REVIEW-BRANCH-CHANGES-2026E | https://help.figma.com/hc/en-us/articles/5693123873687-Review-branch-changes | branch summaries, object-level diffs, and review-again posture are strong precedents for later review windows |
| REF-DBT-DEFER-STATE-2026E | https://docs.getdbt.com/reference/node-selection/defer | comparing against logical state while deferring to a different applied state is a strong precedent for `from` versus serving footing honesty |
| REF-DBT-SOURCE-FRESHNESS-2026E | https://docs.getdbt.com/docs/deploy/source-freshness | compact freshness surfaces backed by stronger source checks are a strong precedent for nearby health/change chrome |
| REF-DBT-DATA-HEALTH-TILE-2026E | https://docs.getdbt.com/docs/explore/data-tile | small embedded health tiles with details/landing pages are a strong precedent for Helm deck-adjacent compact status surfaces |
| REF-DAGSTER-ASSET-VERSIONING-UNSYNCED-2026E | https://docs.dagster.io/guides/build/assets/asset-versioning-and-caching | data-version plus code-version posture and `Unsynced` status are strong precedents for typed changed axes |
| REF-DATAFOLD-DATA-DIFF-MONITORS-2026E | https://docs.datafold.com/data-monitoring/monitors/data-diff-monitors | row/column discrepancy summaries plus scheduling/notifications are strong precedents for typed difference briefs |
| REF-CUBE-QUERY-HISTORY-2026E | https://cube.dev/docs/product/administration/workspace/query-history | serving-path history and acceleration truth are strong precedents for explaining why a visible answer feels different |
| REF-CUBE-PREAGG-HISTORY-2026E | https://cube.dev/docs/product/administration/workspace/pre-aggregations | build history, used-by, and preview posture are strong precedents for inspect exits from compact change chrome |
