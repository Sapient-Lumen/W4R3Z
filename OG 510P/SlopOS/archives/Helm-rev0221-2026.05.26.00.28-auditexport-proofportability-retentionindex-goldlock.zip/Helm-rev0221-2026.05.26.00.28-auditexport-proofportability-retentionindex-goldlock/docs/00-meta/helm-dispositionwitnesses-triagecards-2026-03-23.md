# Helm disposition witnesses + triage cards — 2026-03-23

## Why this pass exists

After state tuples,
why rails,
delta briefs,
footing marks,
salience lenses,
coverage witnesses,
quiet witnesses,
and delivery witnesses,
Helm can now say a lot about a surfaced thing.

But it still lacked one small answer to a very human question:

**what did I decide to do about it?**

That answer should not be hidden in:
- a read cursor
- a delivery witness
- a work claim
- a response kit
- a team assignment
- or the underlying source status

It needs its own compact shell-owned truth object.

## Main judgment

Helm should now admit **disposition witnesses**,
with tiny nearby **triage cards**.

A disposition witness is not:
- the source truth
- the delivery witness
- the current-live beacon
- the work claim
- the response kit
- the final outcome
- or an ambient notification-center archive

It is the exact answer to:
- what stance was chosen for this surfaced subject?
- by whom or by what lane?
- under what return/expiry conditions?
- and what stronger next object,
  if any,
  was bound as the consequence of that stance?

## Why this matters for Helm's pillars

### Overview
Overview can now stay weak but still say:
- `review drift observed • saved for later`
- `candidate change • delegated to release lane`
- `triage item • declined for this lane`

without pretending those are live-source outcomes.

### Recall
Recall can explain not just what changed,
but what stance was last chosen:
- `last seen and snoozed until tomorrow`
- `accepted into team triage`
- `duplicate of existing issue`

### Operations Center
Ops rows can stop flattening:
- read
- acknowledged
- queued-for-work
- delegated
- resolved

into one pseudo-handled badge.

### Omnibox / Object Browser
Helm can offer exact next-step verbs like:
- accept
- decline
- duplicate-into
- delegate-to
- queue-behind
- bind-response-kit
- unsubscribe
- snooze-until

without assuming the subject itself changed yet.

## What Helm should steal

- GitHub's typed inbox triage
- Slack's read-versus-clear distinction
- Linear's triage verbs and snooze/until-new-activity posture
- PagerDuty's explicit acknowledgement / reassign / snooze / resolve action family

## What Helm should refuse

- one giant notification center mythology
- one handled bit
- letting a triage stance impersonate source truth
- letting acknowledgement impersonate repair
- letting delegation impersonate adoption
- letting acceptance impersonate current touch

## Pull-the-trigger conclusion

The next good Helm move is not another pillar.
It is one more cross-pillar ratchet:

**delivery truth tells you what happened in attention.
Disposition truth tells you what stance was chosen afterward.
Outcome truth stays elsewhere.**
