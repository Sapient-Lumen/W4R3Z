# Research bibliography — 2026-03-21 pass XXIII

Official/public sources consulted in this pass:

- VS Code Docs — Profiles in Visual Studio Code  
  https://code.visualstudio.com/docs/configure/profiles
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- VS Code Docs — Revert changes with checkpoints and editing requests  
  https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Microsoft Learn — Adding Dock support to your extension  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/adding-dock-support
- Airtable Support — Using the view share menu in Airtable  
  https://support.airtable.com/docs/using-the-view-share-menu-in-airtable
- Notion Help — Using database views  
  https://www.notion.com/help/guides/using-database-views
- Notion Help — Database templates  
  https://www.notion.com/help/database-templates
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Shared Quicklinks  
  https://manual.raycast.com/quicklinks/shared-quicklinks
- Raycast Manual — Deeplinks  
  https://manual.raycast.com/deeplinks
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- Obsidian Help — Workspaces  
  https://help.obsidian.md/plugins/workspaces
- Obsidian Help — How Obsidian stores data  
  https://help.obsidian.md/data-storage
- Obsidian Help — Sync settings and selective syncing  
  https://help.obsidian.md/sync/settings
- Obsidian Help — Web viewer  
  https://help.obsidian.md/plugins/web-viewer
- Figma Help — Compare changes in Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023193382935-Compare-changes-in-Dev-Mode
- Figma Help — Guide to Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Figma Help — Explore component properties / component playground  
  https://help.figma.com/hc/en-us/articles/5579474826519-Explore-component-properties
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Arc Help Center — Peek: Preview Sites From Pinned Tabs  
  https://resources.arc.net/hc/en-us/articles/19335302900887-Peek-Preview-Sites-From-Pinned-Tabs
