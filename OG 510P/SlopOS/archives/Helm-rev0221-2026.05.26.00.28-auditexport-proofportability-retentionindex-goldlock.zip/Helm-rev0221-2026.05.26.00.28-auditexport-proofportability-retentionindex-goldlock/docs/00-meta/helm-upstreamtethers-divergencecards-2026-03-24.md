# Helm — upstream tethers and divergence cards

## Current judgment

Do **not** add a new pillar.
Do **not** freeze one universal branch/sync manager.
Do **not** let local adoption erase the relation to origin.

The strongest next move is smaller:
**warm upstream tethers + divergence cards as the shell-owned seam after floor grafts and adoption receipts.**

Helm can already say:
- what footing crossed a seam,
- what the receiver could verify,
- what local slice was grafted,
- and what adoption receipt proves that local floor now exists here.

What it still answers too weakly is:
- **what origin or mainline is this local floor still tethered to?**
- **is the local floor in sync, ahead, behind, diverged, detached, or origin-lost?**
- **what exact next verbs exist now: review upstream, take upstream, merge/reconcile, detach, rebind, or archive the tether?**

## The lesson Helm must learn from the past

Past systems keep replaying a follow-source mistake:
**they make imported or locally adopted state feel self-explanatory, then hide whether it is still tracking anything real.**

That creates spooky shell behavior:
- a local deck was adopted here, but the shell no longer says whether it still tracks the source it came from;
- a local branch is clearly *different*, but the shell does not say whether it is ahead, behind, or truly diverged;
- a carried floor became local working truth, then later origin updates exist, but the shell still looks calm and current because adoption erased lineage posture.

Helm should refuse the myth that `adopted here` means `self-sufficient forever`.

## What the outside world is teaching right now

### Git: upstream relation is explicit, and divergence posture is first-class
Git keeps remote-tracking branches, local tracking branches, and the local current branch visibly distinct.
A local branch can be configured to track an upstream branch.
Status can then show whether the local branch is ahead, behind, or both.
Git also lets the operator explicitly set or unset upstream.
That is a strong Helm precedent:
**local adoption should still be able to name an upstream tether, and divergence posture should stay inspectable.**

### Figma: branch work can stay exploratory while updates from main remain explicit
Figma branches start as an exact replica of main.
If main changes, the branch is told updates are available.
The operator can review and apply updates from main, and merge later through a compare surface.
That suggests a second Helm rule:
**a local adopted floor can still stay visibly downstream from another mainline without becoming weak or fake.**

### Kubernetes Server-Side Apply: collaboration means explicit ownership and explicit conflicts
Kubernetes managed fields show that multiple actors can still share or transfer ownership over the same object fields.
Conflicts are explicit instead of silently flattened.
That pressures Helm toward a similar idea:
**an upstream tether does not mean the local floor has no local authority; it means the shell keeps lineage and conflict posture explicit.**

## What the companion cubes are teaching now

### Keep from SlopOS
Keep provider-locality and anti-ambient-authority discipline.
An upstream tether should be a shell-owned relation,
not a hidden promise that the source provider is continuously authoritative inside Helm.

### Keep from Ward
Ward's read cuts and revalidation fences say divergence must bind to one exact compared cut.
`behind` and `diverged` should not be vibes.
They should stand on one named compare basis.

### Keep from Schell
Schell keeps strongest-next-verb pressure honest.
That is excellent here:
- if upstream still exists and only local changes differ,
  maybe the right next verb is `review upstream`;
- if origin is gone,
  maybe the right next verb is `detach` or `rebind`;
- if the relation died,
  Helm should say so.

### Keep from ViewFS
ViewFS is still the best teacher for keeping remembered designators,
current handles,
continuity lockers,
and durable receipts distinct.
An upstream tether should stay like a named relation from local footing to an origin footing,
not collapse into either the current live handle or the adoption receipt.

### Keep from Steward
Steward's observation cursor and continuity-escrow pressure says there is value in keeping `what I can continue from` different from `what I am currently attached to` and different again from `what I have durably adopted`.
That fits perfectly here.

## Bright steals for Helm

1. **Upstream tether**
   - one explicit relation from a local adopted floor to an origin/mainline it still tracks,
     shadows,
     mirrors,
     or follows by review.
2. **Divergence card**
   - one compact shell card showing `in sync`, `ahead`, `behind`, `diverged`, `detached`, `origin-lost`, or `unknown-unchecked`.
3. **Rebind / detach verbs**
   - the shell should not force tracking forever.
4. **Compare-before-take from upstream**
   - follow-source updates should reopen one compared basis rather than silently rewriting local meaning.
5. **Selective local authority with visible lineage**
   - local adoption can be real and still remain visibly downstream of some origin.

## What not to keep

Do not keep:
- one giant universal branch manager,
- one automatic follow-source rule for every adopted object,
- or one claim that local adoption settles all future lineage questions.

Keep the shell grammar small:
one tether,
one divergence card,
and one explicit detach / rebind / review-upstream set of verbs.

## Why this makes Helm super awesome

This is the premium move that keeps local work powerful **without** making lineage spooky.
A person can ask:
- `what is this local floor still tethered to?`
- `am I ahead, behind, or diverged from origin?`
- `did origin move while this local floor stayed valid here?`
- `can I take upstream now, or must I review and reconcile first?`
- `is this now detached on purpose, or did the tether die?`

That is better than a bigger cube.
Not because Helm promises one branch universe,
but because it keeps **local adoption, upstream relation, and divergence posture** visibly different.
