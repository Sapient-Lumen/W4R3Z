# Helm settlement witnesses + commit cards — 2026-03-23

## Why this pass happened

After **headroom witnesses**,
Helm could say:
- who has the baton now
- what signoff threshold still stands
- what budget or quota still applies

But it still lacked one humane operator answer:

**once an act returns,
what exact settlement class do I actually have — merely accepted,
locally durable,
quorum durable,
replicated,
receiver-visible,
or still pending?**

That gap appears across:
- apply / publish / export / replicate acts
- branch adoption or lane promotion where success may precede stronger shared visibility
- multi-target distribution where one destination lags or fails
- remote materialization where local receipt exists but receiver adoption remains unknown
- primary-only or local-durable success that is weaker than quorum or replica durability
- historical success that should not license source deletion or stronger claims yet

## Product judgment

The next narrow trigger is now worth pulling:

- keep the seven pillars stable
- do not add a new pillar
- keep **authority windows** for permission / grant truth
- keep **quorum witnesses** for signoff-threshold truth
- keep **headroom witnesses** for spendability truth
- promote **settlement witnesses** as the shell-owned compact answer to `what exact durability / replication / receiver-visibility class exists after this act?`
- promote **commit cards** as the tiny nearby rendering for that settlement truth

A settlement witness answers:
- exact subject,
  act,
  receipt,
  route,
  or cohort scope
- exact settlement class:
  accepted,
  locally durable,
  journaled,
  quorum durable,
  replicated,
  receiver-visible,
  settlement failed,
  or unknown
- exact destinations / replicas / receivers still pending
- whether the current class is strong enough for the next move the user is considering
- whether it is still unsafe to retire the source or claim wider success
- and what exact next move is honest:
  wait,
  inspect lag,
  re-drive,
  widen durability,
  or downgrade the claim

A commit card answers that truth in one small human-facing form.

## Why this is worth stealing

The current official pressure is unusually clean:

- MongoDB keeps primary-only,
  journaled,
  and majority-durable write acknowledgment distinct
- Kafka keeps `acks=0`,
  `acks=1`,
  `acks=all`,
  and `min.insync.replicas` interplay explicit
- Amazon S3 keeps replication `PENDING`,
  `COMPLETED`,
  `FAILED`,
  and `REPLICA` explicit,
  including multi-destination completeness

Those systems feel humane because they distinguish **accepted truth**,
**durability truth**,
**replication truth**,
and **receiver-visible truth**.

## Lessons Helm must learn from the past

- `success` is too flattering if the product hides whether the effect is only accepted.
- `written` is too flattering if the product hides whether the write is only local.
- `published` is too flattering if cross-destination settlement is still pending.
- `replicated` is too flattering if receiver visibility or adoption is unconfirmed.
- `safe to clean up source` is too flattering if settlement is not complete.
- the right shell magic is not hiding these stages;
  it is making the current settlement class and honest next move obvious at a glance.

## What Helm should keep

Keep:
- effect receipts for bounded historical aftermath
- current-live beacons for present serving / current-live truth
- headroom witnesses for spendability truth
- quorum witnesses for signoff-threshold truth
- reality strips,
  Overview,
  Recall,
  and Operations Center as weak projection surfaces

Add more clearly:
- **settlement witnesses** near apply / publish / materialize / transfer / adopt rails
- **commit cards** near Overview tiles,
  Recall return points,
  reality-strip slots,
  and Operations Center rows where one act returned but stronger settlement is still pending

## What Helm should refuse

Do not:
- build a giant replication center first
- flatten accepted,
  journaled,
  quorum durable,
  replicated,
  receiver-visible,
  and failed into one `succeeded` badge
- let old success receipts imply current settlement strength
- let source retirement or cleanup outrun settlement truth
- let receiver adoption pretend to be proven when only source-side success is known

## Practical effect on Helm surfaces

A good compact Helm surface should increasingly be able to say:
- `apply accepted • quorum commit pending`
- `journaled locally • replica lagging`
- `majority durable • receiver visibility unknown`
- `published to 2/3 targets • keep source`
- `receipt exists • settlement class historical only`
- `copied local • remote durable unknown`

That is a better next move than another pillar,
another replication dashboard,
or another flattering `done` story.
