# Helm service covenants / breach rhythms — 2026-05-18

## Core move

rev0199 adds **service covenants** after obligation ledgers.

An obligation says who owes a piece of follow-through. A service covenant says which bounded operating promise is now being kept, at risk, paused, breached, or observed because of those obligations. The new object deliberately refuses the easy product lie: a single health score, green badge, or aggregate percentage cannot make a breached promise disappear.

## Why this matters

Helm is becoming powerful enough to generate many correct rows: exceptions, due work, settlements, receipts, warnings, and route candidates. Without a covenant layer, users will either drown in rows or ask for one comforting score. The covenant layer gives them the middle path: named promises with evidence windows, breach triggers, repair cadence, owner, and visible degradation.

## Pull the trigger

Pull the trigger on:

- `service_covenant` as a candidate proof-fixture object after obligation ledgers;
- named covenant postures: kept, at_risk, breached, paused, observing, and retired;
- navigation-only covenant rollups that cannot hide a single breached covenant;
- breach/repair rhythm fields before any SLO, scorecard, alerting, or ticketing platform;
- visible copy that explains the promise and what it is not authority for.

Do **not** pull the trigger yet on SLO engine, scorecard engine, service catalog, ownership registry, alerting/incident platform, ticketing/workflow engine, policy engine, backend, semantic layer, table format, or new pillar.

## Helm-specific phrasing

A service covenant is not a dashboard score. It is a **truth-bearing promise card** in Helm's datacube. It can project to a health tile, alert rule, ticket, on-call wake, or service catalog later, but those projections stay smaller than the covenant record.

## Old inspirations worth keeping

Keep:

- health tiles that confess source obligations;
- owner chips that open accountable due work;
- publish previews that show breach impact before consequence;
- patrol routes that revisit covenant promises on a cadence;
- review queues that treat a breached covenant as a reason to inspect, not a reason to panic.

Drop or demote:

- universal green/yellow/red health as authority;
- aggregate percentages that hide the one breached promise;
- scorecard gamification before proof;
- ambient owner inference;
- alert noise that does not open the source obligation and evidence window.
