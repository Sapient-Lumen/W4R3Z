# Research bibliography — 2026-03-22 — pass LXXX

Sources consulted for this pass.

## Exact remembered handles / file-scoped access

- Apple Developer Documentation — *Enabling Security-Scoped Bookmark and URL Access*
  - https://developer.apple.com/documentation/professional-video-applications/enabling-security-scoped-bookmark-and-url-access
- Apple Developer Documentation — *Using Bookmark Data*
  - https://developer.apple.com/documentation/professional-video-applications/using-bookmark-data?language=objc
- Apple Developer Documentation — *Protecting user data with App Sandbox*
  - https://developer.apple.com/documentation/security/protecting-user-data-with-app-sandbox
- Chrome for Developers — *The File System Access API: simplifying access to local files*
  - https://developer.chrome.com/docs/capabilities/web-apis/file-system-access
- Chrome for Developers — *Persistent permissions for the File System Access API*
  - https://developer.chrome.com/blog/persistent-permissions-for-the-file-system-access-api
- Google for Developers — *Display the Google Picker*
  - https://developers.google.com/workspace/drive/api/guides/picker
- Google for Developers — *Choose Google Drive API scopes*
  - https://developers.google.com/workspace/drive/api/guides/api-specific-auth
- Google Workspace Developers Blog — *New file picker method for pre-selecting Google Drive files coming soon*
  - https://workspaceupdates.googleblog.com/2024/11/new-file-picker-method-for-pre-selecting-google-drive-files.html
- Google for Developers — *Scopes | Google Workspace add-ons*
  - https://developers.google.com/workspace/add-ons/concepts/workspace-scopes

## Constrained helper lanes / sandboxing / permission modes

- Claude Code Docs — *Configure permissions*
  - https://code.claude.com/docs/en/permissions
- Claude Code Docs — *Sandboxing*
  - https://code.claude.com/docs/en/sandboxing
- Anthropic Engineering — *Beyond permission prompts: making Claude Code more secure and autonomous*
  - https://www.anthropic.com/engineering/claude-code-sandboxing

## Named protection gates / scoped installs

- AWS Documentation — *Update CloudFormation stacks using change sets*
  - https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-changesets.html
- GitHub Docs — *Deployments and environments*
  - https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments
- GitHub Docs — *Reviewing deployments*
  - https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/review-deployments
- GitHub Changelog — *Required reviewer rule is now generally available*
  - https://github.blog/changelog/2026-02-17-required-reviewer-rule-is-now-generally-available/
- GitHub Docs — *Authorizing GitHub Apps*
  - https://docs.github.com/en/apps/using-github-apps/authorizing-github-apps

## Previously reaffirmed companion ideas still carrying pressure

- VS Code — *Workspace Trust*
  - https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- Chrome for Developers — *The `activeTab` permission*
  - https://developer.chrome.com/docs/extensions/develop/concepts/activeTab
- Android Developers — *Grant partial access to photos and videos*
  - https://developer.android.com/about/versions/14/changes/partial-photo-video-access
- Figma Help Center — *Guide to branching* and *Request a branch review*
  - https://help.figma.com/hc/en-us/articles/360063144053-Guide-to-branching
  - https://help.figma.com/hc/en-us/articles/5691414603543-Request-a-branch-review
- Linear Docs — *Triage* and *Triage Intelligence*
  - https://linear.app/docs/triage
  - https://linear.app/docs/triage-intelligence
- Tailscale Docs — *Funnel* and *Funnel vs. sharing devices*
  - https://tailscale.com/docs/features/tailscale-funnel
  - https://tailscale.com/docs/reference/funnel-vs-sharing
- Terraform CLI docs — *plan*
  - https://developer.hashicorp.com/terraform/cli/commands/plan
