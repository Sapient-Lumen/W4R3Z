# Research bibliography — 2026-03-23 pass CIII

## Primary references used in this pass

- Google Cloud IAM — *Create a downscoped short-lived credential*
  - why it matters: shows upper-bounded delegation,
    token broker / token consumer split,
    and non-amplifying downscoping

- AWS IAM / STS — *Compare AWS STS credentials*
  - why it matters: session permissions are the intersection of base identity policy and session policy

- GitHub Docs — *Managing your personal access tokens*
  - why it matters: fine-grained PATs show owner scoping,
    repo scoping,
    explicit permission selection,
    optional approval,
    and expiration

- GitHub Docs — *Managing deploy keys* / installation token guidance
  - why it matters: installation access tokens are tightly scoped and short-lived

- GitHub Docs — *Token expiration and revocation*
  - why it matters: expired or revoked tokens are dead,
    and exposed tokens can be revoked to limit impact

- Android Developers — *Request runtime permissions*
  - why it matters: ties permission asks to specific user actions,
    requires checking at time of use,
    and encourages graceful degradation

- Android Developers — *Permissions updates in Android 11*
  - why it matters: one-time permissions,
    auto-reset,
    and discouraging repeated nag prompts

- Apple archive docs — *Enabling App Sandbox*
  - why it matters: capability restoration through explicit entitlements,
    user-selected file access,
    and security-scoped bookmark posture

- MDN — *User activation*
  - why it matters: strong web actions keep fresh/direct user mediation distinct from background preparation

- MDN — *FileSystemHandle.requestPermission()*
  - why it matters: permissions remain explicit and stateful even after a handle exists

## Local companion texts reread this pass

- SlopOS RFC-0066 capability leases and limited-use proxies
- SlopOS RFC-0081 activation, handle handoff, and stable service handles
- SlopOS lease-descriptor state boundary
- SlopOS UI automation lease schema
- ViewFS object identity / recents / reveal note
- ViewFS query manifest / snapshot / live feed note
- Schell RFC 0004 and RFC 0005 on smallest reviewed action
- Steward chrome-lane posture and action-surface posture

## Pass judgment

This pass strengthens the case that Helm should add one compact helper-delegation object before it adds bigger helper machinery.
The best laws are downscope,
intersection,
expiry,
exact subject binding,
and preserving the final human seam.
