# Research bibliography — 2026-03-23 — pass CI

- Apple Developer documentation — Live Activities / ActivityKit / `staleDate` / `ActivityState.stale`
  - used for: glanceable current-state surfaces that still carry explicit staleness and decay posture
- Android Developers — privacy indicators, Privacy Dashboard, and permission-usage rationale APIs
  - used for: separating live sensitive use from recent-use history and explanation surfaces
- GitHub Docs — status checks
  - used for: separating in-progress `status` from final `conclusion`
- GitHub Docs — saved views on issues / pull request dashboards
  - used for: stale-aware saved monitoring views that remain weaker than live work objects
- Kubernetes documentation — Pod Lifecycle / Pod conditions
  - used for: multi-axis status grammar and explicit warning against over-reading one high-level state summary
- Microsoft Learn — Windows Terminal shell integration
  - used for: semantic prompt/command/output/exit metadata instead of transcript scraping
- iTerm2 documentation — Status Bar
  - used for: tiny persistent surfaces showing up-to-date environment information
- Microsoft Learn — PowerToys Command Palette Dock
  - used for: persistent edge toolbar / dock-band validation for tiny shell-owned chrome
- Microsoft Learn — PowerToys Workspaces
  - used for: saved launch/layout structure remaining weaker than live continuity
