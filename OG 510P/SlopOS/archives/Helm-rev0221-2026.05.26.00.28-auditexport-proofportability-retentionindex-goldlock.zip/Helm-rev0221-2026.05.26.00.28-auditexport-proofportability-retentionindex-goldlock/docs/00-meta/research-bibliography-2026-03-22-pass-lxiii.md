# Research bibliography — 2026-03-22 — pass LXIII

1. Grafana documentation — Configure mute timings and active time intervals
   - URL: https://grafana.com/docs/grafana/latest/alerting/configure-notifications/mute-timings/
   - used for: recurring quiet periods, active-only intervals, and explicit distinction from silences; strongest evidence that suppression can leave evaluation intact

2. Datadog documentation — Downtimes
   - URL: https://docs.datadoghq.com/monitors/downtimes/
   - used for: scope-by-monitor/tag/group and preview-affected-targets posture before broad quieting

3. PagerDuty support — Maintenance Windows
   - URL: https://support.pagerduty.com/main/docs/maintenance-windows
   - used for: explicit maintenance window state, current/future/past visibility, end-now/update posture, and distinction from disabling a service indefinitely

4. Android Developers — Create and manage notification channels
   - URL: https://developer.android.com/develop/ui/views/notifications/channels
   - used for: per-channel interruption behavior and user-owned final control over visibility/intrusiveness

5. XDG Desktop Portal — Notification
   - URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Notification.html
   - used for: send/withdraw seam and the important rule that the sender cannot know whether the notification was actually presented

6. Apple Developer HIG / support snippets on critical alerts
   - URLs:
     - https://developer.apple.com/design/human-interface-guidelines/managing-notifications
     - https://support.apple.com/en-us/108274
     - https://support.apple.com/en-us/108781
   - used for: critical alerts as a narrower more privileged interruption class that can break through silence/Focus

7. SlopOS RFC `0055-attention-authority-and-notifications.md`
   - local source
   - used for: attention as scarce resource, budgets, canonical branding, urgent-is-a-hint posture, and durable-truth separation

8. SlopOS `docs/30-architecture/attention-durable-status-boundary-v0.md`
   - local source
   - used for: transient attention cannot be the only durable carrier of consequential truth

9. SlopOS `docs/30-architecture/view-namespace-posture-v0.md`
   - local source
   - used for: explicit view ownership and exact target binding, keeping quiet rules tied to shell-owned subjects rather than ambient relatedness
