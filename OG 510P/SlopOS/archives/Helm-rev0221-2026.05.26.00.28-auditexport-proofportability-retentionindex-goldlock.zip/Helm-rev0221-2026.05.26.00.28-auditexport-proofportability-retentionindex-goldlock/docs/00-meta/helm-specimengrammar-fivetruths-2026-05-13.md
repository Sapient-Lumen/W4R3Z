# Helm specimen grammar and five truths — 2026-05-13

## Current judgment

The rev0185 watchrail card was the right trigger, but it is still one abstraction short of being product-useful.
The next Helm move should be **specimen grammar**: one concrete, repeatable proof slice that uses the same tiny truth card across a door pack, saved view, imported arrival, peek, triage lane, review queue, patrol route, and promoted receipt.

This remains smaller than a backend, smaller than a semantic layer, smaller than SlopOS boundary-family coverage, and smaller than a universal workspace/dashboard object.

## The pull-trigger decision

Pull the trigger on a **first-class specimen bundle contract**.

Do **not** pull the trigger yet on:
- a canonical datacube engine,
- a BI metric taxonomy,
- one storage/table format,
- one universal workspace/home object,
- an always-on global index mythology,
- full SlopOS boundary-family machinery,
- or a new Helm pillar.

The wise next bet is a small product proof:

> one serious door pack whose members all confess subject, source cut, serving lane, posture, stale fence, next verbs, and receipt path in one common grammar.

## Why this is deeper than rev0185

rev0185 said, “put a watchrail card on serious surfaces.”

rev0186 says, “make those surfaces prove they can live together.”

A card in isolation is just a nice label.
A specimen loop forces Helm to answer harder product questions:
- Can Omnibox show an exact result, a cached result, a restricted import, and a review-pending queue item without flattening them?
- Can Object Browser show the same subject’s live provider truth, saved definition truth, snapshot truth, derived truth, and receipt truth side by side?
- Can Operations Center explain why a queue item is stale without sounding like infrastructure jargon?
- Can Desktop Flow land output as restricted and adoptable rather than auto-authoritative?
- Can Recall bring back a door pack without pretending remembered layout is live state?
- Can Exchange move a pack as an arrival that is useful before adoption?

## The five truths Helm must show side by side

A powerful Helm object may have several truthful faces at once.
The problem is not choosing one face; the problem is pretending only one exists.

### 1. Current-live truth

What the strongest current source says now, under the current account/provider/profile/basis.
This is the strongest lane for action, but it is expensive, limited, and sometimes unavailable.

### 2. Saved-definition truth

The durable recipe, view, pack, route, query, layout, or front-door definition.
This survives return and sharing, but it is not the current live subject.

### 3. Cut/snapshot truth

The pinned cut, historical tag, imported snapshot, review ticket, branch point, or frozen result used for comparison or handoff.
This is stable, but weaker than current-live truth.

### 4. Derived/serving truth

The cached, precomputed, local analytic, aggregate, summary, embedding, metric, or reconstructed result.
This is often fast and valuable, but must disclose its build basis and what it is weaker than.

### 5. Receipt truth

What Helm did or observed: review, promotion, publish, adopt, decline, duplicate, settle, hand back, route, or recheck.
This is durable history, not live provider state.

## The specimen loop

The first Helm specimen should include exactly these actors:

1. **Saved view object** — the definition and source shape.
2. **Exact front-door handle** — a summonable entry, not live proof.
3. **Door pack manifest** — a tiny control room tying the view, peek, route, and queue together.
4. **Restricted imported arrival** — useful before local adoption, visibly weaker.
5. **Peek panel** — beautiful preview that cannot mutate by being seen.
6. **Triage lane item** — accept, decline, duplicate, snooze, quarantine, adopt, or promote.
7. **Review queue item** — ready only against its reviewed basis and forced to recheck if stale.
8. **Patrol route** — bounded revisit ritual, not dashboard worldview.
9. **Promotion receipt** — durable trace when a weaker thing becomes stronger locally.
10. **Same-object five-truths inspector** — the pane that proves the above did not collapse.

## Lessons Helm must learn from the past

### Hidden chooser logic is the original shell sin

Window managers, launchers, search surfaces, plugin systems, and AI tools all drift toward silent “best” choices.
Helm should show exact, nearby, derived, imported, stale, and permission-limited posture before the operator acts.

### Saved state is not live state

Saved layouts, workspaces, profiles, branches, restored sessions, cached dashboards, and previews are all useful.
They become dangerous when they wear current-live clothing.

### Dashboards rot into authority

A dashboard starts as a derivative convenience and slowly becomes the thing people believe.
Door packs should stay small, named, inspectable, and source-confessing.

### Review without basis is theater

A review queue must name the basis it reviewed.
If the base changed, credentials changed, source definition changed, provider cursor reset, or dependency failed, the queue should say so and recheck.

### Imported usefulness must be weaker than local adoption

A shared view, route, or packet should be immediately inspectable.
It should not arrive already allowed to mutate local truth.

### Fast lanes need humility

Caches, pre-aggregations, local analytics, snapshots, and streaming subscriptions are great because they make the shell feel alive.
They must also say when they were built, what invalidates them, and what stronger truth they are weaker than.

### Receipts must not become surveillance soup

Context crumbs, traces, and receipts are good when they explain why a surface is safe to trust.
They are bad when every action becomes a generalized behavioral exhaust product.
Helm needs bounded receipt paths, not omniscient telemetry religion.

## Nifty outside moves worth stealing

### Steal aggressively

- metric-view-style reusable definitions, but with visible source cuts and dimensions;
- table-format snapshot/evolution humility, but without forcing users to think in partitions;
- local analytics for fast sidecars, but with derived posture;
- precomputed dashboard speed, but with build-cut honesty;
- personal/shared view separation;
- triage inbox verbs with keyboard-speed acceptance, duplicate, decline, and snooze;
- merge-queue-style revalidation against the latest base;
- branch/update-from-main conflict review;
- restricted-mode imported trust;
- context propagation as receipt crumbs, not a monitoring dashboard;
- event-history replay as repair evidence, not live truth.

### Steal carefully

- semantic graphs, but not as the first product language;
- agentic analytics, but not as a magic truth layer;
- workflow replay, but not as a current-state oracle;
- local-first sync, but not as ambient sameness;
- profiles, but not as hidden chooser policy;
- preview/peek, but not as authority to act.

### Refuse for now

- one giant home/workspace/dashboard constitution;
- plugin-defined authority planes;
- provider-shaped connector policy as user-facing law;
- global always-on indexing that hides exposure classes;
- AI-generated summaries that outrank source cuts;
- “current” badges without invalidators;
- saved views that silently become team truth.

## Super-awesome Helm moves unlocked by this pass

### 1. Same object, five truths

A single inspector can answer:
- what is live now?
- what did I save?
- what cut did I review?
- what cached/derived lane am I looking at?
- what did Helm actually do?

This could make Helm feel unusually powerful because it makes contradictions navigable rather than embarrassing.

### 2. Peek with teeth

Peek should be instant, gorgeous, and weak.
Its card says: imported snapshot, cached preview, derived summary, or live-direct glimpse; safe verbs are inspect/adopt/promote, not silent mutation.

### 3. Door pack as truthful control room

A door pack becomes a small manifest of exact refs, not a dashboard blob.
It can say, “these are the view, route, queue, import, peek, and receipts for this activity.”

### 4. Patrol receipts

A patrol run can leave a tiny receipt:
checked, skipped, changed, stale, queued, promoted, declined, and next due.
This turns recurring work into memory without turning it into a bureaucracy.

### 5. Stale-fence refusals that feel helpful

Instead of a vague disabled button, Helm can say:
“Reviewed against `cut A`; source definition changed to `cut B`; recheck to promote.”

### 6. Local analytics without backend religion

Helm can use local columnar and SQL-ish techniques internally, but the product contract remains source cuts, serving lanes, and receipts.
The engine stays replaceable; the truth grammar becomes stable.

## Near-term proof shape

The next mock/prototype should show one named work subject, for example `Release readiness`, with:

```yaml
subject: release-readiness
saved_view: exact saved definition
front_door: exact handle
imported_arrival: restricted packet from teammate/provider
peek: frozen snapshot preview
triage_lane: bounded inbox of arrivals/issues
review_queue: precomputed queue item with stale fence
patrol_route: ordered revisit loop
promotion_receipt: adopt/promote result
inspector: five truth lanes
```

The test is not whether this sounds elegant.
The test is whether it feels obvious, fast, and safer than today’s shells.
