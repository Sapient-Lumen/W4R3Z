# Research bibliography — 2026-03-21 pass XXIV

Official/public sources consulted in this pass:

- VS Code Docs — Profiles in Visual Studio Code  
  https://code.visualstudio.com/docs/configure/profiles
- VS Code Docs — Workspace Trust  
  https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- VS Code Docs — User and workspace settings  
  https://code.visualstudio.com/docs/configure/settings
- VS Code Docs — Settings Sync  
  https://code.visualstudio.com/docs/configure/settings-sync
- VS Code Docs — Revert changes with checkpoints and editing requests  
  https://code.visualstudio.com/docs/copilot/chat/chat-checkpoints
- Raycast Manual — Cloud Sync  
  https://manual.raycast.com/cloud-sync
- Raycast Manual — Shared Quicklinks  
  https://manual.raycast.com/quicklinks/shared-quicklinks
- Obsidian Help — How Obsidian stores data  
  https://help.obsidian.md/data-storage
- Obsidian Help — Sync settings and selective syncing  
  https://help.obsidian.md/sync/settings
- Figma Help — Guide to Dev Mode  
  https://help.figma.com/hc/en-us/articles/15023124644247-Guide-to-Dev-Mode
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Docs — URI Scheme  
  https://docs.warp.dev/terminal/more-features/uri-scheme
- WezTerm Docs — Workspaces / Sessions  
  https://wezterm.org/recipes/workspaces.html
- Notion Docs — Working with views  
  https://developers.notion.com/guides/data-apis/working-with-views
- Notion Docs — Creating pages from templates  
  https://developers.notion.com/guides/data-apis/creating-pages-from-templates
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
