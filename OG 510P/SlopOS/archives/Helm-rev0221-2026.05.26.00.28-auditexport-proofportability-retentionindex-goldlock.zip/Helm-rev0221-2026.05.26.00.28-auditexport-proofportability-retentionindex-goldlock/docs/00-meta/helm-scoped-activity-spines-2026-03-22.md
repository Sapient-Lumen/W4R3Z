# Helm scoped activity spines — 2026-03-22

Purpose: name the next compact shell object that now looks worth defining without adding a new pillar.

## Main idea

Helm likely wants a **scoped activity spine**.

An activity spine is a shell-owned work object that gathers a few things that belong together for one piece of work:
- one or more saved view objects
- one or more checkpoints or branches
- one current-live reentry cue
- one small command band or dock slice
- one or more launch/layout starters
- optional review tickets or exchange routes
- an explicit scope and memory fence

The spine is not the live lane.
The spine is the shell-owned **work frame** around the lane.

## Why this seems timely now

Helm already has several strong candidate objects,
but they still feel scattered:
- saved view objects
- checkpoint branches
- review tickets
- launch/layout starters
- command docks
- publication ladders
- imported-surface trust posture

The outside world is validating that users often want these things to gather under one named work context.
What is usually missing in current tools is truthful shell law around that gathering.

That is the opportunity.

## What to keep

### 1. Explicit scope
A spine should know what is in scope and what is not.
It should not silently inherit nearby account,
profile,
browser,
or provider context.

### 2. Several saved views, not one giant default page
A spine can have multiple attached views,
with one favorite or default front door.
The views remain separate objects.

### 3. One current-live beacon
A spine should have a clean way to say:
**this is the actual live lane right now**
without collapsing the spine into the lane.

### 4. Light nested subcontexts
A spine may want shallow nested subtracks or subspines.
Think:
- a triage subtrack
- a compare subtrack
- a delivery subtrack

This should stay shallow and explicit.

### 5. Share ladders and memory fences
A personal spine,
a shared spine,
and a published spine should not have identical context rights.
Sharing should often tighten boundaries rather than widen them.

### 6. Honest export / import choices
A spine should support:
- export current subthing
- export all grouped things
- preserve lineage
- publish as copy
- instantiate fresh receiver starter

without hiding which choice happened.

## What not to keep

### 1. Giant workspace portability mythology
Do not make activity spines promise that all windows,
accounts,
cookies,
foreground state,
and local residue travel perfectly.

### 2. Ambient capture
Do not auto-add every opened or recent thing into the spine.

### 3. Spine-as-master-ontology
A spine is a useful shell object,
not the replacement for every object family.

### 4. Fake continuity
A saved spine,
a shared spine,
and a current live lane should stay visibly different forms.

## Why this can make Helm super awesome

Because it gives Helm a way to combine several already-good moves into one daily-useful shell object:
- saveable views
- truthful continuity
- scoped memory
- shareable quick actions
- launch/layout starters
- reentry
- and honest export/import

That is a lot of product leverage without adding a pillar.

## Pull-the-trigger judgment

Helm should still keep the leading proofs where they are:
- saved view objects
- checkpoint branches

But it now looks wise to define one supporting object:

**activity spine** — a shell-owned scoped work frame that gathers the right saved objects and current-live cues without pretending to be current live truth itself.
