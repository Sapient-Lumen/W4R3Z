# SlopOS companions evaluation — 2026-03-23 pass CLVII

## Purpose

Continue evaluating **SlopOS**, **Schell**, **ViewFS**, **Harbor**, **Foundry**, **Ward**, and **Steward** after the reviewed-slice round-trip pass by asking one more specific question:

**what datacube laws should Helm freeze next so its surfaces stay exact, typed, and reopenable without becoming one giant center?**

## 1. SlopOS is still the harshest teacher, and that is good

The current SlopOS bundle is still strongest when it says **no**.
The most useful local lessons in this pass are:

- **approval-basis posture**: reviewed approval must bind one exact mutable basis rather than silently follow a newer head or queue item
- **namecert selection boundary**: multiple admissible candidates should stay a bounded candidate set instead of becoming a hidden winner-selection engine
- **show-item exactness boundary**: an exact reveal/select request should fail closed instead of silently degrading into a nearby browse

Those are not just local security laws.
They are datacube laws.
They say Helm should prefer:
- explicit basis
- explicit choice
- honest denial
- and no helpful blur that later cannot be defended

## 2. Schell still proves stage separation is more important than early chrome decisions

Because Schell is still in design,
it keeps teaching the durable part of the story without overfitting the UI too early.
The durable part is still:
- proposal is not review
- review is not run
- run is not later outcome

That maps cleanly into Helm's product grammar.
The shell does not need every final noun yet.
It does need that stage law.

## 3. ViewFS keeps proving that prepared structure and landed structure are not the same truth

ViewFS is increasingly one of Helm's best local teachers for the Browser/Flow/Omnibox cluster.
The archive keeps separating:
- editable buffers
- parsed structures
- advisory diagnostics
- compiled command packets
- prepared actions
- durable receipts/history

That is exactly the kind of datacube honesty Helm wants.
A parse lens or diagnostic rail is useful precisely because it does **not** masquerade as the final packet or later receipt.

## 4. Harbor keeps teaching that preview cues and labels must stay smaller than trust

Harbor's current pass keeps boundary-crossing truth deliberately smaller than durable trust.
Coarse origin cues,
preview assets,
and labels may be helpful,
but they must stay weaker than the later route and aftermath truth.
That is a very direct lesson for Helm:
preview chrome should help,
not overclaim.

## 5. Foundry keeps teaching that actor trails matter without becoming current authority

Foundry's discharge witnesses,
caveat holds,
and actor-path cards are a good reminder that history still matters after authority narrows.
An actor path can be important for audit,
continuity,
and explanation,
but it should stay smaller than the current live authority.
Helm should steal that restraint for its own later settlement and calibration surfaces.

## 6. Ward keeps teaching staleness discipline and revalidation fences

Ward is still one of the clearest local warnings against datacube laziness.
Read cuts,
staleness budgets,
ambiguity windows,
revalidation fences,
cause cohorts,
and local adoption cuts all reinforce the same lesson:
there is no single “current enough” label that can honestly do all the work.
Helm should keep making stale-but-usable,
current-live,
and historical-only different visible truths.

## 7. Steward keeps teaching adaptation is a typed truth, not a generic degraded mood

Steward's recent work around adaptation witnesses,
cache trim,
concurrency caps,
backpressure,
serve state,
and headroom keeps reinforcing one good shell instinct:
there is enormous value in naming **what kind** of pressure or adaptation is in effect.
That is much better than one vague degraded badge.

## 8. The companions together now point at two next shell-wide laws

The companions are converging on a surprisingly tight answer.
The next useful shell-wide datacube freezes are:

1. **truth axes**
2. **basis reopen routes**

The truth-axis pressure says:
when a card matters,
it should admit scope,
phase,
freshness,
basis,
and settlement class.

The reopen-route pressure says:
when a card matters,
it should reopen the exact footing rather than forcing the operator to trust summary chrome.

## 9. Why this is better than another center

A giant center would try to tell the truth by aggregation.
The companions keep arguing for the opposite.
They reward:
- explicit basis
- explicit slices
- explicit choice
- typed conditions
- exact reopen paths
- later settlement/calibration tied back to the original footing

That gives Helm a better datacube with much less premature architecture.

## Product judgment

Keep the seven pillars.
Keep **settlement witnesses + commit cards** admitted.
Keep **calibration witnesses / miss ledgers** warm.
Keep the shared reviewed-slice round-trip.

And now make one more narrow shell-wide decision:
Helm should increasingly require compact **truth axes** and exact **basis reopen routes** on any surface important enough to shape action.

That is the cleanest current lesson from SlopOS and the companion cubes.
