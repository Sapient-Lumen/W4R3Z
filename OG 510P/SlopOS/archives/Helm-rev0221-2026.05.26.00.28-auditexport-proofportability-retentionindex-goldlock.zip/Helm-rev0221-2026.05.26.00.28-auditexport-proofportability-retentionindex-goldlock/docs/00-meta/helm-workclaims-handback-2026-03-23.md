# Helm: work claims + honest handback — 2026-03-23

## Headline

Helm should probably add one compact shell-owned object for this sentence:

**someone or something is touching this exact subject now,
for this reason,
in this mode,
until roughly this freshness horizon,
and here is how it will hand back or decay.**

That object should be a **work claim**.

## Why now

Helm already has many nearby moves:
- current-live beacons
- state tuples
- helper escorts
- authority windows
- gesture runways
- continuity postcards
- quiesce rails
- drain witnesses
- capability budgets
- lease windows

What it still lacks is the coordination object between them.
Without one,
Helm keeps risking three bad collapses:
- “assigned” pretending to mean “actively touching now”
- “has authority” pretending to mean “currently working here”
- “a stale row exists” pretending to mean “the subject is still occupied”

## The move

A Helm work claim should be:
- shell-owned
- over one exact subject or bounded cohort
- narrower than authority
- stronger than a vague activity badge
- freshness-bearing
- reviewable in tiny chrome
- and honest about handback / release / override

## Why this is different from nearby objects

- **authority window** = what power exists or existed
- **helper escort** = what narrow delegated power a helper currently has
- **task handle** = accepted deferred-work wrapper, not the same as occupancy
- **current-live beacon** = where the currently live thing is
- **historical receipt** = what happened then
- **work claim** = who is touching this exact subject now,
  in what coordination mode,
  until when,
  and with what handback posture

That distinction matters a lot.
A helper may have narrow authority but no current claim.
A user may hold a current claim without any power to publish.
A result receipt may exist after the claim is long gone.

## Strongest ideas worth stealing

### 1. Shared versus exclusive versus delay posture
From Web Locks and systemd inhibitors,
Helm should likely support claim modes such as:
- `shared`
- `exclusive`
- `advisory`
- `delay-cutover`
- `block-weak`
- `block`

That is much better than a single “locked” badge.

### 2. If-available and queue truth
A superb shell move is:
- take claim only if available now,
- otherwise show `queued-behind` or `someone-else-active`,
- instead of silently waiting and impersonating immediacy.

### 3. Renewed-at and live-until truth
Kubernetes Lease pressure is especially useful here.
The claim needs:
- acquired at
- renewed at
- live until / expected stale at
- and maybe transitions / owner changes

That lets Helm admit “last renewed 3m ago” instead of faking certainty.

### 4. Who / why metadata close to the seam
systemd’s `who` and `why` are a gift.
Helm should not make operators dig for this.
A tiny claim chip could say:
- who holds it
- why
- mode
- freshness
- next likely release path

### 5. Handback and preferred next holder
A great extra move from leases and queues is **honest handback**.
A claim can say:
- release expected on finish
- handback requested
- preferred next holder waiting
- expired stale
- overridden deliberately

That is much nicer than disappearing rows or mystery contention.

## What to keep from older inspirations

Keep:
- exact subject binding
- shell-owned truthful chrome
- decaying freshness rather than immortal badges
- compare-before-override posture
- publish/apply edge verification
- helper delegation staying separate from live coordination claims

Peel away:
- giant enterprise lock-manager vibes
- project-management assignment semantics as the substrate
- casual steal/preempt-as-default UX
- generic team workflow religion
- stale claim residue pretending to be current occupancy

## Why this could make Helm super awesome

### 1. The shell can finally answer “who is touching this right now?” honestly
Without opening a giant dashboard.

### 2. Helpers become less spooky
A helper escort can have power,
but a separate work claim can show whether it is *currently* editing,
reviewing,
or merely queued.

### 3. Apply/publish/merge edges get calmer
The shell can say:
- active shared review exists
- exclusive mutate claim exists
- claim is stale and review-first override is available
- or claim released cleanly 2m ago

### 4. Recall gets better
Old claim residue can return as:
- historical-only,
- stale-override-available,
- or same-holder-reacquire,
rather than pretending continuity is still live.

### 5. Operations Center becomes more human
Not more bureaucratic.
It can show contention,
queued claims,
stale claims,
and handback requests as real first-class states.

## Pull-the-trigger judgment

Helm still should not freeze a universal collaboration platform.
But it probably **is** time to warm one compact specimen:

**work claims** — shell-owned,
decaying,
reviewable coordination objects over exact subjects with explicit holder,
purpose,
mode,
renewal freshness,
and honest handback / release / override posture.

That looks like a genuine next Helm move.
