# Research bibliography — 2026-03-21 — pass VIII

Compact outside source memory for pass VIII.

## Workspace / layout / overview pressure

- Microsoft PowerToys Workspaces documentation
- Microsoft PowerToys FancyZones documentation
- GNOME Help: Activities overview / workspaces
- Obsidian Help: Workspaces

## Structured command / preview / accelerator pressure

- Microsoft PowerToys Command Palette documentation
- Microsoft PowerToys Peek documentation
- Raycast Quicklinks documentation
- Raycast Snippets documentation
- Raycast Dynamic Placeholders documentation

## Session / profile / debug / evidence pressure

- VS Code Profiles documentation
- VS Code agent overview documentation
- VS Code February 2026 release notes
- VS Code Timeline / user interface documentation
- Node-RED sidebar and debug sidebar documentation

## Pass-VIII bounded take

The current external idea harvest most strongly supports two Helm moves:
- freeze activity-scope truth narrowly,
- and explore activity scope witnesses as a compact shell-owned continuity luxury.
