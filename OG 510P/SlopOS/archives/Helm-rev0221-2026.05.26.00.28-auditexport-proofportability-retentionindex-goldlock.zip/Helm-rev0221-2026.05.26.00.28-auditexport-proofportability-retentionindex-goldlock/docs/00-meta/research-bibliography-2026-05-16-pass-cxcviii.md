# Research bibliography — pass CXCVIII — 2026-05-16

- Google SRE Workbook — Example Error Budget Policy.
- Google SRE Book — Embracing Risk.
- ServiceNow documentation — policy exception and extension lifecycle.
- Kubernetes documentation — finalizers.
- Backstage documentation — software catalog ownership and entity lifecycle.
- Atlassian Compass documentation — scorecards and component health criteria.
- GitHub documentation — Dependabot alert dismissal/reopen lifecycle.
- OpenFeature specification — hooks and evaluation lifecycle.
- SlopOS rev0695 — proof/unsafe obligation registries, budget/lease invariants, descriptor non-authority posture.
