# Helm pillars — lessons, steals, and awesome moves — 2026-03-23

## The current call

Helm does **not** need another pillar right now.
The seven pillars still look right.
The next admitted ratchet is still **settlement witnesses + commit cards**.

But the archive now has enough pressure to say something stronger about what should make Helm amazing next:
**branch-backed decks, live inspector decks, freshness lamps, and local analytical sidecars look like the richest cross-pillar cluster to keep harvesting.**

## The lessons Helm must learn from the past

### 1) Never let one cozy scalar replace a stack of truths
Old products keep doing this:
- one green success state,
- one open/recent state,
- one shared/published state,
- one running/healthy state,
- one merged/done state.

Helm should keep refusing that.
The whole product gets better every time it preserves:
- current-live truth,
- historical truth,
- settlement truth,
- freshness truth,
- branch truth,
- review truth,
- receiver-visible truth,
- and source-local truth.

### 2) The killer feature is not more automation; it is more honesty
The lasting delight in these archives is not “do more automatically.”
It is:
- say what is exact,
- say what is stale,
- say what basis was used,
- say what still needs adoption,
- and say what the next honest move is.

### 3) Tiny humane surfaces beat giant control planes
The best recurring ideas are cards,
chips,
strips,
lamps,
rails,
briefs,
and witnesses.
That is the design lesson.
Helm should keep choosing tiny typed surfaces over huge generalized centers until the laws are extremely clear.

## Great ideas worth stealing now

### A) Smart decks
Saved query/view objects with explicit:
- criteria,
- scope,
- snapshot versus rerun posture,
- live-versus-static posture,
- and target-set/adoption rails.

### B) Live inspector decks
A live deck should say:
- cadence or subscription class,
- lag,
- reconnect posture,
- overflow posture,
- and whether the visible rows are safe for inspect only or ready for stronger reviewed action.

### C) Checkpoint branches
Helm should eventually let an operator:
- branch a deck,
- branch an activity entry kit,
- branch a layout or flow surface,
- update from main,
- compare,
- request review,
- and merge/adopt.

But the branch should remain visibly weaker than mainline live truth until adoption.

### D) Freshness lamps
Compact lamps should increasingly say things like:
- `fresh as of 12:21`
- `warn horizon crossed`
- `stale snapshot`
- `live feed lagging`
- `recheck required before act`

That is much better than a timeless cached-looking surface.

### E) Local analytics sidecars
Helm should probably get a quiet derived-analysis engine over:
- receipts,
- deck histories,
- watch rows,
- route aftermath,
- and activity events.

The trick is to keep that sidecar:
- local-first,
- derived,
- fast,
- and visibly weaker than canonical live shell truth.

## Pillar-by-pillar pressure

### Tiling Shell
Steal:
- branchable layout experiments,
- compare-to-main overlays,
- freshness lamps for restored layouts,
- and tiny settlement / headroom / audience chips on spatial surfaces.

### Omnibox
Steal:
- summon saved decks,
- filter by footing/freshness/branch class,
- branch-from-result,
- and one obvious promote-to-reviewed-target-set path.

### Object Browser
Steal hardest here:
- smart decks,
- snapshot decks,
- live decks,
- branch-from-view,
- freeze-to-basket,
- freshness lamps,
- and sidecar-backed rich local query without pretending derived sets are authority.

### Operations Center
Steal:
- live inspector decks,
- lag/overflow/reconnect confession,
- branch/adoption queues,
- exact after-act settlement chips,
- and “watch is weaker than act” posture.

### Desktop Flow
Steal:
- branchable flow experiments,
- reviewed merge/adopt,
- freshness gates on stale inputs,
- and target-set promotion before many-target effects.

### Recall
Steal:
- last-confirmed versus last-visited footing,
- snapshot refs,
- branch history,
- update-from-main posture,
- freshness lamps,
- and compare-from-here rails.

### Exchange
Steal:
- exact deck export,
- replay capsule posture,
- branch handoff with basis stamps,
- receiver-fit cards,
- and `offer-only` versus `adopted-here` honesty.

### Terminal/Capshell front-end family
Steal:
- query witnesses,
- smart decks,
- watch decks,
- replay capsules,
- and chapter/receipt-aware live inspectors,
without letting them silently become shell-wide authority.

## Moves that could make Helm super awesome

### 1) Branch this view
From a smart deck,
query result,
layout,
or activity front door:
- freeze a snapshot,
- branch it,
- compare it to main,
- and later request adoption.

### 2) Freeze to deck
Any strong result set should be freezable into:
- one exact snapshot deck,
- one named smart deck recipe,
- or one live inspector deck.

Those should be different objects,
not one overloaded save button.

### 3) Freshness before force
Before strong acts,
Helm should increasingly show tiny freshness / basis / branch posture:
- `snapshot old`
- `basis drifted`
- `live deck lagging`
- `receiver truth missing`
- `recheck now`

### 4) Promote to reviewed target set
Do not let top-hit or visible-row convenience become authority.
Make many-target work feel luxurious,
but route it through explicit reviewed target-set promotion.

### 5) Quiet local analytics workbench
A shell-owned workbench over local derived data could make Helm feel extraordinarily good at:
- “show me failed publish attempts with pending settlement”
- “show me decks that have been stale for 2 days”
- “show me branch objects never adopted”
- “show me receiver-fit failures grouped by route”

### 6) Update-from-main cards
Borrow the humane part of Figma branching:
- tell the operator when main moved,
- allow review of incoming changes,
- and make adoption explicit rather than silent.

## What not to steal

Do not steal:
- ambient live dashboards that quietly become control planes,
- giant history/search/watch engines frozen too early,
- saved queries as implied grants,
- branches as fake mainline truth,
- or analytics sidecars as canonical authority.

## The practical next stance

Keep settlement witnesses admitted.
Keep the seven pillars stable.
Then keep harvesting:
- smart decks,
- live inspector decks,
- checkpoint branches,
- freshness lamps,
- local analytics sidecars,

until one or two of them become obviously worth the next narrow contract.
