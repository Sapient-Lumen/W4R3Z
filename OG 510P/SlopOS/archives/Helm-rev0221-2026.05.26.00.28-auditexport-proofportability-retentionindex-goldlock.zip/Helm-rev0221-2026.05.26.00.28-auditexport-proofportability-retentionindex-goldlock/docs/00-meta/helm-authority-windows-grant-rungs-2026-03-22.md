# Helm: authority windows + grant-rung ladders — 2026-03-22

Purpose: name the next compact support layer that now looks worth defining without adding a pillar.

## Main claim

Helm is finally getting good enough at:
- selected context,
- output claim posture,
- exact proposed change,
- aftermath truth,
- and truthful recovery.

That makes one new gap much easier to see:

**what exact authority exists for this stronger act right now,
and how long / where / under what conditions does that authority remain valid?**

The next likely answer is:
- **authority windows**
- **grant-rung ladders**

## Why this now looks mature enough

Outside tools are converging on the same pattern:
- a weaker temporary grant first,
- a stronger persistent grant later,
- explicit session-level autonomy,
- and very visible warnings when bypassing approval gets dangerous.

SlopOS is converging from the harsher side:
- urgency is not authority,
- renewal must not silently widen,
- historical descriptors do not prove current live grants,
- and exact approval must not float onto a newer mutable basis.

Those two pressures line up unusually well.

## What Helm should probably steal

### 1. The permission ladder should be humane, not bureaucratic

A good Helm chooser should probably feel like:

- **Inspect only**
- **Allow once**
- **Allow this time**
- **Allow for this ask / loadout**
- **Allow for this activity**
- **Allow in this isolated side lane**
- **Allow in this named scope until revoked**

Not every authority family needs every rung.
But this is much more truthful than one generic “Allow” button.

### 2. Isolation should earn broader temporary room

This is the nicest steal from the current market.
A helper that wants to mutate the live lane should usually stay on the tighter rungs.
A helper working inside a shadow lane,
worktree,
or other isolated shell-owned side lane can often earn a broader temporary window.

That gives Helm a way to make autonomy feel great **without** making the live lane casually dangerous.

### 3. Duration and scope should be different axes

“Allow for this activity” and “Allow until revoked” are not the same thing.
Neither are “Allow for this tab” and “Allow for this agent session.”

Helm should not flatten duration,
subject,
location,
and blast radius into one fuzzy permission myth.

## What is worth keeping from older inspirations

Keep:
- portals / consent surfaces
- required review
- preview-before-apply
- isolated candidate lanes
- revocable temporary grants
- one-time permission UX
- project-scoped sources and explicit connector approval

Peel away:
- giant permission-center religion
- hidden global autopilot
- sticky approvals that quietly follow drift
- permanent authority as the cheerful default
- historical “allowed once” surfaces pretending they are live now

## What would make Helm super awesome here

### current grant beacons in Operations Center

Not just “agent running” or “tab open.”
A small shell-owned beacon saying:
- current authority family
- holder
- rung
- expiry countdown or current-session status
- isolation posture
- revoke / narrow / inspect nearby

### allow-in-isolated-lane as a first-class answer

This is maybe the coolest move in the whole pass.
It gives users a brave middle option between “no” and “full live-lane yes.”

### expiry-aware reentry

When Recall or an entry kit brings you back,
Helm should be able to say:
- this old window existed,
- it is no longer live,
- here is the nearest safe rung to reacquire it.

### drift-aware authority demotion

If the reviewed basis changed enough,
authority should often demote:
- from apply to inspect,
- from broad temporary to narrow temporary,
- or from live-lane to isolated-lane only.

That would feel unusually honest and unusually good.

## Why this is better than a new pillar

It sharpens many existing pillars at once:
- **Omnibox** gets honest stronger-action grants
- **Operations Center** gets current grant state that is richer than jobs/status folklore
- **Desktop Flow** gets bounded helper power
- **Recall** gets honest historical-vs-current authority
- **Exchange** gets better import/share/app-link approval posture
- **Object Browser** gets clearer subject-and-scope ties for stronger acts

That is exactly the sort of leverage Helm should prefer right now.

## Current judgment

Do **not** add a pillar.
Do keep **saved view objects** and **checkpoint branches** as the main proof targets.

But the next compact support layer that now looks worth defining is:
- **authority windows**
- **grant-rung ladders**
