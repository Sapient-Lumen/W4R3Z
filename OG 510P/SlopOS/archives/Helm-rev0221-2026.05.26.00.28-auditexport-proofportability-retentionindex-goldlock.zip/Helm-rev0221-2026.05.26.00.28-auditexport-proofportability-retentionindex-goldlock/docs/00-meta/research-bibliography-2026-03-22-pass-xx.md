# Research bibliography — 2026-03-22 pass XX

Official/public sources consulted in this pass:

- VS Code Docs — User and workspace settings  
  https://code.visualstudio.com/docs/configure/settings
- VS Code Docs — Profiles in Visual Studio Code  
  https://code.visualstudio.com/docs/configure/profiles
- VS Code Docs — Settings Sync  
  https://code.visualstudio.com/docs/configure/settings-sync
- VS Code Docs — Use custom instructions in VS Code  
  https://code.visualstudio.com/docs/copilot/customization/custom-instructions
- VS Code Docs — Add and manage MCP servers in VS Code  
  https://code.visualstudio.com/docs/copilot/customization/mcp-servers
- Raycast Manual — Quicklinks  
  https://manual.raycast.com/quicklinks
- Raycast Manual — Deeplinks  
  https://manual.raycast.com/deeplinks
- Raycast Manual — Clipboard History  
  https://manual.raycast.com/core
- Raycast Manual — Getting Started with Teams  
  https://manual.raycast.com/getting-started-with-teams
- Obsidian Help — Introduction to Bases  
  https://help.obsidian.md/bases
- Obsidian Help — Bases syntax  
  https://help.obsidian.md/bases/syntax
- Obsidian Help — Workspaces  
  https://help.obsidian.md/plugins/workspaces
- Obsidian Help — How Obsidian stores data  
  https://help.obsidian.md/data-storage
- Warp Docs — Launch Configurations  
  https://docs.warp.dev/terminal/sessions/launch-configurations
- Warp Docs — Session Navigation  
  https://docs.warp.dev/terminal/sessions/session-navigation
- Warp Docs — URI Scheme  
  https://docs.warp.dev/terminal/more-features/uri-scheme
- WezTerm Docs — Workspaces / Sessions  
  https://wezterm.org/recipes/workspaces.html
- WezTerm Docs — launch_menu  
  https://wezterm.org/config/lua/config/launch_menu.html
- Microsoft Learn — PowerToys Command Palette Dock  
  https://learn.microsoft.com/en-us/windows/powertoys/command-palette/dock
- Arc Help Center — Split View: View Multiple Tabs at Once  
  https://resources.arc.net/hc/en-us/articles/19335393146775-Split-View-View-Multiple-Tabs-at-Once
- Arc Help Center — Little Arc: Quick Lookups & Instant Triaging  
  https://resources.arc.net/hc/en-us/articles/19235387524503-Little-Arc-Quick-Lookups-Instant-Triaging
- Apple Support — View and edit files with Quick Look on Mac  
  https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
