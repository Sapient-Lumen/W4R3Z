# Research bibliography — 2026-03-23 pass CXXXVI

| Ref | Source | Why it mattered |
| --- | --- | --- |
| REF-MONGODB-WRITECONCERN-2026 | https://www.mongodb.com/docs/manual/reference/write-concern/ | distinct write-ack levels: primary-only, journaled, majority durable, and timeout / rollback caveats |
| REF-KAFKA-PRODUCER-ACKS-2026 | https://kafka.apache.org/41/configuration/producer-configs/ | `acks=0/1/all` explicitly separate sent, leader-written, and full in-sync acknowledgment |
| REF-KAFKA-MIN-ISR-2026 | https://kafka.apache.org/42/configuration/topic-configs/ | `min.insync.replicas` keeps durability/visibility law separate from mere acceptance |
| REF-S3-REPLICATION-STATUS-2026 | https://docs.aws.amazon.com/AmazonS3/latest/userguide/replication-status.html | `PENDING` / `COMPLETED` / `FAILED` / `REPLICA` make cross-destination settlement visible |
