# Research bibliography — 2026-03-23 pass CXIV

1. **Apple Spotlight actions**
   - Why it mattered: Spotlight can search for specific actions, narrow to actions, and assign quick keys.
   - Helm pull: Omnibox should keep growing as a typed action surface rather than stopping at launcher/search behavior.

2. **Microsoft PowerToys Command Palette**
   - Why it mattered: Command Palette offers quick access to apps, commands, settings, calculator results, clipboard history, and service controls from one summonable palette.
   - Helm pull: a broad shell command surface can stay fast and useful without becoming ambient automation.

3. **Apple Quick Look**
   - Why it mattered: Quick Look gives a fast full-size preview without opening the file and still offers bounded next actions.
   - Helm pull: preview → promote is still one of the highest-leverage shell luxuries.

4. **VS Code Source Control / Timeline**
   - Why it mattered: VS Code attaches Timeline to a specific file and lets users see commit history and local file changes.
   - Helm pull: Recall should get stronger through exact object timelines, not giant generic memory capture.

5. **Figma branching**
   - Why it mattered: branches are controlled environments for exploration that later move through review and merge.
   - Helm pull: shadow work lanes and adoption harbors are the right shape for exploration without mutating live truth.

6. **Git worktree + VS Code worktrees**
   - Why it mattered: multiple branches can be worked on simultaneously in separate working directories, and current editors now surface that workflow explicitly.
   - Helm pull: parallel repo and helper luxury should remain clearly separate from the foreground live lane.

7. **Notion Home**
   - Why it mattered: Home gathers recent pages, shortcuts, upcoming events, and tasks while leaving underlying objects primary.
   - Helm pull: weak Overview landing should be assembled from linked objects rather than replacing them.

8. **Slack canvases / version history**
   - Why it mattered: canvases are durable shared surfaces with workflow embeddings, and Slack exposes version history/restoration for related surfaces.
   - Helm pull: shell-owned knowledge/overview surfaces can be powerful so long as they remain surfaces rather than a second authority plane.

9. **Ink & Switch — Local-first software**
   - Why it mattered: local-first still frames offline strength, ownership, collaboration, privacy, and preservation as one coherent target.
   - Helm pull: keep local durable shell truth and explicit sync/publication seams, but do not force an all-at-once CRDT freeze.

10. **Windows Recall**
    - Why it mattered: Recall uses locally stored and locally analyzed screen snapshots organized into a timeline and searchable with natural language.
    - Helm pull: searchable return-to-work surfaces are valuable, but giant screenshot memory should be treated as a warning, not a default model for Helm Recall.
