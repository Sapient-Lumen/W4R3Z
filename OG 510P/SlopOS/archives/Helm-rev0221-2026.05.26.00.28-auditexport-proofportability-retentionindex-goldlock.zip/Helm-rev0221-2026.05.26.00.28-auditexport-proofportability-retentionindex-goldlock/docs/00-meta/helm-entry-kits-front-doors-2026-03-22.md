# Helm entry kits and front doors — 2026-03-22

Purpose: sharpen one older Helm move that now looks more timely again after activity spines and resource shelves.

## Main idea

Helm likely wants a stronger **activity entry kit / front-door** object.

Not a new pillar.
Not a giant workspace manager.
Not a flattering restore myth.

The entry kit is the saved starter that helps the user say:
**take me back to the right work the right way.**

## Where it sits in the stack

The cleaner stack now looks like this:

- **activity spine** — scoped work frame
- **resource shelf** — curated grouped resources
- **saved view object** — explicit durable view
- **checkpoint branch** — exact temporal branch/restore point
- **activity entry kit** — saved front door / starter into that work frame
- **current-live beacon** — actual live-lane reentry cue

The entry kit is not a replacement for the spine or the shelf.
It is the saved way in.
