# SlopOS companions evaluation — 2026-03-23 pass CLXIII

## Purpose

Continue evaluating **SlopOS**,
**Schell**,
**ViewFS**,
**Ward**,
**Steward**,
**Harbor**,
and **Foundry** after the resumption-brief pass by asking one tighter question:

**if Helm can now reopen a serious story through a resumption brief,
what exact earlier footing should that brief stand on,
and how should the next narrow delta or reset path stay honest?**

## Answer up front

The best next move is still not a pillar.
It is a substrate move beneath resumption briefs:
- **footing marks**
- plus typed **delta ladders**

That keeps Helm honest about what “since” actually means,
and it prevents re-entry from quietly drifting onto whatever the shell happens to have lying around.

## 1. SlopOS still teaches exact basis before pretty recap

SlopOS keeps rewarding exact mutable basis,
local witness posture,
and weaker-versus-stronger truth.
That means Helm should not let a resumption brief say “since” unless it can point at one exact footing mark.
A mark should stay smaller than the live source and smaller than the compare result,
but it should still be explicit.

## 2. Schell still teaches that stage memory needs named anchors

Schell's strongest lesson remains stage separation:
proposal,
review,
run,
outcome.
The new implication is that “last trusted footing” needs naming too.
`last-reviewed` is not `last-visited`.
`shared-base` is not `receipt-backed`.
A footing mark lets Helm say which stage-relative footing it actually means.

## 3. ViewFS almost hands Helm the delta-ladder split directly

ViewFS keeps continuation cursor,
watermark,
live subscription,
rebuilt snapshot,
gap verdict,
and receipt visibly separate.
That is the clearest local teacher for a delta ladder.
One rung can be “continue current round.”
Another can be “store this as the new baseline.”
Another can be “rebuild same scope.”
Another can be “history only; reset required.”
The lesson is not to adopt ViewFS vocabulary wholesale.
The lesson is to keep Helm's next-round grammar just as explicit.

## 4. Ward still teaches that old footing classes have different strength

Ward's read cuts,
staleness budgets,
and revalidation fences matter even more here.
A footing mark should be able to stay visibly weaker or stronger depending on class:
- `last-visited`
- `last-checked`
- `last-confirmed`
- `last-reviewed`
- `shared-base`
- `historical-only`

That is exactly how Helm avoids treating every earlier basis as equally trustworthy.

## 5. Steward still teaches typed repair pressure after continuity fails

Steward's observation-cursor posture and repair-gate posture reinforce that good continuity language has to preserve both:
- what exact mark you last had
- what exact next rung is now honest

That means a delta ladder should not collapse into one `refresh` button.
It should guide toward finish-round,
poll,
store-new-baseline,
rerun-failed-subset,
rebuild-same-scope,
reacquire,
or hold.

## 6. Harbor and Foundry still teach restraint

Harbor warns that route truth and receiver-visible aftermath are different truths.
Foundry warns that diagnostics are not verdict.
For this pass the lesson is restraint:
footing marks and delta ladders should stay smaller than settlement,
runtime evidence,
or outcome claims.
They explain the comparison foothold and next-round path.
They do not absorb the rest of the datacube.

## Product judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Keep **calibration witnesses / miss ledgers** warm.
Keep **resumption briefs + typed gap verdicts** warm.

But the next narrow move that now looks worth naming explicitly is:
- one exact **footing mark** for what earlier footing counts
- one typed **delta ladder** for the next small round / refresh / rebuild / reset path from that mark

That is a better way to make Helm awesome than inventing more centers,
and it respects the companion designs more than inheriting one giant sync or datacube vocabulary would.
