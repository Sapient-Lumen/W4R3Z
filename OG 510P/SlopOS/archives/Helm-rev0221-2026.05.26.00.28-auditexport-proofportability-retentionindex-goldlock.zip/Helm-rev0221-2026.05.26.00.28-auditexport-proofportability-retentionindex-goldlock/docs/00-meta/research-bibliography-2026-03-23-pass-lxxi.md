# Research bibliography — 2026-03-23 — pass LXXI

## Sources consulted for this pass

1. Microsoft Learn — Data, Privacy, and Security for Microsoft 365 Copilot
   - Copilot interaction data includes the prompt,
     the response,
     and citations to information used to ground the response
   - that interaction record forms Copilot activity history

2. Microsoft Support — What information does Copilot use to answer my prompt?
   - grounding is the process of anchoring output in contextual relevant sources
   - grounding may use work data,
     web data,
     or local attached data
   - citations help verify,
     but Microsoft still says users should review the sources and confirm critical details before sharing

3. Microsoft Support — Welcome to Copilot in Word
   - when summarizing or answering questions about a document,
     Copilot provides references with citations to where it retrieved its information from
   - chats are automatically saved to Copilot history

4. Microsoft Support — Transparency Note for Microsoft Copilot
   - grounded web responses include hyperlinked citations below the text
   - Microsoft explicitly describes grounding as centering the response on high-ranking web content rather than unguided generation alone

5. GitHub Docs — Tracking GitHub Copilot's sessions
   - GitHub surfaces running and past agent sessions with status at a glance
   - session logs can be opened to understand Copilot's approach
   - the logs show the tools used and the work done to validate the changes

6. GitHub Changelog — Copilot coding agent supports code referencing
   - matching public code can be highlighted in the session logs with links to the original code and license context
   - this is a strong teacher for inspectable grounding and source-match visibility on helper output

7. GitHub Docs — About GitHub Copilot coding agent
   - details about the analysis performed and actions taken by the coding agent can be reviewed in the session log

8. Datadog Docs — Watchdog Root Cause Analysis
   - Watchdog RCA separates root cause,
     critical failure,
     and impact
   - degraded application performance is not itself classified as the root cause

9. Datadog Docs — Watchdog Alerts / Impact Analysis
   - alert details can include what happened,
     possible impact,
     root cause,
     and affected users or view paths when relevant

10. Atlassian Support — Summarize a work item's details using AI
    - Atlassian's generated summary is visible only to the current user
    - the summary disappears when the user navigates away
    - this is a strong teacher for weak ephemeral AI summaries

11. Atlassian Support — Automation log details
    - log details provide a summary of how a rule was applied
    - status symbols explain why a rule was or was not able to run

12. Microsoft Learn — Power Automate monitor run details
    - run details expose owner,
      metadata,
      status,
      and inputs/outputs
    - secure inputs/outputs remain hidden
    - progressive action logging can provide near real-time action status updates

13. Microsoft Learn — Secure data used in cloud flows
    - hardcoded sensitive information can be exposed through run history inputs and outputs
    - this is a strong teacher for redaction-aware explanation surfaces
