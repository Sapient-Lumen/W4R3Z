# Helm: since cards, delta briefs, and review windows — 2026-03-23

Purpose: name the next adjacent cluster worth harvesting after epoch stamps and stale fences.

The question is no longer only:
- what exact footing did older trust bind to?
- does that trust still bind the current footing?
- and is the stronger rung current, unsynced, narrowed, or reset-class?

The next humane question is:

**what changed since that exact footing, and should I care enough to inspect, re-review, or act differently?**

That does **not** mean a giant timeline,
ambient recap engine,
or shell-wide memory religion.
It means a tiny truthful surface over stronger shell grammar Helm already has or is already warming:
- delta briefs,
- footing marks,
- salience lenses,
- coverage witnesses,
- blindspot rails,
- quiet witnesses,
- semantic recipe cards,
- serve-path strips,
- replay capsules,
- variance cards,
- action-fit strips,
- access verdict cards,
- and epoch / stale-fence posture.

## Main judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Do not change that.

But the next adjacent datacube luxury worth warming now looks like:
- **delta briefs** bound to exact `from` and `to` footing,
- **since cards** as the tiny rendering most operators will actually touch,
- **salience lenses** so the brief says what kinds of change counted,
- **quiet witnesses** so `no qualifying change` stays stronger than an empty diff slot,
- and maybe later bounded **review windows** or **recheck windows** when Helm wants one exact answer to what changed since the footing a human actually reviewed.

## What a delta brief should answer now

A compact delta brief should answer a narrow question:

**between the exact footing this trust bound to and the exact footing I am seeing now, what changed, what stayed stable, and what inspect path matters next?**

Useful early contributors:
- exact `from_basis_ref`
- exact `to_basis_ref`
- basis class labels such as `last-reviewed`, `last-confirmed`, `shared-base`, `published`, or `live-now`
- changed axes or changed slices
- stable anchors that prevent panic
- one salience lens telling what counted in the compact answer
- one coverage / blindspot note when the answer is partial

The point is not a giant diff.
The point is that Helm should stop asking people to infer meaningful change from timestamps or inherited badges alone.

## What a since card should answer

A since card is the tiny render that should be able to say things like:
- since `last-reviewed epoch 12`, the recipe changed and one dependency became stale
- since `last-confirmed`, rows changed but the contract did not
- since `last-visited`, only watch/owner posture changed
- since `published v4`, the current answer is using cache instead of live direct

That is much more humane than one `updated` label.

## What a salience lens should answer

A good change brief should also say what counted as meaningful.
For example:
- `review-critical`
- `operator-risk`
- `serving-path`
- `freshness-only`
- `audience-change`
- `structure-only`

The first point is not perfect scoring.
The first point is to keep a compact brief from either over-reporting harmless churn or hiding the change that matters.

## What a quiet witness should answer

A quiet witness is the strong sibling of `nothing changed`.
It should say:
- what exact footing was compared,
- under what salience lens,
- over what coverage window,
- and whether the quiet answer had any blindspots.

That keeps silence from collapsing into:
- no data,
- stale last-known,
- muted delivery,
- or incomplete inspection.

## What to keep from older Helm work

### 1. Keep epoch stamps and stale fences
A delta brief becomes much more honest once the shell already knows what exact footing older trust was bound to.
That means delta briefs should increasingly sit *beside* epoch/stale-fence truth,
not replace it.

### 2. Keep replay capsules and variance cards
Replay and compare stay the stronger source surfaces.
A delta brief should open them,
not impersonate them.

### 3. Keep action-fit strips and access verdict cards
Change only matters in context.
A brief should increasingly be able to say not just `what moved`,
but also whether the stronger rung is now fenced,
narrowed,
or still fine.

### 4. Keep coverage witnesses and blindspot rails
The brief should confess when the compared answer did not cover one lane,
one dataset family,
or one cold/unhydrated region.

## New move worth stealing hardest: review-relative change
This is the brightest new move in the pass.
Some tiny Helm surface should increasingly be able to say:
- reviewed at epoch 12,
- now at epoch 13,
- these three changes are review-critical,
- these two are stable anchors,
- and the stronger act is therefore `inspect` or `re-review` rather than `act now`.

That is much more useful than one stale fence alone.

## Another move worth stealing: strong quiet
Some slices will often have *no* meaningful change under the chosen lens.
A strong `quiet witness` is much healthier than an empty compare slot because it still says what exact bases were compared,
what counted,
and where the blindspots were.

## Lessons we must learn from the past

1. **Timestamps are not enough.**
2. **`Updated` is weaker than typed changed axes.**
3. **A diff is not the same as a review window.**
4. **No-change is stronger when the inspected window and blindspots are explicit.**
5. **Salience should be chosen, not guessed from prestige.**
6. **Partial coverage should confess itself instead of bluffing completeness.**

## What might make Helm super awesome

One proving slice now looks unusually promising:

- one reviewed slice
- one semantic recipe card
- one serve-path strip
- one action-fit strip
- one epoch stamp
- one stale-fence strip
- one compact **since card**
- one optional **salience lens**
- one optional **quiet witness** when there is no qualifying change
- and one inspect path into full compare / replay / access verdict / re-review

That would let Helm say something much better than:
`this changed recently.`
It could say:
`since the exact footing this trust bound to,
these things changed,
these things stayed stable,
this is what counted,
these were the blindspots,
and this is the next stronger inspect or re-review path.`
