# Helm active-borrow beacons + brake rails — 2026-03-22

Purpose: name the next shell-native honesty move that looks worth proving after trusted chrome lanes and host-effect witnesses.

## Main idea

Helm now has stronger answers for:
- where high-risk review lives,
- how stronger acts get approved,
- and how weaker-origin content requests shell-side effects.

The next missing honesty cut is different:

**what does Helm say after power has already been borrowed and is actively hot now?**

The next compact answer looks like:
- **active-borrow beacon**
- **brake rail**

## 1. Active-borrow beacons

An **active-borrow beacon** is a compact shell-owned on-air witness.

It should be able to say things like:
- microphone is hot now
- camera is hot now
- system audio or screen capture is hot now
- this exact tab or reveal cohort is currently being shared
- this automation lane is still able to inject
- this background-presence grant is still actively running
- this inhibit or keep-awake grant is still holding the machine awake

### Why it is worth stealing

A lease window already helps with borrowed-now truth.
But it still does not answer the smaller,
more operator-urgent question:

**what is actually consuming or exposing power right now?**

That is what modern OS and browser indicators keep proving matters.

### What it should not do

- not become a giant privacy dashboard
- not replace the authority window or lease window
- not become a historical receipt
- not pretend the shell has exact hot-state knowledge when the substrate only gives family-level signals
- not blur “recently used” into “on air now”

## 2. Brake rails

A **brake rail** is the nearby shell-owned control companion for an active-borrow beacon.

It should keep at least some of these meanings distinct:
- stop now
- pause this exact current subject
- mute or silence while keeping the broader session alive
- narrow from whole-display to current-window or current-tab when supported
- escalate to a fuller revoke handle or manage-access surface

### Why it is worth stealing

The best current systems do not force the user to remember a buried settings route while something sensitive is live.
They keep a nearby brake.

That brake is sometimes exact,
sometimes narrow,
and sometimes coarse.
Helm should confess which it has.

### What it should not do

- not promise exact stop if only a coarse family-wide toggle exists
- not pretend a historical receipt can still brake a live session
- not replace the fuller revoke/narrow/manage object when the operator needs richer aftermath truth
- not turn every little indicator into a modal ritual

## 3. Why these two belong together

An active-borrow beacon answers:
**what exact borrowed power is hot now?**

A brake rail answers:
**what truthful stop or narrowing move is nearest?**

Together they keep several shell truths from collapsing:
- issued once versus live borrowed now versus actively hot now
- exact stop versus coarse emergency brake
- current on-air truth versus recent historical use
- live indicator chrome versus full manage/revoke surfaces

## 4. Best first proofs

### Pull the trigger soon
- warm **active-borrow beacon** as a candidate shell object
- warm **brake rail** as a candidate shell object

### Great first demos
- one screen or tab sharing specimen with exact stop-this-share control
- one mic/camera specimen with visible hot-state and a truthful mute/stop route
- one automation/background specimen with shell-owned on-air truth and a kill or hold rail
- one Operations Center row that keeps **issued lease**,
  **borrowed now**,
  and **hot now** visibly different

## 5. Pillar pressure

- **Operations Center** benefits the most because it already owns live jobs,
  background presence,
  grants,
  and failures
- **Exchange** benefits when reveal/share/import surfaces can show exact active sharing and nearby exact stop routes
- **Object Browser** benefits when previews and linked views can admit that a thing is visible or streaming right now without bluffing broader authority
- **Omnibox** benefits when quick “stop sharing / mute / pause / narrow” acts can target exact active beacons
- **Desktop Flow** benefits when helper-backed or automation-backed hot-state remains visible and stoppable
- **Recall** benefits when recent-use residue stays weaker than current on-air truth
- **Terminal/Capshell** benefits when raw or PTY content cannot impersonate shell truth about what capture,
automation,
or reveal is currently active

## Judgment

Helm still does not need another pillar.
It needs one compact answer to live borrowed power.

The right answer now looks like:
- **active-borrow beacon**
- **brake rail**

That pair looks like one of the clearest remaining ways to make Helm feel more humane,
more trustworthy,
and more shell-native at the same time.
