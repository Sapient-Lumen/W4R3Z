# SlopOS companions evaluation — 2026-03-23 pass CIII

## Current judgment

The companion cubes are converging on one more valuable Helm move:
**a helper escort**.

A helper escort is a compact shell-owned bounded delegation object for one helper,
one exact subject or bounded cohort,
and one narrow family of preparatory or observational acts.
It should be weaker than a live authority window,
weaker than an operator-direct lane,
and weaker than a gesture runway that spends the final human seam.

## What SlopOS keeps teaching

### 1. Lease shape matters more than broad permission stories
SlopOS keeps treating temporary authority as a first-class shape rather than a vague remembered mode.
Its lease work says bounded delegation should be:
- attenuated,
- short-lived or use-limited,
- non-amplifying,
- and honest about what is issuance evidence versus current live truth.

Helm should steal the law,
not the whole archive machinery.
A helper escort should therefore show:
- exact helper / lane identity,
- exact delegated scope,
- expiry / uses / renewal posture,
- and nearby narrow / revoke.

### 2. Issued descriptor is not current live state
SlopOS's lease-descriptor boundary is especially valuable here.
Historical issuance evidence is not the same thing as a currently live grant.
That means Helm should not let a saved recipe,
old handoff packet,
or historical helper session quietly resurrect helper authority.

A helper escort can travel as **historical shape**,
but current helper authority still needs a fresh shell-owned live witness.

### 3. Activation / handoff should stay supervisor-owned
SlopOS's activation-handoff posture is a direct warning:
continuity objects and handoff descriptors should be inbound-only continuity,
not a general export seam for hidden ambient power.

For Helm this means:
- helpers may receive a bounded escort,
- but should not become invisible co-owners of the operator's live authority plane.

## What ViewFS keeps teaching

ViewFS keeps separating object identity,
local name,
durable reopen,
and route intent.
That matters because helper work often wants to blur them.

A helper escort should therefore bind to:
- an exact object ref,
- an exact saved view,
- an exact route family,
- or one explicit bounded cohort window.

It should not bind to fuzzy “whatever this pane currently means.”

ViewFS's query-manifest / snapshot / live-feed split also matters.
A helper escort may permit:
- inspect current snapshot,
- refresh bounded query,
- or derive a proposal,
without granting broad live subscription or silent background following.

## What Schell keeps teaching

Schell is still early,
but its “smallest reviewed action” pressure remains sharp.
The shell must keep reviewed human authorship visible.
That means helper power should stop *before* it impersonates operator choice.

A helper escort fits that shape well:
- the helper can inspect,
  narrow,
  compare,
  draft,
  or prepare
- then emit an action warrant or gesture runway
- while the operator remains the clear author of any stronger act.

## What Steward keeps teaching

Steward's action surfaces and chrome lanes make another rule obvious:
affordances are invitations,
not authority.
Presentation is not the canonical truth.

So Helm should make helper escorts visible in trusted shell chrome,
but that chrome must still admit:
- live now,
- expiring,
- boundary hit,
- revoked,
- historical only,
- or proposal-only.

## Pull-the-trigger judgment

Helm still should not freeze giant helper architecture.
But it now looks wise to warm one compact specimen:

**helper escorts — shell-owned downscoped delegation objects for helpers,
flows,
or repair lanes that can carry narrow,
expiring,
non-amplifying authority without inheriting the operator's ambient reach or satisfying the operator's final human seams.**

## What to keep warm nearby

Keep these adjacent objects distinct:
- shadow work lanes
- adoption harbors
- action warrants
- gesture runways
- authority windows
- delegation subtrees
- caveat sheets

The escort is not a replacement for them.
It is the bounded helper-side delegation object that lets them compose more honestly.
