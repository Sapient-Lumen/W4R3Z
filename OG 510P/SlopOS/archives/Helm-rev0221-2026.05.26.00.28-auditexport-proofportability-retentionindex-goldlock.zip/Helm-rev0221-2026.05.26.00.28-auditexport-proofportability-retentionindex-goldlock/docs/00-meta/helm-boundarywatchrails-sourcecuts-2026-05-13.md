# Helm boundary watchrails and source cuts — 2026-05-13

## Current judgment

The rev0184 door-pack / patrol-route cluster still looks like the right direction.
The new question is what tiny thing makes that cluster materially more honest and more premium.

The answer is a **lightweight boundary watchrail card**.

This is not a pillar.
This is not a data warehouse.
This is not the full SlopOS boundary-family coverage map.
This is the smallest surface grammar that prevents Helm's most powerful objects from becoming ambient magic.

## Pull-trigger decision

Pull the trigger now on the card.

Do not pull the trigger yet on:
- a new Helm pillar,
- a global workspace/dashboard constitution,
- a canonical semantic layer,
- a table/lakehouse backend choice,
- or full SlopOS-style family coverage gates.

## The card

Every serious saved view, door pack, patrol route, triage lane, review queue item, peek/glance surface, imported arrival, and promoted output should be able to show this card.

### Required fields

1. **Subject family** — what family of thing is this? View, route, queue item, import, receipt, action proposal, published artifact, local realization, etc.
2. **Exact subject ref** — the strongest handle Helm can name. If not exact, say nearby, derived, imported, or unresolved.
3. **Source cut** — exact pinned cut, floating current head, historical tag, imported snapshot, query-shaped slice, manually observed glimpse, or derived summary.
4. **Serving lane** — live-direct, cached, precomputed, frozen snapshot, live subscription, remote provider view, or local reconstruction.
5. **Scope / adoption posture** — personal, shared, imported, restricted, adoptable, adopted, promoted, published, activated.
6. **Promotion path** — peek, inspect, review, adopt, promote, publish, activate, settle.
7. **Invalidators / stale fence** — what event makes this card stale or weaker.
8. **Receipt / lineage path** — where to inspect who made it, what basis was used, what survived, and what changed.

## Why the card belongs now

The door-pack / patrol-route cluster creates useful adjacency:
- saved views near handles,
- peeks near queues,
- imports near adoption,
- personal views near shared surfaces,
- review near promotion,
- preview near action.

Useful adjacency is also where old desktops and modern dashboards lie by accident.
A watchrail card lets Helm make adjacency feel effortless without pretending adjacent means identical.

## Seven pillar effects

### Tiling Shell

Tiling Shell should show when a pane is live, restored, repaired, pinned, cached, imported, or derived.
Its pact is simple:
**arrangement is not truth**.

Watchrail chips:
- source cut,
- serving lane,
- restoration basis,
- stale/repair posture.

Never claim:
- that a returned pane is still current merely because the layout survived.

Awesome move:
- a layout return card that says `same layout / weaker data / exact receipt survives`.

### Omnibox

Omnibox should disclose exactness, source, action scope, and serving lane before the operator executes.
Its pact:
**suggestion is not authorization**.

Watchrail chips:
- exact vs nearby,
- personal vs shared,
- live vs cached,
- action grant scope,
- preview/adopt/promote verb class.

Never claim:
- that a result is the intended object when it is a fuzzy match.

Awesome move:
- omnibox result rows with tiny source-cut and next-safe-verb badges.

### Object Browser

Object Browser is the natural inspector for watchrail cards.
Its pact:
**inspection names multiple truths without collapsing them**.

Watchrail chips:
- live provider facet,
- saved view facet,
- imported snapshot facet,
- local realization facet,
- receipt facet.

Never claim:
- that one facet is the whole object.

Awesome move:
- the `same object, five truths` inspector.

### Operations Center

Operations Center owns queues, stale fences, patrols, review lanes, and promotion movement.
Its pact:
**queued is not settled**.

Watchrail chips:
- reviewed basis,
- latest basis,
- stale reason,
- promotion gate,
- receipt path.

Never claim:
- that earlier review survives a basis-changing event.

Awesome move:
- review queue items that fail beautifully with an exact invalidator and a safe recheck button.

### Desktop Flow

Desktop Flow turns action paths into explicit proposals, reviews, and receipts.
Its pact:
**automation is not ambient authority**.

Watchrail chips:
- input source cut,
- grant scope,
- proposed effect,
- preview warrant,
- enactment receipt,
- settlement witness.

Never claim:
- that a model/tool output became local truth without adoption.

Awesome move:
- every flow output lands restricted until adopted, and its card explains why.

### Recall

Recall brings back saved, historical, imported, and receipt-backed context.
Its pact:
**remembered is not live**.

Watchrail chips:
- historical tag,
- recall source,
- last checked basis,
- known invalidators,
- live recheck option.

Never claim:
- that a remembered state is current because it is vivid.

Awesome move:
- recall cards that separate `what you saw`, `what you saved`, `what happened`, and `what is live now`.

### Exchange

Exchange handles transfer, import, adoption, publishing, and receipt across boundaries.
Its pact:
**received is not adopted**.

Watchrail chips:
- sender claim,
- transfer envelope,
- restricted arrival,
- fit check,
- adoption receipt,
- published subset.

Never claim:
- that an incoming packet can mutate local authority by arriving.

Awesome move:
- transfer packets arrive as beautiful but weaker objects with an obvious adoption ladder.

### Terminal / Capshell

Terminal/Capshell remains a front-end family rather than a core pillar.
Its pact:
**power commands must show basis and blast radius**.

Watchrail chips:
- capability scope,
- working set,
- source cut,
- dry-run/preview strength,
- command receipt.

Never claim:
- that command-line compactness justifies hidden authority.

Awesome move:
- capshell command previews that show the same watchrail grammar as visual surfaces.

## Super-awesome product moves

### 1. Peek with teeth

Peek is beautiful, fast, and reversible.
It shows:
- source cut,
- serving lane,
- personal/shared/imported posture,
- safe next verbs.

It does not adopt, publish, activate, or settle.

### 2. Door-pack manifest card

A door pack declares:
- saved views it contains,
- exact handles it opens,
- imported arrivals it exposes,
- queue lanes it watches,
- patrol stops it includes,
- stale fences it respects,
- promotion verbs it allows.

### 3. Patrol route as a daily ritual

A patrol route is not a dashboard.
It is a round:
- start,
- inspect,
- peek,
- compare,
- triage,
- promote,
- leave receipt.

### 4. Queue that refuses beautifully

When a queue item is stale, it should not merely error.
It should say:
- reviewed at this cut,
- invalidated by that change,
- safest next move is recheck / compare / decline / split / rebase / adopt weaker.

### 5. Semantic receipt stack

For promoted artifacts, Helm can show a stack:
- source definition,
- dimension/filter cut,
- serving lane,
- review basis,
- adopter,
- durable receipt.

## Proof specimen

The next proof specimen should be small:

- one serious saved view,
- one door pack around it,
- one patrol route through it,
- one imported arrival that remains restricted,
- one peek surface,
- one review queue item,
- one promotion to local truth,
- one receipt trail.

Every object in that loop carries the same watchrail card.
If that feels amazing, then Helm has earned the next layer of machinery.
