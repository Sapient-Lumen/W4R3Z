# Helm pillar pressure map — 2026-03-22 — addendum

Purpose: continue fleshing out the seven pillars by naming the highest-value steals,
what old inspirations still deserve protection,
and which temptations now look actively harmful.

## Global judgment

The seven pillars still look right.
Helm gets better now by giving each pillar one or two signature delights,
not by minting more pillars.

## 1. Tiling Shell

### Keep from the older inspirations
- keyboard-first movement
- overview,
  split,
  and adjacent inspection as native shell verbs

### Steal now
- **peek → split / focus / open** promotion
- **profile-scoped spaces** that keep account/history/cookie posture separate
- **saved layouts as front doors** rather than fake continuity proof

### Resist
- pure placement religion
- saved layouts pretending to be current-live truth

## 2. Omnibox

### Keep from the older inspirations
- summon speed
- typed pivots instead of one giant mixed bag

### Steal now
- **parameterized quick actions / front doors**
- **exact object + exact action** pairings
- **suggestion-first triage hints** with explain-why posture
- **review freshness chips** near stronger actions

### Resist
- ambient context scraping masquerading as magic
- one mixed result row pretending preview,
  execution,
  and live completion are the same state

## 3. Object Browser

### Keep from the older inspirations
- query-first browsing
- preview and exact reveal
- multiple explicit views over one truth

### Steal now
- **saved view objects**
- **linked / mirrored weak views**
- **context modes** that switch one structure across several environments
- **per-instance review** when downstream effects are concrete

### Resist
- giant dashboard religion
- browser chrome or labels quietly becoming object identity

## 4. Operations Center

### Keep from the older inspirations
- live task truth over process theater
- inspectable jobs,
  routes,
  failures,
  and repairs

### Steal now
- **a dedicated triage lane**
- **designated-review / visibility-only audience lanes**
- **stale-on-diff review warnings**
- **current-only grant posture** for stronger moves

### Resist
- admin-console cosplay
- hidden background mutation or silent auto-apply

## 5. Desktop Flow

### Keep from the older inspirations
- desktop programming as a first-class power
- debug / hold / inspect truth

### Steal now
- **saved-plan / inspect / apply** posture for stronger flows
- **parameterized starters** instead of brittle template duplication
- **adoption-first delegated work**

### Keep warm
- managed-facet ownership ideas
- collaborative partial-authority edits

### Resist
- decorative spaghetti
- “agent did it” as enough provenance

## 6. Recall

### Keep from the older inspirations
- exact reentry
- checkpoint / branch / compare rather than vague recent-items memory

### Steal now
- **checkpoint branches**
- **continuity postcards** that say what can be resumed and what cannot
- **private/local recall controls** like pause,
  filter,
  and delete
- **historical title / badge humility**

### Resist
- one giant total timeline religion
- restored labels quietly impersonating current-live truth

## 7. Exchange

### Keep from the older inspirations
- typed transfer
- inspectable attach / import / publish distinctions

### Steal now
- **receiver-fit front doors**
- **visibility-only audiences**
- **restricted import posture** before adoption
- **weak synced mirrors** for repeated read-mostly reuse

### Resist
- ambient sync mythology
- publication that impersonates receiver-side activation

## Pull soon

1. parameterized front doors
2. inert peek → promote
3. exact-scope / current-only grant ladders
4. stale-on-diff reviewed-basis posture
5. triage lane with explainable suggestions

## Keep warm

1. synced weak mirrors
2. context modes
3. notebook-like evidence briefs with live hooks
4. managed-facet ownership / partial authority

## Closing judgment

If Helm protects the old inspirations where they were actually strong,
and steals newer ideas only at their product-law level,
it can become both more magical and more trustworthy at the same time.
