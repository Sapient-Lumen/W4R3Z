# SlopOS + companions evaluation — pass XCII

This pass sharpened one small question:

**what should Helm learn from design-phase companion cubes about post-act truth without turning into a giant workflow console?**

## SlopOS still teaches the deepest rule

SlopOS keeps paying off when it insists on:
- exact admission seams,
- request-versus-live humility,
- lease discipline,
- and the rule that admission is weaker than downstream completion or current liveness.

That is exactly the frame Helm needs for stronger acts.
A strong shell action may be accepted,
may begin,
may partially land,
may leave residue,
and may later drift away from current-live truth.
Those should not collapse into one green success story.

So the bounded take from SlopOS is:
- keep strong acts on explicit shell seams,
- keep exact request / admission / aftermath / current-live truth visibly distinct,
- and do not let a provider-local completion story silently impersonate shell-wide historical truth.

## ViewFS is the clearest companion teacher for partial aftermath

ViewFS keeps reinforcing that:
- observe,
- attach,
- control,
- effective active state,
- and durable history
are different seams.

That directly helps Helm here:
- an **action warrant** is not an **effect receipt**,
- an **effect receipt** is not a **current-live beacon**,
- and a **slot verdict ledger** is not a hidden merge engine.

That separation is valuable because a truthful shell answer after a stronger act is often two-layered:
- one whole-act historical receipt,
- plus one slotwise ledger when the whole surface would be too coarse.

## Schell and Steward make the shell-facing answer clearer

Schell keeps teaching that reviewed or stronger shell decisions should cross one trusted shell-owned seam,
not dissolve into app prose or terminal folklore.
That makes **effect receipts** feel locally earned:
a small shell object can carry exact basis relation,
outcome class,
affected-set witness,
and nearby reverse / repair / compare moves.

Steward keeps sharpening the status side of the same lesson.
A shell that says only "success" is lying by compression.
For post-act truth,
Helm should keep at least these states visibly distinct:
- applied exact,
- applied partial,
- pending follow-on,
- refused,
- duplicate-suppressed,
- superseded,
- historical only,
- and current-live relation unknown / changed / matching.

## What Helm should steal

1. **Historical effect truth should be durable.**
   Not just a toast or a transient activity row.

2. **Whole-act truth and slotwise truth should compose instead of competing.**
   A receipt can say what happened overall.
   A ledger can say which exact pieces landed or failed.

3. **Subset rerun should preserve history rather than rewrite it.**
   Repair should point back to the original effect.

4. **Current-live truth must remain weaker or stronger on its own seam.**
   Historical success is not present liveness.

5. **Keep the shell object small.**
   Helm does not need a giant runbook center.
   It needs one honest receipt pair for stronger aftermath.

## What not to steal

- giant workflow-state ontologies
- universal task-console ambition
- generic green success chips that erase partiality
- history rewriting when only a subset is rerun
- letting a durable receipt masquerade as present-live state

## Judgment

Because SlopOS and Schell are still design-phase systems,
Helm should still steal **their laws more than their machinery**.
This pass says one more law is now worth warming:

> after a stronger act,
> the shell should keep exact historical effect truth and exact partial-slot aftermath truth visibly separate from current-live truth,
> while still making repair or rerun nearby.
