# Research bibliography — 2026-03-21 — pass V

## Internal teacher cubes

- Helm-rev0010-2026.03.21.04.18-rehearsalcards-capsulediffs.zip
- SlopOS-rev0576-2026.03.21.06.08-openuri-speculative-loading-boundary.zip
- Schell-rev0031-2026.03.21.02.14-completioncards-paramhelp-preflighthonesty-originbadges-hintfoundry.zip
- DelayBasin-rev0142-2026.03.21.10.03-sessionaffinity-stickyreuse-shadowgate-nosessioncourt-affinityglass.zip

## External sources consulted in this pass

- PowerToys Command Palette overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- PowerToys Command Palette extensibility overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/extensibility-overview
- PowerToys Workspaces — https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- PowerToys FancyZones — https://learn.microsoft.com/en-us/windows/powertoys/fancyzones
- PowerToys Peek — https://learn.microsoft.com/en-us/windows/powertoys/peek
- Raycast Quicklinks — https://manual.raycast.com/quicklinks
- Raycast Dynamic Placeholders — https://manual.raycast.com/dynamic-placeholders
- Raycast Snippets — https://manual.raycast.com/snippets
- Raycast API List / Detail docs — https://developers.raycast.com/api-reference/user-interface/list and https://developers.raycast.com/api-reference/user-interface/detail
- GNOME Shell overview / workspaces / keyboard navigation — https://help.gnome.org/gnome-help/shell-introduction.html and https://help.gnome.org/gnome-help/shell-workspaces.html and https://help.gnome.org/gnome-help/keyboard-nav.html
- Obsidian Workspaces — https://help.obsidian.md/plugins/workspaces
- VS Code user interface / timeline / local history / agent sessions docs — https://code.visualstudio.com/docs/getstarted/userinterface and https://code.visualstudio.com/updates/v1_66 and https://code.visualstudio.com/docs/copilot/agents/overview and https://code.visualstudio.com/updates/v1_107 and https://code.visualstudio.com/updates/v1_86
- Node-RED sidebar / debug / subflows docs — https://nodered.org/docs/user-guide/editor/sidebar/ and https://nodered.org/docs/user-guide/editor/sidebar/debug and https://nodered.org/docs/user-guide/editor/workspace/subflows
