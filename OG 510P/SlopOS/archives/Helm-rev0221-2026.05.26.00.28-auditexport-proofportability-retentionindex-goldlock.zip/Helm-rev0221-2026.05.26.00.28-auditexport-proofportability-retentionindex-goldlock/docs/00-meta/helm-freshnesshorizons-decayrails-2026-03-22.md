# Helm freshness horizons + decay rails — 2026-03-22

Purpose: name the next shell-native honesty move that looks worth proving after active-borrow beacons and brake rails.

## Main idea

Helm can now say more clearly:
- what power was issued,
- what power is borrowed now,
- what is actively hot now,
- and what brake is nearest.

The next missing honesty cut is smaller but important:

**how long does a live-looking claim stay trustworthy if it is not renewed?**

The next compact answer looks like:
- **freshness-horizon chip**
- **decay rail**

## 1. Freshness-horizon chips

A **freshness-horizon chip** is a compact shell-owned witness that says:
- when this live-looking claim was last confirmed,
- how long it may still be treated as current,
- and what class it should fall to after that.

It should fit next to things like:
- current-live beacons
- active-borrow beacons
- condition strips
- watchpoints
- glance derivations
- recall reopen cards

### Why it is worth stealing

Helm already has freshness windows as a broader law.
But many shell surfaces need something smaller and more immediate.

The chip answers the operator question:

**is this still current,
or am I only looking at the last thing the shell knew?**

### What it should not do

- not become a universal TTL dashboard
- not pretend time alone is authority
- not replace exact source/basis witnesses
- not flatten hot-now,
  last-confirmed,
  stale-while-revalidating,
  and historical-only into one “maybe current” badge

## 2. Decay rails

A **decay rail** is the nearby shell-owned rule and action family for what happens once a freshness horizon passes.

It should be able to support moves like:
- revalidate now
- keep showing as stale-while-revalidating
- downgrade to last-confirmed
- hold stronger action until refreshed
- reopen exact source
- clear the stale current-looking claim

### Why it is worth stealing

The bad historical pattern is familiar:
- a spinner lingers,
- a green badge never dies,
- a share indicator looks current long after the substrate stopped talking,
- or a restored card keeps sounding live because nothing explicitly told it to stop.

A decay rail gives Helm one shell-owned answer:
**when renewal stops,
what truthful downgrade happens next?**

### What it should not do

- not auto-refresh in ways that silently mutate the meaning of a reviewed or saved surface
- not keep stale content looking strong just because the shell is being polite
- not block every stale surface if a weaker served-stale posture is acceptable
- not invent one universal decay ladder for every family

## 3. Why these two belong together

A freshness-horizon chip answers:
**how long can I still trust this claim as current?**

A decay rail answers:
**what exactly happens when that confidence expires?**

Together they stop several shell truths from collapsing:
- current versus last-confirmed versus historical
- hot now versus recently used
- stale but usable versus stale and blocked
- exact revalidation versus generic refresh folklore

## 4. One wise trigger to pull now

This pass looks strong enough to tighten one law:

**every shell-owned current-live or hot-state claim should carry `last_confirmed_at` and one visible freshness horizon.**

Not every family needs the same chrome yet.
But the law itself now looks worth adopting.

## 5. Best first proofs

### Pull the trigger soon
- warm **freshness-horizon chip** as a candidate shell object
- warm **decay rail** as a candidate shell object

### Great first demos
- one active-borrow beacon that falls from **hot now** to **last confirmed** when renewal evidence stops
- one Operations Center row that says **stale while revalidating** instead of bluffing current success
- one Recall reopen card that is clearly **remembered** after freshness expires
- one stronger action whose review basis flips to **must revalidate** once the horizon passes

## 6. Pillar pressure

- **Operations Center** benefits the most because it already owns current jobs,
  grants,
  background presence,
  failures,
  and now on-air truth
- **Recall** benefits because restored and historical surfaces stop sounding accidentally live
- **Object Browser** benefits because glances,
  watchpoints,
  and previews can stay helpful without bluffing freshness
- **Exchange** benefits because live reveal and live share surfaces can admit last-confirmed versus on-air-now posture
- **Omnibox** benefits when quick actions can prefer fresh targets and warn on stale ones
- **Desktop Flow** benefits when helper-backed or observed graph state degrades visibly instead of sticking forever
- **Terminal/Capshell** benefits when shell-owned status stays independent from stale PTY residue

## Judgment

Helm still does not need another pillar.
It needs one tighter live-truth law.

The right next answer looks like:
- **freshness-horizon chip**
- **decay rail**

That pair looks like one of the clearest remaining ways to make Helm feel more trustworthy,
less haunted by stale state,
and more shell-native at the same time.
