# SlopOS + companions evaluation — 2026-03-23 pass CXLVII

## Why this pass happened

The last Helm revision made **delta briefs, since cards, salience lenses, quiet witnesses, and maybe later review windows** the next adjacent honesty cluster.

This pass asked the next nearby question:
**once Helm can say what changed since the footing trust bound to, how should it decide what strength of re-review that change really deserves?**

The companion cubes again point in the same direction:
freeze the law that matters,
keep shell-owned truth stronger than explanation,
and do not let a design-phase convenience become hidden standing approval.

## What SlopOS still teaches best

### 1) Exact reviewed footing matters more than generic freshness
SlopOS remains strongest as a discipline engine.
Its most useful lesson here is still that assurance binds to exact bounded footing.
That makes it a direct teacher for Helm re-review gates.
A later gate should increasingly point at the exact footing being re-opened,
not just say `stale`.

### 2) Assured history is still smaller than current authority
SlopOS also keeps the recency / assurance boundary sharp.
That means Helm should be very suspicious of any design that lets old review glow float forward merely because the same slice name still exists.

## What ViewFS now teaches best

### 1) Basis / drift / reconsent is the right local grammar
ViewFS still gives Helm the cleanest internal split:
exact prior basis,
present drift check,
fresh reconsent,
and renewed artifact are different truths.
That maps almost perfectly onto the new seam.
A Helm delta brief can say what changed.
A change class can say what kind of drift it was.
A re-review gate can say whether that drift only reopens inspect,
requires fresh review,
or requires a stronger reconsent-class move.

### 2) Renewal can narrow instead of only extending
ViewFS also reminds Helm that the next move after change is not always `approve again`.
Sometimes the healthy move is to narrow,
fall back to inspect-only,
or force a fresh chooser.
That is strong pressure against one universal reapproval ladder.

## What Ward now teaches best

Ward remains the local teacher for **reset-class** truth.
Its root epochs,
delegation freezes,
and threshold resets say that some later changes are not ordinary drift at all.
That means Helm should likely preserve one change class that does *not* reopen ordinary review,
but instead reopens reset,
reacquire,
or out-of-band recovery truth.

## What Steward now teaches best

Steward's semantic epochs and readiness-generation posture keep the same law alive:
observations can belong to an older semantic or observed generation even while the current desired footing has moved on.
That is great pressure for Helm.
A re-review gate should increasingly be able to say not just `changed`,
but whether the changed footing is logical,
observed,
serving,
or semantic-path drift.

## What Foundry now teaches best

Foundry's reacquire rail is the sharpest teacher for the hard edge of this pass.
It says some generation changes do not deserve a normal review loop at all.
They require reacquiring the thing that gave the older trust its force.
That should keep Helm from pretending every reset-class change is just another compare card.

## Lessons Helm must learn from the past

### Must learn #1: not every change deserves the same ritual
Metadata drift,
serving-path drift,
semantic-recipe drift,
and reset-class drift should not all open the same gate.

### Must learn #2: partial carry-forward must stay smaller than fresh review
Some truths may carry forward:
owner,
audience,
unchanged stable anchors,
old notes,
or still-valid downstream checks.
But carry-forward should stay visibly weaker than a new review bound to the newest footing.

### Must learn #3: compare depth matters
A row-level discrepancy,
a value-level discrepancy,
a changed dependency,
and an unvalidated downstream consumer are different review inputs.
Helm should not mash them into one `changed` sticker.

### Must learn #4: some changes are ordinary drift, some are reset-class
Ward and Foundry keep saying this.
Helm should listen.
Some gates should say `review again`.
Some should say `reacquire` or `reset`.

## Current Helm judgment

Keep **settlement witnesses + commit cards** as the admitted next shell-wide ratchet.
Do not move that.

But the next adjacent cluster worth warming now looks like:
- **change classes**
- **re-review gates**
- and maybe later **carry-forward rails** or **review packets**

That cluster looks unusually well-supported by SlopOS,
ViewFS,
Ward,
Steward,
and Foundry together.
It could make Helm super awesome because it would let the shell say:
**this slice changed in these ways,
this older review still carries these weaker truths,
and this is the exact strength of re-review or reacquire work now required.**
