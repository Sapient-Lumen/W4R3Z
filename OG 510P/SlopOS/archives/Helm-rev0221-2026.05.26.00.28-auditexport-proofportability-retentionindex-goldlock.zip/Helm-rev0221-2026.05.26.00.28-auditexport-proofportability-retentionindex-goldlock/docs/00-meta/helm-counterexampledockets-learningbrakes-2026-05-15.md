# Helm counterexample dockets and learning brakes — 2026-05-15

Revision: rev0196  
Focus: proving that guarded learning can be wrong safely

## Main judgment

Pull the trigger on **counterexample cases**. Do not pull the trigger on a memory engine, ranking engine, recommender, policy engine, or feature-flag control plane.

rev0195 let Helm learn from settlement. rev0196 makes the learning accountable by giving every learned precedent one explicit way to be challenged.

## Why this is the next hard layer

A product that remembers but cannot be corrected becomes folklore. A product that remembers and visibly narrows itself becomes trustworthy.

The next hard question after precedent cards is not “how do we rank learned suggestions?” It is:

**what record proves this learned suggestion overfit, and what must Helm do when that happens?**

## What we kept from older Helm inspiration

The old calibration, miss-ledger, coverage-gap, and attention-turn notes were pointing at this: useful automation must expose its misses. The counterexample case is the tightest version of that idea for the current proof ladder.

## What we peeled away

- no broad model evaluation layer;
- no personal memory plane;
- no hidden score/ranking update;
- no incident platform;
- no policy language;
- no workflow/retry engine;
- no new pillar.

## The new product feel

A precedent strip can now say:

`Learned warning available • counterexample found: cosmetic drift should not prefill refusal • require material-basis diff • inspect / keep note / demote`

That is the “super awesome” move: Helm can be confidently helpful without pretending its learned habits are law.

## Lessons we must learn from the past

1. **A memory without counterexamples becomes superstition.**
2. **A shape match is not identity.**
3. **A failing row is often more valuable than a passing dashboard.**
4. **A useful default must have a visible brake.**
5. **Coverage gaps break default routing even when the learned route is otherwise reasonable.**
6. **The user should be able to inspect why Helm learned and why Helm stopped trusting that learning.**

## Next work

Prototype the actual precedent/counterexample strip and move one case into a second specimen. The test: can the same object weaken learned behavior outside release readiness without importing a ranking engine?
