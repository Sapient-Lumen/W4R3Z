# Research bibliography — pass CLXXXI — 2026-05-13

- Databricks docs — Unity Catalog metric views / model metric views — https://docs.databricks.com/aws/en/business-semantics/metric-views/
- Databricks docs — metric-view modeling — https://docs.databricks.com/aws/en/business-semantics/metric-views/basic-modeling
- dbt docs — Semantic Layer / metrics — https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl
- Cube docs — pre-aggregations — https://cube.dev/docs/product/data-modeling/reference/pre-aggregations
- Cube docs — using pre-aggregations — https://cube.dev/docs/product/caching/using-pre-aggregations
- Apache Iceberg docs — branching and tagging — https://iceberg.apache.org/docs/latest/branching/
- Apache Iceberg docs — snapshots and procedures — https://iceberg.apache.org/docs/latest/spark-procedures/
- DuckLake docs — snapshots — https://ducklake.select/docs/stable/duckdb/usage/snapshots.html
- OpenLineage docs — facets and extensibility — https://openlineage.io/docs/spec/facets/
- OpenLineage docs — object model — https://openlineage.io/docs/next/spec/object-model/
- OpenTelemetry docs — signals — https://opentelemetry.io/docs/concepts/signals/
- OpenTelemetry docs — context propagation — https://opentelemetry.io/docs/concepts/context-propagation/
- OpenTelemetry docs — baggage — https://opentelemetry.io/docs/concepts/signals/baggage/
- Observable Framework docs — data loaders — https://observablehq.observablehq.cloud/framework/data-loaders
- ElectricSQL docs — client development / shapes — https://electric.ax/docs/sync/guides/client-development
- LiveStore docs — materializers — https://docs.livestore.dev/reference/state/materializers/
- Linear docs — triage — https://linear.app/docs/triage
- GitHub docs — managing a merge queue — https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue
