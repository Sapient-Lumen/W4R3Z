# Archive index — Helm rev0221

- Surface: `Helm-rev0221-2026.05.26.00.28-auditexport-proofportability-retentionindex-goldlock`
- Basis: `Helm-rev0220-2026.05.25.23.59-appealcorrection-reopenreceipts-invariantindex-silverlock.zip`
- New proof layer: portal-net audit/export proof portability.
- Audit/refactor: portal retention index.

See `RELEASE-MANIFEST.json` for command list and surfaces.
