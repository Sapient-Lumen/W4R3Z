# AGENTS — Helm rev0221

Work in this archive as a proof fixture, not a runtime implementation.

Current head: `Helm-rev0221-2026.05.26.00.28-auditexport-proofportability-retentionindex-goldlock.zip`.

For portal-net consent/export work, keep these separations explicit:

- Helm makes authority legible; SlopOS makes authority enforceable.
- Notifications and acknowledgements are not success, comprehension, consent, settlement, or authority.
- Appeals, corrections, reopens, external support notes, rectification, and arbitration are evidence with provenance only.
- Correction is not rewrite; reopen is not silent retry; rectification is not unbounded erasure.
- The portal invariant index is a cube audit surface, not policy or layer-pass oracle.
- Do not import an appeal engine, correction workflow, support-ticketing system, moderation queue, rectification protocol, review runtime, arbitration engine, policy engine, workflow engine, backend, global memory, or new pillar.

Run `python3 tools/check_appeal_correction_pack.py`, `python3 tools/check_portal_invariant_index.py`, and `python3 tools/check_portal_layer_registry.py` before packaging, then run the validation list in `RELEASE-MANIFEST.json`.


## rev0221 note

Do not treat audit/export bundles, support packages, third-party attestations, machine summaries, offline bundles, or reimport candidates as authority. Run `tools/check_audit_export_pack.py` and `tools/check_portal_retention_index.py` when editing the portal cube.
