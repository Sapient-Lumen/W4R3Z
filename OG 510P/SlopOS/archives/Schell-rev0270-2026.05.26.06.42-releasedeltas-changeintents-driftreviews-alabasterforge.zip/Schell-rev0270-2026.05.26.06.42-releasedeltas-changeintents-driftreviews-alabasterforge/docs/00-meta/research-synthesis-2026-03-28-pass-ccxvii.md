# Research synthesis — 2026-03-28 — pass CCXVII

This pass pulls a tighter lesson out of the current shell/terminal/agent field:
**the next big win is not a bigger shell constitution. It is a sacred draft lane with explicit repo-local helper artifacts, visible loaded-context posture, and plan-first luxury.**

## 1) Current tools keep moving reusable helper knowledge into ordinary files

VS Code prompt files are stored as Markdown files, can live in a workspace `.github/prompts` folder or a user profile, are invoked manually, and can declare an agent plus an explicit tool list.
Claude Code skills are file-backed through `SKILL.md` and can be invoked directly by slash command.
Gemini CLI uses `GEMINI.md` files in a hierarchy that can include global, workspace, parent-directory, and just-in-time context, and it even surfaces the number of loaded context files.

The field lesson is strong:
- file-backed helper artifacts are winning,
- repo-local and parent-repo discovery are useful,
- tool budgets can be attached to helper artifacts,
- but the loaded context must be visible if the system is going to remain trustworthy.

## 2) Manual or inspectable invocation is still healthier than ambient startup magic

VS Code explicitly distinguishes prompt files from automatically applied custom instructions.
That is a very healthy pattern.
It means reusable guidance is discoverable and easy to share without quietly becoming invisible law for every interaction.

For Schell, the lesson is clear:
prefer explicit helper artifacts and explicit loaded-context views over another generation of shell startup/profile folklore.

## 3) Plan-first is now an obvious no-regret steal

Claude Code's plan mode is especially clarifying because it promises planning without file edits or command execution.
That clean separation matters.
A shell+terminal can feel much more capable when it lets the operator ask for a smart plan, diff, or warrant without silently sliding into enactment.

Schell should almost certainly steal this exact class of posture:
- understand,
- plan,
- draft,
- review,
- execute.

## 4) Hooks are powerful enough to be dangerous

Claude Code hooks can run automatically at lifecycle points and receive JSON context about events.
That proves hooks are a real, useful pattern.
But it also highlights the danger: automatic lifecycle machinery can easily become a shadow execution plane.

The research compression for Schell is not “avoid hooks.”
It is:
- let hooks observe,
- let them draft or annotate,
- let them raise review cards,
- but be very careful about direct side-effect power.

## 5) Semantic shell integration keeps paying off beyond navigation alone

VS Code shell integration still shows the value of command and cwd detection.
Contour's OSC 133 documentation makes the protocol floor explicit, including prompt start/end, output start, command finished, optional prompt click events, and an optional exact command-line URL.
Ghostty's newer docs reinforce how much polish falls out of that floor: prompt-click cursor movement, better active-prompt resizing, command-output selection, command-finished notifications, and stronger jump-to-prompt behavior.

This suggests a Schell move that is both small and exciting:
keep semantic marks as the shell-owned floor, then let richer helper artifacts and visible modes stack on top.

## 6) Ghostty contributes several high-value local-UX steals

Ghostty's recent docs are especially rich for Schell because they show small visible luxuries that do not require a giant architecture choice:
- visible key-table indicators for modal bindings,
- fine-grained working-directory inheritance controls for tabs/splits/windows,
- prompt-click editing support on active prompts,
- a debug overlay showing OSC 133 areas,
- command-finished notification thresholds,
- and richer clipboard copy formats including plain text, HTML, and VT-preserving copies.

These are excellent examples of “super awesome without dishonest magic.”

## 7) fish still defines the humane input bar

fish continues to show what a humane interactive shell feels like:
- autosuggestions stay inert until accepted,
- external-editor round trips are one shortcut away,
- undo/redo exists in the command-line editor,
- and bracketed paste plus kill-ring behavior treat the input buffer as a serious editing surface.

For Schell, this reinforces the idea that the draft lane itself deserves first-class design attention.

## 8) Structured shells still argue for typed lenses, not early universal law

Nushell's cell-path model is a strong reminder that field/row/value navigation is deeply useful.
YSH adds a subtler lesson: command language and expression language can remain neighboring lanes instead of collapsing into one universal shell substance.

So the current synthesis stays stable:
- exact command chapters should remain authoritative,
- structured lenses should exist where structure is earned,
- but helper-rich value work still does not force one final universal object constitution.

## 9) Runnable docs are valuable, but review-first defaults still matter

Warp notebooks are searchable runnable documentation and can be exported as Markdown.
That is a compelling idea for operational memory and team workflow.

But in a SlopOS-shaped shell, the strongest take is still smaller than automatic execution.
Runnable docs are best when they are easy to discover, easy to inspect, easy to parameterize, and usually able to land in the draft/review lane before they spend.

## 10) Compact conclusion

The field now points toward a tighter next move for Schell:
- keep semantic marks as the interop floor,
- make the draft lane sacred,
- move helper intelligence into repo-local file-backed artifacts,
- surface loaded-context provenance and counts,
- keep plan mode first-class,
- downgrade hooks by default to observation, drafting, or review,
- and let the terminal make all of that legible with visible modes, inspectors, and command-aware ergonomics.