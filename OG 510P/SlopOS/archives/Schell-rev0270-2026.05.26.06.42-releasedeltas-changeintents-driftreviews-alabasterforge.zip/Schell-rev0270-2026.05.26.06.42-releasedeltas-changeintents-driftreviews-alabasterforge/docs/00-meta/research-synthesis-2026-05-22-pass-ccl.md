# Research synthesis 2026-05-22 pass ccl — proof dockets and adversarial restore

This pass imports a narrow pressure: weak forgetting claims need replayable evidence packets, and replay/restore paths must be treated as adversarial challenge routes.

External pressure folded into rev0253:

- NIST SP 800-88 Rev.2 frames sanitization as access to target data being infeasible for a given level of effort; Schell therefore keeps proof-docket claims weaker than sanitization, erasure, or global forgetting.
- OpenTelemetry sensitive-data guidance emphasizes data minimization and sensitive telemetry handling; Schell therefore records collector/exporter epochs and old backend exports as receiver rows.
- GitHub Actions documentation exposes artifact deletion/expiration and artifact/log retention surfaces; Schell therefore splits artifact, log, annotation, and cache receivers before saying CI memory is gone.
- Kubernetes TTL-after-finished makes finished Jobs eligible for cleanup, honors finalizers, and says nothing about external log sinks; Schell therefore challenges TTL cleanup against side receivers.
- AWS S3 Object Lock/versioning pressure is especially useful: legal holds apply to object versions, simple deletes can create delete markers, and noncurrent protected versions can remain. Schell therefore adds version/delete-marker restore challenges.
- OWASP LLM08 and MCP security guidance keep vector/helper influence, tool consent, and confused-deputy risks in scope even after raw memory is minimized or hidden.

Imported design rule:

```text
A forgetting claim is not just a phrase; it is a custody-bound proof docket plus adversarial restore challenge.
```

Non-imports: no compliance certification, legal advice, provider APIs, backup restore engine, S3 adapter, GitHub cleanup bot, Kubernetes controller, vector rebuild runtime, telemetry rewrite, browser/clipboard cleaner, terminal protocol, or final UI grammar.
