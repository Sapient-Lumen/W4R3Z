# SlopOS datacube evaluation — pass CCXXXVIII

Focus: what Schell should learn from SlopOS about durable evidence custody after settlement.

## Imported discipline

SlopOS continues to be valuable because it refuses to let adjacent evidence become broader truth:

- ACP outcome receipts are stable and redaction-safe, but non-authoritative.
- OpenURI launch-completion boundaries admit only handoff, not downstream app completion or user attention.
- FedCM import boundaries keep browser/login/account/disconnect state provider-local.
- MCP import boundaries split metadata, authorization, prompts, resources, progress, sampling, logging, and tool results into scoped evidence.
- Capshell posture keeps command strings, exec packs, cwd, env, argv, handles, result sidecars, and output normal forms separate.
- Crypto audit schemas keep operations digest-first and redaction-safe.
- Attestation freshness boundaries keep nonce/challenge meaning verifier-local.
- Network idempotency boundaries keep duplicate suppression scoped by parameters, region/zone/provider, and retention window.

## Schell-specific consequence

Schell should add an audit-capsule vocabulary before it adds an audit store. The critical question is not “where do we log everything?” but “can the operator tell which claims are raw, signed, chained, observed, projected, redacted, summarized, imported, stale, or broken?”

The SlopOS-aligned rule for Schell rev0241:

> receipts are evidence, chains are custody, traces are correlation, attestations are provenance, redactions are loss-bearing projections, and imports are historical until rebound.

## What not to copy yet

Do not copy SlopOS schema families wholesale into Schell. Do not freeze canonical CBOR/COSE, ACP kinds, CH-LOG, capshell exec packs, MCP import packets, or attestation token structures as Schell's terminal format. Schell still needs to prove the human-facing custody grammar first.

## Next pressure

Run the AC-PF prediction questions over the audit cases. If operators cannot distinguish raw witness, projection, redaction, helper summary, trace correlation, and imported archive authority from one compact line, Schell should simplify the custody grades before building logging machinery.
