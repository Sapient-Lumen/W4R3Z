# Research synthesis 2026-05-26 pass CCLXX: release deltas, change intents, and semantic drift

Rev0269 made release bytes deterministic enough to cite as bounded package custody. That still leaves a different gap: a byte-stable zip can carry undeclared semantic change. Rev0270 imports four pressures.

- in-toto separates materials, products, authorized functionaries, and expected rules. Schell takes only the bounded lesson: a release step should say what input/output relation is being claimed, and what is not being claimed.
- SLSA provenance and build-definition language pressure Schell to distinguish produced artifact metadata from consumer verification against expectations.
- Reproducible Builds/diffoscope pressure Schell to explain differences without treating a difference report as approval or truth.
- OSCAL assessment-results pressure Schell to keep observations, findings, risks, scope, and disposition separate.

Local bounded take: add a release-delta manifest and change-intent review workset. Explicit non-take: no VCS-native review, signed provenance, in-toto layout, diffoscope report, OSCAL export, CI, policy engine, helper runtime, or SlopOS portal adapter.
