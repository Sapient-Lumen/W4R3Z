# Research synthesis — 2026-03-28 pass CCXXII

This pass compresses a smaller current pattern:
**the best helper-aware terminals are getting stricter about what counts as operator command truth, and more explicit about why helper rooms currently need attention.**
The ecosystem is slowly learning that command history, sticky command chrome, helper-room state, and helper intervention reasons should not all collapse into one flattering stream of “terminal activity.”

## 1) VS Code is explicitly protecting shell history from tool-issued commands

VS Code's December 2025 release notes say that when shell integration is enabled, commands run by the terminal tool are no longer included in shell history for bash, zsh, pwsh, and fish.
It also says this is configurable, which is important because it means the product authors now treat shell-history pollution as an explicit policy decision rather than a side effect of tool execution.

That is a major design lesson for Schell.
Operator journal truth is worth protecting.
If a tool or helper runs a command in the terminal, the system should not quietly pretend that the operator personally authored another ordinary shell-history line.

## 2) VS Code is also admitting that not every command-looking buffer deserves sticky command chrome

VS Code's January 2026 release notes added `terminal.integrated.stickyScroll.ignoredCommands`.
The notes explicitly say that some commands appeared in sticky scroll when that behavior was undesirable, and they specifically call out `clear` plus common agentic CLIs such as `copilot`, `claude`, `codex`, and `gemini`.

That is a second important Schell lesson.
Even when something occupies the terminal buffer, it may still be the wrong kind of thing to promote into the strongest command-local navigation chrome.
A resident agentic room or interactive helper session may deserve rich visibility, but not necessarily “this is your main command header” treatment.

## 3) VS Code's shell integration API still shows the floor: exact command identity and exit belong to shell-known execution

VS Code's shell integration API says extensions can listen to commands run in terminals, read their raw output, exit code, and command lines.
It also provides a more reliable execute path that waits for a prompt before sending the command.
That matters because it keeps reminding us that **strong command truth comes from shell-aware execution boundaries**, not from transcript guesses.

So if Schell keeps one sacred operator journal, it should probably be grounded in shell-authenticated chapters and adoption into the operator input lane rather than in ambient helper activity.

## 4) Codex is giving useful clues about bounded terminal access and typed interruption

OpenAI's Codex changelog says Codex can now read the integrated terminal for the **current thread**.
That boundedness is a clue worth stealing.
The helper does not simply own “the terminal” in the abstract; it is attached to a more local continuity object.

The same changelog also says Codex added notifications for **plan mode questions** so it is easier to notice when Codex needs input.
That is interesting because it treats “needs plan feedback” as a distinct interruption reason, not just one more generic busy/done state.
The March 2026 changelog also says a conversation can be forked from an earlier message, which reinforces the idea that helper continuity can branch without rewriting the main line of operator truth.

## 5) Claude Code is converging on explicit permission modes and explicit notification reasons

Claude Code's VS Code integration docs describe distinct permission modes.
In normal mode it asks permission before each action.
In Plan mode it describes what it will do and waits for approval before making changes, and the plan opens as a full markdown document where the operator can leave inline comments.
Auto-accept is a separate stronger mode.

That is a very good hint for Schell.
Plan/review/help lanes should be visibly different from operator shell execution, and “plan feedback needed” should be allowed to exist as a named state instead of being flattened into one generic prompt.

Claude Code's common-workflows docs and hooks docs deepen the same lesson.
The Notification hook fires when Claude is waiting for permission, idle and ready for a new prompt, or completing authentication, and the matcher can be narrowed to `permission_prompt`, `idle_prompt`, `auth_success`, or `elicitation_dialog`.
That is a compact but powerful state family.
It suggests that helper attention is more useful when it is typed by reason.

## 6) The ecosystem lesson is now sharper than “separate chat and shell”

Older design advice might have stopped at “keep AI in a separate pane.”
The current official docs push something narrower and better:
- keep **operator shell history** distinct from tool-run commands,
- keep **sticky command chrome** selective rather than ambient,
- keep **helper terminal access** bounded to a local continuity object such as a thread,
- and keep **helper attention** typed by reason rather than one vague active/busy badge.

That is a stronger synthesis than merely “have a chat pane.”
It gives Schell a concrete specimen bundle to prove.

## 7) Compact conclusion

The next Schell proof should probably not be a bigger helper runtime.
It should be a **history-and-intervention specimen bundle**:
- one sacred operator journal,
- one helper-lane chapter family,
- one adoption path from helper proposal into operator draft,
- one selective sticky-scroll or chapter-header policy,
- and one compact typed intervention-state family for permission / question / auth / idle / plan feedback.

That would steal a genuinely brilliant cluster from the current ecosystem without deciding the whole shell constitution too early.
