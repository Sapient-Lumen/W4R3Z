# Research synthesis — 2026-05-23 pass cclvi — appraisal policies and evidence-conflict merge

Rev0259 imports a narrow lesson: after Schell measures the runner and plan, it still needs to ask **who appraised that evidence, under which policy, and what happens when evidence disagrees?** The answer is not a verifier runtime. It is a proof surface that keeps appraisal rows, trust roots, reference values, endorsement epochs, relying-party reason codes, conflict sets, dissent lanes, and weakest-supported claims visible.

External pressure, bounded take:

- IETF RATS architecture distinguishes Evidence, Endorsements, Reference Values, Verifiers, Appraisal Policy, Attestation Results, and Relying Party appraisal. Schell imports the two-stage appraisal distinction, not RATS protocols.
- RFC 9711 EAT frames attestation tokens as claims about an entity used by relying parties to decide whether and how to trust. Schell imports critical-claim presence and partial-trust vocabulary, not an EAT profile.
- SLSA verification guidance says provenance is valuable only when someone inspects it against expectations. Schell imports expectation checking for appraisal-policy bundles and proof-runner evidence.
- TCG measured-event guidance emphasizes ordered measurement evidence and reference values. Schell imports reference-value/epoch caution, not TPM parsing.
- Rekor/SCITT transparency pressure distinguishes signed/logged/receipted statements from correctness or deletion truth. Schell imports inclusion-is-not-appraisal.
- W3C Data Integrity pressure says proofs carry parameters needed for verification. Schell imports the idea that public minimization must not destroy escrowed verification rows.
- SlopOS rev0720 keeps append/resume/truncation branch-bound. Schell imports accepted-prefix base digest as a relying-party appraisal row.

Local changes:

- Added `verifier-appraisal-policy-board-v0.json` and rationale.
- Added `evidence-conflict-merge-gauntlet-v0.json` and rationale.
- Added H-0417..H-0428 and RF-0043/RF-0044.
- Extended forgetting proof dockets with appraisal-policy and conflict-merge rows.
- Added lint gates for VAP/ECM proof surfaces.

Non-take: do not implement a RATS verifier, EAT profile, TPM event-log parser, SLSA verifier, in-toto policy engine, Rekor/SCITT monitor, W3C proof verifier, provider resolver, conflict database, human appeal workflow, policy engine, helper runtime, UI, terminal protocol, shell grammar, or SlopOS portal adapter.
