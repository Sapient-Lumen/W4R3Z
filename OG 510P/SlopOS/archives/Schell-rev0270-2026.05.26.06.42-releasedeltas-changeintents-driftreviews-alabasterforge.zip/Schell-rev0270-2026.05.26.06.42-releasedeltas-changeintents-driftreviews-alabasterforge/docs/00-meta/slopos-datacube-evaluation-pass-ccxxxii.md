# SlopOS datacube evaluation pass CCXXXII: authority spend rows for Schell imports

Revision: rev0235  
Date: 2026-05-13  
Context: Schell rev0235, SlopOS rev0695, companion cubes retained as pressure sources.

## 1. What SlopOS teaches this pass

SlopOS rev0695's FedCM/browser-federation boundary is the cleanest companion lesson for Schell's imported terminal cards: useful mediated state is still provider-local until an explicit seam says otherwise. Browser account choosers, login-status maps, connected-account sets, returned tokens, and disconnect choreography do not become portable account/session/control truth by implication.

Schell's equivalent danger is terminal-card convenience. A command card may carry cwd chips, helper policy names, account hints, route labels, redaction manifests, receipt digests, prompt zones, or old replay context. Those are useful evidence. They are not recipient authority.

## 2. Capshell pressure

SlopOS capshell treats complete exec packs as descriptors that validators bind under already-held authority. Schell should mirror that posture: a complete command chapter can be beautifully inspectable and still unable to launch until the recipient basis and action floor are fresh.

The rev0235 arrival simulator is therefore a terminal UX analogue of capshell discipline:

- exact evidence is visible;
- missing receipts are named;
- safe verbs remain fast;
- effectful verbs require a fresh floor;
- reversal claims require current rollback/effect identity.

## 3. Companion-cube pressure

- **ViewFS** reinforces path/locality humility: route and view labels must not become local file authority.
- **Harbor** reinforces lineage and contract subsets: imported cards need source and recipient custody rows.
- **Steward** reinforces reconciliation and cause/condition separation: settlement, timeout, retry, and aftercare need distinct rows.
- **Foundry** reinforces semantic spines and serving lanes: rich card projections are useful only when pinned to raw evidence and downgrade metadata.
- **Helm** reinforces patrol/review queues: quick fixes are review candidates until action floors are satisfied.
- **Ward** reinforces tier witnesses: arrival grades and spend floors are tiered claims, not vibes.

## 4. What Schell should not import from SlopOS too early

Schell should not prematurely clone SlopOS schema machinery. The shell+terminal still needs a cheap, tactile interaction proof before canonical encodings, conflict keys, or formal capability objects are designed. Rev0235 therefore uses a small JSON simulator and lint gate rather than a canonical authority format.

## 5. Recommendation

Keep the SlopOS boundary lesson, not the full substrate weight: make authority spend explicit, source-local facts visible, and unsafe promotions fail closed. Delay final formats until the arrival simulator can be rendered and operators can predict blocked verbs without reading policy docs.
