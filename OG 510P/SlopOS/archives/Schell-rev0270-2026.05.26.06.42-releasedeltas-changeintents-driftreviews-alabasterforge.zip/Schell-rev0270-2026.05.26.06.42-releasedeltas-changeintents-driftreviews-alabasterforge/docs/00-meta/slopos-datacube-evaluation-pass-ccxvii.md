# SlopOS datacube evaluation — pass CCXVII

This pass asks a narrower companion question:
**if SlopOS is already refusing ambient startup, hidden parsing, and replay-bloating result contracts, what helper architecture can Schell safely add without cheating?**

## 1) SlopOS keeps pushing Schell away from ambient helper magic

The capshell posture docs continue to make one thing very clear:
- no hidden command-string plane,
- no shell-style word-expansion stage before reviewed argv,
- no ambient startup/profile sourcing in the core,
- no portable PTY/job-control authority plane,
- and no richer result structure silently widened into the replay-stable contract.

That means Schell should treat classic shell helper patterns — startup files, implicit aliases, auto-rewriting wrappers, and lifecycle glue that quietly executes — as suspect by default.

## 2) The companion-safe answer is explicit helper artifacts, not more startup power

Because `capshell-startup-profile-posture-v0.md` and the neighboring capshell surfaces are already protecting the core from ambient startup influence, Schell's safest place to put intelligence is **outside ambient startup and inside explicit helper artifacts**:
- repo-local skill files,
- prompt/runbook files,
- notebook fragments,
- typed workflow cards,
- context notes,
- and visible helper packs discovered from the repo or parent repo.

That preserves the anti-ambient discipline while still letting the shell become much more useful.

## 3) SlopOS's no-hidden-parser stance strongly favors a sacred draft lane

`capshell-command-string-posture-v0.md` and `capshell-word-expansion-posture-v0.md` matter enormously here.
They mean Schell should not answer helper richness by inventing a second invisible parser or an auto-tokenizing assistant lane.

The right fit is smaller:
- helpers produce exact text or exact argv drafts,
- those drafts enter a visible review/editor surface,
- the operator can inspect, edit, or discard them,
- and only then can the shell spend.

That is almost the perfect companion answer to SlopOS's anti-parser discipline.

## 4) Result-sidecar narrowness teaches how helper intelligence should travel

`capshell-result-sidecar-boundary-v0.md` is a good reminder that richer structure belongs in explicit sidecars rather than being smuggled into the replay-stable core.
The same lesson applies to helper intelligence.

Schell should let skills, notebooks, plans, and hooks produce:
- typed plans,
- diffs,
- diagnostics,
- review cards,
- provenance strips,
- or suggested command drafts.

But those helper products should remain visibly helper products until a reviewed action crosses the real command/execution boundary.

## 5) Hooks are only companion-safe when they stay weaker than execution

SlopOS's no-job-control and no-hidden-authority posture argues strongly against autonomous lifecycle execution hidden behind shell events.
So if Schell adopts hooks, the most companion-safe default classes are:
- observe-only hooks,
- draft-only hooks,
- review-card hooks,
- and notify-only hooks.

That still gives Schell a lot of power while staying honest about where authority lives.

## 6) The neighboring datacubes keep reinforcing the same discipline

The companion cubes continue to point in the same direction:
- **Helm** keeps preview and enactment separate, which strongly supports plan-first and review-first helper flows.
- **Ward** keeps evidence, status, and local consequence apart, which maps neatly onto source-labeled loaded-context posture and helper-footing grades.
- **Foundry** keeps compat and restored continuity visibly foreign/weaker, which warns Schell not to let imported parent-repo/global helper packs impersonate local authoritative intent.
- **Harbor** keeps descriptive measurement smaller than consequence, which suggests that loaded-context counts, helper confidence, and tool budgets should stay descriptive rather than decisive.
- **Steward** keeps activation and aftercare honest, which supports hooks and followthrough surfaces that annotate or propose rather than silently act.

## 7) What Schell can safely steal right now

Given SlopOS's current phase, the companion-safe steals now look surprisingly concrete:
- a sacred draft lane,
- repo-local helper artifacts instead of ambient startup files,
- visible loaded-context meters and provenance panels,
- plan-only helper mode,
- semantic prompt/cwd marks plus a terminal inspector,
- and hooks that default to observe/draft/review instead of auto-spend.

## 8) What still should not be decided yet

SlopOS is still too early to justify freezing:
- one final helper artifact schema,
- one final agent/plugin market,
- one final hook authority model,
- one final universal object shell,
- or one private shell↔terminal protocol stack.

Those are exactly the decisions the archive should continue to delay.

## 9) Compact conclusion

SlopOS does not yet tell Schell what the final smart shell must be.
It does tell Schell something precise about helper architecture:
**put intelligence in explicit file-backed artifacts, make the loaded context visible, keep one sacred draft lane, and let plans/hooks stay weaker than execution until the operator admits the spend.**