# Datacube evaluation pass CCXXVI: SlopOS and sibling lessons for Schell

Revision: rev0229
Date: 2026-05-13
Scope: evaluation of SlopOS rev0695 and adjacent cubes as design pressure for Schell's shell+terminal datacube.

## 1. SlopOS rev0695: FedCM boundary as terminal-boundary teacher

SlopOS rev0695 emphasizes browser federation boundaries: provider-local login or browser-mediated convenience must not become durable account/session/current-user truth. Schell should import that exact pattern.

For a shell+terminal, the parallel hazards are:

- shell-emitted command marks becoming launch truth;
- helper summaries becoming command truth;
- synced history becoming current intent;
- restored panes becoming live process state;
- browser login hints becoming portable account authority;
- remote-hop metadata becoming local basis.

The import is simple: every imported convenience needs a locality label and a receipt grade. Schell should show “provider-local,” “shell-signed,” “helper-proposed,” “restored,” “remote-downgraded,” or “host-known” rather than merging them into a single confident terminal surface.

## 2. Foundry: semantic spines and pinned cuts

Foundry's semantic-spines pattern pushes Schell to keep the command chapter spine thin. A chapter should pin a small set of durable cuts: source, envelope, launch, process-ground, output coverage, basis, actions, downgrades. It should not absorb every terminal feature into one huge schema.

Schell design consequence: put rich views behind lenses and action decks; keep the chapter spine stable and inspectable.

## 3. Harbor: temporal witnesses and contract subsets

Harbor's temporal-witness discipline maps cleanly onto terminal work. Every command chapter is time-bound. Every authority claim is a contract subset. Every rerun is a new event, not a continuation of the old one.

Schell design consequence: restored and rerun commands must compare prior launch basis to current basis. “Same text” is not “same command.”

## 4. Steward: cause versus condition

Steward's cause/condition separation is crucial. A launch receipt says what caused a process to begin. A process-ground strip says what condition the runtime is currently in. A summary says what someone believes happened. These are different surfaces.

Schell design consequence: never collapse `launched`, `still running`, `prompt returned`, `output complete`, `helper summarized`, and `operator reviewed` into one green check.

## 5. ViewFS: prefix badges, folder ghosts, and listing snapshots

ViewFS warns against mistaking projected filesystem views for committed resources. Terminal output has the same issue: a detected path, URL, test name, port, or generated file may be a projection from text.

Schell design consequence: action cards should carry source spans and reveal exact basis. A detected path opens in preview; it does not silently become a file authority claim.

## 6. Helm: door packs, patrol routes, and review queues

Helm gives Schell an excellent vocabulary for action decks. A terminal action card is a door pack: it packages a possible next movement with context, risk, and entry conditions. Patrol routes become attention trails across command chapters. Review queues become the place where helper proposals, package installs, destructive actions, and remote operations wait for adoption.

Schell design consequence: action decks should not be one big command palette. They should be sorted by provenance, risk, and review requirement.

## 7. Ward: fidelity tiers and hybrid seams

Ward's fidelity tiers map onto terminal surfaces:

- raw transcript;
- shell-signed marks;
- host-known receipts;
- inferred lenses;
- helper summaries;
- restored snapshots;
- remote-hop views.

Hybrid seams are unavoidable: PTY, shell, terminal, editor, helper, browser, and OS all meet in the same visible surface. Schell should make seams beautiful and obvious rather than hiding them.

## 8. SlopOS D-LLM / app-local lesson

SlopOS's broader app-local/auth posture reinforces that model capability is not authority. A helper can suggest, observe, edit, or run only inside product-enforced boundaries. Schell should make those boundaries inspectable at the command chapter level.

Design consequence: helper-created terminals must carry helper identity, policy, sandbox, approvals, and adoption receipts. A command should not become “operator-authored” merely because it appears in the operator's terminal.

## 9. Evaluation of current Schell direction

The rev0228 Schell direction was correct: protocol humility, basis cards, activation receipts, and env epochs are the right primitives. The next weakness is that the ideas are still too prose-heavy. Rev0229 adds the needed specimen: a command chapter with action deck, helper ladder, resurrection gate, downgrade matrix, and falsification harness.

Recommended next moves:

1. Keep Q-0226 open/prototyping until the specimen exists visually.
2. Advance FT-0230 from prose into a mock or tiny local prototype.
3. Add FT-0231 to build downgrade/adversarial tests.
4. Do not freeze syntax, terminal protocol, or helper runtime yet.
5. Make “raw transcript + receipts + downgrade witness” a non-negotiable surface before exploring magic.

## 10. Decision restraint

This pass intentionally does not decide:

- Schell's final language grammar;
- whether the terminal extension protocol is OSC-based, side-channel, log-based, or hybrid;
- how typed pipelines serialize;
- which helper runtime wins;
- how account/session identity is stored;
- how plumb rules are written;
- which UI toolkit renders chapters.

The important decision is smaller and stronger: Schell's first lovable terminal feature should be a chapter/action/downgrade specimen that tells the truth under stress.
