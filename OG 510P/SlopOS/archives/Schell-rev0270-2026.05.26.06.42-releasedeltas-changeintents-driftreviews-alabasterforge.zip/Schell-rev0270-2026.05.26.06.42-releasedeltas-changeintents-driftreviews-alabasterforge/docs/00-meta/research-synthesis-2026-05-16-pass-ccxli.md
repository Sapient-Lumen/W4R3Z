# Research synthesis 2026-05-16 pass CCXLI — concurrency lanes and lost-update humility

Revision: rev0244  
Scope: current online research plus prior Schell/SlopOS surfaces; static proof surface, not implementation advice.

## Imported pressure

The outside world keeps proving that collaboration objects quickly become race objects.

- GitHub Actions concurrency groups make the group name and cancel/pending policy part of the effect surface. Schell should steal group-lane visibility, not ambient confidence that CI status applies to the current target.
- GitHub merge queues make PR head, merge group head, branch protection, and required checks separate rows. Schell should steal the distinction before any shared command card can say merge or ship.
- Kubernetes server-side apply shows why field ownership conflicts are healthy. A helper patch that collides with a controller-owned field should pause with a transfer ceremony rather than quietly force.
- HTTP conditional requests and If-Match-style preconditions show how to fight lost updates. A command card built from issue text, file content, resource state, or route state needs a version witness.
- Web Locks and PostgreSQL advisory locks are good warnings: locks have scope and lifetime. Some coordinate only one origin; some are advisory; some outlive a rollback expectation.
- Stripe-style idempotency remains a useful retry lesson, but only for the same envelope, same target, same key, and current retention window.

## Translation into Schell

Rev0244 should not build a lock service. It should add a legibility board:

1. target key,
2. contender set,
3. precondition witness,
4. coordination lane,
5. safe non-effectful verb,
6. blocked effect verb,
7. settlement owner,
8. exact rebind/authority requirement.

The board asks one hard product question: can Schell offer luxurious shared action buttons while showing enough race truth that no one mistakes a stale green check, chat approval, helper summary, local lock, or idempotency key for current authority?

## Design caution

Do not freeze final conflict-key encoding, queue semantics, lock service, CRDT model, scheduler, CI adapter, PR/chat adapter, Kubernetes adapter, provider registry, or helper runtime from this pass. The correct next artifact is the static prediction board plus fixtures.
