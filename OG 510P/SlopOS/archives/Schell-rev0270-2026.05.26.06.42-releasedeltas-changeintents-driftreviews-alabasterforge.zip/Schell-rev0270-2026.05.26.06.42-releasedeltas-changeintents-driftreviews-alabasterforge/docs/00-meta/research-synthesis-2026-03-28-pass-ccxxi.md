# Research synthesis — 2026-03-28 pass CCXXI

This pass compresses a smaller current pattern:
**the best modern helper-aware terminal moves are explicit attachment moves, not ambient scraping moves.**
When current tools feel precise, they usually preserve one exact command-shaped object — command, output, exit code, block, zone, or selection — and pass that object forward intentionally.

## 1) VS Code is normalizing attach-only terminal context

VS Code 1.106 says a tracked terminal command can be attached to chat from the command decoration context menu, and that the attachment carries the command line, captured output, and exit code.
That same update also says hidden chat terminals can be discovered and that revealing them can jump directly to the relevant command when shell integration is rich.

This is a very important lesson for Schell.
The elegant move is not “AI can see the terminal.”
It is **the operator can attach one exact chapter-shaped packet to a helper and later reveal the exact room or command that packet came from.**

VS Code's terminal basics page reinforces the same pattern from another angle: `#terminalSelection` adds selected terminal text to a chat prompt and `#terminalLastCommand` adds the last command.
That is explicit, named, and bounded.

## 2) Warp keeps proving the value of chapter-shaped objects and filtered slices

Warp's current block docs say a block groups your command and command output.
Its block actions docs say you can copy the block command, output, or both, and share a block by creating a permalink.
Its notebooks docs say a selected command block can be inserted into the terminal input instead of being run immediately.
And block filtering says you can focus on matching lines plus context lines without deleting the original output.

Taken together, this is a powerful design hint.
A good shell+terminal should let an operator carry command-shaped objects around:
copy them, share them, filter them, reinsert them, annotate them, or attach them to a helper.
But those objects should keep a path back to the original chapter instead of flattening into lossy summary folklore.

## 3) Warp's background blocks are also a warning worth stealing

Warp's background-block docs say output likely from a background process can be collected into a background block, and if commands run while that background process is still producing output, the output can be split into multiple interleaved blocks.

That is unusually honest.
It suggests a rule Schell should adopt explicitly:
background or inferred output is still useful, but provenance and causal ownership may be partial.
Therefore those chapter-like objects should support inspect/share/attach while still admitting weaker footing than shell-authenticated foreground chapters.

## 4) WezTerm still shows the floor: semantic zones make exact selection practical

WezTerm's shell-integration docs say OSC 133 defines input, output, and prompt zones.
Its `ScrollToPrompt` action jumps between prompt zones, and `pane:get_semantic_zones` returns the pane's prompt/input/output semantic zones.

This matters because attach-only help is much easier when the operator can cleanly grab:
- prompt,
- input,
- output,
- or whole chapter regions

without dragging through an ambiguous viewport slice.

## 5) iTerm2 keeps validating optional local memory rather than ambient truth

iTerm2's docs keep marks, annotations, and instant replay as explicit local luxuries.
Annotations are scratchpads for chunks of terminal history, and Instant Replay is a bounded local recording with configurable per-session memory.

That posture is exactly right for Schell.
Notes, clips, and replay are incredibly valuable.
But they should remain explicit local memory objects, not invisible helper context that silently graduates into authority.

## 6) The lesson from the past is “don’t let helpers inherit the whole terminal by implication”

Classic terminals made sharing hard because command/output boundaries were weak.
The new helper-rich risk is the opposite: sharing becomes so easy that context boundaries disappear.

The past lesson Schell must keep is simple:
- **selection is not the same as chapter truth,**
- **filtered output is not the same as original output,**
- **background output is not the same as foreground causal proof,**
- and **hidden helper rooms are not the same as ambient permission to remember everything.**

## 7) Compact conclusion

The best near-term steals are now very concrete:
- attach selected output, last command, or whole chapters explicitly,
- preserve command/output/exit packets as helper context,
- surface hidden helper rooms with exact manifests,
- keep filtered and annotated slices visibly weaker than source chapters,
- and treat background output as useful but weaker provenance.

So the next Schell proof should probably not be “smarter omniscient assistant.”
It should be an **attach-only evidence bundle** built on exact packets, discoverable hidden rooms, and provenance humility.
