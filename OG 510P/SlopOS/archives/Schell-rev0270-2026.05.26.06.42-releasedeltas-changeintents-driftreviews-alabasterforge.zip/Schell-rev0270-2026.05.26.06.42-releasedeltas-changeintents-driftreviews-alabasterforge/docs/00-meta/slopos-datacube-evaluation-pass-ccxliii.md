# SlopOS datacube evaluation — pass CCXLIII

Revision: rev0246  
Focus: what Schell should learn from SlopOS about grant lifecycle state, renewal, revocation cascades, and aftercare without importing SlopOS schemas wholesale.

## Read of SlopOS pressure

SlopOS rev0695 is still design-phase, but it already has unusually useful lifecycle discipline:

- D-LEASE says the live lease proxy is authority and CH-CAPLEASE is a redaction-safe descriptor, not authority.
- D-LEASE forbids raw capability export, unbounded renewal, keepalive-as-renewal, and ambient time authority.
- Lease descriptors do not prove live provider-owned lease state after restore, import, export, or redaction.
- Auth teardown refuses a portable logout / disconnect / revoke seam across generic secret, URI, LLM, vault, or powerbox surfaces.
- Namecert redelegation refuses implicit propagation.
- FedCM, MCP, OpenURI, ACP, Capshell, Hot-action, and network idempotency boundaries keep account, route, action, launch, retry, and settlement authority separate.

## Schell import

Schell should import the discipline, not the object model:

1. Renewal requires explicit renewal authority plus returned live state.
2. Keepalive and cached context are not renewal.
3. Revocation needs a cascade-domain label and child-grant ledger.
4. Revocation after admission is not rollback.
5. Provider-local logout/disconnect/revoke is not portable account truth.
6. Time, TTL, deadline, policy epoch, group membership, secret generation, and claim refresh must be shown as lifecycle witnesses before effects.

## Next proof

Run GL-PF-01 through GL-PF-08 against the twenty-four GL cases. If operators cannot distinguish request, returned state, cascade scope, child grants, provider locality, and aftercare from the compact line, Schell should cut lifecycle vocabulary before any helper learns to renew, revoke, rotate, or tear down delegated authority.
