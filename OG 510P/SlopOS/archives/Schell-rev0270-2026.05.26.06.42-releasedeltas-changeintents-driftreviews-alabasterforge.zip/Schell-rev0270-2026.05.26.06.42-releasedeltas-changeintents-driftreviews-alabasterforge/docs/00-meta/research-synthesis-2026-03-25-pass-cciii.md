# Research synthesis — 2026-03-25 — pass CCIII

This pass sharpens the next compact lesson from current official shell, terminal, and portal docs:
**after chapter-local objects and bounded detectors, the best thing Schell can steal is a user-controlled handoff object — terminals can get excellent at selecting and staging visible targets, but crossing into another app or broader authority should go through chooser/portal-style mediation, exact-reveal honesty, and admission-scoped receipts rather than silent default-handler folklore.**

## 1) Current terminal docs keep validating the front half of the move

VS Code, WezTerm, kitty, Ghostty, and iTerm2 all keep rewarding terminals that know command boundaries, prompt/input/output zones, cwd, and marked command positions.
That keeps showing up as command navigation, sticky command context, exact output selection, hint modes, prompt-aware editing, marks, and command-aware next-action surfaces.
The front half is real and valuable: a modern terminal should be able to identify and stage chapter-local objects extremely well before it crosses into anything stronger.

## 2) Portal docs point to the right crossing rule

The official XDG portal docs provide a very clean precedent for the moment a tool leaves its own sandbox or authority plane.
`FileChooser` lets sandboxed applications ask the user for access to files outside the sandbox, and the selected files are then made accessible to the application.
`OpenURI` lets sandboxed applications open URIs under the control of the user.
That combination is extremely relevant for Schell: the crossing should be explicit, mediated, and user-controlled, not hidden inside a click or an ambient helper.

## 3) Exact object action and weaker nearby action should not blur together

The most interesting terminal affordances today often sit right on this line.
kitty hint mode can act on arbitrary text snippets currently visible on the screen, including paths and file-line references; one path mode inserts the path into the terminal, while another can open a file at a line number in an editor.
That is a wonderful proof that terminals can be object-smart.
It is also a reminder that `insert`, `open exact target`, and `do something nearby` are different route families and should stay separately named.

## 4) Trigger and startup systems are still strong cautionary tales

iTerm2’s captured output is explicitly built on regex triggers and can hand matched output to a user-defined coprocess.
Ghostty can automatically inject shell integration for supported shells, but also documents that integration can be lost when you switch shells and may need to be sourced manually.
Those are good lessons, not bad products: the richer the terminal gets, the more important it becomes to keep handoff, startup influence, and trigger-like behavior visibly weaker than reviewed shell truth.

## 5) Attention and aftermath are useful, but should remain small claims

Marks and finish cues remain worth stealing.
iTerm2 can alert on the next mark when a command prompt returns, and VS Code quick fixes can scan command output for likely next actions.
The best import for Schell is not a universal “it worked out there” story.
It is a smaller aftermath vocabulary: admitted, denied, needs chooser, or review-only, with stronger completion/reentry/history claims deferred until another seam proves them.

## 6) Compact conclusion

The ecosystem is pointing Schell toward one very good next seam:
- chapter-local objects remain first,
- handoff warrants become the explicit cross-boundary object,
- chooser turns and destination diffs make stronger routes reviewable,
- and exact reveal stays separate from nearby browse or generic open.

That is enough to make the shell+terminal feel sharper than classic terminals while still deferring the final chooser backend, browser/open substrate, persistence model, and handler registry.
