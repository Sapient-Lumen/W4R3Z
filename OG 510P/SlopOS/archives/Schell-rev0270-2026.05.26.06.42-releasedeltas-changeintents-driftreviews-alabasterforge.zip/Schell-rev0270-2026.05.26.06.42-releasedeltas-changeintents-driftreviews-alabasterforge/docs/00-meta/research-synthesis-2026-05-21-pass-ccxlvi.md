# Research synthesis 2026-05-21 pass CCXLVI

Revision: rev0249

This pass focused on current retention, sanitization, observability, CI,
cluster cleanup, AI-helper, MCP, and pseudonymisation pressure. The archive keeps
REF-style source families rather than freezing legal/compliance claims.

## Source-family pressure

- **REF-NIST-SP800-88R2** — Media sanitization is stronger than deletion,
  redaction, crop, summary, or local sweep. Schell should not say erased,
  sanitized, or unrecoverable unless an explicit sanitization proof object says
  what target data, medium, method, and verification were used.
- **REF-OPENTELEMETRY-SENSITIVE-DATA-2026** — Telemetry implementers remain
  responsible for sensitive data handling and minimization. Schell should show
  collection purpose, redaction-before-export, and downstream receiver state
  before telemetry leaves the terminal/helper boundary.
- **REF-GITHUB-ACTIONS-RETENTION-2026** — Artifact/log retention windows can be
  configured, but changed settings apply to new objects rather than magically
  rewriting old objects. Schell should model policy epochs and object birth
  epochs.
- **REF-KUBERNETES-TTL-JOBS-2026** — TTL-after-finished makes finished Jobs
  eligible for cascading deletion after TTL expiry, honors finalizers, and is
  time-skew sensitive. Schell should say eligible/cleaned/probed, not globally
  forgotten.
- **REF-OWASP-LLM-TOP10-2025** — Sensitive information disclosure, excessive
  agency, and vector/embedding weaknesses support treating helper context,
  retrieval rankings, and embeddings as retained memory lanes.
- **REF-MCP-SECURITY-2025-2026** — MCP security guidance emphasizes per-client
  consent, exact redirect handling, and confused-deputy prevention. Schell should
  separate consent to execute from consent to retain, reuse, summarize, or share
  helper context.
- **REF-EDPB-PSEUDONYMISATION-2025** — Pseudonymisation controls attribution for
  scoped parties/measures; it is not universal anonymization. Schell should not
  treat tombstones or pseudonymized summaries as harmless metadata.
- **REF-NIST-PRIVACY-FRAMEWORK** — Data processing management and disassociated
  processing pressure support retention owners, lifecycle rows, access/review,
  and risk-managed minimization rather than passive labels.

## Speculative import

Schell should introduce **memory authority** as the larger frame. The issue is
not only whether bytes remain. It is whether retained or derived memory can still
shape a decision, authorize a rerun, seed a helper, affect ranking, justify an
audit claim, or leak that an incident/user/secret existed.

## Concrete rev0249 changes

- Add a companion-head lock so SlopOS pressure cannot silently trail the current
  datacube.
- Add transcript-lineage memory cases for accepted prefix, discarded suffix,
  append base digest, denied observation, and projection debt.
- Add semantic/vector influence as retained memory.
- Add tombstone privacy budgets.
- Add retention leases with owners, renewal authority, and forgetting authority.
- Keep architecture promotion blocked until an independent prediction run or UI
  prototype shows operators can answer RF-PF and TL-PF questions.
