# SlopOS datacube evaluation — pass CCXL

Revision: rev0243  
Focus: what Schell should import from SlopOS when command cards become social/team objects

## Relevant SlopOS pressure

SlopOS continues to be a useful companion because it refuses to let friendly names become authority:

- ACP receipts are scoped outcomes, not later social approval.
- OpenURI admits mediated launch requests, not downstream completion, handler truth, or user-visible settlement.
- FedCM import boundaries keep browser/provider account chips local to a mediation context.
- MCP authorization/import boundaries keep tool metadata, redirect URIs, prompts, resources, logging, and consent per-client and per-session scoped.
- Capshell separates command string, argv, cwd, env, handles, resources, sidecars, and output/result rows.
- Hot-action boundaries preserve conflict keys, ordering, and recipient-local serialization instead of letting old/social order spend current authority.

## Evaluation

Rev0243 applies those lessons to team collaboration. A shared command card is a lot like a SlopOS import boundary: it may carry evidence, but it must not become a portable live-state oracle.

The board therefore asks Schell to preserve:

- **audience truth** — public link, workspace link, repo link, embed, cached card, revoked share, or multi-hop chain;
- **row truth** — command/output/prompt versus cwd/env/stderr/raw/redaction/settlement omissions;
- **actor truth** — teammate, bot, CI, helper, provider, crawler, or platform app;
- **recipient truth** — current repo head, branch policy, tool schema, account, secret, shell, cwd, network route, and terminal capability;
- **approval truth** — comment/reaction/review/check/attestation as evidence, not automatic authority;
- **settlement truth** — notifications and summaries as aftercare cues, not proof of completion.

## Constraint preserved

This pass does not import SlopOS mechanism. It imports posture: capability-like exactness, explicit receipt scope, and current recipient rebinding. Schell still defers its final terminal protocol, shell grammar, helper runtime, hosted share service, PR/issue adapter, and UI toolkit.
