# SlopOS datacube evaluation — pass CCXXXVI

Revision: rev0239  
Theme: effect promotion ceremonies for Schell through SlopOS boundary discipline

## SlopOS pressure imported

SlopOS rev0695 is still a design-phase companion, but its boundary style is directly useful for Schell.

- **FedCM import boundary:** browser-mediated account, chooser, login-status, token, and disconnect semantics are provider-local browser mediation. Schell should use that posture for send, deploy, reauth, and account-bearing command cards.
- **MCP import boundaries:** authorization metadata, dynamic client registration, redirect matching, token exchange, client assertions, tool/resource metadata, prompts, sampling, completions, and elicitation stay import evidence until validators bind current authority. Schell should use that posture for helper/tool promotion.
- **ACP action schema:** preconditions are exact veto/check surfaces, not authority grants. Schell should treat recipient basis and effect envelope receipts the same way: they can block promotion, but a fresh current gesture over a frozen envelope is still needed.
- **Hot-action boundaries:** non-commutative sub-actions must name their minimal serialization point and receipt. Schell should not hide filesystem mutation, process control, broadcast, send, deploy, or tool-call ordering behind one pretty action button.

## Evaluation of Schell after rev0238

Rev0238 was correct to separate source evidence from recipient authority. The missing seam was what happens once rebinding succeeds. A current basis check can make an action eligible, but eligibility is not approval and approval is not settlement.

Rev0239 therefore adds promotion ceremonies. This is faithful to SlopOS because it treats promotion as an explicit boundary with receipts rather than a UX flourish.

## New Schell rule borrowed from SlopOS

A promotion ceremony is the shell+terminal analogue of a SlopOS hot-action boundary:

> exact envelope + contest window + fresh gesture + spend receipt + settlement receipt, or no spend.

This lets Schell preserve delightful fast paths without turning imported browser, MCP, helper, clipboard, hyperlink, TUI, or restored-session evidence into hidden authority.

## Still deferred

Schell should not yet copy SlopOS schema machinery wholesale. The right next step is a prediction drill over the static `PC-*` cases, not final schema families, kernel/action wiring, terminal protocol, or helper transport.
