# Research synthesis — 2026-05-23 pass cclv — probe runner attestation and measurement-plan replay

Rev0258 imports a narrow lesson: a forgetting proof is only as good as the actor and plan that measured it. Schell therefore makes runner identity, code/runtime/materials, nonce or challenge, verifier/appraisal policy, receiver scope, read-only budget, and replayable plan rows visible before a no-hit result can become even a weak claim.

External pressure, bounded take:

- IETF RATS architecture distinguishes Attester, Verifier, Relying Party, Evidence, Endorsements, Reference Values, Appraisal Policy, and Attestation Results. Schell imports role split and appraisal pressure, not a remote attestation protocol.
- RFC 9711 EAT defines attestation-oriented claims about an entity used by a relying party to decide trust. Schell imports the idea that the runner can be described by claims, while keeping EAT weaker than deletion proof.
- SLSA v1.2 provenance describes where, when, and how artifacts were produced; in-toto attestations describe verifiable supply-chain claims. Schell imports provenance/material/expectation pressure while distinguishing build provenance from runtime forgetting measurement.
- Sigstore/Rekor provides transparency and inclusion/consistency style evidence. Schell imports transparency as custody, not correctness or erasure.
- NIST SP 800-88 Rev. 2 keeps sanitization stronger than local deletion, miss witnesses, or redaction. Schell therefore blocks erased/sanitized/compliant claims unless a stronger proof object exists.
- OpenTelemetry sensitive-data guidance keeps probe telemetry in scope as a receiver that can preserve proof residue.
- SlopOS rev0720 keeps append authority bound to accepted-prefix checkpoints; Schell binds measurement plans to that same branch discipline.

Local changes:

- Added `probe-runner-attestation-board-v0.json` and rationale.
- Added `measurement-plan-replay-gauntlet-v0.json` and rationale.
- Added H-0405..H-0416 and RF-0041/RF-0042.
- Added lint gates for PRA/MPR proof surfaces.

Non-take: do not implement a RATS verifier, EAT profile, SLSA verifier, in-toto layout, Rekor monitor, CI runner, provider deletion adapter, vector DB runtime, backup restore engine, OpenTelemetry processor, UI, terminal protocol, shell grammar, or SlopOS portal adapter.
