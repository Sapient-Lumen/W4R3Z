# Research synthesis — 2026-05-15 — pass CCXXXVII

Revision: rev0240  
Theme: post-spend settlement witnesses and rollback honesty

## Sources checked this pass

Current terminal work keeps making commands more object-like: shell integration exposes command/cwd detection, prompt/input/output zones, command navigation, sticky headers, quick fixes, recent-command recall, and resurrection. Agentic terminals and coding assistants add auto-review, hooks, permission modes, sandbox/approval splits, MCP tool calls, and hidden/background execution.

This pass looks at what happens after the fast button actually spends authority. The outside pressure comes from four families:

1. **Semantic terminal affordances**: they make action cards and follow-up buttons feel natural, but they cannot prove downstream settlement.
2. **Provider idempotency practice**: effect keys have scopes, retention windows, parameter matching, and mismatch states; they do not grant infinite retry safety.
3. **Compensating transaction practice**: rollback is often a domain-specific follow-up, not exact reversal.
4. **Agent/tool authorization practice**: sandbox, hooks, auto-review, tool metadata, and MCP authorization are necessary boundaries, but tool text and approval paths are not outcome truth.

## Lessons imported

1. **Exit status is too small.** A process returning 0 is useful evidence, but Schell should still ask what postcondition was promised and what witness proves it.
2. **Operation ids are pending handles.** Provider admissions, request ids, and operation ids are aftercare handles, not finished work.
3. **Idempotency is scoped and aging.** Safe retry needs same parameters, same effect envelope, current idempotency window, and duplicate status.
4. **Compensation is not erasure.** A rollback card must label exact local undo, restore, cancel, revoke, compensation, duplicate suppression, or impossible undo.
5. **Partial settlement is normal.** Broadcasts, deployments, secret rotations, multi-pane actions, and multi-service mutations need per-target state instead of one green check.
6. **Notifications and helper summaries are weak.** They can route attention, but they are not settlement receipts.

## Move made

This pass adds `post-spend-settlement-board-v0.json`: twenty-four cases over local patches, daemons, pipelines, remote jobs, signals, deploys, messages, payments, FedCM disconnects, MCP tools, OpenURI, clipboard writes, TUIs, broadcasts, SSH, redaction, rollback scripts, deletes, symlinks, hooks, notifications, dry-run-live deployment, cancellation races, and secret rotation.

The board forces each case to name:

- spend boundary;
- synchronous observation;
- settlement state;
- first missing witness;
- retry/idempotency policy;
- rollback truth;
- aftercare action;
- SlopOS parallel.

The result is a sharper product hypothesis: Schell can be fast after spend if it treats aftercare as a first-class object instead of painting success over uncertainty.

## Deliberate non-move

No settlement database, watcher API, rollback engine, provider registry, compensation language, final state taxonomy, shell grammar, terminal protocol, helper runtime, account/session model, or UI toolkit is frozen. The board is a prediction and falsification surface.
