# Research synthesis — 2026-05-24 pass cclx — assurance cases and defeater burden

Rev0260 imports a narrow lesson: after Schell appraises evidence and merges conflicts, it still needs to ask **what argument turns that evidence into this claim, and what known reasons for doubt remain?** The answer is not a safety-case editor. It is a proof surface that keeps top claim, context rows, argument strategy, evidence refs, assumptions, justifications, defeaters, burden owner, residual risk, and reassembly triggers visible.

External pressure, bounded take:

- OMG SACM defines an assurance case as structured auditable claims, arguments, and evidence. Schell imports claim/argument/evidence separation, not SACM serialization.
- GSN separates goals, strategies, solutions, contexts, assumptions, and justifications. Schell imports visible argument rows, not GSN diagrams.
- ISO/IEC/IEEE 15026 specifies assurance-case structure and meaning to avoid subjective term use. Schell imports structure discipline, not compliance claims.
- Confidence and defeater work frames reasons for doubt as things to identify, mitigate, or leave as residual risk. Schell imports a defeater ledger and burden-owner row, not quantitative confidence scoring.
- NIST SP 800-160 lifecycle/cyber-resiliency pressure supports reassembly when environment context changes; NIST SP 800-88 keeps sanitization stronger than any weak assurance argument.
- SlopOS rev0720 makes transcript memory branch-bound; Schell imports current accepted-prefix base digest as an assurance-case context row.

Local changes:

- Added `forgetting-assurance-case-board-v0.json` and rationale.
- Added `defeater-burden-ledger-v0.json` and rationale.
- Added H-0429..H-0440 and RF-0045/RF-0046.
- Extended forgetting proof dockets with assurance-case, top-claim, argument-strategy, open-defeater, burden-owner, and residual-risk rows.
- Added lint gates for FAC/DBL proof surfaces.

Non-take: do not implement a GSN/SACM editor, ISO compliance engine, confidence calculus, legal appeal workflow, provider deletion resolver, policy engine, helper runtime, UI, terminal protocol, shell grammar, or SlopOS portal adapter.
