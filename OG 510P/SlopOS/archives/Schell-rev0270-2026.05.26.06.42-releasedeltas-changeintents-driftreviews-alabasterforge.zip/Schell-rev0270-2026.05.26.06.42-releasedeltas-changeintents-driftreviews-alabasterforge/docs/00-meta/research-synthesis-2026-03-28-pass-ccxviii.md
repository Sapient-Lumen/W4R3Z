# Research synthesis — 2026-03-28 pass CCXVIII

This pass compresses a newer cross-tool pattern:
**portable helper packs, hierarchical scope discovery, specialist delegates, and visible context inspection are becoming common — but the best ideas are still the bounded ones.**

## 1) Helper artifacts are converging toward an open, file-backed shape

VS Code's Agent Skills docs now describe Agent Skills as folders of instructions, scripts, and resources that load when relevant, and they explicitly call the format an open standard that works across multiple agents.
That is important because it suggests reusable helper capability does not need to live inside one editor or one proprietary runtime.
Claude Code's skills docs reinforce the same direction: skills follow the Agent Skills open standard, but can still add local extensions.

The lesson for Schell is to steal the **portable folder-backed helper pack** idea before deciding any final private helper constitution.

## 2) Scope and locality are becoming a first-class design concern

VS Code now documents parent-repository discovery for instructions, prompt files, custom agents, agent skills, and hooks.
Prompt files themselves can be stored in the workspace or the user profile.
Claude Code's memory model likewise separates persistent CLAUDE.md files from auto memory, and it even supports file-type-scoped rules.
Claude Code skills add another strong signal: project, personal, enterprise, and plugin skills live in different locations, nested directories can contribute local skills in monorepos, and higher-priority locations win when names conflict.

This is a gift to Schell.
It means the field is already admitting that helper context is plural, layered, and source-sensitive.
Schell should make that scope ladder visible instead of pretending all helper context is one seamless mind.

## 3) Context inspection is becoming an explicit product feature

Gemini CLI's GEMINI.md docs are especially instructive here.
The CLI loads hierarchical context from several locations and gives operators commands like `/memory show` and `/memory reload` to inspect the exact instructional context being sent.
The docs also note that the footer displays the number of loaded context files.
VS Code adds a related diagnostic move: its chat customization diagnostics can show loaded custom agents, prompt files, instruction files, and skills together with errors.

This points to one of the best near-term steals for Schell:
**a one-keystroke loaded-context inspector with scope, counts, provenance, and why-loaded answers.**

## 4) Delegation is real, but bounded delegation is the useful steal

Claude Code's subagent docs frame subagents as specialized helpers for task-specific workflows and improved context management.
Descriptions guide when Claude should delegate, tool access can be restricted, and the docs explicitly recommend focused subagents with limited permissions checked into version control.
Anthropic's cost guidance adds a subtle but important reason to care: verbose work can stay inside a subagent's context while only a summary returns to the main conversation.
VS Code is also moving in this direction with custom agents, handoffs, and multiple agent types; its docs now describe handing a plan from one agent to another and even background agents running in worktrees for isolation.

For Schell, the steal is not "autonomous swarms."
It is **delegation rooms with capped tools, narrow charters, and summary-or-draft returns**.

## 5) Handoffs are becoming an explicit workflow surface

VS Code's custom agent docs now call out handoffs as guided workflows between agents.
The broader agents overview says built-in agents already separate Ask, Plan, and implementation roles, and existing sessions can be handed off to different agent types with history and context carried over.
This is an important signal.
The value is not merely multiple agents; it is the explicitness of the handoff.

Schell should likely keep that explicitness and make handoffs warrant-bearing rather than invisible.

## 6) Terminal semantics keep turning these helper ideas into local delight

Ghostty 1.3.0 is a strong new signal because it adds click-to-move-cursor support inside active OSC 133 prompts, a debug overlay in the terminal inspector that shows OSC 133 areas, better prompt-aware resizing and command-aware behavior, and command-finished notifications with duration thresholds.
WezTerm continues to show how semantic zones can power whole-output selection for a command region.
These are excellent examples of how a shell-authored semantic floor can make sophisticated helper architecture feel immediate and humane without promoting the terminal into a second authority source.

## 7) Restoration remains attractive, but still needs honesty

Zellij's session resurrection continues to matter because it serializes sessions for later recreation after intentional exit or crashes.
That is a superb operator convenience.
But it also keeps reinforcing Schell's current discipline: preserved context is valuable, yet preserved context should stay visibly preserved until live authority is reacquired.

## 8) Compact conclusion

The current field keeps rewarding the same compact pattern:
- helper capability should be file-backed and portable,
- scope should be layered and visible,
- loaded context should be inspectable,
- delegation should be focused and tool-capped,
- handoffs should be explicit,
- and terminal luxuries should ride on semantic marks rather than replace shell truth.

So the next Schell proof should not be a final shell constitution.
It should be a **scope-ladder plus open-helper-pack plus delegation-room specimen bundle**.
