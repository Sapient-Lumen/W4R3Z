# Research synthesis — 2026-03-28 — pass CCXV

This pass sharpens the next compact lesson from current shell and terminal docs:
**the smartest next move for Schell is not to crown one universal object shell. It is to keep an exact command lane, add optional value lenses and typed sidecars, and make workflow/notebook luxury insert-first rather than auto-executing.**

## 1) Modern terminal integration keeps proving that command chapters are the highest-value luxury seam

VS Code shell integration, Ghostty, WezTerm, kitty, and iTerm2 all keep converging on the same practical truth.
When the shell exposes prompt boundaries, command boundaries, cwd, and outcome posture, the terminal can do dramatically better local work:
- jump across command chapters,
- reopen or page one command's output,
- keep sticky context,
- track command history and recent directories,
- spawn new terminals in the right working directory,
- and make prompt-local editing feel humane.

That is the strongest no-regret steal because it improves daily use immediately while still preserving a text-first execution story.

## 2) Humane input editing remains underexploited shell territory

fish is a reminder that the shell experience improves a lot from small humane moves:
- autosuggestions that can be accepted or edited,
- multiline honesty,
- external-editor round trips,
- and undo/redo on the input itself.

Schell should steal that class of comfort aggressively.
It does not require committing to one final language or one smart-terminal architecture.
It only requires keeping active-prompt truth, insert-vs-run honesty, and draft lineage clear.

## 3) Structured-data shells prove the demand for value lenses, not yet one universal pipe law

Nushell and PowerShell both show why people keep reaching for structured pipelines.
Operators really do want rows, fields, typed values, and reliable projection instead of brittle text scraping.
YSH adds a useful nuance: command language and expression language can be neighboring lanes rather than one flattened thing.

That suggests a smaller and safer Schell lesson:
- do not deny structured values,
- but do not force every command through one frozen object pipeline yet;
- instead, allow structured values through explicit sidecars, expression/value lanes, and typed receipts where they earn their keep.

## 4) Parameterized workflows and runnable docs are brilliant when they stay review-first

Warp's workflows and notebooks show a genuinely compelling operator pattern.
Searchable saved recipes, parameter placeholders, mirrored slot filling, and runnable documentation reduce friction a lot.
But the best part is not hidden execution.
The best part is the insertable, inspectable draft.

That points Schell toward workflow cards, parameter cards, and runbook snippets that usually write into the review lane first.
This preserves operator confidence and keeps automation posture honest.

## 5) Restore and resurrection should preserve context, not silently re-spend

Zellij's resurrection posture is a beautiful clue.
Restoring layout and command context without immediately rerunning old commands is exactly the kind of humility a custom shell+terminal should keep.
Schell can become far better than classic shells at returning people to the right room, chapter, or object context while still refusing the lie that restored context equals fresh execution truth.

## 6) Rich local renderers are worth stealing only as optional lanes

Current terminal ecosystems also show that richer local rendering is plausible: tables, command-local paging, prompt-aware cursor movement, shell-aware titles, and increasingly capable TUI or graphics layers are all real.
But the safe lesson is still layered.
Let rich local rendering hang off optional lanes, sidecars, and renderer capabilities.
Do not make it the only truth surface.

## 7) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- keep command chapters exact and first-class,
- steal humane input editing and command-aware navigation aggressively,
- allow structured values through explicit lenses and sidecars,
- keep workflow/notebook luxury insert-first and review-first,
- and treat restore/history richness as context reuse rather than fresh spend authority.

That gives Schell a path to feel deeply modern without forcing a premature verdict on one final shell language, one final object pipeline, or one final smart-terminal substrate.
