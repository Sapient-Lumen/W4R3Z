# Research synthesis — 2026-03-25 — pass CCII

This pass sharpens the next compact lesson from current official shell and terminal docs:
**the best terminal ideas to steal now are chapter-scoped selection, bounded hint modes, command-aware quick fixes, and explicit link/object pickers — but they should hang off shell-authenticated chapters and summoned scopes rather than ambient browser, trigger, or full-history authority.**

## 1) Current terminal docs keep converging on chapter-scoped ergonomics

VS Code, WezTerm, kitty, Ghostty, and iTerm2 all keep rewarding terminals that know where one command begins, what output belongs to it, and what cwd or prompt context existed around it.
That shared direction keeps showing up as command navigation, sticky command context, exact output selection, prompt-local cursor motion, command history rows keyed to host/cwd, and command-aware next-action surfaces.
The convergence is strong evidence that Schell should keep investing in command chapters and chapter-local objects rather than one raw scrollback parser.

## 2) Current docs also keep validating summoned detection over ambient overreach

The most decision-light ideas are not giant autonomous scanners.
They are bounded detectors and explicit pickers:
- VS Code exposes detected links through a keyboard quick pick over links in the viewport,
- kitty exposes hint mode for arbitrary text snippets currently visible on the screen,
- WezTerm lets semantic-zone selection grab surrounding command output cleanly,
- and Ghostty/kitty keep click-to-move cursor tied to prompt-aware shell integration rather than generic screen clicking.

That pattern suggests a strong Schell rule:
**heuristic richness should prefer summoned, visible, or chapter-local scope.**
It is both more explainable and less likely to promote stale scrollback into fake live authority.

## 3) Quick-fix docs point to reviewed bundles, not silent trigger execution

VS Code’s command-aware quick fixes are a very strong proof that terminals can be useful after a command without pretending they are the shell.
They scan command output and suggest likely next moves such as kill-and-rerun, set-upstream, similar command repair, or open the suggested PR link.
That is a great pattern to steal.
The part to resist is the temptation to let detector or trigger systems collapse directly into execution authority.
The best import for Schell is a chapter-bound reviewed action bundle, not a regex-to-exec shortcut.

## 4) Link/open docs point to object ladders, not one generic click story

VS Code’s detected-link picker, kitty’s customizable open actions, and iTerm2’s semantic history all prove that visible text wants richer action than plain copy.
But those same sources also demonstrate the danger zone:
- action depends on detection class,
- cwd context matters,
- editors and URLs can be opened through custom commands,
- and non-standard or emulator-local escape/trigger features can grow surprisingly powerful.

That means Schell should keep `inspect`, `insert`, `reveal`, `safe-open`, `mediated open`, and `run/repair` as visibly different ladders.
Otherwise the terminal will quietly become a browser/router layer with unclear authority.

## 5) Past lessons remain painfully relevant

Old terminal/control-stream history is still telling us the same thing: a terminal stream can carry a lot of power.
xterm documents broad control families including window manipulation and bracketed paste; iTerm2 explicitly says its proprietary escape codes may have unknown effects on other terminals; Ghostty just fixed a 2026 security issue where pasted or drag-dropped control characters could execute arbitrary commands in some shell environments.
So “super awesome” must still mean **strict about truth, generous about comfort**.
The comfort can be rich.
The authority boundaries still need to stay narrow and named.

## 6) Compact conclusion

The ecosystem is pointing Schell toward one very good next seam:
- chapter-local visible objects,
- summoned detector scopes,
- reviewed quick-fix bundles,
- and explicit mediated-open ladders.

That is enough to make the shell+terminal feel dramatically better than classic terminals while still deferring the final detector DSL, final browser/open substrate, final semantic transport, and final persistence model.
