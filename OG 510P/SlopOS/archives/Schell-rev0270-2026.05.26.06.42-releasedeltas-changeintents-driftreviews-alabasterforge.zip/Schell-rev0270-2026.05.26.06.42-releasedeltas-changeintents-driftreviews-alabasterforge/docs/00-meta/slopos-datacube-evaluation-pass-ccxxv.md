# SlopOS datacube evaluation — pass CCXXV

This pass evaluates Schell against the included SlopOS rev0695 and sibling cubes after the new research pass on past terminal lessons, semantic command blocks, plumb/action decks, terminal protocol humility, and agent power ladders.

The conclusion is deliberately conservative:
**Schell should prototype a small protocol-humility specimen, not freeze its final shell language, terminal protocol, helper runtime, account model, or typed pipeline runtime.**

## 1) SlopOS pressure: imported convenience must not become durable truth

SlopOS rev0695 pins FedCM/browser federated sign-in as provider-local browser mediation only.
The important pressure for Schell is not the browser API itself; it is the pattern:
visible login/account/browser affordances are useful, but they must not silently become portable account chooser truth, current-user truth, approval-basis truth, disconnect control, or durable session truth.

Schell's analogous danger is terminal/helper folklore:
- a helper pane can look authoritative;
- a prompt badge can look like basis truth;
- a semantic mark can look host-trusted;
- a block can look exact even when inferred;
- a restored command can look ready to rerun;
- a synced history row can look like present authority.

The boundary must be explicit before the UX gets too good.

## 2) Harbor pressure: derived artifacts need contract tiers and review loops

Harbor rev0075 emphasizes temporal witnesses, contract subsets, freshness basis, row-lineage restraint, and a datacube review loop.
For Schell this translates to:
- command chapters need contract tiers: exact launch receipt, reconstructed command, inferred block, filtered view, redacted share, or historical-only replay;
- source spans and output lenses need freshness/replay basis;
- derived blocks and plumb cards must stay downstream from raw command/source truth;
- repo-hygiene revisions should refresh research, evaluation, ledgers, manifest, and package together.

This revision follows that process by adding one pass synthesis, one pass evaluation, one terminal design surface, ledger refresh, manifest refresh, and linted packaging.

## 3) Foundry pressure: keep semantic spines thin and pinned cuts explicit

Foundry rev0074 intentionally avoids promoting another specimen while SlopOS and sibling cubes are still moving.
Its thin-semantic-spine and pinned-cut discipline are directly relevant.
Schell should not invent a giant universal semantic terminal schema yet.
It should define the minimum spine for a command chapter:
- source identity;
- command/input/output zones;
- cwd/basis/account/process-ground witnesses;
- trust grade for marks;
- raw-span anchors;
- authority for next verbs.

Everything else can remain an adjunct lens or action card until repeated specimens prove promotion.

## 4) Ward pressure: fidelity tiers should be visible

Ward's recent passes keep answers from flattening raw replay, retained/downsampled history, materialized derivatives, display rollups, and hybrid seams.
Schell needs the same posture for terminal memory:
- exact transcript is not filtered view;
- filtered view is not source chapter;
- copied output is not rerun basis;
- restored viewport is not live process;
- inferred semantic zone is not shell-signed zone;
- helper summary is not exact output.

A chapter card should name its fidelity tier before offering strong actions.

## 5) ViewFS / Helm / Steward / Foundry sibling pressure

The sibling cubes keep repeating one design law from different angles:
**delightful indirection must remain visible and revocable.**

For Schell this means:
- ViewFS-style view/open humility: detected paths, URLs, and resources should become action cards with exact source and reviewed verbs.
- Helm-style turn/attention humility: helper tasks, background rooms, and notifications need typed wait reasons and return paths.
- Steward-style lifecycle humility: hooks and automations should stay observable, draftable, or reviewable before becoming effectful.
- Foundry-style foreign-ground humility: terminal semantics crossing tmux/ssh/remote/browser/helper boundaries need hop lineage and downgrade labels.

## 6) What Schell must learn from the past

The past lessons now deserve “must” status:

1. **Text is not launch truth.** Exact argv/fd/env/cwd receipts are load-bearing.
2. **Interactive convenience is not scripting safety.** Do not freeze the language too early.
3. **PTY/job-control state is real authority context.** Foreground, stopped, signal, background, and disowned states need witnesses.
4. **Escape sequences are untrusted until admitted.** Semantic marks need trust grades and downgrade labels.
5. **Paste is not typing.** Generalize origin witnesses to every ingress path.
6. **History is not permission.** Recall and restoration should stage, compare, or review before rerun.
7. **Assistant work is not operator authorship.** Helper lanes need adoption receipts.
8. **Structured data is a lens before it is a treaty.** Preserve raw bytes and declare parser/loss.

## 7) Nifty ideas Schell should steal now

Steal these because they are high leverage and low regret:
- Warp-style command/output blocks, but source-anchored;
- WezTerm/VS Code/Ghostty/iTerm shell-integration marks, but trust-graded;
- Plan 9 plumb routing, but mediated through source-bearing action decks;
- fish autosuggestion posture, but extended to helper proposals and history recall;
- Atuin contextual history, but with recall-to-draft and sync trust posture;
- Nushell structured data pipelines, but first as typed lenses over raw output;
- Kitty/Ghostty modern terminal protocols, but feature-witnessed and downgrade-tested;
- Zellij resurrection gates, but generalized to every restored/rerun path;
- Codex/Claude sandbox+approval lessons, but represented as visible helper power ladders.

## 8) The recommended next move

Do not add a giant spec.
Add a specimen bundle target:

**Protocol-humility specimen:**
- one paste/import chapter;
- one semantic-zone command chapter;
- one plumb/action deck;
- one helper proposal adoption receipt;
- one rerun rehearsal compare;
- one downgrade matrix across native shell integration, no shell integration, tmux/ssh, and plain transcript.

That specimen can prove whether the luxury feels super awesome before any final shell language, terminal protocol, typed-pipeline runtime, or helper constitution is frozen.

## 9) Compact conclusion

Schell's safest superpower is not “make the terminal smart.”
It is:
**make the terminal's smartness accountable.**

Every convenience should say where it came from, what it covers, what it can safely do, what it cannot prove, and how it degrades.
That is exactly compatible with SlopOS's current design-phase discipline.
