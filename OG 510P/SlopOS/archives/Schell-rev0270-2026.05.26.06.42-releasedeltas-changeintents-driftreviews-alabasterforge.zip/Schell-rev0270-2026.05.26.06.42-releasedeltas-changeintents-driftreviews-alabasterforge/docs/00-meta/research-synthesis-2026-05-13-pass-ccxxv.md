# Research synthesis — 2026-05-13 pass CCXXV

This pass broadens the previous basis-card seam into a more historical question:
**what must Schell learn from past shells/terminals, and which modern luxuries are safe enough to prototype before the final language or terminal protocol is chosen?**

The pattern is clear: the best systems add semantic affordances, but the safest systems keep those affordances weaker than exact launch, source, and authority truth.

## 1) Old shell semantics still warn us not to trust visible text alone

The POSIX shell command language remains a warning label for any new shell: parsing, expansion, redirection, field splitting, pathname expansion, and execution are distinct phases.
The visible text a human sees is not the final `argv`/fd/env/cwd/process boundary.
Bash pitfalls and command-injection defenses keep repeating the same lesson from a security angle: user data must not become shell syntax by accident.

Schell's safe steal is not “invent a perfect syntax now.”
It is a reviewed command envelope whose exact argv, redirections, cwd, basis, and effects can be revealed before launch.

## 2) Job control and PTY truth must be first-class

Bash's job-control model and Unix tty lineage keep reminding us that foreground ownership, process groups, signals, stopped/background jobs, and terminal read/write rights are real runtime structure.
A modern UI that simply shows “done” or returns a prompt can still be lying by omission.

Schell should keep process-ground witnesses visible and host-trusted: foreground, background, stopped, disowned, signal, drain, and settlement state must not depend solely on PTY text.

## 3) Shell integration has become the live frontier

VS Code's shell integration tracks command history, current working directory, command output, and semantic command marks; WezTerm uses OSC 7, OSC 133, and OSC 1337 for cwd, prompt/input/output zones, and pane-local user vars; iTerm2 tracks command history, cwd, hostname, and more, even over ssh; Ghostty auto-injects shell integration for several shells and uses it for prompt jumping, command-output selection, cwd inheritance, and close safety.

The good idea: semantic zones and shell-known command chapters.
The danger: a terminal mark can be emitted by many parties and traverse tmux/ssh/foreign paths.
So Schell should attach a trust grade to every mark: host-trusted, shell-signed, app-emitted, inferred, downgraded, or unknown.

## 4) Rich terminal protocols need negotiation and downgrade humility

Kitty's keyboard protocol exists because legacy terminal input cannot represent many modern key distinctions well.
Ghostty's docs split end-user features from developer-facing terminal APIs such as Kitty graphics/keyboard protocols, synchronized rendering, and light/dark notifications.
OSC 8 hyperlinks and bracketed paste show that terminal protocols can be both tiny and transformative.

The safe Schell move is a protocol lab and feature witness matrix, not one universal extension treaty.
Every luxury should state whether it is native, negotiated, degraded, or unavailable.

## 5) Blocks, zones, and resurrection are the current best UX seam

Warp blocks group commands and outputs into atomic units for copying, sharing, re-input, bookmarking, and navigation.
WezTerm exposes prompt/input/output semantic zones.
Zellij serializes layouts and command panes, but gates resurrected commands behind an explicit Enter banner to avoid dangerous accidental reruns.

Schell should treat this as a direct mandate: command chapters should be wonderful to navigate and share, but historical or restored command objects must remain weaker than fresh reviewed execution.

## 6) Plan 9 plumbing still has the cleanest action-routing lesson

Plan 9's plumber routes messages through a small rule language and ports, making common interactive transfers explicit and uniform instead of each app improvising URL/file/error detection.
It is a beautiful ancestor of Schell action decks.

Schell should steal plumb-like routing, but every card should include source span, parser/rule identity, ambiguity, authority, and safe/reviewed verbs.
Detector convenience must not become hidden spend authority.

## 7) Fish, Atuin, and Nushell show three complementary luxuries

Fish proves suggestions can be powerful precisely because they do not execute unless accepted.
Atuin proves shell history can be richer than flat text by storing command context in a database and optionally syncing it end-to-end encrypted.
Nushell proves typed data pipelines can remove a huge amount of string-parsing pain.

Schell should combine the lessons without prematurely merging them:
- suggestions land as draft;
- history recalls as context-bearing insert/stage/compare objects;
- typed output appears as source-anchored lenses over raw bytes until a typed lane is explicitly admitted.

## 8) Agentic terminal tools teach approval-fatigue realism

Modern coding agents are moving terminal work toward assistants, subagents, background tasks, repo maps, sandbox modes, and approval policies.
Codex documents sandbox mode plus approval policy as separate control layers; Anthropic's Claude Code auto-mode discussion explicitly frames approval fatigue and the tradeoff among manual prompts, sandboxes, and unsafe permission skipping.
Aider's repo map shows a different no-regret helper lesson: compact, ranked context can be better than flooding the model with everything.

Schell should steal power ladders, repo maps, explicit context budgets, and background lanes.
It should not steal one vague “agent has access” mode.

## 9) SlopOS companion pressure

SlopOS rev0695 is still in design phase and is actively pinning browser-federation semantics so imported FedCM/browser-login affordances do not become portable account chooser, login-state, approval-basis, or durable account/session truth.
That exact posture should shape Schell:
- terminal helper identity is not operator identity;
- browser/account state is not shell basis;
- provider-local signals are not durable platform truth;
- a visible chooser or login status does not become approval authority.

The sibling cubes reinforce the same discipline: Harbor emphasizes derived artifacts and review loops; Foundry keeps semantic spines thin and pinned cuts explicit; Ward keeps numeric answers tied to fidelity tiers; ViewFS, Helm, Steward, and Foundry all keep boundaries and review posture ahead of big irreversible abstractions.

## 10) What to prototype next

The research points to a specimen rather than a constitution:
- a paste/import chapter with origin chips and insert-first review;
- a semantic-zone chapter with trust-graded command blocks;
- a plumb/action deck for output objects;
- a helper proposal lane with adoption receipts;
- a downgrade matrix across native shell integration, no shell integration, tmux/ssh, and plain transcript.

This would make Schell more awesome immediately while preserving the larger language/protocol/runtime decisions for later.

## 11) Compact conclusion

The brilliant move is not to replace the terminal with an IDE or to replace the shell with an object database.
The brilliant move is to make the old hidden seams visible:
text vs argv, typed vs pasted, mark vs proof, block vs source, restored view vs live process, suggestion vs spend, helper output vs operator authorship, and protocol luxury vs portable truth.
