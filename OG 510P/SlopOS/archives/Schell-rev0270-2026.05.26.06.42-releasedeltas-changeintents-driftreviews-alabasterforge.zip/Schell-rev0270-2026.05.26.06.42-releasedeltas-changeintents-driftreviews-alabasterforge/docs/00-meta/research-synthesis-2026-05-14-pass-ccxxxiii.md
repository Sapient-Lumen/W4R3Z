# Research synthesis pass CCXXXIII: arrival footers, consequence previews, and consent decay

Revision: rev0236  
Date: 2026-05-14  
Scope: current terminal/shell/agent precedents viewed through the question “can the operator predict blocked authority from the card itself?”

## 1. Field signal

The field keeps compressing command work into pleasant objects: command decorations, sticky headers, quick fixes, recent-command recall, semantic zones, mux control streams, resurrected sessions, synced command history, terminal-chat/helper context, hooks, sandboxes, and tool catalogs.

Rev0236 turns that pressure into a small UI proof: every imported action card needs an arrival footer before it gets tempting buttons.

## 2. Updated observations

### 2.1 A button label is not an authority model

“Fix”, “continue”, “open”, “retry”, “paste”, and “inspect” are overloaded product words. Schell should split them by effect: read/inspect/draft/reveal versus launch/open/network/patch/delete/kill/send/retry/rollback/reauth.

### 2.2 Consequence previews are better than generic prompts

A prompt that asks “are you sure?” teaches little. A footer that says “network fetch; external service; not reversible after request; needs target reveal and network lease” teaches the operator why the boundary exists.

### 2.3 Consent decays along more axes than time

Consent decays when the target path changes, the route changes, the account changes, the policy epoch changes, the helper context changes, the prompt becomes armed, or the evidence crosses from source workspace to recipient workspace.

### 2.4 Accessibility is part of authority hygiene

If a blocked reason is color-only, hover-only, or announced after decorative metadata, the footer is not honest. The accessible order must start with allowed/blocked action state and the first missing receipt.

### 2.5 Hooks and helpers need precedence labels

Hook output can be useful deterministic control, but it cannot outrank product-enforced deny/ask policy. Tool metadata and helper summaries stay evidence until policy, sandbox, target, and exact envelope are current.

## 3. Lessons we must keep learning from the past

1. Shell text is not launch truth.
2. A pretty command card is not approval.
3. A restored session is not a live process.
4. A notification is not a consent receipt.
5. A link label is not a URL target.
6. A source account chip is not recipient identity.
7. An undo badge is not current rollback.
8. A hook allow is not policy authority.

## 4. Brilliant ideas to steal, with fences

- Steal quick fixes, but make the first missing receipt visible in the disabled state.
- Steal sticky command headers, but add footer floors when the header becomes actionable.
- Steal semantic zones, but grade their authorship and fallback path.
- Steal mux control streams, but show route/pane authority separately from local path authority.
- Steal resurrection, but keep old commands behind review/enter gates.
- Steal synced history, but keep history search separate from replay permission.
- Steal agent hooks and sandboxes, but display precedence and effect envelopes.
- Steal MCP/tool context, but treat dynamic tool metadata as untrusted until reviewed.

## 5. Recommendation

Before Schell designs a real terminal protocol, run the footer prediction drill over AF-0001 through AF-0014. If operators cannot name “safe now / blocked / first receipt / consequence / raw reveal” from the footer, the vocabulary is still too wide.
