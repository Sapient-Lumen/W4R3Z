# SlopOS datacube evaluation — 2026-03-25 — pass CCIV

**Schell should add opener racks, why-this-opener drawers, open-state badges, and recent-hint humility, because SlopOS keeps handler choice, launch completion, recent items, and exact reveal deliberately separate while the companion cubes keep preview, history, freshness, confirmation, and route residue as neighboring truths rather than one generic open result.**

## 1) SlopOS keeps open-like facts split on purpose

The strongest pressure in this pass comes directly from SlopOS OpenURI boundaries.
SlopOS keeps:
- concrete handler choice shell-owned,
- launch completion admission-scoped only,
- recent-item/history control out of generic OpenURI,
- subject echo bounded,
- materialization separate from generic launch,
- and exact show-item reveal stronger than parent-directory browse.

That means Schell should not stop at “handoff warrant.”
It should also keep the next neighboring truths separate:
which opener class was available,
which opener was actually chosen,
what kind of route memory exists,
and whether any current live state is known at all.

## 2) ViewFS has already named the most useful shell-facing object split

ViewFS’s `type-lenses-handler-racks-and-open-state-badges` surface is a direct gift here.
It keeps declared type, derived type, associated handlers, chosen opener, live open state, and receipt/history explicitly separate.
That is almost exactly the shell+terminal truth split Schell needs once chapter-local objects can leave the terminal.

## 3) Steward keeps detours, pending requests, and history lanes distinct

Steward keeps chooser/open/auth/approval detours as typed pending and outcome lanes, and it keeps history policy as its own lane instead of silently flattening remembered surfaces into execution truth.
That suggests Schell should let `chooser pending`, `admitted external`, `history only`, and `recheck required` stay distinct badges instead of collapsing them into one “open” chip.

## 4) Helm warns that preview and stronger action should not blur

Helm’s preview-warrant and enactment-bond seam is useful pressure even though Schell is not becoming Helm.
A safe preview route, an exact reveal route, an external edit route, and a remembered recent opener do not deserve one common strength class.
Some routes are inspect-only, some are review-first, and some need recheck before they can be claimed again.

## 5) Harbor and Ward keep route residue and freshness honest

Harbor’s confirmation-gap posture is a good reminder that plausible routing cues are not the same as client-facing confirmation.
Ward keeps freshness and revalidation pressure alive, which matters whenever Schell wants to reuse opener memory or a recent handoff hint.
A route that worked before may still be a useful suggestion, but it should climb only after fresh current-basis confirmation.

## 6) Foundry keeps residue classes from collapsing into one score

Foundry keeps reminder pressure around allocation basis, residue class, and apportionment fences.
That matters here because Schell will likely accumulate several different weak external-route residues:
- recent handoff,
- previous opener choice,
- provider-local default,
- live-state uncertainty,
- and durable imported local authority.

Foundry’s lesson is that those should stay in different residue classes rather than being collapsed into one generic confidence badge.

## 7) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- a final handler registry,
- a final recent-items database,
- a final external-live-observation protocol,
- or a final open-with UX architecture.

It only earns a smaller companion rule:
**keep opener class, opener provenance, live-state badge, and recent-hint posture explicitly separate before Schell gets any more magical about external routes.**
