# Research synthesis pass CCXXXII: arrival ledgers, spend floors, and reversible action honesty

Revision: rev0235  
Date: 2026-05-13  
Scope: current terminal/shell/agent precedents viewed through the question “what may an imported command card do now?”

## 1. Field signal

The field keeps pushing terminal work toward reusable objects and agentic action:

- VS Code terminal shell integration makes command regions visible with command guides, sticky scroll, quick fixes, and recent-command recall.
- WezTerm-style shell integration uses OSC 7/133/1337 to expose cwd, prompt/input/output zones, and pane-local user variables.
- Kitty's keyboard protocol shows that richer input should be opt-in and detectable, with legacy recovery paths.
- Warp makes terminal and agent conversations adjacent, searchable, and resumable, with context-window management becoming visible product surface.
- Claude Code hooks and permission rules show lifecycle automation and product-enforced allow/ask/deny policy.
- Codex and Copilot cloud-agent docs separate sandbox/firewall boundaries from approval and network policy.
- MCP security guidance keeps stressing consent, scope, tool risk, and confused-deputy controls.

Rev0235's synthesis: Schell's next hard problem is not card richness. It is **authority spend accounting** at the instant a convenient card tries to become an effect.

## 2. Updated observations

### 2.1 Quick fixes need floors

Quick fixes are excellent, but a detector suggestion can be wrong, stale, source-local, or projection-only. Schell should make quick fixes feel instant for read/draft actions and visibly gated for kill/rerun/open/network/delete/send.

### 2.2 Complete evidence is not current authority

A portable capsule can carry every digest and interval we care about and still be read-only on arrival. Current cwd, env epoch, policy epoch, account lane, route, rollback story, and operator intent are separate facts.

### 2.3 Reversibility must be current

Old snapshots, old undo labels, timeout-looking output, and helper confidence are not rollback authority. A real reversal budget names target, scope, settlement/effect identity, and whether the action escaped the machine.

### 2.4 Helper automation needs spend rows

Hooks, pre-tool checks, sandbox modes, cloud firewalls, and MCP tool catalogs all point toward useful automation. Schell should not ban automation. It should require each effectful helper move to expose a spend row: actor, verb, source of authority, floor, receipts, and denial reason.

### 2.5 Imported ingress is multiple spends

Paste, submit, open URL, open path, reauthorize, network fetch, and patch apply are not one “use this card” action. They spend different authority and need separate receipts.

## 3. Lessons we must keep learning from the past

1. Fast buttons rot unless their authority source is visible.
2. Undo-looking UI is dangerous without a current rollback receipt.
3. A transcript or card can be complete evidence and still be non-authoritative.
4. Imported context is an excellent draft source, not a launch source.
5. Fresh attention is not fresh approval.
6. Account, route, path, and browser facts are local until rebound.

## 4. Brilliant ideas to steal, with fences

- Steal quick fixes, but put the action floor in the button.
- Steal agent hooks, but ledger every effectful hook result.
- Steal context windows, but show coverage and compression boundaries.
- Steal command history sync, but age replay authority separately from search value.
- Steal semantic input protocols, but require support detection and fallback receipts.
- Steal cloud-agent firewalls, but show network posture as a card chip.
- Steal consent UX from auth protocols, but apply it to command-card effects.

## 5. Recommendation

Keep building simulator specimens before building the real protocol. The next Schell object should be a rendered arrival footer: “read now / draft now / reveal needed / reauth needed / review needed / blocked because…”. If that footer is legible, the final terminal can become extremely fast without becoming slippery.
