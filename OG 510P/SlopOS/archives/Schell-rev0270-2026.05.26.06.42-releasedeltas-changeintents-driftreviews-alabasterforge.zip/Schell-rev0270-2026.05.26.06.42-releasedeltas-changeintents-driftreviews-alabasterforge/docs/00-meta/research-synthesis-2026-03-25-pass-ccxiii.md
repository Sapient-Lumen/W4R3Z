# Research synthesis — 2026-03-25 — pass CCXIII

This pass sharpens the next compact lesson from current official docs on distributed trace context, propagated baggage, browser user activation, portal open/ask activation, field-manager ownership, and code-action disabled reasons:
**the smartest next move for Schell is not a giant provenance graph. It is a smaller causal-lane story: let helper-rich shell objects carry tiny witnesses that keep why-this-appeared, fresh gesture proof, carried context, spender footing, approval basis, and disabled reason visibly separate.**

## 1) W3C Trace Context and OpenTelemetry show what causal context is good at — and what it is not

Trace Context standardizes portable request-correlation headers such as `traceparent` and optional `tracestate`, giving distributed systems a common way to connect one request to the next.
OpenTelemetry then makes the lesson explicit: context propagation helps build causal information across process and network boundaries.
That is an excellent steal for Schell.
Action cards and helper returns can benefit from exact correlation handles.

But the OpenTelemetry security guidance is equally important.
It warns to be cautious about accepting context from external sources and warns that baggage carries arbitrary key/value pairs across service boundaries, so sensitive information should not be placed there.
That is exactly the humility rail Schell needs:
**carried context is good for explanation and correlation, but it is still weaker than portable approval or spend authority.**

## 2) Browser user activation shows the next smaller truth: fresh gesture proof

MDN's `UserActivation` docs keep two neighboring truths separate: sticky activation and transient activation.
Transient activation answers whether the user is interacting now; sticky activation only means the user has interacted since load.
This is a nearly perfect lesson for Schell.
A remembered proposal, prior focus, or earlier click can explain why an affordance exists, but it should stay weaker than a fresh gesture that still arms a stronger action right now.

## 3) XDG OpenURI shows chooser intent, opener choice, and activation are different steps

The OpenURI portal keeps the `ask` option separate from an `activation_token`, and the portal returns a request handle for the interaction itself.
That means a cross-app move is not one blur.
There is chooser posture, request-handle posture, and activation posture.
Schell should steal that separation.
A proposal can therefore say `chooser required`, `request in flight`, `chosen app known`, or `activation token spent` instead of flattering every open-like affordance into one immediate do-it path.

## 4) Kubernetes managed fields show why spender footing matters

Server-Side Apply keeps field ownership explicit.
The API server tracks managed fields; a different manager trying to change a field can hit a conflict; and the current field manager is the actor who last asserted the value.
That is a direct design lesson for Schell:
**a proposal can be current and still belong to the wrong spender.**
The shell should therefore be able to say not just `why is this here?`, but `who actually owns the thing that would change if we commit this?`

## 5) VS Code CodeAction shows why disabled reasons should stay visible

VS Code's API keeps a code action's edit/command payload separate from diagnostics and from `disabled.reason`.
If both edit and command are present, the edit is applied first and then the command runs.
That separation is healthy because it prevents suggestion folklore from collapsing into one generic quick fix myth.
Schell should steal the same discipline:
proposal payload, approval basis, spender footing, and disabled reason should remain inspectable even when the stronger apply path is unavailable.

## 6) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- let proposal cause stay separate from fresh gesture proof,
- keep carried context useful for explanation without letting it silently become approval,
- surface spender footing before strong action when another app/helper/manager would actually spend the effect,
- keep approval basis and disabled reason visible on stronger-looking cards,
- and cool expired gestures or stale anchors to compare / re-review / re-arm rather than bluffing.

That is enough to make detectors, quick fixes, portal returns, helper suggestions, and assistant-born follow-ons much more trustworthy while still deferring the final tracing, chooser, and recommendation architecture.
