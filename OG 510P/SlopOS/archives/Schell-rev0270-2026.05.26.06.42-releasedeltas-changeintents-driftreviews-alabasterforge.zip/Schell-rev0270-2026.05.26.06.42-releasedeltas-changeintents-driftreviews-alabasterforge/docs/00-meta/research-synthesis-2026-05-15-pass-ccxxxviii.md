# Research synthesis — 2026-05-15 pass CCXXXVIII

Focus: audit capsules, witness chains, tamper lanes, redaction custody, and durable aftercare for Schell command cards.

## Sources re-read this pass

- Terminal/session precedent: command-aware terminal integration and terminal recording formats remain useful, but visible text and cast streams stay weaker than launch/process/settlement truth.
- Observability precedent: trace context, logs, semantic conventions, CLI spans, and lineage facets show how command work can become searchable and correlated across systems.
- Audit/provenance precedent: signed syslog, in-toto link attestations, SLSA provenance, and transparency logs show how to preserve sequence, inputs, products, commands, builders, and tamper-evident publication.
- SlopOS precedent: ACP, OpenURI, FedCM, MCP, capshell, crypto-audit, attestation freshness, network idempotency, and hot-action boundaries keep receipts scoped, redaction-safe, and non-authoritative.

## What Schell should steal

1. **Sequence and gap detection.** Signed-log practice makes missing-message detection a first-class audit outcome. Schell should show chain gaps in the command card, not bury them in debug logs.
2. **Trace correlation without trace authority.** W3C-style forwarding/participation is a superb mental model for source/collector/helper lanes: carry correlation, but do not turn correlation into authorization or settlement.
3. **CLI/process semantic rows.** OpenTelemetry-style command/process fields are a good search spine for command chapters, especially argv, executable, working directory, exit, observed timestamp, trace id, and attributes.
4. **Materials/products/byproducts.** in-toto and SLSA show how generated artifacts can carry enough provenance to debug and audit. Schell should bind those rows to command envelopes and settlement witnesses.
5. **Lineage facets.** OpenLineage-style facets are useful for rich command products, but old facets stay source-labeled and never become live target authority.
6. **Portable event envelopes.** CloudEvents-like id/source/type/time/datacontenttype thinking is valuable for export hygiene, while remaining too generic to be Schell's final audit truth.
7. **Terminal event streams.** Asciinema-style newline-delimited event streams are easy to share and replay; Schell must label them transcript/recording custody, not launch or settlement custody.
8. **Transparency as publication proof.** Sigstore/Rekor-style transparency pressure is useful for proving publication/inclusion, but does not prove that a redacted capsule is complete or true.

## What Schell must refuse

- Treating helper markdown, screenshots, issue exports, terminal casts, trace IDs, build attestations, inclusion proofs, or collector logs as raw settlement evidence.
- Hiding redaction loss when target names, account chips, effect keys, duplicate windows, or destructive scopes are removed.
- Letting imported archive chains spend authority without recipient rebind.
- Treating clock-normalized exports as stronger than monotonic/event sequence lanes.
- Letting one green audit badge cover partial target matrices or source/collector conflicts.

## No-regret next move

Keep an **audit capsule** paper surface: event identity, sequence lane, source/collector split, clock basis, raw reveal, projection loss, correlation context, and action floor after import. Use it to test whether users can predict custody before Schell invents a live evidence store.
