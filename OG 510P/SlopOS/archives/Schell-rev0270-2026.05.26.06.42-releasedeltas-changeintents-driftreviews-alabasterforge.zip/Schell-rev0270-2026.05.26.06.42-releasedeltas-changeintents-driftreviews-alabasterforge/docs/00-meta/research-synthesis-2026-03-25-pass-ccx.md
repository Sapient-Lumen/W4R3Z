# Research synthesis — 2026-03-25 — pass CCX

This pass sharpens the next compact lesson from current official docs on terminal persistence, multiplexed attach, session restoration, one-time restore tokens, and watch bookmarks:
**the smartest next move for Schell is not a bigger session-resurrection engine. It is a smaller continuity-proof story: let returned surfaces carry tiny continuation tickets, keep same-family continuity separate from same-runtime proof, and make rebind versus historical-only aftermath explicit.**

## 1) VS Code proves that reconnect and revive are already neighboring truths

VS Code's terminal docs keep the basic lesson honest.
Persistent sessions can reconnect when a window opens again, scrollback restoration is separately configurable, and process revive is configurable independently.
Detach/attach is also explicit at the session level.
That is exactly the sort of neighboring-truth posture Schell wants: reconnected view, revived process, and fresh shell are related conveniences, not one universal continuity claim.

## 2) WezTerm shows that domain continuity is useful without pretending the UI view is the same thing

WezTerm's multiplexing docs define a domain as a distinct set of windows and tabs, and once connected that domain can attach windows and tabs to the local native UI.
That is a strong design hint for Schell.
A returned UI view may belong to the same broader continuity family while still being a fresh local view object.
That pushes Schell toward explicitly naming **same continuity family** separately from **same live runtime / same view object**.

## 3) iTerm2 session restoration is a powerful reminder that restored content and running jobs are composed, not identical

iTerm2 explains session restoration by running jobs inside long-lived servers.
If iTerm2 crashes or upgrades, the servers keep going; on restart, iTerm2 finds them again and marries restored window content to the appropriate server.
That is a brilliant product move, but it is also a humility lesson: restored window content, running jobs, and the rebinding act are distinct parts of one continuity story.
Schell should steal the compositional insight, not flatten it into generic `restored` folklore.

## 4) XDG restore tokens teach the best compact continuation-ticket posture

The XDG portal docs are especially useful here.
Persistent sessions can vary by `persist_mode`, and the restore token is invalidated after one use; a later restore must use the new token returned when the session starts again.
That is almost a direct design brief for Schell's return paths.
A detour-return witness should often be a **small, freshness-bearing, rotate-on-success continuation ticket**, not a timeless reopen charm.

## 5) Kubernetes BOOKMARK semantics add the synced-through humility

Kubernetes watch docs add one more excellent lesson.
`BOOKMARK` events indicate the resource version to which a watch is synced, but clients must not assume bookmarks arrive at any specific interval or even at all.
That is the right continuity posture for a shell too:
**synced through** is useful, but it is weaker than same-runtime proof.
A returned terminal surface may know where its observed history got to without claiming that the live runtime or control footing is unchanged.

## 6) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- add **continuation tickets** for some detour-return, restore, and reattach paths,
- keep **same-family continuity** separate from **same-runtime / same-cycle proof**,
- surface **same-runtime**, **same-family-new-view**, **successor-rebound**, **rebind-required**, and **historical-only** honestly,
- let bookmarks and synced-through markers help reacquire place without overclaiming liveness,
- and keep all of that smaller than a universal session-roaming or restore engine.

That is enough to make the shell feel unusually trustworthy after crash, detach, relaunch, reconnect, or restore while still deferring the final continuation protocol, runtime-proof substrate, and successor-adoption policy.
