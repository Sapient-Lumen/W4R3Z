# Research synthesis — 2026-03-25 — pass CCVI

This pass sharpens a smaller and more exciting lesson from current official browser, mobile, runtime, and portal-adjacent docs:
**the smartest next move for Schell is not a bigger permission system. It is a smaller neighboring-state story: keep advisory outlook, explicit user-gesture boost, visibly active while-in-use power, and durable later access separate, because current systems already do.**

## 1) Chrome’s activeTab is the cleanest steal for chapter-local temporary power

Chrome’s `activeTab` permission is unusually instructive.
It gives temporary access to the currently active tab only when the user explicitly invokes the extension, lasts while the user stays on that page, and is revoked on navigation or close.
That is exactly the sort of move Schell should steal in spirit.
A shell+terminal can feel extraordinarily sharp if an explicit action on one current chapter/object temporarily enables richer exact actions for that same object without pretending a standing durable grant now exists.

## 2) Android makes “Only this time” and auto-reset a first-class design lesson

Android 11 is even clearer.
It adds an `Only this time` permission posture for location, microphone, and camera; it auto-resets sensitive runtime permissions for unused apps; and repeated denials can suppress future prompts.
Together those moves teach a great shell+terminal lesson:
**temporary power, durable power, and permission outlook are different classes, and denial history is itself part of honest preflight posture.**
Schell should be able to say not just “possible” but also “likely prompt”, “temporarily available”, “ask again later”, or “policy-blocked here”.

## 3) While-in-use permissions show why current authority can differ from nominal permission state

Android’s foreground-service restrictions reveal an especially important subtlety.
For camera, location, and microphone service types, while-in-use permissions are available only while the app is actually in the foreground; if the app is backgrounded and tries to start one of those services, the system can throw a `SecurityException` even though `checkSelfPermission()` may still report `PERMISSION_GRANTED` because that answer only means “granted while in use.”
That is a spectacular warning for Schell.
An optimistic permission chip or remembered grant can be real and still be weaker than actual current authority.
Schell should therefore keep **outlook** and **active now** visibly separate.

## 4) Strong temporary power tends to come with visible indicators

Android’s foreground-service overview says foreground services are for user-noticeable operations and must show a status-bar notification.
That is a good design constraint to steal.
The stronger and longer-lived a temporary power becomes, the more it deserves a visible active badge, chapter-local indicator, or shell-owned status strip instead of hiding inside a pretty object card.

## 5) Deno proves query/request/revoke is a better mental model than one generic allow bit

Deno’s permissions API is another compact clue.
It supports `query()`, `request()`, and `revoke()`, and permission descriptors can be narrowed by concrete dimensions such as host, path, or command.
That pushes Schell toward small object-local posture chips and exact boost scopes instead of one ambient “allowed” myth.
A command chapter may need to ask: do I have outlook only, do I need request now, am I active on this exact path/host/object, or has the temporary power already been revoked?

## 6) Browser file access now models session-only and durable-later as explicit neighbors

Chrome’s File System Access guidance says stored file or directory handles should be rechecked with `queryPermission()` and re-requested if needed, because permissions are not always persisted between sessions.
Chrome’s newer persistent-permissions behavior makes the split even sharper by offering `Allow this time`, `Allow on every visit`, and `Don't allow`.
That is a nearly perfect precedent for Schell’s access ladder:
- current-turn boost,
- current-session use,
- durable later if explicitly upgraded,
- and revalidation when needed.

## 7) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- add **outlook chips** for advisory preflight posture,
- add **focus/gesture-scoped boosts** for the exact current chapter/object,
- add **active-now badges** when stronger temporary power is visibly in use,
- keep **durable later** as an explicit upgrade,
- and keep all of those weaker than fresh reviewed shell truth.

That is enough to make the shell feel unusually good while still deferring the final grant-wallet, baton substrate, active-indicator plane, persistence database, and policy architecture.
