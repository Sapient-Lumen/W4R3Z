# Datacube evaluation pass CCXXIX: evidence dockets as Schell's boundary object

Revision: rev0232  
Date: 2026-05-13  
Scope: SlopOS rev0695 plus Foundry, Harbor, Steward, ViewFS, Helm, and Ward pressure on the four-card Schell prototype.

## 1. SlopOS: imported convenience needs a boundary object

SlopOS rev0695's FedCM pass keeps browser/provider signals useful without letting them become portable SlopOS account truth. Rev0232 applies the same posture to terminal work: shell marks, helper policies, hyperlinks, clipboard writes, remote paths, notifications, and copied blocks are all useful provider/hop/context claims. They need a small boundary object before becoming action.

The Schell name for that object is now **evidence docket**.

## 2. Foundry: spine versus serving lanes

Foundry's pressure is to keep the spine small. The evidence docket uses six rows rather than a giant terminal ontology. Command cards, sticky headers, quick fixes, helper packets, structured lenses, and export receipts are serving lanes around that spine.

## 3. Harbor: basis changes are contract changes

Harbor's temporal witnesses map directly to Card C and Card D. A restored remote command, a repo-root switch, a helper policy epoch, or a route/path translation can change the contract underneath the same visible command text. The docket forces those changes into the card rather than burying them in logs.

## 4. Steward: do not collapse cause, condition, and aftermath

Steward says detector confidence, policy allow, operator approval, command launch, provider settlement, and aftercare success are different facts. Card D's helper-policy docket and Card B's escape-seam docket are built to preserve those distinctions.

## 5. ViewFS: projection is not object truth

ViewFS ghosts and projection badges transfer cleanly to terminal exports and rich lenses. A filtered test summary, copied block, terminal-chat context packet, or hyperlink preview is not the raw object. Rev0232 adds evidence-export integrity so shared command chapters cannot impersonate complete proof after losing raw reveal links.

## 6. Helm: every action card is a door

Helm's doorpack/review-queue posture says quick fixes are doors with different floors. Kill-port, install-package, open-PR, curl-pipe, browser open, remote open, helper tool call, and cloud mutation must not be presented as one generic “fix.” The evidence docket makes authority spend a row, not a tooltip.

## 7. Ward: tier witnesses must survive compression

Ward's tier witness lesson is now a UI warning: a compressed card can be beautiful only if it preserves raw/restored/projected/helper/export tiers. If the card header is compact but the tier is unrecoverable, the design has failed.

## 8. Evaluation of rev0231

Rev0231 created the operator-comprehension scorecard and expanded fixture pack. Its weakness was that the next artifact was still prose: “make four cards.” Rev0232 stores the four cards in `four-card-downgrade-literacy-prototype-v0.json`, adds eight harder fixtures, and lints the prototype shape.

## 9. Recommended next move

Render the four cards and test real comprehension. Do not add more badges or more schema until an operator can answer CQ-01 through CQ-05 from the card plus one docket gesture. If the human test fails, simplify the card language and action verbs before adding any final terminal architecture.
