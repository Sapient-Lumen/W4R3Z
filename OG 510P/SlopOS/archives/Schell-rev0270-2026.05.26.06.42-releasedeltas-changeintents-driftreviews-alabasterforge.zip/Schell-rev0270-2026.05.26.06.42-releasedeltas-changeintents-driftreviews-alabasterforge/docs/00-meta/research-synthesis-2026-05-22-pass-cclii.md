# Research synthesis — 2026-05-22 pass CCLII

Theme: **proof claims need status, revocation, narrowing, and challenge state**.

Rev0254 made the proof docket disclosure-sensitive. The next pressure is lifecycle: once a proof claim is issued, other systems and operators will cache it, cite it, challenge it, narrow it, revoke it, or attach it to a transparency or attestation trail. Schell needs a checked status vocabulary before any UI or runtime starts rendering proof as green.

External pressure imported:

- W3C Bitstring Status List v1.0 treats suspension and revocation as publishable credential status. Bounded take: Schell can learn the idea of compact status, but the status row itself is retained metadata with a privacy budget.
- W3C Verifiable Credential Data Integrity emphasizes authenticity and integrity proofs. Bounded take: Schell can demand proof integrity without claiming that a signed proof is true, private, current, or non-resurrecting.
- Sigstore/Rekor and Certificate Transparency make append-only auditability vivid. Bounded take: append-only proof metadata is useful for tamper evidence and dangerous for forgetting, because it may be impossible or inappropriate to remove.
- RFC 7009 token revocation invalidates the token and sometimes related grant-derived tokens. Bounded take: revocation is a status transition, not deletion of every projection, summary, log, helper memory, or backup.
- in-toto/SLSA frame attestations as authenticated metadata consumed by policy engines. Bounded take: proof claims will become machine-actionable unless Schell marks stale, revoked, narrowed, or challenged states as no-use.
- NIST SP 800-88 Rev.2 keeps sanitization stronger than local absence, redaction, status, or revocation. Bounded take: status may say `revoked`, `expired`, or `contradicted`, but not `sanitized`.
- OpenTelemetry sensitive-data guidance keeps minimization pressure on exported proof and challenge telemetry.
- OWASP vector/embedding and MCP consent pressure keep helper/vector influence challenges distinct from raw-row deletion.

Imported architecture pressure:

```text
proof claim status = claim id + evidence epoch + disclosure tier + status + witness + challenge route + no-use quarantine + expiry + aftercare
```

New failure class:

```text
A revoked proof claim can still leak the forgotten object.
A narrowed proof claim can still be over-read as global forgetting.
A challenged proof claim can still be used by a helper unless no-use quarantine is explicit.
A public status list can permanently reveal incident existence.
```

Non-takes:

- no VC profile;
- no OAuth revocation endpoint;
- no Rekor/CT publication policy;
- no in-toto layout;
- no legal/compliance workflow;
- no helper/vector runtime;
- no terminal UI or shell protocol;
- no claim that status-list revocation proves erasure.
