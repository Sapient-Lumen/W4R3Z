# SlopOS datacube evaluation — pass CCXXXIX

Focus: what Schell should learn from SlopOS about replay closure and live authority fences.

## Imported discipline

SlopOS continues to push the same lesson from another angle:

- ACP receipts can carry outcome evidence without becoming the next hot-action approval.
- OpenURI can prove launch handoff without proving downstream app completion or user attention.
- FedCM browser/account mechanics are provider-local until the current recipient session binds them.
- MCP metadata, prompts, resources, progress, logs, tool schemas, and tool results are import evidence until current consent and schema bind.
- Capshell keeps command strings, argv, cwd, env, handles, resources, and result sidecars separate, which is exactly what replay closure needs.
- Crypto/audit and attestation surfaces keep secrets, digests, and verifier-local freshness scoped.
- Network idempotency and hot-action ordering keep retry/duplicate/order claims scoped by parameters, provider, queue, and time window.

## Schell-specific consequence

Schell should treat replay as a ladder:

`inspect -> draft -> sandbox/dry-run -> compare -> review -> live spend`

No imported replay packet should jump the ladder. A strong replay closure can make comparison luxurious; it cannot skip recipient rebind, policy currentness, target currentness, or fresh gesture.

The SlopOS-aligned rule for Schell rev0242:

> replay packets carry source evidence; live effects require recipient authority.

## What not to copy yet

Do not copy SlopOS schemas wholesale into a terminal replay format. Do not freeze capshell exec packs, ACP outcomes, MCP import packets, FedCM account rows, OpenURI receipts, idempotency keys, or hot-action queues as Schell's replay substrate yet. Schell first needs to prove the human-facing replay closure vocabulary.

## Next pressure

Run RV-PF prediction questions over RV-0001 through RV-0020. If operators cannot distinguish cast playback, deterministic compare, provenance verification, trace correlation, environment closure, missing input, and current authority from one compact line, Schell should simplify before building any replay runner.
