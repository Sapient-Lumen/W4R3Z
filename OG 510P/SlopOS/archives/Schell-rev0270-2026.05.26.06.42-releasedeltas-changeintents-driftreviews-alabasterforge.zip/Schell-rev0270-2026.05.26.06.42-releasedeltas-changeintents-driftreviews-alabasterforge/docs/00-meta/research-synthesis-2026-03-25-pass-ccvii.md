# Research synthesis — 2026-03-25 — pass CCVII

This pass sharpens the next compact lesson from current official permission, browser, mobile, and portal docs:
**the smartest next move for Schell is not a bigger permission center. It is a smaller watch-duty story: keep issuance/history, watched current state, recheck-now posture, and quarantine visibly separate, because current systems already do.**

## 1) The web permission stack already says permission state can change after grant

The current W3C Permissions specification is blunt: the platform standardizes both querying permission state and being notified if that state changes.
That matters for Schell because it means a remembered grant is not the whole design problem.
If a platform can tell you permission changed, then a shell+terminal owes the operator an honest answer about whether it is relying on fresh watched state or on stale historical posture.

## 2) Chrome keeps temporary power narrow and revocable by ordinary drift

Chrome's `activeTab` remains one of the cleanest lessons in temporary authority.
Access appears only after explicit user invocation, lasts only while the user stays on that page, and is revoked on navigation or close.
That teaches Schell a very useful rule:
**if ordinary navigation or visibility drift ends the power, then remembered availability should quickly degrade to recheck or quarantine rather than pretending the route is still live.**

## 3) File System Access proves that stored handles need recheck, not blind trust

Chrome's File System Access guidance now says stored file or directory handles should be verified with `queryPermission()` and re-requested with `requestPermission()` when needed, because permissions are not always persisted between sessions.
The newer persistent-permissions behavior sharpens this even more: users can grant session-only or durable access, can revoke access per item, and Chrome even treats some backgrounding cases as automatic revocation that requires a fresh request.
That is almost a complete shell lesson already.
Schell should treat stored object cards and recent handles as excellent *staging material*, but weaker than fresh current-state truth.

## 4) Android makes revocation and auto-reset part of the normal lifecycle

Android's runtime-permission guidance is even harsher in a useful way.
One-time permission lasts only while the app remains suitably foregrounded; if the user revokes that one-time permission, the app process terminates; and Android also supports auto-reset for unused apps.
The result is clear:
**permission loss is not an exception path that polite systems hide. It is an ordinary lifecycle transition that systems should model calmly and explicitly.**
Schell should therefore treat `revoked`, `expired`, `while-in-use lost`, and `auto-reset` as first-class operator truths rather than one generic denied badge.

## 5) Portal systems already keep grant, revoke, and deletion explicit

The XDG Documents portal is another strong clue.
It has explicit `GrantPermissions`, `RevokePermissions`, and `Delete` operations, and it exposes document-info/permission state through the portal's own objects rather than by letting historical handles magically answer every current question.
That is a healthy model for Schell too.
Strong acts should hang off explicit current footing, and when the shell lacks that footing it should prefer a recheck rail or quarantine gate over false confidence.

## 6) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- add **watch leases** when a stronger next action depends on mutable provider-owned state,
- add **recheck-now chips** as normal next steps,
- add **provider-state-unknown** and **history-only** badges when live truth is gone,
- add **quarantine gates** when stronger action would otherwise overclaim,
- and keep all of those weaker than fresh reviewed shell truth.

That is enough to make the shell feel unusually sharp while still deferring the final watch protocol, callback bus, quarantine palette, and revocation-store architecture.
