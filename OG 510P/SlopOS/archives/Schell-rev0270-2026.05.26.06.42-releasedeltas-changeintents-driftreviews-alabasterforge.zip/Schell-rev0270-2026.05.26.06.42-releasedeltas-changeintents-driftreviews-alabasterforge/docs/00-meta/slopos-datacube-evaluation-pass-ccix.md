# SlopOS datacube evaluation — 2026-03-25 — pass CCIX

**Schell should add effect keys, duplicate-spend honesty, and retry-identity humility, because SlopOS and the companion datacubes keep proving that reviewed target identity, current live state, retry-equivalent requested effect, and historical residue are neighboring truths rather than one flattering `run that again` story.**

## 1) SlopOS already keeps replay-safe request identity smaller than a mutable upsert seam

SlopOS's network-request idempotency boundary is especially sharp here.
Same scoped request identity replays only the same canonical request, while same key plus different canonical bytes must reject before effect.
That is almost a direct design brief for Schell's stronger shell actions.
A retry key should not become a hidden “edit the old request in place” language.

## 2) Steward gives Schell the exact compact vocabulary it wants

Steward's effect-key posture is unusually helpful because it keeps retry-safe effect identity separate from target identity, live state, and current authority.
It also insists that duplicate suppression, pending work, mismatch, and bounded retention windows should all remain visible outcomes instead of one generic retry myth.
That maps beautifully into Schell's command chapters, handoff warrants, repair cards, and stronger follow-through rails.

## 3) ViewFS and Harbor reinforce the aftermath honesty

ViewFS keeps replay guards, promotion lanes, and source drift honest, which is the right pressure for any shell surface that wants to reoffer earlier actions without silently reauthorizing them.
Harbor's replay/consumption honesty pressure adds the same warning from another angle: duplicate suppression and prior-consumption evidence should be visible as their own aftermath class rather than disappearing into a fresh-success fairy tale.

## 4) Foundry is useful because it names the budgeting side of the same problem

Foundry's inspiration notes explicitly call out effect keys, prior-outcome anchors, and bounded dedupe horizons.
That matters for Schell because duplicate-spend truth is not just about network requests.
It is also about launches, cross-app sends, repairs, approvals, and any action where a beautiful retry button could otherwise do the expensive thing twice.

## 5) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- one final effect-fingerprint schema,
- one final dedupe-window substrate,
- one final pending/completed duplicate outcome lattice across every backend,
- one final exactly-once or transaction protocol,
- or one final history/assistant auto-retry constitution.

It only earns a smaller companion rule:
**let some stronger chapter-local actions carry tiny effect keys, keep duplicate-spend truth separate from stale-basis truth, and make mismatch / still-processing / duplicate-suppressed / dedupe-window-expired outcomes first-class before Schell gets any more magical about retries.**
