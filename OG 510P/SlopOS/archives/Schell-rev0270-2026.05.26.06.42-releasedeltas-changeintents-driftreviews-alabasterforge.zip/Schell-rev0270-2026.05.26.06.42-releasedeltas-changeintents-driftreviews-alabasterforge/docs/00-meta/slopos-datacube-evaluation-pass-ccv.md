# SlopOS datacube evaluation — 2026-03-25 — pass CCV

**Schell should add object-local grant shelves, lease badges, least-widening upgrades, and renewal humility, because SlopOS keeps OpenURI launch separate from resource grant and durable document authority while the companion cubes keep scope width, persistence, and helper propagation as neighboring truths rather than one flattering “it opened so I can still use it” story.**

## 1) SlopOS already separates launch from durable access

SlopOS’s OpenURI resource-grant boundary says generic mediated launch is **not** a portable local-resource grant, URI permission, security scope, attachment grant, or docref handoff.
Its recent-items boundary separately refuses durable history and reopen semantics on generic URI launch.
Its document-portal posture then puts persistence on an explicit document seam, keeps persistence optional, keeps docrefs non-bearer, and refuses app-visible grant inventory.
That means Schell should not stop at opener racks.
It also needs one compact way to say what kind of access, if any, actually exists after the route.

## 2) ViewFS points to the right shell-facing object split

ViewFS is especially strong pressure here.
Its archive keeps chooser/import/save as first-class authority events, treats synthetic grant views as intentionally partial, and repeatedly warns that persistent grants are useful without being magical.
That is a direct fit for Schell.
A terminal object card should be able to say: this is just an observed object, this is a transfer-once object, this is a persistent reopen handle, or this is an imported local copy now detached from the old grant.

## 3) Helm sharpens least-widening and grant-rung posture

Helm’s grant-rung and authority-window language is a helpful reminder that the first healthy grant is often the narrow one.
A current-only or exact-subject grant is not the same as a broader persistent scope.
That pushes Schell toward explicit **grant ladders** rather than one generic “remember this” action.
The shell should stay decision-light and prefer exact-object now, then persistence later if the work proves it deserves it.

## 4) Harbor keeps chooser and aftermath claims honest

Harbor repeatedly insists that chooser hints, selected results, local residue, and durable truth are not the same thing.
That matters here because access UX often tempts designers to collapse “the chooser let me do it once” into “the shell may now act on this object indefinitely.”
Harbor’s lesson is to keep a visible aftermath floor:
- worked now,
- restart-sensitive,
- renewable,
- or re-ask required.

## 5) Apple/Android/XDG pressure all reinforce helper-footing humility

One of the sharpest new lessons from current platform docs is that helper propagation deserves its own seam.
Apple distinguishes static child-process inheritance from post-launch PowerBox access and requires explicit data or bookmark passing for the latter.
Android distinguishes temporary URI permission from explicitly persisted permission.
XDG distinguishes transient file transfer from cross-session accessibility via the Documents portal.
So Schell should not imply that a parent chapter’s access automatically means a helper or later background flow can use the same object without a second named footing.

## 6) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- a final bookmark/docref substrate,
- a final grant wallet or inventory UX,
- a final helper-propagation architecture,
- or a final imported-copy versus persistent-reopen substrate.

It only earns a smaller companion rule:
**keep grant kind, scope width, duration, renewal floor, and helper footing explicitly separate before Schell gets any more magical about durable object access.**
