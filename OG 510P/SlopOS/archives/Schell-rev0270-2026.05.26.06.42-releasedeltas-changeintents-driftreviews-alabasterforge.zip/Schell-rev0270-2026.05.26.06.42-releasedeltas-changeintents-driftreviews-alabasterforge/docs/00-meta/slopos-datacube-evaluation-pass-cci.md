# SlopOS datacube evaluation — 2026-03-25 — pass CCI

**Schell should center its shell+terminal design on one exact command-chapter packet family and keep history engines, finish cues, and terminal luxury metadata visibly weaker than reviewed shell truth, because SlopOS keeps rewarding exact basis, provider-locality humility, approval-basis narrowness, and explicit separation between descriptive projections and portable authority.**

## 1) SlopOS exact-basis posture argues for one shell-owned chapter object

SlopOS keeps insisting that exact reviewed basis matters more than ambient convenience.
Its capshell boundary work refuses hidden command-string fallback, ambient PATH authority, shebang-as-authority, and startup-hook reintroduction.
Its approval-basis posture also refuses vague “latest/current/head now” folklore as approval basis.
That is the right companion pressure for Schell.
A visible command chapter should therefore be a shell-owned object tied to exact accepted input, exact ground, and later exact outcome — not a flattering block inferred from terminal chrome.

## 2) Provider-locality pressure says luxury metadata should stay descriptive

Recent SlopOS boundary work keeps reasserting that provider-local session/result/account/profile material should not quietly become portable substrate truth.
That maps directly onto terminal luxuries.
Cwd hints, chapter marks, local command palettes, title updates, history ranks, and prompt-click affordances may be incredibly useful, but they are still local descriptive projections until the shell promotes them into an explicitly named witness.
That is the right Schell import of the SlopOS boundary habit.

## 3) Approval-basis pressure says history and notifications are not permission caches

SlopOS is also unusually clear that prior approval does not become a generic cache for later mutable targets.
Schell should steal that discipline.
A history row, prediction, completion cue, or finish notification should never flatter the operator into thinking that “I saw this before” is the same thing as “this is still approved on the current basis.”
So command recall should prefer inspect / insert / derive / compare before any stronger rerun rail, and notifications should route back to exact chapter review instead of trying to spend hidden authority inline.

## 4) The companion cubes keep the seam honest

- **Harbor** reinforces label honesty, which matters when Schell should say shell-authenticated, relay-weakened, guessed, historical, private, or plugin-sourced instead of one flattering command-smart badge.
- **Ward** reinforces freshness and revalidation pressure, which matters when a chapter, history row, or finish cue is older than the current ground.
- **Steward** reinforces adaptation and session-proof posture, which matters when local luxury metadata is repaired, cached, or partially restored rather than freshly asserted.
- **Helm** reinforces miss-ledger discipline, which matters when a command chapter looked complete but the finish cue, output grouping, or history eligibility was partial or downgraded.
- **Foundry** reinforces actor/path caveat discipline, which matters when source/authorship of commands or predictions is mixed across operator, assistant, plugin, workflow, or imported surfaces.
- **ViewFS** again supplies the neighboring-state rule: editable text, chapter packets, history rows, finish cues, and local metadata should remain neighbors rather than collapsing into one flattering shell truth surface.

## 5) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final semantic transport,
- one final history database or sync backend,
- one final notification protocol,
- one final palette or browser architecture,
- or one final plugin/runtime extension story.

It only earns a smaller rule:
**exact command chapters first; history hygiene and local luxury second.**
