# Research synthesis pass CCXXXI: transfer gauntlets, capsule custody, and redaction receipts

Revision: rev0234  
Date: 2026-05-13  
Scope: terminal/shell/agent precedents viewed through the question “what survives when command cards cross boundaries?”

## 1. Field signal

The field is still moving toward object-like terminal work:

- VS Code shell integration exposes command guides, sticky command headers, quick fixes, recent-command recall, and output-to-editor style affordances.
- WezTerm and Contour-style shell integration expose cwd and prompt/input/output zones through OSC sequences.
- iTerm2 documents OSC 8 hyperlinks and OSC 52 clipboard effects, reminding us that terminal output can create link and clipboard consequences.
- Kitty's keyboard protocol shows a better pattern for enhancement: query support, progressively enable, and keep legacy recovery paths.
- tmux control mode shows the value and risk of text control protocols over muxed panes: parseable structure exists, but custody and locality still matter.
- Zellij resurrection preserves old work but guards reruns behind an explicit user action.
- Nushell and rich terminal lenses show the appeal of structured views.
- Warp and agentic terminal products move helpers directly into the terminal workflow.
- Codex and MCP security guidance keep showing that sandbox, approval, tool identity, and confused-deputy boundaries are product surfaces, not vibes.

Rev0234's synthesis: command cards become most dangerous when they become portable. The next Schell proof surface should therefore be transfer custody, not more UI flourish.

## 2. Updated observations

### 2.1 Export is a custody break

Copying a command card into an issue tracker, chat, PDF, printout, helper context packet, or teammate share can strip reveal links, local paths, receipt drawers, secret tombstones, and raw-byte provenance. Export must therefore have a receipt of its own.

### 2.2 Replay is a new launch request

An old exact argv is valuable. It is not current launch authority. Replay capsules must keep old basis and current basis separate, especially across repo roots, env epochs, dependency locks, account lanes, network posture, and helper policy epochs.

### 2.3 Rich lenses need confession receipts

Structured table views, copied JSON, folded logs, hyperlinks, progress bars, and summarized terminal-chat packets are product gold. They need transform recipes, skipped/control-byte maps, geometry caveats, and raw reveal status.

### 2.4 Helpers need context manifests, not terminal folklore

A helper receiving a context slice should know whether it got stdout, stderr, exit code, byte intervals, skipped ranges, secrets, redactions, policy epoch, sandbox, and exact effect envelopes. The capsule should block helper action when coverage is insufficient.

### 2.5 Account/provider facts are the shell's FedCM problem

Browser login state, FedCM/account chooser hints, selected workspaces, source helper policy, and connector labels are tempting to carry inside command cards. They should arrive as source-local evidence until a recipient basis reauthorizes them.

## 3. Lessons we must keep learning from the past

1. Screenshots are projections, not receipts.
2. Old commands are drafts until the current basis is compared.
3. Helpful summaries hide coverage unless they carry intervals and skips.
4. Redaction can remove the very target needed to judge authority.
5. Mux and remote control streams are custody systems, not locality oracles.
6. Secret masking proves a secret was hidden, not that secret authority disappeared.
7. Newer Schell must treat older Schell archives as historical evidence until schema compatibility is explicit.

## 4. Brilliant ideas to steal, with fences

- Steal issue-ready terminal cards, but embed receipt digests and reveal-status labels.
- Steal replayable command memory, but force original/current basis comparison.
- Steal terminal-chat attachments, but require context coverage maps.
- Steal rich table/data lenses, but mark them as transforms with raw-byte reveal.
- Steal background notifications, but make return-to-card read-only until fresh intent.
- Steal cross-account/team sharing, but make account/provider/secret authority rebind explicit.
- Steal archive import, but quarantine unknown fields and retired policy terms.

## 5. Recommendation

Keep Schell in proof mode. The next implementation-like artifact should be a tiny capsule import simulator: feed ten transfer drills into the rendered-card model and emit arrival grade, missing receipts, allowed verbs, blocked promotions, and CQ prompts. Do not design the final storage or share format until unsafe imports can fail visibly.
