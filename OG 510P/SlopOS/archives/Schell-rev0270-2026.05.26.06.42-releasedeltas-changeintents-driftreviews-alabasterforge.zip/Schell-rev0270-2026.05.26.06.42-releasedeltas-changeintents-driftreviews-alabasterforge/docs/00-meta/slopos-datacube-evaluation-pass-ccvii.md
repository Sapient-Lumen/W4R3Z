# SlopOS datacube evaluation — 2026-03-25 — pass CCVII

**Schell should add watch leases, quarantine gates, and recheck-truth humility, because SlopOS and the companion datacubes keep proving that issued authority, provider-owned mutable live state, and historical receipts are neighboring truths rather than one flattering “it still works” story.**

## 1) SlopOS already says issued descriptors are smaller than live state

SlopOS's lease-descriptor state boundary is the clearest direct pressure here.
It explicitly pins the rule that a lease/grant descriptor is exact issuance evidence, not a portable oracle for current live state.
That is almost the shell rule Schell needs.
A remembered object card, stored route, or old grant shelf can be exact about history and still be too weak to justify a strong action now.

## 2) Revocation epochs in SlopOS point toward watch duty, not mythology

SlopOS's revocation RFC keeps revocation explicit, bounded, and mechanizable through epochs or revoker objects.
That pressure matters for Schell even though the shell will likely sit on top of many different substrates.
The lesson is not “build one giant revocation engine in the terminal.”
It is smaller:
when current authority depends on mutable provider-owned truth, the shell should either keep an honest watch or fall back to recheck/quarantine.

## 3) OpenURI boundaries already reject the most tempting aftermath myths

SlopOS also keeps OpenURI launch completion, recent-items policy, and durable document authority separate.
That reinforces the same shell lesson from another angle.
A route that once succeeded, a recent item that still exists in history, or a launch that was once admitted are all smaller than current live footing.
The shell should therefore keep `history only`, `recheck now`, and `provider state unknown` as normal named states rather than as embarrassing edge cases.

## 4) ViewFS and Ward suggest the right companion vocabulary

The companion cubes help with vocabulary.
ViewFS repeatedly separates accepted request, provider operation, completion verdict, adopted local result, and receipt.
Ward keeps pushing freshness labels, watch leases, quarantine gates, and later-history humility.
Together they suggest a strong next move for Schell:
use **watch leases** only when the shell truly has a fresh basis for current-state confidence, and otherwise fall to a **quarantine gate** that offers inspect/recheck/import/start-clean ladders instead of bluffing.

## 5) Harbor, Helm, and Steward reinforce that stale truth should not spend like live truth

Harbor's aftermath honesty, Helm's rung discipline, and Steward's cache/session/history caution all reinforce the same point.
A nice local badge should not quietly become an execution-grade claim after time, drift, or provider mutation.
That means the most important shell move is not richer memory.
It is better downgrade posture.

## 6) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- one final watch-status transport,
- one final revocation callback bus,
- one final quarantine palette architecture,
- one final current-state cache,
- or one final cross-provider watcher registry.

It only earns a smaller companion rule:
**keep watched current truth, recheck-now posture, revoked/expired state, provider-state-unknown posture, and history-only residue explicitly separate before Schell gets any more magical about remembered authority.**
