# Datacube evaluation pass CCXXVII: companion-cube pressure on the command-chapter harness

Revision: rev0230
Date: 2026-05-13
Scope: SlopOS rev0695 plus Foundry, Harbor, Steward, ViewFS, Helm, and Ward pressure on Schell's next proof surface.

## 1. SlopOS: imported convenience must stay local

SlopOS rev0695's FedCM import boundary remains the strongest direct teacher. Browser-mediated federation, login-status hints, connected-account lists, chooser UX, disconnect choreography, and returned identity material are useful in their local browser/provider context. They do not become portable current-user, account, session, approval-basis, or durable login truth.

Schell's terminal analog is broad:

- shell marks are not launch truth;
- helper summaries are not command truth;
- restored panes are not live runtime truth;
- synced history is not current intent;
- provider/browser hints are not Schell account truth;
- remote hop metadata is not local basis truth.

The rev0230 harness imports this as `H-0019 browser provider-local login hint` and as a general locality rule: useful observations carry locality labels.

## 2. Foundry: keep the semantic spine thin

Foundry's semantic-spine / serving-lane / pinned-cut posture is a warning against a giant terminal ontology. Schell's command chapter spine should stay small: source, envelope, launch, process-ground, basis, output coverage, marks, actions, downgrades, raw reveal.

Everything else should be a lens, sidecar, action deck, or fixture. The harness enforces this by testing claims rather than adding a huge schema.

## 3. Harbor: time and contract subsets

Harbor's temporal witnesses and contract subsets map cleanly onto terminal work. A command at time T with cwd/env/account/process basis B is not the same command at time T+3 days, even when the text is identical.

The harness imports this through restored-pane, synced-history, reconnect, and basis-drift fixtures. Rerun is a new contract, not a continuation of old intent.

## 4. Steward: cause and condition must not collapse

Steward's cause/condition separation should become a permanent Schell habit. “Schell launched a process,” “a prompt came back,” “output looked quiet,” “a helper summarized success,” and “the provider settled the action” are different facts.

The harness encodes this in missing-finish-marker, background-interleaving, filtered-output, and helper-run fixtures.

## 5. ViewFS: projections are useful but not authority

ViewFS's prefix badges, folder ghosts, and listing-lantern posture warn Schell not to let projections impersonate committed objects. Terminal output projections have the same shape: detected paths, URLs, ports, test names, table lenses, and helper summaries are projections over bytes.

The harness therefore requires source spans, preview posture, exact reveal, and raw transcript escape for action cards and lenses.

## 6. Helm: action decks should be review queues, not magic palettes

Helm's door packs, patrol routes, and review queues are the right vocabulary for Schell actions. A terminal action card is a door pack with source, effect, risk, and entry condition. A helper proposal belongs in a review queue before it becomes live input.

The harness imports this through helper-adoption, kill-port escalation, tool-context, and auto-permission fixtures.

## 7. Ward: tier witnesses and hybrid seams

Ward's trust-layer posture says claims need custody, witnesses, appraisal lanes, and spend gates. Schell's hybrid seam is especially messy: terminal, shell, PTY, OS, helper, browser, mux, remote host, and transcript all meet in one visible pane.

The harness imports Ward as the claim ladder. It does not ask whether a mark is “real” in the abstract. It asks what tier it occupies and what spend gate it is allowed to open.

## 8. Evaluation of rev0229

Rev0229 was the right specimen: command chapters, action decks, semantic trust grades, helper power ladders, rerun gates, downgrade witnesses, and promotion gates. Its remaining weakness was that the falsification harness lived as a checklist inside a prose specimen.

Rev0230 fixes that by creating a dedicated harness document, a machine-checkable fixture pack, and a lint script that keeps fixture hygiene from drifting.

## 9. Recommended next move

Build a tiny visual or local prototype with three modes:

1. native direct-launch chapter;
2. shell-integration-but-fake-marker hostile chapter;
3. restored/remote/helper-downgraded chapter.

Then run the five-question operator comprehension scorecard before adding more features.

## 10. Decision restraint

This pass intentionally does not decide:

- the final terminal protocol;
- the final shell language;
- the final action-card UI;
- the final helper runtime;
- the final typed data treaty;
- the final account/session model.

The new discipline is narrower: no semantic terminal feature graduates until it can survive the harness without laundering weak claims into strong truth.
