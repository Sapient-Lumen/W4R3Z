# Research synthesis — 2026-03-28 pass CCXIX

This pass compresses a newer cross-tool pattern:
**modern helper systems are getting more powerful, but the trustworthy moves are still the gradient ones: explicit approvals, scoped tools, transport-aware auth, progressive enhancement, and deliberate signaling.**

## 1) Agent tools are explicitly modeling autonomy levels now

VS Code's agent tools docs now expose a permissions picker with three distinct autonomy levels for a session: Default Approvals, Bypass Approvals, and Autopilot.
The docs also warn that Bypass Approvals and Autopilot auto-approve potentially destructive actions such as file edits, terminal commands, and external tool calls.
This matters because it shows the field has already given up on pretending all agent power is the same.

The lesson for Schell is not to copy those exact labels.
It is to keep helper power visibly **graduated** rather than treating autonomy as an invisible background fact.

## 2) Tool scope is becoming part of the artifact, not just the session

VS Code's custom-agent frontmatter lets authors specify a `tools` list and an `agents` list, so a custom agent can name which tools it may use and which subagents it may call.
VS Code's subagent docs go further: custom agents can be user-invocable or subagent-only, and model invocation by other agents can be disabled.
Claude Code's subagent docs reinforce the same trend: subagents can be restricted with `tools` allowlists or `disallowedTools` deny lists, and those controls apply even when the main session has broader power.

This is one of the strongest near-term steals for Schell:
**desired power should live on the helper artifact or room, not only in a giant session-wide toggle.**

## 3) Safety posture is getting more explicit about strong actions

Claude Code's security docs describe a permission system for sensitive operations, a default blocklist for risky commands such as `curl` and `wget`, and configurable permissions for MCP servers that are checked into source control.
That is useful because it frames "strong tool access" as a separate admission problem rather than a generic side effect of being in a smart session.

For Schell, the steal is not a particular blocklist.
It is the principle that stronger power should be named, reviewed, and revocable.

## 4) Transport and authorization differences are now first-class protocol facts

The MCP authorization spec says authorization is optional, that HTTP-based transports should follow the authorization spec when supported, and that STDIO transports should not follow that spec and should instead retrieve credentials from the environment.
That is a powerful design lesson.
It means one protocol can still admit **different auth stories on different transports** without pretending they are identical.

Schell should borrow that humility.
A helper/runtime/terminal feature should be allowed to say:
- native and fully authorized,
- authorized but proxied,
- available without richer auth,
- or unavailable on this transport.

## 5) Terminal luxury keeps rewarding progressive enhancement

kitty's keyboard protocol remains a sharp example of progressive enhancement: features such as key repeat/release reporting, alternate keys, and reporting all keys as escape codes are separate enhancement bits rather than one all-or-nothing leap.
That is a better pattern than claiming one brand/version badge proves everything.

WezTerm's user-vars recipe is equally instructive.
It says user vars let the pane deliberately signal information to the terminal config, and that this can work across multiplexer connections and even through tmux when passthrough is enabled.
That is not ambient discovery; it is deliberate signaling plus an explicit relay story.

Together those sources point toward a Schell design where richer capability is additive, deliberate, and visibly downgradeable.

## 6) Semantic prompt luxury is strongest when the shell keeps telling the truth

Ghostty 1.3.0 adds click-to-move-cursor inside active OSC 133 prompts, a debug overlay that shows OSC 133 areas in the terminal inspector, and command-finished notifications with thresholds.
But Ghostty also says those notifications use OSC 133 to track command execution and therefore require shell integration or a shell that emits OSC 133 natively.
That is exactly the kind of honesty Schell should preserve.
Luxury should appear when footing is real, not when the terminal merely hopes it is.

## 7) Compact conclusion

The best current ideas are not "trust the assistant more."
They are:
- make power levels explicit,
- bind tool scope to helper artifacts and rooms,
- keep strong actions reviewable and revocable,
- let transports/auth stories differ without pretending they are the same,
- and treat rich terminal behavior as progressive enhancement riding on deliberate shell signals.

So the next Schell proof should probably not be a final policy engine.
It should be a **power-ladder plus downgrade-adapter plus revocation-lease specimen bundle**.
