# Research synthesis — 2026-03-28 pass CCXXIII

This pass sharpens a smaller current pattern:
**the most promising shell+terminal luxuries are converging on exact command-shaped packets, bounded output slices, and clipped replay or restore surfaces — not on one giant magical history blob.**

## 1) VS Code keeps pushing command-shaped evidence instead of ambient transcript vibes

VS Code's October 2025 release added the ability to attach a terminal command to chat as context.
The attachment carries the command line, captured output, and exit code, and the same release added inline actions to reveal the correct terminal or show the final output in chat.
That is a strong clue for Schell: when comparison or helper handoff matters, the right unit is an exact command-shaped packet rather than a vague scrollback excerpt.

VS Code's February 2026 release adds another useful refinement.
Terminal tool calls in agent mode can render as collapsible sections with summary headers instead of dumping all output inline.
That matters because compare surfaces need compact summaries, but the summary should still unfold back to the exact source command rather than replacing it.

## 2) WezTerm keeps showing that exact compare starts with exact zones

WezTerm's shell integration defines semantic zones and exposes them directly.
`pane:get_semantic_zones()` can return Prompt/Input/Output zones, and mouse selection can expand to the surrounding semantic zone so an entire output region can be selected exactly.
That is excellent pressure on Schell.
If the shell can name exact zones, compare packets can be bound to exact slices instead of regex luck.

## 3) Warp is proving both the appeal and the honesty burden of command-shaped blocks

Warp's block model groups a command and its output into one atomic unit, and block actions let users copy the command, the output, or both.
Block filtering keeps the original output intact while letting operators focus on a subset, which is a great reminder that filtered views should remain weaker than the underlying source.

Warp's background-block docs are equally instructive from the caution side.
Background output can be grouped into blocks even when there is no associated command, and the docs explicitly warn that background output may be mixed together or interleaved with foreground output.
That is exactly the kind of provenance caveat Schell should carry into compare and replay surfaces instead of flattering every clip into one neat causal story.

## 4) iTerm2 and Zellij keep splitting replay from rerun

iTerm2's Instant Replay lets users step back through past window state, and its import/export flow can save that state to an `.itr` recording or clip the recording between selected start and end points.
That is a strong argument for clipped replay as a first-class neighboring act rather than a strange side effect of scrollback.

Zellij sharpens the rerun lesson.
Session resurrection normally brings commands back behind a “Press ENTER to run” banner, and command panes stay in a held state after exit so the user can explicitly rerun with Enter.
That is exactly the right anti-folklore hint for Schell: restored or historical command context should usually come back as pending review, not silently become fresh execution.

## 5) The synthesis is not “invent a history database”

The more grounded synthesis is smaller:
- exact command packets for attachment and handoff,
- exact semantic zones for bounded selection,
- filtered or clipped projections that confess they are projections,
- clipped replay that stays distinct from transcript copy,
- and rerun gates that stay explicit even when restore or compare feels delightful.

That gives Schell a real specimen bundle to prove without freezing one final history warehouse, replay engine, or notebook product.

## 6) Compact conclusion

The current ecosystem keeps converging on the same lesson:
**exact compare begins with exact source packets, replay should be clip-shaped and honest, and rerun should remain a reviewed act.**

So the next Schell proof should probably be a **comparison-and-replay specimen bundle**:
- one named baseline warrant,
- one exact compare packet,
- one bounded output compare,
- one clipped replay card,
- and one explicit rerun gate.
