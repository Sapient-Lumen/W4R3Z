# Research synthesis pass CCXXX: readable cards, replay capsules, and export fences

Revision: rev0234  
Date: 2026-05-13  
Scope: terminal/shell/agent precedents viewed through the question “what breaks when command cards become rendered, replayable, shareable, and helper-consumable?”

## 1. Field signal

The field continues to make command-line work more object-like. VS Code shell integration exposes command detection, cwd detection, decorations, navigation, sticky scroll, quick fixes, recent command recall, and terminal-chat context. WezTerm and Contour document OSC 7/133/1337-style shell integration for cwd and prompt/input/output zones. Ghostty now documents shell integration and OSC 133-based command-aware features. Warp packages commands and outputs as blocks that can be copied, re-input, shared, and bookmarked. Atuin records command history with extra context and encrypted sync. Nushell keeps structured data in the pipeline. Zellij resurrects sessions but puts restored commands behind an explicit press-enter gate. Agent terminals and MCP-style tools increase pressure for helpers to run work with fewer prompts.

Rev0233's synthesis: the next hard problem is not only creating command objects. It is preventing those objects from becoming false evidence when rendered, replayed, shared, redacted, summarized, or consumed by a helper.

## 2. Updated observations

### 2.1 Shell integration is good but not sovereign

Prompt zones, cwd signals, command guides, and sticky headers are great serving lanes. They should make Schell pleasant. But they stay authored signals, not launch truth, because they can be emitted by applications, translated by muxes, stripped over hops, or restored from memory.

### 2.2 Blocks and rich history want export contracts

Warp blocks and Atuin-style contextual history point toward command chapters that are reusable and portable. That is exactly why Schell needs export capsules: every share/copy/print/helper attach should state whether raw bytes, receipt digests, redaction manifests, and audience/locality survived.

### 2.3 Session resurrection needs replay humility

Zellij's press-enter resurrection guard is a useful pattern: old command context can be preserved without silently rerunning it. Schell should generalize that into replay capsules that compare original basis to current basis before spending launch authority.

### 2.4 Terminal protocols are effect surfaces

OSC 8 hyperlinks, OSC 52 clipboard sequences, keyboard negotiation, tmux control mode, shell zones, and proprietary escape conventions all demonstrate that the terminal is a programmable effect surface. Rendering support is not the same as evidence custody, and rich projections are not raw bytes.

### 2.5 Agent permissions are becoming less interruptive

Codex-style sandbox/approval separation, Claude Code permission modes and auto mode, Warp rules, and MCP tool catalogs all point toward agentic terminal workflows with reduced manual prompting. Schell should not fight all automation; it should require per-effect floors, policy epochs, sandbox receipts, exact envelopes, and tool identity checks.

## 3. Lessons we must keep learning from the past

1. A terminal is not a database; if the rendered lens is useful, the raw byte interval still matters.
2. A shell is not a textbox; exact argv and expansion receipts are stronger than pretty command text.
3. A mux is not a locality oracle; visible pane state, control API state, and remote shell state can diverge.
4. A restored session is not a live session; replay is a new request.
5. A helper is an actor; its summaries and tool metadata are not authority.
6. A copied card is not automatically evidence; export changes custody.

## 4. Brilliant ideas to steal, with fences

- Steal command blocks, but attach evidence dockets.
- Steal sticky command headers, but show the strongest downgrade in the header.
- Steal rich history, but mark stale basis and replay envelopes.
- Steal structured lenses, but preserve raw bytes and transform recipes.
- Steal helper batches, but split by authority floor.
- Steal shareable snippets, but carry redaction manifests and receipt digests.
- Steal terminal-chat context, but require output coverage maps.

## 5. Recommendation

Use rev0234's rendered paper prototype as the next operator test input. Do not add more features until the four cards answer CQ-01 through CQ-05 without a legend. The near-term product superpower should be trustable compression: a command card that is beautiful because it knows exactly which facts are weak.
