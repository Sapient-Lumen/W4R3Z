# Research synthesis 2026-05-18 pass CCXLV — retention budgets and forgetting ledgers

Rev0248 adds a retention/forgetting pass to Schell. The outside lesson is that cleanup systems are full of useful mechanisms, but those mechanisms become dangerous when a shell treats them as global erasure or harmless memory.

## Outside pressure

- GDPR Article 5 gives the right shape for Schell vocabulary: purpose limitation, data minimisation, storage limitation, integrity/confidentiality, and accountability. Schell should not copy legal compliance machinery, but it should steal the product idea that retained command evidence needs a purpose and a duration.
- OpenTelemetry's sensitive-data guidance puts responsibility on implementers because telemetry systems cannot know context-specific sensitivity by themselves. The redaction processor also shows why allow/block lists, summaries, and pipeline placement matter: redaction after export is not prevention.
- GitHub Actions artifacts/logs have explicit retention periods; custom retention can be set per artifact, but organization/repository settings and object creation time matter. Schell should show object-local retention rather than narrating policy as retroactive cleanup.
- Kubernetes TTL-after-finished shows why finished-job evidence can be retained for debugging and later cleaned, but TTL expiry, finalizers, cascading deletion, and update races remain separate witness rows.
- systemd-journald and shell history show that logs/history are not one file or one state; vacuum, rewrite, compaction, active files, indexes, and autocomplete projections need separate lanes.
- asciinema's terminal-output recording model is a gift for portable evidence and a trap for secrets: keys may not be recorded, but echoed output can still be captured.

## Schell rule

A retained or forgotten command object becomes useful only when it carries:

1. purpose and basis;
2. data class and sensitivity;
3. raw/redacted/summary/index/backup/share/helper/telemetry copy inventory;
4. retention budget, expiry, and hold state;
5. minimization transform and proof-loss row;
6. forgetting/sweep authority;
7. post-sweep witness;
8. safe next verb and blocked effect floor.

## Decision-light posture

No privacy compliance engine, redaction DSL, backup sweeper, telemetry processor, helper memory runtime, terminal recording redactor, artifact adapter, search-index runtime, shell grammar, terminal protocol, or UI toolkit is chosen. The proof remains static: can operators read compact `retain/minimize/next` lines without treating memory as authority or redaction as erasure?
