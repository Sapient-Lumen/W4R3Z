# Research synthesis — pass CCLXVII — archive envelope and safe extraction

Imported pressure, bounded:

- Python `zipfile` documentation warns that callers using path-like ZIP access must validate or sanitize filenames to prevent path traversal.
- CWE-22/CWE-23 keep pathname traversal and Zip Slip in scope, including archive filenames that write outside an intended extraction directory.
- TUF treats target metadata, hashes, lengths, version/expiry, and mix-and-match/rollback/freeze resistance as update-system concerns; Schell only imports the humility that package metadata must be explicit and scoped.
- SLSA says provenance only helps when consumers inspect it against expectations; Schell imports this as a release-envelope expectation check, not as SLSA adoption.
- SlopOS rev0720 continues to block branchless portal ingestion or append: a Schell package cannot be read as current context merely because the zip extracted successfully.

Bounded take: add `ARCHIVE-ENVELOPE-MANIFEST.json`, `safe-extraction-gauntlet-v0.json`, two lint gates, and a verifier helper. Keep all claims static and non-authorizing.
