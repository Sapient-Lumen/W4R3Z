# Research synthesis — 2026-05-21 pass ccxlviii

Rev0251 imports a narrower lesson than rev0250: Schell needs **probe language**, not just receiver language.

Current official pressure keeps the same shape:

- NIST SP 800-88 Rev. 2 treats sanitization as making access to target data infeasible for a given level of effort. That is stronger than local deletion, redaction, summary, or a missing UI row.
- OpenTelemetry's sensitive-data guidance keeps responsibility with implementers and emphasizes that telemetry collection can capture sensitive or personal information; pipeline order and exporter/backend boundaries matter.
- GitHub Actions exposes retention periods and artifact expiration/deletion state at the artifact/log object level; a setting or future `expires_at` value should not become a retroactive cleanup claim.
- Kubernetes TTL-after-finished makes Jobs eligible for cascading removal from the cluster after completion/failure plus TTL; that does not prove external logs, telemetry, images, or backups forgot.
- OWASP's LLM08 vector/embedding risk validates Schell's decision to treat retrieval influence as retained memory even when raw text is no longer visible.
- MCP security guidance around per-client consent and confused-deputy risk supports separating helper context possession from current tool-call authority.

Bounded take: add a forgetting probe ladder and reconciliation run. A Schell card may say "local row absent" or "named receiver query missed" only when the specific probe is visible. It must continue blocking sanitized, anonymized, compliant, erased, globally forgotten, and no-trace claims.

Explicit non-take: do not implement provider-specific delete APIs, vector rebuild runtimes, backup destroy systems, browser cleaners, clipboard integrations, telemetry processors, legal workflows, or final sanitization certificate formats from this pass.
