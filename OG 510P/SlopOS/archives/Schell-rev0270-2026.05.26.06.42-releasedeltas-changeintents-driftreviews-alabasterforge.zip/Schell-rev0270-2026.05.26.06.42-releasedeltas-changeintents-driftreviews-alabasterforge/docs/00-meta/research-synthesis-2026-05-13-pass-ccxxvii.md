# Research synthesis pass CCXXVII: adversarial semantic terminals and downgrade proof

Revision: rev0230
Date: 2026-05-13
Scope: current terminal/shell/agent precedents viewed through the question “what should Schell try to break before it trusts command chapters?”

## 1. Field signal

The current field keeps pushing terminal work toward semantic units: command blocks, command-output capture, exit-code/cwd integration, prompt/input/output zones, sticky or collapsible command sections, background-agent notifications, terminal-chat context packets, resurrected pane layouts, structured history, structured data pipelines, richer terminal protocols, and agent permission ladders.

The field also keeps exposing the hazard: many of these signals are emitted by shells, foreground apps, terminal escape streams, helper summaries, editor agents, browser sessions, or restored snapshots. They are excellent affordances, not automatic authority.

Rev0230 therefore shifts from “collect brilliant ideas” to “build the falsification oven.” The best next artifact is not a bigger architecture diagram. It is a fixture pack that proves lower-grade claims stay visibly lower-grade while the UX remains delightful.

## 2. Updated observations worth stealing

### 2.1 Editor-agent terminals are becoming chapterized

Recent editor-agent terminal flows expose richer command details, collapse terminal tool invocations into scannable sections, attach command line/output/exit code to chat, reveal hidden chat terminals, and surface long-running background terminal commands through notifications. Schell should steal the operator win: terminal work becomes navigable, attachable, resumable, and reviewable.

The harness lesson: a hidden or collapsed terminal must not hide authorship, output coverage, command basis, or helper policy. Collapse is a projection, not evidence deletion.

### 2.2 OSC 133 and shell integration are becoming common semantic glue

WezTerm, fish, Contour’s OSC 133 documentation, Ghostty discussions, and terminal-agent issue traffic all point to the same center: prompt/input/output regions are useful enough to become de facto shared language.

The harness lesson: the same byte stream can be printed by an app. Schell should use semantic zones for navigation and selection, but the harness must include fake-marker fixtures before zones become trusted chapter boundaries.

### 2.3 Blocks are a proven cognitive unit

Warp-style blocks make command/output grouping actionable: copy command, copy output, copy both, scroll to output, re-input, share, and bookmark. Schell should steal the block as a cognitive unit, then go further by attaching receipt grades and downgrade witnesses.

The harness lesson: a block/chapter is a UI unit; receipts are proof units.

### 2.4 Resurrection is a gift and a trap

Zellij’s resurrection story is particularly instructive because it explicitly re-runs command panes only behind a “Press Enter to run” posture. That small gate says the important thing: restored commands are memory until reviewed as fresh execution.

The harness lesson: revived pane, old scrollback, saved command, and live process are different claims. A rerun gate must compare prior and current basis.

### 2.5 Contextual history should recall to draft

Atuin-style contextual history and sync make shell memory far more powerful by recording context such as cwd, duration, host, user, time, and exit status. Schell should steal contextual recall, not contextual authority.

The harness lesson: history from another host, cwd, account, or env epoch enters a draft lane with basis compare, not a live run lane.

### 2.6 Structured data is a lens, not a treaty

Nushell demonstrates how pleasant structured tables, records, and nested values can be. Schell should adopt lenses for JSON, tables, compiler output, test logs, and file lists. But rev0230 keeps the typed pipeline treaty deferred.

The harness lesson: a lens must reveal raw bytes and projection coverage. It cannot become the only retained truth.

### 2.7 Protocol negotiation should improve luxury without becoming a dependency

Kitty-style terminal protocol extensions show a healthy pattern: query support, enable progressive enhancements, degrade when absent. Schell should use negotiation everywhere it helps input fidelity and rendering.

The harness lesson: failure to negotiate a rich protocol disables luxury, not the truth floor. Plain PTY/transcript mode remains first-class.

### 2.8 Agent permissions need receipts and comprehension checks

Codex-style sandbox plus approval policy separation, Claude Code auto-mode/approval-fatigue pressure, and MCP’s security posture all point to the same rule: agent power must be visible as product-enforced policy, not merely described in natural language.

The harness lesson: helper-run chapters need helper identity, policy, sandbox, approval mode, and resource-packet receipts. “The assistant did it” is not enough.

## 3. Deep lessons from the past

### 3.1 The terminal stream is not a trusted channel

A program can print prompt-looking text, OSC markers, hyperlinks, file paths, fake status lines, and apparent instructions. The historical VT stream is powerful because it is just bytes; it is dangerous for the same reason.

Schell should assume every app-emitted mark is a suggestion unless cross-checked by host or shell footing.

### 3.2 The shell is not a transparent argv machine

Delegating a line to a shell invokes quoting, expansion, redirection, substitution, aliases, functions, options, hooks, and interpreter-specific semantics. Schell may show exact accepted input, but it should not pretend to know final argv unless it truly launched or observed it.

### 3.3 Prompt return is not enough

Jobs can background, stop, disown, trap signals, fork daemons, keep fds open, run under remote muxes, or complete outside the visible prompt. Prompt-ready UX must remain weaker than process-ground proof.

### 3.4 History is fossilized context

History is valuable because it remembers. It is dangerous when it impersonates current intent. The harness must include synced-history and restored-pane tests because those are where convenience most wants to erase time.

### 3.5 Smart actions create authority pressure

Opening a file is low risk; killing a process, installing a package, running a network command, or giving a helper broader scope is not. Action cards need source spans, effect previews, and authority diffs.

## 4. The harness pattern

The rev0230 harness creates three layers:

1. **Claim ladder** — every fact has a grade and source.
2. **Fixture pack** — hostile/degraded situations with expected and forbidden UI behavior.
3. **Operator comprehension scorecard** — the user must be able to answer what happened, who claimed it, what is stale/weak, what authority would be spent, and where the raw evidence is.

This is stronger than a UI mock alone. A mock can look honest while silently overclaiming. A harness forces the overclaim to be named.

## 5. What Schell should now steal with confidence

Schell can keep collecting luxury moves, as long as each is routed through the harness:

- block/chapter navigation;
- sticky headers and minimaps;
- command-output attach packets;
- background command notifications;
- shell-signed semantic zones;
- contextual history search;
- rerun/compare gates;
- structured data lenses;
- helper observe/propose/edit/run ladders;
- plumb-like routing;
- terminal feature negotiation.

The trick is to let these features be fast and beautiful without letting them become hidden truth.

## 6. Recommendation

Promote FT-0231 from prose into a fixture pack and open FT-0232 for operator-comprehension proof. Do not freeze the final UI or protocol until the prototype can pass fake-marker, no-integration, shell-delegated, remote-hop, restored-pane, helper-adoption, filtered-output, and provider-local account tests.
