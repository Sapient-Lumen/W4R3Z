# Research synthesis — 2026-05-25 pass cclxi — remediation obligations and appeal tolling

Rev0261 imports a narrow lesson: after Schell assembles a forgetting assurance case and identifies open defeaters, the archive still needs to say **what happens next**. A suspended, contradicted, privacy-withheld, or burden-shifted claim must not sit forever as ambiguous amber state; it must produce an owned remediation obligation, subject/recipient notice route, appeal/tolling clock, closure receipt, residual-risk statement, and no-use-until-closure fence.

External pressure, bounded take:

- NIST SP 800-61 Revision 3 connects incident response to CSF 2.0 Detect/Respond/Recover and continuous improvement. Schell imports the idea that failed proof should produce tracked response/recovery obligations, not a static warning badge.
- NIST Privacy Framework pressure keeps privacy risk communication and accountability in scope. Schell imports communication/role clarity, not a privacy program.
- GDPR Articles 17, 18, and 19 create pressure around erasure, restriction, and recipient notification. Schell imports notice/recipient/exception discipline, not a legal compliance workflow.
- FedRAMP POA&M guidance uses structured remediation plans and milestones for open risks. Schell imports owner/milestone/closure rows, not FedRAMP authorization machinery.
- Prior FAC/DBL work keeps burden with the proof claimant and treats open defeaters as claim-narrowing. Rev0261 adds what the claimant must now do.
- SlopOS rev0720 keeps transcript memory branch-bound; appeal or remediation closure must recheck accepted-prefix/base-digest lineage before any append/reliance.

Local changes:

- Added `remediation-obligation-ledger-v0.json` and rationale.
- Added `appeal-tolling-board-v0.json` and rationale.
- Added H-0441..H-0452 and RF-0047/RF-0048.
- Extended forgetting proof dockets with remediation-obligation, notice, appeal/tolling, closure, and no-use rows.
- Added lint gates for ROL/ATB proof surfaces.

Non-take: do not implement a legal/compliance engine, DSAR system, POA&M product, incident-response platform, provider deletion adapter, notification service, appeal UI, policy engine, helper runtime, terminal protocol, shell grammar, or SlopOS portal adapter.
