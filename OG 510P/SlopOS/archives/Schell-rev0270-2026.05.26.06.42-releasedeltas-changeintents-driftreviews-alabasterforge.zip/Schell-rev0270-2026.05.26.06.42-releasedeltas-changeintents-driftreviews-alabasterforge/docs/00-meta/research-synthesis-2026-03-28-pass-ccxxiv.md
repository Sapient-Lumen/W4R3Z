# Research synthesis — 2026-03-28 pass CCXXIV

This pass sharpens a smaller current pattern:
**modern shell and terminal tooling is quietly converging on structured environment derivation and activation metadata, but most UX still flattens the result into one ambient env story.**

That mismatch creates a real design opportunity for Schell.
The no-regret move is not to standardize one universal environment object model.
It is to make **basis, activation, recreate path, and drift** visible enough that operators can tell whether they are standing on inherited process state, a structured artifact, or a merely historical restored basis.

## 1) VS Code keeps proving that restored terminals and injected env are basis-bearing, not background details

VS Code's terminal advanced docs say persistent sessions come in two forms: process reconnection and process revive.
The important line is that process revive restores terminal content and **relaunches the process using its original environment**.
That is an excellent reminder that a revived terminal is not automatically “today's environment.”
It may be a content resurrection plus an older basis.

VS Code's terminal profile docs push on the same seam from the setup side.
Profiles are executable-plus-args shell configurations, and the docs show custom init scripts being passed in as profile arguments.
That means the basis for a shell can be profile-defined before the shell does anything on its own.

The Python docs add a second useful example: `.env` variables are injected when terminals are created.
That is another strong clue that terminal/editor surfaces can materially shape runtime footing and should not be treated as invisible furniture.

## 2) direnv keeps proving that project activation is a diff with an authorization story

The direnv docs remain one of the cleanest current examples of environment honesty.
Before each prompt, direnv checks for `.envrc` (and optionally `.env`) in the current or parent directories; if authorized, it loads the file in a bash sub-shell, captures the exported variables, and makes the resulting diff available to the current shell.
The quick demo even prints an explicit export diff like `direnv export: +FOO`.

That is exactly the sort of idea Schell should steal.
Project-local activation should look like an admitted diff with source identity and authorization posture, not like invisible ambient weather.

## 3) Nix and Pixi keep showing that recreate path can be first-class

Nix's `print-dev-env` docs are especially valuable here.
The command prints shell code that can be sourced to reproduce a build environment in the current shell, and with `--json` it emits a JSON serialization of the variables and functions defined by the build process.
That is much more informative than a prompt prefix.
It is a recreate path with machine-readable structure.

Pixi provides a very similar lesson from a different ecosystem.
Its docs distinguish three activation modes: `pixi shell`, `pixi shell-hook`, and `pixi run`.
The shell-hook output shows concrete exported variables such as `CONDA_PREFIX`, `PIXI_PROJECT_ROOT`, and `PIXI_PROJECT_MANIFEST`, and Pixi also records small environment metadata including `manifest_path`, `environment_name`, `pixi_version`, and an `environment_lock_file_hash` in the environment's `conda-meta` area.
That is the clearest current argument for basis cards with recreate paths and artifact hashes.

## 4) Nushell and devcontainers reinforce that layers and definitions deserve names

Nushell overlays keep showing that environment-affecting layers can be activated and deactivated on demand.
The docs describe overlays as layers of commands, aliases, and environment variables, and even support hiding an overlay while keeping selected environment variables.
That pushes Schell toward explicit layer identity rather than a flat env snapshot.

The Development Container Specification adds the structured-definition lesson.
Its purpose is to let tools define development containers that are easy to use, create, and recreate, and it describes `devcontainer.json` metadata as the structured unit that deterministically creates the development environment.
That is another strong example of basis-before-runtime: sometimes the right explanation for an environment is not “what variables exist,” but “what definition produced this place?”

## 5) The synthesis is not “capture all env forever”

The grounded synthesis is smaller:
- show whether the current footing is inherited, activated, restored, or recreated,
- mint explicit activation receipts for basis-changing steps,
- carry recreate paths when the environment came from a structured artifact or activation source,
- keep epoch or drift posture visible when those sources advance,
- and avoid pretending that restored content or prompt decoration proves current reproducibility.

That gives Schell a sharp new specimen bundle without forcing one final environment ontology, secrets system, or manifest treaty.

## 6) Compact conclusion

The current ecosystem keeps teaching the same lesson:
**great environment UX comes from visible basis and recreate path, not from a prettier ambient snapshot.**

So the next Schell proof should probably be a **basis-and-activation specimen bundle**:
- one basis card,
- one activation receipt,
- one recreate-path reveal,
- one env-epoch drift compare,
- and one reviewed recreate action instead of silent rerun.
