# Research synthesis — 2026-05-26 pass CCLXIX

This pass imports bounded pressure from reproducible-build and archive tooling into Schell's static release-custody surfaces.

- Reproducible Builds identifies environment variations such as build path, timestamp, file encoding, filesystem ordering, permissions/umask, locale, dependencies, randomness, and user information as sources of unreproducible artifacts. Schell imports those as environment rows, not as a full reproducible-build system.
- SOURCE_DATE_EPOCH gives a standard way to anchor build timestamps to a numeric UTC epoch; Schell records a fixed epoch and ZIP datetime for release entries.
- Python zipfile exposes ZipInfo date_time, compression method, external attributes, strict timestamp behavior, and metadata encoding surfaces; Schell uses only stored entries with fixed timestamps and empty comments/extra fields for the deterministic packer.
- SLSA and in-toto keep provenance and expected-material/product verification distinct from truth or deletion proof; Schell keeps deterministic package custody non-authorizing.
- SlopOS rev0720 keeps accepted-prefix/base-digest authority separate from incidental package or verifier status.

Imported as archive pressure only: no SLSA provenance, no in-toto layout, no CI, no independent rebuilder quorum, no signature/transparency service, no RATS host attestation, no policy allow, and no SlopOS append authority.
