# Research synthesis pass CCLIV — delegated reliance and policy handoffs

Revision: rev0257

This pass imports delegation and policy-enforcement pressure into Schell without implementing any of the source systems.

## Imported pressure

* OAuth RFC 8693: token exchange creates a structured place for subject, actor, audience, and token-type changes. Schell imports the actor/subject split and audience narrowing, not an STS.
* GNAP RFC 9635: delegation can convey artifacts to software. Schell imports artifact-scope and interaction binding, not a GNAP client.
* OPA: policy decision-making is separated from enforcement; bundles and decision logs make freshness and audit residue concrete. Schell imports policy-input fences and decision-log minimization.
* Cedar / Verified Permissions: authorization is structured around principal, action, resource, and context, with determining policies. Schell imports context-as-evidence discipline and blocks status-as-permit.
* SPIFFE/WIMSE: workload identity is scoped to trust domains and issuer/bundle material. Schell imports trust-domain and issuer-binding gates for delegated proof reliance.
* SD-JWT / SD-JWT VC: selective disclosure and key binding help privacy but can hide rows a verifier needs. Schell imports minimum reliance-stub requirements without demanding raw proof reveal.
* OAuth BCP / RFC 9700: sender-constrained tokens lose protection if token and key material are exposed together. Schell imports key-custody checks for reliance tickets.
* SlopOS rev0720: accepted-prefix checkpoint lineage remains stricter than proof-status display. Schell blocks delegated proof cards from becoming append or resume authority.

## Bounded take

Add delegated-reliance-boundary-board-v0 and automation-policy-handoff-gauntlet-v0. Require reliance tickets, consumer/audience/scope rows, no-redelegation, policy freshness, audit minimization, and fail-closed automation decisions before any effect verb.

## Non-take

No OAuth STS, GNAP client, OPA bundle runner, Cedar policy engine, SPIFFE federation adapter, WIMSE parser, SD-JWT verifier, MCP runtime, CI bot, Kubernetes admission controller, SlopOS portal adapter, terminal protocol, UI, or shell grammar.
