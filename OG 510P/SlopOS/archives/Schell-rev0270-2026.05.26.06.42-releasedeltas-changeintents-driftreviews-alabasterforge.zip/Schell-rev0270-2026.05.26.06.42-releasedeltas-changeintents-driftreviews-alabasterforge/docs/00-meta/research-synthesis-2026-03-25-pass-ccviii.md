# Research synthesis — 2026-03-25 — pass CCVIII

This pass sharpens the next compact lesson from current official docs on conditional requests, watches, bookmarks, file handles, and permission APIs:
**the smartest next move for Schell is not a bigger state center. It is a smaller precondition story: let stronger actions carry exact stale fences and successor offers, because current systems already do.**

## 1) HTTP keeps exact conditional spend separate from ordinary retries

Current HTTP conditional-request guidance is blunt in a very useful way.
Strong validation is stricter than ordinary freshness and exists precisely to avoid data loss or mid-air collisions.
`ETag` gives a version identity for a resource, and `If-Match` says a stronger write or fetch should only proceed if the resource still matches that exact identity; otherwise the server replies with `412 Precondition Failed`.
That is almost a direct shell lesson already.
A stronger action should not merely say `retry`.
It should be able to say what exact basis it was reviewed against and fail honestly when that basis no longer holds.

## 2) Kubernetes proves that synced-through and exact-start are different truths, and that stale anchors are normal

Kubernetes keeps teaching two closely related lessons.
First, bookmark events are useful but not guaranteed at any fixed interval, so a client cannot pretend a bookmark is a permanent oracle.
Second, `resourceVersion` handling is explicit about action floor: `NotOlderThan` is weaker than `Exact`, and an unavailable exact resource version can yield `410 Gone`, after which the client is expected to retry with a newer basis or fall back to a fresh read.
That gives Schell a strong pattern worth stealing:
**carry exact or weaker stale fences explicitly, and when the basis dies, offer refresh/compare/restart rather than silently laundering the action.**

## 3) File handles and persistent access still require named re-check or re-request paths

Chrome's File System Access docs remain a great model because they are powerful without pretending stored handles are a forever truth.
Handles can be stored and reopened, but the platform still distinguishes request-time user gesture, later `requestPermission()` calls, session-only versus durable later access, per-item revocation, and background-driven automatic revocation in the persistent-permissions flow.
That is exactly the kind of humility Schell needs.
Stored object cards and recent chapter actions are superb staging material, but stronger reuse should still carry the exact precondition witness that must be re-earned.

## 4) Apple bookmark APIs make staleness first-class instead of embarrassing

Apple's bookmark APIs expose a `bookmarkDataIsStale` outcome and explicitly tell the app to create a new bookmark from the returned URL when the bookmark data is stale.
Apple also keeps actual use separate from resolution: when a security-scoped URL is obtained, the app must call `startAccessingSecurityScopedResource()` before using it.
That is another strong shell lesson.
A resolved historical object, a live usable object, and a refreshed successor object are neighboring truths rather than one flattering `still works` badge.

## 5) General permission APIs keep query/request/revoke and change notification explicit

The W3C Permissions model, Deno permissions API, and Android runtime-permission docs all reinforce the same shape from different directions: current status can be queried, requests and revocations are separate acts, changes can occur after grant, and temporary/while-in-use authority can disappear as a normal lifecycle event.
For Schell, that means a stronger act should be able to say both **what current footing it still depends on** and **what weaker next move remains when that footing is gone**.

## 6) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- add **precondition witnesses** to stronger chapter-local action objects,
- add **stale fences** that veto quietly when exact basis drifted,
- add **successor offers** that say compare / refresh / rebind / adopt-newer / re-request rather than one vague retry,
- keep **exact**, **not-older-than**, and **historical-only** visibly separate,
- and keep all of those weaker than fresh reviewed shell truth.

That is enough to make the shell feel unusually sharp while still deferring the final compare-clause syntax, successor registry, refresh protocol, and global stale-fence substrate.
