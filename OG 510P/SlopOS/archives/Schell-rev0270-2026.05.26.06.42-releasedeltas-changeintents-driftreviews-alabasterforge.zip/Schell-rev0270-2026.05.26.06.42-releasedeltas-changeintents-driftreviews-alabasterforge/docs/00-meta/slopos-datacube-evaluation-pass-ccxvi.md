# SlopOS datacube evaluation — pass CCXVI

This pass asks a more careful question:
**given that SlopOS capshell is still in design phase, what should Schell treat as already-learned guardrail, and what should Schell still refuse to settle?**

## 1) SlopOS's most useful gift right now is narrowness

The current capshell surfaces are valuable not because they define a finished shell, but because they define several important refusals:
- no ambient PATH lookup,
- no hidden shell-command string parsing,
- no shell-style word expansion before reviewed argv binding,
- no ambient startup/profile sourcing,
- no portable PTY/job-control plane,
- no portable signal/kill plane,
- and no richer result schema smuggled into the replay-stable result contract.

That is exactly the kind of discipline Schell should inherit during the design phase.
It tells us where hidden authority usually re-enters.

## 2) SlopOS already separates command truth from richer result structure

The result-sidecar boundary and output-normal-form docs are especially important for Schell.
SlopOS keeps replay-stable output identity small and digest-addressed, while explicitly deferring richer result structure to a separate sidecar family.

That maps almost directly onto the current Schell split:
- exact command lane remains canonical,
- richer typed sidecars may exist,
- but sidecars must not silently redefine authoritative replay/currentness truth.

## 3) The capshell design phase argues for a specimen-first shell, not a language-first shell

Because so many ambient and hidden behaviors are being ruled out at the capshell layer, Schell should resist the temptation to “solve the whole shell” at once with:
- one final command language,
- one universal object pipeline,
- one restore constitution,
- one shell-owned background/job model,
- or one smart-terminal protocol stack.

A better answer is to prove a specimen bundle above the narrow capshell truths that already exist.
That keeps the archive aligned with SlopOS's current maturity level.

## 4) SlopOS still leaves one very attractive move available: shell-authored semantic marks

The capshell narrowness docs cut off many old shell magic channels.
They do **not** prevent Schell from getting significantly better local UX through shell-authored semantic marks for:
- prompt/input/output boundaries,
- current working directory,
- chapter-local outcome/freshness posture,
- and optional result-sidecar references.

This is exactly the kind of move that respects SlopOS discipline:
small, explicit, inspectable, and useful even when richer local rendering is absent.

## 5) The companion cubes reinforce the same design-phase shape

The neighboring datacubes keep pushing toward the same architectural temperament:
- **ViewFS** keeps command/authority, payer roots, charge posture, overlays, and ghosts separate, reinforcing that shell luxury should preserve footing and spend honesty.
- **Helm** keeps preview warrants and enactment bonds separate, reinforcing that workflow cards and helper previews should remain weaker than execution.
- **Ward** keeps resolution bindings, tier witnesses, and hybrid seams visible, reinforcing that restored or summarized shell state should confess its freshness and source tier.
- **Harbor**, **Foundry**, and **Steward** keep compare-first, scalarization caution, and freshness/re-entry discipline visible, reinforcing that cleaner structure should not flatten away live distinctions.

Together they argue for a shell+terminal that becomes brilliant by naming more truths, not by pretending they are one.

## 6) What Schell should now treat as “must learn from the past”

Transferred through SlopOS and the companions, the must-learn lessons are now very sharp:
- **Do not let convenience reintroduce hidden parsers.**
- **Do not let startup/restore/history/helper UI impersonate fresh live footing.**
- **Do not let structured sidecars silently outrank exact command truth.**
- **Do not let local terminal luxury become a private second authority plane.**
- **Do not let preview, recommendation, or workflow cards quietly become enactment.**
- **Do not let restored context quietly become rerun authority.**

Those are not abstract morals.
They are the recurring failure modes the datacubes are already teaching us.

## 7) The smallest companion-safe answer is now clearer

A Schell-safe next step looks like this:
- exact command chapters remain authoritative;
- a tiny shell-authored semantic-marks floor powers navigation and local UX;
- typed sidecars carry richer structure, but remain inspectable and optional;
- workflows/prompts/skills/notebooks mostly insert into review first;
- restored layouts/cards stay visibly restored until revalidated or rerun;
- and any larger shell language or terminal protocol choice stays deferred.

## 8) Compact conclusion

SlopOS's current design phase does not tell Schell what the final shell must be.
It tells Schell something more valuable for now:
**where not to cheat.**

That makes the next move surprisingly concrete:
prove a specimen bundle on top of narrow capshell truths, add semantic marks before constitutions, and keep every richer helper lane visibly weaker than fresh reviewed execution truth.
