# SlopOS datacube evaluation — 2026-03-25 — pass CCXIII

**Schell should add causal lane witnesses, because SlopOS and the companion datacubes keep proving that why-this-appeared, fresh gesture, carried context, spender footing, approval basis, and disabled reason are neighboring truths rather than one flattering `click to do it` story.**

## 1) SlopOS already keeps approval basis narrower than shell folklore wants

The approval-basis posture in SlopOS is very clear: approval binds one exact action, not a floating mutable target.
If mutable basis matters, it must be reflected in the exact reviewed bytes rather than left ambient.
That is a direct instruction for Schell.
A suggestion card, chooser follow-on, or helper-born command can keep useful cause and correlation material, but it should still show whether the exact reviewed basis remains the same before stronger action is spent.

## 2) SlopOS call-chain and plumb posture both reject causal mystique

RFC-0118 keeps call-chain context bounded and veto-only rather than authoritative.
RFC-0117 keeps plumb messages canonical and useful for routing, but still non-authoritative and not capability-bearing.
Those are exactly the right imports for a future shell+terminal.
Schell should absolutely collect and show small causal lanes, but it should refuse to let imported causal metadata quietly become approval, capability, or automatic execution truth.

## 3) Tool-result visibility boundaries reinforce the same lesson inside helper-rich UX

SlopOS explicitly says audience lanes are not authority lanes.
Model-visible fields and component-only metadata can shape UI, transcript rendering, and local proposal context, but they do not become hidden approval basis or hidden action parameters.
That is a crucial warning for Schell because a custom shell+terminal will be tempted to blur assistant suggestions, portal returns, helper metadata, and actual execution truth.
The right move is smaller: keep the proposal useful, but keep its causal lane descriptive until a fresh reviewed action path is taken.

## 4) Steward is the clearest companion pressure: assist receipts already want this seam

Steward's assist-receipt posture is nearly the same lesson in a different accent.
It keeps one exact anchor, why-this-appeared, what-it-would-touch, and disabled reason distinct.
It also insists that exact provider-owned context outrank parse-lens folklore.
That is excellent pressure for Schell.
If a quick fix or helper action looks strong, the terminal should be able to explain why it is here and why it cannot currently apply, instead of hiding those truths behind smart-terminal mystique.

## 5) Ward and Harbor reinforce compare-first when cause and spender drift apart

Ward repeatedly separates cause, verification, and local admission.
Harbor keeps compare-first stoplines visible when basis or trust posture shifts.
Together they reinforce one healthy local rule for Schell:
when the current proposal no longer has a live gesture, no longer targets the same reviewed basis, or would now be spent by a different actor, the shell should cool toward compare / re-review / re-arm rather than pretending the earlier proposal still authorizes the stronger move.

## 6) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- one final tracing substrate,
- one final chooser or opener constitution,
- one final assistant/action merge model,
- one final cross-process provenance graph,
- or one final recommendation engine.

It only earns a smaller companion rule:
**let helper-rich shell objects carry tiny causal lane witnesses so Schell can say why-this-appeared, what gesture still backs it, what context crossed the boundary, who would actually spend it, what exact basis was reviewed, and why apply is disabled — without pretending suggestion provenance is execution authority.**
