# SlopOS datacube evaluation pass CCXLV — retention budgets for Schell

SlopOS remains the right companion pressure for Schell because its design-phase boundaries keep imported evidence, provider-local state, account surfaces, tool context, and hot actions from silently becoming stronger than their source.

Rev0248 maps that discipline onto retained command memory:

- `D-LEASE` / `CH-CAPLEASE` teach Schell that carried descriptors and retained receipts are weaker than live authority; a remembered command card should not keep acting just because it still exists.
- `auth-teardown` teaches that logout, revoke, disconnect, and expiry are lifecycle events; retaining their tombstones is useful, but not a proof that every derived copy was swept.
- `namecert` no-implied-redelegation teaches that copied runbooks, team pins, helper summaries, and search hits cannot inherit source authority or source retention policy automatically.
- FedCM/MCP/OpenURI/ACP/Capshell/Hot-action boundaries teach that browser account chips, tool snapshots, URI handlers, policy decisions, capsule text, and hot buttons each need separate retention and forgetting rows.

The new retention board should keep Schell from making a classic terminal mistake: equating better history with harmless history. In SlopOS terms, that would be a boundary leak from evidence into authority and from local minimization into global erasure.

The next proof should run RF-PF-01 through RF-PF-08 over RF-0001 through RF-0024 and record whether compact `retain/minimize/next` lines are enough to predict safe sharing, safe summaries, blocked raw exports, and needed sweep witnesses.
