# Research synthesis — 2026-05-25 pass CCLXIV — namespace integrity and row anchors

This pass imports identifier/reference pressure without adopting an external export format.

- JSON Schema 2020-12 treats identifiers, anchors, and references as part of schema navigation and validation posture; Schell imports only the lesson that anchor identity is not prose.
- OSCAL assessment/result models use machine-oriented UUIDs and resource references so findings and evidence can be referenced across instances; Schell imports scoped referenceability without making an OSCAL export.
- W3C PROV separates entities, activities, agents, derivation, attribution, and responsibility; Schell imports derivation/accountability vocabulary for row anchors without serializing RDF.
- SPDX 3.0.1 NamespaceMap pressure shows why prefix maps help humans and machines exchange compact identifiers; Schell imports prefix discipline without becoming an SPDX document.
- SlopOS rev0720 accepted-prefix/base-digest pressure keeps branch identity attached to transcript-memory anchors.

Bounded take: add NIL/SRR surfaces, fix two duplicate legacy ids with alias metadata, add global duplicate-id lint, add MAS/CAR rows, and keep all stable anchors non-authorizing.

Explicit non-take: no JSON Schema, OSCAL, PROV/RDF, SPDX, SCITT, public proof packet, helper runtime, policy engine, or SlopOS portal adapter.
