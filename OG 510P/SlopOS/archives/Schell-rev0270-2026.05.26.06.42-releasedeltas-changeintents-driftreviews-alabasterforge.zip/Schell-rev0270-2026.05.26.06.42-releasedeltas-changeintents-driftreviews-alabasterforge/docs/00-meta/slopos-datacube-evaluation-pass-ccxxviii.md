# Datacube evaluation pass CCXXVIII: companion-cube pressure on human-proof Schell downgrades

Revision: rev0231
Date: 2026-05-13
Scope: SlopOS rev0695 plus Foundry, Harbor, Steward, ViewFS, Helm, and Ward pressure on Schell's operator-comprehension gate.

## 1. SlopOS: provider-local truth is the terminal pattern too

SlopOS rev0695's FedCM boundary keeps browser-mediated identity useful but local: provider lists, login hints, browser-connected accounts, disconnect choreography, and returned tokens do not become durable SlopOS account/session/current-user truth.

Schell's equivalent is now broader than browser hints:

- shell marks do not become launch truth;
- OSC 52/OSC 8 escape effects do not become operator intent;
- mux passthrough does not become end-to-end authenticity;
- helper auto-mode does not become model-owned permission;
- restored history does not become current runtime;
- shared blocks do not become complete evidence.

Rev0231 imports this as an operator question: “Which facts are local to this provider/hop/export/session, and which are portable?”

## 2. Foundry: thin semantic spine, rich serving lanes

Foundry's semantic-spine discipline says the command chapter spine should stay tiny: launch, signal authorship, basis, coverage, spend, and raw reveal. Everything else is a serving lane: lens, action deck, helper packet, export receipt, or downgrade chip.

The scorecard enforces this by testing six obligations rather than inventing a giant terminal ontology.

## 3. Harbor: time and contract subsets become basis compare

Harbor's temporal witnesses say the same command text under a different cwd/env/account/host/policy epoch is a new contract. The scorecard makes basis mismatch a comprehension item, not a log field.

## 4. Steward: cause, condition, and aftermath stay separate

Steward prevents flattering collapse. A quick fix appeared because a detector matched output; an action is allowed because policy permits it; a command succeeded because an exit receipt says so; a provider settled something because a provider receipt says so. These are distinct causes and conditions.

Schell's action cards should show this distinction directly.

## 5. ViewFS: projection egress is a boundary

ViewFS's ghosts, badges, and projections map cleanly to filtered output, hyperlinks, structured lenses, and shared blocks. A projection can be useful while remaining weaker than the object or raw bytes. Rev0231 adds filtered/exported block fixtures for exactly this reason.

## 6. Helm: action cards are review queues

Helm's review-queue posture says terminal quick fixes should not become magic buttons. Port kills, package installs, PR opens, network pipes, file opens, cloud mutations, and helper tool calls are all different doors with different floors.

Schell should make each action's strongest honest next verb obvious.

## 7. Ward: tier witnesses must be human-readable

Ward's tier witnesses only help if the operator sees them. Rev0230 had tier fixtures; rev0231 asks whether the tier is legible under pressure. A hidden or cryptic tier is not product truth.

## 8. Evaluation of rev0230

Rev0230 successfully created the fake-marker/downgrade harness and a fixture pack. Its remaining weakness was that the human proof was described in prose rather than stored as a checkable surface.

Rev0231 fixes that by adding `operator-comprehension-scorecard-v0.json`, a linter, and eight additional fixtures for escape egress, hyperlinks, mux translation, keyboard negotiation fallback, remote path confusion, helper policy drift, transcript poisoning, projection export, and quick-fix authority floors.

## 9. Recommended next move

Build the four-card prototype named in the new terminal doc:

1. native direct argv;
2. spoof/escape seam;
3. restored/remote basis mismatch;
4. helper policy action.

Run the scorecard before adding a real terminal, syntax, protocol treaty, or helper runtime.
