# Research synthesis — 2026-03-25 — pass CCIV

This pass sharpens the next compact lesson from current official shell, terminal, desktop, and portal docs:
**the smartest next cross-boundary move for Schell is not “better open.” It is to keep opener class, opener provenance, live external state, and recent-history posture visibly separate, because current systems already split reveal, open, chooser, transfer, notification, and history in ways classic terminals usually hide.**

## 1) Current desktop APIs already expose route families instead of one generic open

Windows ShellExecute verbs distinguish `open`, `explore`, `openas`, `properties`, and `runas`.
Electron likewise keeps `showItemInFolder`, `openPath`, and `openExternal` as separate functions, and even lets `openExternal` carry options like activation and usage logging.
The lesson is straightforward: the route family matters.
Schell should not flatten exact reveal, ordinary open, choose-an-app, or stronger privileged launch into one flattering “opened” verb.

## 2) Shell-aware terminals keep getting better at selecting the right object before crossing out

VS Code shell integration, WezTerm shell integration, iTerm2 marks, and kitty hints all keep validating the same front-half win: if the shell tells the terminal where prompts, inputs, and outputs are, the terminal can stage exact files, URLs, and command outputs with much less guessing.
kitty is especially crisp here because one hints path inserts a filename into the prompt while another opens a file at a line number.
That is a strong proof that **selection luxury** and **external route luxury** should remain separately named.

## 3) Portals show the difference between transient transfer and durable access

The XDG FileTransfer portal is explicitly a middle-man for copy-paste or drag-and-drop file transfer and says files added this way do **not** stay accessible across sessions.
The Documents portal, by contrast, creates document-store entries and can make them persistent across sessions.
This is exactly the kind of distinction Schell should steal.
A recent handoff hint, transient transfer, durable imported object, and external open history are neighboring truths, not one thing.

## 4) Notifications and launch APIs keep warning against overclaiming aftermath

The XDG Notification portal explicitly says the application cannot learn whether the notification was actually presented to the user.
That is a powerful reminder for the shell+terminal problem too.
Even when an external route is admitted, the terminal should stay careful about claiming that the user definitely saw it, kept it open, or finished work there.
Open-state badges should therefore prefer small truths such as admitted, chooser-pending, no-live-signal, or history-only.

## 5) Recent-item and opener memory are useful, but they are separate policy lanes

macOS keeps recent-item behavior as a separate configuration concern, Windows keeps open-with/default-program behavior as a separate shell concern, and Electron exposes launch logging separately from the basic call.
That convergence suggests Schell should not let “worked last time” silently become “do this now” unless the operator can see the difference.
A tiny why-this-opener drawer and recent-hint badge would likely buy a lot of trust.

## 6) Security lessons keep the route ladder honest

Ghostty’s 2026 advisory about pasted or dropped control characters leading to command execution is another reminder that the terminal must be careful whenever rich selection or drag/drop routes start to feel magical.
The right answer is not less delight.
It is more explicit route class and provenance.
When the operator can tell whether something is insert-only, preview-safe, reveal-exact, open-external, or only historical, the shell has a much better chance of staying powerful without becoming spooky.

## 7) Compact conclusion

The ecosystem is pointing Schell toward one very good next seam:
- keep chapter-local selection rich,
- add opener racks and why-this-opener drawers,
- keep live external state badges visibly weaker than completion truth,
- and keep recent hints weaker than durable reopen or imported local authority.

That is enough to make the shell+terminal feel unusually sharp while still deferring the final handler registry, live external observation story, and recent-items architecture.
