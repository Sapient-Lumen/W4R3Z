# Research synthesis — 2026-03-25 — pass CCXI

This pass sharpens the next compact lesson from current official docs on asynchronous acceptance, long-running operation monitors, enabled-versus-active posture, notification limits, launch-return weakness, and controller-side settlement:
**the smartest next move for Schell is not a giant task manager. It is a smaller aftermath story: let stronger actions optionally leave an aftercare card, keep admission separate from activity and settlement, and show a settlement monitor only when a provider really offers one.**

## 1) HTTP 202 teaches the right admission humility

HTTP keeps one of the most important shell lessons brutally honest.
`202 Accepted` means the request was accepted for processing, but processing is not completed yet, may not even eventually happen, and the response ought to point at a status monitor if later truth matters.
That is almost a direct design brief for Schell's stronger external actions:
**admission is real, but it is not durable completion.**

## 2) Google long-running operations show the cleanest tiny monitor shape

Google's long-running-operation surface keeps the contract admirably small.
The operation may expose metadata such as progress and creation time.
If `done` is false, there is neither `error` nor `response`.
If `done` is true, exactly one of `error` or `response` is present.
That is a beautiful model for Schell aftermath cards:
- some actions should have no followthrough object,
- some should have one tiny monitor,
- and settlement should stay disjoint from in-progress posture.

## 3) XDG InputCapture proves that armed and active are not the same truth

The InputCapture portal draws a line terminals often blur.
There is an **enabled** state where capture has been requested but events are not yet flowing, and an **active** state where events are actually being delivered.
The compositor controls when and whether that upgrade happens.
That is an excellent lesson for Schell:
`armed`, `awaiting conditions`, and `active elsewhere` should not collapse into one generic live badge.

## 4) XDG Notification proves that attention and consumption should stay humble

The Notification portal is equally useful.
An app can send and withdraw notifications, and notifications may outlast the app itself.
But the application still cannot learn whether the notification was actually presented to the user.
That is exactly the sort of humility a shell+terminal needs for wake cues and finish notices:
attention attempts are useful, but they are weaker than current settlement and much weaker than “user definitely saw it.”

## 5) Windows launcher APIs reinforce that success-at-launch is still a narrow truth

Windows ShellExecute keeps its success claim small: return value greater than 32 means the launch request succeeded, and failure returns an error value.
That is useful admission truth.
It is not a portable statement that the target rendered content, kept running, or finished later work.
Schell should copy the narrowness rather than inflating launcher success into rich aftermath truth.

## 6) Kubernetes Jobs remind us that settlement can lag partial success and cleanup

Kubernetes adds one more useful lesson:
controller-side settlement is often later and stricter than “some work happened.”
A Job may still be running while indexes succeed or fail; once all Pods are terminated, the controller sets the final Failed condition, and deadlines can terminate running Pods before final failure is recorded.
That is exactly why a shell should keep provider-active, cleanup-in-progress, and settled-failed truths distinct.

## 7) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- let strong actions produce **admission-only** aftermath when that is all the system truly knows,
- add an **aftercare card** only for routes where later truth matters,
- keep **armed / enabled**, **active elsewhere**, **provider-settled**, and **shell-adopted settlement** visibly different,
- let notifications and wake cues route back to aftermath objects instead of pretending to be completion,
- and degrade stale or missing monitors to **lost-or-expired** or **historical-only** rather than bluffing.

That is enough to make the shell feel dramatically more honest after launches, detours, remote tasks, and long-running operations while still deferring the final callback, watch, workflow, and task-manager architecture.
