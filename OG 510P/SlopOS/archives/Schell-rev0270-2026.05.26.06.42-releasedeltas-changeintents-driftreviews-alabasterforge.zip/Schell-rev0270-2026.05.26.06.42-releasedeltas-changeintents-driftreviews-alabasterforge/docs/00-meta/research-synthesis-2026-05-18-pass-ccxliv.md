# Research synthesis 2026-05-18 pass CCXLIV — residue tombstones

Rev0247 adds a residue-tombstone pass to Schell. The lesson from current systems is not merely that grants expire or can be revoked; it is that death events leave embers.

## Outside pressure

- OAuth token introspection gives protected resources a way to query current token state, including whether a token is active and the authorization context. But the specification also discusses caching introspection responses, which means Schell must show resource-side cache state and recipient context rather than equating one active/ inactive answer with universal truth.
- OIDC back-channel logout is stronger than browser-front-channel logout because it uses direct OP-to-RP communication, but RP-local session termination is still application-specific and must be acknowledged per recipient.
- CAEP/Shared Signals makes access-related changes such as session revocation transmissible between cooperating parties; that is a signal stream, not proof that every receiver has already applied cleanup.
- Docker logout and Git credential-cache show the local-store side of residue: local credential deletion, helper-specific stores, daemon memory, sockets, and timeouts are distinct from provider revocation.
- OpenSSH ControlPersist, forwarded agents, tmux sessions, systemd/logind/user services, nohup/disown, and background jobs show that terminal death, shell exit, pane close, and route closure are different events.
- Kubernetes finalizers and garbage collection show why deletion requested, deletion visible, finalization pending, and dependent cleanup must stay separate.
- Terminal escape effects such as OSC 52 clipboard writes and OSC 8 hyperlink targets create residue outside the command grant itself.

## Schell rule

A death event becomes a useful tombstone only when it carries:

1. death event and claimant;
2. raw receipt;
3. residue inventory;
4. cascade boundary;
5. sweep authority;
6. aftercare owner;
7. post-sweep witness;
8. safe next verb and blocked effect floor.

## Decision-light posture

No sweeper runtime, auth adapter, terminal extension, credential cleaner, browser cleaner, Kubernetes controller, helper memory runtime, shell grammar, or UI toolkit is chosen. The proof is static and falsifiable: can operators read compact `death/residue/next` lines without overclaiming cleanup?
