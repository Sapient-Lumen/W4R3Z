# Research synthesis — 2026-03-25 — pass CCXIV

This pass sharpens the next compact lesson from current official docs on Wayland configure/ack rules, Language Server Protocol capability negotiation, WebSocket and SSH extension negotiation, and XDG chooser/request flows:
**the smartest next move for Schell is not a giant capability broker. It is a smaller negotiated-terms story: let shell-visible objects keep offered terms, agreed terms, dynamic registration/supersession, and historical cached terms visibly separate.**

## 1) Wayland xdg-shell shows that pending offers can be superseded before commit

The xdg-shell protocol is extremely clear.
A compositor can send multiple configure events before a client responds.
The client is free to discard all but the last configure it received.
And if the client sends multiple `ack_configure` requests before committing, only the last ack before the commit indicates which configure event the client is really responding to.

That is a beautiful lesson for Schell.
A pending offered state is not yet live truth.
And an earlier seemingly-valid offer can be superseded before the operator actually commits anything.

## 2) LSP shows that startup agreement is not the whole capability story

The Language Server Protocol starts with `initialize`, but the spec keeps the next step explicit.
After the client receives the initialize result, it sends `initialized`, and only then can the server dynamically register capabilities.
The protocol also defines `client/unregisterCapability`, which means a once-available capability can later be withdrawn.

That matters because a lot of smart shell+terminal luxury will be negotiated exactly this way.
Schell therefore should not flatten `available at startup` and `still available now` into one badge.
It should keep initial agreement, later registration, and later unregistration separately visible.

## 3) WebSocket and SSH both show that offered menus are weaker than agreed results

WebSocket keeps the distinction very clean.
The client can offer subprotocols and extensions, but the server returns the selected `Sec-WebSocket-Protocol` only to confirm the subprotocol of the connection.
The RFC also makes version negotiation explicit: if the server does not support the requested version, it returns the versions it is willing to use and the client can retry the handshake.

SSH extension negotiation adds another useful nuance.
Advertising `ext-info-c` or `ext-info-s` only means a party must be prepared to accept `SSH_MSG_EXT_INFO`; it still may choose not to send that message.
So even the presence of a negotiation indicator is weaker than the later concrete extension payload.

For Schell, the lesson is simple:
**offered menu, negotiated acceptance, and later concrete terms should stay separately nameable.**

## 4) XDG chooser/request flows show that pending interaction, selected result, and fresh activation are different truths

The XDG Request interface gives a handle that stays alive for the duration of the user interaction, and the interaction ends with a `Response` signal.
The AppChooser backend then adds another useful distinction.
A call may include a `last_choice` hint or an incoming `activation_token`, the offered choices can still be updated while the request is outstanding, and the results later return the actual `choice` plus an activation token that may be newly generated if user interaction occurred.

That is almost a direct design brief for Schell.
A remembered preferred opener is weaker than a current chosen opener.
A pending chooser request is weaker than a settled choice.
And a fresh returned activation token is stronger than an older remembered one.

## 5) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- keep the offered menu separate from the agreed result,
- let superseded or discarded pending terms cool visibly instead of disappearing,
- keep startup agreement separate from dynamic later registration/unregistration,
- keep chooser request handles, chosen results, and activation aftermath separately named,
- and cool cached prior terms to compare/history rather than bluffing that they still prove current live footing.

That is enough to make helper-rich shell integration, remote attach luxuries, chooser-backed routes, and dynamic terminal capabilities much more trustworthy while still deferring the final broker and policy architecture.
