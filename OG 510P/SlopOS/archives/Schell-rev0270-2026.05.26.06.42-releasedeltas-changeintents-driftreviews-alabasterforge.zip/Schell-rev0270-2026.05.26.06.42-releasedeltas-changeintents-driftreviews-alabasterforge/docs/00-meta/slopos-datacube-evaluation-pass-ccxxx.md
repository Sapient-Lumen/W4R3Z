# Datacube evaluation pass CCXXX: replay and export as Schell's FedCM analogue

Revision: rev0234  
Date: 2026-05-13  
Scope: SlopOS rev0695 plus companion-cube pressure on rendered Schell command cards.

## 1. SlopOS pressure

SlopOS rev0695 keeps FedCM/browser/provider signals behind an explicit boundary. The browser can help with identity mediation, but browser-local and provider-local signals do not become portable SlopOS account truth.

Schell's equivalent boundary is now replay/export. A command chapter can be restored, copied, printed, shared, attached to a helper, or imported into another account/workspace. Those moves carry useful evidence, but they do not carry current launch authority, recipient identity, local path authority, helper policy authority, or raw-output completeness unless the packet proves it.

## 2. Foundry pressure: keep the spine tiny

Foundry's semantic-spine lesson argues against turning rendered cards into a giant vocabulary dump. Rev0233 keeps the spine to six drawer labels: truth, authorship, basis, coverage, authority, reveal. Replay/export/lens capsules hang from that spine without becoming a second constitution.

## 3. Harbor pressure: basis movement is a contract movement

Replay capsules are Harbor-like temporal witnesses. Original repo root, env epoch, dependency lock, route locality, and helper policy epoch must be compared against current footing before rerun. Old output may remain valuable, but it is not fresh settlement.

## 4. Steward pressure: cause, policy, action, and aftermath are different

A helper batch can contain read-only inspection, patching, test execution, network fetch, secret access, and cloud mutation. Steward's separation discipline says not to collapse these into one “helper did it” claim. Rev0233 therefore requires per-effect floors.

## 5. ViewFS pressure: projection deserves ghosts

A rich table lens, terminal-chat summary, copied block, printed issue card, or exported helper context packet is a projection. ViewFS-style ghosting maps directly: show the projection, but badge what was filtered, redacted, transformed, source-local, or missing.

## 6. Helm pressure: doors need review queues

Rendered action buttons are doors. Helm says every door needs a queue posture. Rev0233 makes review/rerun/route/export actions carry floors rather than letting the prettiest button silently spend the strongest authority.

## 7. Ward pressure: tiers must survive the dashboard

Ward's tier-witness lesson becomes a card rule: if a compressed card cannot tell raw, lens, export, helper, restored, and recipient-local tiers apart, the card has failed even if it looks clean.

## 8. Evaluation of rev0232

Rev0232's static four-card prototype gave Schell a checkable evidence shape. Its weakness was still product distance: it did not show whether the card could be read quickly. Rev0233 adds a paper-render JSON, a linter, and eight new fixtures around rendered raw reveal, replay drift, redaction, terminal-chat coverage, helper batches, rich-lens lossiness, account/provider portability, and printed bug-report evidence loss.

## 9. Recommended next move

Run a real glance test. The repo now has enough static machinery. The next useful evidence is whether a human can answer CQ-01 through CQ-05 from the rendered cards without knowing the design backstory.
