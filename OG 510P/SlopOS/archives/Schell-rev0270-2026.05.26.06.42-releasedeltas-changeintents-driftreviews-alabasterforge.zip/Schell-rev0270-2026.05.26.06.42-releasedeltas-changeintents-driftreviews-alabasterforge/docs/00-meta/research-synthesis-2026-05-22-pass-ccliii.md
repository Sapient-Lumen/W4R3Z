# Research synthesis pass CCLIII — status epochs, anti-equivocation, and proof-status reliance

Date: 2026-05-22
Revision: rev0256

## Imported pressure

- Certificate Transparency frames append-only logs as detectable via Merkle consistency proofs, monitoring, and gossip, but CT does not prevent bad issuance or define erasure. Schell imports the consistency and split-view caution, not CT runtime semantics.
- Sigstore/Rekor exposes append-only transparency and monitor pressure: inclusion and consistency checks can improve auditability while making metadata durable proof residue. Schell imports monitor/checkpoint vocabulary but blocks public proof overclaims.
- SCITT architecture and receipt drafts distinguish signed statements, transparent statements, registration policy epochs, receipts, and verifiable data structures. Schell imports receipt-bound status humility, not a supply-chain transparency service.
- W3C Bitstring Status List shows how status publication can be batched for privacy, but status concerns a credential/status object and not necessarily the underlying real-world fact. Schell imports status/privacy tension and blocks erasure/sanitization claims.
- Key Transparency drafts emphasize consistent views, stale-bound limits, long-term client state, and detecting service-operator equivocation. Schell imports anti-equivocation, stale-cache, and trust-epoch concerns for proof status.

## Bounded take

Rev0256 adds `status-epoch-gossip-board-v0.json` and `proof-status-reliance-gauntlet-v0.json`. A proof status now needs epoch, predecessor/checkpoint, trust epoch, freshness source, receiver scope, challenge state, gossip/consistency witness, proof-residue budget, and blocked effects. Consumers default-deny when status is split, stale, unreceipted, inconsistent, privacy-withheld without appeal, key-epoch gapped, receiver-disagreed, or clock-skewed.

## Explicit non-take

Schell does not implement a transparency log, gossip protocol, SCITT service, Rekor monitor, Certificate Transparency deployment, Key Transparency deployment, W3C status-list host, credential runtime, legal/compliance engine, deletion API, helper runtime, provider adapter, UI, terminal protocol, or shell grammar.
