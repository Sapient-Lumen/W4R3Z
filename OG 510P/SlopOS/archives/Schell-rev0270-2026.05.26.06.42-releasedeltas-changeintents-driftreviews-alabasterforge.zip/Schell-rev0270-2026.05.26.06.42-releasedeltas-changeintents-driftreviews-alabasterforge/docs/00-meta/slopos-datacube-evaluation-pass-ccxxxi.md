# Datacube evaluation pass CCXXXI: capsule transfer as Schell's nonportable-boundary test

Revision: rev0234  
Date: 2026-05-13  
Scope: SlopOS rev0695 plus companion-cube pressure on Schell transfer capsules.

## 1. SlopOS pressure

SlopOS rev0695 is extremely useful here because it treats browser/FedCM/provider/account signals as local mediation facts, not portable substrate truth. Schell's transfer capsules should inherit that posture.

A command card may carry a source account chip, selected workspace, login hint, provider label, helper policy name, or browser-mediated auth detail. On import, those facts are evidence about the source environment. They are not recipient account truth, not launch permission, and not proof that the recipient has the same connected service.

## 2. Capshell pressure: exact packs are veto-only

SlopOS capshell exec-pack discipline treats exact argv/env/cwd/stdio/fd/effect context as a completeness seal and veto surface. Schell should not weaken that by letting a replay packet say “we once had an exact pack, therefore run now.” Old exactness remains old exactness until current basis is proven.

## 3. Foundry pressure: keep the spine small

Foundry's semantic spine lesson argues against inventing a giant export ontology. Rev0234 keeps the transfer rows small: boundary, capsule type, incoming claim, preserved fields, lost/source-local fields, downgrade, receipts, safe verbs, forbidden promotions.

## 4. Harbor pressure: time and lineage are not decoration

Harbor-like temporal witnesses map directly to replay capsules. Old success, old basis, old account, old route, and old helper policy must be shown as old. A transfer capsule without lineage is not safe to rerun.

## 5. Steward pressure: helper batching needs separable causes

A helper context slice can mix read-only analysis, patching, tests, network, secrets, cloud changes, and notifications. Steward's cause/effect separation says Schell should split helper packets by authority floor and preserve denied/skipped residue.

## 6. ViewFS pressure: projections need ghosts

ViewFS-style projection ghosts are the right metaphor for lenses and screenshots. If a card becomes a clean table, issue preview, printout, or summary, the missing raw bytes, links, redactions, and local-only reveals need visible ghosts.

## 7. Helm pressure: return paths are not approvals

Helm's door/review-queue discipline maps to notification return paths. Clicking a notification, chat card, or background-agent banner should reopen context; it should not spend approval or imply settlement.

## 8. Ward pressure: tiers survive transfer or the dashboard lies

Ward's tier-witness pressure becomes a transfer invariant. Raw, lens, export, redacted, helper-slice, remote-observe, replay-draft, and recipient-reauth grades must not collapse into one pretty command card.

## 9. Evaluation of rev0233

Rev0233 successfully made the four cards readable as a paper prototype, but it still treated transfer mostly as prose. Rev0234 improves the evidence posture by adding a ten-drill transfer gauntlet, ten new adversarial fixtures, and a linter that checks capsule families, arrival grades, card refs, fixture refs, receipts, and non-decision hygiene.

## 10. Recommended next move

Build the smallest simulator that imports the ten transfer drills and prints, for each one: arrival grade, preserved fields, missing/source-local fields, required receipts, safe next actions, blocked promotions, and the operator question. Keep it static until it fails unsafe imports reliably.
