# Research synthesis — 2026-05-18 pass CCXLIII

Revision: rev0246  
Focus: grant lifecycle rooms, revocation cascades, and delegated aftercare.

## Imported pressure

Current systems make lifecycle authority easy to overstate:

- OAuth token revocation invalidates a token and, where applicable, other tokens under the same authorization grant; it is not a universal account teardown or rollback primitive.
- OAuth token exchange separates subject and actor tokens, so exchange/impersonation/delegation rows should not be collapsed into renewal authority.
- Vault leases expose TTL, renewability, renewal results, expiry, and revocation; returned lease state beats requested extension.
- GitHub App installation tokens expire and are bounded by repository and permission scope, while GitHub Actions OIDC depends on current claim binding such as audience, subject, workflow, and job identity.
- AWS STS role chaining, Kubernetes impersonation, OpenSSH agent forwarding, sudo timestamp caches, Slack interaction payload retries, MCP authorization/resource binding, and FedCM/browser account surfaces all carry lifecycle state that can decay, fork, expire, or remain provider-local.

## Bounded take

Schell should steal one compact lifecycle line:

`lifecycle: <surface> · grant: <returned/cascade state> · next: <safe latch>; <effect> blocked`

That line must expose issuance basis, renewal actor, returned live state, cascade domain, child grants, provider/locality, aftercare owner, safe non-effect latch, and blocked effect floor.

## Explicit non-take

Do not treat keepalives, requested TTLs, old refresh tokens, old OIDC claims, expired app tokens, role-chain sessions, old impersonation groups, forwarded agent sockets, sudo timestamps, Slack retries, MCP badges, FedCM disconnects, CH-CAPLEASE descriptors, redacted revoke receipts, or policy-epoch text as live authority.

Do not freeze a grant lifecycle schema, token store, refresh rotator, revocation broker, lease service, provider adapter, helper runtime, terminal protocol, shell grammar, or UI toolkit from this pass.

## Resulting proof surface

- `docs/80-terminal/grant-lifecycle-rooms-revocation-cascades-and-delegated-aftercare.md`
- `docs/80-terminal/grant-lifecycle-board-v0.json`
- `tools/check_grant_lifecycle_board.py`
