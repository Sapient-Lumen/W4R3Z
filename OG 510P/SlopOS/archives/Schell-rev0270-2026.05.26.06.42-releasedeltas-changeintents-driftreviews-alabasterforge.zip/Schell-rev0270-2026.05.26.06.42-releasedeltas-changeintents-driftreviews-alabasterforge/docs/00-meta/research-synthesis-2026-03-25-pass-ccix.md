# Research synthesis — 2026-03-25 — pass CCIX

This pass sharpens the next compact lesson from current official docs on idempotent methods, client tokens, idempotency keys, and request IDs:
**the smartest next move for Schell is not a bigger replay engine. It is a smaller retry-safe effect story: let some stronger actions carry tiny effect keys, keep them separate from stale-basis checks, and surface duplicate suppression or mismatch honestly.**

## 1) HTTP itself already distinguishes idempotent semantics from ordinary unsafe mutation

RFC 9110 keeps the basic lesson plain: request methods differ in semantics, and idempotent methods are special precisely because repeating the same request is intended to have the same effect on the server.
That is a useful shell reminder before any product-specific guidance arrives.
A shell+terminal that wants to help with retries should separate read-like repeatability from write-like or spend-like actions that need extra protection.

## 2) AWS shows the most useful compact rule: same token plus same parameters may replay, same token plus different parameters must fail

EC2's client-token guidance is almost a direct design sketch for Schell.
A client token makes supported operations idempotent; retrying with the same token and the same parameters succeeds without performing further actions; retrying with the same token but materially different parameters fails with `IdempotentParameterMismatch`.
That gives Schell a beautiful small vocabulary worth stealing:
**same effect**, **same key wrong payload**, and **do not spend twice**.

## 3) Stripe adds two crucial refinements: replayed result honesty and bounded retention

Stripe's idempotent-request docs add two excellent shell lessons.
First, the server can return the **same stored result** for the same key, including failures, instead of pretending the retry was a fresh mutation.
Second, idempotency keys live on a horizon rather than forever; Stripe prunes them after at least 24 hours and compares incoming parameters to the original request to prevent misuse.
That is exactly the kind of humility Schell wants around retries after disconnects, double-clicks, or uncertain follow-through.

## 4) Google's AIP guidance reinforces that request identity is a separate seam

Google's AIP-155 keeps request identification explicit: APIs may add a `request_id` to uniquely identify a request, and concrete Google Cloud APIs keep saying that a request becomes idempotent only if the `request_id` is provided.
That pushes Schell toward a small but powerful rule:
**fresh review basis is not enough to make a retry duplicate-safe; some actions also need an explicit effect identity.**

## 5) Compact conclusion

Current official docs keep converging on one very good next seam for Schell:
- add **effect keys** to opt-in stronger chapter-local action objects that might otherwise double-spend,
- keep **effect identity** separate from **precondition / stale-basis** identity,
- surface **duplicate-suppressed**, **replayed-prior-outcome**, **still-processing**, **effect-mismatch**, and **dedupe-window-expired** honestly,
- let history/restore/assistant lanes stage old effect identity without silently reusing it,
- and keep all of that smaller than a durable exactly-once plane.

That is enough to make the shell feel unusually trustworthy after interruption, uncertainty, or reconnect while still deferring the final fingerprint schema, retention substrate, and retry constitution.
