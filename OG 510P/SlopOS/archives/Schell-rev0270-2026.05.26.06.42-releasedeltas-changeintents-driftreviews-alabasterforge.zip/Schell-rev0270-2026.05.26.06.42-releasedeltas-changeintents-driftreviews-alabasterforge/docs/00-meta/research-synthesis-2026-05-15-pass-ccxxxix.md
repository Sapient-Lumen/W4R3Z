# Research synthesis — 2026-05-15 pass CCXXXIX

Focus: replay closure, deterministic comparison, terminal playback, provenance verification, and authority fences.

## Sources re-read this pass

- Terminal replay precedent: asciicast-style event streams make terminal playback and lightweight sharing easy, but event playback is not command launch truth.
- Reproducible-build precedent: reproducibility depends on source, build environment, and build instructions; time, randomness, locale, paths, volatile inputs, and output order are replay closure hazards.
- Environment closure precedent: Nix-style reproducible and shareable environments are excellent comfort, but a tool closure is not the current workspace, cwd route, host capability, account, or consent basis.
- Provenance precedent: SLSA and in-toto rows for build definition, run details, builder, materials, products, byproducts, command, and dependencies are exactly the rows Schell should preserve around command products.
- Observability precedent: OpenTelemetry CLI spans are useful for process correlation and search but do not contain stdin, approval, or settlement by default.
- Signing/transparency precedent: Sigstore-style signing and logs preserve artifact integrity/publication evidence; they do not prove current replay safety.

## What Schell should steal

1. **Replay packet closure rows.** Every replay candidate should say which source, environment, input stream, terminal, external service, and authority rows are captured or missing.
2. **Inert playback.** Terminal playback should inert clipboard writes, hyperlinks, app opens, form submits, network calls, broadcasts, and tool calls until current authority is explicit.
3. **Comparison-first luxury.** Make rebuild/compare/fuzz/diff fast when closure is strong enough, even while live rerun remains blocked.
4. **Closure grades.** Recording playback, deterministic compare, provenance verification, trace correlation, helper draft, sandbox rehearsal, and live spend are different latches.
5. **First missing row.** Do not show generic danger. Name the first missing replay row: network response, secret lease, tool schema, time/random seed, cwd route, TUI state, host capability, account, or consent.
6. **Recipient authority fences.** Replay import returns as source evidence. Current workspace/account/policy/tool/queue binding and fresh gesture are required before effects.

## What Schell must refuse

- Treating terminal cast playback as command launch truth.
- Treating reproducibility, provenance, signing, CI success, trace spans, or helper summaries as live approval.
- Replaying terminal effects as if they were output text.
- Refetching network inputs silently.
- Reusing stale secrets, idempotency keys, browser account chips, helper policies, MCP schemas, or hot-action order.
- Letting replay convenience collapse inspect/draft/sandbox/compare/review/spend.

## No-regret next move

Keep `replay-verification-board-v0.json` as a paper proof surface. Run RV-PF-01 through RV-PF-08 before building a runner. If operators cannot predict replay grade, missing closure row, safe latch, and current authority requirement from one compact line, simplify the vocabulary.
