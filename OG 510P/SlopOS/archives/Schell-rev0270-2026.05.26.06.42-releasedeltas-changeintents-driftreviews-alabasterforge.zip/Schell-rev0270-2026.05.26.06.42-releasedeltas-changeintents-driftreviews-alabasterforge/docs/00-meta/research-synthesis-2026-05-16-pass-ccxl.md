# Research synthesis — 2026-05-16 — pass CCXL

Revision: rev0243  
Topic: collaborative command relays, social proof, shared blocks, PR/issue bots, check annotations, artifact attestations, and action authority

## What changed in this pass

Rev0242 made replay evidence portable but fenced it away from live authority. Rev0243 asks what happens when that portable command card becomes a team object: permalink, embed, chat unfurl, issue attachment, PR review, check annotation, artifact attestation, cloud-agent session, helper summary, runbook snippet, or cached public link.

The outside pattern is strong:

- Warp-style blocks make commands and outputs atomic, copyable, re-inputtable, shareable, bookmarkable, and embeddable.
- Slack-style unfurls and Block Kit make social command cards visible, interactive, and accessible across chat surfaces.
- GitHub Checks make line/path/status annotations and manual reruns easy to attach to code review.
- GitHub artifact attestations make provenance/integrity claims easy to publish alongside artifacts.
- Codex and Claude Code PR/issue integrations make `@agent review/fix` workflows feel like normal team collaboration.

Schell should steal the comfort, but invert the authority assumption:

> Shared command cards are collaboration evidence; social proof is not launch truth, approval truth, settlement truth, or current merge authority.

## Imported lessons

1. **Shareable blocks are the right object shape.** A command block that carries command, output, prompt, and formatting is the collaboration unit Schell wants. The risk is row-selection loss: if cwd, env, stderr, raw transcript, redaction tombstones, account, policy epoch, or settlement rows are omitted, the recipient must see that before copying or rerunning.

2. **Embeds and unfurls are projections.** They make command cards more useful in docs and chat, but also introduce web origins, crawlers, clipboard permissions, preview metadata, and accessibility summaries. Schell should mark projection loss and keep terminal effects inert.

3. **PR review agents are scoped relay actors.** Codex and Claude Code style comments are powerful, but a comment trigger is not a merge approval, not a terminal approval, and not durable repo authority. Schell should record actor, platform, token/permission scope, prompt lineage, created branch/diff, and current review gate.

4. **Check annotations are excellent narrow evidence.** Path, line, severity, status, and run links should become nice command-card surfaces. They must stay bound to commit/head and line validity.

5. **Artifact attestations prove production history, not ship intent.** They can verify subject digest and builder/workflow provenance; they do not approve release, current branch, deploy, rollback, or recipient command replay.

6. **Social proof is useful but must not spend.** Reactions, LGTM, comments, summaries, and cached previews should improve attention and recall, not silently satisfy approval, settlement, or effect floors.

## Resulting Schell pressure

Rev0243 adds a collaboration-relay board with twenty-four cases and twenty-four new command-chapter fixtures. It treats shared command cards as first-class, but requires every relay to name:

- relay origin;
- audience/lifecycle state;
- carried rows;
- omitted/projected rows;
- safe collaboration verbs;
- blocked effect verbs;
- current recipient or platform rebind requirement.

## Deliberate non-decisions

No final share encoding, hosted viewer, team identity model, PR/issue adapter, Slack/GitHub integration, agent transport, CI attestation adapter, merge/deploy flow, accessibility contract, shell grammar, terminal protocol, or UI toolkit is frozen by this pass.
