# SlopOS datacube evaluation — pass CCXLII

Revision: rev0245  
Focus: what Schell should learn from SlopOS about delegation, revocation, renewal, and teardown without importing SlopOS schemas wholesale.

## Read of SlopOS pressure

SlopOS rev0695 remains design-phase, but it has several mature posture cuts that Schell should mirror as product discipline:

- D-LEASE treats a lease proxy as authority and CH-CAPLEASE as evidence. The descriptor must not be confused with raw capability authority.
- D-LEASE forbids raw capability export, unbounded renewal, and keepalive-as-renewal.
- Auth teardown refuses a portable logout/disconnect/revoke seam across generic app-secret, vault, powerbox, LLM, or URI surfaces.
- The MCP token-revocation boundary keeps OAuth revocation provider-local rather than turning it into account-disconnect truth.
- Namecert redelegation refuses implicit propagation or may-delegate semantics.
- ACP, Capshell, FedCM, MCP, OpenURI, hot-action, network idempotency, and capability leases keep account, route, tool, launch, and settlement authority on separate seams.

## Schell import

Schell should not import the SlopOS object model. It should import the discipline:

1. Every delegated command card needs authority lineage rows.
2. Lease/grant descriptors stay evidence until a live proxy/grant/current recipient binding exists.
3. No onward delegation, renewal, widening, or transfer by default.
4. Revocation is a future-use or provider-local teardown claim, not proof of settlement rollback.
5. Route facts — forwarded sockets, ports, terminal broadcasts, account chips, cached tokens — are never grant authority.

## Next proof

Run DL-PF-01 through DL-PF-08 against the twenty-four DL cases. If the operator cannot distinguish grant evidence, live grant state, propagation policy, and revocation state from the compact line, Schell should cut the delegation vocabulary before any auth-bearing helper runtime is designed.
