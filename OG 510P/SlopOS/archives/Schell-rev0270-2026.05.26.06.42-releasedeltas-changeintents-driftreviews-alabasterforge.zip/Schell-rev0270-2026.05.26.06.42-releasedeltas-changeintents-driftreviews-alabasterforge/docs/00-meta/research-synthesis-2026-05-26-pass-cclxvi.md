# Research synthesis — 2026-05-26 pass CCLXVI

Rev0266 imports release-custody and rebuild pressure into Schell without adopting a software-supply-chain runtime.

- SLSA provenance describes how an artifact was produced so consumers can verify expectations and rebuild if desired.  Schell imports that as a static release-custody expectation, not as a SLSA provenance generator.
- in-toto attestations are authenticated metadata expressing supply-chain claims.  Schell imports the distinction between attestation metadata and consumer verification, not the in-toto layout/runtime.
- Reproducible Builds defines reproducibility as bit-for-bit recreation from the same source, environment, and instructions.  Schell therefore blocks reproducible-build claims until an independent rebuild drill exists.
- Sigstore-style signing/transparency helps consumers check identity/custody claims, but it does not prove semantic truth, erasure, sanitization, compliance, helper permission, or SlopOS append authority.

Audit/refactor consequence: package handoff now receives `PACKAGE-CONTENTS-MANIFEST.json`, `release-custody-ledger-v0.json`, `package-reproducibility-gauntlet-v0.json`, and three lint gates.  Release green remains weak: checked archive custody, not deletion proof.
