# Research synthesis — 2026-05-22 pass CCLI

Rev0254 imports a new pressure family: proof of forgetting can itself become retained memory.

External pressure, bounded:

- GDPR-style minimisation and erasure pressure means proof rows should be necessary, scoped, and not broader than their purpose. Schell does not claim legal compliance.
- NIST media sanitization pressure keeps `sanitized` stronger than local deletion, miss witnesses, redaction, or proof-docket labels.
- OpenTelemetry sensitive-data guidance keeps telemetry and proof-export rows on a minimization path before export.
- W3C Data Integrity and verifiable-credential pressure shows that cryptographic proofs can make claims tamper-evident, but proof integrity is not privacy and not erasure.
- Sigstore/Rekor and transparency-log pressure shows append-only evidence improves monitoring/consistency while making metadata durable.
- in-toto attestation pressure shows verifiable claims about process are useful, but attestations become new supply-chain metadata receivers.
- AWS S3 Object Lock/versioning pressure keeps legal holds, delete markers, and noncurrent versions separate from proof-row disclosure.
- MCP/helper consent and vector/embedding pressure keep helper-safe explanations separate from helper memory authority.

Bounded local take:

Add `proof-residue-risk-board-v0.json` and `docket-disclosure-ladder-v0.json`. A forgetting proof docket is now treated as a memory object with a disclosure tier, escrow route, retention/expiry, and blocked verbs. Architecture remains blocked until operators can choose the right proof view without leaking proof rows or redacting away all challengeability.
