# Research synthesis pass CCXXVI: terminal semantic power without authority inflation

Revision: rev0229
Date: 2026-05-13
Scope: current terminal/shell/agent precedents, focused on what Schell should steal and what it must not overclaim.

## 1. Current direction of the field

The field has moved beyond the terminal as a flat text pane. Editors, terminals, shells, and agent tools now expose command zones, exit status, cwd detection, output capture, block navigation, semantic quick fixes, terminal-chat attachment, background terminal awareness, auto-approval policies, terminal resurrection, structured history, and structured pipelines.

That is a strong signal for Schell: a shell+terminal can be much more useful than a VT stream with a prompt. It is also a trap: semantic affordances are often produced by shell scripts, escape sequences, editor heuristics, app output, helper summaries, or restored state. Those sources are excellent hints but weak truth.

## 2. Things to steal

### 2.1 Command zones and navigable output

Modern editor terminals demonstrate the value of command boundaries, exit codes, command navigation, sticky command regions, command output copy, rerun affordances, recent-command pickers, quick fixes, and attaching command context to chat. Schell should steal the operator feeling: terminal work becomes an addressable sequence of chapters rather than an undifferentiated scrollback.

The Schell twist: the chapter must name the source of its boundary. A command boundary known because Schell launched the command is stronger than one emitted by the shell, which is stronger than one inferred from text.

### 2.2 Blocks as a cognitive unit

Block terminals prove that grouping command and output is a real usability gain. Copying, rerunning, sharing, bookmarking, and scrolling by block are all desirable. Schell should adopt the chapter as a cognitive unit, but avoid making the chapter a proof unit. Receipts are the proof.

### 2.3 Terminal extension protocols as negotiated affordance

Shell integration sequences and richer keyboard protocols show that terminal evolution often works through opt-in negotiation and graceful degradation. Schell should learn from this: every richer feature needs a downgraded mode and an explanation when it is absent.

### 2.4 Resurrection with gates

Session resurrection is powerful: it can serialize layouts, revive command shapes, and restore scrollback. The best lesson is not merely “save more state.” It is “restored state is not live state.” A restored command should be easy to rerun only after the operator can see which cwd/env/account/process facts are stale or unknown.

### 2.5 Contextual history as recall-to-draft

Context-aware shell history and encrypted sync are useful. Schell should make history feel like a memory palace. But synced history is not current authority. A recalled command should enter a draft/review lane when basis differs.

### 2.6 Structured data as a lens

Structured shells show how pleasant tables, records, lists, JSON, and typed pipelines can be. Schell should steal typed lenses and table affordances early. It should not freeze a universal data model before proving the chapter/receipt/downgrade model. Lens first; treaty later.

### 2.7 Plumb-like routing

Plan 9-style plumbing remains one of the most stealable ideas: route names, files, URLs, errors, and selections to the right tool using user-level rules. Schell action decks can become a modern plumb surface if every route names its source span, effect, and authority.

### 2.8 Agent terminal power ladders

Agentic terminals and coding tools increasingly separate sandboxing, approvals, auto modes, and command execution. The important Schell lesson is that permissions must be represented as product-enforced states with receipts. “The model can/cannot” is the wrong primitive; “this helper session may observe packet X, edit scope Y, run commands under policy Z” is the right primitive.

## 3. Lessons from the past that Schell must learn

### 3.1 Visible text is not launch truth

Shell expansion, quoting, redirection, variable expansion, command substitution, globbing, aliases, functions, and shell-specific parsing mean that the displayed line is often not a complete account of what will execute. Shell delegation must be labeled. Direct argv launch can be stronger, but only when Schell actually does it.

### 3.2 Terminal control streams are adversarial

A terminal is a display protocol shared with programs. Any program may print convincing-looking text. Rich marks emitted through escape sequences can improve UX, but Schell must assume app output can forge hints unless the host boundary proves otherwise.

### 3.3 Prompt return is not process truth

Foreground process, background jobs, process groups, shells, traps, hooks, and remote sessions make “the prompt is back” insufficient as durable truth. Schell needs process-ground receipts where it can get them and explicit downgrade where it cannot.

### 3.4 History is not intent

History rows are useful suggestions. They may be stale, synced from another machine, copied from another directory, or generated by a helper. History should recall to draft, not silently inherit current intent.

### 3.5 Convenience becomes unsafe when it skips review

One-click fixes, reruns, kill-port actions, package installs, and helper-generated commands are excellent when scoped and reviewed. They become dangerous when a semantic hint is promoted into authority. Consequential action cards must become reviewed command envelopes.

### 3.6 Local, browser, and provider identities drift

SlopOS's FedCM boundary is directly relevant: imported browser/account convenience is not portable account truth. A terminal may show “logged in,” “provider says,” or “helper has session,” but Schell should keep those as provider-local observations unless a durable local authority receipt exists.

## 4. Design posture for Schell

Schell should be PTY-hostile in its proofs and generous in its UX.

“PTY-hostile” means assuming terminal streams, marks, prompts, shell hooks, restored panes, and remote hops can lie or be stale. “Generous UX” means still giving users blocks, sticky headers, action cards, lenses, command search, helper packets, routing, and beautiful recovery.

The emerging shape:

- command chapters as addressable UX;
- launch/process/basis receipts as proof;
- trust-graded semantic marks as hints;
- action decks as source-bearing proposals;
- helper power ladders as receipt-bearing authority;
- downgrade witnesses as first-class UI;
- raw transcript and exact source reveal as permanent escape hatches.

## 5. Proposed theft list for future prototypes

- Command decorators, sticky command headers, and command navigation.
- Block copy/share/bookmark/rerun, but with launch and basis receipts.
- Recent-command search that recalls to draft when basis changes.
- Shell integration, but labeled as shell-signed.
- Keyboard/protocol negotiation, but no feature may require it to preserve basic truth.
- Terminal-chat attach packets, but with explicit context boundaries.
- Agent terminal awareness, but with product-enforced permissions and visible policy.
- Session resurrection, but with live/restored distinction and rerun gates.
- Structured table/JSON lenses, but raw bytes remain available.
- Plan 9-like routing, but every route has a source span and effect preview.

## 6. Current recommendation

Proceed with FT-0230 as a concrete specimen, then add FT-0231 as a downgrade/adversarial harness. Do not freeze final syntax or terminal protocol until the specimen survives no-integration, fake-marker, remote-hop, helper-adoption, paste-quarantine, and resurrection tests.
