# Research synthesis — 2026-05-18 pass CCXLII

Revision: rev0245  
Focus: delegation chains, revocation fences, and authority lineage for Schell command cards.

## Imported pressure

Current systems make delegated command work feel natural:

- OAuth token exchange supports exchanging one token for another and can express impersonation/delegation through actor/subject semantics.
- OAuth token revocation gives clients a revocation endpoint for access/refresh tokens, but revocation behavior and cascading remain authorization-server policy.
- GitHub App installation access tokens can be scoped to selected repositories and permissions, expire, and cannot exceed the app/installation grant.
- GitHub Actions OIDC moves CI cloud access away from long-lived secrets, but its safety depends on matching current claims such as audience, subject, and workflow identity to cloud trust policies.
- Kubernetes impersonation explicitly authenticates the requester first, checks impersonation privileges, and then authorizes using the impersonated subject.
- Vault dynamic secrets and service tokens have leases, renewal, TTL, and revocation; returned lease state must be inspected.
- AWS STS role chaining, SSH agent forwarding, sudo timestamp caches, Slack interaction payloads, and MCP authorization all demonstrate scoped delegation surfaces that are easy to over-narrate.

## Bounded take

Schell should steal the UX of delegation rows:

`delegation: <surface> · grant: <state> · next: <safe latch>; <effect> blocked`

Each row must expose grantor, delegate, subject/actor split, rights, target, audience, expiry, propagation policy, live grant state, revoker, and aftercare path.

## Explicit non-take

Do not treat OAuth tokens, GitHub App tokens, OIDC claims, Kubernetes impersonation, Vault leases, AWS role sessions, SSH agent sockets, sudo timestamps, Slack buttons, MCP tool lists, browser account chips, cached tokens, or redacted grant summaries as inherited shell authority.

Do not freeze a final auth runtime, token store, revocation broker, provider adapter, helper runtime, shell grammar, terminal protocol, or UI toolkit from this pass.

## Resulting proof surface

- `docs/80-terminal/delegation-chains-revocation-fences-and-authority-lineage.md`
- `docs/80-terminal/delegation-chain-board-v0.json`
- `tools/check_delegation_chain_board.py`
