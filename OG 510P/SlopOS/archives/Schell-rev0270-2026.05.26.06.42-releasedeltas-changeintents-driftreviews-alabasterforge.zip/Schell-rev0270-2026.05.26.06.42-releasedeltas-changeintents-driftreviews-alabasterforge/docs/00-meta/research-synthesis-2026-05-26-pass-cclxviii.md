# Research synthesis 2026-05-26 pass cclxviii — toolchain manifests and import drift

Schell rev0268 treats its own lint/release verifier toolchain as a retained authority surface. The package can have hashes and a safe zip envelope while the checker runner still imports a network client, resolves dependencies, shells out, or runs under an unstated local Python.

Current external pressure:

- SLSA separates provenance verification from stronger properties such as pinned dependencies, hermetic builds, complete dependency listing, and reproducible builds. Schell imports that as a reason to state runner and dependency assumptions without claiming SLSA.
- in-toto layouts name authorized steps, functionaries, materials, products, and inspections. Schell imports that as a static step/material/product analogy for tool scripts and their import surface.
- NIST SSDF frames secure environments, component provenance, vulnerability response, and risk-based improvement as software-development obligations. Schell imports this as an audit/refactor row, not a compliance claim.
- Python packaging now has pylock.toml as a standardized dependency lock format for reproducible installation. Schell currently has no external dependency manifests, so the archive records a stdlib-only/no-lock-needed claim while blocking future dependency drift without a manifest update.

Speculative pressure: if Schell later grows real code, the toolchain manifest should probably split into three lanes: static archive lints, prototype runners, and release builders. Each lane will need different import, dependency, network, filesystem, and secret budgets. For now, one stdlib-only manifest is the right friction.
