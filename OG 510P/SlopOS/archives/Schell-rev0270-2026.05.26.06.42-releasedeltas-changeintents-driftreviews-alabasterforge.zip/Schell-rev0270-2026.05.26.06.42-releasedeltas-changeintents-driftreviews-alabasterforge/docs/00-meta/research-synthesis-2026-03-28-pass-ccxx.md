# Research synthesis — 2026-03-28 pass CCXX

This pass compresses a tighter current pattern:
**the strongest modern terminal luxuries are not generic notifications or generic AI. They are exact return aids riding on honest shell integration: command guides, sticky headers, marks, semantic zones, jump-to-prompt, and explicit command-context packets.**

## 1) VS Code keeps proving that shell integration should power return, not just decoration

VS Code's terminal shell integration docs now make the return path very concrete.
The command navigation feature uses shell integration to move reliably between commands and select their output.
The command guide draws a bar beside a command and its output to help identify the chapter boundary.
And sticky scroll shows the partially offscreen command at the top of the viewport and lets the operator click that sticky component to scroll back to the command's location.

This matters because it shows that a command-aware terminal becomes dramatically easier to resume **without** inventing a whole new shell language.
The luxury comes from preserving chapter boundaries and making them navigable.

## 2) VS Code is also normalizing exact command-context handoff to helpers

VS Code 1.106 adds a context-menu action that attaches a terminal command to chat, carrying the command line, captured output, and exit code.
That same release says hidden chat terminals can be revealed and, with rich shell integration, can scroll directly to the relevant command.

The steal for Schell is not "put AI everywhere."
It is much smaller and better:
**helpers should receive explicit command-context packets rather than reconstructing events from vague transcript snippets.**

## 3) iTerm2 keeps validating marks, offscreen headers, and chapter-local notes

iTerm2's shell integration docs say the shell sends prompt boundaries, command/output boundaries, return code, username, hostname, and current directory.
When shell integration is enabled, iTerm2 adds a mark at each command prompt and can alert on the next mark so the operator can leave a long-running command and return when the prompt comes back.

Its documentation also exposes two especially good return luxuries:
- "Show offscreen command line at top of session," which shows the originating prompt when the command has scrolled above the viewport, and
- annotations, which are described as a scratchpad for notes about a chunk of terminal history.

Taken together, those features strongly support a Schell seam around offscreen chapter headers, alert-on-next-chapter, and chapter-local residue that stays weaker than transcript truth.

## 4) WezTerm keeps showing the value of semantic zones over raw scrollback guessing

WezTerm documents OSC 133 prompt, input, and output zones, and its `ScrollToPrompt` action moves to the previous or next prompt zone.
It also documents selection by `SemanticZone`, making it possible to select a complete input or output region rather than dragging through raw scrollback.

This matters because it points to a better floor for copy, compare, export, and helper escalation.
The operator often wants **the exact chapter slice**, not a fuzzy viewport guess.

## 5) Ghostty reinforces that richer return comfort should remain shell-integration-powered

Ghostty 1.3 adds command-finished notifications with focus and duration controls, but it explicitly says the feature requires shell integration or a shell that emits OSC 133 natively.
That is the right humility line.
A luxury return path is strongest when the shell keeps telling the terminal the truth about chapters and prompt state.

## 6) The lesson from the past is “don’t make users reconstruct locus from vibes”

Classic terminal pain is not just lack of polish.
It is the constant loss of locus:
- which command produced this output,
- where did the failure start,
- what finished while I was away,
- what exact chunk should I share with a helper,
- and what am I resuming right now?

Current official docs keep converging on the same answer:
make chapters explicit, preserve prompt/output boundaries, and offer resume aids that jump back to exact context.

## 7) Compact conclusion

The best near-term steals are now quite specific:
- sticky or offscreen command headers,
- chapter-local marks and jump navigation,
- alert-on-next-chapter rather than ambient bells,
- semantic-zone selection for exact input/output slices,
- and helper handoff packets that preserve command, output, and exit status.

So the next Schell proof should probably not be a giant inbox or assistant runtime.
It should be a **return-hygiene specimen bundle** built on exact command chapters and explicit resume paths.
