# SlopOS datacube evaluation pass CCXLIV — residue tombstones for Schell

SlopOS remains the right companion pressure for Schell because it refuses to let imported auth, browser, tool, account, and hot-action claims widen existing seams by accident.

Rev0247 maps that discipline onto terminal residue:

- `D-LEASE` / `CH-CAPLEASE` teach Schell that a live proxy and a carried capability descriptor are different; a dead grant tombstone is not authority to keep acting.
- `auth-teardown` teaches that logout, disconnect, revoke, and unlink are provider-local lifecycle events unless a current recipient witness proves a broader cascade.
- `namecert` no-implied-redelegation teaches that a dead or tombstoned delegation cannot silently authorize child cleanup or onward sweeps.
- FedCM/MCP/OpenURI/ACP/Capshell/Hot-action boundaries teach that browser account chips, tool task state, URI handlers, policy acceptance, shell capsule text, and hot actions stay scoped.

The new residue board should help Schell avoid a common shell/terminal failure: closing the visible surface and narrating everything underneath as gone. In SlopOS terms, that would be a boundary leak from evidence into authority and from local teardown into global settlement.

The next proof should run RT-PF-01 through RT-PF-08 over RT-0001 through RT-0024 and record whether the compact `death/residue/next` lines are enough to predict safe sweeps and blocked effects.
