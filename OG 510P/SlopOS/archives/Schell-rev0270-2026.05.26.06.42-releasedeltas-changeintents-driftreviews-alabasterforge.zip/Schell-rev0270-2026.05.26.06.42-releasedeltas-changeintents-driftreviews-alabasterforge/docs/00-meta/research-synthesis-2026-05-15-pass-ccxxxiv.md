# Research synthesis pass CCXXXIV: settlement clocks, drift windows, and effect-key honesty

Revision: rev0237  
Date: 2026-05-15  
Scope: current terminal/shell/agent precedents viewed through the question “what remains safe after time moves?”

## 1. Field signal

The outside field keeps making terminal work more object-like and resumable: command guides, sticky command headers, semantic zones, contextual shell history, resurrected panes, quick fixes, helper hooks, sandbox policies, tool catalogs, and terminal-chat packets.

The missing counterweight is temporal honesty. If the object survives longer than the state it summarizes, the terminal needs a freshness model.

## 2. Updated observations

### 2.1 Semantic command objects need separate freshness channels

Command detection, prompt/input/output zones, sticky headers, and command recall are excellent raw material. Schell should steal them. But a command object has at least two clocks: evidence freshness and spend freshness. It may remain useful for reading while its process, cwd, account, network lease, helper policy, or effect-key window has expired.

### 2.2 Resurrection and history need rerun humility

Resurrection gates and contextual history are valuable because they preserve work. They are dangerous when old command text looks like a current action. Schell's rule should be: restored/history cards may draft and compare by default; rerun is a fresh launch spend.

### 2.3 Agent permissions are temporal too

Sandbox and approval posture can change during a session. Hook output, tool catalogs, auto modes, and MCP metadata must be tied to a policy epoch and exact effect envelope. Old approval under one policy epoch does not silently authorize a broader current policy.

### 2.4 Settlement is a first-class terminal object

Timeout, disconnect, notification return, old green test lamp, and “undo available” are not final truth. They are settlement states requiring receipts: current-through cuts, provider status probes, effect keys, postcondition witnesses, rollback preconditions, and target-generation checks.

## 3. Lessons we must keep learning from the past

1. Wall-clock time is not monotonic freshness.
2. A pid is not a process epoch.
3. A pane is not a process identity.
4. A path label is not a current target.
5. A history hit is not rerun permission.
6. A network lease descriptor is not current live grant state.
7. A source account chip is not recipient authority.
8. A timeout is not failure proof.
9. An idempotency key is not forever.
10. An undo label is not rollback authority.
11. A watcher green lamp is not current-through proof.
12. A notification return is not approval.

## 4. Brilliant ideas to steal, with fences

- Steal sticky command headers, but show stale axis and current-through cut before effect buttons.
- Steal shell history sync, but show source timezone, cwd, exit, duration, and basis before rerun.
- Steal session resurrection, but keep resurrected commands behind review/enter gates and route/basis comparison.
- Steal helper hooks, but bind them to policy epoch and never let hook allow outrank product deny.
- Steal sandbox/approval modes, but show network/filesystem/secret policy as current receipts, not labels.
- Steal MCP-style tool catalogs, but treat tool metadata and auth context as source-local until reviewed.
- Steal beautiful retry/rollback affordances, but make effect-key windows and postcondition drift visible.

## 5. Recommendation

Before Schell designs a live semantic terminal protocol, run the SF-01 through SF-05 settlement-freshness drill over `settlement-clock-ledger-v0.json`. If operators cannot tell which clock/epoch is stale, which action remains safe, and which receipt unlocks review, reduce the vocabulary.
