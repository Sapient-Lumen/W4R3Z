# Research synthesis 2026-05-21 pass ccxlix — negative proof drift and preservation holds

This pass imports a narrow pressure: cleanup evidence decays. A deletion/miss witness must be versioned, receiver-scoped, and contestable. It may also be legitimately blocked by preservation holds or audit requirements without becoming permission to use the retained memory.

External pressure folded into rev0252:

- NIST SP 800-88 Rev.2 frames sanitization as making access to target data infeasible for a given level of effort; Schell therefore keeps local row absence, exact lookup miss, and receiver acknowledgement below sanitization/erasure language.
- OpenTelemetry's sensitive-data guidance emphasizes minimization and implementer responsibility; Schell therefore treats collector redaction as epoch-bounded and not retroactive to old exports.
- AWS S3 Object Lock legal hold language pressures Schell to represent deletion denial under a named hold, separate from permission to expose or reuse held data.
- GitHub Actions retention settings pressure Schell to track object birth epoch, artifact/log/cache receiver distinctions, and policy non-retroactivity.
- Kubernetes TTL-after-finished pressure keeps controller cleanup, deletion pending/finalizer state, and external logs distinct.
- OWASP LLM08 and MCP security guidance keep vector/helper influence and delegated consent as live contest routes even when raw rows or consent cards are gone.

Imported design rule:

```text
negative proof needs a recheck window and a contradiction route; preservation needs use quarantine.
```

Non-imports: no legal advice, provider APIs, compliance certification, deletion adapter, vector rebuild runtime, cloud controller, clipboard/browser cleaner, or final UI grammar.
