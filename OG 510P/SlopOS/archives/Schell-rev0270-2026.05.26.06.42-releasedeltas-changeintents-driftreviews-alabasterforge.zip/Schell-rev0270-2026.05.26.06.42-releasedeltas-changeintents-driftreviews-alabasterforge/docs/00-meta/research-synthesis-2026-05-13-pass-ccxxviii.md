# Research synthesis pass CCXXVIII: human-proof semantic terminals and escape seams

Revision: rev0231
Date: 2026-05-13
Scope: current terminal/shell/agent precedents viewed through the question “can the operator understand the downgrade before acting?”

## 1. Field signal

The external field is no longer merely making terminals prettier. It is making terminal work object-like: command guides, sticky command headers, command-output packets in chat, recent-command palettes, command blocks, contextual history, resurrected panes, structured data, prompt navigation, richer key protocols, terminal hyperlinks, clipboard escape sequences, and helper auto-modes.

The danger is equally object-like: once a surface looks like an object, users may treat it as authoritative. A command block, hyperlink, prompt mark, helper packet, restored pane, or permission badge can feel like a receipt even when it is only a projection, app-emitted byte range, memory, or product-local policy.

Rev0231 therefore moves from “the harness has fixtures” to “the operator must be able to answer the five questions.”

## 2. Updated research observations

### 2.1 Shell integration gives excellent command navigation

VS Code documents command guides, sticky scroll, quick fixes, run-recent-command flows, output attachment, and terminal-chat details. WezTerm documents OSC 7 / OSC 133 / OSC 1337 shell integration for cwd, prompt/input/output zones, and additional shell state. Contour documents OSC 133 A/B/C/D as prompt start, prompt end, command output start, and command finished. tmux now even has prompt navigation that depends on shell-emitted OSC 133 marks.

Schell should steal the navigability. The comprehension rule is that every mark needs authorship and grade.

### 2.2 Blocks and history prove the cognitive unit

Warp’s blocks show the UX value of copy command, copy output, re-input, share, and bookmark. Atuin shows the value of contextual command records: cwd, exit code, duration, host, user, and session. Nushell shows the value of structured tables and typed data.

Schell should steal the unit and the context. The comprehension rule is that block, history row, and structured lens are not launch truth unless a stronger receipt exists.

### 2.3 Resurrection and reconnect need inert gates

Zellij’s resurrection posture remains one of the strongest lessons: restored commands are not immediately run; they are gated behind an explicit Enter banner to avoid dangerous accidents. Mux/reconnect tools can restore a visible terminal state without proving the underlying process or environment is identical.

Schell should steal restore/resume comfort. The comprehension rule is restore, resume, rerun, and relaunch remain different verbs.

### 2.4 Terminal protocols improve fidelity but add downgrade seams

Kitty’s keyboard protocol uses progressive enhancement and explicit support detection. iTerm2 documents OSC 52 clipboard read/write with user consent and OSC 8 hyperlinks that can carry targets separate from visible text. tmux passthrough shows that nested terminal realities can pass, suppress, or transform escape sequences.

Schell should steal negotiated input/render/clipboard/link comfort. The comprehension rule is feature negotiation and escape egress need visible source, policy, and fallback posture.

### 2.5 Agent permissions are moving from prompts to policy

Claude Code documents permission rules where deny, ask, and allow are enforced by the product rather than the model, and its auto mode uses a separate classifier but explicitly remains a research preview that reduces prompts without guaranteeing safety. MCP security guidance stresses that sessions should not be treated as authentication and that asynchronous/resumable server events can create session-hijack or injected-tool risks. OWASP still recommends avoiding direct OS command calls where possible because command injection remains a preventable class of vulnerability.

Schell should steal reduced prompt fatigue and tool-rich workflows. The comprehension rule is helper policy, sandbox, action target, and exact command/API effect need receipts.

## 3. Deep lessons from the past

1. **A terminal is a programmable display, not a trusted data bus.** Escape sequences are useful because they affect the emulator; that is why they require source custody.
2. **A shell line is not an argv receipt.** Shell parsing, expansion, aliases, functions, hooks, and redirections mean pretty text is not final process truth.
3. **A prompt is not process completion.** Jobs, daemons, subshells, remotes, and muxes can make prompt return a weak signal.
4. **A restored pane is not a living process.** Memory must be useful but inert until reviewed.
5. **A helper policy is not model virtue.** Product-enforced permissions need visibility and epochs.
6. **A projection is not evidence.** Filtered output, structured lenses, hyperlinks, and shared blocks need raw reveal.

## 4. What Schell should steal next

- Command chapter cards with source-grade chips.
- Sticky headers whose confidence matches boundary proof.
- Action cards with source span, effect preview, risk floor, and spend target.
- Context packets for helpers that are named, minimal, and revealable.
- History/rerun palettes that recall to draft by default under basis mismatch.
- Structured lenses for JSON/tables/test output with coverage labels.
- Clipboard/link/export receipts for egress.
- Policy epoch strips for helper auto-approval.
- Hop-lineage strips for mux/remote/container seams.
- Four-card prototype before a real terminal UI.

## 5. Recommendation

Promote FT-0232 into a machine-checkable operator-comprehension scorecard and open FT-0233 for a four-card prototype. Do not freeze final shell syntax, terminal protocol, helper runtime, typed pipeline treaty, UI toolkit, or account/session model until the four cards survive the scorecard.
