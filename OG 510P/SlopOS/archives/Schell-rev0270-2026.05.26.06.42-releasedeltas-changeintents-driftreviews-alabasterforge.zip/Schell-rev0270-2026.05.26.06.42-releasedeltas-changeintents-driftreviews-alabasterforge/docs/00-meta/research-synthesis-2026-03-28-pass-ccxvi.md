# Research synthesis — 2026-03-28 — pass CCXVI

This pass pulls one tighter lesson out of the current terminal/shell field:
**the highest-leverage design-phase move for Schell is to prove a specimen bundle on top of a tiny interoperable semantic-marks floor, rather than freezing a bespoke shell language or smart-terminal treaty now.**

## 1) Command-aware semantic marks keep winning because they unlock many luxuries at once

Current terminal docs keep converging on prompt/input/output/cwd signaling.
VS Code uses shell integration for sticky scroll, run-recent-command, go-to-recent-directory, better cwd-aware link resolution, and explicit command detection with anti-spoofing support. kitty, WezTerm, Ghostty, iTerm2, and Contour all keep building on prompt marks and cwd reporting for prompt jumps, output selection, cursor clicks, output paging, working-directory inheritance, notifications, or remote-aware comfort.

The research lesson is not “adopt terminal X.”
It is:
- command-aware chaptering is a proven high-value luxury seam,
- shell-authored semantic marks are an unusually small and interoperable power source,
- and prompt/input/output/cwd truth is enough to unlock a surprising amount of terminal delight.

## 2) Humane input editing is still a no-regret steal

fish remains a reminder that shells get much better with humane editing:
- autosuggestions that stay inert until accepted,
- word-wise acceptance/navigation,
- external-editor round trips,
- and undo/redo in the command-line editor.

These are powerful because they improve the operator's life without forcing a universal object shell or hidden auto-run architecture.
Schell should steal this class aggressively.

## 3) Structured-data shells prove demand for lenses and selectors

Nushell and PowerShell keep proving that people want field/row/property selection, nested-data traversal, and object/value reuse.
YSH contributes a subtler lesson: command language and expression language can remain neighboring lanes rather than one flattened thing.

That suggests a safe Schell compression:
- keep exact command chapters authoritative,
- admit structured value work where structure is earned,
- and expose field/cell/property optics without declaring a universal object constitution yet.

## 4) Workflow docs are best when they stay inspectable and insertable

Warp workflows and command search show the usefulness of searchable saved commands, argument slots, enum suggestions, and unified retrieval across history/workflows/notebooks. Warp's workflow execution path importantly pastes the workflow into the active input editor so the operator can adjust it before running.
VS Code prompt files show another important split: reusable prompt artifacts are stored as ordinary files and manually invoked rather than applied automatically.

The combined lesson is strong:
- saved workflow knowledge is great,
- file-backed or repo-backed helper artifacts are great,
- but design-phase default power should remain insert-first/manual-invoke/review-first.

## 5) Restore should be context resurrection, not command resurrection by default

Zellij's session resurrection is especially instructive because it restores layout and command context while still placing resurrected commands behind an explicit “Press ENTER to run...” gate.
That is a terrific model for Schell:
be outstanding at returning operators to the right room, chapter, and footing — while still refusing the lie that restored context equals fresh execution truth.

## 6) Small visible modes beat hidden intelligence

Ghostty's active key-table indicators, prompt-click support, finish notifications, and working-directory inheritance controls reinforce a broader design lesson.
Modeful local power becomes easier to trust when the mode is visible, scoped, and obviously local.
That same lesson applies to Schell's future resize/select/filter/assist/help modes.

## 7) The protocol lesson is layered, not maximalist

The field is now rich enough to support a clearer protocol stance:
- an **exact command lane** should remain transcript-safe and authoritative;
- a small **semantic marks + cwd floor** should stay as interoperable as practical;
- richer **typed sidecars/value lenses** should remain optional and inspectable;
- workflow, notebook, prompt, and skill artifacts should remain explicit helper lanes;
- any stronger private protocol should be justified only after the specimen bundle proves a real gap.

## 8) Compact conclusion

Current official docs do not point toward one inevitable “future shell.”
They point toward a much smaller, better next move for Schell:
- prove one specimen bundle,
- use semantic prompt/cwd marks as the interop floor,
- steal humane editing and chapter navigation aggressively,
- keep structured values in explicit lenses/sidecars,
- keep workflow and AI help insert-first/manual-first,
- and keep restored context visibly weaker than fresh reviewed execution truth.
