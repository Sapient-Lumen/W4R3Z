# SlopOS datacube evaluation — pass CCXXI

This pass asks a narrower companion question:
**if SlopOS keeps punishing hidden authority and hidden memory, what should Schell steal for helper-rich shell ergonomics without letting helpers become an ambient second shell?**

## 1) SlopOS keeps saying that audience lanes and hidden context are not authority

The newest SlopOS companion pressure is especially relevant here.
Its tool-result visibility boundary says model-visible content and component-only `_meta` are audience lanes, not authority lanes.
Its rendered-tool-UI boundaries keep widget state and widget-originated model-context updates proposal-only rather than hidden durable truth.
And its MCP-sampling boundary refuses to let nested provider-local model calls become a portable hidden planner or background-autonomy plane.

That cluster of boundaries maps almost directly onto Schell helper rooms.
A helper may hold context.
A helper room may have hidden local notes.
A rendered helper panel may hydrate from extra bytes.
None of that should silently become approval, evidence, spend, or durable shell truth.

## 2) The safest shell answer is attach-only helper context

Given that pressure, Schell's companion-safe move is not “the assistant watches your terminal.”
It is:
- attach this exact chapter,
- attach this output slice,
- attach this failure packet,
- attach this filtered compare card,
- reveal which room is holding it,
- and preserve the path back to source truth.

That matches SlopOS very well.
The helper context exists, but it is explicit and reviewable.

## 3) Hidden rooms should behave like bounded leases, not immortal ghosts

SlopOS repeatedly prefers bounded, killable, policy-owned surfaces over ambient daemons and hidden forever-state.
The companion cubes reinforce the same lesson:
- **Steward** keeps lifecycle and shutdown/drain posture explicit,
- **Helm** keeps previews and warrants weaker than enactment,
- **ViewFS** keeps payer and spend rails explicit,
- **Harbor** keeps cache/summary residue weaker than exact footing,
- and **Foundry** keeps scalarization and caveat holds visible.

So hidden helper rooms in Schell should behave like bounded rooms with manifest truth:
- what they hold,
- whether they are waiting, failed, stale, or partial,
- whether their context is filtered or historical,
- when they should drain or expire,
- and which stronger actions still require return to reviewed shell truth.

## 4) Filtered slices and helper summaries must stay visibly weaker than evidence

One of the easiest future mistakes would be to let helper-produced summaries or block filters quietly replace the original chapter in operator memory.
SlopOS's posture says not to do that.
A filtered slice or helper summary is still descriptive residue.
The stronger object is still the exact command chapter and its exact receipt/output basis.

That is the same discipline SlopOS uses elsewhere:
current mutable truth stays stronger than imports, summaries, caches, or proposal-only context.

## 5) What Schell can safely steal now

Given SlopOS's current design phase, the safest steals now look like this:
- attach-only helper evidence packets,
- hidden-room manifests with reveal/resume/discard verbs,
- chapter-local filtering and annotation that preserve source paths,
- explicit room-held-context badges,
- and background-output objects that admit partial provenance.

These are high-value because they make helpers better without forcing a final assistant constitution.

## 6) What still should not be decided yet

SlopOS is still too early to justify freezing:
- one final assistant-room lifecycle protocol,
- one final helper memory model,
- one final packet-sharing/sync architecture,
- one final hidden-terminal policy,
- or one final provider-to-helper context treaty.

Schell should keep proving the smaller seams first.

## 7) Compact conclusion

SlopOS does not yet tell Schell what the final assistant-rich shell must be.
It does tell Schell something precise about the next safer move:
**make helper context explicitly attached, make hidden rooms explicitly revealable, and keep every filtered or summarized helper view weaker than exact shell evidence.**
