# SlopOS datacube evaluation pass CCXXXIV: stale evidence is not live authority

Revision: rev0237  
Date: 2026-05-15  
Context: Schell rev0237, SlopOS rev0695, companion cubes retained as pressure sources.

## 1. What SlopOS teaches this pass

The most useful SlopOS lesson for rev0237 is the lease-descriptor boundary: an issued descriptor is exact issuance evidence, not a current live grant oracle. Schell should apply that lesson to every terminal card that outlives the state it describes.

A command chapter can carry excellent evidence and still be too stale to run. That split is the heart of the settlement clock ledger.

## 2. FedCM/account pressure

SlopOS rev0695's FedCM boundary keeps provider account lists, login status, chooser UI, connected accounts, tokens, and disconnect choreography provider-local. Schell's account chips should behave the same way. A source card may explain that `alice@example.com` was involved upstream, but recipient send/open/reauth actions still need recipient-basis proof.

## 3. Capshell pressure

Capshell keeps launch descriptors, cwd/env/argv, result sidecars, network posture, and effect evidence separate. Schell's footer should therefore distinguish:

- historical command evidence;
- current launch authority;
- current network/secret/account lease;
- settlement evidence;
- retry/rollback effect-key status.

Complete old evidence can support compare and drafting. It does not automatically support rerun.

## 4. MCP and helper pressure

SlopOS's MCP import boundary family is full of “metadata is not authority” cuts: progress, auth discovery, tokens, tool resources, prompts, and task context stay imported evidence until explicit validators bind them. Schell's helper policy epochs and tool-catalog diffs are the terminal-scale equivalent.

## 5. Companion-cube pressure

- **Steward**: timeout, retry, settlement, aftercare, and rollback must remain different states.
- **Harbor**: custody and lineage survive transfer only if the packet names what was preserved and what was lost.
- **ViewFS**: path actions need route/locality/target-generation witnesses.
- **Foundry**: rich projections need raw reveal and transform receipts, not screenshot authority.
- **Helm**: quick fixes belong in review queues until their floors are current.
- **Ward**: witness tiers should not collapse into one green trust color.

## 6. Recommendation

Keep the SlopOS pattern small and tactile in Schell: old cards are evidence, not live authority. Let read/draft/compare be fast; make current spend floors explicit for every action that launches, opens, patches, sends, retries, rolls back, reauths, merges, or pushes.
