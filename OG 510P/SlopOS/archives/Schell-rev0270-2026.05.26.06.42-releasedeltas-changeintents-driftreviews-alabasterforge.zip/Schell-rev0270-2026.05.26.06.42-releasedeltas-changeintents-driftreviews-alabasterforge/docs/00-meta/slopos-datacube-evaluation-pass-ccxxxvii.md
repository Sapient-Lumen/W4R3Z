# SlopOS datacube evaluation — pass CCXXXVII

Revision: rev0240  
Theme: Schell post-spend settlement through SlopOS outcome boundaries

## SlopOS pressure imported

SlopOS rev0695 is still design-phase, but its outcome surfaces are unusually relevant to Schell now:

- **ACP outcome receipts** distinguish accept/reject/error and applied/no-op/duplicate-suppressed metadata while warning that receipts are non-authoritative and do not prove downstream asynchronous completion.
- **OpenURI launch-completion boundaries** say launch admission is not target app lifecycle, rendering, user attention, or downstream completion truth.
- **FedCM import boundaries** keep login status, account lists, disconnects, returned tokens, and provider/browser choreography provider-local.
- **MCP boundaries** keep tool/resource metadata, authorization context, progress, prompts, sampling, token exchange, and exact redirect mechanics from becoming portable authority without current validators and receipts.
- **Hot-action boundaries** make non-commutative ordering and conflict receipts explicit instead of hiding them behind smooth action verbs.

## Evaluation of Schell after rev0239

Rev0239 correctly prevents evidence-to-action collapse. But once a promotion spends, the next temptation is equally dangerous: treating spend, prompt return, provider admission, notification, hook result, or helper summary as settlement.

Rev0240 adds the missing board. This is faithful to SlopOS because it treats post-spend state as evidence with scoped meaning, not as authority or universal truth.

## New Schell rule borrowed from SlopOS

A spend receipt is the shell+terminal analogue of an ACP/OpenURI/FedCM/MCP boundary receipt:

> it proves exactly the boundary it names, and nothing downstream unless a separate current witness says so.

Therefore Schell should expose **settle / rollback / next** lines after every effectful promotion that remains pending, partial, unknown, duplicated, compensated, or externally uncertain.

## Still deferred

Schell should not adopt SlopOS schema families wholesale yet. The correct next move is a PS-PF prediction drill over the settlement board, then a vocabulary cut if operators cannot distinguish accepted, pending, applied, partial, unknown, duplicate-suppressed, compensated, and impossible-rollback cases from compact cues.
