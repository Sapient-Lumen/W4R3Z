# Research synthesis — 2026-03-25 — pass CCV

This pass sharpens the next compact lesson from current official chooser, document, sandbox, and terminal docs:
**the smartest next move for Schell is not a bigger “open” story. It is a smaller access-after-open story: keep launch route, grant kind, scope width, duration, persistence, and renewal/re-ask posture visibly separate, because current platforms already distinguish them.**

## 1) Current file and chooser systems already split transient transfer from durable access

XDG now makes the distinction unusually explicit.
The FileChooser portal says selected files are made accessible to the app and may be added to the Documents portal, and files added this way stay accessible across sessions.
The FileTransfer portal, by contrast, is a middle-man for copy-paste or drag-and-drop, exports files in the Documents portal as needed, and explicitly says files added that way do **not** stay accessible across sessions.
The lesson is straightforward: **transfer once**, **durable access**, and **plain launch** are neighboring truths, not one thing.

## 2) Controlled synthetic views are a better mental model than ambient paths

The XDG Documents portal gives another excellent clue.
It exposes outside files to sandboxed apps through a restricted FUSE-mounted document view, and the per-application permissions for an entry are reflected in that view.
That is a strong precedent for Schell.
A shell+terminal should prefer explicit object-local grant posture over ambient path folklore.
The terminal does not need to know every backend detail; it just needs one honest badge that says whether this object is a transient transfer, a reusable persisted grant, or only an imported copy.

## 3) Android strongly rewards least-widening chooser design

Android’s Storage Access Framework and Photo Picker are especially instructive.
`ACTION_OPEN_DOCUMENT` lets the user choose one document, `ACTION_OPEN_DOCUMENT_TREE` grants access to a selected directory tree only, and the docs emphasize that the app gains access only to the selected tree, not everything outside it.
The Photo Picker goes even further: it provides a built-in way to grant access to only selected images and videos instead of the entire media library, and it lets the caller narrow by single item, multiple items, media type, or specific MIME type.
That is a huge design gift.
Schell should steal the **least-widening chooser ladder** instead of jumping straight to broad file or library grants.

## 4) Persistence is a separate step and still needs renewal honesty

Android also shows the second half of the truth.
A URI permission grant from SAF lasts until device restart, and the app can explicitly call `takePersistableUriPermission()` to preserve access across restarts.
But the docs immediately add a caution: even after taking a persistable permission, the app does not retain access if the document is moved or deleted and must ask again.
That is exactly the kind of humility Schell should steal.
Persistent-looking access is useful, but it still needs a visible `renewable` or `re-ask required` floor.

## 5) Apple keeps user selection, persistent bookmarks, and child-process propagation separate

Apple’s sandbox guidance lines up with the same pattern.
The archived entitlement reference distinguishes user-selected file access from security-scoped bookmark access; it says persistent access requires security-scoped bookmark and URL access, while user-selected file access is its own entitlement family.
The file-system guide also says sandboxed apps can use standard Open and Save panels because those panels work with the security layer to allow exceptions outside the sandbox.
And Apple explicitly warns that child-process inheritance covers static sandbox rights only, not file access added after launch through PowerBox; if post-launch file access is needed, the app must pass the data or pass a bookmark to the child process.
So current access, durable access, and helper propagation are already separate truths in a major desktop ecosystem.

## 6) Shell-aware terminals are best when they stage objects before claiming authority

The terminal side of the ecosystem points in the same direction.
VS Code shell integration and terminal basics show how much value can come from exact object detection, quick fixes, and detected-link pickers while still keeping richer actions explicit.
That is the right order for Schell too:
1. identify the exact object,
2. choose the route,
3. then keep any resulting access badge visibly weaker than the object identity itself.

## 7) Compact conclusion

The ecosystem is pushing Schell toward one very good next seam:
- add object-local **grant shelves**,
- show **scope width** and **duration** separately,
- offer explicit **keep this around** upgrades after success,
- show `renewable` / `re-ask required` / `import instead` floors,
- and keep helper propagation visibly separate from parent access.

That is enough to make the shell feel unusually sharp while still deferring the final bookmark/docref substrate, grant wallet, persistence database, and cross-process propagation architecture.
