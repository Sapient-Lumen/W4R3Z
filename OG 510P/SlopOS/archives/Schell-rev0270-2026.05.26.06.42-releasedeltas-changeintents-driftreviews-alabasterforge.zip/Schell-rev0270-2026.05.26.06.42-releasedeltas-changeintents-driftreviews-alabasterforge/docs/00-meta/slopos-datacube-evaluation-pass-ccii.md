# SlopOS datacube evaluation — 2026-03-25 — pass CCII

**Schell should let command chapters own rich local objects, bounded detector summons, and mediated open ladders, because SlopOS keeps rewarding exact basis, provider-local humility, one-way open semantics, and refusal to let convenient projections silently become substrate authority.**

## 1) SlopOS OpenURI boundaries strongly constrain what “open this” may honestly mean

The biggest companion pressure in this pass comes from SlopOS’s OpenURI family.
SlopOS keeps the following meanings explicitly separate:
- handler choice,
- activation/focus control,
- callback reentry,
- launch completion truth,
- recent-item/history effects,
- subject echo/logging,
- materialization,
- resource grant transfer,
- request shaping,
- speculative loading,
- session/profile selection,
- launch disposition,
- embedded web surface,
- preview metadata,
- and content extraction.

That is exactly the lesson Schell should import.
A selected URL, path, or chapter-local object in the terminal should not silently collapse those meanings into one flattering “smart open.”

## 2) capshell exactness argues for chapter-owned objects over ambient screen folklore

SlopOS capshell posture keeps refusing ambient PATH truth, shebang-as-authority, cwd-text folklore, and inherited startup/session residue.
That is companion pressure for Schell to route rich action through chapter-owned objects with exact footing whenever possible.
A path, file-line, port, or link object is much safer when tied to one exact chapter and one explicit witness than when recovered from ambient scrollback mythology.

## 3) Steward and ViewFS sharpen the neighboring-state rule

Steward keeps reminding us that injection, execution, history, and proof are different lanes.
ViewFS keeps reminding us that current live binding, imported material, local overlays, and receipts/history are neighboring states, not one truth.
That combination is almost a direct specification for Schell here:
- selected visible object,
- detector hit,
- reviewed action bundle,
- mediated open witness,
- and later durable receipt/history
should stay neighboring states instead of collapsing into one generic action chip.

## 4) Harbor, Ward, Helm, and Foundry keep the route honest

- **Harbor** keeps label honesty and trusted-audience posture in scope, which matters when Schell should say shell-authenticated, inferred, restored, explicit-link, provider-local, or inspect-only rather than one flattering click target.
- **Ward** keeps freshness and revalidation pressure alive, which matters when a detector hit or open target came from stale footing.
- **Helm** keeps preview-versus-enactment honesty alive, which matters when hover, preview, or quick-fix explanation has not yet earned enactment.
- **Foundry** keeps residue class and apportionment-fence thinking alive, which matters when detector results or open routes combine shell truth, terminal inference, historical residue, and provider-local policy.

## 5) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- a final browser or embedded-web plane,
- a final detector DSL,
- a final command palette/search architecture,
- a final quick-fix persistence strategy,
- or a final object-card schema.

It only earns a smaller companion rule:
**chapter-local exactness first; summoned detection second; mediated open third; no ambient browser or trigger authority.**
