# Research synthesis pass CCXXIX: evidence dockets, terminal objects, and agent authority floors

Revision: rev0232  
Date: 2026-05-13  
Scope: current terminal/shell/agent precedents viewed through the question “what tiny evidence object must sit behind a beautiful command card?”

## 1. Field signal

The field keeps pushing terminal work from byte stream toward object surface. VS Code shell integration uses command guides, sticky scroll, quick fixes, recent command recall, and terminal-chat context. WezTerm and Contour document OSC 7/133/1337-style shell integration for cwd, prompt/input/output zones, and user variables. Kitty's keyboard protocol shows negotiated progressive enhancement. iTerm2 and related terminal docs show OSC 8 hyperlinks and OSC 52 clipboard surfaces. Roo Code and similar agents treat terminal integration as a bidirectional automation channel. Agent tools now use sandbox/approval/policy layers to make helpers act with less operator interruption.

The shared lesson is not “make Schell a fancier terminal.” The shared lesson is “terminal work is becoming an object with actions.” Once work becomes an object, the object needs evidence custody.

## 2. Updated research observations

### 2.1 Shell integration is a great serving lane

Command guides, sticky headers, scroll-to-prompt, command output selection, cwd inheritance, quick fixes, and terminal-chat packets are compelling. Schell should steal these aggressively. They make a strict shell humane.

The bounded take is that shell integration should serve chapter navigation, not define host truth. Prompt/input/output marks need authorship chips and downgrade paths because they can be app-emitted, missing, nested, mux-translated, restored, or stripped.

### 2.2 Terminal protocols are negotiated effect surfaces

OSC hyperlinks, clipboard sequences, keyboard enhancements, notifications, feature reporting, and scheme handlers show a powerful terminal as a negotiated effect machine. The protocol might render correctly while still being untrusted as evidence. That distinction matters for Schell: render support is not launch proof, operator intent, or authority grant.

Rev0232 therefore puts protocol effects into evidence dockets as signal authorship, egress posture, and raw reveal rows.

### 2.3 Agent terminals make hidden work normal

Agents increasingly run commands, read output, modify files, call tools, attach context, summarize terminal results, and reduce prompts through policies or classifiers. This is desirable; otherwise the user is trapped babysitting a terminal. But a shell+terminal built for this world must expose helper identity, policy epoch, sandbox boundary, tool catalog identity, loaded context packets, and exact command/API envelopes.

The bounded take is not “prompt for everything.” It is “make the action floor and policy receipt visible.”

### 2.4 Objects need export integrity

Command blocks, summaries, shared snippets, copied terminal sessions, and helper packets are all exports. Exports are useful only if the recipient can tell whether raw evidence traveled with the projection. Rev0232 adds export-integrity fixtures because a beautiful shared block can become misinformation if the receipt link is cut.

## 3. Deep lessons from the past

1. **Terminals are display devices with side effects.** That is why they are powerful and why escape effects need custody.
2. **Shells are parsing and expansion machines.** Pretty text is not final argv.
3. **Muxes and remotes create multiple truths.** There is no one pane-sized universe.
4. **History is not liveness.** Restored output and synced history are memory until refreshed.
5. **Helpers are actors.** Their proposals, commands, summaries, and tool calls need authorship and policy receipts.
6. **Export breaks locality.** Once a chapter is shared, filtered, copied, or handed to a helper, the evidence path matters as much as the projection.

## 4. What Schell should steal next

- Command cards with one-line confidence headers.
- Evidence dockets with six rows: launch/event, signal authorship, basis/locality, coverage, authority spend, raw reveal.
- Protocol-effect chips for OSC 8, OSC 52, keyboard negotiation, notifications, and scheme handlers.
- Helper lane cards with policy epoch, sandbox, tool identity, context packet manifest, and exact effect envelope.
- Route choosers for remote/local path ambiguity.
- Export receipts that say whether raw reveal links survived.
- Verbs that lower authority instead of merely warning: preview, choose route, recall to draft, refresh basis, show bytes, review envelope.

## 5. Recommendation

Treat the four-card JSON prototype as a static specimen that earns a visual/local prototype, not as final design. The next pass should render the cards and run a human comprehension test before adding a real terminal, final protocol, helper runtime, or typed pipeline treaty.
