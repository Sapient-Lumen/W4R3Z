# SlopOS datacube evaluation — pass CCXX

This pass asks a narrower companion question:
**if SlopOS treats attention as scarce, budgeted, and weaker than durable state truth, what should Schell steal for a shell+terminal that wants to feel amazing without becoming noisy or presumptuous?**

## 1) SlopOS is already telling us that attention is not authority

SlopOS RFC-0055 on attention and notifications is the clearest companion pressure for this seam.
It says notifications should go through a portal, stay origin-branded and budgeted, and route actions back through the trusted UI path.
It also explicitly says transient attention is not durable outcome truth.

That is a very strong lesson for Schell.
A desktop notification, tab flash, mark alert, or helper ping may help the operator return.
It must not by itself count as completion proof, acknowledgement, or approval.

## 2) The companion-safe answer is chapter-bound return hygiene

Because SlopOS already wants attention bounded and auditable, Schell's safest luxury is not one giant notification center.
It is a better way back to the exact thing that mattered.

Companion-safe return posture probably means:
- alerts bind to exact chapters, rooms, or checkpoints,
- alerts redeem into focus/reveal/jump rather than side effects,
- offscreen headers explain what the current output belongs to,
- and any stronger action still routes through explicit review.

That keeps attention useful while preserving the archive rule that weaker facts stay visibly weaker.

## 3) Helm reinforces that quieting and next-actor truth must stay explicit

Helm's attention-window and attention-turn work keeps making the same point in a different register.
Quiet windows, delivery posture, and next-actor chips should be explicit objects, not folklore inferred from silence.

That supports a Schell design where:
- a chapter may have an alert mark without claiming urgency forever,
- a resumed view may show offscreen header context without claiming fresh completion,
- and a wake or resume path can say whether it is live, restored, or historical.

## 4) Steward and ViewFS reinforce expiry and spend humility

The neighboring cubes keep the same discipline alive:
- **Steward** keeps entry, drain, and shutdown explicit, which is a good reminder that chapter-bound alerts and room wake paths should expire, drain, or re-arm explicitly instead of lingering as immortal obligations.
- **ViewFS** keeps spend rails and payer posture distinct, which reinforces that clicking an alert or opening a hidden chapter should return the operator to judgment, not spend on their behalf.

Together they push Schell toward exact resume paths rather than actionful notification folklore.

## 5) What Schell can safely steal now

Given SlopOS's current design phase, the safest steals now look like this:
- command- or room-bound alert marks,
- offscreen chapter headers that restore locus when the command is out of view,
- jump-to-chapter and select-whole-chapter affordances,
- chapter-local notes that stay clearly weaker than transcript truth,
- and helper comparison packets carrying exact command/output/exit context.

These are high-value moves because they improve return and understanding without forcing a final notification doctrine.

## 6) What still should not be decided yet

SlopOS is still too early to justify freezing:
- one final notification center or durable inbox,
- one final cross-device wake-ticket sync model,
- one final annotation-sharing doctrine,
- one final semantic-zone protocol for every terminal,
- or one final hidden/background helper-terminal relationship.

Those are still the kinds of moves Schell should delay.

## 7) Compact conclusion

SlopOS does not yet tell Schell what the final assistant-heavy shell must be.
It does tell Schell something precise about the next safer move:
**treat attention as scarce, keep alerts weaker than durable truth, and make return to the exact chapter radically better.**
