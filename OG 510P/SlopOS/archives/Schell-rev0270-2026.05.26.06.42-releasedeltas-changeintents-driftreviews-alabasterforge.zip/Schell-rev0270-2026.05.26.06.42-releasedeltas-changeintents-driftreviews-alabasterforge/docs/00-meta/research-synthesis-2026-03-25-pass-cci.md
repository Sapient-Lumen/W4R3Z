# Research synthesis — 2026-03-25 — pass CCI

This pass sharpens a compact lesson from current official shell and terminal docs:
**the best modern shell+terminal luxuries cluster around shell-known command chapters, but history engines, finish cues, prompt clicks, and terminal control streams should still stay visibly weaker than fresh reviewed shell truth.**

## 1) Current docs keep converging on shell-known command chapters

VS Code shell integration, iTerm2 shell integration, WezTerm shell integration, kitty shell integration, and Ghostty's shell-integration work all point in the same direction.
When the shell marks prompt/input/output boundaries and working-directory updates explicitly, the terminal can support command navigation, command-output selection, prompt-local cursor movement, sticky command chrome, and richer chapter browsing without guessing nearly as much.
That convergence is strong evidence that Schell should treat the command chapter as a first-class shell-owned object rather than as a renderer-local block.

## 2) Current docs also keep converging on “local luxury, not portable truth”

The same sources also keep warning, indirectly, that richer terminal UX is not the same thing as durable truth.
OSC 7 cwd hints, OSC 133 prompt/command marks, terminal-local command palettes, title/badge updates, and emulator-local metadata all unlock excellent UX, but they are still enhancement channels.
Old xterm control families and today's richer emulator control planes are a reminder that the terminal stream can carry a lot of power and should not automatically become reviewed shell truth.
So the right Schell import is not to reject these luxuries.
It is to keep them visibly smaller than shell-authenticated packets and exact receipts.

## 3) History and prediction docs point to hygiene, not just recall speed

fish, PSReadLine, and Atuin all reinforce that modern history is richer than a plain reverse-search stack.
fish exposes searchable history plus explicit non-recording posture for leading-space commands.
PSReadLine separates history-based and plugin-based prediction sources.
Atuin adds filters such as cwd, history filters, failed-command storage, and secret filtering, and it explicitly advises pruning history after filter changes.
The lesson is bigger than “history can be fancy.”
The lesson is that source, privacy, filtering, and retention posture deserve first-class representation.

## 4) The low-regret Schell seam is a chapter packet stack

The strongest bounded next move is therefore:
- one shell-owned command chapter packet,
- one prompt-lease packet for live editable input,
- one finish-eligibility packet for threshold watches and focus-aware completion cues,
- and one history-policy witness carrying source/privacy/retention posture.

That packet family is strong enough to unlock chapter navigation, output selection, prompt-local click, source-badged predictions, and watch-this-command cues.
But it still defers the final shell grammar, history store, plugin model, notification backend, and renderer treaty.

## 5) Compact conclusion

Current official docs are lining up on one practical answer.
A super-good shell+terminal should absolutely steal command chapters, exact output selection, prompt-local cursor movement, focus-aware finish cues, rich recall filters, and source-badged predictions.
But it should do so by keeping shell-authenticated packets, local luxury metadata, history hygiene, and durable receipts visibly separate.
