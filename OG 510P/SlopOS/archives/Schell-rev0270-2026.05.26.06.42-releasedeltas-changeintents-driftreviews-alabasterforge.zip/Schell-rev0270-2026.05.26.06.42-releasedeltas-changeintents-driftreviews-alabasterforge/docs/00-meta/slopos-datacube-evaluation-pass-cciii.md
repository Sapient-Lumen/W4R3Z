# SlopOS datacube evaluation — 2026-03-25 — pass CCIII

**Schell should represent the first cross-app or cross-authority move as a handoff warrant with chooser turns, exact-reveal witnesses, and admission-scoped aftermath, because SlopOS keeps OpenURI manual-only, scheme-gated, and launch-only while the companion cubes keep selection, grants, previews, history, and later consequences as neighboring truths instead of one flattering open gesture.**

## 1) SlopOS OpenURI posture is a direct warning against “smart open” blur

The strongest companion pressure in this pass comes from SlopOS’s OpenURI posture.
SlopOS keeps OpenURI:
- manual-only,
- scheme-gated,
- launch-only,
- not a return channel,
- not a handler-inventory oracle,
- not a chooser-control surface,
- not a launch-completion oracle,
- not a recent-item/history control plane,
- not a subject-echo/logging truth source,
- and not a materialization or resource-grant seam.

That is exactly the rule Schell should import.
A selected path, URI, file-line, or chapter-local object in the terminal should not quietly collapse handler choice, reveal policy, browser detour, history enrollment, resource transfer, and completion truth into one “open” badge.

## 2) SlopOS exact-reveal posture argues for a visible veto

SlopOS’s show-item exactness boundary is especially valuable here.
It explicitly resists silent downgrade from exact reveal/select to “open the parent directory” or a generic nearby browse.
That means Schell should likely surface a separate exact-reveal witness on handoff routes.
If the exact route is unavailable, the honest next act is deny or offer a weaker separately named browse route rather than pretending the terminal did the requested thing.

## 3) Harbor keeps the detour state honest

Harbor keeps crossing boundaries framed as a membrane problem with request envelopes, route sets, admission choices, detour state, outcome classes, and aftermath receipts.
That is almost a direct template for Schell’s cross-app handoff work.
The terminal can be delightful, but the moment it leaves chapter-local action and enters chooser/default-handler/external-app territory should still have its own typed crossing object and own aftermath class.

## 4) ViewFS and Steward say selection, grant, history, and session mutation are neighboring states

ViewFS keeps object identity, recents, reveal, chooser sheets, staging trays, and grant ledgers explicitly separate.
Steward keeps pending requests, detour outcomes, assist receipts, history policy, and session mutation as separately named lanes.
Together they sharpen a useful Schell rule:
- selected chapter-local object,
- chooser turn,
- admitted handoff,
- recent-handoff hint,
- and any stronger durable reopen/session consequence
should remain neighboring states instead of collapsing into one generic terminal click result.

## 5) Helm, Ward, and Foundry keep the post-handoff claims narrow

- **Helm** keeps preview-versus-enactment honesty alive, so a chooser preview or destination diff should stay weaker than the actual admitted crossing.
- **Ward** keeps freshness and revalidation pressure alive, so a historical target or old default-handler memory should not carry the same route strength as a fresh current-basis object.
- **Foundry** keeps residue class and apportionment discipline alive, which matters when shell truth, chooser state, default memory, and later history each justify different strengths of action.

## 6) What this pass still refuses to decide

This pass still does **not** force Schell to choose:
- a final browser plane,
- a final chooser UI architecture,
- a final handler registry/default-memory model,
- a final durable reopen/history story,
- or a final external-app completion contract.

It only earns a smaller companion rule:
**chapter-local objects first; explicit handoff warrants second; chooser turns and exact-reveal witnesses third; admission-scoped aftermath only.**
