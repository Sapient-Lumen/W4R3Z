# Research synthesis — 2026-05-25 pass CCLXV — lint coverage and schema obligations

This pass imports automated-check and assessment-structure pressure without adopting a CI system or external compliance format.

- OpenSSF Scorecard pressure: automated checks are useful because they are discrete, reviewable heuristics with visible remediation/risk posture, not because a score proves safety.
- SLSA provenance pressure: provenance and attestations need verification against expected builders, sources, and policy context; Schell imports expectation-checking discipline for lint coverage.
- in-toto pressure: attestations and predicates are useful only when verifiers know which claims are being made and which policy consumes them.
- OSCAL assessment-result pressure: assessment reports distinguish scope, method, findings, risks, and continuous-monitoring context; Schell imports scoped findings without becoming an OSCAL export.
- SlopOS rev0720 pressure: a Schell lint pass cannot become accepted-prefix or append authority; base-digest context stays visible as a blocked-use row.

Bounded take: add LCM/SOB surfaces, a suite-coverage self-check, schema-obligation lint, H-0489..H-0500, RF-0055/RF-0056, and MAS/CAR rows.

Explicit non-take: no CI workflow, OpenSSF Scorecard integration, SLSA verifier, in-toto layout, OSCAL exporter, policy engine, helper runtime, public proof packet, or SlopOS portal adapter.
