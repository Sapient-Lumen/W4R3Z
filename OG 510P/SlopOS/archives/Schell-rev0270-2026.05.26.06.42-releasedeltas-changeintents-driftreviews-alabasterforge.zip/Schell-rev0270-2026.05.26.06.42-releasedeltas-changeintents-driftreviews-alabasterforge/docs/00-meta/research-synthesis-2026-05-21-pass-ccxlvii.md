# Research synthesis pass CCXLVII — receiver ledgers and claim fences

Revision: rev0250  
Timestamp: 2026.05.21.03.17

This pass narrows rev0249's memory-authority thesis into a smaller operator question: when a retained command object is shown, can the operator tell which receiver still has a copy, what claim is safe to make, and which stronger claim is fenced off?

The strongest external pressure is not new regulation-by-name; it is a repeated shape across sanitization, telemetry, CI retention, cluster cleanup, helper/vector stores, and agent consent. Sanitization means target data is made infeasible to access for a given effort, not merely hidden from one projection. Telemetry guidance pushes minimization and collection-purpose discipline. CI retention settings can be non-retroactive for existing artifacts and logs. Cluster TTL cleanup can make an object eligible for cleanup while leaving other projections outside that lifecycle. Vector/embedding systems can carry sensitive influence after raw text is gone. MCP-style tool flows add per-client consent and confused-deputy pressure, so a remembered helper context is not permission to act.

Bounded import for Schell:

- Add a receiver forgetting ledger, not a deletion backend.
- Add a claim fence, not a compliance engine.
- Add a memory authority card gauntlet, not a UI toolkit.
- Keep Schell's verbs deliberately weaker than legal/forensic claims: say `local shell history swept`, `receiver unknown`, `eligible for cleanup`, `post-sweep witness missing`, or `claim blocked`; do not say `sanitized`, `anonymized`, `globally forgotten`, or `compliant` unless a separate proof object exists.

Speculative conclusion: Schell's future terminal does not need a giant privacy dashboard first. It needs a tiny card that refuses to lie. A good card says what still remembers, what that memory can influence, and what the system is not allowed to claim.
