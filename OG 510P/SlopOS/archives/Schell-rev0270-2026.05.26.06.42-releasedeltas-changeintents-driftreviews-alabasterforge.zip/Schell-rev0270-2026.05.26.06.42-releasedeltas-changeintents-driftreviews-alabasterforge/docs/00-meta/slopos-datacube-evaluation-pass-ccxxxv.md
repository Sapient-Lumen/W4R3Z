# SlopOS datacube evaluation pass CCXXXV: recipient basis before spend

Revision: rev0238  
Date: 2026-05-15  
Context: Schell rev0238, SlopOS rev0695, companion cubes retained as pressure sources.

## 1. What SlopOS teaches this pass

SlopOS's strongest lesson for Schell is that imported material should narrow, explain, compare, or deny before it grants. Authority comes from explicit seams, not from convenient representations.

Rev0238 turns that lesson into a terminal rule: source cards are evidence; recipient effects require recipient basis.

## 2. FedCM/account pressure

SlopOS rev0695's FedCM boundary pins browser-mediated account choice, Login Status, connected-account lists, returned tokens, and disconnect choreography as provider-local. Schell should therefore show browser/account chips as explanatory evidence only. A deploy/send/reauth action needs current recipient login proof, approval basis, token audience/scope, and exact effect envelope.

## 3. MCP/client/tool pressure

SlopOS's MCP import family prevents dynamic client registration, auth metadata, authorization context, client assertions, tokens, userinfo, prompts, sampling, completions, tool resources, and progress signals from becoming ambient authority. Schell imports the same rule as a tool-catalog rebind: a helper tool name is not portable semantics, a prior client consent is not recipient consent, and a session is not authentication.

## 4. ACP/action pressure

The SlopOS ACP schema is useful because it keeps action kinds closed, effect typing explicit, and preconditions veto-only. Schell's recipient rebind gauntlet is the shell+terminal analogue. Source evidence can veto unsafe action or produce drafts, but it cannot grant spend without exact recipient action bytes and current witnesses.

## 5. Companion-cube pressure

- **Harbor**: transfer custody must say what survived and what became source-local.
- **ViewFS**: path targets need route, locality, and target-generation witnesses.
- **Foundry**: rich projections and screenshots are not raw/effect authority.
- **Steward**: settlement, retry, reversal, and aftercare need consequence-specific receipts.
- **Helm**: quick fixes live in review queues until floors are current.
- **Ward**: witness tiers must not collapse into one green badge.

## 6. Recommendation

Make recipient rebinding a first-class terminal habit but not a giant architecture yet. The current gauntlet is enough to test whether operators can predict: source evidence, recipient basis, strongest safe latch, blocked effect verb, and first missing rebind.
