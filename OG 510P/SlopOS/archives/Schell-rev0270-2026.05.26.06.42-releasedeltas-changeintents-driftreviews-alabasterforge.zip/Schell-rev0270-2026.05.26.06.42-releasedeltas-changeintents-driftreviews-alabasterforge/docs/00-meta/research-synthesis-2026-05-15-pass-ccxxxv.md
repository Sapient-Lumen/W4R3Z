# Research synthesis pass CCXXXV: recipient rebinding before action

Revision: rev0238  
Date: 2026-05-15  
Scope: current terminal/shell/agent precedents viewed through the question “what must be rebound on the recipient before an old/source card may act?”

## 1. Field signal

The field keeps making command work more durable, structured, transferable, and agentic. Shell integrations expose command/cwd/output zones. Terminal blocks preserve commands as objects. Agent terminals add command intent, working directory, hidden/background terminals, approvals, hooks, tool catalogs, and cross-environment handoff.

That is the right direction for Schell, but it creates a new failure mode: a beautiful source command object can arrive in a different recipient environment and look more current than it is.

## 2. Updated observations

### 2.1 Object-like command work needs recipient-local truth

Command blocks, sticky headers, rich output panels, copy/re-input/share affordances, and resurrected panes are all stealable. They should not be allowed to skip recipient rebinding. A block produced under source cwd, source account, source helper policy, source tool catalog, source terminal capability, or source network route is evidence until the recipient route proves the corresponding basis.

### 2.2 Helper and terminal state are becoming multi-environment

Local, background, cloud, and provider-specific agent sessions make action handoff tempting. The honest design is not to forbid handoff; it is to show which bindings travel and which must be re-established. Tool name, permission mode, config scope, sandbox, approval policy, and hidden terminal state are all recipient-specific until rebound.

### 2.3 Browser/account and MCP signals stay provider-local

FedCM and Login Status style account hints are valuable UX, not portable account truth. MCP auth, dynamic client registration, consent, redirect, token, prompt, sampling, and tool metadata need exact client/redirect/scope/consent binding before terminal actions inherit them. Schell's account and tool chips should therefore be explanatory, not authority-bearing, by default.

### 2.4 Redaction and export can destroy authority while preserving evidence

A redacted replay capsule can be privacy-correct and unreplayable. If the redacted field chooses a destructive target, Schell should not try to infer it. It should keep the card readable, make the missing target role visible, and require a recipient-local target before effect.

## 3. Lessons we must keep learning from the past

1. A source cwd is not a recipient target.
2. A repo name is not a checkout basis.
3. A browser account chip is not login authority.
4. A token-looking field is not approval.
5. A redirect host pattern is not exact redirect binding.
6. A tool name is not tool semantics.
7. A permission mode label is not a stable policy proof.
8. A network hostname is not an egress lease.
9. A secret variable name is not a secret generation.
10. A pid or pane title is not process identity.
11. A hyperlink label is not the URL/effect target.
12. A clipboard escape is not a user copy gesture.
13. A terminal brand/version is not hop-local capability proof.
14. A redacted field may be action-critical.
15. A notification return is not target continuity.
16. A quick-fix string is not recipient parser truth.

## 4. Brilliant ideas to steal, with fences

- Steal command blocks and re-input, but always show source versus recipient basis before rerun.
- Steal terminal-chat command details, but require current cwd/account/tool-policy rows before execution.
- Steal agent handoff, but show which environment owns the policy and tool catalog.
- Steal browser-mediated sign-in comfort, but keep account chips provider-local until recipient login proof exists.
- Steal MCP tool ecosystems, but bind client id, redirect URI, consent, scopes, and tool semantics exactly.
- Steal hyperlink and clipboard luxury, but reveal target/destination and authority floor first.
- Steal quick fixes, but make them editable drafts until the recipient shell parser/options prove the exact envelope.
- Steal redacted share bundles, but label action-critical omissions as authority-fatal.

## 5. Recommendation

Before Schell designs live protocol machinery, run the RB-PF-01 through RB-PF-06 prediction drill over `recipient-rebind-gauntlet-v0.json`. If operators cannot identify the strongest safe latch and first missing recipient binding from a one-line cue, simplify the latch vocabulary before adding more UI, protocol, or helper power.
