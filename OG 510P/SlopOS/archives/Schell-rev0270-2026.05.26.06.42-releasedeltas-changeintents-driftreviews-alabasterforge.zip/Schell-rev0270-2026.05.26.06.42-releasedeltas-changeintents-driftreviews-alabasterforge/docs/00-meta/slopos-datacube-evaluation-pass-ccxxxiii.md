# SlopOS datacube evaluation pass CCXXXIII: footer floors as portable-boundary teaching

Revision: rev0236  
Date: 2026-05-14  
Context: Schell rev0236, SlopOS rev0695, companion cubes retained as pressure sources.

## 1. What SlopOS teaches this pass

SlopOS rev0695 is useful here because it does not merely say “browser federation is risky.” It narrows the imported meaning: FedCM request fields, login status, account lists, connected-account tracking, chooser UI, tokens, disconnect choreography, and browser branding remain provider-local browser mediation unless explicit SlopOS seams bind them.

Schell's footer should teach the same move in miniature. The footer does not need to explain all of SlopOS. It only needs to keep source-local facts from looking like recipient authority.

## 2. Capshell pressure

Capshell's launch posture keeps descriptors, sidecars, result digests, network posture, cwd/env/argv, and effect contracts separate. That matters for Schell because an imported command chapter may be complete as evidence but still not be runnable in the recipient terminal.

The rev0236 footer makes that split tactile:

- complete evidence can enable compare;
- old replay can enable draft;
- redacted partial evidence can enable reveal request;
- remote evidence can enable observe;
- account hints can enable reauth prompt;
- effectful action still waits for current recipient receipts.

## 3. Companion-cube pressure

- **ViewFS**: open/path actions must show route and locality before they affect local files.
- **Harbor**: transfer custody is not a vibe; footer reveal paths need lineage and subset receipts.
- **Steward**: timeout, retry, settlement, rollback, and aftercare must be distinct rows.
- **Foundry**: rich semantic projections need raw reveal and transform receipts.
- **Helm**: quick fixes belong in review queues until floors are satisfied.
- **Ward**: arrival grades are tiered witnesses and must not be collapsed into a single trust color.

## 4. What Schell should not import too early

Do not import SlopOS's full schema heft into Schell yet. The shell+terminal still needs a tactile proof: can an operator predict blocked effects from one footer line? Only after that should Schell design canonical encodings, conflict keys, account objects, or replay stores.

## 5. Recommendation

Keep the SlopOS boundary discipline and use rev0236 footers as a teaching surface: source-local evidence is allowed to be helpful, but it must not silently become recipient authority. If a footer cannot explain that in one line plus one drawer, simplify the footer before building the terminal.
