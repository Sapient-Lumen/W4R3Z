# Research synthesis — 2026-05-15 — pass CCXXXVI

Revision: rev0239  
Theme: promotion ceremonies after recipient rebinding

## Sources checked this pass

Current terminal work keeps strengthening the case for semantic command objects: shell integration exposes command/cwd detection, decorations, navigation, sticky headers, and quick fixes; OSC 7/133/1337-style integrations expose cwd and prompt/input/output zones; hyperlinks and clipboard escapes make labels and output capable of triggering external effects; multiplexers and resurrection systems preserve command context across time; agentic CLIs increasingly expose sandbox, approval, hooks, and permission modes.

The useful steal is not a final protocol. It is the product shape: terminal work can become inspectable objects with fast actions. The dangerous steal would be treating the attractive object as authority.

## Lessons imported

1. **Semantic zones are excellent, but not sovereign.** Prompt/input/output/cwd marks are useful to navigate, select, summarize, and re-run. They still need author, route, capability, and downgrade witnesses.
2. **Clipboard and hyperlink protocols are effect surfaces.** OSC 52 and OSC 8 are too powerful to treat as decoration; Schell should expose origin, destination, target, and scheme authority before spend.
3. **Resurrection should keep a ceremony.** Restored commands are valuable, but pressing Enter over a restored command should remain a fresh gesture over a current envelope, not a replay of old authority.
4. **Agent approvals need enforced boundaries and visible policy epochs.** Sandbox, permission mode, hook result, auto-review, MCP consent, and tool-catalog state must appear as receipts, not background vibes.
5. **OAuth/MCP/FedCM account material stays source-local until rebound.** Exact redirects, state, per-client consent, token audience, browser chooser state, and connected-account hints are not portable shell truth.

## Move made

This pass adds `effect-promotion-ceremony-v0.json`, an eighteen-case matrix that starts where recipient rebinding ends. Each case forces Schell to name:

- the requested promotion;
- exact effect envelope;
- consequence class;
- contest window;
- fresh gesture scope;
- escrow receipts;
- spend receipt;
- settlement or aftercare obligation;
- rollback truth.

The result is a stricter but still decision-light product hypothesis: Schell can be fast if it separates candidate, rebound, enveloped, previewed, contested, armed, spent, and settled.

## Deliberate non-move

No shell grammar, terminal protocol, helper runtime, MCP transport, authorization UI, account/session model, evidence store, redaction format, URL opener policy, clipboard policy, or TUI API is frozen. The ceremony matrix is a legibility test before architecture.
