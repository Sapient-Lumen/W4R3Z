# Research synthesis — 2026-05-25 pass CCLXIII — spine/audit/refactor

This pass imports external pressure as archive-shape discipline only.

- NIST OSCAL Assessment Results pressure: assessment outputs should identify scope, assessment activity, assessor/tooling, observations, risks, findings, expiry, and remediation context. Schell imports this as MAS/CAR trace rows, not as a compliance report.
- NIST OSCAL POA&M pressure: risks and remediation items need status, owners, and plans. Schell imports this as audit/refactor findings and followthrough links.
- IETF SCITT pressure: receipts and transparency statements need registration policy and reproducible audit context before relying parties consume them. Schell imports this as predecessor-gate and policy-context pressure, not as a transparency service.
- OpenSSF Scorecard pressure: small automated checks can expose supply-chain risk and provide remediation prompts. Schell imports this as lint-gate discipline and remediation-oriented audit rows, not as a maturity score.
- SlopOS rev0720 pressure: accepted-prefix/base-digest and no discarded-suffix grafting must survive any compact audit export.

Bounded take: create a memory-authority spine and cube audit/refactor ledger, then require future surfaces to attach to phases before becoming head surfaces.

Non-take: no OSCAL exporter, no SCITT registry, no compliance report, no public proof packet, no runtime deletion adapter, no helper runtime, no terminal UI, no shell grammar freeze, and no SlopOS portal adapter.
