# Start here

Read `RELEASE-DELTA-MANIFEST.json` first.

Current head: **rev0269** — environment capsules, deterministic packer, and host-drift guards. Read `ENVIRONMENT-DETERMINISM-MANIFEST.json`, `docs/80-terminal/environment-capture-ledger-v0.json`, and `docs/80-terminal/path-time-locale-drift-gauntlet-v0.json` before treating any package byte identity as citeable. Byte-stable package custody remains non-authorizing.

# START HERE — Schell rev0269

Schell's current question is whether **a release package can have deterministic path/time/locale/metadata custody without pretending to be host attestation or independent reproducible-build proof**.

Read in this order:

1. `ENVIRONMENT-DETERMINISM-MANIFEST.json`
2. `docs/80-terminal/environment-determinism-manifest-path-time-locale-and-packer-guards.md`
3. `docs/80-terminal/environment-capture-ledger-v0.json`
4. `docs/80-terminal/path-time-locale-drift-gauntlet-host-and-archive-hazards.md`
5. `docs/80-terminal/path-time-locale-drift-gauntlet-v0.json`
6. `TOOLCHAIN-EXECUTION-MANIFEST.json`
7. `ARCHIVE-ENVELOPE-MANIFEST.json`
8. `PACKAGE-CONTENTS-MANIFEST.json`
9. `docs/80-terminal/lint-coverage-manifest-v0.json`
10. `docs/80-terminal/schema-obligation-board-v0.json`
11. `docs/80-terminal/memory-authority-spine-v0.json`
12. `docs/80-terminal/cube-audit-refactor-ledger-v0.json`
13. `docs/80-terminal/retention-forgetting-board-v0.json`
14. `docs/00-meta/research-synthesis-2026-05-26-pass-cclxix.md`

Current invariant:

```text
environment determinism = SOURCE_DATE_EPOCH + UTC zip timestamp + sorted entry list + ZIP_STORED metadata + mode preservation + path/locale/umask/hashseed assumptions + deterministic verifier + non-authority fence.
```

This rev audits and refactors the release package environment. Rev0266 made file-level package custody explicit; rev0267 made the envelope safe before extraction; rev0268 made verifier imports explicit. Rev0269 adds deterministic package rows so byte identity cannot hide ambient host drift.

Architecture remains blocked until independent changed-environment rebuild drills show that reviewers keep deterministic package evidence weaker than erasure, sanitization, compliance, host trust, helper authority, policy permission, receiver sync, public proof permission, or SlopOS append authority.
