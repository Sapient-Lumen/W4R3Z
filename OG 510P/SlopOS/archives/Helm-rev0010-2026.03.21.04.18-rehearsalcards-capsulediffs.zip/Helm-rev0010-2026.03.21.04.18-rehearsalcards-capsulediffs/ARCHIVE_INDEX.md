# Archive index

| Archive bundle | Date | Summary |
| --- | --- | --- |
| Helm-rev0010-2026.03.21.04.18-rehearsalcards-capsulediffs.zip | 2026-03-21 | Outside research pass IV revision: re-read SlopOS and Schell again, then tightened Helm around action rehearsal / route cards, capsule diffs, and shell-owned layout templates with rebinding while keeping the pillars stable. |
| Helm-rev0008-2026.03.21.03.07-typedproviders-capsulehonesty.zip | 2026-03-21 | Outside research pass II revision: re-read SlopOS and Schell again, then tightened Helm around typed Omnibox providers, Desktop Flow observability/reuse, and candidate contracts for Preview, Overview, and workspace/activity capsules. |
| Helm-rev0007-2026.03.21.02.35-pastlessons-stealthis-crosscuts.zip | 2026-03-21 | Outside research + lessons revision: re-read SlopOS and Schell, harvested strong ideas from current and historical desktop systems, and recorded the best non-pillar cross-cuts for Helm — Preview, workspace/activity capsules, Overview, flow debugging/packaging, plumbing-grade routing, query-first browsing, and visual layout templates. |
| Helm-rev0006-2026.03.21.02.09-statuslanes-contextpack-transferledgers.zip | 2026-03-21 | DelayBasin-shaped archive-machinery revision: added startup wrapper, context pack, status lanes, question/assumption/followthrough ledgers, foreign-pressure memory, and revision receipt so Helm's product decisions stop depending on chronology and chat memory. |
| Helm-rev0005-2026.03.21.01.52-recall-exchange-spine.zip | 2026-03-21 | Promoted Recall and Exchange into first-class Helm pillars so continuity, reentry, receipts, and typed transfer became explicit shell/compositor product truth. |
| Helm-rev0004-2026.03.21.01.34-exemplar-pillar-freeze.zip | 2026-03-21 | Froze Helm's product identity around exemplar-translated powers and made the five original pillars explicit first-party surfaces. |
| Helm-rev0003-2026.03.21.01.16-shell-lineage-receipts.zip | 2026-03-21 | Integrated first concrete Schell pressure through lineage, reviewed actions, receipts, ingress packets, and execution grounds. |
| Helm-rev0002-2026.03.21.00.55-control-tier-boundaries.zip | 2026-03-21 | Tightened control-tier boundaries, shell graph posture, input routing, and terminal/capshell separation. |
| Helm-rev0001-2026.03.21.00.42-visible-graph-shell.zip | 2026-03-21 | Initial Helm datacube seed establishing a visible-graph shell/compositor direction. |

- rev0010 — rehearsalcards-capsulediffs — current citation head
