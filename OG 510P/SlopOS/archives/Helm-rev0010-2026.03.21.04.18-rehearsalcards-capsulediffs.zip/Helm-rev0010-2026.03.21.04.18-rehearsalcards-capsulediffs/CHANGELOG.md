# Changelog


## rev0010 — 2026.03.21.04.18 — rehearsalcards-capsulediffs

- re-read SlopOS and Schell again with a tighter focus on humane shell luxuries that still respect exact route/reveal truth and restore honesty
- ran outside research pass IV centered on result cards, truthful continuity views, shell-owned layout templates, and rehearsal-friendly graph tooling
- added pass-IV teacher-cube evaluation, web research synthesis, and bibliography docs
- added candidate contracts for action rehearsal, capsule diffs, and layout templates with rebinding
- updated the trajectory map, roadmap, cross-cutting move catalog, question registry, followthrough queue, foreign-pressure ledger, context pack, release manifest, and revision receipt while deliberately keeping the pillar set stable



## rev0009 — 2026.03.21.03.40 — previewlenses-routecards-seeds

- re-read SlopOS and Schell again, this time focusing on how humane shell luxuries should inherit exactness, denial, lineage, and provenance discipline rather than bypass it
- added `docs/00-meta/slopos-schell-evaluation-2026-03-21-pass-iii.md`, `docs/00-meta/web-research-synthesis-2026-03-21-pass-iii.md`, and `docs/00-meta/research-bibliography-2026-03-21-pass-iii.md`
- added candidate-contract notes for `live lenses` and `snippet / quicklink / placeholder seeds`
- tightened `preview-candidate-contract-v0.md` so Preview is now explicitly action-adjacent while still inspect-before-commit
- tightened `omnibox-provider-posture-v0.md` so richer provider payloads and visibility grades stay possible without returning to plugin folklore
- expanded the cross-cutting move catalog, trajectory map, roadmap, question registry, followthrough queue, foreign-pressure ledger, context pack, and release metadata while deliberately keeping Helm's pillar set stable

## rev0008 — 2026.03.21.03.07 — typedproviders-capsulehonesty

- re-read SlopOS and Schell again, then extended the outside research around typed summon surfaces, continuity capsules, and graph observability instead of merely broadening the idea catalog
- added `docs/00-meta/web-research-synthesis-2026-03-21-pass-ii.md` and `docs/00-meta/research-bibliography-2026-03-21-pass-ii.md` to record the new pass explicitly
- added candidate contract notes for `Preview`, `Overview`, and `workspace/activity capsules` so those cross-cutting moves stop living only as prose pressure
- froze a narrow `omnibox-provider-posture-v0.md` so Helm now prefers typed providers over ambient plugin / shell-string folklore
- froze a narrow `flow-observability-posture-v0.md` so Desktop Flow now explicitly requires debug/event surfaces, graph secondary views, and reusable inspectable fragments
- added ADRs for both new narrow freezes and refreshed trajectory, roadmap, architecture overview, pillar contracts, questions, followthrough, foreign pressure, and release metadata to reflect the stronger shape

## rev0007 — 2026.03.21.02.35 — pastlessons-stealthis-crosscuts

- re-read SlopOS and Schell, then added a deliberate outside-web research pass rather than only iterating on prior chat conclusions
- added `docs/00-meta/web-research-synthesis-2026-03-21-pass-i.md` to record the strongest outside ideas worth stealing for Helm without prematurely promoting them into pillars
- added `docs/00-meta/lessons-we-must-learn-from-the-past.md` so future revisions keep the anti-ambient, anti-folklore lessons explicit instead of rediscovering them the hard way
- added `docs/00-meta/research-bibliography-2026-03-21.md` as a compact source memory for the current outside-idea pass
- added `docs/30-architecture/cross-cutting-move-catalog-v0.md` to track Preview, workspace/activity capsules, Overview, Flow debugging/packaging, plumbing-grade routing, query-first browsing, and visual layout templates as strong non-pillar moves
- refreshed trajectory map, architecture overview, pillar contracts, startup surfaces, question state, followthrough, foreign pressure, and release metadata to keep the new research pressure explicit and bounded

## rev0006 — 2026.03.21.02.09 — statuslanes-contextpack-transferledgers

- imported DelayBasin as a teacher for Helm's archive machinery rather than for product doctrine
- added compact startup surfaces: `START_HERE.md`, `AGENTS.md`, and `context-pack.json`
- added compact state and status surfaces: `SURFACE-STATUS.json`, `REVISION-RECEIPT.json`, `QUESTION-REGISTRY.json`, `ASSUMPTION-LEDGER.json`, `FOREIGN-PRESSURE-LEDGER.json`, `FOLLOWTHROUGH-QUEUE.json`, and `RESOLUTION-LEDGER.json`
- added `ARCHIVE_INDEX.md`, `docs/00-meta/archive-control-surfaces.md`, `docs/00-meta/question-machine.md`, and `docs/00-meta/delaybasin-lessons-for-helm.md`
- recorded explicit bounded takes and non-takes from SlopOS, Schell, and DelayBasin so future revisions do not silently widen imported pressure
- refreshed charter, archive policy, trajectory map, roadmap, claims, invariants, and traceability to include archive-control truth

## rev0005 — 2026.03.21.01.52 — recall-exchange-spine

- promoted Recall into a first-class Helm pillar so continuity, reentry, receipts, and durable activity truth stop hiding inside recents/history folklore
- promoted Exchange into a first-class Helm pillar so paste/drop/share/attach/forward/import stop hiding inside clipboard, drag/drop, and helper-magic folklore
- integrated more direct SlopOS pressure from exact reveal, non-authoritative recents, typed transfer, request-state honesty, and shell-owned persistence boundaries
- integrated more direct Schell pressure from session lineage, restoration honesty, ingress packets, selection packets, intent routing, and attach/forward witness discipline
- added Recall and Exchange posture docs plus ADRs for each promotion
- updated the architecture overview, trajectory map, roadmap, pillar contracts, claims, invariants, boundary-family map, and decision map to reflect seven pillars plus terminal/capshell
- tightened Omnibox, Object Browser, Operations Center, Desktop Flow, terminal, ingress, and reviewed-action language so continuity and transfer compose over the same shell graph

## rev0004 — 2026.03.21.01.34 — exemplar-pillar-freeze

- froze Helm's product identity around powers rather than app-clone thinking
- translated the exemplar list explicitly: i3, AHK, Rofi, Dolphin, and “god-tier task manager” now map to Helm powers and first-party surfaces
- added a base-product-surface posture so the five pillars are treated as one shell/compositor product rather than a distro bundle
- added a pillar-contracts doc with must-have and early-ban guidance for each pillar
- expanded tiling shell, Omnibox, Object Browser, Operations Center, Desktop Flow, and terminal posture docs with clearer v0 contracts
- added ADRs for “exemplars translate to powers” and “the five pillars are one product”
- updated roadmap, trajectory map, resolved history, claims, and invariants so future revisions inherit the same center of gravity

## rev0003 — 2026.03.21.01.16 — shell-lineage-receipts

- integrated the first concrete Schell pressure into Helm instead of leaving shell-facing work as a vague future blob
- added a Helm/Schell treaty doc so Helm can keep moving without pretending Schell is settled
- added shell session-lineage posture
- added reviewed-action / receipt posture
- added execution-ground posture
- added ingress-packet posture
- tightened terminal and capshell language around lineage, review, receipts, and ingress honesty
- clarified roadmap split: keep advancing compositor/object/flow/operator surfaces while keeping final shell syntax and attach/restore semantics provisional

## rev0002 — 2026.03.21.00.55 — control-tier-boundaries

- tightened Helm into a more SlopOS-shaped archive
- added release manifest
- added boundary family map and stronger decision map
- added shell graph, input routing, activation control, and session-selection boundary docs
- split automation into shell graph / structural UI graph / raw automation lane
- added terminal posture beside capshell posture
- strengthened object-browser and query-view stance
- clarified assurance claims and invariants

## rev0001 — 2026.03.21.00.42 — visible-graph-shell

- initial Helm datacube seed
