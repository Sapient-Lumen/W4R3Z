# ADR-0004: Helm exposes three control tiers

## Status
Accepted

## Context

AHK-grade reach matters, but hidden ambient automation would undermine Helm's explainability and shell ownership.

## Decision

Helm exposes three tiers:

1. shell graph automation
2. structural UI graph access
3. raw automation lane

The raw lane is real and powerful, but explicit, visible, and killable.

## Consequences

- Helm preserves an escape hatch for things outside the official model
- raw UI observation and injection are no longer the desktop's primary truth
- compositor and shell must expose enough live state to make Tier 1 genuinely strong
