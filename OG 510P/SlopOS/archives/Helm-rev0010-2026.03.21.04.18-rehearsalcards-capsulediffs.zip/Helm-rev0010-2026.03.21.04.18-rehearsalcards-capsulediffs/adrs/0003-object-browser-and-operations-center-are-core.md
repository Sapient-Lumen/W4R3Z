# ADR-0003: Object Browser and Operations Center are core shell surfaces

## Status
Accepted

## Context

A path browser and a classic task manager would underspecify Helm. The desktop needs first-class object semantics and operational honesty.

## Decision

Helm includes:

- an Object Browser for query views, reveal, preview, durable object selection, and bulk operations
- an Operations Center for windows, jobs, background presence, resource use, grants, failures, and automation sessions

## Consequences

These are shell product surfaces, not mere optional apps.
