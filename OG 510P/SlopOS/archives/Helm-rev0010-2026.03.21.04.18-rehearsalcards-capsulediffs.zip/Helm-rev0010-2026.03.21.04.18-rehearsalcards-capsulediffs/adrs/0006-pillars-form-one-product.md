# ADR-0006: Helm's pillars form one product surface

## Status
Accepted

## Context

As the archive grew, there was a risk that Tiling Shell, Omnibox, Object Browser, Operations Center, Desktop Flow, Recall, Exchange, and terminal/capshell would be treated as adjacent tools instead of one shell/compositor product.

## Decision

Helm treats these surfaces as one control plane over a shared shell graph.

They are first-party faces of the same product and should compose through shared object identity, continuity posture, receipts, grants, automation state, transfer state, and reveal semantics.

## Consequences

- Helm should not ship as a loose bundle of power-user apps
- the shell graph becomes shared substrate rather than one feature among others
- product work that improves one pillar should be expected to surface in the others where appropriate
