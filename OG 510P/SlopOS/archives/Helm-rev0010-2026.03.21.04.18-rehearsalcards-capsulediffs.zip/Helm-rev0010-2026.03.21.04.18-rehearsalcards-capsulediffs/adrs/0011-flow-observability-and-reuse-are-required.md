# ADR-0011: Desktop Flow requires observability and reusable fragments

## Status
Accepted

## Context

Helm already treats Desktop Flow as a pillar. The remaining risk was that the pillar could still be implemented as “a graph canvas now, the real tooling later”. Outside graph systems repeatedly show that this decays into spaghetti, mystery, and loss of trust.

## Decision

Desktop Flow must ship with:
- runtime/event inspection,
- graph secondary views such as outline/search/status,
- and reusable inspectable fragments such as subflows/macros/templates.

These are part of the pillar contract, not stretch goals.

## Consequences

Good:
- Desktop Flow is more likely to remain legible at scale
- failures and disablement can stay honest
- reusable desktop control patterns can spread without becoming copy-paste tangles

Bad:
- the pillar is more demanding to prototype
- Helm must resist shipping a “pretty canvas first” version that lacks the support machinery
