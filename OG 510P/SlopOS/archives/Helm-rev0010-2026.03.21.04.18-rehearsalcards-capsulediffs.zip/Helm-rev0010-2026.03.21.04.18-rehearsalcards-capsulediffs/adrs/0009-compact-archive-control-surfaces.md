# ADR-0009 — Adopt compact archive-control surfaces

## Status
Accepted

## Context

Helm's product doctrine has been tightening quickly, but its archive state still depended too much on chronology, remembered chat context, and implicit startup knowledge. DelayBasin and Schell both demonstrate that a small set of startup, status, question, and receipt surfaces can reduce that drift without forcing a giant bureaucratic stack.

## Decision

Helm adopts a compact archive-control family:

- `START_HERE.md`
- `AGENTS.md`
- `ARCHIVE_INDEX.md`
- `context-pack.json`
- `SURFACE-STATUS.json`
- `REVISION-RECEIPT.json`
- `QUESTION-REGISTRY.json`
- `ASSUMPTION-LEDGER.json`
- `FOREIGN-PRESSURE-LEDGER.json`
- `FOLLOWTHROUGH-QUEUE.json`
- `RESOLUTION-LEDGER.json`

## Consequences

Good:
- future startup is lower-entropy
- imported pressure is less likely to widen silently
- live questions and followthrough stop hiding in prose
- Helm's citation head is now explicit

Bad:
- the archive gains more machinery to maintain
- future revisions must resist adding ledgers just because neighboring datacubes have them

## Non-decision

This does **not** mean Helm imports DelayBasin's whole method constitution or commits to a large constitutional stack.
