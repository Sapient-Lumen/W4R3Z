# ADR-0008: Exchange is a core Helm pillar

## Status
Accepted

## Context

Helm already cared about object identity, explicit routing, and ingress honesty, but paste/drop/share/attach/forward/import remained spread across Object Browser, Omnibox, Desktop Flow, and terminal/capshell without one named product surface. SlopOS transfer/document pressure and Schell packet/route pressure made that omission too large.

## Decision

Helm promotes **Exchange** into a first-class pillar.

Exchange owns shell-level typed movement:
- ingress packets
- selection/intent packets
- exact route witnesses
- distinct open/reveal/insert/import/send/attach/forward actions
- transfer receipts, holds, and denials

## Consequences

- Helm will not treat raw path paste or helper magic as the universal transfer model
- typed packets and route witnesses become shared substrate across shell surfaces
- strong transfer actions must remain inspectable, reviewable when needed, and visible in operations/continuity surfaces
