# ADR-0005: Helm translates exemplars to powers rather than cloning tools

## Status
Accepted

## Context

Helm was seeded from a set of beloved tools: i3, AHK, Rofi, Dolphin, and the desire for a god-tier task manager. The archive needed to preserve what those tools taught without quietly inheriting old authority models or compatibility obligations.

## Decision

Helm will translate exemplars into powers:

- i3 → deterministic tiling discipline
- AHK → low-latency programmable desktop control
- Rofi → unified summon/search/switch/dispatch
- Dolphin → strong object/document browsing
- god-tier task manager → operational honesty

Helm explicitly rejects clone-compatibility as a product goal for those exemplars.

## Consequences

- Helm inherits strengths without promising compatibility theater
- future surface design should ask “which power is load-bearing?” rather than “which app are we re-making?”
- old ambient hook and path-worship habits become optional background context rather than product truth
