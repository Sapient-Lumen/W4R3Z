# ADR-0007: Recall is a core Helm pillar

## Status
Accepted

## Context

Helm's earlier revisions implied continuity through object-browser reopen, operations receipts, and shell/session lineage, but they did not give continuity its own named product surface. SlopOS pressure around non-authoritative recents and exact reveal, plus Schell pressure around reentry cues and restoration honesty, made that omission too large.

## Decision

Helm promotes **Recall** into a first-class pillar.

Recall owns shell-level continuity:
- current-live reentry
- activity trail
- exact reopen/reveal/jump over shell-owned refs
- continuity posture badges such as live/restored/historical/receipt
- hold-card honesty when strong actions reach non-live objects

## Consequences

- Helm will not treat app-local recents or launcher history as adequate continuity truth
- restored and historical objects must remain visibly distinct from live objects
- continuity and receipts must become searchable and actionable across Omnibox, Object Browser, Operations Center, Desktop Flow, and terminal/capshell
