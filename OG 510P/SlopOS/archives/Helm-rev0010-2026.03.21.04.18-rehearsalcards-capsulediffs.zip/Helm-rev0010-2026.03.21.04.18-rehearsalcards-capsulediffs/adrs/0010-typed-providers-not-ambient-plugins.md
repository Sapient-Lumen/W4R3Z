# ADR-0010: Omnibox extensibility uses typed providers, not ambient plugin folklore

## Status
Accepted

## Context

Helm's Omnibox was already understood as more than an app launcher, but outside research kept pointing to the same risk: broad summon surfaces become haunted when they are built on unrestricted shell-outs, hidden helpers, and opaque plugin side effects.

## Decision

Helm will use a **typed provider model** for Omnibox extensibility.

Providers may contribute matches, previews, snippets, quicklinks, routes, and actions, but they do so over typed shell subjects and action families rather than arbitrary shell-string folklore as the primary contract.

## Consequences

Good:
- Omnibox can stay broad without losing explainability
- provider identity and action provenance can remain visible in Operations Center and receipts
- snippets and quicklinks can compose with Exchange and Desktop Flow instead of becoming a separate macro culture

Bad:
- some easy shell-out plugin ideas become less direct
- provider authoring will need a more explicit contract than “run this command and parse stdout”
