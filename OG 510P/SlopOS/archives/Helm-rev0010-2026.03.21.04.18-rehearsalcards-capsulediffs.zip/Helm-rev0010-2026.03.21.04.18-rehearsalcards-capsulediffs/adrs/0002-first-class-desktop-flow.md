# ADR-0002: Desktop Flow is a first-class pillar

## Status
Accepted

## Context

Helm is trying to be meaningfully new. “A nicer launcher” is not enough. The desktop itself must be programmable.

## Decision

Helm ships a first-class visual desktop control surface called Desktop Flow. It is not a hobby layer or late plugin story.

## Consequences

- hotkeys, window rules, object actions, timers, snippets, routing, and workflow reactions belong in one visible control fabric
- Desktop Flow targets the shell graph first
- text scripting may exist, but is not the sole source of desktop programmability
