# ADR-0001: Helm is a shell/compositor product

## Status
Accepted

## Context

The easiest failure mode for Helm is to become a bundle of nice desktop utilities without a coherent shell model.

## Decision

Helm is defined first as a shell/compositor product with shell-owned desktop truth. Base apps exist to expose that truth, not to substitute for it.

## Consequences

- focus, activation, workspace, visibility, reveal/select, and base automation are shell semantics
- the Omnibox, Object Browser, Operations Center, Desktop Flow, and terminal/capshell front-end are part of one product
- app-private models do not outrank shell truth
