
# Helm: start here (for maintainers, including LLMs)

Helm is a **desktop shell/compositor design datacube for SlopOS-style capability systems**.

DelayBasin is being used here as a teacher for archive machinery and, increasingly, for compact preflight/rehearsal thinking. SlopOS remains Helm's main product teacher; Schell remains Helm's main shell-facing seam teacher.

## Non-negotiables

- **Do not collapse the exemplars back into app clones.** Helm is built from powers, not nostalgia bundles.
- **Do not let the compositor disappear into plumbing.** Focus, activation, visibility, placement, reveal/select, and desktop truth stay shell/compositor-owned.
- **Do not let Desktop Flow shrink into script boxes.** Helm's programmable desktop fabric is first-class product truth.
- **Do not let raw automation become ambient by default.** The raw lane exists, but it stays visible, leased, and inspectable.
- **Do not let Recall degrade into recents folklore.** Reentry, restored-vs-live honesty, exact reopen/reveal, and capsule diffs must stay explicit.
- **Do not let Exchange degrade into clipboard folklore.** Paste, drop, attach, forward, import, route witnesses, and rehearsal cards must stay typed and inspectable.
- **Do not let terminal convenience silently choose Helm's whole architecture.** Respect Schell pressure, but keep shell-facing contracts provisional where they are not yet earned.
- **Do not let archive chronology masquerade as state.** Status lanes, ledgers, receipts, and question state are part of the archive's truth surface.
- **Do not silently import pressure from neighboring datacubes.** Record what was taken, what was consciously not taken, and what is still provisional.
- **Do not let archive mass explode.** Add machinery only where it reduces drift, re-argument, or startup entropy.

## Read first

1. `README.md`
2. `context-pack.json`
3. `docs/00-meta/charter.md`
4. `docs/00-meta/trajectory-map.md`
5. `docs/00-meta/archive-control-surfaces.md`
6. `docs/00-meta/delaybasin-lessons-for-helm.md`
7. `docs/00-meta/slopos-schell-evaluation-2026-03-21-pass-iv.md`
8. `docs/00-meta/web-research-synthesis-2026-03-21-pass-iv.md`
9. `docs/00-meta/question-machine.md`
10. `docs/00-meta/helm-schell-treaty-v0.md`
11. `docs/30-architecture/architecture-overview.md`
12. `docs/30-architecture/pillar-contracts-v0.md`
13. `docs/30-architecture/action-rehearsal-candidate-contract-v0.md`
14. `docs/30-architecture/capsule-diff-candidate-contract-v0.md`
15. `docs/30-architecture/layout-template-candidate-contract-v0.md`
16. `docs/30-architecture/preview-candidate-contract-v0.md`
17. `QUESTION-REGISTRY.json`
18. `FOREIGN-PRESSURE-LEDGER.json`
19. `REVISION-RECEIPT.json`
20. `SURFACE-STATUS.json`

## One command

```bash
make lint
```

## What a good revision looks like

A good Helm revision does at least one of these:

- makes the shell/compositor product shape harder to drift,
- hardens a boundary between shell truth and app folklore,
- turns a fuzzy desktop power into an explicit contract,
- keeps Recall or Exchange honest about live truth,
- keeps Desktop Flow powerful without widening ambient authority,
- reduces startup entropy for future maintainers,
- preserves live questions, assumptions, imported pressure, or followthrough explicitly instead of burying them in prose,
- turns outside research into bounded takes, candidate cross-cuts, or explicit open questions instead of silently broadening the product,
- or records exactly why the revision counted at all.
