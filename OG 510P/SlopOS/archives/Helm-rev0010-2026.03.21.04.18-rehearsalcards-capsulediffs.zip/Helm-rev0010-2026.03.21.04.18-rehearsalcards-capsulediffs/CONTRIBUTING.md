# Contributing

Keep docs short, testable, and boundary-oriented.

Preferred document shapes:

- posture docs: purpose, posture, non-goals, wiring
- boundary docs: what stays owned by Helm, what is explicitly out of scope, why widening needs a new surface
- meta docs: mile-high and intentionally short

Rules:

1. Do not import POSIX, X11, Win32, or browser-session habits as unspoken defaults.
2. If a surface affects authority, focus, visibility, activation, persistence, or automation, pin it explicitly.
3. If a design widens authority, make the widening discoverable.
4. If a feature is “for power users,” still define how it stays visible, explainable, and killable.
5. Prefer first-class shell objects over app-private folklore.
