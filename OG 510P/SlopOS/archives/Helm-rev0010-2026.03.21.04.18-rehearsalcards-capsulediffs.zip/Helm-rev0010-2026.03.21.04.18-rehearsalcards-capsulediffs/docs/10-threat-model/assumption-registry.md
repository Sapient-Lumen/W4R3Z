# Assumption registry

- A-0001: Helm can expose a stable shell graph without requiring app cooperation for core desktop truth.
- A-0002: Power users will accept explicit raw automation if Tier 1 is genuinely strong and fast.
- A-0003: Object-centric browsing can replace enough path folklore to be worth making first-class.
- A-0004: Terminal/capshell can remain useful without inheriting POSIX ambient authority.
- A-0005: Desktop Flow can be fast enough to feel native rather than toy-like.
