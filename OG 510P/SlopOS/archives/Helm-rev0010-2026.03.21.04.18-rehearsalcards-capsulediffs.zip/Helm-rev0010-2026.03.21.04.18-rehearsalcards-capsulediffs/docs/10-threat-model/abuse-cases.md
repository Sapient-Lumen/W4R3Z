# Abuse cases

## AC-0001 Hidden global hooks
An app or user flow acquires durable invisible key/pointer interception.
- v0 stance: reject as baseline truth; raw lane must be explicit and visible.

## AC-0002 Focus theft
A component steals foreground or reroutes input without shell policy.
- v0 stance: focus/activation remain shell-owned.

## AC-0003 Haunted startup
Automation silently reappears at login or restart with broadened reach.
- v0 stance: no silent reinjection of raw power; background presence is separate and explicit.

## AC-0004 Fuzzy reveal
“Show item” falls back to approximate browsing or wrong selection.
- v0 stance: exact reveal/select or fail closed.

## AC-0005 Task-manager theater
The desktop hides jobs, grants, or automation sessions behind a shallow process list.
- v0 stance: Operations Center must show operational truth, not mere CPU trivia.

## AC-0006 Terminal regression
Terminal glue becomes the accidental universal authority channel.
- v0 stance: terminal/capshell remains explicit, bounded, and non-ambient by default.

## AC-0007 Over-modeled desktop
Tier 1 is so weak that users must use raw UI poking for ordinary layout and object workflows.
- v0 stance: the shell graph must be strong enough to carry common power-user automation.
