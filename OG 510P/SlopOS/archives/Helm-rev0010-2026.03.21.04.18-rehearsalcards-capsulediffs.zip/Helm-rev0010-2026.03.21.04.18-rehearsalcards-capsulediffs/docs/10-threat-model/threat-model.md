# Threat model (Helm v0)

Helm's primary security and integrity risks are not only memory corruption and malicious code. They also include desktop-level confusion and hidden authority.

Primary concerns:

1. hidden or ambient automation
2. unauthorized focus or activation steering
3. invisible background presence
4. cross-surface observation or injection without an explicit lane
5. object/browser semantics degrading into fuzzy app-private state
6. terminal or shell workflows reintroducing ambient authority
7. a shell graph that is too weak, forcing users into raw automation for normal work

The design target is not merely “safer than old desktops.” It is “power remains available while authority stays legible.”
