# D-RECALL Recall posture v0 (continuity without fake liveness)

Purpose: define Helm's continuity surface so reentry, trail, exact reopen, and restored-vs-live honesty are shell-owned product truth rather than leftover recent-items folklore.

## Posture (v0)

1. **Recall is shell-owned continuity**
   - continuity lives on shell-owned objects, views, receipts, jobs, flows, and transfers rather than app-local recent-files menus or generic launcher history

2. **One obvious current-live reentry cue**
   - users need one trusted path back to the current live lane, not just a pile of things that opened once

3. **Restored, historical, receipt, and live stay visibly distinct**
   - restored continuity is valuable, but it is not silently live
   - strong actions against non-live objects should land on hold cards that explain what witness is missing and how to reacquire live truth

4. **Exact reopen and reveal stay exact**
   - Recall should reopen, reveal, or jump to the exact shell-owned object or report why it cannot, rather than degrading into approximate nearby browse or shallow “open something related” behavior

5. **Recents may exist, but they stay shell-owned and non-authoritative**
   - shell-local hints are acceptable so long as they do not become the durable authority plane
   - explicit persistence and durable reopen should remain tied to shell-owned object/document seams, not generic launch side effects

## v0 must exist

- one obvious current-live reentry cue
- an activity trail spanning windows, workspaces, objects, jobs, flows, transfers, and receipts
- continuity badges at least for `live`, `restored`, `historical`, `receipt`, and `unknown`
- exact reopen/reveal/jump for supported shell-owned refs
- hold cards when a requested strong action reaches a non-live or drifted object

## Temptations to ban early

- generic recent-items folklore as portable truth
- treating restored continuity as weakly-live by default
- using notification history, launcher history, or scrollback as the whole continuity model
- silently substituting approximate nearby browse when exact reentry is unavailable

## Phase 1 non-goals

- universal app-provided recent-item federation
- freezing the final continuity storage format
- pretending every historical object deserves direct rerun or attach

## Wiring

- decision surface: `decision-map.md` (D-RECALL)
- related docs: `object-browser-posture-v0.md`, `operations-center-posture-v0.md`, `reveal-exactness-boundary-v0.md`, `reviewed-action-receipt-posture-v0.md`, `shell-session-lineage-posture-v0.md`, `execution-ground-posture-v0.md`
- design pressures carried forward from SlopOS/Schell: exact reveal, non-authoritative recents, session lineage, reentry cues, restoration honesty, receipts
- assurance anchors: CH-HELM-0013, I-HELM-0012
