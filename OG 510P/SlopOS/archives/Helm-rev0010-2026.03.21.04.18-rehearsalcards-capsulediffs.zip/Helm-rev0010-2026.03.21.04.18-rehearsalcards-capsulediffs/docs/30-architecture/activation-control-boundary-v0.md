# D-ACT activation control boundary v0

Purpose: pin who owns “bring this forward”, “focus this”, and similar foreground effects.

## Boundary (v0)

1. **Foregrounding remains shell-owned**
   - apps may request attention or activation
   - the shell/compositor decides whether and how foregrounding occurs

2. **Activation is distinct from notification**
   - asking for attention does not silently imply focus stealing

3. **Automation does not bypass activation policy**
   - Desktop Flow and the raw lane still cross the shell's activation policy surface

4. **Future widening must be explicit**
   - if Helm ever adds stronger automation-facing foreground powers, they must land on a new explicit surface

## Why this matters

Focus theft is one of the fastest ways to make a desktop feel hostile and haunted.

## Wiring

- decision surface: `decision-map.md` (D-ACT)
- related docs: `compositor-posture-v0.md`, `attention-posture-v0.md`, `ui-automation-posture-v0.md`
- assurance anchors: CH-HELM-0002, I-HELM-0001
