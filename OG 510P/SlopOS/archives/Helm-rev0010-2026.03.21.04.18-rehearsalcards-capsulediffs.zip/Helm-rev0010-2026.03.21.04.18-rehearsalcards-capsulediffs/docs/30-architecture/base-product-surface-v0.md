# D-BASE base product surface posture v0 (one product, not a bundle)

Purpose: pin Helm as a single shell/compositor product so future work does not collapse into “great utilities shipped together”.

## Posture (v0)

1. **Helm is one control plane**
   - Tiling Shell, Omnibox, Object Browser, Operations Center, Desktop Flow, Recall, Exchange, and terminal/capshell are first-party faces of the same product

2. **The shell graph is shared substrate**
   - the pillars should compose over one object model instead of growing separate state silos

3. **The compositor is inside the product identity**
   - Helm is not a shell plus a generic compositor bolted underneath

4. **Core pillars are not “optional power-user extras”**
   - Object Browser, Operations Center, Desktop Flow, Recall, and Exchange are base identity, not late plug-ins

5. **Shell-facing surfaces stay native even while Schell is provisional**
   - terminal/capshell belongs in the base product even before final shell syntax freezes

## Phase 1 non-goals

- shipping a distro-style bundle of loosely related tools
- letting each pillar evolve its own incompatible control vocabulary
- treating the compositor as invisible plumbing with no product posture

## Wiring

- decision surface: `decision-map.md` (D-BASE)
- related docs: `architecture-overview.md`, `shell-graph-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0001, CH-HELM-0012, I-HELM-0010, I-HELM-0011
