# Cross-cutting move catalog v0

Purpose: track strong non-pillar moves that should keep pressuring Helm without automatically becoming pillars.

## 1. Preview as a shell power

What it is:
- shell-wide inspect-before-commit
- reusable across Object Browser, Omnibox, Recall, Exchange, and Operations Center

Guardrails:
- Preview is not silent open/launch/import/run
- provider identity and failures should remain visible
- Preview should not regress into app-local plugin clutter

Current state:
- candidate contract exists in `preview-candidate-contract-v0.md`
- still not promoted to pillar or full service family posture

## 2. Workspace/activity capsules

What they are:
- continuity objects that capture meaningful project/task state across the shell graph
- primarily a Recall/Tiling/Operations concern

Guardrails:
- exact / repaired / partial / unavailable honesty
- no false promise of carrying identity/account/cookie truth
- visible repair reasons when restore is imperfect

Current state:
- candidate contract exists in `workspace-capsule-candidate-contract-v0.md`

## 3. Overview

What it is:
- the spatial companion to Omnibox
- a quick glanceable shell-owned surface over workspaces/windows/focus/continuity cues

Guardrails:
- should render the same shell graph Omnibox and Operations Center rely on
- should not become a decorative mode disconnected from shell truth
- should retain strong keyboard/type-to-search paths

Current state:
- candidate contract exists in `overview-candidate-contract-v0.md`

## 4. Typed providers for Omnibox

What it is:
- provider-contributed matches, previews, snippets, quicklinks, routes, and actions over typed shell subjects

Guardrails:
- typed providers, not unrestricted shell-outs by default
- provider identity stays visible
- strong actions keep review/receipt pathways

Current state:
- this move is now narrow enough to be frozen in `omnibox-provider-posture-v0.md`

## 5. Flow observability and reusable fragments

What it is:
- event/debug lane
- graph outline/search
- node status
- reusable inspectable fragments

Guardrails:
- no “pretty canvas now, tooling later” trap
- packaged fragments remain inspectable locally
- review gates stay visible

Current state:
- this move is now narrow enough to be frozen in `flow-observability-posture-v0.md`

## 6. Plumbing-grade route inspection

What it is:
- typed, inspectable action routing across Exchange, Omnibox, and shell-visible object actions

Guardrails:
- no silent helper magic
- exact subject and route witness remain visible

Current state:
- still pressure spread across Exchange, handler routing, and shell-facing route surfaces

## 7. Visual layout/template editing

What it is:
- a shell-owned spatial template editor inside Tiling Shell

Guardrails:
- do not regress into a separate zone-manager worldview
- layout templates should compose with Recall and capsules rather than sit beside them

Current state:
- still research pressure only

## 8. Breadcrumb / outline / timeline cues

What they are:
- multiple scales of continuity and orientation across Object Browser, Recall, Overview, and maybe Flow

Guardrails:
- do not trap these as app-local editor tricks
- do not confuse helpful local trails with universal truth

Current state:
- still research pressure only, but stronger than before


## 9. Live lenses / derivative surfaces

What they are:
- shell-owned cropped or mirrored live surfaces derived from another exact surface

Guardrails:
- derivative provenance stays visible
- no silent input forwarding by default
- no hidden capture-channel backdoor

Current state:
- candidate contract exists in `live-lens-candidate-contract-v0.md`

## 10. Snippet / quicklink / placeholder seeds

What they are:
- small reusable personal accelerators that expand into typed inserts, routes, review cards, or Flow entrypoints

Guardrails:
- no raw shell-string default substrate
- no hidden scraping to satisfy placeholders
- strong actions still compose with review/receipt pathways

Current state:
- candidate contract exists in `snippet-seed-candidate-contract-v0.md`

## 11. Provider visibility grades and richer result payloads

What they are:
- typed provider payloads richer than flat list items
- root-visible vs scoped-only vs disabled-until-enabled provider surfaces

Guardrails:
- no hidden provider state machines the shell cannot inspect
- do not flood root search with every provider capability by default

Current state:
- still pressure on Omnibox provider design; partially reflected in `omnibox-provider-posture-v0.md`


## 12. Action rehearsal / route cards

What they are:
- shell-owned preflight cards for strong actions, routes, restores, or Flow entrypoints

Guardrails:
- no fake determinism
- no bypass of review/receipt pathways
- uncertainty class stays visible

Current state:
- candidate contract exists in `action-rehearsal-candidate-contract-v0.md`

## 13. Capsule diffs

What they are:
- shell-owned comparisons between live state, selected capsules, and restore receipts

Guardrails:
- do not flatten repaired / partial / unavailable into generic success
- do not pretend app-local memory is shell truth

Current state:
- candidate contract exists in `capsule-diff-candidate-contract-v0.md`

## 14. Layout templates with rebinding

What they are:
- shell-owned spatial templates with named slots, anchors, and rebinding rules

Guardrails:
- do not split into a separate zone-manager worldview
- do not rely primarily on title-matching folklore
- do not hide rebinding decisions

Current state:
- candidate contract exists in `layout-template-candidate-contract-v0.md`
