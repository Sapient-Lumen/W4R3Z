# D-INGRESS ingress packet posture v0 (paste, drop, and selection are not ambient text)

Purpose: carry forward Schell's ingress honesty into Helm's broader shell and object model.

## Posture (v0)

1. **Paste/drop/selection ingress should be explicit where authority matters**
   - not every paste needs ceremony, but authority-bearing ingress should not silently inherit execution power

2. **Objects stay objects when possible**
   - document refs, selections, dropped artifacts, and shell-visible objects should not flatten into lossy strings by default

3. **Ingress packets can feed multiple Helm surfaces**
   - omnibox
   - object browser
   - recall
   - exchange
   - terminal/capshell
   - desktop flow

## Phase 1 non-goals

- giant universal clipboard subsystem
- freezing Schell's final packet schema

## Wiring

- decision surface: `decision-map.md` (D-INGRESS)
- related docs: `object-browser-posture-v0.md`, `omnibox-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `capshell-posture-v0.md`, `desktop-flow-posture-v0.md`
- assurance anchors: CH-HELM-0010, I-HELM-0009
