# D-FLOWOBS Desktop Flow observability and reusable-fragment posture v0

Purpose: keep Desktop Flow from collapsing into a pretty but opaque canvas.

## Posture (v0)

1. **Desktop Flow requires runtime observability**
   - triggers, last run, failures, disablement, and current suspension state must be visible

2. **Desktop Flow requires a debug/event lane**
   - a sidebar, panel, or equivalent inspect surface should exist for recent flow events and node-level state

3. **Graph structure needs secondary views**
   - outline/search over the graph
   - node status
   - cross-reference or jump-to-entrypoint support

4. **Reusable fragments are first-class**
   - subflows, macros, templates, or equivalent reusable fragments should exist
   - packaged fragments should remain inspectable locally

5. **Review boundaries and raw-lane crossings must be legible**
   - data edges, control edges, and review gates should not blur together

## Why freeze this now

Every strong visual-graph system that remains useful at scale invests heavily in debugging, inspection, and reusable fragments.
The “graph only” answer consistently decays into spaghetti and mystery.

This is no longer speculative enough to leave as mere idea pressure.

## v0 must exist

- flow event/debug surface
- graph outline/search
- node status or equivalent local runtime cues
- reusable inspectable fragments

## Ban early in v0

- shipping only a canvas and promising tooling later
- packaged fragments that cannot be inspected by local operators
- flattening review gates into ordinary edges with no visible distinction

## Wiring

- decision surface: `decision-map.md` (D-FLOWOBS)
- related docs: `desktop-flow-posture-v0.md`, `flow-entrypoint-posture-v0.md`, `flow-failure-inspection-posture-v0.md`, `control-tier-boundary-v0.md`, `operations-center-posture-v0.md`
- assurance anchors: CH-HELM-0016, I-HELM-0015
