# D-TILE tiling shell posture v0 (rigorous by default, hybrid by choice)

Purpose: pin Helm's desktop feel without collapsing into “i3 clone” thinking.

## Posture (v0)

1. **Tiling-first**
   - directional focus, predictable layout transforms, and keyboard-first workspace motion are base product behavior

2. **Hybrid-capable**
   - floating, special, or trusted surfaces may exist where the shell decides they are honest

3. **Workspace semantics are shell-owned**
   - workspaces are first-class objects, not an app convention

4. **Layout rules belong in Desktop Flow**
   - window placement and routing policies are graphable, not buried only in static configs

## v0 must exist

- directional focus and directional workspace motion
- split / stack / tab / reparent layout transforms that feel deterministic
- scratch / shelf / special-surface handling by shell policy rather than app folklore

## Temptations to ban early

- cloning historical i3 syntax or compatibility as a design goal
- title/class regex empires as the main policy language
- letting app behavior quietly redefine global focus or workspace semantics

## Phase 1 non-goals

- strict clone-compatibility with any historical tiling WM
- letting apps define their own global workspace/focus policy

## Wiring

- decision surface: `decision-map.md` (D-TILE)
- related docs: `compositor-posture-v0.md`, `desktop-flow-posture-v0.md`, `pillar-contracts-v0.md`
