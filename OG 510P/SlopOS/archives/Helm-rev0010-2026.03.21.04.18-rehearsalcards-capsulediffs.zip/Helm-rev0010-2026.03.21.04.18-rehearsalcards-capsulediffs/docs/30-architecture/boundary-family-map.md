# Boundary family map

## Shell truth family
- compositor-posture-v0.md
- shell-graph-posture-v0.md
- tiling-shell-posture-v0.md
- activation-control-boundary-v0.md
- input-routing-posture-v0.md

## Object workflow family
- object-browser-posture-v0.md
- object-query-posture-v0.md
- reveal-exactness-boundary-v0.md
- handler-routing-boundary-v0.md
- session-selection-boundary-v0.md

## Operations family
- operations-center-posture-v0.md
- background-presence-posture-v0.md
- attention-posture-v0.md

## Desktop control family
- desktop-flow-posture-v0.md
- flow-entrypoint-posture-v0.md
- flow-failure-inspection-posture-v0.md
- control-tier-boundary-v0.md
- structural-ui-graph-posture-v0.md
- raw-automation-lane-posture-v0.md
- ui-automation-posture-v0.md

## Continuity and transfer family
- recall-posture-v0.md
- exchange-posture-v0.md

## Terminal/shell family
- terminal-posture-v0.md
- capshell-posture-v0.md
- shell-session-lineage-posture-v0.md
- reviewed-action-receipt-posture-v0.md
- execution-ground-posture-v0.md
- ingress-packets-posture-v0.md
