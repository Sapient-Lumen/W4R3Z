# D-PILLARS pillar contracts v0 (must exist, ban early)

Purpose: record the minimum visible shape of Helm's eight core surfaces before details scatter across later docs.

## Tiling Shell

### Must exist in v0
- directional focus and workspace movement
- predictable split / stack / tab / layout transforms
- shell-owned workspaces and placement policies

### Ban early in v0
- title/class regex culture as the main customization model
- app-owned global workspace policy
- “config file is the product” thinking

## Omnibox

### Must exist in v0
- instant summon
- search and act over windows, workspaces, objects, views, recall items, exchange routes, and actions
- structured shell actions rather than command-string primacy
- typed provider extensibility with provider-visible actions and results

### Ban early in v0
- app-launcher-only scope
- PATH-plus-argv as the main UX contract
- hidden side effects that bypass shell receipts for strong actions
- ambient plugin folklore where provider identity or action family is opaque

## Object Browser

### Must exist in v0
- split views with strong keyboard navigation
- query views and saved smart views
- bulk operations, preview, and exact reveal/select
- exact reopen/reentry to supported shell-owned objects

### Ban early in v0
- path-only product identity
- fuzzy “best effort” reveal
- treating search/query as a later accessory

## Operations Center

### Must exist in v0
- windows, jobs, background presence, automation sessions, and transfer sessions
- grants / leases / special authority visibility
- receipts, denials, failures, resource use, and continuity posture

### Ban early in v0
- shallow process-list theater
- hiding background presence, automation, or transfer state outside the main ops surface
- making the tool “for emergencies only” instead of daily honesty

## Desktop Flow

### Must exist in v0
- hotkeys, rules, timers, recall jumps, exchange routes, and object actions as flow entrypoints
- typed shell-graph nodes and edges
- live inspection of triggers, failures, and disablement state
- debug/event lane, graph outline/search, and reusable inspectable fragments

### Ban early in v0
- reducing the product to arbitrary script boxes
- ambient invisible persistence for high-risk flows
- sleep-and-pray timing as the normal design path
- shipping only a canvas and promising the support machinery later

## Recall

### Must exist in v0
- one obvious current-live reentry cue
- activity trail across windows, objects, jobs, flows, transfers, and receipts with continuity badges
- exact reopen/reveal/reentry over shell-owned refs, plus hold cards when live truth is missing

### Ban early in v0
- generic recent-items folklore as portable truth
- treating restored/historical objects as silently live
- collapsing continuity into notification toasts or shell-local history hints only

## Exchange

### Must exist in v0
- typed ingress for paste, drop, clipboard, and file-like payloads with inspect / insert / import choices
- typed selection/intent routes for open / reveal / send / attach / forward with exactness and hold-card honesty
- visible transfer, attach, and forward receipts across the shell

### Ban early in v0
- raw path paste as the universal transfer UX
- silent promotion from selection/paste/drop into execution
- approximate “helpful” routing that hides the exact subject or route witness

## Terminal/Capshell

### Must exist in v0
- a first-class shell-facing surface for keyboard operators
- reviewed action / receipt handoff for strong actions
- lineage, ingress honesty, restoration honesty, and execution-ground visibility hooks

### Ban early in v0
- ambient command strings as the default desktop glue
- premature POSIX cosplay
- prompt-return folklore as the only explanation surface

## Wiring

- decision surface: `decision-map.md` (D-PILLARS)
- related docs: `exemplar-translations-v0.md`, `tiling-shell-posture-v0.md`, `omnibox-posture-v0.md`, `omnibox-provider-posture-v0.md`, `object-browser-posture-v0.md`, `operations-center-posture-v0.md`, `desktop-flow-posture-v0.md`, `flow-observability-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `terminal-posture-v0.md`
- assurance anchors: CH-HELM-0011, CH-HELM-0012, CH-HELM-0013, CH-HELM-0014, CH-HELM-0015, CH-HELM-0016, I-HELM-0010, I-HELM-0011, I-HELM-0012, I-HELM-0013, I-HELM-0014, I-HELM-0015

## Cross-cutting moves that should keep pressuring the pillars

These are not promoted pillars yet, but they are important enough to track explicitly:

- **Preview** should pressure Object Browser, Omnibox, Recall, Exchange, and Operations Center.
- **Workspace/activity capsules** should pressure Tiling Shell, Recall, Operations Center, Overview, and Terminal/Capshell.
- **Overview** should pressure Tiling Shell, Omnibox, Recall, and Operations Center.
- **Visual layout/template editing** should pressure Tiling Shell, Recall, and Desktop Flow.

See also: `cross-cutting-move-catalog-v0.md`, `preview-candidate-contract-v0.md`, `overview-candidate-contract-v0.md`, and `workspace-capsule-candidate-contract-v0.md`.
