
# Snippet / quicklink seed candidate contract v0

Purpose: turn the best part of snippets, quicklinks, and placeholder templates into a Helm-native candidate instead of falling back to raw text-macro folklore.

A **seed** is a small reusable personal accelerator.
It may be text-like, route-like, or flow-like, but Helm should treat it as a shell object rather than as an ambient macro.

## Candidate posture

1. **Seeds are typed, not only textual**
   - text seed
   - route seed
   - object jump seed
   - flow entry seed
   - review-card seed

2. **Placeholders bind to shell truths when possible**
   - active selection packet
   - clipboard / transfer packet
   - current object or view anchor
   - current workspace / capsule ref
   - explicit user arguments

3. **Expansion target matters**
   - insert into active input
   - create an intent packet
   - open a review card
   - invoke a Flow entrypoint
   - propose a route or jump

4. **Browsing a seed is not the same as executing it**
   - seeds may preview their expansion shape
   - stronger effects still use review/receipt surfaces where required

5. **Seed provenance stays visible**
   - provider/source
   - placeholder requirements
   - allowed expansion targets

## Why this looks valuable

Tiny personal accelerators are one of the biggest “quality of life” wins in current launchers and shell helpers.
Helm should keep that power while refusing the usual raw-string, hidden-side-effect substrate.

## Candidate uses

- typed quicklinks from Omnibox
- text snippets that can consume selection or clipboard packets
- personal route seeds for Exchange
- Flow entry seeds for repeatable desktop actions
- review-card seeds for frequent strong actions that still need explicit approval

## Guardrails

- do not default to arbitrary shell-string execution
- do not harvest placeholder values through hidden observation when a typed packet is absent
- do not let seeds bypass review/receipt pathways for strong actions

## Candidate v0 specimen

A narrow specimen could be:
- one text seed with typed placeholders,
- one route seed,
- one Flow entry seed,
- and one preview card that shows what expansion would happen before execution.

## Working stance

Seeds look like a very strong way to preserve the best parts of Rofi/AHK/Raycast/Alfred taste without importing ambient macro culture as Helm truth.
