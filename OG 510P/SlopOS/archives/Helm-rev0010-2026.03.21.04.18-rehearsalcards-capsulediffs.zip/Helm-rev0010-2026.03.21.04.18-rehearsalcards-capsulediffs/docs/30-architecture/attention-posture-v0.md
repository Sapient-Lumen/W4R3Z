# D-ATTN attention posture v0

Purpose: pin Helm's attention and notification stance.

## Posture (v0)

1. **Attention is a hint, not foreground authority**
   - notification and urgent state do not bypass activation control

2. **Durable truth lives elsewhere**
   - transient UI is not the sole carrier of consequential state

3. **Desktop Flow may react to attention, but does not bypass policy**
   - flows can route, coalesce, or respond, but still respect shell-owned activation and visibility rules

## Phase 1 non-goals

- making urgent equivalent to focus steal
- treating notifications as the durable system of record

## Wiring

- decision surface: `decision-map.md` (D-ATTN)
- related docs: `activation-control-boundary-v0.md`, `operations-center-posture-v0.md`
