# D-CAPSHELL capshell posture v0 (explicit shell tooling, no ambient command-string contract)

Purpose: pin Helm's current shell-tooling stance using SlopOS and Schell lessons without pretending the final Schell design is already written.

## Posture (v0)

1. **No ambient command-string authority as the desktop's primary glue**
   - command strings may exist, but they are not the default semantic contract for shell actions

2. **No inherited ambient environment baseline by assumption**
   - terminal/capshell workflows should not quietly depend on global desktop ambient state as their authority model

3. **Jobs and backgrounding remain explicit**
   - shell tooling should not silently rebuild hidden daemon culture

4. **Structured shell actions are preferred where practical**
   - typed launch, object, job, and route actions are better native desktop glue than unstructured shell folklore

5. **Reviewed shell-facing actions should be inspectable**
   - basis, approval, execution-ground hints, and receipt truth should not evaporate into prompt folklore

6. **Ingress honesty matters**
   - paste/drop/selection-driven shell entry should not silently inherit more authority than it visibly has

7. **Schell will sharpen this family later**
   - this is an intentional interim posture pending the dedicated Schell datacube

## Phase 1 non-goals

- POSIX shell compatibility as product truth
- treating stringly shell glue as the only operator surface
- freezing final shell syntax or attach/restore semantics too early

## Wiring

- decision surface: `decision-map.md` (D-CAPSHELL)
- related docs: `terminal-posture-v0.md`, `shell-session-lineage-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`, `execution-ground-posture-v0.md`, `ingress-packets-posture-v0.md`, `background-presence-posture-v0.md`
- assurance anchors: CH-HELM-0006, CH-HELM-0008, CH-HELM-0009, CH-HELM-0010
