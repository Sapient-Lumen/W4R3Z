# D-FLOWENTRY flow entrypoint posture v0

Purpose: pin how Desktop Flow begins execution.

## Posture (v0)

1. **Entry points are first-class**
   - hotkeys
   - layout events
   - workspace changes
   - object-browser selections
   - job completions
   - notification events
   - timers
   - explicit user invocations from Omnibox or Operations Center

2. **Hotkeys are not a separate secret subsystem**
   - they are graph entrypoints

3. **Authority tier crossings are visible**
   - if a flow leaves shell graph control for structural or raw automation, that should be visible

4. **Entry points can be disabled, inspected, and named**
   - users should not have to hunt hidden config text to understand what can fire

## Wiring

- decision surface: `decision-map.md` (D-FLOWENTRY)
- related docs: `desktop-flow-posture-v0.md`, `raw-automation-lane-posture-v0.md`, `operations-center-posture-v0.md`
