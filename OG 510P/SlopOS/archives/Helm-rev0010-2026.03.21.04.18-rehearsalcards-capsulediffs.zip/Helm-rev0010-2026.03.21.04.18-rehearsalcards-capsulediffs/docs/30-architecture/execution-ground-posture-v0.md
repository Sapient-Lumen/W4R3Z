# D-EXGROUND execution-ground posture v0 (no ambient cwd/env folklore)

Purpose: state how Helm should think about shell execution context before Schell finishes its own execution-ground design.

## Posture (v0)

1. **Execution context is explicit enough to inspect**
   - cwd-like location, environment/profile deltas, activation posture, and authority-bearing view state should not be guessed from prompt chrome alone

2. **Desktop actions that cross into shell work should carry ground witnesses where practical**
   - re-open, rerun, flow-triggered shell action, and reviewed launch surfaces should not pretend context is obvious when it is not

3. **Prompt appearance is descriptive, not authoritative**
   - pretty shell chrome must not become the only place execution-ground truth exists

## Phase 1 non-goals

- final workspace/dev-shell treaty
- universal serialization of every possible execution context field

## Wiring

- decision surface: `decision-map.md` (D-EXGROUND)
- related docs: `capshell-posture-v0.md`, `terminal-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`
- assurance anchors: CH-HELM-0009
