# D-REVEAL reveal exactness boundary v0

Purpose: pin the meaning of reveal/select requests in Helm.

## Boundary (v0)

1. **Reveal means exact reveal/select**
   - the shell either reveals and selects the exact target or fails closed

2. **Approximate fallback is not silent success**
   - opening a nearby folder or a best-guess view is not equivalent

3. **Apps do not redefine reveal semantics**
   - the shell owns this meaning

4. **Future weakening requires a new explicit surface**
   - fuzzy browse/recommendation may exist elsewhere, but not by silently redefining reveal

## Why this matters

A desktop that lies about “show me the thing” becomes untrustworthy fast.

## Wiring

- decision surface: `decision-map.md` (D-REVEAL)
- related docs: `object-browser-posture-v0.md`, `handler-routing-boundary-v0.md`
- assurance anchors: I-HELM-0003
