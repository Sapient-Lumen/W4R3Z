# D-ROUTE handler routing boundary v0

Purpose: pin who chooses routing when an object or action can be handled by multiple surfaces.

## Boundary (v0)

1. **Routing remains shell-owned**
   - requesters do not become authoritative for global handler choice

2. **Chooser UX is local shell policy**
   - the shell may present a chooser, default, or remembered route, but the route remains a shell decision surface

3. **Desktop Flow may propose routes**
   - flows can express preferences or rules, but still route through shell-owned semantics

4. **Future widening must be explicit**
   - app-owned permanent global handler steering is not silently inherited

## Wiring

- decision surface: `decision-map.md` (D-ROUTE)
- related docs: `object-browser-posture-v0.md`, `session-selection-boundary-v0.md`, `omnibox-posture-v0.md`
