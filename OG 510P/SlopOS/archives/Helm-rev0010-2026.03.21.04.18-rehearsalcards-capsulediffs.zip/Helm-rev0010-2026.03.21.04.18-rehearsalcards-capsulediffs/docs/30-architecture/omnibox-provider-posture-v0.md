# D-OMNIPROV Omnibox provider posture v0

Purpose: narrow the Omnibox extensibility story before launcher/plugin folklore sneaks back in.

## Posture (v0)

1. **Omnibox extensibility is a typed provider model**
   - providers contribute matches, previews, actions, snippets, routes, proposals, pages, or detail surfaces over typed shell subjects

2. **Providers are not ambient shell-command backdoors by default**
   - PATH-plus-argv and arbitrary command strings are not the main extensibility substrate

3. **Provider outputs preserve subject and action truth**
   - exact subject kind or ref
   - action family
   - review posture where relevant
   - receipt expectations where relevant

4. **Provider identity stays inspectable**
   - the user and Operations Center should be able to tell which provider produced a result or action

5. **Provider breadth is allowed; provider folklore is not**
   - snippets, quicklinks, jump targets, object matches, and action providers are welcome
   - hidden helper magic and effect-smuggling are not

6. **Provider visibility grades should stay possible**
   - root-visible, scoped-only, or disabled-until-enabled provider surfaces are all reasonable
   - Omnibox should not assume every provider capability belongs in root search by default

## Why freeze this now

Modern summon surfaces keep proving that broad action surfaces are useful.
The dangerous part is not breadth. It is breadth implemented on top of command-string folklore, hidden daemons, and side-effect opacity.

Helm can avoid that trap now with one narrow posture: typed providers.

## v0 must exist

- one provider registration story
- provider-attributed matches/actions
- typed action dispatch into existing review/receipt surfaces where needed
- snippets/quicklinks able to compose with shell truth rather than live as isolated hacks

## Ban early in v0

- plugin culture whose primary contract is arbitrary shell-out
- providers whose strong actions bypass review/receipt pathways
- result lists that hide which provider generated them

## Wiring

- decision surface: `decision-map.md` (D-OMNIPROV)
- related docs: `omnibox-posture-v0.md`, `preview-candidate-contract-v0.md`, `exchange-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`, `operations-center-posture-v0.md`
- assurance anchors: CH-HELM-0015, I-HELM-0014
