
# Live lens candidate contract v0

Purpose: name a possible Helm move that is stronger than ordinary tiling but smaller than general capture or remote-control folklore.

A **live lens** is a shell-owned derivative surface based on another exact surface or region.

This is inspired by things like cropped live regions, live thumbnails, and focused watch windows.

## Candidate posture

1. **A live lens is derivative and shell-owned**
   - it is not the original surface
   - it should carry a clear exact source witness
   - it should be visible as a derivative object in Operations Center and Recall

2. **A live lens is useful because it is smaller or more focused**
   - cropped region
   - live thumbnail
   - focused sub-surface
   - maybe one exact monitored region

3. **Default action strength should stay modest**
   - inspect
   - follow source
   - pin/unpin
   - expand to source
   - maybe exact jump back to the source object

4. **Interaction should require a stronger explicit posture**
   - no silent input forwarding by default
   - interactive lenses, if admitted, should use a visible stronger lane or lease

5. **Derivative truth must remain visible**
   - source surface
   - freshness / liveness
   - if the source is gone, the lens should degrade honestly rather than pretending independence

## Candidate uses

- Tiling Shell watch window
- Overview watchpoint
- Operations Center live monitor tile
- Recall hold card with one visual watch region
- compare one live region beside another object without taking over the whole layout

## Guardrails

- do not let a lens become a hidden capture backdoor
- do not let a derivative surface claim stronger truth than the source surface
- do not let interactive lenses silently bypass raw-lane or input-routing boundaries

## Candidate v0 specimen

A small proof-bearing slice could be:
- create one shell-owned live thumbnail or cropped region from one source surface,
- show source witness and liveness badge,
- allow inspect/follow/expand actions,
- and show clear degradation when the source surface disappears.

## Working stance

Live lenses look like one of the most promising “super awesome” Helm luxuries, but they should stay a candidate contract until the provenance, interaction, and lifecycle story is earned.
