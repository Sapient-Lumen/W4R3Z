# Architecture overview

Helm is a desktop shell/compositor product built around one idea:

the desktop has a real object model, and that model should be visible and programmable.

The shell/compositor therefore owns desktop truth for:

- surfaces/windows
- focus and activation
- workspaces and placement
- visibility and reveal/select
- continuity posture and reentry
- transfer routing and exactness
- shell-object identity
- base automation entrypoints

Around that truth Helm ships seven first-party shell surfaces plus a native terminal/capshell front-end:

- **Tiling Shell** — keyboard-first, hybrid-capable presentation and layout
- **Omnibox** — launch, search, switch, route, and act over shell-owned objects
- **Object Browser** — query views, reveal, preview, selection, and durable object workflows
- **Operations Center** — windows, jobs, background presence, resource use, grants, failures, automation sessions, transfers, and receipts
- **Desktop Flow** — visible graph control over the desktop
- **Recall** — continuity, reentry, exact reopen/reveal, activity trail, and restored-vs-live honesty
- **Exchange** — typed ingress, selection packets, transfer routing, attach/share/forward workflows, and route witnesses
- **Terminal/Capshell** — explicit shell tooling that does not smuggle ambient authority back in

These are not eight adjacent apps. They are eight faces of one control plane.

Helm preserves raw reach through an explicit control-tier model:

1. shell graph
2. structural UI graph
3. raw automation lane

The exemplar lineage now translates like this:

- i3 → deterministic tiling discipline
- AHK → low-latency desktop programmability with a visible raw lane
- Rofi → unified summon/search/switch/dispatch over shell objects
- Dolphin → strong object/document browsing with query views and exact reveal
- “god-tier task manager” → an Operations Center that explains the desktop honestly

SlopOS and Schell now add two promoted product pressures that became pillars rather than hidden subsystems:
- exact continuity, explicit restore/reentry honesty, and durable activity truth
- typed transfer, explicit ingress/selection packets, and exact route witnesses

Schell changes one major thing in this revision:
Helm no longer treats terminal work as a generic future placeholder.
Instead it names a provisional shell-facing treaty around:
- session lineage
- reviewed actions and receipts
- ingress packets
- execution-ground witnesses
- restoration honesty
- attach/forward route honesty

The product thesis is not “ban hacks.” It is “make the shell graph strong enough that hacks become the exception rather than the substrate.”

## Cross-cutting moves currently pressuring the architecture

These are not promoted pillars, but they are increasingly important:

- **Preview** — a shell-wide inspect-before-commit surface that should appear across Object Browser, Omnibox, Recall, Exchange, and Operations Center
- **Workspace/activity capsules** — continuity objects that capture and reenter meaningful project state with exact/repaired/partial/unavailable honesty
- **Overview** — a spatial companion to Omnibox that shows windows, workspaces, continuity cues, and quick moves at a glance
- **Visual layout/template editing** — a Tiling Shell surface for spatial templates without regressing into separate zone-manager culture

Two narrower moves are now frozen rather than merely implied:

- **typed Omnibox providers** — the action-surface breadth is welcome, but the extensibility model is typed-provider-first rather than ambient shell-string plugin culture
- **Flow observability/reuse** — Desktop Flow now explicitly requires debug/event surfaces, graph secondary views, and reusable inspectable fragments
