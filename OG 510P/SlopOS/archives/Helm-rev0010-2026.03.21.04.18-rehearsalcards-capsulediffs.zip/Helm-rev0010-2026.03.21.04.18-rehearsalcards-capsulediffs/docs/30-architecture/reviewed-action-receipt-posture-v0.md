# D-REVIEW reviewed action and receipt posture v0 (prompt return is not proof)

Purpose: keep Helm's shell-facing actions honest before Schell settles final interaction details.

## Posture (v0)

1. **Strong actions deserve reviewable objects**
   - side-effecting actions should be representable as inspectable proposals rather than only raw command strings or button clicks

2. **Approval basis stays visible**
   - the reviewed basis for an action should remain inspectable at the point of approval

3. **Receipts matter**
   - completion truth should not collapse into spinners, prompt return, or vanished notification toasts

4. **Review/receipt applies beyond the terminal**
   - omnibox actions, object-browser actions, recall jumps that reacquire live state, exchange routes, desktop-flow launches, and explicit raw automation sessions should all be able to leave behind inspectable receipts

## Phase 1 non-goals

- one universal review UI for all action families
- freezing Schell's exact command-envelope schema inside Helm

## Wiring

- decision surface: `decision-map.md` (D-REVIEW)
- related docs: `capshell-posture-v0.md`, `operations-center-posture-v0.md`, `desktop-flow-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `shell-session-lineage-posture-v0.md`
- assurance anchors: CH-HELM-0008, I-HELM-0008
