# D-RAWAUTO raw automation lane posture v0 (explicit reach for what the model does not cover)

Purpose: preserve the elite part of AHK-style reach without making it the desktop's ambient substrate.

## Posture (v0)

1. **The raw lane is real**
   - presentation-oriented observation and injection are legitimate user needs

2. **The raw lane is explicit**
   - sessions are visible, inspectable, and killable

3. **Observation and injection are distinct**
   - read does not imply write; structure does not imply input

4. **The raw lane is fallback, not foundation**
   - common desktop automation should prefer shell graph control

5. **Scratchpad speed still matters**
   - the fallback lane must still be fast enough for ugly local wins when needed

## Phase 1 non-goals

- silent always-on global hook culture
- pretending raw automation does not exist
- making raw automation the only way to control normal shell behavior

## Wiring

- decision surface: `decision-map.md` (D-RAWAUTO)
- related docs: `control-tier-boundary-v0.md`, `flow-entrypoint-posture-v0.md`, `operations-center-posture-v0.md`
- assurance anchors: CH-HELM-0004, I-HELM-0002
