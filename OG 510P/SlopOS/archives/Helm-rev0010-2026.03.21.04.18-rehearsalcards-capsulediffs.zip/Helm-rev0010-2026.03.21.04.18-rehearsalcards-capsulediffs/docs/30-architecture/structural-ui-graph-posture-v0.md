# D-SUIG structural UI graph posture v0

Purpose: define the middle tier between shell semantics and raw automation.

## Posture (v0)

1. **The structural UI graph is explicit**
   - it exposes UI structure only when granted

2. **It bridges semantics and presentation**
   - richer than shell graph, cleaner than pixels-and-timing hacks

3. **Observation does not silently imply injection**
   - seeing interactable structure is distinct from driving it

4. **The structural graph is especially valuable for inspection and tooling**
   - it can support debugging, guided automation, and explainability

## Phase 1 non-goals

- universal ambient accessibility substrate
- silent broad cross-app inspection

## Wiring

- decision surface: `decision-map.md` (D-SUIG)
- related docs: `control-tier-boundary-v0.md`, `raw-automation-lane-posture-v0.md`, `ui-automation-posture-v0.md`
