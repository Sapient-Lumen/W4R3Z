# D-OPS Operations Center posture v0

Purpose: define Helm's operations surface as more than a classic process/task manager.

## Posture (v0)

1. **Operational truth over process theater**
   - windows, jobs, background presence, failures, resource use, grants, transfers, and automation sessions matter

2. **The Operations Center is shell-owned**
   - it reflects shell/compositor truth and explicit service state, not merely app self-reporting

3. **Authority must be legible**
   - if something can observe, inject, keep running, transfer authority-bearing payloads, or hold special access, users should be able to see that

4. **The Operations Center is part of daily use, not only emergencies**
   - it is how Helm stays honest under power-user workflows

5. **Continuity and exchange truth belong here too**
   - receipts, reentry posture, transfer sessions, holds, denials, and stale-vs-live state should be visible

## v0 must exist

- windows, jobs, background presence, flows/automation sessions, transfer sessions, and resource use
- visibility into grants / leases / special authority holdings
- receipts, denials, failures, continuity posture, and kill / suspend surfaces users can actually trust

## Temptations to ban early

- a shallow process list standing in for system truth
- hiding automation, transfer, or grant state in separate debugging tools
- designing the Operations Center only for failure day instead of everyday operation

## Phase 1 non-goals

- being only a process list
- hiding automation or grant state in secondary tools

## Wiring

- decision surface: `decision-map.md` (D-OPS)
- related docs: `background-presence-posture-v0.md`, `desktop-flow-posture-v0.md`, `raw-automation-lane-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0005, I-HELM-0004
