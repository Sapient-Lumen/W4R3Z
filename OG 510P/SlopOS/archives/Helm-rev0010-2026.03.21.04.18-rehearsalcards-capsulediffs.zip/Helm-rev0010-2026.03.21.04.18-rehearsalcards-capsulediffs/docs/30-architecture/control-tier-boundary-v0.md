# D-CTRLTIERS control-tier boundary v0

Purpose: pin Helm's three-tier control model and keep “automation” from collapsing into one blurry authority bucket.

## Boundary (v0)

1. **Tier 1: shell graph**
   - primary and preferred
   - acts on shell-owned desktop objects

2. **Tier 2: structural UI graph**
   - explicit access to UI structure and interactable targets when granted

3. **Tier 3: raw automation lane**
   - presentation-oriented observation and injection for things outside the model

4. **Tier crossing is meaningful**
   - moving from Tier 1 to Tier 2 or Tier 3 is not invisible
   - stronger reach deserves stronger visibility and control

5. **The existence of Tier 3 does not demote Tier 1**
   - raw reach is a fallback lane, not the primary truth of the desktop

## Why this matters

AHK-grade power is valuable, but Helm wants it without making the whole desktop depend on haunted ambient hooks.

## Wiring

- decision surface: `decision-map.md` (D-CTRLTIERS)
- related docs: `shell-graph-posture-v0.md`, `structural-ui-graph-posture-v0.md`, `raw-automation-lane-posture-v0.md`, `ui-automation-posture-v0.md`
- assurance anchors: CH-HELM-0004, I-HELM-0002, I-HELM-0005
