# D-COMP compositor posture v0 (shell-owned desktop truth)

Purpose: pin Helm's core stance that the compositor is not merely a pixel service. It participates in authority-bearing desktop truth.

## Posture (v0)

1. **Focus and activation stay shell/compositor-owned**
   - apps do not decide foreground truth
   - activation requests remain subject to shell policy

2. **Workspace and placement are shell truth**
   - membership, visibility, and reveal destination remain shell-owned
   - apps may express needs, but do not define placement truth

3. **Input routing is shell-governed**
   - pointer and keyboard delivery follow shell focus policy
   - there is no baseline “whoever hooks first wins” model

4. **Visibility and capture are policy surfaces**
   - capture, trusted UI, and observation are explicit surfaces, not accidental renderer side effects

5. **The compositor participates in the shell graph**
   - surfaces, focus chains, workspace membership, occlusion/visibility state, and trusted-mode boundaries must be inspectable enough to power Desktop Flow and Operations Center

## Phase 1 non-goals

- app-owned focus stealing
- ambient global hook culture as baseline truth
- legacy compatibility contracts defining Helm semantics

## Wiring

- decision surface: `decision-map.md` (D-COMP)
- related docs: `shell-graph-posture-v0.md`, `activation-control-boundary-v0.md`, `input-routing-posture-v0.md`, `control-tier-boundary-v0.md`
- assurance anchors: CH-HELM-0002, I-HELM-0001, I-HELM-0002
