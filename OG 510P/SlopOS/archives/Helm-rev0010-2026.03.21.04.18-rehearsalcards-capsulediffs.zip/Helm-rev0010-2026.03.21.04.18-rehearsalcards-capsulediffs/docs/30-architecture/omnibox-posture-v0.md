# D-OMNI Omnibox posture v0

Purpose: define Helm's first-class launcher / switcher / command palette.

## Posture (v0)

1. **Omnibox is a shell surface**
   - it searches and acts over shell-owned objects and actions, not merely app launchers

2. **Primary targets**
   - apps/components
   - windows/workspaces
   - object references
   - query views
   - jobs and notifications
   - recall items and reentry targets
   - exchange routes and transfer proposals
   - shell actions

3. **Structured actions, not only command strings**
   - the Omnibox should prefer typed shell actions over shell-string folklore

4. **Typed providers are the extensibility path**
   - breadth is welcome, but ambient plugin / shell-string folklore is not

5. **Fast enough to replace habit layers**
   - it must feel competitive with the best launcher/switcher tools

## v0 must exist

- instant summon and dismiss
- search over windows, workspaces, documents/views, recall items, exchange routes, and actions from one surface
- action dispatch that participates in review/receipt pathways where strong effects matter
- provider-attributed results/actions over a typed provider model

## Temptations to ban early

- reducing the Omnibox to an app launcher
- inheriting PATH-plus-argv culture as the main semantic model
- letting shell actions bypass the same truth surfaces used elsewhere in Helm
- plugin cultures that make provider identity or action truth opaque

## Phase 1 non-goals

- inheriting PATH-plus-argv culture as its primary semantic model
- being only an app launcher

## Wiring

- decision surface: `decision-map.md` (D-OMNI)
- related docs: `omnibox-provider-posture-v0.md`, `shell-graph-posture-v0.md`, `capshell-posture-v0.md`, `object-browser-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
