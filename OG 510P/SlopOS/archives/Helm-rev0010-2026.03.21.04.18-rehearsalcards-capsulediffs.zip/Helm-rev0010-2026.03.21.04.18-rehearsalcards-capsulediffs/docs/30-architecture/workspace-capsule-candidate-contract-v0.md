# Workspace/activity capsule candidate contract v0

Purpose: turn the current “capsules” idea into a disciplined continuity candidate.

Capsules are **not** generic session folklore.
They are continuity objects that may capture meaningful project/task state across the shell graph.

## Candidate posture

1. **Capsules are continuity objects**
   - they belong primarily to Recall
   - but pressure Tiling Shell, Operations Center, Overview, and Terminal/Capshell

2. **Capsules never overclaim exactness**
   - exact
   - repaired
   - partial
   - unavailable

3. **Capsules may contain multiple kinds of state**
   - workspace/layout posture
   - visible windows/surfaces
   - object/view anchors
   - query-view anchors
   - flow entrypoints or disabled flow references
   - maybe shell-facing lane references where Schell truth allows it

4. **Capsules should preserve why they failed to restore cleanly**
   - missing object
   - stale route
   - unavailable component
   - lineage mismatch
   - execution-ground drift

5. **Capsules are not identity or auth containers**
   - no generic promise of carrying profile/account/cookie state as desktop truth

## Candidate v0 specimen

A narrow specimen could be:
- capture one workspace with layout template + object/view anchors,
- restore it later,
- badge it exact/repaired/partial/unavailable,
- and surface the repair reasons inside Operations Center and Recall.

## Guardrails

- do not promise exact replay when live refs are gone
- do not let capsules become app-local save blobs that Recall cannot see
- do not let capsule share/export become a hidden auth/profile leak

## Working stance

Capsules now look like one of Helm's highest-value continuity moves, but the exact capture contract and Schell-facing lane integration remain open enough that this should stay a candidate contract for now.
