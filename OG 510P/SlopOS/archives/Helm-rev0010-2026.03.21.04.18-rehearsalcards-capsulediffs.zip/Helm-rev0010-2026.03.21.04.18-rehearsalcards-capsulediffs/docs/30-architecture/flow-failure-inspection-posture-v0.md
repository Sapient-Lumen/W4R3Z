# D-FLOWFAIL flow failure inspection posture v0

Purpose: pin Helm's stance that programmable desktop control must be debuggable.

## Posture (v0)

1. **Failure is visible**
   - a flow that did not run, partially ran, or crossed into a denied tier should say so

2. **Last-known context is inspectable**
   - users should be able to inspect recent triggers, important intermediate state, and notable denials

3. **The system prefers causal explanations over folklore**
   - “wrong title match” and “maybe focus was weird” should stop being the normal debugging model

4. **Operations Center is a first-class inspection surface**
   - flow health and recent failures are not buried only in log files

## Wiring

- decision surface: `decision-map.md` (D-FLOWFAIL)
- related docs: `desktop-flow-posture-v0.md`, `operations-center-posture-v0.md`
