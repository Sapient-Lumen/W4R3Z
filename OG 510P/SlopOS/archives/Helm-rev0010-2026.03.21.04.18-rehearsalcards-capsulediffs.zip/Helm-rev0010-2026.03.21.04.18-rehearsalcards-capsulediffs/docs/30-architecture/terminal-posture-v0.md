# D-TERM terminal posture v0 (native front-end, not ambient authority tunnel)

Purpose: pin Helm's terminal stance while Schell is still immature, without treating “terminal later” as a content-free placeholder.

## Posture (v0)

1. **The terminal is a first-class shell surface**
   - it belongs in base Helm

2. **The terminal is not the accidental universal desktop glue**
   - Helm does not smuggle old ambient desktop authority back in through a text box

3. **Terminal workflows should compose with shell truth**
   - object references, structured actions, jobs, recall targets, exchange packets, flow entrypoints, and receipts should be able to participate

4. **Terminal history is not enough**
   - shell-facing work needs lineage, not just scrollback and command history

5. **Text remains valuable**
   - the rejection is of ambient authority folklore, not of text tooling itself

## v0 must exist

- a first-class shell-facing surface for keyboard operators
- reviewed action / receipt pathways for strong shell-facing actions
- lineage, ingress, restoration, and execution-ground visibility hooks instead of prompt folklore only

## Temptations to ban early

- using terminal text as the default ambient glue for all desktop control
- freezing POSIX-looking shell behavior before Schell earns it
- letting prompt return stand in for durable truth

## Phase 1 non-goals

- full terminal/capshell language design before Schell earns it
- pretending keyboard operators do not need a terminal
- letting restoration theater or prompt chrome stand in for live truth

## Wiring

- decision surface: `decision-map.md` (D-TERM)
- related docs: `capshell-posture-v0.md`, `shell-session-lineage-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`, `execution-ground-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0006, CH-HELM-0007
