# D-BGPRES background presence posture v0 (prefer jobs, make presence explicit)

Purpose: pin Helm's stance that “keep running in the background” is a reviewed, visible state rather than an ambient assumption.

## Posture (v0)

1. **Background presence is explicit**
   - a component does not silently become durable or forever-resident just because it exists

2. **Prefer jobs over ambient residence**
   - deferrable work should prefer job-like execution rather than hidden tray/daemon culture

3. **Presence does not silently widen other powers**
   - keeping something around does not automatically grant observation, activation, or raw automation powers

4. **Presence must be visible in Operations Center**
   - users can inspect who is alive and why

## Phase 1 non-goals

- unbounded autostart culture
- silent persistence as a convenience feature

## Wiring

- decision surface: `decision-map.md` (D-BGPRES)
- related docs: `operations-center-posture-v0.md`, `flow-entrypoint-posture-v0.md`
