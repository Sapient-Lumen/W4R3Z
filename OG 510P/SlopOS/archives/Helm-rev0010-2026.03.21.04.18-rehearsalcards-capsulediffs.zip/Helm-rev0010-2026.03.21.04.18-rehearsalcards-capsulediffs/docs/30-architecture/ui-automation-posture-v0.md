# D-AUTO UI automation family posture v0

Purpose: summarize Helm's UI automation stance across all control tiers.

## Posture (v0)

1. **Helm accepts that jurisdiction outside the official model is valuable**
   - raw reach exists for a reason

2. **Helm still prefers shell-first power**
   - the desktop model should be strong enough that raw automation becomes an exception rather than the substrate

3. **Tiering is mandatory**
   - shell graph, structural UI graph, and raw lane are not the same thing

4. **Automation must remain visible**
   - visibility, killability, and inspection are part of the contract

## Wiring

- decision surface: `decision-map.md` (D-AUTO)
- related docs: `control-tier-boundary-v0.md`, `structural-ui-graph-posture-v0.md`, `raw-automation-lane-posture-v0.md`
