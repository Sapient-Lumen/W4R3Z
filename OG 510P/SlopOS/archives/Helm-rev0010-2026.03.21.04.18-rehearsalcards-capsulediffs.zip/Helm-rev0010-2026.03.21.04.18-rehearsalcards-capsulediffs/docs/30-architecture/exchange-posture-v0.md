# D-EXCHANGE Exchange posture v0 (typed movement, exact routes)

Purpose: define Helm's transfer surface so paste, drop, clipboard, share, attach, forward, import, and export become explicit shell-owned packet and route truth rather than helper magic.

## Posture (v0)

1. **Exchange is one typed movement family**
   - paste, drop, clipboard, share, attach, forward, import, export, and object handoff should compose through typed packets and routes instead of flattening into raw text or raw paths

2. **Ingress is inert until routed**
   - packets may be inserted, inspected, quoted, imported, staged, attached, or sent
   - they should not silently inherit execution or strong-action authority just because they arrived from clipboard, drop, or a visible selection

3. **Selection, intent, and route witness stay explicit**
   - open, reveal, insert, import, send, attach, and forward are different actions
   - Exchange should preserve exact subject identity and record whether the route was exact, mediated, held, downgraded, or denied

4. **Transfer truth belongs across the shell**
   - Object Browser, Omnibox, Desktop Flow, terminal/capshell, Recall, and Operations Center should all be able to originate, inspect, or receive transfer receipts

5. **Approximate convenience must not hide widening**
   - helper-like behaviors may exist, but they must not erase exactness, subject identity, or mediation posture

## v0 must exist

- typed ingress for clipboard, paste, drop, and file-like payloads with inspect / insert / import choices
- typed selection/intent routes that keep open / reveal / send / attach / forward distinct
- visible transfer, attach, and forward receipts plus hold/deny reasons
- shell-visible subject identity and exactness posture for strong routes

## Temptations to ban early

- path paste as the universal file-transfer UX
- silent promotion from selected thing to execution target
- “smart click” behavior that hides the real route or exactness class
- flattening typed payloads into lossy strings too early

## Phase 1 non-goals

- freezing one universal clipboard backend
- freezing one final packet schema for every transfer kind
- importing ambient host helper behavior as invisible fallback

## Wiring

- decision surface: `decision-map.md` (D-EXCHANGE)
- related docs: `ingress-packets-posture-v0.md`, `object-browser-posture-v0.md`, `omnibox-posture-v0.md`, `desktop-flow-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`, `operations-center-posture-v0.md`
- design pressures carried forward from SlopOS/Schell: typed transfer, import-vs-open separation, selection packets, intent packets, route witnesses, attach/forward honesty
- assurance anchors: CH-HELM-0014, I-HELM-0013
