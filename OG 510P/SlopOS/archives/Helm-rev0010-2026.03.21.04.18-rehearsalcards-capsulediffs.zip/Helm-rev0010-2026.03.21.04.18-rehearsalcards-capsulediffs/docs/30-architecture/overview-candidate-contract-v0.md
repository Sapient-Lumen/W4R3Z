# Overview candidate contract v0

Purpose: name the spatial companion to Omnibox without prematurely freezing a whole worldview.

Overview is **not** a new pillar.
It is a candidate shell surface that may become essential because Helm otherwise risks becoming powerful but too non-spatial.

## Candidate posture

1. **Overview is the spatial companion to Omnibox**
   - Omnibox is sparse, typed, and direct
   - Overview is glanceable, spatial, and immediate

2. **Overview should render shell truth, not parallel folklore**
   - windows
   - workspaces
   - focus state
   - continuity cues
   - layout state
   - maybe capsule entrypoints

3. **Type-to-search should still be present**
   - Overview should complement Omnibox, not trap users in pointer-only navigation

4. **Fast move / quick act / quick jump matter**
   - jump to workspace
   - move window
   - reopen/reenter from Recall cues
   - maybe launch or route from the same surface

5. **Operations truth must stay consistent**
   - Overview should not invent a second hidden state model separate from Operations Center or the shell graph

## Candidate v0 specimen

A narrow slice could be:
- show all workspaces,
- show focused and visible windows,
- show one Recall cue per workspace,
- permit quick keyboard jump and one window move,
- and allow typing to narrow or jump.

## Guardrails

- do not copy GNOME or KDE whole
- do not let Overview become a decorative mode disconnected from shell truth
- do not let it compete with Omnibox for semantic dispatch

## Working stance

Overview is increasingly plausible as a real Helm surface, but Helm should earn it through a compact specimen first rather than declaring a giant overview worldview.
