# D-OBJ Object Browser posture v0

Purpose: define Helm's first-party object/document browser as a shell surface, not a generic path browser clone.

## Posture (v0)

1. **Object-centric first**
   - browsing may present path-like views, but the substrate is object references, query views, and shell-owned reveal semantics

2. **Strong bulk and navigation workflows**
   - split views, selection, rename/move/copy, preview, and quick actions matter

3. **Query views are first-class**
   - saved and live filtered views belong to the shell product

4. **Reveal exactness is mandatory**
   - “show item” means exact reveal/select or fail closed

5. **The Object Browser participates in Desktop Flow, Recall, and Exchange**
   - selections, views, object actions, reopen targets, and transfer routes are graphable

## v0 must exist

- split views, strong keyboard navigation, and bulk operations
- query views plus saved smart views
- preview and exact reveal/select over shell-owned object identity
- exact reopen/reentry to supported shell-owned objects and exchange/attach entrypoints over those objects

## Temptations to ban early

- reducing the browser to a path-only explorer
- treating smart views as optional garnish
- accepting fuzzy reveal as “good enough” because older systems did

## Phase 1 non-goals

- reducing the browser to a path-only explorer
- treating smart views as an optional afterthought

## Wiring

- decision surface: `decision-map.md` (D-OBJ)
- related docs: `object-query-posture-v0.md`, `reveal-exactness-boundary-v0.md`, `handler-routing-boundary-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0005, I-HELM-0003
