# D-SGRAPH shell graph posture v0

Purpose: define the primary programmable truth surface of the Helm desktop.

## Posture (v0)

1. **The shell graph is the primary automation target**
   - common desktop power should act on shell-owned objects before reaching for raw UI automation

2. **The shell graph contains typed desktop objects**
   - window/surface
   - workspace
   - selection
   - object reference
   - query view
   - job
   - notification
   - shell action
   - automation session
   - background presence record

3. **Identity is stable enough for routing and debugging**
   - graph nodes must be inspectable and referable without relying on window titles or screen coordinates as the primary truth

4. **The graph is live**
   - events and state changes are visible enough to drive Desktop Flow and Operations Center

5. **The graph is not just a debugging API**
   - it is a product surface

## Phase 1 non-goals

- full semantic modeling of every app-internal UI
- replacing all raw automation use cases on day one

## Wiring

- decision surface: `decision-map.md` (D-SGRAPH)
- related docs: `desktop-flow-posture-v0.md`, `operations-center-posture-v0.md`, `object-browser-posture-v0.md`
- assurance anchors: CH-HELM-0003, I-HELM-0005
