# Decision map

## D-BASE
Base product surface posture.

## D-EXEMPLARS
Exemplar translation posture.

## D-PILLARS
Pillar contracts posture.

## D-COMP
Helm compositor posture and shell-owned desktop truth.

## D-SGRAPH
Shell graph posture.

## D-TILE
Tiling-first hybrid shell posture.

## D-ACT
Activation control boundary.

## D-INPUT
Input routing posture.

## D-OMNI
Omnibox posture.

## D-OMNIPROV
Omnibox provider posture.

## D-OBJ
Object Browser posture.

## D-QVIEW
Object query / query-view posture.

## D-REVEAL
Reveal exactness boundary.

## D-ROUTE
Handler routing boundary.

## D-SESSION
Session/profile selection boundary.

## D-OPS
Operations Center posture.

## D-BGPRES
Background presence posture.

## D-ATTN
Attention posture.

## D-FLOW
Desktop Flow posture.

## D-FLOWOBS
Desktop Flow observability / reusable-fragment posture.

## D-FLOWENTRY
Flow entrypoint posture.

## D-FLOWFAIL
Flow failure inspection posture.

## D-CTRLTIERS
Control-tier boundary.

## D-SUIG
Structural UI graph posture.

## D-RAWAUTO
Raw automation lane posture.

## D-AUTO
UI automation family posture.

## D-RECALL
Recall posture.

## D-EXCHANGE
Exchange posture.

## D-TERM
Terminal posture.

## D-CAPSHELL
Capshell posture.

## D-LINEAGE
Shell session-lineage posture.

## D-REVIEW
Reviewed action and receipt posture.

## D-EXGROUND
Execution-ground posture.

## D-INGRESS
Ingress packet posture.
