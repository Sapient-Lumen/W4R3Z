# D-FLOW Desktop Flow posture v0 (visible programmable desktop control)

Purpose: make programmable desktop control a first-class Helm surface.

## Posture (v0)

1. **Desktop Flow is base product**
   - hotkeys, rules, timers, snippets, object actions, layout policies, recall jumps, and exchange routes are all candidates for graph entrypoints

2. **The primary target is the shell graph**
   - windows
   - workspaces
   - selections
   - object references
   - query views
   - notifications
   - jobs
   - recall targets
   - exchange packets/routes
   - shell actions

3. **Typed nodes and edges**
   - Desktop Flow is not just “run arbitrary script”
   - nodes operate on typed desktop objects and actions

4. **Live inspectability**
   - active flows, last-triggered entrypoints, failures, suspension/disablement state, and authority tier crossings should be inspectable

5. **Flow support machinery is required**
   - debug/event lanes, graph outline/search, node status, and reusable inspectable fragments are not optional garnish

6. **Deterministic scheduling where possible**
   - the graph should avoid “sleep and pray” as baseline structure

7. **Scratchpad speed matters**
   - quick local flows must be easy enough to preserve one-minute-hack energy

8. **Shell-facing flow actions should be reviewable where side effects matter**
   - flow should be able to hand off to reviewed shell actions rather than flattening everything into fire-and-forget scripts

## v0 must exist

- hotkeys, rules, timers, recall jumps, exchange routes, and object actions as first-class entrypoints
- typed shell-graph nodes with low-latency execution
- visible failure, disablement, and last-trigger inspection
- debug/event lane, graph outline/search, and reusable inspectable fragments

## Temptations to ban early

- treating “arbitrary script box” as the whole product
- making safe local flows so ceremonial that one-minute hacks die
- letting raw UI injection become the default target even for shell-owned tasks
- shipping only a canvas and deferring observability/reuse indefinitely

## Phase 1 non-goals

- replacing all text scripting
- requiring ceremony so heavy that local power-user tweaks become painful

## Wiring

- decision surface: `decision-map.md` (D-FLOW)
- related docs: `flow-observability-posture-v0.md`, `shell-graph-posture-v0.md`, `flow-entrypoint-posture-v0.md`, `flow-failure-inspection-posture-v0.md`, `control-tier-boundary-v0.md`, `reviewed-action-receipt-posture-v0.md`, `recall-posture-v0.md`, `exchange-posture-v0.md`, `pillar-contracts-v0.md`
- assurance anchors: CH-HELM-0003, I-HELM-0005
