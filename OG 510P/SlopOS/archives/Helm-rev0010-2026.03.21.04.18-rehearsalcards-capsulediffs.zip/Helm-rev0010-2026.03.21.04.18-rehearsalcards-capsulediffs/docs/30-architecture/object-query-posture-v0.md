# D-QVIEW object query posture v0 (query views are shell-owned)

Purpose: pin Helm's stance that saved/live object queries are part of the shell, not merely app-private search widgets.

## Posture (v0)

1. **Query views are first-class shell objects**
   - a query view can be opened, revisited, routed, and acted on

2. **Queries are view-scoped, not ambient full-desktop omniscience**
   - the shell owns the scope and semantics of what a view can see

3. **Selections and bulk actions preserve view meaning**
   - actions performed from a query view keep enough context to remain explainable

4. **Queries are inspectable**
   - users can understand what a saved view means

## Phase 1 non-goals

- universal semantic indexing of everything from day one
- silent app-side query persistence defining desktop truth

## Wiring

- decision surface: `decision-map.md` (D-QVIEW)
- related docs: `object-browser-posture-v0.md`, `desktop-flow-posture-v0.md`
