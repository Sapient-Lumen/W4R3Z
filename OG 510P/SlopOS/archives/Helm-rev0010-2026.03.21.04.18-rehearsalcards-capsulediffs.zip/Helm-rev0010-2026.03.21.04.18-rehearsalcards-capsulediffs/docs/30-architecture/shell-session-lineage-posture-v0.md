# D-LINEAGE shell session-lineage posture v0 (history is too thin)

Purpose: import the most load-bearing Schell lesson into Helm without freezing a final shell language.

## Posture (v0)

1. **History alone is not enough**
   - shell-facing actions should preserve enough lineage to explain what was requested, approved, launched, and observed

2. **Lineage is first-class across shell surfaces**
   - terminal
   - omnibox
   - object browser actions
   - desktop flow entrypoints
   - operations center receipts

3. **Lineage must survive beyond fancy rendering**
   - the truth cannot live only in one terminal widget or one transient review surface

4. **Restoration stays visibly restored until live truth is reacquired**
   - restored shells, panes, and action views must not pretend they are fresh live authority without reacquisition

## Phase 1 non-goals

- full durable event sourcing for every desktop twitch
- freezing Schell's final lineage serialization

## Wiring

- decision surface: `decision-map.md` (D-LINEAGE)
- related docs: `capshell-posture-v0.md`, `terminal-posture-v0.md`, `reviewed-action-receipt-posture-v0.md`, `operations-center-posture-v0.md`
- assurance anchors: CH-HELM-0007, I-HELM-0007
