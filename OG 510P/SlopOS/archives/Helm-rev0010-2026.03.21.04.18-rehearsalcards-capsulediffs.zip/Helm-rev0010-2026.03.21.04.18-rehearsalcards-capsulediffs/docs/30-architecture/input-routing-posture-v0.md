# D-INPUT input routing posture v0 (focus-gated, shell-governed)

Purpose: pin how pointer and keyboard input flows through Helm.

## Posture (v0)

1. **Input routing follows shell focus policy**
   - focused truth is shell-owned

2. **Observation and injection are distinct**
   - seeing input or UI structure does not imply sending input

3. **No ambient global event-tap baseline**
   - broad observation/injection belongs to explicit control tiers, not the default desktop substrate

4. **Trusted or sensitive surfaces may narrow visibility and injection**
   - the shell/compositor may harden specific surfaces beyond general automation rules

## Phase 1 non-goals

- universal ambient keyloggable desktop substrate
- compatibility hooks as product truth

## Wiring

- decision surface: `decision-map.md` (D-INPUT)
- related docs: `compositor-posture-v0.md`, `control-tier-boundary-v0.md`, `raw-automation-lane-posture-v0.md`
