# D-SESSION session/profile selection boundary v0

Purpose: pin Helm's stance that applications do not own global profile/session-selection semantics by default.

## Boundary (v0)

1. **Session/profile selection is not requester-authoritative**
   - opening an object does not let the requester choose arbitrary app session/profile state as part of the base contract

2. **Shell-owned selection may exist locally**
   - the shell may expose local chooser UX or routing rules
   - but this is not widened into a general requester-controlled capability

3. **Compatibility pressures are not design truth**
   - browser-profile or per-app-session habits from legacy systems do not silently define Helm semantics

4. **Future widening must be explicit**
   - if Helm later standardizes session/profile control for a specific family, it must do so on its own surface

## Wiring

- decision surface: `decision-map.md` (D-SESSION)
- related docs: `handler-routing-boundary-v0.md`, `activation-control-boundary-v0.md`
- assurance anchors: I-HELM-0006
