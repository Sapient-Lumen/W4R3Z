
# Research bibliography — 2026-03-21 — pass III

Purpose: keep a compact memory of the outside sources used in pass III.

## Microsoft / Windows

- PowerToys overview — https://learn.microsoft.com/en-us/windows/powertoys/
- PowerToys Command Palette overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- Command Palette extensibility overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/extensibility-overview
- Command Palette extension toolkit namespace — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/microsoft-commandpalette-extensions-toolkit/microsoft-commandpalette-extensions-toolkit
- PowerToys Workspaces — https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- FancyZones — https://learn.microsoft.com/en-us/windows/powertoys/fancyzones
- Peek — https://learn.microsoft.com/en-us/windows/powertoys/peek
- Crop And Lock — https://learn.microsoft.com/en-us/windows/powertoys/crop-and-lock
- PowerToys Run — https://learn.microsoft.com/en-us/windows/powertoys/run
- PowerToys administrator mode — https://learn.microsoft.com/en-us/windows/powertoys/administrator
- File Explorer add-ons — https://learn.microsoft.com/en-us/windows/powertoys/file-explorer

## Apple / macOS

- Spotlight — https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac
- Spotlight narrowing — https://support.apple.com/guide/mac-help/narrow-search-results-in-spotlight-mchl4d69efd3/mac
- Spotlight keyboard shortcuts — https://support.apple.com/guide/mac-help/spotlight-keyboard-shortcuts-mh26783/mac
- Quick Look — https://support.apple.com/guide/mac-help/preview-a-file-mh14119/mac
- Finder Preview pane — https://support.apple.com/guide/mac-help/use-the-preview-pane-in-the-finder-on-mac-mchl1e4644c2/mac
- Finder Quick Actions — https://support.apple.com/guide/mac-help/perform-quick-actions-in-the-finder-on-mac-mchl97ff9142/mac
- Smart Folders — https://support.apple.com/guide/mac-help/create-or-change-a-smart-folder-on-mac-mchlp2804/mac
- Finder search criteria — https://support.apple.com/en-by/guide/mac-help/mh15155/mac

## KDE / GNOME

- KRunner — https://docs.kde.org/trunk_kf6/en/plasma-desktop/plasma-desktop/krunner.html
- Plasma Activities — https://docs.kde.org/?application=plasma-desktop&branch=stable5&language=en&path=activities-interface.html
- GNOME Activities overview — https://help.gnome.org/gnome-help/shell-introduction.html
- GNOME windows and workspaces — https://help.gnome.org/gnome-help/shell-windows.html
- GNOME keyboard shortcuts — https://help.gnome.org/gnome-help/shell-keyboard-shortcuts.html

## Raycast / Alfred / Obsidian / VS Code

- Raycast home — https://www.raycast.com/
- Raycast Quicklinks — https://manual.raycast.com/quicklinks
- Raycast dynamic placeholders — https://manual.raycast.com/dynamic-placeholders
- Raycast snippets (Windows manual) — https://manual.raycast.com/windows/snippets
- Alfred snippets — https://www.alfredapp.com/help/features/snippets/
- Alfred snippet triggers — https://www.alfredapp.com/help/workflows/triggers/snippet/
- Obsidian Workspaces — https://help.obsidian.md/plugins/workspaces
- VS Code user interface — https://code.visualstudio.com/docs/getstarted/userinterface
- VS Code code navigation / breadcrumbs — https://code.visualstudio.com/docs/editing/editingevolved
- VS Code Timeline release note — https://code.visualstudio.com/updates/v1_44
- VS Code custom layout — https://code.visualstudio.com/docs/configure/custom-layout
- VS Code 1.108 update (copy breadcrumbs path) — https://code.visualstudio.com/updates/v1_108

## Graph systems / historical influences

- Node-RED sidebar — https://nodered.org/docs/user-guide/editor/sidebar/
- Node-RED debug sidebar — https://nodered.org/docs/user-guide/editor/sidebar/debug
- Node-RED information sidebar — https://nodered.org/docs/user-guide/editor/sidebar/info
- Node-RED subflows — https://nodered.org/docs/user-guide/editor/workspace/subflows
- Node-RED handling errors — https://nodered.org/docs/user-guide/handling-errors
- Unreal Blueprint workflow tools — https://docs.unrealengine.com/4.26/en-US/ProgrammingAndScripting/Blueprints/Workflow
- Godot debugging overview — https://docs.godotengine.org/en/stable/tutorials/scripting/debug/overview_of_debugging_tools.html
- Godot debugger panel — https://docs.godotengine.org/en/stable/tutorials/scripting/debug/debugger_panel.html
- Plan 9 from User Space manual index — https://9fans.github.io/plan9port/man/man1/
- Plan 9 page viewer — https://9fans.github.io/plan9port/man/man1/page.html

## Working take

The best sources in this pass were not “desktop trend reports”.
They were concrete manuals showing where preview, routing, snippets, layouts, workspaces, and graph debugging become durable user value.
