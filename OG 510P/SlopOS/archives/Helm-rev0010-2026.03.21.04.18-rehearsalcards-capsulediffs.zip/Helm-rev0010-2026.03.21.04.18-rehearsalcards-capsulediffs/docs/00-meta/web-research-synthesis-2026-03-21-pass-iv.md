
# Web research synthesis — 2026-03-21 — pass IV

Purpose: keep harvesting brilliant ideas for Helm without widening the pillar set or freezing too much too early.

This pass concentrates on three moves that now feel especially promising:
1. action rehearsal and route cards,
2. capsule diffs and truthful continuity views,
3. shell-owned layout templates with rebinding.

## What this pass says at a glance

Most current desktop tools still hide their best powers inside helper suites, app-local memory, or mini-automation islands.
Helm should steal the *human value* of those features while absorbing the authority into shell-owned surfaces.

Strong candidate moves:
- a rehearsal card for strong actions,
- a capsule diff surface for restore honesty,
- a layout template model that cooperates with capsules instead of competing with them,
- and richer Omnibox result cards/forms/progress where the shell can still inspect the provider truth.

## Cluster 1 — result cards, forms, and progress

### What current systems teach

PowerToys Command Palette has matured beyond a flat launcher list.
Its extension model includes pages, forms, details, filters, tags, settings, and progress state.
That is a reminder that an action surface can stay compact while still carrying real structure.

### What Helm should steal

Helm should likely grow **result cards** or **action cards** inside Omnibox and related surfaces:
- typed details,
- compact input forms,
- progress views,
- review status,
- and exact provider identity.

This matters because many of Helm's best moves will not fit inside a one-line result row.

### What Helm should refuse

- provider-specific local state machines that the shell cannot inspect
- hiding review or route truth inside an opaque card
- a card system that silently becomes a second app platform

## Cluster 2 — truthful continuity needs diffs

### What current systems teach

VS Code's Timeline keeps showing the value of a unified event history for the active file.
Obsidian Workspaces keeps showing the appeal of named task-specific layouts.
PowerToys Workspaces keeps showing that users want one-shot return to a known desktop arrangement.

But those systems also reveal a risk: capture/restore is attractive long before it becomes honest.

### What Helm should steal

Helm should likely invent a **capsule diff** surface:
- current desktop state vs selected capsule,
- exact matches,
- repaired bindings,
- missing or unavailable pieces,
- and likely reentry effects before restore.

That would make Recall feel much more truthful and much less like glamorous session folklore.

### What Helm should refuse

- restore buttons that pretend exactness when they are about to repair or skip
- app-local history panes claiming shell-wide continuity truth
- giant continuity products before one good diff specimen exists

## Cluster 3 — layout templates should be shell luxuries, not a side religion

### What current systems teach

FancyZones proves that users love editable spatial templates.
PowerToys Workspaces proves they also love saving a whole arrangement and returning to it quickly.
The best part of those moves is not the helper utility itself; it is the feeling that the desktop can remember and reapply useful structure.

### What Helm should steal

Helm should likely add a candidate notion of **layout templates with rebinding**:
- shell-owned slot templates,
- anchor rules,
- rebinding proposals when the exact target is absent,
- and composition with capsules rather than competition.

### What Helm should refuse

- separate zone-manager product logic outside Tiling Shell
- templates that only work by window-title folklore
- layout restore that cannot explain rebinding decisions

## Cluster 4 — typed personal accelerators remain a huge delight multiplier

### What current systems teach

Raycast Quicklinks and dynamic placeholders remain a strong proof that tiny personal accelerators matter.
The important lesson is not “users like macros.”
It is that people love small reusable actions that pick up context and stay quick.

### What Helm should steal

Helm should keep pressuring typed seeds and result cards together:
- a seed can expand into a route card,
- a route card can ask for one or two typed fields,
- and the shell can still keep preview, review, and provider truth visible.

This could preserve a lot of Rofi/AHK/Raycast delight without regressing to ambient script culture.

## Cluster 5 — visual programming scales only when it can be inspected and rehearsed

### What current systems teach

Node-RED's debug sidebar and structured message inspection, plus reusable subflows, keep proving that visual graphs only stay usable when runtime packets are inspectable.
Unreal Blueprints makes the same point from a different direction with debugger support.

### What Helm should steal

Desktop Flow should probably gain pressure toward **rehearsal**:
- show what packet would enter,
- show what route or card would be produced,
- and expose the uncertainty boundary before a strong effect lands.

This is very close to DelayBasin's rehearsal instinct, but translated into Helm product language.

## What now looks strongest

Highest-value candidate moves to keep live:
1. action / result / route cards with typed details and progress
2. capsule diffs for Recall honesty
3. layout templates with visible rebinding
4. typed seeds that can open cards instead of only expanding text
5. rehearsal surfaces for Desktop Flow and strong shell actions

## What still does not need a hard freeze yet

- final card taxonomy across Omnibox, Preview, Exchange, and Operations Center
- exact capsule diff schema
- exact template anchor language
- whether rehearsal becomes a named shell-wide family or stays a narrow reviewed-action luxury

## Working stance

Helm should keep stealing features that make users feel *oriented, powerful, and unsurprised*.
That usually means visible cards, visible diffs, and visible rebinding — not more hidden helpers.
