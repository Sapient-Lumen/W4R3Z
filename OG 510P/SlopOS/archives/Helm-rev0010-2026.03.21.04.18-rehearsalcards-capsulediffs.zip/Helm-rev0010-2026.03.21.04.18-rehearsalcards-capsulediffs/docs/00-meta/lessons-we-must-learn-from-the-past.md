# Lessons we must learn from the past

Purpose: separate **hard-earned desktop lessons** from shiny feature collection.

This is a Helm doc, not a nostalgia shrine. The point is to remember which patterns repeatedly worked, which repeatedly rotted, and which only looked powerful because users had no better substrate.

## The must-learn list

### 1. Ambient authority always feels better before it feels worse

Old desktop power cultures often won because they gave users immediate leverage:
- global hooks
- synthetic input
- scriptable titles and classes
- path-paste glue
- helper processes that could touch anything

That power is real.
But it reliably creates:
- invisible persistence
- weak explainability
- race-condition automation
- security surprises
- support nightmares
- “I do not know why my desktop just did that” moments

Helm must keep the reach while refusing the ambience.

### 2. Window management alone is never enough

Great WMs matter, but they are not the whole desktop.

Past systems often overfit to:
- placement
- decoration
- tiling algorithms
- config elegance

and underfit to:
- browsing
- continuity
- routing
- transfer truth
- operations honesty
- automation introspection

Helm should remember that the window surface is only one face of desktop truth.

### 3. Launchers become central the moment they stop being launchers

The best summon surfaces evolve from:
- “run this app”
to
- “find the thing, switch the context, take the action, and show me why”

The lesson is not “build a cooler launcher.”
The lesson is:
**the summon surface becomes central when it understands real desktop objects and actions.**

### 4. File managers stagnate when search and preview are bolt-ons

The past keeps teaching this:

A browser that only excels at folder traversal eventually feels cramped.
The winning moves are:
- instant preview
- query views
- tags/attributes
- saved views
- strong bulk operations
- exact reveal
- good keyboard paths

Helm should make those normal, not optional.

### 5. “Recent items” is not continuity

Many desktops quietly substituted:
- recent files
- shell history
- toasts
- app-local restore
for actual continuity.

That is not enough.

Users need:
- where they were
- what state was live
- whether a return is exact or approximate
- what changed
- what is gone
- what still needs permission or repair

Recall only earns its place if it provides that.

### 6. “Task manager” UIs usually explain the wrong machine

Classic task managers center:
- processes
- memory
- CPU
- kill buttons

That is useful but incomplete.
Modern desktop truth also includes:
- jobs
- flows
- routes
- transfers
- background presence
- grants
- restore failures
- denied actions

Helm should not regress to process theater.

### 7. Visual programming without observability becomes decorative spaghetti

The graph is not the magic.
The support machinery is the magic:
- debug views
- status cues
- error surfaces
- packageable subgraphs
- search and outline
- performance visibility
- disable/hold/breakpoint-like moves

Desktop Flow needs those from day one of serious use.

### 8. Users love spatial overview when it is fast and honest

Overviews succeed when they:
- reduce lost-window anxiety
- make workspace state legible
- allow direct manipulation
- stay keyboard-friendly

They fail when they:
- become heavy
- become mouse-only theater
- hide exactness
- split from the main action model

Helm should steal the good version.

### 9. Session restore should always admit when it is bluffing

Approximate restore can be extremely valuable.
The mistake is pretending it is exact.

Helm should normalize badges like:
- exact
- repaired
- partial
- unavailable

and make the reasons inspectable.

### 10. Extensibility wins, but only when the host keeps the law

Plugin systems are worth having.
But the host must still own:
- review
- lifecycle
- receipts
- exactness
- visibility
- failure reporting
- revocation

Helm should not let extension culture erase shell law.

## What this means for Helm

We should protect these directions aggressively:

- shell-owned truth over folklore
- exactness over “helpful” approximation where promises matter
- visible raw power over ambient raw power
- preview/query/overview as normal desktop moves
- continuity and transfer as first-class product concerns
- better debugging and honesty surfaces than old desktop power cultures ever had

## Things to keep repeating to ourselves

- The goal is not to make hacks impossible; it is to make them non-foundational.
- The goal is not to freeze everything early; it is to freeze the right invariants.
- The goal is not to copy historical apps; it is to preserve the powers they made feel indispensable.
