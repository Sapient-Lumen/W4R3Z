# Question machine

Purpose: keep Helm's live uncertainties explicit without turning the archive into pure question bureaucracy.

## Rule

A Helm question deserves a registry entry when all three are true:

1. the uncertainty is load-bearing for product direction or archive honesty,
2. the answer is not yet earned, and
3. leaving it in prose would likely cause repeated argument or silent widening.

## States

- `open` — important, but not yet narrowed enough
- `narrowed` — bounded enough to name the next proof surface
- `prototyping` — a specimen or proof-bearing slice is now the next move
- `resolved` — the question has been closed, replaced, or retired

## What not to do

- do not register every curiosity
- do not use the registry as a substitute for architecture docs
- do not let resolved questions linger as if they were still live

## Helm-specific pressure

Helm especially needs this discipline around:
- shell graph scope,
- Recall and Exchange specimen families,
- the raw automation lane,
- the Helm/Schell freeze boundary,
- and future import passes from special cubes or companion datacubes.
