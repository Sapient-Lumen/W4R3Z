# Charter

Helm exists to make a desktop that is:

- explicit rather than ambient
- programmable rather than extension-haunted
- object-centric rather than path-and-window folklore first
- continuous rather than amnesiac
- typed in how things move rather than clipboard-and-helper folklore first
- powerful for operators without becoming mysterious
- native to a capability system rather than adapted from POSIX desktop assumptions

Helm also exists to keep its own design archive honest:

- startup should be low-entropy
- status should not depend on chronology alone
- imported pressure should be bounded and durable
- live questions and followthrough should not dissolve into prose

Helm is not trying to preserve Linux desktop compatibility as product truth.
