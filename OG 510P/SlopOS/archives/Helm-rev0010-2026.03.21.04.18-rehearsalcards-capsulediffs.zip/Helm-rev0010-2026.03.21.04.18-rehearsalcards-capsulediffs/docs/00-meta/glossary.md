# Glossary

## Helm
The desktop shell/compositor product.

## Desktop Flow
Helm's visible graph control fabric.

## Shell graph
The live graph of shell-owned desktop objects such as windows, workspaces, selections, objects, jobs, and shell actions.

## Structural UI graph
An explicit graph of UI structure and interactable surfaces when granted.

## Raw automation lane
The explicit lane for presentation-oriented observation and input injection.

## Object Browser
Helm's first-party document/object/query surface.

## Operations Center
Helm's first-party operations and authority monitor.

## Query view
A shell-owned saved or live view over objects; not merely an app-private search widget.

## Reveal exactness
“Show this item” means exact reveal/select or fail closed.
