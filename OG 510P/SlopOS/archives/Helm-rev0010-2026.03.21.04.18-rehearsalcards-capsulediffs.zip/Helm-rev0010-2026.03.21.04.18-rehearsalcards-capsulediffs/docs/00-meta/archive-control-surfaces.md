# Archive control surfaces v0

Purpose: name the compact surfaces that keep Helm's archive honest across revisions.

## Surfaces

- `START_HERE.md`
  - shortest trustworthy human/LLM reentry surface
- `AGENTS.md`
  - even shorter derivative wrapper for future maintainers
- `context-pack.json`
  - compact machine-readable startup packet
- `SURFACE-STATUS.json`
  - operational head, citation head, and status lanes
- `REVISION-RECEIPT.json`
  - why the latest revision counted
- `QUESTION-REGISTRY.json`
  - live load-bearing open questions
- `ASSUMPTION-LEDGER.json`
  - assumptions still being spent
- `FOREIGN-PRESSURE-LEDGER.json`
  - imported pressure plus bounded takes and explicit non-takes
- `FOLLOWTHROUGH-QUEUE.json`
  - next proof points and waiting inputs that should not disappear
- `RESOLUTION-LEDGER.json`
  - compact memory of what local archive gaps have been closed
- `ARCHIVE_INDEX.md`
  - packaged revision lineage

## Intent

These surfaces are **not** product pillars.
They are the archive machinery that keeps the product pillars from drifting, being silently re-litigated, or being widened by remembered vibe.

## Non-goals

- creating a giant bureaucratic layer around every small move
- replacing architecture docs with ledger entries
- importing DelayBasin's whole method constitution into Helm

## Working rule

Add a new archive-control surface only when it preserves state that would otherwise be repeatedly reconstructed, silently widened, or quietly forgotten.
