# Research bibliography — 2026-03-21 — pass I

This bibliography is intentionally compact. It records the outside sources that informed `web-research-synthesis-2026-03-21-pass-i.md`.

## Current tools and support docs

- Microsoft PowerToys Command Palette overview
- Microsoft PowerToys Workspaces
- Microsoft PowerToys FancyZones
- Microsoft PowerToys Peek
- Apple Spotlight help
- Apple Quick Look help
- Apple Smart Folders help
- Apple Finder tags help
- KDE KRunner user docs and runner plugin docs
- GNOME Activities overview, workspaces, file browsing, and search help
- Node-RED sidebar/debug/info/subflow docs
- Unreal Engine graphs / blueprints docs

## Historical systems and papers

- Plan 9 plumbing docs
- Plan 9 acme paper
- Plan 9/acme/plumber support pages

## How to read this bibliography

Helm uses these sources for:
- feature patterns worth stealing
- proof that certain workflows already resonate with users
- negative examples where a useful move lived inside the wrong substrate

Helm does **not** treat any one of these as a blueprint to port.
