
# Research bibliography — 2026-03-21 — pass IV

## Teacher cubes re-read

- SlopOS-rev0572-2026.03.21.01.03-openuri-session-selection-boundary.zip
- Schell-rev0023-2026.03.21.00.15-remotehops-peerwitnesses-attachhonesty-forwardguards-farshore.zip
- DelayBasin-rev0124-2026.03.20.23.59-openquestionanchors-hotsetrefs-contextpackfreshness-lanternwake.zip

## Outside references used in this pass

- PowerToys Command Palette overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/overview
- PowerToys Command Palette extensibility overview — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/extensibility-overview
- PowerToys Command Palette extension namespaces / toolkit docs — https://learn.microsoft.com/en-us/windows/powertoys/command-palette/microsoft-commandpalette-extensions/microsoft-commandpalette-extensions and https://learn.microsoft.com/en-us/windows/powertoys/command-palette/microsoft-commandpalette-extensions-toolkit/microsoft-commandpalette-extensions-toolkit
- PowerToys Peek — https://learn.microsoft.com/en-us/windows/powertoys/peek
- PowerToys Workspaces — https://learn.microsoft.com/en-us/windows/powertoys/workspaces
- FancyZones — https://learn.microsoft.com/en-us/windows/powertoys/fancyzones
- Apple Spotlight search / actions / shortcuts — https://support.apple.com/guide/mac-help/search-with-spotlight-mchlp1008/mac and https://support.apple.com/guide/mac-help/take-actions-and-shortcuts-in-spotlight-mchl4953dfeb/mac and https://support.apple.com/guide/mac-help/spotlight-keyboard-shortcuts-mh26783/mac
- Apple Quick Look / Finder Quick Actions — https://support.apple.com/en-us/102650 and https://support.apple.com/guide/mac-help/perform-quick-actions-in-the-finder-on-mac-mchl97ff9142/mac
- GNOME Activities overview / workspaces / keyboard navigation — https://help.gnome.org/gnome-help/shell-introduction.html and https://help.gnome.org/gnome-help/shell-workspaces.html and https://help.gnome.org/gnome-help/keyboard-nav.html
- KDE KRunner user docs and plugin docs — https://userbase.kde.org/Plasma/Krunner and https://develop.kde.org/docs/plasma/krunner/ and https://develop.kde.org/docs/plasma/krunner/metadata/
- Obsidian Workspaces — https://help.obsidian.md/plugins/workspaces
- VS Code user interface / timeline / breadcrumbs / layout — https://code.visualstudio.com/docs/getstarted/userinterface and https://code.visualstudio.com/docs/editing/editingevolved and https://code.visualstudio.com/docs/configure/custom-layout and https://code.visualstudio.com/updates/v1_44
- VS Code agent sessions references (for Operations / Recall pressure only) — https://code.visualstudio.com/docs/copilot/agents/overview and https://code.visualstudio.com/updates/v1_105
- Raycast Quicklinks / dynamic placeholders / API surfaces — https://manual.raycast.com/quicklinks and https://manual.raycast.com/dynamic-placeholders and https://developers.raycast.com/api-reference/user-interface/actions
- Node-RED working with messages / debug sidebar / information sidebar / subflows — https://nodered.org/docs/user-guide/messages and https://nodered.org/docs/user-guide/editor/sidebar/debug and https://nodered.org/docs/user-guide/editor/sidebar/info and https://nodered.org/docs/user-guide/editor/workspace/subflows
- Unreal Blueprints visual scripting and debugger docs — https://dev.epicgames.com/documentation/en-us/unreal-engine/blueprints-visual-scripting-in-unreal-engine and https://dev.epicgames.com/documentation/en-us/unreal-engine/blueprint-debugger-in-unreal-engine
- Plan 9 plumbing and acme references — https://9p.io/sys/doc/plumb.html and https://9p.io/magic/man2html/1/acme and https://9fans.github.io/plan9port/man/man4/plumber.html
