# Archive policy

This archive is intentionally small and early.

Rules for v0:

1. Prefer many short docs over one giant spec.
2. Decision surfaces should pin meaning, not narrate history.
3. Where Helm widens authority, make the widening explicit.
4. Where a v0 stance is intentionally conservative, say so.
5. Shell truth outranks app folklore.
6. Non-POSIX means no silent inheritance of legacy shell/session contracts.
7. Startup, status, question, and receipt surfaces are part of archive truth, not process decoration.
8. Imported pressure must preserve bounded takes and explicit non-takes.
9. Add archive machinery only when it reduces drift or startup entropy.

This archive is not a codebase substitute. It is the meaning-pin for the codebase that should follow.
