# Resolved history

## rev0002

- Helm now explicitly adopts a three-tier control model instead of leaving “automation” as a single fuzzy bucket.
- The compositor is now stated as a truth-bearing part of the desktop model, not just a renderer.
- Terminal/capshell posture is separated from generic automation posture.

## rev0003

- Helm no longer treats shell-facing work as “terminal later”.
- Schell pressure is now named explicitly through lineage, reviewed action, receipt, execution-ground, and ingress docs.
- Helm can keep shipping while still leaving final shell syntax and attach/restore semantics provisional.

## rev0004

- Helm's exemplar list is now frozen as translated powers, not app-clone goals.
- The five visible pillars are now stated as one shell/compositor product surface rather than a bundle of utilities.
- Each pillar now has an explicit v0 contract describing what must exist and what should be banned early.

## rev0005

- Recall is now promoted into a first-class Helm pillar instead of being left implicit inside recents/history and shell-local continuity hints.
- Exchange is now promoted into a first-class Helm pillar instead of being left implicit inside clipboard, drag/drop, helper routing, and attach/share folklore.
- SlopOS and Schell pressure now shape Helm more directly around exact reopen/reveal, restored-vs-live honesty, typed ingress/selection packets, and route witnesses.

## rev0006

- DelayBasin is now explicitly imported as a teacher for Helm's archive machinery.
- Helm gained compact startup, context-pack, status-lane, question, assumption, foreign-pressure, followthrough, resolution, and revision-receipt surfaces.
- The archive can now preserve imported pressure and live uncertainties without depending on chronology and chat memory alone.
