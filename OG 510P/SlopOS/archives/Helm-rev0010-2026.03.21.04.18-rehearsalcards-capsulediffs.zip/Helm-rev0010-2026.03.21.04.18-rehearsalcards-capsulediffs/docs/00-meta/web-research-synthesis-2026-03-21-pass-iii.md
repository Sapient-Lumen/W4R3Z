
# Web research synthesis — 2026-03-21 — pass III

Purpose: keep collecting brilliant ideas for Helm while resisting the urge to promote every attractive move into a new pillar or hard freeze.

This pass focuses on five clusters that now look unusually useful:

1. preview plus quick actions
2. live lenses and derivative surfaces
3. typed snippets / quicklinks / placeholders
4. provider payload richness and visibility grades
5. context cues at multiple scales

## What this pass says at a glance

Strong new candidate moves:
- Preview should probably become **action-adjacent**, not just passive.
- Helm likely wants a shell-owned **live lens** object for cropped / mirrored / derived surfaces.
- Snippets, quicklinks, and placeholders are worth stealing, but only if they compile into **typed packets or flow seeds**, not raw ambient command strings.

Strong caution reinforced by current products:
- helper utilities that live outside the shell/compositor tend to demand background daemons, hidden state, or elevated privilege once users expect them to work everywhere.

## Cluster 1 — preview plus quick actions

### What current systems teach

Apple keeps proving that preview is not just an inert viewer.
Quick Look gives fast full-size previews without opening the file into its normal application, and Finder’s Preview pane can host Quick Actions near the preview itself.
PowerToys Peek extends the same instinct on Windows: instant file preview without opening full apps, including summary information for folders.

### What Helm should steal

Helm should steal **preview as a shell power with nearby typed actions**.

A good Helm take looks like:
- Preview remains inspect-before-commit.
- preview panes can surface typed quick actions or route proposals next to the preview,
- providers can expose folder/view summaries as well as file previews,
- and actions launched from preview remain provider-attributed and review-aware when strong.

### What Helm should refuse

- preview silently becoming execution
- provider-specific side effects hidden behind a preview click
- app-local preview extensions that the shell cannot inspect or govern

## Cluster 2 — live lenses and derivative surfaces

### What current systems teach

PowerToys Crop And Lock shows a surprisingly strong move: users often want a live cropped region or thumbnail of another surface so they can keep one important visual slice visible while doing something else.

This is not the same thing as ordinary tiling.
It is a **derived live surface**.

### What Helm should steal

Helm should likely grow a candidate concept of a **live lens**:
- shell-owned derivative surface,
- clearly sourced from another exact surface,
- useful in Tiling Shell, Overview, Operations Center, and maybe Recall,
- optionally interactive only under an explicit stronger posture.

Possible uses:
- keeping one dashboard region visible,
- pinning a live thumbnail of a long-running task,
- mirroring one exact reviewed/monitored area into Operations Center,
- or letting a capsule remember a visual watchpoint without pretending it is a full session.

### What Helm should refuse

- live lenses as hidden screen-scraping proxies
- silent input forwarding by default
- derivative surfaces pretending to carry stronger truth than the source surface

## Cluster 3 — typed snippets, quicklinks, and placeholders

### What current systems teach

Raycast and Alfred keep proving that people love tiny personal accelerators:
snippets, quicklinks, snippet triggers, and dynamic placeholders.
The useful part is not just text expansion. It is fast personal composition.

### What Helm should steal

Helm should steal the **small personal action** shape, but translate it upward:
- snippets become typed template seeds,
- quicklinks become typed route or jump seeds,
- placeholders bind to shell truths like active selection, current object, current workspace/capsule, clipboard packet, or active flow inputs,
- and stronger seeds can escalate into Desktop Flow entrypoints or reviewed actions.

### What Helm should refuse

- raw shell-string templating as the default substrate
- hidden scraping of the screen to populate placeholders
- snippets that bypass review/receipt/route surfaces when they perform strong actions

## Cluster 4 — provider payload richness and visibility grades

### What current systems teach

The PowerToys Command Palette extension toolkit is a good reminder that typed palette results can be richer than a flat list: pages, details, forms, progress, tags, filters, status, and commands can all live in one provider model.
Raycast’s extension surfaces also remind us that not every provider command should flood the root search by default.

### What Helm should steal

Helm should keep typed providers, but likely add pressure in two directions:
- richer typed provider payloads than just one-line results,
- and **visibility grades** such as root-visible, scoped-only, or disabled-until-enabled.

That could help Helm keep Omnibox broad without becoming noisy.

### What Helm should refuse

- allowing provider richness to smuggle in hidden local state machines the shell cannot inspect
- assuming root search should show every possible provider capability immediately

## Cluster 5 — context cues at multiple scales

### What current systems teach

VS Code’s Breadcrumbs, Outline, Timeline, and Sticky Scroll keep reinforcing the same lesson: users navigate better when location, structure, and recent time-series cues are available at multiple scales.
GNOME’s Activities overview and KDE’s KRunner/Activities pairing reinforce the same general point from the desktop side.

### What Helm should steal

Helm should keep pressuring:
- breadcrumb-like location cues in Object Browser and Recall,
- small sticky lineage/context strips where they help,
- exact-path or exact-anchor copying for objects/views,
- and Overview as a spatial cue surface rather than just a big window wall.

### What Helm should refuse

- local cues that quietly claim universal truth,
- or giant decorative overview modes that do not share the same shell graph as Omnibox and Operations Center.

## The caution current Windows utilities keep reinforcing

PowerToys is a useful warning as well as a source of ideas.
Command Palette must run in the background to be available, and PowerToys may need elevation to keep interacting with elevated apps for some utilities such as keyboard interception or moving/resizing windows.

Helm should learn the right lesson from that:
**absorb the right powers into the shell/compositor where possible instead of recreating a forever-growing helper suite that eventually asks for broader privilege just to stay consistent.**

## What now looks strongest

Highest-value candidate moves to keep live:
1. action-adjacent Preview
2. live lenses / derivative surfaces
3. typed snippet / quicklink / placeholder seeds
4. provider visibility grades and richer result payloads
5. breadcrumb / sticky-context cues where they help Recall and Object Browser

## What still does not need a hard freeze yet

- full live-lens contract
- exact placeholder family taxonomy
- Overview’s final shape
- any promise that Preview actions or lenses become universal shell services immediately

## Working stance

Helm is strongest when it steals **humane power** from current tools but refuses their helper-sprawl, ambient-macro, and privilege-creep substrate.
