# DelayBasin lessons for Helm

Purpose: record what DelayBasin should and should not teach Helm.

## The good import

DelayBasin is useful to Helm mainly as a **teacher for archive machinery**.

The strongest lessons are:

1. **Startup surfaces matter**
   - a future maintainer should not have to reconstruct the trusted entry path from chronology and file adjacency
   - Helm should keep a small `START_HERE.md`, `AGENTS.md`, and `context-pack.json`

2. **Status lanes matter**
   - candidate, admitted, packaged, and frozen-citable are different states
   - Helm should not let a mutable working tree silently masquerade as its citation head

3. **Live questions matter**
   - if an uncertainty is load-bearing, it should not float as prose only
   - Helm should keep a compact question registry rather than rediscovering the same open seams from chat memory

4. **Imported pressure should be durable**
   - SlopOS, Schell, and future cubes will keep shaping Helm
   - those imports should preserve bounded takes and explicit non-takes so later sessions do not silently widen them

5. **Revision receipts matter**
   - a revision should say why it counted, what it changed, what stayed out of scope, and which assumptions it spent

6. **Followthrough should not vanish**
   - once a next proof point or promised input becomes important, it should live somewhere durable

## The non-imports

DelayBasin should **not** make Helm into:

- a method archive first and a desktop-product archive second
- a giant constitutional stack full of ledgers with no local proof of need
- a place where archive process overwhelms product clarity
- a place where every neighboring datacube pattern becomes mandatory by prestige alone

## Working rule

Import DelayBasin where it lowers startup entropy, reduces repeated argument, or preserves exact state transitions.

Do **not** import DelayBasin where it would inflate Helm's archive faster than Helm's product decisions are actually maturing.
