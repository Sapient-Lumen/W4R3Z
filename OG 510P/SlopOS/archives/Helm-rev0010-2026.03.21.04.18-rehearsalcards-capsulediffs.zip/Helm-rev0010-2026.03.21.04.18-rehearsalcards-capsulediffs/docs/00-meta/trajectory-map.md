# Trajectory map (Helm v0 + archive-control import)

This doc is intentionally short. It exists to stop Helm from drifting into “nice utilities around an unstated desktop model” or into “good ideas remembered from chat”.

## Non-negotiables

1. **Helm is from scratch**
   - no POSIX desktop inheritance by accident
   - no porting nostalgia as product truth

2. **The exemplar list translates to powers, not clones**
   - i3 is discipline, not historical WM shape
   - AHK is programmable desktop control, not ambient hook culture
   - Rofi is unified summon-and-dispatch, not merely app launch
   - Dolphin is strong object/document browsing, not path worship
   - “god-tier task manager” is operational honesty, not process theater

3. **Shell/compositor owns desktop truth**
   - focus, activation, visibility, placement, reveal/select, continuity posture, transfer routing, and shell-object identity stay shell-owned

4. **Helm is one product with seven visible pillars**
   - Tiling Shell
   - Omnibox
   - Object Browser
   - Operations Center
   - Desktop Flow
   - Recall
   - Exchange
   - plus terminal/capshell as the native shell-facing front-end family

5. **Tiling-first, hybrid-capable**
   - keyboard-first by default
   - floating/special surfaces exist by shell decision, not by accidental legacy convention

6. **Desktop Flow is core**
   - visual desktop programming is part of base Helm, not a plugin story

7. **Automation is tiered**
   - Tier 1: shell graph
   - Tier 2: structural UI graph
   - Tier 3: raw automation lane

8. **The Object Browser is core**
   - query views, reveal exactness, durable object references, preview, bulk operations, and object-local continuity are shell concepts

9. **The Operations Center is core**
   - windows, jobs, background presence, failures, resource use, grants, automation sessions, transfers, and receipts must be visible

10. **Recall is core**
    - reentry, exact reopen/reveal, activity trail, receipts, and restored-vs-live honesty must not collapse into generic recents/history folklore

11. **Exchange is core**
    - paste, drop, clipboard, share, attach, forward, import, export, and action routing must not collapse into path paste, helper magic, or ambient execution

12. **Terminal/capshell is native, not POSIX cosplay**
    - no ambient command-string authority as default desktop glue

13. **Helm does not wait for Schell, but it does respect Schell pressure**
    - lineage over history-only
    - reviewed actions over naked side-effect launch
    - receipts over prompt-return folklore
    - explicit ingress over ambient pasted authority
    - execution grounds over prompt magic
    - restored/attached/resumed posture over fake continuity
    - route witnesses over “smart click” folklore

14. **Helm's archive needs its own control surfaces**
    - startup, status, questions, assumptions, imported pressure, followthrough, and revision receipts are part of durable archive truth, not process garnish

15. **Cross-cutting shell moves matter as much as pillars**
    - Preview should become shell-wide, not app-local
    - workspace/activity capsules should be continuity truth, not folklore session restore
    - Overview should be the spatial companion to Omnibox
    - Desktop Flow needs debug/packaging surfaces, not just a canvas
    - query views and typed routes should keep pressuring multiple pillars at once

16. **Two narrow freezes are now in**
    - Omnibox extensibility is typed-provider-first, not ambient plugin folklore
    - Desktop Flow observability and reusable fragments are required, not optional polish

## Current external idea harvest (not all frozen)

Promising non-pillar moves worth carrying forward:

- Preview as a shell-wide power
- workspace/activity capsules
- Overview as spatial companion to Omnibox
- typed providers for Omnibox
- Flow debug sidebar / outline / reusable fragments
- plumbing-grade route inspection
- visual layout/template editing
- breadcrumb / outline / timeline cues where they strengthen Recall or Object Browser
- live lenses / derivative surfaces as a shell luxury
- typed snippet / quicklink / placeholder seeds

## What Helm is

A shell/compositor product where layout, launch, browsing, operations, automation, continuity, and exchange are all part of one visible control plane.

## Base pillars

- tiling-first shell
- omnibox
- object browser
- operations center
- desktop flow
- recall
- exchange
- terminal/capshell

## Candidate proof-bearing slice

A small slice should demonstrate:

- shell-owned focus and activation
- exact reveal/select
- query views over shell objects
- Omnibox acting over the same shell graph used by Object Browser, Desktop Flow, Recall, and Exchange
- Operations Center visibility into windows/jobs/background/flows/transfers/receipts
- desktop flow over shell graph
- a Recall surface with one obvious current-live reentry cue plus restored/historical/live honesty
- an Exchange surface with typed ingress/selection packets plus exact route witnesses
- explicit raw automation session boundaries
- at least one reviewed shell-facing action with lineage and receipt truth
- typed Omnibox providers with provider-visible actions
- one Desktop Flow debug/outline/reusable-fragment slice
- startup and status surfaces that let a future maintainer land on the same current head without reconstructing it from chronology alone


## New pressure added in rev0010

- rehearsal cards / route cards for strong actions and Flow entrypoints
- capsule diffs as the honesty surface for Recall and restore
- shell-owned layout templates with rebinding instead of zone-manager folklore
