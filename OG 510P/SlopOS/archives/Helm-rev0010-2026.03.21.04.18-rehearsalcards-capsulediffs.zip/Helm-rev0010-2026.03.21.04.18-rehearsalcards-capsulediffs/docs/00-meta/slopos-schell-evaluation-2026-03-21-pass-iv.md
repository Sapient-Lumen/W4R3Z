
# SlopOS + Schell evaluation — 2026-03-21 — pass IV

Purpose: keep using SlopOS and Schell as design teachers while Helm is still choosing what to freeze, what to pressure, and what to postpone.

This pass focuses on three candidate moves that now look unusually valuable for Helm:
- action rehearsal / route cards,
- capsule diffs,
- and shell-owned layout templates with rebinding.

## What SlopOS pressures here

### 1. Rehearsal must stay exact about subjects, routes, and authority

SlopOS keeps teaching the same lesson in different clothes:
exact reveal beats approximate browse; exact route witnesses beat hidden helper behavior; exact durable handles beat path folklore.

That pressure applies directly to rehearsal.
If Helm ever shows a preflight card for a strong action, the card should name:
- the exact subject or packet,
- the selected route or provider,
- the likely effects,
- and the uncertainty boundary.

Helm should refuse “something like this will probably happen” rehearsal theater.

### 2. Continuity should be shell truth, not app folklore

SlopOS keeps continuity and receipts shell-owned.
That is a strong argument for capsule diffs.
A Helm capsule diff should not be a cute comparison view over app-local memory.
It should be a shell-level account of what the desktop can actually reconstitute.

### 3. Spatial templates should compose with continuity instead of becoming a parallel worldview

SlopOS is consistently suspicious of nearby helper subsystems that quietly become more authoritative than the shell.
That means Helm should not let layout templates become a separate zone-manager culture.
Templates should stay shell-owned, inspectable, and composable with Recall, Overview, and capsules.

## What Schell adds

### 1. Rehearsal wants packets and witnesses, not vague previews

Schell is helpful here because it keeps naming compact interactive objects:
selection packets, hold cards, denial cards, route witnesses, restore truth, and attach honesty.

Helm should steal that pattern.
A rehearsal card should look more like a packet-and-witness surface than like a decorative preview.

### 2. Reentry honesty implies diff surfaces

Schell's reentry work keeps distinguishing live, restored, historical, and unavailable truth.
That pushes Helm toward capsule diffs:
- what is live now,
- what the capsule expects,
- what can be restored exactly,
- what needs repair,
- and what is simply unavailable.

Without that diff surface, capsule restore will drift back toward fake session glamour.

### 3. Layout trees are useful, but local

Schell's local-view pressure is also useful here.
A layout template can be a strong local structure without becoming the universal durable truth of Helm.
This argues for templates with explicit scope, explicit anchors, and visible rebinding rather than giant universal saved-desktop dogma.

## What this pass suggests for Helm now

### Worth pushing

- action rehearsal cards as a shared shell surface for strong actions and Flow entrypoints
- capsule diffs as the honesty engine for Recall and restore
- layout templates with explicit slots, anchors, and rebinding
- route cards as typed Exchange / Omnibox / Preview companions rather than hidden helpers

### Worth avoiding

- fake rehearsal that promises determinism where Helm only has partial truth
- capsule restore claims that do not expose repair and loss
- zone-manager drift where templates become a separate subsystem outside the shell graph
- packetless mini-UIs that bypass route witnesses and receipts

## Current bounded take

A useful new Helm rule is:

**when Helm adds luxury, it should add legible luxury — cards, diffs, witnesses, and rebinding surfaces — not hidden helper cleverness.**
