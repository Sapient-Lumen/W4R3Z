# Roadmap

## Phase 0 — meaning pins and archive control
- settle shell/compositor ownership
- settle control-tier boundaries
- settle object-browser and reveal semantics
- settle recall and reentry honesty
- settle exchange and typed transfer routing
- settle terminal/capshell posture
- settle the Helm/Schell treaty for shell-facing seams
- freeze pillar contracts so Helm does not regress into app-bundle thinking
- add compact startup, status, question, and import-memory surfaces so revisions stop depending on chronology and chat memory

## Phase 1 — proof-bearing slice
- shell graph with windows/workspaces/focus
- Tiling Shell with directional focus, layout transforms, and shell-owned workspaces
- Omnibox over shell objects/actions including recall and exchange subjects
- Object Browser with split views, query views, bulk operations, exact reveal, and exact object reopen
- Operations Center with windows/jobs/background/automation sessions/transfers/receipts/grants
- Desktop Flow over shell graph with hotkeys, layout rules, object actions, recall jumps, and exchange routes
- Recall with one obvious current-live reentry cue, liveness badges, activity trail, and hold cards for non-live strong actions
- Exchange with typed ingress/selection packets, exact route witnesses, and visible transfer / attach / forward receipts
- explicit raw automation session with visible indicator and kill switch
- one reviewed shell-facing action with lineage and receipt
- archive control surfaces exercised by at least one honest startup/reentry pass
- typed provider path for Omnibox demonstrated by at least one provider family
- Flow observability/reuse demonstrated by one debug lane plus one reusable fragment specimen
- candidate cross-cut moves narrowed enough to prove or demote: Preview, Overview, and workspace/activity capsules

## Phase 1.5 — cross-cutting shell power pass
- Preview candidate contract and provider posture
- Overview candidate contract as Omnibox's spatial companion
- workspace/activity capsule candidate contract with exact/repaired/partial/unavailable honesty
- query-first browsing and plumbing-grade routing tightened where they pressure multiple pillars
- breadcrumb / outline / timeline cues tightened where they help Recall and Object Browser
- live-lens candidate contract narrowed enough to prove or demote
- snippet / quicklink / placeholder seed candidate narrowed enough to prove or demote

## Phase 2 — deeper automation and Schell integration
- tighter terminal/capshell contract
- richer structural UI graph
- stronger failure inspection and receipts
- ingress / selection / exchange packet family shared more explicitly across surfaces
- execution-ground witnesses on reviewed shell-facing actions
- richer continuity around attach, resume, restore, and remote peer witnesses
- optional sealed compat lanes if ever admitted
- decide whether Helm needs a fuller transfer ledger beyond the current foreign-pressure memory

## What should wait for Schell
- final shell syntax
- final session restore/attach semantics
- final remote forwarding and peer-witness posture


## Added pressure in rev0010

- one rehearsal-card specimen shared across Omnibox / Exchange / Flow
- one capsule diff specimen for Recall honesty
- one layout-template-and-rebinding specimen for Tiling Shell + Recall
