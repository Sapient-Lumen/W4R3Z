# Web research synthesis — 2026-03-21 — pass I

Purpose: continue broadening Helm without freezing too much too early.

This pass is intentionally not a pile of feature envy. It is a **steal / do-not-steal** pass over current and historical desktop ideas, filtered through SlopOS, Schell, and Helm's existing pillar spine.

## What this pass says at a glance

The strongest outside lessons are **not** “add more pillars.”

They are:

- make **preview** a shell-wide power rather than a file-manager trick
- make **workspace capture and restore** a first-class continuity tool, but with ruthless honesty about exact vs best-effort replay
- give Helm a **spatial overview** that complements Omnibox instead of competing with it
- make Omnibox and Exchange more like **typed plumbing** than app-launch folklore
- make Desktop Flow much better at **debugging, packaging, and live inspection**
- keep **live query views** and saved smart views at the center of Object Browser and Recall
- learn from command-palette systems, but do not let them collapse Helm back into “string plus plugin” culture

## What outside systems are worth stealing from

### 1. Quick preview as a shell power

The best preview systems treat “peek before commit” as a universal desktop move rather than as a single app feature.

That pattern shows up clearly in:

- Apple's Quick Look
- PowerToys Peek
- GNOME Files' spacebar preview

Helm should therefore treat preview as a **cross-cutting shell service** used by:
- Object Browser
- Omnibox
- Recall
- Exchange
- Operations Center evidence surfaces

The important translation is:
**do not make Preview a new pillar; make it a reusable shell power with typed providers and clear trust posture.**

### 2. Smart views and live queries are elite

Haiku's query culture and Apple's Smart Folders both point in the same direction:
users should be able to create durable, reusable views over metadata and content-derived facts rather than only browsing static containers.

Helm already wants this through query views and object refs. This pass strengthens that stance:
- query views should feel normal, not advanced
- saved smart views should be visible in the same graph as objects and workspaces
- Recall should be able to jump back into a saved view, not just into a recent object
- Exchange routes should be able to target views as destinations or reveal surfaces where that makes sense

### 3. Command palettes are converging toward action surfaces

Current palette systems increasingly blur:
- launch
- switch
- search
- quick actions
- provider extensibility

That pattern shows up in:
- Apple's Spotlight
- KDE KRunner
- Microsoft's PowerToys Command Palette

Helm should steal the convergence, but not the substrate.
The correct take is:
- Omnibox should search shell objects, actions, routes, views, recall entries, and flow entrypoints
- extensibility should be typed provider registration, not unrestricted shell command backdoors
- actions should have receipts where strong side effects exist
- the spatial companion to Omnibox should be shell-owned Overview, not plugin sprawl

### 4. Workspaces should be capturable, but never lie

PowerToys Workspaces and KRunner session launching both reinforce a real need:
users want a “put me back in project state” move.

Helm should absolutely have that.
But Helm must avoid a fake promise.

The right move is likely:
- **workspace capsules** or **activity capsules**
- explicit badges for exact / repaired / partial / unavailable restore
- visible dependency on live refs, routes, and execution grounds
- Recall and Tiling Shell co-own the experience
- Operations Center explains why replay did or did not fully succeed

This feels much more Helm-native than generic “session restore.”

### 5. Spatial overview is still underrated

GNOME's Activities overview gets something very right:
search, launch, windows, and workspaces become one glanceable spatial surface.

Helm should not copy GNOME's worldview wholesale, but it should steal this:
- an **Overview** that is the spatial companion to Omnibox
- visible workspaces
- visible current windows
- quick jump, quick move, quick launch
- strong keyboard path
- continuity cues from Recall
- route/flow cues where useful

Helm is currently stronger on exactness and power than on this kind of spatial legibility.
That is a gap worth fixing.

### 6. Typed plumbing is still one of the best desktop ideas ever

Plan 9's plumber and acme still point at something most modern desktops regress on:
data movement and action dispatch should be ruleful, inspectable, and programmable.

This is directly relevant to Helm:
- Exchange should look more like typed plumbing than like clipboard folklore
- Omnibox actions should be routable as typed requests
- selection packets, intent packets, and route witnesses should remain first-class
- users should be able to understand and modify route choice without falling down to ambient shell scripting

### 7. Visual programming needs better support machinery, not just a canvas

Node-RED and Unreal-style graph systems remind us that the graph is only half the product.

Desktop Flow should steal:
- searchable graph outline
- debug sidebar
- node status indicators
- subflows / packaged fragments
- typed exec vs data edges
- live message/state inspection

Without those, graph desktop programming looks exciting but degrades into spaghetti.

### 8. Layout editors are useful, but Helm should absorb them upward

FancyZones demonstrates that users like visually editable placement targets.

Helm should steal the idea as:
- a visual layout/template editor inside Tiling Shell
- workspace or activity capsules that can refer to layout templates
- explicit placement hints and exactness badges
- never as a separate zone-manager worldview bolted beside the shell

## What not to steal

### Do not steal ambient plugin cultures whole
Command palette and launcher ecosystems are powerful, but they often assume:
- shell command strings
- hidden background processes
- weak review
- poor failure visibility

Helm should keep typed providers, receipts, and Operations Center visibility.

### Do not steal approximate session-restore bravado
Many systems are useful precisely because they are approximate, but Helm cannot pretend approximate equals exact.

### Do not steal file-manager-local query thinking
If smart views only exist inside Object Browser, Helm misses the point. They should compose across Recall, Exchange, Omnibox, and Flow.

### Do not steal visual-programming canvases without debug tooling
A pretty graph editor with weak observability is just a future regret generator.

## Pressure this creates on Helm's pillars

### Tiling Shell
Needs:
- visual layout/template editing
- workspace capsule hooks
- Overview integration

### Omnibox
Needs:
- typed provider model
- action/result honesty
- route and recall awareness
- maybe a docked or pin-able “always there” summon surface later, but not by default in v0

### Object Browser
Needs:
- shell-wide preview
- saved smart views treated as first-class
- strong tags/attributes/query ergonomics
- exact reveal and jump-back from Recall

### Operations Center
Needs:
- restore truth
- route/transfer truth
- flow debug state
- preview provider failures
- exact vs repaired replay visibility

### Desktop Flow
Needs:
- debug sidebar
- subflow packaging
- graph outline search
- node status
- typed pins/edges

### Recall
Needs:
- workspace/activity capsules
- exact/repaired/partial continuity badges
- view-level reentry, not just item-level reentry

### Exchange
Needs:
- typed routes inspired by plumbing
- preview-before-commit everywhere sensible
- inspectable conversions and transforms
- route witnesses that feel normal, not forensic

### Terminal/Capshell
Needs:
- route and packet awareness
- restore/attach honesty
- consistency with Exchange and Recall rather than a separate continuity folklore

## Working stance after this pass

We should **not** add more pillars right now.

We **should** add or strengthen these cross-cutting shell moves:

1. Preview
2. Workspace/activity capsules
3. Overview
4. Typed provider model for Omnibox
5. Flow debugging/packaging
6. Query/view-first browsing and recall
7. Plumbing-grade route inspection

## Followthrough

- Flesh out the cross-cutting move catalog.
- Record open questions about Preview, Overview, and workspace capsules rather than freezing them immediately.
- Keep the shell graph small while ensuring these moves can still plug into it.
