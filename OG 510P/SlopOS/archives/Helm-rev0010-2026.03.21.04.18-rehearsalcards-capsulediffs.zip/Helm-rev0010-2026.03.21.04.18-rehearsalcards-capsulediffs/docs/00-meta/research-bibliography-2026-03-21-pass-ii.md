# Research bibliography — 2026-03-21 — pass II

This bibliography is intentionally compact. It records the outside sources that informed `web-research-synthesis-2026-03-21-pass-ii.md`.

## Typed provider and summon surfaces

- Apple Spotlight help and Spotlight actions help
- KDE KRunner user docs and runner plugin docs
- Microsoft PowerToys Command Palette and PowerToys Run docs
- Raycast Quicklinks and Snippets docs
- Alfred snippets and workflows docs

## Continuity / capsule / context cues

- Obsidian Workspaces docs
- Arc Spaces docs
- GNOME Activities overview docs
- KDE Activities docs and current KDE Activities blog post
- VS Code Breadcrumbs / Outline / Timeline docs

## Graph observability and reuse

- Node-RED workspace, subflow, debug sidebar, and message inspection docs
- Unreal Blueprint Debugger and Blueprint Macro Library docs
- Godot debugger panel / debugging tools docs

## How to read this bibliography

Helm uses these sources for:
- product patterns worth translating,
- proof that certain interaction shapes repeatedly resonate,
- and warnings about the substrate mistakes that made good ideas rot.

Helm does **not** treat any one of these as a blueprint to port.
