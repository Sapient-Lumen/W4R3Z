# Web research synthesis — 2026-03-21 — pass II

Purpose: keep harvesting brilliant ideas for Helm without widening the architecture by vibes.

This pass is narrower than pass I. It focuses on **three pressure clusters** that now look strong enough to shape Helm's near-term design work:

1. **typed provider action surfaces**
2. **continuity capsules and multi-scale context cues**
3. **graph observability, reusable fragments, and debug tooling**

## What this pass says at a glance

The current evidence suggests two small decisions are now wise:

- Omnibox extensibility should be **typed providers**, not ambient plugin / shell-string sprawl.
- Desktop Flow should require **observability and reusable fragments**, not just a canvas.

It also suggests three strong candidate contracts that still should **not** be frozen too hard yet:

- Preview as a shell-wide service family
- Overview as Omnibox's spatial companion
- workspace/activity capsules as Recall/Tiling/Operations continuity objects

## Cluster 1 — typed providers beat plugin folklore

### What current systems teach

The best modern summon surfaces are converging on a broad action model:
- Spotlight now surfaces apps, files, actions, the web, and the Clipboard from one search surface.
- KRunner remains a compact keyboard-first action surface over applications, web pages, bookmarks, desktop data, and plugin-supplied actions.
- PowerToys Command Palette and PowerToys Run show the same appetite on Windows: summon once, then launch, switch, calculate, search, or run utility actions.
- Raycast Quicklinks and Snippets, plus Alfred's snippets/workflows, show that users love small personal actions, snippets, and quick routes when they feel instant.

### What Helm should steal

Helm should steal the **breadth**, not the substrate.

The good take is:
- Omnibox uses a **typed provider model** over shell-owned objects and actions.
- Providers can contribute matches, previews, actions, snippets, quicklinks, and route proposals.
- Provider outputs carry exact subject identity, action family, review posture, and receipt expectations where needed.
- Snippets and quicklinks should compose with Desktop Flow and Exchange rather than live as isolated toys.

### What Helm should refuse

Helm should refuse:
- arbitrary PATH or shell-string backdoors as the primary extension seam,
- hidden helper daemons as the assumed substrate,
- provider effects that bypass Operations Center visibility,
- and plugin folklore where the user cannot tell which provider acted on what.

### Helm consequence

This is strong enough to move from “research pressure” to **narrow architecture posture**.

## Cluster 2 — continuity needs capsules and multiple scales of context

### What current systems teach

Obsidian Workspaces show that users value restoring a task-shaped application layout rather than reopening everything from scratch.
Arc Spaces show that distinct contexts become stickier when they carry visible identity and a sense of “pick up where you left off”.
VS Code's Breadcrumbs, Outline, and Timeline show that continuity works best when it exists at multiple scales: current location, surrounding structure, and recent/local history.
KDE Activities and GNOME's Activities overview reinforce that context switching is easier when windows, workspaces, and search are part of one spatial story rather than separate utilities.

### What Helm should steal

Helm should steal these ideas as **capsules and context cues**, not as app-specific layout save files.

A good Helm take looks like:
- workspace/activity capsules capture meaningful shell state,
- capsules carry honesty badges: exact / repaired / partial / unavailable,
- Breadcrumb-style context cues appear in Object Browser, Recall, and Overview where they help orientation,
- Timeline/Trail views reinforce Recall rather than living as isolated app features,
- and Overview becomes the quick spatial way back into a capsule or current task context.

### What Helm should refuse

Helm should refuse:
- false promises that capsule restore is exact when live objects are gone,
- profile/account/cookie assumptions leaking into general desktop capsules,
- and app-local “workspace” silos that cannot be seen by Recall or Operations Center.

### Helm consequence

Capsules still belong in the **candidate-contract lane**, but they are no longer a speculative whim. They are one of the clearest paths to making Recall and Tiling Shell feel unusually good.

## Cluster 3 — graph systems live or die by observability

### What current systems teach

Node-RED's Debug sidebar, structured message inspection, workspace tabs, and reusable subflows show that graph tooling only scales when the runtime state is inspectable.
Unreal's Blueprint Debugger and Blueprint Macro Libraries show the same lesson from another angle: breakpoints, runtime inspection, and reusable graph fragments are not garnish.
Godot's debugger panel reinforces the general rule that a visual system needs dedicated panes for runtime truth.

### What Helm should steal

Desktop Flow should steal:
- a debug sidebar or equivalent event/state lane,
- node status surfaces,
- graph outline/search,
- reusable inspectable fragments (subflows/macros/templates),
- and explicit separation between data edges, control edges, and review boundaries.

### What Helm should refuse

Desktop Flow should refuse:
- “the graph is the debugger” as a sufficient answer,
- opaque packaged flows that cannot be inspected locally,
- and pretty node canvases with no durable failure or disablement story.

### Helm consequence

This is also strong enough to move from “research pressure” to **narrow architecture posture**.

## Secondary ideas worth keeping live

These are not the center of this pass, but they are still good:

- Preview should include folder/collection summary surfaces, not just file previews.
- Snippets should be able to escalate into typed actions or Flow entrypoints.
- Breadcrumbs should not be code-only; Object Browser and Recall can use them for object/view lineage too.
- Timeline views should pressure Recall and Operations Center together, not become an isolated history gimmick.
- Shared spaces/workspaces from browser/editor tools are a reminder that export/share of continuity objects may become a future Exchange story — but not a v0 promise.

## What looks wise to freeze now

1. **typed Omnibox providers over ambient plugin culture**
2. **Flow observability and reusable fragments are required for Desktop Flow**

## What still looks better as candidate contracts

1. Preview
2. Overview
3. workspace/activity capsules

## Followthrough

- add a typed-provider posture for Omnibox
- add a flow-observability / reusable-fragment posture for Desktop Flow
- add candidate-contract notes for Preview, Overview, and workspace/activity capsules
- update open questions so the next pass can prove or demote those candidates instead of relitigating them from scratch
