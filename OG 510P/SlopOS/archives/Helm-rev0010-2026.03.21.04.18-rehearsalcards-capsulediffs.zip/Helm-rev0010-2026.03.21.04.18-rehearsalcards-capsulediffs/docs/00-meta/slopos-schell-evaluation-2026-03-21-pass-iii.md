
# SlopOS + Schell evaluation — 2026-03-21 — pass III

Purpose: keep evaluating the teacher cubes instead of treating them as already-settled truth.

This pass focuses on what SlopOS and Schell imply for the current “super awesome” candidate moves rather than on broad constitutional lessons.

## What SlopOS still teaches most strongly

### 1. Exactness is a product feature, not just a security posture

SlopOS keeps returning to the same move:
exact reveal beats approximate browse, exact transfer beats ambient clipboard folklore, exact route witnesses beat “helpful” hidden helpers, and exact durable handles beat ambient paths.

Helm should keep learning from that.
The moment Helm starts flattering the user with nearby fallbacks, it will feel smoother in demos and weaker in real use.

### 2. Shell-owned continuity matters more than app-owned memory

SlopOS’s document, transfer, background, and automation postures all keep shell-owned continuity and receipt truth above app-owned convenience.

That pressures Helm in a useful way:
- Recall should stay shell truth, not app-local recent-items folklore.
- Exchange should stay shell truth, not helper IPC folklore.
- Preview should stay shell-owned, not per-app plugin sprawl.

### 3. “No ambient observer” remains a healthy default

SlopOS is consistently suspicious of background inventory, ambient observation, and hidden capability carry.

For Helm this still means:
- no clipboard-history ambient eavesdropping by default,
- no hidden route inventory as a public ambient substrate,
- no silent preview provider side effects,
- and no invisible raw-lane permanence.

## What Schell adds beyond SlopOS

### 1. Rich visible interaction wants packets and witnesses

Schell keeps finding better names for the same humane move:
let visible things become actionable, but route them through compact objects like selection packets, intent packets, route witnesses, denial cards, and hold cards.

Helm should keep stealing that pattern.
It is especially useful for Omnibox, Recall, Exchange, and Preview-adjacent actions.

### 2. Reentry honesty is more important than session glamor

Schell’s reentry work keeps insisting that restored, historical, live, and receipt-like objects must stay visibly different.

That pressure applies directly to Helm’s Recall and capsule work.
It also pressures any future Overview or lens surface: derivative views must not quietly claim stronger truth than their sources.

### 3. View trees are useful, but should stay visibly local

Schell’s view-tree posture is a helpful warning for Helm.
Pane trees, layout trees, and local view structures can be excellent ergonomic surfaces without becoming the entire durable truth of the product.

This matters for Helm’s Tiling Shell, Overview, and any future live-lens idea.

## What this pass suggests for Helm now

### Keep pushing

- Preview as a shell-wide reusable power
- Overview as a spatial companion to Omnibox
- capsules as Recall continuity objects
- packets/witnesses/hold-cards for routes and denials
- one or two genuinely luxurious shell moves that make Helm feel new

### Stay wary of

- ambient helper daemons that quietly become required for core power
- derivative local views pretending to be durable truth
- preview or quick-action surfaces that silently execute or widen authority
- imported shell-facing semantics that freeze too much of Schell before Schell earns them

## Current bounded take

A good Helm rule now is:

**steal the explicit object-and-witness discipline from SlopOS and Schell, then spend it on humane shell luxuries rather than on hidden helper magic.**

That is the strongest path to “super awesome” without walking back into ambient desktop folklore.
