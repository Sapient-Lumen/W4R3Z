# Non-claims

Helm does not claim in v0:

- universal compatibility with legacy window-manager or shell contracts
- invisible “just works” automation for arbitrary apps without explicit grants
- exact equivalence to i3, AHK, Rofi, or Dolphin
- a complete terminal/capshell design without the future Schell datacube
- that every desktop behavior is modeled semantically from day one
