# Claim registry

## CH-HELM-0001
Helm is a shell/compositor product, not merely a set of desktop utilities.

## CH-HELM-0002
Focus, activation, visibility, placement, and reveal/select are shell-owned semantics.

## CH-HELM-0003
Desktop Flow is a first-class programmable desktop control fabric.

## CH-HELM-0004
Helm preserves an AHK-grade escape hatch via an explicit raw automation lane.

## CH-HELM-0005
The Object Browser and Operations Center are core shell surfaces.

## CH-HELM-0006
Terminal/capshell is native and explicit rather than a return to ambient command-string authority.

## CH-HELM-0007
Shell-facing actions in Helm should preserve lineage richer than history-only scrollback.

## CH-HELM-0008
Reviewed actions and receipts are load-bearing shell-facing objects, not UI garnish.

## CH-HELM-0009
Execution context for strong shell-facing actions should be inspectable rather than prompt-folklore.

## CH-HELM-0010
Authority-bearing paste/drop/selection ingress should remain explicit enough to inspect.

## CH-HELM-0011
Helm's exemplars translate to powers and first-party surfaces, not app-clone compatibility promises.

## CH-HELM-0012
The Tiling Shell, Omnibox, Object Browser, Operations Center, Desktop Flow, Recall, Exchange, and terminal/capshell family form one shared control plane over the same shell graph.

## CH-HELM-0013
Recall is a first-class shell surface for continuity, reentry, durable activity truth, and restored-vs-live honesty.

## CH-HELM-0014
Exchange is a first-class shell surface for typed transfer, route witnesses, and exact attach/open/reveal/send distinctions.

## CH-HELM-0015
Helm's design archive should keep explicit startup, status, question, assumption, foreign-pressure, followthrough, and revision-receipt surfaces so future revisions do not depend on chronology and chat memory alone.
