# Invariant registry

## I-HELM-0001 Shell truth
Apps do not become authoritative for focus, activation, workspace placement, or reveal/select.

## I-HELM-0002 Visible automation
Automation that can observe or inject outside shell-owned objects is never silently ambient.

## I-HELM-0003 Reveal exactness
Helm either reveals/selects the exact target or reports failure.

## I-HELM-0004 Ops honesty
The system does not hide background presence, automation sessions, or grants behind a shallow process list.

## I-HELM-0005 Shell-first power
Common desktop automation should target shell-owned objects before resorting to raw UI poking.

## I-HELM-0006 No session folklore
Applications do not get to own global session/profile selection semantics by default.

## I-HELM-0007 Lineage over history-only
Shell-facing actions do not collapse durable explainability into scrollback or prompt return.

## I-HELM-0008 Review honesty
Strong shell-facing actions do not hide their reviewed basis or receipt truth behind shallow success chrome.

## I-HELM-0009 Ingress honesty
Authority-bearing paste/drop/selection ingress does not silently inherit execution authority as plain text.

## I-HELM-0010 No pillar drift
Helm's pillars do not degrade into disconnected utility apps with separate authority models.

## I-HELM-0011 Shared graph truth
Omnibox, Object Browser, Operations Center, Desktop Flow, Recall, Exchange, and terminal/capshell all compose over the same shell-owned graph instead of parallel ad hoc state silos.

## I-HELM-0012 Continuity honesty
Restored, historical, receipt, and live objects never silently collapse into one continuity posture.

## I-HELM-0013 Exchange honesty
Paste, drop, clipboard, share, attach, forward, and import never silently widen into execution or approximate nearby routing.

## I-HELM-0014 Archive honesty
Helm's datacube must distinguish operational head, citation head, live questions, assumptions, imported pressure, followthrough, and revision basis instead of burying them in chronology and prose alone.
