# Traceability

- CH-HELM-0001 -> adrs/0001-helm-is-a-shell-product.md; docs/30-architecture/architecture-overview.md
- CH-HELM-0002 -> docs/30-architecture/compositor-posture-v0.md; docs/30-architecture/activation-control-boundary-v0.md; docs/30-architecture/input-routing-posture-v0.md
- CH-HELM-0003 -> adrs/0002-first-class-desktop-flow.md; docs/30-architecture/desktop-flow-posture-v0.md; docs/30-architecture/flow-entrypoint-posture-v0.md
- CH-HELM-0004 -> adrs/0004-control-tiers-and-raw-lane.md; docs/30-architecture/control-tier-boundary-v0.md; docs/30-architecture/raw-automation-lane-posture-v0.md
- CH-HELM-0005 -> adrs/0003-object-browser-and-operations-center-are-core.md; docs/30-architecture/object-browser-posture-v0.md; docs/30-architecture/operations-center-posture-v0.md
- CH-HELM-0006 -> docs/30-architecture/capshell-posture-v0.md; docs/30-architecture/terminal-posture-v0.md
- CH-HELM-0007 -> docs/30-architecture/shell-session-lineage-posture-v0.md
- CH-HELM-0008 -> docs/30-architecture/reviewed-action-receipt-posture-v0.md
- CH-HELM-0009 -> docs/30-architecture/execution-ground-posture-v0.md
- CH-HELM-0010 -> docs/30-architecture/ingress-packets-posture-v0.md
- CH-HELM-0011 -> adrs/0005-exemplars-translate-to-powers.md; docs/30-architecture/exemplar-translations-v0.md
- CH-HELM-0012 -> adrs/0006-pillars-form-one-product.md; docs/30-architecture/base-product-surface-v0.md; docs/30-architecture/pillar-contracts-v0.md
- CH-HELM-0013 -> adrs/0007-recall-is-a-core-pillar.md; docs/30-architecture/recall-posture-v0.md
- CH-HELM-0014 -> adrs/0008-exchange-is-a-core-pillar.md; docs/30-architecture/exchange-posture-v0.md
- CH-HELM-0015 -> adrs/0009-compact-archive-control-surfaces.md; START_HERE.md; context-pack.json; SURFACE-STATUS.json; REVISION-RECEIPT.json; QUESTION-REGISTRY.json; FOREIGN-PRESSURE-LEDGER.json
- I-HELM-0014 -> START_HERE.md; SURFACE-STATUS.json; REVISION-RECEIPT.json; QUESTION-REGISTRY.json; ASSUMPTION-LEDGER.json; FOREIGN-PRESSURE-LEDGER.json; FOLLOWTHROUGH-QUEUE.json
