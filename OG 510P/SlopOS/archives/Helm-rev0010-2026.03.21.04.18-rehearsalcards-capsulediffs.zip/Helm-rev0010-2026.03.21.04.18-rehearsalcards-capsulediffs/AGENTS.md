# AGENTS.md

Compact startup wrapper for future maintainers and LLMs.

1. Read `START_HERE.md`.
2. Read `context-pack.json`.
3. Check `SURFACE-STATUS.json` so you know the operational head, citation head, and status lanes.
4. Read `REVISION-RECEIPT.json` for why the latest revision counted.
5. Read `docs/00-meta/trajectory-map.md` and `docs/30-architecture/pillar-contracts-v0.md`.
6. Read `QUESTION-REGISTRY.json`, `ASSUMPTION-LEDGER.json`, `FOLLOWTHROUGH-QUEUE.json`, and `FOREIGN-PRESSURE-LEDGER.json` before making new moves.
7. Use `docs/00-meta/delaybasin-lessons-for-helm.md` to understand why these archive-control surfaces exist.

Rules:
- canon beats convenience;
- the status lanes are not decorative;
- imported pressure must name bounded takes and explicit non-takes;
- do not widen shell-facing contracts just because terminal ideas are attractive;
- do not add archive machinery unless it reduces real drift or startup entropy.
