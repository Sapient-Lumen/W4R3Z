# Changelog

## Revised183 (2026-02-28)
- Integrated a least-authority **entropy request seam** for D-NONDET (no ambient RNG constructors; LLMs propose; validators execute; schemas/receipts are the stable surface):
  - Added **CH-ENTREQ v0** (`docs/30-architecture/entropy-request-schema-v0.md`): bounded, non-authoritative entropy request descriptor for `portal.entropy`; includes stable `req_id` for retry/dedupe correlation; never carries entropy bytes or bearer secrets.
  - Added ACP kind **`portal.entropy.request`** (ordered within `domain.id`; lane-gated by `cfg.params.lane.portal.entropy`) and wired it into commutativity predicates + serialization-boundary registry (keeps Hybrid + D-COMMUTE honest).
  - Updated D-NONDET decision note to explicitly name the ACP/portal seam (`portal.entropy.request` + CH-ENTREQ) as the preferred “no ambient nondet” path.
- Wiring + assurance/evidence:
  - Added **PO-ENTREQ-VALIDATE** and **PO-ACP-ENTROPY-REQUEST**; strengthened **I-NONDET-5**.
  - Registered **EVID-2026-196** (harness plan for lane-disabled rejects, ordered-stream witness enforcement, dedupe by req_id, and CH-ENTROPY emission/validation).
- Reference hygiene: added **REF-LINUX-GETRANDOM** to the bibliography for a primary RNG API baseline.

## Revised182 (2026-02-28)
- Tightened lane-gate *discoverability* on the stable product surface (prevents optional surfaces from drifting into “ambiently enabled” or “lane-gated but unnamed” posture):
  - Added a new CI drift gate `tools/check_acp_kind_lane_gates.py` (wired into `make lint`) that enforces: any lane-gated ACP kind (`portal.*`, `capshell.exec`, `fcell.*`) explicitly names its required `cfg.params.lane.*` kill switch key in the ACP kind registry Profiles cell, and the key exists in both `config-toggle-registry.md` and `profile-lane-defaults.md`.
  - Updated `acp-action-kind-registry.md` to make this requirement explicit in the per-kind metadata contract.
- Assurance + evidence wiring:
  - Strengthened **I-LANEGATE-1** and **PO-LANE-KILL** to include the explicit “ACP kind registry names required lane keys” contract.
  - Registered **EVID-2026-195**.

## Revised181 (2026-02-28)
- Entropy-reducing refactor: upgraded **CH-IOLEASE v0** (`docs/30-architecture/io-lease-schema-v0.md`) from an informal note into a standard schema surface (Encoding + conceptual data model + explicit bounds + fail-closed validation rules). This keeps device lease descriptors LLM-resilient and audit-friendly under D-IOLEASE and sealed-compat device mediation:
  - Explicitly reiterates non-authoritative posture (lease descriptors do not grant), no bearer secrets, and a `dma_window.kind="policy_ref"` option for profiles that forbid embedding raw IOVA addresses.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_iolease_schema_formality.py` and wired it into `make lint`.
  - Enforces that CH-IOLEASE remains marked as a schema surface (no “informal” regression), retains Encoding/Data model/Validation rules sections, and stays wired to canonical PO/I anchors.
- Assurance + evidence wiring:
  - Added **I-IOLEASE-3** and **PO-IOLEASE-VALIDATE**.
  - Registered **EVID-2026-194**.

## Revised180 (2026-02-28)
- Reduced D-COMMUTE / Hybrid drift risk by pinning deterministic conflict-key derivation for the digest-valued `*_key` payload fields used by pinned hot-action and ACP seams (prevents “canonical tuple” ambiguity and keeps ordering scopes reviewable):
  - Added `docs/30-architecture/conflict-key-derivation-registry.md` (v0 seed): normative `ck_id(..)` helper and per-family tuple→digest derivation commitments for `mem.range`/`ipc.endpoint`/`view.slot`/`log.eventset`/`budget.*` (and cross-links for `domain.id`/`policy.param`).
  - Strengthened CH-CONFLICTKEY v0 derivation commitments (`docs/30-architecture/conflict-key-schema-v0.md`) to include these families (not just `policy.param` / `domain.id`) and to reference the derivation registry as the source of truth.
  - Tightened hot-action ordering scope prose (`hot-action-boundaries-v0.md`) so CH-ORDERTOK scoping is explicitly to `digest(CH-CONFLICTKEY v0)` and points to the derivation registry for the underlying `*_key` fields.
- Entropy-reducing refactor: unified CH-ORDERTOK family vocabulary with CH-CONFLICTKEY families to prevent shadow ordering vocabularies:
  - Updated `ordering-token-schema-v0.md` so `scope.family` uses the closed CH-CONFLICTKEY family allowlist pinned in `conflict-key-family-registry.md` (no “profile-defined enum” drift).
  - Updated the conflict-key family registry wiring requirements to explicitly cover CH-ORDERTOK.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_conflictkey_derivation_registry.py` and wired it into `make lint`.
  - Enforces derivation-registry wiring (docs index + CH-CONFLICTKEY schema + hot-action boundaries) and rejects any `CH-ORDERTOK v0 (family \`...\`)` references that use unknown family tokens (prevents D-COMMUTE/Hybrid scoping drift).
- Assurance + evidence wiring:
  - Updated **I-CONFLICTKEY-2** and added **I-ORDERTOK-3**; updated **PO-CONFLICTKEY-DERIVE** and **PO-ORDERTOK-VALIDATE**.
  - Registered **EVID-2026-193**.
- Trajectory map update: refreshed the D-COMMUTE follow-up open question to reflect the new derivation registry; remaining follow-up is pinning canonical encodings for the profile-specific typed ids that feed `ck_id(..)`.

## Revised179 (2026-02-28)
- Tightened **policy/authority denial** evidence surfaces (no ambient “which policy?” drift) by introducing an explicit policy-handle schema surface and removing a stale, non-specified coupling point:
  - Added **CH-POLICYHANDLE v0** (`docs/30-architecture/policy-handle-schema-v0.md`): a digestable, non-authoritative handle naming veto-only policy semantics (evaluator + policy artifact digest). Supports profiles where policy is builtin/compiled (not shipped as a CH-POLICY bundle) while keeping CH-DENY policy denials transcript-visible and reviewable.
  - Updated policy/authority deny bindings to be explicit and schema-pinned: for `missing-approval` / `expired-approval` / `policy-deny`, CH-DENY now binds `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)` (deny-code registry + CH-DENY producer rules + ACP validator semantics + D-POLICY note).
  - Entropy-reducing refactor: removed references to a non-specified `CH-CFG` `policy_bundle` field from CH-FADAPT receipts (v0/v1) and replaced with the explicit CH-POLICY/CH-POLICYHANDLE handle set (prevents a “shadow field” from becoming an ambient policy context).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_no_cfg_policy_bundle_ref.py` and wired it into `make lint`.
  - Forbids stale references to a non-specified `CH-CFG` `policy_bundle` field and vague “profile-defined policy handle” wording, keeping policy-handle semantics pinned to CH-POLICYHANDLE and preventing regression into ambiguous, prose-only policy contexts.
- Assurance + evidence wiring:
  - Added **I-POLICYHANDLE-1** and **PO-POLICYHANDLE-VALIDATE**; strengthened **PO-DENY-POLICY-BIND** and **I-DENY-5** to include CH-POLICYHANDLE.
  - Registered **EVID-2026-192**.

## Revised178 (2026-02-28)
- Entropy-reducing refactor: upgraded **CH-PLUMBMSG v0** (`docs/30-architecture/plumb-message-schema-v0.md`) from an informal note into a standard schema surface (Encoding + conceptual data model + explicit bounds + fail-closed validation rules), keeping D-PLUMB workflow intent envelopes LLM-resilient and audit-friendly.
  - Explicitly anchors `intent.kind` closure to `docs/30-architecture/intent-kind-registry.md` (no shadow enums) and reiterates non-authoritative posture (I-PLUMB-3).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_plumbmsg_schema_formality.py` and wired it into `make lint`.
  - Enforces that CH-PLUMBMSG stays marked as a schema surface (no “informal” regression), references the canonical intent-kind registry, and retains explicit fail-closed + validation anchors (prevents workflow plumbing drift into prose-only surfaces).
- Evidence wiring: registered **EVID-2026-191**.

## Revised177 (2026-02-28)
- Integrated an LLM-first, least-authority **network lease request seam** under D-NETLEASE (no ambient sockets; validators execute; schemas/receipts are the stable surface):
  - Added **CH-NETREQ v0** (`docs/30-architecture/network-request-schema-v0.md`): bounded, non-authoritative request descriptor for `portal.net` lease issuance; includes stable `req_id` for retry/dedupe correlation.
  - Added ACP kind **`portal.net.request`** (ordered within `domain.id`; profile-gated by `cfg.params.lane.portal.net`) so network leases can be requested as **LLM proposals** and executed via deterministic validators with transcript-visible outcomes.
- Hybrid + commutativity wiring (D-COMMUTE):
  - Updated the ACP kind registry and commutativity predicate registry to include `portal.net.request` (explicit predicate + normalized observation boundary).
  - Added serialization-boundary token `svc:portal.net` to the closed registry.
- Wiring + registries + evidence:
  - Updated the schema registry and docs index (`docs/README.md`) to link CH-NETREQ.
  - Updated D-NETLEASE in `decision-map.md` to mention the ACP kind and the request/lease split (CH-NETREQ → CH-NETLEASE).
  - Added **I-NETREQ-1**, **PO-NETREQ-VALIDATE**, and **PO-ACP-NET-REQUEST**; registered **EVID-2026-190**.

## Revised176 (2026-02-28)
- Tightened least-authority + sealed-kill-switch audit surfaces by making **policy/authority denials digest-bound** on the stable CH-DENY receipt surface (prevents “which policy?” from drifting into ambient/log-only explanations):
  - Updated `docs/30-architecture/deny-code-registry.md` to require `reason.ref_digest = digest(CH-POLICY v0)` bindings for `missing-approval`, `expired-approval`, and `policy-deny`.
  - Strengthened CH-DENY v0 producer rules (`docs/30-architecture/denial-receipt-schema-v0.md`) so these deny codes MUST set `reason.kind="policy"` and MUST bind `reason.ref_digest` to the pinned policy handle digest.
  - Updated ACP validator semantics (`docs/70-llm-control/acp-validator-semantics.md`) to emit these bindings on Reject paths and added an explicit “Policy/authority denials are digest-bound” section.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_deny_policy_bindings.py` and wired it into `make lint`.
  - Enforces coherence across deny-code registry + CH-DENY producer rules + ACP semantics so policy-deny bindings cannot silently drift.
- Assurance + evidence wiring:
  - Added **I-DENY-5** and **PO-DENY-POLICY-BIND**; registered **EVID-2026-189**.

## Revised175 (2026-02-28)
- Tightened least-authority workflow intent posture by making “what is this run for?” **schema-pinned and profile-gated** (prevents intent drifting into ambient/prose-only channels while keeping A–D viable without forks):
  - Added **CH-EXECPACK v2** (`docs/30-architecture/capshell-exec-pack-schema-v2.md`): exec-pack now supports an optional `plumbmsg_digest = digest(CH-PLUMBMSG v0)` non-authoritative intent envelope (D-PLUMB) alongside the complete workflow context + `reqctx_digest = digest(CH-REQCTX v1)`.
  - Added `cfg.params.capshell.require_plumbmsg` (veto-only) and pinned A–D defaults in `profile-workflow-defaults.md` so strict profiles can require an explicit CH-PLUMBMSG envelope for `capshell.exec` without forks.
  - Added new deterministic deny token `plumbmsg-missing` to the closed deny-code registry for missing required intent envelopes (receipt-shaped; no ad-hoc strings).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_capshell_plumbmsg_req.py` and wired it into `make lint`.
  - Enforces coherence across cfg toggle registry + profile defaults + CH-EXECPACK v2 + ACP semantics/kind registry + deny-code vocabulary + assurance/evidence wiring (prevents silent regression to prose-only intent).
- Version/wiring updates:
  - Updated capshell/ACP wiring to treat CH-EXECPACK v2 as the normative exec-pack for `capshell.exec` (schema registry, decision map, ACP schema/semantics, CLI plumbing doc).
  - Updated the existing exec-pack reqctx drift gate and evidence entry (**EVID-2026-153**) to reference CH-EXECPACK v2.
- Assurance + evidence wiring:
  - Added **I-CAPSHELL-PLUMBMSG-1** and **PO-CAPSHELL-PLUMBMSG-REQ**; registered **EVID-2026-188**.

## Revised174 (2026-02-28)
- Tightened D-COMMUTE reject evidence so ordering failures stay **receipt-shaped** (no ambient/prose-only “ordering failed” explanations):
  - Updated `deny-code-registry.md` to require digest bindings for ordering denials:
    - `conflict-key-invalid` MUST bind `conflict_key_digest` (rejecting digest; for CH-ACP this is `meta.conflict_key_digest`).
    - `order-witness-missing` MUST bind `conflict_key_digest` (names the serialization domain even when `meta.order_digest` is absent).
    - `order-witness-invalid` MUST bind `order_digest` (and SHOULD bind `conflict_key_digest`).
  - Strengthened CH-DENY v0 producer rules to set `reason.kind="ordering"` and bind the relevant digest fields for these deny codes.
  - Updated ACP validator semantics to explicitly emit these bindings on `Reject(..)` paths (keeps Hybrid + commutativity audit surfaces stable).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_deny_ordering_bindings.py` and wired it into `make lint`.
  - Enforces coherence across deny-code registry, CH-DENY producer rules, and ACP semantics so ordering-deny bindings cannot silently drift.
- Assurance + evidence wiring:
  - Added **I-DENY-4** and **PO-DENY-ORDER-BIND**; registered **EVID-2026-187**.

## Revised173 (2026-02-28)
- Tightened lane kill-switch evidence to stay **explicit and reviewable** (prevents drift into ambiguous `lane-disabled` denials):
  - Strengthened CH-DENY v0 producer rules: for `deny_code == lane-disabled` and `deny_code == cfg-deny`, producers MUST bind `reason.kind="lane"` and MUST set `reason.ref_key=<cfg.params.* key>` naming the **registry-closed** gate/knob in `config-toggle-registry.md` (no ambient “which toggle fired?” state).
  - Updated ACP validator semantics to require the same `reason.ref_key` binding for lane/cfg-param gating rejections (stable receipt surface; LLM tooling can audit kill switches from transcripts).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_deny_lane_refkey.py` and wired it into `make lint`.
  - Enforces coherence across deny-code registry, CH-DENY schema, and ACP semantics so lane/cfg deny bindings cannot silently drift.
- Assurance + evidence wiring:
  - Strengthened **I-LANEGATE-1** and **PO-LANE-KILL** to treat `reason.ref_key` binding as part of lane-gate receipt visibility; registered **EVID-2026-186**.

## Revised172 (2026-02-28)
- Tightened least-authority workflow execution by making **explicit sponsorship** enforceable on the stable schema surface (no implicit budgets in automation):
  - Added `cfg.params.capshell.require_budget_lease` (veto-only). When true **and** `cfg.params.lane.metering=true`, `capshell.exec` requires the bound CH-REQCTX v1 to include at least one `budget_desc_digests` entry that resolves/validates as **CH-BUDGET v0** (D-BUDGET; I-BUDGET-1).
  - Added new deterministic denial token `budget-missing` to the closed deny-code registry for missing required budget leases (binds to the CH-REQCTX digest; no ambient sponsorship).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_capshell_budget_reqctx.py` and wired it into `make lint`.
  - Enforces closure + wiring across the cfg toggle registry, A–D workflow defaults matrix, ACP semantics/kind registry, deny-code vocabulary, and PO/I/EVID surfaces.
- Assurance + evidence wiring:
  - Added **I-CAPSHELL-BUDGET-1** and **PO-CAPSHELL-BUDGET-REQ**; registered **EVID-2026-185**.
- Wiring updates:
  - Updated `docs/30-architecture/decision-map.md` (D-CAPSHELL) to point at the new knob.
  - Updated `docs/70-llm-control/acp-validator-semantics.md` and `docs/70-llm-control/acp-action-kind-registry.md` to make the budget requirement explicit and receipt-shaped.
  - Updated `docs/00-meta/trajectory-map.md` with an open question on typed budget references in CH-REQCTX.

## Revised171 (2026-02-28)
- Tightened D-COMMUTE for the LLM-first action surface by pinning **per-kind commutation predicates** and **normalized observation boundaries** for swap-order tests:
  - Added `docs/70-llm-control/acp-commutativity-predicate-registry.md` (v0) as a stable diff surface for CH-ACP kinds.
  - Updated D-COMMUTE references to treat this as part of the commutativity evidence substrate (in addition to the ACP kind registry and hot-action surfaces).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_acp_commutativity_predicates.py` and wired it into `make lint`.
  - Enforces closure: every CH-ACP kind must have a predicate entry with explicit `Predicate:` and `Normalize:` anchors mentioning CH-ACPOUT + `conflict_key_digest` (prevents planner-unsafe “commutes” drift into prose).
- Assurance + evidence wiring:
  - Added **I-ACP-COMMUTE-1** and **PO-ACP-COMMUTE-PREDMAP**; registered **EVID-2026-184**.

## Revised170 (2026-02-28)
- Added a **profiled workflow hardening knob** for capshell execution context:
  - Introduced `cfg.params.capshell.minimal_context` (veto-only) to require a *minimal* `capshell.exec` context: empty CH-ENV, CH-CWD `kind="empty"`, CH-STDIO `(null, drop, drop)`, empty CH-FDSET, and exactly one CH-ARGV `role="exec"` selector (no ambient PATH).
  - Pinned non-authoritative A–D defaults in `docs/30-architecture/profile-workflow-defaults.md` (no forks).
- Denial + receipt hygiene (entropy-reducing refactor):
  - Added new deny code `cfg-deny` to the closed deny-code registry for cfg-param gates (bind `reason.ref_key = <cfg.params.* key>`).
  - Fixed CH-DENY v0 to include `reason.kind="reqctx"` in its closed enum, aligning the schema with existing `reqctx-mismatch` guidance and ACP semantics.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_profile_workflow_defaults.py` and wired it into `make lint`.
  - Enforces that any `cfg.params.capshell.*` knob is registry-closed, has A–D defaults pinned, and is referenced from capshell/ACP control docs (prevents drift back into prose-only “strict profile” workflow rules).
- Assurance + evidence wiring:
  - Added **I-CAPSHELL-MINCTX-1** and **PO-CAPSHELL-MINCTX-ENF**; registered **EVID-2026-183**.

## Revised169 (2026-02-28)
- Made **retry/dedupe outcomes mechanically distinguishable** on the stable receipt surface:
  - Extended **CH-ACPOUT v0** with an optional closed `effect` field for `accept` outcomes: `applied` | `no_op` | `duplicate_suppressed`.
  - Tightened D-RETRYSAFE / ACP semantics to recommend `effect="duplicate_suppressed"` when a proposal is accepted but deduped (pre-effect suppression remains mandatory; no grant-by-id).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_acp_outcome_effect_status.py` and wired it into `make lint`.
  - Enforces that CH-ACPOUT effect-status anchors and `duplicate_suppressed` wiring remain present across ACP semantics, the ACP kind registry, and PO-RETRY-DEDUP.
- Assurance + evidence wiring:
  - Updated **I-RETRY-1** and **PO-RETRY-DEDUP** to explicitly bind dedupe visibility to CH-ACPOUT `effect`.
  - Registered **EVID-2026-182**.

## Revised168 (2026-02-28)
- Tightened the LLM-first action substrate by pinning **deterministic retry/dedupe semantics** (no duplicate effects under retries):
  - Added decision surface **D-RETRYSAFE** (schema-pinned idempotency keys for any kind that claims *at-least-once-safe*).
  - Updated ACP semantics docs to make dedupe obligations explicit and non-authoritative (no grant-by-id).
  - Updated the trajectory-map open question to treat CH-EFFCON `contract_id` as the canonical idempotency key for `capshell.exec` (output-normal-form remains the open follow-up).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_retry_dedupe_wiring.py` and wired it into `make lint`.
  - Enforces that any ACP kind marked **at-least-once-safe** names an explicit stable id key token (e.g., CH-EFFCON `contract_id`, CH-JOBREQ `job_id`, CH-TIMEREQ `req_id`, CH-NOTIF.id), preventing “retry safe” prose drift.
- Assurance + evidence wiring:
  - Added **I-RETRY-1** and **PO-RETRY-DEDUP**; registered **EVID-2026-181**.
- Wiring updates:
  - Documented the new drift gate in `tools/README.md`, noted it in `README.md`, and updated `docs/70-llm-control/acp-validator-semantics.md` + `docs/70-llm-control/acp-action-kind-registry.md`.

## Revised167 (2026-02-28)
- New CI drift gate to prevent **context-pack drift** (LLM amnesia resistor):
  - Added `tools/check_context_pack_contract.py` and wired it into `make lint`.
  - The check generates a context pack into `out/_ci_context_pack.md` and enforces the contract: header revision/date matches the top CHANGELOG entry; required sections exist (non-negotiables, must-read set, profile matrix, open questions, commands); and all four profile rows remain present.
- Assurance + evidence wiring:
  - Added **I-CTXPACK-1** and **PO-CTXPACK-CONTRACT**; registered **EVID-2026-180**.
- Wiring updates:
  - Documented the new drift gate in `tools/README.md` and noted it in `README.md` repo checks.

## Revised166 (2026-02-28)
- New CI drift gate for the least-authority self-restriction surface (CH-PLEDGE token coherence):
  - Added `tools/check_pledge_token_mapping.py` and wired it into `make lint`.
  - Enforces that `docs/30-architecture/pledge-token-mapping.md` covers the closed CH-PLEDGE v0 token set declared in `docs/30-architecture/pledge-contract-schema-v0.md` exactly (no missing/extra/duplicate tokens), preventing “shadow promise tokens” from drifting into the archive.
- Assurance + evidence wiring:
  - Added **I-PLEDGE-4** and **PO-PLEDGE-MAP-CLOSE**; registered **EVID-2026-179**.
- Wiring updates:
  - Indexed CH-PLEDGE docs from `docs/README.md`, documented the drift gate in `tools/README.md`, and noted the new check in `README.md`.

## Revised165 (2026-02-28)
- Refactor: moved the closed ACP serialization-boundary token allowlist (`validator` / `svc:<name>` / `none`) out of `commutativity-and-interface-scalability.md` into a dedicated stable diff surface:
  - Added `docs/30-architecture/serialization-boundary-registry.md` (v0; closed).
  - Updated `docs/30-architecture/commutativity-and-interface-scalability.md` to reference the registry instead of embedding the table.
- CI drift gate update:
  - Updated `tools/check_acp_serialization_boundary_registry.py` to parse the allowlist from `serialization-boundary-registry.md`.
- Assurance + evidence wiring:
  - Updated **I-ACTMETA-1** and **PO-ACT-KINDMETA** to point at the new registry; registered **EVID-2026-178**.
- Wiring updates:
  - Linked the new registry from `README.md`, `docs/README.md`, `docs/30-architecture/decision-map.md`, and ACP kind registry notes.

## Revised164 (2026-02-28)
- New CI drift gate for privileged-surface discovery: IF-ID reference closure.
  - Added `tools/check_interface_registry_refs.py` and wired it into `make lint`.
  - Enforces that any `IF-...` token referenced in repo markdown (docs/RFCs/ADRs/README) must be present in `docs/30-architecture/interface-registry.md` (prevents typo’d/"shadow" interfaces).
- Assurance + evidence wiring:
  - Added **I-IFREF-1** and **PO-IFREF-CLOSE**; registered evidence hook **EVID-2026-177**.
- Wiring updates:
  - Noted the drift gate in `docs/30-architecture/interface-registry.md` and documented the tool in `tools/README.md`.

## Revised163 (2026-02-28)
- New CI drift gate to prevent “svc-name drift” in multicore/commutativity evidence surfaces:
  - Added a **closed serialization-boundary token registry** in `docs/30-architecture/commutativity-and-interface-scalability.md` (stable diff surface for `validator`/`svc:<name>` tokens used by ordered CH-ACP kinds).
  - Added `tools/check_acp_serialization_boundary_registry.py` and wired it into `make lint` to enforce allowlist closure for the ACP kind registry’s Serialization boundary column.
- Assurance + evidence wiring:
  - Strengthened **I-ACTMETA-1** and **PO-ACT-KINDMETA** to treat serialization-boundary tokens as registry-closed; registered evidence hook **EVID-2026-176**.
- Wiring updates:
  - Documented the new drift gate in `tools/README.md` and added a CI note in `docs/70-llm-control/acp-action-kind-registry.md`.

## Revised162 (2026-02-28)
- Integrated D-BGLEASE into the LLM-first, validator-executed surface (no ambient background/autostart APIs):
  - Added **CH-BGREQ v0** (`docs/30-architecture/background-request-schema-v0.md`), a bounded request descriptor (no capability material) for background/autostart grants.
  - Added ACP kind **`portal.background.request`** and wired it through ACP docs + validator semantics (ordered within `domain.id`; explicit serialization boundary `svc:portal.background`; policy-killable via `cfg.params.lane.portal.background`).
  - Updated RFC-0103 and decision-map D-BGLEASE to reflect the CH-BGREQ→portal→CH-BGLEASE flow and the ACP seam.
- Assurance + evidence wiring:
  - Added **I-BGREQ-1**, **PO-BGREQ-VALIDATE**, and **PO-ACP-BGLEASE-REQUEST**; registered evidence hook **EVID-2026-175**.
- Wiring updates:
  - Updated portal registry + pledge mapping + effect-contract allowlist to reference CH-BGREQ as the request descriptor; updated docs indexes (README + docs/README).

## Revised161 (2026-02-28)
- New CI drift gate to keep drift gates alive and discoverable (LLM-resilience / prevents silent lint degradation):
  - Added `tools/check_guardrail_wiring.py` and wired it into `make lint`.
  - Enforces that every `check_*.py` drift gate under `tools/` is invoked by `make lint`, exists on disk, and is referenced in `tools/README.md`.
- Assurance + evidence wiring:
  - Added **I-TOOLWIRE-1** and **PO-TOOLWIRE-CLOSE**; registered evidence hook **EVID-2026-174**.
- Wiring update:
  - Documented the new drift gate in `tools/README.md`.

## Revised160 (2026-02-28)
- New CI drift gate for the assurance substrate (prevents traceability drift under LLM edits):
  - Added `tools/check_assurance_token_refs.py` and wired it into `make lint`.
  - Enforces registry-closure for assurance IDs across repo markdown: A-* (assumptions), C-* (claims), I-* (invariants), PO-* (proof obligations). Undefined/typo'd assurance IDs (including in registries themselves) fail CI.
- Assurance + evidence wiring:
  - Added **I-ASSUREREF-1** and **PO-ASSUREREF-CLOSE**; registered evidence hook **EVID-2026-173**.
- Entropy-reducing refactor (caught by the new registry-closure gate):
  - De-duplicated **I-WASM-1** by renaming the "Closed import set" invariant to **I-WASM-4** and updating references (PO-WASM-IMPORTS, RFC-0052, AC-041, and related notes).
- Wiring update:
  - Documented the tool in `tools/README.md` and added the new check to `Makefile` `lint`.

## Revised159 (2026-02-28)
- Expanded schema reference closure (LLM-resilience for the schemas/validators/receipts product surface):
  - Added `tools/check_schema_token_refs.py` and wired it into `make lint`.
  - Rejects `docs/` mentions of versioned schema tokens of the form `CH-XYZ vN` unless the (CH-ID,version) pair exists in `docs/30-architecture/schema-registry.md` (catches prose/example typos beyond `digest(...)` references).
- Assurance + evidence wiring:
  - Added **I-SCHEMAREF-2** and extended **PO-SCHEMAREF-CLOSE** to cover both `digest(CH-XYZ vN)` and plain `CH-XYZ vN` references; registered evidence hook **EVID-2026-172**.
- Wiring update:
  - Noted the new drift gate in `docs/30-architecture/schema-registry.md` and documented the tool in `tools/README.md`.

## Revised158 (2026-02-28)
- New CI drift gate to keep the closed `portal.*` workflow authority taxonomy honest in *prose* docs:
  - Added `tools/check_portal_token_refs.py` and wired it into `make lint`.
  - Rejects `docs/` references to backticked `portal.*` tokens unless their root family exists in `docs/30-architecture/portal-family-registry.md` (prevents unreviewed portal seams / workflow authority drift).
- Assurance + evidence wiring:
  - Added **I-PORTALREF-1** and **PO-PORTALREF-CLOSE**; registered evidence hook **EVID-2026-171**.
- Wiring update:
  - Noted the new drift gate in `portal-family-registry.md` and documented the tool in `tools/README.md`.

## Revised157 (2026-02-28)
- New CI drift gate for profile-extension vocabulary: added `tools/check_feature_flag_refs.py` and wired it into `make lint`.
  - Rejects `docs/` references to backticked `ext.*` `cfg.feature_flags` values unless they exist in the closed set pinned in `docs/30-architecture/config-toggle-registry.md` (prevents typo’d/shadow feature flags).
- Assurance + evidence wiring:
  - Added **I-FLAGREF-1** and **PO-FLAGREF-CLOSE**; registered evidence hook **EVID-2026-170**.
- Wiring update:
  - Added the new drift gate to the config-toggle registry evidence seed list.

## Revised156 (2026-02-28)
- Integrated D-JOBS into the LLM-first ACP surface (no ambient cron/alarms):
  - Added ACP kind `portal.jobs.submit` (ordered within `domain.id`, serialization boundary `svc:portal.jobs`) that binds `jobreq_digest = digest(CH-JOBREQ v0)` and is policy-killable via `cfg.params.lane.portal.jobs`.
  - Updated ACP schema/examples and validator semantics to require canonical CH-JOBREQ validation and fail-closed lane gating before invoking the portal; outcomes are transcript-visible (CH-ACPOUT/CH-DENY) with explicit conflict_key/order digests.
- Assurance + evidence wiring:
  - Added **PO-ACP-JOBS-SUBMIT** and registered evidence hook **EVID-2026-169** (ACP/job portal harness plan).
- Wiring updates:
  - Updated RFC-0096, D-JOBS decision-map entry, CH-JOBREQ schema notes, and `docs/README.md` to reference the ACP seam.

## Revised155 (2026-02-28)
- Integrated D-TIMEPROOF into the LLM-first ACP surface (no ambient time assumptions):
  - Added CH-TIMEREQ v0 (`docs/30-architecture/timeproof-request-schema-v0.md`) as a bounded, endpoint-free request descriptor.
  - Added ACP kind `portal.clock.timeproof.sample` that binds `timereq_digest = digest(CH-TIMEREQ v0)` and yields CH-TIMEPROOF evidence; ordered within `domain.id` with explicit `svc:portal.clock` serialization boundary.
- Kept the seam policy-killable and profile-friendly (A–D; no forks):
  - Added lane kill switch `cfg.params.lane.timeproof` (in addition to `cfg.params.lane.portal.clock`) and pinned A–D defaults in `profile-lane-defaults.md`.
- Assurance + evidence wiring:
  - Added **I-TIMEREQ-1**, **PO-TIMEREQ-VALIDATE**, and **PO-ACP-TIMEPROOF-SAMPLE**; registered evidence seed **EVID-2026-168**.
- Discovery/anti-drift hardening:
  - Extended `tools/check_discovery.py` to require CH-TIMEPROOF/CH-TIMEREQ artifacts remain indexed from `docs/README.md`.

## Revised154 (2026-02-28)
- New stable diff surface for profile composition (no forks): added `docs/30-architecture/profile-feature-flag-defaults.md` to pin **non-authoritative** A–D defaults for the closed `cfg.feature_flags` set.
- New CI drift gate (LLM-resilience for profile posture): added `tools/check_profile_feature_flag_defaults.py` and wired it into `make lint`. It enforces matrix closure over the `cfg.feature_flags` closed set in `config-toggle-registry.md` (no silent omission/widening of default profile-extension posture).
- Wiring + assurance:
  - Linked the new matrix from `docs/README.md` and referenced it from `config-toggle-registry.md`.
  - Added **I-PROFFLAGDEFAULTS-1**, **PO-PROFFLAGDEFAULTS-VERIFY**, and evidence **EVID-2026-167**.

## Revised153 (2026-02-28)
- Entropy-reducing refactor: centralized the D-PLUMB workflow `intent.kind` vocabulary as a single stable diff surface:
  - Added `docs/30-architecture/intent-kind-registry.md` as the canonical closed taxonomy shared by CH-PLUMBMSG v0 and CH-ROUTE v0 (non-authoritative; unknown kinds reject).
  - Updated `plumb-message-schema-v0.md` and `route-rules-schema-v0.md` to reference the canonical registry (no shadow enum lists in schema docs).
  - Wired the registry into discovery/control points (`docs/README.md` and the D-PLUMB section of `decision-map.md`).
- New CI drift gate (LLM-resilience for workflow semantics):
  - Added `tools/check_intent_kind_registry.py` and wired it into `make lint`. It enforces that the canonical kind list is defined only in the registry and rejects any local `intent.kind` enum bullet lists near closed-enum declarations (prevents typo’d intents and “shadow vocabularies”).
- Assurance + evidence wiring:
  - Added **I-INTENTKIND-1** and **PO-INTENTKIND-CLOSE**.
  - Evidence: registered **EVID-2026-166**.

## Revised152 (2026-02-28)
- New CI drift gate to keep **decision references** mechanically closed and LLM-resilient:
  - Added `tools/check_decision_map_refs.py` and wired it into `make lint`. It enforces that any `D-*` identifier referenced in the `docs/` tree has a corresponding entry in `docs/30-architecture/decision-map.md` (prevents orphan decision IDs and keeps the decision→schemas→invariants→POs→evidence chain discoverable).
- Assurance + evidence wiring:
  - Added **I-DECISIONMAP-1** and **PO-DECISIONMAP-CLOSE**.
  - Evidence: registered **EVID-2026-165**.

## Revised151 (2026-02-28)
- Tightened sealed-compat killability with **granular Foreign Cell adapter lane gates** (no ambient interop growth):
  - Added per-adapter kill switches `cfg.params.lane.fcell.adapter.*` (v0 seed: `posix_open_via_doc_portal`, `posix_socket_via_net_portal`) so enabling the Foreign Cell lane does not implicitly enable specific adapter-mediated host workflows.
  - Updated D-FCELL control points to require **both** the adapter gate and the bound portal gate to be enabled (missing toggles fail closed): `foreign-cell-contract.md`, `foreign-cell-manifest-schema-v0.md`, `fcell-adapter-kind-registry.md`, `config-toggle-registry.md`, and `profile-lane-defaults.md`.
- Drift gate strengthening (LLM-resilience):
  - Extended `tools/check_fcell_adapter_registry.py` to require each adapter kind row has a corresponding `cfg.params.lane.fcell.adapter.<adapter_kind>` kill switch (in addition to portal lane kill switches), preventing silent compat interop widening.
- Assurance + evidence wiring:
  - Updated I-FADAPT-2 / I-FADAPT-3 and PO-FADAPT-EMIT / PO-FADAPT-KINDREG to reflect adapter-level lane gating.
  - Evidence: registered **EVID-2026-164**.

## Revised150 (2026-02-28)
- Entropy-reducing refactor: made the CH-CONFLICTKEY **family allowlist** a first-class stable diff surface.
  - Added `docs/30-architecture/conflict-key-family-registry.md` as the canonical closed family list and wired it into discovery/control points (docs index, D-COMMUTE decision map, and CH-CONFLICTKEY schema).
- New CI drift gate (LLM-resilience for D-COMMUTE/Hybrid):
  - Added `tools/check_conflictkey_family_registry.py` and wired it into `make lint`. It enforces schema↔registry closure and rejects any `family="..."` references across docs that use unknown family tokens (prevents typo'd family strings from silently drifting validators/evidence harnesses).
- Assurance + evidence wiring:
  - Updated **I-CONFLICTKEY-1** to point to the canonical family registry and extended **PO-CONFLICTKEY-VALIDATE** evidence.
  - Evidence: registered **EVID-2026-163**.

## Revised149 (2026-02-28)
- New CI drift gate to keep **evidence hooks** mechanically closed and LLM-resilient:
  - Added `tools/check_evidence_refs.py` and wired it into `make lint`. It enforces that any `EVID-YYYY-NNN` token referenced in repo markdown resolves to an entry in `docs/00-meta/evidence-index.md` and that evidence IDs are unique (prevents evidence-hook typos and orphaned references).
- Assurance wiring:
  - Added invariant **I-EVID-1** and proof obligation **PO-EVID-CLOSE** so evidence-token closure is an explicit part of the authority-substrate invariants/PO surface.
- Evidence: registered **EVID-2026-162**.

## Revised148 (2026-02-28)
- New CI drift gate to keep **Hybrid + D-COMMUTE** hot-path evidence mechanically honest:
  - Added `tools/check_hot_action_wiring.py` and wired it into `make lint`. It enforces that `hot-action-surface-v0.md` and `hot-action-boundaries-v0.md` name the same pinned family set, and that each family retains explicit conflict-key / ordering-token / replication-contract statements (prevents “hot action” taxonomy drift).
  - Updated `docs/30-architecture/hot-action-boundaries-v0.md` to name the tool as the enforcement surface.
- Evidence: registered **EVID-2026-161**.

## Revised147 (2026-02-28)
- Integrated the attention portal into the **LLM-first ACP surface** without introducing ambient notification APIs:
  - Added ACP kind `portal.attn.request` (profile-gated by `cfg.params.lane.portal.attn`) that binds `notif_digest = digest(CH-NOTIF v0)` and routes requests through the mediated `portal.attn.*` seam.
  - Pinned commutativity/ordering metadata in the ACP kind registry (ordered within `domain.id`; explicit `svc:portal.attn` serialization boundary) to keep Hybrid + D-COMMUTE honest.
- Assurance + evidence wiring:
  - Added **PO-ACP-ATTN-REQUEST** and registered evidence seed **EVID-2026-160** for lane-gate negative tests, CH-NOTIF digest binding, and ordered-witness enforcement.
- New guardrail (drift prevention):
  - Extended `tools/check_acp_kindmeta.py` to verify that any ACP kind starting with `portal.` corresponds to a portal family token in `portal-family-registry.md` and is explicitly lane-gated via `cfg.params.lane.portal.<family>` (keeps workflow seams policy-killable and prevents portal taxonomy drift inside ACP).
- Wiring:
  - Updated D-ATTN decision-map note and CH-NOTIF schema to reference the ACP invocation seam.




## Revised146 (2026-02-28)
- Integrated D-ATTN into the **portal taxonomy** as a first-class, policy-killable workflow seam (no ambient notification APIs):
  - Added the attention portal family `portal.attn.*` with CH-PLEDGE token `portal.attn` to `docs/30-architecture/portal-family-registry.md`.
  - Wired the new portal token through all closed-world control points (no forks):
    - CH-PLEDGE token set (`docs/30-architecture/pledge-contract-schema-v0.md`)
    - pledge token→effect mapping (`docs/30-architecture/pledge-token-mapping.md`)
    - Foreign Cell portal allowlist seed (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`)
    - lane kill switch registry (`docs/30-architecture/config-toggle-registry.md`) + A–D defaults (`docs/30-architecture/profile-lane-defaults.md`)
    - CH-EFFCON effect kind + lane mapping + workflow descriptor allowlist table (`docs/30-architecture/effect-contract-schema-v0.md`)
- Tightened assurance/evidence around notifications as a schema+validator surface:
  - Added **PO-NOTIF-VALIDATE** and registered evidence seed **EVID-2026-159** for CH-NOTIF v0 validation + lane-gate negative tests.
  - Updated `docs/30-architecture/notification-request-schema-v0.md` to explicitly bind to `portal.attn.*` + `cfg.params.lane.portal.attn` and to spell out lane-disabled deny semantics.
- New amnesia-resistor guardrail:
  - Extended `tools/check_discovery.py` to require CH-NOTIF be indexed from `docs/README.md` when present (prevents D-ATTN from drifting into orphan docs).
- Wiring:
  - Updated `docs/README.md` (added portal-family registry + CH-NOTIF) and repo `README.md` pointers.

## Revised145 (2026-02-28)
- Strengthened archive amnesia-resistance around the **stable diff surfaces** by pinning bibliography + evidence hooks into the must-read loop:
  - Updated `docs/00-meta/llm-runbook.md` must-read set to include `docs/00-meta/bibliography.md` and `docs/00-meta/evidence-index.md`.
  - Extended `tools/check_discovery.py` to fail CI if those stable surfaces drop out of the must-read set.
- Discovery wiring:
  - Updated `docs/README.md` to reference `00-meta/evidence-index.md` and `30-architecture/multicore-architecture-options.md`.
  - Updated `tools/README.md` to list `check_discovery.py` and `gen_context_pack.py` as first-class guardrails.
- Wiring + evidence:
  - Registered evidence seed **EVID-2026-158**.

## Revised144 (2026-02-28)
- Strengthened denial semantics as a stable, schema-pinned product surface by adding a new CI drift gate:
  - Added `tools/check_deny_code_refs.py` and wired it into `make lint`. It scans repo markdown for lines that explicitly name a `deny_code` token (e.g., `deny_code = invalid-schema`, `deny_code: invalid-schema`, or `deny_code \`invalid-schema\``) and fails if the token is not present in `docs/30-architecture/deny-code-registry.md`.
  - Updated `deny-code-registry.md` notes to reference the new drift gate.
- Wiring + assurance + evidence:
  - Updated **PO-DENY-CODES** and **I-DENY-3** to reflect registry-closed deny-code references in docs/examples.
  - Registered evidence seed **EVID-2026-157** and documented the tool in `tools/README.md`.

## Revised143 (2026-02-28)
- Tightened **Hybrid + D-COMMUTE** scalability evidence by making serialization points mechanically explicit for ordered ACP kinds:
  - Refactor: extended the ACP kind registry table with a new `Serialization boundary` column. For any kind whose stance includes **ordered**, the boundary must be `validator` or `svc:<name>`; non-ordered kinds must use `none`.
  - Added `tools/check_acp_serialization_boundary.py` and wired it into `make lint` to prevent “ordered-but-nowhere” drift (LLM-amnesia resistor).
  - Updated the D-COMMUTE doc to reference the registry field as the audit surface for explicit serialization owners.
- Wiring + assurance + evidence:
  - Updated **I-ACTMETA-1** and **PO-ACT-KINDMETA** to cover serialization-boundary metadata.
  - Registered evidence seed **EVID-2026-156** and documented the tool in `tools/README.md`.

## Revised142 (2026-02-28)
- Strengthened archive **discovery surfaces** and LLM-resilience by adding a new CI drift gate that keeps bibliography references mechanically coherent:
  - Added `tools/check_bibliography_refs.py` and wired it into `make lint`. It scans repo markdown (docs/RFCs/ADRs/CHANGELOG) for `REF-*` tokens and fails if any referenced token is not defined in `docs/00-meta/bibliography.md` (or if the bibliography contains duplicate REF keys).
  - The guardrail also enforces that each bibliography REF entry line includes an explicit http(s) URL, keeping citations audit-friendly and avoiding “floating” refs.
- Refactor: deduplicated bibliography entries uncovered by the new gate (removed duplicate keys for **REF-RUMPKERNEL-ABC2015**, **REF-ARRAKIS-OSDI14**, and **REF-CAPNP-RPC**) and standardized the canonical Arrakis URL to the Usenix paper PDF.
- Wiring + assurance + evidence:
  - Added invariant **I-REF-1** and proof obligation **PO-REF-CLOSE**.
  - Registered evidence seed **EVID-2026-155** and documented the tool in `tools/README.md`.

## Revised141 (2026-02-28)
- Strengthened the **schemas/validators/receipts product surface** and LLM-resilience by adding a new CI drift gate that prevents schema/version typos from silently drifting the archive:
  - Added `tools/check_digest_schema_refs.py` and wired it into `make lint`. It scans docs for **versioned** schema digest references of the form `digest(CH-XYZ vN)` and fails if any reference does not resolve to an entry in `docs/30-architecture/schema-registry.md`.
  - Documented the guardrail in `docs/30-architecture/schema-registry.md` and `tools/README.md`.
- Wiring + assurance + evidence:
  - Added invariant **I-SCHEMAREF-1** and proof obligation **PO-SCHEMAREF-CLOSE**.
  - Registered evidence seed **EVID-2026-154**.

## Revised140 (2026-02-28)
- Tightened **no ambient authority in workflows** by making request-context correlation non-ambient at the capshell execution boundary:
  - Added **CH-EXECPACK v1** (`docs/30-architecture/capshell-exec-pack-schema-v1.md`): exec-pack now binds `reqctx_digest = digest(CH-REQCTX v1)` in addition to the complete workflow context digests (CH-EFFCON/ARGV/ENV/CWD/STDIO/FDSET).
  - Updated ACP/capshell control points to require `capshell.exec` use `exec_pack_digest = digest(CH-EXECPACK v1)` and to require `CH-ACP meta.reqctx_digest == CH-EXECPACK v1 reqctx_digest` (fail closed; recommended CH-DENY is `reqctx-mismatch`).
  - Refactored D-CAPSHELL decision-map wiring to explicitly include CH-EXECPACK v1 as the workflow completeness seal.
- New CI drift gate (LLM-amnesia resistor):
  - Added `tools/check_capshell_execpack_reqctx.py` and wired it into `make lint`. It fails if exec-pack v1 is missing/unregistered, if ACP/capshell semantics stop requiring reqctx coherence, or if the deny-code vocabulary drifts.
- Wiring + assurance + evidence:
  - Updated schema registry + docs index entries to prefer CH-EXECPACK v1 (v0 retained as legacy).
  - Added invariant **I-EXECPACK-2** and proof obligation **PO-CAPSHELL-REQCTX-BIND**.
  - Registered evidence seed **EVID-2026-153**.

## Revised139 (2026-02-28)
- Added a new CI drift gate to keep the schema registry a closed-world, stable diff surface:
  - Added `tools/check_schema_registry_complete.py` and wired it into `make lint`. It fails if any `*-schema-vN.md` spec file exists under `docs/30-architecture/` or `docs/70-llm-control/` but is missing from `docs/30-architecture/schema-registry.md` (prevents orphan schema specs and LLM drift).
  - Documented the guardrail in `tools/README.md` and noted it in `docs/30-architecture/schema-registry.md`.
- Evidence: registered **EVID-2026-152**.

## Revised138 (2026-02-28)
- Integrated **D-NONDET** into the canonical portal taxonomy to keep “no ambient nondeterminism” mechanically enforceable and drift-resistant:
  - Added `portal.clock` and `portal.entropy` as first-class portal families in `docs/30-architecture/portal-family-registry.md`; updated the CH-PLEDGE token set and the pledge token→effect mapping table accordingly (closed-world, fail-closed).
  - Updated **CH-EFFCON v0**: extended the closed effect-kind enum, lane-gate mapping, and the workflow descriptor allowlist so `capshell.exec` can bind **CH-CLOCK v0** / **CH-ENTROPY v0** descriptors only under declared `portal.clock` / `portal.entropy` effects (no ambient time/RNG).
  - Added explicit lane kill switches `cfg.params.lane.portal.clock` and `cfg.params.lane.portal.entropy` to the CH-CFG toggle registry and pinned A–D default guidance in the profile lane-defaults matrix (still veto-only; enabling never grants authority).
  - Updated CH-FCELL v0 portal-token seeds and the Foreign Cell contract to recognize `portal.clock`/`portal.entropy` issuance flows while keeping time/entropy as explicit resource handles (`resources.clocks` / `resources.entropy`) and preserving the sealed compat membrane.
  - Refactor: eliminated the one-off `portal.time` naming drift in RFC-0063 by renaming it to `portal.clock`.
- Assurance + evidence:
  - Updated **I-NONDET-1** and **PO-NONDET-NOAMBIENT** and registered **EVID-2026-151** (CI drift gates cover D-NONDET portal closure across portal registry/pledge/mapping/lane gates/effcon allowlist).

## Revised137 (2026-02-28)
- Tightened the **sealed POSIX/legacy Foreign Cell** membrane and the **LLM-first schemas/receipts surface** by adding an additive correlation hook for compat adapter receipts:
  - Added **CH-FADAPT v1** (`docs/30-architecture/fcell-adapter-receipt-schema-v1.md`): identical to v0 plus optional `reqctx_digest = digest(CH-REQCTX v1)` (non-authoritative; veto-only). This removes “implicit context” drift for profiles that want end-to-end correlation without introducing ambient authority.
  - Updated wiring surfaces to reference v0/v1 receipts (decision map D-FCELL, foreign cell contract, CH-FCELL manifest notes, schema registry, docs index).
- Strengthened CI drift gates (LLM-amnesia resistors):
  - Extended `tools/check_fcell_adapter_registry.py` to additionally enforce that if CH-FADAPT v1 exists it is registered, discoverable, and references both the adapter-kind registry and CH-REQCTX v1 (prevents orphan schema + correlation-hook drift).
- Assurance + evidence:
  - Added invariant **I-FADAPT-4** (reqctx propagation is non-authoritative/veto-only) and updated **PO-FADAPT-VALIDATE** to cover v0/v1.
  - Registered evidence seed **EVID-2026-150**.

## Revised136 (2026-02-28)
- Addressed the “no forks” profile viability mandate by pinning **non-authoritative A–D default guidance** for lane kill switches as a stable diff surface:
  - Added `docs/30-architecture/profile-lane-defaults.md` (profile default matrix for `cfg.params.lane.*`, including the complete `cfg.params.lane.portal.*` set).
  - Updated the CH-CFG toggle registry to reference the matrix for profile-dependent default guidance (without changing fail-closed lane semantics).
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_profile_lane_defaults.py` and wired it into `make lint`. It fails if the profile defaults matrix is not complete/closed over the `cfg.params.lane.*` key set pinned in `config-toggle-registry.md`, contains unknown keys, or uses values outside `{on,off}`.
- Wiring + assurance + evidence:
  - Added invariant **I-PROFDEFAULTS-1** and proof obligation **PO-PROFDEFAULTS-VERIFY**.
  - Registered evidence seed **EVID-2026-149** and updated discovery surfaces (`docs/README.md`, `tools/README.md`, decision map D-PLUMB note).

## Revised135 (2026-02-28)
- Added a new CI guardrail (LLM-amnesia resistor) to keep **no ambient authority** + **policy-killability** honest for CH-CFG: `tools/check_cfg_key_refs.py` fails `make lint` if any docs reference backticked `cfg.params.*` keys that are not present in the canonical closed set pinned in `docs/30-architecture/config-toggle-registry.md` (prevents “ambient toggles” / unreviewable lane gates).
- Wiring + assurance + evidence:
  - Wired the new check into `make lint` and documented it in `tools/README.md`.
  - Registered evidence seed **EVID-2026-148** and attached it to **PO-CFGTOGGLE-VERIFY**.
  - Updated CH-CFG toggle registry to cite the new evidence seed.

## Revised134 (2026-02-28)
- Tightened the **schemas/receipts are the product surface** + **LLMs propose; validators execute** pillars by making request contexts a stable, digest-only substrate in the ACP: CH-ACP proposals now MUST carry `meta.reqctx_digest = digest(CH-REQCTX v1)` (non-authoritative; veto-only).
  - Updated ACP control points to validate and echo `reqctx_digest` into CH-LOG v0 and CH-ACPOUT v0 (digest-only; redaction-safe), preventing ad-hoc correlation/idempotency drift and keeping replay/audit mechanically checkable.
  - Updated CH-ACPOUT v0 and the CH-LOG contract to include `reqctx_digest` as a first-class observability field (never authorization evidence).
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_acp_reqctx_wiring.py` and wired it into `make lint`. It fails if CH-ACP/ACP semantics stop requiring CH-REQCTX v1, if CH-LOG/CH-ACPOUT stop echoing it, or if wiring/assurance references drift.
- Wiring + assurance + evidence:
  - Updated schema registry + docs indexes for CH-REQCTX v1.
  - Added invariant **I-ACP-REQCTX-1** and proof obligation **PO-ACT-REQCTX**; registered evidence seed **EVID-2026-147**.
## Revised133 (2026-02-28)
- Tightened the **sealed POSIX/legacy Foreign Cell** membrane by closing an `adapter_kind` taxonomy drift seam:
  - Added `docs/30-architecture/fcell-adapter-kind-registry.md` (canonical closed adapter-kind set; binds each adapter to a CH-PLEDGE `portal.*` token, issued descriptor kinds, and lane kill switches).
  - Refactored CH-FCELL v0 seeds to point at the registry and removed the ambiguous `posix.clock_via_clock_handle` seed (time/entropy remain explicit resource handles via `resources.clocks` / `resources.entropy`, not adapter-mediated workflows in v0).
  - Updated CH-FADAPT v0 validation notes to require adapter kinds be members of the registry (fail closed).
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_fcell_adapter_registry.py` and wired it into `make lint`. It fails if CH-FCELL seed enums drift from the registry, CH-FADAPT stops referencing the registry, docs indexes omit the registry, or portal-token bindings lose their corresponding `cfg.params.lane.portal.*` kill switches.
- Assurance + evidence wiring:
  - Added invariant **I-FADAPT-3** and proof obligation **PO-FADAPT-KINDREG**.
  - Registered evidence seed **EVID-2026-146**.

## Revised132 (2026-02-28)
- Tightened the **schemas/receipts are the product surface** pillar by pinning a stable, digest-only outcome receipt for ACP decisions (prevents accept-path drift into ad-hoc strings):
  - Added **CH-ACPOUT v0**: `docs/30-architecture/acp-outcome-receipt-schema-v0.md` (non-authoritative; binds `action_digest` + kind; carries D-COMMUTE observability metadata and optionally references CH-DENY/CH-RECEIPT/other receipts by digest).
  - Wired CH-ACPOUT into ACP control points (`acp-action-schema-v0.md`, `acp-validator-semantics.md`) and D-COMMUTE guidance.
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_acp_outcome_wiring.py` and wired it into `make lint`. It fails if CH-ACPOUT is not registered in the schema registry, is not discoverable from docs indexes, or is not referenced from ACP + assurance control points.
- Assurance + evidence wiring:
  - Added invariant **I-ACPOUT-1** and proof obligation **PO-ACT-ACPOUT**.
  - Registered evidence seed **EVID-2026-145**.

## Revised131 (2026-02-28)
- New CI guardrail (LLM-amnesia resistor) to keep Hybrid + D-COMMUTE metadata stable and reviewable:
  - Added `tools/check_acp_kindmeta.py` and wired it into `make lint`. It treats `docs/70-llm-control/acp-action-kind-registry.md` as machine-checkable source-of-truth and fails if:
    - a kind row is missing an explicit conflict-key family,
    - a row references a non-existent CH-CONFLICTKEY family,
    - an ordered commutativity stance does not require a CH-ORDERTOK witness (or a non-ordered kind claims one),
    - the Profiles column drifts outside the closed A–D set, or
    - profile-gated kinds reference `cfg.params.lane.*` kill switches that are not present in the CH-CFG toggle registry.
- Wiring:
  - Documented the new guardrail in `tools/README.md` and linked it from the ACP kind registry.
  - Registered evidence seed **EVID-2026-144** for the new drift gate.

## Revised130 (2026-02-28)
- Tightened the **no ambient authority (esp. workflows)** pillar by making portal mediation **explicitly policy-killable** for *every* portal family (no partial/implicit enablement drift):
  - Expanded the CH-CFG lane gate surface to include a complete closed set of `cfg.params.lane.portal.*` kill switches (`portal.file`, `portal.uri`, `portal.print`, `portal.device`, `portal.location`, `portal.secret`, `portal.xfer`, `portal.jobs`, `portal.inhibit`), alongside the existing `portal.net`, `portal.capture`, `portal.background`, `portal.a11y`.
  - Updated **CH-EFFCON v0** lane-gate semantics: for any `portal.<family>` effect kind in `effects[*].kind`, runners MUST require `cfg.params.lane.portal.<family>` to be enabled; missing/unknown toggle values are treated as `false` (fail closed) and produce transcript-visible denials (PO-LANE-KILL).
  - Clarified **CH-FCELL v0** validation notes: any `interop.portals_allowed` entry also requires the corresponding portal lane kill switch to be enabled (missing toggles treated as disabled; fail closed).
- Strengthened the portal coherence drift gate (LLM-amnesia resistor):
  - `tools/check_portal_wiring.py` now enforces that the set of `cfg.params.lane.portal.*` kill switches is **complete** for the canonical `portal.*` token set (in addition to the existing cross-doc token coherence checks).
- Assurance + evidence wiring:
  - Added invariant **I-PORTAL-KILL-1** and updated **PO-LANE-KILL** to cover “missing toggle ⇒ disabled” and to reference the portal drift gate evidence.
  - Updated **EVID-2026-141** description to reflect the new completeness check.


## Revised129 (2026-02-28)
- Tightened the “no ambient authority (esp. workflows)” pillar by closing a schema-name drift seam in D-CAPSHELL:
  - Pinned a **workflow-bound descriptor allowlist** in **CH-EFFCON v0**: an explicit mapping from effect kinds → allowed `desc_schema` values for CH-ARGV/CH-ENV bindings (closed-world, effect-bound).
  - Updated **CH-ARGV v0** and **CH-ENV v0** to require `desc_schema` be justified by the bound CH-EFFCON `effects[*].kind` list (mismatches fail closed; recommended CH-DENY `effcon-violation`).
  - Updated ACP control points (kind registry + validator semantics) to make the rule deterministic and transcript-visible for `capshell.exec`.
- New CI-friendly drift gate (LLM-amnesia resistor):
  - Added `tools/check_workflow_descallow.py` and wired it into `make lint`. It treats CH-EFFCON as the source of truth and fails if:
    - any `portal.*` effect kind lacks a row in the mapping table,
    - any mapped `CH-* vN` token is missing from the schema registry,
    - or CH-ARGV/CH-ENV stop referencing the CH-EFFCON allowlist.
- Assurance + evidence wiring:
  - Added invariant **I-WDESC-1** and updated the CH-ARGV/CH-ENV validate/bind proof obligations to require effect-bound descriptor schema checking.
  - Registered evidence seed **EVID-2026-143** for the workflow descriptor allowlist drift gate.


## Revised128 (2026-02-28)
- Entropy-reducing coherence fix for Hybrid + D-COMMUTE (eliminates conflict-key derivation ambiguity at ACP seams):
  - Pinned **normative derivation commitments** in **CH-CONFLICTKEY v0** for the ACP-visible families `policy.param` and `domain.id` (no ambient param aliasing; avoid double-hashing digest-sized domain ids).
  - Updated the ACP kind registry to reference `ck_domain(..)` for `domain.id` keys and to spell `policy.param` payloads as exact `cfg.params.*` keys.
  - Removed a lingering `request_id`-based idempotency hint in `cfg.set_policy` metadata and aligned it with the already-pinned dedupe guidance (`CH-EFFCON contract_id` / explicit dedupe key).
- New CI-friendly drift gate (LLM-amnesia resistor):
  - `tools/lint_archive.py` now fails if CH-CONFLICTKEY loses the derivation commitments section for `policy.param` / `domain.id`, or if ACP kind metadata stops referencing the pinned derivation helper/shape.
- Assurance + evidence wiring:
  - Added invariant **I-CONFLICTKEY-2** and proof obligation **PO-CONFLICTKEY-DERIVE**; registered evidence seed **EVID-2026-142**.

## Revised127 (2026-02-27)
- Entropy-reducing refactor for sealed-compat denial vocabulary (prevents drift and improves LLM-resilience):
  - Clarified **CH-FADAPT v0** `result.reason` reuses the same **closed deny_code set** as CH-DENY (`docs/30-architecture/deny-code-registry.md`), eliminating a parallel uppercase reason-token set.
  - Updated assurance control points (invariants/POs/evidence) to require fail-closed validation of CH-FADAPT denial reasons against the deny-code registry.
- New CI-friendly drift gate:
  - `tools/lint_archive.py` now fails if CH-FADAPT denial reason tokens are non-canonical (not kebab-case) or not present in the deny-code registry, or if CH-FADAPT stops referencing the registry.

## Revised126 (2026-02-27)
- New drift guardrail (CI-friendly) to keep the **workflow/compat portal taxonomy closed and coherent** (LLM-amnesia resistor; sealed-compat honesty):
  - Added `tools/check_portal_wiring.py`, a tiny lint gate that treats `docs/30-architecture/portal-family-registry.md` as the canonical `portal.*` token set and fails if it drifts from:
    - CH-PLEDGE token list (`docs/30-architecture/pledge-contract-schema-v0.md`),
    - pledge token→effect mapping (`docs/30-architecture/pledge-token-mapping.md`),
    - Foreign Cell portal allowlist seeds (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`),
    - and any `cfg.params.lane.portal.*` lane-gate keys.
  - Updated `make lint` to run the new guardrail, and documented the tool in `tools/README.md`.
- Evidence wiring:
  - Registered **EVID-2026-141** for the portal taxonomy coherence drift gate (supports PO-PLEDGE-ENFORCE + sealed-compat POs).

## Revised125 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by preventing omission-based ambient context in D-CAPSHELL:
  - Added **CH-EXECPACK v0** (`docs/30-architecture/capshell-exec-pack-schema-v0.md`) as a bounded, **non-authoritative** capshell execution pack that bundles the complete workflow execution context digests (**CH-EFFCON v0**, **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**).
  - Wired `capshell.exec` to require `exec_pack_digest = digest(CH-EXECPACK v0)` (no ambient PATH/env/cwd/stdio/handle inheritance by omission; still profile-gated via `cfg.params.lane.capshell`).
  - Updated ACP kind registry, ACP validator semantics, and CLI plumbing guidance to treat the exec-pack digest as the stable workflow binding surface (schemas + validators + receipts).
- Entropy-reducing coherence fix:
  - Clarified `capshell.exec` retry safety guidance to use the bound CH-EFFCON `contract_id` (or another explicit dedupe key) for replay/duplicate suppression, rather than an undefined “request_id”.
- Assurance + evidence wiring:
  - Added invariant **I-EXECPACK-1** and proof obligations **PO-EXECPACK-VALIDATE** and **PO-CAPSHELL-EXECPACK-REQUIRE**; registered evidence seed **EVID-2026-140**.
  - Added deny-code **`execpack-missing`** (registry-backed) for deterministic `capshell.exec` omissions.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now fails if CH-EXECPACK exists but isn’t indexed (docs/README + schema registry) or if ACP surfaces regress and stop requiring `exec_pack_digest` / `execpack-missing`.

## Revised124 (2026-02-27)
- Entropy-reducing coherence fix for Hybrid + D-COMMUTE (prevents conflict-key naming drift):
  - Aligned ACP kind metadata conflict-key families with the canonical CH-CONFLICTKEY allowlist (e.g., `policy.param`, `domain.id`, `view.slot`, `budget.issuer`, `cell.id`).
  - Expanded **CH-CONFLICTKEY v0** to include the families actually referenced by the current ACP/compat seams (`policy.param`, `domain.id`, `cell.id`, `cell.adapter`) while preserving the closed-world, fail-closed validation rule.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now fails if any conflict-key `family="..."` referenced by the ACP kind registry, hot-action boundaries, or sealed-compat adapter receipts is missing from CH-CONFLICTKEY’s family allowlist (LLM-amnesia resistor).
- Evidence wiring:
  - Registered **EVID-2026-139** for the conflict-key family coherence drift gate.

## Revised123 (2026-02-27)
- Entropy-reducing workflow coherence fix (no ambient authority drift):
  - Updated `docs/60-engineering/cli-plumbing-tooling.md` to align its capshell integration guidance with the full D-CAPSHELL binding set: **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, and **CH-FDSET v0**.
  - Made the prohibition explicit: no ambient PATH resolution, no env/cwd/stdio inheritance, and no inherited handle/FD tables; all authority acquisition remains portalized and receipt/transcript-visible.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now fails if the CLI plumbing doc’s capshell integration section stops mentioning the binding schemas that exist in the repo, or if it regresses on the explicit “no ambient PATH + require CH-ARGV role=\"exec\"” rule.

## Revised122 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by eliminating inherited handle/FD-table seams in D-CAPSHELL:
  - Added **CH-FDSET v0** (`docs/30-architecture/fdset-schema-v0.md`) as a bounded, **non-authoritative** extra descriptor binding set (slots >= 3) so workflow runners never inherit an ambient parent handle/FD table.
  - Wired `capshell.exec` semantics to require `fdset_digest = digest(CH-FDSET v0)` alongside `effcon_digest`, `argv_digest`, `env_digest`, `cwd_digest`, and `stdio_digest`.
  - Updated CH-STDIO/CH-ARGV docs to point to CH-FDSET as the explicit seam for extra handles beyond stdio.
- Assurance + evidence wiring:
  - Added invariants **I-FDSET-1** (fdset is non-authoritative) and **I-FDSET-2** (no ambient handle inheritance; fail closed and transcript-visible).
  - Added proof obligations **PO-FDSET-VALIDATE** and **PO-CAPSHELL-FDSET-BIND**; registered evidence seed **EVID-2026-138**.
  - Added deny-code **`fd-bind-failed`** (registry-backed) for deterministic fdset binding failures and ambient-extra-handle detection.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-FDSET wiring remains visible in ACP semantics/kind registry and that `fd-bind-failed` stays registry-backed.
  - `tools/check_discovery.py` now enforces CH-FDSET remains indexed from `docs/README.md` when present.



## Revised121 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by eliminating ambient executable resolution in D-CAPSHELL:
  - Updated **CH-ARGV v0** (`docs/30-architecture/argv-schema-v0.md`) to pin an explicit executable-binding rule: `capshell.exec` selects the executable **only** via a `desc` token with `role="exec"` (no ambient PATH resolution from `lit` tokens).
  - Updated ACP validator semantics (`docs/70-llm-control/acp-validator-semantics.md`) and kind registry (`docs/70-llm-control/acp-action-kind-registry.md`) to require and surface the rule.
- Assurance + evidence wiring:
  - Added invariant **I-ARGV-3** (no ambient executable resolution) and updated **PO-CAPSHELL-ARGV-BIND** to include the exec-binding requirement.
  - Updated evidence seed **EVID-2026-134** to include missing/ambiguous `role="exec"` negative cases.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now fails if CH-ARGV / ACP semantics regress and stop pinning “no ambient PATH” + `role="exec"` executable selection.

## Revised120 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by eliminating inherited stdio/TTY seams in D-CAPSHELL:
  - Added **CH-STDIO v0** (`docs/30-architecture/stdio-schema-v0.md`) as a bounded, **non-authoritative** stdio binding descriptor for `stdin/stdout/stderr` (explicit `null/drop` or docref digest bindings).
  - Wired `capshell.exec` semantics to require `stdio_digest = digest(CH-STDIO v0)` alongside `effcon_digest`, `argv_digest`, `env_digest`, and `cwd_digest`, so workflow runners never inherit ambient host stdio/TTY state.
- Entropy-reducing refactor:
  - Removed `stdin/stdout/stderr` roles from **CH-ARGV v0**; stdio binding is now exclusively modeled via **CH-STDIO v0** (prevents parallel, drifting stdio semantics).
- Assurance + evidence wiring:
  - Added invariants **I-STDIO-1** (stdio bindings are non-authoritative) and **I-STDIO-2** (no ambient stdio/TTY inheritance; unbindable bindings fail closed).
  - Added proof obligations **PO-STDIO-VALIDATE** and **PO-CAPSHELL-STDIO-BIND**; registered evidence seed **EVID-2026-137**.
  - Added deny-code **`stdio-bind-failed`** (registry-backed) for deterministic stdio binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-STDIO wiring remains visible in ACP semantics/kind registry and that `stdio-bind-failed` stays registry-backed.
  - `tools/check_discovery.py` now enforces CH-STDIO remains indexed from `docs/README.md` when present.

## Revised119 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by making child current working directory selection explicit and bindable in D-CAPSHELL:
  - Added **CH-CWD v0** (`docs/30-architecture/cwd-schema-v0.md`) as a bounded, **non-authoritative** working-directory selector (`empty` sandbox cwd or directory descriptor reference).
  - Wired `capshell.exec` semantics to require `cwd_digest = digest(CH-CWD v0)` alongside `effcon_digest`, `argv_digest`, and `env_digest`, so workflow runners never inherit ambient host cwd.
- Assurance + evidence wiring:
  - Added invariants **I-CWD-1** (cwd selector is non-authoritative) and **I-CWD-2** (no ambient cwd inheritance; empty cwd must not permit ambient traversal).
  - Added proof obligations **PO-CWD-VALIDATE** and **PO-CAPSHELL-CWD-BIND**; registered evidence seed **EVID-2026-136**.
  - Added deny-code **`cwd-bind-failed`** (registry-backed) for deterministic cwd binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-CWD wiring remains visible in ACP semantics/kind registry and that `cwd-bind-failed` stays registry-backed.
  - `tools/check_discovery.py` now enforces CH-CWD remains indexed from `docs/README.md` when present.

## Revised118 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by making process environments explicit and bindable in D-CAPSHELL (no forks):
  - Added **CH-ENV v0** (`docs/30-architecture/env-schema-v0.md`) as a bounded, **non-authoritative** typed environment token list.
  - Wired `capshell.exec` semantics to require `env_digest = digest(CH-ENV v0)` alongside `effcon_digest` and `argv_digest`, so workflow runners can avoid inheriting ambient host environments and keep env binding receipt-shaped.
- Assurance + evidence wiring:
  - Added invariants **I-ENV-1** (env is non-authoritative) and **I-ENV-2** (no ambient acquisition via env binding).
  - Added proof obligations **PO-ENV-VALIDATE** and **PO-CAPSHELL-ENV-BIND**; registered evidence seed **EVID-2026-135**.
  - Added deny-code **`env-bind-failed`** (registry-backed) for deterministic env binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-ENV wiring stays visible in ACP semantics/kind registry and that `env-bind-failed` remains registry-backed.
  - `tools/check_discovery.py` now enforces CH-ENV remains indexed from `docs/README.md` when present.


## Revised117 (2026-02-27)
- Integrated a new workflow seam to reduce ambient authority in automation inputs (D-CAPSHELL) without forks:
  - Added **CH-ARGV v0** (`docs/30-architecture/argv-schema-v0.md`) as a bounded, **non-authoritative** typed argv token list that binds to already-held descriptor digests (no raw caps; no path/env as “permission grants”).
  - Wired `capshell.exec` to require `argv_digest = digest(CH-ARGV v0)` alongside `effcon_digest` so workflow execution remains schema/receipt-shaped and fail-closed.
- Assurance + evidence wiring:
  - Added invariants **I-ARGV-1** (argv is non-authoritative) and **I-ARGV-2** (no ambient acquisition via argv binding).
  - Added proof obligations **PO-ARGV-VALIDATE** and **PO-CAPSHELL-ARGV-BIND**; registered evidence seed **EVID-2026-134**.
  - Added deny-code **`argv-bind-failed`** (closed-world via deny-code registry) for deterministic binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-ARGV wiring stays visible in ACP semantics/kind registry and that `argv-bind-failed` remains registry-backed.
  - `tools/check_discovery.py` now enforces CH-ARGV remains indexed from `docs/README.md` when present.

## Revised116 (2026-02-27)
- Refactor + coherence fix (pillar: multicore verification required; no single-core shipping):
  - Removed “multicore later / Phase 3” drift from core policy docs by aligning **mechanisms**, **unsafe-concurrency policy**, and **unsafe obligation notes** with D-CONC staged options (UP-only bring-up allowed; SMP big-lock baseline is the early verified posture).
  - Updated D-MEMMODEL to be an **SMP/Hybrid baseline** decision (no conditional “if SMP” phrasing), and tightened related phrasing in the abstract machine and threat-model abuse case AC-004.
- Assurance + evidence wiring:
  - Added **I-CONC-0** (multicore required for flagship; UP-only is non-claim) and **PO-CONC-MULTICORE** (C-CONC-1 evidence requires >=2-core execution); registered evidence seed **EVID-2026-133**.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now includes a **multicore posture** lint that fails if canonical policy docs regress to “single-core default” or “multicore later” language, or if D-MEMMODEL becomes conditional again.
## Revised115 (2026-02-27)
- Reduced drift in fail-closed workflow/policy denials by centralizing denial semantics:
  - Added `docs/30-architecture/deny-code-registry.md` as the source of truth for the closed CH-DENY `deny_code` set (with recommended `reason.kind` bindings and required keys/digests).
  - Updated **CH-DENY v0** (`docs/30-architecture/denial-receipt-schema-v0.md`) to treat the registry as normative (validators reject unknown codes).
  - Updated ACP validator semantics to include an explicit “Deny codes used by ACP validators” list (subset of the registry) and to avoid nested inline-code drift.
- Wiring + assurance:
  - Added **I-DENY-3** (deny semantics centralized) and **PO-DENY-CODES**; registered evidence seed **EVID-2026-132**.
  - Updated D-EXPLAIN decision node to call out the deny-code registry as the closed-world source.
- New drift guardrails (CI-friendly):
  - `make lint` now validates deny-code registry completeness and that ACP semantics lists only registry-backed deny codes.
  - `tools/check_discovery.py` now enforces `deny-code-registry.md` remains indexed (and referenced from CH-DENY) when present.

## Revised114 (2026-02-27)
- Tightened D-RR replay/audit packaging so **fail-closed denials remain mechanically auditable** (and don't drift into ad-hoc strings in incident handoff):
  - Updated **CH-RRBUNDLE v0** (`docs/30-architecture/replay-bundle-schema-v0.md`) to add an optional `deny_stream` payload kind carrying CH-DENY records referenced by bundled CH-LOG entries via `deny_digest`.
  - Updated D-RR notes in the decision map to call out denial-receipt closure as an audit stability requirement (no silent gaps).
- Assurance + evidence wiring:
  - Added **I-RR-4** (bundle closure for denials) and **PO-RR-BUNDLE-CLOSURE**; registered evidence seed **EVID-2026-131**.
- New drift guardrail (CI-friendly): `make lint` now fails if CH-DENY exists but the replay-bundle schema doesn't mention the `deny_stream` closure seam.

## Revised113 (2026-02-27)
- Integrated a **structured denial receipt** seam so fail-closed rejections are mechanically auditable (and don’t drift into ad-hoc strings):
  - Added **CH-DENY v0** (`docs/30-architecture/denial-receipt-schema-v0.md`) as a bounded, **non-authoritative** validator-denial record with a closed `deny_code` enum.
  - Updated **CH-LOG v0** (`docs/30-architecture/transcript-contract.md`) to optionally bind `deny_digest = digest(CH-DENY v0)` for rejected actions.
  - Updated ACP validator semantics to emit CH-DENY for `Reject(..)` outcomes (especially lane/policy/effect-contract/ordering denials) and bind it from CH-LOG when present.
- Assurance + evidence wiring:
  - Updated **I-LOG-1** to cover rejected actions and CH-DENY binding.
  - Added invariants **I-DENY-1** (deny receipts are deterministic + non-authoritative) and **I-DENY-2** (lane/policy kills are receipt-visible).
  - Added proof obligation **PO-DENY-EMIT** and registered evidence seed **EVID-2026-130**.
- Sealed compat wiring tightened (no new ambient channels): Foreign Cell contract now explicitly calls for CH-DENY on lane-disabled and adapter-level rejects, keeping “killable by policy” auditable.
- New drift guardrails (CI-friendly):
  - `make lint` now requires CH-LOG to mention `deny_digest` when CH-DENY exists and sanity-checks the CH-DENY deny-code enum seed.
  - `tools/check_discovery.py` now enforces CH-DENY is indexed from `docs/README.md` when present.

## Revised112 (2026-02-27)
- Strengthened sealed POSIX/legacy compatibility so “interop only via portals/intents/receipts” is mechanically auditable (no ambient channels):
  - Added **CH-FADAPT v0** (`docs/30-architecture/fcell-adapter-receipt-schema-v0.md`) as a bounded, **non-authoritative** per-adapter receipt record that binds `portal_token` + issued descriptor digests (no bearer caps; no paths/env/implicit network).
  - Updated the Foreign Cell membrane contract and CH-FCELL manifest obligations to require per-op CH-FADAPT receipts for any adapter-mediated host effect (ALLOW/DENY), keeping the lane policy-killable and receipt-visible.
- Assurance + evidence wiring:
  - Added invariants **I-FADAPT-1** (non-authoritative + closed tokens) and **I-FADAPT-2** (interop is receipted; lane-kill yields deterministic DENY-only).
  - Added proof obligations **PO-FADAPT-VALIDATE** and **PO-FADAPT-EMIT**; registered evidence seed **EVID-2026-129**.
- New drift guardrail (CI-friendly): `tools/check_discovery.py` now enforces that CH-FADAPT stays indexed from `docs/README.md` and referenced from the Foreign Cell contract when present.

## Revised111 (2026-02-27)
- Entropy-reducing refactor: unified Foreign Cell (sealed compat) portal allowlists with the same **closed** `portal.*` token vocabulary used across portals and workflows:
  - Updated CH-FCELL v0 (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`) so `interop.portals_allowed` is expressed in CH-PLEDGE `portal.*` tokens (mirrors `portal-family-registry.md`) rather than a parallel `portal_kind` taxonomy.
  - Rationale: sealed compat must not grow a drifting portal taxonomy; interop lanes stay reviewable and killable without introducing ambient channels.
- Assurance wiring tightened:
  - Updated **I-FCELL-1** to require portal lanes be validated against the closed CH-PLEDGE `portal.*` set.
  - Updated **PO-FCELL-VALIDATE** to include portal-token closure validation.
- New drift guardrail (CI-friendly):
  - `make lint` now rejects the deprecated CH-FCELL `portal_kind` taxonomy and checks any `portal.*` tokens referenced by CH-FCELL are valid CH-PLEDGE portal tokens.
  - Registered evidence seed **EVID-2026-128** for this sealed-compat drift gate.

## Revised110 (2026-02-27)
- Integrated a drift-resistant **config toggle closure** seam to keep kill switches and profile extensions explicit and reviewable:
  - Added `docs/30-architecture/config-toggle-registry.md` as the canonical registry for the closed set of CH-CFG `feature_flags` values and `cfg.params.lane.*` kill switches.
  - Tightened CH-CFG docs to require enforcement of toggle closure (unknown toggle names reject) and wired the same closure into profile and automation surfaces.
- Strengthened “policy-killable lanes” across workflow glue and sealed compat:
  - `capshell.exec`, `budget.mint`, and `fcell.*` kinds now explicitly reference the required lane gates (`cfg.params.lane.capshell`, `cfg.params.lane.metering`, `cfg.params.lane.fcell`).
  - CH-EFFCON now pins lane gates for profile-gated portal effects (`cfg.params.lane.portal.{net,capture,background,a11y}`), preserving no-ambient-authority workflows and fail-closed semantics.
- Assurance + evidence wiring:
  - New invariants **I-CFGTOGGLE-1** (toggle closure) and **I-LANEGATE-1** (lane gates are fail-closed + receipt-visible).
  - New proof obligations **PO-CFGTOGGLE-VERIFY** and **PO-LANE-KILL**; added evidence seed **EVID-2026-127**.
- New drift guardrails (CI-friendly):
  - `make lint` now checks that any `ext.*` feature flags and `cfg.params.*` lane-gate references in key docs are present in the toggle registry.
  - `tools/check_discovery.py` now enforces the toggle registry is indexed from `docs/README.md` when present.
- Wiring: updated `docs/README.md`, D-CAPSHELL and D-FCELL notes, and deployment profile documentation to use the registry as the canonical closure surface.

## Revised109 (2026-02-27)
- Integrated a high-leverage workflow seam to reduce ambient authority in “glue” automation (shell/CI/runbooks) without forks:
  - Added **CH-EFFCON v0** (`docs/30-architecture/effect-contract-schema-v0.md`) as a *veto-only* **effect contract** descriptor bound to a CH-WALLET core digest (no bearer secrets; no ambient paths/env as “permissions”).
  - Added optional runner surface **IF-CAPSHELL** and a corresponding CH-ACP action kind **`capshell.exec`** (ordered within a `domain_id`, commutative across disjoint domains) so **LLMs propose; deterministic validators execute**, and receipts/transcripts remain the stable product surface.
- Assurance + evidence wiring:
  - New invariants **I-EFFCON-1** (non-authoritative) and **I-EFFCON-2** (no bypass at effect boundaries).
  - New proof obligations **PO-EFFCON-VALIDATE** and **PO-CAPSHELL-ENF**; new evidence seed **EVID-2026-126** (contract enforcement + swap-order tests for disjoint domains).
- New drift guardrail: `tools/check_discovery.py` now enforces that CH-EFFCON stays indexed from `docs/README.md` when present (keeps workflow authority seams visible and reviewable).
- Wiring: registered CH-EFFCON in the schema registry, added IF-CAPSHELL to the interface registry, updated D-CAPSHELL notes, and updated ACP docs to reference effect-contract binding.

## Revised108 (2026-02-27)
- Integrated Hybrid + commutativity observability into the stable product surface (schemas + validators + receipts):
  - Extended **CH-LOG v0** (transcript contract) to optionally carry `conflict_key_digest = digest(CH-CONFLICTKEY v0)` and (for ordered actions) `order_digest = digest(CH-ORDERTOK v0)` as **non-authoritative** metadata.
  - Extended **CH-RECEIPT v0** (consent receipt) to optionally carry the same digests, with normative producer rules for CH-ACP actions (ordered kinds must emit `order_digest`; derived `conflict_key_digest` preferred).
  - Rationale: keeps D-COMMUTE honest by making conflict keys + ordering witnesses receipt-visible without relying on implicit log ordering or ambient state.
- Assurance wiring tightened:
  - Updated **I-LOG-1** and **I-EXPLAIN-2** to reflect conflict/order digest recording as non-authoritative observability when D-COMMUTE is in scope.
  - Added evidence seed **EVID-2026-125** for CH-LOG/CH-RECEIPT action-metadata field emission + redaction-safe export tests.
- New drift guardrail: `make lint` now fails if the CH-LOG and CH-RECEIPT schema docs omit the `conflict_key_digest` / `order_digest` field mentions (prevents silent regression of commutativity evidence surfaces).
- Wiring: updated schema-registry notes for CH-LOG/CH-RECEIPT and clarified ACP validator semantics to reference the log/receipt fields.

## Revised107 (2026-02-27)
- Integrated LLM-first + Hybrid/commutativity surface: added `docs/70-llm-control/acp-action-kind-registry.md` as the **closed-world** registry for CH-ACP kinds, pinning per-kind conflict key derivation, commutativity/ordering stance, retry safety, and profile gates (keeps A–D viable without forks).
  - Added two profiled, policy-killable Foreign Cell control kinds (`fcell.launch` / `fcell.kill`) so sealed compatibility is explicitly surfaced as schemas + validators + receipts rather than ad-hoc tooling.
- Assurance wiring for commutativity discipline at the validator boundary:
  - New invariant **I-ACTMETA-1** (action kind metadata is closed and enforced).
  - New proof obligation **PO-ACT-KINDMETA** (validator computes/records conflict keys; ordered kinds require CH-ORDERTOK + matching CH-CONFLICTKEY digests).
  - New evidence seed **EVID-2026-124** for a kind-metadata gate + negative tests.
- New drift guardrails (CI-friendly):
  - `make lint` now fails if the ACP kind registry is missing/malformed or if an **ordered** kind claims `none` for its ordering witness.
  - `tools/check_discovery.py` now enforces that the ACP kind registry is indexed from both `docs/README.md` and `docs/70-llm-control/README.md`.
- Research/refs: added **REF-KNOSSOS-JEPSEN** (linearizability checker) as a candidate tool for validating ordered serialization boundaries.
- Refactor: fixed numbering/order in `docs/00-meta/trajectory-map.md` non-negotiables list (keeps drift-control docs crisp).

## Revised106 (2026-02-27)
- LLM continuity: extended `tools/gen_context_pack.py` to include a compact **non-negotiables** reminder + **profile matrix** (shared substrate + the four product shapes), derived from `docs/00-meta/llm-runbook.md` and `docs/00-meta/trajectory-map.md`.
  - Goal: keep “no forks; profiles/compositions only” salient in continuation prompts and reduce drift-by-omission.
- New discovery guardrail: `tools/check_discovery.py` now fails if the trajectory map loses any of the four required profile headings (workstation, cloud substrate, embedded/separation, agent/automation).

## Revised105 (2026-02-27)
- Made conflict keys a first-class, schema’d artifact for Hybrid + commutativity:
  - Added CH-CONFLICTKEY v0 (`docs/30-architecture/conflict-key-schema-v0.md`) and registered it in the schema registry.
  - Tightened CH-ORDERTOK scope binding: `scope.key_digest = digest(CH-CONFLICTKEY v0)` (explicit scope-to-conflict-key linkage).
- Hardened ordered-action and commutativity wiring:
  - Updated CH-ACP v0 to require `meta.conflict_key_digest = digest(CH-CONFLICTKEY v0)` for ordered actions (alongside `meta.order_digest`).
  - Updated CH-KABI v0 metadata guidance to optionally carry `meta.conflict_key_digest` for observability and commutativity evidence.
  - Updated RFC-0119 to reflect conflict-key binding and ordered-action requirements.
- New drift guardrail: `make lint` now enforces that each pinned hot family in `hot-action-boundaries-v0.md` includes explicit `Conflict key:` and `Ordering token:` statements (in addition to non-commutative boundary + replication contract).
- Assurance wiring: added I-CONFLICTKEY-1, PO-CONFLICTKEY-VALIDATE, and evidence seed EVID-2026-123.

## Revised104 (2026-02-27)
- Made required ordering a first-class, schema’d artifact (Hybrid + commutativity hardening):
  - Added CH-ORDERTOK v0 (`docs/30-architecture/ordering-token-schema-v0.md`) as a non-authoritative ordering witness descriptor for non-commutative actions.
  - Added RFC-0119 (`rfcs/0119-ordering-streams-and-tokens.md`) to pin how ordered actions carry `order_digest` and how receipts make order visible.
- Tightened the pinned hot action boundary doc to always state `Ordering token:` (CH-ORDERTOK v0 or `none`) per hot family (prevents hidden global serialization).
- Assurance wiring: added invariants I-ORDERTOK-1..2 and proof obligation PO-ORDERTOK-VALIDATE; added EVID-2026-122 stub.
- New drift guardrail: `make lint` now fails if any pinned hot family section is missing an explicit `Ordering token:` statement.

## Revised103 (2026-02-27)
- New drift guardrail: `make lint` now checks that inline backticked repo paths (e.g., `docs/...`, `tools/...`) actually exist (prevents stale references from silently accumulating).
- Refactor: fixed RFC→ADR promotion rubric to link to the canonical [TCB inventory](docs/20-assurance/tcb.md) and [release profiles](docs/60-engineering/release-profiles.md) documents.
- Changelog hygiene: removed a backticked reference to a previously-deleted `__pycache__` directory so future path checks don’t false-alarm.

## Revised102 (2026-02-27)
- Pinned “sealed compatibility” as a first-class architecture seam (so POSIX/legacy support cannot reintroduce ambient authority):
  - Added `docs/30-architecture/foreign-cell-contract.md` defining the Foreign Cell membrane (portalized, fail-closed, policy-killable).
  - Added CH-FCELL v0 (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`) as a bounded, non-authoritative manifest used for validation/receipts/drift-gates.
  - Added D-FCELL to the decision map (membrane contract) and clarified D-RUMPK as the runtime selection *inside* the cell.
- Assurance wiring: added invariant I-FCELL-1 and proof obligation PO-FCELL-VALIDATE.
- Wiring: added the Foreign Cell contract doc to the runbook must-read set and the docs index; registered CH-FCELL in the schema registry.

## Revised101 (2026-02-27)
- Tightened the Hybrid + commutativity integration by making cross-cluster replication assumptions explicit on the pinned hot action surface:
  - Updated `docs/30-architecture/hot-action-surface-v0.md` to record a default RC* replication class per hot family.
  - Updated `docs/30-architecture/hot-action-boundaries-v0.md` to require and document `Replication contract:` statements alongside non-commutative boundaries.
- New drift guardrail: `make lint` now fails if any pinned hot family is missing an explicit replication contract statement (prevents accidental “global state” drift in Hybrid).

## Revised100 (2026-02-27)
- Pinned cross-cluster replication/consistency contracts as an explicit Hybrid artifact seam:
  - Added `docs/30-architecture/replication-contracts-v0.md` (RC0..RC4 vocabulary) and CH-REPLCONTRACT v0 (`docs/30-architecture/replication-contract-schema-v0.md`).
  - Added ADR-0006 and D-REPL in the decision map; registered CH-REPLCONTRACT in the schema registry.
- Tightened assurance wiring for Hybrid cross-cluster metadata:
  - New invariant I-REPL-1 (replication is non-authoritative; no authority amplification from replicated metadata).
  - New proof obligations: PO-REPLCONTRACT-VALIDATE, PO-REPL-NOAMP, PO-REPL-MERGE, PO-REPL-ORDERED; added EVID-2026-121 stub.
- Threat model: added AC-092 (cross-cluster metadata divergence/split-brain) and linked mitigations to D-REPL + RC4 ordered-log semantics where needed.
- Wiring: updated multicore/commutativity docs, cluster-derivation follow-ups, docs index, and bibliography (added REF-CRDT-INRIA11).

## Revised99 (2026-02-27)
- Pinned Hybrid cluster derivation as a deterministic, auditable artifact surface:
  - Added `docs/30-architecture/cluster-derivation.md` and CH-CLUSTERMAP v0 (`docs/30-architecture/cluster-map-schema-v0.md`) for stable cluster partitions derived from CH-HWFACT (+ optional policy digest).
  - Updated ADR-0005 and multicore docs to treat cluster derivation as “done v0” and to focus remaining Hybrid follow-ups on cross-cluster replication/consistency contracts.
- Tightened the CH-HWFACT v0 `cpu_topology` payload with explicit bounded fields and canonicalization rules (supports D-MK/D-SKB).
- New drift guardrail: `make lint` now fails if any `*-schema-vN.md` doc is not registered in `docs/30-architecture/schema-registry.md`.

## Revised98 (2026-02-27)
- Added a conservative discovery-surface guardrail:
  - New tool `tools/check_discovery.py` ensures ADR/RFC indexes are complete and that the runbook must-read set stays discoverable from `docs/README.md`.
  - `make lint` now runs both the core archive lints and the discovery-surface checks (fails fast on drift).
- Updated runbook and docs wiring to reflect the new lint composition.

## Revised97 (2026-02-27)
- Committed the multicore direction as an explicit, permanent decision:
  - Added ADR-0005 adopting **Hybrid** multicore as the default direction and making **D-COMMUTE** a required spec/test discipline.
  - Updated D-MK and D-COMMUTE entries to reflect adopted status (and to keep SMP variants explicitly scoped to in-cluster profiles).
- Entropy-reducing refactor: removed duplicated commutativity sections and clarified the "current direction" in `docs/30-architecture/multicore-architecture-options.md`.
- Updated drift-resistant wiring: trajectory-map open questions now track Hybrid follow-ups (cluster derivation + replication contracts) instead of re-litigating the baseline.

## Revised96 (2026-02-27)
- Added LLM continuity guardrails to reduce archive amnesia:
  - Added `docs/00-meta/llm-runbook.md` (must-read set, non-negotiables, per-run outputs).
  - Added `tools/gen_context_pack.py` and `make context-pack` to generate `out/context_pack.md` for copy/paste-friendly continuation prompts.
- Updated discovery/wiring: `README.md`, `docs/README.md`, and `docs/00-meta/archive-policy.md`; added `out/` to `.gitignore`.

## Revised95 (2026-02-27)
- Refined the hot action surface into explicit **non-commutative sub-action boundaries** (so Hybrid + D-COMMUTE stays enforceable, not vibes):
  - Added `docs/30-architecture/hot-action-boundaries-v0.md` naming the minimal correctness-required serialization boundary (or explicit `none`) for each v0 hot family.
  - Updated `docs/30-architecture/hot-action-surface-v0.md` and D-COMMUTE doc wiring to require a boundary statement per hot family.
- Threaded boundary intent into the action IR docs:
  - Updated `docs/30-architecture/kabi-action-schema-v0.md` to make the IPC endpoint family explicit and to mark budget issuance as a profile-gated, ordered family.
  - Updated `docs/70-llm-control/acp-action-schema-v0.md` to include view attach/detach and budget mint as first-class proposed actions, and to require explicit ordering tokens for ordered actions.
- New drift guardrail:
  - Extended `tools/lint_archive.py` so `make lint` fails if the hot boundaries doc is missing or if a pinned hot family lacks an explicit boundary statement.

## Revised94 (2026-02-27)
- Made commutativity discipline concrete by pinning a **hot privileged action surface** and explicitly marking serialization points:
  - Added `docs/30-architecture/hot-action-surface-v0.md` (v0 seed set: mem.map/unmap, IPC endpoint ops, view attach/detach, transcript append, quota charge) with conflict keys, commutativity stance, and explicit serialization owners.
  - Added proof obligations for the hot surface and its declared serialization points: PO-HOT-MEMRANGE, PO-HOT-IPCORDER, PO-HOT-VIEWSLOT, PO-HOT-LOGCOMMUTE, PO-HOT-QUOTATOK.
  - Added evidence seed `EVID-2026-120` for a microbench + regression harness that measures/guards the declared serialization points.
- Tightened transcript semantics to avoid accidental global bottlenecks:
  - Clarified in `docs/30-architecture/transcript-contract.md` that transcript ingestion is a content-addressed event set; export order is derived canonically (append commutes).
- Wiring updates:
  - Updated D-COMMUTE references and MVP proof-slice wiring to point to the pinned hot surface v0 and the new evidence seed.

## Revised93 (2026-02-27)
- Added interface-first scalability as an explicit, testable discipline that composes with Hybrid multicore:
  - Added `docs/30-architecture/commutativity-and-interface-scalability.md` (D-COMMUTE) framing commutativity as a spec property and evidence target (REF-SCR-TOCS15).
  - Extended `docs/30-architecture/multicore-architecture-options.md` with an orthogonal commutativity lever section.
  - Updated `docs/30-architecture/decision-map.md` with D-COMMUTE and concrete PO hooks (PO-COMMUTE-SPEC, PO-COMMUTE-TEST).
  - Added `REF-SCR-TOCS15` to `docs/00-meta/bibliography.md` and wired evidence seed `EVID-2026-119`.

## Revised92 (2026-02-27)
- Wrote down a mile-high synthesis to prevent design drift:
  - Added `docs/00-meta/trajectory-map.md` capturing the four intended profile stacks (workstation, cloud substrate, embedded/separation, agent/automation) and the current non-negotiables (sealed compat; multicore verification; LLM-first workflows).
- Clarified the multicore option space and wired it into the decision surfaces:
  - Added `docs/30-architecture/multicore-architecture-options.md` (SMP big-lock vs sharded SMP vs multikernel vs hybrids; plus commutativity as an interface tool).
  - Updated the decision map’s D-CONC and D-MK entries to reflect the expanded option set and link to the new doc.
- Updated the verification plan to treat multicore as part of the MVP slice:
  - Refactored `docs/40-verification/minimum-viable-proof-slice.md` so the baseline includes an SMP profile (big-lock as a practical early anchor) rather than UP-only as the intended end state.
- Inspirations + refs:
  - Added compressed lessons and bibliography entries for Corey/Tornado/K42 and the scalable commutativity rule to ground multicore design choices in concrete precedents.

## Revised91 (2026-02-27)
- Added an “in-process confused deputy” guardrail seam (cheap now, painful later):
  - Added **RFC-0118** introducing **D-BRACKET**: privilege bracketing in user-space runtimes (borrowed-mode default; explicit scoped privileged blocks; veto-only).
  - Added **CH-CALLCHAIN v0** schema (bounded call-chain descriptor for audit + deny-only routing).
  - Added **CH-REQCTX v1** schema (optional call-chain digest hook) and updated D-REQCTX to recognize v0/v1.
  - Registered CH-CALLCHAIN and CH-REQCTX v1 in the schema registry and added **D-BRACKET** to the decision map.
- Threat model + assurance wiring:
  - Added abuse case **AC-091** (in-process confused deputy).
  - Added invariants **I-BRACKET-1..3** and **I-CALLCHAIN-1**; refined **I-REQCTX-3** to clarify contexts are non-authoritative for granting but may be used for veto-only narrowing/deny decisions; added **I-REQCTX-4**.
  - Added proof obligations **PO-CALLCHAIN-VALIDATE** and **PO-BRACKET-SCOPE**, and evidence seed **EVID-2026-118**.
- Meta-engineering + research threading:
  - Extended the sealing/learning playbook with an explicit D-BRACKET section.
  - Added a new bake-in item to RFC-0003 for veto-only privilege bracketing in plugin/helper ecosystems.
  - Added an OS lesson tying Confused Deputy + Java stack inspection to our D-BRACKET seam and expanded bibliography with the primary references.

## Revised90 (2026-02-27)
- Strengthened the workflow plumbing seam so CLI and GUI share a pinned, auditable substrate:
  - Added **RFC-0117** introducing **CH-PLUMBMSG v0**: a canonical, **non-authoritative** plumb message envelope for workflow intents (no raw capabilities).
  - Added **CH-PLUMBMSG v0** schema doc and registered it in the schema registry.
  - Refactored **RFC-0046** to explicitly use CH-PLUMBMSG and to document “plumb-first” CLI integration (no ambient paths; wallet-aware).
- Meta-engineering + safety rails:
  - Added **I-PLUMB-3** (plumb envelopes carry no raw capabilities; authority transfer is portalized and transcript-visible).
  - Added **PO-PLUMBMSG-VALIDATE** (total, bounded, closed-enum decoding for CH-PLUMBMSG).
  - Added **AC-090** (plumb injection/confused deputy) to keep the threat model honest.
- Added an engineering guide: `docs/60-engineering/cli-plumbing-tooling.md` (how to build safe `open/share/print` CLI verbs without reintroducing ambient authority).


## Revised89 (2026-02-27)
- Meta-engineering: made wallets usable as **stable drift-gate identifiers**:
  - Added decision node **D-WALLET** to track the wallet seam explicitly.
  - Tightened **CH-WALLET v0** with a normative `wallet_core_digest` normalization algorithm (drop volatile fields; deterministic sorting) so prompts/receipts/CI can key off a stable authority digest.
  - Added invariant **I-WALLET-3** and updated **PO-WALLET-VALIDATE** to cover the normalization requirement when used for gating.
  - Updated **RFC-0115** and **RFC-0116** to prefer `wallet_core_digest` over `digest(CH-WALLET)` for prompts and drift gates.
- Research/lessons: strengthened the **GNU Hurd translators** lesson and tied it to view-mutation semantics; added **REF-HURD-SETTRANS** and threaded it into RFC-0032 (views/namespaces) as an explicit precedent for attach/remove operations.
- Added an engineering playbook: `docs/60-engineering/authority-drift-gates.md` (how to turn authority widening into a deterministic CI failure).



## Revised88 (2026-02-27)
- Tightened the ecosystem adoption seam for least-privilege automation:
  - Added **RFC-0116** and **CH-WALLET v0**: a **non-authoritative capability wallet descriptor** for prompts, receipts, runbooks, and CI drift gates (no bearer secrets).
  - Wired discipline: new invariants **I-WALLET-1/I-WALLET-2**, new proof obligation **PO-WALLET-VALIDATE**, and schema registry entry for CH-WALLET.
  - Updated **RFC-0115** (D-CAPSHELL) to reference CH-WALLET and to position wallets as metadata + drift-gated contracts.
- Portal meta-engineering:
  - Refactored the **portal design playbook** to treat portals as **usage-control boundaries** (UCON lens) and to reference **CH-CAPDIFF + CH-RECEIPT** explicitly (fixing a placeholder CH-*).
  - Reinforced **view objects** as a name-binding protection boundary (Bisbey/Hollingworth lesson).
- Inspirations/research:
  - Added a compressed lesson on **sandboxing adoption reality** (mechanisms exist but adoption is low) and tied it to wrapper-first + learn-mode workflows.
- Bibliography additions: **REF-SANDBOX-ADOPTION-ARXIV24**, **REF-LEASH-CAPSICUM-2025**, **REF-UCON-ABC/REF-UCON-ABC-ACM**, **REF-BISBEY78**.

## Revised87 (2026-02-27)
- Added an ecosystem seam for keeping “glue code” capability-pure:
  - Added **RFC-0115** introducing **D-CAPSHELL**: capability-safe shell + automation components (wrapper-first + learn mode + explicit contracts).
  - Added **portal design playbook** (`docs/60-engineering/portal-design-playbook.md`) as an engineering checklist for portals as non-amplifying mediators.
  - Decision map updated to include D-CAPSHELL as an explicit node.



## Revised86 (2026-02-27)
- Added an ecosystem integrity seam for immutable artifacts:
  - Added **RFC-0114** introducing **D-VERITY**: optional **VerifiedBlob** handles backed by Merkle-tree verified reads (fs-verity/dm-verity lineage), with fail-closed behavior on integrity failure.
  - Added **CH-VBLOB v0** (verified blob descriptor) and registered it in the schema registry.
  - Updated decision map + core mechanisms narrative to include D-VERITY and to position verification as primarily user-space storage/pager policy (keep privileged core small).
  - Discipline wiring: new invariants **I-VERITY-1..3**, new proof obligations **PO-VBLOB-VALIDATE/PO-VERITY-ENF/PO-VERITY-BOUND**, and evidence seed **EVID-2026-117**.
  - Extended **RFC-0003** with a new bake-in item for D-VERITY and added a compressed inspiration lesson.
- Bibliography additions: **REF-LINUX-FSVERITY**, **REF-LINUX-DMVERITY**, **REF-ANDROID-DMVERITY**, **REF-ANDROID-AVB2-README**.



## Revised85 (2026-02-27)
- Added a “CPU-local fast paths without atomics everywhere” ecosystem seam:
  - Added **RFC-0113** introducing **D-RSEQ**: optional **restartable sequences** (Linux rseq lineage) so high-throughput runtimes can implement bounded per-CPU allocators/counters/queues with crisp abort-on-migrate semantics and a single commit point.
  - Updated decision map + core mechanisms narrative to position D-RSEQ as profile-gated (D-NONDET posture) and to clarify the determinism story for D-RR profiles (disable/virtualize/record).
  - Discipline wiring: new invariants **I-RSEQ-1..3**, new proof obligations **PO-RSEQ-BOUND/PO-RSEQ-NONDET**, and evidence seed **EVID-2026-116**.
  - Extended **RFC-0003** with a new bake-in item for D-RSEQ and added a compressed inspiration lesson.
- Bibliography additions: **REF-LINUX-RSEQ-DOC**, **REF-LINUX-RSEQ-MAN**, **REF-REDHAT-RSEQ-GLIBC**, **REF-LWN-RSEQ-GLIBC**.

## Revised84 (2026-02-27)
- Added a "read-mostly sharing without lock pain" ecosystem seam:
  - Added **RFC-0112** introducing **D-RCU**: optional **grace periods + deferred reclamation** (RCU/QSBR/EBR lineage) so components can publish new versions of shared state and safely reclaim old nodes after readers quiesce.
  - Updated decision map + core mechanisms narrative to include a bounded **GraceDomain** seam that composes with **D-UWAIT**/**D-WAITSET** for blocking waits and uses supervision (D-SUPV) as the explicit stall posture (no silent unbounded limbo).
  - Discipline wiring: new invariants **I-RCU-1..3**, new proof obligations **PO-RCU-BOUND/PO-RCU-NOORACLE**, and evidence seed **EVID-2026-115**.
  - Extended **RFC-0003** with a new bake-in item for D-RCU and added a compressed inspiration lesson.
- Bibliography additions: **REF-LINUX-RCU-WHATIS/REF-LINUX-RCU-CONCEPTS/REF-LINUX-RCU-CHECKLIST**, **REF-MCKENNEY-PERFBOOK**, **REF-HAZARD-POINTERS-MICHAEL**, **REF-FRASER-PRACTICAL-LOCK-FREEDOM**, **REF-HART-MEMRECL-IPDPS06**, **REF-LIBURCU**.

## Revised83 (2026-02-27)
- Added an ecosystem reliability seam for shared-memory synchronization:
  - Added **RFC-0111** introducing **D-ROBUSTLOCK**: optional **robust lock / owner-death** semantics so shared user-space locks don’t deadlock forever when an owner thread/process terminates while holding them.
  - Updated decision map + core mechanisms narrative to include a quota-bounded **RobustSet** registration seam that composes with **D-UWAIT**, supervision (D-SUPV), and deterministic replay (D-RR).
  - Discipline wiring: new invariants **I-ROBUST-1..3**, new proof obligations **PO-ROBUST-BOUND/PO-ROBUST-NOREUSE**, and evidence seed **EVID-2026-114**.
  - Inspirations/bibliography: added robust futex + WAIT_ABANDONED references and a compressed lesson mapping.

## Revised82 (2026-02-27)
- Added a “stop spinning / stop allocating events-per-lock” ecosystem seam:
  - Added **RFC-0110** introducing **D-UWAIT**: an optional **wait-on-address** (futex-like) primitive for efficient userspace mutex/condvar implementations (uncontended = userspace; contended = bounded kernel sleep/wake).
  - Updated decision map + core mechanisms narrative to treat wait-on-address as complementary to D-WAITSET (event loops) and to compose with D-REQCTX (timeout/cancel) without ambient time.
  - Discipline wiring: new invariants **I-UWAIT-1..3**, new proof obligations **PO-UWAIT-BOUND/PO-UWAIT-ATOMIC**, and evidence seed **EVID-2026-113**.
  - Extended **RFC-0003** with a new seed item for D-UWAIT and added a compressed lesson to `docs/90-inspirations/os-lessons.md`.
- Bibliography additions: **REF-MS-WAITONADDRESS/REF-MS-WAKEBYADDRESSSINGLE/REF-MS-WAITFUNCS**, **REF-LINUX-FUTEX2/REF-LINUX-FUTEX-PAPER**, **REF-FREEBSD-UMTX-OP**, **REF-FUCHSIA-FUTEX**.

## Revised81 (2026-02-27)
- Added a “post-mortem reliability” seam for incident workflows:
  - Added **RFC-0109** introducing **D-FLIGHTREC**: optional, bounded **flight recorder** retention rings for selected logs/traces/inspect state, with crash/watchdog/operator triggers that assemble CH-SNAPSHOT incident captures.
  - Added **CH-FLIGHTPOL v0** (retention + trigger policy artifact) and registered it in the schema registry.
  - Updated decision map + mechanisms narrative, and threaded D-FLIGHTREC into existing diagnostics/record-replay docs (RFC-0075, RFC-0013) and the ecosystem bake-in list (RFC-0003).
  - Discipline wiring: new invariants **I-FLIGHT-1..3**, new proof obligations **PO-FLIGHT-BOUND/PO-FLIGHT-ACCESS**, and evidence seed **EVID-2026-112**.
- Bibliography additions: **REF-SYSTEMD-JOURNALD**, **REF-LINUX-RAMOOPS**, **REF-LINUX-PSTORE**, **REF-ANDROID-NATIVE-CRASH**.

## Revised80 (2026-02-27)
- Added a “maintenance correctness” seam that is painful to retrofit later:
  - Added **RFC-0108** introducing **D-QUIESCE**: an optional, capability-gated **quiescence + drain/cancel protocol** for shutdown, restart swaps, and checkpoint capture.
  - Added **CH-QUIESCE v0** (bounded, non-authoritative maintenance intent/state descriptor) and registered it in the schema registry.
  - Updated decision map, core mechanisms narrative, and inspirations to treat quiesce/drain as a testable contract (not an ad-hoc signal).
  - Discipline wiring: new invariants **I-QUIESCE-1..3**, new proof obligations **PO-QUIESCE-STATE/PO-QUIESCE-GATE**, and evidence seed **EVID-2026-111**.
  - Extended **RFC-0003** with a new seed item for D-QUIESCE and updated the checkpoint/restore RFC to point at the minimal quiesce contract.
- Bibliography additions: **REF-SYSTEMD-SERVICE**, **REF-KUBE-LIFECYCLE-HOOKS**, **REF-ERLANG-RELEASE-HANDLING**, **REF-LINUX-CGROUP-FREEZER**.


## Revised79 (2026-02-27)
- Added a “throughput without bespoke fast paths” performance seam:
  - Added **RFC-0107** introducing **D-IOQ**: an optional **IoQueue** submission/completion ring object (io_uring / Windows I/O Rings shape) for batching I/O operations and harvesting completions efficiently.
  - Updated decision map, core mechanisms narrative, and inspirations: **D-IOQ** is now a first-class optional seam that composes with **D-WAITSET** and **D-IOBUF**.
  - Discipline wiring: new invariants **I-IOQ-1..3**, new proof obligations **PO-IOQ-BOUND/PO-IOQ-NOAMP**, and evidence seed **EVID-2026-110**.
  - Extended **RFC-0003** with a new seed item for D-IOQ.
- Bibliography additions: **REF-LINUX-IOURING-PDF/REF-LINUX-IOURING-ENTER/REF-LINUX-IOURING-MAN7**, **REF-WIN-IORING-OVERVIEW/REF-WIN-IORING-CREATE/REF-WIN-IORING-SUBMIT**.


## Revised78 (2026-02-27)
- Added a “hard-to-retrofit” event-loop scalability seam:
  - Added **RFC-0106** introducing **D-WAITSET**: object **signal bits** + an efficient **WaitSet** (epoll/kqueue/IOCP/Zircon ports–style) for waiting on many event sources without polling hacks.
  - Updated decision map and assurance registries: new invariants **I-WAITSET-1..3**, new proof obligations **PO-WAITSET-BOUND/PO-WAITSET-NOAMP**, and evidence seed **EVID-2026-109**.
  - Updated `docs/30-architecture/mechanisms.md` to call out WaitSets as an optional core mechanism seam; removed a duplicated “resource meters” section for clarity.
  - Extended **RFC-0003** with a new seed item for D-WAITSET and added a compressed lesson in `docs/90-inspirations/os-lessons.md`.
- Bibliography additions: **REF-ZIRCON-SIGNALS**, **REF-ZIRCON-OBJECT-WAIT-MANY**, **REF-ZIRCON-PORT-WAIT**, **REF-LINUX-EPOLL**, **REF-BSD-KQUEUE**, **REF-WIN-IOCP**.

## Revised77 (2026-02-27)
- Request-context seam added (avoid “timeout soup”; make cancellation/deadlines explainable):
  - Added **RFC-0105** introducing **D-REQCTX** and **CH-REQCTX v0** (bounded, non-authoritative request intent descriptor).
  - Added **CH-CAPRPC v1** as an optional correlation hook: CapRPC frames may carry `ctx_digest` (digest of CH-REQCTX) for transcript-friendly postmortems.
  - Updated **RFC-0026** (CapRPC) to call out request-context conventions and cancellation-as-default posture.
  - Updated decision map and assurance registries: new invariants **I-REQCTX-1..3**, new proof obligations **PO-REQCTX-VALIDATE/PO-REQCTX-ATTEN**, and evidence seed **EVID-2026-108**.
- Diagnostics inspiration tightened:
  - Added a compressed lesson for **Solaris Fault Management Architecture (FMA)** (typed error reports → diagnosis engines → response agents) and added it as prior art to **RFC-0087** triage.
  - Bibliography additions: **REF-SOLARIS-FMA-OVERVIEW**, **REF-SOLARIS-FMA-ADMIN**, plus request-context refs (**REF-GO-CONTEXT**, **REF-KOTLIN-CANCEL**, **REF-CAPNP-1.0-CANCEL**, **REF-VORPUS-TIMEOUTS**).

## Revised76 (2026-02-27)
- Added two “hard-to-retrofit” ecosystem seams:
  - **Constructor/factory components + confinement tests** (KeyKOS/EROS/Hydra lineage): tightened D-CONSTR narrative, added a compressed lesson, and added a matching RFC-0003 seed item pointing at RFC-0042.
  - **Interop-friendly networked object-capability transport** (CapTP/OCapN): added a compressed lesson and a matching RFC-0003 seed item emphasizing “no ambient network” and explicit introduction semantics.
- Meta-engineering:
  - `docs/30-architecture/mechanisms.md` now explicitly calls out constructors as an optional core mechanism seam.
  - Glossary expanded with **constructor/factory**, **confinement test**, and **sealer/unsealer** terminology.
- Bibliography: added **REF-KEYKOS-FACTORY** and **REF-HYDRA-CH6**.


## Revised75 (2026-02-27)
- Added three “operational primitives” lessons + corresponding feature seeds:
  - **Process containers / job objects** (Windows Job Objects + Linux cgroups + Fuchsia jobs) as a unified handle for limits + lifecycle cleanup (`docs/90-inspirations/os-lessons.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`, `rfcs/0012-resource-meters-space-banks-and-budgets.md`, `rfcs/0017-supervision-trees-and-restart-policy.md`).
  - **Death-watch notifications** (Mach dead-name notification pattern) as a clean liveness signal for supervisors (`docs/90-inspirations/os-lessons.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`, `rfcs/0017-supervision-trees-and-restart-policy.md`).
  - **Fast local RPC handles** (Solaris Doors) as a UX/perf target for local cap-RPC (`docs/90-inspirations/os-lessons.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`).
- Added new REF entries: **REF-WIN-JOBOBJECTS**, **REF-MACH-REQUEST-NOTIFY**, **REF-SOLARIS-DOORS**.
- Repo hygiene: removed stray tools/__pycache__/ and empty temp file; added a small `.gitignore`.

## Revised74 (2026-02-27)
- Inspirations + “bake-in” seeds tightened with a few underused-but-relevant systems:
  - Added compressed lessons for **Amoeba** (capability directories + immutable storage), **Twizzler** (object-centric persistence), and **Multics** (rings + the complexity cautionary tale) in `docs/90-inspirations/os-lessons.md`.
  - Extended **RFC-0003** with two new candidate ecosystem features:
    - **38)** Immutable, content-addressed “time machine” storage as a standard service (Venti/Bullet line).
    - **39)** Persistent object graphs and cross-run sharing (Twizzler line).
  - Added new REF entries to the bibliography: **REF-AMOEBA-INTRO/REF-AMOEBA-CACM90/REF-AMOEBA-1990S**, **REF-TWIZZLER-ATC20/REF-TWIZZLER-TR17**, **REF-MULTICS-RINGS/REF-MULTICS-PROTMULT/REF-KARGER-2002**.
- Meta: changelog cleanup (removed an empty Revised70 header that had no associated notes).

## Revised73 (2026-02-26)
- Application secrets made explicit (tight, portalized, non-ambient):
  - Added **RFC-0104** introducing **D-APPSECRET**: application secret seeds are mediated by a secret portal (`portal.secret`) and emit bounded **CH-APPSECRET v0** descriptors.
  - Registered **CH-APPSECRET v0** (`docs/30-architecture/app-secret-descriptor-schema-v0.md`), updated the portal-family registry and CH-PLEDGE token mapping with `portal.secret`.
  - Discipline wiring: new invariants **I-APPSECRET-1..3**, new proof obligations **PO-APPSECRET-VALIDATE/PO-APPSECRET-ENF**, and new abuse case **AC-089** (secret-oracle/correlation/stealth rotation).
  - Evidence seed: **EVID-2026-107** (schema validator + secret-portal harness plan; no secret bytes in transcripts).

## Revised72 (2026-02-26)
- Background execution + login autostart authority made explicit (tight, portalized):
  - Added **RFC-0103** introducing **D-BGLEASE**: background execution and login autostart are mediated by a background portal (`portal.background`) that returns BackgroundLease handles and emits a bounded **CH-BGLEASE v0** descriptor.
  - Registered **CH-BGLEASE v0** (`docs/30-architecture/background-lease-schema-v0.md`), added the `portal.background.*` family to the portal registry, and extended CH-PLEDGE token set/mapping with `portal.background`.
  - Discipline wiring: new invariants **I-BGLEASE-1..3**, new proof obligations **PO-BGLEASE-VALIDATE/PO-BGLEASE-ENF**, and new abuse case **AC-088** (stealth persistence + battery drain via background/autostart).
  - Evidence seed: **EVID-2026-106** (schema validator + background-portal harness plan: deny-by-default; TTL/renew clamps; indicators/status; no implicit net).
  - Inspirations + refs: added a compressed background/autostart lesson and bibliography refs for XDG Background portal, Android background execution limits/FGS restrictions, and Apple background execution modes.


## Revised71 (2026-02-26)
- Power/idle “inhibit” authority made explicit (tight, portalized):
  - Added **RFC-0102** introducing **D-INHIBITLEASE**: session transition inhibition (idle/suspend/logout/shutdown) is mediated by an inhibit portal (`portal.inhibit`) that returns inhibition lease handles and emits a bounded **CH-INHIBITLEASE v0** descriptor.
  - Registered **CH-INHIBITLEASE v0** (`docs/30-architecture/inhibit-lease-schema-v0.md`), added the `portal.inhibit.*` family to the portal registry, and extended CH-PLEDGE token set/mapping with `portal.inhibit`.
  - Discipline wiring: new invariants **I-INHIBIT-1..3**, new proof obligations **PO-INHIBIT-VALIDATE/PO-INHIBIT-ENF**, and new abuse case **AC-087** (battery drain / transition DoS).
  - Evidence seed: **EVID-2026-105** (schema validator + portal harness plan: TTL/renew clamps; delay vs block; indicator/consent posture; no ambient inhibit APIs).
  - Inspirations + refs: added a compressed “inhibitor lock / wake lock” lesson and bibliography refs for XDG Inhibit portal + systemd inhibitor locks + Android wake locks.

- Location authority made explicit (tight, portalized):
  - Added **RFC-0101** introducing **D-LOCLEASE**: location access is mediated by a location portal (`portal.location`) that returns scoped location capabilities and emits a redaction-aware **CH-LOCLEASE v0** descriptor (no coordinates).
  - Registered **CH-LOCLEASE v0** (`docs/30-architecture/location-lease-schema-v0.md`) and added the `portal.location.*` family to the portal registry and CH-PLEDGE token set (`portal.location`).
  - Discipline wiring: new invariants **I-LOCLEASE-1..3**, new proof obligations **PO-LOCLEASE-VALIDATE/PO-LOCLEASE-ENF**, and new abuse case **AC-086** (covert tracking/background surveillance).
  - Evidence seed: **EVID-2026-104** (validator + portal harness: TTL/cadence clamps; background posture; export redaction; no implicit net authority).
  - Inspirations + refs: added a compressed location lesson (coarse vs precise, foreground vs background) and new bibliography refs for the XDG Location portal, Android location permissions/background guidance, Apple Precise Location toggle, and GeoClue D‑Bus API.
- Meta-engineering: archive lint now checks that `portal.*` tokens in CH-PLEDGE are covered by the portal-family registry (prevents silent portal/token drift).


## Revised69 (2026-02-26)
- D-ATTRFS query seam made explicit (tight, low-TCB):
  - Added **RFC-0100** standardizing **CH-ATTRQ v0**: a bounded, deterministic predicate format for attribute-indexed queries (“Find” / smart folders) that stays capability-scoped (view-scoped) and avoids a privileged DB/VM.
  - Registered **CH-ATTRQ v0** in the schema registry (`docs/30-architecture/attribute-query-schema-v0.md`) and updated D-ATTRFS decision-map notes to reference query predicates.
  - Discipline wiring: new invariant **I-ATTRQ-1**, new proof obligations **PO-ATTRQ-VALIDATE/PO-ATTRQ-BOUNDS**, and new abuse case **AC-085** (index/query leakage + query-as-DoS).
  - Evidence seed: **EVID-2026-103** (validator + bounded evaluation harness + no-cross-view-leak negative tests).
  - Bibliography: added **REF-PFSD-BFS** (Giampaolo’s BFS book PDF) and extended the BeOS/Haiku lesson refs.

## Revised68 (2026-02-26)
- Portal family hardening + pledge coherence (tight, meta-engineering):
  - Fixed a drift bug: **CH-PLEDGE v0** now explicitly includes the portal-family tokens already used by the archive, and the mapping table now matches the schema.
    - Added tokens: `portal.capture`, `portal.xfer`, `portal.jobs`, `portal.a11y`, plus `portal.uri`, `portal.print`, `portal.device`.
  - Added `docs/30-architecture/portal-family-registry.md` to keep `portal.*` families stable and reviewable (ties RFCs → portal families → CH-* descriptors → CH-PLEDGE tokens).
  - Meta-engineering: archive lint now checks **CH-PLEDGE token enum ↔ mapping-table consistency**, and the `TBD` placeholder check now matches word boundaries correctly.
  - Inspirations + refs: tightened the portals lesson to call out OpenURI/Print/USB as “boring glue” that benefits from the same mediation discipline; added bibliography refs **REF-XDG-PORTAL-OPENURI/PRINT/USB**.
  - Evidence seed: **EVID-2026-102** (token-set expansion + mapping consistency lint guard).

## Revised67 (2026-02-26)
- Accessibility/automation authority made explicit (tight, low-TCB):
  - Added **RFC-0099** introducing **D-UIAUT**: accessibility + automation as **portal-mediated, leased sessions** with rights separation (observe ≠ inject) and shell-driven indicators.
  - Added **CH-UIAUT v0** schema (`docs/30-architecture/ui-automation-lease-schema-v0.md`) and registered it in the schema registry.
  - Decision map: added **D-UIAUT** adjacent to D-UICAP; updated RFC-0080 to reference D-UIAUT and to treat a11y/automation as session-granted capabilities.
  - Discipline wiring: new invariants **I-UIAUT-1..3**, new proof obligations **PO-UIAUT-VALIDATE/PO-UIAUT-ENF**, new abuse case **AC-084**, and evidence seed **EVID-2026-101**.
  - Meta-engineering: expanded the pledge token mapping to include portal families `portal.capture`, `portal.xfer`, `portal.jobs`, and `portal.a11y` (keeps CH-PLEDGE reviewable as portals grow).
  - Bibliography: added focused references for Android AccessibilityService, Apple accessibility trust gating, and Windows UIAccess.

## Revised66 (2026-02-26)
- Recovery boot posture added (tight, low-TCB):
  - Added **RFC-0098** introducing **D-RECOVERY**: a dedicated, minimal **recovery environment** as a first-class boot target, with at least one physical-presence entry path (boot menu/button/SAS).
  - Standardized a lightweight binding convention: include a `recovery_root` deployment digest in CH-UPD/CH-BOOT `artifacts[]` so recovery is provenance-bound like any other trusted deployment.
  - Added assurance hooks: **I-RECOVERY-1**, **PO-RECOVERY-ENTRY**, **PO-RECOVERY-NOAMP**, with evidence seeds **EVID-2026-099/100** for recovery boot + trial-boot loop harnesses.
  - Decision map: added **D-RECOVERY** and linked it to D-ATOMICUPD/D-HEALTH without importing policy into IF-BOOT.
- Inspirations + refs: extended OS lessons and bibliography with WinRE, Android recovery partition, and systemd rescue/emergency targets (REF-WINRE, REF-ANDROID-PARTITIONS, REF-SYSTEMD-SPECIAL).

## Revised65 (2026-02-26)
- Hardware knowledge seam sharpened (tight, low-TCB):
  - Expanded **RFC-0018 (D-SKB)** to make **fact evolution** explicit: added **CH-HWEVENT v0** (bounded hardware event deltas with epoch+monotonic sequencing) so hotplug/link changes can be audited and replayed without kernel policy logic.
  - Registered **CH-HWEVENT v0** in the schema registry and added schema doc `docs/30-architecture/hardware-event-schema-v0.md`.
  - Tightened integration points:
    - RFC-0085 now records hotplug notifications as CH-HWEVENT (when D-SKB is enabled) and binds attach/detach logs to `{epoch,event_seq}`.
    - RFC-0083 now treats driver binding as a D-SKB informed user-space policy decision rather than ad-hoc probing.
  - Decision map: expanded D-SKB options/evidence/notes to include CH-HWEVENT epoching and D-DEVGUARD interaction.
  - Evidence seeds added: **EVID-2026-097/098** (CH-HWEVENT validator negatives; SKB named-query determinism harness).
- Inspirations + refs: strengthened the SKB lesson (declarative/constraint framing) and added bibliography entries **REF-DECLARATIVE-OS** and **REF-FUCHSIA-DRIVER-NODES**.

## Revised64 (2026-02-26)
- Rollback safety for **mutable data** made explicit (tight, low-TCB):
  - Added **RFC-0097** (data contracts + migration gates) to prevent “code rollback into unreadable state.”
  - Extended **CH-CFG v0** with optional `data_contracts` (bounded per-dataset reader/writer compatibility declarations used by update tooling).
  - Tightened D-ATOMICUPD discipline: new invariant **I-ATOMICUPD-4** (data rollback is explicit) and new proof obligation **PO-ATOMICUPD-DATA** (deterministic activation/rollback checks; snapshot-barrier enforcement).
  - Added evidence seed **EVID-2026-096** (compat-window + breaking-migration + snapshot-barrier harness; rollback fail-closed; restore succeeds; health-commit gating).
  - Integrated into docs: updated `configuration-pipeline.md` (turn NixOS-style footgun into a concrete seam), RFC-0051 (atomic updates caveat + pointer), the decision map D-ATOMICUPD entry, and RFC-0003’s snapshot/boot-environment seed to reference RFC-0097.

## Revised63 (2026-02-26)
- Trusted UI path upgrade (tight, low-TCB):
  - Expanded **RFC-0080** to pin concrete **secure UI mode** semantics (SAS enters a spoof-resistant “secure desktop” for login/high-risk consent) and to add an optional **secure input session** seam (lease + TTL) that suppresses non-authorized keyboard interception during sensitive entry.
  - Strengthened D-UICAP wiring: clarified I-UICAP-2 to treat focus-chain disclosure as sensitive metadata (capability-gated), and tightened PO-UICAP-FOCUS accordingly.
  - Added evidence seed **EVID-2026-095** for SAS + secure-input integration tests (secure desktop entry; secure-input TTL/expiry; non-authorized global tap suppression).
- Ecosystem “bake-in” list: added a dedicated RFC-0003 seed item for trusted-path entry + secure input sessions (SAS + secure keyboard entry).
- Inspirations + refs: added a compressed lesson and bibliography entries for Fuchsia focus-chain sensitivity, macOS Secure Event Input (TN2150), and IBM’s Secure Attention Key / trusted path posture.

## Revised62 (2026-02-26)
- Meta-engineering: fixed archive lint failures by:
  - registering **CH-PROV v0** in the schema registry and adding **ADV-APP** to the canonical adversary list,
  - replacing the sparse evidence register with a complete, tabled **EVID index** (stubs for every referenced EVID),
  - removing shorthand range notation (`EVID-…/…`, `EVID-…..…`) in RFCs/changelog so traceability is machine-checkable.
- Research + synthesis: added an Exokernel/Nemesis “application-level resource management” lesson (and bibliography entry) to strengthen the D-METER/D-PRESSURE/D-PAGER framing, and added a matching RFC-0003 seed item.
## Revised61 (2026-02-26)
- Background work hardening (tight, low-TCB):
  - Added **RFC-0096** introducing **D-JOBS** + **CH-JOBREQ v0**: a bounded job-request descriptor for portal-mediated, constraint-based background work (no ambient cron/alarms).
  - Added schema doc: `docs/30-architecture/job-request-schema-v0.md` and registered **CH-JOBREQ** in the schema registry.
  - Decision map: added **D-JOBS** seam and linked it to D-TCAP/D-PRESSURE/D-ACTIVATE integration points.
  - Discipline wiring: new invariants **I-JOB-1/I-JOB-2**, new proof obligations **PO-JOBREQ-VALIDATE/PO-JOBS-ENF**, new abuse case **AC-083**, and evidence seed **EVID-2026-094**.
- Inspirations + refs: added a compressed lesson and focused bibliography entries for Android JobScheduler/WorkManager, Apple BGTaskScheduler semantics (earliestBeginDate is advisory), and systemd.timer.

## Revised60 (2026-02-26)
- Media capture hardening (tight, low-TCB):
  - Added **RFC-0095** introducing **CH-CAPTURE v0**: a bounded capture-session descriptor for portal-mediated camera/microphone/screencast/remote-desktop workflows (no ambient capture; no media bytes in the descriptor).
  - Added schema doc: `docs/30-architecture/capture-session-schema-v0.md` and registered **CH-CAPTURE** in the schema registry.
  - Decision map: added **D-CAPTURE** seam and updated D-UICAP/D-PLUMB integration points (RFC-0080 + RFC-0046) to reference RFC-0095 + CH-CAPTURE.
  - Discipline wiring: new invariants **I-CAPTURE-1/I-CAPTURE-2**, new proof obligation **PO-CAPTURE-VALIDATE**, new abuse case **AC-082**, and evidence seed **EVID-2026-093**.
- Inspirations + refs: added a compressed lesson and focused bibliography entries for PipeWire access control/session-manager split and XDG portal camera/audio discussions.

## Revised59 (2026-02-26)
- Desktop workflow hardening (tight, low-TCB):
  - Added **RFC-0094** introducing **CH-XFER v0**: a bounded transfer descriptor for portal-mediated clipboard/drag-drop/share transfers (no ambient broadcast; no payload bytes in the descriptor).
  - Added schema doc: `docs/30-architecture/transfer-descriptor-schema-v0.md` and registered **CH-XFER** in the schema registry.
  - Updated D-PLUMB integration points: refined the decision map and updated RFC-0046’s clipboard/drag-drop section to reference RFC-0094 + CH-XFER.
  - Discipline wiring: new invariants **I-XFER-1/I-XFER-2**, new proof obligation **PO-XFER-VALIDATE**, new abuse case **AC-081**, and evidence seed **EVID-2026-092**.
- Bibliography hygiene: fixed stray/orphan bullets in Fuchsia/Genode entries; added focused refs for Wayland `wl_data_device`, XDG portal Clipboard docs, and Android clipboard security guidance.

## Revised58 (2026-02-26)
- Signature hygiene + adoption upgrade (tight, low-TCB):
  - Added **RFC-0093** introducing **D-SIGENV** + **CH-SIGENV v0**: a small, canonical signature envelope that signs *payload digests* with DSSE-style type binding (prevents type confusion and wrapper proliferation).
  - Added schema doc: `docs/30-architecture/signature-envelope-schema-v0.md` and registered **CH-SIGENV** in the schema registry.
  - Decision map: expanded **D-UPD-SIGN** options and added dedicated **D-SIGENV** and **D-KEYLESS** seams for keyless signing profiles.
  - Discipline wiring: new invariants **I-SIGENV-1/I-KEYLESS-1**, new proof obligations **PO-SIGENV-VALIDATE/PO-SIGENV-VERIFY/PO-KEYLESS-VERIFY**, new abuse case **AC-080**, and evidence seed **EVID-2026-091**.
  - Integrated into docs: tightened provenance/update schema notes to point at CH-SIGENV as the concrete “signed container” shape; updated `docs/60-engineering/supply-chain-repro.md`, `docs/60-engineering/update-repository-metadata-and-key-rotation.md`, `docs/90-inspirations/os-lessons.md`, and RFC-0003 with a new “bake-in” seed item.
- Bibliography: added focused references for DSSE, in-toto Statement v1, Sigstore bundle format, and Fulcio OIDC claim mapping.


## Revised57 (2026-02-26)
- Vulnerability-triage ergonomics upgrade (tight, low-TCB):
  - Added **RFC-0092** introducing **D-VEX** + **CH-VEX v0**: a bounded, digest-bound VEX exploitability statement artifact that can be attached to releases/boots and checked for **subject binding** (avoid VEX drift; reduce scanner noise without tribal allowlists).
  - Added schema doc: `docs/30-architecture/vex-schema-v0.md` and registered **CH-VEX** in the schema registry.
  - Decision map: updated **D-SBOM** to reference the concrete VEX seam and added **D-VEX** as a dedicated optional decision.
  - Discipline wiring: new invariants **I-VEX-1/I-VEX-2**, new proof obligations **PO-VEX-VALIDATE/PO-VEX-BIND**, new abuse case **AC-079**, and evidence seed **EVID-2026-090**.
  - Integrated into docs: updated `docs/60-engineering/supply-chain-repro.md`, `docs/90-inspirations/os-lessons.md`, and RFC-0003 with a new “bake-in” seed item.
- Bibliography: added focused references for OpenVEX versioning, CSAF/ISO advisory framing, and a real-world distro VEX feed (Ubuntu).


## Revised56 (2026-02-26)
- Supply-chain audit ergonomics upgrade (tight, low-TCB):
  - Added **RFC-0091** introducing **D-SBOM** + **CH-SBOM v0**: a bounded, digest-bound SBOM inventory artifact that can be attached to releases/boots and checked for **subject binding** (avoid SBOM drift).
  - Added schema doc: `docs/30-architecture/sbom-schema-v0.md` and registered **CH-SBOM** in the schema registry.
  - Decision map: added **D-SBOM** as an optional seam for SBOM artifacts + closure binding.
  - Discipline wiring: new invariants **I-SBOM-1/I-SBOM-2**, new proof obligations **PO-SBOM-VALIDATE/PO-SBOM-BIND**, new abuse case **AC-078**, and evidence seed **EVID-2026-089**.
  - Integrated into docs: updated `docs/60-engineering/supply-chain-repro.md`, `docs/90-inspirations/os-lessons.md`, and RFC-0003 with a new “bake-in” seed item.
- Bibliography: added focused primary references for NTIA/CISA SBOM minimum elements, SPDX specs, CycloneDX spec overview, and CISA/OpenVEX VEX guidance.

## Revised55 (2026-02-26)
- Time as *usable* security infrastructure (tight, low-TCB):
  - Added **RFC-0090** introducing **D-TIMEPROOF** + **CH-TIMEPROOF v0**: a user-space authenticated time bootstrap posture (Roughtime + optional NTS discipline) with a bounded, exportable time-proof receipt artifact.
  - Added schema doc: `docs/30-architecture/time-proof-schema-v0.md` and registered **CH-TIMEPROOF** in the schema registry.
  - Decision map: extended **D-TIME** options to include authenticated bootstrap, and added **D-TIMEPROOF** as a dedicated seam.
  - Discipline wiring: new invariants **I-TIMEPROOF-1/I-TIMEPROOF-2**, new proof obligations **PO-TIMEPROOF-VALIDATE/PO-TIMEPROOF-VERIFY/PO-TIMEPROOF-APPLY**, new abuse case **AC-077**, and evidence seed **EVID-2026-088**.
- Inspirations + refs: added a compressed lesson tying Roughtime/NTS into update freshness and audit workflows, and added focused bibliography entries for Roughtime protocol + IETF draft and RFC 8915 (NTS).

## Revised54 (2026-02-26)
- Desktop sandbox ergonomics upgrade (tight, non-bearer persistence):
  - Added **RFC-0089** introducing **CH-DOCREF v0**: a portal-managed durable “recent document” handle that can be re-opened into a scoped, path-free file capability without becoming a bearer token.
  - Added schema doc: `docs/30-architecture/document-handle-schema-v0.md` and registered **CH-DOCREF** in the schema registry.
  - Tightened RFC-0046’s “document-store ID” note into a concrete CH-* artifact and linked to RFC-0089 (handles/caps, not paths).
  - Discipline wiring: new invariants **I-DOCREF-1/I-DOCREF-2**, new proof obligations **PO-DOCREF-VALIDATE/PO-DOCREF-REOPEN**, new abuse case **AC-076**, and evidence seed **EVID-2026-087**.
  - Updated D-PLUMB entry in the decision map to explicitly call out CH-DOCREF as an optional adoption seam for “recent documents”.
- Inspirations + refs:
  - Updated `docs/90-inspirations/os-lessons.md` with a compressed lesson tying the XDG document portal and macOS security-scoped bookmark pitfalls into our portal/receipt discipline.
  - Updated bibliography with **REF-XDG-PORTAL-DOCUMENTS** and **REF-FLATPAK-SANDBOX-PERMS**.

## Revised53 (2026-02-26)
- Ecosystem ergonomics upgrade for “default isolation” adoption:
  - Documented and integrated the **zygote/template-spawner** pattern (Android/Chromium): warmed templates that fork/clone (or snapshot-restore) to make disposable sandboxes fast and memory-efficient.
  - Updated RFC-0050 (D-EPHEM) with a concrete warm-template section and safety posture (“template is tainted authority; immediate one-way narrowing”).
  - Tightened D-INITSNAP and D-CHKPT RFCs to explicitly support **templates-as-artifacts** (CH-INIT / CH-CKPT digests bound for audit).
  - Extended compressed OS lessons and RFC-0003 with the new “preforked template spawners” seed.
- Bibliography: added focused primary references for Android zygote docs, Android memory overview (zygote fork + shared pages), and Chromium’s zygote process doc.

## Revised52 (2026-02-26)
- Measured-boot made mechanically usable:
  - Added **RFC-0088** introducing **CH-MEASLOG v0**: a bounded, replayable **measured boot event log** artifact (PCR quotes are not interpretable without the event log).
  - Added schema doc: `docs/30-architecture/measured-boot-log-schema-v0.md` and registered **CH-MEASLOG** in the schema registry.
  - Tightened `docs/30-architecture/boot-manifest-schema-v0.md` to bind measurements explicitly via CH-MEASLOG digest references.
  - Discipline wiring: new invariant **I-MEASLOG-1**, new proof obligation **PO-MEASLOG-VALIDATE**, and evidence seed **EVID-2026-086**.
  - Inspirations + RFC-0003: added the measured-boot log posture as a “bake-in seam” and anchored it to TCG/systemd/IMA references.

## Revised51 (2026-02-26)
- Added **RFC-0087** introducing **D-TRIAGE** + **CH-TRIAGE v0**: a pinned, bounded on-device triage rule format that evaluates over CH-INSPECT and/or CH-CRASHCAP to emit bounded findings and advisory snapshot requests.
- Added schema doc: `docs/30-architecture/triage-rules-schema-v0.md` and registered **CH-TRIAGE** in the schema registry.
- Wired triage into the discipline layer:
  - new invariants **I-TRIAGE-1/I-TRIAGE-2**, new proof obligations **PO-TRIAGE-VALIDATE/PO-TRIAGE-EVAL**, new abuse case **AC-075**, and evidence seed **EVID-2026-085**.
- Integrated triage into observability docs:
  - updated `docs/60-engineering/diagnostics-stack.md` (triage workflow pattern)
  - updated RFC-0076 (clarified CH-OBSPOL stays non-programmable; triage is a separate advisory artifact)
- Inspirations + refs: added a compressed lesson about Fuchsia triage + rule-based alerting, and added focused references for Prometheus alerting rules and osquery query-pack configuration.

## Revised50 (2026-02-26)
- Debuggability ecosystem upgrade (tight, bounded, policy-scoped):
  - Added **RFC-0086** introducing **CH-CRASHCAP**: a failure-shaped **crash capsule** manifest that binds crash metadata + environment digests + module identity (build IDs) and references bounded evidence payloads (log/trace/inspect windows; optional minidump/core; optional replay bundle).
  - Added schema doc: `docs/30-architecture/crash-capsule-schema-v0.md`.
  - Updated `docs/60-engineering/diagnostics-stack.md` to position CH-CRASHCAP as the default crash-report artifact (small cousin of CH-SNAPSHOT).
- Prior art + symbolization posture:
  - Updated `docs/90-inspirations/os-lessons.md` with a compressed lesson tying **Crashpad/Breakpad**, **systemd-coredump**, **minidumps**, and **build-id/debuginfod** style symbol fetch into our artifact/policy seams.
  - Updated `docs/00-meta/bibliography.md` with focused references for Crashpad design, systemd-coredump, Microsoft minidump format docs, ELF/GNU ld build-ids, and debuginfod/elfutils debuginfod.
- Archive wiring:
  - Updated D-INSPECT entry in the decision map to mention **CH-CRASHCAP** alongside CH-SNAPSHOT, and updated RFC-0075 to cross-link crash capsules.
  - Updated RFC-0003 with a new ecosystem seed item for crash capsules + stable symbolization.

## Revised49 (2026-02-26)
- Ecosystem “ground-floor” upgrades (tight, low-TCB seams):
  - Added an adoption lesson and tooling seam for **declarative configuration + generations** (Nix/NixOS-style): treat privileged config (CH-CFG) as the compiled output of a deterministic “config compiler,” and make rollback/generations a first-class UX. Wired into RFC-0003 and `docs/60-engineering/configuration-pipeline.md`.
  - Tightened observability ergonomics with **correlation semantics** (ETW/OTel-inspired) without changing CH-TRACE v0: standardized `sem` tags for trace/span/correlation identifiers in CH-TPROBE and documented cross-artifact correlation expectations (traces ↔ inspect snapshots ↔ receipts).
- Archive wiring:
  - Updated `docs/90-inspirations/os-lessons.md` with two new compressed lessons:
    - **NixOS generations + declarative config** as a practical template for “config-as-artifact” and rollback UX.
    - **Windows ETW / Apple unified logging** as a precedent for privacy-aware logging and activity/correlation IDs.
  - Updated RFC-0077 (D-TPROBE) to define recommended `sem` tags (`trace_id`, `span_id`, `parent_span_id`, `corr_id`) and to bind the “correlate by ID” posture to policy/redaction.
  - Added **ADR-0004** to pin the stance that CH-CFG is a small signed artifact produced by deterministic tooling (module evaluation), with generations tracked outside the privileged core.
- Bibliography: added focused references for NixOS manual/generations, Nix profile rollback, Microsoft ETW activity/correlation docs, Apple OSLog privacy, OpenTelemetry trace identifiers, and W3C Trace Context.

## Revised48 (2026-02-26)
- Inspiration and “bake-in seams” tightening:
  - Extended `docs/90-inspirations/os-lessons.md` with two pragmatic adoption precedents:
    - **Capsicum Casper** “capability services” pattern (pre-open explicit service handles before capmode/seal), mapped to D-SEAL/D-CAPMODE.
    - **ZFS boot environments** (Solaris/FreeBSD) as a real-world confirmation of our **CH-BOOTSEL** “pending/tries/commit” state machine for atomic upgrades.
  - Added a small Redox “schemes” lesson to reinforce the value of namespace-shaped service endpoints without ambient discovery.
- RFC refinements:
  - RFC-0016 (D-SEAL): added a Casper-style section describing how compat layers can keep DNS/userdb/etc behind explicit service capabilities after sealing.
  - RFC-0051 (D-ATOMICUPD): added ZFS boot environment prior art to the boot-selector notes and references.
  - RFC-0037 (D-CHKPT): added ZFS send/receive as a “streamed checkpoint artifact” prior-art sanity check.
- Canonicalization / drift control:
  - Marked **RFC-0054** as **DEPRECATED** and **superseded by RFC-0069** (typed diffs via CH-CAPDIFF); updated `docs/00-meta/deprecations.md` and `rfcs/README.md` accordingly.
- Bibliography: added focused references for ZFS boot environments, ZFS send/receive streams, FreeBSD Capsicum/Casper, and Redox schemes.

## Revised47 (2026-02-26)
- Inspirations/refactor pass:
  - Repaired and extended `docs/90-inspirations/os-lessons.md` with the previously-mentioned but missing compressed lessons: **Singularity contracts** (mapped to D-CONTRACT), **OpenBSD W^X** (D-DYNCODE), **Barrelfish SKB** (D-SKB), and **Project Oberon** (simplicity discipline).
  - Added a new persistence UX lesson: **Plan 9 Fossil + Venti** snapshot trees and immutable archival storage, mapped to D-PERSIST/D-NS/D-INSPECT.
- Persistence RFC tightening: updated **RFC-0038** with a Fossil-style “snapshots as a browseable namespace” convention and added the relevant references.
- Bibliography expanded with new Plan 9 snapshot prior art: **REF-PLAN9-FOSSIL** and **REF-PLAN9-FOSSIL-MAN**.
- Repo hygiene: fixed the markdown table formatting in `rfcs/README.md` (removed blank lines that broke table rendering).

## Revised46 (2026-02-25)
- Added **RFC-0085 (D-DEVGUARD)**: an adoptable **deny-by-default** posture for hotplug peripherals (USB/Thunderbolt/PCIe hotplug) that makes device access an explicit, transcript-visible, **revocable** capability grant.
  - New schema: **CH-DEVGUARD v0** (`docs/30-architecture/device-guard-policy-schema-v0.md`) for deterministic device-authorization rules (USBGuard-like) and auditability.
  - Discipline wiring: new invariants **I-DEVGUARD-1/I-DEVGUARD-2**, new proof obligations **PO-DEVGUARD-DECIDE/PO-DEVGUARD-ATTACH**, new abuse case **AC-074**, and new evidence seed **EVID-2026-084**.
  - Updated the decision map (D-DEVGUARD), RFC-0003 feature list (new item 37), compressed OS lessons, and bibliography with concrete prior art (Qubes USB workflows, USBGuard, Thunderspy, Windows Kernel DMA protection, GoodUSB).

## Revised45 (2026-02-25)
- Fixed archive lint issues introduced in the previous pass:
  - RFC-0081: replaced a wildcard supervision proof-obligation reference with concrete **PO-SUPV-NOAMP** / **PO-SUPV-RLIMIT**.
  - RFC-0082: corrected an undefined provenance decision-node token to **D-PCP**.
  - RFC-0083: removed accidental ID tokenization by rephrasing the “visible in CH-LOG” note.
- Added **RFC-0084 (D-IOBUF)**: an optional, adoptable **copyless buffer** seam that keeps bounded-copy the default but enables explicit shared-region buffer handles when needed.
  - New schema: **CH-IOBUF v0** (`docs/30-architecture/io-buffer-schema-v0.md`) for redaction-safe, audit-friendly buffer descriptors.
  - Safety posture: **cross-trust implies immutable/snapshot** (IO-Lite-style immutability or Zircon-style COW snapshots), with contracted ring protocols for mutable streaming cases.
  - Discipline wiring: new invariant **I-IOBUF-2**, new proof obligation **PO-IOBUF-VALIDATE**, tightened **PO-IOBUF-OWNERSHIP**, new abuse case **AC-073**, and new evidence seed **EVID-2026-083**.
- Updated the decision map (D-IOBUF) and inspiration notes with concrete prior art: IO-Lite immutable buffers, Zircon VMO rights + COW children, and Xen grant tables.

## Revised44 (2026-02-25)
- Tightened **D-IFC** (RFC-0047) into an adoptable **IFC-lite** posture: start by labeling a few high-leverage **export sinks** (IF-OBS and portal-mediated exports), make **declassify/endorse** an explicit, transcript-visible authority boundary, and (optionally) represent **quarantine** as a secrecy tag so “clear quarantine” compiles down to declassification.
- Added an explicit declassification/endorsement hook to the discipline layer:
  - new invariant **I-IFC-3** (label lowering / integrity raising requires explicit authority and is transcript-visible)
  - new proof obligation **PO-IFC-DECLASS** (no unauthorized widening of flows; fail closed)
  - new evidence seed **EVID-2026-082** (model-vs-impl differential harness plan + quarantine-as-tag interop tests)
- Threat-model hygiene: added **AC-072** (label laundering / confused-declassifier) with concrete mitigations and evidence targets.
- Inspirations + prior art refactor: added a compressed DIFC lesson to `docs/90-inspirations/os-lessons.md` and upgraded the **IFC / labeled systems** bibliography section with concise “key/why/us” bullets (plus the foundational DIFC model paper).

## Revised43 (2026-02-25)
- Added **RFC-0083**: a tightened **driver-host + compatibility capsule** story that makes driver isolation operationally boring: native drivers run in restartable **driver host** processes (manager-owned lifecycles), and legacy donor stacks (rump/LKL/DDE-style) are treated as **compatibility runtimes** behind an explicit capability membrane.
- Updated **RFC-0036** (D-RUMPK): expanded the comparison space to include **LKL**, L4Re’s driver bring-up patterns, and user-space driver frameworks (Fuchsia DF / Windows UMDF), and linked RFC-0083 as the shared “compat capsule membrane” guidance.
- Updated the decision map’s **D-RUMPK** entry to reference RFC-0036 + RFC-0083 and to explicitly call out Linux-kernel-library style capsules as an alternative runtime.
- Added a new inspirations mapping: **Fuchsia/UMDF driver hosts** as a concrete precedent for D-DRVDOM + D-SUPV + D-ACTIVATE (drivers as restartable user-space services).
- Threat-model + evidence wiring:
  - new abuse case **AC-071** (compatibility capsule escape / ambient host effects)
  - new evidence seed **EVID-2026-081** (compat capsule harness: ambient-effect probes + hostile-input fuzz + restart containment)
- Bibliography expanded with a focused driver-host/compatibility spine: **Fuchsia driver framework**, **UMDF overview**, **LKL**, and **L4Re driver tutorial**.

## Revised42 (2026-02-25)
- Added **RFC-0082** (**D-WITNESS**): an optional, out-of-band **witnessed-checkpoint** seam for transparency logs that raises the bar against **split-view / equivocation** and “targeted invisibility” of releases, while keeping the kernel fully agnostic.
- Tightened **D-TLOG** (RFC-0029): clarified how CH-TLOG anchors can carry (or reference) witness bundles, and reframed witnesses as a profile-gated “audit-complete” predicate rather than a boot dependency.
- Wired witnessing into the discipline layer:
  - new invariant **I-TLOG-2** (split-view resistance when D-WITNESS is enabled)
  - new proof obligation **PO-TLOG-WITNESS**
  - evidence seed **EVID-2026-080** (witness verifier + negative tests)
  - new abuse case **AC-070** (split-view log attack / targeted transparency failure)
- Inspirations + bibliography: added Sigsum’s witness-threshold model, transparency.dev witness/armored-witness, and Go’s sumdb transparency-log design as concrete prior art, and corrected/updated the Tessera reference.

## Revised41 (2026-02-25)
- Added **RFC-0081** (**D-ACTIVATE**): an optional, user-space **activation/handoff** seam that makes crash-only restarts operationally usable: supervisor-owned **stable service handles** (socket-activation style) are passed into each instance at start, and an optional **per-component handle store** can preserve a bounded set of handles across restarts.
- Added **CH-ACTSET v0** (`docs/30-architecture/activation-set-schema-v0.md`) and registered it in the CH schema registry.
- Extended **CH-COMP v0** with an optional `activation` object (`stable_exports` + bounded `handle_store` policy) and tightened validator obligations accordingly.
- Wired the seam into the discipline layer:
  - invariants **I-ACTIVATE-1**, **I-ACTIVATE-2**
  - proof obligation **PO-ACTIVATE-HANDOFF**
  - evidence seed **EVID-2026-079**
  - new abuse case **AC-069** (handle-store misuse / seal bypass / wrong-instance restore)
- Inspirations + refs: added systemd socket activation + FD store, launchd socket activation, nginx “upgrade on the fly”, and Fuchsia Stop/Kill lifecycle semantics as concrete prior art.

## Revised40 (2026-02-25)
- Added **RFC-0080** (**D-UICAP**): an optional **capability-mediated UI compositor** contract that treats surfaces + input endpoints as object capabilities (no ambient global window IDs), routes input via an explicit focus chain, and pushes high-risk UI authority (screenshot/screencast/remote-control) behind portal workflows + leases.
- Hardened the trusted-gesture story: updated **RFC-0039** (D-VOLITION) with an optional **Secure Attention Sequence** concept (SAS) for spoof-resistant entry into secure-mode login/consent flows.
- Wired UI isolation into the archive’s discipline layer:
  - invariants **I-UICAP-1**, **I-UICAP-2**, **I-SAS-1**
  - proof obligations **PO-UICAP-FOCUS**, **PO-SAS-DELIVER**
  - evidence seed **EVID-2026-078** (compositor harness negative tests)
  - threat-model pressure test **AC-068** (UI spoofing / input snooping / screen scrape)
- Inspirations + bibliography: added a focused UI boundary section with Wayland model-of-operation, Fuchsia ViewRef, Windows SAS, and xdg-desktop-portal Screenshot as concrete prior art.

## Revised39 (2026-02-25)
- Added **RFC-0079**: a pragmatic **TUF-style update repository metadata** seam (**D-TUF**) for distributing CH-UPD + artifacts with survivable key compromise, metadata expiry, and freeze/rollback resistance — while keeping the privileged boot path agnostic.
- Added an operator-focused playbook: `docs/60-engineering/update-repository-metadata-and-key-rotation.md` (key hierarchy, thresholds, expiry windows, incident recovery drill).
- Tightened assurance wiring: added **I-TUF-1**, **PO-TUF-VERIFY**, and evidence seed **EVID-2026-077** for a prototype repo + rotation/compromise drill harness.
- Threat-model hygiene: resolved an abuse-case ID collision by renumbering “trace predicate abuse / filter-DoS” to **AC-066** and updating references; added **AC-067** for repository freeze / stale-metadata attacks.
- Inspirations/references: added a concise TUF/Uptane lesson and bibliographic spine (TUF spec + metadata roles + Uptane best practices + Sigstore Fulcio/keyless overview).


## Revised38 (2026-02-25)
- Tightened **D-SEAL / CH-PLEDGE** into an adoption-friendly workflow: clarified that `violation="deny"` acts as a **learn/complain mode** (deny+log) enabling token discovery without syscall-by-syscall allowlists; added a concrete engineering playbook (`docs/60-engineering/authority-bracketing-and-promise-learning.md`).
- Updated **RFC-0016** to include a dedicated “learning/audit mode” section and to explicitly connect execpromises-style spawn-time narrowing to our supervisor/launcher posture.
- Strengthened CH-PLEDGE semantics docs: added guidance that deny-mode violations SHOULD emit deterministic, redaction-safe records to support CI drift gates; updated the pledge token→effect mapping notes accordingly.
- Inspirations + references: expanded the OpenBSD pledge/unveil lesson with modern portability/usability evidence (SerenityOS reimplementation + Threadbox 2025 research) and added corresponding bibliography entries.
- Meta-hygiene: reordered the late evidence-index block so EVID-2026-069..076 are in numeric order and added **EVID-2026-076** for the pledge learn-mode harness.


## Revised37 (2026-02-25)
- Added **RFC-0078** (**D-TURNS**): an optional turn-based ("vat") service concurrency profile to prevent implicit reentrancy (no inbox pumping), improve reasoning tractability, and tighten the deterministic replay story without changing the kernel scheduler.
- Updated **RFC-0026** (D-CAPRPC): added explicit guidance on reentrancy hazards and how D-TURNS composes with oneway/pulses and promise pipelining; expanded the invariants/PO list accordingly.
- Wired D-TURNS into the archive’s discipline layer: added invariant **I-TURNS-1**, proof obligation **PO-TURNS-NOREENTR**, evidence seed **EVID-2026-075**, and a new threat-model abuse case **AC-064** (inbox-pumping RPC reentrancy).
- Updated inspirations and references: added an OS-lesson mapping for E/Spritely vats and expanded the bibliography with E manuals/FAQ + Spritely core/CapTP onboarding; updated the Robust Composition reference to a more stable source URL.


## Revised36 (2026-02-25)
- Strengthened the **D-PERSIST/D-CHKPT** story with tighter prior-art grounding: KeyKOS/EROS/CapROS checkpointed authority graphs + CapROS device-state caveats + modern TreeSLS (SOSP 2023) as an NVM-era “capability tree checkpoint” existence proof; threaded into OS lessons and RFC-0065/RFC-0037.
- Upgraded **D-CAPRPC** with an explicit, optional **promise-handle + pipelined send** profile (Cap’n Proto/E lineage), including new invariant/proof-obligation hooks (I-CAPRPC-3 / PO-CAPRPC-PIPELINE) and evidence seed EVID-2026-074.
- Bibliography expanded with focused refs for Cap’n Proto RPC/pipelining, KeyKOS OSR 1992 writeup, TreeSLS, CapROS persistence/device notes, and checkpoint-based update literature (KUP, L4 user-level checkpointing).

## Revised35 (2026-02-25)
- Added a new high-leverage composition lesson: **seL4 Microkit/capDL** as an existence proof that treating architecture as a static description compiled into a concrete time‑0 snapshot can keep runtime tiny and make initialization verifiable; threaded into OS lessons and D-INITSNAP guidance.
- Updated RFC-0009 (D-COMP): added an optional **CH-COMP → CH-INIT sysgen** posture (Microkit-style) to minimize runtime degrees of freedom in static/high-assurance profiles while preserving CH-COMP as the review artifact.
- Added `docs/60-engineering/system-generation-pipeline.md`: a tight description of the author→lint→sysgen→boot pipeline, TCB boundaries, and early evidence targets for ‘boot matches snapshot’.
- Bibliography additions: REF-MICROKIT-MANUAL / REF-MICROKIT-GITHUB / REF-MICROKIT-TUTORIAL.

## Revised34 (2026-02-25)
- Added a new microkernel “reality check” inspiration: **QNX Neutrino resource managers + pulses** (path-attached user-space servers + bounded async notifications); threaded into OS lessons, namespace/view semantics, and translator seams.
- Extended RFC-0026 (D-CAPRPC) with an optional **oneway/pulse** method profile (interface-marked) and crisp “enqueue vs error” semantics (no silent drop); added invariant **I-CAPRPC-2** and proof obligation **PO-CAPRPC-ONEWAY**.
- Tightened namespace/view docs (RFC-0032 + `docs/30-architecture/view-objects.md`) to explicitly treat **attach/mount/name registration** as an authorization surface that must be capability-gated, transcript-visible, and sealable.
- Meta-hygiene: fixed a duplicate **EVID-2026-070** entry in the evidence index (renumbered the health seam to **EVID-2026-072**) and added an evidence seed for CapRPC oneway tests (**EVID-2026-073**).
- Bibliography additions: REF-QNX-RESMGR / REF-QNX-RESMGR-ATTACH / REF-QNX-PULSES / REF-QNX-MSGSENDPULSE.

## Revised33 (2026-02-25)
- Added a new high-leverage “operator reality check” seed: **Genode depot/Sculpt** as a microkernel-native example of integrity-protected packages with on-target update + routine rollback; threaded into OS lessons, D-FPM/D-ATOMICUPD guidance, and supply-chain notes.
- Updated RFC-0033 (D-FPM): incorporated Genode’s depot posture to reinforce “closure as artifact” and rollback-by-default as an ecosystem goal (not just a build-system preference).
- Updated RFC-0009 (D-COMP): added an explicit mapping to Fuchsia’s manifest/routing semantics (`use`/`offer`/`expose`) to keep the lesson while keeping CH-COMP v0 flat and validator-driven.
- Updated RFC-0060 (D-CHERI) and target-platform notes: anchored the CHERI track to **CheriBSD** deployment realities, Cambridge status notes, and a 2026 security analysis to keep the profile evidence-driven.
- Bibliography additions: REF-FUCHSIA-COMP-MANIFESTS, REF-FUCHSIA-CAPABILITIES, REF-GENODE-PKG/SCULPT/UPDATE-ROLLBACK, REF-CHERIBSD/CHERIBSD-CAMBRIDGE/CHERI-ANALYSIS-2026.

## Revised32 (2026-02-25)
- Refactored `docs/90-inspirations/os-lessons.md` into a compressed, theme-grouped map of high-leverage OS lessons; added Qubes qrexec/templates/clipboard + Solaris SMF as concrete, ops-proven precedents.
- RFC hygiene: strengthened `rfcs/0000-template.md` with explicit TCB/`unsafe` delta + profile gating + compatibility + abuse-case sections.
- Updated RFC-0003: fixed heading numbering (`13b`), added **13c** on Qubes-style cross-domain services + policy-as-data, and threaded Qubes template/clipboard references into atomic updates and portal workflows.
- Updated RFC-0017 supervision to include Solaris SMF as an additional reference point for declarative manifests + restarters.
- Bibliography additions: added REF-QUBES-QREXEC / REF-QUBES-TEMPLATES / REF-QUBES-TEMPLATE-IMPL / REF-QUBES-CLIPBOARD / REF-QUBES-SPLITGPG and REF-SOLARIS-SMF-BP / REF-SOLARIS-SMF-CREATESVC.

## Revised31 (2026-02-25)
- Added **RFC-0077** (D-TPROBE): a pinned **tracepoint descriptor manifest** (**CH-TPROBE v0**) that binds CH-TRACE probe IDs to ordered **field names/types** plus **redaction classes** for safe tooling and predicates.
- Wired D-TPROBE into the decision map, tracing mechanisms, and diagnostics stack; updated CH-TRACE/CH-TPRED docs to reference CH-TPROBE as the authoritative field schema table.
- Added assurance hooks for trace schema safety: invariant **I-TPROBE-1**, proof obligations **PO-TPROBE-VALIDATE/PO-TPROBE-MATCH**, evidence seed **EVID-2026-070**, and threat-model abuse case **AC-063** (schema confusion / redaction bypass).
- Finished D-ENC doc hygiene: removed remaining “canonical JSON is the signed bytes” wording and standardized CH-CLOCK/CH-ENTROPY/CH-RR/CH-RRBUNDLE schema docs on **canonical CBOR** (JSON authoring only; ADR-0003).

## Revised30 (2026-02-25)
- Fixed accidental duplication/corruption in `docs/20-assurance/proof-obligation-registry.md`.
- Added **RFC-0076** (D-OBSPOL): a pinned **observation export policy** artifact (**CH-OBSPOL v0**) to make diagnostics export rules explicit, bounded, and auditable.
- Added **CH-OBSPOL v0** schema doc and registered it in the schema registry; updated IF-OBS + exit-surface ledger to reference the policy seam.
- Added decision nodes **D-OBS** and **D-OBSPOL** to the decision map; introduced invariant **I-OBSPOL-1** and proof obligation hooks for policy validation/application.
- Expanded bibliography with Fuchsia diagnostics/inspect, Android bugreport, Apple sysdiagnose, and Microsoft WER dump references.

## Revised29 (2026-02-25)
- Added **RFC-0075** (D-INSPECT): an Inspect-inspired structured diagnostics tree contract plus **support/incident snapshot bundles** (shareable triage artifacts distinct from replay bundles).
- Added **CH-INSPECT v0** (inspect snapshot) and **CH-SNAPSHOT v0** (diagnostic snapshot bundle manifest) schema docs; registered both in the schema registry.
- Added a new engineering note doc: `docs/60-engineering/inspect-and-snapshots.md`.
- Wired **D-INSPECT** into the decision map, mechanisms, and diagnostics stack mapping.


## Revised28 (2026-02-25)
- Added **RFC-0074** (D-HEALTH): explicit health predicates + capability-gated boot-success commit for spoof-resistant “trial boot → commit on health” semantics.
- Added **CH-HEALTH v0** (health predicate) and **CH-HEALTHREC v0** (health record) schema docs; registered both in the schema registry.
- Tightened CH-BOOTSEL semantics to allow `pending.policy.health_pred_digest` binding and to recommend emitting/binding CH-HEALTHREC on commit.
- Extended **CH-COMP v0** with optional `ready` metadata to support a minimal one-shot readiness barrier (ReadyToken) used by health evaluation and supervision.
- Wired new invariants/POs/EVID seeds and updated AC-059 to include D-HEALTH invariants.

## Revised27 (2026-02-25)
- Added **RFC-0073** (D-TPRED): a bounded trace-predicate contract (**CH-TPRED v0**) for safe prefiltering of CH-TRACE streams (no in-kernel scripting).
- Added **CH-TRACEPROC v1** (schema) to optionally reference CH-TPRED filters in trace-processor configuration; kept v0 for compatibility.
- Threaded D-TPRED through the decision map, mechanisms, and RFC-0015; clarified that early profiles can choose portal-only filtering with optional source-prefilter later.
- Minor doc hygiene: fixed a tracing section typo in mechanisms.md.

## Revised26 (2026-02-25)
- D-IDL/D-APIEVO refinement: clarified canonical `idl_digest` policy + stable method ordinal rules; added `docs/60-engineering/idl-digest-and-ordinal-policy.md`.
- Added **CH-ORD v0** (interface ordinal manifest) + RFC-0072 to pin method name↔id mappings and gate ordinal reuse/collisions.
- Clarified open-interface posture: for CH-IFACE.openness=`open`, it is often preferable to omit `idl_digest` so `iface_digest` stays stable as methods are added; pin evolving IDL revisions via CH-ORD.
- Updated CapRPC schema doc + RFCs (0011/0026/0071) and inspirations notes accordingly.


This archive is intentionally “living”. This file records *high-level* deltas between packaged revisions.


## revised25 (2026-02-25)
- Added **RFC-0071** (D-APIEVO): a concrete interface-evolution posture (closed vs open), explicit unknown-op behavior, and first-class adapter/translator components to avoid “silent fallback” confused-deputy hazards.
- Added **CH-IFACE v0** (interface descriptor) and registered it in the schema registry; refined **CH-CAPRPC** wording so `iface_digest` refers to a **CH-IFACE** digest (not a raw IDL blob), keeping on-wire identity aligned with policy-relevant pins.
- Standardized CapRPC forward-compat framework errors (`UNKNOWN_IFACE` / `UNKNOWN_METHOD`) and documented policy guidance for open vs closed interfaces.
- Added assurance hooks for evolution safety: invariant **I-APIEVO-1**, proof obligation **PO-APIEVO-NOGUESS**, and evidence seed **EVID-2026-068**.
- Added an engineering checklist for safe evolution: `docs/60-engineering/interface-evolution-workflow.md`, and expanded the bibliography with Fuchsia (open protocols / unknown interactions), Cap'n Proto, Protobuf, and COM interface-identity references.


## revised24 (2026-02-25)
- Added **CH-BOOTSEL v0** (boot selector state) as a pinned schema to support A/B-style *trial boot then commit* semantics (bounded tries + automatic fallback to last-known-good).
- Extended **RFC-0051** (atomic system updates) with a concrete boot-health commit handshake, plus new assurance hooks: invariant **I-ATOMICUPD-3** and proof obligations **PO-BOOTSEL-VALIDATE/PO-ATOMICUPD-COMMIT**.
- Threaded CH-BOOTSEL through IF-BOOT and CH-BOOT artifact roles (`boot_selector`) so selection/rollback decisions are auditable in transcripts and boot manifests.
- Added threat-model abuse case **AC-059** (boot-success marking bypass) and evidence seeds **EVID-2026-066, EVID-2026-067** for selector state-machine and negative-test plans.
- Refactored RFC-0051 field naming to align with CH-UPD (`target_root_digest`) and extended the bibliography with Android/ChromeOS/Fuchsia update references for future evidence-driven iteration.

## revised23 (2026-02-25)
- Closed D-ENC loose ends: standardized CH-ATTR + CH-HARDEN schemas on **canonical CBOR** as the normative signed bytes, with an explicit "JSON is authoring only" rule (JCS/RFC 8785) and deterministic transcode guidance.
- Added **ADR-0003** (D-ENC) and tightened `encoding-policy.md` + decision map D-ENC to record the canonical-bytes decision and prevent future hash/signature ambiguity.
- Added `docs/30-architecture/capability-rights-registry.md` (v0) to keep capability classes + rights bits explicit and UI-renderable (CH-CAPDIFF), including an early exec/execmod seam.
- Refactored **RFC-0059** to name the exec-authority capability (`VmExec`) and adopt a "two-key" execute gate (mapping authority + executable backing bytes), with concrete inspiration from Zircon/Fuchsia.
- Extended OS lessons + bibliography with Zircon/Fuchsia execute-gating references (`zx_vmar_map`, `zx_vmo_replace_as_executable`) and added RFC 8785 to canonicalization references.
- Hardened the meta-tooling: archive lint now fails on unresolved **TBD** placeholders in prose.

## revised22 (2026-02-25)
- Deepened the **deterministic replay** story into a concrete, ecosystem-ready "time travel debugging" target: expanded the rr lesson (OS lessons) and RFC-0013 with explicit user-space tooling goals (reverse execution, bisection/search-through-time, queryable traces) and aligned it with D-NONDET + D-CHKPT as optional accelerators.
- Extended the deterministic replay bibliography with practical and research references for "time-travel" workflows and concurrency determinism (Microsoft TTD, FReD, Pernosco dataflow, Kendo) to keep future scope expansions evidence-driven.
- Added `docs/60-engineering/diagnostics-stack.md` to clarify the artifact layering (CH-LOG vs CH-TRACE vs CH-RR vs CH-CKPT) and the safety rules for capture/export/minimization (explicit authority + redaction + boundedness).
- Extended CH-RRBUNDLE guidance to allow an optional `rr_index` payload as a non-authoritative acceleration structure for fast reverse queries/minimization without changing correctness semantics.
- Updated roadmap + decision map + glossary to reflect time-travel debugging as a first-class *ecosystem* goal layered over the replay boundary.


## revised21 (2026-02-25)
- Tightened the **compatibility-runtime story**: expanded D-RUMPK and **RFC-0036** with explicit comparisons to Drawbridge-style libOS/picoprocess compartments and gVisor-style userspace kernels, and clarified that any large ABI facade must stay outside the privileged core behind an explicit, fail-closed membrane.
- Added assurance hooks for compatibility runtimes: invariants **I-COMPAT-1/I-COMPAT-2** and proof obligations **PO-COMPAT-CLOSESET/PO-COMPAT-NOAMBIENT**.
- Extended **RFC-0003** with a **sealed appliance / unikernel-style deployment profile** seed (mapped to D-SEAL/D-FPM/D-BOOT) and a Drawbridge seed as an alternative future compatibility runtime.
- Updated inspirations + glossary to capture the key lessons and terminology (libOS, picoprocess, userspace kernel, unikernel).
- Added bibliography references: **REF-DRAWBRIDGE-ASPL11**, **REF-DRAWBRIDGE-POSIXPICO**, **REF-GVISOR-COST**, **REF-UNIKERNELS-ASPL13**, **REF-MIRAGE-PAPERS**.

## revised20 (2026-02-24)
- Added **RFC-0070**: Sealed secrets + vault service (D-VAULT): standardizes a user-space vault seam for credentials/opaque secrets with pinned policy (**CH-SECRETPOL**) and durable references (**CH-SECRETREF**) so CapStore persists *references*, not secret blobs, and high-risk releases can be consent/receipt- or attestation-gated without expanding the privileged core.
- Added schemas **CH-SECRETPOL v0** and **CH-SECRETREF v0** and registered them in the schema registry; extended mechanisms/roadmap/glossary with the vault seam.
- Extended threat model with abuse case **AC-058** and assurance hooks with invariants **I-VAULT-1/I-VAULT-2** and proof obligations **PO-SECRETPOL-ENF/PO-SECRETREF-PIN**.
- Added bibliography/lessons references for mainstream keychain/keystore patterns and Plan 9 secstore (Apple Keychain, Apple Platform Security keychain data protection, Android Keystore + key attestation, Plan 9 secstore).

## revised19 (2026-02-24)
- Added **RFC-0069**: Capability diffs for consent + receipts (CH-CAPDIFF, D-EXPLAIN): a typed, bounded “authority diff” object that the trusted UI can show and then bind into CH-VOL + CH-RECEIPT, reducing grant-creep/confused-deputy risk.
- Added schema **CH-CAPDIFF v0** (capability diff summary) and registered it in the schema registry; updated CH-RECEIPT to prefer CH-CAPDIFF digests.
- Strengthened assurance hooks for D-EXPLAIN: added abuse case **AC-057**, invariant **I-EXPLAIN-4**, and proof obligation **PO-CAPDIFF-REDACT**.
- Extended OS lessons + bibliography with concrete “powerbox/portal” references (xdg FileChooser, Sandstorm Powerbox, Plash powerbox) and secure UI design guidance (Yee 2002).

## revised18 (2026-02-24)
- Added **RFC-0068**: Wasm trace-processing pipelines (D-TRACEPROC): a user-space “programmable observability” seam that runs untrusted Wasm processors over CH-TRACE streams to produce bounded, redaction-safe aggregates without introducing an in-kernel scripting VM.
- Added schema **CH-TRACEPROC v0** (trace-processing request) and wired it into the schema registry.
- Threaded D-TRACEPROC through the decision map, mechanisms, OS lessons, roadmap, threat model (AC-056), invariants (I-TRACEPROC-1), and proof obligations (PO-TRACEPROC-SBX/PO-TRACEPROC-BOUNDS).

## revised17 (2026-02-24)
- Added **RFC-0067**: Capability crypto services + non-exportable key handles (D-CRYPTOSVC): standardizes “keys as capabilities” so long-lived secrets stay in a small user-space crypto provider (often the auth agent) and clients receive operation-only handles.
- Added schemas **CH-KEYPOL v0**, **CH-KEYREF v0**, and **CH-CRYPTOAUDIT v0**, wired into the schema registry for reviewable policy pins, durable key references (CapStore stores refs, not secrets), and redaction-safe crypto audit entries.
- Threaded D-CRYPTOSVC through the decision map, mechanisms, OS lessons, roadmap, invariants (I-CRYPTO-1/2), and proof obligations (PO-CRYPTOAUDIT-REDACT / PO-CRYPTOPOL-ENF); tightened AC-015 evidence targets to use pinned policy + audit payloads.

## revised16 (2026-02-24)
- Added **RFC-0066**: Capability leases + limited-use proxies (D-LEASE): standardizes time-/use-limited proxy capabilities as a user-space pattern for “temporary authority” at portals/gateways.
- Added **CH-CAPLEASE v0** schema and wired it into the schema registry for audit/receipt binding (no secrets, redaction-friendly).
- Threaded D-LEASE through decision map, capability semantics, mechanisms, roadmap, OS lessons, invariants (I-LEASE-1..3), proof obligations (PO-LEASE-VALIDATE/ENF/NOAMP), and threat model (AC-055).
- Refactored schema naming: **CH-LEASE v0 → CH-IOLEASE v0** for device/I/O leases to reduce ambiguity; recorded in deprecations and updated RFC-0045 + references.

## revised15 (2026-02-24)
- Added **RFC-0065**: Orthogonal persistence + capability store (D-PERSIST): an optional user-space CapStore with durable named roots, explicit durability authority, and rollback/resurrection defenses.
- Added **CH-CAPSTORE v0** schema and wired it into the schema registry.
- Threaded D-PERSIST through decision map, abstract machine, mechanisms, roadmap, threat model, abuse cases (AC-054), invariants (I-PERSIST-1..3), and proof obligations (PO-CAPSTORE-VALIDATE, PO-PERSIST-NOAMP, PO-PERSIST-ROLLBACK).
- Expanded bibliography and OS lessons with CapROS + orthogonal persistence references.

## revised14 (2026-02-24)
- Added **RFC-0064**: Confidential-computing profile (D-CC): an optional deployment extension that binds CC attestation evidence to our CH-BOOT/CH-PROV digests without importing CC protocols or policy into the privileged core.
- Tightened deployment-profile wording for CC mode (attest-only vs enforced isolation) and added decision-map cross-link for D-CC.
- Expanded assumptions and bibliography for CC/attestation with RATS (RFC 9334) and platform evidence references (SNP/TDX/CCA).
- Added a new abuse case **AC-053** covering CC attestation replay / wrong-state secret release failure modes.

## revised13 (2026-02-24)
- Added **RFC-0063**: Nondeterminism capabilities (Clock + Entropy handles) (D-NONDET): makes time/entropy explicit authority for replay, sandboxing, and timer hygiene.
- Added **CH-CLOCK v0** and **CH-ENTROPY v0** schemas; threaded the seam into D-RR and D-WASM where “no ambient time/entropy” was already required.
- Added **D-NONDET** to the decision map; added invariants/proof obligations (I-NONDET-1..4, PO-NONDET-NOAMBIENT, PO-CLOCK-VALIDATE, PO-ENTROPY-VALIDATE, PO-NONDET-RR) and a new abuse case AC-052.
- Extended OS lessons + bibliography with WASI clocks, OpenBSD getentropy/arc4random, and high-resolution timer policy/attack references.

## revised12 (2026-02-24)
- Added **RFC-0062**: Hardware memory tagging + hardening profiles (D-MEMTAG): an optional track that treats hardware tagging (e.g., Arm MTE) as a first-class hardening seam for unsafe/legacy compartments, pinned as data via **CH-HARDEN v0**.
- Added **CH-HARDEN v0** schema and threaded `harden_profile` artifact binding guidance into CH-BOOT; added invariants/proof obligations (I-HARDEN-1, I-MEMTAG-1, PO-HARDEN-BIND, PO-MEMTAG-ENF) and a new abuse case AC-051.
- Updated decision map, roadmap, OS lessons, and bibliography with MTE references (Android + Linux).

## revised11 (2026-02-24)
- Added **RFC-0061**: Bootstrappable toolchains + diverse double-compiling (D-BOOTSTRAP / D-DDC): treats toolchain trust as an explicit seam, binding bootstrap posture + optional DDC gates into provenance without expanding runtime TCB.
- Added **D-BOOTSTRAP** and **D-DDC** to the decision map, and threaded the seam into supply-chain guidance, OS lessons, and roadmap.
- Expanded supply-chain bibliography with references for “trusting trust”, DDC, and bootstrappable builds (Guix full-source bootstrap, stage0).

## revised10 (2026-02-24)
- Added **RFC-0060**: CHERI-ready compartmentalization profile (D-CHERI): an optional hardware-capability track for hardening unsafe/legacy compartments without entangling Phase‑1 bring-up.
- Added **D-CHERI** to the decision map, and threaded the track into target platform strategy, OS lessons, roadmap, and bibliography.
- Expanded CHERI bibliography: purecap vs hybrid definitions, Morello evaluation context, and CHERIoT (embedded).

## revised9 (2026-02-24)
- Added **RFC-0059**: sealed code spaces + dynamic code loading posture (D-DYNCODE): W^X default, capability-gated execmod, and profile-scoped exceptions.
- Added **D-DYNCODE** to the decision map and threaded the posture into mechanisms + threat model + roadmap.
- Extended OS lessons with: Singularity (contracts + manifest discipline), OpenBSD (W^X as default), Barrelfish (multikernel + SKB), Project Oberon (ruthless simplicity).
- Added bibliography refs for W^X and JIT attack surfaces (OpenBSD 3.3 W^X, OpenBSD kernel W^X talk, JITDefender, ACM “War on JITs”), plus Project Oberon.

## revised8 (2026-02-24)
- See prior revision notes in commit history or packaging metadata (if available).
