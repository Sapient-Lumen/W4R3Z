#!/usr/bin/env python3
"""Schema registry completeness drift gate.

Goal: prevent orphan CH-* schema specs from silently appearing in the repo without being
registered in docs/30-architecture/schema-registry.md.

This is intentionally conservative:
- It only considers files named '*-schema-vN.md' under docs/30-architecture/ and
  docs/70-llm-control/.
- It only requires that the schema-registry contains the schema filename (so both
  local links like '(foo-schema-v0.md)' and cross-dir links like '(../70-.../foo-schema-v0.md)'
  satisfy the check).

Exit codes:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[schema-registry] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[schema-registry] OK: {msg}")


def main() -> None:
    root = repo_root()
    reg_path = root / "docs/30-architecture/schema-registry.md"
    if not reg_path.exists():
        fail("missing docs/30-architecture/schema-registry.md")

    reg_txt = read(reg_path)

    schema_dirs = [
        root / "docs/30-architecture",
        root / "docs/70-llm-control",
    ]

    schema_files: list[Path] = []
    for d in schema_dirs:
        if not d.exists():
            continue
        schema_files.extend(sorted(d.glob("*-schema-v*.md")))

    if not schema_files:
        fail("no schema spec files found (unexpected)")

    missing: list[str] = []
    for p in schema_files:
        if p.name not in reg_txt:
            missing.append(p.relative_to(root).as_posix())

    if missing:
        # Keep output readable.
        preview = ", ".join(missing[:25])
        more = "" if len(missing) <= 25 else f" … (+{len(missing)-25} more)"
        fail(f"schema registry missing {len(missing)} schema spec(s): {preview}{more}")

    ok(f"schema registry includes all {len(schema_files)} schema specs")


if __name__ == "__main__":
    main()
