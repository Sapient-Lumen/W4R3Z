#!/usr/bin/env python3
"""Drift gate: forbid ambiguous policy-handle phrasing and stale CH-CFG.policy_bundle references.

Why this exists
--------------
Policy/authority denies must name *which policy handle* was in force on the
stable CH-DENY surface.

Past drift seams:
- prose mentions of "CH-CFG.policy_bundle" (a non-specified field) in schema
  comments/receipts, which silently reintroduces ambiguity and ambient coupling.
- vague wording like "profile-defined policy handle digest" without an explicit
  schema surface, which makes the receipt contract non-mechanical.

This guardrail keeps the archive LLM-resilient by ensuring these phrases do not
reappear.
"""

from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


FORBIDDEN = [
    "CH-CFG.policy_bundle",
    "profile-defined policy handle digest",
]


def is_text_file(p: Path) -> bool:
    return p.suffix in {".md", ".py", ".rs", ".txt"}


def main() -> int:
    problems: list[str] = []

    # Ensure the schema surface exists (prevents "handle" drifting back into prose).
    p_handle = ROOT / "docs/30-architecture/policy-handle-schema-v0.md"
    if not p_handle.exists():
        problems.append("missing required schema doc: docs/30-architecture/policy-handle-schema-v0.md")

    # Scan repo text files for forbidden legacy phrases.
    self_path = Path(__file__).resolve()
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        if p.resolve() == self_path:
            continue
        # Skip large binary-ish artifacts.
        if p.name.endswith(".zip"):
            continue
        if not is_text_file(p):
            continue
        try:
            txt = p.read_text(encoding="utf-8")
        except Exception:
            continue
        for s in FORBIDDEN:
            if s in txt:
                problems.append(f"{p.relative_to(ROOT)}: forbidden substring present: {s!r}")

    if problems:
        print("[policyhandle-clean] FAIL: forbidden legacy policy references detected:\n")
        for pr in problems:
            print(f"- {pr}")
        return 1

    print("[policyhandle-clean] OK: no stale CH-CFG.policy_bundle refs or ambiguous policy-handle phrasing")
    return 0


if __name__ == "__main__":
    sys.exit(main())
