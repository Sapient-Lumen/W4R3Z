#!/usr/bin/env python3
"""Deny-code reference closure drift gate.

Goal: keep deny_code tokens *closed and reviewable*.

This check enforces that any deny_code token explicitly mentioned in repo markdown
(reserving deny_code for stable, schema-pinned rejection classification) is a member
of the closed set in docs/30-architecture/deny-code-registry.md.

We intentionally only extract deny_code *tokens* from lines that appear to name a
specific deny_code ("deny_code = foo", "deny_code: foo", or "deny_code `foo`") to
avoid false positives from prose like "deny_code values are closed".

Policy:
- unknown tokens fail CI
- deny-code registry is source of truth
"""

from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Set


REPO_ROOT = Path(__file__).resolve().parents[1]
DENY_REG_PATH = REPO_ROOT / "docs" / "30-architecture" / "deny-code-registry.md"

MD_DIRS = [
    REPO_ROOT / "docs",
    REPO_ROOT / "rfcs",
    REPO_ROOT / "adrs",
]
MD_FILES_EXPLICIT = [
    REPO_ROOT / "README.md",
    REPO_ROOT / "CHANGELOG.md",
]

TOKEN_RE = r"[a-z][a-z0-9-]{1,63}"

# Only extract deny_code tokens from places that strongly suggest an explicit token.
PATTERNS = [
    re.compile(rf"\bdeny[_-]code\b\s*=\s*`?({TOKEN_RE})`?"),
    re.compile(rf"\bdeny[_-]code\b\s*:\s*`?({TOKEN_RE})`?"),
    re.compile(rf"\bdeny[_-]code\b[^`\n]*`({TOKEN_RE})`"),
]

# Registry row: first cell is backticked token.
REG_ROW_RE = re.compile(rf"^\|\s*`(?P<tok>{TOKEN_RE})`\s*\|")


@dataclass(frozen=True)
class Ref:
    path: Path
    lineno: int
    token: str
    line: str


def die(msg: str, code: int = 2) -> None:
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def parse_registry_tokens(path: Path) -> Set[str]:
    if not path.exists():
        die(f"[denycode-ref] missing deny-code registry: {path}")

    toks: Set[str] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        m = REG_ROW_RE.match(line)
        if m:
            toks.add(m.group("tok"))

    if not toks:
        die(f"[denycode-ref] failed to parse any deny_code tokens from registry: {path}")

    # Basic hygiene: kebab-case already ensured by regex; ensure uniqueness implicitly by set.
    return toks


def iter_markdown_files() -> Iterable[Path]:
    yielded: Set[Path] = set()

    for p in MD_FILES_EXPLICIT:
        if p.exists() and p not in yielded:
            yielded.add(p)
            yield p

    for base in MD_DIRS:
        if not base.exists():
            continue
        for root, _dirs, files in os.walk(base):
            for fn in files:
                if not fn.endswith(".md"):
                    continue
                p = Path(root) / fn
                if p not in yielded:
                    yielded.add(p)
                    yield p


def extract_refs(path: Path) -> List[Ref]:
    refs: List[Ref] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError:
        die(f"[denycode-ref] cannot decode as utf-8: {path}")

    for i, line in enumerate(lines, start=1):
        if "deny_code" not in line and "deny-code" not in line:
            continue

        for pat in PATTERNS:
            for m in pat.finditer(line):
                tok = m.group(1)
                # Deny codes are kebab-case tokens; v0 registry intentionally uses dash-containing tokens.
                # Ignore type-like strings (e.g., `deny_code: tstr` in schema definitions).
                if "-" not in tok:
                    continue
                # Ignore placeholders/wildcards or obvious non-tokens.
                if any(ch in tok for ch in "*<>${}"):
                    continue
                refs.append(Ref(path=path, lineno=i, token=tok, line=line.strip()))

    return refs


def main() -> None:
    reg = parse_registry_tokens(DENY_REG_PATH)

    all_refs: List[Ref] = []
    for md in iter_markdown_files():
        all_refs.extend(extract_refs(md))

    unknown: List[Ref] = [r for r in all_refs if r.token not in reg]

    if unknown:
        print("[denycode-ref] ERROR: unknown deny_code token(s) referenced in markdown:")
        for r in unknown[:80]:
            rel = r.path.relative_to(REPO_ROOT)
            print(f"  - {rel}:{r.lineno}: {r.token} :: {r.line}")
        if len(unknown) > 80:
            print(f"  ... and {len(unknown) - 80} more")
        die("[denycode-ref] FAIL: deny_code references must be registry-closed")

    uniq = len({r.token for r in all_refs})
    print(f"[denycode-ref] OK: all referenced deny_code tokens are registry-closed ({uniq} unique token(s) referenced)")


if __name__ == "__main__":
    main()
