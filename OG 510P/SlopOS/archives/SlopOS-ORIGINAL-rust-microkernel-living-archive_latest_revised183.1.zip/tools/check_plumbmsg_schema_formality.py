#!/usr/bin/env python3
"""CI drift gate: keep CH-PLUMBMSG v0 schema doc formal, bounded, and registry-wired.

Why this exists
--------------
CH-PLUMBMSG v0 is referenced by capshell exec-packs (CH-EXECPACK v2) and by
workflow plumbing (D-PLUMB). If its schema doc drifts into "informal" prose,
LLM/human edits tend to:
- omit fail-closed/closed-enum requirements,
- forget to bind `intent.kind` to the canonical registry,
- weaken bounds, reintroducing ambient workflow channels.

This check is intentionally minimal and robust:
- It does not attempt to parse a full schema.
- It enforces a small set of anchors that keep the doc coherent with the
  authority substrate and existing POs/invariants.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs/30-architecture/plumb-message-schema-v0.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[plumbmsg-schema] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[plumbmsg-schema] OK: {msg}")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/plumb-message-schema-v0.md")

    txt = read(DOC)

    # Title should make it clear this is a schema surface.
    first = txt.splitlines()[0].strip() if txt.splitlines() else ""
    if "CH-PLUMBMSG v0" not in first:
        fail("doc title missing 'CH-PLUMBMSG v0'")
    if "(schema" not in first:
        fail("doc title must include '(schema)' to mark it as a stable surface")
    if "informal" in first.lower() or "informal" in txt.lower():
        fail("plumb-message schema doc must not be marked or described as 'informal'")

    # Required sections that keep the doc reviewable and validator-friendly.
    for section in ["## Encoding", "## Data model", "## Validation rules"]:
        if section not in txt:
            fail(f"missing required section: {section}")

    # Wiring anchors: intent.kind closure and validator PO.
    if "docs/30-architecture/intent-kind-registry.md" not in txt:
        fail("must reference docs/30-architecture/intent-kind-registry.md")
    for tok in ["PO-PLUMBMSG-VALIDATE", "I-PLUMB-3", "I-ENC-1"]:
        if tok not in txt:
            fail(f"missing required assurance anchor token: {tok}")

    # Fail-closed anchor: unknown keys reject.
    if "Unknown" not in txt or "reject" not in txt.lower():
        fail("doc must explicitly state unknown keys/variants reject (fail closed)")

    ok("CH-PLUMBMSG schema doc is formal, bounded, and registry-wired")


if __name__ == "__main__":
    main()
