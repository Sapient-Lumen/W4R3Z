#!/usr/bin/env python3
"""CI drift gate: keep retry/dedupe semantics implementable and non-ambient.

Why this exists
--------------
The ACP kind registry pins retry-safety claims (idempotent / at-least-once-safe / exactly-once).
For any kind that claims *at-least-once-safe*, the spec must also pin an explicit, stable
idempotency/dedupe key in the schema surface (e.g., CH-EFFCON.contract_id, CH-JOBREQ.job_id,
CH-TIMEREQ.req_id, CH-NOTIF.id).

Without an explicit dedupe key, "retry safe" devolves into handwavy prose and implementations
silently reintroduce ambient ordering/state (or duplicate effects).

This check is intentionally narrow:
- it only inspects `docs/70-llm-control/acp-action-kind-registry.md`
- it only constrains rows whose Retry safety cell contains "at-least-once-safe"
- it requires those rows to mention an explicit stable id key (contract_id / *_id / .id)
- and for selected high-impact kinds, it pins the expected key name for drift resistance.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REG = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"


@dataclass
class Problem:
    detail: str


def strip_code_fences(txt: str) -> str:
    out: list[str] = []
    in_fence = False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def parse_kind_rows(txt: str) -> list[dict[str, str]]:
    lines = txt.splitlines()
    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Kind |"):
            header_idx = i
            break
    if header_idx is None:
        raise SystemExit("[retry-dedupe] FAIL: ACP kind registry table header not found")

    rows: list[str] = []
    for ln in lines[header_idx + 2 :]:  # skip header + separator
        if not ln.strip().startswith("|"):
            break
        if ln.strip() == "|":
            break
        rows.append(ln)

    parsed: list[dict[str, str]] = []
    for ln in rows:
        parts = [p.strip() for p in ln.strip().strip("|").split("|")]
        if len(parts) != 8:
            raise SystemExit(
                f"[retry-dedupe] FAIL: expected 8 columns per row, got {len(parts)}: {ln.strip()}"
            )
        parsed.append(
            {
                "kind": parts[0].strip("`").strip(),
                "retry": parts[4],
            }
        )
    return parsed


# Generic signal that a stable idempotency key is explicitly named.
RE_ANY_STABLE_ID = re.compile(r"(\bcontract_id\b|\b[a-z]+_id\b|\.[iI]d\b)")

# Kind-specific pins for high-impact surfaces.
EXPECTED_KEY_HINTS: dict[str, tuple[str, re.Pattern[str]]] = {
    "capshell.exec": ("contract_id", re.compile(r"\bcontract_id\b")),
    "portal.attn.request": ("CH-NOTIF.id", re.compile(r"\.id\b")),
    "portal.clock.timeproof.sample": ("req_id", re.compile(r"\breq_id\b")),
    "portal.jobs.submit": ("job_id", re.compile(r"\bjob_id\b")),
    "portal.background.request": ("req_id", re.compile(r"\breq_id\b")),
}


def main() -> int:
    if not REG.exists():
        print(f"[retry-dedupe] FAIL: missing {REG}")
        return 1

    txt = strip_code_fences(REG.read_text(encoding="utf-8"))
    rows = parse_kind_rows(txt)

    problems: list[Problem] = []

    for row in rows:
        kind = row["kind"]
        retry = row["retry"]
        rlow = retry.lower()

        if "at-least-once-safe" not in rlow:
            continue

        if not RE_ANY_STABLE_ID.search(retry):
            problems.append(
                Problem(
                    f"kind {kind} claims at-least-once-safe but Retry safety cell does not name an explicit stable id key (expected contract_id / *_id / .id)"
                )
            )
            continue

        # High-impact kinds: pin the expected key token to avoid prose drift.
        exp = EXPECTED_KEY_HINTS.get(kind)
        if exp:
            expected, pat = exp
        else:
            expected, pat = None, None
        if pat and not pat.search(retry):
            problems.append(
                Problem(
                    f"kind {kind} claims at-least-once-safe but Retry safety cell must explicitly mention {expected} for drift resistance"
                )
            )

        # Foreign-cell kinds: require cell_id explicitly.
        if kind.startswith("fcell.") and "cell_id" not in retry:
            problems.append(Problem(f"kind {kind} claims at-least-once-safe but must mention cell_id explicitly"))

    if problems:
        print("[retry-dedupe] FAIL: retry/dedupe wiring check failed:\n")
        for pr in problems:
            print(f"- {pr.detail}")
        return 1

    print("[retry-dedupe] OK: at-least-once-safe kinds name explicit dedupe/id keys")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
