#!/usr/bin/env python3
"""CI drift gate for hot-action commutativity + boundary wiring.

Motivation:
- D-COMMUTE makes commutativity/serialization an *interface* property.
- `hot-action-surface-v0.md` and `hot-action-boundaries-v0.md` are stable diff
  surfaces that pin the highest-leverage hot paths for proof + perf work.

Failure modes this guardrail prevents:
- A hot action is added/renamed in one table but not the other (silent drift).
- A pinned hot action loses an explicit non-commutative boundary / RC class.
- Notes lose the explicit Conflict key / Ordering token / RC statements needed
  to keep commutativity evidence honest.

Design: tiny, dependency-free, conservative, fail-closed.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Problem:
    path: Path
    detail: str


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def strip_code_fences(txt: str) -> str:
    out: list[str] = []
    in_fence = False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


_BT = re.compile(r"^`([^`]+)`$")


def unbt(cell: str) -> str:
    c = cell.strip()
    m = _BT.match(c)
    if m:
        return m.group(1).strip()
    # tolerate non-backticked family labels (e.g., "IPC endpoint ops")
    return c.strip()


def norm_family(s: str) -> str:
    # Normalize whitespace + strip markdown emphasis/backticks.
    s = s.replace("`", "").strip()
    s = re.sub(r"\s+", " ", s)
    return s


def parse_table(md: str, header_prefix: str, expected_cols: int) -> tuple[list[list[str]], int | None]:
    lines = md.splitlines()
    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("|") and header_prefix in ln:
            header_idx = i
            break
    if header_idx is None:
        return [], None
    # separator should be next
    rows: list[list[str]] = []
    for ln in lines[header_idx + 2 :]:
        if not ln.strip().startswith("|"):
            break
        parts = [p.strip() for p in ln.strip().strip("|").split("|")]
        if len(parts) < expected_cols:
            # still return it; caller can flag
            rows.append(parts)
        else:
            rows.append(parts[:expected_cols])
    return rows, header_idx


def extract_families_from_surface(md: str) -> tuple[list[str], list[Problem]]:
    problems: list[Problem] = []
    rows, idx = parse_table(md, "| Action family", 7)
    if idx is None:
        problems.append(Problem(ROOT / "docs/30-architecture/hot-action-surface-v0.md", "hot action table header not found"))
        return [], problems
    fams: list[str] = []
    for r in rows:
        if len(r) != 7:
            problems.append(Problem(ROOT / "docs/30-architecture/hot-action-surface-v0.md", f"table row must have 7 columns; got {len(r)}: {' | '.join(r)}"))
            continue
        fams.append(norm_family(unbt(r[0])))
    return fams, problems


def extract_families_from_boundaries(md: str) -> tuple[list[dict[str, str]], list[Problem]]:
    problems: list[Problem] = []
    rows, idx = parse_table(md, "| Family", 6)
    if idx is None:
        problems.append(Problem(ROOT / "docs/30-architecture/hot-action-boundaries-v0.md", "boundary table header not found"))
        return [], problems

    parsed: list[dict[str, str]] = []
    for r in rows:
        if len(r) != 6:
            problems.append(Problem(ROOT / "docs/30-architecture/hot-action-boundaries-v0.md", f"boundary table row must have 6 columns; got {len(r)}: {' | '.join(r)}"))
            continue
        parsed.append(
            {
                "family": norm_family(unbt(r[0])),
                "subactions": r[1].strip(),
                "where": r[2].strip(),
                "commute": r[3].strip(),
                "boundary": r[4].strip(),
                "rc": r[5].strip(),
            }
        )
    return parsed, problems


def extract_family_sections(md: str) -> dict[str, str]:
    """Map normalized family name -> section text from '###' headings."""
    # Split on level-3 headings only.
    lines = md.splitlines()
    out: dict[str, str] = {}

    cur_name: str | None = None
    cur_buf: list[str] = []

    def flush() -> None:
        nonlocal cur_name, cur_buf
        if cur_name is not None:
            out[cur_name] = "\n".join(cur_buf).strip() + "\n"
        cur_name = None
        cur_buf = []

    for ln in lines:
        m = re.match(r"^###\s+(.*)\s*$", ln)
        if m:
            flush()
            name = norm_family(m.group(1))
            cur_name = name
            cur_buf = []
            continue
        if cur_name is not None:
            cur_buf.append(ln)
    flush()
    return out


def section_contains_required(section_txt: str) -> bool:
    # Required statement heads.
    need = {
        "noncomm": "Non-commutative boundary",
        "ck": "Conflict key",
        "ord": "Ordering token",
        "rc": "Replication contract",
    }
    for _, needle in need.items():
        if needle not in section_txt:
            return False
    # Specific schema anchors.
    if "CH-CONFLICTKEY" not in section_txt:
        return False
    if "Ordering token" in section_txt and ("CH-ORDERTOK" not in section_txt and "none" not in section_txt.lower()):
        return False
    if not re.search(r"\bRC[0-4]\b", section_txt):
        return False
    return True


def main() -> int:
    problems: list[Problem] = []

    p_surface = ROOT / "docs/30-architecture/hot-action-surface-v0.md"
    p_bound = ROOT / "docs/30-architecture/hot-action-boundaries-v0.md"

    for p in (p_surface, p_bound):
        if not p.exists():
            problems.append(Problem(p, "missing required file"))

    if problems:
        for pr in problems:
            print(f"- {pr.path.relative_to(ROOT)}: {pr.detail}")
        return 2

    surface_md = strip_code_fences(read_text(p_surface))
    bound_md = strip_code_fences(read_text(p_bound))

    fams_surface, ps = extract_families_from_surface(surface_md)
    problems.extend(ps)

    bound_rows, pb = extract_families_from_boundaries(bound_md)
    problems.extend(pb)

    fams_bound = [r["family"] for r in bound_rows]

    # Cross-doc closure
    set_surface = set(fams_surface)
    set_bound = set(fams_bound)

    extra_in_surface = sorted(set_surface - set_bound)
    extra_in_bound = sorted(set_bound - set_surface)

    if extra_in_surface:
        problems.append(Problem(p_bound, "missing boundary rows for hot action families: " + ", ".join(extra_in_surface)))
    if extra_in_bound:
        problems.append(Problem(p_surface, "hot action surface missing families present in boundary table: " + ", ".join(extra_in_bound)))

    # Boundary table row completeness.
    for r in bound_rows:
        fam = r["family"]
        b = r["boundary"].strip()
        if not b or b in {"—", "-"}:
            problems.append(Problem(p_bound, f"boundary table: family '{fam}' missing explicit non-commutative boundary (use a sub-action name or 'none')"))
        rc = r["rc"]
        if not re.search(r"\bRC[0-4]\b", rc):
            problems.append(Problem(p_bound, f"boundary table: family '{fam}' replication contract must name an RC class (RC0..RC4); got: {rc!r}"))
        comm = r["commute"].lower()
        if not any(tok in comm for tok in ("commutes", "ordered", "commutative")):
            problems.append(Problem(p_bound, f"boundary table: family '{fam}' commutativity column must include 'commutes', 'ordered', or 'commutative'"))

    # Notes per family must keep explicit CK/ORD/RC statements.
    sections = extract_family_sections(bound_md)

    for fam in fams_bound:
        # Find a section whose heading contains the family label as a substring (normalized).
        match_key = None
        for k in sections.keys():
            if fam in k or k in fam:
                match_key = k
                break
        if match_key is None:
            problems.append(Problem(p_bound, f"missing '###' notes section for family '{fam}' (must include Conflict key / Ordering token / Replication contract statements)"))
            continue
        if not section_contains_required(sections[match_key]):
            problems.append(Problem(p_bound, f"notes section '{match_key}' missing required statements (Non-commutative boundary, Conflict key with CH-CONFLICTKEY, Ordering token with CH-ORDERTOK/none, Replication contract with RC*)"))

    if problems:
        print("Hot action wiring check failed:\n")
        for pr in problems:
            rel = pr.path
            try:
                rel = pr.path.relative_to(ROOT)
            except Exception:
                pass
            print(f"- {rel}: {pr.detail}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
