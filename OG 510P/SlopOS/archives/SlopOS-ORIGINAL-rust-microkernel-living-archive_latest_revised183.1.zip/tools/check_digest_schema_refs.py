#!/usr/bin/env python3
"""Versioned digest reference closure drift gate.

Goal: prevent silent drift where docs reference `digest(CH-XYZ vN)` for a schema
that is not registered in docs/30-architecture/schema-registry.md.

Why it matters:
- The stable product surface is schemas + validators + receipts.
- LLM edits often introduce subtle schema/version typos (e.g., `vO`, wrong vN,
  or a non-existent CH-ID) that are hard to spot in review.
- This gate keeps `digest(CH-* vN)` references mechanically tied to the schema
  registry, which is the archive's closed-world diff surface for wire contracts.

Scope (intentionally conservative):
- Only checks *versioned* references of the form `digest(CH-XYZ vN)`.
- Does not attempt to police unversioned shorthand like `digest(CH-BOOT)` which
  appears in many legacy notes and may refer to non-schema artifacts.

Exit codes:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


RE_DIGEST = re.compile(r"digest\(\s*(CH-[A-Z0-9]+)\s+v(\d+)\s*\)")
RE_REGROW = re.compile(r"^\|\s*(CH-[A-Z0-9]+)\s+v(\d+)\s*\|", re.MULTILINE)


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[digest-ref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[digest-ref] OK: {msg}")


def load_registry_pairs(reg_path: Path) -> set[tuple[str, str]]:
    txt = read(reg_path)
    pairs: set[tuple[str, str]] = set()
    for m in RE_REGROW.finditer(txt):
        pairs.add((m.group(1), m.group(2)))
    if not pairs:
        fail("failed to parse any CH-* vN rows from schema registry")
    return pairs


def iter_doc_files(root: Path) -> list[Path]:
    docs_dir = root / "docs"
    if not docs_dir.exists():
        return []
    return sorted(p for p in docs_dir.rglob("*.md") if p.is_file())


def main() -> None:
    root = repo_root()
    reg_path = root / "docs/30-architecture/schema-registry.md"
    if not reg_path.exists():
        fail("missing docs/30-architecture/schema-registry.md")

    reg_pairs = load_registry_pairs(reg_path)
    doc_files = iter_doc_files(root)
    if not doc_files:
        fail("no docs/*.md files found (unexpected)")

    missing: list[str] = []
    total_refs = 0

    for p in doc_files:
        txt = read(p)
        for m in RE_DIGEST.finditer(txt):
            total_refs += 1
            pair = (m.group(1), m.group(2))
            if pair not in reg_pairs:
                # Keep output readable; include file path and the token.
                missing.append(f"{p.relative_to(root).as_posix()}: {m.group(0)}")

    if missing:
        preview = "\n".join(missing[:40])
        more = "" if len(missing) <= 40 else f"\n… (+{len(missing)-40} more)"
        fail(
            "found versioned digest references to unregistered schemas\n"
            f"{preview}{more}\n"
            "Fix: register the referenced CH-ID/version in docs/30-architecture/schema-registry.md, "
            "or correct the reference."
        )

    ok(f"all {total_refs} versioned digest references resolve to schema registry entries")


if __name__ == "__main__":
    main()
