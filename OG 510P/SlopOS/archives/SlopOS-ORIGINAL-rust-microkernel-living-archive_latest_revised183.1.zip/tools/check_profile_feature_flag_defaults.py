#!/usr/bin/env python3
"""CI drift gate for profile feature-flag defaults matrix.

Design intent:
- Treat docs/30-architecture/profile-feature-flag-defaults.md as a stable diff surface.
- Ensure it stays mechanically consistent with the closed cfg.feature_flags value set
  pinned in docs/30-architecture/config-toggle-registry.md.
- Keep this check dependency-free and conservative to avoid noise.

This is non-authoritative guidance: flags never grant authority.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


CFG_REG = Path("docs/30-architecture/config-toggle-registry.md")
MATRIX = Path("docs/30-architecture/profile-feature-flag-defaults.md")


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def parse_md_table_rows(md: str, header_pred) -> list[list[str]]:
    """Return rows (as list of columns) for the first markdown table whose header matches header_pred."""
    lines = md.splitlines()
    for i, ln in enumerate(lines):
        if not ln.strip().startswith("|"):
            continue
        cols = [c.strip() for c in ln.strip().strip("|").split("|")]
        if not header_pred(cols):
            continue
        if i + 1 >= len(lines):
            raise ValueError("table header has no separator line")
        sep = lines[i + 1].strip()
        if not (sep.startswith("|") and "---" in sep):
            raise ValueError("table header missing separator line")
        rows: list[list[str]] = []
        j = i + 2
        while j < len(lines):
            row_ln = lines[j].rstrip()
            if not row_ln.strip().startswith("|"):
                break
            row_cols = [c.strip() for c in row_ln.strip().strip("|").split("|")]
            if len(row_cols) >= 2:
                rows.append(row_cols)
            j += 1
        return rows
    raise ValueError("target table not found")


_BT = re.compile(r"^`([^`]+)`$")


def unbacktick(cell: str) -> str:
    m = _BT.match(cell)
    if not m:
        raise ValueError(f"expected backticked token, got: {cell!r}")
    return m.group(1)


def parse_cfg_feature_flags(cfg_md: str) -> set[str]:
    rows = parse_md_table_rows(
        cfg_md,
        lambda c: len(c) >= 2 and c[0].lower() == "flag value" and c[1].lower() == "meaning",
    )
    flags: set[str] = set()
    for r in rows:
        if not r:
            continue
        v = unbacktick(r[0])
        flags.add(v)
    if not flags:
        raise ValueError("no cfg.feature_flags values found in config-toggle-registry")
    return flags


def parse_matrix(matrix_md: str) -> dict[str, tuple[str, str, str, str]]:
    rows = parse_md_table_rows(
        matrix_md,
        lambda c: len(c) >= 6 and c[0].lower() == "flag value" and c[1].startswith("A"),
    )
    out: dict[str, tuple[str, str, str, str]] = {}
    for r in rows:
        if len(r) < 5:
            continue
        k = unbacktick(r[0])
        a, b, c, d = (r[1].strip().lower(), r[2].strip().lower(), r[3].strip().lower(), r[4].strip().lower())
        out[k] = (a, b, c, d)
    if not out:
        raise ValueError("no rows found in profile feature-flag defaults matrix")
    return out


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def main() -> int:
    root = repo_root()
    cfg_path = root / CFG_REG
    mat_path = root / MATRIX

    cfg_md = read_text(cfg_path)
    mat_md = read_text(mat_path)

    cfg_flags = parse_cfg_feature_flags(cfg_md)
    mat = parse_matrix(mat_md)

    allowed_vals = {"on", "off"}
    bad_vals: list[str] = []
    for k, (a, b, c, d) in mat.items():
        for v in (a, b, c, d):
            if v not in allowed_vals:
                bad_vals.append(f"{k}: {v!r}")
    if bad_vals:
        die(
            "matrix contains invalid values (allowed: on/off): "
            + ", ".join(bad_vals[:12])
            + (" ..." if len(bad_vals) > 12 else "")
        )

    extra = sorted(set(mat.keys()) - cfg_flags)
    missing = sorted(cfg_flags - set(mat.keys()))
    if extra:
        die("matrix contains flag values not present in config-toggle-registry: " + ", ".join(extra))
    if missing:
        die("matrix missing cfg.feature_flags values from config-toggle-registry: " + ", ".join(missing))

    # Wiring checks (lightweight)
    docs_readme = read_text(root / "docs/README.md")
    if "profile-feature-flag-defaults.md" not in docs_readme:
        die("docs/README.md does not link profile-feature-flag-defaults.md")
    if "profile-feature-flag-defaults.md" not in cfg_md:
        die("config-toggle-registry.md does not reference profile-feature-flag-defaults.md for default guidance")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ValueError as e:
        die(str(e))
