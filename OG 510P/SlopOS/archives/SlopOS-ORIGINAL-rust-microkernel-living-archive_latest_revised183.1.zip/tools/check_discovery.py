#!/usr/bin/env python3
"""Discovery-surface checks (LLM amnesia resistors).

Goal: prevent "orphan" control docs and unindexed ADR/RFCs.
This stays intentionally conservative: it enforces only stable, low-noise invariants.

Checks:
- Every ADR file is listed in adrs/README.md index.
- Every RFC file is listed in rfcs/README.md index.
- The must-read set in docs/00-meta/llm-runbook.md exists and is referenced from docs/README.md
  (excluding repo-level README.md and docs/README.md themselves).
- The trajectory map retains all four profile headings (prevents silent "fork-by-omission").
- The ACP kind registry exists and is discoverable (prevents CH-ACP kind drift).
- If CH-EFFCON/D-CAPSHELL artifacts exist, they must be discoverable (prevents workflow authority drift).
- If CH-EFFCON/CH-ARGV (D-CAPSHELL) artifacts exist, they must be discoverable (prevents workflow authority drift).
- If CH-ENV (D-CAPSHELL) artifacts exist, they must be discoverable (prevents ambient env drift in workflows).
- If CH-CWD (D-CAPSHELL) artifacts exist, they must be discoverable (prevents ambient cwd drift in workflows).
- If CH-STDIO (D-CAPSHELL) artifacts exist, they must be discoverable (prevents ambient stdio/TTY drift in workflows).
- If CH-FDSET (D-CAPSHELL) artifacts exist, they must be discoverable (prevents ambient handle/FD table drift in workflows).
- If CH-TIMEPROOF/CH-TIMEREQ (D-TIMEPROOF) artifacts exist, they must be discoverable (prevents timeproof drift into orphan docs).
- If the CH-CFG toggle registry exists, it must be discoverable (prevents silent toggle drift).
- If CH-FADAPT (Foreign Cell adapter receipts) exists, it must be discoverable (prevents sealed-compat interop drift).
- If CH-DENY (deterministic denial receipts) exists, it must be discoverable (prevents workflow/policy deny drift).
- If the deny-code registry exists, it must be discoverable (prevents deny semantics drift).
- CHANGELOG top entry matches the latest revision tag format.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path

RE_BULLET_PATH = re.compile(r"^\s*-\s+`([^`]+)`\s*$")
RE_REVISION = re.compile(r"^##\s+(Revised\d+)\s+\((\d{4}-\d{2}-\d{2})\)\s*$")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[discovery] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[discovery] OK: {msg}")


def list_numbered_md(dir_path: Path) -> list[Path]:
    return sorted(dir_path.glob("[0-9][0-9][0-9][0-9]-*.md"))


def check_index_complete(kind: str, dir_name: str) -> None:
    root = repo_root()
    idx = root / dir_name / "README.md"
    if not idx.exists():
        fail(f"missing {dir_name}/README.md (required index)")
    idx_txt = read(idx)

    missing: list[str] = []
    for p in list_numbered_md(root / dir_name):
        if p.name == "README.md":
            continue
        # Skip non-entries like templates.
        if p.name.startswith("0000-") or "template" in p.name:
            continue
        # Conservative: require filename to appear in README (link or plain text).
        if p.name not in idx_txt:
            missing.append(p.name)

    if missing:
        fail(f"{kind} index missing {len(missing)} file(s): {', '.join(missing)}")
    ok(f"{kind} index includes all {len(list_numbered_md(root/dir_name))} items")


def extract_must_read_paths(runbook_txt: str) -> list[str]:
    # Find the must-read section block.
    start = runbook_txt.find("## Must-read set")
    if start < 0:
        fail("docs/00-meta/llm-runbook.md missing '## Must-read set' section")
    # Take until next '## ' heading.
    end = runbook_txt.find("\n## ", start + 5)
    if end < 0:
        end = len(runbook_txt)
    block = runbook_txt[start:end]
    paths: list[str] = []
    for line in block.splitlines():
        m = RE_BULLET_PATH.match(line)
        if m:
            paths.append(m.group(1))
    if not paths:
        fail("must-read set is empty or not in backtick bullet format")
    return paths


def check_must_read_exists_and_discoverable() -> None:
    root = repo_root()
    runbook = root / "docs/00-meta/llm-runbook.md"
    docs_readme = root / "docs/README.md"
    if not runbook.exists():
        fail("missing docs/00-meta/llm-runbook.md")
    if not docs_readme.exists():
        fail("missing docs/README.md")

    rb = read(runbook)
    must = extract_must_read_paths(rb)

    # Minimal amnesia resistor: keep core diff/evidence surfaces pinned in the must-read set.
    # (If these drift out of the must-read list, future edits tend to lose coherence.)
    required = [
        "docs/00-meta/bibliography.md",
        "docs/00-meta/evidence-index.md",
    ]
    missing = [p for p in required if p not in must]
    if missing:
        fail(f"must-read set missing required stable surfaces: {', '.join(missing)}")

    dr = read(docs_readme)

    for rel in must:
        p = root / rel
        if not p.exists():
            fail(f"must-read path missing from repo: {rel}")
        # Skip requiring docs/README to link to itself or to repo root README.
        if rel in ("README.md", "docs/README.md"):
            continue
        # Conservative discoverability: require the relative path string to appear in docs/README.md.
        if rel.replace("docs/", "") in dr or rel in dr:
            continue
        fail(f"docs/README.md does not reference must-read doc: {rel}")

    ok(f"must-read set exists and is referenced from docs/README.md ({len(must)} items)")


def check_changelog_top_entry() -> None:
    root = repo_root()
    ch = root / "CHANGELOG.md"
    if not ch.exists():
        fail("missing CHANGELOG.md")
    lines = read(ch).splitlines()
    # Find first '## Revised..' line.
    for line in lines:
        m = RE_REVISION.match(line.strip())
        if m:
            ok(f"CHANGELOG top entry: {m.group(1)} ({m.group(2)})")
            return
        if line.startswith("## "):
            # first header but not matching format
            break
    fail("CHANGELOG.md missing a top entry line like '## RevisedNN (YYYY-MM-DD)'")


def check_trajectory_profiles_present() -> None:
    """Ensure the canonical trajectory map keeps all four product shapes visible."""
    root = repo_root()
    traj = root / "docs/00-meta/trajectory-map.md"
    if not traj.exists():
        fail("missing docs/00-meta/trajectory-map.md")
    txt = read(traj)

    required = [
        "### Workstation profile",
        "### Cloud substrate profile",
        "### Embedded / separation profile",
        "### Agent/automation profile",
    ]
    missing = [h for h in required if h not in txt]
    if missing:
        fail(f"trajectory map missing required profile heading(s): {', '.join(missing)}")
    ok("trajectory map retains all four profile headings")


def check_acp_kind_registry_discoverable() -> None:
    """Ensure the ACP kind registry exists and is discoverable from indexes."""
    root = repo_root()
    reg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    if not reg.exists():
        fail("missing docs/70-llm-control/acp-action-kind-registry.md")

    docs_readme = root / "docs/README.md"
    llm_readme = root / "docs/70-llm-control/README.md"
    if not docs_readme.exists() or not llm_readme.exists():
        fail("missing docs/README.md or docs/70-llm-control/README.md")

    dr = read(docs_readme)
    lr = read(llm_readme)
    if "70-llm-control/acp-action-kind-registry.md" not in dr and "acp-action-kind-registry.md" not in dr:
        fail("docs/README.md does not reference the ACP kind registry")
    if "acp-action-kind-registry.md" not in lr:
        fail("docs/70-llm-control/README.md does not reference the ACP kind registry")

    ok("ACP kind registry exists and is referenced from docs indexes")


def check_effcon_discoverable_if_present() -> None:
    """If effect-contract artifacts exist, ensure they are indexed.

    Rationale: workflow-glue is a frequent ambient-authority leak. If we add CH-EFFCON/D-CAPSHELL,
    it must stay visible from stable discovery surfaces.
    """
    root = repo_root()
    eff = root / "docs/30-architecture/effect-contract-schema-v0.md"
    if not eff.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/effect-contract-schema-v0.md" not in dr and "effect-contract-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-EFFCON effect-contract schema")

    ok("CH-EFFCON effect-contract schema exists and is referenced from docs/README.md")


def check_argv_discoverable_if_present() -> None:
    """If CH-ARGV exists, ensure it is indexed.

    Rationale: typed argv tokens are a workflow authority seam; if the schema exists but is not discoverable,
    edits drift back into ambient paths/env as “permissions”.
    """
    root = repo_root()
    argv = root / "docs/30-architecture/argv-schema-v0.md"
    if not argv.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/argv-schema-v0.md" not in dr and "argv-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-ARGV argv schema")

    ok("CH-ARGV argv schema exists and is referenced from docs/README.md")


def check_env_discoverable_if_present() -> None:
    """If CH-ENV exists, ensure it is indexed.

    Rationale: process environments are a classic ambient-authority seam (PATH/LD_* / proxies).
    If we add CH-ENV to make workflow env explicit and bindable, it must remain discoverable
    from stable review surfaces.
    """
    root = repo_root()
    env = root / "docs/30-architecture/env-schema-v0.md"
    if not env.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/env-schema-v0.md" not in dr and "env-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-ENV env schema")

    ok("CH-ENV env schema exists and is referenced from docs/README.md")

def check_cwd_discoverable_if_present() -> None:
    """If CH-CWD exists, ensure it is indexed.

    Rationale: current working directory inheritance is a classic ambient-authority seam.
    If we add CH-CWD to make cwd explicit and bindable for D-CAPSHELL, it must remain
    discoverable from stable review surfaces.
    """
    root = repo_root()
    cwd = root / "docs/30-architecture/cwd-schema-v0.md"
    if not cwd.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/cwd-schema-v0.md" not in dr and "cwd-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-CWD cwd schema")

    ok("CH-CWD cwd schema exists and is referenced from docs/README.md")


def check_stdio_discoverable_if_present() -> None:
    """If CH-STDIO exists, ensure it is indexed.

    Rationale: inherited stdio/TTY is a classic ambient-authority seam.
    If we add CH-STDIO to make stdio explicit and bindable for D-CAPSHELL,
    it must remain discoverable from stable review surfaces.
    """
    root = repo_root()
    stdio = root / "docs/30-architecture/stdio-schema-v0.md"
    if not stdio.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/stdio-schema-v0.md" not in dr and "stdio-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-STDIO stdio schema")

    ok("CH-STDIO stdio schema exists and is referenced from docs/README.md")



def check_fdset_discoverable_if_present() -> None:
    """If CH-FDSET exists, ensure it is indexed.

    Rationale: inherited handle/FD tables are a classic ambient-authority seam.
    If we add CH-FDSET to make extra child handle bindings explicit and bindable for D-CAPSHELL,
    it must remain discoverable from stable review surfaces.
    """
    root = repo_root()
    fdset = root / "docs/30-architecture/fdset-schema-v0.md"
    if not fdset.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/fdset-schema-v0.md" not in dr and "fdset-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-FDSET fdset schema")

    ok("CH-FDSET fdset schema exists and is referenced from docs/README.md")



def check_cfg_toggle_registry_discoverable_if_present() -> None:
    """If the CH-CFG toggle registry exists, ensure it is indexed.

    Rationale: CH-CFG claims a closed set of keys/flags. If the toggle registry exists but is not discoverable,
    reviewers and future LLM edits drift into implicit toggles.
    """
    root = repo_root()
    reg = root / "docs/30-architecture/config-toggle-registry.md"
    if not reg.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/config-toggle-registry.md" not in dr and "config-toggle-registry.md" not in dr:
        fail("docs/README.md does not reference CH-CFG toggle registry")

    ok("CH-CFG toggle registry exists and is referenced from docs/README.md")


def check_deny_discoverable_if_present() -> None:
    """If the CH-DENY schema exists, ensure it is indexed.

    Rationale: fail-closed denials are a frequent drift seam ("why did it deny?" becomes ad-hoc).
    If we add CH-DENY, it must stay visible from stable discovery surfaces.
    """
    root = repo_root()
    deny = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    if not deny.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")
    dr = read(docs_readme)
    if "30-architecture/denial-receipt-schema-v0.md" not in dr and "denial-receipt-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-DENY denial receipt schema")
    ok("CH-DENY denial receipt schema exists and is referenced from docs/README.md")




def check_notif_discoverable_if_present() -> None:
    """If CH-NOTIF exists, ensure it is indexed from docs/README.md.

    Rationale: attention/notification seams are a high-leverage workflow surface. If we pin
    CH-NOTIF as the bounded request contract for D-ATTN, it must remain discoverable from
    stable indexes so edits do not drift back into ad-hoc notification APIs.
    """
    root = repo_root()
    notif = root / "docs/30-architecture/notification-request-schema-v0.md"
    if not notif.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/notification-request-schema-v0.md" not in dr and "notification-request-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-NOTIF notification request schema")

    ok("CH-NOTIF notification schema exists and is referenced from docs indexes")


def check_deny_code_registry_discoverable_if_present() -> None:
    """If the deny-code registry exists, ensure it is indexed and referenced.

    Rationale: deny semantics are a high-leverage drift seam. If we factor deny_code closure
    into a registry, it must remain visible from stable discovery surfaces and referenced
    from CH-DENY.
    """
    root = repo_root()
    reg = root / "docs/30-architecture/deny-code-registry.md"
    if not reg.exists():
        return

    docs_readme = root / "docs/README.md"
    deny_schema = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/deny-code-registry.md" not in dr and "deny-code-registry.md" not in dr:
        fail("docs/README.md does not reference deny-code-registry.md")

    if deny_schema.exists():
        ds = read(deny_schema)
        if "deny-code-registry.md" not in ds:
            fail("denial-receipt-schema-v0.md should reference deny-code-registry.md when the registry exists")

    ok("deny-code registry exists and is referenced from docs indexes + CH-DENY")




def check_timeproof_discoverable_if_present() -> None:
    """If timeproof artifacts exist, ensure they are indexed.

    Rationale: authenticated time is a security-adjacent seam (expiry/anti-rollback). If we add CH-TIMEPROOF and
    CH-TIMEREQ as stable evidence/request artifacts, they must remain visible from stable discovery surfaces so
    future edits cannot silently drift into ambient time assumptions.
    """
    root = repo_root()
    tp = root / "docs/30-architecture/time-proof-schema-v0.md"
    tr = root / "docs/30-architecture/timeproof-request-schema-v0.md"
    if not tp.exists() and not tr.exists():
        return

    docs_readme = root / "docs/README.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")
    dr = read(docs_readme)

    if tp.exists():
        if "30-architecture/time-proof-schema-v0.md" not in dr and "time-proof-schema-v0.md" not in dr:
            fail("docs/README.md does not reference CH-TIMEPROOF time-proof schema")
    if tr.exists():
        if "30-architecture/timeproof-request-schema-v0.md" not in dr and "timeproof-request-schema-v0.md" not in dr:
            fail("docs/README.md does not reference CH-TIMEREQ timeproof-request schema")

    ok("CH-TIMEPROOF/CH-TIMEREQ artifacts are referenced from docs/README.md")

def check_fadapt_discoverable_if_present() -> None:
    """If the Foreign Cell adapter-receipt schema exists, ensure it is indexed.

    Rationale: sealed compat must remain portal/intent/receipt-shaped. If we add CH-FADAPT as the
    per-adapter receipt seam, it must stay visible from stable discovery surfaces so it cannot drift
    into an orphan doc or be silently removed from review paths.
    """
    root = repo_root()
    fad = root / "docs/30-architecture/fcell-adapter-receipt-schema-v0.md"
    if not fad.exists():
        return

    docs_readme = root / "docs/README.md"
    fcell_contract = root / "docs/30-architecture/foreign-cell-contract.md"
    if not docs_readme.exists():
        fail("missing docs/README.md")

    dr = read(docs_readme)
    if "30-architecture/fcell-adapter-receipt-schema-v0.md" not in dr and "fcell-adapter-receipt-schema-v0.md" not in dr:
        fail("docs/README.md does not reference CH-FADAPT adapter-receipt schema")

    if fcell_contract.exists():
        fc = read(fcell_contract)
        if "CH-FADAPT" not in fc and "fcell-adapter-receipt" not in fc:
            fail("foreign-cell-contract.md should reference CH-FADAPT (adapter receipts) when the schema exists")

    ok("CH-FADAPT adapter-receipt schema exists and is referenced from docs indexes")

def main() -> None:
    check_index_complete("ADR", "adrs")
    check_index_complete("RFC", "rfcs")
    check_must_read_exists_and_discoverable()
    check_trajectory_profiles_present()
    check_acp_kind_registry_discoverable()
    check_effcon_discoverable_if_present()
    check_argv_discoverable_if_present()
    check_env_discoverable_if_present()
    check_cwd_discoverable_if_present()
    check_stdio_discoverable_if_present()
    check_fdset_discoverable_if_present()
    check_cfg_toggle_registry_discoverable_if_present()
    check_deny_discoverable_if_present()
    check_notif_discoverable_if_present()
    check_timeproof_discoverable_if_present()
    check_deny_code_registry_discoverable_if_present()
    check_fadapt_discoverable_if_present()
    check_changelog_top_entry()
    print("[discovery] All checks passed.")


if __name__ == "__main__":
    main()
