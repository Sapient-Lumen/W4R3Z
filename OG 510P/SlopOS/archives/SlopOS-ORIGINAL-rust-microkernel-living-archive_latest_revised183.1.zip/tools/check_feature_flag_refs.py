#!/usr/bin/env python3
"""Guardrail: ensure referenced cfg.feature_flags values are registry-closed.

Why this exists
--------------
`cfg.feature_flags` is a high-leverage, high-drift surface:
- it selects optional semantic slices (profiles/extensions),
- it is frequently mentioned in prose docs and threat-model scoping,
- and it must remain a **closed, reviewable** vocabulary.

Implementations must reject unknown feature flags (PO-CFGTOGGLE-VERIFY), but
we also want the *archive* to fail CI when docs drift to reference typo'd or
unregistered flags. Otherwise LLM edits and copy/paste can silently create
"shadow flags" that look real.

This check stays conservative and low-noise:
- It only considers backtick-quoted tokens like `ext.microvm`.
- It ignores placeholders/wildcards (tokens containing '*', '<', '>').
- It scans docs/ only (not RFCs) so exploratory proposals can name tentative
  flags without immediately expanding the closed set.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


RE_FLAG_TOKEN = re.compile(r"`(ext\.[^`\s]+)`")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[flagref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[flagref] OK: {msg}")


def is_placeholder(tok: str) -> bool:
    return ("*" in tok) or ("<" in tok) or (">" in tok)


def load_registry_flags() -> set[str]:
    root = repo_root()
    reg = root / "docs/30-architecture/config-toggle-registry.md"
    if not reg.exists():
        fail("missing docs/30-architecture/config-toggle-registry.md")

    txt = read(reg)
    flags: set[str] = set()
    for m in RE_FLAG_TOKEN.finditer(txt):
        tok = m.group(1)
        if is_placeholder(tok):
            continue
        flags.add(tok)

    if not flags:
        fail("config-toggle-registry.md contains no ext.* feature_flags values")
    return flags


def scan_docs_refs() -> dict[str, list[tuple[str, int]]]:
    """Return {flag: [(relpath, lineno), ...]} for `ext.*` refs in docs/."""
    root = repo_root()
    docs = root / "docs"
    if not docs.exists():
        fail("missing docs/ directory")

    hits: dict[str, list[tuple[str, int]]] = {}
    for p in sorted(docs.rglob("*.md")):
        rel = str(p.relative_to(root))
        for i, line in enumerate(read(p).splitlines(), start=1):
            for m in RE_FLAG_TOKEN.finditer(line):
                tok = m.group(1)
                if is_placeholder(tok):
                    continue
                hits.setdefault(tok, []).append((rel, i))
    return hits


def main() -> None:
    reg = load_registry_flags()
    refs = scan_docs_refs()

    missing = sorted([t for t in refs.keys() if t not in reg])
    if missing:
        lines: list[str] = []
        for t in missing[:50]:
            locs = ", ".join([f"{rp}:{ln}" for rp, ln in refs[t][:3]])
            more = "" if len(refs[t]) <= 3 else f" (+{len(refs[t]) - 3} more)"
            lines.append(f"- {t} @ {locs}{more}")
        extra = "" if len(missing) <= 50 else f" (and {len(missing) - 50} more)"
        fail(
            "docs reference ext.* feature_flags values not present in config-toggle-registry.md"
            + extra
            + "\n"
            + "\n".join(lines)
        )

    ok(f"all referenced ext.* feature_flags values are registry-closed ({len(refs)} unique refs)")


if __name__ == "__main__":
    main()
