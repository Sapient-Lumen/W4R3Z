#!/usr/bin/env python3
"""Evidence EVID-token closure drift gate.

Goal: prevent drift where docs/RFCs/ADRs mention `EVID-YYYY-NNN` tokens that
are not defined in docs/00-meta/evidence-index.md.

Why it matters:
- The archive is an authority substrate; evidence hooks are part of the stable
  product surface (schemas + validators + receipts + evidence).
- LLM edits commonly introduce typos or partial EVID keys that silently break
  traceability and weaken proof/evidence structure.
- This gate keeps EVID references mechanically closed over the evidence index.

What it enforces (intentionally simple):
- Every `EVID-YYYY-NNN` token used anywhere in repo markdown (except the evidence
  index itself) must be defined as an entry in the evidence index.
- Evidence index entries must be unique (no duplicate EVID keys).

Token format:
- EVID-<4digit year>-<3digit seq>, e.g. EVID-2026-161

Exit codes:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


# Definition rows in evidence-index look like:
# | EVID-2026-161 | E0 | ... |
RE_EVID_DEF = re.compile(r"^\|\s*(EVID-\d{4}-\d{3})\s*\|")

# EVID tokens as they appear in prose.
# Use custom boundaries: the token begins/ends with digits, so enforce non-alnum
# around it (avoid matching within longer identifiers).
RE_EVID_TOKEN = re.compile(r"(?<![A-Za-z0-9])(EVID-\d{4}-\d{3})(?![A-Za-z0-9])")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="strict")


def fail(msg: str) -> None:
    print(f"[evid-ref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[evid-ref] OK: {msg}")


def load_evidence_defs(evid_path: Path) -> set[str]:
    txt = read(evid_path)
    defs: set[str] = set()
    dups: list[str] = []

    for i, line in enumerate(txt.splitlines(), 1):
        m = RE_EVID_DEF.match(line.strip())
        if not m:
            continue
        key = m.group(1)
        if key in defs:
            dups.append(f"{evid_path.as_posix()}:{i}: {key}")
        defs.add(key)

    if not defs:
        fail("failed to parse any EVID entries from evidence index")
    if dups:
        preview = "\n".join(dups[:40])
        more = "" if len(dups) <= 40 else f"\n… (+{len(dups)-40} more)"
        fail(
            "duplicate EVID keys in evidence index (must be unique)\n"
            f"{preview}{more}"
        )

    return defs


def iter_md_files(root: Path) -> list[Path]:
    return sorted([p for p in root.rglob("*.md") if p.is_file()])


def main() -> None:
    root = repo_root()
    evid_path = root / "docs/00-meta/evidence-index.md"
    if not evid_path.exists():
        fail("missing docs/00-meta/evidence-index.md")

    defs = load_evidence_defs(evid_path)

    used: set[str] = set()
    offenders: dict[str, set[str]] = {}

    for p in iter_md_files(root):
        if p.resolve() == evid_path.resolve():
            continue
        txt = read(p)
        toks = set(RE_EVID_TOKEN.findall(txt))
        if not toks:
            continue
        used.update(toks)
        missing = toks - defs
        if missing:
            offenders[p.relative_to(root).as_posix()] = missing

    if offenders:
        lines: list[str] = []
        for f in sorted(offenders.keys()):
            miss = sorted(offenders[f])
            lines.append(f"{f}: {', '.join(miss[:12])}{' …' if len(miss) > 12 else ''}")
        preview = "\n".join(lines[:60])
        more = "" if len(lines) <= 60 else f"\n… (+{len(lines)-60} more files)"
        fail(
            "undefined EVID tokens referenced outside evidence index\n"
            f"{preview}{more}\n"
            "Fix: add the missing EVID entry to docs/00-meta/evidence-index.md, "
            "or correct the EVID token in the doc."
        )

    ok(f"all {len(used)} EVID tokens referenced in repo markdown resolve to evidence-index entries")


if __name__ == "__main__":
    main()
