#!/usr/bin/env python3
"""failpoint_validate.py

Tiny validator for CH-FAIL v0 (RFC-0048).

This is intentionally small and format-light: it expects a JSON representation of the
schema described in docs/30-architecture/failpoint-profile-schema-v0.md.

Usage:
  python3 tools/failpoint_validate.py profile.json

Exit codes:
  0 ok
  2 validation errors
"""

from __future__ import annotations

import argparse
import json
import sys

ALLOWED_SCOPES = {"global", "component", "domain"}
ALLOWED_WHEN = {"always", "once", "nth", "every", "range", "prob"}
ALLOWED_EFFECT = {"return_err", "delay", "drop", "stall", "panic"}


def err(msg: str) -> None:
    print(msg, file=sys.stderr)


def get(d: dict, k: str, typ, path: str):
    if k not in d:
        raise ValueError(f"{path}: missing '{k}'")
    v = d[k]
    if not isinstance(v, typ):
        raise ValueError(f"{path}: '{k}' must be {typ.__name__}")
    return v


def validate(profile: dict) -> list[str]:
    problems: list[str] = []

    def add(p: str):
        problems.append(p)

    try:
        schema = get(profile, "schema", str, "profile")
        if schema != "CH-FAIL v0":
            add("profile: schema must be 'CH-FAIL v0'")
    except Exception as e:
        add(str(e))

    try:
        _ = get(profile, "profile_id", str, "profile")
    except Exception as e:
        add(str(e))

    seed = profile.get("seed")
    if seed is not None and not isinstance(seed, int):
        add("profile: 'seed' must be int if present")

    bounds = profile.get("bounds")
    if not isinstance(bounds, dict):
        add("profile: missing or invalid 'bounds' object")
        bounds = {}

    max_rules = bounds.get("max_rules", 256)
    if not isinstance(max_rules, int) or max_rules <= 0 or max_rules > 4096:
        add("bounds.max_rules: must be int in (0,4096]")
        max_rules = 256

    max_delay = bounds.get("max_delay_micros", 5_000_000)
    if not isinstance(max_delay, int) or max_delay < 0 or max_delay > 60_000_000:
        add("bounds.max_delay_micros: must be int in [0,60000000]")
        max_delay = 5_000_000

    rules = profile.get("rules")
    if not isinstance(rules, list):
        add("profile: missing or invalid 'rules' list")
        rules = []

    if len(rules) > max_rules:
        add(f"profile: rules length {len(rules)} exceeds bounds.max_rules {max_rules}")

    uses_prob = False

    for i, r in enumerate(rules):
        pfx = f"rules[{i}]"
        if not isinstance(r, dict):
            add(f"{pfx}: must be object")
            continue

        try:
            rid = get(r, "id", str, pfx)
            if not rid or len(rid) > 128:
                add(f"{pfx}.id: must be non-empty and <=128 chars")
        except Exception as e:
            add(str(e))

        scope = r.get("scope")
        if not isinstance(scope, dict):
            add(f"{pfx}.scope: must be object")
            scope = {}
        sk = scope.get("kind")
        if sk not in ALLOWED_SCOPES:
            add(f"{pfx}.scope.kind: must be one of {sorted(ALLOWED_SCOPES)}")
        if sk == "component" and not isinstance(scope.get("component_id"), str):
            add(f"{pfx}.scope.component_id: required string")
        if sk == "domain" and not isinstance(scope.get("domain_tag"), str):
            add(f"{pfx}.scope.domain_tag: required string")

        when = r.get("when")
        if not isinstance(when, dict):
            add(f"{pfx}.when: must be object")
            when = {}
        wk = when.get("kind")
        if wk not in ALLOWED_WHEN:
            add(f"{pfx}.when.kind: must be one of {sorted(ALLOWED_WHEN)}")
        if wk == "nth":
            n = when.get("n")
            if not isinstance(n, int) or n <= 0 or n > 1_000_000:
                add(f"{pfx}.when.n: must be int in (0,1e6]")
        if wk == "every":
            k = when.get("k")
            if not isinstance(k, int) or k <= 0 or k > 1_000_000:
                add(f"{pfx}.when.k: must be int in (0,1e6]")
        if wk == "range":
            s = when.get("start")
            e = when.get("end")
            if not isinstance(s, int) or not isinstance(e, int) or s < 0 or e < s or e > 1_000_000:
                add(f"{pfx}.when.range: start/end must be ints with 0<=start<=end<=1e6")
        if wk == "prob":
            uses_prob = True
            pnum = when.get("p_num")
            pden = when.get("p_den")
            stream = when.get("stream")
            if not isinstance(pnum, int) or not isinstance(pden, int) or pden <= 0:
                add(f"{pfx}.when.prob: p_num/p_den must be ints with p_den>0")
            elif pnum < 0 or pnum > pden:
                add(f"{pfx}.when.prob: require 0<=p_num<=p_den")
            if not isinstance(stream, str) or not stream or len(stream) > 64:
                add(f"{pfx}.when.prob.stream: required non-empty string <=64")

        eff = r.get("effect")
        if not isinstance(eff, dict):
            add(f"{pfx}.effect: must be object")
            eff = {}
        ek = eff.get("kind")
        if ek not in ALLOWED_EFFECT:
            add(f"{pfx}.effect.kind: must be one of {sorted(ALLOWED_EFFECT)}")
        if ek == "return_err":
            code = eff.get("code")
            if not isinstance(code, str) or not code or len(code) > 64:
                add(f"{pfx}.effect.code: required string <=64")
        if ek in ("delay", "stall"):
            micros = eff.get("micros")
            if not isinstance(micros, int) or micros < 0 or micros > max_delay:
                add(f"{pfx}.effect.micros: must be int in [0,{max_delay}]")
        if ek == "panic":
            reason = eff.get("reason_tag")
            if not isinstance(reason, str) or not reason or len(reason) > 64:
                add(f"{pfx}.effect.reason_tag: required string <=64")

    if uses_prob and seed is None:
        add("profile: 'seed' is required when any rule uses when.kind='prob'")

    return problems


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("profile", help="Path to CH-FAIL JSON profile")
    args = ap.parse_args()

    try:
        with open(args.profile, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except Exception as e:
        err(f"failed to read JSON: {e}")
        return 2

    if not isinstance(obj, dict):
        err("profile must be a JSON object")
        return 2

    problems = validate(obj)
    if problems:
        for p in problems:
            err(p)
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
