#!/usr/bin/env python3
"""
unsafe_scan.py — tiny, auditable “unsafe budget” gate (RFC-0043).

Usage:
  python tools/unsafe_scan.py --root <path> --allowlist <allowlist.txt>

Rules (intentionally simple):
- Any Rust file under --root is scanned for the token `unsafe`.
- Matches are ignored when inside comments/strings? (not attempted; this is a rough gate).
- For each match, we require:
  - the file path is allowlisted, AND
  - the line contains a `U-` identifier (e.g., `// U-0123: ...`).

This is a *starter* tool: keep it small and deterministic, then replace with
a more robust parser-based gate when needed.
"""
import argparse
import pathlib
import re
import sys

UNSAFE_RE = re.compile(r"\bunsafe\b")
UID_RE = re.compile(r"\bU-\d{4}\b")

def load_allowlist(p: pathlib.Path) -> set[str]:
    s = set()
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        s.add(line)
    return s

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="Root directory to scan")
    ap.add_argument("--allowlist", required=True, help="Text file of allowlisted relative paths")
    args = ap.parse_args()

    root = pathlib.Path(args.root).resolve()
    allow = load_allowlist(pathlib.Path(args.allowlist).resolve())

    problems = []
    for p in root.rglob("*.rs"):
        rel = str(p.resolve().relative_to(root))
        for i, line in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), start=1):
            if not UNSAFE_RE.search(line):
                continue
            if rel not in allow:
                problems.append((rel, i, "unsafe outside allowlist"))
                continue
            if not UID_RE.search(line):
                problems.append((rel, i, "unsafe missing U-ID"))
                continue

    if problems:
        for rel, ln, msg in problems:
            print(f"{rel}:{ln}: {msg}", file=sys.stderr)
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
