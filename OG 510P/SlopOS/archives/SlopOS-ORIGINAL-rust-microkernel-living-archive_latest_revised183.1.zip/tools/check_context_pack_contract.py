#!/usr/bin/env python3
"""CI drift gate: ensure the generated context pack remains an amnesia-resistant prompt surface.

Why this exists
--------------
`tools/gen_context_pack.py` is the canonical "continuation prompt" generator for this archive.
If its output silently drifts (missing profile matrix, missing open questions, missing must-read set,
or mismatched revision tags), LLM/human edits become more error-prone and the archive tends to lose
coherence.

This guardrail is intentionally conservative and low-noise:
- It generates a context pack into the ignored `out/` directory.
- It checks for the presence of required sections and the four profile headings.
- It verifies the header revision/date matches the top CHANGELOG entry.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

RE_REVISION = re.compile(r"^##\s+(Revised\d+)\s+\((\d{4}-\d{2}-\d{2})\)\s*$")
RE_CTX_HDR = re.compile(r"^#\s+Context pack\s+—\s+(Revised\d+)\s+\((\d{4}-\d{2}-\d{2})\)\s*$")


def fail(msg: str) -> None:
    print(f"[ctxpack] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[ctxpack] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def parse_changelog_top() -> tuple[str, str]:
    ch = ROOT / "CHANGELOG.md"
    if not ch.exists():
        fail("missing CHANGELOG.md")
    for line in read(ch).splitlines():
        m = RE_REVISION.match(line.strip())
        if m:
            return m.group(1), m.group(2)
        if line.startswith("## "):
            break
    fail("CHANGELOG.md missing a top entry line like '## RevisedNN (YYYY-MM-DD)'")
    raise AssertionError


def generate_context_pack(out_rel: str) -> Path:
    gen = ROOT / "tools" / "gen_context_pack.py"
    if not gen.exists():
        fail("missing tools/gen_context_pack.py")

    out_path = ROOT / out_rel
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Run generator deterministically.
    try:
        subprocess.run(
            ["python3", str(gen), "--out", out_rel],
            cwd=str(ROOT),
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        fail(
            "gen_context_pack.py failed: "
            + (e.stderr.strip() or e.stdout.strip() or "(no output)")
        )

    if not out_path.exists():
        fail(f"context pack not generated at expected path: {out_rel}")
    return out_path


def require_substring(txt: str, needle: str) -> None:
    if needle not in txt:
        fail(f"context pack missing required section/content: {needle!r}")


def main() -> None:
    rev, date = parse_changelog_top()

    out_path = generate_context_pack("out/_ci_context_pack.md")
    txt = read(out_path)

    # Header must match changelog (keeps prompts aligned to the archive's source of truth).
    first = txt.splitlines()[0].strip() if txt.strip() else ""
    m = RE_CTX_HDR.match(first)
    if not m:
        fail("context pack first line must be like '# Context pack — RevisedNN (YYYY-MM-DD)'")
    if (m.group(1), m.group(2)) != (rev, date):
        fail(
            f"context pack header revision/date {m.group(1)} ({m.group(2)}) does not match CHANGELOG top entry {rev} ({date})"
        )

    # Required sections.
    require_substring(txt, "## Non-negotiables")
    require_substring(txt, "## Must-read set")
    require_substring(txt, "## Profile matrix")
    require_substring(txt, "## Commands")
    require_substring(txt, "- `make lint`")
    require_substring(txt, "- `make context-pack`")

    # Profile table must include the four shapes.
    for prof in [
        "Workstation profile",
        "Cloud substrate profile",
        "Embedded / separation profile",
        "Agent/automation profile",
    ]:
        if prof not in txt:
            fail(f"context pack profile matrix missing profile row: {prof}")

    # Open questions are a critical drift-control surface; require at least one bullet if the heading exists.
    if "## Open questions" not in txt:
        fail("context pack missing '## Open questions' section")
    # Conservative parse: require a bullet within 20 lines after the heading.
    lines = txt.splitlines()
    idx = next((i for i, ln in enumerate(lines) if ln.startswith("## Open questions")), -1)
    if idx < 0:
        fail("context pack missing open questions heading")
    window = lines[idx + 1 : idx + 21]
    if not any(ln.strip().startswith("- ") for ln in window):
        fail("context pack open questions section appears empty")

    ok("context pack contract holds (header, required sections, four profiles, open questions)")


if __name__ == "__main__":
    main()
