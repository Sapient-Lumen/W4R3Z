# Tools

These scripts are intentionally tiny and auditable.

- `lint_archive.py`: repository lint gates adopted by ADR-0001 (run via `make lint`).
- `check_discovery.py`: discovery-surface drift gate (ADR/RFC indexes complete; must-read set exists + is indexed; keeps profile headings and key registries discoverable).
- `check_decision_map_refs.py`: drift gate that keeps D-* decision references closed: any D-* token referenced in docs/ must have a corresponding entry in `docs/30-architecture/decision-map.md` (prevents decision/evidence surfaces from drifting into orphan identifiers).
- `check_assurance_token_refs.py`: drift gate that keeps assurance identifiers registry-closed: any A-*/C-*/I-*/PO-* token referenced in repo markdown must be defined in the corresponding canonical registry (assumption/claim/invariant/proof-obligation registries). Prevents typo'd or orphan assurance IDs from breaking traceability.
- `check_interface_registry_refs.py`: drift gate that keeps privileged interface identifiers registry-closed: any IF-* token referenced in repo markdown must be present in `docs/30-architecture/interface-registry.md` (prevents "shadow IF-IDs" and keeps privileged-surface discovery stable; supports I-IF-1).
- `check_portal_wiring.py`: drift gate that keeps the closed `portal.*` token set coherent across portal families, CH-PLEDGE, Foreign Cell allowlists, **and the complete set of `cfg.params.lane.portal.*` kill switches** (prevents ambient enablement drift).
- `check_pledge_token_mapping.py`: drift gate that keeps the CH-PLEDGE promise-token vocabulary coherent by enforcing that `pledge-token-mapping.md` covers the closed CH-PLEDGE v0 token set from `pledge-contract-schema-v0.md` exactly (no missing/extra/duplicate tokens).
- `check_portal_token_refs.py`: drift gate that rejects `docs/` references to backticked `portal.*` tokens unless their root family is present in `docs/30-architecture/portal-family-registry.md` (prevents unreviewed portal seams and workflow authority drift).
- `check_workflow_descallow.py`: drift gate that pins CH-ARGV/CH-ENV `desc_schema` references to the CH-EFFCON effect-bound allowlist (prevents workflow authority drift via schema-name widening).
- `check_intent_kind_registry.py`: drift gate that keeps the workflow `intent.kind` vocabulary single-source and closed. Treats `docs/30-architecture/intent-kind-registry.md` as the canonical kind list; rejects any local enum bullet lists near `intent.kind` closed-enum mentions; requires plumbing schema docs (CH-PLUMBMSG/CH-ROUTE) to reference the canonical registry (prevents typo’d intents and shadow enums that can reintroduce ambient workflow authority).
- `check_plumbmsg_schema_formality.py`: drift gate that keeps CH-PLUMBMSG v0 schema documentation formal (not “informal”), bounded, and wired to the canonical intent-kind registry + PO/I anchors (prevents workflow plumbing drift into prose-only, amnesia-prone surfaces).
- `check_iolease_schema_formality.py`: drift gate that keeps CH-IOLEASE v0 schema documentation formal (not “informal”), bounded, and wired to the canonical PO/I anchors (prevents device lease descriptor drift into prose-only surfaces that weaken D-IOLEASE auditability).
- `check_acp_kindmeta.py`: drift gate that keeps the ACP kind registry table mechanically coherent (closed kind set metadata; conflict-key families must exist; ordered stances must require CH-ORDERTOK; profile-gated kinds must reference existing lane kill switches).
- `check_acp_kind_lane_gates.py`: drift gate that keeps lane-gated ACP kinds reviewable: any `portal.*` / `capshell.exec` / `fcell.*` kind row must explicitly name its required `cfg.params.lane.*` kill switch in the Profiles cell, and the key must exist in the config-toggle registry + profile lane defaults (prevents “lane-gated but unnamed” drift that weakens policy-kill auditability).
- `check_acp_commutativity_predicates.py`: drift gate that keeps D-COMMUTE predicates explicit for every CH-ACP kind by enforcing closure and required anchors in `docs/70-llm-control/acp-commutativity-predicate-registry.md` (prevents planner-unsafe commutativity drift and keeps swap-order testing targets well-specified).
- `check_retry_dedupe_wiring.py`: drift gate that keeps retry-safety claims implementable: any ACP kind marked *at-least-once-safe* must name an explicit stable dedupe key token (e.g., CH-EFFCON `contract_id`, CH-JOBREQ `job_id`, CH-TIMEREQ `req_id`, CH-NOTIF `.id`), preventing “retry safe” prose drift and duplicate-effect hazards (D-RETRYSAFE).
- `check_acp_serialization_boundary.py`: drift gate that forces every **ordered** ACP kind to specify where serialization lives (`validator` or `svc:<name>`), and forces non-ordered kinds to use `none` (keeps D-COMMUTE and multicore evidence honest; prevents “ordered-but-nowhere” drift).
- `check_acp_serialization_boundary_registry.py`: drift gate that enforces **registry-closure** for ACP serialization boundary tokens: any `svc:<name>` boundary (or `validator`/`none`) used in the ACP kind registry must be present in the closed allowlist pinned in `docs/30-architecture/serialization-boundary-registry.md` (prevents typo’d/implicit service-boundary drift that would weaken D-COMMUTE/Hybrid review surfaces).
- `check_acp_outcome_wiring.py`: drift gate that keeps **CH-ACPOUT v0** (ACP outcome receipts) registered and referenced from ACP control docs + assurance registries (prevents ad-hoc accept/reject outcome drift).
- `check_acp_outcome_effect_status.py`: drift gate that keeps retry/dedupe outcomes distinguishable on the stable receipt surface: CH-ACPOUT v0 includes an optional closed `effect` field and ACP docs/POs explicitly reference `effect="duplicate_suppressed"` for deduped accepts (prevents retry ambiguity drift under D-RETRYSAFE).
- `check_acp_reqctx_wiring.py`: drift gate that keeps ACP request-context wiring coherent: CH-ACP requires `meta.reqctx_digest = digest(CH-REQCTX v1)` and CH-LOG/CH-ACPOUT echo it as a non-authoritative observability field (prevents context correlation drift; preserves veto-only semantics).
- `check_fcell_adapter_registry.py`: drift gate that keeps Foreign Cell `adapter_kind` taxonomy closed and coherently wired across CH-FCELL/CH-FADAPT (v0 and optional v1) + **portal and adapter lane kill switches** (prevents sealed-compat interop drift; keeps reqctx correlation hook discoverable).
- `check_cfg_key_refs.py`: drift gate that rejects docs that reference `cfg.params.*` keys not present in `docs/30-architecture/config-toggle-registry.md` (prevents “ambient toggles” / unreviewable lane gates).
- `check_feature_flag_refs.py`: drift gate that rejects docs that reference `cfg.feature_flags` `ext.*` values not present in `docs/30-architecture/config-toggle-registry.md` (prevents typo’d/shadow feature flags and keeps profile-extension vocabulary closed).
- `check_deny_code_refs.py`: drift gate that rejects docs/RFCs/ADRs/CHANGELOG examples that name `deny_code` tokens not present in `docs/30-architecture/deny-code-registry.md` (prevents denial vocabulary drift into ad-hoc strings).
- `check_deny_lane_refkey.py`: drift gate that keeps lane/cfg-param kill-switch evidence reviewable: when validators deny due to `cfg.params.*` gating, CH-DENY receipts must bind the registry-closed gate key via `reason.ref_key` for `lane-disabled`/`cfg-deny` (prevents drift into unbound “lane-disabled” denials that hide which kill switch fired).
- `check_deny_ordering_bindings.py`: drift gate that keeps ordering/commutativity rejects reviewable on the stable receipt surface: ordering-related CH-DENY denials (`conflict-key-invalid`, `order-witness-missing`, `order-witness-invalid`) must bind `conflict_key_digest`/`order_digest` (and set `reason.kind="ordering"`) across deny-code registry + CH-DENY producer rules + ACP validator semantics (prevents “ordering failed” drift into ambient/prose-only explanations under D-COMMUTE).
- `check_deny_policy_bindings.py`: drift gate that keeps policy/authority rejects reviewable on the stable receipt surface: policy-related CH-DENY denials (`missing-approval`, `expired-approval`, `policy-deny`) must bind `reason.kind="policy"` and `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)` across deny-code registry + CH-DENY producer rules + ACP validator semantics (prevents “which policy?” from drifting into ambient/log-only explanations).
- `check_no_cfg_policy_bundle_ref.py`: drift gate that rejects stale/ambiguous policy-handle phrasing (forbids references to a non-specified `CH-CFG` `policy_bundle` field and vague “profile-defined policy handle” wording). Keeps policy-handle semantics pinned to the explicit CH-POLICYHANDLE schema surface.
- `check_profile_lane_defaults.py`: drift gate that treats `docs/30-architecture/profile-lane-defaults.md` as a stable diff surface and enforces completeness/closure over the `cfg.params.lane.*` key set (keeps A–D profile defaults coherent without forks).
- `check_profile_feature_flag_defaults.py`: drift gate that treats `docs/30-architecture/profile-feature-flag-defaults.md` as a stable diff surface and enforces completeness/closure over the closed `cfg.feature_flags` value set pinned in `config-toggle-registry.md` (keeps A–D profile extension defaults coherent without forks).
- `check_profile_workflow_defaults.py`: drift gate that treats `docs/30-architecture/profile-workflow-defaults.md` as a stable diff surface and enforces completeness/closure over the `cfg.params.capshell.*` knob set pinned in `config-toggle-registry.md` (keeps workflow hardening knobs profiled and prevents drift back into prose-only “strict profile” suggestions).
- `check_schema_registry_complete.py`: drift gate that ensures every `*-schema-vN.md` spec file (docs/30-architecture and docs/70-llm-control) is listed in `docs/30-architecture/schema-registry.md` (prevents orphan schema specs and keeps the schema registry a closed-world diff surface).
- `check_digest_schema_refs.py`: drift gate that enforces closure for **versioned** schema digest references: any `digest(CH-XYZ vN)` mentioned in docs must refer to a CH-ID/version registered in `docs/30-architecture/schema-registry.md` (prevents schema/version typos from drifting validators/receipts).
- `check_schema_token_refs.py`: drift gate that enforces closure for **versioned** schema token mentions in docs: any `CH-XYZ vN` referenced in prose/examples must refer to a CH-ID/version registered in `docs/30-architecture/schema-registry.md` (catches typos beyond `digest(...)` references).
- `check_bibliography_refs.py`: drift gate that enforces bibliography closure: any `REF-*` token referenced in docs/RFCs/ADRs/CHANGELOG resolves to an entry in `docs/00-meta/bibliography.md` (and each entry carries an explicit URL). Prevents citation typos/partial keys from breaking discovery surfaces.
- `check_evidence_refs.py`: drift gate that enforces evidence-index closure: any `EVID-YYYY-NNN` token referenced in repo markdown must resolve to an entry in `docs/00-meta/evidence-index.md` (unique keys). Prevents evidence-hook typos from breaking traceability surfaces.
- `check_conflictkey_family_registry.py`: drift gate that treats `docs/30-architecture/conflict-key-family-registry.md` as the canonical allowlist for CH-CONFLICTKEY families, enforces schema↔registry closure, and rejects any `family="..."` references that use unknown family tokens (prevents D-COMMUTE/Hybrid drift via typo'd families).

- `check_conflictkey_derivation_registry.py`: drift gate that treats `docs/30-architecture/conflict-key-derivation-registry.md` as the canonical tuple→digest derivation surface for digest-valued conflict-key payload fields (ck_id commitments), and enforces that CH-ORDERTOK uses the same closed family vocabulary as CH-CONFLICTKEY (prevents ordering/commutativity evidence drift via shadow vocabularies or unstated tuple encodings).
- `check_capshell_execpack_reqctx.py`: drift gate that keeps capshell exec-pack v2 wiring coherent: CH-EXECPACK v2 binds `reqctx_digest = digest(CH-REQCTX v1)` and ACP/capshell semantics require `meta.reqctx_digest` to match (prevents implicit workflow correlation/cancel context drift).
- `check_capshell_plumbmsg_req.py`: drift gate that keeps capshell explicit intent-envelope wiring coherent: when `cfg.params.capshell.require_plumbmsg=true`, `capshell.exec` must bind CH-EXECPACK v2 with `plumbmsg_digest = digest(CH-PLUMBMSG v0)` and validators deny missing/invalid envelopes deterministically (prevents workflow intent from drifting into ambient/prose-only channels).
- `check_capshell_budget_reqctx.py`: drift gate that keeps capshell “explicit sponsorship” wiring coherent: when `cfg.params.capshell.require_budget_lease=true` and `cfg.params.lane.metering=true`, `capshell.exec` requires the bound CH-REQCTX v1 to include at least one budget lease digest that resolves/validates as CH-BUDGET v0 (prevents implicit sponsorship drift under D-BUDGET).
- `check_hot_action_wiring.py`: drift gate that keeps the pinned hot-action commutativity surfaces coherent: `hot-action-surface-v0.md` and `hot-action-boundaries-v0.md` must name the same closed family set; each family must retain explicit conflict-key, ordering-token, and replication-contract statements (prevents Hybrid + D-COMMUTE evidence drift).
- `check_guardrail_wiring.py`: drift gate that keeps drift gates alive and discoverable: every `check_*.py` drift gate under `tools/` must be invoked by `make lint`, must exist on disk, and must be mentioned in `tools/README.md` (prevents dead/forgotten guardrails and silent lint degradation).
- `check_context_pack_contract.py`: drift gate that ensures `gen_context_pack.py` output remains an amnesia-resistant prompt surface: header revision/date matches CHANGELOG, required sections exist (non-negotiables, must-read set, profile matrix, open questions), and all four profile rows remain present (prevents context-pack drift that leads to archive amnesia).
- `gen_context_pack.py`: compact continuation-prompt generator (writes `out/context_pack.md`; includes must-read set, profile matrix, open questions, and latest changelog bullets).

Policy: keep tooling minimal; anything that becomes complex should be justified with an RFC/ADR and an evidence entry.

Lint highlights:
- undefined ID references (A-/C-/I-/IF-/CH-/PO-/RFC-/ADR-)
- internal link existence
- inline backticked repo paths must exist (e.g., `docs/...`, `tools/...`)
- RFC/ADR index tables are complete (no missing entries)
- schema registry pointers are valid
- drift gates for authority-substrate coherence (e.g., portal taxonomy closure; conflict-key family + derivation commitments)


## unsafe_scan.py
A tiny “unsafe budget” gate tool (RFC-0043). Scans Rust sources for `unsafe` and enforces an allowlist + U-ID tagging discipline.

## capgraph_diff.py
Tiny diff tool for CH-CAPG snapshots (RFC-0035). Fails if the *new* snapshot introduces unexpected authority edges (with optional allowlist regexes).

Example:

```
python3 tools/capgraph_diff.py before.json after.json
```

## failpoint_validate.py
Tiny validator for CH-FAIL v0 profiles (RFC-0048). Validates a JSON representation of the schema and enforces strict bounds.

## tcap_validate.py
Tiny validator for CH-TCAP v0 descriptors (RFC-0049). Validates a JSON representation of the schema and enforces strict bounds + closed enums.
