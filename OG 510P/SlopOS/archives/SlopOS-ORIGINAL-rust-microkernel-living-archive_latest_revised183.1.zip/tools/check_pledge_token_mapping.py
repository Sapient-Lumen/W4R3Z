#!/usr/bin/env python3
"""CH-PLEDGE token mapping closure drift gate.

Goal
----
Keep the CH-PLEDGE promise-token vocabulary **closed and reviewable** by ensuring
the seed mapping table stays coherent with the schema's closed token set.

Why this exists
--------------
CH-PLEDGE is a high-leverage least-authority seam: it is a *veto-only*
voluntary self-restriction surface that is frequently referenced by tooling and
profiles. If docs drift to add/remove promise tokens in one place but not the
other, reviewers and validators lose a stable meaning surface.

This gate treats:
  - `docs/30-architecture/pledge-contract-schema-v0.md` as the source of truth
    for the closed v0 token list, and
  - `docs/30-architecture/pledge-token-mapping.md` as the required, complete
    mapping table over that token set.

Policy
------
- Missing/extra tokens fail CI.
- Duplicate tokens in either source fail CI.

Design constraints: tiny, deterministic, dependency-free.
"""

from __future__ import annotations

import re
from pathlib import Path


RE_TOKEN_BULLET = re.compile(r"^\s*-\s+`([^`]+)`\s*—")
RE_TABLE_ROW = re.compile(r"^\|\s*`([^`]+)`\s*\|")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[pledge-map] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[pledge-map] OK: {msg}")


def parse_pledge_tokens_v0(txt: str) -> list[str]:
    """Extract the closed v0 token set from pledge-contract-schema-v0.md.

    We intentionally scope parsing to the "v0 token set (closed enum):" block to
    avoid picking up incidental backticks elsewhere.
    """
    lines = txt.splitlines()
    start = None
    for i, ln in enumerate(lines):
        if "v0 token set (closed enum):" in ln:
            start = i
            break
    if start is None:
        fail("pledge-contract-schema-v0.md missing 'v0 token set (closed enum):' marker")

    toks: list[str] = []
    for ln in lines[start + 1 :]:
        s = ln.strip()
        if s.startswith("Notes:") or s.startswith("## ") or s.startswith("### "):
            break
        m = RE_TOKEN_BULLET.match(s)
        if m:
            toks.append(m.group(1).strip())

    if not toks:
        fail("failed to parse any promise tokens from pledge-contract token list")
    return toks


def parse_mapping_tokens(txt: str) -> list[str]:
    """Extract CH-PLEDGE tokens from the first column of the mapping table."""
    toks: list[str] = []
    for ln in txt.splitlines():
        s = ln.strip()
        if not s.startswith("|"):
            continue
        if s.startswith("|---") or s.startswith("| CH-PLEDGE token"):
            continue
        m = RE_TABLE_ROW.match(s)
        if m:
            toks.append(m.group(1).strip())
    if not toks:
        fail("failed to parse any tokens from pledge-token-mapping.md table")
    return toks


def dupes(xs: list[str]) -> list[str]:
    seen: set[str] = set()
    d: set[str] = set()
    for x in xs:
        if x in seen:
            d.add(x)
        seen.add(x)
    return sorted(d)


def main() -> None:
    root = repo_root()
    p_schema = root / "docs/30-architecture/pledge-contract-schema-v0.md"
    p_map = root / "docs/30-architecture/pledge-token-mapping.md"

    if not p_schema.exists():
        fail("missing docs/30-architecture/pledge-contract-schema-v0.md")
    if not p_map.exists():
        fail("missing docs/30-architecture/pledge-token-mapping.md")

    schema_tokens = parse_pledge_tokens_v0(read(p_schema))
    map_tokens = parse_mapping_tokens(read(p_map))

    d1 = dupes(schema_tokens)
    if d1:
        fail("duplicate token(s) in pledge-contract token list: " + ", ".join(d1))
    d2 = dupes(map_tokens)
    if d2:
        fail("duplicate token(s) in pledge mapping table: " + ", ".join(d2))

    sset = set(schema_tokens)
    mset = set(map_tokens)

    missing = sorted([t for t in schema_tokens if t not in mset])
    extra = sorted([t for t in map_tokens if t not in sset])

    if missing or extra:
        lines: list[str] = []
        if missing:
            lines.append("missing from mapping table: " + ", ".join(missing))
        if extra:
            lines.append("extra in mapping table: " + ", ".join(extra))
        fail("pledge token mapping table must cover the closed CH-PLEDGE v0 token set exactly\n" + "\n".join(lines))

    ok(f"pledge token mapping table matches CH-PLEDGE v0 token set ({len(schema_tokens)} token(s))")


if __name__ == "__main__":
    main()
