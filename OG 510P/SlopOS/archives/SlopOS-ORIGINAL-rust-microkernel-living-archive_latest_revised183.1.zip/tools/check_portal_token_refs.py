#!/usr/bin/env python3
"""Guardrail: reject unknown `portal.*` token references in docs/.

Why this exists
--------------
We treat portal families as a **closed, reviewable** workflow authority surface
(`docs/30-architecture/portal-family-registry.md`). The archive already enforces
coherence across the canonical control points (CH-PLEDGE token set, pledge
mapping, Foreign Cell allowlists, lane gates) via `tools/check_portal_wiring.py`.

However, drift often begins in *prose*: a doc introduces a new backticked
`portal.foo` token without updating the canonical registry and wiring. This can
silently weaken:
- least-authority workflow posture (by normalizing an unreviewed portal seam),
- sealed-compat reasoning (by suggesting interop channels that do not exist), and
- validator closure (schemas/receipts depending on a token string must remain
  closed-world).

This check is intentionally conservative and low-noise:
- It only considers backtick-quoted tokens like `portal.file.open` or
  `portal.file.*`.
- It maps any `portal.<family>.*` or `portal.<family>.<sub>` reference to the
  root family token `portal.<family>`.
- It ignores placeholders/wildcards like `portal.*` or tokens containing
  angle-bracket metavariables.
- It scans docs/ only (not RFCs), so exploratory proposals can mention tentative
  portal tokens without immediately expanding the closed set.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


RE_PORTAL_BT = re.compile(r"`(portal\.[^`\s]+)`")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[portalref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[portalref] OK: {msg}")


def is_placeholder(tok: str) -> bool:
    # portal.* is explicitly a placeholder.
    if tok == "portal.*":
        return True
    # Treat metavariables as placeholders.
    return ("<" in tok) or (">" in tok)


def portal_root(tok: str) -> str | None:
    # Strip any trailing punctuation that tends to appear in prose.
    tok = tok.strip().rstrip(".,;:")
    if not tok.startswith("portal."):
        return None
    parts = tok.split(".")
    if len(parts) < 2:
        return None
    # Root is always `portal.<family>`.
    family = parts[1]
    if family == "*":
        return None
    return f"portal.{family}"


def load_canonical_portals() -> set[str]:
    root = repo_root()
    reg = root / "docs/30-architecture/portal-family-registry.md"
    if not reg.exists():
        fail("missing docs/30-architecture/portal-family-registry.md")

    txt = read(reg)

    canonical: set[str] = set()
    for ln in txt.splitlines():
        s = ln.strip()
        if not s.startswith("|"):
            continue
        # Skip header/separator rows.
        if s.startswith("|---") or s.startswith("| Portal family"):
            continue
        if "portal." not in s:
            continue
        parts = [p.strip() for p in s.strip("|").split("|")]
        if len(parts) < 5:
            continue
        tok = parts[4].strip().strip("`").strip()
        if tok.startswith("portal."):
            canonical.add(tok)

    if not canonical:
        fail("portal-family-registry.md yielded no canonical portal tokens")

    return canonical


def scan_docs_portal_refs() -> dict[str, list[tuple[str, int, str]]]:
    """Return {root_token: [(relpath, lineno, original_token), ...]} for refs."""
    root = repo_root()
    docs = root / "docs"
    if not docs.exists():
        fail("missing docs/ directory")

    hits: dict[str, list[tuple[str, int, str]]] = {}
    for p in sorted(docs.rglob("*.md")):
        rel = str(p.relative_to(root))
        for i, line in enumerate(read(p).splitlines(), start=1):
            for m in RE_PORTAL_BT.finditer(line):
                tok = m.group(1)
                if is_placeholder(tok):
                    continue
                root_tok = portal_root(tok)
                if not root_tok:
                    continue
                hits.setdefault(root_tok, []).append((rel, i, tok))
    return hits


def main() -> None:
    canonical = load_canonical_portals()
    refs = scan_docs_portal_refs()

    unknown = sorted([t for t in refs.keys() if t not in canonical])
    if unknown:
        lines: list[str] = []
        for t in unknown[:50]:
            locs = ", ".join([f"{rp}:{ln} ({orig})" for rp, ln, orig in refs[t][:3]])
            more = "" if len(refs[t]) <= 3 else f" (+{len(refs[t]) - 3} more)"
            lines.append(f"- {t} @ {locs}{more}")
        extra = "" if len(unknown) <= 50 else f" (and {len(unknown) - 50} more)"
        fail(
            "docs reference backticked portal.* tokens whose root family is not present in portal-family-registry.md"
            + extra
            + "\n"
            + "\n".join(lines)
        )

    # Count unique *original* tokens for a bit of signal.
    unique_orig = set()
    for locs in refs.values():
        for _, _, orig in locs:
            unique_orig.add(orig.rstrip(".,;:"))

    ok(f"all referenced portal.* tokens map to canonical families ({len(unique_orig)} unique portal token refs)")


if __name__ == "__main__":
    main()
