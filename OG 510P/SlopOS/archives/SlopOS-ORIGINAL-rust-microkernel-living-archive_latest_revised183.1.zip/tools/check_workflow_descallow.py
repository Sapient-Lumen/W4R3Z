#!/usr/bin/env python3
"""Workflow descriptor allowlist drift gate.

Goal:
- Keep CH-ARGV/CH-ENV `desc_schema` references closed-world and effect-bound.
- Treat CH-EFFCON v0 as the source of truth for the effect-kind -> allowed `desc_schema` mapping.

This is intentionally shallow and CI-friendly:
- It does not parse markdown perfectly.
- It enforces only stable, low-noise invariants that reduce LLM drift.

Checks:
1) Every `portal.*` effect kind in CH-EFFCON v0 appears in the mapping table under
   "## Workflow-bound descriptor allowlist (v0)" (even if mapped to none/—).
2) Every mapping-row effect kind is present in the CH-EFFCON effect-kinds closed enum.
3) Every mapped `CH-FOO vN` token exists in docs/30-architecture/schema-registry.md.
4) CH-ARGV and CH-ENV schemas reference the CH-EFFCON allowlist section (prevents
   profile-only, drifting allowlists).

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path

RE_EFFECT_KIND = re.compile(r"^\-\s*`([^`]+)`\s+—", re.M)
RE_TABLE_ROW = re.compile(r"^\|\s*`([^`]+)`\s*\|\s*([^|]+)\|", re.M)
RE_SCHEMA_TOKEN = re.compile(r"`(CH-[A-Z0-9-]+\s+v[0-9]+)`")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[workflow-descallow] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[workflow-descallow] OK: {msg}")


def extract_effect_kinds(eff_txt: str) -> set[str]:
    # Extract from the "Effect kinds (v0; closed enum)" bullet list.
    # Conservative: capture all backticked tokens in that list.
    return set(RE_EFFECT_KIND.findall(eff_txt))


def extract_mapping_rows(eff_txt: str) -> dict[str, set[str]]:
    # Find the mapping section.
    marker = "## Workflow-bound descriptor allowlist (v0)"
    start = eff_txt.find(marker)
    if start < 0:
        fail("CH-EFFCON missing '## Workflow-bound descriptor allowlist (v0)' section")

    block = eff_txt[start:]

    rows: dict[str, set[str]] = {}
    for m in RE_TABLE_ROW.finditer(block):
        kind = m.group(1).strip()
        allowed_col = m.group(2)
        schemas = set(RE_SCHEMA_TOKEN.findall(allowed_col))
        rows[kind] = schemas

    if not rows:
        fail("no mapping table rows parsed from CH-EFFCON allowlist section")

    return rows


def extract_schema_registry_tokens(reg_txt: str) -> set[str]:
    # Registry rows look like: | CH-FOO v0 | ... |
    return set(re.findall(r"\b(CH-[A-Z0-9-]+\s+v[0-9]+)\b", reg_txt))


def main() -> None:
    root = repo_root()

    eff = root / "docs/30-architecture/effect-contract-schema-v0.md"
    reg = root / "docs/30-architecture/schema-registry.md"
    argv = root / "docs/30-architecture/argv-schema-v0.md"
    env = root / "docs/30-architecture/env-schema-v0.md"

    for p in (eff, reg, argv, env):
        if not p.exists():
            fail(f"missing required file: {p}")

    eff_txt = read(eff)
    reg_txt = read(reg)

    effect_kinds = extract_effect_kinds(eff_txt)
    if not effect_kinds:
        fail("could not extract effect kinds from CH-EFFCON")

    rows = extract_mapping_rows(eff_txt)

    # 1) All portal.* kinds must be in rows.
    portal_kinds = sorted([k for k in effect_kinds if k.startswith("portal.")])
    missing_rows = [k for k in portal_kinds if k not in rows]
    if missing_rows:
        fail(f"portal effect kinds missing from allowlist table: {', '.join(missing_rows)}")
    ok(f"allowlist table covers all {len(portal_kinds)} portal.* effect kinds")

    # 2) Every row kind must be a real effect kind.
    extra_rows = sorted([k for k in rows.keys() if k not in effect_kinds])
    if extra_rows:
        fail(f"allowlist table contains kinds not in CH-EFFCON effect enum: {', '.join(extra_rows)}")

    # 3) Every mapped schema token must exist in the schema registry.
    known = extract_schema_registry_tokens(reg_txt)
    unknown_schema_tokens: set[str] = set()
    for kind, schemas in rows.items():
        for s in schemas:
            if s not in known:
                unknown_schema_tokens.add(s)

    if unknown_schema_tokens:
        fail(f"allowlist references schema id(s) not present in schema-registry.md: {', '.join(sorted(unknown_schema_tokens))}")
    ok("all mapped schema ids exist in schema-registry.md")

    # 4) CH-ARGV and CH-ENV must reference this allowlist (prevents profile-only drift).
    argv_txt = read(argv)
    env_txt = read(env)
    required_phrases = ["Workflow-bound descriptor allowlist", "CH-EFFCON"]

    for name, txt in [("CH-ARGV", argv_txt), ("CH-ENV", env_txt)]:
        for phrase in required_phrases:
            if phrase not in txt:
                fail(f"{name} schema does not reference '{phrase}' (must point to CH-EFFCON allowlist)")
    ok("CH-ARGV and CH-ENV reference CH-EFFCON allowlist")


if __name__ == "__main__":
    main()
