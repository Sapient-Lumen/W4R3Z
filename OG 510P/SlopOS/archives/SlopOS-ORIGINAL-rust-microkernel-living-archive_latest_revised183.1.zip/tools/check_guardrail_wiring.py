#!/usr/bin/env python3
"""CI guardrail: ensure drift-gate scripts are wired and discoverable.

Why this exists
--------------
This archive relies on tiny, auditable drift gates (tools/check_*.py) to keep the
authority substrate coherent and LLM-resilient.

Failure modes this prevents:
- A new check script is added but not run by `make lint` (guardrail becomes dead).
- `make lint` references a check script that no longer exists (lint silently
  degrades if a caller ignores errors).
- A check script exists but is not mentioned in tools/README.md, reducing
  discoverability and making edits harder to review.

This check is intentionally conservative:
- It only considers scripts matching tools/check_*.py.
- It requires that each such script is invoked by the `lint:` target.
- It requires that tools/README.md contains a backticked reference to each
  check script filename.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"[toolwire] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[toolwire] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def list_check_scripts() -> list[str]:
    tools = ROOT / "tools"
    if not tools.exists():
        fail("missing tools/ directory")
    return sorted([p.name for p in tools.glob("check_*.py")])


def parse_makefile_lint_calls() -> list[str]:
    mk = ROOT / "Makefile"
    if not mk.exists():
        fail("missing Makefile")
    txt = read(mk)

    # Extract the lint target block.
    m = re.search(r"^lint:\n(?P<body>(?:\t.*\n)+)", txt, flags=re.MULTILINE)
    if not m:
        fail("could not locate lint target in Makefile")
    body = m.group("body")

    calls = re.findall(r"python3\s+tools/(check_[^\s]+\.py)", body)
    return sorted(set(calls))


def main() -> None:
    checks = list_check_scripts()
    called = parse_makefile_lint_calls()

    missing = [c for c in checks if c not in called]
    extra = [c for c in called if c not in checks]

    if missing:
        fail(
            "check scripts present in tools/ but not invoked by `make lint`: "
            + ", ".join(missing)
        )
    if extra:
        fail(
            "Makefile lint target references missing check scripts: "
            + ", ".join(extra)
        )

    # Discoverability: ensure tools/README.md mentions each check script.
    readme = ROOT / "tools" / "README.md"
    if not readme.exists():
        fail("missing tools/README.md")
    txt = read(readme)
    missing_doc = [c for c in checks if f"`{c}`" not in txt]
    if missing_doc:
        fail(
            "check scripts not mentioned in tools/README.md: "
            + ", ".join(missing_doc)
        )

    ok(f"all {len(checks)} check scripts are wired in Makefile lint target and documented")


if __name__ == "__main__":
    main()
