#!/usr/bin/env python3
"""CI drift gate: ensure lane/cfg denials bind the firing cfg.params key.

Why this exists
--------------
Lane kill switches and workflow posture knobs are high-leverage authority seams.
If denials drift to a bare `lane-disabled` token without binding *which* gate
fired, we lose reviewability and make it easier for ambient authority to creep
in through undocumented toggles.

This check keeps the archive mechanically explicit:
- `deny-code-registry.md` must require `reason.ref_key` bindings for the
  `lane-disabled` and `cfg-deny` deny codes.
- `denial-receipt-schema-v0.md` must specify MUST-level producer rules binding
  `reason.ref_key` for those deny codes.
- `acp-validator-semantics.md` must include MUST-level guidance to bind
  `reason.ref_key` for lane/cfg-param gating rejections.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"[denyrefkey] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[denyrefkey] OK: {msg}")


def read(p: Path) -> str:
    if not p.exists():
        fail(f"missing required file: {p}")
    return p.read_text(encoding="utf-8")


def require_registry_row_has(tok: str, needle: str) -> None:
    reg = ROOT / "docs/30-architecture/deny-code-registry.md"
    txt = read(reg)
    # match a markdown table row for the token
    rows = [ln for ln in txt.splitlines() if ln.strip().startswith("|") and f"`{tok}`" in ln]
    if not rows:
        fail(f"deny-code-registry.md missing row for `{tok}`")
    # take the first match; table should be unique
    row = rows[0]
    if needle not in row:
        fail(f"deny-code-registry.md row for `{tok}` must mention `{needle}`")


def require_denyschema_rule(tok: str) -> None:
    p = ROOT / "docs/30-architecture/denial-receipt-schema-v0.md"
    txt = read(p)
    # We require a MUST-level producer rule binding reason.ref_key for each token.
    pat = re.compile(
        rf"When `deny_code == {re.escape(tok)}`[^\n]*MUST[^\n]*reason\.ref_key",
        flags=re.IGNORECASE,
    )
    if not pat.search(txt):
        fail(
            f"denial-receipt-schema-v0.md must include a MUST-level producer rule binding `reason.ref_key` for `{tok}`"
        )


def require_acp_semantics_anchor() -> None:
    p = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    txt = read(p)

    # Accept either a single paragraph covering both tokens, or separate mentions.
    need = [
        ("lane-disabled", re.compile(r"lane-disabled[^\n]{0,240}reason\.ref_key", re.IGNORECASE | re.DOTALL)),
        ("cfg-deny", re.compile(r"cfg-deny[^\n]{0,240}reason\.ref_key", re.IGNORECASE | re.DOTALL)),
    ]
    missing = [name for name, pat in need if not pat.search(txt)]
    if missing:
        fail(
            "acp-validator-semantics.md must mention binding `reason.ref_key` for deny codes: "
            + ", ".join(missing)
        )

    # Also require at least one MUST in the same neighborhood, to keep it normative.
    if "reason.ref_key" in txt and "MUST" not in txt:
        fail("acp-validator-semantics.md appears to mention reason.ref_key but has no MUST-level requirement")


def main() -> None:
    require_registry_row_has("lane-disabled", "reason.ref_key")
    require_registry_row_has("cfg-deny", "reason.ref_key")

    require_denyschema_rule("lane-disabled")
    require_denyschema_rule("cfg-deny")

    require_acp_semantics_anchor()

    ok("lane/cfg deny ref_key bindings are wired across registry + schema + ACP semantics")


if __name__ == "__main__":
    main()
