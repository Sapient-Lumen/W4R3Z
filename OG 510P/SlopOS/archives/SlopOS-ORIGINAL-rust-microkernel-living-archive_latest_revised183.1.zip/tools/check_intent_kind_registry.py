#!/usr/bin/env python3
"""Guardrail: keep workflow `intent.kind` vocabulary single-source and closed.

Why this exists
--------------
`intent.kind` appears in workflow plumbing artifacts (D-PLUMB):
- CH-PLUMBMSG v0 intent envelopes
- CH-ROUTE v0 routing rules

If the canonical kind set drifts into multiple docs, LLM edits (or humans)
can silently introduce:
- typo'd kinds that no validator/router recognizes,
- shadow enumerations that diverge across docs,
- permissive fallback behavior that reintroduces ambient workflow authority.

This check keeps the surface LLM-resilient by enforcing:
1) the canonical kind list lives only in `docs/30-architecture/intent-kind-registry.md`.
2) docs that declare `intent.kind` is a closed enum must not define a local list.
3) the plumbing schema/control docs point to the canonical registry.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


RE_KIND_ITEM = re.compile(r"^\s*-\s*`([a-z0-9_]+)`(?:\s*[:\-].*)?$")
RE_INTENT_ENUM_LINE = re.compile(r"intent\.kind|Intent\.kind", re.IGNORECASE)
RE_CLOSED_ENUM_HINT = re.compile(r"closed\s+enum", re.IGNORECASE)


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[intentkind] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[intentkind] OK: {msg}")


def load_registry_kinds(reg: Path) -> list[str]:
    txt = read(reg)
    kinds: list[str] = []
    for line in txt.splitlines():
        m = RE_KIND_ITEM.match(line)
        if m:
            kinds.append(m.group(1))

    if not kinds:
        fail("intent-kind-registry contains no `- `kind`` entries")

    dupes = sorted({k for k in kinds if kinds.count(k) > 1})
    if dupes:
        fail(f"intent-kind-registry has duplicate kind entries: {dupes}")

    # We prefer alphabetical order as a stable diff surface.
    if kinds != sorted(kinds):
        fail("intent-kind-registry kind list must be alphabetical (stable diff surface)")

    return kinds


def find_shadow_enum_blocks(md: Path, *, is_registry: bool) -> list[tuple[int, list[str]]]:
    """Return blocks of kind bullet lists that appear near an `intent.kind` closed-enum mention."""
    blocks: list[tuple[int, list[str]]] = []
    lines = read(md).splitlines()

    for i, line in enumerate(lines):
        if not (RE_INTENT_ENUM_LINE.search(line) and RE_CLOSED_ENUM_HINT.search(line)):
            continue

        # Look ahead for a contiguous bullet list of backticked tokens.
        j = i + 1
        # Skip a few non-bullet lines (e.g., "(v0):")
        while j < len(lines) and j < i + 35 and lines[j].strip() and not lines[j].lstrip().startswith("-"):
            j += 1

        kind_items: list[str] = []
        while j < len(lines) and j < i + 80:
            s = lines[j]
            if s.strip() == "":
                break
            if s.startswith("#"):
                break
            m = RE_KIND_ITEM.match(s)
            if m:
                kind_items.append(m.group(1))
                j += 1
                continue
            # Stop when we leave the bullet list.
            if kind_items:
                break
            j += 1

        if kind_items:
            blocks.append((i + 1, kind_items))

    if is_registry:
        return []
    return blocks


def main() -> None:
    root = repo_root()
    reg = root / "docs/30-architecture/intent-kind-registry.md"
    if not reg.exists():
        fail("missing docs/30-architecture/intent-kind-registry.md")

    kinds = load_registry_kinds(reg)

    # Require the primary plumbing schema docs to point at the registry.
    required_refs = [
        root / "docs/30-architecture/plumb-message-schema-v0.md",
        root / "docs/30-architecture/route-rules-schema-v0.md",
    ]
    for p in required_refs:
        if not p.exists():
            fail(f"missing required plumbing doc: {p.relative_to(root)}")
        if "docs/30-architecture/intent-kind-registry.md" not in read(p):
            fail(
                f"{p.relative_to(root)} must reference `docs/30-architecture/intent-kind-registry.md` "
                "as the canonical intent.kind list"
            )

    docs = root / "docs"
    shadow: list[str] = []
    for md in sorted(docs.rglob("*.md")):
        is_reg = md.samefile(reg)
        blocks = find_shadow_enum_blocks(md, is_registry=is_reg)
        for lineno, items in blocks:
            loc = f"{md.relative_to(root)}:{lineno}"
            shadow.append(f"- shadow intent.kind enum @ {loc}: {items}")

    if shadow:
        fail(
            "docs contain local `intent.kind` enum bullet lists; canonical list must live only in intent-kind-registry.md\n"
            + "\n".join(shadow[:50])
        )

    ok(f"intent.kind registry closed and single-source ({len(kinds)} kinds)")


if __name__ == "__main__":
    main()
