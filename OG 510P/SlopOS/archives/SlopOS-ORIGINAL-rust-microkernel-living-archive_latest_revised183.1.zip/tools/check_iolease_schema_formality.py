#!/usr/bin/env python3
"""CI drift gate: keep CH-IOLEASE v0 schema doc formal, bounded, and assurance-wired.

Why this exists
--------------
CH-IOLEASE is a stable descriptor surface for device/I/O leases (D-IOLEASE) and
is used by tooling and audits to reason about least-authority device access
without relying on implementation logs.

Historically, lease descriptor docs drift into "informal" prose, which causes:
- missing fail-closed / closed-enum requirements,
- unclear bounds and address-sensitivity rules,
- forgotten assurance wiring (I/PO tokens),
...all of which degrades LLM-resilience and reviewability.

This check is intentionally small and robust:
- It does not parse a full schema.
- It enforces a minimal set of anchors that keep the doc coherent.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs/30-architecture/io-lease-schema-v0.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[iolease-schema] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[iolease-schema] OK: {msg}")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/io-lease-schema-v0.md")

    txt = read(DOC)

    # Title must clearly mark this as a schema surface.
    first = txt.splitlines()[0].strip() if txt.splitlines() else ""
    if "CH-IOLEASE v0" not in first:
        fail("doc title missing 'CH-IOLEASE v0'")
    if "(schema" not in first:
        fail("doc title must include '(schema)' to mark it as a stable surface")
    if "informal" in txt.lower():
        fail("io-lease schema doc must not be marked or described as 'informal'")

    # Required sections keep the doc validator-friendly.
    for section in ["## Encoding", "## Data model", "## Validation rules"]:
        if section not in txt:
            fail(f"missing required section: {section}")

    # Assurance wiring anchors.
    for tok in ["PO-IOLEASE-VALIDATE", "I-IOLEASE-3", "I-ENC-1", "D-IOLEASE"]:
        if tok not in txt:
            fail(f"missing required anchor token: {tok}")

    # Fail-closed anchor.
    low = txt.lower()
    if "unknown" not in low or "reject" not in low:
        fail("doc must explicitly state unknown keys/variants reject (fail closed)")

    # No-secrets anchor.
    if "no secrets" not in low and "no bearer" not in low:
        fail("doc must explicitly state that it contains no secrets / bearer capability material")

    ok("CH-IOLEASE schema doc is formal, bounded, and assurance-wired")


if __name__ == "__main__":
    main()
