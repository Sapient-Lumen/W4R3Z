#!/usr/bin/env python3
"""CI guardrail: keep Foreign Cell adapter kinds closed + coherently wired.

Source of truth:
- docs/30-architecture/fcell-adapter-kind-registry.md

Checks (fail closed):
- Registry table parses and defines a non-empty closed set of adapter_kind tokens.
- foreign-cell-manifest-schema-v0.md v0 seed list matches the registry set.
- fcell-adapter-receipt-schema-v0.md references the registry.
- docs/README.md references the registry.
- Each adapter row names a portal token that exists in CH-PLEDGE and has a lane kill switch.

Rationale:
Sealed compatibility is only honest if compat interop cannot silently grow a parallel taxonomy.
"""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REG = ROOT / "docs/30-architecture/fcell-adapter-kind-registry.md"
FCELL = ROOT / "docs/30-architecture/foreign-cell-manifest-schema-v0.md"
FADAPT = ROOT / "docs/30-architecture/fcell-adapter-receipt-schema-v0.md"
FADAPT_V1 = ROOT / "docs/30-architecture/fcell-adapter-receipt-schema-v1.md"
PLEDGE = ROOT / "docs/30-architecture/pledge-contract-schema-v0.md"
CFG = ROOT / "docs/30-architecture/config-toggle-registry.md"
DOCS_README = ROOT / "docs/README.md"
SCHEMA_REG = ROOT / "docs/30-architecture/schema-registry.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[fcell-adapter-reg] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[fcell-adapter-reg] OK: {msg}")


def parse_registry_table(txt: str) -> list[tuple[str, str]]:
    """Return list of (adapter_kind, portal_token) rows."""
    rows: list[tuple[str, str]] = []
    in_table = False
    for line in txt.splitlines():
        if line.strip().startswith("| adapter_kind"):
            in_table = True
            continue
        if not in_table:
            continue
        if not line.strip().startswith("|"):
            # end table
            if rows:
                break
            continue
        # skip separator row
        if re.match(r"^\|\s*---", line.strip()):
            continue
        cols = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cols) < 3:
            continue
        ak_m = re.search(r"`([^`]+)`", cols[0])
        pt_m = re.search(r"`([^`]+)`", cols[2])
        if not ak_m or not pt_m:
            continue
        rows.append((ak_m.group(1).strip(), pt_m.group(1).strip()))
    return rows


def parse_fcell_seed(txt: str) -> set[str]:
    m = re.search(r"^\-\s*`adapter_kind` \(seed\):.*?\(v0 seed: `([^`]+)`\)", txt, re.M)
    if not m:
        fail("foreign-cell-manifest-schema-v0.md missing adapter_kind seed line with '(v0 seed: `...`)'")
    seed = m.group(1)
    parts = [x.strip() for x in seed.split("|")]
    return {p for p in parts if p}


def parse_pledge_portal_tokens(txt: str) -> set[str]:
    toks: set[str] = set()
    for line in txt.splitlines():
        m = re.match(r"^\-\s*`(portal\.[^`]+)`\s+—", line.strip())
        if m:
            toks.add(m.group(1))
    return toks


def cfg_has_kill_switch(cfg_txt: str, portal_token: str) -> bool:
    # portal.file -> cfg.params.lane.portal.file
    fam = portal_token.split(".", 1)[1]
    key = f"cfg.params.lane.portal.{fam}"
    return key in cfg_txt


def cfg_has_adapter_kill_switch(cfg_txt: str, adapter_kind: str) -> bool:
    # posix.open_via_doc_portal -> cfg.params.lane.fcell.adapter.posix_open_via_doc_portal
    key = "cfg.params.lane.fcell.adapter." + adapter_kind.replace(".", "_")
    return key in cfg_txt


def main() -> None:
    if not REG.exists():
        fail("missing fcell-adapter-kind-registry.md")
    rows = parse_registry_table(read(REG))
    if not rows:
        fail("failed to parse any adapter_kind rows from registry table")

    adapter_kinds = [ak for ak, _ in rows]
    if len(set(adapter_kinds)) != len(adapter_kinds):
        fail("duplicate adapter_kind in registry table")

    ok(f"parsed {len(rows)} adapter kind row(s)")

    seed = parse_fcell_seed(read(FCELL))
    reg_set = set(adapter_kinds)
    if seed != reg_set:
        missing = sorted(reg_set - seed)
        extra = sorted(seed - reg_set)
        msg = []
        if missing:
            msg.append(f"missing in CH-FCELL seed: {', '.join(missing)}")
        if extra:
            msg.append(f"extra in CH-FCELL seed: {', '.join(extra)}")
        fail("adapter_kind seed mismatch: " + "; ".join(msg))
    ok("CH-FCELL adapter_kind seed matches registry")

    fad_txt = read(FADAPT)
    if "fcell-adapter-kind-registry.md" not in fad_txt:
        fail("CH-FADAPT schema does not reference fcell-adapter-kind-registry.md")
    ok("CH-FADAPT references adapter kind registry")

    # Optional v1: reqctx correlation hook. If present, it must be wired and discoverable.
    if FADAPT_V1.exists():
        fad1 = read(FADAPT_V1)
        if "fcell-adapter-kind-registry.md" not in fad1:
            fail("CH-FADAPT v1 schema does not reference fcell-adapter-kind-registry.md")
        if "reqctx_digest" not in fad1 or "CH-REQCTX v1" not in fad1:
            fail("CH-FADAPT v1 schema missing reqctx_digest hook or CH-REQCTX v1 reference")
        ok("CH-FADAPT v1 references adapter kind registry and reqctx")

        # Ensure schema registry includes CH-FADAPT v1 entry (prevents orphan schema drift).
        if not SCHEMA_REG.exists():
            fail("missing docs/30-architecture/schema-registry.md")
        sr = read(SCHEMA_REG)
        if "| CH-FADAPT v1 |" not in sr and "CH-FADAPT v1" not in sr:
            fail("schema-registry.md missing CH-FADAPT v1 entry")
        ok("schema registry includes CH-FADAPT v1")

        # Ensure docs index references v1 (discovery surface).
        dr = read(DOCS_README)
        if "30-architecture/fcell-adapter-receipt-schema-v1.md" not in dr and "fcell-adapter-receipt-schema-v1.md" not in dr:
            fail("docs/README.md does not reference fcell-adapter-receipt-schema-v1.md")
        ok("docs/README.md references CH-FADAPT v1")

    dr = read(DOCS_README)
    if "30-architecture/fcell-adapter-kind-registry.md" not in dr and "fcell-adapter-kind-registry.md" not in dr:
        fail("docs/README.md does not reference fcell-adapter-kind-registry.md")
    ok("docs/README.md references adapter kind registry")

    pledge_tokens = parse_pledge_portal_tokens(read(PLEDGE))
    if not pledge_tokens:
        fail("failed to parse portal.* tokens from CH-PLEDGE schema")

    cfg_txt = read(CFG)
    for ak, pt in rows:
        if pt not in pledge_tokens:
            fail(f"registry row {ak} references portal token not present in CH-PLEDGE: {pt}")
        if not cfg_has_kill_switch(cfg_txt, pt):
            fail(f"registry row {ak} portal token missing lane kill switch in config-toggle-registry.md: {pt}")
        if not cfg_has_adapter_kill_switch(cfg_txt, ak):
            fail(f"registry row {ak} missing adapter-specific kill switch in config-toggle-registry.md: cfg.params.lane.fcell.adapter.{ak.replace('.', '_')}")

    ok("all registry portal tokens exist in CH-PLEDGE and have portal+adapter lane kill switches")


if __name__ == "__main__":
    main()
