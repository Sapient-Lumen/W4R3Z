#!/usr/bin/env python3
"""Minimal, high-value archive lints.

Goals:
- Prevent silent drift in IDs, links, and schemas.
- Keep implementation tiny and easy to audit.

Non-goals:
- Perfect markdown parsing.
- Proving correctness of content.
"""

from __future__ import annotations

import re
import sys
import os
from dataclasses import dataclass
from pathlib import Path

RE_MD_LINK = re.compile(r"\[[^\]]*\]\(([^)]+)\)")
RE_CODE_FENCE = re.compile(r"^```")
RE_INLINE_CODE = re.compile(r"`([^`\n]+)`")

# Concrete ID patterns (intentionally strict to avoid placeholders like ADR-????)
# Use a negative lookbehind to avoid matching substrings inside other IDs
# (e.g., avoid matching "IF-1" inside "I-IF-1").

def _pat(s: str) -> re.Pattern[str]:
    return re.compile(rf"(?<![A-Z0-9-]){s}")

ID_PATTERNS: dict[str, re.Pattern[str]] = {
    "A": _pat(r"A-[A-Z][A-Z0-9-]*"),
    "ADV": _pat(r"ADV-[A-Z][A-Z0-9-]*"),
    "AC": _pat(r"AC-[0-9]{3}"),
    "C": _pat(r"C-[A-Z][A-Z0-9-]*"),
    "I": _pat(r"I-[A-Z][A-Z0-9-]*"),
    "D": _pat(r"D-[A-Z][A-Z0-9-]*"),
    "PO": _pat(r"PO-[A-Z][A-Z0-9-]*"),
    "U": _pat(r"U-[A-Z][A-Z0-9-]*"),
    "IF": _pat(r"IF-[A-Z][A-Z0-9-]*"),
    "CH": _pat(r"CH-[A-Z][A-Z0-9-]*"),
    "EVID": _pat(r"EVID-[0-9]{4}-[0-9]{3}"),
    "REF": _pat(r"REF-[A-Z][A-Z0-9-]*"),
    "ADR": _pat(r"ADR-[0-9]{4}"),
    "RFC": _pat(r"RFC-[0-9]{4}"),
}

# Placeholders used as prose labels that should not be linted as concrete IDs.
IGNORE_IDS = {
    "A-ID",
    "C-ID",
    "I-ID",
    "D-ID",
    "PO-ID",
    "U-ID",
    "IF-ID",
    "CH-ID",
    "EVID-ID",
    "REF-ID",
}

CANONICAL_DEFS = {
    "A": ["docs/10-threat-model/assumption-registry.md"],
    "ADV": ["docs/10-threat-model/threat-model.md"],
    "AC": ["docs/10-threat-model/abuse-cases.md"],
    "C": ["docs/20-assurance/claim-registry.md"],
    "I": ["docs/20-assurance/invariant-registry.md"],
    "PO": ["docs/20-assurance/proof-obligation-registry.md"],
    "U": ["docs/20-assurance/unsafe-obligation-registry.md"],
    "IF": ["docs/30-architecture/interface-registry.md"],
    "CH": [
        "docs/30-architecture/schema-registry.md",
        "docs/70-llm-control/acp-action-schema-v0.md",
        "docs/30-architecture/transcript-contract.md",
    ],
    "EVID": ["docs/00-meta/evidence-index.md"],
    "REF": ["docs/00-meta/bibliography.md"],
    "D": ["docs/30-architecture/decision-map.md"],
}


@dataclass
class Problem:
    kind: str
    path: Path
    detail: str


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def iter_markdown_files(root: Path) -> list[Path]:
    return sorted([p for p in root.rglob("*.md") if ".git" not in p.parts])


def strip_family_refs(text: str) -> str:
    """Remove shorthand refs like <I-FOO-*> to avoid false undefined-ID reports."""
    return re.sub(r"<[^>]*\*>", "", text)


def strip_code_fences(text: str) -> str:
    """Drop fenced code blocks (IDs in code examples shouldn't be linted)."""
    out_lines: list[str] = []
    in_fence = False
    for line in text.splitlines():
        if RE_CODE_FENCE.match(line.strip()):
            in_fence = not in_fence
            continue
        if not in_fence:
            out_lines.append(line)
    return "\n".join(out_lines)


def collect_defined_ids(root: Path) -> dict[str, set[str]]:
    defined: dict[str, set[str]] = {k: set() for k in ID_PATTERNS.keys()}

    # Canonical registries/maps
    for ns, rels in CANONICAL_DEFS.items():
        pat = ID_PATTERNS[ns]
        for rel in rels:
            p = root / rel
            if not p.exists():
                continue
            txt = strip_code_fences(strip_family_refs(read_text(p)))
            defined[ns].update(pat.findall(txt))

    # ADR/RFC: filenames define IDs
    for p in (root / "adrs").glob("[0-9][0-9][0-9][0-9]-*.md"):
        defined["ADR"].add(f"ADR-{p.name[:4]}")
    for p in (root / "rfcs").glob("[0-9][0-9][0-9][0-9]-*.md"):
        defined["RFC"].add(f"RFC-{p.name[:4]}")

    return defined


def find_references_in_file(text: str) -> dict[str, set[str]]:
    txt = strip_code_fences(strip_family_refs(text))
    refs: dict[str, set[str]] = {}
    for ns, pat in ID_PATTERNS.items():
        found = set(pat.findall(txt))
        # Drop prose-label placeholders like "C-ID".
        found = {x for x in found if x not in IGNORE_IDS and not x.endswith("-ID")}
        refs[ns] = found
    return refs


def lint_undefined_ids(root: Path, defined: dict[str, set[str]]) -> list[Problem]:
    problems: list[Problem] = []
    for md in iter_markdown_files(root):
        txt = read_text(md)
        refs = find_references_in_file(txt)
        for ns, found in refs.items():
            if ns not in defined:
                continue
            missing = sorted([x for x in found if x not in defined[ns]])
            if missing:
                problems.append(
                    Problem(
                        kind="undefined-id",
                        path=md.relative_to(root),
                        detail=f"{ns}: {', '.join(missing[:20])}{' …' if len(missing)>20 else ''}",
                    )
                )
    return problems


def lint_internal_links(root: Path) -> list[Problem]:
    problems: list[Problem] = []
    for md in iter_markdown_files(root):
        base = md.parent
        txt = strip_code_fences(read_text(md))
        for target in RE_MD_LINK.findall(txt):
            target = target.strip()
            if not target or target.startswith("#"):
                continue
            if target.startswith("http://") or target.startswith("https://") or target.startswith("mailto:"):
                continue
            # Strip anchors
            target_path = target.split("#", 1)[0]
            if not target_path:
                continue
            p = (base / target_path).resolve()
            try:
                p.relative_to(root)
            except ValueError:
                problems.append(Problem("bad-link", md.relative_to(root), f"link escapes repo: {target}"))
                continue
            if not p.exists():
                problems.append(Problem("bad-link", md.relative_to(root), f"missing: {target}"))
    return problems


def lint_no_raw_urls(root: Path) -> list[Problem]:
    problems: list[Problem] = []
    bib = (root / "docs/00-meta/bibliography.md").resolve()
    for md in iter_markdown_files(root):
        if md.resolve() == bib:
            continue
        txt = strip_code_fences(read_text(md))
        if "http://" in txt or "https://" in txt:
            problems.append(
                Problem(
                    "raw-url",
                    md.relative_to(root),
                    "raw URL found (register as REF; keep URLs in bibliography only)",
                )
            )
    return problems


def lint_inline_repo_paths(root: Path) -> list[Problem]:
    """Ensure backticked repo paths actually exist.

    Rationale: prose docs often reference internal files/paths in inline code.
    These references silently rot when files move. Keeping them valid preserves
    “stable review surfaces” and reduces LLM drift.

    Scope: only checks obvious repo-rooted paths (docs/, tools/, adrs/, rfcs/)
    and a small allowlist of top-level files. Does NOT attempt to validate
    commands (e.g., `make lint`) or generated outputs (out/).
    """
    problems: list[Problem] = []
    top_level = {"README.md", "CHANGELOG.md", "Makefile", "CONTRIBUTING.md", ".gitignore"}

    for md in iter_markdown_files(root):
        txt = strip_code_fences(read_text(md))
        for raw in RE_INLINE_CODE.findall(txt):
            s = raw.strip()
            # Trim common trailing punctuation.
            s = s.rstrip(".,);:")
            if s.startswith("out/"):
                continue
            if not (
                s.startswith(("docs/", "tools/", "adrs/", "rfcs/"))
                or s in top_level
            ):
                continue

            rel = s.rstrip("/")
            p = (root / rel).resolve()
            try:
                p.relative_to(root)
            except ValueError:
                problems.append(Problem("inline-path", md.relative_to(root), f"path escapes repo: `{s}`"))
                continue
            if not p.exists():
                problems.append(Problem("inline-path", md.relative_to(root), f"missing: `{s}`"))

    return problems


def lint_numbering_unique(root: Path) -> list[Problem]:
    problems: list[Problem] = []

    def dupe_check(dir_name: str, kind: str) -> None:
        seen: dict[str, Path] = {}
        for p in (root / dir_name).glob("[0-9][0-9][0-9][0-9]-*.md"):
            n = p.name[:4]
            if n in seen:
                problems.append(
                    Problem(
                        "duplicate-number",
                        p.relative_to(root),
                        f"{kind} {n} duplicates {seen[n].relative_to(root)}",
                    )
                )
            else:
                seen[n] = p

    dupe_check("adrs", "ADR")
    dupe_check("rfcs", "RFC")
    return problems


def lint_traceability(root: Path, defined: dict[str, set[str]]) -> list[Problem]:
    problems: list[Problem] = []
    trace = root / "docs/20-assurance/traceability.md"
    if not trace.exists():
        return problems
    txt = strip_code_fences(read_text(trace))
    for cid in sorted(defined.get("C", set())):
        if cid not in txt:
            problems.append(Problem("traceability", trace.relative_to(root), f"missing claim row for {cid}"))
    return problems


def lint_schema_registry_pointers(root: Path) -> list[Problem]:
    """Ensure schema registry rows point to spec docs that name CH-* + version.

    Additional drift guard: if a registry row names `CH-FOO v0`, the linked spec
    should contain that exact token (prevents silent mismatches).
    """
    problems: list[Problem] = []
    reg = root / "docs/30-architecture/schema-registry.md"
    if not reg.exists():
        return problems
    reg_txt = strip_code_fences(read_text(reg))

    # 1) Basic: every markdown link to a .md in the registry must exist.
    md_links = [x.strip() for x in RE_MD_LINK.findall(reg_txt)]
    spec_paths = [x.split("#", 1)[0] for x in md_links if x.endswith(".md")]

    for rel in sorted(set(spec_paths)):
        p = (reg.parent / rel).resolve()
        if not p.exists():
            problems.append(Problem("schema", reg.relative_to(root), f"schema spec missing: {rel}"))
            continue
        txt = strip_code_fences(read_text(p))
        head = "\n".join(txt.splitlines()[:40])
        if "CH-" not in head or not re.search(r"\bv[0-9]+\b", head):
            problems.append(
                Problem(
                    "schema",
                    p.relative_to(root),
                    "schema spec should name CH-* and version (e.g., 'CH-FOO v0')",
                )
            )

    # 2) Drift guard: registry row schema id must appear in the linked spec.
    row_re = re.compile(
        r"^\|\s*(CH-[A-Z0-9-]+\s+v[0-9]+)\s*\|.*?\|\s*\[.*?\]\(([^)]+\.md)(?:#[^)]+)?\)\s*\|",
        re.M,
    )
    for m in row_re.finditer(reg_txt):
        schema_id = m.group(1).strip()
        rel = m.group(2).strip().split("#", 1)[0]
        spec = (reg.parent / rel).resolve()
        if not spec.exists():
            continue
        body = strip_code_fences(read_text(spec))
        head = "\n".join(body.splitlines()[:80])
        if schema_id not in head and schema_id not in body:
            problems.append(
                Problem(
                    "schema",
                    spec.relative_to(root),
                    f"schema spec does not mention its registry id '{schema_id}'",
                )
            )

    return problems


def lint_schema_docs_registered(root: Path) -> list[Problem]:
    """Ensure every `*-schema-vN.md` doc is listed in the schema registry.

    Rationale: schemas are cross-boundary contracts. Orphaned schema docs are a common
    source of drift (LLM edits add a schema doc but forget to register it).
    """
    problems: list[Problem] = []
    reg = root / "docs/30-architecture/schema-registry.md"
    if not reg.exists():
        return problems

    reg_dir = reg.parent
    reg_txt = strip_code_fences(read_text(reg))
    linked = {
        x.split("#", 1)[0].strip().lstrip("./")
        for x in RE_MD_LINK.findall(reg_txt)
        if x.strip().endswith(".md")
    }

    # Any schema doc in docs/ is required to be registered.
    schema_docs = sorted((root / "docs").rglob("*-schema-v[0-9]*.md"))
    for sd in schema_docs:
        rel = Path(os.path.relpath(sd, reg_dir)).as_posix()
        rel = rel.lstrip("./")
        if rel not in linked:
            problems.append(
                Problem(
                    kind="schema",
                    path=sd.relative_to(root),
                    detail="schema doc not registered in schema-registry.md",
                )
            )
    return problems


def lint_index_tables(root: Path) -> list[Problem]:
    """Ensure rfcs/README.md and adrs/README.md indexes list all non-template entries."""
    problems: list[Problem] = []

    def _check(dir_rel: str, readme_rel: str, kind: str) -> None:
        d = root / dir_rel
        readme = root / readme_rel
        if not d.exists() or not readme.exists():
            return
        files = sorted([p.name for p in d.glob("[0-9][0-9][0-9][0-9]-*.md") if p.name != "0000-template.md"])
        txt = strip_code_fences(read_text(readme))
        linked = sorted({Path(x.split("#",1)[0]).name for x in RE_MD_LINK.findall(txt) if x.endswith(".md")})
        missing = [f for f in files if f not in linked]
        extra = [f for f in linked if re.match(r"^[0-9]{4}-.*\.md$", f) and f not in files]
        if missing:
            problems.append(Problem(kind, Path(readme_rel), f"index missing: {', '.join(missing)}"))
        if extra:
            problems.append(Problem(kind, Path(readme_rel), f"index links to non-existent: {', '.join(extra)}"))

    _check("rfcs", "rfcs/README.md", "rfc-index")
    _check("adrs", "adrs/README.md", "adr-index")
    return problems





def lint_pledge_token_consistency(root: Path) -> list[Problem]:
    """Ensure CH-PLEDGE token enum and the mapping table stay consistent.

    Rationale: CH-PLEDGE validators must reject unknown tokens. If the mapping table
    mentions tokens not listed in the schema (or vice versa), reviews and tests drift.
    """
    problems: list[Problem] = []
    schema = root / "docs/30-architecture/pledge-contract-schema-v0.md"
    mapping = root / "docs/30-architecture/pledge-token-mapping.md"
    if not schema.exists() or not mapping.exists():
        return problems

    schema_txt = strip_code_fences(read_text(schema))
    mapping_txt = strip_code_fences(read_text(mapping))

    # Schema tokens: bullet list in the "Promise tokens" section (lines like: - `token` — ...)
    schema_tok_re = re.compile(r"^\-\s*`([^`]+)`\s+—", re.M)
    schema_tokens = set(schema_tok_re.findall(schema_txt))

    # Mapping tokens: first column of the markdown table.
    map_tok_re = re.compile(r"^\|\s*`([^`]+)`\s*\|", re.M)
    map_tokens = set(map_tok_re.findall(mapping_txt))

    missing_in_schema = sorted(map_tokens - schema_tokens)
    missing_in_map = sorted(schema_tokens - map_tokens)

    if missing_in_schema:
        problems.append(
            Problem(
                kind="pledge-tokens",
                path=mapping.relative_to(root),
                detail=f"tokens in mapping but not in CH-PLEDGE schema: {', '.join(missing_in_schema)}",
            )
        )
    if missing_in_map:
        problems.append(
            Problem(
                kind="pledge-tokens",
                path=mapping.relative_to(root),
                detail=f"tokens in CH-PLEDGE schema but not in mapping table: {', '.join(missing_in_map)}",
            )
        )

    return problems



def lint_portal_family_registry_consistency(root: Path) -> list[Problem]:
    '''Ensure portal-family-registry covers all `portal.*` tokens in CH-PLEDGE.

    Rationale: portal families are security seams; if CH-PLEDGE grows a new `portal.*` token,
    reviewers should see it reflected in the portal registry (and vice versa).
    '''
    problems: list[Problem] = []
    schema = root / "docs/30-architecture/pledge-contract-schema-v0.md"
    preg = root / "docs/30-architecture/portal-family-registry.md"
    if not schema.exists() or not preg.exists():
        return problems

    schema_txt = strip_code_fences(read_text(schema))
    # Schema tokens: bullet list in the "Promise tokens" section (lines like: - `token` — ...)
    schema_tok_re = re.compile(r"^\-\s*`([^`]+)`\s+—", re.M)
    schema_tokens = set(schema_tok_re.findall(schema_txt))
    pledge_portal_tokens = {t for t in schema_tokens if t.startswith("portal.")}

    preg_txt = strip_code_fences(read_text(preg))
    reg_tokens: set[str] = set()
    for line in preg_txt.splitlines():
        if not line.strip().startswith("| `portal."):
            continue
        toks = re.findall(r"`(portal\.[^`]+)`", line)
        if toks:
            # The last token on the row is the CH-PLEDGE token column.
            reg_tokens.add(toks[-1])

    missing_in_registry = sorted(pledge_portal_tokens - reg_tokens)
    missing_in_schema = sorted(reg_tokens - pledge_portal_tokens)

    if missing_in_registry:
        problems.append(
            Problem(
                kind="portal-registry",
                path=preg.relative_to(root),
                detail=f"portal tokens in CH-PLEDGE but missing from portal registry: {', '.join(missing_in_registry)}",
            )
        )
    if missing_in_schema:
        problems.append(
            Problem(
                kind="portal-registry",
                path=preg.relative_to(root),
                detail=f"portal tokens in portal registry but missing from CH-PLEDGE schema: {', '.join(missing_in_schema)}",
            )
        )

    return problems


def lint_fcell_portal_token_consistency(root: Path) -> list[Problem]:
    """Ensure CH-FCELL portal allowlists use the same closed `portal.*` token set.

    Rationale:
    - Sealed compatibility must not grow a parallel, drifting portal taxonomy.
    - CH-FCELL interop gates should be reviewable against the same stable surfaces used
      by portals and workflow tooling (CH-PLEDGE + portal-family-registry).

    This guardrail is intentionally shallow:
    - it only checks that portal tokens mentioned in CH-FCELL are valid CH-PLEDGE `portal.*` tokens,
    - and that CH-FCELL does not retain the old `portal_kind` taxonomy.
    """
    problems: list[Problem] = []
    fcell = root / "docs/30-architecture/foreign-cell-manifest-schema-v0.md"
    pledge = root / "docs/30-architecture/pledge-contract-schema-v0.md"
    if not fcell.exists() or not pledge.exists():
        return problems

    raw = read_text(fcell)
    ftxt = strip_code_fences(raw)
    if "portal_kind" in raw:
        problems.append(
            Problem(
                kind="fcell-portals",
                path=fcell.relative_to(root),
                detail="CH-FCELL must use CH-PLEDGE `portal.*` tokens (portal_token), not the deprecated `portal_kind` taxonomy",
            )
        )

    # Extract CH-PLEDGE tokens.
    ptxt = strip_code_fences(read_text(pledge))
    schema_tok_re = re.compile(r"^\-\s*`([^`]+)`\s+—", re.M)
    pledge_tokens = set(schema_tok_re.findall(ptxt))
    pledge_portal_tokens = {t for t in pledge_tokens if t.startswith("portal.")}

    # Extract portal tokens mentioned by CH-FCELL.
    fcell_portal_tokens = set(re.findall(r"`(portal\.[^`]+)`", ftxt))

    if not fcell_portal_tokens:
        problems.append(
            Problem(
                kind="fcell-portals",
                path=fcell.relative_to(root),
                detail="CH-FCELL should explicitly mention at least one `portal.*` token in its v0 seeds (helps reviewers; enables lint alignment)",
            )
        )
        return problems

    missing = sorted(fcell_portal_tokens - pledge_portal_tokens)
    if missing:
        problems.append(
            Problem(
                kind="fcell-portals",
                path=fcell.relative_to(root),
                detail=f"CH-FCELL references portal token(s) not present in CH-PLEDGE schema: {', '.join(missing)}",
            )
        )

    # Small sanity: ensure the schema labels the list entries as `<portal_token>`.
    if "<portal_token>" not in raw:
        problems.append(
            Problem(
                kind="fcell-portals",
                path=fcell.relative_to(root),
                detail="CH-FCELL should label `interop.portals_allowed` entries as `<portal_token>` (not `<portal_kind>`)",
            )
        )

    return problems


def lint_cfg_toggle_registry_consistency(root: Path) -> list[Problem]:
    """Guardrail: keep CH-CFG toggle closure explicit and consistent.

    Rationale:
    - CH-CFG claims a closed set of keys/flags.
    - Profile/lane gating is a common drift seam (new toggle names appear in prose/tools without being reviewed).

    This lint is intentionally shallow: it checks that references to `ext.*` flags and `cfg.params.*` lane gates
    appear in the toggle registry.
    """
    problems: list[Problem] = []
    reg = root / "docs/30-architecture/config-toggle-registry.md"
    if not reg.exists():
        return problems

    reg_txt = strip_code_fences(read_text(reg))

    # Extract flag values from the first-column table entries.
    flag_re = re.compile(r"^\|\s*`(ext\.[^`]+)`\s*\|", re.M)
    flags = set(flag_re.findall(reg_txt))

    # Extract param keys from the lane-gates table.
    param_re = re.compile(r"^\|\s*`(cfg\.params\.[^`]+)`\s*\|", re.M)
    params = set(param_re.findall(reg_txt))

    if not flags or not params:
        problems.append(Problem("cfg-toggles", reg.relative_to(root), "toggle registry must list at least one ext.* flag and one cfg.params.* key"))
        return problems

    # Config schema must reference the registry.
    cfgdoc = root / "docs/30-architecture/config-schema-v0.md"
    if cfgdoc.exists():
        txt = strip_code_fences(read_text(cfgdoc))
        if "config-toggle-registry.md" not in txt:
            problems.append(Problem("cfg-toggles", cfgdoc.relative_to(root), "CH-CFG schema doc must reference config-toggle-registry.md"))

    # Deployment profiles: any backticked ext.* flag must be in the registry.
    prof = root / "docs/10-threat-model/deployment-profiles.md"
    if prof.exists():
        ptxt = strip_code_fences(read_text(prof))
        used = set(re.findall(r"`(ext\.[^`]+)`", ptxt))
        missing = sorted(used - flags)
        if missing:
            problems.append(Problem("cfg-toggles", prof.relative_to(root), f"deployment profiles mention unknown feature flag(s): {', '.join(missing)}"))

    # ACP kind registry + effect-contract schema: any cfg.params.* reference must be in the registry.
    for doc_rel in [
        "docs/70-llm-control/acp-action-kind-registry.md",
        "docs/30-architecture/effect-contract-schema-v0.md",
    ]:
        d = root / doc_rel
        if not d.exists():
            continue
        dtxt = strip_code_fences(read_text(d))
        usedp = set(re.findall(r"\bcfg\.params\.[a-z0-9_.-]+\b", dtxt))
        missingp = sorted(usedp - params)
        if missingp:
            problems.append(Problem("cfg-toggles", d.relative_to(root), f"doc references cfg.params key(s) missing from toggle registry: {', '.join(missingp)}"))

    return problems


def lint_acp_action_kind_registry(root: Path) -> list[Problem]:
    """Guardrail: ensure ACP action kind registry stays structured and enforceable.

    Rationale: CH-ACP is the stable product surface for automation. The kind registry is
    where we pin conflict keys + commutativity/ordering stance so Hybrid + D-COMMUTE
    stays honest and LLM tooling can't drift into undocumented kinds.
    """
    problems: list[Problem] = []
    reg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    schema = root / "docs/70-llm-control/acp-action-schema-v0.md"

    if not reg.exists():
        problems.append(Problem("acp-kind-registry", Path("docs/70-llm-control"), "missing acp-action-kind-registry.md"))
        return problems

    reg_txt = strip_code_fences(read_text(reg))

    # Require schema doc to reference the registry (prevents invisible drift).
    if schema.exists():
        sch_txt = strip_code_fences(read_text(schema))
        if "acp-action-kind-registry.md" not in sch_txt:
            problems.append(Problem("acp-kind-registry", schema.relative_to(root), "CH-ACP schema doc must reference acp-action-kind-registry.md"))

    # Find the registry table header.
    lines = [ln.rstrip() for ln in reg_txt.splitlines()]
    try:
        h = next(i for i, ln in enumerate(lines) if ln.strip().startswith("| Kind |") and "Commutativity" in ln)
    except StopIteration:
        problems.append(Problem("acp-kind-registry", reg.relative_to(root), "missing registry table header with Kind/Commutativity columns"))
        return problems

    # Data rows follow after the separator row.
    data: list[str] = []
    for ln in lines[h+2:]:
        if not ln.strip().startswith("|"):
            break
        if ln.strip().startswith("|---"):
            continue
        data.append(ln)

    if not data:
        problems.append(Problem("acp-kind-registry", reg.relative_to(root), "registry table has no rows"))
        return problems

    for ln in data:
        cols = [c.strip() for c in ln.strip().strip("|").split("|")]
        if len(cols) < 7:
            problems.append(Problem("acp-kind-registry", reg.relative_to(root), f"malformed row (expected 7 cols): {ln}"))
            continue
        kind, owner, ck, comm, retry, order, profiles = cols[:7]
        if not kind or not owner or not ck or not comm or not profiles:
            problems.append(Problem("acp-kind-registry", reg.relative_to(root), f"row missing required fields: {ln}"))
            continue
        if "ordered" in comm.lower() or "non-commutative" in comm.lower():
            if "none" in order.lower() or not order:
                problems.append(Problem("acp-kind-registry", reg.relative_to(root), f"ordered kind must not have 'none' ordering witness: {kind}"))

    return problems


def lint_log_and_receipt_action_metadata(root: Path) -> list[Problem]:
    """Guardrail: keep CH-LOG/CH-RECEIPT aligned with D-COMMUTE observability.

    Rationale:
    - Hybrid + commutativity requires explicit conflict keys and explicit ordering witnesses.
    - If logs/receipts omit the digests, we lose stable diff surfaces and evidence hooks.

    This is intentionally simple: we only assert the schema docs mention the fields.
    """
    problems: list[Problem] = []
    logdoc = root / "docs/30-architecture/transcript-contract.md"
    rdoc = root / "docs/30-architecture/consent-receipt-schema-v0.md"

    # Both docs must keep the D-COMMUTE observability fields visible.
    for p in (logdoc, rdoc):
        if not p.exists():
            continue
        txt = strip_code_fences(read_text(p))
        for tok in ("conflict_key_digest", "order_digest"):
            if tok not in txt:
                problems.append(
                    Problem(
                        kind="log-receipt-meta",
                        path=p.relative_to(root),
                        detail=f"missing required D-COMMUTE observability field mention: '{tok}'",
                    )
                )

    # Log contract must also mention deny_digest when CH-DENY is present.
    deny = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    if deny.exists() and logdoc.exists():
        ltxt = strip_code_fences(read_text(logdoc))
        if "deny_digest" not in ltxt:
            problems.append(
                Problem(
                    kind="log-receipt-meta",
                    path=logdoc.relative_to(root),
                    detail="CH-LOG contract must mention 'deny_digest' when CH-DENY exists",
                )
            )

        dtxt = strip_code_fences(read_text(deny))
        if "deny_code" not in dtxt:
            problems.append(
                Problem(
                    kind="log-receipt-meta",
                    path=deny.relative_to(root),
                    detail="CH-DENY schema should mention 'deny_code' (closed enum via deny-code-registry.md)",
                )
            )
        if "deny-code-registry.md" not in dtxt:
            problems.append(
                Problem(
                    kind="log-receipt-meta",
                    path=deny.relative_to(root),
                    detail="CH-DENY schema should reference deny-code-registry.md when present (prevents deny-code drift)",
                )
            )

    return problems


def lint_deny_code_registry_consistency(root: Path) -> list[Problem]:
    """Guardrail: keep deny_code closure stable and machine-checkable.

    Rationale:
    - CH-DENY uses a closed `deny_code` enum.
    - Centralizing the enum in a registry reduces drift and improves reviewability.
    - ACP validator semantics should list the deny codes it emits as a subset of the registry.
    """
    problems: list[Problem] = []
    reg = root / "docs/30-architecture/deny-code-registry.md"
    if not reg.exists():
        return problems

    rtxt = strip_code_fences(read_text(reg))
    code_re = re.compile(r"^\|\s*`([a-z][a-z0-9-]+)`\s*\|", re.M)
    codes = set(code_re.findall(rtxt))
    if not codes:
        problems.append(Problem("deny-codes", reg.relative_to(root), "deny-code registry table has no deny_code rows"))
        return problems

    # Minimum seed set: ensures policy-kill + lane-kill + schema rejects remain representable.
    required = {"invalid-schema", "unknown-kind", "policy-deny", "lane-disabled", "internal-error"}
    missing = sorted(required - codes)
    if missing:
        problems.append(Problem("deny-codes", reg.relative_to(root), f"deny-code registry missing required seed code(s): {', '.join(missing)}"))

    # CH-DENY schema must reference the registry.
    deny = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    if deny.exists():
        dtxt = strip_code_fences(read_text(deny))
        if "deny-code-registry.md" not in dtxt:
            problems.append(Problem("deny-codes", deny.relative_to(root), "CH-DENY schema must reference deny-code-registry.md"))

    # ACP semantics: deny-code list must be a subset of the registry.
    acp = root / "docs/70-llm-control/acp-validator-semantics.md"
    if acp.exists():
        atxt = strip_code_fences(read_text(acp))
        start = atxt.find("### Deny codes used by ACP validators")
        if start < 0:
            problems.append(Problem("deny-codes", acp.relative_to(root), "missing '### Deny codes used by ACP validators' section"))
        else:
            end = atxt.find("\n## ", start + 5)
            if end < 0:
                end = len(atxt)
            block = atxt[start:end]
            used = set(re.findall(r"^\-\s+`([^`]+)`\s*$", block, re.M))
            unknown = sorted([c for c in used if c not in codes])
            if unknown:
                problems.append(Problem("deny-codes", acp.relative_to(root), f"ACP semantics lists deny_code(s) not in registry: {', '.join(unknown)}"))
            if "lane-disabled" not in used:
                problems.append(Problem("deny-codes", acp.relative_to(root), "ACP semantics deny-code list should include 'lane-disabled' (policy-kill audit seam)"))

    # CH-FADAPT schema: reuse deny_code closure for adapter denial reasons (prevents compat drift).
    fadapt = root / "docs/30-architecture/fcell-adapter-receipt-schema-v0.md"
    if fadapt.exists():
        ftxt = strip_code_fences(read_text(fadapt))
        if "deny-code-registry.md" not in ftxt:
            problems.append(Problem("deny-codes", fadapt.relative_to(root), "CH-FADAPT schema must reference deny-code-registry.md (unify denial tokens)"))
        for m in re.finditer(r"reason\s*=\s*`?([A-Za-z0-9_-]+)`?", ftxt):
            tok = m.group(1)
            if tok.lower() != tok or "_" in tok:
                problems.append(Problem("deny-codes", fadapt.relative_to(root), f"CH-FADAPT uses non-canonical reason token '{tok}'; use deny_code tokens (kebab-case)"))
            elif tok not in codes:
                problems.append(Problem("deny-codes", fadapt.relative_to(root), f"CH-FADAPT reason token '{tok}' not present in deny-code registry"))

    return problems


def lint_rrbundle_denial_closure(root: Path) -> list[Problem]:
    """Guardrail: keep CH-RRBUNDLE aware of structured denials when CH-DENY exists.

    Rationale:
    - CH-DENY makes fail-closed rejections mechanically auditable.
    - If replay/audit bundles omit denial records (or never mention them), incident handoffs drift
      back into ad-hoc strings and hidden policy seams.

    This lint is intentionally shallow: it only asserts the CH-RRBUNDLE schema doc mentions
    the optional `deny_stream` payload kind and CH-DENY.
    """
    problems: list[Problem] = []
    deny = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    bundle = root / "docs/30-architecture/replay-bundle-schema-v0.md"
    if not deny.exists() or not bundle.exists():
        return problems

    btxt = strip_code_fences(read_text(bundle))
    if "deny_stream" not in btxt or "CH-DENY" not in btxt:
        problems.append(
            Problem(
                kind="rrbundle-deny",
                path=bundle.relative_to(root),
                detail="CH-RRBUNDLE schema should mention optional deny_stream payload kind bound to CH-DENY (prevents deny drift in replay bundles)",
            )
        )
    return problems


def lint_capshell_argv_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep CH-ARGV wiring tight when D-CAPSHELL is in play.

    Rationale:
    - Workflow automation is a frequent ambient-authority leak.
    - If we introduce typed argv tokens (CH-ARGV), they must remain visible from
      the stable validator surfaces (ACP semantics + kind registry) and have a
      deterministic denial code for binding failures.

    This lint is intentionally shallow: it asserts that key docs mention the
    required hooks.
    """
    problems: list[Problem] = []
    argv = root / "docs/30-architecture/argv-schema-v0.md"
    if not argv.exists():
        return problems

    atxt = strip_code_fences(read_text(argv))
    if "ambient PATH" not in atxt or "role=\"exec\"" not in atxt:
        problems.append(
            Problem(
                kind="capshell-argv",
                path=argv.relative_to(root),
                detail=(
                    "CH-ARGV schema should pin the executable binding rule for capshell.exec "
                    "(no ambient PATH resolution; require an explicit desc token with role=\"exec\")"
                ),
            )
        )

    kindreg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    sem = root / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = root / "docs/30-architecture/deny-code-registry.md"

    if kindreg.exists():
        ktxt = strip_code_fences(read_text(kindreg))
        if "capshell.exec" in ktxt and "argv_digest" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-argv",
                    path=kindreg.relative_to(root),
                    detail="capshell.exec wiring should mention required argv_digest = digest(CH-ARGV v0)",
                )
            )
        if "CH-ARGV v0" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-argv",
                    path=kindreg.relative_to(root),
                    detail="ACP kind registry should mention CH-ARGV v0 when argv schema exists",
                )
            )

    if sem.exists():
        stxt = strip_code_fences(read_text(sem))
        if "capshell.exec" in stxt and "argv_digest" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-argv",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics should mention argv_digest requirement for capshell.exec when CH-ARGV exists",
                )
            )
        if "argv-bind-failed" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-argv",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include 'argv-bind-failed' when CH-ARGV exists",
                )
            )
        if "ambient PATH" not in stxt or "role=\"exec\"" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-argv",
                    path=sem.relative_to(root),
                    detail=(
                        "ACP validator semantics should pin that capshell.exec selects executables only via CH-ARGV role=\"exec\" "
                        "(no ambient PATH resolution)"
                    ),
                )
            )

    if denyreg.exists():
        dtxt = strip_code_fences(read_text(denyreg))
        if "`argv-bind-failed`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-argv",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define argv-bind-failed when CH-ARGV exists",
                )
            )

    return problems


def lint_capshell_env_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep CH-ENV wiring tight when D-CAPSHELL is in play.

    Rationale:
    - Process environments are a classic ambient-authority seam (PATH/LD_* / proxy vars).
    - If we introduce typed env tokens (CH-ENV), they must remain visible from
      stable validator surfaces (ACP semantics + kind registry) and have a
      deterministic denial code for binding failures.

    This lint is intentionally shallow: it asserts that key docs mention the
    required hooks.
    """
    problems: list[Problem] = []
    env = root / "docs/30-architecture/env-schema-v0.md"
    if not env.exists():
        return problems

    kindreg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    sem = root / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = root / "docs/30-architecture/deny-code-registry.md"

    if kindreg.exists():
        ktxt = strip_code_fences(read_text(kindreg))
        if "capshell.exec" in ktxt and "env_digest" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-env",
                    path=kindreg.relative_to(root),
                    detail="capshell.exec wiring should mention required env_digest = digest(CH-ENV v0)",
                )
            )
        if "CH-ENV v0" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-env",
                    path=kindreg.relative_to(root),
                    detail="ACP kind registry should mention CH-ENV v0 when env schema exists",
                )
            )

    if sem.exists():
        stxt = strip_code_fences(read_text(sem))
        if "capshell.exec" in stxt and "env_digest" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-env",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics should mention env_digest requirement for capshell.exec when CH-ENV exists",
                )
            )
        if "env-bind-failed" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-env",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include 'env-bind-failed' when CH-ENV exists",
                )
            )

    if denyreg.exists():
        dtxt = strip_code_fences(read_text(denyreg))
        if "`env-bind-failed`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-env",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define env-bind-failed when CH-ENV exists",
                )
            )

    return problems



def lint_capshell_cwd_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep CH-CWD wiring tight when D-CAPSHELL is in play.

    Rationale:
    - Current working directory inheritance is a classic ambient-authority seam.
    - If we introduce a typed cwd selector (CH-CWD), it must remain visible from
      stable validator surfaces (ACP semantics + kind registry) and have a
      deterministic denial code for binding failures.

    This lint is intentionally shallow: it asserts that key docs mention the
    required hooks.
    """
    problems: list[Problem] = []
    cwd = root / "docs/30-architecture/cwd-schema-v0.md"
    if not cwd.exists():
        return problems

    kindreg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    sem = root / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = root / "docs/30-architecture/deny-code-registry.md"

    if kindreg.exists():
        ktxt = strip_code_fences(read_text(kindreg))
        if "capshell.exec" in ktxt and "cwd_digest" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-cwd",
                    path=kindreg.relative_to(root),
                    detail="capshell.exec wiring should mention required cwd_digest = digest(CH-CWD v0)",
                )
            )
        if "CH-CWD v0" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-cwd",
                    path=kindreg.relative_to(root),
                    detail="ACP kind registry should mention CH-CWD v0 when cwd schema exists",
                )
            )

    if sem.exists():
        stxt = strip_code_fences(read_text(sem))
        if "capshell.exec" in stxt and "cwd_digest" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-cwd",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics should mention cwd_digest requirement for capshell.exec when CH-CWD exists",
                )
            )
        if "cwd-bind-failed" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-cwd",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include cwd-bind-failed when CH-CWD exists",
                )
            )

    if denyreg.exists():
        dtxt = strip_code_fences(read_text(denyreg))
        if "`cwd-bind-failed`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-cwd",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define cwd-bind-failed when CH-CWD exists",
                )
            )

    return problems




def lint_capshell_stdio_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep CH-STDIO wiring tight when D-CAPSHELL is in play.

    Rationale:
    - Inherited stdio/TTY is a classic ambient-authority seam in workflows.
    - If we introduce typed stdio bindings (CH-STDIO), they must remain visible from
      stable validator surfaces (ACP semantics + kind registry) and have a
      deterministic denial code for binding failures.

    This lint is intentionally shallow: it asserts that key docs mention the
    required hooks.
    """
    problems: list[Problem] = []
    stdio = root / "docs/30-architecture/stdio-schema-v0.md"
    if not stdio.exists():
        return problems

    kindreg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    sem = root / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = root / "docs/30-architecture/deny-code-registry.md"

    if kindreg.exists():
        ktxt = strip_code_fences(read_text(kindreg))
        if "capshell.exec" in ktxt and "stdio_digest" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-stdio",
                    path=kindreg.relative_to(root),
                    detail="capshell.exec wiring should mention required stdio_digest = digest(CH-STDIO v0)",
                )
            )
        if "CH-STDIO v0" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-stdio",
                    path=kindreg.relative_to(root),
                    detail="ACP kind registry should mention CH-STDIO v0 when stdio schema exists",
                )
            )

    if sem.exists():
        stxt = strip_code_fences(read_text(sem))
        if "capshell.exec" in stxt and "stdio_digest" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-stdio",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics should mention stdio_digest requirement for capshell.exec when CH-STDIO exists",
                )
            )
        if "stdio-bind-failed" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-stdio",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include stdio-bind-failed when CH-STDIO exists",
                )
            )

    if denyreg.exists():
        dtxt = strip_code_fences(read_text(denyreg))
        if "`stdio-bind-failed`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-stdio",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define stdio-bind-failed when CH-STDIO exists",
                )
            )

    return problems



def lint_capshell_fdset_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep CH-FDSET wiring tight when D-CAPSHELL is in play.

    Rationale:
    - Inherited handle/FD tables are a classic ambient-authority seam.
    - If we introduce typed extra handle bindings (CH-FDSET), they must remain visible from
      stable validator surfaces (ACP semantics + kind registry) and have a
      deterministic denial code for binding failures.

    This lint is intentionally shallow: it asserts that key docs mention the
    required hooks.
    """
    problems: list[Problem] = []
    fdset = root / "docs/30-architecture/fdset-schema-v0.md"
    if not fdset.exists():
        return problems

    kindreg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    sem = root / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = root / "docs/30-architecture/deny-code-registry.md"

    if kindreg.exists():
        ktxt = strip_code_fences(read_text(kindreg))
        if "capshell.exec" in ktxt and "fdset_digest" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-fdset",
                    path=kindreg.relative_to(root),
                    detail="capshell.exec wiring should mention required fdset_digest = digest(CH-FDSET v0)",
                )
            )
        if "CH-FDSET v0" not in ktxt:
            problems.append(
                Problem(
                    kind="capshell-fdset",
                    path=kindreg.relative_to(root),
                    detail="ACP kind registry should mention CH-FDSET v0 when fdset schema exists",
                )
            )

    if sem.exists():
        stxt = strip_code_fences(read_text(sem))
        if "capshell.exec" in stxt and "fdset_digest" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-fdset",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics should mention fdset_digest requirement for capshell.exec when CH-FDSET exists",
                )
            )
        if "fd-bind-failed" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-fdset",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include fd-bind-failed when CH-FDSET exists",
                )
            )

    if denyreg.exists():
        dtxt = strip_code_fences(read_text(denyreg))
        if "`fd-bind-failed`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-fdset",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define fd-bind-failed when CH-FDSET exists",
                )
            )

    return problems


def lint_capshell_execpack_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep CH-EXECPACK wiring tight (prevents ambient workflow context by omission).

    Rationale:
    - D-CAPSHELL depends on *complete* explicit workflow context (contract+argv+env+cwd+stdio+fdset).
    - Missing any binding tends to fall back to inherited/ambient host process context.
    - CH-EXECPACK provides a single stable digest surface (`exec_pack_digest`) for `capshell.exec`.

    This lint is intentionally shallow: it checks that the key discovery and validator surfaces
    mention CH-EXECPACK when the schema exists.
    """
    problems: list[Problem] = []
    pack_v2 = root / "docs/30-architecture/capshell-exec-pack-schema-v2.md"
    pack_v1 = root / "docs/30-architecture/capshell-exec-pack-schema-v1.md"
    pack_v0 = root / "docs/30-architecture/capshell-exec-pack-schema-v0.md"
    if pack_v2.exists():
        pack = pack_v2
    elif pack_v1.exists():
        pack = pack_v1
    else:
        pack = pack_v0
    if not pack.exists():
        return problems

    ptxt = strip_code_fences(read_text(pack))
    required_fields = [
        "exec_pack_digest",
    ]
    # v1+ bind reqctx_digest to prevent implicit correlation/cancel context.
    if pack != pack_v0:
        required_fields.append("reqctx_digest")

    required_fields += [
        "effcon_digest",
        "argv_digest",
        "env_digest",
        "cwd_digest",
        "stdio_digest",
        "fdset_digest",
    ]
    missing = [f for f in required_fields if f not in ptxt]
    if missing:
        problems.append(
            Problem(
                kind="capshell-execpack",
                path=pack.relative_to(root),
                detail=f"CH-EXECPACK schema should mention required fields: {', '.join(missing)}",
            )
        )

    schemareg = root / "docs/30-architecture/schema-registry.md"
    if schemareg.exists():
        stxt = strip_code_fences(read_text(schemareg))
        if "CH-EXECPACK v2" not in stxt or "capshell-exec-pack-schema-v2.md" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=schemareg.relative_to(root),
                    detail="schema registry should include CH-EXECPACK v2 and point to capshell-exec-pack-schema-v2.md",
                )
            )

    docsreadme = root / "docs/README.md"
    if docsreadme.exists():
        dtxt = strip_code_fences(read_text(docsreadme))
        if "capshell-exec-pack-schema-v2.md" not in dtxt or "CH-EXECPACK v2" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=docsreadme.relative_to(root),
                    detail="docs/README.md should index CH-EXECPACK v2 (discovery surface)",
                )
            )

    kindreg = root / "docs/70-llm-control/acp-action-kind-registry.md"
    if kindreg.exists():
        ktxt = strip_code_fences(read_text(kindreg))
        if "capshell.exec" in ktxt and ("exec_pack_digest" not in ktxt or "CH-EXECPACK v2" not in ktxt):
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=kindreg.relative_to(root),
                    detail="ACP kind registry should mention exec_pack_digest = digest(CH-EXECPACK v2) for capshell.exec",
                )
            )

    sem = root / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = root / "docs/30-architecture/deny-code-registry.md"

    if sem.exists():
        stxt = strip_code_fences(read_text(sem))
        if "capshell.exec" in stxt and "exec_pack_digest" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics should require exec_pack_digest for capshell.exec when CH-EXECPACK exists",
                )
            )
        if "execpack-missing" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include execpack-missing when CH-EXECPACK exists",
                )
            )

        if pack != pack_v0 and "reqctx-mismatch" not in stxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=sem.relative_to(root),
                    detail="ACP validator semantics deny-code list should include reqctx-mismatch when CH-EXECPACK v2 exists",
                )
            )

    if denyreg.exists():
        dtxt = strip_code_fences(read_text(denyreg))
        if "`execpack-missing`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define execpack-missing when CH-EXECPACK exists",
                )
            )

        if pack != pack_v0 and "`reqctx-mismatch`" not in dtxt:
            problems.append(
                Problem(
                    kind="capshell-execpack",
                    path=denyreg.relative_to(root),
                    detail="deny-code registry should define reqctx-mismatch when CH-EXECPACK v2 exists",
                )
            )

    return problems


def lint_capshell_cli_plumbing_wiring(root: Path) -> list[Problem]:
    """Guardrail: keep the CLI plumbing doc aligned with D-CAPSHELL bindings.

    Rationale:
    - Workflow/tooling docs are common drift surfaces (LLM edits add a new binding schema
      but forget to update workflow guidance).
    - The CLI ecosystem is where ambient authority sneaks back in (PATH/env/cwd/stdio/FD table).

    This lint is intentionally shallow: it checks that the capshell integration section
    in docs/60-engineering/cli-plumbing-tooling.md mentions the binding schemas that
    exist in the repo.
    """
    problems: list[Problem] = []
    doc = root / "docs/60-engineering/cli-plumbing-tooling.md"
    if not doc.exists():
        return problems

    txt = strip_code_fences(read_text(doc))

    required: list[tuple[Path, str]] = [
        (root / "docs/30-architecture/capshell-exec-pack-schema-v2.md", "CH-EXECPACK v2"),
        (root / "docs/30-architecture/request-context-schema-v1.md", "CH-REQCTX v1"),
        (root / "docs/30-architecture/argv-schema-v0.md", "CH-ARGV v0"),
        (root / "docs/30-architecture/env-schema-v0.md", "CH-ENV v0"),
        (root / "docs/30-architecture/cwd-schema-v0.md", "CH-CWD v0"),
        (root / "docs/30-architecture/stdio-schema-v0.md", "CH-STDIO v0"),
        (root / "docs/30-architecture/fdset-schema-v0.md", "CH-FDSET v0"),
    ]

    missing: list[str] = []
    for p, token in required:
        if p.exists() and token not in txt:
            missing.append(token)
    if missing:
        problems.append(
            Problem(
                kind="capshell-cli",
                path=doc.relative_to(root),
                detail=f"capshell integration section should mention: {', '.join(missing)}",
            )
        )

    # If CH-ARGV exists, keep the ambient PATH seam explicitly called out.
    if (root / "docs/30-architecture/argv-schema-v0.md").exists():
        if "ambient PATH" not in txt or "role=\"exec\"" not in txt:
            problems.append(
                Problem(
                    kind="capshell-cli",
                    path=doc.relative_to(root),
                    detail=(
                        "capshell integration should explicitly forbid ambient PATH resolution and "
                        "require CH-ARGV role=\"exec\" for executable selection"
                    ),
                )
            )

    return problems


def lint_hot_action_boundaries(root: Path) -> list[Problem]:
    """Ensure hot-action-boundaries v0 exists and names a boundary per pinned hot family.

    Rationale: D-COMMUTE + Hybrid only stay honest if we explicitly state the *minimal*
    correctness-required serialization boundary (or explicit 'none') for each hot family.
    """
    problems: list[Problem] = []
    bdoc = root / "docs/30-architecture/hot-action-boundaries-v0.md"
    sdoc = root / "docs/30-architecture/hot-action-surface-v0.md"
    if not sdoc.exists():
        return problems
    if not bdoc.exists():
        problems.append(
            Problem(
                kind="hot-actions",
                path=sdoc.relative_to(root),
                detail="missing docs/30-architecture/hot-action-boundaries-v0.md (required by hot action surface)",
            )
        )
        return problems

    txt = strip_code_fences(read_text(bdoc))

    # Each family must have a dedicated section with an explicit boundary line.
    headers = {
        "mem": r"^###\s+`mem\.map`\s*/\s*`mem\.unmap`",
        "ipc": r"^###\s+IPC endpoint ops\b",
        "view": r"^###\s+`view\.attach`\s*/\s*`view\.detach`",
        "log": r"^###\s+Transcript/receipt append\b",
        "budget": r"^###\s+Meter/budget charge\b",
    }

    # Find section spans.
    lines = txt.splitlines()
    idx: dict[str, int] = {}
    for i, line in enumerate(lines):
        for k, pat in headers.items():
            if k in idx:
                continue
            if re.search(pat, line):
                idx[k] = i

    for k, pat in headers.items():
        if k not in idx:
            problems.append(
                Problem(
                    kind="hot-actions",
                    path=bdoc.relative_to(root),
                    detail=f"missing required section header for {k} (pattern: {pat})",
                )
            )

    # For each found section, require an explicit 'Non-commutative boundary:' line.
    for k, start in idx.items():
        # end at next '###' or end of file
        end = len(lines)
        for j in range(start + 1, len(lines)):
            if lines[j].startswith("### "):
                end = j
                break
        body = "\n".join(lines[start:end])
        if "Non-commutative boundary:" not in body:
            problems.append(
                Problem(
                    kind="hot-actions",
                    path=bdoc.relative_to(root),
                    detail=f"section '{k}' must include an explicit 'Non-commutative boundary:' statement (or 'none')",
                )
            )
        if "Replication contract:" not in body:
            problems.append(
                Problem(
                    kind="hot-actions",
                    path=bdoc.relative_to(root),
                    detail=f"section '{k}' must include an explicit 'Replication contract:' statement (RC0..RC4)",
                )
            )
        if "Ordering token:" not in body:
            problems.append(
                Problem(
                    kind="hot-actions",
                    path=bdoc.relative_to(root),
                    detail=f"section '{k}' must include an explicit 'Ordering token:' statement (CH-ORDERTOK v0 or none)",
                )
            )
        if "Conflict key:" not in body:
            problems.append(
                Problem(
                    kind="hot-actions",
                    path=bdoc.relative_to(root),
                    detail=f"section '{k}' must include an explicit 'Conflict key:' statement (digest(CH-CONFLICTKEY v0))",
                )
            )

    return problems

def lint_conflictkey_family_coherence(root: Path) -> list[Problem]:
    """Guardrail: keep conflict-key family names coherent across the archive.

    Rationale:
    - D-COMMUTE and Hybrid rely on conflict keys as a stable, reviewable artifact surface.
    - If ACP kind metadata or sealed-compat receipts name a family not present in CH-CONFLICTKEY,
      validators and evidence harnesses silently drift (LLM edits are especially prone to this).
    """
    problems: list[Problem] = []
    schema = root / "docs/30-architecture/conflict-key-schema-v0.md"
    if not schema.exists():
        return problems

    stxt = strip_code_fences(read_text(schema))

    # Extract the allowlist from the numbered family section.
    start = stxt.find("### Family payloads")
    if start < 0:
        problems.append(
            Problem(
                kind="conflictkey-family",
                path=schema.relative_to(root),
                detail="missing '### Family payloads' section (cannot extract family allowlist)",
            )
        )
        return problems

    end = stxt.find("## Validation rules", start)
    if end < 0:
        end = len(stxt)
    block = stxt[start:end]
    allow = set(re.findall(r"^\s*\d+\)\s+`([^`]+)`\s*$", block, flags=re.M))
    if not allow:
        problems.append(
            Problem(
                kind="conflictkey-family",
                path=schema.relative_to(root),
                detail="could not extract family allowlist (expected lines like '1) `mem.range`')",
            )
        )
        return problems

    refs: set[str] = set()
    for rel in [
        "docs/70-llm-control/acp-action-kind-registry.md",
        "docs/30-architecture/hot-action-boundaries-v0.md",
        "docs/30-architecture/fcell-adapter-receipt-schema-v0.md",
    ]:
        p = root / rel
        if not p.exists():
            continue
        body = strip_code_fences(read_text(p))
        refs.update(re.findall(r'family="([^"]+)"', body))
        refs.update(re.findall(r"family=`([^`]+)`", body))

    refs = {r.strip() for r in refs if r.strip()}
    missing = sorted(refs - allow)
    if missing:
        problems.append(
            Problem(
                kind="conflictkey-family",
                path=schema.relative_to(root),
                detail=f"CH-CONFLICTKEY is missing family definition(s) referenced elsewhere: {', '.join(missing)}",
            )
        )

    return problems




def lint_conflictkey_derivation_commitments(root: Path) -> list[Problem]:
    '''Guardrail: pin deterministic derivation rules for ACP-visible conflict keys.

    Rationale:
    - D-COMMUTE and Hybrid rely on conflict keys as a stable diff surface.
    - Ambiguity in *how* we derive keys (double-hashing, param aliasing) is a high-risk drift seam,
      especially under LLM edits.

    This check enforces that CH-CONFLICTKEY v0 explicitly documents derivation commitments for
    ACP-visible families (`policy.param`, `domain.id`) and that the ACP kind registry references
    those commitments.
    '''
    problems: list[Problem] = []

    schema = root / "docs/30-architecture/conflict-key-schema-v0.md"
    reg = root / "docs/70-llm-control/acp-action-kind-registry.md"

    if schema.exists():
        stxt = strip_code_fences(read_text(schema))
        if "### Derivation commitments" not in stxt:
            problems.append(
                Problem(
                    kind="conflictkey-derive",
                    path=schema.relative_to(root),
                    detail="missing '### Derivation commitments' section (pin ACP-visible derivation rules for policy.param and domain.id)",
                )
            )
        else:
            for tok in ["policy.param", "domain.id", "ck_domain("]:
                if tok not in stxt:
                    problems.append(
                        Problem(
                            kind="conflictkey-derive",
                            path=schema.relative_to(root),
                            detail=f"derivation commitments section should mention '{tok}'",
                        )
                    )

    if reg.exists():
        rtxt = strip_code_fences(read_text(reg))
        # Ensure registry uses the pinned helper for domain keys and makes policy.param keys explicit.
        if "ck_domain(" not in rtxt:
            problems.append(
                Problem(
                    kind="conflictkey-derive",
                    path=reg.relative_to(root),
                    detail="ACP kind registry should use 'ck_domain(..)' for domain.id conflict keys (prevents double-hash drift)",
                )
            )
        if "payload={param=<cfg.params.* key>}" not in rtxt and "policy.param" in rtxt:
            problems.append(
                Problem(
                    kind="conflictkey-derive",
                    path=reg.relative_to(root),
                    detail="ACP kind registry should spell `policy.param` payload as an exact cfg key (e.g., payload={param=<cfg.params.* key>})",
                )
            )
        if "conflict-key-schema-v0.md" not in rtxt:
            problems.append(
                Problem(
                    kind="conflictkey-derive",
                    path=reg.relative_to(root),
                    detail="ACP kind registry should reference conflict-key-schema-v0.md derivation commitments (prevents hidden drift)",
                )
            )

    return problems



def lint_rfc_decision_map_coverage(root: Path) -> list[Problem]:
    """Ensure any D-* referenced by an RFC header has a node in the decision-map.

    Rationale: prevent RFCs from drifting away from the architecture decision graph.
    This is intentionally *one-way*: decision-map can contain placeholders, but RFCs
    should not introduce unseen D-nodes.
    """
    problems: list[Problem] = []
    dmap = root / "docs/30-architecture/decision-map.md"
    rfcs = root / "rfcs"
    if not dmap.exists() or not rfcs.exists():
        return problems

    d_nodes: set[str] = set()
    for line in read_text(dmap).splitlines():
        m = re.match(r"^##\s+(D-[A-Z][A-Z0-9-]*)\b", line.strip())
        if m:
            d_nodes.add(m.group(1))

    # Only check the header region to avoid accidental mentions in background text.
    tok_re = re.compile(r"\bD-[A-Z][A-Z0-9-]*\b")
    for rfc in sorted(rfcs.glob("[0-9][0-9][0-9][0-9]-*.md")):
        header = "\n".join(read_text(rfc).splitlines()[:80])
        header = strip_code_fences(header)
        for tok in sorted(set(tok_re.findall(header))):
            if tok not in d_nodes:
                problems.append(
                    Problem(
                        "decision-map",
                        rfc.relative_to(root),
                        f"RFC header references {tok} but decision-map lacks a node",
                    )
                )

    return problems




def lint_decision_map_unique(root: Path) -> list[Problem]:
    problems: list[Problem] = []
    dmap = root / "docs/30-architecture/decision-map.md"
    if not dmap.exists():
        return problems
    seen: dict[str, int] = {}
    for i, line in enumerate(read_text(dmap).splitlines(), start=1):
        m = re.match(r"^##\s+(D-[A-Z][A-Z0-9-]*)\b", line.strip())
        if not m:
            continue
        did = m.group(1)
        if did in seen:
            problems.append(
                Problem(
                    kind="decision-map-dupe",
                    path=dmap.relative_to(root),
                    detail=f"{did} duplicated (first at L{seen[did]}, again at L{i})",
                )
            )
        else:
            seen[did] = i
    return problems


def lint_schema_registry_unique(root: Path) -> list[Problem]:
    problems: list[Problem] = []
    reg = root / "docs/30-architecture/schema-registry.md"
    if not reg.exists():
        return problems
    seen: dict[str, int] = {}
    for i, line in enumerate(strip_code_fences(read_text(reg)).splitlines(), start=1):
        if not line.strip().startswith("| CH-"):
            continue
        # First column up to next '|'
        cols = [c.strip() for c in line.strip().strip("|").split("|")]
        if not cols:
            continue
        key = cols[0]
        if key in seen:
            problems.append(
                Problem(
                    kind="schema-dupe",
                    path=reg.relative_to(root),
                    detail=f"{key} duplicated (first at L{seen[key]}, again at L{i})",
                )
            )
        else:
            seen[key] = i
    return problems




def lint_multicore_posture_consistency(root: Path) -> list[Problem]:
    """Guardrail: keep the archive's multicore posture consistent with the charter.

    Rationale:
    - Pillar: multicore verification is required; we do not ship a single-core-only kernel.
    - We allow UP-only bring-up prototypes, but docs/policies must not drift into treating
      "single-core" as the default or as the verification end-state.

    This lint is intentionally narrow (only checks a few canonical policy docs) to avoid
    false positives in historical discussions.
    """
    problems: list[Problem] = []

    checks = {
        "docs/30-architecture/decision-map.md": [
            (r"\(if SMP\)", "D-MEMMODEL must not be conditional on SMP; multicore is a baseline requirement"),
        ],
        "docs/30-architecture/mechanisms.md": [
            (r"multicore as a Phase 3 axis", "mechanisms.md must not frame multicore as a later phase; only refinements are staged"),
            (r"Start constrained \(" , "mechanisms.md should not reintroduce single-core-first scheduling guidance"),
        ],
        "docs/60-engineering/unsafe-concurrency-policy.md": [
            (r"single-core only \(Phase", "unsafe-concurrency-policy must not treat single-core-only as the default"),
            (r"Phase 3", "unsafe-concurrency-policy must not frame multicore as Phase 3; use D-CONC staged options"),
        ],
        "docs/20-assurance/unsafe-obligation-registry.md": [
            (r"prefer single-core early", "unsafe obligations must not recommend single-core as a strategy"),
            (r"avoid until we commit to SMP", "unsafe obligations must assume SMP baseline; avoid lock-free is OK but not 'commit to SMP'"),
            (r"stage SMP later", "unsafe obligations must not defer SMP as a later stage"),
        ],
        "docs/30-architecture/abstract-machine.md": [
            (r"single-core profile", "abstract machine should treat UP-only as bring-up, not a product profile"),
        ],
        "docs/10-threat-model/abuse-cases.md": [
            (r"C-CONC-1 \(Phase 3", "abuse-cases must not defer concurrency safety to Phase 3"),
        ],
    }

    for rel, pats in checks.items():
        path = root / rel
        if not path.exists():
            continue
        body = strip_code_fences(read_text(path))
        for pat, msg in pats:
            if re.search(pat, body):
                problems.append(Problem(kind="multicore-posture", path=path.relative_to(root), detail=msg))

    # Positive anchor: decision map must explicitly name the baseline posture.
    dmap = root / "docs/30-architecture/decision-map.md"
    if dmap.exists():
        dbody = strip_code_fences(read_text(dmap))
        if "D-MEMMODEL: memory model stance (SMP/Hybrid baseline)" not in dbody:
            problems.append(
                Problem(
                    kind="multicore-posture",
                    path=dmap.relative_to(root),
                    detail="decision map must include 'D-MEMMODEL: memory model stance (SMP/Hybrid baseline)'",
                )
            )

    return problems

def lint_no_tbd(root: Path) -> list[Problem]:
    """Fail on TODO placeholders in prose.

    Rationale: leaving "TBD" in normative docs/RFCs tends to rot into an implicit decision.
    We allow TODOs in code blocks and in tooling output, but not in the living archive prose.
    """
    problems: list[Problem] = []
    # Scan only prose-y trees.
    for rel in [Path('docs'), Path('rfcs'), Path('adrs')]:
        base = root / rel
        if not base.exists():
            continue
        for path in base.rglob('*.md'):
            body = strip_code_fences(read_text(path))
            if re.search(r"\bTBD\b", body):
                problems.append(
                    Problem(
                        kind='tbd-placeholder',
                        path=path.relative_to(root),
                        detail='contains "TBD" placeholder; resolve or rewrite to a bounded statement',
                    )
                )
    return problems


def main() -> int:
    root = repo_root()
    defined = collect_defined_ids(root)

    checks = [
        lint_numbering_unique,
        lint_internal_links,
        lint_index_tables,
        lint_inline_repo_paths,
        lint_pledge_token_consistency,
        lint_portal_family_registry_consistency,
        lint_fcell_portal_token_consistency,
        lint_cfg_toggle_registry_consistency,
        lint_acp_action_kind_registry,
        lint_log_and_receipt_action_metadata,
        lint_capshell_argv_wiring,
        lint_capshell_env_wiring,
        lint_capshell_cwd_wiring,
        lint_capshell_stdio_wiring,
        lint_capshell_fdset_wiring,
        lint_capshell_execpack_wiring,
        lint_capshell_cli_plumbing_wiring,
        lint_deny_code_registry_consistency,
        lint_rrbundle_denial_closure,
        lint_hot_action_boundaries,
        lint_conflictkey_family_coherence,
        lint_conflictkey_derivation_commitments,
        lint_multicore_posture_consistency,
        lint_no_raw_urls,
        lint_no_tbd,
        lambda r: lint_undefined_ids(r, defined),
        lambda r: lint_traceability(r, defined),
        lint_rfc_decision_map_coverage,
        lint_decision_map_unique,
        lint_schema_registry_unique,
        lint_schema_docs_registered,
        lint_schema_registry_pointers,
    ]

    problems: list[Problem] = []
    for check in checks:
        problems.extend(check(root))

    if problems:
        print("Archive lint FAILED:\n")
        for p in problems:
            print(f"- [{p.kind}] {p.path}: {p.detail}")
        print("\nFix issues or update registries/refs accordingly.")
        return 1

    print("Archive lint OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
