#!/usr/bin/env python3
"""CI drift gate: privileged interface (IF-*) references are registry-closed.

Source of truth:
  - docs/30-architecture/interface-registry.md

Fail-closed checks:
  - Parse the canonical IF-ID set from the registry table.
  - Scan repo markdown (docs/, rfcs/, adrs/, README.md) for IF-FOO style tokens.
  - Any referenced IF-ID must be present in the registry.

Rationale:
  - IF-IDs are privileged entrypoints/control surfaces.
  - Typos or "shadow" IF-IDs in prose are a classic drift/amnesia seam
    (especially under LLM edits) and weaken I-IF-1.
  - Keeping the IF-ID vocabulary closed supports stable diff surfaces and
    reviewability.

Design constraints: dependency-free, conservative parsing, deterministic.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Problem:
    path: str
    line: int
    token: str
    detail: str


ROOT = Path(__file__).resolve().parents[1]

REG = ROOT / "docs/30-architecture/interface-registry.md"

# Match IF-<NAME> where NAME begins with a letter (avoids matching I-IF-1 -> IF-1).
RE_IF = re.compile(r"\bIF-[A-Z][A-Z0-9-]*\b")

# Tokens that are not interface IDs (table headers / prose).
IF_EXCEPTIONS = {"IF-ID", "IF-IDs"}


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def parse_if_ids(reg_md: str) -> set[str]:
    """Parse IF-IDs from the first markdown table whose header contains 'IF-ID'."""
    ids: list[str] = []
    in_table = False
    for ln in reg_md.splitlines():
        s = ln.strip()
        if s.startswith("| IF-ID "):
            in_table = True
            continue
        if not in_table:
            continue
        if not s.startswith("|"):
            if ids:
                break
            continue
        if s.startswith("|---"):
            continue
        cols = [c.strip() for c in s.strip("|").split("|")]
        if not cols:
            continue
        tok = cols[0]
        if tok.startswith("IF-"):
            ids.append(tok)
    if not ids:
        raise ValueError("failed to parse any IF-IDs from interface registry table")
    return set(ids)


def markdown_files() -> list[Path]:
    paths: list[Path] = []
    for d in ("docs", "rfcs", "adrs"):
        p = ROOT / d
        if p.exists():
            paths.extend(p.rglob("*.md"))
    # Root README.md is also a discovery surface.
    if (ROOT / "README.md").exists():
        paths.append(ROOT / "README.md")
    return sorted(set(paths))


def main() -> int:
    if not REG.exists():
        print(f"ERROR: missing interface registry: {REG.relative_to(ROOT)}")
        return 2

    try:
        canonical = parse_if_ids(read(REG))
    except ValueError as e:
        print(f"ERROR: {e}")
        return 2

    problems: list[Problem] = []

    for p in markdown_files():
        txt = read(p)
        for i, ln in enumerate(txt.splitlines(), start=1):
            for m in RE_IF.finditer(ln):
                tok = m.group(0)
                if tok in IF_EXCEPTIONS:
                    continue
                if tok not in canonical:
                    problems.append(
                        Problem(
                            path=str(p.relative_to(ROOT)),
                            line=i,
                            token=tok,
                            detail="IF-ID not present in docs/30-architecture/interface-registry.md",
                        )
                    )

    if problems:
        print("IF-ID reference drift detected:\n")
        for pr in problems[:40]:
            print(f"- {pr.path}:{pr.line}: {pr.token}: {pr.detail}")
        if len(problems) > 40:
            print(f"... ({len(problems) - 40} more)")
        print(
            "\nFix: add the IF-ID to interface-registry.md (if it is a real privileged surface), "
            "or correct/remove the stray reference."
        )
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
