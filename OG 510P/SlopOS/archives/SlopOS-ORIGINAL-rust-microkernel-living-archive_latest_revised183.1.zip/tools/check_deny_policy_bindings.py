#!/usr/bin/env python3
"""Policy-deny digest-binding drift gate.

Why this exists
--------------
Least-authority and sealed-kill-switch posture depends on *explicit* policy handles.
A common drift seam is that policy/authority failures devolve into ad-hoc strings
("policy denied", "missing approval") without naming *which* pinned policy handle
was in force.

We treat CH-DENY v0 as the stable, redaction-safe denial surface. This check
ensures that policy-related deny codes are wired to a *digest* binding across the
canonical docs:
- deny-code-registry.md (required bindings)
- denial-receipt-schema-v0.md (producer rules)
- acp-validator-semantics.md (ACP-specific guidance)

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[deny-policy-bind] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[deny-policy-bind] OK: {msg}")


def must_contain(p: Path, pattern: str, desc: str) -> None:
    txt = read(p)
    if re.search(pattern, txt, flags=re.MULTILINE) is None:
        fail(
            f"{p.relative_to(repo_root())}: missing required anchor for {desc} (pattern: {pattern})"
        )


def main() -> None:
    root = repo_root()

    p_reg = root / "docs/30-architecture/deny-code-registry.md"
    p_deny = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    p_acp = root / "docs/70-llm-control/acp-validator-semantics.md"

    for p in [p_reg, p_deny, p_acp]:
        if not p.exists():
            fail(f"missing required file: {p}")

    # deny-code-registry.md: required bindings must be explicit.
    must_contain(
        p_reg,
        r"^\| `missing-approval` \|.*`reason\.ref_digest` MUST be present = `digest\(CH-POLICY v0\)`.*`digest\(CH-POLICYHANDLE v0\)`",
        "missing-approval requires policy digest/handle binding",
    )
    must_contain(
        p_reg,
        r"^\| `expired-approval` \|.*`reason\.ref_digest` MUST be present = `digest\(CH-POLICY v0\)`.*`digest\(CH-POLICYHANDLE v0\)`",
        "expired-approval requires policy digest/handle binding",
    )
    must_contain(
        p_reg,
        r"^\| `policy-deny` \|.*`reason\.ref_digest` MUST be present = `digest\(CH-POLICY v0\)`.*`digest\(CH-POLICYHANDLE v0\)`",
        "policy-deny requires policy digest/handle binding",
    )

    # denial-receipt-schema-v0.md: producer rules must bind reason.kind + digest.
    must_contain(
        p_deny,
        r"deny_code == missing-approval.*reason\.kind = \"policy\"",
        "CH-DENY producer rule: missing-approval sets reason.kind=policy",
    )
    must_contain(
        p_deny,
        r"deny_code == missing-approval.*reason\.ref_digest = digest\(CH-POLICY v0\).*CH-POLICYHANDLE v0",
        "CH-DENY producer rule: missing-approval binds policy digest or handle",
    )
    must_contain(
        p_deny,
        r"deny_code == expired-approval.*reason\.kind = \"policy\"",
        "CH-DENY producer rule: expired-approval sets reason.kind=policy",
    )
    must_contain(
        p_deny,
        r"deny_code == expired-approval.*reason\.ref_digest = digest\(CH-POLICY v0\).*CH-POLICYHANDLE v0",
        "CH-DENY producer rule: expired-approval binds policy digest or handle",
    )
    must_contain(
        p_deny,
        r"deny_code == policy-deny.*reason\.kind = \"policy\"",
        "CH-DENY producer rule: policy-deny sets reason.kind=policy",
    )
    must_contain(
        p_deny,
        r"deny_code == policy-deny.*reason\.ref_digest = digest\(CH-POLICY v0\).*CH-POLICYHANDLE v0",
        "CH-DENY producer rule: policy-deny binds policy digest or handle",
    )

    # ACP semantics must have a dedicated section that names the bindings.
    must_contain(
        p_acp,
        r"^### Policy/authority denials are digest-bound",
        "ACP semantics section header",
    )
    must_contain(
        p_acp,
        r"deny_code = missing-approval.*reason\.ref_digest = digest\(CH-POLICY v0\).*CH-POLICYHANDLE v0",
        "ACP semantics: missing-approval binding includes handle",
    )
    must_contain(
        p_acp,
        r"deny_code = expired-approval.*reason\.ref_digest = digest\(CH-POLICY v0\).*CH-POLICYHANDLE v0",
        "ACP semantics: expired-approval binding includes handle",
    )
    must_contain(
        p_acp,
        r"deny_code = policy-deny.*reason\.ref_digest = digest\(CH-POLICY v0\).*CH-POLICYHANDLE v0",
        "ACP semantics: policy-deny binding includes handle",
    )

    ok("policy/authority CH-DENY bindings are explicitly wired (deny-code registry + schema + ACP semantics)")


if __name__ == "__main__":
    main()
