#!/usr/bin/env python3
"""Ordering-deny digest-binding drift gate.

Why this exists
--------------
D-COMMUTE requires that ordering/commutativity boundaries remain explicit and
reviewable. A common drift seam is that ordering failures devolve into vague
prose/log strings ("ordering failed") without a stable, schema-pinned binding to:
- which serialization domain (conflict key) was involved, and
- which ordering witness was rejected.

We treat CH-DENY v0 as the stable, redaction-safe denial surface. This check
ensures that ordering-related deny codes are wired to *digest* fields, not ad-hoc
messages, across the canonical docs:
- deny-code-registry.md (required bindings)
- denial-receipt-schema-v0.md (producer rules)
- acp-validator-semantics.md (ACP-specific guidance)

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[deny-order-bind] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[deny-order-bind] OK: {msg}")


def must_contain(p: Path, pattern: str, desc: str) -> None:
    txt = read(p)
    if re.search(pattern, txt, flags=re.MULTILINE) is None:
        fail(f"{p.relative_to(repo_root())}: missing required anchor for {desc} (pattern: {pattern})")


def main() -> None:
    root = repo_root()

    p_reg = root / "docs/30-architecture/deny-code-registry.md"
    p_deny = root / "docs/30-architecture/denial-receipt-schema-v0.md"
    p_acp = root / "docs/70-llm-control/acp-validator-semantics.md"

    for p in [p_reg, p_deny, p_acp]:
        if not p.exists():
            fail(f"missing required file: {p}")

    # deny-code-registry.md: required bindings must be explicit.
    must_contain(
        p_reg,
        r"^\| `conflict-key-invalid` \|.*`conflict_key_digest` MUST be present",
        "conflict-key-invalid requires conflict_key_digest",
    )
    must_contain(
        p_reg,
        r"^\| `conflict-key-invalid` \|.*meta\.conflict_key_digest",
        "conflict-key-invalid ties rejecting digest to meta.conflict_key_digest for CH-ACP",
    )
    must_contain(
        p_reg,
        r"^\| `order-witness-missing` \|.*`conflict_key_digest` MUST be present",
        "order-witness-missing requires conflict_key_digest",
    )
    must_contain(
        p_reg,
        r"^\| `order-witness-invalid` \|.*`order_digest` MUST be present",
        "order-witness-invalid requires order_digest",
    )

    # denial-receipt-schema-v0.md: producer rules must bind reason.kind + digests.
    must_contain(
        p_deny,
        r"deny_code == conflict-key-invalid.*reason\.kind = \"ordering\"",
        "CH-DENY producer rule: conflict-key-invalid sets reason.kind=ordering",
    )
    must_contain(
        p_deny,
        r"deny_code == conflict-key-invalid.*conflict_key_digest",
        "CH-DENY producer rule: conflict-key-invalid binds conflict_key_digest",
    )
    must_contain(
        p_deny,
        r"deny_code == conflict-key-invalid.*meta\.conflict_key_digest",
        "CH-DENY producer rule: conflict-key-invalid ties to meta.conflict_key_digest",
    )
    must_contain(
        p_deny,
        r"deny_code == order-witness-missing.*reason\.kind = \"ordering\"",
        "CH-DENY producer rule: order-witness-missing sets reason.kind=ordering",
    )
    must_contain(
        p_deny,
        r"deny_code == order-witness-missing.*conflict_key_digest",
        "CH-DENY producer rule: order-witness-missing binds conflict_key_digest",
    )
    must_contain(
        p_deny,
        r"deny_code == order-witness-invalid.*reason\.kind = \"ordering\"",
        "CH-DENY producer rule: order-witness-invalid sets reason.kind=ordering",
    )
    must_contain(
        p_deny,
        r"deny_code == order-witness-invalid.*order_digest",
        "CH-DENY producer rule: order-witness-invalid binds order_digest",
    )

    # ACP semantics must have a dedicated section that names the bindings.
    must_contain(
        p_acp,
        r"^### Ordering denials are digest-bound",
        "ACP semantics section header",
    )
    must_contain(
        p_acp,
        r"deny_code = conflict-key-invalid.*conflict_key_digest",
        "ACP semantics: conflict-key-invalid binding",
    )
    must_contain(
        p_acp,
        r"deny_code = order-witness-missing.*conflict_key_digest",
        "ACP semantics: order-witness-missing binding",
    )
    must_contain(
        p_acp,
        r"deny_code = order-witness-invalid.*order_digest",
        "ACP semantics: order-witness-invalid binding",
    )

    ok("ordering-related CH-DENY bindings are explicitly wired (deny-code registry + schema + ACP semantics)")


if __name__ == "__main__":
    main()
