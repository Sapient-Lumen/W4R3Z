#!/usr/bin/env python3
"""CI drift gate: keep D-* decision references closed + discoverable.

Rationale
---------
The decision map is a stable diff surface for the archive's "authority substrate":
changes should be routed through explicit, reviewable decision nodes.

LLM (and human) edits often reference new D-* identifiers without wiring them
into the canonical decision map. That creates silent drift:
- reviewers can't find the decision's evidence surface,
- tooling can't reliably anchor "decision → schemas → invariants → POs → evidence".

Source of truth
---------------
- docs/30-architecture/decision-map.md (headings "## D-FOO: ...")

Checks (fail closed)
--------------------
1) Parse the set of decision ids from decision-map headings.
2) Scan docs/ for any word-boundary D-* tokens (excluding code fences) and fail
   if any referenced decision id is not present in the decision map.

Design constraints
------------------
- Tiny, dependency-free, deterministic.
- Conservative: scans only docs/ (not rfcs/ or adrs/) to avoid blocking proposal
  documents that may mention future decision ids.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from dataclasses import dataclass


ROOT = Path(__file__).resolve().parents[1]
DECISION_MAP = ROOT / "docs/30-architecture/decision-map.md"
DOCS_DIR = ROOT / "docs"

RE_DECISION_HEADING = re.compile(r"^##\s+(D-[A-Z0-9][A-Z0-9-]*)\b", re.M)
RE_DECISION_TOKEN = re.compile(r"\b(D-[A-Z0-9][A-Z0-9-]{1,})\b")


@dataclass
class Ref:
    path: str
    line: int


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def strip_code_fences(md: str) -> str:
    """Remove fenced code blocks (```...```) to reduce false positives."""
    out: list[str] = []
    in_fence = False
    for ln in md.splitlines():
        s = ln.strip()
        if s.startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(ln)
    return "\n".join(out)


def fail(msg: str) -> int:
    print(f"[decision-map] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[decision-map] OK: {msg}")


def parse_decisions(decision_map_md: str) -> list[str]:
    ids = RE_DECISION_HEADING.findall(decision_map_md)
    return ids


def scan_docs_for_decisions() -> tuple[set[str], dict[str, list[Ref]]]:
    """Return (decision_tokens, locations) across docs/."""
    toks: set[str] = set()
    locs: dict[str, list[Ref]] = {}

    for p in sorted(DOCS_DIR.rglob("*.md")):
        # Exclude the canonical decision map itself.
        if p == DECISION_MAP:
            continue
        rel = str(p.relative_to(ROOT))
        txt = strip_code_fences(read(p))
        for i, ln in enumerate(txt.splitlines(), start=1):
            for m in RE_DECISION_TOKEN.finditer(ln):
                tok = m.group(1)
                # Ignore placeholder-ish tokens (rare) like "D-*" (won't match) or "D-<X>".
                if "<" in tok or ">" in tok or "*" in tok:
                    continue
                toks.add(tok)
                locs.setdefault(tok, []).append(Ref(rel, i))

    return toks, locs


def main() -> int:
    if not DECISION_MAP.exists():
        return fail("missing docs/30-architecture/decision-map.md")
    if not DOCS_DIR.exists():
        return fail("missing docs/ directory")

    dm = read(DECISION_MAP)
    ids = parse_decisions(dm)
    if not ids:
        return fail("could not parse any decision headings from decision-map.md")

    # Uniqueness check
    dup = sorted({d for d in ids if ids.count(d) > 1})
    if dup:
        return fail("duplicate decision ids in decision-map headings: " + ", ".join(dup))

    canon = set(ids)
    ok(f"parsed {len(canon)} decision id(s) from decision-map.md")

    toks, locs = scan_docs_for_decisions()

    unknown = sorted([t for t in toks if t not in canon])
    if unknown:
        lines: list[str] = []
        for t in unknown[:30]:
            r = locs.get(t, [])
            if r:
                ex = ", ".join([f"{rr.path}:{rr.line}" for rr in r[:3]])
                more = "" if len(r) <= 3 else f" (+{len(r)-3} more)"
                lines.append(f"- {t} @ {ex}{more}")
            else:
                lines.append(f"- {t}")
        extra = "" if len(unknown) <= 30 else f" (and {len(unknown)-30} more)"
        return fail(
            "docs reference D-* decision id(s) not present in docs/30-architecture/decision-map.md" + extra + "\n" + "\n".join(lines)
        )

    ok(f"all referenced D-* decisions in docs/ are present in decision-map.md ({len(toks)} unique refs)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
