# RFC-0032: View/namespace semantics v1 (per-process namespaces, union mounts, service trees)

Status: Draft  
Updated: 2026-02-25  
Decision node: D-NS

Goal: get the **Plan 9 namespace ergonomics** (per-process namespaces + union mounts) *without* ambient authority, and define a stable “service tree” convention that makes systems debuggable and scriptable without bloating the privileged core.

Non-goal: moving policy into the kernel. Namespace/view operations are normal capability-mediated object operations; any “mounting” is a mutation of an explicit view object.

## Problem
We already use **view objects** to replace global name resolution with explicit, auditable objects (`view.resolve(view, name)` with no fallback). In practice, v0 views (bind/mount/resolve) leave open questions that matter for:
- usability (layering, overlays, per-app custom worlds);
- determinism (record/replay, postmortems);
- tooling (introspection that doesn’t become ambient authority).

Plan 9’s answer was “the namespace is per-process” and union mounts are cheap. We want that *shape* while keeping our core discipline:
- no ambient acquisition (I-VIEW-1);
- no implicit amplification (I-VIEW-2);
- keep privileged surfaces closed (IF-KABI remains small).

Refs: REF-PLAN9, REF-PLAN9-NSCROSS, REF-STYX-ARCH, REF-QNX-RESMGR, REF-QNX-RESMGR-ATTACH, REF-HURD-TRANSLATORS, REF-HURD-SETTRANS.

## Proposal
### 1) Per-process namespaces (explicit view handoff)
Each process/component runs with an explicit **root view** capability:
- spawn APIs take an explicit `view_cap` argument (default: inherit);
- a child can be given a narrower view (least authority by construction);
- the root view can be sealed/locked after init (aligns with D-SEAL).

#### Copy-on-write clone
Add:
- `view.clone(view) -> view'`

Semantics:
- `view'` initially resolves exactly as `view`;
- mutations to `view'` do not affect `view`;
- implementations MAY use COW/structural sharing.

Why:
- cheap “custom worlds” (overlay debug tooling, test harness views, etc.);
- encourages least-authority propagation (pass a clone, then narrow it).

### 2) Union mounts / overlays (ordered search)
Add the ability to bind a name/prefix to an ordered list of targets (overlay stack):
- `view.bind_union(view, name, [cap...])`
- `view.mount_union(view, prefix, [view...])`

Resolution sketch:
- attempt candidates left-to-right;
- for “directory-like” objects, expose a union directory view with stable enumeration + shadowing rules (so tooling isn’t nondeterministic).

Guardrails:
- union/overlay must not create authority beyond the provided capabilities (still I-VIEW-2);
- mutations are capability-authorized operations on the view object.

### 3) Service trees (tooling convention; optional)
Plan 9/Inferno popularized “hierarchical interfaces” (e.g., 9P) because they are easy to inspect, script, and debug. We adopt a narrower convention:

- A component MAY expose a **tree** rooted at a capability.
- Each node is itself a capability (not necessarily a byte file).
- A user-space “tree adapter” provides inspection + read/write UX and can map to POSIX-ish tooling for operator convenience.

Optional transport:
- a user-space bridge MAY speak a 9P-like protocol so service trees can be mounted remotely for operations/debugging, but the endpoint is just another capability (no privileged network magic).

Refs: REF-9P, REF-STYX-ARCH.

QNX reality check:
- QNX Neutrino’s “resource managers” are effectively path-attached user-space servers backed by message passing, and their docs treat *attaching a pathname* as a privileged pathspace operation.
- That matches our posture: view mutation (bind/mount/attach) should be an explicit capability right, transcripted, and sealable (D-SEAL) — not a “helper API” that quietly expands authority.


Hurd reality check:
- GNU Hurd’s translators make the same seam explicit: `settrans` attaches/removes a user-space server at a node. In our model this is just another **view mutation**: explicit authority, transcripted, and sealable.


## Minimal integration seam
- Views remain ordinary objects; privileged code never consults a global resolver.
- If we adopt service trees, the adapter/bridge is *user space* and consumes normal capabilities; no new IF-* surface required.
- Namespace mutations SHOULD be transcripted (CH-LOG) so record/replay and postmortems can reconstruct a process’ naming environment.

## Risks & mitigations
- **Nondeterminism via enumeration order:** require stable union enumeration rules; treat unstable order as a bug (breaks replay).
- **Covert channels via namespaces:** treat large-scale name listing/search as an observation surface; scope via IF-OBS redaction and view attenuation.
- **Complexity creep:** union mounts are optional; keep v0 views minimal for Phase 1, and gate v1 features behind profiles.

## Evidence plan
1. **Reference model + differential tests:** tiny pure model of `resolve` for v1 semantics; fuzz mutations and compare implementations (pairs well with D-DRT).
2. **Model checking:** small bounded graphs for “no amplification” and determinism properties.
3. **Microbench:** define budgets for resolve with union depth N; ensure disabled-by-default overhead stays negligible.
4. **Dogfood:** expose IF-OBS export as a service tree; verify redaction holds under traversal.

## Open questions
- Do we need explicit “remove/unmount” ops in v1, or is “clone + replace” sufficient for most workflows?
- What is the minimal “directory-like” capability interface that enables stable enumeration without imposing POSIX semantics?
