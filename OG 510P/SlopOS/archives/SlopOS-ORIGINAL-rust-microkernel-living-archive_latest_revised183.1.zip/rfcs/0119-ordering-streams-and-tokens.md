# RFC-0119: Ordering streams + ordering tokens for non-commutative actions (CH-ORDERTOK) (D-COMMUTE)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-COMMUTE** (primary), D-MK (adjunct), D-REPL (adjunct), D-BUDGET (adjunct), D-PLUMB (adjunct)

## Summary
Hybrid + commutativity only works if *required ordering* is:
1) **scoped** (to the conflict key),
2) **explicit** (not hidden in global locks), and
3) **receipt-visible** (so tooling can reason about it).

This RFC introduces a small, cross-cutting artifact seam:
- **CH-ORDERTOK v0**: a **non-authoritative** descriptor of membership in an **ordered stream**.

Ordered actions (non-commutative by spec) MUST carry an `order_digest` reference (digest of CH-ORDERTOK) and receipts MUST record that `order_digest`.

## Motivation
D-COMMUTE explicitly distinguishes:
- actions that commute (and can scale by avoiding coordination), from
- actions that are non-commutative (order is part of the spec).

Without a standard way to represent “this action is in an ordered stream”:
- ordering becomes an implementation accident (global lock / hidden singleton),
- LLM planners cannot safely batch/reorder,
- validators cannot fail closed on missing order evidence,
- and audits cannot explain “why did this serialize?”

The scalable commutativity rule pushes the same lesson: if order is observable in the spec, we must treat it as a first-class surface (REF-SCR-TOCS15).

## CH-ORDERTOK v0 (descriptor)
Spec: `docs/30-architecture/ordering-token-schema-v0.md`
Related: `docs/30-architecture/conflict-key-schema-v0.md` (CH-CONFLICTKEY v0)

CH-ORDERTOK describes:
- `scope` (ordered stream identity) as `(family, key_digest)` where `key_digest = digest(CH-CONFLICTKEY v0)` for the relevant conflict key,
- `(epoch, seqno)` within the stream,
- optional ownership hints (cluster/service identity),
- optional expiry.

Constraints:
- **non-authoritative** (no bearer secrets, no raw cap IDs),
- **bounded + closed enums** for `scope.family`,
- canonical encoding for hashing/signing.

## Required wiring (v0)

### Hot action surface
For each pinned hot family, `hot-action-boundaries-v0.md` must state an explicit:
- **Ordering token:** line (`CH-ORDERTOK v0` scoped to the conflict key, or `none`).

This keeps ordered surfaces explicit and reviewable.

### CH-ACP (proposal actions)
Spec: `docs/70-llm-control/acp-action-schema-v0.md`

If an action kind is specified as **ordered**, the proposal MUST include:
- `meta.order_digest = digest(CH-ORDERTOK v0)`,
- `meta.conflict_key_digest = digest(CH-CONFLICTKEY v0)`.

Validators MUST fail closed on:
- missing `order_digest`,
- expired ordering token,
- mismatched `scope.key_digest` vs `conflict_key_digest`.

### CH-KABI (privileged actions)
Spec: `docs/30-architecture/kabi-action-schema-v0.md`

For ordered KABI families (e.g., `ipc.*`, `budget.mint`), implementations SHOULD:
- record `meta.order_digest` (digest of CH-ORDERTOK) for observability and replay/trace alignment.

We do not require a specific kernel mechanism here; this is about stable, reviewable evidence surfaces.

## Assurance wiring (seed)
New invariants (optional):
- **I-ORDERTOK-1**: ordering tokens are non-authoritative (cannot grant effects).
- **I-ORDERTOK-2**: ordered actions are scope-bound; missing/expired/mismatched order evidence fails closed.

New proof obligation:
- **PO-ORDERTOK-VALIDATE**: CH-ORDERTOK decode/validation is total/canonical; bounds enforced; closed enums; ordered actions fail closed on invalid order evidence.

Evidence seed:
- **EVID-2026-122**: CH-ORDERTOK validator + ordered-action negative tests (scope mismatch, expiry, missing digest) + swap-order harness integration.

## Alternatives
- **Implicit locks / internal sequence numbers only**: hides ordering as implementation accident; breaks audit/LLM planning; invites ambient serialization.
- **Global total order for everything**: simple but destroys scalability; incompatible with Hybrid unless profiled explicitly (RC4).
- **Per-service ad hoc ordering tokens**: leads to ecosystem drift and inconsistent receipts; hard to validate mechanically.

## References
REF-SCR-TOCS15.
