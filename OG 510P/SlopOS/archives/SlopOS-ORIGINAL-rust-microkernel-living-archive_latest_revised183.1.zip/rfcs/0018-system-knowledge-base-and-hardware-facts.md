# RFC-0018: System Knowledge Base (SKB) + hardware facts (D-SKB)

Status: Draft

Goal: keep the privileged core *small* while still supporting realistic hardware bring-up and policy decisions by making **hardware knowledge** an explicit, queryable, evidence-tracked artifact.

This is an optional seam: the kernel/hypervisor should not grow a “hardware policy brain.” Instead, it exports bounded **facts** and accepts bounded **decisions** through existing CH-KABI/CH-CFG pathways.

## Why this exists
Modern systems require decisions that depend on hardware topology and configuration:
- interrupt routing and affinity
- DMA/IOMMU posture
- device exposure (MMIO windows, IRQ endpoints)
- multicore partitioning (when we eventually stage D-CONC)
- PCI resource allocation / bridge windows / quirks

If we scatter “probe-and-decide” logic across privileged code, we enlarge TCB and make proofs brittle.
Barrelfish’s lesson is to centralize hardware knowledge in a service (SKB) with a queryable fact base, keeping the kernel closer to a message-passing substrate and pushing configuration into a declarative/rule-driven layer.

Refs: REF-MULTIKERNEL-SOSP09, REF-BARRELFISH-SKB, REF-DECLARATIVE-OS.

## Design stance (minimal but complete)

### 1) Hardware knowledge is explicit data
Introduce **CH-HWFACT v0**: a bounded, canonical “hardware facts” record produced during early boot/hardware discovery.

- The privileged core may produce a CH-HWFACT record (or accept one from a trusted boot stage per A-BOOT-1).
- The record is **canonical** and **hashable** (I-ENC-1).
- Large structures (ACPI tables, full PCI config space dumps) are represented as digests, not embedded payloads.

### 2) SKB is user space (no logic engines in the kernel)
The SKB runs as a user-space service:
- stores CH-HWFACT facts + derived facts,
- answers **pure** queries (deterministic given the fact set),
- emits *recommendations* (bindings, placements, routing suggestions) as ordinary user-space outputs.

The privileged core does **not** embed a Prolog/CLP engine. If we want logic queries, we keep a bounded query language in user space (e.g., a Datalog subset or constraint logic programming), and treat its results as **untrusted** until validated by policy.

Practical integration targets (non-exhaustive):
- driver binding: choose the appropriate driver host/runtime for a device class
- interrupt routing: suggest affinity layouts under profile constraints
- PCI allocation: compute a deterministic assignment under bridge constraints

### 3) Bind facts and derived decisions to provenance
If CH-HWFACT is used, its digest should be listed in CH-BOOT `artifacts` under a role tag like `hwfacts`.

If the SKB produces a decision that becomes authoritative (e.g., it is written into CH-CFG), then the decision must be:
- **transcript-visible** (CH-LOG)
- attributable to a specific fact epoch (see §4)
- applied only via an interface that cannot be silently invoked (IF-ACP / admin action / portalized workflow)

Maps to: I-BOOT-1, I-PROV-CHAIN-1, PO-BOOT-BIND.

### 4) Hotplug and evolving facts: epoch + event log (optional but recommended with D-DEVGUARD)
Hardware reality changes at runtime (hotplug, link training, firmware-reported topology quirks).
To keep proofs and audits sane, we treat “fact base evolution” as explicit, bounded events.

Introduce **CH-HWEVENT v0**: a bounded *hardware event* record.

Model:
- An SKB maintains a current **epoch**.
- Initial epoch facts come from CH-HWFACT.
- Subsequent changes arrive as CH-HWEVENT records, each with a monotonic `event_seq` and a closed `kind`.

Constraints:
- CH-HWEVENT is not a “driver protocol.” It’s a minimal, structured *fact delta* suitable for audit/replay.
- Any security-relevant attach/detach decision (D-DEVGUARD) references the current epoch and the relevant event digests.

This aligns with systems that model device state as a topology graph of nodes and lifecycle events (cf. Fuchsia’s driver framework topology model). Refs: REF-FUCHSIA-DRIVER-FRAMEWORK, REF-FUCHSIA-DRIVER-NODES.

### 5) Query interface shape (keep it boring)
We don’t standardize “the whole SKB language” early.
Instead:
- define a small IDL surface for a handful of **named queries** ("cpu_topology", "iommu_present", "pci_device_by_loc", "interrupt_route_suggestions")
- each query returns a bounded result record with a stable schema version
- each query response includes the input epoch id and (optionally) the digests of the fact artifacts it depended on

If/when a richer query language exists, it stays in user space, and we treat “query text” as an input that must not be attacker-controlled when used for privileged decisions.

## Candidate invariants / obligations (optional)
- **I-HWFACT-1 (Pinned hardware facts, optional)**: any hardware-derived parameters used to authorize privileged effects are traceable either to CH-HWFACT/CH-HWEVENT (fact base) or to explicit policy/config artifacts; no “silent probing” affects security decisions.
- **PO-HWFACT-BIND**: if CH-HWFACT is used, the active fact digest is exportable for audit (IF-OBS) and, when required by profile, bound in CH-BOOT.
- **PO-SKB-PURITY**: SKB queries used for policy decisions are pure (deterministic given the declared facts) and their inputs/outputs are transcript-logged when they affect configuration.
- **PO-HWEVENT-VALIDATE**: CH-HWEVENT records are validated (closed enum kinds; bounds; monotonic sequence per epoch) before being accepted into the fact base.

## Abuse cases
- attacker forges/channels hardware facts to widen authority (covered by boot/provenance binding + CH-CFG signatures)
- “hardware probe” nondeterminism breaks replay/evidence (covered by D-RR + CH-RR; CH-HWFACT can pin probe results)
- hotplug churn causes policy races (covered by explicit epoch+event digests; attach decisions bind to a specific epoch)

## Evidence plan (tight)
Phase 1:
- build a CH-HWFACT encoder/decoder + tests
- build a CH-HWEVENT encoder/decoder + tests
- a tiny SKB prototype that answers 3–5 named queries (CPU topology, IOMMU presence, PCI device selection, a toy interrupt-route suggestion)
- negative tests: mutated facts rejected; unknown fact kinds reject; event sequence violations reject

Phase 2:
- bounded model check: “facts → query → config decision” pipeline preserves I-CAP-1/I-IF-1 under declared bounds
- hotplug simulation harness: event log → epoch advance → attach/detach decisions remain deterministic and transcript-visible

## Archive impact
- D-SKB is clarified to include optional fact-evolution via CH-HWEVENT.
- Adds CH-HWEVENT v0 schema + schema registry row.
- Updates RFC-0018 (this file) and `os-lessons.md` SKB entry.
