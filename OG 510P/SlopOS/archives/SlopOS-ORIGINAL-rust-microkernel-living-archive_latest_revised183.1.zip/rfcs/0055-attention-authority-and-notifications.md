# RFC-0055: Attention authority + notifications (D-ATTN)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-ATTN, D-VOLITION, D-EXPLAIN, D-PLUMB

## Summary
Introduce a first-class **attention**/notification substrate that treats user attention as a scarce resource:
- apps/extensions request notifications through a **notification portal** (no direct “draw a toast anywhere”);
- notifications are **origin-branded** (unspoofable attribution) and **budgeted** (rate/volume bounds);
- notification interactions (buttons/clicks) are routed through the trusted UI path (D-VOLITION) and, when they grant new authority, require an authority diff preview + receipt (D-EXPLAIN).

This reduces phishing/spam via notifications, prevents “notification click” confused-deputy patterns, and keeps notification semantics deterministic and auditable.

## Motivation
Real systems have learned (the hard way) that notifications are:
- a **phishing surface** (customizable text/icon/actions can mimic other apps), and
- an **interruption DoS** vector (spammy apps degrade usability and can train users to click blindly).

Mobile platforms introduced mitigations that are worth baking in:
- **origin attribution** and limited customization (iOS/Windows Phone vs. Android/BlackBerry in early eras),
- **notification channels** + user-tunable interruption levels (Android),
- special-case **critical alerts** (Apple) with elevated consent.

In our ecosystem, notifications also intersect with agent/automation flows: agents can propose actions, but notification clicks must not become a “free approval bypass”.

Refs: REF-XDG-PORTAL-NOTIFICATION, REF-ANDROID-NOTIF-CHANNELS, REF-APPLE-NOTIF-HIG, REF-APPLE-CRITICAL-ALERTS, REF-NOTIF-PHISH-WOOT12.

## Integration seam / privileged impact
- Kernel impact: **none required**.
- User-space components:
  - UI shell / workflow router provides a **Notification portal** endpoint.
  - If D-VOLITION is enabled, notification actions require a fresh CH-VOL.
  - If D-EXPLAIN is enabled, any action that adds authority MUST show an authority diff and emit CH-RECEIPT.

## Design

### 1) Notification portal (handles, not paths)
Apps/extensions do not directly “show a notification.” They submit a **CH-NOTIF v0** request to the portal.

Portal rules:
1) Request payload is bounded and **non-executable** (no HTML, no scriptable links).
2) Any media (icon/image) is referenced by **handles/capabilities** (view-scoped or content-addressed), never raw paths.
3) The portal MAY suppress or coalesce notifications based on budget policy.
4) The sender cannot learn whether the user saw the notification (avoid a high-fidelity side channel).

Schema: CH-NOTIF v0 (see `docs/30-architecture/notification-request-schema-v0.md`).

### 2) Origin branding (unspoofable attribution)
Every presented notification MUST include an origin badge derived from canonical identity:
- component identity digest (CH-COMP route identity) and/or a stable user-facing app label,
- optional provenance class (installed, dev, quarantined, disposable domain).

Rules:
- app-provided strings cannot override origin branding;
- origin label is produced by the portal/UI shell from **canonical manifests**, not requester text.

Interaction with D-QUAR/D-EPHEM:
- notifications originating from a quarantined/disposable context MUST be visibly marked (and optionally down-ranked).

### 3) Channels + budgets (attention as a metered resource)
The portal maintains per-origin **channels** with user-tunable importance and rate limits.

Minimum channel set:
- `default` (normal)
- `background` (non-interruptive)
- `urgent` (requires additional capability; see below)

Budget policy (default stance):
- hard per-origin rate limit + burst window,
- per-channel “interruption cap” (e.g., only N interrupts per hour),
- coalescing rules for repeated notifications.

The user can globally mute channels/origins, but we avoid ambient per-app permission toggles as the *primary* control; instead we emphasize bounded-by-default + receipts for sensitive actions.

### 4) Notification actions: volition-gated, route-based
Notifications may include a small number of **actions** (buttons).

Rules:
1) Actions MUST be expressed as **route intents** (D-PLUMB) or ACP actions (CH-ACP) that are validated deterministically.
2) Clicking an action MUST require a fresh CH-VOL (D-VOLITION) and produces a transcript entry (CH-LOG).
3) If an action would add authority, the portal MUST show an authority diff (D-EXPLAIN) and emit a CH-RECEIPT.
4) Actions MUST be idempotent or explicitly labeled with expected effects; destructive actions require stronger friction (e.g., “hold-to-confirm” on the trusted UI path).

Rationale: prevent “tapjacking / clickjacking” style attacks where a notification click becomes an unintended privileged effect.
Refs: REF-TAPTRAP-SEC25 (background), REF-NOTIF-PHISH-WOOT12.

### 5) Urgent / critical alerts (optional)
Support an optional “urgent” channel class that is gated by explicit consent:
- a component must hold an `attention.urgent` capability (minted by IF-CONSENT via a clear UX),
- urgent notifications remain origin-branded and are still budgeted, but can bypass some suppression (within bounds).

This mirrors “critical alerts” patterns while keeping authority explicit.
Refs: REF-APPLE-CRITICAL-ALERTS.

## Registries impacted
Add/update:
- Decision map: **D-ATTN**
- Schema registry: **CH-NOTIF v0**
- Invariant registry: **I-ATTN-1..3**
- Proof obligations: **PO-ATTN-BRAND, PO-ATTN-BUDGET, PO-ATTN-ACTIONBIND**
- Abuse cases: **AC-043, AC-044**
- Evidence index: **EVID-2026-049, EVID-2026-050, EVID-2026-051**
- OS lessons: add “notification channels + origin branding” mapping
- Bibliography: add refs

## Threat-model impact
Mitigates:
- notification phishing/spam via origin branding + bounded customization
- “notification click → privileged effect” confused deputy via volition + diff/receipt

New risks:
- notification metadata may be privacy-sensitive; treat CH-NOTIF as PII-adjacent and minimize exports (align with C-OBS-1).

## Assurance/verification impact
New invariants / obligations:
- **I-ATTN-1 (Origin branding is canonical, optional)**: notification origin labeling is derived from canonical identity, not requester-controlled strings.
- **I-ATTN-2 (Notification actions are volition-gated, optional)**: executing an action from a notification requires a fresh CH-VOL and produces a transcript entry binding the exact action.
- **I-ATTN-3 (Budgets enforced, optional)**: portal enforces per-origin/channel budget policy deterministically; violations suppress/coalesce rather than amplify.

Proof obligations:
- **PO-ATTN-BRAND**: show origin labels are computed from canonical manifests/IDs and cannot be overridden by request fields.
- **PO-ATTN-BUDGET**: show budget enforcement is total/deterministic and fail-closed.
- **PO-ATTN-ACTIONBIND**: show notification action clicks bind to a specific action/route digest and cannot be swapped post-render.

## Evidence plan
E1 prototype:
- implement a minimal notification portal + ledger of suppressed/coalesced events;
- add golden tests for branding (cannot spoof) and action binding (digest mismatch rejects);
- add fuzz tests for CH-NOTIF total parsing and bounded payloads.

E2:
- integrate with D-EXPLAIN: show diff/receipt for a notification action that grants a file handle.

## Open questions
- What is the minimal stable user-facing origin label that avoids leaking identifiers but is still meaningful?
- Should we allow “rich notifications” at all (images, inline reply)? If so, how do we keep it non-executable and low side-channel?
- How should urgent/critical capabilities interact with DND modes and per-profile safety defaults?
