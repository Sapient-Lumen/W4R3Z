# RFC-0069: Capability diffs for consent + receipts (CH-CAPDIFF, D-EXPLAIN)

Status: draft  
Decision node(s): D-EXPLAIN, D-VOLITION, D-POWERBOX, D-PLUMB

## Goal
Make “**what authority is being added**” a first-class, mechanically checkable object:
- users can see an *authority diff* preview before approving,
- the UI gesture evidence (CH-VOL) binds to the exact diff shown,
- the audit trail (CH-RECEIPT + CH-LOG) records a durable, non-authoritative receipt.

This targets *grant creep* and confused-deputy patterns where permissions drift over time or approvals are not meaningfully bound to what executes.

## Background / lessons
Permission systems often fail when grants are decoupled from user intent and lack a clear “delta”:
- “powerbox” style pickers (CapDesk lineage; Plash; Sandstorm) use designation as least authority,
- portals (e.g., xdg-desktop-portal) mediate access to user-owned resources via user-driven UX,
- UDAC argues permission granting should be UI-coupled and contextual.

Maps to: IF-CONSENT, CH-VOL, CH-AUTHZ, CH-RECEIPT, CH-LOG.

Refs: REF-UDAC-SP12, REF-XDG-PORTAL, REF-XDG-PORTAL-FILECHOOSER, REF-SANDSTORM-POWERBOX, REF-PLASH-POWERBOX, REF-YEE-UIDSS-2002.

## Proposal
1) Adopt **CH-CAPDIFF v0** as the preferred typed structure for “authority diffs”.
   - Minimum v0 focus: `cap.grant` / `lease.issue` / portal-granted resource access.
2) Define deterministic binding rules:
   - consent UI renders a diff derived only from canonical inputs (action bytes + relevant policy/state) (I-EXPLAIN-1)
   - `summary_digest` in CH-VOL and CH-RECEIPT is the digest of canonical CH-CAPDIFF bytes (preferred path)
3) Enforce privacy + boundedness:
   - CH-CAPDIFF is size-bounded and redacted; no raw secrets/pointers/stable kernel IDs (I-EXPLAIN-4; I-OBS-1)
   - “resource_hint” (e.g., filenames) is profile-gated and omitted by default exports (PO-CAPDIFF-REDACT)

## Why this is worth baking in early
- Ecosystem pressure: apps inevitably need to request user-owned resources; without a standard diff/receipt object, each UI reinvents (and often weakens) the flow.
- Auditability: receipts become comparable across versions and tools; operator UX can answer “what changed?” without bespoke parsing.
- Verification seam: we can test the binding properties (action→diff→vol/receipt) without needing a complete desktop environment.

## Options considered
- **No authority diffs**: rely on coarse prompts; weak against “approve fatigue”.
- **Free-form text diffs**: easy to spoof; non-deterministic; hard to bind.
- **Cap-graph snapshots only (CH-CAPG)**: useful for debugging, but not designed as the canonical consent object.
- **Typed diff object (CH-CAPDIFF)** (proposed): bounded, redacted, digest-bindable.

## Impact
### Schemas
- Adds: CH-CAPDIFF v0 (docs/30-architecture/capability-diff-schema-v0.md)
- Clarifies: CH-RECEIPT v0 `diff_digest` prefers CH-CAPDIFF digests

### Invariants / proof obligations
- Uses: I-EXPLAIN-1..3 (existing), adds I-EXPLAIN-4 (bounded/redacted diffs)
- Adds: PO-CAPDIFF-REDACT

### Threat model
- Adds: AC-057 (consent diff spoofing / confused-deputy)

## Evidence plan (ADR promotion targets)
- E1: property tests that CH-CAPDIFF generation is deterministic given canonical inputs; requester strings/locale hints do not affect digest
- E1: negative tests for truncation/overflow: generation must fail closed or explicitly mark `clamps=["truncated"]` under policy
- E2: model-check a small “approve→execute→receipt” transition system to show (digest) bindings are preserved
- Red-team: attempt “UI says A, action does B” through TOCTOU, encoding malleability, and localization tricks

## Out of scope (v0)
- A universal diff language for *all* actions; start with grants/leases/portals.
- Remote notarization of receipts (tamper-evidence) — requires explicit crypto + trust assumptions.
- Global policy UI — keep policy in user space and profile-scoped.

