# RFC-0113: Restartable sequences + CPU-local fast paths (D-RSEQ)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-RSEQ**, D-SCHED (adjunct), D-NONDET (adjunct), D-UWAIT (adjunct), D-RR (adjunct), D-METER (adjunct)

## Summary
Once an ecosystem has multi-core scheduling and shared memory, it will eventually want **CPU-local fast paths**:

- per-CPU allocators / arenas,
- per-CPU counters and queues,
- sharded caches keyed by “current CPU”.

Most OSes make these work by using **atomics** or kernel objects, but that can be expensive and/or forces heavier synchronization than the use-case needs.

Linux introduced **restartable sequences (rseq)**: small, user-space code regions that are *intended to run start→commit on a single CPU*, and if the kernel preempts/migrates/interrupts the thread, it redirects control to a user-provided **abort handler**. This enables a class of “atomicless” per-CPU updates (still bounded, still careful) without turning every operation into a syscall.

We should bake in a minimal, capability-friendly **D-RSEQ seam** now so runtimes can use it *when justified* without bespoke kernel hacks.

## Goals
- Provide an **optional** primitive for high-throughput user-space runtimes to perform bounded **per-CPU** updates with fewer atomics/locks.
- Keep the seam **small and profile-gated** (not universally enabled).
- Ensure **boundedness**: no unbounded preemption suppression, no unbounded kernel bookkeeping, no “infinite critical sections”.
- Compose with:
  - D-SCHED (migration/preemption),
  - D-NONDET (exposing “current CPU” as a potential side-channel),
  - D-RR deterministic replay profiles (record/disable/virtualize),
  - D-UWAIT for contended slow paths (locks still exist).

## Non-goals
- A general “transactional memory” feature.
- A kernel-managed allocator or per-CPU library specification.
- A cross-process/global rseq design (v0 targets process-local, thread-local registration).

## Design sketch
### Minimal seam (v0)
Expose rseq as a **thread-local registration ABI**:

1) **Register** a per-thread “rseq area” in user memory (writable, page-pinned under this ABI) containing:
   - a cached `cpu_id` (or `vcpu_id` in virtualized profiles),
   - a monotonically changing sequence field used to detect preemption/migration,
   - ABI version and flags.

2) Allow user-space to designate bounded **restartable regions**:
   - each region has a start IP, a commit IP (the point after which it is considered “done”), and an abort IP,
   - if the kernel detects interruption/migration before commit, it forces control to the abort IP (with a stable reason code),
   - abort handlers must be re-entrant-safe and must not assume the fast path partially committed.

This is intentionally similar to Linux’s rseq shape, but we keep the contract closed and explicitly bounded.

### Profile gating (important)
D-RSEQ should be enabled only in profiles that:
- allow exposing “current CPU/vCPU” (D-NONDET posture),
- accept that user-space may run very short regions that are sensitive to preemption/migration,
- have tooling to debug “why did this abort” failures.

For deterministic replay (D-RR), D-RSEQ must be:
- **disabled**, or
- **virtualized** (record abort points + vCPU ids), or
- constrained to a mode where it has deterministic outcomes under replay (e.g., fixed scheduling in a static partition profile).

### Constraints (the “don’t let this become a footgun” list)
- Restartable regions must be **short** and must not:
  - take page faults,
  - perform IPC,
  - block,
  - loop indefinitely,
  - access pointers that can become invalid under migration without verification.
- The kernel must enforce bounds (e.g., max number of registered regions per thread/process, max nesting depth = 0 in v0).
- Registration/unregistration is **quota-bounded** and attributable when D-METER is enabled.

### Interaction notes
- **With D-UWAIT**: rseq is not a lock replacement; it’s a fast path for CPU-local operations. Contended/slow paths still use locks and should block via D-UWAIT.
- **With hotplug / CPU sets**: if CPU availability changes, the rseq contract must fail closed: abort → slow path, with explicit reason codes.
- **With side-channel posture**: CPU-local fast paths can increase observability of scheduler behavior. D-RSEQ should be treated like other non-determinism surfaces: explicit profile enablement and documentation.

## Security and safety notes
- **DoS risk**: poorly written rseq regions can churn aborts and waste CPU. Mitigation: bounded registrations, accounting, and supervisor visibility for high abort rates.
- **Side-channels**: exposing CPU/vCPU identifiers can create a scheduler oracle. Mitigation: D-NONDET gating and explicit profile posture.
- **Correctness**: the most common rseq bug is “partial commit”. The v0 contract must define a single commit point and require abort handlers to restore invariants.

## Alternatives
- Only atomics + locks: simplest, but can be too slow for some allocators/counters.
- Kernel-managed per-CPU objects: expands TCB and makes policy expensive.
- Pure user-space TLS sharding: helps only when “which shard” is stable; does not solve migration races without heavier atomics.

## Evidence plan (seed)
EVID-2026-116:
- a minimal rseq prototype + harness that:
  - forces aborts via preemption/migration signals,
  - validates “no partial commit” properties on a small per-CPU counter and per-CPU free-list toy,
  - stresses bounds (registrations, nesting=0, abort rate),
  - exercises replay/profile gating (D-RR disabled mode; static partition mode).

## References (see bibliography)
REF-LINUX-RSEQ-DOC, REF-LINUX-RSEQ-MAN, REF-REDHAT-RSEQ-GLIBC, REF-LWN-RSEQ-GLIBC.
