# RFC-0096: Job portal + constraint-based background work (no ambient cron/alarms)

Status: Draft  
Updated: 2026-02-28
Decision node(s): D-JOBS, D-TCAP, D-BUDGET, D-PRESSURE, D-ACTIVATE (adjunct), D-PLUMB (adjunct), D-PERSIST (optional)

## Summary
Standardize an adoptable, low-TCB pattern for **deferrable background work** that:
- avoids ambient “wake up the world” primitives (cron/alarms as global authority),
- makes background execution **explicit, attributable, bounded, and cancellable**,
- lets the system coalesce work for power/latency without turning scheduling into kernel policy, and
- integrates naturally with our existing seams: temporal capabilities (D-TCAP), budget leases (D-BUDGET), and pressure signals (D-PRESSURE).

This RFC introduces **CH-JOBREQ v0**, a bounded descriptor for scheduled job requests. It is **not authority**; it describes the request and its bounds.

## Motivation
Background work is where real systems quietly reintroduce ambient authority:
- “set an alarm for 3am and run” becomes an un-audited power + network + timing channel.
- long-lived background daemons become the default workaround.

Mature ecosystems converged on a better shape:
- **Android JobScheduler / WorkManager**: you describe constraints (network/charging/idle/etc.) and the system runs work opportunistically; timing is *not* a promise, it’s “at least once” behavior under constraints.
- **Apple BGTaskScheduler**: you request an earliest start time, but the system explicitly does not guarantee launching at that time; it schedules for overall device health.
- **systemd timers**: a declarative timer model with coalescing/randomization and persistence semantics for “catch up after downtime.”

A greenfield capability OS can bake in a single posture:
- **background work is a portal-mediated request** with explicit constraints and bounded runtime.

## Non-goals
- Replacing the full app lifecycle model (foreground UI, push messaging, etc.).
- Guaranteeing exact run-at timestamps (that reintroduces a side-channel and power abuse surface).
- Making CH-JOBREQ an authorization token.

## Design

### Conceptual model
A **job portal** is a normal user-space service (e.g., `/svc/portal/jobs`) that mediates background scheduling.

A job request is modeled as:
1) a **submit** call: “run this work later,” with constraints and bounds,
2) the portal returning a **cancellable handle** (a job ticket capability),
3) the portal emitting a **CH-JOBREQ v0** descriptor logged/receipted by digest,
4) on trigger, the portal delivers an activation/message to the target with an **execution budget**.

### LLM-first interface (ACP kind; no ambient cron/alarms)
For the “LLMs propose; validators execute” posture (shape D and automation-heavy A/B), job submission is exposed as a CH-ACP kind:
- `portal.jobs.submit`: proposal binds `jobreq_digest = digest(CH-JOBREQ v0)` and MUST carry `meta.reqctx_digest = digest(CH-REQCTX v1)`; the validator enforces lane gate `cfg.params.lane.portal.jobs` fail-closed and performs canonical CH-JOBREQ validation before invoking the portal service.
- Outcomes are transcript-visible via CH-ACPOUT/CH-DENY, and ordered-stream witnesses (CH-ORDERTOK) are required because job-queue mutation is an ordered boundary within `domain.id` (see `docs/70-llm-control/acp-action-kind-registry.md`).
This preserves least authority in workflows: there is no direct “schedule alarm” API and no ambient host scheduler interface.

### Background execution is explicit authority
Submitting a job is authority to:
- wake a component later,
- spend bounded CPU/time,
- (optionally) request network or other portals during the run.

Therefore:
- components MUST NOT be able to schedule background execution via ambient APIs after init.
- job submission should be capability-gated (policy-defined); untrusted apps may only schedule limited classes.

### Constraint model (bounded, closed-set)
CH-JOBREQ v0 uses a **closed-set** constraint vocabulary (no arbitrary predicates):
- `network`: none / any / unmetered / local_only
- `requires_charging`: bool
- `requires_device_idle`: bool
- `battery_not_low`: bool
- `storage_not_low`: bool
- `expedited`: bool (optional “run soon,” still bounded)

The job portal is free to **delay** execution even when constraints are satisfied, to coalesce work and respect pressure.

### Runtime bounds (pair with D-TCAP/D-BUDGET)
Each job execution SHOULD be bounded by:
- a maximum wall-time budget (e.g., `max_runtime_ms`), and
- (when D-TCAP is enabled) a temporal capability donated/assigned for the run.

Optionally (D-BUDGET): portal may require an operation-scoped budget lease to “pay” for resource-heavy job kinds.

### Trigger semantics (no exact timestamps)
A job request uses a windowed model:
- `earliest`: do not start before this time
- `latest` (optional): preferred deadline window end (best-effort)

The portal may use coarse time (or “next maintenance window”) to reduce timing channels.

### Durability (optional)
If D-PERSIST is enabled:
- jobs are only durable if the submitter holds explicit durability authority (CapStore / DurableRoot).
- durable job schedules MUST be non-amplifying: restoring schedules cannot create new authority.

### CH-JOBREQ v0
Introduce CH-JOBREQ v0 as a bounded descriptor for scheduled jobs.
- Emitted by the job portal on submission (and optionally on reschedule).
- Logged/receipted by digest.
- Contains **no capability material** and MUST NOT embed large payloads.

See: `docs/30-architecture/job-request-schema-v0.md`.

### Integration with existing seams
- **D-TCAP (RFC-0049):** portal assigns/donates a scheduling context for each run (or rejects if unavailable).
- **D-PRESSURE (RFC-0057):** portal uses pressure signals to defer/coalesce background work.
- **D-ACTIVATE (RFC-0081):** portal can trigger work by activation delivery (stable handles) instead of forcing always-on daemons.
- **D-PLUMB (RFC-0046):** job submission is a portal workflow; strict profiles may require receipts for authority-widening job classes.
- **D-NETLEASE (RFC-0056):** background work does not imply ambient networking; network access remains lease-based.

## Registries impacted
- Add **CH-JOBREQ v0** to the schema registry.
- Add decision node: **D-JOBS**.
- Add invariants:
  - **I-JOB-1** (No ambient background wakeups, optional)
  - **I-JOB-2** (Bounded + non-amplifying job execution, optional)
- Add proof obligations:
  - **PO-JOBREQ-VALIDATE** (CH-JOBREQ decoding/validation is total, canonical, bounded)
  - **PO-JOBS-ENF** (portal enforces constraints + runtime bounds; no bypass)
- Add abuse case:
  - **AC-083** (Background job abuse / wakeup storms / timing channels)
- Add evidence seed:
  - **EVID-2026-094** (CH-JOBREQ spec + portal harness plan)

## Evidence plan
E0: Spec + harness plan (EVID-2026-094):
- golden tests: CH-JOBREQ schema validation (closed enums, bounds, canonical decode)
- harness: demonstrate (a) no ambient alarms/cron APIs, (b) constraint gating works, (c) cancellation works, (d) runtime bounds enforced (wall-time + optional TCaps), (e) pressure signals cause deferral/coalescing deterministically
- negative tests: untrusted app cannot schedule privileged job kinds; job cannot silently gain network without a lease; job metadata exports obey CH-OBSPOL tiers

## References
Refs: REF-ANDROID-JOBINFO, REF-ANDROID-WORKMANAGER, REF-APPLE-BGTASKS, REF-APPLE-BGTASK-EARLIEST, REF-SYSTEMD-TIMER.
