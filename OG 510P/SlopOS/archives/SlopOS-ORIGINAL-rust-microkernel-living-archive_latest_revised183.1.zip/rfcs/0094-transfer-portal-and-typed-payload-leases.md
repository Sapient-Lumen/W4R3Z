# RFC-0094: Transfer portal + typed payload leases (clipboard/drag-drop/share without ambient broadcast)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-PLUMB, D-LEASE, D-VOLITION (adjunct)

## Summary
Define a standard, capability-safe pattern for **cross-application data transfer** (clipboard, drag-drop, “share”) that:
- avoids **ambient broadcast clipboards**,
- makes transfers **explicit, auditable, and revocable**, and
- keeps the privileged core unchanged (user-space portal service).

This RFC introduces **CH-XFER v0**, a bounded descriptor for a portal-mediated transfer. It is **not** authority; it describes a transfer grant and its bounds.

## Motivation
Clipboard/drag-drop are where least-privilege desktop sandboxes routinely collapse:
- global clipboard becomes an implicit read channel (background snooping)
- “drag a file” becomes an implicit path leak or long-lived delegation
- large payloads become covert channels (export-by-metadata)

Modern systems are converging on “clipboard is a security surface” mitigations (notifications, access mediation, session handles), but they often bolt them on inconsistently.

A greenfield capability OS can make the *default* workflow:
- **copy ≠ grant** and **paste == grant** (explicit user-mediated transfer),
- transfer results are **leased** and bounded (D-LEASE),
- every cross-component transfer is attributable and (optionally) receipt-bound.

## Non-goals
- Designing a full desktop UX (selection semantics, primary selection, rich MIME negotiation UI).
- Mandating a particular graphics stack.
- Making CH-XFER an authorization token.

## Design

### Conceptual model
A **transfer portal** is a normal user-space service (e.g., `/svc/portal/xfer`) that mediates data movement between components.

Transfers are modeled as:
1) a **source offer** (data provider),
2) a **sink request** (paste/drop/share target),
3) a portal-mediated **grant** that yields a typed payload capability **with lease bounds**.

### Key rule: no ambient reads
- No component can observe clipboard/drag-drop payloads unless it receives an explicit **grant** for a specific transfer.
- When a grant crosses trust boundaries, it SHOULD require fresh **volition** (D-VOLITION) and SHOULD emit a **receipt** (D-EXPLAIN) that references the relevant transfer descriptor digest.

### Payload transport
The portal may implement payload delivery using:
- immutable I/O buffers (D-IOBUF) for small/medium payloads,
- streaming endpoints for large payloads,
- or “offer callbacks” where the portal requests a specific format on demand.

A practical precedent is the Wayland pattern: a data source offers MIME types; a sink selects one; bytes transfer over a passed file descriptor.

### Default safety posture (recommended)
For transfers that cross components (or cross quarantine boundaries):
- **short TTL**, and/or **single-use** grants (D-LEASE)
- **auto-clear** behavior for clipboard-style transfers after completion
- **size bounds** and format allowlists (e.g., default-to-plain-text for cross-domain clipboard)
- optional **sensitive** marking so logs/exports redact the descriptor and forbid snapshot inclusion unless explicitly authorized

### CH-XFER v0
Introduce CH-XFER v0 as a redaction-aware descriptor for a portal-mediated transfer.
- Emitted by the portal alongside a grant.
- Logged/receipted by digest.
- Contains **no secret capability material** and MUST NOT embed raw payload bytes.

See: `docs/30-architecture/transfer-descriptor-schema-v0.md`.

### Integration with existing seams
- **D-PLUMB**: workflow router routes `Paste` / `DragDrop` / `Share` intents to the transfer portal.
- **D-LEASE**: grants SHOULD be leased proxies; CH-XFER records TTL/uses intent (redaction-safe).
- **D-VOLITION**: if required by policy, a paste/drop is bound to a trusted UI gesture.
- **D-OBSPOL**: exporting CH-XFER (or embedding it into CH-SNAPSHOT/CH-CRASHCAP) must obey redaction tiers.

## Registries impacted
- Add **CH-XFER v0** to the schema registry.
- Add invariants:
  - **I-XFER-1** (no ambient reads; transfer is explicit and attributable)
  - **I-XFER-2** (bounded + auto-clear posture; sensitive marking is respected)
- Add proof obligation:
  - **PO-XFER-VALIDATE** (CH-XFER decoding/validation is total, canonical, bounded)
- Add abuse case:
  - **AC-081** (clipboard/drag-drop exfil and covert channels)
- Add evidence seed:
  - **EVID-2026-092** (CH-XFER v0 spec + portal harness plan)

## Evidence plan
E0: Spec + harness plan (EVID-2026-092):
- golden tests: CH-XFER schema validation (closed enums, bounds, canonical decode)
- portal harness: demonstrate (a) cross-app paste requires explicit grant, (b) auto-clear works, (c) lease expiry/uses are enforced, (d) sensitive transfers are redacted/blocked from exports per CH-OBSPOL
- negative tests: background app cannot read clipboard; oversized payload offers reject; non-allowlisted MIME types reject in cross-domain profile

## References
Refs: REF-QUBES-CLIPBOARD, REF-WAYLAND-CH04, REF-WAYLAND-APA-DATADEVICE, REF-XDG-PORTAL, REF-XDG-PORTAL-CLIPBOARD, REF-ANDROID-SECURE-CLIPBOARD, REF-ANDROID-12-CLIPBOARD-TOAST.
