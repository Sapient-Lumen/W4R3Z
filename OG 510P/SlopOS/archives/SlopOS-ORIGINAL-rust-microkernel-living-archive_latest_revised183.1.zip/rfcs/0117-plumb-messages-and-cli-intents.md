# RFC-0117: Plumb messages + CLI intents (pinning cross-app “glue”)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): D-PLUMB, D-CAPSHELL, D-WALLET

## Summary
Extend RFC-0046 (workflow plumbing) with a **pinned, canonical message envelope** (**CH-PLUMBMSG v0**) for cross-application “intent” routing, so that:
- GUI portals and CLI tools share the same workflow substrate,
- routing is deterministic and auditable (CH-ROUTE v0),
- messages do **not** become an ambient covert channel or a side-door for capability transfer.

This is a Plan 9 plumber–inspired layer (REF-PLAN9-PLUMB) adapted to an object-capability OS where authority flows only via explicit handles, portals, and receipts.

## Motivation
Workflow “glue” is where otherwise-capable systems regress to ambient authority:
- `open` / `xdg-open` equivalents interpret paths/URIs and implicitly delegate to helpers.
- “open-with”, “share”, “print”, “paste”, and “drag/drop” become hidden IPC conventions.
- CLI automation tends to bypass UI mediation entirely.

We already have the workflow router + portals concept (RFC-0046). What’s missing is a **stable, lintable envelope** for “plumbing” messages so:
- routing rules can match on **typed intent fields**, not ad-hoc strings,
- shells/runners can generate intents without private conventions,
- transcripts and receipts can bind to a canonical digest.

## Non-goals
- Define a rich scripting language (D-CAPSHELL covers that).
- Move policy into the kernel (keep D-PLUMB user-space).
- Make messages capability-bearing in a way that bypasses portals.

## Design

### CH-PLUMBMSG v0 (message envelope)
Add **CH-PLUMBMSG v0** as a canonical, non-secret envelope used by `Workflow.Plumb`.
- Schema: `docs/30-architecture/plumb-message-schema-v0.md`.
- The envelope is **non-authoritative**: it may carry *digests, tags, and references*, but not raw capabilities.

### Ports, subscriptions, and delivery
Keep the Plan 9 mental model (ports + rules) while preserving cap discipline:
- Senders call `Workflow.Plumb.Send(msg)`.
- Receivers call `Workflow.Plumb.Subscribe(port)` and receive a stream of messages.
- When a rule action needs to deliver a capability, it is delivered by **out-of-band capability transfer** tied to the receiving subscription (e.g., a router-owned mailbox object that only that subscriber can redeem).

Rationale: capabilities are authority; embedding them into a generic message bus invites accidental ambient channels.

### CLI ergonomics: “plumb-first” tools
Define a “boring” baseline of CLI verbs that always route through the workflow router:
- `open <docref|sturdyref|uri>` → emits `intent.kind=open` and uses portals as required
- `save-as` / `export` → emits `intent.kind=export` with explicit format bounds
- `share` / `paste` / `drag` → emits transfer intents (RFC-0094)
- `print` → emits print intents (portal discipline)

The key requirement is that these tools:
- work in **capmode** (D-CAPMODE) and sealed contexts (D-SEAL),
- can attach a **wallet_core_digest** when available (D-WALLET) to enable drift gates and explainability,
- never rely on ambient file paths; they operate on handles or portalized selection.

### Routing and explainability
- CH-ROUTE matches on `intent.kind`, `tags`, and source identity.
- Portal completions emit CH-RECEIPT entries that can reference the CH-PLUMBMSG digest and any CH-CAPDIFF digest.

### Security properties (new invariant)
Add a small, explicit invariant:
- **I-PLUMB-3 (Plumb envelopes are non-authoritative, optional)**: CH-PLUMBMSG carries no raw capabilities; any authority transfer is mediated (portal grant or subscription-bound mailbox redemption) and is transcript-visible.

Optionally extend PLUMB proof obligations:
- **PO-PLUMBMSG-VALIDATE**: decoders reject unknown fields and enforce closed enums/bounds so message parsing is total and deterministic.

### Abuse case coverage
Add an abuse case to keep the threat model honest:
- **AC-090**: “plumb injection / confused deputy” — a malicious component forges intents to trick helpers into opening/exporting in an unsafe context; mitigations require strict source identity binding + safe defaults (deny-by-default routes, portal mediation for risky intents, and receipts).

## Registries impacted
- Schema registry: add **CH-PLUMBMSG v0**.
- Invariant registry: add **I-PLUMB-3**.
- Proof obligation registry: add **PO-PLUMBMSG-VALIDATE**.
- Abuse cases: add **AC-090**.

## Evidence plan
E1: minimal router prototype that accepts `open` intents from both GUI and CLI, producing the same receipts and diffs.
E2: fuzz + differential tests for CH-PLUMBMSG parsing and rule evaluation; confirm deterministic rejection on malformed or oversized messages.

## References
Refs: REF-PLAN9-PLUMB, REF-XDG-PORTAL, REF-XDG-PORTAL-OPENURI, REF-XDG-PORTAL-FILECHOOSER, REF-XDG-PORTAL-DOCUMENTS.
