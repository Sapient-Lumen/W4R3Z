# RFC-0107: I/O submission queues + completion events (D-IOQ)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-IOQ**, D-WAITSET (adjunct), D-IOBUF (adjunct), D-REQCTX (adjunct), D-METER (adjunct)

## Summary
For high-throughput subsystems (storage, networking, device I/O), the difference between “fast enough” and “stuck at 20% CPU in overhead” is often **how many boundary crossings** are required per operation.

This RFC proposes an optional, capability-safe seam:
- **D-IOQ**: a submission/completion **I/O queue object** (shared rings + doorbell) that lets a domain enqueue many operations and receive completions efficiently, without expanding the privileged core with a large programmable VM.

The goal is not “copy Linux io_uring” or “copy Windows I/O Rings”, but to adopt the stable *shape*:
- bounded submission ring,
- bounded completion ring,
- tags/ids provided by the submitter,
- completions surfaced as events (composes with **D-WAITSET**).

Refs: REF-LINUX-IOURING-PDF, REF-LINUX-IOURING-MAN7, REF-LINUX-IOURING-ENTER, REF-WIN-IORING-OVERVIEW, REF-WIN-IORING-CREATE, REF-WIN-IORING-SUBMIT.

## Motivation
Even with a microkernel, we will have workloads where the naive per-op path is too expensive:
- high-QPS local services that push many small I/Os,
- drivers and driver-hosts that must issue bursts,
- RPC runtimes that want to batch copyless buffer grants (D-IOBUF) or queue async operations.

Young systems often accumulate bespoke batching hacks:
- “vector” syscalls,
- ad hoc shared memory request arrays,
- per-driver special-case fast paths.

A general **queue object** can concentrate the performance surface in one place, while keeping policy and higher-level semantics in user space.

## Non-goals
- A kernel-resident programmable filter VM (avoid eBPF-class verifier/JIT complexity).
- Exposing ambient path-based I/O constructors.
- Replacing message IPC; D-IOQ is an optional performance seam.

## Proposed seam: D-IOQ

### Object model (informal)
Introduce an optional I/O queue object type:
- `IoQueue`: a capability handle that represents a paired submission/completion queue.

Creation is capability-mediated and bounded:
- constructing an IoQueue requires explicit authority (e.g., via a driver host, a storage service, or a portal-like broker in strict profiles),
- queue sizes are clamped and charged (D-METER if enabled),
- per-domain and per-queue bounds are enforced deterministically.

### Queue shape (v0)
A minimal v0 shape:
- Submission ring entries include:
  - `op` (closed opcode enum; fail closed on unknown),
  - `target` (an explicit handle/capability; no ambient paths),
  - `buffers` (optional: explicit shared buffers via D-IOBUF),
  - `ctx_digest` (optional: request-context digest for cancellation/deadlines correlation; see D-REQCTX),
  - `user_tag` (opaque bytes or u64 chosen by submitter; treated as untrusted data).
- Completion ring entries include:
  - `user_tag`,
  - `status` (closed error/status enum),
  - optional bounded `result` fields (e.g., bytes transferred, offset advanced).

Doorbell model:
- A submit call (or a doorbell signal) tells the implementation to consume N new submissions.
- Completions are appended to the completion ring.

### Completion delivery (composes with D-WAITSET)
If D-WAITSET is enabled, `IoQueue` is a waitable handle with signal bits:
- `CQ_READABLE` when completion entries are available,
- `SQ_AVAILABLE` when submission space exists (optional),
- `PEER_CLOSED` when the provider/queue is torn down.

This means event loops do not need a second bespoke “poll” mechanism for I/O queues.

### Cancellation/deadlines (adjunct)
D-IOQ should not invent a new cancellation system.
Instead:
- If a submission includes `ctx_digest` and the runtime holds a cancellation source, cancel should be expressed by:
  - completing the operation with `CANCELLED` deterministically, and/or
  - a provider-specific cancel opcode that requires a handle to the outstanding op id.

Key rule: cancellation is **best-effort but explicit**; it must not silently “finish in the background” after the submitter has been told the op is cancelled.

### Security and authority discipline
D-IOQ must preserve capability discipline:
- An op can only touch objects the submitter already has handles for.
- Queue providers must validate targets/buffers rights on dequeue, not only at submit time.
- `user_tag` is always treated as untrusted data; it must not influence authorization.

## Options

### Option 0: No I/O queues
- Keep per-op IPC/syscalls.
- Pros: simplest.
- Cons: likely performance cliffs for I/O-heavy services; invites ad hoc batching.

### Option 1 (recommended seam): Bounded IoQueue + D-WAITSET integration
- Keep the surface minimal: queue create/config + submit + drain.
- Keep opcodes closed and small.

### Option 2: Rich programmable I/O language
- Avoid early: too much verifier/JIT and helper surface.

## Assurance wiring (seed)
New invariants (optional; only if D-IOQ is enabled):
- **I-IOQ-1 (Targets are explicit handles, optional)**: IoQueue submissions cannot introduce ambient acquisition; operations target only explicit handles and declared shared buffers.
- **I-IOQ-2 (Bounded rings + deterministic overflow, optional)**: submission/completion rings and outstanding op counts are bounded; overflow/backpressure behavior is explicit and deterministic.
- **I-IOQ-3 (Completions are non-amplifying, optional)**: completions/events cannot create authority; tags are treated as untrusted data; status/results are derived only from authorized object state and declared op semantics.

New proof obligations (seed):
- **PO-IOQ-BOUND**: queue sizing, outstanding op limits, and completion draining are bounded and fail closed; no unbounded queues or hidden allocations.
- **PO-IOQ-NOAMP**: dequeue/execute validates rights; tags/results do not influence authorization; completion delivery cannot bypass capability checks.

## Evidence plan
- **EVID-2026-110**: harness plan covering:
  - bounds/overflow behavior under churn,
  - right-check validation on dequeue (negative tests for stale/forged handles),
  - teardown semantics (peer_closed, cancellation),
  - microbench: per-op IPC vs batched IoQueue for a small set of ops.

## References
REF-LINUX-IOURING-PDF, REF-LINUX-IOURING-MAN7, REF-LINUX-IOURING-ENTER, REF-WIN-IORING-OVERVIEW, REF-WIN-IORING-CREATE, REF-WIN-IORING-SUBMIT.
