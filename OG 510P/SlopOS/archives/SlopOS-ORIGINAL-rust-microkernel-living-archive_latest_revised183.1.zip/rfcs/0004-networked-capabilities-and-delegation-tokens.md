# RFC-0004: Networked capabilities + delegation tokens (D-CAPX)

Status: Draft

Goal: capture a *minimal*, spec-first seam for capability delegation across process/VM/machine boundaries **without** dragging a giant distributed-systems TCB into the privileged core.

## Problem
Our archive is capability-first, but IPC-only capability passing stops at the machine boundary. Real deployments often need:
- a way to hand off **attenuated** authority to remote parties (operators, peers, services)
- a way to audit/attribute that handoff (who delegated what; when; under what constraints)
- a way to do this without reintroducing ambient authority (“network == root”).

We want a direction that *few kernels try seriously*: **networked object capabilities** with explicit delegation trails, compatible with “spec-first, proof-driven” evolution.

## Non-goals
- Not committing to a full distributed-object runtime in kernel.
- Not claiming global revocation, distributed GC, or perfect replay over networks (unless explicitly modeled later).
- Not inventing a bespoke crypto format (reuse D-ENC; keep token logic out of core where possible).

## Candidate decision: D-CAPX (capability export/import model)
Options (kept intentionally small):
1) **Proxy-based CapTP-style references** (REF-CAPTP, REF-OCAPN): exported “capabilities” are references to local objects mediated by a user-space gateway; remote use is message-based.
   - Note: Cap’n Proto RPC provides a mature semantics reference for object-capability RPC (calls-as-caps) and may inform an optional D-CAPRPC profile without committing to its full stack (REF-CAPNP-RPC).
2) **Cryptographic bearer tokens** (REF-MACAROONS-NDSS14, REF-BISCUIT-SPEC): exported “capabilities” are unforgeable tokens encoding attenuation constraints.
3) **Hybrid**: CapTP-style object references plus bearer tokens as *attenuation certificates* or offline delegation receipts.

Adjunct (often missing in practice): **offline capabilities** (“SturdyRefs” / capability URIs) that can be restored to live capabilities later; see RFC-0014 + CH-SREF v0.

Default posture: pick (1) first (keeps kernel agnostic; aligns with “no ambient network authority”), keep (2)/(3) as optional adjuncts.

## Minimal seam (what we actually spec)
We define a **wire contract** for exporting/importing delegated authority *as data*:
- CH-CAPX v0 (see `docs/30-architecture/capability-export-schema-v0.md`)
  - note: `token_kind == "sturdyref"` is reserved for CH-SREF v0 bytes

Key idea: CH-CAPX describes an *opaque* token plus explicit bindings to our local authority graph (cap/proxy IDs). The privileged core never needs to understand macaroon/biscuit/captp internals; it only validates:
- canonical encoding (I-ENC-1)
- binding to declared authority objects (I-CAPX-1)
- monotonic attenuation commitments if we support local checks (I-CAPX-2)

If we keep token logic in user space, the privileged core only needs to support:
- stable capability/proxy identifiers (non-forgeable handles)
- an audit transcript hook (CH-LOG v0) for delegation events

## Invariants (added)
- **I-CAPX-1 (No ambient remote authority)**: any remote authority usable on this system must be traceable to an explicit handoff event and bind to a local capability/proxy identifier.
- **I-CAPX-2 (Delegation attenuation is monotonic)**: if a token can be “derived” (attenuated), any derived token cannot exceed the authority of its parent under the declared attenuation relation.

## Proof obligations (added; keep scoped)
- **PO-CAPX-BIND**: any accepted CH-CAPX object is bound to a concrete local authority object (cap/proxy ID) and schema version; mismatches fail closed.
- **PO-CAPX-ATTEN**: for the chosen token form (macaroon/biscuit/other), “adding caveats/constraints” is non-removable and results in monotonic attenuation (within the formal token semantics we adopt).

## Abuse cases to pressure-test early
- **AC-012**: attacker strips caveats or swaps bindings (token confusion) to regain authority.

## Evidence plan (tight)
Phase 0/1:
- property tests: CH-CAPX decode/encode canonicalization; binding checks reject mismatches
- fuzzing: token parser *outside core* (if any)
- transcript tests: delegation events are logged with digests and schema versions (I-LOG-1)

Phase 2/3:
- bounded model checks for the binding/attenuation relation (PO-CAPX-BIND/ATTEN) on a small token subset
- mechanize the chosen token calculus only if we actually claim D-CAPX security properties (otherwise keep as non-claim direction)

## Design notes (lessons from others)
- Capability systems *can* support confinement and revocation patterns, but it depends on explicit construction and careful design (REF-EROS-CONFINEMENT).
- Networked capability systems exist but stayed niche (CapTP/OCapN); they are a rich source of “sharp” design constraints we can adopt without importing their full runtimes.
- If we ever expose capability strings/URLs, treat them as secrets with operational guidance (REF-W3C-CAPURLS, REF-TAHOE-LAFS).

## Archive impact
- Adds D-CAPX to the decision map.
- Adds CH-CAPX v0 schema and registry entry.
- Adds I-CAPX-1/2 invariants + PO-CAPX-BIND/ATTEN obligations.
- Adds AC-012 abuse case.
