# RFC-0099: Accessibility + automation as leased, audited capabilities (D-UIAUT)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-UIAUT, D-UICAP, D-PLUMB, D-LEASE, D-VOLITION, D-EXPLAIN

## Summary
Modern OSes routinely ship “accessibility” and “automation” APIs that are effectively **global hooks**: they can observe UI structure/text and inject input across apps. These are valuable for assistive tech and testing, but they become a common malware escalation channel.

This RFC adds an explicit seam so we can support accessibility/automation without ambient authority:

- UI observation/injection is granted only via **portal-mediated sessions** that return capability handles.
- Sessions are **leased** by default (TTL, renew via portal) and **attributable** via a bounded descriptor **CH-UIAUT v0**.
- Rights are **separated**: observation does not imply injection.
- Active sessions imply **shell-driven indicators** (not requester-controlled UI).

The privileged core remains unchanged: the UI root/compositor and portal services implement the policy and the enforcement.

## Motivation
Real-world patterns:
- Assistive tooling needs to query focus, UI tree structure, or read selected accessibility text.
- Test automation needs controlled injection.
- Remote desktop/remote support needs injection but must be explicit, temporary, and visibly indicated.

Failure mode:
- If the OS exposes ambient/global “automation” channels, any compromised app can become a global UI parasite (scrape + click) with poor attribution and weak revocation.

D-UICAP already removes ambient screen readback and routes input via a focus chain, but without a disciplined seam we risk reintroducing ambient hooks “for compatibility.” D-UIAUT makes the high-risk exception explicit and auditable.

## Integration seam (keep TCB small)
Kernel impact: none.

User-space responsibilities:
- UI root/compositor provides the primitive capabilities (`UiA11y`/`UiAutomation`) and enforces focus/input routing.
- An accessibility/automation portal mediates grant workflows, returns leased proxies (D-LEASE), and emits CH-UIAUT descriptors for audit.

## Design

### A) Session-first model
Instead of global APIs, expose portal sessions:
- `portal.a11y.observe(...)` → returns `UiA11y` handle + CH-UIAUT descriptor (kind `a11y_observe`).
- `portal.a11y.inject(...)` → returns `UiAutomation` handle + CH-UIAUT descriptor (kind `a11y_inject`).
- `portal.automation.test(...)` → dev/test automation sessions (kind `automation_test`).
- `portal.remotedesktop(...)` may also mint an automation session descriptor (kind `automation_remote`) when injection is enabled.

### B) Rights separation
Rights are expressed as a closed allowlist in CH-UIAUT:
- Observation rights: `observe_focus`, `observe_tree`, `observe_text`.
- Injection rights: `inject_keyboard`, `inject_pointer`, `global_hotkeys`.

Defaults:
- Accessibility SHOULD default to observation-only.
- Injection SHOULD require additional policy gates (higher trust, stronger indicators, and often fresh consent/volition).

### C) Scope
Scope is explicitly declared and should be clamped:
- `global` is highest risk (requires the strongest policy).
- `app` scope can be bounded by canonical component identity.
- `view` scope may be used when the UI stack supports stable, non-secret view tokens.

CH-UIAUT MUST NOT include window titles, UI text, host paths, or stable kernel IDs.

### D) Lease posture + indicators
- Sessions SHOULD be leased by default: TTL, renewable only via portal mediation.
- Sessions MUST be revocable.
- Profiles SHOULD require shell-driven indicators for any active observation/injection session.

### E) Composition with consent receipts
When policy requires user consent:
- Portal grants should bind to CH-AUTHZ/CH-RECEIPT (and CH-VOL for high-risk injection) so audit trails can answer: who asked, what scope/rights, and for how long.

## Registries impacted

### Decision map
- Add **D-UIAUT**.

### Schemas
- Add **CH-UIAUT v0**: `docs/30-architecture/ui-automation-lease-schema-v0.md`.

### Invariants
- Add **I-UIAUT-1..3** (no ambient hooks; lease+indicator; transcripted grants).

### Proof obligations
- Add **PO-UIAUT-VALIDATE** (canonical decode/closed enums/bounds).
- Add **PO-UIAUT-ENF** (rights+TTL enforced; no bypass; indicators not spoofable).

### Threat model
- Add abuse case **AC-084** (accessibility/automation abuse).

### Evidence plan
- Add evidence seed **EVID-2026-101**:
  - validator tests for CH-UIAUT (closed rights; bounds; unknown-key rejection)
  - negative tests: observe-only sessions cannot inject; no ambient constructors exist
  - lease tests: TTL expiry + revocation restores focus-only delivery deterministically
  - indicator tests: active session implies shell indicator; requester cannot spoof indicator

## Alternatives
- Ambient global hooks (traditional): rejected for default profiles.
- Kernel-enforced UI permissions: rejected (TCB expansion); user-space portals + leased proxies are sufficient.
- “Only prompts”: rejected as the sole mechanism (consent fatigue); prompts can exist, but grants must remain attributable, scoped, and time-bounded.

## References
REF-ANDROID-ACCESSIBILITYSERVICE, REF-APPLE-ACCESSIBILITY-TRUST, REF-WIN-UIACCESS, REF-FUCHSIA-FOCUSCHAIN.
