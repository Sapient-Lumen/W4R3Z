# RFC-0023: Local naming certificates (SPKI/SDSI-style) (D-NAMECERT)

Status: Draft

Goal: add a small, optional seam for **linked local namespaces** and **delegation** that plays nicely with capability mode and networked capability handoff, without importing a large PKI or global naming scheme.

Refs: REF-SDSI-RL96, REF-SPKI-RFC2692, REF-SPKI-RFC2693.

## Why this exists
Capability systems often struggle with *usability*: “what is this opaque cap?” and “how do we refer to it safely across time and machines?”

SDSI’s key lesson is that names should be **local**, linkable, and compositional rather than globally hierarchical. SPKI’s focus on **authorization** (not identity) matches our posture: we care about *authority edges* and their attenuation.

We already have **view objects** (name→cap resolution) and **sturdyrefs** (offline capability-bearing references). D-NAMECERT complements those by letting a domain carry a small set of **signed bindings** that name keys/caps and allow controlled delegation.

## Design stance (minimal)
### 1) Certificates live in user space
The privileged core should not implement certificate parsing or chain discovery.

Instead:
- a user-space “naming service” ingests certificate bundles
- produces a **view** (or a view fragment) that resolves local names to caps/proxies
- binds decisions into CH-LOG for audit if they affect privileged configuration

### 2) Keep the format tiny
Introduce **CH-NAMECERT v0** as a canonical envelope for a small bundle of:
- local name bindings (name → key/cap reference)
- delegation statements (issuer authorizes subject for a named role/capability set)

This is not X.509 and not a general policy language.

### 3) Interop with D-CAPX
If D-CAPX is enabled, CH-NAMECERT can help:
- label/organize remote authorities (keys/proxies) in a local namespace
- document delegation edges as explicit evidence objects

## Candidate invariants / obligations (optional)
- **I-NAME-1 (Local naming is explicit, optional)**: any name→cap resolution that matters for authority is traceable to an explicit view and/or a pinned CH-NAMECERT bundle; no ambient/global name service is consulted.
- **I-NAME-2 (Delegation is non-amplifying, optional)**: evaluating a certificate bundle cannot yield authority beyond what is explicitly delegated; “chain” resolution is monotonic under the declared delegation rules.

Associated proof obligations:
- **PO-NAMECERT-VALIDATE**: CH-NAMECERT decoding/validation is deterministic; rejects unknown variants; enforces bounds.
- **PO-NAMECERT-CHAIN**: chain evaluation (in user space) is sound w.r.t. the declared delegation semantics and cannot amplify authority.

## Abuse cases
See AC-029..AC-030.

## Evidence plan (tight)
Phase 1 (E1):
- implement a tiny CH-NAMECERT validator + reference evaluator for one constrained semantics
- negative tests: name shadowing/alias attacks; chain substitution; ambiguous parsing

Phase 2 (E2):
- bounded model check on “name graph + delegation edges” (reachability/attenuation)

## Archive impact
- Adds D-NAMECERT entry in the decision map.
- Adds CH-NAMECERT v0 schema + schema registry row.
- Adds PO/AC/EVID hooks for certificate bundle validation + chain soundness.
