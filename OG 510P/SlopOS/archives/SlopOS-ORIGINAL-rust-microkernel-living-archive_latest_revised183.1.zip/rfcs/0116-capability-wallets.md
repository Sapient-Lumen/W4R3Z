# RFC-0116: Capability wallets (CH-WALLET v0)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): D-WALLET, D-CAPSHELL (adjunct), D-EXPLAIN (adjunct), D-SEAL/D-CAPMODE (adjunct), D-PLUMB (adjunct)

## Summary
Automation and “glue” work best when humans can quickly answer:
- **what authority is active right now?**
- **what would widen it?**
- **did it drift since last review?**

This RFC introduces **CH-WALLET v0**, a *non-authoritative* descriptor that summarizes a component/job’s intended authority bundle:
- allowed effect families (CH-PLEDGE tokens),
- handle inventory at the level of cap kinds/rights,
- and (optionally) digests of typed descriptors (leases, capture sessions, transfers) used for receipts/audit.

CH-WALLET is designed for prompts, receipts, runbooks, and CI drift gates. It is not a capability container.

## Motivation
Empirically, sandboxing mechanisms exist but see low direct adoption; ecosystems rely on wrappers and packaging to apply confinement. That only works if the tooling is ergonomic and audit-friendly.

A “wallet” object makes three things cheap:
1) **Operator comprehension**: the shell prompt can show a wallet digest and a short, stable summary of active authority.
2) **Compositional pipelines**: passing a wallet along a pipeline makes authority flow explicit (and reviewable) rather than implicit ambient inheritance.
3) **Drift gates**: once a job is sealed, widening promises or adding new authority kinds can be made a deterministic CI failure.

Refs: REF-SHILL-OSDI14, REF-SANDBOX-ADOPTION-ARXIV24.

## Goals
- **Non-authoritative by construction**: CH-WALLET cannot be used to obtain capabilities or bearer secrets.
- **Stable, typed summaries**: ties naturally to CH-PLEDGE, CH-CAPDIFF, and portal/lease descriptors.
- **Adoptable**: usable for wrapper-first launchers and legacy binaries.

## Non-goals
- Defining a new kernel mechanism for capability passing.
- Replacing durable capability formats (CH-SREF/CH-CAPX) or portals.

## Design
### 1) Wallets are descriptors, not containers
CH-WALLET contains:
- a subject identity (component_id/instance_id) as non-authoritative metadata,
- a pledge token list (closed allowlist per profile),
- an inventory of handle **kinds** and optional rights, and
- optional digests of typed descriptors (e.g., CH-NETLEASE/CH-DOCREF/CH-IOLEASE/CH-CAPTURE).

It MUST NOT contain bearer secrets (no CH-SREF tokens, no export envelopes, no raw kernel IDs).

Spec: `docs/30-architecture/capability-wallet-schema-v0.md`.

### 2) Wallet digests are first-class UX and audit hooks
Recommended conventions:
- Shells/automation runners display `digest(CH-WALLET)` in prompts/log headers.
- Receipts (CH-RECEIPT) and transcripts (CH-LOG) may include `wallet_digest` as an optional correlation hint.
- CI rules treat “wallet widening” as evidence-relevant drift.



### 2b) Authority digest normalization (stable identifiers)
CH-WALLET includes some fields that are useful for local indexing or correlation (e.g., timestamps or instance identifiers) but are **not** stable inputs for drift gates.

Tooling SHOULD compute a `wallet_core_digest` over a **normalized projection** that:
- drops volatile fields (`wallet_id`, `issued_at`, `subject.instance_id`, and `meta`),
- sorts token/right lists deterministically, and
- sorts the handle inventory deterministically (see the CH-WALLET schema "Digest normalization" section).

Use `wallet_core_digest` for prompts/receipts/CI drift gates; treat `digest(CH-WALLET)` as an optional correlation id only.
### 3) Wallets compose with explain/diff
Where available:
- include `capgraph_digest` (digest of CH-CAPG snapshot)
- and/or `capdiff_digest` (digest of CH-CAPDIFF relative to a declared baseline).

This keeps “what changed?” machine-checkable and avoids free-form narratives.

## Assurance hooks
New invariants:
- **I-WALLET-1 (Wallets are non-authoritative)**: CH-WALLET descriptors cannot be used to obtain capabilities; they contain no bearer secrets.
- **I-WALLET-2 (Wallets are closed + bounded)**: CH-WALLET decode/validation rejects unknown kinds/rights/tokens and enforces strict bounds.

New proof obligation:
- **PO-WALLET-VALIDATE**: CH-WALLET decoding/validation is total, closed-world, bounded, and enforces the non-authoritative rule.

## Evidence plan
E0:
- Implement a user-space wallet emitter for a wrapper-first launcher (inventory = cap kinds + pledge tokens + selected descriptor digests).
- Add golden tests: unknown kind/unknown token → reject; any attempt to embed a bearer token → reject.

E1:
- Integrate into capshell prompt + CI drift gate: once a job is marked sealed, widening the wallet fails deterministically.

## References
- REF-SHILL-OSDI14
- REF-SANDBOX-ADOPTION-ARXIV24
- REF-TAOUP-SECWRAP
