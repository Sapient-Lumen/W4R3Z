# RFC-0115: Capability-safe shell + automation components (D-CAPSHELL)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-CAPSHELL**, D-COMP (adjunct), D-NS (views), D-SEAL/D-CAPMODE (adjunct), D-PLUMB/D-POWERBOX (adjunct), D-EXPLAIN (adjunct)

## Summary
Shell scripts, cron jobs, CI hooks, and admin runbooks are where least-privilege routinely collapses into ambient authority. We want a *default* path for automation that:
- stays capability-pure (no ambient path opens, no ambient network),
- composes (pipelines don’t “re-ambientize” authority), and
- is adoptable for real ops work (learn mode, good error reporting).

This RFC proposes an **ecosystem** decision node (**D-CAPSHELL**) for a capability-safe automation layer:
- a capability-aware interactive shell mode (for humans), and
- a script/automation runner that treats scripts as **components** with declared authority contracts.

The privileged core does not change.

## Motivation
In practice, the fastest path to “root everywhere” is:
1) a shell script with a few helper binaries,
2) a small, implicit config file,
3) environment variables and ambient filesystem/network access.

Even teams who care about security end up with “just run it as root,” because:
- sandboxing existing command-line tools is tedious,
- pipelines hide authority flow,
- policy failures are hard to debug.

Prior art points at a workable direction:
- **SHILL** shows a capability-safe scripting language that wraps spawned binaries in sandboxes and uses explicit contracts for effects.
- **Plash/Polaris/Capsicum** show that wrapper-based least-privilege can be pragmatic if the ergonomics are good.

Refs: REF-SHILL-OSDI14, REF-PLASH, REF-POLARIS-SOUPS05, REF-CAPSICUM.

## Goals
- **No ambient authority**: scripts and pipeline stages run with only explicit caps and explicit portals.
- **Compositional reasoning**: “this script can only do X” is checkable, even when it shells out.
- **Adoptability**: learn mode, deterministic violations, and a path to incremental hardening.
- **No new privileged TCB**: enforcement lives in user space via existing seams.

## Non-goals
- Replacing POSIX shells immediately.
- Adding a new kernel security mechanism.
- A general-purpose policy language for the whole OS (D-POLICY is separate).

## Design sketch
### 1) Scripts are components
Treat each automation unit as a normal D-COMP component:
- it receives explicit starting caps (views, service endpoints, portal request caps),
- it may perform init work, then should seal down (D-SEAL/D-CAPMODE) before steady-state loops.

This reuses:
- I-COMP-1 (no undeclared edges),
- I-SEAL-1 / I-CAPMODE-1 (post-init narrowing is one-way),
- I-VIEW-1/I-VIEW-2 (no ambient resolution; non-amplifying naming).

### 2) Capability wallets (ergonomic bundling)
Introduce a user-space convention: a **capability wallet** is a bundle of handles + pledge tokens that can be:
- handed to a command as its initial authority set,
- passed along a pipeline intentionally,
- audited/diffed as a single object.

In v0 we standardize a **non-authoritative** descriptor, **CH-WALLET v0**, so wallets can be hashed/diffed and used in prompts, receipts, and CI drift gates.
Actual capability transfer still happens out-of-band (process launch handle passing, portal responses, CapRPC).

### 3) Effect contracts map to CH-PLEDGE
Scripts should declare a contract using CH-PLEDGE token families (or an equivalent closed allowlist):
- `view.open` / `view.resolve`
- `portal.openuri`, `portal.print`, `portal.net`, `portal.xfer`, …
- `exec.spawn` (optional; controlled)

Enforcement remains the same: privileged effects are gated by tokens at the boundary (D-SEAL / CH-PLEDGE profile). The shell/runner just makes contracts ergonomic.

### 4) “Learn mode” for workflows
Borrow the D-SEAL “complain/learn” idea:
- run the script with deny+log for missing contract items,
- emit a deterministic “required token set + missing handles” report,
- allow CI to gate drift (script sealed → tokens must not widen).

### 5) Pipelines must not become ambient channels
Pipelines should avoid ambient inheritance by default:
- stdin/stdout are treated as explicit, bounded stream handles,
- passing file paths is discouraged; pass document/file handles or view-scoped caps instead,
- cross-domain transfers use portals (D-PLUMB) and are leased by default (D-LEASE).

## Options
- **None**: keep automation ad hoc; rely on wrappers and manual sandboxing.
- **Wrapper-first**: ship only a “capsicum/plash-style launcher” and a learn-mode report generator.
- **Integrated capshell** (recommended): wrapper-first + an interactive shell mode where:
  - the prompt reflects active authority (`wallet_core_digest` over CH-WALLET; stable under normalization),
  - common operations (`open`, `share`, `net`) go through portals,
  - sealing is a first-class command.

## Evidence plan
E0:
- Prototype a wrapper-first runner that can execute an unmodified binary under a default-deny view with a small wallet.

E1:
- Dogfood: express a small admin runbook (log bundle capture + upload + reboot gate) as a sealed automation component.
- Negative tests: attempt to open arbitrary paths, dial arbitrary networks, or read clipboard without portal grants.

E2:
- CI drift gate: once sealed, contract tokens cannot widen (deterministic failure on new effect families).

## Open questions
- What is the minimal “wallet” serialization format that stays human-friendly yet unambiguous (while keeping it non-authoritative and small (CH-WALLET))?
- Should capshell expose a constrained *capability passing* primitive for pipelines (handle passing) distinct from byte streams?

## References
- REF-SHILL-OSDI14
- REF-PLASH
- REF-POLARIS-SOUPS05
- REF-CAPSICUM
- REF-TAOUP-SECWRAP
