# RFC-0012: Resource meters, space banks, and budgets (D-METER, D-TCAP)

Status: Draft

Goal: make **resource consumption** (memory objects, endpoints, CPU time, I/O buffers, outbound bytes) an explicit, capability-mediated authority story **without** importing a policy-heavy kernel.

This RFC is intentionally narrow: it defines the *minimum* mechanism seam required to (a) bound denial-of-service where we claim it, (b) attribute consumption (“who paid?”), and (c) keep the result compatible with staged verification.

## Problem
Microkernels often keep “resource policy” vague until late, and then end up with:
- hidden global allocators
- implicit CPU time rights
- un-auditable DoS behavior
- **confused-deputy billing** (services accidentally pay for attacker-driven work)

For our archive, this conflicts with:
- I-METER-1 / PO-METER-CHARGE / PO-METER-NOBYPASS (explicit authority)
- verification posture (keep kernel policy small)
- replay/evidence posture (resource evolution must be explainable)

## Non-goals
- Not promising global fairness, optimal scheduling, or hard real-time guarantees.
- Not requiring one universal accounting model for all devices/accelerators.
- Not committing to persistence/checkpointing for meters (can remain optional).

## Key insight: separate “resource principal” from “protection domain”
A protection domain answers “who can do what”; a resource principal answers “who pays”.

If those are conflated, large systems accumulate hidden sponsorship and billing bugs.
Resource-container work motivates treating the payer identity as a first-class design seam.
Refs: REF-BANGA-RESCONTAINERS.

In our design, **meters** are the canonical payer objects.

## Candidate design stance
We treat meters as **capability-shaped budget containers** with **attenuation-only delegation**.

**Clarification (D-BUDGET):** this RFC uses “budget” broadly. RFC-0058 introduces a concrete, operation-scoped **budget lease** pattern for passing payer authority explicitly at effect boundaries (especially portal workflows) to avoid implicit sponsorship.


### Meter objects (abstract)
Introduce an abstract object kind `Meter` with operations:
- `split(m: Meter, kind, limit) -> Meter` (attenuation-only delegation)
- `charge(m: Meter, kind, amount) -> ok | exhausted`
- `query(m: Meter) -> (remaining, lineage_hint)` (optional; may be privileged)

Kinds are a *closed* set per profile (avoid “stringly policy”):
- `mem_bytes`
- `kernel_refs` (cap slots, endpoints, notification queues, …)
- `io_buf_bytes` (if D-IOBUF)
- `net_bytes` (if D-NETLEASE)
- `cpu_ticks` (if D-TCAP; may be represented by CH-TCAP directly)

### CH-METER v0 (descriptor for logging/audit)
To keep payer attribution debuggable and replay-friendly, any resource-creating privileged action should name an explicit payer and transcript-log a redaction-safe descriptor:
- **CH-METER v0** describes bounds + lineage **without** carrying secrets.
- CH-LOG entries reference `digest(CH-METER)` for payer correlation.

See: CH-METER v0 schema spec.

### Hierarchical delegation: meter trees
A meter split forms a **meter tree**:
- child ≤ parent (attenuation)
- lineage is logged (for audits and “why did we run out?”)

This mirrors the operational success of hierarchical resource control in:
- Linux cgroup v2 (unified hierarchy) and delegation practice (subtree delegation) (REF-CGROUPV2, REF-CGROUP-DELEGATION)
- Fuchsia job trees that apply policies/quotas top-down (REF-FUCHSIA-JOBS, REF-ZIRCON-OBJECTS)
- Windows Job Objects as a securable process-group container with limits/accounting (REF-WIN-JOBOBJECTS)

### Space banks (user space by default)
For memory, prefer a **space-bank style** allocator service in user space:
- the kernel provides *mechanism* for allocating/retyping page objects subject to a meter
- user space provides *policy* (subbanks, quotas per component, reclamation)

This matches classic capability OS practice while keeping policy out of the privileged core.
Refs: REF-KEYKOS-NANOKERNEL.

### Who pays? explicit sponsorship (avoid confused-deputy billing)
Rule of thumb: **expensive work requires an explicit payer**.

Patterns:
- A service that may allocate must either:
  - require the caller to supply a payer meter ("pay for what you ask"), or
  - consciously spend its own meter (and log that decision).
- Requests that carry a payer meter should be modeled as *attenuation-only*: the callee may charge but cannot amplify the budget.

This is the concrete “greenfield advantage”: we can prevent an entire class of billing/DoS bugs by making payer identity explicit at the seam.

### Temporal capabilities (TCaps) as “time meters”
When D-TCAP is enabled:
- runnable time/budget is represented as explicit `TCap` objects
- each `TCap` is associated with a `Meter(kind=cpu_ticks)` (or is itself the meter)
- scheduling becomes “charge-on-run” with deterministic semantics

Refs: REF-SEL4-SCHEDCTX-EUROSYS18, REF-SEL4-MCS-TUTORIAL.

## Kernel object quotas (optional extension: D-KOBJQ)
Even if memory objects are bounded, microkernels can still be DoS’d via **kernel-maintained references** (cap slots, endpoints, signal handlers). When D-KOBJQ is enabled, creation of these reference-like objects is charged to meters/budgets the same way as memory allocations.

This is inspired by Genode’s explicit *cap quota* and *RAM quota* approach.
See: RFC-0034; refs: REF-GENODE-RESMGMT.

## Invariants (additions/refinements)
- **I-METER-1** (existing): charges/grants are capability-mediated; exceed-quota is fail-closed or explicitly attributed.
- **I-METER-2** (existing, conditional): if D-KOBJQ is enabled, no free kernel refs.
- **I-METER-3 (Explicit payer, optional)**: if D-METER is enabled, any privileged effect that creates/expands a resource must identify an explicit **payer** meter (or be an explicit profile exemption); payer selection must be transcript-visible.

- **I-TCAP-1** (existing): time is explicit authority when enabled; charging is deterministic under Phase-1 profile.

## Proof obligations
- **PO-METER-CHARGE** (existing): meter/quota operations are explicit and total; exhaustion is fail-closed or explicitly attributed.
- **PO-METER-NOBYPASS** (existing): any resource-expanding abstract-machine operation must charge a meter or be an explicit profile exemption.

Additions:
- **PO-METER-PAYER**: any resource-creating privileged effect must name a payer meter (CH-METER digest) in its transcript entry.
- **PO-METER-DELEGATE**: `split` is attenuation-only; child limits ≤ parent and lineage is logged.

- **PO-TCAP-ENF** (existing): TCap exhaustion behavior is deterministic and fail-closed.

## Abuse cases (add)
- **AC-020** (existing): meter bypass / quota forgery.
- **AC-048**: confused-deputy billing / sponsorship bug — attacker induces a service to spend its own meter unexpectedly (or to charge a victim meter without explicit consent).

## Evidence plan (tight)
Phase 0/1:
- property tests: split monotonicity; charge totality; exhaustion paths
- negative tests: allocations without payer; ensure fail-closed
- sponsorship tests: service API requires payer for expensive calls; verify logs identify payer

Phase 2:
- bounded model check of a tiny abstract allocator + split/charge rules (ties to PO-METER-DELEGATE/PO-METER-NOBYPASS)

## Archive impact
- Adds **CH-METER v0** schema + schema registry row.
- Updates decision-map D-METER note (payer attribution).
- Adds I-METER-3, PO-METER-PAYER, PO-METER-DELEGATE, and AC-048 entries.
- Adds evidence stubs for payer/monotonicity tests.
