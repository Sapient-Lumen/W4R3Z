# RFC-0081: Activation, handle handoff, and stable service handles (D-ACTIVATE)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): D-ACTIVATE, D-SUPV, D-COMP, D-SEAL (optional), D-LEASE (optional)

## Summary
Bake in an **adoptable zero-downtime restart pattern** without growing the privileged core:

- Treat certain inbound “public” endpoints as **supervisor-owned handles** that are **passed into** a service instance at start (socket-activation style).
- Optionally provide a **per-component handle store** so a service can ask the supervisor to preserve selected handles across restarts (systemd FD store style), under a **manifested allowlist**.
- Keep the design strictly user space: this is a CH-COMP + supervisor/runtime convention, not a new kernel feature.

## Motivation
Crash-only discipline is easiest to live with when restarts don’t drop external traffic and don’t require ad-hoc “warmup ordering.” Many mature systems converged on the same practical trick:

- **systemd socket activation**: a manager binds/listens and passes ready FDs to the service; restarts don’t drop new connections. (REF-SYSTEMD-SOCKET-ACTIVATION, REF-SD-LISTEN-FDS)
- **systemd FD store**: the manager optionally preserves a set of service-provided FDs across restarts to keep continuity. (REF-SYSTEMD-FDSTORE)
- **launchd socket activation**: similar idea on macOS via `launch_activate_socket()`. (REF-LAUNCHD-ACTIVATE-SOCKET)
- **nginx on-the-fly upgrade**: old/new masters coordinate around inherited listening sockets for zero-downtime upgrades. (REF-NGINX-CONTROL)

Microkernel-ish designs already trend toward supervisor-held capability routing; greenfield advantage is to make this *boringly standard* so ecosystems stop reinventing it.

## Design goals
- **No kernel changes required.**
- **No ambient global names.** Activation is an explicit capability delivery event.
- **Restartability as a first-class UX/ops property.**
- **Non-amplifying by construction.** Restarts and preserved handles cannot widen authority.

Non-goals:
- Not a full live state migration story (D-CHKPT/D-PERSIST cover that).
- Not promising strict availability/SLA.

## Design

### 1) Stable service handles (activation-owned exports)
We define a convention: some exported capabilities are **stable handles** owned by the supervisor.

- The supervisor creates the endpoint object(s) (e.g., `SvcPort`, `NetListen`, `UiInput`, etc.) and retains ownership.
- On service start, the supervisor grants the service the right to **serve** on those handles.
- On restart, the supervisor re-grants the same stable handle(s) to the new instance.

This mirrors socket activation: the manager owns the “public” listener and can restart the worker without changing the listener identity.

### 2) Activation set delivery: CH-ACTSET v0
To keep startup deterministic and lintable, the supervisor provides a bounded activation bundle to a service instance as a single object:

- **CH-ACTSET v0** describes a small set of named handles delivered at start.
- The actset is **not authority by itself**; it is a manifest of what capabilities were delivered.

Spec: `docs/30-architecture/activation-set-schema-v0.md`.

### 3) Handle store (optional)
Some services need to preserve continuity across restarts for *selected* handles (e.g., pre-established sockets, session keys, per-instance ring buffers). We add an optional, supervisor-provided **handle store**:

- Each component gets a **private** store namespace keyed by `cid`.
- The service may `Put(key, cap)` and later `Get(key)` after restart.
- Keys are bounded and allowlisted by CH-COMP (closed world).
- The store is bounded by count and total serialized metadata size.

This is the capability-native analog of systemd’s FD store.

### 4) Seal/phase discipline
We must not allow “stash init-only authority, then resurrect it later” as a seal bypass.

Default posture:
- Handle-store `Put()` is permitted **only after seal** (steady state).
- A profile may allow `Put()` during init only if the stored key is explicitly declared `phase=init_ok`.

This makes the interaction with D-SEAL explicit and testable.

### 5) Stop vs kill semantics (operational hygiene)
Supervision needs a deterministic escalation path:
- `Stop(grace)` requests cooperative shutdown (drain/flush within a bounded time).
- If the component does not comply, supervisor escalates to `Kill()`.

This mirrors the pragmatic two-step lifecycle found in component runners. (REF-FUCHSIA-RUNNER-STOP)

## Manifest integration
We extend CH-COMP v0 with an optional `activation` object on each component:

- `stable_exports`: list of exported `cap_kind` values that are supervisor-owned stable handles.
- `handle_store` (optional):
  - `enabled`: bool
  - `key_allowlist`: bounded list of bounded keys (labels; not authority)
  - `max_items`: bounded count
  - `phase`: one of `{ steady_only, init_ok }` (default `steady_only`)

Validation updates are captured in PO-COMP-VALIDATE.

## Registries impacted
Add:
- Decision node: **D-ACTIVATE**
- Schema: **CH-ACTSET v0**
- Invariants: **I-ACTIVATE-1**, **I-ACTIVATE-2**
- Proof obligation: **PO-ACTIVATE-HANDOFF**
- Abuse case: **AC-069** (handle-store misuse / seal bypass / cross-component confusion)
- Evidence seed: **EVID-2026-079**

Update:
- CH-COMP schema doc (activation fields)
- RFC-0009 / RFC-0017 / RFC-0041 (restart posture)
- OS lessons (systemd/launchd/nginx patterns)

## Threat-model notes
Primary risks:
- **Seal bypass by stashing init-only authority**.
- **Cross-component confusion** (wrong instance gets another’s stored handles).
- **DoS via unbounded stored items**.

Mitigations:
- store is per-`cid` and keyed; retrieval requires matching `cid` binding
- explicit `phase` gating tied to seal state
- strict bounds (count + metadata size); deterministic overflow behavior
- restarts remain subject to I-SUPV-1 and PO-SUPV-NOAMP (no authority amplification)
- crash-loop rate limits remain subject to PO-SUPV-RLIMIT

## Evidence plan
E0/E1 prototype:
- Implement a toy supervisor and a `echo-server` style component with:
  - stable listen handle delivered via CH-ACTSET
  - handle-store enabled with 1–2 allowlisted keys
- Tests:
  - restart does not drop new inbound connections (connections queue at manager-owned endpoint)
  - wrong-`cid` retrieval fails closed
  - attempts to `Put()` before seal are rejected under default `steady_only`
  - bound enforcement: overflow yields deterministic error + CH-LOG record

## Alternatives
- **Service binds its own endpoints**: simpler in tiny systems but breaks “restart without drop” and reintroduces ordering hell.
- **Kernel-resident endpoint registry**: stronger continuity but expands privileged TCB and proof surface.
- **No handle store**: still valuable (socket activation), but misses the “preserve a tiny bit of continuity” use-case that avoids full checkpointing.

## Open questions
- Do we want an explicit capability kind for “stable service handle” vs representing it as a supervisor-owned export annotation only?
- Should handle-store keys be enums (closed set) rather than bounded strings for even tighter linting?
