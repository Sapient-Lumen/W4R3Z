# RFC-0095: Media capture portals + session descriptors (camera/mic/screencast without ambient sockets)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-CAPTURE, D-UICAP, D-PLUMB, D-LEASE, D-IOLEASE (adjunct)

## Summary
Define a standard, capability-safe pattern for **high-risk media capture** (camera, microphone, screencast, remote desktop) that:
- avoids ambient “always-on” capture channels (global audio servers, X11-style screen readback),
- makes capture **explicit, attributable, bounded, and revocable**, and
- keeps the privileged core unchanged (user-space portal + user-space media graph).

This RFC introduces **CH-CAPTURE v0**, a bounded descriptor for portal-mediated capture sessions. It is **not** authority; it describes the session bounds and attribution.

## Motivation
Real systems show two converging lessons:
1) **Screen sharing on modern desktops moved behind portals** (Wayland + xdg-desktop-portal) because ambient screen readback is a security failure mode.
2) **Audio capture is still often “ambient by socket”** (PulseAudio/PipeWire sockets granted statically), which makes “record the mic” too easy without a per-session user decision.

PipeWire explicitly supports per-client permissions on graph objects and expects a session manager to decide whether clients may access resources. This is the right *shape* for our design: keep the media graph in user space, concentrate policy in a session manager/portal, and use capability discipline (handles/leases) for access.

A greenfield capability OS can bake in a consistent rule:
- **capture == portal-mediated lease**, with user visibility + revocation,
- **every capture** can emit a bounded descriptor for audit/receipts/export hygiene.

## Non-goals
- Standardizing a full multimedia stack or codec/format registry.
- Mandating PipeWire specifically.
- Making CH-CAPTURE an authorization token.

## Design

### Conceptual model
A **capture portal** is a normal user-space service (e.g., `/svc/portal/capture`) that mediates access to capture sources and capture effects.

Capture sessions are modeled as:
1) a **request**: “start capture” (camera/mic/screencast/remote desktop),
2) an optional **user mediation step** (D-POWERBOX/D-VOLITION policy),
3) a portal-issued **leased capture capability** (D-LEASE) with explicit scope and bounds,
4) an emitted **CH-CAPTURE v0** descriptor logged/receipted by digest.

### No ambient capture (recommended default)
- No component can access camera/mic/screen capture without an explicit portal-issued grant.
- Cross-trust capture SHOULD require fresh user volition (D-VOLITION) and SHOULD be receipt-bound (D-EXPLAIN).

### Transport and implementation freedom
The portal may implement capture delivery using:
- copyless buffer objects (D-IOBUF) for frames/chunks,
- streaming endpoints (e.g., a graph node handle),
- or device-leased raw access (D-IOLEASE) for trusted capture services.

A practical model is the PipeWire pattern: per-client permissions on objects in a media graph, with a session/policy manager deciding which clients may access which resources.

### CH-CAPTURE v0
Introduce CH-CAPTURE v0 as a redaction-aware descriptor for portal-mediated capture sessions.
- Emitted by the portal alongside a grant.
- Logged/receipted by digest.
- Contains **no secret capability material** and MUST NOT embed raw frame/audio bytes.

See: `docs/30-architecture/capture-session-schema-v0.md`.

### Integration with existing seams
- **D-UICAP (RFC-0080):** screenshot/screencast/remote desktop are portal workflows; CH-CAPTURE provides a standard descriptor for those sessions.
- **D-PLUMB (RFC-0046):** add `portal.screencast`, `portal.remotedesktop`, `portal.camera`, and `portal.microphone` families as lease-first portals that can emit CH-CAPTURE.
- **D-LEASE (RFC-0066):** capture grants SHOULD be leased proxies; renewal/escalation are explicit and transcript-visible.
- **D-IOLEASE (RFC-0045):** trusted capture services may hold device leases; apps get only constrained capture endpoints.
- **D-OBSPOL (RFC-0076):** CH-CAPTURE exports must be policy-scoped; capture sessions are typically sensitive metadata.

## Registries impacted
- Add **CH-CAPTURE v0** to the schema registry.
- Add invariants:
  - **I-CAPTURE-1** (no ambient capture; capture is portal-mediated and attributable)
  - **I-CAPTURE-2** (bounded + privacy posture; exports obey CH-OBSPOL; no embedded bytes/paths)
- Add proof obligation:
  - **PO-CAPTURE-VALIDATE** (CH-CAPTURE decoding/validation is total, canonical, bounded)
- Add abuse case:
  - **AC-082** (silent capture / indicator spoofing / scope escalation)
- Add evidence seed:
  - **EVID-2026-093** (CH-CAPTURE spec + portal harness plan)

## Evidence plan
E0: Spec + harness plan (EVID-2026-093):
- golden tests: CH-CAPTURE schema validation (closed enums, bounds, canonical decode)
- portal harness: demonstrate (a) no ambient camera/mic capture, (b) screencast requires explicit grant, (c) lease expiry/renew/escalation is enforced, (d) CH-OBSPOL can redact/forbid export of capture descriptors
- negative tests: background app cannot obtain capture; scope escalation requires fresh consent; capture descriptor cannot smuggle high-entropy payload bytes

## References
Refs: REF-PIPEWIRE-ACCESS, REF-PIPEWIRE-SESSMGR, REF-XDG-PORTAL-SCREENCAST, REF-XDG-PORTAL-REMOTEDESKTOP, REF-XDG-PORTAL-SCREENSHOT, REF-XDG-PORTAL-CAMERA, REF-XDG-PORTAL-AUDIO-ISSUE.
