# RFC-0026: object-capability RPC profile (Cap'n Proto–style) (optional)

Status: draft  
Updated: 2026-02-25

## Motivation
We already have:
- **D-CAPX** (cross-boundary capability export/import)
- **D-IDL** (IDL + codegen)

A recurring ecosystem “sharp edge” is that systems end up reinventing RPC that accidentally reintroduces ambient authority, identity confusion, or weak binding between interface and authorization. Interface evolution is another: upgrades commonly break callers in ways that are hard to diagnose and easy to paper over unsafely (see D-APIEVO).

This RFC introduces an **optional** profile for *capability-based RPC* where the **only** way to invoke a remote service is to hold an explicit object reference (capability handle), and call/return is framed as **message exchange** with canonical encoding.

## Design sketch
- “Remote object” references are capabilities.
- Calls carry:
  - a target object reference (cap handle),
  - a method identifier,
  - a canonical payload,
  - explicit attached capability references.
- Responses carry:
  - deterministic success/error code,
  - canonical payload,
  - explicit capability references.

This profile is intended to live **outside** the privileged core (gateway / RPC runtime in user space) and integrate with:
- CH-CAPX / CH-SREF for export/persistence
- CH-LOG for transcript/replay

## Oneway calls (“pulses”) for notifications (optional)

Some cross-component interactions are better modeled as **bounded notifications** than as request/reply:
- device/timer wakeups,
- backpressure/pressure signals,
- “fire-and-forget” telemetry into a local collector.

QNX Neutrino popularized this shape with **pulses**: fixed-size, nonblocking messages delivered through the same receive path, but with **no reply** semantics. That avoids faking replies, reduces coupling, and keeps the fast path small. (REF-QNX-PULSES)

Proposed CapRPC profile extension:
- Interface methods MAY be marked `oneway` (IDL-level attribute; pinned via CH-IFACE/CH-ORD).
- A oneway call carries the normal CapRPC frame, but the sender does not wait for a reply and the callee MUST NOT attempt to reply.
- Payload and attached capability counts MUST be bounded more tightly than normal calls (so oneway cannot become a stealth bulk-transfer channel).
- Failure semantics must be crisp and testable: either the send deterministically returns an error (not enqueued) or it is accepted for delivery (enqueued). **Silent drop is forbidden** in the profile.

This is a *profile choice*; Phase 1 can omit oneway entirely if it complicates the runtime.

Refs: REF-QNX-PULSES, REF-QNX-MSGSENDPULSE.


## Promise handles + pipelining (optional)

Motivation: without pipelining, any multi-step interaction with remote objects tends to pay **one network round-trip per step**, which makes ocap “object style” APIs unusable across latency.

Profile extension (library/runtime; no privileged-core changes required):
- Remote calls may return **promise handles** (futures) for:
  - data results, and/or
  - capability results (object references produced by the callee).
- The runtime may allow **pipelined sends** to a promise handle *before* it resolves:
  - Semantics: a pipelined call must execute **exactly as-if** it were sent immediately after the promise resolves (same sender identity, same interface/rights checks), or fail with a deterministic framework error.
  - Disconnect/abort: if the underlying connection breaks or the promise is broken, all dependent pipelined calls fail deterministically (e.g., `DISCONNECTED` / `BROKEN_PROMISE`), never “half succeed”.
- Pipelining MUST remain non-amplifying:
  - it cannot be used to bypass `iface_digest` / `method_id` checks,
  - it cannot smuggle additional authority (attachments are still explicit and bounded),
  - and it cannot cause the callee to run “as” a different principal.

Implementation note: Cap’n Proto demonstrates a practical wire approach using “promised answer” paths for pipelined messages; we can adopt the same idea (or an equivalent) while keeping our CH-CAPRPC frame pinned and our IDL/ordinal policy intact.

Refs: REF-CAPNP-RPC, REF-TC39-EVENTUALSEND.

## Request contexts: deadlines + cancellation propagation (recommended adjunct)

Almost every RPC ecosystem eventually reinvents a “request context” that carries:
- cancellation (stop wasted work on disconnect or user abort),
- optional deadlines/timeouts,
- trace correlation.

Go’s `context` package is the canonical operator reality check: request-scoped cancellation + deadlines make shutdown and failure handling far less ad hoc. Structured concurrency runtimes further insist that cancellation propagates to child operations, preventing orphan work. Cap’n Proto’s 1.0 notes that cancellation should be effectively **opt-out**, because “opt in” is too easy to forget in production.

Profile guidance (user space; no privileged-core changes):
- Stub generators SHOULD include a `ctx` parameter by convention (D-REQCTX, RFC-0105).
- Cancellation SHOULD deterministically break outstanding promises/calls when:
  - the caller cancels its context, or
  - the underlying connection disconnects/aborts.
- Deadlines SHOULD be expressed as *intent* and/or via explicit time/budget authority:
  - for local calls: a monotonic deadline intent (and local timers),
  - for metered/time-sensitive calls: pass explicit CH-BUDGET / D-TCAP authority where profiles require “who pays” semantics.
- Outcomes SHOULD be explicit and stable (no silent drops): e.g., framework errors for `CANCELLED` / `DEADLINE_EXCEEDED` (taxonomy pinned for replay/logging).

Correlation hook:
- If desired, CH-CAPRPC v1 may carry an optional `ctx_digest` (digest of CH-REQCTX) purely for logging/postmortems.

Refs: REF-GO-CONTEXT, REF-KOTLIN-CANCEL, REF-CAPNP-1.0-CANCEL.


## Reentrancy hazards and turn-based runtimes (optional)

A common trap in RPC runtimes is to offer a "synchronous" or "await" API that keeps the caller responsive by **pumping inbound messages while waiting**. In capability systems this can create implicit **reentrancy**: a remote party can callback into a service while it is mid-update, violating local invariants and causing confused-deputy style escalation.

To keep reasoning tractable, profiles MAY adopt **D-TURNS** (RFC-0078): run selected services as single-threaded event loops ("vats") that process one inbound message at a time ("turns"), and forbid hidden inbox pumping. In that posture:
- cross-component calls are naturally promise-based (no cross-vat synchronous call chains)
- oneway/pulse methods remain safe as notifications (bounded; no reply paths)
- promise pipelining remains useful without requiring synchronous waits

If D-TURNS is enabled for a service set, CapRPC stub generators should prefer APIs that return promises/streams rather than blocking calls, and test suites should include explicit reentrancy probes (PO-TURNS-NOREENTR).

Refs: REF-ROBUST-COMPOSITION, REF-E-LRM, REF-SPRITELY-CORE.


## Candidate foundation (reference)
Cap’n Proto RPC is a mature instance of object-capability RPC with features like **promise pipelining** and **persistent capabilities**. This RFC does not mandate adopting it wholesale, but uses it as a reference model for semantics and threat posture.

## New decision
- **D-CAPRPC**: adopt a capability-RPC profile as a standard transport/IPC boundary for components (optional).

## New schema (optional outer frame)
- **CH-CAPRPC v0** (payload frame): stable outer wrapper; inner payload is governed by D-IDL.


## Ordinals and interface pins (D-APIEVO refinement)
The CapRPC frame carries both:
- `iface_digest` (CH-IFACE): which interface family is being spoken, and
- `method_id`: which operation within that family.

To make upgrades safe:
- `method_id` assignment MUST be stable (never reused for different semantics).
- For open interfaces, prefer hash-derived ordinals so new methods can be added without renumbering; unknown methods return `UNKNOWN_METHOD` with no side effects.
- Tooling may pin the mapping using **CH-ORD v0** and gate upgrades on collision/reuse.

See RFC-0072 and `docs/60-engineering/idl-digest-and-ordinal-policy.md`.

## Security properties
- No ambient authority: a call requires an explicit object capability.
- No confused deputy by names: method dispatch is keyed by the held reference + method id, not global names.
- Transcriptability: calls/responses can be bound into CH-LOG entries for replay/forensics.

## Invariants / proof obligations
- **I-CAPRPC-1 (RPC endpoints are explicit, optional)**: any RPC invocation that produces effect across a boundary is attributable to an explicit capability handle and method id; there is no ambient endpoint resolution.
- **I-CAPRPC-2 (Oneway calls are bounded and non-silent, optional)**: if oneway/pulse methods are enabled, send semantics are deterministic (enqueue vs error; no silent drop), payload/attachment bounds are enforced, and oneway is permitted only for interface-marked methods.
- **I-CAPRPC-3 (Promise pipelining is explicit and non-amplifying, optional)**: if promise handles / pipelined sends are enabled, pipelined calls execute exactly as-if sent after resolution (or fail deterministically); interface/rights checks are not bypassable.
- **I-TURNS-1 (No implicit reentrancy, optional)**: for D-TURNS components/services, inbound delivery is turn-atomic and blocking/await APIs do not pump inbound messages (RFC-0078).
- **PO-CAPRPC-FRAME**: CH-CAPRPC decoding is canonical and total; unknown variants reject.
- **PO-CAPRPC-ONEWAY**: for `oneway` methods, runtime enforces enqueue-vs-error semantics with no silent drop; reply paths are impossible; tighter bounds are enforced.
- **PO-CAPRPC-PIPELINE**: for promise pipelining, pipelined sends are explicit, deterministic, and non-amplifying; disconnect/abort fails dependent calls with defined errors.
- **PO-CAPRPC-NOAMBIENT**: the runtime cannot initiate calls absent a held reference; resolver/introducer is an explicit capability.
- **PO-TURNS-NOREENTR**: if D-TURNS is enabled, runtime tests demonstrate no implicit reentrancy (no inbox pumping) during a turn.

## Evidence plan
- E1: property tests on frame encode/decode; negative tests for unknown variants.
- E2: bounded model check on a small RPC graph: no call path exists without an explicit handle.

## Open questions
- Should promise pipelining be allowed in Phase 1, or deferred (simpler semantics)?
- Do we standardize one IDL encoding (e.g., capnp) or allow multiple under D-IDL, with explicit per-interface pinning?
