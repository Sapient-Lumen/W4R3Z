# RFC-0029: Transparency log anchors for evidence (release/provenance)

Status: Draft  
Owner: archive  
Last updated: 2026-02-25

## Summary
Introduce an optional transparency-log anchoring seam (D-TLOG) that lets us publish **tamper-evident evidence objects** (e.g., CH-BOOT/CH-PROV digests, release manifests, proof bundle digests) to an append-only verifiable log.

The kernel does not depend on the log. This is release engineering + auditability.

## Motivation
Our long-lived archive is evidence-tracked: we want third parties (or future-us) to verify “this artifact existed at that time” and to detect tampering or equivocation in published releases. Transparency logs (Certificate Transparency and successors) offer a well-understood, verifiable append-only pattern for this. (REF-CT-RFC6962, REF-TLOG-SWTCH).

Sigstore’s Rekor demonstrates a practical software-supply-chain workflow using a transparency log for signed metadata (REF-SIGSTORE-REKOR). Modern log ecosystems are moving toward tile-based APIs (Tessera) for efficient serving and auditing (REF-TESSERA).

## Design

### D-TLOG posture
- **Out-of-band**: log interaction is a release-time (or fleet-audit-time) activity.
- **Optional**: absence of a log anchor does not invalidate runtime claims; it weakens “independent auditability” posture.
- **Small artifacts**: log leaves carry digests and minimal metadata; large blobs stay in artifact stores.

### CH-TLOG v0 (anchor record)
Define a small schema describing what we store/pin as an “anchor”:
- log identity (`log_id`, `pubkey_id`)
- leaf payload digest (e.g., digest of CH-BOOT or an E4 release bundle)
- checkpoint (tree size + root hash + signature) sufficient for auditors to verify append-only growth
- optional inclusion proof pointer (stored externally; referenced by digest)

The CH-TLOG record is used as:
- an attachment in the release bundle
- an input to auditors/monitors
- an optional field in CH-PROV or a release manifest that asserts “this digest was logged”

### Optional: witnessed checkpoints (D-WITNESS)
A standalone append-only log improves auditability but can still attempt **equivocation** (split views).
If higher assurance is needed, enable **D-WITNESS** (RFC-0082): require threshold witness signatures over checkpoints and ship a digest-bound witness bundle alongside CH-TLOG anchors.

### Obligations
- **I-TLOG-1**: if a build/release claims log anchoring, it must provide a verifiable checkpoint binding the artifact digest to the log state.
- **PO-TLOG-VERIFY**: auditors verify checkpoint signatures and consistency relative to prior checkpoints.

## Assumptions impacted (A-IDs)
None.

## Threat-model impact
- Reduces trust in a single publisher by enabling third-party monitoring and later consistency checks.
- Does not prevent initial compromise, but increases detection probability and raises the bar for stealthy tampering.

## Assurance/verification impact
- Adds CH-TLOG v0 schema + registry entry.
- Adds PO-TLOG-VERIFY; evidence is E4 (release artifacts) and E1 (verification tooling).

## Alternatives
- **Run no log**: simplest; weaker audit trail.
- **Run our own Trillian log**: operational cost; still viable later.
- **Rely only on Git history**: does not provide the same anti-equivocation guarantees.

## Evidence plan
- **E1**: a tiny verifier tool that validates a CH-TLOG anchor against a pinned log public key (checkpoint signature).
- **E4**: at least one release bundle that includes CH-BOOT/CH-PROV digests + CH-TLOG anchor records.

## Open questions
- Which log ecosystem to target first (public Rekor vs private Tessera instance).
- Witnesses/cosigning are treated as an optional extension via D-WITNESS (RFC-0082).
