# RFC-0111: Robust locks + owner-death semantics for shared synchronization (D-ROBUSTLOCK)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-ROBUSTLOCK**, D-UWAIT (adjunct), D-METER (adjunct), D-RR (adjunct), D-REQCTX (adjunct)

## Summary
A “wait-on-address” primitive (RFC-0110) makes fast locks possible, but does not by itself prevent a common failure mode:

> A thread/process terminates while holding a user-space lock stored in shared memory; other participants can block forever.

Many mature ecosystems address this with **robust locks**:
- **Linux robust futex ABI**: kernel-assisted cleanup sets an **OWNER_DIED** flag and wakes a waiter on task exit.
- **Windows mutexes**: the waiter acquires the mutex but learns it was **abandoned** (WAIT_ABANDONED) and must treat protected state as suspect.
- **FreeBSD umtx**: explicit registration of robust mutex lists for owner-death cleanup.

We should design for this now because retrofitting “owner-death recovery” later is painful: it touches the ABI for shared-lock words, exit paths, and runtime contracts.

## Goals
- Prevent **permanent deadlock** caused by owner termination while holding a shared user-space lock.
- Make “protected state may be inconsistent” **explicit** to the next acquirer (poison/repair protocol).
- Keep the mechanism **bounded and attributable** (D-METER when enabled).
- Keep the mechanism **non-amplifying** (no new authority is created by opting into robustness).

## Non-goals
- A full kernel lock manager or global priority inheritance policy.
- Making *all* locks robust by default (opt-in only).
- Solving application-specific recovery logic; we only signal “owner died”.

## Design sketch

### 1) Robust sets as explicit objects (recommended)
Introduce an optional kernel object type:

- **RobustSet**: a per-thread (or per-process) registry of user-space lock words that require owner-death cleanup.
- Rights: `REGISTER`, `UNREGISTER`, `ARM` (optional), `QUERY` (optional).
- Charging: each registered entry consumes a bounded amount of kernel state and is charged to the holder’s budget/meter.

This makes the “robust surface” explicit and auditable: it is a capability, can be withheld, and can be quota-bounded.

### 2) What is registered?
A robust entry is a tuple:
- `addr`: address of the lock word
- `kind`: `mutex | rwlock | condvar` (optional; may be used only for wake policy)
- `scope`: `process-local | shared-region`
- `wake_policy`: `wake-one | wake-all` (default wake-one)

**Validation:** the kernel validates that `addr` lies within:
- the process’s address space **and**
- if `scope=shared-region`, within an explicitly shared region object (D-IOBUF / shared-region lineage) for which the caller has write permission.

### 3) Owner token + OWNER_DIED bit
Define a small, language-neutral convention for the lock word:
- a stable **owner token** (e.g., thread handle ID + generation) and
- a single **OWNER_DIED** flag bit.

When a robust owner exits abnormally (or is force-killed) while holding the lock:
1. Kernel sets `OWNER_DIED` in the lock word (atomic OR).
2. Kernel performs a bounded wake on any waiters (via D-UWAIT or equivalent).
3. Next acquirer observes `OWNER_DIED` and returns an explicit error/flag:
   - `OWNER_DIED` / `EOWNERDEAD` / `ABANDONED` analogue.

The runtime must then either:
- **repair** the protected state and call `make_consistent()` (clears OWNER_DIED), or
- **abandon** the lock/state (fail-close, restart component, etc.).

### 4) Interaction with deterministic replay (D-RR)
Owner-death is an externally visible event. If D-RR is enabled, the “owner died” outcome must be recorded as part of the transcript (or surfaced as a replayable decision), so replay does not silently diverge.

### 5) Interaction with request contexts (D-REQCTX)
Robustness is not a substitute for timeouts; but it reduces the need for “timeout as a liveness hack”.
If a wait is cancellable, cancellation must not silently clear OWNER_DIED; it only cancels the caller’s wait.

## API sketch (not final)
- `robust_create(quota) -> RobustSet`
- `robust_register(rs, addr, flags)`
- `robust_unregister(rs, addr)`
- `robust_arm(rs)` (optional: declare “I may hold robust locks”; helps fail-closed auditing)
- `robust_on_exit(rs)` (implicit by kernel on exit; exported only for test harnesses)

User-space lock API surface (library-level):
- `lock() -> ok | owner_died`
- `make_consistent()` (required after owner_died if continuing)

## Security and safety notes
- **Non-amplification:** registering an address must not allow the caller to mutate memory it could not already write. Validation + explicit shared-region scope enforce this.
- **Bounds:** robust sets must be capped; on overflow registration fails deterministically (no silent partial coverage).
- **No hidden oracles:** waking a waiter must not become an information leak beyond what existing wait primitives already permit.

## Alternatives
- “Don’t support this”: pushes recovery into ad-hoc timeouts; shared runtimes will re-invent partial robust schemes.
- Force “process dies on thread crash”: reduces the need for intra-process robustness but does not address inter-process shared-memory locks.
- Kernel-managed lock objects: violates minimality and increases TCB.

## Evidence plan (seed)
- EVID-2026-114: build a small harness that:
  - creates shared lock words, registers them, then kills an owner mid-critical section,
  - checks that a waiter gets `owner_died`,
  - checks bounds/charging behavior,
  - validates determinism hooks for D-RR.

## References (see bibliography)
REF-LINUX-ROBUST-FUTEX-ABI, REF-LINUX-GET-ROBUST-LIST, REF-KERNEL-ROBUST-FUTEXES-TXT,  
REF-FREEBSD-UMTX-OP, REF-WIN-WAITFORSINGLEOBJECT, REF-WIN-WAIT_ABANDONED
