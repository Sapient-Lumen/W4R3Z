# RFC-0014: SturdyRefs + capability URIs (offline capabilities) (D-CAPX adjunct)

Status: Draft

Goal: capture a low-TCB, evidence-friendly way to represent **offline / out-of-band capabilities**:
- survive disconnects and reboots
- can be transmitted via non-live channels (config, QR code, printed string, etc.)
- still fit our “no ambient authority” posture

This is a *user-space gateway* feature by default. Kernel impact should be zero unless we later prove a need.

## Why this matters
Network capability systems often get stuck on one missing primitive: an “offline reference” that can later be turned into a live capability.

The object-capability community calls these **SturdyRefs**: opaque, unguessable references that are restored by an introducer/persistence service (REF-ROBUST-COMPOSITION, REF-CAPTP).

Separately, Tahoe-LAFS demonstrates that “capability strings” can be usable at scale—*if* you treat them as secrets and design for least authority (REF-TAHOE-LAFS, REF-W3C-CAPURLS).

## Non-goals
- Not promising distributed GC or global revocation.
- Not promising that capability URIs are safe to paste into logs.
- Not standardizing a single distributed-object runtime.

## Design stance
We define a schema for an offline capability reference, **CH-SREF v0** ("sturdy reference"), with these properties:
- canonical bytes for hashing/signing (I-ENC-1)
- a *closed* set of kinds and versioning
- an explicit pointer to the restoring authority (introducer) without making the introducer interface itself powerful

Restoration yields a **live** capability/proxy (e.g., via D-CAPX gateway) which then behaves like other capabilities.

## Minimal seam
### 1) Offline reference representation
- CH-SREF v0 schema: `docs/30-architecture/sturdyref-schema-v0.md`

### 2) Restore API shape (conceptual)
We do *not* standardize a full protocol, only the authority constraint:
- The gateway's public bootstrap interface MUST NOT grant meaningful authority.
- All meaningful authority is obtained by presenting a CH-SREF that is unguessable and valid.

This mirrors long-standing guidance in capability-RPC ecosystems (REF-CAPTP; Cap’n Proto capability systems also separate public bootstrap from durable refs).

### 3) Relationship to tokens
CH-SREF does not mandate macaroon/biscuit, but allows embedding an opaque token of either class:
- macaroons: contextual caveats / attenuation receipts (REF-MACAROONS-NDSS14)
- biscuit: datalog blocks / offline attenuation (REF-BISCUIT-SPEC)

## Invariants (additions)
- **I-SREF-1 (Offline capability unforgeability, optional)**:
  - within the chosen crypto assumptions, an attacker cannot construct a CH-SREF that restores to authority they were not delegated.
- **I-SREF-2 (Restore is non-amplifying, optional)**:
  - restoring a CH-SREF yields authority ≤ the reference’s delegated authority (no implicit amplification).

These complement (not replace) I-CAPX-1/2.

## Proof obligations (additions)
- **PO-SREF-RESTORE**:
  - restoration is total and fail-closed: invalid/expired/malformed CH-SREF yields no authority;
  - restoration binds returned live capability/proxy to the presented CH-SREF digest + schema version (for audit and replay).

## Abuse cases (add)
- **AC-021: sturdyref restore confusion**
  - attacker uses a public bootstrap interface to obtain authority, or guesses/brute-forces CH-SREF bearer material, or causes restore() to return a more powerful capability than intended.

## Evidence plan (tight)
Phase 0/1:
- prototype a user-space “introducer” service with:
  - `restore(CH-SREF) -> cap/proxy` (capability-mode + sealed steady state)
  - property tests: invalid refs fail; restored authority matches declared attenuation
  - operational tests: redaction policy prevents CH-SREF leakage through logs

Phase 2:
- bounded model check a tiny restore/attenuation automaton (ties to PO-SREF-RESTORE and PO-CAPX-ATTEN)

## Archive impact
- Adds RFC-0014.
- Adds CH-SREF v0 schema + registry entry.
- Adds I-SREF-1/I-SREF-2 + PO-SREF-RESTORE.
- Adds AC-021.
