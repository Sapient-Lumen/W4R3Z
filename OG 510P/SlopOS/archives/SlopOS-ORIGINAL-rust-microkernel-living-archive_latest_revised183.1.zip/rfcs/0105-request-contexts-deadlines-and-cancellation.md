# RFC-0105: Request contexts (deadlines + cancellation + trace correlation) (D-REQCTX)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-REQCTX**, D-CAPRPC (adjunct), D-TURNS (adjunct), D-BUDGET/D-TCAP (adjunct), D-NONDET (clock posture)

## Summary
Standardize an **optional** request-context seam so the ecosystem doesn’t reinvent “timeouts + cancellation + per-request metadata” in ad hoc ways that leak resources and break replay/debuggability.

This RFC proposes:
- **D-REQCTX**: a profile decision to standardize request contexts.
- **CH-REQCTX v0/v1**: a bounded, redaction-safe descriptor for *request intent* (deadline/budget/trace correlation), used for audit/logging and stable tooling.
- **CH-CAPRPC v1 (optional)**: a small extension of the CapRPC frame that can carry an optional `ctx_digest` (digest of CH-REQCTX) for correlation and postmortems.

Core stance:
- Context is **not authority**. It must not grant rights or bypass policy.
- Cancellation/deadlines are **coordination** and **resource hygiene**, not a security boundary.
- Enforcement lives in user-space runtimes and supervisors; the privileged core stays unchanged.

Refs: REF-GO-CONTEXT, REF-KOTLIN-CANCEL, REF-CAPNP-1.0-CANCEL, REF-VORPUS-TIMEOUTS.

## Motivation
Two recurrent failures in real systems:
1) **Orphan work**: a client disconnects or gives up, but work continues (wasted CPU, stuck locks, leaked handles).
2) **Timeout soup**: timeouts are scattered, inconsistent, and hard to debug (“why did this cancel?”).

Successful ecosystems converge on a single shape:
- pass a request context object across API boundaries,
- it carries a cancellation signal + optional deadline,
- cancellation propagates down the operation tree (“structured concurrency”),
- cancellation/deadline causes are surfaced explicitly as errors and can be logged.

Go’s `context` established the practical pattern for RPC/server stacks (request-scoped cancellation + deadlines). Kotlin and other structured-concurrency runtimes formalize parent→child cancellation propagation. Cap’n Proto RPC notes that cancellation should be “opt-out” rather than “opt-in,” because forgetting to allow cancellation is a common production footgun.

## Non-goals
- Enforcing deadlines in the kernel scheduler (that’s D-TCAP/D-BUDGET territory).
- A general “baggage” KV store that apps can abuse as a covert channel.
- Turning context into an authorization artifact.

## Proposed seam: D-REQCTX
### Option 0 (default): ad hoc per-interface parameters
- Pros: no standardization work.
- Cons: fragmented semantics; poor cancellation propagation; hard to lint.

### Option 1 (recommended, optional): standardize a request context model
- A context is a **capability-owned object** in user space (library/runtime), whose state includes:
  - cancel flag + optional reason,
  - optional deadline intent,
  - optional correlation identifiers (trace/span),
  - optional links to budget descriptors (CH-BUDGET/CH-TCAP digests for audit only).

Key property: **attenuation only**.
- A derived/child context can only narrow:
  - earlier deadlines (never later),
  - smaller budgets (if referenced),
  - fewer tags (if tags are allowlisted and bounded).

### Composition points
- **CapRPC**: generated stubs SHOULD accept a `ctx` parameter by convention; runtimes SHOULD propagate cancellation to in-flight promises/calls.
- **Supervision**: shutdown sequences SHOULD be driven by a “shutdown context” carrying a deadline and cancellation, rather than timers sprinkled across components.
- **Replay/logging**: contexts can be represented as CH-REQCTX descriptors (no secrets) and referenced by digest in logs/frames.

## CH-REQCTX v0/v1 (descriptor)
Spec: `docs/30-architecture/request-context-schema-v0.md` (v0) and `docs/30-architecture/request-context-schema-v1.md` (v1)

A CH-REQCTX is a **descriptor**, not a token:
- it contains no capabilities and grants no authority,
- it is safe to log/export under normal redaction posture,
- it provides stable correlation and intent for diagnostics.

Intended uses:
- CH-LOG entries can reference the context digest for “why did this operation cancel/timeout?”
- CapRPC v1 can carry `ctx_digest` for correlation across services.
- If v1 is used, the context may also reference a CH-CALLCHAIN digest for audit/deny-only uses (see RFC-0118).

## CH-CAPRPC v1 (optional correlation hook)
Spec: `docs/30-architecture/capability-rpc-frame-schema-v1.md`

CH-CAPRPC v1 adds:
- optional `ctx_digest: bytes32` in call frames (digest of CH-REQCTX).

This is deliberately small:
- it does not add a new mandatory field,
- it does not change method dispatch or authority semantics,
- it enables deterministic, tooling-friendly correlation without out-of-band logs.

## Cancellation semantics (profile guidance)
Cancellation should be **cheap and ubiquitous**:
- Default: allow cancellation of outstanding requests when the caller cancels its context or disconnects.
- Propagation: canceling a parent context cancels child operations (structured concurrency).
- Delivery: cancellation becomes an explicit, stable error outcome (e.g., `CANCELLED` / `DEADLINE_EXCEEDED`), not a silent drop.

CapRPC note:
- If promise handles / pipelining are enabled (RFC-0026), cancellation should deterministically break dependent promises/calls on disconnect or explicit cancel.

## Risks & mitigations
- **Context becomes an information leak (“baggage abuse”)**:
  - Mitigation: bound the tag set and values in CH-REQCTX; treat tags as redaction-scoped metadata; do not make them a general-purpose KV store.
- **Deadline ambiguity across clock domains**:
  - Mitigation: CH-REQCTX encodes deadlines as *intent*; enforcement uses explicit clock handles (D-NONDET) or explicit budget/time authority (D-BUDGET/D-TCAP). Avoid “trust the network time” in v0.
- **Cancellation as a kill-switch**:
  - Mitigation: cancellation affects only operations that voluntarily register against the provided context; it does not revoke unrelated authority.

## Assurance wiring (seed)
New invariants (optional; only if D-REQCTX is enabled):
- **I-REQCTX-1 (Context attenuation)**: derived contexts cannot widen deadline/budget intent relative to their parent (monotonic narrowing).
- **I-REQCTX-2 (Deterministic cancel outcomes)**: cancellation/deadline outcomes are explicit and stable (no silent drops); runtimes surface deterministic error codes for cancel/deadline.
- **I-REQCTX-3 (Context is non-authoritative)**: CH-REQCTX contents are informational only; they do not grant authority and must not be used to **grant** privileged effects (veto-only narrowing/deny decisions are allowed).
- **I-REQCTX-4 (Call chain reference is bounded, optional)**: if CH-REQCTX v1 references CH-CALLCHAIN, the call-chain descriptor is bounded, closed-enum, and non-authoritative (see RFC-0118).

New proof obligations (seed):
- **PO-REQCTX-VALIDATE**: CH-REQCTX decoding/validation is canonical and total; bounds enforced; unknown variants reject.
- **PO-REQCTX-ATTEN**: context derivation is monotonic: narrowing only; tests demonstrate that widening attempts fail closed.

## Evidence plan
- EVID-2026-108: CH-REQCTX v0 validator + golden tests (baseline).
- EVID-2026-118: CH-CALLCHAIN v0 + CH-REQCTX v1 validator + bracketing harness (deny-only call-chain uses; exception-safe privilege bracketing).

Harness demonstrates:
  - parent→child cancellation propagation,
  - deadline/timeout surfaces as stable errors,
  - CH-CAPRPC v1 `ctx_digest` correlation shows up in transcripts.

## Alternatives
- **Rely only on D-TCAP/D-BUDGET**: handles “who pays” but not “who cancels” and does not address API ergonomics.
- **Implicit cancellation on disconnect only**: helps but doesn’t solve explicit timeouts or manual cancellation for long ops.

## References
REF-GO-CONTEXT, REF-KOTLIN-CANCEL, REF-CAPNP-1.0-CANCEL, REF-VORPUS-TIMEOUTS.
