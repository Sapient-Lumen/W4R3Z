# RFC-0078: turn-based concurrency + reentrancy guards for capability services (D-TURNS) (optional)

Status: draft  
Updated: 2026-02-25

## Motivation
Object-capability systems often learn (sometimes the hard way) that **access control and concurrency control interact**:
- A capability call can arrive at a surprising time.
- Naive “block waiting for reply while also servicing the inbox” creates **reentrancy** hazards (callbacks into partially updated state).
- If we want deterministic replay (D-RR) and staged verification, reducing concurrency shapes is leverage.

The E-language lineage addresses this by modeling components as **communicating event loops** (“vats”), where each vat processes one message at a time in a **turn**. This keeps local reasoning tractable while still supporting parallelism across vats.

This RFC proposes an **optional deployment/runtime profile** that encourages (and optionally enforces) a turn-based delivery model for selected components and CapRPC services.

Refs: REF-ROBUST-COMPOSITION, REF-E-LRM, REF-E-FAQ, REF-SPRITELY-CORE.

## Non-goals
- Mandate a single concurrency model for the entire OS.
- Replace the kernel scheduling design (D-SCHED / D-TCAP).
- Introduce a heavyweight distributed-object framework into the privileged core.

This is a **user-space runtime discipline** that can be adopted per-component.

## Terminology
- **Vat**: a single-threaded event loop hosting a set of objects.
- **Turn**: processing of one inbound message (including any synchronous local work) to completion.
- **Near vs far**: within a vat, synchronous calls are possible; across vats/domains, calls are treated as asynchronous message sends.

## Problem statement
We want an ecosystem posture where:
- cross-component calls are naturally **asynchronous** (so latency and partial failure are explicit),
- “await” or “block” APIs do **not** secretly pump the inbox (no hidden reentrancy),
- the default service model is easy to fuzz, replay, and reason about.

A classic failure mode is “RPC that looks synchronous”:
1) component A calls B and blocks waiting for reply,
2) the runtime keeps A responsive by servicing inbound calls while blocked,
3) B (or a third party) reenters A via a callback, observing/altering half-mutated state.

This pattern is a confused-deputy factory in capability systems because it combines:
- unexpected control flow,
- partial failure,
- authority-bearing callbacks.

## Proposed profile (D-TURNS)
### 1) Turn-atomic message delivery (default for D-TURNS components)
For components running under D-TURNS:
- inbound messages are queued and delivered **one at a time**
- while a turn is executing, the runtime MUST NOT deliver another inbound message to the same vat
- local synchronous calls are permitted only within the same vat (no cross-vat synchronous call chains)

### 2) Far calls are asynchronous (promise-based)
Across component boundaries:
- a “call” returns a **promise handle** (or framework error)
- results are delivered by a later message/turn
- promise pipelining (RFC-0026) is compatible and encouraged

### 3) No hidden inbox pumping
If an API offers a blocking/awaiting convenience:
- it MUST either block without servicing inbound messages (risking deadlock if misused), OR
- be implemented as scheduling a continuation (preferred) so the vat remains non-reentrant.

The profile forbids “block while pumping inbound,” because it reintroduces reentrancy implicitly.

### 4) Opt-out is explicit and auditable
Some components (e.g., high-performance dataplanes) may prefer multithreading.
- D-TURNS is **optional** and should be enabled only where it buys tractability.
- If enabled for a component, the component’s runtime MUST provide enforcement hooks and test harnesses.

(If we later need a manifest-level declaration, that should be a new schema revision, not an ad-hoc extension of CH-COMP v0.)

## Interaction with other decisions
- **D-CAPRPC**: D-TURNS complements CapRPC by making the default service concurrency model explicit and safe against reentrancy. (RFC-0026)
- **D-RR / D-SCHED**: turn-based services reduce nondeterministic interleavings; record/replay can capture a turn log as a compact summary.
- **D-SEAL / D-CAPMODE**: init→seal and capability mode become easier to apply when long-lived services avoid ad-hoc thread spawning.

## Invariants / proof obligations
- **I-TURNS-1 (No implicit reentrancy, optional)**: for D-TURNS components, inbound message delivery is turn-atomic; blocking/await APIs do not pump inbound messages.
- **PO-TURNS-NOREENTR**: runtime tests demonstrate that while a turn is executing, no inbound call/callback can reenter the vat unless an explicit opt-out is enabled.

## Evidence plan
- E1: “callback reentrancy” regression harness: a service that mutates state, blocks/awaits, and is probed by a remote callback attempt; verify the callback cannot interleave inside the same turn.
- E2: trace/replay integration: log turns as CH-LOG entries (or as a derived CH-TRACE stream) and show replay reproduces the same per-turn effects.

## Open questions
- Should D-TURNS be expressed as a profile flag in CH-COMP v1 or as an interface-level requirement (CH-IFACE) once we rev schemas?
- For components that need multithreading, do we want a standard “vat per shard” pattern (explicit sharding) to keep reasoning tractable?
