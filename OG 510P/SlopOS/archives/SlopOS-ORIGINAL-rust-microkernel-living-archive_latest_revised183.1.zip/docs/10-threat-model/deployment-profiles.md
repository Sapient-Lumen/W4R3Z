# Deployment profiles (scope knobs)

Purpose: constrain claims by explicitly choosing operational assumptions. A claim must name its profile(s) or list the A-IDs it needs.

## Profile P0: Dev/Research (wide scope, weak operational claims)
- Boot: best-effort (A-BOOT-1 not required)
- Updates: no anti-rollback claim
- Devices: may be trusted implicitly for bring-up (but then isolation claims must be scoped)

## Profile P1: High-assurance lab (strong integrity + reproducibility)
- Boot: verified or measured boot (A-BOOT-1)
- Updates: signed metadata (CH-UPD); optional D-TUF repository metadata for freeze/mix-and-match resistance; anti-rollback if A-BOOT-2 satisfied
- Devices/DMA: IOMMU enforced if claiming DMA-aware isolation (A-DMA-1)

## Profile P2: Field/hostile environment (explicitly harder)
- Requires P1 plus explicit physical attacker model (A-OPS-1 tightened)
- Side channels remain non-claims unless separately modeled and mitigated


## Optional profile extensions (must be explicit)
These are *extensions* that further constrain the system and/or introduce additional assumptions. If enabled they must be recorded in CH-CFG `feature_flags` and logged in CH-BOOT/CH-LOG.

The closed set of allowed `feature_flags` values is pinned in:
- `docs/30-architecture/config-toggle-registry.md`

- **`ext.static_partitioning`**: fixed cores + fixed memory partitions; no overcommit; minimal scheduler complexity.
  - Benefit: makes early isolation proofs cheaper.
  - Typical dependencies: D-ARCH (separation-kernel-ish) + D-SCHED deterministic.

- **`ext.microvm`**: minimal, declared device model; no hidden emulation; tight exit/entry budget.
  - Benefit: yields a realistic hypervisor-first A2/A3 slice.
  - Typical dependencies: D-MICROVM + D-XS closed sets.

- **`ext.confidential_computing.attest_only`**: TEE-backed attestation evidence only (integrity evidence only; no isolation claim).
- **`ext.confidential_computing.enforced`**: TEE-backed guest isolation + attestation (claim-scoped isolation per A-CC-1).
  - Benefit: enables attestation-gated secret release and tighter “what ran?” provenance for remote parties, but increases assumption surface.
  - Dependencies: D-CC + A-CC-1 + explicit side-channel posture (D-SIDECH).
  - See: RFC-0064.

- **`ext.cheri`**: capability hardware for pointer provenance/permissions (research/targeted platforms).
  - Benefit: can tighten memory-safety and compartment boundaries for selected components (especially mixed-language driver stacks).
  - Dependencies: A-CHERI-1 + explicit scope (what is CHERI-enforced vs not); side-channel posture unchanged unless separately addressed.
  - Refs: REF-CHERI-INTRO.

- **`ext.capx_remote_delegation`**: optional “remote caps” via CH-CAPX envelope and a user-space gateway.
  - Benefit: least-authority delegation across machines with explicit audit trails.
  - Dependencies: D-CAPX + <I-CAPX-*> + careful observation/redaction posture (C-OBS-1).

- **`ext.wasm_plugins`**: user-space Wasm runtime for extension components with a capability-only host boundary.
  - Benefit: bespoke extensibility without importing large unsafe runtimes into the privileged core.
  - Dependencies: D-WASM + I-WASM-1 + D-SEAL (recommended for long-lived hosts).

- **`ext.ifc_lite`**: decentralized information-flow control for a scoped subset of IPC/buffer/object operations.
  - Benefit: makes privacy/integrity confinement properties expressible and testable without central MAC policy.
  - Dependencies: D-IFC + I-IFC-1/I-IFC-2 + PO-IFC-STEP; explicit label/tag budget limits.

- **`ext.user_mode_pager`**: faults/exceptions delivered as IPC to declared pager/exception servers.
  - Benefit: shrinks kernel paging policy and makes fault handling explicit/auditable.
  - Dependencies: D-PAGER + I-PAGER-1 + DoS posture (D-METER recommended).